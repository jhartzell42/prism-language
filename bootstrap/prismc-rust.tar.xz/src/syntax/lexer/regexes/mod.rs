//! The module `Syntax.Lexer.Regexes`, from `target/bootstrap/src/prismc/syntax/lexer/regexes.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// let percentMessage
/// ```
pub fn percent_message() -> Text {
    Text::lit("`%` is no operator: the remainder is `mod`, and `%` begins a regular expression only as `%/` or `%#/`")
}

/// ```prism
/// LexRegex: unbounded fn Lex, Text, Nat -> Lex
/// ```
pub fn lex_regex(l: &crate::syntax::lexer::Lex, sigils: &Text, start: &Nat) -> crate::syntax::lexer::Lex {
    let pct = l.pos.clone();
    let open = hashes_end(&l.src, &(&pct + &Nat::from(1u32)));
    let hashes = crate::syntax::lexer::chars::between(&l.src, &(&pct + &Nat::from(1u32)), &open);
    if &crate::syntax::lexer::chars::char_at_byte(&l.src, &open) != &Text::lit("/") {
        no_regex(l, &pct, &open, &hashes)
    } else {
        {
            let close = Text::from(format!("/{}", &hashes));
            let end_opt = if &hashes == &Text::lit("") {
                plain_end(&l.src, &(&open + &Nat::from(1u32)))
            } else {
                hashed_end(&l.src, &(&open + &Nat::from(1u32)), &close)
            };
            match &end_opt {
                Some(e) => after_pattern(l, sigils, start, &(&open + &Nat::from(1u32)), e, &close),
                None => unclosed(l, sigils, start, &crate::syntax::lexer::chars::between(&l.src, &(&open + &Nat::from(1u32)), &line_end_at(&l.src, &open)), &(&open + &Nat::from(1u32)), &None, &Text::lit("pattern"), &close),
            }
        }
    }
}

/// The step machine of `LexRegex`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexRegex: unbounded fn Lex, Text, Nat -> Lex
/// ```
pub struct LexRegex {
    pub l: crate::syntax::lexer::Lex,
    pub sigils: Text,
    pub start: Nat,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for LexRegex {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l = &self.l;
        let sigils = &self.sigils;
        let start = &self.start;
        let pct = l.pos.clone();
        let open = hashes_end(&l.src, &(&pct + &Nat::from(1u32)));
        let hashes = crate::syntax::lexer::chars::between(&l.src, &(&pct + &Nat::from(1u32)), &open);
        if &crate::syntax::lexer::chars::char_at_byte(&l.src, &open) != &Text::lit("/") {
            prism_rtl::Turn::Finished(no_regex(l, &pct, &open, &hashes))
        } else {
            {
                let close = Text::from(format!("/{}", &hashes));
                let end_opt = if &hashes == &Text::lit("") {
                    plain_end(&l.src, &(&open + &Nat::from(1u32)))
                } else {
                    hashed_end(&l.src, &(&open + &Nat::from(1u32)), &close)
                };
                match &end_opt {
                    Some(e) => prism_rtl::Turn::More(Rc::new(AfterPattern { l: l.clone(), sigils: sigils.clone(), start: start.clone(), at_: &open + &Nat::from(1u32), end: e.clone(), close: close.clone() })),
                    None => prism_rtl::Turn::More(Rc::new(Unclosed { l: l.clone(), sigils: sigils.clone(), start: start.clone(), pattern: crate::syntax::lexer::chars::between(&l.src, &(&open + &Nat::from(1u32)), &line_end_at(&l.src, &open)), at_: &open + &Nat::from(1u32), replacement_opt: None, what: Text::lit("pattern"), close: close.clone() })),
                }
            }
        }
    }
}

/// `Start LexRegex, x`: what the function value is when passed to `@Run`.
pub fn start_lex_regex(l: crate::syntax::lexer::Lex, sigils: Text, start: Nat) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(LexRegex { l, sigils, start })
}

/// ```prism
/// NoRegex: fn Lex, Nat, Nat, Text -> Lex
/// ```
pub fn no_regex(l: &crate::syntax::lexer::Lex, pct: &Nat, open: &Nat, hashes: &Text) -> crate::syntax::lexer::Lex {
    let end = if hashes == &Text::lit("") { pct + &Nat::from(1u32) } else { open.clone() };
    let message = if hashes == &Text::lit("") {
        percent_message()
    } else {
        Text::lit("a hashed regular expression opens with `%`, its hashes and `/`: `%#/.../#`")
    };
    let l1 = {
        let mut this: crate::syntax::lexer::Lex = l.clone();
        this.pos = end.clone();
        this
    };
    let l2 = crate::syntax::lexer::chars::lex_err(&l1, pct, &end, &message);
    let mut this: crate::syntax::lexer::Lex = l2.clone();
    this.last_ws = true;
    this
}

/// ```prism
/// AfterPattern: unbounded fn Lex, Text, Nat, Nat, Nat, Text -> Lex
/// ```
pub fn after_pattern(l: &crate::syntax::lexer::Lex, sigils: &Text, start: &Nat, at_: &Nat, end: &Nat, close: &Text) -> crate::syntax::lexer::Lex {
    let src = l.src.clone();
    let pattern = crate::syntax::lexer::chars::between(&src, at_, end);
    let after_ = end + &len_text(close);
    let run_end = letters_end(&src, &after_);
    let run_ = crate::syntax::lexer::chars::between(&src, &after_, &run_end);
    let c = crate::syntax::lexer::chars::char_at_byte(&src, &run_end);
    let plain = close == &Text::lit("/");
    if (((&c == &Text::lit("")) || (&c == &Text::lit("\n"))) || crate::syntax::lexer::chars::contains(&Text::lit(",)]}:;"), &c)) || (plain && crate::syntax::lexer::chars::is_space_char(&c)) {
        finish(l, sigils, start, &pattern, at_, &None, &Nat::from(0u32), &after_)
    } else {
        if crate::syntax::lexer::chars::has_prefix(&text_from(&src, &run_end), close) {
            finish(l, sigils, start, &pattern, at_, &Some(run_.clone()), &after_, &(&run_end + &len_text(close)))
        } else {
            if plain && (&run_ == &Text::lit("")) {
                match plain_end(&src, &after_) {
                    Some(e) => finish(l, sigils, start, &pattern, at_, &Some(crate::syntax::lexer::chars::between(&src, &after_, &e)), &after_, &(&e + &Nat::from(1u32))),
                    None => unclosed(l, sigils, start, &pattern, at_, &Some(crate::syntax::lexer::chars::between(&src, &after_, &line_end_at(&src, &after_))), &Text::lit("replacement"), close),
                }
            } else {
                if !plain && ((&run_ == &Text::lit("")) || crate::syntax::lexer::chars::is_space_char(&c)) {
                    match hashed_end(&src, &after_, close) {
                        Some(e) => finish(l, sigils, start, &pattern, at_, &Some(crate::syntax::lexer::chars::between(&src, &after_, &e)), &after_, &(&e + &len_text(close))),
                        None => finish(l, sigils, start, &pattern, at_, &None, &Nat::from(0u32), &after_),
                    }
                } else {
                    finish(l, sigils, start, &pattern, at_, &None, &Nat::from(0u32), &after_)
                }
            }
        }
    }
}

/// The step machine of `AfterPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AfterPattern: unbounded fn Lex, Text, Nat, Nat, Nat, Text -> Lex
/// ```
pub struct AfterPattern {
    pub l: crate::syntax::lexer::Lex,
    pub sigils: Text,
    pub start: Nat,
    pub at_: Nat,
    pub end: Nat,
    pub close: Text,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for AfterPattern {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l = &self.l;
        let sigils = &self.sigils;
        let start = &self.start;
        let at_ = &self.at_;
        let end = &self.end;
        let close = &self.close;
        let src = l.src.clone();
        let pattern = crate::syntax::lexer::chars::between(&src, at_, end);
        let after_ = end + &len_text(close);
        let run_end = letters_end(&src, &after_);
        let run_ = crate::syntax::lexer::chars::between(&src, &after_, &run_end);
        let c = crate::syntax::lexer::chars::char_at_byte(&src, &run_end);
        let plain = close == &Text::lit("/");
        if (((&c == &Text::lit("")) || (&c == &Text::lit("\n"))) || crate::syntax::lexer::chars::contains(&Text::lit(",)]}:;"), &c)) || (plain && crate::syntax::lexer::chars::is_space_char(&c)) {
            prism_rtl::Turn::More(Rc::new(Finish { l: l.clone(), sigils: sigils.clone(), start: start.clone(), pattern: pattern.clone(), at_: at_.clone(), replacement_opt: None, replacement_at: Nat::from(0u32), flags_at: after_.clone() }))
        } else {
            if crate::syntax::lexer::chars::has_prefix(&text_from(&src, &run_end), close) {
                prism_rtl::Turn::More(Rc::new(Finish { l: l.clone(), sigils: sigils.clone(), start: start.clone(), pattern: pattern.clone(), at_: at_.clone(), replacement_opt: Some(run_.clone()), replacement_at: after_.clone(), flags_at: &run_end + &len_text(close) }))
            } else {
                if plain && (&run_ == &Text::lit("")) {
                    match plain_end(&src, &after_) {
                        Some(e) => prism_rtl::Turn::More(Rc::new(Finish { l: l.clone(), sigils: sigils.clone(), start: start.clone(), pattern: pattern.clone(), at_: at_.clone(), replacement_opt: Some(crate::syntax::lexer::chars::between(&src, &after_, &e)), replacement_at: after_.clone(), flags_at: &e + &Nat::from(1u32) })),
                        None => prism_rtl::Turn::More(Rc::new(Unclosed { l: l.clone(), sigils: sigils.clone(), start: start.clone(), pattern: pattern.clone(), at_: at_.clone(), replacement_opt: Some(crate::syntax::lexer::chars::between(&src, &after_, &line_end_at(&src, &after_))), what: Text::lit("replacement"), close: close.clone() })),
                    }
                } else {
                    if !plain && ((&run_ == &Text::lit("")) || crate::syntax::lexer::chars::is_space_char(&c)) {
                        {
                            let at_ = at_.clone();
                            let close = close.clone();
                            let l = l.clone();
                            let sigils = sigils.clone();
                            let start = start.clone();
                            call_then(start_hashed_end(src.clone(), after_.clone(), close.clone()), move |hashed_end_3454: Option<Nat>| match hashed_end_3454 {
                                Some(e) => prism_rtl::Turn::More(Rc::new(Finish { l: l.clone(), sigils: sigils.clone(), start: start.clone(), pattern: pattern.clone(), at_: at_.clone(), replacement_opt: Some(crate::syntax::lexer::chars::between(&src, &after_, &e)), replacement_at: after_.clone(), flags_at: &e + &len_text(&close) })),
                                None => prism_rtl::Turn::More(Rc::new(Finish { l: l.clone(), sigils: sigils.clone(), start: start.clone(), pattern: pattern.clone(), at_: at_.clone(), replacement_opt: None, replacement_at: Nat::from(0u32), flags_at: after_.clone() })),
                            })
                        }
                    } else {
                        prism_rtl::Turn::More(Rc::new(Finish { l: l.clone(), sigils: sigils.clone(), start: start.clone(), pattern: pattern.clone(), at_: at_.clone(), replacement_opt: None, replacement_at: Nat::from(0u32), flags_at: after_.clone() }))
                    }
                }
            }
        }
    }
}

/// `Start AfterPattern, x`: what the function value is when passed to `@Run`.
pub fn start_after_pattern(l: crate::syntax::lexer::Lex, sigils: Text, start: Nat, at_: Nat, end: Nat, close: Text) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(AfterPattern { l, sigils, start, at_, end, close })
}

/// ```prism
/// Finish: unbounded fn Lex, Text, Nat, Text, Nat, ?Text, Nat, Nat -> Lex
/// ```
pub fn finish(l: &crate::syntax::lexer::Lex, sigils: &Text, start: &Nat, pattern: &Text, at_: &Nat, replacement_opt: &Option<Text>, replacement_at: &Nat, flags_at: &Nat) -> crate::syntax::lexer::Lex {
    let src = l.src.clone();
    let flags_end = letters_end(&src, flags_at);
    let lit = crate::syntax::RegexLit { pattern: pattern.clone(), pattern_at: at_.clone(), replacement: replacement_opt.clone(), replacement_at: replacement_at.clone(), flags: crate::syntax::lexer::chars::between(&src, flags_at, &flags_end), flags_at: flags_at.clone() };
    let tail = ident_end(&src, &flags_end);
    let l1 = {
        let mut this: crate::syntax::lexer::Lex = l.clone();
        this.pos = tail.clone();
        this
    };
    let l2 = if &tail > &flags_end {
        crate::syntax::lexer::chars::lex_err(&l1, &flags_end, &tail, &Text::from(format!("`{}` touches the flags of a regular expression: the flags are letters, and no name character follows them", &crate::syntax::lexer::chars::between(&src, &flags_end, &tail))))
    } else {
        l1.clone()
    };
    crate::syntax::lexer::push_tok(&l2, &crate::syntax::lexer::TokKind::KRegex(sigils.clone(), lit.clone()), start, &flags_end)
}

/// The step machine of `Finish`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Finish: unbounded fn Lex, Text, Nat, Text, Nat, ?Text, Nat, Nat -> Lex
/// ```
pub struct Finish {
    pub l: crate::syntax::lexer::Lex,
    pub sigils: Text,
    pub start: Nat,
    pub pattern: Text,
    pub at_: Nat,
    pub replacement_opt: Option<Text>,
    pub replacement_at: Nat,
    pub flags_at: Nat,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for Finish {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l = &self.l;
        let sigils = &self.sigils;
        let start = &self.start;
        let pattern = &self.pattern;
        let at_ = &self.at_;
        let replacement_opt = &self.replacement_opt;
        let replacement_at = &self.replacement_at;
        let flags_at = &self.flags_at;
        let src = l.src.clone();
        let flags_end = letters_end(&src, flags_at);
        let lit = crate::syntax::RegexLit { pattern: pattern.clone(), pattern_at: at_.clone(), replacement: replacement_opt.clone(), replacement_at: replacement_at.clone(), flags: crate::syntax::lexer::chars::between(&src, flags_at, &flags_end), flags_at: flags_at.clone() };
        let tail = ident_end(&src, &flags_end);
        let l1 = {
            let mut this: crate::syntax::lexer::Lex = l.clone();
            this.pos = tail.clone();
            this
        };
        let l2 = if &tail > &flags_end {
            crate::syntax::lexer::chars::lex_err(&l1, &flags_end, &tail, &Text::from(format!("`{}` touches the flags of a regular expression: the flags are letters, and no name character follows them", &crate::syntax::lexer::chars::between(&src, &flags_end, &tail))))
        } else {
            l1.clone()
        };
        prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok(&l2, &crate::syntax::lexer::TokKind::KRegex(sigils.clone(), lit.clone()), start, &flags_end))
    }
}

/// `Start Finish, x`: what the function value is when passed to `@Run`.
pub fn start_finish(l: crate::syntax::lexer::Lex, sigils: Text, start: Nat, pattern: Text, at_: Nat, replacement_opt: Option<Text>, replacement_at: Nat, flags_at: Nat) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(Finish { l, sigils, start, pattern, at_, replacement_opt, replacement_at, flags_at })
}

/// ```prism
/// Unclosed: unbounded fn Lex, Text, Nat, Text, Nat, ?Text, Text, Text -> Lex
/// ```
pub fn unclosed(l: &crate::syntax::lexer::Lex, sigils: &Text, start: &Nat, pattern: &Text, at_: &Nat, replacement_opt: &Option<Text>, what: &Text, close: &Text) -> crate::syntax::lexer::Lex {
    let end = line_end_at(&l.src, at_);
    let lit = crate::syntax::RegexLit { pattern: pattern.clone(), pattern_at: at_.clone(), replacement: replacement_opt.clone(), replacement_at: at_.clone(), flags: Text::lit(""), flags_at: end.clone() };
    let l1 = {
        let mut this: crate::syntax::lexer::Lex = l.clone();
        this.pos = end.clone();
        this
    };
    let l2 = crate::syntax::lexer::chars::lex_err(&l1, start, &end, &Text::from(format!("a regular expression ends on its line: close its {} with `{}`", what, close)));
    crate::syntax::lexer::push_tok(&l2, &crate::syntax::lexer::TokKind::KRegex(sigils.clone(), lit.clone()), start, &end)
}

/// The step machine of `Unclosed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Unclosed: unbounded fn Lex, Text, Nat, Text, Nat, ?Text, Text, Text -> Lex
/// ```
pub struct Unclosed {
    pub l: crate::syntax::lexer::Lex,
    pub sigils: Text,
    pub start: Nat,
    pub pattern: Text,
    pub at_: Nat,
    pub replacement_opt: Option<Text>,
    pub what: Text,
    pub close: Text,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for Unclosed {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l = &self.l;
        let sigils = &self.sigils;
        let start = &self.start;
        let pattern = &self.pattern;
        let at_ = &self.at_;
        let replacement_opt = &self.replacement_opt;
        let what = &self.what;
        let close = &self.close;
        let end = line_end_at(&l.src, at_);
        let lit = crate::syntax::RegexLit { pattern: pattern.clone(), pattern_at: at_.clone(), replacement: replacement_opt.clone(), replacement_at: at_.clone(), flags: Text::lit(""), flags_at: end.clone() };
        let l1 = {
            let mut this: crate::syntax::lexer::Lex = l.clone();
            this.pos = end.clone();
            this
        };
        let l2 = crate::syntax::lexer::chars::lex_err(&l1, start, &end, &Text::from(format!("a regular expression ends on its line: close its {} with `{}`", what, close)));
        prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok(&l2, &crate::syntax::lexer::TokKind::KRegex(sigils.clone(), lit.clone()), start, &end))
    }
}

/// `Start Unclosed, x`: what the function value is when passed to `@Run`.
pub fn start_unclosed(l: crate::syntax::lexer::Lex, sigils: Text, start: Nat, pattern: Text, at_: Nat, replacement_opt: Option<Text>, what: Text, close: Text) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(Unclosed { l, sigils, start, pattern, at_, replacement_opt, what, close })
}

/// ```prism
/// ?PlainEnd: fn Text, Nat -> ?Nat
/// ```
pub fn plain_end(src: &Text, at_: &Nat) -> Option<Nat> {
    match crate::syntax::lexer::chars::match_end(&{ thread_local!(static R: Regex = Regex::lit("(?:[^\\/\\\\\\n]|\\\\[^\\n])*\\/", "")); R.with(Regex::clone) }, src, at_) {
        e if (&e > at_) => (&e).checked_sub(&Nat::from(1u32)),
        _ => None,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ?HashedEnd: unbounded fn Text, Nat, Text -> ?Nat
/// ```
pub fn hashed_end(src: &Text, at_: &Nat, close: &Text) -> Option<Nat> {
    let (found_opt, _, _) = {
        let mut this: (Option<Nat>, Nat, bool) = (None, at_.clone(), true);
        let mut i: Nat = at_.clone();
        let mut going: bool = true;
        let mut found_opt: Option<Nat> = None;
        while going {
            let c = crate::syntax::lexer::chars::char_at_byte(src, &i);
            if (&c == &Text::lit("")) || (&c == &Text::lit("\n")) {
                going = false;
            } else if (&c == &Text::lit("/")) && crate::syntax::lexer::chars::has_prefix(&text_from(src, &i), close) {
                found_opt = Some(i.clone());
                going = false;
            } else {
                i = &i + &len_text(&c);
            }
        }
        this = (found_opt.clone(), i.clone(), going);
        this
    };
    found_opt.clone()
}

/// The step machine of `HashedEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?HashedEnd: unbounded fn Text, Nat, Text -> ?Nat
/// ```
pub struct HashedEnd {
    pub src: Text,
    pub at_: Nat,
    pub close: Text,
}

impl prism_rtl::Job<Option<Nat>> for HashedEnd {
    fn cycle(&self) -> prism_rtl::Turn<Option<Nat>> {
        let src = &self.src;
        let at_ = &self.at_;
        let close = &self.close;
        let mut this: (Option<Nat>, Nat, bool) = (None, at_.clone(), true);
        let mut i: Nat = at_.clone();
        let mut going: bool = true;
        let mut found_opt: Option<Nat> = None;
        let at_ = at_.clone();
        call_then(loop_job((found_opt, this, going, i), {
            let close = close.clone();
            let src = src.clone();
            move |(mut found_opt, mut this, mut going, mut i): (Option<Nat>, (Option<Nat>, Nat, bool), bool, Nat)| if going {
                {
                    let c = crate::syntax::lexer::chars::char_at_byte(&src, &i);
                    if (&c == &Text::lit("")) || (&c == &Text::lit("\n")) {
                        going = false;
                    } else if (&c == &Text::lit("/")) && crate::syntax::lexer::chars::has_prefix(&text_from(&src, &i), &close) {
                        found_opt = Some(i.clone());
                        going = false;
                    } else {
                        i = &i + &len_text(&c);
                    }
                    Ok((found_opt, this, going, i))
                }
            } else {
                Err((found_opt, this, going, i))
            }
        }), move |(mut found_opt, mut this, mut going, mut i): (Option<Nat>, (Option<Nat>, Nat, bool), bool, Nat)| {
            this = (found_opt.clone(), i.clone(), going);
            let (found_opt, _, _) = this;
            prism_rtl::Turn::Finished(found_opt.clone())
        })
    }
}

/// `Start HashedEnd, x`: what the function value is when passed to `@Run`.
pub fn start_hashed_end(src: Text, at_: Nat, close: Text) -> Rc<dyn prism_rtl::Job<Option<Nat>>> {
    Rc::new(HashedEnd { src, at_, close })
}

/// ```prism
/// HashesEnd: fn Text, Nat -> Nat
/// ```
pub fn hashes_end(src: &Text, at_: &Nat) -> Nat {
    crate::syntax::lexer::chars::match_end(&{ thread_local!(static R: Regex = Regex::lit("#*", "")); R.with(Regex::clone) }, src, at_)
}

/// ```prism
/// LettersEnd: fn Text, Nat -> Nat
/// ```
pub fn letters_end(src: &Text, at_: &Nat) -> Nat {
    crate::syntax::lexer::chars::match_end(&{ thread_local!(static R: Regex = Regex::lit("[A-Za-z]*", "")); R.with(Regex::clone) }, src, at_)
}

/// ```prism
/// IdentEnd: fn Text, Nat -> Nat
/// ```
pub fn ident_end(src: &Text, at_: &Nat) -> Nat {
    crate::syntax::lexer::chars::match_end(&{ thread_local!(static R: Regex = Regex::lit("[A-Za-z0-9_]*", "")); R.with(Regex::clone) }, src, at_)
}

/// ```prism
/// LineEndAt: fn Text, Nat -> Nat
/// ```
pub fn line_end_at(src: &Text, at_: &Nat) -> Nat {
    crate::syntax::lexer::chars::match_end(&{ thread_local!(static R: Regex = Regex::lit("[^\\n]*", "")); R.with(Regex::clone) }, src, at_)
}

/// ```prism
/// TextFrom: fn Text, Nat -> Text
/// ```
pub fn text_from(src: &Text, at_: &Nat) -> Text {
    match cursor_at(src, at_) {
        Some(c) => after(&c),
        None => Text::lit(""),
    }
}
