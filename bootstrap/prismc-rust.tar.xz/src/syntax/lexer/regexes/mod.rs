//! The module `Syntax.Lexer.Regexes`, from `target/bootstrap/src/prismc/syntax/lexer/regexes.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// let percentMessage
/// ```
pub fn percent_message_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("`%` is no operator: the remainder is `mod`, and `%` begins a regular expression only as `%/` or `%#/`")
}

/// ```prism
/// LexRegex: unbounded fn Lex, Text, Nat -> Lex
/// ```
pub fn lex_regex_f(l_p0: &crate::syntax::lexer::Lex, sigils_p1: &crate::prelude::Text, start_p2: &crate::prelude::Nat) -> crate::syntax::lexer::Lex {
    let pct_p3 = l_p0.pos_p.clone();
    let open_p4 = hashes_end_f(&l_p0.src_p, &(&pct_p3 + &crate::prelude::Nat::from(1u32)));
    let hashes_p5 = crate::syntax::lexer::chars::between_f(&l_p0.src_p, &(&pct_p3 + &crate::prelude::Nat::from(1u32)), &open_p4);
    if &crate::syntax::lexer::chars::char_at_byte_f(&l_p0.src_p, &open_p4) != &crate::prelude::Text::lit("/") {
        no_regex_f(l_p0, &pct_p3, &open_p4, &hashes_p5)
    } else {
        {
            let close_p6 = crate::prelude::Text::from(format!("/{}", &hashes_p5));
            let end_o7 = if &hashes_p5 == &crate::prelude::Text::lit("") {
                plain_end_o(&l_p0.src_p, &(&open_p4 + &crate::prelude::Nat::from(1u32)))
            } else {
                hashed_end_o(&l_p0.src_p, &(&open_p4 + &crate::prelude::Nat::from(1u32)), &close_p6)
            };
            match &end_o7 {
                ::std::option::Option::Some(e_p8) => after_pattern_f(l_p0, sigils_p1, start_p2, &(&open_p4 + &crate::prelude::Nat::from(1u32)), e_p8, &close_p6),
                ::std::option::Option::None => unclosed_f(l_p0, sigils_p1, start_p2, &crate::syntax::lexer::chars::between_f(&l_p0.src_p, &(&open_p4 + &crate::prelude::Nat::from(1u32)), &line_end_at_f(&l_p0.src_p, &open_p4)), &(&open_p4 + &crate::prelude::Nat::from(1u32)), &::std::option::Option::None, &crate::prelude::Text::lit("pattern"), &close_p6),
            }
        }
    }
}

/// The step machine of `LexRegex`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexRegex: unbounded fn Lex, Text, Nat -> Lex
/// ```
pub struct LexRegex {
    pub l_p0: crate::syntax::lexer::Lex,
    pub sigils_p1: crate::prelude::Text,
    pub start_p2: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::syntax::lexer::Lex> for LexRegex {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l_p0 = &self.l_p0;
        let sigils_p1 = &self.sigils_p1;
        let start_p2 = &self.start_p2;
        let pct_p3 = l_p0.pos_p.clone();
        let open_p4 = hashes_end_f(&l_p0.src_p, &(&pct_p3 + &crate::prelude::Nat::from(1u32)));
        let hashes_p5 = crate::syntax::lexer::chars::between_f(&l_p0.src_p, &(&pct_p3 + &crate::prelude::Nat::from(1u32)), &open_p4);
        if &crate::syntax::lexer::chars::char_at_byte_f(&l_p0.src_p, &open_p4) != &crate::prelude::Text::lit("/") {
            ::prism_rtl::Turn::Finished(no_regex_f(l_p0, &pct_p3, &open_p4, &hashes_p5))
        } else {
            {
                let close_p6 = crate::prelude::Text::from(format!("/{}", &hashes_p5));
                let close_p6z = close_p6.clone();
                let l_p0z = l_p0.clone();
                let open_p4z = open_p4.clone();
                let sigils_p1z = sigils_p1.clone();
                let start_p2z = start_p2.clone();
                let k_let1184 = move |v1184: ::std::option::Option<crate::prelude::Nat>| {
                    let end_o7 = v1184;
                    match &end_o7 {
                        ::std::option::Option::Some(e_p8) => ::prism_rtl::Turn::More(::std::rc::Rc::new(AfterPattern { l_p0: l_p0z.clone(), sigils_p1: sigils_p1z.clone(), start_p2: start_p2z.clone(), at_p3: &open_p4z + &crate::prelude::Nat::from(1u32), end_p4: e_p8.clone(), close_p5: close_p6z.clone() })),
                        ::std::option::Option::None => ::prism_rtl::Turn::More(::std::rc::Rc::new(Unclosed { l_p0: l_p0z.clone(), sigils_p1: sigils_p1z.clone(), start_p2: start_p2z.clone(), pattern_p3: crate::syntax::lexer::chars::between_f(&l_p0z.src_p, &(&open_p4z + &crate::prelude::Nat::from(1u32)), &line_end_at_f(&l_p0z.src_p, &open_p4z)), at_p4: &open_p4z + &crate::prelude::Nat::from(1u32), replacement_o5: ::std::option::Option::None, what_p6: crate::prelude::Text::lit("pattern"), close_p7: close_p6z.clone() })),
                    }
                };
                if &hashes_p5 == &crate::prelude::Text::lit("") {
                    k_let1184(plain_end_o(&l_p0.src_p, &(&open_p4 + &crate::prelude::Nat::from(1u32))))
                } else {
                    {
                        let l_p0x = l_p0.clone();
                        crate::prelude::call_then(start_hashed_end_o(l_p0x.src_p.clone(), &open_p4 + &crate::prelude::Nat::from(1u32), close_p6.clone()), move |hashed_end_o_1244: ::std::option::Option<crate::prelude::Nat>| k_let1184(hashed_end_o_1244))
                    }
                }
            }
        }
    }
}

/// `Start LexRegex, x`: what the function value is when passed to `@Run`.
pub fn start_lex_regex_f(l_p0: crate::syntax::lexer::Lex, sigils_p1: crate::prelude::Text, start_p2: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::lexer::Lex>> {
    ::std::rc::Rc::new(LexRegex { l_p0, sigils_p1, start_p2 })
}

/// ```prism
/// NoRegex: fn Lex, Nat, Nat, Text -> Lex
/// ```
pub fn no_regex_f(l_p0: &crate::syntax::lexer::Lex, pct_p1: &crate::prelude::Nat, open_p2: &crate::prelude::Nat, hashes_p3: &crate::prelude::Text) -> crate::syntax::lexer::Lex {
    let end_p4 = if hashes_p3 == &crate::prelude::Text::lit("") {
        pct_p1 + &crate::prelude::Nat::from(1u32)
    } else {
        open_p2.clone()
    };
    let message_p5 = if hashes_p3 == &crate::prelude::Text::lit("") {
        percent_message_p()
    } else {
        crate::prelude::Text::lit("a hashed regular expression opens with `%`, its hashes and `/`: `%#/.../#`")
    };
    let l1_p6 = {
        let mut this: crate::syntax::lexer::Lex = l_p0.clone();
        this.pos_p = end_p4.clone();
        this
    };
    let l2_p7 = crate::syntax::lexer::chars::lex_err_f(&l1_p6, pct_p1, &end_p4, &message_p5);
    let mut this: crate::syntax::lexer::Lex = l2_p7.clone();
    this.last_ws_p = true;
    this
}

/// ```prism
/// AfterPattern: unbounded fn Lex, Text, Nat, Nat, Nat, Text -> Lex
/// ```
pub fn after_pattern_f(l_p0: &crate::syntax::lexer::Lex, sigils_p1: &crate::prelude::Text, start_p2: &crate::prelude::Nat, at_p3: &crate::prelude::Nat, end_p4: &crate::prelude::Nat, close_p5: &crate::prelude::Text) -> crate::syntax::lexer::Lex {
    let src_p6 = l_p0.src_p.clone();
    let pattern_p7 = crate::syntax::lexer::chars::between_f(&src_p6, at_p3, end_p4);
    let after_p8 = end_p4 + &crate::prelude::len_text(close_p5);
    let run_end_p9 = letters_end_f(&src_p6, &after_p8);
    let run_pa = crate::syntax::lexer::chars::between_f(&src_p6, &after_p8, &run_end_p9);
    let c_pb = crate::syntax::lexer::chars::char_at_byte_f(&src_p6, &run_end_p9);
    let plain_pc = close_p5 == &crate::prelude::Text::lit("/");
    if (((&c_pb == &crate::prelude::Text::lit("")) || (&c_pb == &crate::prelude::Text::lit("\n"))) || crate::syntax::lexer::chars::contains_f(&crate::prelude::Text::lit(",)]}:;"), &c_pb)) || (plain_pc && crate::syntax::lexer::chars::is_space_char_f(&c_pb)) {
        finish_f(l_p0, sigils_p1, start_p2, &pattern_p7, at_p3, &::std::option::Option::None, &crate::prelude::Nat::from(0u32), &after_p8)
    } else {
        if crate::syntax::lexer::chars::has_prefix_f(&text_from_f(&src_p6, &run_end_p9), close_p5) {
            finish_f(l_p0, sigils_p1, start_p2, &pattern_p7, at_p3, &::std::option::Option::Some(run_pa.clone()), &after_p8, &(&run_end_p9 + &crate::prelude::len_text(close_p5)))
        } else {
            if plain_pc && (&run_pa == &crate::prelude::Text::lit("")) {
                match plain_end_o(&src_p6, &after_p8) {
                    ::std::option::Option::Some(e_pd) => finish_f(l_p0, sigils_p1, start_p2, &pattern_p7, at_p3, &::std::option::Option::Some(crate::syntax::lexer::chars::between_f(&src_p6, &after_p8, &e_pd)), &after_p8, &(&e_pd + &crate::prelude::Nat::from(1u32))),
                    ::std::option::Option::None => unclosed_f(l_p0, sigils_p1, start_p2, &pattern_p7, at_p3, &::std::option::Option::Some(crate::syntax::lexer::chars::between_f(&src_p6, &after_p8, &line_end_at_f(&src_p6, &after_p8))), &crate::prelude::Text::lit("replacement"), close_p5),
                }
            } else {
                if !plain_pc && ((&run_pa == &crate::prelude::Text::lit("")) || crate::syntax::lexer::chars::is_space_char_f(&c_pb)) {
                    match hashed_end_o(&src_p6, &after_p8, close_p5) {
                        ::std::option::Option::Some(e_pe) => finish_f(l_p0, sigils_p1, start_p2, &pattern_p7, at_p3, &::std::option::Option::Some(crate::syntax::lexer::chars::between_f(&src_p6, &after_p8, &e_pe)), &after_p8, &(&e_pe + &crate::prelude::len_text(close_p5))),
                        ::std::option::Option::None => finish_f(l_p0, sigils_p1, start_p2, &pattern_p7, at_p3, &::std::option::Option::None, &crate::prelude::Nat::from(0u32), &after_p8),
                    }
                } else {
                    finish_f(l_p0, sigils_p1, start_p2, &pattern_p7, at_p3, &::std::option::Option::None, &crate::prelude::Nat::from(0u32), &after_p8)
                }
            }
        }
    }
}

/// The step machine of `AfterPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AfterPattern: unbounded fn Lex, Text, Nat, Nat, Nat, Text -> Lex
/// ```
pub struct AfterPattern {
    pub l_p0: crate::syntax::lexer::Lex,
    pub sigils_p1: crate::prelude::Text,
    pub start_p2: crate::prelude::Nat,
    pub at_p3: crate::prelude::Nat,
    pub end_p4: crate::prelude::Nat,
    pub close_p5: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::syntax::lexer::Lex> for AfterPattern {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l_p0 = &self.l_p0;
        let sigils_p1 = &self.sigils_p1;
        let start_p2 = &self.start_p2;
        let at_p3 = &self.at_p3;
        let end_p4 = &self.end_p4;
        let close_p5 = &self.close_p5;
        let src_p6 = l_p0.src_p.clone();
        let pattern_p7 = crate::syntax::lexer::chars::between_f(&src_p6, at_p3, end_p4);
        let after_p8 = end_p4 + &crate::prelude::len_text(close_p5);
        let run_end_p9 = letters_end_f(&src_p6, &after_p8);
        let run_pa = crate::syntax::lexer::chars::between_f(&src_p6, &after_p8, &run_end_p9);
        let c_pb = crate::syntax::lexer::chars::char_at_byte_f(&src_p6, &run_end_p9);
        let plain_pc = close_p5 == &crate::prelude::Text::lit("/");
        if (((&c_pb == &crate::prelude::Text::lit("")) || (&c_pb == &crate::prelude::Text::lit("\n"))) || crate::syntax::lexer::chars::contains_f(&crate::prelude::Text::lit(",)]}:;"), &c_pb)) || (plain_pc && crate::syntax::lexer::chars::is_space_char_f(&c_pb)) {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(Finish { l_p0: l_p0.clone(), sigils_p1: sigils_p1.clone(), start_p2: start_p2.clone(), pattern_p3: pattern_p7.clone(), at_p4: at_p3.clone(), replacement_o5: ::std::option::Option::None, replacement_at_p6: crate::prelude::Nat::from(0u32), flags_at_p7: after_p8.clone() }))
        } else {
            if crate::syntax::lexer::chars::has_prefix_f(&text_from_f(&src_p6, &run_end_p9), close_p5) {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(Finish { l_p0: l_p0.clone(), sigils_p1: sigils_p1.clone(), start_p2: start_p2.clone(), pattern_p3: pattern_p7.clone(), at_p4: at_p3.clone(), replacement_o5: ::std::option::Option::Some(run_pa.clone()), replacement_at_p6: after_p8.clone(), flags_at_p7: &run_end_p9 + &crate::prelude::len_text(close_p5) }))
            } else {
                if plain_pc && (&run_pa == &crate::prelude::Text::lit("")) {
                    match plain_end_o(&src_p6, &after_p8) {
                        ::std::option::Option::Some(e_pd) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Finish { l_p0: l_p0.clone(), sigils_p1: sigils_p1.clone(), start_p2: start_p2.clone(), pattern_p3: pattern_p7.clone(), at_p4: at_p3.clone(), replacement_o5: ::std::option::Option::Some(crate::syntax::lexer::chars::between_f(&src_p6, &after_p8, &e_pd)), replacement_at_p6: after_p8.clone(), flags_at_p7: &e_pd + &crate::prelude::Nat::from(1u32) })),
                        ::std::option::Option::None => ::prism_rtl::Turn::More(::std::rc::Rc::new(Unclosed { l_p0: l_p0.clone(), sigils_p1: sigils_p1.clone(), start_p2: start_p2.clone(), pattern_p3: pattern_p7.clone(), at_p4: at_p3.clone(), replacement_o5: ::std::option::Option::Some(crate::syntax::lexer::chars::between_f(&src_p6, &after_p8, &line_end_at_f(&src_p6, &after_p8))), what_p6: crate::prelude::Text::lit("replacement"), close_p7: close_p5.clone() })),
                    }
                } else {
                    if !plain_pc && ((&run_pa == &crate::prelude::Text::lit("")) || crate::syntax::lexer::chars::is_space_char_f(&c_pb)) {
                        {
                            let at_p3x = at_p3.clone();
                            let close_p5x = close_p5.clone();
                            let l_p0x = l_p0.clone();
                            let sigils_p1x = sigils_p1.clone();
                            let start_p2x = start_p2.clone();
                            crate::prelude::call_then(start_hashed_end_o(src_p6.clone(), after_p8.clone(), close_p5x.clone()), move |hashed_end_o_3454: ::std::option::Option<crate::prelude::Nat>| match hashed_end_o_3454 {
                                ::std::option::Option::Some(e_pe) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Finish { l_p0: l_p0x.clone(), sigils_p1: sigils_p1x.clone(), start_p2: start_p2x.clone(), pattern_p3: pattern_p7.clone(), at_p4: at_p3x.clone(), replacement_o5: ::std::option::Option::Some(crate::syntax::lexer::chars::between_f(&src_p6, &after_p8, &e_pe)), replacement_at_p6: after_p8.clone(), flags_at_p7: &e_pe + &crate::prelude::len_text(&close_p5x) })),
                                ::std::option::Option::None => ::prism_rtl::Turn::More(::std::rc::Rc::new(Finish { l_p0: l_p0x.clone(), sigils_p1: sigils_p1x.clone(), start_p2: start_p2x.clone(), pattern_p3: pattern_p7.clone(), at_p4: at_p3x.clone(), replacement_o5: ::std::option::Option::None, replacement_at_p6: crate::prelude::Nat::from(0u32), flags_at_p7: after_p8.clone() })),
                            })
                        }
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(Finish { l_p0: l_p0.clone(), sigils_p1: sigils_p1.clone(), start_p2: start_p2.clone(), pattern_p3: pattern_p7.clone(), at_p4: at_p3.clone(), replacement_o5: ::std::option::Option::None, replacement_at_p6: crate::prelude::Nat::from(0u32), flags_at_p7: after_p8.clone() }))
                    }
                }
            }
        }
    }
}

/// `Start AfterPattern, x`: what the function value is when passed to `@Run`.
pub fn start_after_pattern_f(l_p0: crate::syntax::lexer::Lex, sigils_p1: crate::prelude::Text, start_p2: crate::prelude::Nat, at_p3: crate::prelude::Nat, end_p4: crate::prelude::Nat, close_p5: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::lexer::Lex>> {
    ::std::rc::Rc::new(AfterPattern { l_p0, sigils_p1, start_p2, at_p3, end_p4, close_p5 })
}

/// ```prism
/// Finish: unbounded fn Lex, Text, Nat, Text, Nat, ?Text, Nat, Nat -> Lex
/// ```
pub fn finish_f(l_p0: &crate::syntax::lexer::Lex, sigils_p1: &crate::prelude::Text, start_p2: &crate::prelude::Nat, pattern_p3: &crate::prelude::Text, at_p4: &crate::prelude::Nat, replacement_o5: &::std::option::Option<crate::prelude::Text>, replacement_at_p6: &crate::prelude::Nat, flags_at_p7: &crate::prelude::Nat) -> crate::syntax::lexer::Lex {
    let src_p8 = l_p0.src_p.clone();
    let flags_end_p9 = letters_end_f(&src_p8, flags_at_p7);
    let lit_pa = crate::syntax::RegexLit { pattern_p: pattern_p3.clone(), pattern_at_p: at_p4.clone(), replacement_o: replacement_o5.clone(), replacement_at_p: replacement_at_p6.clone(), flags_p: crate::syntax::lexer::chars::between_f(&src_p8, flags_at_p7, &flags_end_p9), flags_at_p: flags_at_p7.clone() };
    let tail_pb = ident_end_f(&src_p8, &flags_end_p9);
    let l1_pc = {
        let mut this: crate::syntax::lexer::Lex = l_p0.clone();
        this.pos_p = tail_pb.clone();
        this
    };
    let l2_pd = if &tail_pb > &flags_end_p9 {
        crate::syntax::lexer::chars::lex_err_f(&l1_pc, &flags_end_p9, &tail_pb, &crate::prelude::Text::from(format!("`{}` touches the flags of a regular expression: the flags are letters, and no name character follows them", &crate::syntax::lexer::chars::between_f(&src_p8, &flags_end_p9, &tail_pb))))
    } else {
        l1_pc.clone()
    };
    crate::syntax::lexer::push_tok_f(&l2_pd, &crate::syntax::lexer::TokKind::KRegex(sigils_p1.clone(), lit_pa.clone()), start_p2, &flags_end_p9)
}

/// The step machine of `Finish`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Finish: unbounded fn Lex, Text, Nat, Text, Nat, ?Text, Nat, Nat -> Lex
/// ```
pub struct Finish {
    pub l_p0: crate::syntax::lexer::Lex,
    pub sigils_p1: crate::prelude::Text,
    pub start_p2: crate::prelude::Nat,
    pub pattern_p3: crate::prelude::Text,
    pub at_p4: crate::prelude::Nat,
    pub replacement_o5: ::std::option::Option<crate::prelude::Text>,
    pub replacement_at_p6: crate::prelude::Nat,
    pub flags_at_p7: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::syntax::lexer::Lex> for Finish {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l_p0 = &self.l_p0;
        let sigils_p1 = &self.sigils_p1;
        let start_p2 = &self.start_p2;
        let pattern_p3 = &self.pattern_p3;
        let at_p4 = &self.at_p4;
        let replacement_o5 = &self.replacement_o5;
        let replacement_at_p6 = &self.replacement_at_p6;
        let flags_at_p7 = &self.flags_at_p7;
        let src_p8 = l_p0.src_p.clone();
        let flags_end_p9 = letters_end_f(&src_p8, flags_at_p7);
        let lit_pa = crate::syntax::RegexLit { pattern_p: pattern_p3.clone(), pattern_at_p: at_p4.clone(), replacement_o: replacement_o5.clone(), replacement_at_p: replacement_at_p6.clone(), flags_p: crate::syntax::lexer::chars::between_f(&src_p8, flags_at_p7, &flags_end_p9), flags_at_p: flags_at_p7.clone() };
        let tail_pb = ident_end_f(&src_p8, &flags_end_p9);
        let l1_pc = {
            let mut this: crate::syntax::lexer::Lex = l_p0.clone();
            this.pos_p = tail_pb.clone();
            this
        };
        let l2_pd = if &tail_pb > &flags_end_p9 {
            crate::syntax::lexer::chars::lex_err_f(&l1_pc, &flags_end_p9, &tail_pb, &crate::prelude::Text::from(format!("`{}` touches the flags of a regular expression: the flags are letters, and no name character follows them", &crate::syntax::lexer::chars::between_f(&src_p8, &flags_end_p9, &tail_pb))))
        } else {
            l1_pc.clone()
        };
        ::prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok_f(&l2_pd, &crate::syntax::lexer::TokKind::KRegex(sigils_p1.clone(), lit_pa.clone()), start_p2, &flags_end_p9))
    }
}

/// `Start Finish, x`: what the function value is when passed to `@Run`.
pub fn start_finish_f(l_p0: crate::syntax::lexer::Lex, sigils_p1: crate::prelude::Text, start_p2: crate::prelude::Nat, pattern_p3: crate::prelude::Text, at_p4: crate::prelude::Nat, replacement_o5: ::std::option::Option<crate::prelude::Text>, replacement_at_p6: crate::prelude::Nat, flags_at_p7: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::lexer::Lex>> {
    ::std::rc::Rc::new(Finish { l_p0, sigils_p1, start_p2, pattern_p3, at_p4, replacement_o5, replacement_at_p6, flags_at_p7 })
}

/// ```prism
/// Unclosed: unbounded fn Lex, Text, Nat, Text, Nat, ?Text, Text, Text -> Lex
/// ```
pub fn unclosed_f(l_p0: &crate::syntax::lexer::Lex, sigils_p1: &crate::prelude::Text, start_p2: &crate::prelude::Nat, pattern_p3: &crate::prelude::Text, at_p4: &crate::prelude::Nat, replacement_o5: &::std::option::Option<crate::prelude::Text>, what_p6: &crate::prelude::Text, close_p7: &crate::prelude::Text) -> crate::syntax::lexer::Lex {
    let end_p8 = line_end_at_f(&l_p0.src_p, at_p4);
    let lit_p9 = crate::syntax::RegexLit { pattern_p: pattern_p3.clone(), pattern_at_p: at_p4.clone(), replacement_o: replacement_o5.clone(), replacement_at_p: at_p4.clone(), flags_p: crate::prelude::Text::lit(""), flags_at_p: end_p8.clone() };
    let l1_pa = {
        let mut this: crate::syntax::lexer::Lex = l_p0.clone();
        this.pos_p = end_p8.clone();
        this
    };
    let l2_pb = crate::syntax::lexer::chars::lex_err_f(&l1_pa, start_p2, &end_p8, &crate::prelude::Text::from(format!("a regular expression ends on its line: close its {} with `{}`", what_p6, close_p7)));
    crate::syntax::lexer::push_tok_f(&l2_pb, &crate::syntax::lexer::TokKind::KRegex(sigils_p1.clone(), lit_p9.clone()), start_p2, &end_p8)
}

/// The step machine of `Unclosed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Unclosed: unbounded fn Lex, Text, Nat, Text, Nat, ?Text, Text, Text -> Lex
/// ```
pub struct Unclosed {
    pub l_p0: crate::syntax::lexer::Lex,
    pub sigils_p1: crate::prelude::Text,
    pub start_p2: crate::prelude::Nat,
    pub pattern_p3: crate::prelude::Text,
    pub at_p4: crate::prelude::Nat,
    pub replacement_o5: ::std::option::Option<crate::prelude::Text>,
    pub what_p6: crate::prelude::Text,
    pub close_p7: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::syntax::lexer::Lex> for Unclosed {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l_p0 = &self.l_p0;
        let sigils_p1 = &self.sigils_p1;
        let start_p2 = &self.start_p2;
        let pattern_p3 = &self.pattern_p3;
        let at_p4 = &self.at_p4;
        let replacement_o5 = &self.replacement_o5;
        let what_p6 = &self.what_p6;
        let close_p7 = &self.close_p7;
        let end_p8 = line_end_at_f(&l_p0.src_p, at_p4);
        let lit_p9 = crate::syntax::RegexLit { pattern_p: pattern_p3.clone(), pattern_at_p: at_p4.clone(), replacement_o: replacement_o5.clone(), replacement_at_p: at_p4.clone(), flags_p: crate::prelude::Text::lit(""), flags_at_p: end_p8.clone() };
        let l1_pa = {
            let mut this: crate::syntax::lexer::Lex = l_p0.clone();
            this.pos_p = end_p8.clone();
            this
        };
        let l2_pb = crate::syntax::lexer::chars::lex_err_f(&l1_pa, start_p2, &end_p8, &crate::prelude::Text::from(format!("a regular expression ends on its line: close its {} with `{}`", what_p6, close_p7)));
        ::prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok_f(&l2_pb, &crate::syntax::lexer::TokKind::KRegex(sigils_p1.clone(), lit_p9.clone()), start_p2, &end_p8))
    }
}

/// `Start Unclosed, x`: what the function value is when passed to `@Run`.
pub fn start_unclosed_f(l_p0: crate::syntax::lexer::Lex, sigils_p1: crate::prelude::Text, start_p2: crate::prelude::Nat, pattern_p3: crate::prelude::Text, at_p4: crate::prelude::Nat, replacement_o5: ::std::option::Option<crate::prelude::Text>, what_p6: crate::prelude::Text, close_p7: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::lexer::Lex>> {
    ::std::rc::Rc::new(Unclosed { l_p0, sigils_p1, start_p2, pattern_p3, at_p4, replacement_o5, what_p6, close_p7 })
}

/// ```prism
/// ?PlainEnd: fn Text, Nat -> ?Nat
/// ```
pub fn plain_end_o(src_p0: &crate::prelude::Text, at_p1: &crate::prelude::Nat) -> ::std::option::Option<crate::prelude::Nat> {
    match crate::syntax::lexer::chars::match_end_f(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("(?:[^\\/\\\\\\n]|\\\\[^\\n])*\\/", "")); R.with(crate::prelude::Regex::clone) }, src_p0, at_p1) {
        e_p2 if (&e_p2 > at_p1) => (&e_p2).checked_sub(&crate::prelude::Nat::from(1u32)),
        _ => ::std::option::Option::None,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ?HashedEnd: unbounded fn Text, Nat, Text -> ?Nat
/// ```
pub fn hashed_end_o(src_p0: &crate::prelude::Text, at_p1: &crate::prelude::Nat, close_p2: &crate::prelude::Text) -> ::std::option::Option<crate::prelude::Nat> {
    let (found_o7, _, _) = {
        let mut this: (::std::option::Option<crate::prelude::Nat>, crate::prelude::Nat, bool) = (::std::option::Option::None, at_p1.clone(), true);
        let mut i_p3: crate::prelude::Nat = at_p1.clone();
        let mut going_p4: bool = true;
        let mut found_o5: ::std::option::Option<crate::prelude::Nat> = ::std::option::Option::None;
        while going_p4 {
            let c_p6 = crate::syntax::lexer::chars::char_at_byte_f(src_p0, &i_p3);
            if (&c_p6 == &crate::prelude::Text::lit("")) || (&c_p6 == &crate::prelude::Text::lit("\n")) {
                going_p4 = false;
            } else if (&c_p6 == &crate::prelude::Text::lit("/")) && crate::syntax::lexer::chars::has_prefix_f(&text_from_f(src_p0, &i_p3), close_p2) {
                found_o5 = ::std::option::Option::Some(i_p3.clone());
                going_p4 = false;
            } else {
                i_p3 = &i_p3 + &crate::prelude::len_text(&c_p6);
            }
        }
        this = (found_o5.clone(), i_p3.clone(), going_p4);
        this
    };
    found_o7.clone()
}

/// The step machine of `HashedEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?HashedEnd: unbounded fn Text, Nat, Text -> ?Nat
/// ```
pub struct HashedEnd {
    pub src_p0: crate::prelude::Text,
    pub at_p1: crate::prelude::Nat,
    pub close_p2: crate::prelude::Text,
}

impl ::prism_rtl::Job<::std::option::Option<crate::prelude::Nat>> for HashedEnd {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::prelude::Nat>> {
        let src_p0 = &self.src_p0;
        let at_p1 = &self.at_p1;
        let close_p2 = &self.close_p2;
        let mut this: (::std::option::Option<crate::prelude::Nat>, crate::prelude::Nat, bool) = (::std::option::Option::None, at_p1.clone(), true);
        let mut i_p3: crate::prelude::Nat = at_p1.clone();
        let mut going_p4: bool = true;
        let mut found_o5: ::std::option::Option<crate::prelude::Nat> = ::std::option::Option::None;
        crate::prelude::call_then(crate::prelude::loop_job((found_o5, this, going_p4, i_p3), {
            let close_p2x = close_p2.clone();
            let src_p0x = src_p0.clone();
            move |(mut found_o5, mut this, mut going_p4, mut i_p3): (::std::option::Option<crate::prelude::Nat>, (::std::option::Option<crate::prelude::Nat>, crate::prelude::Nat, bool), bool, crate::prelude::Nat)| if going_p4 {
                {
                    let c_p6 = crate::syntax::lexer::chars::char_at_byte_f(&src_p0x, &i_p3);
                    if (&c_p6 == &crate::prelude::Text::lit("")) || (&c_p6 == &crate::prelude::Text::lit("\n")) {
                        going_p4 = false;
                    } else if (&c_p6 == &crate::prelude::Text::lit("/")) && crate::syntax::lexer::chars::has_prefix_f(&text_from_f(&src_p0x, &i_p3), &close_p2x) {
                        found_o5 = ::std::option::Option::Some(i_p3.clone());
                        going_p4 = false;
                    } else {
                        i_p3 = &i_p3 + &crate::prelude::len_text(&c_p6);
                    }
                    ::std::result::Result::Ok((found_o5, this, going_p4, i_p3))
                }
            } else {
                ::std::result::Result::Err((found_o5, this, going_p4, i_p3))
            }
        }), move |(mut found_o5, mut this, mut going_p4, mut i_p3): (::std::option::Option<crate::prelude::Nat>, (::std::option::Option<crate::prelude::Nat>, crate::prelude::Nat, bool), bool, crate::prelude::Nat)| {
            this = (found_o5.clone(), i_p3.clone(), going_p4);
            let (found_o7, _, _) = this;
            ::prism_rtl::Turn::Finished(found_o7.clone())
        })
    }
}

/// `Start HashedEnd, x`: what the function value is when passed to `@Run`.
pub fn start_hashed_end_o(src_p0: crate::prelude::Text, at_p1: crate::prelude::Nat, close_p2: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Nat>>> {
    ::std::rc::Rc::new(HashedEnd { src_p0, at_p1, close_p2 })
}

/// ```prism
/// HashesEnd: fn Text, Nat -> Nat
/// ```
pub fn hashes_end_f(src_p0: &crate::prelude::Text, at_p1: &crate::prelude::Nat) -> crate::prelude::Nat {
    crate::syntax::lexer::chars::match_end_f(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("#*", "")); R.with(crate::prelude::Regex::clone) }, src_p0, at_p1)
}

/// ```prism
/// LettersEnd: fn Text, Nat -> Nat
/// ```
pub fn letters_end_f(src_p0: &crate::prelude::Text, at_p1: &crate::prelude::Nat) -> crate::prelude::Nat {
    crate::syntax::lexer::chars::match_end_f(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[A-Za-z]*", "")); R.with(crate::prelude::Regex::clone) }, src_p0, at_p1)
}

/// ```prism
/// IdentEnd: fn Text, Nat -> Nat
/// ```
pub fn ident_end_f(src_p0: &crate::prelude::Text, at_p1: &crate::prelude::Nat) -> crate::prelude::Nat {
    crate::syntax::lexer::chars::match_end_f(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[A-Za-z0-9_]*", "")); R.with(crate::prelude::Regex::clone) }, src_p0, at_p1)
}

/// ```prism
/// LineEndAt: fn Text, Nat -> Nat
/// ```
pub fn line_end_at_f(src_p0: &crate::prelude::Text, at_p1: &crate::prelude::Nat) -> crate::prelude::Nat {
    crate::syntax::lexer::chars::match_end_f(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[^\\n]*", "")); R.with(crate::prelude::Regex::clone) }, src_p0, at_p1)
}

/// ```prism
/// TextFrom: fn Text, Nat -> Text
/// ```
pub fn text_from_f(src_p0: &crate::prelude::Text, at_p1: &crate::prelude::Nat) -> crate::prelude::Text {
    match crate::prelude::cursor_at(src_p0, at_p1) {
        ::std::option::Option::Some(c_p2) => crate::prelude::after(&c_p2),
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    }
}
