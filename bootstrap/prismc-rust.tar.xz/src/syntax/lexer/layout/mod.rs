//! The module `Syntax.Lexer.Layout`, from `target/bootstrap/src/prismc/syntax/lexer/layout.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// LexFile: unbounded fn Text -> Lexed
/// ```
pub fn lex_file_f(src_p0: &Text) -> crate::syntax::lexer::Lexed {
    let start_p1 = crate::syntax::lexer::Lex { src_p: src_p0.clone(), pos_p: Nat::from(0u32), diags_p: Array::new(), mode_p: crate::syntax::lexer::Mode::MFile, tokens_p: Array::new(), layout_p: Array::new(), frames_p: Array::new(), last_ws_p: true, lambda_open_p: false, pending_open_p: false, pending_span_p: crate::syntax::Range { start_p: Nat::from(0u32), end_p: Nat::from(0u32) }, line_first_p: Nat::from(0u32), mark_line_start_p: false, first_line_p: true, test_pending_p: Text::lit(""), test_depth_o: None, check_depth_o: None, path_next_p: false };
    let skipped_p2 = skip_blank_and_comment_lines_f(&start_p1);
    let opened_p3 = (&crate::syntax::lexer::chars::peek_f(&skipped_p2) == &Text::lit("<")) && (&crate::syntax::lexer::templates::template_tag_ahead_f(&skipped_p2) != &Text::lit(""));
    let (head_p5, l_p6) = if opened_p3 { template_head_f(&skipped_p2) } else { (Array::new(), start_p1.clone()) };
    let body_p4 = lex_stream_f(&crate::syntax::lexer::fresh_f(&l_p6, &crate::syntax::lexer::Mode::MFile));
    crate::syntax::lexer::Lexed { tokens_p: crate::prelude::append(&head_p5, &body_p4.tokens_p), diags_p: body_p4.diags_p.clone() }
}

/// The step machine of `LexFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexFile: unbounded fn Text -> Lexed
/// ```
pub struct LexFile {
    pub src_p0: Text,
}

impl prism_rtl::Job<crate::syntax::lexer::Lexed> for LexFile {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lexed> {
        let src_p0 = &self.src_p0;
        let start_p1 = crate::syntax::lexer::Lex { src_p: src_p0.clone(), pos_p: Nat::from(0u32), diags_p: Array::new(), mode_p: crate::syntax::lexer::Mode::MFile, tokens_p: Array::new(), layout_p: Array::new(), frames_p: Array::new(), last_ws_p: true, lambda_open_p: false, pending_open_p: false, pending_span_p: crate::syntax::Range { start_p: Nat::from(0u32), end_p: Nat::from(0u32) }, line_first_p: Nat::from(0u32), mark_line_start_p: false, first_line_p: true, test_pending_p: Text::lit(""), test_depth_o: None, check_depth_o: None, path_next_p: false };
        crate::prelude::call_then(start_skip_blank_and_comment_lines_f(start_p1.clone()), move |skip_blank_and_comment_lines_f_1051: crate::syntax::lexer::Lex| {
            let skipped_p2 = skip_blank_and_comment_lines_f_1051;
            let opened_p3 = (&crate::syntax::lexer::chars::peek_f(&skipped_p2) == &Text::lit("<")) && (&crate::syntax::lexer::templates::template_tag_ahead_f(&skipped_p2) != &Text::lit(""));
            let (head_p5, l_p6) = if opened_p3 { template_head_f(&skipped_p2) } else { (Array::new(), start_p1.clone()) };
            crate::prelude::call_then(start_lex_stream_f(crate::syntax::lexer::fresh_f(&l_p6, &crate::syntax::lexer::Mode::MFile)), move |lex_stream_f_1249: crate::syntax::lexer::Lex| {
                let body_p4 = lex_stream_f_1249;
                prism_rtl::Turn::Finished(crate::syntax::lexer::Lexed { tokens_p: crate::prelude::append(&head_p5, &body_p4.tokens_p), diags_p: body_p4.diags_p.clone() })
            })
        })
    }
}

/// `Start LexFile, x`: what the function value is when passed to `@Run`.
pub fn start_lex_file_f(src_p0: Text) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lexed>> {
    Rc::new(LexFile { src_p0 })
}

/// ```prism
/// TemplateHead: unbounded fn Lex -> (([Tok], Lex))
/// ```
pub fn template_head_f(l0_p0: &crate::syntax::lexer::Lex) -> (Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex) {
    let (kind_p2, l_p3) = crate::syntax::lexer::templates::lex_template_f(l0_p0, &Text::lit("File"), &l0_p0.pos_p);
    let tok_p1 = crate::syntax::lexer::Tok { kind_p: kind_p2.clone(), span_p: crate::syntax::Range { start_p: l0_p0.pos_p.clone(), end_p: l_p3.pos_p.clone() }, touches_p: false, line_start_p: false };
    (Array::from(vec![tok_p1.clone()]), l_p3.clone())
}

/// The step machine of `TemplateHead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateHead: unbounded fn Lex -> (([Tok], Lex))
/// ```
pub struct TemplateHead {
    pub l0_p0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<(Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex)> for TemplateHead {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex)> {
        let l0_p0 = &self.l0_p0;
        let l0_p0x = l0_p0.clone();
        crate::prelude::call_then(crate::syntax::lexer::templates::start_lex_template_f(l0_p0x.clone(), Text::lit("File"), l0_p0x.pos_p.clone()), move |lex_template_f_1501: (crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)| {
            let (kind_p2, l_p3) = lex_template_f_1501;
            let tok_p1 = crate::syntax::lexer::Tok { kind_p: kind_p2.clone(), span_p: crate::syntax::Range { start_p: l0_p0x.pos_p.clone(), end_p: l_p3.pos_p.clone() }, touches_p: false, line_start_p: false };
            prism_rtl::Turn::Finished((Array::from(vec![tok_p1.clone()]), l_p3.clone()))
        })
    }
}

/// `Start TemplateHead, x`: what the function value is when passed to `@Run`.
pub fn start_template_head_f(l0_p0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex)>> {
    Rc::new(TemplateHead { l0_p0 })
}

/// ```prism
/// SkipBlankAndCommentLines: unbounded fn Lex -> Lex
/// ```
pub fn skip_blank_and_comment_lines_f(l_p0: &crate::syntax::lexer::Lex) -> crate::syntax::lexer::Lex {
    let mut this: crate::syntax::lexer::Lex = l_p0.clone();
    let mut going_p1: bool = true;
    while going_p1 {
        let line_p2 = crate::syntax::lexer::chars::rest_of_line_f(&this);
        let t_p3 = crate::syntax::lexer::chars::trim_start_f(&line_p2);
        if ((&t_p3 == &Text::lit("")) || (&crate::syntax::lexer::chars::head_f(&t_p3) == &Text::lit("#"))) && (&(&this.pos_p + &crate::prelude::len_text(&line_p2)) < &crate::prelude::len_text(&this.src_p)) {
            this.pos_p = &this.pos_p + &(&crate::prelude::len_text(&line_p2) + &Nat::from(1u32));
        } else {
            going_p1 = false;
        }
    }
    this
}

/// The step machine of `SkipBlankAndCommentLines`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SkipBlankAndCommentLines: unbounded fn Lex -> Lex
/// ```
pub struct SkipBlankAndCommentLines {
    pub l_p0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for SkipBlankAndCommentLines {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l_p0 = &self.l_p0;
        let mut this: crate::syntax::lexer::Lex = l_p0.clone();
        let mut going_p1: bool = true;
        crate::prelude::call_then(crate::prelude::loop_job((this, going_p1), move |(mut this, mut going_p1): (crate::syntax::lexer::Lex, bool)| if going_p1 {
            {
                let line_p2 = crate::syntax::lexer::chars::rest_of_line_f(&this);
                let t_p3 = crate::syntax::lexer::chars::trim_start_f(&line_p2);
                if ((&t_p3 == &Text::lit("")) || (&crate::syntax::lexer::chars::head_f(&t_p3) == &Text::lit("#"))) && (&(&this.pos_p + &crate::prelude::len_text(&line_p2)) < &crate::prelude::len_text(&this.src_p)) {
                    this.pos_p = &this.pos_p + &(&crate::prelude::len_text(&line_p2) + &Nat::from(1u32));
                } else {
                    going_p1 = false;
                }
                Ok((this, going_p1))
            }
        } else {
            Err((this, going_p1))
        }), move |(mut this, mut going_p1): (crate::syntax::lexer::Lex, bool)| prism_rtl::Turn::Finished(this))
    }
}

/// `Start SkipBlankAndCommentLines, x`: what the function value is when passed to `@Run`.
pub fn start_skip_blank_and_comment_lines_f(l_p0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(SkipBlankAndCommentLines { l_p0 })
}

/// ```prism
/// Nested: unbounded fn Lex, Mode -> (([Tok], Lex))
/// ```
pub fn nested_f(l_p0: &crate::syntax::lexer::Lex, mode_p1: &crate::syntax::lexer::Mode) -> (Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex) {
    let inner_p2 = lex_stream_f(&crate::syntax::lexer::fresh_f(l_p0, mode_p1));
    let back_p3 = {
        let mut this: crate::syntax::lexer::Lex = l_p0.clone();
        this.pos_p = inner_p2.pos_p.clone();
        this.diags_p = inner_p2.diags_p.clone();
        this
    };
    (inner_p2.tokens_p.clone(), back_p3.clone())
}

/// The step machine of `Nested`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Nested: unbounded fn Lex, Mode -> (([Tok], Lex))
/// ```
pub struct Nested {
    pub l_p0: crate::syntax::lexer::Lex,
    pub mode_p1: crate::syntax::lexer::Mode,
}

impl prism_rtl::Job<(Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex)> for Nested {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex)> {
        let l_p0 = &self.l_p0;
        let mode_p1 = &self.mode_p1;
        let l_p0x = l_p0.clone();
        let mode_p1x = mode_p1.clone();
        crate::prelude::call_then(start_lex_stream_f(crate::syntax::lexer::fresh_f(&l_p0x, &mode_p1x)), move |lex_stream_f_2224: crate::syntax::lexer::Lex| {
            let inner_p2 = lex_stream_f_2224;
            let back_p3 = {
                let mut this: crate::syntax::lexer::Lex = l_p0x.clone();
                this.pos_p = inner_p2.pos_p.clone();
                this.diags_p = inner_p2.diags_p.clone();
                this
            };
            prism_rtl::Turn::Finished((inner_p2.tokens_p.clone(), back_p3.clone()))
        })
    }
}

/// `Start Nested, x`: what the function value is when passed to `@Run`.
pub fn start_nested_f(l_p0: crate::syntax::lexer::Lex, mode_p1: crate::syntax::lexer::Mode) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex)>> {
    Rc::new(Nested { l_p0, mode_p1 })
}

/// ```prism
/// LexStream: unbounded fn Lex -> Lex
/// ```
pub fn lex_stream_f(l0_p0: &crate::syntax::lexer::Lex) -> crate::syntax::lexer::Lex {
    let mut this: crate::syntax::lexer::Lex = l0_p0.clone();
    let mut at_line_start_p1: bool = crate::syntax::lexer::layout_on_f(&this.mode_p);
    let mut done_p2: bool = false;
    while !done_p2 {
        let mut go_p3: bool = true;
        if at_line_start_p1 && crate::syntax::lexer::layout_active_f(&this) {
            at_line_start_p1 = false;
            let (l_p4, verdict_p5) = begin_line_f(&this);
            this = l_p4.clone();
            if &verdict_p5 == &Text::lit("skip") {
                at_line_start_p1 = true;
                go_p3 = false;
            }
            if &verdict_p5 == &Text::lit("end") {
                done_p2 = true;
                go_p3 = false;
            }
        }
        if go_p3 {
            let c_p6 = crate::syntax::lexer::chars::peek_f(&this);
            match &c_p6 {
                u3052_0 if (u3052_0 == &Text::lit("")) => {
                    this = unclosed_stream_f(&this);
                    done_p2 = true;
                    ()
                },
                u3052_1 if (u3052_1 == &Text::lit("\n")) => {
                    this.pos_p = &this.pos_p + &Nat::from(1u32);
                    this.last_ws_p = true;
                    if this.lambda_open_p {
                        this = crate::syntax::lexer::chars::lex_err_f(&this, &crate::syntax::lexer::chars::dec_f(&this.pos_p), &this.pos_p, &Text::lit("a lambda\'s parameter list closes with `|` on its own line"));
                        this.lambda_open_p = false;
                    }
                    if crate::syntax::lexer::layout_active_f(&this) {
                        this = end_line_f(&this);
                        at_line_start_p1 = true;
                    }
                    ()
                },
                u3052_2 if (u3052_2 == &Text::lit(" ")) => {
                    this.pos_p = &this.pos_p + &Nat::from(1u32);
                    this.last_ws_p = true;
                    ()
                },
                u3052_3 if (u3052_3 == &Text::lit("\r")) => {
                    this.pos_p = &this.pos_p + &Nat::from(1u32);
                    this.last_ws_p = true;
                    ()
                },
                u3052_4 if (u3052_4 == &Text::lit("\t")) => {
                    this.pos_p = &this.pos_p + &Nat::from(1u32);
                    this.last_ws_p = true;
                    ()
                },
                u3052_5 if (u3052_5 == &Text::lit("#")) => {
                    this.pos_p = crate::syntax::lexer::chars::line_end_f(&this);
                    this.last_ws_p = true;
                    ()
                },
                _ => {
                    let (ends_p7, l_p8) = stream_ends_here_f(&this);
                    this = l_p8.clone();
                    if ends_p7 {
                        done_p2 = true;
                    } else {
                        this = crate::syntax::lexer::words::lex_token_f(&this);
                    }
                    ()
                },
                _ => unreachable!("no arm matched"),
            };
        }
    }
    if crate::syntax::lexer::layout_on_f(&this.mode_p) {
        while &crate::prelude::len(&this.layout_p) > &Nat::from(1u32) {
            this.layout_p = crate::syntax::lexer::chars::pop_f(&this.layout_p);
            this = crate::syntax::lexer::push_tok_f(&this, &crate::syntax::lexer::TokKind::KLayClose, &this.pos_p, &this.pos_p);
        }
    }
    if &this.mode_p == &crate::syntax::lexer::Mode::MFile {
        this = crate::syntax::lexer::push_tok_f(&this, &crate::syntax::lexer::TokKind::KEof, &this.pos_p, &this.pos_p);
    }
    this
}

/// The step machine of `LexStream`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexStream: unbounded fn Lex -> Lex
/// ```
pub struct LexStream {
    pub l0_p0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for LexStream {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l0_p0 = &self.l0_p0;
        let mut this: crate::syntax::lexer::Lex = l0_p0.clone();
        let mut at_line_start_p1: bool = crate::syntax::lexer::layout_on_f(&this.mode_p);
        let mut done_p2: bool = false;
        crate::prelude::call_then(crate::prelude::loop_job((this, at_line_start_p1, done_p2), move |(mut this, mut at_line_start_p1, mut done_p2): (crate::syntax::lexer::Lex, bool, bool)| if !done_p2 {
            {
                let mut go_p3: bool = true;
                if at_line_start_p1 && crate::syntax::lexer::layout_active_f(&this) {
                    at_line_start_p1 = false;
                    let (l_p4, verdict_p5) = begin_line_f(&this);
                    this = l_p4.clone();
                    if &verdict_p5 == &Text::lit("skip") {
                        at_line_start_p1 = true;
                        go_p3 = false;
                    }
                    if &verdict_p5 == &Text::lit("end") {
                        done_p2 = true;
                        go_p3 = false;
                    }
                }
                if go_p3 {
                    let c_p6 = crate::syntax::lexer::chars::peek_f(&this);
                    match &c_p6 {
                        u3052_0 if (u3052_0 == &Text::lit("")) => {
                            this = unclosed_stream_f(&this);
                            done_p2 = true;
                            ()
                        },
                        u3052_1 if (u3052_1 == &Text::lit("\n")) => {
                            this.pos_p = &this.pos_p + &Nat::from(1u32);
                            this.last_ws_p = true;
                            if this.lambda_open_p {
                                this = crate::syntax::lexer::chars::lex_err_f(&this, &crate::syntax::lexer::chars::dec_f(&this.pos_p), &this.pos_p, &Text::lit("a lambda\'s parameter list closes with `|` on its own line"));
                                this.lambda_open_p = false;
                            }
                            if crate::syntax::lexer::layout_active_f(&this) {
                                this = end_line_f(&this);
                                at_line_start_p1 = true;
                            }
                            ()
                        },
                        u3052_2 if (u3052_2 == &Text::lit(" ")) => {
                            this.pos_p = &this.pos_p + &Nat::from(1u32);
                            this.last_ws_p = true;
                            ()
                        },
                        u3052_3 if (u3052_3 == &Text::lit("\r")) => {
                            this.pos_p = &this.pos_p + &Nat::from(1u32);
                            this.last_ws_p = true;
                            ()
                        },
                        u3052_4 if (u3052_4 == &Text::lit("\t")) => {
                            this.pos_p = &this.pos_p + &Nat::from(1u32);
                            this.last_ws_p = true;
                            ()
                        },
                        u3052_5 if (u3052_5 == &Text::lit("#")) => {
                            this.pos_p = crate::syntax::lexer::chars::line_end_f(&this);
                            this.last_ws_p = true;
                            ()
                        },
                        _ => {
                            let (ends_p7, l_p8) = stream_ends_here_f(&this);
                            this = l_p8.clone();
                            if ends_p7 {
                                done_p2 = true;
                            } else {
                                this = crate::syntax::lexer::words::lex_token_f(&this);
                            }
                            ()
                        },
                        _ => unreachable!("no arm matched"),
                    };
                }
                Ok((this, at_line_start_p1, done_p2))
            }
        } else {
            Err((this, at_line_start_p1, done_p2))
        }), move |(mut this, mut at_line_start_p1, mut done_p2): (crate::syntax::lexer::Lex, bool, bool)| {
            let k_if4442 = move |(mut this, mut at_line_start_p1, mut done_p2): (crate::syntax::lexer::Lex, bool, bool)| {
                if &this.mode_p == &crate::syntax::lexer::Mode::MFile {
                    this = crate::syntax::lexer::push_tok_f(&this, &crate::syntax::lexer::TokKind::KEof, &this.pos_p, &this.pos_p);
                }
                prism_rtl::Turn::Finished(this)
            };
            if crate::syntax::lexer::layout_on_f(&this.mode_p) {
                crate::prelude::call_then(crate::prelude::loop_job((this, at_line_start_p1, done_p2), move |(mut this, mut at_line_start_p1, mut done_p2): (crate::syntax::lexer::Lex, bool, bool)| if &crate::prelude::len(&this.layout_p) > &Nat::from(1u32) {
                    {
                        this.layout_p = crate::syntax::lexer::chars::pop_f(&this.layout_p);
                        this = crate::syntax::lexer::push_tok_f(&this, &crate::syntax::lexer::TokKind::KLayClose, &this.pos_p, &this.pos_p);
                        Ok((this, at_line_start_p1, done_p2))
                    }
                } else {
                    Err((this, at_line_start_p1, done_p2))
                }), move |(mut this, mut at_line_start_p1, mut done_p2): (crate::syntax::lexer::Lex, bool, bool)| k_if4442((this, at_line_start_p1, done_p2)))
            } else {
                k_if4442((this, at_line_start_p1, done_p2))
            }
        })
    }
}

/// `Start LexStream, x`: what the function value is when passed to `@Run`.
pub fn start_lex_stream_f(l0_p0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(LexStream { l0_p0 })
}

/// ```prism
/// UnclosedStream: fn Lex -> Lex
/// ```
pub fn unclosed_stream_f(l_p0: &crate::syntax::lexer::Lex) -> crate::syntax::lexer::Lex {
    match &l_p0.mode_p {
        crate::syntax::lexer::Mode::MFile => l_p0.clone(),
        crate::syntax::lexer::Mode::MBrace(_) => crate::syntax::lexer::chars::lex_err_f(l_p0, &l_p0.pos_p, &l_p0.pos_p, &Text::lit("a brace block never closes: expected its closing delimiter alone on a line")),
        crate::syntax::lexer::Mode::MPlaceholder(m4718_2_0) if (m4718_2_0 == &Text::lit("single")) => crate::syntax::lexer::chars::lex_err_f(l_p0, &l_p0.pos_p, &l_p0.pos_p, &Text::lit("a placeholder never closes: expected `}`")),
        crate::syntax::lexer::Mode::MPlaceholder(_) => crate::syntax::lexer::chars::lex_err_f(l_p0, &l_p0.pos_p, &l_p0.pos_p, &Text::lit("a placeholder never closes: expected `}}`")),
        crate::syntax::lexer::Mode::MPathKey => crate::syntax::lexer::chars::lex_err_f(l_p0, &l_p0.pos_p, &l_p0.pos_p, &Text::lit("a path key never closes: expected `]`")),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// StreamEndsHere: fn Lex -> ((Bool, Lex))
/// ```
pub fn stream_ends_here_f(l_p0: &crate::syntax::lexer::Lex) -> (bool, crate::syntax::lexer::Lex) {
    let c_p1 = crate::syntax::lexer::chars::peek_f(l_p0);
    let closes_p2 = match &l_p0.mode_p {
        crate::syntax::lexer::Mode::MPlaceholder(m5318_0_0) if (m5318_0_0 == &Text::lit("single")) => &c_p1 == &Text::lit("}"),
        crate::syntax::lexer::Mode::MPlaceholder(m5318_1_0) if (m5318_1_0 == &Text::lit("double")) => crate::syntax::lexer::chars::starts_with_f(l_p0, &Text::lit("}}")),
        crate::syntax::lexer::Mode::MPathKey => &c_p1 == &Text::lit("]"),
        _ => false,
        _ => unreachable!("no arm matched"),
    };
    let width_p3 = if &l_p0.mode_p == &crate::syntax::lexer::Mode::MPlaceholder(Text::lit("double")) {
        Nat::from(2u32)
    } else {
        Nat::from(1u32)
    };
    if (&crate::prelude::len(&l_p0.frames_p) == &Nat::from(0u32)) && closes_p2 {
        (true, crate::syntax::lexer::chars::forward_f(l_p0, &width_p3))
    } else {
        (false, l_p0.clone())
    }
}

/// ```prism
/// EndLine: fn Lex -> Lex
/// ```
pub fn end_line_f(l_p0: &crate::syntax::lexer::Lex) -> crate::syntax::lexer::Lex {
    match crate::syntax::lexer::chars::last_o(&l_p0.tokens_p) {
        Some(t_p1) if ((&crate::prelude::len(&l_p0.tokens_p) > &l_p0.line_first_p) && opens_block_f(&t_p1.kind_p)) => {
            let mut this: crate::syntax::lexer::Lex = l_p0.clone();
            this.pending_open_p = true;
            this.pending_span_p = t_p1.span_p.clone();
            this
        },
        _ => l_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// OpensBlock: fn TokKind -> Bool
/// ```
pub fn opens_block_f(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KColon => true,
        crate::syntax::lexer::TokKind::KLambdaBar(false) => true,
        _ => false,
    }
}

/// ```prism
/// BeginLine: unbounded fn Lex -> ((Lex, Text))
/// ```
pub fn begin_line_f(l0_p0: &crate::syntax::lexer::Lex) -> (crate::syntax::lexer::Lex, Text) {
    let line_begin_p1 = l0_p0.pos_p.clone();
    let (l1_p2, col_p3) = indentation_f(l0_p0);
    match crate::syntax::lexer::chars::peek_f(&l1_p2) {
        m6669_0 if (&m6669_0 == &Text::lit("")) => (l1_p2.clone(), Text::lit("end")),
        m6669_1 if (&m6669_1 == &Text::lit("\n")) => (crate::syntax::lexer::chars::bump_f(&l1_p2), Text::lit("skip")),
        m6669_2 if (&m6669_2 == &Text::lit("#")) => {
            let l2_p4 = {
                let mut this: crate::syntax::lexer::Lex = l1_p2.clone();
                this.pos_p = crate::syntax::lexer::chars::line_end_f(&this);
                this
            };
            if &crate::syntax::lexer::chars::peek_f(&l2_p4) == &Text::lit("\n") {
                (crate::syntax::lexer::chars::bump_f(&l2_p4), Text::lit("skip"))
            } else {
                (l2_p4.clone(), Text::lit("end"))
            }
        },
        _ => if closes_brace_block_f(&l1_p2) {
            (skip_line_f(&l1_p2), Text::lit("end"))
        } else {
            {
                let l2_p5 = indented_line_f(&l1_p2, &col_p3, &line_begin_p1);
                (l2_p5.clone(), Text::lit("tokens"))
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `BeginLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BeginLine: unbounded fn Lex -> ((Lex, Text))
/// ```
pub struct BeginLine {
    pub l0_p0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<(crate::syntax::lexer::Lex, Text)> for BeginLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::lexer::Lex, Text)> {
        let l0_p0 = &self.l0_p0;
        let line_begin_p1 = l0_p0.pos_p.clone();
        let l0_p0x = l0_p0.clone();
        crate::prelude::call_then(start_indentation_f(l0_p0x.clone()), move |indentation_f_6650: (crate::syntax::lexer::Lex, Nat)| {
            let (l1_p2, col_p3) = indentation_f_6650;
            match crate::syntax::lexer::chars::peek_f(&l1_p2) {
                m6669_0 if (&m6669_0 == &Text::lit("")) => prism_rtl::Turn::Finished((l1_p2.clone(), Text::lit("end"))),
                m6669_1 if (&m6669_1 == &Text::lit("\n")) => prism_rtl::Turn::Finished((crate::syntax::lexer::chars::bump_f(&l1_p2), Text::lit("skip"))),
                m6669_2 if (&m6669_2 == &Text::lit("#")) => {
                    let l2_p4 = {
                        let mut this: crate::syntax::lexer::Lex = l1_p2.clone();
                        this.pos_p = crate::syntax::lexer::chars::line_end_f(&this);
                        this
                    };
                    if &crate::syntax::lexer::chars::peek_f(&l2_p4) == &Text::lit("\n") {
                        prism_rtl::Turn::Finished((crate::syntax::lexer::chars::bump_f(&l2_p4), Text::lit("skip")))
                    } else {
                        prism_rtl::Turn::Finished((l2_p4.clone(), Text::lit("end")))
                    }
                },
                _ => crate::prelude::call_then(start_closes_brace_block_f(l1_p2.clone()), move |closes_brace_block_f_7024: bool| if closes_brace_block_f_7024 {
                    crate::prelude::call_then(start_skip_line_f(l1_p2.clone()), move |skip_line_f_7047: crate::syntax::lexer::Lex| prism_rtl::Turn::Finished((skip_line_f_7047, Text::lit("end"))))
                } else {
                    crate::prelude::call_then(start_indented_line_f(l1_p2.clone(), col_p3.clone(), line_begin_p1.clone()), move |indented_line_f_7111: crate::syntax::lexer::Lex| {
                        let l2_p5 = indented_line_f_7111;
                        prism_rtl::Turn::Finished((l2_p5.clone(), Text::lit("tokens")))
                    })
                }),
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start BeginLine, x`: what the function value is when passed to `@Run`.
pub fn start_begin_line_f(l0_p0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<(crate::syntax::lexer::Lex, Text)>> {
    Rc::new(BeginLine { l0_p0 })
}

/// ```prism
/// Indentation: unbounded fn Lex -> ((Lex, Nat))
/// ```
pub fn indentation_f(l0_p0: &crate::syntax::lexer::Lex) -> (crate::syntax::lexer::Lex, Nat) {
    let mut this: (crate::syntax::lexer::Lex, Nat) = (l0_p0.clone(), Nat::from(0u32));
    let mut l_p1: crate::syntax::lexer::Lex = l0_p0.clone();
    let mut col_p2: Nat = Nat::from(0u32);
    let mut going_p3: bool = true;
    while going_p3 {
        match &crate::syntax::lexer::chars::peek_f(&l_p1) {
            u7432_0 if (u7432_0 == &Text::lit(" ")) => {
                l_p1 = crate::syntax::lexer::chars::bump_f(&l_p1);
                col_p2 = &col_p2 + &Nat::from(1u32);
                ()
            },
            u7432_1 if (u7432_1 == &Text::lit("\t")) => {
                l_p1 = crate::syntax::lexer::chars::lex_err_f(&crate::syntax::lexer::chars::bump_f(&l_p1), &l_p1.pos_p, &(&l_p1.pos_p + &Nat::from(1u32)), &Text::lit("a tab in leading whitespace is an error: indent with spaces"));
                col_p2 = &col_p2 + &Nat::from(1u32);
                ()
            },
            u7432_2 if (u7432_2 == &Text::lit("\r")) => {
                l_p1 = crate::syntax::lexer::chars::bump_f(&l_p1);
                ()
            },
            _ => {
                going_p3 = false;
                ()
            },
            _ => unreachable!("no arm matched"),
        };
    }
    this = (l_p1.clone(), col_p2.clone());
    this
}

/// The step machine of `Indentation`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Indentation: unbounded fn Lex -> ((Lex, Nat))
/// ```
pub struct Indentation {
    pub l0_p0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<(crate::syntax::lexer::Lex, Nat)> for Indentation {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::lexer::Lex, Nat)> {
        let l0_p0 = &self.l0_p0;
        let mut this: (crate::syntax::lexer::Lex, Nat) = (l0_p0.clone(), Nat::from(0u32));
        let mut l_p1: crate::syntax::lexer::Lex = l0_p0.clone();
        let mut col_p2: Nat = Nat::from(0u32);
        let mut going_p3: bool = true;
        crate::prelude::call_then(crate::prelude::loop_job((this, col_p2, going_p3, l_p1), move |(mut this, mut col_p2, mut going_p3, mut l_p1): ((crate::syntax::lexer::Lex, Nat), Nat, bool, crate::syntax::lexer::Lex)| if going_p3 {
            {
                match &crate::syntax::lexer::chars::peek_f(&l_p1) {
                    u7432_0 if (u7432_0 == &Text::lit(" ")) => {
                        l_p1 = crate::syntax::lexer::chars::bump_f(&l_p1);
                        col_p2 = &col_p2 + &Nat::from(1u32);
                        ()
                    },
                    u7432_1 if (u7432_1 == &Text::lit("\t")) => {
                        l_p1 = crate::syntax::lexer::chars::lex_err_f(&crate::syntax::lexer::chars::bump_f(&l_p1), &l_p1.pos_p, &(&l_p1.pos_p + &Nat::from(1u32)), &Text::lit("a tab in leading whitespace is an error: indent with spaces"));
                        col_p2 = &col_p2 + &Nat::from(1u32);
                        ()
                    },
                    u7432_2 if (u7432_2 == &Text::lit("\r")) => {
                        l_p1 = crate::syntax::lexer::chars::bump_f(&l_p1);
                        ()
                    },
                    _ => {
                        going_p3 = false;
                        ()
                    },
                    _ => unreachable!("no arm matched"),
                };
                Ok((this, col_p2, going_p3, l_p1))
            }
        } else {
            Err((this, col_p2, going_p3, l_p1))
        }), move |(mut this, mut col_p2, mut going_p3, mut l_p1): ((crate::syntax::lexer::Lex, Nat), Nat, bool, crate::syntax::lexer::Lex)| {
            this = (l_p1.clone(), col_p2.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start Indentation, x`: what the function value is when passed to `@Run`.
pub fn start_indentation_f(l0_p0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<(crate::syntax::lexer::Lex, Nat)>> {
    Rc::new(Indentation { l0_p0 })
}

/// ```prism
/// ClosesBraceBlock: unbounded fn Lex -> Bool
/// ```
pub fn closes_brace_block_f(l_p0: &crate::syntax::lexer::Lex) -> bool {
    match &l_p0.mode_p {
        crate::syntax::lexer::Mode::MBrace(m7910_0_0) if (m7910_0_0 == &Text::lit("double")) => &crate::syntax::lexer::chars::trim_end_f(&crate::syntax::lexer::chars::rest_of_line_f(l_p0)) == &Text::lit("}}"),
        crate::syntax::lexer::Mode::MBrace(_) => &crate::syntax::lexer::chars::trim_end_f(&crate::syntax::lexer::chars::rest_of_line_f(l_p0)) == &Text::lit("}"),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ClosesBraceBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosesBraceBlock: unbounded fn Lex -> Bool
/// ```
pub struct ClosesBraceBlock {
    pub l_p0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<bool> for ClosesBraceBlock {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let l_p0 = &self.l_p0;
        match &l_p0.mode_p {
            crate::syntax::lexer::Mode::MBrace(m7910_0_0) if (m7910_0_0 == &Text::lit("double")) => {
                let l_p0x = l_p0.clone();
                crate::prelude::call_then(crate::syntax::lexer::chars::start_rest_of_line_f(l_p0x.clone()), move |rest_of_line_f_7955: Text| prism_rtl::Turn::Finished(&crate::syntax::lexer::chars::trim_end_f(&rest_of_line_f_7955) == &Text::lit("}}")))
            },
            crate::syntax::lexer::Mode::MBrace(_) => {
                let l_p0x = l_p0.clone();
                crate::prelude::call_then(crate::syntax::lexer::chars::start_rest_of_line_f(l_p0x.clone()), move |rest_of_line_f_8009: Text| prism_rtl::Turn::Finished(&crate::syntax::lexer::chars::trim_end_f(&rest_of_line_f_8009) == &Text::lit("}")))
            },
            _ => prism_rtl::Turn::Finished(false),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ClosesBraceBlock, x`: what the function value is when passed to `@Run`.
pub fn start_closes_brace_block_f(l_p0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(ClosesBraceBlock { l_p0 })
}

/// ```prism
/// SkipLine: unbounded fn Lex -> Lex
/// ```
pub fn skip_line_f(l0_p0: &crate::syntax::lexer::Lex) -> crate::syntax::lexer::Lex {
    let l_p1 = {
        let mut this: crate::syntax::lexer::Lex = l0_p0.clone();
        this.pos_p = crate::syntax::lexer::chars::line_end_f(&this);
        this
    };
    if &crate::syntax::lexer::chars::peek_f(&l_p1) == &Text::lit("\n") {
        crate::syntax::lexer::chars::bump_f(&l_p1)
    } else {
        l_p1.clone()
    }
}

/// The step machine of `SkipLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SkipLine: unbounded fn Lex -> Lex
/// ```
pub struct SkipLine {
    pub l0_p0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for SkipLine {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l0_p0 = &self.l0_p0;
        let l_p1 = {
            let mut this: crate::syntax::lexer::Lex = l0_p0.clone();
            this.pos_p = crate::syntax::lexer::chars::line_end_f(&this);
            this
        };
        if &crate::syntax::lexer::chars::peek_f(&l_p1) == &Text::lit("\n") {
            prism_rtl::Turn::Finished(crate::syntax::lexer::chars::bump_f(&l_p1))
        } else {
            prism_rtl::Turn::Finished(l_p1.clone())
        }
    }
}

/// `Start SkipLine, x`: what the function value is when passed to `@Run`.
pub fn start_skip_line_f(l0_p0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(SkipLine { l0_p0 })
}

/// ```prism
/// IndentedLine: unbounded fn Lex, Nat, Nat -> Lex
/// ```
pub fn indented_line_f(l0_p0: &crate::syntax::lexer::Lex, col_p1: &Nat, line_begin_p2: &Nat) -> crate::syntax::lexer::Lex {
    let here_p3 = l0_p0.pos_p.clone();
    let l_p4 = {
        let mut this: crate::syntax::lexer::Lex = l0_p0.clone();
        this.line_first_p = crate::prelude::len(&this.tokens_p);
        this.last_ws_p = true;
        this
    };
    if l_p4.first_line_p {
        first_line_f(&l_p4, col_p1, line_begin_p2, &here_p3)
    } else {
        layout_line_f(&l_p4, col_p1, line_begin_p2, &here_p3)
    }
}

/// The step machine of `IndentedLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IndentedLine: unbounded fn Lex, Nat, Nat -> Lex
/// ```
pub struct IndentedLine {
    pub l0_p0: crate::syntax::lexer::Lex,
    pub col_p1: Nat,
    pub line_begin_p2: Nat,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for IndentedLine {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l0_p0 = &self.l0_p0;
        let col_p1 = &self.col_p1;
        let line_begin_p2 = &self.line_begin_p2;
        let here_p3 = l0_p0.pos_p.clone();
        let l_p4 = {
            let mut this: crate::syntax::lexer::Lex = l0_p0.clone();
            this.line_first_p = crate::prelude::len(&this.tokens_p);
            this.last_ws_p = true;
            this
        };
        if l_p4.first_line_p {
            prism_rtl::Turn::Finished(first_line_f(&l_p4, col_p1, line_begin_p2, &here_p3))
        } else {
            prism_rtl::Turn::Finished(layout_line_f(&l_p4, col_p1, line_begin_p2, &here_p3))
        }
    }
}

/// `Start IndentedLine, x`: what the function value is when passed to `@Run`.
pub fn start_indented_line_f(l0_p0: crate::syntax::lexer::Lex, col_p1: Nat, line_begin_p2: Nat) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(IndentedLine { l0_p0, col_p1, line_begin_p2 })
}

/// ```prism
/// FirstLine: fn Lex, Nat, Nat, Nat -> Lex
/// ```
pub fn first_line_f(l0_p0: &crate::syntax::lexer::Lex, col_p1: &Nat, line_begin_p2: &Nat, here_p3: &Nat) -> crate::syntax::lexer::Lex {
    let mut this: crate::syntax::lexer::Lex = l0_p0.clone();
    this.first_line_p = false;
    if &this.mode_p == &crate::syntax::lexer::Mode::MFile {
        this.layout_p = Array::from(vec![Nat::from(0u32)]);
        if col_p1 != &Nat::from(0u32) {
            this = crate::syntax::lexer::chars::lex_err_f(&this, line_begin_p2, here_p3, &Text::lit("the first line of a file starts at column 0"));
            this.layout_p = Array::from(vec![col_p1.clone()]);
        }
    } else {
        this.layout_p = crate::prelude::push(&this.layout_p, col_p1);
    }
    this
}

/// ```prism
/// Below: fn ?Nat, Nat -> Bool
/// ```
pub fn below_f(opt0: &Option<Nat>, n1: &Nat) -> bool {
    match (opt0, n1) {
        (None, _) => false,
        (Some(d_p0), depth_p1) => depth_p1 < d_p0,
    }
}

/// ```prism
/// LayoutLine: fn Lex, Nat, Nat, Nat -> Lex
/// ```
pub fn layout_line_f(l0_p0: &crate::syntax::lexer::Lex, col_p1: &Nat, line_begin_p2: &Nat, here_p3: &Nat) -> crate::syntax::lexer::Lex {
    let mut this: crate::syntax::lexer::Lex = l0_p0.clone();
    let top_p4 = crate::prelude::or(&crate::syntax::lexer::chars::last_o(&this.layout_p), &Nat::from(0u32));
    let fat_p5 = crate::syntax::lexer::chars::starts_with_f(&this, &Text::lit("=>"));
    let mut opened_p6: bool = false;
    let mut fuel_p7: Nat = crate::prelude::len(&this.layout_p);
    if this.pending_open_p {
        this.pending_open_p = false;
        if col_p1 > &top_p4 {
            this.layout_p = crate::prelude::push(&this.layout_p, col_p1);
            this = crate::syntax::lexer::push_tok_f(&this, &crate::syntax::lexer::TokKind::KLayOpen, here_p3, here_p3);
            if &this.test_pending_p == &Text::lit("test") {
                this.test_depth_o = Some(crate::prelude::len(&this.layout_p));
            }
            if &this.test_pending_p == &Text::lit("check") {
                this.check_depth_o = Some(crate::prelude::len(&this.layout_p));
            }
            this.test_pending_p = Text::lit("");
            opened_p6 = true;
        } else {
            this.diags_p = crate::prelude::push(&this.diags_p, &crate::syntax::lexer::chars::lex_diag_f(&this.pending_span_p, &Text::lit("expected an indented block after `:`")));
        }
    }
    if !opened_p6 {
        if ((col_p1 > &top_p4) && fat_p5) && (&this.test_depth_o == &Some(crate::prelude::len(&this.layout_p))) {
            this.layout_p = crate::prelude::push(&this.layout_p, col_p1);
            this = crate::syntax::lexer::push_tok_f(&this, &crate::syntax::lexer::TokKind::KLayOpen, here_p3, here_p3);
        } else if col_p1 == &top_p4 {
            this = crate::syntax::lexer::push_tok_f(&this, &crate::syntax::lexer::TokKind::KLaySep, here_p3, here_p3);
            if &crate::prelude::len(&this.layout_p) == &Nat::from(1u32) {
                this.test_pending_p = Text::lit("");
            }
        } else if col_p1 > &top_p4 {
            this.mark_line_start_p = true;
        } else {
            while let Some(left_p8) = (&fuel_p7).checked_sub(&Nat::from(1u32)) {
                if !((&crate::prelude::len(&this.layout_p) > &Nat::from(1u32)) && (col_p1 < &crate::prelude::or(&crate::syntax::lexer::chars::last_o(&this.layout_p), &Nat::from(0u32)))) {
                    break;
                }
                fuel_p7 = left_p8.clone();
                this.layout_p = crate::syntax::lexer::chars::pop_f(&this.layout_p);
                this = crate::syntax::lexer::push_tok_f(&this, &crate::syntax::lexer::TokKind::KLayClose, here_p3, here_p3);
                let depth_p9 = crate::prelude::len(&this.layout_p);
                if below_f(&this.test_depth_o, &depth_p9) {
                    this.test_depth_o = None;
                }
                if below_f(&this.check_depth_o, &depth_p9) {
                    this.check_depth_o = None;
                }
            }
            if col_p1 != &crate::prelude::or(&crate::syntax::lexer::chars::last_o(&this.layout_p), &Nat::from(0u32)) {
                this = crate::syntax::lexer::chars::lex_err_f(&this, line_begin_p2, here_p3, &Text::lit("unindent does not match any open block"));
            }
            this = crate::syntax::lexer::push_tok_f(&this, &crate::syntax::lexer::TokKind::KLaySep, here_p3, here_p3);
            if &crate::prelude::len(&this.layout_p) == &Nat::from(1u32) {
                this.test_pending_p = Text::lit("");
            }
        }
    }
    this
}
