//! The module `Syntax.Lexer.Layout`, from `target/bootstrap/src/prismc/syntax/lexer/layout.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// LexFile: unbounded fn Text -> Lexed
/// ```
pub fn lex_file(src: &Text) -> crate::syntax::lexer::Lexed {
    let start = crate::syntax::lexer::Lex { src: src.clone(), pos: Nat::from(0u32), diags: Array::new(), mode: crate::syntax::lexer::Mode::MFile, tokens: Array::new(), layout: Array::new(), frames: Array::new(), last_ws: true, lambda_open: false, pending_open: false, pending_span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) }, line_first: Nat::from(0u32), mark_line_start: false, first_line: true, test_pending: Text::lit(""), test_depth: None, check_depth: None, path_next: false };
    let skipped = skip_blank_and_comment_lines(&start);
    let opened = (&crate::syntax::lexer::chars::peek(&skipped) == &Text::lit("<")) && (&crate::syntax::lexer::templates::template_tag_ahead(&skipped) != &Text::lit(""));
    let (head, l) = if opened { template_head(&skipped) } else { (Array::new(), start.clone()) };
    let body = lex_stream(&crate::syntax::lexer::fresh(&l, &crate::syntax::lexer::Mode::MFile));
    crate::syntax::lexer::Lexed { tokens: append(&head, &body.tokens), diags: body.diags.clone() }
}

/// The step machine of `LexFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexFile: unbounded fn Text -> Lexed
/// ```
pub struct LexFile {
    pub src: Text,
}

impl prism_rtl::Job<crate::syntax::lexer::Lexed> for LexFile {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lexed> {
        let src = &self.src;
        let start = crate::syntax::lexer::Lex { src: src.clone(), pos: Nat::from(0u32), diags: Array::new(), mode: crate::syntax::lexer::Mode::MFile, tokens: Array::new(), layout: Array::new(), frames: Array::new(), last_ws: true, lambda_open: false, pending_open: false, pending_span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) }, line_first: Nat::from(0u32), mark_line_start: false, first_line: true, test_pending: Text::lit(""), test_depth: None, check_depth: None, path_next: false };
        call_then(start_skip_blank_and_comment_lines(start.clone()), move |skip_blank_and_comment_lines_1051: crate::syntax::lexer::Lex| {
            let skipped = skip_blank_and_comment_lines_1051;
            let opened = (&crate::syntax::lexer::chars::peek(&skipped) == &Text::lit("<")) && (&crate::syntax::lexer::templates::template_tag_ahead(&skipped) != &Text::lit(""));
            let (head, l) = if opened { template_head(&skipped) } else { (Array::new(), start.clone()) };
            call_then(start_lex_stream(crate::syntax::lexer::fresh(&l, &crate::syntax::lexer::Mode::MFile)), move |lex_stream_1249: crate::syntax::lexer::Lex| {
                let body = lex_stream_1249;
                prism_rtl::Turn::Finished(crate::syntax::lexer::Lexed { tokens: append(&head, &body.tokens), diags: body.diags.clone() })
            })
        })
    }
}

/// `Start LexFile, x`: what the function value is when passed to `@Run`.
pub fn start_lex_file(src: Text) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lexed>> {
    Rc::new(LexFile { src })
}

/// ```prism
/// TemplateHead: unbounded fn Lex -> (([Tok], Lex))
/// ```
pub fn template_head(l0: &crate::syntax::lexer::Lex) -> (Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex) {
    let (kind, l) = crate::syntax::lexer::templates::lex_template(l0, &Text::lit("File"), &l0.pos);
    let tok = crate::syntax::lexer::Tok { kind: kind.clone(), span: crate::syntax::Range { start: l0.pos.clone(), end: l.pos.clone() }, touches: false, line_start: false };
    (Array::from(vec![tok.clone()]), l.clone())
}

/// The step machine of `TemplateHead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateHead: unbounded fn Lex -> (([Tok], Lex))
/// ```
pub struct TemplateHead {
    pub l0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<(Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex)> for TemplateHead {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex)> {
        let l0 = &self.l0;
        let l0 = l0.clone();
        call_then(crate::syntax::lexer::templates::start_lex_template(l0.clone(), Text::lit("File"), l0.pos.clone()), move |lex_template_1501: (crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)| {
            let (kind, l) = lex_template_1501;
            let tok = crate::syntax::lexer::Tok { kind: kind.clone(), span: crate::syntax::Range { start: l0.pos.clone(), end: l.pos.clone() }, touches: false, line_start: false };
            prism_rtl::Turn::Finished((Array::from(vec![tok.clone()]), l.clone()))
        })
    }
}

/// `Start TemplateHead, x`: what the function value is when passed to `@Run`.
pub fn start_template_head(l0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex)>> {
    Rc::new(TemplateHead { l0 })
}

/// ```prism
/// SkipBlankAndCommentLines: unbounded fn Lex -> Lex
/// ```
pub fn skip_blank_and_comment_lines(l: &crate::syntax::lexer::Lex) -> crate::syntax::lexer::Lex {
    let mut this: crate::syntax::lexer::Lex = l.clone();
    let mut going: bool = true;
    while going {
        let line = crate::syntax::lexer::chars::rest_of_line(&this);
        let t = crate::syntax::lexer::chars::trim_start(&line);
        if ((&t == &Text::lit("")) || (&crate::syntax::lexer::chars::head(&t) == &Text::lit("#"))) && (&(&this.pos + &len_text(&line)) < &len_text(&this.src)) {
            this.pos = &this.pos + &(&len_text(&line) + &Nat::from(1u32));
        } else {
            going = false;
        }
    }
    this
}

/// The step machine of `SkipBlankAndCommentLines`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SkipBlankAndCommentLines: unbounded fn Lex -> Lex
/// ```
pub struct SkipBlankAndCommentLines {
    pub l: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for SkipBlankAndCommentLines {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l = &self.l;
        let mut this: crate::syntax::lexer::Lex = l.clone();
        let mut going: bool = true;
        call_then(loop_job((this, going), move |(mut this, mut going): (crate::syntax::lexer::Lex, bool)| if going {
            {
                let line = crate::syntax::lexer::chars::rest_of_line(&this);
                let t = crate::syntax::lexer::chars::trim_start(&line);
                if ((&t == &Text::lit("")) || (&crate::syntax::lexer::chars::head(&t) == &Text::lit("#"))) && (&(&this.pos + &len_text(&line)) < &len_text(&this.src)) {
                    this.pos = &this.pos + &(&len_text(&line) + &Nat::from(1u32));
                } else {
                    going = false;
                }
                Ok((this, going))
            }
        } else {
            Err((this, going))
        }), move |(mut this, mut going): (crate::syntax::lexer::Lex, bool)| prism_rtl::Turn::Finished(this))
    }
}

/// `Start SkipBlankAndCommentLines, x`: what the function value is when passed to `@Run`.
pub fn start_skip_blank_and_comment_lines(l: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(SkipBlankAndCommentLines { l })
}

/// ```prism
/// Nested: unbounded fn Lex, Mode -> (([Tok], Lex))
/// ```
pub fn nested(l: &crate::syntax::lexer::Lex, mode: &crate::syntax::lexer::Mode) -> (Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex) {
    let inner = lex_stream(&crate::syntax::lexer::fresh(l, mode));
    let back_ = {
        let mut this: crate::syntax::lexer::Lex = l.clone();
        this.pos = inner.pos.clone();
        this.diags = inner.diags.clone();
        this
    };
    (inner.tokens.clone(), back_.clone())
}

/// The step machine of `Nested`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Nested: unbounded fn Lex, Mode -> (([Tok], Lex))
/// ```
pub struct Nested {
    pub l: crate::syntax::lexer::Lex,
    pub mode: crate::syntax::lexer::Mode,
}

impl prism_rtl::Job<(Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex)> for Nested {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex)> {
        let l = &self.l;
        let mode = &self.mode;
        let l = l.clone();
        let mode = mode.clone();
        call_then(start_lex_stream(crate::syntax::lexer::fresh(&l, &mode)), move |lex_stream_2224: crate::syntax::lexer::Lex| {
            let inner = lex_stream_2224;
            let back_ = {
                let mut this: crate::syntax::lexer::Lex = l.clone();
                this.pos = inner.pos.clone();
                this.diags = inner.diags.clone();
                this
            };
            prism_rtl::Turn::Finished((inner.tokens.clone(), back_.clone()))
        })
    }
}

/// `Start Nested, x`: what the function value is when passed to `@Run`.
pub fn start_nested(l: crate::syntax::lexer::Lex, mode: crate::syntax::lexer::Mode) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex)>> {
    Rc::new(Nested { l, mode })
}

/// ```prism
/// LexStream: unbounded fn Lex -> Lex
/// ```
pub fn lex_stream(l0: &crate::syntax::lexer::Lex) -> crate::syntax::lexer::Lex {
    let mut this: crate::syntax::lexer::Lex = l0.clone();
    let mut at_line_start: bool = crate::syntax::lexer::layout_on(&this.mode);
    let mut done: bool = false;
    while !done {
        let mut go: bool = true;
        if at_line_start && crate::syntax::lexer::layout_active(&this) {
            at_line_start = false;
            let (l, verdict) = begin_line(&this);
            this = l.clone();
            if &verdict == &Text::lit("skip") {
                at_line_start = true;
                go = false;
            }
            if &verdict == &Text::lit("end") {
                done = true;
                go = false;
            }
        }
        if go {
            let c = crate::syntax::lexer::chars::peek(&this);
            match &c {
                u3052_0 if (u3052_0 == &Text::lit("")) => {
                    this = unclosed_stream(&this);
                    done = true;
                    ()
                },
                u3052_1 if (u3052_1 == &Text::lit("\n")) => {
                    this.pos = &this.pos + &Nat::from(1u32);
                    this.last_ws = true;
                    if this.lambda_open {
                        this = crate::syntax::lexer::chars::lex_err(&this, &crate::syntax::lexer::chars::dec(&this.pos), &this.pos, &Text::lit("a lambda's parameter list closes with `|` on its own line"));
                        this.lambda_open = false;
                    }
                    if crate::syntax::lexer::layout_active(&this) {
                        this = end_line(&this);
                        at_line_start = true;
                    }
                    ()
                },
                u3052_2 if (u3052_2 == &Text::lit(" ")) => {
                    this.pos = &this.pos + &Nat::from(1u32);
                    this.last_ws = true;
                    ()
                },
                u3052_3 if (u3052_3 == &Text::lit("\r")) => {
                    this.pos = &this.pos + &Nat::from(1u32);
                    this.last_ws = true;
                    ()
                },
                u3052_4 if (u3052_4 == &Text::lit("\t")) => {
                    this.pos = &this.pos + &Nat::from(1u32);
                    this.last_ws = true;
                    ()
                },
                u3052_5 if (u3052_5 == &Text::lit("#")) => {
                    this.pos = crate::syntax::lexer::chars::line_end(&this);
                    this.last_ws = true;
                    ()
                },
                _ => {
                    let (ends, l) = stream_ends_here(&this);
                    this = l.clone();
                    if ends {
                        done = true;
                    } else {
                        this = crate::syntax::lexer::words::lex_token(&this);
                    }
                    ()
                },
                _ => unreachable!("no arm matched"),
            };
        }
    }
    if crate::syntax::lexer::layout_on(&this.mode) {
        while &len(&this.layout) > &Nat::from(1u32) {
            this.layout = crate::syntax::lexer::chars::pop(&this.layout);
            this = crate::syntax::lexer::push_tok(&this, &crate::syntax::lexer::TokKind::KLayClose, &this.pos, &this.pos);
        }
    }
    if &this.mode == &crate::syntax::lexer::Mode::MFile {
        this = crate::syntax::lexer::push_tok(&this, &crate::syntax::lexer::TokKind::KEof, &this.pos, &this.pos);
    }
    this
}

/// The step machine of `LexStream`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexStream: unbounded fn Lex -> Lex
/// ```
pub struct LexStream {
    pub l0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for LexStream {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l0 = &self.l0;
        let mut this: crate::syntax::lexer::Lex = l0.clone();
        let mut at_line_start: bool = crate::syntax::lexer::layout_on(&this.mode);
        let mut done: bool = false;
        call_then(loop_job((this, at_line_start, done), move |(mut this, mut at_line_start, mut done): (crate::syntax::lexer::Lex, bool, bool)| if !done {
            {
                let mut go: bool = true;
                if at_line_start && crate::syntax::lexer::layout_active(&this) {
                    at_line_start = false;
                    let (l, verdict) = begin_line(&this);
                    this = l.clone();
                    if &verdict == &Text::lit("skip") {
                        at_line_start = true;
                        go = false;
                    }
                    if &verdict == &Text::lit("end") {
                        done = true;
                        go = false;
                    }
                }
                if go {
                    let c = crate::syntax::lexer::chars::peek(&this);
                    match &c {
                        u3052_0 if (u3052_0 == &Text::lit("")) => {
                            this = unclosed_stream(&this);
                            done = true;
                            ()
                        },
                        u3052_1 if (u3052_1 == &Text::lit("\n")) => {
                            this.pos = &this.pos + &Nat::from(1u32);
                            this.last_ws = true;
                            if this.lambda_open {
                                this = crate::syntax::lexer::chars::lex_err(&this, &crate::syntax::lexer::chars::dec(&this.pos), &this.pos, &Text::lit("a lambda's parameter list closes with `|` on its own line"));
                                this.lambda_open = false;
                            }
                            if crate::syntax::lexer::layout_active(&this) {
                                this = end_line(&this);
                                at_line_start = true;
                            }
                            ()
                        },
                        u3052_2 if (u3052_2 == &Text::lit(" ")) => {
                            this.pos = &this.pos + &Nat::from(1u32);
                            this.last_ws = true;
                            ()
                        },
                        u3052_3 if (u3052_3 == &Text::lit("\r")) => {
                            this.pos = &this.pos + &Nat::from(1u32);
                            this.last_ws = true;
                            ()
                        },
                        u3052_4 if (u3052_4 == &Text::lit("\t")) => {
                            this.pos = &this.pos + &Nat::from(1u32);
                            this.last_ws = true;
                            ()
                        },
                        u3052_5 if (u3052_5 == &Text::lit("#")) => {
                            this.pos = crate::syntax::lexer::chars::line_end(&this);
                            this.last_ws = true;
                            ()
                        },
                        _ => {
                            let (ends, l) = stream_ends_here(&this);
                            this = l.clone();
                            if ends {
                                done = true;
                            } else {
                                this = crate::syntax::lexer::words::lex_token(&this);
                            }
                            ()
                        },
                        _ => unreachable!("no arm matched"),
                    };
                }
                Ok((this, at_line_start, done))
            }
        } else {
            Err((this, at_line_start, done))
        }), move |(mut this, mut at_line_start, mut done): (crate::syntax::lexer::Lex, bool, bool)| {
            let k_if4442 = move |(mut this, mut at_line_start, mut done): (crate::syntax::lexer::Lex, bool, bool)| {
                if &this.mode == &crate::syntax::lexer::Mode::MFile {
                    this = crate::syntax::lexer::push_tok(&this, &crate::syntax::lexer::TokKind::KEof, &this.pos, &this.pos);
                }
                prism_rtl::Turn::Finished(this)
            };
            if crate::syntax::lexer::layout_on(&this.mode) {
                call_then(loop_job((this, at_line_start, done), move |(mut this, mut at_line_start, mut done): (crate::syntax::lexer::Lex, bool, bool)| if &len(&this.layout) > &Nat::from(1u32) {
                    {
                        this.layout = crate::syntax::lexer::chars::pop(&this.layout);
                        this = crate::syntax::lexer::push_tok(&this, &crate::syntax::lexer::TokKind::KLayClose, &this.pos, &this.pos);
                        Ok((this, at_line_start, done))
                    }
                } else {
                    Err((this, at_line_start, done))
                }), move |(mut this, mut at_line_start, mut done): (crate::syntax::lexer::Lex, bool, bool)| k_if4442((this, at_line_start, done)))
            } else {
                k_if4442((this, at_line_start, done))
            }
        })
    }
}

/// `Start LexStream, x`: what the function value is when passed to `@Run`.
pub fn start_lex_stream(l0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(LexStream { l0 })
}

/// ```prism
/// UnclosedStream: fn Lex -> Lex
/// ```
pub fn unclosed_stream(l: &crate::syntax::lexer::Lex) -> crate::syntax::lexer::Lex {
    match &l.mode {
        crate::syntax::lexer::Mode::MFile => l.clone(),
        crate::syntax::lexer::Mode::MBrace(_) => crate::syntax::lexer::chars::lex_err(l, &l.pos, &l.pos, &Text::lit("a brace block never closes: expected its closing delimiter alone on a line")),
        crate::syntax::lexer::Mode::MPlaceholder(m4718_2_0) if (m4718_2_0 == &Text::lit("single")) => crate::syntax::lexer::chars::lex_err(l, &l.pos, &l.pos, &Text::lit("a placeholder never closes: expected `}`")),
        crate::syntax::lexer::Mode::MPlaceholder(_) => crate::syntax::lexer::chars::lex_err(l, &l.pos, &l.pos, &Text::lit("a placeholder never closes: expected `}}`")),
        crate::syntax::lexer::Mode::MPathKey => crate::syntax::lexer::chars::lex_err(l, &l.pos, &l.pos, &Text::lit("a path key never closes: expected `]`")),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// StreamEndsHere: fn Lex -> ((Bool, Lex))
/// ```
pub fn stream_ends_here(l: &crate::syntax::lexer::Lex) -> (bool, crate::syntax::lexer::Lex) {
    let c = crate::syntax::lexer::chars::peek(l);
    let closes = match &l.mode {
        crate::syntax::lexer::Mode::MPlaceholder(m5318_0_0) if (m5318_0_0 == &Text::lit("single")) => &c == &Text::lit("}"),
        crate::syntax::lexer::Mode::MPlaceholder(m5318_1_0) if (m5318_1_0 == &Text::lit("double")) => crate::syntax::lexer::chars::starts_with(l, &Text::lit("}}")),
        crate::syntax::lexer::Mode::MPathKey => &c == &Text::lit("]"),
        _ => false,
        _ => unreachable!("no arm matched"),
    };
    let width = if &l.mode == &crate::syntax::lexer::Mode::MPlaceholder(Text::lit("double")) {
        Nat::from(2u32)
    } else {
        Nat::from(1u32)
    };
    if (&len(&l.frames) == &Nat::from(0u32)) && closes {
        (true, crate::syntax::lexer::chars::forward(l, &width))
    } else {
        (false, l.clone())
    }
}

/// ```prism
/// EndLine: fn Lex -> Lex
/// ```
pub fn end_line(l: &crate::syntax::lexer::Lex) -> crate::syntax::lexer::Lex {
    match crate::syntax::lexer::chars::last(&l.tokens) {
        Some(t) if ((&len(&l.tokens) > &l.line_first) && opens_block(&t.kind)) => {
            let mut this: crate::syntax::lexer::Lex = l.clone();
            this.pending_open = true;
            this.pending_span = t.span.clone();
            this
        },
        _ => l.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// OpensBlock: fn TokKind -> Bool
/// ```
pub fn opens_block(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KColon => true,
        crate::syntax::lexer::TokKind::KLambdaBar(false) => true,
        _ => false,
    }
}

/// ```prism
/// BeginLine: unbounded fn Lex -> ((Lex, Text))
/// ```
pub fn begin_line(l0: &crate::syntax::lexer::Lex) -> (crate::syntax::lexer::Lex, Text) {
    let line_begin = l0.pos.clone();
    let (l1, col) = indentation(l0);
    match crate::syntax::lexer::chars::peek(&l1) {
        m6669_0 if (&m6669_0 == &Text::lit("")) => (l1.clone(), Text::lit("end")),
        m6669_1 if (&m6669_1 == &Text::lit("\n")) => (crate::syntax::lexer::chars::bump(&l1), Text::lit("skip")),
        m6669_2 if (&m6669_2 == &Text::lit("#")) => {
            let l2 = {
                let mut this: crate::syntax::lexer::Lex = l1.clone();
                this.pos = crate::syntax::lexer::chars::line_end(&this);
                this
            };
            if &crate::syntax::lexer::chars::peek(&l2) == &Text::lit("\n") {
                (crate::syntax::lexer::chars::bump(&l2), Text::lit("skip"))
            } else {
                (l2.clone(), Text::lit("end"))
            }
        },
        _ => if closes_brace_block(&l1) {
            (skip_line(&l1), Text::lit("end"))
        } else {
            {
                let l2 = indented_line(&l1, &col, &line_begin);
                (l2.clone(), Text::lit("tokens"))
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `BeginLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BeginLine: unbounded fn Lex -> ((Lex, Text))
/// ```
pub struct BeginLine {
    pub l0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<(crate::syntax::lexer::Lex, Text)> for BeginLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::lexer::Lex, Text)> {
        let l0 = &self.l0;
        let line_begin = l0.pos.clone();
        let l0 = l0.clone();
        call_then(start_indentation(l0.clone()), move |indentation_6650: (crate::syntax::lexer::Lex, Nat)| {
            let (l1, col) = indentation_6650;
            match crate::syntax::lexer::chars::peek(&l1) {
                m6669_0 if (&m6669_0 == &Text::lit("")) => prism_rtl::Turn::Finished((l1.clone(), Text::lit("end"))),
                m6669_1 if (&m6669_1 == &Text::lit("\n")) => prism_rtl::Turn::Finished((crate::syntax::lexer::chars::bump(&l1), Text::lit("skip"))),
                m6669_2 if (&m6669_2 == &Text::lit("#")) => {
                    let l2 = {
                        let mut this: crate::syntax::lexer::Lex = l1.clone();
                        this.pos = crate::syntax::lexer::chars::line_end(&this);
                        this
                    };
                    if &crate::syntax::lexer::chars::peek(&l2) == &Text::lit("\n") {
                        prism_rtl::Turn::Finished((crate::syntax::lexer::chars::bump(&l2), Text::lit("skip")))
                    } else {
                        prism_rtl::Turn::Finished((l2.clone(), Text::lit("end")))
                    }
                },
                _ => call_then(start_closes_brace_block(l1.clone()), move |closes_brace_block_7024: bool| if closes_brace_block_7024 {
                    call_then(start_skip_line(l1.clone()), move |skip_line_7047: crate::syntax::lexer::Lex| prism_rtl::Turn::Finished((skip_line_7047, Text::lit("end"))))
                } else {
                    call_then(start_indented_line(l1.clone(), col.clone(), line_begin.clone()), move |indented_line_7111: crate::syntax::lexer::Lex| {
                        let l2 = indented_line_7111;
                        prism_rtl::Turn::Finished((l2.clone(), Text::lit("tokens")))
                    })
                }),
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start BeginLine, x`: what the function value is when passed to `@Run`.
pub fn start_begin_line(l0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<(crate::syntax::lexer::Lex, Text)>> {
    Rc::new(BeginLine { l0 })
}

/// ```prism
/// Indentation: unbounded fn Lex -> ((Lex, Nat))
/// ```
pub fn indentation(l0: &crate::syntax::lexer::Lex) -> (crate::syntax::lexer::Lex, Nat) {
    let mut this: (crate::syntax::lexer::Lex, Nat) = (l0.clone(), Nat::from(0u32));
    let mut l: crate::syntax::lexer::Lex = l0.clone();
    let mut col: Nat = Nat::from(0u32);
    let mut going: bool = true;
    while going {
        match &crate::syntax::lexer::chars::peek(&l) {
            u7432_0 if (u7432_0 == &Text::lit(" ")) => {
                l = crate::syntax::lexer::chars::bump(&l);
                col = &col + &Nat::from(1u32);
                ()
            },
            u7432_1 if (u7432_1 == &Text::lit("\t")) => {
                l = crate::syntax::lexer::chars::lex_err(&crate::syntax::lexer::chars::bump(&l), &l.pos, &(&l.pos + &Nat::from(1u32)), &Text::lit("a tab in leading whitespace is an error: indent with spaces"));
                col = &col + &Nat::from(1u32);
                ()
            },
            u7432_2 if (u7432_2 == &Text::lit("\r")) => {
                l = crate::syntax::lexer::chars::bump(&l);
                ()
            },
            _ => {
                going = false;
                ()
            },
            _ => unreachable!("no arm matched"),
        };
    }
    this = (l.clone(), col.clone());
    this
}

/// The step machine of `Indentation`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Indentation: unbounded fn Lex -> ((Lex, Nat))
/// ```
pub struct Indentation {
    pub l0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<(crate::syntax::lexer::Lex, Nat)> for Indentation {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::lexer::Lex, Nat)> {
        let l0 = &self.l0;
        let mut this: (crate::syntax::lexer::Lex, Nat) = (l0.clone(), Nat::from(0u32));
        let mut l: crate::syntax::lexer::Lex = l0.clone();
        let mut col: Nat = Nat::from(0u32);
        let mut going: bool = true;
        call_then(loop_job((this, col, going, l), move |(mut this, mut col, mut going, mut l): ((crate::syntax::lexer::Lex, Nat), Nat, bool, crate::syntax::lexer::Lex)| if going {
            {
                match &crate::syntax::lexer::chars::peek(&l) {
                    u7432_0 if (u7432_0 == &Text::lit(" ")) => {
                        l = crate::syntax::lexer::chars::bump(&l);
                        col = &col + &Nat::from(1u32);
                        ()
                    },
                    u7432_1 if (u7432_1 == &Text::lit("\t")) => {
                        l = crate::syntax::lexer::chars::lex_err(&crate::syntax::lexer::chars::bump(&l), &l.pos, &(&l.pos + &Nat::from(1u32)), &Text::lit("a tab in leading whitespace is an error: indent with spaces"));
                        col = &col + &Nat::from(1u32);
                        ()
                    },
                    u7432_2 if (u7432_2 == &Text::lit("\r")) => {
                        l = crate::syntax::lexer::chars::bump(&l);
                        ()
                    },
                    _ => {
                        going = false;
                        ()
                    },
                    _ => unreachable!("no arm matched"),
                };
                Ok((this, col, going, l))
            }
        } else {
            Err((this, col, going, l))
        }), move |(mut this, mut col, mut going, mut l): ((crate::syntax::lexer::Lex, Nat), Nat, bool, crate::syntax::lexer::Lex)| {
            this = (l.clone(), col.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start Indentation, x`: what the function value is when passed to `@Run`.
pub fn start_indentation(l0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<(crate::syntax::lexer::Lex, Nat)>> {
    Rc::new(Indentation { l0 })
}

/// ```prism
/// ClosesBraceBlock: unbounded fn Lex -> Bool
/// ```
pub fn closes_brace_block(l: &crate::syntax::lexer::Lex) -> bool {
    match &l.mode {
        crate::syntax::lexer::Mode::MBrace(m7910_0_0) if (m7910_0_0 == &Text::lit("double")) => &crate::syntax::lexer::chars::trim_end(&crate::syntax::lexer::chars::rest_of_line(l)) == &Text::lit("}}"),
        crate::syntax::lexer::Mode::MBrace(_) => &crate::syntax::lexer::chars::trim_end(&crate::syntax::lexer::chars::rest_of_line(l)) == &Text::lit("}"),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ClosesBraceBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosesBraceBlock: unbounded fn Lex -> Bool
/// ```
pub struct ClosesBraceBlock {
    pub l: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<bool> for ClosesBraceBlock {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let l = &self.l;
        match &l.mode {
            crate::syntax::lexer::Mode::MBrace(m7910_0_0) if (m7910_0_0 == &Text::lit("double")) => {
                let l = l.clone();
                call_then(crate::syntax::lexer::chars::start_rest_of_line(l.clone()), move |rest_of_line_7955: Text| prism_rtl::Turn::Finished(&crate::syntax::lexer::chars::trim_end(&rest_of_line_7955) == &Text::lit("}}")))
            },
            crate::syntax::lexer::Mode::MBrace(_) => {
                let l = l.clone();
                call_then(crate::syntax::lexer::chars::start_rest_of_line(l.clone()), move |rest_of_line_8009: Text| prism_rtl::Turn::Finished(&crate::syntax::lexer::chars::trim_end(&rest_of_line_8009) == &Text::lit("}")))
            },
            _ => prism_rtl::Turn::Finished(false),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ClosesBraceBlock, x`: what the function value is when passed to `@Run`.
pub fn start_closes_brace_block(l: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(ClosesBraceBlock { l })
}

/// ```prism
/// SkipLine: unbounded fn Lex -> Lex
/// ```
pub fn skip_line(l0: &crate::syntax::lexer::Lex) -> crate::syntax::lexer::Lex {
    let l = {
        let mut this: crate::syntax::lexer::Lex = l0.clone();
        this.pos = crate::syntax::lexer::chars::line_end(&this);
        this
    };
    if &crate::syntax::lexer::chars::peek(&l) == &Text::lit("\n") {
        crate::syntax::lexer::chars::bump(&l)
    } else {
        l.clone()
    }
}

/// The step machine of `SkipLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SkipLine: unbounded fn Lex -> Lex
/// ```
pub struct SkipLine {
    pub l0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for SkipLine {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l0 = &self.l0;
        let l = {
            let mut this: crate::syntax::lexer::Lex = l0.clone();
            this.pos = crate::syntax::lexer::chars::line_end(&this);
            this
        };
        if &crate::syntax::lexer::chars::peek(&l) == &Text::lit("\n") {
            prism_rtl::Turn::Finished(crate::syntax::lexer::chars::bump(&l))
        } else {
            prism_rtl::Turn::Finished(l.clone())
        }
    }
}

/// `Start SkipLine, x`: what the function value is when passed to `@Run`.
pub fn start_skip_line(l0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(SkipLine { l0 })
}

/// ```prism
/// IndentedLine: unbounded fn Lex, Nat, Nat -> Lex
/// ```
pub fn indented_line(l0: &crate::syntax::lexer::Lex, col: &Nat, line_begin: &Nat) -> crate::syntax::lexer::Lex {
    let here = l0.pos.clone();
    let l = {
        let mut this: crate::syntax::lexer::Lex = l0.clone();
        this.line_first = len(&this.tokens);
        this.last_ws = true;
        this
    };
    if l.first_line {
        first_line(&l, col, line_begin, &here)
    } else {
        layout_line(&l, col, line_begin, &here)
    }
}

/// The step machine of `IndentedLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IndentedLine: unbounded fn Lex, Nat, Nat -> Lex
/// ```
pub struct IndentedLine {
    pub l0: crate::syntax::lexer::Lex,
    pub col: Nat,
    pub line_begin: Nat,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for IndentedLine {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l0 = &self.l0;
        let col = &self.col;
        let line_begin = &self.line_begin;
        let here = l0.pos.clone();
        let l = {
            let mut this: crate::syntax::lexer::Lex = l0.clone();
            this.line_first = len(&this.tokens);
            this.last_ws = true;
            this
        };
        if l.first_line {
            prism_rtl::Turn::Finished(first_line(&l, col, line_begin, &here))
        } else {
            prism_rtl::Turn::Finished(layout_line(&l, col, line_begin, &here))
        }
    }
}

/// `Start IndentedLine, x`: what the function value is when passed to `@Run`.
pub fn start_indented_line(l0: crate::syntax::lexer::Lex, col: Nat, line_begin: Nat) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(IndentedLine { l0, col, line_begin })
}

/// ```prism
/// FirstLine: fn Lex, Nat, Nat, Nat -> Lex
/// ```
pub fn first_line(l0: &crate::syntax::lexer::Lex, col: &Nat, line_begin: &Nat, here: &Nat) -> crate::syntax::lexer::Lex {
    let mut this: crate::syntax::lexer::Lex = l0.clone();
    this.first_line = false;
    if &this.mode == &crate::syntax::lexer::Mode::MFile {
        this.layout = Array::from(vec![Nat::from(0u32)]);
        if col != &Nat::from(0u32) {
            this = crate::syntax::lexer::chars::lex_err(&this, line_begin, here, &Text::lit("the first line of a file starts at column 0"));
            this.layout = Array::from(vec![col.clone()]);
        }
    } else {
        this.layout = push(&this.layout, col);
    }
    this
}

/// ```prism
/// Below: fn ?Nat, Nat -> Bool
/// ```
pub fn below(opt0: &Option<Nat>, n1: &Nat) -> bool {
    match (opt0, n1) {
        (None, _) => false,
        (Some(d), depth) => depth < d,
    }
}

/// ```prism
/// LayoutLine: fn Lex, Nat, Nat, Nat -> Lex
/// ```
pub fn layout_line(l0: &crate::syntax::lexer::Lex, col: &Nat, line_begin: &Nat, here: &Nat) -> crate::syntax::lexer::Lex {
    let mut this: crate::syntax::lexer::Lex = l0.clone();
    let top = or(&crate::syntax::lexer::chars::last(&this.layout), &Nat::from(0u32));
    let fat = crate::syntax::lexer::chars::starts_with(&this, &Text::lit("=>"));
    let mut opened: bool = false;
    let mut fuel: Nat = len(&this.layout);
    if this.pending_open {
        this.pending_open = false;
        if col > &top {
            this.layout = push(&this.layout, col);
            this = crate::syntax::lexer::push_tok(&this, &crate::syntax::lexer::TokKind::KLayOpen, here, here);
            if &this.test_pending == &Text::lit("test") {
                this.test_depth = Some(len(&this.layout));
            }
            if &this.test_pending == &Text::lit("check") {
                this.check_depth = Some(len(&this.layout));
            }
            this.test_pending = Text::lit("");
            opened = true;
        } else {
            this.diags = push(&this.diags, &crate::syntax::lexer::chars::lex_diag(&this.pending_span, &Text::lit("expected an indented block after `:`")));
        }
    }
    if !opened {
        if ((col > &top) && fat) && (&this.test_depth == &Some(len(&this.layout))) {
            this.layout = push(&this.layout, col);
            this = crate::syntax::lexer::push_tok(&this, &crate::syntax::lexer::TokKind::KLayOpen, here, here);
        } else if col == &top {
            this = crate::syntax::lexer::push_tok(&this, &crate::syntax::lexer::TokKind::KLaySep, here, here);
            if &len(&this.layout) == &Nat::from(1u32) {
                this.test_pending = Text::lit("");
            }
        } else if col > &top {
            this.mark_line_start = true;
        } else {
            while let Some(left) = (&fuel).checked_sub(&Nat::from(1u32)) {
                if !((&len(&this.layout) > &Nat::from(1u32)) && (col < &or(&crate::syntax::lexer::chars::last(&this.layout), &Nat::from(0u32)))) {
                    break;
                }
                fuel = left.clone();
                this.layout = crate::syntax::lexer::chars::pop(&this.layout);
                this = crate::syntax::lexer::push_tok(&this, &crate::syntax::lexer::TokKind::KLayClose, here, here);
                let depth = len(&this.layout);
                if below(&this.test_depth, &depth) {
                    this.test_depth = None;
                }
                if below(&this.check_depth, &depth) {
                    this.check_depth = None;
                }
            }
            if col != &or(&crate::syntax::lexer::chars::last(&this.layout), &Nat::from(0u32)) {
                this = crate::syntax::lexer::chars::lex_err(&this, line_begin, here, &Text::lit("unindent does not match any open block"));
            }
            this = crate::syntax::lexer::push_tok(&this, &crate::syntax::lexer::TokKind::KLaySep, here, here);
            if &len(&this.layout) == &Nat::from(1u32) {
                this.test_pending = Text::lit("");
            }
        }
    }
    this
}
