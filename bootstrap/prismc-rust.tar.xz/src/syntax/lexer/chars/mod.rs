//! The module `Syntax.Lexer.Chars`, from `target/bootstrap/src/prismc/syntax/lexer/chars.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// Dec: fn Nat -> Nat
/// ```
pub fn dec_f(n_p0: &crate::prelude::Nat) -> crate::prelude::Nat {
    crate::prelude::or(&n_p0.checked_sub(&crate::prelude::Nat::from(1u32)), &crate::prelude::Nat::from(0u32))
}

/// ```prism
/// ?Last: fn [a] -> ?a
/// ```
pub fn last_o<A: ::std::clone::Clone + 'static>(xs_p0: &crate::prelude::Array<A>) -> ::std::option::Option<A> {
    crate::prelude::index(xs_p0, &dec_f(&crate::prelude::len(xs_p0)))
}

/// ```prism
/// Pop: fn [a] -> [a]
/// ```
pub fn pop_f<A: ::std::clone::Clone + 'static>(xs_p0: &crate::prelude::Array<A>) -> crate::prelude::Array<A> {
    crate::prelude::take(xs_p0, &dec_f(&crate::prelude::len(xs_p0)))
}

/// ```prism
/// Join: fn [Text], Text -> Text
/// ```
pub fn join_f(xs_p0: &crate::prelude::Array<crate::prelude::Text>, sep_p1: &crate::prelude::Text) -> crate::prelude::Text {
    match crate::prelude::index(xs_p0, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::Some(first_p2) => crate::prelude::concat(&crate::prelude::fold(&crate::prelude::drop(xs_p0, &crate::prelude::Nat::from(1u32)), &crate::prelude::Array::from(vec![first_p2.clone()]), &(|acc_p3: &crate::prelude::Array<crate::prelude::Text>, x_p4: &crate::prelude::Text| crate::prelude::push(&crate::prelude::push(acc_p3, sep_p1), x_p4)))),
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// CharAt: fn Cursor -> Text
/// ```
pub fn char_at_f(c_p0: &crate::prelude::Cursor) -> crate::prelude::Text {
    match crate::prelude::step(&crate::prelude::front(&crate::prelude::after(c_p0))) {
        ::std::option::Option::Some((_, one_p1)) => crate::prelude::before(&one_p1),
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// Head: fn Text -> Text
/// ```
pub fn head_f(t_p0: &crate::prelude::Text) -> crate::prelude::Text {
    char_at_f(&crate::prelude::front(t_p0))
}

/// ```prism
/// AfterFirst: fn Text -> Text
/// ```
pub fn after_first_f(t_p0: &crate::prelude::Text) -> crate::prelude::Text {
    match crate::prelude::step(&crate::prelude::front(t_p0)) {
        ::std::option::Option::Some((_, c_p1)) => crate::prelude::after(&c_p1),
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// LastChar: fn Text -> Text
/// ```
pub fn last_char_f(t_p0: &crate::prelude::Text) -> crate::prelude::Text {
    match crate::prelude::step_back(&crate::prelude::back(t_p0)) {
        ::std::option::Option::Some((_, c_p1)) => crate::prelude::after(&c_p1),
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// BeforeLast: fn Text -> Text
/// ```
pub fn before_last_f(t_p0: &crate::prelude::Text) -> crate::prelude::Text {
    match crate::prelude::step_back(&crate::prelude::back(t_p0)) {
        ::std::option::Option::Some((_, c_p1)) => crate::prelude::before(&c_p1),
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// Between: fn Text, Nat, Nat -> Text
/// ```
pub fn between_f(t_p0: &crate::prelude::Text, a_p1: &crate::prelude::Nat, b_p2: &crate::prelude::Nat) -> crate::prelude::Text {
    match crate::prelude::cursor_at(t_p0, b_p2) {
        ::std::option::Option::Some(cb_p3) => match crate::prelude::cursor_at(&crate::prelude::before(&cb_p3), a_p1) {
            ::std::option::Option::Some(ca_p4) => crate::prelude::after(&ca_p4),
            ::std::option::Option::None => crate::prelude::Text::lit(""),
        },
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// ?AfterPrefix: fn Text, Text -> ?Text
/// ```
pub fn after_prefix_o(t_p0: &crate::prelude::Text, p_p1: &crate::prelude::Text) -> ::std::option::Option<crate::prelude::Text> {
    match crate::prelude::cursor_at(t_p0, &crate::prelude::len_text(p_p1)) {
        ::std::option::Option::Some(c_p2) => if &crate::prelude::before(&c_p2) == p_p1 {
            ::std::option::Option::Some(crate::prelude::after(&c_p2))
        } else {
            ::std::option::Option::None
        },
        ::std::option::Option::None => ::std::option::Option::None,
    }
}

/// ```prism
/// HasPrefix: fn Text, Text -> Bool
/// ```
pub fn has_prefix_f(t_p0: &crate::prelude::Text, p_p1: &crate::prelude::Text) -> bool {
    &after_prefix_o(t_p0, p_p1) != &::std::option::Option::None
}

/// ```prism
/// DropPrefix: fn Text, Text -> Text
/// ```
pub fn drop_prefix_f(t_p0: &crate::prelude::Text, p_p1: &crate::prelude::Text) -> crate::prelude::Text {
    crate::prelude::or(&after_prefix_o(t_p0, p_p1), t_p0)
}

/// ```prism
/// ?BeforeSuffix: fn Text, Text -> ?Text
/// ```
pub fn before_suffix_o(t_p0: &crate::prelude::Text, s_p1: &crate::prelude::Text) -> ::std::option::Option<crate::prelude::Text> {
    match (&crate::prelude::len_text(t_p0)).checked_sub(&crate::prelude::len_text(s_p1)) {
        ::std::option::Option::Some(n_p2) => match crate::prelude::cursor_at(t_p0, &n_p2) {
            ::std::option::Option::Some(c_p3) => if &crate::prelude::after(&c_p3) == s_p1 {
                ::std::option::Option::Some(crate::prelude::before(&c_p3))
            } else {
                ::std::option::Option::None
            },
            ::std::option::Option::None => ::std::option::Option::None,
        },
        ::std::option::Option::None => ::std::option::Option::None,
    }
}

/// ```prism
/// HasSuffix: fn Text, Text -> Bool
/// ```
pub fn has_suffix_f(t_p0: &crate::prelude::Text, s_p1: &crate::prelude::Text) -> bool {
    &before_suffix_o(t_p0, s_p1) != &::std::option::Option::None
}

/// ```prism
/// FoldChars: fn Text, b, (fn b, Text -> b) -> b
/// ```
pub fn fold_chars_f<B: ::std::clone::Clone + 'static>(t_p0: &crate::prelude::Text, z_p1: &B, f_f2: &::std::rc::Rc<dyn ::std::ops::Fn((B, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<B>>>) -> B {
    let mut this: B = z_p1.clone();
    let mut c_p3: crate::prelude::Cursor = crate::prelude::front(t_p0);
    while let ::std::option::Option::Some((_, next_p4)) = crate::prelude::step(&c_p3) {
        this = crate::prelude::run_to_end(f_f2((this.clone(), char_at_f(&c_p3))));
        c_p3 = next_p4.clone();
    }
    this
}

/// The step machine of `FoldChars`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FoldChars: fn Text, b, (fn b, Text -> b) -> b
/// ```
pub struct FoldChars<B> {
    pub t_p0: crate::prelude::Text,
    pub z_p1: B,
    pub f_f2: ::std::rc::Rc<dyn ::std::ops::Fn((B, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<B>>>,
}

impl<B: ::std::clone::Clone + 'static> ::prism_rtl::Job<B> for FoldChars<B> {
    fn cycle(&self) -> ::prism_rtl::Turn<B> {
        let t_p0 = &self.t_p0;
        let z_p1 = &self.z_p1;
        let f_f2 = &self.f_f2;
        ::prism_rtl::Turn::Finished({
            let mut this: B = z_p1.clone();
            let mut c_p3: crate::prelude::Cursor = crate::prelude::front(t_p0);
            while let ::std::option::Option::Some((_, next_p4)) = crate::prelude::step(&c_p3) {
                this = crate::prelude::run_to_end(f_f2((this.clone(), char_at_f(&c_p3))));
                c_p3 = next_p4.clone();
            }
            this
        })
    }
}

/// `Start FoldChars, x`: what the function value is when passed to `@Run`.
pub fn start_fold_chars_f<B: ::std::clone::Clone + 'static>(t_p0: crate::prelude::Text, z_p1: B, f_f2: ::std::rc::Rc<dyn ::std::ops::Fn((B, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<B>>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<B>> {
    ::std::rc::Rc::new(FoldChars::<B> { t_p0, z_p1, f_f2 })
}

/// ```prism
/// MapChars: fn Text, (fn Text -> Text) -> Text
/// ```
pub fn map_chars_f(t_p0: &crate::prelude::Text, f_f1: &::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>) -> crate::prelude::Text {
    crate::prelude::concat(&fold_chars_f(t_p0, &crate::prelude::Array::new(), &{
        let f_f1x = f_f1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)| {
            let f_f1xy = f_f1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p2 = p0;
                let c_p3 = p1;
                crate::prelude::call_value((&f_f1xy)(c_p3.clone()), move |f_3224: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p2, &f_3224)))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
    }))
}

/// ```prism
/// CountChars: fn Text -> Nat
/// ```
pub fn count_chars_f(t_p0: &crate::prelude::Text) -> crate::prelude::Nat {
    fold_chars_f(t_p0, &crate::prelude::Nat::from(0u32), &(::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Nat, crate::prelude::Text)| crate::prelude::once_job(move || {
        let n_p1 = p0;
        let _ = p1;
        ::prism_rtl::Turn::Finished(&n_p1 + &crate::prelude::Nat::from(1u32))
    })) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Nat, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Nat>>>))
}

/// ```prism
/// ColumnOf: fn Text, Nat, Nat -> Nat
/// ```
pub fn column_of_f(text_p0: &crate::prelude::Text, from_p1: &crate::prelude::Nat, offset_p2: &crate::prelude::Nat) -> crate::prelude::Nat {
    count_chars_f(&between_f(text_p0, from_p1, offset_p2))
}

/// ```prism
/// AllChars: fn Text, (fn Text -> Bool) -> Bool
/// ```
pub fn all_chars_f(t_p0: &crate::prelude::Text, p_f1: &::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>) -> bool {
    fold_chars_f(t_p0, &true, &{
        let p_f1x = p_f1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::prelude::Text)| {
            let p_f1xy = p_f1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let ok_p2 = p0;
                let c_p3 = p1;
                if ok_p2 {
                    (&p_f1xy)(c_p3.clone()).cycle()
                } else {
                    ::prism_rtl::Turn::Finished(false)
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    })
}

/// ```prism
/// TrimLeading: fn Text, Text -> Text
/// ```
pub fn trim_leading_f(t_p0: &crate::prelude::Text, set_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let c_p2 = {
        let mut this: crate::prelude::Cursor = crate::prelude::front(t_p0);
        while let ::std::option::Option::Some((_, next_p3)) = crate::prelude::step(&this) {
            if !contains_f(set_p1, &char_at_f(&this)) {
                break;
            }
            this = next_p3.clone();
        }
        this
    };
    crate::prelude::after(&c_p2)
}

/// ```prism
/// TrimTrailing: fn Text, Text -> Text
/// ```
pub fn trim_trailing_f(t_p0: &crate::prelude::Text, set_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let c_p2 = {
        let mut this: crate::prelude::Cursor = crate::prelude::back(t_p0);
        let mut fuel_p3: crate::prelude::Nat = crate::prelude::len_text(t_p0);
        while let ::std::option::Option::Some(left_p4) = (&fuel_p3).checked_sub(&crate::prelude::Nat::from(1u32)) {
            fuel_p3 = left_p4.clone();
            match &crate::prelude::step_back(&this) {
                ::std::option::Option::Some((_, prev_p5)) if contains_f(set_p1, &char_at_f(prev_p5)) => {
                    this = prev_p5.clone();
                    ()
                },
                _ => {
                    fuel_p3 = crate::prelude::Nat::from(0u32);
                    ()
                },
                _ => unreachable!("no arm matched"),
            };
        }
        this
    };
    crate::prelude::before(&c_p2)
}

/// ```prism
/// TrimStart: fn Text -> Text
/// ```
pub fn trim_start_f(t_p0: &crate::prelude::Text) -> crate::prelude::Text {
    trim_leading_f(t_p0, &crate::prelude::Text::lit(" \r"))
}

/// ```prism
/// TrimEnd: fn Text -> Text
/// ```
pub fn trim_end_f(t_p0: &crate::prelude::Text) -> crate::prelude::Text {
    trim_trailing_f(t_p0, &crate::prelude::Text::lit(" \r"))
}

/// ```prism
/// Trim: fn Text -> Text
/// ```
pub fn trim_f(t_p0: &crate::prelude::Text) -> crate::prelude::Text {
    trim_end_f(&trim_start_f(t_p0))
}

/// ```prism
/// LeadingIn: fn Text, Text -> Nat
/// ```
pub fn leading_in_f(t_p0: &crate::prelude::Text, set_p1: &crate::prelude::Text) -> crate::prelude::Nat {
    crate::prelude::or(&(&crate::prelude::len_text(t_p0)).checked_sub(&crate::prelude::len_text(&trim_leading_f(t_p0, set_p1))), &crate::prelude::Nat::from(0u32))
}

/// ```prism
/// Contains: fn Text, Text -> Bool
/// ```
pub fn contains_f(set_p0: &crate::prelude::Text, c_p1: &crate::prelude::Text) -> bool {
    (c_p1 != &crate::prelude::Text::lit("")) && (&crate::prelude::len(&crate::prelude::split_on(set_p0, c_p1)) > &crate::prelude::Nat::from(1u32))
}

/// ```prism
/// IsDigit: fn Text -> Bool
/// ```
pub fn is_digit_f(c_p0: &crate::prelude::Text) -> bool {
    (&crate::prelude::Text::lit("0") <= c_p0) && (c_p0 <= &crate::prelude::Text::lit("9"))
}

/// ```prism
/// IsUpper: fn Text -> Bool
/// ```
pub fn is_upper_f(c_p0: &crate::prelude::Text) -> bool {
    (&crate::prelude::Text::lit("A") <= c_p0) && (c_p0 <= &crate::prelude::Text::lit("Z"))
}

/// ```prism
/// IsLower: fn Text -> Bool
/// ```
pub fn is_lower_f(c_p0: &crate::prelude::Text) -> bool {
    (&crate::prelude::Text::lit("a") <= c_p0) && (c_p0 <= &crate::prelude::Text::lit("z"))
}

/// ```prism
/// IsIdentStart: fn Text -> Bool
/// ```
pub fn is_ident_start_f(c_p0: &crate::prelude::Text) -> bool {
    (is_lower_f(c_p0) || is_upper_f(c_p0)) || (c_p0 == &crate::prelude::Text::lit("_"))
}

/// ```prism
/// IsIdentChar: fn Text -> Bool
/// ```
pub fn is_ident_char_f(c_p0: &crate::prelude::Text) -> bool {
    is_ident_start_f(c_p0) || is_digit_f(c_p0)
}

/// ```prism
/// IsHexDigit: fn Text -> Bool
/// ```
pub fn is_hex_digit_f(c_p0: &crate::prelude::Text) -> bool {
    (is_digit_f(c_p0) || ((&crate::prelude::Text::lit("a") <= c_p0) && (c_p0 <= &crate::prelude::Text::lit("f")))) || ((&crate::prelude::Text::lit("A") <= c_p0) && (c_p0 <= &crate::prelude::Text::lit("F")))
}

/// ```prism
/// IsNonAscii: fn Text -> Bool
/// ```
pub fn is_non_ascii_f(c_p0: &crate::prelude::Text) -> bool {
    c_p0 > &crate::prelude::Text::lit("")
}

/// ```prism
/// IsSigilChar: fn Text -> Bool
/// ```
pub fn is_sigil_char_f(c_p0: &crate::prelude::Text) -> bool {
    contains_f(&crate::prelude::Text::lit("$!@?~&"), c_p0)
}

/// ```prism
/// IsSpaceChar: fn Text -> Bool
/// ```
pub fn is_space_char_f(c_p0: &crate::prelude::Text) -> bool {
    (((c_p0 == &crate::prelude::Text::lit(" ")) || (c_p0 == &crate::prelude::Text::lit("\n"))) || (c_p0 == &crate::prelude::Text::lit("\r"))) || (c_p0 == &crate::prelude::Text::lit("\t"))
}

/// ```prism
/// IsReservedCtor: fn Text -> Bool
/// ```
pub fn is_reserved_ctor_f(w_p0: &crate::prelude::Text) -> bool {
    (w_p0 == &crate::prelude::Text::lit("templatetext")) || (w_p0 == &crate::prelude::Text::lit("templateplaceholder"))
}

/// ```prism
/// let asciiText
/// ```
pub fn ascii_text_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("\0\t\n\r !\"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")
}

/// ```prism
/// let hexDigits
/// ```
pub fn hex_digits_p() -> crate::prelude::Text {
    crate::prelude::Text::lit("0123456789abcdef")
}

/// ```prism
/// CharAtByte: fn Text, Nat -> Text
/// ```
pub fn char_at_byte_f(t_p0: &crate::prelude::Text, n_p1: &crate::prelude::Nat) -> crate::prelude::Text {
    match crate::prelude::cursor_at(t_p0, n_p1) {
        ::std::option::Option::Some(c_p2) => char_at_f(&c_p2),
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// HexValue: fn Text -> Nat
/// ```
pub fn hex_value_f(c_p0: &crate::prelude::Text) -> crate::prelude::Nat {
    let l_p1 = crate::prelude::lower(c_p0);
    if &l_p1 == &crate::prelude::Text::lit("") {
        crate::prelude::Nat::from(16u32)
    } else {
        crate::prelude::len_text(&crate::prelude::or(&crate::prelude::index(&crate::prelude::split_on(&hex_digits_p(), &l_p1), &crate::prelude::Nat::from(0u32)), &hex_digits_p()))
    }
}

/// ```prism
/// ?ParseHex: fn Text -> ?Nat
/// ```
pub fn parse_hex_o(t_p0: &crate::prelude::Text) -> ::std::option::Option<crate::prelude::Nat> {
    'g7251: {
        if !((t_p0 != &crate::prelude::Text::lit("")) && all_chars_f(t_p0, &{
            let f = ::std::rc::Rc::new(is_hex_digit_f);
            ::std::rc::Rc::new(move |a0: crate::prelude::Text| {
                let fy = f.clone();
                crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        })) {
            break 'g7251 ::std::option::Option::None;
        }
        ::std::option::Option::Some(fold_chars_f(t_p0, &crate::prelude::Nat::from(0u32), &(::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Nat, crate::prelude::Text)| crate::prelude::once_job(move || {
            let n_p1 = p0;
            let c_p2 = p1;
            ::prism_rtl::Turn::Finished(&(&n_p1 * &crate::prelude::Nat::from(16u32)) + &hex_value_f(&c_p2))
        })) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Nat, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Nat>>>)))
    }
}

/// ```prism
/// Rest: fn Lex -> Text
/// ```
pub fn rest_f(l_p0: &crate::syntax::lexer::Lex) -> crate::prelude::Text {
    match crate::prelude::cursor_at(&l_p0.src_p, &l_p0.pos_p) {
        ::std::option::Option::Some(c_p1) => crate::prelude::after(&c_p1),
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// Peek: fn Lex -> Text
/// ```
pub fn peek_f(l_p0: &crate::syntax::lexer::Lex) -> crate::prelude::Text {
    char_at_byte_f(&l_p0.src_p, &l_p0.pos_p)
}

/// ```prism
/// PeekAt: fn Lex, Nat -> Text
/// ```
pub fn peek_at_f(l_p0: &crate::syntax::lexer::Lex, n_p1: &crate::prelude::Nat) -> crate::prelude::Text {
    let rest_p2 = {
        let mut this: crate::prelude::Text = rest_f(l_p0);
        let mut k_p3: crate::prelude::Nat = n_p1.clone();
        while let ::std::option::Option::Some(left_p4) = (&k_p3).checked_sub(&crate::prelude::Nat::from(1u32)) {
            k_p3 = left_p4.clone();
            this = after_first_f(&this);
        }
        this
    };
    head_f(&rest_p2)
}

/// ```prism
/// StartsWith: fn Lex, Text -> Bool
/// ```
pub fn starts_with_f(l_p0: &crate::syntax::lexer::Lex, s_p1: &crate::prelude::Text) -> bool {
    has_prefix_f(&rest_f(l_p0), s_p1)
}

/// ```prism
/// Slice: fn Lex, Nat, Nat -> Text
/// ```
pub fn slice_f(l_p0: &crate::syntax::lexer::Lex, a_p1: &crate::prelude::Nat, b_p2: &crate::prelude::Nat) -> crate::prelude::Text {
    between_f(&l_p0.src_p, a_p1, b_p2)
}

/// ```prism
/// Bump: fn Lex -> Lex
/// ```
pub fn bump_f(l_p0: &crate::syntax::lexer::Lex) -> crate::syntax::lexer::Lex {
    let mut this: crate::syntax::lexer::Lex = l_p0.clone();
    this.pos_p = &this.pos_p + &crate::prelude::len_text(&peek_f(&this));
    this
}

/// ```prism
/// Forward: fn Lex, Nat -> Lex
/// ```
pub fn forward_f(l_p0: &crate::syntax::lexer::Lex, n_p1: &crate::prelude::Nat) -> crate::syntax::lexer::Lex {
    let mut this: crate::syntax::lexer::Lex = l_p0.clone();
    let mut k_p2: crate::prelude::Nat = n_p1.clone();
    while let ::std::option::Option::Some(left_p3) = (&k_p2).checked_sub(&crate::prelude::Nat::from(1u32)) {
        k_p2 = left_p3.clone();
        this.pos_p = &this.pos_p + &crate::prelude::len_text(&peek_f(&this));
    }
    this
}

/// ```prism
/// NextIsSpace: fn Lex, Nat -> Bool
/// ```
pub fn next_is_space_f(l_p0: &crate::syntax::lexer::Lex, n_p1: &crate::prelude::Nat) -> bool {
    let c_p2 = peek_at_f(l_p0, n_p1);
    (&c_p2 == &crate::prelude::Text::lit("")) || is_space_char_f(&c_p2)
}

/// ```prism
/// MatchEnd: fn Regex, Text, Nat -> Nat
/// ```
pub fn match_end_f(r_p0: &crate::prelude::Regex, src_p1: &crate::prelude::Text, at_p2: &crate::prelude::Nat) -> crate::prelude::Nat {
    match crate::prelude::cursor_at(src_p1, at_p2) {
        ::std::option::Option::Some(c_p3) => match crate::prelude::match_(r_p0, &c_p3) {
            ::std::option::Option::Some(m_p4) => crate::prelude::at(&m_p4.back_p),
            ::std::option::Option::None => at_p2.clone(),
        },
        ::std::option::Option::None => at_p2.clone(),
    }
}

/// ```prism
/// MatchHere: fn Regex, Lex -> Text
/// ```
pub fn match_here_f(r_p0: &crate::prelude::Regex, l_p1: &crate::syntax::lexer::Lex) -> crate::prelude::Text {
    between_f(&l_p1.src_p, &l_p1.pos_p, &match_end_f(r_p0, &l_p1.src_p, &l_p1.pos_p))
}

/// ```prism
/// LineEnd: fn Lex -> Nat
/// ```
pub fn line_end_f(l_p0: &crate::syntax::lexer::Lex) -> crate::prelude::Nat {
    match_end_f(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[^\\n]*", "")); R.with(crate::prelude::Regex::clone) }, &l_p0.src_p, &l_p0.pos_p)
}

/// ```prism
/// RestOfLine: unbounded fn Lex -> Text
/// ```
pub fn rest_of_line_f(l_p0: &crate::syntax::lexer::Lex) -> crate::prelude::Text {
    slice_f(l_p0, &l_p0.pos_p, &line_end_f(l_p0))
}

/// The step machine of `RestOfLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RestOfLine: unbounded fn Lex -> Text
/// ```
pub struct RestOfLine {
    pub l_p0: crate::syntax::lexer::Lex,
}

impl ::prism_rtl::Job<crate::prelude::Text> for RestOfLine {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let l_p0 = &self.l_p0;
        ::prism_rtl::Turn::Finished(slice_f(l_p0, &l_p0.pos_p, &line_end_f(l_p0)))
    }
}

/// `Start RestOfLine, x`: what the function value is when passed to `@Run`.
pub fn start_rest_of_line_f(l_p0: crate::syntax::lexer::Lex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(RestOfLine { l_p0 })
}

/// ```prism
/// LexErr: fn Lex, Nat, Nat, Text -> Lex
/// ```
pub fn lex_err_f(l_p0: &crate::syntax::lexer::Lex, start_p1: &crate::prelude::Nat, end_p2: &crate::prelude::Nat, message_p3: &crate::prelude::Text) -> crate::syntax::lexer::Lex {
    let mut this: crate::syntax::lexer::Lex = l_p0.clone();
    this.diags_p = crate::prelude::push(&this.diags_p, &lex_diag_f(&crate::syntax::Range { start_p: start_p1.clone(), end_p: crate::prelude::max(end_p2, start_p1) }, message_p3));
    this
}

/// ```prism
/// LexDiag: fn Range, Text -> Diag
/// ```
pub fn lex_diag_f(span_p0: &crate::syntax::Range, message_p1: &crate::prelude::Text) -> crate::syntax::Diag {
    crate::syntax::Diag { stage_p: crate::prelude::Text::lit("lex"), span_p: span_p0.clone(), message_p: message_p1.clone(), feature_o: ::std::option::Option::None }
}
