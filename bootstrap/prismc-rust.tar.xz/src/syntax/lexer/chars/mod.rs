//! The module `Syntax.Lexer.Chars`, from `target/bootstrap/src/prismc/syntax/lexer/chars.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// Dec: fn Nat -> Nat
/// ```
pub fn dec(n: &Nat) -> Nat {
    or(&n.checked_sub(&Nat::from(1u32)), &Nat::from(0u32))
}

/// ```prism
/// ?Last: fn [a] -> ?a
/// ```
pub fn last<A: Clone + 'static>(xs: &Array<A>) -> Option<A> {
    index(xs, &dec(&len(xs)))
}

/// ```prism
/// Pop: fn [a] -> [a]
/// ```
pub fn pop<A: Clone + 'static>(xs: &Array<A>) -> Array<A> {
    take(xs, &dec(&len(xs)))
}

/// ```prism
/// Join: fn [Text], Text -> Text
/// ```
pub fn join(xs: &Array<Text>, sep: &Text) -> Text {
    match index(xs, &Nat::from(0u32)) {
        Some(first_) => concat(&fold(&drop(xs, &Nat::from(1u32)), &Array::from(vec![first_.clone()]), &(|acc: &Array<Text>, x: &Text| push(&push(acc, sep), x)))),
        None => Text::lit(""),
    }
}

/// ```prism
/// CharAt: fn Cursor -> Text
/// ```
pub fn char_at(c: &Cursor) -> Text {
    match step(&front(&after(c))) {
        Some((_, one)) => before(&one),
        None => Text::lit(""),
    }
}

/// ```prism
/// Head: fn Text -> Text
/// ```
pub fn head(t: &Text) -> Text {
    char_at(&front(t))
}

/// ```prism
/// AfterFirst: fn Text -> Text
/// ```
pub fn after_first(t: &Text) -> Text {
    match step(&front(t)) {
        Some((_, c)) => after(&c),
        None => Text::lit(""),
    }
}

/// ```prism
/// LastChar: fn Text -> Text
/// ```
pub fn last_char(t: &Text) -> Text {
    match step_back(&back(t)) {
        Some((_, c)) => after(&c),
        None => Text::lit(""),
    }
}

/// ```prism
/// BeforeLast: fn Text -> Text
/// ```
pub fn before_last(t: &Text) -> Text {
    match step_back(&back(t)) {
        Some((_, c)) => before(&c),
        None => Text::lit(""),
    }
}

/// ```prism
/// Between: fn Text, Nat, Nat -> Text
/// ```
pub fn between(t: &Text, a: &Nat, b: &Nat) -> Text {
    match cursor_at(t, b) {
        Some(cb) => match cursor_at(&before(&cb), a) {
            Some(ca) => after(&ca),
            None => Text::lit(""),
        },
        None => Text::lit(""),
    }
}

/// ```prism
/// ?AfterPrefix: fn Text, Text -> ?Text
/// ```
pub fn after_prefix(t: &Text, p_: &Text) -> Option<Text> {
    match cursor_at(t, &len_text(p_)) {
        Some(c) => if &before(&c) == p_ { Some(after(&c)) } else { None },
        None => None,
    }
}

/// ```prism
/// HasPrefix: fn Text, Text -> Bool
/// ```
pub fn has_prefix(t: &Text, p_: &Text) -> bool {
    &after_prefix(t, p_) != &None
}

/// ```prism
/// DropPrefix: fn Text, Text -> Text
/// ```
pub fn drop_prefix(t: &Text, p_: &Text) -> Text {
    or(&after_prefix(t, p_), t)
}

/// ```prism
/// ?BeforeSuffix: fn Text, Text -> ?Text
/// ```
pub fn before_suffix(t: &Text, s: &Text) -> Option<Text> {
    match (&len_text(t)).checked_sub(&len_text(s)) {
        Some(n) => match cursor_at(t, &n) {
            Some(c) => if &after(&c) == s { Some(before(&c)) } else { None },
            None => None,
        },
        None => None,
    }
}

/// ```prism
/// HasSuffix: fn Text, Text -> Bool
/// ```
pub fn has_suffix(t: &Text, s: &Text) -> bool {
    &before_suffix(t, s) != &None
}

/// ```prism
/// FoldChars: fn Text, b, (fn b, Text -> b) -> b
/// ```
pub fn fold_chars<B: Clone + 'static>(t: &Text, z: &B, f_fn: &Rc<dyn Fn((B, Text)) -> Rc<dyn prism_rtl::Job<B>>>) -> B {
    let mut this: B = z.clone();
    let mut c: Cursor = front(t);
    while let Some((_, next)) = step(&c) {
        this = run_to_end(f_fn((this.clone(), char_at(&c))));
        c = next.clone();
    }
    this
}

/// The step machine of `FoldChars`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FoldChars: fn Text, b, (fn b, Text -> b) -> b
/// ```
pub struct FoldChars<B> {
    pub t: Text,
    pub z: B,
    pub f_fn: Rc<dyn Fn((B, Text)) -> Rc<dyn prism_rtl::Job<B>>>,
}

impl<B: Clone + 'static> prism_rtl::Job<B> for FoldChars<B> {
    fn cycle(&self) -> prism_rtl::Turn<B> {
        let t = &self.t;
        let z = &self.z;
        let f_fn = &self.f_fn;
        prism_rtl::Turn::Finished({
            let mut this: B = z.clone();
            let mut c: Cursor = front(t);
            while let Some((_, next)) = step(&c) {
                this = run_to_end(f_fn((this.clone(), char_at(&c))));
                c = next.clone();
            }
            this
        })
    }
}

/// `Start FoldChars, x`: what the function value is when passed to `@Run`.
pub fn start_fold_chars<B: Clone + 'static>(t: Text, z: B, f_fn: Rc<dyn Fn((B, Text)) -> Rc<dyn prism_rtl::Job<B>>>) -> Rc<dyn prism_rtl::Job<B>> {
    Rc::new(FoldChars { t, z, f_fn })
}

/// ```prism
/// MapChars: fn Text, (fn Text -> Text) -> Text
/// ```
pub fn map_chars(t: &Text, f_fn: &Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>) -> Text {
    concat(&fold_chars(t, &Array::new(), &{
        let f_fn = f_fn.clone();
        Rc::new(move |(p0, p1): (Array<Text>, Text)| {
            let f_fn = f_fn.clone();
            entered(once_job(move || {
                let acc = p0;
                let c = p1;
                call_value((&f_fn)(c.clone()), move |f_3224: Text| prism_rtl::Turn::Finished(push(&acc, &f_3224)))
            }))
        }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// ```prism
/// CountChars: fn Text -> Nat
/// ```
pub fn count_chars(t: &Text) -> Nat {
    fold_chars(t, &Nat::from(0u32), &(Rc::new(move |(p0, p1): (Nat, Text)| once_job(move || {
        let n = p0;
        let _ = p1;
        prism_rtl::Turn::Finished(&n + &Nat::from(1u32))
    })) as Rc<dyn Fn((Nat, Text)) -> Rc<dyn prism_rtl::Job<Nat>>>))
}

/// ```prism
/// ColumnOf: fn Text, Nat, Nat -> Nat
/// ```
pub fn column_of(text: &Text, from: &Nat, offset: &Nat) -> Nat {
    count_chars(&between(text, from, offset))
}

/// ```prism
/// AllChars: fn Text, (fn Text -> Bool) -> Bool
/// ```
pub fn all_chars(t: &Text, p__fn: &Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>) -> bool {
    fold_chars(t, &true, &{
        let p__fn = p__fn.clone();
        Rc::new(move |(p0, p1): (bool, Text)| {
            let p__fn = p__fn.clone();
            entered(once_job(move || {
                let ok = p0;
                let c = p1;
                prism_rtl::Turn::Finished(ok && run_to_end((&p__fn)(c.clone())))
            }))
        }) as Rc<dyn Fn((bool, Text)) -> Rc<dyn prism_rtl::Job<bool>>>
    })
}

/// ```prism
/// TrimLeading: fn Text, Text -> Text
/// ```
pub fn trim_leading(t: &Text, set: &Text) -> Text {
    let c = {
        let mut this: Cursor = front(t);
        while let Some((_, next)) = step(&this) {
            if !contains(set, &char_at(&this)) {
                break;
            }
            this = next.clone();
        }
        this
    };
    after(&c)
}

/// ```prism
/// TrimTrailing: fn Text, Text -> Text
/// ```
pub fn trim_trailing(t: &Text, set: &Text) -> Text {
    let c = {
        let mut this: Cursor = back(t);
        let mut fuel: Nat = len_text(t);
        while let Some(left) = (&fuel).checked_sub(&Nat::from(1u32)) {
            fuel = left.clone();
            match &step_back(&this) {
                Some((_, prev)) if contains(set, &char_at(prev)) => {
                    this = prev.clone();
                    ()
                },
                _ => {
                    fuel = Nat::from(0u32);
                    ()
                },
                _ => unreachable!("no arm matched"),
            };
        }
        this
    };
    before(&c)
}

/// ```prism
/// TrimStart: fn Text -> Text
/// ```
pub fn trim_start(t: &Text) -> Text {
    trim_leading(t, &Text::lit(" \r"))
}

/// ```prism
/// TrimEnd: fn Text -> Text
/// ```
pub fn trim_end(t: &Text) -> Text {
    trim_trailing(t, &Text::lit(" \r"))
}

/// ```prism
/// Trim: fn Text -> Text
/// ```
pub fn trim(t: &Text) -> Text {
    trim_end(&trim_start(t))
}

/// ```prism
/// LeadingIn: fn Text, Text -> Nat
/// ```
pub fn leading_in(t: &Text, set: &Text) -> Nat {
    or(&(&len_text(t)).checked_sub(&len_text(&trim_leading(t, set))), &Nat::from(0u32))
}

/// ```prism
/// Contains: fn Text, Text -> Bool
/// ```
pub fn contains(set: &Text, c: &Text) -> bool {
    (c != &Text::lit("")) && (&len(&split_on(set, c)) > &Nat::from(1u32))
}

/// ```prism
/// IsDigit: fn Text -> Bool
/// ```
pub fn is_digit(c: &Text) -> bool {
    (&Text::lit("0") <= c) && (c <= &Text::lit("9"))
}

/// ```prism
/// IsUpper: fn Text -> Bool
/// ```
pub fn is_upper(c: &Text) -> bool {
    (&Text::lit("A") <= c) && (c <= &Text::lit("Z"))
}

/// ```prism
/// IsLower: fn Text -> Bool
/// ```
pub fn is_lower(c: &Text) -> bool {
    (&Text::lit("a") <= c) && (c <= &Text::lit("z"))
}

/// ```prism
/// IsIdentStart: fn Text -> Bool
/// ```
pub fn is_ident_start(c: &Text) -> bool {
    (is_lower(c) || is_upper(c)) || (c == &Text::lit("_"))
}

/// ```prism
/// IsIdentChar: fn Text -> Bool
/// ```
pub fn is_ident_char(c: &Text) -> bool {
    is_ident_start(c) || is_digit(c)
}

/// ```prism
/// IsHexDigit: fn Text -> Bool
/// ```
pub fn is_hex_digit(c: &Text) -> bool {
    (is_digit(c) || ((&Text::lit("a") <= c) && (c <= &Text::lit("f")))) || ((&Text::lit("A") <= c) && (c <= &Text::lit("F")))
}

/// ```prism
/// IsNonAscii: fn Text -> Bool
/// ```
pub fn is_non_ascii(c: &Text) -> bool {
    c > &Text::lit("")
}

/// ```prism
/// IsSigilChar: fn Text -> Bool
/// ```
pub fn is_sigil_char(c: &Text) -> bool {
    contains(&Text::lit("$!@?~&"), c)
}

/// ```prism
/// IsSpaceChar: fn Text -> Bool
/// ```
pub fn is_space_char(c: &Text) -> bool {
    (((c == &Text::lit(" ")) || (c == &Text::lit("\n"))) || (c == &Text::lit("\r"))) || (c == &Text::lit("\t"))
}

/// ```prism
/// IsReservedCtor: fn Text -> Bool
/// ```
pub fn is_reserved_ctor(w: &Text) -> bool {
    (w == &Text::lit("templatetext")) || (w == &Text::lit("templateplaceholder"))
}

/// ```prism
/// let asciiText
/// ```
pub fn ascii_text() -> Text {
    Text::lit("\0\t\n\r !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")
}

/// ```prism
/// let hexDigits
/// ```
pub fn hex_digits() -> Text {
    Text::lit("0123456789abcdef")
}

/// ```prism
/// CharAtByte: fn Text, Nat -> Text
/// ```
pub fn char_at_byte(t: &Text, n: &Nat) -> Text {
    match cursor_at(t, n) {
        Some(c) => char_at(&c),
        None => Text::lit(""),
    }
}

/// ```prism
/// HexValue: fn Text -> Nat
/// ```
pub fn hex_value(c: &Text) -> Nat {
    let l = crate::prelude::lower(c);
    if &l == &Text::lit("") {
        Nat::from(16u32)
    } else {
        len_text(&or(&index(&split_on(&hex_digits(), &l), &Nat::from(0u32)), &hex_digits()))
    }
}

/// ```prism
/// ?ParseHex: fn Text -> ?Nat
/// ```
pub fn parse_hex(t: &Text) -> Option<Nat> {
    'g7309: {
        if !((t != &Text::lit("")) && all_chars(t, &{
            let f = Rc::new(is_hex_digit);
            Rc::new(move |a0: Text| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
        })) {
            break 'g7309 None;
        }
        Some(fold_chars(t, &Nat::from(0u32), &(Rc::new(move |(p0, p1): (Nat, Text)| once_job(move || {
            let n = p0;
            let c = p1;
            prism_rtl::Turn::Finished(&(&n * &Nat::from(16u32)) + &hex_value(&c))
        })) as Rc<dyn Fn((Nat, Text)) -> Rc<dyn prism_rtl::Job<Nat>>>)))
    }
}

/// ```prism
/// ?AsciiChar: fn Nat -> ?Text
/// ```
pub fn ascii_char(n: &Nat) -> Option<Text> {
    if n < &Nat::from(128u32) { Some(char_at_byte(&ascii_text(), n)) } else { None }
}

/// ```prism
/// Rest: fn Lex -> Text
/// ```
pub fn rest(l: &crate::syntax::lexer::Lex) -> Text {
    match cursor_at(&l.src, &l.pos) {
        Some(c) => after(&c),
        None => Text::lit(""),
    }
}

/// ```prism
/// Peek: fn Lex -> Text
/// ```
pub fn peek(l: &crate::syntax::lexer::Lex) -> Text {
    char_at_byte(&l.src, &l.pos)
}

/// ```prism
/// PeekAt: fn Lex, Nat -> Text
/// ```
pub fn peek_at(l: &crate::syntax::lexer::Lex, n: &Nat) -> Text {
    let rest_ = {
        let mut this: Text = rest(l);
        let mut k: Nat = n.clone();
        while let Some(left) = (&k).checked_sub(&Nat::from(1u32)) {
            k = left.clone();
            this = after_first(&this);
        }
        this
    };
    head(&rest_)
}

/// ```prism
/// StartsWith: fn Lex, Text -> Bool
/// ```
pub fn starts_with(l: &crate::syntax::lexer::Lex, s: &Text) -> bool {
    has_prefix(&rest(l), s)
}

/// ```prism
/// Slice: fn Lex, Nat, Nat -> Text
/// ```
pub fn slice(l: &crate::syntax::lexer::Lex, a: &Nat, b: &Nat) -> Text {
    between(&l.src, a, b)
}

/// ```prism
/// Bump: fn Lex -> Lex
/// ```
pub fn bump(l: &crate::syntax::lexer::Lex) -> crate::syntax::lexer::Lex {
    let mut this: crate::syntax::lexer::Lex = l.clone();
    this.pos = &this.pos + &len_text(&peek(&this));
    this
}

/// ```prism
/// Forward: fn Lex, Nat -> Lex
/// ```
pub fn forward(l: &crate::syntax::lexer::Lex, n: &Nat) -> crate::syntax::lexer::Lex {
    let mut this: crate::syntax::lexer::Lex = l.clone();
    let mut k: Nat = n.clone();
    while let Some(left) = (&k).checked_sub(&Nat::from(1u32)) {
        k = left.clone();
        this.pos = &this.pos + &len_text(&peek(&this));
    }
    this
}

/// ```prism
/// NextIsSpace: fn Lex, Nat -> Bool
/// ```
pub fn next_is_space(l: &crate::syntax::lexer::Lex, n: &Nat) -> bool {
    let c = peek_at(l, n);
    (&c == &Text::lit("")) || is_space_char(&c)
}

/// ```prism
/// LineEnd: fn Lex -> Nat
/// ```
pub fn line_end(l: &crate::syntax::lexer::Lex) -> Nat {
    match cursor_at(&l.src, &l.pos) {
        Some(c) => {
            let end = {
                let mut this: Cursor = c.clone();
                while let Some((ch, next)) = step(&this) {
                    if !(&ch != &'\n') {
                        break;
                    }
                    this = next.clone();
                }
                this
            };
            at(&end)
        },
        None => l.pos.clone(),
    }
}

/// ```prism
/// RestOfLine: unbounded fn Lex -> Text
/// ```
pub fn rest_of_line(l: &crate::syntax::lexer::Lex) -> Text {
    slice(l, &l.pos, &line_end(l))
}

/// The step machine of `RestOfLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RestOfLine: unbounded fn Lex -> Text
/// ```
pub struct RestOfLine {
    pub l: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<Text> for RestOfLine {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let l = &self.l;
        prism_rtl::Turn::Finished(slice(l, &l.pos, &line_end(l)))
    }
}

/// `Start RestOfLine, x`: what the function value is when passed to `@Run`.
pub fn start_rest_of_line(l: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RestOfLine { l })
}

/// ```prism
/// LexErr: fn Lex, Nat, Nat, Text -> Lex
/// ```
pub fn lex_err(l: &crate::syntax::lexer::Lex, start: &Nat, end: &Nat, message: &Text) -> crate::syntax::lexer::Lex {
    let mut this: crate::syntax::lexer::Lex = l.clone();
    this.diags = push(&this.diags, &lex_diag(&crate::syntax::Range { start: start.clone(), end: max(end, start) }, message));
    this
}

/// ```prism
/// LexDiag: fn Range, Text -> Diag
/// ```
pub fn lex_diag(span: &crate::syntax::Range, message: &Text) -> crate::syntax::Diag {
    crate::syntax::Diag { stage: Text::lit("lex"), span: span.clone(), message: message.clone(), feature: None }
}
