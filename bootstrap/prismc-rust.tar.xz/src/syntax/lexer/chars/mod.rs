//! The module `Syntax.Lexer.Chars`, from `target/bootstrap/src/prismc/syntax/lexer/chars.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// Dec: fn Nat -> Nat
/// ```
pub fn dec_f(n_p0: &Nat) -> Nat {
    crate::prelude::or(&n_p0.checked_sub(&Nat::from(1u32)), &Nat::from(0u32))
}

/// ```prism
/// ?Last: fn [a] -> ?a
/// ```
pub fn last_o<A: Clone + 'static>(xs_p0: &Array<A>) -> Option<A> {
    crate::prelude::index(xs_p0, &dec_f(&crate::prelude::len(xs_p0)))
}

/// ```prism
/// Pop: fn [a] -> [a]
/// ```
pub fn pop_f<A: Clone + 'static>(xs_p0: &Array<A>) -> Array<A> {
    crate::prelude::take(xs_p0, &dec_f(&crate::prelude::len(xs_p0)))
}

/// ```prism
/// Join: fn [Text], Text -> Text
/// ```
pub fn join_f(xs_p0: &Array<Text>, sep_p1: &Text) -> Text {
    match crate::prelude::index(xs_p0, &Nat::from(0u32)) {
        Some(first_p2) => crate::prelude::concat(&crate::prelude::fold(&crate::prelude::drop(xs_p0, &Nat::from(1u32)), &Array::from(vec![first_p2.clone()]), &(|acc_p3: &Array<Text>, x_p4: &Text| crate::prelude::push(&crate::prelude::push(acc_p3, sep_p1), x_p4)))),
        None => Text::lit(""),
    }
}

/// ```prism
/// CharAt: fn Cursor -> Text
/// ```
pub fn char_at_f(c_p0: &Cursor) -> Text {
    match crate::prelude::step(&crate::prelude::front(&crate::prelude::after(c_p0))) {
        Some((_, one_p1)) => crate::prelude::before(&one_p1),
        None => Text::lit(""),
    }
}

/// ```prism
/// Head: fn Text -> Text
/// ```
pub fn head_f(t_p0: &Text) -> Text {
    char_at_f(&crate::prelude::front(t_p0))
}

/// ```prism
/// AfterFirst: fn Text -> Text
/// ```
pub fn after_first_f(t_p0: &Text) -> Text {
    match crate::prelude::step(&crate::prelude::front(t_p0)) {
        Some((_, c_p1)) => crate::prelude::after(&c_p1),
        None => Text::lit(""),
    }
}

/// ```prism
/// LastChar: fn Text -> Text
/// ```
pub fn last_char_f(t_p0: &Text) -> Text {
    match crate::prelude::step_back(&crate::prelude::back(t_p0)) {
        Some((_, c_p1)) => crate::prelude::after(&c_p1),
        None => Text::lit(""),
    }
}

/// ```prism
/// BeforeLast: fn Text -> Text
/// ```
pub fn before_last_f(t_p0: &Text) -> Text {
    match crate::prelude::step_back(&crate::prelude::back(t_p0)) {
        Some((_, c_p1)) => crate::prelude::before(&c_p1),
        None => Text::lit(""),
    }
}

/// ```prism
/// Between: fn Text, Nat, Nat -> Text
/// ```
pub fn between_f(t_p0: &Text, a_p1: &Nat, b_p2: &Nat) -> Text {
    match crate::prelude::cursor_at(t_p0, b_p2) {
        Some(cb_p3) => match crate::prelude::cursor_at(&crate::prelude::before(&cb_p3), a_p1) {
            Some(ca_p4) => crate::prelude::after(&ca_p4),
            None => Text::lit(""),
        },
        None => Text::lit(""),
    }
}

/// ```prism
/// ?AfterPrefix: fn Text, Text -> ?Text
/// ```
pub fn after_prefix_o(t_p0: &Text, p_p1: &Text) -> Option<Text> {
    match crate::prelude::cursor_at(t_p0, &crate::prelude::len_text(p_p1)) {
        Some(c_p2) => if &crate::prelude::before(&c_p2) == p_p1 {
            Some(crate::prelude::after(&c_p2))
        } else {
            None
        },
        None => None,
    }
}

/// ```prism
/// HasPrefix: fn Text, Text -> Bool
/// ```
pub fn has_prefix_f(t_p0: &Text, p_p1: &Text) -> bool {
    &after_prefix_o(t_p0, p_p1) != &None
}

/// ```prism
/// DropPrefix: fn Text, Text -> Text
/// ```
pub fn drop_prefix_f(t_p0: &Text, p_p1: &Text) -> Text {
    crate::prelude::or(&after_prefix_o(t_p0, p_p1), t_p0)
}

/// ```prism
/// ?BeforeSuffix: fn Text, Text -> ?Text
/// ```
pub fn before_suffix_o(t_p0: &Text, s_p1: &Text) -> Option<Text> {
    match (&crate::prelude::len_text(t_p0)).checked_sub(&crate::prelude::len_text(s_p1)) {
        Some(n_p2) => match crate::prelude::cursor_at(t_p0, &n_p2) {
            Some(c_p3) => if &crate::prelude::after(&c_p3) == s_p1 {
                Some(crate::prelude::before(&c_p3))
            } else {
                None
            },
            None => None,
        },
        None => None,
    }
}

/// ```prism
/// HasSuffix: fn Text, Text -> Bool
/// ```
pub fn has_suffix_f(t_p0: &Text, s_p1: &Text) -> bool {
    &before_suffix_o(t_p0, s_p1) != &None
}

/// ```prism
/// FoldChars: fn Text, b, (fn b, Text -> b) -> b
/// ```
pub fn fold_chars_f<B: Clone + 'static>(t_p0: &Text, z_p1: &B, f_f2: &Rc<dyn Fn((B, Text)) -> Rc<dyn prism_rtl::Job<B>>>) -> B {
    let mut this: B = z_p1.clone();
    let mut c_p3: Cursor = crate::prelude::front(t_p0);
    while let Some((_, next_p4)) = crate::prelude::step(&c_p3) {
        this = crate::prelude::run_to_end(f_f2((this.clone(), char_at_f(&c_p3))));
        c_p3 = next_p4.clone();
    }
    this
}

/// The step machine of `FoldChars`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FoldChars: fn Text, b, (fn b, Text -> b) -> b
/// ```
pub struct FoldChars<B> {
    pub t_p0: Text,
    pub z_p1: B,
    pub f_f2: Rc<dyn Fn((B, Text)) -> Rc<dyn prism_rtl::Job<B>>>,
}

impl<B: Clone + 'static> prism_rtl::Job<B> for FoldChars<B> {
    fn cycle(&self) -> prism_rtl::Turn<B> {
        let t_p0 = &self.t_p0;
        let z_p1 = &self.z_p1;
        let f_f2 = &self.f_f2;
        prism_rtl::Turn::Finished({
            let mut this: B = z_p1.clone();
            let mut c_p3: Cursor = crate::prelude::front(t_p0);
            while let Some((_, next_p4)) = crate::prelude::step(&c_p3) {
                this = crate::prelude::run_to_end(f_f2((this.clone(), char_at_f(&c_p3))));
                c_p3 = next_p4.clone();
            }
            this
        })
    }
}

/// `Start FoldChars, x`: what the function value is when passed to `@Run`.
pub fn start_fold_chars_f<B: Clone + 'static>(t_p0: Text, z_p1: B, f_f2: Rc<dyn Fn((B, Text)) -> Rc<dyn prism_rtl::Job<B>>>) -> Rc<dyn prism_rtl::Job<B>> {
    Rc::new(FoldChars { t_p0, z_p1, f_f2 })
}

/// ```prism
/// MapChars: fn Text, (fn Text -> Text) -> Text
/// ```
pub fn map_chars_f(t_p0: &Text, f_f1: &Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>) -> Text {
    crate::prelude::concat(&fold_chars_f(t_p0, &Array::new(), &{
        let f_f1x = f_f1.clone();
        Rc::new(move |(p0, p1): (Array<Text>, Text)| {
            let f_f1xy = f_f1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p2 = p0;
                let c_p3 = p1;
                crate::prelude::call_value((&f_f1xy)(c_p3.clone()), move |f_3224: Text| prism_rtl::Turn::Finished(crate::prelude::push(&acc_p2, &f_3224)))
            }))
        }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// ```prism
/// CountChars: fn Text -> Nat
/// ```
pub fn count_chars_f(t_p0: &Text) -> Nat {
    fold_chars_f(t_p0, &Nat::from(0u32), &(Rc::new(move |(p0, p1): (Nat, Text)| crate::prelude::once_job(move || {
        let n_p1 = p0;
        let _ = p1;
        prism_rtl::Turn::Finished(&n_p1 + &Nat::from(1u32))
    })) as Rc<dyn Fn((Nat, Text)) -> Rc<dyn prism_rtl::Job<Nat>>>))
}

/// ```prism
/// ColumnOf: fn Text, Nat, Nat -> Nat
/// ```
pub fn column_of_f(text_p0: &Text, from_p1: &Nat, offset_p2: &Nat) -> Nat {
    count_chars_f(&between_f(text_p0, from_p1, offset_p2))
}

/// ```prism
/// AllChars: fn Text, (fn Text -> Bool) -> Bool
/// ```
pub fn all_chars_f(t_p0: &Text, p_f1: &Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>) -> bool {
    fold_chars_f(t_p0, &true, &{
        let p_f1x = p_f1.clone();
        Rc::new(move |(p0, p1): (bool, Text)| {
            let p_f1xy = p_f1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let ok_p2 = p0;
                let c_p3 = p1;
                prism_rtl::Turn::Finished(ok_p2 && crate::prelude::run_to_end((&p_f1xy)(c_p3.clone())))
            }))
        }) as Rc<dyn Fn((bool, Text)) -> Rc<dyn prism_rtl::Job<bool>>>
    })
}

/// ```prism
/// TrimLeading: fn Text, Text -> Text
/// ```
pub fn trim_leading_f(t_p0: &Text, set_p1: &Text) -> Text {
    let c_p2 = {
        let mut this: Cursor = crate::prelude::front(t_p0);
        while let Some((_, next_p3)) = crate::prelude::step(&this) {
            if !contains_f(set_p1, &char_at_f(&this)) {
                break;
            }
            this = next_p3.clone();
        }
        this
    };
    crate::prelude::after(&c_p2)
}

/// ```prism
/// TrimTrailing: fn Text, Text -> Text
/// ```
pub fn trim_trailing_f(t_p0: &Text, set_p1: &Text) -> Text {
    let c_p2 = {
        let mut this: Cursor = crate::prelude::back(t_p0);
        let mut fuel_p3: Nat = crate::prelude::len_text(t_p0);
        while let Some(left_p4) = (&fuel_p3).checked_sub(&Nat::from(1u32)) {
            fuel_p3 = left_p4.clone();
            match &crate::prelude::step_back(&this) {
                Some((_, prev_p5)) if contains_f(set_p1, &char_at_f(prev_p5)) => {
                    this = prev_p5.clone();
                    ()
                },
                _ => {
                    fuel_p3 = Nat::from(0u32);
                    ()
                },
                _ => unreachable!("no arm matched"),
            };
        }
        this
    };
    crate::prelude::before(&c_p2)
}

/// ```prism
/// TrimStart: fn Text -> Text
/// ```
pub fn trim_start_f(t_p0: &Text) -> Text {
    trim_leading_f(t_p0, &Text::lit(" \r"))
}

/// ```prism
/// TrimEnd: fn Text -> Text
/// ```
pub fn trim_end_f(t_p0: &Text) -> Text {
    trim_trailing_f(t_p0, &Text::lit(" \r"))
}

/// ```prism
/// Trim: fn Text -> Text
/// ```
pub fn trim_f(t_p0: &Text) -> Text {
    trim_end_f(&trim_start_f(t_p0))
}

/// ```prism
/// LeadingIn: fn Text, Text -> Nat
/// ```
pub fn leading_in_f(t_p0: &Text, set_p1: &Text) -> Nat {
    crate::prelude::or(&(&crate::prelude::len_text(t_p0)).checked_sub(&crate::prelude::len_text(&trim_leading_f(t_p0, set_p1))), &Nat::from(0u32))
}

/// ```prism
/// Contains: fn Text, Text -> Bool
/// ```
pub fn contains_f(set_p0: &Text, c_p1: &Text) -> bool {
    (c_p1 != &Text::lit("")) && (&crate::prelude::len(&crate::prelude::split_on(set_p0, c_p1)) > &Nat::from(1u32))
}

/// ```prism
/// IsDigit: fn Text -> Bool
/// ```
pub fn is_digit_f(c_p0: &Text) -> bool {
    (&Text::lit("0") <= c_p0) && (c_p0 <= &Text::lit("9"))
}

/// ```prism
/// IsUpper: fn Text -> Bool
/// ```
pub fn is_upper_f(c_p0: &Text) -> bool {
    (&Text::lit("A") <= c_p0) && (c_p0 <= &Text::lit("Z"))
}

/// ```prism
/// IsLower: fn Text -> Bool
/// ```
pub fn is_lower_f(c_p0: &Text) -> bool {
    (&Text::lit("a") <= c_p0) && (c_p0 <= &Text::lit("z"))
}

/// ```prism
/// IsIdentStart: fn Text -> Bool
/// ```
pub fn is_ident_start_f(c_p0: &Text) -> bool {
    (is_lower_f(c_p0) || is_upper_f(c_p0)) || (c_p0 == &Text::lit("_"))
}

/// ```prism
/// IsIdentChar: fn Text -> Bool
/// ```
pub fn is_ident_char_f(c_p0: &Text) -> bool {
    is_ident_start_f(c_p0) || is_digit_f(c_p0)
}

/// ```prism
/// IsHexDigit: fn Text -> Bool
/// ```
pub fn is_hex_digit_f(c_p0: &Text) -> bool {
    (is_digit_f(c_p0) || ((&Text::lit("a") <= c_p0) && (c_p0 <= &Text::lit("f")))) || ((&Text::lit("A") <= c_p0) && (c_p0 <= &Text::lit("F")))
}

/// ```prism
/// IsNonAscii: fn Text -> Bool
/// ```
pub fn is_non_ascii_f(c_p0: &Text) -> bool {
    c_p0 > &Text::lit("")
}

/// ```prism
/// IsSigilChar: fn Text -> Bool
/// ```
pub fn is_sigil_char_f(c_p0: &Text) -> bool {
    contains_f(&Text::lit("$!@?~&"), c_p0)
}

/// ```prism
/// IsSpaceChar: fn Text -> Bool
/// ```
pub fn is_space_char_f(c_p0: &Text) -> bool {
    (((c_p0 == &Text::lit(" ")) || (c_p0 == &Text::lit("\n"))) || (c_p0 == &Text::lit("\r"))) || (c_p0 == &Text::lit("\t"))
}

/// ```prism
/// IsReservedCtor: fn Text -> Bool
/// ```
pub fn is_reserved_ctor_f(w_p0: &Text) -> bool {
    (w_p0 == &Text::lit("templatetext")) || (w_p0 == &Text::lit("templateplaceholder"))
}

/// ```prism
/// let asciiText
/// ```
pub fn ascii_text_p() -> Text {
    Text::lit("\0\t\n\r !\"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")
}

/// ```prism
/// let hexDigits
/// ```
pub fn hex_digits_p() -> Text {
    Text::lit("0123456789abcdef")
}

/// ```prism
/// CharAtByte: fn Text, Nat -> Text
/// ```
pub fn char_at_byte_f(t_p0: &Text, n_p1: &Nat) -> Text {
    match crate::prelude::cursor_at(t_p0, n_p1) {
        Some(c_p2) => char_at_f(&c_p2),
        None => Text::lit(""),
    }
}

/// ```prism
/// HexValue: fn Text -> Nat
/// ```
pub fn hex_value_f(c_p0: &Text) -> Nat {
    let l_p1 = crate::prelude::lower(c_p0);
    if &l_p1 == &Text::lit("") {
        Nat::from(16u32)
    } else {
        crate::prelude::len_text(&crate::prelude::or(&crate::prelude::index(&crate::prelude::split_on(&hex_digits_p(), &l_p1), &Nat::from(0u32)), &hex_digits_p()))
    }
}

/// ```prism
/// ?ParseHex: fn Text -> ?Nat
/// ```
pub fn parse_hex_o(t_p0: &Text) -> Option<Nat> {
    'g7251: {
        if !((t_p0 != &Text::lit("")) && all_chars_f(t_p0, &{
            let f = Rc::new(is_hex_digit_f);
            Rc::new(move |a0: Text| {
                let fy = f.clone();
                crate::prelude::once_job(move || prism_rtl::Turn::Finished(fy(&a0)))
            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
        })) {
            break 'g7251 None;
        }
        Some(fold_chars_f(t_p0, &Nat::from(0u32), &(Rc::new(move |(p0, p1): (Nat, Text)| crate::prelude::once_job(move || {
            let n_p1 = p0;
            let c_p2 = p1;
            prism_rtl::Turn::Finished(&(&n_p1 * &Nat::from(16u32)) + &hex_value_f(&c_p2))
        })) as Rc<dyn Fn((Nat, Text)) -> Rc<dyn prism_rtl::Job<Nat>>>)))
    }
}

/// ```prism
/// Rest: fn Lex -> Text
/// ```
pub fn rest_f(l_p0: &crate::syntax::lexer::Lex) -> Text {
    match crate::prelude::cursor_at(&l_p0.src_p, &l_p0.pos_p) {
        Some(c_p1) => crate::prelude::after(&c_p1),
        None => Text::lit(""),
    }
}

/// ```prism
/// Peek: fn Lex -> Text
/// ```
pub fn peek_f(l_p0: &crate::syntax::lexer::Lex) -> Text {
    char_at_byte_f(&l_p0.src_p, &l_p0.pos_p)
}

/// ```prism
/// PeekAt: fn Lex, Nat -> Text
/// ```
pub fn peek_at_f(l_p0: &crate::syntax::lexer::Lex, n_p1: &Nat) -> Text {
    let rest_p2 = {
        let mut this: Text = rest_f(l_p0);
        let mut k_p3: Nat = n_p1.clone();
        while let Some(left_p4) = (&k_p3).checked_sub(&Nat::from(1u32)) {
            k_p3 = left_p4.clone();
            this = after_first_f(&this);
        }
        this
    };
    head_f(&rest_p2)
}

/// ```prism
/// StartsWith: fn Lex, Text -> Bool
/// ```
pub fn starts_with_f(l_p0: &crate::syntax::lexer::Lex, s_p1: &Text) -> bool {
    has_prefix_f(&rest_f(l_p0), s_p1)
}

/// ```prism
/// Slice: fn Lex, Nat, Nat -> Text
/// ```
pub fn slice_f(l_p0: &crate::syntax::lexer::Lex, a_p1: &Nat, b_p2: &Nat) -> Text {
    between_f(&l_p0.src_p, a_p1, b_p2)
}

/// ```prism
/// Bump: fn Lex -> Lex
/// ```
pub fn bump_f(l_p0: &crate::syntax::lexer::Lex) -> crate::syntax::lexer::Lex {
    let mut this: crate::syntax::lexer::Lex = l_p0.clone();
    this.pos_p = &this.pos_p + &crate::prelude::len_text(&peek_f(&this));
    this
}

/// ```prism
/// Forward: fn Lex, Nat -> Lex
/// ```
pub fn forward_f(l_p0: &crate::syntax::lexer::Lex, n_p1: &Nat) -> crate::syntax::lexer::Lex {
    let mut this: crate::syntax::lexer::Lex = l_p0.clone();
    let mut k_p2: Nat = n_p1.clone();
    while let Some(left_p3) = (&k_p2).checked_sub(&Nat::from(1u32)) {
        k_p2 = left_p3.clone();
        this.pos_p = &this.pos_p + &crate::prelude::len_text(&peek_f(&this));
    }
    this
}

/// ```prism
/// NextIsSpace: fn Lex, Nat -> Bool
/// ```
pub fn next_is_space_f(l_p0: &crate::syntax::lexer::Lex, n_p1: &Nat) -> bool {
    let c_p2 = peek_at_f(l_p0, n_p1);
    (&c_p2 == &Text::lit("")) || is_space_char_f(&c_p2)
}

/// ```prism
/// MatchEnd: fn Regex, Text, Nat -> Nat
/// ```
pub fn match_end_f(r_p0: &Regex, src_p1: &Text, at_p2: &Nat) -> Nat {
    match crate::prelude::cursor_at(src_p1, at_p2) {
        Some(c_p3) => match crate::prelude::match_(r_p0, &c_p3) {
            Some(m_p4) => crate::prelude::at(&m_p4.back_p),
            None => at_p2.clone(),
        },
        None => at_p2.clone(),
    }
}

/// ```prism
/// MatchHere: fn Regex, Lex -> Text
/// ```
pub fn match_here_f(r_p0: &Regex, l_p1: &crate::syntax::lexer::Lex) -> Text {
    between_f(&l_p1.src_p, &l_p1.pos_p, &match_end_f(r_p0, &l_p1.src_p, &l_p1.pos_p))
}

/// ```prism
/// LineEnd: fn Lex -> Nat
/// ```
pub fn line_end_f(l_p0: &crate::syntax::lexer::Lex) -> Nat {
    match_end_f(&{ thread_local!(static R: Regex = Regex::lit("[^\\n]*", "")); R.with(Regex::clone) }, &l_p0.src_p, &l_p0.pos_p)
}

/// ```prism
/// RestOfLine: unbounded fn Lex -> Text
/// ```
pub fn rest_of_line_f(l_p0: &crate::syntax::lexer::Lex) -> Text {
    slice_f(l_p0, &l_p0.pos_p, &line_end_f(l_p0))
}

/// The step machine of `RestOfLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RestOfLine: unbounded fn Lex -> Text
/// ```
pub struct RestOfLine {
    pub l_p0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<Text> for RestOfLine {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let l_p0 = &self.l_p0;
        prism_rtl::Turn::Finished(slice_f(l_p0, &l_p0.pos_p, &line_end_f(l_p0)))
    }
}

/// `Start RestOfLine, x`: what the function value is when passed to `@Run`.
pub fn start_rest_of_line_f(l_p0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RestOfLine { l_p0 })
}

/// ```prism
/// LexErr: fn Lex, Nat, Nat, Text -> Lex
/// ```
pub fn lex_err_f(l_p0: &crate::syntax::lexer::Lex, start_p1: &Nat, end_p2: &Nat, message_p3: &Text) -> crate::syntax::lexer::Lex {
    let mut this: crate::syntax::lexer::Lex = l_p0.clone();
    this.diags_p = crate::prelude::push(&this.diags_p, &lex_diag_f(&crate::syntax::Range { start_p: start_p1.clone(), end_p: crate::prelude::max(end_p2, start_p1) }, message_p3));
    this
}

/// ```prism
/// LexDiag: fn Range, Text -> Diag
/// ```
pub fn lex_diag_f(span_p0: &crate::syntax::Range, message_p1: &Text) -> crate::syntax::Diag {
    crate::syntax::Diag { stage_p: Text::lit("lex"), span_p: span_p0.clone(), message_p: message_p1.clone(), feature_o: None }
}
