//! The module `Syntax.Lexer.Templates`, from `target/bootstrap/src/prismc/syntax/lexer/templates.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `CallRead`:
///
/// ```prism
/// type CallRead = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CallRead {
    pub l: crate::syntax::lexer::Lex,
    pub attrs: Array<crate::syntax::lexer::AttrTok>,
    pub body: Option<Array<crate::syntax::lexer::TPartTok>>,
    pub going: bool,
}

impl Show for CallRead {
    fn show(&self, p: &mut Printer) {
        p.record("CallRead", &[("l", &self.l), ("attrs", &self.attrs), ("body", &self.body), ("going", &self.going)]);
    }
}

impl ToPod for CallRead {
    fn to_pod(&self) -> Pod {
        Pod::record("CallRead", vec![("l", self.l.to_pod()), ("attrs", self.attrs.to_pod()), ("body", self.body.to_pod()), ("going", self.going.to_pod())])
    }
}

impl FromPod for CallRead {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CallRead { l: FromPod::from_pod(field(p, "l")?)?, attrs: FromPod::from_pod(field(p, "attrs")?)?, body: FromPod::from_pod(field(p, "body")?)?, going: FromPod::from_pod(field(p, "going")?)? })
    }
}

/// `RawItem`:
///
/// ```prism
/// type RawItem = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum RawItem {
    RiText(Text),
    RiPlaceholder(Array<crate::syntax::lexer::Tok>, crate::syntax::Range),
    RiBlock(Array<crate::syntax::lexer::Tok>, crate::syntax::Range),
    RiCall(crate::syntax::lexer::NameTok, Array<crate::syntax::lexer::AttrTok>, Option<Array<crate::syntax::lexer::TPartTok>>, crate::syntax::Range),
}

impl Show for RawItem {
    fn show(&self, p: &mut Printer) {
        match self {
            RawItem::RiText(a0) => p.choice("RiText", &[a0]),
            RawItem::RiPlaceholder(a0, a1) => p.choice("RiPlaceholder", &[a0, a1]),
            RawItem::RiBlock(a0, a1) => p.choice("RiBlock", &[a0, a1]),
            RawItem::RiCall(a0, a1, a2, a3) => p.choice("RiCall", &[a0, a1, a2, a3]),
        }
    }
}

impl ToPod for RawItem {
    fn to_pod(&self) -> Pod {
        match self {
            RawItem::RiText(a0) => Pod::Choice("RiText".into(), vec![a0.to_pod()]),
            RawItem::RiPlaceholder(a0, a1) => Pod::Choice("RiPlaceholder".into(), vec![a0.to_pod(), a1.to_pod()]),
            RawItem::RiBlock(a0, a1) => Pod::Choice("RiBlock".into(), vec![a0.to_pod(), a1.to_pod()]),
            RawItem::RiCall(a0, a1, a2, a3) => Pod::Choice("RiCall".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
        }
    }
}

impl FromPod for RawItem {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "RiText" && a.len() == 1 => Ok(RawItem::RiText(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "RiPlaceholder" && a.len() == 2 => Ok(RawItem::RiPlaceholder(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "RiBlock" && a.len() == 2 => Ok(RawItem::RiBlock(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "RiCall" && a.len() == 4 => Ok(RawItem::RiCall(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?, FromPod::from_pod(&a[3])?)),
            other => mismatch("a RawItem", other),
        }
    }
}

/// `RawLine`:
///
/// ```prism
/// type RawLine = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct RawLine {
    pub items: Array<RawItem>,
    pub newline: bool,
    pub block: bool,
}

impl Show for RawLine {
    fn show(&self, p: &mut Printer) {
        p.record("RawLine", &[("items", &self.items), ("newline", &self.newline), ("block", &self.block)]);
    }
}

impl ToPod for RawLine {
    fn to_pod(&self) -> Pod {
        Pod::record("RawLine", vec![("items", self.items.to_pod()), ("newline", self.newline.to_pod()), ("block", self.block.to_pod())])
    }
}

impl FromPod for RawLine {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(RawLine { items: FromPod::from_pod(field(p, "items")?)?, newline: FromPod::from_pod(field(p, "newline")?)?, block: FromPod::from_pod(field(p, "block")?)? })
    }
}

/// `TplHow`:
///
/// ```prism
/// type TplHow = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TplHow {
    pub close: Text,
    pub delims: Text,
    pub open: Text,
    pub is_raw: bool,
    pub first_continues: bool,
}

impl Show for TplHow {
    fn show(&self, p: &mut Printer) {
        p.record("TplHow", &[("close", &self.close), ("delims", &self.delims), ("open", &self.open), ("is_raw", &self.is_raw), ("first_continues", &self.first_continues)]);
    }
}

impl ToPod for TplHow {
    fn to_pod(&self) -> Pod {
        Pod::record("TplHow", vec![("close", self.close.to_pod()), ("delims", self.delims.to_pod()), ("open", self.open.to_pod()), ("is_raw", self.is_raw.to_pod()), ("first_continues", self.first_continues.to_pod())])
    }
}

impl FromPod for TplHow {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TplHow { close: FromPod::from_pod(field(p, "close")?)?, delims: FromPod::from_pod(field(p, "delims")?)?, open: FromPod::from_pod(field(p, "open")?)?, is_raw: FromPod::from_pod(field(p, "is_raw")?)?, first_continues: FromPod::from_pod(field(p, "first_continues")?)? })
    }
}

/// `TplRead`:
///
/// ```prism
/// type TplRead = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TplRead {
    pub l: crate::syntax::lexer::Lex,
    pub lines: Array<RawLine>,
    pub cur: RawLine,
    pub closing_col: Option<Nat>,
    pub closed: bool,
    pub at_line_start: bool,
    pub going: bool,
}

impl Show for TplRead {
    fn show(&self, p: &mut Printer) {
        p.record("TplRead", &[("l", &self.l), ("lines", &self.lines), ("cur", &self.cur), ("closing_col", &self.closing_col), ("closed", &self.closed), ("at_line_start", &self.at_line_start), ("going", &self.going)]);
    }
}

impl ToPod for TplRead {
    fn to_pod(&self) -> Pod {
        Pod::record("TplRead", vec![("l", self.l.to_pod()), ("lines", self.lines.to_pod()), ("cur", self.cur.to_pod()), ("closing_col", self.closing_col.to_pod()), ("closed", self.closed.to_pod()), ("at_line_start", self.at_line_start.to_pod()), ("going", self.going.to_pod())])
    }
}

impl FromPod for TplRead {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TplRead { l: FromPod::from_pod(field(p, "l")?)?, lines: FromPod::from_pod(field(p, "lines")?)?, cur: FromPod::from_pod(field(p, "cur")?)?, closing_col: FromPod::from_pod(field(p, "closing_col")?)?, closed: FromPod::from_pod(field(p, "closed")?)?, at_line_start: FromPod::from_pod(field(p, "at_line_start")?)?, going: FromPod::from_pod(field(p, "going")?)? })
    }
}

/// ```prism
/// MaybeTemplate: unbounded fn Lex, Text -> Lex
/// ```
pub fn maybe_template(l0: &crate::syntax::lexer::Lex, kw: &Text) -> crate::syntax::lexer::Lex {
    let l = {
        let mut this: crate::syntax::lexer::Lex = l0.clone();
        this.pos = crate::syntax::lexer::chars::match_end(&{ thread_local!(static R: Regex = Regex::lit(" *", "")); R.with(Regex::clone) }, &this.src, &this.pos);
        this
    };
    if (&crate::syntax::lexer::chars::peek(&l) == &Text::lit("<")) && (&template_tag_ahead(&l) != &Text::lit("")) {
        {
            let keyword = if kw == &Text::lit("output") {
                Text::lit("Output")
            } else {
                if kw == &Text::lit("inline_text") {
                    Text::lit("InlineText")
                } else {
                    Text::lit("Raw")
                }
            };
            let (kind, l2) = lex_template(&l, &keyword, &l.pos);
            let l3 = {
                let mut this: crate::syntax::lexer::Lex = l2.clone();
                this.last_ws = true;
                this
            };
            crate::syntax::lexer::push_tok(&l3, &kind, &l.pos, &l3.pos)
        }
    } else {
        crate::syntax::lexer::chars::lex_err(l0, &l0.pos, &l0.pos, &Text::from(format!("`{}` is followed by a language tag, `<rust>`", kw)))
    }
}

/// The step machine of `MaybeTemplate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MaybeTemplate: unbounded fn Lex, Text -> Lex
/// ```
pub struct MaybeTemplate {
    pub l0: crate::syntax::lexer::Lex,
    pub kw: Text,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for MaybeTemplate {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l0 = &self.l0;
        let kw = &self.kw;
        let l = {
            let mut this: crate::syntax::lexer::Lex = l0.clone();
            this.pos = crate::syntax::lexer::chars::match_end(&{ thread_local!(static R: Regex = Regex::lit(" *", "")); R.with(Regex::clone) }, &this.src, &this.pos);
            this
        };
        if (&crate::syntax::lexer::chars::peek(&l) == &Text::lit("<")) && (&template_tag_ahead(&l) != &Text::lit("")) {
            {
                let keyword = if kw == &Text::lit("output") {
                    Text::lit("Output")
                } else {
                    if kw == &Text::lit("inline_text") {
                        Text::lit("InlineText")
                    } else {
                        Text::lit("Raw")
                    }
                };
                call_then(start_lex_template(l.clone(), keyword.clone(), l.pos.clone()), move |lex_template_1019: (crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)| {
                    let (kind, l2) = lex_template_1019;
                    let l3 = {
                        let mut this: crate::syntax::lexer::Lex = l2.clone();
                        this.last_ws = true;
                        this
                    };
                    prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok(&l3, &kind, &l.pos, &l3.pos))
                })
            }
        } else {
            prism_rtl::Turn::Finished(crate::syntax::lexer::chars::lex_err(l0, &l0.pos, &l0.pos, &Text::from(format!("`{}` is followed by a language tag, `<rust>`", kw))))
        }
    }
}

/// `Start MaybeTemplate, x`: what the function value is when passed to `@Run`.
pub fn start_maybe_template(l0: crate::syntax::lexer::Lex, kw: Text) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(MaybeTemplate { l0, kw })
}

/// ```prism
/// TemplateTagAhead: unbounded fn Lex -> Text
/// ```
pub fn template_tag_ahead(l: &crate::syntax::lexer::Lex) -> Text {
    let (name, _) = crate::syntax::lexer::words::lex_ident(&crate::syntax::lexer::chars::bump(l));
    let after_ = crate::syntax::lexer::chars::peek_at(l, &(&len_text(&name) + &Nat::from(1u32)));
    if (((&crate::syntax::lexer::chars::peek(l) == &Text::lit("<")) && (&name != &Text::lit(""))) && crate::syntax::lexer::chars::is_lower(&crate::syntax::lexer::chars::head(&name))) && (&after_ == &Text::lit(">")) {
        name.clone()
    } else {
        Text::lit("")
    }
}

/// The step machine of `TemplateTagAhead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateTagAhead: unbounded fn Lex -> Text
/// ```
pub struct TemplateTagAhead {
    pub l: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<Text> for TemplateTagAhead {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let l = &self.l;
        let l = l.clone();
        call_then(crate::syntax::lexer::words::start_lex_ident(crate::syntax::lexer::chars::bump(&l)), move |lex_ident_1410: (Text, crate::syntax::lexer::Lex)| {
            let (name, _) = lex_ident_1410;
            let after_ = crate::syntax::lexer::chars::peek_at(&l, &(&len_text(&name) + &Nat::from(1u32)));
            if (((&crate::syntax::lexer::chars::peek(&l) == &Text::lit("<")) && (&name != &Text::lit(""))) && crate::syntax::lexer::chars::is_lower(&crate::syntax::lexer::chars::head(&name))) && (&after_ == &Text::lit(">")) {
                prism_rtl::Turn::Finished(name.clone())
            } else {
                prism_rtl::Turn::Finished(Text::lit(""))
            }
        })
    }
}

/// `Start TemplateTagAhead, x`: what the function value is when passed to `@Run`.
pub fn start_template_tag_ahead(l: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TemplateTagAhead { l })
}

/// ```prism
/// LexTemplate: unbounded fn Lex, Text, Nat -> ((TokKind, Lex))
/// ```
pub fn lex_template(l0: &crate::syntax::lexer::Lex, keyword: &Text, start: &Nat) -> (crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex) {
    let lang = template_tag_ahead(l0);
    let l1 = crate::syntax::lexer::chars::forward(l0, &(&len_text(&lang) + &Nat::from(2u32)));
    let delims = if (&lang == &Text::lit("markdown")) || (&lang == &Text::lit("html")) {
        Text::lit("single")
    } else {
        Text::lit("double")
    };
    let ends_line = (&crate::syntax::lexer::chars::peek(&l1) == &Text::lit("\n")) || crate::syntax::lexer::chars::starts_with(&l1, &Text::lit("\r\n"));
    let skip = if &crate::syntax::lexer::chars::peek(&l1) == &Text::lit("\r") {
        Nat::from(2u32)
    } else {
        Nat::from(1u32)
    };
    let l2 = if ends_line { crate::syntax::lexer::chars::forward(&l1, &skip) } else { l1.clone() };
    let (parts, l3) = template_body(&l2, &Text::from(format!("</{}>", &lang)), &delims, &(keyword == &Text::lit("Raw")), &!ends_line, start);
    let kind = crate::syntax::lexer::TokKind::KTemplate(crate::syntax::lexer::TemplateTok { keyword: keyword.clone(), lang: lang.clone(), delims: delims.clone(), parts: parts.clone() });
    (kind.clone(), l3.clone())
}

/// The step machine of `LexTemplate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexTemplate: unbounded fn Lex, Text, Nat -> ((TokKind, Lex))
/// ```
pub struct LexTemplate {
    pub l0: crate::syntax::lexer::Lex,
    pub keyword: Text,
    pub start: Nat,
}

impl prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> for LexTemplate {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> {
        let l0 = &self.l0;
        let keyword = &self.keyword;
        let start = &self.start;
        let keyword = keyword.clone();
        let l0 = l0.clone();
        let start = start.clone();
        call_then(start_template_tag_ahead(l0.clone()), move |template_tag_ahead_1743: Text| {
            let lang = template_tag_ahead_1743;
            let l1 = crate::syntax::lexer::chars::forward(&l0, &(&len_text(&lang) + &Nat::from(2u32)));
            let delims = if (&lang == &Text::lit("markdown")) || (&lang == &Text::lit("html")) {
                Text::lit("single")
            } else {
                Text::lit("double")
            };
            let ends_line = (&crate::syntax::lexer::chars::peek(&l1) == &Text::lit("\n")) || crate::syntax::lexer::chars::starts_with(&l1, &Text::lit("\r\n"));
            let skip = if &crate::syntax::lexer::chars::peek(&l1) == &Text::lit("\r") {
                Nat::from(2u32)
            } else {
                Nat::from(1u32)
            };
            let l2 = if ends_line { crate::syntax::lexer::chars::forward(&l1, &skip) } else { l1.clone() };
            call_then(start_template_body(l2.clone(), Text::from(format!("</{}>", &lang)), delims.clone(), &keyword == &Text::lit("Raw"), !ends_line, start.clone()), move |template_body_2157: (Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex)| {
                let (parts, l3) = template_body_2157;
                let kind = crate::syntax::lexer::TokKind::KTemplate(crate::syntax::lexer::TemplateTok { keyword: keyword.clone(), lang: lang.clone(), delims: delims.clone(), parts: parts.clone() });
                prism_rtl::Turn::Finished((kind.clone(), l3.clone()))
            })
        })
    }
}

/// `Start LexTemplate, x`: what the function value is when passed to `@Run`.
pub fn start_lex_template(l0: crate::syntax::lexer::Lex, keyword: Text, start: Nat) -> Rc<dyn prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)>> {
    Rc::new(LexTemplate { l0, keyword, start })
}

/// ```prism
/// let emptyLine
/// ```
pub fn empty_line() -> RawLine {
    RawLine { items: Array::new(), newline: false, block: false }
}

/// ```prism
/// AddItem: fn RawLine, RawItem -> RawLine
/// ```
pub fn add_item(line: &RawLine, item: &RawItem) -> RawLine {
    let mut this: RawLine = line.clone();
    this.items = add_raw(&this.items, item);
    this
}

/// ```prism
/// AddRaw: fn [RawItem], RawItem -> [RawItem]
/// ```
pub fn add_raw(items: &Array<RawItem>, raw_item1: &RawItem) -> Array<RawItem> {
    match raw_item1 {
        RawItem::RiText(t) => match crate::syntax::lexer::chars::last(items) {
            Some(RawItem::RiText(s)) => push(&crate::syntax::lexer::chars::pop(items), &RawItem::RiText(Text::from(format!("{}{}", &s, t)))),
            _ => push(items, &RawItem::RiText(t.clone())),
        },
        item => push(items, item),
    }
}

/// ```prism
/// OnlyWhitespace: fn RawLine -> Bool
/// ```
pub fn only_whitespace(line: &RawLine) -> bool {
    fold(&line.items, &true, &(|ok: &bool, it: &RawItem| *ok && is_blank_text(it)))
}

/// ```prism
/// IsBlankText: fn RawItem -> Bool
/// ```
pub fn is_blank_text(raw_item0: &RawItem) -> bool {
    match raw_item0 {
        RawItem::RiText(s) => crate::syntax::lexer::chars::all_chars(s, &(Rc::new(move |p0: Text| once_job(move || {
            let c = p0;
            prism_rtl::Turn::Finished((&c == &Text::lit(" ")) || (&c == &Text::lit("\r")))
        })) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>)),
        _ => false,
    }
}

/// ```prism
/// TextLen: fn RawLine -> Nat
/// ```
pub fn text_len(line: &RawLine) -> Nat {
    fold(&line.items, &Nat::from(0u32), &(|n: &Nat, it: &RawItem| n + &text_len_of(it)))
}

/// ```prism
/// TextLenOf: fn RawItem -> Nat
/// ```
pub fn text_len_of(raw_item0: &RawItem) -> Nat {
    match raw_item0 {
        RawItem::RiText(s) => len_text(s),
        _ => Nat::from(0u32),
    }
}

/// ```prism
/// TemplateBody: unbounded fn Lex, Text, Text, Bool, Bool, Nat -> (([TPartTok], Lex))
/// ```
pub fn template_body(l0: &crate::syntax::lexer::Lex, close: &Text, delims: &Text, is_raw: &bool, first_continues: &bool, open_start: &Nat) -> (Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex) {
    let open = if delims == &Text::lit("double") { Text::lit("{{") } else { Text::lit("{") };
    let how = TplHow { close: close.clone(), delims: delims.clone(), open: open.clone(), is_raw: *is_raw, first_continues: *first_continues };
    let start = TplRead { l: l0.clone(), lines: Array::new(), cur: empty_line(), closing_col: None, closed: false, at_line_start: !*first_continues, going: true };
    let r = {
        let mut this: TplRead = start.clone();
        while this.going {
            this = template_step(&this, &how);
        }
        this
    };
    let l1 = if r.closed {
        r.l.clone()
    } else {
        crate::syntax::lexer::chars::lex_err(&r.l, open_start, &r.l.pos, &Text::from(format!("a template never closes: expected `{}`", close)))
    };
    finish_template_lines(&l1, &push(&r.lines, &r.cur), &or(&r.closing_col, &Nat::from(0u32)), first_continues)
}

/// The step machine of `TemplateBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateBody: unbounded fn Lex, Text, Text, Bool, Bool, Nat -> (([TPartTok], Lex))
/// ```
pub struct TemplateBody {
    pub l0: crate::syntax::lexer::Lex,
    pub close: Text,
    pub delims: Text,
    pub is_raw: bool,
    pub first_continues: bool,
    pub open_start: Nat,
}

impl prism_rtl::Job<(Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex)> for TemplateBody {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex)> {
        let l0 = &self.l0;
        let close = &self.close;
        let delims = &self.delims;
        let is_raw = &self.is_raw;
        let first_continues = &self.first_continues;
        let open_start = &self.open_start;
        let open = if delims == &Text::lit("double") { Text::lit("{{") } else { Text::lit("{") };
        let how = TplHow { close: close.clone(), delims: delims.clone(), open: open.clone(), is_raw: *is_raw, first_continues: *first_continues };
        let start = TplRead { l: l0.clone(), lines: Array::new(), cur: empty_line(), closing_col: None, closed: false, at_line_start: !*first_continues, going: true };
        let mut this: TplRead = start.clone();
        let close = close.clone();
        let first_continues = *first_continues;
        let open_start = open_start.clone();
        call_then(loop_job((this,), {
            let how = how.clone();
            move |(mut this,): (TplRead,)| if this.going {
                {
                    this = template_step(&this, &how);
                    Ok((this,))
                }
            } else {
                Err((this,))
            }
        }), move |(mut this,): (TplRead,)| {
            let r = this;
            let l1 = if r.closed {
                r.l.clone()
            } else {
                crate::syntax::lexer::chars::lex_err(&r.l, &open_start, &r.l.pos, &Text::from(format!("a template never closes: expected `{}`", &close)))
            };
            prism_rtl::Turn::Finished(finish_template_lines(&l1, &push(&r.lines, &r.cur), &or(&r.closing_col, &Nat::from(0u32)), &first_continues))
        })
    }
}

/// `Start TemplateBody, x`: what the function value is when passed to `@Run`.
pub fn start_template_body(l0: crate::syntax::lexer::Lex, close: Text, delims: Text, is_raw: bool, first_continues: bool, open_start: Nat) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex)>> {
    Rc::new(TemplateBody { l0, close, delims, is_raw, first_continues, open_start })
}

/// ```prism
/// TemplateStep: unbounded fn TplRead, TplHow -> TplRead
/// ```
pub fn template_step(s: &TplRead, how: &TplHow) -> TplRead {
    let c = crate::syntax::lexer::chars::peek(&s.l);
    if (s.at_line_start && !how.is_raw) && (&crate::syntax::lexer::chars::trim(&crate::syntax::lexer::chars::rest_of_line(&s.l)) == &how.open) {
        brace_block_line(s, &crate::syntax::lexer::chars::rest_of_line(&s.l), how)
    } else {
        if crate::syntax::lexer::chars::starts_with(&s.l, &how.close) {
            close_template(s, how)
        } else {
            if &c == &Text::lit("") {
                {
                    let mut this: TplRead = s.clone();
                    this.at_line_start = false;
                    this.going = false;
                    this
                }
            } else {
                if &c == &Text::lit("\n") {
                    {
                        let mut this: TplRead = s.clone();
                        this.l = crate::syntax::lexer::chars::bump(&this.l);
                        this.cur.newline = true;
                        this.lines = push(&this.lines, &this.cur);
                        this.cur = empty_line();
                        this.at_line_start = true;
                        this
                    }
                } else {
                    {
                        let (item, l2) = template_item(&s.l, how);
                        {
                            let mut this: TplRead = s.clone();
                            this.at_line_start = false;
                            this.l = l2.clone();
                            this.cur = add_item(&this.cur, &item);
                            this
                        }
                    }
                }
            }
        }
    }
}

/// The step machine of `TemplateStep`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateStep: unbounded fn TplRead, TplHow -> TplRead
/// ```
pub struct TemplateStep {
    pub s: TplRead,
    pub how: TplHow,
}

impl prism_rtl::Job<TplRead> for TemplateStep {
    fn cycle(&self) -> prism_rtl::Turn<TplRead> {
        let s = &self.s;
        let how = &self.how;
        let c = crate::syntax::lexer::chars::peek(&s.l);
        if (s.at_line_start && !how.is_raw) && (&crate::syntax::lexer::chars::trim(&crate::syntax::lexer::chars::rest_of_line(&s.l)) == &how.open) {
            {
                let how = how.clone();
                let s = s.clone();
                call_then(crate::syntax::lexer::chars::start_rest_of_line(s.l.clone()), move |rest_of_line_5173: Text| prism_rtl::Turn::More(Rc::new(BraceBlockLine { s: s.clone(), rest: rest_of_line_5173, how: how.clone() })))
            }
        } else {
            if crate::syntax::lexer::chars::starts_with(&s.l, &how.close) {
                prism_rtl::Turn::Finished(close_template(s, how))
            } else {
                if &c == &Text::lit("") {
                    prism_rtl::Turn::Finished({
                        let mut this: TplRead = s.clone();
                        this.at_line_start = false;
                        this.going = false;
                        this
                    })
                } else {
                    if &c == &Text::lit("\n") {
                        prism_rtl::Turn::Finished({
                            let mut this: TplRead = s.clone();
                            this.l = crate::syntax::lexer::chars::bump(&this.l);
                            this.cur.newline = true;
                            this.lines = push(&this.lines, &this.cur);
                            this.cur = empty_line();
                            this.at_line_start = true;
                            this
                        })
                    } else {
                        {
                            let how = how.clone();
                            let s = s.clone();
                            call_then(start_template_item(s.l.clone(), how.clone()), move |template_item_5618: (RawItem, crate::syntax::lexer::Lex)| {
                                let (item, l2) = template_item_5618;
                                prism_rtl::Turn::Finished({
                                    let mut this: TplRead = s.clone();
                                    this.at_line_start = false;
                                    this.l = l2.clone();
                                    this.cur = add_item(&this.cur, &item);
                                    this
                                })
                            })
                        }
                    }
                }
            }
        }
    }
}

/// `Start TemplateStep, x`: what the function value is when passed to `@Run`.
pub fn start_template_step(s: TplRead, how: TplHow) -> Rc<dyn prism_rtl::Job<TplRead>> {
    Rc::new(TemplateStep { s, how })
}

/// ```prism
/// BraceBlockLine: unbounded fn TplRead, Text, TplHow -> TplRead
/// ```
pub fn brace_block_line(s: &TplRead, rest: &Text, how: &TplHow) -> TplRead {
    let bs = s.l.pos.clone();
    let past = crate::syntax::lexer::chars::forward(&s.l, &len_text(rest));
    let at_ = if &crate::syntax::lexer::chars::peek(&past) == &Text::lit("\n") {
        crate::syntax::lexer::chars::bump(&past)
    } else {
        past.clone()
    };
    let (toks, l2) = crate::syntax::lexer::layout::nested(&at_, &crate::syntax::lexer::Mode::MBrace(how.delims.clone()));
    let line = RawLine { items: Array::from(vec![RawItem::RiBlock(toks.clone(), crate::syntax::Range { start: bs.clone(), end: l2.pos.clone() })]), newline: false, block: true };
    let mut this: TplRead = s.clone();
    this.lines = push(&this.lines, &line);
    this.l = l2.clone();
    this
}

/// The step machine of `BraceBlockLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BraceBlockLine: unbounded fn TplRead, Text, TplHow -> TplRead
/// ```
pub struct BraceBlockLine {
    pub s: TplRead,
    pub rest: Text,
    pub how: TplHow,
}

impl prism_rtl::Job<TplRead> for BraceBlockLine {
    fn cycle(&self) -> prism_rtl::Turn<TplRead> {
        let s = &self.s;
        let rest = &self.rest;
        let how = &self.how;
        let bs = s.l.pos.clone();
        let past = crate::syntax::lexer::chars::forward(&s.l, &len_text(rest));
        let at_ = if &crate::syntax::lexer::chars::peek(&past) == &Text::lit("\n") {
            crate::syntax::lexer::chars::bump(&past)
        } else {
            past.clone()
        };
        let how = how.clone();
        let s = s.clone();
        call_then(crate::syntax::lexer::layout::start_nested(at_.clone(), crate::syntax::lexer::Mode::MBrace(how.delims.clone())), move |nested_5996: (Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex)| {
            let (toks, l2) = nested_5996;
            let line = RawLine { items: Array::from(vec![RawItem::RiBlock(toks.clone(), crate::syntax::Range { start: bs.clone(), end: l2.pos.clone() })]), newline: false, block: true };
            prism_rtl::Turn::Finished({
                let mut this: TplRead = s.clone();
                this.lines = push(&this.lines, &line);
                this.l = l2.clone();
                this
            })
        })
    }
}

/// `Start BraceBlockLine, x`: what the function value is when passed to `@Run`.
pub fn start_brace_block_line(s: TplRead, rest: Text, how: TplHow) -> Rc<dyn prism_rtl::Job<TplRead>> {
    Rc::new(BraceBlockLine { s, rest, how })
}

/// ```prism
/// CloseTemplate: fn TplRead, TplHow -> TplRead
/// ```
pub fn close_template(s: &TplRead, how: &TplHow) -> TplRead {
    let mut this: TplRead = s.clone();
    this.at_line_start = false;
    if only_whitespace(&this.cur) && ((&len(&this.lines) > &Nat::from(0u32)) || !how.first_continues) {
        this.closing_col = Some(text_len(&this.cur));
        this.cur.items = Array::new();
    }
    this.l = crate::syntax::lexer::chars::forward(&this.l, &len_text(&how.close));
    this.closed = true;
    this.going = false;
    this
}

/// ```prism
/// TemplateItem: unbounded fn Lex, TplHow -> ((RawItem, Lex))
/// ```
pub fn template_item(l: &crate::syntax::lexer::Lex, how: &TplHow) -> (RawItem, crate::syntax::lexer::Lex) {
    let live = !how.is_raw;
    if (live && (&how.delims == &Text::lit("double"))) && crate::syntax::lexer::chars::starts_with(l, &Text::lit("\\{{")) {
        (RawItem::RiText(Text::lit("{{")), crate::syntax::lexer::chars::forward(l, &Nat::from(3u32)))
    } else {
        if (live && (&how.delims == &Text::lit("single"))) && crate::syntax::lexer::chars::starts_with(l, &Text::lit("\\{")) {
            (RawItem::RiText(Text::lit("{")), crate::syntax::lexer::chars::forward(l, &Nat::from(2u32)))
        } else {
            if live && crate::syntax::lexer::chars::starts_with(l, &how.open) {
                {
                    let ps = l.pos.clone();
                    let (toks, l2) = crate::syntax::lexer::layout::nested(&crate::syntax::lexer::chars::forward(l, &len_text(&how.open)), &crate::syntax::lexer::Mode::MPlaceholder(how.delims.clone()));
                    let item = RawItem::RiPlaceholder(toks.clone(), crate::syntax::Range { start: ps.clone(), end: l2.pos.clone() });
                    (item.clone(), l2.clone())
                }
            } else {
                if (live && crate::syntax::lexer::chars::starts_with(l, &Text::lit("<@"))) && crate::syntax::lexer::chars::is_upper(&crate::syntax::lexer::chars::peek_at(l, &Nat::from(2u32))) {
                    template_call(l, &how.delims, &how.open)
                } else {
                    {
                        let run_ = crate::syntax::lexer::chars::match_here(&{ thread_local!(static R: Regex = Regex::lit("[^\\\\{<\\n]+", "")); R.with(Regex::clone) }, l);
                        let n = if &run_ == &Text::lit("") {
                            len_text(&crate::syntax::lexer::chars::peek(l))
                        } else {
                            len_text(&run_)
                        };
                        let l2 = {
                            let mut this: crate::syntax::lexer::Lex = l.clone();
                            this.pos = &this.pos + &n;
                            this
                        };
                        (RawItem::RiText(crate::syntax::lexer::chars::slice(l, &l.pos, &l2.pos)), l2.clone())
                    }
                }
            }
        }
    }
}

/// The step machine of `TemplateItem`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateItem: unbounded fn Lex, TplHow -> ((RawItem, Lex))
/// ```
pub struct TemplateItem {
    pub l: crate::syntax::lexer::Lex,
    pub how: TplHow,
}

impl prism_rtl::Job<(RawItem, crate::syntax::lexer::Lex)> for TemplateItem {
    fn cycle(&self) -> prism_rtl::Turn<(RawItem, crate::syntax::lexer::Lex)> {
        let l = &self.l;
        let how = &self.how;
        let live = !how.is_raw;
        if (live && (&how.delims == &Text::lit("double"))) && crate::syntax::lexer::chars::starts_with(l, &Text::lit("\\{{")) {
            prism_rtl::Turn::Finished((RawItem::RiText(Text::lit("{{")), crate::syntax::lexer::chars::forward(l, &Nat::from(3u32))))
        } else {
            if (live && (&how.delims == &Text::lit("single"))) && crate::syntax::lexer::chars::starts_with(l, &Text::lit("\\{")) {
                prism_rtl::Turn::Finished((RawItem::RiText(Text::lit("{")), crate::syntax::lexer::chars::forward(l, &Nat::from(2u32))))
            } else {
                if live && crate::syntax::lexer::chars::starts_with(l, &how.open) {
                    {
                        let ps = l.pos.clone();
                        let how = how.clone();
                        let l = l.clone();
                        call_then(crate::syntax::lexer::layout::start_nested(crate::syntax::lexer::chars::forward(&l, &len_text(&how.open)), crate::syntax::lexer::Mode::MPlaceholder(how.delims.clone())), move |nested_7242: (Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex)| {
                            let (toks, l2) = nested_7242;
                            let item = RawItem::RiPlaceholder(toks.clone(), crate::syntax::Range { start: ps.clone(), end: l2.pos.clone() });
                            prism_rtl::Turn::Finished((item.clone(), l2.clone()))
                        })
                    }
                } else {
                    if (live && crate::syntax::lexer::chars::starts_with(l, &Text::lit("<@"))) && crate::syntax::lexer::chars::is_upper(&crate::syntax::lexer::chars::peek_at(l, &Nat::from(2u32))) {
                        prism_rtl::Turn::More(Rc::new(TemplateCall { l0: l.clone(), delims: how.delims.clone(), open: how.open.clone() }))
                    } else {
                        {
                            let run_ = crate::syntax::lexer::chars::match_here(&{ thread_local!(static R: Regex = Regex::lit("[^\\\\{<\\n]+", "")); R.with(Regex::clone) }, l);
                            let n = if &run_ == &Text::lit("") {
                                len_text(&crate::syntax::lexer::chars::peek(l))
                            } else {
                                len_text(&run_)
                            };
                            let l2 = {
                                let mut this: crate::syntax::lexer::Lex = l.clone();
                                this.pos = &this.pos + &n;
                                this
                            };
                            prism_rtl::Turn::Finished((RawItem::RiText(crate::syntax::lexer::chars::slice(l, &l.pos, &l2.pos)), l2.clone()))
                        }
                    }
                }
            }
        }
    }
}

/// `Start TemplateItem, x`: what the function value is when passed to `@Run`.
pub fn start_template_item(l: crate::syntax::lexer::Lex, how: TplHow) -> Rc<dyn prism_rtl::Job<(RawItem, crate::syntax::lexer::Lex)>> {
    Rc::new(TemplateItem { l, how })
}

/// ```prism
/// TemplateCall: unbounded fn Lex, Text, Text -> ((RawItem, Lex))
/// ```
pub fn template_call(l0: &crate::syntax::lexer::Lex, delims: &Text, open: &Text) -> (RawItem, crate::syntax::lexer::Lex) {
    let start = l0.pos.clone();
    let (sigils, _, l1) = crate::syntax::lexer::words::read_sigils(&crate::syntax::lexer::chars::bump(l0));
    let (path_, l2) = crate::syntax::lexer::words::lex_qualified_path(&l1);
    let name = crate::syntax::lexer::NameTok { sigils: sigils.clone(), path_: path_.clone(), case: crate::syntax::lexer::NameCase::CaseUpper };
    let close = Text::from(format!("</{}{}>", &sigils, &crate::syntax::lexer::chars::join(&path_, &Text::lit("."))));
    let r = {
        let mut this: CallRead = CallRead { l: l2.clone(), attrs: Array::new(), body: None, going: true };
        while this.going {
            this = call_step(&this, &start, &close, delims, open);
        }
        this
    };
    let item = RawItem::RiCall(name.clone(), r.attrs.clone(), r.body.clone(), crate::syntax::Range { start: start.clone(), end: r.l.pos.clone() });
    (item.clone(), r.l.clone())
}

/// The step machine of `TemplateCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateCall: unbounded fn Lex, Text, Text -> ((RawItem, Lex))
/// ```
pub struct TemplateCall {
    pub l0: crate::syntax::lexer::Lex,
    pub delims: Text,
    pub open: Text,
}

impl prism_rtl::Job<(RawItem, crate::syntax::lexer::Lex)> for TemplateCall {
    fn cycle(&self) -> prism_rtl::Turn<(RawItem, crate::syntax::lexer::Lex)> {
        let l0 = &self.l0;
        let delims = &self.delims;
        let open = &self.open;
        let start = l0.pos.clone();
        let delims = delims.clone();
        let l0 = l0.clone();
        let open = open.clone();
        call_then(crate::syntax::lexer::words::start_read_sigils(crate::syntax::lexer::chars::bump(&l0)), move |read_sigils_8234: (Text, bool, crate::syntax::lexer::Lex)| {
            let (sigils, _, l1) = read_sigils_8234;
            call_then(crate::syntax::lexer::words::start_lex_qualified_path(l1.clone()), move |lex_qualified_path_8278: (Array<Text>, crate::syntax::lexer::Lex)| {
                let (path_, l2) = lex_qualified_path_8278;
                let name = crate::syntax::lexer::NameTok { sigils: sigils.clone(), path_: path_.clone(), case: crate::syntax::lexer::NameCase::CaseUpper };
                let close = Text::from(format!("</{}{}>", &sigils, &crate::syntax::lexer::chars::join(&path_, &Text::lit("."))));
                let mut this: CallRead = CallRead { l: l2.clone(), attrs: Array::new(), body: None, going: true };
                let name = name.clone();
                let start = start.clone();
                call_then(loop_job((this,), {
                    let close = close.clone();
                    let delims = delims.clone();
                    let open = open.clone();
                    let start = start.clone();
                    move |(mut this,): (CallRead,)| if this.going {
                        {
                            this = call_step(&this, &start, &close, &delims, &open);
                            Ok((this,))
                        }
                    } else {
                        Err((this,))
                    }
                }), move |(mut this,): (CallRead,)| {
                    let r = this;
                    let item = RawItem::RiCall(name.clone(), r.attrs.clone(), r.body.clone(), crate::syntax::Range { start: start.clone(), end: r.l.pos.clone() });
                    prism_rtl::Turn::Finished((item.clone(), r.l.clone()))
                })
            })
        })
    }
}

/// `Start TemplateCall, x`: what the function value is when passed to `@Run`.
pub fn start_template_call(l0: crate::syntax::lexer::Lex, delims: Text, open: Text) -> Rc<dyn prism_rtl::Job<(RawItem, crate::syntax::lexer::Lex)>> {
    Rc::new(TemplateCall { l0, delims, open })
}

/// ```prism
/// CallStep: unbounded fn CallRead, Nat, Text, Text, Text -> CallRead
/// ```
pub fn call_step(s0: &CallRead, start: &Nat, close: &Text, delims: &Text, open: &Text) -> CallRead {
    let l = {
        let mut this: crate::syntax::lexer::Lex = s0.l.clone();
        this.pos = crate::syntax::lexer::chars::match_end(&{ thread_local!(static R: Regex = Regex::lit("[ \\n\\r]*", "")); R.with(Regex::clone) }, &this.src, &this.pos);
        this
    };
    let s = {
        let mut this: CallRead = s0.clone();
        this.l = l.clone();
        this
    };
    let at_ = l.pos.clone();
    if crate::syntax::lexer::chars::starts_with(&l, &Text::lit("/>")) {
        {
            let mut this: CallRead = s.clone();
            this.l = crate::syntax::lexer::chars::forward(&l, &Nat::from(2u32));
            this.going = false;
            this
        }
    } else {
        if &crate::syntax::lexer::chars::peek(&l) == &Text::lit(">") {
            {
                let past = crate::syntax::lexer::chars::bump(&l);
                let continues = &crate::syntax::lexer::chars::peek(&past) != &Text::lit("\n");
                let from = if continues { past.clone() } else { crate::syntax::lexer::chars::bump(&past) };
                let (parts, l3) = template_body(&from, close, delims, &false, &continues, start);
                {
                    let mut this: CallRead = s.clone();
                    this.body = Some(parts.clone());
                    this.l = l3.clone();
                    this.going = false;
                    this
                }
            }
        } else {
            if !crate::syntax::lexer::chars::is_ident_start(&crate::syntax::lexer::chars::peek(&l)) {
                {
                    let mut this: CallRead = s.clone();
                    this.l = crate::syntax::lexer::chars::lex_err(&l, &at_, &(&at_ + &Nat::from(1u32)), &Text::lit("expected an attribute `name=value`, `/>` or `>` in a template call"));
                    this.going = false;
                    this
                }
            } else {
                {
                    let (aname, l3) = crate::syntax::lexer::words::lex_ident(&l);
                    if &crate::syntax::lexer::chars::peek(&l3) != &Text::lit("=") {
                        {
                            let mut this: CallRead = s.clone();
                            this.l = crate::syntax::lexer::chars::lex_err(&l3, &at_, &l3.pos, &Text::lit("an attribute is `name=value`"));
                            this
                        }
                    } else {
                        {
                            let (tokens, l4) = attr_value(&crate::syntax::lexer::chars::bump(&l3), delims, open);
                            {
                                let mut this: CallRead = s.clone();
                                this.attrs = push(&this.attrs, &crate::syntax::lexer::AttrTok { name: aname.clone(), tokens: tokens.clone(), span: crate::syntax::Range { start: at_.clone(), end: l4.pos.clone() } });
                                this.l = l4.clone();
                                this
                            }
                        }
                    }
                }
            }
        }
    }
}

/// The step machine of `CallStep`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallStep: unbounded fn CallRead, Nat, Text, Text, Text -> CallRead
/// ```
pub struct CallStep {
    pub s0: CallRead,
    pub start: Nat,
    pub close: Text,
    pub delims: Text,
    pub open: Text,
}

impl prism_rtl::Job<CallRead> for CallStep {
    fn cycle(&self) -> prism_rtl::Turn<CallRead> {
        let s0 = &self.s0;
        let start = &self.start;
        let close = &self.close;
        let delims = &self.delims;
        let open = &self.open;
        let l = {
            let mut this: crate::syntax::lexer::Lex = s0.l.clone();
            this.pos = crate::syntax::lexer::chars::match_end(&{ thread_local!(static R: Regex = Regex::lit("[ \\n\\r]*", "")); R.with(Regex::clone) }, &this.src, &this.pos);
            this
        };
        let s = {
            let mut this: CallRead = s0.clone();
            this.l = l.clone();
            this
        };
        let at_ = l.pos.clone();
        if crate::syntax::lexer::chars::starts_with(&l, &Text::lit("/>")) {
            prism_rtl::Turn::Finished({
                let mut this: CallRead = s.clone();
                this.l = crate::syntax::lexer::chars::forward(&l, &Nat::from(2u32));
                this.going = false;
                this
            })
        } else {
            if &crate::syntax::lexer::chars::peek(&l) == &Text::lit(">") {
                {
                    let past = crate::syntax::lexer::chars::bump(&l);
                    let continues = &crate::syntax::lexer::chars::peek(&past) != &Text::lit("\n");
                    let from = if continues { past.clone() } else { crate::syntax::lexer::chars::bump(&past) };
                    let close = close.clone();
                    let delims = delims.clone();
                    let start = start.clone();
                    call_then(start_template_body(from.clone(), close.clone(), delims.clone(), false, continues, start.clone()), move |template_body_9198: (Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex)| {
                        let (parts, l3) = template_body_9198;
                        prism_rtl::Turn::Finished({
                            let mut this: CallRead = s.clone();
                            this.body = Some(parts.clone());
                            this.l = l3.clone();
                            this.going = false;
                            this
                        })
                    })
                }
            } else {
                if !crate::syntax::lexer::chars::is_ident_start(&crate::syntax::lexer::chars::peek(&l)) {
                    prism_rtl::Turn::Finished({
                        let mut this: CallRead = s.clone();
                        this.l = crate::syntax::lexer::chars::lex_err(&l, &at_, &(&at_ + &Nat::from(1u32)), &Text::lit("expected an attribute `name=value`, `/>` or `>` in a template call"));
                        this.going = false;
                        this
                    })
                } else {
                    {
                        let delims = delims.clone();
                        let open = open.clone();
                        let start = start.clone();
                        call_then(crate::syntax::lexer::words::start_lex_ident(l.clone()), move |lex_ident_9597: (Text, crate::syntax::lexer::Lex)| {
                            let (aname, l3) = lex_ident_9597;
                            if &crate::syntax::lexer::chars::peek(&l3) != &Text::lit("=") {
                                prism_rtl::Turn::Finished({
                                    let mut this: CallRead = s.clone();
                                    this.l = crate::syntax::lexer::chars::lex_err(&l3, &at_, &l3.pos, &Text::lit("an attribute is `name=value`"));
                                    this
                                })
                            } else {
                                {
                                    let (tokens, l4) = attr_value(&crate::syntax::lexer::chars::bump(&l3), &delims, &open);
                                    prism_rtl::Turn::Finished({
                                        let mut this: CallRead = s.clone();
                                        this.attrs = push(&this.attrs, &crate::syntax::lexer::AttrTok { name: aname.clone(), tokens: tokens.clone(), span: crate::syntax::Range { start: at_.clone(), end: l4.pos.clone() } });
                                        this.l = l4.clone();
                                        this
                                    })
                                }
                            }
                        })
                    }
                }
            }
        }
    }
}

/// `Start CallStep, x`: what the function value is when passed to `@Run`.
pub fn start_call_step(s0: CallRead, start: Nat, close: Text, delims: Text, open: Text) -> Rc<dyn prism_rtl::Job<CallRead>> {
    Rc::new(CallStep { s0, start, close, delims, open })
}

/// ```prism
/// AttrValue: unbounded fn Lex, Text, Text -> (([Tok], Lex))
/// ```
pub fn attr_value(l: &crate::syntax::lexer::Lex, delims: &Text, open: &Text) -> (Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex) {
    if crate::syntax::lexer::chars::starts_with(l, open) {
        crate::syntax::lexer::layout::nested(&crate::syntax::lexer::chars::forward(l, &len_text(open)), &crate::syntax::lexer::Mode::MPlaceholder(delims.clone()))
    } else {
        if &crate::syntax::lexer::chars::peek(l) == &Text::lit("\"") {
            {
                let (text_, l2) = crate::syntax::lexer::literals::lex_text(l);
                let tok = crate::syntax::lexer::Tok { kind: crate::syntax::lexer::TokKind::KText(Text::lit(""), text_.clone()), span: crate::syntax::Range { start: l.pos.clone(), end: l2.pos.clone() }, touches: false, line_start: false };
                (Array::from(vec![tok.clone()]), l2.clone())
            }
        } else {
            (Array::new(), crate::syntax::lexer::chars::lex_err(l, &l.pos, &l.pos, &Text::from(format!("an attribute\'s value is a placeholder `{}...` or a text literal", open))))
        }
    }
}

/// ```prism
/// FinishTemplateLines: fn Lex, [RawLine], Nat, Bool -> (([TPartTok], Lex))
/// ```
pub fn finish_template_lines(l0: &crate::syntax::lexer::Lex, lines: &Array<RawLine>, strip: &Nat, first_continues: &bool) -> (Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex) {
    let mut this: (Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex) = (Array::new(), l0.clone());
    let mut l: crate::syntax::lexer::Lex = l0.clone();
    let mut parts: Array<crate::syntax::lexer::TPartTok> = Array::new();
    for (i10950, v10950) in lines.clone().into_iter().enumerate() {
        let k10950 = nat_of(i10950);
        let line = v10950.clone();
        if line.block {
            parts = append(&parts, &block_parts(&line.items));
        } else {
            let first_ = (&k10950 == &Nat::from(0u32)) && *first_continues;
            let (items, l2) = if !first_ && (strip > &Nat::from(0u32)) {
                strip_line(&line, strip, &l)
            } else {
                (line.items.clone(), l.clone())
            };
            l = l2.clone();
            let non_blank = fold(&items, &Array::new(), &(|acc: &Array<RawItem>, it: &RawItem| if is_blank_or_empty(it) { acc.clone() } else { push(acc, it) }));
            let alone = ((!first_ && line.newline) && (&len(&non_blank) == &Nat::from(1u32))) && is_placeholder_item(&or(&index(&non_blank, &Nat::from(0u32)), &RawItem::RiText(Text::lit(""))));
            if alone {
                parts = push(&parts, &alone_placeholder(&items));
            } else {
                parts = fold(&items, &parts, &push_part);
                if line.newline {
                    parts = push_part(&parts, &RawItem::RiText(Text::lit("\n")));
                }
            }
        }
    }
    this = (parts.clone(), l.clone());
    this
}

/// ```prism
/// BlockParts: fn [RawItem] -> [TPartTok]
/// ```
pub fn block_parts(items: &Array<RawItem>) -> Array<crate::syntax::lexer::TPartTok> {
    fold(items, &Array::new(), &(|acc: &Array<crate::syntax::lexer::TPartTok>, it: &RawItem| match it {
        RawItem::RiBlock(tokens, span) => push(acc, &crate::syntax::lexer::TPartTok::TptBlock(tokens.clone(), span.clone())),
        _ => acc.clone(),
    }))
}

/// ```prism
/// StripLine: fn RawLine, Nat, Lex -> (([RawItem], Lex))
/// ```
pub fn strip_line(line: &RawLine, strip: &Nat, l: &crate::syntax::lexer::Lex) -> (Array<RawItem>, crate::syntax::lexer::Lex) {
    let blank = only_whitespace(line);
    let n = match index(&line.items, &Nat::from(0u32)) {
        Some(RawItem::RiText(s)) => crate::syntax::lexer::chars::leading_in(&s, &Text::lit(" ")),
        _ => Nat::from(0u32),
    };
    let items = match index(&line.items, &Nat::from(0u32)) {
        Some(RawItem::RiText(s)) => {
            let rest = match cursor_at(&s, &min(&n, strip)) {
                Some(c) => after(&c),
                None => s.clone(),
            };
            append(&Array::from(vec![RawItem::RiText(rest.clone())]), &drop(&line.items, &Nat::from(1u32)))
        },
        _ => line.items.clone(),
    };
    let l2 = if (&n < strip) && !blank {
        crate::syntax::lexer::chars::lex_err(l, &first_item_span(&items).start, &first_item_span(&items).end, &Text::lit("a template line is indented less than its closing tag (Q-CT3)"))
    } else {
        l.clone()
    };
    let kept = if &index(&items, &Nat::from(0u32)) == &Some(RawItem::RiText(Text::lit(""))) {
        drop(&items, &Nat::from(1u32))
    } else {
        items.clone()
    };
    (kept.clone(), l2.clone())
}

/// ```prism
/// IsBlankOrEmpty: fn RawItem -> Bool
/// ```
pub fn is_blank_or_empty(raw_item0: &RawItem) -> bool {
    match raw_item0 {
        RawItem::RiText(s) => &crate::syntax::lexer::chars::trim(s) == &Text::lit(""),
        _ => false,
    }
}

/// ```prism
/// IsPlaceholderItem: fn RawItem -> Bool
/// ```
pub fn is_placeholder_item(raw_item0: &RawItem) -> bool {
    match raw_item0 {
        RawItem::RiPlaceholder(_, _) => true,
        _ => false,
    }
}

/// ```prism
/// FirstItemSpan: fn [RawItem] -> Range
/// ```
pub fn first_item_span(items: &Array<RawItem>) -> crate::syntax::Range {
    or(&fold(items, &None, &(|found_opt: &Option<crate::syntax::Range>, it: &RawItem| if found_opt != &None { found_opt.clone() } else { item_span(it) })), &crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) })
}

/// ```prism
/// ?ItemSpan: fn RawItem -> ?Range
/// ```
pub fn item_span(raw_item0: &RawItem) -> Option<crate::syntax::Range> {
    match raw_item0 {
        RawItem::RiPlaceholder(_, span) => Some(span.clone()),
        RawItem::RiBlock(_, span) => Some(span.clone()),
        RawItem::RiCall(_, _, _, span) => Some(span.clone()),
        _ => None,
    }
}

/// ```prism
/// AlonePlaceholder: fn [RawItem] -> TPartTok
/// ```
pub fn alone_placeholder(items: &Array<RawItem>) -> crate::syntax::lexer::TPartTok {
    let (_, part) = fold(items, &(Nat::from(0u32), crate::syntax::lexer::TPartTok::TptText(Text::lit(""))), &(|(c, p_): &(Nat, crate::syntax::lexer::TPartTok), it: &RawItem| alone_step(c, p_, it)));
    part.clone()
}

/// ```prism
/// AloneStep: fn Nat, TPartTok, RawItem -> ((Nat, TPartTok))
/// ```
pub fn alone_step(c: &Nat, tpart_tok1: &crate::syntax::lexer::TPartTok, raw_item2: &RawItem) -> (Nat, crate::syntax::lexer::TPartTok) {
    match (tpart_tok1, raw_item2) {
        (crate::syntax::lexer::TPartTok::TptText(c0_1_0), RawItem::RiText(s)) if (c0_1_0 == &Text::lit("")) => if c == &Nat::from(0u32) {
            (crate::syntax::lexer::chars::leading_in(s, &Text::lit(" ")), crate::syntax::lexer::TPartTok::TptText(Text::lit("")))
        } else {
            (c.clone(), crate::syntax::lexer::TPartTok::TptText(Text::lit("")))
        },
        (crate::syntax::lexer::TPartTok::TptText(c1_1_0), RawItem::RiPlaceholder(tokens, span)) if (c1_1_0 == &Text::lit("")) => (c.clone(), crate::syntax::lexer::TPartTok::TptPlaceholder(tokens.clone(), Some(c.clone()), span.clone())),
        (p_, _) => (c.clone(), p_.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// PushPart: fn [TPartTok], RawItem -> [TPartTok]
/// ```
pub fn push_part(parts: &Array<crate::syntax::lexer::TPartTok>, raw_item1: &RawItem) -> Array<crate::syntax::lexer::TPartTok> {
    match raw_item1 {
        RawItem::RiText(c0_1_0) if (c0_1_0 == &Text::lit("")) => parts.clone(),
        RawItem::RiText(t) => match crate::syntax::lexer::chars::last(parts) {
            Some(crate::syntax::lexer::TPartTok::TptText(s)) => push(&crate::syntax::lexer::chars::pop(parts), &crate::syntax::lexer::TPartTok::TptText(Text::from(format!("{}{}", &s, t)))),
            _ => push(parts, &crate::syntax::lexer::TPartTok::TptText(t.clone())),
        },
        RawItem::RiPlaceholder(tokens, span) => push(parts, &crate::syntax::lexer::TPartTok::TptPlaceholder(tokens.clone(), None, span.clone())),
        RawItem::RiBlock(tokens, span) => push(parts, &crate::syntax::lexer::TPartTok::TptBlock(tokens.clone(), span.clone())),
        RawItem::RiCall(name, attrs, body_opt, span) => push(parts, &crate::syntax::lexer::TPartTok::TptCall(name.clone(), attrs.clone(), body_opt.clone(), span.clone())),
        _ => unreachable!("no arm matched"),
    }
}
