//! The module `Syntax.Lexer.Templates`, from `target/bootstrap/src/prismc/syntax/lexer/templates.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `CallRead`:
///
/// ```prism
/// type CallRead = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CallRead {
    pub l_p: crate::syntax::lexer::Lex,
    pub attrs_p: Array<crate::syntax::lexer::AttrTok>,
    pub body_o: Option<Array<crate::syntax::lexer::TPartTok>>,
    pub going_p: bool,
}

impl Show for CallRead {
    fn show(&self, p: &mut Printer) {
        p.record("CallRead", &[("l", &self.l_p), ("attrs", &self.attrs_p), ("body", &self.body_o), ("going", &self.going_p)]);
    }
}

impl ToPod for CallRead {
    fn to_pod(&self) -> Pod {
        Pod::record("CallRead", vec![("l", self.l_p.to_pod()), ("attrs", self.attrs_p.to_pod()), ("body", self.body_o.to_pod()), ("going", self.going_p.to_pod())])
    }
}

impl FromPod for CallRead {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CallRead { l_p: FromPod::from_pod(field(p, "l")?)?, attrs_p: FromPod::from_pod(field(p, "attrs")?)?, body_o: FromPod::from_pod(field(p, "body")?)?, going_p: FromPod::from_pod(field(p, "going")?)? })
    }
}

/// `RawItem`:
///
/// ```prism
/// type RawItem = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum RawItem {
    RiText(Text),
    RiPlaceholder(Array<crate::syntax::lexer::Tok>, crate::syntax::Range),
    RiBlock(Array<crate::syntax::lexer::Tok>, crate::syntax::Range),
    RiCall(crate::syntax::lexer::NameTok, Array<crate::syntax::lexer::AttrTok>, Option<Array<crate::syntax::lexer::TPartTok>>, crate::syntax::Range),
}

impl Show for RawItem {
    fn show(&self, p: &mut Printer) {
        match self {
            RawItem::RiText(a0) => p.choice("RiText", &[a0]),
            RawItem::RiPlaceholder(a0, a1) => p.choice("RiPlaceholder", &[a0, a1]),
            RawItem::RiBlock(a0, a1) => p.choice("RiBlock", &[a0, a1]),
            RawItem::RiCall(a0, a1, a2, a3) => p.choice("RiCall", &[a0, a1, a2, a3]),
        }
    }
}

impl ToPod for RawItem {
    fn to_pod(&self) -> Pod {
        match self {
            RawItem::RiText(a0) => Pod::Choice("RiText".into(), vec![a0.to_pod()]),
            RawItem::RiPlaceholder(a0, a1) => Pod::Choice("RiPlaceholder".into(), vec![a0.to_pod(), a1.to_pod()]),
            RawItem::RiBlock(a0, a1) => Pod::Choice("RiBlock".into(), vec![a0.to_pod(), a1.to_pod()]),
            RawItem::RiCall(a0, a1, a2, a3) => Pod::Choice("RiCall".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
        }
    }
}

impl FromPod for RawItem {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "RiText" && a.len() == 1 => Ok(RawItem::RiText(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "RiPlaceholder" && a.len() == 2 => Ok(RawItem::RiPlaceholder(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "RiBlock" && a.len() == 2 => Ok(RawItem::RiBlock(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "RiCall" && a.len() == 4 => Ok(RawItem::RiCall(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?, FromPod::from_pod(&a[3])?)),
            other => mismatch("a RawItem", other),
        }
    }
}

/// `RawLine`:
///
/// ```prism
/// type RawLine = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct RawLine {
    pub items_p: Array<RawItem>,
    pub newline_p: bool,
    pub block_p: bool,
}

impl Show for RawLine {
    fn show(&self, p: &mut Printer) {
        p.record("RawLine", &[("items", &self.items_p), ("newline", &self.newline_p), ("block", &self.block_p)]);
    }
}

impl ToPod for RawLine {
    fn to_pod(&self) -> Pod {
        Pod::record("RawLine", vec![("items", self.items_p.to_pod()), ("newline", self.newline_p.to_pod()), ("block", self.block_p.to_pod())])
    }
}

impl FromPod for RawLine {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(RawLine { items_p: FromPod::from_pod(field(p, "items")?)?, newline_p: FromPod::from_pod(field(p, "newline")?)?, block_p: FromPod::from_pod(field(p, "block")?)? })
    }
}

/// `TplHow`:
///
/// ```prism
/// type TplHow = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TplHow {
    pub close_p: Text,
    pub delims_p: Text,
    pub open_p: Text,
    pub is_raw_p: bool,
    pub first_continues_p: bool,
}

impl Show for TplHow {
    fn show(&self, p: &mut Printer) {
        p.record("TplHow", &[("close", &self.close_p), ("delims", &self.delims_p), ("open", &self.open_p), ("isRaw", &self.is_raw_p), ("firstContinues", &self.first_continues_p)]);
    }
}

impl ToPod for TplHow {
    fn to_pod(&self) -> Pod {
        Pod::record("TplHow", vec![("close", self.close_p.to_pod()), ("delims", self.delims_p.to_pod()), ("open", self.open_p.to_pod()), ("isRaw", self.is_raw_p.to_pod()), ("firstContinues", self.first_continues_p.to_pod())])
    }
}

impl FromPod for TplHow {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TplHow { close_p: FromPod::from_pod(field(p, "close")?)?, delims_p: FromPod::from_pod(field(p, "delims")?)?, open_p: FromPod::from_pod(field(p, "open")?)?, is_raw_p: FromPod::from_pod(field(p, "isRaw")?)?, first_continues_p: FromPod::from_pod(field(p, "firstContinues")?)? })
    }
}

/// `TplRead`:
///
/// ```prism
/// type TplRead = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TplRead {
    pub l_p: crate::syntax::lexer::Lex,
    pub lines_p: Array<RawLine>,
    pub cur_p: RawLine,
    pub closing_col_o: Option<Nat>,
    pub closed_p: bool,
    pub at_line_start_p: bool,
    pub going_p: bool,
}

impl Show for TplRead {
    fn show(&self, p: &mut Printer) {
        p.record("TplRead", &[("l", &self.l_p), ("lines", &self.lines_p), ("cur", &self.cur_p), ("closingCol", &self.closing_col_o), ("closed", &self.closed_p), ("atLineStart", &self.at_line_start_p), ("going", &self.going_p)]);
    }
}

impl ToPod for TplRead {
    fn to_pod(&self) -> Pod {
        Pod::record("TplRead", vec![("l", self.l_p.to_pod()), ("lines", self.lines_p.to_pod()), ("cur", self.cur_p.to_pod()), ("closingCol", self.closing_col_o.to_pod()), ("closed", self.closed_p.to_pod()), ("atLineStart", self.at_line_start_p.to_pod()), ("going", self.going_p.to_pod())])
    }
}

impl FromPod for TplRead {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TplRead { l_p: FromPod::from_pod(field(p, "l")?)?, lines_p: FromPod::from_pod(field(p, "lines")?)?, cur_p: FromPod::from_pod(field(p, "cur")?)?, closing_col_o: FromPod::from_pod(field(p, "closingCol")?)?, closed_p: FromPod::from_pod(field(p, "closed")?)?, at_line_start_p: FromPod::from_pod(field(p, "atLineStart")?)?, going_p: FromPod::from_pod(field(p, "going")?)? })
    }
}

/// ```prism
/// MaybeTemplate: unbounded fn Lex, Text -> Lex
/// ```
pub fn maybe_template_f(l0_p0: &crate::syntax::lexer::Lex, kw_p1: &Text) -> crate::syntax::lexer::Lex {
    let l_p2 = {
        let mut this: crate::syntax::lexer::Lex = l0_p0.clone();
        this.pos_p = crate::syntax::lexer::chars::match_end_f(&{ thread_local!(static R: Regex = Regex::lit(" *", "")); R.with(Regex::clone) }, &this.src_p, &this.pos_p);
        this
    };
    if (&crate::syntax::lexer::chars::peek_f(&l_p2) == &Text::lit("<")) && (&template_tag_ahead_f(&l_p2) != &Text::lit("")) {
        {
            let keyword_p3 = if kw_p1 == &Text::lit("output") {
                Text::lit("Output")
            } else {
                if kw_p1 == &Text::lit("inline_text") {
                    Text::lit("InlineText")
                } else {
                    Text::lit("Raw")
                }
            };
            let (kind_p5, l2_p6) = lex_template_f(&l_p2, &keyword_p3, &l_p2.pos_p);
            let l3_p4 = {
                let mut this: crate::syntax::lexer::Lex = l2_p6.clone();
                this.last_ws_p = true;
                this
            };
            crate::syntax::lexer::push_tok_f(&l3_p4, &kind_p5, &l_p2.pos_p, &l3_p4.pos_p)
        }
    } else {
        crate::syntax::lexer::chars::lex_err_f(l0_p0, &l0_p0.pos_p, &l0_p0.pos_p, &Text::from(format!("`{}` is followed by a language tag, `<rust>`", kw_p1)))
    }
}

/// The step machine of `MaybeTemplate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MaybeTemplate: unbounded fn Lex, Text -> Lex
/// ```
pub struct MaybeTemplate {
    pub l0_p0: crate::syntax::lexer::Lex,
    pub kw_p1: Text,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for MaybeTemplate {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l0_p0 = &self.l0_p0;
        let kw_p1 = &self.kw_p1;
        let l_p2 = {
            let mut this: crate::syntax::lexer::Lex = l0_p0.clone();
            this.pos_p = crate::syntax::lexer::chars::match_end_f(&{ thread_local!(static R: Regex = Regex::lit(" *", "")); R.with(Regex::clone) }, &this.src_p, &this.pos_p);
            this
        };
        if (&crate::syntax::lexer::chars::peek_f(&l_p2) == &Text::lit("<")) && (&template_tag_ahead_f(&l_p2) != &Text::lit("")) {
            {
                let keyword_p3 = if kw_p1 == &Text::lit("output") {
                    Text::lit("Output")
                } else {
                    if kw_p1 == &Text::lit("inline_text") {
                        Text::lit("InlineText")
                    } else {
                        Text::lit("Raw")
                    }
                };
                crate::prelude::call_then(start_lex_template_f(l_p2.clone(), keyword_p3.clone(), l_p2.pos_p.clone()), move |lex_template_f_1019: (crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)| {
                    let (kind_p5, l2_p6) = lex_template_f_1019;
                    let l3_p4 = {
                        let mut this: crate::syntax::lexer::Lex = l2_p6.clone();
                        this.last_ws_p = true;
                        this
                    };
                    prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok_f(&l3_p4, &kind_p5, &l_p2.pos_p, &l3_p4.pos_p))
                })
            }
        } else {
            prism_rtl::Turn::Finished(crate::syntax::lexer::chars::lex_err_f(l0_p0, &l0_p0.pos_p, &l0_p0.pos_p, &Text::from(format!("`{}` is followed by a language tag, `<rust>`", kw_p1))))
        }
    }
}

/// `Start MaybeTemplate, x`: what the function value is when passed to `@Run`.
pub fn start_maybe_template_f(l0_p0: crate::syntax::lexer::Lex, kw_p1: Text) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(MaybeTemplate { l0_p0, kw_p1 })
}

/// ```prism
/// TemplateTagAhead: unbounded fn Lex -> Text
/// ```
pub fn template_tag_ahead_f(l_p0: &crate::syntax::lexer::Lex) -> Text {
    let (name_p2, _) = crate::syntax::lexer::words::lex_ident_f(&crate::syntax::lexer::chars::bump_f(l_p0));
    let after_p1 = crate::syntax::lexer::chars::peek_at_f(l_p0, &(&crate::prelude::len_text(&name_p2) + &Nat::from(1u32)));
    if (((&crate::syntax::lexer::chars::peek_f(l_p0) == &Text::lit("<")) && (&name_p2 != &Text::lit(""))) && crate::syntax::lexer::chars::is_lower_f(&crate::syntax::lexer::chars::head_f(&name_p2))) && (&after_p1 == &Text::lit(">")) {
        name_p2.clone()
    } else {
        Text::lit("")
    }
}

/// The step machine of `TemplateTagAhead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateTagAhead: unbounded fn Lex -> Text
/// ```
pub struct TemplateTagAhead {
    pub l_p0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<Text> for TemplateTagAhead {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let l_p0 = &self.l_p0;
        let l_p0x = l_p0.clone();
        crate::prelude::call_then(crate::syntax::lexer::words::start_lex_ident_f(crate::syntax::lexer::chars::bump_f(&l_p0x)), move |lex_ident_f_1410: (Text, crate::syntax::lexer::Lex)| {
            let (name_p2, _) = lex_ident_f_1410;
            let after_p1 = crate::syntax::lexer::chars::peek_at_f(&l_p0x, &(&crate::prelude::len_text(&name_p2) + &Nat::from(1u32)));
            if (((&crate::syntax::lexer::chars::peek_f(&l_p0x) == &Text::lit("<")) && (&name_p2 != &Text::lit(""))) && crate::syntax::lexer::chars::is_lower_f(&crate::syntax::lexer::chars::head_f(&name_p2))) && (&after_p1 == &Text::lit(">")) {
                prism_rtl::Turn::Finished(name_p2.clone())
            } else {
                prism_rtl::Turn::Finished(Text::lit(""))
            }
        })
    }
}

/// `Start TemplateTagAhead, x`: what the function value is when passed to `@Run`.
pub fn start_template_tag_ahead_f(l_p0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TemplateTagAhead { l_p0 })
}

/// ```prism
/// LexTemplate: unbounded fn Lex, Text, Nat -> ((TokKind, Lex))
/// ```
pub fn lex_template_f(l0_p0: &crate::syntax::lexer::Lex, keyword_p1: &Text, start_p2: &Nat) -> (crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex) {
    let lang_p3 = template_tag_ahead_f(l0_p0);
    let l1_p4 = crate::syntax::lexer::chars::forward_f(l0_p0, &(&crate::prelude::len_text(&lang_p3) + &Nat::from(2u32)));
    let delims_p5 = if (&lang_p3 == &Text::lit("markdown")) || (&lang_p3 == &Text::lit("html")) {
        Text::lit("single")
    } else {
        Text::lit("double")
    };
    let ends_line_p6 = (&crate::syntax::lexer::chars::peek_f(&l1_p4) == &Text::lit("\n")) || crate::syntax::lexer::chars::starts_with_f(&l1_p4, &Text::lit("\r\n"));
    let skip_p7 = if &crate::syntax::lexer::chars::peek_f(&l1_p4) == &Text::lit("\r") {
        Nat::from(2u32)
    } else {
        Nat::from(1u32)
    };
    let l2_p8 = if ends_line_p6 {
        crate::syntax::lexer::chars::forward_f(&l1_p4, &skip_p7)
    } else {
        l1_p4.clone()
    };
    let (parts_pa, l3_pb) = template_body_f(&l2_p8, &Text::from(format!("</{}>", &lang_p3)), &delims_p5, &(keyword_p1 == &Text::lit("Raw")), &!ends_line_p6, start_p2);
    let kind_p9 = crate::syntax::lexer::TokKind::KTemplate(crate::syntax::lexer::TemplateTok { keyword_p: keyword_p1.clone(), lang_p: lang_p3.clone(), delims_p: delims_p5.clone(), parts_p: parts_pa.clone() });
    (kind_p9.clone(), l3_pb.clone())
}

/// The step machine of `LexTemplate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexTemplate: unbounded fn Lex, Text, Nat -> ((TokKind, Lex))
/// ```
pub struct LexTemplate {
    pub l0_p0: crate::syntax::lexer::Lex,
    pub keyword_p1: Text,
    pub start_p2: Nat,
}

impl prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> for LexTemplate {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> {
        let l0_p0 = &self.l0_p0;
        let keyword_p1 = &self.keyword_p1;
        let start_p2 = &self.start_p2;
        let keyword_p1x = keyword_p1.clone();
        let l0_p0x = l0_p0.clone();
        let start_p2x = start_p2.clone();
        crate::prelude::call_then(start_template_tag_ahead_f(l0_p0x.clone()), move |template_tag_ahead_f_1743: Text| {
            let lang_p3 = template_tag_ahead_f_1743;
            let l1_p4 = crate::syntax::lexer::chars::forward_f(&l0_p0x, &(&crate::prelude::len_text(&lang_p3) + &Nat::from(2u32)));
            let delims_p5 = if (&lang_p3 == &Text::lit("markdown")) || (&lang_p3 == &Text::lit("html")) {
                Text::lit("single")
            } else {
                Text::lit("double")
            };
            let ends_line_p6 = (&crate::syntax::lexer::chars::peek_f(&l1_p4) == &Text::lit("\n")) || crate::syntax::lexer::chars::starts_with_f(&l1_p4, &Text::lit("\r\n"));
            let skip_p7 = if &crate::syntax::lexer::chars::peek_f(&l1_p4) == &Text::lit("\r") {
                Nat::from(2u32)
            } else {
                Nat::from(1u32)
            };
            let l2_p8 = if ends_line_p6 {
                crate::syntax::lexer::chars::forward_f(&l1_p4, &skip_p7)
            } else {
                l1_p4.clone()
            };
            crate::prelude::call_then(start_template_body_f(l2_p8.clone(), Text::from(format!("</{}>", &lang_p3)), delims_p5.clone(), &keyword_p1x == &Text::lit("Raw"), !ends_line_p6, start_p2x.clone()), move |template_body_f_2157: (Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex)| {
                let (parts_pa, l3_pb) = template_body_f_2157;
                let kind_p9 = crate::syntax::lexer::TokKind::KTemplate(crate::syntax::lexer::TemplateTok { keyword_p: keyword_p1x.clone(), lang_p: lang_p3.clone(), delims_p: delims_p5.clone(), parts_p: parts_pa.clone() });
                prism_rtl::Turn::Finished((kind_p9.clone(), l3_pb.clone()))
            })
        })
    }
}

/// `Start LexTemplate, x`: what the function value is when passed to `@Run`.
pub fn start_lex_template_f(l0_p0: crate::syntax::lexer::Lex, keyword_p1: Text, start_p2: Nat) -> Rc<dyn prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)>> {
    Rc::new(LexTemplate { l0_p0, keyword_p1, start_p2 })
}

/// ```prism
/// let emptyLine
/// ```
pub fn empty_line_p() -> RawLine {
    RawLine { items_p: Array::new(), newline_p: false, block_p: false }
}

/// ```prism
/// AddItem: fn RawLine, RawItem -> RawLine
/// ```
pub fn add_item_f(line_p0: &RawLine, item_p1: &RawItem) -> RawLine {
    let mut this: RawLine = line_p0.clone();
    this.items_p = add_raw_f(&this.items_p, item_p1);
    this
}

/// ```prism
/// AddRaw: fn [RawItem], RawItem -> [RawItem]
/// ```
pub fn add_raw_f(items_p0: &Array<RawItem>, raw_item1: &RawItem) -> Array<RawItem> {
    match raw_item1 {
        RawItem::RiText(t_p1) => match crate::syntax::lexer::chars::last_o(items_p0) {
            Some(RawItem::RiText(s_p2)) => crate::prelude::push(&crate::syntax::lexer::chars::pop_f(items_p0), &RawItem::RiText(Text::from(format!("{}{}", &s_p2, t_p1)))),
            _ => crate::prelude::push(items_p0, &RawItem::RiText(t_p1.clone())),
        },
        item_p4 => crate::prelude::push(items_p0, item_p4),
    }
}

/// ```prism
/// OnlyWhitespace: fn RawLine -> Bool
/// ```
pub fn only_whitespace_f(line_p0: &RawLine) -> bool {
    crate::prelude::fold(&line_p0.items_p, &true, &(|ok_p1: &bool, it_p2: &RawItem| *ok_p1 && is_blank_text_f(it_p2)))
}

/// ```prism
/// IsBlankText: fn RawItem -> Bool
/// ```
pub fn is_blank_text_f(raw_item0: &RawItem) -> bool {
    match raw_item0 {
        RawItem::RiText(s_p0) => crate::syntax::lexer::chars::all_chars_f(s_p0, &(Rc::new(move |p0: Text| crate::prelude::once_job(move || {
            let c_p1 = p0;
            prism_rtl::Turn::Finished((&c_p1 == &Text::lit(" ")) || (&c_p1 == &Text::lit("\r")))
        })) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>)),
        _ => false,
    }
}

/// ```prism
/// TextLen: fn RawLine -> Nat
/// ```
pub fn text_len_f(line_p0: &RawLine) -> Nat {
    crate::prelude::fold(&line_p0.items_p, &Nat::from(0u32), &(|n_p1: &Nat, it_p2: &RawItem| n_p1 + &text_len_of_f(it_p2)))
}

/// ```prism
/// TextLenOf: fn RawItem -> Nat
/// ```
pub fn text_len_of_f(raw_item0: &RawItem) -> Nat {
    match raw_item0 {
        RawItem::RiText(s_p0) => crate::prelude::len_text(s_p0),
        _ => Nat::from(0u32),
    }
}

/// ```prism
/// TemplateBody: unbounded fn Lex, Text, Text, Bool, Bool, Nat -> (([TPartTok], Lex))
/// ```
pub fn template_body_f(l0_p0: &crate::syntax::lexer::Lex, close_p1: &Text, delims_p2: &Text, is_raw_p3: &bool, first_continues_p4: &bool, open_start_p5: &Nat) -> (Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex) {
    let open_p6 = if delims_p2 == &Text::lit("double") { Text::lit("{{") } else { Text::lit("{") };
    let how_p7 = TplHow { close_p: close_p1.clone(), delims_p: delims_p2.clone(), open_p: open_p6.clone(), is_raw_p: *is_raw_p3, first_continues_p: *first_continues_p4 };
    let start_p8 = TplRead { l_p: l0_p0.clone(), lines_p: Array::new(), cur_p: empty_line_p(), closing_col_o: None, closed_p: false, at_line_start_p: !*first_continues_p4, going_p: true };
    let r_p9 = {
        let mut this: TplRead = start_p8.clone();
        while this.going_p {
            this = template_step_f(&this, &how_p7);
        }
        this
    };
    let l1_pa = if r_p9.closed_p {
        r_p9.l_p.clone()
    } else {
        crate::syntax::lexer::chars::lex_err_f(&r_p9.l_p, open_start_p5, &r_p9.l_p.pos_p, &Text::from(format!("a template never closes: expected `{}`", close_p1)))
    };
    finish_template_lines_f(&l1_pa, &crate::prelude::push(&r_p9.lines_p, &r_p9.cur_p), &crate::prelude::or(&r_p9.closing_col_o, &Nat::from(0u32)), first_continues_p4)
}

/// The step machine of `TemplateBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateBody: unbounded fn Lex, Text, Text, Bool, Bool, Nat -> (([TPartTok], Lex))
/// ```
pub struct TemplateBody {
    pub l0_p0: crate::syntax::lexer::Lex,
    pub close_p1: Text,
    pub delims_p2: Text,
    pub is_raw_p3: bool,
    pub first_continues_p4: bool,
    pub open_start_p5: Nat,
}

impl prism_rtl::Job<(Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex)> for TemplateBody {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex)> {
        let l0_p0 = &self.l0_p0;
        let close_p1 = &self.close_p1;
        let delims_p2 = &self.delims_p2;
        let is_raw_p3 = &self.is_raw_p3;
        let first_continues_p4 = &self.first_continues_p4;
        let open_start_p5 = &self.open_start_p5;
        let open_p6 = if delims_p2 == &Text::lit("double") { Text::lit("{{") } else { Text::lit("{") };
        let how_p7 = TplHow { close_p: close_p1.clone(), delims_p: delims_p2.clone(), open_p: open_p6.clone(), is_raw_p: *is_raw_p3, first_continues_p: *first_continues_p4 };
        let start_p8 = TplRead { l_p: l0_p0.clone(), lines_p: Array::new(), cur_p: empty_line_p(), closing_col_o: None, closed_p: false, at_line_start_p: !*first_continues_p4, going_p: true };
        let mut this: TplRead = start_p8.clone();
        let close_p1z = close_p1.clone();
        let first_continues_p4z = *first_continues_p4;
        let open_start_p5z = open_start_p5.clone();
        crate::prelude::call_then(crate::prelude::loop_job((this,), {
            let how_p7x = how_p7.clone();
            move |(mut this,): (TplRead,)| if this.going_p {
                {
                    this = template_step_f(&this, &how_p7x);
                    Ok((this,))
                }
            } else {
                Err((this,))
            }
        }), move |(mut this,): (TplRead,)| {
            let r_p9 = this;
            let l1_pa = if r_p9.closed_p {
                r_p9.l_p.clone()
            } else {
                crate::syntax::lexer::chars::lex_err_f(&r_p9.l_p, &open_start_p5z, &r_p9.l_p.pos_p, &Text::from(format!("a template never closes: expected `{}`", &close_p1z)))
            };
            prism_rtl::Turn::Finished(finish_template_lines_f(&l1_pa, &crate::prelude::push(&r_p9.lines_p, &r_p9.cur_p), &crate::prelude::or(&r_p9.closing_col_o, &Nat::from(0u32)), &first_continues_p4z))
        })
    }
}

/// `Start TemplateBody, x`: what the function value is when passed to `@Run`.
pub fn start_template_body_f(l0_p0: crate::syntax::lexer::Lex, close_p1: Text, delims_p2: Text, is_raw_p3: bool, first_continues_p4: bool, open_start_p5: Nat) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex)>> {
    Rc::new(TemplateBody { l0_p0, close_p1, delims_p2, is_raw_p3, first_continues_p4, open_start_p5 })
}

/// ```prism
/// TemplateStep: unbounded fn TplRead, TplHow -> TplRead
/// ```
pub fn template_step_f(s_p0: &TplRead, how_p1: &TplHow) -> TplRead {
    let c_p2 = crate::syntax::lexer::chars::peek_f(&s_p0.l_p);
    if (s_p0.at_line_start_p && !how_p1.is_raw_p) && (&crate::syntax::lexer::chars::trim_f(&crate::syntax::lexer::chars::rest_of_line_f(&s_p0.l_p)) == &how_p1.open_p) {
        brace_block_line_f(s_p0, &crate::syntax::lexer::chars::rest_of_line_f(&s_p0.l_p), how_p1)
    } else {
        if crate::syntax::lexer::chars::starts_with_f(&s_p0.l_p, &how_p1.close_p) {
            close_template_f(s_p0, how_p1)
        } else {
            if &c_p2 == &Text::lit("") {
                {
                    let mut this: TplRead = s_p0.clone();
                    this.at_line_start_p = false;
                    this.going_p = false;
                    this
                }
            } else {
                if &c_p2 == &Text::lit("\n") {
                    {
                        let mut this: TplRead = s_p0.clone();
                        this.l_p = crate::syntax::lexer::chars::bump_f(&this.l_p);
                        this.cur_p.newline_p = true;
                        this.lines_p = crate::prelude::push(&this.lines_p, &this.cur_p);
                        this.cur_p = empty_line_p();
                        this.at_line_start_p = true;
                        this
                    }
                } else {
                    {
                        let (item_p3, l2_p4) = template_item_f(&s_p0.l_p, how_p1);
                        {
                            let mut this: TplRead = s_p0.clone();
                            this.at_line_start_p = false;
                            this.l_p = l2_p4.clone();
                            this.cur_p = add_item_f(&this.cur_p, &item_p3);
                            this
                        }
                    }
                }
            }
        }
    }
}

/// The step machine of `TemplateStep`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateStep: unbounded fn TplRead, TplHow -> TplRead
/// ```
pub struct TemplateStep {
    pub s_p0: TplRead,
    pub how_p1: TplHow,
}

impl prism_rtl::Job<TplRead> for TemplateStep {
    fn cycle(&self) -> prism_rtl::Turn<TplRead> {
        let s_p0 = &self.s_p0;
        let how_p1 = &self.how_p1;
        let c_p2 = crate::syntax::lexer::chars::peek_f(&s_p0.l_p);
        if (s_p0.at_line_start_p && !how_p1.is_raw_p) && (&crate::syntax::lexer::chars::trim_f(&crate::syntax::lexer::chars::rest_of_line_f(&s_p0.l_p)) == &how_p1.open_p) {
            {
                let how_p1x = how_p1.clone();
                let s_p0x = s_p0.clone();
                crate::prelude::call_then(crate::syntax::lexer::chars::start_rest_of_line_f(s_p0x.l_p.clone()), move |rest_of_line_f_5173: Text| prism_rtl::Turn::More(Rc::new(BraceBlockLine { s_p0: s_p0x.clone(), rest_p1: rest_of_line_f_5173, how_p2: how_p1x.clone() })))
            }
        } else {
            if crate::syntax::lexer::chars::starts_with_f(&s_p0.l_p, &how_p1.close_p) {
                prism_rtl::Turn::Finished(close_template_f(s_p0, how_p1))
            } else {
                if &c_p2 == &Text::lit("") {
                    prism_rtl::Turn::Finished({
                        let mut this: TplRead = s_p0.clone();
                        this.at_line_start_p = false;
                        this.going_p = false;
                        this
                    })
                } else {
                    if &c_p2 == &Text::lit("\n") {
                        prism_rtl::Turn::Finished({
                            let mut this: TplRead = s_p0.clone();
                            this.l_p = crate::syntax::lexer::chars::bump_f(&this.l_p);
                            this.cur_p.newline_p = true;
                            this.lines_p = crate::prelude::push(&this.lines_p, &this.cur_p);
                            this.cur_p = empty_line_p();
                            this.at_line_start_p = true;
                            this
                        })
                    } else {
                        {
                            let how_p1x = how_p1.clone();
                            let s_p0x = s_p0.clone();
                            crate::prelude::call_then(start_template_item_f(s_p0x.l_p.clone(), how_p1x.clone()), move |template_item_f_5618: (RawItem, crate::syntax::lexer::Lex)| {
                                let (item_p3, l2_p4) = template_item_f_5618;
                                prism_rtl::Turn::Finished({
                                    let mut this: TplRead = s_p0x.clone();
                                    this.at_line_start_p = false;
                                    this.l_p = l2_p4.clone();
                                    this.cur_p = add_item_f(&this.cur_p, &item_p3);
                                    this
                                })
                            })
                        }
                    }
                }
            }
        }
    }
}

/// `Start TemplateStep, x`: what the function value is when passed to `@Run`.
pub fn start_template_step_f(s_p0: TplRead, how_p1: TplHow) -> Rc<dyn prism_rtl::Job<TplRead>> {
    Rc::new(TemplateStep { s_p0, how_p1 })
}

/// ```prism
/// BraceBlockLine: unbounded fn TplRead, Text, TplHow -> TplRead
/// ```
pub fn brace_block_line_f(s_p0: &TplRead, rest_p1: &Text, how_p2: &TplHow) -> TplRead {
    let bs_p3 = s_p0.l_p.pos_p.clone();
    let past_p4 = crate::syntax::lexer::chars::forward_f(&s_p0.l_p, &crate::prelude::len_text(rest_p1));
    let at_p5 = if &crate::syntax::lexer::chars::peek_f(&past_p4) == &Text::lit("\n") {
        crate::syntax::lexer::chars::bump_f(&past_p4)
    } else {
        past_p4.clone()
    };
    let (toks_p7, l2_p8) = crate::syntax::lexer::layout::nested_f(&at_p5, &crate::syntax::lexer::Mode::MBrace(how_p2.delims_p.clone()));
    let line_p6 = RawLine { items_p: Array::from(vec![RawItem::RiBlock(toks_p7.clone(), crate::syntax::Range { start_p: bs_p3.clone(), end_p: l2_p8.pos_p.clone() })]), newline_p: false, block_p: true };
    let mut this: TplRead = s_p0.clone();
    this.lines_p = crate::prelude::push(&this.lines_p, &line_p6);
    this.l_p = l2_p8.clone();
    this
}

/// The step machine of `BraceBlockLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BraceBlockLine: unbounded fn TplRead, Text, TplHow -> TplRead
/// ```
pub struct BraceBlockLine {
    pub s_p0: TplRead,
    pub rest_p1: Text,
    pub how_p2: TplHow,
}

impl prism_rtl::Job<TplRead> for BraceBlockLine {
    fn cycle(&self) -> prism_rtl::Turn<TplRead> {
        let s_p0 = &self.s_p0;
        let rest_p1 = &self.rest_p1;
        let how_p2 = &self.how_p2;
        let bs_p3 = s_p0.l_p.pos_p.clone();
        let past_p4 = crate::syntax::lexer::chars::forward_f(&s_p0.l_p, &crate::prelude::len_text(rest_p1));
        let at_p5 = if &crate::syntax::lexer::chars::peek_f(&past_p4) == &Text::lit("\n") {
            crate::syntax::lexer::chars::bump_f(&past_p4)
        } else {
            past_p4.clone()
        };
        let how_p2x = how_p2.clone();
        let s_p0x = s_p0.clone();
        crate::prelude::call_then(crate::syntax::lexer::layout::start_nested_f(at_p5.clone(), crate::syntax::lexer::Mode::MBrace(how_p2x.delims_p.clone())), move |nested_f_5996: (Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex)| {
            let (toks_p7, l2_p8) = nested_f_5996;
            let line_p6 = RawLine { items_p: Array::from(vec![RawItem::RiBlock(toks_p7.clone(), crate::syntax::Range { start_p: bs_p3.clone(), end_p: l2_p8.pos_p.clone() })]), newline_p: false, block_p: true };
            prism_rtl::Turn::Finished({
                let mut this: TplRead = s_p0x.clone();
                this.lines_p = crate::prelude::push(&this.lines_p, &line_p6);
                this.l_p = l2_p8.clone();
                this
            })
        })
    }
}

/// `Start BraceBlockLine, x`: what the function value is when passed to `@Run`.
pub fn start_brace_block_line_f(s_p0: TplRead, rest_p1: Text, how_p2: TplHow) -> Rc<dyn prism_rtl::Job<TplRead>> {
    Rc::new(BraceBlockLine { s_p0, rest_p1, how_p2 })
}

/// ```prism
/// CloseTemplate: fn TplRead, TplHow -> TplRead
/// ```
pub fn close_template_f(s_p0: &TplRead, how_p1: &TplHow) -> TplRead {
    let mut this: TplRead = s_p0.clone();
    this.at_line_start_p = false;
    if only_whitespace_f(&this.cur_p) && ((&crate::prelude::len(&this.lines_p) > &Nat::from(0u32)) || !how_p1.first_continues_p) {
        this.closing_col_o = Some(text_len_f(&this.cur_p));
        this.cur_p.items_p = Array::new();
    }
    this.l_p = crate::syntax::lexer::chars::forward_f(&this.l_p, &crate::prelude::len_text(&how_p1.close_p));
    this.closed_p = true;
    this.going_p = false;
    this
}

/// ```prism
/// TemplateItem: unbounded fn Lex, TplHow -> ((RawItem, Lex))
/// ```
pub fn template_item_f(l_p0: &crate::syntax::lexer::Lex, how_p1: &TplHow) -> (RawItem, crate::syntax::lexer::Lex) {
    let live_p2 = !how_p1.is_raw_p;
    if (live_p2 && (&how_p1.delims_p == &Text::lit("double"))) && crate::syntax::lexer::chars::starts_with_f(l_p0, &Text::lit("\\{{")) {
        (RawItem::RiText(Text::lit("{{")), crate::syntax::lexer::chars::forward_f(l_p0, &Nat::from(3u32)))
    } else {
        if (live_p2 && (&how_p1.delims_p == &Text::lit("single"))) && crate::syntax::lexer::chars::starts_with_f(l_p0, &Text::lit("\\{")) {
            (RawItem::RiText(Text::lit("{")), crate::syntax::lexer::chars::forward_f(l_p0, &Nat::from(2u32)))
        } else {
            if live_p2 && crate::syntax::lexer::chars::starts_with_f(l_p0, &how_p1.open_p) {
                {
                    let ps_p3 = l_p0.pos_p.clone();
                    let (toks_p5, l2_p6) = crate::syntax::lexer::layout::nested_f(&crate::syntax::lexer::chars::forward_f(l_p0, &crate::prelude::len_text(&how_p1.open_p)), &crate::syntax::lexer::Mode::MPlaceholder(how_p1.delims_p.clone()));
                    let item_p4 = RawItem::RiPlaceholder(toks_p5.clone(), crate::syntax::Range { start_p: ps_p3.clone(), end_p: l2_p6.pos_p.clone() });
                    (item_p4.clone(), l2_p6.clone())
                }
            } else {
                if (live_p2 && crate::syntax::lexer::chars::starts_with_f(l_p0, &Text::lit("<@"))) && crate::syntax::lexer::chars::is_upper_f(&crate::syntax::lexer::chars::peek_at_f(l_p0, &Nat::from(2u32))) {
                    template_call_f(l_p0, &how_p1.delims_p, &how_p1.open_p)
                } else {
                    {
                        let run_p7 = crate::syntax::lexer::chars::match_here_f(&{ thread_local!(static R: Regex = Regex::lit("[^\\\\{<\\n]+", "")); R.with(Regex::clone) }, l_p0);
                        let n_p8 = if &run_p7 == &Text::lit("") {
                            crate::prelude::len_text(&crate::syntax::lexer::chars::peek_f(l_p0))
                        } else {
                            crate::prelude::len_text(&run_p7)
                        };
                        let l2_p9 = {
                            let mut this: crate::syntax::lexer::Lex = l_p0.clone();
                            this.pos_p = &this.pos_p + &n_p8;
                            this
                        };
                        (RawItem::RiText(crate::syntax::lexer::chars::slice_f(l_p0, &l_p0.pos_p, &l2_p9.pos_p)), l2_p9.clone())
                    }
                }
            }
        }
    }
}

/// The step machine of `TemplateItem`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateItem: unbounded fn Lex, TplHow -> ((RawItem, Lex))
/// ```
pub struct TemplateItem {
    pub l_p0: crate::syntax::lexer::Lex,
    pub how_p1: TplHow,
}

impl prism_rtl::Job<(RawItem, crate::syntax::lexer::Lex)> for TemplateItem {
    fn cycle(&self) -> prism_rtl::Turn<(RawItem, crate::syntax::lexer::Lex)> {
        let l_p0 = &self.l_p0;
        let how_p1 = &self.how_p1;
        let live_p2 = !how_p1.is_raw_p;
        if (live_p2 && (&how_p1.delims_p == &Text::lit("double"))) && crate::syntax::lexer::chars::starts_with_f(l_p0, &Text::lit("\\{{")) {
            prism_rtl::Turn::Finished((RawItem::RiText(Text::lit("{{")), crate::syntax::lexer::chars::forward_f(l_p0, &Nat::from(3u32))))
        } else {
            if (live_p2 && (&how_p1.delims_p == &Text::lit("single"))) && crate::syntax::lexer::chars::starts_with_f(l_p0, &Text::lit("\\{")) {
                prism_rtl::Turn::Finished((RawItem::RiText(Text::lit("{")), crate::syntax::lexer::chars::forward_f(l_p0, &Nat::from(2u32))))
            } else {
                if live_p2 && crate::syntax::lexer::chars::starts_with_f(l_p0, &how_p1.open_p) {
                    {
                        let ps_p3 = l_p0.pos_p.clone();
                        let how_p1x = how_p1.clone();
                        let l_p0x = l_p0.clone();
                        crate::prelude::call_then(crate::syntax::lexer::layout::start_nested_f(crate::syntax::lexer::chars::forward_f(&l_p0x, &crate::prelude::len_text(&how_p1x.open_p)), crate::syntax::lexer::Mode::MPlaceholder(how_p1x.delims_p.clone())), move |nested_f_7242: (Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex)| {
                            let (toks_p5, l2_p6) = nested_f_7242;
                            let item_p4 = RawItem::RiPlaceholder(toks_p5.clone(), crate::syntax::Range { start_p: ps_p3.clone(), end_p: l2_p6.pos_p.clone() });
                            prism_rtl::Turn::Finished((item_p4.clone(), l2_p6.clone()))
                        })
                    }
                } else {
                    if (live_p2 && crate::syntax::lexer::chars::starts_with_f(l_p0, &Text::lit("<@"))) && crate::syntax::lexer::chars::is_upper_f(&crate::syntax::lexer::chars::peek_at_f(l_p0, &Nat::from(2u32))) {
                        prism_rtl::Turn::More(Rc::new(TemplateCall { l0_p0: l_p0.clone(), delims_p1: how_p1.delims_p.clone(), open_p2: how_p1.open_p.clone() }))
                    } else {
                        {
                            let run_p7 = crate::syntax::lexer::chars::match_here_f(&{ thread_local!(static R: Regex = Regex::lit("[^\\\\{<\\n]+", "")); R.with(Regex::clone) }, l_p0);
                            let n_p8 = if &run_p7 == &Text::lit("") {
                                crate::prelude::len_text(&crate::syntax::lexer::chars::peek_f(l_p0))
                            } else {
                                crate::prelude::len_text(&run_p7)
                            };
                            let l2_p9 = {
                                let mut this: crate::syntax::lexer::Lex = l_p0.clone();
                                this.pos_p = &this.pos_p + &n_p8;
                                this
                            };
                            prism_rtl::Turn::Finished((RawItem::RiText(crate::syntax::lexer::chars::slice_f(l_p0, &l_p0.pos_p, &l2_p9.pos_p)), l2_p9.clone()))
                        }
                    }
                }
            }
        }
    }
}

/// `Start TemplateItem, x`: what the function value is when passed to `@Run`.
pub fn start_template_item_f(l_p0: crate::syntax::lexer::Lex, how_p1: TplHow) -> Rc<dyn prism_rtl::Job<(RawItem, crate::syntax::lexer::Lex)>> {
    Rc::new(TemplateItem { l_p0, how_p1 })
}

/// ```prism
/// TemplateCall: unbounded fn Lex, Text, Text -> ((RawItem, Lex))
/// ```
pub fn template_call_f(l0_p0: &crate::syntax::lexer::Lex, delims_p1: &Text, open_p2: &Text) -> (RawItem, crate::syntax::lexer::Lex) {
    let start_p3 = l0_p0.pos_p.clone();
    let (sigils_p8, _, l1_p9) = crate::syntax::lexer::words::read_sigils_f(&crate::syntax::lexer::chars::bump_f(l0_p0));
    let (path_pa, l2_pb) = crate::syntax::lexer::words::lex_qualified_path_f(&l1_p9);
    let name_p4 = crate::syntax::lexer::NameTok { sigils_p: sigils_p8.clone(), path_p: path_pa.clone(), case_p: crate::syntax::lexer::NameCase::CaseUpper };
    let close_p5 = Text::from(format!("</{}{}>", &sigils_p8, &crate::syntax::lexer::chars::join_f(&path_pa, &Text::lit("."))));
    let r_p6 = {
        let mut this: CallRead = CallRead { l_p: l2_pb.clone(), attrs_p: Array::new(), body_o: None, going_p: true };
        while this.going_p {
            this = call_step_f(&this, &start_p3, &close_p5, delims_p1, open_p2);
        }
        this
    };
    let item_p7 = RawItem::RiCall(name_p4.clone(), r_p6.attrs_p.clone(), r_p6.body_o.clone(), crate::syntax::Range { start_p: start_p3.clone(), end_p: r_p6.l_p.pos_p.clone() });
    (item_p7.clone(), r_p6.l_p.clone())
}

/// The step machine of `TemplateCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateCall: unbounded fn Lex, Text, Text -> ((RawItem, Lex))
/// ```
pub struct TemplateCall {
    pub l0_p0: crate::syntax::lexer::Lex,
    pub delims_p1: Text,
    pub open_p2: Text,
}

impl prism_rtl::Job<(RawItem, crate::syntax::lexer::Lex)> for TemplateCall {
    fn cycle(&self) -> prism_rtl::Turn<(RawItem, crate::syntax::lexer::Lex)> {
        let l0_p0 = &self.l0_p0;
        let delims_p1 = &self.delims_p1;
        let open_p2 = &self.open_p2;
        let start_p3 = l0_p0.pos_p.clone();
        let delims_p1x = delims_p1.clone();
        let l0_p0x = l0_p0.clone();
        let open_p2x = open_p2.clone();
        crate::prelude::call_then(crate::syntax::lexer::words::start_read_sigils_f(crate::syntax::lexer::chars::bump_f(&l0_p0x)), move |read_sigils_f_8234: (Text, bool, crate::syntax::lexer::Lex)| {
            let (sigils_p8, _, l1_p9) = read_sigils_f_8234;
            crate::prelude::call_then(crate::syntax::lexer::words::start_lex_qualified_path_f(l1_p9.clone()), move |lex_qualified_path_f_8278: (Array<Text>, crate::syntax::lexer::Lex)| {
                let (path_pa, l2_pb) = lex_qualified_path_f_8278;
                let name_p4 = crate::syntax::lexer::NameTok { sigils_p: sigils_p8.clone(), path_p: path_pa.clone(), case_p: crate::syntax::lexer::NameCase::CaseUpper };
                let close_p5 = Text::from(format!("</{}{}>", &sigils_p8, &crate::syntax::lexer::chars::join_f(&path_pa, &Text::lit("."))));
                let mut this: CallRead = CallRead { l_p: l2_pb.clone(), attrs_p: Array::new(), body_o: None, going_p: true };
                let name_p4z = name_p4.clone();
                let start_p3z = start_p3.clone();
                crate::prelude::call_then(crate::prelude::loop_job((this,), {
                    let close_p5x = close_p5.clone();
                    let delims_p1xx = delims_p1x.clone();
                    let open_p2xx = open_p2x.clone();
                    let start_p3x = start_p3.clone();
                    move |(mut this,): (CallRead,)| if this.going_p {
                        {
                            this = call_step_f(&this, &start_p3x, &close_p5x, &delims_p1xx, &open_p2xx);
                            Ok((this,))
                        }
                    } else {
                        Err((this,))
                    }
                }), move |(mut this,): (CallRead,)| {
                    let r_p6 = this;
                    let item_p7 = RawItem::RiCall(name_p4z.clone(), r_p6.attrs_p.clone(), r_p6.body_o.clone(), crate::syntax::Range { start_p: start_p3z.clone(), end_p: r_p6.l_p.pos_p.clone() });
                    prism_rtl::Turn::Finished((item_p7.clone(), r_p6.l_p.clone()))
                })
            })
        })
    }
}

/// `Start TemplateCall, x`: what the function value is when passed to `@Run`.
pub fn start_template_call_f(l0_p0: crate::syntax::lexer::Lex, delims_p1: Text, open_p2: Text) -> Rc<dyn prism_rtl::Job<(RawItem, crate::syntax::lexer::Lex)>> {
    Rc::new(TemplateCall { l0_p0, delims_p1, open_p2 })
}

/// ```prism
/// CallStep: unbounded fn CallRead, Nat, Text, Text, Text -> CallRead
/// ```
pub fn call_step_f(s0_p0: &CallRead, start_p1: &Nat, close_p2: &Text, delims_p3: &Text, open_p4: &Text) -> CallRead {
    let l_p5 = {
        let mut this: crate::syntax::lexer::Lex = s0_p0.l_p.clone();
        this.pos_p = crate::syntax::lexer::chars::match_end_f(&{ thread_local!(static R: Regex = Regex::lit("[ \\n\\r]*", "")); R.with(Regex::clone) }, &this.src_p, &this.pos_p);
        this
    };
    let s_p6 = {
        let mut this: CallRead = s0_p0.clone();
        this.l_p = l_p5.clone();
        this
    };
    let at_p7 = l_p5.pos_p.clone();
    if crate::syntax::lexer::chars::starts_with_f(&l_p5, &Text::lit("/>")) {
        {
            let mut this: CallRead = s_p6.clone();
            this.l_p = crate::syntax::lexer::chars::forward_f(&l_p5, &Nat::from(2u32));
            this.going_p = false;
            this
        }
    } else {
        if &crate::syntax::lexer::chars::peek_f(&l_p5) == &Text::lit(">") {
            {
                let past_p8 = crate::syntax::lexer::chars::bump_f(&l_p5);
                let continues_p9 = &crate::syntax::lexer::chars::peek_f(&past_p8) != &Text::lit("\n");
                let from_pa = if continues_p9 {
                    past_p8.clone()
                } else {
                    crate::syntax::lexer::chars::bump_f(&past_p8)
                };
                let (parts_pb, l3_pc) = template_body_f(&from_pa, close_p2, delims_p3, &false, &continues_p9, start_p1);
                {
                    let mut this: CallRead = s_p6.clone();
                    this.body_o = Some(parts_pb.clone());
                    this.l_p = l3_pc.clone();
                    this.going_p = false;
                    this
                }
            }
        } else {
            if !crate::syntax::lexer::chars::is_ident_start_f(&crate::syntax::lexer::chars::peek_f(&l_p5)) {
                {
                    let mut this: CallRead = s_p6.clone();
                    this.l_p = crate::syntax::lexer::chars::lex_err_f(&l_p5, &at_p7, &(&at_p7 + &Nat::from(1u32)), &Text::lit("expected an attribute `name=value`, `/>` or `>` in a template call"));
                    this.going_p = false;
                    this
                }
            } else {
                {
                    let (aname_pd, l3_pe) = crate::syntax::lexer::words::lex_ident_f(&l_p5);
                    if &crate::syntax::lexer::chars::peek_f(&l3_pe) != &Text::lit("=") {
                        {
                            let mut this: CallRead = s_p6.clone();
                            this.l_p = crate::syntax::lexer::chars::lex_err_f(&l3_pe, &at_p7, &l3_pe.pos_p, &Text::lit("an attribute is `name=value`"));
                            this
                        }
                    } else {
                        {
                            let (tokens_pf, l4_pg) = attr_value_f(&crate::syntax::lexer::chars::bump_f(&l3_pe), delims_p3, open_p4);
                            {
                                let mut this: CallRead = s_p6.clone();
                                this.attrs_p = crate::prelude::push(&this.attrs_p, &crate::syntax::lexer::AttrTok { name_p: aname_pd.clone(), tokens_p: tokens_pf.clone(), span_p: crate::syntax::Range { start_p: at_p7.clone(), end_p: l4_pg.pos_p.clone() } });
                                this.l_p = l4_pg.clone();
                                this
                            }
                        }
                    }
                }
            }
        }
    }
}

/// The step machine of `CallStep`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallStep: unbounded fn CallRead, Nat, Text, Text, Text -> CallRead
/// ```
pub struct CallStep {
    pub s0_p0: CallRead,
    pub start_p1: Nat,
    pub close_p2: Text,
    pub delims_p3: Text,
    pub open_p4: Text,
}

impl prism_rtl::Job<CallRead> for CallStep {
    fn cycle(&self) -> prism_rtl::Turn<CallRead> {
        let s0_p0 = &self.s0_p0;
        let start_p1 = &self.start_p1;
        let close_p2 = &self.close_p2;
        let delims_p3 = &self.delims_p3;
        let open_p4 = &self.open_p4;
        let l_p5 = {
            let mut this: crate::syntax::lexer::Lex = s0_p0.l_p.clone();
            this.pos_p = crate::syntax::lexer::chars::match_end_f(&{ thread_local!(static R: Regex = Regex::lit("[ \\n\\r]*", "")); R.with(Regex::clone) }, &this.src_p, &this.pos_p);
            this
        };
        let s_p6 = {
            let mut this: CallRead = s0_p0.clone();
            this.l_p = l_p5.clone();
            this
        };
        let at_p7 = l_p5.pos_p.clone();
        if crate::syntax::lexer::chars::starts_with_f(&l_p5, &Text::lit("/>")) {
            prism_rtl::Turn::Finished({
                let mut this: CallRead = s_p6.clone();
                this.l_p = crate::syntax::lexer::chars::forward_f(&l_p5, &Nat::from(2u32));
                this.going_p = false;
                this
            })
        } else {
            if &crate::syntax::lexer::chars::peek_f(&l_p5) == &Text::lit(">") {
                {
                    let past_p8 = crate::syntax::lexer::chars::bump_f(&l_p5);
                    let continues_p9 = &crate::syntax::lexer::chars::peek_f(&past_p8) != &Text::lit("\n");
                    let from_pa = if continues_p9 {
                        past_p8.clone()
                    } else {
                        crate::syntax::lexer::chars::bump_f(&past_p8)
                    };
                    let close_p2x = close_p2.clone();
                    let delims_p3x = delims_p3.clone();
                    let start_p1x = start_p1.clone();
                    crate::prelude::call_then(start_template_body_f(from_pa.clone(), close_p2x.clone(), delims_p3x.clone(), false, continues_p9, start_p1x.clone()), move |template_body_f_9198: (Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex)| {
                        let (parts_pb, l3_pc) = template_body_f_9198;
                        prism_rtl::Turn::Finished({
                            let mut this: CallRead = s_p6.clone();
                            this.body_o = Some(parts_pb.clone());
                            this.l_p = l3_pc.clone();
                            this.going_p = false;
                            this
                        })
                    })
                }
            } else {
                if !crate::syntax::lexer::chars::is_ident_start_f(&crate::syntax::lexer::chars::peek_f(&l_p5)) {
                    prism_rtl::Turn::Finished({
                        let mut this: CallRead = s_p6.clone();
                        this.l_p = crate::syntax::lexer::chars::lex_err_f(&l_p5, &at_p7, &(&at_p7 + &Nat::from(1u32)), &Text::lit("expected an attribute `name=value`, `/>` or `>` in a template call"));
                        this.going_p = false;
                        this
                    })
                } else {
                    {
                        let delims_p3x = delims_p3.clone();
                        let open_p4x = open_p4.clone();
                        let start_p1x = start_p1.clone();
                        crate::prelude::call_then(crate::syntax::lexer::words::start_lex_ident_f(l_p5.clone()), move |lex_ident_f_9597: (Text, crate::syntax::lexer::Lex)| {
                            let (aname_pd, l3_pe) = lex_ident_f_9597;
                            if &crate::syntax::lexer::chars::peek_f(&l3_pe) != &Text::lit("=") {
                                prism_rtl::Turn::Finished({
                                    let mut this: CallRead = s_p6.clone();
                                    this.l_p = crate::syntax::lexer::chars::lex_err_f(&l3_pe, &at_p7, &l3_pe.pos_p, &Text::lit("an attribute is `name=value`"));
                                    this
                                })
                            } else {
                                {
                                    let (tokens_pf, l4_pg) = attr_value_f(&crate::syntax::lexer::chars::bump_f(&l3_pe), &delims_p3x, &open_p4x);
                                    prism_rtl::Turn::Finished({
                                        let mut this: CallRead = s_p6.clone();
                                        this.attrs_p = crate::prelude::push(&this.attrs_p, &crate::syntax::lexer::AttrTok { name_p: aname_pd.clone(), tokens_p: tokens_pf.clone(), span_p: crate::syntax::Range { start_p: at_p7.clone(), end_p: l4_pg.pos_p.clone() } });
                                        this.l_p = l4_pg.clone();
                                        this
                                    })
                                }
                            }
                        })
                    }
                }
            }
        }
    }
}

/// `Start CallStep, x`: what the function value is when passed to `@Run`.
pub fn start_call_step_f(s0_p0: CallRead, start_p1: Nat, close_p2: Text, delims_p3: Text, open_p4: Text) -> Rc<dyn prism_rtl::Job<CallRead>> {
    Rc::new(CallStep { s0_p0, start_p1, close_p2, delims_p3, open_p4 })
}

/// ```prism
/// AttrValue: unbounded fn Lex, Text, Text -> (([Tok], Lex))
/// ```
pub fn attr_value_f(l_p0: &crate::syntax::lexer::Lex, delims_p1: &Text, open_p2: &Text) -> (Array<crate::syntax::lexer::Tok>, crate::syntax::lexer::Lex) {
    if crate::syntax::lexer::chars::starts_with_f(l_p0, open_p2) {
        crate::syntax::lexer::layout::nested_f(&crate::syntax::lexer::chars::forward_f(l_p0, &crate::prelude::len_text(open_p2)), &crate::syntax::lexer::Mode::MPlaceholder(delims_p1.clone()))
    } else {
        if &crate::syntax::lexer::chars::peek_f(l_p0) == &Text::lit("\"") {
            {
                let (text_p4, l2_p5) = crate::syntax::lexer::literals::lex_text_f(l_p0);
                let tok_p3 = crate::syntax::lexer::Tok { kind_p: crate::syntax::lexer::TokKind::KText(Text::lit(""), text_p4.clone()), span_p: crate::syntax::Range { start_p: l_p0.pos_p.clone(), end_p: l2_p5.pos_p.clone() }, touches_p: false, line_start_p: false };
                (Array::from(vec![tok_p3.clone()]), l2_p5.clone())
            }
        } else {
            (Array::new(), crate::syntax::lexer::chars::lex_err_f(l_p0, &l_p0.pos_p, &l_p0.pos_p, &Text::from(format!("an attribute\'s value is a placeholder `{}...` or a text literal", open_p2))))
        }
    }
}

/// ```prism
/// FinishTemplateLines: fn Lex, [RawLine], Nat, Bool -> (([TPartTok], Lex))
/// ```
pub fn finish_template_lines_f(l0_p0: &crate::syntax::lexer::Lex, lines_p1: &Array<RawLine>, strip_p2: &Nat, first_continues_p3: &bool) -> (Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex) {
    let mut this: (Array<crate::syntax::lexer::TPartTok>, crate::syntax::lexer::Lex) = (Array::new(), l0_p0.clone());
    let mut l_p4: crate::syntax::lexer::Lex = l0_p0.clone();
    let mut parts_p5: Array<crate::syntax::lexer::TPartTok> = Array::new();
    for (i10950, v10950) in lines_p1.clone().into_iter().enumerate() {
        let k10950 = crate::prelude::nat_of(i10950);
        let line_p6 = v10950.clone();
        if line_p6.block_p {
            parts_p5 = crate::prelude::append(&parts_p5, &block_parts_f(&line_p6.items_p));
        } else {
            let first_p7 = (&k10950 == &Nat::from(0u32)) && *first_continues_p3;
            let (items_p8, l2_p9) = if !first_p7 && (strip_p2 > &Nat::from(0u32)) {
                strip_line_f(&line_p6, strip_p2, &l_p4)
            } else {
                (line_p6.items_p.clone(), l_p4.clone())
            };
            l_p4 = l2_p9.clone();
            let non_blank_pc = crate::prelude::fold(&items_p8, &Array::new(), &(|acc_pa: &Array<RawItem>, it_pb: &RawItem| if is_blank_or_empty_f(it_pb) {
                acc_pa.clone()
            } else {
                crate::prelude::push(acc_pa, it_pb)
            }));
            let alone_pd = ((!first_p7 && line_p6.newline_p) && (&crate::prelude::len(&non_blank_pc) == &Nat::from(1u32))) && is_placeholder_item_f(&crate::prelude::or(&crate::prelude::index(&non_blank_pc, &Nat::from(0u32)), &RawItem::RiText(Text::lit(""))));
            if alone_pd {
                parts_p5 = crate::prelude::push(&parts_p5, &alone_placeholder_f(&items_p8));
            } else {
                parts_p5 = crate::prelude::fold(&items_p8, &parts_p5, &push_part_f);
                if line_p6.newline_p {
                    parts_p5 = push_part_f(&parts_p5, &RawItem::RiText(Text::lit("\n")));
                }
            }
        }
    }
    this = (parts_p5.clone(), l_p4.clone());
    this
}

/// ```prism
/// BlockParts: fn [RawItem] -> [TPartTok]
/// ```
pub fn block_parts_f(items_p0: &Array<RawItem>) -> Array<crate::syntax::lexer::TPartTok> {
    crate::prelude::fold(items_p0, &Array::new(), &(|acc_p1: &Array<crate::syntax::lexer::TPartTok>, it_p2: &RawItem| match it_p2 {
        RawItem::RiBlock(tokens_p3, span_p4) => crate::prelude::push(acc_p1, &crate::syntax::lexer::TPartTok::TptBlock(tokens_p3.clone(), span_p4.clone())),
        _ => acc_p1.clone(),
    }))
}

/// ```prism
/// StripLine: fn RawLine, Nat, Lex -> (([RawItem], Lex))
/// ```
pub fn strip_line_f(line_p0: &RawLine, strip_p1: &Nat, l_p2: &crate::syntax::lexer::Lex) -> (Array<RawItem>, crate::syntax::lexer::Lex) {
    let blank_p3 = only_whitespace_f(line_p0);
    let n_p4 = match crate::prelude::index(&line_p0.items_p, &Nat::from(0u32)) {
        Some(RawItem::RiText(s_p8)) => crate::syntax::lexer::chars::leading_in_f(&s_p8, &Text::lit(" ")),
        _ => Nat::from(0u32),
    };
    let items_p5 = match crate::prelude::index(&line_p0.items_p, &Nat::from(0u32)) {
        Some(RawItem::RiText(s_p9)) => {
            let rest_pa = match crate::prelude::cursor_at(&s_p9, &crate::prelude::min(&n_p4, strip_p1)) {
                Some(c_pb) => crate::prelude::after(&c_pb),
                None => s_p9.clone(),
            };
            crate::prelude::append(&Array::from(vec![RawItem::RiText(rest_pa.clone())]), &crate::prelude::drop(&line_p0.items_p, &Nat::from(1u32)))
        },
        _ => line_p0.items_p.clone(),
    };
    let l2_p6 = if (&n_p4 < strip_p1) && !blank_p3 {
        crate::syntax::lexer::chars::lex_err_f(l_p2, &first_item_span_f(&items_p5).start_p, &first_item_span_f(&items_p5).end_p, &Text::lit("a template line is indented less than its closing tag (Q-CT3)"))
    } else {
        l_p2.clone()
    };
    let kept_p7 = if &crate::prelude::index(&items_p5, &Nat::from(0u32)) == &Some(RawItem::RiText(Text::lit(""))) {
        crate::prelude::drop(&items_p5, &Nat::from(1u32))
    } else {
        items_p5.clone()
    };
    (kept_p7.clone(), l2_p6.clone())
}

/// ```prism
/// IsBlankOrEmpty: fn RawItem -> Bool
/// ```
pub fn is_blank_or_empty_f(raw_item0: &RawItem) -> bool {
    match raw_item0 {
        RawItem::RiText(s_p0) => &crate::syntax::lexer::chars::trim_f(s_p0) == &Text::lit(""),
        _ => false,
    }
}

/// ```prism
/// IsPlaceholderItem: fn RawItem -> Bool
/// ```
pub fn is_placeholder_item_f(raw_item0: &RawItem) -> bool {
    match raw_item0 {
        RawItem::RiPlaceholder(_, _) => true,
        _ => false,
    }
}

/// ```prism
/// FirstItemSpan: fn [RawItem] -> Range
/// ```
pub fn first_item_span_f(items_p0: &Array<RawItem>) -> crate::syntax::Range {
    crate::prelude::or(&crate::prelude::fold(items_p0, &None, &(|found_o1: &Option<crate::syntax::Range>, it_p2: &RawItem| if found_o1 != &None { found_o1.clone() } else { item_span_o(it_p2) })), &crate::syntax::Range { start_p: Nat::from(0u32), end_p: Nat::from(0u32) })
}

/// ```prism
/// ?ItemSpan: fn RawItem -> ?Range
/// ```
pub fn item_span_o(raw_item0: &RawItem) -> Option<crate::syntax::Range> {
    match raw_item0 {
        RawItem::RiPlaceholder(_, span_p0) => Some(span_p0.clone()),
        RawItem::RiBlock(_, span_p1) => Some(span_p1.clone()),
        RawItem::RiCall(_, _, _, span_p2) => Some(span_p2.clone()),
        _ => None,
    }
}

/// ```prism
/// AlonePlaceholder: fn [RawItem] -> TPartTok
/// ```
pub fn alone_placeholder_f(items_p0: &Array<RawItem>) -> crate::syntax::lexer::TPartTok {
    let (_, part_p4) = crate::prelude::fold(items_p0, &(Nat::from(0u32), crate::syntax::lexer::TPartTok::TptText(Text::lit(""))), &(|(c_p1, p_p2): &(Nat, crate::syntax::lexer::TPartTok), it_p3: &RawItem| alone_step_f(c_p1, p_p2, it_p3)));
    part_p4.clone()
}

/// ```prism
/// AloneStep: fn Nat, TPartTok, RawItem -> ((Nat, TPartTok))
/// ```
pub fn alone_step_f(c_p0: &Nat, tpart_tok1: &crate::syntax::lexer::TPartTok, raw_item2: &RawItem) -> (Nat, crate::syntax::lexer::TPartTok) {
    match (tpart_tok1, raw_item2) {
        (crate::syntax::lexer::TPartTok::TptText(c0_1_0), RawItem::RiText(s_p1)) if (c0_1_0 == &Text::lit("")) => if c_p0 == &Nat::from(0u32) {
            (crate::syntax::lexer::chars::leading_in_f(s_p1, &Text::lit(" ")), crate::syntax::lexer::TPartTok::TptText(Text::lit("")))
        } else {
            (c_p0.clone(), crate::syntax::lexer::TPartTok::TptText(Text::lit("")))
        },
        (crate::syntax::lexer::TPartTok::TptText(c1_1_0), RawItem::RiPlaceholder(tokens_p3, span_p4)) if (c1_1_0 == &Text::lit("")) => (c_p0.clone(), crate::syntax::lexer::TPartTok::TptPlaceholder(tokens_p3.clone(), Some(c_p0.clone()), span_p4.clone())),
        (p_p6, _) => (c_p0.clone(), p_p6.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// PushPart: fn [TPartTok], RawItem -> [TPartTok]
/// ```
pub fn push_part_f(parts_p0: &Array<crate::syntax::lexer::TPartTok>, raw_item1: &RawItem) -> Array<crate::syntax::lexer::TPartTok> {
    match raw_item1 {
        RawItem::RiText(c0_1_0) if (c0_1_0 == &Text::lit("")) => parts_p0.clone(),
        RawItem::RiText(t_p2) => match crate::syntax::lexer::chars::last_o(parts_p0) {
            Some(crate::syntax::lexer::TPartTok::TptText(s_p3)) => crate::prelude::push(&crate::syntax::lexer::chars::pop_f(parts_p0), &crate::syntax::lexer::TPartTok::TptText(Text::from(format!("{}{}", &s_p3, t_p2)))),
            _ => crate::prelude::push(parts_p0, &crate::syntax::lexer::TPartTok::TptText(t_p2.clone())),
        },
        RawItem::RiPlaceholder(tokens_p5, span_p6) => crate::prelude::push(parts_p0, &crate::syntax::lexer::TPartTok::TptPlaceholder(tokens_p5.clone(), None, span_p6.clone())),
        RawItem::RiBlock(tokens_p8, span_p9) => crate::prelude::push(parts_p0, &crate::syntax::lexer::TPartTok::TptBlock(tokens_p8.clone(), span_p9.clone())),
        RawItem::RiCall(name_pb, attrs_pc, body_od, span_pe) => crate::prelude::push(parts_p0, &crate::syntax::lexer::TPartTok::TptCall(name_pb.clone(), attrs_pc.clone(), body_od.clone(), span_pe.clone())),
        _ => unreachable!("no arm matched"),
    }
}
