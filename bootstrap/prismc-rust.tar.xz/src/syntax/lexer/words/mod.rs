//! The module `Syntax.Lexer.Words`, from `target/bootstrap/src/prismc/syntax/lexer/words.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// LexToken: unbounded fn Lex -> Lex
/// ```
pub fn lex_token(l0: &crate::syntax::lexer::Lex) -> crate::syntax::lexer::Lex {
    let start = l0.pos.clone();
    let c = crate::syntax::lexer::chars::peek(l0);
    let l = {
        let mut this: crate::syntax::lexer::Lex = l0.clone();
        this.path_next = false;
        this
    };
    if l0.path_next && ((crate::syntax::lexer::chars::is_digit(&c) || (&c == &Text::lit("#"))) || (&c == &Text::lit("["))) {
        lex_path_token(&l, &start)
    } else {
        lex_token_at(&l, &start, &c)
    }
}

/// The step machine of `LexToken`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexToken: unbounded fn Lex -> Lex
/// ```
pub struct LexToken {
    pub l0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for LexToken {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l0 = &self.l0;
        let start = l0.pos.clone();
        let c = crate::syntax::lexer::chars::peek(l0);
        let l = {
            let mut this: crate::syntax::lexer::Lex = l0.clone();
            this.path_next = false;
            this
        };
        if l0.path_next && ((crate::syntax::lexer::chars::is_digit(&c) || (&c == &Text::lit("#"))) || (&c == &Text::lit("["))) {
            prism_rtl::Turn::More(Rc::new(LexPathToken { l: l.clone(), start: start.clone() }))
        } else {
            prism_rtl::Turn::More(Rc::new(LexTokenAt { l: l.clone(), start: start.clone(), c: c.clone() }))
        }
    }
}

/// `Start LexToken, x`: what the function value is when passed to `@Run`.
pub fn start_lex_token(l0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(LexToken { l0 })
}

/// ```prism
/// LexPathToken: unbounded fn Lex, Nat -> Lex
/// ```
pub fn lex_path_token(l: &crate::syntax::lexer::Lex, start: &Nat) -> crate::syntax::lexer::Lex {
    let (segs, l2) = crate::syntax::lexer::literals::lex_path(l);
    crate::syntax::lexer::push_tok(&l2, &crate::syntax::lexer::TokKind::KPath(segs.clone()), start, &l2.pos)
}

/// The step machine of `LexPathToken`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexPathToken: unbounded fn Lex, Nat -> Lex
/// ```
pub struct LexPathToken {
    pub l: crate::syntax::lexer::Lex,
    pub start: Nat,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for LexPathToken {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l = &self.l;
        let start = &self.start;
        let l = l.clone();
        let start = start.clone();
        call_then(crate::syntax::lexer::literals::start_lex_path(l.clone()), move |lex_path_963: (Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex)| {
            let (segs, l2) = lex_path_963;
            prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok(&l2, &crate::syntax::lexer::TokKind::KPath(segs.clone()), &start, &l2.pos))
        })
    }
}

/// `Start LexPathToken, x`: what the function value is when passed to `@Run`.
pub fn start_lex_path_token(l: crate::syntax::lexer::Lex, start: Nat) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(LexPathToken { l, start })
}

/// ```prism
/// LexTokenAt: unbounded fn Lex, Nat, Text -> Lex
/// ```
pub fn lex_token_at(l: &crate::syntax::lexer::Lex, start: &Nat, c: &Text) -> crate::syntax::lexer::Lex {
    match c {
        m1093_0 if (m1093_0 == &Text::lit("\"")) => {
            let (text, l2) = crate::syntax::lexer::literals::lex_text(l);
            crate::syntax::lexer::push_tok(&l2, &crate::syntax::lexer::TokKind::KText(Text::lit(""), text.clone()), start, &l2.pos)
        },
        m1093_1 if (m1093_1 == &Text::lit("'")) => {
            let (ch, l2) = crate::syntax::lexer::literals::lex_char(l);
            crate::syntax::lexer::push_tok(&l2, &crate::syntax::lexer::TokKind::KChar(Text::lit(""), ch.clone()), start, &l2.pos)
        },
        _ if crate::syntax::lexer::chars::is_digit(c) => {
            let (kind, l2) = crate::syntax::lexer::literals::lex_number(l, &Text::lit(""));
            crate::syntax::lexer::push_tok(&l2, &kind, start, &l2.pos)
        },
        _ if crate::syntax::lexer::chars::is_ident_start(c) => lex_word_token(l, &Text::lit(""), start),
        _ if crate::syntax::lexer::chars::contains(&Text::lit("$@?~&^"), c) => lex_sigils(l),
        m1093_5 if (m1093_5 == &Text::lit("!")) => if &crate::syntax::lexer::chars::peek_at(l, &Nat::from(1u32)) == &Text::lit("=") {
            push_op_suffix(&crate::syntax::lexer::chars::forward(l, &Nat::from(2u32)), &Text::lit("!="), start)
        } else {
            lex_sigils(l)
        },
        _ if crate::syntax::lexer::chars::contains(&Text::lit("([{"), c) => lex_open(l, c, start),
        _ if crate::syntax::lexer::chars::contains(&Text::lit(")]}"), c) => lex_close(l, c, start),
        m1093_8 if (m1093_8 == &Text::lit(",")) => crate::syntax::lexer::push_tok(&crate::syntax::lexer::chars::bump(l), &crate::syntax::lexer::TokKind::KComma, start, &(start + &Nat::from(1u32))),
        m1093_9 if (m1093_9 == &Text::lit(":")) => crate::syntax::lexer::push_tok(&crate::syntax::lexer::chars::bump(l), &crate::syntax::lexer::TokKind::KColon, start, &(start + &Nat::from(1u32))),
        m1093_10 if (m1093_10 == &Text::lit(";")) => crate::syntax::lexer::push_tok(&crate::syntax::lexer::chars::bump(l), &crate::syntax::lexer::TokKind::KSemi, start, &(start + &Nat::from(1u32))),
        m1093_11 if (m1093_11 == &Text::lit("\\")) => lex_backslash(l, start),
        m1093_12 if (m1093_12 == &Text::lit("%")) => crate::syntax::lexer::regexes::lex_regex(l, &Text::lit(""), start),
        m1093_13 if (m1093_13 == &Text::lit("|")) => lex_bar(l, start),
        m1093_14 if (m1093_14 == &Text::lit(".")) => lex_dot(l, start),
        _ => match lex_operator(l, start) {
            Some(l2) => l2.clone(),
            None => {
                let l1 = crate::syntax::lexer::chars::bump(l);
                let l2 = crate::syntax::lexer::chars::lex_err(&l1, start, &l1.pos, &Text::from(format!("unexpected character `{}`", c)));
                {
                    let mut this: crate::syntax::lexer::Lex = l2.clone();
                    this.last_ws = true;
                    this
                }
            },
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `LexTokenAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexTokenAt: unbounded fn Lex, Nat, Text -> Lex
/// ```
pub struct LexTokenAt {
    pub l: crate::syntax::lexer::Lex,
    pub start: Nat,
    pub c: Text,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for LexTokenAt {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l = &self.l;
        let start = &self.start;
        let c = &self.c;
        match c {
            m1093_0 if (m1093_0 == &Text::lit("\"")) => {
                let l = l.clone();
                let start = start.clone();
                call_then(crate::syntax::lexer::literals::start_lex_text(l.clone()), move |lex_text_1139: (Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex)| {
                    let (text, l2) = lex_text_1139;
                    prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok(&l2, &crate::syntax::lexer::TokKind::KText(Text::lit(""), text.clone()), &start, &l2.pos))
                })
            },
            m1093_1 if (m1093_1 == &Text::lit("'")) => {
                let l = l.clone();
                let start = start.clone();
                call_then(crate::syntax::lexer::literals::start_lex_char(l.clone()), move |lex_char_1235: (Text, crate::syntax::lexer::Lex)| {
                    let (ch, l2) = lex_char_1235;
                    prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok(&l2, &crate::syntax::lexer::TokKind::KChar(Text::lit(""), ch.clone()), &start, &l2.pos))
                })
            },
            _ if crate::syntax::lexer::chars::is_digit(c) => {
                let l = l.clone();
                let start = start.clone();
                call_then(crate::syntax::lexer::literals::start_lex_number(l.clone(), Text::lit("")), move |lex_number_1347: (crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)| {
                    let (kind, l2) = lex_number_1347;
                    prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok(&l2, &kind, &start, &l2.pos))
                })
            },
            _ if crate::syntax::lexer::chars::is_ident_start(c) => prism_rtl::Turn::More(Rc::new(LexWordToken { l0: l.clone(), sigils: Text::lit(""), start: start.clone() })),
            _ if crate::syntax::lexer::chars::contains(&Text::lit("$@?~&^"), c) => prism_rtl::Turn::More(Rc::new(LexSigils { l0: l.clone() })),
            m1093_5 if (m1093_5 == &Text::lit("!")) => if &crate::syntax::lexer::chars::peek_at(l, &Nat::from(1u32)) == &Text::lit("=") {
                prism_rtl::Turn::More(Rc::new(PushOpSuffix { l: crate::syntax::lexer::chars::forward(l, &Nat::from(2u32)), op: Text::lit("!="), start: start.clone() }))
            } else {
                prism_rtl::Turn::More(Rc::new(LexSigils { l0: l.clone() }))
            },
            _ if crate::syntax::lexer::chars::contains(&Text::lit("([{"), c) => prism_rtl::Turn::Finished(lex_open(l, c, start)),
            _ if crate::syntax::lexer::chars::contains(&Text::lit(")]}"), c) => prism_rtl::Turn::Finished(lex_close(l, c, start)),
            m1093_8 if (m1093_8 == &Text::lit(",")) => prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok(&crate::syntax::lexer::chars::bump(l), &crate::syntax::lexer::TokKind::KComma, start, &(start + &Nat::from(1u32)))),
            m1093_9 if (m1093_9 == &Text::lit(":")) => prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok(&crate::syntax::lexer::chars::bump(l), &crate::syntax::lexer::TokKind::KColon, start, &(start + &Nat::from(1u32)))),
            m1093_10 if (m1093_10 == &Text::lit(";")) => prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok(&crate::syntax::lexer::chars::bump(l), &crate::syntax::lexer::TokKind::KSemi, start, &(start + &Nat::from(1u32)))),
            m1093_11 if (m1093_11 == &Text::lit("\\")) => prism_rtl::Turn::Finished(lex_backslash(l, start)),
            m1093_12 if (m1093_12 == &Text::lit("%")) => prism_rtl::Turn::More(Rc::new(crate::syntax::lexer::regexes::LexRegex { l: l.clone(), sigils: Text::lit(""), start: start.clone() })),
            m1093_13 if (m1093_13 == &Text::lit("|")) => prism_rtl::Turn::Finished(lex_bar(l, start)),
            m1093_14 if (m1093_14 == &Text::lit(".")) => prism_rtl::Turn::Finished(lex_dot(l, start)),
            _ => {
                let c = c.clone();
                let l = l.clone();
                let start = start.clone();
                call_then(start_lex_operator(l.clone(), start.clone()), move |lex_operator_1998: Option<crate::syntax::lexer::Lex>| match lex_operator_1998 {
                    Some(l2) => prism_rtl::Turn::Finished(l2.clone()),
                    None => {
                        let l1 = crate::syntax::lexer::chars::bump(&l);
                        let l2 = crate::syntax::lexer::chars::lex_err(&l1, &start, &l1.pos, &Text::from(format!("unexpected character `{}`", &c)));
                        prism_rtl::Turn::Finished({
                            let mut this: crate::syntax::lexer::Lex = l2.clone();
                            this.last_ws = true;
                            this
                        })
                    },
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start LexTokenAt, x`: what the function value is when passed to `@Run`.
pub fn start_lex_token_at(l: crate::syntax::lexer::Lex, start: Nat, c: Text) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(LexTokenAt { l, start, c })
}

/// ```prism
/// LexOpen: fn Lex, Text, Nat -> Lex
/// ```
pub fn lex_open(l: &crate::syntax::lexer::Lex, c: &Text, start: &Nat) -> crate::syntax::lexer::Lex {
    let prefix = ((c == &Text::lit("[")) && crate::syntax::lexer::prefix_position(l)) && !crate::syntax::lexer::chars::next_is_space(l, &Nat::from(1u32));
    let l2 = {
        let mut this: crate::syntax::lexer::Lex = crate::syntax::lexer::chars::bump(l);
        this.frames = push(&this.frames, c);
        this
    };
    crate::syntax::lexer::push_tok(&l2, &crate::syntax::lexer::TokKind::KOpen(c.clone(), prefix), start, &l2.pos)
}

/// ```prism
/// LexClose: fn Lex, Text, Nat -> Lex
/// ```
pub fn lex_close(l: &crate::syntax::lexer::Lex, c: &Text, start: &Nat) -> crate::syntax::lexer::Lex {
    let kind = crate::syntax::lexer::open_of(c);
    let l1 = crate::syntax::lexer::chars::bump(l);
    let l2 = match crate::syntax::lexer::chars::last(&l1.frames) {
        Some(k) if (&k == &kind) => {
            let mut this: crate::syntax::lexer::Lex = l1.clone();
            this.frames = crate::syntax::lexer::chars::pop(&this.frames);
            this
        },
        Some(m2675_1) if (&m2675_1 == &Text::lit("<<")) => crate::syntax::lexer::chars::lex_err(&l1, start, &l1.pos, &Text::from(format!("`{}` inside `<<`: expected `>>`", c))),
        Some(k) => {
            let l3 = crate::syntax::lexer::chars::lex_err(&l1, start, &l1.pos, &Text::from(format!("`{}` closes a `{}`", c, &k)));
            {
                let mut this: crate::syntax::lexer::Lex = l3.clone();
                this.frames = crate::syntax::lexer::chars::pop(&this.frames);
                this
            }
        },
        None => crate::syntax::lexer::chars::lex_err(&l1, start, &l1.pos, &Text::from(format!("`{}` closes nothing", c))),
        _ => unreachable!("no arm matched"),
    };
    crate::syntax::lexer::push_tok(&l2, &crate::syntax::lexer::TokKind::KClose(kind.clone()), start, &l2.pos)
}

/// ```prism
/// LexBackslash: fn Lex, Nat -> Lex
/// ```
pub fn lex_backslash(l: &crate::syntax::lexer::Lex, start: &Nat) -> crate::syntax::lexer::Lex {
    let l1 = crate::syntax::lexer::push_tok(&crate::syntax::lexer::chars::bump(l), &crate::syntax::lexer::TokKind::KBackslash, start, &(start + &Nat::from(1u32)));
    if &crate::syntax::lexer::chars::peek(&l1) == &Text::lit("|") {
        {
            let l2 = {
                let mut this: crate::syntax::lexer::Lex = crate::syntax::lexer::chars::bump(&l1);
                this.lambda_open = true;
                this
            };
            crate::syntax::lexer::push_tok(&l2, &crate::syntax::lexer::TokKind::KLambdaBar(true), &l1.pos, &(&l1.pos + &Nat::from(1u32)))
        }
    } else {
        l1.clone()
    }
}

/// ```prism
/// LexBar: fn Lex, Nat -> Lex
/// ```
pub fn lex_bar(l: &crate::syntax::lexer::Lex, start: &Nat) -> crate::syntax::lexer::Lex {
    let l1 = crate::syntax::lexer::chars::bump(l);
    if l1.lambda_open {
        {
            let l2 = {
                let mut this: crate::syntax::lexer::Lex = l1.clone();
                this.lambda_open = false;
                this
            };
            crate::syntax::lexer::push_tok(&l2, &crate::syntax::lexer::TokKind::KLambdaBar(false), start, &l2.pos)
        }
    } else {
        crate::syntax::lexer::push_tok(&l1, &crate::syntax::lexer::TokKind::KBar, start, &l1.pos)
    }
}

/// ```prism
/// LexDot: fn Lex, Nat -> Lex
/// ```
pub fn lex_dot(l: &crate::syntax::lexer::Lex, start: &Nat) -> crate::syntax::lexer::Lex {
    if crate::syntax::lexer::chars::starts_with(l, &Text::lit("..")) {
        crate::syntax::lexer::push_tok(&crate::syntax::lexer::chars::forward(l, &Nat::from(2u32)), &crate::syntax::lexer::TokKind::KDotDot, start, &(start + &Nat::from(2u32)))
    } else {
        {
            let prefix = crate::syntax::lexer::prefix_position(l) && !crate::syntax::lexer::chars::next_is_space(l, &Nat::from(1u32));
            let l1 = if prefix && crate::syntax::lexer::chars::is_digit(&crate::syntax::lexer::chars::peek_at(l, &Nat::from(1u32))) {
                crate::syntax::lexer::chars::lex_err(l, start, &(start + &Nat::from(1u32)), &Text::lit("a decimal literal has digits on both sides of its point: write `0.5`, not `.5`"))
            } else {
                l.clone()
            };
            crate::syntax::lexer::push_tok(&crate::syntax::lexer::chars::bump(&l1), &crate::syntax::lexer::TokKind::KDot(prefix), start, &(start + &Nat::from(1u32)))
        }
    }
}

/// ```prism
/// PushOpSuffix: unbounded fn Lex, Text, Nat -> Lex
/// ```
pub fn push_op_suffix(l: &crate::syntax::lexer::Lex, op: &Text, start: &Nat) -> crate::syntax::lexer::Lex {
    if crate::syntax::lexer::takes_suffix(op) && crate::syntax::lexer::chars::is_upper(&crate::syntax::lexer::chars::peek(l)) {
        {
            let (path_, l2) = lex_qualified_path(l);
            crate::syntax::lexer::push_tok(&l2, &crate::syntax::lexer::TokKind::KSuffixed(op.clone(), path_.clone()), start, &l2.pos)
        }
    } else {
        crate::syntax::lexer::push_tok(l, &crate::syntax::lexer::TokKind::KOp(op.clone(), false), start, &l.pos)
    }
}

/// The step machine of `PushOpSuffix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PushOpSuffix: unbounded fn Lex, Text, Nat -> Lex
/// ```
pub struct PushOpSuffix {
    pub l: crate::syntax::lexer::Lex,
    pub op: Text,
    pub start: Nat,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for PushOpSuffix {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l = &self.l;
        let op = &self.op;
        let start = &self.start;
        if crate::syntax::lexer::takes_suffix(op) && crate::syntax::lexer::chars::is_upper(&crate::syntax::lexer::chars::peek(l)) {
            {
                let l = l.clone();
                let op = op.clone();
                let start = start.clone();
                call_then(start_lex_qualified_path(l.clone()), move |lex_qualified_path_4539: (Array<Text>, crate::syntax::lexer::Lex)| {
                    let (path_, l2) = lex_qualified_path_4539;
                    prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok(&l2, &crate::syntax::lexer::TokKind::KSuffixed(op.clone(), path_.clone()), &start, &l2.pos))
                })
            }
        } else {
            prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok(l, &crate::syntax::lexer::TokKind::KOp(op.clone(), false), start, &l.pos))
        }
    }
}

/// `Start PushOpSuffix, x`: what the function value is when passed to `@Run`.
pub fn start_push_op_suffix(l: crate::syntax::lexer::Lex, op: Text, start: Nat) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(PushOpSuffix { l, op, start })
}

/// ```prism
/// FirstOp: fn Lex -> Text
/// ```
pub fn first_op(l: &crate::syntax::lexer::Lex) -> Text {
    let fat = crate::syntax::lexer::fat_arrow_on(l);
    fold(&crate::syntax::lexer::op_table(), &Text::lit(""), &(|found: &Text, s: &Text| if ((found == &Text::lit("")) && ((s != &Text::lit("=>")) || fat)) && crate::syntax::lexer::chars::starts_with(l, s) {
        s.clone()
    } else {
        found.clone()
    }))
}

/// ```prism
/// EndsMark: fn Text -> Bool
/// ```
pub fn ends_mark(a: &Text) -> bool {
    (a == &Text::lit("")) || crate::syntax::lexer::chars::contains(&Text::lit(" \n\r,)]}"), a)
}

/// ```prism
/// ClosesSquareOrBrace: fn ?Tok -> Bool
/// ```
pub fn closes_square_or_brace(opt0: &Option<crate::syntax::lexer::Tok>) -> bool {
    match opt0 {
        Some(t) => (&t.kind == &crate::syntax::lexer::TokKind::KClose(Text::lit("["))) || (&t.kind == &crate::syntax::lexer::TokKind::KClose(Text::lit("{"))),
        None => false,
    }
}

/// ```prism
/// ?LexOperator: unbounded fn Lex, Nat -> ?Lex
/// ```
pub fn lex_operator(l: &crate::syntax::lexer::Lex, start: &Nat) -> Option<crate::syntax::lexer::Lex> {
    let c = crate::syntax::lexer::chars::peek(l);
    let after_ = crate::syntax::lexer::chars::peek_at(l, &Nat::from(1u32));
    let non_empty = (((&c == &Text::lit("+")) && !l.last_ws) && closes_square_or_brace(&crate::syntax::lexer::chars::last(&l.tokens))) && (ends_mark(&after_) || ((&after_ == &Text::lit("?")) && ends_mark(&crate::syntax::lexer::chars::peek_at(l, &Nat::from(2u32)))));
    if (&c == &Text::lit("-")) && crate::syntax::lexer::chars::contains(&Text::lit(",)]}"), &after_) {
        Some(crate::syntax::lexer::push_tok(&crate::syntax::lexer::chars::bump(l), &crate::syntax::lexer::TokKind::KAbsent, start, &(start + &Nat::from(1u32))))
    } else {
        if non_empty {
            Some(non_empty_mark(l, start, &after_))
        } else {
            if crate::syntax::lexer::chars::starts_with(l, &Text::lit("<<")) {
                Some(open_type_args(l, start))
            } else {
                if crate::syntax::lexer::chars::starts_with(l, &Text::lit(">>")) && (&crate::syntax::lexer::chars::last(&l.frames) == &Some(Text::lit("<<"))) {
                    Some(close_type_args(l, start))
                } else {
                    if crate::syntax::lexer::chars::starts_with(l, &Text::lit(">>")) {
                        Some(crate::syntax::lexer::chars::lex_err(&crate::syntax::lexer::push_tok(&crate::syntax::lexer::chars::forward(l, &Nat::from(2u32)), &crate::syntax::lexer::TokKind::KGtGt, start, &(start + &Nat::from(2u32))), start, &(start + &Nat::from(2u32)), &Text::lit("`>>` closes explicit type arguments, and none is open (Prism has no shift operators)")))
                    } else {
                        match first_op(l) {
                            m6204_0 if (&m6204_0 == &Text::lit("")) => None,
                            op => Some(push_operator(l, &op, start)),
                            _ => unreachable!("no arm matched"),
                        }
                    }
                }
            }
        }
    }
}

/// The step machine of `LexOperator`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?LexOperator: unbounded fn Lex, Nat -> ?Lex
/// ```
pub struct LexOperator {
    pub l: crate::syntax::lexer::Lex,
    pub start: Nat,
}

impl prism_rtl::Job<Option<crate::syntax::lexer::Lex>> for LexOperator {
    fn cycle(&self) -> prism_rtl::Turn<Option<crate::syntax::lexer::Lex>> {
        let l = &self.l;
        let start = &self.start;
        let c = crate::syntax::lexer::chars::peek(l);
        let after_ = crate::syntax::lexer::chars::peek_at(l, &Nat::from(1u32));
        let non_empty = (((&c == &Text::lit("+")) && !l.last_ws) && closes_square_or_brace(&crate::syntax::lexer::chars::last(&l.tokens))) && (ends_mark(&after_) || ((&after_ == &Text::lit("?")) && ends_mark(&crate::syntax::lexer::chars::peek_at(l, &Nat::from(2u32)))));
        if (&c == &Text::lit("-")) && crate::syntax::lexer::chars::contains(&Text::lit(",)]}"), &after_) {
            prism_rtl::Turn::Finished(Some(crate::syntax::lexer::push_tok(&crate::syntax::lexer::chars::bump(l), &crate::syntax::lexer::TokKind::KAbsent, start, &(start + &Nat::from(1u32)))))
        } else {
            if non_empty {
                prism_rtl::Turn::Finished(Some(non_empty_mark(l, start, &after_)))
            } else {
                if crate::syntax::lexer::chars::starts_with(l, &Text::lit("<<")) {
                    prism_rtl::Turn::Finished(Some(open_type_args(l, start)))
                } else {
                    if crate::syntax::lexer::chars::starts_with(l, &Text::lit(">>")) && (&crate::syntax::lexer::chars::last(&l.frames) == &Some(Text::lit("<<"))) {
                        prism_rtl::Turn::Finished(Some(close_type_args(l, start)))
                    } else {
                        if crate::syntax::lexer::chars::starts_with(l, &Text::lit(">>")) {
                            prism_rtl::Turn::Finished(Some(crate::syntax::lexer::chars::lex_err(&crate::syntax::lexer::push_tok(&crate::syntax::lexer::chars::forward(l, &Nat::from(2u32)), &crate::syntax::lexer::TokKind::KGtGt, start, &(start + &Nat::from(2u32))), start, &(start + &Nat::from(2u32)), &Text::lit("`>>` closes explicit type arguments, and none is open (Prism has no shift operators)"))))
                        } else {
                            match first_op(l) {
                                m6204_0 if (&m6204_0 == &Text::lit("")) => prism_rtl::Turn::Finished(None),
                                op => prism_rtl::Turn::Finished(Some(push_operator(l, &op, start))),
                                _ => unreachable!("no arm matched"),
                            }
                        }
                    }
                }
            }
        }
    }
}

/// `Start LexOperator, x`: what the function value is when passed to `@Run`.
pub fn start_lex_operator(l: crate::syntax::lexer::Lex, start: Nat) -> Rc<dyn prism_rtl::Job<Option<crate::syntax::lexer::Lex>>> {
    Rc::new(LexOperator { l, start })
}

/// ```prism
/// NonEmptyMark: fn Lex, Nat, Text -> Lex
/// ```
pub fn non_empty_mark(l: &crate::syntax::lexer::Lex, start: &Nat, after_: &Text) -> crate::syntax::lexer::Lex {
    let l1 = crate::syntax::lexer::push_tok(&crate::syntax::lexer::chars::bump(l), &crate::syntax::lexer::TokKind::KNonEmpty, start, &(start + &Nat::from(1u32)));
    if after_ == &Text::lit("?") {
        crate::syntax::lexer::push_tok(&crate::syntax::lexer::chars::bump(&l1), &crate::syntax::lexer::TokKind::KFree(Text::lit("?")), &l1.pos, &(&l1.pos + &Nat::from(1u32)))
    } else {
        l1.clone()
    }
}

/// ```prism
/// OpenTypeArgs: fn Lex, Nat -> Lex
/// ```
pub fn open_type_args(l: &crate::syntax::lexer::Lex, start: &Nat) -> crate::syntax::lexer::Lex {
    let touching = !l.last_ws && is_name_tok(&crate::syntax::lexer::chars::last(&l.tokens));
    let l1 = crate::syntax::lexer::chars::forward(l, &Nat::from(2u32));
    let l2 = if touching {
        l1.clone()
    } else {
        crate::syntax::lexer::chars::lex_err(&l1, start, &l1.pos, &Text::lit("`<<` opens explicit type arguments and must touch a name on its left (Prism has no shift operators)"))
    };
    let l3 = {
        let mut this: crate::syntax::lexer::Lex = l2.clone();
        this.frames = push(&this.frames, &Text::lit("<<"));
        this
    };
    crate::syntax::lexer::push_tok(&l3, &crate::syntax::lexer::TokKind::KLtLt, start, &l3.pos)
}

/// ```prism
/// IsNameTok: fn ?Tok -> Bool
/// ```
pub fn is_name_tok(opt0: &Option<crate::syntax::lexer::Tok>) -> bool {
    match opt0 {
        Some(t) => match &t.kind {
            crate::syntax::lexer::TokKind::KName(_) => true,
            _ => false,
        },
        None => false,
    }
}

/// ```prism
/// CloseTypeArgs: fn Lex, Nat -> Lex
/// ```
pub fn close_type_args(l: &crate::syntax::lexer::Lex, start: &Nat) -> crate::syntax::lexer::Lex {
    let l1 = {
        let mut this: crate::syntax::lexer::Lex = crate::syntax::lexer::chars::forward(l, &Nat::from(2u32));
        this.frames = crate::syntax::lexer::chars::pop(&this.frames);
        this
    };
    crate::syntax::lexer::push_tok(&l1, &crate::syntax::lexer::TokKind::KGtGt, start, &l1.pos)
}

/// ```prism
/// PushOperator: unbounded fn Lex, Text, Nat -> Lex
/// ```
pub fn push_operator(l: &crate::syntax::lexer::Lex, op: &Text, start: &Nat) -> crate::syntax::lexer::Lex {
    let l1 = crate::syntax::lexer::chars::forward(l, &len_text(op));
    if (((op == &Text::lit("+")) || (op == &Text::lit("-"))) || (op == &Text::lit("-?"))) && !crate::syntax::lexer::chars::is_upper(&crate::syntax::lexer::chars::peek(&l1)) {
        crate::syntax::lexer::push_tok(&l1, &crate::syntax::lexer::TokKind::KOp(op.clone(), crate::syntax::lexer::prefix_position(&l1) && !crate::syntax::lexer::chars::next_is_space(&l1, &Nat::from(0u32))), start, &l1.pos)
    } else {
        push_op_suffix(&l1, op, start)
    }
}

/// The step machine of `PushOperator`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PushOperator: unbounded fn Lex, Text, Nat -> Lex
/// ```
pub struct PushOperator {
    pub l: crate::syntax::lexer::Lex,
    pub op: Text,
    pub start: Nat,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for PushOperator {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l = &self.l;
        let op = &self.op;
        let start = &self.start;
        let l1 = crate::syntax::lexer::chars::forward(l, &len_text(op));
        if (((op == &Text::lit("+")) || (op == &Text::lit("-"))) || (op == &Text::lit("-?"))) && !crate::syntax::lexer::chars::is_upper(&crate::syntax::lexer::chars::peek(&l1)) {
            prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok(&l1, &crate::syntax::lexer::TokKind::KOp(op.clone(), crate::syntax::lexer::prefix_position(&l1) && !crate::syntax::lexer::chars::next_is_space(&l1, &Nat::from(0u32))), start, &l1.pos))
        } else {
            prism_rtl::Turn::More(Rc::new(PushOpSuffix { l: l1.clone(), op: op.clone(), start: start.clone() }))
        }
    }
}

/// `Start PushOperator, x`: what the function value is when passed to `@Run`.
pub fn start_push_operator(l: crate::syntax::lexer::Lex, op: Text, start: Nat) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(PushOperator { l, op, start })
}

/// ```prism
/// LexSigils: unbounded fn Lex -> Lex
/// ```
pub fn lex_sigils(l0: &crate::syntax::lexer::Lex) -> crate::syntax::lexer::Lex {
    let start = l0.pos.clone();
    let (sigils, caret, l) = read_sigils(l0);
    let next = crate::syntax::lexer::chars::peek(&l);
    if caret {
        lex_caret(&l, &start, &sigils, &next)
    } else {
        if ((crate::syntax::lexer::chars::is_ident_start(&next) || crate::syntax::lexer::chars::is_digit(&next)) || (&next == &Text::lit("\""))) || (&next == &Text::lit("%")) {
            lex_attached(&l, &start, &sigils, &next)
        } else {
            if ((&sigils == &Text::lit("&")) && (&next == &Text::lit("."))) && crate::syntax::lexer::chars::is_lower(&crate::syntax::lexer::chars::peek_at(&l, &Nat::from(1u32))) {
                crate::syntax::lexer::push_tok(&crate::syntax::lexer::chars::bump(&l), &crate::syntax::lexer::TokKind::KLensDot, &start, &(&l.pos + &Nat::from(1u32)))
            } else {
                free_sigils(&l, &start, &sigils)
            }
        }
    }
}

/// The step machine of `LexSigils`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexSigils: unbounded fn Lex -> Lex
/// ```
pub struct LexSigils {
    pub l0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for LexSigils {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l0 = &self.l0;
        let start = l0.pos.clone();
        let l0 = l0.clone();
        call_then(start_read_sigils(l0.clone()), move |read_sigils_8444: (Text, bool, crate::syntax::lexer::Lex)| {
            let (sigils, caret, l) = read_sigils_8444;
            let next = crate::syntax::lexer::chars::peek(&l);
            if caret {
                prism_rtl::Turn::More(Rc::new(LexCaret { l: l.clone(), start: start.clone(), sigils: sigils.clone(), next: next.clone() }))
            } else {
                if ((crate::syntax::lexer::chars::is_ident_start(&next) || crate::syntax::lexer::chars::is_digit(&next)) || (&next == &Text::lit("\""))) || (&next == &Text::lit("%")) {
                    prism_rtl::Turn::More(Rc::new(LexAttached { l: l.clone(), start: start.clone(), sigils: sigils.clone(), next: next.clone() }))
                } else {
                    if ((&sigils == &Text::lit("&")) && (&next == &Text::lit("."))) && crate::syntax::lexer::chars::is_lower(&crate::syntax::lexer::chars::peek_at(&l, &Nat::from(1u32))) {
                        prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok(&crate::syntax::lexer::chars::bump(&l), &crate::syntax::lexer::TokKind::KLensDot, &start, &(&l.pos + &Nat::from(1u32))))
                    } else {
                        prism_rtl::Turn::Finished(free_sigils(&l, &start, &sigils))
                    }
                }
            }
        })
    }
}

/// `Start LexSigils, x`: what the function value is when passed to `@Run`.
pub fn start_lex_sigils(l0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(LexSigils { l0 })
}

/// ```prism
/// ReadSigils: unbounded fn Lex -> ((Text, Bool, Lex))
/// ```
pub fn read_sigils(l0: &crate::syntax::lexer::Lex) -> (Text, bool, crate::syntax::lexer::Lex) {
    let mut this: (Text, bool, crate::syntax::lexer::Lex) = (Text::lit(""), false, l0.clone());
    let mut l: crate::syntax::lexer::Lex = l0.clone();
    let mut sigils: Text = Text::lit("");
    let mut caret: bool = false;
    let mut going: bool = true;
    while going {
        let c = crate::syntax::lexer::chars::peek(&l);
        if &c == &Text::lit("^") {
            l = crate::syntax::lexer::chars::bump(&l);
            caret = true;
            going = false;
        } else if crate::syntax::lexer::chars::is_sigil_char(&c) && !((&c == &Text::lit("!")) && (&crate::syntax::lexer::chars::peek_at(&l, &Nat::from(1u32)) == &Text::lit("="))) {
            l = crate::syntax::lexer::chars::bump(&l);
            sigils = Text::from(format!("{}{}", &sigils, &c));
        } else {
            going = false;
        }
    }
    this = (sigils.clone(), caret, l.clone());
    this
}

/// The step machine of `ReadSigils`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadSigils: unbounded fn Lex -> ((Text, Bool, Lex))
/// ```
pub struct ReadSigils {
    pub l0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<(Text, bool, crate::syntax::lexer::Lex)> for ReadSigils {
    fn cycle(&self) -> prism_rtl::Turn<(Text, bool, crate::syntax::lexer::Lex)> {
        let l0 = &self.l0;
        let mut this: (Text, bool, crate::syntax::lexer::Lex) = (Text::lit(""), false, l0.clone());
        let mut l: crate::syntax::lexer::Lex = l0.clone();
        let mut sigils: Text = Text::lit("");
        let mut caret: bool = false;
        let mut going: bool = true;
        call_then(loop_job((this, caret, going, l, sigils), move |(mut this, mut caret, mut going, mut l, mut sigils): ((Text, bool, crate::syntax::lexer::Lex), bool, bool, crate::syntax::lexer::Lex, Text)| if going {
            {
                let c = crate::syntax::lexer::chars::peek(&l);
                if &c == &Text::lit("^") {
                    l = crate::syntax::lexer::chars::bump(&l);
                    caret = true;
                    going = false;
                } else if crate::syntax::lexer::chars::is_sigil_char(&c) && !((&c == &Text::lit("!")) && (&crate::syntax::lexer::chars::peek_at(&l, &Nat::from(1u32)) == &Text::lit("="))) {
                    l = crate::syntax::lexer::chars::bump(&l);
                    sigils = Text::from(format!("{}{}", &sigils, &c));
                } else {
                    going = false;
                }
                Ok((this, caret, going, l, sigils))
            }
        } else {
            Err((this, caret, going, l, sigils))
        }), move |(mut this, mut caret, mut going, mut l, mut sigils): ((Text, bool, crate::syntax::lexer::Lex), bool, bool, crate::syntax::lexer::Lex, Text)| {
            this = (sigils.clone(), caret, l.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start ReadSigils, x`: what the function value is when passed to `@Run`.
pub fn start_read_sigils(l0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<(Text, bool, crate::syntax::lexer::Lex)>> {
    Rc::new(ReadSigils { l0 })
}

/// ```prism
/// LexCaret: unbounded fn Lex, Nat, Text, Text -> Lex
/// ```
pub fn lex_caret(l: &crate::syntax::lexer::Lex, start: &Nat, sigils: &Text, next: &Text) -> crate::syntax::lexer::Lex {
    if crate::syntax::lexer::chars::is_upper(next) && (sigils == &Text::lit("")) {
        {
            let (path_, l2) = lex_qualified_path(l);
            crate::syntax::lexer::push_tok(&l2, &crate::syntax::lexer::TokKind::KTrait(path_.clone()), start, &l2.pos)
        }
    } else {
        {
            let (_, skipped) = lex_qualified_path(l);
            let l2 = if crate::syntax::lexer::chars::is_ident_start(next) {
                skipped.clone()
            } else {
                l.clone()
            };
            crate::syntax::lexer::chars::lex_err(&l2, start, &max(&l2.pos, &l.pos), &Text::lit("`^` marks a trait and attaches to its uppercase name: no trait is a value"))
        }
    }
}

/// The step machine of `LexCaret`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexCaret: unbounded fn Lex, Nat, Text, Text -> Lex
/// ```
pub struct LexCaret {
    pub l: crate::syntax::lexer::Lex,
    pub start: Nat,
    pub sigils: Text,
    pub next: Text,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for LexCaret {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l = &self.l;
        let start = &self.start;
        let sigils = &self.sigils;
        let next = &self.next;
        if crate::syntax::lexer::chars::is_upper(next) && (sigils == &Text::lit("")) {
            {
                let l = l.clone();
                let start = start.clone();
                call_then(start_lex_qualified_path(l.clone()), move |lex_qualified_path_9648: (Array<Text>, crate::syntax::lexer::Lex)| {
                    let (path_, l2) = lex_qualified_path_9648;
                    prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok(&l2, &crate::syntax::lexer::TokKind::KTrait(path_.clone()), &start, &l2.pos))
                })
            }
        } else {
            {
                let l = l.clone();
                let next = next.clone();
                let start = start.clone();
                call_then(start_lex_qualified_path(l.clone()), move |lex_qualified_path_9760: (Array<Text>, crate::syntax::lexer::Lex)| {
                    let (_, skipped) = lex_qualified_path_9760;
                    let l2 = if crate::syntax::lexer::chars::is_ident_start(&next) {
                        skipped.clone()
                    } else {
                        l.clone()
                    };
                    prism_rtl::Turn::Finished(crate::syntax::lexer::chars::lex_err(&l2, &start, &max(&l2.pos, &l.pos), &Text::lit("`^` marks a trait and attaches to its uppercase name: no trait is a value")))
                })
            }
        }
    }
}

/// `Start LexCaret, x`: what the function value is when passed to `@Run`.
pub fn start_lex_caret(l: crate::syntax::lexer::Lex, start: Nat, sigils: Text, next: Text) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(LexCaret { l, start, sigils, next })
}

/// ```prism
/// LexAttached: unbounded fn Lex, Nat, Text, Text -> Lex
/// ```
pub fn lex_attached(l: &crate::syntax::lexer::Lex, start: &Nat, sigils: &Text, next: &Text) -> crate::syntax::lexer::Lex {
    if next == &Text::lit("\"") {
        {
            let (text, l2) = crate::syntax::lexer::literals::lex_text(l);
            crate::syntax::lexer::push_tok(&l2, &crate::syntax::lexer::TokKind::KText(sigils.clone(), text.clone()), start, &l2.pos)
        }
    } else {
        if crate::syntax::lexer::chars::is_digit(next) {
            {
                let (kind, l2) = crate::syntax::lexer::literals::lex_number(l, sigils);
                crate::syntax::lexer::push_tok(&l2, &kind, start, &l2.pos)
            }
        } else {
            if next == &Text::lit("%") {
                crate::syntax::lexer::regexes::lex_regex(l, sigils, start)
            } else {
                lex_word_token(l, sigils, start)
            }
        }
    }
}

/// The step machine of `LexAttached`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexAttached: unbounded fn Lex, Nat, Text, Text -> Lex
/// ```
pub struct LexAttached {
    pub l: crate::syntax::lexer::Lex,
    pub start: Nat,
    pub sigils: Text,
    pub next: Text,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for LexAttached {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l = &self.l;
        let start = &self.start;
        let sigils = &self.sigils;
        let next = &self.next;
        if next == &Text::lit("\"") {
            {
                let l = l.clone();
                let sigils = sigils.clone();
                let start = start.clone();
                call_then(crate::syntax::lexer::literals::start_lex_text(l.clone()), move |lex_text_10099: (Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex)| {
                    let (text, l2) = lex_text_10099;
                    prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok(&l2, &crate::syntax::lexer::TokKind::KText(sigils.clone(), text.clone()), &start, &l2.pos))
                })
            }
        } else {
            if crate::syntax::lexer::chars::is_digit(next) {
                {
                    let l = l.clone();
                    let sigils = sigils.clone();
                    let start = start.clone();
                    call_then(crate::syntax::lexer::literals::start_lex_number(l.clone(), sigils.clone()), move |lex_number_10219: (crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)| {
                        let (kind, l2) = lex_number_10219;
                        prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok(&l2, &kind, &start, &l2.pos))
                    })
                }
            } else {
                if next == &Text::lit("%") {
                    prism_rtl::Turn::More(Rc::new(crate::syntax::lexer::regexes::LexRegex { l: l.clone(), sigils: sigils.clone(), start: start.clone() }))
                } else {
                    prism_rtl::Turn::More(Rc::new(LexWordToken { l0: l.clone(), sigils: sigils.clone(), start: start.clone() }))
                }
            }
        }
    }
}

/// `Start LexAttached, x`: what the function value is when passed to `@Run`.
pub fn start_lex_attached(l: crate::syntax::lexer::Lex, start: Nat, sigils: Text, next: Text) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(LexAttached { l, start, sigils, next })
}

/// ```prism
/// FreeSigils: fn Lex, Nat, Text -> Lex
/// ```
pub fn free_sigils(l0: &crate::syntax::lexer::Lex, start: &Nat, sigils: &Text) -> crate::syntax::lexer::Lex {
    let mut this: crate::syntax::lexer::Lex = l0.clone();
    let space_after = crate::syntax::lexer::chars::next_is_space(&this, &Nat::from(0u32));
    let all = crate::syntax::lexer::chars::fold_chars(sigils, &Array::new(), &(Rc::new(move |(p0, p1): (Array<Text>, Text)| once_job(move || {
        let acc = p0;
        let c = p1;
        prism_rtl::Turn::Finished(push(&acc, &c))
    })) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    for (i10699, v10699) in all.clone().into_iter().enumerate() {
        let k10699 = nat_of(i10699);
        let s = v10699.clone();
        let at_ = start + &k10699;
        if space_after && (&(&k10699 + &Nat::from(1u32)) == &len(&all)) {
            if &s == &Text::lit("!") {
                this = crate::syntax::lexer::chars::lex_err(&this, &at_, &(&at_ + &Nat::from(1u32)), &Text::lit("`!` is never free: no event fires a constant (write `!e` touching its name)"));
            }
            if &s == &Text::lit("&") {
                this = crate::syntax::lexer::chars::lex_err(&this, &at_, &(&at_ + &Nat::from(1u32)), &Text::lit("`&` is never free: no reference exists outside the value an `update` block names"));
            }
        }
        this = crate::syntax::lexer::push_tok(&this, &crate::syntax::lexer::TokKind::KFree(s.clone()), &at_, &(&at_ + &Nat::from(1u32)));
    }
    this
}

/// ```prism
/// LexQualifiedPath: unbounded fn Lex -> (([Text], Lex))
/// ```
pub fn lex_qualified_path(l0: &crate::syntax::lexer::Lex) -> (Array<Text>, crate::syntax::lexer::Lex) {
    let mut this: (Array<Text>, crate::syntax::lexer::Lex) = (Array::new(), l0.clone());
    let (first_, l1) = lex_ident(l0);
    let mut path_: Array<Text> = Array::from(vec![first_.clone()]);
    let mut l: crate::syntax::lexer::Lex = l1.clone();
    let mut going: bool = true;
    while going {
        let last = or(&crate::syntax::lexer::chars::last(&path_), &Text::lit(""));
        let next = crate::syntax::lexer::chars::peek_at(&l, &Nat::from(1u32));
        if (&crate::syntax::lexer::chars::peek(&l) != &Text::lit(".")) || !crate::syntax::lexer::chars::is_upper(&crate::syntax::lexer::chars::head(&last)) {
            going = false;
        } else if crate::syntax::lexer::chars::is_upper(&next) {
            let (seg, l2) = lex_ident(&crate::syntax::lexer::chars::bump(&l));
            path_ = push(&path_, &seg);
            l = l2.clone();
        } else {
            going = false;
            if crate::syntax::lexer::chars::is_ident_start(&next) {
                let (w, l2) = lex_ident(&crate::syntax::lexer::chars::bump(&l));
                if crate::syntax::lexer::chars::is_reserved_ctor(&w) {
                    path_ = push(&path_, &w);
                    l = l2.clone();
                }
            }
        }
    }
    this = (path_.clone(), l.clone());
    this
}

/// The step machine of `LexQualifiedPath`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexQualifiedPath: unbounded fn Lex -> (([Text], Lex))
/// ```
pub struct LexQualifiedPath {
    pub l0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<(Array<Text>, crate::syntax::lexer::Lex)> for LexQualifiedPath {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Text>, crate::syntax::lexer::Lex)> {
        let l0 = &self.l0;
        let mut this: (Array<Text>, crate::syntax::lexer::Lex) = (Array::new(), l0.clone());
        let (first_, l1) = lex_ident(l0);
        let mut path_: Array<Text> = Array::from(vec![first_.clone()]);
        let mut l: crate::syntax::lexer::Lex = l1.clone();
        let mut going: bool = true;
        call_then(loop_job((this, going, l, path_), move |(mut this, mut going, mut l, mut path_): ((Array<Text>, crate::syntax::lexer::Lex), bool, crate::syntax::lexer::Lex, Array<Text>)| if going {
            {
                let last = or(&crate::syntax::lexer::chars::last(&path_), &Text::lit(""));
                let next = crate::syntax::lexer::chars::peek_at(&l, &Nat::from(1u32));
                if (&crate::syntax::lexer::chars::peek(&l) != &Text::lit(".")) || !crate::syntax::lexer::chars::is_upper(&crate::syntax::lexer::chars::head(&last)) {
                    going = false;
                } else if crate::syntax::lexer::chars::is_upper(&next) {
                    let (seg, l2) = lex_ident(&crate::syntax::lexer::chars::bump(&l));
                    path_ = push(&path_, &seg);
                    l = l2.clone();
                } else {
                    going = false;
                    if crate::syntax::lexer::chars::is_ident_start(&next) {
                        let (w, l2) = lex_ident(&crate::syntax::lexer::chars::bump(&l));
                        if crate::syntax::lexer::chars::is_reserved_ctor(&w) {
                            path_ = push(&path_, &w);
                            l = l2.clone();
                        }
                    }
                }
                Ok((this, going, l, path_))
            }
        } else {
            Err((this, going, l, path_))
        }), move |(mut this, mut going, mut l, mut path_): ((Array<Text>, crate::syntax::lexer::Lex), bool, crate::syntax::lexer::Lex, Array<Text>)| {
            this = (path_.clone(), l.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start LexQualifiedPath, x`: what the function value is when passed to `@Run`.
pub fn start_lex_qualified_path(l0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<(Array<Text>, crate::syntax::lexer::Lex)>> {
    Rc::new(LexQualifiedPath { l0 })
}

/// ```prism
/// LexIdent: unbounded fn Lex -> ((Text, Lex))
/// ```
pub fn lex_ident(l0: &crate::syntax::lexer::Lex) -> (Text, crate::syntax::lexer::Lex) {
    let l = {
        let mut this: crate::syntax::lexer::Lex = l0.clone();
        while crate::syntax::lexer::chars::is_ident_char(&crate::syntax::lexer::chars::peek(&this)) {
            this.pos = &this.pos + &Nat::from(1u32);
        }
        this
    };
    let word = crate::syntax::lexer::chars::slice(&l, &l0.pos, &l.pos);
    (word.clone(), l.clone())
}

/// The step machine of `LexIdent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexIdent: unbounded fn Lex -> ((Text, Lex))
/// ```
pub struct LexIdent {
    pub l0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<(Text, crate::syntax::lexer::Lex)> for LexIdent {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::syntax::lexer::Lex)> {
        let l0 = &self.l0;
        let mut this: crate::syntax::lexer::Lex = l0.clone();
        let l0 = l0.clone();
        call_then(loop_job((this,), move |(mut this,): (crate::syntax::lexer::Lex,)| if crate::syntax::lexer::chars::is_ident_char(&crate::syntax::lexer::chars::peek(&this)) {
            {
                this.pos = &this.pos + &Nat::from(1u32);
                Ok((this,))
            }
        } else {
            Err((this,))
        }), move |(mut this,): (crate::syntax::lexer::Lex,)| {
            let l = this;
            let word = crate::syntax::lexer::chars::slice(&l, &l0.pos, &l.pos);
            prism_rtl::Turn::Finished((word.clone(), l.clone()))
        })
    }
}

/// `Start LexIdent, x`: what the function value is when passed to `@Run`.
pub fn start_lex_ident(l0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<(Text, crate::syntax::lexer::Lex)>> {
    Rc::new(LexIdent { l0 })
}

/// ```prism
/// LexWordToken: unbounded fn Lex, Text, Nat -> Lex
/// ```
pub fn lex_word_token(l0: &crate::syntax::lexer::Lex, sigils: &Text, start: &Nat) -> crate::syntax::lexer::Lex {
    let w_start = l0.pos.clone();
    let (path_, l1) = lex_qualified_path(l0);
    let l = if crate::syntax::lexer::chars::is_non_ascii(&crate::syntax::lexer::chars::peek(&l1)) {
        skip_non_ascii(&l1, &w_start)
    } else {
        l1.clone()
    };
    let first_ = or(&index(&path_, &Nat::from(0u32)), &Text::lit(""));
    if crate::syntax::lexer::chars::starts_with(&l, &Text::lit(".*")) && crate::syntax::lexer::chars::is_upper(&crate::syntax::lexer::chars::head(&first_)) {
        {
            let l2 = crate::syntax::lexer::chars::forward(&l, &Nat::from(2u32));
            let l3 = if sigils != &Text::lit("") {
                crate::syntax::lexer::chars::lex_err(&l2, start, &l2.pos, &Text::lit("a family pattern takes no sigil"))
            } else {
                l2.clone()
            };
            crate::syntax::lexer::push_tok(&l3, &crate::syntax::lexer::TokKind::KFamily(path_.clone()), start, &l3.pos)
        }
    } else {
        if ((&len(&path_) == &Nat::from(1u32)) && crate::syntax::lexer::is_keyword(&first_)) && !(crate::syntax::lexer::is_bound_word(&first_) && (sigils != &Text::lit(""))) {
            lex_keyword(&l, &first_, sigils, start)
        } else {
            lex_name(&l, &path_, sigils, start, &w_start)
        }
    }
}

/// The step machine of `LexWordToken`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexWordToken: unbounded fn Lex, Text, Nat -> Lex
/// ```
pub struct LexWordToken {
    pub l0: crate::syntax::lexer::Lex,
    pub sigils: Text,
    pub start: Nat,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for LexWordToken {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l0 = &self.l0;
        let sigils = &self.sigils;
        let start = &self.start;
        let w_start = l0.pos.clone();
        let l0 = l0.clone();
        let sigils = sigils.clone();
        let start = start.clone();
        call_then(start_lex_qualified_path(l0.clone()), move |lex_qualified_path_12573: (Array<Text>, crate::syntax::lexer::Lex)| {
            let (path_, l1) = lex_qualified_path_12573;
            let l = if crate::syntax::lexer::chars::is_non_ascii(&crate::syntax::lexer::chars::peek(&l1)) {
                skip_non_ascii(&l1, &w_start)
            } else {
                l1.clone()
            };
            let first_ = or(&index(&path_, &Nat::from(0u32)), &Text::lit(""));
            if crate::syntax::lexer::chars::starts_with(&l, &Text::lit(".*")) && crate::syntax::lexer::chars::is_upper(&crate::syntax::lexer::chars::head(&first_)) {
                {
                    let l2 = crate::syntax::lexer::chars::forward(&l, &Nat::from(2u32));
                    let l3 = if &sigils != &Text::lit("") {
                        crate::syntax::lexer::chars::lex_err(&l2, &start, &l2.pos, &Text::lit("a family pattern takes no sigil"))
                    } else {
                        l2.clone()
                    };
                    prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok(&l3, &crate::syntax::lexer::TokKind::KFamily(path_.clone()), &start, &l3.pos))
                }
            } else {
                if ((&len(&path_) == &Nat::from(1u32)) && crate::syntax::lexer::is_keyword(&first_)) && !(crate::syntax::lexer::is_bound_word(&first_) && (&sigils != &Text::lit(""))) {
                    prism_rtl::Turn::More(Rc::new(LexKeyword { l: l.clone(), w: first_.clone(), sigils: sigils.clone(), start: start.clone() }))
                } else {
                    prism_rtl::Turn::More(Rc::new(LexName { l: l.clone(), path_: path_.clone(), sigils: sigils.clone(), start: start.clone(), w_start: w_start.clone() }))
                }
            }
        })
    }
}

/// `Start LexWordToken, x`: what the function value is when passed to `@Run`.
pub fn start_lex_word_token(l0: crate::syntax::lexer::Lex, sigils: Text, start: Nat) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(LexWordToken { l0, sigils, start })
}

/// ```prism
/// SkipNonAscii: unbounded fn Lex, Nat -> Lex
/// ```
pub fn skip_non_ascii(l0: &crate::syntax::lexer::Lex, w_start: &Nat) -> crate::syntax::lexer::Lex {
    let l = {
        let mut this: crate::syntax::lexer::Lex = l0.clone();
        while crate::syntax::lexer::chars::is_ident_char(&crate::syntax::lexer::chars::peek(&this)) || crate::syntax::lexer::chars::is_non_ascii(&crate::syntax::lexer::chars::peek(&this)) {
            this.pos = &this.pos + &len_text(&crate::syntax::lexer::chars::peek(&this));
        }
        this
    };
    crate::syntax::lexer::chars::lex_err(&l, w_start, &l.pos, &Text::lit("names are ASCII letters, digits and underscores"))
}

/// The step machine of `SkipNonAscii`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SkipNonAscii: unbounded fn Lex, Nat -> Lex
/// ```
pub struct SkipNonAscii {
    pub l0: crate::syntax::lexer::Lex,
    pub w_start: Nat,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for SkipNonAscii {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l0 = &self.l0;
        let w_start = &self.w_start;
        let mut this: crate::syntax::lexer::Lex = l0.clone();
        let w_start = w_start.clone();
        call_then(loop_job((this,), move |(mut this,): (crate::syntax::lexer::Lex,)| if crate::syntax::lexer::chars::is_ident_char(&crate::syntax::lexer::chars::peek(&this)) || crate::syntax::lexer::chars::is_non_ascii(&crate::syntax::lexer::chars::peek(&this)) {
            {
                this.pos = &this.pos + &len_text(&crate::syntax::lexer::chars::peek(&this));
                Ok((this,))
            }
        } else {
            Err((this,))
        }), move |(mut this,): (crate::syntax::lexer::Lex,)| {
            let l = this;
            prism_rtl::Turn::Finished(crate::syntax::lexer::chars::lex_err(&l, &w_start, &l.pos, &Text::lit("names are ASCII letters, digits and underscores")))
        })
    }
}

/// `Start SkipNonAscii, x`: what the function value is when passed to `@Run`.
pub fn start_skip_non_ascii(l0: crate::syntax::lexer::Lex, w_start: Nat) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(SkipNonAscii { l0, w_start })
}

/// ```prism
/// LexKeyword: unbounded fn Lex, Text, Text, Nat -> Lex
/// ```
pub fn lex_keyword(l: &crate::syntax::lexer::Lex, w: &Text, sigils: &Text, start: &Nat) -> crate::syntax::lexer::Lex {
    let l1 = if (sigils != &Text::lit("")) && !(((w == &Text::lit("widget")) || (w == &Text::lit("unit"))) || (w == &Text::lit("nil"))) {
        crate::syntax::lexer::chars::lex_err(l, start, &l.pos, &Text::from(format!("`{}` is a keyword and takes no sigil", w)))
    } else {
        l.clone()
    };
    let l2 = if (w == &Text::lit("widget")) && (sigils != &Text::lit("@")) {
        crate::syntax::lexer::chars::lex_err(&l1, start, &l1.pos, &Text::lit("`widget` is a block only as `@widget:`"))
    } else {
        l1.clone()
    };
    let l3 = crate::syntax::lexer::push_tok(&l2, &crate::syntax::lexer::TokKind::KKw(w.clone(), sigils.clone()), start, &l2.pos);
    if ((w == &Text::lit("output")) || (w == &Text::lit("inline_text"))) || (w == &Text::lit("raw")) {
        crate::syntax::lexer::templates::maybe_template(&l3, w)
    } else {
        l3.clone()
    }
}

/// The step machine of `LexKeyword`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexKeyword: unbounded fn Lex, Text, Text, Nat -> Lex
/// ```
pub struct LexKeyword {
    pub l: crate::syntax::lexer::Lex,
    pub w: Text,
    pub sigils: Text,
    pub start: Nat,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for LexKeyword {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l = &self.l;
        let w = &self.w;
        let sigils = &self.sigils;
        let start = &self.start;
        let l1 = if (sigils != &Text::lit("")) && !(((w == &Text::lit("widget")) || (w == &Text::lit("unit"))) || (w == &Text::lit("nil"))) {
            crate::syntax::lexer::chars::lex_err(l, start, &l.pos, &Text::from(format!("`{}` is a keyword and takes no sigil", w)))
        } else {
            l.clone()
        };
        let l2 = if (w == &Text::lit("widget")) && (sigils != &Text::lit("@")) {
            crate::syntax::lexer::chars::lex_err(&l1, start, &l1.pos, &Text::lit("`widget` is a block only as `@widget:`"))
        } else {
            l1.clone()
        };
        let l3 = crate::syntax::lexer::push_tok(&l2, &crate::syntax::lexer::TokKind::KKw(w.clone(), sigils.clone()), start, &l2.pos);
        if ((w == &Text::lit("output")) || (w == &Text::lit("inline_text"))) || (w == &Text::lit("raw")) {
            prism_rtl::Turn::More(Rc::new(crate::syntax::lexer::templates::MaybeTemplate { l0: l3.clone(), kw: w.clone() }))
        } else {
            prism_rtl::Turn::Finished(l3.clone())
        }
    }
}

/// `Start LexKeyword, x`: what the function value is when passed to `@Run`.
pub fn start_lex_keyword(l: crate::syntax::lexer::Lex, w: Text, sigils: Text, start: Nat) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(LexKeyword { l, w, sigils, start })
}

/// ```prism
/// LexName: unbounded fn Lex, [Text], Text, Nat, Nat -> Lex
/// ```
pub fn lex_name(l: &crate::syntax::lexer::Lex, path_: &Array<Text>, sigils: &Text, start: &Nat, w_start: &Nat) -> crate::syntax::lexer::Lex {
    let (case, l1) = name_case_of(l, path_, w_start);
    let l2 = if is_path_word(&l1, sigils, path_) {
        {
            let mut this: crate::syntax::lexer::Lex = l1.clone();
            this.path_next = true;
            this
        }
    } else {
        l1.clone()
    };
    crate::syntax::lexer::push_tok(&l2, &crate::syntax::lexer::TokKind::KName(crate::syntax::lexer::NameTok { sigils: sigils.clone(), path_: path_.clone(), case: case.clone() }), start, &l2.pos)
}

/// The step machine of `LexName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexName: unbounded fn Lex, [Text], Text, Nat, Nat -> Lex
/// ```
pub struct LexName {
    pub l: crate::syntax::lexer::Lex,
    pub path_: Array<Text>,
    pub sigils: Text,
    pub start: Nat,
    pub w_start: Nat,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for LexName {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l = &self.l;
        let path_ = &self.path_;
        let sigils = &self.sigils;
        let start = &self.start;
        let w_start = &self.w_start;
        let (case, l1) = name_case_of(l, path_, w_start);
        let l2 = if is_path_word(&l1, sigils, path_) {
            {
                let mut this: crate::syntax::lexer::Lex = l1.clone();
                this.path_next = true;
                this
            }
        } else {
            l1.clone()
        };
        prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok(&l2, &crate::syntax::lexer::TokKind::KName(crate::syntax::lexer::NameTok { sigils: sigils.clone(), path_: path_.clone(), case: case.clone() }), start, &l2.pos))
    }
}

/// `Start LexName, x`: what the function value is when passed to `@Run`.
pub fn start_lex_name(l: crate::syntax::lexer::Lex, path_: Array<Text>, sigils: Text, start: Nat, w_start: Nat) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(LexName { l, path_, sigils, start, w_start })
}

/// ```prism
/// NameCaseOf: fn Lex, [Text], Nat -> ((NameCase, Lex))
/// ```
pub fn name_case_of(l: &crate::syntax::lexer::Lex, path_: &Array<Text>, w_start: &Nat) -> (crate::syntax::lexer::NameCase, crate::syntax::lexer::Lex) {
    let last = or(&crate::syntax::lexer::chars::last(path_), &Text::lit(""));
    if &last == &Text::lit("_") {
        (crate::syntax::lexer::NameCase::CaseTopic, l.clone())
    } else {
        if (&crate::syntax::lexer::chars::head(&last) == &Text::lit("_")) && crate::syntax::lexer::chars::all_chars(&crate::syntax::lexer::chars::after_first(&last), &{
            let f = Rc::new(crate::syntax::lexer::chars::is_digit);
            Rc::new(move |a0: Text| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
        }) {
            (crate::syntax::lexer::NameCase::CaseHole, l.clone())
        } else {
            if &crate::syntax::lexer::chars::head(&last) == &Text::lit("_") {
                (crate::syntax::lexer::NameCase::CaseLower, crate::syntax::lexer::chars::lex_err(l, w_start, &l.pos, &Text::lit("`_` followed by a letter is not a name: `_` alone is the topic, `_1` a hole")))
            } else {
                if crate::syntax::lexer::chars::is_reserved_ctor(&last) {
                    (crate::syntax::lexer::NameCase::CaseReserved, l.clone())
                } else {
                    if crate::syntax::lexer::chars::is_upper(&crate::syntax::lexer::chars::head(&last)) {
                        {
                            let underscored = fold(path_, &false, &(|seen: &bool, seg: &Text| *seen || crate::syntax::lexer::chars::contains(seg, &Text::lit("_"))));
                            if underscored {
                                (crate::syntax::lexer::NameCase::CaseUpper, crate::syntax::lexer::chars::lex_err(l, w_start, &l.pos, &Text::from(format!("`{}`: a capital promises UpperCamelCase", &crate::syntax::lexer::chars::join(path_, &Text::lit("."))))))
                            } else {
                                (crate::syntax::lexer::NameCase::CaseUpper, l.clone())
                            }
                        }
                    } else {
                        (crate::syntax::lexer::NameCase::CaseLower, l.clone())
                    }
                }
            }
        }
    }
}

/// ```prism
/// IsPathWord: fn Lex, Text, [Text] -> Bool
/// ```
pub fn is_path_word(l: &crate::syntax::lexer::Lex, sigils: &Text, path_: &Array<Text>) -> bool {
    let w = or(&index(path_, &Nat::from(0u32)), &Text::lit(""));
    let words = if &w == &Text::lit("at") {
        Array::from(vec![Text::lit("send"), Text::lit("click"), Text::lit("answer")])
    } else {
        Array::from(vec![Text::lit("click")])
    };
    let prev = match crate::syntax::lexer::chars::last(&l.tokens) {
        Some(t) => match &t.kind {
            crate::syntax::lexer::TokKind::KName(n) if ((&n.sigils == &Text::lit("")) && (&len(&n.path_) == &Nat::from(1u32))) => or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")),
            _ => Text::lit(""),
            _ => unreachable!("no arm matched"),
        },
        None => Text::lit(""),
    };
    ((((&l.test_depth != &None) && (sigils == &Text::lit(""))) && (&len(path_) == &Nat::from(1u32))) && ((&w == &Text::lit("at")) || (&w == &Text::lit("element")))) && fold(&words, &false, &(|seen: &bool, x: &Text| *seen || (x == &prev)))
}
