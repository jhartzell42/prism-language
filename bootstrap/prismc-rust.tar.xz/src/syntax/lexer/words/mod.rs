//! The module `Syntax.Lexer.Words`, from `target/bootstrap/src/prismc/syntax/lexer/words.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// LexToken: unbounded fn Lex -> Lex
/// ```
pub fn lex_token_f(l0_p0: &crate::syntax::lexer::Lex) -> crate::syntax::lexer::Lex {
    let start_p1 = l0_p0.pos_p.clone();
    let c_p2 = crate::syntax::lexer::chars::peek_f(l0_p0);
    let l_p3 = {
        let mut this: crate::syntax::lexer::Lex = l0_p0.clone();
        this.path_next_p = false;
        this
    };
    if l0_p0.path_next_p && ((crate::syntax::lexer::chars::is_digit_f(&c_p2) || (&c_p2 == &crate::prelude::Text::lit("#"))) || (&c_p2 == &crate::prelude::Text::lit("["))) {
        lex_path_token_f(&l_p3, &start_p1)
    } else {
        lex_token_at_f(&l_p3, &start_p1, &c_p2)
    }
}

/// The step machine of `LexToken`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexToken: unbounded fn Lex -> Lex
/// ```
pub struct LexToken {
    pub l0_p0: crate::syntax::lexer::Lex,
}

impl ::prism_rtl::Job<crate::syntax::lexer::Lex> for LexToken {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l0_p0 = &self.l0_p0;
        let start_p1 = l0_p0.pos_p.clone();
        let c_p2 = crate::syntax::lexer::chars::peek_f(l0_p0);
        let l_p3 = {
            let mut this: crate::syntax::lexer::Lex = l0_p0.clone();
            this.path_next_p = false;
            this
        };
        if l0_p0.path_next_p && ((crate::syntax::lexer::chars::is_digit_f(&c_p2) || (&c_p2 == &crate::prelude::Text::lit("#"))) || (&c_p2 == &crate::prelude::Text::lit("["))) {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(LexPathToken { l_p0: l_p3.clone(), start_p1: start_p1.clone() }))
        } else {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(LexTokenAt { l_p0: l_p3.clone(), start_p1: start_p1.clone(), c_p2: c_p2.clone() }))
        }
    }
}

/// `Start LexToken, x`: what the function value is when passed to `@Run`.
pub fn start_lex_token_f(l0_p0: crate::syntax::lexer::Lex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::lexer::Lex>> {
    ::std::rc::Rc::new(LexToken { l0_p0 })
}

/// ```prism
/// LexPathToken: unbounded fn Lex, Nat -> Lex
/// ```
pub fn lex_path_token_f(l_p0: &crate::syntax::lexer::Lex, start_p1: &crate::prelude::Nat) -> crate::syntax::lexer::Lex {
    let (segs_p2, l2_p3) = crate::syntax::lexer::literals::lex_path_f(l_p0);
    crate::syntax::lexer::push_tok_f(&l2_p3, &crate::syntax::lexer::TokKind::KPath(segs_p2.clone()), start_p1, &l2_p3.pos_p)
}

/// The step machine of `LexPathToken`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexPathToken: unbounded fn Lex, Nat -> Lex
/// ```
pub struct LexPathToken {
    pub l_p0: crate::syntax::lexer::Lex,
    pub start_p1: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::syntax::lexer::Lex> for LexPathToken {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l_p0 = &self.l_p0;
        let start_p1 = &self.start_p1;
        let l_p0x = l_p0.clone();
        let start_p1x = start_p1.clone();
        crate::prelude::call_then(crate::syntax::lexer::literals::start_lex_path_f(l_p0x.clone()), move |lex_path_f_963: (crate::prelude::Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex)| {
            let (segs_p2, l2_p3) = lex_path_f_963;
            ::prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok_f(&l2_p3, &crate::syntax::lexer::TokKind::KPath(segs_p2.clone()), &start_p1x, &l2_p3.pos_p))
        })
    }
}

/// `Start LexPathToken, x`: what the function value is when passed to `@Run`.
pub fn start_lex_path_token_f(l_p0: crate::syntax::lexer::Lex, start_p1: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::lexer::Lex>> {
    ::std::rc::Rc::new(LexPathToken { l_p0, start_p1 })
}

/// ```prism
/// LexTokenAt: unbounded fn Lex, Nat, Text -> Lex
/// ```
pub fn lex_token_at_f(l_p0: &crate::syntax::lexer::Lex, start_p1: &crate::prelude::Nat, c_p2: &crate::prelude::Text) -> crate::syntax::lexer::Lex {
    match c_p2 {
        m1093_0 if (m1093_0 == &crate::prelude::Text::lit("\"")) => {
            let (text_p3, l2_p4) = crate::syntax::lexer::literals::lex_text_f(l_p0);
            crate::syntax::lexer::push_tok_f(&l2_p4, &crate::syntax::lexer::TokKind::KText(crate::prelude::Text::lit(""), text_p3.clone()), start_p1, &l2_p4.pos_p)
        },
        m1093_1 if (m1093_1 == &crate::prelude::Text::lit("\'")) => {
            let (ch_p5, l2_p6) = crate::syntax::lexer::literals::lex_char_f(l_p0);
            crate::syntax::lexer::push_tok_f(&l2_p6, &crate::syntax::lexer::TokKind::KChar(crate::prelude::Text::lit(""), ch_p5.clone()), start_p1, &l2_p6.pos_p)
        },
        _ if crate::syntax::lexer::chars::is_digit_f(c_p2) => {
            let (kind_p7, l2_p8) = crate::syntax::lexer::literals::lex_number_f(l_p0, &crate::prelude::Text::lit(""));
            crate::syntax::lexer::push_tok_f(&l2_p8, &kind_p7, start_p1, &l2_p8.pos_p)
        },
        _ if crate::syntax::lexer::chars::is_ident_start_f(c_p2) => lex_word_token_f(l_p0, &crate::prelude::Text::lit(""), start_p1),
        _ if crate::syntax::lexer::chars::contains_f(&crate::prelude::Text::lit("$@?~&^"), c_p2) => lex_sigils_f(l_p0),
        m1093_5 if (m1093_5 == &crate::prelude::Text::lit("!")) => if &crate::syntax::lexer::chars::peek_at_f(l_p0, &crate::prelude::Nat::from(1u32)) == &crate::prelude::Text::lit("=") {
            push_op_suffix_f(&crate::syntax::lexer::chars::forward_f(l_p0, &crate::prelude::Nat::from(2u32)), &crate::prelude::Text::lit("!="), start_p1)
        } else {
            lex_sigils_f(l_p0)
        },
        _ if crate::syntax::lexer::chars::contains_f(&crate::prelude::Text::lit("([{"), c_p2) => lex_open_f(l_p0, c_p2, start_p1),
        _ if crate::syntax::lexer::chars::contains_f(&crate::prelude::Text::lit(")]}"), c_p2) => lex_close_f(l_p0, c_p2, start_p1),
        m1093_8 if (m1093_8 == &crate::prelude::Text::lit(",")) => crate::syntax::lexer::push_tok_f(&crate::syntax::lexer::chars::bump_f(l_p0), &crate::syntax::lexer::TokKind::KComma, start_p1, &(start_p1 + &crate::prelude::Nat::from(1u32))),
        m1093_9 if (m1093_9 == &crate::prelude::Text::lit(":")) => crate::syntax::lexer::push_tok_f(&crate::syntax::lexer::chars::bump_f(l_p0), &crate::syntax::lexer::TokKind::KColon, start_p1, &(start_p1 + &crate::prelude::Nat::from(1u32))),
        m1093_10 if (m1093_10 == &crate::prelude::Text::lit(";")) => crate::syntax::lexer::push_tok_f(&crate::syntax::lexer::chars::bump_f(l_p0), &crate::syntax::lexer::TokKind::KSemi, start_p1, &(start_p1 + &crate::prelude::Nat::from(1u32))),
        m1093_11 if (m1093_11 == &crate::prelude::Text::lit("\\")) => lex_backslash_f(l_p0, start_p1),
        m1093_12 if (m1093_12 == &crate::prelude::Text::lit("%")) => crate::syntax::lexer::regexes::lex_regex_f(l_p0, &crate::prelude::Text::lit(""), start_p1),
        m1093_13 if (m1093_13 == &crate::prelude::Text::lit("|")) => lex_bar_f(l_p0, start_p1),
        m1093_14 if (m1093_14 == &crate::prelude::Text::lit(".")) => lex_dot_f(l_p0, start_p1),
        _ => match lex_operator_o(l_p0, start_p1) {
            ::std::option::Option::Some(l2_p9) => l2_p9,
            ::std::option::Option::None => {
                let l1_pa = crate::syntax::lexer::chars::bump_f(l_p0);
                let l2_pb = crate::syntax::lexer::chars::lex_err_f(&l1_pa, start_p1, &l1_pa.pos_p, &crate::prelude::Text::from(format!("unexpected character `{}`", c_p2)));
                {
                    let mut this: crate::syntax::lexer::Lex = l2_pb.clone();
                    this.last_ws_p = true;
                    this
                }
            },
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `LexTokenAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexTokenAt: unbounded fn Lex, Nat, Text -> Lex
/// ```
pub struct LexTokenAt {
    pub l_p0: crate::syntax::lexer::Lex,
    pub start_p1: crate::prelude::Nat,
    pub c_p2: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::syntax::lexer::Lex> for LexTokenAt {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l_p0 = &self.l_p0;
        let start_p1 = &self.start_p1;
        let c_p2 = &self.c_p2;
        match c_p2 {
            m1093_0 if (m1093_0 == &crate::prelude::Text::lit("\"")) => {
                let l_p0x = l_p0.clone();
                let start_p1x = start_p1.clone();
                crate::prelude::call_then(crate::syntax::lexer::literals::start_lex_text_f(l_p0x.clone()), move |lex_text_f_1139: (crate::prelude::Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex)| {
                    let (text_p3, l2_p4) = lex_text_f_1139;
                    ::prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok_f(&l2_p4, &crate::syntax::lexer::TokKind::KText(crate::prelude::Text::lit(""), text_p3.clone()), &start_p1x, &l2_p4.pos_p))
                })
            },
            m1093_1 if (m1093_1 == &crate::prelude::Text::lit("\'")) => {
                let l_p0x = l_p0.clone();
                let start_p1x = start_p1.clone();
                crate::prelude::call_then(crate::syntax::lexer::literals::start_lex_char_f(l_p0x.clone()), move |lex_char_f_1235: (crate::prelude::Text, crate::syntax::lexer::Lex)| {
                    let (ch_p5, l2_p6) = lex_char_f_1235;
                    ::prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok_f(&l2_p6, &crate::syntax::lexer::TokKind::KChar(crate::prelude::Text::lit(""), ch_p5.clone()), &start_p1x, &l2_p6.pos_p))
                })
            },
            _ if crate::syntax::lexer::chars::is_digit_f(c_p2) => {
                let l_p0x = l_p0.clone();
                let start_p1x = start_p1.clone();
                crate::prelude::call_then(crate::syntax::lexer::literals::start_lex_number_f(l_p0x.clone(), crate::prelude::Text::lit("")), move |lex_number_f_1347: (crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)| {
                    let (kind_p7, l2_p8) = lex_number_f_1347;
                    ::prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok_f(&l2_p8, &kind_p7, &start_p1x, &l2_p8.pos_p))
                })
            },
            _ if crate::syntax::lexer::chars::is_ident_start_f(c_p2) => ::prism_rtl::Turn::More(::std::rc::Rc::new(LexWordToken { l0_p0: l_p0.clone(), sigils_p1: crate::prelude::Text::lit(""), start_p2: start_p1.clone() })),
            _ if crate::syntax::lexer::chars::contains_f(&crate::prelude::Text::lit("$@?~&^"), c_p2) => ::prism_rtl::Turn::More(::std::rc::Rc::new(LexSigils { l0_p0: l_p0.clone() })),
            m1093_5 if (m1093_5 == &crate::prelude::Text::lit("!")) => if &crate::syntax::lexer::chars::peek_at_f(l_p0, &crate::prelude::Nat::from(1u32)) == &crate::prelude::Text::lit("=") {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(PushOpSuffix { l_p0: crate::syntax::lexer::chars::forward_f(l_p0, &crate::prelude::Nat::from(2u32)), op_p1: crate::prelude::Text::lit("!="), start_p2: start_p1.clone() }))
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(LexSigils { l0_p0: l_p0.clone() }))
            },
            _ if crate::syntax::lexer::chars::contains_f(&crate::prelude::Text::lit("([{"), c_p2) => ::prism_rtl::Turn::Finished(lex_open_f(l_p0, c_p2, start_p1)),
            _ if crate::syntax::lexer::chars::contains_f(&crate::prelude::Text::lit(")]}"), c_p2) => ::prism_rtl::Turn::Finished(lex_close_f(l_p0, c_p2, start_p1)),
            m1093_8 if (m1093_8 == &crate::prelude::Text::lit(",")) => ::prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok_f(&crate::syntax::lexer::chars::bump_f(l_p0), &crate::syntax::lexer::TokKind::KComma, start_p1, &(start_p1 + &crate::prelude::Nat::from(1u32)))),
            m1093_9 if (m1093_9 == &crate::prelude::Text::lit(":")) => ::prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok_f(&crate::syntax::lexer::chars::bump_f(l_p0), &crate::syntax::lexer::TokKind::KColon, start_p1, &(start_p1 + &crate::prelude::Nat::from(1u32)))),
            m1093_10 if (m1093_10 == &crate::prelude::Text::lit(";")) => ::prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok_f(&crate::syntax::lexer::chars::bump_f(l_p0), &crate::syntax::lexer::TokKind::KSemi, start_p1, &(start_p1 + &crate::prelude::Nat::from(1u32)))),
            m1093_11 if (m1093_11 == &crate::prelude::Text::lit("\\")) => ::prism_rtl::Turn::Finished(lex_backslash_f(l_p0, start_p1)),
            m1093_12 if (m1093_12 == &crate::prelude::Text::lit("%")) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::syntax::lexer::regexes::LexRegex { l_p0: l_p0.clone(), sigils_p1: crate::prelude::Text::lit(""), start_p2: start_p1.clone() })),
            m1093_13 if (m1093_13 == &crate::prelude::Text::lit("|")) => ::prism_rtl::Turn::Finished(lex_bar_f(l_p0, start_p1)),
            m1093_14 if (m1093_14 == &crate::prelude::Text::lit(".")) => ::prism_rtl::Turn::Finished(lex_dot_f(l_p0, start_p1)),
            _ => {
                let c_p2x = c_p2.clone();
                let l_p0x = l_p0.clone();
                let start_p1x = start_p1.clone();
                crate::prelude::call_then(start_lex_operator_o(l_p0x.clone(), start_p1x.clone()), move |lex_operator_o_1998: ::std::option::Option<crate::syntax::lexer::Lex>| match lex_operator_o_1998 {
                    ::std::option::Option::Some(l2_p9) => ::prism_rtl::Turn::Finished(l2_p9.clone()),
                    ::std::option::Option::None => {
                        let l1_pa = crate::syntax::lexer::chars::bump_f(&l_p0x);
                        let l2_pb = crate::syntax::lexer::chars::lex_err_f(&l1_pa, &start_p1x, &l1_pa.pos_p, &crate::prelude::Text::from(format!("unexpected character `{}`", &c_p2x)));
                        ::prism_rtl::Turn::Finished({
                            let mut this: crate::syntax::lexer::Lex = l2_pb.clone();
                            this.last_ws_p = true;
                            this
                        })
                    },
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start LexTokenAt, x`: what the function value is when passed to `@Run`.
pub fn start_lex_token_at_f(l_p0: crate::syntax::lexer::Lex, start_p1: crate::prelude::Nat, c_p2: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::lexer::Lex>> {
    ::std::rc::Rc::new(LexTokenAt { l_p0, start_p1, c_p2 })
}

/// ```prism
/// LexOpen: fn Lex, Text, Nat -> Lex
/// ```
pub fn lex_open_f(l_p0: &crate::syntax::lexer::Lex, c_p1: &crate::prelude::Text, start_p2: &crate::prelude::Nat) -> crate::syntax::lexer::Lex {
    let prefix_p3 = ((c_p1 == &crate::prelude::Text::lit("[")) && crate::syntax::lexer::prefix_position_f(l_p0)) && !crate::syntax::lexer::chars::next_is_space_f(l_p0, &crate::prelude::Nat::from(1u32));
    let l2_p4 = {
        let mut this: crate::syntax::lexer::Lex = crate::syntax::lexer::chars::bump_f(l_p0);
        this.frames_p = crate::prelude::push(&this.frames_p, c_p1);
        this
    };
    crate::syntax::lexer::push_tok_f(&l2_p4, &crate::syntax::lexer::TokKind::KOpen(c_p1.clone(), prefix_p3), start_p2, &l2_p4.pos_p)
}

/// ```prism
/// LexClose: fn Lex, Text, Nat -> Lex
/// ```
pub fn lex_close_f(l_p0: &crate::syntax::lexer::Lex, c_p1: &crate::prelude::Text, start_p2: &crate::prelude::Nat) -> crate::syntax::lexer::Lex {
    let kind_p3 = crate::syntax::lexer::open_of_f(c_p1);
    let l1_p4 = crate::syntax::lexer::chars::bump_f(l_p0);
    let l2_p5 = match crate::syntax::lexer::chars::last_o(&l1_p4.frames_p) {
        ::std::option::Option::Some(k_p6) if (&k_p6 == &kind_p3) => {
            let mut this: crate::syntax::lexer::Lex = l1_p4.clone();
            this.frames_p = crate::syntax::lexer::chars::pop_f(&this.frames_p);
            this
        },
        ::std::option::Option::Some(m2675_1) if (&m2675_1 == &crate::prelude::Text::lit("<<")) => crate::syntax::lexer::chars::lex_err_f(&l1_p4, start_p2, &l1_p4.pos_p, &crate::prelude::Text::from(format!("`{}` inside `<<`: expected `>>`", c_p1))),
        ::std::option::Option::Some(k_p7) => {
            let l3_p8 = crate::syntax::lexer::chars::lex_err_f(&l1_p4, start_p2, &l1_p4.pos_p, &crate::prelude::Text::from(format!("`{}` closes a `{}`", c_p1, &k_p7)));
            {
                let mut this: crate::syntax::lexer::Lex = l3_p8.clone();
                this.frames_p = crate::syntax::lexer::chars::pop_f(&this.frames_p);
                this
            }
        },
        ::std::option::Option::None => crate::syntax::lexer::chars::lex_err_f(&l1_p4, start_p2, &l1_p4.pos_p, &crate::prelude::Text::from(format!("`{}` closes nothing", c_p1))),
        _ => unreachable!("no arm matched"),
    };
    crate::syntax::lexer::push_tok_f(&l2_p5, &crate::syntax::lexer::TokKind::KClose(kind_p3.clone()), start_p2, &l2_p5.pos_p)
}

/// ```prism
/// LexBackslash: fn Lex, Nat -> Lex
/// ```
pub fn lex_backslash_f(l_p0: &crate::syntax::lexer::Lex, start_p1: &crate::prelude::Nat) -> crate::syntax::lexer::Lex {
    let l1_p2 = crate::syntax::lexer::push_tok_f(&crate::syntax::lexer::chars::bump_f(l_p0), &crate::syntax::lexer::TokKind::KBackslash, start_p1, &(start_p1 + &crate::prelude::Nat::from(1u32)));
    if &crate::syntax::lexer::chars::peek_f(&l1_p2) == &crate::prelude::Text::lit("|") {
        {
            let l2_p3 = {
                let mut this: crate::syntax::lexer::Lex = crate::syntax::lexer::chars::bump_f(&l1_p2);
                this.lambda_open_p = true;
                this
            };
            crate::syntax::lexer::push_tok_f(&l2_p3, &crate::syntax::lexer::TokKind::KLambdaBar(true), &l1_p2.pos_p, &(&l1_p2.pos_p + &crate::prelude::Nat::from(1u32)))
        }
    } else {
        l1_p2.clone()
    }
}

/// ```prism
/// LexBar: fn Lex, Nat -> Lex
/// ```
pub fn lex_bar_f(l_p0: &crate::syntax::lexer::Lex, start_p1: &crate::prelude::Nat) -> crate::syntax::lexer::Lex {
    let l1_p2 = crate::syntax::lexer::chars::bump_f(l_p0);
    if l1_p2.lambda_open_p {
        {
            let l2_p3 = {
                let mut this: crate::syntax::lexer::Lex = l1_p2.clone();
                this.lambda_open_p = false;
                this
            };
            crate::syntax::lexer::push_tok_f(&l2_p3, &crate::syntax::lexer::TokKind::KLambdaBar(false), start_p1, &l2_p3.pos_p)
        }
    } else {
        crate::syntax::lexer::push_tok_f(&l1_p2, &crate::syntax::lexer::TokKind::KBar, start_p1, &l1_p2.pos_p)
    }
}

/// ```prism
/// LexDot: fn Lex, Nat -> Lex
/// ```
pub fn lex_dot_f(l_p0: &crate::syntax::lexer::Lex, start_p1: &crate::prelude::Nat) -> crate::syntax::lexer::Lex {
    if crate::syntax::lexer::chars::starts_with_f(l_p0, &crate::prelude::Text::lit("..")) {
        crate::syntax::lexer::push_tok_f(&crate::syntax::lexer::chars::forward_f(l_p0, &crate::prelude::Nat::from(2u32)), &crate::syntax::lexer::TokKind::KDotDot, start_p1, &(start_p1 + &crate::prelude::Nat::from(2u32)))
    } else {
        {
            let prefix_p2 = crate::syntax::lexer::prefix_position_f(l_p0) && !crate::syntax::lexer::chars::next_is_space_f(l_p0, &crate::prelude::Nat::from(1u32));
            let l1_p3 = if prefix_p2 && crate::syntax::lexer::chars::is_digit_f(&crate::syntax::lexer::chars::peek_at_f(l_p0, &crate::prelude::Nat::from(1u32))) {
                crate::syntax::lexer::chars::lex_err_f(l_p0, start_p1, &(start_p1 + &crate::prelude::Nat::from(1u32)), &crate::prelude::Text::lit("a decimal literal has digits on both sides of its point: write `0.5`, not `.5`"))
            } else {
                l_p0.clone()
            };
            crate::syntax::lexer::push_tok_f(&crate::syntax::lexer::chars::bump_f(&l1_p3), &crate::syntax::lexer::TokKind::KDot(prefix_p2), start_p1, &(start_p1 + &crate::prelude::Nat::from(1u32)))
        }
    }
}

/// ```prism
/// PushOpSuffix: unbounded fn Lex, Text, Nat -> Lex
/// ```
pub fn push_op_suffix_f(l_p0: &crate::syntax::lexer::Lex, op_p1: &crate::prelude::Text, start_p2: &crate::prelude::Nat) -> crate::syntax::lexer::Lex {
    if crate::syntax::lexer::takes_suffix_f(op_p1) && crate::syntax::lexer::chars::is_upper_f(&crate::syntax::lexer::chars::peek_f(l_p0)) {
        {
            let (path_p3, l2_p4) = lex_qualified_path_f(l_p0);
            crate::syntax::lexer::push_tok_f(&l2_p4, &crate::syntax::lexer::TokKind::KSuffixed(op_p1.clone(), path_p3.clone()), start_p2, &l2_p4.pos_p)
        }
    } else {
        crate::syntax::lexer::push_tok_f(l_p0, &crate::syntax::lexer::TokKind::KOp(op_p1.clone(), false), start_p2, &l_p0.pos_p)
    }
}

/// The step machine of `PushOpSuffix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PushOpSuffix: unbounded fn Lex, Text, Nat -> Lex
/// ```
pub struct PushOpSuffix {
    pub l_p0: crate::syntax::lexer::Lex,
    pub op_p1: crate::prelude::Text,
    pub start_p2: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::syntax::lexer::Lex> for PushOpSuffix {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l_p0 = &self.l_p0;
        let op_p1 = &self.op_p1;
        let start_p2 = &self.start_p2;
        if crate::syntax::lexer::takes_suffix_f(op_p1) && crate::syntax::lexer::chars::is_upper_f(&crate::syntax::lexer::chars::peek_f(l_p0)) {
            {
                let l_p0x = l_p0.clone();
                let op_p1x = op_p1.clone();
                let start_p2x = start_p2.clone();
                crate::prelude::call_then(start_lex_qualified_path_f(l_p0x.clone()), move |lex_qualified_path_f_4539: (crate::prelude::Array<crate::prelude::Text>, crate::syntax::lexer::Lex)| {
                    let (path_p3, l2_p4) = lex_qualified_path_f_4539;
                    ::prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok_f(&l2_p4, &crate::syntax::lexer::TokKind::KSuffixed(op_p1x.clone(), path_p3.clone()), &start_p2x, &l2_p4.pos_p))
                })
            }
        } else {
            ::prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok_f(l_p0, &crate::syntax::lexer::TokKind::KOp(op_p1.clone(), false), start_p2, &l_p0.pos_p))
        }
    }
}

/// `Start PushOpSuffix, x`: what the function value is when passed to `@Run`.
pub fn start_push_op_suffix_f(l_p0: crate::syntax::lexer::Lex, op_p1: crate::prelude::Text, start_p2: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::lexer::Lex>> {
    ::std::rc::Rc::new(PushOpSuffix { l_p0, op_p1, start_p2 })
}

/// ```prism
/// FirstOp: fn Lex -> Text
/// ```
pub fn first_op_f(l_p0: &crate::syntax::lexer::Lex) -> crate::prelude::Text {
    crate::syntax::lexer::chars::match_here_f(&(if crate::syntax::lexer::fat_arrow_on_f(l_p0) {
        { thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("==>|<-|<=|<\\||->|-=|-\\?|\\+=|\\+\\?|\\*=|\\*\\?|\\/=|==|>=|=>|<|>|-|\\+|\\*|\\/|=", "")); R.with(crate::prelude::Regex::clone) }
    } else {
        { thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("==>|<-|<=|<\\||->|-=|-\\?|\\+=|\\+\\?|\\*=|\\*\\?|\\/=|==|>=|<|>|-|\\+|\\*|\\/|=", "")); R.with(crate::prelude::Regex::clone) }
    }), l_p0)
}

/// ```prism
/// EndsMark: fn Text -> Bool
/// ```
pub fn ends_mark_f(a_p0: &crate::prelude::Text) -> bool {
    (a_p0 == &crate::prelude::Text::lit("")) || crate::syntax::lexer::chars::contains_f(&crate::prelude::Text::lit(" \n\r,)]}:"), a_p0)
}

/// ```prism
/// ClosesSquareOrBrace: fn ?Tok -> Bool
/// ```
pub fn closes_square_or_brace_f(opt0: &::std::option::Option<crate::syntax::lexer::Tok>) -> bool {
    match opt0 {
        ::std::option::Option::Some(t_p0) => (&t_p0.kind_p == &crate::syntax::lexer::TokKind::KClose(crate::prelude::Text::lit("["))) || (&t_p0.kind_p == &crate::syntax::lexer::TokKind::KClose(crate::prelude::Text::lit("{"))),
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// ?LexOperator: unbounded fn Lex, Nat -> ?Lex
/// ```
pub fn lex_operator_o(l_p0: &crate::syntax::lexer::Lex, start_p1: &crate::prelude::Nat) -> ::std::option::Option<crate::syntax::lexer::Lex> {
    let c_p2 = crate::syntax::lexer::chars::peek_f(l_p0);
    let after_p3 = crate::syntax::lexer::chars::peek_at_f(l_p0, &crate::prelude::Nat::from(1u32));
    let non_empty_p4 = (((&c_p2 == &crate::prelude::Text::lit("+")) && !l_p0.last_ws_p) && closes_square_or_brace_f(&crate::syntax::lexer::chars::last_o(&l_p0.tokens_p))) && (ends_mark_f(&after_p3) || ((&after_p3 == &crate::prelude::Text::lit("?")) && ends_mark_f(&crate::syntax::lexer::chars::peek_at_f(l_p0, &crate::prelude::Nat::from(2u32)))));
    if (&c_p2 == &crate::prelude::Text::lit("-")) && crate::syntax::lexer::chars::contains_f(&crate::prelude::Text::lit(",)]}"), &after_p3) {
        ::std::option::Option::Some(crate::syntax::lexer::push_tok_f(&crate::syntax::lexer::chars::bump_f(l_p0), &crate::syntax::lexer::TokKind::KAbsent, start_p1, &(start_p1 + &crate::prelude::Nat::from(1u32))))
    } else {
        if non_empty_p4 {
            ::std::option::Option::Some(non_empty_mark_f(l_p0, start_p1, &after_p3))
        } else {
            if crate::syntax::lexer::chars::starts_with_f(l_p0, &crate::prelude::Text::lit("<<")) {
                ::std::option::Option::Some(open_type_args_f(l_p0, start_p1))
            } else {
                if crate::syntax::lexer::chars::starts_with_f(l_p0, &crate::prelude::Text::lit(">>")) && (&crate::syntax::lexer::chars::last_o(&l_p0.frames_p) == &::std::option::Option::Some(crate::prelude::Text::lit("<<"))) {
                    ::std::option::Option::Some(close_type_args_f(l_p0, start_p1))
                } else {
                    if crate::syntax::lexer::chars::starts_with_f(l_p0, &crate::prelude::Text::lit(">>")) {
                        ::std::option::Option::Some(crate::syntax::lexer::chars::lex_err_f(&crate::syntax::lexer::push_tok_f(&crate::syntax::lexer::chars::forward_f(l_p0, &crate::prelude::Nat::from(2u32)), &crate::syntax::lexer::TokKind::KGtGt, start_p1, &(start_p1 + &crate::prelude::Nat::from(2u32))), start_p1, &(start_p1 + &crate::prelude::Nat::from(2u32)), &crate::prelude::Text::lit("`>>` closes explicit type arguments, and none is open (Prism has no shift operators)")))
                    } else {
                        match first_op_f(l_p0) {
                            m6641_0 if (&m6641_0 == &crate::prelude::Text::lit("")) => ::std::option::Option::None,
                            op_p5 => ::std::option::Option::Some(push_operator_f(l_p0, &op_p5, start_p1)),
                            _ => unreachable!("no arm matched"),
                        }
                    }
                }
            }
        }
    }
}

/// The step machine of `LexOperator`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?LexOperator: unbounded fn Lex, Nat -> ?Lex
/// ```
pub struct LexOperator {
    pub l_p0: crate::syntax::lexer::Lex,
    pub start_p1: crate::prelude::Nat,
}

impl ::prism_rtl::Job<::std::option::Option<crate::syntax::lexer::Lex>> for LexOperator {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::syntax::lexer::Lex>> {
        let l_p0 = &self.l_p0;
        let start_p1 = &self.start_p1;
        let c_p2 = crate::syntax::lexer::chars::peek_f(l_p0);
        let after_p3 = crate::syntax::lexer::chars::peek_at_f(l_p0, &crate::prelude::Nat::from(1u32));
        let non_empty_p4 = (((&c_p2 == &crate::prelude::Text::lit("+")) && !l_p0.last_ws_p) && closes_square_or_brace_f(&crate::syntax::lexer::chars::last_o(&l_p0.tokens_p))) && (ends_mark_f(&after_p3) || ((&after_p3 == &crate::prelude::Text::lit("?")) && ends_mark_f(&crate::syntax::lexer::chars::peek_at_f(l_p0, &crate::prelude::Nat::from(2u32)))));
        if (&c_p2 == &crate::prelude::Text::lit("-")) && crate::syntax::lexer::chars::contains_f(&crate::prelude::Text::lit(",)]}"), &after_p3) {
            ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::syntax::lexer::push_tok_f(&crate::syntax::lexer::chars::bump_f(l_p0), &crate::syntax::lexer::TokKind::KAbsent, start_p1, &(start_p1 + &crate::prelude::Nat::from(1u32)))))
        } else {
            if non_empty_p4 {
                ::prism_rtl::Turn::Finished(::std::option::Option::Some(non_empty_mark_f(l_p0, start_p1, &after_p3)))
            } else {
                if crate::syntax::lexer::chars::starts_with_f(l_p0, &crate::prelude::Text::lit("<<")) {
                    ::prism_rtl::Turn::Finished(::std::option::Option::Some(open_type_args_f(l_p0, start_p1)))
                } else {
                    if crate::syntax::lexer::chars::starts_with_f(l_p0, &crate::prelude::Text::lit(">>")) && (&crate::syntax::lexer::chars::last_o(&l_p0.frames_p) == &::std::option::Option::Some(crate::prelude::Text::lit("<<"))) {
                        ::prism_rtl::Turn::Finished(::std::option::Option::Some(close_type_args_f(l_p0, start_p1)))
                    } else {
                        if crate::syntax::lexer::chars::starts_with_f(l_p0, &crate::prelude::Text::lit(">>")) {
                            ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::syntax::lexer::chars::lex_err_f(&crate::syntax::lexer::push_tok_f(&crate::syntax::lexer::chars::forward_f(l_p0, &crate::prelude::Nat::from(2u32)), &crate::syntax::lexer::TokKind::KGtGt, start_p1, &(start_p1 + &crate::prelude::Nat::from(2u32))), start_p1, &(start_p1 + &crate::prelude::Nat::from(2u32)), &crate::prelude::Text::lit("`>>` closes explicit type arguments, and none is open (Prism has no shift operators)"))))
                        } else {
                            match first_op_f(l_p0) {
                                m6641_0 if (&m6641_0 == &crate::prelude::Text::lit("")) => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                                op_p5 => ::prism_rtl::Turn::Finished(::std::option::Option::Some(push_operator_f(l_p0, &op_p5, start_p1))),
                                _ => unreachable!("no arm matched"),
                            }
                        }
                    }
                }
            }
        }
    }
}

/// `Start LexOperator, x`: what the function value is when passed to `@Run`.
pub fn start_lex_operator_o(l_p0: crate::syntax::lexer::Lex, start_p1: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::syntax::lexer::Lex>>> {
    ::std::rc::Rc::new(LexOperator { l_p0, start_p1 })
}

/// ```prism
/// NonEmptyMark: fn Lex, Nat, Text -> Lex
/// ```
pub fn non_empty_mark_f(l_p0: &crate::syntax::lexer::Lex, start_p1: &crate::prelude::Nat, after_p2: &crate::prelude::Text) -> crate::syntax::lexer::Lex {
    let l1_p3 = crate::syntax::lexer::push_tok_f(&crate::syntax::lexer::chars::bump_f(l_p0), &crate::syntax::lexer::TokKind::KNonEmpty, start_p1, &(start_p1 + &crate::prelude::Nat::from(1u32)));
    if after_p2 == &crate::prelude::Text::lit("?") {
        crate::syntax::lexer::push_tok_f(&crate::syntax::lexer::chars::bump_f(&l1_p3), &crate::syntax::lexer::TokKind::KFree(crate::prelude::Text::lit("?")), &l1_p3.pos_p, &(&l1_p3.pos_p + &crate::prelude::Nat::from(1u32)))
    } else {
        l1_p3.clone()
    }
}

/// ```prism
/// OpenTypeArgs: fn Lex, Nat -> Lex
/// ```
pub fn open_type_args_f(l_p0: &crate::syntax::lexer::Lex, start_p1: &crate::prelude::Nat) -> crate::syntax::lexer::Lex {
    let touching_p2 = !l_p0.last_ws_p && is_name_tok_f(&crate::syntax::lexer::chars::last_o(&l_p0.tokens_p));
    let l1_p3 = crate::syntax::lexer::chars::forward_f(l_p0, &crate::prelude::Nat::from(2u32));
    let l2_p4 = if touching_p2 {
        l1_p3.clone()
    } else {
        crate::syntax::lexer::chars::lex_err_f(&l1_p3, start_p1, &l1_p3.pos_p, &crate::prelude::Text::lit("`<<` opens explicit type arguments and must touch a name on its left (Prism has no shift operators)"))
    };
    let l3_p5 = {
        let mut this: crate::syntax::lexer::Lex = l2_p4.clone();
        this.frames_p = crate::prelude::push(&this.frames_p, &crate::prelude::Text::lit("<<"));
        this
    };
    crate::syntax::lexer::push_tok_f(&l3_p5, &crate::syntax::lexer::TokKind::KLtLt, start_p1, &l3_p5.pos_p)
}

/// ```prism
/// IsNameTok: fn ?Tok -> Bool
/// ```
pub fn is_name_tok_f(opt0: &::std::option::Option<crate::syntax::lexer::Tok>) -> bool {
    match opt0 {
        ::std::option::Option::Some(t_p0) => match &t_p0.kind_p {
            crate::syntax::lexer::TokKind::KName(_) => true,
            _ => false,
        },
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// CloseTypeArgs: fn Lex, Nat -> Lex
/// ```
pub fn close_type_args_f(l_p0: &crate::syntax::lexer::Lex, start_p1: &crate::prelude::Nat) -> crate::syntax::lexer::Lex {
    let l1_p2 = {
        let mut this: crate::syntax::lexer::Lex = crate::syntax::lexer::chars::forward_f(l_p0, &crate::prelude::Nat::from(2u32));
        this.frames_p = crate::syntax::lexer::chars::pop_f(&this.frames_p);
        this
    };
    crate::syntax::lexer::push_tok_f(&l1_p2, &crate::syntax::lexer::TokKind::KGtGt, start_p1, &l1_p2.pos_p)
}

/// ```prism
/// PushOperator: unbounded fn Lex, Text, Nat -> Lex
/// ```
pub fn push_operator_f(l_p0: &crate::syntax::lexer::Lex, op_p1: &crate::prelude::Text, start_p2: &crate::prelude::Nat) -> crate::syntax::lexer::Lex {
    let l1_p3 = crate::syntax::lexer::chars::forward_f(l_p0, &crate::prelude::len_text(op_p1));
    if (((op_p1 == &crate::prelude::Text::lit("+")) || (op_p1 == &crate::prelude::Text::lit("-"))) || (op_p1 == &crate::prelude::Text::lit("-?"))) && !crate::syntax::lexer::chars::is_upper_f(&crate::syntax::lexer::chars::peek_f(&l1_p3)) {
        crate::syntax::lexer::push_tok_f(&l1_p3, &crate::syntax::lexer::TokKind::KOp(op_p1.clone(), crate::syntax::lexer::prefix_position_f(&l1_p3) && !crate::syntax::lexer::chars::next_is_space_f(&l1_p3, &crate::prelude::Nat::from(0u32))), start_p2, &l1_p3.pos_p)
    } else {
        push_op_suffix_f(&l1_p3, op_p1, start_p2)
    }
}

/// The step machine of `PushOperator`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PushOperator: unbounded fn Lex, Text, Nat -> Lex
/// ```
pub struct PushOperator {
    pub l_p0: crate::syntax::lexer::Lex,
    pub op_p1: crate::prelude::Text,
    pub start_p2: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::syntax::lexer::Lex> for PushOperator {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l_p0 = &self.l_p0;
        let op_p1 = &self.op_p1;
        let start_p2 = &self.start_p2;
        let l1_p3 = crate::syntax::lexer::chars::forward_f(l_p0, &crate::prelude::len_text(op_p1));
        if (((op_p1 == &crate::prelude::Text::lit("+")) || (op_p1 == &crate::prelude::Text::lit("-"))) || (op_p1 == &crate::prelude::Text::lit("-?"))) && !crate::syntax::lexer::chars::is_upper_f(&crate::syntax::lexer::chars::peek_f(&l1_p3)) {
            ::prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok_f(&l1_p3, &crate::syntax::lexer::TokKind::KOp(op_p1.clone(), crate::syntax::lexer::prefix_position_f(&l1_p3) && !crate::syntax::lexer::chars::next_is_space_f(&l1_p3, &crate::prelude::Nat::from(0u32))), start_p2, &l1_p3.pos_p))
        } else {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(PushOpSuffix { l_p0: l1_p3.clone(), op_p1: op_p1.clone(), start_p2: start_p2.clone() }))
        }
    }
}

/// `Start PushOperator, x`: what the function value is when passed to `@Run`.
pub fn start_push_operator_f(l_p0: crate::syntax::lexer::Lex, op_p1: crate::prelude::Text, start_p2: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::lexer::Lex>> {
    ::std::rc::Rc::new(PushOperator { l_p0, op_p1, start_p2 })
}

/// ```prism
/// LexSigils: unbounded fn Lex -> Lex
/// ```
pub fn lex_sigils_f(l0_p0: &crate::syntax::lexer::Lex) -> crate::syntax::lexer::Lex {
    let start_p1 = l0_p0.pos_p.clone();
    let (sigils_p3, caret_p4, l_p5) = read_sigils_f(l0_p0);
    let next_p2 = crate::syntax::lexer::chars::peek_f(&l_p5);
    if caret_p4 {
        lex_caret_f(&l_p5, &start_p1, &sigils_p3, &next_p2)
    } else {
        if ((crate::syntax::lexer::chars::is_ident_start_f(&next_p2) || crate::syntax::lexer::chars::is_digit_f(&next_p2)) || (&next_p2 == &crate::prelude::Text::lit("\""))) || (&next_p2 == &crate::prelude::Text::lit("%")) {
            lex_attached_f(&l_p5, &start_p1, &sigils_p3, &next_p2)
        } else {
            if ((&sigils_p3 == &crate::prelude::Text::lit("&")) && (&next_p2 == &crate::prelude::Text::lit("."))) && crate::syntax::lexer::chars::is_lower_f(&crate::syntax::lexer::chars::peek_at_f(&l_p5, &crate::prelude::Nat::from(1u32))) {
                crate::syntax::lexer::push_tok_f(&crate::syntax::lexer::chars::bump_f(&l_p5), &crate::syntax::lexer::TokKind::KLensDot, &start_p1, &(&l_p5.pos_p + &crate::prelude::Nat::from(1u32)))
            } else {
                free_sigils_f(&l_p5, &start_p1, &sigils_p3)
            }
        }
    }
}

/// The step machine of `LexSigils`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexSigils: unbounded fn Lex -> Lex
/// ```
pub struct LexSigils {
    pub l0_p0: crate::syntax::lexer::Lex,
}

impl ::prism_rtl::Job<crate::syntax::lexer::Lex> for LexSigils {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l0_p0 = &self.l0_p0;
        let start_p1 = l0_p0.pos_p.clone();
        let l0_p0x = l0_p0.clone();
        crate::prelude::call_then(start_read_sigils_f(l0_p0x.clone()), move |read_sigils_f_8881: (crate::prelude::Text, bool, crate::syntax::lexer::Lex)| {
            let (sigils_p3, caret_p4, l_p5) = read_sigils_f_8881;
            let next_p2 = crate::syntax::lexer::chars::peek_f(&l_p5);
            if caret_p4 {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(LexCaret { l_p0: l_p5.clone(), start_p1: start_p1.clone(), sigils_p2: sigils_p3.clone(), next_p3: next_p2.clone() }))
            } else {
                if ((crate::syntax::lexer::chars::is_ident_start_f(&next_p2) || crate::syntax::lexer::chars::is_digit_f(&next_p2)) || (&next_p2 == &crate::prelude::Text::lit("\""))) || (&next_p2 == &crate::prelude::Text::lit("%")) {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(LexAttached { l_p0: l_p5.clone(), start_p1: start_p1.clone(), sigils_p2: sigils_p3.clone(), next_p3: next_p2.clone() }))
                } else {
                    if ((&sigils_p3 == &crate::prelude::Text::lit("&")) && (&next_p2 == &crate::prelude::Text::lit("."))) && crate::syntax::lexer::chars::is_lower_f(&crate::syntax::lexer::chars::peek_at_f(&l_p5, &crate::prelude::Nat::from(1u32))) {
                        ::prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok_f(&crate::syntax::lexer::chars::bump_f(&l_p5), &crate::syntax::lexer::TokKind::KLensDot, &start_p1, &(&l_p5.pos_p + &crate::prelude::Nat::from(1u32))))
                    } else {
                        ::prism_rtl::Turn::Finished(free_sigils_f(&l_p5, &start_p1, &sigils_p3))
                    }
                }
            }
        })
    }
}

/// `Start LexSigils, x`: what the function value is when passed to `@Run`.
pub fn start_lex_sigils_f(l0_p0: crate::syntax::lexer::Lex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::lexer::Lex>> {
    ::std::rc::Rc::new(LexSigils { l0_p0 })
}

/// ```prism
/// ReadSigils: unbounded fn Lex -> ((Text, Bool, Lex))
/// ```
pub fn read_sigils_f(l0_p0: &crate::syntax::lexer::Lex) -> (crate::prelude::Text, bool, crate::syntax::lexer::Lex) {
    let mut this: (crate::prelude::Text, bool, crate::syntax::lexer::Lex) = (crate::prelude::Text::lit(""), false, l0_p0.clone());
    let mut l_p1: crate::syntax::lexer::Lex = l0_p0.clone();
    let mut sigils_p2: crate::prelude::Text = crate::prelude::Text::lit("");
    let mut caret_p3: bool = false;
    let mut going_p4: bool = true;
    while going_p4 {
        let c_p5 = crate::syntax::lexer::chars::peek_f(&l_p1);
        if &c_p5 == &crate::prelude::Text::lit("^") {
            l_p1 = crate::syntax::lexer::chars::bump_f(&l_p1);
            caret_p3 = true;
            going_p4 = false;
        } else if crate::syntax::lexer::chars::is_sigil_char_f(&c_p5) && !((&c_p5 == &crate::prelude::Text::lit("!")) && (&crate::syntax::lexer::chars::peek_at_f(&l_p1, &crate::prelude::Nat::from(1u32)) == &crate::prelude::Text::lit("="))) {
            l_p1 = crate::syntax::lexer::chars::bump_f(&l_p1);
            sigils_p2 = crate::prelude::Text::from(format!("{}{}", &sigils_p2, &c_p5));
        } else {
            going_p4 = false;
        }
    }
    this = (sigils_p2.clone(), caret_p3, l_p1.clone());
    this
}

/// The step machine of `ReadSigils`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadSigils: unbounded fn Lex -> ((Text, Bool, Lex))
/// ```
pub struct ReadSigils {
    pub l0_p0: crate::syntax::lexer::Lex,
}

impl ::prism_rtl::Job<(crate::prelude::Text, bool, crate::syntax::lexer::Lex)> for ReadSigils {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Text, bool, crate::syntax::lexer::Lex)> {
        let l0_p0 = &self.l0_p0;
        let mut this: (crate::prelude::Text, bool, crate::syntax::lexer::Lex) = (crate::prelude::Text::lit(""), false, l0_p0.clone());
        let mut l_p1: crate::syntax::lexer::Lex = l0_p0.clone();
        let mut sigils_p2: crate::prelude::Text = crate::prelude::Text::lit("");
        let mut caret_p3: bool = false;
        let mut going_p4: bool = true;
        crate::prelude::call_then(crate::prelude::loop_job((this, caret_p3, going_p4, l_p1, sigils_p2), move |(mut this, mut caret_p3, mut going_p4, mut l_p1, mut sigils_p2): ((crate::prelude::Text, bool, crate::syntax::lexer::Lex), bool, bool, crate::syntax::lexer::Lex, crate::prelude::Text)| if going_p4 {
            {
                let c_p5 = crate::syntax::lexer::chars::peek_f(&l_p1);
                if &c_p5 == &crate::prelude::Text::lit("^") {
                    l_p1 = crate::syntax::lexer::chars::bump_f(&l_p1);
                    caret_p3 = true;
                    going_p4 = false;
                } else if crate::syntax::lexer::chars::is_sigil_char_f(&c_p5) && !((&c_p5 == &crate::prelude::Text::lit("!")) && (&crate::syntax::lexer::chars::peek_at_f(&l_p1, &crate::prelude::Nat::from(1u32)) == &crate::prelude::Text::lit("="))) {
                    l_p1 = crate::syntax::lexer::chars::bump_f(&l_p1);
                    sigils_p2 = crate::prelude::Text::from(format!("{}{}", &sigils_p2, &c_p5));
                } else {
                    going_p4 = false;
                }
                ::std::result::Result::Ok((this, caret_p3, going_p4, l_p1, sigils_p2))
            }
        } else {
            ::std::result::Result::Err((this, caret_p3, going_p4, l_p1, sigils_p2))
        }), move |(mut this, mut caret_p3, mut going_p4, mut l_p1, mut sigils_p2): ((crate::prelude::Text, bool, crate::syntax::lexer::Lex), bool, bool, crate::syntax::lexer::Lex, crate::prelude::Text)| {
            this = (sigils_p2.clone(), caret_p3, l_p1.clone());
            ::prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start ReadSigils, x`: what the function value is when passed to `@Run`.
pub fn start_read_sigils_f(l0_p0: crate::syntax::lexer::Lex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, bool, crate::syntax::lexer::Lex)>> {
    ::std::rc::Rc::new(ReadSigils { l0_p0 })
}

/// ```prism
/// LexCaret: unbounded fn Lex, Nat, Text, Text -> Lex
/// ```
pub fn lex_caret_f(l_p0: &crate::syntax::lexer::Lex, start_p1: &crate::prelude::Nat, sigils_p2: &crate::prelude::Text, next_p3: &crate::prelude::Text) -> crate::syntax::lexer::Lex {
    if crate::syntax::lexer::chars::is_upper_f(next_p3) && (sigils_p2 == &crate::prelude::Text::lit("")) {
        {
            let (path_p4, l2_p5) = lex_qualified_path_f(l_p0);
            crate::syntax::lexer::push_tok_f(&l2_p5, &crate::syntax::lexer::TokKind::KTrait(path_p4.clone()), start_p1, &l2_p5.pos_p)
        }
    } else {
        {
            let (_, skipped_p7) = lex_qualified_path_f(l_p0);
            let l2_p6 = if crate::syntax::lexer::chars::is_ident_start_f(next_p3) {
                skipped_p7.clone()
            } else {
                l_p0.clone()
            };
            crate::syntax::lexer::chars::lex_err_f(&l2_p6, start_p1, &crate::prelude::max(&l2_p6.pos_p, &l_p0.pos_p), &crate::prelude::Text::lit("`^` marks a trait and attaches to its uppercase name: no trait is a value"))
        }
    }
}

/// The step machine of `LexCaret`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexCaret: unbounded fn Lex, Nat, Text, Text -> Lex
/// ```
pub struct LexCaret {
    pub l_p0: crate::syntax::lexer::Lex,
    pub start_p1: crate::prelude::Nat,
    pub sigils_p2: crate::prelude::Text,
    pub next_p3: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::syntax::lexer::Lex> for LexCaret {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l_p0 = &self.l_p0;
        let start_p1 = &self.start_p1;
        let sigils_p2 = &self.sigils_p2;
        let next_p3 = &self.next_p3;
        if crate::syntax::lexer::chars::is_upper_f(next_p3) && (sigils_p2 == &crate::prelude::Text::lit("")) {
            {
                let l_p0x = l_p0.clone();
                let start_p1x = start_p1.clone();
                crate::prelude::call_then(start_lex_qualified_path_f(l_p0x.clone()), move |lex_qualified_path_f_10085: (crate::prelude::Array<crate::prelude::Text>, crate::syntax::lexer::Lex)| {
                    let (path_p4, l2_p5) = lex_qualified_path_f_10085;
                    ::prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok_f(&l2_p5, &crate::syntax::lexer::TokKind::KTrait(path_p4.clone()), &start_p1x, &l2_p5.pos_p))
                })
            }
        } else {
            {
                let l_p0x = l_p0.clone();
                let next_p3x = next_p3.clone();
                let start_p1x = start_p1.clone();
                crate::prelude::call_then(start_lex_qualified_path_f(l_p0x.clone()), move |lex_qualified_path_f_10197: (crate::prelude::Array<crate::prelude::Text>, crate::syntax::lexer::Lex)| {
                    let (_, skipped_p7) = lex_qualified_path_f_10197;
                    let l2_p6 = if crate::syntax::lexer::chars::is_ident_start_f(&next_p3x) {
                        skipped_p7.clone()
                    } else {
                        l_p0x.clone()
                    };
                    ::prism_rtl::Turn::Finished(crate::syntax::lexer::chars::lex_err_f(&l2_p6, &start_p1x, &crate::prelude::max(&l2_p6.pos_p, &l_p0x.pos_p), &crate::prelude::Text::lit("`^` marks a trait and attaches to its uppercase name: no trait is a value")))
                })
            }
        }
    }
}

/// `Start LexCaret, x`: what the function value is when passed to `@Run`.
pub fn start_lex_caret_f(l_p0: crate::syntax::lexer::Lex, start_p1: crate::prelude::Nat, sigils_p2: crate::prelude::Text, next_p3: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::lexer::Lex>> {
    ::std::rc::Rc::new(LexCaret { l_p0, start_p1, sigils_p2, next_p3 })
}

/// ```prism
/// LexAttached: unbounded fn Lex, Nat, Text, Text -> Lex
/// ```
pub fn lex_attached_f(l_p0: &crate::syntax::lexer::Lex, start_p1: &crate::prelude::Nat, sigils_p2: &crate::prelude::Text, next_p3: &crate::prelude::Text) -> crate::syntax::lexer::Lex {
    if next_p3 == &crate::prelude::Text::lit("\"") {
        {
            let (text_p4, l2_p5) = crate::syntax::lexer::literals::lex_text_f(l_p0);
            crate::syntax::lexer::push_tok_f(&l2_p5, &crate::syntax::lexer::TokKind::KText(sigils_p2.clone(), text_p4.clone()), start_p1, &l2_p5.pos_p)
        }
    } else {
        if crate::syntax::lexer::chars::is_digit_f(next_p3) {
            {
                let (kind_p6, l2_p7) = crate::syntax::lexer::literals::lex_number_f(l_p0, sigils_p2);
                crate::syntax::lexer::push_tok_f(&l2_p7, &kind_p6, start_p1, &l2_p7.pos_p)
            }
        } else {
            if next_p3 == &crate::prelude::Text::lit("%") {
                crate::syntax::lexer::regexes::lex_regex_f(l_p0, sigils_p2, start_p1)
            } else {
                lex_word_token_f(l_p0, sigils_p2, start_p1)
            }
        }
    }
}

/// The step machine of `LexAttached`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexAttached: unbounded fn Lex, Nat, Text, Text -> Lex
/// ```
pub struct LexAttached {
    pub l_p0: crate::syntax::lexer::Lex,
    pub start_p1: crate::prelude::Nat,
    pub sigils_p2: crate::prelude::Text,
    pub next_p3: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::syntax::lexer::Lex> for LexAttached {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l_p0 = &self.l_p0;
        let start_p1 = &self.start_p1;
        let sigils_p2 = &self.sigils_p2;
        let next_p3 = &self.next_p3;
        if next_p3 == &crate::prelude::Text::lit("\"") {
            {
                let l_p0x = l_p0.clone();
                let sigils_p2x = sigils_p2.clone();
                let start_p1x = start_p1.clone();
                crate::prelude::call_then(crate::syntax::lexer::literals::start_lex_text_f(l_p0x.clone()), move |lex_text_f_10536: (crate::prelude::Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex)| {
                    let (text_p4, l2_p5) = lex_text_f_10536;
                    ::prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok_f(&l2_p5, &crate::syntax::lexer::TokKind::KText(sigils_p2x.clone(), text_p4.clone()), &start_p1x, &l2_p5.pos_p))
                })
            }
        } else {
            if crate::syntax::lexer::chars::is_digit_f(next_p3) {
                {
                    let l_p0x = l_p0.clone();
                    let sigils_p2x = sigils_p2.clone();
                    let start_p1x = start_p1.clone();
                    crate::prelude::call_then(crate::syntax::lexer::literals::start_lex_number_f(l_p0x.clone(), sigils_p2x.clone()), move |lex_number_f_10656: (crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)| {
                        let (kind_p6, l2_p7) = lex_number_f_10656;
                        ::prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok_f(&l2_p7, &kind_p6, &start_p1x, &l2_p7.pos_p))
                    })
                }
            } else {
                if next_p3 == &crate::prelude::Text::lit("%") {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::syntax::lexer::regexes::LexRegex { l_p0: l_p0.clone(), sigils_p1: sigils_p2.clone(), start_p2: start_p1.clone() }))
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(LexWordToken { l0_p0: l_p0.clone(), sigils_p1: sigils_p2.clone(), start_p2: start_p1.clone() }))
                }
            }
        }
    }
}

/// `Start LexAttached, x`: what the function value is when passed to `@Run`.
pub fn start_lex_attached_f(l_p0: crate::syntax::lexer::Lex, start_p1: crate::prelude::Nat, sigils_p2: crate::prelude::Text, next_p3: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::lexer::Lex>> {
    ::std::rc::Rc::new(LexAttached { l_p0, start_p1, sigils_p2, next_p3 })
}

/// ```prism
/// FreeSigils: fn Lex, Nat, Text -> Lex
/// ```
pub fn free_sigils_f(l0_p0: &crate::syntax::lexer::Lex, start_p1: &crate::prelude::Nat, sigils_p2: &crate::prelude::Text) -> crate::syntax::lexer::Lex {
    let mut this: crate::syntax::lexer::Lex = l0_p0.clone();
    let space_after_p3 = crate::syntax::lexer::chars::next_is_space_f(&this, &crate::prelude::Nat::from(0u32));
    let all_p6 = crate::syntax::lexer::chars::fold_chars_f(sigils_p2, &crate::prelude::Array::new(), &(::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)| crate::prelude::once_job(move || {
        let acc_p4 = p0;
        let c_p5 = p1;
        ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p4, &c_p5))
    })) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>));
    for (i11136, v11136) in all_p6.clone().into_iter().enumerate() {
        let k11136 = crate::prelude::nat_of(i11136);
        let s_p7 = v11136.clone();
        let at_p8 = start_p1 + &k11136;
        if space_after_p3 && (&(&k11136 + &crate::prelude::Nat::from(1u32)) == &crate::prelude::len(&all_p6)) {
            if &s_p7 == &crate::prelude::Text::lit("!") {
                this = crate::syntax::lexer::chars::lex_err_f(&this, &at_p8, &(&at_p8 + &crate::prelude::Nat::from(1u32)), &crate::prelude::Text::lit("`!` is never free: no event fires a constant (write `!e` touching its name)"));
            }
            if &s_p7 == &crate::prelude::Text::lit("&") {
                this = crate::syntax::lexer::chars::lex_err_f(&this, &at_p8, &(&at_p8 + &crate::prelude::Nat::from(1u32)), &crate::prelude::Text::lit("`&` is never free: no reference exists outside the value an `update` block names"));
            }
        }
        this = crate::syntax::lexer::push_tok_f(&this, &crate::syntax::lexer::TokKind::KFree(s_p7.clone()), &at_p8, &(&at_p8 + &crate::prelude::Nat::from(1u32)));
    }
    this
}

/// ```prism
/// LexQualifiedPath: unbounded fn Lex -> (([Text], Lex))
/// ```
pub fn lex_qualified_path_f(l0_p0: &crate::syntax::lexer::Lex) -> (crate::prelude::Array<crate::prelude::Text>, crate::syntax::lexer::Lex) {
    let mut this: (crate::prelude::Array<crate::prelude::Text>, crate::syntax::lexer::Lex) = (crate::prelude::Array::new(), l0_p0.clone());
    let (first_p1, l1_p2) = lex_ident_f(l0_p0);
    let mut path_p3: crate::prelude::Array<crate::prelude::Text> = crate::prelude::Array::from(vec![first_p1.clone()]);
    let mut l_p4: crate::syntax::lexer::Lex = l1_p2.clone();
    let mut going_p5: bool = true;
    while going_p5 {
        let last_p6 = crate::prelude::or(&crate::syntax::lexer::chars::last_o(&path_p3), &crate::prelude::Text::lit(""));
        let next_p7 = crate::syntax::lexer::chars::peek_at_f(&l_p4, &crate::prelude::Nat::from(1u32));
        if (&crate::syntax::lexer::chars::peek_f(&l_p4) != &crate::prelude::Text::lit(".")) || !crate::syntax::lexer::chars::is_upper_f(&crate::syntax::lexer::chars::head_f(&last_p6)) {
            going_p5 = false;
        } else if crate::syntax::lexer::chars::is_upper_f(&next_p7) {
            let (seg_p8, l2_p9) = lex_ident_f(&crate::syntax::lexer::chars::bump_f(&l_p4));
            path_p3 = crate::prelude::push(&path_p3, &seg_p8);
            l_p4 = l2_p9.clone();
        } else {
            going_p5 = false;
            if crate::syntax::lexer::chars::is_ident_start_f(&next_p7) {
                let (w_pa, l2_pb) = lex_ident_f(&crate::syntax::lexer::chars::bump_f(&l_p4));
                if crate::syntax::lexer::chars::is_reserved_ctor_f(&w_pa) {
                    path_p3 = crate::prelude::push(&path_p3, &w_pa);
                    l_p4 = l2_pb.clone();
                }
            }
        }
    }
    this = (path_p3.clone(), l_p4.clone());
    this
}

/// The step machine of `LexQualifiedPath`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexQualifiedPath: unbounded fn Lex -> (([Text], Lex))
/// ```
pub struct LexQualifiedPath {
    pub l0_p0: crate::syntax::lexer::Lex,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, crate::syntax::lexer::Lex)> for LexQualifiedPath {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::prelude::Text>, crate::syntax::lexer::Lex)> {
        let l0_p0 = &self.l0_p0;
        let mut this: (crate::prelude::Array<crate::prelude::Text>, crate::syntax::lexer::Lex) = (crate::prelude::Array::new(), l0_p0.clone());
        let (first_p1, l1_p2) = lex_ident_f(l0_p0);
        let mut path_p3: crate::prelude::Array<crate::prelude::Text> = crate::prelude::Array::from(vec![first_p1.clone()]);
        let mut l_p4: crate::syntax::lexer::Lex = l1_p2.clone();
        let mut going_p5: bool = true;
        crate::prelude::call_then(crate::prelude::loop_job((this, going_p5, l_p4, path_p3), move |(mut this, mut going_p5, mut l_p4, mut path_p3): ((crate::prelude::Array<crate::prelude::Text>, crate::syntax::lexer::Lex), bool, crate::syntax::lexer::Lex, crate::prelude::Array<crate::prelude::Text>)| if going_p5 {
            {
                let last_p6 = crate::prelude::or(&crate::syntax::lexer::chars::last_o(&path_p3), &crate::prelude::Text::lit(""));
                let next_p7 = crate::syntax::lexer::chars::peek_at_f(&l_p4, &crate::prelude::Nat::from(1u32));
                if (&crate::syntax::lexer::chars::peek_f(&l_p4) != &crate::prelude::Text::lit(".")) || !crate::syntax::lexer::chars::is_upper_f(&crate::syntax::lexer::chars::head_f(&last_p6)) {
                    going_p5 = false;
                } else if crate::syntax::lexer::chars::is_upper_f(&next_p7) {
                    let (seg_p8, l2_p9) = lex_ident_f(&crate::syntax::lexer::chars::bump_f(&l_p4));
                    path_p3 = crate::prelude::push(&path_p3, &seg_p8);
                    l_p4 = l2_p9.clone();
                } else {
                    going_p5 = false;
                    if crate::syntax::lexer::chars::is_ident_start_f(&next_p7) {
                        let (w_pa, l2_pb) = lex_ident_f(&crate::syntax::lexer::chars::bump_f(&l_p4));
                        if crate::syntax::lexer::chars::is_reserved_ctor_f(&w_pa) {
                            path_p3 = crate::prelude::push(&path_p3, &w_pa);
                            l_p4 = l2_pb.clone();
                        }
                    }
                }
                ::std::result::Result::Ok((this, going_p5, l_p4, path_p3))
            }
        } else {
            ::std::result::Result::Err((this, going_p5, l_p4, path_p3))
        }), move |(mut this, mut going_p5, mut l_p4, mut path_p3): ((crate::prelude::Array<crate::prelude::Text>, crate::syntax::lexer::Lex), bool, crate::syntax::lexer::Lex, crate::prelude::Array<crate::prelude::Text>)| {
            this = (path_p3.clone(), l_p4.clone());
            ::prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start LexQualifiedPath, x`: what the function value is when passed to `@Run`.
pub fn start_lex_qualified_path_f(l0_p0: crate::syntax::lexer::Lex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, crate::syntax::lexer::Lex)>> {
    ::std::rc::Rc::new(LexQualifiedPath { l0_p0 })
}

/// ```prism
/// LexIdent: unbounded fn Lex -> ((Text, Lex))
/// ```
pub fn lex_ident_f(l0_p0: &crate::syntax::lexer::Lex) -> (crate::prelude::Text, crate::syntax::lexer::Lex) {
    let word_p1 = crate::syntax::lexer::chars::match_here_f(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[A-Za-z0-9_]*", "")); R.with(crate::prelude::Regex::clone) }, l0_p0);
    let l_p2 = {
        let mut this: crate::syntax::lexer::Lex = l0_p0.clone();
        this.pos_p = &this.pos_p + &crate::prelude::len_text(&word_p1);
        this
    };
    (word_p1.clone(), l_p2.clone())
}

/// The step machine of `LexIdent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexIdent: unbounded fn Lex -> ((Text, Lex))
/// ```
pub struct LexIdent {
    pub l0_p0: crate::syntax::lexer::Lex,
}

impl ::prism_rtl::Job<(crate::prelude::Text, crate::syntax::lexer::Lex)> for LexIdent {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Text, crate::syntax::lexer::Lex)> {
        let l0_p0 = &self.l0_p0;
        let word_p1 = crate::syntax::lexer::chars::match_here_f(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[A-Za-z0-9_]*", "")); R.with(crate::prelude::Regex::clone) }, l0_p0);
        let l_p2 = {
            let mut this: crate::syntax::lexer::Lex = l0_p0.clone();
            this.pos_p = &this.pos_p + &crate::prelude::len_text(&word_p1);
            this
        };
        ::prism_rtl::Turn::Finished((word_p1.clone(), l_p2.clone()))
    }
}

/// `Start LexIdent, x`: what the function value is when passed to `@Run`.
pub fn start_lex_ident_f(l0_p0: crate::syntax::lexer::Lex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::syntax::lexer::Lex)>> {
    ::std::rc::Rc::new(LexIdent { l0_p0 })
}

/// ```prism
/// LexWordToken: unbounded fn Lex, Text, Nat -> Lex
/// ```
pub fn lex_word_token_f(l0_p0: &crate::syntax::lexer::Lex, sigils_p1: &crate::prelude::Text, start_p2: &crate::prelude::Nat) -> crate::syntax::lexer::Lex {
    let w_start_p3 = l0_p0.pos_p.clone();
    let (path_p6, l1_p7) = lex_qualified_path_f(l0_p0);
    let l_p4 = if crate::syntax::lexer::chars::is_non_ascii_f(&crate::syntax::lexer::chars::peek_f(&l1_p7)) {
        skip_non_ascii_f(&l1_p7, &w_start_p3)
    } else {
        l1_p7.clone()
    };
    let first_p5 = crate::prelude::or(&crate::prelude::index(&path_p6, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit(""));
    if crate::syntax::lexer::chars::starts_with_f(&l_p4, &crate::prelude::Text::lit(".*")) && crate::syntax::lexer::chars::is_upper_f(&crate::syntax::lexer::chars::head_f(&first_p5)) {
        {
            let l2_p8 = crate::syntax::lexer::chars::forward_f(&l_p4, &crate::prelude::Nat::from(2u32));
            let l3_p9 = if sigils_p1 != &crate::prelude::Text::lit("") {
                crate::syntax::lexer::chars::lex_err_f(&l2_p8, start_p2, &l2_p8.pos_p, &crate::prelude::Text::lit("a family pattern takes no sigil"))
            } else {
                l2_p8.clone()
            };
            crate::syntax::lexer::push_tok_f(&l3_p9, &crate::syntax::lexer::TokKind::KFamily(path_p6.clone()), start_p2, &l3_p9.pos_p)
        }
    } else {
        if ((&crate::prelude::len(&path_p6) == &crate::prelude::Nat::from(1u32)) && crate::syntax::lexer::is_keyword_f(&first_p5)) && !(crate::syntax::lexer::is_bound_word_f(&first_p5) && (sigils_p1 != &crate::prelude::Text::lit(""))) {
            lex_keyword_f(&l_p4, &first_p5, sigils_p1, start_p2)
        } else {
            lex_name_f(&l_p4, &path_p6, sigils_p1, start_p2, &w_start_p3)
        }
    }
}

/// The step machine of `LexWordToken`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexWordToken: unbounded fn Lex, Text, Nat -> Lex
/// ```
pub struct LexWordToken {
    pub l0_p0: crate::syntax::lexer::Lex,
    pub sigils_p1: crate::prelude::Text,
    pub start_p2: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::syntax::lexer::Lex> for LexWordToken {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l0_p0 = &self.l0_p0;
        let sigils_p1 = &self.sigils_p1;
        let start_p2 = &self.start_p2;
        let w_start_p3 = l0_p0.pos_p.clone();
        let l0_p0x = l0_p0.clone();
        let sigils_p1x = sigils_p1.clone();
        let start_p2x = start_p2.clone();
        crate::prelude::call_then(start_lex_qualified_path_f(l0_p0x.clone()), move |lex_qualified_path_f_12984: (crate::prelude::Array<crate::prelude::Text>, crate::syntax::lexer::Lex)| {
            let (path_p6, l1_p7) = lex_qualified_path_f_12984;
            let path_p6z = path_p6.clone();
            let sigils_p1xz = sigils_p1x.clone();
            let start_p2xz = start_p2x.clone();
            let w_start_p3z = w_start_p3.clone();
            let k_let13008 = move |v13008: crate::syntax::lexer::Lex| {
                let l_p4 = v13008;
                let first_p5 = crate::prelude::or(&crate::prelude::index(&path_p6z, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit(""));
                if crate::syntax::lexer::chars::starts_with_f(&l_p4, &crate::prelude::Text::lit(".*")) && crate::syntax::lexer::chars::is_upper_f(&crate::syntax::lexer::chars::head_f(&first_p5)) {
                    {
                        let l2_p8 = crate::syntax::lexer::chars::forward_f(&l_p4, &crate::prelude::Nat::from(2u32));
                        let l3_p9 = if &sigils_p1xz != &crate::prelude::Text::lit("") {
                            crate::syntax::lexer::chars::lex_err_f(&l2_p8, &start_p2xz, &l2_p8.pos_p, &crate::prelude::Text::lit("a family pattern takes no sigil"))
                        } else {
                            l2_p8.clone()
                        };
                        ::prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok_f(&l3_p9, &crate::syntax::lexer::TokKind::KFamily(path_p6z.clone()), &start_p2xz, &l3_p9.pos_p))
                    }
                } else {
                    if ((&crate::prelude::len(&path_p6z) == &crate::prelude::Nat::from(1u32)) && crate::syntax::lexer::is_keyword_f(&first_p5)) && !(crate::syntax::lexer::is_bound_word_f(&first_p5) && (&sigils_p1xz != &crate::prelude::Text::lit(""))) {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(LexKeyword { l_p0: l_p4.clone(), w_p1: first_p5.clone(), sigils_p2: sigils_p1xz.clone(), start_p3: start_p2xz.clone() }))
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(LexName { l_p0: l_p4.clone(), path_p1: path_p6z.clone(), sigils_p2: sigils_p1xz.clone(), start_p3: start_p2xz.clone(), w_start_p4: w_start_p3z.clone() }))
                    }
                }
            };
            if crate::syntax::lexer::chars::is_non_ascii_f(&crate::syntax::lexer::chars::peek_f(&l1_p7)) {
                crate::prelude::call_then(start_skip_non_ascii_f(l1_p7.clone(), w_start_p3.clone()), move |skip_non_ascii_f_13041: crate::syntax::lexer::Lex| k_let13008(skip_non_ascii_f_13041))
            } else {
                k_let13008(l1_p7.clone())
            }
        })
    }
}

/// `Start LexWordToken, x`: what the function value is when passed to `@Run`.
pub fn start_lex_word_token_f(l0_p0: crate::syntax::lexer::Lex, sigils_p1: crate::prelude::Text, start_p2: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::lexer::Lex>> {
    ::std::rc::Rc::new(LexWordToken { l0_p0, sigils_p1, start_p2 })
}

/// ```prism
/// SkipNonAscii: unbounded fn Lex, Nat -> Lex
/// ```
pub fn skip_non_ascii_f(l0_p0: &crate::syntax::lexer::Lex, w_start_p1: &crate::prelude::Nat) -> crate::syntax::lexer::Lex {
    let l_p2 = {
        let mut this: crate::syntax::lexer::Lex = l0_p0.clone();
        this.pos_p = crate::syntax::lexer::chars::match_end_f(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[A-Za-z0-9_\\x{80}-\\x{10FFFF}]*", "")); R.with(crate::prelude::Regex::clone) }, &this.src_p, &this.pos_p);
        this
    };
    crate::syntax::lexer::chars::lex_err_f(&l_p2, w_start_p1, &l_p2.pos_p, &crate::prelude::Text::lit("names are ASCII letters, digits and underscores"))
}

/// The step machine of `SkipNonAscii`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SkipNonAscii: unbounded fn Lex, Nat -> Lex
/// ```
pub struct SkipNonAscii {
    pub l0_p0: crate::syntax::lexer::Lex,
    pub w_start_p1: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::syntax::lexer::Lex> for SkipNonAscii {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l0_p0 = &self.l0_p0;
        let w_start_p1 = &self.w_start_p1;
        let l_p2 = {
            let mut this: crate::syntax::lexer::Lex = l0_p0.clone();
            this.pos_p = crate::syntax::lexer::chars::match_end_f(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[A-Za-z0-9_\\x{80}-\\x{10FFFF}]*", "")); R.with(crate::prelude::Regex::clone) }, &this.src_p, &this.pos_p);
            this
        };
        ::prism_rtl::Turn::Finished(crate::syntax::lexer::chars::lex_err_f(&l_p2, w_start_p1, &l_p2.pos_p, &crate::prelude::Text::lit("names are ASCII letters, digits and underscores")))
    }
}

/// `Start SkipNonAscii, x`: what the function value is when passed to `@Run`.
pub fn start_skip_non_ascii_f(l0_p0: crate::syntax::lexer::Lex, w_start_p1: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::lexer::Lex>> {
    ::std::rc::Rc::new(SkipNonAscii { l0_p0, w_start_p1 })
}

/// ```prism
/// LexKeyword: unbounded fn Lex, Text, Text, Nat -> Lex
/// ```
pub fn lex_keyword_f(l_p0: &crate::syntax::lexer::Lex, w_p1: &crate::prelude::Text, sigils_p2: &crate::prelude::Text, start_p3: &crate::prelude::Nat) -> crate::syntax::lexer::Lex {
    let l1_p4 = if (sigils_p2 != &crate::prelude::Text::lit("")) && !(((w_p1 == &crate::prelude::Text::lit("widget")) || (w_p1 == &crate::prelude::Text::lit("unit"))) || (w_p1 == &crate::prelude::Text::lit("nil"))) {
        crate::syntax::lexer::chars::lex_err_f(l_p0, start_p3, &l_p0.pos_p, &crate::prelude::Text::from(format!("`{}` is a keyword and takes no sigil", w_p1)))
    } else {
        l_p0.clone()
    };
    let l2_p5 = if (w_p1 == &crate::prelude::Text::lit("widget")) && (sigils_p2 != &crate::prelude::Text::lit("@")) {
        crate::syntax::lexer::chars::lex_err_f(&l1_p4, start_p3, &l1_p4.pos_p, &crate::prelude::Text::lit("`widget` is a block only as `@widget:`"))
    } else {
        l1_p4.clone()
    };
    let l3_p6 = crate::syntax::lexer::push_tok_f(&l2_p5, &crate::syntax::lexer::TokKind::KKw(w_p1.clone(), sigils_p2.clone()), start_p3, &l2_p5.pos_p);
    if ((w_p1 == &crate::prelude::Text::lit("output")) || (w_p1 == &crate::prelude::Text::lit("inline_text"))) || (w_p1 == &crate::prelude::Text::lit("raw")) {
        crate::syntax::lexer::templates::maybe_template_f(&l3_p6, w_p1)
    } else {
        l3_p6.clone()
    }
}

/// The step machine of `LexKeyword`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexKeyword: unbounded fn Lex, Text, Text, Nat -> Lex
/// ```
pub struct LexKeyword {
    pub l_p0: crate::syntax::lexer::Lex,
    pub w_p1: crate::prelude::Text,
    pub sigils_p2: crate::prelude::Text,
    pub start_p3: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::syntax::lexer::Lex> for LexKeyword {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l_p0 = &self.l_p0;
        let w_p1 = &self.w_p1;
        let sigils_p2 = &self.sigils_p2;
        let start_p3 = &self.start_p3;
        let l1_p4 = if (sigils_p2 != &crate::prelude::Text::lit("")) && !(((w_p1 == &crate::prelude::Text::lit("widget")) || (w_p1 == &crate::prelude::Text::lit("unit"))) || (w_p1 == &crate::prelude::Text::lit("nil"))) {
            crate::syntax::lexer::chars::lex_err_f(l_p0, start_p3, &l_p0.pos_p, &crate::prelude::Text::from(format!("`{}` is a keyword and takes no sigil", w_p1)))
        } else {
            l_p0.clone()
        };
        let l2_p5 = if (w_p1 == &crate::prelude::Text::lit("widget")) && (sigils_p2 != &crate::prelude::Text::lit("@")) {
            crate::syntax::lexer::chars::lex_err_f(&l1_p4, start_p3, &l1_p4.pos_p, &crate::prelude::Text::lit("`widget` is a block only as `@widget:`"))
        } else {
            l1_p4.clone()
        };
        let l3_p6 = crate::syntax::lexer::push_tok_f(&l2_p5, &crate::syntax::lexer::TokKind::KKw(w_p1.clone(), sigils_p2.clone()), start_p3, &l2_p5.pos_p);
        if ((w_p1 == &crate::prelude::Text::lit("output")) || (w_p1 == &crate::prelude::Text::lit("inline_text"))) || (w_p1 == &crate::prelude::Text::lit("raw")) {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::syntax::lexer::templates::MaybeTemplate { l0_p0: l3_p6.clone(), kw_p1: w_p1.clone() }))
        } else {
            ::prism_rtl::Turn::Finished(l3_p6.clone())
        }
    }
}

/// `Start LexKeyword, x`: what the function value is when passed to `@Run`.
pub fn start_lex_keyword_f(l_p0: crate::syntax::lexer::Lex, w_p1: crate::prelude::Text, sigils_p2: crate::prelude::Text, start_p3: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::lexer::Lex>> {
    ::std::rc::Rc::new(LexKeyword { l_p0, w_p1, sigils_p2, start_p3 })
}

/// ```prism
/// LexName: unbounded fn Lex, [Text], Text, Nat, Nat -> Lex
/// ```
pub fn lex_name_f(l_p0: &crate::syntax::lexer::Lex, path_p1: &crate::prelude::Array<crate::prelude::Text>, sigils_p2: &crate::prelude::Text, start_p3: &crate::prelude::Nat, w_start_p4: &crate::prelude::Nat) -> crate::syntax::lexer::Lex {
    let (case_p6, l1_p7) = name_case_of_f(l_p0, path_p1, w_start_p4);
    let l2_p5 = if is_path_word_f(&l1_p7, sigils_p2, path_p1) {
        {
            let mut this: crate::syntax::lexer::Lex = l1_p7.clone();
            this.path_next_p = true;
            this
        }
    } else {
        l1_p7.clone()
    };
    crate::syntax::lexer::push_tok_f(&l2_p5, &crate::syntax::lexer::TokKind::KName(crate::syntax::lexer::NameTok { sigils_p: sigils_p2.clone(), path_p: path_p1.clone(), case_p: case_p6.clone() }), start_p3, &l2_p5.pos_p)
}

/// The step machine of `LexName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexName: unbounded fn Lex, [Text], Text, Nat, Nat -> Lex
/// ```
pub struct LexName {
    pub l_p0: crate::syntax::lexer::Lex,
    pub path_p1: crate::prelude::Array<crate::prelude::Text>,
    pub sigils_p2: crate::prelude::Text,
    pub start_p3: crate::prelude::Nat,
    pub w_start_p4: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::syntax::lexer::Lex> for LexName {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l_p0 = &self.l_p0;
        let path_p1 = &self.path_p1;
        let sigils_p2 = &self.sigils_p2;
        let start_p3 = &self.start_p3;
        let w_start_p4 = &self.w_start_p4;
        let (case_p6, l1_p7) = name_case_of_f(l_p0, path_p1, w_start_p4);
        let l2_p5 = if is_path_word_f(&l1_p7, sigils_p2, path_p1) {
            {
                let mut this: crate::syntax::lexer::Lex = l1_p7.clone();
                this.path_next_p = true;
                this
            }
        } else {
            l1_p7.clone()
        };
        ::prism_rtl::Turn::Finished(crate::syntax::lexer::push_tok_f(&l2_p5, &crate::syntax::lexer::TokKind::KName(crate::syntax::lexer::NameTok { sigils_p: sigils_p2.clone(), path_p: path_p1.clone(), case_p: case_p6.clone() }), start_p3, &l2_p5.pos_p))
    }
}

/// `Start LexName, x`: what the function value is when passed to `@Run`.
pub fn start_lex_name_f(l_p0: crate::syntax::lexer::Lex, path_p1: crate::prelude::Array<crate::prelude::Text>, sigils_p2: crate::prelude::Text, start_p3: crate::prelude::Nat, w_start_p4: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::lexer::Lex>> {
    ::std::rc::Rc::new(LexName { l_p0, path_p1, sigils_p2, start_p3, w_start_p4 })
}

/// ```prism
/// NameCaseOf: fn Lex, [Text], Nat -> ((NameCase, Lex))
/// ```
pub fn name_case_of_f(l_p0: &crate::syntax::lexer::Lex, path_p1: &crate::prelude::Array<crate::prelude::Text>, w_start_p2: &crate::prelude::Nat) -> (crate::syntax::lexer::NameCase, crate::syntax::lexer::Lex) {
    let last_p3 = crate::prelude::or(&crate::syntax::lexer::chars::last_o(path_p1), &crate::prelude::Text::lit(""));
    if &last_p3 == &crate::prelude::Text::lit("_") {
        (crate::syntax::lexer::NameCase::CaseTopic, l_p0.clone())
    } else {
        if (&crate::syntax::lexer::chars::head_f(&last_p3) == &crate::prelude::Text::lit("_")) && crate::syntax::lexer::chars::all_chars_f(&crate::syntax::lexer::chars::after_first_f(&last_p3), &{
            let f = ::std::rc::Rc::new(crate::syntax::lexer::chars::is_digit_f);
            ::std::rc::Rc::new(move |a0: crate::prelude::Text| {
                let fy = f.clone();
                crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        }) {
            (crate::syntax::lexer::NameCase::CaseHole, l_p0.clone())
        } else {
            if &crate::syntax::lexer::chars::head_f(&last_p3) == &crate::prelude::Text::lit("_") {
                (crate::syntax::lexer::NameCase::CaseLower, crate::syntax::lexer::chars::lex_err_f(l_p0, w_start_p2, &l_p0.pos_p, &crate::prelude::Text::lit("`_` followed by a letter is not a name: `_` alone is the topic, `_1` a hole")))
            } else {
                if crate::syntax::lexer::chars::is_reserved_ctor_f(&last_p3) {
                    (crate::syntax::lexer::NameCase::CaseReserved, l_p0.clone())
                } else {
                    if crate::syntax::lexer::chars::is_upper_f(&crate::syntax::lexer::chars::head_f(&last_p3)) {
                        {
                            let underscored_p4 = crate::prelude::fold(path_p1, &false, &(|seen_p5: &bool, seg_p6: &crate::prelude::Text| *seen_p5 || crate::syntax::lexer::chars::contains_f(seg_p6, &crate::prelude::Text::lit("_"))));
                            if underscored_p4 {
                                (crate::syntax::lexer::NameCase::CaseUpper, crate::syntax::lexer::chars::lex_err_f(l_p0, w_start_p2, &l_p0.pos_p, &crate::prelude::Text::from(format!("`{}`: a capital promises UpperCamelCase", &crate::syntax::lexer::chars::join_f(path_p1, &crate::prelude::Text::lit("."))))))
                            } else {
                                (crate::syntax::lexer::NameCase::CaseUpper, l_p0.clone())
                            }
                        }
                    } else {
                        (crate::syntax::lexer::NameCase::CaseLower, l_p0.clone())
                    }
                }
            }
        }
    }
}

/// ```prism
/// IsPathWord: fn Lex, Text, [Text] -> Bool
/// ```
pub fn is_path_word_f(l_p0: &crate::syntax::lexer::Lex, sigils_p1: &crate::prelude::Text, path_p2: &crate::prelude::Array<crate::prelude::Text>) -> bool {
    let w_p3 = crate::prelude::or(&crate::prelude::index(path_p2, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit(""));
    let words_p4 = if &w_p3 == &crate::prelude::Text::lit("at") {
        crate::prelude::Array::from(vec![crate::prelude::Text::lit("send"), crate::prelude::Text::lit("click"), crate::prelude::Text::lit("answer")])
    } else {
        crate::prelude::Array::from(vec![crate::prelude::Text::lit("click")])
    };
    let prev_p5 = match crate::syntax::lexer::chars::last_o(&l_p0.tokens_p) {
        ::std::option::Option::Some(t_p6) => match &t_p6.kind_p {
            crate::syntax::lexer::TokKind::KName(n_p7) if ((&n_p7.sigils_p == &crate::prelude::Text::lit("")) && (&crate::prelude::len(&n_p7.path_p) == &crate::prelude::Nat::from(1u32))) => crate::prelude::or(&crate::prelude::index(&n_p7.path_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")),
            _ => crate::prelude::Text::lit(""),
            _ => unreachable!("no arm matched"),
        },
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    };
    ((((&l_p0.test_depth_o != &::std::option::Option::None) && (sigils_p1 == &crate::prelude::Text::lit(""))) && (&crate::prelude::len(path_p2) == &crate::prelude::Nat::from(1u32))) && ((&w_p3 == &crate::prelude::Text::lit("at")) || (&w_p3 == &crate::prelude::Text::lit("element")))) && crate::prelude::fold(&words_p4, &false, &(|seen_p8: &bool, x_p9: &crate::prelude::Text| *seen_p8 || (x_p9 == &prev_p5)))
}
