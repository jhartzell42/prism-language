//! The module `Syntax.Lexer`, from `target/bootstrap/src/prismc/syntax/lexer/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;
pub mod chars;
pub mod corpus;
pub mod layout;
pub mod literals;
pub mod regexes;
pub mod templates;
pub mod words;

/// `AttrTok`:
///
/// ```prism
/// type AttrTok = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct AttrTok {
    pub name_p: crate::prelude::Text,
    pub tokens_p: crate::prelude::Array<Tok>,
    pub span_p: crate::syntax::Range,
}

impl crate::prelude::Show for AttrTok {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("AttrTok", &[("name", &self.name_p), ("tokens", &self.tokens_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for AttrTok {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("AttrTok", vec![("name", self.name_p.to_pod()), ("tokens", self.tokens_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for AttrTok {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(AttrTok { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, tokens_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "tokens")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `Lex`:
///
/// ```prism
/// type Lex = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Lex {
    pub src_p: crate::prelude::Text,
    pub pos_p: crate::prelude::Nat,
    pub diags_p: crate::prelude::Array<crate::syntax::Diag>,
    pub mode_p: Mode,
    pub tokens_p: crate::prelude::Array<Tok>,
    pub layout_p: crate::prelude::Array<crate::prelude::Nat>,
    pub frames_p: crate::prelude::Array<crate::prelude::Text>,
    pub last_ws_p: bool,
    pub lambda_open_p: bool,
    pub pending_open_p: bool,
    pub pending_empty_p: bool,
    pub pending_span_p: crate::syntax::Range,
    pub line_first_p: crate::prelude::Nat,
    pub mark_line_start_p: bool,
    pub first_line_p: bool,
    pub test_pending_p: crate::prelude::Text,
    pub test_depth_o: ::std::option::Option<crate::prelude::Nat>,
    pub check_depth_o: ::std::option::Option<crate::prelude::Nat>,
    pub path_next_p: bool,
}

impl crate::prelude::Show for Lex {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Lex", &[("src", &self.src_p), ("pos", &self.pos_p), ("diags", &self.diags_p), ("mode", &self.mode_p), ("tokens", &self.tokens_p), ("layout", &self.layout_p), ("frames", &self.frames_p), ("lastWs", &self.last_ws_p), ("lambdaOpen", &self.lambda_open_p), ("pendingOpen", &self.pending_open_p), ("pendingEmpty", &self.pending_empty_p), ("pendingSpan", &self.pending_span_p), ("lineFirst", &self.line_first_p), ("markLineStart", &self.mark_line_start_p), ("firstLine", &self.first_line_p), ("testPending", &self.test_pending_p), ("testDepth", &self.test_depth_o), ("checkDepth", &self.check_depth_o), ("pathNext", &self.path_next_p)]);
    }
}

impl crate::prelude::ToPod for Lex {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Lex", vec![("src", self.src_p.to_pod()), ("pos", self.pos_p.to_pod()), ("diags", self.diags_p.to_pod()), ("mode", self.mode_p.to_pod()), ("tokens", self.tokens_p.to_pod()), ("layout", self.layout_p.to_pod()), ("frames", self.frames_p.to_pod()), ("lastWs", self.last_ws_p.to_pod()), ("lambdaOpen", self.lambda_open_p.to_pod()), ("pendingOpen", self.pending_open_p.to_pod()), ("pendingEmpty", self.pending_empty_p.to_pod()), ("pendingSpan", self.pending_span_p.to_pod()), ("lineFirst", self.line_first_p.to_pod()), ("markLineStart", self.mark_line_start_p.to_pod()), ("firstLine", self.first_line_p.to_pod()), ("testPending", self.test_pending_p.to_pod()), ("testDepth", self.test_depth_o.to_pod()), ("checkDepth", self.check_depth_o.to_pod()), ("pathNext", self.path_next_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Lex {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Lex { src_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "src")?)?, pos_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "pos")?)?, diags_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "diags")?)?, mode_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "mode")?)?, tokens_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "tokens")?)?, layout_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "layout")?)?, frames_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "frames")?)?, last_ws_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "lastWs")?)?, lambda_open_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "lambdaOpen")?)?, pending_open_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "pendingOpen")?)?, pending_empty_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "pendingEmpty")?)?, pending_span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "pendingSpan")?)?, line_first_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "lineFirst")?)?, mark_line_start_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "markLineStart")?)?, first_line_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "firstLine")?)?, test_pending_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "testPending")?)?, test_depth_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "testDepth")?)?, check_depth_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "checkDepth")?)?, path_next_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "pathNext")?)? })
    }
}

/// `Lexed`:
///
/// ```prism
/// type Lexed = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Lexed {
    pub tokens_p: crate::prelude::Array<Tok>,
    pub diags_p: crate::prelude::Array<crate::syntax::Diag>,
}

impl crate::prelude::Show for Lexed {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Lexed", &[("tokens", &self.tokens_p), ("diags", &self.diags_p)]);
    }
}

impl crate::prelude::ToPod for Lexed {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Lexed", vec![("tokens", self.tokens_p.to_pod()), ("diags", self.diags_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Lexed {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Lexed { tokens_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "tokens")?)?, diags_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "diags")?)? })
    }
}

/// `Mode`:
///
/// ```prism
/// type Mode = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum Mode {
    MFile,
    MBrace(crate::prelude::Text),
    MPlaceholder(crate::prelude::Text),
    MPathKey,
}

impl crate::prelude::Show for Mode {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            Mode::MFile => p.choice("MFile", &[]),
            Mode::MBrace(a0) => p.choice("MBrace", &[a0]),
            Mode::MPlaceholder(a0) => p.choice("MPlaceholder", &[a0]),
            Mode::MPathKey => p.choice("MPathKey", &[]),
        }
    }
}

impl crate::prelude::ToPod for Mode {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            Mode::MFile => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("MFile", 0), vec![]),
            Mode::MBrace(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("MBrace", 1), vec![a0.to_pod()]),
            Mode::MPlaceholder(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("MPlaceholder", 2), vec![a0.to_pod()]),
            Mode::MPathKey => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("MPathKey", 3), vec![]),
        }
    }
}

impl crate::prelude::FromPod for Mode {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "MFile" && a.len() == 0 => ::std::result::Result::Ok(Mode::MFile),
            crate::prelude::Pod::Choice(c, a) if &**c == "MBrace" && a.len() == 1 => ::std::result::Result::Ok(Mode::MBrace(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "MPlaceholder" && a.len() == 1 => ::std::result::Result::Ok(Mode::MPlaceholder(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "MPathKey" && a.len() == 0 => ::std::result::Result::Ok(Mode::MPathKey),
            other => ::prism_rtl::pod::mismatch("a Mode", other),
        }
    }
}

/// `NameCase`:
///
/// ```prism
/// type NameCase = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum NameCase {
    CaseLower,
    CaseUpper,
    CaseTopic,
    CaseHole,
    CaseReserved,
}

impl crate::prelude::Show for NameCase {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            NameCase::CaseLower => p.choice("CaseLower", &[]),
            NameCase::CaseUpper => p.choice("CaseUpper", &[]),
            NameCase::CaseTopic => p.choice("CaseTopic", &[]),
            NameCase::CaseHole => p.choice("CaseHole", &[]),
            NameCase::CaseReserved => p.choice("CaseReserved", &[]),
        }
    }
}

impl crate::prelude::ToPod for NameCase {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            NameCase::CaseLower => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CaseLower", 0), vec![]),
            NameCase::CaseUpper => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CaseUpper", 1), vec![]),
            NameCase::CaseTopic => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CaseTopic", 2), vec![]),
            NameCase::CaseHole => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CaseHole", 3), vec![]),
            NameCase::CaseReserved => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CaseReserved", 4), vec![]),
        }
    }
}

impl crate::prelude::FromPod for NameCase {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "CaseLower" && a.len() == 0 => ::std::result::Result::Ok(NameCase::CaseLower),
            crate::prelude::Pod::Choice(c, a) if &**c == "CaseUpper" && a.len() == 0 => ::std::result::Result::Ok(NameCase::CaseUpper),
            crate::prelude::Pod::Choice(c, a) if &**c == "CaseTopic" && a.len() == 0 => ::std::result::Result::Ok(NameCase::CaseTopic),
            crate::prelude::Pod::Choice(c, a) if &**c == "CaseHole" && a.len() == 0 => ::std::result::Result::Ok(NameCase::CaseHole),
            crate::prelude::Pod::Choice(c, a) if &**c == "CaseReserved" && a.len() == 0 => ::std::result::Result::Ok(NameCase::CaseReserved),
            other => ::prism_rtl::pod::mismatch("a NameCase", other),
        }
    }
}

/// `NameTok`:
///
/// ```prism
/// type NameTok = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct NameTok {
    pub sigils_p: crate::prelude::Text,
    pub path_p: crate::prelude::Array<crate::prelude::Text>,
    pub case_p: NameCase,
}

impl crate::prelude::Show for NameTok {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("NameTok", &[("sigils", &self.sigils_p), ("path", &self.path_p), ("case", &self.case_p)]);
    }
}

impl crate::prelude::ToPod for NameTok {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("NameTok", vec![("sigils", self.sigils_p.to_pod()), ("path", self.path_p.to_pod()), ("case", self.case_p.to_pod())])
    }
}

impl crate::prelude::FromPod for NameTok {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(NameTok { sigils_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "sigils")?)?, path_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "path")?)?, case_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "case")?)? })
    }
}

/// `PathSegTok`:
///
/// ```prism
/// type PathSegTok = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum PathSegTok {
    PstNum(crate::prelude::Nat),
    PstGen(crate::prelude::Nat),
    PstKey(crate::prelude::Array<Tok>),
}

impl crate::prelude::Show for PathSegTok {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            PathSegTok::PstNum(a0) => p.choice("PstNum", &[a0]),
            PathSegTok::PstGen(a0) => p.choice("PstGen", &[a0]),
            PathSegTok::PstKey(a0) => p.choice("PstKey", &[a0]),
        }
    }
}

impl crate::prelude::ToPod for PathSegTok {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            PathSegTok::PstNum(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PstNum", 0), vec![a0.to_pod()]),
            PathSegTok::PstGen(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PstGen", 1), vec![a0.to_pod()]),
            PathSegTok::PstKey(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PstKey", 2), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for PathSegTok {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "PstNum" && a.len() == 1 => ::std::result::Result::Ok(PathSegTok::PstNum(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "PstGen" && a.len() == 1 => ::std::result::Result::Ok(PathSegTok::PstGen(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "PstKey" && a.len() == 1 => ::std::result::Result::Ok(PathSegTok::PstKey(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a PathSegTok", other),
        }
    }
}

/// `TPartTok`:
///
/// ```prism
/// type TPartTok = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum TPartTok {
    TptText(crate::prelude::Text),
    TptPlaceholder(crate::prelude::Array<Tok>, ::std::option::Option<crate::prelude::Nat>, crate::syntax::Range),
    TptBlock(crate::prelude::Array<Tok>, crate::syntax::Range),
    TptCall(NameTok, crate::prelude::Array<AttrTok>, ::std::option::Option<crate::prelude::Array<TPartTok>>, crate::syntax::Range),
}

impl crate::prelude::Show for TPartTok {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            TPartTok::TptText(a0) => p.choice("TptText", &[a0]),
            TPartTok::TptPlaceholder(a0, a1, a2) => p.choice("TptPlaceholder", &[a0, a1, a2]),
            TPartTok::TptBlock(a0, a1) => p.choice("TptBlock", &[a0, a1]),
            TPartTok::TptCall(a0, a1, a2, a3) => p.choice("TptCall", &[a0, a1, a2, a3]),
        }
    }
}

impl crate::prelude::ToPod for TPartTok {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            TPartTok::TptText(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TptText", 0), vec![a0.to_pod()]),
            TPartTok::TptPlaceholder(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TptPlaceholder", 1), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            TPartTok::TptBlock(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TptBlock", 2), vec![a0.to_pod(), a1.to_pod()]),
            TPartTok::TptCall(a0, a1, a2, a3) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TptCall", 3), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for TPartTok {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "TptText" && a.len() == 1 => ::std::result::Result::Ok(TPartTok::TptText(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TptPlaceholder" && a.len() == 3 => ::std::result::Result::Ok(TPartTok::TptPlaceholder(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TptBlock" && a.len() == 2 => ::std::result::Result::Ok(TPartTok::TptBlock(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TptCall" && a.len() == 4 => ::std::result::Result::Ok(TPartTok::TptCall(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?, crate::prelude::FromPod::from_pod(&a[3])?)),
            other => ::prism_rtl::pod::mismatch("a TPartTok", other),
        }
    }
}

/// `TemplateTok`:
///
/// ```prism
/// type TemplateTok = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct TemplateTok {
    pub keyword_p: crate::prelude::Text,
    pub lang_p: crate::prelude::Text,
    pub delims_p: crate::prelude::Text,
    pub parts_p: crate::prelude::Array<TPartTok>,
}

impl crate::prelude::Show for TemplateTok {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("TemplateTok", &[("keyword", &self.keyword_p), ("lang", &self.lang_p), ("delims", &self.delims_p), ("parts", &self.parts_p)]);
    }
}

impl crate::prelude::ToPod for TemplateTok {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("TemplateTok", vec![("keyword", self.keyword_p.to_pod()), ("lang", self.lang_p.to_pod()), ("delims", self.delims_p.to_pod()), ("parts", self.parts_p.to_pod())])
    }
}

impl crate::prelude::FromPod for TemplateTok {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(TemplateTok { keyword_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "keyword")?)?, lang_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "lang")?)?, delims_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "delims")?)?, parts_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "parts")?)? })
    }
}

/// `TextSegTok`:
///
/// ```prism
/// type TextSegTok = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum TextSegTok {
    TsPlain(crate::prelude::Text),
    TsPlaceholder(crate::prelude::Array<Tok>, crate::syntax::Range),
}

impl crate::prelude::Show for TextSegTok {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            TextSegTok::TsPlain(a0) => p.choice("TsPlain", &[a0]),
            TextSegTok::TsPlaceholder(a0, a1) => p.choice("TsPlaceholder", &[a0, a1]),
        }
    }
}

impl crate::prelude::ToPod for TextSegTok {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            TextSegTok::TsPlain(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TsPlain", 0), vec![a0.to_pod()]),
            TextSegTok::TsPlaceholder(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TsPlaceholder", 1), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for TextSegTok {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "TsPlain" && a.len() == 1 => ::std::result::Result::Ok(TextSegTok::TsPlain(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TsPlaceholder" && a.len() == 2 => ::std::result::Result::Ok(TextSegTok::TsPlaceholder(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            other => ::prism_rtl::pod::mismatch("a TextSegTok", other),
        }
    }
}

/// `Tok`:
///
/// ```prism
/// type Tok = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Tok {
    pub kind_p: TokKind,
    pub span_p: crate::syntax::Range,
    pub touches_p: bool,
    pub line_start_p: bool,
}

impl crate::prelude::Show for Tok {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Tok", &[("kind", &self.kind_p), ("span", &self.span_p), ("touches", &self.touches_p), ("lineStart", &self.line_start_p)]);
    }
}

impl crate::prelude::ToPod for Tok {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Tok", vec![("kind", self.kind_p.to_pod()), ("span", self.span_p.to_pod()), ("touches", self.touches_p.to_pod()), ("lineStart", self.line_start_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Tok {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Tok { kind_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "kind")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)?, touches_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "touches")?)?, line_start_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "lineStart")?)? })
    }
}

/// `TokKind`:
///
/// ```prism
/// type TokKind = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum TokKind {
    KName(NameTok),
    KFamily(crate::prelude::Array<crate::prelude::Text>),
    KTrait(crate::prelude::Array<crate::prelude::Text>),
    KKw(crate::prelude::Text, crate::prelude::Text),
    KFree(crate::prelude::Text),
    KLensDot,
    KInt(crate::prelude::Text, crate::prelude::Text),
    KFloat(crate::prelude::Text, crate::prelude::Text),
    KDuration(crate::prelude::Text, crate::prelude::Text, crate::prelude::Text),
    KChar(crate::prelude::Text, crate::prelude::Text),
    KText(crate::prelude::Text, crate::prelude::Array<TextSegTok>),
    KRegex(crate::prelude::Text, crate::syntax::RegexLit),
    KTemplate(TemplateTok),
    KOp(crate::prelude::Text, bool),
    KSuffixed(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>),
    KDot(bool),
    KDotDot,
    KComma,
    KColon,
    KSemi,
    KBackslash,
    KLambdaBar(bool),
    KBar,
    KLtLt,
    KGtGt,
    KOpen(crate::prelude::Text, bool),
    KClose(crate::prelude::Text),
    KAbsent,
    KNonEmpty,
    KPath(crate::prelude::Array<PathSegTok>),
    KLayOpen,
    KLaySep,
    KLayClose,
    KEof,
}

impl crate::prelude::Show for TokKind {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            TokKind::KName(a0) => p.choice("KName", &[a0]),
            TokKind::KFamily(a0) => p.choice("KFamily", &[a0]),
            TokKind::KTrait(a0) => p.choice("KTrait", &[a0]),
            TokKind::KKw(a0, a1) => p.choice("KKw", &[a0, a1]),
            TokKind::KFree(a0) => p.choice("KFree", &[a0]),
            TokKind::KLensDot => p.choice("KLensDot", &[]),
            TokKind::KInt(a0, a1) => p.choice("KInt", &[a0, a1]),
            TokKind::KFloat(a0, a1) => p.choice("KFloat", &[a0, a1]),
            TokKind::KDuration(a0, a1, a2) => p.choice("KDuration", &[a0, a1, a2]),
            TokKind::KChar(a0, a1) => p.choice("KChar", &[a0, a1]),
            TokKind::KText(a0, a1) => p.choice("KText", &[a0, a1]),
            TokKind::KRegex(a0, a1) => p.choice("KRegex", &[a0, a1]),
            TokKind::KTemplate(a0) => p.choice("KTemplate", &[a0]),
            TokKind::KOp(a0, a1) => p.choice("KOp", &[a0, a1]),
            TokKind::KSuffixed(a0, a1) => p.choice("KSuffixed", &[a0, a1]),
            TokKind::KDot(a0) => p.choice("KDot", &[a0]),
            TokKind::KDotDot => p.choice("KDotDot", &[]),
            TokKind::KComma => p.choice("KComma", &[]),
            TokKind::KColon => p.choice("KColon", &[]),
            TokKind::KSemi => p.choice("KSemi", &[]),
            TokKind::KBackslash => p.choice("KBackslash", &[]),
            TokKind::KLambdaBar(a0) => p.choice("KLambdaBar", &[a0]),
            TokKind::KBar => p.choice("KBar", &[]),
            TokKind::KLtLt => p.choice("KLtLt", &[]),
            TokKind::KGtGt => p.choice("KGtGt", &[]),
            TokKind::KOpen(a0, a1) => p.choice("KOpen", &[a0, a1]),
            TokKind::KClose(a0) => p.choice("KClose", &[a0]),
            TokKind::KAbsent => p.choice("KAbsent", &[]),
            TokKind::KNonEmpty => p.choice("KNonEmpty", &[]),
            TokKind::KPath(a0) => p.choice("KPath", &[a0]),
            TokKind::KLayOpen => p.choice("KLayOpen", &[]),
            TokKind::KLaySep => p.choice("KLaySep", &[]),
            TokKind::KLayClose => p.choice("KLayClose", &[]),
            TokKind::KEof => p.choice("KEof", &[]),
        }
    }
}

impl crate::prelude::ToPod for TokKind {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            TokKind::KName(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KName", 0), vec![a0.to_pod()]),
            TokKind::KFamily(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KFamily", 1), vec![a0.to_pod()]),
            TokKind::KTrait(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KTrait", 2), vec![a0.to_pod()]),
            TokKind::KKw(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KKw", 3), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KFree(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KFree", 4), vec![a0.to_pod()]),
            TokKind::KLensDot => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KLensDot", 5), vec![]),
            TokKind::KInt(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KInt", 6), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KFloat(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KFloat", 7), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KDuration(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KDuration", 8), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            TokKind::KChar(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KChar", 9), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KText(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KText", 10), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KRegex(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KRegex", 11), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KTemplate(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KTemplate", 12), vec![a0.to_pod()]),
            TokKind::KOp(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KOp", 13), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KSuffixed(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KSuffixed", 14), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KDot(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KDot", 15), vec![a0.to_pod()]),
            TokKind::KDotDot => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KDotDot", 16), vec![]),
            TokKind::KComma => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KComma", 17), vec![]),
            TokKind::KColon => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KColon", 18), vec![]),
            TokKind::KSemi => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KSemi", 19), vec![]),
            TokKind::KBackslash => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KBackslash", 20), vec![]),
            TokKind::KLambdaBar(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KLambdaBar", 21), vec![a0.to_pod()]),
            TokKind::KBar => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KBar", 22), vec![]),
            TokKind::KLtLt => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KLtLt", 23), vec![]),
            TokKind::KGtGt => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KGtGt", 24), vec![]),
            TokKind::KOpen(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KOpen", 25), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KClose(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KClose", 26), vec![a0.to_pod()]),
            TokKind::KAbsent => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KAbsent", 27), vec![]),
            TokKind::KNonEmpty => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KNonEmpty", 28), vec![]),
            TokKind::KPath(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KPath", 29), vec![a0.to_pod()]),
            TokKind::KLayOpen => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KLayOpen", 30), vec![]),
            TokKind::KLaySep => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KLaySep", 31), vec![]),
            TokKind::KLayClose => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KLayClose", 32), vec![]),
            TokKind::KEof => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("KEof", 33), vec![]),
        }
    }
}

impl crate::prelude::FromPod for TokKind {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "KName" && a.len() == 1 => ::std::result::Result::Ok(TokKind::KName(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "KFamily" && a.len() == 1 => ::std::result::Result::Ok(TokKind::KFamily(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "KTrait" && a.len() == 1 => ::std::result::Result::Ok(TokKind::KTrait(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "KKw" && a.len() == 2 => ::std::result::Result::Ok(TokKind::KKw(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "KFree" && a.len() == 1 => ::std::result::Result::Ok(TokKind::KFree(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "KLensDot" && a.len() == 0 => ::std::result::Result::Ok(TokKind::KLensDot),
            crate::prelude::Pod::Choice(c, a) if &**c == "KInt" && a.len() == 2 => ::std::result::Result::Ok(TokKind::KInt(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "KFloat" && a.len() == 2 => ::std::result::Result::Ok(TokKind::KFloat(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "KDuration" && a.len() == 3 => ::std::result::Result::Ok(TokKind::KDuration(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "KChar" && a.len() == 2 => ::std::result::Result::Ok(TokKind::KChar(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "KText" && a.len() == 2 => ::std::result::Result::Ok(TokKind::KText(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "KRegex" && a.len() == 2 => ::std::result::Result::Ok(TokKind::KRegex(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "KTemplate" && a.len() == 1 => ::std::result::Result::Ok(TokKind::KTemplate(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "KOp" && a.len() == 2 => ::std::result::Result::Ok(TokKind::KOp(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "KSuffixed" && a.len() == 2 => ::std::result::Result::Ok(TokKind::KSuffixed(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "KDot" && a.len() == 1 => ::std::result::Result::Ok(TokKind::KDot(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "KDotDot" && a.len() == 0 => ::std::result::Result::Ok(TokKind::KDotDot),
            crate::prelude::Pod::Choice(c, a) if &**c == "KComma" && a.len() == 0 => ::std::result::Result::Ok(TokKind::KComma),
            crate::prelude::Pod::Choice(c, a) if &**c == "KColon" && a.len() == 0 => ::std::result::Result::Ok(TokKind::KColon),
            crate::prelude::Pod::Choice(c, a) if &**c == "KSemi" && a.len() == 0 => ::std::result::Result::Ok(TokKind::KSemi),
            crate::prelude::Pod::Choice(c, a) if &**c == "KBackslash" && a.len() == 0 => ::std::result::Result::Ok(TokKind::KBackslash),
            crate::prelude::Pod::Choice(c, a) if &**c == "KLambdaBar" && a.len() == 1 => ::std::result::Result::Ok(TokKind::KLambdaBar(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "KBar" && a.len() == 0 => ::std::result::Result::Ok(TokKind::KBar),
            crate::prelude::Pod::Choice(c, a) if &**c == "KLtLt" && a.len() == 0 => ::std::result::Result::Ok(TokKind::KLtLt),
            crate::prelude::Pod::Choice(c, a) if &**c == "KGtGt" && a.len() == 0 => ::std::result::Result::Ok(TokKind::KGtGt),
            crate::prelude::Pod::Choice(c, a) if &**c == "KOpen" && a.len() == 2 => ::std::result::Result::Ok(TokKind::KOpen(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "KClose" && a.len() == 1 => ::std::result::Result::Ok(TokKind::KClose(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "KAbsent" && a.len() == 0 => ::std::result::Result::Ok(TokKind::KAbsent),
            crate::prelude::Pod::Choice(c, a) if &**c == "KNonEmpty" && a.len() == 0 => ::std::result::Result::Ok(TokKind::KNonEmpty),
            crate::prelude::Pod::Choice(c, a) if &**c == "KPath" && a.len() == 1 => ::std::result::Result::Ok(TokKind::KPath(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "KLayOpen" && a.len() == 0 => ::std::result::Result::Ok(TokKind::KLayOpen),
            crate::prelude::Pod::Choice(c, a) if &**c == "KLaySep" && a.len() == 0 => ::std::result::Result::Ok(TokKind::KLaySep),
            crate::prelude::Pod::Choice(c, a) if &**c == "KLayClose" && a.len() == 0 => ::std::result::Result::Ok(TokKind::KLayClose),
            crate::prelude::Pod::Choice(c, a) if &**c == "KEof" && a.len() == 0 => ::std::result::Result::Ok(TokKind::KEof),
            other => ::prism_rtl::pod::mismatch("a TokKind", other),
        }
    }
}

/// ```prism
/// Fresh: fn Lex, Mode -> Lex
/// ```
pub fn fresh_f(l_p0: &Lex, mode_p1: &Mode) -> Lex {
    Lex { src_p: l_p0.src_p.clone(), pos_p: l_p0.pos_p.clone(), diags_p: l_p0.diags_p.clone(), mode_p: mode_p1.clone(), tokens_p: crate::prelude::Array::new(), layout_p: crate::prelude::Array::new(), frames_p: crate::prelude::Array::new(), last_ws_p: true, lambda_open_p: false, pending_open_p: false, pending_empty_p: false, pending_span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) }, line_first_p: crate::prelude::Nat::from(0u32), mark_line_start_p: false, first_line_p: true, test_pending_p: crate::prelude::Text::lit(""), test_depth_o: ::std::option::Option::None, check_depth_o: ::std::option::Option::None, path_next_p: false }
}

/// ```prism
/// IsLayoutOrEof: fn TokKind -> Bool
/// ```
pub fn is_layout_or_eof_f(tok_kind0: &TokKind) -> bool {
    match tok_kind0 {
        TokKind::KLayOpen => true,
        TokKind::KLaySep => true,
        TokKind::KLayClose => true,
        TokKind::KEof => true,
        _ => false,
    }
}

/// ```prism
/// IsLayout: fn TokKind -> Bool
/// ```
pub fn is_layout_f(tok_kind0: &TokKind) -> bool {
    match tok_kind0 {
        TokKind::KLayOpen => true,
        TokKind::KLaySep => true,
        TokKind::KLayClose => true,
        _ => false,
    }
}

/// ```prism
/// EndsOperand: fn TokKind -> Bool
/// ```
pub fn ends_operand_f(tok_kind0: &TokKind) -> bool {
    match tok_kind0 {
        TokKind::KName(_) => true,
        TokKind::KFamily(_) => true,
        TokKind::KInt(_, _) => true,
        TokKind::KFloat(_, _) => true,
        TokKind::KDuration(_, _, _) => true,
        TokKind::KChar(_, _) => true,
        TokKind::KText(_, _) => true,
        TokKind::KRegex(_, _) => true,
        TokKind::KTemplate(_) => true,
        TokKind::KClose(_) => true,
        TokKind::KGtGt => true,
        TokKind::KNonEmpty => true,
        TokKind::KAbsent => true,
        TokKind::KKw(w_p0, _) => is_value_word_f(w_p0),
        _ => false,
    }
}

/// ```prism
/// IsValueWord: fn Text -> Bool
/// ```
pub fn is_value_word_f(w_p0: &crate::prelude::Text) -> bool {
    ((w_p0 == &crate::prelude::Text::lit("unit")) || (w_p0 == &crate::prelude::Text::lit("nil"))) || is_bound_word_f(w_p0)
}

/// ```prism
/// IsBoundWord: fn Text -> Bool
/// ```
pub fn is_bound_word_f(w_p0: &crate::prelude::Text) -> bool {
    (((w_p0 == &crate::prelude::Text::lit("key")) || (w_p0 == &crate::prelude::Text::lit("ix"))) || (w_p0 == &crate::prelude::Text::lit("jx"))) || (w_p0 == &crate::prelude::Text::lit("kx"))
}

/// ```prism
/// let keywordList
/// ```
pub fn keyword_list_p() -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::Array::from(vec![crate::prelude::Text::lit("module"), crate::prelude::Text::lit("emit"), crate::prelude::Text::lit("use"), crate::prelude::Text::lit("type"), crate::prelude::Text::lit("record"), crate::prelude::Text::lit("choice"), crate::prelude::Text::lit("row"), crate::prelude::Text::lit("tag"), crate::prelude::Text::lit("of"), crate::prelude::Text::lit("derive"), crate::prelude::Text::lit("trait"), crate::prelude::Text::lit("impl"), crate::prelude::Text::lit("where"), crate::prelude::Text::lit("any"), crate::prelude::Text::lit("let"), crate::prelude::Text::lit("fn"), crate::prelude::Text::lit("test"), crate::prelude::Text::lit("check"), crate::prelude::Text::lit("widget"), crate::prelude::Text::lit("rebuild"), crate::prelude::Text::lit("for"), crate::prelude::Text::lit("given"), crate::prelude::Text::lit("monad"), crate::prelude::Text::lit("update"), crate::prelude::Text::lit("while"), crate::prelude::Text::lit("match"), crate::prelude::Text::lit("if"), crate::prelude::Text::lit("else"), crate::prelude::Text::lit("otherwise"), crate::prelude::Text::lit("require"), crate::prelude::Text::lit("forbid"), crate::prelude::Text::lit("return"), crate::prelude::Text::lit("ignore"), crate::prelude::Text::lit("then"), crate::prelude::Text::lit("on"), crate::prelude::Text::lit("not"), crate::prelude::Text::lit("and"), crate::prelude::Text::lit("or"), crate::prelude::Text::lit("mod"), crate::prelude::Text::lit("as"), crate::prelude::Text::lit("output"), crate::prelude::Text::lit("inline_text"), crate::prelude::Text::lit("raw"), crate::prelude::Text::lit("unbounded"), crate::prelude::Text::lit("unit"), crate::prelude::Text::lit("nil"), crate::prelude::Text::lit("key"), crate::prelude::Text::lit("ix"), crate::prelude::Text::lit("jx"), crate::prelude::Text::lit("kx")])
}

/// ```prism
/// let keywordSet
/// ```
pub fn keyword_set_p() -> crate::prelude::Map<crate::prelude::Text, bool> {
    crate::prelude::map(&crate::prelude::each(&keyword_list_p(), &(|w_p0: &crate::prelude::Text| (w_p0.clone(), true))))
}

/// ```prism
/// IsKeyword: fn Text -> Bool
/// ```
pub fn is_keyword_f(w_p0: &crate::prelude::Text) -> bool {
    &crate::prelude::get(&keyword_set_p(), w_p0) != &::std::option::Option::None
}

/// ```prism
/// TakesSuffix: fn Text -> Bool
/// ```
pub fn takes_suffix_f(op_p0: &crate::prelude::Text) -> bool {
    crate::prelude::fold(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("<="), crate::prelude::Text::lit("=="), crate::prelude::Text::lit("!="), crate::prelude::Text::lit("<"), crate::prelude::Text::lit(">"), crate::prelude::Text::lit(">="), crate::prelude::Text::lit("+"), crate::prelude::Text::lit("-"), crate::prelude::Text::lit("*"), crate::prelude::Text::lit("/"), crate::prelude::Text::lit("+?"), crate::prelude::Text::lit("-?"), crate::prelude::Text::lit("*?")]), &false, &(|seen_p1: &bool, o_p2: &crate::prelude::Text| *seen_p1 || (o_p2 == op_p0)))
}

/// ```prism
/// CloseChar: fn Text -> Text
/// ```
pub fn close_char_f(text0: &crate::prelude::Text) -> crate::prelude::Text {
    match text0 {
        c0_0 if (c0_0 == &crate::prelude::Text::lit("(")) => crate::prelude::Text::lit(")"),
        c1_0 if (c1_0 == &crate::prelude::Text::lit("[")) => crate::prelude::Text::lit("]"),
        _ => crate::prelude::Text::lit("}"),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// OpenOf: fn Text -> Text
/// ```
pub fn open_of_f(text0: &crate::prelude::Text) -> crate::prelude::Text {
    match text0 {
        c0_0 if (c0_0 == &crate::prelude::Text::lit(")")) => crate::prelude::Text::lit("("),
        c1_0 if (c1_0 == &crate::prelude::Text::lit("]")) => crate::prelude::Text::lit("["),
        _ => crate::prelude::Text::lit("{"),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// PrefixPosition: fn Lex -> Bool
/// ```
pub fn prefix_position_f(l_p0: &Lex) -> bool {
    l_p0.last_ws_p || no_operand_before_f(&crate::syntax::lexer::chars::last_o(&l_p0.tokens_p))
}

/// ```prism
/// NoOperandBefore: fn ?Tok -> Bool
/// ```
pub fn no_operand_before_f(opt0: &::std::option::Option<Tok>) -> bool {
    match opt0 {
        ::std::option::Option::None => true,
        ::std::option::Option::Some(t_p0) => !ends_operand_f(&t_p0.kind_p),
    }
}

/// ```prism
/// TestWordOf: fn TokKind -> Text
/// ```
pub fn test_word_of_f(tok_kind0: &TokKind) -> crate::prelude::Text {
    match tok_kind0 {
        TokKind::KKw(c0_0_0, _) if (c0_0_0 == &crate::prelude::Text::lit("test")) => crate::prelude::Text::lit("test"),
        TokKind::KKw(c1_0_0, _) if (c1_0_0 == &crate::prelude::Text::lit("check")) => crate::prelude::Text::lit("check"),
        _ => crate::prelude::Text::lit(""),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// AllLayout: fn [Tok] -> Bool
/// ```
pub fn all_layout_f(ts_p0: &crate::prelude::Array<Tok>) -> bool {
    crate::prelude::fold(ts_p0, &true, &(|ok_p1: &bool, t_p2: &Tok| *ok_p1 && is_layout_f(&t_p2.kind_p)))
}

/// ```prism
/// PushTok: fn Lex, TokKind, Nat, Nat -> Lex
/// ```
pub fn push_tok_f(l_p0: &Lex, kind_p1: &TokKind, start_p2: &crate::prelude::Nat, end_p3: &crate::prelude::Nat) -> Lex {
    let mut this: Lex = l_p0.clone();
    let layout_p4 = is_layout_or_eof_f(kind_p1);
    let touches_p5 = (!this.last_ws_p && (&crate::prelude::len(&this.tokens_p) > &crate::prelude::Nat::from(0u32))) && !layout_p4;
    let line_start_p6 = !layout_p4 && this.mark_line_start_p;
    if !layout_p4 {
        this.mark_line_start_p = false;
    }
    let word_p7 = test_word_of_f(kind_p1);
    if (((&word_p7 != &crate::prelude::Text::lit("")) && (&this.mode_p == &Mode::MFile)) && (&crate::prelude::len(&this.layout_p) == &crate::prelude::Nat::from(1u32))) && all_layout_f(&crate::prelude::drop(&this.tokens_p, &this.line_first_p)) {
        this.test_pending_p = word_p7.clone();
    }
    this.tokens_p = crate::prelude::push(&this.tokens_p, &Tok { kind_p: kind_p1.clone(), span_p: crate::syntax::Range { start_p: start_p2.clone(), end_p: end_p3.clone() }, touches_p: touches_p5, line_start_p: line_start_p6 });
    this.last_ws_p = false;
    this
}

/// ```prism
/// LayoutOn: fn Mode -> Bool
/// ```
pub fn layout_on_f(mode0: &Mode) -> bool {
    match mode0 {
        Mode::MFile => true,
        Mode::MBrace(_) => true,
        _ => false,
    }
}

/// ```prism
/// LayoutActive: fn Lex -> Bool
/// ```
pub fn layout_active_f(l_p0: &Lex) -> bool {
    layout_on_f(&l_p0.mode_p) && (&crate::prelude::len(&l_p0.frames_p) == &crate::prelude::Nat::from(0u32))
}

/// ```prism
/// FatArrowOn: fn Lex -> Bool
/// ```
pub fn fat_arrow_on_f(l_p0: &Lex) -> bool {
    (&l_p0.test_depth_o != &::std::option::Option::None) || (&l_p0.check_depth_o != &::std::option::Option::None)
}
