//! The module `Syntax.Lexer`, from `target/bootstrap/src/prismc/syntax/lexer/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `AttrTok`:
///
/// ```prism
/// type AttrTok = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct AttrTok {
    pub name: Text,
    pub tokens: Array<Tok>,
    pub span: crate::syntax::Range,
}

impl Show for AttrTok {
    fn show(&self, p: &mut Printer) {
        p.record("AttrTok", &[("name", &self.name), ("tokens", &self.tokens), ("span", &self.span)]);
    }
}

impl ToPod for AttrTok {
    fn to_pod(&self) -> Pod {
        Pod::record("AttrTok", vec![("name", self.name.to_pod()), ("tokens", self.tokens.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for AttrTok {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(AttrTok { name: FromPod::from_pod(field(p, "name")?)?, tokens: FromPod::from_pod(field(p, "tokens")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `CallRead`:
///
/// ```prism
/// type CallRead = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CallRead {
    pub l: Lex,
    pub attrs: Array<AttrTok>,
    pub body: Option<Array<TPartTok>>,
    pub going: bool,
}

impl Show for CallRead {
    fn show(&self, p: &mut Printer) {
        p.record("CallRead", &[("l", &self.l), ("attrs", &self.attrs), ("body", &self.body), ("going", &self.going)]);
    }
}

impl ToPod for CallRead {
    fn to_pod(&self) -> Pod {
        Pod::record("CallRead", vec![("l", self.l.to_pod()), ("attrs", self.attrs.to_pod()), ("body", self.body.to_pod()), ("going", self.going.to_pod())])
    }
}

impl FromPod for CallRead {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CallRead { l: FromPod::from_pod(field(p, "l")?)?, attrs: FromPod::from_pod(field(p, "attrs")?)?, body: FromPod::from_pod(field(p, "body")?)?, going: FromPod::from_pod(field(p, "going")?)? })
    }
}

/// `Lex`:
///
/// ```prism
/// type Lex = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Lex {
    pub src: Text,
    pub pos: Nat,
    pub diags: Array<crate::syntax::Diag>,
    pub mode: Mode,
    pub tokens: Array<Tok>,
    pub layout: Array<Nat>,
    pub frames: Array<Text>,
    pub last_ws: bool,
    pub lambda_open: bool,
    pub pending_open: bool,
    pub pending_span: crate::syntax::Range,
    pub line_first: Nat,
    pub mark_line_start: bool,
    pub first_line: bool,
    pub test_pending: Text,
    pub test_depth: Option<Nat>,
    pub check_depth: Option<Nat>,
    pub path_next: bool,
}

impl Show for Lex {
    fn show(&self, p: &mut Printer) {
        p.record("Lex", &[("src", &self.src), ("pos", &self.pos), ("diags", &self.diags), ("mode", &self.mode), ("tokens", &self.tokens), ("layout", &self.layout), ("frames", &self.frames), ("last_ws", &self.last_ws), ("lambda_open", &self.lambda_open), ("pending_open", &self.pending_open), ("pending_span", &self.pending_span), ("line_first", &self.line_first), ("mark_line_start", &self.mark_line_start), ("first_line", &self.first_line), ("test_pending", &self.test_pending), ("test_depth", &self.test_depth), ("check_depth", &self.check_depth), ("path_next", &self.path_next)]);
    }
}

impl ToPod for Lex {
    fn to_pod(&self) -> Pod {
        Pod::record("Lex", vec![("src", self.src.to_pod()), ("pos", self.pos.to_pod()), ("diags", self.diags.to_pod()), ("mode", self.mode.to_pod()), ("tokens", self.tokens.to_pod()), ("layout", self.layout.to_pod()), ("frames", self.frames.to_pod()), ("last_ws", self.last_ws.to_pod()), ("lambda_open", self.lambda_open.to_pod()), ("pending_open", self.pending_open.to_pod()), ("pending_span", self.pending_span.to_pod()), ("line_first", self.line_first.to_pod()), ("mark_line_start", self.mark_line_start.to_pod()), ("first_line", self.first_line.to_pod()), ("test_pending", self.test_pending.to_pod()), ("test_depth", self.test_depth.to_pod()), ("check_depth", self.check_depth.to_pod()), ("path_next", self.path_next.to_pod())])
    }
}

impl FromPod for Lex {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Lex { src: FromPod::from_pod(field(p, "src")?)?, pos: FromPod::from_pod(field(p, "pos")?)?, diags: FromPod::from_pod(field(p, "diags")?)?, mode: FromPod::from_pod(field(p, "mode")?)?, tokens: FromPod::from_pod(field(p, "tokens")?)?, layout: FromPod::from_pod(field(p, "layout")?)?, frames: FromPod::from_pod(field(p, "frames")?)?, last_ws: FromPod::from_pod(field(p, "last_ws")?)?, lambda_open: FromPod::from_pod(field(p, "lambda_open")?)?, pending_open: FromPod::from_pod(field(p, "pending_open")?)?, pending_span: FromPod::from_pod(field(p, "pending_span")?)?, line_first: FromPod::from_pod(field(p, "line_first")?)?, mark_line_start: FromPod::from_pod(field(p, "mark_line_start")?)?, first_line: FromPod::from_pod(field(p, "first_line")?)?, test_pending: FromPod::from_pod(field(p, "test_pending")?)?, test_depth: FromPod::from_pod(field(p, "test_depth")?)?, check_depth: FromPod::from_pod(field(p, "check_depth")?)?, path_next: FromPod::from_pod(field(p, "path_next")?)? })
    }
}

/// `Lexed`:
///
/// ```prism
/// type Lexed = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Lexed {
    pub tokens: Array<Tok>,
    pub diags: Array<crate::syntax::Diag>,
}

impl Show for Lexed {
    fn show(&self, p: &mut Printer) {
        p.record("Lexed", &[("tokens", &self.tokens), ("diags", &self.diags)]);
    }
}

impl ToPod for Lexed {
    fn to_pod(&self) -> Pod {
        Pod::record("Lexed", vec![("tokens", self.tokens.to_pod()), ("diags", self.diags.to_pod())])
    }
}

impl FromPod for Lexed {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Lexed { tokens: FromPod::from_pod(field(p, "tokens")?)?, diags: FromPod::from_pod(field(p, "diags")?)? })
    }
}

/// `Mode`:
///
/// ```prism
/// type Mode = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Mode {
    MFile,
    MBrace(Text),
    MPlaceholder(Text),
    MPathKey,
}

impl Show for Mode {
    fn show(&self, p: &mut Printer) {
        match self {
            Mode::MFile => p.choice("MFile", &[]),
            Mode::MBrace(a0) => p.choice("MBrace", &[a0]),
            Mode::MPlaceholder(a0) => p.choice("MPlaceholder", &[a0]),
            Mode::MPathKey => p.choice("MPathKey", &[]),
        }
    }
}

impl ToPod for Mode {
    fn to_pod(&self) -> Pod {
        match self {
            Mode::MFile => Pod::Choice("MFile".into(), vec![]),
            Mode::MBrace(a0) => Pod::Choice("MBrace".into(), vec![a0.to_pod()]),
            Mode::MPlaceholder(a0) => Pod::Choice("MPlaceholder".into(), vec![a0.to_pod()]),
            Mode::MPathKey => Pod::Choice("MPathKey".into(), vec![]),
        }
    }
}

impl FromPod for Mode {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "MFile" && a.len() == 0 => Ok(Mode::MFile),
            Pod::Choice(c, a) if &**c == "MBrace" && a.len() == 1 => Ok(Mode::MBrace(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "MPlaceholder" && a.len() == 1 => Ok(Mode::MPlaceholder(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "MPathKey" && a.len() == 0 => Ok(Mode::MPathKey),
            other => mismatch("a Mode", other),
        }
    }
}

/// `NameCase`:
///
/// ```prism
/// type NameCase = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum NameCase {
    CaseLower,
    CaseUpper,
    CaseTopic,
    CaseHole,
    CaseReserved,
}

impl Show for NameCase {
    fn show(&self, p: &mut Printer) {
        match self {
            NameCase::CaseLower => p.choice("CaseLower", &[]),
            NameCase::CaseUpper => p.choice("CaseUpper", &[]),
            NameCase::CaseTopic => p.choice("CaseTopic", &[]),
            NameCase::CaseHole => p.choice("CaseHole", &[]),
            NameCase::CaseReserved => p.choice("CaseReserved", &[]),
        }
    }
}

impl ToPod for NameCase {
    fn to_pod(&self) -> Pod {
        match self {
            NameCase::CaseLower => Pod::Choice("CaseLower".into(), vec![]),
            NameCase::CaseUpper => Pod::Choice("CaseUpper".into(), vec![]),
            NameCase::CaseTopic => Pod::Choice("CaseTopic".into(), vec![]),
            NameCase::CaseHole => Pod::Choice("CaseHole".into(), vec![]),
            NameCase::CaseReserved => Pod::Choice("CaseReserved".into(), vec![]),
        }
    }
}

impl FromPod for NameCase {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "CaseLower" && a.len() == 0 => Ok(NameCase::CaseLower),
            Pod::Choice(c, a) if &**c == "CaseUpper" && a.len() == 0 => Ok(NameCase::CaseUpper),
            Pod::Choice(c, a) if &**c == "CaseTopic" && a.len() == 0 => Ok(NameCase::CaseTopic),
            Pod::Choice(c, a) if &**c == "CaseHole" && a.len() == 0 => Ok(NameCase::CaseHole),
            Pod::Choice(c, a) if &**c == "CaseReserved" && a.len() == 0 => Ok(NameCase::CaseReserved),
            other => mismatch("a NameCase", other),
        }
    }
}

/// `NameTok`:
///
/// ```prism
/// type NameTok = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct NameTok {
    pub sigils: Text,
    pub path_: Array<Text>,
    pub case: NameCase,
}

impl Show for NameTok {
    fn show(&self, p: &mut Printer) {
        p.record("NameTok", &[("sigils", &self.sigils), ("path", &self.path_), ("case", &self.case)]);
    }
}

impl ToPod for NameTok {
    fn to_pod(&self) -> Pod {
        Pod::record("NameTok", vec![("sigils", self.sigils.to_pod()), ("path", self.path_.to_pod()), ("case", self.case.to_pod())])
    }
}

impl FromPod for NameTok {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(NameTok { sigils: FromPod::from_pod(field(p, "sigils")?)?, path_: FromPod::from_pod(field(p, "path")?)?, case: FromPod::from_pod(field(p, "case")?)? })
    }
}

/// `PathSegTok`:
///
/// ```prism
/// type PathSegTok = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum PathSegTok {
    PstNum(Nat),
    PstGen(Nat),
    PstKey(Array<Tok>),
}

impl Show for PathSegTok {
    fn show(&self, p: &mut Printer) {
        match self {
            PathSegTok::PstNum(a0) => p.choice("PstNum", &[a0]),
            PathSegTok::PstGen(a0) => p.choice("PstGen", &[a0]),
            PathSegTok::PstKey(a0) => p.choice("PstKey", &[a0]),
        }
    }
}

impl ToPod for PathSegTok {
    fn to_pod(&self) -> Pod {
        match self {
            PathSegTok::PstNum(a0) => Pod::Choice("PstNum".into(), vec![a0.to_pod()]),
            PathSegTok::PstGen(a0) => Pod::Choice("PstGen".into(), vec![a0.to_pod()]),
            PathSegTok::PstKey(a0) => Pod::Choice("PstKey".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for PathSegTok {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "PstNum" && a.len() == 1 => Ok(PathSegTok::PstNum(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PstGen" && a.len() == 1 => Ok(PathSegTok::PstGen(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PstKey" && a.len() == 1 => Ok(PathSegTok::PstKey(FromPod::from_pod(&a[0])?)),
            other => mismatch("a PathSegTok", other),
        }
    }
}

/// `RawItem`:
///
/// ```prism
/// type RawItem = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum RawItem {
    RiText(Text),
    RiPlaceholder(Array<Tok>, crate::syntax::Range),
    RiBlock(Array<Tok>, crate::syntax::Range),
    RiCall(NameTok, Array<AttrTok>, Option<Array<TPartTok>>, crate::syntax::Range),
}

impl Show for RawItem {
    fn show(&self, p: &mut Printer) {
        match self {
            RawItem::RiText(a0) => p.choice("RiText", &[a0]),
            RawItem::RiPlaceholder(a0, a1) => p.choice("RiPlaceholder", &[a0, a1]),
            RawItem::RiBlock(a0, a1) => p.choice("RiBlock", &[a0, a1]),
            RawItem::RiCall(a0, a1, a2, a3) => p.choice("RiCall", &[a0, a1, a2, a3]),
        }
    }
}

impl ToPod for RawItem {
    fn to_pod(&self) -> Pod {
        match self {
            RawItem::RiText(a0) => Pod::Choice("RiText".into(), vec![a0.to_pod()]),
            RawItem::RiPlaceholder(a0, a1) => Pod::Choice("RiPlaceholder".into(), vec![a0.to_pod(), a1.to_pod()]),
            RawItem::RiBlock(a0, a1) => Pod::Choice("RiBlock".into(), vec![a0.to_pod(), a1.to_pod()]),
            RawItem::RiCall(a0, a1, a2, a3) => Pod::Choice("RiCall".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
        }
    }
}

impl FromPod for RawItem {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "RiText" && a.len() == 1 => Ok(RawItem::RiText(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "RiPlaceholder" && a.len() == 2 => Ok(RawItem::RiPlaceholder(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "RiBlock" && a.len() == 2 => Ok(RawItem::RiBlock(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "RiCall" && a.len() == 4 => Ok(RawItem::RiCall(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?, FromPod::from_pod(&a[3])?)),
            other => mismatch("a RawItem", other),
        }
    }
}

/// `RawLine`:
///
/// ```prism
/// type RawLine = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct RawLine {
    pub items: Array<RawItem>,
    pub newline: bool,
    pub block: bool,
}

impl Show for RawLine {
    fn show(&self, p: &mut Printer) {
        p.record("RawLine", &[("items", &self.items), ("newline", &self.newline), ("block", &self.block)]);
    }
}

impl ToPod for RawLine {
    fn to_pod(&self) -> Pod {
        Pod::record("RawLine", vec![("items", self.items.to_pod()), ("newline", self.newline.to_pod()), ("block", self.block.to_pod())])
    }
}

impl FromPod for RawLine {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(RawLine { items: FromPod::from_pod(field(p, "items")?)?, newline: FromPod::from_pod(field(p, "newline")?)?, block: FromPod::from_pod(field(p, "block")?)? })
    }
}

/// `TPartTok`:
///
/// ```prism
/// type TPartTok = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum TPartTok {
    TptText(Text),
    TptPlaceholder(Array<Tok>, Option<Nat>, crate::syntax::Range),
    TptBlock(Array<Tok>, crate::syntax::Range),
    TptCall(NameTok, Array<AttrTok>, Option<Array<TPartTok>>, crate::syntax::Range),
}

impl Show for TPartTok {
    fn show(&self, p: &mut Printer) {
        match self {
            TPartTok::TptText(a0) => p.choice("TptText", &[a0]),
            TPartTok::TptPlaceholder(a0, a1, a2) => p.choice("TptPlaceholder", &[a0, a1, a2]),
            TPartTok::TptBlock(a0, a1) => p.choice("TptBlock", &[a0, a1]),
            TPartTok::TptCall(a0, a1, a2, a3) => p.choice("TptCall", &[a0, a1, a2, a3]),
        }
    }
}

impl ToPod for TPartTok {
    fn to_pod(&self) -> Pod {
        match self {
            TPartTok::TptText(a0) => Pod::Choice("TptText".into(), vec![a0.to_pod()]),
            TPartTok::TptPlaceholder(a0, a1, a2) => Pod::Choice("TptPlaceholder".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            TPartTok::TptBlock(a0, a1) => Pod::Choice("TptBlock".into(), vec![a0.to_pod(), a1.to_pod()]),
            TPartTok::TptCall(a0, a1, a2, a3) => Pod::Choice("TptCall".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
        }
    }
}

impl FromPod for TPartTok {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "TptText" && a.len() == 1 => Ok(TPartTok::TptText(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TptPlaceholder" && a.len() == 3 => Ok(TPartTok::TptPlaceholder(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "TptBlock" && a.len() == 2 => Ok(TPartTok::TptBlock(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "TptCall" && a.len() == 4 => Ok(TPartTok::TptCall(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?, FromPod::from_pod(&a[3])?)),
            other => mismatch("a TPartTok", other),
        }
    }
}

/// `TemplateTok`:
///
/// ```prism
/// type TemplateTok = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TemplateTok {
    pub keyword: Text,
    pub lang: Text,
    pub delims: Text,
    pub parts: Array<TPartTok>,
}

impl Show for TemplateTok {
    fn show(&self, p: &mut Printer) {
        p.record("TemplateTok", &[("keyword", &self.keyword), ("lang", &self.lang), ("delims", &self.delims), ("parts", &self.parts)]);
    }
}

impl ToPod for TemplateTok {
    fn to_pod(&self) -> Pod {
        Pod::record("TemplateTok", vec![("keyword", self.keyword.to_pod()), ("lang", self.lang.to_pod()), ("delims", self.delims.to_pod()), ("parts", self.parts.to_pod())])
    }
}

impl FromPod for TemplateTok {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TemplateTok { keyword: FromPod::from_pod(field(p, "keyword")?)?, lang: FromPod::from_pod(field(p, "lang")?)?, delims: FromPod::from_pod(field(p, "delims")?)?, parts: FromPod::from_pod(field(p, "parts")?)? })
    }
}

/// `TextSegTok`:
///
/// ```prism
/// type TextSegTok = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum TextSegTok {
    TsPlain(Text),
    TsPlaceholder(Array<Tok>, crate::syntax::Range),
}

impl Show for TextSegTok {
    fn show(&self, p: &mut Printer) {
        match self {
            TextSegTok::TsPlain(a0) => p.choice("TsPlain", &[a0]),
            TextSegTok::TsPlaceholder(a0, a1) => p.choice("TsPlaceholder", &[a0, a1]),
        }
    }
}

impl ToPod for TextSegTok {
    fn to_pod(&self) -> Pod {
        match self {
            TextSegTok::TsPlain(a0) => Pod::Choice("TsPlain".into(), vec![a0.to_pod()]),
            TextSegTok::TsPlaceholder(a0, a1) => Pod::Choice("TsPlaceholder".into(), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl FromPod for TextSegTok {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "TsPlain" && a.len() == 1 => Ok(TextSegTok::TsPlain(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TsPlaceholder" && a.len() == 2 => Ok(TextSegTok::TsPlaceholder(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            other => mismatch("a TextSegTok", other),
        }
    }
}

/// `Tok`:
///
/// ```prism
/// type Tok = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Tok {
    pub kind: TokKind,
    pub span: crate::syntax::Range,
    pub touches: bool,
    pub line_start: bool,
}

impl Show for Tok {
    fn show(&self, p: &mut Printer) {
        p.record("Tok", &[("kind", &self.kind), ("span", &self.span), ("touches", &self.touches), ("line_start", &self.line_start)]);
    }
}

impl ToPod for Tok {
    fn to_pod(&self) -> Pod {
        Pod::record("Tok", vec![("kind", self.kind.to_pod()), ("span", self.span.to_pod()), ("touches", self.touches.to_pod()), ("line_start", self.line_start.to_pod())])
    }
}

impl FromPod for Tok {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Tok { kind: FromPod::from_pod(field(p, "kind")?)?, span: FromPod::from_pod(field(p, "span")?)?, touches: FromPod::from_pod(field(p, "touches")?)?, line_start: FromPod::from_pod(field(p, "line_start")?)? })
    }
}

/// `TokKind`:
///
/// ```prism
/// type TokKind = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum TokKind {
    KName(NameTok),
    KFamily(Array<Text>),
    KTrait(Array<Text>),
    KKw(Text, Text),
    KFree(Text),
    KLensDot,
    KInt(Text, Text),
    KFloat(Text, Text),
    KDuration(Text, Text, Text),
    KChar(Text, Text),
    KText(Text, Array<TextSegTok>),
    KTemplate(TemplateTok),
    KOp(Text, bool),
    KSuffixed(Text, Array<Text>),
    KDot(bool),
    KDotDot,
    KComma,
    KColon,
    KSemi,
    KBackslash,
    KLambdaBar(bool),
    KBar,
    KLtLt,
    KGtGt,
    KOpen(Text, bool),
    KClose(Text),
    KAbsent,
    KNonEmpty,
    KPath(Array<PathSegTok>),
    KLayOpen,
    KLaySep,
    KLayClose,
    KEof,
}

impl Show for TokKind {
    fn show(&self, p: &mut Printer) {
        match self {
            TokKind::KName(a0) => p.choice("KName", &[a0]),
            TokKind::KFamily(a0) => p.choice("KFamily", &[a0]),
            TokKind::KTrait(a0) => p.choice("KTrait", &[a0]),
            TokKind::KKw(a0, a1) => p.choice("KKw", &[a0, a1]),
            TokKind::KFree(a0) => p.choice("KFree", &[a0]),
            TokKind::KLensDot => p.choice("KLensDot", &[]),
            TokKind::KInt(a0, a1) => p.choice("KInt", &[a0, a1]),
            TokKind::KFloat(a0, a1) => p.choice("KFloat", &[a0, a1]),
            TokKind::KDuration(a0, a1, a2) => p.choice("KDuration", &[a0, a1, a2]),
            TokKind::KChar(a0, a1) => p.choice("KChar", &[a0, a1]),
            TokKind::KText(a0, a1) => p.choice("KText", &[a0, a1]),
            TokKind::KTemplate(a0) => p.choice("KTemplate", &[a0]),
            TokKind::KOp(a0, a1) => p.choice("KOp", &[a0, a1]),
            TokKind::KSuffixed(a0, a1) => p.choice("KSuffixed", &[a0, a1]),
            TokKind::KDot(a0) => p.choice("KDot", &[a0]),
            TokKind::KDotDot => p.choice("KDotDot", &[]),
            TokKind::KComma => p.choice("KComma", &[]),
            TokKind::KColon => p.choice("KColon", &[]),
            TokKind::KSemi => p.choice("KSemi", &[]),
            TokKind::KBackslash => p.choice("KBackslash", &[]),
            TokKind::KLambdaBar(a0) => p.choice("KLambdaBar", &[a0]),
            TokKind::KBar => p.choice("KBar", &[]),
            TokKind::KLtLt => p.choice("KLtLt", &[]),
            TokKind::KGtGt => p.choice("KGtGt", &[]),
            TokKind::KOpen(a0, a1) => p.choice("KOpen", &[a0, a1]),
            TokKind::KClose(a0) => p.choice("KClose", &[a0]),
            TokKind::KAbsent => p.choice("KAbsent", &[]),
            TokKind::KNonEmpty => p.choice("KNonEmpty", &[]),
            TokKind::KPath(a0) => p.choice("KPath", &[a0]),
            TokKind::KLayOpen => p.choice("KLayOpen", &[]),
            TokKind::KLaySep => p.choice("KLaySep", &[]),
            TokKind::KLayClose => p.choice("KLayClose", &[]),
            TokKind::KEof => p.choice("KEof", &[]),
        }
    }
}

impl ToPod for TokKind {
    fn to_pod(&self) -> Pod {
        match self {
            TokKind::KName(a0) => Pod::Choice("KName".into(), vec![a0.to_pod()]),
            TokKind::KFamily(a0) => Pod::Choice("KFamily".into(), vec![a0.to_pod()]),
            TokKind::KTrait(a0) => Pod::Choice("KTrait".into(), vec![a0.to_pod()]),
            TokKind::KKw(a0, a1) => Pod::Choice("KKw".into(), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KFree(a0) => Pod::Choice("KFree".into(), vec![a0.to_pod()]),
            TokKind::KLensDot => Pod::Choice("KLensDot".into(), vec![]),
            TokKind::KInt(a0, a1) => Pod::Choice("KInt".into(), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KFloat(a0, a1) => Pod::Choice("KFloat".into(), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KDuration(a0, a1, a2) => Pod::Choice("KDuration".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            TokKind::KChar(a0, a1) => Pod::Choice("KChar".into(), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KText(a0, a1) => Pod::Choice("KText".into(), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KTemplate(a0) => Pod::Choice("KTemplate".into(), vec![a0.to_pod()]),
            TokKind::KOp(a0, a1) => Pod::Choice("KOp".into(), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KSuffixed(a0, a1) => Pod::Choice("KSuffixed".into(), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KDot(a0) => Pod::Choice("KDot".into(), vec![a0.to_pod()]),
            TokKind::KDotDot => Pod::Choice("KDotDot".into(), vec![]),
            TokKind::KComma => Pod::Choice("KComma".into(), vec![]),
            TokKind::KColon => Pod::Choice("KColon".into(), vec![]),
            TokKind::KSemi => Pod::Choice("KSemi".into(), vec![]),
            TokKind::KBackslash => Pod::Choice("KBackslash".into(), vec![]),
            TokKind::KLambdaBar(a0) => Pod::Choice("KLambdaBar".into(), vec![a0.to_pod()]),
            TokKind::KBar => Pod::Choice("KBar".into(), vec![]),
            TokKind::KLtLt => Pod::Choice("KLtLt".into(), vec![]),
            TokKind::KGtGt => Pod::Choice("KGtGt".into(), vec![]),
            TokKind::KOpen(a0, a1) => Pod::Choice("KOpen".into(), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KClose(a0) => Pod::Choice("KClose".into(), vec![a0.to_pod()]),
            TokKind::KAbsent => Pod::Choice("KAbsent".into(), vec![]),
            TokKind::KNonEmpty => Pod::Choice("KNonEmpty".into(), vec![]),
            TokKind::KPath(a0) => Pod::Choice("KPath".into(), vec![a0.to_pod()]),
            TokKind::KLayOpen => Pod::Choice("KLayOpen".into(), vec![]),
            TokKind::KLaySep => Pod::Choice("KLaySep".into(), vec![]),
            TokKind::KLayClose => Pod::Choice("KLayClose".into(), vec![]),
            TokKind::KEof => Pod::Choice("KEof".into(), vec![]),
        }
    }
}

impl FromPod for TokKind {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "KName" && a.len() == 1 => Ok(TokKind::KName(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "KFamily" && a.len() == 1 => Ok(TokKind::KFamily(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "KTrait" && a.len() == 1 => Ok(TokKind::KTrait(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "KKw" && a.len() == 2 => Ok(TokKind::KKw(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KFree" && a.len() == 1 => Ok(TokKind::KFree(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "KLensDot" && a.len() == 0 => Ok(TokKind::KLensDot),
            Pod::Choice(c, a) if &**c == "KInt" && a.len() == 2 => Ok(TokKind::KInt(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KFloat" && a.len() == 2 => Ok(TokKind::KFloat(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KDuration" && a.len() == 3 => Ok(TokKind::KDuration(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "KChar" && a.len() == 2 => Ok(TokKind::KChar(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KText" && a.len() == 2 => Ok(TokKind::KText(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KTemplate" && a.len() == 1 => Ok(TokKind::KTemplate(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "KOp" && a.len() == 2 => Ok(TokKind::KOp(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KSuffixed" && a.len() == 2 => Ok(TokKind::KSuffixed(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KDot" && a.len() == 1 => Ok(TokKind::KDot(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "KDotDot" && a.len() == 0 => Ok(TokKind::KDotDot),
            Pod::Choice(c, a) if &**c == "KComma" && a.len() == 0 => Ok(TokKind::KComma),
            Pod::Choice(c, a) if &**c == "KColon" && a.len() == 0 => Ok(TokKind::KColon),
            Pod::Choice(c, a) if &**c == "KSemi" && a.len() == 0 => Ok(TokKind::KSemi),
            Pod::Choice(c, a) if &**c == "KBackslash" && a.len() == 0 => Ok(TokKind::KBackslash),
            Pod::Choice(c, a) if &**c == "KLambdaBar" && a.len() == 1 => Ok(TokKind::KLambdaBar(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "KBar" && a.len() == 0 => Ok(TokKind::KBar),
            Pod::Choice(c, a) if &**c == "KLtLt" && a.len() == 0 => Ok(TokKind::KLtLt),
            Pod::Choice(c, a) if &**c == "KGtGt" && a.len() == 0 => Ok(TokKind::KGtGt),
            Pod::Choice(c, a) if &**c == "KOpen" && a.len() == 2 => Ok(TokKind::KOpen(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KClose" && a.len() == 1 => Ok(TokKind::KClose(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "KAbsent" && a.len() == 0 => Ok(TokKind::KAbsent),
            Pod::Choice(c, a) if &**c == "KNonEmpty" && a.len() == 0 => Ok(TokKind::KNonEmpty),
            Pod::Choice(c, a) if &**c == "KPath" && a.len() == 1 => Ok(TokKind::KPath(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "KLayOpen" && a.len() == 0 => Ok(TokKind::KLayOpen),
            Pod::Choice(c, a) if &**c == "KLaySep" && a.len() == 0 => Ok(TokKind::KLaySep),
            Pod::Choice(c, a) if &**c == "KLayClose" && a.len() == 0 => Ok(TokKind::KLayClose),
            Pod::Choice(c, a) if &**c == "KEof" && a.len() == 0 => Ok(TokKind::KEof),
            other => mismatch("a TokKind", other),
        }
    }
}

/// `TplHow`:
///
/// ```prism
/// type TplHow = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TplHow {
    pub close: Text,
    pub delims: Text,
    pub open: Text,
    pub is_raw: bool,
    pub first_continues: bool,
}

impl Show for TplHow {
    fn show(&self, p: &mut Printer) {
        p.record("TplHow", &[("close", &self.close), ("delims", &self.delims), ("open", &self.open), ("is_raw", &self.is_raw), ("first_continues", &self.first_continues)]);
    }
}

impl ToPod for TplHow {
    fn to_pod(&self) -> Pod {
        Pod::record("TplHow", vec![("close", self.close.to_pod()), ("delims", self.delims.to_pod()), ("open", self.open.to_pod()), ("is_raw", self.is_raw.to_pod()), ("first_continues", self.first_continues.to_pod())])
    }
}

impl FromPod for TplHow {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TplHow { close: FromPod::from_pod(field(p, "close")?)?, delims: FromPod::from_pod(field(p, "delims")?)?, open: FromPod::from_pod(field(p, "open")?)?, is_raw: FromPod::from_pod(field(p, "is_raw")?)?, first_continues: FromPod::from_pod(field(p, "first_continues")?)? })
    }
}

/// `TplRead`:
///
/// ```prism
/// type TplRead = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TplRead {
    pub l: Lex,
    pub lines: Array<RawLine>,
    pub cur: RawLine,
    pub closing_col: Option<Nat>,
    pub closed: bool,
    pub at_line_start: bool,
    pub going: bool,
}

impl Show for TplRead {
    fn show(&self, p: &mut Printer) {
        p.record("TplRead", &[("l", &self.l), ("lines", &self.lines), ("cur", &self.cur), ("closing_col", &self.closing_col), ("closed", &self.closed), ("at_line_start", &self.at_line_start), ("going", &self.going)]);
    }
}

impl ToPod for TplRead {
    fn to_pod(&self) -> Pod {
        Pod::record("TplRead", vec![("l", self.l.to_pod()), ("lines", self.lines.to_pod()), ("cur", self.cur.to_pod()), ("closing_col", self.closing_col.to_pod()), ("closed", self.closed.to_pod()), ("at_line_start", self.at_line_start.to_pod()), ("going", self.going.to_pod())])
    }
}

impl FromPod for TplRead {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TplRead { l: FromPod::from_pod(field(p, "l")?)?, lines: FromPod::from_pod(field(p, "lines")?)?, cur: FromPod::from_pod(field(p, "cur")?)?, closing_col: FromPod::from_pod(field(p, "closing_col")?)?, closed: FromPod::from_pod(field(p, "closed")?)?, at_line_start: FromPod::from_pod(field(p, "at_line_start")?)?, going: FromPod::from_pod(field(p, "going")?)? })
    }
}

/// ```prism
/// Fresh: fn Lex, Mode -> Lex
/// ```
pub fn fresh(l: &Lex, mode: &Mode) -> Lex {
    Lex { src: l.src.clone(), pos: l.pos.clone(), diags: l.diags.clone(), mode: mode.clone(), tokens: Array::new(), layout: Array::new(), frames: Array::new(), last_ws: true, lambda_open: false, pending_open: false, pending_span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) }, line_first: Nat::from(0u32), mark_line_start: false, first_line: true, test_pending: Text::lit(""), test_depth: None, check_depth: None, path_next: false }
}

/// ```prism
/// IsLayoutOrEof: fn TokKind -> Bool
/// ```
pub fn is_layout_or_eof(tok_kind0: &TokKind) -> bool {
    match tok_kind0 {
        TokKind::KLayOpen => true,
        TokKind::KLaySep => true,
        TokKind::KLayClose => true,
        TokKind::KEof => true,
        _ => false,
    }
}

/// ```prism
/// IsLayout: fn TokKind -> Bool
/// ```
pub fn is_layout(tok_kind0: &TokKind) -> bool {
    match tok_kind0 {
        TokKind::KLayOpen => true,
        TokKind::KLaySep => true,
        TokKind::KLayClose => true,
        _ => false,
    }
}

/// ```prism
/// EndsOperand: fn TokKind -> Bool
/// ```
pub fn ends_operand(tok_kind0: &TokKind) -> bool {
    match tok_kind0 {
        TokKind::KName(_) => true,
        TokKind::KFamily(_) => true,
        TokKind::KInt(_, _) => true,
        TokKind::KFloat(_, _) => true,
        TokKind::KDuration(_, _, _) => true,
        TokKind::KChar(_, _) => true,
        TokKind::KText(_, _) => true,
        TokKind::KTemplate(_) => true,
        TokKind::KClose(_) => true,
        TokKind::KGtGt => true,
        TokKind::KNonEmpty => true,
        TokKind::KAbsent => true,
        TokKind::KKw(w, _) => is_value_word(w),
        _ => false,
    }
}

/// ```prism
/// IsValueWord: fn Text -> Bool
/// ```
pub fn is_value_word(w: &Text) -> bool {
    ((w == &Text::lit("unit")) || (w == &Text::lit("nil"))) || is_bound_word(w)
}

/// ```prism
/// IsBoundWord: fn Text -> Bool
/// ```
pub fn is_bound_word(w: &Text) -> bool {
    (((w == &Text::lit("key")) || (w == &Text::lit("ix"))) || (w == &Text::lit("jx"))) || (w == &Text::lit("kx"))
}

/// ```prism
/// let keywordList
/// ```
pub fn keyword_list() -> Array<Text> {
    Array::from(vec![Text::lit("module"), Text::lit("emit"), Text::lit("use"), Text::lit("type"), Text::lit("record"), Text::lit("choice"), Text::lit("row"), Text::lit("tag"), Text::lit("of"), Text::lit("derive"), Text::lit("trait"), Text::lit("impl"), Text::lit("where"), Text::lit("any"), Text::lit("let"), Text::lit("fn"), Text::lit("test"), Text::lit("check"), Text::lit("widget"), Text::lit("rebuild"), Text::lit("for"), Text::lit("given"), Text::lit("monad"), Text::lit("update"), Text::lit("while"), Text::lit("match"), Text::lit("if"), Text::lit("else"), Text::lit("otherwise"), Text::lit("require"), Text::lit("forbid"), Text::lit("return"), Text::lit("ignore"), Text::lit("then"), Text::lit("on"), Text::lit("not"), Text::lit("and"), Text::lit("or"), Text::lit("mod"), Text::lit("as"), Text::lit("output"), Text::lit("inline_text"), Text::lit("raw"), Text::lit("unbounded"), Text::lit("unit"), Text::lit("nil"), Text::lit("key"), Text::lit("ix"), Text::lit("jx"), Text::lit("kx")])
}

/// ```prism
/// let keywordSet
/// ```
pub fn keyword_set() -> Map<Text, bool> {
    map(&each(&keyword_list(), &(|w: &Text| (w.clone(), true))))
}

/// ```prism
/// IsKeyword: fn Text -> Bool
/// ```
pub fn is_keyword(w: &Text) -> bool {
    &get(&keyword_set(), w) != &None
}

/// ```prism
/// let opTable
/// ```
pub fn op_table() -> Array<Text> {
    Array::from(vec![Text::lit("==>"), Text::lit("<-"), Text::lit("<="), Text::lit("<|"), Text::lit("->"), Text::lit("-="), Text::lit("-?"), Text::lit("+="), Text::lit("+?"), Text::lit("*="), Text::lit("*?"), Text::lit("/="), Text::lit("=="), Text::lit(">="), Text::lit("=>"), Text::lit("<"), Text::lit(">"), Text::lit("-"), Text::lit("+"), Text::lit("*"), Text::lit("/"), Text::lit("=")])
}

/// ```prism
/// TakesSuffix: fn Text -> Bool
/// ```
pub fn takes_suffix(op: &Text) -> bool {
    fold(&Array::from(vec![Text::lit("<="), Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit(">"), Text::lit(">="), Text::lit("+"), Text::lit("-"), Text::lit("*"), Text::lit("/"), Text::lit("+?"), Text::lit("-?"), Text::lit("*?")]), &false, &(|seen: &bool, o: &Text| *seen || (o == op)))
}

/// ```prism
/// CloseChar: fn Text -> Text
/// ```
pub fn close_char(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("(")) => Text::lit(")"),
        c1_0 if (c1_0 == &Text::lit("[")) => Text::lit("]"),
        _ => Text::lit("}"),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// OpenOf: fn Text -> Text
/// ```
pub fn open_of(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit(")")) => Text::lit("("),
        c1_0 if (c1_0 == &Text::lit("]")) => Text::lit("["),
        _ => Text::lit("{"),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// PrefixPosition: fn Lex -> Bool
/// ```
pub fn prefix_position(l: &Lex) -> bool {
    l.last_ws || no_operand_before(&last(&l.tokens))
}

/// ```prism
/// NoOperandBefore: fn ?Tok -> Bool
/// ```
pub fn no_operand_before(opt0: &Option<Tok>) -> bool {
    match opt0 {
        None => true,
        Some(t) => !ends_operand(&t.kind),
    }
}

/// ```prism
/// TestWordOf: fn TokKind -> Text
/// ```
pub fn test_word_of(tok_kind0: &TokKind) -> Text {
    match tok_kind0 {
        TokKind::KKw(c0_0_0, _) if (c0_0_0 == &Text::lit("test")) => Text::lit("test"),
        TokKind::KKw(c1_0_0, _) if (c1_0_0 == &Text::lit("check")) => Text::lit("check"),
        _ => Text::lit(""),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// AllLayout: fn [Tok] -> Bool
/// ```
pub fn all_layout(ts: &Array<Tok>) -> bool {
    fold(ts, &true, &(|ok: &bool, t: &Tok| *ok && is_layout(&t.kind)))
}

/// ```prism
/// PushTok: fn Lex, TokKind, Nat, Nat -> Lex
/// ```
pub fn push_tok(l: &Lex, kind: &TokKind, start: &Nat, end: &Nat) -> Lex {
    let mut this: Lex = l.clone();
    let layout = is_layout_or_eof(kind);
    let touches = (!this.last_ws && (&len(&this.tokens) > &Nat::from(0u32))) && !layout;
    let line_start = !layout && this.mark_line_start;
    if !layout {
        this.mark_line_start = false;
    }
    let word = test_word_of(kind);
    if (((&word != &Text::lit("")) && (&this.mode == &Mode::MFile)) && (&len(&this.layout) == &Nat::from(1u32))) && all_layout(&drop(&this.tokens, &this.line_first)) {
        this.test_pending = word.clone();
    }
    this.tokens = push(&this.tokens, &Tok { kind: kind.clone(), span: crate::syntax::Range { start: start.clone(), end: end.clone() }, touches, line_start });
    this.last_ws = false;
    this
}

/// ```prism
/// LayoutOn: fn Mode -> Bool
/// ```
pub fn layout_on(mode0: &Mode) -> bool {
    match mode0 {
        Mode::MFile => true,
        Mode::MBrace(_) => true,
        _ => false,
    }
}

/// ```prism
/// LayoutActive: fn Lex -> Bool
/// ```
pub fn layout_active(l: &Lex) -> bool {
    layout_on(&l.mode) && (&len(&l.frames) == &Nat::from(0u32))
}

/// ```prism
/// FatArrowOn: fn Lex -> Bool
/// ```
pub fn fat_arrow_on(l: &Lex) -> bool {
    (&l.test_depth != &None) || (&l.check_depth != &None)
}

/// ```prism
/// Dec: fn Nat -> Nat
/// ```
pub fn dec(n: &Nat) -> Nat {
    or(&n.checked_sub(&Nat::from(1u32)), &Nat::from(0u32))
}

/// ```prism
/// ?Last: fn [a] -> ?a
/// ```
pub fn last<A: Clone + 'static>(xs: &Array<A>) -> Option<A> {
    index(xs, &dec(&len(xs)))
}

/// ```prism
/// Pop: fn [a] -> [a]
/// ```
pub fn pop<A: Clone + 'static>(xs: &Array<A>) -> Array<A> {
    take(xs, &dec(&len(xs)))
}

/// ```prism
/// Join: fn [Text], Text -> Text
/// ```
pub fn join(xs: &Array<Text>, sep: &Text) -> Text {
    match index(xs, &Nat::from(0u32)) {
        Some(first_) => concat(&fold(&drop(xs, &Nat::from(1u32)), &Array::from(vec![first_.clone()]), &(|acc: &Array<Text>, x: &Text| push(&push(acc, sep), x)))),
        None => Text::lit(""),
    }
}

/// ```prism
/// CharAt: fn Cursor -> Text
/// ```
pub fn char_at(c: &Cursor) -> Text {
    match step(&front(&after(c))) {
        Some((_, one)) => before(&one),
        None => Text::lit(""),
    }
}

/// ```prism
/// Head: fn Text -> Text
/// ```
pub fn head(t: &Text) -> Text {
    char_at(&front(t))
}

/// ```prism
/// AfterFirst: fn Text -> Text
/// ```
pub fn after_first(t: &Text) -> Text {
    match step(&front(t)) {
        Some((_, c)) => after(&c),
        None => Text::lit(""),
    }
}

/// ```prism
/// LastChar: fn Text -> Text
/// ```
pub fn last_char(t: &Text) -> Text {
    match step_back(&back(t)) {
        Some((_, c)) => after(&c),
        None => Text::lit(""),
    }
}

/// ```prism
/// BeforeLast: fn Text -> Text
/// ```
pub fn before_last(t: &Text) -> Text {
    match step_back(&back(t)) {
        Some((_, c)) => before(&c),
        None => Text::lit(""),
    }
}

/// ```prism
/// Between: fn Text, Nat, Nat -> Text
/// ```
pub fn between(t: &Text, a: &Nat, b: &Nat) -> Text {
    match cursor_at(t, b) {
        Some(cb) => match cursor_at(&before(&cb), a) {
            Some(ca) => after(&ca),
            None => Text::lit(""),
        },
        None => Text::lit(""),
    }
}

/// ```prism
/// ?AfterPrefix: fn Text, Text -> ?Text
/// ```
pub fn after_prefix(t: &Text, p_: &Text) -> Option<Text> {
    match cursor_at(t, &len_text(p_)) {
        Some(c) => if &before(&c) == p_ { Some(after(&c)) } else { None },
        None => None,
    }
}

/// ```prism
/// HasPrefix: fn Text, Text -> Bool
/// ```
pub fn has_prefix(t: &Text, p_: &Text) -> bool {
    &after_prefix(t, p_) != &None
}

/// ```prism
/// DropPrefix: fn Text, Text -> Text
/// ```
pub fn drop_prefix(t: &Text, p_: &Text) -> Text {
    or(&after_prefix(t, p_), t)
}

/// ```prism
/// ?BeforeSuffix: fn Text, Text -> ?Text
/// ```
pub fn before_suffix(t: &Text, s: &Text) -> Option<Text> {
    match (&len_text(t)).checked_sub(&len_text(s)) {
        Some(n) => match cursor_at(t, &n) {
            Some(c) => if &after(&c) == s { Some(before(&c)) } else { None },
            None => None,
        },
        None => None,
    }
}

/// ```prism
/// HasSuffix: fn Text, Text -> Bool
/// ```
pub fn has_suffix(t: &Text, s: &Text) -> bool {
    &before_suffix(t, s) != &None
}

/// ```prism
/// FoldChars: fn Text, b, (fn b, Text -> b) -> b
/// ```
pub fn fold_chars<B: Clone + 'static>(t: &Text, z: &B, f_fn: &Rc<dyn Fn((B, Text)) -> Rc<dyn prism_rtl::Job<B>>>) -> B {
    let mut this: B = z.clone();
    let mut c: Cursor = front(t);
    while let Some((_, next)) = step(&c) {
        this = run_to_end(f_fn((this.clone(), char_at(&c))));
        c = next.clone();
    }
    this
}

/// The step machine of `FoldChars`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FoldChars: fn Text, b, (fn b, Text -> b) -> b
/// ```
pub struct FoldChars<B> {
    pub t: Text,
    pub z: B,
    pub f_fn: Rc<dyn Fn((B, Text)) -> Rc<dyn prism_rtl::Job<B>>>,
}

impl<B: Clone + 'static> prism_rtl::Job<B> for FoldChars<B> {
    fn cycle(&self) -> prism_rtl::Turn<B> {
        let t = &self.t;
        let z = &self.z;
        let f_fn = &self.f_fn;
        prism_rtl::Turn::Finished({
            let mut this: B = z.clone();
            let mut c: Cursor = front(t);
            while let Some((_, next)) = step(&c) {
                this = run_to_end(f_fn((this.clone(), char_at(&c))));
                c = next.clone();
            }
            this
        })
    }
}

/// `Start FoldChars, x`: what the function value is when passed to `@Run`.
pub fn start_fold_chars<B: Clone + 'static>(t: Text, z: B, f_fn: Rc<dyn Fn((B, Text)) -> Rc<dyn prism_rtl::Job<B>>>) -> Rc<dyn prism_rtl::Job<B>> {
    Rc::new(FoldChars { t, z, f_fn })
}

/// ```prism
/// MapChars: fn Text, (fn Text -> Text) -> Text
/// ```
pub fn map_chars(t: &Text, f_fn: &Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>) -> Text {
    concat(&fold_chars(t, &Array::new(), &{
        let f_fn = f_fn.clone();
        Rc::new(move |(p0, p1): (Array<Text>, Text)| {
            let f_fn = f_fn.clone();
            entered(once_job(move || {
                let acc = p0;
                let c = p1;
                call_value((&f_fn)(c.clone()), move |f_12505: Text| prism_rtl::Turn::Finished(push(&acc, &f_12505)))
            }))
        }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// ```prism
/// CountChars: fn Text -> Nat
/// ```
pub fn count_chars(t: &Text) -> Nat {
    fold_chars(t, &Nat::from(0u32), &(Rc::new(move |(p0, p1): (Nat, Text)| once_job(move || {
        let n = p0;
        let _ = p1;
        prism_rtl::Turn::Finished(&n + &Nat::from(1u32))
    })) as Rc<dyn Fn((Nat, Text)) -> Rc<dyn prism_rtl::Job<Nat>>>))
}

/// ```prism
/// ColumnOf: fn Text, Nat, Nat -> Nat
/// ```
pub fn column_of(text: &Text, from: &Nat, offset: &Nat) -> Nat {
    count_chars(&between(text, from, offset))
}

/// ```prism
/// AllChars: fn Text, (fn Text -> Bool) -> Bool
/// ```
pub fn all_chars(t: &Text, p__fn: &Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>) -> bool {
    fold_chars(t, &true, &{
        let p__fn = p__fn.clone();
        Rc::new(move |(p0, p1): (bool, Text)| {
            let p__fn = p__fn.clone();
            entered(once_job(move || {
                let ok = p0;
                let c = p1;
                prism_rtl::Turn::Finished(ok && run_to_end((&p__fn)(c.clone())))
            }))
        }) as Rc<dyn Fn((bool, Text)) -> Rc<dyn prism_rtl::Job<bool>>>
    })
}

/// ```prism
/// TrimLeading: fn Text, Text -> Text
/// ```
pub fn trim_leading(t: &Text, set: &Text) -> Text {
    let c = {
        let mut this: Cursor = front(t);
        while let Some((_, next)) = step(&this) {
            if !contains(set, &char_at(&this)) {
                break;
            }
            this = next.clone();
        }
        this
    };
    after(&c)
}

/// ```prism
/// TrimTrailing: fn Text, Text -> Text
/// ```
pub fn trim_trailing(t: &Text, set: &Text) -> Text {
    let c = {
        let mut this: Cursor = back(t);
        let mut fuel: Nat = len_text(t);
        while let Some(left) = (&fuel).checked_sub(&Nat::from(1u32)) {
            fuel = left.clone();
            match &step_back(&this) {
                Some((_, prev)) if contains(set, &char_at(prev)) => {
                    this = prev.clone();
                    ()
                },
                _ => {
                    fuel = Nat::from(0u32);
                    ()
                },
                _ => unreachable!("no arm matched"),
            };
        }
        this
    };
    before(&c)
}

/// ```prism
/// TrimStart: fn Text -> Text
/// ```
pub fn trim_start(t: &Text) -> Text {
    trim_leading(t, &Text::lit(" \r"))
}

/// ```prism
/// TrimEnd: fn Text -> Text
/// ```
pub fn trim_end(t: &Text) -> Text {
    trim_trailing(t, &Text::lit(" \r"))
}

/// ```prism
/// Trim: fn Text -> Text
/// ```
pub fn trim(t: &Text) -> Text {
    trim_end(&trim_start(t))
}

/// ```prism
/// LeadingIn: fn Text, Text -> Nat
/// ```
pub fn leading_in(t: &Text, set: &Text) -> Nat {
    or(&(&len_text(t)).checked_sub(&len_text(&trim_leading(t, set))), &Nat::from(0u32))
}

/// ```prism
/// Contains: fn Text, Text -> Bool
/// ```
pub fn contains(set: &Text, c: &Text) -> bool {
    (c != &Text::lit("")) && (&len(&split(set, c)) > &Nat::from(1u32))
}

/// ```prism
/// IsDigit: fn Text -> Bool
/// ```
pub fn is_digit(c: &Text) -> bool {
    (&Text::lit("0") <= c) && (c <= &Text::lit("9"))
}

/// ```prism
/// IsUpper: fn Text -> Bool
/// ```
pub fn is_upper(c: &Text) -> bool {
    (&Text::lit("A") <= c) && (c <= &Text::lit("Z"))
}

/// ```prism
/// IsLower: fn Text -> Bool
/// ```
pub fn is_lower(c: &Text) -> bool {
    (&Text::lit("a") <= c) && (c <= &Text::lit("z"))
}

/// ```prism
/// IsIdentStart: fn Text -> Bool
/// ```
pub fn is_ident_start(c: &Text) -> bool {
    (is_lower(c) || is_upper(c)) || (c == &Text::lit("_"))
}

/// ```prism
/// IsIdentChar: fn Text -> Bool
/// ```
pub fn is_ident_char(c: &Text) -> bool {
    is_ident_start(c) || is_digit(c)
}

/// ```prism
/// IsHexDigit: fn Text -> Bool
/// ```
pub fn is_hex_digit(c: &Text) -> bool {
    (is_digit(c) || ((&Text::lit("a") <= c) && (c <= &Text::lit("f")))) || ((&Text::lit("A") <= c) && (c <= &Text::lit("F")))
}

/// ```prism
/// IsNonAscii: fn Text -> Bool
/// ```
pub fn is_non_ascii(c: &Text) -> bool {
    c > &Text::lit("")
}

/// ```prism
/// IsSigilChar: fn Text -> Bool
/// ```
pub fn is_sigil_char(c: &Text) -> bool {
    contains(&Text::lit("$!@?~&"), c)
}

/// ```prism
/// IsSpaceChar: fn Text -> Bool
/// ```
pub fn is_space_char(c: &Text) -> bool {
    (((c == &Text::lit(" ")) || (c == &Text::lit("\n"))) || (c == &Text::lit("\r"))) || (c == &Text::lit("\t"))
}

/// ```prism
/// IsReservedCtor: fn Text -> Bool
/// ```
pub fn is_reserved_ctor(w: &Text) -> bool {
    (w == &Text::lit("templatetext")) || (w == &Text::lit("templateplaceholder"))
}

/// ```prism
/// let asciiText
/// ```
pub fn ascii_text() -> Text {
    Text::lit("\0\t\n\r !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")
}

/// ```prism
/// let hexDigits
/// ```
pub fn hex_digits_value() -> Text {
    Text::lit("0123456789abcdef")
}

/// ```prism
/// CharAtByte: fn Text, Nat -> Text
/// ```
pub fn char_at_byte(t: &Text, n: &Nat) -> Text {
    match cursor_at(t, n) {
        Some(c) => char_at(&c),
        None => Text::lit(""),
    }
}

/// ```prism
/// HexValue: fn Text -> Nat
/// ```
pub fn hex_value(c: &Text) -> Nat {
    let l = lower(c);
    if &l == &Text::lit("") {
        Nat::from(16u32)
    } else {
        len_text(&or(&index(&split(&hex_digits_value(), &l), &Nat::from(0u32)), &hex_digits_value()))
    }
}

/// ```prism
/// ?ParseHex: fn Text -> ?Nat
/// ```
pub fn parse_hex(t: &Text) -> Option<Nat> {
    'g16586: {
        if !((t != &Text::lit("")) && all_chars(t, &{
            let f = Rc::new(is_hex_digit);
            Rc::new(move |a0: Text| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
        })) {
            break 'g16586 None;
        }
        Some(fold_chars(t, &Nat::from(0u32), &(Rc::new(move |(p0, p1): (Nat, Text)| once_job(move || {
            let n = p0;
            let c = p1;
            prism_rtl::Turn::Finished(&(&n * &Nat::from(16u32)) + &hex_value(&c))
        })) as Rc<dyn Fn((Nat, Text)) -> Rc<dyn prism_rtl::Job<Nat>>>)))
    }
}

/// ```prism
/// ?AsciiChar: fn Nat -> ?Text
/// ```
pub fn ascii_char(n: &Nat) -> Option<Text> {
    if n < &Nat::from(128u32) { Some(char_at_byte(&ascii_text(), n)) } else { None }
}

/// ```prism
/// Rest: fn Lex -> Text
/// ```
pub fn rest(l: &Lex) -> Text {
    match cursor_at(&l.src, &l.pos) {
        Some(c) => after(&c),
        None => Text::lit(""),
    }
}

/// ```prism
/// Peek: fn Lex -> Text
/// ```
pub fn peek(l: &Lex) -> Text {
    char_at_byte(&l.src, &l.pos)
}

/// ```prism
/// PeekAt: fn Lex, Nat -> Text
/// ```
pub fn peek_at(l: &Lex, n: &Nat) -> Text {
    let rest_ = {
        let mut this: Text = rest(l);
        let mut k: Nat = n.clone();
        while let Some(left) = (&k).checked_sub(&Nat::from(1u32)) {
            k = left.clone();
            this = after_first(&this);
        }
        this
    };
    head(&rest_)
}

/// ```prism
/// StartsWith: fn Lex, Text -> Bool
/// ```
pub fn starts_with(l: &Lex, s: &Text) -> bool {
    has_prefix(&rest(l), s)
}

/// ```prism
/// Slice: fn Lex, Nat, Nat -> Text
/// ```
pub fn slice(l: &Lex, a: &Nat, b: &Nat) -> Text {
    between(&l.src, a, b)
}

/// ```prism
/// Bump: fn Lex -> Lex
/// ```
pub fn bump(l: &Lex) -> Lex {
    let mut this: Lex = l.clone();
    this.pos = &this.pos + &len_text(&peek(&this));
    this
}

/// ```prism
/// Forward: fn Lex, Nat -> Lex
/// ```
pub fn forward(l: &Lex, n: &Nat) -> Lex {
    let mut this: Lex = l.clone();
    let mut k: Nat = n.clone();
    while let Some(left) = (&k).checked_sub(&Nat::from(1u32)) {
        k = left.clone();
        this.pos = &this.pos + &len_text(&peek(&this));
    }
    this
}

/// ```prism
/// NextIsSpace: fn Lex, Nat -> Bool
/// ```
pub fn next_is_space(l: &Lex, n: &Nat) -> bool {
    let c = peek_at(l, n);
    (&c == &Text::lit("")) || is_space_char(&c)
}

/// ```prism
/// LineEnd: fn Lex -> Nat
/// ```
pub fn line_end(l: &Lex) -> Nat {
    match cursor_at(&l.src, &l.pos) {
        Some(c) => {
            let end = {
                let mut this: Cursor = c.clone();
                while let Some((ch, next)) = step(&this) {
                    if !(&ch != &'\n') {
                        break;
                    }
                    this = next.clone();
                }
                this
            };
            at(&end)
        },
        None => l.pos.clone(),
    }
}

/// ```prism
/// RestOfLine: unbounded fn Lex -> Text
/// ```
pub fn rest_of_line(l: &Lex) -> Text {
    slice(l, &l.pos, &line_end(l))
}

/// The step machine of `RestOfLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RestOfLine: unbounded fn Lex -> Text
/// ```
pub struct RestOfLine {
    pub l: Lex,
}

impl prism_rtl::Job<Text> for RestOfLine {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let l = &self.l;
        prism_rtl::Turn::Finished(slice(l, &l.pos, &line_end(l)))
    }
}

/// `Start RestOfLine, x`: what the function value is when passed to `@Run`.
pub fn start_rest_of_line(l: Lex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RestOfLine { l })
}

/// ```prism
/// LexErr: fn Lex, Nat, Nat, Text -> Lex
/// ```
pub fn lex_err(l: &Lex, start: &Nat, end: &Nat, message: &Text) -> Lex {
    let mut this: Lex = l.clone();
    this.diags = push(&this.diags, &lex_diag(&crate::syntax::Range { start: start.clone(), end: max(end, start) }, message));
    this
}

/// ```prism
/// LexDiag: fn Range, Text -> Diag
/// ```
pub fn lex_diag(span: &crate::syntax::Range, message: &Text) -> crate::syntax::Diag {
    crate::syntax::Diag { stage: Text::lit("lex"), span: span.clone(), message: message.clone(), feature: None }
}

/// ```prism
/// LexFile: unbounded fn Text -> Lexed
/// ```
pub fn lex_file(src: &Text) -> Lexed {
    let start = Lex { src: src.clone(), pos: Nat::from(0u32), diags: Array::new(), mode: Mode::MFile, tokens: Array::new(), layout: Array::new(), frames: Array::new(), last_ws: true, lambda_open: false, pending_open: false, pending_span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) }, line_first: Nat::from(0u32), mark_line_start: false, first_line: true, test_pending: Text::lit(""), test_depth: None, check_depth: None, path_next: false };
    let skipped = skip_blank_and_comment_lines(&start);
    let opened = (&peek(&skipped) == &Text::lit("<")) && (&template_tag_ahead(&skipped) != &Text::lit(""));
    let (head_, l) = if opened { template_head(&skipped) } else { (Array::new(), start.clone()) };
    let body = lex_stream(&fresh(&l, &Mode::MFile));
    Lexed { tokens: append(&head_, &body.tokens), diags: body.diags.clone() }
}

/// The step machine of `LexFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexFile: unbounded fn Text -> Lexed
/// ```
pub struct LexFile {
    pub src: Text,
}

impl prism_rtl::Job<Lexed> for LexFile {
    fn cycle(&self) -> prism_rtl::Turn<Lexed> {
        let src = &self.src;
        let start = Lex { src: src.clone(), pos: Nat::from(0u32), diags: Array::new(), mode: Mode::MFile, tokens: Array::new(), layout: Array::new(), frames: Array::new(), last_ws: true, lambda_open: false, pending_open: false, pending_span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) }, line_first: Nat::from(0u32), mark_line_start: false, first_line: true, test_pending: Text::lit(""), test_depth: None, check_depth: None, path_next: false };
        call_then(start_skip_blank_and_comment_lines(start.clone()), move |skip_blank_and_comment_lines_19767: Lex| {
            let skipped = skip_blank_and_comment_lines_19767;
            let opened = (&peek(&skipped) == &Text::lit("<")) && (&template_tag_ahead(&skipped) != &Text::lit(""));
            let (head_, l) = if opened { template_head(&skipped) } else { (Array::new(), start.clone()) };
            call_then(start_lex_stream(fresh(&l, &Mode::MFile)), move |lex_stream_19965: Lex| {
                let body = lex_stream_19965;
                prism_rtl::Turn::Finished(Lexed { tokens: append(&head_, &body.tokens), diags: body.diags.clone() })
            })
        })
    }
}

/// `Start LexFile, x`: what the function value is when passed to `@Run`.
pub fn start_lex_file(src: Text) -> Rc<dyn prism_rtl::Job<Lexed>> {
    Rc::new(LexFile { src })
}

/// ```prism
/// TemplateHead: unbounded fn Lex -> (([Tok], Lex))
/// ```
pub fn template_head(l0: &Lex) -> (Array<Tok>, Lex) {
    let (kind, l) = lex_template(l0, &Text::lit("File"), &l0.pos);
    let tok = Tok { kind: kind.clone(), span: crate::syntax::Range { start: l0.pos.clone(), end: l.pos.clone() }, touches: false, line_start: false };
    (Array::from(vec![tok.clone()]), l.clone())
}

/// The step machine of `TemplateHead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateHead: unbounded fn Lex -> (([Tok], Lex))
/// ```
pub struct TemplateHead {
    pub l0: Lex,
}

impl prism_rtl::Job<(Array<Tok>, Lex)> for TemplateHead {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Tok>, Lex)> {
        let l0 = &self.l0;
        let l0 = l0.clone();
        call_then(start_lex_template(l0.clone(), Text::lit("File"), l0.pos.clone()), move |lex_template_20217: (TokKind, Lex)| {
            let (kind, l) = lex_template_20217;
            let tok = Tok { kind: kind.clone(), span: crate::syntax::Range { start: l0.pos.clone(), end: l.pos.clone() }, touches: false, line_start: false };
            prism_rtl::Turn::Finished((Array::from(vec![tok.clone()]), l.clone()))
        })
    }
}

/// `Start TemplateHead, x`: what the function value is when passed to `@Run`.
pub fn start_template_head(l0: Lex) -> Rc<dyn prism_rtl::Job<(Array<Tok>, Lex)>> {
    Rc::new(TemplateHead { l0 })
}

/// ```prism
/// SkipBlankAndCommentLines: unbounded fn Lex -> Lex
/// ```
pub fn skip_blank_and_comment_lines(l: &Lex) -> Lex {
    let mut this: Lex = l.clone();
    let mut going: bool = true;
    while going {
        let line = rest_of_line(&this);
        let t = trim_start(&line);
        if ((&t == &Text::lit("")) || (&head(&t) == &Text::lit("#"))) && (&(&this.pos + &len_text(&line)) < &len_text(&this.src)) {
            this.pos = &this.pos + &(&len_text(&line) + &Nat::from(1u32));
        } else {
            going = false;
        }
    }
    this
}

/// The step machine of `SkipBlankAndCommentLines`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SkipBlankAndCommentLines: unbounded fn Lex -> Lex
/// ```
pub struct SkipBlankAndCommentLines {
    pub l: Lex,
}

impl prism_rtl::Job<Lex> for SkipBlankAndCommentLines {
    fn cycle(&self) -> prism_rtl::Turn<Lex> {
        let l = &self.l;
        let mut this: Lex = l.clone();
        let mut going: bool = true;
        call_then(loop_job((this, going), move |(mut this, mut going): (Lex, bool)| if going {
            {
                let line = rest_of_line(&this);
                let t = trim_start(&line);
                if ((&t == &Text::lit("")) || (&head(&t) == &Text::lit("#"))) && (&(&this.pos + &len_text(&line)) < &len_text(&this.src)) {
                    this.pos = &this.pos + &(&len_text(&line) + &Nat::from(1u32));
                } else {
                    going = false;
                }
                Ok((this, going))
            }
        } else {
            Err((this, going))
        }), move |(mut this, mut going): (Lex, bool)| prism_rtl::Turn::Finished(this))
    }
}

/// `Start SkipBlankAndCommentLines, x`: what the function value is when passed to `@Run`.
pub fn start_skip_blank_and_comment_lines(l: Lex) -> Rc<dyn prism_rtl::Job<Lex>> {
    Rc::new(SkipBlankAndCommentLines { l })
}

/// ```prism
/// Nested: unbounded fn Lex, Mode -> (([Tok], Lex))
/// ```
pub fn nested(l: &Lex, mode: &Mode) -> (Array<Tok>, Lex) {
    let inner = lex_stream(&fresh(l, mode));
    let back_ = {
        let mut this: Lex = l.clone();
        this.pos = inner.pos.clone();
        this.diags = inner.diags.clone();
        this
    };
    (inner.tokens.clone(), back_.clone())
}

/// The step machine of `Nested`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Nested: unbounded fn Lex, Mode -> (([Tok], Lex))
/// ```
pub struct Nested {
    pub l: Lex,
    pub mode: Mode,
}

impl prism_rtl::Job<(Array<Tok>, Lex)> for Nested {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Tok>, Lex)> {
        let l = &self.l;
        let mode = &self.mode;
        let l = l.clone();
        let mode = mode.clone();
        call_then(start_lex_stream(fresh(&l, &mode)), move |lex_stream_20940: Lex| {
            let inner = lex_stream_20940;
            let back_ = {
                let mut this: Lex = l.clone();
                this.pos = inner.pos.clone();
                this.diags = inner.diags.clone();
                this
            };
            prism_rtl::Turn::Finished((inner.tokens.clone(), back_.clone()))
        })
    }
}

/// `Start Nested, x`: what the function value is when passed to `@Run`.
pub fn start_nested(l: Lex, mode: Mode) -> Rc<dyn prism_rtl::Job<(Array<Tok>, Lex)>> {
    Rc::new(Nested { l, mode })
}

/// ```prism
/// LexStream: unbounded fn Lex -> Lex
/// ```
pub fn lex_stream(l0: &Lex) -> Lex {
    let mut this: Lex = l0.clone();
    let mut at_line_start: bool = layout_on(&this.mode);
    let mut done: bool = false;
    while !done {
        let mut go: bool = true;
        if at_line_start && layout_active(&this) {
            at_line_start = false;
            let (l, verdict) = begin_line(&this);
            this = l.clone();
            if &verdict == &Text::lit("skip") {
                at_line_start = true;
                go = false;
            }
            if &verdict == &Text::lit("end") {
                done = true;
                go = false;
            }
        }
        if go {
            let c = peek(&this);
            match &c {
                u21768_0 if (u21768_0 == &Text::lit("")) => {
                    this = unclosed_stream(&this);
                    done = true;
                    ()
                },
                u21768_1 if (u21768_1 == &Text::lit("\n")) => {
                    this.pos = &this.pos + &Nat::from(1u32);
                    this.last_ws = true;
                    if this.lambda_open {
                        this = lex_err(&this, &dec(&this.pos), &this.pos, &Text::lit("a lambda's parameter list closes with `|` on its own line"));
                        this.lambda_open = false;
                    }
                    if layout_active(&this) {
                        this = end_line(&this);
                        at_line_start = true;
                    }
                    ()
                },
                u21768_2 if (u21768_2 == &Text::lit(" ")) => {
                    this.pos = &this.pos + &Nat::from(1u32);
                    this.last_ws = true;
                    ()
                },
                u21768_3 if (u21768_3 == &Text::lit("\r")) => {
                    this.pos = &this.pos + &Nat::from(1u32);
                    this.last_ws = true;
                    ()
                },
                u21768_4 if (u21768_4 == &Text::lit("\t")) => {
                    this.pos = &this.pos + &Nat::from(1u32);
                    this.last_ws = true;
                    ()
                },
                u21768_5 if (u21768_5 == &Text::lit("#")) => {
                    this.pos = line_end(&this);
                    this.last_ws = true;
                    ()
                },
                _ => {
                    let (ends, l) = stream_ends_here(&this);
                    this = l.clone();
                    if ends {
                        done = true;
                    } else {
                        this = lex_token(&this);
                    }
                    ()
                },
                _ => unreachable!("no arm matched"),
            };
        }
    }
    if layout_on(&this.mode) {
        while &len(&this.layout) > &Nat::from(1u32) {
            this.layout = pop(&this.layout);
            this = push_tok(&this, &TokKind::KLayClose, &this.pos, &this.pos);
        }
    }
    if &this.mode == &Mode::MFile {
        this = push_tok(&this, &TokKind::KEof, &this.pos, &this.pos);
    }
    this
}

/// The step machine of `LexStream`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexStream: unbounded fn Lex -> Lex
/// ```
pub struct LexStream {
    pub l0: Lex,
}

impl prism_rtl::Job<Lex> for LexStream {
    fn cycle(&self) -> prism_rtl::Turn<Lex> {
        let l0 = &self.l0;
        let mut this: Lex = l0.clone();
        let mut at_line_start: bool = layout_on(&this.mode);
        let mut done: bool = false;
        call_then(loop_job((this, at_line_start, done), move |(mut this, mut at_line_start, mut done): (Lex, bool, bool)| if !done {
            {
                let mut go: bool = true;
                if at_line_start && layout_active(&this) {
                    at_line_start = false;
                    let (l, verdict) = begin_line(&this);
                    this = l.clone();
                    if &verdict == &Text::lit("skip") {
                        at_line_start = true;
                        go = false;
                    }
                    if &verdict == &Text::lit("end") {
                        done = true;
                        go = false;
                    }
                }
                if go {
                    let c = peek(&this);
                    match &c {
                        u21768_0 if (u21768_0 == &Text::lit("")) => {
                            this = unclosed_stream(&this);
                            done = true;
                            ()
                        },
                        u21768_1 if (u21768_1 == &Text::lit("\n")) => {
                            this.pos = &this.pos + &Nat::from(1u32);
                            this.last_ws = true;
                            if this.lambda_open {
                                this = lex_err(&this, &dec(&this.pos), &this.pos, &Text::lit("a lambda's parameter list closes with `|` on its own line"));
                                this.lambda_open = false;
                            }
                            if layout_active(&this) {
                                this = end_line(&this);
                                at_line_start = true;
                            }
                            ()
                        },
                        u21768_2 if (u21768_2 == &Text::lit(" ")) => {
                            this.pos = &this.pos + &Nat::from(1u32);
                            this.last_ws = true;
                            ()
                        },
                        u21768_3 if (u21768_3 == &Text::lit("\r")) => {
                            this.pos = &this.pos + &Nat::from(1u32);
                            this.last_ws = true;
                            ()
                        },
                        u21768_4 if (u21768_4 == &Text::lit("\t")) => {
                            this.pos = &this.pos + &Nat::from(1u32);
                            this.last_ws = true;
                            ()
                        },
                        u21768_5 if (u21768_5 == &Text::lit("#")) => {
                            this.pos = line_end(&this);
                            this.last_ws = true;
                            ()
                        },
                        _ => {
                            let (ends, l) = stream_ends_here(&this);
                            this = l.clone();
                            if ends {
                                done = true;
                            } else {
                                this = lex_token(&this);
                            }
                            ()
                        },
                        _ => unreachable!("no arm matched"),
                    };
                }
                Ok((this, at_line_start, done))
            }
        } else {
            Err((this, at_line_start, done))
        }), move |(mut this, mut at_line_start, mut done): (Lex, bool, bool)| {
            let k_if23158 = move |(mut this, mut at_line_start, mut done): (Lex, bool, bool)| {
                if &this.mode == &Mode::MFile {
                    this = push_tok(&this, &TokKind::KEof, &this.pos, &this.pos);
                }
                prism_rtl::Turn::Finished(this)
            };
            if layout_on(&this.mode) {
                call_then(loop_job((this, at_line_start, done), move |(mut this, mut at_line_start, mut done): (Lex, bool, bool)| if &len(&this.layout) > &Nat::from(1u32) {
                    {
                        this.layout = pop(&this.layout);
                        this = push_tok(&this, &TokKind::KLayClose, &this.pos, &this.pos);
                        Ok((this, at_line_start, done))
                    }
                } else {
                    Err((this, at_line_start, done))
                }), move |(mut this, mut at_line_start, mut done): (Lex, bool, bool)| k_if23158((this, at_line_start, done)))
            } else {
                k_if23158((this, at_line_start, done))
            }
        })
    }
}

/// `Start LexStream, x`: what the function value is when passed to `@Run`.
pub fn start_lex_stream(l0: Lex) -> Rc<dyn prism_rtl::Job<Lex>> {
    Rc::new(LexStream { l0 })
}

/// ```prism
/// UnclosedStream: fn Lex -> Lex
/// ```
pub fn unclosed_stream(l: &Lex) -> Lex {
    match &l.mode {
        Mode::MFile => l.clone(),
        Mode::MBrace(_) => lex_err(l, &l.pos, &l.pos, &Text::lit("a brace block never closes: expected its closing delimiter alone on a line")),
        Mode::MPlaceholder(m23434_2_0) if (m23434_2_0 == &Text::lit("single")) => lex_err(l, &l.pos, &l.pos, &Text::lit("a placeholder never closes: expected `}`")),
        Mode::MPlaceholder(_) => lex_err(l, &l.pos, &l.pos, &Text::lit("a placeholder never closes: expected `}}`")),
        Mode::MPathKey => lex_err(l, &l.pos, &l.pos, &Text::lit("a path key never closes: expected `]`")),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// StreamEndsHere: fn Lex -> ((Bool, Lex))
/// ```
pub fn stream_ends_here(l: &Lex) -> (bool, Lex) {
    let c = peek(l);
    let closes = match &l.mode {
        Mode::MPlaceholder(m24034_0_0) if (m24034_0_0 == &Text::lit("single")) => &c == &Text::lit("}"),
        Mode::MPlaceholder(m24034_1_0) if (m24034_1_0 == &Text::lit("double")) => starts_with(l, &Text::lit("}}")),
        Mode::MPathKey => &c == &Text::lit("]"),
        _ => false,
        _ => unreachable!("no arm matched"),
    };
    let width = if &l.mode == &Mode::MPlaceholder(Text::lit("double")) {
        Nat::from(2u32)
    } else {
        Nat::from(1u32)
    };
    if (&len(&l.frames) == &Nat::from(0u32)) && closes {
        (true, forward(l, &width))
    } else {
        (false, l.clone())
    }
}

/// ```prism
/// EndLine: fn Lex -> Lex
/// ```
pub fn end_line(l: &Lex) -> Lex {
    match last(&l.tokens) {
        Some(t) if ((&len(&l.tokens) > &l.line_first) && opens_block(&t.kind)) => {
            let mut this: Lex = l.clone();
            this.pending_open = true;
            this.pending_span = t.span.clone();
            this
        },
        _ => l.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// OpensBlock: fn TokKind -> Bool
/// ```
pub fn opens_block(tok_kind0: &TokKind) -> bool {
    match tok_kind0 {
        TokKind::KColon => true,
        TokKind::KLambdaBar(false) => true,
        _ => false,
    }
}

/// ```prism
/// BeginLine: unbounded fn Lex -> ((Lex, Text))
/// ```
pub fn begin_line(l0: &Lex) -> (Lex, Text) {
    let line_begin = l0.pos.clone();
    let (l1, col) = indentation(l0);
    match peek(&l1) {
        m25385_0 if (&m25385_0 == &Text::lit("")) => (l1.clone(), Text::lit("end")),
        m25385_1 if (&m25385_1 == &Text::lit("\n")) => (bump(&l1), Text::lit("skip")),
        m25385_2 if (&m25385_2 == &Text::lit("#")) => {
            let l2 = {
                let mut this: Lex = l1.clone();
                this.pos = line_end(&this);
                this
            };
            if &peek(&l2) == &Text::lit("\n") {
                (bump(&l2), Text::lit("skip"))
            } else {
                (l2.clone(), Text::lit("end"))
            }
        },
        _ => if closes_brace_block(&l1) {
            (skip_line(&l1), Text::lit("end"))
        } else {
            {
                let l2 = indented_line(&l1, &col, &line_begin);
                (l2.clone(), Text::lit("tokens"))
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `BeginLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BeginLine: unbounded fn Lex -> ((Lex, Text))
/// ```
pub struct BeginLine {
    pub l0: Lex,
}

impl prism_rtl::Job<(Lex, Text)> for BeginLine {
    fn cycle(&self) -> prism_rtl::Turn<(Lex, Text)> {
        let l0 = &self.l0;
        let line_begin = l0.pos.clone();
        let l0 = l0.clone();
        call_then(start_indentation(l0.clone()), move |indentation_25366: (Lex, Nat)| {
            let (l1, col) = indentation_25366;
            match peek(&l1) {
                m25385_0 if (&m25385_0 == &Text::lit("")) => prism_rtl::Turn::Finished((l1.clone(), Text::lit("end"))),
                m25385_1 if (&m25385_1 == &Text::lit("\n")) => prism_rtl::Turn::Finished((bump(&l1), Text::lit("skip"))),
                m25385_2 if (&m25385_2 == &Text::lit("#")) => {
                    let l2 = {
                        let mut this: Lex = l1.clone();
                        this.pos = line_end(&this);
                        this
                    };
                    if &peek(&l2) == &Text::lit("\n") {
                        prism_rtl::Turn::Finished((bump(&l2), Text::lit("skip")))
                    } else {
                        prism_rtl::Turn::Finished((l2.clone(), Text::lit("end")))
                    }
                },
                _ => call_then(start_closes_brace_block(l1.clone()), move |closes_brace_block_25740: bool| if closes_brace_block_25740 {
                    call_then(start_skip_line(l1.clone()), move |skip_line_25763: Lex| prism_rtl::Turn::Finished((skip_line_25763, Text::lit("end"))))
                } else {
                    call_then(start_indented_line(l1.clone(), col.clone(), line_begin.clone()), move |indented_line_25827: Lex| {
                        let l2 = indented_line_25827;
                        prism_rtl::Turn::Finished((l2.clone(), Text::lit("tokens")))
                    })
                }),
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start BeginLine, x`: what the function value is when passed to `@Run`.
pub fn start_begin_line(l0: Lex) -> Rc<dyn prism_rtl::Job<(Lex, Text)>> {
    Rc::new(BeginLine { l0 })
}

/// ```prism
/// Indentation: unbounded fn Lex -> ((Lex, Nat))
/// ```
pub fn indentation(l0: &Lex) -> (Lex, Nat) {
    let mut this: (Lex, Nat) = (l0.clone(), Nat::from(0u32));
    let mut l: Lex = l0.clone();
    let mut col: Nat = Nat::from(0u32);
    let mut going: bool = true;
    while going {
        match &peek(&l) {
            u26148_0 if (u26148_0 == &Text::lit(" ")) => {
                l = bump(&l);
                col = &col + &Nat::from(1u32);
                ()
            },
            u26148_1 if (u26148_1 == &Text::lit("\t")) => {
                l = lex_err(&bump(&l), &l.pos, &(&l.pos + &Nat::from(1u32)), &Text::lit("a tab in leading whitespace is an error: indent with spaces"));
                col = &col + &Nat::from(1u32);
                ()
            },
            u26148_2 if (u26148_2 == &Text::lit("\r")) => {
                l = bump(&l);
                ()
            },
            _ => {
                going = false;
                ()
            },
            _ => unreachable!("no arm matched"),
        };
    }
    this = (l.clone(), col.clone());
    this
}

/// The step machine of `Indentation`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Indentation: unbounded fn Lex -> ((Lex, Nat))
/// ```
pub struct Indentation {
    pub l0: Lex,
}

impl prism_rtl::Job<(Lex, Nat)> for Indentation {
    fn cycle(&self) -> prism_rtl::Turn<(Lex, Nat)> {
        let l0 = &self.l0;
        let mut this: (Lex, Nat) = (l0.clone(), Nat::from(0u32));
        let mut l: Lex = l0.clone();
        let mut col: Nat = Nat::from(0u32);
        let mut going: bool = true;
        call_then(loop_job((this, col, going, l), move |(mut this, mut col, mut going, mut l): ((Lex, Nat), Nat, bool, Lex)| if going {
            {
                match &peek(&l) {
                    u26148_0 if (u26148_0 == &Text::lit(" ")) => {
                        l = bump(&l);
                        col = &col + &Nat::from(1u32);
                        ()
                    },
                    u26148_1 if (u26148_1 == &Text::lit("\t")) => {
                        l = lex_err(&bump(&l), &l.pos, &(&l.pos + &Nat::from(1u32)), &Text::lit("a tab in leading whitespace is an error: indent with spaces"));
                        col = &col + &Nat::from(1u32);
                        ()
                    },
                    u26148_2 if (u26148_2 == &Text::lit("\r")) => {
                        l = bump(&l);
                        ()
                    },
                    _ => {
                        going = false;
                        ()
                    },
                    _ => unreachable!("no arm matched"),
                };
                Ok((this, col, going, l))
            }
        } else {
            Err((this, col, going, l))
        }), move |(mut this, mut col, mut going, mut l): ((Lex, Nat), Nat, bool, Lex)| {
            this = (l.clone(), col.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start Indentation, x`: what the function value is when passed to `@Run`.
pub fn start_indentation(l0: Lex) -> Rc<dyn prism_rtl::Job<(Lex, Nat)>> {
    Rc::new(Indentation { l0 })
}

/// ```prism
/// ClosesBraceBlock: unbounded fn Lex -> Bool
/// ```
pub fn closes_brace_block(l: &Lex) -> bool {
    match &l.mode {
        Mode::MBrace(m26626_0_0) if (m26626_0_0 == &Text::lit("double")) => &trim_end(&rest_of_line(l)) == &Text::lit("}}"),
        Mode::MBrace(_) => &trim_end(&rest_of_line(l)) == &Text::lit("}"),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ClosesBraceBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosesBraceBlock: unbounded fn Lex -> Bool
/// ```
pub struct ClosesBraceBlock {
    pub l: Lex,
}

impl prism_rtl::Job<bool> for ClosesBraceBlock {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let l = &self.l;
        match &l.mode {
            Mode::MBrace(m26626_0_0) if (m26626_0_0 == &Text::lit("double")) => {
                let l = l.clone();
                call_then(start_rest_of_line(l.clone()), move |rest_of_line_26671: Text| prism_rtl::Turn::Finished(&trim_end(&rest_of_line_26671) == &Text::lit("}}")))
            },
            Mode::MBrace(_) => {
                let l = l.clone();
                call_then(start_rest_of_line(l.clone()), move |rest_of_line_26725: Text| prism_rtl::Turn::Finished(&trim_end(&rest_of_line_26725) == &Text::lit("}")))
            },
            _ => prism_rtl::Turn::Finished(false),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ClosesBraceBlock, x`: what the function value is when passed to `@Run`.
pub fn start_closes_brace_block(l: Lex) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(ClosesBraceBlock { l })
}

/// ```prism
/// SkipLine: unbounded fn Lex -> Lex
/// ```
pub fn skip_line(l0: &Lex) -> Lex {
    let l = {
        let mut this: Lex = l0.clone();
        this.pos = line_end(&this);
        this
    };
    if &peek(&l) == &Text::lit("\n") { bump(&l) } else { l.clone() }
}

/// The step machine of `SkipLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SkipLine: unbounded fn Lex -> Lex
/// ```
pub struct SkipLine {
    pub l0: Lex,
}

impl prism_rtl::Job<Lex> for SkipLine {
    fn cycle(&self) -> prism_rtl::Turn<Lex> {
        let l0 = &self.l0;
        let l = {
            let mut this: Lex = l0.clone();
            this.pos = line_end(&this);
            this
        };
        if &peek(&l) == &Text::lit("\n") {
            prism_rtl::Turn::Finished(bump(&l))
        } else {
            prism_rtl::Turn::Finished(l.clone())
        }
    }
}

/// `Start SkipLine, x`: what the function value is when passed to `@Run`.
pub fn start_skip_line(l0: Lex) -> Rc<dyn prism_rtl::Job<Lex>> {
    Rc::new(SkipLine { l0 })
}

/// ```prism
/// IndentedLine: unbounded fn Lex, Nat, Nat -> Lex
/// ```
pub fn indented_line(l0: &Lex, col: &Nat, line_begin: &Nat) -> Lex {
    let here = l0.pos.clone();
    let l = {
        let mut this: Lex = l0.clone();
        this.line_first = len(&this.tokens);
        this.last_ws = true;
        this
    };
    if l.first_line {
        first_line(&l, col, line_begin, &here)
    } else {
        layout_line(&l, col, line_begin, &here)
    }
}

/// The step machine of `IndentedLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IndentedLine: unbounded fn Lex, Nat, Nat -> Lex
/// ```
pub struct IndentedLine {
    pub l0: Lex,
    pub col: Nat,
    pub line_begin: Nat,
}

impl prism_rtl::Job<Lex> for IndentedLine {
    fn cycle(&self) -> prism_rtl::Turn<Lex> {
        let l0 = &self.l0;
        let col = &self.col;
        let line_begin = &self.line_begin;
        let here = l0.pos.clone();
        let l = {
            let mut this: Lex = l0.clone();
            this.line_first = len(&this.tokens);
            this.last_ws = true;
            this
        };
        if l.first_line {
            prism_rtl::Turn::Finished(first_line(&l, col, line_begin, &here))
        } else {
            prism_rtl::Turn::Finished(layout_line(&l, col, line_begin, &here))
        }
    }
}

/// `Start IndentedLine, x`: what the function value is when passed to `@Run`.
pub fn start_indented_line(l0: Lex, col: Nat, line_begin: Nat) -> Rc<dyn prism_rtl::Job<Lex>> {
    Rc::new(IndentedLine { l0, col, line_begin })
}

/// ```prism
/// FirstLine: fn Lex, Nat, Nat, Nat -> Lex
/// ```
pub fn first_line(l0: &Lex, col: &Nat, line_begin: &Nat, here: &Nat) -> Lex {
    let mut this: Lex = l0.clone();
    this.first_line = false;
    if &this.mode == &Mode::MFile {
        this.layout = Array::from(vec![Nat::from(0u32)]);
        if col != &Nat::from(0u32) {
            this = lex_err(&this, line_begin, here, &Text::lit("the first line of a file starts at column 0"));
            this.layout = Array::from(vec![col.clone()]);
        }
    } else {
        this.layout = push(&this.layout, col);
    }
    this
}

/// ```prism
/// Below: fn ?Nat, Nat -> Bool
/// ```
pub fn below(opt0: &Option<Nat>, n1: &Nat) -> bool {
    match (opt0, n1) {
        (None, _) => false,
        (Some(d), depth) => depth < d,
    }
}

/// ```prism
/// LayoutLine: fn Lex, Nat, Nat, Nat -> Lex
/// ```
pub fn layout_line(l0: &Lex, col: &Nat, line_begin: &Nat, here: &Nat) -> Lex {
    let mut this: Lex = l0.clone();
    let top = or(&last(&this.layout), &Nat::from(0u32));
    let fat = starts_with(&this, &Text::lit("=>"));
    let mut opened: bool = false;
    let mut fuel: Nat = len(&this.layout);
    if this.pending_open {
        this.pending_open = false;
        if col > &top {
            this.layout = push(&this.layout, col);
            this = push_tok(&this, &TokKind::KLayOpen, here, here);
            if &this.test_pending == &Text::lit("test") {
                this.test_depth = Some(len(&this.layout));
            }
            if &this.test_pending == &Text::lit("check") {
                this.check_depth = Some(len(&this.layout));
            }
            this.test_pending = Text::lit("");
            opened = true;
        } else {
            this.diags = push(&this.diags, &lex_diag(&this.pending_span, &Text::lit("expected an indented block after `:`")));
        }
    }
    if !opened {
        if ((col > &top) && fat) && (&this.test_depth == &Some(len(&this.layout))) {
            this.layout = push(&this.layout, col);
            this = push_tok(&this, &TokKind::KLayOpen, here, here);
        } else if col == &top {
            this = push_tok(&this, &TokKind::KLaySep, here, here);
            if &len(&this.layout) == &Nat::from(1u32) {
                this.test_pending = Text::lit("");
            }
        } else if col > &top {
            this.mark_line_start = true;
        } else {
            while let Some(left) = (&fuel).checked_sub(&Nat::from(1u32)) {
                if !((&len(&this.layout) > &Nat::from(1u32)) && (col < &or(&last(&this.layout), &Nat::from(0u32)))) {
                    break;
                }
                fuel = left.clone();
                this.layout = pop(&this.layout);
                this = push_tok(&this, &TokKind::KLayClose, here, here);
                let depth = len(&this.layout);
                if below(&this.test_depth, &depth) {
                    this.test_depth = None;
                }
                if below(&this.check_depth, &depth) {
                    this.check_depth = None;
                }
            }
            if col != &or(&last(&this.layout), &Nat::from(0u32)) {
                this = lex_err(&this, line_begin, here, &Text::lit("unindent does not match any open block"));
            }
            this = push_tok(&this, &TokKind::KLaySep, here, here);
            if &len(&this.layout) == &Nat::from(1u32) {
                this.test_pending = Text::lit("");
            }
        }
    }
    this
}

/// ```prism
/// LexToken: unbounded fn Lex -> Lex
/// ```
pub fn lex_token(l0: &Lex) -> Lex {
    let start = l0.pos.clone();
    let c = peek(l0);
    let l = {
        let mut this: Lex = l0.clone();
        this.path_next = false;
        this
    };
    if l0.path_next && ((is_digit(&c) || (&c == &Text::lit("#"))) || (&c == &Text::lit("["))) {
        lex_path_token(&l, &start)
    } else {
        lex_token_at(&l, &start, &c)
    }
}

/// The step machine of `LexToken`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexToken: unbounded fn Lex -> Lex
/// ```
pub struct LexToken {
    pub l0: Lex,
}

impl prism_rtl::Job<Lex> for LexToken {
    fn cycle(&self) -> prism_rtl::Turn<Lex> {
        let l0 = &self.l0;
        let start = l0.pos.clone();
        let c = peek(l0);
        let l = {
            let mut this: Lex = l0.clone();
            this.path_next = false;
            this
        };
        if l0.path_next && ((is_digit(&c) || (&c == &Text::lit("#"))) || (&c == &Text::lit("["))) {
            prism_rtl::Turn::More(Rc::new(LexPathToken { l: l.clone(), start: start.clone() }))
        } else {
            prism_rtl::Turn::More(Rc::new(LexTokenAt { l: l.clone(), start: start.clone(), c: c.clone() }))
        }
    }
}

/// `Start LexToken, x`: what the function value is when passed to `@Run`.
pub fn start_lex_token(l0: Lex) -> Rc<dyn prism_rtl::Job<Lex>> {
    Rc::new(LexToken { l0 })
}

/// ```prism
/// LexPathToken: unbounded fn Lex, Nat -> Lex
/// ```
pub fn lex_path_token(l: &Lex, start: &Nat) -> Lex {
    let (segs, l2) = lex_path(l);
    push_tok(&l2, &TokKind::KPath(segs.clone()), start, &l2.pos)
}

/// The step machine of `LexPathToken`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexPathToken: unbounded fn Lex, Nat -> Lex
/// ```
pub struct LexPathToken {
    pub l: Lex,
    pub start: Nat,
}

impl prism_rtl::Job<Lex> for LexPathToken {
    fn cycle(&self) -> prism_rtl::Turn<Lex> {
        let l = &self.l;
        let start = &self.start;
        let l = l.clone();
        let start = start.clone();
        call_then(start_lex_path(l.clone()), move |lex_path_31091: (Array<PathSegTok>, Lex)| {
            let (segs, l2) = lex_path_31091;
            prism_rtl::Turn::Finished(push_tok(&l2, &TokKind::KPath(segs.clone()), &start, &l2.pos))
        })
    }
}

/// `Start LexPathToken, x`: what the function value is when passed to `@Run`.
pub fn start_lex_path_token(l: Lex, start: Nat) -> Rc<dyn prism_rtl::Job<Lex>> {
    Rc::new(LexPathToken { l, start })
}

/// ```prism
/// LexTokenAt: unbounded fn Lex, Nat, Text -> Lex
/// ```
pub fn lex_token_at(l: &Lex, start: &Nat, c: &Text) -> Lex {
    match c {
        m31221_0 if (m31221_0 == &Text::lit("\"")) => {
            let (text, l2) = lex_text(l);
            push_tok(&l2, &TokKind::KText(Text::lit(""), text.clone()), start, &l2.pos)
        },
        m31221_1 if (m31221_1 == &Text::lit("'")) => {
            let (ch, l2) = lex_char(l);
            push_tok(&l2, &TokKind::KChar(Text::lit(""), ch.clone()), start, &l2.pos)
        },
        _ if is_digit(c) => {
            let (kind, l2) = lex_number(l, &Text::lit(""));
            push_tok(&l2, &kind, start, &l2.pos)
        },
        _ if is_ident_start(c) => lex_word_token(l, &Text::lit(""), start),
        _ if contains(&Text::lit("$@?~&^"), c) => lex_sigils(l),
        m31221_5 if (m31221_5 == &Text::lit("!")) => if &peek_at(l, &Nat::from(1u32)) == &Text::lit("=") {
            push_op_suffix(&forward(l, &Nat::from(2u32)), &Text::lit("!="), start)
        } else {
            lex_sigils(l)
        },
        _ if contains(&Text::lit("([{"), c) => lex_open(l, c, start),
        _ if contains(&Text::lit(")]}"), c) => lex_close(l, c, start),
        m31221_8 if (m31221_8 == &Text::lit(",")) => push_tok(&bump(l), &TokKind::KComma, start, &(start + &Nat::from(1u32))),
        m31221_9 if (m31221_9 == &Text::lit(":")) => push_tok(&bump(l), &TokKind::KColon, start, &(start + &Nat::from(1u32))),
        m31221_10 if (m31221_10 == &Text::lit(";")) => push_tok(&bump(l), &TokKind::KSemi, start, &(start + &Nat::from(1u32))),
        m31221_11 if (m31221_11 == &Text::lit("\\")) => lex_backslash(l, start),
        m31221_12 if (m31221_12 == &Text::lit("|")) => lex_bar(l, start),
        m31221_13 if (m31221_13 == &Text::lit(".")) => lex_dot(l, start),
        _ => match lex_operator(l, start) {
            Some(l2) => l2.clone(),
            None => {
                let l1 = bump(l);
                let l2 = lex_err(&l1, start, &l1.pos, &Text::from(format!("unexpected character `{}`", c)));
                {
                    let mut this: Lex = l2.clone();
                    this.last_ws = true;
                    this
                }
            },
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `LexTokenAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexTokenAt: unbounded fn Lex, Nat, Text -> Lex
/// ```
pub struct LexTokenAt {
    pub l: Lex,
    pub start: Nat,
    pub c: Text,
}

impl prism_rtl::Job<Lex> for LexTokenAt {
    fn cycle(&self) -> prism_rtl::Turn<Lex> {
        let l = &self.l;
        let start = &self.start;
        let c = &self.c;
        match c {
            m31221_0 if (m31221_0 == &Text::lit("\"")) => {
                let l = l.clone();
                let start = start.clone();
                call_then(start_lex_text(l.clone()), move |lex_text_31267: (Array<TextSegTok>, Lex)| {
                    let (text, l2) = lex_text_31267;
                    prism_rtl::Turn::Finished(push_tok(&l2, &TokKind::KText(Text::lit(""), text.clone()), &start, &l2.pos))
                })
            },
            m31221_1 if (m31221_1 == &Text::lit("'")) => {
                let l = l.clone();
                let start = start.clone();
                call_then(start_lex_char(l.clone()), move |lex_char_31363: (Text, Lex)| {
                    let (ch, l2) = lex_char_31363;
                    prism_rtl::Turn::Finished(push_tok(&l2, &TokKind::KChar(Text::lit(""), ch.clone()), &start, &l2.pos))
                })
            },
            _ if is_digit(c) => {
                let l = l.clone();
                let start = start.clone();
                call_then(start_lex_number(l.clone(), Text::lit("")), move |lex_number_31475: (TokKind, Lex)| {
                    let (kind, l2) = lex_number_31475;
                    prism_rtl::Turn::Finished(push_tok(&l2, &kind, &start, &l2.pos))
                })
            },
            _ if is_ident_start(c) => prism_rtl::Turn::More(Rc::new(LexWordToken { l0: l.clone(), sigils: Text::lit(""), start: start.clone() })),
            _ if contains(&Text::lit("$@?~&^"), c) => prism_rtl::Turn::More(Rc::new(LexSigils { l0: l.clone() })),
            m31221_5 if (m31221_5 == &Text::lit("!")) => if &peek_at(l, &Nat::from(1u32)) == &Text::lit("=") {
                prism_rtl::Turn::More(Rc::new(PushOpSuffix { l: forward(l, &Nat::from(2u32)), op: Text::lit("!="), start: start.clone() }))
            } else {
                prism_rtl::Turn::More(Rc::new(LexSigils { l0: l.clone() }))
            },
            _ if contains(&Text::lit("([{"), c) => prism_rtl::Turn::Finished(lex_open(l, c, start)),
            _ if contains(&Text::lit(")]}"), c) => prism_rtl::Turn::Finished(lex_close(l, c, start)),
            m31221_8 if (m31221_8 == &Text::lit(",")) => prism_rtl::Turn::Finished(push_tok(&bump(l), &TokKind::KComma, start, &(start + &Nat::from(1u32)))),
            m31221_9 if (m31221_9 == &Text::lit(":")) => prism_rtl::Turn::Finished(push_tok(&bump(l), &TokKind::KColon, start, &(start + &Nat::from(1u32)))),
            m31221_10 if (m31221_10 == &Text::lit(";")) => prism_rtl::Turn::Finished(push_tok(&bump(l), &TokKind::KSemi, start, &(start + &Nat::from(1u32)))),
            m31221_11 if (m31221_11 == &Text::lit("\\")) => prism_rtl::Turn::Finished(lex_backslash(l, start)),
            m31221_12 if (m31221_12 == &Text::lit("|")) => prism_rtl::Turn::Finished(lex_bar(l, start)),
            m31221_13 if (m31221_13 == &Text::lit(".")) => prism_rtl::Turn::Finished(lex_dot(l, start)),
            _ => {
                let c = c.clone();
                let l = l.clone();
                let start = start.clone();
                call_then(start_lex_operator(l.clone(), start.clone()), move |lex_operator_32095: Option<Lex>| match lex_operator_32095 {
                    Some(l2) => prism_rtl::Turn::Finished(l2.clone()),
                    None => {
                        let l1 = bump(&l);
                        let l2 = lex_err(&l1, &start, &l1.pos, &Text::from(format!("unexpected character `{}`", &c)));
                        prism_rtl::Turn::Finished({
                            let mut this: Lex = l2.clone();
                            this.last_ws = true;
                            this
                        })
                    },
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start LexTokenAt, x`: what the function value is when passed to `@Run`.
pub fn start_lex_token_at(l: Lex, start: Nat, c: Text) -> Rc<dyn prism_rtl::Job<Lex>> {
    Rc::new(LexTokenAt { l, start, c })
}

/// ```prism
/// LexOpen: fn Lex, Text, Nat -> Lex
/// ```
pub fn lex_open(l: &Lex, c: &Text, start: &Nat) -> Lex {
    let prefix = ((c == &Text::lit("[")) && prefix_position(l)) && !next_is_space(l, &Nat::from(1u32));
    let l2 = {
        let mut this: Lex = bump(l);
        this.frames = push(&this.frames, c);
        this
    };
    push_tok(&l2, &TokKind::KOpen(c.clone(), prefix), start, &l2.pos)
}

/// ```prism
/// LexClose: fn Lex, Text, Nat -> Lex
/// ```
pub fn lex_close(l: &Lex, c: &Text, start: &Nat) -> Lex {
    let kind = open_of(c);
    let l1 = bump(l);
    let l2 = match last(&l1.frames) {
        Some(k) if (&k == &kind) => {
            let mut this: Lex = l1.clone();
            this.frames = pop(&this.frames);
            this
        },
        Some(m32772_1) if (&m32772_1 == &Text::lit("<<")) => lex_err(&l1, start, &l1.pos, &Text::from(format!("`{}` inside `<<`: expected `>>`", c))),
        Some(k) => {
            let l3 = lex_err(&l1, start, &l1.pos, &Text::from(format!("`{}` closes a `{}`", c, &k)));
            {
                let mut this: Lex = l3.clone();
                this.frames = pop(&this.frames);
                this
            }
        },
        None => lex_err(&l1, start, &l1.pos, &Text::from(format!("`{}` closes nothing", c))),
        _ => unreachable!("no arm matched"),
    };
    push_tok(&l2, &TokKind::KClose(kind.clone()), start, &l2.pos)
}

/// ```prism
/// LexBackslash: fn Lex, Nat -> Lex
/// ```
pub fn lex_backslash(l: &Lex, start: &Nat) -> Lex {
    let l1 = push_tok(&bump(l), &TokKind::KBackslash, start, &(start + &Nat::from(1u32)));
    if &peek(&l1) == &Text::lit("|") {
        {
            let l2 = {
                let mut this: Lex = bump(&l1);
                this.lambda_open = true;
                this
            };
            push_tok(&l2, &TokKind::KLambdaBar(true), &l1.pos, &(&l1.pos + &Nat::from(1u32)))
        }
    } else {
        l1.clone()
    }
}

/// ```prism
/// LexBar: fn Lex, Nat -> Lex
/// ```
pub fn lex_bar(l: &Lex, start: &Nat) -> Lex {
    let l1 = bump(l);
    if l1.lambda_open {
        {
            let l2 = {
                let mut this: Lex = l1.clone();
                this.lambda_open = false;
                this
            };
            push_tok(&l2, &TokKind::KLambdaBar(false), start, &l2.pos)
        }
    } else {
        push_tok(&l1, &TokKind::KBar, start, &l1.pos)
    }
}

/// ```prism
/// LexDot: fn Lex, Nat -> Lex
/// ```
pub fn lex_dot(l: &Lex, start: &Nat) -> Lex {
    if starts_with(l, &Text::lit("..")) {
        push_tok(&forward(l, &Nat::from(2u32)), &TokKind::KDotDot, start, &(start + &Nat::from(2u32)))
    } else {
        {
            let prefix = prefix_position(l) && !next_is_space(l, &Nat::from(1u32));
            let l1 = if prefix && is_digit(&peek_at(l, &Nat::from(1u32))) {
                lex_err(l, start, &(start + &Nat::from(1u32)), &Text::lit("a decimal literal has digits on both sides of its point: write `0.5`, not `.5`"))
            } else {
                l.clone()
            };
            push_tok(&bump(&l1), &TokKind::KDot(prefix), start, &(start + &Nat::from(1u32)))
        }
    }
}

/// ```prism
/// PushOpSuffix: unbounded fn Lex, Text, Nat -> Lex
/// ```
pub fn push_op_suffix(l: &Lex, op: &Text, start: &Nat) -> Lex {
    if takes_suffix(op) && is_upper(&peek(l)) {
        {
            let (path_, l2) = lex_qualified_path(l);
            push_tok(&l2, &TokKind::KSuffixed(op.clone(), path_.clone()), start, &l2.pos)
        }
    } else {
        push_tok(l, &TokKind::KOp(op.clone(), false), start, &l.pos)
    }
}

/// The step machine of `PushOpSuffix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PushOpSuffix: unbounded fn Lex, Text, Nat -> Lex
/// ```
pub struct PushOpSuffix {
    pub l: Lex,
    pub op: Text,
    pub start: Nat,
}

impl prism_rtl::Job<Lex> for PushOpSuffix {
    fn cycle(&self) -> prism_rtl::Turn<Lex> {
        let l = &self.l;
        let op = &self.op;
        let start = &self.start;
        if takes_suffix(op) && is_upper(&peek(l)) {
            {
                let l = l.clone();
                let op = op.clone();
                let start = start.clone();
                call_then(start_lex_qualified_path(l.clone()), move |lex_qualified_path_34636: (Array<Text>, Lex)| {
                    let (path_, l2) = lex_qualified_path_34636;
                    prism_rtl::Turn::Finished(push_tok(&l2, &TokKind::KSuffixed(op.clone(), path_.clone()), &start, &l2.pos))
                })
            }
        } else {
            prism_rtl::Turn::Finished(push_tok(l, &TokKind::KOp(op.clone(), false), start, &l.pos))
        }
    }
}

/// `Start PushOpSuffix, x`: what the function value is when passed to `@Run`.
pub fn start_push_op_suffix(l: Lex, op: Text, start: Nat) -> Rc<dyn prism_rtl::Job<Lex>> {
    Rc::new(PushOpSuffix { l, op, start })
}

/// ```prism
/// FirstOp: fn Lex -> Text
/// ```
pub fn first_op(l: &Lex) -> Text {
    let fat = fat_arrow_on(l);
    fold(&op_table(), &Text::lit(""), &(|found: &Text, s: &Text| if ((found == &Text::lit("")) && ((s != &Text::lit("=>")) || fat)) && starts_with(l, s) {
        s.clone()
    } else {
        found.clone()
    }))
}

/// ```prism
/// EndsMark: fn Text -> Bool
/// ```
pub fn ends_mark(a: &Text) -> bool {
    (a == &Text::lit("")) || contains(&Text::lit(" \n\r,)]}"), a)
}

/// ```prism
/// ClosesSquareOrBrace: fn ?Tok -> Bool
/// ```
pub fn closes_square_or_brace(opt0: &Option<Tok>) -> bool {
    match opt0 {
        Some(t) => (&t.kind == &TokKind::KClose(Text::lit("["))) || (&t.kind == &TokKind::KClose(Text::lit("{"))),
        None => false,
    }
}

/// ```prism
/// ?LexOperator: unbounded fn Lex, Nat -> ?Lex
/// ```
pub fn lex_operator(l: &Lex, start: &Nat) -> Option<Lex> {
    let c = peek(l);
    let after_ = peek_at(l, &Nat::from(1u32));
    let non_empty = (((&c == &Text::lit("+")) && !l.last_ws) && closes_square_or_brace(&last(&l.tokens))) && (ends_mark(&after_) || ((&after_ == &Text::lit("?")) && ends_mark(&peek_at(l, &Nat::from(2u32)))));
    if (&c == &Text::lit("-")) && contains(&Text::lit(",)]}"), &after_) {
        Some(push_tok(&bump(l), &TokKind::KAbsent, start, &(start + &Nat::from(1u32))))
    } else {
        if non_empty {
            Some(non_empty_mark(l, start, &after_))
        } else {
            if starts_with(l, &Text::lit("<<")) {
                Some(open_type_args(l, start))
            } else {
                if starts_with(l, &Text::lit(">>")) && (&last(&l.frames) == &Some(Text::lit("<<"))) {
                    Some(close_type_args(l, start))
                } else {
                    if starts_with(l, &Text::lit(">>")) {
                        Some(lex_err(&push_tok(&forward(l, &Nat::from(2u32)), &TokKind::KGtGt, start, &(start + &Nat::from(2u32))), start, &(start + &Nat::from(2u32)), &Text::lit("`>>` closes explicit type arguments, and none is open (Prism has no shift operators)")))
                    } else {
                        match first_op(l) {
                            m36301_0 if (&m36301_0 == &Text::lit("")) => None,
                            op => Some(push_operator(l, &op, start)),
                            _ => unreachable!("no arm matched"),
                        }
                    }
                }
            }
        }
    }
}

/// The step machine of `LexOperator`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?LexOperator: unbounded fn Lex, Nat -> ?Lex
/// ```
pub struct LexOperator {
    pub l: Lex,
    pub start: Nat,
}

impl prism_rtl::Job<Option<Lex>> for LexOperator {
    fn cycle(&self) -> prism_rtl::Turn<Option<Lex>> {
        let l = &self.l;
        let start = &self.start;
        let c = peek(l);
        let after_ = peek_at(l, &Nat::from(1u32));
        let non_empty = (((&c == &Text::lit("+")) && !l.last_ws) && closes_square_or_brace(&last(&l.tokens))) && (ends_mark(&after_) || ((&after_ == &Text::lit("?")) && ends_mark(&peek_at(l, &Nat::from(2u32)))));
        if (&c == &Text::lit("-")) && contains(&Text::lit(",)]}"), &after_) {
            prism_rtl::Turn::Finished(Some(push_tok(&bump(l), &TokKind::KAbsent, start, &(start + &Nat::from(1u32)))))
        } else {
            if non_empty {
                prism_rtl::Turn::Finished(Some(non_empty_mark(l, start, &after_)))
            } else {
                if starts_with(l, &Text::lit("<<")) {
                    prism_rtl::Turn::Finished(Some(open_type_args(l, start)))
                } else {
                    if starts_with(l, &Text::lit(">>")) && (&last(&l.frames) == &Some(Text::lit("<<"))) {
                        prism_rtl::Turn::Finished(Some(close_type_args(l, start)))
                    } else {
                        if starts_with(l, &Text::lit(">>")) {
                            prism_rtl::Turn::Finished(Some(lex_err(&push_tok(&forward(l, &Nat::from(2u32)), &TokKind::KGtGt, start, &(start + &Nat::from(2u32))), start, &(start + &Nat::from(2u32)), &Text::lit("`>>` closes explicit type arguments, and none is open (Prism has no shift operators)"))))
                        } else {
                            match first_op(l) {
                                m36301_0 if (&m36301_0 == &Text::lit("")) => prism_rtl::Turn::Finished(None),
                                op => prism_rtl::Turn::Finished(Some(push_operator(l, &op, start))),
                                _ => unreachable!("no arm matched"),
                            }
                        }
                    }
                }
            }
        }
    }
}

/// `Start LexOperator, x`: what the function value is when passed to `@Run`.
pub fn start_lex_operator(l: Lex, start: Nat) -> Rc<dyn prism_rtl::Job<Option<Lex>>> {
    Rc::new(LexOperator { l, start })
}

/// ```prism
/// NonEmptyMark: fn Lex, Nat, Text -> Lex
/// ```
pub fn non_empty_mark(l: &Lex, start: &Nat, after_: &Text) -> Lex {
    let l1 = push_tok(&bump(l), &TokKind::KNonEmpty, start, &(start + &Nat::from(1u32)));
    if after_ == &Text::lit("?") {
        push_tok(&bump(&l1), &TokKind::KFree(Text::lit("?")), &l1.pos, &(&l1.pos + &Nat::from(1u32)))
    } else {
        l1.clone()
    }
}

/// ```prism
/// OpenTypeArgs: fn Lex, Nat -> Lex
/// ```
pub fn open_type_args(l: &Lex, start: &Nat) -> Lex {
    let touching = !l.last_ws && is_name_tok(&last(&l.tokens));
    let l1 = forward(l, &Nat::from(2u32));
    let l2 = if touching {
        l1.clone()
    } else {
        lex_err(&l1, start, &l1.pos, &Text::lit("`<<` opens explicit type arguments and must touch a name on its left (Prism has no shift operators)"))
    };
    let l3 = {
        let mut this: Lex = l2.clone();
        this.frames = push(&this.frames, &Text::lit("<<"));
        this
    };
    push_tok(&l3, &TokKind::KLtLt, start, &l3.pos)
}

/// ```prism
/// IsNameTok: fn ?Tok -> Bool
/// ```
pub fn is_name_tok(opt0: &Option<Tok>) -> bool {
    match opt0 {
        Some(t) => match &t.kind {
            TokKind::KName(_) => true,
            _ => false,
        },
        None => false,
    }
}

/// ```prism
/// CloseTypeArgs: fn Lex, Nat -> Lex
/// ```
pub fn close_type_args(l: &Lex, start: &Nat) -> Lex {
    let l1 = {
        let mut this: Lex = forward(l, &Nat::from(2u32));
        this.frames = pop(&this.frames);
        this
    };
    push_tok(&l1, &TokKind::KGtGt, start, &l1.pos)
}

/// ```prism
/// PushOperator: unbounded fn Lex, Text, Nat -> Lex
/// ```
pub fn push_operator(l: &Lex, op: &Text, start: &Nat) -> Lex {
    let l1 = forward(l, &len_text(op));
    if (((op == &Text::lit("+")) || (op == &Text::lit("-"))) || (op == &Text::lit("-?"))) && !is_upper(&peek(&l1)) {
        push_tok(&l1, &TokKind::KOp(op.clone(), prefix_position(&l1) && !next_is_space(&l1, &Nat::from(0u32))), start, &l1.pos)
    } else {
        push_op_suffix(&l1, op, start)
    }
}

/// The step machine of `PushOperator`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PushOperator: unbounded fn Lex, Text, Nat -> Lex
/// ```
pub struct PushOperator {
    pub l: Lex,
    pub op: Text,
    pub start: Nat,
}

impl prism_rtl::Job<Lex> for PushOperator {
    fn cycle(&self) -> prism_rtl::Turn<Lex> {
        let l = &self.l;
        let op = &self.op;
        let start = &self.start;
        let l1 = forward(l, &len_text(op));
        if (((op == &Text::lit("+")) || (op == &Text::lit("-"))) || (op == &Text::lit("-?"))) && !is_upper(&peek(&l1)) {
            prism_rtl::Turn::Finished(push_tok(&l1, &TokKind::KOp(op.clone(), prefix_position(&l1) && !next_is_space(&l1, &Nat::from(0u32))), start, &l1.pos))
        } else {
            prism_rtl::Turn::More(Rc::new(PushOpSuffix { l: l1.clone(), op: op.clone(), start: start.clone() }))
        }
    }
}

/// `Start PushOperator, x`: what the function value is when passed to `@Run`.
pub fn start_push_operator(l: Lex, op: Text, start: Nat) -> Rc<dyn prism_rtl::Job<Lex>> {
    Rc::new(PushOperator { l, op, start })
}

/// ```prism
/// LexSigils: unbounded fn Lex -> Lex
/// ```
pub fn lex_sigils(l0: &Lex) -> Lex {
    let start = l0.pos.clone();
    let (sigils, caret, l) = read_sigils(l0);
    let next = peek(&l);
    if caret {
        lex_caret(&l, &start, &sigils, &next)
    } else {
        if (is_ident_start(&next) || is_digit(&next)) || (&next == &Text::lit("\"")) {
            lex_attached(&l, &start, &sigils, &next)
        } else {
            if ((&sigils == &Text::lit("&")) && (&next == &Text::lit("."))) && is_lower(&peek_at(&l, &Nat::from(1u32))) {
                push_tok(&bump(&l), &TokKind::KLensDot, &start, &(&l.pos + &Nat::from(1u32)))
            } else {
                free_sigils(&l, &start, &sigils)
            }
        }
    }
}

/// The step machine of `LexSigils`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexSigils: unbounded fn Lex -> Lex
/// ```
pub struct LexSigils {
    pub l0: Lex,
}

impl prism_rtl::Job<Lex> for LexSigils {
    fn cycle(&self) -> prism_rtl::Turn<Lex> {
        let l0 = &self.l0;
        let start = l0.pos.clone();
        let l0 = l0.clone();
        call_then(start_read_sigils(l0.clone()), move |read_sigils_38541: (Text, bool, Lex)| {
            let (sigils, caret, l) = read_sigils_38541;
            let next = peek(&l);
            if caret {
                prism_rtl::Turn::More(Rc::new(LexCaret { l: l.clone(), start: start.clone(), sigils: sigils.clone(), next: next.clone() }))
            } else {
                if (is_ident_start(&next) || is_digit(&next)) || (&next == &Text::lit("\"")) {
                    prism_rtl::Turn::More(Rc::new(LexAttached { l: l.clone(), start: start.clone(), sigils: sigils.clone(), next: next.clone() }))
                } else {
                    if ((&sigils == &Text::lit("&")) && (&next == &Text::lit("."))) && is_lower(&peek_at(&l, &Nat::from(1u32))) {
                        prism_rtl::Turn::Finished(push_tok(&bump(&l), &TokKind::KLensDot, &start, &(&l.pos + &Nat::from(1u32))))
                    } else {
                        prism_rtl::Turn::Finished(free_sigils(&l, &start, &sigils))
                    }
                }
            }
        })
    }
}

/// `Start LexSigils, x`: what the function value is when passed to `@Run`.
pub fn start_lex_sigils(l0: Lex) -> Rc<dyn prism_rtl::Job<Lex>> {
    Rc::new(LexSigils { l0 })
}

/// ```prism
/// ReadSigils: unbounded fn Lex -> ((Text, Bool, Lex))
/// ```
pub fn read_sigils(l0: &Lex) -> (Text, bool, Lex) {
    let mut this: (Text, bool, Lex) = (Text::lit(""), false, l0.clone());
    let mut l: Lex = l0.clone();
    let mut sigils: Text = Text::lit("");
    let mut caret: bool = false;
    let mut going: bool = true;
    while going {
        let c = peek(&l);
        if &c == &Text::lit("^") {
            l = bump(&l);
            caret = true;
            going = false;
        } else if is_sigil_char(&c) && !((&c == &Text::lit("!")) && (&peek_at(&l, &Nat::from(1u32)) == &Text::lit("="))) {
            l = bump(&l);
            sigils = Text::from(format!("{}{}", &sigils, &c));
        } else {
            going = false;
        }
    }
    this = (sigils.clone(), caret, l.clone());
    this
}

/// The step machine of `ReadSigils`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadSigils: unbounded fn Lex -> ((Text, Bool, Lex))
/// ```
pub struct ReadSigils {
    pub l0: Lex,
}

impl prism_rtl::Job<(Text, bool, Lex)> for ReadSigils {
    fn cycle(&self) -> prism_rtl::Turn<(Text, bool, Lex)> {
        let l0 = &self.l0;
        let mut this: (Text, bool, Lex) = (Text::lit(""), false, l0.clone());
        let mut l: Lex = l0.clone();
        let mut sigils: Text = Text::lit("");
        let mut caret: bool = false;
        let mut going: bool = true;
        call_then(loop_job((this, caret, going, l, sigils), move |(mut this, mut caret, mut going, mut l, mut sigils): ((Text, bool, Lex), bool, bool, Lex, Text)| if going {
            {
                let c = peek(&l);
                if &c == &Text::lit("^") {
                    l = bump(&l);
                    caret = true;
                    going = false;
                } else if is_sigil_char(&c) && !((&c == &Text::lit("!")) && (&peek_at(&l, &Nat::from(1u32)) == &Text::lit("="))) {
                    l = bump(&l);
                    sigils = Text::from(format!("{}{}", &sigils, &c));
                } else {
                    going = false;
                }
                Ok((this, caret, going, l, sigils))
            }
        } else {
            Err((this, caret, going, l, sigils))
        }), move |(mut this, mut caret, mut going, mut l, mut sigils): ((Text, bool, Lex), bool, bool, Lex, Text)| {
            this = (sigils.clone(), caret, l.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start ReadSigils, x`: what the function value is when passed to `@Run`.
pub fn start_read_sigils(l0: Lex) -> Rc<dyn prism_rtl::Job<(Text, bool, Lex)>> {
    Rc::new(ReadSigils { l0 })
}

/// ```prism
/// LexCaret: unbounded fn Lex, Nat, Text, Text -> Lex
/// ```
pub fn lex_caret(l: &Lex, start: &Nat, sigils: &Text, next: &Text) -> Lex {
    if is_upper(next) && (sigils == &Text::lit("")) {
        {
            let (path_, l2) = lex_qualified_path(l);
            push_tok(&l2, &TokKind::KTrait(path_.clone()), start, &l2.pos)
        }
    } else {
        {
            let (_, skipped) = lex_qualified_path(l);
            let l2 = if is_ident_start(next) { skipped.clone() } else { l.clone() };
            lex_err(&l2, start, &max(&l2.pos, &l.pos), &Text::lit("`^` marks a trait and attaches to its uppercase name: no trait is a value"))
        }
    }
}

/// The step machine of `LexCaret`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexCaret: unbounded fn Lex, Nat, Text, Text -> Lex
/// ```
pub struct LexCaret {
    pub l: Lex,
    pub start: Nat,
    pub sigils: Text,
    pub next: Text,
}

impl prism_rtl::Job<Lex> for LexCaret {
    fn cycle(&self) -> prism_rtl::Turn<Lex> {
        let l = &self.l;
        let start = &self.start;
        let sigils = &self.sigils;
        let next = &self.next;
        if is_upper(next) && (sigils == &Text::lit("")) {
            {
                let l = l.clone();
                let start = start.clone();
                call_then(start_lex_qualified_path(l.clone()), move |lex_qualified_path_39730: (Array<Text>, Lex)| {
                    let (path_, l2) = lex_qualified_path_39730;
                    prism_rtl::Turn::Finished(push_tok(&l2, &TokKind::KTrait(path_.clone()), &start, &l2.pos))
                })
            }
        } else {
            {
                let l = l.clone();
                let next = next.clone();
                let start = start.clone();
                call_then(start_lex_qualified_path(l.clone()), move |lex_qualified_path_39842: (Array<Text>, Lex)| {
                    let (_, skipped) = lex_qualified_path_39842;
                    let l2 = if is_ident_start(&next) { skipped.clone() } else { l.clone() };
                    prism_rtl::Turn::Finished(lex_err(&l2, &start, &max(&l2.pos, &l.pos), &Text::lit("`^` marks a trait and attaches to its uppercase name: no trait is a value")))
                })
            }
        }
    }
}

/// `Start LexCaret, x`: what the function value is when passed to `@Run`.
pub fn start_lex_caret(l: Lex, start: Nat, sigils: Text, next: Text) -> Rc<dyn prism_rtl::Job<Lex>> {
    Rc::new(LexCaret { l, start, sigils, next })
}

/// ```prism
/// LexAttached: unbounded fn Lex, Nat, Text, Text -> Lex
/// ```
pub fn lex_attached(l: &Lex, start: &Nat, sigils: &Text, next: &Text) -> Lex {
    if next == &Text::lit("\"") {
        {
            let (text, l2) = lex_text(l);
            push_tok(&l2, &TokKind::KText(sigils.clone(), text.clone()), start, &l2.pos)
        }
    } else {
        if is_digit(next) {
            {
                let (kind, l2) = lex_number(l, sigils);
                push_tok(&l2, &kind, start, &l2.pos)
            }
        } else {
            lex_word_token(l, sigils, start)
        }
    }
}

/// The step machine of `LexAttached`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexAttached: unbounded fn Lex, Nat, Text, Text -> Lex
/// ```
pub struct LexAttached {
    pub l: Lex,
    pub start: Nat,
    pub sigils: Text,
    pub next: Text,
}

impl prism_rtl::Job<Lex> for LexAttached {
    fn cycle(&self) -> prism_rtl::Turn<Lex> {
        let l = &self.l;
        let start = &self.start;
        let sigils = &self.sigils;
        let next = &self.next;
        if next == &Text::lit("\"") {
            {
                let l = l.clone();
                let sigils = sigils.clone();
                let start = start.clone();
                call_then(start_lex_text(l.clone()), move |lex_text_40181: (Array<TextSegTok>, Lex)| {
                    let (text, l2) = lex_text_40181;
                    prism_rtl::Turn::Finished(push_tok(&l2, &TokKind::KText(sigils.clone(), text.clone()), &start, &l2.pos))
                })
            }
        } else {
            if is_digit(next) {
                {
                    let l = l.clone();
                    let sigils = sigils.clone();
                    let start = start.clone();
                    call_then(start_lex_number(l.clone(), sigils.clone()), move |lex_number_40301: (TokKind, Lex)| {
                        let (kind, l2) = lex_number_40301;
                        prism_rtl::Turn::Finished(push_tok(&l2, &kind, &start, &l2.pos))
                    })
                }
            } else {
                prism_rtl::Turn::More(Rc::new(LexWordToken { l0: l.clone(), sigils: sigils.clone(), start: start.clone() }))
            }
        }
    }
}

/// `Start LexAttached, x`: what the function value is when passed to `@Run`.
pub fn start_lex_attached(l: Lex, start: Nat, sigils: Text, next: Text) -> Rc<dyn prism_rtl::Job<Lex>> {
    Rc::new(LexAttached { l, start, sigils, next })
}

/// ```prism
/// FreeSigils: fn Lex, Nat, Text -> Lex
/// ```
pub fn free_sigils(l0: &Lex, start: &Nat, sigils: &Text) -> Lex {
    let mut this: Lex = l0.clone();
    let space_after = next_is_space(&this, &Nat::from(0u32));
    let all = fold_chars(sigils, &Array::new(), &(Rc::new(move |(p0, p1): (Array<Text>, Text)| once_job(move || {
        let acc = p0;
        let c = p1;
        prism_rtl::Turn::Finished(push(&acc, &c))
    })) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    for (i40729, v40729) in all.clone().into_iter().enumerate() {
        let k40729 = nat_of(i40729);
        let s = v40729.clone();
        let at_ = start + &k40729;
        if space_after && (&(&k40729 + &Nat::from(1u32)) == &len(&all)) {
            if &s == &Text::lit("!") {
                this = lex_err(&this, &at_, &(&at_ + &Nat::from(1u32)), &Text::lit("`!` is never free: no event fires a constant (write `!e` touching its name)"));
            }
            if &s == &Text::lit("&") {
                this = lex_err(&this, &at_, &(&at_ + &Nat::from(1u32)), &Text::lit("`&` is never free: no reference exists outside the value an `update` block names"));
            }
        }
        this = push_tok(&this, &TokKind::KFree(s.clone()), &at_, &(&at_ + &Nat::from(1u32)));
    }
    this
}

/// ```prism
/// LexQualifiedPath: unbounded fn Lex -> (([Text], Lex))
/// ```
pub fn lex_qualified_path(l0: &Lex) -> (Array<Text>, Lex) {
    let mut this: (Array<Text>, Lex) = (Array::new(), l0.clone());
    let (first_, l1) = lex_ident(l0);
    let mut path_: Array<Text> = Array::from(vec![first_.clone()]);
    let mut l: Lex = l1.clone();
    let mut going: bool = true;
    while going {
        let last_ = or(&last(&path_), &Text::lit(""));
        let next = peek_at(&l, &Nat::from(1u32));
        if (&peek(&l) != &Text::lit(".")) || !is_upper(&head(&last_)) {
            going = false;
        } else if is_upper(&next) {
            let (seg, l2) = lex_ident(&bump(&l));
            path_ = push(&path_, &seg);
            l = l2.clone();
        } else {
            going = false;
            if is_ident_start(&next) {
                let (w, l2) = lex_ident(&bump(&l));
                if is_reserved_ctor(&w) {
                    path_ = push(&path_, &w);
                    l = l2.clone();
                }
            }
        }
    }
    this = (path_.clone(), l.clone());
    this
}

/// The step machine of `LexQualifiedPath`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexQualifiedPath: unbounded fn Lex -> (([Text], Lex))
/// ```
pub struct LexQualifiedPath {
    pub l0: Lex,
}

impl prism_rtl::Job<(Array<Text>, Lex)> for LexQualifiedPath {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Text>, Lex)> {
        let l0 = &self.l0;
        let mut this: (Array<Text>, Lex) = (Array::new(), l0.clone());
        let (first_, l1) = lex_ident(l0);
        let mut path_: Array<Text> = Array::from(vec![first_.clone()]);
        let mut l: Lex = l1.clone();
        let mut going: bool = true;
        call_then(loop_job((this, going, l, path_), move |(mut this, mut going, mut l, mut path_): ((Array<Text>, Lex), bool, Lex, Array<Text>)| if going {
            {
                let last_ = or(&last(&path_), &Text::lit(""));
                let next = peek_at(&l, &Nat::from(1u32));
                if (&peek(&l) != &Text::lit(".")) || !is_upper(&head(&last_)) {
                    going = false;
                } else if is_upper(&next) {
                    let (seg, l2) = lex_ident(&bump(&l));
                    path_ = push(&path_, &seg);
                    l = l2.clone();
                } else {
                    going = false;
                    if is_ident_start(&next) {
                        let (w, l2) = lex_ident(&bump(&l));
                        if is_reserved_ctor(&w) {
                            path_ = push(&path_, &w);
                            l = l2.clone();
                        }
                    }
                }
                Ok((this, going, l, path_))
            }
        } else {
            Err((this, going, l, path_))
        }), move |(mut this, mut going, mut l, mut path_): ((Array<Text>, Lex), bool, Lex, Array<Text>)| {
            this = (path_.clone(), l.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start LexQualifiedPath, x`: what the function value is when passed to `@Run`.
pub fn start_lex_qualified_path(l0: Lex) -> Rc<dyn prism_rtl::Job<(Array<Text>, Lex)>> {
    Rc::new(LexQualifiedPath { l0 })
}

/// ```prism
/// LexIdent: unbounded fn Lex -> ((Text, Lex))
/// ```
pub fn lex_ident(l0: &Lex) -> (Text, Lex) {
    let l = {
        let mut this: Lex = l0.clone();
        while is_ident_char(&peek(&this)) {
            this.pos = &this.pos + &Nat::from(1u32);
        }
        this
    };
    let word = slice(&l, &l0.pos, &l.pos);
    (word.clone(), l.clone())
}

/// The step machine of `LexIdent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexIdent: unbounded fn Lex -> ((Text, Lex))
/// ```
pub struct LexIdent {
    pub l0: Lex,
}

impl prism_rtl::Job<(Text, Lex)> for LexIdent {
    fn cycle(&self) -> prism_rtl::Turn<(Text, Lex)> {
        let l0 = &self.l0;
        let mut this: Lex = l0.clone();
        let l0 = l0.clone();
        call_then(loop_job((this,), move |(mut this,): (Lex,)| if is_ident_char(&peek(&this)) {
            {
                this.pos = &this.pos + &Nat::from(1u32);
                Ok((this,))
            }
        } else {
            Err((this,))
        }), move |(mut this,): (Lex,)| {
            let l = this;
            let word = slice(&l, &l0.pos, &l.pos);
            prism_rtl::Turn::Finished((word.clone(), l.clone()))
        })
    }
}

/// `Start LexIdent, x`: what the function value is when passed to `@Run`.
pub fn start_lex_ident(l0: Lex) -> Rc<dyn prism_rtl::Job<(Text, Lex)>> {
    Rc::new(LexIdent { l0 })
}

/// ```prism
/// LexWordToken: unbounded fn Lex, Text, Nat -> Lex
/// ```
pub fn lex_word_token(l0: &Lex, sigils: &Text, start: &Nat) -> Lex {
    let w_start = l0.pos.clone();
    let (path_, l1) = lex_qualified_path(l0);
    let l = if is_non_ascii(&peek(&l1)) { skip_non_ascii(&l1, &w_start) } else { l1.clone() };
    let first_ = or(&index(&path_, &Nat::from(0u32)), &Text::lit(""));
    if starts_with(&l, &Text::lit(".*")) && is_upper(&head(&first_)) {
        {
            let l2 = forward(&l, &Nat::from(2u32));
            let l3 = if sigils != &Text::lit("") {
                lex_err(&l2, start, &l2.pos, &Text::lit("a family pattern takes no sigil"))
            } else {
                l2.clone()
            };
            push_tok(&l3, &TokKind::KFamily(path_.clone()), start, &l3.pos)
        }
    } else {
        if ((&len(&path_) == &Nat::from(1u32)) && is_keyword(&first_)) && !(is_bound_word(&first_) && (sigils != &Text::lit(""))) {
            lex_keyword(&l, &first_, sigils, start)
        } else {
            lex_name(&l, &path_, sigils, start, &w_start)
        }
    }
}

/// The step machine of `LexWordToken`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexWordToken: unbounded fn Lex, Text, Nat -> Lex
/// ```
pub struct LexWordToken {
    pub l0: Lex,
    pub sigils: Text,
    pub start: Nat,
}

impl prism_rtl::Job<Lex> for LexWordToken {
    fn cycle(&self) -> prism_rtl::Turn<Lex> {
        let l0 = &self.l0;
        let sigils = &self.sigils;
        let start = &self.start;
        let w_start = l0.pos.clone();
        let l0 = l0.clone();
        let sigils = sigils.clone();
        let start = start.clone();
        call_then(start_lex_qualified_path(l0.clone()), move |lex_qualified_path_42603: (Array<Text>, Lex)| {
            let (path_, l1) = lex_qualified_path_42603;
            let l = if is_non_ascii(&peek(&l1)) { skip_non_ascii(&l1, &w_start) } else { l1.clone() };
            let first_ = or(&index(&path_, &Nat::from(0u32)), &Text::lit(""));
            if starts_with(&l, &Text::lit(".*")) && is_upper(&head(&first_)) {
                {
                    let l2 = forward(&l, &Nat::from(2u32));
                    let l3 = if &sigils != &Text::lit("") {
                        lex_err(&l2, &start, &l2.pos, &Text::lit("a family pattern takes no sigil"))
                    } else {
                        l2.clone()
                    };
                    prism_rtl::Turn::Finished(push_tok(&l3, &TokKind::KFamily(path_.clone()), &start, &l3.pos))
                }
            } else {
                if ((&len(&path_) == &Nat::from(1u32)) && is_keyword(&first_)) && !(is_bound_word(&first_) && (&sigils != &Text::lit(""))) {
                    prism_rtl::Turn::More(Rc::new(LexKeyword { l: l.clone(), w: first_.clone(), sigils: sigils.clone(), start: start.clone() }))
                } else {
                    prism_rtl::Turn::More(Rc::new(LexName { l: l.clone(), path_: path_.clone(), sigils: sigils.clone(), start: start.clone(), w_start: w_start.clone() }))
                }
            }
        })
    }
}

/// `Start LexWordToken, x`: what the function value is when passed to `@Run`.
pub fn start_lex_word_token(l0: Lex, sigils: Text, start: Nat) -> Rc<dyn prism_rtl::Job<Lex>> {
    Rc::new(LexWordToken { l0, sigils, start })
}

/// ```prism
/// SkipNonAscii: unbounded fn Lex, Nat -> Lex
/// ```
pub fn skip_non_ascii(l0: &Lex, w_start: &Nat) -> Lex {
    let l = {
        let mut this: Lex = l0.clone();
        while is_ident_char(&peek(&this)) || is_non_ascii(&peek(&this)) {
            this.pos = &this.pos + &len_text(&peek(&this));
        }
        this
    };
    lex_err(&l, w_start, &l.pos, &Text::lit("names are ASCII letters, digits and underscores"))
}

/// The step machine of `SkipNonAscii`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SkipNonAscii: unbounded fn Lex, Nat -> Lex
/// ```
pub struct SkipNonAscii {
    pub l0: Lex,
    pub w_start: Nat,
}

impl prism_rtl::Job<Lex> for SkipNonAscii {
    fn cycle(&self) -> prism_rtl::Turn<Lex> {
        let l0 = &self.l0;
        let w_start = &self.w_start;
        let mut this: Lex = l0.clone();
        let w_start = w_start.clone();
        call_then(loop_job((this,), move |(mut this,): (Lex,)| if is_ident_char(&peek(&this)) || is_non_ascii(&peek(&this)) {
            {
                this.pos = &this.pos + &len_text(&peek(&this));
                Ok((this,))
            }
        } else {
            Err((this,))
        }), move |(mut this,): (Lex,)| {
            let l = this;
            prism_rtl::Turn::Finished(lex_err(&l, &w_start, &l.pos, &Text::lit("names are ASCII letters, digits and underscores")))
        })
    }
}

/// `Start SkipNonAscii, x`: what the function value is when passed to `@Run`.
pub fn start_skip_non_ascii(l0: Lex, w_start: Nat) -> Rc<dyn prism_rtl::Job<Lex>> {
    Rc::new(SkipNonAscii { l0, w_start })
}

/// ```prism
/// LexKeyword: unbounded fn Lex, Text, Text, Nat -> Lex
/// ```
pub fn lex_keyword(l: &Lex, w: &Text, sigils: &Text, start: &Nat) -> Lex {
    let l1 = if (sigils != &Text::lit("")) && !(((w == &Text::lit("widget")) || (w == &Text::lit("unit"))) || (w == &Text::lit("nil"))) {
        lex_err(l, start, &l.pos, &Text::from(format!("`{}` is a keyword and takes no sigil", w)))
    } else {
        l.clone()
    };
    let l2 = if (w == &Text::lit("widget")) && (sigils != &Text::lit("@")) {
        lex_err(&l1, start, &l1.pos, &Text::lit("`widget` is a block only as `@widget:`"))
    } else {
        l1.clone()
    };
    let l3 = push_tok(&l2, &TokKind::KKw(w.clone(), sigils.clone()), start, &l2.pos);
    if ((w == &Text::lit("output")) || (w == &Text::lit("inline_text"))) || (w == &Text::lit("raw")) {
        maybe_template(&l3, w)
    } else {
        l3.clone()
    }
}

/// The step machine of `LexKeyword`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexKeyword: unbounded fn Lex, Text, Text, Nat -> Lex
/// ```
pub struct LexKeyword {
    pub l: Lex,
    pub w: Text,
    pub sigils: Text,
    pub start: Nat,
}

impl prism_rtl::Job<Lex> for LexKeyword {
    fn cycle(&self) -> prism_rtl::Turn<Lex> {
        let l = &self.l;
        let w = &self.w;
        let sigils = &self.sigils;
        let start = &self.start;
        let l1 = if (sigils != &Text::lit("")) && !(((w == &Text::lit("widget")) || (w == &Text::lit("unit"))) || (w == &Text::lit("nil"))) {
            lex_err(l, start, &l.pos, &Text::from(format!("`{}` is a keyword and takes no sigil", w)))
        } else {
            l.clone()
        };
        let l2 = if (w == &Text::lit("widget")) && (sigils != &Text::lit("@")) {
            lex_err(&l1, start, &l1.pos, &Text::lit("`widget` is a block only as `@widget:`"))
        } else {
            l1.clone()
        };
        let l3 = push_tok(&l2, &TokKind::KKw(w.clone(), sigils.clone()), start, &l2.pos);
        if ((w == &Text::lit("output")) || (w == &Text::lit("inline_text"))) || (w == &Text::lit("raw")) {
            prism_rtl::Turn::More(Rc::new(MaybeTemplate { l0: l3.clone(), kw: w.clone() }))
        } else {
            prism_rtl::Turn::Finished(l3.clone())
        }
    }
}

/// `Start LexKeyword, x`: what the function value is when passed to `@Run`.
pub fn start_lex_keyword(l: Lex, w: Text, sigils: Text, start: Nat) -> Rc<dyn prism_rtl::Job<Lex>> {
    Rc::new(LexKeyword { l, w, sigils, start })
}

/// ```prism
/// LexName: unbounded fn Lex, [Text], Text, Nat, Nat -> Lex
/// ```
pub fn lex_name(l: &Lex, path_: &Array<Text>, sigils: &Text, start: &Nat, w_start: &Nat) -> Lex {
    let (case, l1) = name_case_of(l, path_, w_start);
    let l2 = if is_path_word(&l1, sigils, path_) {
        {
            let mut this: Lex = l1.clone();
            this.path_next = true;
            this
        }
    } else {
        l1.clone()
    };
    push_tok(&l2, &TokKind::KName(NameTok { sigils: sigils.clone(), path_: path_.clone(), case: case.clone() }), start, &l2.pos)
}

/// The step machine of `LexName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexName: unbounded fn Lex, [Text], Text, Nat, Nat -> Lex
/// ```
pub struct LexName {
    pub l: Lex,
    pub path_: Array<Text>,
    pub sigils: Text,
    pub start: Nat,
    pub w_start: Nat,
}

impl prism_rtl::Job<Lex> for LexName {
    fn cycle(&self) -> prism_rtl::Turn<Lex> {
        let l = &self.l;
        let path_ = &self.path_;
        let sigils = &self.sigils;
        let start = &self.start;
        let w_start = &self.w_start;
        let (case, l1) = name_case_of(l, path_, w_start);
        let l2 = if is_path_word(&l1, sigils, path_) {
            {
                let mut this: Lex = l1.clone();
                this.path_next = true;
                this
            }
        } else {
            l1.clone()
        };
        prism_rtl::Turn::Finished(push_tok(&l2, &TokKind::KName(NameTok { sigils: sigils.clone(), path_: path_.clone(), case: case.clone() }), start, &l2.pos))
    }
}

/// `Start LexName, x`: what the function value is when passed to `@Run`.
pub fn start_lex_name(l: Lex, path_: Array<Text>, sigils: Text, start: Nat, w_start: Nat) -> Rc<dyn prism_rtl::Job<Lex>> {
    Rc::new(LexName { l, path_, sigils, start, w_start })
}

/// ```prism
/// NameCaseOf: fn Lex, [Text], Nat -> ((NameCase, Lex))
/// ```
pub fn name_case_of(l: &Lex, path_: &Array<Text>, w_start: &Nat) -> (NameCase, Lex) {
    let last_ = or(&last(path_), &Text::lit(""));
    if &last_ == &Text::lit("_") {
        (NameCase::CaseTopic, l.clone())
    } else {
        if (&head(&last_) == &Text::lit("_")) && all_chars(&after_first(&last_), &{
            let f = Rc::new(is_digit);
            Rc::new(move |a0: Text| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
        }) {
            (NameCase::CaseHole, l.clone())
        } else {
            if &head(&last_) == &Text::lit("_") {
                (NameCase::CaseLower, lex_err(l, w_start, &l.pos, &Text::lit("`_` followed by a letter is not a name: `_` alone is the topic, `_1` a hole")))
            } else {
                if is_reserved_ctor(&last_) {
                    (NameCase::CaseReserved, l.clone())
                } else {
                    if is_upper(&head(&last_)) {
                        {
                            let underscored = fold(path_, &false, &(|seen: &bool, seg: &Text| *seen || contains(seg, &Text::lit("_"))));
                            if underscored {
                                (NameCase::CaseUpper, lex_err(l, w_start, &l.pos, &Text::from(format!("`{}`: a capital promises UpperCamelCase", &join(path_, &Text::lit("."))))))
                            } else {
                                (NameCase::CaseUpper, l.clone())
                            }
                        }
                    } else {
                        (NameCase::CaseLower, l.clone())
                    }
                }
            }
        }
    }
}

/// ```prism
/// IsPathWord: fn Lex, Text, [Text] -> Bool
/// ```
pub fn is_path_word(l: &Lex, sigils: &Text, path_: &Array<Text>) -> bool {
    let w = or(&index(path_, &Nat::from(0u32)), &Text::lit(""));
    let words = if &w == &Text::lit("at") {
        Array::from(vec![Text::lit("send"), Text::lit("click"), Text::lit("answer")])
    } else {
        Array::from(vec![Text::lit("click")])
    };
    let prev = match last(&l.tokens) {
        Some(t) => match &t.kind {
            TokKind::KName(n) if ((&n.sigils == &Text::lit("")) && (&len(&n.path_) == &Nat::from(1u32))) => or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")),
            _ => Text::lit(""),
            _ => unreachable!("no arm matched"),
        },
        None => Text::lit(""),
    };
    ((((&l.test_depth != &None) && (sigils == &Text::lit(""))) && (&len(path_) == &Nat::from(1u32))) && ((&w == &Text::lit("at")) || (&w == &Text::lit("element")))) && fold(&words, &false, &(|seen: &bool, x: &Text| *seen || (x == &prev)))
}

/// ```prism
/// LexNumber: unbounded fn Lex, Text -> ((TokKind, Lex))
/// ```
pub fn lex_number(l: &Lex, sigils: &Text) -> (TokKind, Lex) {
    if (&peek(l) == &Text::lit("0")) && contains(&Text::lit("xob"), &peek_at(l, &Nat::from(1u32))) {
        lex_radix(l, sigils)
    } else {
        lex_decimal(l, sigils)
    }
}

/// The step machine of `LexNumber`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexNumber: unbounded fn Lex, Text -> ((TokKind, Lex))
/// ```
pub struct LexNumber {
    pub l: Lex,
    pub sigils: Text,
}

impl prism_rtl::Job<(TokKind, Lex)> for LexNumber {
    fn cycle(&self) -> prism_rtl::Turn<(TokKind, Lex)> {
        let l = &self.l;
        let sigils = &self.sigils;
        if (&peek(l) == &Text::lit("0")) && contains(&Text::lit("xob"), &peek_at(l, &Nat::from(1u32))) {
            prism_rtl::Turn::More(Rc::new(LexRadix { l0: l.clone(), sigils: sigils.clone() }))
        } else {
            prism_rtl::Turn::More(Rc::new(LexDecimal { l0: l.clone(), sigils: sigils.clone() }))
        }
    }
}

/// `Start LexNumber, x`: what the function value is when passed to `@Run`.
pub fn start_lex_number(l: Lex, sigils: Text) -> Rc<dyn prism_rtl::Job<(TokKind, Lex)>> {
    Rc::new(LexNumber { l, sigils })
}

/// ```prism
/// RadixDigit: fn Text, Text -> Bool
/// ```
pub fn radix_digit(text0: &Text, c: &Text) -> bool {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("x")) => is_hex_digit(c),
        c1_0 if (c1_0 == &Text::lit("o")) => (&Text::lit("0") <= c) && (c <= &Text::lit("7")),
        _ => (c == &Text::lit("0")) || (c == &Text::lit("1")),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// LexRadix: unbounded fn Lex, Text -> ((TokKind, Lex))
/// ```
pub fn lex_radix(l0: &Lex, sigils: &Text) -> (TokKind, Lex) {
    let start = l0.pos.clone();
    let radix = peek_at(l0, &Nat::from(1u32));
    let l1 = forward(l0, &Nat::from(2u32));
    let l2 = {
        let mut this: Lex = l1.clone();
        while radix_digit(&radix, &peek(&this)) || (&peek(&this) == &Text::lit("_")) {
            this.pos = &this.pos + &Nat::from(1u32);
        }
        this
    };
    let l3 = if &l2.pos == &l1.pos {
        lex_err(&l2, &start, &l2.pos, &Text::lit("a radix prefix needs digits after it"))
    } else {
        l2.clone()
    };
    let l4 = check_no_suffix(&l3, &start);
    let kind = TokKind::KInt(sigils.clone(), slice(&l4, &start, &l4.pos));
    (kind.clone(), l4.clone())
}

/// The step machine of `LexRadix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexRadix: unbounded fn Lex, Text -> ((TokKind, Lex))
/// ```
pub struct LexRadix {
    pub l0: Lex,
    pub sigils: Text,
}

impl prism_rtl::Job<(TokKind, Lex)> for LexRadix {
    fn cycle(&self) -> prism_rtl::Turn<(TokKind, Lex)> {
        let l0 = &self.l0;
        let sigils = &self.sigils;
        let start = l0.pos.clone();
        let radix = peek_at(l0, &Nat::from(1u32));
        let l1 = forward(l0, &Nat::from(2u32));
        let mut this: Lex = l1.clone();
        let l1 = l1.clone();
        let radix = radix.clone();
        let sigils = sigils.clone();
        let start = start.clone();
        call_then(loop_job((this,), {
            let radix = radix.clone();
            move |(mut this,): (Lex,)| if radix_digit(&radix, &peek(&this)) || (&peek(&this) == &Text::lit("_")) {
                {
                    this.pos = &this.pos + &Nat::from(1u32);
                    Ok((this,))
                }
            } else {
                Err((this,))
            }
        }), move |(mut this,): (Lex,)| {
            let l2 = this;
            let l3 = if &l2.pos == &l1.pos {
                lex_err(&l2, &start, &l2.pos, &Text::lit("a radix prefix needs digits after it"))
            } else {
                l2.clone()
            };
            call_then(start_check_no_suffix(l3.clone(), start.clone()), move |check_no_suffix_46973: Lex| {
                let l4 = check_no_suffix_46973;
                let kind = TokKind::KInt(sigils.clone(), slice(&l4, &start, &l4.pos));
                prism_rtl::Turn::Finished((kind.clone(), l4.clone()))
            })
        })
    }
}

/// `Start LexRadix, x`: what the function value is when passed to `@Run`.
pub fn start_lex_radix(l0: Lex, sigils: Text) -> Rc<dyn prism_rtl::Job<(TokKind, Lex)>> {
    Rc::new(LexRadix { l0, sigils })
}

/// ```prism
/// SkipDigits: unbounded fn Lex -> Lex
/// ```
pub fn skip_digits(l: &Lex) -> Lex {
    let mut this: Lex = l.clone();
    while is_digit(&peek(&this)) || (&peek(&this) == &Text::lit("_")) {
        this.pos = &this.pos + &Nat::from(1u32);
    }
    this
}

/// The step machine of `SkipDigits`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SkipDigits: unbounded fn Lex -> Lex
/// ```
pub struct SkipDigits {
    pub l: Lex,
}

impl prism_rtl::Job<Lex> for SkipDigits {
    fn cycle(&self) -> prism_rtl::Turn<Lex> {
        let l = &self.l;
        let mut this: Lex = l.clone();
        call_then(loop_job((this,), move |(mut this,): (Lex,)| if is_digit(&peek(&this)) || (&peek(&this) == &Text::lit("_")) {
            {
                this.pos = &this.pos + &Nat::from(1u32);
                Ok((this,))
            }
        } else {
            Err((this,))
        }), move |(mut this,): (Lex,)| prism_rtl::Turn::Finished(this))
    }
}

/// `Start SkipDigits, x`: what the function value is when passed to `@Run`.
pub fn start_skip_digits(l: Lex) -> Rc<dyn prism_rtl::Job<Lex>> {
    Rc::new(SkipDigits { l })
}

/// ```prism
/// LexDecimal: unbounded fn Lex, Text -> ((TokKind, Lex))
/// ```
pub fn lex_decimal(l0: &Lex, sigils: &Text) -> (TokKind, Lex) {
    let start = l0.pos.clone();
    let l1 = skip_digits(l0);
    let next = peek_at(&l1, &Nat::from(1u32));
    if (&peek(&l1) == &Text::lit(".")) && is_digit(&next) {
        number_tail(&skip_digits(&bump(&l1)), sigils, &start, &true)
    } else {
        if (((&peek(&l1) == &Text::lit(".")) && (&next != &Text::lit("."))) && (&next != &Text::lit(""))) && !is_ident_start(&next) {
            {
                let l2 = bump(&l1);
                let l3 = lex_err(&l2, &start, &l2.pos, &Text::from(format!("`{}` is not a number: a decimal literal has digits on both sides of its point", &slice(&l2, &start, &l2.pos))));
                let kind = TokKind::KFloat(sigils.clone(), slice(&l3, &start, &dec(&l2.pos)));
                (kind.clone(), l3.clone())
            }
        } else {
            number_tail(&l1, sigils, &start, &false)
        }
    }
}

/// The step machine of `LexDecimal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexDecimal: unbounded fn Lex, Text -> ((TokKind, Lex))
/// ```
pub struct LexDecimal {
    pub l0: Lex,
    pub sigils: Text,
}

impl prism_rtl::Job<(TokKind, Lex)> for LexDecimal {
    fn cycle(&self) -> prism_rtl::Turn<(TokKind, Lex)> {
        let l0 = &self.l0;
        let sigils = &self.sigils;
        let start = l0.pos.clone();
        let l0 = l0.clone();
        let sigils = sigils.clone();
        call_then(start_skip_digits(l0.clone()), move |skip_digits_47322: Lex| {
            let l1 = skip_digits_47322;
            let next = peek_at(&l1, &Nat::from(1u32));
            if (&peek(&l1) == &Text::lit(".")) && is_digit(&next) {
                call_then(start_skip_digits(bump(&l1)), move |skip_digits_47420: Lex| prism_rtl::Turn::More(Rc::new(NumberTail { l: skip_digits_47420, sigils: sigils.clone(), start: start.clone(), decimal: true })))
            } else {
                if (((&peek(&l1) == &Text::lit(".")) && (&next != &Text::lit("."))) && (&next != &Text::lit(""))) && !is_ident_start(&next) {
                    {
                        let l2 = bump(&l1);
                        let l3 = lex_err(&l2, &start, &l2.pos, &Text::from(format!("`{}` is not a number: a decimal literal has digits on both sides of its point", &slice(&l2, &start, &l2.pos))));
                        let kind = TokKind::KFloat(sigils.clone(), slice(&l3, &start, &dec(&l2.pos)));
                        prism_rtl::Turn::Finished((kind.clone(), l3.clone()))
                    }
                } else {
                    prism_rtl::Turn::More(Rc::new(NumberTail { l: l1.clone(), sigils: sigils.clone(), start: start.clone(), decimal: false }))
                }
            }
        })
    }
}

/// `Start LexDecimal, x`: what the function value is when passed to `@Run`.
pub fn start_lex_decimal(l0: Lex, sigils: Text) -> Rc<dyn prism_rtl::Job<(TokKind, Lex)>> {
    Rc::new(LexDecimal { l0, sigils })
}

/// ```prism
/// let durationUnits
/// ```
pub fn duration_units() -> Array<(Text, Nat)> {
    Array::from(vec![(Text::lit("ns"), Nat::from(1u32)), (Text::lit("us"), Nat::from(1000u32)), (Text::lit("ms"), Nat::from(1000000u32)), (Text::lit("min"), Nat::from_int(Int::from(60000000000i64)).unwrap()), (Text::lit("s"), Nat::from_int(Int::from(1000000000i64)).unwrap()), (Text::lit("h"), Nat::from_int(Int::from(3600000000000i64)).unwrap())])
}

/// ```prism
/// ?UnitAt: fn Lex -> ?((Text, Nat))
/// ```
pub fn unit_at(l: &Lex) -> Option<(Text, Nat)> {
    fold(&duration_units(), &None, &(|found_opt: &Option<(Text, Nat)>, u: &(Text, Nat)| if (found_opt == &None) && unit_here(l, u) {
        Some(u.clone())
    } else {
        found_opt.clone()
    }))
}

/// ```prism
/// UnitHere: fn Lex, ((Text, Nat)) -> Bool
/// ```
pub fn unit_here(l: &Lex, arg1: &(Text, Nat)) -> bool {
    match arg1 {
        (u, _) => starts_with(l, u) && !is_ident_char(&peek_at(l, &len_text(u))),
    }
}

/// ```prism
/// NumberTail: unbounded fn Lex, Text, Nat, Bool -> ((TokKind, Lex))
/// ```
pub fn number_tail(l: &Lex, sigils: &Text, start: &Nat, decimal: &bool) -> (TokKind, Lex) {
    match unit_at(l) {
        Some((u, scale)) => {
            let digits = slice(l, start, &l.pos);
            let l2 = forward(l, &len_text(&u));
            let l3 = if whole_nanoseconds(&digits, &scale) {
                l2.clone()
            } else {
                lex_err(&l2, start, &l2.pos, &Text::from(format!("`{}{}` does not name a whole number of nanoseconds", &digits, &u)))
            };
            let kind = TokKind::KDuration(sigils.clone(), digits.clone(), u.clone());
            (kind.clone(), l3.clone())
        },
        None => {
            let (dec_, l2) = exponent(l, decimal);
            let l3 = check_no_suffix(&l2, start);
            let text = slice(&l3, start, &l3.pos);
            let kind = if dec_ {
                TokKind::KFloat(sigils.clone(), text.clone())
            } else {
                TokKind::KInt(sigils.clone(), text.clone())
            };
            (kind.clone(), l3.clone())
        },
    }
}

/// The step machine of `NumberTail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NumberTail: unbounded fn Lex, Text, Nat, Bool -> ((TokKind, Lex))
/// ```
pub struct NumberTail {
    pub l: Lex,
    pub sigils: Text,
    pub start: Nat,
    pub decimal: bool,
}

impl prism_rtl::Job<(TokKind, Lex)> for NumberTail {
    fn cycle(&self) -> prism_rtl::Turn<(TokKind, Lex)> {
        let l = &self.l;
        let sigils = &self.sigils;
        let start = &self.start;
        let decimal = &self.decimal;
        match unit_at(l) {
            Some((u, scale)) => {
                let digits = slice(l, start, &l.pos);
                let l2 = forward(l, &len_text(&u));
                let l3 = if whole_nanoseconds(&digits, &scale) {
                    l2.clone()
                } else {
                    lex_err(&l2, start, &l2.pos, &Text::from(format!("`{}{}` does not name a whole number of nanoseconds", &digits, &u)))
                };
                let kind = TokKind::KDuration(sigils.clone(), digits.clone(), u.clone());
                prism_rtl::Turn::Finished((kind.clone(), l3.clone()))
            },
            None => {
                let decimal = *decimal;
                let l = l.clone();
                let sigils = sigils.clone();
                let start = start.clone();
                call_then(start_exponent(l.clone(), decimal), move |exponent_49241: (bool, Lex)| {
                    let (dec_, l2) = exponent_49241;
                    call_then(start_check_no_suffix(l2.clone(), start.clone()), move |check_no_suffix_49278: Lex| {
                        let l3 = check_no_suffix_49278;
                        let text = slice(&l3, &start, &l3.pos);
                        let kind = if dec_ {
                            TokKind::KFloat(sigils.clone(), text.clone())
                        } else {
                            TokKind::KInt(sigils.clone(), text.clone())
                        };
                        prism_rtl::Turn::Finished((kind.clone(), l3.clone()))
                    })
                })
            },
        }
    }
}

/// `Start NumberTail, x`: what the function value is when passed to `@Run`.
pub fn start_number_tail(l: Lex, sigils: Text, start: Nat, decimal: bool) -> Rc<dyn prism_rtl::Job<(TokKind, Lex)>> {
    Rc::new(NumberTail { l, sigils, start, decimal })
}

/// ```prism
/// Exponent: unbounded fn Lex, Bool -> ((Bool, Lex))
/// ```
pub fn exponent(l: &Lex, decimal: &bool) -> (bool, Lex) {
    let l1 = bump(l);
    let l2 = if (&peek(&l1) == &Text::lit("+")) || (&peek(&l1) == &Text::lit("-")) {
        bump(&l1)
    } else {
        l1.clone()
    };
    if ((&peek(l) == &Text::lit("e")) || (&peek(l) == &Text::lit("E"))) && is_digit(&peek(&l2)) {
        (true, skip_digits(&l2))
    } else {
        (*decimal, l.clone())
    }
}

/// The step machine of `Exponent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Exponent: unbounded fn Lex, Bool -> ((Bool, Lex))
/// ```
pub struct Exponent {
    pub l: Lex,
    pub decimal: bool,
}

impl prism_rtl::Job<(bool, Lex)> for Exponent {
    fn cycle(&self) -> prism_rtl::Turn<(bool, Lex)> {
        let l = &self.l;
        let decimal = &self.decimal;
        let l1 = bump(l);
        let l2 = if (&peek(&l1) == &Text::lit("+")) || (&peek(&l1) == &Text::lit("-")) {
            bump(&l1)
        } else {
            l1.clone()
        };
        if ((&peek(l) == &Text::lit("e")) || (&peek(l) == &Text::lit("E"))) && is_digit(&peek(&l2)) {
            call_then(start_skip_digits(l2.clone()), move |skip_digits_49680: Lex| prism_rtl::Turn::Finished((true, skip_digits_49680)))
        } else {
            prism_rtl::Turn::Finished((*decimal, l.clone()))
        }
    }
}

/// `Start Exponent, x`: what the function value is when passed to `@Run`.
pub fn start_exponent(l: Lex, decimal: bool) -> Rc<dyn prism_rtl::Job<(bool, Lex)>> {
    Rc::new(Exponent { l, decimal })
}

/// ```prism
/// WholeNanoseconds: fn Text, Nat -> Bool
/// ```
pub fn whole_nanoseconds(text: &Text, scale: &Nat) -> bool {
    let parts = split(&concat(&split(text, &Text::lit("_"))), &Text::lit("."));
    match index(&parts, &Nat::from(1u32)) {
        None => true,
        Some(frac0) => {
            let frac = trim_zeros(&frac0);
            let k = len_text(&frac);
            let f = if &frac == &Text::lit("") {
                Nat::from(0u32)
            } else {
                or(&parse_nat_opt(&frac), &Nat::from(1u32))
            };
            let tens = fold_chars(&frac, &Nat::from(1u32), &(Rc::new(move |(p0, p1): (Nat, Text)| once_job(move || {
                let p_ = p0;
                let _ = p1;
                prism_rtl::Turn::Finished(&p_ * &Nat::from(10u32))
            })) as Rc<dyn Fn((Nat, Text)) -> Rc<dyn prism_rtl::Job<Nat>>>));
            (&k <= &Nat::from(30u32)) && (&or(&mod_(&(&f * scale), &tens), &Nat::from(1u32)) == &Nat::from(0u32))
        },
    }
}

/// ```prism
/// TrimZeros: fn Text -> Text
/// ```
pub fn trim_zeros(t: &Text) -> Text {
    trim_trailing(t, &Text::lit("0"))
}

/// ```prism
/// CheckNoSuffix: unbounded fn Lex, Nat -> Lex
/// ```
pub fn check_no_suffix(l0: &Lex, start: &Nat) -> Lex {
    if is_ident_char(&peek(l0)) {
        {
            let l = {
                let mut this: Lex = l0.clone();
                while is_ident_char(&peek(&this)) {
                    this.pos = &this.pos + &Nat::from(1u32);
                }
                this
            };
            lex_err(&l, start, &l.pos, &Text::from(format!("`{}` is not a token: a number literal has no suffix (write a type annotation)", &slice(&l, start, &l.pos))))
        }
    } else {
        l0.clone()
    }
}

/// The step machine of `CheckNoSuffix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckNoSuffix: unbounded fn Lex, Nat -> Lex
/// ```
pub struct CheckNoSuffix {
    pub l0: Lex,
    pub start: Nat,
}

impl prism_rtl::Job<Lex> for CheckNoSuffix {
    fn cycle(&self) -> prism_rtl::Turn<Lex> {
        let l0 = &self.l0;
        let start = &self.start;
        if is_ident_char(&peek(l0)) {
            {
                let mut this: Lex = l0.clone();
                let start = start.clone();
                call_then(loop_job((this,), move |(mut this,): (Lex,)| if is_ident_char(&peek(&this)) {
                    {
                        this.pos = &this.pos + &Nat::from(1u32);
                        Ok((this,))
                    }
                } else {
                    Err((this,))
                }), move |(mut this,): (Lex,)| {
                    let l = this;
                    prism_rtl::Turn::Finished(lex_err(&l, &start, &l.pos, &Text::from(format!("`{}` is not a token: a number literal has no suffix (write a type annotation)", &slice(&l, &start, &l.pos)))))
                })
            }
        } else {
            prism_rtl::Turn::Finished(l0.clone())
        }
    }
}

/// `Start CheckNoSuffix, x`: what the function value is when passed to `@Run`.
pub fn start_check_no_suffix(l0: Lex, start: Nat) -> Rc<dyn prism_rtl::Job<Lex>> {
    Rc::new(CheckNoSuffix { l0, start })
}

/// ```prism
/// LexEscape: unbounded fn Lex -> ((Text, Lex))
/// ```
pub fn lex_escape(l0: &Lex) -> (Text, Lex) {
    let start = l0.pos.clone();
    let l1 = bump(l0);
    let c = peek(&l1);
    let l2 = bump(&l1);
    match &c {
        m50945_0 if (m50945_0 == &Text::lit("\\")) => (Text::lit("\\"), l2.clone()),
        m50945_1 if (m50945_1 == &Text::lit("\"")) => (Text::lit("\""), l2.clone()),
        m50945_2 if (m50945_2 == &Text::lit("'")) => (Text::lit("'"), l2.clone()),
        m50945_3 if (m50945_3 == &Text::lit("n")) => (Text::lit("\n"), l2.clone()),
        m50945_4 if (m50945_4 == &Text::lit("t")) => (Text::lit("\t"), l2.clone()),
        m50945_5 if (m50945_5 == &Text::lit("{")) => (Text::lit("{"), l2.clone()),
        m50945_6 if (m50945_6 == &Text::lit("}")) => (Text::lit("}"), l2.clone()),
        m50945_7 if (m50945_7 == &Text::lit("u")) => unicode_escape(&l2, &start),
        m50945_8 if (m50945_8 == &Text::lit("")) => (Text::lit(""), lex_err(&l1, &start, &l1.pos, &Text::lit("a text literal ends inside an escape"))),
        _ => (Text::lit(""), lex_err(&l2, &start, &l2.pos, &Text::from(format!("`\\{}` is not an escape: the escapes are \\\\ \\\" \\n \\t \\{{ \\}} \\u{{hex}}", &c)))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `LexEscape`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexEscape: unbounded fn Lex -> ((Text, Lex))
/// ```
pub struct LexEscape {
    pub l0: Lex,
}

impl prism_rtl::Job<(Text, Lex)> for LexEscape {
    fn cycle(&self) -> prism_rtl::Turn<(Text, Lex)> {
        let l0 = &self.l0;
        let start = l0.pos.clone();
        let l1 = bump(l0);
        let c = peek(&l1);
        let l2 = bump(&l1);
        match &c {
            m50945_0 if (m50945_0 == &Text::lit("\\")) => prism_rtl::Turn::Finished((Text::lit("\\"), l2.clone())),
            m50945_1 if (m50945_1 == &Text::lit("\"")) => prism_rtl::Turn::Finished((Text::lit("\""), l2.clone())),
            m50945_2 if (m50945_2 == &Text::lit("'")) => prism_rtl::Turn::Finished((Text::lit("'"), l2.clone())),
            m50945_3 if (m50945_3 == &Text::lit("n")) => prism_rtl::Turn::Finished((Text::lit("\n"), l2.clone())),
            m50945_4 if (m50945_4 == &Text::lit("t")) => prism_rtl::Turn::Finished((Text::lit("\t"), l2.clone())),
            m50945_5 if (m50945_5 == &Text::lit("{")) => prism_rtl::Turn::Finished((Text::lit("{"), l2.clone())),
            m50945_6 if (m50945_6 == &Text::lit("}")) => prism_rtl::Turn::Finished((Text::lit("}"), l2.clone())),
            m50945_7 if (m50945_7 == &Text::lit("u")) => prism_rtl::Turn::More(Rc::new(UnicodeEscape { l: l2.clone(), start: start.clone() })),
            m50945_8 if (m50945_8 == &Text::lit("")) => prism_rtl::Turn::Finished((Text::lit(""), lex_err(&l1, &start, &l1.pos, &Text::lit("a text literal ends inside an escape")))),
            _ => prism_rtl::Turn::Finished((Text::lit(""), lex_err(&l2, &start, &l2.pos, &Text::from(format!("`\\{}` is not an escape: the escapes are \\\\ \\\" \\n \\t \\{{ \\}} \\u{{hex}}", &c))))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start LexEscape, x`: what the function value is when passed to `@Run`.
pub fn start_lex_escape(l0: Lex) -> Rc<dyn prism_rtl::Job<(Text, Lex)>> {
    Rc::new(LexEscape { l0 })
}

/// ```prism
/// UnicodeEscape: unbounded fn Lex, Nat -> ((Text, Lex))
/// ```
pub fn unicode_escape(l: &Lex, start: &Nat) -> (Text, Lex) {
    if &peek(l) != &Text::lit("{") {
        (Text::lit(""), lex_err(l, start, &l.pos, &Text::lit("`\\u` is written `\\u{hex}`")))
    } else {
        {
            let hs = &l.pos + &Nat::from(1u32);
            let l1 = {
                let mut this: Lex = bump(l);
                while is_hex_digit(&peek(&this)) {
                    this.pos = &this.pos + &Nat::from(1u32);
                }
                this
            };
            let hex = slice(&l1, &hs, &l1.pos);
            if &peek(&l1) != &Text::lit("}") {
                (Text::lit(""), lex_err(&l1, start, &l1.pos, &Text::lit("`\\u{` needs its closing `}`")))
            } else {
                {
                    let l2 = bump(&l1);
                    match ascii_char(&or(&parse_hex(&hex), &Nat::from(1114112u32))) {
                        Some(ch) => (ch.clone(), l2.clone()),
                        None => (Text::lit(""), lex_err(&l2, start, &l2.pos, &Text::from(format!("`\\u{{{}}}` is past ASCII, which prismc cannot write yet (prismc/README.md, gap UC)", &hex)))),
                    }
                }
            }
        }
    }
}

/// The step machine of `UnicodeEscape`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnicodeEscape: unbounded fn Lex, Nat -> ((Text, Lex))
/// ```
pub struct UnicodeEscape {
    pub l: Lex,
    pub start: Nat,
}

impl prism_rtl::Job<(Text, Lex)> for UnicodeEscape {
    fn cycle(&self) -> prism_rtl::Turn<(Text, Lex)> {
        let l = &self.l;
        let start = &self.start;
        if &peek(l) != &Text::lit("{") {
            prism_rtl::Turn::Finished((Text::lit(""), lex_err(l, start, &l.pos, &Text::lit("`\\u` is written `\\u{hex}`"))))
        } else {
            {
                let hs = &l.pos + &Nat::from(1u32);
                let mut this: Lex = bump(l);
                let hs = hs.clone();
                let start = start.clone();
                call_then(loop_job((this,), move |(mut this,): (Lex,)| if is_hex_digit(&peek(&this)) {
                    {
                        this.pos = &this.pos + &Nat::from(1u32);
                        Ok((this,))
                    }
                } else {
                    Err((this,))
                }), move |(mut this,): (Lex,)| {
                    let l1 = this;
                    let hex = slice(&l1, &hs, &l1.pos);
                    if &peek(&l1) != &Text::lit("}") {
                        prism_rtl::Turn::Finished((Text::lit(""), lex_err(&l1, &start, &l1.pos, &Text::lit("`\\u{` needs its closing `}`"))))
                    } else {
                        {
                            let l2 = bump(&l1);
                            match ascii_char(&or(&parse_hex(&hex), &Nat::from(1114112u32))) {
                                Some(ch) => prism_rtl::Turn::Finished((ch.clone(), l2.clone())),
                                None => prism_rtl::Turn::Finished((Text::lit(""), lex_err(&l2, &start, &l2.pos, &Text::from(format!("`\\u{{{}}}` is past ASCII, which prismc cannot write yet (prismc/README.md, gap UC)", &hex))))),
                            }
                        }
                    }
                })
            }
        }
    }
}

/// `Start UnicodeEscape, x`: what the function value is when passed to `@Run`.
pub fn start_unicode_escape(l: Lex, start: Nat) -> Rc<dyn prism_rtl::Job<(Text, Lex)>> {
    Rc::new(UnicodeEscape { l, start })
}

/// ```prism
/// LexText: unbounded fn Lex -> (([TextSegTok], Lex))
/// ```
pub fn lex_text(l0: &Lex) -> (Array<TextSegTok>, Lex) {
    let mut this: (Array<TextSegTok>, Lex) = (Array::new(), l0.clone());
    let start = l0.pos.clone();
    let mut l: Lex = bump(l0);
    let mut segs: Array<TextSegTok> = Array::new();
    let mut cur: Text = Text::lit("");
    let mut going: bool = true;
    while going {
        let c = peek(&l);
        if (&c == &Text::lit("")) || (&c == &Text::lit("\n")) {
            l = lex_err(&l, &start, &l.pos, &Text::lit("a text literal ends on its line: close it with `\"`, or write a multiline text as `raw <markdown>...</markdown>`"));
            going = false;
        } else {
            match &c {
                u52685_0 if (u52685_0 == &Text::lit("\"")) => {
                    l = bump(&l);
                    going = false;
                    ()
                },
                u52685_1 if (u52685_1 == &Text::lit("\\")) => {
                    let (s, l2) = lex_escape(&l);
                    cur = Text::from(format!("{}{}", &cur, &s));
                    l = l2.clone();
                    ()
                },
                u52685_2 if (u52685_2 == &Text::lit("{")) => {
                    if &cur != &Text::lit("") {
                        segs = push(&segs, &TextSegTok::TsPlain(cur.clone()));
                        cur = Text::lit("");
                    }
                    let ps = l.pos.clone();
                    let (toks, l2) = nested(&bump(&l), &Mode::MPlaceholder(Text::lit("single")));
                    segs = push(&segs, &TextSegTok::TsPlaceholder(toks.clone(), crate::syntax::Range { start: ps.clone(), end: l2.pos.clone() }));
                    l = l2.clone();
                    ()
                },
                u52685_3 if (u52685_3 == &Text::lit("}")) => {
                    l = lex_err(&bump(&l), &l.pos, &(&l.pos + &Nat::from(1u32)), &Text::lit("a `}` in text is written `\\}`"));
                    cur = Text::from(format!("{}}}", &cur));
                    ()
                },
                _ => {
                    l = bump(&l);
                    cur = Text::from(format!("{}{}", &cur, &c));
                    ()
                },
                _ => unreachable!("no arm matched"),
            };
        }
    }
    if &cur != &Text::lit("") {
        segs = push(&segs, &TextSegTok::TsPlain(cur.clone()));
    }
    this = (segs.clone(), l.clone());
    this
}

/// The step machine of `LexText`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexText: unbounded fn Lex -> (([TextSegTok], Lex))
/// ```
pub struct LexText {
    pub l0: Lex,
}

impl prism_rtl::Job<(Array<TextSegTok>, Lex)> for LexText {
    fn cycle(&self) -> prism_rtl::Turn<(Array<TextSegTok>, Lex)> {
        let l0 = &self.l0;
        let mut this: (Array<TextSegTok>, Lex) = (Array::new(), l0.clone());
        let start = l0.pos.clone();
        let mut l: Lex = bump(l0);
        let mut segs: Array<TextSegTok> = Array::new();
        let mut cur: Text = Text::lit("");
        let mut going: bool = true;
        call_then(loop_job((this, cur, going, l, segs), {
            let start = start.clone();
            move |(mut this, mut cur, mut going, mut l, mut segs): ((Array<TextSegTok>, Lex), Text, bool, Lex, Array<TextSegTok>)| if going {
                {
                    let c = peek(&l);
                    if (&c == &Text::lit("")) || (&c == &Text::lit("\n")) {
                        l = lex_err(&l, &start, &l.pos, &Text::lit("a text literal ends on its line: close it with `\"`, or write a multiline text as `raw <markdown>...</markdown>`"));
                        going = false;
                    } else {
                        match &c {
                            u52685_0 if (u52685_0 == &Text::lit("\"")) => {
                                l = bump(&l);
                                going = false;
                                ()
                            },
                            u52685_1 if (u52685_1 == &Text::lit("\\")) => {
                                let (s, l2) = lex_escape(&l);
                                cur = Text::from(format!("{}{}", &cur, &s));
                                l = l2.clone();
                                ()
                            },
                            u52685_2 if (u52685_2 == &Text::lit("{")) => {
                                if &cur != &Text::lit("") {
                                    segs = push(&segs, &TextSegTok::TsPlain(cur.clone()));
                                    cur = Text::lit("");
                                }
                                let ps = l.pos.clone();
                                let (toks, l2) = nested(&bump(&l), &Mode::MPlaceholder(Text::lit("single")));
                                segs = push(&segs, &TextSegTok::TsPlaceholder(toks.clone(), crate::syntax::Range { start: ps.clone(), end: l2.pos.clone() }));
                                l = l2.clone();
                                ()
                            },
                            u52685_3 if (u52685_3 == &Text::lit("}")) => {
                                l = lex_err(&bump(&l), &l.pos, &(&l.pos + &Nat::from(1u32)), &Text::lit("a `}` in text is written `\\}`"));
                                cur = Text::from(format!("{}}}", &cur));
                                ()
                            },
                            _ => {
                                l = bump(&l);
                                cur = Text::from(format!("{}{}", &cur, &c));
                                ()
                            },
                            _ => unreachable!("no arm matched"),
                        };
                    }
                    Ok((this, cur, going, l, segs))
                }
            } else {
                Err((this, cur, going, l, segs))
            }
        }), move |(mut this, mut cur, mut going, mut l, mut segs): ((Array<TextSegTok>, Lex), Text, bool, Lex, Array<TextSegTok>)| {
            if &cur != &Text::lit("") {
                segs = push(&segs, &TextSegTok::TsPlain(cur.clone()));
            }
            this = (segs.clone(), l.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start LexText, x`: what the function value is when passed to `@Run`.
pub fn start_lex_text(l0: Lex) -> Rc<dyn prism_rtl::Job<(Array<TextSegTok>, Lex)>> {
    Rc::new(LexText { l0 })
}

/// ```prism
/// LexChar: unbounded fn Lex -> ((Text, Lex))
/// ```
pub fn lex_char(l0: &Lex) -> (Text, Lex) {
    let start = l0.pos.clone();
    let l1 = bump(l0);
    let c = peek(&l1);
    let (s, l2) = if &c == &Text::lit("\\") {
        lex_escape(&l1)
    } else {
        if ((&c == &Text::lit("'")) || (&c == &Text::lit("\n"))) || (&c == &Text::lit("")) {
            (Text::lit(""), l1.clone())
        } else {
            (c.clone(), bump(&l1))
        }
    };
    let ok = &peek(&l2) == &Text::lit("'");
    let l3 = if ok { bump(&l2) } else { char_tail(&l2, &start) };
    let l4 = if &s == &Text::lit("") {
        lex_err(&l3, &start, &l3.pos, &Text::lit("a character literal holds one code point: `'c'`"))
    } else {
        l3.clone()
    };
    let ch = if &s == &Text::lit("") { Text::lit("\0") } else { s.clone() };
    (ch.clone(), l4.clone())
}

/// The step machine of `LexChar`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexChar: unbounded fn Lex -> ((Text, Lex))
/// ```
pub struct LexChar {
    pub l0: Lex,
}

impl prism_rtl::Job<(Text, Lex)> for LexChar {
    fn cycle(&self) -> prism_rtl::Turn<(Text, Lex)> {
        let l0 = &self.l0;
        let start = l0.pos.clone();
        let l1 = bump(l0);
        let c = peek(&l1);
        let (s, l2) = if &c == &Text::lit("\\") {
            lex_escape(&l1)
        } else {
            if ((&c == &Text::lit("'")) || (&c == &Text::lit("\n"))) || (&c == &Text::lit("")) {
                (Text::lit(""), l1.clone())
            } else {
                (c.clone(), bump(&l1))
            }
        };
        let ok = &peek(&l2) == &Text::lit("'");
        let l3 = if ok { bump(&l2) } else { char_tail(&l2, &start) };
        let l4 = if &s == &Text::lit("") {
            lex_err(&l3, &start, &l3.pos, &Text::lit("a character literal holds one code point: `'c'`"))
        } else {
            l3.clone()
        };
        let ch = if &s == &Text::lit("") { Text::lit("\0") } else { s.clone() };
        prism_rtl::Turn::Finished((ch.clone(), l4.clone()))
    }
}

/// `Start LexChar, x`: what the function value is when passed to `@Run`.
pub fn start_lex_char(l0: Lex) -> Rc<dyn prism_rtl::Job<(Text, Lex)>> {
    Rc::new(LexChar { l0 })
}

/// ```prism
/// CharTail: unbounded fn Lex, Nat -> Lex
/// ```
pub fn char_tail(l0: &Lex, start: &Nat) -> Lex {
    let l1 = {
        let mut this: Lex = l0.clone();
        while ((&peek(&this) != &Text::lit("'")) && (&peek(&this) != &Text::lit("\n"))) && (&peek(&this) != &Text::lit("")) {
            this.pos = &this.pos + &len_text(&peek(&this));
        }
        this
    };
    let l2 = if &peek(&l1) == &Text::lit("'") { bump(&l1) } else { l1.clone() };
    lex_err(&l2, start, &l2.pos, &Text::lit("a character literal holds one code point: `'c'`"))
}

/// The step machine of `CharTail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CharTail: unbounded fn Lex, Nat -> Lex
/// ```
pub struct CharTail {
    pub l0: Lex,
    pub start: Nat,
}

impl prism_rtl::Job<Lex> for CharTail {
    fn cycle(&self) -> prism_rtl::Turn<Lex> {
        let l0 = &self.l0;
        let start = &self.start;
        let mut this: Lex = l0.clone();
        let start = start.clone();
        call_then(loop_job((this,), move |(mut this,): (Lex,)| if ((&peek(&this) != &Text::lit("'")) && (&peek(&this) != &Text::lit("\n"))) && (&peek(&this) != &Text::lit("")) {
            {
                this.pos = &this.pos + &len_text(&peek(&this));
                Ok((this,))
            }
        } else {
            Err((this,))
        }), move |(mut this,): (Lex,)| {
            let l1 = this;
            let l2 = if &peek(&l1) == &Text::lit("'") { bump(&l1) } else { l1.clone() };
            prism_rtl::Turn::Finished(lex_err(&l2, &start, &l2.pos, &Text::lit("a character literal holds one code point: `'c'`")))
        })
    }
}

/// `Start CharTail, x`: what the function value is when passed to `@Run`.
pub fn start_char_tail(l0: Lex, start: Nat) -> Rc<dyn prism_rtl::Job<Lex>> {
    Rc::new(CharTail { l0, start })
}

/// ```prism
/// LexPath: unbounded fn Lex -> (([PathSegTok], Lex))
/// ```
pub fn lex_path(l0: &Lex) -> (Array<PathSegTok>, Lex) {
    let mut this: (Array<PathSegTok>, Lex) = (Array::new(), l0.clone());
    let mut l: Lex = l0.clone();
    let mut segs: Array<PathSegTok> = Array::new();
    let mut going: bool = true;
    while going {
        let s = l.pos.clone();
        let c = peek(&l);
        if &c == &Text::lit("#") {
            let digits = {
                let mut this: Lex = bump(&l);
                while is_digit(&peek(&this)) {
                    this.pos = &this.pos + &Nat::from(1u32);
                }
                this
            };
            let text = slice(&digits, &(&s + &Nat::from(1u32)), &digits.pos);
            l = if &text == &Text::lit("") {
                lex_err(&digits, &s, &digits.pos, &Text::lit("a generation segment is `#` and a number"))
            } else {
                digits.clone()
            };
            segs = push(&segs, &PathSegTok::PstGen(or(&parse_nat_opt(&text), &Nat::from(0u32))));
        } else if is_digit(&c) {
            let digits = {
                let mut this: Lex = l.clone();
                while is_digit(&peek(&this)) {
                    this.pos = &this.pos + &Nat::from(1u32);
                }
                this
            };
            segs = push(&segs, &PathSegTok::PstNum(or(&parse_nat_opt(&slice(&digits, &s, &digits.pos)), &Nat::from(0u32))));
            l = digits.clone();
        } else if &c == &Text::lit("[") {
            let (toks, l2) = nested(&bump(&l), &Mode::MPathKey);
            segs = push(&segs, &PathSegTok::PstKey(toks.clone()));
            l = l2.clone();
        } else {
            l = lex_err(&l, &s, &s, &Text::lit("expected a path segment: a number, `#` and a number, or `[key]`"));
            going = false;
        }
        if going {
            if &peek(&l) == &Text::lit("/") {
                l = bump(&l);
            } else {
                going = false;
            }
        }
    }
    this = (segs.clone(), l.clone());
    this
}

/// The step machine of `LexPath`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexPath: unbounded fn Lex -> (([PathSegTok], Lex))
/// ```
pub struct LexPath {
    pub l0: Lex,
}

impl prism_rtl::Job<(Array<PathSegTok>, Lex)> for LexPath {
    fn cycle(&self) -> prism_rtl::Turn<(Array<PathSegTok>, Lex)> {
        let l0 = &self.l0;
        let mut this: (Array<PathSegTok>, Lex) = (Array::new(), l0.clone());
        let mut l: Lex = l0.clone();
        let mut segs: Array<PathSegTok> = Array::new();
        let mut going: bool = true;
        call_then(loop_job((this, going, l, segs), move |(mut this, mut going, mut l, mut segs): ((Array<PathSegTok>, Lex), bool, Lex, Array<PathSegTok>)| if going {
            {
                let s = l.pos.clone();
                let c = peek(&l);
                if &c == &Text::lit("#") {
                    let digits = {
                        let mut this: Lex = bump(&l);
                        while is_digit(&peek(&this)) {
                            this.pos = &this.pos + &Nat::from(1u32);
                        }
                        this
                    };
                    let text = slice(&digits, &(&s + &Nat::from(1u32)), &digits.pos);
                    l = if &text == &Text::lit("") {
                        lex_err(&digits, &s, &digits.pos, &Text::lit("a generation segment is `#` and a number"))
                    } else {
                        digits.clone()
                    };
                    segs = push(&segs, &PathSegTok::PstGen(or(&parse_nat_opt(&text), &Nat::from(0u32))));
                } else if is_digit(&c) {
                    let digits = {
                        let mut this: Lex = l.clone();
                        while is_digit(&peek(&this)) {
                            this.pos = &this.pos + &Nat::from(1u32);
                        }
                        this
                    };
                    segs = push(&segs, &PathSegTok::PstNum(or(&parse_nat_opt(&slice(&digits, &s, &digits.pos)), &Nat::from(0u32))));
                    l = digits.clone();
                } else if &c == &Text::lit("[") {
                    let (toks, l2) = nested(&bump(&l), &Mode::MPathKey);
                    segs = push(&segs, &PathSegTok::PstKey(toks.clone()));
                    l = l2.clone();
                } else {
                    l = lex_err(&l, &s, &s, &Text::lit("expected a path segment: a number, `#` and a number, or `[key]`"));
                    going = false;
                }
                if going {
                    if &peek(&l) == &Text::lit("/") {
                        l = bump(&l);
                    } else {
                        going = false;
                    }
                }
                Ok((this, going, l, segs))
            }
        } else {
            Err((this, going, l, segs))
        }), move |(mut this, mut going, mut l, mut segs): ((Array<PathSegTok>, Lex), bool, Lex, Array<PathSegTok>)| {
            this = (segs.clone(), l.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start LexPath, x`: what the function value is when passed to `@Run`.
pub fn start_lex_path(l0: Lex) -> Rc<dyn prism_rtl::Job<(Array<PathSegTok>, Lex)>> {
    Rc::new(LexPath { l0 })
}

/// ```prism
/// MaybeTemplate: unbounded fn Lex, Text -> Lex
/// ```
pub fn maybe_template(l0: &Lex, kw: &Text) -> Lex {
    let l = {
        let mut this: Lex = l0.clone();
        while &peek(&this) == &Text::lit(" ") {
            this.pos = &this.pos + &Nat::from(1u32);
        }
        this
    };
    if (&peek(&l) == &Text::lit("<")) && (&template_tag_ahead(&l) != &Text::lit("")) {
        {
            let keyword = if kw == &Text::lit("output") {
                Text::lit("Output")
            } else {
                if kw == &Text::lit("inline_text") {
                    Text::lit("InlineText")
                } else {
                    Text::lit("Raw")
                }
            };
            let (kind, l2) = lex_template(&l, &keyword, &l.pos);
            let l3 = {
                let mut this: Lex = l2.clone();
                this.last_ws = true;
                this
            };
            push_tok(&l3, &kind, &l.pos, &l3.pos)
        }
    } else {
        lex_err(l0, &l0.pos, &l0.pos, &Text::from(format!("`{}` is followed by a language tag, `<rust>`", kw)))
    }
}

/// The step machine of `MaybeTemplate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MaybeTemplate: unbounded fn Lex, Text -> Lex
/// ```
pub struct MaybeTemplate {
    pub l0: Lex,
    pub kw: Text,
}

impl prism_rtl::Job<Lex> for MaybeTemplate {
    fn cycle(&self) -> prism_rtl::Turn<Lex> {
        let l0 = &self.l0;
        let kw = &self.kw;
        let mut this: Lex = l0.clone();
        let kw = kw.clone();
        let l0 = l0.clone();
        call_then(loop_job((this,), move |(mut this,): (Lex,)| if &peek(&this) == &Text::lit(" ") {
            {
                this.pos = &this.pos + &Nat::from(1u32);
                Ok((this,))
            }
        } else {
            Err((this,))
        }), move |(mut this,): (Lex,)| {
            let l = this;
            if (&peek(&l) == &Text::lit("<")) && (&template_tag_ahead(&l) != &Text::lit("")) {
                {
                    let keyword = if &kw == &Text::lit("output") {
                        Text::lit("Output")
                    } else {
                        if &kw == &Text::lit("inline_text") {
                            Text::lit("InlineText")
                        } else {
                            Text::lit("Raw")
                        }
                    };
                    call_then(start_lex_template(l.clone(), keyword.clone(), l.pos.clone()), move |lex_template_57243: (TokKind, Lex)| {
                        let (kind, l2) = lex_template_57243;
                        let l3 = {
                            let mut this: Lex = l2.clone();
                            this.last_ws = true;
                            this
                        };
                        prism_rtl::Turn::Finished(push_tok(&l3, &kind, &l.pos, &l3.pos))
                    })
                }
            } else {
                prism_rtl::Turn::Finished(lex_err(&l0, &l0.pos, &l0.pos, &Text::from(format!("`{}` is followed by a language tag, `<rust>`", &kw))))
            }
        })
    }
}

/// `Start MaybeTemplate, x`: what the function value is when passed to `@Run`.
pub fn start_maybe_template(l0: Lex, kw: Text) -> Rc<dyn prism_rtl::Job<Lex>> {
    Rc::new(MaybeTemplate { l0, kw })
}

/// ```prism
/// TemplateTagAhead: unbounded fn Lex -> Text
/// ```
pub fn template_tag_ahead(l: &Lex) -> Text {
    let (name, _) = lex_ident(&bump(l));
    let after_ = peek_at(l, &(&len_text(&name) + &Nat::from(1u32)));
    if (((&peek(l) == &Text::lit("<")) && (&name != &Text::lit(""))) && is_lower(&head(&name))) && (&after_ == &Text::lit(">")) {
        name.clone()
    } else {
        Text::lit("")
    }
}

/// The step machine of `TemplateTagAhead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateTagAhead: unbounded fn Lex -> Text
/// ```
pub struct TemplateTagAhead {
    pub l: Lex,
}

impl prism_rtl::Job<Text> for TemplateTagAhead {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let l = &self.l;
        let l = l.clone();
        call_then(start_lex_ident(bump(&l)), move |lex_ident_57634: (Text, Lex)| {
            let (name, _) = lex_ident_57634;
            let after_ = peek_at(&l, &(&len_text(&name) + &Nat::from(1u32)));
            if (((&peek(&l) == &Text::lit("<")) && (&name != &Text::lit(""))) && is_lower(&head(&name))) && (&after_ == &Text::lit(">")) {
                prism_rtl::Turn::Finished(name.clone())
            } else {
                prism_rtl::Turn::Finished(Text::lit(""))
            }
        })
    }
}

/// `Start TemplateTagAhead, x`: what the function value is when passed to `@Run`.
pub fn start_template_tag_ahead(l: Lex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TemplateTagAhead { l })
}

/// ```prism
/// LexTemplate: unbounded fn Lex, Text, Nat -> ((TokKind, Lex))
/// ```
pub fn lex_template(l0: &Lex, keyword: &Text, start: &Nat) -> (TokKind, Lex) {
    let lang = template_tag_ahead(l0);
    let l1 = forward(l0, &(&len_text(&lang) + &Nat::from(2u32)));
    let delims = if (&lang == &Text::lit("markdown")) || (&lang == &Text::lit("html")) {
        Text::lit("single")
    } else {
        Text::lit("double")
    };
    let ends_line = (&peek(&l1) == &Text::lit("\n")) || starts_with(&l1, &Text::lit("\r\n"));
    let skip = if &peek(&l1) == &Text::lit("\r") { Nat::from(2u32) } else { Nat::from(1u32) };
    let l2 = if ends_line { forward(&l1, &skip) } else { l1.clone() };
    let (parts, l3) = template_body(&l2, &Text::from(format!("</{}>", &lang)), &delims, &(keyword == &Text::lit("Raw")), &!ends_line, start);
    let kind = TokKind::KTemplate(TemplateTok { keyword: keyword.clone(), lang: lang.clone(), delims: delims.clone(), parts: parts.clone() });
    (kind.clone(), l3.clone())
}

/// The step machine of `LexTemplate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexTemplate: unbounded fn Lex, Text, Nat -> ((TokKind, Lex))
/// ```
pub struct LexTemplate {
    pub l0: Lex,
    pub keyword: Text,
    pub start: Nat,
}

impl prism_rtl::Job<(TokKind, Lex)> for LexTemplate {
    fn cycle(&self) -> prism_rtl::Turn<(TokKind, Lex)> {
        let l0 = &self.l0;
        let keyword = &self.keyword;
        let start = &self.start;
        let keyword = keyword.clone();
        let l0 = l0.clone();
        let start = start.clone();
        call_then(start_template_tag_ahead(l0.clone()), move |template_tag_ahead_57967: Text| {
            let lang = template_tag_ahead_57967;
            let l1 = forward(&l0, &(&len_text(&lang) + &Nat::from(2u32)));
            let delims = if (&lang == &Text::lit("markdown")) || (&lang == &Text::lit("html")) {
                Text::lit("single")
            } else {
                Text::lit("double")
            };
            let ends_line = (&peek(&l1) == &Text::lit("\n")) || starts_with(&l1, &Text::lit("\r\n"));
            let skip = if &peek(&l1) == &Text::lit("\r") { Nat::from(2u32) } else { Nat::from(1u32) };
            let l2 = if ends_line { forward(&l1, &skip) } else { l1.clone() };
            call_then(start_template_body(l2.clone(), Text::from(format!("</{}>", &lang)), delims.clone(), &keyword == &Text::lit("Raw"), !ends_line, start.clone()), move |template_body_58381: (Array<TPartTok>, Lex)| {
                let (parts, l3) = template_body_58381;
                let kind = TokKind::KTemplate(TemplateTok { keyword: keyword.clone(), lang: lang.clone(), delims: delims.clone(), parts: parts.clone() });
                prism_rtl::Turn::Finished((kind.clone(), l3.clone()))
            })
        })
    }
}

/// `Start LexTemplate, x`: what the function value is when passed to `@Run`.
pub fn start_lex_template(l0: Lex, keyword: Text, start: Nat) -> Rc<dyn prism_rtl::Job<(TokKind, Lex)>> {
    Rc::new(LexTemplate { l0, keyword, start })
}

/// ```prism
/// let emptyLine
/// ```
pub fn empty_line() -> RawLine {
    RawLine { items: Array::new(), newline: false, block: false }
}

/// ```prism
/// AddItem: fn RawLine, RawItem -> RawLine
/// ```
pub fn add_item(line: &RawLine, item: &RawItem) -> RawLine {
    let mut this: RawLine = line.clone();
    this.items = add_raw(&this.items, item);
    this
}

/// ```prism
/// AddRaw: fn [RawItem], RawItem -> [RawItem]
/// ```
pub fn add_raw(items: &Array<RawItem>, raw_item1: &RawItem) -> Array<RawItem> {
    match raw_item1 {
        RawItem::RiText(t) => match last(items) {
            Some(RawItem::RiText(s)) => push(&pop(items), &RawItem::RiText(Text::from(format!("{}{}", &s, t)))),
            _ => push(items, &RawItem::RiText(t.clone())),
        },
        item => push(items, item),
    }
}

/// ```prism
/// OnlyWhitespace: fn RawLine -> Bool
/// ```
pub fn only_whitespace(line: &RawLine) -> bool {
    fold(&line.items, &true, &(|ok: &bool, it: &RawItem| *ok && is_blank_text(it)))
}

/// ```prism
/// IsBlankText: fn RawItem -> Bool
/// ```
pub fn is_blank_text(raw_item0: &RawItem) -> bool {
    match raw_item0 {
        RawItem::RiText(s) => all_chars(s, &(Rc::new(move |p0: Text| once_job(move || {
            let c = p0;
            prism_rtl::Turn::Finished((&c == &Text::lit(" ")) || (&c == &Text::lit("\r")))
        })) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>)),
        _ => false,
    }
}

/// ```prism
/// TextLen: fn RawLine -> Nat
/// ```
pub fn text_len(line: &RawLine) -> Nat {
    fold(&line.items, &Nat::from(0u32), &(|n: &Nat, it: &RawItem| n + &text_len_of(it)))
}

/// ```prism
/// TextLenOf: fn RawItem -> Nat
/// ```
pub fn text_len_of(raw_item0: &RawItem) -> Nat {
    match raw_item0 {
        RawItem::RiText(s) => len_text(s),
        _ => Nat::from(0u32),
    }
}

/// ```prism
/// TemplateBody: unbounded fn Lex, Text, Text, Bool, Bool, Nat -> (([TPartTok], Lex))
/// ```
pub fn template_body(l0: &Lex, close: &Text, delims: &Text, is_raw: &bool, first_continues: &bool, open_start: &Nat) -> (Array<TPartTok>, Lex) {
    let open = if delims == &Text::lit("double") { Text::lit("{{") } else { Text::lit("{") };
    let how = TplHow { close: close.clone(), delims: delims.clone(), open: open.clone(), is_raw: *is_raw, first_continues: *first_continues };
    let start = TplRead { l: l0.clone(), lines: Array::new(), cur: empty_line(), closing_col: None, closed: false, at_line_start: !*first_continues, going: true };
    let r = {
        let mut this: TplRead = start.clone();
        while this.going {
            this = template_step(&this, &how);
        }
        this
    };
    let l1 = if r.closed {
        r.l.clone()
    } else {
        lex_err(&r.l, open_start, &r.l.pos, &Text::from(format!("a template never closes: expected `{}`", close)))
    };
    finish_template_lines(&l1, &push(&r.lines, &r.cur), &or(&r.closing_col, &Nat::from(0u32)), first_continues)
}

/// The step machine of `TemplateBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateBody: unbounded fn Lex, Text, Text, Bool, Bool, Nat -> (([TPartTok], Lex))
/// ```
pub struct TemplateBody {
    pub l0: Lex,
    pub close: Text,
    pub delims: Text,
    pub is_raw: bool,
    pub first_continues: bool,
    pub open_start: Nat,
}

impl prism_rtl::Job<(Array<TPartTok>, Lex)> for TemplateBody {
    fn cycle(&self) -> prism_rtl::Turn<(Array<TPartTok>, Lex)> {
        let l0 = &self.l0;
        let close = &self.close;
        let delims = &self.delims;
        let is_raw = &self.is_raw;
        let first_continues = &self.first_continues;
        let open_start = &self.open_start;
        let open = if delims == &Text::lit("double") { Text::lit("{{") } else { Text::lit("{") };
        let how = TplHow { close: close.clone(), delims: delims.clone(), open: open.clone(), is_raw: *is_raw, first_continues: *first_continues };
        let start = TplRead { l: l0.clone(), lines: Array::new(), cur: empty_line(), closing_col: None, closed: false, at_line_start: !*first_continues, going: true };
        let mut this: TplRead = start.clone();
        let close = close.clone();
        let first_continues = *first_continues;
        let open_start = open_start.clone();
        call_then(loop_job((this,), {
            let how = how.clone();
            move |(mut this,): (TplRead,)| if this.going {
                {
                    this = template_step(&this, &how);
                    Ok((this,))
                }
            } else {
                Err((this,))
            }
        }), move |(mut this,): (TplRead,)| {
            let r = this;
            let l1 = if r.closed {
                r.l.clone()
            } else {
                lex_err(&r.l, &open_start, &r.l.pos, &Text::from(format!("a template never closes: expected `{}`", &close)))
            };
            prism_rtl::Turn::Finished(finish_template_lines(&l1, &push(&r.lines, &r.cur), &or(&r.closing_col, &Nat::from(0u32)), &first_continues))
        })
    }
}

/// `Start TemplateBody, x`: what the function value is when passed to `@Run`.
pub fn start_template_body(l0: Lex, close: Text, delims: Text, is_raw: bool, first_continues: bool, open_start: Nat) -> Rc<dyn prism_rtl::Job<(Array<TPartTok>, Lex)>> {
    Rc::new(TemplateBody { l0, close, delims, is_raw, first_continues, open_start })
}

/// ```prism
/// TemplateStep: unbounded fn TplRead, TplHow -> TplRead
/// ```
pub fn template_step(s: &TplRead, how: &TplHow) -> TplRead {
    let rest_ = rest_of_line(&s.l);
    let c = peek(&s.l);
    if (s.at_line_start && !how.is_raw) && (&trim(&rest_) == &how.open) {
        brace_block_line(s, &rest_, how)
    } else {
        if starts_with(&s.l, &how.close) {
            close_template(s, how)
        } else {
            if &c == &Text::lit("") {
                {
                    let mut this: TplRead = s.clone();
                    this.at_line_start = false;
                    this.going = false;
                    this
                }
            } else {
                if &c == &Text::lit("\n") {
                    {
                        let mut this: TplRead = s.clone();
                        this.l = bump(&this.l);
                        this.cur.newline = true;
                        this.lines = push(&this.lines, &this.cur);
                        this.cur = empty_line();
                        this.at_line_start = true;
                        this
                    }
                } else {
                    {
                        let (item, l2) = template_item(&s.l, how);
                        {
                            let mut this: TplRead = s.clone();
                            this.at_line_start = false;
                            this.l = l2.clone();
                            this.cur = add_item(&this.cur, &item);
                            this
                        }
                    }
                }
            }
        }
    }
}

/// The step machine of `TemplateStep`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateStep: unbounded fn TplRead, TplHow -> TplRead
/// ```
pub struct TemplateStep {
    pub s: TplRead,
    pub how: TplHow,
}

impl prism_rtl::Job<TplRead> for TemplateStep {
    fn cycle(&self) -> prism_rtl::Turn<TplRead> {
        let s = &self.s;
        let how = &self.how;
        let how = how.clone();
        let s = s.clone();
        call_then(start_rest_of_line(s.l.clone()), move |rest_of_line_61241: Text| {
            let rest_ = rest_of_line_61241;
            let c = peek(&s.l);
            if (s.at_line_start && !how.is_raw) && (&trim(&rest_) == &how.open) {
                prism_rtl::Turn::More(Rc::new(BraceBlockLine { s: s.clone(), rest_: rest_.clone(), how: how.clone() }))
            } else {
                if starts_with(&s.l, &how.close) {
                    prism_rtl::Turn::Finished(close_template(&s, &how))
                } else {
                    if &c == &Text::lit("") {
                        prism_rtl::Turn::Finished({
                            let mut this: TplRead = s.clone();
                            this.at_line_start = false;
                            this.going = false;
                            this
                        })
                    } else {
                        if &c == &Text::lit("\n") {
                            prism_rtl::Turn::Finished({
                                let mut this: TplRead = s.clone();
                                this.l = bump(&this.l);
                                this.cur.newline = true;
                                this.lines = push(&this.lines, &this.cur);
                                this.cur = empty_line();
                                this.at_line_start = true;
                                this
                            })
                        } else {
                            call_then(start_template_item(s.l.clone(), how.clone()), move |template_item_61848: (RawItem, Lex)| {
                                let (item, l2) = template_item_61848;
                                prism_rtl::Turn::Finished({
                                    let mut this: TplRead = s.clone();
                                    this.at_line_start = false;
                                    this.l = l2.clone();
                                    this.cur = add_item(&this.cur, &item);
                                    this
                                })
                            })
                        }
                    }
                }
            }
        })
    }
}

/// `Start TemplateStep, x`: what the function value is when passed to `@Run`.
pub fn start_template_step(s: TplRead, how: TplHow) -> Rc<dyn prism_rtl::Job<TplRead>> {
    Rc::new(TemplateStep { s, how })
}

/// ```prism
/// BraceBlockLine: unbounded fn TplRead, Text, TplHow -> TplRead
/// ```
pub fn brace_block_line(s: &TplRead, rest_: &Text, how: &TplHow) -> TplRead {
    let bs = s.l.pos.clone();
    let past = forward(&s.l, &len_text(rest_));
    let at_ = if &peek(&past) == &Text::lit("\n") { bump(&past) } else { past.clone() };
    let (toks, l2) = nested(&at_, &Mode::MBrace(how.delims.clone()));
    let line = RawLine { items: Array::from(vec![RawItem::RiBlock(toks.clone(), crate::syntax::Range { start: bs.clone(), end: l2.pos.clone() })]), newline: false, block: true };
    let mut this: TplRead = s.clone();
    this.lines = push(&this.lines, &line);
    this.l = l2.clone();
    this
}

/// The step machine of `BraceBlockLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BraceBlockLine: unbounded fn TplRead, Text, TplHow -> TplRead
/// ```
pub struct BraceBlockLine {
    pub s: TplRead,
    pub rest_: Text,
    pub how: TplHow,
}

impl prism_rtl::Job<TplRead> for BraceBlockLine {
    fn cycle(&self) -> prism_rtl::Turn<TplRead> {
        let s = &self.s;
        let rest_ = &self.rest_;
        let how = &self.how;
        let bs = s.l.pos.clone();
        let past = forward(&s.l, &len_text(rest_));
        let at_ = if &peek(&past) == &Text::lit("\n") { bump(&past) } else { past.clone() };
        let how = how.clone();
        let s = s.clone();
        call_then(start_nested(at_.clone(), Mode::MBrace(how.delims.clone())), move |nested_62226: (Array<Tok>, Lex)| {
            let (toks, l2) = nested_62226;
            let line = RawLine { items: Array::from(vec![RawItem::RiBlock(toks.clone(), crate::syntax::Range { start: bs.clone(), end: l2.pos.clone() })]), newline: false, block: true };
            prism_rtl::Turn::Finished({
                let mut this: TplRead = s.clone();
                this.lines = push(&this.lines, &line);
                this.l = l2.clone();
                this
            })
        })
    }
}

/// `Start BraceBlockLine, x`: what the function value is when passed to `@Run`.
pub fn start_brace_block_line(s: TplRead, rest_: Text, how: TplHow) -> Rc<dyn prism_rtl::Job<TplRead>> {
    Rc::new(BraceBlockLine { s, rest_, how })
}

/// ```prism
/// CloseTemplate: fn TplRead, TplHow -> TplRead
/// ```
pub fn close_template(s: &TplRead, how: &TplHow) -> TplRead {
    let mut this: TplRead = s.clone();
    this.at_line_start = false;
    if only_whitespace(&this.cur) && ((&len(&this.lines) > &Nat::from(0u32)) || !how.first_continues) {
        this.closing_col = Some(text_len(&this.cur));
        this.cur.items = Array::new();
    }
    this.l = forward(&this.l, &len_text(&how.close));
    this.closed = true;
    this.going = false;
    this
}

/// ```prism
/// TemplateItem: unbounded fn Lex, TplHow -> ((RawItem, Lex))
/// ```
pub fn template_item(l: &Lex, how: &TplHow) -> (RawItem, Lex) {
    let live = !how.is_raw;
    if (live && (&how.delims == &Text::lit("double"))) && starts_with(l, &Text::lit("\\{{")) {
        (RawItem::RiText(Text::lit("{{")), forward(l, &Nat::from(3u32)))
    } else {
        if (live && (&how.delims == &Text::lit("single"))) && starts_with(l, &Text::lit("\\{")) {
            (RawItem::RiText(Text::lit("{")), forward(l, &Nat::from(2u32)))
        } else {
            if live && starts_with(l, &how.open) {
                {
                    let ps = l.pos.clone();
                    let (toks, l2) = nested(&forward(l, &len_text(&how.open)), &Mode::MPlaceholder(how.delims.clone()));
                    let item = RawItem::RiPlaceholder(toks.clone(), crate::syntax::Range { start: ps.clone(), end: l2.pos.clone() });
                    (item.clone(), l2.clone())
                }
            } else {
                if (live && starts_with(l, &Text::lit("<@"))) && is_upper(&peek_at(l, &Nat::from(2u32))) {
                    template_call(l, &how.delims, &how.open)
                } else {
                    (RawItem::RiText(peek(l)), bump(l))
                }
            }
        }
    }
}

/// The step machine of `TemplateItem`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateItem: unbounded fn Lex, TplHow -> ((RawItem, Lex))
/// ```
pub struct TemplateItem {
    pub l: Lex,
    pub how: TplHow,
}

impl prism_rtl::Job<(RawItem, Lex)> for TemplateItem {
    fn cycle(&self) -> prism_rtl::Turn<(RawItem, Lex)> {
        let l = &self.l;
        let how = &self.how;
        let live = !how.is_raw;
        if (live && (&how.delims == &Text::lit("double"))) && starts_with(l, &Text::lit("\\{{")) {
            prism_rtl::Turn::Finished((RawItem::RiText(Text::lit("{{")), forward(l, &Nat::from(3u32))))
        } else {
            if (live && (&how.delims == &Text::lit("single"))) && starts_with(l, &Text::lit("\\{")) {
                prism_rtl::Turn::Finished((RawItem::RiText(Text::lit("{")), forward(l, &Nat::from(2u32))))
            } else {
                if live && starts_with(l, &how.open) {
                    {
                        let ps = l.pos.clone();
                        let how = how.clone();
                        let l = l.clone();
                        call_then(start_nested(forward(&l, &len_text(&how.open)), Mode::MPlaceholder(how.delims.clone())), move |nested_63472: (Array<Tok>, Lex)| {
                            let (toks, l2) = nested_63472;
                            let item = RawItem::RiPlaceholder(toks.clone(), crate::syntax::Range { start: ps.clone(), end: l2.pos.clone() });
                            prism_rtl::Turn::Finished((item.clone(), l2.clone()))
                        })
                    }
                } else {
                    if (live && starts_with(l, &Text::lit("<@"))) && is_upper(&peek_at(l, &Nat::from(2u32))) {
                        prism_rtl::Turn::More(Rc::new(TemplateCall { l0: l.clone(), delims: how.delims.clone(), open: how.open.clone() }))
                    } else {
                        prism_rtl::Turn::Finished((RawItem::RiText(peek(l)), bump(l)))
                    }
                }
            }
        }
    }
}

/// `Start TemplateItem, x`: what the function value is when passed to `@Run`.
pub fn start_template_item(l: Lex, how: TplHow) -> Rc<dyn prism_rtl::Job<(RawItem, Lex)>> {
    Rc::new(TemplateItem { l, how })
}

/// ```prism
/// TemplateCall: unbounded fn Lex, Text, Text -> ((RawItem, Lex))
/// ```
pub fn template_call(l0: &Lex, delims: &Text, open: &Text) -> (RawItem, Lex) {
    let start = l0.pos.clone();
    let (sigils, _, l1) = read_sigils(&bump(l0));
    let (path_, l2) = lex_qualified_path(&l1);
    let name = NameTok { sigils: sigils.clone(), path_: path_.clone(), case: NameCase::CaseUpper };
    let close = Text::from(format!("</{}{}>", &sigils, &join(&path_, &Text::lit("."))));
    let r = {
        let mut this: CallRead = CallRead { l: l2.clone(), attrs: Array::new(), body: None, going: true };
        while this.going {
            this = call_step(&this, &start, &close, delims, open);
        }
        this
    };
    let item = RawItem::RiCall(name.clone(), r.attrs.clone(), r.body.clone(), crate::syntax::Range { start: start.clone(), end: r.l.pos.clone() });
    (item.clone(), r.l.clone())
}

/// The step machine of `TemplateCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateCall: unbounded fn Lex, Text, Text -> ((RawItem, Lex))
/// ```
pub struct TemplateCall {
    pub l0: Lex,
    pub delims: Text,
    pub open: Text,
}

impl prism_rtl::Job<(RawItem, Lex)> for TemplateCall {
    fn cycle(&self) -> prism_rtl::Turn<(RawItem, Lex)> {
        let l0 = &self.l0;
        let delims = &self.delims;
        let open = &self.open;
        let start = l0.pos.clone();
        let delims = delims.clone();
        let l0 = l0.clone();
        let open = open.clone();
        call_then(start_read_sigils(bump(&l0)), move |read_sigils_64204: (Text, bool, Lex)| {
            let (sigils, _, l1) = read_sigils_64204;
            call_then(start_lex_qualified_path(l1.clone()), move |lex_qualified_path_64248: (Array<Text>, Lex)| {
                let (path_, l2) = lex_qualified_path_64248;
                let name = NameTok { sigils: sigils.clone(), path_: path_.clone(), case: NameCase::CaseUpper };
                let close = Text::from(format!("</{}{}>", &sigils, &join(&path_, &Text::lit("."))));
                let mut this: CallRead = CallRead { l: l2.clone(), attrs: Array::new(), body: None, going: true };
                let name = name.clone();
                let start = start.clone();
                call_then(loop_job((this,), {
                    let close = close.clone();
                    let delims = delims.clone();
                    let open = open.clone();
                    let start = start.clone();
                    move |(mut this,): (CallRead,)| if this.going {
                        {
                            this = call_step(&this, &start, &close, &delims, &open);
                            Ok((this,))
                        }
                    } else {
                        Err((this,))
                    }
                }), move |(mut this,): (CallRead,)| {
                    let r = this;
                    let item = RawItem::RiCall(name.clone(), r.attrs.clone(), r.body.clone(), crate::syntax::Range { start: start.clone(), end: r.l.pos.clone() });
                    prism_rtl::Turn::Finished((item.clone(), r.l.clone()))
                })
            })
        })
    }
}

/// `Start TemplateCall, x`: what the function value is when passed to `@Run`.
pub fn start_template_call(l0: Lex, delims: Text, open: Text) -> Rc<dyn prism_rtl::Job<(RawItem, Lex)>> {
    Rc::new(TemplateCall { l0, delims, open })
}

/// ```prism
/// CallStep: unbounded fn CallRead, Nat, Text, Text, Text -> CallRead
/// ```
pub fn call_step(s0: &CallRead, start: &Nat, close: &Text, delims: &Text, open: &Text) -> CallRead {
    let l = {
        let mut this: Lex = s0.l.clone();
        while contains(&Text::lit(" \n\r"), &peek(&this)) {
            this.pos = &this.pos + &Nat::from(1u32);
        }
        this
    };
    let s = {
        let mut this: CallRead = s0.clone();
        this.l = l.clone();
        this
    };
    let at_ = l.pos.clone();
    if starts_with(&l, &Text::lit("/>")) {
        {
            let mut this: CallRead = s.clone();
            this.l = forward(&l, &Nat::from(2u32));
            this.going = false;
            this
        }
    } else {
        if &peek(&l) == &Text::lit(">") {
            {
                let past = bump(&l);
                let continues = &peek(&past) != &Text::lit("\n");
                let from = if continues { past.clone() } else { bump(&past) };
                let (parts, l3) = template_body(&from, close, delims, &false, &continues, start);
                {
                    let mut this: CallRead = s.clone();
                    this.body = Some(parts.clone());
                    this.l = l3.clone();
                    this.going = false;
                    this
                }
            }
        } else {
            if !is_ident_start(&peek(&l)) {
                {
                    let mut this: CallRead = s.clone();
                    this.l = lex_err(&l, &at_, &(&at_ + &Nat::from(1u32)), &Text::lit("expected an attribute `name=value`, `/>` or `>` in a template call"));
                    this.going = false;
                    this
                }
            } else {
                {
                    let (aname, l3) = lex_ident(&l);
                    if &peek(&l3) != &Text::lit("=") {
                        {
                            let mut this: CallRead = s.clone();
                            this.l = lex_err(&l3, &at_, &l3.pos, &Text::lit("an attribute is `name=value`"));
                            this
                        }
                    } else {
                        {
                            let (tokens, l4) = attr_value(&bump(&l3), delims, open);
                            {
                                let mut this: CallRead = s.clone();
                                this.attrs = push(&this.attrs, &AttrTok { name: aname.clone(), tokens: tokens.clone(), span: crate::syntax::Range { start: at_.clone(), end: l4.pos.clone() } });
                                this.l = l4.clone();
                                this
                            }
                        }
                    }
                }
            }
        }
    }
}

/// The step machine of `CallStep`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallStep: unbounded fn CallRead, Nat, Text, Text, Text -> CallRead
/// ```
pub struct CallStep {
    pub s0: CallRead,
    pub start: Nat,
    pub close: Text,
    pub delims: Text,
    pub open: Text,
}

impl prism_rtl::Job<CallRead> for CallStep {
    fn cycle(&self) -> prism_rtl::Turn<CallRead> {
        let s0 = &self.s0;
        let start = &self.start;
        let close = &self.close;
        let delims = &self.delims;
        let open = &self.open;
        let mut this: Lex = s0.l.clone();
        let close = close.clone();
        let delims = delims.clone();
        let open = open.clone();
        let s0 = s0.clone();
        let start = start.clone();
        call_then(loop_job((this,), move |(mut this,): (Lex,)| if contains(&Text::lit(" \n\r"), &peek(&this)) {
            {
                this.pos = &this.pos + &Nat::from(1u32);
                Ok((this,))
            }
        } else {
            Err((this,))
        }), move |(mut this,): (Lex,)| {
            let l = this;
            let s = {
                let mut this: CallRead = s0.clone();
                this.l = l.clone();
                this
            };
            let at_ = l.pos.clone();
            if starts_with(&l, &Text::lit("/>")) {
                prism_rtl::Turn::Finished({
                    let mut this: CallRead = s.clone();
                    this.l = forward(&l, &Nat::from(2u32));
                    this.going = false;
                    this
                })
            } else {
                if &peek(&l) == &Text::lit(">") {
                    {
                        let past = bump(&l);
                        let continues = &peek(&past) != &Text::lit("\n");
                        let from = if continues { past.clone() } else { bump(&past) };
                        call_then(start_template_body(from.clone(), close.clone(), delims.clone(), false, continues, start.clone()), move |template_body_65183: (Array<TPartTok>, Lex)| {
                            let (parts, l3) = template_body_65183;
                            prism_rtl::Turn::Finished({
                                let mut this: CallRead = s.clone();
                                this.body = Some(parts.clone());
                                this.l = l3.clone();
                                this.going = false;
                                this
                            })
                        })
                    }
                } else {
                    if !is_ident_start(&peek(&l)) {
                        prism_rtl::Turn::Finished({
                            let mut this: CallRead = s.clone();
                            this.l = lex_err(&l, &at_, &(&at_ + &Nat::from(1u32)), &Text::lit("expected an attribute `name=value`, `/>` or `>` in a template call"));
                            this.going = false;
                            this
                        })
                    } else {
                        call_then(start_lex_ident(l.clone()), move |lex_ident_65582: (Text, Lex)| {
                            let (aname, l3) = lex_ident_65582;
                            if &peek(&l3) != &Text::lit("=") {
                                prism_rtl::Turn::Finished({
                                    let mut this: CallRead = s.clone();
                                    this.l = lex_err(&l3, &at_, &l3.pos, &Text::lit("an attribute is `name=value`"));
                                    this
                                })
                            } else {
                                {
                                    let (tokens, l4) = attr_value(&bump(&l3), &delims, &open);
                                    prism_rtl::Turn::Finished({
                                        let mut this: CallRead = s.clone();
                                        this.attrs = push(&this.attrs, &AttrTok { name: aname.clone(), tokens: tokens.clone(), span: crate::syntax::Range { start: at_.clone(), end: l4.pos.clone() } });
                                        this.l = l4.clone();
                                        this
                                    })
                                }
                            }
                        })
                    }
                }
            }
        })
    }
}

/// `Start CallStep, x`: what the function value is when passed to `@Run`.
pub fn start_call_step(s0: CallRead, start: Nat, close: Text, delims: Text, open: Text) -> Rc<dyn prism_rtl::Job<CallRead>> {
    Rc::new(CallStep { s0, start, close, delims, open })
}

/// ```prism
/// AttrValue: unbounded fn Lex, Text, Text -> (([Tok], Lex))
/// ```
pub fn attr_value(l: &Lex, delims: &Text, open: &Text) -> (Array<Tok>, Lex) {
    if starts_with(l, open) {
        nested(&forward(l, &len_text(open)), &Mode::MPlaceholder(delims.clone()))
    } else {
        if &peek(l) == &Text::lit("\"") {
            {
                let (text, l2) = lex_text(l);
                let tok = Tok { kind: TokKind::KText(Text::lit(""), text.clone()), span: crate::syntax::Range { start: l.pos.clone(), end: l2.pos.clone() }, touches: false, line_start: false };
                (Array::from(vec![tok.clone()]), l2.clone())
            }
        } else {
            (Array::new(), lex_err(l, &l.pos, &l.pos, &Text::from(format!("an attribute's value is a placeholder `{}...` or a text literal", open))))
        }
    }
}

/// ```prism
/// FinishTemplateLines: fn Lex, [RawLine], Nat, Bool -> (([TPartTok], Lex))
/// ```
pub fn finish_template_lines(l0: &Lex, lines: &Array<RawLine>, strip: &Nat, first_continues: &bool) -> (Array<TPartTok>, Lex) {
    let mut this: (Array<TPartTok>, Lex) = (Array::new(), l0.clone());
    let mut l: Lex = l0.clone();
    let mut parts: Array<TPartTok> = Array::new();
    for (i66935, v66935) in lines.clone().into_iter().enumerate() {
        let k66935 = nat_of(i66935);
        let line = v66935.clone();
        if line.block {
            parts = append(&parts, &block_parts(&line.items));
        } else {
            let first_ = (&k66935 == &Nat::from(0u32)) && *first_continues;
            let (items, l2) = if !first_ && (strip > &Nat::from(0u32)) {
                strip_line(&line, strip, &l)
            } else {
                (line.items.clone(), l.clone())
            };
            l = l2.clone();
            let non_blank = fold(&items, &Array::new(), &(|acc: &Array<RawItem>, it: &RawItem| if is_blank_or_empty(it) { acc.clone() } else { push(acc, it) }));
            let alone = ((!first_ && line.newline) && (&len(&non_blank) == &Nat::from(1u32))) && is_placeholder_item(&or(&index(&non_blank, &Nat::from(0u32)), &RawItem::RiText(Text::lit(""))));
            if alone {
                parts = push(&parts, &alone_placeholder(&items));
            } else {
                parts = fold(&items, &parts, &push_part);
                if line.newline {
                    parts = push_part(&parts, &RawItem::RiText(Text::lit("\n")));
                }
            }
        }
    }
    this = (parts.clone(), l.clone());
    this
}

/// ```prism
/// BlockParts: fn [RawItem] -> [TPartTok]
/// ```
pub fn block_parts(items: &Array<RawItem>) -> Array<TPartTok> {
    fold(items, &Array::new(), &(|acc: &Array<TPartTok>, it: &RawItem| match it {
        RawItem::RiBlock(tokens, span) => push(acc, &TPartTok::TptBlock(tokens.clone(), span.clone())),
        _ => acc.clone(),
    }))
}

/// ```prism
/// StripLine: fn RawLine, Nat, Lex -> (([RawItem], Lex))
/// ```
pub fn strip_line(line: &RawLine, strip: &Nat, l: &Lex) -> (Array<RawItem>, Lex) {
    let blank = only_whitespace(line);
    let n = match index(&line.items, &Nat::from(0u32)) {
        Some(RawItem::RiText(s)) => leading_in(&s, &Text::lit(" ")),
        _ => Nat::from(0u32),
    };
    let items = match index(&line.items, &Nat::from(0u32)) {
        Some(RawItem::RiText(s)) => {
            let rest_ = match cursor_at(&s, &min(&n, strip)) {
                Some(c) => after(&c),
                None => s.clone(),
            };
            append(&Array::from(vec![RawItem::RiText(rest_.clone())]), &drop(&line.items, &Nat::from(1u32)))
        },
        _ => line.items.clone(),
    };
    let l2 = if (&n < strip) && !blank {
        lex_err(l, &first_item_span(&items).start, &first_item_span(&items).end, &Text::lit("a template line is indented less than its closing tag (Q-CT3)"))
    } else {
        l.clone()
    };
    let kept = if &index(&items, &Nat::from(0u32)) == &Some(RawItem::RiText(Text::lit(""))) {
        drop(&items, &Nat::from(1u32))
    } else {
        items.clone()
    };
    (kept.clone(), l2.clone())
}

/// ```prism
/// IsBlankOrEmpty: fn RawItem -> Bool
/// ```
pub fn is_blank_or_empty(raw_item0: &RawItem) -> bool {
    match raw_item0 {
        RawItem::RiText(s) => &trim(s) == &Text::lit(""),
        _ => false,
    }
}

/// ```prism
/// IsPlaceholderItem: fn RawItem -> Bool
/// ```
pub fn is_placeholder_item(raw_item0: &RawItem) -> bool {
    match raw_item0 {
        RawItem::RiPlaceholder(_, _) => true,
        _ => false,
    }
}

/// ```prism
/// FirstItemSpan: fn [RawItem] -> Range
/// ```
pub fn first_item_span(items: &Array<RawItem>) -> crate::syntax::Range {
    or(&fold(items, &None, &(|found_opt: &Option<crate::syntax::Range>, it: &RawItem| if found_opt != &None { found_opt.clone() } else { item_span(it) })), &crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) })
}

/// ```prism
/// ?ItemSpan: fn RawItem -> ?Range
/// ```
pub fn item_span(raw_item0: &RawItem) -> Option<crate::syntax::Range> {
    match raw_item0 {
        RawItem::RiPlaceholder(_, span) => Some(span.clone()),
        RawItem::RiBlock(_, span) => Some(span.clone()),
        RawItem::RiCall(_, _, _, span) => Some(span.clone()),
        _ => None,
    }
}

/// ```prism
/// AlonePlaceholder: fn [RawItem] -> TPartTok
/// ```
pub fn alone_placeholder(items: &Array<RawItem>) -> TPartTok {
    let (_, part) = fold(items, &(Nat::from(0u32), TPartTok::TptText(Text::lit(""))), &(|(c, p_): &(Nat, TPartTok), it: &RawItem| alone_step(c, p_, it)));
    part.clone()
}

/// ```prism
/// AloneStep: fn Nat, TPartTok, RawItem -> ((Nat, TPartTok))
/// ```
pub fn alone_step(c: &Nat, tpart_tok1: &TPartTok, raw_item2: &RawItem) -> (Nat, TPartTok) {
    match (tpart_tok1, raw_item2) {
        (TPartTok::TptText(c0_1_0), RawItem::RiText(s)) if (c0_1_0 == &Text::lit("")) => if c == &Nat::from(0u32) {
            (leading_in(s, &Text::lit(" ")), TPartTok::TptText(Text::lit("")))
        } else {
            (c.clone(), TPartTok::TptText(Text::lit("")))
        },
        (TPartTok::TptText(c1_1_0), RawItem::RiPlaceholder(tokens, span)) if (c1_1_0 == &Text::lit("")) => (c.clone(), TPartTok::TptPlaceholder(tokens.clone(), Some(c.clone()), span.clone())),
        (p_, _) => (c.clone(), p_.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// PushPart: fn [TPartTok], RawItem -> [TPartTok]
/// ```
pub fn push_part(parts: &Array<TPartTok>, raw_item1: &RawItem) -> Array<TPartTok> {
    match raw_item1 {
        RawItem::RiText(c0_1_0) if (c0_1_0 == &Text::lit("")) => parts.clone(),
        RawItem::RiText(t) => match last(parts) {
            Some(TPartTok::TptText(s)) => push(&pop(parts), &TPartTok::TptText(Text::from(format!("{}{}", &s, t)))),
            _ => push(parts, &TPartTok::TptText(t.clone())),
        },
        RawItem::RiPlaceholder(tokens, span) => push(parts, &TPartTok::TptPlaceholder(tokens.clone(), None, span.clone())),
        RawItem::RiBlock(tokens, span) => push(parts, &TPartTok::TptBlock(tokens.clone(), span.clone())),
        RawItem::RiCall(name, attrs, body_opt, span) => push(parts, &TPartTok::TptCall(name.clone(), attrs.clone(), body_opt.clone(), span.clone())),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// RenderTokens: fn [Tok] -> Text
/// ```
pub fn render_tokens(tokens: &Array<Tok>) -> Text {
    let (out, _) = fold(tokens, &(Text::lit(""), None), &(|(acc, prev_opt): &(Text, Option<Tok>), t: &Tok| render_step(acc, prev_opt, t)));
    Text::from(format!("{}\n", &out))
}

/// ```prism
/// RenderStep: fn Text, ?Tok, Tok -> ((Text, ?Tok))
/// ```
pub fn render_step(acc: &Text, prev_opt: &Option<Tok>, t: &Tok) -> (Text, Option<Tok>) {
    let gap = match prev_opt {
        None => Text::lit(""),
        Some(p_) => if is_layout(&t.kind) {
            Text::lit("\n")
        } else {
            if (is_bracket(&p_.kind) && is_bracket(&t.kind)) && t.touches {
                Text::lit("·")
            } else {
                Text::lit(" ")
            }
        },
    };
    if &t.kind == &TokKind::KEof {
        (acc.clone(), Some(t.clone()))
    } else {
        (Text::from(format!("{}{}{}", acc, &gap, &token_text(&t.kind))), Some(t.clone()))
    }
}

/// ```prism
/// IsBracket: fn TokKind -> Bool
/// ```
pub fn is_bracket(tok_kind0: &TokKind) -> bool {
    match tok_kind0 {
        TokKind::KOpen(_, _) => true,
        TokKind::KClose(_) => true,
        _ => false,
    }
}

/// ```prism
/// RenderInner: fn [Tok] -> Text
/// ```
pub fn render_inner(tokens: &Array<Tok>) -> Text {
    join(&split(&trim_end(&trim_newlines(&render_tokens(tokens))), &Text::lit("\n")), &Text::lit(" "))
}

/// ```prism
/// TrimNewlines: fn Text -> Text
/// ```
pub fn trim_newlines(t: &Text) -> Text {
    trim_trailing(t, &Text::lit("\n \t"))
}

/// ```prism
/// TokenText: fn TokKind -> Text
/// ```
pub fn token_text(tok_kind0: &TokKind) -> Text {
    match tok_kind0 {
        TokKind::KName(n) => Text::from(format!("{}{}", &n.sigils, &join(&n.path_, &Text::lit(".")))),
        TokKind::KFamily(p_) => Text::from(format!("{}.*", &join(p_, &Text::lit(".")))),
        TokKind::KTrait(p_) => Text::from(format!("^{}", &join(p_, &Text::lit(".")))),
        TokKind::KKw(w, s) => Text::from(format!("{}{}", s, w)),
        TokKind::KFree(s) => Text::from(format!("free{}", s)),
        TokKind::KLensDot => Text::lit("&."),
        TokKind::KInt(s, t) => Text::from(format!("{}{}", s, t)),
        TokKind::KFloat(s, t) => Text::from(format!("{}{}", s, t)),
        TokKind::KDuration(s, t, u) => Text::from(format!("{}{}{}", s, t, u)),
        TokKind::KChar(s, c) => Text::from(format!("{}{}", s, &debug_char(c))),
        TokKind::KText(s, segs) => Text::from(format!("{}TEXT({})", s, &concat(&each(segs, &seg_text)))),
        TokKind::KTemplate(t) => Text::from(format!("TEMPLATE<{}>({})", &t.lang, &concat(&each(&t.parts, &part_text)))),
        TokKind::KOp(op, true) => Text::from(format!("{}pre", op)),
        TokKind::KOp(op, false) => op.clone(),
        TokKind::KSuffixed(op, ty) => Text::from(format!("{}{}", op, &join(ty, &Text::lit(".")))),
        TokKind::KDot(true) => Text::lit(".pre"),
        TokKind::KDot(false) => Text::lit("."),
        TokKind::KDotDot => Text::lit(".."),
        TokKind::KComma => Text::lit(","),
        TokKind::KColon => Text::lit(":"),
        TokKind::KSemi => Text::lit(";"),
        TokKind::KBackslash => Text::lit("\\"),
        TokKind::KLambdaBar(_) => Text::lit("|"),
        TokKind::KBar => Text::lit("|"),
        TokKind::KLtLt => Text::lit("<<"),
        TokKind::KGtGt => Text::lit(">>"),
        TokKind::KOpen(k, _) => k.clone(),
        TokKind::KClose(k) => close_char(k),
        TokKind::KAbsent => Text::lit("absent"),
        TokKind::KNonEmpty => Text::lit("nonempty"),
        TokKind::KPath(segs) => Text::from(format!("PATH({})", &join(&each(segs, &path_seg_text), &Text::lit("/")))),
        TokKind::KLayOpen => Text::lit("open"),
        TokKind::KLaySep => Text::lit("sep"),
        TokKind::KLayClose => Text::lit("close"),
        TokKind::KEof => Text::lit("eof"),
    }
}

/// ```prism
/// SegText: fn TextSegTok -> Text
/// ```
pub fn seg_text(text_seg_tok0: &TextSegTok) -> Text {
    match text_seg_tok0 {
        TextSegTok::TsPlain(p_) => escape_braces(&escape_debug(p_, &true, &true)),
        TextSegTok::TsPlaceholder(toks, _) => Text::from(format!("{{{}}}", &render_inner(toks))),
    }
}

/// ```prism
/// EscapeBraces: fn Text -> Text
/// ```
pub fn escape_braces(t: &Text) -> Text {
    map_chars(t, &(Rc::new(move |p0: Text| once_job(move || {
        let c = p0;
        if (&c == &Text::lit("{")) || (&c == &Text::lit("}")) {
            prism_rtl::Turn::Finished(Text::from(format!("\\{}", &c)))
        } else {
            prism_rtl::Turn::Finished(c.clone())
        }
    })) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>))
}

/// ```prism
/// PathSegText: fn PathSegTok -> Text
/// ```
pub fn path_seg_text(path_seg_tok0: &PathSegTok) -> Text {
    match path_seg_tok0 {
        PathSegTok::PstNum(n) => Text::from(format!("{}", n)),
        PathSegTok::PstGen(n) => Text::from(format!("#{}", n)),
        PathSegTok::PstKey(toks) => Text::from(format!("[{}]", &render_inner(toks))),
    }
}

/// ```prism
/// PartText: fn TPartTok -> Text
/// ```
pub fn part_text(tpart_tok0: &TPartTok) -> Text {
    match tpart_tok0 {
        TPartTok::TptText(t) => debug_text(t),
        TPartTok::TptPlaceholder(toks, col_opt, _) => Text::from(format!("{{{{{}}}}}{}", &render_inner(toks), &col_text(col_opt))),
        TPartTok::TptBlock(toks, _) => Text::from(format!("BLOCK{{ {} }}", &render_inner(toks))),
        TPartTok::TptCall(name, attrs, body_opt, _) => Text::from(format!("<{}{}{}{}", &name.sigils, &join(&name.path_, &Text::lit(".")), &concat(&each(attrs, &attr_text)), &call_body(name, body_opt))),
    }
}

/// ```prism
/// ColText: fn ?Nat -> Text
/// ```
pub fn col_text(opt0: &Option<Nat>) -> Text {
    match opt0 {
        None => Text::lit(""),
        Some(c) => Text::from(format!("@col{}", c)),
    }
}

/// ```prism
/// AttrText: fn AttrTok -> Text
/// ```
pub fn attr_text(a: &AttrTok) -> Text {
    Text::from(format!(" {}={{{}}}", &a.name, &render_inner(&a.tokens)))
}

/// ```prism
/// CallBody: fn NameTok, ?[TPartTok] -> Text
/// ```
pub fn call_body(name_tok0: &NameTok, opt1: &Option<Array<TPartTok>>) -> Text {
    match (name_tok0, opt1) {
        (_, None) => Text::lit("/>"),
        (name, Some(parts)) => Text::from(format!(">{}</{}{}>", &concat(&each(parts, &part_text)), &name.sigils, &join(&name.path_, &Text::lit(".")))),
    }
}

/// ```prism
/// DebugText: fn Text -> Text
/// ```
pub fn debug_text(t: &Text) -> Text {
    Text::from(format!("\"{}\"", &escape_debug(t, &false, &true)))
}

/// ```prism
/// DebugChar: fn Text -> Text
/// ```
pub fn debug_char(c: &Text) -> Text {
    Text::from(format!("'{}'", &escape_debug(c, &true, &false)))
}

/// ```prism
/// EscapeDebug: fn Text, Bool, Bool -> Text
/// ```
pub fn escape_debug(t: &Text, single: &bool, double: &bool) -> Text {
    map_chars(t, &{
        let single = *single;
        let double = *double;
        Rc::new(move |p0: Text| {
            let single = single;
            let double = double;
            once_job(move || {
                let c = p0;
                prism_rtl::Turn::Finished(escape_char(&c, &single, &double))
            })
        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>
    })
}

/// ```prism
/// EscapeChar: fn Text, Bool, Bool -> Text
/// ```
pub fn escape_char(c: &Text, single: &bool, double: &bool) -> Text {
    match c {
        m75236_0 if (m75236_0 == &Text::lit("\0")) => Text::lit("\\0"),
        m75236_1 if (m75236_1 == &Text::lit("\t")) => Text::lit("\\t"),
        m75236_2 if (m75236_2 == &Text::lit("\r")) => Text::lit("\\r"),
        m75236_3 if (m75236_3 == &Text::lit("\n")) => Text::lit("\\n"),
        m75236_4 if (m75236_4 == &Text::lit("\\")) => Text::lit("\\\\"),
        m75236_5 if (m75236_5 == &Text::lit("'")) && *single => Text::lit("\\'"),
        m75236_6 if (m75236_6 == &Text::lit("\"")) && *double => Text::lit("\\\""),
        _ if ((c < &Text::lit(" ")) || (c == &Text::lit(""))) => Text::from(format!("\\u{{{}}}", &hex_of(&code_of(c)))),
        _ => c.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CodeOf: fn Text -> Nat
/// ```
pub fn code_of(c: &Text) -> Nat {
    if c == &Text::lit("") {
        Nat::from(128u32)
    } else {
        len_text(&or(&index(&split(&ascii_text(), c), &Nat::from(0u32)), &ascii_text()))
    }
}

/// ```prism
/// HexOf: fn Nat -> Text
/// ```
pub fn hex_of(n: &Nat) -> Text {
    hex_digits(n, n)
}

/// ```prism
/// HexDigits: fn Nat, Nat -> Text
/// ```
pub fn hex_digits(n: &Nat, fuel: &Nat) -> Text {
    match fuel.checked_sub(&Nat::from(1u32)) {
        Some(left) if (n >= &Nat::from(16u32)) => Text::from(format!("{}{}", &hex_digits(&or(&div(n, &Nat::from(16u32)), &Nat::from(0u32)), &left), &char_at_byte(&hex_digits_value(), &or(&mod_(n, &Nat::from(16u32)), &Nat::from(0u32))))),
        _ => if n < &Nat::from(16u32) {
            char_at_byte(&hex_digits_value(), n)
        } else {
            Text::lit("0")
        },
        _ => unreachable!("no arm matched"),
    }
}
