//! The module `Syntax.Lexer`, from `target/bootstrap/src/prismc/syntax/lexer/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod chars;
pub mod corpus;
pub mod layout;
pub mod literals;
pub mod templates;
pub mod words;

/// `AttrTok`:
///
/// ```prism
/// type AttrTok = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct AttrTok {
    pub name: Text,
    pub tokens: Array<Tok>,
    pub span: crate::syntax::Range,
}

impl Show for AttrTok {
    fn show(&self, p: &mut Printer) {
        p.record("AttrTok", &[("name", &self.name), ("tokens", &self.tokens), ("span", &self.span)]);
    }
}

impl ToPod for AttrTok {
    fn to_pod(&self) -> Pod {
        Pod::record("AttrTok", vec![("name", self.name.to_pod()), ("tokens", self.tokens.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for AttrTok {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(AttrTok { name: FromPod::from_pod(field(p, "name")?)?, tokens: FromPod::from_pod(field(p, "tokens")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `Lex`:
///
/// ```prism
/// type Lex = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Lex {
    pub src: Text,
    pub pos: Nat,
    pub diags: Array<crate::syntax::Diag>,
    pub mode: Mode,
    pub tokens: Array<Tok>,
    pub layout: Array<Nat>,
    pub frames: Array<Text>,
    pub last_ws: bool,
    pub lambda_open: bool,
    pub pending_open: bool,
    pub pending_span: crate::syntax::Range,
    pub line_first: Nat,
    pub mark_line_start: bool,
    pub first_line: bool,
    pub test_pending: Text,
    pub test_depth: Option<Nat>,
    pub check_depth: Option<Nat>,
    pub path_next: bool,
}

impl Show for Lex {
    fn show(&self, p: &mut Printer) {
        p.record("Lex", &[("src", &self.src), ("pos", &self.pos), ("diags", &self.diags), ("mode", &self.mode), ("tokens", &self.tokens), ("layout", &self.layout), ("frames", &self.frames), ("last_ws", &self.last_ws), ("lambda_open", &self.lambda_open), ("pending_open", &self.pending_open), ("pending_span", &self.pending_span), ("line_first", &self.line_first), ("mark_line_start", &self.mark_line_start), ("first_line", &self.first_line), ("test_pending", &self.test_pending), ("test_depth", &self.test_depth), ("check_depth", &self.check_depth), ("path_next", &self.path_next)]);
    }
}

impl ToPod for Lex {
    fn to_pod(&self) -> Pod {
        Pod::record("Lex", vec![("src", self.src.to_pod()), ("pos", self.pos.to_pod()), ("diags", self.diags.to_pod()), ("mode", self.mode.to_pod()), ("tokens", self.tokens.to_pod()), ("layout", self.layout.to_pod()), ("frames", self.frames.to_pod()), ("last_ws", self.last_ws.to_pod()), ("lambda_open", self.lambda_open.to_pod()), ("pending_open", self.pending_open.to_pod()), ("pending_span", self.pending_span.to_pod()), ("line_first", self.line_first.to_pod()), ("mark_line_start", self.mark_line_start.to_pod()), ("first_line", self.first_line.to_pod()), ("test_pending", self.test_pending.to_pod()), ("test_depth", self.test_depth.to_pod()), ("check_depth", self.check_depth.to_pod()), ("path_next", self.path_next.to_pod())])
    }
}

impl FromPod for Lex {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Lex { src: FromPod::from_pod(field(p, "src")?)?, pos: FromPod::from_pod(field(p, "pos")?)?, diags: FromPod::from_pod(field(p, "diags")?)?, mode: FromPod::from_pod(field(p, "mode")?)?, tokens: FromPod::from_pod(field(p, "tokens")?)?, layout: FromPod::from_pod(field(p, "layout")?)?, frames: FromPod::from_pod(field(p, "frames")?)?, last_ws: FromPod::from_pod(field(p, "last_ws")?)?, lambda_open: FromPod::from_pod(field(p, "lambda_open")?)?, pending_open: FromPod::from_pod(field(p, "pending_open")?)?, pending_span: FromPod::from_pod(field(p, "pending_span")?)?, line_first: FromPod::from_pod(field(p, "line_first")?)?, mark_line_start: FromPod::from_pod(field(p, "mark_line_start")?)?, first_line: FromPod::from_pod(field(p, "first_line")?)?, test_pending: FromPod::from_pod(field(p, "test_pending")?)?, test_depth: FromPod::from_pod(field(p, "test_depth")?)?, check_depth: FromPod::from_pod(field(p, "check_depth")?)?, path_next: FromPod::from_pod(field(p, "path_next")?)? })
    }
}

/// `Lexed`:
///
/// ```prism
/// type Lexed = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Lexed {
    pub tokens: Array<Tok>,
    pub diags: Array<crate::syntax::Diag>,
}

impl Show for Lexed {
    fn show(&self, p: &mut Printer) {
        p.record("Lexed", &[("tokens", &self.tokens), ("diags", &self.diags)]);
    }
}

impl ToPod for Lexed {
    fn to_pod(&self) -> Pod {
        Pod::record("Lexed", vec![("tokens", self.tokens.to_pod()), ("diags", self.diags.to_pod())])
    }
}

impl FromPod for Lexed {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Lexed { tokens: FromPod::from_pod(field(p, "tokens")?)?, diags: FromPod::from_pod(field(p, "diags")?)? })
    }
}

/// `Mode`:
///
/// ```prism
/// type Mode = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Mode {
    MFile,
    MBrace(Text),
    MPlaceholder(Text),
    MPathKey,
}

impl Show for Mode {
    fn show(&self, p: &mut Printer) {
        match self {
            Mode::MFile => p.choice("MFile", &[]),
            Mode::MBrace(a0) => p.choice("MBrace", &[a0]),
            Mode::MPlaceholder(a0) => p.choice("MPlaceholder", &[a0]),
            Mode::MPathKey => p.choice("MPathKey", &[]),
        }
    }
}

impl ToPod for Mode {
    fn to_pod(&self) -> Pod {
        match self {
            Mode::MFile => Pod::Choice("MFile".into(), vec![]),
            Mode::MBrace(a0) => Pod::Choice("MBrace".into(), vec![a0.to_pod()]),
            Mode::MPlaceholder(a0) => Pod::Choice("MPlaceholder".into(), vec![a0.to_pod()]),
            Mode::MPathKey => Pod::Choice("MPathKey".into(), vec![]),
        }
    }
}

impl FromPod for Mode {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "MFile" && a.len() == 0 => Ok(Mode::MFile),
            Pod::Choice(c, a) if &**c == "MBrace" && a.len() == 1 => Ok(Mode::MBrace(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "MPlaceholder" && a.len() == 1 => Ok(Mode::MPlaceholder(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "MPathKey" && a.len() == 0 => Ok(Mode::MPathKey),
            other => mismatch("a Mode", other),
        }
    }
}

/// `NameCase`:
///
/// ```prism
/// type NameCase = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum NameCase {
    CaseLower,
    CaseUpper,
    CaseTopic,
    CaseHole,
    CaseReserved,
}

impl Show for NameCase {
    fn show(&self, p: &mut Printer) {
        match self {
            NameCase::CaseLower => p.choice("CaseLower", &[]),
            NameCase::CaseUpper => p.choice("CaseUpper", &[]),
            NameCase::CaseTopic => p.choice("CaseTopic", &[]),
            NameCase::CaseHole => p.choice("CaseHole", &[]),
            NameCase::CaseReserved => p.choice("CaseReserved", &[]),
        }
    }
}

impl ToPod for NameCase {
    fn to_pod(&self) -> Pod {
        match self {
            NameCase::CaseLower => Pod::Choice("CaseLower".into(), vec![]),
            NameCase::CaseUpper => Pod::Choice("CaseUpper".into(), vec![]),
            NameCase::CaseTopic => Pod::Choice("CaseTopic".into(), vec![]),
            NameCase::CaseHole => Pod::Choice("CaseHole".into(), vec![]),
            NameCase::CaseReserved => Pod::Choice("CaseReserved".into(), vec![]),
        }
    }
}

impl FromPod for NameCase {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "CaseLower" && a.len() == 0 => Ok(NameCase::CaseLower),
            Pod::Choice(c, a) if &**c == "CaseUpper" && a.len() == 0 => Ok(NameCase::CaseUpper),
            Pod::Choice(c, a) if &**c == "CaseTopic" && a.len() == 0 => Ok(NameCase::CaseTopic),
            Pod::Choice(c, a) if &**c == "CaseHole" && a.len() == 0 => Ok(NameCase::CaseHole),
            Pod::Choice(c, a) if &**c == "CaseReserved" && a.len() == 0 => Ok(NameCase::CaseReserved),
            other => mismatch("a NameCase", other),
        }
    }
}

/// `NameTok`:
///
/// ```prism
/// type NameTok = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct NameTok {
    pub sigils: Text,
    pub path_: Array<Text>,
    pub case: NameCase,
}

impl Show for NameTok {
    fn show(&self, p: &mut Printer) {
        p.record("NameTok", &[("sigils", &self.sigils), ("path", &self.path_), ("case", &self.case)]);
    }
}

impl ToPod for NameTok {
    fn to_pod(&self) -> Pod {
        Pod::record("NameTok", vec![("sigils", self.sigils.to_pod()), ("path", self.path_.to_pod()), ("case", self.case.to_pod())])
    }
}

impl FromPod for NameTok {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(NameTok { sigils: FromPod::from_pod(field(p, "sigils")?)?, path_: FromPod::from_pod(field(p, "path")?)?, case: FromPod::from_pod(field(p, "case")?)? })
    }
}

/// `PathSegTok`:
///
/// ```prism
/// type PathSegTok = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum PathSegTok {
    PstNum(Nat),
    PstGen(Nat),
    PstKey(Array<Tok>),
}

impl Show for PathSegTok {
    fn show(&self, p: &mut Printer) {
        match self {
            PathSegTok::PstNum(a0) => p.choice("PstNum", &[a0]),
            PathSegTok::PstGen(a0) => p.choice("PstGen", &[a0]),
            PathSegTok::PstKey(a0) => p.choice("PstKey", &[a0]),
        }
    }
}

impl ToPod for PathSegTok {
    fn to_pod(&self) -> Pod {
        match self {
            PathSegTok::PstNum(a0) => Pod::Choice("PstNum".into(), vec![a0.to_pod()]),
            PathSegTok::PstGen(a0) => Pod::Choice("PstGen".into(), vec![a0.to_pod()]),
            PathSegTok::PstKey(a0) => Pod::Choice("PstKey".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for PathSegTok {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "PstNum" && a.len() == 1 => Ok(PathSegTok::PstNum(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PstGen" && a.len() == 1 => Ok(PathSegTok::PstGen(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PstKey" && a.len() == 1 => Ok(PathSegTok::PstKey(FromPod::from_pod(&a[0])?)),
            other => mismatch("a PathSegTok", other),
        }
    }
}

/// `TPartTok`:
///
/// ```prism
/// type TPartTok = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum TPartTok {
    TptText(Text),
    TptPlaceholder(Array<Tok>, Option<Nat>, crate::syntax::Range),
    TptBlock(Array<Tok>, crate::syntax::Range),
    TptCall(NameTok, Array<AttrTok>, Option<Array<TPartTok>>, crate::syntax::Range),
}

impl Show for TPartTok {
    fn show(&self, p: &mut Printer) {
        match self {
            TPartTok::TptText(a0) => p.choice("TptText", &[a0]),
            TPartTok::TptPlaceholder(a0, a1, a2) => p.choice("TptPlaceholder", &[a0, a1, a2]),
            TPartTok::TptBlock(a0, a1) => p.choice("TptBlock", &[a0, a1]),
            TPartTok::TptCall(a0, a1, a2, a3) => p.choice("TptCall", &[a0, a1, a2, a3]),
        }
    }
}

impl ToPod for TPartTok {
    fn to_pod(&self) -> Pod {
        match self {
            TPartTok::TptText(a0) => Pod::Choice("TptText".into(), vec![a0.to_pod()]),
            TPartTok::TptPlaceholder(a0, a1, a2) => Pod::Choice("TptPlaceholder".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            TPartTok::TptBlock(a0, a1) => Pod::Choice("TptBlock".into(), vec![a0.to_pod(), a1.to_pod()]),
            TPartTok::TptCall(a0, a1, a2, a3) => Pod::Choice("TptCall".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
        }
    }
}

impl FromPod for TPartTok {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "TptText" && a.len() == 1 => Ok(TPartTok::TptText(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TptPlaceholder" && a.len() == 3 => Ok(TPartTok::TptPlaceholder(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "TptBlock" && a.len() == 2 => Ok(TPartTok::TptBlock(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "TptCall" && a.len() == 4 => Ok(TPartTok::TptCall(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?, FromPod::from_pod(&a[3])?)),
            other => mismatch("a TPartTok", other),
        }
    }
}

/// `TemplateTok`:
///
/// ```prism
/// type TemplateTok = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TemplateTok {
    pub keyword: Text,
    pub lang: Text,
    pub delims: Text,
    pub parts: Array<TPartTok>,
}

impl Show for TemplateTok {
    fn show(&self, p: &mut Printer) {
        p.record("TemplateTok", &[("keyword", &self.keyword), ("lang", &self.lang), ("delims", &self.delims), ("parts", &self.parts)]);
    }
}

impl ToPod for TemplateTok {
    fn to_pod(&self) -> Pod {
        Pod::record("TemplateTok", vec![("keyword", self.keyword.to_pod()), ("lang", self.lang.to_pod()), ("delims", self.delims.to_pod()), ("parts", self.parts.to_pod())])
    }
}

impl FromPod for TemplateTok {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TemplateTok { keyword: FromPod::from_pod(field(p, "keyword")?)?, lang: FromPod::from_pod(field(p, "lang")?)?, delims: FromPod::from_pod(field(p, "delims")?)?, parts: FromPod::from_pod(field(p, "parts")?)? })
    }
}

/// `TextSegTok`:
///
/// ```prism
/// type TextSegTok = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum TextSegTok {
    TsPlain(Text),
    TsPlaceholder(Array<Tok>, crate::syntax::Range),
}

impl Show for TextSegTok {
    fn show(&self, p: &mut Printer) {
        match self {
            TextSegTok::TsPlain(a0) => p.choice("TsPlain", &[a0]),
            TextSegTok::TsPlaceholder(a0, a1) => p.choice("TsPlaceholder", &[a0, a1]),
        }
    }
}

impl ToPod for TextSegTok {
    fn to_pod(&self) -> Pod {
        match self {
            TextSegTok::TsPlain(a0) => Pod::Choice("TsPlain".into(), vec![a0.to_pod()]),
            TextSegTok::TsPlaceholder(a0, a1) => Pod::Choice("TsPlaceholder".into(), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl FromPod for TextSegTok {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "TsPlain" && a.len() == 1 => Ok(TextSegTok::TsPlain(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TsPlaceholder" && a.len() == 2 => Ok(TextSegTok::TsPlaceholder(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            other => mismatch("a TextSegTok", other),
        }
    }
}

/// `Tok`:
///
/// ```prism
/// type Tok = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Tok {
    pub kind: TokKind,
    pub span: crate::syntax::Range,
    pub touches: bool,
    pub line_start: bool,
}

impl Show for Tok {
    fn show(&self, p: &mut Printer) {
        p.record("Tok", &[("kind", &self.kind), ("span", &self.span), ("touches", &self.touches), ("line_start", &self.line_start)]);
    }
}

impl ToPod for Tok {
    fn to_pod(&self) -> Pod {
        Pod::record("Tok", vec![("kind", self.kind.to_pod()), ("span", self.span.to_pod()), ("touches", self.touches.to_pod()), ("line_start", self.line_start.to_pod())])
    }
}

impl FromPod for Tok {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Tok { kind: FromPod::from_pod(field(p, "kind")?)?, span: FromPod::from_pod(field(p, "span")?)?, touches: FromPod::from_pod(field(p, "touches")?)?, line_start: FromPod::from_pod(field(p, "line_start")?)? })
    }
}

/// `TokKind`:
///
/// ```prism
/// type TokKind = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum TokKind {
    KName(NameTok),
    KFamily(Array<Text>),
    KTrait(Array<Text>),
    KKw(Text, Text),
    KFree(Text),
    KLensDot,
    KInt(Text, Text),
    KFloat(Text, Text),
    KDuration(Text, Text, Text),
    KChar(Text, Text),
    KText(Text, Array<TextSegTok>),
    KTemplate(TemplateTok),
    KOp(Text, bool),
    KSuffixed(Text, Array<Text>),
    KDot(bool),
    KDotDot,
    KComma,
    KColon,
    KSemi,
    KBackslash,
    KLambdaBar(bool),
    KBar,
    KLtLt,
    KGtGt,
    KOpen(Text, bool),
    KClose(Text),
    KAbsent,
    KNonEmpty,
    KPath(Array<PathSegTok>),
    KLayOpen,
    KLaySep,
    KLayClose,
    KEof,
}

impl Show for TokKind {
    fn show(&self, p: &mut Printer) {
        match self {
            TokKind::KName(a0) => p.choice("KName", &[a0]),
            TokKind::KFamily(a0) => p.choice("KFamily", &[a0]),
            TokKind::KTrait(a0) => p.choice("KTrait", &[a0]),
            TokKind::KKw(a0, a1) => p.choice("KKw", &[a0, a1]),
            TokKind::KFree(a0) => p.choice("KFree", &[a0]),
            TokKind::KLensDot => p.choice("KLensDot", &[]),
            TokKind::KInt(a0, a1) => p.choice("KInt", &[a0, a1]),
            TokKind::KFloat(a0, a1) => p.choice("KFloat", &[a0, a1]),
            TokKind::KDuration(a0, a1, a2) => p.choice("KDuration", &[a0, a1, a2]),
            TokKind::KChar(a0, a1) => p.choice("KChar", &[a0, a1]),
            TokKind::KText(a0, a1) => p.choice("KText", &[a0, a1]),
            TokKind::KTemplate(a0) => p.choice("KTemplate", &[a0]),
            TokKind::KOp(a0, a1) => p.choice("KOp", &[a0, a1]),
            TokKind::KSuffixed(a0, a1) => p.choice("KSuffixed", &[a0, a1]),
            TokKind::KDot(a0) => p.choice("KDot", &[a0]),
            TokKind::KDotDot => p.choice("KDotDot", &[]),
            TokKind::KComma => p.choice("KComma", &[]),
            TokKind::KColon => p.choice("KColon", &[]),
            TokKind::KSemi => p.choice("KSemi", &[]),
            TokKind::KBackslash => p.choice("KBackslash", &[]),
            TokKind::KLambdaBar(a0) => p.choice("KLambdaBar", &[a0]),
            TokKind::KBar => p.choice("KBar", &[]),
            TokKind::KLtLt => p.choice("KLtLt", &[]),
            TokKind::KGtGt => p.choice("KGtGt", &[]),
            TokKind::KOpen(a0, a1) => p.choice("KOpen", &[a0, a1]),
            TokKind::KClose(a0) => p.choice("KClose", &[a0]),
            TokKind::KAbsent => p.choice("KAbsent", &[]),
            TokKind::KNonEmpty => p.choice("KNonEmpty", &[]),
            TokKind::KPath(a0) => p.choice("KPath", &[a0]),
            TokKind::KLayOpen => p.choice("KLayOpen", &[]),
            TokKind::KLaySep => p.choice("KLaySep", &[]),
            TokKind::KLayClose => p.choice("KLayClose", &[]),
            TokKind::KEof => p.choice("KEof", &[]),
        }
    }
}

impl ToPod for TokKind {
    fn to_pod(&self) -> Pod {
        match self {
            TokKind::KName(a0) => Pod::Choice("KName".into(), vec![a0.to_pod()]),
            TokKind::KFamily(a0) => Pod::Choice("KFamily".into(), vec![a0.to_pod()]),
            TokKind::KTrait(a0) => Pod::Choice("KTrait".into(), vec![a0.to_pod()]),
            TokKind::KKw(a0, a1) => Pod::Choice("KKw".into(), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KFree(a0) => Pod::Choice("KFree".into(), vec![a0.to_pod()]),
            TokKind::KLensDot => Pod::Choice("KLensDot".into(), vec![]),
            TokKind::KInt(a0, a1) => Pod::Choice("KInt".into(), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KFloat(a0, a1) => Pod::Choice("KFloat".into(), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KDuration(a0, a1, a2) => Pod::Choice("KDuration".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            TokKind::KChar(a0, a1) => Pod::Choice("KChar".into(), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KText(a0, a1) => Pod::Choice("KText".into(), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KTemplate(a0) => Pod::Choice("KTemplate".into(), vec![a0.to_pod()]),
            TokKind::KOp(a0, a1) => Pod::Choice("KOp".into(), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KSuffixed(a0, a1) => Pod::Choice("KSuffixed".into(), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KDot(a0) => Pod::Choice("KDot".into(), vec![a0.to_pod()]),
            TokKind::KDotDot => Pod::Choice("KDotDot".into(), vec![]),
            TokKind::KComma => Pod::Choice("KComma".into(), vec![]),
            TokKind::KColon => Pod::Choice("KColon".into(), vec![]),
            TokKind::KSemi => Pod::Choice("KSemi".into(), vec![]),
            TokKind::KBackslash => Pod::Choice("KBackslash".into(), vec![]),
            TokKind::KLambdaBar(a0) => Pod::Choice("KLambdaBar".into(), vec![a0.to_pod()]),
            TokKind::KBar => Pod::Choice("KBar".into(), vec![]),
            TokKind::KLtLt => Pod::Choice("KLtLt".into(), vec![]),
            TokKind::KGtGt => Pod::Choice("KGtGt".into(), vec![]),
            TokKind::KOpen(a0, a1) => Pod::Choice("KOpen".into(), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KClose(a0) => Pod::Choice("KClose".into(), vec![a0.to_pod()]),
            TokKind::KAbsent => Pod::Choice("KAbsent".into(), vec![]),
            TokKind::KNonEmpty => Pod::Choice("KNonEmpty".into(), vec![]),
            TokKind::KPath(a0) => Pod::Choice("KPath".into(), vec![a0.to_pod()]),
            TokKind::KLayOpen => Pod::Choice("KLayOpen".into(), vec![]),
            TokKind::KLaySep => Pod::Choice("KLaySep".into(), vec![]),
            TokKind::KLayClose => Pod::Choice("KLayClose".into(), vec![]),
            TokKind::KEof => Pod::Choice("KEof".into(), vec![]),
        }
    }
}

impl FromPod for TokKind {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "KName" && a.len() == 1 => Ok(TokKind::KName(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "KFamily" && a.len() == 1 => Ok(TokKind::KFamily(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "KTrait" && a.len() == 1 => Ok(TokKind::KTrait(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "KKw" && a.len() == 2 => Ok(TokKind::KKw(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KFree" && a.len() == 1 => Ok(TokKind::KFree(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "KLensDot" && a.len() == 0 => Ok(TokKind::KLensDot),
            Pod::Choice(c, a) if &**c == "KInt" && a.len() == 2 => Ok(TokKind::KInt(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KFloat" && a.len() == 2 => Ok(TokKind::KFloat(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KDuration" && a.len() == 3 => Ok(TokKind::KDuration(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "KChar" && a.len() == 2 => Ok(TokKind::KChar(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KText" && a.len() == 2 => Ok(TokKind::KText(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KTemplate" && a.len() == 1 => Ok(TokKind::KTemplate(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "KOp" && a.len() == 2 => Ok(TokKind::KOp(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KSuffixed" && a.len() == 2 => Ok(TokKind::KSuffixed(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KDot" && a.len() == 1 => Ok(TokKind::KDot(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "KDotDot" && a.len() == 0 => Ok(TokKind::KDotDot),
            Pod::Choice(c, a) if &**c == "KComma" && a.len() == 0 => Ok(TokKind::KComma),
            Pod::Choice(c, a) if &**c == "KColon" && a.len() == 0 => Ok(TokKind::KColon),
            Pod::Choice(c, a) if &**c == "KSemi" && a.len() == 0 => Ok(TokKind::KSemi),
            Pod::Choice(c, a) if &**c == "KBackslash" && a.len() == 0 => Ok(TokKind::KBackslash),
            Pod::Choice(c, a) if &**c == "KLambdaBar" && a.len() == 1 => Ok(TokKind::KLambdaBar(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "KBar" && a.len() == 0 => Ok(TokKind::KBar),
            Pod::Choice(c, a) if &**c == "KLtLt" && a.len() == 0 => Ok(TokKind::KLtLt),
            Pod::Choice(c, a) if &**c == "KGtGt" && a.len() == 0 => Ok(TokKind::KGtGt),
            Pod::Choice(c, a) if &**c == "KOpen" && a.len() == 2 => Ok(TokKind::KOpen(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KClose" && a.len() == 1 => Ok(TokKind::KClose(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "KAbsent" && a.len() == 0 => Ok(TokKind::KAbsent),
            Pod::Choice(c, a) if &**c == "KNonEmpty" && a.len() == 0 => Ok(TokKind::KNonEmpty),
            Pod::Choice(c, a) if &**c == "KPath" && a.len() == 1 => Ok(TokKind::KPath(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "KLayOpen" && a.len() == 0 => Ok(TokKind::KLayOpen),
            Pod::Choice(c, a) if &**c == "KLaySep" && a.len() == 0 => Ok(TokKind::KLaySep),
            Pod::Choice(c, a) if &**c == "KLayClose" && a.len() == 0 => Ok(TokKind::KLayClose),
            Pod::Choice(c, a) if &**c == "KEof" && a.len() == 0 => Ok(TokKind::KEof),
            other => mismatch("a TokKind", other),
        }
    }
}

/// ```prism
/// Fresh: fn Lex, Mode -> Lex
/// ```
pub fn fresh(l: &Lex, mode: &Mode) -> Lex {
    Lex { src: l.src.clone(), pos: l.pos.clone(), diags: l.diags.clone(), mode: mode.clone(), tokens: Array::new(), layout: Array::new(), frames: Array::new(), last_ws: true, lambda_open: false, pending_open: false, pending_span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) }, line_first: Nat::from(0u32), mark_line_start: false, first_line: true, test_pending: Text::lit(""), test_depth: None, check_depth: None, path_next: false }
}

/// ```prism
/// IsLayoutOrEof: fn TokKind -> Bool
/// ```
pub fn is_layout_or_eof(tok_kind0: &TokKind) -> bool {
    match tok_kind0 {
        TokKind::KLayOpen => true,
        TokKind::KLaySep => true,
        TokKind::KLayClose => true,
        TokKind::KEof => true,
        _ => false,
    }
}

/// ```prism
/// IsLayout: fn TokKind -> Bool
/// ```
pub fn is_layout(tok_kind0: &TokKind) -> bool {
    match tok_kind0 {
        TokKind::KLayOpen => true,
        TokKind::KLaySep => true,
        TokKind::KLayClose => true,
        _ => false,
    }
}

/// ```prism
/// EndsOperand: fn TokKind -> Bool
/// ```
pub fn ends_operand(tok_kind0: &TokKind) -> bool {
    match tok_kind0 {
        TokKind::KName(_) => true,
        TokKind::KFamily(_) => true,
        TokKind::KInt(_, _) => true,
        TokKind::KFloat(_, _) => true,
        TokKind::KDuration(_, _, _) => true,
        TokKind::KChar(_, _) => true,
        TokKind::KText(_, _) => true,
        TokKind::KTemplate(_) => true,
        TokKind::KClose(_) => true,
        TokKind::KGtGt => true,
        TokKind::KNonEmpty => true,
        TokKind::KAbsent => true,
        TokKind::KKw(w, _) => is_value_word(w),
        _ => false,
    }
}

/// ```prism
/// IsValueWord: fn Text -> Bool
/// ```
pub fn is_value_word(w: &Text) -> bool {
    ((w == &Text::lit("unit")) || (w == &Text::lit("nil"))) || is_bound_word(w)
}

/// ```prism
/// IsBoundWord: fn Text -> Bool
/// ```
pub fn is_bound_word(w: &Text) -> bool {
    (((w == &Text::lit("key")) || (w == &Text::lit("ix"))) || (w == &Text::lit("jx"))) || (w == &Text::lit("kx"))
}

/// ```prism
/// let keywordList
/// ```
pub fn keyword_list() -> Array<Text> {
    Array::from(vec![Text::lit("module"), Text::lit("emit"), Text::lit("use"), Text::lit("type"), Text::lit("record"), Text::lit("choice"), Text::lit("row"), Text::lit("tag"), Text::lit("of"), Text::lit("derive"), Text::lit("trait"), Text::lit("impl"), Text::lit("where"), Text::lit("any"), Text::lit("let"), Text::lit("fn"), Text::lit("test"), Text::lit("check"), Text::lit("widget"), Text::lit("rebuild"), Text::lit("for"), Text::lit("given"), Text::lit("monad"), Text::lit("update"), Text::lit("while"), Text::lit("match"), Text::lit("if"), Text::lit("else"), Text::lit("otherwise"), Text::lit("require"), Text::lit("forbid"), Text::lit("return"), Text::lit("ignore"), Text::lit("then"), Text::lit("on"), Text::lit("not"), Text::lit("and"), Text::lit("or"), Text::lit("mod"), Text::lit("as"), Text::lit("output"), Text::lit("inline_text"), Text::lit("raw"), Text::lit("unbounded"), Text::lit("unit"), Text::lit("nil"), Text::lit("key"), Text::lit("ix"), Text::lit("jx"), Text::lit("kx")])
}

/// ```prism
/// let keywordSet
/// ```
pub fn keyword_set() -> Map<Text, bool> {
    map(&each(&keyword_list(), &(|w: &Text| (w.clone(), true))))
}

/// ```prism
/// IsKeyword: fn Text -> Bool
/// ```
pub fn is_keyword(w: &Text) -> bool {
    &get(&keyword_set(), w) != &None
}

/// ```prism
/// let opTable
/// ```
pub fn op_table() -> Array<Text> {
    Array::from(vec![Text::lit("==>"), Text::lit("<-"), Text::lit("<="), Text::lit("<|"), Text::lit("->"), Text::lit("-="), Text::lit("-?"), Text::lit("+="), Text::lit("+?"), Text::lit("*="), Text::lit("*?"), Text::lit("/="), Text::lit("=="), Text::lit(">="), Text::lit("=>"), Text::lit("<"), Text::lit(">"), Text::lit("-"), Text::lit("+"), Text::lit("*"), Text::lit("/"), Text::lit("=")])
}

/// ```prism
/// TakesSuffix: fn Text -> Bool
/// ```
pub fn takes_suffix(op: &Text) -> bool {
    fold(&Array::from(vec![Text::lit("<="), Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit(">"), Text::lit(">="), Text::lit("+"), Text::lit("-"), Text::lit("*"), Text::lit("/"), Text::lit("+?"), Text::lit("-?"), Text::lit("*?")]), &false, &(|seen: &bool, o: &Text| *seen || (o == op)))
}

/// ```prism
/// CloseChar: fn Text -> Text
/// ```
pub fn close_char(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("(")) => Text::lit(")"),
        c1_0 if (c1_0 == &Text::lit("[")) => Text::lit("]"),
        _ => Text::lit("}"),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// OpenOf: fn Text -> Text
/// ```
pub fn open_of(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit(")")) => Text::lit("("),
        c1_0 if (c1_0 == &Text::lit("]")) => Text::lit("["),
        _ => Text::lit("{"),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// PrefixPosition: fn Lex -> Bool
/// ```
pub fn prefix_position(l: &Lex) -> bool {
    l.last_ws || no_operand_before(&crate::syntax::lexer::chars::last(&l.tokens))
}

/// ```prism
/// NoOperandBefore: fn ?Tok -> Bool
/// ```
pub fn no_operand_before(opt0: &Option<Tok>) -> bool {
    match opt0 {
        None => true,
        Some(t) => !ends_operand(&t.kind),
    }
}

/// ```prism
/// TestWordOf: fn TokKind -> Text
/// ```
pub fn test_word_of(tok_kind0: &TokKind) -> Text {
    match tok_kind0 {
        TokKind::KKw(c0_0_0, _) if (c0_0_0 == &Text::lit("test")) => Text::lit("test"),
        TokKind::KKw(c1_0_0, _) if (c1_0_0 == &Text::lit("check")) => Text::lit("check"),
        _ => Text::lit(""),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// AllLayout: fn [Tok] -> Bool
/// ```
pub fn all_layout(ts: &Array<Tok>) -> bool {
    fold(ts, &true, &(|ok: &bool, t: &Tok| *ok && is_layout(&t.kind)))
}

/// ```prism
/// PushTok: fn Lex, TokKind, Nat, Nat -> Lex
/// ```
pub fn push_tok(l: &Lex, kind: &TokKind, start: &Nat, end: &Nat) -> Lex {
    let mut this: Lex = l.clone();
    let layout = is_layout_or_eof(kind);
    let touches = (!this.last_ws && (&len(&this.tokens) > &Nat::from(0u32))) && !layout;
    let line_start = !layout && this.mark_line_start;
    if !layout {
        this.mark_line_start = false;
    }
    let word = test_word_of(kind);
    if (((&word != &Text::lit("")) && (&this.mode == &Mode::MFile)) && (&len(&this.layout) == &Nat::from(1u32))) && all_layout(&drop(&this.tokens, &this.line_first)) {
        this.test_pending = word.clone();
    }
    this.tokens = push(&this.tokens, &Tok { kind: kind.clone(), span: crate::syntax::Range { start: start.clone(), end: end.clone() }, touches, line_start });
    this.last_ws = false;
    this
}

/// ```prism
/// LayoutOn: fn Mode -> Bool
/// ```
pub fn layout_on(mode0: &Mode) -> bool {
    match mode0 {
        Mode::MFile => true,
        Mode::MBrace(_) => true,
        _ => false,
    }
}

/// ```prism
/// LayoutActive: fn Lex -> Bool
/// ```
pub fn layout_active(l: &Lex) -> bool {
    layout_on(&l.mode) && (&len(&l.frames) == &Nat::from(0u32))
}

/// ```prism
/// FatArrowOn: fn Lex -> Bool
/// ```
pub fn fat_arrow_on(l: &Lex) -> bool {
    (&l.test_depth != &None) || (&l.check_depth != &None)
}
