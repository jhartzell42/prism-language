//! The module `Syntax.Lexer`, from `target/bootstrap/src/prismc/syntax/lexer/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod chars;
pub mod corpus;
pub mod layout;
pub mod literals;
pub mod regexes;
pub mod templates;
pub mod words;

/// `AttrTok`:
///
/// ```prism
/// type AttrTok = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct AttrTok {
    pub name_p: Text,
    pub tokens_p: Array<Tok>,
    pub span_p: crate::syntax::Range,
}

impl Show for AttrTok {
    fn show(&self, p: &mut Printer) {
        p.record("AttrTok", &[("name", &self.name_p), ("tokens", &self.tokens_p), ("span", &self.span_p)]);
    }
}

impl ToPod for AttrTok {
    fn to_pod(&self) -> Pod {
        Pod::record("AttrTok", vec![("name", self.name_p.to_pod()), ("tokens", self.tokens_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl FromPod for AttrTok {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(AttrTok { name_p: FromPod::from_pod(field(p, "name")?)?, tokens_p: FromPod::from_pod(field(p, "tokens")?)?, span_p: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `Lex`:
///
/// ```prism
/// type Lex = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Lex {
    pub src_p: Text,
    pub pos_p: Nat,
    pub diags_p: Array<crate::syntax::Diag>,
    pub mode_p: Mode,
    pub tokens_p: Array<Tok>,
    pub layout_p: Array<Nat>,
    pub frames_p: Array<Text>,
    pub last_ws_p: bool,
    pub lambda_open_p: bool,
    pub pending_open_p: bool,
    pub pending_span_p: crate::syntax::Range,
    pub line_first_p: Nat,
    pub mark_line_start_p: bool,
    pub first_line_p: bool,
    pub test_pending_p: Text,
    pub test_depth_o: Option<Nat>,
    pub check_depth_o: Option<Nat>,
    pub path_next_p: bool,
}

impl Show for Lex {
    fn show(&self, p: &mut Printer) {
        p.record("Lex", &[("src", &self.src_p), ("pos", &self.pos_p), ("diags", &self.diags_p), ("mode", &self.mode_p), ("tokens", &self.tokens_p), ("layout", &self.layout_p), ("frames", &self.frames_p), ("lastWs", &self.last_ws_p), ("lambdaOpen", &self.lambda_open_p), ("pendingOpen", &self.pending_open_p), ("pendingSpan", &self.pending_span_p), ("lineFirst", &self.line_first_p), ("markLineStart", &self.mark_line_start_p), ("firstLine", &self.first_line_p), ("testPending", &self.test_pending_p), ("testDepth", &self.test_depth_o), ("checkDepth", &self.check_depth_o), ("pathNext", &self.path_next_p)]);
    }
}

impl ToPod for Lex {
    fn to_pod(&self) -> Pod {
        Pod::record("Lex", vec![("src", self.src_p.to_pod()), ("pos", self.pos_p.to_pod()), ("diags", self.diags_p.to_pod()), ("mode", self.mode_p.to_pod()), ("tokens", self.tokens_p.to_pod()), ("layout", self.layout_p.to_pod()), ("frames", self.frames_p.to_pod()), ("lastWs", self.last_ws_p.to_pod()), ("lambdaOpen", self.lambda_open_p.to_pod()), ("pendingOpen", self.pending_open_p.to_pod()), ("pendingSpan", self.pending_span_p.to_pod()), ("lineFirst", self.line_first_p.to_pod()), ("markLineStart", self.mark_line_start_p.to_pod()), ("firstLine", self.first_line_p.to_pod()), ("testPending", self.test_pending_p.to_pod()), ("testDepth", self.test_depth_o.to_pod()), ("checkDepth", self.check_depth_o.to_pod()), ("pathNext", self.path_next_p.to_pod())])
    }
}

impl FromPod for Lex {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Lex { src_p: FromPod::from_pod(field(p, "src")?)?, pos_p: FromPod::from_pod(field(p, "pos")?)?, diags_p: FromPod::from_pod(field(p, "diags")?)?, mode_p: FromPod::from_pod(field(p, "mode")?)?, tokens_p: FromPod::from_pod(field(p, "tokens")?)?, layout_p: FromPod::from_pod(field(p, "layout")?)?, frames_p: FromPod::from_pod(field(p, "frames")?)?, last_ws_p: FromPod::from_pod(field(p, "lastWs")?)?, lambda_open_p: FromPod::from_pod(field(p, "lambdaOpen")?)?, pending_open_p: FromPod::from_pod(field(p, "pendingOpen")?)?, pending_span_p: FromPod::from_pod(field(p, "pendingSpan")?)?, line_first_p: FromPod::from_pod(field(p, "lineFirst")?)?, mark_line_start_p: FromPod::from_pod(field(p, "markLineStart")?)?, first_line_p: FromPod::from_pod(field(p, "firstLine")?)?, test_pending_p: FromPod::from_pod(field(p, "testPending")?)?, test_depth_o: FromPod::from_pod(field(p, "testDepth")?)?, check_depth_o: FromPod::from_pod(field(p, "checkDepth")?)?, path_next_p: FromPod::from_pod(field(p, "pathNext")?)? })
    }
}

/// `Lexed`:
///
/// ```prism
/// type Lexed = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Lexed {
    pub tokens_p: Array<Tok>,
    pub diags_p: Array<crate::syntax::Diag>,
}

impl Show for Lexed {
    fn show(&self, p: &mut Printer) {
        p.record("Lexed", &[("tokens", &self.tokens_p), ("diags", &self.diags_p)]);
    }
}

impl ToPod for Lexed {
    fn to_pod(&self) -> Pod {
        Pod::record("Lexed", vec![("tokens", self.tokens_p.to_pod()), ("diags", self.diags_p.to_pod())])
    }
}

impl FromPod for Lexed {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Lexed { tokens_p: FromPod::from_pod(field(p, "tokens")?)?, diags_p: FromPod::from_pod(field(p, "diags")?)? })
    }
}

/// `Mode`:
///
/// ```prism
/// type Mode = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Mode {
    MFile,
    MBrace(Text),
    MPlaceholder(Text),
    MPathKey,
}

impl Show for Mode {
    fn show(&self, p: &mut Printer) {
        match self {
            Mode::MFile => p.choice("MFile", &[]),
            Mode::MBrace(a0) => p.choice("MBrace", &[a0]),
            Mode::MPlaceholder(a0) => p.choice("MPlaceholder", &[a0]),
            Mode::MPathKey => p.choice("MPathKey", &[]),
        }
    }
}

impl ToPod for Mode {
    fn to_pod(&self) -> Pod {
        match self {
            Mode::MFile => Pod::Choice("MFile".into(), vec![]),
            Mode::MBrace(a0) => Pod::Choice("MBrace".into(), vec![a0.to_pod()]),
            Mode::MPlaceholder(a0) => Pod::Choice("MPlaceholder".into(), vec![a0.to_pod()]),
            Mode::MPathKey => Pod::Choice("MPathKey".into(), vec![]),
        }
    }
}

impl FromPod for Mode {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "MFile" && a.len() == 0 => Ok(Mode::MFile),
            Pod::Choice(c, a) if &**c == "MBrace" && a.len() == 1 => Ok(Mode::MBrace(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "MPlaceholder" && a.len() == 1 => Ok(Mode::MPlaceholder(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "MPathKey" && a.len() == 0 => Ok(Mode::MPathKey),
            other => mismatch("a Mode", other),
        }
    }
}

/// `NameCase`:
///
/// ```prism
/// type NameCase = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum NameCase {
    CaseLower,
    CaseUpper,
    CaseTopic,
    CaseHole,
    CaseReserved,
}

impl Show for NameCase {
    fn show(&self, p: &mut Printer) {
        match self {
            NameCase::CaseLower => p.choice("CaseLower", &[]),
            NameCase::CaseUpper => p.choice("CaseUpper", &[]),
            NameCase::CaseTopic => p.choice("CaseTopic", &[]),
            NameCase::CaseHole => p.choice("CaseHole", &[]),
            NameCase::CaseReserved => p.choice("CaseReserved", &[]),
        }
    }
}

impl ToPod for NameCase {
    fn to_pod(&self) -> Pod {
        match self {
            NameCase::CaseLower => Pod::Choice("CaseLower".into(), vec![]),
            NameCase::CaseUpper => Pod::Choice("CaseUpper".into(), vec![]),
            NameCase::CaseTopic => Pod::Choice("CaseTopic".into(), vec![]),
            NameCase::CaseHole => Pod::Choice("CaseHole".into(), vec![]),
            NameCase::CaseReserved => Pod::Choice("CaseReserved".into(), vec![]),
        }
    }
}

impl FromPod for NameCase {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "CaseLower" && a.len() == 0 => Ok(NameCase::CaseLower),
            Pod::Choice(c, a) if &**c == "CaseUpper" && a.len() == 0 => Ok(NameCase::CaseUpper),
            Pod::Choice(c, a) if &**c == "CaseTopic" && a.len() == 0 => Ok(NameCase::CaseTopic),
            Pod::Choice(c, a) if &**c == "CaseHole" && a.len() == 0 => Ok(NameCase::CaseHole),
            Pod::Choice(c, a) if &**c == "CaseReserved" && a.len() == 0 => Ok(NameCase::CaseReserved),
            other => mismatch("a NameCase", other),
        }
    }
}

/// `NameTok`:
///
/// ```prism
/// type NameTok = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct NameTok {
    pub sigils_p: Text,
    pub path_p: Array<Text>,
    pub case_p: NameCase,
}

impl Show for NameTok {
    fn show(&self, p: &mut Printer) {
        p.record("NameTok", &[("sigils", &self.sigils_p), ("path", &self.path_p), ("case", &self.case_p)]);
    }
}

impl ToPod for NameTok {
    fn to_pod(&self) -> Pod {
        Pod::record("NameTok", vec![("sigils", self.sigils_p.to_pod()), ("path", self.path_p.to_pod()), ("case", self.case_p.to_pod())])
    }
}

impl FromPod for NameTok {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(NameTok { sigils_p: FromPod::from_pod(field(p, "sigils")?)?, path_p: FromPod::from_pod(field(p, "path")?)?, case_p: FromPod::from_pod(field(p, "case")?)? })
    }
}

/// `PathSegTok`:
///
/// ```prism
/// type PathSegTok = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum PathSegTok {
    PstNum(Nat),
    PstGen(Nat),
    PstKey(Array<Tok>),
}

impl Show for PathSegTok {
    fn show(&self, p: &mut Printer) {
        match self {
            PathSegTok::PstNum(a0) => p.choice("PstNum", &[a0]),
            PathSegTok::PstGen(a0) => p.choice("PstGen", &[a0]),
            PathSegTok::PstKey(a0) => p.choice("PstKey", &[a0]),
        }
    }
}

impl ToPod for PathSegTok {
    fn to_pod(&self) -> Pod {
        match self {
            PathSegTok::PstNum(a0) => Pod::Choice("PstNum".into(), vec![a0.to_pod()]),
            PathSegTok::PstGen(a0) => Pod::Choice("PstGen".into(), vec![a0.to_pod()]),
            PathSegTok::PstKey(a0) => Pod::Choice("PstKey".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for PathSegTok {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "PstNum" && a.len() == 1 => Ok(PathSegTok::PstNum(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PstGen" && a.len() == 1 => Ok(PathSegTok::PstGen(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PstKey" && a.len() == 1 => Ok(PathSegTok::PstKey(FromPod::from_pod(&a[0])?)),
            other => mismatch("a PathSegTok", other),
        }
    }
}

/// `TPartTok`:
///
/// ```prism
/// type TPartTok = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum TPartTok {
    TptText(Text),
    TptPlaceholder(Array<Tok>, Option<Nat>, crate::syntax::Range),
    TptBlock(Array<Tok>, crate::syntax::Range),
    TptCall(NameTok, Array<AttrTok>, Option<Array<TPartTok>>, crate::syntax::Range),
}

impl Show for TPartTok {
    fn show(&self, p: &mut Printer) {
        match self {
            TPartTok::TptText(a0) => p.choice("TptText", &[a0]),
            TPartTok::TptPlaceholder(a0, a1, a2) => p.choice("TptPlaceholder", &[a0, a1, a2]),
            TPartTok::TptBlock(a0, a1) => p.choice("TptBlock", &[a0, a1]),
            TPartTok::TptCall(a0, a1, a2, a3) => p.choice("TptCall", &[a0, a1, a2, a3]),
        }
    }
}

impl ToPod for TPartTok {
    fn to_pod(&self) -> Pod {
        match self {
            TPartTok::TptText(a0) => Pod::Choice("TptText".into(), vec![a0.to_pod()]),
            TPartTok::TptPlaceholder(a0, a1, a2) => Pod::Choice("TptPlaceholder".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            TPartTok::TptBlock(a0, a1) => Pod::Choice("TptBlock".into(), vec![a0.to_pod(), a1.to_pod()]),
            TPartTok::TptCall(a0, a1, a2, a3) => Pod::Choice("TptCall".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
        }
    }
}

impl FromPod for TPartTok {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "TptText" && a.len() == 1 => Ok(TPartTok::TptText(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TptPlaceholder" && a.len() == 3 => Ok(TPartTok::TptPlaceholder(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "TptBlock" && a.len() == 2 => Ok(TPartTok::TptBlock(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "TptCall" && a.len() == 4 => Ok(TPartTok::TptCall(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?, FromPod::from_pod(&a[3])?)),
            other => mismatch("a TPartTok", other),
        }
    }
}

/// `TemplateTok`:
///
/// ```prism
/// type TemplateTok = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TemplateTok {
    pub keyword_p: Text,
    pub lang_p: Text,
    pub delims_p: Text,
    pub parts_p: Array<TPartTok>,
}

impl Show for TemplateTok {
    fn show(&self, p: &mut Printer) {
        p.record("TemplateTok", &[("keyword", &self.keyword_p), ("lang", &self.lang_p), ("delims", &self.delims_p), ("parts", &self.parts_p)]);
    }
}

impl ToPod for TemplateTok {
    fn to_pod(&self) -> Pod {
        Pod::record("TemplateTok", vec![("keyword", self.keyword_p.to_pod()), ("lang", self.lang_p.to_pod()), ("delims", self.delims_p.to_pod()), ("parts", self.parts_p.to_pod())])
    }
}

impl FromPod for TemplateTok {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TemplateTok { keyword_p: FromPod::from_pod(field(p, "keyword")?)?, lang_p: FromPod::from_pod(field(p, "lang")?)?, delims_p: FromPod::from_pod(field(p, "delims")?)?, parts_p: FromPod::from_pod(field(p, "parts")?)? })
    }
}

/// `TextSegTok`:
///
/// ```prism
/// type TextSegTok = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum TextSegTok {
    TsPlain(Text),
    TsPlaceholder(Array<Tok>, crate::syntax::Range),
}

impl Show for TextSegTok {
    fn show(&self, p: &mut Printer) {
        match self {
            TextSegTok::TsPlain(a0) => p.choice("TsPlain", &[a0]),
            TextSegTok::TsPlaceholder(a0, a1) => p.choice("TsPlaceholder", &[a0, a1]),
        }
    }
}

impl ToPod for TextSegTok {
    fn to_pod(&self) -> Pod {
        match self {
            TextSegTok::TsPlain(a0) => Pod::Choice("TsPlain".into(), vec![a0.to_pod()]),
            TextSegTok::TsPlaceholder(a0, a1) => Pod::Choice("TsPlaceholder".into(), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl FromPod for TextSegTok {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "TsPlain" && a.len() == 1 => Ok(TextSegTok::TsPlain(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TsPlaceholder" && a.len() == 2 => Ok(TextSegTok::TsPlaceholder(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            other => mismatch("a TextSegTok", other),
        }
    }
}

/// `Tok`:
///
/// ```prism
/// type Tok = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Tok {
    pub kind_p: TokKind,
    pub span_p: crate::syntax::Range,
    pub touches_p: bool,
    pub line_start_p: bool,
}

impl Show for Tok {
    fn show(&self, p: &mut Printer) {
        p.record("Tok", &[("kind", &self.kind_p), ("span", &self.span_p), ("touches", &self.touches_p), ("lineStart", &self.line_start_p)]);
    }
}

impl ToPod for Tok {
    fn to_pod(&self) -> Pod {
        Pod::record("Tok", vec![("kind", self.kind_p.to_pod()), ("span", self.span_p.to_pod()), ("touches", self.touches_p.to_pod()), ("lineStart", self.line_start_p.to_pod())])
    }
}

impl FromPod for Tok {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Tok { kind_p: FromPod::from_pod(field(p, "kind")?)?, span_p: FromPod::from_pod(field(p, "span")?)?, touches_p: FromPod::from_pod(field(p, "touches")?)?, line_start_p: FromPod::from_pod(field(p, "lineStart")?)? })
    }
}

/// `TokKind`:
///
/// ```prism
/// type TokKind = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum TokKind {
    KName(NameTok),
    KFamily(Array<Text>),
    KTrait(Array<Text>),
    KKw(Text, Text),
    KFree(Text),
    KLensDot,
    KInt(Text, Text),
    KFloat(Text, Text),
    KDuration(Text, Text, Text),
    KChar(Text, Text),
    KText(Text, Array<TextSegTok>),
    KRegex(Text, crate::syntax::RegexLit),
    KTemplate(TemplateTok),
    KOp(Text, bool),
    KSuffixed(Text, Array<Text>),
    KDot(bool),
    KDotDot,
    KComma,
    KColon,
    KSemi,
    KBackslash,
    KLambdaBar(bool),
    KBar,
    KLtLt,
    KGtGt,
    KOpen(Text, bool),
    KClose(Text),
    KAbsent,
    KNonEmpty,
    KPath(Array<PathSegTok>),
    KLayOpen,
    KLaySep,
    KLayClose,
    KEof,
}

impl Show for TokKind {
    fn show(&self, p: &mut Printer) {
        match self {
            TokKind::KName(a0) => p.choice("KName", &[a0]),
            TokKind::KFamily(a0) => p.choice("KFamily", &[a0]),
            TokKind::KTrait(a0) => p.choice("KTrait", &[a0]),
            TokKind::KKw(a0, a1) => p.choice("KKw", &[a0, a1]),
            TokKind::KFree(a0) => p.choice("KFree", &[a0]),
            TokKind::KLensDot => p.choice("KLensDot", &[]),
            TokKind::KInt(a0, a1) => p.choice("KInt", &[a0, a1]),
            TokKind::KFloat(a0, a1) => p.choice("KFloat", &[a0, a1]),
            TokKind::KDuration(a0, a1, a2) => p.choice("KDuration", &[a0, a1, a2]),
            TokKind::KChar(a0, a1) => p.choice("KChar", &[a0, a1]),
            TokKind::KText(a0, a1) => p.choice("KText", &[a0, a1]),
            TokKind::KRegex(a0, a1) => p.choice("KRegex", &[a0, a1]),
            TokKind::KTemplate(a0) => p.choice("KTemplate", &[a0]),
            TokKind::KOp(a0, a1) => p.choice("KOp", &[a0, a1]),
            TokKind::KSuffixed(a0, a1) => p.choice("KSuffixed", &[a0, a1]),
            TokKind::KDot(a0) => p.choice("KDot", &[a0]),
            TokKind::KDotDot => p.choice("KDotDot", &[]),
            TokKind::KComma => p.choice("KComma", &[]),
            TokKind::KColon => p.choice("KColon", &[]),
            TokKind::KSemi => p.choice("KSemi", &[]),
            TokKind::KBackslash => p.choice("KBackslash", &[]),
            TokKind::KLambdaBar(a0) => p.choice("KLambdaBar", &[a0]),
            TokKind::KBar => p.choice("KBar", &[]),
            TokKind::KLtLt => p.choice("KLtLt", &[]),
            TokKind::KGtGt => p.choice("KGtGt", &[]),
            TokKind::KOpen(a0, a1) => p.choice("KOpen", &[a0, a1]),
            TokKind::KClose(a0) => p.choice("KClose", &[a0]),
            TokKind::KAbsent => p.choice("KAbsent", &[]),
            TokKind::KNonEmpty => p.choice("KNonEmpty", &[]),
            TokKind::KPath(a0) => p.choice("KPath", &[a0]),
            TokKind::KLayOpen => p.choice("KLayOpen", &[]),
            TokKind::KLaySep => p.choice("KLaySep", &[]),
            TokKind::KLayClose => p.choice("KLayClose", &[]),
            TokKind::KEof => p.choice("KEof", &[]),
        }
    }
}

impl ToPod for TokKind {
    fn to_pod(&self) -> Pod {
        match self {
            TokKind::KName(a0) => Pod::Choice("KName".into(), vec![a0.to_pod()]),
            TokKind::KFamily(a0) => Pod::Choice("KFamily".into(), vec![a0.to_pod()]),
            TokKind::KTrait(a0) => Pod::Choice("KTrait".into(), vec![a0.to_pod()]),
            TokKind::KKw(a0, a1) => Pod::Choice("KKw".into(), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KFree(a0) => Pod::Choice("KFree".into(), vec![a0.to_pod()]),
            TokKind::KLensDot => Pod::Choice("KLensDot".into(), vec![]),
            TokKind::KInt(a0, a1) => Pod::Choice("KInt".into(), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KFloat(a0, a1) => Pod::Choice("KFloat".into(), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KDuration(a0, a1, a2) => Pod::Choice("KDuration".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            TokKind::KChar(a0, a1) => Pod::Choice("KChar".into(), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KText(a0, a1) => Pod::Choice("KText".into(), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KRegex(a0, a1) => Pod::Choice("KRegex".into(), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KTemplate(a0) => Pod::Choice("KTemplate".into(), vec![a0.to_pod()]),
            TokKind::KOp(a0, a1) => Pod::Choice("KOp".into(), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KSuffixed(a0, a1) => Pod::Choice("KSuffixed".into(), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KDot(a0) => Pod::Choice("KDot".into(), vec![a0.to_pod()]),
            TokKind::KDotDot => Pod::Choice("KDotDot".into(), vec![]),
            TokKind::KComma => Pod::Choice("KComma".into(), vec![]),
            TokKind::KColon => Pod::Choice("KColon".into(), vec![]),
            TokKind::KSemi => Pod::Choice("KSemi".into(), vec![]),
            TokKind::KBackslash => Pod::Choice("KBackslash".into(), vec![]),
            TokKind::KLambdaBar(a0) => Pod::Choice("KLambdaBar".into(), vec![a0.to_pod()]),
            TokKind::KBar => Pod::Choice("KBar".into(), vec![]),
            TokKind::KLtLt => Pod::Choice("KLtLt".into(), vec![]),
            TokKind::KGtGt => Pod::Choice("KGtGt".into(), vec![]),
            TokKind::KOpen(a0, a1) => Pod::Choice("KOpen".into(), vec![a0.to_pod(), a1.to_pod()]),
            TokKind::KClose(a0) => Pod::Choice("KClose".into(), vec![a0.to_pod()]),
            TokKind::KAbsent => Pod::Choice("KAbsent".into(), vec![]),
            TokKind::KNonEmpty => Pod::Choice("KNonEmpty".into(), vec![]),
            TokKind::KPath(a0) => Pod::Choice("KPath".into(), vec![a0.to_pod()]),
            TokKind::KLayOpen => Pod::Choice("KLayOpen".into(), vec![]),
            TokKind::KLaySep => Pod::Choice("KLaySep".into(), vec![]),
            TokKind::KLayClose => Pod::Choice("KLayClose".into(), vec![]),
            TokKind::KEof => Pod::Choice("KEof".into(), vec![]),
        }
    }
}

impl FromPod for TokKind {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "KName" && a.len() == 1 => Ok(TokKind::KName(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "KFamily" && a.len() == 1 => Ok(TokKind::KFamily(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "KTrait" && a.len() == 1 => Ok(TokKind::KTrait(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "KKw" && a.len() == 2 => Ok(TokKind::KKw(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KFree" && a.len() == 1 => Ok(TokKind::KFree(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "KLensDot" && a.len() == 0 => Ok(TokKind::KLensDot),
            Pod::Choice(c, a) if &**c == "KInt" && a.len() == 2 => Ok(TokKind::KInt(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KFloat" && a.len() == 2 => Ok(TokKind::KFloat(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KDuration" && a.len() == 3 => Ok(TokKind::KDuration(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "KChar" && a.len() == 2 => Ok(TokKind::KChar(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KText" && a.len() == 2 => Ok(TokKind::KText(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KRegex" && a.len() == 2 => Ok(TokKind::KRegex(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KTemplate" && a.len() == 1 => Ok(TokKind::KTemplate(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "KOp" && a.len() == 2 => Ok(TokKind::KOp(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KSuffixed" && a.len() == 2 => Ok(TokKind::KSuffixed(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KDot" && a.len() == 1 => Ok(TokKind::KDot(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "KDotDot" && a.len() == 0 => Ok(TokKind::KDotDot),
            Pod::Choice(c, a) if &**c == "KComma" && a.len() == 0 => Ok(TokKind::KComma),
            Pod::Choice(c, a) if &**c == "KColon" && a.len() == 0 => Ok(TokKind::KColon),
            Pod::Choice(c, a) if &**c == "KSemi" && a.len() == 0 => Ok(TokKind::KSemi),
            Pod::Choice(c, a) if &**c == "KBackslash" && a.len() == 0 => Ok(TokKind::KBackslash),
            Pod::Choice(c, a) if &**c == "KLambdaBar" && a.len() == 1 => Ok(TokKind::KLambdaBar(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "KBar" && a.len() == 0 => Ok(TokKind::KBar),
            Pod::Choice(c, a) if &**c == "KLtLt" && a.len() == 0 => Ok(TokKind::KLtLt),
            Pod::Choice(c, a) if &**c == "KGtGt" && a.len() == 0 => Ok(TokKind::KGtGt),
            Pod::Choice(c, a) if &**c == "KOpen" && a.len() == 2 => Ok(TokKind::KOpen(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KClose" && a.len() == 1 => Ok(TokKind::KClose(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "KAbsent" && a.len() == 0 => Ok(TokKind::KAbsent),
            Pod::Choice(c, a) if &**c == "KNonEmpty" && a.len() == 0 => Ok(TokKind::KNonEmpty),
            Pod::Choice(c, a) if &**c == "KPath" && a.len() == 1 => Ok(TokKind::KPath(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "KLayOpen" && a.len() == 0 => Ok(TokKind::KLayOpen),
            Pod::Choice(c, a) if &**c == "KLaySep" && a.len() == 0 => Ok(TokKind::KLaySep),
            Pod::Choice(c, a) if &**c == "KLayClose" && a.len() == 0 => Ok(TokKind::KLayClose),
            Pod::Choice(c, a) if &**c == "KEof" && a.len() == 0 => Ok(TokKind::KEof),
            other => mismatch("a TokKind", other),
        }
    }
}

/// ```prism
/// Fresh: fn Lex, Mode -> Lex
/// ```
pub fn fresh_f(l_p0: &Lex, mode_p1: &Mode) -> Lex {
    Lex { src_p: l_p0.src_p.clone(), pos_p: l_p0.pos_p.clone(), diags_p: l_p0.diags_p.clone(), mode_p: mode_p1.clone(), tokens_p: Array::new(), layout_p: Array::new(), frames_p: Array::new(), last_ws_p: true, lambda_open_p: false, pending_open_p: false, pending_span_p: crate::syntax::Range { start_p: Nat::from(0u32), end_p: Nat::from(0u32) }, line_first_p: Nat::from(0u32), mark_line_start_p: false, first_line_p: true, test_pending_p: Text::lit(""), test_depth_o: None, check_depth_o: None, path_next_p: false }
}

/// ```prism
/// IsLayoutOrEof: fn TokKind -> Bool
/// ```
pub fn is_layout_or_eof_f(tok_kind0: &TokKind) -> bool {
    match tok_kind0 {
        TokKind::KLayOpen => true,
        TokKind::KLaySep => true,
        TokKind::KLayClose => true,
        TokKind::KEof => true,
        _ => false,
    }
}

/// ```prism
/// IsLayout: fn TokKind -> Bool
/// ```
pub fn is_layout_f(tok_kind0: &TokKind) -> bool {
    match tok_kind0 {
        TokKind::KLayOpen => true,
        TokKind::KLaySep => true,
        TokKind::KLayClose => true,
        _ => false,
    }
}

/// ```prism
/// EndsOperand: fn TokKind -> Bool
/// ```
pub fn ends_operand_f(tok_kind0: &TokKind) -> bool {
    match tok_kind0 {
        TokKind::KName(_) => true,
        TokKind::KFamily(_) => true,
        TokKind::KInt(_, _) => true,
        TokKind::KFloat(_, _) => true,
        TokKind::KDuration(_, _, _) => true,
        TokKind::KChar(_, _) => true,
        TokKind::KText(_, _) => true,
        TokKind::KRegex(_, _) => true,
        TokKind::KTemplate(_) => true,
        TokKind::KClose(_) => true,
        TokKind::KGtGt => true,
        TokKind::KNonEmpty => true,
        TokKind::KAbsent => true,
        TokKind::KKw(w_p0, _) => is_value_word_f(w_p0),
        _ => false,
    }
}

/// ```prism
/// IsValueWord: fn Text -> Bool
/// ```
pub fn is_value_word_f(w_p0: &Text) -> bool {
    ((w_p0 == &Text::lit("unit")) || (w_p0 == &Text::lit("nil"))) || is_bound_word_f(w_p0)
}

/// ```prism
/// IsBoundWord: fn Text -> Bool
/// ```
pub fn is_bound_word_f(w_p0: &Text) -> bool {
    (((w_p0 == &Text::lit("key")) || (w_p0 == &Text::lit("ix"))) || (w_p0 == &Text::lit("jx"))) || (w_p0 == &Text::lit("kx"))
}

/// ```prism
/// let keywordList
/// ```
pub fn keyword_list_p() -> Array<Text> {
    Array::from(vec![Text::lit("module"), Text::lit("emit"), Text::lit("use"), Text::lit("type"), Text::lit("record"), Text::lit("choice"), Text::lit("row"), Text::lit("tag"), Text::lit("of"), Text::lit("derive"), Text::lit("trait"), Text::lit("impl"), Text::lit("where"), Text::lit("any"), Text::lit("let"), Text::lit("fn"), Text::lit("test"), Text::lit("check"), Text::lit("widget"), Text::lit("rebuild"), Text::lit("for"), Text::lit("given"), Text::lit("monad"), Text::lit("update"), Text::lit("while"), Text::lit("match"), Text::lit("if"), Text::lit("else"), Text::lit("otherwise"), Text::lit("require"), Text::lit("forbid"), Text::lit("return"), Text::lit("ignore"), Text::lit("then"), Text::lit("on"), Text::lit("not"), Text::lit("and"), Text::lit("or"), Text::lit("mod"), Text::lit("as"), Text::lit("output"), Text::lit("inline_text"), Text::lit("raw"), Text::lit("unbounded"), Text::lit("unit"), Text::lit("nil"), Text::lit("key"), Text::lit("ix"), Text::lit("jx"), Text::lit("kx")])
}

/// ```prism
/// let keywordSet
/// ```
pub fn keyword_set_p() -> Map<Text, bool> {
    crate::prelude::map(&crate::prelude::each(&keyword_list_p(), &(|w_p0: &Text| (w_p0.clone(), true))))
}

/// ```prism
/// IsKeyword: fn Text -> Bool
/// ```
pub fn is_keyword_f(w_p0: &Text) -> bool {
    &crate::prelude::get(&keyword_set_p(), w_p0) != &None
}

/// ```prism
/// TakesSuffix: fn Text -> Bool
/// ```
pub fn takes_suffix_f(op_p0: &Text) -> bool {
    crate::prelude::fold(&Array::from(vec![Text::lit("<="), Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit(">"), Text::lit(">="), Text::lit("+"), Text::lit("-"), Text::lit("*"), Text::lit("/"), Text::lit("+?"), Text::lit("-?"), Text::lit("*?")]), &false, &(|seen_p1: &bool, o_p2: &Text| *seen_p1 || (o_p2 == op_p0)))
}

/// ```prism
/// CloseChar: fn Text -> Text
/// ```
pub fn close_char_f(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("(")) => Text::lit(")"),
        c1_0 if (c1_0 == &Text::lit("[")) => Text::lit("]"),
        _ => Text::lit("}"),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// OpenOf: fn Text -> Text
/// ```
pub fn open_of_f(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit(")")) => Text::lit("("),
        c1_0 if (c1_0 == &Text::lit("]")) => Text::lit("["),
        _ => Text::lit("{"),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// PrefixPosition: fn Lex -> Bool
/// ```
pub fn prefix_position_f(l_p0: &Lex) -> bool {
    l_p0.last_ws_p || no_operand_before_f(&crate::syntax::lexer::chars::last_o(&l_p0.tokens_p))
}

/// ```prism
/// NoOperandBefore: fn ?Tok -> Bool
/// ```
pub fn no_operand_before_f(opt0: &Option<Tok>) -> bool {
    match opt0 {
        None => true,
        Some(t_p0) => !ends_operand_f(&t_p0.kind_p),
    }
}

/// ```prism
/// TestWordOf: fn TokKind -> Text
/// ```
pub fn test_word_of_f(tok_kind0: &TokKind) -> Text {
    match tok_kind0 {
        TokKind::KKw(c0_0_0, _) if (c0_0_0 == &Text::lit("test")) => Text::lit("test"),
        TokKind::KKw(c1_0_0, _) if (c1_0_0 == &Text::lit("check")) => Text::lit("check"),
        _ => Text::lit(""),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// AllLayout: fn [Tok] -> Bool
/// ```
pub fn all_layout_f(ts_p0: &Array<Tok>) -> bool {
    crate::prelude::fold(ts_p0, &true, &(|ok_p1: &bool, t_p2: &Tok| *ok_p1 && is_layout_f(&t_p2.kind_p)))
}

/// ```prism
/// PushTok: fn Lex, TokKind, Nat, Nat -> Lex
/// ```
pub fn push_tok_f(l_p0: &Lex, kind_p1: &TokKind, start_p2: &Nat, end_p3: &Nat) -> Lex {
    let mut this: Lex = l_p0.clone();
    let layout_p4 = is_layout_or_eof_f(kind_p1);
    let touches_p5 = (!this.last_ws_p && (&crate::prelude::len(&this.tokens_p) > &Nat::from(0u32))) && !layout_p4;
    let line_start_p6 = !layout_p4 && this.mark_line_start_p;
    if !layout_p4 {
        this.mark_line_start_p = false;
    }
    let word_p7 = test_word_of_f(kind_p1);
    if (((&word_p7 != &Text::lit("")) && (&this.mode_p == &Mode::MFile)) && (&crate::prelude::len(&this.layout_p) == &Nat::from(1u32))) && all_layout_f(&crate::prelude::drop(&this.tokens_p, &this.line_first_p)) {
        this.test_pending_p = word_p7.clone();
    }
    this.tokens_p = crate::prelude::push(&this.tokens_p, &Tok { kind_p: kind_p1.clone(), span_p: crate::syntax::Range { start_p: start_p2.clone(), end_p: end_p3.clone() }, touches_p: touches_p5, line_start_p: line_start_p6 });
    this.last_ws_p = false;
    this
}

/// ```prism
/// LayoutOn: fn Mode -> Bool
/// ```
pub fn layout_on_f(mode0: &Mode) -> bool {
    match mode0 {
        Mode::MFile => true,
        Mode::MBrace(_) => true,
        _ => false,
    }
}

/// ```prism
/// LayoutActive: fn Lex -> Bool
/// ```
pub fn layout_active_f(l_p0: &Lex) -> bool {
    layout_on_f(&l_p0.mode_p) && (&crate::prelude::len(&l_p0.frames_p) == &Nat::from(0u32))
}

/// ```prism
/// FatArrowOn: fn Lex -> Bool
/// ```
pub fn fat_arrow_on_f(l_p0: &Lex) -> bool {
    (&l_p0.test_depth_o != &None) || (&l_p0.check_depth_o != &None)
}
