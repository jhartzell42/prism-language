//! The module `Syntax.Sexp`, from `target/bootstrap/src/prismc/syntax/sexp.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// Nl: fn Nat -> Text
/// ```
pub fn nl(d: &Nat) -> Text {
    Text::from(format!("\n{}", &indent(d)))
}

/// ```prism
/// Indent: fn Nat -> Text
/// ```
pub fn indent(d: &Nat) -> Text {
    match d.checked_sub(&Nat::from(1u32)) {
        Some(m) => Text::from(format!("  {}", &indent(&m))),
        None => Text::lit(""),
    }
}

/// ```prism
/// Spaced: fn [a], (fn a -> Text) -> Text
/// ```
pub fn spaced<A: Clone + 'static>(xs: &Array<A>, f_fn: &Rc<dyn Fn(A) -> Rc<dyn prism_rtl::Job<Text>>>) -> Text {
    concat(&run_to_end(each_job(xs.clone(), {
        let f_fn = f_fn.clone();
        Rc::new(move |p0: A| {
            let f_fn = f_fn.clone();
            entered(once_job(move || {
                let x = p0;
                call_value((&f_fn)(x.clone()), move |f_1272: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &f_1272))))
            }))
        }) as Rc<dyn Fn(A) -> Rc<dyn prism_rtl::Job<Text>>>
    })))
}

/// ```prism
/// Path: fn [Text] -> Text
/// ```
pub fn path_(p_: &Array<Text>) -> Text {
    crate::syntax::lexer::chars::join(p_, &Text::lit("."))
}

/// ```prism
/// SNameText: fn SName -> Text
/// ```
pub fn sname_text(n: &crate::syntax::SName) -> Text {
    Text::from(format!("{}{}", &n.sigils, &path_(&n.path_)))
}

/// ```prism
/// SexpModule: fn Module -> Text
/// ```
pub fn sexp_module(m: &crate::syntax::Module) -> Text {
    let name = match &m.name {
        Some(n) => Text::from(format!("{}(name {})", &nl(&Nat::from(1u32)), &path_(&n.path_))),
        None => Text::lit(""),
    };
    let emits = match &m.emit_row {
        Some(r) => Text::from(format!("{}(emit {})", &nl(&Nat::from(1u32)), &sexp_row(r))),
        None => Text::lit(""),
    };
    let mods = concat(&each(&m.mods, &(|l: &crate::syntax::ModLine| Text::from(format!("{}({} {})", &nl(&Nat::from(1u32)), &(if l.is_test { Text::lit("test-mod") } else { Text::lit("mod") }), &l.name.name)))));
    let uses = concat(&each(&m.uses, &(|u: &crate::syntax::Use| Text::from(format!("{}(use {}{})", &nl(&Nat::from(1u32)), &path_(&u.target.path_), &(if u.star { Text::lit(".*") } else { Text::lit("") }))))));
    let template = match &m.template {
        Some(t) => Text::from(format!("{}{}", &nl(&Nat::from(1u32)), &sexp_template(t, &Nat::from(1u32)))),
        None => Text::lit(""),
    };
    let decls = concat(&each(&m.decls, &(|d: &crate::syntax::decls::Decl| Text::from(format!("{}{}", &nl(&Nat::from(1u32)), &sexp_decl(d, &Nat::from(1u32)))))));
    Text::from(format!("(module{}{}{}{}{}{})\n", &name, &emits, &mods, &uses, &template, &decls))
}

/// ```prism
/// SexpRow: fn Row -> Text
/// ```
pub fn sexp_row(r: &crate::syntax::Row_) -> Text {
    Text::from(format!("(row{})", &spaced(&r.terms, &{
        let f = Rc::new(sexp_row_term);
        Rc::new(move |a0: crate::syntax::RowTerm| {
            let f = f.clone();
            once_job(move || prism_rtl::Turn::Finished(f(&a0)))
        }) as Rc<dyn Fn(crate::syntax::RowTerm) -> Rc<dyn prism_rtl::Job<Text>>>
    })))
}

/// ```prism
/// SexpRowTerm: fn RowTerm -> Text
/// ```
pub fn sexp_row_term(row_term0: &crate::syntax::RowTerm) -> Text {
    match row_term0 {
        crate::syntax::RowTerm::RFamily(q) => Text::from(format!("{}.*", &path_(&q.path_))),
        crate::syntax::RowTerm::RVar(v_) => Text::from(format!("(var {})", &v_.name)),
        crate::syntax::RowTerm::RType(t) => sexp_type(t),
    }
}

/// ```prism
/// SexpDecl: fn Decl, Nat -> Text
/// ```
pub fn sexp_decl(d: &crate::syntax::decls::Decl, depth: &Nat) -> Text {
    match &d.kind {
        crate::syntax::decls::DeclKind::DSignature(s) => sexp_signature(s),
        crate::syntax::decls::DeclKind::DFn(f) => sexp_fn(f, depth),
        crate::syntax::decls::DeclKind::DLet(l) => Text::from(format!("(let {}{} {})", &sexp_pattern(&l.pattern, depth), &opt_type(&l.ty), &sexp_expr(&l.value, depth))),
        crate::syntax::decls::DeclKind::DWidget(w) => Text::from(format!("(widget {}{})", &sname_text(&w.name), &sexp_block(&w.body, depth))),
        crate::syntax::decls::DeclKind::DType(t) => Text::from(format!("(type {}{}{})", &path_(&t.name.path_), &concat(&each(&t.params, &(|p_: &crate::syntax::Ident| Text::from(format!(" {}", &p_.name))))), &sexp_type_body(&t.body, depth))),
        crate::syntax::decls::DeclKind::DTag(t) => Text::from(format!("(tag {} {}{}{})", &path_(&t.name.path_), &sexp_type(&t.of_type), &sexp_bounds(&t.bounds), &sexp_fields(&t.fields, depth))),
        crate::syntax::decls::DeclKind::DDerive(ts) => Text::from(format!("(derive{})", &concat(&each(ts, &(|t: &crate::syntax::TraitRef| Text::from(format!(" ^{}", &path_(&t.path_)))))))),
        crate::syntax::decls::DeclKind::DTrait(t) => Text::from(format!("(trait ^{}{}{}{})", &path_(&t.name.path_), &concat(&each(&t.params, &(|p_: &crate::syntax::Ident| Text::from(format!(" {}", &p_.name))))), &sexp_bounds(&t.bounds), &sexp_items(&t.items, depth))),
        crate::syntax::decls::DeclKind::DImpl(i) => Text::from(format!("(impl ^{} {}{}{})", &path_(&i.trait_ref.path_), &sexp_type(&i.ty), &sexp_bounds(&i.bounds), &sexp_items(&i.items, depth))),
        crate::syntax::decls::DeclKind::DCheck(c) => Text::from(format!("(check {}{})", &c.name.name, &concat(&each(&c.lines, &(|l: &crate::syntax::decls::CheckLine| Text::from(format!("{}(line {}{})", &nl(&(depth + &Nat::from(1u32))), &sexp_expr(&l.expr, &(depth + &Nat::from(1u32))), &check_pattern(&l.pattern, &(depth + &Nat::from(1u32)))))))))),
        crate::syntax::decls::DeclKind::DTest(t) => sexp_test(t, depth),
        crate::syntax::decls::DeclKind::DStmt(s) => sexp_stmt(s, depth),
    }
}

/// ```prism
/// OptType: fn ?Type -> Text
/// ```
pub fn opt_type(opt0: &Option<crate::syntax::Type>) -> Text {
    match opt0 {
        None => Text::lit(""),
        Some(t) => Text::from(format!(" {}", &sexp_type(t))),
    }
}

/// ```prism
/// CheckPattern: fn ?Pattern, Nat -> Text
/// ```
pub fn check_pattern(opt0: &Option<crate::syntax::Pattern_>, n1: &Nat) -> Text {
    match (opt0, n1) {
        (None, _) => Text::lit(""),
        (Some(p_), d) => Text::from(format!(" => {}", &sexp_pattern(p_, d))),
    }
}

/// ```prism
/// SexpTypeBody: fn ?TypeBody, Nat -> Text
/// ```
pub fn sexp_type_body(opt0: &Option<crate::syntax::decls::TypeBody>, n1: &Nat) -> Text {
    match (opt0, n1) {
        (None, _) => Text::lit(" opaque"),
        (Some(b), depth) => match b {
            crate::syntax::decls::TypeBody::TbRecord(fs) => Text::from(format!(" record{}", &sexp_fields(fs, depth))),
            crate::syntax::decls::TypeBody::TbChoice(cs) => Text::from(format!(" choice{}", &concat(&each(cs, &(|c: &crate::syntax::decls::Case_| Text::from(format!("{}{}", &nl(&(depth + &Nat::from(1u32))), &sexp_case(c)))))))),
            crate::syntax::decls::TypeBody::TbRow => Text::lit(" row"),
            crate::syntax::decls::TypeBody::TbNewtype(c) => Text::from(format!(" newtype {}", &sexp_case(c))),
            crate::syntax::decls::TypeBody::TbUnit(i) => Text::from(format!(" unit {}", &i.name)),
            crate::syntax::decls::TypeBody::TbAlias(t) => Text::from(format!(" alias {}", &sexp_type(t))),
        },
    }
}

/// ```prism
/// SexpSignature: fn Signature -> Text
/// ```
pub fn sexp_signature(s: &crate::syntax::decls::Signature) -> Text {
    Text::from(format!("(sig {} {}{})", &sexp_def_name(&s.name), &sexp_type(&s.ty), &sexp_bounds(&s.bounds)))
}

/// ```prism
/// SexpDefName: fn DefName -> Text
/// ```
pub fn sexp_def_name(def_name0: &crate::syntax::decls::DefName) -> Text {
    match def_name0 {
        crate::syntax::decls::DefName::DefSName(n) => sname_text(n),
        crate::syntax::decls::DefName::DefOp(o, _) => Text::from(format!("(op {})", o)),
    }
}

/// ```prism
/// SexpBounds: fn [Bound] -> Text
/// ```
pub fn sexp_bounds(bs: &Array<crate::syntax::decls::Bound>) -> Text {
    concat(&each(bs, &(|b: &crate::syntax::decls::Bound| Text::from(format!(" (where {}{})", &b.var.name, &concat(&each(&b.traits, &(|t: &crate::syntax::TraitRef| Text::from(format!(" ^{}", &path_(&t.path_)))))))))))
}

/// ```prism
/// SexpFn: fn FnClause, Nat -> Text
/// ```
pub fn sexp_fn(f: &crate::syntax::decls::FnClause, depth: &Nat) -> Text {
    let body = match &f.body {
        crate::syntax::decls::FnBody::BodyExpr(e) => Text::from(format!("{}{}", &nl(&(depth + &Nat::from(1u32))), &sexp_expr(e, &(depth + &Nat::from(1u32))))),
        crate::syntax::decls::FnBody::BodyBlock(b) => sexp_block(b, depth),
    };
    Text::from(format!("(fn {} (params{}){})", &sexp_def_name(&f.name), &concat(&each(&f.params, &(|p_: &crate::syntax::Pattern_| Text::from(format!(" {}", &sexp_pattern(p_, depth)))))), &body))
}

/// ```prism
/// SexpFields: fn [Field], Nat -> Text
/// ```
pub fn sexp_fields(fs: &Array<crate::syntax::decls::Field>, depth: &Nat) -> Text {
    concat(&each(fs, &(|f: &crate::syntax::decls::Field| Text::from(format!("{}(field {} {})", &nl(&(depth + &Nat::from(1u32))), &f.name.name, &sexp_type(&f.ty))))))
}

/// ```prism
/// SexpCase: fn Case -> Text
/// ```
pub fn sexp_case(c: &crate::syntax::decls::Case_) -> Text {
    let indexed_ = match &c.indexed {
        Some(r) => Text::from(format!(" -> {}", &sexp_type(r))),
        None => Text::lit(""),
    };
    Text::from(format!("(case {}{}{})", &sname_text(&c.name), &spaced(&c.args, &{
        let f = Rc::new(sexp_type);
        Rc::new(move |a0: crate::syntax::Type| {
            let f = f.clone();
            once_job(move || prism_rtl::Turn::Finished(f(&a0)))
        }) as Rc<dyn Fn(crate::syntax::Type) -> Rc<dyn prism_rtl::Job<Text>>>
    }), &indexed_))
}

/// ```prism
/// SexpItems: fn [TraitItem], Nat -> Text
/// ```
pub fn sexp_items(items: &Array<crate::syntax::decls::TraitItem>, depth: &Nat) -> Text {
    concat(&each(items, &(|it: &crate::syntax::decls::TraitItem| Text::from(format!("{}{}", &nl(&(depth + &Nat::from(1u32))), &sexp_item(it, &(depth + &Nat::from(1u32))))))))
}

/// ```prism
/// SexpItem: fn TraitItem, Nat -> Text
/// ```
pub fn sexp_item(trait_item0: &crate::syntax::decls::TraitItem, n1: &Nat) -> Text {
    match (trait_item0, n1) {
        (crate::syntax::decls::TraitItem::TiSignature(s), _) => sexp_signature(s),
        (crate::syntax::decls::TraitItem::TiFn(f), d) => sexp_fn(f, d),
        (crate::syntax::decls::TraitItem::TiAssocType(name, params, value_opt, _), _) => Text::from(format!("(assoc-type {}{}{})", &name.name, &concat(&each(params, &(|p_: &crate::syntax::Ident| Text::from(format!(" {}", &p_.name))))), &opt_type(value_opt))),
        (crate::syntax::decls::TraitItem::TiAssocRow(name, _), _) => Text::from(format!("(assoc-row {})", &sname_text(name))),
    }
}

/// ```prism
/// SexpTest: fn TestDecl, Nat -> Text
/// ```
pub fn sexp_test(t: &crate::syntax::decls::TestDecl, depth: &Nat) -> Text {
    let seed = match &t.seed {
        Some(s) => Text::from(format!(" (seed {})", s)),
        None => Text::lit(""),
    };
    Text::from(format!("(test {} {}{}{})", &t.name.name, &sexp_expr(&t.blueprint, depth), &seed, &concat(&each(&t.steps, &(|s: &crate::syntax::decls::TestStep| Text::from(format!("{}{}", &nl(&(depth + &Nat::from(1u32))), &sexp_step(s, &(depth + &Nat::from(1u32))))))))))
}

/// ```prism
/// SexpStep: fn TestStep, Nat -> Text
/// ```
pub fn sexp_step(s: &crate::syntax::decls::TestStep, d: &Nat) -> Text {
    let withs = concat(&each(&s.withs, &(|w: &crate::syntax::decls::Entry| Text::from(format!(" (with {} {})", &sexp_expr(&w.element, d), &sexp_expr(&w.value, d))))));
    let checks = concat(&each(&s.checks, &(|c: &crate::syntax::decls::TestCheck| Text::from(format!("{}{}", &nl(&(d + &Nat::from(1u32))), &sexp_check(c, &(d + &Nat::from(1u32))))))));
    Text::from(format!("(step{} {}{})", &withs, &sexp_action(&s.action, d), &checks))
}

/// ```prism
/// SexpAction: fn StepAction, Nat -> Text
/// ```
pub fn sexp_action(step_action0: &crate::syntax::decls::StepAction, n1: &Nat) -> Text {
    match (step_action0, n1) {
        (crate::syntax::decls::StepAction::SaBuild, _) => Text::lit("build"),
        (crate::syntax::decls::StepAction::SaTick, _) => Text::lit("tick"),
        (crate::syntax::decls::StepAction::SaCompute(true), _) => Text::lit("compute-until-idle"),
        (crate::syntax::decls::StepAction::SaCompute(false), _) => Text::lit("compute"),
        (crate::syntax::decls::StepAction::SaWithOnly, _) => Text::lit("with-only"),
        (crate::syntax::decls::StepAction::SaPush(e), d) => Text::from(format!("(push {} {})", &sexp_expr(&e.element, d), &sexp_expr(&e.value, d))),
        (crate::syntax::decls::StepAction::SaDeliver(ds), d) => crate::syntax::lexer::chars::join(&each(ds, &(|x: &crate::syntax::decls::Delivery| sexp_delivery(x, d))), &Text::lit(" ")),
    }
}

/// ```prism
/// SexpDelivery: fn Delivery, Nat -> Text
/// ```
pub fn sexp_delivery(x: &crate::syntax::decls::Delivery, d: &Nat) -> Text {
    let word = match &x.kind {
        crate::syntax::decls::DeliveryKind::DkSend(_) => Text::lit("send"),
        crate::syntax::decls::DeliveryKind::DkClick => Text::lit("click"),
        crate::syntax::decls::DeliveryKind::DkAnswer => Text::lit("answer"),
    };
    let value = match &x.kind {
        crate::syntax::decls::DeliveryKind::DkSend(v_) => Text::from(format!(" {}", &sexp_expr(v_, d))),
        _ => Text::lit(""),
    };
    Text::from(format!("({} {}{})", &word, &sexp_target(&x.target, d), &value))
}

/// ```prism
/// SexpTarget: fn Target, Nat -> Text
/// ```
pub fn sexp_target(target0: &crate::syntax::decls::Target, d: &Nat) -> Text {
    match target0 {
        crate::syntax::decls::Target::TgPattern(p_) => sexp_pattern(p_, d),
        crate::syntax::decls::Target::TgPath(p_) => sexp_path(&Text::lit("at"), p_, d),
        crate::syntax::decls::Target::TgElement(p_) => sexp_path(&Text::lit("element"), p_, d),
    }
}

/// ```prism
/// SexpPath: fn Text, TestPath, Nat -> Text
/// ```
pub fn sexp_path(word: &Text, p_: &crate::syntax::decls::TestPath, d: &Nat) -> Text {
    Text::from(format!("({}{})", word, &concat(&each(&p_.segments, &(|s: &crate::syntax::decls::PathSeg| sexp_path_seg(s, d))))))
}

/// ```prism
/// SexpPathSeg: fn PathSeg, Nat -> Text
/// ```
pub fn sexp_path_seg(path_seg0: &crate::syntax::decls::PathSeg, n1: &Nat) -> Text {
    match (path_seg0, n1) {
        (crate::syntax::decls::PathSeg::PsNum(n), _) => Text::from(format!(" {}", n)),
        (crate::syntax::decls::PathSeg::PsGen(n), _) => Text::from(format!(" #{}", n)),
        (crate::syntax::decls::PathSeg::PsKey(e), d) => Text::from(format!(" [{}]", &sexp_expr(e, d))),
    }
}

/// ```prism
/// SexpCheck: fn TestCheck, Nat -> Text
/// ```
pub fn sexp_check(c: &crate::syntax::decls::TestCheck, d: &Nat) -> Text {
    match &c.kind {
        crate::syntax::decls::TestCheckKind::CkExpect(p_) => Text::from(format!("(=> expect {})", &sexp_pattern(p_, d))),
        crate::syntax::decls::TestCheckKind::CkExpectNone(p_) => Text::from(format!("(=> expect_none {})", &sexp_pattern(p_, d))),
        crate::syntax::decls::TestCheckKind::CkExpectCount(p_, n) => Text::from(format!("(=> expect_count {} {})", &sexp_pattern(p_, d), n)),
        crate::syntax::decls::TestCheckKind::CkExpectTop(p_) => Text::from(format!("(=> expect_top {})", &sexp_pattern(p_, d))),
        crate::syntax::decls::TestCheckKind::CkExpectTopNone(p_) => Text::from(format!("(=> expect_top_none {})", &sexp_pattern(p_, d))),
        crate::syntax::decls::TestCheckKind::CkRequested(p_, v_) => Text::from(format!("(=> requested {} {})", &sexp_pattern(p_, d), &sexp_pattern(v_, d))),
        crate::syntax::decls::TestCheckKind::CkUnrequested(p_) => Text::from(format!("(=> unrequested {})", &sexp_pattern(p_, d))),
        crate::syntax::decls::TestCheckKind::CkReturns(p_) => Text::from(format!("(=> returns {})", &sexp_pattern(p_, d))),
        crate::syntax::decls::TestCheckKind::CkFired(p_) => Text::from(format!("(=> fired {})", &sexp_pattern(p_, d))),
        crate::syntax::decls::TestCheckKind::CkQuiet => Text::lit("(=> quiet)"),
        crate::syntax::decls::TestCheckKind::CkSettles => Text::lit("(=> settles)"),
        crate::syntax::decls::TestCheckKind::CkAborted => Text::lit("(=> aborted)"),
        crate::syntax::decls::TestCheckKind::CkSnapshot(s) => Text::from(format!("(=> snapshot {})", &crate::syntax::lexer::corpus::debug_text(s))),
    }
}

/// ```prism
/// SexpBlock: fn Block, Nat -> Text
/// ```
pub fn sexp_block(b: &crate::syntax::Block, d: &Nat) -> Text {
    if b.inline {
        Text::from(format!(" (inline{})", &concat(&each(&b.stmts, &(|s: &crate::syntax::Stmt| Text::from(format!(" {}", &sexp_stmt(s, d))))))))
    } else {
        concat(&each(&b.stmts, &(|s: &crate::syntax::Stmt| Text::from(format!("{}{}", &nl(&(d + &Nat::from(1u32))), &sexp_stmt(s, &(d + &Nat::from(1u32))))))))
    }
}

/// ```prism
/// SexpStmt: fn Stmt, Nat -> Text
/// ```
pub fn sexp_stmt(s: &crate::syntax::Stmt, d: &Nat) -> Text {
    match &s.kind {
        crate::syntax::StmtKind::SEmit(r) => Text::from(format!("(emit {})", &sexp_row(r))),
        crate::syntax::StmtKind::SBind(p_, v_, None) => Text::from(format!("(bind {} {})", &sexp_pattern(p_, d), &sexp_expr(v_, d))),
        crate::syntax::StmtKind::SBind(p_, v_, Some(t)) => Text::from(format!("(hold {} {} then {})", &sexp_pattern(p_, d), &sexp_expr(v_, d), &sexp_expr(t, d))),
        crate::syntax::StmtKind::SIgnore(e) => Text::from(format!("(ignore {})", &sexp_expr(e, d))),
        crate::syntax::StmtKind::SLet(p_, ty_opt, v_) => Text::from(format!("(let {}{} {})", &sexp_pattern(p_, d), &opt_type(ty_opt), &sexp_expr(v_, d))),
        crate::syntax::StmtKind::SSignature(sg) => sexp_signature(sg),
        crate::syntax::StmtKind::SFn(f) => sexp_fn(f, d),
        crate::syntax::StmtKind::SWidget(w) => Text::from(format!("(widget {}{})", &sname_text(&w.name), &sexp_block(&w.body, d))),
        crate::syntax::StmtKind::SSet(t, v_) => Text::from(format!("(set {} {})", &sexp_expr(t, d), &sexp_expr(v_, d))),
        crate::syntax::StmtKind::SAccum(t, op, v_) => Text::from(format!("({} {} {})", op, &sexp_expr(t, d), &sexp_expr(v_, d))),
        crate::syntax::StmtKind::SRequire(c) => Text::from(format!("(require {})", &sexp_expr(c, d))),
        crate::syntax::StmtKind::SForbid(c) => Text::from(format!("(forbid {})", &sexp_expr(c, d))),
        crate::syntax::StmtKind::SWhile(c, body) => Text::from(format!("(while {}{})", &sexp_cond(c, d), &sexp_block(body, d))),
        crate::syntax::StmtKind::SReturn(e) => Text::from(format!("(return {})", &sexp_expr(e, d))),
        crate::syntax::StmtKind::SExpr(e) => sexp_expr(e, d),
    }
}

/// ```prism
/// SexpCond: fn Cond, Nat -> Text
/// ```
pub fn sexp_cond(cond0: &crate::syntax::Cond, d: &Nat) -> Text {
    match cond0 {
        crate::syntax::Cond::CondExpr(e) => sexp_expr(&**e, d),
        crate::syntax::Cond::CondBind(p_, v_, g_opt) => Text::from(format!("(<- {} {}{})", &sexp_pattern(p_, d), &sexp_expr(&**v_, d), &sexp_guard(&**g_opt, d))),
    }
}

/// ```prism
/// SexpGuard: fn ?Expr, Nat -> Text
/// ```
pub fn sexp_guard(opt0: &Option<crate::syntax::Expr>, n1: &Nat) -> Text {
    match (opt0, n1) {
        (None, _) => Text::lit(""),
        (Some(g), d) => Text::from(format!(" (if {})", &sexp_expr(g, d))),
    }
}

/// ```prism
/// SexpLiteral: fn Literal, Nat -> Text
/// ```
pub fn sexp_literal(l: &crate::syntax::Literal, d: &Nat) -> Text {
    match &l.kind {
        crate::syntax::LitKind::LInt(s) => Text::from(format!("{}{}", &l.marks, s)),
        crate::syntax::LitKind::LFloat(s) => Text::from(format!("{}{}", &l.marks, s)),
        crate::syntax::LitKind::LDuration(digits, u) => Text::from(format!("{}{}{}", &l.marks, digits, u)),
        crate::syntax::LitKind::LChar(c) => Text::from(format!("{}{}", &l.marks, &crate::syntax::lexer::corpus::debug_char(c))),
        crate::syntax::LitKind::LRegex(r) => match &r.replacement {
            None => Text::from(format!("({}regex {} {})", &l.marks, &crate::syntax::lexer::corpus::debug_text(&r.pattern), &crate::syntax::lexer::corpus::debug_text(&r.flags))),
            Some(t) => Text::from(format!("({}regex-replacement {} {} {})", &l.marks, &crate::syntax::lexer::corpus::debug_text(&r.pattern), &crate::syntax::lexer::corpus::debug_text(t), &crate::syntax::lexer::corpus::debug_text(&r.flags))),
        },
        crate::syntax::LitKind::LText(segs) => if all_plain_segs(segs) {
            Text::from(format!("{}{}", &l.marks, &crate::syntax::lexer::corpus::debug_text(&concat(&each(segs, &plain_seg_text)))))
        } else {
            Text::from(format!("({}text{})", &l.marks, &concat(&each(segs, &(|s: &crate::syntax::TextSeg| Text::from(format!(" {}", &sexp_seg(s, d))))))))
        },
    }
}

/// ```prism
/// AllPlainSegs: fn [TextSeg] -> Bool
/// ```
pub fn all_plain_segs(segs: &Array<crate::syntax::TextSeg>) -> bool {
    fold(segs, &true, &(|ok_: &bool, s: &crate::syntax::TextSeg| *ok_ && is_plain_text_seg(s)))
}

/// ```prism
/// IsPlainTextSeg: fn TextSeg -> Bool
/// ```
pub fn is_plain_text_seg(text_seg0: &crate::syntax::TextSeg) -> bool {
    match text_seg0 {
        crate::syntax::TextSeg::SegPlain(_) => true,
        _ => false,
    }
}

/// ```prism
/// PlainSegText: fn TextSeg -> Text
/// ```
pub fn plain_seg_text(text_seg0: &crate::syntax::TextSeg) -> Text {
    match text_seg0 {
        crate::syntax::TextSeg::SegPlain(s) => s.clone(),
        _ => Text::lit(""),
    }
}

/// ```prism
/// SexpSeg: fn TextSeg, Nat -> Text
/// ```
pub fn sexp_seg(text_seg0: &crate::syntax::TextSeg, n1: &Nat) -> Text {
    match (text_seg0, n1) {
        (crate::syntax::TextSeg::SegPlain(p_), _) => crate::syntax::lexer::corpus::debug_text(p_),
        (crate::syntax::TextSeg::SegPlaceholder(e), d) => Text::from(format!("{{{}}}", &sexp_expr(e, d))),
    }
}

/// ```prism
/// SexpArgs: fn [Arg], Nat -> Text
/// ```
pub fn sexp_args(args: &Array<crate::syntax::Arg>, d: &Nat) -> Text {
    concat(&each(args, &(|a: &crate::syntax::Arg| Text::from(format!(" {}{}", &arg_name(&a.name), &sexp_expr(&a.value, d))))))
}

/// ```prism
/// ArgName: fn ?Ident -> Text
/// ```
pub fn arg_name(opt0: &Option<crate::syntax::Ident>) -> Text {
    match opt0 {
        None => Text::lit(""),
        Some(n) => Text::from(format!("{}=", &n.name)),
    }
}

/// ```prism
/// SexpExprs: fn [Expr], Nat -> Text
/// ```
pub fn sexp_exprs(es: &Array<crate::syntax::Expr>, d: &Nat) -> Text {
    concat(&each(es, &(|x: &crate::syntax::Expr| Text::from(format!(" {}", &sexp_expr(x, d))))))
}

/// ```prism
/// SexpExpr: fn Expr, Nat -> Text
/// ```
pub fn sexp_expr(e: &crate::syntax::Expr, d: &Nat) -> Text {
    match &*e.kind {
        crate::syntax::ExprKind::EName(n) => sname_text(n),
        crate::syntax::ExprKind::ELit(l) => sexp_literal(l, d),
        crate::syntax::ExprKind::EUnit(s) => Text::from(format!("{}unit", s)),
        crate::syntax::ExprKind::ENil(s) => Text::from(format!("{}nil", s)),
        crate::syntax::ExprKind::EBound(b) => b.clone(),
        crate::syntax::ExprKind::ETuple(es) => Text::from(format!("(tuple{})", &sexp_exprs(es, d))),
        crate::syntax::ExprKind::EArray(es) => Text::from(format!("(array{})", &sexp_exprs(es, d))),
        crate::syntax::ExprKind::EMap(es) => Text::from(format!("(map{})", &concat(&each(es, &(|(k, v_): &(crate::syntax::Expr, crate::syntax::Expr)| Text::from(format!(" ({}: {})", &sexp_expr(k, d), &sexp_expr(v_, d)))))))),
        crate::syntax::ExprKind::EGroup(x) => Text::from(format!("(group {})", &sexp_expr(&**x, d))),
        crate::syntax::ExprKind::ECall(callee, args, parens, rest) => Text::from(format!("({} {}{}{})", &(if *parens { Text::lit("call()") } else { Text::lit("call") }), &sexp_expr(&**callee, d), &sexp_args(args, d), &(if *rest { Text::lit(" ..") } else { Text::lit("") }))),
        crate::syntax::ExprKind::EBinary(op, lhs, rhs) => Text::from(format!("({} {} {})", op, &sexp_expr(&**lhs, d), &sexp_expr(&**rhs, d))),
        crate::syntax::ExprKind::ESuffixed(op, ty, lhs, rhs) => Text::from(format!("({}{} {} {})", op, &path_(&ty.path_), &sexp_expr(&**lhs, d), &sexp_expr(&**rhs, d))),
        crate::syntax::ExprKind::EUnary(op, operand) => Text::from(format!("({} {})", op, &sexp_expr(&**operand, d))),
        crate::syntax::ExprKind::EFreeSigil(s, operand) => Text::from(format!("(free{} {})", s, &sexp_expr(&**operand, d))),
        crate::syntax::ExprKind::EField(recv, sigils, name) => Text::from(format!("(. {} {}{})", &sexp_expr(&**recv, d), sigils, &name.name)),
        crate::syntax::ExprKind::EIndex(recv, index_) => Text::from(format!("(index {} {})", &sexp_expr(&**recv, d), &sexp_expr(&**index_, d))),
        crate::syntax::ExprKind::ETopicField(n) => Text::from(format!("(. _ {})", &n.name)),
        crate::syntax::ExprKind::ETopicIndex(i) => Text::from(format!("(index _ {})", &sexp_expr(&**i, d))),
        crate::syntax::ExprKind::EMethod(recv, method, args) => Text::from(format!("(.{} {}{})", &sname_text(method), &sexp_expr(&**recv, d), &sexp_args(args, d))),
        crate::syntax::ExprKind::ETypeArgs(target, types) => Text::from(format!("(<<>> {}{})", &sexp_expr(&**target, d), &spaced(types, &{
            let f = Rc::new(sexp_type);
            Rc::new(move |a0: crate::syntax::Type| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(crate::syntax::Type) -> Rc<dyn prism_rtl::Job<Text>>>
        }))),
        crate::syntax::ExprKind::ECast(x, ty, checked) => Text::from(format!("({} {} {})", &(if *checked { Text::lit("as?") } else { Text::lit("as") }), &sexp_expr(&**x, d), &sexp_type(ty))),
        crate::syntax::ExprKind::ENonEmpty(x) => Text::from(format!("(nonempty {})", &sexp_expr(&**x, d))),
        crate::syntax::ExprKind::EAbsent => Text::lit("absent"),
        crate::syntax::ExprKind::ERest => Text::lit(".."),
        crate::syntax::ExprKind::ELambda(params_opt, body) => Text::from(format!("(lambda{}{})", &sexp_lambda_params(params_opt, d), &sexp_lambda_body(&**body, d))),
        crate::syntax::ExprKind::EIf(c, then_block, else_block_opt) => Text::from(format!("(if {}{}{})", &sexp_cond(&**c, d), &sexp_block(then_block, d), &sexp_else(else_block_opt, d))),
        crate::syntax::ExprKind::EMatch(scrutinee, arms) => Text::from(format!("(match {}{})", &sexp_expr(&**scrutinee, d), &concat(&each(arms, &(|a: &crate::syntax::Arm| Text::from(format!("{}{}", &nl(&(d + &Nat::from(1u32))), &sexp_arm(a, &(d + &Nat::from(1u32)))))))))),
        crate::syntax::ExprKind::ERebuild(scrutinee, body) => Text::from(format!("(rebuild {}{})", &sexp_expr(&**scrutinee, d), &sexp_block(body, d))),
        crate::syntax::ExprKind::EFor(binders_opt, source, body) => Text::from(format!("(for{} {}{})", &sexp_binders(binders_opt, d), &sexp_expr(&**source, d), &sexp_block(body, d))),
        crate::syntax::ExprKind::EGiven(b) => Text::from(format!("(given{})", &sexp_block(b, d))),
        crate::syntax::ExprKind::EUpdate(target, body) => Text::from(format!("(update {}{})", &sexp_expr(&**target, d), &sexp_block(body, d))),
        crate::syntax::ExprKind::EWidgetBlock(b) => Text::from(format!("(@widget{})", &sexp_block(b, d))),
        crate::syntax::ExprKind::EMonad(m, body) => Text::from(format!("(monad {}{})", &sexp_expr(&**m, d), &sexp_block(body, d))),
        crate::syntax::ExprKind::ETemplate(t) => sexp_template(t, d),
        crate::syntax::ExprKind::EAny(x) => Text::from(format!("(any {})", &sexp_expr(&**x, d))),
        crate::syntax::ExprKind::ELens(path__) => Text::from(format!("(lens {})", &crate::syntax::lexer::chars::join(&each(path__, &(|i: &crate::syntax::Ident| i.name.clone())), &Text::lit(".")))),
        crate::syntax::ExprKind::EError => Text::lit("<error>"),
    }
}

/// ```prism
/// SexpLambdaParams: fn ?[Pattern], Nat -> Text
/// ```
pub fn sexp_lambda_params(opt0: &Option<Array<crate::syntax::Pattern_>>, n1: &Nat) -> Text {
    match (opt0, n1) {
        (None, _) => Text::lit(" topic"),
        (Some(ps), d) => Text::from(format!(" (params{})", &concat(&each(ps, &(|p_: &crate::syntax::Pattern_| Text::from(format!(" {}", &sexp_pattern(p_, d)))))))),
    }
}

/// ```prism
/// SexpLambdaBody: fn LambdaBody, Nat -> Text
/// ```
pub fn sexp_lambda_body(lambda_body0: &crate::syntax::LambdaBody, d: &Nat) -> Text {
    match lambda_body0 {
        crate::syntax::LambdaBody::LbExpr(e) => Text::from(format!(" {}", &sexp_expr(&**e, d))),
        crate::syntax::LambdaBody::LbBlock(b) => sexp_block(b, d),
    }
}

/// ```prism
/// SexpElse: fn ?Block, Nat -> Text
/// ```
pub fn sexp_else(opt0: &Option<crate::syntax::Block>, n1: &Nat) -> Text {
    match (opt0, n1) {
        (None, _) => Text::lit(""),
        (Some(b), d) => Text::from(format!("{} else{}", &(if b.inline { Text::lit("") } else { nl(d) }), &sexp_block(b, d))),
    }
}

/// ```prism
/// SexpArm: fn Arm, Nat -> Text
/// ```
pub fn sexp_arm(a: &crate::syntax::Arm, d: &Nat) -> Text {
    let pattern = match &a.pattern {
        Some(p_) => sexp_pattern(p_, d),
        None => Text::lit("otherwise"),
    };
    Text::from(format!("(arm {}{}{})", &pattern, &sexp_guard(&a.guard, d), &sexp_block(&a.body, d)))
}

/// ```prism
/// SexpBinders: fn ?ForBinders, Nat -> Text
/// ```
pub fn sexp_binders(opt0: &Option<crate::syntax::ForBinders>, n1: &Nat) -> Text {
    match (opt0, n1) {
        (None, _) => Text::lit(""),
        (Some(b), d) => {
            let second = match &b.second {
                Some(s) => Text::from(format!(", {}", &sexp_pattern(s, d))),
                None => Text::lit(""),
            };
            Text::from(format!(" {}{} <-", &sexp_pattern(&b.first, d), &second))
        },
    }
}

/// ```prism
/// SexpTemplate: fn Template, Nat -> Text
/// ```
pub fn sexp_template(t: &crate::syntax::Template, d: &Nat) -> Text {
    Text::from(format!("(template {} <{}>{})", &t.keyword, &t.lang, &sexp_parts(&t.parts, &(d + &Nat::from(1u32)))))
}

/// ```prism
/// SexpParts: fn [TemplatePart], Nat -> Text
/// ```
pub fn sexp_parts(parts: &Array<crate::syntax::TemplatePart>, d: &Nat) -> Text {
    concat(&each(parts, &(|p_: &crate::syntax::TemplatePart| Text::from(format!("{}{}", &nl(d), &sexp_part(p_, d))))))
}

/// ```prism
/// SexpPart: fn TemplatePart, Nat -> Text
/// ```
pub fn sexp_part(template_part0: &crate::syntax::TemplatePart, n1: &Nat) -> Text {
    match (template_part0, n1) {
        (crate::syntax::TemplatePart::TpText(s), _) => crate::syntax::lexer::corpus::debug_text(s),
        (crate::syntax::TemplatePart::TpPlaceholder(e, col_opt), d) => Text::from(format!("{{{{{}}}}}{}", &sexp_expr(e, d), &column_text(col_opt))),
        (crate::syntax::TemplatePart::TpBlock(b), d) => Text::from(format!("(brace-block{})", &sexp_block(b, d))),
        (crate::syntax::TemplatePart::TpCall(name, attrs, body_opt, _), d) => Text::from(format!("(call {}{}{})", &sname_text(name), &sexp_args(attrs, d), &call_parts(body_opt, d))),
    }
}

/// ```prism
/// ColumnText: fn ?Nat -> Text
/// ```
pub fn column_text(opt0: &Option<Nat>) -> Text {
    match opt0 {
        None => Text::lit(""),
        Some(c) => Text::from(format!(" @col {}", c)),
    }
}

/// ```prism
/// CallParts: fn ?[TemplatePart], Nat -> Text
/// ```
pub fn call_parts(opt0: &Option<Array<crate::syntax::TemplatePart>>, n1: &Nat) -> Text {
    match (opt0, n1) {
        (None, _) => Text::lit(""),
        (Some(parts), d) => sexp_parts(parts, &(d + &Nat::from(1u32))),
    }
}

/// ```prism
/// SexpPattern: fn Pattern, Nat -> Text
/// ```
pub fn sexp_pattern(p_: &crate::syntax::Pattern_, d: &Nat) -> Text {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => sname_text(n),
        crate::syntax::PatternKind::PIgnore => Text::lit("ignore"),
        crate::syntax::PatternKind::PLit(l) => sexp_literal(l, d),
        crate::syntax::PatternKind::PNeg(l) => Text::from(format!("-{}", &sexp_literal(l, d))),
        crate::syntax::PatternKind::PUnit => Text::lit("unit"),
        crate::syntax::PatternKind::PNil => Text::lit("nil"),
        crate::syntax::PatternKind::PCtor(name, args) => Text::from(format!("(ctor {}{})", &sname_text(name), &concat(&each(args, &(|a: &crate::syntax::Pattern_| Text::from(format!(" {}", &sexp_pattern(a, d)))))))),
        crate::syntax::PatternKind::PRecord(name, fields, rest) => Text::from(format!("(record {}{}{})", &sname_text(name), &concat(&each(fields, &(|f: &crate::syntax::FieldPat| Text::from(format!(" {}{}", &arg_name(&f.name), &sexp_pattern(&f.pattern, d)))))), &(if *rest { Text::lit(" ..") } else { Text::lit("") }))),
        crate::syntax::PatternKind::PSigil(s, inner) => Text::from(format!("(free{} {})", s, &sexp_pattern(&**inner, d))),
        crate::syntax::PatternKind::PTuple(ps) => Text::from(format!("(tuple{})", &concat(&each(ps, &(|x: &crate::syntax::Pattern_| Text::from(format!(" {}", &sexp_pattern(x, d)))))))),
        crate::syntax::PatternKind::PArray(ps) => Text::from(format!("(array{})", &concat(&each(ps, &(|x: &crate::syntax::Pattern_| Text::from(format!(" {}", &sexp_pattern(x, d)))))))),
        crate::syntax::PatternKind::PGroup(x) => Text::from(format!("(group {})", &sexp_pattern(&**x, d))),
        crate::syntax::PatternKind::PFamily(q) => Text::from(format!("{}.*", &path_(&q.path_))),
    }
}

/// ```prism
/// SexpType: fn Type -> Text
/// ```
pub fn sexp_type(t: &crate::syntax::Type) -> Text {
    match &*t.kind {
        crate::syntax::TypeKind::TName(name, m16591_0_1) if (m16591_0_1.len() == 0) => sname_text(name),
        crate::syntax::TypeKind::TName(name, args) => Text::from(format!("({}{})", &sname_text(name), &concat(&each(args, &(|a: &crate::syntax::Type| Text::from(format!(" {}", &sexp_type(a)))))))),
        crate::syntax::TypeKind::TSigiled(sigils, inner) => Text::from(format!("(free{} {})", sigils, &sexp_type(&**inner))),
        crate::syntax::TypeKind::TArray(elem, true) => Text::from(format!("[[{}]]", &sexp_type(&**elem))),
        crate::syntax::TypeKind::TArray(elem, false) => Text::from(format!("[{}]", &sexp_type(&**elem))),
        crate::syntax::TypeKind::TTuple(ts) => Text::from(format!("(tuple{})", &concat(&each(ts, &(|x: &crate::syntax::Type| Text::from(format!(" {}", &sexp_type(x)))))))),
        crate::syntax::TypeKind::TGroup(x) => Text::from(format!("(group {})", &sexp_type(&**x))),
        crate::syntax::TypeKind::TMap(k, v_) => Text::from(format!("(==> {} {})", &sexp_type(&**k), &sexp_type(&**v_))),
        crate::syntax::TypeKind::TFn(color, params, result) => Text::from(format!("({}fn{} -> {})", &color_text(color), &concat(&each(params, &(|x: &crate::syntax::Type| Text::from(format!(" {}", &sexp_type(x)))))), &sexp_type(&**result))),
        crate::syntax::TypeKind::TEmit(ty, r) => Text::from(format!("(emit {} {})", &sexp_type(&**ty), &sexp_type(&**r))),
        crate::syntax::TypeKind::TRowUnion(ts) => Text::from(format!("(|{})", &concat(&each(ts, &(|x: &crate::syntax::Type| Text::from(format!(" {}", &sexp_type(x)))))))),
        crate::syntax::TypeKind::TFamily(q) => Text::from(format!("{}.*", &path_(&q.path_))),
        crate::syntax::TypeKind::TAny(tr) => Text::from(format!("(any ^{})", &path_(&tr.path_))),
        crate::syntax::TypeKind::TUnit(s) => Text::from(format!("{}unit", s)),
        crate::syntax::TypeKind::THole(n) => sname_text(n),
        crate::syntax::TypeKind::TAbsent => Text::lit("absent"),
        crate::syntax::TypeKind::TNonEmpty(x) => Text::from(format!("(nonempty {})", &sexp_type(&**x))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ColorText: fn Color -> Text
/// ```
pub fn color_text(color0: &crate::syntax::Color) -> Text {
    match color0 {
        crate::syntax::Color::Bounded => Text::lit(""),
        crate::syntax::Color::Unbounded => Text::lit("unbounded "),
        crate::syntax::Color::ColorVar(v_) => Text::from(format!("{} ", &v_.name)),
    }
}
