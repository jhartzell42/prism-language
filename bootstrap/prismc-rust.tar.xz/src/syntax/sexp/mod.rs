//! The module `Syntax.Sexp`, from `target/bootstrap/src/prismc/syntax/sexp.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// Nl: fn Nat -> Text
/// ```
pub fn nl_f(d_p0: &Nat) -> Text {
    Text::from(format!("\n{}", &indent_f(d_p0)))
}

/// ```prism
/// Indent: fn Nat -> Text
/// ```
pub fn indent_f(d_p0: &Nat) -> Text {
    match d_p0.checked_sub(&Nat::from(1u32)) {
        Some(m_p1) => Text::from(format!("  {}", &indent_f(&m_p1))),
        None => Text::lit(""),
    }
}

/// ```prism
/// Spaced: fn [a], (fn a -> Text) -> Text
/// ```
pub fn spaced_f<A: Clone + 'static>(xs_p0: &Array<A>, f_f1: &Rc<dyn Fn(A) -> Rc<dyn prism_rtl::Job<Text>>>) -> Text {
    crate::prelude::concat(&crate::prelude::run_to_end(crate::prelude::each_job(xs_p0.clone(), {
        let f_f1x = f_f1.clone();
        Rc::new(move |p0: A| {
            let f_f1xy = f_f1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let x_p2 = p0;
                crate::prelude::call_value((&f_f1xy)(x_p2.clone()), move |f_1176: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &f_1176))))
            }))
        }) as Rc<dyn Fn(A) -> Rc<dyn prism_rtl::Job<Text>>>
    })))
}

/// ```prism
/// Path: fn [Text] -> Text
/// ```
pub fn path_f(p_p0: &Array<Text>) -> Text {
    crate::syntax::lexer::chars::join_f(p_p0, &Text::lit("."))
}

/// ```prism
/// SNameText: fn SName -> Text
/// ```
pub fn sname_text_f(n_p0: &crate::syntax::SName) -> Text {
    Text::from(format!("{}{}", &n_p0.sigils_p, &path_f(&n_p0.path_p)))
}

/// ```prism
/// SexpModule: fn Module -> Text
/// ```
pub fn sexp_module_f(m_p0: &crate::syntax::Module) -> Text {
    let name_p1 = match &m_p0.name_o {
        Some(n_p7) => Text::from(format!("{}(name {})", &nl_f(&Nat::from(1u32)), &path_f(&n_p7.path_p))),
        None => Text::lit(""),
    };
    let emits_p2 = match &m_p0.emit_row_o {
        Some(r_p8) => Text::from(format!("{}(emit {})", &nl_f(&Nat::from(1u32)), &sexp_row_f(r_p8))),
        None => Text::lit(""),
    };
    let mods_p3 = crate::prelude::concat(&crate::prelude::each(&m_p0.mods_p, &(|l_p9: &crate::syntax::ModLine| Text::from(format!("{}({} {})", &nl_f(&Nat::from(1u32)), &(if l_p9.is_test_p { Text::lit("test-mod") } else { Text::lit("mod") }), &l_p9.name_p.name_p)))));
    let uses_p4 = crate::prelude::concat(&crate::prelude::each(&m_p0.uses_p, &(|u_pa: &crate::syntax::Use| Text::from(format!("{}(use {}{})", &nl_f(&Nat::from(1u32)), &path_f(&u_pa.target_p.path_p), &(if u_pa.star_p { Text::lit(".*") } else { Text::lit("") }))))));
    let template_p5 = match &m_p0.template_o {
        Some(t_pb) => Text::from(format!("{}{}", &nl_f(&Nat::from(1u32)), &sexp_template_f(t_pb, &Nat::from(1u32)))),
        None => Text::lit(""),
    };
    let decls_p6 = crate::prelude::concat(&crate::prelude::each(&m_p0.decls_p, &(|d_pc: &crate::syntax::decls::Decl| Text::from(format!("{}{}", &nl_f(&Nat::from(1u32)), &sexp_decl_f(d_pc, &Nat::from(1u32)))))));
    Text::from(format!("(module{}{}{}{}{}{})\n", &name_p1, &emits_p2, &mods_p3, &uses_p4, &template_p5, &decls_p6))
}

/// ```prism
/// SexpRow: fn Row -> Text
/// ```
pub fn sexp_row_f(r_p0: &crate::syntax::Row_) -> Text {
    Text::from(format!("(row{})", &spaced_f(&r_p0.terms_p, &{
        let f = Rc::new(sexp_row_term_f);
        Rc::new(move |a0: crate::syntax::RowTerm| {
            let fy = f.clone();
            crate::prelude::once_job(move || prism_rtl::Turn::Finished(fy(&a0)))
        }) as Rc<dyn Fn(crate::syntax::RowTerm) -> Rc<dyn prism_rtl::Job<Text>>>
    })))
}

/// ```prism
/// SexpRowTerm: fn RowTerm -> Text
/// ```
pub fn sexp_row_term_f(row_term0: &crate::syntax::RowTerm) -> Text {
    match row_term0 {
        crate::syntax::RowTerm::RFamily(q_p0) => Text::from(format!("{}.*", &path_f(&q_p0.path_p))),
        crate::syntax::RowTerm::RVar(v_p1) => Text::from(format!("(var {})", &v_p1.name_p)),
        crate::syntax::RowTerm::RType(t_p2) => sexp_type_f(t_p2),
    }
}

/// ```prism
/// SexpDecl: fn Decl, Nat -> Text
/// ```
pub fn sexp_decl_f(d_p0: &crate::syntax::decls::Decl, depth_p1: &Nat) -> Text {
    match &d_p0.kind_p {
        crate::syntax::decls::DeclKind::DSignature(s_p2) => sexp_signature_f(s_p2),
        crate::syntax::decls::DeclKind::DFn(f_p3) => sexp_fn_f(f_p3, depth_p1),
        crate::syntax::decls::DeclKind::DLet(l_p4) => Text::from(format!("(let {}{} {})", &sexp_pattern_f(&l_p4.pattern_p, depth_p1), &opt_type_f(&l_p4.ty_o), &sexp_expr_f(&l_p4.value_p, depth_p1))),
        crate::syntax::decls::DeclKind::DWidget(w_p5) => Text::from(format!("(widget {}{})", &sname_text_f(&w_p5.name_p), &sexp_block_f(&w_p5.body_p, depth_p1))),
        crate::syntax::decls::DeclKind::DType(t_p6) => Text::from(format!("(type {}{}{})", &path_f(&t_p6.name_p.path_p), &crate::prelude::concat(&crate::prelude::each(&t_p6.params_p, &(|p_p7: &crate::syntax::Ident| Text::from(format!(" {}", &p_p7.name_p))))), &sexp_type_body_f(&t_p6.body_o, depth_p1))),
        crate::syntax::decls::DeclKind::DTag(t_p8) => Text::from(format!("(tag {} {}{}{})", &path_f(&t_p8.name_p.path_p), &sexp_type_f(&t_p8.of_type_p), &sexp_bounds_f(&t_p8.bounds_p), &sexp_fields_f(&t_p8.fields_p, depth_p1))),
        crate::syntax::decls::DeclKind::DDerive(ts_p9) => Text::from(format!("(derive{})", &crate::prelude::concat(&crate::prelude::each(ts_p9, &(|t_pa: &crate::syntax::TraitRef| Text::from(format!(" ^{}", &path_f(&t_pa.path_p)))))))),
        crate::syntax::decls::DeclKind::DTrait(t_pb) => Text::from(format!("(trait ^{}{}{}{})", &path_f(&t_pb.name_p.path_p), &crate::prelude::concat(&crate::prelude::each(&t_pb.params_p, &(|p_pc: &crate::syntax::Ident| Text::from(format!(" {}", &p_pc.name_p))))), &sexp_bounds_f(&t_pb.bounds_p), &sexp_items_f(&t_pb.items_p, depth_p1))),
        crate::syntax::decls::DeclKind::DImpl(i_pd) => Text::from(format!("(impl ^{} {}{}{})", &path_f(&i_pd.trait_ref_p.path_p), &sexp_type_f(&i_pd.ty_p), &sexp_bounds_f(&i_pd.bounds_p), &sexp_items_f(&i_pd.items_p, depth_p1))),
        crate::syntax::decls::DeclKind::DCheck(c_pe) => Text::from(format!("(check {}{})", &c_pe.name_p.name_p, &crate::prelude::concat(&crate::prelude::each(&c_pe.lines_p, &(|l_pf: &crate::syntax::decls::CheckLine| Text::from(format!("{}(line {}{})", &nl_f(&(depth_p1 + &Nat::from(1u32))), &sexp_expr_f(&l_pf.expr_p, &(depth_p1 + &Nat::from(1u32))), &check_pattern_f(&l_pf.pattern_o, &(depth_p1 + &Nat::from(1u32)))))))))),
        crate::syntax::decls::DeclKind::DTest(t_pg) => sexp_test_f(t_pg, depth_p1),
        crate::syntax::decls::DeclKind::DStmt(s_ph) => sexp_stmt_f(s_ph, depth_p1),
    }
}

/// ```prism
/// OptType: fn ?Type -> Text
/// ```
pub fn opt_type_f(opt0: &Option<crate::syntax::Type>) -> Text {
    match opt0 {
        None => Text::lit(""),
        Some(t_p0) => Text::from(format!(" {}", &sexp_type_f(t_p0))),
    }
}

/// ```prism
/// CheckPattern: fn ?Pattern, Nat -> Text
/// ```
pub fn check_pattern_f(opt0: &Option<crate::syntax::Pattern_>, n1: &Nat) -> Text {
    match (opt0, n1) {
        (None, _) => Text::lit(""),
        (Some(p_p0), d_p1) => Text::from(format!(" => {}", &sexp_pattern_f(p_p0, d_p1))),
    }
}

/// ```prism
/// SexpTypeBody: fn ?TypeBody, Nat -> Text
/// ```
pub fn sexp_type_body_f(opt0: &Option<crate::syntax::decls::TypeBody>, n1: &Nat) -> Text {
    match (opt0, n1) {
        (None, _) => Text::lit(" opaque"),
        (Some(b_p0), depth_p1) => match b_p0 {
            crate::syntax::decls::TypeBody::TbRecord(fs_p2) => Text::from(format!(" record{}", &sexp_fields_f(fs_p2, depth_p1))),
            crate::syntax::decls::TypeBody::TbChoice(cs_p3) => Text::from(format!(" choice{}", &crate::prelude::concat(&crate::prelude::each(cs_p3, &(|c_p4: &crate::syntax::decls::Case_| Text::from(format!("{}{}", &nl_f(&(depth_p1 + &Nat::from(1u32))), &sexp_case_f(c_p4)))))))),
            crate::syntax::decls::TypeBody::TbRow => Text::lit(" row"),
            crate::syntax::decls::TypeBody::TbNewtype(c_p5) => Text::from(format!(" newtype {}", &sexp_case_f(c_p5))),
            crate::syntax::decls::TypeBody::TbUnit(i_p6) => Text::from(format!(" unit {}", &i_p6.name_p)),
            crate::syntax::decls::TypeBody::TbAlias(t_p7) => Text::from(format!(" alias {}", &sexp_type_f(t_p7))),
        },
    }
}

/// ```prism
/// SexpSignature: fn Signature -> Text
/// ```
pub fn sexp_signature_f(s_p0: &crate::syntax::decls::Signature) -> Text {
    Text::from(format!("(sig {} {}{})", &sexp_def_name_f(&s_p0.name_p), &sexp_type_f(&s_p0.ty_p), &sexp_bounds_f(&s_p0.bounds_p)))
}

/// ```prism
/// SexpDefName: fn DefName -> Text
/// ```
pub fn sexp_def_name_f(def_name0: &crate::syntax::decls::DefName) -> Text {
    match def_name0 {
        crate::syntax::decls::DefName::DefSName(n_p0) => sname_text_f(n_p0),
        crate::syntax::decls::DefName::DefOp(o_p1, _) => Text::from(format!("(op {})", o_p1)),
    }
}

/// ```prism
/// SexpBounds: fn [Bound] -> Text
/// ```
pub fn sexp_bounds_f(bs_p0: &Array<crate::syntax::decls::Bound>) -> Text {
    crate::prelude::concat(&crate::prelude::each(bs_p0, &(|b_p1: &crate::syntax::decls::Bound| Text::from(format!(" (where {}{})", &b_p1.var_p.name_p, &crate::prelude::concat(&crate::prelude::each(&b_p1.traits_p, &(|t_p2: &crate::syntax::TraitRef| Text::from(format!(" ^{}", &path_f(&t_p2.path_p)))))))))))
}

/// ```prism
/// SexpFn: fn FnClause, Nat -> Text
/// ```
pub fn sexp_fn_f(f_p0: &crate::syntax::decls::FnClause, depth_p1: &Nat) -> Text {
    let body_p2 = match &f_p0.body_p {
        crate::syntax::decls::FnBody::BodyExpr(e_p3) => Text::from(format!("{}{}", &nl_f(&(depth_p1 + &Nat::from(1u32))), &sexp_expr_f(e_p3, &(depth_p1 + &Nat::from(1u32))))),
        crate::syntax::decls::FnBody::BodyBlock(b_p4) => sexp_block_f(b_p4, depth_p1),
    };
    Text::from(format!("(fn {} (params{}){})", &sexp_def_name_f(&f_p0.name_p), &crate::prelude::concat(&crate::prelude::each(&f_p0.params_p, &(|p_p5: &crate::syntax::Pattern_| Text::from(format!(" {}", &sexp_pattern_f(p_p5, depth_p1)))))), &body_p2))
}

/// ```prism
/// SexpFields: fn [Field], Nat -> Text
/// ```
pub fn sexp_fields_f(fs_p0: &Array<crate::syntax::decls::Field>, depth_p1: &Nat) -> Text {
    crate::prelude::concat(&crate::prelude::each(fs_p0, &(|f_p2: &crate::syntax::decls::Field| Text::from(format!("{}(field {} {})", &nl_f(&(depth_p1 + &Nat::from(1u32))), &f_p2.name_p.name_p, &sexp_type_f(&f_p2.ty_p))))))
}

/// ```prism
/// SexpCase: fn Case -> Text
/// ```
pub fn sexp_case_f(c_p0: &crate::syntax::decls::Case_) -> Text {
    let indexed_p1 = match &c_p0.indexed_o {
        Some(r_p2) => Text::from(format!(" -> {}", &sexp_type_f(r_p2))),
        None => Text::lit(""),
    };
    Text::from(format!("(case {}{}{})", &sname_text_f(&c_p0.name_p), &spaced_f(&c_p0.args_p, &{
        let f = Rc::new(sexp_type_f);
        Rc::new(move |a0: crate::syntax::Type| {
            let fy = f.clone();
            crate::prelude::once_job(move || prism_rtl::Turn::Finished(fy(&a0)))
        }) as Rc<dyn Fn(crate::syntax::Type) -> Rc<dyn prism_rtl::Job<Text>>>
    }), &indexed_p1))
}

/// ```prism
/// SexpItems: fn [TraitItem], Nat -> Text
/// ```
pub fn sexp_items_f(items_p0: &Array<crate::syntax::decls::TraitItem>, depth_p1: &Nat) -> Text {
    crate::prelude::concat(&crate::prelude::each(items_p0, &(|it_p2: &crate::syntax::decls::TraitItem| Text::from(format!("{}{}", &nl_f(&(depth_p1 + &Nat::from(1u32))), &sexp_item_f(it_p2, &(depth_p1 + &Nat::from(1u32))))))))
}

/// ```prism
/// SexpItem: fn TraitItem, Nat -> Text
/// ```
pub fn sexp_item_f(trait_item0: &crate::syntax::decls::TraitItem, n1: &Nat) -> Text {
    match (trait_item0, n1) {
        (crate::syntax::decls::TraitItem::TiSignature(s_p0), _) => sexp_signature_f(s_p0),
        (crate::syntax::decls::TraitItem::TiFn(f_p1), d_p2) => sexp_fn_f(f_p1, d_p2),
        (crate::syntax::decls::TraitItem::TiAssocType(name_p3, params_p4, value_o5, _), _) => Text::from(format!("(assoc-type {}{}{})", &name_p3.name_p, &crate::prelude::concat(&crate::prelude::each(params_p4, &(|p_p6: &crate::syntax::Ident| Text::from(format!(" {}", &p_p6.name_p))))), &opt_type_f(value_o5))),
        (crate::syntax::decls::TraitItem::TiAssocRow(name_p7, _), _) => Text::from(format!("(assoc-row {})", &sname_text_f(name_p7))),
    }
}

/// ```prism
/// SexpTest: fn TestDecl, Nat -> Text
/// ```
pub fn sexp_test_f(t_p0: &crate::syntax::decls::TestDecl, depth_p1: &Nat) -> Text {
    let seed_p2 = match &t_p0.seed_o {
        Some(s_p3) => Text::from(format!(" (seed {})", s_p3)),
        None => Text::lit(""),
    };
    Text::from(format!("(test {} {}{}{})", &t_p0.name_p.name_p, &sexp_expr_f(&t_p0.blueprint_p, depth_p1), &seed_p2, &crate::prelude::concat(&crate::prelude::each(&t_p0.steps_p, &(|s_p4: &crate::syntax::decls::TestStep| Text::from(format!("{}{}", &nl_f(&(depth_p1 + &Nat::from(1u32))), &sexp_step_f(s_p4, &(depth_p1 + &Nat::from(1u32))))))))))
}

/// ```prism
/// SexpStep: fn TestStep, Nat -> Text
/// ```
pub fn sexp_step_f(s_p0: &crate::syntax::decls::TestStep, d_p1: &Nat) -> Text {
    let withs_p2 = crate::prelude::concat(&crate::prelude::each(&s_p0.withs_p, &(|w_p4: &crate::syntax::decls::Entry| Text::from(format!(" (with {} {})", &sexp_expr_f(&w_p4.element_p, d_p1), &sexp_expr_f(&w_p4.value_p, d_p1))))));
    let checks_p3 = crate::prelude::concat(&crate::prelude::each(&s_p0.checks_p, &(|c_p5: &crate::syntax::decls::TestCheck| Text::from(format!("{}{}", &nl_f(&(d_p1 + &Nat::from(1u32))), &sexp_check_f(c_p5, &(d_p1 + &Nat::from(1u32))))))));
    Text::from(format!("(step{} {}{})", &withs_p2, &sexp_action_f(&s_p0.action_p, d_p1), &checks_p3))
}

/// ```prism
/// SexpAction: fn StepAction, Nat -> Text
/// ```
pub fn sexp_action_f(step_action0: &crate::syntax::decls::StepAction, n1: &Nat) -> Text {
    match (step_action0, n1) {
        (crate::syntax::decls::StepAction::SaBuild, _) => Text::lit("build"),
        (crate::syntax::decls::StepAction::SaTick, _) => Text::lit("tick"),
        (crate::syntax::decls::StepAction::SaCompute(true), _) => Text::lit("compute-until-idle"),
        (crate::syntax::decls::StepAction::SaCompute(false), _) => Text::lit("compute"),
        (crate::syntax::decls::StepAction::SaWithOnly, _) => Text::lit("with-only"),
        (crate::syntax::decls::StepAction::SaPush(e_p0), d_p1) => Text::from(format!("(push {} {})", &sexp_expr_f(&e_p0.element_p, d_p1), &sexp_expr_f(&e_p0.value_p, d_p1))),
        (crate::syntax::decls::StepAction::SaDeliver(ds_p2), d_p3) => crate::syntax::lexer::chars::join_f(&crate::prelude::each(ds_p2, &(|x_p4: &crate::syntax::decls::Delivery| sexp_delivery_f(x_p4, d_p3))), &Text::lit(" ")),
    }
}

/// ```prism
/// SexpDelivery: fn Delivery, Nat -> Text
/// ```
pub fn sexp_delivery_f(x_p0: &crate::syntax::decls::Delivery, d_p1: &Nat) -> Text {
    let word_p2 = match &x_p0.kind_p {
        crate::syntax::decls::DeliveryKind::DkSend(_) => Text::lit("send"),
        crate::syntax::decls::DeliveryKind::DkClick => Text::lit("click"),
        crate::syntax::decls::DeliveryKind::DkAnswer => Text::lit("answer"),
    };
    let value_p3 = match &x_p0.kind_p {
        crate::syntax::decls::DeliveryKind::DkSend(v_p4) => Text::from(format!(" {}", &sexp_expr_f(v_p4, d_p1))),
        _ => Text::lit(""),
    };
    Text::from(format!("({} {}{})", &word_p2, &sexp_target_f(&x_p0.target_p, d_p1), &value_p3))
}

/// ```prism
/// SexpTarget: fn Target, Nat -> Text
/// ```
pub fn sexp_target_f(target0: &crate::syntax::decls::Target, d_p1: &Nat) -> Text {
    match target0 {
        crate::syntax::decls::Target::TgPattern(p_p0) => sexp_pattern_f(p_p0, d_p1),
        crate::syntax::decls::Target::TgPath(p_p2) => sexp_path_f(&Text::lit("at"), p_p2, d_p1),
        crate::syntax::decls::Target::TgElement(p_p4) => sexp_path_f(&Text::lit("element"), p_p4, d_p1),
    }
}

/// ```prism
/// SexpPath: fn Text, TestPath, Nat -> Text
/// ```
pub fn sexp_path_f(word_p0: &Text, p_p1: &crate::syntax::decls::TestPath, d_p2: &Nat) -> Text {
    Text::from(format!("({}{})", word_p0, &crate::prelude::concat(&crate::prelude::each(&p_p1.segments_p, &(|s_p3: &crate::syntax::decls::PathSeg| sexp_path_seg_f(s_p3, d_p2))))))
}

/// ```prism
/// SexpPathSeg: fn PathSeg, Nat -> Text
/// ```
pub fn sexp_path_seg_f(path_seg0: &crate::syntax::decls::PathSeg, n1: &Nat) -> Text {
    match (path_seg0, n1) {
        (crate::syntax::decls::PathSeg::PsNum(n_p0), _) => Text::from(format!(" {}", n_p0)),
        (crate::syntax::decls::PathSeg::PsGen(n_p1), _) => Text::from(format!(" #{}", n_p1)),
        (crate::syntax::decls::PathSeg::PsKey(e_p2), d_p3) => Text::from(format!(" [{}]", &sexp_expr_f(e_p2, d_p3))),
    }
}

/// ```prism
/// SexpCheck: fn TestCheck, Nat -> Text
/// ```
pub fn sexp_check_f(c_p0: &crate::syntax::decls::TestCheck, d_p1: &Nat) -> Text {
    match &c_p0.kind_p {
        crate::syntax::decls::TestCheckKind::CkExpect(p_p2) => Text::from(format!("(=> expect {})", &sexp_pattern_f(p_p2, d_p1))),
        crate::syntax::decls::TestCheckKind::CkExpectNone(p_p3) => Text::from(format!("(=> expect_none {})", &sexp_pattern_f(p_p3, d_p1))),
        crate::syntax::decls::TestCheckKind::CkExpectCount(p_p4, n_p5) => Text::from(format!("(=> expect_count {} {})", &sexp_pattern_f(p_p4, d_p1), n_p5)),
        crate::syntax::decls::TestCheckKind::CkExpectTop(p_p6) => Text::from(format!("(=> expect_top {})", &sexp_pattern_f(p_p6, d_p1))),
        crate::syntax::decls::TestCheckKind::CkExpectTopNone(p_p7) => Text::from(format!("(=> expect_top_none {})", &sexp_pattern_f(p_p7, d_p1))),
        crate::syntax::decls::TestCheckKind::CkRequested(p_p8, v_p9) => Text::from(format!("(=> requested {} {})", &sexp_pattern_f(p_p8, d_p1), &sexp_pattern_f(v_p9, d_p1))),
        crate::syntax::decls::TestCheckKind::CkUnrequested(p_pa) => Text::from(format!("(=> unrequested {})", &sexp_pattern_f(p_pa, d_p1))),
        crate::syntax::decls::TestCheckKind::CkReturns(p_pb) => Text::from(format!("(=> returns {})", &sexp_pattern_f(p_pb, d_p1))),
        crate::syntax::decls::TestCheckKind::CkFired(p_pc) => Text::from(format!("(=> fired {})", &sexp_pattern_f(p_pc, d_p1))),
        crate::syntax::decls::TestCheckKind::CkQuiet => Text::lit("(=> quiet)"),
        crate::syntax::decls::TestCheckKind::CkSettles => Text::lit("(=> settles)"),
        crate::syntax::decls::TestCheckKind::CkAborted => Text::lit("(=> aborted)"),
        crate::syntax::decls::TestCheckKind::CkSnapshot(s_pd) => Text::from(format!("(=> snapshot {})", &crate::syntax::lexer::corpus::debug_text_f(s_pd))),
    }
}

/// ```prism
/// SexpBlock: fn Block, Nat -> Text
/// ```
pub fn sexp_block_f(b_p0: &crate::syntax::Block, d_p1: &Nat) -> Text {
    if b_p0.inline_p {
        Text::from(format!(" (inline{})", &crate::prelude::concat(&crate::prelude::each(&b_p0.stmts_p, &(|s_p2: &crate::syntax::Stmt| Text::from(format!(" {}", &sexp_stmt_f(s_p2, d_p1))))))))
    } else {
        crate::prelude::concat(&crate::prelude::each(&b_p0.stmts_p, &(|s_p3: &crate::syntax::Stmt| Text::from(format!("{}{}", &nl_f(&(d_p1 + &Nat::from(1u32))), &sexp_stmt_f(s_p3, &(d_p1 + &Nat::from(1u32))))))))
    }
}

/// ```prism
/// SexpStmt: fn Stmt, Nat -> Text
/// ```
pub fn sexp_stmt_f(s_p0: &crate::syntax::Stmt, d_p1: &Nat) -> Text {
    match &s_p0.kind_p {
        crate::syntax::StmtKind::SEmit(r_p2) => Text::from(format!("(emit {})", &sexp_row_f(r_p2))),
        crate::syntax::StmtKind::SBind(p_p3, v_p4, None) => Text::from(format!("(bind {} {})", &sexp_pattern_f(p_p3, d_p1), &sexp_expr_f(v_p4, d_p1))),
        crate::syntax::StmtKind::SBind(p_p5, v_p6, Some(t_p7)) => Text::from(format!("(hold {} {} then {})", &sexp_pattern_f(p_p5, d_p1), &sexp_expr_f(v_p6, d_p1), &sexp_expr_f(t_p7, d_p1))),
        crate::syntax::StmtKind::SIgnore(e_p8) => Text::from(format!("(ignore {})", &sexp_expr_f(e_p8, d_p1))),
        crate::syntax::StmtKind::SLet(p_p9, ty_oa, v_pb) => Text::from(format!("(let {}{} {})", &sexp_pattern_f(p_p9, d_p1), &opt_type_f(ty_oa), &sexp_expr_f(v_pb, d_p1))),
        crate::syntax::StmtKind::SSignature(sg_pc) => sexp_signature_f(sg_pc),
        crate::syntax::StmtKind::SFn(f_pd) => sexp_fn_f(f_pd, d_p1),
        crate::syntax::StmtKind::SWidget(w_pe) => Text::from(format!("(widget {}{})", &sname_text_f(&w_pe.name_p), &sexp_block_f(&w_pe.body_p, d_p1))),
        crate::syntax::StmtKind::SSet(t_pf, v_pg) => Text::from(format!("(set {} {})", &sexp_expr_f(t_pf, d_p1), &sexp_expr_f(v_pg, d_p1))),
        crate::syntax::StmtKind::SAccum(t_ph, op_pi, v_pj) => Text::from(format!("({} {} {})", op_pi, &sexp_expr_f(t_ph, d_p1), &sexp_expr_f(v_pj, d_p1))),
        crate::syntax::StmtKind::SRequire(c_pk) => Text::from(format!("(require {})", &sexp_expr_f(c_pk, d_p1))),
        crate::syntax::StmtKind::SForbid(c_pl) => Text::from(format!("(forbid {})", &sexp_expr_f(c_pl, d_p1))),
        crate::syntax::StmtKind::SWhile(c_pm, body_pn) => Text::from(format!("(while {}{})", &sexp_cond_f(c_pm, d_p1), &sexp_block_f(body_pn, d_p1))),
        crate::syntax::StmtKind::SReturn(e_po) => Text::from(format!("(return {})", &sexp_expr_f(e_po, d_p1))),
        crate::syntax::StmtKind::SExpr(e_pp) => sexp_expr_f(e_pp, d_p1),
    }
}

/// ```prism
/// SexpCond: fn Cond, Nat -> Text
/// ```
pub fn sexp_cond_f(cond0: &crate::syntax::Cond, d_p1: &Nat) -> Text {
    match cond0 {
        crate::syntax::Cond::CondExpr(e_p0) => sexp_expr_f(&**e_p0, d_p1),
        crate::syntax::Cond::CondBind(p_p2, v_p3, g_o4) => Text::from(format!("(<- {} {}{})", &sexp_pattern_f(p_p2, d_p1), &sexp_expr_f(&**v_p3, d_p1), &sexp_guard_f(&**g_o4, d_p1))),
    }
}

/// ```prism
/// SexpGuard: fn ?Expr, Nat -> Text
/// ```
pub fn sexp_guard_f(opt0: &Option<crate::syntax::Expr>, n1: &Nat) -> Text {
    match (opt0, n1) {
        (None, _) => Text::lit(""),
        (Some(g_p0), d_p1) => Text::from(format!(" (if {})", &sexp_expr_f(g_p0, d_p1))),
    }
}

/// ```prism
/// SexpLiteral: fn Literal, Nat -> Text
/// ```
pub fn sexp_literal_f(l_p0: &crate::syntax::Literal, d_p1: &Nat) -> Text {
    match &l_p0.kind_p {
        crate::syntax::LitKind::LInt(s_p2) => Text::from(format!("{}{}", &l_p0.marks_p, s_p2)),
        crate::syntax::LitKind::LFloat(s_p3) => Text::from(format!("{}{}", &l_p0.marks_p, s_p3)),
        crate::syntax::LitKind::LDuration(digits_p4, u_p5) => Text::from(format!("{}{}{}", &l_p0.marks_p, digits_p4, u_p5)),
        crate::syntax::LitKind::LChar(c_p6) => Text::from(format!("{}{}", &l_p0.marks_p, &crate::syntax::lexer::corpus::debug_char_f(c_p6))),
        crate::syntax::LitKind::LRegex(r_p7) => match &r_p7.replacement_o {
            None => Text::from(format!("({}regex {} {})", &l_p0.marks_p, &crate::syntax::lexer::corpus::debug_text_f(&r_p7.pattern_p), &crate::syntax::lexer::corpus::debug_text_f(&r_p7.flags_p))),
            Some(t_p8) => Text::from(format!("({}regex-replacement {} {} {})", &l_p0.marks_p, &crate::syntax::lexer::corpus::debug_text_f(&r_p7.pattern_p), &crate::syntax::lexer::corpus::debug_text_f(t_p8), &crate::syntax::lexer::corpus::debug_text_f(&r_p7.flags_p))),
        },
        crate::syntax::LitKind::LText(segs_p9) => if all_plain_segs_f(segs_p9) {
            Text::from(format!("{}{}", &l_p0.marks_p, &crate::syntax::lexer::corpus::debug_text_f(&crate::prelude::concat(&crate::prelude::each(segs_p9, &plain_seg_text_f)))))
        } else {
            Text::from(format!("({}text{})", &l_p0.marks_p, &crate::prelude::concat(&crate::prelude::each(segs_p9, &(|s_pa: &crate::syntax::TextSeg| Text::from(format!(" {}", &sexp_seg_f(s_pa, d_p1))))))))
        },
    }
}

/// ```prism
/// AllPlainSegs: fn [TextSeg] -> Bool
/// ```
pub fn all_plain_segs_f(segs_p0: &Array<crate::syntax::TextSeg>) -> bool {
    crate::prelude::fold(segs_p0, &true, &(|ok_p1: &bool, s_p2: &crate::syntax::TextSeg| *ok_p1 && is_plain_text_seg_f(s_p2)))
}

/// ```prism
/// IsPlainTextSeg: fn TextSeg -> Bool
/// ```
pub fn is_plain_text_seg_f(text_seg0: &crate::syntax::TextSeg) -> bool {
    match text_seg0 {
        crate::syntax::TextSeg::SegPlain(_) => true,
        _ => false,
    }
}

/// ```prism
/// PlainSegText: fn TextSeg -> Text
/// ```
pub fn plain_seg_text_f(text_seg0: &crate::syntax::TextSeg) -> Text {
    match text_seg0 {
        crate::syntax::TextSeg::SegPlain(s_p0) => s_p0.clone(),
        _ => Text::lit(""),
    }
}

/// ```prism
/// SexpSeg: fn TextSeg, Nat -> Text
/// ```
pub fn sexp_seg_f(text_seg0: &crate::syntax::TextSeg, n1: &Nat) -> Text {
    match (text_seg0, n1) {
        (crate::syntax::TextSeg::SegPlain(p_p0), _) => crate::syntax::lexer::corpus::debug_text_f(p_p0),
        (crate::syntax::TextSeg::SegPlaceholder(e_p1), d_p2) => Text::from(format!("{{{}}}", &sexp_expr_f(e_p1, d_p2))),
    }
}

/// ```prism
/// SexpArgs: fn [Arg], Nat -> Text
/// ```
pub fn sexp_args_f(args_p0: &Array<crate::syntax::Arg>, d_p1: &Nat) -> Text {
    crate::prelude::concat(&crate::prelude::each(args_p0, &(|a_p2: &crate::syntax::Arg| Text::from(format!(" {}{}", &arg_name_f(&a_p2.name_o), &sexp_expr_f(&a_p2.value_p, d_p1))))))
}

/// ```prism
/// ArgName: fn ?Ident -> Text
/// ```
pub fn arg_name_f(opt0: &Option<crate::syntax::Ident>) -> Text {
    match opt0 {
        None => Text::lit(""),
        Some(n_p0) => Text::from(format!("{}=", &n_p0.name_p)),
    }
}

/// ```prism
/// SexpExprs: fn [Expr], Nat -> Text
/// ```
pub fn sexp_exprs_f(es_p0: &Array<crate::syntax::Expr>, d_p1: &Nat) -> Text {
    crate::prelude::concat(&crate::prelude::each(es_p0, &(|x_p2: &crate::syntax::Expr| Text::from(format!(" {}", &sexp_expr_f(x_p2, d_p1))))))
}

/// ```prism
/// SexpExpr: fn Expr, Nat -> Text
/// ```
pub fn sexp_expr_f(e_p0: &crate::syntax::Expr, d_p1: &Nat) -> Text {
    match &*e_p0.kind_p {
        crate::syntax::ExprKind::EName(n_p2) => sname_text_f(n_p2),
        crate::syntax::ExprKind::ELit(l_p3) => sexp_literal_f(l_p3, d_p1),
        crate::syntax::ExprKind::EUnit(s_p4) => Text::from(format!("{}unit", s_p4)),
        crate::syntax::ExprKind::ENil(s_p5) => Text::from(format!("{}nil", s_p5)),
        crate::syntax::ExprKind::EBound(b_p6) => b_p6.clone(),
        crate::syntax::ExprKind::ETuple(es_p7) => Text::from(format!("(tuple{})", &sexp_exprs_f(es_p7, d_p1))),
        crate::syntax::ExprKind::EArray(es_p8) => Text::from(format!("(array{})", &sexp_exprs_f(es_p8, d_p1))),
        crate::syntax::ExprKind::EMap(es_p9) => Text::from(format!("(map{})", &crate::prelude::concat(&crate::prelude::each(es_p9, &(|(k_pa, v_pb): &(crate::syntax::Expr, crate::syntax::Expr)| Text::from(format!(" ({}: {})", &sexp_expr_f(k_pa, d_p1), &sexp_expr_f(v_pb, d_p1)))))))),
        crate::syntax::ExprKind::EGroup(x_pc) => Text::from(format!("(group {})", &sexp_expr_f(&**x_pc, d_p1))),
        crate::syntax::ExprKind::ECall(callee_pd, args_pe, parens_pf, rest_pg) => Text::from(format!("({} {}{}{})", &(if *parens_pf { Text::lit("call()") } else { Text::lit("call") }), &sexp_expr_f(&**callee_pd, d_p1), &sexp_args_f(args_pe, d_p1), &(if *rest_pg { Text::lit(" ..") } else { Text::lit("") }))),
        crate::syntax::ExprKind::EBinary(op_ph, lhs_pi, rhs_pj) => Text::from(format!("({} {} {})", op_ph, &sexp_expr_f(&**lhs_pi, d_p1), &sexp_expr_f(&**rhs_pj, d_p1))),
        crate::syntax::ExprKind::ESuffixed(op_pk, ty_pl, lhs_pm, rhs_pn) => Text::from(format!("({}{} {} {})", op_pk, &path_f(&ty_pl.path_p), &sexp_expr_f(&**lhs_pm, d_p1), &sexp_expr_f(&**rhs_pn, d_p1))),
        crate::syntax::ExprKind::EUnary(op_po, operand_pp) => Text::from(format!("({} {})", op_po, &sexp_expr_f(&**operand_pp, d_p1))),
        crate::syntax::ExprKind::EFreeSigil(s_pq, operand_pr) => Text::from(format!("(free{} {})", s_pq, &sexp_expr_f(&**operand_pr, d_p1))),
        crate::syntax::ExprKind::EField(recv_ps, sigils_pt, name_pu) => Text::from(format!("(. {} {}{})", &sexp_expr_f(&**recv_ps, d_p1), sigils_pt, &name_pu.name_p)),
        crate::syntax::ExprKind::EIndex(recv_pv, index_p10) => Text::from(format!("(index {} {})", &sexp_expr_f(&**recv_pv, d_p1), &sexp_expr_f(&**index_p10, d_p1))),
        crate::syntax::ExprKind::ETopicField(n_p11) => Text::from(format!("(. _ {})", &n_p11.name_p)),
        crate::syntax::ExprKind::ETopicIndex(i_p12) => Text::from(format!("(index _ {})", &sexp_expr_f(&**i_p12, d_p1))),
        crate::syntax::ExprKind::EMethod(recv_p13, method_p14, args_p15) => Text::from(format!("(.{} {}{})", &sname_text_f(method_p14), &sexp_expr_f(&**recv_p13, d_p1), &sexp_args_f(args_p15, d_p1))),
        crate::syntax::ExprKind::ETypeArgs(target_p16, types_p17) => Text::from(format!("(<<>> {}{})", &sexp_expr_f(&**target_p16, d_p1), &spaced_f(types_p17, &{
            let f = Rc::new(sexp_type_f);
            Rc::new(move |a0: crate::syntax::Type| {
                let fy = f.clone();
                crate::prelude::once_job(move || prism_rtl::Turn::Finished(fy(&a0)))
            }) as Rc<dyn Fn(crate::syntax::Type) -> Rc<dyn prism_rtl::Job<Text>>>
        }))),
        crate::syntax::ExprKind::ECast(x_p18, ty_p19, checked_p1a) => Text::from(format!("({} {} {})", &(if *checked_p1a { Text::lit("as?") } else { Text::lit("as") }), &sexp_expr_f(&**x_p18, d_p1), &sexp_type_f(ty_p19))),
        crate::syntax::ExprKind::ENonEmpty(x_p1b) => Text::from(format!("(nonempty {})", &sexp_expr_f(&**x_p1b, d_p1))),
        crate::syntax::ExprKind::EAbsent => Text::lit("absent"),
        crate::syntax::ExprKind::ERest => Text::lit(".."),
        crate::syntax::ExprKind::ELambda(params_o1c, body_p1d) => Text::from(format!("(lambda{}{})", &sexp_lambda_params_f(params_o1c, d_p1), &sexp_lambda_body_f(&**body_p1d, d_p1))),
        crate::syntax::ExprKind::EIf(c_p1e, then_block_p1f, else_block_o1g) => Text::from(format!("(if {}{}{})", &sexp_cond_f(&**c_p1e, d_p1), &sexp_block_f(then_block_p1f, d_p1), &sexp_else_f(else_block_o1g, d_p1))),
        crate::syntax::ExprKind::EMatch(scrutinee_p1h, arms_p1i) => Text::from(format!("(match {}{})", &sexp_expr_f(&**scrutinee_p1h, d_p1), &crate::prelude::concat(&crate::prelude::each(arms_p1i, &(|a_p1j: &crate::syntax::Arm| Text::from(format!("{}{}", &nl_f(&(d_p1 + &Nat::from(1u32))), &sexp_arm_f(a_p1j, &(d_p1 + &Nat::from(1u32)))))))))),
        crate::syntax::ExprKind::ERebuild(scrutinee_p1k, body_p1l) => Text::from(format!("(rebuild {}{})", &sexp_expr_f(&**scrutinee_p1k, d_p1), &sexp_block_f(body_p1l, d_p1))),
        crate::syntax::ExprKind::EFor(binders_o1m, source_p1n, body_p1o) => Text::from(format!("(for{} {}{})", &sexp_binders_f(binders_o1m, d_p1), &sexp_expr_f(&**source_p1n, d_p1), &sexp_block_f(body_p1o, d_p1))),
        crate::syntax::ExprKind::EGiven(b_p1p) => Text::from(format!("(given{})", &sexp_block_f(b_p1p, d_p1))),
        crate::syntax::ExprKind::EUpdate(target_p1q, body_p1r) => Text::from(format!("(update {}{})", &sexp_expr_f(&**target_p1q, d_p1), &sexp_block_f(body_p1r, d_p1))),
        crate::syntax::ExprKind::EWidgetBlock(b_p1s) => Text::from(format!("(@widget{})", &sexp_block_f(b_p1s, d_p1))),
        crate::syntax::ExprKind::EMonad(m_p1t, body_p1u) => Text::from(format!("(monad {}{})", &sexp_expr_f(&**m_p1t, d_p1), &sexp_block_f(body_p1u, d_p1))),
        crate::syntax::ExprKind::ETemplate(t_p1v) => sexp_template_f(t_p1v, d_p1),
        crate::syntax::ExprKind::EAny(x_p20) => Text::from(format!("(any {})", &sexp_expr_f(&**x_p20, d_p1))),
        crate::syntax::ExprKind::ELens(path_p21) => Text::from(format!("(lens {})", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(path_p21, &(|i_p22: &crate::syntax::Ident| i_p22.name_p.clone())), &Text::lit(".")))),
        crate::syntax::ExprKind::EError => Text::lit("<error>"),
    }
}

/// ```prism
/// SexpLambdaParams: fn ?[Pattern], Nat -> Text
/// ```
pub fn sexp_lambda_params_f(opt0: &Option<Array<crate::syntax::Pattern_>>, n1: &Nat) -> Text {
    match (opt0, n1) {
        (None, _) => Text::lit(" topic"),
        (Some(ps_p0), d_p1) => Text::from(format!(" (params{})", &crate::prelude::concat(&crate::prelude::each(ps_p0, &(|p_p2: &crate::syntax::Pattern_| Text::from(format!(" {}", &sexp_pattern_f(p_p2, d_p1)))))))),
    }
}

/// ```prism
/// SexpLambdaBody: fn LambdaBody, Nat -> Text
/// ```
pub fn sexp_lambda_body_f(lambda_body0: &crate::syntax::LambdaBody, d_p1: &Nat) -> Text {
    match lambda_body0 {
        crate::syntax::LambdaBody::LbExpr(e_p0) => Text::from(format!(" {}", &sexp_expr_f(&**e_p0, d_p1))),
        crate::syntax::LambdaBody::LbBlock(b_p2) => sexp_block_f(b_p2, d_p1),
    }
}

/// ```prism
/// SexpElse: fn ?Block, Nat -> Text
/// ```
pub fn sexp_else_f(opt0: &Option<crate::syntax::Block>, n1: &Nat) -> Text {
    match (opt0, n1) {
        (None, _) => Text::lit(""),
        (Some(b_p0), d_p1) => Text::from(format!("{} else{}", &(if b_p0.inline_p { Text::lit("") } else { nl_f(d_p1) }), &sexp_block_f(b_p0, d_p1))),
    }
}

/// ```prism
/// SexpArm: fn Arm, Nat -> Text
/// ```
pub fn sexp_arm_f(a_p0: &crate::syntax::Arm, d_p1: &Nat) -> Text {
    let pattern_p2 = match &a_p0.pattern_o {
        Some(p_p3) => sexp_pattern_f(p_p3, d_p1),
        None => Text::lit("otherwise"),
    };
    Text::from(format!("(arm {}{}{})", &pattern_p2, &sexp_guard_f(&a_p0.guard_o, d_p1), &sexp_block_f(&a_p0.body_p, d_p1)))
}

/// ```prism
/// SexpBinders: fn ?ForBinders, Nat -> Text
/// ```
pub fn sexp_binders_f(opt0: &Option<crate::syntax::ForBinders>, n1: &Nat) -> Text {
    match (opt0, n1) {
        (None, _) => Text::lit(""),
        (Some(b_p0), d_p1) => {
            let second_p2 = match &b_p0.second_o {
                Some(s_p3) => Text::from(format!(", {}", &sexp_pattern_f(s_p3, d_p1))),
                None => Text::lit(""),
            };
            Text::from(format!(" {}{} <-", &sexp_pattern_f(&b_p0.first_p, d_p1), &second_p2))
        },
    }
}

/// ```prism
/// SexpTemplate: fn Template, Nat -> Text
/// ```
pub fn sexp_template_f(t_p0: &crate::syntax::Template, d_p1: &Nat) -> Text {
    Text::from(format!("(template {} <{}>{})", &t_p0.keyword_p, &t_p0.lang_p, &sexp_parts_f(&t_p0.parts_p, &(d_p1 + &Nat::from(1u32)))))
}

/// ```prism
/// SexpParts: fn [TemplatePart], Nat -> Text
/// ```
pub fn sexp_parts_f(parts_p0: &Array<crate::syntax::TemplatePart>, d_p1: &Nat) -> Text {
    crate::prelude::concat(&crate::prelude::each(parts_p0, &(|p_p2: &crate::syntax::TemplatePart| Text::from(format!("{}{}", &nl_f(d_p1), &sexp_part_f(p_p2, d_p1))))))
}

/// ```prism
/// SexpPart: fn TemplatePart, Nat -> Text
/// ```
pub fn sexp_part_f(template_part0: &crate::syntax::TemplatePart, n1: &Nat) -> Text {
    match (template_part0, n1) {
        (crate::syntax::TemplatePart::TpText(s_p0), _) => crate::syntax::lexer::corpus::debug_text_f(s_p0),
        (crate::syntax::TemplatePart::TpPlaceholder(e_p1, col_o2), d_p3) => Text::from(format!("{{{{{}}}}}{}", &sexp_expr_f(e_p1, d_p3), &column_text_f(col_o2))),
        (crate::syntax::TemplatePart::TpBlock(b_p4), d_p5) => Text::from(format!("(brace-block{})", &sexp_block_f(b_p4, d_p5))),
        (crate::syntax::TemplatePart::TpCall(name_p6, attrs_p7, body_o8, _), d_p9) => Text::from(format!("(call {}{}{})", &sname_text_f(name_p6), &sexp_args_f(attrs_p7, d_p9), &call_parts_f(body_o8, d_p9))),
    }
}

/// ```prism
/// ColumnText: fn ?Nat -> Text
/// ```
pub fn column_text_f(opt0: &Option<Nat>) -> Text {
    match opt0 {
        None => Text::lit(""),
        Some(c_p0) => Text::from(format!(" @col {}", c_p0)),
    }
}

/// ```prism
/// CallParts: fn ?[TemplatePart], Nat -> Text
/// ```
pub fn call_parts_f(opt0: &Option<Array<crate::syntax::TemplatePart>>, n1: &Nat) -> Text {
    match (opt0, n1) {
        (None, _) => Text::lit(""),
        (Some(parts_p0), d_p1) => sexp_parts_f(parts_p0, &(d_p1 + &Nat::from(1u32))),
    }
}

/// ```prism
/// SexpPattern: fn Pattern, Nat -> Text
/// ```
pub fn sexp_pattern_f(p_p0: &crate::syntax::Pattern_, d_p1: &Nat) -> Text {
    match &*p_p0.kind_p {
        crate::syntax::PatternKind::PName(n_p2) => sname_text_f(n_p2),
        crate::syntax::PatternKind::PIgnore => Text::lit("ignore"),
        crate::syntax::PatternKind::PLit(l_p3) => sexp_literal_f(l_p3, d_p1),
        crate::syntax::PatternKind::PNeg(l_p4) => Text::from(format!("-{}", &sexp_literal_f(l_p4, d_p1))),
        crate::syntax::PatternKind::PUnit => Text::lit("unit"),
        crate::syntax::PatternKind::PNil => Text::lit("nil"),
        crate::syntax::PatternKind::PCtor(name_p5, args_p6) => Text::from(format!("(ctor {}{})", &sname_text_f(name_p5), &crate::prelude::concat(&crate::prelude::each(args_p6, &(|a_p7: &crate::syntax::Pattern_| Text::from(format!(" {}", &sexp_pattern_f(a_p7, d_p1)))))))),
        crate::syntax::PatternKind::PRecord(name_p8, fields_p9, rest_pa) => Text::from(format!("(record {}{}{})", &sname_text_f(name_p8), &crate::prelude::concat(&crate::prelude::each(fields_p9, &(|f_pb: &crate::syntax::FieldPat| Text::from(format!(" {}{}", &arg_name_f(&f_pb.name_o), &sexp_pattern_f(&f_pb.pattern_p, d_p1)))))), &(if *rest_pa { Text::lit(" ..") } else { Text::lit("") }))),
        crate::syntax::PatternKind::PSigil(s_pc, inner_pd) => Text::from(format!("(free{} {})", s_pc, &sexp_pattern_f(&**inner_pd, d_p1))),
        crate::syntax::PatternKind::PTuple(ps_pe) => Text::from(format!("(tuple{})", &crate::prelude::concat(&crate::prelude::each(ps_pe, &(|x_pf: &crate::syntax::Pattern_| Text::from(format!(" {}", &sexp_pattern_f(x_pf, d_p1)))))))),
        crate::syntax::PatternKind::PArray(ps_pg) => Text::from(format!("(array{})", &crate::prelude::concat(&crate::prelude::each(ps_pg, &(|x_ph: &crate::syntax::Pattern_| Text::from(format!(" {}", &sexp_pattern_f(x_ph, d_p1)))))))),
        crate::syntax::PatternKind::PGroup(x_pi) => Text::from(format!("(group {})", &sexp_pattern_f(&**x_pi, d_p1))),
        crate::syntax::PatternKind::PFamily(q_pj) => Text::from(format!("{}.*", &path_f(&q_pj.path_p))),
    }
}

/// ```prism
/// SexpType: fn Type -> Text
/// ```
pub fn sexp_type_f(t_p0: &crate::syntax::Type) -> Text {
    match &*t_p0.kind_p {
        crate::syntax::TypeKind::TName(name_p1, m16495_0_1) if (m16495_0_1.len() == 0) => sname_text_f(name_p1),
        crate::syntax::TypeKind::TName(name_p2, args_p3) => Text::from(format!("({}{})", &sname_text_f(name_p2), &crate::prelude::concat(&crate::prelude::each(args_p3, &(|a_p4: &crate::syntax::Type| Text::from(format!(" {}", &sexp_type_f(a_p4)))))))),
        crate::syntax::TypeKind::TSigiled(sigils_p5, inner_p6) => Text::from(format!("(free{} {})", sigils_p5, &sexp_type_f(&**inner_p6))),
        crate::syntax::TypeKind::TArray(elem_p7, true) => Text::from(format!("[[{}]]", &sexp_type_f(&**elem_p7))),
        crate::syntax::TypeKind::TArray(elem_p8, false) => Text::from(format!("[{}]", &sexp_type_f(&**elem_p8))),
        crate::syntax::TypeKind::TTuple(ts_p9) => Text::from(format!("(tuple{})", &crate::prelude::concat(&crate::prelude::each(ts_p9, &(|x_pa: &crate::syntax::Type| Text::from(format!(" {}", &sexp_type_f(x_pa)))))))),
        crate::syntax::TypeKind::TGroup(x_pb) => Text::from(format!("(group {})", &sexp_type_f(&**x_pb))),
        crate::syntax::TypeKind::TMap(k_pc, v_pd) => Text::from(format!("(==> {} {})", &sexp_type_f(&**k_pc), &sexp_type_f(&**v_pd))),
        crate::syntax::TypeKind::TFn(color_pe, params_pf, result_pg) => Text::from(format!("({}fn{} -> {})", &color_text_f(color_pe), &crate::prelude::concat(&crate::prelude::each(params_pf, &(|x_ph: &crate::syntax::Type| Text::from(format!(" {}", &sexp_type_f(x_ph)))))), &sexp_type_f(&**result_pg))),
        crate::syntax::TypeKind::TEmit(ty_pi, r_pj) => Text::from(format!("(emit {} {})", &sexp_type_f(&**ty_pi), &sexp_type_f(&**r_pj))),
        crate::syntax::TypeKind::TRowUnion(ts_pk) => Text::from(format!("(|{})", &crate::prelude::concat(&crate::prelude::each(ts_pk, &(|x_pl: &crate::syntax::Type| Text::from(format!(" {}", &sexp_type_f(x_pl)))))))),
        crate::syntax::TypeKind::TFamily(q_pm) => Text::from(format!("{}.*", &path_f(&q_pm.path_p))),
        crate::syntax::TypeKind::TAny(tr_pn) => Text::from(format!("(any ^{})", &path_f(&tr_pn.path_p))),
        crate::syntax::TypeKind::TUnit(s_po) => Text::from(format!("{}unit", s_po)),
        crate::syntax::TypeKind::THole(n_pp) => sname_text_f(n_pp),
        crate::syntax::TypeKind::TAbsent => Text::lit("absent"),
        crate::syntax::TypeKind::TNonEmpty(x_pq) => Text::from(format!("(nonempty {})", &sexp_type_f(&**x_pq))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ColorText: fn Color -> Text
/// ```
pub fn color_text_f(color0: &crate::syntax::Color) -> Text {
    match color0 {
        crate::syntax::Color::Bounded => Text::lit(""),
        crate::syntax::Color::Unbounded => Text::lit("unbounded "),
        crate::syntax::Color::ColorVar(v_p0) => Text::from(format!("{} ", &v_p0.name_p)),
    }
}
