//! The module `Syntax.Decls`, from `target/bootstrap/src/prismc/syntax/decls.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Bound`:
///
/// ```prism
/// type Bound = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Bound {
    pub var_p: crate::syntax::Ident,
    pub traits_p: Array<crate::syntax::TraitRef>,
    pub span_p: crate::syntax::Range,
}

impl Show for Bound {
    fn show(&self, p: &mut Printer) {
        p.record("Bound", &[("var", &self.var_p), ("traits", &self.traits_p), ("span", &self.span_p)]);
    }
}

impl ToPod for Bound {
    fn to_pod(&self) -> Pod {
        Pod::record("Bound", vec![("var", self.var_p.to_pod()), ("traits", self.traits_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl FromPod for Bound {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Bound { var_p: FromPod::from_pod(field(p, "var")?)?, traits_p: FromPod::from_pod(field(p, "traits")?)?, span_p: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `Case`:
///
/// ```prism
/// type Case = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Case_ {
    pub name_p: crate::syntax::SName,
    pub args_p: Array<crate::syntax::Type>,
    pub indexed_o: Option<crate::syntax::Type>,
    pub span_p: crate::syntax::Range,
}

impl Show for Case_ {
    fn show(&self, p: &mut Printer) {
        p.record("Case", &[("name", &self.name_p), ("args", &self.args_p), ("indexed", &self.indexed_o), ("span", &self.span_p)]);
    }
}

impl ToPod for Case_ {
    fn to_pod(&self) -> Pod {
        Pod::record("Case", vec![("name", self.name_p.to_pod()), ("args", self.args_p.to_pod()), ("indexed", self.indexed_o.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl FromPod for Case_ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Case_ { name_p: FromPod::from_pod(field(p, "name")?)?, args_p: FromPod::from_pod(field(p, "args")?)?, indexed_o: FromPod::from_pod(field(p, "indexed")?)?, span_p: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `CheckDecl`:
///
/// ```prism
/// type CheckDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CheckDecl {
    pub name_p: crate::syntax::Ident,
    pub lines_p: Array<CheckLine>,
    pub span_p: crate::syntax::Range,
}

impl Show for CheckDecl {
    fn show(&self, p: &mut Printer) {
        p.record("CheckDecl", &[("name", &self.name_p), ("lines", &self.lines_p), ("span", &self.span_p)]);
    }
}

impl ToPod for CheckDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("CheckDecl", vec![("name", self.name_p.to_pod()), ("lines", self.lines_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl FromPod for CheckDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CheckDecl { name_p: FromPod::from_pod(field(p, "name")?)?, lines_p: FromPod::from_pod(field(p, "lines")?)?, span_p: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `CheckLine`:
///
/// ```prism
/// type CheckLine = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CheckLine {
    pub expr_p: crate::syntax::Expr,
    pub pattern_o: Option<crate::syntax::Pattern_>,
    pub span_p: crate::syntax::Range,
}

impl Show for CheckLine {
    fn show(&self, p: &mut Printer) {
        p.record("CheckLine", &[("expr", &self.expr_p), ("pattern", &self.pattern_o), ("span", &self.span_p)]);
    }
}

impl ToPod for CheckLine {
    fn to_pod(&self) -> Pod {
        Pod::record("CheckLine", vec![("expr", self.expr_p.to_pod()), ("pattern", self.pattern_o.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl FromPod for CheckLine {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CheckLine { expr_p: FromPod::from_pod(field(p, "expr")?)?, pattern_o: FromPod::from_pod(field(p, "pattern")?)?, span_p: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `Decl`:
///
/// ```prism
/// type Decl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Decl {
    pub kind_p: DeclKind,
    pub span_p: crate::syntax::Range,
}

impl Show for Decl {
    fn show(&self, p: &mut Printer) {
        p.record("Decl", &[("kind", &self.kind_p), ("span", &self.span_p)]);
    }
}

impl ToPod for Decl {
    fn to_pod(&self) -> Pod {
        Pod::record("Decl", vec![("kind", self.kind_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl FromPod for Decl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Decl { kind_p: FromPod::from_pod(field(p, "kind")?)?, span_p: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `DeclKind`:
///
/// ```prism
/// type DeclKind = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum DeclKind {
    DSignature(Signature),
    DFn(FnClause),
    DLet(LetDecl),
    DWidget(WidgetDecl),
    DType(TypeDecl),
    DTag(TagDecl),
    DDerive(Array<crate::syntax::TraitRef>),
    DTrait(TraitDecl),
    DImpl(ImplDecl),
    DCheck(CheckDecl),
    DTest(TestDecl),
    DStmt(crate::syntax::Stmt),
}

impl Show for DeclKind {
    fn show(&self, p: &mut Printer) {
        match self {
            DeclKind::DSignature(a0) => p.choice("DSignature", &[a0]),
            DeclKind::DFn(a0) => p.choice("DFn", &[a0]),
            DeclKind::DLet(a0) => p.choice("DLet", &[a0]),
            DeclKind::DWidget(a0) => p.choice("DWidget", &[a0]),
            DeclKind::DType(a0) => p.choice("DType", &[a0]),
            DeclKind::DTag(a0) => p.choice("DTag", &[a0]),
            DeclKind::DDerive(a0) => p.choice("DDerive", &[a0]),
            DeclKind::DTrait(a0) => p.choice("DTrait", &[a0]),
            DeclKind::DImpl(a0) => p.choice("DImpl", &[a0]),
            DeclKind::DCheck(a0) => p.choice("DCheck", &[a0]),
            DeclKind::DTest(a0) => p.choice("DTest", &[a0]),
            DeclKind::DStmt(a0) => p.choice("DStmt", &[a0]),
        }
    }
}

impl ToPod for DeclKind {
    fn to_pod(&self) -> Pod {
        match self {
            DeclKind::DSignature(a0) => Pod::Choice("DSignature".into(), vec![a0.to_pod()]),
            DeclKind::DFn(a0) => Pod::Choice("DFn".into(), vec![a0.to_pod()]),
            DeclKind::DLet(a0) => Pod::Choice("DLet".into(), vec![a0.to_pod()]),
            DeclKind::DWidget(a0) => Pod::Choice("DWidget".into(), vec![a0.to_pod()]),
            DeclKind::DType(a0) => Pod::Choice("DType".into(), vec![a0.to_pod()]),
            DeclKind::DTag(a0) => Pod::Choice("DTag".into(), vec![a0.to_pod()]),
            DeclKind::DDerive(a0) => Pod::Choice("DDerive".into(), vec![a0.to_pod()]),
            DeclKind::DTrait(a0) => Pod::Choice("DTrait".into(), vec![a0.to_pod()]),
            DeclKind::DImpl(a0) => Pod::Choice("DImpl".into(), vec![a0.to_pod()]),
            DeclKind::DCheck(a0) => Pod::Choice("DCheck".into(), vec![a0.to_pod()]),
            DeclKind::DTest(a0) => Pod::Choice("DTest".into(), vec![a0.to_pod()]),
            DeclKind::DStmt(a0) => Pod::Choice("DStmt".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for DeclKind {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "DSignature" && a.len() == 1 => Ok(DeclKind::DSignature(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DFn" && a.len() == 1 => Ok(DeclKind::DFn(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DLet" && a.len() == 1 => Ok(DeclKind::DLet(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DWidget" && a.len() == 1 => Ok(DeclKind::DWidget(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DType" && a.len() == 1 => Ok(DeclKind::DType(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DTag" && a.len() == 1 => Ok(DeclKind::DTag(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DDerive" && a.len() == 1 => Ok(DeclKind::DDerive(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DTrait" && a.len() == 1 => Ok(DeclKind::DTrait(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DImpl" && a.len() == 1 => Ok(DeclKind::DImpl(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DCheck" && a.len() == 1 => Ok(DeclKind::DCheck(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DTest" && a.len() == 1 => Ok(DeclKind::DTest(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DStmt" && a.len() == 1 => Ok(DeclKind::DStmt(FromPod::from_pod(&a[0])?)),
            other => mismatch("a DeclKind", other),
        }
    }
}

/// `DefName`:
///
/// ```prism
/// type DefName = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum DefName {
    DefSName(crate::syntax::SName),
    DefOp(Text, crate::syntax::Range),
}

impl Show for DefName {
    fn show(&self, p: &mut Printer) {
        match self {
            DefName::DefSName(a0) => p.choice("DefSName", &[a0]),
            DefName::DefOp(a0, a1) => p.choice("DefOp", &[a0, a1]),
        }
    }
}

impl ToPod for DefName {
    fn to_pod(&self) -> Pod {
        match self {
            DefName::DefSName(a0) => Pod::Choice("DefSName".into(), vec![a0.to_pod()]),
            DefName::DefOp(a0, a1) => Pod::Choice("DefOp".into(), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl FromPod for DefName {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "DefSName" && a.len() == 1 => Ok(DefName::DefSName(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DefOp" && a.len() == 2 => Ok(DefName::DefOp(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            other => mismatch("a DefName", other),
        }
    }
}

/// `Delivery`:
///
/// ```prism
/// type Delivery = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Delivery {
    pub kind_p: DeliveryKind,
    pub target_p: Target,
    pub span_p: crate::syntax::Range,
}

impl Show for Delivery {
    fn show(&self, p: &mut Printer) {
        p.record("Delivery", &[("kind", &self.kind_p), ("target", &self.target_p), ("span", &self.span_p)]);
    }
}

impl ToPod for Delivery {
    fn to_pod(&self) -> Pod {
        Pod::record("Delivery", vec![("kind", self.kind_p.to_pod()), ("target", self.target_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl FromPod for Delivery {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Delivery { kind_p: FromPod::from_pod(field(p, "kind")?)?, target_p: FromPod::from_pod(field(p, "target")?)?, span_p: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `DeliveryKind`:
///
/// ```prism
/// type DeliveryKind = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum DeliveryKind {
    DkSend(crate::syntax::Expr),
    DkClick,
    DkAnswer,
}

impl Show for DeliveryKind {
    fn show(&self, p: &mut Printer) {
        match self {
            DeliveryKind::DkSend(a0) => p.choice("DkSend", &[a0]),
            DeliveryKind::DkClick => p.choice("DkClick", &[]),
            DeliveryKind::DkAnswer => p.choice("DkAnswer", &[]),
        }
    }
}

impl ToPod for DeliveryKind {
    fn to_pod(&self) -> Pod {
        match self {
            DeliveryKind::DkSend(a0) => Pod::Choice("DkSend".into(), vec![a0.to_pod()]),
            DeliveryKind::DkClick => Pod::Choice("DkClick".into(), vec![]),
            DeliveryKind::DkAnswer => Pod::Choice("DkAnswer".into(), vec![]),
        }
    }
}

impl FromPod for DeliveryKind {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "DkSend" && a.len() == 1 => Ok(DeliveryKind::DkSend(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DkClick" && a.len() == 0 => Ok(DeliveryKind::DkClick),
            Pod::Choice(c, a) if &**c == "DkAnswer" && a.len() == 0 => Ok(DeliveryKind::DkAnswer),
            other => mismatch("a DeliveryKind", other),
        }
    }
}

/// `Entry`:
///
/// ```prism
/// type Entry = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Entry {
    pub element_p: crate::syntax::Expr,
    pub value_p: crate::syntax::Expr,
    pub span_p: crate::syntax::Range,
}

impl Show for Entry {
    fn show(&self, p: &mut Printer) {
        p.record("Entry", &[("element", &self.element_p), ("value", &self.value_p), ("span", &self.span_p)]);
    }
}

impl ToPod for Entry {
    fn to_pod(&self) -> Pod {
        Pod::record("Entry", vec![("element", self.element_p.to_pod()), ("value", self.value_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl FromPod for Entry {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Entry { element_p: FromPod::from_pod(field(p, "element")?)?, value_p: FromPod::from_pod(field(p, "value")?)?, span_p: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `Field`:
///
/// ```prism
/// type Field = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Field {
    pub name_p: crate::syntax::Ident,
    pub ty_p: crate::syntax::Type,
    pub span_p: crate::syntax::Range,
}

impl Show for Field {
    fn show(&self, p: &mut Printer) {
        p.record("Field", &[("name", &self.name_p), ("ty", &self.ty_p), ("span", &self.span_p)]);
    }
}

impl ToPod for Field {
    fn to_pod(&self) -> Pod {
        Pod::record("Field", vec![("name", self.name_p.to_pod()), ("ty", self.ty_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl FromPod for Field {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Field { name_p: FromPod::from_pod(field(p, "name")?)?, ty_p: FromPod::from_pod(field(p, "ty")?)?, span_p: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `FnBody`:
///
/// ```prism
/// type FnBody = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum FnBody {
    BodyExpr(crate::syntax::Expr),
    BodyBlock(crate::syntax::Block),
}

impl Show for FnBody {
    fn show(&self, p: &mut Printer) {
        match self {
            FnBody::BodyExpr(a0) => p.choice("BodyExpr", &[a0]),
            FnBody::BodyBlock(a0) => p.choice("BodyBlock", &[a0]),
        }
    }
}

impl ToPod for FnBody {
    fn to_pod(&self) -> Pod {
        match self {
            FnBody::BodyExpr(a0) => Pod::Choice("BodyExpr".into(), vec![a0.to_pod()]),
            FnBody::BodyBlock(a0) => Pod::Choice("BodyBlock".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for FnBody {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "BodyExpr" && a.len() == 1 => Ok(FnBody::BodyExpr(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "BodyBlock" && a.len() == 1 => Ok(FnBody::BodyBlock(FromPod::from_pod(&a[0])?)),
            other => mismatch("a FnBody", other),
        }
    }
}

/// `FnClause`:
///
/// ```prism
/// type FnClause = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct FnClause {
    pub name_p: DefName,
    pub params_p: Array<crate::syntax::Pattern_>,
    pub body_p: FnBody,
    pub span_p: crate::syntax::Range,
}

impl Show for FnClause {
    fn show(&self, p: &mut Printer) {
        p.record("FnClause", &[("name", &self.name_p), ("params", &self.params_p), ("body", &self.body_p), ("span", &self.span_p)]);
    }
}

impl ToPod for FnClause {
    fn to_pod(&self) -> Pod {
        Pod::record("FnClause", vec![("name", self.name_p.to_pod()), ("params", self.params_p.to_pod()), ("body", self.body_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl FromPod for FnClause {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(FnClause { name_p: FromPod::from_pod(field(p, "name")?)?, params_p: FromPod::from_pod(field(p, "params")?)?, body_p: FromPod::from_pod(field(p, "body")?)?, span_p: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `ImplDecl`:
///
/// ```prism
/// type ImplDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ImplDecl {
    pub trait_ref_p: crate::syntax::TraitRef,
    pub ty_p: crate::syntax::Type,
    pub bounds_p: Array<Bound>,
    pub items_p: Array<TraitItem>,
    pub span_p: crate::syntax::Range,
}

impl Show for ImplDecl {
    fn show(&self, p: &mut Printer) {
        p.record("ImplDecl", &[("traitRef", &self.trait_ref_p), ("ty", &self.ty_p), ("bounds", &self.bounds_p), ("items", &self.items_p), ("span", &self.span_p)]);
    }
}

impl ToPod for ImplDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("ImplDecl", vec![("traitRef", self.trait_ref_p.to_pod()), ("ty", self.ty_p.to_pod()), ("bounds", self.bounds_p.to_pod()), ("items", self.items_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl FromPod for ImplDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ImplDecl { trait_ref_p: FromPod::from_pod(field(p, "traitRef")?)?, ty_p: FromPod::from_pod(field(p, "ty")?)?, bounds_p: FromPod::from_pod(field(p, "bounds")?)?, items_p: FromPod::from_pod(field(p, "items")?)?, span_p: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `LetDecl`:
///
/// ```prism
/// type LetDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct LetDecl {
    pub pattern_p: crate::syntax::Pattern_,
    pub ty_o: Option<crate::syntax::Type>,
    pub value_p: crate::syntax::Expr,
    pub span_p: crate::syntax::Range,
}

impl Show for LetDecl {
    fn show(&self, p: &mut Printer) {
        p.record("LetDecl", &[("pattern", &self.pattern_p), ("ty", &self.ty_o), ("value", &self.value_p), ("span", &self.span_p)]);
    }
}

impl ToPod for LetDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("LetDecl", vec![("pattern", self.pattern_p.to_pod()), ("ty", self.ty_o.to_pod()), ("value", self.value_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl FromPod for LetDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(LetDecl { pattern_p: FromPod::from_pod(field(p, "pattern")?)?, ty_o: FromPod::from_pod(field(p, "ty")?)?, value_p: FromPod::from_pod(field(p, "value")?)?, span_p: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `PathSeg`:
///
/// ```prism
/// type PathSeg = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum PathSeg {
    PsNum(Nat),
    PsGen(Nat),
    PsKey(crate::syntax::Expr),
}

impl Show for PathSeg {
    fn show(&self, p: &mut Printer) {
        match self {
            PathSeg::PsNum(a0) => p.choice("PsNum", &[a0]),
            PathSeg::PsGen(a0) => p.choice("PsGen", &[a0]),
            PathSeg::PsKey(a0) => p.choice("PsKey", &[a0]),
        }
    }
}

impl ToPod for PathSeg {
    fn to_pod(&self) -> Pod {
        match self {
            PathSeg::PsNum(a0) => Pod::Choice("PsNum".into(), vec![a0.to_pod()]),
            PathSeg::PsGen(a0) => Pod::Choice("PsGen".into(), vec![a0.to_pod()]),
            PathSeg::PsKey(a0) => Pod::Choice("PsKey".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for PathSeg {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "PsNum" && a.len() == 1 => Ok(PathSeg::PsNum(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PsGen" && a.len() == 1 => Ok(PathSeg::PsGen(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PsKey" && a.len() == 1 => Ok(PathSeg::PsKey(FromPod::from_pod(&a[0])?)),
            other => mismatch("a PathSeg", other),
        }
    }
}

/// `Signature`:
///
/// ```prism
/// type Signature = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Signature {
    pub name_p: DefName,
    pub ty_p: crate::syntax::Type,
    pub bounds_p: Array<Bound>,
    pub span_p: crate::syntax::Range,
}

impl Show for Signature {
    fn show(&self, p: &mut Printer) {
        p.record("Signature", &[("name", &self.name_p), ("ty", &self.ty_p), ("bounds", &self.bounds_p), ("span", &self.span_p)]);
    }
}

impl ToPod for Signature {
    fn to_pod(&self) -> Pod {
        Pod::record("Signature", vec![("name", self.name_p.to_pod()), ("ty", self.ty_p.to_pod()), ("bounds", self.bounds_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl FromPod for Signature {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Signature { name_p: FromPod::from_pod(field(p, "name")?)?, ty_p: FromPod::from_pod(field(p, "ty")?)?, bounds_p: FromPod::from_pod(field(p, "bounds")?)?, span_p: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `StepAction`:
///
/// ```prism
/// type StepAction = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum StepAction {
    SaBuild,
    SaTick,
    SaCompute(bool),
    SaPush(Entry),
    SaDeliver(Array<Delivery>),
    SaWithOnly,
}

impl Show for StepAction {
    fn show(&self, p: &mut Printer) {
        match self {
            StepAction::SaBuild => p.choice("SaBuild", &[]),
            StepAction::SaTick => p.choice("SaTick", &[]),
            StepAction::SaCompute(a0) => p.choice("SaCompute", &[a0]),
            StepAction::SaPush(a0) => p.choice("SaPush", &[a0]),
            StepAction::SaDeliver(a0) => p.choice("SaDeliver", &[a0]),
            StepAction::SaWithOnly => p.choice("SaWithOnly", &[]),
        }
    }
}

impl ToPod for StepAction {
    fn to_pod(&self) -> Pod {
        match self {
            StepAction::SaBuild => Pod::Choice("SaBuild".into(), vec![]),
            StepAction::SaTick => Pod::Choice("SaTick".into(), vec![]),
            StepAction::SaCompute(a0) => Pod::Choice("SaCompute".into(), vec![a0.to_pod()]),
            StepAction::SaPush(a0) => Pod::Choice("SaPush".into(), vec![a0.to_pod()]),
            StepAction::SaDeliver(a0) => Pod::Choice("SaDeliver".into(), vec![a0.to_pod()]),
            StepAction::SaWithOnly => Pod::Choice("SaWithOnly".into(), vec![]),
        }
    }
}

impl FromPod for StepAction {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "SaBuild" && a.len() == 0 => Ok(StepAction::SaBuild),
            Pod::Choice(c, a) if &**c == "SaTick" && a.len() == 0 => Ok(StepAction::SaTick),
            Pod::Choice(c, a) if &**c == "SaCompute" && a.len() == 1 => Ok(StepAction::SaCompute(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SaPush" && a.len() == 1 => Ok(StepAction::SaPush(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SaDeliver" && a.len() == 1 => Ok(StepAction::SaDeliver(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SaWithOnly" && a.len() == 0 => Ok(StepAction::SaWithOnly),
            other => mismatch("a StepAction", other),
        }
    }
}

/// `TagDecl`:
///
/// ```prism
/// type TagDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TagDecl {
    pub name_p: crate::syntax::QualName,
    pub of_type_p: crate::syntax::Type,
    pub bounds_p: Array<Bound>,
    pub fields_p: Array<Field>,
    pub span_p: crate::syntax::Range,
}

impl Show for TagDecl {
    fn show(&self, p: &mut Printer) {
        p.record("TagDecl", &[("name", &self.name_p), ("ofType", &self.of_type_p), ("bounds", &self.bounds_p), ("fields", &self.fields_p), ("span", &self.span_p)]);
    }
}

impl ToPod for TagDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("TagDecl", vec![("name", self.name_p.to_pod()), ("ofType", self.of_type_p.to_pod()), ("bounds", self.bounds_p.to_pod()), ("fields", self.fields_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl FromPod for TagDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TagDecl { name_p: FromPod::from_pod(field(p, "name")?)?, of_type_p: FromPod::from_pod(field(p, "ofType")?)?, bounds_p: FromPod::from_pod(field(p, "bounds")?)?, fields_p: FromPod::from_pod(field(p, "fields")?)?, span_p: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `Target`:
///
/// ```prism
/// type Target = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Target {
    TgPattern(crate::syntax::Pattern_),
    TgPath(TestPath),
    TgElement(TestPath),
}

impl Show for Target {
    fn show(&self, p: &mut Printer) {
        match self {
            Target::TgPattern(a0) => p.choice("TgPattern", &[a0]),
            Target::TgPath(a0) => p.choice("TgPath", &[a0]),
            Target::TgElement(a0) => p.choice("TgElement", &[a0]),
        }
    }
}

impl ToPod for Target {
    fn to_pod(&self) -> Pod {
        match self {
            Target::TgPattern(a0) => Pod::Choice("TgPattern".into(), vec![a0.to_pod()]),
            Target::TgPath(a0) => Pod::Choice("TgPath".into(), vec![a0.to_pod()]),
            Target::TgElement(a0) => Pod::Choice("TgElement".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for Target {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "TgPattern" && a.len() == 1 => Ok(Target::TgPattern(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TgPath" && a.len() == 1 => Ok(Target::TgPath(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TgElement" && a.len() == 1 => Ok(Target::TgElement(FromPod::from_pod(&a[0])?)),
            other => mismatch("a Target", other),
        }
    }
}

/// `TestCheck`:
///
/// ```prism
/// type TestCheck = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TestCheck {
    pub kind_p: TestCheckKind,
    pub span_p: crate::syntax::Range,
}

impl Show for TestCheck {
    fn show(&self, p: &mut Printer) {
        p.record("TestCheck", &[("kind", &self.kind_p), ("span", &self.span_p)]);
    }
}

impl ToPod for TestCheck {
    fn to_pod(&self) -> Pod {
        Pod::record("TestCheck", vec![("kind", self.kind_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl FromPod for TestCheck {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TestCheck { kind_p: FromPod::from_pod(field(p, "kind")?)?, span_p: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TestCheckKind`:
///
/// ```prism
/// type TestCheckKind = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum TestCheckKind {
    CkExpect(crate::syntax::Pattern_),
    CkExpectNone(crate::syntax::Pattern_),
    CkExpectCount(crate::syntax::Pattern_, Nat),
    CkExpectTop(crate::syntax::Pattern_),
    CkExpectTopNone(crate::syntax::Pattern_),
    CkRequested(crate::syntax::Pattern_, crate::syntax::Pattern_),
    CkUnrequested(crate::syntax::Pattern_),
    CkReturns(crate::syntax::Pattern_),
    CkFired(crate::syntax::Pattern_),
    CkQuiet,
    CkSettles,
    CkAborted,
    CkSnapshot(Text),
}

impl Show for TestCheckKind {
    fn show(&self, p: &mut Printer) {
        match self {
            TestCheckKind::CkExpect(a0) => p.choice("CkExpect", &[a0]),
            TestCheckKind::CkExpectNone(a0) => p.choice("CkExpectNone", &[a0]),
            TestCheckKind::CkExpectCount(a0, a1) => p.choice("CkExpectCount", &[a0, a1]),
            TestCheckKind::CkExpectTop(a0) => p.choice("CkExpectTop", &[a0]),
            TestCheckKind::CkExpectTopNone(a0) => p.choice("CkExpectTopNone", &[a0]),
            TestCheckKind::CkRequested(a0, a1) => p.choice("CkRequested", &[a0, a1]),
            TestCheckKind::CkUnrequested(a0) => p.choice("CkUnrequested", &[a0]),
            TestCheckKind::CkReturns(a0) => p.choice("CkReturns", &[a0]),
            TestCheckKind::CkFired(a0) => p.choice("CkFired", &[a0]),
            TestCheckKind::CkQuiet => p.choice("CkQuiet", &[]),
            TestCheckKind::CkSettles => p.choice("CkSettles", &[]),
            TestCheckKind::CkAborted => p.choice("CkAborted", &[]),
            TestCheckKind::CkSnapshot(a0) => p.choice("CkSnapshot", &[a0]),
        }
    }
}

impl ToPod for TestCheckKind {
    fn to_pod(&self) -> Pod {
        match self {
            TestCheckKind::CkExpect(a0) => Pod::Choice("CkExpect".into(), vec![a0.to_pod()]),
            TestCheckKind::CkExpectNone(a0) => Pod::Choice("CkExpectNone".into(), vec![a0.to_pod()]),
            TestCheckKind::CkExpectCount(a0, a1) => Pod::Choice("CkExpectCount".into(), vec![a0.to_pod(), a1.to_pod()]),
            TestCheckKind::CkExpectTop(a0) => Pod::Choice("CkExpectTop".into(), vec![a0.to_pod()]),
            TestCheckKind::CkExpectTopNone(a0) => Pod::Choice("CkExpectTopNone".into(), vec![a0.to_pod()]),
            TestCheckKind::CkRequested(a0, a1) => Pod::Choice("CkRequested".into(), vec![a0.to_pod(), a1.to_pod()]),
            TestCheckKind::CkUnrequested(a0) => Pod::Choice("CkUnrequested".into(), vec![a0.to_pod()]),
            TestCheckKind::CkReturns(a0) => Pod::Choice("CkReturns".into(), vec![a0.to_pod()]),
            TestCheckKind::CkFired(a0) => Pod::Choice("CkFired".into(), vec![a0.to_pod()]),
            TestCheckKind::CkQuiet => Pod::Choice("CkQuiet".into(), vec![]),
            TestCheckKind::CkSettles => Pod::Choice("CkSettles".into(), vec![]),
            TestCheckKind::CkAborted => Pod::Choice("CkAborted".into(), vec![]),
            TestCheckKind::CkSnapshot(a0) => Pod::Choice("CkSnapshot".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for TestCheckKind {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "CkExpect" && a.len() == 1 => Ok(TestCheckKind::CkExpect(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CkExpectNone" && a.len() == 1 => Ok(TestCheckKind::CkExpectNone(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CkExpectCount" && a.len() == 2 => Ok(TestCheckKind::CkExpectCount(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "CkExpectTop" && a.len() == 1 => Ok(TestCheckKind::CkExpectTop(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CkExpectTopNone" && a.len() == 1 => Ok(TestCheckKind::CkExpectTopNone(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CkRequested" && a.len() == 2 => Ok(TestCheckKind::CkRequested(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "CkUnrequested" && a.len() == 1 => Ok(TestCheckKind::CkUnrequested(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CkReturns" && a.len() == 1 => Ok(TestCheckKind::CkReturns(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CkFired" && a.len() == 1 => Ok(TestCheckKind::CkFired(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CkQuiet" && a.len() == 0 => Ok(TestCheckKind::CkQuiet),
            Pod::Choice(c, a) if &**c == "CkSettles" && a.len() == 0 => Ok(TestCheckKind::CkSettles),
            Pod::Choice(c, a) if &**c == "CkAborted" && a.len() == 0 => Ok(TestCheckKind::CkAborted),
            Pod::Choice(c, a) if &**c == "CkSnapshot" && a.len() == 1 => Ok(TestCheckKind::CkSnapshot(FromPod::from_pod(&a[0])?)),
            other => mismatch("a TestCheckKind", other),
        }
    }
}

/// `TestDecl`:
///
/// ```prism
/// type TestDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TestDecl {
    pub name_p: crate::syntax::Ident,
    pub blueprint_p: crate::syntax::Expr,
    pub seed_o: Option<Nat>,
    pub steps_p: Array<TestStep>,
    pub span_p: crate::syntax::Range,
}

impl Show for TestDecl {
    fn show(&self, p: &mut Printer) {
        p.record("TestDecl", &[("name", &self.name_p), ("blueprint", &self.blueprint_p), ("seed", &self.seed_o), ("steps", &self.steps_p), ("span", &self.span_p)]);
    }
}

impl ToPod for TestDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("TestDecl", vec![("name", self.name_p.to_pod()), ("blueprint", self.blueprint_p.to_pod()), ("seed", self.seed_o.to_pod()), ("steps", self.steps_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl FromPod for TestDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TestDecl { name_p: FromPod::from_pod(field(p, "name")?)?, blueprint_p: FromPod::from_pod(field(p, "blueprint")?)?, seed_o: FromPod::from_pod(field(p, "seed")?)?, steps_p: FromPod::from_pod(field(p, "steps")?)?, span_p: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TestPath`:
///
/// ```prism
/// type TestPath = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TestPath {
    pub segments_p: Array<PathSeg>,
    pub span_p: crate::syntax::Range,
}

impl Show for TestPath {
    fn show(&self, p: &mut Printer) {
        p.record("TestPath", &[("segments", &self.segments_p), ("span", &self.span_p)]);
    }
}

impl ToPod for TestPath {
    fn to_pod(&self) -> Pod {
        Pod::record("TestPath", vec![("segments", self.segments_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl FromPod for TestPath {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TestPath { segments_p: FromPod::from_pod(field(p, "segments")?)?, span_p: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TestStep`:
///
/// ```prism
/// type TestStep = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TestStep {
    pub withs_p: Array<Entry>,
    pub action_p: StepAction,
    pub checks_p: Array<TestCheck>,
    pub span_p: crate::syntax::Range,
}

impl Show for TestStep {
    fn show(&self, p: &mut Printer) {
        p.record("TestStep", &[("withs", &self.withs_p), ("action", &self.action_p), ("checks", &self.checks_p), ("span", &self.span_p)]);
    }
}

impl ToPod for TestStep {
    fn to_pod(&self) -> Pod {
        Pod::record("TestStep", vec![("withs", self.withs_p.to_pod()), ("action", self.action_p.to_pod()), ("checks", self.checks_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl FromPod for TestStep {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TestStep { withs_p: FromPod::from_pod(field(p, "withs")?)?, action_p: FromPod::from_pod(field(p, "action")?)?, checks_p: FromPod::from_pod(field(p, "checks")?)?, span_p: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TraitDecl`:
///
/// ```prism
/// type TraitDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TraitDecl {
    pub name_p: crate::syntax::TraitRef,
    pub params_p: Array<crate::syntax::Ident>,
    pub bounds_p: Array<Bound>,
    pub items_p: Array<TraitItem>,
    pub span_p: crate::syntax::Range,
}

impl Show for TraitDecl {
    fn show(&self, p: &mut Printer) {
        p.record("TraitDecl", &[("name", &self.name_p), ("params", &self.params_p), ("bounds", &self.bounds_p), ("items", &self.items_p), ("span", &self.span_p)]);
    }
}

impl ToPod for TraitDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("TraitDecl", vec![("name", self.name_p.to_pod()), ("params", self.params_p.to_pod()), ("bounds", self.bounds_p.to_pod()), ("items", self.items_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl FromPod for TraitDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TraitDecl { name_p: FromPod::from_pod(field(p, "name")?)?, params_p: FromPod::from_pod(field(p, "params")?)?, bounds_p: FromPod::from_pod(field(p, "bounds")?)?, items_p: FromPod::from_pod(field(p, "items")?)?, span_p: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TraitItem`:
///
/// ```prism
/// type TraitItem = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum TraitItem {
    TiSignature(Signature),
    TiFn(FnClause),
    TiAssocType(crate::syntax::Ident, Array<crate::syntax::Ident>, Option<crate::syntax::Type>, crate::syntax::Range),
    TiAssocRow(crate::syntax::SName, crate::syntax::Range),
}

impl Show for TraitItem {
    fn show(&self, p: &mut Printer) {
        match self {
            TraitItem::TiSignature(a0) => p.choice("TiSignature", &[a0]),
            TraitItem::TiFn(a0) => p.choice("TiFn", &[a0]),
            TraitItem::TiAssocType(a0, a1, a2, a3) => p.choice("TiAssocType", &[a0, a1, a2, a3]),
            TraitItem::TiAssocRow(a0, a1) => p.choice("TiAssocRow", &[a0, a1]),
        }
    }
}

impl ToPod for TraitItem {
    fn to_pod(&self) -> Pod {
        match self {
            TraitItem::TiSignature(a0) => Pod::Choice("TiSignature".into(), vec![a0.to_pod()]),
            TraitItem::TiFn(a0) => Pod::Choice("TiFn".into(), vec![a0.to_pod()]),
            TraitItem::TiAssocType(a0, a1, a2, a3) => Pod::Choice("TiAssocType".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
            TraitItem::TiAssocRow(a0, a1) => Pod::Choice("TiAssocRow".into(), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl FromPod for TraitItem {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "TiSignature" && a.len() == 1 => Ok(TraitItem::TiSignature(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TiFn" && a.len() == 1 => Ok(TraitItem::TiFn(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TiAssocType" && a.len() == 4 => Ok(TraitItem::TiAssocType(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?, FromPod::from_pod(&a[3])?)),
            Pod::Choice(c, a) if &**c == "TiAssocRow" && a.len() == 2 => Ok(TraitItem::TiAssocRow(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            other => mismatch("a TraitItem", other),
        }
    }
}

/// `TypeBody`:
///
/// ```prism
/// type TypeBody = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum TypeBody {
    TbRecord(Array<Field>),
    TbChoice(Array<Case_>),
    TbRow,
    TbNewtype(Case_),
    TbUnit(crate::syntax::Ident),
    TbAlias(crate::syntax::Type),
}

impl Show for TypeBody {
    fn show(&self, p: &mut Printer) {
        match self {
            TypeBody::TbRecord(a0) => p.choice("TbRecord", &[a0]),
            TypeBody::TbChoice(a0) => p.choice("TbChoice", &[a0]),
            TypeBody::TbRow => p.choice("TbRow", &[]),
            TypeBody::TbNewtype(a0) => p.choice("TbNewtype", &[a0]),
            TypeBody::TbUnit(a0) => p.choice("TbUnit", &[a0]),
            TypeBody::TbAlias(a0) => p.choice("TbAlias", &[a0]),
        }
    }
}

impl ToPod for TypeBody {
    fn to_pod(&self) -> Pod {
        match self {
            TypeBody::TbRecord(a0) => Pod::Choice("TbRecord".into(), vec![a0.to_pod()]),
            TypeBody::TbChoice(a0) => Pod::Choice("TbChoice".into(), vec![a0.to_pod()]),
            TypeBody::TbRow => Pod::Choice("TbRow".into(), vec![]),
            TypeBody::TbNewtype(a0) => Pod::Choice("TbNewtype".into(), vec![a0.to_pod()]),
            TypeBody::TbUnit(a0) => Pod::Choice("TbUnit".into(), vec![a0.to_pod()]),
            TypeBody::TbAlias(a0) => Pod::Choice("TbAlias".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for TypeBody {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "TbRecord" && a.len() == 1 => Ok(TypeBody::TbRecord(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TbChoice" && a.len() == 1 => Ok(TypeBody::TbChoice(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TbRow" && a.len() == 0 => Ok(TypeBody::TbRow),
            Pod::Choice(c, a) if &**c == "TbNewtype" && a.len() == 1 => Ok(TypeBody::TbNewtype(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TbUnit" && a.len() == 1 => Ok(TypeBody::TbUnit(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TbAlias" && a.len() == 1 => Ok(TypeBody::TbAlias(FromPod::from_pod(&a[0])?)),
            other => mismatch("a TypeBody", other),
        }
    }
}

/// `TypeDecl`:
///
/// ```prism
/// type TypeDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TypeDecl {
    pub name_p: crate::syntax::QualName,
    pub params_p: Array<crate::syntax::Ident>,
    pub body_o: Option<TypeBody>,
    pub span_p: crate::syntax::Range,
}

impl Show for TypeDecl {
    fn show(&self, p: &mut Printer) {
        p.record("TypeDecl", &[("name", &self.name_p), ("params", &self.params_p), ("body", &self.body_o), ("span", &self.span_p)]);
    }
}

impl ToPod for TypeDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("TypeDecl", vec![("name", self.name_p.to_pod()), ("params", self.params_p.to_pod()), ("body", self.body_o.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl FromPod for TypeDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TypeDecl { name_p: FromPod::from_pod(field(p, "name")?)?, params_p: FromPod::from_pod(field(p, "params")?)?, body_o: FromPod::from_pod(field(p, "body")?)?, span_p: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `WidgetDecl`:
///
/// ```prism
/// type WidgetDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct WidgetDecl {
    pub name_p: crate::syntax::SName,
    pub body_p: crate::syntax::Block,
    pub span_p: crate::syntax::Range,
}

impl Show for WidgetDecl {
    fn show(&self, p: &mut Printer) {
        p.record("WidgetDecl", &[("name", &self.name_p), ("body", &self.body_p), ("span", &self.span_p)]);
    }
}

impl ToPod for WidgetDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("WidgetDecl", vec![("name", self.name_p.to_pod()), ("body", self.body_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl FromPod for WidgetDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(WidgetDecl { name_p: FromPod::from_pod(field(p, "name")?)?, body_p: FromPod::from_pod(field(p, "body")?)?, span_p: FromPod::from_pod(field(p, "span")?)? })
    }
}
