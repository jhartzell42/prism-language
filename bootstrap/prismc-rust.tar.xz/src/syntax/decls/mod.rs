//! The module `Syntax.Decls`, from `target/bootstrap/src/prismc/syntax/decls.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `Bound`:
///
/// ```prism
/// type Bound = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Bound {
    pub var_p: crate::syntax::Ident,
    pub traits_p: crate::prelude::Array<crate::syntax::TraitRef>,
    pub span_p: crate::syntax::Range,
}

impl crate::prelude::Show for Bound {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Bound", &[("var", &self.var_p), ("traits", &self.traits_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for Bound {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Bound", vec![("var", self.var_p.to_pod()), ("traits", self.traits_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Bound {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Bound { var_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "var")?)?, traits_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "traits")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `Case`:
///
/// ```prism
/// type Case = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Case {
    pub name_p: crate::syntax::SName,
    pub args_p: crate::prelude::Array<crate::syntax::Type>,
    pub indexed_o: ::std::option::Option<crate::syntax::Type>,
    pub span_p: crate::syntax::Range,
}

impl crate::prelude::Show for Case {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Case", &[("name", &self.name_p), ("args", &self.args_p), ("indexed", &self.indexed_o), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for Case {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Case", vec![("name", self.name_p.to_pod()), ("args", self.args_p.to_pod()), ("indexed", self.indexed_o.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Case {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Case { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, args_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "args")?)?, indexed_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "indexed")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `CheckDecl`:
///
/// ```prism
/// type CheckDecl = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct CheckDecl {
    pub name_p: crate::syntax::Ident,
    pub lines_p: crate::prelude::Array<CheckLine>,
    pub span_p: crate::syntax::Range,
}

impl crate::prelude::Show for CheckDecl {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("CheckDecl", &[("name", &self.name_p), ("lines", &self.lines_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for CheckDecl {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("CheckDecl", vec![("name", self.name_p.to_pod()), ("lines", self.lines_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for CheckDecl {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(CheckDecl { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, lines_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "lines")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `CheckLine`:
///
/// ```prism
/// type CheckLine = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct CheckLine {
    pub expr_p: crate::syntax::Expr,
    pub pattern_o: ::std::option::Option<crate::syntax::Pattern>,
    pub span_p: crate::syntax::Range,
}

impl crate::prelude::Show for CheckLine {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("CheckLine", &[("expr", &self.expr_p), ("pattern", &self.pattern_o), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for CheckLine {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("CheckLine", vec![("expr", self.expr_p.to_pod()), ("pattern", self.pattern_o.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for CheckLine {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(CheckLine { expr_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "expr")?)?, pattern_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "pattern")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `Decl`:
///
/// ```prism
/// type Decl = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Decl {
    pub kind_p: DeclKind,
    pub span_p: crate::syntax::Range,
}

impl crate::prelude::Show for Decl {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Decl", &[("kind", &self.kind_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for Decl {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Decl", vec![("kind", self.kind_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Decl {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Decl { kind_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "kind")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `DeclKind`:
///
/// ```prism
/// type DeclKind = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum DeclKind {
    DSignature(Signature),
    DFn(FnClause),
    DLet(LetDecl),
    DWidget(WidgetDecl),
    DType(TypeDecl),
    DTag(TagDecl),
    DDerive(crate::prelude::Array<crate::syntax::TraitRef>),
    DTrait(TraitDecl),
    DImpl(ImplDecl),
    DCheck(CheckDecl),
    DTest(TestDecl),
    DStmt(crate::syntax::Stmt),
}

impl crate::prelude::Show for DeclKind {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            DeclKind::DSignature(a0) => p.choice("DSignature", &[a0]),
            DeclKind::DFn(a0) => p.choice("DFn", &[a0]),
            DeclKind::DLet(a0) => p.choice("DLet", &[a0]),
            DeclKind::DWidget(a0) => p.choice("DWidget", &[a0]),
            DeclKind::DType(a0) => p.choice("DType", &[a0]),
            DeclKind::DTag(a0) => p.choice("DTag", &[a0]),
            DeclKind::DDerive(a0) => p.choice("DDerive", &[a0]),
            DeclKind::DTrait(a0) => p.choice("DTrait", &[a0]),
            DeclKind::DImpl(a0) => p.choice("DImpl", &[a0]),
            DeclKind::DCheck(a0) => p.choice("DCheck", &[a0]),
            DeclKind::DTest(a0) => p.choice("DTest", &[a0]),
            DeclKind::DStmt(a0) => p.choice("DStmt", &[a0]),
        }
    }
}

impl crate::prelude::ToPod for DeclKind {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            DeclKind::DSignature(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DSignature", 0), vec![a0.to_pod()]),
            DeclKind::DFn(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DFn", 1), vec![a0.to_pod()]),
            DeclKind::DLet(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DLet", 2), vec![a0.to_pod()]),
            DeclKind::DWidget(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DWidget", 3), vec![a0.to_pod()]),
            DeclKind::DType(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DType", 4), vec![a0.to_pod()]),
            DeclKind::DTag(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DTag", 5), vec![a0.to_pod()]),
            DeclKind::DDerive(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DDerive", 6), vec![a0.to_pod()]),
            DeclKind::DTrait(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DTrait", 7), vec![a0.to_pod()]),
            DeclKind::DImpl(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DImpl", 8), vec![a0.to_pod()]),
            DeclKind::DCheck(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DCheck", 9), vec![a0.to_pod()]),
            DeclKind::DTest(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DTest", 10), vec![a0.to_pod()]),
            DeclKind::DStmt(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DStmt", 11), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for DeclKind {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "DSignature" && a.len() == 1 => ::std::result::Result::Ok(DeclKind::DSignature(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DFn" && a.len() == 1 => ::std::result::Result::Ok(DeclKind::DFn(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DLet" && a.len() == 1 => ::std::result::Result::Ok(DeclKind::DLet(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DWidget" && a.len() == 1 => ::std::result::Result::Ok(DeclKind::DWidget(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DType" && a.len() == 1 => ::std::result::Result::Ok(DeclKind::DType(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DTag" && a.len() == 1 => ::std::result::Result::Ok(DeclKind::DTag(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DDerive" && a.len() == 1 => ::std::result::Result::Ok(DeclKind::DDerive(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DTrait" && a.len() == 1 => ::std::result::Result::Ok(DeclKind::DTrait(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DImpl" && a.len() == 1 => ::std::result::Result::Ok(DeclKind::DImpl(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DCheck" && a.len() == 1 => ::std::result::Result::Ok(DeclKind::DCheck(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DTest" && a.len() == 1 => ::std::result::Result::Ok(DeclKind::DTest(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DStmt" && a.len() == 1 => ::std::result::Result::Ok(DeclKind::DStmt(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a DeclKind", other),
        }
    }
}

/// `DefName`:
///
/// ```prism
/// type DefName = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum DefName {
    DefSName(crate::syntax::SName),
    DefOp(crate::prelude::Text, crate::syntax::Range),
}

impl crate::prelude::Show for DefName {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            DefName::DefSName(a0) => p.choice("DefSName", &[a0]),
            DefName::DefOp(a0, a1) => p.choice("DefOp", &[a0, a1]),
        }
    }
}

impl crate::prelude::ToPod for DefName {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            DefName::DefSName(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DefSName", 0), vec![a0.to_pod()]),
            DefName::DefOp(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DefOp", 1), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for DefName {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "DefSName" && a.len() == 1 => ::std::result::Result::Ok(DefName::DefSName(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DefOp" && a.len() == 2 => ::std::result::Result::Ok(DefName::DefOp(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            other => ::prism_rtl::pod::mismatch("a DefName", other),
        }
    }
}

/// `Delivery`:
///
/// ```prism
/// type Delivery = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Delivery {
    pub kind_p: DeliveryKind,
    pub target_p: Target,
    pub span_p: crate::syntax::Range,
}

impl crate::prelude::Show for Delivery {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Delivery", &[("kind", &self.kind_p), ("target", &self.target_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for Delivery {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Delivery", vec![("kind", self.kind_p.to_pod()), ("target", self.target_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Delivery {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Delivery { kind_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "kind")?)?, target_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "target")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `DeliveryKind`:
///
/// ```prism
/// type DeliveryKind = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum DeliveryKind {
    DkSend(crate::syntax::Expr),
    DkClick,
    DkAnswer,
}

impl crate::prelude::Show for DeliveryKind {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            DeliveryKind::DkSend(a0) => p.choice("DkSend", &[a0]),
            DeliveryKind::DkClick => p.choice("DkClick", &[]),
            DeliveryKind::DkAnswer => p.choice("DkAnswer", &[]),
        }
    }
}

impl crate::prelude::ToPod for DeliveryKind {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            DeliveryKind::DkSend(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DkSend", 0), vec![a0.to_pod()]),
            DeliveryKind::DkClick => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DkClick", 1), vec![]),
            DeliveryKind::DkAnswer => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("DkAnswer", 2), vec![]),
        }
    }
}

impl crate::prelude::FromPod for DeliveryKind {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "DkSend" && a.len() == 1 => ::std::result::Result::Ok(DeliveryKind::DkSend(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "DkClick" && a.len() == 0 => ::std::result::Result::Ok(DeliveryKind::DkClick),
            crate::prelude::Pod::Choice(c, a) if &**c == "DkAnswer" && a.len() == 0 => ::std::result::Result::Ok(DeliveryKind::DkAnswer),
            other => ::prism_rtl::pod::mismatch("a DeliveryKind", other),
        }
    }
}

/// `Entry`:
///
/// ```prism
/// type Entry = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Entry {
    pub element_p: crate::syntax::Expr,
    pub value_p: crate::syntax::Expr,
    pub span_p: crate::syntax::Range,
}

impl crate::prelude::Show for Entry {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Entry", &[("element", &self.element_p), ("value", &self.value_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for Entry {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Entry", vec![("element", self.element_p.to_pod()), ("value", self.value_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Entry {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Entry { element_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "element")?)?, value_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "value")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `Field`:
///
/// ```prism
/// type Field = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Field {
    pub sigils_p: crate::prelude::Text,
    pub name_p: crate::syntax::Ident,
    pub ty_p: crate::syntax::Type,
    pub span_p: crate::syntax::Range,
}

impl crate::prelude::Show for Field {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Field", &[("sigils", &self.sigils_p), ("name", &self.name_p), ("ty", &self.ty_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for Field {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Field", vec![("sigils", self.sigils_p.to_pod()), ("name", self.name_p.to_pod()), ("ty", self.ty_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Field {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Field { sigils_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "sigils")?)?, name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, ty_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "ty")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `FnBody`:
///
/// ```prism
/// type FnBody = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum FnBody {
    BodyExpr(crate::syntax::Expr),
    BodyBlock(crate::syntax::Block),
}

impl crate::prelude::Show for FnBody {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            FnBody::BodyExpr(a0) => p.choice("BodyExpr", &[a0]),
            FnBody::BodyBlock(a0) => p.choice("BodyBlock", &[a0]),
        }
    }
}

impl crate::prelude::ToPod for FnBody {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            FnBody::BodyExpr(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("BodyExpr", 0), vec![a0.to_pod()]),
            FnBody::BodyBlock(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("BodyBlock", 1), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for FnBody {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "BodyExpr" && a.len() == 1 => ::std::result::Result::Ok(FnBody::BodyExpr(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "BodyBlock" && a.len() == 1 => ::std::result::Result::Ok(FnBody::BodyBlock(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a FnBody", other),
        }
    }
}

/// `FnClause`:
///
/// ```prism
/// type FnClause = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct FnClause {
    pub name_p: DefName,
    pub params_p: crate::prelude::Array<crate::syntax::Pattern>,
    pub body_p: FnBody,
    pub span_p: crate::syntax::Range,
}

impl crate::prelude::Show for FnClause {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("FnClause", &[("name", &self.name_p), ("params", &self.params_p), ("body", &self.body_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for FnClause {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("FnClause", vec![("name", self.name_p.to_pod()), ("params", self.params_p.to_pod()), ("body", self.body_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for FnClause {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(FnClause { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, params_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "params")?)?, body_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "body")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `ImplDecl`:
///
/// ```prism
/// type ImplDecl = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct ImplDecl {
    pub trait_ref_p: crate::syntax::TraitRef,
    pub ty_p: crate::syntax::Type,
    pub bounds_p: crate::prelude::Array<Bound>,
    pub items_p: crate::prelude::Array<TraitItem>,
    pub span_p: crate::syntax::Range,
}

impl crate::prelude::Show for ImplDecl {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("ImplDecl", &[("traitRef", &self.trait_ref_p), ("ty", &self.ty_p), ("bounds", &self.bounds_p), ("items", &self.items_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for ImplDecl {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("ImplDecl", vec![("traitRef", self.trait_ref_p.to_pod()), ("ty", self.ty_p.to_pod()), ("bounds", self.bounds_p.to_pod()), ("items", self.items_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for ImplDecl {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(ImplDecl { trait_ref_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "traitRef")?)?, ty_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "ty")?)?, bounds_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "bounds")?)?, items_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "items")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `LetDecl`:
///
/// ```prism
/// type LetDecl = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct LetDecl {
    pub pattern_p: crate::syntax::Pattern,
    pub ty_o: ::std::option::Option<crate::syntax::Type>,
    pub value_p: crate::syntax::Expr,
    pub span_p: crate::syntax::Range,
}

impl crate::prelude::Show for LetDecl {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("LetDecl", &[("pattern", &self.pattern_p), ("ty", &self.ty_o), ("value", &self.value_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for LetDecl {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("LetDecl", vec![("pattern", self.pattern_p.to_pod()), ("ty", self.ty_o.to_pod()), ("value", self.value_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for LetDecl {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(LetDecl { pattern_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "pattern")?)?, ty_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "ty")?)?, value_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "value")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `PathSeg`:
///
/// ```prism
/// type PathSeg = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum PathSeg {
    PsNum(crate::prelude::Nat),
    PsGen(crate::prelude::Nat),
    PsKey(crate::syntax::Expr),
}

impl crate::prelude::Show for PathSeg {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            PathSeg::PsNum(a0) => p.choice("PsNum", &[a0]),
            PathSeg::PsGen(a0) => p.choice("PsGen", &[a0]),
            PathSeg::PsKey(a0) => p.choice("PsKey", &[a0]),
        }
    }
}

impl crate::prelude::ToPod for PathSeg {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            PathSeg::PsNum(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PsNum", 0), vec![a0.to_pod()]),
            PathSeg::PsGen(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PsGen", 1), vec![a0.to_pod()]),
            PathSeg::PsKey(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PsKey", 2), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for PathSeg {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "PsNum" && a.len() == 1 => ::std::result::Result::Ok(PathSeg::PsNum(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "PsGen" && a.len() == 1 => ::std::result::Result::Ok(PathSeg::PsGen(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "PsKey" && a.len() == 1 => ::std::result::Result::Ok(PathSeg::PsKey(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a PathSeg", other),
        }
    }
}

/// `Signature`:
///
/// ```prism
/// type Signature = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Signature {
    pub name_p: DefName,
    pub ty_p: crate::syntax::Type,
    pub bounds_p: crate::prelude::Array<Bound>,
    pub span_p: crate::syntax::Range,
}

impl crate::prelude::Show for Signature {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Signature", &[("name", &self.name_p), ("ty", &self.ty_p), ("bounds", &self.bounds_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for Signature {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Signature", vec![("name", self.name_p.to_pod()), ("ty", self.ty_p.to_pod()), ("bounds", self.bounds_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Signature {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Signature { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, ty_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "ty")?)?, bounds_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "bounds")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `StepAction`:
///
/// ```prism
/// type StepAction = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum StepAction {
    SaBuild,
    SaTick,
    SaCompute(bool),
    SaPush(Entry),
    SaDeliver(crate::prelude::Array<Delivery>),
    SaWithOnly,
}

impl crate::prelude::Show for StepAction {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            StepAction::SaBuild => p.choice("SaBuild", &[]),
            StepAction::SaTick => p.choice("SaTick", &[]),
            StepAction::SaCompute(a0) => p.choice("SaCompute", &[a0]),
            StepAction::SaPush(a0) => p.choice("SaPush", &[a0]),
            StepAction::SaDeliver(a0) => p.choice("SaDeliver", &[a0]),
            StepAction::SaWithOnly => p.choice("SaWithOnly", &[]),
        }
    }
}

impl crate::prelude::ToPod for StepAction {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            StepAction::SaBuild => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SaBuild", 0), vec![]),
            StepAction::SaTick => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SaTick", 1), vec![]),
            StepAction::SaCompute(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SaCompute", 2), vec![a0.to_pod()]),
            StepAction::SaPush(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SaPush", 3), vec![a0.to_pod()]),
            StepAction::SaDeliver(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SaDeliver", 4), vec![a0.to_pod()]),
            StepAction::SaWithOnly => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SaWithOnly", 5), vec![]),
        }
    }
}

impl crate::prelude::FromPod for StepAction {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "SaBuild" && a.len() == 0 => ::std::result::Result::Ok(StepAction::SaBuild),
            crate::prelude::Pod::Choice(c, a) if &**c == "SaTick" && a.len() == 0 => ::std::result::Result::Ok(StepAction::SaTick),
            crate::prelude::Pod::Choice(c, a) if &**c == "SaCompute" && a.len() == 1 => ::std::result::Result::Ok(StepAction::SaCompute(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SaPush" && a.len() == 1 => ::std::result::Result::Ok(StepAction::SaPush(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SaDeliver" && a.len() == 1 => ::std::result::Result::Ok(StepAction::SaDeliver(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SaWithOnly" && a.len() == 0 => ::std::result::Result::Ok(StepAction::SaWithOnly),
            other => ::prism_rtl::pod::mismatch("a StepAction", other),
        }
    }
}

/// `TagDecl`:
///
/// ```prism
/// type TagDecl = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct TagDecl {
    pub name_p: crate::syntax::QualName,
    pub of_type_p: crate::syntax::Type,
    pub bounds_p: crate::prelude::Array<Bound>,
    pub fields_p: crate::prelude::Array<Field>,
    pub span_p: crate::syntax::Range,
}

impl crate::prelude::Show for TagDecl {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("TagDecl", &[("name", &self.name_p), ("ofType", &self.of_type_p), ("bounds", &self.bounds_p), ("fields", &self.fields_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for TagDecl {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("TagDecl", vec![("name", self.name_p.to_pod()), ("ofType", self.of_type_p.to_pod()), ("bounds", self.bounds_p.to_pod()), ("fields", self.fields_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for TagDecl {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(TagDecl { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, of_type_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "ofType")?)?, bounds_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "bounds")?)?, fields_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "fields")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `Target`:
///
/// ```prism
/// type Target = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum Target {
    TgPattern(crate::syntax::Pattern),
    TgPath(TestPath),
    TgElement(TestPath),
}

impl crate::prelude::Show for Target {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            Target::TgPattern(a0) => p.choice("TgPattern", &[a0]),
            Target::TgPath(a0) => p.choice("TgPath", &[a0]),
            Target::TgElement(a0) => p.choice("TgElement", &[a0]),
        }
    }
}

impl crate::prelude::ToPod for Target {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            Target::TgPattern(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TgPattern", 0), vec![a0.to_pod()]),
            Target::TgPath(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TgPath", 1), vec![a0.to_pod()]),
            Target::TgElement(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TgElement", 2), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for Target {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "TgPattern" && a.len() == 1 => ::std::result::Result::Ok(Target::TgPattern(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TgPath" && a.len() == 1 => ::std::result::Result::Ok(Target::TgPath(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TgElement" && a.len() == 1 => ::std::result::Result::Ok(Target::TgElement(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a Target", other),
        }
    }
}

/// `TestCheck`:
///
/// ```prism
/// type TestCheck = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct TestCheck {
    pub kind_p: TestCheckKind,
    pub span_p: crate::syntax::Range,
}

impl crate::prelude::Show for TestCheck {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("TestCheck", &[("kind", &self.kind_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for TestCheck {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("TestCheck", vec![("kind", self.kind_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for TestCheck {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(TestCheck { kind_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "kind")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `TestCheckKind`:
///
/// ```prism
/// type TestCheckKind = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum TestCheckKind {
    CkExpect(crate::syntax::Pattern),
    CkExpectNone(crate::syntax::Pattern),
    CkExpectCount(crate::syntax::Pattern, crate::prelude::Nat),
    CkExpectTop(crate::syntax::Pattern),
    CkExpectTopNone(crate::syntax::Pattern),
    CkRequested(crate::syntax::Pattern, crate::syntax::Pattern),
    CkUnrequested(crate::syntax::Pattern),
    CkReturns(crate::syntax::Pattern),
    CkFired(crate::syntax::Pattern),
    CkQuiet,
    CkSettles,
    CkAborted,
    CkSnapshot(crate::prelude::Text),
}

impl crate::prelude::Show for TestCheckKind {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            TestCheckKind::CkExpect(a0) => p.choice("CkExpect", &[a0]),
            TestCheckKind::CkExpectNone(a0) => p.choice("CkExpectNone", &[a0]),
            TestCheckKind::CkExpectCount(a0, a1) => p.choice("CkExpectCount", &[a0, a1]),
            TestCheckKind::CkExpectTop(a0) => p.choice("CkExpectTop", &[a0]),
            TestCheckKind::CkExpectTopNone(a0) => p.choice("CkExpectTopNone", &[a0]),
            TestCheckKind::CkRequested(a0, a1) => p.choice("CkRequested", &[a0, a1]),
            TestCheckKind::CkUnrequested(a0) => p.choice("CkUnrequested", &[a0]),
            TestCheckKind::CkReturns(a0) => p.choice("CkReturns", &[a0]),
            TestCheckKind::CkFired(a0) => p.choice("CkFired", &[a0]),
            TestCheckKind::CkQuiet => p.choice("CkQuiet", &[]),
            TestCheckKind::CkSettles => p.choice("CkSettles", &[]),
            TestCheckKind::CkAborted => p.choice("CkAborted", &[]),
            TestCheckKind::CkSnapshot(a0) => p.choice("CkSnapshot", &[a0]),
        }
    }
}

impl crate::prelude::ToPod for TestCheckKind {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            TestCheckKind::CkExpect(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CkExpect", 0), vec![a0.to_pod()]),
            TestCheckKind::CkExpectNone(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CkExpectNone", 1), vec![a0.to_pod()]),
            TestCheckKind::CkExpectCount(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CkExpectCount", 2), vec![a0.to_pod(), a1.to_pod()]),
            TestCheckKind::CkExpectTop(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CkExpectTop", 3), vec![a0.to_pod()]),
            TestCheckKind::CkExpectTopNone(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CkExpectTopNone", 4), vec![a0.to_pod()]),
            TestCheckKind::CkRequested(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CkRequested", 5), vec![a0.to_pod(), a1.to_pod()]),
            TestCheckKind::CkUnrequested(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CkUnrequested", 6), vec![a0.to_pod()]),
            TestCheckKind::CkReturns(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CkReturns", 7), vec![a0.to_pod()]),
            TestCheckKind::CkFired(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CkFired", 8), vec![a0.to_pod()]),
            TestCheckKind::CkQuiet => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CkQuiet", 9), vec![]),
            TestCheckKind::CkSettles => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CkSettles", 10), vec![]),
            TestCheckKind::CkAborted => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CkAborted", 11), vec![]),
            TestCheckKind::CkSnapshot(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CkSnapshot", 12), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for TestCheckKind {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "CkExpect" && a.len() == 1 => ::std::result::Result::Ok(TestCheckKind::CkExpect(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "CkExpectNone" && a.len() == 1 => ::std::result::Result::Ok(TestCheckKind::CkExpectNone(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "CkExpectCount" && a.len() == 2 => ::std::result::Result::Ok(TestCheckKind::CkExpectCount(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "CkExpectTop" && a.len() == 1 => ::std::result::Result::Ok(TestCheckKind::CkExpectTop(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "CkExpectTopNone" && a.len() == 1 => ::std::result::Result::Ok(TestCheckKind::CkExpectTopNone(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "CkRequested" && a.len() == 2 => ::std::result::Result::Ok(TestCheckKind::CkRequested(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "CkUnrequested" && a.len() == 1 => ::std::result::Result::Ok(TestCheckKind::CkUnrequested(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "CkReturns" && a.len() == 1 => ::std::result::Result::Ok(TestCheckKind::CkReturns(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "CkFired" && a.len() == 1 => ::std::result::Result::Ok(TestCheckKind::CkFired(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "CkQuiet" && a.len() == 0 => ::std::result::Result::Ok(TestCheckKind::CkQuiet),
            crate::prelude::Pod::Choice(c, a) if &**c == "CkSettles" && a.len() == 0 => ::std::result::Result::Ok(TestCheckKind::CkSettles),
            crate::prelude::Pod::Choice(c, a) if &**c == "CkAborted" && a.len() == 0 => ::std::result::Result::Ok(TestCheckKind::CkAborted),
            crate::prelude::Pod::Choice(c, a) if &**c == "CkSnapshot" && a.len() == 1 => ::std::result::Result::Ok(TestCheckKind::CkSnapshot(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a TestCheckKind", other),
        }
    }
}

/// `TestDecl`:
///
/// ```prism
/// type TestDecl = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct TestDecl {
    pub name_p: crate::syntax::Ident,
    pub blueprint_p: crate::syntax::Expr,
    pub seed_o: ::std::option::Option<crate::prelude::Nat>,
    pub steps_p: crate::prelude::Array<TestStep>,
    pub span_p: crate::syntax::Range,
}

impl crate::prelude::Show for TestDecl {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("TestDecl", &[("name", &self.name_p), ("blueprint", &self.blueprint_p), ("seed", &self.seed_o), ("steps", &self.steps_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for TestDecl {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("TestDecl", vec![("name", self.name_p.to_pod()), ("blueprint", self.blueprint_p.to_pod()), ("seed", self.seed_o.to_pod()), ("steps", self.steps_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for TestDecl {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(TestDecl { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, blueprint_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "blueprint")?)?, seed_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "seed")?)?, steps_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "steps")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `TestPath`:
///
/// ```prism
/// type TestPath = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct TestPath {
    pub segments_p: crate::prelude::Array<PathSeg>,
    pub span_p: crate::syntax::Range,
}

impl crate::prelude::Show for TestPath {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("TestPath", &[("segments", &self.segments_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for TestPath {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("TestPath", vec![("segments", self.segments_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for TestPath {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(TestPath { segments_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "segments")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `TestStep`:
///
/// ```prism
/// type TestStep = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct TestStep {
    pub withs_p: crate::prelude::Array<Entry>,
    pub action_p: StepAction,
    pub checks_p: crate::prelude::Array<TestCheck>,
    pub span_p: crate::syntax::Range,
}

impl crate::prelude::Show for TestStep {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("TestStep", &[("withs", &self.withs_p), ("action", &self.action_p), ("checks", &self.checks_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for TestStep {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("TestStep", vec![("withs", self.withs_p.to_pod()), ("action", self.action_p.to_pod()), ("checks", self.checks_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for TestStep {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(TestStep { withs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "withs")?)?, action_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "action")?)?, checks_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "checks")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `TraitDecl`:
///
/// ```prism
/// type TraitDecl = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct TraitDecl {
    pub name_p: crate::syntax::TraitRef,
    pub params_p: crate::prelude::Array<crate::syntax::Ident>,
    pub bounds_p: crate::prelude::Array<Bound>,
    pub items_p: crate::prelude::Array<TraitItem>,
    pub span_p: crate::syntax::Range,
}

impl crate::prelude::Show for TraitDecl {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("TraitDecl", &[("name", &self.name_p), ("params", &self.params_p), ("bounds", &self.bounds_p), ("items", &self.items_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for TraitDecl {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("TraitDecl", vec![("name", self.name_p.to_pod()), ("params", self.params_p.to_pod()), ("bounds", self.bounds_p.to_pod()), ("items", self.items_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for TraitDecl {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(TraitDecl { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, params_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "params")?)?, bounds_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "bounds")?)?, items_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "items")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `TraitItem`:
///
/// ```prism
/// type TraitItem = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum TraitItem {
    TiSignature(Signature),
    TiFn(FnClause),
    TiAssocType(crate::syntax::Ident, crate::prelude::Array<crate::syntax::Ident>, ::std::option::Option<crate::syntax::Type>, crate::syntax::Range),
    TiAssocRow(crate::syntax::SName, crate::syntax::Range),
}

impl crate::prelude::Show for TraitItem {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            TraitItem::TiSignature(a0) => p.choice("TiSignature", &[a0]),
            TraitItem::TiFn(a0) => p.choice("TiFn", &[a0]),
            TraitItem::TiAssocType(a0, a1, a2, a3) => p.choice("TiAssocType", &[a0, a1, a2, a3]),
            TraitItem::TiAssocRow(a0, a1) => p.choice("TiAssocRow", &[a0, a1]),
        }
    }
}

impl crate::prelude::ToPod for TraitItem {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            TraitItem::TiSignature(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TiSignature", 0), vec![a0.to_pod()]),
            TraitItem::TiFn(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TiFn", 1), vec![a0.to_pod()]),
            TraitItem::TiAssocType(a0, a1, a2, a3) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TiAssocType", 2), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
            TraitItem::TiAssocRow(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TiAssocRow", 3), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for TraitItem {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "TiSignature" && a.len() == 1 => ::std::result::Result::Ok(TraitItem::TiSignature(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TiFn" && a.len() == 1 => ::std::result::Result::Ok(TraitItem::TiFn(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TiAssocType" && a.len() == 4 => ::std::result::Result::Ok(TraitItem::TiAssocType(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?, crate::prelude::FromPod::from_pod(&a[3])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TiAssocRow" && a.len() == 2 => ::std::result::Result::Ok(TraitItem::TiAssocRow(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            other => ::prism_rtl::pod::mismatch("a TraitItem", other),
        }
    }
}

/// `TypeBody`:
///
/// ```prism
/// type TypeBody = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum TypeBody {
    TbRecord(crate::prelude::Array<Field>),
    TbChoice(crate::prelude::Array<Case>),
    TbRow,
    TbNewtype(Case),
    TbUnit(crate::syntax::Ident),
    TbAlias(crate::syntax::Type),
}

impl crate::prelude::Show for TypeBody {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            TypeBody::TbRecord(a0) => p.choice("TbRecord", &[a0]),
            TypeBody::TbChoice(a0) => p.choice("TbChoice", &[a0]),
            TypeBody::TbRow => p.choice("TbRow", &[]),
            TypeBody::TbNewtype(a0) => p.choice("TbNewtype", &[a0]),
            TypeBody::TbUnit(a0) => p.choice("TbUnit", &[a0]),
            TypeBody::TbAlias(a0) => p.choice("TbAlias", &[a0]),
        }
    }
}

impl crate::prelude::ToPod for TypeBody {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            TypeBody::TbRecord(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TbRecord", 0), vec![a0.to_pod()]),
            TypeBody::TbChoice(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TbChoice", 1), vec![a0.to_pod()]),
            TypeBody::TbRow => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TbRow", 2), vec![]),
            TypeBody::TbNewtype(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TbNewtype", 3), vec![a0.to_pod()]),
            TypeBody::TbUnit(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TbUnit", 4), vec![a0.to_pod()]),
            TypeBody::TbAlias(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TbAlias", 5), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for TypeBody {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "TbRecord" && a.len() == 1 => ::std::result::Result::Ok(TypeBody::TbRecord(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TbChoice" && a.len() == 1 => ::std::result::Result::Ok(TypeBody::TbChoice(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TbRow" && a.len() == 0 => ::std::result::Result::Ok(TypeBody::TbRow),
            crate::prelude::Pod::Choice(c, a) if &**c == "TbNewtype" && a.len() == 1 => ::std::result::Result::Ok(TypeBody::TbNewtype(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TbUnit" && a.len() == 1 => ::std::result::Result::Ok(TypeBody::TbUnit(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TbAlias" && a.len() == 1 => ::std::result::Result::Ok(TypeBody::TbAlias(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a TypeBody", other),
        }
    }
}

/// `TypeDecl`:
///
/// ```prism
/// type TypeDecl = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct TypeDecl {
    pub name_p: crate::syntax::QualName,
    pub params_p: crate::prelude::Array<crate::syntax::Ident>,
    pub body_o: ::std::option::Option<TypeBody>,
    pub span_p: crate::syntax::Range,
}

impl crate::prelude::Show for TypeDecl {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("TypeDecl", &[("name", &self.name_p), ("params", &self.params_p), ("body", &self.body_o), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for TypeDecl {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("TypeDecl", vec![("name", self.name_p.to_pod()), ("params", self.params_p.to_pod()), ("body", self.body_o.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for TypeDecl {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(TypeDecl { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, params_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "params")?)?, body_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "body")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `WidgetDecl`:
///
/// ```prism
/// type WidgetDecl = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct WidgetDecl {
    pub name_p: crate::syntax::SName,
    pub body_p: crate::syntax::Block,
    pub span_p: crate::syntax::Range,
}

impl crate::prelude::Show for WidgetDecl {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("WidgetDecl", &[("name", &self.name_p), ("body", &self.body_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for WidgetDecl {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("WidgetDecl", vec![("name", self.name_p.to_pod()), ("body", self.body_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for WidgetDecl {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(WidgetDecl { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, body_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "body")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}
