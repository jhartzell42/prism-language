//! The module `Syntax.Decls`, from `target/bootstrap/src/prismc/syntax/decls.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Bound`:
///
/// ```prism
/// type Bound = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Bound {
    pub var: crate::syntax::Ident,
    pub traits: Array<crate::syntax::TraitRef>,
    pub span: crate::syntax::Range,
}

impl Show for Bound {
    fn show(&self, p: &mut Printer) {
        p.record("Bound", &[("var", &self.var), ("traits", &self.traits), ("span", &self.span)]);
    }
}

impl ToPod for Bound {
    fn to_pod(&self) -> Pod {
        Pod::record("Bound", vec![("var", self.var.to_pod()), ("traits", self.traits.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for Bound {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Bound { var: FromPod::from_pod(field(p, "var")?)?, traits: FromPod::from_pod(field(p, "traits")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `Case`:
///
/// ```prism
/// type Case = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Case_ {
    pub name: crate::syntax::SName,
    pub args: Array<crate::syntax::Type>,
    pub indexed: Option<crate::syntax::Type>,
    pub span: crate::syntax::Range,
}

impl Show for Case_ {
    fn show(&self, p: &mut Printer) {
        p.record("Case", &[("name", &self.name), ("args", &self.args), ("indexed", &self.indexed), ("span", &self.span)]);
    }
}

impl ToPod for Case_ {
    fn to_pod(&self) -> Pod {
        Pod::record("Case", vec![("name", self.name.to_pod()), ("args", self.args.to_pod()), ("indexed", self.indexed.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for Case_ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Case_ { name: FromPod::from_pod(field(p, "name")?)?, args: FromPod::from_pod(field(p, "args")?)?, indexed: FromPod::from_pod(field(p, "indexed")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `CheckDecl`:
///
/// ```prism
/// type CheckDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CheckDecl {
    pub name: crate::syntax::Ident,
    pub lines: Array<CheckLine>,
    pub span: crate::syntax::Range,
}

impl Show for CheckDecl {
    fn show(&self, p: &mut Printer) {
        p.record("CheckDecl", &[("name", &self.name), ("lines", &self.lines), ("span", &self.span)]);
    }
}

impl ToPod for CheckDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("CheckDecl", vec![("name", self.name.to_pod()), ("lines", self.lines.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for CheckDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CheckDecl { name: FromPod::from_pod(field(p, "name")?)?, lines: FromPod::from_pod(field(p, "lines")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `CheckLine`:
///
/// ```prism
/// type CheckLine = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CheckLine {
    pub expr: crate::syntax::Expr,
    pub pattern: Option<crate::syntax::Pattern_>,
    pub span: crate::syntax::Range,
}

impl Show for CheckLine {
    fn show(&self, p: &mut Printer) {
        p.record("CheckLine", &[("expr", &self.expr), ("pattern", &self.pattern), ("span", &self.span)]);
    }
}

impl ToPod for CheckLine {
    fn to_pod(&self) -> Pod {
        Pod::record("CheckLine", vec![("expr", self.expr.to_pod()), ("pattern", self.pattern.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for CheckLine {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CheckLine { expr: FromPod::from_pod(field(p, "expr")?)?, pattern: FromPod::from_pod(field(p, "pattern")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `Decl`:
///
/// ```prism
/// type Decl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Decl {
    pub kind: DeclKind,
    pub span: crate::syntax::Range,
}

impl Show for Decl {
    fn show(&self, p: &mut Printer) {
        p.record("Decl", &[("kind", &self.kind), ("span", &self.span)]);
    }
}

impl ToPod for Decl {
    fn to_pod(&self) -> Pod {
        Pod::record("Decl", vec![("kind", self.kind.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for Decl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Decl { kind: FromPod::from_pod(field(p, "kind")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `DeclKind`:
///
/// ```prism
/// type DeclKind = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum DeclKind {
    DSignature(Signature),
    DFn(FnClause),
    DLet(LetDecl),
    DWidget(WidgetDecl),
    DType(TypeDecl),
    DTag(TagDecl),
    DDerive(Array<crate::syntax::TraitRef>),
    DTrait(TraitDecl),
    DImpl(ImplDecl),
    DCheck(CheckDecl),
    DTest(TestDecl),
    DStmt(crate::syntax::Stmt),
}

impl Show for DeclKind {
    fn show(&self, p: &mut Printer) {
        match self {
            DeclKind::DSignature(a0) => p.choice("DSignature", &[a0]),
            DeclKind::DFn(a0) => p.choice("DFn", &[a0]),
            DeclKind::DLet(a0) => p.choice("DLet", &[a0]),
            DeclKind::DWidget(a0) => p.choice("DWidget", &[a0]),
            DeclKind::DType(a0) => p.choice("DType", &[a0]),
            DeclKind::DTag(a0) => p.choice("DTag", &[a0]),
            DeclKind::DDerive(a0) => p.choice("DDerive", &[a0]),
            DeclKind::DTrait(a0) => p.choice("DTrait", &[a0]),
            DeclKind::DImpl(a0) => p.choice("DImpl", &[a0]),
            DeclKind::DCheck(a0) => p.choice("DCheck", &[a0]),
            DeclKind::DTest(a0) => p.choice("DTest", &[a0]),
            DeclKind::DStmt(a0) => p.choice("DStmt", &[a0]),
        }
    }
}

impl ToPod for DeclKind {
    fn to_pod(&self) -> Pod {
        match self {
            DeclKind::DSignature(a0) => Pod::Choice("DSignature".into(), vec![a0.to_pod()]),
            DeclKind::DFn(a0) => Pod::Choice("DFn".into(), vec![a0.to_pod()]),
            DeclKind::DLet(a0) => Pod::Choice("DLet".into(), vec![a0.to_pod()]),
            DeclKind::DWidget(a0) => Pod::Choice("DWidget".into(), vec![a0.to_pod()]),
            DeclKind::DType(a0) => Pod::Choice("DType".into(), vec![a0.to_pod()]),
            DeclKind::DTag(a0) => Pod::Choice("DTag".into(), vec![a0.to_pod()]),
            DeclKind::DDerive(a0) => Pod::Choice("DDerive".into(), vec![a0.to_pod()]),
            DeclKind::DTrait(a0) => Pod::Choice("DTrait".into(), vec![a0.to_pod()]),
            DeclKind::DImpl(a0) => Pod::Choice("DImpl".into(), vec![a0.to_pod()]),
            DeclKind::DCheck(a0) => Pod::Choice("DCheck".into(), vec![a0.to_pod()]),
            DeclKind::DTest(a0) => Pod::Choice("DTest".into(), vec![a0.to_pod()]),
            DeclKind::DStmt(a0) => Pod::Choice("DStmt".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for DeclKind {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "DSignature" && a.len() == 1 => Ok(DeclKind::DSignature(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DFn" && a.len() == 1 => Ok(DeclKind::DFn(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DLet" && a.len() == 1 => Ok(DeclKind::DLet(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DWidget" && a.len() == 1 => Ok(DeclKind::DWidget(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DType" && a.len() == 1 => Ok(DeclKind::DType(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DTag" && a.len() == 1 => Ok(DeclKind::DTag(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DDerive" && a.len() == 1 => Ok(DeclKind::DDerive(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DTrait" && a.len() == 1 => Ok(DeclKind::DTrait(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DImpl" && a.len() == 1 => Ok(DeclKind::DImpl(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DCheck" && a.len() == 1 => Ok(DeclKind::DCheck(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DTest" && a.len() == 1 => Ok(DeclKind::DTest(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DStmt" && a.len() == 1 => Ok(DeclKind::DStmt(FromPod::from_pod(&a[0])?)),
            other => mismatch("a DeclKind", other),
        }
    }
}

/// `DefName`:
///
/// ```prism
/// type DefName = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum DefName {
    DefSName(crate::syntax::SName),
    DefOp(Text, crate::syntax::Range),
}

impl Show for DefName {
    fn show(&self, p: &mut Printer) {
        match self {
            DefName::DefSName(a0) => p.choice("DefSName", &[a0]),
            DefName::DefOp(a0, a1) => p.choice("DefOp", &[a0, a1]),
        }
    }
}

impl ToPod for DefName {
    fn to_pod(&self) -> Pod {
        match self {
            DefName::DefSName(a0) => Pod::Choice("DefSName".into(), vec![a0.to_pod()]),
            DefName::DefOp(a0, a1) => Pod::Choice("DefOp".into(), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl FromPod for DefName {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "DefSName" && a.len() == 1 => Ok(DefName::DefSName(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DefOp" && a.len() == 2 => Ok(DefName::DefOp(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            other => mismatch("a DefName", other),
        }
    }
}

/// `Delivery`:
///
/// ```prism
/// type Delivery = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Delivery {
    pub kind: DeliveryKind,
    pub target: Target,
    pub span: crate::syntax::Range,
}

impl Show for Delivery {
    fn show(&self, p: &mut Printer) {
        p.record("Delivery", &[("kind", &self.kind), ("target", &self.target), ("span", &self.span)]);
    }
}

impl ToPod for Delivery {
    fn to_pod(&self) -> Pod {
        Pod::record("Delivery", vec![("kind", self.kind.to_pod()), ("target", self.target.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for Delivery {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Delivery { kind: FromPod::from_pod(field(p, "kind")?)?, target: FromPod::from_pod(field(p, "target")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `DeliveryKind`:
///
/// ```prism
/// type DeliveryKind = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum DeliveryKind {
    DkSend(crate::syntax::Expr),
    DkClick,
    DkAnswer,
}

impl Show for DeliveryKind {
    fn show(&self, p: &mut Printer) {
        match self {
            DeliveryKind::DkSend(a0) => p.choice("DkSend", &[a0]),
            DeliveryKind::DkClick => p.choice("DkClick", &[]),
            DeliveryKind::DkAnswer => p.choice("DkAnswer", &[]),
        }
    }
}

impl ToPod for DeliveryKind {
    fn to_pod(&self) -> Pod {
        match self {
            DeliveryKind::DkSend(a0) => Pod::Choice("DkSend".into(), vec![a0.to_pod()]),
            DeliveryKind::DkClick => Pod::Choice("DkClick".into(), vec![]),
            DeliveryKind::DkAnswer => Pod::Choice("DkAnswer".into(), vec![]),
        }
    }
}

impl FromPod for DeliveryKind {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "DkSend" && a.len() == 1 => Ok(DeliveryKind::DkSend(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DkClick" && a.len() == 0 => Ok(DeliveryKind::DkClick),
            Pod::Choice(c, a) if &**c == "DkAnswer" && a.len() == 0 => Ok(DeliveryKind::DkAnswer),
            other => mismatch("a DeliveryKind", other),
        }
    }
}

/// `Entry`:
///
/// ```prism
/// type Entry = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Entry {
    pub element: crate::syntax::Expr,
    pub value: crate::syntax::Expr,
    pub span: crate::syntax::Range,
}

impl Show for Entry {
    fn show(&self, p: &mut Printer) {
        p.record("Entry", &[("element", &self.element), ("value", &self.value), ("span", &self.span)]);
    }
}

impl ToPod for Entry {
    fn to_pod(&self) -> Pod {
        Pod::record("Entry", vec![("element", self.element.to_pod()), ("value", self.value.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for Entry {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Entry { element: FromPod::from_pod(field(p, "element")?)?, value: FromPod::from_pod(field(p, "value")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `Field`:
///
/// ```prism
/// type Field = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Field {
    pub name: crate::syntax::Ident,
    pub ty: crate::syntax::Type,
    pub span: crate::syntax::Range,
}

impl Show for Field {
    fn show(&self, p: &mut Printer) {
        p.record("Field", &[("name", &self.name), ("ty", &self.ty), ("span", &self.span)]);
    }
}

impl ToPod for Field {
    fn to_pod(&self) -> Pod {
        Pod::record("Field", vec![("name", self.name.to_pod()), ("ty", self.ty.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for Field {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Field { name: FromPod::from_pod(field(p, "name")?)?, ty: FromPod::from_pod(field(p, "ty")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `FnBody`:
///
/// ```prism
/// type FnBody = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum FnBody {
    BodyExpr(crate::syntax::Expr),
    BodyBlock(crate::syntax::Block),
}

impl Show for FnBody {
    fn show(&self, p: &mut Printer) {
        match self {
            FnBody::BodyExpr(a0) => p.choice("BodyExpr", &[a0]),
            FnBody::BodyBlock(a0) => p.choice("BodyBlock", &[a0]),
        }
    }
}

impl ToPod for FnBody {
    fn to_pod(&self) -> Pod {
        match self {
            FnBody::BodyExpr(a0) => Pod::Choice("BodyExpr".into(), vec![a0.to_pod()]),
            FnBody::BodyBlock(a0) => Pod::Choice("BodyBlock".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for FnBody {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "BodyExpr" && a.len() == 1 => Ok(FnBody::BodyExpr(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "BodyBlock" && a.len() == 1 => Ok(FnBody::BodyBlock(FromPod::from_pod(&a[0])?)),
            other => mismatch("a FnBody", other),
        }
    }
}

/// `FnClause`:
///
/// ```prism
/// type FnClause = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct FnClause {
    pub name: DefName,
    pub params: Array<crate::syntax::Pattern_>,
    pub body: FnBody,
    pub span: crate::syntax::Range,
}

impl Show for FnClause {
    fn show(&self, p: &mut Printer) {
        p.record("FnClause", &[("name", &self.name), ("params", &self.params), ("body", &self.body), ("span", &self.span)]);
    }
}

impl ToPod for FnClause {
    fn to_pod(&self) -> Pod {
        Pod::record("FnClause", vec![("name", self.name.to_pod()), ("params", self.params.to_pod()), ("body", self.body.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for FnClause {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(FnClause { name: FromPod::from_pod(field(p, "name")?)?, params: FromPod::from_pod(field(p, "params")?)?, body: FromPod::from_pod(field(p, "body")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `ImplDecl`:
///
/// ```prism
/// type ImplDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ImplDecl {
    pub trait_ref: crate::syntax::TraitRef,
    pub ty: crate::syntax::Type,
    pub bounds: Array<Bound>,
    pub items: Array<TraitItem>,
    pub span: crate::syntax::Range,
}

impl Show for ImplDecl {
    fn show(&self, p: &mut Printer) {
        p.record("ImplDecl", &[("trait_ref", &self.trait_ref), ("ty", &self.ty), ("bounds", &self.bounds), ("items", &self.items), ("span", &self.span)]);
    }
}

impl ToPod for ImplDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("ImplDecl", vec![("trait_ref", self.trait_ref.to_pod()), ("ty", self.ty.to_pod()), ("bounds", self.bounds.to_pod()), ("items", self.items.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for ImplDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ImplDecl { trait_ref: FromPod::from_pod(field(p, "trait_ref")?)?, ty: FromPod::from_pod(field(p, "ty")?)?, bounds: FromPod::from_pod(field(p, "bounds")?)?, items: FromPod::from_pod(field(p, "items")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `LetDecl`:
///
/// ```prism
/// type LetDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct LetDecl {
    pub pattern: crate::syntax::Pattern_,
    pub ty: Option<crate::syntax::Type>,
    pub value: crate::syntax::Expr,
    pub span: crate::syntax::Range,
}

impl Show for LetDecl {
    fn show(&self, p: &mut Printer) {
        p.record("LetDecl", &[("pattern", &self.pattern), ("ty", &self.ty), ("value", &self.value), ("span", &self.span)]);
    }
}

impl ToPod for LetDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("LetDecl", vec![("pattern", self.pattern.to_pod()), ("ty", self.ty.to_pod()), ("value", self.value.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for LetDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(LetDecl { pattern: FromPod::from_pod(field(p, "pattern")?)?, ty: FromPod::from_pod(field(p, "ty")?)?, value: FromPod::from_pod(field(p, "value")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `PathSeg`:
///
/// ```prism
/// type PathSeg = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum PathSeg {
    PsNum(Nat),
    PsGen(Nat),
    PsKey(crate::syntax::Expr),
}

impl Show for PathSeg {
    fn show(&self, p: &mut Printer) {
        match self {
            PathSeg::PsNum(a0) => p.choice("PsNum", &[a0]),
            PathSeg::PsGen(a0) => p.choice("PsGen", &[a0]),
            PathSeg::PsKey(a0) => p.choice("PsKey", &[a0]),
        }
    }
}

impl ToPod for PathSeg {
    fn to_pod(&self) -> Pod {
        match self {
            PathSeg::PsNum(a0) => Pod::Choice("PsNum".into(), vec![a0.to_pod()]),
            PathSeg::PsGen(a0) => Pod::Choice("PsGen".into(), vec![a0.to_pod()]),
            PathSeg::PsKey(a0) => Pod::Choice("PsKey".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for PathSeg {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "PsNum" && a.len() == 1 => Ok(PathSeg::PsNum(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PsGen" && a.len() == 1 => Ok(PathSeg::PsGen(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PsKey" && a.len() == 1 => Ok(PathSeg::PsKey(FromPod::from_pod(&a[0])?)),
            other => mismatch("a PathSeg", other),
        }
    }
}

/// `Signature`:
///
/// ```prism
/// type Signature = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Signature {
    pub name: DefName,
    pub ty: crate::syntax::Type,
    pub bounds: Array<Bound>,
    pub span: crate::syntax::Range,
}

impl Show for Signature {
    fn show(&self, p: &mut Printer) {
        p.record("Signature", &[("name", &self.name), ("ty", &self.ty), ("bounds", &self.bounds), ("span", &self.span)]);
    }
}

impl ToPod for Signature {
    fn to_pod(&self) -> Pod {
        Pod::record("Signature", vec![("name", self.name.to_pod()), ("ty", self.ty.to_pod()), ("bounds", self.bounds.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for Signature {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Signature { name: FromPod::from_pod(field(p, "name")?)?, ty: FromPod::from_pod(field(p, "ty")?)?, bounds: FromPod::from_pod(field(p, "bounds")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `StepAction`:
///
/// ```prism
/// type StepAction = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum StepAction {
    SaBuild,
    SaTick,
    SaCompute(bool),
    SaPush(Entry),
    SaDeliver(Array<Delivery>),
    SaWithOnly,
}

impl Show for StepAction {
    fn show(&self, p: &mut Printer) {
        match self {
            StepAction::SaBuild => p.choice("SaBuild", &[]),
            StepAction::SaTick => p.choice("SaTick", &[]),
            StepAction::SaCompute(a0) => p.choice("SaCompute", &[a0]),
            StepAction::SaPush(a0) => p.choice("SaPush", &[a0]),
            StepAction::SaDeliver(a0) => p.choice("SaDeliver", &[a0]),
            StepAction::SaWithOnly => p.choice("SaWithOnly", &[]),
        }
    }
}

impl ToPod for StepAction {
    fn to_pod(&self) -> Pod {
        match self {
            StepAction::SaBuild => Pod::Choice("SaBuild".into(), vec![]),
            StepAction::SaTick => Pod::Choice("SaTick".into(), vec![]),
            StepAction::SaCompute(a0) => Pod::Choice("SaCompute".into(), vec![a0.to_pod()]),
            StepAction::SaPush(a0) => Pod::Choice("SaPush".into(), vec![a0.to_pod()]),
            StepAction::SaDeliver(a0) => Pod::Choice("SaDeliver".into(), vec![a0.to_pod()]),
            StepAction::SaWithOnly => Pod::Choice("SaWithOnly".into(), vec![]),
        }
    }
}

impl FromPod for StepAction {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "SaBuild" && a.len() == 0 => Ok(StepAction::SaBuild),
            Pod::Choice(c, a) if &**c == "SaTick" && a.len() == 0 => Ok(StepAction::SaTick),
            Pod::Choice(c, a) if &**c == "SaCompute" && a.len() == 1 => Ok(StepAction::SaCompute(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SaPush" && a.len() == 1 => Ok(StepAction::SaPush(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SaDeliver" && a.len() == 1 => Ok(StepAction::SaDeliver(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SaWithOnly" && a.len() == 0 => Ok(StepAction::SaWithOnly),
            other => mismatch("a StepAction", other),
        }
    }
}

/// `TagDecl`:
///
/// ```prism
/// type TagDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TagDecl {
    pub name: crate::syntax::QualName,
    pub of_type: crate::syntax::Type,
    pub bounds: Array<Bound>,
    pub fields: Array<Field>,
    pub span: crate::syntax::Range,
}

impl Show for TagDecl {
    fn show(&self, p: &mut Printer) {
        p.record("TagDecl", &[("name", &self.name), ("of_type", &self.of_type), ("bounds", &self.bounds), ("fields", &self.fields), ("span", &self.span)]);
    }
}

impl ToPod for TagDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("TagDecl", vec![("name", self.name.to_pod()), ("of_type", self.of_type.to_pod()), ("bounds", self.bounds.to_pod()), ("fields", self.fields.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for TagDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TagDecl { name: FromPod::from_pod(field(p, "name")?)?, of_type: FromPod::from_pod(field(p, "of_type")?)?, bounds: FromPod::from_pod(field(p, "bounds")?)?, fields: FromPod::from_pod(field(p, "fields")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `Target`:
///
/// ```prism
/// type Target = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Target {
    TgPattern(crate::syntax::Pattern_),
    TgPath(TestPath),
    TgElement(TestPath),
}

impl Show for Target {
    fn show(&self, p: &mut Printer) {
        match self {
            Target::TgPattern(a0) => p.choice("TgPattern", &[a0]),
            Target::TgPath(a0) => p.choice("TgPath", &[a0]),
            Target::TgElement(a0) => p.choice("TgElement", &[a0]),
        }
    }
}

impl ToPod for Target {
    fn to_pod(&self) -> Pod {
        match self {
            Target::TgPattern(a0) => Pod::Choice("TgPattern".into(), vec![a0.to_pod()]),
            Target::TgPath(a0) => Pod::Choice("TgPath".into(), vec![a0.to_pod()]),
            Target::TgElement(a0) => Pod::Choice("TgElement".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for Target {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "TgPattern" && a.len() == 1 => Ok(Target::TgPattern(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TgPath" && a.len() == 1 => Ok(Target::TgPath(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TgElement" && a.len() == 1 => Ok(Target::TgElement(FromPod::from_pod(&a[0])?)),
            other => mismatch("a Target", other),
        }
    }
}

/// `TestCheck`:
///
/// ```prism
/// type TestCheck = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TestCheck {
    pub kind: TestCheckKind,
    pub span: crate::syntax::Range,
}

impl Show for TestCheck {
    fn show(&self, p: &mut Printer) {
        p.record("TestCheck", &[("kind", &self.kind), ("span", &self.span)]);
    }
}

impl ToPod for TestCheck {
    fn to_pod(&self) -> Pod {
        Pod::record("TestCheck", vec![("kind", self.kind.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for TestCheck {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TestCheck { kind: FromPod::from_pod(field(p, "kind")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TestCheckKind`:
///
/// ```prism
/// type TestCheckKind = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum TestCheckKind {
    CkExpect(crate::syntax::Pattern_),
    CkExpectNone(crate::syntax::Pattern_),
    CkExpectCount(crate::syntax::Pattern_, Nat),
    CkExpectTop(crate::syntax::Pattern_),
    CkExpectTopNone(crate::syntax::Pattern_),
    CkRequested(crate::syntax::Pattern_, crate::syntax::Pattern_),
    CkUnrequested(crate::syntax::Pattern_),
    CkReturns(crate::syntax::Pattern_),
    CkFired(crate::syntax::Pattern_),
    CkQuiet,
    CkSettles,
    CkAborted,
    CkSnapshot(Text),
}

impl Show for TestCheckKind {
    fn show(&self, p: &mut Printer) {
        match self {
            TestCheckKind::CkExpect(a0) => p.choice("CkExpect", &[a0]),
            TestCheckKind::CkExpectNone(a0) => p.choice("CkExpectNone", &[a0]),
            TestCheckKind::CkExpectCount(a0, a1) => p.choice("CkExpectCount", &[a0, a1]),
            TestCheckKind::CkExpectTop(a0) => p.choice("CkExpectTop", &[a0]),
            TestCheckKind::CkExpectTopNone(a0) => p.choice("CkExpectTopNone", &[a0]),
            TestCheckKind::CkRequested(a0, a1) => p.choice("CkRequested", &[a0, a1]),
            TestCheckKind::CkUnrequested(a0) => p.choice("CkUnrequested", &[a0]),
            TestCheckKind::CkReturns(a0) => p.choice("CkReturns", &[a0]),
            TestCheckKind::CkFired(a0) => p.choice("CkFired", &[a0]),
            TestCheckKind::CkQuiet => p.choice("CkQuiet", &[]),
            TestCheckKind::CkSettles => p.choice("CkSettles", &[]),
            TestCheckKind::CkAborted => p.choice("CkAborted", &[]),
            TestCheckKind::CkSnapshot(a0) => p.choice("CkSnapshot", &[a0]),
        }
    }
}

impl ToPod for TestCheckKind {
    fn to_pod(&self) -> Pod {
        match self {
            TestCheckKind::CkExpect(a0) => Pod::Choice("CkExpect".into(), vec![a0.to_pod()]),
            TestCheckKind::CkExpectNone(a0) => Pod::Choice("CkExpectNone".into(), vec![a0.to_pod()]),
            TestCheckKind::CkExpectCount(a0, a1) => Pod::Choice("CkExpectCount".into(), vec![a0.to_pod(), a1.to_pod()]),
            TestCheckKind::CkExpectTop(a0) => Pod::Choice("CkExpectTop".into(), vec![a0.to_pod()]),
            TestCheckKind::CkExpectTopNone(a0) => Pod::Choice("CkExpectTopNone".into(), vec![a0.to_pod()]),
            TestCheckKind::CkRequested(a0, a1) => Pod::Choice("CkRequested".into(), vec![a0.to_pod(), a1.to_pod()]),
            TestCheckKind::CkUnrequested(a0) => Pod::Choice("CkUnrequested".into(), vec![a0.to_pod()]),
            TestCheckKind::CkReturns(a0) => Pod::Choice("CkReturns".into(), vec![a0.to_pod()]),
            TestCheckKind::CkFired(a0) => Pod::Choice("CkFired".into(), vec![a0.to_pod()]),
            TestCheckKind::CkQuiet => Pod::Choice("CkQuiet".into(), vec![]),
            TestCheckKind::CkSettles => Pod::Choice("CkSettles".into(), vec![]),
            TestCheckKind::CkAborted => Pod::Choice("CkAborted".into(), vec![]),
            TestCheckKind::CkSnapshot(a0) => Pod::Choice("CkSnapshot".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for TestCheckKind {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "CkExpect" && a.len() == 1 => Ok(TestCheckKind::CkExpect(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CkExpectNone" && a.len() == 1 => Ok(TestCheckKind::CkExpectNone(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CkExpectCount" && a.len() == 2 => Ok(TestCheckKind::CkExpectCount(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "CkExpectTop" && a.len() == 1 => Ok(TestCheckKind::CkExpectTop(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CkExpectTopNone" && a.len() == 1 => Ok(TestCheckKind::CkExpectTopNone(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CkRequested" && a.len() == 2 => Ok(TestCheckKind::CkRequested(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "CkUnrequested" && a.len() == 1 => Ok(TestCheckKind::CkUnrequested(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CkReturns" && a.len() == 1 => Ok(TestCheckKind::CkReturns(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CkFired" && a.len() == 1 => Ok(TestCheckKind::CkFired(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CkQuiet" && a.len() == 0 => Ok(TestCheckKind::CkQuiet),
            Pod::Choice(c, a) if &**c == "CkSettles" && a.len() == 0 => Ok(TestCheckKind::CkSettles),
            Pod::Choice(c, a) if &**c == "CkAborted" && a.len() == 0 => Ok(TestCheckKind::CkAborted),
            Pod::Choice(c, a) if &**c == "CkSnapshot" && a.len() == 1 => Ok(TestCheckKind::CkSnapshot(FromPod::from_pod(&a[0])?)),
            other => mismatch("a TestCheckKind", other),
        }
    }
}

/// `TestDecl`:
///
/// ```prism
/// type TestDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TestDecl {
    pub name: crate::syntax::Ident,
    pub blueprint: crate::syntax::Expr,
    pub seed: Option<Nat>,
    pub steps: Array<TestStep>,
    pub span: crate::syntax::Range,
}

impl Show for TestDecl {
    fn show(&self, p: &mut Printer) {
        p.record("TestDecl", &[("name", &self.name), ("blueprint", &self.blueprint), ("seed", &self.seed), ("steps", &self.steps), ("span", &self.span)]);
    }
}

impl ToPod for TestDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("TestDecl", vec![("name", self.name.to_pod()), ("blueprint", self.blueprint.to_pod()), ("seed", self.seed.to_pod()), ("steps", self.steps.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for TestDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TestDecl { name: FromPod::from_pod(field(p, "name")?)?, blueprint: FromPod::from_pod(field(p, "blueprint")?)?, seed: FromPod::from_pod(field(p, "seed")?)?, steps: FromPod::from_pod(field(p, "steps")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TestPath`:
///
/// ```prism
/// type TestPath = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TestPath {
    pub segments: Array<PathSeg>,
    pub span: crate::syntax::Range,
}

impl Show for TestPath {
    fn show(&self, p: &mut Printer) {
        p.record("TestPath", &[("segments", &self.segments), ("span", &self.span)]);
    }
}

impl ToPod for TestPath {
    fn to_pod(&self) -> Pod {
        Pod::record("TestPath", vec![("segments", self.segments.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for TestPath {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TestPath { segments: FromPod::from_pod(field(p, "segments")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TestStep`:
///
/// ```prism
/// type TestStep = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TestStep {
    pub withs: Array<Entry>,
    pub action: StepAction,
    pub checks: Array<TestCheck>,
    pub span: crate::syntax::Range,
}

impl Show for TestStep {
    fn show(&self, p: &mut Printer) {
        p.record("TestStep", &[("withs", &self.withs), ("action", &self.action), ("checks", &self.checks), ("span", &self.span)]);
    }
}

impl ToPod for TestStep {
    fn to_pod(&self) -> Pod {
        Pod::record("TestStep", vec![("withs", self.withs.to_pod()), ("action", self.action.to_pod()), ("checks", self.checks.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for TestStep {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TestStep { withs: FromPod::from_pod(field(p, "withs")?)?, action: FromPod::from_pod(field(p, "action")?)?, checks: FromPod::from_pod(field(p, "checks")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TraitDecl`:
///
/// ```prism
/// type TraitDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TraitDecl {
    pub name: crate::syntax::TraitRef,
    pub params: Array<crate::syntax::Ident>,
    pub bounds: Array<Bound>,
    pub items: Array<TraitItem>,
    pub span: crate::syntax::Range,
}

impl Show for TraitDecl {
    fn show(&self, p: &mut Printer) {
        p.record("TraitDecl", &[("name", &self.name), ("params", &self.params), ("bounds", &self.bounds), ("items", &self.items), ("span", &self.span)]);
    }
}

impl ToPod for TraitDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("TraitDecl", vec![("name", self.name.to_pod()), ("params", self.params.to_pod()), ("bounds", self.bounds.to_pod()), ("items", self.items.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for TraitDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TraitDecl { name: FromPod::from_pod(field(p, "name")?)?, params: FromPod::from_pod(field(p, "params")?)?, bounds: FromPod::from_pod(field(p, "bounds")?)?, items: FromPod::from_pod(field(p, "items")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TraitItem`:
///
/// ```prism
/// type TraitItem = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum TraitItem {
    TiSignature(Signature),
    TiFn(FnClause),
    TiAssocType(crate::syntax::Ident, Array<crate::syntax::Ident>, Option<crate::syntax::Type>, crate::syntax::Range),
    TiAssocRow(crate::syntax::SName, crate::syntax::Range),
}

impl Show for TraitItem {
    fn show(&self, p: &mut Printer) {
        match self {
            TraitItem::TiSignature(a0) => p.choice("TiSignature", &[a0]),
            TraitItem::TiFn(a0) => p.choice("TiFn", &[a0]),
            TraitItem::TiAssocType(a0, a1, a2, a3) => p.choice("TiAssocType", &[a0, a1, a2, a3]),
            TraitItem::TiAssocRow(a0, a1) => p.choice("TiAssocRow", &[a0, a1]),
        }
    }
}

impl ToPod for TraitItem {
    fn to_pod(&self) -> Pod {
        match self {
            TraitItem::TiSignature(a0) => Pod::Choice("TiSignature".into(), vec![a0.to_pod()]),
            TraitItem::TiFn(a0) => Pod::Choice("TiFn".into(), vec![a0.to_pod()]),
            TraitItem::TiAssocType(a0, a1, a2, a3) => Pod::Choice("TiAssocType".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
            TraitItem::TiAssocRow(a0, a1) => Pod::Choice("TiAssocRow".into(), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl FromPod for TraitItem {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "TiSignature" && a.len() == 1 => Ok(TraitItem::TiSignature(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TiFn" && a.len() == 1 => Ok(TraitItem::TiFn(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TiAssocType" && a.len() == 4 => Ok(TraitItem::TiAssocType(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?, FromPod::from_pod(&a[3])?)),
            Pod::Choice(c, a) if &**c == "TiAssocRow" && a.len() == 2 => Ok(TraitItem::TiAssocRow(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            other => mismatch("a TraitItem", other),
        }
    }
}

/// `TypeBody`:
///
/// ```prism
/// type TypeBody = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum TypeBody {
    TbRecord(Array<Field>),
    TbChoice(Array<Case_>),
    TbRow,
    TbNewtype(Case_),
    TbUnit(crate::syntax::Ident),
    TbAlias(crate::syntax::Type),
}

impl Show for TypeBody {
    fn show(&self, p: &mut Printer) {
        match self {
            TypeBody::TbRecord(a0) => p.choice("TbRecord", &[a0]),
            TypeBody::TbChoice(a0) => p.choice("TbChoice", &[a0]),
            TypeBody::TbRow => p.choice("TbRow", &[]),
            TypeBody::TbNewtype(a0) => p.choice("TbNewtype", &[a0]),
            TypeBody::TbUnit(a0) => p.choice("TbUnit", &[a0]),
            TypeBody::TbAlias(a0) => p.choice("TbAlias", &[a0]),
        }
    }
}

impl ToPod for TypeBody {
    fn to_pod(&self) -> Pod {
        match self {
            TypeBody::TbRecord(a0) => Pod::Choice("TbRecord".into(), vec![a0.to_pod()]),
            TypeBody::TbChoice(a0) => Pod::Choice("TbChoice".into(), vec![a0.to_pod()]),
            TypeBody::TbRow => Pod::Choice("TbRow".into(), vec![]),
            TypeBody::TbNewtype(a0) => Pod::Choice("TbNewtype".into(), vec![a0.to_pod()]),
            TypeBody::TbUnit(a0) => Pod::Choice("TbUnit".into(), vec![a0.to_pod()]),
            TypeBody::TbAlias(a0) => Pod::Choice("TbAlias".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for TypeBody {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "TbRecord" && a.len() == 1 => Ok(TypeBody::TbRecord(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TbChoice" && a.len() == 1 => Ok(TypeBody::TbChoice(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TbRow" && a.len() == 0 => Ok(TypeBody::TbRow),
            Pod::Choice(c, a) if &**c == "TbNewtype" && a.len() == 1 => Ok(TypeBody::TbNewtype(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TbUnit" && a.len() == 1 => Ok(TypeBody::TbUnit(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TbAlias" && a.len() == 1 => Ok(TypeBody::TbAlias(FromPod::from_pod(&a[0])?)),
            other => mismatch("a TypeBody", other),
        }
    }
}

/// `TypeDecl`:
///
/// ```prism
/// type TypeDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TypeDecl {
    pub name: crate::syntax::QualName,
    pub params: Array<crate::syntax::Ident>,
    pub body: Option<TypeBody>,
    pub span: crate::syntax::Range,
}

impl Show for TypeDecl {
    fn show(&self, p: &mut Printer) {
        p.record("TypeDecl", &[("name", &self.name), ("params", &self.params), ("body", &self.body), ("span", &self.span)]);
    }
}

impl ToPod for TypeDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("TypeDecl", vec![("name", self.name.to_pod()), ("params", self.params.to_pod()), ("body", self.body.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for TypeDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TypeDecl { name: FromPod::from_pod(field(p, "name")?)?, params: FromPod::from_pod(field(p, "params")?)?, body: FromPod::from_pod(field(p, "body")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `WidgetDecl`:
///
/// ```prism
/// type WidgetDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct WidgetDecl {
    pub name: crate::syntax::SName,
    pub body: crate::syntax::Block,
    pub span: crate::syntax::Range,
}

impl Show for WidgetDecl {
    fn show(&self, p: &mut Printer) {
        p.record("WidgetDecl", &[("name", &self.name), ("body", &self.body), ("span", &self.span)]);
    }
}

impl ToPod for WidgetDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("WidgetDecl", vec![("name", self.name.to_pod()), ("body", self.body.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for WidgetDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(WidgetDecl { name: FromPod::from_pod(field(p, "name")?)?, body: FromPod::from_pod(field(p, "body")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}
