//! The module `Syntax`, from `target/bootstrap/src/prismc/syntax/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;
pub mod decls;
pub mod lexer;
pub mod parser;
pub mod sexp;

/// `Arg`:
///
/// ```prism
/// type Arg = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Arg {
    pub marks_p: crate::prelude::Text,
    pub name_o: ::std::option::Option<Ident>,
    pub value_p: Expr,
    pub span_p: Range,
}

impl crate::prelude::Show for Arg {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Arg", &[("marks", &self.marks_p), ("name", &self.name_o), ("value", &self.value_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for Arg {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Arg", vec![("marks", self.marks_p.to_pod()), ("name", self.name_o.to_pod()), ("value", self.value_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Arg {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Arg { marks_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "marks")?)?, name_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, value_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "value")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `Arm`:
///
/// ```prism
/// type Arm = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Arm {
    pub pattern_o: ::std::option::Option<Pattern>,
    pub guard_o: ::std::option::Option<Expr>,
    pub body_p: Block,
    pub span_p: Range,
}

impl crate::prelude::Show for Arm {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Arm", &[("pattern", &self.pattern_o), ("guard", &self.guard_o), ("body", &self.body_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for Arm {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Arm", vec![("pattern", self.pattern_o.to_pod()), ("guard", self.guard_o.to_pod()), ("body", self.body_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Arm {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Arm { pattern_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "pattern")?)?, guard_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "guard")?)?, body_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "body")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `Block`:
///
/// ```prism
/// type Block = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Block {
    pub stmts_p: crate::prelude::Array<Stmt>,
    pub inline_p: bool,
    pub span_p: Range,
}

impl crate::prelude::Show for Block {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Block", &[("stmts", &self.stmts_p), ("inline", &self.inline_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for Block {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Block", vec![("stmts", self.stmts_p.to_pod()), ("inline", self.inline_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Block {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Block { stmts_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "stmts")?)?, inline_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "inline")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `Color`:
///
/// ```prism
/// type Color = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum Color {
    Bounded,
    Unbounded,
    ColorVar(Ident),
}

impl crate::prelude::Show for Color {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            Color::Bounded => p.choice("Bounded", &[]),
            Color::Unbounded => p.choice("Unbounded", &[]),
            Color::ColorVar(a0) => p.choice("ColorVar", &[a0]),
        }
    }
}

impl crate::prelude::ToPod for Color {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            Color::Bounded => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("Bounded", 0), vec![]),
            Color::Unbounded => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("Unbounded", 1), vec![]),
            Color::ColorVar(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ColorVar", 2), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for Color {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "Bounded" && a.len() == 0 => ::std::result::Result::Ok(Color::Bounded),
            crate::prelude::Pod::Choice(c, a) if &**c == "Unbounded" && a.len() == 0 => ::std::result::Result::Ok(Color::Unbounded),
            crate::prelude::Pod::Choice(c, a) if &**c == "ColorVar" && a.len() == 1 => ::std::result::Result::Ok(Color::ColorVar(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a Color", other),
        }
    }
}

/// `Cond`:
///
/// ```prism
/// type Cond = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum Cond {
    CondExpr(::std::rc::Rc<Expr>),
    CondBind(Pattern, ::std::rc::Rc<Expr>, ::std::rc::Rc<::std::option::Option<Expr>>),
}

impl crate::prelude::Show for Cond {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            Cond::CondExpr(a0) => p.choice("CondExpr", &[a0]),
            Cond::CondBind(a0, a1, a2) => p.choice("CondBind", &[a0, a1, a2]),
        }
    }
}

impl crate::prelude::ToPod for Cond {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            Cond::CondExpr(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CondExpr", 0), vec![a0.to_pod()]),
            Cond::CondBind(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("CondBind", 1), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for Cond {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "CondExpr" && a.len() == 1 => ::std::result::Result::Ok(Cond::CondExpr(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "CondBind" && a.len() == 3 => ::std::result::Result::Ok(Cond::CondBind(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            other => ::prism_rtl::pod::mismatch("a Cond", other),
        }
    }
}

/// `Diag`:
///
/// ```prism
/// type Diag = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Diag {
    pub stage_p: crate::prelude::Text,
    pub span_p: Range,
    pub message_p: crate::prelude::Text,
    pub feature_o: ::std::option::Option<crate::prelude::Text>,
}

impl crate::prelude::Show for Diag {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Diag", &[("stage", &self.stage_p), ("span", &self.span_p), ("message", &self.message_p), ("feature", &self.feature_o)]);
    }
}

impl crate::prelude::ToPod for Diag {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Diag", vec![("stage", self.stage_p.to_pod()), ("span", self.span_p.to_pod()), ("message", self.message_p.to_pod()), ("feature", self.feature_o.to_pod())])
    }
}

impl crate::prelude::FromPod for Diag {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Diag { stage_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "stage")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)?, message_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "message")?)?, feature_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "feature")?)? })
    }
}

/// `Expr`:
///
/// ```prism
/// type Expr = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Expr {
    pub kind_p: ::std::rc::Rc<ExprKind>,
    pub span_p: Range,
}

impl crate::prelude::Show for Expr {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Expr", &[("kind", &self.kind_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for Expr {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Expr", vec![("kind", self.kind_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Expr {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Expr { kind_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "kind")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `ExprKind`:
///
/// ```prism
/// type ExprKind = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum ExprKind {
    EName(SName),
    ELit(Literal),
    EUnit(crate::prelude::Text),
    ENil(crate::prelude::Text),
    EBound(crate::prelude::Text),
    ETuple(crate::prelude::Array<Expr>),
    EArray(crate::prelude::Array<Expr>),
    EMap(crate::prelude::Array<(Expr, Expr)>),
    EGroup(::std::rc::Rc<Expr>),
    ECall(::std::rc::Rc<Expr>, crate::prelude::Array<Arg>, bool, bool),
    EBinary(crate::prelude::Text, ::std::rc::Rc<Expr>, ::std::rc::Rc<Expr>),
    EUnary(crate::prelude::Text, ::std::rc::Rc<Expr>),
    ESuffixed(crate::prelude::Text, QualName, ::std::rc::Rc<Expr>, ::std::rc::Rc<Expr>),
    EFreeSigil(crate::prelude::Text, ::std::rc::Rc<Expr>),
    EField(::std::rc::Rc<Expr>, crate::prelude::Text, Ident),
    EIndex(::std::rc::Rc<Expr>, ::std::rc::Rc<Expr>),
    ETopicField(Ident),
    ETopicIndex(::std::rc::Rc<Expr>),
    EMethod(::std::rc::Rc<Expr>, SName, crate::prelude::Array<Arg>),
    ETypeArgs(::std::rc::Rc<Expr>, crate::prelude::Array<Type>),
    ECast(::std::rc::Rc<Expr>, Type, bool),
    ENonEmpty(::std::rc::Rc<Expr>),
    EAbsent,
    ERest,
    ELambda(::std::option::Option<crate::prelude::Array<Pattern>>, ::std::rc::Rc<LambdaBody>),
    EIf(::std::rc::Rc<Cond>, Block, ::std::option::Option<Block>),
    EMatch(::std::rc::Rc<Expr>, crate::prelude::Array<Arm>),
    ERebuild(::std::rc::Rc<Expr>, Block),
    EFor(::std::option::Option<ForBinders>, ::std::rc::Rc<Expr>, Block),
    EGiven(Block),
    EUpdate(::std::rc::Rc<Expr>, Block),
    EWidgetBlock(Block),
    EMonad(::std::rc::Rc<Expr>, Block),
    ETemplate(Template),
    EAny(::std::rc::Rc<Expr>),
    ELens(crate::prelude::Array<Ident>),
    EError,
}

impl crate::prelude::Show for ExprKind {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            ExprKind::EName(a0) => p.choice("EName", &[a0]),
            ExprKind::ELit(a0) => p.choice("ELit", &[a0]),
            ExprKind::EUnit(a0) => p.choice("EUnit", &[a0]),
            ExprKind::ENil(a0) => p.choice("ENil", &[a0]),
            ExprKind::EBound(a0) => p.choice("EBound", &[a0]),
            ExprKind::ETuple(a0) => p.choice("ETuple", &[a0]),
            ExprKind::EArray(a0) => p.choice("EArray", &[a0]),
            ExprKind::EMap(a0) => p.choice("EMap", &[a0]),
            ExprKind::EGroup(a0) => p.choice("EGroup", &[a0]),
            ExprKind::ECall(a0, a1, a2, a3) => p.choice("ECall", &[a0, a1, a2, a3]),
            ExprKind::EBinary(a0, a1, a2) => p.choice("EBinary", &[a0, a1, a2]),
            ExprKind::EUnary(a0, a1) => p.choice("EUnary", &[a0, a1]),
            ExprKind::ESuffixed(a0, a1, a2, a3) => p.choice("ESuffixed", &[a0, a1, a2, a3]),
            ExprKind::EFreeSigil(a0, a1) => p.choice("EFreeSigil", &[a0, a1]),
            ExprKind::EField(a0, a1, a2) => p.choice("EField", &[a0, a1, a2]),
            ExprKind::EIndex(a0, a1) => p.choice("EIndex", &[a0, a1]),
            ExprKind::ETopicField(a0) => p.choice("ETopicField", &[a0]),
            ExprKind::ETopicIndex(a0) => p.choice("ETopicIndex", &[a0]),
            ExprKind::EMethod(a0, a1, a2) => p.choice("EMethod", &[a0, a1, a2]),
            ExprKind::ETypeArgs(a0, a1) => p.choice("ETypeArgs", &[a0, a1]),
            ExprKind::ECast(a0, a1, a2) => p.choice("ECast", &[a0, a1, a2]),
            ExprKind::ENonEmpty(a0) => p.choice("ENonEmpty", &[a0]),
            ExprKind::EAbsent => p.choice("EAbsent", &[]),
            ExprKind::ERest => p.choice("ERest", &[]),
            ExprKind::ELambda(a0, a1) => p.choice("ELambda", &[a0, a1]),
            ExprKind::EIf(a0, a1, a2) => p.choice("EIf", &[a0, a1, a2]),
            ExprKind::EMatch(a0, a1) => p.choice("EMatch", &[a0, a1]),
            ExprKind::ERebuild(a0, a1) => p.choice("ERebuild", &[a0, a1]),
            ExprKind::EFor(a0, a1, a2) => p.choice("EFor", &[a0, a1, a2]),
            ExprKind::EGiven(a0) => p.choice("EGiven", &[a0]),
            ExprKind::EUpdate(a0, a1) => p.choice("EUpdate", &[a0, a1]),
            ExprKind::EWidgetBlock(a0) => p.choice("EWidgetBlock", &[a0]),
            ExprKind::EMonad(a0, a1) => p.choice("EMonad", &[a0, a1]),
            ExprKind::ETemplate(a0) => p.choice("ETemplate", &[a0]),
            ExprKind::EAny(a0) => p.choice("EAny", &[a0]),
            ExprKind::ELens(a0) => p.choice("ELens", &[a0]),
            ExprKind::EError => p.choice("EError", &[]),
        }
    }
}

impl crate::prelude::ToPod for ExprKind {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            ExprKind::EName(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("EName", 0), vec![a0.to_pod()]),
            ExprKind::ELit(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ELit", 1), vec![a0.to_pod()]),
            ExprKind::EUnit(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("EUnit", 2), vec![a0.to_pod()]),
            ExprKind::ENil(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ENil", 3), vec![a0.to_pod()]),
            ExprKind::EBound(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("EBound", 4), vec![a0.to_pod()]),
            ExprKind::ETuple(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ETuple", 5), vec![a0.to_pod()]),
            ExprKind::EArray(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("EArray", 6), vec![a0.to_pod()]),
            ExprKind::EMap(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("EMap", 7), vec![a0.to_pod()]),
            ExprKind::EGroup(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("EGroup", 8), vec![a0.to_pod()]),
            ExprKind::ECall(a0, a1, a2, a3) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ECall", 9), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
            ExprKind::EBinary(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("EBinary", 10), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            ExprKind::EUnary(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("EUnary", 11), vec![a0.to_pod(), a1.to_pod()]),
            ExprKind::ESuffixed(a0, a1, a2, a3) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ESuffixed", 12), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
            ExprKind::EFreeSigil(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("EFreeSigil", 13), vec![a0.to_pod(), a1.to_pod()]),
            ExprKind::EField(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("EField", 14), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            ExprKind::EIndex(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("EIndex", 15), vec![a0.to_pod(), a1.to_pod()]),
            ExprKind::ETopicField(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ETopicField", 16), vec![a0.to_pod()]),
            ExprKind::ETopicIndex(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ETopicIndex", 17), vec![a0.to_pod()]),
            ExprKind::EMethod(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("EMethod", 18), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            ExprKind::ETypeArgs(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ETypeArgs", 19), vec![a0.to_pod(), a1.to_pod()]),
            ExprKind::ECast(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ECast", 20), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            ExprKind::ENonEmpty(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ENonEmpty", 21), vec![a0.to_pod()]),
            ExprKind::EAbsent => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("EAbsent", 22), vec![]),
            ExprKind::ERest => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ERest", 23), vec![]),
            ExprKind::ELambda(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ELambda", 24), vec![a0.to_pod(), a1.to_pod()]),
            ExprKind::EIf(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("EIf", 25), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            ExprKind::EMatch(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("EMatch", 26), vec![a0.to_pod(), a1.to_pod()]),
            ExprKind::ERebuild(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ERebuild", 27), vec![a0.to_pod(), a1.to_pod()]),
            ExprKind::EFor(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("EFor", 28), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            ExprKind::EGiven(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("EGiven", 29), vec![a0.to_pod()]),
            ExprKind::EUpdate(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("EUpdate", 30), vec![a0.to_pod(), a1.to_pod()]),
            ExprKind::EWidgetBlock(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("EWidgetBlock", 31), vec![a0.to_pod()]),
            ExprKind::EMonad(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("EMonad", 32), vec![a0.to_pod(), a1.to_pod()]),
            ExprKind::ETemplate(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ETemplate", 33), vec![a0.to_pod()]),
            ExprKind::EAny(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("EAny", 34), vec![a0.to_pod()]),
            ExprKind::ELens(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("ELens", 35), vec![a0.to_pod()]),
            ExprKind::EError => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("EError", 36), vec![]),
        }
    }
}

impl crate::prelude::FromPod for ExprKind {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "EName" && a.len() == 1 => ::std::result::Result::Ok(ExprKind::EName(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "ELit" && a.len() == 1 => ::std::result::Result::Ok(ExprKind::ELit(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "EUnit" && a.len() == 1 => ::std::result::Result::Ok(ExprKind::EUnit(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "ENil" && a.len() == 1 => ::std::result::Result::Ok(ExprKind::ENil(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "EBound" && a.len() == 1 => ::std::result::Result::Ok(ExprKind::EBound(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "ETuple" && a.len() == 1 => ::std::result::Result::Ok(ExprKind::ETuple(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "EArray" && a.len() == 1 => ::std::result::Result::Ok(ExprKind::EArray(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "EMap" && a.len() == 1 => ::std::result::Result::Ok(ExprKind::EMap(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "EGroup" && a.len() == 1 => ::std::result::Result::Ok(ExprKind::EGroup(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "ECall" && a.len() == 4 => ::std::result::Result::Ok(ExprKind::ECall(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?, crate::prelude::FromPod::from_pod(&a[3])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "EBinary" && a.len() == 3 => ::std::result::Result::Ok(ExprKind::EBinary(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "EUnary" && a.len() == 2 => ::std::result::Result::Ok(ExprKind::EUnary(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "ESuffixed" && a.len() == 4 => ::std::result::Result::Ok(ExprKind::ESuffixed(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?, crate::prelude::FromPod::from_pod(&a[3])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "EFreeSigil" && a.len() == 2 => ::std::result::Result::Ok(ExprKind::EFreeSigil(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "EField" && a.len() == 3 => ::std::result::Result::Ok(ExprKind::EField(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "EIndex" && a.len() == 2 => ::std::result::Result::Ok(ExprKind::EIndex(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "ETopicField" && a.len() == 1 => ::std::result::Result::Ok(ExprKind::ETopicField(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "ETopicIndex" && a.len() == 1 => ::std::result::Result::Ok(ExprKind::ETopicIndex(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "EMethod" && a.len() == 3 => ::std::result::Result::Ok(ExprKind::EMethod(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "ETypeArgs" && a.len() == 2 => ::std::result::Result::Ok(ExprKind::ETypeArgs(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "ECast" && a.len() == 3 => ::std::result::Result::Ok(ExprKind::ECast(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "ENonEmpty" && a.len() == 1 => ::std::result::Result::Ok(ExprKind::ENonEmpty(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "EAbsent" && a.len() == 0 => ::std::result::Result::Ok(ExprKind::EAbsent),
            crate::prelude::Pod::Choice(c, a) if &**c == "ERest" && a.len() == 0 => ::std::result::Result::Ok(ExprKind::ERest),
            crate::prelude::Pod::Choice(c, a) if &**c == "ELambda" && a.len() == 2 => ::std::result::Result::Ok(ExprKind::ELambda(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "EIf" && a.len() == 3 => ::std::result::Result::Ok(ExprKind::EIf(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "EMatch" && a.len() == 2 => ::std::result::Result::Ok(ExprKind::EMatch(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "ERebuild" && a.len() == 2 => ::std::result::Result::Ok(ExprKind::ERebuild(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "EFor" && a.len() == 3 => ::std::result::Result::Ok(ExprKind::EFor(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "EGiven" && a.len() == 1 => ::std::result::Result::Ok(ExprKind::EGiven(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "EUpdate" && a.len() == 2 => ::std::result::Result::Ok(ExprKind::EUpdate(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "EWidgetBlock" && a.len() == 1 => ::std::result::Result::Ok(ExprKind::EWidgetBlock(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "EMonad" && a.len() == 2 => ::std::result::Result::Ok(ExprKind::EMonad(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "ETemplate" && a.len() == 1 => ::std::result::Result::Ok(ExprKind::ETemplate(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "EAny" && a.len() == 1 => ::std::result::Result::Ok(ExprKind::EAny(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "ELens" && a.len() == 1 => ::std::result::Result::Ok(ExprKind::ELens(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "EError" && a.len() == 0 => ::std::result::Result::Ok(ExprKind::EError),
            other => ::prism_rtl::pod::mismatch("a ExprKind", other),
        }
    }
}

/// `FieldPat`:
///
/// ```prism
/// type FieldPat = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct FieldPat {
    pub marks_p: crate::prelude::Text,
    pub name_o: ::std::option::Option<Ident>,
    pub pattern_p: Pattern,
    pub span_p: Range,
}

impl crate::prelude::Show for FieldPat {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("FieldPat", &[("marks", &self.marks_p), ("name", &self.name_o), ("pattern", &self.pattern_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for FieldPat {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("FieldPat", vec![("marks", self.marks_p.to_pod()), ("name", self.name_o.to_pod()), ("pattern", self.pattern_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for FieldPat {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(FieldPat { marks_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "marks")?)?, name_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, pattern_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "pattern")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `ForBinders`:
///
/// ```prism
/// type ForBinders = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct ForBinders {
    pub first_p: Pattern,
    pub second_o: ::std::option::Option<Pattern>,
}

impl crate::prelude::Show for ForBinders {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("ForBinders", &[("first", &self.first_p), ("second", &self.second_o)]);
    }
}

impl crate::prelude::ToPod for ForBinders {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("ForBinders", vec![("first", self.first_p.to_pod()), ("second", self.second_o.to_pod())])
    }
}

impl crate::prelude::FromPod for ForBinders {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(ForBinders { first_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "first")?)?, second_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "second")?)? })
    }
}

/// `Ident`:
///
/// ```prism
/// type Ident = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Ident {
    pub name_p: crate::prelude::Text,
    pub span_p: Range,
}

impl crate::prelude::Show for Ident {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Ident", &[("name", &self.name_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for Ident {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Ident", vec![("name", self.name_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Ident {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Ident { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `LambdaBody`:
///
/// ```prism
/// type LambdaBody = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum LambdaBody {
    LbExpr(::std::rc::Rc<Expr>),
    LbBlock(Block),
}

impl crate::prelude::Show for LambdaBody {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            LambdaBody::LbExpr(a0) => p.choice("LbExpr", &[a0]),
            LambdaBody::LbBlock(a0) => p.choice("LbBlock", &[a0]),
        }
    }
}

impl crate::prelude::ToPod for LambdaBody {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            LambdaBody::LbExpr(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("LbExpr", 0), vec![a0.to_pod()]),
            LambdaBody::LbBlock(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("LbBlock", 1), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for LambdaBody {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "LbExpr" && a.len() == 1 => ::std::result::Result::Ok(LambdaBody::LbExpr(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "LbBlock" && a.len() == 1 => ::std::result::Result::Ok(LambdaBody::LbBlock(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a LambdaBody", other),
        }
    }
}

/// `LitKind`:
///
/// ```prism
/// type LitKind = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum LitKind {
    LInt(crate::prelude::Text),
    LFloat(crate::prelude::Text),
    LDuration(crate::prelude::Text, crate::prelude::Text),
    LChar(crate::prelude::Text),
    LText(crate::prelude::Array<TextSeg>),
    LRegex(RegexLit),
}

impl crate::prelude::Show for LitKind {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            LitKind::LInt(a0) => p.choice("LInt", &[a0]),
            LitKind::LFloat(a0) => p.choice("LFloat", &[a0]),
            LitKind::LDuration(a0, a1) => p.choice("LDuration", &[a0, a1]),
            LitKind::LChar(a0) => p.choice("LChar", &[a0]),
            LitKind::LText(a0) => p.choice("LText", &[a0]),
            LitKind::LRegex(a0) => p.choice("LRegex", &[a0]),
        }
    }
}

impl crate::prelude::ToPod for LitKind {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            LitKind::LInt(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("LInt", 0), vec![a0.to_pod()]),
            LitKind::LFloat(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("LFloat", 1), vec![a0.to_pod()]),
            LitKind::LDuration(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("LDuration", 2), vec![a0.to_pod(), a1.to_pod()]),
            LitKind::LChar(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("LChar", 3), vec![a0.to_pod()]),
            LitKind::LText(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("LText", 4), vec![a0.to_pod()]),
            LitKind::LRegex(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("LRegex", 5), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for LitKind {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "LInt" && a.len() == 1 => ::std::result::Result::Ok(LitKind::LInt(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "LFloat" && a.len() == 1 => ::std::result::Result::Ok(LitKind::LFloat(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "LDuration" && a.len() == 2 => ::std::result::Result::Ok(LitKind::LDuration(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "LChar" && a.len() == 1 => ::std::result::Result::Ok(LitKind::LChar(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "LText" && a.len() == 1 => ::std::result::Result::Ok(LitKind::LText(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "LRegex" && a.len() == 1 => ::std::result::Result::Ok(LitKind::LRegex(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a LitKind", other),
        }
    }
}

/// `Literal`:
///
/// ```prism
/// type Literal = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Literal {
    pub marks_p: crate::prelude::Text,
    pub kind_p: LitKind,
    pub span_p: Range,
}

impl crate::prelude::Show for Literal {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Literal", &[("marks", &self.marks_p), ("kind", &self.kind_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for Literal {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Literal", vec![("marks", self.marks_p.to_pod()), ("kind", self.kind_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Literal {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Literal { marks_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "marks")?)?, kind_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "kind")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `ModLine`:
///
/// ```prism
/// type ModLine = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct ModLine {
    pub name_p: Ident,
    pub is_test_p: bool,
    pub span_p: Range,
}

impl crate::prelude::Show for ModLine {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("ModLine", &[("name", &self.name_p), ("isTest", &self.is_test_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for ModLine {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("ModLine", vec![("name", self.name_p.to_pod()), ("isTest", self.is_test_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for ModLine {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(ModLine { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, is_test_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "isTest")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `Module`:
///
/// ```prism
/// type Module = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Module {
    pub name_o: ::std::option::Option<QualName>,
    pub emit_row_o: ::std::option::Option<Row>,
    pub mods_p: crate::prelude::Array<ModLine>,
    pub uses_p: crate::prelude::Array<Use>,
    pub decls_p: crate::prelude::Array<crate::syntax::decls::Decl>,
    pub template_o: ::std::option::Option<Template>,
    pub span_p: Range,
}

impl crate::prelude::Show for Module {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Module", &[("name", &self.name_o), ("emitRow", &self.emit_row_o), ("mods", &self.mods_p), ("uses", &self.uses_p), ("decls", &self.decls_p), ("template", &self.template_o), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for Module {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Module", vec![("name", self.name_o.to_pod()), ("emitRow", self.emit_row_o.to_pod()), ("mods", self.mods_p.to_pod()), ("uses", self.uses_p.to_pod()), ("decls", self.decls_p.to_pod()), ("template", self.template_o.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Module {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Module { name_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, emit_row_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "emitRow")?)?, mods_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "mods")?)?, uses_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "uses")?)?, decls_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "decls")?)?, template_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "template")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `Pattern`:
///
/// ```prism
/// type Pattern = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Pattern {
    pub kind_p: ::std::rc::Rc<PatternKind>,
    pub span_p: Range,
}

impl crate::prelude::Show for Pattern {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Pattern", &[("kind", &self.kind_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for Pattern {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Pattern", vec![("kind", self.kind_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Pattern {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Pattern { kind_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "kind")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `PatternKind`:
///
/// ```prism
/// type PatternKind = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum PatternKind {
    PName(SName),
    PIgnore,
    PLit(Literal),
    PNeg(Literal),
    PUnit,
    PNil,
    PCtor(SName, crate::prelude::Array<Pattern>),
    PRecord(SName, crate::prelude::Array<FieldPat>, bool),
    PSigil(crate::prelude::Text, ::std::rc::Rc<Pattern>),
    PTuple(crate::prelude::Array<Pattern>),
    PArray(crate::prelude::Array<Pattern>),
    PGroup(::std::rc::Rc<Pattern>),
    PFamily(QualName),
}

impl crate::prelude::Show for PatternKind {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            PatternKind::PName(a0) => p.choice("PName", &[a0]),
            PatternKind::PIgnore => p.choice("PIgnore", &[]),
            PatternKind::PLit(a0) => p.choice("PLit", &[a0]),
            PatternKind::PNeg(a0) => p.choice("PNeg", &[a0]),
            PatternKind::PUnit => p.choice("PUnit", &[]),
            PatternKind::PNil => p.choice("PNil", &[]),
            PatternKind::PCtor(a0, a1) => p.choice("PCtor", &[a0, a1]),
            PatternKind::PRecord(a0, a1, a2) => p.choice("PRecord", &[a0, a1, a2]),
            PatternKind::PSigil(a0, a1) => p.choice("PSigil", &[a0, a1]),
            PatternKind::PTuple(a0) => p.choice("PTuple", &[a0]),
            PatternKind::PArray(a0) => p.choice("PArray", &[a0]),
            PatternKind::PGroup(a0) => p.choice("PGroup", &[a0]),
            PatternKind::PFamily(a0) => p.choice("PFamily", &[a0]),
        }
    }
}

impl crate::prelude::ToPod for PatternKind {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            PatternKind::PName(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PName", 0), vec![a0.to_pod()]),
            PatternKind::PIgnore => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PIgnore", 1), vec![]),
            PatternKind::PLit(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PLit", 2), vec![a0.to_pod()]),
            PatternKind::PNeg(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PNeg", 3), vec![a0.to_pod()]),
            PatternKind::PUnit => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PUnit", 4), vec![]),
            PatternKind::PNil => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PNil", 5), vec![]),
            PatternKind::PCtor(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PCtor", 6), vec![a0.to_pod(), a1.to_pod()]),
            PatternKind::PRecord(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PRecord", 7), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            PatternKind::PSigil(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PSigil", 8), vec![a0.to_pod(), a1.to_pod()]),
            PatternKind::PTuple(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PTuple", 9), vec![a0.to_pod()]),
            PatternKind::PArray(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PArray", 10), vec![a0.to_pod()]),
            PatternKind::PGroup(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PGroup", 11), vec![a0.to_pod()]),
            PatternKind::PFamily(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("PFamily", 12), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for PatternKind {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "PName" && a.len() == 1 => ::std::result::Result::Ok(PatternKind::PName(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "PIgnore" && a.len() == 0 => ::std::result::Result::Ok(PatternKind::PIgnore),
            crate::prelude::Pod::Choice(c, a) if &**c == "PLit" && a.len() == 1 => ::std::result::Result::Ok(PatternKind::PLit(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "PNeg" && a.len() == 1 => ::std::result::Result::Ok(PatternKind::PNeg(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "PUnit" && a.len() == 0 => ::std::result::Result::Ok(PatternKind::PUnit),
            crate::prelude::Pod::Choice(c, a) if &**c == "PNil" && a.len() == 0 => ::std::result::Result::Ok(PatternKind::PNil),
            crate::prelude::Pod::Choice(c, a) if &**c == "PCtor" && a.len() == 2 => ::std::result::Result::Ok(PatternKind::PCtor(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "PRecord" && a.len() == 3 => ::std::result::Result::Ok(PatternKind::PRecord(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "PSigil" && a.len() == 2 => ::std::result::Result::Ok(PatternKind::PSigil(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "PTuple" && a.len() == 1 => ::std::result::Result::Ok(PatternKind::PTuple(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "PArray" && a.len() == 1 => ::std::result::Result::Ok(PatternKind::PArray(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "PGroup" && a.len() == 1 => ::std::result::Result::Ok(PatternKind::PGroup(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "PFamily" && a.len() == 1 => ::std::result::Result::Ok(PatternKind::PFamily(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a PatternKind", other),
        }
    }
}

/// `QualName`:
///
/// ```prism
/// type QualName = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct QualName {
    pub path_p: crate::prelude::Array<crate::prelude::Text>,
    pub span_p: Range,
}

impl crate::prelude::Show for QualName {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("QualName", &[("path", &self.path_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for QualName {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("QualName", vec![("path", self.path_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for QualName {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(QualName { path_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "path")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `Range`:
///
/// ```prism
/// type Range = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Range {
    pub start_p: crate::prelude::Nat,
    pub end_p: crate::prelude::Nat,
}

impl crate::prelude::Show for Range {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Range", &[("start", &self.start_p), ("end", &self.end_p)]);
    }
}

impl crate::prelude::ToPod for Range {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Range", vec![("start", self.start_p.to_pod()), ("end", self.end_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Range {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Range { start_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "start")?)?, end_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "end")?)? })
    }
}

/// `RegexLit`:
///
/// ```prism
/// type RegexLit = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct RegexLit {
    pub pattern_p: crate::prelude::Text,
    pub pattern_at_p: crate::prelude::Nat,
    pub replacement_o: ::std::option::Option<crate::prelude::Text>,
    pub replacement_at_p: crate::prelude::Nat,
    pub flags_p: crate::prelude::Text,
    pub flags_at_p: crate::prelude::Nat,
}

impl crate::prelude::Show for RegexLit {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("RegexLit", &[("pattern", &self.pattern_p), ("patternAt", &self.pattern_at_p), ("replacement", &self.replacement_o), ("replacementAt", &self.replacement_at_p), ("flags", &self.flags_p), ("flagsAt", &self.flags_at_p)]);
    }
}

impl crate::prelude::ToPod for RegexLit {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("RegexLit", vec![("pattern", self.pattern_p.to_pod()), ("patternAt", self.pattern_at_p.to_pod()), ("replacement", self.replacement_o.to_pod()), ("replacementAt", self.replacement_at_p.to_pod()), ("flags", self.flags_p.to_pod()), ("flagsAt", self.flags_at_p.to_pod())])
    }
}

impl crate::prelude::FromPod for RegexLit {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(RegexLit { pattern_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "pattern")?)?, pattern_at_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "patternAt")?)?, replacement_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "replacement")?)?, replacement_at_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "replacementAt")?)?, flags_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "flags")?)?, flags_at_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "flagsAt")?)? })
    }
}

/// `Row`:
///
/// ```prism
/// type Row = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Row {
    pub terms_p: crate::prelude::Array<RowTerm>,
    pub span_p: Range,
}

impl crate::prelude::Show for Row {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Row", &[("terms", &self.terms_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for Row {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Row", vec![("terms", self.terms_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Row {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Row { terms_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "terms")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `RowTerm`:
///
/// ```prism
/// type RowTerm = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum RowTerm {
    RFamily(QualName),
    RType(Type),
    RVar(Ident),
}

impl crate::prelude::Show for RowTerm {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            RowTerm::RFamily(a0) => p.choice("RFamily", &[a0]),
            RowTerm::RType(a0) => p.choice("RType", &[a0]),
            RowTerm::RVar(a0) => p.choice("RVar", &[a0]),
        }
    }
}

impl crate::prelude::ToPod for RowTerm {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            RowTerm::RFamily(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("RFamily", 0), vec![a0.to_pod()]),
            RowTerm::RType(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("RType", 1), vec![a0.to_pod()]),
            RowTerm::RVar(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("RVar", 2), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for RowTerm {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "RFamily" && a.len() == 1 => ::std::result::Result::Ok(RowTerm::RFamily(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "RType" && a.len() == 1 => ::std::result::Result::Ok(RowTerm::RType(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "RVar" && a.len() == 1 => ::std::result::Result::Ok(RowTerm::RVar(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a RowTerm", other),
        }
    }
}

/// `SName`:
///
/// ```prism
/// type SName = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct SName {
    pub sigils_p: crate::prelude::Text,
    pub path_p: crate::prelude::Array<crate::prelude::Text>,
    pub span_p: Range,
}

impl crate::prelude::Show for SName {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("SName", &[("sigils", &self.sigils_p), ("path", &self.path_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for SName {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("SName", vec![("sigils", self.sigils_p.to_pod()), ("path", self.path_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for SName {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(SName { sigils_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "sigils")?)?, path_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "path")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `Stmt`:
///
/// ```prism
/// type Stmt = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Stmt {
    pub kind_p: StmtKind,
    pub span_p: Range,
}

impl crate::prelude::Show for Stmt {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Stmt", &[("kind", &self.kind_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for Stmt {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Stmt", vec![("kind", self.kind_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Stmt {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Stmt { kind_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "kind")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `StmtKind`:
///
/// ```prism
/// type StmtKind = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum StmtKind {
    SEmit(Row),
    SBind(Pattern, Expr, ::std::option::Option<Expr>),
    SIgnore(Expr),
    SLet(Pattern, ::std::option::Option<Type>, Expr),
    SSignature(crate::syntax::decls::Signature),
    SFn(crate::syntax::decls::FnClause),
    SWidget(crate::syntax::decls::WidgetDecl),
    SSet(Expr, Expr),
    SAccum(Expr, crate::prelude::Text, Expr),
    SRequire(Expr),
    SForbid(Expr),
    SWhile(Cond, Block),
    SReturn(Expr),
    SExpr(Expr),
}

impl crate::prelude::Show for StmtKind {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            StmtKind::SEmit(a0) => p.choice("SEmit", &[a0]),
            StmtKind::SBind(a0, a1, a2) => p.choice("SBind", &[a0, a1, a2]),
            StmtKind::SIgnore(a0) => p.choice("SIgnore", &[a0]),
            StmtKind::SLet(a0, a1, a2) => p.choice("SLet", &[a0, a1, a2]),
            StmtKind::SSignature(a0) => p.choice("SSignature", &[a0]),
            StmtKind::SFn(a0) => p.choice("SFn", &[a0]),
            StmtKind::SWidget(a0) => p.choice("SWidget", &[a0]),
            StmtKind::SSet(a0, a1) => p.choice("SSet", &[a0, a1]),
            StmtKind::SAccum(a0, a1, a2) => p.choice("SAccum", &[a0, a1, a2]),
            StmtKind::SRequire(a0) => p.choice("SRequire", &[a0]),
            StmtKind::SForbid(a0) => p.choice("SForbid", &[a0]),
            StmtKind::SWhile(a0, a1) => p.choice("SWhile", &[a0, a1]),
            StmtKind::SReturn(a0) => p.choice("SReturn", &[a0]),
            StmtKind::SExpr(a0) => p.choice("SExpr", &[a0]),
        }
    }
}

impl crate::prelude::ToPod for StmtKind {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            StmtKind::SEmit(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SEmit", 0), vec![a0.to_pod()]),
            StmtKind::SBind(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SBind", 1), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            StmtKind::SIgnore(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SIgnore", 2), vec![a0.to_pod()]),
            StmtKind::SLet(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SLet", 3), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            StmtKind::SSignature(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SSignature", 4), vec![a0.to_pod()]),
            StmtKind::SFn(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SFn", 5), vec![a0.to_pod()]),
            StmtKind::SWidget(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SWidget", 6), vec![a0.to_pod()]),
            StmtKind::SSet(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SSet", 7), vec![a0.to_pod(), a1.to_pod()]),
            StmtKind::SAccum(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SAccum", 8), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            StmtKind::SRequire(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SRequire", 9), vec![a0.to_pod()]),
            StmtKind::SForbid(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SForbid", 10), vec![a0.to_pod()]),
            StmtKind::SWhile(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SWhile", 11), vec![a0.to_pod(), a1.to_pod()]),
            StmtKind::SReturn(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SReturn", 12), vec![a0.to_pod()]),
            StmtKind::SExpr(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SExpr", 13), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for StmtKind {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "SEmit" && a.len() == 1 => ::std::result::Result::Ok(StmtKind::SEmit(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SBind" && a.len() == 3 => ::std::result::Result::Ok(StmtKind::SBind(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SIgnore" && a.len() == 1 => ::std::result::Result::Ok(StmtKind::SIgnore(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SLet" && a.len() == 3 => ::std::result::Result::Ok(StmtKind::SLet(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SSignature" && a.len() == 1 => ::std::result::Result::Ok(StmtKind::SSignature(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SFn" && a.len() == 1 => ::std::result::Result::Ok(StmtKind::SFn(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SWidget" && a.len() == 1 => ::std::result::Result::Ok(StmtKind::SWidget(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SSet" && a.len() == 2 => ::std::result::Result::Ok(StmtKind::SSet(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SAccum" && a.len() == 3 => ::std::result::Result::Ok(StmtKind::SAccum(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SRequire" && a.len() == 1 => ::std::result::Result::Ok(StmtKind::SRequire(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SForbid" && a.len() == 1 => ::std::result::Result::Ok(StmtKind::SForbid(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SWhile" && a.len() == 2 => ::std::result::Result::Ok(StmtKind::SWhile(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SReturn" && a.len() == 1 => ::std::result::Result::Ok(StmtKind::SReturn(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SExpr" && a.len() == 1 => ::std::result::Result::Ok(StmtKind::SExpr(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a StmtKind", other),
        }
    }
}

/// `Template`:
///
/// ```prism
/// type Template = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Template {
    pub keyword_p: crate::prelude::Text,
    pub lang_p: crate::prelude::Text,
    pub delims_p: crate::prelude::Text,
    pub parts_p: crate::prelude::Array<TemplatePart>,
    pub span_p: Range,
}

impl crate::prelude::Show for Template {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Template", &[("keyword", &self.keyword_p), ("lang", &self.lang_p), ("delims", &self.delims_p), ("parts", &self.parts_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for Template {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Template", vec![("keyword", self.keyword_p.to_pod()), ("lang", self.lang_p.to_pod()), ("delims", self.delims_p.to_pod()), ("parts", self.parts_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Template {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Template { keyword_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "keyword")?)?, lang_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "lang")?)?, delims_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "delims")?)?, parts_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "parts")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `TemplatePart`:
///
/// ```prism
/// type TemplatePart = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum TemplatePart {
    TpText(crate::prelude::Text),
    TpPlaceholder(Expr, ::std::option::Option<crate::prelude::Nat>),
    TpBlock(Block),
    TpCall(SName, crate::prelude::Array<Arg>, ::std::option::Option<crate::prelude::Array<TemplatePart>>, Range),
}

impl crate::prelude::Show for TemplatePart {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            TemplatePart::TpText(a0) => p.choice("TpText", &[a0]),
            TemplatePart::TpPlaceholder(a0, a1) => p.choice("TpPlaceholder", &[a0, a1]),
            TemplatePart::TpBlock(a0) => p.choice("TpBlock", &[a0]),
            TemplatePart::TpCall(a0, a1, a2, a3) => p.choice("TpCall", &[a0, a1, a2, a3]),
        }
    }
}

impl crate::prelude::ToPod for TemplatePart {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            TemplatePart::TpText(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TpText", 0), vec![a0.to_pod()]),
            TemplatePart::TpPlaceholder(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TpPlaceholder", 1), vec![a0.to_pod(), a1.to_pod()]),
            TemplatePart::TpBlock(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TpBlock", 2), vec![a0.to_pod()]),
            TemplatePart::TpCall(a0, a1, a2, a3) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TpCall", 3), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for TemplatePart {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "TpText" && a.len() == 1 => ::std::result::Result::Ok(TemplatePart::TpText(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TpPlaceholder" && a.len() == 2 => ::std::result::Result::Ok(TemplatePart::TpPlaceholder(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TpBlock" && a.len() == 1 => ::std::result::Result::Ok(TemplatePart::TpBlock(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TpCall" && a.len() == 4 => ::std::result::Result::Ok(TemplatePart::TpCall(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?, crate::prelude::FromPod::from_pod(&a[3])?)),
            other => ::prism_rtl::pod::mismatch("a TemplatePart", other),
        }
    }
}

/// `TextSeg`:
///
/// ```prism
/// type TextSeg = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum TextSeg {
    SegPlain(crate::prelude::Text),
    SegPlaceholder(Expr),
}

impl crate::prelude::Show for TextSeg {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            TextSeg::SegPlain(a0) => p.choice("SegPlain", &[a0]),
            TextSeg::SegPlaceholder(a0) => p.choice("SegPlaceholder", &[a0]),
        }
    }
}

impl crate::prelude::ToPod for TextSeg {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            TextSeg::SegPlain(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SegPlain", 0), vec![a0.to_pod()]),
            TextSeg::SegPlaceholder(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("SegPlaceholder", 1), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for TextSeg {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "SegPlain" && a.len() == 1 => ::std::result::Result::Ok(TextSeg::SegPlain(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "SegPlaceholder" && a.len() == 1 => ::std::result::Result::Ok(TextSeg::SegPlaceholder(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a TextSeg", other),
        }
    }
}

/// `TraitRef`:
///
/// ```prism
/// type TraitRef = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct TraitRef {
    pub path_p: crate::prelude::Array<crate::prelude::Text>,
    pub span_p: Range,
}

impl crate::prelude::Show for TraitRef {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("TraitRef", &[("path", &self.path_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for TraitRef {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("TraitRef", vec![("path", self.path_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for TraitRef {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(TraitRef { path_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "path")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `Type`:
///
/// ```prism
/// type Type = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Type {
    pub kind_p: ::std::rc::Rc<TypeKind>,
    pub span_p: Range,
}

impl crate::prelude::Show for Type {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Type", &[("kind", &self.kind_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for Type {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Type", vec![("kind", self.kind_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Type {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Type { kind_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "kind")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}

/// `TypeKind`:
///
/// ```prism
/// type TypeKind = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum TypeKind {
    TName(SName, crate::prelude::Array<Type>),
    TSigiled(crate::prelude::Text, ::std::rc::Rc<Type>),
    TArray(::std::rc::Rc<Type>, bool),
    TTuple(crate::prelude::Array<Type>),
    TGroup(::std::rc::Rc<Type>),
    TMap(::std::rc::Rc<Type>, ::std::rc::Rc<Type>),
    TFn(Color, crate::prelude::Array<Type>, ::std::rc::Rc<Type>),
    TEmit(::std::rc::Rc<Type>, ::std::rc::Rc<Type>),
    TRowUnion(crate::prelude::Array<Type>),
    TFamily(QualName),
    TAny(TraitRef),
    TUnit(crate::prelude::Text),
    THole(SName),
    TAbsent,
    TNonEmpty(::std::rc::Rc<Type>),
}

impl crate::prelude::Show for TypeKind {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            TypeKind::TName(a0, a1) => p.choice("TName", &[a0, a1]),
            TypeKind::TSigiled(a0, a1) => p.choice("TSigiled", &[a0, a1]),
            TypeKind::TArray(a0, a1) => p.choice("TArray", &[a0, a1]),
            TypeKind::TTuple(a0) => p.choice("TTuple", &[a0]),
            TypeKind::TGroup(a0) => p.choice("TGroup", &[a0]),
            TypeKind::TMap(a0, a1) => p.choice("TMap", &[a0, a1]),
            TypeKind::TFn(a0, a1, a2) => p.choice("TFn", &[a0, a1, a2]),
            TypeKind::TEmit(a0, a1) => p.choice("TEmit", &[a0, a1]),
            TypeKind::TRowUnion(a0) => p.choice("TRowUnion", &[a0]),
            TypeKind::TFamily(a0) => p.choice("TFamily", &[a0]),
            TypeKind::TAny(a0) => p.choice("TAny", &[a0]),
            TypeKind::TUnit(a0) => p.choice("TUnit", &[a0]),
            TypeKind::THole(a0) => p.choice("THole", &[a0]),
            TypeKind::TAbsent => p.choice("TAbsent", &[]),
            TypeKind::TNonEmpty(a0) => p.choice("TNonEmpty", &[a0]),
        }
    }
}

impl crate::prelude::ToPod for TypeKind {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            TypeKind::TName(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TName", 0), vec![a0.to_pod(), a1.to_pod()]),
            TypeKind::TSigiled(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TSigiled", 1), vec![a0.to_pod(), a1.to_pod()]),
            TypeKind::TArray(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TArray", 2), vec![a0.to_pod(), a1.to_pod()]),
            TypeKind::TTuple(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TTuple", 3), vec![a0.to_pod()]),
            TypeKind::TGroup(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TGroup", 4), vec![a0.to_pod()]),
            TypeKind::TMap(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TMap", 5), vec![a0.to_pod(), a1.to_pod()]),
            TypeKind::TFn(a0, a1, a2) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TFn", 6), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            TypeKind::TEmit(a0, a1) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TEmit", 7), vec![a0.to_pod(), a1.to_pod()]),
            TypeKind::TRowUnion(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TRowUnion", 8), vec![a0.to_pod()]),
            TypeKind::TFamily(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TFamily", 9), vec![a0.to_pod()]),
            TypeKind::TAny(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TAny", 10), vec![a0.to_pod()]),
            TypeKind::TUnit(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TUnit", 11), vec![a0.to_pod()]),
            TypeKind::THole(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("THole", 12), vec![a0.to_pod()]),
            TypeKind::TAbsent => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TAbsent", 13), vec![]),
            TypeKind::TNonEmpty(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("TNonEmpty", 14), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for TypeKind {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "TName" && a.len() == 2 => ::std::result::Result::Ok(TypeKind::TName(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TSigiled" && a.len() == 2 => ::std::result::Result::Ok(TypeKind::TSigiled(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TArray" && a.len() == 2 => ::std::result::Result::Ok(TypeKind::TArray(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TTuple" && a.len() == 1 => ::std::result::Result::Ok(TypeKind::TTuple(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TGroup" && a.len() == 1 => ::std::result::Result::Ok(TypeKind::TGroup(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TMap" && a.len() == 2 => ::std::result::Result::Ok(TypeKind::TMap(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TFn" && a.len() == 3 => ::std::result::Result::Ok(TypeKind::TFn(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?, crate::prelude::FromPod::from_pod(&a[2])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TEmit" && a.len() == 2 => ::std::result::Result::Ok(TypeKind::TEmit(crate::prelude::FromPod::from_pod(&a[0])?, crate::prelude::FromPod::from_pod(&a[1])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TRowUnion" && a.len() == 1 => ::std::result::Result::Ok(TypeKind::TRowUnion(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TFamily" && a.len() == 1 => ::std::result::Result::Ok(TypeKind::TFamily(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TAny" && a.len() == 1 => ::std::result::Result::Ok(TypeKind::TAny(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TUnit" && a.len() == 1 => ::std::result::Result::Ok(TypeKind::TUnit(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "THole" && a.len() == 1 => ::std::result::Result::Ok(TypeKind::THole(crate::prelude::FromPod::from_pod(&a[0])?)),
            crate::prelude::Pod::Choice(c, a) if &**c == "TAbsent" && a.len() == 0 => ::std::result::Result::Ok(TypeKind::TAbsent),
            crate::prelude::Pod::Choice(c, a) if &**c == "TNonEmpty" && a.len() == 1 => ::std::result::Result::Ok(TypeKind::TNonEmpty(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a TypeKind", other),
        }
    }
}

/// `Use`:
///
/// ```prism
/// type Use = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Use {
    pub target_p: QualName,
    pub star_p: bool,
    pub span_p: Range,
}

impl crate::prelude::Show for Use {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Use", &[("target", &self.target_p), ("star", &self.star_p), ("span", &self.span_p)]);
    }
}

impl crate::prelude::ToPod for Use {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Use", vec![("target", self.target_p.to_pod()), ("star", self.star_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Use {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Use { target_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "target")?)?, star_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "star")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)? })
    }
}
