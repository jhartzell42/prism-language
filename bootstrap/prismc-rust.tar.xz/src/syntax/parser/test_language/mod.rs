//! The module `Syntax.Parser.TestLanguage`, from `target/bootstrap/src/prismc/syntax/parser/test_language.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// let deliveryWords
/// ```
pub fn delivery_words() -> Array<Text> {
    Array::from(vec![Text::lit("send"), Text::lit("click"), Text::lit("answer")])
}

/// ```prism
/// IsDeliveryWord: fn Text -> Bool
/// ```
pub fn is_delivery_word(w_p0: &Text) -> bool {
    fold(&delivery_words(), &false, &(|seen_p1: &bool, d_p2: &Text| *seen_p1 || (d_p2 == w_p0)))
}

/// ```prism
/// StepWord: fn Ps -> Text
/// ```
pub fn step_word(p_p0: &crate::syntax::parser::Ps) -> Text {
    match crate::syntax::parser::kind(p_p0) {
        crate::syntax::lexer::TokKind::KName(n_p1) if (((&n_p1.sigils == &Text::lit("")) && (&len(&n_p1.path_) == &Nat::from(1u32))) && (&n_p1.case == &crate::syntax::lexer::NameCase::CaseLower)) => or(&index(&n_p1.path_, &Nat::from(0u32)), &Text::lit("")),
        _ => Text::lit(""),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// AtWord: fn Ps, Text -> Bool
/// ```
pub fn at_word(p_p0: &crate::syntax::parser::Ps, w_p1: &Text) -> bool {
    &step_word(p_p0) == w_p1
}

/// ```prism
/// ParseCheckDecl: unbounded fn Ps -> ((CheckDecl, Ps))
/// ```
pub fn parse_check_decl(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::CheckDecl, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here(p0_p0);
    let (name_p3, p1_p4) = crate::syntax::parser::parse_ident(&crate::syntax::parser::adv(p0_p0));
    let p2_p2 = crate::syntax::parser::expect_colon(&p1_p4);
    if crate::syntax::parser::at_open_l(&p2_p2) {
        {
            let (lines_p5, q_p6) = crate::syntax::parser::layout_items(&crate::syntax::parser::adv(&p2_p2), &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_check_line(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::CheckLine, crate::syntax::parser::Ps)>>>));
            (crate::syntax::decls::CheckDecl { name: name_p3.clone(), lines: lines_p5.clone(), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&q_p6)) }, q_p6.clone())
        }
    } else {
        (crate::syntax::decls::CheckDecl { name: name_p3.clone(), lines: Array::new(), span: start_p1.clone() }, crate::syntax::parser::error_here(&p2_p2, &Text::lit("a `check` block\'s lines stand in an indented block")))
    }
}

/// The step machine of `ParseCheckDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseCheckDecl: unbounded fn Ps -> ((CheckDecl, Ps))
/// ```
pub struct ParseCheckDecl {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::CheckDecl, crate::syntax::parser::Ps)> for ParseCheckDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::CheckDecl, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let start_p1 = crate::syntax::parser::here(p0_p0);
        let (name_p3, p1_p4) = crate::syntax::parser::parse_ident(&crate::syntax::parser::adv(p0_p0));
        let p2_p2 = crate::syntax::parser::expect_colon(&p1_p4);
        if crate::syntax::parser::at_open_l(&p2_p2) {
            call_then(crate::syntax::parser::start_layout_items(crate::syntax::parser::adv(&p2_p2), Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_check_line(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::CheckLine, crate::syntax::parser::Ps)>>>), move |layout_items_1679: (Array<crate::syntax::decls::CheckLine>, crate::syntax::parser::Ps)| {
                let (lines_p5, q_p6) = layout_items_1679;
                prism_rtl::Turn::Finished((crate::syntax::decls::CheckDecl { name: name_p3.clone(), lines: lines_p5.clone(), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&q_p6)) }, q_p6.clone()))
            })
        } else {
            prism_rtl::Turn::Finished((crate::syntax::decls::CheckDecl { name: name_p3.clone(), lines: Array::new(), span: start_p1.clone() }, crate::syntax::parser::error_here(&p2_p2, &Text::lit("a `check` block\'s lines stand in an indented block"))))
        }
    }
}

/// `Start ParseCheckDecl, x`: what the function value is when passed to `@Run`.
pub fn start_parse_check_decl(p0_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::CheckDecl, crate::syntax::parser::Ps)>> {
    Rc::new(ParseCheckDecl { p0_p0 })
}

/// ```prism
/// ParseCheckLine: unbounded fn Ps -> ((CheckLine, Ps))
/// ```
pub fn parse_check_line(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::CheckLine, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here(p_p0);
    let (expr_p2, p1_p3) = crate::syntax::parser::expr::parse_rhs_expr(p_p0);
    let (pattern_o4, q_p5) = if crate::syntax::parser::at_op(&p1_p3, &Text::lit("=>")) {
        optional_pattern_top(&crate::syntax::parser::adv(&p1_p3))
    } else {
        (None, p1_p3.clone())
    };
    (crate::syntax::decls::CheckLine { expr: expr_p2.clone(), pattern: pattern_o4.clone(), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&q_p5)) }, q_p5.clone())
}

/// The step machine of `ParseCheckLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseCheckLine: unbounded fn Ps -> ((CheckLine, Ps))
/// ```
pub struct ParseCheckLine {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::CheckLine, crate::syntax::parser::Ps)> for ParseCheckLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::CheckLine, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here(p_p0);
        let p_p0 = p_p0.clone();
        call_then(crate::syntax::parser::expr::start_parse_rhs_expr(p_p0.clone()), move |parse_rhs_expr_2042: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
            let (expr_p2, p1_p3) = parse_rhs_expr_2042;
            let (pattern_o4, q_p5) = if crate::syntax::parser::at_op(&p1_p3, &Text::lit("=>")) {
                optional_pattern_top(&crate::syntax::parser::adv(&p1_p3))
            } else {
                (None, p1_p3.clone())
            };
            prism_rtl::Turn::Finished((crate::syntax::decls::CheckLine { expr: expr_p2.clone(), pattern: pattern_o4.clone(), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&q_p5)) }, q_p5.clone()))
        })
    }
}

/// `Start ParseCheckLine, x`: what the function value is when passed to `@Run`.
pub fn start_parse_check_line(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::CheckLine, crate::syntax::parser::Ps)>> {
    Rc::new(ParseCheckLine { p_p0 })
}

/// ```prism
/// OptionalPatternTop: unbounded fn Ps -> ((?Pattern, Ps))
/// ```
pub fn optional_pattern_top(p_p0: &crate::syntax::parser::Ps) -> (Option<crate::syntax::Pattern_>, crate::syntax::parser::Ps) {
    let (pat_p1, q_p2) = crate::syntax::parser::types::parse_pattern(p_p0, &true);
    (Some(pat_p1.clone()), q_p2.clone())
}

/// The step machine of `OptionalPatternTop`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptionalPatternTop: unbounded fn Ps -> ((?Pattern, Ps))
/// ```
pub struct OptionalPatternTop {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(Option<crate::syntax::Pattern_>, crate::syntax::parser::Ps)> for OptionalPatternTop {
    fn cycle(&self) -> prism_rtl::Turn<(Option<crate::syntax::Pattern_>, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let p_p0 = p_p0.clone();
        call_then(crate::syntax::parser::types::start_parse_pattern(p_p0.clone(), true), move |parse_pattern_2327: (crate::syntax::Pattern_, crate::syntax::parser::Ps)| {
            let (pat_p1, q_p2) = parse_pattern_2327;
            prism_rtl::Turn::Finished((Some(pat_p1.clone()), q_p2.clone()))
        })
    }
}

/// `Start OptionalPatternTop, x`: what the function value is when passed to `@Run`.
pub fn start_optional_pattern_top(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(Option<crate::syntax::Pattern_>, crate::syntax::parser::Ps)>> {
    Rc::new(OptionalPatternTop { p_p0 })
}

/// ```prism
/// ParseTestDecl: unbounded fn Ps -> ((TestDecl, Ps))
/// ```
pub fn parse_test_decl(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::TestDecl, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here(p0_p0);
    let (name_p3, p1_p4) = crate::syntax::parser::parse_ident(&crate::syntax::parser::adv(p0_p0));
    let fallback_p2 = crate::syntax::decls::TestDecl { name: name_p3.clone(), blueprint: crate::syntax::parser::decls::no_expr(), seed: None, steps: Array::new(), span: start_p1.clone() };
    if !crate::syntax::parser::at_comma(&p1_p4) {
        (fallback_p2.clone(), crate::syntax::parser::error_here(&p1_p4, &Text::lit("a test names its blueprint: `test name, @blueprint:`")))
    } else {
        {
            let (blueprint_p6, p2_p7) = crate::syntax::parser::expr::parse_arg_expr(&crate::syntax::parser::adv(&p1_p4));
            let (seed_o8, p3_p9) = if crate::syntax::parser::at_comma(&p2_p7) {
                parse_seed(&crate::syntax::parser::adv(&p2_p7))
            } else {
                (None, p2_p7.clone())
            };
            let p4_p5 = crate::syntax::parser::expect_colon(&p3_p9);
            if crate::syntax::parser::at_open_l(&p4_p5) {
                {
                    let saved_pa = p4_p5.step_mode;
                    let (steps_pd, p5_pe) = crate::syntax::parser::layout_items(&crate::syntax::parser::adv(&p4_p5), &{
                        let saved_pa = saved_pa;
                        Rc::new(move |p0: crate::syntax::parser::Ps| {
                            let saved_pa = saved_pa;
                            entered(once_job(move || {
                                let s_pc = p0;
                                prism_rtl::Turn::More(Rc::new(StepIn { p_p0: s_pc.clone(), saved_p1: saved_pa }))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TestStep, crate::syntax::parser::Ps)>>>
                    });
                    let q_pb = crate::syntax::parser::with_step_mode(&p5_pe, &saved_pa);
                    (crate::syntax::decls::TestDecl { name: name_p3.clone(), blueprint: blueprint_p6.clone(), seed: seed_o8.clone(), steps: steps_pd.clone(), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&q_pb)) }, q_pb.clone())
                }
            } else {
                (fallback_p2.clone(), crate::syntax::parser::error_here(&p4_p5, &Text::lit("a test\'s steps stand in an indented block")))
            }
        }
    }
}

/// The step machine of `ParseTestDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTestDecl: unbounded fn Ps -> ((TestDecl, Ps))
/// ```
pub struct ParseTestDecl {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::TestDecl, crate::syntax::parser::Ps)> for ParseTestDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::TestDecl, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let start_p1 = crate::syntax::parser::here(p0_p0);
        let (name_p3, p1_p4) = crate::syntax::parser::parse_ident(&crate::syntax::parser::adv(p0_p0));
        let fallback_p2 = crate::syntax::decls::TestDecl { name: name_p3.clone(), blueprint: crate::syntax::parser::decls::no_expr(), seed: None, steps: Array::new(), span: start_p1.clone() };
        if !crate::syntax::parser::at_comma(&p1_p4) {
            prism_rtl::Turn::Finished((fallback_p2.clone(), crate::syntax::parser::error_here(&p1_p4, &Text::lit("a test names its blueprint: `test name, @blueprint:`"))))
        } else {
            call_then(crate::syntax::parser::expr::start_parse_arg_expr(crate::syntax::parser::adv(&p1_p4)), move |parse_arg_expr_2820: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                let (blueprint_p6, p2_p7) = parse_arg_expr_2820;
                let (seed_o8, p3_p9) = if crate::syntax::parser::at_comma(&p2_p7) {
                    parse_seed(&crate::syntax::parser::adv(&p2_p7))
                } else {
                    (None, p2_p7.clone())
                };
                let p4_p5 = crate::syntax::parser::expect_colon(&p3_p9);
                if crate::syntax::parser::at_open_l(&p4_p5) {
                    {
                        let saved_pa = p4_p5.step_mode;
                        call_then(crate::syntax::parser::start_layout_items(crate::syntax::parser::adv(&p4_p5), {
                            let saved_pa = saved_pa;
                            Rc::new(move |p0: crate::syntax::parser::Ps| {
                                let saved_pa = saved_pa;
                                entered(once_job(move || {
                                    let s_pc = p0;
                                    prism_rtl::Turn::More(Rc::new(StepIn { p_p0: s_pc.clone(), saved_p1: saved_pa }))
                                }))
                            }) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TestStep, crate::syntax::parser::Ps)>>>
                        }), move |layout_items_3045: (Array<crate::syntax::decls::TestStep>, crate::syntax::parser::Ps)| {
                            let (steps_pd, p5_pe) = layout_items_3045;
                            let q_pb = crate::syntax::parser::with_step_mode(&p5_pe, &saved_pa);
                            prism_rtl::Turn::Finished((crate::syntax::decls::TestDecl { name: name_p3.clone(), blueprint: blueprint_p6.clone(), seed: seed_o8.clone(), steps: steps_pd.clone(), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&q_pb)) }, q_pb.clone()))
                        })
                    }
                } else {
                    prism_rtl::Turn::Finished((fallback_p2.clone(), crate::syntax::parser::error_here(&p4_p5, &Text::lit("a test\'s steps stand in an indented block"))))
                }
            })
        }
    }
}

/// `Start ParseTestDecl, x`: what the function value is when passed to `@Run`.
pub fn start_parse_test_decl(p0_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TestDecl, crate::syntax::parser::Ps)>> {
    Rc::new(ParseTestDecl { p0_p0 })
}

/// ```prism
/// ParseSeed: fn Ps -> ((?Nat, Ps))
/// ```
pub fn parse_seed(p_p0: &crate::syntax::parser::Ps) -> (Option<Nat>, crate::syntax::parser::Ps) {
    if !at_word(p_p0, &Text::lit("seed")) {
        (None, crate::syntax::parser::error_here(p_p0, &Text::lit("after the blueprint, a test takes only `seed n`")))
    } else {
        {
            let p1_p1 = crate::syntax::parser::adv(p_p0);
            match crate::syntax::parser::kind(&p1_p1) {
                crate::syntax::lexer::TokKind::KInt(m3527_0_0, text_p2) if (&m3527_0_0 == &Text::lit("")) => (Some(parse_nat_text(&text_p2)), crate::syntax::parser::adv(&p1_p1)),
                _ => (None, crate::syntax::parser::error_here(&p1_p1, &Text::lit("`seed` takes a number"))),
                _ => unreachable!("no arm matched"),
            }
        }
    }
}

/// ```prism
/// StepIn: unbounded fn Ps, Bool -> ((TestStep, Ps))
/// ```
pub fn step_in(p_p0: &crate::syntax::parser::Ps, saved_p1: &bool) -> (crate::syntax::decls::TestStep, crate::syntax::parser::Ps) {
    let (s_p2, q_p3) = parse_step(&crate::syntax::parser::with_step_mode(p_p0, &true));
    (s_p2.clone(), crate::syntax::parser::with_step_mode(&q_p3, saved_p1))
}

/// The step machine of `StepIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StepIn: unbounded fn Ps, Bool -> ((TestStep, Ps))
/// ```
pub struct StepIn {
    pub p_p0: crate::syntax::parser::Ps,
    pub saved_p1: bool,
}

impl prism_rtl::Job<(crate::syntax::decls::TestStep, crate::syntax::parser::Ps)> for StepIn {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::TestStep, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let saved_p1 = &self.saved_p1;
        let (s_p2, q_p3) = parse_step(&crate::syntax::parser::with_step_mode(p_p0, &true));
        prism_rtl::Turn::Finished((s_p2.clone(), crate::syntax::parser::with_step_mode(&q_p3, saved_p1)))
    }
}

/// `Start StepIn, x`: what the function value is when passed to `@Run`.
pub fn start_step_in(p_p0: crate::syntax::parser::Ps, saved_p1: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TestStep, crate::syntax::parser::Ps)>> {
    Rc::new(StepIn { p_p0, saved_p1 })
}

/// ```prism
/// ParseStep: unbounded fn Ps -> ((TestStep, Ps))
/// ```
pub fn parse_step(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::TestStep, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here(p0_p0);
    let (withs_p2, p1_p3) = with_entries(p0_p0);
    let (action_p4, p2_p5) = step_action_of(&p1_p3, &withs_p2);
    if p2_p5.bad {
        (crate::syntax::decls::TestStep { withs: withs_p2.clone(), action: action_p4.clone(), checks: Array::new(), span: start_p1.clone() }, p2_p5.clone())
    } else {
        if crate::syntax::parser::at_open_l(&p2_p5) {
            {
                let (checks_p6, q_p7) = crate::syntax::parser::layout_items(&crate::syntax::parser::adv(&p2_p5), &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_test_check(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TestCheck, crate::syntax::parser::Ps)>>>));
                (crate::syntax::decls::TestStep { withs: withs_p2.clone(), action: action_p4.clone(), checks: checks_p6.clone(), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&q_p7)) }, q_p7.clone())
            }
        } else {
            if crate::syntax::parser::at_comma(&p2_p5) {
                (crate::syntax::decls::TestStep { withs: withs_p2.clone(), action: action_p4.clone(), checks: Array::new(), span: start_p1.clone() }, crate::syntax::parser::error_at(&p2_p5, &crate::syntax::parser::here(&p2_p5), &Text::lit("a comma in a step begins a delivery; a value with commas in it is written in parentheses")))
            } else {
                (crate::syntax::decls::TestStep { withs: withs_p2.clone(), action: action_p4.clone(), checks: Array::new(), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p2_p5)) }, p2_p5.clone())
            }
        }
    }
}

/// ```prism
/// WithEntries: unbounded fn Ps -> (([Entry], Ps))
/// ```
pub fn with_entries(p0_p0: &crate::syntax::parser::Ps) -> (Array<crate::syntax::decls::Entry>, crate::syntax::parser::Ps) {
    let mut this: (Array<crate::syntax::decls::Entry>, crate::syntax::parser::Ps) = (Array::new(), p0_p0.clone());
    let mut withs_p1: Array<crate::syntax::decls::Entry> = Array::new();
    let mut p_p2: crate::syntax::parser::Ps = p0_p0.clone();
    let mut going_p3: bool = at_word(p0_p0, &Text::lit("with"));
    while going_p3 && !p_p2.bad {
        let (e_p4, q_p5) = parse_entry(&crate::syntax::parser::adv(&p_p2));
        withs_p1 = push(&withs_p1, &e_p4);
        if crate::syntax::parser::at_comma(&q_p5) {
            p_p2 = crate::syntax::parser::adv(&q_p5);
            going_p3 = at_word(&p_p2, &Text::lit("with"));
        } else {
            p_p2 = q_p5.clone();
            going_p3 = false;
        }
    }
    this = (withs_p1.clone(), p_p2.clone());
    this
}

/// ```prism
/// StepActionOf: unbounded fn Ps, [Entry] -> ((StepAction, Ps))
/// ```
pub fn step_action_of(p_p0: &crate::syntax::parser::Ps, withs_p1: &Array<crate::syntax::decls::Entry>) -> (crate::syntax::decls::StepAction, crate::syntax::parser::Ps) {
    let w_p2 = step_word(p_p0);
    match &w_p2 {
        m5346_0 if (m5346_0 == &Text::lit("build")) => (crate::syntax::decls::StepAction::SaBuild, crate::syntax::parser::adv(p_p0)),
        m5346_1 if (m5346_1 == &Text::lit("tick")) => (crate::syntax::decls::StepAction::SaTick, crate::syntax::parser::adv(p_p0)),
        m5346_2 if (m5346_2 == &Text::lit("compute")) => {
            let p1_p3 = crate::syntax::parser::adv(p_p0);
            if at_word(&p1_p3, &Text::lit("until")) {
                {
                    let p2_p4 = crate::syntax::parser::adv(&p1_p3);
                    if at_word(&p2_p4, &Text::lit("idle")) {
                        (crate::syntax::decls::StepAction::SaCompute(true), crate::syntax::parser::adv(&p2_p4))
                    } else {
                        (crate::syntax::decls::StepAction::SaCompute(true), crate::syntax::parser::error_here(&p2_p4, &Text::lit("`compute until` is followed by `idle`")))
                    }
                }
            } else {
                (crate::syntax::decls::StepAction::SaCompute(false), p1_p3.clone())
            }
        },
        m5346_3 if (m5346_3 == &Text::lit("push")) => {
            let (e_p5, q_p6) = parse_entry(&crate::syntax::parser::adv(p_p0));
            (crate::syntax::decls::StepAction::SaPush(e_p5.clone()), q_p6.clone())
        },
        _ if is_delivery_word(&w_p2) => deliveries(p_p0),
        _ if ((&len(withs_p1) > &Nat::from(0u32)) && (crate::syntax::parser::at_open_l(p_p0) || crate::syntax::parser::at_stmt_boundary(p_p0))) => (crate::syntax::decls::StepAction::SaWithOnly, p_p0.clone()),
        _ => (crate::syntax::decls::StepAction::SaBuild, crate::syntax::parser::error_here(p_p0, &Text::lit("expected a step: `build`, `tick`, `compute`, `send`, `click`, `answer`, `with` or `push`"))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Deliveries: unbounded fn Ps -> ((StepAction, Ps))
/// ```
pub fn deliveries(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::StepAction, crate::syntax::parser::Ps) {
    let mut this: (crate::syntax::decls::StepAction, crate::syntax::parser::Ps) = (crate::syntax::decls::StepAction::SaBuild, p0_p0.clone());
    let (first_p1, p1_p2) = parse_delivery(p0_p0);
    let mut ds_p3: Array<crate::syntax::decls::Delivery> = Array::from(vec![first_p1.clone()]);
    let mut p_p4: crate::syntax::parser::Ps = p1_p2.clone();
    while crate::syntax::parser::at_comma(&p_p4) && !p_p4.bad {
        if is_delivery_name(&crate::syntax::parser::kind_at(&p_p4, &Nat::from(1u32))) {
            let (d_p5, q_p6) = parse_delivery(&crate::syntax::parser::adv(&p_p4));
            ds_p3 = push(&ds_p3, &d_p5);
            p_p4 = q_p6.clone();
        } else {
            p_p4 = crate::syntax::parser::error_at(&p_p4, &crate::syntax::parser::here(&p_p4), &Text::lit("a comma in a step begins a delivery (`click p, click q`); a value with commas in it is written in parentheses: `send p, (Min a, b)`"));
        }
    }
    this = (crate::syntax::decls::StepAction::SaDeliver(ds_p3.clone()), p_p4.clone());
    this
}

/// ```prism
/// IsDeliveryName: fn TokKind -> Bool
/// ```
pub fn is_delivery_name(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KName(n_p0) => (&len(&n_p0.path_) == &Nat::from(1u32)) && is_delivery_word(&or(&index(&n_p0.path_, &Nat::from(0u32)), &Text::lit(""))),
        _ => false,
    }
}

/// ```prism
/// ParseEntry: unbounded fn Ps -> ((Entry, Ps))
/// ```
pub fn parse_entry(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::Entry, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here(p_p0);
    let (element_p2, p1_p3) = crate::syntax::parser::expr::parse_arg_expr(p_p0);
    let (value_p4, q_p5) = crate::syntax::parser::expr::parse_arg_expr(&crate::syntax::parser::expect_op(&p1_p3, &Text::lit("=")));
    (crate::syntax::decls::Entry { element: element_p2.clone(), value: value_p4.clone(), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&q_p5)) }, q_p5.clone())
}

/// ```prism
/// ParseDelivery: unbounded fn Ps -> ((Delivery, Ps))
/// ```
pub fn parse_delivery(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::Delivery, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here(p_p0);
    let word_p2 = step_word(p_p0);
    let (target_p3, p1_p4) = parse_target(&crate::syntax::parser::adv(p_p0));
    let (kind_p5, q_p6) = if &word_p2 == &Text::lit("send") {
        send_value(&p1_p4)
    } else {
        if &word_p2 == &Text::lit("click") {
            (crate::syntax::decls::DeliveryKind::DkClick, p1_p4.clone())
        } else {
            (crate::syntax::decls::DeliveryKind::DkAnswer, p1_p4.clone())
        }
    };
    (crate::syntax::decls::Delivery { kind: kind_p5.clone(), target: target_p3.clone(), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&q_p6)) }, q_p6.clone())
}

/// ```prism
/// SendValue: unbounded fn Ps -> ((DeliveryKind, Ps))
/// ```
pub fn send_value(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::DeliveryKind, crate::syntax::parser::Ps) {
    if crate::syntax::parser::at_comma(p_p0) {
        {
            let (v_p1, q_p2) = crate::syntax::parser::expr::parse_arg_expr(&crate::syntax::parser::adv(p_p0));
            (crate::syntax::decls::DeliveryKind::DkSend(v_p1.clone()), q_p2.clone())
        }
    } else {
        (crate::syntax::decls::DeliveryKind::DkClick, crate::syntax::parser::error_here(p_p0, &Text::lit("`send` takes a target and a value: `send p, v`")))
    }
}

/// ```prism
/// ParseTarget: unbounded fn Ps -> ((Target, Ps))
/// ```
pub fn parse_target(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::Target, crate::syntax::parser::Ps) {
    let element_p1 = at_word(p_p0, &Text::lit("element")) && is_path_kind(&crate::syntax::parser::kind_at(p_p0, &Nat::from(1u32)));
    if at_word(p_p0, &Text::lit("at")) || element_p1 {
        {
            let p1_p2 = crate::syntax::parser::adv(p_p0);
            match crate::syntax::parser::kind(&p1_p2) {
                crate::syntax::lexer::TokKind::KPath(segs_p3) => {
                    let span_p4 = crate::syntax::parser::here(&p1_p2);
                    let (segments_p9, q_pa) = run_to_end(fold_job(segs_p3.clone(), (Array::new(), crate::syntax::parser::adv(&p1_p2)), {
                        let span_p4 = span_p4.clone();
                        Rc::new(move |(p0, p1): ((Array<crate::syntax::decls::PathSeg>, crate::syntax::parser::Ps), crate::syntax::lexer::PathSegTok)| {
                            let span_p4 = span_p4.clone();
                            entered(once_job(move || {
                                let (acc_p6, pp_p7) = p0;
                                let seg_p8 = p1;
                                prism_rtl::Turn::Finished(path_seg_of(&acc_p6, &pp_p7, &seg_p8, &span_p4))
                            }))
                        }) as Rc<dyn Fn(((Array<crate::syntax::decls::PathSeg>, crate::syntax::parser::Ps), crate::syntax::lexer::PathSegTok)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::decls::PathSeg>, crate::syntax::parser::Ps)>>>
                    }));
                    let path_p5 = crate::syntax::decls::TestPath { segments: segments_p9.clone(), span: span_p4.clone() };
                    if element_p1 {
                        (crate::syntax::decls::Target::TgElement(path_p5.clone()), q_pa.clone())
                    } else {
                        (crate::syntax::decls::Target::TgPath(path_p5.clone()), q_pa.clone())
                    }
                },
                _ => (crate::syntax::decls::Target::TgPattern(crate::syntax::parser::decls::no_pattern()), crate::syntax::parser::error_here(&p1_p2, &Text::lit("`at` takes a path, `1/#0/0`"))),
            }
        }
    } else {
        {
            let (pat_pb, q_pc) = crate::syntax::parser::types::parse_pattern(p_p0, &false);
            (crate::syntax::decls::Target::TgPattern(pat_pb.clone()), q_pc.clone())
        }
    }
}

/// ```prism
/// IsPathKind: fn TokKind -> Bool
/// ```
pub fn is_path_kind(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KPath(_) => true,
        _ => false,
    }
}

/// ```prism
/// PathSegOf: unbounded fn [PathSeg], Ps, PathSegTok, Range -> (([PathSeg], Ps))
/// ```
pub fn path_seg_of(acc_p0: &Array<crate::syntax::decls::PathSeg>, p_p1: &crate::syntax::parser::Ps, path_seg_tok2: &crate::syntax::lexer::PathSegTok, range3: &crate::syntax::Range) -> (Array<crate::syntax::decls::PathSeg>, crate::syntax::parser::Ps) {
    match (path_seg_tok2, range3) {
        (crate::syntax::lexer::PathSegTok::PstNum(n_p2), _) => (push(acc_p0, &crate::syntax::decls::PathSeg::PsNum(n_p2.clone())), p_p1.clone()),
        (crate::syntax::lexer::PathSegTok::PstGen(n_p5), _) => (push(acc_p0, &crate::syntax::decls::PathSeg::PsGen(n_p5.clone())), p_p1.clone()),
        (crate::syntax::lexer::PathSegTok::PstKey(toks_p8), span_p9) => {
            let (e_pa, q_pb) = crate::syntax::parser::expr::parse_nested(p_p1, toks_p8, span_p9);
            (push(acc_p0, &crate::syntax::decls::PathSeg::PsKey(e_pa.clone())), q_pb.clone())
        },
    }
}

/// ```prism
/// ParseTestCheck: unbounded fn Ps -> ((TestCheck, Ps))
/// ```
pub fn parse_test_check(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::TestCheck, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here(p0_p0);
    let p_p2 = crate::syntax::parser::expect_op(p0_p0, &Text::lit("=>"));
    let word_p3 = step_word(&p_p2);
    if p_p2.bad {
        (crate::syntax::decls::TestCheck { kind: crate::syntax::decls::TestCheckKind::CkQuiet, span: start_p1.clone() }, p_p2.clone())
    } else {
        if &word_p3 == &Text::lit("") {
            (crate::syntax::decls::TestCheck { kind: crate::syntax::decls::TestCheckKind::CkQuiet, span: start_p1.clone() }, crate::syntax::parser::error_here(&p_p2, &Text::lit("expected a check after `=>`: `expect`, `returns`, `fired`, `quiet`, ...")))
        } else {
            {
                let (kind_p4, q_p5) = check_kind_of(&crate::syntax::parser::adv(&p_p2), &word_p3);
                (crate::syntax::decls::TestCheck { kind: kind_p4.clone(), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&q_p5)) }, q_p5.clone())
            }
        }
    }
}

/// The step machine of `ParseTestCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTestCheck: unbounded fn Ps -> ((TestCheck, Ps))
/// ```
pub struct ParseTestCheck {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::TestCheck, crate::syntax::parser::Ps)> for ParseTestCheck {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::TestCheck, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let start_p1 = crate::syntax::parser::here(p0_p0);
        let p_p2 = crate::syntax::parser::expect_op(p0_p0, &Text::lit("=>"));
        let word_p3 = step_word(&p_p2);
        if p_p2.bad {
            prism_rtl::Turn::Finished((crate::syntax::decls::TestCheck { kind: crate::syntax::decls::TestCheckKind::CkQuiet, span: start_p1.clone() }, p_p2.clone()))
        } else {
            if &word_p3 == &Text::lit("") {
                prism_rtl::Turn::Finished((crate::syntax::decls::TestCheck { kind: crate::syntax::decls::TestCheckKind::CkQuiet, span: start_p1.clone() }, crate::syntax::parser::error_here(&p_p2, &Text::lit("expected a check after `=>`: `expect`, `returns`, `fired`, `quiet`, ..."))))
            } else {
                call_then(start_check_kind_of(crate::syntax::parser::adv(&p_p2), word_p3.clone()), move |check_kind_of_9526: (crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps)| {
                    let (kind_p4, q_p5) = check_kind_of_9526;
                    prism_rtl::Turn::Finished((crate::syntax::decls::TestCheck { kind: kind_p4.clone(), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&q_p5)) }, q_p5.clone()))
                })
            }
        }
    }
}

/// `Start ParseTestCheck, x`: what the function value is when passed to `@Run`.
pub fn start_parse_test_check(p0_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TestCheck, crate::syntax::parser::Ps)>> {
    Rc::new(ParseTestCheck { p0_p0 })
}

/// ```prism
/// CheckKindOf: unbounded fn Ps, Text -> ((TestCheckKind, Ps))
/// ```
pub fn check_kind_of(p_p0: &crate::syntax::parser::Ps, word_p1: &Text) -> (crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps) {
    match word_p1 {
        m9701_0 if (m9701_0 == &Text::lit("expect")) => one_pattern(p_p0, &{
            let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkExpect(a0.clone()));
            Rc::new(move |a0: crate::syntax::Pattern_| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
        }),
        m9701_1 if (m9701_1 == &Text::lit("expect_none")) => one_pattern(p_p0, &{
            let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkExpectNone(a0.clone()));
            Rc::new(move |a0: crate::syntax::Pattern_| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
        }),
        m9701_2 if (m9701_2 == &Text::lit("expect_top")) => one_pattern(p_p0, &{
            let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkExpectTop(a0.clone()));
            Rc::new(move |a0: crate::syntax::Pattern_| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
        }),
        m9701_3 if (m9701_3 == &Text::lit("expect_top_none")) => one_pattern(p_p0, &{
            let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkExpectTopNone(a0.clone()));
            Rc::new(move |a0: crate::syntax::Pattern_| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
        }),
        m9701_4 if (m9701_4 == &Text::lit("unrequested")) => one_pattern(p_p0, &{
            let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkUnrequested(a0.clone()));
            Rc::new(move |a0: crate::syntax::Pattern_| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
        }),
        m9701_5 if (m9701_5 == &Text::lit("returns")) => one_pattern(p_p0, &{
            let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkReturns(a0.clone()));
            Rc::new(move |a0: crate::syntax::Pattern_| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
        }),
        m9701_6 if (m9701_6 == &Text::lit("fired")) => one_pattern(p_p0, &{
            let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkFired(a0.clone()));
            Rc::new(move |a0: crate::syntax::Pattern_| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
        }),
        m9701_7 if (m9701_7 == &Text::lit("expect_count")) => {
            let (pat_p2, p1_p3) = crate::syntax::parser::types::parse_pattern(p_p0, &false);
            if !crate::syntax::parser::at_comma(&p1_p3) {
                (crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_here(&p1_p3, &Text::lit("`expect_count` takes a pattern and a count: `expect_count p, n`")))
            } else {
                {
                    let p2_p4 = crate::syntax::parser::adv(&p1_p3);
                    match crate::syntax::parser::kind(&p2_p4) {
                        crate::syntax::lexer::TokKind::KInt(m10260_0_0, text_p5) if (&m10260_0_0 == &Text::lit("")) => (crate::syntax::decls::TestCheckKind::CkExpectCount(pat_p2.clone(), parse_nat_text(&text_p5)), crate::syntax::parser::adv(&p2_p4)),
                        _ => (crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_here(&p2_p4, &Text::lit("`expect_count` takes a number"))),
                        _ => unreachable!("no arm matched"),
                    }
                }
            }
        },
        m9701_8 if (m9701_8 == &Text::lit("requested")) => {
            let (place_p6, p1_p7) = crate::syntax::parser::types::parse_pattern(p_p0, &false);
            if !crate::syntax::parser::at_comma(&p1_p7) {
                (crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_here(&p1_p7, &Text::lit("`requested` takes a place and a value: `requested p, v`")))
            } else {
                {
                    let (value_p8, q_p9) = crate::syntax::parser::types::parse_pattern(&crate::syntax::parser::adv(&p1_p7), &false);
                    (crate::syntax::decls::TestCheckKind::CkRequested(place_p6.clone(), value_p8.clone()), q_p9.clone())
                }
            }
        },
        m9701_9 if (m9701_9 == &Text::lit("quiet")) => (crate::syntax::decls::TestCheckKind::CkQuiet, p_p0.clone()),
        m9701_10 if (m9701_10 == &Text::lit("settles")) => (crate::syntax::decls::TestCheckKind::CkSettles, p_p0.clone()),
        m9701_11 if (m9701_11 == &Text::lit("aborted")) => (crate::syntax::decls::TestCheckKind::CkAborted, p_p0.clone()),
        m9701_12 if (m9701_12 == &Text::lit("snapshot")) => match crate::syntax::parser::kind(p_p0) {
            crate::syntax::lexer::TokKind::KText(m10860_0_0, segs_pa) if (&m10860_0_0 == &Text::lit("")) && all_plain(&segs_pa) => (crate::syntax::decls::TestCheckKind::CkSnapshot(concat(&each(&segs_pa, &plain_of))), crate::syntax::parser::adv(p_p0)),
            _ => (crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_here(p_p0, &Text::lit("`snapshot` takes a file name, a text literal"))),
            _ => unreachable!("no arm matched"),
        },
        _ => (crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_at(p_p0, &crate::syntax::parser::prev(p_p0), &Text::from(format!("`{}` is not a check: the checks are expect, expect_none, expect_count, expect_top, expect_top_none, requested, unrequested, returns, fired, quiet, settles, aborted, snapshot", word_p1)))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CheckKindOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckKindOf: unbounded fn Ps, Text -> ((TestCheckKind, Ps))
/// ```
pub struct CheckKindOf {
    pub p_p0: crate::syntax::parser::Ps,
    pub word_p1: Text,
}

impl prism_rtl::Job<(crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps)> for CheckKindOf {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let word_p1 = &self.word_p1;
        match word_p1 {
            m9701_0 if (m9701_0 == &Text::lit("expect")) => prism_rtl::Turn::More(Rc::new(OnePattern { p_p0: p_p0.clone(), make_f1: {
                let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkExpect(a0.clone()));
                Rc::new(move |a0: crate::syntax::Pattern_| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
            } })),
            m9701_1 if (m9701_1 == &Text::lit("expect_none")) => prism_rtl::Turn::More(Rc::new(OnePattern { p_p0: p_p0.clone(), make_f1: {
                let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkExpectNone(a0.clone()));
                Rc::new(move |a0: crate::syntax::Pattern_| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
            } })),
            m9701_2 if (m9701_2 == &Text::lit("expect_top")) => prism_rtl::Turn::More(Rc::new(OnePattern { p_p0: p_p0.clone(), make_f1: {
                let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkExpectTop(a0.clone()));
                Rc::new(move |a0: crate::syntax::Pattern_| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
            } })),
            m9701_3 if (m9701_3 == &Text::lit("expect_top_none")) => prism_rtl::Turn::More(Rc::new(OnePattern { p_p0: p_p0.clone(), make_f1: {
                let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkExpectTopNone(a0.clone()));
                Rc::new(move |a0: crate::syntax::Pattern_| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
            } })),
            m9701_4 if (m9701_4 == &Text::lit("unrequested")) => prism_rtl::Turn::More(Rc::new(OnePattern { p_p0: p_p0.clone(), make_f1: {
                let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkUnrequested(a0.clone()));
                Rc::new(move |a0: crate::syntax::Pattern_| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
            } })),
            m9701_5 if (m9701_5 == &Text::lit("returns")) => prism_rtl::Turn::More(Rc::new(OnePattern { p_p0: p_p0.clone(), make_f1: {
                let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkReturns(a0.clone()));
                Rc::new(move |a0: crate::syntax::Pattern_| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
            } })),
            m9701_6 if (m9701_6 == &Text::lit("fired")) => prism_rtl::Turn::More(Rc::new(OnePattern { p_p0: p_p0.clone(), make_f1: {
                let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkFired(a0.clone()));
                Rc::new(move |a0: crate::syntax::Pattern_| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
            } })),
            m9701_7 if (m9701_7 == &Text::lit("expect_count")) => {
                let p_p0 = p_p0.clone();
                call_then(crate::syntax::parser::types::start_parse_pattern(p_p0.clone(), false), move |parse_pattern_10060: (crate::syntax::Pattern_, crate::syntax::parser::Ps)| {
                    let (pat_p2, p1_p3) = parse_pattern_10060;
                    if !crate::syntax::parser::at_comma(&p1_p3) {
                        prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_here(&p1_p3, &Text::lit("`expect_count` takes a pattern and a count: `expect_count p, n`"))))
                    } else {
                        {
                            let p2_p4 = crate::syntax::parser::adv(&p1_p3);
                            match crate::syntax::parser::kind(&p2_p4) {
                                crate::syntax::lexer::TokKind::KInt(m10260_0_0, text_p5) if (&m10260_0_0 == &Text::lit("")) => prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkExpectCount(pat_p2.clone(), parse_nat_text(&text_p5)), crate::syntax::parser::adv(&p2_p4))),
                                _ => prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_here(&p2_p4, &Text::lit("`expect_count` takes a number")))),
                                _ => unreachable!("no arm matched"),
                            }
                        }
                    }
                })
            },
            m9701_8 if (m9701_8 == &Text::lit("requested")) => {
                let p_p0 = p_p0.clone();
                call_then(crate::syntax::parser::types::start_parse_pattern(p_p0.clone(), false), move |parse_pattern_10494: (crate::syntax::Pattern_, crate::syntax::parser::Ps)| {
                    let (place_p6, p1_p7) = parse_pattern_10494;
                    if !crate::syntax::parser::at_comma(&p1_p7) {
                        prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_here(&p1_p7, &Text::lit("`requested` takes a place and a value: `requested p, v`"))))
                    } else {
                        call_then(crate::syntax::parser::types::start_parse_pattern(crate::syntax::parser::adv(&p1_p7), false), move |parse_pattern_10677: (crate::syntax::Pattern_, crate::syntax::parser::Ps)| {
                            let (value_p8, q_p9) = parse_pattern_10677;
                            prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkRequested(place_p6.clone(), value_p8.clone()), q_p9.clone()))
                        })
                    }
                })
            },
            m9701_9 if (m9701_9 == &Text::lit("quiet")) => prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkQuiet, p_p0.clone())),
            m9701_10 if (m9701_10 == &Text::lit("settles")) => prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkSettles, p_p0.clone())),
            m9701_11 if (m9701_11 == &Text::lit("aborted")) => prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkAborted, p_p0.clone())),
            m9701_12 if (m9701_12 == &Text::lit("snapshot")) => match crate::syntax::parser::kind(p_p0) {
                crate::syntax::lexer::TokKind::KText(m10860_0_0, segs_pa) if (&m10860_0_0 == &Text::lit("")) && all_plain(&segs_pa) => prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkSnapshot(concat(&each(&segs_pa, &plain_of))), crate::syntax::parser::adv(p_p0))),
                _ => prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_here(p_p0, &Text::lit("`snapshot` takes a file name, a text literal")))),
                _ => unreachable!("no arm matched"),
            },
            _ => prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_at(p_p0, &crate::syntax::parser::prev(p_p0), &Text::from(format!("`{}` is not a check: the checks are expect, expect_none, expect_count, expect_top, expect_top_none, requested, unrequested, returns, fired, quiet, settles, aborted, snapshot", word_p1))))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start CheckKindOf, x`: what the function value is when passed to `@Run`.
pub fn start_check_kind_of(p_p0: crate::syntax::parser::Ps, word_p1: Text) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps)>> {
    Rc::new(CheckKindOf { p_p0, word_p1 })
}

/// ```prism
/// OnePattern: unbounded fn Ps, (fn Pattern -> TestCheckKind) -> ((TestCheckKind, Ps))
/// ```
pub fn one_pattern(p_p0: &crate::syntax::parser::Ps, make_f1: &Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>) -> (crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps) {
    let (pat_p2, q_p3) = crate::syntax::parser::types::parse_pattern(p_p0, &false);
    (run_to_end(make_f1(pat_p2.clone())), q_p3.clone())
}

/// The step machine of `OnePattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OnePattern: unbounded fn Ps, (fn Pattern -> TestCheckKind) -> ((TestCheckKind, Ps))
/// ```
pub struct OnePattern {
    pub p_p0: crate::syntax::parser::Ps,
    pub make_f1: Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>,
}

impl prism_rtl::Job<(crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps)> for OnePattern {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let make_f1 = &self.make_f1;
        let make_f1 = make_f1.clone();
        let p_p0 = p_p0.clone();
        call_then(crate::syntax::parser::types::start_parse_pattern(p_p0.clone(), false), move |parse_pattern_11423: (crate::syntax::Pattern_, crate::syntax::parser::Ps)| {
            let (pat_p2, q_p3) = parse_pattern_11423;
            call_value((&make_f1)(pat_p2.clone()), move |make_11451: crate::syntax::decls::TestCheckKind| prism_rtl::Turn::Finished((make_11451, q_p3.clone())))
        })
    }
}

/// `Start OnePattern, x`: what the function value is when passed to `@Run`.
pub fn start_one_pattern(p_p0: crate::syntax::parser::Ps, make_f1: Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps)>> {
    Rc::new(OnePattern { p_p0, make_f1 })
}

/// ```prism
/// AllPlain: fn [TextSegTok] -> Bool
/// ```
pub fn all_plain(segs_p0: &Array<crate::syntax::lexer::TextSegTok>) -> bool {
    fold(segs_p0, &true, &(|ok_p1: &bool, s_p2: &crate::syntax::lexer::TextSegTok| *ok_p1 && is_plain_seg(s_p2)))
}

/// ```prism
/// IsPlainSeg: fn TextSegTok -> Bool
/// ```
pub fn is_plain_seg(text_seg_tok0: &crate::syntax::lexer::TextSegTok) -> bool {
    match text_seg_tok0 {
        crate::syntax::lexer::TextSegTok::TsPlain(_) => true,
        _ => false,
    }
}

/// ```prism
/// PlainOf: fn TextSegTok -> Text
/// ```
pub fn plain_of(text_seg_tok0: &crate::syntax::lexer::TextSegTok) -> Text {
    match text_seg_tok0 {
        crate::syntax::lexer::TextSegTok::TsPlain(s_p0) => s_p0.clone(),
        _ => Text::lit(""),
    }
}

/// ```prism
/// ParseNatText: fn Text -> Nat
/// ```
pub fn parse_nat_text(text0_p0: &Text) -> Nat {
    let text_p1 = concat(&split_on(text0_p0, &Text::lit("_")));
    if crate::syntax::lexer::chars::has_prefix(&text_p1, &Text::lit("0x")) {
        or(&crate::syntax::lexer::chars::parse_hex(&crate::syntax::lexer::chars::drop_prefix(&text_p1, &Text::lit("0x"))), &Nat::from(0u32))
    } else {
        if crate::syntax::lexer::chars::has_prefix(&text_p1, &Text::lit("0o")) {
            or(&parse_radix(&crate::syntax::lexer::chars::drop_prefix(&text_p1, &Text::lit("0o")), &Nat::from(8u32)), &Nat::from(0u32))
        } else {
            if crate::syntax::lexer::chars::has_prefix(&text_p1, &Text::lit("0b")) {
                or(&parse_radix(&crate::syntax::lexer::chars::drop_prefix(&text_p1, &Text::lit("0b")), &Nat::from(2u32)), &Nat::from(0u32))
            } else {
                or(&parse_nat_opt(&text_p1), &Nat::from(0u32))
            }
        }
    }
}

/// ```prism
/// ?ParseRadix: fn Text, Nat -> ?Nat
/// ```
pub fn parse_radix(t_p0: &Text, radix_p1: &Nat) -> Option<Nat> {
    'g12268: {
        if !((t_p0 != &Text::lit("")) && crate::syntax::lexer::chars::all_chars(t_p0, &{
            let radix_p1 = radix_p1.clone();
            Rc::new(move |p0: Text| {
                let radix_p1 = radix_p1.clone();
                once_job(move || {
                    let c_p2 = p0;
                    prism_rtl::Turn::Finished(crate::syntax::lexer::chars::is_digit(&c_p2) && (&crate::syntax::lexer::chars::hex_value(&c_p2) < &radix_p1))
                })
            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
        })) {
            break 'g12268 None;
        }
        Some(crate::syntax::lexer::chars::fold_chars(t_p0, &Nat::from(0u32), &{
            let radix_p1 = radix_p1.clone();
            Rc::new(move |(p0, p1): (Nat, Text)| {
                let radix_p1 = radix_p1.clone();
                once_job(move || {
                    let n_p3 = p0;
                    let c_p4 = p1;
                    prism_rtl::Turn::Finished(&(&n_p3 * &radix_p1) + &crate::syntax::lexer::chars::hex_value(&c_p4))
                })
            }) as Rc<dyn Fn((Nat, Text)) -> Rc<dyn prism_rtl::Job<Nat>>>
        }))
    }
}
