//! The module `Syntax.Parser.TestLanguage`, from `target/bootstrap/src/prismc/syntax/parser/test_language.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// let deliveryWords
/// ```
pub fn delivery_words_p() -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::Array::from(vec![crate::prelude::Text::lit("send"), crate::prelude::Text::lit("click"), crate::prelude::Text::lit("answer")])
}

/// ```prism
/// IsDeliveryWord: fn Text -> Bool
/// ```
pub fn is_delivery_word_f(w_p0: &crate::prelude::Text) -> bool {
    crate::prelude::fold(&delivery_words_p(), &false, &(|seen_p1: &bool, d_p2: &crate::prelude::Text| *seen_p1 || (d_p2 == w_p0)))
}

/// ```prism
/// StepWord: fn Ps -> Text
/// ```
pub fn step_word_f(p_p0: &crate::syntax::parser::Ps) -> crate::prelude::Text {
    match crate::syntax::parser::kind_f(p_p0) {
        crate::syntax::lexer::TokKind::KName(n_p1) if (((&n_p1.sigils_p == &crate::prelude::Text::lit("")) && (&crate::prelude::len(&n_p1.path_p) == &crate::prelude::Nat::from(1u32))) && (&n_p1.case_p == &crate::syntax::lexer::NameCase::CaseLower)) => crate::prelude::or(&crate::prelude::index(&n_p1.path_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")),
        _ => crate::prelude::Text::lit(""),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// AtWord: fn Ps, Text -> Bool
/// ```
pub fn at_word_f(p_p0: &crate::syntax::parser::Ps, w_p1: &crate::prelude::Text) -> bool {
    &step_word_f(p_p0) == w_p1
}

/// ```prism
/// ParseCheckDecl: unbounded fn Ps -> ((CheckDecl, Ps))
/// ```
pub fn parse_check_decl_f(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::CheckDecl, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p0_p0);
    let (name_p3, p1_p4) = crate::syntax::parser::parse_ident_f(&crate::syntax::parser::adv_f(p0_p0));
    let p2_p2 = crate::syntax::parser::expect_colon_f(&p1_p4);
    if crate::syntax::parser::at_open_l_f(&p2_p2) {
        {
            let (lines_p5, q_p6) = crate::syntax::parser::layout_items_f(&crate::syntax::parser::adv_f(&p2_p2), &(::std::rc::Rc::new(|a0: crate::syntax::parser::Ps| crate::prelude::entered(start_parse_check_line_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::decls::CheckLine, crate::syntax::parser::Ps)>>>));
            (crate::syntax::decls::CheckDecl { name_p: name_p3.clone(), lines_p: lines_p5.clone(), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&q_p6)) }, q_p6.clone())
        }
    } else {
        (crate::syntax::decls::CheckDecl { name_p: name_p3.clone(), lines_p: crate::prelude::Array::new(), span_p: start_p1.clone() }, crate::syntax::parser::error_here_f(&p2_p2, &crate::prelude::Text::lit("a `check` block\'s lines stand in an indented block")))
    }
}

/// The step machine of `ParseCheckDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseCheckDecl: unbounded fn Ps -> ((CheckDecl, Ps))
/// ```
pub struct ParseCheckDecl {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::decls::CheckDecl, crate::syntax::parser::Ps)> for ParseCheckDecl {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::decls::CheckDecl, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let start_p1 = crate::syntax::parser::here_f(p0_p0);
        let (name_p3, p1_p4) = crate::syntax::parser::parse_ident_f(&crate::syntax::parser::adv_f(p0_p0));
        let p2_p2 = crate::syntax::parser::expect_colon_f(&p1_p4);
        if crate::syntax::parser::at_open_l_f(&p2_p2) {
            crate::prelude::call_then(crate::syntax::parser::start_layout_items_f(crate::syntax::parser::adv_f(&p2_p2), ::std::rc::Rc::new(|a0: crate::syntax::parser::Ps| crate::prelude::entered(start_parse_check_line_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::decls::CheckLine, crate::syntax::parser::Ps)>>>), move |layout_items_f_1679: (crate::prelude::Array<crate::syntax::decls::CheckLine>, crate::syntax::parser::Ps)| {
                let (lines_p5, q_p6) = layout_items_f_1679;
                ::prism_rtl::Turn::Finished((crate::syntax::decls::CheckDecl { name_p: name_p3.clone(), lines_p: lines_p5.clone(), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&q_p6)) }, q_p6.clone()))
            })
        } else {
            ::prism_rtl::Turn::Finished((crate::syntax::decls::CheckDecl { name_p: name_p3.clone(), lines_p: crate::prelude::Array::new(), span_p: start_p1.clone() }, crate::syntax::parser::error_here_f(&p2_p2, &crate::prelude::Text::lit("a `check` block\'s lines stand in an indented block"))))
        }
    }
}

/// `Start ParseCheckDecl, x`: what the function value is when passed to `@Run`.
pub fn start_parse_check_decl_f(p0_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::decls::CheckDecl, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseCheckDecl { p0_p0 })
}

/// ```prism
/// ParseCheckLine: unbounded fn Ps -> ((CheckLine, Ps))
/// ```
pub fn parse_check_line_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::CheckLine, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p_p0);
    let (expr_p2, p1_p3) = crate::syntax::parser::expr::parse_rhs_expr_f(p_p0);
    let (pattern_o4, q_p5) = if crate::syntax::parser::at_op_f(&p1_p3, &crate::prelude::Text::lit("=>")) {
        optional_pattern_top_f(&crate::syntax::parser::adv_f(&p1_p3))
    } else {
        (::std::option::Option::None, p1_p3.clone())
    };
    (crate::syntax::decls::CheckLine { expr_p: expr_p2.clone(), pattern_o: pattern_o4.clone(), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&q_p5)) }, q_p5.clone())
}

/// The step machine of `ParseCheckLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseCheckLine: unbounded fn Ps -> ((CheckLine, Ps))
/// ```
pub struct ParseCheckLine {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::decls::CheckLine, crate::syntax::parser::Ps)> for ParseCheckLine {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::decls::CheckLine, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here_f(p_p0);
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(crate::syntax::parser::expr::start_parse_rhs_expr_f(p_p0x.clone()), move |parse_rhs_expr_f_2042: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
            let (expr_p2, p1_p3) = parse_rhs_expr_f_2042;
            let expr_p2z = expr_p2.clone();
            let start_p1z = start_p1.clone();
            let k_let2061 = move |v2061: (::std::option::Option<crate::syntax::Pattern>, crate::syntax::parser::Ps)| {
                let (pattern_o4, q_p5) = v2061;
                ::prism_rtl::Turn::Finished((crate::syntax::decls::CheckLine { expr_p: expr_p2z.clone(), pattern_o: pattern_o4.clone(), span_p: crate::syntax::parser::to_f(&start_p1z, &crate::syntax::parser::prev_f(&q_p5)) }, q_p5.clone()))
            };
            if crate::syntax::parser::at_op_f(&p1_p3, &crate::prelude::Text::lit("=>")) {
                crate::prelude::call_then(start_optional_pattern_top_f(crate::syntax::parser::adv_f(&p1_p3)), move |optional_pattern_top_f_2101: (::std::option::Option<crate::syntax::Pattern>, crate::syntax::parser::Ps)| k_let2061(optional_pattern_top_f_2101))
            } else {
                k_let2061((::std::option::Option::None, p1_p3.clone()))
            }
        })
    }
}

/// `Start ParseCheckLine, x`: what the function value is when passed to `@Run`.
pub fn start_parse_check_line_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::decls::CheckLine, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseCheckLine { p_p0 })
}

/// ```prism
/// OptionalPatternTop: unbounded fn Ps -> ((?Pattern, Ps))
/// ```
pub fn optional_pattern_top_f(p_p0: &crate::syntax::parser::Ps) -> (::std::option::Option<crate::syntax::Pattern>, crate::syntax::parser::Ps) {
    let (pat_p1, q_p2) = crate::syntax::parser::types::parse_pattern_f(p_p0, &true);
    (::std::option::Option::Some(pat_p1.clone()), q_p2.clone())
}

/// The step machine of `OptionalPatternTop`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptionalPatternTop: unbounded fn Ps -> ((?Pattern, Ps))
/// ```
pub struct OptionalPatternTop {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(::std::option::Option<crate::syntax::Pattern>, crate::syntax::parser::Ps)> for OptionalPatternTop {
    fn cycle(&self) -> ::prism_rtl::Turn<(::std::option::Option<crate::syntax::Pattern>, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(crate::syntax::parser::types::start_parse_pattern_f(p_p0x.clone(), true), move |parse_pattern_f_2328: (crate::syntax::Pattern, crate::syntax::parser::Ps)| {
            let (pat_p1, q_p2) = parse_pattern_f_2328;
            ::prism_rtl::Turn::Finished((::std::option::Option::Some(pat_p1.clone()), q_p2.clone()))
        })
    }
}

/// `Start OptionalPatternTop, x`: what the function value is when passed to `@Run`.
pub fn start_optional_pattern_top_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(::std::option::Option<crate::syntax::Pattern>, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(OptionalPatternTop { p_p0 })
}

/// ```prism
/// ParseTestDecl: unbounded fn Ps -> ((TestDecl, Ps))
/// ```
pub fn parse_test_decl_f(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::TestDecl, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p0_p0);
    let (name_p3, p1_p4) = crate::syntax::parser::parse_ident_f(&crate::syntax::parser::adv_f(p0_p0));
    let fallback_p2 = crate::syntax::decls::TestDecl { name_p: name_p3.clone(), blueprint_p: crate::syntax::parser::decls::no_expr_p(), seed_o: ::std::option::Option::None, steps_p: crate::prelude::Array::new(), span_p: start_p1.clone() };
    if !crate::syntax::parser::at_comma_f(&p1_p4) {
        (fallback_p2.clone(), crate::syntax::parser::error_here_f(&p1_p4, &crate::prelude::Text::lit("a test names its blueprint: `test name, @blueprint:`")))
    } else {
        {
            let (blueprint_p6, p2_p7) = crate::syntax::parser::expr::parse_arg_expr_f(&crate::syntax::parser::adv_f(&p1_p4));
            let (seed_o8, p3_p9) = if crate::syntax::parser::at_comma_f(&p2_p7) {
                parse_seed_f(&crate::syntax::parser::adv_f(&p2_p7))
            } else {
                (::std::option::Option::None, p2_p7.clone())
            };
            let p4_p5 = crate::syntax::parser::expect_colon_f(&p3_p9);
            if crate::syntax::parser::at_open_l_f(&p4_p5) {
                {
                    let saved_pa = p4_p5.step_mode_p;
                    let (steps_pd, p5_pe) = crate::syntax::parser::layout_items_f(&crate::syntax::parser::adv_f(&p4_p5), &{
                        let saved_pax = saved_pa;
                        ::std::rc::Rc::new(move |p0: crate::syntax::parser::Ps| {
                            let saved_paxy = saved_pax;
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let s_pc = p0;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(StepIn { p_p0: s_pc.clone(), saved_p1: saved_paxy }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::decls::TestStep, crate::syntax::parser::Ps)>>>
                    });
                    let q_pb = crate::syntax::parser::with_step_mode_f(&p5_pe, &saved_pa);
                    (crate::syntax::decls::TestDecl { name_p: name_p3.clone(), blueprint_p: blueprint_p6.clone(), seed_o: seed_o8.clone(), steps_p: steps_pd.clone(), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&q_pb)) }, q_pb.clone())
                }
            } else {
                (fallback_p2.clone(), crate::syntax::parser::error_here_f(&p4_p5, &crate::prelude::Text::lit("a test\'s steps stand in an indented block")))
            }
        }
    }
}

/// The step machine of `ParseTestDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTestDecl: unbounded fn Ps -> ((TestDecl, Ps))
/// ```
pub struct ParseTestDecl {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::decls::TestDecl, crate::syntax::parser::Ps)> for ParseTestDecl {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::decls::TestDecl, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let start_p1 = crate::syntax::parser::here_f(p0_p0);
        let (name_p3, p1_p4) = crate::syntax::parser::parse_ident_f(&crate::syntax::parser::adv_f(p0_p0));
        let fallback_p2 = crate::syntax::decls::TestDecl { name_p: name_p3.clone(), blueprint_p: crate::syntax::parser::decls::no_expr_p(), seed_o: ::std::option::Option::None, steps_p: crate::prelude::Array::new(), span_p: start_p1.clone() };
        if !crate::syntax::parser::at_comma_f(&p1_p4) {
            ::prism_rtl::Turn::Finished((fallback_p2.clone(), crate::syntax::parser::error_here_f(&p1_p4, &crate::prelude::Text::lit("a test names its blueprint: `test name, @blueprint:`"))))
        } else {
            crate::prelude::call_then(crate::syntax::parser::expr::start_parse_arg_expr_f(crate::syntax::parser::adv_f(&p1_p4)), move |parse_arg_expr_f_2822: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                let (blueprint_p6, p2_p7) = parse_arg_expr_f_2822;
                let (seed_o8, p3_p9) = if crate::syntax::parser::at_comma_f(&p2_p7) {
                    parse_seed_f(&crate::syntax::parser::adv_f(&p2_p7))
                } else {
                    (::std::option::Option::None, p2_p7.clone())
                };
                let p4_p5 = crate::syntax::parser::expect_colon_f(&p3_p9);
                if crate::syntax::parser::at_open_l_f(&p4_p5) {
                    {
                        let saved_pa = p4_p5.step_mode_p;
                        crate::prelude::call_then(crate::syntax::parser::start_layout_items_f(crate::syntax::parser::adv_f(&p4_p5), {
                            let saved_pax = saved_pa;
                            ::std::rc::Rc::new(move |p0: crate::syntax::parser::Ps| {
                                let saved_paxy = saved_pax;
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let s_pc = p0;
                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(StepIn { p_p0: s_pc.clone(), saved_p1: saved_paxy }))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::decls::TestStep, crate::syntax::parser::Ps)>>>
                        }), move |layout_items_f_3047: (crate::prelude::Array<crate::syntax::decls::TestStep>, crate::syntax::parser::Ps)| {
                            let (steps_pd, p5_pe) = layout_items_f_3047;
                            let q_pb = crate::syntax::parser::with_step_mode_f(&p5_pe, &saved_pa);
                            ::prism_rtl::Turn::Finished((crate::syntax::decls::TestDecl { name_p: name_p3.clone(), blueprint_p: blueprint_p6.clone(), seed_o: seed_o8.clone(), steps_p: steps_pd.clone(), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&q_pb)) }, q_pb.clone()))
                        })
                    }
                } else {
                    ::prism_rtl::Turn::Finished((fallback_p2.clone(), crate::syntax::parser::error_here_f(&p4_p5, &crate::prelude::Text::lit("a test\'s steps stand in an indented block"))))
                }
            })
        }
    }
}

/// `Start ParseTestDecl, x`: what the function value is when passed to `@Run`.
pub fn start_parse_test_decl_f(p0_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::decls::TestDecl, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseTestDecl { p0_p0 })
}

/// ```prism
/// ParseSeed: fn Ps -> ((?Nat, Ps))
/// ```
pub fn parse_seed_f(p_p0: &crate::syntax::parser::Ps) -> (::std::option::Option<crate::prelude::Nat>, crate::syntax::parser::Ps) {
    if !at_word_f(p_p0, &crate::prelude::Text::lit("seed")) {
        (::std::option::Option::None, crate::syntax::parser::error_here_f(p_p0, &crate::prelude::Text::lit("after the blueprint, a test takes only `seed n`")))
    } else {
        {
            let p1_p1 = crate::syntax::parser::adv_f(p_p0);
            match crate::syntax::parser::kind_f(&p1_p1) {
                crate::syntax::lexer::TokKind::KInt(m3530_0_0, text_p2) if (&m3530_0_0 == &crate::prelude::Text::lit("")) => (::std::option::Option::Some(parse_nat_text_f(&text_p2)), crate::syntax::parser::adv_f(&p1_p1)),
                _ => (::std::option::Option::None, crate::syntax::parser::error_here_f(&p1_p1, &crate::prelude::Text::lit("`seed` takes a number"))),
                _ => unreachable!("no arm matched"),
            }
        }
    }
}

/// ```prism
/// StepIn: unbounded fn Ps, Bool -> ((TestStep, Ps))
/// ```
pub fn step_in_f(p_p0: &crate::syntax::parser::Ps, saved_p1: &bool) -> (crate::syntax::decls::TestStep, crate::syntax::parser::Ps) {
    let (s_p2, q_p3) = parse_step_f(&crate::syntax::parser::with_step_mode_f(p_p0, &true));
    (s_p2.clone(), crate::syntax::parser::with_step_mode_f(&q_p3, saved_p1))
}

/// The step machine of `StepIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StepIn: unbounded fn Ps, Bool -> ((TestStep, Ps))
/// ```
pub struct StepIn {
    pub p_p0: crate::syntax::parser::Ps,
    pub saved_p1: bool,
}

impl ::prism_rtl::Job<(crate::syntax::decls::TestStep, crate::syntax::parser::Ps)> for StepIn {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::decls::TestStep, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let saved_p1 = &self.saved_p1;
        let (s_p2, q_p3) = parse_step_f(&crate::syntax::parser::with_step_mode_f(p_p0, &true));
        ::prism_rtl::Turn::Finished((s_p2.clone(), crate::syntax::parser::with_step_mode_f(&q_p3, saved_p1)))
    }
}

/// `Start StepIn, x`: what the function value is when passed to `@Run`.
pub fn start_step_in_f(p_p0: crate::syntax::parser::Ps, saved_p1: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::decls::TestStep, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(StepIn { p_p0, saved_p1 })
}

/// ```prism
/// ParseStep: unbounded fn Ps -> ((TestStep, Ps))
/// ```
pub fn parse_step_f(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::TestStep, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p0_p0);
    let (withs_p2, p1_p3) = with_entries_f(p0_p0);
    let (action_p4, p2_p5) = step_action_of_f(&p1_p3, &withs_p2);
    if p2_p5.bad_p {
        (crate::syntax::decls::TestStep { withs_p: withs_p2.clone(), action_p: action_p4.clone(), checks_p: crate::prelude::Array::new(), span_p: start_p1.clone() }, p2_p5.clone())
    } else {
        if crate::syntax::parser::at_open_l_f(&p2_p5) {
            {
                let (checks_p6, q_p7) = crate::syntax::parser::layout_items_f(&crate::syntax::parser::adv_f(&p2_p5), &(::std::rc::Rc::new(|a0: crate::syntax::parser::Ps| crate::prelude::entered(start_parse_test_check_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::decls::TestCheck, crate::syntax::parser::Ps)>>>));
                (crate::syntax::decls::TestStep { withs_p: withs_p2.clone(), action_p: action_p4.clone(), checks_p: checks_p6.clone(), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&q_p7)) }, q_p7.clone())
            }
        } else {
            if crate::syntax::parser::at_comma_f(&p2_p5) {
                (crate::syntax::decls::TestStep { withs_p: withs_p2.clone(), action_p: action_p4.clone(), checks_p: crate::prelude::Array::new(), span_p: start_p1.clone() }, crate::syntax::parser::error_at_f(&p2_p5, &crate::syntax::parser::here_f(&p2_p5), &crate::prelude::Text::lit("a comma in a step begins a delivery; a value with commas in it is written in parentheses")))
            } else {
                (crate::syntax::decls::TestStep { withs_p: withs_p2.clone(), action_p: action_p4.clone(), checks_p: crate::prelude::Array::new(), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&p2_p5)) }, p2_p5.clone())
            }
        }
    }
}

/// ```prism
/// WithEntries: unbounded fn Ps -> (([Entry], Ps))
/// ```
pub fn with_entries_f(p0_p0: &crate::syntax::parser::Ps) -> (crate::prelude::Array<crate::syntax::decls::Entry>, crate::syntax::parser::Ps) {
    let mut this: (crate::prelude::Array<crate::syntax::decls::Entry>, crate::syntax::parser::Ps) = (crate::prelude::Array::new(), p0_p0.clone());
    let mut withs_p1: crate::prelude::Array<crate::syntax::decls::Entry> = crate::prelude::Array::new();
    let mut p_p2: crate::syntax::parser::Ps = p0_p0.clone();
    let mut going_p3: bool = at_word_f(p0_p0, &crate::prelude::Text::lit("with"));
    while going_p3 && !p_p2.bad_p {
        let (e_p4, q_p5) = parse_entry_f(&crate::syntax::parser::adv_f(&p_p2));
        withs_p1 = crate::prelude::push(&withs_p1, &e_p4);
        if crate::syntax::parser::at_comma_f(&q_p5) {
            p_p2 = crate::syntax::parser::adv_f(&q_p5);
            going_p3 = at_word_f(&p_p2, &crate::prelude::Text::lit("with"));
        } else {
            p_p2 = q_p5.clone();
            going_p3 = false;
        }
    }
    this = (withs_p1.clone(), p_p2.clone());
    this
}

/// ```prism
/// StepActionOf: unbounded fn Ps, [Entry] -> ((StepAction, Ps))
/// ```
pub fn step_action_of_f(p_p0: &crate::syntax::parser::Ps, withs_p1: &crate::prelude::Array<crate::syntax::decls::Entry>) -> (crate::syntax::decls::StepAction, crate::syntax::parser::Ps) {
    let w_p2 = step_word_f(p_p0);
    match &w_p2 {
        m5349_0 if (m5349_0 == &crate::prelude::Text::lit("build")) => (crate::syntax::decls::StepAction::SaBuild, crate::syntax::parser::adv_f(p_p0)),
        m5349_1 if (m5349_1 == &crate::prelude::Text::lit("tick")) => (crate::syntax::decls::StepAction::SaTick, crate::syntax::parser::adv_f(p_p0)),
        m5349_2 if (m5349_2 == &crate::prelude::Text::lit("compute")) => {
            let p1_p3 = crate::syntax::parser::adv_f(p_p0);
            if at_word_f(&p1_p3, &crate::prelude::Text::lit("until")) {
                {
                    let p2_p4 = crate::syntax::parser::adv_f(&p1_p3);
                    if at_word_f(&p2_p4, &crate::prelude::Text::lit("idle")) {
                        (crate::syntax::decls::StepAction::SaCompute(true), crate::syntax::parser::adv_f(&p2_p4))
                    } else {
                        (crate::syntax::decls::StepAction::SaCompute(true), crate::syntax::parser::error_here_f(&p2_p4, &crate::prelude::Text::lit("`compute until` is followed by `idle`")))
                    }
                }
            } else {
                (crate::syntax::decls::StepAction::SaCompute(false), p1_p3.clone())
            }
        },
        m5349_3 if (m5349_3 == &crate::prelude::Text::lit("push")) => {
            let (e_p5, q_p6) = parse_entry_f(&crate::syntax::parser::adv_f(p_p0));
            (crate::syntax::decls::StepAction::SaPush(e_p5.clone()), q_p6.clone())
        },
        _ if is_delivery_word_f(&w_p2) => deliveries_f(p_p0),
        _ if ((&crate::prelude::len(withs_p1) > &crate::prelude::Nat::from(0u32)) && (crate::syntax::parser::at_open_l_f(p_p0) || crate::syntax::parser::at_stmt_boundary_f(p_p0))) => (crate::syntax::decls::StepAction::SaWithOnly, p_p0.clone()),
        _ => (crate::syntax::decls::StepAction::SaBuild, crate::syntax::parser::error_here_f(p_p0, &crate::prelude::Text::lit("expected a step: `build`, `tick`, `compute`, `send`, `click`, `answer`, `with` or `push`"))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Deliveries: unbounded fn Ps -> ((StepAction, Ps))
/// ```
pub fn deliveries_f(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::StepAction, crate::syntax::parser::Ps) {
    let mut this: (crate::syntax::decls::StepAction, crate::syntax::parser::Ps) = (crate::syntax::decls::StepAction::SaBuild, p0_p0.clone());
    let (first_p1, p1_p2) = parse_delivery_f(p0_p0);
    let mut ds_p3: crate::prelude::Array<crate::syntax::decls::Delivery> = crate::prelude::Array::from(vec![first_p1.clone()]);
    let mut p_p4: crate::syntax::parser::Ps = p1_p2.clone();
    while crate::syntax::parser::at_comma_f(&p_p4) && !p_p4.bad_p {
        if is_delivery_name_f(&crate::syntax::parser::kind_at_f(&p_p4, &crate::prelude::Nat::from(1u32))) {
            let (d_p5, q_p6) = parse_delivery_f(&crate::syntax::parser::adv_f(&p_p4));
            ds_p3 = crate::prelude::push(&ds_p3, &d_p5);
            p_p4 = q_p6.clone();
        } else {
            p_p4 = crate::syntax::parser::error_at_f(&p_p4, &crate::syntax::parser::here_f(&p_p4), &crate::prelude::Text::lit("a comma in a step begins a delivery (`click p, click q`); a value with commas in it is written in parentheses: `send p, (Min a, b)`"));
        }
    }
    this = (crate::syntax::decls::StepAction::SaDeliver(ds_p3.clone()), p_p4.clone());
    this
}

/// ```prism
/// IsDeliveryName: fn TokKind -> Bool
/// ```
pub fn is_delivery_name_f(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KName(n_p0) => (&crate::prelude::len(&n_p0.path_p) == &crate::prelude::Nat::from(1u32)) && is_delivery_word_f(&crate::prelude::or(&crate::prelude::index(&n_p0.path_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit(""))),
        _ => false,
    }
}

/// ```prism
/// ParseEntry: unbounded fn Ps -> ((Entry, Ps))
/// ```
pub fn parse_entry_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::Entry, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p_p0);
    let (element_p2, p1_p3) = crate::syntax::parser::expr::parse_arg_expr_f(p_p0);
    let (value_p4, q_p5) = crate::syntax::parser::expr::parse_arg_expr_f(&crate::syntax::parser::expect_op_f(&p1_p3, &crate::prelude::Text::lit("=")));
    (crate::syntax::decls::Entry { element_p: element_p2.clone(), value_p: value_p4.clone(), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&q_p5)) }, q_p5.clone())
}

/// ```prism
/// ParseDelivery: unbounded fn Ps -> ((Delivery, Ps))
/// ```
pub fn parse_delivery_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::Delivery, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p_p0);
    let word_p2 = step_word_f(p_p0);
    let (target_p3, p1_p4) = parse_target_f(&crate::syntax::parser::adv_f(p_p0));
    let (kind_p5, q_p6) = if &word_p2 == &crate::prelude::Text::lit("send") {
        send_value_f(&p1_p4)
    } else {
        if &word_p2 == &crate::prelude::Text::lit("click") {
            (crate::syntax::decls::DeliveryKind::DkClick, p1_p4.clone())
        } else {
            (crate::syntax::decls::DeliveryKind::DkAnswer, p1_p4.clone())
        }
    };
    (crate::syntax::decls::Delivery { kind_p: kind_p5.clone(), target_p: target_p3.clone(), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&q_p6)) }, q_p6.clone())
}

/// ```prism
/// SendValue: unbounded fn Ps -> ((DeliveryKind, Ps))
/// ```
pub fn send_value_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::DeliveryKind, crate::syntax::parser::Ps) {
    if crate::syntax::parser::at_comma_f(p_p0) {
        {
            let (v_p1, q_p2) = crate::syntax::parser::expr::parse_arg_expr_f(&crate::syntax::parser::adv_f(p_p0));
            (crate::syntax::decls::DeliveryKind::DkSend(v_p1.clone()), q_p2.clone())
        }
    } else {
        (crate::syntax::decls::DeliveryKind::DkClick, crate::syntax::parser::error_here_f(p_p0, &crate::prelude::Text::lit("`send` takes a target and a value: `send p, v`")))
    }
}

/// ```prism
/// ParseTarget: unbounded fn Ps -> ((Target, Ps))
/// ```
pub fn parse_target_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::Target, crate::syntax::parser::Ps) {
    let element_p1 = at_word_f(p_p0, &crate::prelude::Text::lit("element")) && is_path_kind_f(&crate::syntax::parser::kind_at_f(p_p0, &crate::prelude::Nat::from(1u32)));
    if at_word_f(p_p0, &crate::prelude::Text::lit("at")) || element_p1 {
        {
            let p1_p2 = crate::syntax::parser::adv_f(p_p0);
            match crate::syntax::parser::kind_f(&p1_p2) {
                crate::syntax::lexer::TokKind::KPath(segs_p3) => {
                    let span_p4 = crate::syntax::parser::here_f(&p1_p2);
                    let (segments_p9, q_pa) = crate::prelude::run_to_end(crate::prelude::fold_job(segs_p3.clone(), (crate::prelude::Array::new(), crate::syntax::parser::adv_f(&p1_p2)), {
                        let span_p4x = span_p4.clone();
                        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::syntax::decls::PathSeg>, crate::syntax::parser::Ps), crate::syntax::lexer::PathSegTok)| {
                            let span_p4xy = span_p4x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (acc_p6, pp_p7) = p0;
                                let seg_p8 = p1;
                                ::prism_rtl::Turn::Finished(path_seg_of_f(&acc_p6, &pp_p7, &seg_p8, &span_p4xy))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::syntax::decls::PathSeg>, crate::syntax::parser::Ps), crate::syntax::lexer::PathSegTok)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::decls::PathSeg>, crate::syntax::parser::Ps)>>>
                    }));
                    let path_p5 = crate::syntax::decls::TestPath { segments_p: segments_p9.clone(), span_p: span_p4.clone() };
                    if element_p1 {
                        (crate::syntax::decls::Target::TgElement(path_p5.clone()), q_pa.clone())
                    } else {
                        (crate::syntax::decls::Target::TgPath(path_p5.clone()), q_pa.clone())
                    }
                },
                _ => (crate::syntax::decls::Target::TgPattern(crate::syntax::parser::decls::no_pattern_p()), crate::syntax::parser::error_here_f(&p1_p2, &crate::prelude::Text::lit("`at` takes a path, `1/#0/0`"))),
            }
        }
    } else {
        {
            let (pat_pb, q_pc) = crate::syntax::parser::types::parse_pattern_f(p_p0, &false);
            (crate::syntax::decls::Target::TgPattern(pat_pb.clone()), q_pc.clone())
        }
    }
}

/// ```prism
/// IsPathKind: fn TokKind -> Bool
/// ```
pub fn is_path_kind_f(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KPath(_) => true,
        _ => false,
    }
}

/// ```prism
/// PathSegOf: unbounded fn [PathSeg], Ps, PathSegTok, Range -> (([PathSeg], Ps))
/// ```
pub fn path_seg_of_f(acc_p0: &crate::prelude::Array<crate::syntax::decls::PathSeg>, p_p1: &crate::syntax::parser::Ps, path_seg_tok2: &crate::syntax::lexer::PathSegTok, range3: &crate::syntax::Range) -> (crate::prelude::Array<crate::syntax::decls::PathSeg>, crate::syntax::parser::Ps) {
    match (path_seg_tok2, range3) {
        (crate::syntax::lexer::PathSegTok::PstNum(n_p2), _) => (crate::prelude::push(acc_p0, &crate::syntax::decls::PathSeg::PsNum(n_p2.clone())), p_p1.clone()),
        (crate::syntax::lexer::PathSegTok::PstGen(n_p5), _) => (crate::prelude::push(acc_p0, &crate::syntax::decls::PathSeg::PsGen(n_p5.clone())), p_p1.clone()),
        (crate::syntax::lexer::PathSegTok::PstKey(toks_p8), span_p9) => {
            let (e_pa, q_pb) = crate::syntax::parser::expr::parse_nested_f(p_p1, toks_p8, span_p9);
            (crate::prelude::push(acc_p0, &crate::syntax::decls::PathSeg::PsKey(e_pa.clone())), q_pb.clone())
        },
    }
}

/// ```prism
/// ParseTestCheck: unbounded fn Ps -> ((TestCheck, Ps))
/// ```
pub fn parse_test_check_f(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::TestCheck, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p0_p0);
    let p_p2 = crate::syntax::parser::expect_op_f(p0_p0, &crate::prelude::Text::lit("=>"));
    let word_p3 = step_word_f(&p_p2);
    if p_p2.bad_p {
        (crate::syntax::decls::TestCheck { kind_p: crate::syntax::decls::TestCheckKind::CkQuiet, span_p: start_p1.clone() }, p_p2.clone())
    } else {
        if &word_p3 == &crate::prelude::Text::lit("") {
            (crate::syntax::decls::TestCheck { kind_p: crate::syntax::decls::TestCheckKind::CkQuiet, span_p: start_p1.clone() }, crate::syntax::parser::error_here_f(&p_p2, &crate::prelude::Text::lit("expected a check after `=>`: `expect`, `returns`, `fired`, `quiet`, ...")))
        } else {
            {
                let (kind_p4, q_p5) = check_kind_of_f(&crate::syntax::parser::adv_f(&p_p2), &word_p3);
                (crate::syntax::decls::TestCheck { kind_p: kind_p4.clone(), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&q_p5)) }, q_p5.clone())
            }
        }
    }
}

/// The step machine of `ParseTestCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTestCheck: unbounded fn Ps -> ((TestCheck, Ps))
/// ```
pub struct ParseTestCheck {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::decls::TestCheck, crate::syntax::parser::Ps)> for ParseTestCheck {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::decls::TestCheck, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let start_p1 = crate::syntax::parser::here_f(p0_p0);
        let p_p2 = crate::syntax::parser::expect_op_f(p0_p0, &crate::prelude::Text::lit("=>"));
        let word_p3 = step_word_f(&p_p2);
        if p_p2.bad_p {
            ::prism_rtl::Turn::Finished((crate::syntax::decls::TestCheck { kind_p: crate::syntax::decls::TestCheckKind::CkQuiet, span_p: start_p1.clone() }, p_p2.clone()))
        } else {
            if &word_p3 == &crate::prelude::Text::lit("") {
                ::prism_rtl::Turn::Finished((crate::syntax::decls::TestCheck { kind_p: crate::syntax::decls::TestCheckKind::CkQuiet, span_p: start_p1.clone() }, crate::syntax::parser::error_here_f(&p_p2, &crate::prelude::Text::lit("expected a check after `=>`: `expect`, `returns`, `fired`, `quiet`, ..."))))
            } else {
                crate::prelude::call_then(start_check_kind_of_f(crate::syntax::parser::adv_f(&p_p2), word_p3.clone()), move |check_kind_of_f_9529: (crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps)| {
                    let (kind_p4, q_p5) = check_kind_of_f_9529;
                    ::prism_rtl::Turn::Finished((crate::syntax::decls::TestCheck { kind_p: kind_p4.clone(), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&q_p5)) }, q_p5.clone()))
                })
            }
        }
    }
}

/// `Start ParseTestCheck, x`: what the function value is when passed to `@Run`.
pub fn start_parse_test_check_f(p0_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::decls::TestCheck, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseTestCheck { p0_p0 })
}

/// ```prism
/// CheckKindOf: unbounded fn Ps, Text -> ((TestCheckKind, Ps))
/// ```
pub fn check_kind_of_f(p_p0: &crate::syntax::parser::Ps, word_p1: &crate::prelude::Text) -> (crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps) {
    match word_p1 {
        m9704_0 if (m9704_0 == &crate::prelude::Text::lit("expect")) => one_pattern_f(p_p0, &{
            let f = ::std::rc::Rc::new(|a0: &crate::syntax::Pattern| crate::syntax::decls::TestCheckKind::CkExpect(a0.clone()));
            ::std::rc::Rc::new(move |a0: crate::syntax::Pattern| {
                let fy = f.clone();
                crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Pattern) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
        }),
        m9704_1 if (m9704_1 == &crate::prelude::Text::lit("expect_none")) => one_pattern_f(p_p0, &{
            let f = ::std::rc::Rc::new(|a0: &crate::syntax::Pattern| crate::syntax::decls::TestCheckKind::CkExpectNone(a0.clone()));
            ::std::rc::Rc::new(move |a0: crate::syntax::Pattern| {
                let fy = f.clone();
                crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Pattern) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
        }),
        m9704_2 if (m9704_2 == &crate::prelude::Text::lit("expect_top")) => one_pattern_f(p_p0, &{
            let f = ::std::rc::Rc::new(|a0: &crate::syntax::Pattern| crate::syntax::decls::TestCheckKind::CkExpectTop(a0.clone()));
            ::std::rc::Rc::new(move |a0: crate::syntax::Pattern| {
                let fy = f.clone();
                crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Pattern) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
        }),
        m9704_3 if (m9704_3 == &crate::prelude::Text::lit("expect_top_none")) => one_pattern_f(p_p0, &{
            let f = ::std::rc::Rc::new(|a0: &crate::syntax::Pattern| crate::syntax::decls::TestCheckKind::CkExpectTopNone(a0.clone()));
            ::std::rc::Rc::new(move |a0: crate::syntax::Pattern| {
                let fy = f.clone();
                crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Pattern) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
        }),
        m9704_4 if (m9704_4 == &crate::prelude::Text::lit("unrequested")) => one_pattern_f(p_p0, &{
            let f = ::std::rc::Rc::new(|a0: &crate::syntax::Pattern| crate::syntax::decls::TestCheckKind::CkUnrequested(a0.clone()));
            ::std::rc::Rc::new(move |a0: crate::syntax::Pattern| {
                let fy = f.clone();
                crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Pattern) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
        }),
        m9704_5 if (m9704_5 == &crate::prelude::Text::lit("returns")) => one_pattern_f(p_p0, &{
            let f = ::std::rc::Rc::new(|a0: &crate::syntax::Pattern| crate::syntax::decls::TestCheckKind::CkReturns(a0.clone()));
            ::std::rc::Rc::new(move |a0: crate::syntax::Pattern| {
                let fy = f.clone();
                crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Pattern) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
        }),
        m9704_6 if (m9704_6 == &crate::prelude::Text::lit("fired")) => one_pattern_f(p_p0, &{
            let f = ::std::rc::Rc::new(|a0: &crate::syntax::Pattern| crate::syntax::decls::TestCheckKind::CkFired(a0.clone()));
            ::std::rc::Rc::new(move |a0: crate::syntax::Pattern| {
                let fy = f.clone();
                crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Pattern) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
        }),
        m9704_7 if (m9704_7 == &crate::prelude::Text::lit("expect_count")) => {
            let (pat_p2, p1_p3) = crate::syntax::parser::types::parse_pattern_f(p_p0, &false);
            if !crate::syntax::parser::at_comma_f(&p1_p3) {
                (crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_here_f(&p1_p3, &crate::prelude::Text::lit("`expect_count` takes a pattern and a count: `expect_count p, n`")))
            } else {
                {
                    let p2_p4 = crate::syntax::parser::adv_f(&p1_p3);
                    match crate::syntax::parser::kind_f(&p2_p4) {
                        crate::syntax::lexer::TokKind::KInt(m10263_0_0, text_p5) if (&m10263_0_0 == &crate::prelude::Text::lit("")) => (crate::syntax::decls::TestCheckKind::CkExpectCount(pat_p2.clone(), parse_nat_text_f(&text_p5)), crate::syntax::parser::adv_f(&p2_p4)),
                        _ => (crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_here_f(&p2_p4, &crate::prelude::Text::lit("`expect_count` takes a number"))),
                        _ => unreachable!("no arm matched"),
                    }
                }
            }
        },
        m9704_8 if (m9704_8 == &crate::prelude::Text::lit("requested")) => {
            let (place_p6, p1_p7) = crate::syntax::parser::types::parse_pattern_f(p_p0, &false);
            if !crate::syntax::parser::at_comma_f(&p1_p7) {
                (crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_here_f(&p1_p7, &crate::prelude::Text::lit("`requested` takes a place and a value: `requested p, v`")))
            } else {
                {
                    let (value_p8, q_p9) = crate::syntax::parser::types::parse_pattern_f(&crate::syntax::parser::adv_f(&p1_p7), &false);
                    (crate::syntax::decls::TestCheckKind::CkRequested(place_p6.clone(), value_p8.clone()), q_p9.clone())
                }
            }
        },
        m9704_9 if (m9704_9 == &crate::prelude::Text::lit("quiet")) => (crate::syntax::decls::TestCheckKind::CkQuiet, p_p0.clone()),
        m9704_10 if (m9704_10 == &crate::prelude::Text::lit("settles")) => (crate::syntax::decls::TestCheckKind::CkSettles, p_p0.clone()),
        m9704_11 if (m9704_11 == &crate::prelude::Text::lit("aborted")) => (crate::syntax::decls::TestCheckKind::CkAborted, p_p0.clone()),
        m9704_12 if (m9704_12 == &crate::prelude::Text::lit("snapshot")) => match crate::syntax::parser::kind_f(p_p0) {
            crate::syntax::lexer::TokKind::KText(m10863_0_0, segs_pa) if (&m10863_0_0 == &crate::prelude::Text::lit("")) && all_plain_f(&segs_pa) => (crate::syntax::decls::TestCheckKind::CkSnapshot(crate::prelude::concat(&crate::prelude::each(&segs_pa, &plain_of_f))), crate::syntax::parser::adv_f(p_p0)),
            _ => (crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_here_f(p_p0, &crate::prelude::Text::lit("`snapshot` takes a file name, a text literal"))),
            _ => unreachable!("no arm matched"),
        },
        _ => (crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_at_f(p_p0, &crate::syntax::parser::prev_f(p_p0), &crate::prelude::Text::from(format!("`{}` is not a check: the checks are expect, expect_none, expect_count, expect_top, expect_top_none, requested, unrequested, returns, fired, quiet, settles, aborted, snapshot", word_p1)))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CheckKindOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckKindOf: unbounded fn Ps, Text -> ((TestCheckKind, Ps))
/// ```
pub struct CheckKindOf {
    pub p_p0: crate::syntax::parser::Ps,
    pub word_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<(crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps)> for CheckKindOf {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let word_p1 = &self.word_p1;
        match word_p1 {
            m9704_0 if (m9704_0 == &crate::prelude::Text::lit("expect")) => ::prism_rtl::Turn::More(::std::rc::Rc::new(OnePattern { p_p0: p_p0.clone(), make_f1: {
                let f = ::std::rc::Rc::new(|a0: &crate::syntax::Pattern| crate::syntax::decls::TestCheckKind::CkExpect(a0.clone()));
                ::std::rc::Rc::new(move |a0: crate::syntax::Pattern| {
                    let fy = f.clone();
                    crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Pattern) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
            } })),
            m9704_1 if (m9704_1 == &crate::prelude::Text::lit("expect_none")) => ::prism_rtl::Turn::More(::std::rc::Rc::new(OnePattern { p_p0: p_p0.clone(), make_f1: {
                let f = ::std::rc::Rc::new(|a0: &crate::syntax::Pattern| crate::syntax::decls::TestCheckKind::CkExpectNone(a0.clone()));
                ::std::rc::Rc::new(move |a0: crate::syntax::Pattern| {
                    let fy = f.clone();
                    crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Pattern) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
            } })),
            m9704_2 if (m9704_2 == &crate::prelude::Text::lit("expect_top")) => ::prism_rtl::Turn::More(::std::rc::Rc::new(OnePattern { p_p0: p_p0.clone(), make_f1: {
                let f = ::std::rc::Rc::new(|a0: &crate::syntax::Pattern| crate::syntax::decls::TestCheckKind::CkExpectTop(a0.clone()));
                ::std::rc::Rc::new(move |a0: crate::syntax::Pattern| {
                    let fy = f.clone();
                    crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Pattern) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
            } })),
            m9704_3 if (m9704_3 == &crate::prelude::Text::lit("expect_top_none")) => ::prism_rtl::Turn::More(::std::rc::Rc::new(OnePattern { p_p0: p_p0.clone(), make_f1: {
                let f = ::std::rc::Rc::new(|a0: &crate::syntax::Pattern| crate::syntax::decls::TestCheckKind::CkExpectTopNone(a0.clone()));
                ::std::rc::Rc::new(move |a0: crate::syntax::Pattern| {
                    let fy = f.clone();
                    crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Pattern) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
            } })),
            m9704_4 if (m9704_4 == &crate::prelude::Text::lit("unrequested")) => ::prism_rtl::Turn::More(::std::rc::Rc::new(OnePattern { p_p0: p_p0.clone(), make_f1: {
                let f = ::std::rc::Rc::new(|a0: &crate::syntax::Pattern| crate::syntax::decls::TestCheckKind::CkUnrequested(a0.clone()));
                ::std::rc::Rc::new(move |a0: crate::syntax::Pattern| {
                    let fy = f.clone();
                    crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Pattern) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
            } })),
            m9704_5 if (m9704_5 == &crate::prelude::Text::lit("returns")) => ::prism_rtl::Turn::More(::std::rc::Rc::new(OnePattern { p_p0: p_p0.clone(), make_f1: {
                let f = ::std::rc::Rc::new(|a0: &crate::syntax::Pattern| crate::syntax::decls::TestCheckKind::CkReturns(a0.clone()));
                ::std::rc::Rc::new(move |a0: crate::syntax::Pattern| {
                    let fy = f.clone();
                    crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Pattern) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
            } })),
            m9704_6 if (m9704_6 == &crate::prelude::Text::lit("fired")) => ::prism_rtl::Turn::More(::std::rc::Rc::new(OnePattern { p_p0: p_p0.clone(), make_f1: {
                let f = ::std::rc::Rc::new(|a0: &crate::syntax::Pattern| crate::syntax::decls::TestCheckKind::CkFired(a0.clone()));
                ::std::rc::Rc::new(move |a0: crate::syntax::Pattern| {
                    let fy = f.clone();
                    crate::prelude::once_job(move || ::prism_rtl::Turn::Finished(fy(&a0)))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Pattern) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
            } })),
            m9704_7 if (m9704_7 == &crate::prelude::Text::lit("expect_count")) => {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(crate::syntax::parser::types::start_parse_pattern_f(p_p0x.clone(), false), move |parse_pattern_f_10063: (crate::syntax::Pattern, crate::syntax::parser::Ps)| {
                    let (pat_p2, p1_p3) = parse_pattern_f_10063;
                    if !crate::syntax::parser::at_comma_f(&p1_p3) {
                        ::prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_here_f(&p1_p3, &crate::prelude::Text::lit("`expect_count` takes a pattern and a count: `expect_count p, n`"))))
                    } else {
                        {
                            let p2_p4 = crate::syntax::parser::adv_f(&p1_p3);
                            match crate::syntax::parser::kind_f(&p2_p4) {
                                crate::syntax::lexer::TokKind::KInt(m10263_0_0, text_p5) if (&m10263_0_0 == &crate::prelude::Text::lit("")) => ::prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkExpectCount(pat_p2.clone(), parse_nat_text_f(&text_p5)), crate::syntax::parser::adv_f(&p2_p4))),
                                _ => ::prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_here_f(&p2_p4, &crate::prelude::Text::lit("`expect_count` takes a number")))),
                                _ => unreachable!("no arm matched"),
                            }
                        }
                    }
                })
            },
            m9704_8 if (m9704_8 == &crate::prelude::Text::lit("requested")) => {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(crate::syntax::parser::types::start_parse_pattern_f(p_p0x.clone(), false), move |parse_pattern_f_10497: (crate::syntax::Pattern, crate::syntax::parser::Ps)| {
                    let (place_p6, p1_p7) = parse_pattern_f_10497;
                    if !crate::syntax::parser::at_comma_f(&p1_p7) {
                        ::prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_here_f(&p1_p7, &crate::prelude::Text::lit("`requested` takes a place and a value: `requested p, v`"))))
                    } else {
                        crate::prelude::call_then(crate::syntax::parser::types::start_parse_pattern_f(crate::syntax::parser::adv_f(&p1_p7), false), move |parse_pattern_f_10680: (crate::syntax::Pattern, crate::syntax::parser::Ps)| {
                            let (value_p8, q_p9) = parse_pattern_f_10680;
                            ::prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkRequested(place_p6.clone(), value_p8.clone()), q_p9.clone()))
                        })
                    }
                })
            },
            m9704_9 if (m9704_9 == &crate::prelude::Text::lit("quiet")) => ::prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkQuiet, p_p0.clone())),
            m9704_10 if (m9704_10 == &crate::prelude::Text::lit("settles")) => ::prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkSettles, p_p0.clone())),
            m9704_11 if (m9704_11 == &crate::prelude::Text::lit("aborted")) => ::prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkAborted, p_p0.clone())),
            m9704_12 if (m9704_12 == &crate::prelude::Text::lit("snapshot")) => match crate::syntax::parser::kind_f(p_p0) {
                crate::syntax::lexer::TokKind::KText(m10863_0_0, segs_pa) if (&m10863_0_0 == &crate::prelude::Text::lit("")) && all_plain_f(&segs_pa) => ::prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkSnapshot(crate::prelude::concat(&crate::prelude::each(&segs_pa, &plain_of_f))), crate::syntax::parser::adv_f(p_p0))),
                _ => ::prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_here_f(p_p0, &crate::prelude::Text::lit("`snapshot` takes a file name, a text literal")))),
                _ => unreachable!("no arm matched"),
            },
            _ => ::prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_at_f(p_p0, &crate::syntax::parser::prev_f(p_p0), &crate::prelude::Text::from(format!("`{}` is not a check: the checks are expect, expect_none, expect_count, expect_top, expect_top_none, requested, unrequested, returns, fired, quiet, settles, aborted, snapshot", word_p1))))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start CheckKindOf, x`: what the function value is when passed to `@Run`.
pub fn start_check_kind_of_f(p_p0: crate::syntax::parser::Ps, word_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(CheckKindOf { p_p0, word_p1 })
}

/// ```prism
/// OnePattern: unbounded fn Ps, (fn Pattern -> TestCheckKind) -> ((TestCheckKind, Ps))
/// ```
pub fn one_pattern_f(p_p0: &crate::syntax::parser::Ps, make_f1: &::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Pattern) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>) -> (crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps) {
    let (pat_p2, q_p3) = crate::syntax::parser::types::parse_pattern_f(p_p0, &false);
    (crate::prelude::run_to_end(make_f1(pat_p2.clone())), q_p3.clone())
}

/// The step machine of `OnePattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OnePattern: unbounded fn Ps, (fn Pattern -> TestCheckKind) -> ((TestCheckKind, Ps))
/// ```
pub struct OnePattern {
    pub p_p0: crate::syntax::parser::Ps,
    pub make_f1: ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Pattern) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>,
}

impl ::prism_rtl::Job<(crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps)> for OnePattern {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let make_f1 = &self.make_f1;
        let make_f1x = make_f1.clone();
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(crate::syntax::parser::types::start_parse_pattern_f(p_p0x.clone(), false), move |parse_pattern_f_11426: (crate::syntax::Pattern, crate::syntax::parser::Ps)| {
            let (pat_p2, q_p3) = parse_pattern_f_11426;
            crate::prelude::call_value((&make_f1x)(pat_p2.clone()), move |make_11454: crate::syntax::decls::TestCheckKind| ::prism_rtl::Turn::Finished((make_11454, q_p3.clone())))
        })
    }
}

/// `Start OnePattern, x`: what the function value is when passed to `@Run`.
pub fn start_one_pattern_f(p_p0: crate::syntax::parser::Ps, make_f1: ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::Pattern) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(OnePattern { p_p0, make_f1 })
}

/// ```prism
/// AllPlain: fn [TextSegTok] -> Bool
/// ```
pub fn all_plain_f(segs_p0: &crate::prelude::Array<crate::syntax::lexer::TextSegTok>) -> bool {
    crate::prelude::fold(segs_p0, &true, &(|ok_p1: &bool, s_p2: &crate::syntax::lexer::TextSegTok| *ok_p1 && is_plain_seg_f(s_p2)))
}

/// ```prism
/// IsPlainSeg: fn TextSegTok -> Bool
/// ```
pub fn is_plain_seg_f(text_seg_tok0: &crate::syntax::lexer::TextSegTok) -> bool {
    match text_seg_tok0 {
        crate::syntax::lexer::TextSegTok::TsPlain(_) => true,
        _ => false,
    }
}

/// ```prism
/// PlainOf: fn TextSegTok -> Text
/// ```
pub fn plain_of_f(text_seg_tok0: &crate::syntax::lexer::TextSegTok) -> crate::prelude::Text {
    match text_seg_tok0 {
        crate::syntax::lexer::TextSegTok::TsPlain(s_p0) => s_p0.clone(),
        _ => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// ParseNatText: fn Text -> Nat
/// ```
pub fn parse_nat_text_f(text0_p0: &crate::prelude::Text) -> crate::prelude::Nat {
    let text_p1 = crate::prelude::concat(&crate::prelude::split_on(text0_p0, &crate::prelude::Text::lit("_")));
    if crate::syntax::lexer::chars::has_prefix_f(&text_p1, &crate::prelude::Text::lit("0x")) {
        crate::prelude::or(&crate::syntax::lexer::chars::parse_hex_o(&crate::syntax::lexer::chars::drop_prefix_f(&text_p1, &crate::prelude::Text::lit("0x"))), &crate::prelude::Nat::from(0u32))
    } else {
        if crate::syntax::lexer::chars::has_prefix_f(&text_p1, &crate::prelude::Text::lit("0o")) {
            crate::prelude::or(&parse_radix_o(&crate::syntax::lexer::chars::drop_prefix_f(&text_p1, &crate::prelude::Text::lit("0o")), &crate::prelude::Nat::from(8u32)), &crate::prelude::Nat::from(0u32))
        } else {
            if crate::syntax::lexer::chars::has_prefix_f(&text_p1, &crate::prelude::Text::lit("0b")) {
                crate::prelude::or(&parse_radix_o(&crate::syntax::lexer::chars::drop_prefix_f(&text_p1, &crate::prelude::Text::lit("0b")), &crate::prelude::Nat::from(2u32)), &crate::prelude::Nat::from(0u32))
            } else {
                crate::prelude::or(&crate::prelude::parse_nat_opt(&text_p1), &crate::prelude::Nat::from(0u32))
            }
        }
    }
}

/// ```prism
/// ?ParseRadix: fn Text, Nat -> ?Nat
/// ```
pub fn parse_radix_o(t_p0: &crate::prelude::Text, radix_p1: &crate::prelude::Nat) -> ::std::option::Option<crate::prelude::Nat> {
    'g12271: {
        if !((t_p0 != &crate::prelude::Text::lit("")) && crate::syntax::lexer::chars::all_chars_f(t_p0, &{
            let radix_p1x = radix_p1.clone();
            ::std::rc::Rc::new(move |p0: crate::prelude::Text| {
                let radix_p1xy = radix_p1x.clone();
                crate::prelude::once_job(move || {
                    let c_p2 = p0;
                    ::prism_rtl::Turn::Finished(crate::syntax::lexer::chars::is_digit_f(&c_p2) && (&crate::syntax::lexer::chars::hex_value_f(&c_p2) < &radix_p1xy))
                })
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        })) {
            break 'g12271 ::std::option::Option::None;
        }
        ::std::option::Option::Some(crate::syntax::lexer::chars::fold_chars_f(t_p0, &crate::prelude::Nat::from(0u32), &{
            let radix_p1x = radix_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Nat, crate::prelude::Text)| {
                let radix_p1xy = radix_p1x.clone();
                crate::prelude::once_job(move || {
                    let n_p3 = p0;
                    let c_p4 = p1;
                    ::prism_rtl::Turn::Finished(&(&n_p3 * &radix_p1xy) + &crate::syntax::lexer::chars::hex_value_f(&c_p4))
                })
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Nat, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Nat>>>
        }))
    }
}
