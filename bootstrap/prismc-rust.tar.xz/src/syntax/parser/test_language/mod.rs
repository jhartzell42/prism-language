//! The module `Syntax.Parser.TestLanguage`, from `target/bootstrap/src/prismc/syntax/parser/test_language.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// let deliveryWords
/// ```
pub fn delivery_words() -> Array<Text> {
    Array::from(vec![Text::lit("send"), Text::lit("click"), Text::lit("answer")])
}

/// ```prism
/// IsDeliveryWord: fn Text -> Bool
/// ```
pub fn is_delivery_word(w: &Text) -> bool {
    fold(&delivery_words(), &false, &(|seen: &bool, d: &Text| *seen || (d == w)))
}

/// ```prism
/// StepWord: fn Ps -> Text
/// ```
pub fn step_word(p_: &crate::syntax::parser::Ps) -> Text {
    match crate::syntax::parser::kind(p_) {
        crate::syntax::lexer::TokKind::KName(n) if (((&n.sigils == &Text::lit("")) && (&len(&n.path_) == &Nat::from(1u32))) && (&n.case == &crate::syntax::lexer::NameCase::CaseLower)) => or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")),
        _ => Text::lit(""),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// AtWord: fn Ps, Text -> Bool
/// ```
pub fn at_word(p_: &crate::syntax::parser::Ps, w: &Text) -> bool {
    &step_word(p_) == w
}

/// ```prism
/// ParseCheckDecl: unbounded fn Ps -> ((CheckDecl, Ps))
/// ```
pub fn parse_check_decl(p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::CheckDecl, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p0);
    let (name, p1) = crate::syntax::parser::parse_ident(&crate::syntax::parser::adv(p0));
    let p2 = crate::syntax::parser::expect_colon(&p1);
    if crate::syntax::parser::at_open_l(&p2) {
        {
            let (lines, q) = crate::syntax::parser::layout_items(&crate::syntax::parser::adv(&p2), &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_check_line(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::CheckLine, crate::syntax::parser::Ps)>>>));
            (crate::syntax::decls::CheckDecl { name: name.clone(), lines: lines.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone())
        }
    } else {
        (crate::syntax::decls::CheckDecl { name: name.clone(), lines: Array::new(), span: start.clone() }, crate::syntax::parser::error_here(&p2, &Text::lit("a `check` block's lines stand in an indented block")))
    }
}

/// The step machine of `ParseCheckDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseCheckDecl: unbounded fn Ps -> ((CheckDecl, Ps))
/// ```
pub struct ParseCheckDecl {
    pub p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::CheckDecl, crate::syntax::parser::Ps)> for ParseCheckDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::CheckDecl, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let start = crate::syntax::parser::here(p0);
        let (name, p1) = crate::syntax::parser::parse_ident(&crate::syntax::parser::adv(p0));
        let p2 = crate::syntax::parser::expect_colon(&p1);
        if crate::syntax::parser::at_open_l(&p2) {
            call_then(crate::syntax::parser::start_layout_items(crate::syntax::parser::adv(&p2), Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_check_line(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::CheckLine, crate::syntax::parser::Ps)>>>), move |layout_items_1679: (Array<crate::syntax::decls::CheckLine>, crate::syntax::parser::Ps)| {
                let (lines, q) = layout_items_1679;
                prism_rtl::Turn::Finished((crate::syntax::decls::CheckDecl { name: name.clone(), lines: lines.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone()))
            })
        } else {
            prism_rtl::Turn::Finished((crate::syntax::decls::CheckDecl { name: name.clone(), lines: Array::new(), span: start.clone() }, crate::syntax::parser::error_here(&p2, &Text::lit("a `check` block's lines stand in an indented block"))))
        }
    }
}

/// `Start ParseCheckDecl, x`: what the function value is when passed to `@Run`.
pub fn start_parse_check_decl(p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::CheckDecl, crate::syntax::parser::Ps)>> {
    Rc::new(ParseCheckDecl { p0 })
}

/// ```prism
/// ParseCheckLine: unbounded fn Ps -> ((CheckLine, Ps))
/// ```
pub fn parse_check_line(p_: &crate::syntax::parser::Ps) -> (crate::syntax::decls::CheckLine, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p_);
    let (expr, p1) = crate::syntax::parser::expr::parse_rhs_expr(p_);
    let (pattern_opt, q) = if crate::syntax::parser::at_op(&p1, &Text::lit("=>")) {
        optional_pattern_top(&crate::syntax::parser::adv(&p1))
    } else {
        (None, p1.clone())
    };
    (crate::syntax::decls::CheckLine { expr: expr.clone(), pattern: pattern_opt.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone())
}

/// The step machine of `ParseCheckLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseCheckLine: unbounded fn Ps -> ((CheckLine, Ps))
/// ```
pub struct ParseCheckLine {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::CheckLine, crate::syntax::parser::Ps)> for ParseCheckLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::CheckLine, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let start = crate::syntax::parser::here(p_);
        let p_ = p_.clone();
        call_then(crate::syntax::parser::expr::start_parse_rhs_expr(p_.clone()), move |parse_rhs_expr_2042: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
            let (expr, p1) = parse_rhs_expr_2042;
            let (pattern_opt, q) = if crate::syntax::parser::at_op(&p1, &Text::lit("=>")) {
                optional_pattern_top(&crate::syntax::parser::adv(&p1))
            } else {
                (None, p1.clone())
            };
            prism_rtl::Turn::Finished((crate::syntax::decls::CheckLine { expr: expr.clone(), pattern: pattern_opt.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone()))
        })
    }
}

/// `Start ParseCheckLine, x`: what the function value is when passed to `@Run`.
pub fn start_parse_check_line(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::CheckLine, crate::syntax::parser::Ps)>> {
    Rc::new(ParseCheckLine { p_ })
}

/// ```prism
/// OptionalPatternTop: unbounded fn Ps -> ((?Pattern, Ps))
/// ```
pub fn optional_pattern_top(p_: &crate::syntax::parser::Ps) -> (Option<crate::syntax::Pattern_>, crate::syntax::parser::Ps) {
    let (pat, q) = crate::syntax::parser::types::parse_pattern(p_, &true);
    (Some(pat.clone()), q.clone())
}

/// The step machine of `OptionalPatternTop`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptionalPatternTop: unbounded fn Ps -> ((?Pattern, Ps))
/// ```
pub struct OptionalPatternTop {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(Option<crate::syntax::Pattern_>, crate::syntax::parser::Ps)> for OptionalPatternTop {
    fn cycle(&self) -> prism_rtl::Turn<(Option<crate::syntax::Pattern_>, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let p_ = p_.clone();
        call_then(crate::syntax::parser::types::start_parse_pattern(p_.clone(), true), move |parse_pattern_2327: (crate::syntax::Pattern_, crate::syntax::parser::Ps)| {
            let (pat, q) = parse_pattern_2327;
            prism_rtl::Turn::Finished((Some(pat.clone()), q.clone()))
        })
    }
}

/// `Start OptionalPatternTop, x`: what the function value is when passed to `@Run`.
pub fn start_optional_pattern_top(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(Option<crate::syntax::Pattern_>, crate::syntax::parser::Ps)>> {
    Rc::new(OptionalPatternTop { p_ })
}

/// ```prism
/// ParseTestDecl: unbounded fn Ps -> ((TestDecl, Ps))
/// ```
pub fn parse_test_decl(p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::TestDecl, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p0);
    let (name, p1) = crate::syntax::parser::parse_ident(&crate::syntax::parser::adv(p0));
    let fallback = crate::syntax::decls::TestDecl { name: name.clone(), blueprint: crate::syntax::parser::decls::no_expr(), seed: None, steps: Array::new(), span: start.clone() };
    if !crate::syntax::parser::at_comma(&p1) {
        (fallback.clone(), crate::syntax::parser::error_here(&p1, &Text::lit("a test names its blueprint: `test name, @blueprint:`")))
    } else {
        {
            let (blueprint, p2) = crate::syntax::parser::expr::parse_arg_expr(&crate::syntax::parser::adv(&p1));
            let (seed_opt, p3) = if crate::syntax::parser::at_comma(&p2) {
                parse_seed(&crate::syntax::parser::adv(&p2))
            } else {
                (None, p2.clone())
            };
            let p4 = crate::syntax::parser::expect_colon(&p3);
            if crate::syntax::parser::at_open_l(&p4) {
                {
                    let saved = p4.step_mode;
                    let (steps, p5) = crate::syntax::parser::layout_items(&crate::syntax::parser::adv(&p4), &{
                        let saved = saved;
                        Rc::new(move |p0: crate::syntax::parser::Ps| {
                            let saved = saved;
                            entered(once_job(move || {
                                let s = p0;
                                prism_rtl::Turn::More(Rc::new(StepIn { p_: s.clone(), saved }))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TestStep, crate::syntax::parser::Ps)>>>
                    });
                    let q = crate::syntax::parser::with_step_mode(&p5, &saved);
                    (crate::syntax::decls::TestDecl { name: name.clone(), blueprint: blueprint.clone(), seed: seed_opt.clone(), steps: steps.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone())
                }
            } else {
                (fallback.clone(), crate::syntax::parser::error_here(&p4, &Text::lit("a test's steps stand in an indented block")))
            }
        }
    }
}

/// The step machine of `ParseTestDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTestDecl: unbounded fn Ps -> ((TestDecl, Ps))
/// ```
pub struct ParseTestDecl {
    pub p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::TestDecl, crate::syntax::parser::Ps)> for ParseTestDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::TestDecl, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let start = crate::syntax::parser::here(p0);
        let (name, p1) = crate::syntax::parser::parse_ident(&crate::syntax::parser::adv(p0));
        let fallback = crate::syntax::decls::TestDecl { name: name.clone(), blueprint: crate::syntax::parser::decls::no_expr(), seed: None, steps: Array::new(), span: start.clone() };
        if !crate::syntax::parser::at_comma(&p1) {
            prism_rtl::Turn::Finished((fallback.clone(), crate::syntax::parser::error_here(&p1, &Text::lit("a test names its blueprint: `test name, @blueprint:`"))))
        } else {
            call_then(crate::syntax::parser::expr::start_parse_arg_expr(crate::syntax::parser::adv(&p1)), move |parse_arg_expr_2820: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                let (blueprint, p2) = parse_arg_expr_2820;
                let (seed_opt, p3) = if crate::syntax::parser::at_comma(&p2) {
                    parse_seed(&crate::syntax::parser::adv(&p2))
                } else {
                    (None, p2.clone())
                };
                let p4 = crate::syntax::parser::expect_colon(&p3);
                if crate::syntax::parser::at_open_l(&p4) {
                    {
                        let saved = p4.step_mode;
                        call_then(crate::syntax::parser::start_layout_items(crate::syntax::parser::adv(&p4), {
                            let saved = saved;
                            Rc::new(move |p0: crate::syntax::parser::Ps| {
                                let saved = saved;
                                entered(once_job(move || {
                                    let s = p0;
                                    prism_rtl::Turn::More(Rc::new(StepIn { p_: s.clone(), saved }))
                                }))
                            }) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TestStep, crate::syntax::parser::Ps)>>>
                        }), move |layout_items_3045: (Array<crate::syntax::decls::TestStep>, crate::syntax::parser::Ps)| {
                            let (steps, p5) = layout_items_3045;
                            let q = crate::syntax::parser::with_step_mode(&p5, &saved);
                            prism_rtl::Turn::Finished((crate::syntax::decls::TestDecl { name: name.clone(), blueprint: blueprint.clone(), seed: seed_opt.clone(), steps: steps.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone()))
                        })
                    }
                } else {
                    prism_rtl::Turn::Finished((fallback.clone(), crate::syntax::parser::error_here(&p4, &Text::lit("a test's steps stand in an indented block"))))
                }
            })
        }
    }
}

/// `Start ParseTestDecl, x`: what the function value is when passed to `@Run`.
pub fn start_parse_test_decl(p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TestDecl, crate::syntax::parser::Ps)>> {
    Rc::new(ParseTestDecl { p0 })
}

/// ```prism
/// ParseSeed: fn Ps -> ((?Nat, Ps))
/// ```
pub fn parse_seed(p_: &crate::syntax::parser::Ps) -> (Option<Nat>, crate::syntax::parser::Ps) {
    if !at_word(p_, &Text::lit("seed")) {
        (None, crate::syntax::parser::error_here(p_, &Text::lit("after the blueprint, a test takes only `seed n`")))
    } else {
        {
            let p1 = crate::syntax::parser::adv(p_);
            match crate::syntax::parser::kind(&p1) {
                crate::syntax::lexer::TokKind::KInt(m3527_0_0, text) if (&m3527_0_0 == &Text::lit("")) => (Some(parse_nat_text(&text)), crate::syntax::parser::adv(&p1)),
                _ => (None, crate::syntax::parser::error_here(&p1, &Text::lit("`seed` takes a number"))),
                _ => unreachable!("no arm matched"),
            }
        }
    }
}

/// ```prism
/// StepIn: unbounded fn Ps, Bool -> ((TestStep, Ps))
/// ```
pub fn step_in(p_: &crate::syntax::parser::Ps, saved: &bool) -> (crate::syntax::decls::TestStep, crate::syntax::parser::Ps) {
    let (s, q) = parse_step(&crate::syntax::parser::with_step_mode(p_, &true));
    (s.clone(), crate::syntax::parser::with_step_mode(&q, saved))
}

/// The step machine of `StepIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StepIn: unbounded fn Ps, Bool -> ((TestStep, Ps))
/// ```
pub struct StepIn {
    pub p_: crate::syntax::parser::Ps,
    pub saved: bool,
}

impl prism_rtl::Job<(crate::syntax::decls::TestStep, crate::syntax::parser::Ps)> for StepIn {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::TestStep, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let saved = &self.saved;
        let (s, q) = parse_step(&crate::syntax::parser::with_step_mode(p_, &true));
        prism_rtl::Turn::Finished((s.clone(), crate::syntax::parser::with_step_mode(&q, saved)))
    }
}

/// `Start StepIn, x`: what the function value is when passed to `@Run`.
pub fn start_step_in(p_: crate::syntax::parser::Ps, saved: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TestStep, crate::syntax::parser::Ps)>> {
    Rc::new(StepIn { p_, saved })
}

/// ```prism
/// ParseStep: unbounded fn Ps -> ((TestStep, Ps))
/// ```
pub fn parse_step(p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::TestStep, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p0);
    let (withs, p1) = with_entries(p0);
    let (action, p2) = step_action_of(&p1, &withs);
    if p2.bad {
        (crate::syntax::decls::TestStep { withs: withs.clone(), action: action.clone(), checks: Array::new(), span: start.clone() }, p2.clone())
    } else {
        if crate::syntax::parser::at_open_l(&p2) {
            {
                let (checks, q) = crate::syntax::parser::layout_items(&crate::syntax::parser::adv(&p2), &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_test_check(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TestCheck, crate::syntax::parser::Ps)>>>));
                (crate::syntax::decls::TestStep { withs: withs.clone(), action: action.clone(), checks: checks.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone())
            }
        } else {
            if crate::syntax::parser::at_comma(&p2) {
                (crate::syntax::decls::TestStep { withs: withs.clone(), action: action.clone(), checks: Array::new(), span: start.clone() }, crate::syntax::parser::error_at(&p2, &crate::syntax::parser::here(&p2), &Text::lit("a comma in a step begins a delivery; a value with commas in it is written in parentheses")))
            } else {
                (crate::syntax::decls::TestStep { withs: withs.clone(), action: action.clone(), checks: Array::new(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p2)) }, p2.clone())
            }
        }
    }
}

/// ```prism
/// WithEntries: unbounded fn Ps -> (([Entry], Ps))
/// ```
pub fn with_entries(p0: &crate::syntax::parser::Ps) -> (Array<crate::syntax::decls::Entry>, crate::syntax::parser::Ps) {
    let mut this: (Array<crate::syntax::decls::Entry>, crate::syntax::parser::Ps) = (Array::new(), p0.clone());
    let mut withs: Array<crate::syntax::decls::Entry> = Array::new();
    let mut p_: crate::syntax::parser::Ps = p0.clone();
    let mut going: bool = at_word(p0, &Text::lit("with"));
    while going && !p_.bad {
        let (e, q) = parse_entry(&crate::syntax::parser::adv(&p_));
        withs = push(&withs, &e);
        if crate::syntax::parser::at_comma(&q) {
            p_ = crate::syntax::parser::adv(&q);
            going = at_word(&p_, &Text::lit("with"));
        } else {
            p_ = q.clone();
            going = false;
        }
    }
    this = (withs.clone(), p_.clone());
    this
}

/// ```prism
/// StepActionOf: unbounded fn Ps, [Entry] -> ((StepAction, Ps))
/// ```
pub fn step_action_of(p_: &crate::syntax::parser::Ps, withs: &Array<crate::syntax::decls::Entry>) -> (crate::syntax::decls::StepAction, crate::syntax::parser::Ps) {
    let w = step_word(p_);
    match &w {
        m5346_0 if (m5346_0 == &Text::lit("build")) => (crate::syntax::decls::StepAction::SaBuild, crate::syntax::parser::adv(p_)),
        m5346_1 if (m5346_1 == &Text::lit("tick")) => (crate::syntax::decls::StepAction::SaTick, crate::syntax::parser::adv(p_)),
        m5346_2 if (m5346_2 == &Text::lit("compute")) => {
            let p1 = crate::syntax::parser::adv(p_);
            if at_word(&p1, &Text::lit("until")) {
                {
                    let p2 = crate::syntax::parser::adv(&p1);
                    if at_word(&p2, &Text::lit("idle")) {
                        (crate::syntax::decls::StepAction::SaCompute(true), crate::syntax::parser::adv(&p2))
                    } else {
                        (crate::syntax::decls::StepAction::SaCompute(true), crate::syntax::parser::error_here(&p2, &Text::lit("`compute until` is followed by `idle`")))
                    }
                }
            } else {
                (crate::syntax::decls::StepAction::SaCompute(false), p1.clone())
            }
        },
        m5346_3 if (m5346_3 == &Text::lit("push")) => {
            let (e, q) = parse_entry(&crate::syntax::parser::adv(p_));
            (crate::syntax::decls::StepAction::SaPush(e.clone()), q.clone())
        },
        _ if is_delivery_word(&w) => deliveries(p_),
        _ if ((&len(withs) > &Nat::from(0u32)) && (crate::syntax::parser::at_open_l(p_) || crate::syntax::parser::at_stmt_boundary(p_))) => (crate::syntax::decls::StepAction::SaWithOnly, p_.clone()),
        _ => (crate::syntax::decls::StepAction::SaBuild, crate::syntax::parser::error_here(p_, &Text::lit("expected a step: `build`, `tick`, `compute`, `send`, `click`, `answer`, `with` or `push`"))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Deliveries: unbounded fn Ps -> ((StepAction, Ps))
/// ```
pub fn deliveries(p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::StepAction, crate::syntax::parser::Ps) {
    let mut this: (crate::syntax::decls::StepAction, crate::syntax::parser::Ps) = (crate::syntax::decls::StepAction::SaBuild, p0.clone());
    let (first_, p1) = parse_delivery(p0);
    let mut ds: Array<crate::syntax::decls::Delivery> = Array::from(vec![first_.clone()]);
    let mut p_: crate::syntax::parser::Ps = p1.clone();
    while crate::syntax::parser::at_comma(&p_) && !p_.bad {
        if is_delivery_name(&crate::syntax::parser::kind_at(&p_, &Nat::from(1u32))) {
            let (d, q) = parse_delivery(&crate::syntax::parser::adv(&p_));
            ds = push(&ds, &d);
            p_ = q.clone();
        } else {
            p_ = crate::syntax::parser::error_at(&p_, &crate::syntax::parser::here(&p_), &Text::lit("a comma in a step begins a delivery (`click p, click q`); a value with commas in it is written in parentheses: `send p, (Min a, b)`"));
        }
    }
    this = (crate::syntax::decls::StepAction::SaDeliver(ds.clone()), p_.clone());
    this
}

/// ```prism
/// IsDeliveryName: fn TokKind -> Bool
/// ```
pub fn is_delivery_name(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KName(n) => (&len(&n.path_) == &Nat::from(1u32)) && is_delivery_word(&or(&index(&n.path_, &Nat::from(0u32)), &Text::lit(""))),
        _ => false,
    }
}

/// ```prism
/// ParseEntry: unbounded fn Ps -> ((Entry, Ps))
/// ```
pub fn parse_entry(p_: &crate::syntax::parser::Ps) -> (crate::syntax::decls::Entry, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p_);
    let (element_, p1) = crate::syntax::parser::expr::parse_arg_expr(p_);
    let (value, q) = crate::syntax::parser::expr::parse_arg_expr(&crate::syntax::parser::expect_op(&p1, &Text::lit("=")));
    (crate::syntax::decls::Entry { element: element_.clone(), value: value.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone())
}

/// ```prism
/// ParseDelivery: unbounded fn Ps -> ((Delivery, Ps))
/// ```
pub fn parse_delivery(p_: &crate::syntax::parser::Ps) -> (crate::syntax::decls::Delivery, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p_);
    let word = step_word(p_);
    let (target, p1) = parse_target(&crate::syntax::parser::adv(p_));
    let (kind, q) = if &word == &Text::lit("send") {
        send_value(&p1)
    } else {
        if &word == &Text::lit("click") {
            (crate::syntax::decls::DeliveryKind::DkClick, p1.clone())
        } else {
            (crate::syntax::decls::DeliveryKind::DkAnswer, p1.clone())
        }
    };
    (crate::syntax::decls::Delivery { kind: kind.clone(), target: target.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone())
}

/// ```prism
/// SendValue: unbounded fn Ps -> ((DeliveryKind, Ps))
/// ```
pub fn send_value(p_: &crate::syntax::parser::Ps) -> (crate::syntax::decls::DeliveryKind, crate::syntax::parser::Ps) {
    if crate::syntax::parser::at_comma(p_) {
        {
            let (v_, q) = crate::syntax::parser::expr::parse_arg_expr(&crate::syntax::parser::adv(p_));
            (crate::syntax::decls::DeliveryKind::DkSend(v_.clone()), q.clone())
        }
    } else {
        (crate::syntax::decls::DeliveryKind::DkClick, crate::syntax::parser::error_here(p_, &Text::lit("`send` takes a target and a value: `send p, v`")))
    }
}

/// ```prism
/// ParseTarget: unbounded fn Ps -> ((Target, Ps))
/// ```
pub fn parse_target(p_: &crate::syntax::parser::Ps) -> (crate::syntax::decls::Target, crate::syntax::parser::Ps) {
    let element_ = at_word(p_, &Text::lit("element")) && is_path_kind(&crate::syntax::parser::kind_at(p_, &Nat::from(1u32)));
    if at_word(p_, &Text::lit("at")) || element_ {
        {
            let p1 = crate::syntax::parser::adv(p_);
            match crate::syntax::parser::kind(&p1) {
                crate::syntax::lexer::TokKind::KPath(segs) => {
                    let span = crate::syntax::parser::here(&p1);
                    let (segments, q) = run_to_end(fold_job(segs.clone(), (Array::new(), crate::syntax::parser::adv(&p1)), {
                        let span = span.clone();
                        Rc::new(move |(p0, p1): ((Array<crate::syntax::decls::PathSeg>, crate::syntax::parser::Ps), crate::syntax::lexer::PathSegTok)| {
                            let span = span.clone();
                            entered(once_job(move || {
                                let (acc, pp) = p0;
                                let seg = p1;
                                prism_rtl::Turn::Finished(path_seg_of(&acc, &pp, &seg, &span))
                            }))
                        }) as Rc<dyn Fn(((Array<crate::syntax::decls::PathSeg>, crate::syntax::parser::Ps), crate::syntax::lexer::PathSegTok)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::decls::PathSeg>, crate::syntax::parser::Ps)>>>
                    }));
                    let path_ = crate::syntax::decls::TestPath { segments: segments.clone(), span: span.clone() };
                    if element_ {
                        (crate::syntax::decls::Target::TgElement(path_.clone()), q.clone())
                    } else {
                        (crate::syntax::decls::Target::TgPath(path_.clone()), q.clone())
                    }
                },
                _ => (crate::syntax::decls::Target::TgPattern(crate::syntax::parser::decls::no_pattern()), crate::syntax::parser::error_here(&p1, &Text::lit("`at` takes a path, `1/#0/0`"))),
            }
        }
    } else {
        {
            let (pat, q) = crate::syntax::parser::types::parse_pattern(p_, &false);
            (crate::syntax::decls::Target::TgPattern(pat.clone()), q.clone())
        }
    }
}

/// ```prism
/// IsPathKind: fn TokKind -> Bool
/// ```
pub fn is_path_kind(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KPath(_) => true,
        _ => false,
    }
}

/// ```prism
/// PathSegOf: unbounded fn [PathSeg], Ps, PathSegTok, Range -> (([PathSeg], Ps))
/// ```
pub fn path_seg_of(acc: &Array<crate::syntax::decls::PathSeg>, p_: &crate::syntax::parser::Ps, path_seg_tok2: &crate::syntax::lexer::PathSegTok, range3: &crate::syntax::Range) -> (Array<crate::syntax::decls::PathSeg>, crate::syntax::parser::Ps) {
    match (path_seg_tok2, range3) {
        (crate::syntax::lexer::PathSegTok::PstNum(n), _) => (push(acc, &crate::syntax::decls::PathSeg::PsNum(n.clone())), p_.clone()),
        (crate::syntax::lexer::PathSegTok::PstGen(n), _) => (push(acc, &crate::syntax::decls::PathSeg::PsGen(n.clone())), p_.clone()),
        (crate::syntax::lexer::PathSegTok::PstKey(toks), span) => {
            let (e, q) = crate::syntax::parser::expr::parse_nested(p_, toks, span);
            (push(acc, &crate::syntax::decls::PathSeg::PsKey(e.clone())), q.clone())
        },
    }
}

/// ```prism
/// ParseTestCheck: unbounded fn Ps -> ((TestCheck, Ps))
/// ```
pub fn parse_test_check(p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::TestCheck, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p0);
    let p_ = crate::syntax::parser::expect_op(p0, &Text::lit("=>"));
    let word = step_word(&p_);
    if p_.bad {
        (crate::syntax::decls::TestCheck { kind: crate::syntax::decls::TestCheckKind::CkQuiet, span: start.clone() }, p_.clone())
    } else {
        if &word == &Text::lit("") {
            (crate::syntax::decls::TestCheck { kind: crate::syntax::decls::TestCheckKind::CkQuiet, span: start.clone() }, crate::syntax::parser::error_here(&p_, &Text::lit("expected a check after `=>`: `expect`, `returns`, `fired`, `quiet`, ...")))
        } else {
            {
                let (kind, q) = check_kind_of(&crate::syntax::parser::adv(&p_), &word);
                (crate::syntax::decls::TestCheck { kind: kind.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone())
            }
        }
    }
}

/// The step machine of `ParseTestCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTestCheck: unbounded fn Ps -> ((TestCheck, Ps))
/// ```
pub struct ParseTestCheck {
    pub p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::TestCheck, crate::syntax::parser::Ps)> for ParseTestCheck {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::TestCheck, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let start = crate::syntax::parser::here(p0);
        let p_ = crate::syntax::parser::expect_op(p0, &Text::lit("=>"));
        let word = step_word(&p_);
        if p_.bad {
            prism_rtl::Turn::Finished((crate::syntax::decls::TestCheck { kind: crate::syntax::decls::TestCheckKind::CkQuiet, span: start.clone() }, p_.clone()))
        } else {
            if &word == &Text::lit("") {
                prism_rtl::Turn::Finished((crate::syntax::decls::TestCheck { kind: crate::syntax::decls::TestCheckKind::CkQuiet, span: start.clone() }, crate::syntax::parser::error_here(&p_, &Text::lit("expected a check after `=>`: `expect`, `returns`, `fired`, `quiet`, ..."))))
            } else {
                call_then(start_check_kind_of(crate::syntax::parser::adv(&p_), word.clone()), move |check_kind_of_9526: (crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps)| {
                    let (kind, q) = check_kind_of_9526;
                    prism_rtl::Turn::Finished((crate::syntax::decls::TestCheck { kind: kind.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone()))
                })
            }
        }
    }
}

/// `Start ParseTestCheck, x`: what the function value is when passed to `@Run`.
pub fn start_parse_test_check(p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TestCheck, crate::syntax::parser::Ps)>> {
    Rc::new(ParseTestCheck { p0 })
}

/// ```prism
/// CheckKindOf: unbounded fn Ps, Text -> ((TestCheckKind, Ps))
/// ```
pub fn check_kind_of(p_: &crate::syntax::parser::Ps, word: &Text) -> (crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps) {
    match word {
        m9701_0 if (m9701_0 == &Text::lit("expect")) => one_pattern(p_, &{
            let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkExpect(a0.clone()));
            Rc::new(move |a0: crate::syntax::Pattern_| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
        }),
        m9701_1 if (m9701_1 == &Text::lit("expect_none")) => one_pattern(p_, &{
            let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkExpectNone(a0.clone()));
            Rc::new(move |a0: crate::syntax::Pattern_| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
        }),
        m9701_2 if (m9701_2 == &Text::lit("expect_top")) => one_pattern(p_, &{
            let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkExpectTop(a0.clone()));
            Rc::new(move |a0: crate::syntax::Pattern_| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
        }),
        m9701_3 if (m9701_3 == &Text::lit("expect_top_none")) => one_pattern(p_, &{
            let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkExpectTopNone(a0.clone()));
            Rc::new(move |a0: crate::syntax::Pattern_| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
        }),
        m9701_4 if (m9701_4 == &Text::lit("unrequested")) => one_pattern(p_, &{
            let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkUnrequested(a0.clone()));
            Rc::new(move |a0: crate::syntax::Pattern_| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
        }),
        m9701_5 if (m9701_5 == &Text::lit("returns")) => one_pattern(p_, &{
            let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkReturns(a0.clone()));
            Rc::new(move |a0: crate::syntax::Pattern_| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
        }),
        m9701_6 if (m9701_6 == &Text::lit("fired")) => one_pattern(p_, &{
            let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkFired(a0.clone()));
            Rc::new(move |a0: crate::syntax::Pattern_| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
        }),
        m9701_7 if (m9701_7 == &Text::lit("expect_count")) => {
            let (pat, p1) = crate::syntax::parser::types::parse_pattern(p_, &false);
            if !crate::syntax::parser::at_comma(&p1) {
                (crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_here(&p1, &Text::lit("`expect_count` takes a pattern and a count: `expect_count p, n`")))
            } else {
                {
                    let p2 = crate::syntax::parser::adv(&p1);
                    match crate::syntax::parser::kind(&p2) {
                        crate::syntax::lexer::TokKind::KInt(m10260_0_0, text) if (&m10260_0_0 == &Text::lit("")) => (crate::syntax::decls::TestCheckKind::CkExpectCount(pat.clone(), parse_nat_text(&text)), crate::syntax::parser::adv(&p2)),
                        _ => (crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_here(&p2, &Text::lit("`expect_count` takes a number"))),
                        _ => unreachable!("no arm matched"),
                    }
                }
            }
        },
        m9701_8 if (m9701_8 == &Text::lit("requested")) => {
            let (place, p1) = crate::syntax::parser::types::parse_pattern(p_, &false);
            if !crate::syntax::parser::at_comma(&p1) {
                (crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_here(&p1, &Text::lit("`requested` takes a place and a value: `requested p, v`")))
            } else {
                {
                    let (value, q) = crate::syntax::parser::types::parse_pattern(&crate::syntax::parser::adv(&p1), &false);
                    (crate::syntax::decls::TestCheckKind::CkRequested(place.clone(), value.clone()), q.clone())
                }
            }
        },
        m9701_9 if (m9701_9 == &Text::lit("quiet")) => (crate::syntax::decls::TestCheckKind::CkQuiet, p_.clone()),
        m9701_10 if (m9701_10 == &Text::lit("settles")) => (crate::syntax::decls::TestCheckKind::CkSettles, p_.clone()),
        m9701_11 if (m9701_11 == &Text::lit("aborted")) => (crate::syntax::decls::TestCheckKind::CkAborted, p_.clone()),
        m9701_12 if (m9701_12 == &Text::lit("snapshot")) => match crate::syntax::parser::kind(p_) {
            crate::syntax::lexer::TokKind::KText(m10860_0_0, segs) if (&m10860_0_0 == &Text::lit("")) && all_plain(&segs) => (crate::syntax::decls::TestCheckKind::CkSnapshot(concat(&each(&segs, &plain_of))), crate::syntax::parser::adv(p_)),
            _ => (crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_here(p_, &Text::lit("`snapshot` takes a file name, a text literal"))),
            _ => unreachable!("no arm matched"),
        },
        _ => (crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_at(p_, &crate::syntax::parser::prev(p_), &Text::from(format!("`{}` is not a check: the checks are expect, expect_none, expect_count, expect_top, expect_top_none, requested, unrequested, returns, fired, quiet, settles, aborted, snapshot", word)))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CheckKindOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckKindOf: unbounded fn Ps, Text -> ((TestCheckKind, Ps))
/// ```
pub struct CheckKindOf {
    pub p_: crate::syntax::parser::Ps,
    pub word: Text,
}

impl prism_rtl::Job<(crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps)> for CheckKindOf {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let word = &self.word;
        match word {
            m9701_0 if (m9701_0 == &Text::lit("expect")) => prism_rtl::Turn::More(Rc::new(OnePattern { p_: p_.clone(), make_fn: {
                let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkExpect(a0.clone()));
                Rc::new(move |a0: crate::syntax::Pattern_| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
            } })),
            m9701_1 if (m9701_1 == &Text::lit("expect_none")) => prism_rtl::Turn::More(Rc::new(OnePattern { p_: p_.clone(), make_fn: {
                let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkExpectNone(a0.clone()));
                Rc::new(move |a0: crate::syntax::Pattern_| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
            } })),
            m9701_2 if (m9701_2 == &Text::lit("expect_top")) => prism_rtl::Turn::More(Rc::new(OnePattern { p_: p_.clone(), make_fn: {
                let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkExpectTop(a0.clone()));
                Rc::new(move |a0: crate::syntax::Pattern_| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
            } })),
            m9701_3 if (m9701_3 == &Text::lit("expect_top_none")) => prism_rtl::Turn::More(Rc::new(OnePattern { p_: p_.clone(), make_fn: {
                let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkExpectTopNone(a0.clone()));
                Rc::new(move |a0: crate::syntax::Pattern_| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
            } })),
            m9701_4 if (m9701_4 == &Text::lit("unrequested")) => prism_rtl::Turn::More(Rc::new(OnePattern { p_: p_.clone(), make_fn: {
                let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkUnrequested(a0.clone()));
                Rc::new(move |a0: crate::syntax::Pattern_| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
            } })),
            m9701_5 if (m9701_5 == &Text::lit("returns")) => prism_rtl::Turn::More(Rc::new(OnePattern { p_: p_.clone(), make_fn: {
                let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkReturns(a0.clone()));
                Rc::new(move |a0: crate::syntax::Pattern_| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
            } })),
            m9701_6 if (m9701_6 == &Text::lit("fired")) => prism_rtl::Turn::More(Rc::new(OnePattern { p_: p_.clone(), make_fn: {
                let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::decls::TestCheckKind::CkFired(a0.clone()));
                Rc::new(move |a0: crate::syntax::Pattern_| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>
            } })),
            m9701_7 if (m9701_7 == &Text::lit("expect_count")) => {
                let p_ = p_.clone();
                call_then(crate::syntax::parser::types::start_parse_pattern(p_.clone(), false), move |parse_pattern_10060: (crate::syntax::Pattern_, crate::syntax::parser::Ps)| {
                    let (pat, p1) = parse_pattern_10060;
                    if !crate::syntax::parser::at_comma(&p1) {
                        prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_here(&p1, &Text::lit("`expect_count` takes a pattern and a count: `expect_count p, n`"))))
                    } else {
                        {
                            let p2 = crate::syntax::parser::adv(&p1);
                            match crate::syntax::parser::kind(&p2) {
                                crate::syntax::lexer::TokKind::KInt(m10260_0_0, text) if (&m10260_0_0 == &Text::lit("")) => prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkExpectCount(pat.clone(), parse_nat_text(&text)), crate::syntax::parser::adv(&p2))),
                                _ => prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_here(&p2, &Text::lit("`expect_count` takes a number")))),
                                _ => unreachable!("no arm matched"),
                            }
                        }
                    }
                })
            },
            m9701_8 if (m9701_8 == &Text::lit("requested")) => {
                let p_ = p_.clone();
                call_then(crate::syntax::parser::types::start_parse_pattern(p_.clone(), false), move |parse_pattern_10494: (crate::syntax::Pattern_, crate::syntax::parser::Ps)| {
                    let (place, p1) = parse_pattern_10494;
                    if !crate::syntax::parser::at_comma(&p1) {
                        prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_here(&p1, &Text::lit("`requested` takes a place and a value: `requested p, v`"))))
                    } else {
                        call_then(crate::syntax::parser::types::start_parse_pattern(crate::syntax::parser::adv(&p1), false), move |parse_pattern_10677: (crate::syntax::Pattern_, crate::syntax::parser::Ps)| {
                            let (value, q) = parse_pattern_10677;
                            prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkRequested(place.clone(), value.clone()), q.clone()))
                        })
                    }
                })
            },
            m9701_9 if (m9701_9 == &Text::lit("quiet")) => prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkQuiet, p_.clone())),
            m9701_10 if (m9701_10 == &Text::lit("settles")) => prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkSettles, p_.clone())),
            m9701_11 if (m9701_11 == &Text::lit("aborted")) => prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkAborted, p_.clone())),
            m9701_12 if (m9701_12 == &Text::lit("snapshot")) => match crate::syntax::parser::kind(p_) {
                crate::syntax::lexer::TokKind::KText(m10860_0_0, segs) if (&m10860_0_0 == &Text::lit("")) && all_plain(&segs) => prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkSnapshot(concat(&each(&segs, &plain_of))), crate::syntax::parser::adv(p_))),
                _ => prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_here(p_, &Text::lit("`snapshot` takes a file name, a text literal")))),
                _ => unreachable!("no arm matched"),
            },
            _ => prism_rtl::Turn::Finished((crate::syntax::decls::TestCheckKind::CkQuiet, crate::syntax::parser::error_at(p_, &crate::syntax::parser::prev(p_), &Text::from(format!("`{}` is not a check: the checks are expect, expect_none, expect_count, expect_top, expect_top_none, requested, unrequested, returns, fired, quiet, settles, aborted, snapshot", word))))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start CheckKindOf, x`: what the function value is when passed to `@Run`.
pub fn start_check_kind_of(p_: crate::syntax::parser::Ps, word: Text) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps)>> {
    Rc::new(CheckKindOf { p_, word })
}

/// ```prism
/// OnePattern: unbounded fn Ps, (fn Pattern -> TestCheckKind) -> ((TestCheckKind, Ps))
/// ```
pub fn one_pattern(p_: &crate::syntax::parser::Ps, make_fn: &Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>) -> (crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps) {
    let (pat, q) = crate::syntax::parser::types::parse_pattern(p_, &false);
    (run_to_end(make_fn(pat.clone())), q.clone())
}

/// The step machine of `OnePattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OnePattern: unbounded fn Ps, (fn Pattern -> TestCheckKind) -> ((TestCheckKind, Ps))
/// ```
pub struct OnePattern {
    pub p_: crate::syntax::parser::Ps,
    pub make_fn: Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>,
}

impl prism_rtl::Job<(crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps)> for OnePattern {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let make_fn = &self.make_fn;
        let make_fn = make_fn.clone();
        let p_ = p_.clone();
        call_then(crate::syntax::parser::types::start_parse_pattern(p_.clone(), false), move |parse_pattern_11423: (crate::syntax::Pattern_, crate::syntax::parser::Ps)| {
            let (pat, q) = parse_pattern_11423;
            call_value((&make_fn)(pat.clone()), move |make_11451: crate::syntax::decls::TestCheckKind| prism_rtl::Turn::Finished((make_11451, q.clone())))
        })
    }
}

/// `Start OnePattern, x`: what the function value is when passed to `@Run`.
pub fn start_one_pattern(p_: crate::syntax::parser::Ps, make_fn: Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::decls::TestCheckKind>>>) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TestCheckKind, crate::syntax::parser::Ps)>> {
    Rc::new(OnePattern { p_, make_fn })
}

/// ```prism
/// AllPlain: fn [TextSegTok] -> Bool
/// ```
pub fn all_plain(segs: &Array<crate::syntax::lexer::TextSegTok>) -> bool {
    fold(segs, &true, &(|ok: &bool, s: &crate::syntax::lexer::TextSegTok| *ok && is_plain_seg(s)))
}

/// ```prism
/// IsPlainSeg: fn TextSegTok -> Bool
/// ```
pub fn is_plain_seg(text_seg_tok0: &crate::syntax::lexer::TextSegTok) -> bool {
    match text_seg_tok0 {
        crate::syntax::lexer::TextSegTok::TsPlain(_) => true,
        _ => false,
    }
}

/// ```prism
/// PlainOf: fn TextSegTok -> Text
/// ```
pub fn plain_of(text_seg_tok0: &crate::syntax::lexer::TextSegTok) -> Text {
    match text_seg_tok0 {
        crate::syntax::lexer::TextSegTok::TsPlain(s) => s.clone(),
        _ => Text::lit(""),
    }
}

/// ```prism
/// ParseNatText: fn Text -> Nat
/// ```
pub fn parse_nat_text(text0: &Text) -> Nat {
    let text = concat(&split_on(text0, &Text::lit("_")));
    if crate::syntax::lexer::chars::has_prefix(&text, &Text::lit("0x")) {
        or(&crate::syntax::lexer::chars::parse_hex(&crate::syntax::lexer::chars::drop_prefix(&text, &Text::lit("0x"))), &Nat::from(0u32))
    } else {
        if crate::syntax::lexer::chars::has_prefix(&text, &Text::lit("0o")) {
            or(&parse_radix(&crate::syntax::lexer::chars::drop_prefix(&text, &Text::lit("0o")), &Nat::from(8u32)), &Nat::from(0u32))
        } else {
            if crate::syntax::lexer::chars::has_prefix(&text, &Text::lit("0b")) {
                or(&parse_radix(&crate::syntax::lexer::chars::drop_prefix(&text, &Text::lit("0b")), &Nat::from(2u32)), &Nat::from(0u32))
            } else {
                or(&parse_nat_opt(&text), &Nat::from(0u32))
            }
        }
    }
}

/// ```prism
/// ?ParseRadix: fn Text, Nat -> ?Nat
/// ```
pub fn parse_radix(t: &Text, radix: &Nat) -> Option<Nat> {
    'g12268: {
        if !((t != &Text::lit("")) && crate::syntax::lexer::chars::all_chars(t, &{
            let radix = radix.clone();
            Rc::new(move |p0: Text| {
                let radix = radix.clone();
                once_job(move || {
                    let c = p0;
                    prism_rtl::Turn::Finished(crate::syntax::lexer::chars::is_digit(&c) && (&crate::syntax::lexer::chars::hex_value(&c) < &radix))
                })
            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
        })) {
            break 'g12268 None;
        }
        Some(crate::syntax::lexer::chars::fold_chars(t, &Nat::from(0u32), &{
            let radix = radix.clone();
            Rc::new(move |(p0, p1): (Nat, Text)| {
                let radix = radix.clone();
                once_job(move || {
                    let n = p0;
                    let c = p1;
                    prism_rtl::Turn::Finished(&(&n * &radix) + &crate::syntax::lexer::chars::hex_value(&c))
                })
            }) as Rc<dyn Fn((Nat, Text)) -> Rc<dyn prism_rtl::Job<Nat>>>
        }))
    }
}
