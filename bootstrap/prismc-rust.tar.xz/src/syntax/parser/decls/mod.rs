//! The module `Syntax.Parser.Decls`, from `target/bootstrap/src/prismc/syntax/parser/decls.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `ModRead`:
///
/// ```prism
/// type ModRead = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ModRead {
    pub p_: crate::syntax::parser::Ps,
    pub m: crate::syntax::Module,
    pub stage: Nat,
}

impl Show for ModRead {
    fn show(&self, p: &mut Printer) {
        p.record("ModRead", &[("p", &self.p_), ("m", &self.m), ("stage", &self.stage)]);
    }
}

impl ToPod for ModRead {
    fn to_pod(&self) -> Pod {
        Pod::record("ModRead", vec![("p", self.p_.to_pod()), ("m", self.m.to_pod()), ("stage", self.stage.to_pod())])
    }
}

impl FromPod for ModRead {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ModRead { p_: FromPod::from_pod(field(p, "p")?)?, m: FromPod::from_pod(field(p, "m")?)?, stage: FromPod::from_pod(field(p, "stage")?)? })
    }
}

/// ```prism
/// ParseModule: unbounded fn Ps, Bool -> ((Module, Ps))
/// ```
pub fn parse_module(p0: &crate::syntax::parser::Ps, fragment: &bool) -> (crate::syntax::Module, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p0);
    let (template_opt, p1) = match crate::syntax::parser::kind(p0) {
        crate::syntax::lexer::TokKind::KTemplate(t) => {
            let (tpl, q) = crate::syntax::parser::expr::parse_template(&crate::syntax::parser::adv(p0), &t, &crate::syntax::parser::here(p0));
            (Some(tpl.clone()), q.clone())
        },
        _ => (None, p0.clone()),
    };
    let m0 = crate::syntax::Module { name: None, emit_row: None, mods: Array::new(), uses: Array::new(), decls: Array::new(), template: template_opt.clone(), span: start.clone() };
    let r = {
        let mut this: ModRead = ModRead { p_: p1.clone(), m: m0.clone(), stage: Nat::from(0u32) };
        while !crate::syntax::parser::at_eof(&this.p_) {
            this = module_item(&this, fragment);
        }
        this
    };
    let m = {
        let mut this: crate::syntax::Module = r.m.clone();
        this.span = crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&r.p_));
        this
    };
    (m.clone(), r.p_.clone())
}

/// The step machine of `ParseModule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseModule: unbounded fn Ps, Bool -> ((Module, Ps))
/// ```
pub struct ParseModule {
    pub p0: crate::syntax::parser::Ps,
    pub fragment: bool,
}

impl prism_rtl::Job<(crate::syntax::Module, crate::syntax::parser::Ps)> for ParseModule {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Module, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let fragment = &self.fragment;
        let start = crate::syntax::parser::here(p0);
        let (template_opt, p1) = match crate::syntax::parser::kind(p0) {
            crate::syntax::lexer::TokKind::KTemplate(t) => {
                let (tpl, q) = crate::syntax::parser::expr::parse_template(&crate::syntax::parser::adv(p0), &t, &crate::syntax::parser::here(p0));
                (Some(tpl.clone()), q.clone())
            },
            _ => (None, p0.clone()),
        };
        let m0 = crate::syntax::Module { name: None, emit_row: None, mods: Array::new(), uses: Array::new(), decls: Array::new(), template: template_opt.clone(), span: start.clone() };
        let mut this: ModRead = ModRead { p_: p1.clone(), m: m0.clone(), stage: Nat::from(0u32) };
        let start = start.clone();
        call_then(loop_job((this,), {
            let fragment = *fragment;
            move |(mut this,): (ModRead,)| if !crate::syntax::parser::at_eof(&this.p_) {
                {
                    this = module_item(&this, &fragment);
                    Ok((this,))
                }
            } else {
                Err((this,))
            }
        }), move |(mut this,): (ModRead,)| {
            let r = this;
            let m = {
                let mut this: crate::syntax::Module = r.m.clone();
                this.span = crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&r.p_));
                this
            };
            prism_rtl::Turn::Finished((m.clone(), r.p_.clone()))
        })
    }
}

/// `Start ParseModule, x`: what the function value is when passed to `@Run`.
pub fn start_parse_module(p0: crate::syntax::parser::Ps, fragment: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Module, crate::syntax::parser::Ps)>> {
    Rc::new(ParseModule { p0, fragment })
}

/// ```prism
/// ModuleItem: unbounded fn ModRead, Bool -> ModRead
/// ```
pub fn module_item(s: &ModRead, fragment: &bool) -> ModRead {
    if crate::syntax::parser::at_sep(&s.p_) {
        {
            let mut this: ModRead = s.clone();
            this.p_ = crate::syntax::parser::adv(&this.p_);
            this
        }
    } else {
        {
            let s1 = header_or_decl(s, fragment, &crate::syntax::parser::here(&s.p_));
            let p2 = crate::syntax::parser::recovered(&s1.p_);
            let p3 = if crate::syntax::parser::at_close_l(&p2) {
                crate::syntax::parser::adv(&p2)
            } else {
                if crate::syntax::parser::at_eof(&p2) {
                    p2.clone()
                } else {
                    crate::syntax::parser::expect_stmt_end(&p2, &Text::lit("declaration"))
                }
            };
            {
                let mut this: ModRead = s1.clone();
                this.p_ = p3.clone();
                this
            }
        }
    }
}

/// The step machine of `ModuleItem`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModuleItem: unbounded fn ModRead, Bool -> ModRead
/// ```
pub struct ModuleItem {
    pub s: ModRead,
    pub fragment: bool,
}

impl prism_rtl::Job<ModRead> for ModuleItem {
    fn cycle(&self) -> prism_rtl::Turn<ModRead> {
        let s = &self.s;
        let fragment = &self.fragment;
        if crate::syntax::parser::at_sep(&s.p_) {
            prism_rtl::Turn::Finished({
                let mut this: ModRead = s.clone();
                this.p_ = crate::syntax::parser::adv(&this.p_);
                this
            })
        } else {
            {
                let fragment = *fragment;
                let s = s.clone();
                call_then(start_header_or_decl(s.clone(), fragment, crate::syntax::parser::here(&s.p_)), move |header_or_decl_1962: ModRead| {
                    let s1 = header_or_decl_1962;
                    call_then(crate::syntax::parser::start_recovered(s1.p_.clone()), move |recovered_2016: crate::syntax::parser::Ps| {
                        let p2 = recovered_2016;
                        let p3 = if crate::syntax::parser::at_close_l(&p2) {
                            crate::syntax::parser::adv(&p2)
                        } else {
                            if crate::syntax::parser::at_eof(&p2) {
                                p2.clone()
                            } else {
                                crate::syntax::parser::expect_stmt_end(&p2, &Text::lit("declaration"))
                            }
                        };
                        prism_rtl::Turn::Finished({
                            let mut this: ModRead = s1.clone();
                            this.p_ = p3.clone();
                            this
                        })
                    })
                })
            }
        }
    }
}

/// `Start ModuleItem, x`: what the function value is when passed to `@Run`.
pub fn start_module_item(s: ModRead, fragment: bool) -> Rc<dyn prism_rtl::Job<ModRead>> {
    Rc::new(ModuleItem { s, fragment })
}

/// ```prism
/// HeaderOrDecl: unbounded fn ModRead, Bool, Range -> ModRead
/// ```
pub fn header_or_decl(s: &ModRead, fragment: &bool, item_start: &crate::syntax::Range) -> ModRead {
    match crate::syntax::parser::kind(&s.p_) {
        crate::syntax::lexer::TokKind::KKw(m2338_0_0, m2338_0_1) if (&m2338_0_0 == &Text::lit("module")) && (&m2338_0_1 == &Text::lit("")) => {
            let (name, p_) = crate::syntax::parser::parse_qual_name(&crate::syntax::parser::adv(&s.p_));
            if p_.bad {
                {
                    let mut this: ModRead = s.clone();
                    this.p_ = p_.clone();
                    this
                }
            } else {
                {
                    let late = (&s.stage > &Nat::from(0u32)) || (&s.m.name != &None);
                    {
                        let mut this: ModRead = s.clone();
                        this.p_ = if late {
                            crate::syntax::parser::note_error(&p_, item_start, &Text::lit("the `module` line comes first in a file"))
                        } else {
                            p_.clone()
                        };
                        this.m.name = Some(name.clone());
                        this.stage = Nat::from(1u32);
                        this
                    }
                }
            }
        },
        crate::syntax::lexer::TokKind::KKw(m2338_1_0, m2338_1_1) if (&m2338_1_0 == &Text::lit("emit")) && (&m2338_1_1 == &Text::lit("")) => {
            let (emit_row, p_) = crate::syntax::parser::types::parse_row(&crate::syntax::parser::adv(&s.p_));
            if p_.bad {
                {
                    let mut this: ModRead = s.clone();
                    this.p_ = p_.clone();
                    this
                }
            } else {
                {
                    let late = (&s.stage > &Nat::from(1u32)) || (&s.m.emit_row != &None);
                    {
                        let mut this: ModRead = s.clone();
                        this.p_ = if late {
                            crate::syntax::parser::note_error(&p_, item_start, &Text::lit("`emit` comes after `module` and above `use`, once (Semantics ch. 6)"))
                        } else {
                            p_.clone()
                        };
                        this.m.emit_row = Some(emit_row.clone());
                        this.stage = Nat::from(2u32);
                        this
                    }
                }
            }
        },
        crate::syntax::lexer::TokKind::KKw(m2338_2_0, m2338_2_1) if (&m2338_2_0 == &Text::lit("use")) && (&m2338_2_1 == &Text::lit("")) => {
            let (u, p_) = parse_use(&crate::syntax::parser::adv(&s.p_), item_start);
            if p_.bad {
                {
                    let mut this: ModRead = s.clone();
                    this.p_ = p_.clone();
                    this
                }
            } else {
                {
                    let mut this: ModRead = s.clone();
                    this.p_ = if &s.stage > &Nat::from(4u32) {
                        crate::syntax::parser::note_error(&p_, item_start, &Text::lit("`use` lines belong to the header, above the declarations"))
                    } else {
                        p_.clone()
                    };
                    this.m.uses = push(&this.m.uses, &u);
                    this.stage = Nat::from(4u32);
                    this
                }
            }
        },
        crate::syntax::lexer::TokKind::KKw(m2338_3_0, m2338_3_1) if (&m2338_3_0 == &Text::lit("mod")) && (&m2338_3_1 == &Text::lit("")) => mod_header(s, &crate::syntax::parser::adv(&s.p_), &false, item_start),
        crate::syntax::lexer::TokKind::KKw(m2338_4_0, m2338_4_1) if (&m2338_4_0 == &Text::lit("test")) && (&m2338_4_1 == &Text::lit("")) && is_kw_kind(&crate::syntax::parser::kind(&crate::syntax::parser::adv(&s.p_)), &Text::lit("mod")) => mod_header(s, &crate::syntax::parser::adv(&crate::syntax::parser::adv(&s.p_)), &true, item_start),
        _ => {
            let (d, p_) = parse_decl(&s.p_, fragment);
            {
                let mut this: ModRead = s.clone();
                this.p_ = p_.clone();
                this.stage = Nat::from(5u32);
                if !p_.bad {
                    this.m.decls = push(&this.m.decls, &d);
                }
                this
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `HeaderOrDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HeaderOrDecl: unbounded fn ModRead, Bool, Range -> ModRead
/// ```
pub struct HeaderOrDecl {
    pub s: ModRead,
    pub fragment: bool,
    pub item_start: crate::syntax::Range,
}

impl prism_rtl::Job<ModRead> for HeaderOrDecl {
    fn cycle(&self) -> prism_rtl::Turn<ModRead> {
        let s = &self.s;
        let fragment = &self.fragment;
        let item_start = &self.item_start;
        match crate::syntax::parser::kind(&s.p_) {
            crate::syntax::lexer::TokKind::KKw(m2338_0_0, m2338_0_1) if (&m2338_0_0 == &Text::lit("module")) && (&m2338_0_1 == &Text::lit("")) => {
                let (name, p_) = crate::syntax::parser::parse_qual_name(&crate::syntax::parser::adv(&s.p_));
                if p_.bad {
                    prism_rtl::Turn::Finished({
                        let mut this: ModRead = s.clone();
                        this.p_ = p_.clone();
                        this
                    })
                } else {
                    {
                        let late = (&s.stage > &Nat::from(0u32)) || (&s.m.name != &None);
                        prism_rtl::Turn::Finished({
                            let mut this: ModRead = s.clone();
                            this.p_ = if late {
                                crate::syntax::parser::note_error(&p_, item_start, &Text::lit("the `module` line comes first in a file"))
                            } else {
                                p_.clone()
                            };
                            this.m.name = Some(name.clone());
                            this.stage = Nat::from(1u32);
                            this
                        })
                    }
                }
            },
            crate::syntax::lexer::TokKind::KKw(m2338_1_0, m2338_1_1) if (&m2338_1_0 == &Text::lit("emit")) && (&m2338_1_1 == &Text::lit("")) => {
                let item_start = item_start.clone();
                let s = s.clone();
                call_then(crate::syntax::parser::types::start_parse_row(crate::syntax::parser::adv(&s.p_)), move |parse_row_2789: (crate::syntax::Row_, crate::syntax::parser::Ps)| {
                    let (emit_row, p_) = parse_row_2789;
                    if p_.bad {
                        prism_rtl::Turn::Finished({
                            let mut this: ModRead = s.clone();
                            this.p_ = p_.clone();
                            this
                        })
                    } else {
                        {
                            let late = (&s.stage > &Nat::from(1u32)) || (&s.m.emit_row != &None);
                            prism_rtl::Turn::Finished({
                                let mut this: ModRead = s.clone();
                                this.p_ = if late {
                                    crate::syntax::parser::note_error(&p_, &item_start, &Text::lit("`emit` comes after `module` and above `use`, once (Semantics ch. 6)"))
                                } else {
                                    p_.clone()
                                };
                                this.m.emit_row = Some(emit_row.clone());
                                this.stage = Nat::from(2u32);
                                this
                            })
                        }
                    }
                })
            },
            crate::syntax::lexer::TokKind::KKw(m2338_2_0, m2338_2_1) if (&m2338_2_0 == &Text::lit("use")) && (&m2338_2_1 == &Text::lit("")) => {
                let (u, p_) = parse_use(&crate::syntax::parser::adv(&s.p_), item_start);
                if p_.bad {
                    prism_rtl::Turn::Finished({
                        let mut this: ModRead = s.clone();
                        this.p_ = p_.clone();
                        this
                    })
                } else {
                    prism_rtl::Turn::Finished({
                        let mut this: ModRead = s.clone();
                        this.p_ = if &s.stage > &Nat::from(4u32) {
                            crate::syntax::parser::note_error(&p_, item_start, &Text::lit("`use` lines belong to the header, above the declarations"))
                        } else {
                            p_.clone()
                        };
                        this.m.uses = push(&this.m.uses, &u);
                        this.stage = Nat::from(4u32);
                        this
                    })
                }
            },
            crate::syntax::lexer::TokKind::KKw(m2338_3_0, m2338_3_1) if (&m2338_3_0 == &Text::lit("mod")) && (&m2338_3_1 == &Text::lit("")) => prism_rtl::Turn::Finished(mod_header(s, &crate::syntax::parser::adv(&s.p_), &false, item_start)),
            crate::syntax::lexer::TokKind::KKw(m2338_4_0, m2338_4_1) if (&m2338_4_0 == &Text::lit("test")) && (&m2338_4_1 == &Text::lit("")) && is_kw_kind(&crate::syntax::parser::kind(&crate::syntax::parser::adv(&s.p_)), &Text::lit("mod")) => prism_rtl::Turn::Finished(mod_header(s, &crate::syntax::parser::adv(&crate::syntax::parser::adv(&s.p_)), &true, item_start)),
            _ => {
                let fragment = *fragment;
                let s = s.clone();
                call_then(start_parse_decl(s.p_.clone(), fragment), move |parse_decl_3725: (crate::syntax::decls::Decl, crate::syntax::parser::Ps)| {
                    let (d, p_) = parse_decl_3725;
                    prism_rtl::Turn::Finished({
                        let mut this: ModRead = s.clone();
                        this.p_ = p_.clone();
                        this.stage = Nat::from(5u32);
                        if !p_.bad {
                            this.m.decls = push(&this.m.decls, &d);
                        }
                        this
                    })
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start HeaderOrDecl, x`: what the function value is when passed to `@Run`.
pub fn start_header_or_decl(s: ModRead, fragment: bool, item_start: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<ModRead>> {
    Rc::new(HeaderOrDecl { s, fragment, item_start })
}

/// ```prism
/// ModHeader: fn ModRead, Ps, Bool, Range -> ModRead
/// ```
pub fn mod_header(s: &ModRead, p_: &crate::syntax::parser::Ps, is_test: &bool, item_start: &crate::syntax::Range) -> ModRead {
    match crate::syntax::parser::kind(p_) {
        crate::syntax::lexer::TokKind::KName(n) if ((&n.sigils == &Text::lit("")) && (&len(&n.path_) == &Nat::from(1u32))) => {
            let line = crate::syntax::ModLine { name: crate::syntax::Ident { name: or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")), span: crate::syntax::parser::here(p_) }, is_test: *is_test, span: crate::syntax::parser::to(item_start, &crate::syntax::parser::here(p_)) };
            {
                let mut this: ModRead = s.clone();
                this.p_ = if &s.stage > &Nat::from(3u32) {
                    crate::syntax::parser::note_error(&crate::syntax::parser::adv(p_), item_start, &Text::lit("`mod` lines come after `emit` and above `use` (claude/modules-style-pass.md)"))
                } else {
                    crate::syntax::parser::adv(p_)
                };
                this.m.mods = push(&this.m.mods, &line);
                this.stage = Nat::from(3u32);
                this
            }
        },
        _ => {
            let mut this: ModRead = s.clone();
            this.p_ = crate::syntax::parser::error_here(p_, &(if *is_test {
                Text::lit("expected a test module\'s name after `test mod`")
            } else {
                Text::lit("expected a module\'s name after `mod`")
            }));
            this
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IsKwKind: fn TokKind, Text -> Bool
/// ```
pub fn is_kw_kind(k: &crate::syntax::lexer::TokKind, w: &Text) -> bool {
    match k {
        crate::syntax::lexer::TokKind::KKw(x, _) => x == w,
        _ => false,
    }
}

/// ```prism
/// let noQual
/// ```
pub fn no_qual() -> crate::syntax::QualName {
    crate::syntax::QualName { path_: Array::new(), span: crate::syntax::parser::no_range() }
}

/// ```prism
/// ParseUse: fn Ps, Range -> ((Use, Ps))
/// ```
pub fn parse_use(p_: &crate::syntax::parser::Ps, start: &crate::syntax::Range) -> (crate::syntax::Use, crate::syntax::parser::Ps) {
    match crate::syntax::parser::kind(p_) {
        crate::syntax::lexer::TokKind::KFamily(path_) => (crate::syntax::Use { target: crate::syntax::QualName { path_: path_.clone(), span: crate::syntax::parser::here(p_) }, star: true, span: crate::syntax::parser::to(start, &crate::syntax::parser::here(p_)) }, crate::syntax::parser::adv(p_)),
        crate::syntax::lexer::TokKind::KName(n) if ((&n.sigils == &Text::lit("")) && (&n.case == &crate::syntax::lexer::NameCase::CaseUpper)) => (crate::syntax::Use { target: crate::syntax::QualName { path_: n.path_.clone(), span: crate::syntax::parser::here(p_) }, star: false, span: crate::syntax::parser::to(start, &crate::syntax::parser::here(p_)) }, crate::syntax::parser::adv(p_)),
        _ => (crate::syntax::Use { target: no_qual(), star: false, span: crate::syntax::parser::no_range() }, crate::syntax::parser::error_here(p_, &Text::lit("expected a module name after `use`"))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// let noExpr
/// ```
pub fn no_expr() -> crate::syntax::Expr {
    crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: crate::syntax::parser::no_range() }
}

/// ```prism
/// let noType
/// ```
pub fn no_type() -> crate::syntax::Type {
    crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TAbsent), span: crate::syntax::parser::no_range() }
}

/// ```prism
/// let noPattern
/// ```
pub fn no_pattern() -> crate::syntax::Pattern_ {
    crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: crate::syntax::parser::no_range() }
}

/// ```prism
/// let noBlock
/// ```
pub fn no_block() -> crate::syntax::Block {
    crate::syntax::Block { stmts: Array::new(), inline: true, span: crate::syntax::parser::no_range() }
}

/// ```prism
/// ParseDecl: unbounded fn Ps, Bool -> ((Decl, Ps))
/// ```
pub fn parse_decl(p_: &crate::syntax::parser::Ps, fragment: &bool) -> (crate::syntax::decls::Decl, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p_);
    let (kind, q) = decl_kind_of(p_, fragment, &start);
    (crate::syntax::decls::Decl { kind: kind.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone())
}

/// The step machine of `ParseDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseDecl: unbounded fn Ps, Bool -> ((Decl, Ps))
/// ```
pub struct ParseDecl {
    pub p_: crate::syntax::parser::Ps,
    pub fragment: bool,
}

impl prism_rtl::Job<(crate::syntax::decls::Decl, crate::syntax::parser::Ps)> for ParseDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::Decl, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let fragment = &self.fragment;
        let start = crate::syntax::parser::here(p_);
        let fragment = *fragment;
        let p_ = p_.clone();
        call_then(start_decl_kind_of(p_.clone(), fragment, start.clone()), move |decl_kind_of_5602: (crate::syntax::decls::DeclKind, crate::syntax::parser::Ps)| {
            let (kind, q) = decl_kind_of_5602;
            prism_rtl::Turn::Finished((crate::syntax::decls::Decl { kind: kind.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone()))
        })
    }
}

/// `Start ParseDecl, x`: what the function value is when passed to `@Run`.
pub fn start_parse_decl(p_: crate::syntax::parser::Ps, fragment: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::Decl, crate::syntax::parser::Ps)>> {
    Rc::new(ParseDecl { p_, fragment })
}

/// ```prism
/// DeclKindOf: unbounded fn Ps, Bool, Range -> ((DeclKind, Ps))
/// ```
pub fn decl_kind_of(p_: &crate::syntax::parser::Ps, fragment: &bool, start: &crate::syntax::Range) -> (crate::syntax::decls::DeclKind, crate::syntax::parser::Ps) {
    match crate::syntax::parser::kind(p_) {
        crate::syntax::lexer::TokKind::KKw(m5783_0_0, _) if (&m5783_0_0 == &Text::lit("type")) => {
            let (d, q) = parse_type_decl(p_);
            (crate::syntax::decls::DeclKind::DType(d.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m5783_1_0, _) if (&m5783_1_0 == &Text::lit("tag")) => {
            let (d, q) = parse_tag_decl(p_);
            (crate::syntax::decls::DeclKind::DTag(d.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m5783_2_0, _) if (&m5783_2_0 == &Text::lit("derive")) => {
            let (traits, q) = crate::syntax::parser::commas(&crate::syntax::parser::adv(p_), &{
                let f = Rc::new(crate::syntax::parser::parse_trait_ref);
                Rc::new(move |a0: crate::syntax::parser::Ps| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                }) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::TraitRef, crate::syntax::parser::Ps)>>>
            });
            (crate::syntax::decls::DeclKind::DDerive(traits.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m5783_3_0, _) if (&m5783_3_0 == &Text::lit("trait")) => {
            let (d, q) = parse_trait_decl(p_);
            (crate::syntax::decls::DeclKind::DTrait(d.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m5783_4_0, _) if (&m5783_4_0 == &Text::lit("impl")) => {
            let (d, q) = parse_impl_decl(p_);
            (crate::syntax::decls::DeclKind::DImpl(d.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m5783_5_0, _) if (&m5783_5_0 == &Text::lit("check")) => {
            let (d, q) = crate::syntax::parser::test_language::parse_check_decl(p_);
            (crate::syntax::decls::DeclKind::DCheck(d.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m5783_6_0, _) if (&m5783_6_0 == &Text::lit("test")) => {
            let (d, q) = crate::syntax::parser::test_language::parse_test_decl(p_);
            (crate::syntax::decls::DeclKind::DTest(d.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m5783_7_0, _) if (&m5783_7_0 == &Text::lit("fn")) => {
            let (d, q) = parse_fn_clause(p_);
            (crate::syntax::decls::DeclKind::DFn(d.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m5783_8_0, _) if (&m5783_8_0 == &Text::lit("let")) => {
            let (pattern, p1) = crate::syntax::parser::types::parse_pattern(&crate::syntax::parser::adv(p_), &false);
            let (ty_opt, p2) = optional_annotation(&p1);
            let (value, p3) = crate::syntax::parser::expr::parse_rhs_expr(&crate::syntax::parser::expect_op(&p2, &Text::lit("=")));
            (crate::syntax::decls::DeclKind::DLet(crate::syntax::decls::LetDecl { pattern: pattern.clone(), ty: ty_opt.clone(), value: value.clone(), span: crate::syntax::parser::to(start, &crate::syntax::parser::prev(&p3)) }), p3.clone())
        },
        crate::syntax::lexer::TokKind::KName(_) if (&crate::syntax::parser::kind_at(p_, &Nat::from(1u32)) == &crate::syntax::lexer::TokKind::KColon) => if &crate::syntax::parser::kind_at(p_, &Nat::from(2u32)) == &crate::syntax::lexer::TokKind::KLayOpen {
            {
                let (name, p1) = crate::syntax::parser::parse_sname(p_);
                let (body, p2) = crate::syntax::parser::blocks::parse_block_after_colon(&p1);
                (crate::syntax::decls::DeclKind::DWidget(crate::syntax::decls::WidgetDecl { name: name.clone(), body: body.clone(), span: crate::syntax::parser::to(start, &body.span) }), p2.clone())
            }
        } else {
            {
                let (sig, q) = parse_signature(p_);
                (crate::syntax::decls::DeclKind::DSignature(sig.clone()), q.clone())
            }
        },
        _ => if *fragment {
            {
                let (st, q) = crate::syntax::parser::blocks::parse_stmt(p_);
                (crate::syntax::decls::DeclKind::DStmt(st.clone()), q.clone())
            }
        } else {
            {
                let (st, q) = crate::syntax::parser::blocks::parse_stmt(p_);
                match &st.kind {
                    crate::syntax::StmtKind::SBind(_, _, _) if !q.bad => (crate::syntax::decls::DeclKind::DStmt(st.clone()), crate::syntax::parser::error_at(&q, start, &Text::lit("a bind or hold is a statement of a widget block: nothing at top level is built (Semantics ch. 6)"))),
                    _ => {
                        let at_ = if q.bad { p_.clone() } else { q.clone() };
                        (crate::syntax::decls::DeclKind::DStmt(st.clone()), crate::syntax::parser::error_here(&at_, &Text::lit("expected a declaration (`fn`, `let`, `type`, `tag`, `derive`, `trait`, `impl`, `test`, `check`, or a signature `Name: type`)")))
                    },
                    _ => unreachable!("no arm matched"),
                }
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `DeclKindOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DeclKindOf: unbounded fn Ps, Bool, Range -> ((DeclKind, Ps))
/// ```
pub struct DeclKindOf {
    pub p_: crate::syntax::parser::Ps,
    pub fragment: bool,
    pub start: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::syntax::decls::DeclKind, crate::syntax::parser::Ps)> for DeclKindOf {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::DeclKind, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let fragment = &self.fragment;
        let start = &self.start;
        match crate::syntax::parser::kind(p_) {
            crate::syntax::lexer::TokKind::KKw(m5783_0_0, _) if (&m5783_0_0 == &Text::lit("type")) => {
                let p_ = p_.clone();
                call_then(start_parse_type_decl(p_.clone()), move |parse_type_decl_5844: (crate::syntax::decls::TypeDecl, crate::syntax::parser::Ps)| {
                    let (d, q) = parse_type_decl_5844;
                    prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DType(d.clone()), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m5783_1_0, _) if (&m5783_1_0 == &Text::lit("tag")) => {
                let p_ = p_.clone();
                call_then(start_parse_tag_decl(p_.clone()), move |parse_tag_decl_5929: (crate::syntax::decls::TagDecl, crate::syntax::parser::Ps)| {
                    let (d, q) = parse_tag_decl_5929;
                    prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DTag(d.clone()), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m5783_2_0, _) if (&m5783_2_0 == &Text::lit("derive")) => {
                let p_ = p_.clone();
                call_then(crate::syntax::parser::start_commas(crate::syntax::parser::adv(&p_), {
                    let f = Rc::new(crate::syntax::parser::parse_trait_ref);
                    Rc::new(move |a0: crate::syntax::parser::Ps| {
                        let f = f.clone();
                        once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                    }) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::TraitRef, crate::syntax::parser::Ps)>>>
                }), move |commas_6020: (Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps)| {
                    let (traits, q) = commas_6020;
                    prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DDerive(traits.clone()), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m5783_3_0, _) if (&m5783_3_0 == &Text::lit("trait")) => {
                let p_ = p_.clone();
                call_then(start_parse_trait_decl(p_.clone()), move |parse_trait_decl_6128: (crate::syntax::decls::TraitDecl, crate::syntax::parser::Ps)| {
                    let (d, q) = parse_trait_decl_6128;
                    prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DTrait(d.clone()), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m5783_4_0, _) if (&m5783_4_0 == &Text::lit("impl")) => {
                let p_ = p_.clone();
                call_then(start_parse_impl_decl(p_.clone()), move |parse_impl_decl_6216: (crate::syntax::decls::ImplDecl, crate::syntax::parser::Ps)| {
                    let (d, q) = parse_impl_decl_6216;
                    prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DImpl(d.clone()), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m5783_5_0, _) if (&m5783_5_0 == &Text::lit("check")) => {
                let p_ = p_.clone();
                call_then(crate::syntax::parser::test_language::start_parse_check_decl(p_.clone()), move |parse_check_decl_6303: (crate::syntax::decls::CheckDecl, crate::syntax::parser::Ps)| {
                    let (d, q) = parse_check_decl_6303;
                    prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DCheck(d.clone()), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m5783_6_0, _) if (&m5783_6_0 == &Text::lit("test")) => {
                let p_ = p_.clone();
                call_then(crate::syntax::parser::test_language::start_parse_test_decl(p_.clone()), move |parse_test_decl_6391: (crate::syntax::decls::TestDecl, crate::syntax::parser::Ps)| {
                    let (d, q) = parse_test_decl_6391;
                    prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DTest(d.clone()), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m5783_7_0, _) if (&m5783_7_0 == &Text::lit("fn")) => {
                let p_ = p_.clone();
                call_then(start_parse_fn_clause(p_.clone()), move |parse_fn_clause_6475: (crate::syntax::decls::FnClause, crate::syntax::parser::Ps)| {
                    let (d, q) = parse_fn_clause_6475;
                    prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DFn(d.clone()), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m5783_8_0, _) if (&m5783_8_0 == &Text::lit("let")) => {
                let p_ = p_.clone();
                let start = start.clone();
                call_then(crate::syntax::parser::types::start_parse_pattern(crate::syntax::parser::adv(&p_), false), move |parse_pattern_6565: (crate::syntax::Pattern_, crate::syntax::parser::Ps)| {
                    let (pattern, p1) = parse_pattern_6565;
                    call_then(start_optional_annotation(p1.clone()), move |optional_annotation_6619: (Option<crate::syntax::Type>, crate::syntax::parser::Ps)| {
                        let (ty_opt, p2) = optional_annotation_6619;
                        call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::expect_op(&p2, &Text::lit("="))), move |parse_rhs_expr_6669: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                            let (value, p3) = parse_rhs_expr_6669;
                            prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DLet(crate::syntax::decls::LetDecl { pattern: pattern.clone(), ty: ty_opt.clone(), value: value.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p3)) }), p3.clone()))
                        })
                    })
                })
            },
            crate::syntax::lexer::TokKind::KName(_) if (&crate::syntax::parser::kind_at(p_, &Nat::from(1u32)) == &crate::syntax::lexer::TokKind::KColon) => if &crate::syntax::parser::kind_at(p_, &Nat::from(2u32)) == &crate::syntax::lexer::TokKind::KLayOpen {
                {
                    let (name, p1) = crate::syntax::parser::parse_sname(p_);
                    let start = start.clone();
                    call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(p1.clone()), move |parse_block_after_colon_6954: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                        let (body, p2) = parse_block_after_colon_6954;
                        prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DWidget(crate::syntax::decls::WidgetDecl { name: name.clone(), body: body.clone(), span: crate::syntax::parser::to(&start, &body.span) }), p2.clone()))
                    })
                }
            } else {
                {
                    let p_ = p_.clone();
                    call_then(start_parse_signature(p_.clone()), move |parse_signature_7110: (crate::syntax::decls::Signature, crate::syntax::parser::Ps)| {
                        let (sig, q) = parse_signature_7110;
                        prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DSignature(sig.clone()), q.clone()))
                    })
                }
            },
            _ => if *fragment {
                {
                    let p_ = p_.clone();
                    call_then(crate::syntax::parser::blocks::start_parse_stmt(p_.clone()), move |parse_stmt_7225: (crate::syntax::Stmt, crate::syntax::parser::Ps)| {
                        let (st, q) = parse_stmt_7225;
                        prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DStmt(st.clone()), q.clone()))
                    })
                }
            } else {
                {
                    let p_ = p_.clone();
                    let start = start.clone();
                    call_then(crate::syntax::parser::blocks::start_parse_stmt(p_.clone()), move |parse_stmt_7433: (crate::syntax::Stmt, crate::syntax::parser::Ps)| {
                        let (st, q) = parse_stmt_7433;
                        match &st.kind {
                            crate::syntax::StmtKind::SBind(_, _, _) if !q.bad => prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DStmt(st.clone()), crate::syntax::parser::error_at(&q, &start, &Text::lit("a bind or hold is a statement of a widget block: nothing at top level is built (Semantics ch. 6)")))),
                            _ => {
                                let at_ = if q.bad { p_.clone() } else { q.clone() };
                                prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DStmt(st.clone()), crate::syntax::parser::error_here(&at_, &Text::lit("expected a declaration (`fn`, `let`, `type`, `tag`, `derive`, `trait`, `impl`, `test`, `check`, or a signature `Name: type`)"))))
                            },
                            _ => unreachable!("no arm matched"),
                        }
                    })
                }
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start DeclKindOf, x`: what the function value is when passed to `@Run`.
pub fn start_decl_kind_of(p_: crate::syntax::parser::Ps, fragment: bool, start: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::DeclKind, crate::syntax::parser::Ps)>> {
    Rc::new(DeclKindOf { p_, fragment, start })
}

/// ```prism
/// OptionalAnnotation: unbounded fn Ps -> ((?Type, Ps))
/// ```
pub fn optional_annotation(p_: &crate::syntax::parser::Ps) -> (Option<crate::syntax::Type>, crate::syntax::parser::Ps) {
    if crate::syntax::parser::at_colon(p_) {
        {
            let (ty, q) = crate::syntax::parser::types::parse_type(&crate::syntax::parser::adv(p_));
            (Some(ty.clone()), q.clone())
        }
    } else {
        (None, p_.clone())
    }
}

/// The step machine of `OptionalAnnotation`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptionalAnnotation: unbounded fn Ps -> ((?Type, Ps))
/// ```
pub struct OptionalAnnotation {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(Option<crate::syntax::Type>, crate::syntax::parser::Ps)> for OptionalAnnotation {
    fn cycle(&self) -> prism_rtl::Turn<(Option<crate::syntax::Type>, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        if crate::syntax::parser::at_colon(p_) {
            {
                let p_ = p_.clone();
                call_then(crate::syntax::parser::types::start_parse_type(crate::syntax::parser::adv(&p_)), move |parse_type_8123: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (ty, q) = parse_type_8123;
                    prism_rtl::Turn::Finished((Some(ty.clone()), q.clone()))
                })
            }
        } else {
            prism_rtl::Turn::Finished((None, p_.clone()))
        }
    }
}

/// `Start OptionalAnnotation, x`: what the function value is when passed to `@Run`.
pub fn start_optional_annotation(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(Option<crate::syntax::Type>, crate::syntax::parser::Ps)>> {
    Rc::new(OptionalAnnotation { p_ })
}

/// ```prism
/// ParseSignature: unbounded fn Ps -> ((Signature, Ps))
/// ```
pub fn parse_signature(p_: &crate::syntax::parser::Ps) -> (crate::syntax::decls::Signature, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p_);
    let (name, p1) = parse_def_name(p_);
    let (ty, p2) = crate::syntax::parser::types::parse_type(&crate::syntax::parser::expect_colon(&p1));
    let (bounds, p3) = optional_bounds(&p2);
    (crate::syntax::decls::Signature { name: name.clone(), ty: ty.clone(), bounds: bounds.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p3)) }, p3.clone())
}

/// The step machine of `ParseSignature`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseSignature: unbounded fn Ps -> ((Signature, Ps))
/// ```
pub struct ParseSignature {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::Signature, crate::syntax::parser::Ps)> for ParseSignature {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::Signature, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let start = crate::syntax::parser::here(p_);
        let (name, p1) = parse_def_name(p_);
        call_then(crate::syntax::parser::types::start_parse_type(crate::syntax::parser::expect_colon(&p1)), move |parse_type_8405: (crate::syntax::Type, crate::syntax::parser::Ps)| {
            let (ty, p2) = parse_type_8405;
            call_then(start_optional_bounds(p2.clone()), move |optional_bounds_8457: (Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps)| {
                let (bounds, p3) = optional_bounds_8457;
                prism_rtl::Turn::Finished((crate::syntax::decls::Signature { name: name.clone(), ty: ty.clone(), bounds: bounds.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p3)) }, p3.clone()))
            })
        })
    }
}

/// `Start ParseSignature, x`: what the function value is when passed to `@Run`.
pub fn start_parse_signature(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::Signature, crate::syntax::parser::Ps)>> {
    Rc::new(ParseSignature { p_ })
}

/// ```prism
/// OptionalBounds: unbounded fn Ps -> (([Bound], Ps))
/// ```
pub fn optional_bounds(p_: &crate::syntax::parser::Ps) -> (Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps) {
    if crate::syntax::parser::at_kw(p_, &Text::lit("where")) {
        crate::syntax::parser::types::parse_bounds(&crate::syntax::parser::adv(p_))
    } else {
        (Array::new(), p_.clone())
    }
}

/// The step machine of `OptionalBounds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptionalBounds: unbounded fn Ps -> (([Bound], Ps))
/// ```
pub struct OptionalBounds {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps)> for OptionalBounds {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        if crate::syntax::parser::at_kw(p_, &Text::lit("where")) {
            prism_rtl::Turn::More(Rc::new(crate::syntax::parser::types::ParseBounds { p0: crate::syntax::parser::adv(p_) }))
        } else {
            prism_rtl::Turn::Finished((Array::new(), p_.clone()))
        }
    }
}

/// `Start OptionalBounds, x`: what the function value is when passed to `@Run`.
pub fn start_optional_bounds(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps)>> {
    Rc::new(OptionalBounds { p_ })
}

/// ```prism
/// ParseDefName: fn Ps -> ((DefName, Ps))
/// ```
pub fn parse_def_name(p_: &crate::syntax::parser::Ps) -> (crate::syntax::decls::DefName, crate::syntax::parser::Ps) {
    match crate::syntax::parser::kind(p_) {
        crate::syntax::lexer::TokKind::KName(n) => {
            let (name, q) = crate::syntax::parser::parse_sname(p_);
            let lens = crate::syntax::lexer::chars::has_prefix(&n.sigils, &Text::lit("&")) && crate::syntax::parser::is_upper_name(&name);
            let q2 = if lens {
                crate::syntax::parser::out_of_scope(&q, &name.span, &Text::lit("named lenses `&Home` and `Over`"), &Text::from(format!("the named lens `{}` is out of this compiler", &crate::syntax::parser::name_text(&name))))
            } else {
                q.clone()
            };
            (crate::syntax::decls::DefName::DefSName(name.clone()), q2.clone())
        },
        crate::syntax::lexer::TokKind::KOp(op, _) if p_.in_trait => {
            let name = crate::syntax::decls::DefName::DefOp(op.clone(), crate::syntax::parser::here(p_));
            (name.clone(), crate::syntax::parser::adv(p_))
        },
        _ => (crate::syntax::decls::DefName::DefSName(crate::syntax::parser::no_sname()), crate::syntax::parser::error_here(p_, &Text::lit("expected a name"))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParseFnClause: unbounded fn Ps -> ((FnClause, Ps))
/// ```
pub fn parse_fn_clause(p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::FnClause, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p0);
    let (name, p1) = parse_def_name(&crate::syntax::parser::expect_kw(p0, &Text::lit("fn")));
    let (params, p2) = if crate::syntax::parser::at_op(&p1, &Text::lit("=")) || crate::syntax::parser::at_colon(&p1) {
        (Array::new(), p1.clone())
    } else {
        crate::syntax::parser::commas(&p1, &(Rc::new(move |p0: crate::syntax::parser::Ps| entered(once_job(move || {
            let q = p0;
            prism_rtl::Turn::More(Rc::new(crate::syntax::parser::types::ParsePattern { p_: q.clone(), commas0: false }))
        }))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>>>))
    };
    let (body, p3) = parse_fn_body(&p2);
    (crate::syntax::decls::FnClause { name: name.clone(), params: params.clone(), body: body.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p3)) }, p3.clone())
}

/// The step machine of `ParseFnClause`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseFnClause: unbounded fn Ps -> ((FnClause, Ps))
/// ```
pub struct ParseFnClause {
    pub p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::FnClause, crate::syntax::parser::Ps)> for ParseFnClause {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::FnClause, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let start = crate::syntax::parser::here(p0);
        let (name, p1) = parse_def_name(&crate::syntax::parser::expect_kw(p0, &Text::lit("fn")));
        let (params, p2) = if crate::syntax::parser::at_op(&p1, &Text::lit("=")) || crate::syntax::parser::at_colon(&p1) {
            (Array::new(), p1.clone())
        } else {
            crate::syntax::parser::commas(&p1, &(Rc::new(move |p0: crate::syntax::parser::Ps| entered(once_job(move || {
                let q = p0;
                prism_rtl::Turn::More(Rc::new(crate::syntax::parser::types::ParsePattern { p_: q.clone(), commas0: false }))
            }))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>>>))
        };
        call_then(start_parse_fn_body(p2.clone()), move |parse_fn_body_9580: (crate::syntax::decls::FnBody, crate::syntax::parser::Ps)| {
            let (body, p3) = parse_fn_body_9580;
            prism_rtl::Turn::Finished((crate::syntax::decls::FnClause { name: name.clone(), params: params.clone(), body: body.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p3)) }, p3.clone()))
        })
    }
}

/// `Start ParseFnClause, x`: what the function value is when passed to `@Run`.
pub fn start_parse_fn_clause(p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::FnClause, crate::syntax::parser::Ps)>> {
    Rc::new(ParseFnClause { p0 })
}

/// ```prism
/// ParseFnBody: unbounded fn Ps -> ((FnBody, Ps))
/// ```
pub fn parse_fn_body(p_: &crate::syntax::parser::Ps) -> (crate::syntax::decls::FnBody, crate::syntax::parser::Ps) {
    if crate::syntax::parser::at_op(p_, &Text::lit("=")) {
        {
            let (e, q) = crate::syntax::parser::expr::parse_rhs_expr(&crate::syntax::parser::adv(p_));
            (crate::syntax::decls::FnBody::BodyExpr(e.clone()), q.clone())
        }
    } else {
        if crate::syntax::parser::at_colon(p_) {
            {
                let (b, q) = crate::syntax::parser::blocks::parse_block_after_colon(p_);
                (crate::syntax::decls::FnBody::BodyBlock(b.clone()), q.clone())
            }
        } else {
            (crate::syntax::decls::FnBody::BodyExpr(no_expr()), crate::syntax::parser::error_here(p_, &Text::lit("expected `=` and an expression, or `:` and a block, after the parameters")))
        }
    }
}

/// The step machine of `ParseFnBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseFnBody: unbounded fn Ps -> ((FnBody, Ps))
/// ```
pub struct ParseFnBody {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::FnBody, crate::syntax::parser::Ps)> for ParseFnBody {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::FnBody, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        if crate::syntax::parser::at_op(p_, &Text::lit("=")) {
            {
                let p_ = p_.clone();
                call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::adv(&p_)), move |parse_rhs_expr_9790: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (e, q) = parse_rhs_expr_9790;
                    prism_rtl::Turn::Finished((crate::syntax::decls::FnBody::BodyExpr(e.clone()), q.clone()))
                })
            }
        } else {
            if crate::syntax::parser::at_colon(p_) {
                {
                    let p_ = p_.clone();
                    call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(p_.clone()), move |parse_block_after_colon_9884: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                        let (b, q) = parse_block_after_colon_9884;
                        prism_rtl::Turn::Finished((crate::syntax::decls::FnBody::BodyBlock(b.clone()), q.clone()))
                    })
                }
            } else {
                prism_rtl::Turn::Finished((crate::syntax::decls::FnBody::BodyExpr(no_expr()), crate::syntax::parser::error_here(p_, &Text::lit("expected `=` and an expression, or `:` and a block, after the parameters"))))
            }
        }
    }
}

/// `Start ParseFnBody, x`: what the function value is when passed to `@Run`.
pub fn start_parse_fn_body(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::FnBody, crate::syntax::parser::Ps)>> {
    Rc::new(ParseFnBody { p_ })
}

/// ```prism
/// LowerParams: fn Ps -> (([Ident], Ps))
/// ```
pub fn lower_params(p0: &crate::syntax::parser::Ps) -> (Array<crate::syntax::Ident>, crate::syntax::parser::Ps) {
    let mut this: (Array<crate::syntax::Ident>, crate::syntax::parser::Ps) = (Array::new(), p0.clone());
    let mut ps: Array<crate::syntax::Ident> = Array::new();
    let mut p_: crate::syntax::parser::Ps = p0.clone();
    let mut fuel: Nat = len(&p0.toks);
    while let Some(left) = (&fuel).checked_sub(&Nat::from(1u32)) {
        if !is_plain_lower(&crate::syntax::parser::kind(&p_)) {
            break;
        }
        fuel = left.clone();
        let (i, q) = crate::syntax::parser::parse_ident(&p_);
        ps = push(&ps, &i);
        p_ = q.clone();
    }
    this = (ps.clone(), p_.clone());
    this
}

/// ```prism
/// IsPlainLower: fn TokKind -> Bool
/// ```
pub fn is_plain_lower(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KName(n) => (&n.case == &crate::syntax::lexer::NameCase::CaseLower) && (&n.sigils == &Text::lit("")),
        _ => false,
    }
}

/// ```prism
/// ParseTypeDecl: unbounded fn Ps -> ((TypeDecl, Ps))
/// ```
pub fn parse_type_decl(p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::TypeDecl, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p0);
    let (name, p1) = crate::syntax::parser::parse_qual_name(&crate::syntax::parser::adv(p0));
    let (params, p2) = lower_params(&p1);
    let (body_opt, p3) = if crate::syntax::parser::at_op(&p2, &Text::lit("=")) {
        parse_type_body(&crate::syntax::parser::adv(&p2), &name, &params)
    } else {
        (None, p2.clone())
    };
    (crate::syntax::decls::TypeDecl { name: name.clone(), params: params.clone(), body: body_opt.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p3)) }, p3.clone())
}

/// The step machine of `ParseTypeDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTypeDecl: unbounded fn Ps -> ((TypeDecl, Ps))
/// ```
pub struct ParseTypeDecl {
    pub p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::TypeDecl, crate::syntax::parser::Ps)> for ParseTypeDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::TypeDecl, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let start = crate::syntax::parser::here(p0);
        let (name, p1) = crate::syntax::parser::parse_qual_name(&crate::syntax::parser::adv(p0));
        let (params, p2) = lower_params(&p1);
        let (body_opt, p3) = if crate::syntax::parser::at_op(&p2, &Text::lit("=")) {
            parse_type_body(&crate::syntax::parser::adv(&p2), &name, &params)
        } else {
            (None, p2.clone())
        };
        prism_rtl::Turn::Finished((crate::syntax::decls::TypeDecl { name: name.clone(), params: params.clone(), body: body_opt.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p3)) }, p3.clone()))
    }
}

/// `Start ParseTypeDecl, x`: what the function value is when passed to `@Run`.
pub fn start_parse_type_decl(p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TypeDecl, crate::syntax::parser::Ps)>> {
    Rc::new(ParseTypeDecl { p0 })
}

/// ```prism
/// ParseTypeBody: unbounded fn Ps, QualName, [Ident] -> ((?TypeBody, Ps))
/// ```
pub fn parse_type_body(p_: &crate::syntax::parser::Ps, name: &crate::syntax::QualName, params: &Array<crate::syntax::Ident>) -> (Option<crate::syntax::decls::TypeBody>, crate::syntax::parser::Ps) {
    match crate::syntax::parser::kind(p_) {
        crate::syntax::lexer::TokKind::KKw(m11097_0_0, m11097_0_1) if (&m11097_0_0 == &Text::lit("record")) && (&m11097_0_1 == &Text::lit("")) => {
            let (fields, q) = parse_field_block(&crate::syntax::parser::adv(p_));
            (Some(crate::syntax::decls::TypeBody::TbRecord(fields.clone())), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m11097_1_0, m11097_1_1) if (&m11097_1_0 == &Text::lit("choice")) && (&m11097_1_1 == &Text::lit("")) => {
            let p1 = crate::syntax::parser::expect_colon(&crate::syntax::parser::adv(p_));
            if crate::syntax::parser::at_open_l(&p1) {
                {
                    let (cases, q) = crate::syntax::parser::layout_items(&crate::syntax::parser::adv(&p1), &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_case(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::Case_, crate::syntax::parser::Ps)>>>));
                    (Some(crate::syntax::decls::TypeBody::TbChoice(cases.clone())), q.clone())
                }
            } else {
                (None, crate::syntax::parser::error_here(&p1, &Text::lit("a choice\'s cases stand in an indented block after `choice:`")))
            }
        },
        crate::syntax::lexer::TokKind::KKw(m11097_2_0, m11097_2_1) if (&m11097_2_0 == &Text::lit("row")) && (&m11097_2_1 == &Text::lit("")) => (Some(crate::syntax::decls::TypeBody::TbRow), crate::syntax::parser::adv(p_)),
        crate::syntax::lexer::TokKind::KName(n) if (((&n.sigils == &Text::lit("")) && (&len(&n.path_) == &Nat::from(1u32))) && (&crate::syntax::lexer::chars::last(&n.path_) == &crate::syntax::lexer::chars::last(&name.path_))) => {
            let (c, q) = parse_case(p_);
            (Some(crate::syntax::decls::TypeBody::TbNewtype(c.clone())), q.clone())
        },
        crate::syntax::lexer::TokKind::KName(n) if is_unit_body(p_, &n, params) => {
            let (i, q) = crate::syntax::parser::parse_ident(p_);
            (Some(crate::syntax::decls::TypeBody::TbUnit(i.clone())), q.clone())
        },
        _ => {
            let (ty, q) = crate::syntax::parser::types::parse_type(p_);
            (Some(crate::syntax::decls::TypeBody::TbAlias(ty.clone())), q.clone())
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ParseTypeBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTypeBody: unbounded fn Ps, QualName, [Ident] -> ((?TypeBody, Ps))
/// ```
pub struct ParseTypeBody {
    pub p_: crate::syntax::parser::Ps,
    pub name: crate::syntax::QualName,
    pub params: Array<crate::syntax::Ident>,
}

impl prism_rtl::Job<(Option<crate::syntax::decls::TypeBody>, crate::syntax::parser::Ps)> for ParseTypeBody {
    fn cycle(&self) -> prism_rtl::Turn<(Option<crate::syntax::decls::TypeBody>, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let name = &self.name;
        let params = &self.params;
        match crate::syntax::parser::kind(p_) {
            crate::syntax::lexer::TokKind::KKw(m11097_0_0, m11097_0_1) if (&m11097_0_0 == &Text::lit("record")) && (&m11097_0_1 == &Text::lit("")) => {
                let p_ = p_.clone();
                call_then(start_parse_field_block(crate::syntax::parser::adv(&p_)), move |parse_field_block_11161: (Array<crate::syntax::decls::Field>, crate::syntax::parser::Ps)| {
                    let (fields, q) = parse_field_block_11161;
                    prism_rtl::Turn::Finished((Some(crate::syntax::decls::TypeBody::TbRecord(fields.clone())), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m11097_1_0, m11097_1_1) if (&m11097_1_0 == &Text::lit("choice")) && (&m11097_1_1 == &Text::lit("")) => {
                let p1 = crate::syntax::parser::expect_colon(&crate::syntax::parser::adv(p_));
                if crate::syntax::parser::at_open_l(&p1) {
                    call_then(crate::syntax::parser::start_layout_items(crate::syntax::parser::adv(&p1), Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_case(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::Case_, crate::syntax::parser::Ps)>>>), move |layout_items_11333: (Array<crate::syntax::decls::Case_>, crate::syntax::parser::Ps)| {
                        let (cases, q) = layout_items_11333;
                        prism_rtl::Turn::Finished((Some(crate::syntax::decls::TypeBody::TbChoice(cases.clone())), q.clone()))
                    })
                } else {
                    prism_rtl::Turn::Finished((None, crate::syntax::parser::error_here(&p1, &Text::lit("a choice\'s cases stand in an indented block after `choice:`"))))
                }
            },
            crate::syntax::lexer::TokKind::KKw(m11097_2_0, m11097_2_1) if (&m11097_2_0 == &Text::lit("row")) && (&m11097_2_1 == &Text::lit("")) => prism_rtl::Turn::Finished((Some(crate::syntax::decls::TypeBody::TbRow), crate::syntax::parser::adv(p_))),
            crate::syntax::lexer::TokKind::KName(n) if (((&n.sigils == &Text::lit("")) && (&len(&n.path_) == &Nat::from(1u32))) && (&crate::syntax::lexer::chars::last(&n.path_) == &crate::syntax::lexer::chars::last(&name.path_))) => {
                let p_ = p_.clone();
                call_then(start_parse_case(p_.clone()), move |parse_case_11752: (crate::syntax::decls::Case_, crate::syntax::parser::Ps)| {
                    let (c, q) = parse_case_11752;
                    prism_rtl::Turn::Finished((Some(crate::syntax::decls::TypeBody::TbNewtype(c.clone())), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KName(n) if is_unit_body(p_, &n, params) => {
                let (i, q) = crate::syntax::parser::parse_ident(p_);
                prism_rtl::Turn::Finished((Some(crate::syntax::decls::TypeBody::TbUnit(i.clone())), q.clone()))
            },
            _ => {
                let p_ = p_.clone();
                call_then(crate::syntax::parser::types::start_parse_type(p_.clone()), move |parse_type_12008: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (ty, q) = parse_type_12008;
                    prism_rtl::Turn::Finished((Some(crate::syntax::decls::TypeBody::TbAlias(ty.clone())), q.clone()))
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ParseTypeBody, x`: what the function value is when passed to `@Run`.
pub fn start_parse_type_body(p_: crate::syntax::parser::Ps, name: crate::syntax::QualName, params: Array<crate::syntax::Ident>) -> Rc<dyn prism_rtl::Job<(Option<crate::syntax::decls::TypeBody>, crate::syntax::parser::Ps)>> {
    Rc::new(ParseTypeBody { p_, name, params })
}

/// ```prism
/// IsUnitBody: fn Ps, NameTok, [Ident] -> Bool
/// ```
pub fn is_unit_body(p_: &crate::syntax::parser::Ps, n: &crate::syntax::lexer::NameTok, params: &Array<crate::syntax::Ident>) -> bool {
    let w = or(&index(&n.path_, &Nat::from(0u32)), &Text::lit(""));
    let param = fold(params, &false, &(|seen: &bool, i: &crate::syntax::Ident| *seen || (&i.name == &w)));
    let ends = match crate::syntax::parser::kind_at(p_, &Nat::from(1u32)) {
        crate::syntax::lexer::TokKind::KLaySep => true,
        crate::syntax::lexer::TokKind::KLayOpen => true,
        crate::syntax::lexer::TokKind::KLayClose => true,
        crate::syntax::lexer::TokKind::KEof => true,
        _ => false,
    };
    ((((&n.sigils == &Text::lit("")) && (&n.case == &crate::syntax::lexer::NameCase::CaseLower)) && (&len(&n.path_) == &Nat::from(1u32))) && !param) && ends
}

/// ```prism
/// ParseFieldBlock: unbounded fn Ps -> (([Field], Ps))
/// ```
pub fn parse_field_block(p0: &crate::syntax::parser::Ps) -> (Array<crate::syntax::decls::Field>, crate::syntax::parser::Ps) {
    let p_ = crate::syntax::parser::expect_colon(p0);
    if crate::syntax::parser::at_open_l(&p_) {
        crate::syntax::parser::layout_items(&crate::syntax::parser::adv(&p_), &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_field(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::Field, crate::syntax::parser::Ps)>>>))
    } else {
        (Array::new(), crate::syntax::parser::error_here(&p_, &Text::lit("fields stand in an indented block, one `name: Type` per line")))
    }
}

/// The step machine of `ParseFieldBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseFieldBlock: unbounded fn Ps -> (([Field], Ps))
/// ```
pub struct ParseFieldBlock {
    pub p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(Array<crate::syntax::decls::Field>, crate::syntax::parser::Ps)> for ParseFieldBlock {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::decls::Field>, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let p_ = crate::syntax::parser::expect_colon(p0);
        if crate::syntax::parser::at_open_l(&p_) {
            prism_rtl::Turn::More(Rc::new(crate::syntax::parser::LayoutItems { p0: crate::syntax::parser::adv(&p_), f_fn: Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_field(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::Field, crate::syntax::parser::Ps)>>> }))
        } else {
            prism_rtl::Turn::Finished((Array::new(), crate::syntax::parser::error_here(&p_, &Text::lit("fields stand in an indented block, one `name: Type` per line"))))
        }
    }
}

/// `Start ParseFieldBlock, x`: what the function value is when passed to `@Run`.
pub fn start_parse_field_block(p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::decls::Field>, crate::syntax::parser::Ps)>> {
    Rc::new(ParseFieldBlock { p0 })
}

/// ```prism
/// ParseField: unbounded fn Ps -> ((Field, Ps))
/// ```
pub fn parse_field(p_: &crate::syntax::parser::Ps) -> (crate::syntax::decls::Field, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p_);
    let (name, p1) = crate::syntax::parser::parse_ident(p_);
    let (ty, p2) = crate::syntax::parser::types::parse_type(&crate::syntax::parser::expect_colon(&p1));
    (crate::syntax::decls::Field { name: name.clone(), ty: ty.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p2)) }, p2.clone())
}

/// The step machine of `ParseField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseField: unbounded fn Ps -> ((Field, Ps))
/// ```
pub struct ParseField {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::Field, crate::syntax::parser::Ps)> for ParseField {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::Field, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let start = crate::syntax::parser::here(p_);
        let (name, p1) = crate::syntax::parser::parse_ident(p_);
        call_then(crate::syntax::parser::types::start_parse_type(crate::syntax::parser::expect_colon(&p1)), move |parse_type_12885: (crate::syntax::Type, crate::syntax::parser::Ps)| {
            let (ty, p2) = parse_type_12885;
            prism_rtl::Turn::Finished((crate::syntax::decls::Field { name: name.clone(), ty: ty.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p2)) }, p2.clone()))
        })
    }
}

/// `Start ParseField, x`: what the function value is when passed to `@Run`.
pub fn start_parse_field(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::Field, crate::syntax::parser::Ps)>> {
    Rc::new(ParseField { p_ })
}

/// ```prism
/// ParseCase: unbounded fn Ps -> ((Case, Ps))
/// ```
pub fn parse_case(p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::Case_, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p0);
    let (name, p1) = crate::syntax::parser::parse_sname(p0);
    let p2 = if &name.sigils != &Text::lit("") {
        crate::syntax::parser::note_error(&p1, &name.span, &Text::lit("a constructor takes no sigil"))
    } else {
        p1.clone()
    };
    if crate::syntax::parser::at_colon(&p2) {
        {
            let p3 = crate::syntax::parser::adv(&p2);
            let (args, p4) = if crate::syntax::parser::at_op(&p3, &Text::lit("->")) {
                (Array::new(), p3.clone())
            } else {
                crate::syntax::parser::commas(&p3, &(Rc::new(|a0: crate::syntax::parser::Ps| entered(crate::syntax::parser::types::start_parse_emit_type(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>>>))
            };
            let (result, p5) = crate::syntax::parser::types::parse_type(&crate::syntax::parser::expect_op(&p4, &Text::lit("->")));
            let p6 = crate::syntax::parser::out_of_scope(&p5, &start, &Text::lit("indexed choices/GADTs for user types"), &Text::from(format!("`{}` is an indexed alternative: indexed choices for user types are out of this compiler", &crate::syntax::parser::name_text(&name))));
            (crate::syntax::decls::Case_ { name: name.clone(), args: args.clone(), indexed: Some(result.clone()), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p6)) }, p6.clone())
        }
    } else {
        {
            let (args, p3) = if crate::syntax::parser::at_stmt_boundary(&p2) {
                (Array::new(), p2.clone())
            } else {
                crate::syntax::parser::commas(&p2, &(Rc::new(|a0: crate::syntax::parser::Ps| entered(crate::syntax::parser::types::start_parse_type(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>>>))
            };
            (crate::syntax::decls::Case_ { name: name.clone(), args: args.clone(), indexed: None, span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p3)) }, p3.clone())
        }
    }
}

/// The step machine of `ParseCase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseCase: unbounded fn Ps -> ((Case, Ps))
/// ```
pub struct ParseCase {
    pub p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::Case_, crate::syntax::parser::Ps)> for ParseCase {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::Case_, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let start = crate::syntax::parser::here(p0);
        let (name, p1) = crate::syntax::parser::parse_sname(p0);
        let p2 = if &name.sigils != &Text::lit("") {
            crate::syntax::parser::note_error(&p1, &name.span, &Text::lit("a constructor takes no sigil"))
        } else {
            p1.clone()
        };
        if crate::syntax::parser::at_colon(&p2) {
            {
                let p3 = crate::syntax::parser::adv(&p2);
                let (args, p4) = if crate::syntax::parser::at_op(&p3, &Text::lit("->")) {
                    (Array::new(), p3.clone())
                } else {
                    crate::syntax::parser::commas(&p3, &(Rc::new(|a0: crate::syntax::parser::Ps| entered(crate::syntax::parser::types::start_parse_emit_type(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>>>))
                };
                call_then(crate::syntax::parser::types::start_parse_type(crate::syntax::parser::expect_op(&p4, &Text::lit("->"))), move |parse_type_13499: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (result, p5) = parse_type_13499;
                    let p6 = crate::syntax::parser::out_of_scope(&p5, &start, &Text::lit("indexed choices/GADTs for user types"), &Text::from(format!("`{}` is an indexed alternative: indexed choices for user types are out of this compiler", &crate::syntax::parser::name_text(&name))));
                    prism_rtl::Turn::Finished((crate::syntax::decls::Case_ { name: name.clone(), args: args.clone(), indexed: Some(result.clone()), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p6)) }, p6.clone()))
                })
            }
        } else {
            {
                let (args, p3) = if crate::syntax::parser::at_stmt_boundary(&p2) {
                    (Array::new(), p2.clone())
                } else {
                    crate::syntax::parser::commas(&p2, &(Rc::new(|a0: crate::syntax::parser::Ps| entered(crate::syntax::parser::types::start_parse_type(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>>>))
                };
                prism_rtl::Turn::Finished((crate::syntax::decls::Case_ { name: name.clone(), args: args.clone(), indexed: None, span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p3)) }, p3.clone()))
            }
        }
    }
}

/// `Start ParseCase, x`: what the function value is when passed to `@Run`.
pub fn start_parse_case(p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::Case_, crate::syntax::parser::Ps)>> {
    Rc::new(ParseCase { p0 })
}

/// ```prism
/// ParseTagDecl: unbounded fn Ps -> ((TagDecl, Ps))
/// ```
pub fn parse_tag_decl(p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::TagDecl, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p0);
    let (name, p1) = crate::syntax::parser::parse_qual_name(&crate::syntax::parser::adv(p0));
    let (of_type, p2) = crate::syntax::parser::types::parse_type(&crate::syntax::parser::expect_kw(&p1, &Text::lit("of")));
    let (bounds, p3) = optional_bounds(&p2);
    let (fields, p4) = if crate::syntax::parser::at_colon(&p3) {
        parse_field_block(&p3)
    } else {
        (Array::new(), p3.clone())
    };
    (crate::syntax::decls::TagDecl { name: name.clone(), of_type: of_type.clone(), bounds: bounds.clone(), fields: fields.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p4)) }, p4.clone())
}

/// The step machine of `ParseTagDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTagDecl: unbounded fn Ps -> ((TagDecl, Ps))
/// ```
pub struct ParseTagDecl {
    pub p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::TagDecl, crate::syntax::parser::Ps)> for ParseTagDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::TagDecl, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let start = crate::syntax::parser::here(p0);
        let (name, p1) = crate::syntax::parser::parse_qual_name(&crate::syntax::parser::adv(p0));
        call_then(crate::syntax::parser::types::start_parse_type(crate::syntax::parser::expect_kw(&p1, &Text::lit("of"))), move |parse_type_14203: (crate::syntax::Type, crate::syntax::parser::Ps)| {
            let (of_type, p2) = parse_type_14203;
            call_then(start_optional_bounds(p2.clone()), move |optional_bounds_14258: (Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps)| {
                let (bounds, p3) = optional_bounds_14258;
                let (fields, p4) = if crate::syntax::parser::at_colon(&p3) {
                    parse_field_block(&p3)
                } else {
                    (Array::new(), p3.clone())
                };
                prism_rtl::Turn::Finished((crate::syntax::decls::TagDecl { name: name.clone(), of_type: of_type.clone(), bounds: bounds.clone(), fields: fields.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p4)) }, p4.clone()))
            })
        })
    }
}

/// `Start ParseTagDecl, x`: what the function value is when passed to `@Run`.
pub fn start_parse_tag_decl(p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TagDecl, crate::syntax::parser::Ps)>> {
    Rc::new(ParseTagDecl { p0 })
}

/// ```prism
/// ParseTraitDecl: unbounded fn Ps -> ((TraitDecl, Ps))
/// ```
pub fn parse_trait_decl(p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::TraitDecl, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p0);
    let (name, p1) = crate::syntax::parser::parse_trait_ref(&crate::syntax::parser::adv(p0));
    let (params, p2) = lower_params(&p1);
    let (bounds, p3) = optional_bounds(&p2);
    let (items, p4) = parse_trait_items(&p3);
    let decl = crate::syntax::decls::TraitDecl { name: name.clone(), params: params.clone(), bounds: bounds.clone(), items: items.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p4)) };
    (decl.clone(), check_higher_kinded(&p4, &decl))
}

/// The step machine of `ParseTraitDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTraitDecl: unbounded fn Ps -> ((TraitDecl, Ps))
/// ```
pub struct ParseTraitDecl {
    pub p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::TraitDecl, crate::syntax::parser::Ps)> for ParseTraitDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::TraitDecl, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let start = crate::syntax::parser::here(p0);
        let (name, p1) = crate::syntax::parser::parse_trait_ref(&crate::syntax::parser::adv(p0));
        let (params, p2) = lower_params(&p1);
        call_then(start_optional_bounds(p2.clone()), move |optional_bounds_14716: (Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps)| {
            let (bounds, p3) = optional_bounds_14716;
            call_then(start_parse_trait_items(p3.clone()), move |parse_trait_items_14758: (Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps)| {
                let (items, p4) = parse_trait_items_14758;
                let decl = crate::syntax::decls::TraitDecl { name: name.clone(), params: params.clone(), bounds: bounds.clone(), items: items.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p4)) };
                prism_rtl::Turn::Finished((decl.clone(), check_higher_kinded(&p4, &decl)))
            })
        })
    }
}

/// `Start ParseTraitDecl, x`: what the function value is when passed to `@Run`.
pub fn start_parse_trait_decl(p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TraitDecl, crate::syntax::parser::Ps)>> {
    Rc::new(ParseTraitDecl { p0 })
}

/// ```prism
/// ParseImplDecl: unbounded fn Ps -> ((ImplDecl, Ps))
/// ```
pub fn parse_impl_decl(p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::ImplDecl, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p0);
    let (trait_ref, p1) = crate::syntax::parser::parse_trait_ref(&crate::syntax::parser::adv(p0));
    let (ty, p2) = crate::syntax::parser::types::parse_type(&p1);
    let (bounds, p3) = optional_bounds(&p2);
    let (items, p4) = parse_trait_items(&p3);
    (crate::syntax::decls::ImplDecl { trait_ref: trait_ref.clone(), ty: ty.clone(), bounds: bounds.clone(), items: items.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p4)) }, p4.clone())
}

/// The step machine of `ParseImplDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseImplDecl: unbounded fn Ps -> ((ImplDecl, Ps))
/// ```
pub struct ParseImplDecl {
    pub p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::ImplDecl, crate::syntax::parser::Ps)> for ParseImplDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::ImplDecl, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let start = crate::syntax::parser::here(p0);
        let (trait_ref, p1) = crate::syntax::parser::parse_trait_ref(&crate::syntax::parser::adv(p0));
        call_then(crate::syntax::parser::types::start_parse_type(p1.clone()), move |parse_type_15144: (crate::syntax::Type, crate::syntax::parser::Ps)| {
            let (ty, p2) = parse_type_15144;
            call_then(start_optional_bounds(p2.clone()), move |optional_bounds_15182: (Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps)| {
                let (bounds, p3) = optional_bounds_15182;
                call_then(start_parse_trait_items(p3.clone()), move |parse_trait_items_15224: (Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps)| {
                    let (items, p4) = parse_trait_items_15224;
                    prism_rtl::Turn::Finished((crate::syntax::decls::ImplDecl { trait_ref: trait_ref.clone(), ty: ty.clone(), bounds: bounds.clone(), items: items.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p4)) }, p4.clone()))
                })
            })
        })
    }
}

/// `Start ParseImplDecl, x`: what the function value is when passed to `@Run`.
pub fn start_parse_impl_decl(p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::ImplDecl, crate::syntax::parser::Ps)>> {
    Rc::new(ParseImplDecl { p0 })
}

/// ```prism
/// ParseTraitItems: unbounded fn Ps -> (([TraitItem], Ps))
/// ```
pub fn parse_trait_items(p0: &crate::syntax::parser::Ps) -> (Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps) {
    let p_ = crate::syntax::parser::expect_colon(p0);
    if crate::syntax::parser::at_open_l(&p_) {
        {
            let inside = {
                let mut this: crate::syntax::parser::Ps = crate::syntax::parser::adv(&p_);
                this.in_trait = true;
                this
            };
            let (items, q) = crate::syntax::parser::layout_items(&inside, &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_trait_item(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TraitItem, crate::syntax::parser::Ps)>>>));
            (items.clone(), {
                let mut this: crate::syntax::parser::Ps = q.clone();
                this.in_trait = p_.in_trait;
                this
            })
        }
    } else {
        (Array::new(), crate::syntax::parser::error_here(&p_, &Text::lit("a trait\'s or impl\'s items stand in an indented block")))
    }
}

/// The step machine of `ParseTraitItems`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTraitItems: unbounded fn Ps -> (([TraitItem], Ps))
/// ```
pub struct ParseTraitItems {
    pub p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps)> for ParseTraitItems {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let p_ = crate::syntax::parser::expect_colon(p0);
        if crate::syntax::parser::at_open_l(&p_) {
            {
                let inside = {
                    let mut this: crate::syntax::parser::Ps = crate::syntax::parser::adv(&p_);
                    this.in_trait = true;
                    this
                };
                call_then(crate::syntax::parser::start_layout_items(inside.clone(), Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_trait_item(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TraitItem, crate::syntax::parser::Ps)>>>), move |layout_items_15566: (Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps)| {
                    let (items, q) = layout_items_15566;
                    prism_rtl::Turn::Finished((items.clone(), {
                        let mut this: crate::syntax::parser::Ps = q.clone();
                        this.in_trait = p_.in_trait;
                        this
                    }))
                })
            }
        } else {
            prism_rtl::Turn::Finished((Array::new(), crate::syntax::parser::error_here(&p_, &Text::lit("a trait\'s or impl\'s items stand in an indented block"))))
        }
    }
}

/// `Start ParseTraitItems, x`: what the function value is when passed to `@Run`.
pub fn start_parse_trait_items(p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps)>> {
    Rc::new(ParseTraitItems { p0 })
}

/// ```prism
/// ParseTraitItem: unbounded fn Ps -> ((TraitItem, Ps))
/// ```
pub fn parse_trait_item(p_: &crate::syntax::parser::Ps) -> (crate::syntax::decls::TraitItem, crate::syntax::parser::Ps) {
    match crate::syntax::parser::kind(p_) {
        crate::syntax::lexer::TokKind::KKw(m15834_0_0, _) if (&m15834_0_0 == &Text::lit("fn")) => {
            let (f, q) = parse_fn_clause(p_);
            (crate::syntax::decls::TraitItem::TiFn(f.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m15834_1_0, _) if (&m15834_1_0 == &Text::lit("type")) => {
            let start = crate::syntax::parser::here(p_);
            let p1 = crate::syntax::parser::adv(p_);
            match crate::syntax::parser::kind(&p1) {
                crate::syntax::lexer::TokKind::KName(n) if (((&n.case == &crate::syntax::lexer::NameCase::CaseUpper) && (&n.sigils == &Text::lit(""))) && (&len(&n.path_) == &Nat::from(1u32))) => {
                    let name = crate::syntax::Ident { name: or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")), span: crate::syntax::parser::here(&p1) };
                    let (params, p2) = lower_params(&crate::syntax::parser::adv(&p1));
                    let (value_opt, p3) = if crate::syntax::parser::at_op(&p2, &Text::lit("=")) {
                        optional_type(&crate::syntax::parser::adv(&p2))
                    } else {
                        (None, p2.clone())
                    };
                    let item = crate::syntax::decls::TraitItem::TiAssocType(name.clone(), params.clone(), value_opt.clone(), crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p3)));
                    (item.clone(), p3.clone())
                },
                _ => {
                    let item = crate::syntax::decls::TraitItem::TiAssocType(crate::syntax::parser::no_ident(), Array::new(), None, crate::syntax::parser::no_range());
                    (item.clone(), crate::syntax::parser::error_here(&p1, &Text::lit("expected the associated type\'s name")))
                },
                _ => unreachable!("no arm matched"),
            }
        },
        crate::syntax::lexer::TokKind::KKw(m15834_2_0, _) if (&m15834_2_0 == &Text::lit("row")) => {
            let start = crate::syntax::parser::here(p_);
            let (name, q) = crate::syntax::parser::parse_sname(&crate::syntax::parser::adv(p_));
            let item = crate::syntax::decls::TraitItem::TiAssocRow(name.clone(), crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)));
            (item.clone(), q.clone())
        },
        _ => {
            let (sig, q) = parse_signature(p_);
            (crate::syntax::decls::TraitItem::TiSignature(sig.clone()), q.clone())
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ParseTraitItem`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTraitItem: unbounded fn Ps -> ((TraitItem, Ps))
/// ```
pub struct ParseTraitItem {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::TraitItem, crate::syntax::parser::Ps)> for ParseTraitItem {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::TraitItem, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        match crate::syntax::parser::kind(p_) {
            crate::syntax::lexer::TokKind::KKw(m15834_0_0, _) if (&m15834_0_0 == &Text::lit("fn")) => {
                let p_ = p_.clone();
                call_then(start_parse_fn_clause(p_.clone()), move |parse_fn_clause_15893: (crate::syntax::decls::FnClause, crate::syntax::parser::Ps)| {
                    let (f, q) = parse_fn_clause_15893;
                    prism_rtl::Turn::Finished((crate::syntax::decls::TraitItem::TiFn(f.clone()), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m15834_1_0, _) if (&m15834_1_0 == &Text::lit("type")) => {
                let start = crate::syntax::parser::here(p_);
                let p1 = crate::syntax::parser::adv(p_);
                match crate::syntax::parser::kind(&p1) {
                    crate::syntax::lexer::TokKind::KName(n) if (((&n.case == &crate::syntax::lexer::NameCase::CaseUpper) && (&n.sigils == &Text::lit(""))) && (&len(&n.path_) == &Nat::from(1u32))) => {
                        let name = crate::syntax::Ident { name: or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")), span: crate::syntax::parser::here(&p1) };
                        let (params, p2) = lower_params(&crate::syntax::parser::adv(&p1));
                        let (value_opt, p3) = if crate::syntax::parser::at_op(&p2, &Text::lit("=")) {
                            optional_type(&crate::syntax::parser::adv(&p2))
                        } else {
                            (None, p2.clone())
                        };
                        let item = crate::syntax::decls::TraitItem::TiAssocType(name.clone(), params.clone(), value_opt.clone(), crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p3)));
                        prism_rtl::Turn::Finished((item.clone(), p3.clone()))
                    },
                    _ => {
                        let item = crate::syntax::decls::TraitItem::TiAssocType(crate::syntax::parser::no_ident(), Array::new(), None, crate::syntax::parser::no_range());
                        prism_rtl::Turn::Finished((item.clone(), crate::syntax::parser::error_here(&p1, &Text::lit("expected the associated type\'s name"))))
                    },
                    _ => unreachable!("no arm matched"),
                }
            },
            crate::syntax::lexer::TokKind::KKw(m15834_2_0, _) if (&m15834_2_0 == &Text::lit("row")) => {
                let start = crate::syntax::parser::here(p_);
                let (name, q) = crate::syntax::parser::parse_sname(&crate::syntax::parser::adv(p_));
                let item = crate::syntax::decls::TraitItem::TiAssocRow(name.clone(), crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)));
                prism_rtl::Turn::Finished((item.clone(), q.clone()))
            },
            _ => {
                let p_ = p_.clone();
                call_then(start_parse_signature(p_.clone()), move |parse_signature_16833: (crate::syntax::decls::Signature, crate::syntax::parser::Ps)| {
                    let (sig, q) = parse_signature_16833;
                    prism_rtl::Turn::Finished((crate::syntax::decls::TraitItem::TiSignature(sig.clone()), q.clone()))
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ParseTraitItem, x`: what the function value is when passed to `@Run`.
pub fn start_parse_trait_item(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TraitItem, crate::syntax::parser::Ps)>> {
    Rc::new(ParseTraitItem { p_ })
}

/// ```prism
/// OptionalType: unbounded fn Ps -> ((?Type, Ps))
/// ```
pub fn optional_type(p_: &crate::syntax::parser::Ps) -> (Option<crate::syntax::Type>, crate::syntax::parser::Ps) {
    let (ty, q) = crate::syntax::parser::types::parse_type(p_);
    (Some(ty.clone()), q.clone())
}

/// The step machine of `OptionalType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptionalType: unbounded fn Ps -> ((?Type, Ps))
/// ```
pub struct OptionalType {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(Option<crate::syntax::Type>, crate::syntax::parser::Ps)> for OptionalType {
    fn cycle(&self) -> prism_rtl::Turn<(Option<crate::syntax::Type>, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let p_ = p_.clone();
        call_then(crate::syntax::parser::types::start_parse_type(p_.clone()), move |parse_type_16968: (crate::syntax::Type, crate::syntax::parser::Ps)| {
            let (ty, q) = parse_type_16968;
            prism_rtl::Turn::Finished((Some(ty.clone()), q.clone()))
        })
    }
}

/// `Start OptionalType, x`: what the function value is when passed to `@Run`.
pub fn start_optional_type(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(Option<crate::syntax::Type>, crate::syntax::parser::Ps)>> {
    Rc::new(OptionalType { p_ })
}

/// ```prism
/// CheckHigherKinded: fn Ps, TraitDecl -> Ps
/// ```
pub fn check_higher_kinded(p_: &crate::syntax::parser::Ps, t: &crate::syntax::decls::TraitDecl) -> crate::syntax::parser::Ps {
    let hk = fold(&t.items, &false, &(|seen: &bool, item: &crate::syntax::decls::TraitItem| *seen || item_applies(item, &t.params)));
    if hk && (&t.name.path_ != &Array::from(vec![Text::lit("Monad")])) {
        crate::syntax::parser::out_of_scope(p_, &t.name.span, &Text::lit("higher-kinded traits"), &Text::from(format!("`^{}` applies its parameter to arguments: higher-kinded traits are out of this compiler", &crate::syntax::lexer::chars::join(&t.name.path_, &Text::lit(".")))))
    } else {
        p_.clone()
    }
}

/// ```prism
/// ItemApplies: fn TraitItem, [Ident] -> Bool
/// ```
pub fn item_applies(trait_item0: &crate::syntax::decls::TraitItem, xs1: &Array<crate::syntax::Ident>) -> bool {
    match (trait_item0, xs1) {
        (crate::syntax::decls::TraitItem::TiSignature(s), params) => applies(&s.ty, params),
        (_, _) => false,
    }
}

/// ```prism
/// AnyApplies: fn [Type], [Ident] -> Bool
/// ```
pub fn any_applies(ts: &Array<crate::syntax::Type>, params: &Array<crate::syntax::Ident>) -> bool {
    fold(ts, &false, &(|seen: &bool, t: &crate::syntax::Type| *seen || applies(t, params)))
}

/// ```prism
/// Applies: fn Type, [Ident] -> Bool
/// ```
pub fn applies(ty: &crate::syntax::Type, params: &Array<crate::syntax::Ident>) -> bool {
    match &*ty.kind {
        crate::syntax::TypeKind::TName(name, args) => {
            let head = ((&len(args) > &Nat::from(0u32)) && (&len(&name.path_) == &Nat::from(1u32))) && fold(params, &false, &(|seen: &bool, i: &crate::syntax::Ident| *seen || (&i.name == &or(&index(&name.path_, &Nat::from(0u32)), &Text::lit("")))));
            head || any_applies(args, params)
        },
        crate::syntax::TypeKind::TSigiled(_, inner) => applies(&**inner, params),
        crate::syntax::TypeKind::TGroup(inner) => applies(&**inner, params),
        crate::syntax::TypeKind::TNonEmpty(inner) => applies(&**inner, params),
        crate::syntax::TypeKind::TArray(elem, _) => applies(&**elem, params),
        crate::syntax::TypeKind::TTuple(ts) => any_applies(ts, params),
        crate::syntax::TypeKind::TRowUnion(ts) => any_applies(ts, params),
        crate::syntax::TypeKind::TMap(k, v_) => applies(&**k, params) || applies(&**v_, params),
        crate::syntax::TypeKind::TFn(_, ps, result) => any_applies(ps, params) || applies(&**result, params),
        crate::syntax::TypeKind::TEmit(t, r) => applies(&**t, params) || applies(&**r, params),
        _ => false,
    }
}
