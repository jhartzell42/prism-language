//! The module `Syntax.Parser.Decls`, from `target/bootstrap/src/prismc/syntax/parser/decls.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `ModRead`:
///
/// ```prism
/// type ModRead = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ModRead {
    pub p_: crate::syntax::parser::Ps,
    pub m: crate::syntax::Module,
    pub stage: Nat,
}

impl Show for ModRead {
    fn show(&self, p: &mut Printer) {
        p.record("ModRead", &[("p", &self.p_), ("m", &self.m), ("stage", &self.stage)]);
    }
}

impl ToPod for ModRead {
    fn to_pod(&self) -> Pod {
        Pod::record("ModRead", vec![("p", self.p_.to_pod()), ("m", self.m.to_pod()), ("stage", self.stage.to_pod())])
    }
}

impl FromPod for ModRead {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ModRead { p_: FromPod::from_pod(field(p, "p")?)?, m: FromPod::from_pod(field(p, "m")?)?, stage: FromPod::from_pod(field(p, "stage")?)? })
    }
}

/// ```prism
/// ParseModule: unbounded fn Ps, Bool -> ((Module, Ps))
/// ```
pub fn parse_module(p0_p0: &crate::syntax::parser::Ps, fragment_p1: &bool) -> (crate::syntax::Module, crate::syntax::parser::Ps) {
    let start_p2 = crate::syntax::parser::here(p0_p0);
    let (template_o9, p1_pa) = match crate::syntax::parser::kind(p0_p0) {
        crate::syntax::lexer::TokKind::KTemplate(t_p6) => {
            let (tpl_p7, q_p8) = crate::syntax::parser::expr::parse_template(&crate::syntax::parser::adv(p0_p0), &t_p6, &crate::syntax::parser::here(p0_p0));
            (Some(tpl_p7.clone()), q_p8.clone())
        },
        _ => (None, p0_p0.clone()),
    };
    let m0_p3 = crate::syntax::Module { name: None, emit_row: None, mods: Array::new(), uses: Array::new(), decls: Array::new(), template: template_o9.clone(), span: start_p2.clone() };
    let r_p4 = {
        let mut this: ModRead = ModRead { p_: p1_pa.clone(), m: m0_p3.clone(), stage: Nat::from(0u32) };
        while !crate::syntax::parser::at_eof(&this.p_) {
            this = module_item(&this, fragment_p1);
        }
        this
    };
    let m_p5 = {
        let mut this: crate::syntax::Module = r_p4.m.clone();
        this.span = crate::syntax::parser::to(&start_p2, &crate::syntax::parser::prev(&r_p4.p_));
        this
    };
    (m_p5.clone(), r_p4.p_.clone())
}

/// The step machine of `ParseModule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseModule: unbounded fn Ps, Bool -> ((Module, Ps))
/// ```
pub struct ParseModule {
    pub p0_p0: crate::syntax::parser::Ps,
    pub fragment_p1: bool,
}

impl prism_rtl::Job<(crate::syntax::Module, crate::syntax::parser::Ps)> for ParseModule {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Module, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let fragment_p1 = &self.fragment_p1;
        let start_p2 = crate::syntax::parser::here(p0_p0);
        let (template_o9, p1_pa) = match crate::syntax::parser::kind(p0_p0) {
            crate::syntax::lexer::TokKind::KTemplate(t_p6) => {
                let (tpl_p7, q_p8) = crate::syntax::parser::expr::parse_template(&crate::syntax::parser::adv(p0_p0), &t_p6, &crate::syntax::parser::here(p0_p0));
                (Some(tpl_p7.clone()), q_p8.clone())
            },
            _ => (None, p0_p0.clone()),
        };
        let m0_p3 = crate::syntax::Module { name: None, emit_row: None, mods: Array::new(), uses: Array::new(), decls: Array::new(), template: template_o9.clone(), span: start_p2.clone() };
        let mut this: ModRead = ModRead { p_: p1_pa.clone(), m: m0_p3.clone(), stage: Nat::from(0u32) };
        let start_p2 = start_p2.clone();
        call_then(loop_job((this,), {
            let fragment_p1 = *fragment_p1;
            move |(mut this,): (ModRead,)| if !crate::syntax::parser::at_eof(&this.p_) {
                {
                    this = module_item(&this, &fragment_p1);
                    Ok((this,))
                }
            } else {
                Err((this,))
            }
        }), move |(mut this,): (ModRead,)| {
            let r_p4 = this;
            let m_p5 = {
                let mut this: crate::syntax::Module = r_p4.m.clone();
                this.span = crate::syntax::parser::to(&start_p2, &crate::syntax::parser::prev(&r_p4.p_));
                this
            };
            prism_rtl::Turn::Finished((m_p5.clone(), r_p4.p_.clone()))
        })
    }
}

/// `Start ParseModule, x`: what the function value is when passed to `@Run`.
pub fn start_parse_module(p0_p0: crate::syntax::parser::Ps, fragment_p1: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Module, crate::syntax::parser::Ps)>> {
    Rc::new(ParseModule { p0_p0, fragment_p1 })
}

/// ```prism
/// ModuleItem: unbounded fn ModRead, Bool -> ModRead
/// ```
pub fn module_item(s_p0: &ModRead, fragment_p1: &bool) -> ModRead {
    if crate::syntax::parser::at_sep(&s_p0.p_) {
        {
            let mut this: ModRead = s_p0.clone();
            this.p_ = crate::syntax::parser::adv(&this.p_);
            this
        }
    } else {
        {
            let s1_p2 = header_or_decl(s_p0, fragment_p1, &crate::syntax::parser::here(&s_p0.p_));
            let p2_p3 = crate::syntax::parser::recovered(&s1_p2.p_);
            let p3_p4 = if crate::syntax::parser::at_close_l(&p2_p3) {
                crate::syntax::parser::adv(&p2_p3)
            } else {
                if crate::syntax::parser::at_eof(&p2_p3) {
                    p2_p3.clone()
                } else {
                    crate::syntax::parser::expect_stmt_end(&p2_p3, &Text::lit("declaration"))
                }
            };
            {
                let mut this: ModRead = s1_p2.clone();
                this.p_ = p3_p4.clone();
                this
            }
        }
    }
}

/// The step machine of `ModuleItem`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModuleItem: unbounded fn ModRead, Bool -> ModRead
/// ```
pub struct ModuleItem {
    pub s_p0: ModRead,
    pub fragment_p1: bool,
}

impl prism_rtl::Job<ModRead> for ModuleItem {
    fn cycle(&self) -> prism_rtl::Turn<ModRead> {
        let s_p0 = &self.s_p0;
        let fragment_p1 = &self.fragment_p1;
        if crate::syntax::parser::at_sep(&s_p0.p_) {
            prism_rtl::Turn::Finished({
                let mut this: ModRead = s_p0.clone();
                this.p_ = crate::syntax::parser::adv(&this.p_);
                this
            })
        } else {
            {
                let fragment_p1 = *fragment_p1;
                let s_p0 = s_p0.clone();
                call_then(start_header_or_decl(s_p0.clone(), fragment_p1, crate::syntax::parser::here(&s_p0.p_)), move |header_or_decl_1962: ModRead| {
                    let s1_p2 = header_or_decl_1962;
                    call_then(crate::syntax::parser::start_recovered(s1_p2.p_.clone()), move |recovered_2016: crate::syntax::parser::Ps| {
                        let p2_p3 = recovered_2016;
                        let p3_p4 = if crate::syntax::parser::at_close_l(&p2_p3) {
                            crate::syntax::parser::adv(&p2_p3)
                        } else {
                            if crate::syntax::parser::at_eof(&p2_p3) {
                                p2_p3.clone()
                            } else {
                                crate::syntax::parser::expect_stmt_end(&p2_p3, &Text::lit("declaration"))
                            }
                        };
                        prism_rtl::Turn::Finished({
                            let mut this: ModRead = s1_p2.clone();
                            this.p_ = p3_p4.clone();
                            this
                        })
                    })
                })
            }
        }
    }
}

/// `Start ModuleItem, x`: what the function value is when passed to `@Run`.
pub fn start_module_item(s_p0: ModRead, fragment_p1: bool) -> Rc<dyn prism_rtl::Job<ModRead>> {
    Rc::new(ModuleItem { s_p0, fragment_p1 })
}

/// ```prism
/// HeaderOrDecl: unbounded fn ModRead, Bool, Range -> ModRead
/// ```
pub fn header_or_decl(s_p0: &ModRead, fragment_p1: &bool, item_start_p2: &crate::syntax::Range) -> ModRead {
    match crate::syntax::parser::kind(&s_p0.p_) {
        crate::syntax::lexer::TokKind::KKw(m2338_0_0, m2338_0_1) if (&m2338_0_0 == &Text::lit("module")) && (&m2338_0_1 == &Text::lit("")) => {
            let (name_p3, p_p4) = crate::syntax::parser::parse_qual_name(&crate::syntax::parser::adv(&s_p0.p_));
            if p_p4.bad {
                {
                    let mut this: ModRead = s_p0.clone();
                    this.p_ = p_p4.clone();
                    this
                }
            } else {
                {
                    let late_p5 = (&s_p0.stage > &Nat::from(0u32)) || (&s_p0.m.name != &None);
                    {
                        let mut this: ModRead = s_p0.clone();
                        this.p_ = if late_p5 {
                            crate::syntax::parser::note_error(&p_p4, item_start_p2, &Text::lit("the `module` line comes first in a file"))
                        } else {
                            p_p4.clone()
                        };
                        this.m.name = Some(name_p3.clone());
                        this.stage = Nat::from(1u32);
                        this
                    }
                }
            }
        },
        crate::syntax::lexer::TokKind::KKw(m2338_1_0, m2338_1_1) if (&m2338_1_0 == &Text::lit("emit")) && (&m2338_1_1 == &Text::lit("")) => {
            let (emit_row_p6, p_p7) = crate::syntax::parser::types::parse_row(&crate::syntax::parser::adv(&s_p0.p_));
            if p_p7.bad {
                {
                    let mut this: ModRead = s_p0.clone();
                    this.p_ = p_p7.clone();
                    this
                }
            } else {
                {
                    let late_p8 = (&s_p0.stage > &Nat::from(1u32)) || (&s_p0.m.emit_row != &None);
                    {
                        let mut this: ModRead = s_p0.clone();
                        this.p_ = if late_p8 {
                            crate::syntax::parser::note_error(&p_p7, item_start_p2, &Text::lit("`emit` comes after `module` and above `use`, once (Semantics ch. 6)"))
                        } else {
                            p_p7.clone()
                        };
                        this.m.emit_row = Some(emit_row_p6.clone());
                        this.stage = Nat::from(2u32);
                        this
                    }
                }
            }
        },
        crate::syntax::lexer::TokKind::KKw(m2338_2_0, m2338_2_1) if (&m2338_2_0 == &Text::lit("use")) && (&m2338_2_1 == &Text::lit("")) => {
            let (u_p9, p_pa) = parse_use(&crate::syntax::parser::adv(&s_p0.p_), item_start_p2);
            if p_pa.bad {
                {
                    let mut this: ModRead = s_p0.clone();
                    this.p_ = p_pa.clone();
                    this
                }
            } else {
                {
                    let mut this: ModRead = s_p0.clone();
                    this.p_ = if &s_p0.stage > &Nat::from(4u32) {
                        crate::syntax::parser::note_error(&p_pa, item_start_p2, &Text::lit("`use` lines belong to the header, above the declarations"))
                    } else {
                        p_pa.clone()
                    };
                    this.m.uses = push(&this.m.uses, &u_p9);
                    this.stage = Nat::from(4u32);
                    this
                }
            }
        },
        crate::syntax::lexer::TokKind::KKw(m2338_3_0, m2338_3_1) if (&m2338_3_0 == &Text::lit("mod")) && (&m2338_3_1 == &Text::lit("")) => mod_header(s_p0, &crate::syntax::parser::adv(&s_p0.p_), &false, item_start_p2),
        crate::syntax::lexer::TokKind::KKw(m2338_4_0, m2338_4_1) if (&m2338_4_0 == &Text::lit("test")) && (&m2338_4_1 == &Text::lit("")) && is_kw_kind(&crate::syntax::parser::kind(&crate::syntax::parser::adv(&s_p0.p_)), &Text::lit("mod")) => mod_header(s_p0, &crate::syntax::parser::adv(&crate::syntax::parser::adv(&s_p0.p_)), &true, item_start_p2),
        _ => {
            let (d_pb, p_pc) = parse_decl(&s_p0.p_, fragment_p1);
            {
                let mut this: ModRead = s_p0.clone();
                this.p_ = p_pc.clone();
                this.stage = Nat::from(5u32);
                if !p_pc.bad {
                    this.m.decls = push(&this.m.decls, &d_pb);
                }
                this
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `HeaderOrDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HeaderOrDecl: unbounded fn ModRead, Bool, Range -> ModRead
/// ```
pub struct HeaderOrDecl {
    pub s_p0: ModRead,
    pub fragment_p1: bool,
    pub item_start_p2: crate::syntax::Range,
}

impl prism_rtl::Job<ModRead> for HeaderOrDecl {
    fn cycle(&self) -> prism_rtl::Turn<ModRead> {
        let s_p0 = &self.s_p0;
        let fragment_p1 = &self.fragment_p1;
        let item_start_p2 = &self.item_start_p2;
        match crate::syntax::parser::kind(&s_p0.p_) {
            crate::syntax::lexer::TokKind::KKw(m2338_0_0, m2338_0_1) if (&m2338_0_0 == &Text::lit("module")) && (&m2338_0_1 == &Text::lit("")) => {
                let (name_p3, p_p4) = crate::syntax::parser::parse_qual_name(&crate::syntax::parser::adv(&s_p0.p_));
                if p_p4.bad {
                    prism_rtl::Turn::Finished({
                        let mut this: ModRead = s_p0.clone();
                        this.p_ = p_p4.clone();
                        this
                    })
                } else {
                    {
                        let late_p5 = (&s_p0.stage > &Nat::from(0u32)) || (&s_p0.m.name != &None);
                        prism_rtl::Turn::Finished({
                            let mut this: ModRead = s_p0.clone();
                            this.p_ = if late_p5 {
                                crate::syntax::parser::note_error(&p_p4, item_start_p2, &Text::lit("the `module` line comes first in a file"))
                            } else {
                                p_p4.clone()
                            };
                            this.m.name = Some(name_p3.clone());
                            this.stage = Nat::from(1u32);
                            this
                        })
                    }
                }
            },
            crate::syntax::lexer::TokKind::KKw(m2338_1_0, m2338_1_1) if (&m2338_1_0 == &Text::lit("emit")) && (&m2338_1_1 == &Text::lit("")) => {
                let item_start_p2 = item_start_p2.clone();
                let s_p0 = s_p0.clone();
                call_then(crate::syntax::parser::types::start_parse_row(crate::syntax::parser::adv(&s_p0.p_)), move |parse_row_2789: (crate::syntax::Row_, crate::syntax::parser::Ps)| {
                    let (emit_row_p6, p_p7) = parse_row_2789;
                    if p_p7.bad {
                        prism_rtl::Turn::Finished({
                            let mut this: ModRead = s_p0.clone();
                            this.p_ = p_p7.clone();
                            this
                        })
                    } else {
                        {
                            let late_p8 = (&s_p0.stage > &Nat::from(1u32)) || (&s_p0.m.emit_row != &None);
                            prism_rtl::Turn::Finished({
                                let mut this: ModRead = s_p0.clone();
                                this.p_ = if late_p8 {
                                    crate::syntax::parser::note_error(&p_p7, &item_start_p2, &Text::lit("`emit` comes after `module` and above `use`, once (Semantics ch. 6)"))
                                } else {
                                    p_p7.clone()
                                };
                                this.m.emit_row = Some(emit_row_p6.clone());
                                this.stage = Nat::from(2u32);
                                this
                            })
                        }
                    }
                })
            },
            crate::syntax::lexer::TokKind::KKw(m2338_2_0, m2338_2_1) if (&m2338_2_0 == &Text::lit("use")) && (&m2338_2_1 == &Text::lit("")) => {
                let (u_p9, p_pa) = parse_use(&crate::syntax::parser::adv(&s_p0.p_), item_start_p2);
                if p_pa.bad {
                    prism_rtl::Turn::Finished({
                        let mut this: ModRead = s_p0.clone();
                        this.p_ = p_pa.clone();
                        this
                    })
                } else {
                    prism_rtl::Turn::Finished({
                        let mut this: ModRead = s_p0.clone();
                        this.p_ = if &s_p0.stage > &Nat::from(4u32) {
                            crate::syntax::parser::note_error(&p_pa, item_start_p2, &Text::lit("`use` lines belong to the header, above the declarations"))
                        } else {
                            p_pa.clone()
                        };
                        this.m.uses = push(&this.m.uses, &u_p9);
                        this.stage = Nat::from(4u32);
                        this
                    })
                }
            },
            crate::syntax::lexer::TokKind::KKw(m2338_3_0, m2338_3_1) if (&m2338_3_0 == &Text::lit("mod")) && (&m2338_3_1 == &Text::lit("")) => prism_rtl::Turn::Finished(mod_header(s_p0, &crate::syntax::parser::adv(&s_p0.p_), &false, item_start_p2)),
            crate::syntax::lexer::TokKind::KKw(m2338_4_0, m2338_4_1) if (&m2338_4_0 == &Text::lit("test")) && (&m2338_4_1 == &Text::lit("")) && is_kw_kind(&crate::syntax::parser::kind(&crate::syntax::parser::adv(&s_p0.p_)), &Text::lit("mod")) => prism_rtl::Turn::Finished(mod_header(s_p0, &crate::syntax::parser::adv(&crate::syntax::parser::adv(&s_p0.p_)), &true, item_start_p2)),
            _ => {
                let fragment_p1 = *fragment_p1;
                let s_p0 = s_p0.clone();
                call_then(start_parse_decl(s_p0.p_.clone(), fragment_p1), move |parse_decl_3725: (crate::syntax::decls::Decl, crate::syntax::parser::Ps)| {
                    let (d_pb, p_pc) = parse_decl_3725;
                    prism_rtl::Turn::Finished({
                        let mut this: ModRead = s_p0.clone();
                        this.p_ = p_pc.clone();
                        this.stage = Nat::from(5u32);
                        if !p_pc.bad {
                            this.m.decls = push(&this.m.decls, &d_pb);
                        }
                        this
                    })
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start HeaderOrDecl, x`: what the function value is when passed to `@Run`.
pub fn start_header_or_decl(s_p0: ModRead, fragment_p1: bool, item_start_p2: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<ModRead>> {
    Rc::new(HeaderOrDecl { s_p0, fragment_p1, item_start_p2 })
}

/// ```prism
/// ModHeader: fn ModRead, Ps, Bool, Range -> ModRead
/// ```
pub fn mod_header(s_p0: &ModRead, p_p1: &crate::syntax::parser::Ps, is_test_p2: &bool, item_start_p3: &crate::syntax::Range) -> ModRead {
    match crate::syntax::parser::kind(p_p1) {
        crate::syntax::lexer::TokKind::KName(n_p4) if ((&n_p4.sigils == &Text::lit("")) && (&len(&n_p4.path_) == &Nat::from(1u32))) => {
            let line_p5 = crate::syntax::ModLine { name: crate::syntax::Ident { name: or(&index(&n_p4.path_, &Nat::from(0u32)), &Text::lit("")), span: crate::syntax::parser::here(p_p1) }, is_test: *is_test_p2, span: crate::syntax::parser::to(item_start_p3, &crate::syntax::parser::here(p_p1)) };
            {
                let mut this: ModRead = s_p0.clone();
                this.p_ = if &s_p0.stage > &Nat::from(3u32) {
                    crate::syntax::parser::note_error(&crate::syntax::parser::adv(p_p1), item_start_p3, &Text::lit("`mod` lines come after `emit` and above `use` (claude/modules-style-pass.md)"))
                } else {
                    crate::syntax::parser::adv(p_p1)
                };
                this.m.mods = push(&this.m.mods, &line_p5);
                this.stage = Nat::from(3u32);
                this
            }
        },
        _ => {
            let mut this: ModRead = s_p0.clone();
            this.p_ = crate::syntax::parser::error_here(p_p1, &(if *is_test_p2 {
                Text::lit("expected a test module\'s name after `test mod`")
            } else {
                Text::lit("expected a module\'s name after `mod`")
            }));
            this
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IsKwKind: fn TokKind, Text -> Bool
/// ```
pub fn is_kw_kind(k_p0: &crate::syntax::lexer::TokKind, w_p1: &Text) -> bool {
    match k_p0 {
        crate::syntax::lexer::TokKind::KKw(x_p2, _) => x_p2 == w_p1,
        _ => false,
    }
}

/// ```prism
/// let noQual
/// ```
pub fn no_qual() -> crate::syntax::QualName {
    crate::syntax::QualName { path_: Array::new(), span: crate::syntax::parser::no_range() }
}

/// ```prism
/// ParseUse: fn Ps, Range -> ((Use, Ps))
/// ```
pub fn parse_use(p_p0: &crate::syntax::parser::Ps, start_p1: &crate::syntax::Range) -> (crate::syntax::Use, crate::syntax::parser::Ps) {
    match crate::syntax::parser::kind(p_p0) {
        crate::syntax::lexer::TokKind::KFamily(path_p2) => (crate::syntax::Use { target: crate::syntax::QualName { path_: path_p2.clone(), span: crate::syntax::parser::here(p_p0) }, star: true, span: crate::syntax::parser::to(start_p1, &crate::syntax::parser::here(p_p0)) }, crate::syntax::parser::adv(p_p0)),
        crate::syntax::lexer::TokKind::KName(n_p3) if ((&n_p3.sigils == &Text::lit("")) && (&n_p3.case == &crate::syntax::lexer::NameCase::CaseUpper)) => (crate::syntax::Use { target: crate::syntax::QualName { path_: n_p3.path_.clone(), span: crate::syntax::parser::here(p_p0) }, star: false, span: crate::syntax::parser::to(start_p1, &crate::syntax::parser::here(p_p0)) }, crate::syntax::parser::adv(p_p0)),
        _ => (crate::syntax::Use { target: no_qual(), star: false, span: crate::syntax::parser::no_range() }, crate::syntax::parser::error_here(p_p0, &Text::lit("expected a module name after `use`"))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// let noExpr
/// ```
pub fn no_expr() -> crate::syntax::Expr {
    crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: crate::syntax::parser::no_range() }
}

/// ```prism
/// let noType
/// ```
pub fn no_type() -> crate::syntax::Type {
    crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TAbsent), span: crate::syntax::parser::no_range() }
}

/// ```prism
/// let noPattern
/// ```
pub fn no_pattern() -> crate::syntax::Pattern_ {
    crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: crate::syntax::parser::no_range() }
}

/// ```prism
/// let noBlock
/// ```
pub fn no_block() -> crate::syntax::Block {
    crate::syntax::Block { stmts: Array::new(), inline: true, span: crate::syntax::parser::no_range() }
}

/// ```prism
/// ParseDecl: unbounded fn Ps, Bool -> ((Decl, Ps))
/// ```
pub fn parse_decl(p_p0: &crate::syntax::parser::Ps, fragment_p1: &bool) -> (crate::syntax::decls::Decl, crate::syntax::parser::Ps) {
    let start_p2 = crate::syntax::parser::here(p_p0);
    let (kind_p3, q_p4) = decl_kind_of(p_p0, fragment_p1, &start_p2);
    (crate::syntax::decls::Decl { kind: kind_p3.clone(), span: crate::syntax::parser::to(&start_p2, &crate::syntax::parser::prev(&q_p4)) }, q_p4.clone())
}

/// The step machine of `ParseDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseDecl: unbounded fn Ps, Bool -> ((Decl, Ps))
/// ```
pub struct ParseDecl {
    pub p_p0: crate::syntax::parser::Ps,
    pub fragment_p1: bool,
}

impl prism_rtl::Job<(crate::syntax::decls::Decl, crate::syntax::parser::Ps)> for ParseDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::Decl, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let fragment_p1 = &self.fragment_p1;
        let start_p2 = crate::syntax::parser::here(p_p0);
        let fragment_p1 = *fragment_p1;
        let p_p0 = p_p0.clone();
        call_then(start_decl_kind_of(p_p0.clone(), fragment_p1, start_p2.clone()), move |decl_kind_of_5602: (crate::syntax::decls::DeclKind, crate::syntax::parser::Ps)| {
            let (kind_p3, q_p4) = decl_kind_of_5602;
            prism_rtl::Turn::Finished((crate::syntax::decls::Decl { kind: kind_p3.clone(), span: crate::syntax::parser::to(&start_p2, &crate::syntax::parser::prev(&q_p4)) }, q_p4.clone()))
        })
    }
}

/// `Start ParseDecl, x`: what the function value is when passed to `@Run`.
pub fn start_parse_decl(p_p0: crate::syntax::parser::Ps, fragment_p1: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::Decl, crate::syntax::parser::Ps)>> {
    Rc::new(ParseDecl { p_p0, fragment_p1 })
}

/// ```prism
/// DeclKindOf: unbounded fn Ps, Bool, Range -> ((DeclKind, Ps))
/// ```
pub fn decl_kind_of(p_p0: &crate::syntax::parser::Ps, fragment_p1: &bool, start_p2: &crate::syntax::Range) -> (crate::syntax::decls::DeclKind, crate::syntax::parser::Ps) {
    match crate::syntax::parser::kind(p_p0) {
        crate::syntax::lexer::TokKind::KKw(m5783_0_0, _) if (&m5783_0_0 == &Text::lit("type")) => {
            let (d_p3, q_p4) = parse_type_decl(p_p0);
            (crate::syntax::decls::DeclKind::DType(d_p3.clone()), q_p4.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m5783_1_0, _) if (&m5783_1_0 == &Text::lit("tag")) => {
            let (d_p5, q_p6) = parse_tag_decl(p_p0);
            (crate::syntax::decls::DeclKind::DTag(d_p5.clone()), q_p6.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m5783_2_0, _) if (&m5783_2_0 == &Text::lit("derive")) => {
            let (traits_p7, q_p8) = crate::syntax::parser::commas(&crate::syntax::parser::adv(p_p0), &{
                let f = Rc::new(crate::syntax::parser::parse_trait_ref);
                Rc::new(move |a0: crate::syntax::parser::Ps| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                }) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::TraitRef, crate::syntax::parser::Ps)>>>
            });
            (crate::syntax::decls::DeclKind::DDerive(traits_p7.clone()), q_p8.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m5783_3_0, _) if (&m5783_3_0 == &Text::lit("trait")) => {
            let (d_p9, q_pa) = parse_trait_decl(p_p0);
            (crate::syntax::decls::DeclKind::DTrait(d_p9.clone()), q_pa.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m5783_4_0, _) if (&m5783_4_0 == &Text::lit("impl")) => {
            let (d_pb, q_pc) = parse_impl_decl(p_p0);
            (crate::syntax::decls::DeclKind::DImpl(d_pb.clone()), q_pc.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m5783_5_0, _) if (&m5783_5_0 == &Text::lit("check")) => {
            let (d_pd, q_pe) = crate::syntax::parser::test_language::parse_check_decl(p_p0);
            (crate::syntax::decls::DeclKind::DCheck(d_pd.clone()), q_pe.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m5783_6_0, _) if (&m5783_6_0 == &Text::lit("test")) => {
            let (d_pf, q_pg) = crate::syntax::parser::test_language::parse_test_decl(p_p0);
            (crate::syntax::decls::DeclKind::DTest(d_pf.clone()), q_pg.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m5783_7_0, _) if (&m5783_7_0 == &Text::lit("fn")) => {
            let (d_ph, q_pi) = parse_fn_clause(p_p0);
            (crate::syntax::decls::DeclKind::DFn(d_ph.clone()), q_pi.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m5783_8_0, _) if (&m5783_8_0 == &Text::lit("let")) => {
            let (pattern_pj, p1_pk) = crate::syntax::parser::types::parse_pattern(&crate::syntax::parser::adv(p_p0), &false);
            let (ty_ol, p2_pm) = optional_annotation(&p1_pk);
            let (value_pn, p3_po) = crate::syntax::parser::expr::parse_rhs_expr(&crate::syntax::parser::expect_op(&p2_pm, &Text::lit("=")));
            (crate::syntax::decls::DeclKind::DLet(crate::syntax::decls::LetDecl { pattern: pattern_pj.clone(), ty: ty_ol.clone(), value: value_pn.clone(), span: crate::syntax::parser::to(start_p2, &crate::syntax::parser::prev(&p3_po)) }), p3_po.clone())
        },
        crate::syntax::lexer::TokKind::KName(_) if (&crate::syntax::parser::kind_at(p_p0, &Nat::from(1u32)) == &crate::syntax::lexer::TokKind::KColon) => if &crate::syntax::parser::kind_at(p_p0, &Nat::from(2u32)) == &crate::syntax::lexer::TokKind::KLayOpen {
            {
                let (name_pp, p1_pq) = crate::syntax::parser::parse_sname(p_p0);
                let (body_pr, p2_ps) = crate::syntax::parser::blocks::parse_block_after_colon(&p1_pq);
                (crate::syntax::decls::DeclKind::DWidget(crate::syntax::decls::WidgetDecl { name: name_pp.clone(), body: body_pr.clone(), span: crate::syntax::parser::to(start_p2, &body_pr.span) }), p2_ps.clone())
            }
        } else {
            {
                let (sig_pt, q_pu) = parse_signature(p_p0);
                (crate::syntax::decls::DeclKind::DSignature(sig_pt.clone()), q_pu.clone())
            }
        },
        _ => if *fragment_p1 {
            {
                let (st_pv, q_p10) = crate::syntax::parser::blocks::parse_stmt(p_p0);
                (crate::syntax::decls::DeclKind::DStmt(st_pv.clone()), q_p10.clone())
            }
        } else {
            {
                let (st_p11, q_p12) = crate::syntax::parser::blocks::parse_stmt(p_p0);
                match &st_p11.kind {
                    crate::syntax::StmtKind::SBind(_, _, _) if !q_p12.bad => (crate::syntax::decls::DeclKind::DStmt(st_p11.clone()), crate::syntax::parser::error_at(&q_p12, start_p2, &Text::lit("a bind or hold is a statement of a widget block: nothing at top level is built (Semantics ch. 6)"))),
                    _ => {
                        let at_p13 = if q_p12.bad { p_p0.clone() } else { q_p12.clone() };
                        (crate::syntax::decls::DeclKind::DStmt(st_p11.clone()), crate::syntax::parser::error_here(&at_p13, &Text::lit("expected a declaration (`fn`, `let`, `type`, `tag`, `derive`, `trait`, `impl`, `test`, `check`, or a signature `Name: type`)")))
                    },
                    _ => unreachable!("no arm matched"),
                }
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `DeclKindOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DeclKindOf: unbounded fn Ps, Bool, Range -> ((DeclKind, Ps))
/// ```
pub struct DeclKindOf {
    pub p_p0: crate::syntax::parser::Ps,
    pub fragment_p1: bool,
    pub start_p2: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::syntax::decls::DeclKind, crate::syntax::parser::Ps)> for DeclKindOf {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::DeclKind, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let fragment_p1 = &self.fragment_p1;
        let start_p2 = &self.start_p2;
        match crate::syntax::parser::kind(p_p0) {
            crate::syntax::lexer::TokKind::KKw(m5783_0_0, _) if (&m5783_0_0 == &Text::lit("type")) => {
                let p_p0 = p_p0.clone();
                call_then(start_parse_type_decl(p_p0.clone()), move |parse_type_decl_5844: (crate::syntax::decls::TypeDecl, crate::syntax::parser::Ps)| {
                    let (d_p3, q_p4) = parse_type_decl_5844;
                    prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DType(d_p3.clone()), q_p4.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m5783_1_0, _) if (&m5783_1_0 == &Text::lit("tag")) => {
                let p_p0 = p_p0.clone();
                call_then(start_parse_tag_decl(p_p0.clone()), move |parse_tag_decl_5929: (crate::syntax::decls::TagDecl, crate::syntax::parser::Ps)| {
                    let (d_p5, q_p6) = parse_tag_decl_5929;
                    prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DTag(d_p5.clone()), q_p6.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m5783_2_0, _) if (&m5783_2_0 == &Text::lit("derive")) => {
                let p_p0 = p_p0.clone();
                call_then(crate::syntax::parser::start_commas(crate::syntax::parser::adv(&p_p0), {
                    let f = Rc::new(crate::syntax::parser::parse_trait_ref);
                    Rc::new(move |a0: crate::syntax::parser::Ps| {
                        let f = f.clone();
                        once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                    }) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::TraitRef, crate::syntax::parser::Ps)>>>
                }), move |commas_6020: (Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps)| {
                    let (traits_p7, q_p8) = commas_6020;
                    prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DDerive(traits_p7.clone()), q_p8.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m5783_3_0, _) if (&m5783_3_0 == &Text::lit("trait")) => {
                let p_p0 = p_p0.clone();
                call_then(start_parse_trait_decl(p_p0.clone()), move |parse_trait_decl_6128: (crate::syntax::decls::TraitDecl, crate::syntax::parser::Ps)| {
                    let (d_p9, q_pa) = parse_trait_decl_6128;
                    prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DTrait(d_p9.clone()), q_pa.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m5783_4_0, _) if (&m5783_4_0 == &Text::lit("impl")) => {
                let p_p0 = p_p0.clone();
                call_then(start_parse_impl_decl(p_p0.clone()), move |parse_impl_decl_6216: (crate::syntax::decls::ImplDecl, crate::syntax::parser::Ps)| {
                    let (d_pb, q_pc) = parse_impl_decl_6216;
                    prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DImpl(d_pb.clone()), q_pc.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m5783_5_0, _) if (&m5783_5_0 == &Text::lit("check")) => {
                let p_p0 = p_p0.clone();
                call_then(crate::syntax::parser::test_language::start_parse_check_decl(p_p0.clone()), move |parse_check_decl_6303: (crate::syntax::decls::CheckDecl, crate::syntax::parser::Ps)| {
                    let (d_pd, q_pe) = parse_check_decl_6303;
                    prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DCheck(d_pd.clone()), q_pe.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m5783_6_0, _) if (&m5783_6_0 == &Text::lit("test")) => {
                let p_p0 = p_p0.clone();
                call_then(crate::syntax::parser::test_language::start_parse_test_decl(p_p0.clone()), move |parse_test_decl_6391: (crate::syntax::decls::TestDecl, crate::syntax::parser::Ps)| {
                    let (d_pf, q_pg) = parse_test_decl_6391;
                    prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DTest(d_pf.clone()), q_pg.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m5783_7_0, _) if (&m5783_7_0 == &Text::lit("fn")) => {
                let p_p0 = p_p0.clone();
                call_then(start_parse_fn_clause(p_p0.clone()), move |parse_fn_clause_6475: (crate::syntax::decls::FnClause, crate::syntax::parser::Ps)| {
                    let (d_ph, q_pi) = parse_fn_clause_6475;
                    prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DFn(d_ph.clone()), q_pi.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m5783_8_0, _) if (&m5783_8_0 == &Text::lit("let")) => {
                let p_p0 = p_p0.clone();
                let start_p2 = start_p2.clone();
                call_then(crate::syntax::parser::types::start_parse_pattern(crate::syntax::parser::adv(&p_p0), false), move |parse_pattern_6565: (crate::syntax::Pattern_, crate::syntax::parser::Ps)| {
                    let (pattern_pj, p1_pk) = parse_pattern_6565;
                    call_then(start_optional_annotation(p1_pk.clone()), move |optional_annotation_6619: (Option<crate::syntax::Type>, crate::syntax::parser::Ps)| {
                        let (ty_ol, p2_pm) = optional_annotation_6619;
                        call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::expect_op(&p2_pm, &Text::lit("="))), move |parse_rhs_expr_6669: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                            let (value_pn, p3_po) = parse_rhs_expr_6669;
                            prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DLet(crate::syntax::decls::LetDecl { pattern: pattern_pj.clone(), ty: ty_ol.clone(), value: value_pn.clone(), span: crate::syntax::parser::to(&start_p2, &crate::syntax::parser::prev(&p3_po)) }), p3_po.clone()))
                        })
                    })
                })
            },
            crate::syntax::lexer::TokKind::KName(_) if (&crate::syntax::parser::kind_at(p_p0, &Nat::from(1u32)) == &crate::syntax::lexer::TokKind::KColon) => if &crate::syntax::parser::kind_at(p_p0, &Nat::from(2u32)) == &crate::syntax::lexer::TokKind::KLayOpen {
                {
                    let (name_pp, p1_pq) = crate::syntax::parser::parse_sname(p_p0);
                    let start_p2 = start_p2.clone();
                    call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(p1_pq.clone()), move |parse_block_after_colon_6954: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                        let (body_pr, p2_ps) = parse_block_after_colon_6954;
                        prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DWidget(crate::syntax::decls::WidgetDecl { name: name_pp.clone(), body: body_pr.clone(), span: crate::syntax::parser::to(&start_p2, &body_pr.span) }), p2_ps.clone()))
                    })
                }
            } else {
                {
                    let p_p0 = p_p0.clone();
                    call_then(start_parse_signature(p_p0.clone()), move |parse_signature_7110: (crate::syntax::decls::Signature, crate::syntax::parser::Ps)| {
                        let (sig_pt, q_pu) = parse_signature_7110;
                        prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DSignature(sig_pt.clone()), q_pu.clone()))
                    })
                }
            },
            _ => if *fragment_p1 {
                {
                    let p_p0 = p_p0.clone();
                    call_then(crate::syntax::parser::blocks::start_parse_stmt(p_p0.clone()), move |parse_stmt_7225: (crate::syntax::Stmt, crate::syntax::parser::Ps)| {
                        let (st_pv, q_p10) = parse_stmt_7225;
                        prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DStmt(st_pv.clone()), q_p10.clone()))
                    })
                }
            } else {
                {
                    let p_p0 = p_p0.clone();
                    let start_p2 = start_p2.clone();
                    call_then(crate::syntax::parser::blocks::start_parse_stmt(p_p0.clone()), move |parse_stmt_7433: (crate::syntax::Stmt, crate::syntax::parser::Ps)| {
                        let (st_p11, q_p12) = parse_stmt_7433;
                        match &st_p11.kind {
                            crate::syntax::StmtKind::SBind(_, _, _) if !q_p12.bad => prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DStmt(st_p11.clone()), crate::syntax::parser::error_at(&q_p12, &start_p2, &Text::lit("a bind or hold is a statement of a widget block: nothing at top level is built (Semantics ch. 6)")))),
                            _ => {
                                let at_p13 = if q_p12.bad { p_p0.clone() } else { q_p12.clone() };
                                prism_rtl::Turn::Finished((crate::syntax::decls::DeclKind::DStmt(st_p11.clone()), crate::syntax::parser::error_here(&at_p13, &Text::lit("expected a declaration (`fn`, `let`, `type`, `tag`, `derive`, `trait`, `impl`, `test`, `check`, or a signature `Name: type`)"))))
                            },
                            _ => unreachable!("no arm matched"),
                        }
                    })
                }
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start DeclKindOf, x`: what the function value is when passed to `@Run`.
pub fn start_decl_kind_of(p_p0: crate::syntax::parser::Ps, fragment_p1: bool, start_p2: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::DeclKind, crate::syntax::parser::Ps)>> {
    Rc::new(DeclKindOf { p_p0, fragment_p1, start_p2 })
}

/// ```prism
/// OptionalAnnotation: unbounded fn Ps -> ((?Type, Ps))
/// ```
pub fn optional_annotation(p_p0: &crate::syntax::parser::Ps) -> (Option<crate::syntax::Type>, crate::syntax::parser::Ps) {
    if crate::syntax::parser::at_colon(p_p0) {
        {
            let (ty_p1, q_p2) = crate::syntax::parser::types::parse_type(&crate::syntax::parser::adv(p_p0));
            (Some(ty_p1.clone()), q_p2.clone())
        }
    } else {
        (None, p_p0.clone())
    }
}

/// The step machine of `OptionalAnnotation`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptionalAnnotation: unbounded fn Ps -> ((?Type, Ps))
/// ```
pub struct OptionalAnnotation {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(Option<crate::syntax::Type>, crate::syntax::parser::Ps)> for OptionalAnnotation {
    fn cycle(&self) -> prism_rtl::Turn<(Option<crate::syntax::Type>, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        if crate::syntax::parser::at_colon(p_p0) {
            {
                let p_p0 = p_p0.clone();
                call_then(crate::syntax::parser::types::start_parse_type(crate::syntax::parser::adv(&p_p0)), move |parse_type_8123: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (ty_p1, q_p2) = parse_type_8123;
                    prism_rtl::Turn::Finished((Some(ty_p1.clone()), q_p2.clone()))
                })
            }
        } else {
            prism_rtl::Turn::Finished((None, p_p0.clone()))
        }
    }
}

/// `Start OptionalAnnotation, x`: what the function value is when passed to `@Run`.
pub fn start_optional_annotation(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(Option<crate::syntax::Type>, crate::syntax::parser::Ps)>> {
    Rc::new(OptionalAnnotation { p_p0 })
}

/// ```prism
/// ParseSignature: unbounded fn Ps -> ((Signature, Ps))
/// ```
pub fn parse_signature(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::Signature, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here(p_p0);
    let (name_p2, p1_p3) = parse_def_name(p_p0);
    let (ty_p4, p2_p5) = crate::syntax::parser::types::parse_type(&crate::syntax::parser::expect_colon(&p1_p3));
    let (bounds_p6, p3_p7) = optional_bounds(&p2_p5);
    (crate::syntax::decls::Signature { name: name_p2.clone(), ty: ty_p4.clone(), bounds: bounds_p6.clone(), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p3_p7)) }, p3_p7.clone())
}

/// The step machine of `ParseSignature`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseSignature: unbounded fn Ps -> ((Signature, Ps))
/// ```
pub struct ParseSignature {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::Signature, crate::syntax::parser::Ps)> for ParseSignature {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::Signature, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here(p_p0);
        let (name_p2, p1_p3) = parse_def_name(p_p0);
        call_then(crate::syntax::parser::types::start_parse_type(crate::syntax::parser::expect_colon(&p1_p3)), move |parse_type_8405: (crate::syntax::Type, crate::syntax::parser::Ps)| {
            let (ty_p4, p2_p5) = parse_type_8405;
            call_then(start_optional_bounds(p2_p5.clone()), move |optional_bounds_8457: (Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps)| {
                let (bounds_p6, p3_p7) = optional_bounds_8457;
                prism_rtl::Turn::Finished((crate::syntax::decls::Signature { name: name_p2.clone(), ty: ty_p4.clone(), bounds: bounds_p6.clone(), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p3_p7)) }, p3_p7.clone()))
            })
        })
    }
}

/// `Start ParseSignature, x`: what the function value is when passed to `@Run`.
pub fn start_parse_signature(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::Signature, crate::syntax::parser::Ps)>> {
    Rc::new(ParseSignature { p_p0 })
}

/// ```prism
/// OptionalBounds: unbounded fn Ps -> (([Bound], Ps))
/// ```
pub fn optional_bounds(p_p0: &crate::syntax::parser::Ps) -> (Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps) {
    if crate::syntax::parser::at_kw(p_p0, &Text::lit("where")) {
        crate::syntax::parser::types::parse_bounds(&crate::syntax::parser::adv(p_p0))
    } else {
        (Array::new(), p_p0.clone())
    }
}

/// The step machine of `OptionalBounds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptionalBounds: unbounded fn Ps -> (([Bound], Ps))
/// ```
pub struct OptionalBounds {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps)> for OptionalBounds {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        if crate::syntax::parser::at_kw(p_p0, &Text::lit("where")) {
            prism_rtl::Turn::More(Rc::new(crate::syntax::parser::types::ParseBounds { p0_p0: crate::syntax::parser::adv(p_p0) }))
        } else {
            prism_rtl::Turn::Finished((Array::new(), p_p0.clone()))
        }
    }
}

/// `Start OptionalBounds, x`: what the function value is when passed to `@Run`.
pub fn start_optional_bounds(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps)>> {
    Rc::new(OptionalBounds { p_p0 })
}

/// ```prism
/// ParseDefName: fn Ps -> ((DefName, Ps))
/// ```
pub fn parse_def_name(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::DefName, crate::syntax::parser::Ps) {
    match crate::syntax::parser::kind(p_p0) {
        crate::syntax::lexer::TokKind::KName(n_p1) => {
            let (name_p4, q_p5) = crate::syntax::parser::parse_sname(p_p0);
            let lens_p2 = crate::syntax::lexer::chars::has_prefix(&n_p1.sigils, &Text::lit("&")) && crate::syntax::parser::is_upper_name(&name_p4);
            let q2_p3 = if lens_p2 {
                crate::syntax::parser::out_of_scope(&q_p5, &name_p4.span, &Text::lit("named lenses `&Home` and `Over`"), &Text::from(format!("the named lens `{}` is out of this compiler", &crate::syntax::parser::name_text(&name_p4))))
            } else {
                q_p5.clone()
            };
            (crate::syntax::decls::DefName::DefSName(name_p4.clone()), q2_p3.clone())
        },
        crate::syntax::lexer::TokKind::KOp(op_p6, _) if p_p0.in_trait => {
            let name_p7 = crate::syntax::decls::DefName::DefOp(op_p6, crate::syntax::parser::here(p_p0));
            (name_p7.clone(), crate::syntax::parser::adv(p_p0))
        },
        _ => (crate::syntax::decls::DefName::DefSName(crate::syntax::parser::no_sname()), crate::syntax::parser::error_here(p_p0, &Text::lit("expected a name"))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParseFnClause: unbounded fn Ps -> ((FnClause, Ps))
/// ```
pub fn parse_fn_clause(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::FnClause, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here(p0_p0);
    let (name_p2, p1_p3) = parse_def_name(&crate::syntax::parser::expect_kw(p0_p0, &Text::lit("fn")));
    let (params_p5, p2_p6) = if crate::syntax::parser::at_op(&p1_p3, &Text::lit("=")) || crate::syntax::parser::at_colon(&p1_p3) {
        (Array::new(), p1_p3.clone())
    } else {
        crate::syntax::parser::commas(&p1_p3, &(Rc::new(move |p0: crate::syntax::parser::Ps| entered(once_job(move || {
            let q_p4 = p0;
            prism_rtl::Turn::More(Rc::new(crate::syntax::parser::types::ParsePattern { p_p0: q_p4.clone(), commas0_p1: false }))
        }))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>>>))
    };
    let (body_p7, p3_p8) = parse_fn_body(&p2_p6);
    (crate::syntax::decls::FnClause { name: name_p2.clone(), params: params_p5.clone(), body: body_p7.clone(), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p3_p8)) }, p3_p8.clone())
}

/// The step machine of `ParseFnClause`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseFnClause: unbounded fn Ps -> ((FnClause, Ps))
/// ```
pub struct ParseFnClause {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::FnClause, crate::syntax::parser::Ps)> for ParseFnClause {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::FnClause, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let start_p1 = crate::syntax::parser::here(p0_p0);
        let (name_p2, p1_p3) = parse_def_name(&crate::syntax::parser::expect_kw(p0_p0, &Text::lit("fn")));
        let (params_p5, p2_p6) = if crate::syntax::parser::at_op(&p1_p3, &Text::lit("=")) || crate::syntax::parser::at_colon(&p1_p3) {
            (Array::new(), p1_p3.clone())
        } else {
            crate::syntax::parser::commas(&p1_p3, &(Rc::new(move |p0: crate::syntax::parser::Ps| entered(once_job(move || {
                let q_p4 = p0;
                prism_rtl::Turn::More(Rc::new(crate::syntax::parser::types::ParsePattern { p_p0: q_p4.clone(), commas0_p1: false }))
            }))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>>>))
        };
        call_then(start_parse_fn_body(p2_p6.clone()), move |parse_fn_body_9580: (crate::syntax::decls::FnBody, crate::syntax::parser::Ps)| {
            let (body_p7, p3_p8) = parse_fn_body_9580;
            prism_rtl::Turn::Finished((crate::syntax::decls::FnClause { name: name_p2.clone(), params: params_p5.clone(), body: body_p7.clone(), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p3_p8)) }, p3_p8.clone()))
        })
    }
}

/// `Start ParseFnClause, x`: what the function value is when passed to `@Run`.
pub fn start_parse_fn_clause(p0_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::FnClause, crate::syntax::parser::Ps)>> {
    Rc::new(ParseFnClause { p0_p0 })
}

/// ```prism
/// ParseFnBody: unbounded fn Ps -> ((FnBody, Ps))
/// ```
pub fn parse_fn_body(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::FnBody, crate::syntax::parser::Ps) {
    if crate::syntax::parser::at_op(p_p0, &Text::lit("=")) {
        {
            let (e_p1, q_p2) = crate::syntax::parser::expr::parse_rhs_expr(&crate::syntax::parser::adv(p_p0));
            (crate::syntax::decls::FnBody::BodyExpr(e_p1.clone()), q_p2.clone())
        }
    } else {
        if crate::syntax::parser::at_colon(p_p0) {
            {
                let (b_p3, q_p4) = crate::syntax::parser::blocks::parse_block_after_colon(p_p0);
                (crate::syntax::decls::FnBody::BodyBlock(b_p3.clone()), q_p4.clone())
            }
        } else {
            (crate::syntax::decls::FnBody::BodyExpr(no_expr()), crate::syntax::parser::error_here(p_p0, &Text::lit("expected `=` and an expression, or `:` and a block, after the parameters")))
        }
    }
}

/// The step machine of `ParseFnBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseFnBody: unbounded fn Ps -> ((FnBody, Ps))
/// ```
pub struct ParseFnBody {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::FnBody, crate::syntax::parser::Ps)> for ParseFnBody {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::FnBody, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        if crate::syntax::parser::at_op(p_p0, &Text::lit("=")) {
            {
                let p_p0 = p_p0.clone();
                call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::adv(&p_p0)), move |parse_rhs_expr_9790: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (e_p1, q_p2) = parse_rhs_expr_9790;
                    prism_rtl::Turn::Finished((crate::syntax::decls::FnBody::BodyExpr(e_p1.clone()), q_p2.clone()))
                })
            }
        } else {
            if crate::syntax::parser::at_colon(p_p0) {
                {
                    let p_p0 = p_p0.clone();
                    call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(p_p0.clone()), move |parse_block_after_colon_9884: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                        let (b_p3, q_p4) = parse_block_after_colon_9884;
                        prism_rtl::Turn::Finished((crate::syntax::decls::FnBody::BodyBlock(b_p3.clone()), q_p4.clone()))
                    })
                }
            } else {
                prism_rtl::Turn::Finished((crate::syntax::decls::FnBody::BodyExpr(no_expr()), crate::syntax::parser::error_here(p_p0, &Text::lit("expected `=` and an expression, or `:` and a block, after the parameters"))))
            }
        }
    }
}

/// `Start ParseFnBody, x`: what the function value is when passed to `@Run`.
pub fn start_parse_fn_body(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::FnBody, crate::syntax::parser::Ps)>> {
    Rc::new(ParseFnBody { p_p0 })
}

/// ```prism
/// LowerParams: fn Ps -> (([Ident], Ps))
/// ```
pub fn lower_params(p0_p0: &crate::syntax::parser::Ps) -> (Array<crate::syntax::Ident>, crate::syntax::parser::Ps) {
    let mut this: (Array<crate::syntax::Ident>, crate::syntax::parser::Ps) = (Array::new(), p0_p0.clone());
    let mut ps_p1: Array<crate::syntax::Ident> = Array::new();
    let mut p_p2: crate::syntax::parser::Ps = p0_p0.clone();
    let mut fuel_p3: Nat = len(&p0_p0.toks);
    while let Some(left_p4) = (&fuel_p3).checked_sub(&Nat::from(1u32)) {
        if !is_plain_lower(&crate::syntax::parser::kind(&p_p2)) {
            break;
        }
        fuel_p3 = left_p4.clone();
        let (i_p5, q_p6) = crate::syntax::parser::parse_ident(&p_p2);
        ps_p1 = push(&ps_p1, &i_p5);
        p_p2 = q_p6.clone();
    }
    this = (ps_p1.clone(), p_p2.clone());
    this
}

/// ```prism
/// IsPlainLower: fn TokKind -> Bool
/// ```
pub fn is_plain_lower(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KName(n_p0) => (&n_p0.case == &crate::syntax::lexer::NameCase::CaseLower) && (&n_p0.sigils == &Text::lit("")),
        _ => false,
    }
}

/// ```prism
/// ParseTypeDecl: unbounded fn Ps -> ((TypeDecl, Ps))
/// ```
pub fn parse_type_decl(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::TypeDecl, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here(p0_p0);
    let (name_p2, p1_p3) = crate::syntax::parser::parse_qual_name(&crate::syntax::parser::adv(p0_p0));
    let (params_p4, p2_p5) = lower_params(&p1_p3);
    let (body_o6, p3_p7) = if crate::syntax::parser::at_op(&p2_p5, &Text::lit("=")) {
        parse_type_body(&crate::syntax::parser::adv(&p2_p5), &name_p2, &params_p4)
    } else {
        (None, p2_p5.clone())
    };
    (crate::syntax::decls::TypeDecl { name: name_p2.clone(), params: params_p4.clone(), body: body_o6.clone(), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p3_p7)) }, p3_p7.clone())
}

/// The step machine of `ParseTypeDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTypeDecl: unbounded fn Ps -> ((TypeDecl, Ps))
/// ```
pub struct ParseTypeDecl {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::TypeDecl, crate::syntax::parser::Ps)> for ParseTypeDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::TypeDecl, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let start_p1 = crate::syntax::parser::here(p0_p0);
        let (name_p2, p1_p3) = crate::syntax::parser::parse_qual_name(&crate::syntax::parser::adv(p0_p0));
        let (params_p4, p2_p5) = lower_params(&p1_p3);
        let (body_o6, p3_p7) = if crate::syntax::parser::at_op(&p2_p5, &Text::lit("=")) {
            parse_type_body(&crate::syntax::parser::adv(&p2_p5), &name_p2, &params_p4)
        } else {
            (None, p2_p5.clone())
        };
        prism_rtl::Turn::Finished((crate::syntax::decls::TypeDecl { name: name_p2.clone(), params: params_p4.clone(), body: body_o6.clone(), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p3_p7)) }, p3_p7.clone()))
    }
}

/// `Start ParseTypeDecl, x`: what the function value is when passed to `@Run`.
pub fn start_parse_type_decl(p0_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TypeDecl, crate::syntax::parser::Ps)>> {
    Rc::new(ParseTypeDecl { p0_p0 })
}

/// ```prism
/// ParseTypeBody: unbounded fn Ps, QualName, [Ident] -> ((?TypeBody, Ps))
/// ```
pub fn parse_type_body(p_p0: &crate::syntax::parser::Ps, name_p1: &crate::syntax::QualName, params_p2: &Array<crate::syntax::Ident>) -> (Option<crate::syntax::decls::TypeBody>, crate::syntax::parser::Ps) {
    match crate::syntax::parser::kind(p_p0) {
        crate::syntax::lexer::TokKind::KKw(m11097_0_0, m11097_0_1) if (&m11097_0_0 == &Text::lit("record")) && (&m11097_0_1 == &Text::lit("")) => {
            let (fields_p3, q_p4) = parse_field_block(&crate::syntax::parser::adv(p_p0));
            (Some(crate::syntax::decls::TypeBody::TbRecord(fields_p3.clone())), q_p4.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m11097_1_0, m11097_1_1) if (&m11097_1_0 == &Text::lit("choice")) && (&m11097_1_1 == &Text::lit("")) => {
            let p1_p5 = crate::syntax::parser::expect_colon(&crate::syntax::parser::adv(p_p0));
            if crate::syntax::parser::at_open_l(&p1_p5) {
                {
                    let (cases_p6, q_p7) = crate::syntax::parser::layout_items(&crate::syntax::parser::adv(&p1_p5), &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_case(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::Case_, crate::syntax::parser::Ps)>>>));
                    (Some(crate::syntax::decls::TypeBody::TbChoice(cases_p6.clone())), q_p7.clone())
                }
            } else {
                (None, crate::syntax::parser::error_here(&p1_p5, &Text::lit("a choice\'s cases stand in an indented block after `choice:`")))
            }
        },
        crate::syntax::lexer::TokKind::KKw(m11097_2_0, m11097_2_1) if (&m11097_2_0 == &Text::lit("row")) && (&m11097_2_1 == &Text::lit("")) => (Some(crate::syntax::decls::TypeBody::TbRow), crate::syntax::parser::adv(p_p0)),
        crate::syntax::lexer::TokKind::KName(n_p8) if (((&n_p8.sigils == &Text::lit("")) && (&len(&n_p8.path_) == &Nat::from(1u32))) && (&crate::syntax::lexer::chars::last(&n_p8.path_) == &crate::syntax::lexer::chars::last(&name_p1.path_))) => {
            let (c_p9, q_pa) = parse_case(p_p0);
            (Some(crate::syntax::decls::TypeBody::TbNewtype(c_p9.clone())), q_pa.clone())
        },
        crate::syntax::lexer::TokKind::KName(n_pb) if is_unit_body(p_p0, &n_pb, params_p2) => {
            let (i_pc, q_pd) = crate::syntax::parser::parse_ident(p_p0);
            (Some(crate::syntax::decls::TypeBody::TbUnit(i_pc.clone())), q_pd.clone())
        },
        _ => {
            let (ty_pe, q_pf) = crate::syntax::parser::types::parse_type(p_p0);
            (Some(crate::syntax::decls::TypeBody::TbAlias(ty_pe.clone())), q_pf.clone())
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ParseTypeBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTypeBody: unbounded fn Ps, QualName, [Ident] -> ((?TypeBody, Ps))
/// ```
pub struct ParseTypeBody {
    pub p_p0: crate::syntax::parser::Ps,
    pub name_p1: crate::syntax::QualName,
    pub params_p2: Array<crate::syntax::Ident>,
}

impl prism_rtl::Job<(Option<crate::syntax::decls::TypeBody>, crate::syntax::parser::Ps)> for ParseTypeBody {
    fn cycle(&self) -> prism_rtl::Turn<(Option<crate::syntax::decls::TypeBody>, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let name_p1 = &self.name_p1;
        let params_p2 = &self.params_p2;
        match crate::syntax::parser::kind(p_p0) {
            crate::syntax::lexer::TokKind::KKw(m11097_0_0, m11097_0_1) if (&m11097_0_0 == &Text::lit("record")) && (&m11097_0_1 == &Text::lit("")) => {
                let p_p0 = p_p0.clone();
                call_then(start_parse_field_block(crate::syntax::parser::adv(&p_p0)), move |parse_field_block_11161: (Array<crate::syntax::decls::Field>, crate::syntax::parser::Ps)| {
                    let (fields_p3, q_p4) = parse_field_block_11161;
                    prism_rtl::Turn::Finished((Some(crate::syntax::decls::TypeBody::TbRecord(fields_p3.clone())), q_p4.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m11097_1_0, m11097_1_1) if (&m11097_1_0 == &Text::lit("choice")) && (&m11097_1_1 == &Text::lit("")) => {
                let p1_p5 = crate::syntax::parser::expect_colon(&crate::syntax::parser::adv(p_p0));
                if crate::syntax::parser::at_open_l(&p1_p5) {
                    call_then(crate::syntax::parser::start_layout_items(crate::syntax::parser::adv(&p1_p5), Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_case(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::Case_, crate::syntax::parser::Ps)>>>), move |layout_items_11333: (Array<crate::syntax::decls::Case_>, crate::syntax::parser::Ps)| {
                        let (cases_p6, q_p7) = layout_items_11333;
                        prism_rtl::Turn::Finished((Some(crate::syntax::decls::TypeBody::TbChoice(cases_p6.clone())), q_p7.clone()))
                    })
                } else {
                    prism_rtl::Turn::Finished((None, crate::syntax::parser::error_here(&p1_p5, &Text::lit("a choice\'s cases stand in an indented block after `choice:`"))))
                }
            },
            crate::syntax::lexer::TokKind::KKw(m11097_2_0, m11097_2_1) if (&m11097_2_0 == &Text::lit("row")) && (&m11097_2_1 == &Text::lit("")) => prism_rtl::Turn::Finished((Some(crate::syntax::decls::TypeBody::TbRow), crate::syntax::parser::adv(p_p0))),
            crate::syntax::lexer::TokKind::KName(n_p8) if (((&n_p8.sigils == &Text::lit("")) && (&len(&n_p8.path_) == &Nat::from(1u32))) && (&crate::syntax::lexer::chars::last(&n_p8.path_) == &crate::syntax::lexer::chars::last(&name_p1.path_))) => {
                let p_p0 = p_p0.clone();
                call_then(start_parse_case(p_p0.clone()), move |parse_case_11752: (crate::syntax::decls::Case_, crate::syntax::parser::Ps)| {
                    let (c_p9, q_pa) = parse_case_11752;
                    prism_rtl::Turn::Finished((Some(crate::syntax::decls::TypeBody::TbNewtype(c_p9.clone())), q_pa.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KName(n_pb) if is_unit_body(p_p0, &n_pb, params_p2) => {
                let (i_pc, q_pd) = crate::syntax::parser::parse_ident(p_p0);
                prism_rtl::Turn::Finished((Some(crate::syntax::decls::TypeBody::TbUnit(i_pc.clone())), q_pd.clone()))
            },
            _ => {
                let p_p0 = p_p0.clone();
                call_then(crate::syntax::parser::types::start_parse_type(p_p0.clone()), move |parse_type_12008: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (ty_pe, q_pf) = parse_type_12008;
                    prism_rtl::Turn::Finished((Some(crate::syntax::decls::TypeBody::TbAlias(ty_pe.clone())), q_pf.clone()))
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ParseTypeBody, x`: what the function value is when passed to `@Run`.
pub fn start_parse_type_body(p_p0: crate::syntax::parser::Ps, name_p1: crate::syntax::QualName, params_p2: Array<crate::syntax::Ident>) -> Rc<dyn prism_rtl::Job<(Option<crate::syntax::decls::TypeBody>, crate::syntax::parser::Ps)>> {
    Rc::new(ParseTypeBody { p_p0, name_p1, params_p2 })
}

/// ```prism
/// IsUnitBody: fn Ps, NameTok, [Ident] -> Bool
/// ```
pub fn is_unit_body(p_p0: &crate::syntax::parser::Ps, n_p1: &crate::syntax::lexer::NameTok, params_p2: &Array<crate::syntax::Ident>) -> bool {
    let w_p3 = or(&index(&n_p1.path_, &Nat::from(0u32)), &Text::lit(""));
    let param_p4 = fold(params_p2, &false, &(|seen_p6: &bool, i_p7: &crate::syntax::Ident| *seen_p6 || (&i_p7.name == &w_p3)));
    let ends_p5 = match crate::syntax::parser::kind_at(p_p0, &Nat::from(1u32)) {
        crate::syntax::lexer::TokKind::KLaySep => true,
        crate::syntax::lexer::TokKind::KLayOpen => true,
        crate::syntax::lexer::TokKind::KLayClose => true,
        crate::syntax::lexer::TokKind::KEof => true,
        _ => false,
    };
    ((((&n_p1.sigils == &Text::lit("")) && (&n_p1.case == &crate::syntax::lexer::NameCase::CaseLower)) && (&len(&n_p1.path_) == &Nat::from(1u32))) && !param_p4) && ends_p5
}

/// ```prism
/// ParseFieldBlock: unbounded fn Ps -> (([Field], Ps))
/// ```
pub fn parse_field_block(p0_p0: &crate::syntax::parser::Ps) -> (Array<crate::syntax::decls::Field>, crate::syntax::parser::Ps) {
    let p_p1 = crate::syntax::parser::expect_colon(p0_p0);
    if crate::syntax::parser::at_open_l(&p_p1) {
        crate::syntax::parser::layout_items(&crate::syntax::parser::adv(&p_p1), &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_field(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::Field, crate::syntax::parser::Ps)>>>))
    } else {
        (Array::new(), crate::syntax::parser::error_here(&p_p1, &Text::lit("fields stand in an indented block, one `name: Type` per line")))
    }
}

/// The step machine of `ParseFieldBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseFieldBlock: unbounded fn Ps -> (([Field], Ps))
/// ```
pub struct ParseFieldBlock {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(Array<crate::syntax::decls::Field>, crate::syntax::parser::Ps)> for ParseFieldBlock {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::decls::Field>, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let p_p1 = crate::syntax::parser::expect_colon(p0_p0);
        if crate::syntax::parser::at_open_l(&p_p1) {
            prism_rtl::Turn::More(Rc::new(crate::syntax::parser::LayoutItems { p0_p0: crate::syntax::parser::adv(&p_p1), f_f1: Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_field(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::Field, crate::syntax::parser::Ps)>>> }))
        } else {
            prism_rtl::Turn::Finished((Array::new(), crate::syntax::parser::error_here(&p_p1, &Text::lit("fields stand in an indented block, one `name: Type` per line"))))
        }
    }
}

/// `Start ParseFieldBlock, x`: what the function value is when passed to `@Run`.
pub fn start_parse_field_block(p0_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::decls::Field>, crate::syntax::parser::Ps)>> {
    Rc::new(ParseFieldBlock { p0_p0 })
}

/// ```prism
/// ParseField: unbounded fn Ps -> ((Field, Ps))
/// ```
pub fn parse_field(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::Field, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here(p_p0);
    let (name_p2, p1_p3) = crate::syntax::parser::parse_ident(p_p0);
    let (ty_p4, p2_p5) = crate::syntax::parser::types::parse_type(&crate::syntax::parser::expect_colon(&p1_p3));
    (crate::syntax::decls::Field { name: name_p2.clone(), ty: ty_p4.clone(), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p2_p5)) }, p2_p5.clone())
}

/// The step machine of `ParseField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseField: unbounded fn Ps -> ((Field, Ps))
/// ```
pub struct ParseField {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::Field, crate::syntax::parser::Ps)> for ParseField {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::Field, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here(p_p0);
        let (name_p2, p1_p3) = crate::syntax::parser::parse_ident(p_p0);
        call_then(crate::syntax::parser::types::start_parse_type(crate::syntax::parser::expect_colon(&p1_p3)), move |parse_type_12885: (crate::syntax::Type, crate::syntax::parser::Ps)| {
            let (ty_p4, p2_p5) = parse_type_12885;
            prism_rtl::Turn::Finished((crate::syntax::decls::Field { name: name_p2.clone(), ty: ty_p4.clone(), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p2_p5)) }, p2_p5.clone()))
        })
    }
}

/// `Start ParseField, x`: what the function value is when passed to `@Run`.
pub fn start_parse_field(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::Field, crate::syntax::parser::Ps)>> {
    Rc::new(ParseField { p_p0 })
}

/// ```prism
/// ParseCase: unbounded fn Ps -> ((Case, Ps))
/// ```
pub fn parse_case(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::Case_, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here(p0_p0);
    let (name_p3, p1_p4) = crate::syntax::parser::parse_sname(p0_p0);
    let p2_p2 = if &name_p3.sigils != &Text::lit("") {
        crate::syntax::parser::note_error(&p1_p4, &name_p3.span, &Text::lit("a constructor takes no sigil"))
    } else {
        p1_p4.clone()
    };
    if crate::syntax::parser::at_colon(&p2_p2) {
        {
            let p3_p5 = crate::syntax::parser::adv(&p2_p2);
            let (args_p7, p4_p8) = if crate::syntax::parser::at_op(&p3_p5, &Text::lit("->")) {
                (Array::new(), p3_p5.clone())
            } else {
                crate::syntax::parser::commas(&p3_p5, &(Rc::new(|a0: crate::syntax::parser::Ps| entered(crate::syntax::parser::types::start_parse_emit_type(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>>>))
            };
            let (result_p9, p5_pa) = crate::syntax::parser::types::parse_type(&crate::syntax::parser::expect_op(&p4_p8, &Text::lit("->")));
            let p6_p6 = crate::syntax::parser::out_of_scope(&p5_pa, &start_p1, &Text::lit("indexed choices/GADTs for user types"), &Text::from(format!("`{}` is an indexed alternative: indexed choices for user types are out of this compiler", &crate::syntax::parser::name_text(&name_p3))));
            (crate::syntax::decls::Case_ { name: name_p3.clone(), args: args_p7.clone(), indexed: Some(result_p9.clone()), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p6_p6)) }, p6_p6.clone())
        }
    } else {
        {
            let (args_pb, p3_pc) = if crate::syntax::parser::at_stmt_boundary(&p2_p2) {
                (Array::new(), p2_p2.clone())
            } else {
                crate::syntax::parser::commas(&p2_p2, &(Rc::new(|a0: crate::syntax::parser::Ps| entered(crate::syntax::parser::types::start_parse_type(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>>>))
            };
            (crate::syntax::decls::Case_ { name: name_p3.clone(), args: args_pb.clone(), indexed: None, span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p3_pc)) }, p3_pc.clone())
        }
    }
}

/// The step machine of `ParseCase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseCase: unbounded fn Ps -> ((Case, Ps))
/// ```
pub struct ParseCase {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::Case_, crate::syntax::parser::Ps)> for ParseCase {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::Case_, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let start_p1 = crate::syntax::parser::here(p0_p0);
        let (name_p3, p1_p4) = crate::syntax::parser::parse_sname(p0_p0);
        let p2_p2 = if &name_p3.sigils != &Text::lit("") {
            crate::syntax::parser::note_error(&p1_p4, &name_p3.span, &Text::lit("a constructor takes no sigil"))
        } else {
            p1_p4.clone()
        };
        if crate::syntax::parser::at_colon(&p2_p2) {
            {
                let p3_p5 = crate::syntax::parser::adv(&p2_p2);
                let (args_p7, p4_p8) = if crate::syntax::parser::at_op(&p3_p5, &Text::lit("->")) {
                    (Array::new(), p3_p5.clone())
                } else {
                    crate::syntax::parser::commas(&p3_p5, &(Rc::new(|a0: crate::syntax::parser::Ps| entered(crate::syntax::parser::types::start_parse_emit_type(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>>>))
                };
                call_then(crate::syntax::parser::types::start_parse_type(crate::syntax::parser::expect_op(&p4_p8, &Text::lit("->"))), move |parse_type_13499: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (result_p9, p5_pa) = parse_type_13499;
                    let p6_p6 = crate::syntax::parser::out_of_scope(&p5_pa, &start_p1, &Text::lit("indexed choices/GADTs for user types"), &Text::from(format!("`{}` is an indexed alternative: indexed choices for user types are out of this compiler", &crate::syntax::parser::name_text(&name_p3))));
                    prism_rtl::Turn::Finished((crate::syntax::decls::Case_ { name: name_p3.clone(), args: args_p7.clone(), indexed: Some(result_p9.clone()), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p6_p6)) }, p6_p6.clone()))
                })
            }
        } else {
            {
                let (args_pb, p3_pc) = if crate::syntax::parser::at_stmt_boundary(&p2_p2) {
                    (Array::new(), p2_p2.clone())
                } else {
                    crate::syntax::parser::commas(&p2_p2, &(Rc::new(|a0: crate::syntax::parser::Ps| entered(crate::syntax::parser::types::start_parse_type(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>>>))
                };
                prism_rtl::Turn::Finished((crate::syntax::decls::Case_ { name: name_p3.clone(), args: args_pb.clone(), indexed: None, span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p3_pc)) }, p3_pc.clone()))
            }
        }
    }
}

/// `Start ParseCase, x`: what the function value is when passed to `@Run`.
pub fn start_parse_case(p0_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::Case_, crate::syntax::parser::Ps)>> {
    Rc::new(ParseCase { p0_p0 })
}

/// ```prism
/// ParseTagDecl: unbounded fn Ps -> ((TagDecl, Ps))
/// ```
pub fn parse_tag_decl(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::TagDecl, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here(p0_p0);
    let (name_p2, p1_p3) = crate::syntax::parser::parse_qual_name(&crate::syntax::parser::adv(p0_p0));
    let (of_type_p4, p2_p5) = crate::syntax::parser::types::parse_type(&crate::syntax::parser::expect_kw(&p1_p3, &Text::lit("of")));
    let (bounds_p6, p3_p7) = optional_bounds(&p2_p5);
    let (fields_p8, p4_p9) = if crate::syntax::parser::at_colon(&p3_p7) {
        parse_field_block(&p3_p7)
    } else {
        (Array::new(), p3_p7.clone())
    };
    (crate::syntax::decls::TagDecl { name: name_p2.clone(), of_type: of_type_p4.clone(), bounds: bounds_p6.clone(), fields: fields_p8.clone(), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p4_p9)) }, p4_p9.clone())
}

/// The step machine of `ParseTagDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTagDecl: unbounded fn Ps -> ((TagDecl, Ps))
/// ```
pub struct ParseTagDecl {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::TagDecl, crate::syntax::parser::Ps)> for ParseTagDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::TagDecl, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let start_p1 = crate::syntax::parser::here(p0_p0);
        let (name_p2, p1_p3) = crate::syntax::parser::parse_qual_name(&crate::syntax::parser::adv(p0_p0));
        call_then(crate::syntax::parser::types::start_parse_type(crate::syntax::parser::expect_kw(&p1_p3, &Text::lit("of"))), move |parse_type_14203: (crate::syntax::Type, crate::syntax::parser::Ps)| {
            let (of_type_p4, p2_p5) = parse_type_14203;
            call_then(start_optional_bounds(p2_p5.clone()), move |optional_bounds_14258: (Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps)| {
                let (bounds_p6, p3_p7) = optional_bounds_14258;
                let (fields_p8, p4_p9) = if crate::syntax::parser::at_colon(&p3_p7) {
                    parse_field_block(&p3_p7)
                } else {
                    (Array::new(), p3_p7.clone())
                };
                prism_rtl::Turn::Finished((crate::syntax::decls::TagDecl { name: name_p2.clone(), of_type: of_type_p4.clone(), bounds: bounds_p6.clone(), fields: fields_p8.clone(), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p4_p9)) }, p4_p9.clone()))
            })
        })
    }
}

/// `Start ParseTagDecl, x`: what the function value is when passed to `@Run`.
pub fn start_parse_tag_decl(p0_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TagDecl, crate::syntax::parser::Ps)>> {
    Rc::new(ParseTagDecl { p0_p0 })
}

/// ```prism
/// ParseTraitDecl: unbounded fn Ps -> ((TraitDecl, Ps))
/// ```
pub fn parse_trait_decl(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::TraitDecl, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here(p0_p0);
    let (name_p3, p1_p4) = crate::syntax::parser::parse_trait_ref(&crate::syntax::parser::adv(p0_p0));
    let (params_p5, p2_p6) = lower_params(&p1_p4);
    let (bounds_p7, p3_p8) = optional_bounds(&p2_p6);
    let (items_p9, p4_pa) = parse_trait_items(&p3_p8);
    let decl_p2 = crate::syntax::decls::TraitDecl { name: name_p3.clone(), params: params_p5.clone(), bounds: bounds_p7.clone(), items: items_p9.clone(), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p4_pa)) };
    (decl_p2.clone(), check_higher_kinded(&p4_pa, &decl_p2))
}

/// The step machine of `ParseTraitDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTraitDecl: unbounded fn Ps -> ((TraitDecl, Ps))
/// ```
pub struct ParseTraitDecl {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::TraitDecl, crate::syntax::parser::Ps)> for ParseTraitDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::TraitDecl, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let start_p1 = crate::syntax::parser::here(p0_p0);
        let (name_p3, p1_p4) = crate::syntax::parser::parse_trait_ref(&crate::syntax::parser::adv(p0_p0));
        let (params_p5, p2_p6) = lower_params(&p1_p4);
        call_then(start_optional_bounds(p2_p6.clone()), move |optional_bounds_14716: (Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps)| {
            let (bounds_p7, p3_p8) = optional_bounds_14716;
            call_then(start_parse_trait_items(p3_p8.clone()), move |parse_trait_items_14758: (Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps)| {
                let (items_p9, p4_pa) = parse_trait_items_14758;
                let decl_p2 = crate::syntax::decls::TraitDecl { name: name_p3.clone(), params: params_p5.clone(), bounds: bounds_p7.clone(), items: items_p9.clone(), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p4_pa)) };
                prism_rtl::Turn::Finished((decl_p2.clone(), check_higher_kinded(&p4_pa, &decl_p2)))
            })
        })
    }
}

/// `Start ParseTraitDecl, x`: what the function value is when passed to `@Run`.
pub fn start_parse_trait_decl(p0_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TraitDecl, crate::syntax::parser::Ps)>> {
    Rc::new(ParseTraitDecl { p0_p0 })
}

/// ```prism
/// ParseImplDecl: unbounded fn Ps -> ((ImplDecl, Ps))
/// ```
pub fn parse_impl_decl(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::ImplDecl, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here(p0_p0);
    let (trait_ref_p2, p1_p3) = crate::syntax::parser::parse_trait_ref(&crate::syntax::parser::adv(p0_p0));
    let (ty_p4, p2_p5) = crate::syntax::parser::types::parse_type(&p1_p3);
    let (bounds_p6, p3_p7) = optional_bounds(&p2_p5);
    let (items_p8, p4_p9) = parse_trait_items(&p3_p7);
    (crate::syntax::decls::ImplDecl { trait_ref: trait_ref_p2.clone(), ty: ty_p4.clone(), bounds: bounds_p6.clone(), items: items_p8.clone(), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p4_p9)) }, p4_p9.clone())
}

/// The step machine of `ParseImplDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseImplDecl: unbounded fn Ps -> ((ImplDecl, Ps))
/// ```
pub struct ParseImplDecl {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::ImplDecl, crate::syntax::parser::Ps)> for ParseImplDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::ImplDecl, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let start_p1 = crate::syntax::parser::here(p0_p0);
        let (trait_ref_p2, p1_p3) = crate::syntax::parser::parse_trait_ref(&crate::syntax::parser::adv(p0_p0));
        call_then(crate::syntax::parser::types::start_parse_type(p1_p3.clone()), move |parse_type_15144: (crate::syntax::Type, crate::syntax::parser::Ps)| {
            let (ty_p4, p2_p5) = parse_type_15144;
            call_then(start_optional_bounds(p2_p5.clone()), move |optional_bounds_15182: (Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps)| {
                let (bounds_p6, p3_p7) = optional_bounds_15182;
                call_then(start_parse_trait_items(p3_p7.clone()), move |parse_trait_items_15224: (Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps)| {
                    let (items_p8, p4_p9) = parse_trait_items_15224;
                    prism_rtl::Turn::Finished((crate::syntax::decls::ImplDecl { trait_ref: trait_ref_p2.clone(), ty: ty_p4.clone(), bounds: bounds_p6.clone(), items: items_p8.clone(), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p4_p9)) }, p4_p9.clone()))
                })
            })
        })
    }
}

/// `Start ParseImplDecl, x`: what the function value is when passed to `@Run`.
pub fn start_parse_impl_decl(p0_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::ImplDecl, crate::syntax::parser::Ps)>> {
    Rc::new(ParseImplDecl { p0_p0 })
}

/// ```prism
/// ParseTraitItems: unbounded fn Ps -> (([TraitItem], Ps))
/// ```
pub fn parse_trait_items(p0_p0: &crate::syntax::parser::Ps) -> (Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps) {
    let p_p1 = crate::syntax::parser::expect_colon(p0_p0);
    if crate::syntax::parser::at_open_l(&p_p1) {
        {
            let inside_p2 = {
                let mut this: crate::syntax::parser::Ps = crate::syntax::parser::adv(&p_p1);
                this.in_trait = true;
                this
            };
            let (items_p3, q_p4) = crate::syntax::parser::layout_items(&inside_p2, &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_trait_item(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TraitItem, crate::syntax::parser::Ps)>>>));
            (items_p3.clone(), {
                let mut this: crate::syntax::parser::Ps = q_p4.clone();
                this.in_trait = p_p1.in_trait;
                this
            })
        }
    } else {
        (Array::new(), crate::syntax::parser::error_here(&p_p1, &Text::lit("a trait\'s or impl\'s items stand in an indented block")))
    }
}

/// The step machine of `ParseTraitItems`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTraitItems: unbounded fn Ps -> (([TraitItem], Ps))
/// ```
pub struct ParseTraitItems {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps)> for ParseTraitItems {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let p_p1 = crate::syntax::parser::expect_colon(p0_p0);
        if crate::syntax::parser::at_open_l(&p_p1) {
            {
                let inside_p2 = {
                    let mut this: crate::syntax::parser::Ps = crate::syntax::parser::adv(&p_p1);
                    this.in_trait = true;
                    this
                };
                call_then(crate::syntax::parser::start_layout_items(inside_p2.clone(), Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_trait_item(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TraitItem, crate::syntax::parser::Ps)>>>), move |layout_items_15566: (Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps)| {
                    let (items_p3, q_p4) = layout_items_15566;
                    prism_rtl::Turn::Finished((items_p3.clone(), {
                        let mut this: crate::syntax::parser::Ps = q_p4.clone();
                        this.in_trait = p_p1.in_trait;
                        this
                    }))
                })
            }
        } else {
            prism_rtl::Turn::Finished((Array::new(), crate::syntax::parser::error_here(&p_p1, &Text::lit("a trait\'s or impl\'s items stand in an indented block"))))
        }
    }
}

/// `Start ParseTraitItems, x`: what the function value is when passed to `@Run`.
pub fn start_parse_trait_items(p0_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::decls::TraitItem>, crate::syntax::parser::Ps)>> {
    Rc::new(ParseTraitItems { p0_p0 })
}

/// ```prism
/// ParseTraitItem: unbounded fn Ps -> ((TraitItem, Ps))
/// ```
pub fn parse_trait_item(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::TraitItem, crate::syntax::parser::Ps) {
    match crate::syntax::parser::kind(p_p0) {
        crate::syntax::lexer::TokKind::KKw(m15834_0_0, _) if (&m15834_0_0 == &Text::lit("fn")) => {
            let (f_p1, q_p2) = parse_fn_clause(p_p0);
            (crate::syntax::decls::TraitItem::TiFn(f_p1.clone()), q_p2.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m15834_1_0, _) if (&m15834_1_0 == &Text::lit("type")) => {
            let start_p3 = crate::syntax::parser::here(p_p0);
            let p1_p4 = crate::syntax::parser::adv(p_p0);
            match crate::syntax::parser::kind(&p1_p4) {
                crate::syntax::lexer::TokKind::KName(n_p5) if (((&n_p5.case == &crate::syntax::lexer::NameCase::CaseUpper) && (&n_p5.sigils == &Text::lit(""))) && (&len(&n_p5.path_) == &Nat::from(1u32))) => {
                    let name_p6 = crate::syntax::Ident { name: or(&index(&n_p5.path_, &Nat::from(0u32)), &Text::lit("")), span: crate::syntax::parser::here(&p1_p4) };
                    let (params_p8, p2_p9) = lower_params(&crate::syntax::parser::adv(&p1_p4));
                    let (value_oa, p3_pb) = if crate::syntax::parser::at_op(&p2_p9, &Text::lit("=")) {
                        optional_type(&crate::syntax::parser::adv(&p2_p9))
                    } else {
                        (None, p2_p9.clone())
                    };
                    let item_p7 = crate::syntax::decls::TraitItem::TiAssocType(name_p6.clone(), params_p8.clone(), value_oa.clone(), crate::syntax::parser::to(&start_p3, &crate::syntax::parser::prev(&p3_pb)));
                    (item_p7.clone(), p3_pb.clone())
                },
                _ => {
                    let item_pc = crate::syntax::decls::TraitItem::TiAssocType(crate::syntax::parser::no_ident(), Array::new(), None, crate::syntax::parser::no_range());
                    (item_pc.clone(), crate::syntax::parser::error_here(&p1_p4, &Text::lit("expected the associated type\'s name")))
                },
                _ => unreachable!("no arm matched"),
            }
        },
        crate::syntax::lexer::TokKind::KKw(m15834_2_0, _) if (&m15834_2_0 == &Text::lit("row")) => {
            let start_pd = crate::syntax::parser::here(p_p0);
            let (name_pf, q_pg) = crate::syntax::parser::parse_sname(&crate::syntax::parser::adv(p_p0));
            let item_pe = crate::syntax::decls::TraitItem::TiAssocRow(name_pf.clone(), crate::syntax::parser::to(&start_pd, &crate::syntax::parser::prev(&q_pg)));
            (item_pe.clone(), q_pg.clone())
        },
        _ => {
            let (sig_ph, q_pi) = parse_signature(p_p0);
            (crate::syntax::decls::TraitItem::TiSignature(sig_ph.clone()), q_pi.clone())
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ParseTraitItem`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTraitItem: unbounded fn Ps -> ((TraitItem, Ps))
/// ```
pub struct ParseTraitItem {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::TraitItem, crate::syntax::parser::Ps)> for ParseTraitItem {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::TraitItem, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        match crate::syntax::parser::kind(p_p0) {
            crate::syntax::lexer::TokKind::KKw(m15834_0_0, _) if (&m15834_0_0 == &Text::lit("fn")) => {
                let p_p0 = p_p0.clone();
                call_then(start_parse_fn_clause(p_p0.clone()), move |parse_fn_clause_15893: (crate::syntax::decls::FnClause, crate::syntax::parser::Ps)| {
                    let (f_p1, q_p2) = parse_fn_clause_15893;
                    prism_rtl::Turn::Finished((crate::syntax::decls::TraitItem::TiFn(f_p1.clone()), q_p2.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m15834_1_0, _) if (&m15834_1_0 == &Text::lit("type")) => {
                let start_p3 = crate::syntax::parser::here(p_p0);
                let p1_p4 = crate::syntax::parser::adv(p_p0);
                match crate::syntax::parser::kind(&p1_p4) {
                    crate::syntax::lexer::TokKind::KName(n_p5) if (((&n_p5.case == &crate::syntax::lexer::NameCase::CaseUpper) && (&n_p5.sigils == &Text::lit(""))) && (&len(&n_p5.path_) == &Nat::from(1u32))) => {
                        let name_p6 = crate::syntax::Ident { name: or(&index(&n_p5.path_, &Nat::from(0u32)), &Text::lit("")), span: crate::syntax::parser::here(&p1_p4) };
                        let (params_p8, p2_p9) = lower_params(&crate::syntax::parser::adv(&p1_p4));
                        let (value_oa, p3_pb) = if crate::syntax::parser::at_op(&p2_p9, &Text::lit("=")) {
                            optional_type(&crate::syntax::parser::adv(&p2_p9))
                        } else {
                            (None, p2_p9.clone())
                        };
                        let item_p7 = crate::syntax::decls::TraitItem::TiAssocType(name_p6.clone(), params_p8.clone(), value_oa.clone(), crate::syntax::parser::to(&start_p3, &crate::syntax::parser::prev(&p3_pb)));
                        prism_rtl::Turn::Finished((item_p7.clone(), p3_pb.clone()))
                    },
                    _ => {
                        let item_pc = crate::syntax::decls::TraitItem::TiAssocType(crate::syntax::parser::no_ident(), Array::new(), None, crate::syntax::parser::no_range());
                        prism_rtl::Turn::Finished((item_pc.clone(), crate::syntax::parser::error_here(&p1_p4, &Text::lit("expected the associated type\'s name"))))
                    },
                    _ => unreachable!("no arm matched"),
                }
            },
            crate::syntax::lexer::TokKind::KKw(m15834_2_0, _) if (&m15834_2_0 == &Text::lit("row")) => {
                let start_pd = crate::syntax::parser::here(p_p0);
                let (name_pf, q_pg) = crate::syntax::parser::parse_sname(&crate::syntax::parser::adv(p_p0));
                let item_pe = crate::syntax::decls::TraitItem::TiAssocRow(name_pf.clone(), crate::syntax::parser::to(&start_pd, &crate::syntax::parser::prev(&q_pg)));
                prism_rtl::Turn::Finished((item_pe.clone(), q_pg.clone()))
            },
            _ => {
                let p_p0 = p_p0.clone();
                call_then(start_parse_signature(p_p0.clone()), move |parse_signature_16833: (crate::syntax::decls::Signature, crate::syntax::parser::Ps)| {
                    let (sig_ph, q_pi) = parse_signature_16833;
                    prism_rtl::Turn::Finished((crate::syntax::decls::TraitItem::TiSignature(sig_ph.clone()), q_pi.clone()))
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ParseTraitItem, x`: what the function value is when passed to `@Run`.
pub fn start_parse_trait_item(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::TraitItem, crate::syntax::parser::Ps)>> {
    Rc::new(ParseTraitItem { p_p0 })
}

/// ```prism
/// OptionalType: unbounded fn Ps -> ((?Type, Ps))
/// ```
pub fn optional_type(p_p0: &crate::syntax::parser::Ps) -> (Option<crate::syntax::Type>, crate::syntax::parser::Ps) {
    let (ty_p1, q_p2) = crate::syntax::parser::types::parse_type(p_p0);
    (Some(ty_p1.clone()), q_p2.clone())
}

/// The step machine of `OptionalType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptionalType: unbounded fn Ps -> ((?Type, Ps))
/// ```
pub struct OptionalType {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(Option<crate::syntax::Type>, crate::syntax::parser::Ps)> for OptionalType {
    fn cycle(&self) -> prism_rtl::Turn<(Option<crate::syntax::Type>, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let p_p0 = p_p0.clone();
        call_then(crate::syntax::parser::types::start_parse_type(p_p0.clone()), move |parse_type_16968: (crate::syntax::Type, crate::syntax::parser::Ps)| {
            let (ty_p1, q_p2) = parse_type_16968;
            prism_rtl::Turn::Finished((Some(ty_p1.clone()), q_p2.clone()))
        })
    }
}

/// `Start OptionalType, x`: what the function value is when passed to `@Run`.
pub fn start_optional_type(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(Option<crate::syntax::Type>, crate::syntax::parser::Ps)>> {
    Rc::new(OptionalType { p_p0 })
}

/// ```prism
/// CheckHigherKinded: fn Ps, TraitDecl -> Ps
/// ```
pub fn check_higher_kinded(p_p0: &crate::syntax::parser::Ps, t_p1: &crate::syntax::decls::TraitDecl) -> crate::syntax::parser::Ps {
    let hk_p2 = fold(&t_p1.items, &false, &(|seen_p3: &bool, item_p4: &crate::syntax::decls::TraitItem| *seen_p3 || item_applies(item_p4, &t_p1.params)));
    if hk_p2 && (&t_p1.name.path_ != &Array::from(vec![Text::lit("Monad")])) {
        crate::syntax::parser::out_of_scope(p_p0, &t_p1.name.span, &Text::lit("higher-kinded traits"), &Text::from(format!("`^{}` applies its parameter to arguments: higher-kinded traits are out of this compiler", &crate::syntax::lexer::chars::join(&t_p1.name.path_, &Text::lit(".")))))
    } else {
        p_p0.clone()
    }
}

/// ```prism
/// ItemApplies: fn TraitItem, [Ident] -> Bool
/// ```
pub fn item_applies(trait_item0: &crate::syntax::decls::TraitItem, xs1: &Array<crate::syntax::Ident>) -> bool {
    match (trait_item0, xs1) {
        (crate::syntax::decls::TraitItem::TiSignature(s_p0), params_p1) => applies(&s_p0.ty, params_p1),
        (_, _) => false,
    }
}

/// ```prism
/// AnyApplies: fn [Type], [Ident] -> Bool
/// ```
pub fn any_applies(ts_p0: &Array<crate::syntax::Type>, params_p1: &Array<crate::syntax::Ident>) -> bool {
    fold(ts_p0, &false, &(|seen_p2: &bool, t_p3: &crate::syntax::Type| *seen_p2 || applies(t_p3, params_p1)))
}

/// ```prism
/// Applies: fn Type, [Ident] -> Bool
/// ```
pub fn applies(ty_p0: &crate::syntax::Type, params_p1: &Array<crate::syntax::Ident>) -> bool {
    match &*ty_p0.kind {
        crate::syntax::TypeKind::TName(name_p2, args_p3) => {
            let head_p4 = ((&len(args_p3) > &Nat::from(0u32)) && (&len(&name_p2.path_) == &Nat::from(1u32))) && fold(params_p1, &false, &(|seen_p5: &bool, i_p6: &crate::syntax::Ident| *seen_p5 || (&i_p6.name == &or(&index(&name_p2.path_, &Nat::from(0u32)), &Text::lit("")))));
            head_p4 || any_applies(args_p3, params_p1)
        },
        crate::syntax::TypeKind::TSigiled(_, inner_p7) => applies(&**inner_p7, params_p1),
        crate::syntax::TypeKind::TGroup(inner_p8) => applies(&**inner_p8, params_p1),
        crate::syntax::TypeKind::TNonEmpty(inner_p9) => applies(&**inner_p9, params_p1),
        crate::syntax::TypeKind::TArray(elem_pa, _) => applies(&**elem_pa, params_p1),
        crate::syntax::TypeKind::TTuple(ts_pb) => any_applies(ts_pb, params_p1),
        crate::syntax::TypeKind::TRowUnion(ts_pc) => any_applies(ts_pc, params_p1),
        crate::syntax::TypeKind::TMap(k_pd, v_pe) => applies(&**k_pd, params_p1) || applies(&**v_pe, params_p1),
        crate::syntax::TypeKind::TFn(_, ps_pf, result_pg) => any_applies(ps_pf, params_p1) || applies(&**result_pg, params_p1),
        crate::syntax::TypeKind::TEmit(t_ph, r_pi) => applies(&**t_ph, params_p1) || applies(&**r_pi, params_p1),
        _ => false,
    }
}
