//! The module `Syntax.Parser.Blocks`, from `target/bootstrap/src/prismc/syntax/parser/blocks.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// ParseBlockAfterColon: unbounded fn Ps -> ((Block, Ps))
/// ```
pub fn parse_block_after_colon(p0: &crate::syntax::parser::Ps) -> (crate::syntax::Block, crate::syntax::parser::Ps) {
    let p_ = crate::syntax::parser::expect_colon(p0);
    if crate::syntax::parser::at_open_l(&p_) {
        parse_indented_block(&p_)
    } else {
        if crate::syntax::parser::at_stmt_boundary(&p_) {
            (crate::syntax::parser::decls::no_block(), crate::syntax::parser::error_here(&p_, &Text::lit("expected a statement after `:`")))
        } else {
            {
                let start = crate::syntax::parser::here(&p_);
                let (first_, p1) = parse_stmt(&p_);
                let r = {
                    let mut this: (Array<crate::syntax::Stmt>, crate::syntax::parser::Ps) = (Array::from(vec![first_.clone()]), p1.clone());
                    let mut stmts: Array<crate::syntax::Stmt> = Array::from(vec![first_.clone()]);
                    let mut q: crate::syntax::parser::Ps = p1.clone();
                    while (&crate::syntax::parser::kind(&q) == &crate::syntax::lexer::TokKind::KSemi) && !q.bad {
                        let (st, q2) = parse_stmt(&crate::syntax::parser::adv(&q));
                        stmts = push(&stmts, &st);
                        q = q2.clone();
                    }
                    this = (stmts.clone(), q.clone());
                    this
                };
                let (stmts, q) = r.clone();
                (crate::syntax::Block { stmts: stmts.clone(), inline: true, span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone())
            }
        }
    }
}

/// The step machine of `ParseBlockAfterColon`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseBlockAfterColon: unbounded fn Ps -> ((Block, Ps))
/// ```
pub struct ParseBlockAfterColon {
    pub p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Block, crate::syntax::parser::Ps)> for ParseBlockAfterColon {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Block, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let p_ = crate::syntax::parser::expect_colon(p0);
        if crate::syntax::parser::at_open_l(&p_) {
            prism_rtl::Turn::More(Rc::new(ParseIndentedBlock { p0: p_.clone() }))
        } else {
            if crate::syntax::parser::at_stmt_boundary(&p_) {
                prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_block(), crate::syntax::parser::error_here(&p_, &Text::lit("expected a statement after `:`"))))
            } else {
                {
                    let start = crate::syntax::parser::here(&p_);
                    call_then(start_parse_stmt(p_.clone()), move |parse_stmt_1224: (crate::syntax::Stmt, crate::syntax::parser::Ps)| {
                        let (first_, p1) = parse_stmt_1224;
                        let mut this: (Array<crate::syntax::Stmt>, crate::syntax::parser::Ps) = (Array::from(vec![first_.clone()]), p1.clone());
                        let mut stmts: Array<crate::syntax::Stmt> = Array::from(vec![first_.clone()]);
                        let mut q: crate::syntax::parser::Ps = p1.clone();
                        let start = start.clone();
                        call_then(loop_job((this, q, stmts), move |(mut this, mut q, mut stmts): ((Array<crate::syntax::Stmt>, crate::syntax::parser::Ps), crate::syntax::parser::Ps, Array<crate::syntax::Stmt>)| if (&crate::syntax::parser::kind(&q) == &crate::syntax::lexer::TokKind::KSemi) && !q.bad {
                            {
                                let (st, q2) = parse_stmt(&crate::syntax::parser::adv(&q));
                                stmts = push(&stmts, &st);
                                q = q2.clone();
                                Ok((this, q, stmts))
                            }
                        } else {
                            Err((this, q, stmts))
                        }), move |(mut this, mut q, mut stmts): ((Array<crate::syntax::Stmt>, crate::syntax::parser::Ps), crate::syntax::parser::Ps, Array<crate::syntax::Stmt>)| {
                            this = (stmts.clone(), q.clone());
                            let r = this;
                            let (stmts, q) = r.clone();
                            prism_rtl::Turn::Finished((crate::syntax::Block { stmts: stmts.clone(), inline: true, span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone()))
                        })
                    })
                }
            }
        }
    }
}

/// `Start ParseBlockAfterColon, x`: what the function value is when passed to `@Run`.
pub fn start_parse_block_after_colon(p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Block, crate::syntax::parser::Ps)>> {
    Rc::new(ParseBlockAfterColon { p0 })
}

/// ```prism
/// ParseIndentedBlock: unbounded fn Ps -> ((Block, Ps))
/// ```
pub fn parse_indented_block(p0: &crate::syntax::parser::Ps) -> (crate::syntax::Block, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p0);
    let (stmts, q) = stmts_until(&crate::syntax::parser::adv(p0), &true);
    (crate::syntax::Block { stmts: stmts.clone(), inline: false, span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone())
}

/// The step machine of `ParseIndentedBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseIndentedBlock: unbounded fn Ps -> ((Block, Ps))
/// ```
pub struct ParseIndentedBlock {
    pub p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Block, crate::syntax::parser::Ps)> for ParseIndentedBlock {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Block, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let start = crate::syntax::parser::here(p0);
        let p0 = p0.clone();
        call_then(start_stmts_until(crate::syntax::parser::adv(&p0), true), move |stmts_until_1826: (Array<crate::syntax::Stmt>, crate::syntax::parser::Ps)| {
            let (stmts, q) = stmts_until_1826;
            prism_rtl::Turn::Finished((crate::syntax::Block { stmts: stmts.clone(), inline: false, span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone()))
        })
    }
}

/// `Start ParseIndentedBlock, x`: what the function value is when passed to `@Run`.
pub fn start_parse_indented_block(p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Block, crate::syntax::parser::Ps)>> {
    Rc::new(ParseIndentedBlock { p0 })
}

/// ```prism
/// ParseBlockUntilEof: unbounded fn Ps, Range -> ((Block, Ps))
/// ```
pub fn parse_block_until_eof(p_: &crate::syntax::parser::Ps, span: &crate::syntax::Range) -> (crate::syntax::Block, crate::syntax::parser::Ps) {
    let (stmts, q) = if crate::syntax::parser::at_eof(p_) {
        (Array::new(), p_.clone())
    } else {
        stmts_until(p_, &false)
    };
    (crate::syntax::Block { stmts: stmts.clone(), inline: false, span: span.clone() }, q.clone())
}

/// The step machine of `ParseBlockUntilEof`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseBlockUntilEof: unbounded fn Ps, Range -> ((Block, Ps))
/// ```
pub struct ParseBlockUntilEof {
    pub p_: crate::syntax::parser::Ps,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::syntax::Block, crate::syntax::parser::Ps)> for ParseBlockUntilEof {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Block, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let span = &self.span;
        let (stmts, q) = if crate::syntax::parser::at_eof(p_) {
            (Array::new(), p_.clone())
        } else {
            stmts_until(p_, &false)
        };
        prism_rtl::Turn::Finished((crate::syntax::Block { stmts: stmts.clone(), inline: false, span: span.clone() }, q.clone()))
    }
}

/// `Start ParseBlockUntilEof, x`: what the function value is when passed to `@Run`.
pub fn start_parse_block_until_eof(p_: crate::syntax::parser::Ps, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::syntax::Block, crate::syntax::parser::Ps)>> {
    Rc::new(ParseBlockUntilEof { p_, span })
}

/// ```prism
/// StmtsUntil: unbounded fn Ps, Bool -> (([Stmt], Ps))
/// ```
pub fn stmts_until(p0: &crate::syntax::parser::Ps, indented: &bool) -> (Array<crate::syntax::Stmt>, crate::syntax::parser::Ps) {
    let mut this: (Array<crate::syntax::Stmt>, crate::syntax::parser::Ps) = (Array::new(), p0.clone());
    let mut stmts: Array<crate::syntax::Stmt> = Array::new();
    let mut p_: crate::syntax::parser::Ps = p0.clone();
    let mut going: bool = true;
    while going {
        let (st, q) = parse_stmt(&p_);
        if !q.bad {
            stmts = push(&stmts, &st);
        }
        p_ = crate::syntax::parser::recovered(&q);
        match &crate::syntax::parser::kind(&p_) {
            crate::syntax::lexer::TokKind::KLaySep => {
                p_ = crate::syntax::parser::adv(&p_);
                if !*indented && crate::syntax::parser::at_eof(&p_) {
                    going = false;
                }
            }
            crate::syntax::lexer::TokKind::KLayClose => {
                p_ = crate::syntax::parser::adv(&p_);
                if *indented || crate::syntax::parser::at_eof(&p_) {
                    going = false;
                }
            }
            crate::syntax::lexer::TokKind::KEof => {
                going = false;
            }
            _ => {
                p_ = crate::syntax::parser::recover(&crate::syntax::parser::complain(&p_, &Text::lit("expected the end of the statement")));
            }
        }
    }
    this = (stmts.clone(), p_.clone());
    this
}

/// The step machine of `StmtsUntil`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtsUntil: unbounded fn Ps, Bool -> (([Stmt], Ps))
/// ```
pub struct StmtsUntil {
    pub p0: crate::syntax::parser::Ps,
    pub indented: bool,
}

impl prism_rtl::Job<(Array<crate::syntax::Stmt>, crate::syntax::parser::Ps)> for StmtsUntil {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::Stmt>, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let indented = &self.indented;
        let mut this: (Array<crate::syntax::Stmt>, crate::syntax::parser::Ps) = (Array::new(), p0.clone());
        let mut stmts: Array<crate::syntax::Stmt> = Array::new();
        let mut p_: crate::syntax::parser::Ps = p0.clone();
        let mut going: bool = true;
        call_then(loop_job((this, going, p_, stmts), {
            let indented = *indented;
            move |(mut this, mut going, mut p_, mut stmts): ((Array<crate::syntax::Stmt>, crate::syntax::parser::Ps), bool, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>)| if going {
                {
                    let (st, q) = parse_stmt(&p_);
                    if !q.bad {
                        stmts = push(&stmts, &st);
                    }
                    p_ = crate::syntax::parser::recovered(&q);
                    match &crate::syntax::parser::kind(&p_) {
                        crate::syntax::lexer::TokKind::KLaySep => {
                            p_ = crate::syntax::parser::adv(&p_);
                            if !indented && crate::syntax::parser::at_eof(&p_) {
                                going = false;
                            }
                        }
                        crate::syntax::lexer::TokKind::KLayClose => {
                            p_ = crate::syntax::parser::adv(&p_);
                            if indented || crate::syntax::parser::at_eof(&p_) {
                                going = false;
                            }
                        }
                        crate::syntax::lexer::TokKind::KEof => {
                            going = false;
                        }
                        _ => {
                            p_ = crate::syntax::parser::recover(&crate::syntax::parser::complain(&p_, &Text::lit("expected the end of the statement")));
                        }
                    }
                    Ok((this, going, p_, stmts))
                }
            } else {
                Err((this, going, p_, stmts))
            }
        }), move |(mut this, mut going, mut p_, mut stmts): ((Array<crate::syntax::Stmt>, crate::syntax::parser::Ps), bool, crate::syntax::parser::Ps, Array<crate::syntax::Stmt>)| {
            this = (stmts.clone(), p_.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start StmtsUntil, x`: what the function value is when passed to `@Run`.
pub fn start_stmts_until(p0: crate::syntax::parser::Ps, indented: bool) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Stmt>, crate::syntax::parser::Ps)>> {
    Rc::new(StmtsUntil { p0, indented })
}

/// ```prism
/// ParseStmt: unbounded fn Ps -> ((Stmt, Ps))
/// ```
pub fn parse_stmt(p_: &crate::syntax::parser::Ps) -> (crate::syntax::Stmt, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p_);
    let (kind, q) = stmt_kind_of(p_, &start);
    (crate::syntax::Stmt { kind: kind.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone())
}

/// The step machine of `ParseStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseStmt: unbounded fn Ps -> ((Stmt, Ps))
/// ```
pub struct ParseStmt {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Stmt, crate::syntax::parser::Ps)> for ParseStmt {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Stmt, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let start = crate::syntax::parser::here(p_);
        let p_ = p_.clone();
        call_then(start_stmt_kind_of(p_.clone(), start.clone()), move |stmt_kind_of_3254: (crate::syntax::StmtKind, crate::syntax::parser::Ps)| {
            let (kind, q) = stmt_kind_of_3254;
            prism_rtl::Turn::Finished((crate::syntax::Stmt { kind: kind.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone()))
        })
    }
}

/// `Start ParseStmt, x`: what the function value is when passed to `@Run`.
pub fn start_parse_stmt(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Stmt, crate::syntax::parser::Ps)>> {
    Rc::new(ParseStmt { p_ })
}

/// ```prism
/// StmtKindOf: unbounded fn Ps, Range -> ((StmtKind, Ps))
/// ```
pub fn stmt_kind_of(p_: &crate::syntax::parser::Ps, start: &crate::syntax::Range) -> (crate::syntax::StmtKind, crate::syntax::parser::Ps) {
    match crate::syntax::parser::kind(p_) {
        crate::syntax::lexer::TokKind::KKw(m3409_0_0, m3409_0_1) if (&m3409_0_0 == &Text::lit("emit")) && (&m3409_0_1 == &Text::lit("")) => {
            let (r, q) = crate::syntax::parser::types::parse_row(&crate::syntax::parser::adv(p_));
            (crate::syntax::StmtKind::SEmit(r.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m3409_1_0, m3409_1_1) if (&m3409_1_0 == &Text::lit("let")) && (&m3409_1_1 == &Text::lit("")) => {
            let (pattern, p1) = crate::syntax::parser::types::parse_pattern(&crate::syntax::parser::adv(p_), &false);
            let (ty_opt, p2) = crate::syntax::parser::decls::optional_annotation(&p1);
            let (value, p3) = crate::syntax::parser::expr::parse_rhs_expr(&crate::syntax::parser::expect_op(&p2, &Text::lit("=")));
            (crate::syntax::StmtKind::SLet(pattern.clone(), ty_opt.clone(), value.clone()), p3.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m3409_2_0, m3409_2_1) if (&m3409_2_0 == &Text::lit("fn")) && (&m3409_2_1 == &Text::lit("")) => {
            let (f, q) = crate::syntax::parser::decls::parse_fn_clause(p_);
            (crate::syntax::StmtKind::SFn(f.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m3409_3_0, m3409_3_1) if (&m3409_3_0 == &Text::lit("ignore")) && (&m3409_3_1 == &Text::lit("")) && crate::syntax::parser::at_op(&crate::syntax::parser::adv(p_), &Text::lit("<-")) => {
            let (e, q) = crate::syntax::parser::expr::parse_rhs_expr(&crate::syntax::parser::adv(&crate::syntax::parser::adv(p_)));
            (crate::syntax::StmtKind::SIgnore(e.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(w, m3409_4_1) if (&m3409_4_1 == &Text::lit("")) && ((&w == &Text::lit("require")) || (&w == &Text::lit("forbid"))) => {
            let (c, p1) = crate::syntax::parser::expr::parse_rhs_expr(&crate::syntax::parser::adv(p_));
            let q = if crate::syntax::parser::at_comma(&p1) {
                crate::syntax::parser::error_at(&p1, &crate::syntax::parser::here(&p1), &Text::from(format!("`{}` takes its condition alone, with no error value after a comma (decisions.md D15): a failed guard under `~` raises `Prelude.Unmet` (D11), and a comma after a guard belongs to a call at the head of its condition, as in `require Clear g, from, corner`", &w)))
            } else {
                p1.clone()
            };
            if &w == &Text::lit("require") {
                (crate::syntax::StmtKind::SRequire(c.clone()), q.clone())
            } else {
                (crate::syntax::StmtKind::SForbid(c.clone()), q.clone())
            }
        },
        crate::syntax::lexer::TokKind::KKw(m3409_5_0, m3409_5_1) if (&m3409_5_0 == &Text::lit("while")) && (&m3409_5_1 == &Text::lit("")) => {
            let (cond, p1) = crate::syntax::parser::expr::parse_cond(&crate::syntax::parser::adv(p_), &true);
            let (body, q) = parse_block_after_colon(&p1);
            (crate::syntax::StmtKind::SWhile(cond.clone(), body.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m3409_6_0, m3409_6_1) if (&m3409_6_0 == &Text::lit("return")) && (&m3409_6_1 == &Text::lit("")) => {
            let p1 = crate::syntax::parser::out_of_scope(&crate::syntax::parser::adv(p_), &crate::syntax::parser::here(p_), &Text::lit("`T monad:` blocks and `^Monad`"), &Text::lit("`return` ends a monad block, which is out of this compiler"));
            let (e, q) = crate::syntax::parser::expr::parse_rhs_expr(&p1);
            (crate::syntax::StmtKind::SReturn(e.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KName(_) if (&crate::syntax::parser::kind_at(p_, &Nat::from(1u32)) == &crate::syntax::lexer::TokKind::KColon) => if &crate::syntax::parser::kind_at(p_, &Nat::from(2u32)) == &crate::syntax::lexer::TokKind::KLayOpen {
            {
                let (name, p1) = crate::syntax::parser::parse_sname(p_);
                let (body, q) = parse_block_after_colon(&p1);
                (crate::syntax::StmtKind::SWidget(crate::syntax::decls::WidgetDecl { name: name.clone(), body: body.clone(), span: crate::syntax::parser::to(start, &body.span) }), q.clone())
            }
        } else {
            {
                let (sig, q) = crate::syntax::parser::decls::parse_signature(p_);
                (crate::syntax::StmtKind::SSignature(sig.clone()), q.clone())
            }
        },
        _ => other_stmt(p_),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `StmtKindOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtKindOf: unbounded fn Ps, Range -> ((StmtKind, Ps))
/// ```
pub struct StmtKindOf {
    pub p_: crate::syntax::parser::Ps,
    pub start: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::syntax::StmtKind, crate::syntax::parser::Ps)> for StmtKindOf {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::StmtKind, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let start = &self.start;
        match crate::syntax::parser::kind(p_) {
            crate::syntax::lexer::TokKind::KKw(m3409_0_0, m3409_0_1) if (&m3409_0_0 == &Text::lit("emit")) && (&m3409_0_1 == &Text::lit("")) => {
                let p_ = p_.clone();
                call_then(crate::syntax::parser::types::start_parse_row(crate::syntax::parser::adv(&p_)), move |parse_row_3466: (crate::syntax::Row_, crate::syntax::parser::Ps)| {
                    let (r, q) = parse_row_3466;
                    prism_rtl::Turn::Finished((crate::syntax::StmtKind::SEmit(r.clone()), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m3409_1_0, m3409_1_1) if (&m3409_1_0 == &Text::lit("let")) && (&m3409_1_1 == &Text::lit("")) => {
                let p_ = p_.clone();
                call_then(crate::syntax::parser::types::start_parse_pattern(crate::syntax::parser::adv(&p_), false), move |parse_pattern_3555: (crate::syntax::Pattern_, crate::syntax::parser::Ps)| {
                    let (pattern, p1) = parse_pattern_3555;
                    call_then(crate::syntax::parser::decls::start_optional_annotation(p1.clone()), move |optional_annotation_3609: (Option<crate::syntax::Type>, crate::syntax::parser::Ps)| {
                        let (ty_opt, p2) = optional_annotation_3609;
                        call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::expect_op(&p2, &Text::lit("="))), move |parse_rhs_expr_3659: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                            let (value, p3) = parse_rhs_expr_3659;
                            prism_rtl::Turn::Finished((crate::syntax::StmtKind::SLet(pattern.clone(), ty_opt.clone(), value.clone()), p3.clone()))
                        })
                    })
                })
            },
            crate::syntax::lexer::TokKind::KKw(m3409_2_0, m3409_2_1) if (&m3409_2_0 == &Text::lit("fn")) && (&m3409_2_1 == &Text::lit("")) => {
                let p_ = p_.clone();
                call_then(crate::syntax::parser::decls::start_parse_fn_clause(p_.clone()), move |parse_fn_clause_3775: (crate::syntax::decls::FnClause, crate::syntax::parser::Ps)| {
                    let (f, q) = parse_fn_clause_3775;
                    prism_rtl::Turn::Finished((crate::syntax::StmtKind::SFn(f.clone()), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m3409_3_0, m3409_3_1) if (&m3409_3_0 == &Text::lit("ignore")) && (&m3409_3_1 == &Text::lit("")) && crate::syntax::parser::at_op(&crate::syntax::parser::adv(p_), &Text::lit("<-")) => {
                let p_ = p_.clone();
                call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::adv(&crate::syntax::parser::adv(&p_))), move |parse_rhs_expr_3881: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (e, q) = parse_rhs_expr_3881;
                    prism_rtl::Turn::Finished((crate::syntax::StmtKind::SIgnore(e.clone()), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(w, m3409_4_1) if (&m3409_4_1 == &Text::lit("")) && ((&w == &Text::lit("require")) || (&w == &Text::lit("forbid"))) => {
                let p_ = p_.clone();
                call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::adv(&p_)), move |parse_rhs_expr_4174: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (c, p1) = parse_rhs_expr_4174;
                    let q = if crate::syntax::parser::at_comma(&p1) {
                        crate::syntax::parser::error_at(&p1, &crate::syntax::parser::here(&p1), &Text::from(format!("`{}` takes its condition alone, with no error value after a comma (decisions.md D15): a failed guard under `~` raises `Prelude.Unmet` (D11), and a comma after a guard belongs to a call at the head of its condition, as in `require Clear g, from, corner`", &w)))
                    } else {
                        p1.clone()
                    };
                    if &w == &Text::lit("require") {
                        prism_rtl::Turn::Finished((crate::syntax::StmtKind::SRequire(c.clone()), q.clone()))
                    } else {
                        prism_rtl::Turn::Finished((crate::syntax::StmtKind::SForbid(c.clone()), q.clone()))
                    }
                })
            },
            crate::syntax::lexer::TokKind::KKw(m3409_5_0, m3409_5_1) if (&m3409_5_0 == &Text::lit("while")) && (&m3409_5_1 == &Text::lit("")) => {
                let p_ = p_.clone();
                call_then(crate::syntax::parser::expr::start_parse_cond(crate::syntax::parser::adv(&p_), true), move |parse_cond_4630: (crate::syntax::Cond, crate::syntax::parser::Ps)| {
                    let (cond, p1) = parse_cond_4630;
                    call_then(start_parse_block_after_colon(p1.clone()), move |parse_block_after_colon_4680: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                        let (body, q) = parse_block_after_colon_4680;
                        prism_rtl::Turn::Finished((crate::syntax::StmtKind::SWhile(cond.clone(), body.clone()), q.clone()))
                    })
                })
            },
            crate::syntax::lexer::TokKind::KKw(m3409_6_0, m3409_6_1) if (&m3409_6_0 == &Text::lit("return")) && (&m3409_6_1 == &Text::lit("")) => {
                let p1 = crate::syntax::parser::out_of_scope(&crate::syntax::parser::adv(p_), &crate::syntax::parser::here(p_), &Text::lit("`T monad:` blocks and `^Monad`"), &Text::lit("`return` ends a monad block, which is out of this compiler"));
                call_then(crate::syntax::parser::expr::start_parse_rhs_expr(p1.clone()), move |parse_rhs_expr_4926: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (e, q) = parse_rhs_expr_4926;
                    prism_rtl::Turn::Finished((crate::syntax::StmtKind::SReturn(e.clone()), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KName(_) if (&crate::syntax::parser::kind_at(p_, &Nat::from(1u32)) == &crate::syntax::lexer::TokKind::KColon) => if &crate::syntax::parser::kind_at(p_, &Nat::from(2u32)) == &crate::syntax::lexer::TokKind::KLayOpen {
                {
                    let (name, p1) = crate::syntax::parser::parse_sname(p_);
                    let start = start.clone();
                    call_then(start_parse_block_after_colon(p1.clone()), move |parse_block_after_colon_5173: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                        let (body, q) = parse_block_after_colon_5173;
                        prism_rtl::Turn::Finished((crate::syntax::StmtKind::SWidget(crate::syntax::decls::WidgetDecl { name: name.clone(), body: body.clone(), span: crate::syntax::parser::to(&start, &body.span) }), q.clone()))
                    })
                }
            } else {
                {
                    let p_ = p_.clone();
                    call_then(crate::syntax::parser::decls::start_parse_signature(p_.clone()), move |parse_signature_5328: (crate::syntax::decls::Signature, crate::syntax::parser::Ps)| {
                        let (sig, q) = parse_signature_5328;
                        prism_rtl::Turn::Finished((crate::syntax::StmtKind::SSignature(sig.clone()), q.clone()))
                    })
                }
            },
            _ => prism_rtl::Turn::More(Rc::new(OtherStmt { p_: p_.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start StmtKindOf, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_kind_of(p_: crate::syntax::parser::Ps, start: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::syntax::StmtKind, crate::syntax::parser::Ps)>> {
    Rc::new(StmtKindOf { p_, start })
}

/// ```prism
/// OtherStmt: unbounded fn Ps -> ((StmtKind, Ps))
/// ```
pub fn other_stmt(p_: &crate::syntax::parser::Ps) -> (crate::syntax::StmtKind, crate::syntax::parser::Ps) {
    let (upd, u) = parse_update_stmt(p_);
    let (pattern, b) = crate::syntax::parser::types::parse_pattern(p_, &true);
    if !u.bad {
        (upd.clone(), u.clone())
    } else {
        if !b.bad && crate::syntax::parser::at_op(&b, &Text::lit("<-")) {
            {
                let (value, p1) = crate::syntax::parser::expr::parse_rhs_expr(&crate::syntax::parser::adv(&b));
                let (then_step_opt, p2) = if crate::syntax::parser::at_kw(&p1, &Text::lit("then")) {
                    optional_rhs(&crate::syntax::parser::adv(&p1))
                } else {
                    (None, p1.clone())
                };
                if crate::syntax::parser::at_kw(&p2, &Text::lit("then")) {
                    (crate::syntax::StmtKind::SExpr(crate::syntax::parser::decls::no_expr()), crate::syntax::parser::error_at(&p2, &crate::syntax::parser::here(&p2), &Text::lit("`then` does not associate: a hold has one start and one step")))
                } else {
                    (crate::syntax::StmtKind::SBind(pattern.clone(), value.clone(), then_step_opt.clone()), p2.clone())
                }
            }
        } else {
            {
                let (e, p1) = crate::syntax::parser::expr::parse_rhs_expr(p_);
                if crate::syntax::parser::at_op(&p1, &Text::lit("<-")) {
                    (crate::syntax::StmtKind::SExpr(e.clone()), crate::syntax::parser::error_at(&p1, &crate::syntax::parser::here(&p1), &Text::lit("the left side of `<-` is not a pattern")))
                } else {
                    if crate::syntax::parser::at_kw(&p1, &Text::lit("then")) {
                        (crate::syntax::StmtKind::SExpr(e.clone()), crate::syntax::parser::error_at(&p1, &crate::syntax::parser::here(&p1), &Text::lit("`then` belongs to a hold: `$x <- start then step`")))
                    } else {
                        (crate::syntax::StmtKind::SExpr(e.clone()), p1.clone())
                    }
                }
            }
        }
    }
}

/// The step machine of `OtherStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OtherStmt: unbounded fn Ps -> ((StmtKind, Ps))
/// ```
pub struct OtherStmt {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::StmtKind, crate::syntax::parser::Ps)> for OtherStmt {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::StmtKind, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let p_ = p_.clone();
        call_then(start_parse_update_stmt(p_.clone()), move |parse_update_stmt_5569: (crate::syntax::StmtKind, crate::syntax::parser::Ps)| {
            let (upd, u) = parse_update_stmt_5569;
            call_then(crate::syntax::parser::types::start_parse_pattern(p_.clone(), true), move |parse_pattern_5612: (crate::syntax::Pattern_, crate::syntax::parser::Ps)| {
                let (pattern, b) = parse_pattern_5612;
                if !u.bad {
                    prism_rtl::Turn::Finished((upd.clone(), u.clone()))
                } else {
                    if !b.bad && crate::syntax::parser::at_op(&b, &Text::lit("<-")) {
                        call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::adv(&b)), move |parse_rhs_expr_5733: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                            let (value, p1) = parse_rhs_expr_5733;
                            let (then_step_opt, p2) = if crate::syntax::parser::at_kw(&p1, &Text::lit("then")) {
                                optional_rhs(&crate::syntax::parser::adv(&p1))
                            } else {
                                (None, p1.clone())
                            };
                            if crate::syntax::parser::at_kw(&p2, &Text::lit("then")) {
                                prism_rtl::Turn::Finished((crate::syntax::StmtKind::SExpr(crate::syntax::parser::decls::no_expr()), crate::syntax::parser::error_at(&p2, &crate::syntax::parser::here(&p2), &Text::lit("`then` does not associate: a hold has one start and one step"))))
                            } else {
                                prism_rtl::Turn::Finished((crate::syntax::StmtKind::SBind(pattern.clone(), value.clone(), then_step_opt.clone()), p2.clone()))
                            }
                        })
                    } else {
                        call_then(crate::syntax::parser::expr::start_parse_rhs_expr(p_.clone()), move |parse_rhs_expr_6069: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                            let (e, p1) = parse_rhs_expr_6069;
                            if crate::syntax::parser::at_op(&p1, &Text::lit("<-")) {
                                prism_rtl::Turn::Finished((crate::syntax::StmtKind::SExpr(e.clone()), crate::syntax::parser::error_at(&p1, &crate::syntax::parser::here(&p1), &Text::lit("the left side of `<-` is not a pattern"))))
                            } else {
                                if crate::syntax::parser::at_kw(&p1, &Text::lit("then")) {
                                    prism_rtl::Turn::Finished((crate::syntax::StmtKind::SExpr(e.clone()), crate::syntax::parser::error_at(&p1, &crate::syntax::parser::here(&p1), &Text::lit("`then` belongs to a hold: `$x <- start then step`"))))
                                } else {
                                    prism_rtl::Turn::Finished((crate::syntax::StmtKind::SExpr(e.clone()), p1.clone()))
                                }
                            }
                        })
                    }
                }
            })
        })
    }
}

/// `Start OtherStmt, x`: what the function value is when passed to `@Run`.
pub fn start_other_stmt(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::StmtKind, crate::syntax::parser::Ps)>> {
    Rc::new(OtherStmt { p_ })
}

/// ```prism
/// OptionalRhs: unbounded fn Ps -> ((?Expr, Ps))
/// ```
pub fn optional_rhs(p_: &crate::syntax::parser::Ps) -> (Option<crate::syntax::Expr>, crate::syntax::parser::Ps) {
    let (e, q) = crate::syntax::parser::expr::parse_rhs_expr(p_);
    (Some(e.clone()), q.clone())
}

/// The step machine of `OptionalRhs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptionalRhs: unbounded fn Ps -> ((?Expr, Ps))
/// ```
pub struct OptionalRhs {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(Option<crate::syntax::Expr>, crate::syntax::parser::Ps)> for OptionalRhs {
    fn cycle(&self) -> prism_rtl::Turn<(Option<crate::syntax::Expr>, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let p_ = p_.clone();
        call_then(crate::syntax::parser::expr::start_parse_rhs_expr(p_.clone()), move |parse_rhs_expr_6427: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
            let (e, q) = parse_rhs_expr_6427;
            prism_rtl::Turn::Finished((Some(e.clone()), q.clone()))
        })
    }
}

/// `Start OptionalRhs, x`: what the function value is when passed to `@Run`.
pub fn start_optional_rhs(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(Option<crate::syntax::Expr>, crate::syntax::parser::Ps)>> {
    Rc::new(OptionalRhs { p_ })
}

/// ```prism
/// ParseUpdateStmt: unbounded fn Ps -> ((StmtKind, Ps))
/// ```
pub fn parse_update_stmt(p_: &crate::syntax::parser::Ps) -> (crate::syntax::StmtKind, crate::syntax::parser::Ps) {
    let (target, p1) = parse_reference(p_);
    let op = match crate::syntax::parser::kind(&p1) {
        crate::syntax::lexer::TokKind::KOp(o, _) => o.clone(),
        _ => Text::lit(""),
    };
    if p1.bad || !(((((&op == &Text::lit("<=")) || (&op == &Text::lit("+="))) || (&op == &Text::lit("-="))) || (&op == &Text::lit("*="))) || (&op == &Text::lit("/="))) {
        (crate::syntax::StmtKind::SExpr(crate::syntax::parser::decls::no_expr()), crate::syntax::parser::fail(&p1))
    } else {
        {
            let (value, q) = crate::syntax::parser::expr::parse_rhs_expr(&crate::syntax::parser::adv(&p1));
            if &op == &Text::lit("<=") {
                (crate::syntax::StmtKind::SSet(target.clone(), value.clone()), q.clone())
            } else {
                (crate::syntax::StmtKind::SAccum(target.clone(), op.clone(), value.clone()), q.clone())
            }
        }
    }
}

/// The step machine of `ParseUpdateStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseUpdateStmt: unbounded fn Ps -> ((StmtKind, Ps))
/// ```
pub struct ParseUpdateStmt {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::StmtKind, crate::syntax::parser::Ps)> for ParseUpdateStmt {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::StmtKind, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let p_ = p_.clone();
        call_then(start_parse_reference(p_.clone()), move |parse_reference_6741: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
            let (target, p1) = parse_reference_6741;
            let op = match crate::syntax::parser::kind(&p1) {
                crate::syntax::lexer::TokKind::KOp(o, _) => o.clone(),
                _ => Text::lit(""),
            };
            if p1.bad || !(((((&op == &Text::lit("<=")) || (&op == &Text::lit("+="))) || (&op == &Text::lit("-="))) || (&op == &Text::lit("*="))) || (&op == &Text::lit("/="))) {
                prism_rtl::Turn::Finished((crate::syntax::StmtKind::SExpr(crate::syntax::parser::decls::no_expr()), crate::syntax::parser::fail(&p1)))
            } else {
                call_then(crate::syntax::parser::expr::start_parse_rhs_expr(crate::syntax::parser::adv(&p1)), move |parse_rhs_expr_6989: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (value, q) = parse_rhs_expr_6989;
                    if &op == &Text::lit("<=") {
                        prism_rtl::Turn::Finished((crate::syntax::StmtKind::SSet(target.clone(), value.clone()), q.clone()))
                    } else {
                        prism_rtl::Turn::Finished((crate::syntax::StmtKind::SAccum(target.clone(), op.clone(), value.clone()), q.clone()))
                    }
                })
            }
        })
    }
}

/// `Start ParseUpdateStmt, x`: what the function value is when passed to `@Run`.
pub fn start_parse_update_stmt(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::StmtKind, crate::syntax::parser::Ps)>> {
    Rc::new(ParseUpdateStmt { p_ })
}

/// ```prism
/// ParseReference: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_reference(p_: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    match crate::syntax::parser::kind(p_) {
        crate::syntax::lexer::TokKind::KName(n) if crate::syntax::lexer::chars::has_prefix(&n.sigils, &Text::lit("&")) => {
            let start = crate::syntax::parser::here(p_);
            let (name, p1) = crate::syntax::parser::parse_sname(p_);
            if crate::syntax::parser::is_upper_name(&name) {
                {
                    let p2 = crate::syntax::parser::out_of_scope(&p1, &name.span, &Text::lit("named lenses `&Home` and `Over`"), &Text::from(format!("the named lens `{}` is out of this compiler; write its path, `&_.score.home`", &crate::syntax::parser::name_text(&name))));
                    let (inner, q) = parse_reference(&p2);
                    let callee = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(name.clone())), span: start.clone() };
                    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECall(Rc::new(callee.clone()), Array::from(vec![crate::syntax::Arg { name: None, value: inner.clone(), span: inner.span.clone() }]), false, false)), span: crate::syntax::parser::to(&start, &inner.span) }, q.clone())
                }
            } else {
                lens_steps(&crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(name.clone())), span: name.span.clone() }, &p1)
            }
        },
        _ => (crate::syntax::parser::decls::no_expr(), crate::syntax::parser::fail(p_)),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ParseReference`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseReference: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseReference {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseReference {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        match crate::syntax::parser::kind(p_) {
            crate::syntax::lexer::TokKind::KName(n) if crate::syntax::lexer::chars::has_prefix(&n.sigils, &Text::lit("&")) => {
                let start = crate::syntax::parser::here(p_);
                let (name, p1) = crate::syntax::parser::parse_sname(p_);
                if crate::syntax::parser::is_upper_name(&name) {
                    {
                        let p2 = crate::syntax::parser::out_of_scope(&p1, &name.span, &Text::lit("named lenses `&Home` and `Over`"), &Text::from(format!("the named lens `{}` is out of this compiler; write its path, `&_.score.home`", &crate::syntax::parser::name_text(&name))));
                        call_then(start_parse_reference(p2.clone()), move |parse_reference_7673: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                            let (inner, q) = parse_reference_7673;
                            let callee = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(name.clone())), span: start.clone() };
                            prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECall(Rc::new(callee.clone()), Array::from(vec![crate::syntax::Arg { name: None, value: inner.clone(), span: inner.span.clone() }]), false, false)), span: crate::syntax::parser::to(&start, &inner.span) }, q.clone()))
                        })
                    }
                } else {
                    prism_rtl::Turn::Finished(lens_steps(&crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(name.clone())), span: name.span.clone() }, &p1))
                }
            },
            _ => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), crate::syntax::parser::fail(p_))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ParseReference, x`: what the function value is when passed to `@Run`.
pub fn start_parse_reference(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(ParseReference { p_ })
}

/// ```prism
/// LensSteps: unbounded fn Expr, Ps -> ((Expr, Ps))
/// ```
pub fn lens_steps(e0: &crate::syntax::Expr, p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let mut this: (crate::syntax::Expr, crate::syntax::parser::Ps) = (e0.clone(), p0.clone());
    let mut e: crate::syntax::Expr = e0.clone();
    let mut p_: crate::syntax::parser::Ps = p0.clone();
    let mut going: bool = true;
    while going && !p_.bad {
        match &crate::syntax::parser::kind(&p_) {
            crate::syntax::lexer::TokKind::KDot(false) => {
                let p1 = crate::syntax::parser::adv(&p_);
                let t = crate::syntax::parser::here(&p1);
                match &crate::syntax::parser::kind(&p1) {
                    crate::syntax::lexer::TokKind::KName(f) if ((&f.sigils == &Text::lit("")) && (&f.case == &crate::syntax::lexer::NameCase::CaseLower)) => {
                        e = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EField(Rc::new(e.clone()), Text::lit(""), crate::syntax::Ident { name: or(&index(&f.path_, &Nat::from(0u32)), &Text::lit("")), span: t.clone() })), span: crate::syntax::parser::to(&e.span, &t) };
                        p_ = crate::syntax::parser::adv(&p1);
                        ()
                    },
                    crate::syntax::lexer::TokKind::KKw(u8306_1_0, _) if (u8306_1_0 == &Text::lit("key")) => {
                        e = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EField(Rc::new(e.clone()), Text::lit(""), crate::syntax::Ident { name: Text::lit("key"), span: t.clone() })), span: crate::syntax::parser::to(&e.span, &t) };
                        p_ = crate::syntax::parser::adv(&p1);
                        ()
                    },
                    _ => {
                        p_ = crate::syntax::parser::fail(&p1);
                        ()
                    },
                    _ => unreachable!("no arm matched"),
                };
                ()
            },
            crate::syntax::lexer::TokKind::KOpen(u8187_1_0, false) if (u8187_1_0 == &Text::lit("[")) && crate::syntax::parser::tk(&p_).touches => {
                let (index, p1) = crate::syntax::parser::expr::parse_expr(&crate::syntax::parser::adv(&p_));
                let p2 = crate::syntax::parser::expect_close(&p1, &Text::lit("["));
                e = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EIndex(Rc::new(e.clone()), Rc::new(index.clone()))), span: crate::syntax::parser::to(&e.span, &crate::syntax::parser::prev(&p2)) };
                p_ = p2.clone();
                ()
            },
            _ => {
                going = false;
                ()
            },
            _ => unreachable!("no arm matched"),
        };
    }
    this = (e.clone(), p_.clone());
    this
}
