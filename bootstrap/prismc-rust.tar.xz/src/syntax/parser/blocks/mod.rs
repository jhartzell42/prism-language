//! The module `Syntax.Parser.Blocks`, from `target/bootstrap/src/prismc/syntax/parser/blocks.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// ParseBlockAfterColon: unbounded fn Ps -> ((Block, Ps))
/// ```
pub fn parse_block_after_colon_f(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Block, crate::syntax::parser::Ps) {
    let p_p1 = crate::syntax::parser::expect_colon_f(p0_p0);
    if crate::syntax::parser::at_open_l_f(&p_p1) {
        parse_indented_block_f(&p_p1)
    } else {
        if crate::syntax::parser::at_stmt_boundary_f(&p_p1) {
            (crate::syntax::parser::decls::no_block_p(), crate::syntax::parser::error_here_f(&p_p1, &crate::prelude::Text::lit("expected a statement after `:`")))
        } else {
            {
                let start_p2 = crate::syntax::parser::here_f(&p_p1);
                let (first_p4, p1_p5) = parse_stmt_f(&p_p1);
                let r_p3 = {
                    let mut this: (crate::prelude::Array<crate::syntax::Stmt>, crate::syntax::parser::Ps) = (crate::prelude::Array::from(vec![first_p4.clone()]), p1_p5.clone());
                    let mut stmts_p6: crate::prelude::Array<crate::syntax::Stmt> = crate::prelude::Array::from(vec![first_p4.clone()]);
                    let mut q_p7: crate::syntax::parser::Ps = p1_p5.clone();
                    while (&crate::syntax::parser::kind_f(&q_p7) == &crate::syntax::lexer::TokKind::KSemi) && !q_p7.bad_p {
                        let (st_p8, q2_p9) = parse_stmt_f(&crate::syntax::parser::adv_f(&q_p7));
                        stmts_p6 = crate::prelude::push(&stmts_p6, &st_p8);
                        q_p7 = q2_p9.clone();
                    }
                    this = (stmts_p6.clone(), q_p7.clone());
                    this
                };
                let (stmts_pa, q_pb) = r_p3.clone();
                (crate::syntax::Block { stmts_p: stmts_pa.clone(), inline_p: true, span_p: crate::syntax::parser::to_f(&start_p2, &crate::syntax::parser::prev_f(&q_pb)) }, q_pb.clone())
            }
        }
    }
}

/// The step machine of `ParseBlockAfterColon`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseBlockAfterColon: unbounded fn Ps -> ((Block, Ps))
/// ```
pub struct ParseBlockAfterColon {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::Block, crate::syntax::parser::Ps)> for ParseBlockAfterColon {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Block, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let p_p1 = crate::syntax::parser::expect_colon_f(p0_p0);
        if crate::syntax::parser::at_open_l_f(&p_p1) {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(ParseIndentedBlock { p0_p0: p_p1.clone() }))
        } else {
            if crate::syntax::parser::at_stmt_boundary_f(&p_p1) {
                ::prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_block_p(), crate::syntax::parser::error_here_f(&p_p1, &crate::prelude::Text::lit("expected a statement after `:`"))))
            } else {
                {
                    let start_p2 = crate::syntax::parser::here_f(&p_p1);
                    crate::prelude::call_then(start_parse_stmt_f(p_p1.clone()), move |parse_stmt_f_1224: (crate::syntax::Stmt, crate::syntax::parser::Ps)| {
                        let (first_p4, p1_p5) = parse_stmt_f_1224;
                        let mut this: (crate::prelude::Array<crate::syntax::Stmt>, crate::syntax::parser::Ps) = (crate::prelude::Array::from(vec![first_p4.clone()]), p1_p5.clone());
                        let mut stmts_p6: crate::prelude::Array<crate::syntax::Stmt> = crate::prelude::Array::from(vec![first_p4.clone()]);
                        let mut q_p7: crate::syntax::parser::Ps = p1_p5.clone();
                        let start_p2z = start_p2.clone();
                        crate::prelude::call_then(crate::prelude::loop_job((this, q_p7, stmts_p6), move |(mut this, mut q_p7, mut stmts_p6): ((crate::prelude::Array<crate::syntax::Stmt>, crate::syntax::parser::Ps), crate::syntax::parser::Ps, crate::prelude::Array<crate::syntax::Stmt>)| if (&crate::syntax::parser::kind_f(&q_p7) == &crate::syntax::lexer::TokKind::KSemi) && !q_p7.bad_p {
                            {
                                let (st_p8, q2_p9) = parse_stmt_f(&crate::syntax::parser::adv_f(&q_p7));
                                stmts_p6 = crate::prelude::push(&stmts_p6, &st_p8);
                                q_p7 = q2_p9.clone();
                                ::std::result::Result::Ok((this, q_p7, stmts_p6))
                            }
                        } else {
                            ::std::result::Result::Err((this, q_p7, stmts_p6))
                        }), move |(mut this, mut q_p7, mut stmts_p6): ((crate::prelude::Array<crate::syntax::Stmt>, crate::syntax::parser::Ps), crate::syntax::parser::Ps, crate::prelude::Array<crate::syntax::Stmt>)| {
                            this = (stmts_p6.clone(), q_p7.clone());
                            let r_p3 = this;
                            let (stmts_pa, q_pb) = r_p3.clone();
                            ::prism_rtl::Turn::Finished((crate::syntax::Block { stmts_p: stmts_pa.clone(), inline_p: true, span_p: crate::syntax::parser::to_f(&start_p2z, &crate::syntax::parser::prev_f(&q_pb)) }, q_pb.clone()))
                        })
                    })
                }
            }
        }
    }
}

/// `Start ParseBlockAfterColon, x`: what the function value is when passed to `@Run`.
pub fn start_parse_block_after_colon_f(p0_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Block, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseBlockAfterColon { p0_p0 })
}

/// ```prism
/// ParseIndentedBlock: unbounded fn Ps -> ((Block, Ps))
/// ```
pub fn parse_indented_block_f(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Block, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p0_p0);
    let (stmts_p2, q_p3) = stmts_until_f(&crate::syntax::parser::adv_f(p0_p0), &true);
    (crate::syntax::Block { stmts_p: stmts_p2.clone(), inline_p: false, span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&q_p3)) }, q_p3.clone())
}

/// The step machine of `ParseIndentedBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseIndentedBlock: unbounded fn Ps -> ((Block, Ps))
/// ```
pub struct ParseIndentedBlock {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::Block, crate::syntax::parser::Ps)> for ParseIndentedBlock {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Block, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let start_p1 = crate::syntax::parser::here_f(p0_p0);
        let p0_p0x = p0_p0.clone();
        crate::prelude::call_then(start_stmts_until_f(crate::syntax::parser::adv_f(&p0_p0x), true), move |stmts_until_f_1826: (crate::prelude::Array<crate::syntax::Stmt>, crate::syntax::parser::Ps)| {
            let (stmts_p2, q_p3) = stmts_until_f_1826;
            ::prism_rtl::Turn::Finished((crate::syntax::Block { stmts_p: stmts_p2.clone(), inline_p: false, span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&q_p3)) }, q_p3.clone()))
        })
    }
}

/// `Start ParseIndentedBlock, x`: what the function value is when passed to `@Run`.
pub fn start_parse_indented_block_f(p0_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Block, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseIndentedBlock { p0_p0 })
}

/// ```prism
/// ParseBlockUntilEof: unbounded fn Ps, Range -> ((Block, Ps))
/// ```
pub fn parse_block_until_eof_f(p_p0: &crate::syntax::parser::Ps, span_p1: &crate::syntax::Range) -> (crate::syntax::Block, crate::syntax::parser::Ps) {
    let (stmts_p2, q_p3) = if crate::syntax::parser::at_eof_f(p_p0) {
        (crate::prelude::Array::new(), p_p0.clone())
    } else {
        stmts_until_f(p_p0, &false)
    };
    (crate::syntax::Block { stmts_p: stmts_p2.clone(), inline_p: false, span_p: span_p1.clone() }, q_p3.clone())
}

/// The step machine of `ParseBlockUntilEof`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseBlockUntilEof: unbounded fn Ps, Range -> ((Block, Ps))
/// ```
pub struct ParseBlockUntilEof {
    pub p_p0: crate::syntax::parser::Ps,
    pub span_p1: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::syntax::Block, crate::syntax::parser::Ps)> for ParseBlockUntilEof {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Block, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let span_p1 = &self.span_p1;
        let span_p1z = span_p1.clone();
        let k_let2120 = move |v2120: (crate::prelude::Array<crate::syntax::Stmt>, crate::syntax::parser::Ps)| {
            let (stmts_p2, q_p3) = v2120;
            ::prism_rtl::Turn::Finished((crate::syntax::Block { stmts_p: stmts_p2.clone(), inline_p: false, span_p: span_p1z.clone() }, q_p3.clone()))
        };
        if crate::syntax::parser::at_eof_f(p_p0) {
            k_let2120((crate::prelude::Array::new(), p_p0.clone()))
        } else {
            {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(start_stmts_until_f(p_p0x.clone(), false), move |stmts_until_f_2169: (crate::prelude::Array<crate::syntax::Stmt>, crate::syntax::parser::Ps)| k_let2120(stmts_until_f_2169))
            }
        }
    }
}

/// `Start ParseBlockUntilEof, x`: what the function value is when passed to `@Run`.
pub fn start_parse_block_until_eof_f(p_p0: crate::syntax::parser::Ps, span_p1: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Block, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseBlockUntilEof { p_p0, span_p1 })
}

/// ```prism
/// StmtsUntil: unbounded fn Ps, Bool -> (([Stmt], Ps))
/// ```
pub fn stmts_until_f(p0_p0: &crate::syntax::parser::Ps, indented_p1: &bool) -> (crate::prelude::Array<crate::syntax::Stmt>, crate::syntax::parser::Ps) {
    let mut this: (crate::prelude::Array<crate::syntax::Stmt>, crate::syntax::parser::Ps) = (crate::prelude::Array::new(), p0_p0.clone());
    let mut stmts_p2: crate::prelude::Array<crate::syntax::Stmt> = crate::prelude::Array::new();
    let mut p_p3: crate::syntax::parser::Ps = p0_p0.clone();
    let mut going_p4: bool = true;
    while going_p4 {
        let (st_p5, q_p6) = parse_stmt_f(&p_p3);
        if !q_p6.bad_p {
            stmts_p2 = crate::prelude::push(&stmts_p2, &st_p5);
        }
        p_p3 = crate::syntax::parser::recovered_f(&q_p6);
        match &crate::syntax::parser::kind_f(&p_p3) {
            crate::syntax::lexer::TokKind::KLaySep => {
                p_p3 = crate::syntax::parser::adv_f(&p_p3);
                if !*indented_p1 && crate::syntax::parser::at_eof_f(&p_p3) {
                    going_p4 = false;
                }
            }
            crate::syntax::lexer::TokKind::KLayClose => {
                p_p3 = crate::syntax::parser::adv_f(&p_p3);
                if *indented_p1 || crate::syntax::parser::at_eof_f(&p_p3) {
                    going_p4 = false;
                }
            }
            crate::syntax::lexer::TokKind::KEof => {
                going_p4 = false;
            }
            _ => {
                p_p3 = crate::syntax::parser::recover_f(&crate::syntax::parser::complain_f(&p_p3, &crate::prelude::Text::lit("expected the end of the statement")));
            }
        }
    }
    this = (stmts_p2.clone(), p_p3.clone());
    this
}

/// The step machine of `StmtsUntil`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtsUntil: unbounded fn Ps, Bool -> (([Stmt], Ps))
/// ```
pub struct StmtsUntil {
    pub p0_p0: crate::syntax::parser::Ps,
    pub indented_p1: bool,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::Stmt>, crate::syntax::parser::Ps)> for StmtsUntil {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::syntax::Stmt>, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let indented_p1 = &self.indented_p1;
        let mut this: (crate::prelude::Array<crate::syntax::Stmt>, crate::syntax::parser::Ps) = (crate::prelude::Array::new(), p0_p0.clone());
        let mut stmts_p2: crate::prelude::Array<crate::syntax::Stmt> = crate::prelude::Array::new();
        let mut p_p3: crate::syntax::parser::Ps = p0_p0.clone();
        let mut going_p4: bool = true;
        crate::prelude::call_then(crate::prelude::loop_job((this, going_p4, p_p3, stmts_p2), {
            let indented_p1x = *indented_p1;
            move |(mut this, mut going_p4, mut p_p3, mut stmts_p2): ((crate::prelude::Array<crate::syntax::Stmt>, crate::syntax::parser::Ps), bool, crate::syntax::parser::Ps, crate::prelude::Array<crate::syntax::Stmt>)| if going_p4 {
                {
                    let (st_p5, q_p6) = parse_stmt_f(&p_p3);
                    if !q_p6.bad_p {
                        stmts_p2 = crate::prelude::push(&stmts_p2, &st_p5);
                    }
                    p_p3 = crate::syntax::parser::recovered_f(&q_p6);
                    match &crate::syntax::parser::kind_f(&p_p3) {
                        crate::syntax::lexer::TokKind::KLaySep => {
                            p_p3 = crate::syntax::parser::adv_f(&p_p3);
                            if !indented_p1x && crate::syntax::parser::at_eof_f(&p_p3) {
                                going_p4 = false;
                            }
                        }
                        crate::syntax::lexer::TokKind::KLayClose => {
                            p_p3 = crate::syntax::parser::adv_f(&p_p3);
                            if indented_p1x || crate::syntax::parser::at_eof_f(&p_p3) {
                                going_p4 = false;
                            }
                        }
                        crate::syntax::lexer::TokKind::KEof => {
                            going_p4 = false;
                        }
                        _ => {
                            p_p3 = crate::syntax::parser::recover_f(&crate::syntax::parser::complain_f(&p_p3, &crate::prelude::Text::lit("expected the end of the statement")));
                        }
                    }
                    ::std::result::Result::Ok((this, going_p4, p_p3, stmts_p2))
                }
            } else {
                ::std::result::Result::Err((this, going_p4, p_p3, stmts_p2))
            }
        }), move |(mut this, mut going_p4, mut p_p3, mut stmts_p2): ((crate::prelude::Array<crate::syntax::Stmt>, crate::syntax::parser::Ps), bool, crate::syntax::parser::Ps, crate::prelude::Array<crate::syntax::Stmt>)| {
            this = (stmts_p2.clone(), p_p3.clone());
            ::prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start StmtsUntil, x`: what the function value is when passed to `@Run`.
pub fn start_stmts_until_f(p0_p0: crate::syntax::parser::Ps, indented_p1: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::Stmt>, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(StmtsUntil { p0_p0, indented_p1 })
}

/// ```prism
/// ParseStmt: unbounded fn Ps -> ((Stmt, Ps))
/// ```
pub fn parse_stmt_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Stmt, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p_p0);
    let (kind_p2, q_p3) = stmt_kind_of_f(p_p0, &start_p1);
    (crate::syntax::Stmt { kind_p: kind_p2.clone(), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&q_p3)) }, q_p3.clone())
}

/// The step machine of `ParseStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseStmt: unbounded fn Ps -> ((Stmt, Ps))
/// ```
pub struct ParseStmt {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::Stmt, crate::syntax::parser::Ps)> for ParseStmt {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Stmt, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here_f(p_p0);
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(start_stmt_kind_of_f(p_p0x.clone(), start_p1.clone()), move |stmt_kind_of_f_3254: (crate::syntax::StmtKind, crate::syntax::parser::Ps)| {
            let (kind_p2, q_p3) = stmt_kind_of_f_3254;
            ::prism_rtl::Turn::Finished((crate::syntax::Stmt { kind_p: kind_p2.clone(), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&q_p3)) }, q_p3.clone()))
        })
    }
}

/// `Start ParseStmt, x`: what the function value is when passed to `@Run`.
pub fn start_parse_stmt_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Stmt, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseStmt { p_p0 })
}

/// ```prism
/// StmtKindOf: unbounded fn Ps, Range -> ((StmtKind, Ps))
/// ```
pub fn stmt_kind_of_f(p_p0: &crate::syntax::parser::Ps, start_p1: &crate::syntax::Range) -> (crate::syntax::StmtKind, crate::syntax::parser::Ps) {
    match crate::syntax::parser::kind_f(p_p0) {
        crate::syntax::lexer::TokKind::KKw(m3409_0_0, m3409_0_1) if (&m3409_0_0 == &crate::prelude::Text::lit("emit")) && (&m3409_0_1 == &crate::prelude::Text::lit("")) => {
            let (r_p2, q_p3) = crate::syntax::parser::types::parse_row_f(&crate::syntax::parser::adv_f(p_p0));
            (crate::syntax::StmtKind::SEmit(r_p2.clone()), q_p3.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m3409_1_0, m3409_1_1) if (&m3409_1_0 == &crate::prelude::Text::lit("let")) && (&m3409_1_1 == &crate::prelude::Text::lit("")) => {
            let (pattern_p4, p1_p5) = crate::syntax::parser::types::parse_pattern_f(&crate::syntax::parser::adv_f(p_p0), &false);
            let (ty_o6, p2_p7) = crate::syntax::parser::decls::optional_annotation_f(&p1_p5);
            let (value_p8, p3_p9) = crate::syntax::parser::expr::parse_rhs_expr_f(&crate::syntax::parser::expect_op_f(&p2_p7, &crate::prelude::Text::lit("=")));
            (crate::syntax::StmtKind::SLet(pattern_p4.clone(), ty_o6.clone(), value_p8.clone()), p3_p9.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m3409_2_0, m3409_2_1) if (&m3409_2_0 == &crate::prelude::Text::lit("fn")) && (&m3409_2_1 == &crate::prelude::Text::lit("")) => {
            let (f_pa, q_pb) = crate::syntax::parser::decls::parse_fn_clause_f(p_p0);
            (crate::syntax::StmtKind::SFn(f_pa.clone()), q_pb.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m3409_3_0, m3409_3_1) if (&m3409_3_0 == &crate::prelude::Text::lit("ignore")) && (&m3409_3_1 == &crate::prelude::Text::lit("")) && crate::syntax::parser::at_op_f(&crate::syntax::parser::adv_f(p_p0), &crate::prelude::Text::lit("<-")) => {
            let (e_pc, q_pd) = crate::syntax::parser::expr::parse_rhs_expr_f(&crate::syntax::parser::adv_f(&crate::syntax::parser::adv_f(p_p0)));
            (crate::syntax::StmtKind::SIgnore(e_pc.clone()), q_pd.clone())
        },
        crate::syntax::lexer::TokKind::KKw(w_pe, m3409_4_1) if (&m3409_4_1 == &crate::prelude::Text::lit("")) && ((&w_pe == &crate::prelude::Text::lit("require")) || (&w_pe == &crate::prelude::Text::lit("forbid"))) => {
            let (c_pg, p1_ph) = crate::syntax::parser::expr::parse_rhs_expr_f(&crate::syntax::parser::adv_f(p_p0));
            let q_pf = if crate::syntax::parser::at_comma_f(&p1_ph) {
                crate::syntax::parser::error_at_f(&p1_ph, &crate::syntax::parser::here_f(&p1_ph), &crate::prelude::Text::from(format!("`{}` takes its condition alone, with no error value after a comma (decisions.md D15): a failed guard under `~` raises `Prelude.Unmet` (D11), and a comma after a guard belongs to a call at the head of its condition, as in `require Clear g, from, corner`", &w_pe)))
            } else {
                p1_ph.clone()
            };
            if &w_pe == &crate::prelude::Text::lit("require") {
                (crate::syntax::StmtKind::SRequire(c_pg.clone()), q_pf.clone())
            } else {
                (crate::syntax::StmtKind::SForbid(c_pg.clone()), q_pf.clone())
            }
        },
        crate::syntax::lexer::TokKind::KKw(m3409_5_0, m3409_5_1) if (&m3409_5_0 == &crate::prelude::Text::lit("while")) && (&m3409_5_1 == &crate::prelude::Text::lit("")) => {
            let (cond_pi, p1_pj) = crate::syntax::parser::expr::parse_cond_f(&crate::syntax::parser::adv_f(p_p0), &true);
            let (body_pk, q_pl) = parse_block_after_colon_f(&p1_pj);
            (crate::syntax::StmtKind::SWhile(cond_pi.clone(), body_pk.clone()), q_pl.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m3409_6_0, m3409_6_1) if (&m3409_6_0 == &crate::prelude::Text::lit("return")) && (&m3409_6_1 == &crate::prelude::Text::lit("")) => {
            let p1_pm = crate::syntax::parser::out_of_scope_f(&crate::syntax::parser::adv_f(p_p0), &crate::syntax::parser::here_f(p_p0), &crate::prelude::Text::lit("`T monad:` blocks and `^Monad`"), &crate::prelude::Text::lit("`return` ends a monad block, which is out of this compiler"));
            let (e_pn, q_po) = crate::syntax::parser::expr::parse_rhs_expr_f(&p1_pm);
            (crate::syntax::StmtKind::SReturn(e_pn.clone()), q_po.clone())
        },
        crate::syntax::lexer::TokKind::KName(_) if (&crate::syntax::parser::kind_at_f(p_p0, &crate::prelude::Nat::from(1u32)) == &crate::syntax::lexer::TokKind::KColon) => if &crate::syntax::parser::kind_at_f(p_p0, &crate::prelude::Nat::from(2u32)) == &crate::syntax::lexer::TokKind::KLayOpen {
            {
                let (name_pp, p1_pq) = crate::syntax::parser::parse_sname_f(p_p0);
                let (body_pr, q_ps) = parse_block_after_colon_f(&p1_pq);
                (crate::syntax::StmtKind::SWidget(crate::syntax::decls::WidgetDecl { name_p: name_pp.clone(), body_p: body_pr.clone(), span_p: crate::syntax::parser::to_f(start_p1, &body_pr.span_p) }), q_ps.clone())
            }
        } else {
            {
                let (sig_pt, q_pu) = crate::syntax::parser::decls::parse_signature_f(p_p0);
                (crate::syntax::StmtKind::SSignature(sig_pt.clone()), q_pu.clone())
            }
        },
        _ => other_stmt_f(p_p0),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `StmtKindOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtKindOf: unbounded fn Ps, Range -> ((StmtKind, Ps))
/// ```
pub struct StmtKindOf {
    pub p_p0: crate::syntax::parser::Ps,
    pub start_p1: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::syntax::StmtKind, crate::syntax::parser::Ps)> for StmtKindOf {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::StmtKind, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = &self.start_p1;
        match crate::syntax::parser::kind_f(p_p0) {
            crate::syntax::lexer::TokKind::KKw(m3409_0_0, m3409_0_1) if (&m3409_0_0 == &crate::prelude::Text::lit("emit")) && (&m3409_0_1 == &crate::prelude::Text::lit("")) => {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(crate::syntax::parser::types::start_parse_row_f(crate::syntax::parser::adv_f(&p_p0x)), move |parse_row_f_3466: (crate::syntax::Row, crate::syntax::parser::Ps)| {
                    let (r_p2, q_p3) = parse_row_f_3466;
                    ::prism_rtl::Turn::Finished((crate::syntax::StmtKind::SEmit(r_p2.clone()), q_p3.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m3409_1_0, m3409_1_1) if (&m3409_1_0 == &crate::prelude::Text::lit("let")) && (&m3409_1_1 == &crate::prelude::Text::lit("")) => {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(crate::syntax::parser::types::start_parse_pattern_f(crate::syntax::parser::adv_f(&p_p0x), false), move |parse_pattern_f_3555: (crate::syntax::Pattern, crate::syntax::parser::Ps)| {
                    let (pattern_p4, p1_p5) = parse_pattern_f_3555;
                    crate::prelude::call_then(crate::syntax::parser::decls::start_optional_annotation_f(p1_p5.clone()), move |optional_annotation_f_3609: (::std::option::Option<crate::syntax::Type>, crate::syntax::parser::Ps)| {
                        let (ty_o6, p2_p7) = optional_annotation_f_3609;
                        crate::prelude::call_then(crate::syntax::parser::expr::start_parse_rhs_expr_f(crate::syntax::parser::expect_op_f(&p2_p7, &crate::prelude::Text::lit("="))), move |parse_rhs_expr_f_3659: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                            let (value_p8, p3_p9) = parse_rhs_expr_f_3659;
                            ::prism_rtl::Turn::Finished((crate::syntax::StmtKind::SLet(pattern_p4.clone(), ty_o6.clone(), value_p8.clone()), p3_p9.clone()))
                        })
                    })
                })
            },
            crate::syntax::lexer::TokKind::KKw(m3409_2_0, m3409_2_1) if (&m3409_2_0 == &crate::prelude::Text::lit("fn")) && (&m3409_2_1 == &crate::prelude::Text::lit("")) => {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(crate::syntax::parser::decls::start_parse_fn_clause_f(p_p0x.clone()), move |parse_fn_clause_f_3775: (crate::syntax::decls::FnClause, crate::syntax::parser::Ps)| {
                    let (f_pa, q_pb) = parse_fn_clause_f_3775;
                    ::prism_rtl::Turn::Finished((crate::syntax::StmtKind::SFn(f_pa.clone()), q_pb.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m3409_3_0, m3409_3_1) if (&m3409_3_0 == &crate::prelude::Text::lit("ignore")) && (&m3409_3_1 == &crate::prelude::Text::lit("")) && crate::syntax::parser::at_op_f(&crate::syntax::parser::adv_f(p_p0), &crate::prelude::Text::lit("<-")) => {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(crate::syntax::parser::expr::start_parse_rhs_expr_f(crate::syntax::parser::adv_f(&crate::syntax::parser::adv_f(&p_p0x))), move |parse_rhs_expr_f_3881: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (e_pc, q_pd) = parse_rhs_expr_f_3881;
                    ::prism_rtl::Turn::Finished((crate::syntax::StmtKind::SIgnore(e_pc.clone()), q_pd.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(w_pe, m3409_4_1) if (&m3409_4_1 == &crate::prelude::Text::lit("")) && ((&w_pe == &crate::prelude::Text::lit("require")) || (&w_pe == &crate::prelude::Text::lit("forbid"))) => {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(crate::syntax::parser::expr::start_parse_rhs_expr_f(crate::syntax::parser::adv_f(&p_p0x)), move |parse_rhs_expr_f_4174: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (c_pg, p1_ph) = parse_rhs_expr_f_4174;
                    let q_pf = if crate::syntax::parser::at_comma_f(&p1_ph) {
                        crate::syntax::parser::error_at_f(&p1_ph, &crate::syntax::parser::here_f(&p1_ph), &crate::prelude::Text::from(format!("`{}` takes its condition alone, with no error value after a comma (decisions.md D15): a failed guard under `~` raises `Prelude.Unmet` (D11), and a comma after a guard belongs to a call at the head of its condition, as in `require Clear g, from, corner`", &w_pe)))
                    } else {
                        p1_ph.clone()
                    };
                    if &w_pe == &crate::prelude::Text::lit("require") {
                        ::prism_rtl::Turn::Finished((crate::syntax::StmtKind::SRequire(c_pg.clone()), q_pf.clone()))
                    } else {
                        ::prism_rtl::Turn::Finished((crate::syntax::StmtKind::SForbid(c_pg.clone()), q_pf.clone()))
                    }
                })
            },
            crate::syntax::lexer::TokKind::KKw(m3409_5_0, m3409_5_1) if (&m3409_5_0 == &crate::prelude::Text::lit("while")) && (&m3409_5_1 == &crate::prelude::Text::lit("")) => {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(crate::syntax::parser::expr::start_parse_cond_f(crate::syntax::parser::adv_f(&p_p0x), true), move |parse_cond_f_4630: (crate::syntax::Cond, crate::syntax::parser::Ps)| {
                    let (cond_pi, p1_pj) = parse_cond_f_4630;
                    crate::prelude::call_then(start_parse_block_after_colon_f(p1_pj.clone()), move |parse_block_after_colon_f_4680: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                        let (body_pk, q_pl) = parse_block_after_colon_f_4680;
                        ::prism_rtl::Turn::Finished((crate::syntax::StmtKind::SWhile(cond_pi.clone(), body_pk.clone()), q_pl.clone()))
                    })
                })
            },
            crate::syntax::lexer::TokKind::KKw(m3409_6_0, m3409_6_1) if (&m3409_6_0 == &crate::prelude::Text::lit("return")) && (&m3409_6_1 == &crate::prelude::Text::lit("")) => {
                let p1_pm = crate::syntax::parser::out_of_scope_f(&crate::syntax::parser::adv_f(p_p0), &crate::syntax::parser::here_f(p_p0), &crate::prelude::Text::lit("`T monad:` blocks and `^Monad`"), &crate::prelude::Text::lit("`return` ends a monad block, which is out of this compiler"));
                crate::prelude::call_then(crate::syntax::parser::expr::start_parse_rhs_expr_f(p1_pm.clone()), move |parse_rhs_expr_f_4926: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (e_pn, q_po) = parse_rhs_expr_f_4926;
                    ::prism_rtl::Turn::Finished((crate::syntax::StmtKind::SReturn(e_pn.clone()), q_po.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KName(_) if (&crate::syntax::parser::kind_at_f(p_p0, &crate::prelude::Nat::from(1u32)) == &crate::syntax::lexer::TokKind::KColon) => if &crate::syntax::parser::kind_at_f(p_p0, &crate::prelude::Nat::from(2u32)) == &crate::syntax::lexer::TokKind::KLayOpen {
                {
                    let (name_pp, p1_pq) = crate::syntax::parser::parse_sname_f(p_p0);
                    let start_p1x = start_p1.clone();
                    crate::prelude::call_then(start_parse_block_after_colon_f(p1_pq.clone()), move |parse_block_after_colon_f_5173: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                        let (body_pr, q_ps) = parse_block_after_colon_f_5173;
                        ::prism_rtl::Turn::Finished((crate::syntax::StmtKind::SWidget(crate::syntax::decls::WidgetDecl { name_p: name_pp.clone(), body_p: body_pr.clone(), span_p: crate::syntax::parser::to_f(&start_p1x, &body_pr.span_p) }), q_ps.clone()))
                    })
                }
            } else {
                {
                    let p_p0x = p_p0.clone();
                    crate::prelude::call_then(crate::syntax::parser::decls::start_parse_signature_f(p_p0x.clone()), move |parse_signature_f_5328: (crate::syntax::decls::Signature, crate::syntax::parser::Ps)| {
                        let (sig_pt, q_pu) = parse_signature_f_5328;
                        ::prism_rtl::Turn::Finished((crate::syntax::StmtKind::SSignature(sig_pt.clone()), q_pu.clone()))
                    })
                }
            },
            _ => ::prism_rtl::Turn::More(::std::rc::Rc::new(OtherStmt { p_p0: p_p0.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start StmtKindOf, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_kind_of_f(p_p0: crate::syntax::parser::Ps, start_p1: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::StmtKind, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(StmtKindOf { p_p0, start_p1 })
}

/// ```prism
/// OtherStmt: unbounded fn Ps -> ((StmtKind, Ps))
/// ```
pub fn other_stmt_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::StmtKind, crate::syntax::parser::Ps) {
    let (upd_p1, u_p2) = parse_update_stmt_f(p_p0);
    let (pattern_p3, b_p4) = crate::syntax::parser::types::parse_pattern_f(p_p0, &true);
    if !u_p2.bad_p {
        (upd_p1.clone(), u_p2.clone())
    } else {
        if !b_p4.bad_p && crate::syntax::parser::at_op_f(&b_p4, &crate::prelude::Text::lit("<-")) {
            {
                let (value_p5, p1_p6) = crate::syntax::parser::expr::parse_rhs_expr_f(&crate::syntax::parser::adv_f(&b_p4));
                let (then_step_o7, p2_p8) = if crate::syntax::parser::at_kw_f(&p1_p6, &crate::prelude::Text::lit("then")) {
                    optional_rhs_f(&crate::syntax::parser::adv_f(&p1_p6))
                } else {
                    (::std::option::Option::None, p1_p6.clone())
                };
                if crate::syntax::parser::at_kw_f(&p2_p8, &crate::prelude::Text::lit("then")) {
                    (crate::syntax::StmtKind::SExpr(crate::syntax::parser::decls::no_expr_p()), crate::syntax::parser::error_at_f(&p2_p8, &crate::syntax::parser::here_f(&p2_p8), &crate::prelude::Text::lit("`then` does not associate: a hold has one start and one step")))
                } else {
                    (crate::syntax::StmtKind::SBind(pattern_p3.clone(), value_p5.clone(), then_step_o7.clone()), p2_p8.clone())
                }
            }
        } else {
            {
                let (e_p9, p1_pa) = crate::syntax::parser::expr::parse_rhs_expr_f(p_p0);
                if crate::syntax::parser::at_op_f(&p1_pa, &crate::prelude::Text::lit("<-")) {
                    (crate::syntax::StmtKind::SExpr(e_p9.clone()), crate::syntax::parser::error_at_f(&p1_pa, &crate::syntax::parser::here_f(&p1_pa), &crate::prelude::Text::lit("the left side of `<-` is not a pattern")))
                } else {
                    if crate::syntax::parser::at_kw_f(&p1_pa, &crate::prelude::Text::lit("then")) {
                        (crate::syntax::StmtKind::SExpr(e_p9.clone()), crate::syntax::parser::error_at_f(&p1_pa, &crate::syntax::parser::here_f(&p1_pa), &crate::prelude::Text::lit("`then` belongs to a hold: `$x <- start then step`")))
                    } else {
                        (crate::syntax::StmtKind::SExpr(e_p9.clone()), p1_pa.clone())
                    }
                }
            }
        }
    }
}

/// The step machine of `OtherStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OtherStmt: unbounded fn Ps -> ((StmtKind, Ps))
/// ```
pub struct OtherStmt {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::StmtKind, crate::syntax::parser::Ps)> for OtherStmt {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::StmtKind, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(start_parse_update_stmt_f(p_p0x.clone()), move |parse_update_stmt_f_5569: (crate::syntax::StmtKind, crate::syntax::parser::Ps)| {
            let (upd_p1, u_p2) = parse_update_stmt_f_5569;
            crate::prelude::call_then(crate::syntax::parser::types::start_parse_pattern_f(p_p0x.clone(), true), move |parse_pattern_f_5612: (crate::syntax::Pattern, crate::syntax::parser::Ps)| {
                let (pattern_p3, b_p4) = parse_pattern_f_5612;
                if !u_p2.bad_p {
                    ::prism_rtl::Turn::Finished((upd_p1.clone(), u_p2.clone()))
                } else {
                    if !b_p4.bad_p && crate::syntax::parser::at_op_f(&b_p4, &crate::prelude::Text::lit("<-")) {
                        crate::prelude::call_then(crate::syntax::parser::expr::start_parse_rhs_expr_f(crate::syntax::parser::adv_f(&b_p4)), move |parse_rhs_expr_f_5733: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                            let (value_p5, p1_p6) = parse_rhs_expr_f_5733;
                            let pattern_p3z = pattern_p3.clone();
                            let value_p5z = value_p5.clone();
                            let k_let5762 = move |v5762: (::std::option::Option<crate::syntax::Expr>, crate::syntax::parser::Ps)| {
                                let (then_step_o7, p2_p8) = v5762;
                                if crate::syntax::parser::at_kw_f(&p2_p8, &crate::prelude::Text::lit("then")) {
                                    ::prism_rtl::Turn::Finished((crate::syntax::StmtKind::SExpr(crate::syntax::parser::decls::no_expr_p()), crate::syntax::parser::error_at_f(&p2_p8, &crate::syntax::parser::here_f(&p2_p8), &crate::prelude::Text::lit("`then` does not associate: a hold has one start and one step"))))
                                } else {
                                    ::prism_rtl::Turn::Finished((crate::syntax::StmtKind::SBind(pattern_p3z.clone(), value_p5z.clone(), then_step_o7.clone()), p2_p8.clone()))
                                }
                            };
                            if crate::syntax::parser::at_kw_f(&p1_p6, &crate::prelude::Text::lit("then")) {
                                crate::prelude::call_then(start_optional_rhs_f(crate::syntax::parser::adv_f(&p1_p6)), move |optional_rhs_f_5806: (::std::option::Option<crate::syntax::Expr>, crate::syntax::parser::Ps)| k_let5762(optional_rhs_f_5806))
                            } else {
                                k_let5762((::std::option::Option::None, p1_p6.clone()))
                            }
                        })
                    } else {
                        crate::prelude::call_then(crate::syntax::parser::expr::start_parse_rhs_expr_f(p_p0x.clone()), move |parse_rhs_expr_f_6069: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                            let (e_p9, p1_pa) = parse_rhs_expr_f_6069;
                            if crate::syntax::parser::at_op_f(&p1_pa, &crate::prelude::Text::lit("<-")) {
                                ::prism_rtl::Turn::Finished((crate::syntax::StmtKind::SExpr(e_p9.clone()), crate::syntax::parser::error_at_f(&p1_pa, &crate::syntax::parser::here_f(&p1_pa), &crate::prelude::Text::lit("the left side of `<-` is not a pattern"))))
                            } else {
                                if crate::syntax::parser::at_kw_f(&p1_pa, &crate::prelude::Text::lit("then")) {
                                    ::prism_rtl::Turn::Finished((crate::syntax::StmtKind::SExpr(e_p9.clone()), crate::syntax::parser::error_at_f(&p1_pa, &crate::syntax::parser::here_f(&p1_pa), &crate::prelude::Text::lit("`then` belongs to a hold: `$x <- start then step`"))))
                                } else {
                                    ::prism_rtl::Turn::Finished((crate::syntax::StmtKind::SExpr(e_p9.clone()), p1_pa.clone()))
                                }
                            }
                        })
                    }
                }
            })
        })
    }
}

/// `Start OtherStmt, x`: what the function value is when passed to `@Run`.
pub fn start_other_stmt_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::StmtKind, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(OtherStmt { p_p0 })
}

/// ```prism
/// OptionalRhs: unbounded fn Ps -> ((?Expr, Ps))
/// ```
pub fn optional_rhs_f(p_p0: &crate::syntax::parser::Ps) -> (::std::option::Option<crate::syntax::Expr>, crate::syntax::parser::Ps) {
    let (e_p1, q_p2) = crate::syntax::parser::expr::parse_rhs_expr_f(p_p0);
    (::std::option::Option::Some(e_p1.clone()), q_p2.clone())
}

/// The step machine of `OptionalRhs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptionalRhs: unbounded fn Ps -> ((?Expr, Ps))
/// ```
pub struct OptionalRhs {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(::std::option::Option<crate::syntax::Expr>, crate::syntax::parser::Ps)> for OptionalRhs {
    fn cycle(&self) -> ::prism_rtl::Turn<(::std::option::Option<crate::syntax::Expr>, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(crate::syntax::parser::expr::start_parse_rhs_expr_f(p_p0x.clone()), move |parse_rhs_expr_f_6427: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
            let (e_p1, q_p2) = parse_rhs_expr_f_6427;
            ::prism_rtl::Turn::Finished((::std::option::Option::Some(e_p1.clone()), q_p2.clone()))
        })
    }
}

/// `Start OptionalRhs, x`: what the function value is when passed to `@Run`.
pub fn start_optional_rhs_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(::std::option::Option<crate::syntax::Expr>, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(OptionalRhs { p_p0 })
}

/// ```prism
/// ParseUpdateStmt: unbounded fn Ps -> ((StmtKind, Ps))
/// ```
pub fn parse_update_stmt_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::StmtKind, crate::syntax::parser::Ps) {
    let (target_p2, p1_p3) = parse_reference_f(p_p0);
    let op_p1 = match crate::syntax::parser::kind_f(&p1_p3) {
        crate::syntax::lexer::TokKind::KOp(o_p4, _) => o_p4,
        _ => crate::prelude::Text::lit(""),
    };
    if p1_p3.bad_p || !(((((&op_p1 == &crate::prelude::Text::lit("<=")) || (&op_p1 == &crate::prelude::Text::lit("+="))) || (&op_p1 == &crate::prelude::Text::lit("-="))) || (&op_p1 == &crate::prelude::Text::lit("*="))) || (&op_p1 == &crate::prelude::Text::lit("/="))) {
        (crate::syntax::StmtKind::SExpr(crate::syntax::parser::decls::no_expr_p()), crate::syntax::parser::fail_f(&p1_p3))
    } else {
        {
            let (value_p5, q_p6) = crate::syntax::parser::expr::parse_rhs_expr_f(&crate::syntax::parser::adv_f(&p1_p3));
            if &op_p1 == &crate::prelude::Text::lit("<=") {
                (crate::syntax::StmtKind::SSet(target_p2.clone(), value_p5.clone()), q_p6.clone())
            } else {
                (crate::syntax::StmtKind::SAccum(target_p2.clone(), op_p1.clone(), value_p5.clone()), q_p6.clone())
            }
        }
    }
}

/// The step machine of `ParseUpdateStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseUpdateStmt: unbounded fn Ps -> ((StmtKind, Ps))
/// ```
pub struct ParseUpdateStmt {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::StmtKind, crate::syntax::parser::Ps)> for ParseUpdateStmt {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::StmtKind, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(start_parse_reference_f(p_p0x.clone()), move |parse_reference_f_6741: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
            let (target_p2, p1_p3) = parse_reference_f_6741;
            let op_p1 = match crate::syntax::parser::kind_f(&p1_p3) {
                crate::syntax::lexer::TokKind::KOp(o_p4, _) => o_p4,
                _ => crate::prelude::Text::lit(""),
            };
            if p1_p3.bad_p || !(((((&op_p1 == &crate::prelude::Text::lit("<=")) || (&op_p1 == &crate::prelude::Text::lit("+="))) || (&op_p1 == &crate::prelude::Text::lit("-="))) || (&op_p1 == &crate::prelude::Text::lit("*="))) || (&op_p1 == &crate::prelude::Text::lit("/="))) {
                ::prism_rtl::Turn::Finished((crate::syntax::StmtKind::SExpr(crate::syntax::parser::decls::no_expr_p()), crate::syntax::parser::fail_f(&p1_p3)))
            } else {
                crate::prelude::call_then(crate::syntax::parser::expr::start_parse_rhs_expr_f(crate::syntax::parser::adv_f(&p1_p3)), move |parse_rhs_expr_f_6989: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (value_p5, q_p6) = parse_rhs_expr_f_6989;
                    if &op_p1 == &crate::prelude::Text::lit("<=") {
                        ::prism_rtl::Turn::Finished((crate::syntax::StmtKind::SSet(target_p2.clone(), value_p5.clone()), q_p6.clone()))
                    } else {
                        ::prism_rtl::Turn::Finished((crate::syntax::StmtKind::SAccum(target_p2.clone(), op_p1.clone(), value_p5.clone()), q_p6.clone()))
                    }
                })
            }
        })
    }
}

/// `Start ParseUpdateStmt, x`: what the function value is when passed to `@Run`.
pub fn start_parse_update_stmt_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::StmtKind, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseUpdateStmt { p_p0 })
}

/// ```prism
/// ParseReference: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_reference_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    match crate::syntax::parser::kind_f(p_p0) {
        crate::syntax::lexer::TokKind::KName(n_p1) if crate::syntax::lexer::chars::has_prefix_f(&n_p1.sigils_p, &crate::prelude::Text::lit("&")) => {
            let start_p2 = crate::syntax::parser::here_f(p_p0);
            let (name_p3, p1_p4) = crate::syntax::parser::parse_sname_f(p_p0);
            if crate::syntax::parser::is_upper_name_f(&name_p3) {
                {
                    let (inner_p6, q_p7) = parse_reference_f(&p1_p4);
                    let callee_p5 = crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EName(name_p3.clone())), span_p: start_p2.clone() };
                    (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ECall(::std::rc::Rc::new(callee_p5.clone()), crate::prelude::Array::from(vec![crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: inner_p6.clone(), span_p: inner_p6.span_p.clone() }]), false, false)), span_p: crate::syntax::parser::to_f(&start_p2, &inner_p6.span_p) }, q_p7.clone())
                }
            } else {
                lens_steps_f(&crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EName(name_p3.clone())), span_p: name_p3.span_p.clone() }, &p1_p4)
            }
        },
        _ => (crate::syntax::parser::decls::no_expr_p(), crate::syntax::parser::fail_f(p_p0)),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ParseReference`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseReference: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseReference {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseReference {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        match crate::syntax::parser::kind_f(p_p0) {
            crate::syntax::lexer::TokKind::KName(n_p1) if crate::syntax::lexer::chars::has_prefix_f(&n_p1.sigils_p, &crate::prelude::Text::lit("&")) => {
                let start_p2 = crate::syntax::parser::here_f(p_p0);
                let (name_p3, p1_p4) = crate::syntax::parser::parse_sname_f(p_p0);
                if crate::syntax::parser::is_upper_name_f(&name_p3) {
                    crate::prelude::call_then(start_parse_reference_f(p1_p4.clone()), move |parse_reference_f_7509: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                        let (inner_p6, q_p7) = parse_reference_f_7509;
                        let callee_p5 = crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EName(name_p3.clone())), span_p: start_p2.clone() };
                        ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ECall(::std::rc::Rc::new(callee_p5.clone()), crate::prelude::Array::from(vec![crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: inner_p6.clone(), span_p: inner_p6.span_p.clone() }]), false, false)), span_p: crate::syntax::parser::to_f(&start_p2, &inner_p6.span_p) }, q_p7.clone()))
                    })
                } else {
                    ::prism_rtl::Turn::Finished(lens_steps_f(&crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EName(name_p3.clone())), span_p: name_p3.span_p.clone() }, &p1_p4))
                }
            },
            _ => ::prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr_p(), crate::syntax::parser::fail_f(p_p0))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ParseReference, x`: what the function value is when passed to `@Run`.
pub fn start_parse_reference_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseReference { p_p0 })
}

/// ```prism
/// LensSteps: unbounded fn Expr, Ps -> ((Expr, Ps))
/// ```
pub fn lens_steps_f(e0_p0: &crate::syntax::Expr, p0_p1: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let mut this: (crate::syntax::Expr, crate::syntax::parser::Ps) = (e0_p0.clone(), p0_p1.clone());
    let mut e_p2: crate::syntax::Expr = e0_p0.clone();
    let mut p_p3: crate::syntax::parser::Ps = p0_p1.clone();
    let mut going_p4: bool = true;
    while going_p4 && !p_p3.bad_p {
        match &crate::syntax::parser::kind_f(&p_p3) {
            crate::syntax::lexer::TokKind::KDot(false) => {
                let p1_p5 = crate::syntax::parser::adv_f(&p_p3);
                let t_p6 = crate::syntax::parser::here_f(&p1_p5);
                match &crate::syntax::parser::kind_f(&p1_p5) {
                    crate::syntax::lexer::TokKind::KName(f_p7) if ((&f_p7.sigils_p == &crate::prelude::Text::lit("")) && (&f_p7.case_p == &crate::syntax::lexer::NameCase::CaseLower)) => {
                        e_p2 = crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EField(::std::rc::Rc::new(e_p2.clone()), crate::prelude::Text::lit(""), crate::syntax::Ident { name_p: crate::prelude::or(&crate::prelude::index(&f_p7.path_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")), span_p: t_p6.clone() })), span_p: crate::syntax::parser::to_f(&e_p2.span_p, &t_p6) };
                        p_p3 = crate::syntax::parser::adv_f(&p1_p5);
                        ()
                    },
                    crate::syntax::lexer::TokKind::KKw(u8153_1_0, _) if (u8153_1_0 == &crate::prelude::Text::lit("key")) => {
                        e_p2 = crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EField(::std::rc::Rc::new(e_p2.clone()), crate::prelude::Text::lit(""), crate::syntax::Ident { name_p: crate::prelude::Text::lit("key"), span_p: t_p6.clone() })), span_p: crate::syntax::parser::to_f(&e_p2.span_p, &t_p6) };
                        p_p3 = crate::syntax::parser::adv_f(&p1_p5);
                        ()
                    },
                    _ => {
                        p_p3 = crate::syntax::parser::fail_f(&p1_p5);
                        ()
                    },
                    _ => unreachable!("no arm matched"),
                };
                ()
            },
            crate::syntax::lexer::TokKind::KOpen(u8034_1_0, false) if (u8034_1_0 == &crate::prelude::Text::lit("[")) && crate::syntax::parser::tk_f(&p_p3).touches_p => {
                let (index_p8, p1_p9) = crate::syntax::parser::expr::parse_expr_f(&crate::syntax::parser::adv_f(&p_p3));
                let p2_pa = crate::syntax::parser::expect_close_f(&p1_p9, &crate::prelude::Text::lit("["));
                e_p2 = crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EIndex(::std::rc::Rc::new(e_p2.clone()), ::std::rc::Rc::new(index_p8.clone()))), span_p: crate::syntax::parser::to_f(&e_p2.span_p, &crate::syntax::parser::prev_f(&p2_pa)) };
                p_p3 = p2_pa.clone();
                ()
            },
            _ => {
                going_p4 = false;
                ()
            },
            _ => unreachable!("no arm matched"),
        };
    }
    this = (e_p2.clone(), p_p3.clone());
    this
}
