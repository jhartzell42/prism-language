//! The module `Syntax.Parser`, from `target/bootstrap/src/prismc/syntax/parser/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod blocks;
pub mod decls;
pub mod expr;
pub mod test_language;
pub mod types;

/// `Pair`:
///
/// ```prism
/// type Pair = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Pair {
    pub partner: Option<Nat>,
    pub outer: bool,
    pub inner: bool,
}

impl Show for Pair {
    fn show(&self, p: &mut Printer) {
        p.record("Pair", &[("partner", &self.partner), ("outer", &self.outer), ("inner", &self.inner)]);
    }
}

impl ToPod for Pair {
    fn to_pod(&self) -> Pod {
        Pod::record("Pair", vec![("partner", self.partner.to_pod()), ("outer", self.outer.to_pod()), ("inner", self.inner.to_pod())])
    }
}

impl FromPod for Pair {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Pair { partner: FromPod::from_pod(field(p, "partner")?)?, outer: FromPod::from_pod(field(p, "outer")?)?, inner: FromPod::from_pod(field(p, "inner")?)? })
    }
}

/// `Parsed`:
///
/// ```prism
/// type Parsed = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Parsed {
    pub tree: crate::syntax::Module,
    pub diags: Array<crate::syntax::Diag>,
}

impl Show for Parsed {
    fn show(&self, p: &mut Printer) {
        p.record("Parsed", &[("tree", &self.tree), ("diags", &self.diags)]);
    }
}

impl ToPod for Parsed {
    fn to_pod(&self) -> Pod {
        Pod::record("Parsed", vec![("tree", self.tree.to_pod()), ("diags", self.diags.to_pod())])
    }
}

impl FromPod for Parsed {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Parsed { tree: FromPod::from_pod(field(p, "tree")?)?, diags: FromPod::from_pod(field(p, "diags")?)? })
    }
}

/// `Ps`:
///
/// ```prism
/// type Ps = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Ps {
    pub toks: Array<crate::syntax::lexer::Tok>,
    pub pairs: Array<Pair>,
    pub pos: Nat,
    pub diags: Array<crate::syntax::Diag>,
    pub out: Array<crate::syntax::Diag>,
    pub step_mode: bool,
    pub in_trait: bool,
    pub bad: bool,
}

impl Show for Ps {
    fn show(&self, p: &mut Printer) {
        p.record("Ps", &[("toks", &self.toks), ("pairs", &self.pairs), ("pos", &self.pos), ("diags", &self.diags), ("out", &self.out), ("step_mode", &self.step_mode), ("in_trait", &self.in_trait), ("bad", &self.bad)]);
    }
}

impl ToPod for Ps {
    fn to_pod(&self) -> Pod {
        Pod::record("Ps", vec![("toks", self.toks.to_pod()), ("pairs", self.pairs.to_pod()), ("pos", self.pos.to_pod()), ("diags", self.diags.to_pod()), ("out", self.out.to_pod()), ("step_mode", self.step_mode.to_pod()), ("in_trait", self.in_trait.to_pod()), ("bad", self.bad.to_pod())])
    }
}

impl FromPod for Ps {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Ps { toks: FromPod::from_pod(field(p, "toks")?)?, pairs: FromPod::from_pod(field(p, "pairs")?)?, pos: FromPod::from_pod(field(p, "pos")?)?, diags: FromPod::from_pod(field(p, "diags")?)?, out: FromPod::from_pod(field(p, "out")?)?, step_mode: FromPod::from_pod(field(p, "step_mode")?)?, in_trait: FromPod::from_pod(field(p, "in_trait")?)?, bad: FromPod::from_pod(field(p, "bad")?)? })
    }
}

/// ```prism
/// let noRange
/// ```
pub fn no_range() -> crate::syntax::Range {
    crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) }
}

/// ```prism
/// let eofTok
/// ```
pub fn eof_tok() -> crate::syntax::lexer::Tok {
    crate::syntax::lexer::Tok { kind: crate::syntax::lexer::TokKind::KEof, span: no_range(), touches: false, line_start: false }
}

/// ```prism
/// let noPair
/// ```
pub fn no_pair() -> Pair {
    Pair { partner: None, outer: false, inner: false }
}

/// ```prism
/// ParseFile: unbounded fn Text -> Parsed
/// ```
pub fn parse_file(src_p0: &Text) -> Parsed {
    let lexed_p1 = crate::syntax::lexer::layout::lex_file(src_p0);
    let (m_p2, p_p3) = crate::syntax::parser::decls::parse_module(&new_ps(&lexed_p1.tokens), &false);
    Parsed { tree: m_p2.clone(), diags: finish_diags(&append(&append(&lexed_p1.diags, &p_p3.diags), &p_p3.out)) }
}

/// The step machine of `ParseFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseFile: unbounded fn Text -> Parsed
/// ```
pub struct ParseFile {
    pub src_p0: Text,
}

impl prism_rtl::Job<Parsed> for ParseFile {
    fn cycle(&self) -> prism_rtl::Turn<Parsed> {
        let src_p0 = &self.src_p0;
        let src_p0 = src_p0.clone();
        call_then(crate::syntax::lexer::layout::start_lex_file(src_p0.clone()), move |lex_file_3387: crate::syntax::lexer::Lexed| {
            let lexed_p1 = lex_file_3387;
            call_then(start_new_ps(lexed_p1.tokens.clone()), move |new_ps_3431: Ps| call_then(crate::syntax::parser::decls::start_parse_module(new_ps_3431, false), move |parse_module_3418: (crate::syntax::Module, Ps)| {
                let (m_p2, p_p3) = parse_module_3418;
                prism_rtl::Turn::Finished(Parsed { tree: m_p2.clone(), diags: finish_diags(&append(&append(&lexed_p1.diags, &p_p3.diags), &p_p3.out)) })
            }))
        })
    }
}

/// `Start ParseFile, x`: what the function value is when passed to `@Run`.
pub fn start_parse_file(src_p0: Text) -> Rc<dyn prism_rtl::Job<Parsed>> {
    Rc::new(ParseFile { src_p0 })
}

/// ```prism
/// ParseFragment: unbounded fn Text -> Parsed
/// ```
pub fn parse_fragment(src_p0: &Text) -> Parsed {
    let lexed_p1 = crate::syntax::lexer::layout::lex_file(src_p0);
    let (m_p2, p_p3) = crate::syntax::parser::decls::parse_module(&new_ps(&lexed_p1.tokens), &true);
    Parsed { tree: m_p2.clone(), diags: finish_diags(&append(&append(&lexed_p1.diags, &p_p3.diags), &p_p3.out)) }
}

/// The step machine of `ParseFragment`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseFragment: unbounded fn Text -> Parsed
/// ```
pub struct ParseFragment {
    pub src_p0: Text,
}

impl prism_rtl::Job<Parsed> for ParseFragment {
    fn cycle(&self) -> prism_rtl::Turn<Parsed> {
        let src_p0 = &self.src_p0;
        let src_p0 = src_p0.clone();
        call_then(crate::syntax::lexer::layout::start_lex_file(src_p0.clone()), move |lex_file_3780: crate::syntax::lexer::Lexed| {
            let lexed_p1 = lex_file_3780;
            call_then(start_new_ps(lexed_p1.tokens.clone()), move |new_ps_3824: Ps| call_then(crate::syntax::parser::decls::start_parse_module(new_ps_3824, true), move |parse_module_3811: (crate::syntax::Module, Ps)| {
                let (m_p2, p_p3) = parse_module_3811;
                prism_rtl::Turn::Finished(Parsed { tree: m_p2.clone(), diags: finish_diags(&append(&append(&lexed_p1.diags, &p_p3.diags), &p_p3.out)) })
            }))
        })
    }
}

/// `Start ParseFragment, x`: what the function value is when passed to `@Run`.
pub fn start_parse_fragment(src_p0: Text) -> Rc<dyn prism_rtl::Job<Parsed>> {
    Rc::new(ParseFragment { src_p0 })
}

/// ```prism
/// NewPs: unbounded fn [Tok] -> Ps
/// ```
pub fn new_ps(toks0_p0: &Array<crate::syntax::lexer::Tok>) -> Ps {
    let ends_p1 = match crate::syntax::lexer::chars::last(toks0_p0) {
        Some(t_p4) => &t_p4.kind == &crate::syntax::lexer::TokKind::KEof,
        None => false,
    };
    let end_p2 = match crate::syntax::lexer::chars::last(toks0_p0) {
        Some(t_p5) => crate::syntax::Range { start: t_p5.span.end.clone(), end: t_p5.span.end.clone() },
        None => no_range(),
    };
    let toks_p3 = if ends_p1 {
        toks0_p0.clone()
    } else {
        push(toks0_p0, &crate::syntax::lexer::Tok { kind: crate::syntax::lexer::TokKind::KEof, span: end_p2.clone(), touches: false, line_start: false })
    };
    Ps { toks: toks_p3.clone(), pairs: pair_brackets(&toks_p3), pos: Nat::from(0u32), diags: Array::new(), out: Array::new(), step_mode: false, in_trait: false, bad: false }
}

/// The step machine of `NewPs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NewPs: unbounded fn [Tok] -> Ps
/// ```
pub struct NewPs {
    pub toks0_p0: Array<crate::syntax::lexer::Tok>,
}

impl prism_rtl::Job<Ps> for NewPs {
    fn cycle(&self) -> prism_rtl::Turn<Ps> {
        let toks0_p0 = &self.toks0_p0;
        let ends_p1 = match crate::syntax::lexer::chars::last(toks0_p0) {
            Some(t_p4) => &t_p4.kind == &crate::syntax::lexer::TokKind::KEof,
            None => false,
        };
        let end_p2 = match crate::syntax::lexer::chars::last(toks0_p0) {
            Some(t_p5) => crate::syntax::Range { start: t_p5.span.end.clone(), end: t_p5.span.end.clone() },
            None => no_range(),
        };
        let toks_p3 = if ends_p1 {
            toks0_p0.clone()
        } else {
            push(toks0_p0, &crate::syntax::lexer::Tok { kind: crate::syntax::lexer::TokKind::KEof, span: end_p2.clone(), touches: false, line_start: false })
        };
        call_then(start_pair_brackets(toks_p3.clone()), move |pair_brackets_4303: Array<Pair>| prism_rtl::Turn::Finished(Ps { toks: toks_p3.clone(), pairs: pair_brackets_4303, pos: Nat::from(0u32), diags: Array::new(), out: Array::new(), step_mode: false, in_trait: false, bad: false }))
    }
}

/// `Start NewPs, x`: what the function value is when passed to `@Run`.
pub fn start_new_ps(toks0_p0: Array<crate::syntax::lexer::Tok>) -> Rc<dyn prism_rtl::Job<Ps>> {
    Rc::new(NewPs { toks0_p0 })
}

/// ```prism
/// Sub: unbounded fn Ps, [Tok], Range -> Ps
/// ```
pub fn sub(p_p0: &Ps, toks_p1: &Array<crate::syntax::lexer::Tok>, end_p2: &crate::syntax::Range) -> Ps {
    let q_p3 = new_ps(&push(toks_p1, &crate::syntax::lexer::Tok { kind: crate::syntax::lexer::TokKind::KEof, span: end_p2.clone(), touches: false, line_start: false }));
    let mut this: Ps = q_p3.clone();
    this.step_mode = p_p0.step_mode;
    this
}

/// The step machine of `Sub`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Sub: unbounded fn Ps, [Tok], Range -> Ps
/// ```
pub struct Sub {
    pub p_p0: Ps,
    pub toks_p1: Array<crate::syntax::lexer::Tok>,
    pub end_p2: crate::syntax::Range,
}

impl prism_rtl::Job<Ps> for Sub {
    fn cycle(&self) -> prism_rtl::Turn<Ps> {
        let p_p0 = &self.p_p0;
        let toks_p1 = &self.toks_p1;
        let end_p2 = &self.end_p2;
        let end_p2 = end_p2.clone();
        let p_p0 = p_p0.clone();
        let toks_p1 = toks_p1.clone();
        call_then(start_new_ps(push(&toks_p1, &crate::syntax::lexer::Tok { kind: crate::syntax::lexer::TokKind::KEof, span: end_p2.clone(), touches: false, line_start: false })), move |new_ps_4612: Ps| {
            let q_p3 = new_ps_4612;
            prism_rtl::Turn::Finished({
                let mut this: Ps = q_p3.clone();
                this.step_mode = p_p0.step_mode;
                this
            })
        })
    }
}

/// `Start Sub, x`: what the function value is when passed to `@Run`.
pub fn start_sub(p_p0: Ps, toks_p1: Array<crate::syntax::lexer::Tok>, end_p2: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<Ps>> {
    Rc::new(Sub { p_p0, toks_p1, end_p2 })
}

/// ```prism
/// Absorb: fn Ps, Ps -> Ps
/// ```
pub fn absorb(p_p0: &Ps, sub_p1: &Ps) -> Ps {
    let mut this: Ps = p_p0.clone();
    this.diags = append(&this.diags, &sub_p1.diags);
    this.out = append(&this.out, &sub_p1.out);
    this
}

/// ```prism
/// FinishDiags: fn [Diag] -> [Diag]
/// ```
pub fn finish_diags(ds_p0: &Array<crate::syntax::Diag>) -> Array<crate::syntax::Diag> {
    let sorted_p1 = fold(ds_p0, &Array::new(), &insert_diag);
    fold(&sorted_p1, &Array::new(), &(|acc_p2: &Array<crate::syntax::Diag>, d_p3: &crate::syntax::Diag| match crate::syntax::lexer::chars::last(acc_p2) {
        Some(e_p4) if ((&e_p4.span == &d_p3.span) && (&e_p4.message == &d_p3.message)) => acc_p2.clone(),
        _ => push(acc_p2, d_p3),
        _ => unreachable!("no arm matched"),
    }))
}

/// ```prism
/// StageRank: fn Text -> Nat
/// ```
pub fn stage_rank(text0: &Text) -> Nat {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("lex")) => Nat::from(0u32),
        c1_0 if (c1_0 == &Text::lit("parse")) => Nat::from(1u32),
        _ => Nat::from(2u32),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// DiagBefore: fn Diag, Diag -> Bool
/// ```
pub fn diag_before(a_p0: &crate::syntax::Diag, b_p1: &crate::syntax::Diag) -> bool {
    (&a_p0.span.start < &b_p1.span.start) || ((&a_p0.span.start == &b_p1.span.start) && (&stage_rank(&a_p0.stage) < &stage_rank(&b_p1.stage)))
}

/// ```prism
/// InsertDiag: fn [Diag], Diag -> [Diag]
/// ```
pub fn insert_diag(sorted_p0: &Array<crate::syntax::Diag>, d_p1: &crate::syntax::Diag) -> Array<crate::syntax::Diag> {
    let before_p2 = fold(sorted_p0, &Array::new(), &(|acc_p4: &Array<crate::syntax::Diag>, e_p5: &crate::syntax::Diag| if diag_before(d_p1, e_p5) { acc_p4.clone() } else { push(acc_p4, e_p5) }));
    let after_p3 = fold(sorted_p0, &Array::new(), &(|acc_p6: &Array<crate::syntax::Diag>, e_p7: &crate::syntax::Diag| if diag_before(d_p1, e_p7) { push(acc_p6, e_p7) } else { acc_p6.clone() }));
    append(&push(&before_p2, d_p1), &after_p3)
}

/// ```prism
/// PairBrackets: unbounded fn [Tok] -> [Pair]
/// ```
pub fn pair_brackets(toks_p0: &Array<crate::syntax::lexer::Tok>) -> Array<Pair> {
    let mut this: Array<Pair> = each(toks_p0, &(|t_p1: &crate::syntax::lexer::Tok| no_pair()));
    let mut stack_p2: Array<(Nat, Text)> = Array::new();
    for (i6364, v6364) in toks_p0.clone().into_iter().enumerate() {
        let k6364 = nat_of(i6364);
        let t_p3 = v6364.clone();
        if let Some(k_p4) = open_kind_of(&t_p3.kind) {
            stack_p2 = push(&stack_p2, &(k6364.clone(), k_p4.clone()));
        }
        if let Some(k_p5) = close_kind_of(&t_p3.kind) {
            if let Some((j_p6, k2_p7)) = crate::syntax::lexer::chars::last(&stack_p2) {
                if &k2_p7 == &k_p5 {
                    stack_p2 = crate::syntax::lexer::chars::pop(&stack_p2);
                    (*at_mut(&mut this, &k6364)).partner = Some(j_p6.clone());
                    (*at_mut(&mut this, &j_p6)).partner = Some(k6364.clone());
                }
            }
        }
    }
    for (i6825, v6825) in toks_p0.clone().into_iter().enumerate() {
        let k6825 = nat_of(i6825);
        let t_p8 = v6825.clone();
        let i_p9 = k6825.clone();
        if let Some(kind_pa) = open_kind_of(&t_p8.kind) {
            if (&kind_pa != &Text::lit("{")) && !or(&index(&this, &i_p9), &no_pair()).inner {
                if let Some(j_pb) = or(&index(&this, &i_p9), &no_pair()).partner.clone() {
                    if double_at(&this, toks_p0, &i_p9, &j_pb, &kind_pa) {
                        (*at_mut(&mut this, &i_p9)).outer = true;
                        (*at_mut(&mut this, &j_pb)).outer = true;
                        (*at_mut(&mut this, &(&i_p9 + &Nat::from(1u32)))).inner = true;
                        (*at_mut(&mut this, &crate::syntax::lexer::chars::dec(&j_pb))).inner = true;
                    }
                }
            }
        }
    }
    this
}

/// The step machine of `PairBrackets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PairBrackets: unbounded fn [Tok] -> [Pair]
/// ```
pub struct PairBrackets {
    pub toks_p0: Array<crate::syntax::lexer::Tok>,
}

impl prism_rtl::Job<Array<Pair>> for PairBrackets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Pair>> {
        let toks_p0 = &self.toks_p0;
        prism_rtl::Turn::Finished({
            let mut this: Array<Pair> = each(toks_p0, &(|t_p1: &crate::syntax::lexer::Tok| no_pair()));
            let mut stack_p2: Array<(Nat, Text)> = Array::new();
            for (i6364, v6364) in toks_p0.clone().into_iter().enumerate() {
                let k6364 = nat_of(i6364);
                let t_p3 = v6364.clone();
                if let Some(k_p4) = open_kind_of(&t_p3.kind) {
                    stack_p2 = push(&stack_p2, &(k6364.clone(), k_p4.clone()));
                }
                if let Some(k_p5) = close_kind_of(&t_p3.kind) {
                    if let Some((j_p6, k2_p7)) = crate::syntax::lexer::chars::last(&stack_p2) {
                        if &k2_p7 == &k_p5 {
                            stack_p2 = crate::syntax::lexer::chars::pop(&stack_p2);
                            (*at_mut(&mut this, &k6364)).partner = Some(j_p6.clone());
                            (*at_mut(&mut this, &j_p6)).partner = Some(k6364.clone());
                        }
                    }
                }
            }
            for (i6825, v6825) in toks_p0.clone().into_iter().enumerate() {
                let k6825 = nat_of(i6825);
                let t_p8 = v6825.clone();
                let i_p9 = k6825.clone();
                if let Some(kind_pa) = open_kind_of(&t_p8.kind) {
                    if (&kind_pa != &Text::lit("{")) && !or(&index(&this, &i_p9), &no_pair()).inner {
                        if let Some(j_pb) = or(&index(&this, &i_p9), &no_pair()).partner.clone() {
                            if double_at(&this, toks_p0, &i_p9, &j_pb, &kind_pa) {
                                (*at_mut(&mut this, &i_p9)).outer = true;
                                (*at_mut(&mut this, &j_pb)).outer = true;
                                (*at_mut(&mut this, &(&i_p9 + &Nat::from(1u32)))).inner = true;
                                (*at_mut(&mut this, &crate::syntax::lexer::chars::dec(&j_pb))).inner = true;
                            }
                        }
                    }
                }
            }
            this
        })
    }
}

/// `Start PairBrackets, x`: what the function value is when passed to `@Run`.
pub fn start_pair_brackets(toks_p0: Array<crate::syntax::lexer::Tok>) -> Rc<dyn prism_rtl::Job<Array<Pair>>> {
    Rc::new(PairBrackets { toks_p0 })
}

/// ```prism
/// DoubleAt: fn [Pair], [Tok], Nat, Nat, Text -> Bool
/// ```
pub fn double_at(pairs_p0: &Array<Pair>, toks_p1: &Array<crate::syntax::lexer::Tok>, i_p2: &Nat, j_p3: &Nat, kind_p4: &Text) -> bool {
    let next_p5 = or(&index(toks_p1, &(i_p2 + &Nat::from(1u32))), &eof_tok());
    let inner_close_o6 = or(&index(pairs_p0, &(i_p2 + &Nat::from(1u32))), &no_pair()).partner.clone();
    ((is_open_of(&next_p5.kind, kind_p4) && next_p5.touches) && (&inner_close_o6 == &Some(crate::syntax::lexer::chars::dec(j_p3)))) && or(&index(toks_p1, j_p3), &eof_tok()).touches
}

/// ```prism
/// ?OpenKindOf: fn TokKind -> ?Text
/// ```
pub fn open_kind_of(tok_kind0: &crate::syntax::lexer::TokKind) -> Option<Text> {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KOpen(k_p0, _) => Some(k_p0.clone()),
        _ => None,
    }
}

/// ```prism
/// ?CloseKindOf: fn TokKind -> ?Text
/// ```
pub fn close_kind_of(tok_kind0: &crate::syntax::lexer::TokKind) -> Option<Text> {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KClose(k_p0) => Some(k_p0.clone()),
        _ => None,
    }
}

/// ```prism
/// IsOpenOf: fn TokKind, Text -> Bool
/// ```
pub fn is_open_of(tok_kind0: &crate::syntax::lexer::TokKind, text1: &Text) -> bool {
    match (tok_kind0, text1) {
        (crate::syntax::lexer::TokKind::KOpen(k_p0, _), kind_p1) => k_p0 == kind_p1,
        (_, _) => false,
    }
}

/// ```prism
/// Tk: fn Ps -> Tok
/// ```
pub fn tk(p_p0: &Ps) -> crate::syntax::lexer::Tok {
    if p_p0.bad {
        eof_tok()
    } else {
        or(&index(&p_p0.toks, &min(&p_p0.pos, &crate::syntax::lexer::chars::dec(&len(&p_p0.toks)))), &eof_tok())
    }
}

/// ```prism
/// TkAt: fn Ps, Nat -> Tok
/// ```
pub fn tk_at(p_p0: &Ps, n_p1: &Nat) -> crate::syntax::lexer::Tok {
    if p_p0.bad {
        eof_tok()
    } else {
        or(&index(&p_p0.toks, &min(&(&p_p0.pos + n_p1), &crate::syntax::lexer::chars::dec(&len(&p_p0.toks)))), &eof_tok())
    }
}

/// ```prism
/// Kind: fn Ps -> TokKind
/// ```
pub fn kind(p_p0: &Ps) -> crate::syntax::lexer::TokKind {
    tk(p_p0).kind.clone()
}

/// ```prism
/// KindAt: fn Ps, Nat -> TokKind
/// ```
pub fn kind_at(p_p0: &Ps, n_p1: &Nat) -> crate::syntax::lexer::TokKind {
    tk_at(p_p0, n_p1).kind.clone()
}

/// ```prism
/// Here: fn Ps -> Range
/// ```
pub fn here(p_p0: &Ps) -> crate::syntax::Range {
    tk(p_p0).span.clone()
}

/// ```prism
/// Prev: fn Ps -> Range
/// ```
pub fn prev(p_p0: &Ps) -> crate::syntax::Range {
    or(&index(&p_p0.toks, &crate::syntax::lexer::chars::dec(&p_p0.pos)), &eof_tok()).span.clone()
}

/// ```prism
/// To: fn Range, Range -> Range
/// ```
pub fn to(a_p0: &crate::syntax::Range, b_p1: &crate::syntax::Range) -> crate::syntax::Range {
    crate::syntax::Range { start: min(&a_p0.start, &b_p1.start), end: max(&a_p0.end, &b_p1.end) }
}

/// ```prism
/// AtEnd: fn Range -> Range
/// ```
pub fn at_end(r_p0: &crate::syntax::Range) -> crate::syntax::Range {
    crate::syntax::Range { start: r_p0.end.clone(), end: r_p0.end.clone() }
}

/// ```prism
/// Adv: fn Ps -> Ps
/// ```
pub fn adv(p_p0: &Ps) -> Ps {
    if p_p0.bad || (&(&p_p0.pos + &Nat::from(1u32)) >= &len(&p_p0.toks)) {
        p_p0.clone()
    } else {
        {
            let mut this: Ps = p_p0.clone();
            this.pos = &this.pos + &Nat::from(1u32);
            this
        }
    }
}

/// ```prism
/// PairAt: fn Ps -> Pair
/// ```
pub fn pair_at(p_p0: &Ps) -> Pair {
    or(&index(&p_p0.pairs, &min(&p_p0.pos, &crate::syntax::lexer::chars::dec(&len(&p_p0.pairs)))), &no_pair())
}

/// ```prism
/// AtEof: fn Ps -> Bool
/// ```
pub fn at_eof(p_p0: &Ps) -> bool {
    &kind(p_p0) == &crate::syntax::lexer::TokKind::KEof
}

/// ```prism
/// AtKw: fn Ps, Text -> Bool
/// ```
pub fn at_kw(p_p0: &Ps, w_p1: &Text) -> bool {
    &kind(p_p0) == &crate::syntax::lexer::TokKind::KKw(w_p1.clone(), Text::lit(""))
}

/// ```prism
/// AtOp: fn Ps, Text -> Bool
/// ```
pub fn at_op(p_p0: &Ps, op_p1: &Text) -> bool {
    match kind(p_p0) {
        crate::syntax::lexer::TokKind::KOp(o_p2, _) => &o_p2 == op_p1,
        _ => false,
    }
}

/// ```prism
/// AtSep: fn Ps -> Bool
/// ```
pub fn at_sep(p_p0: &Ps) -> bool {
    &kind(p_p0) == &crate::syntax::lexer::TokKind::KLaySep
}

/// ```prism
/// AtOpenL: fn Ps -> Bool
/// ```
pub fn at_open_l(p_p0: &Ps) -> bool {
    &kind(p_p0) == &crate::syntax::lexer::TokKind::KLayOpen
}

/// ```prism
/// AtCloseL: fn Ps -> Bool
/// ```
pub fn at_close_l(p_p0: &Ps) -> bool {
    &kind(p_p0) == &crate::syntax::lexer::TokKind::KLayClose
}

/// ```prism
/// AtComma: fn Ps -> Bool
/// ```
pub fn at_comma(p_p0: &Ps) -> bool {
    &kind(p_p0) == &crate::syntax::lexer::TokKind::KComma
}

/// ```prism
/// AtColon: fn Ps -> Bool
/// ```
pub fn at_colon(p_p0: &Ps) -> bool {
    &kind(p_p0) == &crate::syntax::lexer::TokKind::KColon
}

/// ```prism
/// IsOpenKind: fn TokKind, Text -> Bool
/// ```
pub fn is_open_kind(tok_kind0: &crate::syntax::lexer::TokKind, text1: &Text) -> bool {
    match (tok_kind0, text1) {
        (crate::syntax::lexer::TokKind::KOpen(k_p0, _), kind_p1) => k_p0 == kind_p1,
        (_, _) => false,
    }
}

/// ```prism
/// AtDoubleOpen: fn Ps, Text -> Bool
/// ```
pub fn at_double_open(p_p0: &Ps, kind_p1: &Text) -> bool {
    is_open_kind(&kind(p_p0), kind_p1) && pair_at(p_p0).outer
}

/// ```prism
/// AtSingleOpen: fn Ps, Text -> Bool
/// ```
pub fn at_single_open(p_p0: &Ps, kind_p1: &Text) -> bool {
    is_open_kind(&kind(p_p0), kind_p1) && !pair_at(p_p0).outer
}

/// ```prism
/// AtClose: fn Ps, Text -> Bool
/// ```
pub fn at_close(p_p0: &Ps, kind_p1: &Text) -> bool {
    &kind(p_p0) == &crate::syntax::lexer::TokKind::KClose(kind_p1.clone())
}

/// ```prism
/// OpenDouble: fn Ps -> Ps
/// ```
pub fn open_double(p_p0: &Ps) -> Ps {
    adv(&adv(p_p0))
}

/// ```prism
/// CloseDouble: fn Ps, Text -> Ps
/// ```
pub fn close_double(p_p0: &Ps, kind_p1: &Text) -> Ps {
    let c_p2 = crate::syntax::lexer::close_char(kind_p1);
    let p1_p3 = adv(p_p0);
    if ((at_close(p_p0, kind_p1) && pair_at(p_p0).inner) && at_close(&p1_p3, kind_p1)) && pair_at(&p1_p3).outer {
        adv(&p1_p3)
    } else {
        if at_close(p_p0, kind_p1) && pair_at(p_p0).inner {
            error_here(&p1_p3, &Text::from(format!("expected `{}{}` to close the double bracket", &c_p2, &c_p2)))
        } else {
            error_here(p_p0, &Text::from(format!("expected `{}{}` to close the double bracket", &c_p2, &c_p2)))
        }
    }
}

/// ```prism
/// ExpectClose: fn Ps, Text -> Ps
/// ```
pub fn expect_close(p_p0: &Ps, kind_p1: &Text) -> Ps {
    if at_close(p_p0, kind_p1) {
        adv(p_p0)
    } else {
        error_here(p_p0, &Text::from(format!("expected `{}`", &crate::syntax::lexer::close_char(kind_p1))))
    }
}

/// ```prism
/// ParseDiag: fn Range, Text -> Diag
/// ```
pub fn parse_diag(span_p0: &crate::syntax::Range, message_p1: &Text) -> crate::syntax::Diag {
    crate::syntax::Diag { stage: Text::lit("parse"), span: span_p0.clone(), message: message_p1.clone(), feature: None }
}

/// ```prism
/// ErrorAt: fn Ps, Range, Text -> Ps
/// ```
pub fn error_at(p_p0: &Ps, span_p1: &crate::syntax::Range, message_p2: &Text) -> Ps {
    if p_p0.bad {
        p_p0.clone()
    } else {
        {
            let mut this: Ps = p_p0.clone();
            this.diags = push(&this.diags, &parse_diag(span_p1, message_p2));
            this.bad = true;
            this
        }
    }
}

/// ```prism
/// ErrorHere: fn Ps, Text -> Ps
/// ```
pub fn error_here(p_p0: &Ps, message_p1: &Text) -> Ps {
    error_at(p_p0, &here(p_p0), &Text::from(format!("{}, found {}", message_p1, &describe(&kind(p_p0)))))
}

/// ```prism
/// Fail: fn Ps -> Ps
/// ```
pub fn fail(p_p0: &Ps) -> Ps {
    let mut this: Ps = p_p0.clone();
    this.bad = true;
    this
}

/// ```prism
/// Unbad: fn Ps -> Ps
/// ```
pub fn unbad(p_p0: &Ps) -> Ps {
    let mut this: Ps = p_p0.clone();
    this.bad = false;
    this
}

/// ```prism
/// NoteError: fn Ps, Range, Text -> Ps
/// ```
pub fn note_error(p_p0: &Ps, span_p1: &crate::syntax::Range, message_p2: &Text) -> Ps {
    if p_p0.bad {
        p_p0.clone()
    } else {
        {
            let mut this: Ps = p_p0.clone();
            this.diags = push(&this.diags, &parse_diag(span_p1, message_p2));
            this
        }
    }
}

/// ```prism
/// Complain: fn Ps, Text -> Ps
/// ```
pub fn complain(p_p0: &Ps, message_p1: &Text) -> Ps {
    unbad(&error_here(p_p0, message_p1))
}

/// ```prism
/// OutOfScope: fn Ps, Range, Text, Text -> Ps
/// ```
pub fn out_of_scope(p_p0: &Ps, span_p1: &crate::syntax::Range, feature_p2: &Text, message_p3: &Text) -> Ps {
    if p_p0.bad {
        p_p0.clone()
    } else {
        {
            let mut this: Ps = p_p0.clone();
            this.out = push(&this.out, &crate::syntax::Diag { stage: Text::lit("out"), span: span_p1.clone(), message: message_p3.clone(), feature: Some(feature_p2.clone()) });
            this
        }
    }
}

/// ```prism
/// ExpectColon: fn Ps -> Ps
/// ```
pub fn expect_colon(p_p0: &Ps) -> Ps {
    if at_colon(p_p0) { adv(p_p0) } else { error_here(p_p0, &Text::lit("expected `:`")) }
}

/// ```prism
/// ExpectOp: fn Ps, Text -> Ps
/// ```
pub fn expect_op(p_p0: &Ps, op_p1: &Text) -> Ps {
    if at_op(p_p0, op_p1) {
        adv(p_p0)
    } else {
        error_here(p_p0, &Text::from(format!("expected `{}`", op_p1)))
    }
}

/// ```prism
/// ExpectKw: fn Ps, Text -> Ps
/// ```
pub fn expect_kw(p_p0: &Ps, w_p1: &Text) -> Ps {
    if at_kw(p_p0, w_p1) {
        adv(p_p0)
    } else {
        error_here(p_p0, &Text::from(format!("expected `{}`", w_p1)))
    }
}

/// ```prism
/// Recover: unbounded fn Ps -> Ps
/// ```
pub fn recover(p0_p0: &Ps) -> Ps {
    let mut this: Ps = unbad(p0_p0);
    let mut depth_p1: Nat = Nat::from(0u32);
    let mut going_p2: bool = true;
    while going_p2 {
        match &kind(&this) {
            crate::syntax::lexer::TokKind::KEof => {
                going_p2 = false;
                ()
            },
            crate::syntax::lexer::TokKind::KLayOpen => {
                depth_p1 = &depth_p1 + &Nat::from(1u32);
                this = adv(&this);
                ()
            },
            crate::syntax::lexer::TokKind::KLayClose => {
                if &depth_p1 == &Nat::from(0u32) {
                    going_p2 = false;
                } else {
                    depth_p1 = crate::syntax::lexer::chars::dec(&depth_p1);
                    this = adv(&this);
                }
                ()
            },
            crate::syntax::lexer::TokKind::KLaySep if (&depth_p1 == &Nat::from(0u32)) => {
                going_p2 = false;
                ()
            },
            _ => {
                this = adv(&this);
                ()
            },
            _ => unreachable!("no arm matched"),
        };
    }
    this
}

/// The step machine of `Recover`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Recover: unbounded fn Ps -> Ps
/// ```
pub struct Recover {
    pub p0_p0: Ps,
}

impl prism_rtl::Job<Ps> for Recover {
    fn cycle(&self) -> prism_rtl::Turn<Ps> {
        let p0_p0 = &self.p0_p0;
        let mut this: Ps = unbad(p0_p0);
        let mut depth_p1: Nat = Nat::from(0u32);
        let mut going_p2: bool = true;
        call_then(loop_job((this, depth_p1, going_p2), move |(mut this, mut depth_p1, mut going_p2): (Ps, Nat, bool)| if going_p2 {
            {
                match &kind(&this) {
                    crate::syntax::lexer::TokKind::KEof => {
                        going_p2 = false;
                        ()
                    },
                    crate::syntax::lexer::TokKind::KLayOpen => {
                        depth_p1 = &depth_p1 + &Nat::from(1u32);
                        this = adv(&this);
                        ()
                    },
                    crate::syntax::lexer::TokKind::KLayClose => {
                        if &depth_p1 == &Nat::from(0u32) {
                            going_p2 = false;
                        } else {
                            depth_p1 = crate::syntax::lexer::chars::dec(&depth_p1);
                            this = adv(&this);
                        }
                        ()
                    },
                    crate::syntax::lexer::TokKind::KLaySep if (&depth_p1 == &Nat::from(0u32)) => {
                        going_p2 = false;
                        ()
                    },
                    _ => {
                        this = adv(&this);
                        ()
                    },
                    _ => unreachable!("no arm matched"),
                };
                Ok((this, depth_p1, going_p2))
            }
        } else {
            Err((this, depth_p1, going_p2))
        }), move |(mut this, mut depth_p1, mut going_p2): (Ps, Nat, bool)| prism_rtl::Turn::Finished(this))
    }
}

/// `Start Recover, x`: what the function value is when passed to `@Run`.
pub fn start_recover(p0_p0: Ps) -> Rc<dyn prism_rtl::Job<Ps>> {
    Rc::new(Recover { p0_p0 })
}

/// ```prism
/// Recovered: unbounded fn Ps -> Ps
/// ```
pub fn recovered(p_p0: &Ps) -> Ps {
    if p_p0.bad { recover(p_p0) } else { p_p0.clone() }
}

/// The step machine of `Recovered`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Recovered: unbounded fn Ps -> Ps
/// ```
pub struct Recovered {
    pub p_p0: Ps,
}

impl prism_rtl::Job<Ps> for Recovered {
    fn cycle(&self) -> prism_rtl::Turn<Ps> {
        let p_p0 = &self.p_p0;
        if p_p0.bad {
            prism_rtl::Turn::More(Rc::new(Recover { p0_p0: p_p0.clone() }))
        } else {
            prism_rtl::Turn::Finished(p_p0.clone())
        }
    }
}

/// `Start Recovered, x`: what the function value is when passed to `@Run`.
pub fn start_recovered(p_p0: Ps) -> Rc<dyn prism_rtl::Job<Ps>> {
    Rc::new(Recovered { p_p0 })
}

/// ```prism
/// AtStmtBoundary: fn Ps -> Bool
/// ```
pub fn at_stmt_boundary(p_p0: &Ps) -> bool {
    match kind(p_p0) {
        crate::syntax::lexer::TokKind::KLaySep => true,
        crate::syntax::lexer::TokKind::KLayClose => true,
        crate::syntax::lexer::TokKind::KEof => true,
        _ => false,
    }
}

/// ```prism
/// ExpectStmtEnd: unbounded fn Ps, Text -> Ps
/// ```
pub fn expect_stmt_end(p_p0: &Ps, what_p1: &Text) -> Ps {
    if at_stmt_boundary(p_p0) {
        p_p0.clone()
    } else {
        recover(&note_error(p_p0, &here(p_p0), &Text::from(format!("expected the end of the {}, found {}", what_p1, &describe(&kind(p_p0))))))
    }
}

/// The step machine of `ExpectStmtEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExpectStmtEnd: unbounded fn Ps, Text -> Ps
/// ```
pub struct ExpectStmtEnd {
    pub p_p0: Ps,
    pub what_p1: Text,
}

impl prism_rtl::Job<Ps> for ExpectStmtEnd {
    fn cycle(&self) -> prism_rtl::Turn<Ps> {
        let p_p0 = &self.p_p0;
        let what_p1 = &self.what_p1;
        if at_stmt_boundary(p_p0) {
            prism_rtl::Turn::Finished(p_p0.clone())
        } else {
            prism_rtl::Turn::More(Rc::new(Recover { p0_p0: note_error(p_p0, &here(p_p0), &Text::from(format!("expected the end of the {}, found {}", what_p1, &describe(&kind(p_p0))))) }))
        }
    }
}

/// `Start ExpectStmtEnd, x`: what the function value is when passed to `@Run`.
pub fn start_expect_stmt_end(p_p0: Ps, what_p1: Text) -> Rc<dyn prism_rtl::Job<Ps>> {
    Rc::new(ExpectStmtEnd { p_p0, what_p1 })
}

/// ```prism
/// Describe: fn TokKind -> Text
/// ```
pub fn describe(tok_kind0: &crate::syntax::lexer::TokKind) -> Text {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KLayOpen => Text::lit("an indented block"),
        crate::syntax::lexer::TokKind::KLaySep => Text::lit("the end of the line"),
        crate::syntax::lexer::TokKind::KLayClose => Text::lit("the end of the block"),
        crate::syntax::lexer::TokKind::KEof => Text::lit("the end of the input"),
        crate::syntax::lexer::TokKind::KText(_, _) => Text::lit("a text literal"),
        crate::syntax::lexer::TokKind::KRegex(_, _) => Text::lit("a regular expression"),
        crate::syntax::lexer::TokKind::KTemplate(_) => Text::lit("a template"),
        k_p0 => Text::from(format!("`{}`", &crate::syntax::lexer::corpus::token_text(k_p0))),
    }
}

/// ```prism
/// Bracketed: fn Ps, (fn Ps -> ((a, Ps))) -> ((a, Ps))
/// ```
pub fn bracketed<A: Clone + 'static>(p_p0: &Ps, f_f1: &Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>) -> (A, Ps) {
    let (v_p2, q_p3) = run_to_end(f_f1(with_step_mode(p_p0, &false)));
    (v_p2.clone(), with_step_mode(&q_p3, &p_p0.step_mode))
}

/// The step machine of `Bracketed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Bracketed: fn Ps, (fn Ps -> ((a, Ps))) -> ((a, Ps))
/// ```
pub struct Bracketed<A> {
    pub p_p0: Ps,
    pub f_f1: Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>,
}

impl<A: Clone + 'static> prism_rtl::Job<(A, Ps)> for Bracketed<A> {
    fn cycle(&self) -> prism_rtl::Turn<(A, Ps)> {
        let p_p0 = &self.p_p0;
        let f_f1 = &self.f_f1;
        let f_f1 = f_f1.clone();
        let p_p0 = p_p0.clone();
        call_value((&f_f1)(with_step_mode(&p_p0, &false)), move |f_14243: (A, Ps)| {
            let (v_p2, q_p3) = f_14243;
            prism_rtl::Turn::Finished((v_p2.clone(), with_step_mode(&q_p3, &p_p0.step_mode)))
        })
    }
}

/// `Start Bracketed, x`: what the function value is when passed to `@Run`.
pub fn start_bracketed<A: Clone + 'static>(p_p0: Ps, f_f1: Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>) -> Rc<dyn prism_rtl::Job<(A, Ps)>> {
    Rc::new(Bracketed { p_p0, f_f1 })
}

/// ```prism
/// WithStepMode: fn Ps, Bool -> Ps
/// ```
pub fn with_step_mode(p_p0: &Ps, flag_p1: &bool) -> Ps {
    let mut this: Ps = p_p0.clone();
    this.step_mode = *flag_p1;
    this
}

/// ```prism
/// LayoutItems: unbounded fn Ps, (fn Ps -> ((a, Ps))) -> (([a], Ps))
/// ```
pub fn layout_items<A: Clone + 'static>(p0_p0: &Ps, f_f1: &Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>) -> (Array<A>, Ps) {
    let mut this: (Array<A>, Ps) = (Array::new(), p0_p0.clone());
    let mut items_p2: Array<A> = Array::new();
    let mut p_p3: Ps = p0_p0.clone();
    let mut going_p4: bool = true;
    while going_p4 {
        let (item_p5, q_p6) = run_to_end(f_f1(p_p3.clone()));
        if !q_p6.bad {
            items_p2 = push(&items_p2, &item_p5);
        }
        p_p3 = recovered(&q_p6);
        match &kind(&p_p3) {
            crate::syntax::lexer::TokKind::KLaySep => {
                p_p3 = adv(&p_p3);
            }
            crate::syntax::lexer::TokKind::KLayClose => {
                p_p3 = adv(&p_p3);
                going_p4 = false;
            }
            crate::syntax::lexer::TokKind::KEof => {
                going_p4 = false;
            }
            _ => {
                p_p3 = recover(&complain(&p_p3, &Text::lit("expected the end of the line")));
            }
        }
    }
    this = (items_p2.clone(), p_p3.clone());
    this
}

/// The step machine of `LayoutItems`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LayoutItems: unbounded fn Ps, (fn Ps -> ((a, Ps))) -> (([a], Ps))
/// ```
pub struct LayoutItems<A> {
    pub p0_p0: Ps,
    pub f_f1: Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>,
}

impl<A: Clone + 'static> prism_rtl::Job<(Array<A>, Ps)> for LayoutItems<A> {
    fn cycle(&self) -> prism_rtl::Turn<(Array<A>, Ps)> {
        let p0_p0 = &self.p0_p0;
        let f_f1 = &self.f_f1;
        let mut this: (Array<A>, Ps) = (Array::new(), p0_p0.clone());
        let mut items_p2: Array<A> = Array::new();
        let mut p_p3: Ps = p0_p0.clone();
        let mut going_p4: bool = true;
        let f_f1 = f_f1.clone();
        call_then(loop_job((this, going_p4, items_p2, p_p3), {
            let f_f1 = f_f1.clone();
            move |(mut this, mut going_p4, mut items_p2, mut p_p3): ((Array<A>, Ps), bool, Array<A>, Ps)| if going_p4 {
                {
                    let (item_p5, q_p6) = run_to_end((&f_f1)(p_p3.clone()));
                    if !q_p6.bad {
                        items_p2 = push(&items_p2, &item_p5);
                    }
                    p_p3 = recovered(&q_p6);
                    match &kind(&p_p3) {
                        crate::syntax::lexer::TokKind::KLaySep => {
                            p_p3 = adv(&p_p3);
                        }
                        crate::syntax::lexer::TokKind::KLayClose => {
                            p_p3 = adv(&p_p3);
                            going_p4 = false;
                        }
                        crate::syntax::lexer::TokKind::KEof => {
                            going_p4 = false;
                        }
                        _ => {
                            p_p3 = recover(&complain(&p_p3, &Text::lit("expected the end of the line")));
                        }
                    }
                    Ok((this, going_p4, items_p2, p_p3))
                }
            } else {
                Err((this, going_p4, items_p2, p_p3))
            }
        }), move |(mut this, mut going_p4, mut items_p2, mut p_p3): ((Array<A>, Ps), bool, Array<A>, Ps)| {
            this = (items_p2.clone(), p_p3.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start LayoutItems, x`: what the function value is when passed to `@Run`.
pub fn start_layout_items<A: Clone + 'static>(p0_p0: Ps, f_f1: Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>) -> Rc<dyn prism_rtl::Job<(Array<A>, Ps)>> {
    Rc::new(LayoutItems { p0_p0, f_f1 })
}

/// ```prism
/// Commas: unbounded fn Ps, (fn Ps -> ((a, Ps))) -> (([a], Ps))
/// ```
pub fn commas<A: Clone + 'static>(p0_p0: &Ps, f_f1: &Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>) -> (Array<A>, Ps) {
    let mut this: (Array<A>, Ps) = (Array::new(), p0_p0.clone());
    let (first_p2, p1_p3) = run_to_end(f_f1(p0_p0.clone()));
    let mut items_p4: Array<A> = Array::from(vec![first_p2.clone()]);
    let mut p_p5: Ps = p1_p3.clone();
    while at_comma(&p_p5) && !p_p5.bad {
        let (item_p6, q_p7) = run_to_end(f_f1(adv(&p_p5)));
        items_p4 = push(&items_p4, &item_p6);
        p_p5 = q_p7.clone();
    }
    this = (items_p4.clone(), p_p5.clone());
    this
}

/// The step machine of `Commas`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Commas: unbounded fn Ps, (fn Ps -> ((a, Ps))) -> (([a], Ps))
/// ```
pub struct Commas<A> {
    pub p0_p0: Ps,
    pub f_f1: Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>,
}

impl<A: Clone + 'static> prism_rtl::Job<(Array<A>, Ps)> for Commas<A> {
    fn cycle(&self) -> prism_rtl::Turn<(Array<A>, Ps)> {
        let p0_p0 = &self.p0_p0;
        let f_f1 = &self.f_f1;
        let mut this: (Array<A>, Ps) = (Array::new(), p0_p0.clone());
        let (first_p2, p1_p3) = run_to_end(f_f1(p0_p0.clone()));
        let mut items_p4: Array<A> = Array::from(vec![first_p2.clone()]);
        let mut p_p5: Ps = p1_p3.clone();
        call_then(loop_job((this, items_p4, p_p5), {
            let f_f1 = f_f1.clone();
            move |(mut this, mut items_p4, mut p_p5): ((Array<A>, Ps), Array<A>, Ps)| if at_comma(&p_p5) && !p_p5.bad {
                {
                    let (item_p6, q_p7) = run_to_end((&f_f1)(adv(&p_p5)));
                    items_p4 = push(&items_p4, &item_p6);
                    p_p5 = q_p7.clone();
                    Ok((this, items_p4, p_p5))
                }
            } else {
                Err((this, items_p4, p_p5))
            }
        }), move |(mut this, mut items_p4, mut p_p5): ((Array<A>, Ps), Array<A>, Ps)| {
            this = (items_p4.clone(), p_p5.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start Commas, x`: what the function value is when passed to `@Run`.
pub fn start_commas<A: Clone + 'static>(p0_p0: Ps, f_f1: Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>) -> Rc<dyn prism_rtl::Job<(Array<A>, Ps)>> {
    Rc::new(Commas { p0_p0, f_f1 })
}

/// ```prism
/// let noSName
/// ```
pub fn no_sname() -> crate::syntax::SName {
    crate::syntax::SName { sigils: Text::lit(""), path_: Array::new(), span: no_range() }
}

/// ```prism
/// let noIdent
/// ```
pub fn no_ident() -> crate::syntax::Ident {
    crate::syntax::Ident { name: Text::lit(""), span: no_range() }
}

/// ```prism
/// IsUpperName: fn SName -> Bool
/// ```
pub fn is_upper_name(n_p0: &crate::syntax::SName) -> bool {
    crate::syntax::lexer::chars::is_upper(&crate::syntax::lexer::chars::head(&or(&crate::syntax::lexer::chars::last(&n_p0.path_), &Text::lit(""))))
}

/// ```prism
/// IsCallee: fn SName -> Bool
/// ```
pub fn is_callee(n_p0: &crate::syntax::SName) -> bool {
    is_upper_name(n_p0) || crate::syntax::lexer::chars::is_reserved_ctor(&or(&crate::syntax::lexer::chars::last(&n_p0.path_), &Text::lit("")))
}

/// ```prism
/// IsTopic: fn SName -> Bool
/// ```
pub fn is_topic(n_p0: &crate::syntax::SName) -> bool {
    &n_p0.path_ == &Array::from(vec![Text::lit("_")])
}

/// ```prism
/// NameText: fn SName -> Text
/// ```
pub fn name_text(n_p0: &crate::syntax::SName) -> Text {
    Text::from(format!("{}{}", &n_p0.sigils, &crate::syntax::lexer::chars::join(&n_p0.path_, &Text::lit("."))))
}

/// ```prism
/// ParseSName: fn Ps -> ((SName, Ps))
/// ```
pub fn parse_sname(p_p0: &Ps) -> (crate::syntax::SName, Ps) {
    match kind(p_p0) {
        crate::syntax::lexer::TokKind::KName(n_p1) => (crate::syntax::SName { sigils: n_p1.sigils.clone(), path_: n_p1.path_.clone(), span: here(p_p0) }, adv(p_p0)),
        _ => (no_sname(), error_here(p_p0, &Text::lit("expected a name"))),
    }
}

/// ```prism
/// ParseIdent: fn Ps -> ((Ident, Ps))
/// ```
pub fn parse_ident(p_p0: &Ps) -> (crate::syntax::Ident, Ps) {
    match kind(p_p0) {
        crate::syntax::lexer::TokKind::KName(n_p1) if (((&n_p1.sigils == &Text::lit("")) && (&len(&n_p1.path_) == &Nat::from(1u32))) && (&n_p1.case == &crate::syntax::lexer::NameCase::CaseLower)) => (crate::syntax::Ident { name: or(&index(&n_p1.path_, &Nat::from(0u32)), &Text::lit("")), span: here(p_p0) }, adv(p_p0)),
        crate::syntax::lexer::TokKind::KKw(m16443_1_0, m16443_1_1) if (&m16443_1_0 == &Text::lit("key")) && (&m16443_1_1 == &Text::lit("")) => (crate::syntax::Ident { name: Text::lit("key"), span: here(p_p0) }, adv(p_p0)),
        _ => (no_ident(), error_here(p_p0, &Text::lit("expected a lowercase name"))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParseQualName: fn Ps -> ((QualName, Ps))
/// ```
pub fn parse_qual_name(p_p0: &Ps) -> (crate::syntax::QualName, Ps) {
    match kind(p_p0) {
        crate::syntax::lexer::TokKind::KName(n_p1) if ((&n_p1.sigils == &Text::lit("")) && (&n_p1.case == &crate::syntax::lexer::NameCase::CaseUpper)) => (crate::syntax::QualName { path_: n_p1.path_.clone(), span: here(p_p0) }, adv(p_p0)),
        _ => (crate::syntax::QualName { path_: Array::new(), span: no_range() }, error_here(p_p0, &Text::lit("expected an uppercase name"))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParseTraitRef: fn Ps -> ((TraitRef, Ps))
/// ```
pub fn parse_trait_ref(p_p0: &Ps) -> (crate::syntax::TraitRef, Ps) {
    match kind(p_p0) {
        crate::syntax::lexer::TokKind::KTrait(path_p1) => {
            let span_p2 = here(p_p0);
            let q_p3 = if &path_p1 == &Array::from(vec![Text::lit("Monad")]) {
                out_of_scope(p_p0, &span_p2, &Text::lit("`T monad:` blocks and `^Monad`"), &Text::lit("`^Monad` is out of this compiler"))
            } else {
                p_p0.clone()
            };
            (crate::syntax::TraitRef { path_: path_p1.clone(), span: span_p2.clone() }, adv(&q_p3))
        },
        _ => (crate::syntax::TraitRef { path_: Array::new(), span: no_range() }, error_here(p_p0, &Text::lit("expected a trait, `^Name`"))),
    }
}

/// ```prism
/// CheckNameScope: fn Ps, SName -> Ps
/// ```
pub fn check_name_scope(p_p0: &Ps, name_p1: &crate::syntax::SName) -> Ps {
    let text_p2 = name_text(name_p1);
    let feature_p3 = match &text_p2 {
        m17606_0 if (m17606_0 == &Text::lit("!Align")) => Text::lit("`!Align`"),
        m17606_1 if (m17606_1 == &Text::lit("@Collect")) => Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"),
        m17606_2 if (m17606_2 == &Text::lit("@View")) => Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"),
        m17606_3 if (m17606_3 == &Text::lit("@Edit")) => Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"),
        m17606_4 if (m17606_4 == &Text::lit("@Translate")) => Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"),
        m17606_5 if (m17606_5 == &Text::lit("Over")) => Text::lit("named lenses `&Home` and `Over`"),
        _ => Text::lit(""),
        _ => unreachable!("no arm matched"),
    };
    if &feature_p3 == &Text::lit("") {
        p_p0.clone()
    } else {
        out_of_scope(p_p0, &name_p1.span, &feature_p3, &Text::from(format!("`{}` is out of this compiler", &text_p2)))
    }
}

/// ```prism
/// CheckTypeNameScope: fn Ps, SName -> Ps
/// ```
pub fn check_type_name_scope(p_p0: &Ps, name_p1: &crate::syntax::SName) -> Ps {
    let b_p2 = or(&crate::syntax::lexer::chars::last(&name_p1.path_), &Text::lit(""));
    let sized_p3 = fold(&Array::from(vec![Text::lit("U16"), Text::lit("U32"), Text::lit("U64"), Text::lit("U128"), Text::lit("I8"), Text::lit("I16"), Text::lit("I32"), Text::lit("I64"), Text::lit("I128")]), &false, &(|seen_p4: &bool, s_p5: &Text| *seen_p4 || (s_p5 == &b_p2)));
    if &len(&name_p1.path_) != &Nat::from(1u32) {
        p_p0.clone()
    } else {
        if sized_p3 {
            out_of_scope(p_p0, &name_p1.span, &Text::lit("sized ints other than `U8`"), &Text::from(format!("`{}` is out of this compiler: the sized integer it has is `U8`", &b_p2)))
        } else {
            if &b_p2 == &Text::lit("Instant") {
                out_of_scope(p_p0, &name_p1.span, &Text::lit("`Instant`"), &Text::lit("`Instant` is out of this compiler"))
            } else {
                p_p0.clone()
            }
        }
    }
}
