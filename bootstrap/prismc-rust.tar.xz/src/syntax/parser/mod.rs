//! The module `Syntax.Parser`, from `target/bootstrap/src/prismc/syntax/parser/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (docs/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `ArgsRead`:
///
/// ```prism
/// type ArgsRead = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ArgsRead {
    pub args: Array<crate::syntax::Arg>,
    pub rest: bool,
    pub p_: Ps,
    pub going: bool,
}

impl Show for ArgsRead {
    fn show(&self, p: &mut Printer) {
        p.record("ArgsRead", &[("args", &self.args), ("rest", &self.rest), ("p", &self.p_), ("going", &self.going)]);
    }
}

impl ToPod for ArgsRead {
    fn to_pod(&self) -> Pod {
        Pod::record("ArgsRead", vec![("args", self.args.to_pod()), ("rest", self.rest.to_pod()), ("p", self.p_.to_pod()), ("going", self.going.to_pod())])
    }
}

impl FromPod for ArgsRead {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ArgsRead { args: FromPod::from_pod(field(p, "args")?)?, rest: FromPod::from_pod(field(p, "rest")?)?, p_: FromPod::from_pod(field(p, "p")?)?, going: FromPod::from_pod(field(p, "going")?)? })
    }
}

/// `Climb`:
///
/// ```prism
/// type Climb = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Climb {
    pub lhs: crate::syntax::Expr,
    pub p_: Ps,
    pub going: bool,
}

impl Show for Climb {
    fn show(&self, p: &mut Printer) {
        p.record("Climb", &[("lhs", &self.lhs), ("p", &self.p_), ("going", &self.going)]);
    }
}

impl ToPod for Climb {
    fn to_pod(&self) -> Pod {
        Pod::record("Climb", vec![("lhs", self.lhs.to_pod()), ("p", self.p_.to_pod()), ("going", self.going.to_pod())])
    }
}

impl FromPod for Climb {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Climb { lhs: FromPod::from_pod(field(p, "lhs")?)?, p_: FromPod::from_pod(field(p, "p")?)?, going: FromPod::from_pod(field(p, "going")?)? })
    }
}

/// `FieldsRead`:
///
/// ```prism
/// type FieldsRead = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct FieldsRead {
    pub fields: Array<crate::syntax::FieldPat>,
    pub rest: bool,
    pub p_: Ps,
    pub going: bool,
}

impl Show for FieldsRead {
    fn show(&self, p: &mut Printer) {
        p.record("FieldsRead", &[("fields", &self.fields), ("rest", &self.rest), ("p", &self.p_), ("going", &self.going)]);
    }
}

impl ToPod for FieldsRead {
    fn to_pod(&self) -> Pod {
        Pod::record("FieldsRead", vec![("fields", self.fields.to_pod()), ("rest", self.rest.to_pod()), ("p", self.p_.to_pod()), ("going", self.going.to_pod())])
    }
}

impl FromPod for FieldsRead {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(FieldsRead { fields: FromPod::from_pod(field(p, "fields")?)?, rest: FromPod::from_pod(field(p, "rest")?)?, p_: FromPod::from_pod(field(p, "p")?)?, going: FromPod::from_pod(field(p, "going")?)? })
    }
}

/// `ModRead`:
///
/// ```prism
/// type ModRead = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ModRead {
    pub p_: Ps,
    pub m: crate::syntax::Module,
    pub stage: Nat,
}

impl Show for ModRead {
    fn show(&self, p: &mut Printer) {
        p.record("ModRead", &[("p", &self.p_), ("m", &self.m), ("stage", &self.stage)]);
    }
}

impl ToPod for ModRead {
    fn to_pod(&self) -> Pod {
        Pod::record("ModRead", vec![("p", self.p_.to_pod()), ("m", self.m.to_pod()), ("stage", self.stage.to_pod())])
    }
}

impl FromPod for ModRead {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ModRead { p_: FromPod::from_pod(field(p, "p")?)?, m: FromPod::from_pod(field(p, "m")?)?, stage: FromPod::from_pod(field(p, "stage")?)? })
    }
}

/// `Pair`:
///
/// ```prism
/// type Pair = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Pair {
    pub partner: Option<Nat>,
    pub outer: bool,
    pub inner: bool,
}

impl Show for Pair {
    fn show(&self, p: &mut Printer) {
        p.record("Pair", &[("partner", &self.partner), ("outer", &self.outer), ("inner", &self.inner)]);
    }
}

impl ToPod for Pair {
    fn to_pod(&self) -> Pod {
        Pod::record("Pair", vec![("partner", self.partner.to_pod()), ("outer", self.outer.to_pod()), ("inner", self.inner.to_pod())])
    }
}

impl FromPod for Pair {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Pair { partner: FromPod::from_pod(field(p, "partner")?)?, outer: FromPod::from_pod(field(p, "outer")?)?, inner: FromPod::from_pod(field(p, "inner")?)? })
    }
}

/// `Parsed`:
///
/// ```prism
/// type Parsed = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Parsed {
    pub tree: crate::syntax::Module,
    pub diags: Array<crate::syntax::Diag>,
}

impl Show for Parsed {
    fn show(&self, p: &mut Printer) {
        p.record("Parsed", &[("tree", &self.tree), ("diags", &self.diags)]);
    }
}

impl ToPod for Parsed {
    fn to_pod(&self) -> Pod {
        Pod::record("Parsed", vec![("tree", self.tree.to_pod()), ("diags", self.diags.to_pod())])
    }
}

impl FromPod for Parsed {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Parsed { tree: FromPod::from_pod(field(p, "tree")?)?, diags: FromPod::from_pod(field(p, "diags")?)? })
    }
}

/// `Ps`:
///
/// ```prism
/// type Ps = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Ps {
    pub toks: Array<crate::syntax::lexer::Tok>,
    pub pairs: Array<Pair>,
    pub pos: Nat,
    pub diags: Array<crate::syntax::Diag>,
    pub out: Array<crate::syntax::Diag>,
    pub step_mode: bool,
    pub in_trait: bool,
    pub bad: bool,
}

impl Show for Ps {
    fn show(&self, p: &mut Printer) {
        p.record("Ps", &[("toks", &self.toks), ("pairs", &self.pairs), ("pos", &self.pos), ("diags", &self.diags), ("out", &self.out), ("step_mode", &self.step_mode), ("in_trait", &self.in_trait), ("bad", &self.bad)]);
    }
}

impl ToPod for Ps {
    fn to_pod(&self) -> Pod {
        Pod::record("Ps", vec![("toks", self.toks.to_pod()), ("pairs", self.pairs.to_pod()), ("pos", self.pos.to_pod()), ("diags", self.diags.to_pod()), ("out", self.out.to_pod()), ("step_mode", self.step_mode.to_pod()), ("in_trait", self.in_trait.to_pod()), ("bad", self.bad.to_pod())])
    }
}

impl FromPod for Ps {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Ps { toks: FromPod::from_pod(field(p, "toks")?)?, pairs: FromPod::from_pod(field(p, "pairs")?)?, pos: FromPod::from_pod(field(p, "pos")?)?, diags: FromPod::from_pod(field(p, "diags")?)?, out: FromPod::from_pod(field(p, "out")?)?, step_mode: FromPod::from_pod(field(p, "step_mode")?)?, in_trait: FromPod::from_pod(field(p, "in_trait")?)?, bad: FromPod::from_pod(field(p, "bad")?)? })
    }
}

/// ```prism
/// let noRange
/// ```
pub fn no_range() -> crate::syntax::Range {
    crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) }
}

/// ```prism
/// let eofTok
/// ```
pub fn eof_tok() -> crate::syntax::lexer::Tok {
    crate::syntax::lexer::Tok { kind: crate::syntax::lexer::TokKind::KEof, span: no_range(), touches: false, line_start: false }
}

/// ```prism
/// let noPair
/// ```
pub fn no_pair() -> Pair {
    Pair { partner: None, outer: false, inner: false }
}

/// ```prism
/// ParseFile: unbounded fn Text -> Parsed
/// ```
pub fn parse_file(src: &Text) -> Parsed {
    let lexed = crate::syntax::lexer::lex_file(src);
    let (m, p_) = parse_module(&new_ps(&lexed.tokens), &false);
    Parsed { tree: m.clone(), diags: finish_diags(&append(&append(&lexed.diags, &p_.diags), &p_.out)) }
}

/// The step machine of `ParseFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseFile: unbounded fn Text -> Parsed
/// ```
pub struct ParseFile {
    pub src: Text,
}

impl prism_rtl::Job<Parsed> for ParseFile {
    fn cycle(&self) -> prism_rtl::Turn<Parsed> {
        let src = &self.src;
        let src = src.clone();
        call_then(crate::syntax::lexer::start_lex_file(src.clone()), move |lex_file_3073: crate::syntax::lexer::Lexed| {
            let lexed = lex_file_3073;
            call_then(start_new_ps(lexed.tokens.clone()), move |new_ps_3117: Ps| call_then(start_parse_module(new_ps_3117, false), move |parse_module_3104: (crate::syntax::Module, Ps)| {
                let (m, p_) = parse_module_3104;
                prism_rtl::Turn::Finished(Parsed { tree: m.clone(), diags: finish_diags(&append(&append(&lexed.diags, &p_.diags), &p_.out)) })
            }))
        })
    }
}

/// `Start ParseFile, x`: what the function value is when passed to `@Run`.
pub fn start_parse_file(src: Text) -> Rc<dyn prism_rtl::Job<Parsed>> {
    Rc::new(ParseFile { src })
}

/// ```prism
/// ParseFragment: unbounded fn Text -> Parsed
/// ```
pub fn parse_fragment(src: &Text) -> Parsed {
    let lexed = crate::syntax::lexer::lex_file(src);
    let (m, p_) = parse_module(&new_ps(&lexed.tokens), &true);
    Parsed { tree: m.clone(), diags: finish_diags(&append(&append(&lexed.diags, &p_.diags), &p_.out)) }
}

/// The step machine of `ParseFragment`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseFragment: unbounded fn Text -> Parsed
/// ```
pub struct ParseFragment {
    pub src: Text,
}

impl prism_rtl::Job<Parsed> for ParseFragment {
    fn cycle(&self) -> prism_rtl::Turn<Parsed> {
        let src = &self.src;
        let src = src.clone();
        call_then(crate::syntax::lexer::start_lex_file(src.clone()), move |lex_file_3466: crate::syntax::lexer::Lexed| {
            let lexed = lex_file_3466;
            call_then(start_new_ps(lexed.tokens.clone()), move |new_ps_3510: Ps| call_then(start_parse_module(new_ps_3510, true), move |parse_module_3497: (crate::syntax::Module, Ps)| {
                let (m, p_) = parse_module_3497;
                prism_rtl::Turn::Finished(Parsed { tree: m.clone(), diags: finish_diags(&append(&append(&lexed.diags, &p_.diags), &p_.out)) })
            }))
        })
    }
}

/// `Start ParseFragment, x`: what the function value is when passed to `@Run`.
pub fn start_parse_fragment(src: Text) -> Rc<dyn prism_rtl::Job<Parsed>> {
    Rc::new(ParseFragment { src })
}

/// ```prism
/// NewPs: unbounded fn [Tok] -> Ps
/// ```
pub fn new_ps(toks0: &Array<crate::syntax::lexer::Tok>) -> Ps {
    let ends = match crate::syntax::lexer::last(toks0) {
        Some(t) => &t.kind == &crate::syntax::lexer::TokKind::KEof,
        None => false,
    };
    let end = match crate::syntax::lexer::last(toks0) {
        Some(t) => crate::syntax::Range { start: t.span.end.clone(), end: t.span.end.clone() },
        None => no_range(),
    };
    let toks = if ends {
        toks0.clone()
    } else {
        push(toks0, &crate::syntax::lexer::Tok { kind: crate::syntax::lexer::TokKind::KEof, span: end.clone(), touches: false, line_start: false })
    };
    Ps { toks: toks.clone(), pairs: pair_brackets(&toks), pos: Nat::from(0u32), diags: Array::new(), out: Array::new(), step_mode: false, in_trait: false, bad: false }
}

/// The step machine of `NewPs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NewPs: unbounded fn [Tok] -> Ps
/// ```
pub struct NewPs {
    pub toks0: Array<crate::syntax::lexer::Tok>,
}

impl prism_rtl::Job<Ps> for NewPs {
    fn cycle(&self) -> prism_rtl::Turn<Ps> {
        let toks0 = &self.toks0;
        let ends = match crate::syntax::lexer::last(toks0) {
            Some(t) => &t.kind == &crate::syntax::lexer::TokKind::KEof,
            None => false,
        };
        let end = match crate::syntax::lexer::last(toks0) {
            Some(t) => crate::syntax::Range { start: t.span.end.clone(), end: t.span.end.clone() },
            None => no_range(),
        };
        let toks = if ends {
            toks0.clone()
        } else {
            push(toks0, &crate::syntax::lexer::Tok { kind: crate::syntax::lexer::TokKind::KEof, span: end.clone(), touches: false, line_start: false })
        };
        call_then(start_pair_brackets(toks.clone()), move |pair_brackets_3989: Array<Pair>| prism_rtl::Turn::Finished(Ps { toks: toks.clone(), pairs: pair_brackets_3989, pos: Nat::from(0u32), diags: Array::new(), out: Array::new(), step_mode: false, in_trait: false, bad: false }))
    }
}

/// `Start NewPs, x`: what the function value is when passed to `@Run`.
pub fn start_new_ps(toks0: Array<crate::syntax::lexer::Tok>) -> Rc<dyn prism_rtl::Job<Ps>> {
    Rc::new(NewPs { toks0 })
}

/// ```prism
/// Sub: unbounded fn Ps, [Tok], Range -> Ps
/// ```
pub fn sub(p_: &Ps, toks: &Array<crate::syntax::lexer::Tok>, end: &crate::syntax::Range) -> Ps {
    let q = new_ps(&push(toks, &crate::syntax::lexer::Tok { kind: crate::syntax::lexer::TokKind::KEof, span: end.clone(), touches: false, line_start: false }));
    let mut this: Ps = q.clone();
    this.step_mode = p_.step_mode;
    this
}

/// The step machine of `Sub`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Sub: unbounded fn Ps, [Tok], Range -> Ps
/// ```
pub struct Sub {
    pub p_: Ps,
    pub toks: Array<crate::syntax::lexer::Tok>,
    pub end: crate::syntax::Range,
}

impl prism_rtl::Job<Ps> for Sub {
    fn cycle(&self) -> prism_rtl::Turn<Ps> {
        let p_ = &self.p_;
        let toks = &self.toks;
        let end = &self.end;
        let end = end.clone();
        let p_ = p_.clone();
        let toks = toks.clone();
        call_then(start_new_ps(push(&toks, &crate::syntax::lexer::Tok { kind: crate::syntax::lexer::TokKind::KEof, span: end.clone(), touches: false, line_start: false })), move |new_ps_4298: Ps| {
            let q = new_ps_4298;
            prism_rtl::Turn::Finished({
                let mut this: Ps = q.clone();
                this.step_mode = p_.step_mode;
                this
            })
        })
    }
}

/// `Start Sub, x`: what the function value is when passed to `@Run`.
pub fn start_sub(p_: Ps, toks: Array<crate::syntax::lexer::Tok>, end: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<Ps>> {
    Rc::new(Sub { p_, toks, end })
}

/// ```prism
/// Absorb: fn Ps, Ps -> Ps
/// ```
pub fn absorb(p_: &Ps, sub_: &Ps) -> Ps {
    let mut this: Ps = p_.clone();
    this.diags = append(&this.diags, &sub_.diags);
    this.out = append(&this.out, &sub_.out);
    this
}

/// ```prism
/// FinishDiags: fn [Diag] -> [Diag]
/// ```
pub fn finish_diags(ds: &Array<crate::syntax::Diag>) -> Array<crate::syntax::Diag> {
    let sorted = fold(ds, &Array::new(), &insert_diag);
    fold(&sorted, &Array::new(), &(|acc: &Array<crate::syntax::Diag>, d: &crate::syntax::Diag| match crate::syntax::lexer::last(acc) {
        Some(e) if ((&e.span == &d.span) && (&e.message == &d.message)) => acc.clone(),
        _ => push(acc, d),
        _ => unreachable!("no arm matched"),
    }))
}

/// ```prism
/// StageRank: fn Text -> Nat
/// ```
pub fn stage_rank(text0: &Text) -> Nat {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("lex")) => Nat::from(0u32),
        c1_0 if (c1_0 == &Text::lit("parse")) => Nat::from(1u32),
        _ => Nat::from(2u32),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// DiagBefore: fn Diag, Diag -> Bool
/// ```
pub fn diag_before(a: &crate::syntax::Diag, b: &crate::syntax::Diag) -> bool {
    (&a.span.start < &b.span.start) || ((&a.span.start == &b.span.start) && (&stage_rank(&a.stage) < &stage_rank(&b.stage)))
}

/// ```prism
/// InsertDiag: fn [Diag], Diag -> [Diag]
/// ```
pub fn insert_diag(sorted: &Array<crate::syntax::Diag>, d: &crate::syntax::Diag) -> Array<crate::syntax::Diag> {
    let before_ = fold(sorted, &Array::new(), &(|acc: &Array<crate::syntax::Diag>, e: &crate::syntax::Diag| if diag_before(d, e) { acc.clone() } else { push(acc, e) }));
    let after_ = fold(sorted, &Array::new(), &(|acc: &Array<crate::syntax::Diag>, e: &crate::syntax::Diag| if diag_before(d, e) { push(acc, e) } else { acc.clone() }));
    append(&push(&before_, d), &after_)
}

/// ```prism
/// PairBrackets: unbounded fn [Tok] -> [Pair]
/// ```
pub fn pair_brackets(toks: &Array<crate::syntax::lexer::Tok>) -> Array<Pair> {
    let mut this: Array<Pair> = each(toks, &(|t: &crate::syntax::lexer::Tok| no_pair()));
    let mut stack: Array<(Nat, Text)> = Array::new();
    for (i6050, v6050) in toks.clone().into_iter().enumerate() {
        let k6050 = nat_of(i6050);
        let t = v6050.clone();
        if let Some(k) = open_kind_of(&t.kind) {
            stack = push(&stack, &(k6050.clone(), k.clone()));
        }
        if let Some(k) = close_kind_of(&t.kind) {
            if let Some((j, k2)) = crate::syntax::lexer::last(&stack) {
                if &k2 == &k {
                    stack = crate::syntax::lexer::pop(&stack);
                    (*at_mut(&mut this, &k6050)).partner = Some(j.clone());
                    (*at_mut(&mut this, &j)).partner = Some(k6050.clone());
                }
            }
        }
    }
    for (i6511, v6511) in toks.clone().into_iter().enumerate() {
        let k6511 = nat_of(i6511);
        let t = v6511.clone();
        let i = k6511.clone();
        if let Some(kind_) = open_kind_of(&t.kind) {
            if (&kind_ != &Text::lit("{")) && !or(&index(&this, &i), &no_pair()).inner {
                if let Some(j) = or(&index(&this, &i), &no_pair()).partner.clone() {
                    if double_at(&this, toks, &i, &j, &kind_) {
                        (*at_mut(&mut this, &i)).outer = true;
                        (*at_mut(&mut this, &j)).outer = true;
                        (*at_mut(&mut this, &(&i + &Nat::from(1u32)))).inner = true;
                        (*at_mut(&mut this, &crate::syntax::lexer::dec(&j))).inner = true;
                    }
                }
            }
        }
    }
    this
}

/// The step machine of `PairBrackets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PairBrackets: unbounded fn [Tok] -> [Pair]
/// ```
pub struct PairBrackets {
    pub toks: Array<crate::syntax::lexer::Tok>,
}

impl prism_rtl::Job<Array<Pair>> for PairBrackets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Pair>> {
        let toks = &self.toks;
        prism_rtl::Turn::Finished({
            let mut this: Array<Pair> = each(toks, &(|t: &crate::syntax::lexer::Tok| no_pair()));
            let mut stack: Array<(Nat, Text)> = Array::new();
            for (i6050, v6050) in toks.clone().into_iter().enumerate() {
                let k6050 = nat_of(i6050);
                let t = v6050.clone();
                if let Some(k) = open_kind_of(&t.kind) {
                    stack = push(&stack, &(k6050.clone(), k.clone()));
                }
                if let Some(k) = close_kind_of(&t.kind) {
                    if let Some((j, k2)) = crate::syntax::lexer::last(&stack) {
                        if &k2 == &k {
                            stack = crate::syntax::lexer::pop(&stack);
                            (*at_mut(&mut this, &k6050)).partner = Some(j.clone());
                            (*at_mut(&mut this, &j)).partner = Some(k6050.clone());
                        }
                    }
                }
            }
            for (i6511, v6511) in toks.clone().into_iter().enumerate() {
                let k6511 = nat_of(i6511);
                let t = v6511.clone();
                let i = k6511.clone();
                if let Some(kind_) = open_kind_of(&t.kind) {
                    if (&kind_ != &Text::lit("{")) && !or(&index(&this, &i), &no_pair()).inner {
                        if let Some(j) = or(&index(&this, &i), &no_pair()).partner.clone() {
                            if double_at(&this, toks, &i, &j, &kind_) {
                                (*at_mut(&mut this, &i)).outer = true;
                                (*at_mut(&mut this, &j)).outer = true;
                                (*at_mut(&mut this, &(&i + &Nat::from(1u32)))).inner = true;
                                (*at_mut(&mut this, &crate::syntax::lexer::dec(&j))).inner = true;
                            }
                        }
                    }
                }
            }
            this
        })
    }
}

/// `Start PairBrackets, x`: what the function value is when passed to `@Run`.
pub fn start_pair_brackets(toks: Array<crate::syntax::lexer::Tok>) -> Rc<dyn prism_rtl::Job<Array<Pair>>> {
    Rc::new(PairBrackets { toks })
}

/// ```prism
/// DoubleAt: fn [Pair], [Tok], Nat, Nat, Text -> Bool
/// ```
pub fn double_at(pairs: &Array<Pair>, toks: &Array<crate::syntax::lexer::Tok>, i: &Nat, j: &Nat, kind_: &Text) -> bool {
    let next = or(&index(toks, &(i + &Nat::from(1u32))), &eof_tok());
    let inner_close_opt = or(&index(pairs, &(i + &Nat::from(1u32))), &no_pair()).partner.clone();
    ((is_open_of(&next.kind, kind_) && next.touches) && (&inner_close_opt == &Some(crate::syntax::lexer::dec(j)))) && or(&index(toks, j), &eof_tok()).touches
}

/// ```prism
/// ?OpenKindOf: fn TokKind -> ?Text
/// ```
pub fn open_kind_of(tok_kind0: &crate::syntax::lexer::TokKind) -> Option<Text> {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KOpen(k, _) => Some(k.clone()),
        _ => None,
    }
}

/// ```prism
/// ?CloseKindOf: fn TokKind -> ?Text
/// ```
pub fn close_kind_of(tok_kind0: &crate::syntax::lexer::TokKind) -> Option<Text> {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KClose(k) => Some(k.clone()),
        _ => None,
    }
}

/// ```prism
/// IsOpenOf: fn TokKind, Text -> Bool
/// ```
pub fn is_open_of(tok_kind0: &crate::syntax::lexer::TokKind, text1: &Text) -> bool {
    match (tok_kind0, text1) {
        (crate::syntax::lexer::TokKind::KOpen(k, _), kind_) => k == kind_,
        (_, _) => false,
    }
}

/// ```prism
/// Tk: fn Ps -> Tok
/// ```
pub fn tk(p_: &Ps) -> crate::syntax::lexer::Tok {
    if p_.bad {
        eof_tok()
    } else {
        or(&index(&p_.toks, &min(&p_.pos, &crate::syntax::lexer::dec(&len(&p_.toks)))), &eof_tok())
    }
}

/// ```prism
/// TkAt: fn Ps, Nat -> Tok
/// ```
pub fn tk_at(p_: &Ps, n: &Nat) -> crate::syntax::lexer::Tok {
    if p_.bad {
        eof_tok()
    } else {
        or(&index(&p_.toks, &min(&(&p_.pos + n), &crate::syntax::lexer::dec(&len(&p_.toks)))), &eof_tok())
    }
}

/// ```prism
/// Kind: fn Ps -> TokKind
/// ```
pub fn kind(p_: &Ps) -> crate::syntax::lexer::TokKind {
    tk(p_).kind.clone()
}

/// ```prism
/// KindAt: fn Ps, Nat -> TokKind
/// ```
pub fn kind_at(p_: &Ps, n: &Nat) -> crate::syntax::lexer::TokKind {
    tk_at(p_, n).kind.clone()
}

/// ```prism
/// Here: fn Ps -> Range
/// ```
pub fn here(p_: &Ps) -> crate::syntax::Range {
    tk(p_).span.clone()
}

/// ```prism
/// Prev: fn Ps -> Range
/// ```
pub fn prev(p_: &Ps) -> crate::syntax::Range {
    or(&index(&p_.toks, &crate::syntax::lexer::dec(&p_.pos)), &eof_tok()).span.clone()
}

/// ```prism
/// To: fn Range, Range -> Range
/// ```
pub fn to(a: &crate::syntax::Range, b: &crate::syntax::Range) -> crate::syntax::Range {
    crate::syntax::Range { start: min(&a.start, &b.start), end: max(&a.end, &b.end) }
}

/// ```prism
/// AtEnd: fn Range -> Range
/// ```
pub fn at_end(r: &crate::syntax::Range) -> crate::syntax::Range {
    crate::syntax::Range { start: r.end.clone(), end: r.end.clone() }
}

/// ```prism
/// Adv: fn Ps -> Ps
/// ```
pub fn adv(p_: &Ps) -> Ps {
    if p_.bad || (&(&p_.pos + &Nat::from(1u32)) >= &len(&p_.toks)) {
        p_.clone()
    } else {
        {
            let mut this: Ps = p_.clone();
            this.pos = &this.pos + &Nat::from(1u32);
            this
        }
    }
}

/// ```prism
/// PairAt: fn Ps -> Pair
/// ```
pub fn pair_at(p_: &Ps) -> Pair {
    or(&index(&p_.pairs, &min(&p_.pos, &crate::syntax::lexer::dec(&len(&p_.pairs)))), &no_pair())
}

/// ```prism
/// AtEof: fn Ps -> Bool
/// ```
pub fn at_eof(p_: &Ps) -> bool {
    &kind(p_) == &crate::syntax::lexer::TokKind::KEof
}

/// ```prism
/// AtKw: fn Ps, Text -> Bool
/// ```
pub fn at_kw(p_: &Ps, w: &Text) -> bool {
    &kind(p_) == &crate::syntax::lexer::TokKind::KKw(w.clone(), Text::lit(""))
}

/// ```prism
/// AtOp: fn Ps, Text -> Bool
/// ```
pub fn at_op(p_: &Ps, op: &Text) -> bool {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KOp(o, _) => &o == op,
        _ => false,
    }
}

/// ```prism
/// AtSep: fn Ps -> Bool
/// ```
pub fn at_sep(p_: &Ps) -> bool {
    &kind(p_) == &crate::syntax::lexer::TokKind::KLaySep
}

/// ```prism
/// AtOpenL: fn Ps -> Bool
/// ```
pub fn at_open_l(p_: &Ps) -> bool {
    &kind(p_) == &crate::syntax::lexer::TokKind::KLayOpen
}

/// ```prism
/// AtCloseL: fn Ps -> Bool
/// ```
pub fn at_close_l(p_: &Ps) -> bool {
    &kind(p_) == &crate::syntax::lexer::TokKind::KLayClose
}

/// ```prism
/// AtComma: fn Ps -> Bool
/// ```
pub fn at_comma(p_: &Ps) -> bool {
    &kind(p_) == &crate::syntax::lexer::TokKind::KComma
}

/// ```prism
/// AtColon: fn Ps -> Bool
/// ```
pub fn at_colon(p_: &Ps) -> bool {
    &kind(p_) == &crate::syntax::lexer::TokKind::KColon
}

/// ```prism
/// IsOpenKind: fn TokKind, Text -> Bool
/// ```
pub fn is_open_kind(tok_kind0: &crate::syntax::lexer::TokKind, text1: &Text) -> bool {
    match (tok_kind0, text1) {
        (crate::syntax::lexer::TokKind::KOpen(k, _), kind_) => k == kind_,
        (_, _) => false,
    }
}

/// ```prism
/// AtDoubleOpen: fn Ps, Text -> Bool
/// ```
pub fn at_double_open(p_: &Ps, kind_: &Text) -> bool {
    is_open_kind(&kind(p_), kind_) && pair_at(p_).outer
}

/// ```prism
/// AtSingleOpen: fn Ps, Text -> Bool
/// ```
pub fn at_single_open(p_: &Ps, kind_: &Text) -> bool {
    is_open_kind(&kind(p_), kind_) && !pair_at(p_).outer
}

/// ```prism
/// AtClose: fn Ps, Text -> Bool
/// ```
pub fn at_close(p_: &Ps, kind_: &Text) -> bool {
    &kind(p_) == &crate::syntax::lexer::TokKind::KClose(kind_.clone())
}

/// ```prism
/// OpenDouble: fn Ps -> Ps
/// ```
pub fn open_double(p_: &Ps) -> Ps {
    adv(&adv(p_))
}

/// ```prism
/// CloseDouble: fn Ps, Text -> Ps
/// ```
pub fn close_double(p_: &Ps, kind_: &Text) -> Ps {
    let c = crate::syntax::lexer::close_char(kind_);
    let p1 = adv(p_);
    if ((at_close(p_, kind_) && pair_at(p_).inner) && at_close(&p1, kind_)) && pair_at(&p1).outer {
        adv(&p1)
    } else {
        if at_close(p_, kind_) && pair_at(p_).inner {
            error_here(&p1, &Text::from(format!("expected `{}{}` to close the double bracket", &c, &c)))
        } else {
            error_here(p_, &Text::from(format!("expected `{}{}` to close the double bracket", &c, &c)))
        }
    }
}

/// ```prism
/// ExpectClose: fn Ps, Text -> Ps
/// ```
pub fn expect_close(p_: &Ps, kind_: &Text) -> Ps {
    if at_close(p_, kind_) {
        adv(p_)
    } else {
        error_here(p_, &Text::from(format!("expected `{}`", &crate::syntax::lexer::close_char(kind_))))
    }
}

/// ```prism
/// ParseDiag: fn Range, Text -> Diag
/// ```
pub fn parse_diag(span: &crate::syntax::Range, message: &Text) -> crate::syntax::Diag {
    crate::syntax::Diag { stage: Text::lit("parse"), span: span.clone(), message: message.clone(), feature: None }
}

/// ```prism
/// ErrorAt: fn Ps, Range, Text -> Ps
/// ```
pub fn error_at(p_: &Ps, span: &crate::syntax::Range, message: &Text) -> Ps {
    if p_.bad {
        p_.clone()
    } else {
        {
            let mut this: Ps = p_.clone();
            this.diags = push(&this.diags, &parse_diag(span, message));
            this.bad = true;
            this
        }
    }
}

/// ```prism
/// ErrorHere: fn Ps, Text -> Ps
/// ```
pub fn error_here(p_: &Ps, message: &Text) -> Ps {
    error_at(p_, &here(p_), &Text::from(format!("{}, found {}", message, &describe(&kind(p_)))))
}

/// ```prism
/// Fail: fn Ps -> Ps
/// ```
pub fn fail(p_: &Ps) -> Ps {
    let mut this: Ps = p_.clone();
    this.bad = true;
    this
}

/// ```prism
/// Unbad: fn Ps -> Ps
/// ```
pub fn unbad(p_: &Ps) -> Ps {
    let mut this: Ps = p_.clone();
    this.bad = false;
    this
}

/// ```prism
/// NoteError: fn Ps, Range, Text -> Ps
/// ```
pub fn note_error(p_: &Ps, span: &crate::syntax::Range, message: &Text) -> Ps {
    if p_.bad {
        p_.clone()
    } else {
        {
            let mut this: Ps = p_.clone();
            this.diags = push(&this.diags, &parse_diag(span, message));
            this
        }
    }
}

/// ```prism
/// Complain: fn Ps, Text -> Ps
/// ```
pub fn complain(p_: &Ps, message: &Text) -> Ps {
    unbad(&error_here(p_, message))
}

/// ```prism
/// OutOfScope: fn Ps, Range, Text, Text -> Ps
/// ```
pub fn out_of_scope(p_: &Ps, span: &crate::syntax::Range, feature: &Text, message: &Text) -> Ps {
    if p_.bad {
        p_.clone()
    } else {
        {
            let mut this: Ps = p_.clone();
            this.out = push(&this.out, &crate::syntax::Diag { stage: Text::lit("out"), span: span.clone(), message: message.clone(), feature: Some(feature.clone()) });
            this
        }
    }
}

/// ```prism
/// ExpectColon: fn Ps -> Ps
/// ```
pub fn expect_colon(p_: &Ps) -> Ps {
    if at_colon(p_) { adv(p_) } else { error_here(p_, &Text::lit("expected `:`")) }
}

/// ```prism
/// ExpectOp: fn Ps, Text -> Ps
/// ```
pub fn expect_op(p_: &Ps, op: &Text) -> Ps {
    if at_op(p_, op) {
        adv(p_)
    } else {
        error_here(p_, &Text::from(format!("expected `{}`", op)))
    }
}

/// ```prism
/// ExpectKw: fn Ps, Text -> Ps
/// ```
pub fn expect_kw(p_: &Ps, w: &Text) -> Ps {
    if at_kw(p_, w) {
        adv(p_)
    } else {
        error_here(p_, &Text::from(format!("expected `{}`", w)))
    }
}

/// ```prism
/// Recover: unbounded fn Ps -> Ps
/// ```
pub fn recover(p0: &Ps) -> Ps {
    let mut this: Ps = unbad(p0);
    let mut depth: Nat = Nat::from(0u32);
    let mut going: bool = true;
    while going {
        match &kind(&this) {
            crate::syntax::lexer::TokKind::KEof => {
                going = false;
                ()
            },
            crate::syntax::lexer::TokKind::KLayOpen => {
                depth = &depth + &Nat::from(1u32);
                this = adv(&this);
                ()
            },
            crate::syntax::lexer::TokKind::KLayClose => {
                if &depth == &Nat::from(0u32) {
                    going = false;
                } else {
                    depth = crate::syntax::lexer::dec(&depth);
                    this = adv(&this);
                }
                ()
            },
            crate::syntax::lexer::TokKind::KLaySep if (&depth == &Nat::from(0u32)) => {
                going = false;
                ()
            },
            _ => {
                this = adv(&this);
                ()
            },
            _ => unreachable!("no arm matched"),
        };
    }
    this
}

/// The step machine of `Recover`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Recover: unbounded fn Ps -> Ps
/// ```
pub struct Recover {
    pub p0: Ps,
}

impl prism_rtl::Job<Ps> for Recover {
    fn cycle(&self) -> prism_rtl::Turn<Ps> {
        let p0 = &self.p0;
        let mut this: Ps = unbad(p0);
        let mut depth: Nat = Nat::from(0u32);
        let mut going: bool = true;
        call_then(loop_job((this, depth, going), move |(mut this, mut depth, mut going): (Ps, Nat, bool)| if going {
            {
                match &kind(&this) {
                    crate::syntax::lexer::TokKind::KEof => {
                        going = false;
                        ()
                    },
                    crate::syntax::lexer::TokKind::KLayOpen => {
                        depth = &depth + &Nat::from(1u32);
                        this = adv(&this);
                        ()
                    },
                    crate::syntax::lexer::TokKind::KLayClose => {
                        if &depth == &Nat::from(0u32) {
                            going = false;
                        } else {
                            depth = crate::syntax::lexer::dec(&depth);
                            this = adv(&this);
                        }
                        ()
                    },
                    crate::syntax::lexer::TokKind::KLaySep if (&depth == &Nat::from(0u32)) => {
                        going = false;
                        ()
                    },
                    _ => {
                        this = adv(&this);
                        ()
                    },
                    _ => unreachable!("no arm matched"),
                };
                Ok((this, depth, going))
            }
        } else {
            Err((this, depth, going))
        }), move |(mut this, mut depth, mut going): (Ps, Nat, bool)| prism_rtl::Turn::Finished(this))
    }
}

/// `Start Recover, x`: what the function value is when passed to `@Run`.
pub fn start_recover(p0: Ps) -> Rc<dyn prism_rtl::Job<Ps>> {
    Rc::new(Recover { p0 })
}

/// ```prism
/// Recovered: unbounded fn Ps -> Ps
/// ```
pub fn recovered(p_: &Ps) -> Ps {
    if p_.bad { recover(p_) } else { p_.clone() }
}

/// The step machine of `Recovered`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Recovered: unbounded fn Ps -> Ps
/// ```
pub struct Recovered {
    pub p_: Ps,
}

impl prism_rtl::Job<Ps> for Recovered {
    fn cycle(&self) -> prism_rtl::Turn<Ps> {
        let p_ = &self.p_;
        if p_.bad {
            prism_rtl::Turn::More(Rc::new(Recover { p0: p_.clone() }))
        } else {
            prism_rtl::Turn::Finished(p_.clone())
        }
    }
}

/// `Start Recovered, x`: what the function value is when passed to `@Run`.
pub fn start_recovered(p_: Ps) -> Rc<dyn prism_rtl::Job<Ps>> {
    Rc::new(Recovered { p_ })
}

/// ```prism
/// AtStmtBoundary: fn Ps -> Bool
/// ```
pub fn at_stmt_boundary(p_: &Ps) -> bool {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KLaySep => true,
        crate::syntax::lexer::TokKind::KLayClose => true,
        crate::syntax::lexer::TokKind::KEof => true,
        _ => false,
    }
}

/// ```prism
/// ExpectStmtEnd: unbounded fn Ps, Text -> Ps
/// ```
pub fn expect_stmt_end(p_: &Ps, what: &Text) -> Ps {
    if at_stmt_boundary(p_) {
        p_.clone()
    } else {
        recover(&note_error(p_, &here(p_), &Text::from(format!("expected the end of the {}, found {}", what, &describe(&kind(p_))))))
    }
}

/// The step machine of `ExpectStmtEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExpectStmtEnd: unbounded fn Ps, Text -> Ps
/// ```
pub struct ExpectStmtEnd {
    pub p_: Ps,
    pub what: Text,
}

impl prism_rtl::Job<Ps> for ExpectStmtEnd {
    fn cycle(&self) -> prism_rtl::Turn<Ps> {
        let p_ = &self.p_;
        let what = &self.what;
        if at_stmt_boundary(p_) {
            prism_rtl::Turn::Finished(p_.clone())
        } else {
            prism_rtl::Turn::More(Rc::new(Recover { p0: note_error(p_, &here(p_), &Text::from(format!("expected the end of the {}, found {}", what, &describe(&kind(p_))))) }))
        }
    }
}

/// `Start ExpectStmtEnd, x`: what the function value is when passed to `@Run`.
pub fn start_expect_stmt_end(p_: Ps, what: Text) -> Rc<dyn prism_rtl::Job<Ps>> {
    Rc::new(ExpectStmtEnd { p_, what })
}

/// ```prism
/// Describe: fn TokKind -> Text
/// ```
pub fn describe(tok_kind0: &crate::syntax::lexer::TokKind) -> Text {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KLayOpen => Text::lit("an indented block"),
        crate::syntax::lexer::TokKind::KLaySep => Text::lit("the end of the line"),
        crate::syntax::lexer::TokKind::KLayClose => Text::lit("the end of the block"),
        crate::syntax::lexer::TokKind::KEof => Text::lit("the end of the input"),
        crate::syntax::lexer::TokKind::KText(_, _) => Text::lit("a text literal"),
        crate::syntax::lexer::TokKind::KTemplate(_) => Text::lit("a template"),
        k => Text::from(format!("`{}`", &crate::syntax::lexer::token_text(k))),
    }
}

/// ```prism
/// Bracketed: fn Ps, (fn Ps -> ((a, Ps))) -> ((a, Ps))
/// ```
pub fn bracketed<A: Clone + 'static>(p_: &Ps, f_fn: &Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>) -> (A, Ps) {
    let (v_, q) = run_to_end(f_fn(with_step_mode(p_, &false)));
    (v_.clone(), with_step_mode(&q, &p_.step_mode))
}

/// The step machine of `Bracketed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Bracketed: fn Ps, (fn Ps -> ((a, Ps))) -> ((a, Ps))
/// ```
pub struct Bracketed<A> {
    pub p_: Ps,
    pub f_fn: Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>,
}

impl<A: Clone + 'static> prism_rtl::Job<(A, Ps)> for Bracketed<A> {
    fn cycle(&self) -> prism_rtl::Turn<(A, Ps)> {
        let p_ = &self.p_;
        let f_fn = &self.f_fn;
        let f_fn = f_fn.clone();
        let p_ = p_.clone();
        call_value((&f_fn)(with_step_mode(&p_, &false)), move |f_13868: (A, Ps)| {
            let (v_, q) = f_13868;
            prism_rtl::Turn::Finished((v_.clone(), with_step_mode(&q, &p_.step_mode)))
        })
    }
}

/// `Start Bracketed, x`: what the function value is when passed to `@Run`.
pub fn start_bracketed<A: Clone + 'static>(p_: Ps, f_fn: Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>) -> Rc<dyn prism_rtl::Job<(A, Ps)>> {
    Rc::new(Bracketed { p_, f_fn })
}

/// ```prism
/// WithStepMode: fn Ps, Bool -> Ps
/// ```
pub fn with_step_mode(p_: &Ps, flag: &bool) -> Ps {
    let mut this: Ps = p_.clone();
    this.step_mode = *flag;
    this
}

/// ```prism
/// LayoutItems: unbounded fn Ps, (fn Ps -> ((a, Ps))) -> (([a], Ps))
/// ```
pub fn layout_items<A: Clone + 'static>(p0: &Ps, f_fn: &Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>) -> (Array<A>, Ps) {
    let mut this: (Array<A>, Ps) = (Array::new(), p0.clone());
    let mut items: Array<A> = Array::new();
    let mut p_: Ps = p0.clone();
    let mut going: bool = true;
    while going {
        let (item, q) = run_to_end(f_fn(p_.clone()));
        if !q.bad {
            items = push(&items, &item);
        }
        p_ = recovered(&q);
        match &kind(&p_) {
            crate::syntax::lexer::TokKind::KLaySep => {
                p_ = adv(&p_);
            }
            crate::syntax::lexer::TokKind::KLayClose => {
                p_ = adv(&p_);
                going = false;
            }
            crate::syntax::lexer::TokKind::KEof => {
                going = false;
            }
            _ => {
                p_ = recover(&complain(&p_, &Text::lit("expected the end of the line")));
            }
        }
    }
    this = (items.clone(), p_.clone());
    this
}

/// The step machine of `LayoutItems`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LayoutItems: unbounded fn Ps, (fn Ps -> ((a, Ps))) -> (([a], Ps))
/// ```
pub struct LayoutItems<A> {
    pub p0: Ps,
    pub f_fn: Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>,
}

impl<A: Clone + 'static> prism_rtl::Job<(Array<A>, Ps)> for LayoutItems<A> {
    fn cycle(&self) -> prism_rtl::Turn<(Array<A>, Ps)> {
        let p0 = &self.p0;
        let f_fn = &self.f_fn;
        let mut this: (Array<A>, Ps) = (Array::new(), p0.clone());
        let mut items: Array<A> = Array::new();
        let mut p_: Ps = p0.clone();
        let mut going: bool = true;
        let f_fn = f_fn.clone();
        call_then(loop_job((this, going, items, p_), {
            let f_fn = f_fn.clone();
            move |(mut this, mut going, mut items, mut p_): ((Array<A>, Ps), bool, Array<A>, Ps)| if going {
                {
                    let (item, q) = run_to_end((&f_fn)(p_.clone()));
                    if !q.bad {
                        items = push(&items, &item);
                    }
                    p_ = recovered(&q);
                    match &kind(&p_) {
                        crate::syntax::lexer::TokKind::KLaySep => {
                            p_ = adv(&p_);
                        }
                        crate::syntax::lexer::TokKind::KLayClose => {
                            p_ = adv(&p_);
                            going = false;
                        }
                        crate::syntax::lexer::TokKind::KEof => {
                            going = false;
                        }
                        _ => {
                            p_ = recover(&complain(&p_, &Text::lit("expected the end of the line")));
                        }
                    }
                    Ok((this, going, items, p_))
                }
            } else {
                Err((this, going, items, p_))
            }
        }), move |(mut this, mut going, mut items, mut p_): ((Array<A>, Ps), bool, Array<A>, Ps)| {
            this = (items.clone(), p_.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start LayoutItems, x`: what the function value is when passed to `@Run`.
pub fn start_layout_items<A: Clone + 'static>(p0: Ps, f_fn: Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>) -> Rc<dyn prism_rtl::Job<(Array<A>, Ps)>> {
    Rc::new(LayoutItems { p0, f_fn })
}

/// ```prism
/// Commas: unbounded fn Ps, (fn Ps -> ((a, Ps))) -> (([a], Ps))
/// ```
pub fn commas<A: Clone + 'static>(p0: &Ps, f_fn: &Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>) -> (Array<A>, Ps) {
    let mut this: (Array<A>, Ps) = (Array::new(), p0.clone());
    let (first_, p1) = run_to_end(f_fn(p0.clone()));
    let mut items: Array<A> = Array::from(vec![first_.clone()]);
    let mut p_: Ps = p1.clone();
    while at_comma(&p_) && !p_.bad {
        let (item, q) = run_to_end(f_fn(adv(&p_)));
        items = push(&items, &item);
        p_ = q.clone();
    }
    this = (items.clone(), p_.clone());
    this
}

/// The step machine of `Commas`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Commas: unbounded fn Ps, (fn Ps -> ((a, Ps))) -> (([a], Ps))
/// ```
pub struct Commas<A> {
    pub p0: Ps,
    pub f_fn: Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>,
}

impl<A: Clone + 'static> prism_rtl::Job<(Array<A>, Ps)> for Commas<A> {
    fn cycle(&self) -> prism_rtl::Turn<(Array<A>, Ps)> {
        let p0 = &self.p0;
        let f_fn = &self.f_fn;
        let mut this: (Array<A>, Ps) = (Array::new(), p0.clone());
        let (first_, p1) = run_to_end(f_fn(p0.clone()));
        let mut items: Array<A> = Array::from(vec![first_.clone()]);
        let mut p_: Ps = p1.clone();
        call_then(loop_job((this, items, p_), {
            let f_fn = f_fn.clone();
            move |(mut this, mut items, mut p_): ((Array<A>, Ps), Array<A>, Ps)| if at_comma(&p_) && !p_.bad {
                {
                    let (item, q) = run_to_end((&f_fn)(adv(&p_)));
                    items = push(&items, &item);
                    p_ = q.clone();
                    Ok((this, items, p_))
                }
            } else {
                Err((this, items, p_))
            }
        }), move |(mut this, mut items, mut p_): ((Array<A>, Ps), Array<A>, Ps)| {
            this = (items.clone(), p_.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start Commas, x`: what the function value is when passed to `@Run`.
pub fn start_commas<A: Clone + 'static>(p0: Ps, f_fn: Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>) -> Rc<dyn prism_rtl::Job<(Array<A>, Ps)>> {
    Rc::new(Commas { p0, f_fn })
}

/// ```prism
/// let noSName
/// ```
pub fn no_sname() -> crate::syntax::SName {
    crate::syntax::SName { sigils: Text::lit(""), path_: Array::new(), span: no_range() }
}

/// ```prism
/// let noIdent
/// ```
pub fn no_ident() -> crate::syntax::Ident {
    crate::syntax::Ident { name: Text::lit(""), span: no_range() }
}

/// ```prism
/// IsUpperName: fn SName -> Bool
/// ```
pub fn is_upper_name(n: &crate::syntax::SName) -> bool {
    crate::syntax::lexer::is_upper(&crate::syntax::lexer::head(&or(&crate::syntax::lexer::last(&n.path_), &Text::lit(""))))
}

/// ```prism
/// IsCallee: fn SName -> Bool
/// ```
pub fn is_callee(n: &crate::syntax::SName) -> bool {
    is_upper_name(n) || crate::syntax::lexer::is_reserved_ctor(&or(&crate::syntax::lexer::last(&n.path_), &Text::lit("")))
}

/// ```prism
/// IsTopic: fn SName -> Bool
/// ```
pub fn is_topic(n: &crate::syntax::SName) -> bool {
    &n.path_ == &Array::from(vec![Text::lit("_")])
}

/// ```prism
/// NameText: fn SName -> Text
/// ```
pub fn name_text(n: &crate::syntax::SName) -> Text {
    Text::from(format!("{}{}", &n.sigils, &crate::syntax::lexer::join(&n.path_, &Text::lit("."))))
}

/// ```prism
/// ParseSName: fn Ps -> ((SName, Ps))
/// ```
pub fn parse_sname(p_: &Ps) -> (crate::syntax::SName, Ps) {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KName(n) => (crate::syntax::SName { sigils: n.sigils.clone(), path_: n.path_.clone(), span: here(p_) }, adv(p_)),
        _ => (no_sname(), error_here(p_, &Text::lit("expected a name"))),
    }
}

/// ```prism
/// ParseIdent: fn Ps -> ((Ident, Ps))
/// ```
pub fn parse_ident(p_: &Ps) -> (crate::syntax::Ident, Ps) {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KName(n) if (((&n.sigils == &Text::lit("")) && (&len(&n.path_) == &Nat::from(1u32))) && (&n.case == &crate::syntax::lexer::NameCase::CaseLower)) => (crate::syntax::Ident { name: or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")), span: here(p_) }, adv(p_)),
        crate::syntax::lexer::TokKind::KKw(m16068_1_0, m16068_1_1) if (&m16068_1_0 == &Text::lit("key")) && (&m16068_1_1 == &Text::lit("")) => (crate::syntax::Ident { name: Text::lit("key"), span: here(p_) }, adv(p_)),
        _ => (no_ident(), error_here(p_, &Text::lit("expected a lowercase name"))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParseQualName: fn Ps -> ((QualName, Ps))
/// ```
pub fn parse_qual_name(p_: &Ps) -> (crate::syntax::QualName, Ps) {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KName(n) if ((&n.sigils == &Text::lit("")) && (&n.case == &crate::syntax::lexer::NameCase::CaseUpper)) => (crate::syntax::QualName { path_: n.path_.clone(), span: here(p_) }, adv(p_)),
        _ => (crate::syntax::QualName { path_: Array::new(), span: no_range() }, error_here(p_, &Text::lit("expected an uppercase name"))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParseTraitRef: fn Ps -> ((TraitRef, Ps))
/// ```
pub fn parse_trait_ref(p_: &Ps) -> (crate::syntax::TraitRef, Ps) {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KTrait(path_) => {
            let span = here(p_);
            let q = if &path_ == &Array::from(vec![Text::lit("Monad")]) {
                out_of_scope(p_, &span, &Text::lit("`T monad:` blocks and `^Monad`"), &Text::lit("`^Monad` is out of this compiler"))
            } else {
                p_.clone()
            };
            (crate::syntax::TraitRef { path_: path_.clone(), span: span.clone() }, adv(&q))
        },
        _ => (crate::syntax::TraitRef { path_: Array::new(), span: no_range() }, error_here(p_, &Text::lit("expected a trait, `^Name`"))),
    }
}

/// ```prism
/// CheckNameScope: fn Ps, SName -> Ps
/// ```
pub fn check_name_scope(p_: &Ps, name: &crate::syntax::SName) -> Ps {
    let text = name_text(name);
    let feature = match &text {
        m17231_0 if (m17231_0 == &Text::lit("!Align")) => Text::lit("`!Align`"),
        m17231_1 if (m17231_1 == &Text::lit("@Collect")) => Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"),
        m17231_2 if (m17231_2 == &Text::lit("@View")) => Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"),
        m17231_3 if (m17231_3 == &Text::lit("@Edit")) => Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"),
        m17231_4 if (m17231_4 == &Text::lit("@Translate")) => Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"),
        m17231_5 if (m17231_5 == &Text::lit("Over")) => Text::lit("named lenses `&Home` and `Over`"),
        _ => Text::lit(""),
        _ => unreachable!("no arm matched"),
    };
    if &feature == &Text::lit("") {
        p_.clone()
    } else {
        out_of_scope(p_, &name.span, &feature, &Text::from(format!("`{}` is out of this compiler", &text)))
    }
}

/// ```prism
/// CheckTypeNameScope: fn Ps, SName -> Ps
/// ```
pub fn check_type_name_scope(p_: &Ps, name: &crate::syntax::SName) -> Ps {
    let b = or(&crate::syntax::lexer::last(&name.path_), &Text::lit(""));
    let sized = fold(&Array::from(vec![Text::lit("U16"), Text::lit("U32"), Text::lit("U64"), Text::lit("U128"), Text::lit("I8"), Text::lit("I16"), Text::lit("I32"), Text::lit("I64"), Text::lit("I128")]), &false, &(|seen: &bool, s: &Text| *seen || (s == &b)));
    if &len(&name.path_) != &Nat::from(1u32) {
        p_.clone()
    } else {
        if sized {
            out_of_scope(p_, &name.span, &Text::lit("sized ints other than `U8`"), &Text::from(format!("`{}` is out of this compiler: the sized integer it has is `U8`", &b)))
        } else {
            if &b == &Text::lit("Instant") {
                out_of_scope(p_, &name.span, &Text::lit("`Instant`"), &Text::lit("`Instant` is out of this compiler"))
            } else {
                p_.clone()
            }
        }
    }
}

/// ```prism
/// ParseModule: unbounded fn Ps, Bool -> ((Module, Ps))
/// ```
pub fn parse_module(p0: &Ps, fragment: &bool) -> (crate::syntax::Module, Ps) {
    let start = here(p0);
    let (template_opt, p1) = match kind(p0) {
        crate::syntax::lexer::TokKind::KTemplate(t) => {
            let (tpl, q) = parse_template(&adv(p0), &t, &here(p0));
            (Some(tpl.clone()), q.clone())
        },
        _ => (None, p0.clone()),
    };
    let m0 = crate::syntax::Module { name: None, emit_row: None, mods: Array::new(), uses: Array::new(), decls: Array::new(), template: template_opt.clone(), span: start.clone() };
    let r = {
        let mut this: ModRead = ModRead { p_: p1.clone(), m: m0.clone(), stage: Nat::from(0u32) };
        while !at_eof(&this.p_) {
            this = module_item(&this, fragment);
        }
        this
    };
    let m = {
        let mut this: crate::syntax::Module = r.m.clone();
        this.span = to(&start, &prev(&r.p_));
        this
    };
    (m.clone(), r.p_.clone())
}

/// The step machine of `ParseModule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseModule: unbounded fn Ps, Bool -> ((Module, Ps))
/// ```
pub struct ParseModule {
    pub p0: Ps,
    pub fragment: bool,
}

impl prism_rtl::Job<(crate::syntax::Module, Ps)> for ParseModule {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Module, Ps)> {
        let p0 = &self.p0;
        let fragment = &self.fragment;
        let start = here(p0);
        let (template_opt, p1) = match kind(p0) {
            crate::syntax::lexer::TokKind::KTemplate(t) => {
                let (tpl, q) = parse_template(&adv(p0), &t, &here(p0));
                (Some(tpl.clone()), q.clone())
            },
            _ => (None, p0.clone()),
        };
        let m0 = crate::syntax::Module { name: None, emit_row: None, mods: Array::new(), uses: Array::new(), decls: Array::new(), template: template_opt.clone(), span: start.clone() };
        let mut this: ModRead = ModRead { p_: p1.clone(), m: m0.clone(), stage: Nat::from(0u32) };
        let start = start.clone();
        call_then(loop_job((this,), {
            let fragment = *fragment;
            move |(mut this,): (ModRead,)| if !at_eof(&this.p_) {
                {
                    this = module_item(&this, &fragment);
                    Ok((this,))
                }
            } else {
                Err((this,))
            }
        }), move |(mut this,): (ModRead,)| {
            let r = this;
            let m = {
                let mut this: crate::syntax::Module = r.m.clone();
                this.span = to(&start, &prev(&r.p_));
                this
            };
            prism_rtl::Turn::Finished((m.clone(), r.p_.clone()))
        })
    }
}

/// `Start ParseModule, x`: what the function value is when passed to `@Run`.
pub fn start_parse_module(p0: Ps, fragment: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Module, Ps)>> {
    Rc::new(ParseModule { p0, fragment })
}

/// ```prism
/// ModuleItem: unbounded fn ModRead, Bool -> ModRead
/// ```
pub fn module_item(s: &ModRead, fragment: &bool) -> ModRead {
    if at_sep(&s.p_) {
        {
            let mut this: ModRead = s.clone();
            this.p_ = adv(&this.p_);
            this
        }
    } else {
        {
            let s1 = header_or_decl(s, fragment, &here(&s.p_));
            let p2 = recovered(&s1.p_);
            let p3 = if at_close_l(&p2) {
                adv(&p2)
            } else {
                if at_eof(&p2) { p2.clone() } else { expect_stmt_end(&p2, &Text::lit("declaration")) }
            };
            {
                let mut this: ModRead = s1.clone();
                this.p_ = p3.clone();
                this
            }
        }
    }
}

/// The step machine of `ModuleItem`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModuleItem: unbounded fn ModRead, Bool -> ModRead
/// ```
pub struct ModuleItem {
    pub s: ModRead,
    pub fragment: bool,
}

impl prism_rtl::Job<ModRead> for ModuleItem {
    fn cycle(&self) -> prism_rtl::Turn<ModRead> {
        let s = &self.s;
        let fragment = &self.fragment;
        if at_sep(&s.p_) {
            prism_rtl::Turn::Finished({
                let mut this: ModRead = s.clone();
                this.p_ = adv(&this.p_);
                this
            })
        } else {
            {
                let fragment = *fragment;
                let s = s.clone();
                call_then(start_header_or_decl(s.clone(), fragment, here(&s.p_)), move |header_or_decl_19928: ModRead| {
                    let s1 = header_or_decl_19928;
                    call_then(start_recovered(s1.p_.clone()), move |recovered_19982: Ps| {
                        let p2 = recovered_19982;
                        let p3 = if at_close_l(&p2) {
                            adv(&p2)
                        } else {
                            if at_eof(&p2) { p2.clone() } else { expect_stmt_end(&p2, &Text::lit("declaration")) }
                        };
                        prism_rtl::Turn::Finished({
                            let mut this: ModRead = s1.clone();
                            this.p_ = p3.clone();
                            this
                        })
                    })
                })
            }
        }
    }
}

/// `Start ModuleItem, x`: what the function value is when passed to `@Run`.
pub fn start_module_item(s: ModRead, fragment: bool) -> Rc<dyn prism_rtl::Job<ModRead>> {
    Rc::new(ModuleItem { s, fragment })
}

/// ```prism
/// HeaderOrDecl: unbounded fn ModRead, Bool, Range -> ModRead
/// ```
pub fn header_or_decl(s: &ModRead, fragment: &bool, item_start: &crate::syntax::Range) -> ModRead {
    match kind(&s.p_) {
        crate::syntax::lexer::TokKind::KKw(m20304_0_0, m20304_0_1) if (&m20304_0_0 == &Text::lit("module")) && (&m20304_0_1 == &Text::lit("")) => {
            let (name, p_) = parse_qual_name(&adv(&s.p_));
            if p_.bad {
                {
                    let mut this: ModRead = s.clone();
                    this.p_ = p_.clone();
                    this
                }
            } else {
                {
                    let late = (&s.stage > &Nat::from(0u32)) || (&s.m.name != &None);
                    {
                        let mut this: ModRead = s.clone();
                        this.p_ = if late {
                            note_error(&p_, item_start, &Text::lit("the `module` line comes first in a file"))
                        } else {
                            p_.clone()
                        };
                        this.m.name = Some(name.clone());
                        this.stage = Nat::from(1u32);
                        this
                    }
                }
            }
        },
        crate::syntax::lexer::TokKind::KKw(m20304_1_0, m20304_1_1) if (&m20304_1_0 == &Text::lit("emit")) && (&m20304_1_1 == &Text::lit("")) => {
            let (emit_row, p_) = parse_row(&adv(&s.p_));
            if p_.bad {
                {
                    let mut this: ModRead = s.clone();
                    this.p_ = p_.clone();
                    this
                }
            } else {
                {
                    let late = (&s.stage > &Nat::from(1u32)) || (&s.m.emit_row != &None);
                    {
                        let mut this: ModRead = s.clone();
                        this.p_ = if late {
                            note_error(&p_, item_start, &Text::lit("`emit` comes after `module` and above `use`, once (Semantics ch. 6)"))
                        } else {
                            p_.clone()
                        };
                        this.m.emit_row = Some(emit_row.clone());
                        this.stage = Nat::from(2u32);
                        this
                    }
                }
            }
        },
        crate::syntax::lexer::TokKind::KKw(m20304_2_0, m20304_2_1) if (&m20304_2_0 == &Text::lit("use")) && (&m20304_2_1 == &Text::lit("")) => {
            let (u, p_) = parse_use(&adv(&s.p_), item_start);
            if p_.bad {
                {
                    let mut this: ModRead = s.clone();
                    this.p_ = p_.clone();
                    this
                }
            } else {
                {
                    let mut this: ModRead = s.clone();
                    this.p_ = if &s.stage > &Nat::from(4u32) {
                        note_error(&p_, item_start, &Text::lit("`use` lines belong to the header, above the declarations"))
                    } else {
                        p_.clone()
                    };
                    this.m.uses = push(&this.m.uses, &u);
                    this.stage = Nat::from(4u32);
                    this
                }
            }
        },
        crate::syntax::lexer::TokKind::KKw(m20304_3_0, m20304_3_1) if (&m20304_3_0 == &Text::lit("mod")) && (&m20304_3_1 == &Text::lit("")) => mod_header(s, &adv(&s.p_), &false, item_start),
        crate::syntax::lexer::TokKind::KKw(m20304_4_0, m20304_4_1) if (&m20304_4_0 == &Text::lit("test")) && (&m20304_4_1 == &Text::lit("")) && is_kw_kind(&kind(&adv(&s.p_)), &Text::lit("mod")) => mod_header(s, &adv(&adv(&s.p_)), &true, item_start),
        _ => {
            let (d, p_) = parse_decl(&s.p_, fragment);
            {
                let mut this: ModRead = s.clone();
                this.p_ = p_.clone();
                this.stage = Nat::from(5u32);
                if !p_.bad {
                    this.m.decls = push(&this.m.decls, &d);
                }
                this
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `HeaderOrDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HeaderOrDecl: unbounded fn ModRead, Bool, Range -> ModRead
/// ```
pub struct HeaderOrDecl {
    pub s: ModRead,
    pub fragment: bool,
    pub item_start: crate::syntax::Range,
}

impl prism_rtl::Job<ModRead> for HeaderOrDecl {
    fn cycle(&self) -> prism_rtl::Turn<ModRead> {
        let s = &self.s;
        let fragment = &self.fragment;
        let item_start = &self.item_start;
        match kind(&s.p_) {
            crate::syntax::lexer::TokKind::KKw(m20304_0_0, m20304_0_1) if (&m20304_0_0 == &Text::lit("module")) && (&m20304_0_1 == &Text::lit("")) => {
                let (name, p_) = parse_qual_name(&adv(&s.p_));
                if p_.bad {
                    prism_rtl::Turn::Finished({
                        let mut this: ModRead = s.clone();
                        this.p_ = p_.clone();
                        this
                    })
                } else {
                    {
                        let late = (&s.stage > &Nat::from(0u32)) || (&s.m.name != &None);
                        prism_rtl::Turn::Finished({
                            let mut this: ModRead = s.clone();
                            this.p_ = if late {
                                note_error(&p_, item_start, &Text::lit("the `module` line comes first in a file"))
                            } else {
                                p_.clone()
                            };
                            this.m.name = Some(name.clone());
                            this.stage = Nat::from(1u32);
                            this
                        })
                    }
                }
            },
            crate::syntax::lexer::TokKind::KKw(m20304_1_0, m20304_1_1) if (&m20304_1_0 == &Text::lit("emit")) && (&m20304_1_1 == &Text::lit("")) => {
                let item_start = item_start.clone();
                let s = s.clone();
                call_then(start_parse_row(adv(&s.p_)), move |parse_row_20755: (crate::syntax::Row_, Ps)| {
                    let (emit_row, p_) = parse_row_20755;
                    if p_.bad {
                        prism_rtl::Turn::Finished({
                            let mut this: ModRead = s.clone();
                            this.p_ = p_.clone();
                            this
                        })
                    } else {
                        {
                            let late = (&s.stage > &Nat::from(1u32)) || (&s.m.emit_row != &None);
                            prism_rtl::Turn::Finished({
                                let mut this: ModRead = s.clone();
                                this.p_ = if late {
                                    note_error(&p_, &item_start, &Text::lit("`emit` comes after `module` and above `use`, once (Semantics ch. 6)"))
                                } else {
                                    p_.clone()
                                };
                                this.m.emit_row = Some(emit_row.clone());
                                this.stage = Nat::from(2u32);
                                this
                            })
                        }
                    }
                })
            },
            crate::syntax::lexer::TokKind::KKw(m20304_2_0, m20304_2_1) if (&m20304_2_0 == &Text::lit("use")) && (&m20304_2_1 == &Text::lit("")) => {
                let (u, p_) = parse_use(&adv(&s.p_), item_start);
                if p_.bad {
                    prism_rtl::Turn::Finished({
                        let mut this: ModRead = s.clone();
                        this.p_ = p_.clone();
                        this
                    })
                } else {
                    prism_rtl::Turn::Finished({
                        let mut this: ModRead = s.clone();
                        this.p_ = if &s.stage > &Nat::from(4u32) {
                            note_error(&p_, item_start, &Text::lit("`use` lines belong to the header, above the declarations"))
                        } else {
                            p_.clone()
                        };
                        this.m.uses = push(&this.m.uses, &u);
                        this.stage = Nat::from(4u32);
                        this
                    })
                }
            },
            crate::syntax::lexer::TokKind::KKw(m20304_3_0, m20304_3_1) if (&m20304_3_0 == &Text::lit("mod")) && (&m20304_3_1 == &Text::lit("")) => prism_rtl::Turn::Finished(mod_header(s, &adv(&s.p_), &false, item_start)),
            crate::syntax::lexer::TokKind::KKw(m20304_4_0, m20304_4_1) if (&m20304_4_0 == &Text::lit("test")) && (&m20304_4_1 == &Text::lit("")) && is_kw_kind(&kind(&adv(&s.p_)), &Text::lit("mod")) => prism_rtl::Turn::Finished(mod_header(s, &adv(&adv(&s.p_)), &true, item_start)),
            _ => {
                let fragment = *fragment;
                let s = s.clone();
                call_then(start_parse_decl(s.p_.clone(), fragment), move |parse_decl_21691: (crate::syntax::Decl, Ps)| {
                    let (d, p_) = parse_decl_21691;
                    prism_rtl::Turn::Finished({
                        let mut this: ModRead = s.clone();
                        this.p_ = p_.clone();
                        this.stage = Nat::from(5u32);
                        if !p_.bad {
                            this.m.decls = push(&this.m.decls, &d);
                        }
                        this
                    })
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start HeaderOrDecl, x`: what the function value is when passed to `@Run`.
pub fn start_header_or_decl(s: ModRead, fragment: bool, item_start: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<ModRead>> {
    Rc::new(HeaderOrDecl { s, fragment, item_start })
}

/// ```prism
/// ModHeader: fn ModRead, Ps, Bool, Range -> ModRead
/// ```
pub fn mod_header(s: &ModRead, p_: &Ps, is_test: &bool, item_start: &crate::syntax::Range) -> ModRead {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KName(n) if (((&n.sigils == &Text::lit("")) && (&len(&n.path_) == &Nat::from(1u32))) && !(*is_test && (&n.case == &crate::syntax::lexer::NameCase::CaseUpper))) => {
            let line = crate::syntax::ModLine { name: crate::syntax::Ident { name: or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")), span: here(p_) }, is_test: *is_test, span: to(item_start, &here(p_)) };
            {
                let mut this: ModRead = s.clone();
                this.p_ = if &s.stage > &Nat::from(3u32) {
                    note_error(&adv(p_), item_start, &Text::lit("`mod` lines come after `emit` and above `use` (docs/modules-style-pass.md)"))
                } else {
                    adv(p_)
                };
                this.m.mods = push(&this.m.mods, &line);
                this.stage = Nat::from(3u32);
                this
            }
        },
        _ => {
            let mut this: ModRead = s.clone();
            this.p_ = error_here(p_, &(if *is_test {
                Text::lit("expected a test module's lowercase name after `test mod`")
            } else {
                Text::lit("expected a section's or a submodule's name after `mod`")
            }));
            this
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IsKwKind: fn TokKind, Text -> Bool
/// ```
pub fn is_kw_kind(k: &crate::syntax::lexer::TokKind, w: &Text) -> bool {
    match k {
        crate::syntax::lexer::TokKind::KKw(x, _) => x == w,
        _ => false,
    }
}

/// ```prism
/// let noQual
/// ```
pub fn no_qual() -> crate::syntax::QualName {
    crate::syntax::QualName { path_: Array::new(), span: no_range() }
}

/// ```prism
/// ParseUse: fn Ps, Range -> ((Use, Ps))
/// ```
pub fn parse_use(p_: &Ps, start: &crate::syntax::Range) -> (crate::syntax::Use, Ps) {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KFamily(path_) => (crate::syntax::Use { target: crate::syntax::QualName { path_: path_.clone(), span: here(p_) }, star: true, span: to(start, &here(p_)) }, adv(p_)),
        crate::syntax::lexer::TokKind::KName(n) if ((&n.sigils == &Text::lit("")) && (&n.case == &crate::syntax::lexer::NameCase::CaseUpper)) => (crate::syntax::Use { target: crate::syntax::QualName { path_: n.path_.clone(), span: here(p_) }, star: false, span: to(start, &here(p_)) }, adv(p_)),
        _ => (crate::syntax::Use { target: no_qual(), star: false, span: no_range() }, error_here(p_, &Text::lit("expected a module name after `use`"))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// let noExpr
/// ```
pub fn no_expr() -> crate::syntax::Expr {
    crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: no_range() }
}

/// ```prism
/// let noType
/// ```
pub fn no_type() -> crate::syntax::Type {
    crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TAbsent), span: no_range() }
}

/// ```prism
/// let noPattern
/// ```
pub fn no_pattern() -> crate::syntax::Pattern_ {
    crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: no_range() }
}

/// ```prism
/// let noBlock
/// ```
pub fn no_block() -> crate::syntax::Block {
    crate::syntax::Block { stmts: Array::new(), inline: true, span: no_range() }
}

/// ```prism
/// ParseDecl: unbounded fn Ps, Bool -> ((Decl, Ps))
/// ```
pub fn parse_decl(p_: &Ps, fragment: &bool) -> (crate::syntax::Decl, Ps) {
    let start = here(p_);
    let (kind_, q) = decl_kind_of(p_, fragment, &start);
    (crate::syntax::Decl { kind: kind_.clone(), span: to(&start, &prev(&q)) }, q.clone())
}

/// The step machine of `ParseDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseDecl: unbounded fn Ps, Bool -> ((Decl, Ps))
/// ```
pub struct ParseDecl {
    pub p_: Ps,
    pub fragment: bool,
}

impl prism_rtl::Job<(crate::syntax::Decl, Ps)> for ParseDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Decl, Ps)> {
        let p_ = &self.p_;
        let fragment = &self.fragment;
        let start = here(p_);
        let fragment = *fragment;
        let p_ = p_.clone();
        call_then(start_decl_kind_of(p_.clone(), fragment, start.clone()), move |decl_kind_of_23635: (crate::syntax::DeclKind, Ps)| {
            let (kind_, q) = decl_kind_of_23635;
            prism_rtl::Turn::Finished((crate::syntax::Decl { kind: kind_.clone(), span: to(&start, &prev(&q)) }, q.clone()))
        })
    }
}

/// `Start ParseDecl, x`: what the function value is when passed to `@Run`.
pub fn start_parse_decl(p_: Ps, fragment: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Decl, Ps)>> {
    Rc::new(ParseDecl { p_, fragment })
}

/// ```prism
/// DeclKindOf: unbounded fn Ps, Bool, Range -> ((DeclKind, Ps))
/// ```
pub fn decl_kind_of(p_: &Ps, fragment: &bool, start: &crate::syntax::Range) -> (crate::syntax::DeclKind, Ps) {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KKw(m23816_0_0, _) if (&m23816_0_0 == &Text::lit("type")) => {
            let (d, q) = parse_type_decl(p_);
            (crate::syntax::DeclKind::DType(d.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m23816_1_0, _) if (&m23816_1_0 == &Text::lit("tag")) => {
            let (d, q) = parse_tag_decl(p_);
            (crate::syntax::DeclKind::DTag(d.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m23816_2_0, _) if (&m23816_2_0 == &Text::lit("derive")) => {
            let (traits, q) = commas(&adv(p_), &{
                let f = Rc::new(parse_trait_ref);
                Rc::new(move |a0: Ps| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                }) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::TraitRef, Ps)>>>
            });
            (crate::syntax::DeclKind::DDerive(traits.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m23816_3_0, _) if (&m23816_3_0 == &Text::lit("trait")) => {
            let (d, q) = parse_trait_decl(p_);
            (crate::syntax::DeclKind::DTrait(d.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m23816_4_0, _) if (&m23816_4_0 == &Text::lit("impl")) => {
            let (d, q) = parse_impl_decl(p_);
            (crate::syntax::DeclKind::DImpl(d.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m23816_5_0, _) if (&m23816_5_0 == &Text::lit("check")) => {
            let (d, q) = parse_check_decl(p_);
            (crate::syntax::DeclKind::DCheck(d.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m23816_6_0, _) if (&m23816_6_0 == &Text::lit("test")) => {
            let (d, q) = parse_test_decl(p_);
            (crate::syntax::DeclKind::DTest(d.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m23816_7_0, _) if (&m23816_7_0 == &Text::lit("fn")) => {
            let (d, q) = parse_fn_clause(p_);
            (crate::syntax::DeclKind::DFn(d.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m23816_8_0, _) if (&m23816_8_0 == &Text::lit("let")) => {
            let (pattern, p1) = parse_pattern(&adv(p_), &false);
            let (ty_opt, p2) = optional_annotation(&p1);
            let (value, p3) = parse_rhs_expr(&expect_op(&p2, &Text::lit("=")));
            (crate::syntax::DeclKind::DLet(crate::syntax::LetDecl { pattern: pattern.clone(), ty: ty_opt.clone(), value: value.clone(), span: to(start, &prev(&p3)) }), p3.clone())
        },
        crate::syntax::lexer::TokKind::KName(_) if (&kind_at(p_, &Nat::from(1u32)) == &crate::syntax::lexer::TokKind::KColon) => if &kind_at(p_, &Nat::from(2u32)) == &crate::syntax::lexer::TokKind::KLayOpen {
            {
                let (name, p1) = parse_sname(p_);
                let (body, p2) = parse_block_after_colon(&p1);
                (crate::syntax::DeclKind::DWidget(crate::syntax::WidgetDecl { name: name.clone(), body: body.clone(), span: to(start, &body.span) }), p2.clone())
            }
        } else {
            {
                let (sig, q) = parse_signature(p_);
                (crate::syntax::DeclKind::DSignature(sig.clone()), q.clone())
            }
        },
        _ => if *fragment {
            {
                let (st, q) = parse_stmt(p_);
                (crate::syntax::DeclKind::DStmt(st.clone()), q.clone())
            }
        } else {
            {
                let (st, q) = parse_stmt(p_);
                match &st.kind {
                    crate::syntax::StmtKind::SBind(_, _, _) if !q.bad => (crate::syntax::DeclKind::DStmt(st.clone()), error_at(&q, start, &Text::lit("a bind or hold is a statement of a widget block: nothing at top level is built (Semantics ch. 6)"))),
                    _ => {
                        let at_ = if q.bad { p_.clone() } else { q.clone() };
                        (crate::syntax::DeclKind::DStmt(st.clone()), error_here(&at_, &Text::lit("expected a declaration (`fn`, `let`, `type`, `tag`, `derive`, `trait`, `impl`, `test`, `check`, or a signature `Name: type`)")))
                    },
                    _ => unreachable!("no arm matched"),
                }
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `DeclKindOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DeclKindOf: unbounded fn Ps, Bool, Range -> ((DeclKind, Ps))
/// ```
pub struct DeclKindOf {
    pub p_: Ps,
    pub fragment: bool,
    pub start: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::syntax::DeclKind, Ps)> for DeclKindOf {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::DeclKind, Ps)> {
        let p_ = &self.p_;
        let fragment = &self.fragment;
        let start = &self.start;
        match kind(p_) {
            crate::syntax::lexer::TokKind::KKw(m23816_0_0, _) if (&m23816_0_0 == &Text::lit("type")) => {
                let p_ = p_.clone();
                call_then(start_parse_type_decl(p_.clone()), move |parse_type_decl_23877: (crate::syntax::TypeDecl, Ps)| {
                    let (d, q) = parse_type_decl_23877;
                    prism_rtl::Turn::Finished((crate::syntax::DeclKind::DType(d.clone()), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m23816_1_0, _) if (&m23816_1_0 == &Text::lit("tag")) => {
                let p_ = p_.clone();
                call_then(start_parse_tag_decl(p_.clone()), move |parse_tag_decl_23962: (crate::syntax::TagDecl, Ps)| {
                    let (d, q) = parse_tag_decl_23962;
                    prism_rtl::Turn::Finished((crate::syntax::DeclKind::DTag(d.clone()), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m23816_2_0, _) if (&m23816_2_0 == &Text::lit("derive")) => {
                let p_ = p_.clone();
                call_then(start_commas(adv(&p_), {
                    let f = Rc::new(parse_trait_ref);
                    Rc::new(move |a0: Ps| {
                        let f = f.clone();
                        once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                    }) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::TraitRef, Ps)>>>
                }), move |commas_24053: (Array<crate::syntax::TraitRef>, Ps)| {
                    let (traits, q) = commas_24053;
                    prism_rtl::Turn::Finished((crate::syntax::DeclKind::DDerive(traits.clone()), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m23816_3_0, _) if (&m23816_3_0 == &Text::lit("trait")) => {
                let p_ = p_.clone();
                call_then(start_parse_trait_decl(p_.clone()), move |parse_trait_decl_24161: (crate::syntax::TraitDecl, Ps)| {
                    let (d, q) = parse_trait_decl_24161;
                    prism_rtl::Turn::Finished((crate::syntax::DeclKind::DTrait(d.clone()), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m23816_4_0, _) if (&m23816_4_0 == &Text::lit("impl")) => {
                let p_ = p_.clone();
                call_then(start_parse_impl_decl(p_.clone()), move |parse_impl_decl_24249: (crate::syntax::ImplDecl, Ps)| {
                    let (d, q) = parse_impl_decl_24249;
                    prism_rtl::Turn::Finished((crate::syntax::DeclKind::DImpl(d.clone()), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m23816_5_0, _) if (&m23816_5_0 == &Text::lit("check")) => {
                let p_ = p_.clone();
                call_then(start_parse_check_decl(p_.clone()), move |parse_check_decl_24336: (crate::syntax::CheckDecl, Ps)| {
                    let (d, q) = parse_check_decl_24336;
                    prism_rtl::Turn::Finished((crate::syntax::DeclKind::DCheck(d.clone()), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m23816_6_0, _) if (&m23816_6_0 == &Text::lit("test")) => {
                let p_ = p_.clone();
                call_then(start_parse_test_decl(p_.clone()), move |parse_test_decl_24424: (crate::syntax::TestDecl, Ps)| {
                    let (d, q) = parse_test_decl_24424;
                    prism_rtl::Turn::Finished((crate::syntax::DeclKind::DTest(d.clone()), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m23816_7_0, _) if (&m23816_7_0 == &Text::lit("fn")) => {
                let p_ = p_.clone();
                call_then(start_parse_fn_clause(p_.clone()), move |parse_fn_clause_24508: (crate::syntax::FnClause, Ps)| {
                    let (d, q) = parse_fn_clause_24508;
                    prism_rtl::Turn::Finished((crate::syntax::DeclKind::DFn(d.clone()), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m23816_8_0, _) if (&m23816_8_0 == &Text::lit("let")) => {
                let p_ = p_.clone();
                let start = start.clone();
                call_then(start_parse_pattern(adv(&p_), false), move |parse_pattern_24598: (crate::syntax::Pattern_, Ps)| {
                    let (pattern, p1) = parse_pattern_24598;
                    call_then(start_optional_annotation(p1.clone()), move |optional_annotation_24652: (Option<crate::syntax::Type>, Ps)| {
                        let (ty_opt, p2) = optional_annotation_24652;
                        call_then(start_parse_rhs_expr(expect_op(&p2, &Text::lit("="))), move |parse_rhs_expr_24702: (crate::syntax::Expr, Ps)| {
                            let (value, p3) = parse_rhs_expr_24702;
                            prism_rtl::Turn::Finished((crate::syntax::DeclKind::DLet(crate::syntax::LetDecl { pattern: pattern.clone(), ty: ty_opt.clone(), value: value.clone(), span: to(&start, &prev(&p3)) }), p3.clone()))
                        })
                    })
                })
            },
            crate::syntax::lexer::TokKind::KName(_) if (&kind_at(p_, &Nat::from(1u32)) == &crate::syntax::lexer::TokKind::KColon) => if &kind_at(p_, &Nat::from(2u32)) == &crate::syntax::lexer::TokKind::KLayOpen {
                {
                    let (name, p1) = parse_sname(p_);
                    let start = start.clone();
                    call_then(start_parse_block_after_colon(p1.clone()), move |parse_block_after_colon_24987: (crate::syntax::Block, Ps)| {
                        let (body, p2) = parse_block_after_colon_24987;
                        prism_rtl::Turn::Finished((crate::syntax::DeclKind::DWidget(crate::syntax::WidgetDecl { name: name.clone(), body: body.clone(), span: to(&start, &body.span) }), p2.clone()))
                    })
                }
            } else {
                {
                    let p_ = p_.clone();
                    call_then(start_parse_signature(p_.clone()), move |parse_signature_25143: (crate::syntax::Signature, Ps)| {
                        let (sig, q) = parse_signature_25143;
                        prism_rtl::Turn::Finished((crate::syntax::DeclKind::DSignature(sig.clone()), q.clone()))
                    })
                }
            },
            _ => if *fragment {
                {
                    let p_ = p_.clone();
                    call_then(start_parse_stmt(p_.clone()), move |parse_stmt_25258: (crate::syntax::Stmt, Ps)| {
                        let (st, q) = parse_stmt_25258;
                        prism_rtl::Turn::Finished((crate::syntax::DeclKind::DStmt(st.clone()), q.clone()))
                    })
                }
            } else {
                {
                    let p_ = p_.clone();
                    let start = start.clone();
                    call_then(start_parse_stmt(p_.clone()), move |parse_stmt_25466: (crate::syntax::Stmt, Ps)| {
                        let (st, q) = parse_stmt_25466;
                        match &st.kind {
                            crate::syntax::StmtKind::SBind(_, _, _) if !q.bad => prism_rtl::Turn::Finished((crate::syntax::DeclKind::DStmt(st.clone()), error_at(&q, &start, &Text::lit("a bind or hold is a statement of a widget block: nothing at top level is built (Semantics ch. 6)")))),
                            _ => {
                                let at_ = if q.bad { p_.clone() } else { q.clone() };
                                prism_rtl::Turn::Finished((crate::syntax::DeclKind::DStmt(st.clone()), error_here(&at_, &Text::lit("expected a declaration (`fn`, `let`, `type`, `tag`, `derive`, `trait`, `impl`, `test`, `check`, or a signature `Name: type`)"))))
                            },
                            _ => unreachable!("no arm matched"),
                        }
                    })
                }
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start DeclKindOf, x`: what the function value is when passed to `@Run`.
pub fn start_decl_kind_of(p_: Ps, fragment: bool, start: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::syntax::DeclKind, Ps)>> {
    Rc::new(DeclKindOf { p_, fragment, start })
}

/// ```prism
/// OptionalAnnotation: unbounded fn Ps -> ((?Type, Ps))
/// ```
pub fn optional_annotation(p_: &Ps) -> (Option<crate::syntax::Type>, Ps) {
    if at_colon(p_) {
        {
            let (ty, q) = parse_type(&adv(p_));
            (Some(ty.clone()), q.clone())
        }
    } else {
        (None, p_.clone())
    }
}

/// The step machine of `OptionalAnnotation`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptionalAnnotation: unbounded fn Ps -> ((?Type, Ps))
/// ```
pub struct OptionalAnnotation {
    pub p_: Ps,
}

impl prism_rtl::Job<(Option<crate::syntax::Type>, Ps)> for OptionalAnnotation {
    fn cycle(&self) -> prism_rtl::Turn<(Option<crate::syntax::Type>, Ps)> {
        let p_ = &self.p_;
        if at_colon(p_) {
            {
                let p_ = p_.clone();
                call_then(start_parse_type(adv(&p_)), move |parse_type_26156: (crate::syntax::Type, Ps)| {
                    let (ty, q) = parse_type_26156;
                    prism_rtl::Turn::Finished((Some(ty.clone()), q.clone()))
                })
            }
        } else {
            prism_rtl::Turn::Finished((None, p_.clone()))
        }
    }
}

/// `Start OptionalAnnotation, x`: what the function value is when passed to `@Run`.
pub fn start_optional_annotation(p_: Ps) -> Rc<dyn prism_rtl::Job<(Option<crate::syntax::Type>, Ps)>> {
    Rc::new(OptionalAnnotation { p_ })
}

/// ```prism
/// ParseSignature: unbounded fn Ps -> ((Signature, Ps))
/// ```
pub fn parse_signature(p_: &Ps) -> (crate::syntax::Signature, Ps) {
    let start = here(p_);
    let (name, p1) = parse_def_name(p_);
    let (ty, p2) = parse_type(&expect_colon(&p1));
    let (bounds, p3) = optional_bounds(&p2);
    (crate::syntax::Signature { name: name.clone(), ty: ty.clone(), bounds: bounds.clone(), span: to(&start, &prev(&p3)) }, p3.clone())
}

/// The step machine of `ParseSignature`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseSignature: unbounded fn Ps -> ((Signature, Ps))
/// ```
pub struct ParseSignature {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::Signature, Ps)> for ParseSignature {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Signature, Ps)> {
        let p_ = &self.p_;
        let start = here(p_);
        let (name, p1) = parse_def_name(p_);
        call_then(start_parse_type(expect_colon(&p1)), move |parse_type_26438: (crate::syntax::Type, Ps)| {
            let (ty, p2) = parse_type_26438;
            call_then(start_optional_bounds(p2.clone()), move |optional_bounds_26490: (Array<crate::syntax::Bound>, Ps)| {
                let (bounds, p3) = optional_bounds_26490;
                prism_rtl::Turn::Finished((crate::syntax::Signature { name: name.clone(), ty: ty.clone(), bounds: bounds.clone(), span: to(&start, &prev(&p3)) }, p3.clone()))
            })
        })
    }
}

/// `Start ParseSignature, x`: what the function value is when passed to `@Run`.
pub fn start_parse_signature(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Signature, Ps)>> {
    Rc::new(ParseSignature { p_ })
}

/// ```prism
/// OptionalBounds: unbounded fn Ps -> (([Bound], Ps))
/// ```
pub fn optional_bounds(p_: &Ps) -> (Array<crate::syntax::Bound>, Ps) {
    if at_kw(p_, &Text::lit("where")) {
        parse_bounds(&adv(p_))
    } else {
        (Array::new(), p_.clone())
    }
}

/// The step machine of `OptionalBounds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptionalBounds: unbounded fn Ps -> (([Bound], Ps))
/// ```
pub struct OptionalBounds {
    pub p_: Ps,
}

impl prism_rtl::Job<(Array<crate::syntax::Bound>, Ps)> for OptionalBounds {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::Bound>, Ps)> {
        let p_ = &self.p_;
        if at_kw(p_, &Text::lit("where")) {
            prism_rtl::Turn::More(Rc::new(ParseBounds { p0: adv(p_) }))
        } else {
            prism_rtl::Turn::Finished((Array::new(), p_.clone()))
        }
    }
}

/// `Start OptionalBounds, x`: what the function value is when passed to `@Run`.
pub fn start_optional_bounds(p_: Ps) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Bound>, Ps)>> {
    Rc::new(OptionalBounds { p_ })
}

/// ```prism
/// ParseDefName: fn Ps -> ((DefName, Ps))
/// ```
pub fn parse_def_name(p_: &Ps) -> (crate::syntax::DefName, Ps) {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KName(n) => {
            let (name, q) = parse_sname(p_);
            let lens = crate::syntax::lexer::has_prefix(&n.sigils, &Text::lit("&")) && is_upper_name(&name);
            let q2 = if lens {
                out_of_scope(&q, &name.span, &Text::lit("named lenses `&Home` and `Over`"), &Text::from(format!("the named lens `{}` is out of this compiler", &name_text(&name))))
            } else {
                q.clone()
            };
            (crate::syntax::DefName::DefSName(name.clone()), q2.clone())
        },
        crate::syntax::lexer::TokKind::KOp(op, _) if p_.in_trait => {
            let name = crate::syntax::DefName::DefOp(op.clone(), here(p_));
            (name.clone(), adv(p_))
        },
        _ => (crate::syntax::DefName::DefSName(no_sname()), error_here(p_, &Text::lit("expected a name"))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParseFnClause: unbounded fn Ps -> ((FnClause, Ps))
/// ```
pub fn parse_fn_clause(p0: &Ps) -> (crate::syntax::FnClause, Ps) {
    let start = here(p0);
    let (name, p1) = parse_def_name(&expect_kw(p0, &Text::lit("fn")));
    let (params, p2) = if at_op(&p1, &Text::lit("=")) || at_colon(&p1) {
        (Array::new(), p1.clone())
    } else {
        commas(&p1, &(Rc::new(move |p0: Ps| entered(once_job(move || {
            let q = p0;
            prism_rtl::Turn::More(Rc::new(ParsePattern { p_: q.clone(), commas0: false }))
        }))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, Ps)>>>))
    };
    let (body, p3) = parse_fn_body(&p2);
    (crate::syntax::FnClause { name: name.clone(), params: params.clone(), body: body.clone(), span: to(&start, &prev(&p3)) }, p3.clone())
}

/// The step machine of `ParseFnClause`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseFnClause: unbounded fn Ps -> ((FnClause, Ps))
/// ```
pub struct ParseFnClause {
    pub p0: Ps,
}

impl prism_rtl::Job<(crate::syntax::FnClause, Ps)> for ParseFnClause {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::FnClause, Ps)> {
        let p0 = &self.p0;
        let start = here(p0);
        let (name, p1) = parse_def_name(&expect_kw(p0, &Text::lit("fn")));
        let (params, p2) = if at_op(&p1, &Text::lit("=")) || at_colon(&p1) {
            (Array::new(), p1.clone())
        } else {
            commas(&p1, &(Rc::new(move |p0: Ps| entered(once_job(move || {
                let q = p0;
                prism_rtl::Turn::More(Rc::new(ParsePattern { p_: q.clone(), commas0: false }))
            }))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, Ps)>>>))
        };
        call_then(start_parse_fn_body(p2.clone()), move |parse_fn_body_27613: (crate::syntax::FnBody, Ps)| {
            let (body, p3) = parse_fn_body_27613;
            prism_rtl::Turn::Finished((crate::syntax::FnClause { name: name.clone(), params: params.clone(), body: body.clone(), span: to(&start, &prev(&p3)) }, p3.clone()))
        })
    }
}

/// `Start ParseFnClause, x`: what the function value is when passed to `@Run`.
pub fn start_parse_fn_clause(p0: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::FnClause, Ps)>> {
    Rc::new(ParseFnClause { p0 })
}

/// ```prism
/// ParseFnBody: unbounded fn Ps -> ((FnBody, Ps))
/// ```
pub fn parse_fn_body(p_: &Ps) -> (crate::syntax::FnBody, Ps) {
    if at_op(p_, &Text::lit("=")) {
        {
            let (e, q) = parse_rhs_expr(&adv(p_));
            (crate::syntax::FnBody::BodyExpr(e.clone()), q.clone())
        }
    } else {
        if at_colon(p_) {
            {
                let (b, q) = parse_block_after_colon(p_);
                (crate::syntax::FnBody::BodyBlock(b.clone()), q.clone())
            }
        } else {
            (crate::syntax::FnBody::BodyExpr(no_expr()), error_here(p_, &Text::lit("expected `=` and an expression, or `:` and a block, after the parameters")))
        }
    }
}

/// The step machine of `ParseFnBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseFnBody: unbounded fn Ps -> ((FnBody, Ps))
/// ```
pub struct ParseFnBody {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::FnBody, Ps)> for ParseFnBody {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::FnBody, Ps)> {
        let p_ = &self.p_;
        if at_op(p_, &Text::lit("=")) {
            {
                let p_ = p_.clone();
                call_then(start_parse_rhs_expr(adv(&p_)), move |parse_rhs_expr_27823: (crate::syntax::Expr, Ps)| {
                    let (e, q) = parse_rhs_expr_27823;
                    prism_rtl::Turn::Finished((crate::syntax::FnBody::BodyExpr(e.clone()), q.clone()))
                })
            }
        } else {
            if at_colon(p_) {
                {
                    let p_ = p_.clone();
                    call_then(start_parse_block_after_colon(p_.clone()), move |parse_block_after_colon_27917: (crate::syntax::Block, Ps)| {
                        let (b, q) = parse_block_after_colon_27917;
                        prism_rtl::Turn::Finished((crate::syntax::FnBody::BodyBlock(b.clone()), q.clone()))
                    })
                }
            } else {
                prism_rtl::Turn::Finished((crate::syntax::FnBody::BodyExpr(no_expr()), error_here(p_, &Text::lit("expected `=` and an expression, or `:` and a block, after the parameters"))))
            }
        }
    }
}

/// `Start ParseFnBody, x`: what the function value is when passed to `@Run`.
pub fn start_parse_fn_body(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::FnBody, Ps)>> {
    Rc::new(ParseFnBody { p_ })
}

/// ```prism
/// LowerParams: fn Ps -> (([Ident], Ps))
/// ```
pub fn lower_params(p0: &Ps) -> (Array<crate::syntax::Ident>, Ps) {
    let mut this: (Array<crate::syntax::Ident>, Ps) = (Array::new(), p0.clone());
    let mut ps: Array<crate::syntax::Ident> = Array::new();
    let mut p_: Ps = p0.clone();
    let mut fuel: Nat = len(&p0.toks);
    while let Some(left) = (&fuel).checked_sub(&Nat::from(1u32)) {
        if !is_plain_lower(&kind(&p_)) {
            break;
        }
        fuel = left.clone();
        let (i, q) = parse_ident(&p_);
        ps = push(&ps, &i);
        p_ = q.clone();
    }
    this = (ps.clone(), p_.clone());
    this
}

/// ```prism
/// IsPlainLower: fn TokKind -> Bool
/// ```
pub fn is_plain_lower(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KName(n) => (&n.case == &crate::syntax::lexer::NameCase::CaseLower) && (&n.sigils == &Text::lit("")),
        _ => false,
    }
}

/// ```prism
/// ParseTypeDecl: unbounded fn Ps -> ((TypeDecl, Ps))
/// ```
pub fn parse_type_decl(p0: &Ps) -> (crate::syntax::TypeDecl, Ps) {
    let start = here(p0);
    let (name, p1) = parse_qual_name(&adv(p0));
    let (params, p2) = lower_params(&p1);
    let (body_opt, p3) = if at_op(&p2, &Text::lit("=")) {
        parse_type_body(&adv(&p2), &name, &params)
    } else {
        (None, p2.clone())
    };
    (crate::syntax::TypeDecl { name: name.clone(), params: params.clone(), body: body_opt.clone(), span: to(&start, &prev(&p3)) }, p3.clone())
}

/// The step machine of `ParseTypeDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTypeDecl: unbounded fn Ps -> ((TypeDecl, Ps))
/// ```
pub struct ParseTypeDecl {
    pub p0: Ps,
}

impl prism_rtl::Job<(crate::syntax::TypeDecl, Ps)> for ParseTypeDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::TypeDecl, Ps)> {
        let p0 = &self.p0;
        let start = here(p0);
        let (name, p1) = parse_qual_name(&adv(p0));
        let (params, p2) = lower_params(&p1);
        let (body_opt, p3) = if at_op(&p2, &Text::lit("=")) {
            parse_type_body(&adv(&p2), &name, &params)
        } else {
            (None, p2.clone())
        };
        prism_rtl::Turn::Finished((crate::syntax::TypeDecl { name: name.clone(), params: params.clone(), body: body_opt.clone(), span: to(&start, &prev(&p3)) }, p3.clone()))
    }
}

/// `Start ParseTypeDecl, x`: what the function value is when passed to `@Run`.
pub fn start_parse_type_decl(p0: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::TypeDecl, Ps)>> {
    Rc::new(ParseTypeDecl { p0 })
}

/// ```prism
/// ParseTypeBody: unbounded fn Ps, QualName, [Ident] -> ((?TypeBody, Ps))
/// ```
pub fn parse_type_body(p_: &Ps, name: &crate::syntax::QualName, params: &Array<crate::syntax::Ident>) -> (Option<crate::syntax::TypeBody>, Ps) {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KKw(m29130_0_0, m29130_0_1) if (&m29130_0_0 == &Text::lit("record")) && (&m29130_0_1 == &Text::lit("")) => {
            let (fields, q) = parse_field_block(&adv(p_));
            (Some(crate::syntax::TypeBody::TbRecord(fields.clone())), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m29130_1_0, m29130_1_1) if (&m29130_1_0 == &Text::lit("choice")) && (&m29130_1_1 == &Text::lit("")) => {
            let p1 = expect_colon(&adv(p_));
            if at_open_l(&p1) {
                {
                    let (cases, q) = layout_items(&adv(&p1), &(Rc::new(|a0: Ps| entered(start_parse_case(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Case_, Ps)>>>));
                    (Some(crate::syntax::TypeBody::TbChoice(cases.clone())), q.clone())
                }
            } else {
                (None, error_here(&p1, &Text::lit("a choice's cases stand in an indented block after `choice:`")))
            }
        },
        crate::syntax::lexer::TokKind::KKw(m29130_2_0, m29130_2_1) if (&m29130_2_0 == &Text::lit("row")) && (&m29130_2_1 == &Text::lit("")) => (Some(crate::syntax::TypeBody::TbRow), adv(p_)),
        crate::syntax::lexer::TokKind::KName(n) if (((&n.sigils == &Text::lit("")) && (&len(&n.path_) == &Nat::from(1u32))) && (&crate::syntax::lexer::last(&n.path_) == &crate::syntax::lexer::last(&name.path_))) => {
            let (c, q) = parse_case(p_);
            (Some(crate::syntax::TypeBody::TbNewtype(c.clone())), q.clone())
        },
        crate::syntax::lexer::TokKind::KName(n) if is_unit_body(p_, &n, params) => {
            let (i, q) = parse_ident(p_);
            (Some(crate::syntax::TypeBody::TbUnit(i.clone())), q.clone())
        },
        _ => {
            let (ty, q) = parse_type(p_);
            (Some(crate::syntax::TypeBody::TbAlias(ty.clone())), q.clone())
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ParseTypeBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTypeBody: unbounded fn Ps, QualName, [Ident] -> ((?TypeBody, Ps))
/// ```
pub struct ParseTypeBody {
    pub p_: Ps,
    pub name: crate::syntax::QualName,
    pub params: Array<crate::syntax::Ident>,
}

impl prism_rtl::Job<(Option<crate::syntax::TypeBody>, Ps)> for ParseTypeBody {
    fn cycle(&self) -> prism_rtl::Turn<(Option<crate::syntax::TypeBody>, Ps)> {
        let p_ = &self.p_;
        let name = &self.name;
        let params = &self.params;
        match kind(p_) {
            crate::syntax::lexer::TokKind::KKw(m29130_0_0, m29130_0_1) if (&m29130_0_0 == &Text::lit("record")) && (&m29130_0_1 == &Text::lit("")) => {
                let p_ = p_.clone();
                call_then(start_parse_field_block(adv(&p_)), move |parse_field_block_29194: (Array<crate::syntax::Field>, Ps)| {
                    let (fields, q) = parse_field_block_29194;
                    prism_rtl::Turn::Finished((Some(crate::syntax::TypeBody::TbRecord(fields.clone())), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m29130_1_0, m29130_1_1) if (&m29130_1_0 == &Text::lit("choice")) && (&m29130_1_1 == &Text::lit("")) => {
                let p1 = expect_colon(&adv(p_));
                if at_open_l(&p1) {
                    call_then(start_layout_items(adv(&p1), Rc::new(|a0: Ps| entered(start_parse_case(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Case_, Ps)>>>), move |layout_items_29366: (Array<crate::syntax::Case_>, Ps)| {
                        let (cases, q) = layout_items_29366;
                        prism_rtl::Turn::Finished((Some(crate::syntax::TypeBody::TbChoice(cases.clone())), q.clone()))
                    })
                } else {
                    prism_rtl::Turn::Finished((None, error_here(&p1, &Text::lit("a choice's cases stand in an indented block after `choice:`"))))
                }
            },
            crate::syntax::lexer::TokKind::KKw(m29130_2_0, m29130_2_1) if (&m29130_2_0 == &Text::lit("row")) && (&m29130_2_1 == &Text::lit("")) => prism_rtl::Turn::Finished((Some(crate::syntax::TypeBody::TbRow), adv(p_))),
            crate::syntax::lexer::TokKind::KName(n) if (((&n.sigils == &Text::lit("")) && (&len(&n.path_) == &Nat::from(1u32))) && (&crate::syntax::lexer::last(&n.path_) == &crate::syntax::lexer::last(&name.path_))) => {
                let p_ = p_.clone();
                call_then(start_parse_case(p_.clone()), move |parse_case_29785: (crate::syntax::Case_, Ps)| {
                    let (c, q) = parse_case_29785;
                    prism_rtl::Turn::Finished((Some(crate::syntax::TypeBody::TbNewtype(c.clone())), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KName(n) if is_unit_body(p_, &n, params) => {
                let (i, q) = parse_ident(p_);
                prism_rtl::Turn::Finished((Some(crate::syntax::TypeBody::TbUnit(i.clone())), q.clone()))
            },
            _ => {
                let p_ = p_.clone();
                call_then(start_parse_type(p_.clone()), move |parse_type_30041: (crate::syntax::Type, Ps)| {
                    let (ty, q) = parse_type_30041;
                    prism_rtl::Turn::Finished((Some(crate::syntax::TypeBody::TbAlias(ty.clone())), q.clone()))
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ParseTypeBody, x`: what the function value is when passed to `@Run`.
pub fn start_parse_type_body(p_: Ps, name: crate::syntax::QualName, params: Array<crate::syntax::Ident>) -> Rc<dyn prism_rtl::Job<(Option<crate::syntax::TypeBody>, Ps)>> {
    Rc::new(ParseTypeBody { p_, name, params })
}

/// ```prism
/// IsUnitBody: fn Ps, NameTok, [Ident] -> Bool
/// ```
pub fn is_unit_body(p_: &Ps, n: &crate::syntax::lexer::NameTok, params: &Array<crate::syntax::Ident>) -> bool {
    let w = or(&index(&n.path_, &Nat::from(0u32)), &Text::lit(""));
    let param = fold(params, &false, &(|seen: &bool, i: &crate::syntax::Ident| *seen || (&i.name == &w)));
    let ends = match kind_at(p_, &Nat::from(1u32)) {
        crate::syntax::lexer::TokKind::KLaySep => true,
        crate::syntax::lexer::TokKind::KLayOpen => true,
        crate::syntax::lexer::TokKind::KLayClose => true,
        crate::syntax::lexer::TokKind::KEof => true,
        _ => false,
    };
    ((((&n.sigils == &Text::lit("")) && (&n.case == &crate::syntax::lexer::NameCase::CaseLower)) && (&len(&n.path_) == &Nat::from(1u32))) && !param) && ends
}

/// ```prism
/// ParseFieldBlock: unbounded fn Ps -> (([Field], Ps))
/// ```
pub fn parse_field_block(p0: &Ps) -> (Array<crate::syntax::Field>, Ps) {
    let p_ = expect_colon(p0);
    if at_open_l(&p_) {
        layout_items(&adv(&p_), &(Rc::new(|a0: Ps| entered(start_parse_field(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Field, Ps)>>>))
    } else {
        (Array::new(), error_here(&p_, &Text::lit("fields stand in an indented block, one `name: Type` per line")))
    }
}

/// The step machine of `ParseFieldBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseFieldBlock: unbounded fn Ps -> (([Field], Ps))
/// ```
pub struct ParseFieldBlock {
    pub p0: Ps,
}

impl prism_rtl::Job<(Array<crate::syntax::Field>, Ps)> for ParseFieldBlock {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::Field>, Ps)> {
        let p0 = &self.p0;
        let p_ = expect_colon(p0);
        if at_open_l(&p_) {
            prism_rtl::Turn::More(Rc::new(LayoutItems { p0: adv(&p_), f_fn: Rc::new(|a0: Ps| entered(start_parse_field(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Field, Ps)>>> }))
        } else {
            prism_rtl::Turn::Finished((Array::new(), error_here(&p_, &Text::lit("fields stand in an indented block, one `name: Type` per line"))))
        }
    }
}

/// `Start ParseFieldBlock, x`: what the function value is when passed to `@Run`.
pub fn start_parse_field_block(p0: Ps) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Field>, Ps)>> {
    Rc::new(ParseFieldBlock { p0 })
}

/// ```prism
/// ParseField: unbounded fn Ps -> ((Field, Ps))
/// ```
pub fn parse_field(p_: &Ps) -> (crate::syntax::Field, Ps) {
    let start = here(p_);
    let (name, p1) = parse_ident(p_);
    let (ty, p2) = parse_type(&expect_colon(&p1));
    (crate::syntax::Field { name: name.clone(), ty: ty.clone(), span: to(&start, &prev(&p2)) }, p2.clone())
}

/// The step machine of `ParseField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseField: unbounded fn Ps -> ((Field, Ps))
/// ```
pub struct ParseField {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::Field, Ps)> for ParseField {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Field, Ps)> {
        let p_ = &self.p_;
        let start = here(p_);
        let (name, p1) = parse_ident(p_);
        call_then(start_parse_type(expect_colon(&p1)), move |parse_type_30918: (crate::syntax::Type, Ps)| {
            let (ty, p2) = parse_type_30918;
            prism_rtl::Turn::Finished((crate::syntax::Field { name: name.clone(), ty: ty.clone(), span: to(&start, &prev(&p2)) }, p2.clone()))
        })
    }
}

/// `Start ParseField, x`: what the function value is when passed to `@Run`.
pub fn start_parse_field(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Field, Ps)>> {
    Rc::new(ParseField { p_ })
}

/// ```prism
/// ParseCase: unbounded fn Ps -> ((Case, Ps))
/// ```
pub fn parse_case(p0: &Ps) -> (crate::syntax::Case_, Ps) {
    let start = here(p0);
    let (name, p1) = parse_sname(p0);
    let p2 = if &name.sigils != &Text::lit("") {
        note_error(&p1, &name.span, &Text::lit("a constructor takes no sigil"))
    } else {
        p1.clone()
    };
    if at_colon(&p2) {
        {
            let p3 = adv(&p2);
            let (args, p4) = if at_op(&p3, &Text::lit("->")) {
                (Array::new(), p3.clone())
            } else {
                commas(&p3, &(Rc::new(|a0: Ps| entered(start_parse_emit_type(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, Ps)>>>))
            };
            let (result, p5) = parse_type(&expect_op(&p4, &Text::lit("->")));
            let p6 = out_of_scope(&p5, &start, &Text::lit("indexed choices/GADTs for user types"), &Text::from(format!("`{}` is an indexed alternative: indexed choices for user types are out of this compiler", &name_text(&name))));
            (crate::syntax::Case_ { name: name.clone(), args: args.clone(), indexed: Some(result.clone()), span: to(&start, &prev(&p6)) }, p6.clone())
        }
    } else {
        {
            let (args, p3) = if at_stmt_boundary(&p2) {
                (Array::new(), p2.clone())
            } else {
                commas(&p2, &(Rc::new(|a0: Ps| entered(start_parse_type(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, Ps)>>>))
            };
            (crate::syntax::Case_ { name: name.clone(), args: args.clone(), indexed: None, span: to(&start, &prev(&p3)) }, p3.clone())
        }
    }
}

/// The step machine of `ParseCase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseCase: unbounded fn Ps -> ((Case, Ps))
/// ```
pub struct ParseCase {
    pub p0: Ps,
}

impl prism_rtl::Job<(crate::syntax::Case_, Ps)> for ParseCase {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Case_, Ps)> {
        let p0 = &self.p0;
        let start = here(p0);
        let (name, p1) = parse_sname(p0);
        let p2 = if &name.sigils != &Text::lit("") {
            note_error(&p1, &name.span, &Text::lit("a constructor takes no sigil"))
        } else {
            p1.clone()
        };
        if at_colon(&p2) {
            {
                let p3 = adv(&p2);
                let (args, p4) = if at_op(&p3, &Text::lit("->")) {
                    (Array::new(), p3.clone())
                } else {
                    commas(&p3, &(Rc::new(|a0: Ps| entered(start_parse_emit_type(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, Ps)>>>))
                };
                call_then(start_parse_type(expect_op(&p4, &Text::lit("->"))), move |parse_type_31532: (crate::syntax::Type, Ps)| {
                    let (result, p5) = parse_type_31532;
                    let p6 = out_of_scope(&p5, &start, &Text::lit("indexed choices/GADTs for user types"), &Text::from(format!("`{}` is an indexed alternative: indexed choices for user types are out of this compiler", &name_text(&name))));
                    prism_rtl::Turn::Finished((crate::syntax::Case_ { name: name.clone(), args: args.clone(), indexed: Some(result.clone()), span: to(&start, &prev(&p6)) }, p6.clone()))
                })
            }
        } else {
            {
                let (args, p3) = if at_stmt_boundary(&p2) {
                    (Array::new(), p2.clone())
                } else {
                    commas(&p2, &(Rc::new(|a0: Ps| entered(start_parse_type(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, Ps)>>>))
                };
                prism_rtl::Turn::Finished((crate::syntax::Case_ { name: name.clone(), args: args.clone(), indexed: None, span: to(&start, &prev(&p3)) }, p3.clone()))
            }
        }
    }
}

/// `Start ParseCase, x`: what the function value is when passed to `@Run`.
pub fn start_parse_case(p0: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Case_, Ps)>> {
    Rc::new(ParseCase { p0 })
}

/// ```prism
/// ParseTagDecl: unbounded fn Ps -> ((TagDecl, Ps))
/// ```
pub fn parse_tag_decl(p0: &Ps) -> (crate::syntax::TagDecl, Ps) {
    let start = here(p0);
    let (name, p1) = parse_qual_name(&adv(p0));
    let (of_type, p2) = parse_type(&expect_kw(&p1, &Text::lit("of")));
    let (bounds, p3) = optional_bounds(&p2);
    let (fields, p4) = if at_colon(&p3) { parse_field_block(&p3) } else { (Array::new(), p3.clone()) };
    (crate::syntax::TagDecl { name: name.clone(), of_type: of_type.clone(), bounds: bounds.clone(), fields: fields.clone(), span: to(&start, &prev(&p4)) }, p4.clone())
}

/// The step machine of `ParseTagDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTagDecl: unbounded fn Ps -> ((TagDecl, Ps))
/// ```
pub struct ParseTagDecl {
    pub p0: Ps,
}

impl prism_rtl::Job<(crate::syntax::TagDecl, Ps)> for ParseTagDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::TagDecl, Ps)> {
        let p0 = &self.p0;
        let start = here(p0);
        let (name, p1) = parse_qual_name(&adv(p0));
        call_then(start_parse_type(expect_kw(&p1, &Text::lit("of"))), move |parse_type_32236: (crate::syntax::Type, Ps)| {
            let (of_type, p2) = parse_type_32236;
            call_then(start_optional_bounds(p2.clone()), move |optional_bounds_32291: (Array<crate::syntax::Bound>, Ps)| {
                let (bounds, p3) = optional_bounds_32291;
                let (fields, p4) = if at_colon(&p3) { parse_field_block(&p3) } else { (Array::new(), p3.clone()) };
                prism_rtl::Turn::Finished((crate::syntax::TagDecl { name: name.clone(), of_type: of_type.clone(), bounds: bounds.clone(), fields: fields.clone(), span: to(&start, &prev(&p4)) }, p4.clone()))
            })
        })
    }
}

/// `Start ParseTagDecl, x`: what the function value is when passed to `@Run`.
pub fn start_parse_tag_decl(p0: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::TagDecl, Ps)>> {
    Rc::new(ParseTagDecl { p0 })
}

/// ```prism
/// ParseTraitDecl: unbounded fn Ps -> ((TraitDecl, Ps))
/// ```
pub fn parse_trait_decl(p0: &Ps) -> (crate::syntax::TraitDecl, Ps) {
    let start = here(p0);
    let (name, p1) = parse_trait_ref(&adv(p0));
    let (params, p2) = lower_params(&p1);
    let (bounds, p3) = optional_bounds(&p2);
    let (items, p4) = parse_trait_items(&p3);
    let decl = crate::syntax::TraitDecl { name: name.clone(), params: params.clone(), bounds: bounds.clone(), items: items.clone(), span: to(&start, &prev(&p4)) };
    (decl.clone(), check_higher_kinded(&p4, &decl))
}

/// The step machine of `ParseTraitDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTraitDecl: unbounded fn Ps -> ((TraitDecl, Ps))
/// ```
pub struct ParseTraitDecl {
    pub p0: Ps,
}

impl prism_rtl::Job<(crate::syntax::TraitDecl, Ps)> for ParseTraitDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::TraitDecl, Ps)> {
        let p0 = &self.p0;
        let start = here(p0);
        let (name, p1) = parse_trait_ref(&adv(p0));
        let (params, p2) = lower_params(&p1);
        call_then(start_optional_bounds(p2.clone()), move |optional_bounds_32749: (Array<crate::syntax::Bound>, Ps)| {
            let (bounds, p3) = optional_bounds_32749;
            call_then(start_parse_trait_items(p3.clone()), move |parse_trait_items_32791: (Array<crate::syntax::TraitItem>, Ps)| {
                let (items, p4) = parse_trait_items_32791;
                let decl = crate::syntax::TraitDecl { name: name.clone(), params: params.clone(), bounds: bounds.clone(), items: items.clone(), span: to(&start, &prev(&p4)) };
                prism_rtl::Turn::Finished((decl.clone(), check_higher_kinded(&p4, &decl)))
            })
        })
    }
}

/// `Start ParseTraitDecl, x`: what the function value is when passed to `@Run`.
pub fn start_parse_trait_decl(p0: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::TraitDecl, Ps)>> {
    Rc::new(ParseTraitDecl { p0 })
}

/// ```prism
/// ParseImplDecl: unbounded fn Ps -> ((ImplDecl, Ps))
/// ```
pub fn parse_impl_decl(p0: &Ps) -> (crate::syntax::ImplDecl, Ps) {
    let start = here(p0);
    let (trait_ref, p1) = parse_trait_ref(&adv(p0));
    let (ty, p2) = parse_type(&p1);
    let (bounds, p3) = optional_bounds(&p2);
    let (items, p4) = parse_trait_items(&p3);
    (crate::syntax::ImplDecl { trait_ref: trait_ref.clone(), ty: ty.clone(), bounds: bounds.clone(), items: items.clone(), span: to(&start, &prev(&p4)) }, p4.clone())
}

/// The step machine of `ParseImplDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseImplDecl: unbounded fn Ps -> ((ImplDecl, Ps))
/// ```
pub struct ParseImplDecl {
    pub p0: Ps,
}

impl prism_rtl::Job<(crate::syntax::ImplDecl, Ps)> for ParseImplDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::ImplDecl, Ps)> {
        let p0 = &self.p0;
        let start = here(p0);
        let (trait_ref, p1) = parse_trait_ref(&adv(p0));
        call_then(start_parse_type(p1.clone()), move |parse_type_33177: (crate::syntax::Type, Ps)| {
            let (ty, p2) = parse_type_33177;
            call_then(start_optional_bounds(p2.clone()), move |optional_bounds_33215: (Array<crate::syntax::Bound>, Ps)| {
                let (bounds, p3) = optional_bounds_33215;
                call_then(start_parse_trait_items(p3.clone()), move |parse_trait_items_33257: (Array<crate::syntax::TraitItem>, Ps)| {
                    let (items, p4) = parse_trait_items_33257;
                    prism_rtl::Turn::Finished((crate::syntax::ImplDecl { trait_ref: trait_ref.clone(), ty: ty.clone(), bounds: bounds.clone(), items: items.clone(), span: to(&start, &prev(&p4)) }, p4.clone()))
                })
            })
        })
    }
}

/// `Start ParseImplDecl, x`: what the function value is when passed to `@Run`.
pub fn start_parse_impl_decl(p0: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::ImplDecl, Ps)>> {
    Rc::new(ParseImplDecl { p0 })
}

/// ```prism
/// ParseTraitItems: unbounded fn Ps -> (([TraitItem], Ps))
/// ```
pub fn parse_trait_items(p0: &Ps) -> (Array<crate::syntax::TraitItem>, Ps) {
    let p_ = expect_colon(p0);
    if at_open_l(&p_) {
        {
            let inside = {
                let mut this: Ps = adv(&p_);
                this.in_trait = true;
                this
            };
            let (items, q) = layout_items(&inside, &(Rc::new(|a0: Ps| entered(start_parse_trait_item(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::TraitItem, Ps)>>>));
            (items.clone(), {
                let mut this: Ps = q.clone();
                this.in_trait = p_.in_trait;
                this
            })
        }
    } else {
        (Array::new(), error_here(&p_, &Text::lit("a trait's or impl's items stand in an indented block")))
    }
}

/// The step machine of `ParseTraitItems`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTraitItems: unbounded fn Ps -> (([TraitItem], Ps))
/// ```
pub struct ParseTraitItems {
    pub p0: Ps,
}

impl prism_rtl::Job<(Array<crate::syntax::TraitItem>, Ps)> for ParseTraitItems {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::TraitItem>, Ps)> {
        let p0 = &self.p0;
        let p_ = expect_colon(p0);
        if at_open_l(&p_) {
            {
                let inside = {
                    let mut this: Ps = adv(&p_);
                    this.in_trait = true;
                    this
                };
                call_then(start_layout_items(inside.clone(), Rc::new(|a0: Ps| entered(start_parse_trait_item(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::TraitItem, Ps)>>>), move |layout_items_33599: (Array<crate::syntax::TraitItem>, Ps)| {
                    let (items, q) = layout_items_33599;
                    prism_rtl::Turn::Finished((items.clone(), {
                        let mut this: Ps = q.clone();
                        this.in_trait = p_.in_trait;
                        this
                    }))
                })
            }
        } else {
            prism_rtl::Turn::Finished((Array::new(), error_here(&p_, &Text::lit("a trait's or impl's items stand in an indented block"))))
        }
    }
}

/// `Start ParseTraitItems, x`: what the function value is when passed to `@Run`.
pub fn start_parse_trait_items(p0: Ps) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::TraitItem>, Ps)>> {
    Rc::new(ParseTraitItems { p0 })
}

/// ```prism
/// ParseTraitItem: unbounded fn Ps -> ((TraitItem, Ps))
/// ```
pub fn parse_trait_item(p_: &Ps) -> (crate::syntax::TraitItem, Ps) {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KKw(m33867_0_0, _) if (&m33867_0_0 == &Text::lit("fn")) => {
            let (f, q) = parse_fn_clause(p_);
            (crate::syntax::TraitItem::TiFn(f.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m33867_1_0, _) if (&m33867_1_0 == &Text::lit("type")) => {
            let start = here(p_);
            let p1 = adv(p_);
            match kind(&p1) {
                crate::syntax::lexer::TokKind::KName(n) if (((&n.case == &crate::syntax::lexer::NameCase::CaseUpper) && (&n.sigils == &Text::lit(""))) && (&len(&n.path_) == &Nat::from(1u32))) => {
                    let name = crate::syntax::Ident { name: or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")), span: here(&p1) };
                    let (params, p2) = lower_params(&adv(&p1));
                    let (value_opt, p3) = if at_op(&p2, &Text::lit("=")) { optional_type(&adv(&p2)) } else { (None, p2.clone()) };
                    let item = crate::syntax::TraitItem::TiAssocType(name.clone(), params.clone(), value_opt.clone(), to(&start, &prev(&p3)));
                    (item.clone(), p3.clone())
                },
                _ => {
                    let item = crate::syntax::TraitItem::TiAssocType(no_ident(), Array::new(), None, no_range());
                    (item.clone(), error_here(&p1, &Text::lit("expected the associated type's name")))
                },
                _ => unreachable!("no arm matched"),
            }
        },
        crate::syntax::lexer::TokKind::KKw(m33867_2_0, _) if (&m33867_2_0 == &Text::lit("row")) => {
            let start = here(p_);
            let (name, q) = parse_sname(&adv(p_));
            let item = crate::syntax::TraitItem::TiAssocRow(name.clone(), to(&start, &prev(&q)));
            (item.clone(), q.clone())
        },
        _ => {
            let (sig, q) = parse_signature(p_);
            (crate::syntax::TraitItem::TiSignature(sig.clone()), q.clone())
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ParseTraitItem`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTraitItem: unbounded fn Ps -> ((TraitItem, Ps))
/// ```
pub struct ParseTraitItem {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::TraitItem, Ps)> for ParseTraitItem {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::TraitItem, Ps)> {
        let p_ = &self.p_;
        match kind(p_) {
            crate::syntax::lexer::TokKind::KKw(m33867_0_0, _) if (&m33867_0_0 == &Text::lit("fn")) => {
                let p_ = p_.clone();
                call_then(start_parse_fn_clause(p_.clone()), move |parse_fn_clause_33926: (crate::syntax::FnClause, Ps)| {
                    let (f, q) = parse_fn_clause_33926;
                    prism_rtl::Turn::Finished((crate::syntax::TraitItem::TiFn(f.clone()), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m33867_1_0, _) if (&m33867_1_0 == &Text::lit("type")) => {
                let start = here(p_);
                let p1 = adv(p_);
                match kind(&p1) {
                    crate::syntax::lexer::TokKind::KName(n) if (((&n.case == &crate::syntax::lexer::NameCase::CaseUpper) && (&n.sigils == &Text::lit(""))) && (&len(&n.path_) == &Nat::from(1u32))) => {
                        let name = crate::syntax::Ident { name: or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")), span: here(&p1) };
                        let (params, p2) = lower_params(&adv(&p1));
                        let (value_opt, p3) = if at_op(&p2, &Text::lit("=")) { optional_type(&adv(&p2)) } else { (None, p2.clone()) };
                        let item = crate::syntax::TraitItem::TiAssocType(name.clone(), params.clone(), value_opt.clone(), to(&start, &prev(&p3)));
                        prism_rtl::Turn::Finished((item.clone(), p3.clone()))
                    },
                    _ => {
                        let item = crate::syntax::TraitItem::TiAssocType(no_ident(), Array::new(), None, no_range());
                        prism_rtl::Turn::Finished((item.clone(), error_here(&p1, &Text::lit("expected the associated type's name"))))
                    },
                    _ => unreachable!("no arm matched"),
                }
            },
            crate::syntax::lexer::TokKind::KKw(m33867_2_0, _) if (&m33867_2_0 == &Text::lit("row")) => {
                let start = here(p_);
                let (name, q) = parse_sname(&adv(p_));
                let item = crate::syntax::TraitItem::TiAssocRow(name.clone(), to(&start, &prev(&q)));
                prism_rtl::Turn::Finished((item.clone(), q.clone()))
            },
            _ => {
                let p_ = p_.clone();
                call_then(start_parse_signature(p_.clone()), move |parse_signature_34866: (crate::syntax::Signature, Ps)| {
                    let (sig, q) = parse_signature_34866;
                    prism_rtl::Turn::Finished((crate::syntax::TraitItem::TiSignature(sig.clone()), q.clone()))
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ParseTraitItem, x`: what the function value is when passed to `@Run`.
pub fn start_parse_trait_item(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::TraitItem, Ps)>> {
    Rc::new(ParseTraitItem { p_ })
}

/// ```prism
/// OptionalType: unbounded fn Ps -> ((?Type, Ps))
/// ```
pub fn optional_type(p_: &Ps) -> (Option<crate::syntax::Type>, Ps) {
    let (ty, q) = parse_type(p_);
    (Some(ty.clone()), q.clone())
}

/// The step machine of `OptionalType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptionalType: unbounded fn Ps -> ((?Type, Ps))
/// ```
pub struct OptionalType {
    pub p_: Ps,
}

impl prism_rtl::Job<(Option<crate::syntax::Type>, Ps)> for OptionalType {
    fn cycle(&self) -> prism_rtl::Turn<(Option<crate::syntax::Type>, Ps)> {
        let p_ = &self.p_;
        let p_ = p_.clone();
        call_then(start_parse_type(p_.clone()), move |parse_type_35001: (crate::syntax::Type, Ps)| {
            let (ty, q) = parse_type_35001;
            prism_rtl::Turn::Finished((Some(ty.clone()), q.clone()))
        })
    }
}

/// `Start OptionalType, x`: what the function value is when passed to `@Run`.
pub fn start_optional_type(p_: Ps) -> Rc<dyn prism_rtl::Job<(Option<crate::syntax::Type>, Ps)>> {
    Rc::new(OptionalType { p_ })
}

/// ```prism
/// CheckHigherKinded: fn Ps, TraitDecl -> Ps
/// ```
pub fn check_higher_kinded(p_: &Ps, t: &crate::syntax::TraitDecl) -> Ps {
    let hk = fold(&t.items, &false, &(|seen: &bool, item: &crate::syntax::TraitItem| *seen || item_applies(item, &t.params)));
    if hk && (&t.name.path_ != &Array::from(vec![Text::lit("Monad")])) {
        out_of_scope(p_, &t.name.span, &Text::lit("higher-kinded traits"), &Text::from(format!("`^{}` applies its parameter to arguments: higher-kinded traits are out of this compiler", &crate::syntax::lexer::join(&t.name.path_, &Text::lit(".")))))
    } else {
        p_.clone()
    }
}

/// ```prism
/// ItemApplies: fn TraitItem, [Ident] -> Bool
/// ```
pub fn item_applies(trait_item0: &crate::syntax::TraitItem, xs1: &Array<crate::syntax::Ident>) -> bool {
    match (trait_item0, xs1) {
        (crate::syntax::TraitItem::TiSignature(s), params) => applies(&s.ty, params),
        (_, _) => false,
    }
}

/// ```prism
/// AnyApplies: fn [Type], [Ident] -> Bool
/// ```
pub fn any_applies(ts: &Array<crate::syntax::Type>, params: &Array<crate::syntax::Ident>) -> bool {
    fold(ts, &false, &(|seen: &bool, t: &crate::syntax::Type| *seen || applies(t, params)))
}

/// ```prism
/// Applies: fn Type, [Ident] -> Bool
/// ```
pub fn applies(ty: &crate::syntax::Type, params: &Array<crate::syntax::Ident>) -> bool {
    match &*ty.kind {
        crate::syntax::TypeKind::TName(name, args) => {
            let head = ((&len(args) > &Nat::from(0u32)) && (&len(&name.path_) == &Nat::from(1u32))) && fold(params, &false, &(|seen: &bool, i: &crate::syntax::Ident| *seen || (&i.name == &or(&index(&name.path_, &Nat::from(0u32)), &Text::lit("")))));
            head || any_applies(args, params)
        },
        crate::syntax::TypeKind::TSigiled(_, inner) => applies(&**inner, params),
        crate::syntax::TypeKind::TGroup(inner) => applies(&**inner, params),
        crate::syntax::TypeKind::TNonEmpty(inner) => applies(&**inner, params),
        crate::syntax::TypeKind::TArray(elem, _) => applies(&**elem, params),
        crate::syntax::TypeKind::TTuple(ts) => any_applies(ts, params),
        crate::syntax::TypeKind::TRowUnion(ts) => any_applies(ts, params),
        crate::syntax::TypeKind::TMap(k, v_) => applies(&**k, params) || applies(&**v_, params),
        crate::syntax::TypeKind::TFn(_, ps, result) => any_applies(ps, params) || applies(&**result, params),
        crate::syntax::TypeKind::TEmit(t, r) => applies(&**t, params) || applies(&**r, params),
        _ => false,
    }
}

/// ```prism
/// ParseExpr: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_expr(p_: &Ps) -> (crate::syntax::Expr, Ps) {
    parse_expr_ctx(p_, &true)
}

/// The step machine of `ParseExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseExpr: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseExpr {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, Ps)> for ParseExpr {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, Ps)> {
        let p_ = &self.p_;
        prism_rtl::Turn::More(Rc::new(ParseExprCtx { p_: p_.clone(), commas_: true }))
    }
}

/// `Start ParseExpr, x`: what the function value is when passed to `@Run`.
pub fn start_parse_expr(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, Ps)>> {
    Rc::new(ParseExpr { p_ })
}

/// ```prism
/// ParseArgExpr: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_arg_expr(p_: &Ps) -> (crate::syntax::Expr, Ps) {
    parse_expr_ctx(p_, &false)
}

/// The step machine of `ParseArgExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseArgExpr: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseArgExpr {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, Ps)> for ParseArgExpr {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, Ps)> {
        let p_ = &self.p_;
        prism_rtl::Turn::More(Rc::new(ParseExprCtx { p_: p_.clone(), commas_: false }))
    }
}

/// `Start ParseArgExpr, x`: what the function value is when passed to `@Run`.
pub fn start_parse_arg_expr(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, Ps)>> {
    Rc::new(ParseArgExpr { p_ })
}

/// ```prism
/// ParseExprCtx: unbounded fn Ps, Bool -> ((Expr, Ps))
/// ```
pub fn parse_expr_ctx(p_: &Ps, commas_: &bool) -> (crate::syntax::Expr, Ps) {
    parse_binary(p_, &Nat::from(4u32), &(*commas_ && !p_.step_mode))
}

/// The step machine of `ParseExprCtx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseExprCtx: unbounded fn Ps, Bool -> ((Expr, Ps))
/// ```
pub struct ParseExprCtx {
    pub p_: Ps,
    pub commas_: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, Ps)> for ParseExprCtx {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, Ps)> {
        let p_ = &self.p_;
        let commas_ = &self.commas_;
        prism_rtl::Turn::More(Rc::new(ParseBinary { p0: p_.clone(), min_: Nat::from(4u32), commas_: *commas_ && !p_.step_mode }))
    }
}

/// `Start ParseExprCtx, x`: what the function value is when passed to `@Run`.
pub fn start_parse_expr_ctx(p_: Ps, commas_: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, Ps)>> {
    Rc::new(ParseExprCtx { p_, commas_ })
}

/// ```prism
/// ParseRhsExpr: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_rhs_expr(p0: &Ps) -> (crate::syntax::Expr, Ps) {
    let mut this: (crate::syntax::Expr, Ps) = parse_expr(p0);
    let (e0, p1) = this.clone();
    let mut e: crate::syntax::Expr = e0.clone();
    let mut p_: Ps = p1.clone();
    while at_line_method(&p_) {
        let (method, p2) = parse_sname(&adv(&p_));
        let (args, p3) = if arg_starts_here(&p2) {
            parse_call_args(&p2, &true)
        } else {
            (Array::new(), p2.clone())
        };
        e = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMethod(Rc::new(e.clone()), method.clone(), args.clone())), span: to(&e.span, &prev(&p3)) };
        p_ = p3.clone();
    }
    this = (e.clone(), p_.clone());
    this
}

/// The step machine of `ParseRhsExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseRhsExpr: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseRhsExpr {
    pub p0: Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, Ps)> for ParseRhsExpr {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, Ps)> {
        let p0 = &self.p0;
        let mut this: (crate::syntax::Expr, Ps) = parse_expr(p0);
        let (e0, p1) = this.clone();
        let mut e: crate::syntax::Expr = e0.clone();
        let mut p_: Ps = p1.clone();
        call_then(loop_job((this, e, p_), move |(mut this, mut e, mut p_): ((crate::syntax::Expr, Ps), crate::syntax::Expr, Ps)| if at_line_method(&p_) {
            {
                let (method, p2) = parse_sname(&adv(&p_));
                let (args, p3) = if arg_starts_here(&p2) {
                    parse_call_args(&p2, &true)
                } else {
                    (Array::new(), p2.clone())
                };
                e = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMethod(Rc::new(e.clone()), method.clone(), args.clone())), span: to(&e.span, &prev(&p3)) };
                p_ = p3.clone();
                Ok((this, e, p_))
            }
        } else {
            Err((this, e, p_))
        }), move |(mut this, mut e, mut p_): ((crate::syntax::Expr, Ps), crate::syntax::Expr, Ps)| {
            this = (e.clone(), p_.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start ParseRhsExpr, x`: what the function value is when passed to `@Run`.
pub fn start_parse_rhs_expr(p0: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, Ps)>> {
    Rc::new(ParseRhsExpr { p0 })
}

/// ```prism
/// AtLineMethod: fn Ps -> Bool
/// ```
pub fn at_line_method(p_: &Ps) -> bool {
    ((&kind(p_) == &crate::syntax::lexer::TokKind::KDot(true)) && tk(p_).line_start) && is_plain_upper(&kind_at(p_, &Nat::from(1u32)))
}

/// ```prism
/// IsPlainUpper: fn TokKind -> Bool
/// ```
pub fn is_plain_upper(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KName(n) => (&n.case == &crate::syntax::lexer::NameCase::CaseUpper) && (&n.sigils == &Text::lit("")),
        _ => false,
    }
}

/// ```prism
/// IsUpperTok: fn TokKind -> Bool
/// ```
pub fn is_upper_tok(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KName(n) => &n.case == &crate::syntax::lexer::NameCase::CaseUpper,
        _ => false,
    }
}

/// ```prism
/// ?PeekBinop: fn Ps -> ?((Text, ?[Text]))
/// ```
pub fn peek_binop(p_: &Ps) -> Option<(Text, Option<Array<Text>>)> {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KOp(op, prefix) if (!prefix || (&op == &Text::lit("-?"))) => if is_binop(&op) { Some((op.clone(), None)) } else { None },
        crate::syntax::lexer::TokKind::KSuffixed(op, ty) => if is_binop(&op) { Some((op.clone(), Some(ty.clone()))) } else { None },
        crate::syntax::lexer::TokKind::KKw(m38968_2_0, m38968_2_1) if (&m38968_2_0 == &Text::lit("on")) && (&m38968_2_1 == &Text::lit("")) => Some((Text::lit("on"), None)),
        crate::syntax::lexer::TokKind::KKw(m38968_3_0, m38968_3_1) if (&m38968_3_0 == &Text::lit("or")) && (&m38968_3_1 == &Text::lit("")) => Some((Text::lit("or"), None)),
        crate::syntax::lexer::TokKind::KKw(m38968_4_0, m38968_4_1) if (&m38968_4_0 == &Text::lit("and")) && (&m38968_4_1 == &Text::lit("")) => Some((Text::lit("and"), None)),
        crate::syntax::lexer::TokKind::KKw(m38968_5_0, m38968_5_1) if (&m38968_5_0 == &Text::lit("mod")) && (&m38968_5_1 == &Text::lit("")) => Some((Text::lit("mod"), None)),
        _ => None,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IsBinop: fn Text -> Bool
/// ```
pub fn is_binop(op: &Text) -> bool {
    fold(&Array::from(vec![Text::lit("<|"), Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit("<="), Text::lit(">"), Text::lit(">="), Text::lit("+"), Text::lit("-"), Text::lit("+?"), Text::lit("-?"), Text::lit("*"), Text::lit("/"), Text::lit("*?")]), &false, &(|seen: &bool, o: &Text| *seen || (o == op)))
}

/// ```prism
/// Level: fn Text -> Nat
/// ```
pub fn level(text0: &Text) -> Nat {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("<|")) => Nat::from(4u32),
        c1_0 if (c1_0 == &Text::lit("on")) => Nat::from(5u32),
        c2_0 if (c2_0 == &Text::lit("or")) => Nat::from(6u32),
        c3_0 if (c3_0 == &Text::lit("and")) => Nat::from(7u32),
        c4_0 if (c4_0 == &Text::lit("+")) => Nat::from(10u32),
        c5_0 if (c5_0 == &Text::lit("-")) => Nat::from(10u32),
        c6_0 if (c6_0 == &Text::lit("+?")) => Nat::from(10u32),
        c7_0 if (c7_0 == &Text::lit("-?")) => Nat::from(10u32),
        c8_0 if (c8_0 == &Text::lit("*")) => Nat::from(11u32),
        c9_0 if (c9_0 == &Text::lit("/")) => Nat::from(11u32),
        c10_0 if (c10_0 == &Text::lit("*?")) => Nat::from(11u32),
        c11_0 if (c11_0 == &Text::lit("mod")) => Nat::from(11u32),
        _ => Nat::from(9u32),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParseBinary: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
/// ```
pub fn parse_binary(p0: &Ps, min_: &Nat, commas_: &bool) -> (crate::syntax::Expr, Ps) {
    let (lhs, p1) = parse_prefix(p0, min_, commas_);
    let r = {
        let mut this: Climb = Climb { lhs: lhs.clone(), p_: p1.clone(), going: true };
        while this.going && !this.p_.bad {
            this = climb_step(&this, min_, commas_);
        }
        this
    };
    (r.lhs.clone(), r.p_.clone())
}

/// The step machine of `ParseBinary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseBinary: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
/// ```
pub struct ParseBinary {
    pub p0: Ps,
    pub min_: Nat,
    pub commas_: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, Ps)> for ParseBinary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, Ps)> {
        let p0 = &self.p0;
        let min_ = &self.min_;
        let commas_ = &self.commas_;
        let commas_ = *commas_;
        let min_ = min_.clone();
        let p0 = p0.clone();
        call_then(start_parse_prefix(p0.clone(), min_.clone(), commas_), move |parse_prefix_40236: (crate::syntax::Expr, Ps)| {
            let (lhs, p1) = parse_prefix_40236;
            let mut this: Climb = Climb { lhs: lhs.clone(), p_: p1.clone(), going: true };
            let lhs = lhs.clone();
            call_then(loop_job((this,), {
                let commas_ = commas_;
                let min_ = min_.clone();
                move |(mut this,): (Climb,)| if this.going && !this.p_.bad {
                    {
                        this = climb_step(&this, &min_, &commas_);
                        Ok((this,))
                    }
                } else {
                    Err((this,))
                }
            }), move |(mut this,): (Climb,)| {
                let r = this;
                prism_rtl::Turn::Finished((r.lhs.clone(), r.p_.clone()))
            })
        })
    }
}

/// `Start ParseBinary, x`: what the function value is when passed to `@Run`.
pub fn start_parse_binary(p0: Ps, min_: Nat, commas_: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, Ps)>> {
    Rc::new(ParseBinary { p0, min_, commas_ })
}

/// ```prism
/// ClimbStep: unbounded fn Climb, Nat, Bool -> Climb
/// ```
pub fn climb_step(c: &Climb, min_: &Nat, commas_: &bool) -> Climb {
    let p_ = c.p_.clone();
    if at_kw(&p_, &Text::lit("as")) && (min_ <= &Nat::from(12u32)) {
        {
            let (ty, p2) = parse_type(&adv(&p_));
            let checked = (&kind(&p2) == &crate::syntax::lexer::TokKind::KFree(Text::lit("?"))) && tk(&p2).touches;
            let p3 = if checked { adv(&p2) } else { p2.clone() };
            {
                let mut this: Climb = c.clone();
                this.lhs = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECast(Rc::new(this.lhs.clone()), ty.clone(), checked)), span: to(&this.lhs.span, &prev(&p3)) };
                this.p_ = p3.clone();
                this
            }
        }
    } else {
        match peek_binop(&p_) {
            None => {
                let mut this: Climb = c.clone();
                this.going = false;
                this.p_ = no_operator(&p_);
                this
            },
            Some((op, suffix_opt)) => if &level(&op) < min_ {
                {
                    let mut this: Climb = c.clone();
                    this.going = false;
                    this
                }
            } else {
                {
                    let p1 = if &kind(&p_) == &crate::syntax::lexer::TokKind::KOp(Text::lit("-?"), true) {
                        note_error(&p_, &here(&p_), &Text::lit("`-?` is the checked subtraction by longest match; to subtract or negate an optional, write `-(?x)`"))
                    } else {
                        p_.clone()
                    };
                    let op_tok = tk(&p1);
                    let (rhs, p2) = parse_binary(&adv(&p1), &(&level(&op) + &Nat::from(1u32)), commas_);
                    let span = to(&c.lhs.span, &rhs.span);
                    let kind_ = match &suffix_opt {
                        None => crate::syntax::ExprKind::EBinary(op.clone(), Rc::new(c.lhs.clone()), Rc::new(rhs.clone())),
                        Some(ty) => crate::syntax::ExprKind::ESuffixed(op.clone(), crate::syntax::QualName { path_: ty.clone(), span: op_tok.span.clone() }, Rc::new(c.lhs.clone()), Rc::new(rhs.clone())),
                    };
                    let p3 = if &suffix_opt == &None {
                        p2.clone()
                    } else {
                        out_of_scope(&p2, &op_tok.span, &Text::lit("suffixed operators"), &Text::from(format!("the suffixed operator `{}` is out of this compiler", &crate::syntax::lexer::token_text(&op_tok.kind))))
                    };
                    {
                        let mut this: Climb = c.clone();
                        this.lhs = crate::syntax::Expr { kind: Rc::new(kind_.clone()), span: span.clone() };
                        this.p_ = p3.clone();
                        this
                    }
                }
            },
        }
    }
}

/// The step machine of `ClimbStep`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClimbStep: unbounded fn Climb, Nat, Bool -> Climb
/// ```
pub struct ClimbStep {
    pub c: Climb,
    pub min_: Nat,
    pub commas_: bool,
}

impl prism_rtl::Job<Climb> for ClimbStep {
    fn cycle(&self) -> prism_rtl::Turn<Climb> {
        let c = &self.c;
        let min_ = &self.min_;
        let commas_ = &self.commas_;
        let p_ = c.p_.clone();
        if at_kw(&p_, &Text::lit("as")) && (min_ <= &Nat::from(12u32)) {
            {
                let c = c.clone();
                call_then(start_parse_type(adv(&p_)), move |parse_type_40632: (crate::syntax::Type, Ps)| {
                    let (ty, p2) = parse_type_40632;
                    let checked = (&kind(&p2) == &crate::syntax::lexer::TokKind::KFree(Text::lit("?"))) && tk(&p2).touches;
                    let p3 = if checked { adv(&p2) } else { p2.clone() };
                    prism_rtl::Turn::Finished({
                        let mut this: Climb = c.clone();
                        this.lhs = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECast(Rc::new(this.lhs.clone()), ty.clone(), checked)), span: to(&this.lhs.span, &prev(&p3)) };
                        this.p_ = p3.clone();
                        this
                    })
                })
            }
        } else {
            match peek_binop(&p_) {
                None => prism_rtl::Turn::Finished({
                    let mut this: Climb = c.clone();
                    this.going = false;
                    this.p_ = no_operator(&p_);
                    this
                }),
                Some((op, suffix_opt)) => if &level(&op) < min_ {
                    prism_rtl::Turn::Finished({
                        let mut this: Climb = c.clone();
                        this.going = false;
                        this
                    })
                } else {
                    {
                        let p1 = if &kind(&p_) == &crate::syntax::lexer::TokKind::KOp(Text::lit("-?"), true) {
                            note_error(&p_, &here(&p_), &Text::lit("`-?` is the checked subtraction by longest match; to subtract or negate an optional, write `-(?x)`"))
                        } else {
                            p_.clone()
                        };
                        let op_tok = tk(&p1);
                        let c = c.clone();
                        let commas_ = *commas_;
                        call_then(start_parse_binary(adv(&p1), &level(&op) + &Nat::from(1u32), commas_), move |parse_binary_41544: (crate::syntax::Expr, Ps)| {
                            let (rhs, p2) = parse_binary_41544;
                            let span = to(&c.lhs.span, &rhs.span);
                            let kind_ = match &suffix_opt {
                                None => crate::syntax::ExprKind::EBinary(op.clone(), Rc::new(c.lhs.clone()), Rc::new(rhs.clone())),
                                Some(ty) => crate::syntax::ExprKind::ESuffixed(op.clone(), crate::syntax::QualName { path_: ty.clone(), span: op_tok.span.clone() }, Rc::new(c.lhs.clone()), Rc::new(rhs.clone())),
                            };
                            let p3 = if &suffix_opt == &None {
                                p2.clone()
                            } else {
                                out_of_scope(&p2, &op_tok.span, &Text::lit("suffixed operators"), &Text::from(format!("the suffixed operator `{}` is out of this compiler", &crate::syntax::lexer::token_text(&op_tok.kind))))
                            };
                            prism_rtl::Turn::Finished({
                                let mut this: Climb = c.clone();
                                this.lhs = crate::syntax::Expr { kind: Rc::new(kind_.clone()), span: span.clone() };
                                this.p_ = p3.clone();
                                this
                            })
                        })
                    }
                },
            }
        }
    }
}

/// `Start ClimbStep, x`: what the function value is when passed to `@Run`.
pub fn start_climb_step(c: Climb, min_: Nat, commas_: bool) -> Rc<dyn prism_rtl::Job<Climb>> {
    Rc::new(ClimbStep { c, min_, commas_ })
}

/// ```prism
/// NoOperator: fn Ps -> Ps
/// ```
pub fn no_operator(p_: &Ps) -> Ps {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KOp(o, true) if (((&o == &Text::lit("-")) || (&o == &Text::lit("+"))) && !tk(p_).line_start) => error_at(p_, &here(p_), &Text::from(format!("`{}` here is a prefix sign by the spacing rule (a space before it and none after); did you mean `a {} 1`, with spaces on both sides?", &o, &o))),
        crate::syntax::lexer::TokKind::KBar => error_at(p_, &here(p_), &Text::lit("a bare `|` is not an operator: the merge is `<|`, and `|` separates the families of a row")),
        crate::syntax::lexer::TokKind::KDot(true) if (!at_line_method(p_) && is_upper_tok(&kind_at(p_, &Nat::from(1u32)))) => error_at(p_, &here(p_), &Text::lit("a spaced `.Method` begins its own line, below the call it takes as its receiver (layout rule 9)")),
        _ => p_.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParsePrefix: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
/// ```
pub fn parse_prefix(p_: &Ps, min_: &Nat, commas_: &bool) -> (crate::syntax::Expr, Ps) {
    let start = here(p_);
    if at_kw(p_, &Text::lit("not")) {
        {
            let (operand, q) = parse_binary(&adv(p_), &max(&Nat::from(9u32), min_), commas_);
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EUnary(Text::lit("not"), Rc::new(operand.clone()))), span: to(&start, &operand.span) }, q.clone())
        }
    } else {
        match kind(p_) {
            crate::syntax::lexer::TokKind::KOp(op, true) if ((&op == &Text::lit("-")) || (&op == &Text::lit("+"))) => {
                let (operand, q) = parse_postfix_expr(&adv(p_), commas_);
                let name = if &op == &Text::lit("-") { Text::lit("neg") } else { Text::lit("pos") };
                (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EUnary(name.clone(), Rc::new(operand.clone()))), span: to(&start, &operand.span) }, q.clone())
            },
            crate::syntax::lexer::TokKind::KOp(m43337_1_0, _) if (&m43337_1_0 == &Text::lit("-?")) => (no_expr(), error_at(p_, &here(p_), &Text::lit("`-?` is the checked subtraction and needs a left operand; to negate an optional write `-(?x)`"))),
            _ => parse_postfix_expr(p_, commas_),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// The step machine of `ParsePrefix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParsePrefix: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
/// ```
pub struct ParsePrefix {
    pub p_: Ps,
    pub min_: Nat,
    pub commas_: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, Ps)> for ParsePrefix {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, Ps)> {
        let p_ = &self.p_;
        let min_ = &self.min_;
        let commas_ = &self.commas_;
        let start = here(p_);
        if at_kw(p_, &Text::lit("not")) {
            {
                let commas_ = *commas_;
                let min_ = min_.clone();
                let p_ = p_.clone();
                call_then(start_parse_binary(adv(&p_), max(&Nat::from(9u32), &min_), commas_), move |parse_binary_43204: (crate::syntax::Expr, Ps)| {
                    let (operand, q) = parse_binary_43204;
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EUnary(Text::lit("not"), Rc::new(operand.clone()))), span: to(&start, &operand.span) }, q.clone()))
                })
            }
        } else {
            match kind(p_) {
                crate::syntax::lexer::TokKind::KOp(op, true) if ((&op == &Text::lit("-")) || (&op == &Text::lit("+"))) => {
                    let commas_ = *commas_;
                    let p_ = p_.clone();
                    call_then(start_parse_postfix_expr(adv(&p_), commas_), move |parse_postfix_expr_43432: (crate::syntax::Expr, Ps)| {
                        let (operand, q) = parse_postfix_expr_43432;
                        let name = if &op == &Text::lit("-") { Text::lit("neg") } else { Text::lit("pos") };
                        prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EUnary(name.clone(), Rc::new(operand.clone()))), span: to(&start, &operand.span) }, q.clone()))
                    })
                },
                crate::syntax::lexer::TokKind::KOp(m43337_1_0, _) if (&m43337_1_0 == &Text::lit("-?")) => prism_rtl::Turn::Finished((no_expr(), error_at(p_, &here(p_), &Text::lit("`-?` is the checked subtraction and needs a left operand; to negate an optional write `-(?x)`")))),
                _ => prism_rtl::Turn::More(Rc::new(ParsePostfixExpr { p_: p_.clone(), commas_: *commas_ })),
                _ => unreachable!("no arm matched"),
            }
        }
    }
}

/// `Start ParsePrefix, x`: what the function value is when passed to `@Run`.
pub fn start_parse_prefix(p_: Ps, min_: Nat, commas_: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, Ps)>> {
    Rc::new(ParsePrefix { p_, min_, commas_ })
}

/// ```prism
/// ParsePostfixExpr: unbounded fn Ps, Bool -> ((Expr, Ps))
/// ```
pub fn parse_postfix_expr(p_: &Ps, commas_: &bool) -> (crate::syntax::Expr, Ps) {
    let (e, took_rest, q) = parse_primary(p_, commas_);
    if took_rest { (e.clone(), q.clone()) } else { parse_postfix(&e, &q, commas_) }
}

/// The step machine of `ParsePostfixExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParsePostfixExpr: unbounded fn Ps, Bool -> ((Expr, Ps))
/// ```
pub struct ParsePostfixExpr {
    pub p_: Ps,
    pub commas_: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, Ps)> for ParsePostfixExpr {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, Ps)> {
        let p_ = &self.p_;
        let commas_ = &self.commas_;
        let commas_ = *commas_;
        let p_ = p_.clone();
        call_then(start_parse_primary(p_.clone(), commas_), move |parse_primary_44039: (crate::syntax::Expr, bool, Ps)| {
            let (e, took_rest, q) = parse_primary_44039;
            if took_rest {
                prism_rtl::Turn::Finished((e.clone(), q.clone()))
            } else {
                prism_rtl::Turn::More(Rc::new(ParsePostfix { e0: e.clone(), p0: q.clone(), commas_ }))
            }
        })
    }
}

/// `Start ParsePostfixExpr, x`: what the function value is when passed to `@Run`.
pub fn start_parse_postfix_expr(p_: Ps, commas_: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, Ps)>> {
    Rc::new(ParsePostfixExpr { p_, commas_ })
}

/// ```prism
/// ParsePostfix: unbounded fn Expr, Ps, Bool -> ((Expr, Ps))
/// ```
pub fn parse_postfix(e0: &crate::syntax::Expr, p0: &Ps, commas_: &bool) -> (crate::syntax::Expr, Ps) {
    let mut this: (crate::syntax::Expr, Ps) = (e0.clone(), p0.clone());
    let mut e: crate::syntax::Expr = e0.clone();
    let mut p_: Ps = p0.clone();
    let mut going: bool = true;
    while going && !p_.bad {
        let (e2, p2, more) = postfix_step(&e, &p_, commas_);
        e = e2.clone();
        p_ = p2.clone();
        going = more;
    }
    this = (e.clone(), p_.clone());
    this
}

/// The step machine of `ParsePostfix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParsePostfix: unbounded fn Expr, Ps, Bool -> ((Expr, Ps))
/// ```
pub struct ParsePostfix {
    pub e0: crate::syntax::Expr,
    pub p0: Ps,
    pub commas_: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, Ps)> for ParsePostfix {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, Ps)> {
        let e0 = &self.e0;
        let p0 = &self.p0;
        let commas_ = &self.commas_;
        let mut this: (crate::syntax::Expr, Ps) = (e0.clone(), p0.clone());
        let mut e: crate::syntax::Expr = e0.clone();
        let mut p_: Ps = p0.clone();
        let mut going: bool = true;
        call_then(loop_job((this, e, going, p_), {
            let commas_ = *commas_;
            move |(mut this, mut e, mut going, mut p_): ((crate::syntax::Expr, Ps), crate::syntax::Expr, bool, Ps)| if going && !p_.bad {
                {
                    let (e2, p2, more) = postfix_step(&e, &p_, &commas_);
                    e = e2.clone();
                    p_ = p2.clone();
                    going = more;
                    Ok((this, e, going, p_))
                }
            } else {
                Err((this, e, going, p_))
            }
        }), move |(mut this, mut e, mut going, mut p_): ((crate::syntax::Expr, Ps), crate::syntax::Expr, bool, Ps)| {
            this = (e.clone(), p_.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start ParsePostfix, x`: what the function value is when passed to `@Run`.
pub fn start_parse_postfix(e0: crate::syntax::Expr, p0: Ps, commas_: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, Ps)>> {
    Rc::new(ParsePostfix { e0, p0, commas_ })
}

/// ```prism
/// PostfixStep: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
/// ```
pub fn postfix_step(e: &crate::syntax::Expr, p_: &Ps, commas_: &bool) -> (crate::syntax::Expr, Ps, bool) {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KDot(false) => field_or_method(e, p_, commas_),
        crate::syntax::lexer::TokKind::KOpen(m44669_1_0, false) if (&m44669_1_0 == &Text::lit("[")) && (tk(p_).touches && !at_double_open(p_, &Text::lit("["))) => {
            let (index, p1) = bracketed(&adv(p_), &(Rc::new(|a0: Ps| entered(start_parse_expr(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, Ps)>>>));
            let p2 = expect_close(&p1, &Text::lit("["));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EIndex(Rc::new(e.clone()), Rc::new(index.clone()))), span: to(&e.span, &prev(&p2)) }, p2.clone(), true)
        },
        crate::syntax::lexer::TokKind::KLtLt => {
            let (types, q) = parse_type_args(p_);
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETypeArgs(Rc::new(e.clone()), types.clone())), span: to(&e.span, &prev(&q)) }, q.clone(), true)
        },
        crate::syntax::lexer::TokKind::KNonEmpty => {
            let span = here(p_);
            let q = out_of_scope(&adv(p_), &span, &Text::lit("non-empty arrays"), &Text::lit("the non-empty mark `+` is out of this compiler"));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ENonEmpty(Rc::new(e.clone()))), span: to(&e.span, &span) }, q.clone(), true)
        },
        _ => (e.clone(), p_.clone(), false),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `PostfixStep`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PostfixStep: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
/// ```
pub struct PostfixStep {
    pub e: crate::syntax::Expr,
    pub p_: Ps,
    pub commas_: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, Ps, bool)> for PostfixStep {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, Ps, bool)> {
        let e = &self.e;
        let p_ = &self.p_;
        let commas_ = &self.commas_;
        match kind(p_) {
            crate::syntax::lexer::TokKind::KDot(false) => prism_rtl::Turn::More(Rc::new(FieldOrMethod { e: e.clone(), p0: p_.clone(), commas_: *commas_ })),
            crate::syntax::lexer::TokKind::KOpen(m44669_1_0, false) if (&m44669_1_0 == &Text::lit("[")) && (tk(p_).touches && !at_double_open(p_, &Text::lit("["))) => {
                let e = e.clone();
                let p_ = p_.clone();
                call_then(start_bracketed(adv(&p_), Rc::new(|a0: Ps| entered(start_parse_expr(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, Ps)>>>), move |bracketed_44824: (crate::syntax::Expr, Ps)| {
                    let (index, p1) = bracketed_44824;
                    let p2 = expect_close(&p1, &Text::lit("["));
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EIndex(Rc::new(e.clone()), Rc::new(index.clone()))), span: to(&e.span, &prev(&p2)) }, p2.clone(), true))
                })
            },
            crate::syntax::lexer::TokKind::KLtLt => {
                let e = e.clone();
                let p_ = p_.clone();
                call_then(start_parse_type_args(p_.clone()), move |parse_type_args_45008: (Array<crate::syntax::Type>, Ps)| {
                    let (types, q) = parse_type_args_45008;
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETypeArgs(Rc::new(e.clone()), types.clone())), span: to(&e.span, &prev(&q)) }, q.clone(), true))
                })
            },
            crate::syntax::lexer::TokKind::KNonEmpty => {
                let span = here(p_);
                let q = out_of_scope(&adv(p_), &span, &Text::lit("non-empty arrays"), &Text::lit("the non-empty mark `+` is out of this compiler"));
                prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ENonEmpty(Rc::new(e.clone()))), span: to(&e.span, &span) }, q.clone(), true))
            },
            _ => prism_rtl::Turn::Finished((e.clone(), p_.clone(), false)),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start PostfixStep, x`: what the function value is when passed to `@Run`.
pub fn start_postfix_step(e: crate::syntax::Expr, p_: Ps, commas_: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, Ps, bool)>> {
    Rc::new(PostfixStep { e, p_, commas_ })
}

/// ```prism
/// FieldOrMethod: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
/// ```
pub fn field_or_method(e: &crate::syntax::Expr, p0: &Ps, commas_: &bool) -> (crate::syntax::Expr, Ps, bool) {
    let dot = here(p0);
    let p_ = adv(p0);
    match kind(&p_) {
        crate::syntax::lexer::TokKind::KName(n) if ((&len(&n.path_) == &Nat::from(1u32)) && ((&n.case == &crate::syntax::lexer::NameCase::CaseLower) || (&n.case == &crate::syntax::lexer::NameCase::CaseTopic))) => {
            let t = here(&p_);
            let field = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EField(Rc::new(e.clone()), n.sigils.clone(), crate::syntax::Ident { name: or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")), span: t.clone() })), span: to(&e.span, &t) };
            let p1 = adv(&p_);
            if arg_starts_here(&p1) && !tk(&p1).line_start {
                {
                    let (args, p2) = parse_call_args(&p1, commas_);
                    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECall(Rc::new(field.clone()), args.clone(), false, false)), span: to(&field.span, &prev(&p2)) }, p2.clone(), false)
                }
            } else {
                (field.clone(), p1.clone(), true)
            }
        },
        crate::syntax::lexer::TokKind::KKw(w, m45501_1_1) if (&m45501_1_1 == &Text::lit("")) && crate::syntax::lexer::is_bound_word(&w) => {
            let t = here(&p_);
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EField(Rc::new(e.clone()), Text::lit(""), crate::syntax::Ident { name: w.clone(), span: t.clone() })), span: to(&e.span, &t) }, adv(&p_), true)
        },
        crate::syntax::lexer::TokKind::KName(n) if ((&n.case == &crate::syntax::lexer::NameCase::CaseUpper) || (&n.case == &crate::syntax::lexer::NameCase::CaseReserved)) => {
            let (method, p1) = parse_sname(&p_);
            let (args, p2) = if arg_starts_here(&p1) {
                parse_call_args(&p1, commas_)
            } else {
                (Array::new(), p1.clone())
            };
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMethod(Rc::new(e.clone()), method.clone(), args.clone())), span: to(&e.span, &prev(&p2)) }, p2.clone(), false)
        },
        _ => (e.clone(), error_at(&p_, &dot, &Text::lit("expected a field name or a `.Method` after `.`")), false),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `FieldOrMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldOrMethod: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
/// ```
pub struct FieldOrMethod {
    pub e: crate::syntax::Expr,
    pub p0: Ps,
    pub commas_: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, Ps, bool)> for FieldOrMethod {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, Ps, bool)> {
        let e = &self.e;
        let p0 = &self.p0;
        let commas_ = &self.commas_;
        let dot = here(p0);
        let p_ = adv(p0);
        match kind(&p_) {
            crate::syntax::lexer::TokKind::KName(n) if ((&len(&n.path_) == &Nat::from(1u32)) && ((&n.case == &crate::syntax::lexer::NameCase::CaseLower) || (&n.case == &crate::syntax::lexer::NameCase::CaseTopic))) => {
                let t = here(&p_);
                let field = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EField(Rc::new(e.clone()), n.sigils.clone(), crate::syntax::Ident { name: or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")), span: t.clone() })), span: to(&e.span, &t) };
                let p1 = adv(&p_);
                if arg_starts_here(&p1) && !tk(&p1).line_start {
                    {
                        let commas_ = *commas_;
                        call_then(start_parse_call_args(p1.clone(), commas_), move |parse_call_args_46120: (Array<crate::syntax::Arg>, Ps)| {
                            let (args, p2) = parse_call_args_46120;
                            prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECall(Rc::new(field.clone()), args.clone(), false, false)), span: to(&field.span, &prev(&p2)) }, p2.clone(), false))
                        })
                    }
                } else {
                    prism_rtl::Turn::Finished((field.clone(), p1.clone(), true))
                }
            },
            crate::syntax::lexer::TokKind::KKw(w, m45501_1_1) if (&m45501_1_1 == &Text::lit("")) && crate::syntax::lexer::is_bound_word(&w) => {
                let t = here(&p_);
                prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EField(Rc::new(e.clone()), Text::lit(""), crate::syntax::Ident { name: w.clone(), span: t.clone() })), span: to(&e.span, &t) }, adv(&p_), true))
            },
            crate::syntax::lexer::TokKind::KName(n) if ((&n.case == &crate::syntax::lexer::NameCase::CaseUpper) || (&n.case == &crate::syntax::lexer::NameCase::CaseReserved)) => {
                let (method, p1) = parse_sname(&p_);
                let (args, p2) = if arg_starts_here(&p1) {
                    parse_call_args(&p1, commas_)
                } else {
                    (Array::new(), p1.clone())
                };
                prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMethod(Rc::new(e.clone()), method.clone(), args.clone())), span: to(&e.span, &prev(&p2)) }, p2.clone(), false))
            },
            _ => prism_rtl::Turn::Finished((e.clone(), error_at(&p_, &dot, &Text::lit("expected a field name or a `.Method` after `.`")), false)),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start FieldOrMethod, x`: what the function value is when passed to `@Run`.
pub fn start_field_or_method(e: crate::syntax::Expr, p0: Ps, commas_: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, Ps, bool)>> {
    Rc::new(FieldOrMethod { e, p0, commas_ })
}

/// ```prism
/// ParseTypeArgs: unbounded fn Ps -> (([Type], Ps))
/// ```
pub fn parse_type_args(p_: &Ps) -> (Array<crate::syntax::Type>, Ps) {
    let (types, q) = commas(&adv(p_), &(Rc::new(|a0: Ps| entered(start_parse_type(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, Ps)>>>));
    if &kind(&q) == &crate::syntax::lexer::TokKind::KGtGt {
        (types.clone(), adv(&q))
    } else {
        (types.clone(), error_here(&q, &Text::lit("expected `>>` to close the type arguments")))
    }
}

/// The step machine of `ParseTypeArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTypeArgs: unbounded fn Ps -> (([Type], Ps))
/// ```
pub struct ParseTypeArgs {
    pub p_: Ps,
}

impl prism_rtl::Job<(Array<crate::syntax::Type>, Ps)> for ParseTypeArgs {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::Type>, Ps)> {
        let p_ = &self.p_;
        let p_ = p_.clone();
        call_then(start_commas(adv(&p_), Rc::new(|a0: Ps| entered(start_parse_type(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, Ps)>>>), move |commas_47110: (Array<crate::syntax::Type>, Ps)| {
            let (types, q) = commas_47110;
            if &kind(&q) == &crate::syntax::lexer::TokKind::KGtGt {
                prism_rtl::Turn::Finished((types.clone(), adv(&q)))
            } else {
                prism_rtl::Turn::Finished((types.clone(), error_here(&q, &Text::lit("expected `>>` to close the type arguments"))))
            }
        })
    }
}

/// `Start ParseTypeArgs, x`: what the function value is when passed to `@Run`.
pub fn start_parse_type_args(p_: Ps) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Type>, Ps)>> {
    Rc::new(ParseTypeArgs { p_ })
}

/// ```prism
/// ArgStartsHere: fn Ps -> Bool
/// ```
pub fn arg_starts_here(p_: &Ps) -> bool {
    let t = tk(p_);
    match &t.kind {
        crate::syntax::lexer::TokKind::KName(_) => true,
        crate::syntax::lexer::TokKind::KInt(_, _) => true,
        crate::syntax::lexer::TokKind::KFloat(_, _) => true,
        crate::syntax::lexer::TokKind::KDuration(_, _, _) => true,
        crate::syntax::lexer::TokKind::KChar(_, _) => true,
        crate::syntax::lexer::TokKind::KText(_, _) => true,
        crate::syntax::lexer::TokKind::KTemplate(_) => true,
        crate::syntax::lexer::TokKind::KFree(_) => true,
        crate::syntax::lexer::TokKind::KLensDot => true,
        crate::syntax::lexer::TokKind::KBackslash => true,
        crate::syntax::lexer::TokKind::KAbsent => true,
        crate::syntax::lexer::TokKind::KOpen(m47427_11_0, prefix) if (m47427_11_0 == &Text::lit("[")) => (*prefix || !t.touches) || at_double_open(p_, &Text::lit("[")),
        crate::syntax::lexer::TokKind::KOpen(_, _) => true,
        crate::syntax::lexer::TokKind::KOp(op, true) => (op == &Text::lit("+")) || (op == &Text::lit("-")),
        crate::syntax::lexer::TokKind::KDot(true) => !at_line_method(p_),
        crate::syntax::lexer::TokKind::KKw(w, _) => fold(&arg_words(), &false, &(|seen: &bool, x: &Text| *seen || (x == w))),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// let argWords
/// ```
pub fn arg_words() -> Array<Text> {
    Array::from(vec![Text::lit("unit"), Text::lit("nil"), Text::lit("key"), Text::lit("ix"), Text::lit("jx"), Text::lit("kx"), Text::lit("not"), Text::lit("any"), Text::lit("given"), Text::lit("update"), Text::lit("match"), Text::lit("rebuild"), Text::lit("widget"), Text::lit("output"), Text::lit("inline_text"), Text::lit("raw")])
}

/// ```prism
/// ParseCallArgs: unbounded fn Ps, Bool -> (([Arg], Ps))
/// ```
pub fn parse_call_args(p_: &Ps, commas_: &bool) -> (Array<crate::syntax::Arg>, Ps) {
    if *commas_ && !p_.step_mode {
        commas(p_, &(Rc::new(|a0: Ps| entered(start_parse_arg(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Arg, Ps)>>>))
    } else {
        parse_one_arg(p_)
    }
}

/// The step machine of `ParseCallArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseCallArgs: unbounded fn Ps, Bool -> (([Arg], Ps))
/// ```
pub struct ParseCallArgs {
    pub p_: Ps,
    pub commas_: bool,
}

impl prism_rtl::Job<(Array<crate::syntax::Arg>, Ps)> for ParseCallArgs {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::Arg>, Ps)> {
        let p_ = &self.p_;
        let commas_ = &self.commas_;
        if *commas_ && !p_.step_mode {
            prism_rtl::Turn::More(Rc::new(Commas { p0: p_.clone(), f_fn: Rc::new(|a0: Ps| entered(start_parse_arg(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Arg, Ps)>>> }))
        } else {
            prism_rtl::Turn::More(Rc::new(ParseOneArg { p_: p_.clone() }))
        }
    }
}

/// `Start ParseCallArgs, x`: what the function value is when passed to `@Run`.
pub fn start_parse_call_args(p_: Ps, commas_: bool) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Arg>, Ps)>> {
    Rc::new(ParseCallArgs { p_, commas_ })
}

/// ```prism
/// ParseOneArg: unbounded fn Ps -> (([Arg], Ps))
/// ```
pub fn parse_one_arg(p_: &Ps) -> (Array<crate::syntax::Arg>, Ps) {
    let (a, q) = parse_arg(p_);
    (Array::from(vec![a.clone()]), q.clone())
}

/// The step machine of `ParseOneArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseOneArg: unbounded fn Ps -> (([Arg], Ps))
/// ```
pub struct ParseOneArg {
    pub p_: Ps,
}

impl prism_rtl::Job<(Array<crate::syntax::Arg>, Ps)> for ParseOneArg {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::Arg>, Ps)> {
        let p_ = &self.p_;
        let p_ = p_.clone();
        call_then(start_parse_arg(p_.clone()), move |parse_arg_48643: (crate::syntax::Arg, Ps)| {
            let (a, q) = parse_arg_48643;
            prism_rtl::Turn::Finished((Array::from(vec![a.clone()]), q.clone()))
        })
    }
}

/// `Start ParseOneArg, x`: what the function value is when passed to `@Run`.
pub fn start_parse_one_arg(p_: Ps) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Arg>, Ps)>> {
    Rc::new(ParseOneArg { p_ })
}

/// ```prism
/// ParseArg: unbounded fn Ps -> ((Arg, Ps))
/// ```
pub fn parse_arg(p_: &Ps) -> (crate::syntax::Arg, Ps) {
    let (value, q) = parse_arg_expr(p_);
    (crate::syntax::Arg { name: None, value: value.clone(), span: value.span.clone() }, q.clone())
}

/// The step machine of `ParseArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseArg: unbounded fn Ps -> ((Arg, Ps))
/// ```
pub struct ParseArg {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::Arg, Ps)> for ParseArg {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Arg, Ps)> {
        let p_ = &self.p_;
        let p_ = p_.clone();
        call_then(start_parse_arg_expr(p_.clone()), move |parse_arg_expr_48751: (crate::syntax::Expr, Ps)| {
            let (value, q) = parse_arg_expr_48751;
            prism_rtl::Turn::Finished((crate::syntax::Arg { name: None, value: value.clone(), span: value.span.clone() }, q.clone()))
        })
    }
}

/// `Start ParseArg, x`: what the function value is when passed to `@Run`.
pub fn start_parse_arg(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Arg, Ps)>> {
    Rc::new(ParseArg { p_ })
}

/// ```prism
/// ParseParenArgs: unbounded fn Ps -> (([Arg], Bool, Ps))
/// ```
pub fn parse_paren_args(p0: &Ps) -> (Array<crate::syntax::Arg>, bool, Ps) {
    let p_ = adv(p0);
    if at_close(&p_, &Text::lit("(")) {
        (Array::new(), false, adv(&p_))
    } else {
        {
            let r = {
                let mut this: ArgsRead = ArgsRead { args: Array::new(), rest: false, p_: p_.clone(), going: true };
                while this.going && !this.p_.bad {
                    if &kind(&this.p_) == &crate::syntax::lexer::TokKind::KDotDot {
                        this.p_ = adv(&this.p_);
                        this.rest = true;
                    } else {
                        let start = here(&this.p_);
                        let (name_opt, p1) = parse_arg_name(&this.p_);
                        let (value, p2) = parse_arg_expr(&p1);
                        this.args = push(&this.args, &crate::syntax::Arg { name: name_opt.clone(), value: value.clone(), span: to(&start, &value.span) });
                        this.p_ = p2.clone();
                    }
                    if at_comma(&this.p_) {
                        this.p_ = adv(&this.p_);
                    } else {
                        this.p_ = expect_close(&this.p_, &Text::lit("("));
                        this.going = false;
                    }
                }
                this
            };
            (r.args.clone(), r.rest, r.p_.clone())
        }
    }
}

/// The step machine of `ParseParenArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseParenArgs: unbounded fn Ps -> (([Arg], Bool, Ps))
/// ```
pub struct ParseParenArgs {
    pub p0: Ps,
}

impl prism_rtl::Job<(Array<crate::syntax::Arg>, bool, Ps)> for ParseParenArgs {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::Arg>, bool, Ps)> {
        let p0 = &self.p0;
        let p_ = adv(p0);
        if at_close(&p_, &Text::lit("(")) {
            prism_rtl::Turn::Finished((Array::new(), false, adv(&p_)))
        } else {
            {
                let mut this: ArgsRead = ArgsRead { args: Array::new(), rest: false, p_: p_.clone(), going: true };
                let p_ = p_.clone();
                call_then(loop_job((this,), {
                    let p_ = p_.clone();
                    move |(mut this,): (ArgsRead,)| if this.going && !this.p_.bad {
                        {
                            if &kind(&this.p_) == &crate::syntax::lexer::TokKind::KDotDot {
                                this.p_ = adv(&this.p_);
                                this.rest = true;
                            } else {
                                let start = here(&this.p_);
                                let (name_opt, p1) = parse_arg_name(&this.p_);
                                let (value, p2) = parse_arg_expr(&p1);
                                this.args = push(&this.args, &crate::syntax::Arg { name: name_opt.clone(), value: value.clone(), span: to(&start, &value.span) });
                                this.p_ = p2.clone();
                            }
                            if at_comma(&this.p_) {
                                this.p_ = adv(&this.p_);
                            } else {
                                this.p_ = expect_close(&this.p_, &Text::lit("("));
                                this.going = false;
                            }
                            Ok((this,))
                        }
                    } else {
                        Err((this,))
                    }
                }), move |(mut this,): (ArgsRead,)| {
                    let r = this;
                    prism_rtl::Turn::Finished((r.args.clone(), r.rest, r.p_.clone()))
                })
            }
        }
    }
}

/// `Start ParseParenArgs, x`: what the function value is when passed to `@Run`.
pub fn start_parse_paren_args(p0: Ps) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Arg>, bool, Ps)>> {
    Rc::new(ParseParenArgs { p0 })
}

/// ```prism
/// ParseArgName: fn Ps -> ((?Ident, Ps))
/// ```
pub fn parse_arg_name(p_: &Ps) -> (Option<crate::syntax::Ident>, Ps) {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KName(n) if ((((&n.sigils == &Text::lit("")) && (&len(&n.path_) == &Nat::from(1u32))) && (&n.case == &crate::syntax::lexer::NameCase::CaseLower)) && at_op(&adv(p_), &Text::lit("="))) => (Some(crate::syntax::Ident { name: or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")), span: here(p_) }), adv(&adv(p_))),
        _ => (None, p_.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParsePrimary: unbounded fn Ps, Bool -> ((Expr, Bool, Ps))
/// ```
pub fn parse_primary(p_: &Ps, commas_: &bool) -> (crate::syntax::Expr, bool, Ps) {
    let start = here(p_);
    let tok = tk(p_);
    match &tok.kind {
        crate::syntax::lexer::TokKind::KName(n) => name_primary(p_, n, commas_),
        crate::syntax::lexer::TokKind::KKw(w, sigils) => keyword_primary(p_, w, sigils, commas_),
        crate::syntax::lexer::TokKind::KInt(_, _) => literal_primary(p_),
        crate::syntax::lexer::TokKind::KFloat(_, _) => literal_primary(p_),
        crate::syntax::lexer::TokKind::KDuration(_, _, _) => literal_primary(p_),
        crate::syntax::lexer::TokKind::KChar(_, _) => literal_primary(p_),
        crate::syntax::lexer::TokKind::KText(_, _) => literal_primary(p_),
        crate::syntax::lexer::TokKind::KTemplate(t) => {
            let (tpl, q) = parse_template(&adv(p_), t, &tok.span);
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETemplate(tpl.clone())), span: tok.span.clone() }, false, q.clone())
        },
        crate::syntax::lexer::TokKind::KOpen(m50602_8_0, _) if (m50602_8_0 == &Text::lit("(")) => paren_primary(p_),
        crate::syntax::lexer::TokKind::KOpen(m50602_9_0, _) if (m50602_9_0 == &Text::lit("[")) => square_primary(p_),
        crate::syntax::lexer::TokKind::KOpen(_, _) => map_primary(p_),
        crate::syntax::lexer::TokKind::KDot(true) => {
            let p1 = adv(p_);
            match kind(&p1) {
                crate::syntax::lexer::TokKind::KName(n) if (((&n.sigils == &Text::lit("")) && (&len(&n.path_) == &Nat::from(1u32))) && (&n.case == &crate::syntax::lexer::NameCase::CaseLower)) => {
                    let t = here(&p1);
                    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETopicField(crate::syntax::Ident { name: or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")), span: t.clone() })), span: to(&start, &t) }, false, adv(&p1))
                },
                crate::syntax::lexer::TokKind::KName(n) if (&n.case == &crate::syntax::lexer::NameCase::CaseUpper) => (no_expr(), false, error_at(&p1, &start, &Text::from(format!("a spaced `.{}` begins its own line, below the call it takes as its receiver (layout rule 9)", &crate::syntax::lexer::join(&n.path_, &Text::lit(".")))))),
                _ => (no_expr(), false, error_at(&p1, &start, &Text::lit("a prefix `.` takes a field name, applied to the topic `_`"))),
                _ => unreachable!("no arm matched"),
            }
        },
        crate::syntax::lexer::TokKind::KLensDot => lens_primary(p_),
        crate::syntax::lexer::TokKind::KFree(s) => if s == &Text::lit("!") {
            (no_expr(), true, error_at(&adv(p_), &tok.span, &Text::lit("`!` is never free: no event fires a constant")))
        } else {
            if s == &Text::lit("&") {
                (no_expr(), true, error_at(&adv(p_), &tok.span, &Text::lit("`&` is never free: no reference exists outside the value an `update` block names")))
            } else {
                {
                    let (operand, q) = parse_expr_ctx(&adv(p_), commas_);
                    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EFreeSigil(s.clone(), Rc::new(operand.clone()))), span: to(&start, &operand.span) }, true, q.clone())
                }
            }
        },
        crate::syntax::lexer::TokKind::KBackslash => {
            let (e, q) = parse_lambda(p_);
            (e.clone(), true, q.clone())
        },
        crate::syntax::lexer::TokKind::KAbsent => {
            let q = out_of_scope(&adv(p_), &tok.span, &Text::lit("sparse tuples"), &Text::lit("an absent component `-` makes a sparse tuple, which is out of this compiler"));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EAbsent), span: tok.span.clone() }, false, q.clone())
        },
        crate::syntax::lexer::TokKind::KDotDot => (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ERest), span: tok.span.clone() }, false, adv(p_)),
        crate::syntax::lexer::TokKind::KTrait(_) => (no_expr(), false, error_at(p_, &tok.span, &Text::lit("no trait is a value: a `^Trait` stands in a type, a bound, `derive`, `trait` or `impl`"))),
        crate::syntax::lexer::TokKind::KFamily(path_) => (no_expr(), false, error_at(p_, &tok.span, &Text::from(format!("`{}.*` names every tag of a family: it stands in a pattern, an `emit` row or a `use`, not in an expression", &crate::syntax::lexer::join(path_, &Text::lit(".")))))),
        crate::syntax::lexer::TokKind::KBar => (no_expr(), false, error_at(p_, &tok.span, &Text::lit("a bare `|` is not an operator: the merge is `<|`, and `|` separates the families of a row"))),
        _ => (no_expr(), false, error_here(p_, &Text::lit("expected an expression"))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ParsePrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParsePrimary: unbounded fn Ps, Bool -> ((Expr, Bool, Ps))
/// ```
pub struct ParsePrimary {
    pub p_: Ps,
    pub commas_: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, bool, Ps)> for ParsePrimary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, bool, Ps)> {
        let p_ = &self.p_;
        let commas_ = &self.commas_;
        let start = here(p_);
        let tok = tk(p_);
        match &tok.kind {
            crate::syntax::lexer::TokKind::KName(n) => prism_rtl::Turn::More(Rc::new(NamePrimary { p0: p_.clone(), n: n.clone(), commas_: *commas_ })),
            crate::syntax::lexer::TokKind::KKw(w, sigils) => prism_rtl::Turn::More(Rc::new(KeywordPrimary { p_: p_.clone(), w: w.clone(), sigils: sigils.clone(), commas_: *commas_ })),
            crate::syntax::lexer::TokKind::KInt(_, _) => prism_rtl::Turn::More(Rc::new(LiteralPrimary { p_: p_.clone() })),
            crate::syntax::lexer::TokKind::KFloat(_, _) => prism_rtl::Turn::More(Rc::new(LiteralPrimary { p_: p_.clone() })),
            crate::syntax::lexer::TokKind::KDuration(_, _, _) => prism_rtl::Turn::More(Rc::new(LiteralPrimary { p_: p_.clone() })),
            crate::syntax::lexer::TokKind::KChar(_, _) => prism_rtl::Turn::More(Rc::new(LiteralPrimary { p_: p_.clone() })),
            crate::syntax::lexer::TokKind::KText(_, _) => prism_rtl::Turn::More(Rc::new(LiteralPrimary { p_: p_.clone() })),
            crate::syntax::lexer::TokKind::KTemplate(t) => {
                let p_ = p_.clone();
                let t = t.clone();
                call_then(start_parse_template(adv(&p_), t.clone(), tok.span.clone()), move |parse_template_51016: (crate::syntax::Template, Ps)| {
                    let (tpl, q) = parse_template_51016;
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETemplate(tpl.clone())), span: tok.span.clone() }, false, q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KOpen(m50602_8_0, _) if (m50602_8_0 == &Text::lit("(")) => prism_rtl::Turn::More(Rc::new(ParenPrimary { p_: p_.clone() })),
            crate::syntax::lexer::TokKind::KOpen(m50602_9_0, _) if (m50602_9_0 == &Text::lit("[")) => prism_rtl::Turn::More(Rc::new(SquarePrimary { p_: p_.clone() })),
            crate::syntax::lexer::TokKind::KOpen(_, _) => prism_rtl::Turn::More(Rc::new(MapPrimary { p_: p_.clone() })),
            crate::syntax::lexer::TokKind::KDot(true) => {
                let p1 = adv(p_);
                match kind(&p1) {
                    crate::syntax::lexer::TokKind::KName(n) if (((&n.sigils == &Text::lit("")) && (&len(&n.path_) == &Nat::from(1u32))) && (&n.case == &crate::syntax::lexer::NameCase::CaseLower)) => {
                        let t = here(&p1);
                        prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETopicField(crate::syntax::Ident { name: or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")), span: t.clone() })), span: to(&start, &t) }, false, adv(&p1)))
                    },
                    crate::syntax::lexer::TokKind::KName(n) if (&n.case == &crate::syntax::lexer::NameCase::CaseUpper) => prism_rtl::Turn::Finished((no_expr(), false, error_at(&p1, &start, &Text::from(format!("a spaced `.{}` begins its own line, below the call it takes as its receiver (layout rule 9)", &crate::syntax::lexer::join(&n.path_, &Text::lit("."))))))),
                    _ => prism_rtl::Turn::Finished((no_expr(), false, error_at(&p1, &start, &Text::lit("a prefix `.` takes a field name, applied to the topic `_`")))),
                    _ => unreachable!("no arm matched"),
                }
            },
            crate::syntax::lexer::TokKind::KLensDot => prism_rtl::Turn::More(Rc::new(LensPrimary { p0: p_.clone() })),
            crate::syntax::lexer::TokKind::KFree(s) => if s == &Text::lit("!") {
                prism_rtl::Turn::Finished((no_expr(), true, error_at(&adv(p_), &tok.span, &Text::lit("`!` is never free: no event fires a constant"))))
            } else {
                if s == &Text::lit("&") {
                    prism_rtl::Turn::Finished((no_expr(), true, error_at(&adv(p_), &tok.span, &Text::lit("`&` is never free: no reference exists outside the value an `update` block names"))))
                } else {
                    {
                        let commas_ = *commas_;
                        let p_ = p_.clone();
                        let s = s.clone();
                        call_then(start_parse_expr_ctx(adv(&p_), commas_), move |parse_expr_ctx_52532: (crate::syntax::Expr, Ps)| {
                            let (operand, q) = parse_expr_ctx_52532;
                            prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EFreeSigil(s.clone(), Rc::new(operand.clone()))), span: to(&start, &operand.span) }, true, q.clone()))
                        })
                    }
                }
            },
            crate::syntax::lexer::TokKind::KBackslash => {
                let p_ = p_.clone();
                call_then(start_parse_lambda(p_.clone()), move |parse_lambda_52703: (crate::syntax::Expr, Ps)| {
                    let (e, q) = parse_lambda_52703;
                    prism_rtl::Turn::Finished((e.clone(), true, q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KAbsent => {
                let q = out_of_scope(&adv(p_), &tok.span, &Text::lit("sparse tuples"), &Text::lit("an absent component `-` makes a sparse tuple, which is out of this compiler"));
                prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EAbsent), span: tok.span.clone() }, false, q.clone()))
            },
            crate::syntax::lexer::TokKind::KDotDot => prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ERest), span: tok.span.clone() }, false, adv(p_))),
            crate::syntax::lexer::TokKind::KTrait(_) => prism_rtl::Turn::Finished((no_expr(), false, error_at(p_, &tok.span, &Text::lit("no trait is a value: a `^Trait` stands in a type, a bound, `derive`, `trait` or `impl`")))),
            crate::syntax::lexer::TokKind::KFamily(path_) => prism_rtl::Turn::Finished((no_expr(), false, error_at(p_, &tok.span, &Text::from(format!("`{}.*` names every tag of a family: it stands in a pattern, an `emit` row or a `use`, not in an expression", &crate::syntax::lexer::join(path_, &Text::lit("."))))))),
            crate::syntax::lexer::TokKind::KBar => prism_rtl::Turn::Finished((no_expr(), false, error_at(p_, &tok.span, &Text::lit("a bare `|` is not an operator: the merge is `<|`, and `|` separates the families of a row")))),
            _ => prism_rtl::Turn::Finished((no_expr(), false, error_here(p_, &Text::lit("expected an expression")))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ParsePrimary, x`: what the function value is when passed to `@Run`.
pub fn start_parse_primary(p_: Ps, commas_: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, bool, Ps)>> {
    Rc::new(ParsePrimary { p_, commas_ })
}

/// ```prism
/// LiteralPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub fn literal_primary(p_: &Ps) -> (crate::syntax::Expr, bool, Ps) {
    let (lit, q) = parse_literal(p_);
    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELit(lit.clone())), span: lit.span.clone() }, false, q.clone())
}

/// The step machine of `LiteralPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LiteralPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub struct LiteralPrimary {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, bool, Ps)> for LiteralPrimary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, bool, Ps)> {
        let p_ = &self.p_;
        let p_ = p_.clone();
        call_then(start_parse_literal(p_.clone()), move |parse_literal_53699: (crate::syntax::Literal, Ps)| {
            let (lit, q) = parse_literal_53699;
            prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELit(lit.clone())), span: lit.span.clone() }, false, q.clone()))
        })
    }
}

/// `Start LiteralPrimary, x`: what the function value is when passed to `@Run`.
pub fn start_literal_primary(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, bool, Ps)>> {
    Rc::new(LiteralPrimary { p_ })
}

/// ```prism
/// NamePrimary: unbounded fn Ps, NameTok, Bool -> ((Expr, Bool, Ps))
/// ```
pub fn name_primary(p0: &Ps, n: &crate::syntax::lexer::NameTok, commas_: &bool) -> (crate::syntax::Expr, bool, Ps) {
    let start = here(p0);
    let name = crate::syntax::SName { sigils: n.sigils.clone(), path_: n.path_.clone(), span: start.clone() };
    let p1 = check_name_scope(&adv(p0), &name);
    let plain = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(name.clone())), span: start.clone() };
    let (e, p_) = if &kind(&p1) == &crate::syntax::lexer::TokKind::KLtLt {
        type_args_on(&plain, &p1, &start)
    } else {
        (plain.clone(), p1.clone())
    };
    if is_callee(&name) {
        if at_single_open(&p_, &Text::lit("(")) && tk(&p_).touches {
            {
                let (args, rest, q) = parse_paren_args(&p_);
                (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECall(Rc::new(e.clone()), args.clone(), true, rest)), span: to(&start, &prev(&q)) }, false, q.clone())
            }
        } else {
            if at_kw(&p_, &Text::lit("monad")) {
                {
                    let kw = here(&p_);
                    let (body, q) = parse_block_after_colon(&out_of_scope(&adv(&p_), &kw, &Text::lit("`T monad:` blocks and `^Monad`"), &Text::lit("monad blocks are out of this compiler")));
                    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMonad(Rc::new(e.clone()), body.clone())), span: to(&start, &body.span) }, true, q.clone())
                }
            } else {
                if arg_starts_here(&p_) {
                    {
                        let (args, q) = parse_call_args(&p_, commas_);
                        (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECall(Rc::new(e.clone()), args.clone(), false, false)), span: to(&start, &prev(&q)) }, true, q.clone())
                    }
                } else {
                    (e.clone(), false, p_.clone())
                }
            }
        }
    } else {
        if (at_single_open(&p_, &Text::lit("(")) && tk(&p_).touches) && !is_topic(&name) {
            (e.clone(), false, error_at(&p_, &here(&p_), &Text::from(format!("`{}` is a value and is not applied: a function's name is uppercase (case is a mark)", &name_text(&name)))))
        } else {
            (e.clone(), false, p_.clone())
        }
    }
}

/// The step machine of `NamePrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamePrimary: unbounded fn Ps, NameTok, Bool -> ((Expr, Bool, Ps))
/// ```
pub struct NamePrimary {
    pub p0: Ps,
    pub n: crate::syntax::lexer::NameTok,
    pub commas_: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, bool, Ps)> for NamePrimary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, bool, Ps)> {
        let p0 = &self.p0;
        let n = &self.n;
        let commas_ = &self.commas_;
        let start = here(p0);
        let name = crate::syntax::SName { sigils: n.sigils.clone(), path_: n.path_.clone(), span: start.clone() };
        let p1 = check_name_scope(&adv(p0), &name);
        let plain = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(name.clone())), span: start.clone() };
        let (e, p_) = if &kind(&p1) == &crate::syntax::lexer::TokKind::KLtLt {
            type_args_on(&plain, &p1, &start)
        } else {
            (plain.clone(), p1.clone())
        };
        if is_callee(&name) {
            if at_single_open(&p_, &Text::lit("(")) && tk(&p_).touches {
                call_then(start_parse_paren_args(p_.clone()), move |parse_paren_args_54322: (Array<crate::syntax::Arg>, bool, Ps)| {
                    let (args, rest, q) = parse_paren_args_54322;
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECall(Rc::new(e.clone()), args.clone(), true, rest)), span: to(&start, &prev(&q)) }, false, q.clone()))
                })
            } else {
                if at_kw(&p_, &Text::lit("monad")) {
                    {
                        let kw = here(&p_);
                        call_then(start_parse_block_after_colon(out_of_scope(&adv(&p_), &kw, &Text::lit("`T monad:` blocks and `^Monad`"), &Text::lit("monad blocks are out of this compiler"))), move |parse_block_after_colon_54573: (crate::syntax::Block, Ps)| {
                            let (body, q) = parse_block_after_colon_54573;
                            prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMonad(Rc::new(e.clone()), body.clone())), span: to(&start, &body.span) }, true, q.clone()))
                        })
                    }
                } else {
                    if arg_starts_here(&p_) {
                        {
                            let commas_ = *commas_;
                            call_then(start_parse_call_args(p_.clone(), commas_), move |parse_call_args_54839: (Array<crate::syntax::Arg>, Ps)| {
                                let (args, q) = parse_call_args_54839;
                                prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECall(Rc::new(e.clone()), args.clone(), false, false)), span: to(&start, &prev(&q)) }, true, q.clone()))
                            })
                        }
                    } else {
                        prism_rtl::Turn::Finished((e.clone(), false, p_.clone()))
                    }
                }
            }
        } else {
            if (at_single_open(&p_, &Text::lit("(")) && tk(&p_).touches) && !is_topic(&name) {
                prism_rtl::Turn::Finished((e.clone(), false, error_at(&p_, &here(&p_), &Text::from(format!("`{}` is a value and is not applied: a function's name is uppercase (case is a mark)", &name_text(&name))))))
            } else {
                prism_rtl::Turn::Finished((e.clone(), false, p_.clone()))
            }
        }
    }
}

/// `Start NamePrimary, x`: what the function value is when passed to `@Run`.
pub fn start_name_primary(p0: Ps, n: crate::syntax::lexer::NameTok, commas_: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, bool, Ps)>> {
    Rc::new(NamePrimary { p0, n, commas_ })
}

/// ```prism
/// TypeArgsOn: unbounded fn Expr, Ps, Range -> ((Expr, Ps))
/// ```
pub fn type_args_on(e: &crate::syntax::Expr, p_: &Ps, start: &crate::syntax::Range) -> (crate::syntax::Expr, Ps) {
    let (types, q) = parse_type_args(p_);
    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETypeArgs(Rc::new(e.clone()), types.clone())), span: to(start, &prev(&q)) }, q.clone())
}

/// The step machine of `TypeArgsOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeArgsOn: unbounded fn Expr, Ps, Range -> ((Expr, Ps))
/// ```
pub struct TypeArgsOn {
    pub e: crate::syntax::Expr,
    pub p_: Ps,
    pub start: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::syntax::Expr, Ps)> for TypeArgsOn {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, Ps)> {
        let e = &self.e;
        let p_ = &self.p_;
        let start = &self.start;
        let e = e.clone();
        let p_ = p_.clone();
        let start = start.clone();
        call_then(start_parse_type_args(p_.clone()), move |parse_type_args_55342: (Array<crate::syntax::Type>, Ps)| {
            let (types, q) = parse_type_args_55342;
            prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETypeArgs(Rc::new(e.clone()), types.clone())), span: to(&start, &prev(&q)) }, q.clone()))
        })
    }
}

/// `Start TypeArgsOn, x`: what the function value is when passed to `@Run`.
pub fn start_type_args_on(e: crate::syntax::Expr, p_: Ps, start: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, Ps)>> {
    Rc::new(TypeArgsOn { e, p_, start })
}

/// ```prism
/// ParenPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub fn paren_primary(p_: &Ps) -> (crate::syntax::Expr, bool, Ps) {
    let start = here(p_);
    if at_double_open(p_, &Text::lit("(")) {
        {
            let (elems, p1) = commas(&open_double(p_), &(Rc::new(|a0: Ps| entered(start_parse_arg_expr(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, Ps)>>>));
            let p2 = close_double(&p1, &Text::lit("("));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETuple(elems.clone())), span: to(&start, &prev(&p2)) }, false, p2.clone())
        }
    } else {
        {
            let (inner, p1) = bracketed(&adv(p_), &(Rc::new(|a0: Ps| entered(start_parse_rhs_expr(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, Ps)>>>));
            if at_comma(&p1) {
                (no_expr(), false, error_at(&p1, &here(&p1), &Text::lit("a group holds one expression: a comma here needs a call at the group's head, or `((` `))` for a tuple")))
            } else {
                {
                    let p2 = expect_close(&p1, &Text::lit("("));
                    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EGroup(Rc::new(inner.clone()))), span: to(&start, &prev(&p2)) }, false, p2.clone())
                }
            }
        }
    }
}

/// The step machine of `ParenPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParenPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub struct ParenPrimary {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, bool, Ps)> for ParenPrimary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, bool, Ps)> {
        let p_ = &self.p_;
        let start = here(p_);
        if at_double_open(p_, &Text::lit("(")) {
            {
                let p_ = p_.clone();
                call_then(start_commas(open_double(&p_), Rc::new(|a0: Ps| entered(start_parse_arg_expr(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, Ps)>>>), move |commas_55672: (Array<crate::syntax::Expr>, Ps)| {
                    let (elems, p1) = commas_55672;
                    let p2 = close_double(&p1, &Text::lit("("));
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETuple(elems.clone())), span: to(&start, &prev(&p2)) }, false, p2.clone()))
                })
            }
        } else {
            {
                let p_ = p_.clone();
                call_then(start_bracketed(adv(&p_), Rc::new(|a0: Ps| entered(start_parse_rhs_expr(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, Ps)>>>), move |bracketed_55936: (crate::syntax::Expr, Ps)| {
                    let (inner, p1) = bracketed_55936;
                    if at_comma(&p1) {
                        prism_rtl::Turn::Finished((no_expr(), false, error_at(&p1, &here(&p1), &Text::lit("a group holds one expression: a comma here needs a call at the group's head, or `((` `))` for a tuple"))))
                    } else {
                        {
                            let p2 = expect_close(&p1, &Text::lit("("));
                            prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EGroup(Rc::new(inner.clone()))), span: to(&start, &prev(&p2)) }, false, p2.clone()))
                        }
                    }
                })
            }
        }
    }
}

/// `Start ParenPrimary, x`: what the function value is when passed to `@Run`.
pub fn start_paren_primary(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, bool, Ps)>> {
    Rc::new(ParenPrimary { p_ })
}

/// ```prism
/// SquarePrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub fn square_primary(p_: &Ps) -> (crate::syntax::Expr, bool, Ps) {
    let start = here(p_);
    if at_double_open(p_, &Text::lit("[")) {
        {
            let p1 = open_double(p_);
            let (elems, p2) = if at_close(&p1, &Text::lit("[")) {
                (Array::new(), p1.clone())
            } else {
                commas(&p1, &(Rc::new(|a0: Ps| entered(start_parse_arg_expr(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, Ps)>>>))
            };
            let p3 = close_double(&p2, &Text::lit("["));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EArray(elems.clone())), span: to(&start, &prev(&p3)) }, false, p3.clone())
        }
    } else {
        {
            let (index, p1) = bracketed(&adv(p_), &(Rc::new(|a0: Ps| entered(start_parse_expr(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, Ps)>>>));
            let p2 = expect_close(&p1, &Text::lit("["));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETopicIndex(Rc::new(index.clone()))), span: to(&start, &prev(&p2)) }, false, p2.clone())
        }
    }
}

/// The step machine of `SquarePrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SquarePrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub struct SquarePrimary {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, bool, Ps)> for SquarePrimary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, bool, Ps)> {
        let p_ = &self.p_;
        let start = here(p_);
        if at_double_open(p_, &Text::lit("[")) {
            {
                let p1 = open_double(p_);
                let (elems, p2) = if at_close(&p1, &Text::lit("[")) {
                    (Array::new(), p1.clone())
                } else {
                    commas(&p1, &(Rc::new(|a0: Ps| entered(start_parse_arg_expr(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, Ps)>>>))
                };
                let p3 = close_double(&p2, &Text::lit("["));
                prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EArray(elems.clone())), span: to(&start, &prev(&p3)) }, false, p3.clone()))
            }
        } else {
            {
                let p_ = p_.clone();
                call_then(start_bracketed(adv(&p_), Rc::new(|a0: Ps| entered(start_parse_expr(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, Ps)>>>), move |bracketed_56760: (crate::syntax::Expr, Ps)| {
                    let (index, p1) = bracketed_56760;
                    let p2 = expect_close(&p1, &Text::lit("["));
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETopicIndex(Rc::new(index.clone()))), span: to(&start, &prev(&p2)) }, false, p2.clone()))
                })
            }
        }
    }
}

/// `Start SquarePrimary, x`: what the function value is when passed to `@Run`.
pub fn start_square_primary(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, bool, Ps)>> {
    Rc::new(SquarePrimary { p_ })
}

/// ```prism
/// MapPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub fn map_primary(p_: &Ps) -> (crate::syntax::Expr, bool, Ps) {
    let start = here(p_);
    let p1 = adv(p_);
    let (entries, p2) = if at_close(&p1, &Text::lit("{")) {
        (Array::new(), p1.clone())
    } else {
        commas(&p1, &(Rc::new(|a0: Ps| entered(start_parse_map_entry(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<((crate::syntax::Expr, crate::syntax::Expr), Ps)>>>))
    };
    let p3 = expect_close(&p2, &Text::lit("{"));
    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMap(entries.clone())), span: to(&start, &prev(&p3)) }, false, p3.clone())
}

/// The step machine of `MapPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MapPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub struct MapPrimary {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, bool, Ps)> for MapPrimary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, bool, Ps)> {
        let p_ = &self.p_;
        let start = here(p_);
        let p1 = adv(p_);
        let (entries, p2) = if at_close(&p1, &Text::lit("{")) {
            (Array::new(), p1.clone())
        } else {
            commas(&p1, &(Rc::new(|a0: Ps| entered(start_parse_map_entry(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<((crate::syntax::Expr, crate::syntax::Expr), Ps)>>>))
        };
        let p3 = expect_close(&p2, &Text::lit("{"));
        prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMap(entries.clone())), span: to(&start, &prev(&p3)) }, false, p3.clone()))
    }
}

/// `Start MapPrimary, x`: what the function value is when passed to `@Run`.
pub fn start_map_primary(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, bool, Ps)>> {
    Rc::new(MapPrimary { p_ })
}

/// ```prism
/// ParseMapEntry: unbounded fn Ps -> ((((Expr, Expr)), Ps))
/// ```
pub fn parse_map_entry(p_: &Ps) -> ((crate::syntax::Expr, crate::syntax::Expr), Ps) {
    let (k, p1) = parse_arg_expr(p_);
    let (v_, p2) = parse_arg_expr(&expect_colon(&p1));
    ((k.clone(), v_.clone()), p2.clone())
}

/// The step machine of `ParseMapEntry`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseMapEntry: unbounded fn Ps -> ((((Expr, Expr)), Ps))
/// ```
pub struct ParseMapEntry {
    pub p_: Ps,
}

impl prism_rtl::Job<((crate::syntax::Expr, crate::syntax::Expr), Ps)> for ParseMapEntry {
    fn cycle(&self) -> prism_rtl::Turn<((crate::syntax::Expr, crate::syntax::Expr), Ps)> {
        let p_ = &self.p_;
        let p_ = p_.clone();
        call_then(start_parse_arg_expr(p_.clone()), move |parse_arg_expr_57343: (crate::syntax::Expr, Ps)| {
            let (k, p1) = parse_arg_expr_57343;
            call_then(start_parse_arg_expr(expect_colon(&p1)), move |parse_arg_expr_57378: (crate::syntax::Expr, Ps)| {
                let (v_, p2) = parse_arg_expr_57378;
                prism_rtl::Turn::Finished(((k.clone(), v_.clone()), p2.clone()))
            })
        })
    }
}

/// `Start ParseMapEntry, x`: what the function value is when passed to `@Run`.
pub fn start_parse_map_entry(p_: Ps) -> Rc<dyn prism_rtl::Job<((crate::syntax::Expr, crate::syntax::Expr), Ps)>> {
    Rc::new(ParseMapEntry { p_ })
}

/// ```prism
/// LensPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub fn lens_primary(p0: &Ps) -> (crate::syntax::Expr, bool, Ps) {
    let start = here(p0);
    let r = {
        let mut this: (Array<crate::syntax::Ident>, Ps) = (Array::new(), adv(p0));
        let mut path_: Array<crate::syntax::Ident> = Array::new();
        let mut p_: Ps = adv(p0);
        let mut going: bool = true;
        while going && !p_.bad {
            match &kind(&p_) {
                crate::syntax::lexer::TokKind::KName(n) if (((&n.sigils == &Text::lit("")) && (&n.case == &crate::syntax::lexer::NameCase::CaseLower)) && (&len(&n.path_) == &Nat::from(1u32))) => {
                    path_ = push(&path_, &crate::syntax::Ident { name: or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")), span: here(&p_) });
                    p_ = adv(&p_);
                    if &kind(&p_) == &crate::syntax::lexer::TokKind::KDot(false) {
                        p_ = adv(&p_);
                    } else {
                        going = false;
                    }
                    ()
                },
                _ => {
                    p_ = error_here(&p_, &Text::lit("expected a field name in a lens path"));
                    ()
                },
                _ => unreachable!("no arm matched"),
            };
        }
        this = (path_.clone(), p_.clone());
        this
    };
    let (path_, q) = r.clone();
    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELens(path_.clone())), span: to(&start, &prev(&q)) }, false, q.clone())
}

/// The step machine of `LensPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LensPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub struct LensPrimary {
    pub p0: Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, bool, Ps)> for LensPrimary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, bool, Ps)> {
        let p0 = &self.p0;
        let start = here(p0);
        let mut this: (Array<crate::syntax::Ident>, Ps) = (Array::new(), adv(p0));
        let mut path_: Array<crate::syntax::Ident> = Array::new();
        let mut p_: Ps = adv(p0);
        let mut going: bool = true;
        let start = start.clone();
        call_then(loop_job((this, going, p_, path_), move |(mut this, mut going, mut p_, mut path_): ((Array<crate::syntax::Ident>, Ps), bool, Ps, Array<crate::syntax::Ident>)| if going && !p_.bad {
            {
                match &kind(&p_) {
                    crate::syntax::lexer::TokKind::KName(n) if (((&n.sigils == &Text::lit("")) && (&n.case == &crate::syntax::lexer::NameCase::CaseLower)) && (&len(&n.path_) == &Nat::from(1u32))) => {
                        path_ = push(&path_, &crate::syntax::Ident { name: or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")), span: here(&p_) });
                        p_ = adv(&p_);
                        if &kind(&p_) == &crate::syntax::lexer::TokKind::KDot(false) {
                            p_ = adv(&p_);
                        } else {
                            going = false;
                        }
                        ()
                    },
                    _ => {
                        p_ = error_here(&p_, &Text::lit("expected a field name in a lens path"));
                        ()
                    },
                    _ => unreachable!("no arm matched"),
                };
                Ok((this, going, p_, path_))
            }
        } else {
            Err((this, going, p_, path_))
        }), move |(mut this, mut going, mut p_, mut path_): ((Array<crate::syntax::Ident>, Ps), bool, Ps, Array<crate::syntax::Ident>)| {
            this = (path_.clone(), p_.clone());
            let r = this;
            let (path_, q) = r.clone();
            prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELens(path_.clone())), span: to(&start, &prev(&q)) }, false, q.clone()))
        })
    }
}

/// `Start LensPrimary, x`: what the function value is when passed to `@Run`.
pub fn start_lens_primary(p0: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, bool, Ps)>> {
    Rc::new(LensPrimary { p0 })
}

/// ```prism
/// KeywordPrimary: unbounded fn Ps, Text, Text, Bool -> ((Expr, Bool, Ps))
/// ```
pub fn keyword_primary(p_: &Ps, w: &Text, sigils: &Text, commas_: &bool) -> (crate::syntax::Expr, bool, Ps) {
    let start = here(p_);
    match w {
        m58503_0 if (m58503_0 == &Text::lit("unit")) => (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EUnit(sigils.clone())), span: start.clone() }, false, adv(p_)),
        m58503_1 if (m58503_1 == &Text::lit("nil")) => (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ENil(sigils.clone())), span: start.clone() }, false, adv(p_)),
        _ if crate::syntax::lexer::is_bound_word(w) => (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EBound(w.clone())), span: start.clone() }, false, adv(p_)),
        m58503_3 if (m58503_3 == &Text::lit("if")) => took(&parse_if(p_)),
        m58503_4 if (m58503_4 == &Text::lit("match")) => took(&parse_match(p_)),
        m58503_5 if (m58503_5 == &Text::lit("rebuild")) => {
            let (scrutinee, p1) = parse_expr(&adv(p_));
            let (body, p2) = parse_block_after_colon(&p1);
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ERebuild(Rc::new(scrutinee.clone()), body.clone())), span: to(&start, &body.span) }, true, p2.clone())
        },
        m58503_6 if (m58503_6 == &Text::lit("for")) => took(&parse_for(p_)),
        m58503_7 if (m58503_7 == &Text::lit("given")) => {
            let (body, q) = parse_block_after_colon(&adv(p_));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EGiven(body.clone())), span: to(&start, &body.span) }, true, q.clone())
        },
        m58503_8 if (m58503_8 == &Text::lit("update")) => {
            let (target, p1) = parse_expr(&adv(p_));
            let (body, p2) = parse_block_after_colon(&p1);
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EUpdate(Rc::new(target.clone()), body.clone())), span: to(&start, &body.span) }, true, p2.clone())
        },
        m58503_9 if (m58503_9 == &Text::lit("widget")) => {
            let (body, q) = parse_block_after_colon(&adv(p_));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EWidgetBlock(body.clone())), span: to(&start, &body.span) }, true, q.clone())
        },
        m58503_10 if (m58503_10 == &Text::lit("any")) => {
            let (operand, q) = parse_expr_ctx(&adv(p_), commas_);
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EAny(Rc::new(operand.clone()))), span: to(&start, &operand.span) }, true, q.clone())
        },
        m58503_11 if (m58503_11 == &Text::lit("not")) => {
            let (e, q) = parse_binary(p_, &Nat::from(8u32), commas_);
            (e.clone(), true, q.clone())
        },
        _ if (((w == &Text::lit("output")) || (w == &Text::lit("inline_text"))) || (w == &Text::lit("raw"))) => {
            let p1 = adv(p_);
            match kind(&p1) {
                crate::syntax::lexer::TokKind::KTemplate(t) => {
                    let tspan = here(&p1);
                    let (tpl, q) = parse_template(&adv(&p1), &t, &tspan);
                    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETemplate(tpl.clone())), span: to(&start, &tspan) }, false, q.clone())
                },
                _ => (no_expr(), false, fail(&p1)),
            }
        },
        m58503_13 if (m58503_13 == &Text::lit("then")) => (no_expr(), false, error_at(p_, &start, &Text::lit("`then` belongs to a hold: `$x <- start then step`"))),
        m58503_14 if (m58503_14 == &Text::lit("else")) => (no_expr(), false, error_at(p_, &start, &Text::lit("`else` without its `if`"))),
        m58503_15 if (m58503_15 == &Text::lit("ignore")) => (no_expr(), false, error_at(p_, &start, &Text::lit("`ignore` stands only inside a pattern or as the left side of a bind"))),
        m58503_16 if (m58503_16 == &Text::lit("return")) => (no_expr(), false, error_at(p_, &start, &Text::lit("`return` ends a monad block, as its last statement"))),
        _ => (no_expr(), false, error_here(p_, &Text::lit("expected an expression"))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `KeywordPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// KeywordPrimary: unbounded fn Ps, Text, Text, Bool -> ((Expr, Bool, Ps))
/// ```
pub struct KeywordPrimary {
    pub p_: Ps,
    pub w: Text,
    pub sigils: Text,
    pub commas_: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, bool, Ps)> for KeywordPrimary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, bool, Ps)> {
        let p_ = &self.p_;
        let w = &self.w;
        let sigils = &self.sigils;
        let commas_ = &self.commas_;
        let start = here(p_);
        match w {
            m58503_0 if (m58503_0 == &Text::lit("unit")) => prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EUnit(sigils.clone())), span: start.clone() }, false, adv(p_))),
            m58503_1 if (m58503_1 == &Text::lit("nil")) => prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ENil(sigils.clone())), span: start.clone() }, false, adv(p_))),
            _ if crate::syntax::lexer::is_bound_word(w) => prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EBound(w.clone())), span: start.clone() }, false, adv(p_))),
            m58503_3 if (m58503_3 == &Text::lit("if")) => {
                let p_ = p_.clone();
                call_then(start_parse_if(p_.clone()), move |parse_if_58765: (crate::syntax::Expr, Ps)| prism_rtl::Turn::Finished(took(&parse_if_58765)))
            },
            m58503_4 if (m58503_4 == &Text::lit("match")) => {
                let p_ = p_.clone();
                call_then(start_parse_match(p_.clone()), move |parse_match_58799: (crate::syntax::Expr, Ps)| prism_rtl::Turn::Finished(took(&parse_match_58799)))
            },
            m58503_5 if (m58503_5 == &Text::lit("rebuild")) => {
                let p_ = p_.clone();
                call_then(start_parse_expr(adv(&p_)), move |parse_expr_58868: (crate::syntax::Expr, Ps)| {
                    let (scrutinee, p1) = parse_expr_58868;
                    call_then(start_parse_block_after_colon(p1.clone()), move |parse_block_after_colon_58917: (crate::syntax::Block, Ps)| {
                        let (body, p2) = parse_block_after_colon_58917;
                        prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ERebuild(Rc::new(scrutinee.clone()), body.clone())), span: to(&start, &body.span) }, true, p2.clone()))
                    })
                })
            },
            m58503_6 if (m58503_6 == &Text::lit("for")) => {
                let p_ = p_.clone();
                call_then(start_parse_for(p_.clone()), move |parse_for_59054: (crate::syntax::Expr, Ps)| prism_rtl::Turn::Finished(took(&parse_for_59054)))
            },
            m58503_7 if (m58503_7 == &Text::lit("given")) => {
                let p_ = p_.clone();
                call_then(start_parse_block_after_colon(adv(&p_)), move |parse_block_after_colon_59113: (crate::syntax::Block, Ps)| {
                    let (body, q) = parse_block_after_colon_59113;
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EGiven(body.clone())), span: to(&start, &body.span) }, true, q.clone()))
                })
            },
            m58503_8 if (m58503_8 == &Text::lit("update")) => {
                let p_ = p_.clone();
                call_then(start_parse_expr(adv(&p_)), move |parse_expr_59271: (crate::syntax::Expr, Ps)| {
                    let (target, p1) = parse_expr_59271;
                    call_then(start_parse_block_after_colon(p1.clone()), move |parse_block_after_colon_59320: (crate::syntax::Block, Ps)| {
                        let (body, p2) = parse_block_after_colon_59320;
                        prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EUpdate(Rc::new(target.clone()), body.clone())), span: to(&start, &body.span) }, true, p2.clone()))
                    })
                })
            },
            m58503_9 if (m58503_9 == &Text::lit("widget")) => {
                let p_ = p_.clone();
                call_then(start_parse_block_after_colon(adv(&p_)), move |parse_block_after_colon_59533: (crate::syntax::Block, Ps)| {
                    let (body, q) = parse_block_after_colon_59533;
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EWidgetBlock(body.clone())), span: to(&start, &body.span) }, true, q.clone()))
                })
            },
            m58503_10 if (m58503_10 == &Text::lit("any")) => {
                let commas_ = *commas_;
                let p_ = p_.clone();
                call_then(start_parse_expr_ctx(adv(&p_), commas_), move |parse_expr_ctx_59694: (crate::syntax::Expr, Ps)| {
                    let (operand, q) = parse_expr_ctx_59694;
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EAny(Rc::new(operand.clone()))), span: to(&start, &operand.span) }, true, q.clone()))
                })
            },
            m58503_11 if (m58503_11 == &Text::lit("not")) => {
                let commas_ = *commas_;
                let p_ = p_.clone();
                call_then(start_parse_binary(p_.clone(), Nat::from(8u32), commas_), move |parse_binary_59847: (crate::syntax::Expr, Ps)| {
                    let (e, q) = parse_binary_59847;
                    prism_rtl::Turn::Finished((e.clone(), true, q.clone()))
                })
            },
            _ if (((w == &Text::lit("output")) || (w == &Text::lit("inline_text"))) || (w == &Text::lit("raw"))) => {
                let p1 = adv(p_);
                match kind(&p1) {
                    crate::syntax::lexer::TokKind::KTemplate(t) => {
                        let tspan = here(&p1);
                        call_then(start_parse_template(adv(&p1), t.clone(), tspan.clone()), move |parse_template_60207: (crate::syntax::Template, Ps)| {
                            let (tpl, q) = parse_template_60207;
                            prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETemplate(tpl.clone())), span: to(&start, &tspan) }, false, q.clone()))
                        })
                    },
                    _ => prism_rtl::Turn::Finished((no_expr(), false, fail(&p1))),
                }
            },
            m58503_13 if (m58503_13 == &Text::lit("then")) => prism_rtl::Turn::Finished((no_expr(), false, error_at(p_, &start, &Text::lit("`then` belongs to a hold: `$x <- start then step`")))),
            m58503_14 if (m58503_14 == &Text::lit("else")) => prism_rtl::Turn::Finished((no_expr(), false, error_at(p_, &start, &Text::lit("`else` without its `if`")))),
            m58503_15 if (m58503_15 == &Text::lit("ignore")) => prism_rtl::Turn::Finished((no_expr(), false, error_at(p_, &start, &Text::lit("`ignore` stands only inside a pattern or as the left side of a bind")))),
            m58503_16 if (m58503_16 == &Text::lit("return")) => prism_rtl::Turn::Finished((no_expr(), false, error_at(p_, &start, &Text::lit("`return` ends a monad block, as its last statement")))),
            _ => prism_rtl::Turn::Finished((no_expr(), false, error_here(p_, &Text::lit("expected an expression")))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start KeywordPrimary, x`: what the function value is when passed to `@Run`.
pub fn start_keyword_primary(p_: Ps, w: Text, sigils: Text, commas_: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, bool, Ps)>> {
    Rc::new(KeywordPrimary { p_, w, sigils, commas_ })
}

/// ```prism
/// Took: fn ((Expr, Ps)) -> ((Expr, Bool, Ps))
/// ```
pub fn took(arg0: &(crate::syntax::Expr, Ps)) -> (crate::syntax::Expr, bool, Ps) {
    match arg0 {
        (e, p_) => (e.clone(), true, p_.clone()),
    }
}

/// ```prism
/// ParseLiteral: unbounded fn Ps -> ((Literal, Ps))
/// ```
pub fn parse_literal(p_: &Ps) -> (crate::syntax::Literal, Ps) {
    let span = here(p_);
    let p1 = adv(p_);
    match kind(p_) {
        crate::syntax::lexer::TokKind::KInt(s, t) => (crate::syntax::Literal { marks: s.clone(), kind: crate::syntax::LitKind::LInt(t.clone()), span: span.clone() }, p1.clone()),
        crate::syntax::lexer::TokKind::KFloat(s, t) => (crate::syntax::Literal { marks: s.clone(), kind: crate::syntax::LitKind::LFloat(t.clone()), span: span.clone() }, p1.clone()),
        crate::syntax::lexer::TokKind::KDuration(s, n, u) => (crate::syntax::Literal { marks: s.clone(), kind: crate::syntax::LitKind::LDuration(n.clone(), u.clone()), span: span.clone() }, p1.clone()),
        crate::syntax::lexer::TokKind::KChar(s, c) => (crate::syntax::Literal { marks: s.clone(), kind: crate::syntax::LitKind::LChar(c.clone()), span: span.clone() }, p1.clone()),
        crate::syntax::lexer::TokKind::KText(s, segs) => {
            let (out, q) = run_to_end(fold_job(segs.clone(), (Array::new(), p1.clone()), Rc::new(move |(p0, p1): ((Array<crate::syntax::TextSeg>, Ps), crate::syntax::lexer::TextSegTok)| entered(once_job(move || {
                let (acc, pp) = p0;
                let seg = p1;
                prism_rtl::Turn::More(Rc::new(TextSegment { acc: acc.clone(), p_: pp.clone(), text_seg_tok2: seg.clone() }))
            }))) as Rc<dyn Fn(((Array<crate::syntax::TextSeg>, Ps), crate::syntax::lexer::TextSegTok)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::TextSeg>, Ps)>>>));
            (crate::syntax::Literal { marks: s.clone(), kind: crate::syntax::LitKind::LText(out.clone()), span: span.clone() }, q.clone())
        },
        _ => (crate::syntax::Literal { marks: Text::lit(""), kind: crate::syntax::LitKind::LInt(Text::lit("")), span: span.clone() }, error_at(&p1, &span, &Text::lit("expected a literal"))),
    }
}

/// The step machine of `ParseLiteral`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseLiteral: unbounded fn Ps -> ((Literal, Ps))
/// ```
pub struct ParseLiteral {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::Literal, Ps)> for ParseLiteral {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Literal, Ps)> {
        let p_ = &self.p_;
        let span = here(p_);
        let p1 = adv(p_);
        match kind(p_) {
            crate::syntax::lexer::TokKind::KInt(s, t) => prism_rtl::Turn::Finished((crate::syntax::Literal { marks: s.clone(), kind: crate::syntax::LitKind::LInt(t.clone()), span: span.clone() }, p1.clone())),
            crate::syntax::lexer::TokKind::KFloat(s, t) => prism_rtl::Turn::Finished((crate::syntax::Literal { marks: s.clone(), kind: crate::syntax::LitKind::LFloat(t.clone()), span: span.clone() }, p1.clone())),
            crate::syntax::lexer::TokKind::KDuration(s, n, u) => prism_rtl::Turn::Finished((crate::syntax::Literal { marks: s.clone(), kind: crate::syntax::LitKind::LDuration(n.clone(), u.clone()), span: span.clone() }, p1.clone())),
            crate::syntax::lexer::TokKind::KChar(s, c) => prism_rtl::Turn::Finished((crate::syntax::Literal { marks: s.clone(), kind: crate::syntax::LitKind::LChar(c.clone()), span: span.clone() }, p1.clone())),
            crate::syntax::lexer::TokKind::KText(s, segs) => call_value(fold_job(segs.clone(), (Array::new(), p1.clone()), Rc::new(move |(p0, p1): ((Array<crate::syntax::TextSeg>, Ps), crate::syntax::lexer::TextSegTok)| entered(once_job(move || {
                let (acc, pp) = p0;
                let seg = p1;
                prism_rtl::Turn::More(Rc::new(TextSegment { acc: acc.clone(), p_: pp.clone(), text_seg_tok2: seg.clone() }))
            }))) as Rc<dyn Fn(((Array<crate::syntax::TextSeg>, Ps), crate::syntax::lexer::TextSegTok)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::TextSeg>, Ps)>>>), move |fold_61521: (Array<crate::syntax::TextSeg>, Ps)| {
                let (out, q) = fold_61521;
                prism_rtl::Turn::Finished((crate::syntax::Literal { marks: s.clone(), kind: crate::syntax::LitKind::LText(out.clone()), span: span.clone() }, q.clone()))
            }),
            _ => prism_rtl::Turn::Finished((crate::syntax::Literal { marks: Text::lit(""), kind: crate::syntax::LitKind::LInt(Text::lit("")), span: span.clone() }, error_at(&p1, &span, &Text::lit("expected a literal")))),
        }
    }
}

/// `Start ParseLiteral, x`: what the function value is when passed to `@Run`.
pub fn start_parse_literal(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Literal, Ps)>> {
    Rc::new(ParseLiteral { p_ })
}

/// ```prism
/// TextSegment: unbounded fn [TextSeg], Ps, TextSegTok -> (([TextSeg], Ps))
/// ```
pub fn text_segment(acc: &Array<crate::syntax::TextSeg>, p_: &Ps, text_seg_tok2: &crate::syntax::lexer::TextSegTok) -> (Array<crate::syntax::TextSeg>, Ps) {
    match text_seg_tok2 {
        crate::syntax::lexer::TextSegTok::TsPlain(s) => (push(acc, &crate::syntax::TextSeg::SegPlain(s.clone())), p_.clone()),
        crate::syntax::lexer::TextSegTok::TsPlaceholder(toks, span) => {
            let (e, q) = parse_nested(p_, toks, span);
            (push(acc, &crate::syntax::TextSeg::SegPlaceholder(e.clone())), q.clone())
        },
    }
}

/// The step machine of `TextSegment`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TextSegment: unbounded fn [TextSeg], Ps, TextSegTok -> (([TextSeg], Ps))
/// ```
pub struct TextSegment {
    pub acc: Array<crate::syntax::TextSeg>,
    pub p_: Ps,
    pub text_seg_tok2: crate::syntax::lexer::TextSegTok,
}

impl prism_rtl::Job<(Array<crate::syntax::TextSeg>, Ps)> for TextSegment {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::TextSeg>, Ps)> {
        let acc = &self.acc;
        let p_ = &self.p_;
        let text_seg_tok2 = &self.text_seg_tok2;
        match text_seg_tok2 {
            crate::syntax::lexer::TextSegTok::TsPlain(s) => prism_rtl::Turn::Finished((push(acc, &crate::syntax::TextSeg::SegPlain(s.clone())), p_.clone())),
            crate::syntax::lexer::TextSegTok::TsPlaceholder(toks, span) => {
                let acc = acc.clone();
                let p_ = p_.clone();
                let span = span.clone();
                let toks = toks.clone();
                call_then(start_parse_nested(p_.clone(), toks.clone(), span.clone()), move |parse_nested_61979: (crate::syntax::Expr, Ps)| {
                    let (e, q) = parse_nested_61979;
                    prism_rtl::Turn::Finished((push(&acc, &crate::syntax::TextSeg::SegPlaceholder(e.clone())), q.clone()))
                })
            },
        }
    }
}

/// `Start TextSegment, x`: what the function value is when passed to `@Run`.
pub fn start_text_segment(acc: Array<crate::syntax::TextSeg>, p_: Ps, text_seg_tok2: crate::syntax::lexer::TextSegTok) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::TextSeg>, Ps)>> {
    Rc::new(TextSegment { acc, p_, text_seg_tok2 })
}

/// ```prism
/// ParseNested: unbounded fn Ps, [Tok], Range -> ((Expr, Ps))
/// ```
pub fn parse_nested(p_: &Ps, toks: &Array<crate::syntax::lexer::Tok>, span: &crate::syntax::Range) -> (crate::syntax::Expr, Ps) {
    let sub_ = with_step_mode(&sub(p_, toks, &at_end(span)), &false);
    let (e, s1) = parse_rhs_expr(&sub_);
    let s2 = if !s1.bad && !at_eof(&s1) {
        note_error(&s1, &here(&s1), &Text::from(format!("expected the end of the placeholder, found {}", &describe(&kind(&s1)))))
    } else {
        s1.clone()
    };
    let s3 = if s2.bad && (&len(&s2.diags) == &Nat::from(0u32)) {
        note_error(&unbad(&s2), span, &Text::lit("expected an expression in the placeholder"))
    } else {
        s2.clone()
    };
    let q = absorb(p_, &s3);
    if s1.bad {
        (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span.clone() }, q.clone())
    } else {
        (e.clone(), q.clone())
    }
}

/// The step machine of `ParseNested`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseNested: unbounded fn Ps, [Tok], Range -> ((Expr, Ps))
/// ```
pub struct ParseNested {
    pub p_: Ps,
    pub toks: Array<crate::syntax::lexer::Tok>,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::syntax::Expr, Ps)> for ParseNested {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, Ps)> {
        let p_ = &self.p_;
        let toks = &self.toks;
        let span = &self.span;
        let p_ = p_.clone();
        let span = span.clone();
        let toks = toks.clone();
        call_then(start_sub(p_.clone(), toks.clone(), at_end(&span)), move |sub_62302: Ps| {
            let sub_ = with_step_mode(&sub_62302, &false);
            call_then(start_parse_rhs_expr(sub_.clone()), move |parse_rhs_expr_62356: (crate::syntax::Expr, Ps)| {
                let (e, s1) = parse_rhs_expr_62356;
                let s2 = if !s1.bad && !at_eof(&s1) {
                    note_error(&s1, &here(&s1), &Text::from(format!("expected the end of the placeholder, found {}", &describe(&kind(&s1)))))
                } else {
                    s1.clone()
                };
                let s3 = if s2.bad && (&len(&s2.diags) == &Nat::from(0u32)) {
                    note_error(&unbad(&s2), &span, &Text::lit("expected an expression in the placeholder"))
                } else {
                    s2.clone()
                };
                let q = absorb(&p_, &s3);
                if s1.bad {
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span.clone() }, q.clone()))
                } else {
                    prism_rtl::Turn::Finished((e.clone(), q.clone()))
                }
            })
        })
    }
}

/// `Start ParseNested, x`: what the function value is when passed to `@Run`.
pub fn start_parse_nested(p_: Ps, toks: Array<crate::syntax::lexer::Tok>, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, Ps)>> {
    Rc::new(ParseNested { p_, toks, span })
}

/// ```prism
/// ParseTemplate: unbounded fn Ps, TemplateTok, Range -> ((Template, Ps))
/// ```
pub fn parse_template(p0: &Ps, t: &crate::syntax::lexer::TemplateTok, span: &crate::syntax::Range) -> (crate::syntax::Template, Ps) {
    let p1 = if (&t.delims == &Text::lit("single")) && (&t.keyword != &Text::lit("Raw")) {
        out_of_scope(p0, span, &Text::lit("the template notation"), &Text::from(format!("a `<{}>` template is the template notation for an element language, out of this compiler (code templates only)", &t.lang)))
    } else {
        p0.clone()
    };
    let p2 = if &t.keyword == &Text::lit("File") {
        out_of_scope(&p1, span, &Text::lit("the template notation"), &Text::lit("a file whose first token is a language tag is a template file, out of this compiler (code templates only)"))
    } else {
        p1.clone()
    };
    let (parts, p3) = template_parts(&p2, &t.parts);
    (crate::syntax::Template { keyword: t.keyword.clone(), lang: t.lang.clone(), delims: t.delims.clone(), parts: parts.clone(), span: span.clone() }, p3.clone())
}

/// The step machine of `ParseTemplate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTemplate: unbounded fn Ps, TemplateTok, Range -> ((Template, Ps))
/// ```
pub struct ParseTemplate {
    pub p0: Ps,
    pub t: crate::syntax::lexer::TemplateTok,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::syntax::Template, Ps)> for ParseTemplate {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Template, Ps)> {
        let p0 = &self.p0;
        let t = &self.t;
        let span = &self.span;
        let p1 = if (&t.delims == &Text::lit("single")) && (&t.keyword != &Text::lit("Raw")) {
            out_of_scope(p0, span, &Text::lit("the template notation"), &Text::from(format!("a `<{}>` template is the template notation for an element language, out of this compiler (code templates only)", &t.lang)))
        } else {
            p0.clone()
        };
        let p2 = if &t.keyword == &Text::lit("File") {
            out_of_scope(&p1, span, &Text::lit("the template notation"), &Text::lit("a file whose first token is a language tag is a template file, out of this compiler (code templates only)"))
        } else {
            p1.clone()
        };
        let span = span.clone();
        let t = t.clone();
        call_then(start_template_parts(p2.clone(), t.parts.clone()), move |template_parts_63351: (Array<crate::syntax::TemplatePart>, Ps)| {
            let (parts, p3) = template_parts_63351;
            prism_rtl::Turn::Finished((crate::syntax::Template { keyword: t.keyword.clone(), lang: t.lang.clone(), delims: t.delims.clone(), parts: parts.clone(), span: span.clone() }, p3.clone()))
        })
    }
}

/// `Start ParseTemplate, x`: what the function value is when passed to `@Run`.
pub fn start_parse_template(p0: Ps, t: crate::syntax::lexer::TemplateTok, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::syntax::Template, Ps)>> {
    Rc::new(ParseTemplate { p0, t, span })
}

/// ```prism
/// TemplateParts: unbounded fn Ps, [TPartTok] -> (([TemplatePart], Ps))
/// ```
pub fn template_parts(p_: &Ps, parts: &Array<crate::syntax::lexer::TPartTok>) -> (Array<crate::syntax::TemplatePart>, Ps) {
    run_to_end(fold_job(parts.clone(), (Array::new(), p_.clone()), Rc::new(move |(p0, p1): ((Array<crate::syntax::TemplatePart>, Ps), crate::syntax::lexer::TPartTok)| entered(once_job(move || {
        let (acc, q) = p0;
        let part = p1;
        prism_rtl::Turn::More(Rc::new(TemplatePartOf { acc: acc.clone(), p_: q.clone(), tpart_tok2: part.clone() }))
    }))) as Rc<dyn Fn(((Array<crate::syntax::TemplatePart>, Ps), crate::syntax::lexer::TPartTok)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::TemplatePart>, Ps)>>>))
}

/// The step machine of `TemplateParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateParts: unbounded fn Ps, [TPartTok] -> (([TemplatePart], Ps))
/// ```
pub struct TemplateParts {
    pub p_: Ps,
    pub parts: Array<crate::syntax::lexer::TPartTok>,
}

impl prism_rtl::Job<(Array<crate::syntax::TemplatePart>, Ps)> for TemplateParts {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::TemplatePart>, Ps)> {
        let p_ = &self.p_;
        let parts = &self.parts;
        fold_job(parts.clone(), (Array::new(), p_.clone()), Rc::new(move |(p0, p1): ((Array<crate::syntax::TemplatePart>, Ps), crate::syntax::lexer::TPartTok)| entered(once_job(move || {
            let (acc, q) = p0;
            let part = p1;
            prism_rtl::Turn::More(Rc::new(TemplatePartOf { acc: acc.clone(), p_: q.clone(), tpart_tok2: part.clone() }))
        }))) as Rc<dyn Fn(((Array<crate::syntax::TemplatePart>, Ps), crate::syntax::lexer::TPartTok)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::TemplatePart>, Ps)>>>).cycle()
    }
}

/// `Start TemplateParts, x`: what the function value is when passed to `@Run`.
pub fn start_template_parts(p_: Ps, parts: Array<crate::syntax::lexer::TPartTok>) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::TemplatePart>, Ps)>> {
    Rc::new(TemplateParts { p_, parts })
}

/// ```prism
/// TemplatePartOf: unbounded fn [TemplatePart], Ps, TPartTok -> (([TemplatePart], Ps))
/// ```
pub fn template_part_of(acc: &Array<crate::syntax::TemplatePart>, p_: &Ps, tpart_tok2: &crate::syntax::lexer::TPartTok) -> (Array<crate::syntax::TemplatePart>, Ps) {
    match tpart_tok2 {
        crate::syntax::lexer::TPartTok::TptText(s) => (push(acc, &crate::syntax::TemplatePart::TpText(s.clone())), p_.clone()),
        crate::syntax::lexer::TPartTok::TptPlaceholder(toks, col_opt, span) => {
            let (e, q) = parse_nested(p_, toks, span);
            (push(acc, &crate::syntax::TemplatePart::TpPlaceholder(e.clone(), col_opt.clone())), q.clone())
        },
        crate::syntax::lexer::TPartTok::TptBlock(toks, span) => {
            let sub_ = sub(p_, toks, &at_end(span));
            let (block, s1) = parse_block_until_eof(&sub_, span);
            (push(acc, &crate::syntax::TemplatePart::TpBlock(block.clone())), absorb(p_, &s1))
        },
        crate::syntax::lexer::TPartTok::TptCall(name, attrs, body_opt, span) => {
            let sname = crate::syntax::SName { sigils: name.sigils.clone(), path_: name.path_.clone(), span: span.clone() };
            let (args, p1) = run_to_end(fold_job(attrs.clone(), (Array::new(), p_.clone()), Rc::new(move |(p0, p1): ((Array<crate::syntax::Arg>, Ps), crate::syntax::lexer::AttrTok)| entered(once_job(move || {
                let (done, q) = p0;
                let a = p1;
                prism_rtl::Turn::More(Rc::new(AttrArg { done: done.clone(), p_: q.clone(), a: a.clone() }))
            }))) as Rc<dyn Fn(((Array<crate::syntax::Arg>, Ps), crate::syntax::lexer::AttrTok)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Arg>, Ps)>>>));
            let (inner_opt, p2) = match body_opt {
                Some(b) => {
                    let (ps, q) = template_parts(&p1, b);
                    (Some(ps.clone()), q.clone())
                },
                None => (None, p1.clone()),
            };
            (push(acc, &crate::syntax::TemplatePart::TpCall(sname.clone(), args.clone(), inner_opt.clone(), span.clone())), p2.clone())
        },
    }
}

/// The step machine of `TemplatePartOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplatePartOf: unbounded fn [TemplatePart], Ps, TPartTok -> (([TemplatePart], Ps))
/// ```
pub struct TemplatePartOf {
    pub acc: Array<crate::syntax::TemplatePart>,
    pub p_: Ps,
    pub tpart_tok2: crate::syntax::lexer::TPartTok,
}

impl prism_rtl::Job<(Array<crate::syntax::TemplatePart>, Ps)> for TemplatePartOf {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::TemplatePart>, Ps)> {
        let acc = &self.acc;
        let p_ = &self.p_;
        let tpart_tok2 = &self.tpart_tok2;
        match tpart_tok2 {
            crate::syntax::lexer::TPartTok::TptText(s) => prism_rtl::Turn::Finished((push(acc, &crate::syntax::TemplatePart::TpText(s.clone())), p_.clone())),
            crate::syntax::lexer::TPartTok::TptPlaceholder(toks, col_opt, span) => {
                let col_opt = col_opt.clone();
                let acc = acc.clone();
                let p_ = p_.clone();
                let span = span.clone();
                let toks = toks.clone();
                call_then(start_parse_nested(p_.clone(), toks.clone(), span.clone()), move |parse_nested_63877: (crate::syntax::Expr, Ps)| {
                    let (e, q) = parse_nested_63877;
                    prism_rtl::Turn::Finished((push(&acc, &crate::syntax::TemplatePart::TpPlaceholder(e.clone(), col_opt.clone())), q.clone()))
                })
            },
            crate::syntax::lexer::TPartTok::TptBlock(toks, span) => {
                let acc = acc.clone();
                let p_ = p_.clone();
                let span = span.clone();
                let toks = toks.clone();
                call_then(start_sub(p_.clone(), toks.clone(), at_end(&span)), move |sub_64013: Ps| {
                    let sub_ = sub_64013;
                    call_then(start_parse_block_until_eof(sub_.clone(), span.clone()), move |parse_block_until_eof_64063: (crate::syntax::Block, Ps)| {
                        let (block, s1) = parse_block_until_eof_64063;
                        prism_rtl::Turn::Finished((push(&acc, &crate::syntax::TemplatePart::TpBlock(block.clone())), absorb(&p_, &s1)))
                    })
                })
            },
            crate::syntax::lexer::TPartTok::TptCall(name, attrs, body_opt, span) => {
                let sname = crate::syntax::SName { sigils: name.sigils.clone(), path_: name.path_.clone(), span: span.clone() };
                let body_opt = body_opt.clone();
                let acc = acc.clone();
                let attrs = attrs.clone();
                let p_ = p_.clone();
                let span = span.clone();
                call_value(fold_job(attrs.clone(), (Array::new(), p_.clone()), Rc::new(move |(p0, p1): ((Array<crate::syntax::Arg>, Ps), crate::syntax::lexer::AttrTok)| entered(once_job(move || {
                    let (done, q) = p0;
                    let a = p1;
                    prism_rtl::Turn::More(Rc::new(AttrArg { done: done.clone(), p_: q.clone(), a: a.clone() }))
                }))) as Rc<dyn Fn(((Array<crate::syntax::Arg>, Ps), crate::syntax::lexer::AttrTok)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Arg>, Ps)>>>), move |fold_64298: (Array<crate::syntax::Arg>, Ps)| {
                    let (args, p1) = fold_64298;
                    let (inner_opt, p2) = match &body_opt {
                        Some(b) => {
                            let (ps, q) = template_parts(&p1, b);
                            (Some(ps.clone()), q.clone())
                        },
                        None => (None, p1.clone()),
                    };
                    prism_rtl::Turn::Finished((push(&acc, &crate::syntax::TemplatePart::TpCall(sname.clone(), args.clone(), inner_opt.clone(), span.clone())), p2.clone()))
                })
            },
        }
    }
}

/// `Start TemplatePartOf, x`: what the function value is when passed to `@Run`.
pub fn start_template_part_of(acc: Array<crate::syntax::TemplatePart>, p_: Ps, tpart_tok2: crate::syntax::lexer::TPartTok) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::TemplatePart>, Ps)>> {
    Rc::new(TemplatePartOf { acc, p_, tpart_tok2 })
}

/// ```prism
/// AttrArg: unbounded fn [Arg], Ps, AttrTok -> (([Arg], Ps))
/// ```
pub fn attr_arg(done: &Array<crate::syntax::Arg>, p_: &Ps, a: &crate::syntax::lexer::AttrTok) -> (Array<crate::syntax::Arg>, Ps) {
    let (value, q) = parse_nested(p_, &a.tokens, &a.span);
    (push(done, &crate::syntax::Arg { name: Some(crate::syntax::Ident { name: a.name.clone(), span: a.span.clone() }), value: value.clone(), span: a.span.clone() }), q.clone())
}

/// The step machine of `AttrArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AttrArg: unbounded fn [Arg], Ps, AttrTok -> (([Arg], Ps))
/// ```
pub struct AttrArg {
    pub done: Array<crate::syntax::Arg>,
    pub p_: Ps,
    pub a: crate::syntax::lexer::AttrTok,
}

impl prism_rtl::Job<(Array<crate::syntax::Arg>, Ps)> for AttrArg {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::Arg>, Ps)> {
        let done = &self.done;
        let p_ = &self.p_;
        let a = &self.a;
        let a = a.clone();
        let done = done.clone();
        let p_ = p_.clone();
        call_then(start_parse_nested(p_.clone(), a.tokens.clone(), a.span.clone()), move |parse_nested_64672: (crate::syntax::Expr, Ps)| {
            let (value, q) = parse_nested_64672;
            prism_rtl::Turn::Finished((push(&done, &crate::syntax::Arg { name: Some(crate::syntax::Ident { name: a.name.clone(), span: a.span.clone() }), value: value.clone(), span: a.span.clone() }), q.clone()))
        })
    }
}

/// `Start AttrArg, x`: what the function value is when passed to `@Run`.
pub fn start_attr_arg(done: Array<crate::syntax::Arg>, p_: Ps, a: crate::syntax::lexer::AttrTok) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Arg>, Ps)>> {
    Rc::new(AttrArg { done, p_, a })
}

/// ```prism
/// ParseLambda: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_lambda(p0: &Ps) -> (crate::syntax::Expr, Ps) {
    let start = here(p0);
    let p_ = adv(p0);
    let (params_opt, p1) = if &kind(&p_) == &crate::syntax::lexer::TokKind::KLambdaBar(true) {
        lambda_params(&adv(&p_))
    } else {
        (None, p_.clone())
    };
    if at_open_l(&p1) {
        {
            let (block, q) = parse_indented_block(&p1);
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELambda(params_opt.clone(), Rc::new(crate::syntax::LambdaBody::LbBlock(block.clone())))), span: to(&start, &block.span) }, q.clone())
        }
    } else {
        {
            let (body, q) = parse_expr(&p1);
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELambda(params_opt.clone(), Rc::new(crate::syntax::LambdaBody::LbExpr(Rc::new(body.clone()))))), span: to(&start, &body.span) }, q.clone())
        }
    }
}

/// The step machine of `ParseLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseLambda: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseLambda {
    pub p0: Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, Ps)> for ParseLambda {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, Ps)> {
        let p0 = &self.p0;
        let start = here(p0);
        let p_ = adv(p0);
        let (params_opt, p1) = if &kind(&p_) == &crate::syntax::lexer::TokKind::KLambdaBar(true) {
            lambda_params(&adv(&p_))
        } else {
            (None, p_.clone())
        };
        if at_open_l(&p1) {
            call_then(start_parse_indented_block(p1.clone()), move |parse_indented_block_65301: (crate::syntax::Block, Ps)| {
                let (block, q) = parse_indented_block_65301;
                prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELambda(params_opt.clone(), Rc::new(crate::syntax::LambdaBody::LbBlock(block.clone())))), span: to(&start, &block.span) }, q.clone()))
            })
        } else {
            call_then(start_parse_expr(p1.clone()), move |parse_expr_65449: (crate::syntax::Expr, Ps)| {
                let (body, q) = parse_expr_65449;
                prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELambda(params_opt.clone(), Rc::new(crate::syntax::LambdaBody::LbExpr(Rc::new(body.clone()))))), span: to(&start, &body.span) }, q.clone()))
            })
        }
    }
}

/// `Start ParseLambda, x`: what the function value is when passed to `@Run`.
pub fn start_parse_lambda(p0: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, Ps)>> {
    Rc::new(ParseLambda { p0 })
}

/// ```prism
/// LambdaParams: unbounded fn Ps -> ((?[Pattern], Ps))
/// ```
pub fn lambda_params(p_: &Ps) -> (Option<Array<crate::syntax::Pattern_>>, Ps) {
    let (ps, p1) = if &kind(p_) == &crate::syntax::lexer::TokKind::KLambdaBar(false) {
        (Array::new(), p_.clone())
    } else {
        commas(p_, &(Rc::new(move |p0: Ps| entered(once_job(move || {
            let q = p0;
            prism_rtl::Turn::More(Rc::new(ParsePattern { p_: q.clone(), commas0: false }))
        }))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, Ps)>>>))
    };
    if &kind(&p1) == &crate::syntax::lexer::TokKind::KLambdaBar(false) {
        (Some(ps.clone()), adv(&p1))
    } else {
        (None, error_here(&p1, &Text::lit("expected `|` to close the lambda's parameters")))
    }
}

/// The step machine of `LambdaParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LambdaParams: unbounded fn Ps -> ((?[Pattern], Ps))
/// ```
pub struct LambdaParams {
    pub p_: Ps,
}

impl prism_rtl::Job<(Option<Array<crate::syntax::Pattern_>>, Ps)> for LambdaParams {
    fn cycle(&self) -> prism_rtl::Turn<(Option<Array<crate::syntax::Pattern_>>, Ps)> {
        let p_ = &self.p_;
        let (ps, p1) = if &kind(p_) == &crate::syntax::lexer::TokKind::KLambdaBar(false) {
            (Array::new(), p_.clone())
        } else {
            commas(p_, &(Rc::new(move |p0: Ps| entered(once_job(move || {
                let q = p0;
                prism_rtl::Turn::More(Rc::new(ParsePattern { p_: q.clone(), commas0: false }))
            }))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, Ps)>>>))
        };
        if &kind(&p1) == &crate::syntax::lexer::TokKind::KLambdaBar(false) {
            prism_rtl::Turn::Finished((Some(ps.clone()), adv(&p1)))
        } else {
            prism_rtl::Turn::Finished((None, error_here(&p1, &Text::lit("expected `|` to close the lambda's parameters"))))
        }
    }
}

/// `Start LambdaParams, x`: what the function value is when passed to `@Run`.
pub fn start_lambda_params(p_: Ps) -> Rc<dyn prism_rtl::Job<(Option<Array<crate::syntax::Pattern_>>, Ps)>> {
    Rc::new(LambdaParams { p_ })
}

/// ```prism
/// ParseCond: unbounded fn Ps, Bool -> ((Cond, Ps))
/// ```
pub fn parse_cond(p_: &Ps, allow_guard: &bool) -> (crate::syntax::Cond, Ps) {
    let (pattern, q) = parse_pattern(p_, &true);
    if !q.bad && at_op(&q, &Text::lit("<-")) {
        {
            let (value, q1) = parse_expr(&adv(&q));
            if *allow_guard && at_kw(&q1, &Text::lit("if")) {
                {
                    let (guard, q2) = parse_expr(&adv(&q1));
                    (crate::syntax::Cond::CondBind(pattern.clone(), Rc::new(value.clone()), Rc::new(Some(guard.clone()))), q2.clone())
                }
            } else {
                (crate::syntax::Cond::CondBind(pattern.clone(), Rc::new(value.clone()), Rc::new(None)), q1.clone())
            }
        }
    } else {
        {
            let (e, q1) = parse_expr(p_);
            (crate::syntax::Cond::CondExpr(Rc::new(e.clone())), q1.clone())
        }
    }
}

/// The step machine of `ParseCond`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseCond: unbounded fn Ps, Bool -> ((Cond, Ps))
/// ```
pub struct ParseCond {
    pub p_: Ps,
    pub allow_guard: bool,
}

impl prism_rtl::Job<(crate::syntax::Cond, Ps)> for ParseCond {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Cond, Ps)> {
        let p_ = &self.p_;
        let allow_guard = &self.allow_guard;
        let allow_guard = *allow_guard;
        let p_ = p_.clone();
        call_then(start_parse_pattern(p_.clone(), true), move |parse_pattern_66034: (crate::syntax::Pattern_, Ps)| {
            let (pattern, q) = parse_pattern_66034;
            if !q.bad && at_op(&q, &Text::lit("<-")) {
                call_then(start_parse_expr(adv(&q)), move |parse_expr_66120: (crate::syntax::Expr, Ps)| {
                    let (value, q1) = parse_expr_66120;
                    if allow_guard && at_kw(&q1, &Text::lit("if")) {
                        call_then(start_parse_expr(adv(&q1)), move |parse_expr_66213: (crate::syntax::Expr, Ps)| {
                            let (guard, q2) = parse_expr_66213;
                            prism_rtl::Turn::Finished((crate::syntax::Cond::CondBind(pattern.clone(), Rc::new(value.clone()), Rc::new(Some(guard.clone()))), q2.clone()))
                        })
                    } else {
                        prism_rtl::Turn::Finished((crate::syntax::Cond::CondBind(pattern.clone(), Rc::new(value.clone()), Rc::new(None)), q1.clone()))
                    }
                })
            } else {
                call_then(start_parse_expr(p_.clone()), move |parse_expr_66376: (crate::syntax::Expr, Ps)| {
                    let (e, q1) = parse_expr_66376;
                    prism_rtl::Turn::Finished((crate::syntax::Cond::CondExpr(Rc::new(e.clone())), q1.clone()))
                })
            }
        })
    }
}

/// `Start ParseCond, x`: what the function value is when passed to `@Run`.
pub fn start_parse_cond(p_: Ps, allow_guard: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Cond, Ps)>> {
    Rc::new(ParseCond { p_, allow_guard })
}

/// ```prism
/// ParseIf: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_if(p0: &Ps) -> (crate::syntax::Expr, Ps) {
    let start = here(p0);
    let (cond, p1) = parse_cond(&adv(p0), &false);
    let (then_block, p2) = parse_block_after_colon(&p1);
    let p3 = if at_sep(&p2) && is_else(&kind_at(&p2, &Nat::from(1u32))) {
        adv(&p2)
    } else {
        p2.clone()
    };
    if at_kw(&p3, &Text::lit("else")) {
        {
            let (else_block, q) = parse_block_after_colon(&adv(&p3));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EIf(Rc::new(cond.clone()), then_block.clone(), Some(else_block.clone()))), span: to(&start, &else_block.span) }, q.clone())
        }
    } else {
        (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EIf(Rc::new(cond.clone()), then_block.clone(), None)), span: to(&start, &then_block.span) }, p3.clone())
    }
}

/// The step machine of `ParseIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseIf: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseIf {
    pub p0: Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, Ps)> for ParseIf {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, Ps)> {
        let p0 = &self.p0;
        let start = here(p0);
        let p0 = p0.clone();
        call_then(start_parse_cond(adv(&p0), false), move |parse_cond_66609: (crate::syntax::Cond, Ps)| {
            let (cond, p1) = parse_cond_66609;
            call_then(start_parse_block_after_colon(p1.clone()), move |parse_block_after_colon_66663: (crate::syntax::Block, Ps)| {
                let (then_block, p2) = parse_block_after_colon_66663;
                let p3 = if at_sep(&p2) && is_else(&kind_at(&p2, &Nat::from(1u32))) {
                    adv(&p2)
                } else {
                    p2.clone()
                };
                if at_kw(&p3, &Text::lit("else")) {
                    call_then(start_parse_block_after_colon(adv(&p3)), move |parse_block_after_colon_66814: (crate::syntax::Block, Ps)| {
                        let (else_block, q) = parse_block_after_colon_66814;
                        prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EIf(Rc::new(cond.clone()), then_block.clone(), Some(else_block.clone()))), span: to(&start, &else_block.span) }, q.clone()))
                    })
                } else {
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EIf(Rc::new(cond.clone()), then_block.clone(), None)), span: to(&start, &then_block.span) }, p3.clone()))
                }
            })
        })
    }
}

/// `Start ParseIf, x`: what the function value is when passed to `@Run`.
pub fn start_parse_if(p0: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, Ps)>> {
    Rc::new(ParseIf { p0 })
}

/// ```prism
/// IsElse: fn TokKind -> Bool
/// ```
pub fn is_else(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KKw(c0_0_0, _) if (c0_0_0 == &Text::lit("else")) => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParseMatch: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_match(p0: &Ps) -> (crate::syntax::Expr, Ps) {
    let start = here(p0);
    let (scrutinee, p1) = parse_expr(&adv(p0));
    let p2 = expect_colon(&p1);
    if at_open_l(&p2) {
        {
            let (arms, q) = match_arms(&adv(&p2));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMatch(Rc::new(scrutinee.clone()), arms.clone())), span: to(&start, &prev(&q)) }, q.clone())
        }
    } else {
        (no_expr(), error_here(&p2, &Text::lit("a `match`'s arms stand in an indented block after its `:`")))
    }
}

/// The step machine of `ParseMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseMatch: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseMatch {
    pub p0: Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, Ps)> for ParseMatch {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, Ps)> {
        let p0 = &self.p0;
        let start = here(p0);
        let p0 = p0.clone();
        call_then(start_parse_expr(adv(&p0)), move |parse_expr_67395: (crate::syntax::Expr, Ps)| {
            let (scrutinee, p1) = parse_expr_67395;
            let p2 = expect_colon(&p1);
            if at_open_l(&p2) {
                call_then(start_match_arms(adv(&p2)), move |match_arms_67487: (Array<crate::syntax::Arm>, Ps)| {
                    let (arms, q) = match_arms_67487;
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMatch(Rc::new(scrutinee.clone()), arms.clone())), span: to(&start, &prev(&q)) }, q.clone()))
                })
            } else {
                prism_rtl::Turn::Finished((no_expr(), error_here(&p2, &Text::lit("a `match`'s arms stand in an indented block after its `:`"))))
            }
        })
    }
}

/// `Start ParseMatch, x`: what the function value is when passed to `@Run`.
pub fn start_parse_match(p0: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, Ps)>> {
    Rc::new(ParseMatch { p0 })
}

/// ```prism
/// MatchArms: unbounded fn Ps -> (([Arm], Ps))
/// ```
pub fn match_arms(p0: &Ps) -> (Array<crate::syntax::Arm>, Ps) {
    let mut this: (Array<crate::syntax::Arm>, Ps) = (Array::new(), p0.clone());
    let mut arms: Array<crate::syntax::Arm> = Array::new();
    let mut p_: Ps = p0.clone();
    let mut going: bool = true;
    while going {
        let (arm, q) = parse_arm(&p_);
        if !q.bad {
            arms = push(&arms, &arm);
        }
        p_ = recovered(&q);
        match &kind(&p_) {
            crate::syntax::lexer::TokKind::KLaySep => {
                p_ = adv(&p_);
            }
            crate::syntax::lexer::TokKind::KLayClose => {
                p_ = adv(&p_);
                going = false;
            }
            crate::syntax::lexer::TokKind::KEof => {
                going = false;
            }
            _ => {
                p_ = recover(&complain(&p_, &Text::lit("expected the end of the arm")));
            }
        }
    }
    this = (arms.clone(), p_.clone());
    this
}

/// The step machine of `MatchArms`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MatchArms: unbounded fn Ps -> (([Arm], Ps))
/// ```
pub struct MatchArms {
    pub p0: Ps,
}

impl prism_rtl::Job<(Array<crate::syntax::Arm>, Ps)> for MatchArms {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::Arm>, Ps)> {
        let p0 = &self.p0;
        let mut this: (Array<crate::syntax::Arm>, Ps) = (Array::new(), p0.clone());
        let mut arms: Array<crate::syntax::Arm> = Array::new();
        let mut p_: Ps = p0.clone();
        let mut going: bool = true;
        call_then(loop_job((this, arms, going, p_), move |(mut this, mut arms, mut going, mut p_): ((Array<crate::syntax::Arm>, Ps), Array<crate::syntax::Arm>, bool, Ps)| if going {
            {
                let (arm, q) = parse_arm(&p_);
                if !q.bad {
                    arms = push(&arms, &arm);
                }
                p_ = recovered(&q);
                match &kind(&p_) {
                    crate::syntax::lexer::TokKind::KLaySep => {
                        p_ = adv(&p_);
                    }
                    crate::syntax::lexer::TokKind::KLayClose => {
                        p_ = adv(&p_);
                        going = false;
                    }
                    crate::syntax::lexer::TokKind::KEof => {
                        going = false;
                    }
                    _ => {
                        p_ = recover(&complain(&p_, &Text::lit("expected the end of the arm")));
                    }
                }
                Ok((this, arms, going, p_))
            }
        } else {
            Err((this, arms, going, p_))
        }), move |(mut this, mut arms, mut going, mut p_): ((Array<crate::syntax::Arm>, Ps), Array<crate::syntax::Arm>, bool, Ps)| {
            this = (arms.clone(), p_.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start MatchArms, x`: what the function value is when passed to `@Run`.
pub fn start_match_arms(p0: Ps) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Arm>, Ps)>> {
    Rc::new(MatchArms { p0 })
}

/// ```prism
/// ParseArm: unbounded fn Ps -> ((Arm, Ps))
/// ```
pub fn parse_arm(p_: &Ps) -> (crate::syntax::Arm, Ps) {
    let start = here(p_);
    if at_kw(p_, &Text::lit("otherwise")) {
        {
            let (body, q) = parse_block_after_colon(&adv(p_));
            (crate::syntax::Arm { pattern: None, guard: None, body: body.clone(), span: to(&start, &body.span) }, q.clone())
        }
    } else {
        if at_kw(p_, &Text::lit("ignore")) && (&kind_at(p_, &Nat::from(1u32)) == &crate::syntax::lexer::TokKind::KColon) {
            (crate::syntax::Arm { pattern: None, guard: None, body: no_block(), span: start.clone() }, error_at(p_, &here(p_), &Text::lit("an arm beginning `ignore:` would read as \"ignore these cases\": the catch-all is `otherwise:`")))
        } else {
            {
                let (pattern, p1) = parse_pattern(p_, &true);
                let (guard_opt, p2) = if at_kw(&p1, &Text::lit("if")) {
                    optional_expr(&adv(&p1))
                } else {
                    (None, p1.clone())
                };
                let (body, p3) = parse_block_after_colon(&p2);
                (crate::syntax::Arm { pattern: Some(pattern.clone()), guard: guard_opt.clone(), body: body.clone(), span: to(&start, &body.span) }, p3.clone())
            }
        }
    }
}

/// ```prism
/// OptionalExpr: unbounded fn Ps -> ((?Expr, Ps))
/// ```
pub fn optional_expr(p_: &Ps) -> (Option<crate::syntax::Expr>, Ps) {
    let (e, q) = parse_expr(p_);
    (Some(e.clone()), q.clone())
}

/// ```prism
/// ParseFor: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_for(p0: &Ps) -> (crate::syntax::Expr, Ps) {
    let start = here(p0);
    let p_ = adv(p0);
    let (binders_opt, p1) = for_binders_of(&p_);
    let (source, p2) = parse_expr(&p1);
    let (body, p3) = parse_block_after_colon(&p2);
    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EFor(binders_opt.clone(), Rc::new(source.clone()), body.clone())), span: to(&start, &body.span) }, p3.clone())
}

/// The step machine of `ParseFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseFor: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseFor {
    pub p0: Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, Ps)> for ParseFor {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, Ps)> {
        let p0 = &self.p0;
        let start = here(p0);
        let p_ = adv(p0);
        call_then(start_for_binders_of(p_.clone()), move |for_binders_of_69343: (Option<crate::syntax::ForBinders>, Ps)| {
            let (binders_opt, p1) = for_binders_of_69343;
            call_then(start_parse_expr(p1.clone()), move |parse_expr_69383: (crate::syntax::Expr, Ps)| {
                let (source, p2) = parse_expr_69383;
                call_then(start_parse_block_after_colon(p2.clone()), move |parse_block_after_colon_69419: (crate::syntax::Block, Ps)| {
                    let (body, p3) = parse_block_after_colon_69419;
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EFor(binders_opt.clone(), Rc::new(source.clone()), body.clone())), span: to(&start, &body.span) }, p3.clone()))
                })
            })
        })
    }
}

/// `Start ParseFor, x`: what the function value is when passed to `@Run`.
pub fn start_parse_for(p0: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, Ps)>> {
    Rc::new(ParseFor { p0 })
}

/// ```prism
/// ForBindersOf: unbounded fn Ps -> ((?ForBinders, Ps))
/// ```
pub fn for_binders_of(p_: &Ps) -> (Option<crate::syntax::ForBinders>, Ps) {
    let (first_, q1) = parse_pattern(p_, &false);
    let (second_opt, q2) = if at_comma(&q1) { optional_pattern(&adv(&q1)) } else { (None, q1.clone()) };
    if !q2.bad && at_op(&q2, &Text::lit("<-")) {
        (Some(crate::syntax::ForBinders { first: first_.clone(), second: second_opt.clone() }), adv(&q2))
    } else {
        (None, p_.clone())
    }
}

/// The step machine of `ForBindersOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ForBindersOf: unbounded fn Ps -> ((?ForBinders, Ps))
/// ```
pub struct ForBindersOf {
    pub p_: Ps,
}

impl prism_rtl::Job<(Option<crate::syntax::ForBinders>, Ps)> for ForBindersOf {
    fn cycle(&self) -> prism_rtl::Turn<(Option<crate::syntax::ForBinders>, Ps)> {
        let p_ = &self.p_;
        let p_ = p_.clone();
        call_then(start_parse_pattern(p_.clone(), false), move |parse_pattern_69704: (crate::syntax::Pattern_, Ps)| {
            let (first_, q1) = parse_pattern_69704;
            let (second_opt, q2) = if at_comma(&q1) { optional_pattern(&adv(&q1)) } else { (None, q1.clone()) };
            if !q2.bad && at_op(&q2, &Text::lit("<-")) {
                prism_rtl::Turn::Finished((Some(crate::syntax::ForBinders { first: first_.clone(), second: second_opt.clone() }), adv(&q2)))
            } else {
                prism_rtl::Turn::Finished((None, p_.clone()))
            }
        })
    }
}

/// `Start ForBindersOf, x`: what the function value is when passed to `@Run`.
pub fn start_for_binders_of(p_: Ps) -> Rc<dyn prism_rtl::Job<(Option<crate::syntax::ForBinders>, Ps)>> {
    Rc::new(ForBindersOf { p_ })
}

/// ```prism
/// OptionalPattern: unbounded fn Ps -> ((?Pattern, Ps))
/// ```
pub fn optional_pattern(p_: &Ps) -> (Option<crate::syntax::Pattern_>, Ps) {
    let (pat, q) = parse_pattern(p_, &false);
    (Some(pat.clone()), q.clone())
}

/// ```prism
/// ParseBlockAfterColon: unbounded fn Ps -> ((Block, Ps))
/// ```
pub fn parse_block_after_colon(p0: &Ps) -> (crate::syntax::Block, Ps) {
    let p_ = expect_colon(p0);
    if at_open_l(&p_) {
        parse_indented_block(&p_)
    } else {
        if at_stmt_boundary(&p_) {
            (no_block(), error_here(&p_, &Text::lit("expected a statement after `:`")))
        } else {
            {
                let start = here(&p_);
                let (first_, p1) = parse_stmt(&p_);
                let r = {
                    let mut this: (Array<crate::syntax::Stmt>, Ps) = (Array::from(vec![first_.clone()]), p1.clone());
                    let mut stmts: Array<crate::syntax::Stmt> = Array::from(vec![first_.clone()]);
                    let mut q: Ps = p1.clone();
                    while (&kind(&q) == &crate::syntax::lexer::TokKind::KSemi) && !q.bad {
                        let (st, q2) = parse_stmt(&adv(&q));
                        stmts = push(&stmts, &st);
                        q = q2.clone();
                    }
                    this = (stmts.clone(), q.clone());
                    this
                };
                let (stmts, q) = r.clone();
                (crate::syntax::Block { stmts: stmts.clone(), inline: true, span: to(&start, &prev(&q)) }, q.clone())
            }
        }
    }
}

/// The step machine of `ParseBlockAfterColon`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseBlockAfterColon: unbounded fn Ps -> ((Block, Ps))
/// ```
pub struct ParseBlockAfterColon {
    pub p0: Ps,
}

impl prism_rtl::Job<(crate::syntax::Block, Ps)> for ParseBlockAfterColon {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Block, Ps)> {
        let p0 = &self.p0;
        let p_ = expect_colon(p0);
        if at_open_l(&p_) {
            prism_rtl::Turn::More(Rc::new(ParseIndentedBlock { p0: p_.clone() }))
        } else {
            if at_stmt_boundary(&p_) {
                prism_rtl::Turn::Finished((no_block(), error_here(&p_, &Text::lit("expected a statement after `:`"))))
            } else {
                {
                    let start = here(&p_);
                    call_then(start_parse_stmt(p_.clone()), move |parse_stmt_70899: (crate::syntax::Stmt, Ps)| {
                        let (first_, p1) = parse_stmt_70899;
                        let mut this: (Array<crate::syntax::Stmt>, Ps) = (Array::from(vec![first_.clone()]), p1.clone());
                        let mut stmts: Array<crate::syntax::Stmt> = Array::from(vec![first_.clone()]);
                        let mut q: Ps = p1.clone();
                        let start = start.clone();
                        call_then(loop_job((this, q, stmts), move |(mut this, mut q, mut stmts): ((Array<crate::syntax::Stmt>, Ps), Ps, Array<crate::syntax::Stmt>)| if (&kind(&q) == &crate::syntax::lexer::TokKind::KSemi) && !q.bad {
                            {
                                let (st, q2) = parse_stmt(&adv(&q));
                                stmts = push(&stmts, &st);
                                q = q2.clone();
                                Ok((this, q, stmts))
                            }
                        } else {
                            Err((this, q, stmts))
                        }), move |(mut this, mut q, mut stmts): ((Array<crate::syntax::Stmt>, Ps), Ps, Array<crate::syntax::Stmt>)| {
                            this = (stmts.clone(), q.clone());
                            let r = this;
                            let (stmts, q) = r.clone();
                            prism_rtl::Turn::Finished((crate::syntax::Block { stmts: stmts.clone(), inline: true, span: to(&start, &prev(&q)) }, q.clone()))
                        })
                    })
                }
            }
        }
    }
}

/// `Start ParseBlockAfterColon, x`: what the function value is when passed to `@Run`.
pub fn start_parse_block_after_colon(p0: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Block, Ps)>> {
    Rc::new(ParseBlockAfterColon { p0 })
}

/// ```prism
/// ParseIndentedBlock: unbounded fn Ps -> ((Block, Ps))
/// ```
pub fn parse_indented_block(p0: &Ps) -> (crate::syntax::Block, Ps) {
    let start = here(p0);
    let (stmts, q) = stmts_until(&adv(p0), &true);
    (crate::syntax::Block { stmts: stmts.clone(), inline: false, span: to(&start, &prev(&q)) }, q.clone())
}

/// The step machine of `ParseIndentedBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseIndentedBlock: unbounded fn Ps -> ((Block, Ps))
/// ```
pub struct ParseIndentedBlock {
    pub p0: Ps,
}

impl prism_rtl::Job<(crate::syntax::Block, Ps)> for ParseIndentedBlock {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Block, Ps)> {
        let p0 = &self.p0;
        let start = here(p0);
        let p0 = p0.clone();
        call_then(start_stmts_until(adv(&p0), true), move |stmts_until_71501: (Array<crate::syntax::Stmt>, Ps)| {
            let (stmts, q) = stmts_until_71501;
            prism_rtl::Turn::Finished((crate::syntax::Block { stmts: stmts.clone(), inline: false, span: to(&start, &prev(&q)) }, q.clone()))
        })
    }
}

/// `Start ParseIndentedBlock, x`: what the function value is when passed to `@Run`.
pub fn start_parse_indented_block(p0: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Block, Ps)>> {
    Rc::new(ParseIndentedBlock { p0 })
}

/// ```prism
/// ParseBlockUntilEof: unbounded fn Ps, Range -> ((Block, Ps))
/// ```
pub fn parse_block_until_eof(p_: &Ps, span: &crate::syntax::Range) -> (crate::syntax::Block, Ps) {
    let (stmts, q) = if at_eof(p_) { (Array::new(), p_.clone()) } else { stmts_until(p_, &false) };
    (crate::syntax::Block { stmts: stmts.clone(), inline: false, span: span.clone() }, q.clone())
}

/// The step machine of `ParseBlockUntilEof`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseBlockUntilEof: unbounded fn Ps, Range -> ((Block, Ps))
/// ```
pub struct ParseBlockUntilEof {
    pub p_: Ps,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::syntax::Block, Ps)> for ParseBlockUntilEof {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Block, Ps)> {
        let p_ = &self.p_;
        let span = &self.span;
        let (stmts, q) = if at_eof(p_) { (Array::new(), p_.clone()) } else { stmts_until(p_, &false) };
        prism_rtl::Turn::Finished((crate::syntax::Block { stmts: stmts.clone(), inline: false, span: span.clone() }, q.clone()))
    }
}

/// `Start ParseBlockUntilEof, x`: what the function value is when passed to `@Run`.
pub fn start_parse_block_until_eof(p_: Ps, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::syntax::Block, Ps)>> {
    Rc::new(ParseBlockUntilEof { p_, span })
}

/// ```prism
/// StmtsUntil: unbounded fn Ps, Bool -> (([Stmt], Ps))
/// ```
pub fn stmts_until(p0: &Ps, indented: &bool) -> (Array<crate::syntax::Stmt>, Ps) {
    let mut this: (Array<crate::syntax::Stmt>, Ps) = (Array::new(), p0.clone());
    let mut stmts: Array<crate::syntax::Stmt> = Array::new();
    let mut p_: Ps = p0.clone();
    let mut going: bool = true;
    while going {
        let (st, q) = parse_stmt(&p_);
        if !q.bad {
            stmts = push(&stmts, &st);
        }
        p_ = recovered(&q);
        match &kind(&p_) {
            crate::syntax::lexer::TokKind::KLaySep => {
                p_ = adv(&p_);
                if !*indented && at_eof(&p_) {
                    going = false;
                }
            }
            crate::syntax::lexer::TokKind::KLayClose => {
                p_ = adv(&p_);
                if *indented || at_eof(&p_) {
                    going = false;
                }
            }
            crate::syntax::lexer::TokKind::KEof => {
                going = false;
            }
            _ => {
                p_ = recover(&complain(&p_, &Text::lit("expected the end of the statement")));
            }
        }
    }
    this = (stmts.clone(), p_.clone());
    this
}

/// The step machine of `StmtsUntil`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtsUntil: unbounded fn Ps, Bool -> (([Stmt], Ps))
/// ```
pub struct StmtsUntil {
    pub p0: Ps,
    pub indented: bool,
}

impl prism_rtl::Job<(Array<crate::syntax::Stmt>, Ps)> for StmtsUntil {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::Stmt>, Ps)> {
        let p0 = &self.p0;
        let indented = &self.indented;
        let mut this: (Array<crate::syntax::Stmt>, Ps) = (Array::new(), p0.clone());
        let mut stmts: Array<crate::syntax::Stmt> = Array::new();
        let mut p_: Ps = p0.clone();
        let mut going: bool = true;
        call_then(loop_job((this, going, p_, stmts), {
            let indented = *indented;
            move |(mut this, mut going, mut p_, mut stmts): ((Array<crate::syntax::Stmt>, Ps), bool, Ps, Array<crate::syntax::Stmt>)| if going {
                {
                    let (st, q) = parse_stmt(&p_);
                    if !q.bad {
                        stmts = push(&stmts, &st);
                    }
                    p_ = recovered(&q);
                    match &kind(&p_) {
                        crate::syntax::lexer::TokKind::KLaySep => {
                            p_ = adv(&p_);
                            if !indented && at_eof(&p_) {
                                going = false;
                            }
                        }
                        crate::syntax::lexer::TokKind::KLayClose => {
                            p_ = adv(&p_);
                            if indented || at_eof(&p_) {
                                going = false;
                            }
                        }
                        crate::syntax::lexer::TokKind::KEof => {
                            going = false;
                        }
                        _ => {
                            p_ = recover(&complain(&p_, &Text::lit("expected the end of the statement")));
                        }
                    }
                    Ok((this, going, p_, stmts))
                }
            } else {
                Err((this, going, p_, stmts))
            }
        }), move |(mut this, mut going, mut p_, mut stmts): ((Array<crate::syntax::Stmt>, Ps), bool, Ps, Array<crate::syntax::Stmt>)| {
            this = (stmts.clone(), p_.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start StmtsUntil, x`: what the function value is when passed to `@Run`.
pub fn start_stmts_until(p0: Ps, indented: bool) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Stmt>, Ps)>> {
    Rc::new(StmtsUntil { p0, indented })
}

/// ```prism
/// ParseStmt: unbounded fn Ps -> ((Stmt, Ps))
/// ```
pub fn parse_stmt(p_: &Ps) -> (crate::syntax::Stmt, Ps) {
    let start = here(p_);
    let (kind_, q) = stmt_kind_of(p_, &start);
    (crate::syntax::Stmt { kind: kind_.clone(), span: to(&start, &prev(&q)) }, q.clone())
}

/// The step machine of `ParseStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseStmt: unbounded fn Ps -> ((Stmt, Ps))
/// ```
pub struct ParseStmt {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::Stmt, Ps)> for ParseStmt {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Stmt, Ps)> {
        let p_ = &self.p_;
        let start = here(p_);
        let p_ = p_.clone();
        call_then(start_stmt_kind_of(p_.clone(), start.clone()), move |stmt_kind_of_72929: (crate::syntax::StmtKind, Ps)| {
            let (kind_, q) = stmt_kind_of_72929;
            prism_rtl::Turn::Finished((crate::syntax::Stmt { kind: kind_.clone(), span: to(&start, &prev(&q)) }, q.clone()))
        })
    }
}

/// `Start ParseStmt, x`: what the function value is when passed to `@Run`.
pub fn start_parse_stmt(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Stmt, Ps)>> {
    Rc::new(ParseStmt { p_ })
}

/// ```prism
/// StmtKindOf: unbounded fn Ps, Range -> ((StmtKind, Ps))
/// ```
pub fn stmt_kind_of(p_: &Ps, start: &crate::syntax::Range) -> (crate::syntax::StmtKind, Ps) {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KKw(m73084_0_0, m73084_0_1) if (&m73084_0_0 == &Text::lit("emit")) && (&m73084_0_1 == &Text::lit("")) => {
            let (r, q) = parse_row(&adv(p_));
            (crate::syntax::StmtKind::SEmit(r.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m73084_1_0, m73084_1_1) if (&m73084_1_0 == &Text::lit("let")) && (&m73084_1_1 == &Text::lit("")) => {
            let (pattern, p1) = parse_pattern(&adv(p_), &false);
            let (ty_opt, p2) = optional_annotation(&p1);
            let (value, p3) = parse_rhs_expr(&expect_op(&p2, &Text::lit("=")));
            (crate::syntax::StmtKind::SLet(pattern.clone(), ty_opt.clone(), value.clone()), p3.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m73084_2_0, m73084_2_1) if (&m73084_2_0 == &Text::lit("fn")) && (&m73084_2_1 == &Text::lit("")) => {
            let (f, q) = parse_fn_clause(p_);
            (crate::syntax::StmtKind::SFn(f.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m73084_3_0, m73084_3_1) if (&m73084_3_0 == &Text::lit("ignore")) && (&m73084_3_1 == &Text::lit("")) && at_op(&adv(p_), &Text::lit("<-")) => {
            let (e, q) = parse_rhs_expr(&adv(&adv(p_)));
            (crate::syntax::StmtKind::SIgnore(e.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(w, m73084_4_1) if (&m73084_4_1 == &Text::lit("")) && ((&w == &Text::lit("require")) || (&w == &Text::lit("forbid"))) => {
            let (c, p1) = parse_rhs_expr(&adv(p_));
            let q = if at_comma(&p1) {
                error_at(&p1, &here(&p1), &Text::from(format!("`{}` takes its condition alone, with no error value after a comma (decisions.md D15): a failed guard under `~` raises `Prelude.Unmet` (D11), and a comma after a guard belongs to a call at the head of its condition, as in `require Clear g, from, corner`", &w)))
            } else {
                p1.clone()
            };
            if &w == &Text::lit("require") {
                (crate::syntax::StmtKind::SRequire(c.clone()), q.clone())
            } else {
                (crate::syntax::StmtKind::SForbid(c.clone()), q.clone())
            }
        },
        crate::syntax::lexer::TokKind::KKw(m73084_5_0, m73084_5_1) if (&m73084_5_0 == &Text::lit("while")) && (&m73084_5_1 == &Text::lit("")) => {
            let (cond, p1) = parse_cond(&adv(p_), &true);
            let (body, q) = parse_block_after_colon(&p1);
            (crate::syntax::StmtKind::SWhile(cond.clone(), body.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KKw(m73084_6_0, m73084_6_1) if (&m73084_6_0 == &Text::lit("return")) && (&m73084_6_1 == &Text::lit("")) => {
            let p1 = out_of_scope(&adv(p_), &here(p_), &Text::lit("`T monad:` blocks and `^Monad`"), &Text::lit("`return` ends a monad block, which is out of this compiler"));
            let (e, q) = parse_rhs_expr(&p1);
            (crate::syntax::StmtKind::SReturn(e.clone()), q.clone())
        },
        crate::syntax::lexer::TokKind::KName(_) if (&kind_at(p_, &Nat::from(1u32)) == &crate::syntax::lexer::TokKind::KColon) => if &kind_at(p_, &Nat::from(2u32)) == &crate::syntax::lexer::TokKind::KLayOpen {
            {
                let (name, p1) = parse_sname(p_);
                let (body, q) = parse_block_after_colon(&p1);
                (crate::syntax::StmtKind::SWidget(crate::syntax::WidgetDecl { name: name.clone(), body: body.clone(), span: to(start, &body.span) }), q.clone())
            }
        } else {
            {
                let (sig, q) = parse_signature(p_);
                (crate::syntax::StmtKind::SSignature(sig.clone()), q.clone())
            }
        },
        _ => other_stmt(p_),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `StmtKindOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtKindOf: unbounded fn Ps, Range -> ((StmtKind, Ps))
/// ```
pub struct StmtKindOf {
    pub p_: Ps,
    pub start: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::syntax::StmtKind, Ps)> for StmtKindOf {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::StmtKind, Ps)> {
        let p_ = &self.p_;
        let start = &self.start;
        match kind(p_) {
            crate::syntax::lexer::TokKind::KKw(m73084_0_0, m73084_0_1) if (&m73084_0_0 == &Text::lit("emit")) && (&m73084_0_1 == &Text::lit("")) => {
                let p_ = p_.clone();
                call_then(start_parse_row(adv(&p_)), move |parse_row_73141: (crate::syntax::Row_, Ps)| {
                    let (r, q) = parse_row_73141;
                    prism_rtl::Turn::Finished((crate::syntax::StmtKind::SEmit(r.clone()), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m73084_1_0, m73084_1_1) if (&m73084_1_0 == &Text::lit("let")) && (&m73084_1_1 == &Text::lit("")) => {
                let p_ = p_.clone();
                call_then(start_parse_pattern(adv(&p_), false), move |parse_pattern_73230: (crate::syntax::Pattern_, Ps)| {
                    let (pattern, p1) = parse_pattern_73230;
                    call_then(start_optional_annotation(p1.clone()), move |optional_annotation_73284: (Option<crate::syntax::Type>, Ps)| {
                        let (ty_opt, p2) = optional_annotation_73284;
                        call_then(start_parse_rhs_expr(expect_op(&p2, &Text::lit("="))), move |parse_rhs_expr_73334: (crate::syntax::Expr, Ps)| {
                            let (value, p3) = parse_rhs_expr_73334;
                            prism_rtl::Turn::Finished((crate::syntax::StmtKind::SLet(pattern.clone(), ty_opt.clone(), value.clone()), p3.clone()))
                        })
                    })
                })
            },
            crate::syntax::lexer::TokKind::KKw(m73084_2_0, m73084_2_1) if (&m73084_2_0 == &Text::lit("fn")) && (&m73084_2_1 == &Text::lit("")) => {
                let p_ = p_.clone();
                call_then(start_parse_fn_clause(p_.clone()), move |parse_fn_clause_73450: (crate::syntax::FnClause, Ps)| {
                    let (f, q) = parse_fn_clause_73450;
                    prism_rtl::Turn::Finished((crate::syntax::StmtKind::SFn(f.clone()), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(m73084_3_0, m73084_3_1) if (&m73084_3_0 == &Text::lit("ignore")) && (&m73084_3_1 == &Text::lit("")) && at_op(&adv(p_), &Text::lit("<-")) => {
                let p_ = p_.clone();
                call_then(start_parse_rhs_expr(adv(&adv(&p_))), move |parse_rhs_expr_73556: (crate::syntax::Expr, Ps)| {
                    let (e, q) = parse_rhs_expr_73556;
                    prism_rtl::Turn::Finished((crate::syntax::StmtKind::SIgnore(e.clone()), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KKw(w, m73084_4_1) if (&m73084_4_1 == &Text::lit("")) && ((&w == &Text::lit("require")) || (&w == &Text::lit("forbid"))) => {
                let p_ = p_.clone();
                call_then(start_parse_rhs_expr(adv(&p_)), move |parse_rhs_expr_73849: (crate::syntax::Expr, Ps)| {
                    let (c, p1) = parse_rhs_expr_73849;
                    let q = if at_comma(&p1) {
                        error_at(&p1, &here(&p1), &Text::from(format!("`{}` takes its condition alone, with no error value after a comma (decisions.md D15): a failed guard under `~` raises `Prelude.Unmet` (D11), and a comma after a guard belongs to a call at the head of its condition, as in `require Clear g, from, corner`", &w)))
                    } else {
                        p1.clone()
                    };
                    if &w == &Text::lit("require") {
                        prism_rtl::Turn::Finished((crate::syntax::StmtKind::SRequire(c.clone()), q.clone()))
                    } else {
                        prism_rtl::Turn::Finished((crate::syntax::StmtKind::SForbid(c.clone()), q.clone()))
                    }
                })
            },
            crate::syntax::lexer::TokKind::KKw(m73084_5_0, m73084_5_1) if (&m73084_5_0 == &Text::lit("while")) && (&m73084_5_1 == &Text::lit("")) => {
                let p_ = p_.clone();
                call_then(start_parse_cond(adv(&p_), true), move |parse_cond_74305: (crate::syntax::Cond, Ps)| {
                    let (cond, p1) = parse_cond_74305;
                    call_then(start_parse_block_after_colon(p1.clone()), move |parse_block_after_colon_74355: (crate::syntax::Block, Ps)| {
                        let (body, q) = parse_block_after_colon_74355;
                        prism_rtl::Turn::Finished((crate::syntax::StmtKind::SWhile(cond.clone(), body.clone()), q.clone()))
                    })
                })
            },
            crate::syntax::lexer::TokKind::KKw(m73084_6_0, m73084_6_1) if (&m73084_6_0 == &Text::lit("return")) && (&m73084_6_1 == &Text::lit("")) => {
                let p1 = out_of_scope(&adv(p_), &here(p_), &Text::lit("`T monad:` blocks and `^Monad`"), &Text::lit("`return` ends a monad block, which is out of this compiler"));
                call_then(start_parse_rhs_expr(p1.clone()), move |parse_rhs_expr_74601: (crate::syntax::Expr, Ps)| {
                    let (e, q) = parse_rhs_expr_74601;
                    prism_rtl::Turn::Finished((crate::syntax::StmtKind::SReturn(e.clone()), q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KName(_) if (&kind_at(p_, &Nat::from(1u32)) == &crate::syntax::lexer::TokKind::KColon) => if &kind_at(p_, &Nat::from(2u32)) == &crate::syntax::lexer::TokKind::KLayOpen {
                {
                    let (name, p1) = parse_sname(p_);
                    let start = start.clone();
                    call_then(start_parse_block_after_colon(p1.clone()), move |parse_block_after_colon_74848: (crate::syntax::Block, Ps)| {
                        let (body, q) = parse_block_after_colon_74848;
                        prism_rtl::Turn::Finished((crate::syntax::StmtKind::SWidget(crate::syntax::WidgetDecl { name: name.clone(), body: body.clone(), span: to(&start, &body.span) }), q.clone()))
                    })
                }
            } else {
                {
                    let p_ = p_.clone();
                    call_then(start_parse_signature(p_.clone()), move |parse_signature_75003: (crate::syntax::Signature, Ps)| {
                        let (sig, q) = parse_signature_75003;
                        prism_rtl::Turn::Finished((crate::syntax::StmtKind::SSignature(sig.clone()), q.clone()))
                    })
                }
            },
            _ => prism_rtl::Turn::More(Rc::new(OtherStmt { p_: p_.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start StmtKindOf, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_kind_of(p_: Ps, start: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::syntax::StmtKind, Ps)>> {
    Rc::new(StmtKindOf { p_, start })
}

/// ```prism
/// OtherStmt: unbounded fn Ps -> ((StmtKind, Ps))
/// ```
pub fn other_stmt(p_: &Ps) -> (crate::syntax::StmtKind, Ps) {
    let (upd, u) = parse_update_stmt(p_);
    let (pattern, b) = parse_pattern(p_, &true);
    if !u.bad {
        (upd.clone(), u.clone())
    } else {
        if !b.bad && at_op(&b, &Text::lit("<-")) {
            {
                let (value, p1) = parse_rhs_expr(&adv(&b));
                let (then_step_opt, p2) = if at_kw(&p1, &Text::lit("then")) {
                    optional_rhs(&adv(&p1))
                } else {
                    (None, p1.clone())
                };
                if at_kw(&p2, &Text::lit("then")) {
                    (crate::syntax::StmtKind::SExpr(no_expr()), error_at(&p2, &here(&p2), &Text::lit("`then` does not associate: a hold has one start and one step")))
                } else {
                    (crate::syntax::StmtKind::SBind(pattern.clone(), value.clone(), then_step_opt.clone()), p2.clone())
                }
            }
        } else {
            {
                let (e, p1) = parse_rhs_expr(p_);
                if at_op(&p1, &Text::lit("<-")) {
                    (crate::syntax::StmtKind::SExpr(e.clone()), error_at(&p1, &here(&p1), &Text::lit("the left side of `<-` is not a pattern")))
                } else {
                    if at_kw(&p1, &Text::lit("then")) {
                        (crate::syntax::StmtKind::SExpr(e.clone()), error_at(&p1, &here(&p1), &Text::lit("`then` belongs to a hold: `$x <- start then step`")))
                    } else {
                        (crate::syntax::StmtKind::SExpr(e.clone()), p1.clone())
                    }
                }
            }
        }
    }
}

/// The step machine of `OtherStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OtherStmt: unbounded fn Ps -> ((StmtKind, Ps))
/// ```
pub struct OtherStmt {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::StmtKind, Ps)> for OtherStmt {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::StmtKind, Ps)> {
        let p_ = &self.p_;
        let p_ = p_.clone();
        call_then(start_parse_update_stmt(p_.clone()), move |parse_update_stmt_75244: (crate::syntax::StmtKind, Ps)| {
            let (upd, u) = parse_update_stmt_75244;
            call_then(start_parse_pattern(p_.clone(), true), move |parse_pattern_75287: (crate::syntax::Pattern_, Ps)| {
                let (pattern, b) = parse_pattern_75287;
                if !u.bad {
                    prism_rtl::Turn::Finished((upd.clone(), u.clone()))
                } else {
                    if !b.bad && at_op(&b, &Text::lit("<-")) {
                        call_then(start_parse_rhs_expr(adv(&b)), move |parse_rhs_expr_75408: (crate::syntax::Expr, Ps)| {
                            let (value, p1) = parse_rhs_expr_75408;
                            let (then_step_opt, p2) = if at_kw(&p1, &Text::lit("then")) {
                                optional_rhs(&adv(&p1))
                            } else {
                                (None, p1.clone())
                            };
                            if at_kw(&p2, &Text::lit("then")) {
                                prism_rtl::Turn::Finished((crate::syntax::StmtKind::SExpr(no_expr()), error_at(&p2, &here(&p2), &Text::lit("`then` does not associate: a hold has one start and one step"))))
                            } else {
                                prism_rtl::Turn::Finished((crate::syntax::StmtKind::SBind(pattern.clone(), value.clone(), then_step_opt.clone()), p2.clone()))
                            }
                        })
                    } else {
                        call_then(start_parse_rhs_expr(p_.clone()), move |parse_rhs_expr_75744: (crate::syntax::Expr, Ps)| {
                            let (e, p1) = parse_rhs_expr_75744;
                            if at_op(&p1, &Text::lit("<-")) {
                                prism_rtl::Turn::Finished((crate::syntax::StmtKind::SExpr(e.clone()), error_at(&p1, &here(&p1), &Text::lit("the left side of `<-` is not a pattern"))))
                            } else {
                                if at_kw(&p1, &Text::lit("then")) {
                                    prism_rtl::Turn::Finished((crate::syntax::StmtKind::SExpr(e.clone()), error_at(&p1, &here(&p1), &Text::lit("`then` belongs to a hold: `$x <- start then step`"))))
                                } else {
                                    prism_rtl::Turn::Finished((crate::syntax::StmtKind::SExpr(e.clone()), p1.clone()))
                                }
                            }
                        })
                    }
                }
            })
        })
    }
}

/// `Start OtherStmt, x`: what the function value is when passed to `@Run`.
pub fn start_other_stmt(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::StmtKind, Ps)>> {
    Rc::new(OtherStmt { p_ })
}

/// ```prism
/// OptionalRhs: unbounded fn Ps -> ((?Expr, Ps))
/// ```
pub fn optional_rhs(p_: &Ps) -> (Option<crate::syntax::Expr>, Ps) {
    let (e, q) = parse_rhs_expr(p_);
    (Some(e.clone()), q.clone())
}

/// The step machine of `OptionalRhs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptionalRhs: unbounded fn Ps -> ((?Expr, Ps))
/// ```
pub struct OptionalRhs {
    pub p_: Ps,
}

impl prism_rtl::Job<(Option<crate::syntax::Expr>, Ps)> for OptionalRhs {
    fn cycle(&self) -> prism_rtl::Turn<(Option<crate::syntax::Expr>, Ps)> {
        let p_ = &self.p_;
        let p_ = p_.clone();
        call_then(start_parse_rhs_expr(p_.clone()), move |parse_rhs_expr_76102: (crate::syntax::Expr, Ps)| {
            let (e, q) = parse_rhs_expr_76102;
            prism_rtl::Turn::Finished((Some(e.clone()), q.clone()))
        })
    }
}

/// `Start OptionalRhs, x`: what the function value is when passed to `@Run`.
pub fn start_optional_rhs(p_: Ps) -> Rc<dyn prism_rtl::Job<(Option<crate::syntax::Expr>, Ps)>> {
    Rc::new(OptionalRhs { p_ })
}

/// ```prism
/// ParseUpdateStmt: unbounded fn Ps -> ((StmtKind, Ps))
/// ```
pub fn parse_update_stmt(p_: &Ps) -> (crate::syntax::StmtKind, Ps) {
    let (target, p1) = parse_reference(p_);
    let op = match kind(&p1) {
        crate::syntax::lexer::TokKind::KOp(o, _) => o.clone(),
        _ => Text::lit(""),
    };
    if p1.bad || !(((((&op == &Text::lit("<=")) || (&op == &Text::lit("+="))) || (&op == &Text::lit("-="))) || (&op == &Text::lit("*="))) || (&op == &Text::lit("/="))) {
        (crate::syntax::StmtKind::SExpr(no_expr()), fail(&p1))
    } else {
        {
            let (value, q) = parse_rhs_expr(&adv(&p1));
            if &op == &Text::lit("<=") {
                (crate::syntax::StmtKind::SSet(target.clone(), value.clone()), q.clone())
            } else {
                (crate::syntax::StmtKind::SAccum(target.clone(), op.clone(), value.clone()), q.clone())
            }
        }
    }
}

/// The step machine of `ParseUpdateStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseUpdateStmt: unbounded fn Ps -> ((StmtKind, Ps))
/// ```
pub struct ParseUpdateStmt {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::StmtKind, Ps)> for ParseUpdateStmt {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::StmtKind, Ps)> {
        let p_ = &self.p_;
        let p_ = p_.clone();
        call_then(start_parse_reference(p_.clone()), move |parse_reference_76416: (crate::syntax::Expr, Ps)| {
            let (target, p1) = parse_reference_76416;
            let op = match kind(&p1) {
                crate::syntax::lexer::TokKind::KOp(o, _) => o.clone(),
                _ => Text::lit(""),
            };
            if p1.bad || !(((((&op == &Text::lit("<=")) || (&op == &Text::lit("+="))) || (&op == &Text::lit("-="))) || (&op == &Text::lit("*="))) || (&op == &Text::lit("/="))) {
                prism_rtl::Turn::Finished((crate::syntax::StmtKind::SExpr(no_expr()), fail(&p1)))
            } else {
                call_then(start_parse_rhs_expr(adv(&p1)), move |parse_rhs_expr_76664: (crate::syntax::Expr, Ps)| {
                    let (value, q) = parse_rhs_expr_76664;
                    if &op == &Text::lit("<=") {
                        prism_rtl::Turn::Finished((crate::syntax::StmtKind::SSet(target.clone(), value.clone()), q.clone()))
                    } else {
                        prism_rtl::Turn::Finished((crate::syntax::StmtKind::SAccum(target.clone(), op.clone(), value.clone()), q.clone()))
                    }
                })
            }
        })
    }
}

/// `Start ParseUpdateStmt, x`: what the function value is when passed to `@Run`.
pub fn start_parse_update_stmt(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::StmtKind, Ps)>> {
    Rc::new(ParseUpdateStmt { p_ })
}

/// ```prism
/// ParseReference: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_reference(p_: &Ps) -> (crate::syntax::Expr, Ps) {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KName(n) if crate::syntax::lexer::has_prefix(&n.sigils, &Text::lit("&")) => {
            let start = here(p_);
            let (name, p1) = parse_sname(p_);
            if is_upper_name(&name) {
                {
                    let p2 = out_of_scope(&p1, &name.span, &Text::lit("named lenses `&Home` and `Over`"), &Text::from(format!("the named lens `{}` is out of this compiler; write its path, `&_.score.home`", &name_text(&name))));
                    let (inner, q) = parse_reference(&p2);
                    let callee = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(name.clone())), span: start.clone() };
                    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECall(Rc::new(callee.clone()), Array::from(vec![crate::syntax::Arg { name: None, value: inner.clone(), span: inner.span.clone() }]), false, false)), span: to(&start, &inner.span) }, q.clone())
                }
            } else {
                lens_steps(&crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(name.clone())), span: name.span.clone() }, &p1)
            }
        },
        _ => (no_expr(), fail(p_)),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ParseReference`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseReference: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseReference {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, Ps)> for ParseReference {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, Ps)> {
        let p_ = &self.p_;
        match kind(p_) {
            crate::syntax::lexer::TokKind::KName(n) if crate::syntax::lexer::has_prefix(&n.sigils, &Text::lit("&")) => {
                let start = here(p_);
                let (name, p1) = parse_sname(p_);
                if is_upper_name(&name) {
                    {
                        let p2 = out_of_scope(&p1, &name.span, &Text::lit("named lenses `&Home` and `Over`"), &Text::from(format!("the named lens `{}` is out of this compiler; write its path, `&_.score.home`", &name_text(&name))));
                        call_then(start_parse_reference(p2.clone()), move |parse_reference_77348: (crate::syntax::Expr, Ps)| {
                            let (inner, q) = parse_reference_77348;
                            let callee = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(name.clone())), span: start.clone() };
                            prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECall(Rc::new(callee.clone()), Array::from(vec![crate::syntax::Arg { name: None, value: inner.clone(), span: inner.span.clone() }]), false, false)), span: to(&start, &inner.span) }, q.clone()))
                        })
                    }
                } else {
                    prism_rtl::Turn::Finished(lens_steps(&crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(name.clone())), span: name.span.clone() }, &p1))
                }
            },
            _ => prism_rtl::Turn::Finished((no_expr(), fail(p_))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ParseReference, x`: what the function value is when passed to `@Run`.
pub fn start_parse_reference(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, Ps)>> {
    Rc::new(ParseReference { p_ })
}

/// ```prism
/// LensSteps: unbounded fn Expr, Ps -> ((Expr, Ps))
/// ```
pub fn lens_steps(e0: &crate::syntax::Expr, p0: &Ps) -> (crate::syntax::Expr, Ps) {
    let mut this: (crate::syntax::Expr, Ps) = (e0.clone(), p0.clone());
    let mut e: crate::syntax::Expr = e0.clone();
    let mut p_: Ps = p0.clone();
    let mut going: bool = true;
    while going && !p_.bad {
        match &kind(&p_) {
            crate::syntax::lexer::TokKind::KDot(false) => {
                let p1 = adv(&p_);
                let t = here(&p1);
                match &kind(&p1) {
                    crate::syntax::lexer::TokKind::KName(f) if ((&f.sigils == &Text::lit("")) && (&f.case == &crate::syntax::lexer::NameCase::CaseLower)) => {
                        e = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EField(Rc::new(e.clone()), Text::lit(""), crate::syntax::Ident { name: or(&index(&f.path_, &Nat::from(0u32)), &Text::lit("")), span: t.clone() })), span: to(&e.span, &t) };
                        p_ = adv(&p1);
                        ()
                    },
                    crate::syntax::lexer::TokKind::KKw(u77981_1_0, _) if (u77981_1_0 == &Text::lit("key")) => {
                        e = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EField(Rc::new(e.clone()), Text::lit(""), crate::syntax::Ident { name: Text::lit("key"), span: t.clone() })), span: to(&e.span, &t) };
                        p_ = adv(&p1);
                        ()
                    },
                    _ => {
                        p_ = fail(&p1);
                        ()
                    },
                    _ => unreachable!("no arm matched"),
                };
                ()
            },
            crate::syntax::lexer::TokKind::KOpen(u77862_1_0, false) if (u77862_1_0 == &Text::lit("[")) && tk(&p_).touches => {
                let (index, p1) = parse_expr(&adv(&p_));
                let p2 = expect_close(&p1, &Text::lit("["));
                e = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EIndex(Rc::new(e.clone()), Rc::new(index.clone()))), span: to(&e.span, &prev(&p2)) };
                p_ = p2.clone();
                ()
            },
            _ => {
                going = false;
                ()
            },
            _ => unreachable!("no arm matched"),
        };
    }
    this = (e.clone(), p_.clone());
    this
}

/// ```prism
/// ParseType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_type(p_: &Ps) -> (crate::syntax::Type, Ps) {
    let start = here(p_);
    let color_var = is_plain_lower_one(&kind(p_)) && is_fn_kw(&kind_at(p_, &Nat::from(1u32)));
    let (color, p1) = if at_kw(p_, &Text::lit("unbounded")) {
        (crate::syntax::Color::Unbounded, adv(p_))
    } else {
        if color_var { color_var_of(p_) } else { (crate::syntax::Color::Bounded, p_.clone()) }
    };
    if at_kw(&p1, &Text::lit("fn")) {
        {
            let p2 = adv(&p1);
            let (params, p3) = if at_op(&p2, &Text::lit("->")) {
                (Array::new(), p2.clone())
            } else {
                commas(&p2, &(Rc::new(|a0: Ps| entered(start_parse_emit_type(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, Ps)>>>))
            };
            let (result, p4) = parse_type(&expect_op(&p3, &Text::lit("->")));
            (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TFn(color.clone(), params.clone(), Rc::new(result.clone()))), span: to(&start, &result.span) }, p4.clone())
        }
    } else {
        if &color != &crate::syntax::Color::Bounded {
            (no_type(), error_here(&p1, &Text::lit("a color (`unbounded`, or a color variable) is written before a function type's `fn`")))
        } else {
            {
                let (t, q) = parse_emit_type(&p1);
                if at_op(&q, &Text::lit("->")) {
                    (t.clone(), error_at(&q, &here(&q), &Text::lit("a function type begins with `fn`: `fn A -> B`")))
                } else {
                    (t.clone(), q.clone())
                }
            }
        }
    }
}

/// The step machine of `ParseType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseType {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::Type, Ps)> for ParseType {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Type, Ps)> {
        let p_ = &self.p_;
        let start = here(p_);
        let color_var = is_plain_lower_one(&kind(p_)) && is_fn_kw(&kind_at(p_, &Nat::from(1u32)));
        let (color, p1) = if at_kw(p_, &Text::lit("unbounded")) {
            (crate::syntax::Color::Unbounded, adv(p_))
        } else {
            if color_var { color_var_of(p_) } else { (crate::syntax::Color::Bounded, p_.clone()) }
        };
        if at_kw(&p1, &Text::lit("fn")) {
            {
                let p2 = adv(&p1);
                let (params, p3) = if at_op(&p2, &Text::lit("->")) {
                    (Array::new(), p2.clone())
                } else {
                    commas(&p2, &(Rc::new(|a0: Ps| entered(start_parse_emit_type(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, Ps)>>>))
                };
                call_then(start_parse_type(expect_op(&p3, &Text::lit("->"))), move |parse_type_80346: (crate::syntax::Type, Ps)| {
                    let (result, p4) = parse_type_80346;
                    prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TFn(color.clone(), params.clone(), Rc::new(result.clone()))), span: to(&start, &result.span) }, p4.clone()))
                })
            }
        } else {
            if &color != &crate::syntax::Color::Bounded {
                prism_rtl::Turn::Finished((no_type(), error_here(&p1, &Text::lit("a color (`unbounded`, or a color variable) is written before a function type's `fn`"))))
            } else {
                call_then(start_parse_emit_type(p1.clone()), move |parse_emit_type_80639: (crate::syntax::Type, Ps)| {
                    let (t, q) = parse_emit_type_80639;
                    if at_op(&q, &Text::lit("->")) {
                        prism_rtl::Turn::Finished((t.clone(), error_at(&q, &here(&q), &Text::lit("a function type begins with `fn`: `fn A -> B`"))))
                    } else {
                        prism_rtl::Turn::Finished((t.clone(), q.clone()))
                    }
                })
            }
        }
    }
}

/// `Start ParseType, x`: what the function value is when passed to `@Run`.
pub fn start_parse_type(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, Ps)>> {
    Rc::new(ParseType { p_ })
}

/// ```prism
/// IsPlainLowerOne: fn TokKind -> Bool
/// ```
pub fn is_plain_lower_one(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KName(n) => ((&n.sigils == &Text::lit("")) && (&n.case == &crate::syntax::lexer::NameCase::CaseLower)) && (&len(&n.path_) == &Nat::from(1u32)),
        _ => false,
    }
}

/// ```prism
/// IsFnKw: fn TokKind -> Bool
/// ```
pub fn is_fn_kw(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KKw(c0_0_0, _) if (c0_0_0 == &Text::lit("fn")) => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ColorVarOf: fn Ps -> ((Color, Ps))
/// ```
pub fn color_var_of(p_: &Ps) -> (crate::syntax::Color, Ps) {
    let (i, q) = parse_ident(p_);
    (crate::syntax::Color::ColorVar(i.clone()), q.clone())
}

/// ```prism
/// ParseEmitType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_emit_type(p_: &Ps) -> (crate::syntax::Type, Ps) {
    let start = here(p_);
    let (t, p1) = parse_union_type(p_);
    if at_kw(&p1, &Text::lit("emit")) {
        {
            let (r, q) = parse_union_type(&adv(&p1));
            (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TEmit(Rc::new(t.clone()), Rc::new(r.clone()))), span: to(&start, &r.span) }, q.clone())
        }
    } else {
        (t.clone(), p1.clone())
    }
}

/// The step machine of `ParseEmitType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseEmitType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseEmitType {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::Type, Ps)> for ParseEmitType {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Type, Ps)> {
        let p_ = &self.p_;
        let start = here(p_);
        let p_ = p_.clone();
        call_then(start_parse_union_type(p_.clone()), move |parse_union_type_81244: (crate::syntax::Type, Ps)| {
            let (t, p1) = parse_union_type_81244;
            if at_kw(&p1, &Text::lit("emit")) {
                call_then(start_parse_union_type(adv(&p1)), move |parse_union_type_81308: (crate::syntax::Type, Ps)| {
                    let (r, q) = parse_union_type_81308;
                    prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TEmit(Rc::new(t.clone()), Rc::new(r.clone()))), span: to(&start, &r.span) }, q.clone()))
                })
            } else {
                prism_rtl::Turn::Finished((t.clone(), p1.clone()))
            }
        })
    }
}

/// `Start ParseEmitType, x`: what the function value is when passed to `@Run`.
pub fn start_parse_emit_type(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, Ps)>> {
    Rc::new(ParseEmitType { p_ })
}

/// ```prism
/// ParseUnionType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_union_type(p_: &Ps) -> (crate::syntax::Type, Ps) {
    let start = here(p_);
    let (first_, p1) = parse_map_type(p_);
    if &kind(&p1) != &crate::syntax::lexer::TokKind::KBar {
        (first_.clone(), p1.clone())
    } else {
        {
            let r = {
                let mut this: (Array<crate::syntax::Type>, Ps) = (Array::from(vec![first_.clone()]), p1.clone());
                let mut terms: Array<crate::syntax::Type> = Array::from(vec![first_.clone()]);
                let mut q: Ps = p1.clone();
                while (&kind(&q) == &crate::syntax::lexer::TokKind::KBar) && !q.bad {
                    let (t, q2) = parse_map_type(&adv(&q));
                    terms = push(&terms, &t);
                    q = q2.clone();
                }
                this = (terms.clone(), q.clone());
                this
            };
            let (terms, q) = r.clone();
            (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TRowUnion(terms.clone())), span: to(&start, &prev(&q)) }, q.clone())
        }
    }
}

/// The step machine of `ParseUnionType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseUnionType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseUnionType {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::Type, Ps)> for ParseUnionType {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Type, Ps)> {
        let p_ = &self.p_;
        let start = here(p_);
        let p_ = p_.clone();
        call_then(start_parse_map_type(p_.clone()), move |parse_map_type_81533: (crate::syntax::Type, Ps)| {
            let (first_, p1) = parse_map_type_81533;
            if &kind(&p1) != &crate::syntax::lexer::TokKind::KBar {
                prism_rtl::Turn::Finished((first_.clone(), p1.clone()))
            } else {
                {
                    let mut this: (Array<crate::syntax::Type>, Ps) = (Array::from(vec![first_.clone()]), p1.clone());
                    let mut terms: Array<crate::syntax::Type> = Array::from(vec![first_.clone()]);
                    let mut q: Ps = p1.clone();
                    let start = start.clone();
                    call_then(loop_job((this, q, terms), move |(mut this, mut q, mut terms): ((Array<crate::syntax::Type>, Ps), Ps, Array<crate::syntax::Type>)| if (&kind(&q) == &crate::syntax::lexer::TokKind::KBar) && !q.bad {
                        {
                            let (t, q2) = parse_map_type(&adv(&q));
                            terms = push(&terms, &t);
                            q = q2.clone();
                            Ok((this, q, terms))
                        }
                    } else {
                        Err((this, q, terms))
                    }), move |(mut this, mut q, mut terms): ((Array<crate::syntax::Type>, Ps), Ps, Array<crate::syntax::Type>)| {
                        this = (terms.clone(), q.clone());
                        let r = this;
                        let (terms, q) = r.clone();
                        prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TRowUnion(terms.clone())), span: to(&start, &prev(&q)) }, q.clone()))
                    })
                }
            }
        })
    }
}

/// `Start ParseUnionType, x`: what the function value is when passed to `@Run`.
pub fn start_parse_union_type(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, Ps)>> {
    Rc::new(ParseUnionType { p_ })
}

/// ```prism
/// ParseMapType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_map_type(p_: &Ps) -> (crate::syntax::Type, Ps) {
    let start = here(p_);
    let (k, p1) = parse_sigiled_type(p_);
    if at_op(&p1, &Text::lit("==>")) {
        {
            let (value, q) = parse_map_type(&adv(&p1));
            (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TMap(Rc::new(k.clone()), Rc::new(value.clone()))), span: to(&start, &value.span) }, q.clone())
        }
    } else {
        (k.clone(), p1.clone())
    }
}

/// The step machine of `ParseMapType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseMapType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseMapType {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::Type, Ps)> for ParseMapType {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Type, Ps)> {
        let p_ = &self.p_;
        let start = here(p_);
        let p_ = p_.clone();
        call_then(start_parse_sigiled_type(p_.clone()), move |parse_sigiled_type_82113: (crate::syntax::Type, Ps)| {
            let (k, p1) = parse_sigiled_type_82113;
            if at_op(&p1, &Text::lit("==>")) {
                call_then(start_parse_map_type(adv(&p1)), move |parse_map_type_82182: (crate::syntax::Type, Ps)| {
                    let (value, q) = parse_map_type_82182;
                    prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TMap(Rc::new(k.clone()), Rc::new(value.clone()))), span: to(&start, &value.span) }, q.clone()))
                })
            } else {
                prism_rtl::Turn::Finished((k.clone(), p1.clone()))
            }
        })
    }
}

/// `Start ParseMapType, x`: what the function value is when passed to `@Run`.
pub fn start_parse_map_type(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, Ps)>> {
    Rc::new(ParseMapType { p_ })
}

/// ```prism
/// ParseSigiledType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_sigiled_type(p_: &Ps) -> (crate::syntax::Type, Ps) {
    let start = here(p_);
    let (sigils, p1) = free_sigil_run(p_);
    let (inner, q) = parse_app_type(&p1);
    if &sigils == &Text::lit("") {
        (inner.clone(), q.clone())
    } else {
        (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TSigiled(sigils.clone(), Rc::new(inner.clone()))), span: to(&start, &inner.span) }, q.clone())
    }
}

/// The step machine of `ParseSigiledType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseSigiledType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseSigiledType {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::Type, Ps)> for ParseSigiledType {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Type, Ps)> {
        let p_ = &self.p_;
        let start = here(p_);
        let (sigils, p1) = free_sigil_run(p_);
        call_then(start_parse_app_type(p1.clone()), move |parse_app_type_82455: (crate::syntax::Type, Ps)| {
            let (inner, q) = parse_app_type_82455;
            if &sigils == &Text::lit("") {
                prism_rtl::Turn::Finished((inner.clone(), q.clone()))
            } else {
                prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TSigiled(sigils.clone(), Rc::new(inner.clone()))), span: to(&start, &inner.span) }, q.clone()))
            }
        })
    }
}

/// `Start ParseSigiledType, x`: what the function value is when passed to `@Run`.
pub fn start_parse_sigiled_type(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, Ps)>> {
    Rc::new(ParseSigiledType { p_ })
}

/// ```prism
/// FreeSigilRun: fn Ps -> ((Text, Ps))
/// ```
pub fn free_sigil_run(p0: &Ps) -> (Text, Ps) {
    let mut this: (Text, Ps) = (Text::lit(""), p0.clone());
    let mut sigils: Text = Text::lit("");
    let mut p_: Ps = p0.clone();
    let mut fuel: Nat = len(&p0.toks);
    while let Some(left) = (&fuel).checked_sub(&Nat::from(1u32)) {
        fuel = left.clone();
        match &kind(&p_) {
            crate::syntax::lexer::TokKind::KFree(s) => {
                sigils = Text::from(format!("{}{}", &sigils, s));
                p_ = adv(&p_);
            }
            _ => {
                fuel = Nat::from(0u32);
            }
        }
    }
    this = (sigils.clone(), p_.clone());
    this
}

/// ```prism
/// ParseAppType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_app_type(p_: &Ps) -> (crate::syntax::Type, Ps) {
    let start = here(p_);
    let (head, p1) = parse_type_atom(p_);
    match &*head.kind {
        crate::syntax::TypeKind::TName(name, m83086_0_1) if (m83086_0_1.len() == 0) && type_atom_starts_here(&p1) => {
            let r = {
                let mut this: (Array<crate::syntax::Type>, Ps) = (Array::new(), p1.clone());
                let mut args: Array<crate::syntax::Type> = Array::new();
                let mut q: Ps = p1.clone();
                while type_atom_starts_here(&q) && !q.bad {
                    let (a, q2) = parse_type_atom(&q);
                    args = push(&args, &a);
                    q = q2.clone();
                }
                this = (args.clone(), q.clone());
                this
            };
            let (args, q) = r.clone();
            (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TName(name.clone(), args.clone())), span: to(&start, &prev(&q)) }, q.clone())
        },
        _ => (head.clone(), p1.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ParseAppType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseAppType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseAppType {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::Type, Ps)> for ParseAppType {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Type, Ps)> {
        let p_ = &self.p_;
        let start = here(p_);
        let p_ = p_.clone();
        call_then(start_parse_type_atom(p_.clone()), move |parse_type_atom_83066: (crate::syntax::Type, Ps)| {
            let (head, p1) = parse_type_atom_83066;
            match &*head.kind {
                crate::syntax::TypeKind::TName(name, m83086_0_1) if (m83086_0_1.len() == 0) && type_atom_starts_here(&p1) => {
                    let mut this: (Array<crate::syntax::Type>, Ps) = (Array::new(), p1.clone());
                    let mut args: Array<crate::syntax::Type> = Array::new();
                    let mut q: Ps = p1.clone();
                    let name = name.clone();
                    let start = start.clone();
                    call_then(loop_job((this, args, q), move |(mut this, mut args, mut q): ((Array<crate::syntax::Type>, Ps), Array<crate::syntax::Type>, Ps)| if type_atom_starts_here(&q) && !q.bad {
                        {
                            let (a, q2) = parse_type_atom(&q);
                            args = push(&args, &a);
                            q = q2.clone();
                            Ok((this, args, q))
                        }
                    } else {
                        Err((this, args, q))
                    }), move |(mut this, mut args, mut q): ((Array<crate::syntax::Type>, Ps), Array<crate::syntax::Type>, Ps)| {
                        this = (args.clone(), q.clone());
                        let r = this;
                        let (args, q) = r.clone();
                        prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TName(name.clone(), args.clone())), span: to(&start, &prev(&q)) }, q.clone()))
                    })
                },
                _ => prism_rtl::Turn::Finished((head.clone(), p1.clone())),
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start ParseAppType, x`: what the function value is when passed to `@Run`.
pub fn start_parse_app_type(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, Ps)>> {
    Rc::new(ParseAppType { p_ })
}

/// ```prism
/// TypeAtomStartsHere: fn Ps -> Bool
/// ```
pub fn type_atom_starts_here(p_: &Ps) -> bool {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KName(_) => true,
        crate::syntax::lexer::TokKind::KFamily(_) => true,
        crate::syntax::lexer::TokKind::KFree(_) => true,
        crate::syntax::lexer::TokKind::KOpen(_, _) => true,
        crate::syntax::lexer::TokKind::KKw(w, _) => (&w == &Text::lit("unit")) || (&w == &Text::lit("any")),
        _ => false,
    }
}

/// ```prism
/// ParseTypeAtom: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_type_atom(p_: &Ps) -> (crate::syntax::Type, Ps) {
    let start = here(p_);
    match kind(p_) {
        crate::syntax::lexer::TokKind::KFree(_) => parse_sigiled_type(p_),
        _ => {
            let (t, p1) = type_atom_body(p_, &start);
            if &kind(&p1) == &crate::syntax::lexer::TokKind::KNonEmpty {
                {
                    let m = here(&p1);
                    let q = out_of_scope(&adv(&p1), &m, &Text::lit("non-empty arrays"), &Text::lit("the non-empty array type `[a]+` is out of this compiler"));
                    (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TNonEmpty(Rc::new(t.clone()))), span: to(&start, &m) }, q.clone())
                }
            } else {
                (t.clone(), p1.clone())
            }
        },
    }
}

/// The step machine of `ParseTypeAtom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTypeAtom: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseTypeAtom {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::Type, Ps)> for ParseTypeAtom {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Type, Ps)> {
        let p_ = &self.p_;
        let start = here(p_);
        match kind(p_) {
            crate::syntax::lexer::TokKind::KFree(_) => prism_rtl::Turn::More(Rc::new(ParseSigiledType { p_: p_.clone() })),
            _ => {
                let p_ = p_.clone();
                call_then(start_type_atom_body(p_.clone(), start.clone()), move |type_atom_body_84149: (crate::syntax::Type, Ps)| {
                    let (t, p1) = type_atom_body_84149;
                    if &kind(&p1) == &crate::syntax::lexer::TokKind::KNonEmpty {
                        {
                            let m = here(&p1);
                            let q = out_of_scope(&adv(&p1), &m, &Text::lit("non-empty arrays"), &Text::lit("the non-empty array type `[a]+` is out of this compiler"));
                            prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TNonEmpty(Rc::new(t.clone()))), span: to(&start, &m) }, q.clone()))
                        }
                    } else {
                        prism_rtl::Turn::Finished((t.clone(), p1.clone()))
                    }
                })
            },
        }
    }
}

/// `Start ParseTypeAtom, x`: what the function value is when passed to `@Run`.
pub fn start_parse_type_atom(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, Ps)>> {
    Rc::new(ParseTypeAtom { p_ })
}

/// ```prism
/// TypeAtomBody: unbounded fn Ps, Range -> ((Type, Ps))
/// ```
pub fn type_atom_body(p_: &Ps, start: &crate::syntax::Range) -> (crate::syntax::Type, Ps) {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KName(n) => {
            let name = crate::syntax::SName { sigils: n.sigils.clone(), path_: n.path_.clone(), span: start.clone() };
            if (&n.case == &crate::syntax::lexer::NameCase::CaseTopic) || (&n.case == &crate::syntax::lexer::NameCase::CaseHole) {
                (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::THole(name.clone())), span: start.clone() }, adv(p_))
            } else {
                (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TName(name.clone(), Array::new())), span: start.clone() }, check_type_name_scope(&adv(p_), &name))
            }
        },
        crate::syntax::lexer::TokKind::KKw(m84545_1_0, sigils) if (&m84545_1_0 == &Text::lit("unit")) => (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TUnit(sigils.clone())), span: start.clone() }, adv(p_)),
        crate::syntax::lexer::TokKind::KKw(m84545_2_0, _) if (&m84545_2_0 == &Text::lit("any")) => {
            let (tr, q) = parse_trait_ref(&adv(p_));
            (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TAny(tr.clone())), span: to(start, &prev(&q)) }, q.clone())
        },
        crate::syntax::lexer::TokKind::KFamily(path_) => (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TFamily(crate::syntax::QualName { path_: path_.clone(), span: start.clone() })), span: start.clone() }, adv(p_)),
        crate::syntax::lexer::TokKind::KAbsent => (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TAbsent), span: start.clone() }, out_of_scope(&adv(p_), start, &Text::lit("sparse tuples"), &Text::lit("a sparse tuple type is out of this compiler"))),
        crate::syntax::lexer::TokKind::KOpen(m84545_5_0, _) if (&m84545_5_0 == &Text::lit("(")) => if at_double_open(p_, &Text::lit("(")) {
            {
                let (elems, p1) = commas(&open_double(p_), &(Rc::new(|a0: Ps| entered(start_parse_type(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, Ps)>>>));
                let p2 = close_double(&p1, &Text::lit("("));
                (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TTuple(elems.clone())), span: to(start, &prev(&p2)) }, p2.clone())
            }
        } else {
            {
                let (inner, p1) = parse_type(&adv(p_));
                let p2 = expect_close(&p1, &Text::lit("("));
                (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TGroup(Rc::new(inner.clone()))), span: to(start, &prev(&p2)) }, p2.clone())
            }
        },
        crate::syntax::lexer::TokKind::KOpen(m84545_6_0, _) if (&m84545_6_0 == &Text::lit("[")) => {
            let doubled = at_double_open(p_, &Text::lit("["));
            let (elem, p1) = parse_type(&(if doubled { open_double(p_) } else { adv(p_) }));
            let p2 = if doubled {
                close_double(&p1, &Text::lit("["))
            } else {
                expect_close(&p1, &Text::lit("["))
            };
            (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TArray(Rc::new(elem.clone()), doubled)), span: to(start, &prev(&p2)) }, p2.clone())
        },
        _ => (no_type(), error_here(p_, &Text::lit("expected a type"))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `TypeAtomBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeAtomBody: unbounded fn Ps, Range -> ((Type, Ps))
/// ```
pub struct TypeAtomBody {
    pub p_: Ps,
    pub start: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::syntax::Type, Ps)> for TypeAtomBody {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Type, Ps)> {
        let p_ = &self.p_;
        let start = &self.start;
        match kind(p_) {
            crate::syntax::lexer::TokKind::KName(n) => {
                let name = crate::syntax::SName { sigils: n.sigils.clone(), path_: n.path_.clone(), span: start.clone() };
                if (&n.case == &crate::syntax::lexer::NameCase::CaseTopic) || (&n.case == &crate::syntax::lexer::NameCase::CaseHole) {
                    prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::THole(name.clone())), span: start.clone() }, adv(p_)))
                } else {
                    prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TName(name.clone(), Array::new())), span: start.clone() }, check_type_name_scope(&adv(p_), &name)))
                }
            },
            crate::syntax::lexer::TokKind::KKw(m84545_1_0, sigils) if (&m84545_1_0 == &Text::lit("unit")) => prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TUnit(sigils.clone())), span: start.clone() }, adv(p_))),
            crate::syntax::lexer::TokKind::KKw(m84545_2_0, _) if (&m84545_2_0 == &Text::lit("any")) => {
                let (tr, q) = parse_trait_ref(&adv(p_));
                prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TAny(tr.clone())), span: to(start, &prev(&q)) }, q.clone()))
            },
            crate::syntax::lexer::TokKind::KFamily(path_) => prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TFamily(crate::syntax::QualName { path_: path_.clone(), span: start.clone() })), span: start.clone() }, adv(p_))),
            crate::syntax::lexer::TokKind::KAbsent => prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TAbsent), span: start.clone() }, out_of_scope(&adv(p_), start, &Text::lit("sparse tuples"), &Text::lit("a sparse tuple type is out of this compiler")))),
            crate::syntax::lexer::TokKind::KOpen(m84545_5_0, _) if (&m84545_5_0 == &Text::lit("(")) => if at_double_open(p_, &Text::lit("(")) {
                {
                    let p_ = p_.clone();
                    let start = start.clone();
                    call_then(start_commas(open_double(&p_), Rc::new(|a0: Ps| entered(start_parse_type(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, Ps)>>>), move |commas_85506: (Array<crate::syntax::Type>, Ps)| {
                        let (elems, p1) = commas_85506;
                        let p2 = close_double(&p1, &Text::lit("("));
                        prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TTuple(elems.clone())), span: to(&start, &prev(&p2)) }, p2.clone()))
                    })
                }
            } else {
                {
                    let p_ = p_.clone();
                    let start = start.clone();
                    call_then(start_parse_type(adv(&p_)), move |parse_type_85700: (crate::syntax::Type, Ps)| {
                        let (inner, p1) = parse_type_85700;
                        let p2 = expect_close(&p1, &Text::lit("("));
                        prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TGroup(Rc::new(inner.clone()))), span: to(&start, &prev(&p2)) }, p2.clone()))
                    })
                }
            },
            crate::syntax::lexer::TokKind::KOpen(m84545_6_0, _) if (&m84545_6_0 == &Text::lit("[")) => {
                let doubled = at_double_open(p_, &Text::lit("["));
                let p_ = p_.clone();
                let start = start.clone();
                call_then(start_parse_type(if doubled { open_double(&p_) } else { adv(&p_) }), move |parse_type_85925: (crate::syntax::Type, Ps)| {
                    let (elem, p1) = parse_type_85925;
                    let p2 = if doubled {
                        close_double(&p1, &Text::lit("["))
                    } else {
                        expect_close(&p1, &Text::lit("["))
                    };
                    prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TArray(Rc::new(elem.clone()), doubled)), span: to(&start, &prev(&p2)) }, p2.clone()))
                })
            },
            _ => prism_rtl::Turn::Finished((no_type(), error_here(p_, &Text::lit("expected a type")))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start TypeAtomBody, x`: what the function value is when passed to `@Run`.
pub fn start_type_atom_body(p_: Ps, start: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, Ps)>> {
    Rc::new(TypeAtomBody { p_, start })
}

/// ```prism
/// ParseBounds: unbounded fn Ps -> (([Bound], Ps))
/// ```
pub fn parse_bounds(p0: &Ps) -> (Array<crate::syntax::Bound>, Ps) {
    let mut this: (Array<crate::syntax::Bound>, Ps) = (Array::new(), p0.clone());
    let mut bounds: Array<crate::syntax::Bound> = Array::new();
    let mut p_: Ps = p0.clone();
    let mut going: bool = true;
    while going && !p_.bad {
        let (b, q) = parse_bound(&p_);
        bounds = push(&bounds, &b);
        p_ = q.clone();
        if (at_comma(&p_) && is_name_kind(&kind_at(&p_, &Nat::from(1u32)))) && (&kind_at(&p_, &Nat::from(2u32)) == &crate::syntax::lexer::TokKind::KColon) {
            p_ = adv(&p_);
        } else {
            going = false;
        }
    }
    this = (bounds.clone(), p_.clone());
    this
}

/// The step machine of `ParseBounds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseBounds: unbounded fn Ps -> (([Bound], Ps))
/// ```
pub struct ParseBounds {
    pub p0: Ps,
}

impl prism_rtl::Job<(Array<crate::syntax::Bound>, Ps)> for ParseBounds {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::Bound>, Ps)> {
        let p0 = &self.p0;
        let mut this: (Array<crate::syntax::Bound>, Ps) = (Array::new(), p0.clone());
        let mut bounds: Array<crate::syntax::Bound> = Array::new();
        let mut p_: Ps = p0.clone();
        let mut going: bool = true;
        call_then(loop_job((this, bounds, going, p_), move |(mut this, mut bounds, mut going, mut p_): ((Array<crate::syntax::Bound>, Ps), Array<crate::syntax::Bound>, bool, Ps)| if going && !p_.bad {
            {
                let (b, q) = parse_bound(&p_);
                bounds = push(&bounds, &b);
                p_ = q.clone();
                if (at_comma(&p_) && is_name_kind(&kind_at(&p_, &Nat::from(1u32)))) && (&kind_at(&p_, &Nat::from(2u32)) == &crate::syntax::lexer::TokKind::KColon) {
                    p_ = adv(&p_);
                } else {
                    going = false;
                }
                Ok((this, bounds, going, p_))
            }
        } else {
            Err((this, bounds, going, p_))
        }), move |(mut this, mut bounds, mut going, mut p_): ((Array<crate::syntax::Bound>, Ps), Array<crate::syntax::Bound>, bool, Ps)| {
            this = (bounds.clone(), p_.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start ParseBounds, x`: what the function value is when passed to `@Run`.
pub fn start_parse_bounds(p0: Ps) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Bound>, Ps)>> {
    Rc::new(ParseBounds { p0 })
}

/// ```prism
/// IsNameKind: fn TokKind -> Bool
/// ```
pub fn is_name_kind(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KName(_) => true,
        _ => false,
    }
}

/// ```prism
/// IsTraitKind: fn TokKind -> Bool
/// ```
pub fn is_trait_kind(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KTrait(_) => true,
        _ => false,
    }
}

/// ```prism
/// ParseBound: unbounded fn Ps -> ((Bound, Ps))
/// ```
pub fn parse_bound(p_: &Ps) -> (crate::syntax::Bound, Ps) {
    let start = here(p_);
    let (var, p1) = parse_ident(p_);
    let (first_, p2) = parse_trait_ref(&expect_colon(&p1));
    let r = {
        let mut this: (Array<crate::syntax::TraitRef>, Ps) = (Array::from(vec![first_.clone()]), p2.clone());
        let mut traits: Array<crate::syntax::TraitRef> = Array::from(vec![first_.clone()]);
        let mut q: Ps = p2.clone();
        while (at_comma(&q) && is_trait_kind(&kind_at(&q, &Nat::from(1u32)))) && !q.bad {
            let (t, q2) = parse_trait_ref(&adv(&q));
            traits = push(&traits, &t);
            q = q2.clone();
        }
        this = (traits.clone(), q.clone());
        this
    };
    let (traits, q) = r.clone();
    (crate::syntax::Bound { var: var.clone(), traits: traits.clone(), span: to(&start, &prev(&q)) }, q.clone())
}

/// The step machine of `ParseBound`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseBound: unbounded fn Ps -> ((Bound, Ps))
/// ```
pub struct ParseBound {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::Bound, Ps)> for ParseBound {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Bound, Ps)> {
        let p_ = &self.p_;
        let start = here(p_);
        let (var, p1) = parse_ident(p_);
        let (first_, p2) = parse_trait_ref(&expect_colon(&p1));
        let mut this: (Array<crate::syntax::TraitRef>, Ps) = (Array::from(vec![first_.clone()]), p2.clone());
        let mut traits: Array<crate::syntax::TraitRef> = Array::from(vec![first_.clone()]);
        let mut q: Ps = p2.clone();
        let start = start.clone();
        let var = var.clone();
        call_then(loop_job((this, q, traits), move |(mut this, mut q, mut traits): ((Array<crate::syntax::TraitRef>, Ps), Ps, Array<crate::syntax::TraitRef>)| if (at_comma(&q) && is_trait_kind(&kind_at(&q, &Nat::from(1u32)))) && !q.bad {
            {
                let (t, q2) = parse_trait_ref(&adv(&q));
                traits = push(&traits, &t);
                q = q2.clone();
                Ok((this, q, traits))
            }
        } else {
            Err((this, q, traits))
        }), move |(mut this, mut q, mut traits): ((Array<crate::syntax::TraitRef>, Ps), Ps, Array<crate::syntax::TraitRef>)| {
            this = (traits.clone(), q.clone());
            let r = this;
            let (traits, q) = r.clone();
            prism_rtl::Turn::Finished((crate::syntax::Bound { var: var.clone(), traits: traits.clone(), span: to(&start, &prev(&q)) }, q.clone()))
        })
    }
}

/// `Start ParseBound, x`: what the function value is when passed to `@Run`.
pub fn start_parse_bound(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Bound, Ps)>> {
    Rc::new(ParseBound { p_ })
}

/// ```prism
/// ParseRow: unbounded fn Ps -> ((Row, Ps))
/// ```
pub fn parse_row(p_: &Ps) -> (crate::syntax::Row_, Ps) {
    let start = here(p_);
    let (first_, p1) = parse_row_term(p_);
    let r = {
        let mut this: (Array<crate::syntax::RowTerm>, Ps) = (Array::from(vec![first_.clone()]), p1.clone());
        let mut terms: Array<crate::syntax::RowTerm> = Array::from(vec![first_.clone()]);
        let mut q: Ps = p1.clone();
        while (&kind(&q) == &crate::syntax::lexer::TokKind::KBar) && !q.bad {
            let (t, q2) = parse_row_term(&adv(&q));
            terms = push(&terms, &t);
            q = q2.clone();
        }
        this = (terms.clone(), q.clone());
        this
    };
    let (terms, q) = r.clone();
    (crate::syntax::Row_ { terms: terms.clone(), span: to(&start, &prev(&q)) }, q.clone())
}

/// The step machine of `ParseRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseRow: unbounded fn Ps -> ((Row, Ps))
/// ```
pub struct ParseRow {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::Row_, Ps)> for ParseRow {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Row_, Ps)> {
        let p_ = &self.p_;
        let start = here(p_);
        let p_ = p_.clone();
        call_then(start_parse_row_term(p_.clone()), move |parse_row_term_87724: (crate::syntax::RowTerm, Ps)| {
            let (first_, p1) = parse_row_term_87724;
            let mut this: (Array<crate::syntax::RowTerm>, Ps) = (Array::from(vec![first_.clone()]), p1.clone());
            let mut terms: Array<crate::syntax::RowTerm> = Array::from(vec![first_.clone()]);
            let mut q: Ps = p1.clone();
            let start = start.clone();
            call_then(loop_job((this, q, terms), move |(mut this, mut q, mut terms): ((Array<crate::syntax::RowTerm>, Ps), Ps, Array<crate::syntax::RowTerm>)| if (&kind(&q) == &crate::syntax::lexer::TokKind::KBar) && !q.bad {
                {
                    let (t, q2) = parse_row_term(&adv(&q));
                    terms = push(&terms, &t);
                    q = q2.clone();
                    Ok((this, q, terms))
                }
            } else {
                Err((this, q, terms))
            }), move |(mut this, mut q, mut terms): ((Array<crate::syntax::RowTerm>, Ps), Ps, Array<crate::syntax::RowTerm>)| {
                this = (terms.clone(), q.clone());
                let r = this;
                let (terms, q) = r.clone();
                prism_rtl::Turn::Finished((crate::syntax::Row_ { terms: terms.clone(), span: to(&start, &prev(&q)) }, q.clone()))
            })
        })
    }
}

/// `Start ParseRow, x`: what the function value is when passed to `@Run`.
pub fn start_parse_row(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Row_, Ps)>> {
    Rc::new(ParseRow { p_ })
}

/// ```prism
/// ParseRowTerm: unbounded fn Ps -> ((RowTerm, Ps))
/// ```
pub fn parse_row_term(p_: &Ps) -> (crate::syntax::RowTerm, Ps) {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KFamily(path_) => (crate::syntax::RowTerm::RFamily(crate::syntax::QualName { path_: path_.clone(), span: here(p_) }), adv(p_)),
        crate::syntax::lexer::TokKind::KName(n) if (is_plain_lower_one(&crate::syntax::lexer::TokKind::KName(n.clone())) && !type_atom_after_name(p_)) => (crate::syntax::RowTerm::RVar(crate::syntax::Ident { name: or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")), span: here(p_) }), adv(p_)),
        _ => {
            let (t, q) = parse_map_type(p_);
            (crate::syntax::RowTerm::RType(t.clone()), q.clone())
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ParseRowTerm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseRowTerm: unbounded fn Ps -> ((RowTerm, Ps))
/// ```
pub struct ParseRowTerm {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::RowTerm, Ps)> for ParseRowTerm {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::RowTerm, Ps)> {
        let p_ = &self.p_;
        match kind(p_) {
            crate::syntax::lexer::TokKind::KFamily(path_) => prism_rtl::Turn::Finished((crate::syntax::RowTerm::RFamily(crate::syntax::QualName { path_: path_.clone(), span: here(p_) }), adv(p_))),
            crate::syntax::lexer::TokKind::KName(n) if (is_plain_lower_one(&crate::syntax::lexer::TokKind::KName(n.clone())) && !type_atom_after_name(p_)) => prism_rtl::Turn::Finished((crate::syntax::RowTerm::RVar(crate::syntax::Ident { name: or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")), span: here(p_) }), adv(p_))),
            _ => {
                let p_ = p_.clone();
                call_then(start_parse_map_type(p_.clone()), move |parse_map_type_88435: (crate::syntax::Type, Ps)| {
                    let (t, q) = parse_map_type_88435;
                    prism_rtl::Turn::Finished((crate::syntax::RowTerm::RType(t.clone()), q.clone()))
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ParseRowTerm, x`: what the function value is when passed to `@Run`.
pub fn start_parse_row_term(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::RowTerm, Ps)>> {
    Rc::new(ParseRowTerm { p_ })
}

/// ```prism
/// TypeAtomAfterName: fn Ps -> Bool
/// ```
pub fn type_atom_after_name(p_: &Ps) -> bool {
    match kind_at(p_, &Nat::from(1u32)) {
        crate::syntax::lexer::TokKind::KName(_) => true,
        crate::syntax::lexer::TokKind::KOpen(_, _) => true,
        crate::syntax::lexer::TokKind::KFamily(_) => true,
        _ => false,
    }
}

/// ```prism
/// ParsePattern: unbounded fn Ps, Bool -> ((Pattern, Ps))
/// ```
pub fn parse_pattern(p_: &Ps, commas0: &bool) -> (crate::syntax::Pattern_, Ps) {
    let commas_ = *commas0 && !p_.step_mode;
    let start = here(p_);
    match kind(p_) {
        crate::syntax::lexer::TokKind::KFree(s) if ((&s == &Text::lit("?")) || (&s == &Text::lit("~"))) => {
            let (inner, q) = parse_pattern(&adv(p_), &commas_);
            (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PSigil(s.clone(), Rc::new(inner.clone()))), span: to(&start, &inner.span) }, q.clone())
        },
        crate::syntax::lexer::TokKind::KFree(s) => (no_pattern(), error_at(p_, &start, &Text::from(format!("a free `{}` is not a pattern: only `? p` and `~ p` take a value apart", &s)))),
        crate::syntax::lexer::TokKind::KName(n) => name_pattern(p_, &n, &commas_),
        crate::syntax::lexer::TokKind::KKw(m89219_3_0, _) if (&m89219_3_0 == &Text::lit("ignore")) => (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: start.clone() }, adv(p_)),
        crate::syntax::lexer::TokKind::KKw(m89219_4_0, _) if (&m89219_4_0 == &Text::lit("unit")) => (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PUnit), span: start.clone() }, adv(p_)),
        crate::syntax::lexer::TokKind::KKw(m89219_5_0, _) if (&m89219_5_0 == &Text::lit("nil")) => (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PNil), span: start.clone() }, adv(p_)),
        crate::syntax::lexer::TokKind::KInt(_, _) => literal_pattern(p_),
        crate::syntax::lexer::TokKind::KFloat(_, _) => literal_pattern(p_),
        crate::syntax::lexer::TokKind::KDuration(_, _, _) => literal_pattern(p_),
        crate::syntax::lexer::TokKind::KChar(_, _) => literal_pattern(p_),
        crate::syntax::lexer::TokKind::KText(_, _) => literal_pattern(p_),
        crate::syntax::lexer::TokKind::KOp(m89219_11_0, true) if (&m89219_11_0 == &Text::lit("-")) => {
            let p1 = adv(p_);
            if is_number_kind(&kind(&p1)) {
                {
                    let (lit, q) = parse_literal(&p1);
                    (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PNeg(lit.clone())), span: to(&start, &lit.span) }, q.clone())
                }
            } else {
                (no_pattern(), error_here(&p1, &Text::lit("a `-` in a pattern is the sign of a number literal")))
            }
        },
        crate::syntax::lexer::TokKind::KOpen(m89219_12_0, _) if (&m89219_12_0 == &Text::lit("(")) => if at_double_open(p_, &Text::lit("(")) {
            {
                let (elems, p1) = commas(&open_double(p_), &(Rc::new(move |p0: Ps| entered(once_job(move || {
                    let q = p0;
                    prism_rtl::Turn::More(Rc::new(ParsePattern { p_: q.clone(), commas0: false }))
                }))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, Ps)>>>));
                let p2 = close_double(&p1, &Text::lit("("));
                (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PTuple(elems.clone())), span: to(&start, &prev(&p2)) }, p2.clone())
            }
        } else {
            {
                let (inner, p1) = bracketed(&adv(p_), &(Rc::new(move |p0: Ps| entered(once_job(move || {
                    let q = p0;
                    prism_rtl::Turn::More(Rc::new(ParsePattern { p_: q.clone(), commas0: true }))
                }))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, Ps)>>>));
                let p2 = expect_close(&p1, &Text::lit("("));
                (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PGroup(Rc::new(inner.clone()))), span: to(&start, &prev(&p2)) }, p2.clone())
            }
        },
        crate::syntax::lexer::TokKind::KOpen(m89219_13_0, _) if (&m89219_13_0 == &Text::lit("[")) && at_double_open(p_, &Text::lit("[")) => {
            let p1 = open_double(p_);
            let (elems, p2) = if at_close(&p1, &Text::lit("[")) {
                (Array::new(), p1.clone())
            } else {
                commas(&p1, &(Rc::new(move |p0: Ps| entered(once_job(move || {
                    let q = p0;
                    prism_rtl::Turn::More(Rc::new(ParsePattern { p_: q.clone(), commas0: false }))
                }))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, Ps)>>>))
            };
            let p3 = close_double(&p2, &Text::lit("["));
            (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PArray(elems.clone())), span: to(&start, &prev(&p3)) }, p3.clone())
        },
        crate::syntax::lexer::TokKind::KFamily(path_) => (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PFamily(crate::syntax::QualName { path_: path_.clone(), span: start.clone() })), span: start.clone() }, adv(p_)),
        crate::syntax::lexer::TokKind::KAbsent => (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: start.clone() }, out_of_scope(&adv(p_), &start, &Text::lit("sparse tuples"), &Text::lit("an absent component `-` is a sparse tuple's, out of this compiler"))),
        _ => (no_pattern(), error_here(p_, &Text::lit("expected a pattern"))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ParsePattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParsePattern: unbounded fn Ps, Bool -> ((Pattern, Ps))
/// ```
pub struct ParsePattern {
    pub p_: Ps,
    pub commas0: bool,
}

impl prism_rtl::Job<(crate::syntax::Pattern_, Ps)> for ParsePattern {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Pattern_, Ps)> {
        let p_ = &self.p_;
        let commas0 = &self.commas0;
        let commas_ = *commas0 && !p_.step_mode;
        let start = here(p_);
        match kind(p_) {
            crate::syntax::lexer::TokKind::KFree(s) if ((&s == &Text::lit("?")) || (&s == &Text::lit("~"))) => {
                let p_ = p_.clone();
                call_then(start_parse_pattern(adv(&p_), commas_), move |parse_pattern_89305: (crate::syntax::Pattern_, Ps)| {
                    let (inner, q) = parse_pattern_89305;
                    prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PSigil(s.clone(), Rc::new(inner.clone()))), span: to(&start, &inner.span) }, q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KFree(s) => prism_rtl::Turn::Finished((no_pattern(), error_at(p_, &start, &Text::from(format!("a free `{}` is not a pattern: only `? p` and `~ p` take a value apart", &s))))),
            crate::syntax::lexer::TokKind::KName(n) => prism_rtl::Turn::More(Rc::new(NamePattern { p0: p_.clone(), n: n.clone(), commas_ })),
            crate::syntax::lexer::TokKind::KKw(m89219_3_0, _) if (&m89219_3_0 == &Text::lit("ignore")) => prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: start.clone() }, adv(p_))),
            crate::syntax::lexer::TokKind::KKw(m89219_4_0, _) if (&m89219_4_0 == &Text::lit("unit")) => prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PUnit), span: start.clone() }, adv(p_))),
            crate::syntax::lexer::TokKind::KKw(m89219_5_0, _) if (&m89219_5_0 == &Text::lit("nil")) => prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PNil), span: start.clone() }, adv(p_))),
            crate::syntax::lexer::TokKind::KInt(_, _) => prism_rtl::Turn::More(Rc::new(LiteralPattern { p_: p_.clone() })),
            crate::syntax::lexer::TokKind::KFloat(_, _) => prism_rtl::Turn::More(Rc::new(LiteralPattern { p_: p_.clone() })),
            crate::syntax::lexer::TokKind::KDuration(_, _, _) => prism_rtl::Turn::More(Rc::new(LiteralPattern { p_: p_.clone() })),
            crate::syntax::lexer::TokKind::KChar(_, _) => prism_rtl::Turn::More(Rc::new(LiteralPattern { p_: p_.clone() })),
            crate::syntax::lexer::TokKind::KText(_, _) => prism_rtl::Turn::More(Rc::new(LiteralPattern { p_: p_.clone() })),
            crate::syntax::lexer::TokKind::KOp(m89219_11_0, true) if (&m89219_11_0 == &Text::lit("-")) => {
                let p1 = adv(p_);
                if is_number_kind(&kind(&p1)) {
                    call_then(start_parse_literal(p1.clone()), move |parse_literal_90216: (crate::syntax::Literal, Ps)| {
                        let (lit, q) = parse_literal_90216;
                        prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PNeg(lit.clone())), span: to(&start, &lit.span) }, q.clone()))
                    })
                } else {
                    prism_rtl::Turn::Finished((no_pattern(), error_here(&p1, &Text::lit("a `-` in a pattern is the sign of a number literal"))))
                }
            },
            crate::syntax::lexer::TokKind::KOpen(m89219_12_0, _) if (&m89219_12_0 == &Text::lit("(")) => if at_double_open(p_, &Text::lit("(")) {
                {
                    let p_ = p_.clone();
                    call_then(start_commas(open_double(&p_), Rc::new(move |p0: Ps| entered(once_job(move || {
                        let q = p0;
                        prism_rtl::Turn::More(Rc::new(ParsePattern { p_: q.clone(), commas0: false }))
                    }))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, Ps)>>>), move |commas_90508: (Array<crate::syntax::Pattern_>, Ps)| {
                        let (elems, p1) = commas_90508;
                        let p2 = close_double(&p1, &Text::lit("("));
                        prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PTuple(elems.clone())), span: to(&start, &prev(&p2)) }, p2.clone()))
                    })
                }
            } else {
                {
                    let p_ = p_.clone();
                    call_then(start_bracketed(adv(&p_), Rc::new(move |p0: Ps| entered(once_job(move || {
                        let q = p0;
                        prism_rtl::Turn::More(Rc::new(ParsePattern { p_: q.clone(), commas0: true }))
                    }))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, Ps)>>>), move |bracketed_90895: (crate::syntax::Pattern_, Ps)| {
                        let (inner, p1) = bracketed_90895;
                        let p2 = expect_close(&p1, &Text::lit("("));
                        prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PGroup(Rc::new(inner.clone()))), span: to(&start, &prev(&p2)) }, p2.clone()))
                    })
                }
            },
            crate::syntax::lexer::TokKind::KOpen(m89219_13_0, _) if (&m89219_13_0 == &Text::lit("[")) && at_double_open(p_, &Text::lit("[")) => {
                let p1 = open_double(p_);
                let (elems, p2) = if at_close(&p1, &Text::lit("[")) {
                    (Array::new(), p1.clone())
                } else {
                    commas(&p1, &(Rc::new(move |p0: Ps| entered(once_job(move || {
                        let q = p0;
                        prism_rtl::Turn::More(Rc::new(ParsePattern { p_: q.clone(), commas0: false }))
                    }))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, Ps)>>>))
                };
                let p3 = close_double(&p2, &Text::lit("["));
                prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PArray(elems.clone())), span: to(&start, &prev(&p3)) }, p3.clone()))
            },
            crate::syntax::lexer::TokKind::KFamily(path_) => prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PFamily(crate::syntax::QualName { path_: path_.clone(), span: start.clone() })), span: start.clone() }, adv(p_))),
            crate::syntax::lexer::TokKind::KAbsent => prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: start.clone() }, out_of_scope(&adv(p_), &start, &Text::lit("sparse tuples"), &Text::lit("an absent component `-` is a sparse tuple's, out of this compiler")))),
            _ => prism_rtl::Turn::Finished((no_pattern(), error_here(p_, &Text::lit("expected a pattern")))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ParsePattern, x`: what the function value is when passed to `@Run`.
pub fn start_parse_pattern(p_: Ps, commas0: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, Ps)>> {
    Rc::new(ParsePattern { p_, commas0 })
}

/// ```prism
/// IsNumberKind: fn TokKind -> Bool
/// ```
pub fn is_number_kind(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KInt(_, _) => true,
        crate::syntax::lexer::TokKind::KFloat(_, _) => true,
        crate::syntax::lexer::TokKind::KDuration(_, _, _) => true,
        _ => false,
    }
}

/// ```prism
/// LiteralPattern: unbounded fn Ps -> ((Pattern, Ps))
/// ```
pub fn literal_pattern(p_: &Ps) -> (crate::syntax::Pattern_, Ps) {
    let (lit, q) = parse_literal(p_);
    (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PLit(lit.clone())), span: lit.span.clone() }, q.clone())
}

/// The step machine of `LiteralPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LiteralPattern: unbounded fn Ps -> ((Pattern, Ps))
/// ```
pub struct LiteralPattern {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::Pattern_, Ps)> for LiteralPattern {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Pattern_, Ps)> {
        let p_ = &self.p_;
        let p_ = p_.clone();
        call_then(start_parse_literal(p_.clone()), move |parse_literal_92029: (crate::syntax::Literal, Ps)| {
            let (lit, q) = parse_literal_92029;
            prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PLit(lit.clone())), span: lit.span.clone() }, q.clone()))
        })
    }
}

/// `Start LiteralPattern, x`: what the function value is when passed to `@Run`.
pub fn start_literal_pattern(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, Ps)>> {
    Rc::new(LiteralPattern { p_ })
}

/// ```prism
/// NamePattern: unbounded fn Ps, NameTok, Bool -> ((Pattern, Ps))
/// ```
pub fn name_pattern(p0: &Ps, n: &crate::syntax::lexer::NameTok, commas_: &bool) -> (crate::syntax::Pattern_, Ps) {
    let start = here(p0);
    let name = crate::syntax::SName { sigils: n.sigils.clone(), path_: n.path_.clone(), span: start.clone() };
    let p_ = adv(p0);
    if (is_callee(&name) && at_single_open(&p_, &Text::lit("("))) && tk(&p_).touches {
        parse_record_pattern(&p_, &name)
    } else {
        if is_callee(&name) && pat_arg_starts_here(&p_) {
            {
                let (first_, p1) = parse_pattern(&p_, &false);
                let r = {
                    let mut this: (Array<crate::syntax::Pattern_>, Ps) = (Array::from(vec![first_.clone()]), p1.clone());
                    let mut args: Array<crate::syntax::Pattern_> = Array::from(vec![first_.clone()]);
                    let mut q: Ps = p1.clone();
                    while (*commas_ && at_comma(&q)) && !q.bad {
                        let (a, q2) = parse_pattern(&adv(&q), &false);
                        args = push(&args, &a);
                        q = q2.clone();
                    }
                    this = (args.clone(), q.clone());
                    this
                };
                let (args, q) = r.clone();
                (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PCtor(name.clone(), args.clone())), span: to(&start, &prev(&q)) }, q.clone())
            }
        } else {
            (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PName(name.clone())), span: start.clone() }, p_.clone())
        }
    }
}

/// The step machine of `NamePattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamePattern: unbounded fn Ps, NameTok, Bool -> ((Pattern, Ps))
/// ```
pub struct NamePattern {
    pub p0: Ps,
    pub n: crate::syntax::lexer::NameTok,
    pub commas_: bool,
}

impl prism_rtl::Job<(crate::syntax::Pattern_, Ps)> for NamePattern {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Pattern_, Ps)> {
        let p0 = &self.p0;
        let n = &self.n;
        let commas_ = &self.commas_;
        let start = here(p0);
        let name = crate::syntax::SName { sigils: n.sigils.clone(), path_: n.path_.clone(), span: start.clone() };
        let p_ = adv(p0);
        if (is_callee(&name) && at_single_open(&p_, &Text::lit("("))) && tk(&p_).touches {
            prism_rtl::Turn::More(Rc::new(ParseRecordPattern { p0: p_.clone(), name: name.clone() }))
        } else {
            if is_callee(&name) && pat_arg_starts_here(&p_) {
                {
                    let commas_ = *commas_;
                    call_then(start_parse_pattern(p_.clone(), false), move |parse_pattern_92474: (crate::syntax::Pattern_, Ps)| {
                        let (first_, p1) = parse_pattern_92474;
                        let mut this: (Array<crate::syntax::Pattern_>, Ps) = (Array::from(vec![first_.clone()]), p1.clone());
                        let mut args: Array<crate::syntax::Pattern_> = Array::from(vec![first_.clone()]);
                        let mut q: Ps = p1.clone();
                        let name = name.clone();
                        let start = start.clone();
                        call_then(loop_job((this, args, q), {
                            let commas_ = commas_;
                            move |(mut this, mut args, mut q): ((Array<crate::syntax::Pattern_>, Ps), Array<crate::syntax::Pattern_>, Ps)| if (commas_ && at_comma(&q)) && !q.bad {
                                {
                                    let (a, q2) = parse_pattern(&adv(&q), &false);
                                    args = push(&args, &a);
                                    q = q2.clone();
                                    Ok((this, args, q))
                                }
                            } else {
                                Err((this, args, q))
                            }
                        }), move |(mut this, mut args, mut q): ((Array<crate::syntax::Pattern_>, Ps), Array<crate::syntax::Pattern_>, Ps)| {
                            this = (args.clone(), q.clone());
                            let r = this;
                            let (args, q) = r.clone();
                            prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PCtor(name.clone(), args.clone())), span: to(&start, &prev(&q)) }, q.clone()))
                        })
                    })
                }
            } else {
                prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PName(name.clone())), span: start.clone() }, p_.clone()))
            }
        }
    }
}

/// `Start NamePattern, x`: what the function value is when passed to `@Run`.
pub fn start_name_pattern(p0: Ps, n: crate::syntax::lexer::NameTok, commas_: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, Ps)>> {
    Rc::new(NamePattern { p0, n, commas_ })
}

/// ```prism
/// PatArgStartsHere: fn Ps -> Bool
/// ```
pub fn pat_arg_starts_here(p_: &Ps) -> bool {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KName(_) => true,
        crate::syntax::lexer::TokKind::KInt(_, _) => true,
        crate::syntax::lexer::TokKind::KFloat(_, _) => true,
        crate::syntax::lexer::TokKind::KDuration(_, _, _) => true,
        crate::syntax::lexer::TokKind::KChar(_, _) => true,
        crate::syntax::lexer::TokKind::KText(_, _) => true,
        crate::syntax::lexer::TokKind::KFamily(_) => true,
        crate::syntax::lexer::TokKind::KFree(s) => (&s == &Text::lit("?")) || (&s == &Text::lit("~")),
        crate::syntax::lexer::TokKind::KOpen(m93092_8_0, _) if (&m93092_8_0 == &Text::lit("(")) => !tk(p_).touches || at_double_open(p_, &Text::lit("(")),
        crate::syntax::lexer::TokKind::KOpen(m93092_9_0, _) if (&m93092_9_0 == &Text::lit("[")) => at_double_open(p_, &Text::lit("[")),
        crate::syntax::lexer::TokKind::KOp(m93092_10_0, true) if (&m93092_10_0 == &Text::lit("-")) => true,
        crate::syntax::lexer::TokKind::KKw(w, _) => ((&w == &Text::lit("ignore")) || (&w == &Text::lit("unit"))) || (&w == &Text::lit("nil")),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParseRecordPattern: unbounded fn Ps, SName -> ((Pattern, Ps))
/// ```
pub fn parse_record_pattern(p0: &Ps, name: &crate::syntax::SName) -> (crate::syntax::Pattern_, Ps) {
    let p_ = adv(p0);
    let r = {
        let mut this: FieldsRead = FieldsRead { fields: Array::new(), rest: false, p_: p_.clone(), going: !at_close(&p_, &Text::lit("(")) };
        while this.going && !this.p_.bad {
            if &kind(&this.p_) == &crate::syntax::lexer::TokKind::KDotDot {
                this.p_ = adv(&this.p_);
                this.rest = true;
            } else {
                let fstart = here(&this.p_);
                let (fname_opt, p1) = parse_arg_name(&this.p_);
                let (pattern, p2) = parse_pattern(&p1, &false);
                this.fields = push(&this.fields, &crate::syntax::FieldPat { name: fname_opt.clone(), pattern: pattern.clone(), span: to(&fstart, &pattern.span) });
                this.p_ = p2.clone();
            }
            if at_comma(&this.p_) {
                this.p_ = adv(&this.p_);
            } else {
                this.going = false;
            }
        }
        this
    };
    let q = expect_close(&r.p_, &Text::lit("("));
    (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PRecord(name.clone(), r.fields.clone(), r.rest)), span: to(&name.span, &prev(&q)) }, q.clone())
}

/// The step machine of `ParseRecordPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseRecordPattern: unbounded fn Ps, SName -> ((Pattern, Ps))
/// ```
pub struct ParseRecordPattern {
    pub p0: Ps,
    pub name: crate::syntax::SName,
}

impl prism_rtl::Job<(crate::syntax::Pattern_, Ps)> for ParseRecordPattern {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Pattern_, Ps)> {
        let p0 = &self.p0;
        let name = &self.name;
        let p_ = adv(p0);
        let mut this: FieldsRead = FieldsRead { fields: Array::new(), rest: false, p_: p_.clone(), going: !at_close(&p_, &Text::lit("(")) };
        let name = name.clone();
        let p_ = p_.clone();
        call_then(loop_job((this,), {
            let name = name.clone();
            let p_ = p_.clone();
            move |(mut this,): (FieldsRead,)| if this.going && !this.p_.bad {
                {
                    if &kind(&this.p_) == &crate::syntax::lexer::TokKind::KDotDot {
                        this.p_ = adv(&this.p_);
                        this.rest = true;
                    } else {
                        let fstart = here(&this.p_);
                        let (fname_opt, p1) = parse_arg_name(&this.p_);
                        let (pattern, p2) = parse_pattern(&p1, &false);
                        this.fields = push(&this.fields, &crate::syntax::FieldPat { name: fname_opt.clone(), pattern: pattern.clone(), span: to(&fstart, &pattern.span) });
                        this.p_ = p2.clone();
                    }
                    if at_comma(&this.p_) {
                        this.p_ = adv(&this.p_);
                    } else {
                        this.going = false;
                    }
                    Ok((this,))
                }
            } else {
                Err((this,))
            }
        }), move |(mut this,): (FieldsRead,)| {
            let r = this;
            let q = expect_close(&r.p_, &Text::lit("("));
            prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PRecord(name.clone(), r.fields.clone(), r.rest)), span: to(&name.span, &prev(&q)) }, q.clone()))
        })
    }
}

/// `Start ParseRecordPattern, x`: what the function value is when passed to `@Run`.
pub fn start_parse_record_pattern(p0: Ps, name: crate::syntax::SName) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, Ps)>> {
    Rc::new(ParseRecordPattern { p0, name })
}

/// ```prism
/// let deliveryWords
/// ```
pub fn delivery_words() -> Array<Text> {
    Array::from(vec![Text::lit("send"), Text::lit("click"), Text::lit("answer")])
}

/// ```prism
/// IsDeliveryWord: fn Text -> Bool
/// ```
pub fn is_delivery_word(w: &Text) -> bool {
    fold(&delivery_words(), &false, &(|seen: &bool, d: &Text| *seen || (d == w)))
}

/// ```prism
/// StepWord: fn Ps -> Text
/// ```
pub fn step_word(p_: &Ps) -> Text {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KName(n) if (((&n.sigils == &Text::lit("")) && (&len(&n.path_) == &Nat::from(1u32))) && (&n.case == &crate::syntax::lexer::NameCase::CaseLower)) => or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")),
        _ => Text::lit(""),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// AtWord: fn Ps, Text -> Bool
/// ```
pub fn at_word(p_: &Ps, w: &Text) -> bool {
    &step_word(p_) == w
}

/// ```prism
/// ParseCheckDecl: unbounded fn Ps -> ((CheckDecl, Ps))
/// ```
pub fn parse_check_decl(p0: &Ps) -> (crate::syntax::CheckDecl, Ps) {
    let start = here(p0);
    let (name, p1) = parse_ident(&adv(p0));
    let p2 = expect_colon(&p1);
    if at_open_l(&p2) {
        {
            let (lines, q) = layout_items(&adv(&p2), &(Rc::new(|a0: Ps| entered(start_parse_check_line(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::CheckLine, Ps)>>>));
            (crate::syntax::CheckDecl { name: name.clone(), lines: lines.clone(), span: to(&start, &prev(&q)) }, q.clone())
        }
    } else {
        (crate::syntax::CheckDecl { name: name.clone(), lines: Array::new(), span: start.clone() }, error_here(&p2, &Text::lit("a `check` block's lines stand in an indented block")))
    }
}

/// The step machine of `ParseCheckDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseCheckDecl: unbounded fn Ps -> ((CheckDecl, Ps))
/// ```
pub struct ParseCheckDecl {
    pub p0: Ps,
}

impl prism_rtl::Job<(crate::syntax::CheckDecl, Ps)> for ParseCheckDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::CheckDecl, Ps)> {
        let p0 = &self.p0;
        let start = here(p0);
        let (name, p1) = parse_ident(&adv(p0));
        let p2 = expect_colon(&p1);
        if at_open_l(&p2) {
            call_then(start_layout_items(adv(&p2), Rc::new(|a0: Ps| entered(start_parse_check_line(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::CheckLine, Ps)>>>), move |layout_items_95906: (Array<crate::syntax::CheckLine>, Ps)| {
                let (lines, q) = layout_items_95906;
                prism_rtl::Turn::Finished((crate::syntax::CheckDecl { name: name.clone(), lines: lines.clone(), span: to(&start, &prev(&q)) }, q.clone()))
            })
        } else {
            prism_rtl::Turn::Finished((crate::syntax::CheckDecl { name: name.clone(), lines: Array::new(), span: start.clone() }, error_here(&p2, &Text::lit("a `check` block's lines stand in an indented block"))))
        }
    }
}

/// `Start ParseCheckDecl, x`: what the function value is when passed to `@Run`.
pub fn start_parse_check_decl(p0: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::CheckDecl, Ps)>> {
    Rc::new(ParseCheckDecl { p0 })
}

/// ```prism
/// ParseCheckLine: unbounded fn Ps -> ((CheckLine, Ps))
/// ```
pub fn parse_check_line(p_: &Ps) -> (crate::syntax::CheckLine, Ps) {
    let start = here(p_);
    let (expr, p1) = parse_rhs_expr(p_);
    let (pattern_opt, q) = if at_op(&p1, &Text::lit("=>")) {
        optional_pattern_top(&adv(&p1))
    } else {
        (None, p1.clone())
    };
    (crate::syntax::CheckLine { expr: expr.clone(), pattern: pattern_opt.clone(), span: to(&start, &prev(&q)) }, q.clone())
}

/// The step machine of `ParseCheckLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseCheckLine: unbounded fn Ps -> ((CheckLine, Ps))
/// ```
pub struct ParseCheckLine {
    pub p_: Ps,
}

impl prism_rtl::Job<(crate::syntax::CheckLine, Ps)> for ParseCheckLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::CheckLine, Ps)> {
        let p_ = &self.p_;
        let start = here(p_);
        let p_ = p_.clone();
        call_then(start_parse_rhs_expr(p_.clone()), move |parse_rhs_expr_96269: (crate::syntax::Expr, Ps)| {
            let (expr, p1) = parse_rhs_expr_96269;
            let (pattern_opt, q) = if at_op(&p1, &Text::lit("=>")) {
                optional_pattern_top(&adv(&p1))
            } else {
                (None, p1.clone())
            };
            prism_rtl::Turn::Finished((crate::syntax::CheckLine { expr: expr.clone(), pattern: pattern_opt.clone(), span: to(&start, &prev(&q)) }, q.clone()))
        })
    }
}

/// `Start ParseCheckLine, x`: what the function value is when passed to `@Run`.
pub fn start_parse_check_line(p_: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::CheckLine, Ps)>> {
    Rc::new(ParseCheckLine { p_ })
}

/// ```prism
/// OptionalPatternTop: unbounded fn Ps -> ((?Pattern, Ps))
/// ```
pub fn optional_pattern_top(p_: &Ps) -> (Option<crate::syntax::Pattern_>, Ps) {
    let (pat, q) = parse_pattern(p_, &true);
    (Some(pat.clone()), q.clone())
}

/// The step machine of `OptionalPatternTop`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptionalPatternTop: unbounded fn Ps -> ((?Pattern, Ps))
/// ```
pub struct OptionalPatternTop {
    pub p_: Ps,
}

impl prism_rtl::Job<(Option<crate::syntax::Pattern_>, Ps)> for OptionalPatternTop {
    fn cycle(&self) -> prism_rtl::Turn<(Option<crate::syntax::Pattern_>, Ps)> {
        let p_ = &self.p_;
        let p_ = p_.clone();
        call_then(start_parse_pattern(p_.clone(), true), move |parse_pattern_96554: (crate::syntax::Pattern_, Ps)| {
            let (pat, q) = parse_pattern_96554;
            prism_rtl::Turn::Finished((Some(pat.clone()), q.clone()))
        })
    }
}

/// `Start OptionalPatternTop, x`: what the function value is when passed to `@Run`.
pub fn start_optional_pattern_top(p_: Ps) -> Rc<dyn prism_rtl::Job<(Option<crate::syntax::Pattern_>, Ps)>> {
    Rc::new(OptionalPatternTop { p_ })
}

/// ```prism
/// ParseTestDecl: unbounded fn Ps -> ((TestDecl, Ps))
/// ```
pub fn parse_test_decl(p0: &Ps) -> (crate::syntax::TestDecl, Ps) {
    let start = here(p0);
    let (name, p1) = parse_ident(&adv(p0));
    let fallback = crate::syntax::TestDecl { name: name.clone(), blueprint: no_expr(), seed: None, steps: Array::new(), span: start.clone() };
    if !at_comma(&p1) {
        (fallback.clone(), error_here(&p1, &Text::lit("a test names its blueprint: `test name, @blueprint:`")))
    } else {
        {
            let (blueprint, p2) = parse_arg_expr(&adv(&p1));
            let (seed_opt, p3) = if at_comma(&p2) { parse_seed(&adv(&p2)) } else { (None, p2.clone()) };
            let p4 = expect_colon(&p3);
            if at_open_l(&p4) {
                {
                    let saved = p4.step_mode;
                    let (steps, p5) = layout_items(&adv(&p4), &{
                        let saved = saved;
                        Rc::new(move |p0: Ps| {
                            let saved = saved;
                            entered(once_job(move || {
                                let s = p0;
                                prism_rtl::Turn::More(Rc::new(StepIn { p_: s.clone(), saved }))
                            }))
                        }) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::TestStep, Ps)>>>
                    });
                    let q = with_step_mode(&p5, &saved);
                    (crate::syntax::TestDecl { name: name.clone(), blueprint: blueprint.clone(), seed: seed_opt.clone(), steps: steps.clone(), span: to(&start, &prev(&q)) }, q.clone())
                }
            } else {
                (fallback.clone(), error_here(&p4, &Text::lit("a test's steps stand in an indented block")))
            }
        }
    }
}

/// The step machine of `ParseTestDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTestDecl: unbounded fn Ps -> ((TestDecl, Ps))
/// ```
pub struct ParseTestDecl {
    pub p0: Ps,
}

impl prism_rtl::Job<(crate::syntax::TestDecl, Ps)> for ParseTestDecl {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::TestDecl, Ps)> {
        let p0 = &self.p0;
        let start = here(p0);
        let (name, p1) = parse_ident(&adv(p0));
        let fallback = crate::syntax::TestDecl { name: name.clone(), blueprint: no_expr(), seed: None, steps: Array::new(), span: start.clone() };
        if !at_comma(&p1) {
            prism_rtl::Turn::Finished((fallback.clone(), error_here(&p1, &Text::lit("a test names its blueprint: `test name, @blueprint:`"))))
        } else {
            call_then(start_parse_arg_expr(adv(&p1)), move |parse_arg_expr_97047: (crate::syntax::Expr, Ps)| {
                let (blueprint, p2) = parse_arg_expr_97047;
                let (seed_opt, p3) = if at_comma(&p2) { parse_seed(&adv(&p2)) } else { (None, p2.clone()) };
                let p4 = expect_colon(&p3);
                if at_open_l(&p4) {
                    {
                        let saved = p4.step_mode;
                        call_then(start_layout_items(adv(&p4), {
                            let saved = saved;
                            Rc::new(move |p0: Ps| {
                                let saved = saved;
                                entered(once_job(move || {
                                    let s = p0;
                                    prism_rtl::Turn::More(Rc::new(StepIn { p_: s.clone(), saved }))
                                }))
                            }) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::TestStep, Ps)>>>
                        }), move |layout_items_97272: (Array<crate::syntax::TestStep>, Ps)| {
                            let (steps, p5) = layout_items_97272;
                            let q = with_step_mode(&p5, &saved);
                            prism_rtl::Turn::Finished((crate::syntax::TestDecl { name: name.clone(), blueprint: blueprint.clone(), seed: seed_opt.clone(), steps: steps.clone(), span: to(&start, &prev(&q)) }, q.clone()))
                        })
                    }
                } else {
                    prism_rtl::Turn::Finished((fallback.clone(), error_here(&p4, &Text::lit("a test's steps stand in an indented block"))))
                }
            })
        }
    }
}

/// `Start ParseTestDecl, x`: what the function value is when passed to `@Run`.
pub fn start_parse_test_decl(p0: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::TestDecl, Ps)>> {
    Rc::new(ParseTestDecl { p0 })
}

/// ```prism
/// ParseSeed: fn Ps -> ((?Nat, Ps))
/// ```
pub fn parse_seed(p_: &Ps) -> (Option<Nat>, Ps) {
    if !at_word(p_, &Text::lit("seed")) {
        (None, error_here(p_, &Text::lit("after the blueprint, a test takes only `seed n`")))
    } else {
        {
            let p1 = adv(p_);
            match kind(&p1) {
                crate::syntax::lexer::TokKind::KInt(m97754_0_0, text) if (&m97754_0_0 == &Text::lit("")) => (Some(parse_nat_text(&text)), adv(&p1)),
                _ => (None, error_here(&p1, &Text::lit("`seed` takes a number"))),
                _ => unreachable!("no arm matched"),
            }
        }
    }
}

/// ```prism
/// StepIn: unbounded fn Ps, Bool -> ((TestStep, Ps))
/// ```
pub fn step_in(p_: &Ps, saved: &bool) -> (crate::syntax::TestStep, Ps) {
    let (s, q) = parse_step(&with_step_mode(p_, &true));
    (s.clone(), with_step_mode(&q, saved))
}

/// The step machine of `StepIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StepIn: unbounded fn Ps, Bool -> ((TestStep, Ps))
/// ```
pub struct StepIn {
    pub p_: Ps,
    pub saved: bool,
}

impl prism_rtl::Job<(crate::syntax::TestStep, Ps)> for StepIn {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::TestStep, Ps)> {
        let p_ = &self.p_;
        let saved = &self.saved;
        let (s, q) = parse_step(&with_step_mode(p_, &true));
        prism_rtl::Turn::Finished((s.clone(), with_step_mode(&q, saved)))
    }
}

/// `Start StepIn, x`: what the function value is when passed to `@Run`.
pub fn start_step_in(p_: Ps, saved: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::TestStep, Ps)>> {
    Rc::new(StepIn { p_, saved })
}

/// ```prism
/// ParseStep: unbounded fn Ps -> ((TestStep, Ps))
/// ```
pub fn parse_step(p0: &Ps) -> (crate::syntax::TestStep, Ps) {
    let start = here(p0);
    let (withs, p1) = with_entries(p0);
    let (action, p2) = step_action_of(&p1, &withs);
    if p2.bad {
        (crate::syntax::TestStep { withs: withs.clone(), action: action.clone(), checks: Array::new(), span: start.clone() }, p2.clone())
    } else {
        if at_open_l(&p2) {
            {
                let (checks, q) = layout_items(&adv(&p2), &(Rc::new(|a0: Ps| entered(start_parse_test_check(a0))) as Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::TestCheck, Ps)>>>));
                (crate::syntax::TestStep { withs: withs.clone(), action: action.clone(), checks: checks.clone(), span: to(&start, &prev(&q)) }, q.clone())
            }
        } else {
            if at_comma(&p2) {
                (crate::syntax::TestStep { withs: withs.clone(), action: action.clone(), checks: Array::new(), span: start.clone() }, error_at(&p2, &here(&p2), &Text::lit("a comma in a step begins a delivery; a value with commas in it is written in parentheses")))
            } else {
                (crate::syntax::TestStep { withs: withs.clone(), action: action.clone(), checks: Array::new(), span: to(&start, &prev(&p2)) }, p2.clone())
            }
        }
    }
}

/// ```prism
/// WithEntries: unbounded fn Ps -> (([Entry], Ps))
/// ```
pub fn with_entries(p0: &Ps) -> (Array<crate::syntax::Entry>, Ps) {
    let mut this: (Array<crate::syntax::Entry>, Ps) = (Array::new(), p0.clone());
    let mut withs: Array<crate::syntax::Entry> = Array::new();
    let mut p_: Ps = p0.clone();
    let mut going: bool = at_word(p0, &Text::lit("with"));
    while going && !p_.bad {
        let (e, q) = parse_entry(&adv(&p_));
        withs = push(&withs, &e);
        if at_comma(&q) {
            p_ = adv(&q);
            going = at_word(&p_, &Text::lit("with"));
        } else {
            p_ = q.clone();
            going = false;
        }
    }
    this = (withs.clone(), p_.clone());
    this
}

/// ```prism
/// StepActionOf: unbounded fn Ps, [Entry] -> ((StepAction, Ps))
/// ```
pub fn step_action_of(p_: &Ps, withs: &Array<crate::syntax::Entry>) -> (crate::syntax::StepAction, Ps) {
    let w = step_word(p_);
    match &w {
        m99573_0 if (m99573_0 == &Text::lit("build")) => (crate::syntax::StepAction::SaBuild, adv(p_)),
        m99573_1 if (m99573_1 == &Text::lit("tick")) => (crate::syntax::StepAction::SaTick, adv(p_)),
        m99573_2 if (m99573_2 == &Text::lit("compute")) => {
            let p1 = adv(p_);
            if at_word(&p1, &Text::lit("until")) {
                {
                    let p2 = adv(&p1);
                    if at_word(&p2, &Text::lit("idle")) {
                        (crate::syntax::StepAction::SaCompute(true), adv(&p2))
                    } else {
                        (crate::syntax::StepAction::SaCompute(true), error_here(&p2, &Text::lit("`compute until` is followed by `idle`")))
                    }
                }
            } else {
                (crate::syntax::StepAction::SaCompute(false), p1.clone())
            }
        },
        m99573_3 if (m99573_3 == &Text::lit("push")) => {
            let (e, q) = parse_entry(&adv(p_));
            (crate::syntax::StepAction::SaPush(e.clone()), q.clone())
        },
        _ if is_delivery_word(&w) => deliveries(p_),
        _ if ((&len(withs) > &Nat::from(0u32)) && (at_open_l(p_) || at_stmt_boundary(p_))) => (crate::syntax::StepAction::SaWithOnly, p_.clone()),
        _ => (crate::syntax::StepAction::SaBuild, error_here(p_, &Text::lit("expected a step: `build`, `tick`, `compute`, `send`, `click`, `answer`, `with` or `push`"))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Deliveries: unbounded fn Ps -> ((StepAction, Ps))
/// ```
pub fn deliveries(p0: &Ps) -> (crate::syntax::StepAction, Ps) {
    let mut this: (crate::syntax::StepAction, Ps) = (crate::syntax::StepAction::SaBuild, p0.clone());
    let (first_, p1) = parse_delivery(p0);
    let mut ds: Array<crate::syntax::Delivery> = Array::from(vec![first_.clone()]);
    let mut p_: Ps = p1.clone();
    while at_comma(&p_) && !p_.bad {
        if is_delivery_name(&kind_at(&p_, &Nat::from(1u32))) {
            let (d, q) = parse_delivery(&adv(&p_));
            ds = push(&ds, &d);
            p_ = q.clone();
        } else {
            p_ = error_at(&p_, &here(&p_), &Text::lit("a comma in a step begins a delivery (`click p, click q`); a value with commas in it is written in parentheses: `send p, (Min a, b)`"));
        }
    }
    this = (crate::syntax::StepAction::SaDeliver(ds.clone()), p_.clone());
    this
}

/// ```prism
/// IsDeliveryName: fn TokKind -> Bool
/// ```
pub fn is_delivery_name(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KName(n) => (&len(&n.path_) == &Nat::from(1u32)) && is_delivery_word(&or(&index(&n.path_, &Nat::from(0u32)), &Text::lit(""))),
        _ => false,
    }
}

/// ```prism
/// ParseEntry: unbounded fn Ps -> ((Entry, Ps))
/// ```
pub fn parse_entry(p_: &Ps) -> (crate::syntax::Entry, Ps) {
    let start = here(p_);
    let (element_, p1) = parse_arg_expr(p_);
    let (value, q) = parse_arg_expr(&expect_op(&p1, &Text::lit("=")));
    (crate::syntax::Entry { element: element_.clone(), value: value.clone(), span: to(&start, &prev(&q)) }, q.clone())
}

/// ```prism
/// ParseDelivery: unbounded fn Ps -> ((Delivery, Ps))
/// ```
pub fn parse_delivery(p_: &Ps) -> (crate::syntax::Delivery, Ps) {
    let start = here(p_);
    let word = step_word(p_);
    let (target, p1) = parse_target(&adv(p_));
    let (kind_, q) = if &word == &Text::lit("send") {
        send_value(&p1)
    } else {
        if &word == &Text::lit("click") {
            (crate::syntax::DeliveryKind::DkClick, p1.clone())
        } else {
            (crate::syntax::DeliveryKind::DkAnswer, p1.clone())
        }
    };
    (crate::syntax::Delivery { kind: kind_.clone(), target: target.clone(), span: to(&start, &prev(&q)) }, q.clone())
}

/// ```prism
/// SendValue: unbounded fn Ps -> ((DeliveryKind, Ps))
/// ```
pub fn send_value(p_: &Ps) -> (crate::syntax::DeliveryKind, Ps) {
    if at_comma(p_) {
        {
            let (v_, q) = parse_arg_expr(&adv(p_));
            (crate::syntax::DeliveryKind::DkSend(v_.clone()), q.clone())
        }
    } else {
        (crate::syntax::DeliveryKind::DkClick, error_here(p_, &Text::lit("`send` takes a target and a value: `send p, v`")))
    }
}

/// ```prism
/// ParseTarget: unbounded fn Ps -> ((Target, Ps))
/// ```
pub fn parse_target(p_: &Ps) -> (crate::syntax::Target, Ps) {
    let element_ = at_word(p_, &Text::lit("element")) && is_path_kind(&kind_at(p_, &Nat::from(1u32)));
    if at_word(p_, &Text::lit("at")) || element_ {
        {
            let p1 = adv(p_);
            match kind(&p1) {
                crate::syntax::lexer::TokKind::KPath(segs) => {
                    let span = here(&p1);
                    let (segments, q) = run_to_end(fold_job(segs.clone(), (Array::new(), adv(&p1)), {
                        let span = span.clone();
                        Rc::new(move |(p0, p1): ((Array<crate::syntax::PathSeg>, Ps), crate::syntax::lexer::PathSegTok)| {
                            let span = span.clone();
                            entered(once_job(move || {
                                let (acc, pp) = p0;
                                let seg = p1;
                                prism_rtl::Turn::Finished(path_seg_of(&acc, &pp, &seg, &span))
                            }))
                        }) as Rc<dyn Fn(((Array<crate::syntax::PathSeg>, Ps), crate::syntax::lexer::PathSegTok)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::PathSeg>, Ps)>>>
                    }));
                    let path_ = crate::syntax::TestPath { segments: segments.clone(), span: span.clone() };
                    if element_ {
                        (crate::syntax::Target::TgElement(path_.clone()), q.clone())
                    } else {
                        (crate::syntax::Target::TgPath(path_.clone()), q.clone())
                    }
                },
                _ => (crate::syntax::Target::TgPattern(no_pattern()), error_here(&p1, &Text::lit("`at` takes a path, `1/#0/0`"))),
            }
        }
    } else {
        {
            let (pat, q) = parse_pattern(p_, &false);
            (crate::syntax::Target::TgPattern(pat.clone()), q.clone())
        }
    }
}

/// ```prism
/// IsPathKind: fn TokKind -> Bool
/// ```
pub fn is_path_kind(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KPath(_) => true,
        _ => false,
    }
}

/// ```prism
/// PathSegOf: unbounded fn [PathSeg], Ps, PathSegTok, Range -> (([PathSeg], Ps))
/// ```
pub fn path_seg_of(acc: &Array<crate::syntax::PathSeg>, p_: &Ps, path_seg_tok2: &crate::syntax::lexer::PathSegTok, range3: &crate::syntax::Range) -> (Array<crate::syntax::PathSeg>, Ps) {
    match (path_seg_tok2, range3) {
        (crate::syntax::lexer::PathSegTok::PstNum(n), _) => (push(acc, &crate::syntax::PathSeg::PsNum(n.clone())), p_.clone()),
        (crate::syntax::lexer::PathSegTok::PstGen(n), _) => (push(acc, &crate::syntax::PathSeg::PsGen(n.clone())), p_.clone()),
        (crate::syntax::lexer::PathSegTok::PstKey(toks), span) => {
            let (e, q) = parse_nested(p_, toks, span);
            (push(acc, &crate::syntax::PathSeg::PsKey(e.clone())), q.clone())
        },
    }
}

/// ```prism
/// ParseTestCheck: unbounded fn Ps -> ((TestCheck, Ps))
/// ```
pub fn parse_test_check(p0: &Ps) -> (crate::syntax::TestCheck, Ps) {
    let start = here(p0);
    let p_ = expect_op(p0, &Text::lit("=>"));
    let word = step_word(&p_);
    if p_.bad {
        (crate::syntax::TestCheck { kind: crate::syntax::TestCheckKind::CkQuiet, span: start.clone() }, p_.clone())
    } else {
        if &word == &Text::lit("") {
            (crate::syntax::TestCheck { kind: crate::syntax::TestCheckKind::CkQuiet, span: start.clone() }, error_here(&p_, &Text::lit("expected a check after `=>`: `expect`, `returns`, `fired`, `quiet`, ...")))
        } else {
            {
                let (kind_, q) = check_kind_of(&adv(&p_), &word);
                (crate::syntax::TestCheck { kind: kind_.clone(), span: to(&start, &prev(&q)) }, q.clone())
            }
        }
    }
}

/// The step machine of `ParseTestCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTestCheck: unbounded fn Ps -> ((TestCheck, Ps))
/// ```
pub struct ParseTestCheck {
    pub p0: Ps,
}

impl prism_rtl::Job<(crate::syntax::TestCheck, Ps)> for ParseTestCheck {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::TestCheck, Ps)> {
        let p0 = &self.p0;
        let start = here(p0);
        let p_ = expect_op(p0, &Text::lit("=>"));
        let word = step_word(&p_);
        if p_.bad {
            prism_rtl::Turn::Finished((crate::syntax::TestCheck { kind: crate::syntax::TestCheckKind::CkQuiet, span: start.clone() }, p_.clone()))
        } else {
            if &word == &Text::lit("") {
                prism_rtl::Turn::Finished((crate::syntax::TestCheck { kind: crate::syntax::TestCheckKind::CkQuiet, span: start.clone() }, error_here(&p_, &Text::lit("expected a check after `=>`: `expect`, `returns`, `fired`, `quiet`, ..."))))
            } else {
                call_then(start_check_kind_of(adv(&p_), word.clone()), move |check_kind_of_103753: (crate::syntax::TestCheckKind, Ps)| {
                    let (kind_, q) = check_kind_of_103753;
                    prism_rtl::Turn::Finished((crate::syntax::TestCheck { kind: kind_.clone(), span: to(&start, &prev(&q)) }, q.clone()))
                })
            }
        }
    }
}

/// `Start ParseTestCheck, x`: what the function value is when passed to `@Run`.
pub fn start_parse_test_check(p0: Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::TestCheck, Ps)>> {
    Rc::new(ParseTestCheck { p0 })
}

/// ```prism
/// CheckKindOf: unbounded fn Ps, Text -> ((TestCheckKind, Ps))
/// ```
pub fn check_kind_of(p_: &Ps, word: &Text) -> (crate::syntax::TestCheckKind, Ps) {
    match word {
        m103928_0 if (m103928_0 == &Text::lit("expect")) => one_pattern(p_, &{
            let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::TestCheckKind::CkExpect(a0.clone()));
            Rc::new(move |a0: crate::syntax::Pattern_| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::TestCheckKind>>>
        }),
        m103928_1 if (m103928_1 == &Text::lit("expect_none")) => one_pattern(p_, &{
            let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::TestCheckKind::CkExpectNone(a0.clone()));
            Rc::new(move |a0: crate::syntax::Pattern_| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::TestCheckKind>>>
        }),
        m103928_2 if (m103928_2 == &Text::lit("expect_top")) => one_pattern(p_, &{
            let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::TestCheckKind::CkExpectTop(a0.clone()));
            Rc::new(move |a0: crate::syntax::Pattern_| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::TestCheckKind>>>
        }),
        m103928_3 if (m103928_3 == &Text::lit("expect_top_none")) => one_pattern(p_, &{
            let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::TestCheckKind::CkExpectTopNone(a0.clone()));
            Rc::new(move |a0: crate::syntax::Pattern_| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::TestCheckKind>>>
        }),
        m103928_4 if (m103928_4 == &Text::lit("unrequested")) => one_pattern(p_, &{
            let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::TestCheckKind::CkUnrequested(a0.clone()));
            Rc::new(move |a0: crate::syntax::Pattern_| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::TestCheckKind>>>
        }),
        m103928_5 if (m103928_5 == &Text::lit("returns")) => one_pattern(p_, &{
            let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::TestCheckKind::CkReturns(a0.clone()));
            Rc::new(move |a0: crate::syntax::Pattern_| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::TestCheckKind>>>
        }),
        m103928_6 if (m103928_6 == &Text::lit("fired")) => one_pattern(p_, &{
            let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::TestCheckKind::CkFired(a0.clone()));
            Rc::new(move |a0: crate::syntax::Pattern_| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::TestCheckKind>>>
        }),
        m103928_7 if (m103928_7 == &Text::lit("expect_count")) => {
            let (pat, p1) = parse_pattern(p_, &false);
            if !at_comma(&p1) {
                (crate::syntax::TestCheckKind::CkQuiet, error_here(&p1, &Text::lit("`expect_count` takes a pattern and a count: `expect_count p, n`")))
            } else {
                {
                    let p2 = adv(&p1);
                    match kind(&p2) {
                        crate::syntax::lexer::TokKind::KInt(m104487_0_0, text) if (&m104487_0_0 == &Text::lit("")) => (crate::syntax::TestCheckKind::CkExpectCount(pat.clone(), parse_nat_text(&text)), adv(&p2)),
                        _ => (crate::syntax::TestCheckKind::CkQuiet, error_here(&p2, &Text::lit("`expect_count` takes a number"))),
                        _ => unreachable!("no arm matched"),
                    }
                }
            }
        },
        m103928_8 if (m103928_8 == &Text::lit("requested")) => {
            let (place, p1) = parse_pattern(p_, &false);
            if !at_comma(&p1) {
                (crate::syntax::TestCheckKind::CkQuiet, error_here(&p1, &Text::lit("`requested` takes a place and a value: `requested p, v`")))
            } else {
                {
                    let (value, q) = parse_pattern(&adv(&p1), &false);
                    (crate::syntax::TestCheckKind::CkRequested(place.clone(), value.clone()), q.clone())
                }
            }
        },
        m103928_9 if (m103928_9 == &Text::lit("quiet")) => (crate::syntax::TestCheckKind::CkQuiet, p_.clone()),
        m103928_10 if (m103928_10 == &Text::lit("settles")) => (crate::syntax::TestCheckKind::CkSettles, p_.clone()),
        m103928_11 if (m103928_11 == &Text::lit("aborted")) => (crate::syntax::TestCheckKind::CkAborted, p_.clone()),
        m103928_12 if (m103928_12 == &Text::lit("snapshot")) => match kind(p_) {
            crate::syntax::lexer::TokKind::KText(m105087_0_0, segs) if (&m105087_0_0 == &Text::lit("")) && all_plain(&segs) => (crate::syntax::TestCheckKind::CkSnapshot(concat(&each(&segs, &plain_of))), adv(p_)),
            _ => (crate::syntax::TestCheckKind::CkQuiet, error_here(p_, &Text::lit("`snapshot` takes a file name, a text literal"))),
            _ => unreachable!("no arm matched"),
        },
        _ => (crate::syntax::TestCheckKind::CkQuiet, error_at(p_, &prev(p_), &Text::from(format!("`{}` is not a check: the checks are expect, expect_none, expect_count, expect_top, expect_top_none, requested, unrequested, returns, fired, quiet, settles, aborted, snapshot", word)))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CheckKindOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckKindOf: unbounded fn Ps, Text -> ((TestCheckKind, Ps))
/// ```
pub struct CheckKindOf {
    pub p_: Ps,
    pub word: Text,
}

impl prism_rtl::Job<(crate::syntax::TestCheckKind, Ps)> for CheckKindOf {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::TestCheckKind, Ps)> {
        let p_ = &self.p_;
        let word = &self.word;
        match word {
            m103928_0 if (m103928_0 == &Text::lit("expect")) => prism_rtl::Turn::More(Rc::new(OnePattern { p_: p_.clone(), make_fn: {
                let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::TestCheckKind::CkExpect(a0.clone()));
                Rc::new(move |a0: crate::syntax::Pattern_| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::TestCheckKind>>>
            } })),
            m103928_1 if (m103928_1 == &Text::lit("expect_none")) => prism_rtl::Turn::More(Rc::new(OnePattern { p_: p_.clone(), make_fn: {
                let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::TestCheckKind::CkExpectNone(a0.clone()));
                Rc::new(move |a0: crate::syntax::Pattern_| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::TestCheckKind>>>
            } })),
            m103928_2 if (m103928_2 == &Text::lit("expect_top")) => prism_rtl::Turn::More(Rc::new(OnePattern { p_: p_.clone(), make_fn: {
                let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::TestCheckKind::CkExpectTop(a0.clone()));
                Rc::new(move |a0: crate::syntax::Pattern_| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::TestCheckKind>>>
            } })),
            m103928_3 if (m103928_3 == &Text::lit("expect_top_none")) => prism_rtl::Turn::More(Rc::new(OnePattern { p_: p_.clone(), make_fn: {
                let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::TestCheckKind::CkExpectTopNone(a0.clone()));
                Rc::new(move |a0: crate::syntax::Pattern_| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::TestCheckKind>>>
            } })),
            m103928_4 if (m103928_4 == &Text::lit("unrequested")) => prism_rtl::Turn::More(Rc::new(OnePattern { p_: p_.clone(), make_fn: {
                let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::TestCheckKind::CkUnrequested(a0.clone()));
                Rc::new(move |a0: crate::syntax::Pattern_| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::TestCheckKind>>>
            } })),
            m103928_5 if (m103928_5 == &Text::lit("returns")) => prism_rtl::Turn::More(Rc::new(OnePattern { p_: p_.clone(), make_fn: {
                let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::TestCheckKind::CkReturns(a0.clone()));
                Rc::new(move |a0: crate::syntax::Pattern_| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::TestCheckKind>>>
            } })),
            m103928_6 if (m103928_6 == &Text::lit("fired")) => prism_rtl::Turn::More(Rc::new(OnePattern { p_: p_.clone(), make_fn: {
                let f = Rc::new(|a0: &crate::syntax::Pattern_| crate::syntax::TestCheckKind::CkFired(a0.clone()));
                Rc::new(move |a0: crate::syntax::Pattern_| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0)))
                }) as Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::TestCheckKind>>>
            } })),
            m103928_7 if (m103928_7 == &Text::lit("expect_count")) => {
                let p_ = p_.clone();
                call_then(start_parse_pattern(p_.clone(), false), move |parse_pattern_104287: (crate::syntax::Pattern_, Ps)| {
                    let (pat, p1) = parse_pattern_104287;
                    if !at_comma(&p1) {
                        prism_rtl::Turn::Finished((crate::syntax::TestCheckKind::CkQuiet, error_here(&p1, &Text::lit("`expect_count` takes a pattern and a count: `expect_count p, n`"))))
                    } else {
                        {
                            let p2 = adv(&p1);
                            match kind(&p2) {
                                crate::syntax::lexer::TokKind::KInt(m104487_0_0, text) if (&m104487_0_0 == &Text::lit("")) => prism_rtl::Turn::Finished((crate::syntax::TestCheckKind::CkExpectCount(pat.clone(), parse_nat_text(&text)), adv(&p2))),
                                _ => prism_rtl::Turn::Finished((crate::syntax::TestCheckKind::CkQuiet, error_here(&p2, &Text::lit("`expect_count` takes a number")))),
                                _ => unreachable!("no arm matched"),
                            }
                        }
                    }
                })
            },
            m103928_8 if (m103928_8 == &Text::lit("requested")) => {
                let p_ = p_.clone();
                call_then(start_parse_pattern(p_.clone(), false), move |parse_pattern_104721: (crate::syntax::Pattern_, Ps)| {
                    let (place, p1) = parse_pattern_104721;
                    if !at_comma(&p1) {
                        prism_rtl::Turn::Finished((crate::syntax::TestCheckKind::CkQuiet, error_here(&p1, &Text::lit("`requested` takes a place and a value: `requested p, v`"))))
                    } else {
                        call_then(start_parse_pattern(adv(&p1), false), move |parse_pattern_104904: (crate::syntax::Pattern_, Ps)| {
                            let (value, q) = parse_pattern_104904;
                            prism_rtl::Turn::Finished((crate::syntax::TestCheckKind::CkRequested(place.clone(), value.clone()), q.clone()))
                        })
                    }
                })
            },
            m103928_9 if (m103928_9 == &Text::lit("quiet")) => prism_rtl::Turn::Finished((crate::syntax::TestCheckKind::CkQuiet, p_.clone())),
            m103928_10 if (m103928_10 == &Text::lit("settles")) => prism_rtl::Turn::Finished((crate::syntax::TestCheckKind::CkSettles, p_.clone())),
            m103928_11 if (m103928_11 == &Text::lit("aborted")) => prism_rtl::Turn::Finished((crate::syntax::TestCheckKind::CkAborted, p_.clone())),
            m103928_12 if (m103928_12 == &Text::lit("snapshot")) => match kind(p_) {
                crate::syntax::lexer::TokKind::KText(m105087_0_0, segs) if (&m105087_0_0 == &Text::lit("")) && all_plain(&segs) => prism_rtl::Turn::Finished((crate::syntax::TestCheckKind::CkSnapshot(concat(&each(&segs, &plain_of))), adv(p_))),
                _ => prism_rtl::Turn::Finished((crate::syntax::TestCheckKind::CkQuiet, error_here(p_, &Text::lit("`snapshot` takes a file name, a text literal")))),
                _ => unreachable!("no arm matched"),
            },
            _ => prism_rtl::Turn::Finished((crate::syntax::TestCheckKind::CkQuiet, error_at(p_, &prev(p_), &Text::from(format!("`{}` is not a check: the checks are expect, expect_none, expect_count, expect_top, expect_top_none, requested, unrequested, returns, fired, quiet, settles, aborted, snapshot", word))))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start CheckKindOf, x`: what the function value is when passed to `@Run`.
pub fn start_check_kind_of(p_: Ps, word: Text) -> Rc<dyn prism_rtl::Job<(crate::syntax::TestCheckKind, Ps)>> {
    Rc::new(CheckKindOf { p_, word })
}

/// ```prism
/// OnePattern: unbounded fn Ps, (fn Pattern -> TestCheckKind) -> ((TestCheckKind, Ps))
/// ```
pub fn one_pattern(p_: &Ps, make_fn: &Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::TestCheckKind>>>) -> (crate::syntax::TestCheckKind, Ps) {
    let (pat, q) = parse_pattern(p_, &false);
    (run_to_end(make_fn(pat.clone())), q.clone())
}

/// The step machine of `OnePattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OnePattern: unbounded fn Ps, (fn Pattern -> TestCheckKind) -> ((TestCheckKind, Ps))
/// ```
pub struct OnePattern {
    pub p_: Ps,
    pub make_fn: Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::TestCheckKind>>>,
}

impl prism_rtl::Job<(crate::syntax::TestCheckKind, Ps)> for OnePattern {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::TestCheckKind, Ps)> {
        let p_ = &self.p_;
        let make_fn = &self.make_fn;
        let make_fn = make_fn.clone();
        let p_ = p_.clone();
        call_then(start_parse_pattern(p_.clone(), false), move |parse_pattern_105650: (crate::syntax::Pattern_, Ps)| {
            let (pat, q) = parse_pattern_105650;
            call_value((&make_fn)(pat.clone()), move |make_105678: crate::syntax::TestCheckKind| prism_rtl::Turn::Finished((make_105678, q.clone())))
        })
    }
}

/// `Start OnePattern, x`: what the function value is when passed to `@Run`.
pub fn start_one_pattern(p_: Ps, make_fn: Rc<dyn Fn(crate::syntax::Pattern_) -> Rc<dyn prism_rtl::Job<crate::syntax::TestCheckKind>>>) -> Rc<dyn prism_rtl::Job<(crate::syntax::TestCheckKind, Ps)>> {
    Rc::new(OnePattern { p_, make_fn })
}

/// ```prism
/// AllPlain: fn [TextSegTok] -> Bool
/// ```
pub fn all_plain(segs: &Array<crate::syntax::lexer::TextSegTok>) -> bool {
    fold(segs, &true, &(|ok: &bool, s: &crate::syntax::lexer::TextSegTok| *ok && is_plain_seg(s)))
}

/// ```prism
/// IsPlainSeg: fn TextSegTok -> Bool
/// ```
pub fn is_plain_seg(text_seg_tok0: &crate::syntax::lexer::TextSegTok) -> bool {
    match text_seg_tok0 {
        crate::syntax::lexer::TextSegTok::TsPlain(_) => true,
        _ => false,
    }
}

/// ```prism
/// PlainOf: fn TextSegTok -> Text
/// ```
pub fn plain_of(text_seg_tok0: &crate::syntax::lexer::TextSegTok) -> Text {
    match text_seg_tok0 {
        crate::syntax::lexer::TextSegTok::TsPlain(s) => s.clone(),
        _ => Text::lit(""),
    }
}

/// ```prism
/// ParseNatText: fn Text -> Nat
/// ```
pub fn parse_nat_text(text0: &Text) -> Nat {
    let text = concat(&split(text0, &Text::lit("_")));
    if crate::syntax::lexer::has_prefix(&text, &Text::lit("0x")) {
        or(&crate::syntax::lexer::parse_hex(&crate::syntax::lexer::drop_prefix(&text, &Text::lit("0x"))), &Nat::from(0u32))
    } else {
        if crate::syntax::lexer::has_prefix(&text, &Text::lit("0o")) {
            or(&parse_radix(&crate::syntax::lexer::drop_prefix(&text, &Text::lit("0o")), &Nat::from(8u32)), &Nat::from(0u32))
        } else {
            if crate::syntax::lexer::has_prefix(&text, &Text::lit("0b")) {
                or(&parse_radix(&crate::syntax::lexer::drop_prefix(&text, &Text::lit("0b")), &Nat::from(2u32)), &Nat::from(0u32))
            } else {
                or(&parse_nat_opt(&text), &Nat::from(0u32))
            }
        }
    }
}

/// ```prism
/// ?ParseRadix: fn Text, Nat -> ?Nat
/// ```
pub fn parse_radix(t: &Text, radix: &Nat) -> Option<Nat> {
    'g106493: {
        if !((t != &Text::lit("")) && crate::syntax::lexer::all_chars(t, &{
            let radix = radix.clone();
            Rc::new(move |p0: Text| {
                let radix = radix.clone();
                once_job(move || {
                    let c = p0;
                    prism_rtl::Turn::Finished(crate::syntax::lexer::is_digit(&c) && (&crate::syntax::lexer::hex_value(&c) < &radix))
                })
            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
        })) {
            break 'g106493 None;
        }
        Some(crate::syntax::lexer::fold_chars(t, &Nat::from(0u32), &{
            let radix = radix.clone();
            Rc::new(move |(p0, p1): (Nat, Text)| {
                let radix = radix.clone();
                once_job(move || {
                    let n = p0;
                    let c = p1;
                    prism_rtl::Turn::Finished(&(&n * &radix) + &crate::syntax::lexer::hex_value(&c))
                })
            }) as Rc<dyn Fn((Nat, Text)) -> Rc<dyn prism_rtl::Job<Nat>>>
        }))
    }
}
