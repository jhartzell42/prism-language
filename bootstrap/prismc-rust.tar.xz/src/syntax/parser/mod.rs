//! The module `Syntax.Parser`, from `target/bootstrap/src/prismc/syntax/parser/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod blocks;
pub mod decls;
pub mod expr;
pub mod test_language;
pub mod types;

/// `Pair`:
///
/// ```prism
/// type Pair = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Pair {
    pub partner: Option<Nat>,
    pub outer: bool,
    pub inner: bool,
}

impl Show for Pair {
    fn show(&self, p: &mut Printer) {
        p.record("Pair", &[("partner", &self.partner), ("outer", &self.outer), ("inner", &self.inner)]);
    }
}

impl ToPod for Pair {
    fn to_pod(&self) -> Pod {
        Pod::record("Pair", vec![("partner", self.partner.to_pod()), ("outer", self.outer.to_pod()), ("inner", self.inner.to_pod())])
    }
}

impl FromPod for Pair {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Pair { partner: FromPod::from_pod(field(p, "partner")?)?, outer: FromPod::from_pod(field(p, "outer")?)?, inner: FromPod::from_pod(field(p, "inner")?)? })
    }
}

/// `Parsed`:
///
/// ```prism
/// type Parsed = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Parsed {
    pub tree: crate::syntax::Module,
    pub diags: Array<crate::syntax::Diag>,
}

impl Show for Parsed {
    fn show(&self, p: &mut Printer) {
        p.record("Parsed", &[("tree", &self.tree), ("diags", &self.diags)]);
    }
}

impl ToPod for Parsed {
    fn to_pod(&self) -> Pod {
        Pod::record("Parsed", vec![("tree", self.tree.to_pod()), ("diags", self.diags.to_pod())])
    }
}

impl FromPod for Parsed {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Parsed { tree: FromPod::from_pod(field(p, "tree")?)?, diags: FromPod::from_pod(field(p, "diags")?)? })
    }
}

/// `Ps`:
///
/// ```prism
/// type Ps = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Ps {
    pub toks: Array<crate::syntax::lexer::Tok>,
    pub pairs: Array<Pair>,
    pub pos: Nat,
    pub diags: Array<crate::syntax::Diag>,
    pub out: Array<crate::syntax::Diag>,
    pub step_mode: bool,
    pub in_trait: bool,
    pub bad: bool,
}

impl Show for Ps {
    fn show(&self, p: &mut Printer) {
        p.record("Ps", &[("toks", &self.toks), ("pairs", &self.pairs), ("pos", &self.pos), ("diags", &self.diags), ("out", &self.out), ("step_mode", &self.step_mode), ("in_trait", &self.in_trait), ("bad", &self.bad)]);
    }
}

impl ToPod for Ps {
    fn to_pod(&self) -> Pod {
        Pod::record("Ps", vec![("toks", self.toks.to_pod()), ("pairs", self.pairs.to_pod()), ("pos", self.pos.to_pod()), ("diags", self.diags.to_pod()), ("out", self.out.to_pod()), ("step_mode", self.step_mode.to_pod()), ("in_trait", self.in_trait.to_pod()), ("bad", self.bad.to_pod())])
    }
}

impl FromPod for Ps {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Ps { toks: FromPod::from_pod(field(p, "toks")?)?, pairs: FromPod::from_pod(field(p, "pairs")?)?, pos: FromPod::from_pod(field(p, "pos")?)?, diags: FromPod::from_pod(field(p, "diags")?)?, out: FromPod::from_pod(field(p, "out")?)?, step_mode: FromPod::from_pod(field(p, "step_mode")?)?, in_trait: FromPod::from_pod(field(p, "in_trait")?)?, bad: FromPod::from_pod(field(p, "bad")?)? })
    }
}

/// ```prism
/// let noRange
/// ```
pub fn no_range() -> crate::syntax::Range {
    crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) }
}

/// ```prism
/// let eofTok
/// ```
pub fn eof_tok() -> crate::syntax::lexer::Tok {
    crate::syntax::lexer::Tok { kind: crate::syntax::lexer::TokKind::KEof, span: no_range(), touches: false, line_start: false }
}

/// ```prism
/// let noPair
/// ```
pub fn no_pair() -> Pair {
    Pair { partner: None, outer: false, inner: false }
}

/// ```prism
/// ParseFile: unbounded fn Text -> Parsed
/// ```
pub fn parse_file(src: &Text) -> Parsed {
    let lexed = crate::syntax::lexer::layout::lex_file(src);
    let (m, p_) = crate::syntax::parser::decls::parse_module(&new_ps(&lexed.tokens), &false);
    Parsed { tree: m.clone(), diags: finish_diags(&append(&append(&lexed.diags, &p_.diags), &p_.out)) }
}

/// The step machine of `ParseFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseFile: unbounded fn Text -> Parsed
/// ```
pub struct ParseFile {
    pub src: Text,
}

impl prism_rtl::Job<Parsed> for ParseFile {
    fn cycle(&self) -> prism_rtl::Turn<Parsed> {
        let src = &self.src;
        let src = src.clone();
        call_then(crate::syntax::lexer::layout::start_lex_file(src.clone()), move |lex_file_3387: crate::syntax::lexer::Lexed| {
            let lexed = lex_file_3387;
            call_then(start_new_ps(lexed.tokens.clone()), move |new_ps_3431: Ps| call_then(crate::syntax::parser::decls::start_parse_module(new_ps_3431, false), move |parse_module_3418: (crate::syntax::Module, Ps)| {
                let (m, p_) = parse_module_3418;
                prism_rtl::Turn::Finished(Parsed { tree: m.clone(), diags: finish_diags(&append(&append(&lexed.diags, &p_.diags), &p_.out)) })
            }))
        })
    }
}

/// `Start ParseFile, x`: what the function value is when passed to `@Run`.
pub fn start_parse_file(src: Text) -> Rc<dyn prism_rtl::Job<Parsed>> {
    Rc::new(ParseFile { src })
}

/// ```prism
/// ParseFragment: unbounded fn Text -> Parsed
/// ```
pub fn parse_fragment(src: &Text) -> Parsed {
    let lexed = crate::syntax::lexer::layout::lex_file(src);
    let (m, p_) = crate::syntax::parser::decls::parse_module(&new_ps(&lexed.tokens), &true);
    Parsed { tree: m.clone(), diags: finish_diags(&append(&append(&lexed.diags, &p_.diags), &p_.out)) }
}

/// The step machine of `ParseFragment`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseFragment: unbounded fn Text -> Parsed
/// ```
pub struct ParseFragment {
    pub src: Text,
}

impl prism_rtl::Job<Parsed> for ParseFragment {
    fn cycle(&self) -> prism_rtl::Turn<Parsed> {
        let src = &self.src;
        let src = src.clone();
        call_then(crate::syntax::lexer::layout::start_lex_file(src.clone()), move |lex_file_3780: crate::syntax::lexer::Lexed| {
            let lexed = lex_file_3780;
            call_then(start_new_ps(lexed.tokens.clone()), move |new_ps_3824: Ps| call_then(crate::syntax::parser::decls::start_parse_module(new_ps_3824, true), move |parse_module_3811: (crate::syntax::Module, Ps)| {
                let (m, p_) = parse_module_3811;
                prism_rtl::Turn::Finished(Parsed { tree: m.clone(), diags: finish_diags(&append(&append(&lexed.diags, &p_.diags), &p_.out)) })
            }))
        })
    }
}

/// `Start ParseFragment, x`: what the function value is when passed to `@Run`.
pub fn start_parse_fragment(src: Text) -> Rc<dyn prism_rtl::Job<Parsed>> {
    Rc::new(ParseFragment { src })
}

/// ```prism
/// NewPs: unbounded fn [Tok] -> Ps
/// ```
pub fn new_ps(toks0: &Array<crate::syntax::lexer::Tok>) -> Ps {
    let ends = match crate::syntax::lexer::chars::last(toks0) {
        Some(t) => &t.kind == &crate::syntax::lexer::TokKind::KEof,
        None => false,
    };
    let end = match crate::syntax::lexer::chars::last(toks0) {
        Some(t) => crate::syntax::Range { start: t.span.end.clone(), end: t.span.end.clone() },
        None => no_range(),
    };
    let toks = if ends {
        toks0.clone()
    } else {
        push(toks0, &crate::syntax::lexer::Tok { kind: crate::syntax::lexer::TokKind::KEof, span: end.clone(), touches: false, line_start: false })
    };
    Ps { toks: toks.clone(), pairs: pair_brackets(&toks), pos: Nat::from(0u32), diags: Array::new(), out: Array::new(), step_mode: false, in_trait: false, bad: false }
}

/// The step machine of `NewPs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NewPs: unbounded fn [Tok] -> Ps
/// ```
pub struct NewPs {
    pub toks0: Array<crate::syntax::lexer::Tok>,
}

impl prism_rtl::Job<Ps> for NewPs {
    fn cycle(&self) -> prism_rtl::Turn<Ps> {
        let toks0 = &self.toks0;
        let ends = match crate::syntax::lexer::chars::last(toks0) {
            Some(t) => &t.kind == &crate::syntax::lexer::TokKind::KEof,
            None => false,
        };
        let end = match crate::syntax::lexer::chars::last(toks0) {
            Some(t) => crate::syntax::Range { start: t.span.end.clone(), end: t.span.end.clone() },
            None => no_range(),
        };
        let toks = if ends {
            toks0.clone()
        } else {
            push(toks0, &crate::syntax::lexer::Tok { kind: crate::syntax::lexer::TokKind::KEof, span: end.clone(), touches: false, line_start: false })
        };
        call_then(start_pair_brackets(toks.clone()), move |pair_brackets_4303: Array<Pair>| prism_rtl::Turn::Finished(Ps { toks: toks.clone(), pairs: pair_brackets_4303, pos: Nat::from(0u32), diags: Array::new(), out: Array::new(), step_mode: false, in_trait: false, bad: false }))
    }
}

/// `Start NewPs, x`: what the function value is when passed to `@Run`.
pub fn start_new_ps(toks0: Array<crate::syntax::lexer::Tok>) -> Rc<dyn prism_rtl::Job<Ps>> {
    Rc::new(NewPs { toks0 })
}

/// ```prism
/// Sub: unbounded fn Ps, [Tok], Range -> Ps
/// ```
pub fn sub(p_: &Ps, toks: &Array<crate::syntax::lexer::Tok>, end: &crate::syntax::Range) -> Ps {
    let q = new_ps(&push(toks, &crate::syntax::lexer::Tok { kind: crate::syntax::lexer::TokKind::KEof, span: end.clone(), touches: false, line_start: false }));
    let mut this: Ps = q.clone();
    this.step_mode = p_.step_mode;
    this
}

/// The step machine of `Sub`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Sub: unbounded fn Ps, [Tok], Range -> Ps
/// ```
pub struct Sub {
    pub p_: Ps,
    pub toks: Array<crate::syntax::lexer::Tok>,
    pub end: crate::syntax::Range,
}

impl prism_rtl::Job<Ps> for Sub {
    fn cycle(&self) -> prism_rtl::Turn<Ps> {
        let p_ = &self.p_;
        let toks = &self.toks;
        let end = &self.end;
        let end = end.clone();
        let p_ = p_.clone();
        let toks = toks.clone();
        call_then(start_new_ps(push(&toks, &crate::syntax::lexer::Tok { kind: crate::syntax::lexer::TokKind::KEof, span: end.clone(), touches: false, line_start: false })), move |new_ps_4612: Ps| {
            let q = new_ps_4612;
            prism_rtl::Turn::Finished({
                let mut this: Ps = q.clone();
                this.step_mode = p_.step_mode;
                this
            })
        })
    }
}

/// `Start Sub, x`: what the function value is when passed to `@Run`.
pub fn start_sub(p_: Ps, toks: Array<crate::syntax::lexer::Tok>, end: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<Ps>> {
    Rc::new(Sub { p_, toks, end })
}

/// ```prism
/// Absorb: fn Ps, Ps -> Ps
/// ```
pub fn absorb(p_: &Ps, sub_: &Ps) -> Ps {
    let mut this: Ps = p_.clone();
    this.diags = append(&this.diags, &sub_.diags);
    this.out = append(&this.out, &sub_.out);
    this
}

/// ```prism
/// FinishDiags: fn [Diag] -> [Diag]
/// ```
pub fn finish_diags(ds: &Array<crate::syntax::Diag>) -> Array<crate::syntax::Diag> {
    let sorted = fold(ds, &Array::new(), &insert_diag);
    fold(&sorted, &Array::new(), &(|acc: &Array<crate::syntax::Diag>, d: &crate::syntax::Diag| match crate::syntax::lexer::chars::last(acc) {
        Some(e) if ((&e.span == &d.span) && (&e.message == &d.message)) => acc.clone(),
        _ => push(acc, d),
        _ => unreachable!("no arm matched"),
    }))
}

/// ```prism
/// StageRank: fn Text -> Nat
/// ```
pub fn stage_rank(text0: &Text) -> Nat {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("lex")) => Nat::from(0u32),
        c1_0 if (c1_0 == &Text::lit("parse")) => Nat::from(1u32),
        _ => Nat::from(2u32),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// DiagBefore: fn Diag, Diag -> Bool
/// ```
pub fn diag_before(a: &crate::syntax::Diag, b: &crate::syntax::Diag) -> bool {
    (&a.span.start < &b.span.start) || ((&a.span.start == &b.span.start) && (&stage_rank(&a.stage) < &stage_rank(&b.stage)))
}

/// ```prism
/// InsertDiag: fn [Diag], Diag -> [Diag]
/// ```
pub fn insert_diag(sorted: &Array<crate::syntax::Diag>, d: &crate::syntax::Diag) -> Array<crate::syntax::Diag> {
    let before_ = fold(sorted, &Array::new(), &(|acc: &Array<crate::syntax::Diag>, e: &crate::syntax::Diag| if diag_before(d, e) { acc.clone() } else { push(acc, e) }));
    let after_ = fold(sorted, &Array::new(), &(|acc: &Array<crate::syntax::Diag>, e: &crate::syntax::Diag| if diag_before(d, e) { push(acc, e) } else { acc.clone() }));
    append(&push(&before_, d), &after_)
}

/// ```prism
/// PairBrackets: unbounded fn [Tok] -> [Pair]
/// ```
pub fn pair_brackets(toks: &Array<crate::syntax::lexer::Tok>) -> Array<Pair> {
    let mut this: Array<Pair> = each(toks, &(|t: &crate::syntax::lexer::Tok| no_pair()));
    let mut stack: Array<(Nat, Text)> = Array::new();
    for (i6364, v6364) in toks.clone().into_iter().enumerate() {
        let k6364 = nat_of(i6364);
        let t = v6364.clone();
        if let Some(k) = open_kind_of(&t.kind) {
            stack = push(&stack, &(k6364.clone(), k.clone()));
        }
        if let Some(k) = close_kind_of(&t.kind) {
            if let Some((j, k2)) = crate::syntax::lexer::chars::last(&stack) {
                if &k2 == &k {
                    stack = crate::syntax::lexer::chars::pop(&stack);
                    (*at_mut(&mut this, &k6364)).partner = Some(j.clone());
                    (*at_mut(&mut this, &j)).partner = Some(k6364.clone());
                }
            }
        }
    }
    for (i6825, v6825) in toks.clone().into_iter().enumerate() {
        let k6825 = nat_of(i6825);
        let t = v6825.clone();
        let i = k6825.clone();
        if let Some(kind_) = open_kind_of(&t.kind) {
            if (&kind_ != &Text::lit("{")) && !or(&index(&this, &i), &no_pair()).inner {
                if let Some(j) = or(&index(&this, &i), &no_pair()).partner.clone() {
                    if double_at(&this, toks, &i, &j, &kind_) {
                        (*at_mut(&mut this, &i)).outer = true;
                        (*at_mut(&mut this, &j)).outer = true;
                        (*at_mut(&mut this, &(&i + &Nat::from(1u32)))).inner = true;
                        (*at_mut(&mut this, &crate::syntax::lexer::chars::dec(&j))).inner = true;
                    }
                }
            }
        }
    }
    this
}

/// The step machine of `PairBrackets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PairBrackets: unbounded fn [Tok] -> [Pair]
/// ```
pub struct PairBrackets {
    pub toks: Array<crate::syntax::lexer::Tok>,
}

impl prism_rtl::Job<Array<Pair>> for PairBrackets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Pair>> {
        let toks = &self.toks;
        prism_rtl::Turn::Finished({
            let mut this: Array<Pair> = each(toks, &(|t: &crate::syntax::lexer::Tok| no_pair()));
            let mut stack: Array<(Nat, Text)> = Array::new();
            for (i6364, v6364) in toks.clone().into_iter().enumerate() {
                let k6364 = nat_of(i6364);
                let t = v6364.clone();
                if let Some(k) = open_kind_of(&t.kind) {
                    stack = push(&stack, &(k6364.clone(), k.clone()));
                }
                if let Some(k) = close_kind_of(&t.kind) {
                    if let Some((j, k2)) = crate::syntax::lexer::chars::last(&stack) {
                        if &k2 == &k {
                            stack = crate::syntax::lexer::chars::pop(&stack);
                            (*at_mut(&mut this, &k6364)).partner = Some(j.clone());
                            (*at_mut(&mut this, &j)).partner = Some(k6364.clone());
                        }
                    }
                }
            }
            for (i6825, v6825) in toks.clone().into_iter().enumerate() {
                let k6825 = nat_of(i6825);
                let t = v6825.clone();
                let i = k6825.clone();
                if let Some(kind_) = open_kind_of(&t.kind) {
                    if (&kind_ != &Text::lit("{")) && !or(&index(&this, &i), &no_pair()).inner {
                        if let Some(j) = or(&index(&this, &i), &no_pair()).partner.clone() {
                            if double_at(&this, toks, &i, &j, &kind_) {
                                (*at_mut(&mut this, &i)).outer = true;
                                (*at_mut(&mut this, &j)).outer = true;
                                (*at_mut(&mut this, &(&i + &Nat::from(1u32)))).inner = true;
                                (*at_mut(&mut this, &crate::syntax::lexer::chars::dec(&j))).inner = true;
                            }
                        }
                    }
                }
            }
            this
        })
    }
}

/// `Start PairBrackets, x`: what the function value is when passed to `@Run`.
pub fn start_pair_brackets(toks: Array<crate::syntax::lexer::Tok>) -> Rc<dyn prism_rtl::Job<Array<Pair>>> {
    Rc::new(PairBrackets { toks })
}

/// ```prism
/// DoubleAt: fn [Pair], [Tok], Nat, Nat, Text -> Bool
/// ```
pub fn double_at(pairs: &Array<Pair>, toks: &Array<crate::syntax::lexer::Tok>, i: &Nat, j: &Nat, kind_: &Text) -> bool {
    let next = or(&index(toks, &(i + &Nat::from(1u32))), &eof_tok());
    let inner_close_opt = or(&index(pairs, &(i + &Nat::from(1u32))), &no_pair()).partner.clone();
    ((is_open_of(&next.kind, kind_) && next.touches) && (&inner_close_opt == &Some(crate::syntax::lexer::chars::dec(j)))) && or(&index(toks, j), &eof_tok()).touches
}

/// ```prism
/// ?OpenKindOf: fn TokKind -> ?Text
/// ```
pub fn open_kind_of(tok_kind0: &crate::syntax::lexer::TokKind) -> Option<Text> {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KOpen(k, _) => Some(k.clone()),
        _ => None,
    }
}

/// ```prism
/// ?CloseKindOf: fn TokKind -> ?Text
/// ```
pub fn close_kind_of(tok_kind0: &crate::syntax::lexer::TokKind) -> Option<Text> {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KClose(k) => Some(k.clone()),
        _ => None,
    }
}

/// ```prism
/// IsOpenOf: fn TokKind, Text -> Bool
/// ```
pub fn is_open_of(tok_kind0: &crate::syntax::lexer::TokKind, text1: &Text) -> bool {
    match (tok_kind0, text1) {
        (crate::syntax::lexer::TokKind::KOpen(k, _), kind_) => k == kind_,
        (_, _) => false,
    }
}

/// ```prism
/// Tk: fn Ps -> Tok
/// ```
pub fn tk(p_: &Ps) -> crate::syntax::lexer::Tok {
    if p_.bad {
        eof_tok()
    } else {
        or(&index(&p_.toks, &min(&p_.pos, &crate::syntax::lexer::chars::dec(&len(&p_.toks)))), &eof_tok())
    }
}

/// ```prism
/// TkAt: fn Ps, Nat -> Tok
/// ```
pub fn tk_at(p_: &Ps, n: &Nat) -> crate::syntax::lexer::Tok {
    if p_.bad {
        eof_tok()
    } else {
        or(&index(&p_.toks, &min(&(&p_.pos + n), &crate::syntax::lexer::chars::dec(&len(&p_.toks)))), &eof_tok())
    }
}

/// ```prism
/// Kind: fn Ps -> TokKind
/// ```
pub fn kind(p_: &Ps) -> crate::syntax::lexer::TokKind {
    tk(p_).kind.clone()
}

/// ```prism
/// KindAt: fn Ps, Nat -> TokKind
/// ```
pub fn kind_at(p_: &Ps, n: &Nat) -> crate::syntax::lexer::TokKind {
    tk_at(p_, n).kind.clone()
}

/// ```prism
/// Here: fn Ps -> Range
/// ```
pub fn here(p_: &Ps) -> crate::syntax::Range {
    tk(p_).span.clone()
}

/// ```prism
/// Prev: fn Ps -> Range
/// ```
pub fn prev(p_: &Ps) -> crate::syntax::Range {
    or(&index(&p_.toks, &crate::syntax::lexer::chars::dec(&p_.pos)), &eof_tok()).span.clone()
}

/// ```prism
/// To: fn Range, Range -> Range
/// ```
pub fn to(a: &crate::syntax::Range, b: &crate::syntax::Range) -> crate::syntax::Range {
    crate::syntax::Range { start: min(&a.start, &b.start), end: max(&a.end, &b.end) }
}

/// ```prism
/// AtEnd: fn Range -> Range
/// ```
pub fn at_end(r: &crate::syntax::Range) -> crate::syntax::Range {
    crate::syntax::Range { start: r.end.clone(), end: r.end.clone() }
}

/// ```prism
/// Adv: fn Ps -> Ps
/// ```
pub fn adv(p_: &Ps) -> Ps {
    if p_.bad || (&(&p_.pos + &Nat::from(1u32)) >= &len(&p_.toks)) {
        p_.clone()
    } else {
        {
            let mut this: Ps = p_.clone();
            this.pos = &this.pos + &Nat::from(1u32);
            this
        }
    }
}

/// ```prism
/// PairAt: fn Ps -> Pair
/// ```
pub fn pair_at(p_: &Ps) -> Pair {
    or(&index(&p_.pairs, &min(&p_.pos, &crate::syntax::lexer::chars::dec(&len(&p_.pairs)))), &no_pair())
}

/// ```prism
/// AtEof: fn Ps -> Bool
/// ```
pub fn at_eof(p_: &Ps) -> bool {
    &kind(p_) == &crate::syntax::lexer::TokKind::KEof
}

/// ```prism
/// AtKw: fn Ps, Text -> Bool
/// ```
pub fn at_kw(p_: &Ps, w: &Text) -> bool {
    &kind(p_) == &crate::syntax::lexer::TokKind::KKw(w.clone(), Text::lit(""))
}

/// ```prism
/// AtOp: fn Ps, Text -> Bool
/// ```
pub fn at_op(p_: &Ps, op: &Text) -> bool {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KOp(o, _) => &o == op,
        _ => false,
    }
}

/// ```prism
/// AtSep: fn Ps -> Bool
/// ```
pub fn at_sep(p_: &Ps) -> bool {
    &kind(p_) == &crate::syntax::lexer::TokKind::KLaySep
}

/// ```prism
/// AtOpenL: fn Ps -> Bool
/// ```
pub fn at_open_l(p_: &Ps) -> bool {
    &kind(p_) == &crate::syntax::lexer::TokKind::KLayOpen
}

/// ```prism
/// AtCloseL: fn Ps -> Bool
/// ```
pub fn at_close_l(p_: &Ps) -> bool {
    &kind(p_) == &crate::syntax::lexer::TokKind::KLayClose
}

/// ```prism
/// AtComma: fn Ps -> Bool
/// ```
pub fn at_comma(p_: &Ps) -> bool {
    &kind(p_) == &crate::syntax::lexer::TokKind::KComma
}

/// ```prism
/// AtColon: fn Ps -> Bool
/// ```
pub fn at_colon(p_: &Ps) -> bool {
    &kind(p_) == &crate::syntax::lexer::TokKind::KColon
}

/// ```prism
/// IsOpenKind: fn TokKind, Text -> Bool
/// ```
pub fn is_open_kind(tok_kind0: &crate::syntax::lexer::TokKind, text1: &Text) -> bool {
    match (tok_kind0, text1) {
        (crate::syntax::lexer::TokKind::KOpen(k, _), kind_) => k == kind_,
        (_, _) => false,
    }
}

/// ```prism
/// AtDoubleOpen: fn Ps, Text -> Bool
/// ```
pub fn at_double_open(p_: &Ps, kind_: &Text) -> bool {
    is_open_kind(&kind(p_), kind_) && pair_at(p_).outer
}

/// ```prism
/// AtSingleOpen: fn Ps, Text -> Bool
/// ```
pub fn at_single_open(p_: &Ps, kind_: &Text) -> bool {
    is_open_kind(&kind(p_), kind_) && !pair_at(p_).outer
}

/// ```prism
/// AtClose: fn Ps, Text -> Bool
/// ```
pub fn at_close(p_: &Ps, kind_: &Text) -> bool {
    &kind(p_) == &crate::syntax::lexer::TokKind::KClose(kind_.clone())
}

/// ```prism
/// OpenDouble: fn Ps -> Ps
/// ```
pub fn open_double(p_: &Ps) -> Ps {
    adv(&adv(p_))
}

/// ```prism
/// CloseDouble: fn Ps, Text -> Ps
/// ```
pub fn close_double(p_: &Ps, kind_: &Text) -> Ps {
    let c = crate::syntax::lexer::close_char(kind_);
    let p1 = adv(p_);
    if ((at_close(p_, kind_) && pair_at(p_).inner) && at_close(&p1, kind_)) && pair_at(&p1).outer {
        adv(&p1)
    } else {
        if at_close(p_, kind_) && pair_at(p_).inner {
            error_here(&p1, &Text::from(format!("expected `{}{}` to close the double bracket", &c, &c)))
        } else {
            error_here(p_, &Text::from(format!("expected `{}{}` to close the double bracket", &c, &c)))
        }
    }
}

/// ```prism
/// ExpectClose: fn Ps, Text -> Ps
/// ```
pub fn expect_close(p_: &Ps, kind_: &Text) -> Ps {
    if at_close(p_, kind_) {
        adv(p_)
    } else {
        error_here(p_, &Text::from(format!("expected `{}`", &crate::syntax::lexer::close_char(kind_))))
    }
}

/// ```prism
/// ParseDiag: fn Range, Text -> Diag
/// ```
pub fn parse_diag(span: &crate::syntax::Range, message: &Text) -> crate::syntax::Diag {
    crate::syntax::Diag { stage: Text::lit("parse"), span: span.clone(), message: message.clone(), feature: None }
}

/// ```prism
/// ErrorAt: fn Ps, Range, Text -> Ps
/// ```
pub fn error_at(p_: &Ps, span: &crate::syntax::Range, message: &Text) -> Ps {
    if p_.bad {
        p_.clone()
    } else {
        {
            let mut this: Ps = p_.clone();
            this.diags = push(&this.diags, &parse_diag(span, message));
            this.bad = true;
            this
        }
    }
}

/// ```prism
/// ErrorHere: fn Ps, Text -> Ps
/// ```
pub fn error_here(p_: &Ps, message: &Text) -> Ps {
    error_at(p_, &here(p_), &Text::from(format!("{}, found {}", message, &describe(&kind(p_)))))
}

/// ```prism
/// Fail: fn Ps -> Ps
/// ```
pub fn fail(p_: &Ps) -> Ps {
    let mut this: Ps = p_.clone();
    this.bad = true;
    this
}

/// ```prism
/// Unbad: fn Ps -> Ps
/// ```
pub fn unbad(p_: &Ps) -> Ps {
    let mut this: Ps = p_.clone();
    this.bad = false;
    this
}

/// ```prism
/// NoteError: fn Ps, Range, Text -> Ps
/// ```
pub fn note_error(p_: &Ps, span: &crate::syntax::Range, message: &Text) -> Ps {
    if p_.bad {
        p_.clone()
    } else {
        {
            let mut this: Ps = p_.clone();
            this.diags = push(&this.diags, &parse_diag(span, message));
            this
        }
    }
}

/// ```prism
/// Complain: fn Ps, Text -> Ps
/// ```
pub fn complain(p_: &Ps, message: &Text) -> Ps {
    unbad(&error_here(p_, message))
}

/// ```prism
/// OutOfScope: fn Ps, Range, Text, Text -> Ps
/// ```
pub fn out_of_scope(p_: &Ps, span: &crate::syntax::Range, feature: &Text, message: &Text) -> Ps {
    if p_.bad {
        p_.clone()
    } else {
        {
            let mut this: Ps = p_.clone();
            this.out = push(&this.out, &crate::syntax::Diag { stage: Text::lit("out"), span: span.clone(), message: message.clone(), feature: Some(feature.clone()) });
            this
        }
    }
}

/// ```prism
/// ExpectColon: fn Ps -> Ps
/// ```
pub fn expect_colon(p_: &Ps) -> Ps {
    if at_colon(p_) { adv(p_) } else { error_here(p_, &Text::lit("expected `:`")) }
}

/// ```prism
/// ExpectOp: fn Ps, Text -> Ps
/// ```
pub fn expect_op(p_: &Ps, op: &Text) -> Ps {
    if at_op(p_, op) {
        adv(p_)
    } else {
        error_here(p_, &Text::from(format!("expected `{}`", op)))
    }
}

/// ```prism
/// ExpectKw: fn Ps, Text -> Ps
/// ```
pub fn expect_kw(p_: &Ps, w: &Text) -> Ps {
    if at_kw(p_, w) {
        adv(p_)
    } else {
        error_here(p_, &Text::from(format!("expected `{}`", w)))
    }
}

/// ```prism
/// Recover: unbounded fn Ps -> Ps
/// ```
pub fn recover(p0: &Ps) -> Ps {
    let mut this: Ps = unbad(p0);
    let mut depth: Nat = Nat::from(0u32);
    let mut going: bool = true;
    while going {
        match &kind(&this) {
            crate::syntax::lexer::TokKind::KEof => {
                going = false;
                ()
            },
            crate::syntax::lexer::TokKind::KLayOpen => {
                depth = &depth + &Nat::from(1u32);
                this = adv(&this);
                ()
            },
            crate::syntax::lexer::TokKind::KLayClose => {
                if &depth == &Nat::from(0u32) {
                    going = false;
                } else {
                    depth = crate::syntax::lexer::chars::dec(&depth);
                    this = adv(&this);
                }
                ()
            },
            crate::syntax::lexer::TokKind::KLaySep if (&depth == &Nat::from(0u32)) => {
                going = false;
                ()
            },
            _ => {
                this = adv(&this);
                ()
            },
            _ => unreachable!("no arm matched"),
        };
    }
    this
}

/// The step machine of `Recover`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Recover: unbounded fn Ps -> Ps
/// ```
pub struct Recover {
    pub p0: Ps,
}

impl prism_rtl::Job<Ps> for Recover {
    fn cycle(&self) -> prism_rtl::Turn<Ps> {
        let p0 = &self.p0;
        let mut this: Ps = unbad(p0);
        let mut depth: Nat = Nat::from(0u32);
        let mut going: bool = true;
        call_then(loop_job((this, depth, going), move |(mut this, mut depth, mut going): (Ps, Nat, bool)| if going {
            {
                match &kind(&this) {
                    crate::syntax::lexer::TokKind::KEof => {
                        going = false;
                        ()
                    },
                    crate::syntax::lexer::TokKind::KLayOpen => {
                        depth = &depth + &Nat::from(1u32);
                        this = adv(&this);
                        ()
                    },
                    crate::syntax::lexer::TokKind::KLayClose => {
                        if &depth == &Nat::from(0u32) {
                            going = false;
                        } else {
                            depth = crate::syntax::lexer::chars::dec(&depth);
                            this = adv(&this);
                        }
                        ()
                    },
                    crate::syntax::lexer::TokKind::KLaySep if (&depth == &Nat::from(0u32)) => {
                        going = false;
                        ()
                    },
                    _ => {
                        this = adv(&this);
                        ()
                    },
                    _ => unreachable!("no arm matched"),
                };
                Ok((this, depth, going))
            }
        } else {
            Err((this, depth, going))
        }), move |(mut this, mut depth, mut going): (Ps, Nat, bool)| prism_rtl::Turn::Finished(this))
    }
}

/// `Start Recover, x`: what the function value is when passed to `@Run`.
pub fn start_recover(p0: Ps) -> Rc<dyn prism_rtl::Job<Ps>> {
    Rc::new(Recover { p0 })
}

/// ```prism
/// Recovered: unbounded fn Ps -> Ps
/// ```
pub fn recovered(p_: &Ps) -> Ps {
    if p_.bad { recover(p_) } else { p_.clone() }
}

/// The step machine of `Recovered`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Recovered: unbounded fn Ps -> Ps
/// ```
pub struct Recovered {
    pub p_: Ps,
}

impl prism_rtl::Job<Ps> for Recovered {
    fn cycle(&self) -> prism_rtl::Turn<Ps> {
        let p_ = &self.p_;
        if p_.bad {
            prism_rtl::Turn::More(Rc::new(Recover { p0: p_.clone() }))
        } else {
            prism_rtl::Turn::Finished(p_.clone())
        }
    }
}

/// `Start Recovered, x`: what the function value is when passed to `@Run`.
pub fn start_recovered(p_: Ps) -> Rc<dyn prism_rtl::Job<Ps>> {
    Rc::new(Recovered { p_ })
}

/// ```prism
/// AtStmtBoundary: fn Ps -> Bool
/// ```
pub fn at_stmt_boundary(p_: &Ps) -> bool {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KLaySep => true,
        crate::syntax::lexer::TokKind::KLayClose => true,
        crate::syntax::lexer::TokKind::KEof => true,
        _ => false,
    }
}

/// ```prism
/// ExpectStmtEnd: unbounded fn Ps, Text -> Ps
/// ```
pub fn expect_stmt_end(p_: &Ps, what: &Text) -> Ps {
    if at_stmt_boundary(p_) {
        p_.clone()
    } else {
        recover(&note_error(p_, &here(p_), &Text::from(format!("expected the end of the {}, found {}", what, &describe(&kind(p_))))))
    }
}

/// The step machine of `ExpectStmtEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExpectStmtEnd: unbounded fn Ps, Text -> Ps
/// ```
pub struct ExpectStmtEnd {
    pub p_: Ps,
    pub what: Text,
}

impl prism_rtl::Job<Ps> for ExpectStmtEnd {
    fn cycle(&self) -> prism_rtl::Turn<Ps> {
        let p_ = &self.p_;
        let what = &self.what;
        if at_stmt_boundary(p_) {
            prism_rtl::Turn::Finished(p_.clone())
        } else {
            prism_rtl::Turn::More(Rc::new(Recover { p0: note_error(p_, &here(p_), &Text::from(format!("expected the end of the {}, found {}", what, &describe(&kind(p_))))) }))
        }
    }
}

/// `Start ExpectStmtEnd, x`: what the function value is when passed to `@Run`.
pub fn start_expect_stmt_end(p_: Ps, what: Text) -> Rc<dyn prism_rtl::Job<Ps>> {
    Rc::new(ExpectStmtEnd { p_, what })
}

/// ```prism
/// Describe: fn TokKind -> Text
/// ```
pub fn describe(tok_kind0: &crate::syntax::lexer::TokKind) -> Text {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KLayOpen => Text::lit("an indented block"),
        crate::syntax::lexer::TokKind::KLaySep => Text::lit("the end of the line"),
        crate::syntax::lexer::TokKind::KLayClose => Text::lit("the end of the block"),
        crate::syntax::lexer::TokKind::KEof => Text::lit("the end of the input"),
        crate::syntax::lexer::TokKind::KText(_, _) => Text::lit("a text literal"),
        crate::syntax::lexer::TokKind::KTemplate(_) => Text::lit("a template"),
        k => Text::from(format!("`{}`", &crate::syntax::lexer::corpus::token_text(k))),
    }
}

/// ```prism
/// Bracketed: fn Ps, (fn Ps -> ((a, Ps))) -> ((a, Ps))
/// ```
pub fn bracketed<A: Clone + 'static>(p_: &Ps, f_fn: &Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>) -> (A, Ps) {
    let (v_, q) = run_to_end(f_fn(with_step_mode(p_, &false)));
    (v_.clone(), with_step_mode(&q, &p_.step_mode))
}

/// The step machine of `Bracketed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Bracketed: fn Ps, (fn Ps -> ((a, Ps))) -> ((a, Ps))
/// ```
pub struct Bracketed<A> {
    pub p_: Ps,
    pub f_fn: Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>,
}

impl<A: Clone + 'static> prism_rtl::Job<(A, Ps)> for Bracketed<A> {
    fn cycle(&self) -> prism_rtl::Turn<(A, Ps)> {
        let p_ = &self.p_;
        let f_fn = &self.f_fn;
        let f_fn = f_fn.clone();
        let p_ = p_.clone();
        call_value((&f_fn)(with_step_mode(&p_, &false)), move |f_14182: (A, Ps)| {
            let (v_, q) = f_14182;
            prism_rtl::Turn::Finished((v_.clone(), with_step_mode(&q, &p_.step_mode)))
        })
    }
}

/// `Start Bracketed, x`: what the function value is when passed to `@Run`.
pub fn start_bracketed<A: Clone + 'static>(p_: Ps, f_fn: Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>) -> Rc<dyn prism_rtl::Job<(A, Ps)>> {
    Rc::new(Bracketed { p_, f_fn })
}

/// ```prism
/// WithStepMode: fn Ps, Bool -> Ps
/// ```
pub fn with_step_mode(p_: &Ps, flag: &bool) -> Ps {
    let mut this: Ps = p_.clone();
    this.step_mode = *flag;
    this
}

/// ```prism
/// LayoutItems: unbounded fn Ps, (fn Ps -> ((a, Ps))) -> (([a], Ps))
/// ```
pub fn layout_items<A: Clone + 'static>(p0: &Ps, f_fn: &Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>) -> (Array<A>, Ps) {
    let mut this: (Array<A>, Ps) = (Array::new(), p0.clone());
    let mut items: Array<A> = Array::new();
    let mut p_: Ps = p0.clone();
    let mut going: bool = true;
    while going {
        let (item, q) = run_to_end(f_fn(p_.clone()));
        if !q.bad {
            items = push(&items, &item);
        }
        p_ = recovered(&q);
        match &kind(&p_) {
            crate::syntax::lexer::TokKind::KLaySep => {
                p_ = adv(&p_);
            }
            crate::syntax::lexer::TokKind::KLayClose => {
                p_ = adv(&p_);
                going = false;
            }
            crate::syntax::lexer::TokKind::KEof => {
                going = false;
            }
            _ => {
                p_ = recover(&complain(&p_, &Text::lit("expected the end of the line")));
            }
        }
    }
    this = (items.clone(), p_.clone());
    this
}

/// The step machine of `LayoutItems`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LayoutItems: unbounded fn Ps, (fn Ps -> ((a, Ps))) -> (([a], Ps))
/// ```
pub struct LayoutItems<A> {
    pub p0: Ps,
    pub f_fn: Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>,
}

impl<A: Clone + 'static> prism_rtl::Job<(Array<A>, Ps)> for LayoutItems<A> {
    fn cycle(&self) -> prism_rtl::Turn<(Array<A>, Ps)> {
        let p0 = &self.p0;
        let f_fn = &self.f_fn;
        let mut this: (Array<A>, Ps) = (Array::new(), p0.clone());
        let mut items: Array<A> = Array::new();
        let mut p_: Ps = p0.clone();
        let mut going: bool = true;
        let f_fn = f_fn.clone();
        call_then(loop_job((this, going, items, p_), {
            let f_fn = f_fn.clone();
            move |(mut this, mut going, mut items, mut p_): ((Array<A>, Ps), bool, Array<A>, Ps)| if going {
                {
                    let (item, q) = run_to_end((&f_fn)(p_.clone()));
                    if !q.bad {
                        items = push(&items, &item);
                    }
                    p_ = recovered(&q);
                    match &kind(&p_) {
                        crate::syntax::lexer::TokKind::KLaySep => {
                            p_ = adv(&p_);
                        }
                        crate::syntax::lexer::TokKind::KLayClose => {
                            p_ = adv(&p_);
                            going = false;
                        }
                        crate::syntax::lexer::TokKind::KEof => {
                            going = false;
                        }
                        _ => {
                            p_ = recover(&complain(&p_, &Text::lit("expected the end of the line")));
                        }
                    }
                    Ok((this, going, items, p_))
                }
            } else {
                Err((this, going, items, p_))
            }
        }), move |(mut this, mut going, mut items, mut p_): ((Array<A>, Ps), bool, Array<A>, Ps)| {
            this = (items.clone(), p_.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start LayoutItems, x`: what the function value is when passed to `@Run`.
pub fn start_layout_items<A: Clone + 'static>(p0: Ps, f_fn: Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>) -> Rc<dyn prism_rtl::Job<(Array<A>, Ps)>> {
    Rc::new(LayoutItems { p0, f_fn })
}

/// ```prism
/// Commas: unbounded fn Ps, (fn Ps -> ((a, Ps))) -> (([a], Ps))
/// ```
pub fn commas<A: Clone + 'static>(p0: &Ps, f_fn: &Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>) -> (Array<A>, Ps) {
    let mut this: (Array<A>, Ps) = (Array::new(), p0.clone());
    let (first_, p1) = run_to_end(f_fn(p0.clone()));
    let mut items: Array<A> = Array::from(vec![first_.clone()]);
    let mut p_: Ps = p1.clone();
    while at_comma(&p_) && !p_.bad {
        let (item, q) = run_to_end(f_fn(adv(&p_)));
        items = push(&items, &item);
        p_ = q.clone();
    }
    this = (items.clone(), p_.clone());
    this
}

/// The step machine of `Commas`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Commas: unbounded fn Ps, (fn Ps -> ((a, Ps))) -> (([a], Ps))
/// ```
pub struct Commas<A> {
    pub p0: Ps,
    pub f_fn: Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>,
}

impl<A: Clone + 'static> prism_rtl::Job<(Array<A>, Ps)> for Commas<A> {
    fn cycle(&self) -> prism_rtl::Turn<(Array<A>, Ps)> {
        let p0 = &self.p0;
        let f_fn = &self.f_fn;
        let mut this: (Array<A>, Ps) = (Array::new(), p0.clone());
        let (first_, p1) = run_to_end(f_fn(p0.clone()));
        let mut items: Array<A> = Array::from(vec![first_.clone()]);
        let mut p_: Ps = p1.clone();
        call_then(loop_job((this, items, p_), {
            let f_fn = f_fn.clone();
            move |(mut this, mut items, mut p_): ((Array<A>, Ps), Array<A>, Ps)| if at_comma(&p_) && !p_.bad {
                {
                    let (item, q) = run_to_end((&f_fn)(adv(&p_)));
                    items = push(&items, &item);
                    p_ = q.clone();
                    Ok((this, items, p_))
                }
            } else {
                Err((this, items, p_))
            }
        }), move |(mut this, mut items, mut p_): ((Array<A>, Ps), Array<A>, Ps)| {
            this = (items.clone(), p_.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start Commas, x`: what the function value is when passed to `@Run`.
pub fn start_commas<A: Clone + 'static>(p0: Ps, f_fn: Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>) -> Rc<dyn prism_rtl::Job<(Array<A>, Ps)>> {
    Rc::new(Commas { p0, f_fn })
}

/// ```prism
/// let noSName
/// ```
pub fn no_sname() -> crate::syntax::SName {
    crate::syntax::SName { sigils: Text::lit(""), path_: Array::new(), span: no_range() }
}

/// ```prism
/// let noIdent
/// ```
pub fn no_ident() -> crate::syntax::Ident {
    crate::syntax::Ident { name: Text::lit(""), span: no_range() }
}

/// ```prism
/// IsUpperName: fn SName -> Bool
/// ```
pub fn is_upper_name(n: &crate::syntax::SName) -> bool {
    crate::syntax::lexer::chars::is_upper(&crate::syntax::lexer::chars::head(&or(&crate::syntax::lexer::chars::last(&n.path_), &Text::lit(""))))
}

/// ```prism
/// IsCallee: fn SName -> Bool
/// ```
pub fn is_callee(n: &crate::syntax::SName) -> bool {
    is_upper_name(n) || crate::syntax::lexer::chars::is_reserved_ctor(&or(&crate::syntax::lexer::chars::last(&n.path_), &Text::lit("")))
}

/// ```prism
/// IsTopic: fn SName -> Bool
/// ```
pub fn is_topic(n: &crate::syntax::SName) -> bool {
    &n.path_ == &Array::from(vec![Text::lit("_")])
}

/// ```prism
/// NameText: fn SName -> Text
/// ```
pub fn name_text(n: &crate::syntax::SName) -> Text {
    Text::from(format!("{}{}", &n.sigils, &crate::syntax::lexer::chars::join(&n.path_, &Text::lit("."))))
}

/// ```prism
/// ParseSName: fn Ps -> ((SName, Ps))
/// ```
pub fn parse_sname(p_: &Ps) -> (crate::syntax::SName, Ps) {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KName(n) => (crate::syntax::SName { sigils: n.sigils.clone(), path_: n.path_.clone(), span: here(p_) }, adv(p_)),
        _ => (no_sname(), error_here(p_, &Text::lit("expected a name"))),
    }
}

/// ```prism
/// ParseIdent: fn Ps -> ((Ident, Ps))
/// ```
pub fn parse_ident(p_: &Ps) -> (crate::syntax::Ident, Ps) {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KName(n) if (((&n.sigils == &Text::lit("")) && (&len(&n.path_) == &Nat::from(1u32))) && (&n.case == &crate::syntax::lexer::NameCase::CaseLower)) => (crate::syntax::Ident { name: or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")), span: here(p_) }, adv(p_)),
        crate::syntax::lexer::TokKind::KKw(m16382_1_0, m16382_1_1) if (&m16382_1_0 == &Text::lit("key")) && (&m16382_1_1 == &Text::lit("")) => (crate::syntax::Ident { name: Text::lit("key"), span: here(p_) }, adv(p_)),
        _ => (no_ident(), error_here(p_, &Text::lit("expected a lowercase name"))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParseQualName: fn Ps -> ((QualName, Ps))
/// ```
pub fn parse_qual_name(p_: &Ps) -> (crate::syntax::QualName, Ps) {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KName(n) if ((&n.sigils == &Text::lit("")) && (&n.case == &crate::syntax::lexer::NameCase::CaseUpper)) => (crate::syntax::QualName { path_: n.path_.clone(), span: here(p_) }, adv(p_)),
        _ => (crate::syntax::QualName { path_: Array::new(), span: no_range() }, error_here(p_, &Text::lit("expected an uppercase name"))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParseTraitRef: fn Ps -> ((TraitRef, Ps))
/// ```
pub fn parse_trait_ref(p_: &Ps) -> (crate::syntax::TraitRef, Ps) {
    match kind(p_) {
        crate::syntax::lexer::TokKind::KTrait(path_) => {
            let span = here(p_);
            let q = if &path_ == &Array::from(vec![Text::lit("Monad")]) {
                out_of_scope(p_, &span, &Text::lit("`T monad:` blocks and `^Monad`"), &Text::lit("`^Monad` is out of this compiler"))
            } else {
                p_.clone()
            };
            (crate::syntax::TraitRef { path_: path_.clone(), span: span.clone() }, adv(&q))
        },
        _ => (crate::syntax::TraitRef { path_: Array::new(), span: no_range() }, error_here(p_, &Text::lit("expected a trait, `^Name`"))),
    }
}

/// ```prism
/// CheckNameScope: fn Ps, SName -> Ps
/// ```
pub fn check_name_scope(p_: &Ps, name: &crate::syntax::SName) -> Ps {
    let text_ = name_text(name);
    let feature = match &text_ {
        m17545_0 if (m17545_0 == &Text::lit("!Align")) => Text::lit("`!Align`"),
        m17545_1 if (m17545_1 == &Text::lit("@Collect")) => Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"),
        m17545_2 if (m17545_2 == &Text::lit("@View")) => Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"),
        m17545_3 if (m17545_3 == &Text::lit("@Edit")) => Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"),
        m17545_4 if (m17545_4 == &Text::lit("@Translate")) => Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"),
        m17545_5 if (m17545_5 == &Text::lit("Over")) => Text::lit("named lenses `&Home` and `Over`"),
        _ => Text::lit(""),
        _ => unreachable!("no arm matched"),
    };
    if &feature == &Text::lit("") {
        p_.clone()
    } else {
        out_of_scope(p_, &name.span, &feature, &Text::from(format!("`{}` is out of this compiler", &text_)))
    }
}

/// ```prism
/// CheckTypeNameScope: fn Ps, SName -> Ps
/// ```
pub fn check_type_name_scope(p_: &Ps, name: &crate::syntax::SName) -> Ps {
    let b = or(&crate::syntax::lexer::chars::last(&name.path_), &Text::lit(""));
    let sized = fold(&Array::from(vec![Text::lit("U16"), Text::lit("U32"), Text::lit("U64"), Text::lit("U128"), Text::lit("I8"), Text::lit("I16"), Text::lit("I32"), Text::lit("I64"), Text::lit("I128")]), &false, &(|seen: &bool, s: &Text| *seen || (s == &b)));
    if &len(&name.path_) != &Nat::from(1u32) {
        p_.clone()
    } else {
        if sized {
            out_of_scope(p_, &name.span, &Text::lit("sized ints other than `U8`"), &Text::from(format!("`{}` is out of this compiler: the sized integer it has is `U8`", &b)))
        } else {
            if &b == &Text::lit("Instant") {
                out_of_scope(p_, &name.span, &Text::lit("`Instant`"), &Text::lit("`Instant` is out of this compiler"))
            } else {
                p_.clone()
            }
        }
    }
}
