//! The module `Syntax.Parser`, from `target/bootstrap/src/prismc/syntax/parser/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod blocks;
pub mod decls;
pub mod expr;
pub mod test_language;
pub mod types;

/// `Pair`:
///
/// ```prism
/// type Pair = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Pair {
    pub partner_o: Option<Nat>,
    pub outer_p: bool,
    pub inner_p: bool,
}

impl Show for Pair {
    fn show(&self, p: &mut Printer) {
        p.record("Pair", &[("partner", &self.partner_o), ("outer", &self.outer_p), ("inner", &self.inner_p)]);
    }
}

impl ToPod for Pair {
    fn to_pod(&self) -> Pod {
        Pod::record("Pair", vec![("partner", self.partner_o.to_pod()), ("outer", self.outer_p.to_pod()), ("inner", self.inner_p.to_pod())])
    }
}

impl FromPod for Pair {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Pair { partner_o: FromPod::from_pod(field(p, "partner")?)?, outer_p: FromPod::from_pod(field(p, "outer")?)?, inner_p: FromPod::from_pod(field(p, "inner")?)? })
    }
}

/// `Parsed`:
///
/// ```prism
/// type Parsed = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Parsed {
    pub tree_p: crate::syntax::Module,
    pub diags_p: Array<crate::syntax::Diag>,
}

impl Show for Parsed {
    fn show(&self, p: &mut Printer) {
        p.record("Parsed", &[("tree", &self.tree_p), ("diags", &self.diags_p)]);
    }
}

impl ToPod for Parsed {
    fn to_pod(&self) -> Pod {
        Pod::record("Parsed", vec![("tree", self.tree_p.to_pod()), ("diags", self.diags_p.to_pod())])
    }
}

impl FromPod for Parsed {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Parsed { tree_p: FromPod::from_pod(field(p, "tree")?)?, diags_p: FromPod::from_pod(field(p, "diags")?)? })
    }
}

/// `Ps`:
///
/// ```prism
/// type Ps = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Ps {
    pub toks_p: Array<crate::syntax::lexer::Tok>,
    pub pairs_p: Array<Pair>,
    pub pos_p: Nat,
    pub diags_p: Array<crate::syntax::Diag>,
    pub out_p: Array<crate::syntax::Diag>,
    pub step_mode_p: bool,
    pub in_trait_p: bool,
    pub bad_p: bool,
}

impl Show for Ps {
    fn show(&self, p: &mut Printer) {
        p.record("Ps", &[("toks", &self.toks_p), ("pairs", &self.pairs_p), ("pos", &self.pos_p), ("diags", &self.diags_p), ("out", &self.out_p), ("stepMode", &self.step_mode_p), ("inTrait", &self.in_trait_p), ("bad", &self.bad_p)]);
    }
}

impl ToPod for Ps {
    fn to_pod(&self) -> Pod {
        Pod::record("Ps", vec![("toks", self.toks_p.to_pod()), ("pairs", self.pairs_p.to_pod()), ("pos", self.pos_p.to_pod()), ("diags", self.diags_p.to_pod()), ("out", self.out_p.to_pod()), ("stepMode", self.step_mode_p.to_pod()), ("inTrait", self.in_trait_p.to_pod()), ("bad", self.bad_p.to_pod())])
    }
}

impl FromPod for Ps {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Ps { toks_p: FromPod::from_pod(field(p, "toks")?)?, pairs_p: FromPod::from_pod(field(p, "pairs")?)?, pos_p: FromPod::from_pod(field(p, "pos")?)?, diags_p: FromPod::from_pod(field(p, "diags")?)?, out_p: FromPod::from_pod(field(p, "out")?)?, step_mode_p: FromPod::from_pod(field(p, "stepMode")?)?, in_trait_p: FromPod::from_pod(field(p, "inTrait")?)?, bad_p: FromPod::from_pod(field(p, "bad")?)? })
    }
}

/// ```prism
/// let noRange
/// ```
pub fn no_range_p() -> crate::syntax::Range {
    crate::syntax::Range { start_p: Nat::from(0u32), end_p: Nat::from(0u32) }
}

/// ```prism
/// let eofTok
/// ```
pub fn eof_tok_p() -> crate::syntax::lexer::Tok {
    crate::syntax::lexer::Tok { kind_p: crate::syntax::lexer::TokKind::KEof, span_p: no_range_p(), touches_p: false, line_start_p: false }
}

/// ```prism
/// let noPair
/// ```
pub fn no_pair_p() -> Pair {
    Pair { partner_o: None, outer_p: false, inner_p: false }
}

/// ```prism
/// ParseFile: unbounded fn Text -> Parsed
/// ```
pub fn parse_file_f(src_p0: &Text) -> Parsed {
    let lexed_p1 = crate::syntax::lexer::layout::lex_file_f(src_p0);
    let (m_p2, p_p3) = crate::syntax::parser::decls::parse_module_f(&new_ps_f(&lexed_p1.tokens_p), &false);
    Parsed { tree_p: m_p2.clone(), diags_p: finish_diags_f(&crate::prelude::append(&crate::prelude::append(&lexed_p1.diags_p, &p_p3.diags_p), &p_p3.out_p)) }
}

/// The step machine of `ParseFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseFile: unbounded fn Text -> Parsed
/// ```
pub struct ParseFile {
    pub src_p0: Text,
}

impl prism_rtl::Job<Parsed> for ParseFile {
    fn cycle(&self) -> prism_rtl::Turn<Parsed> {
        let src_p0 = &self.src_p0;
        let src_p0x = src_p0.clone();
        crate::prelude::call_then(crate::syntax::lexer::layout::start_lex_file_f(src_p0x.clone()), move |lex_file_f_3340: crate::syntax::lexer::Lexed| {
            let lexed_p1 = lex_file_f_3340;
            crate::prelude::call_then(start_new_ps_f(lexed_p1.tokens_p.clone()), move |new_ps_f_3384: Ps| crate::prelude::call_then(crate::syntax::parser::decls::start_parse_module_f(new_ps_f_3384, false), move |parse_module_f_3371: (crate::syntax::Module, Ps)| {
                let (m_p2, p_p3) = parse_module_f_3371;
                prism_rtl::Turn::Finished(Parsed { tree_p: m_p2.clone(), diags_p: finish_diags_f(&crate::prelude::append(&crate::prelude::append(&lexed_p1.diags_p, &p_p3.diags_p), &p_p3.out_p)) })
            }))
        })
    }
}

/// `Start ParseFile, x`: what the function value is when passed to `@Run`.
pub fn start_parse_file_f(src_p0: Text) -> Rc<dyn prism_rtl::Job<Parsed>> {
    Rc::new(ParseFile { src_p0 })
}

/// ```prism
/// ParseFragment: unbounded fn Text -> Parsed
/// ```
pub fn parse_fragment_f(src_p0: &Text) -> Parsed {
    let lexed_p1 = crate::syntax::lexer::layout::lex_file_f(src_p0);
    let (m_p2, p_p3) = crate::syntax::parser::decls::parse_module_f(&new_ps_f(&lexed_p1.tokens_p), &true);
    Parsed { tree_p: m_p2.clone(), diags_p: finish_diags_f(&crate::prelude::append(&crate::prelude::append(&lexed_p1.diags_p, &p_p3.diags_p), &p_p3.out_p)) }
}

/// The step machine of `ParseFragment`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseFragment: unbounded fn Text -> Parsed
/// ```
pub struct ParseFragment {
    pub src_p0: Text,
}

impl prism_rtl::Job<Parsed> for ParseFragment {
    fn cycle(&self) -> prism_rtl::Turn<Parsed> {
        let src_p0 = &self.src_p0;
        let src_p0x = src_p0.clone();
        crate::prelude::call_then(crate::syntax::lexer::layout::start_lex_file_f(src_p0x.clone()), move |lex_file_f_3733: crate::syntax::lexer::Lexed| {
            let lexed_p1 = lex_file_f_3733;
            crate::prelude::call_then(start_new_ps_f(lexed_p1.tokens_p.clone()), move |new_ps_f_3777: Ps| crate::prelude::call_then(crate::syntax::parser::decls::start_parse_module_f(new_ps_f_3777, true), move |parse_module_f_3764: (crate::syntax::Module, Ps)| {
                let (m_p2, p_p3) = parse_module_f_3764;
                prism_rtl::Turn::Finished(Parsed { tree_p: m_p2.clone(), diags_p: finish_diags_f(&crate::prelude::append(&crate::prelude::append(&lexed_p1.diags_p, &p_p3.diags_p), &p_p3.out_p)) })
            }))
        })
    }
}

/// `Start ParseFragment, x`: what the function value is when passed to `@Run`.
pub fn start_parse_fragment_f(src_p0: Text) -> Rc<dyn prism_rtl::Job<Parsed>> {
    Rc::new(ParseFragment { src_p0 })
}

/// ```prism
/// NewPs: unbounded fn [Tok] -> Ps
/// ```
pub fn new_ps_f(toks0_p0: &Array<crate::syntax::lexer::Tok>) -> Ps {
    let ends_p1 = match crate::syntax::lexer::chars::last_o(toks0_p0) {
        Some(t_p4) => &t_p4.kind_p == &crate::syntax::lexer::TokKind::KEof,
        None => false,
    };
    let end_p2 = match crate::syntax::lexer::chars::last_o(toks0_p0) {
        Some(t_p5) => crate::syntax::Range { start_p: t_p5.span_p.end_p.clone(), end_p: t_p5.span_p.end_p.clone() },
        None => no_range_p(),
    };
    let toks_p3 = if ends_p1 {
        toks0_p0.clone()
    } else {
        crate::prelude::push(toks0_p0, &crate::syntax::lexer::Tok { kind_p: crate::syntax::lexer::TokKind::KEof, span_p: end_p2.clone(), touches_p: false, line_start_p: false })
    };
    Ps { toks_p: toks_p3.clone(), pairs_p: pair_brackets_f(&toks_p3), pos_p: Nat::from(0u32), diags_p: Array::new(), out_p: Array::new(), step_mode_p: false, in_trait_p: false, bad_p: false }
}

/// The step machine of `NewPs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NewPs: unbounded fn [Tok] -> Ps
/// ```
pub struct NewPs {
    pub toks0_p0: Array<crate::syntax::lexer::Tok>,
}

impl prism_rtl::Job<Ps> for NewPs {
    fn cycle(&self) -> prism_rtl::Turn<Ps> {
        let toks0_p0 = &self.toks0_p0;
        let ends_p1 = match crate::syntax::lexer::chars::last_o(toks0_p0) {
            Some(t_p4) => &t_p4.kind_p == &crate::syntax::lexer::TokKind::KEof,
            None => false,
        };
        let end_p2 = match crate::syntax::lexer::chars::last_o(toks0_p0) {
            Some(t_p5) => crate::syntax::Range { start_p: t_p5.span_p.end_p.clone(), end_p: t_p5.span_p.end_p.clone() },
            None => no_range_p(),
        };
        let toks_p3 = if ends_p1 {
            toks0_p0.clone()
        } else {
            crate::prelude::push(toks0_p0, &crate::syntax::lexer::Tok { kind_p: crate::syntax::lexer::TokKind::KEof, span_p: end_p2.clone(), touches_p: false, line_start_p: false })
        };
        crate::prelude::call_then(start_pair_brackets_f(toks_p3.clone()), move |pair_brackets_f_4256: Array<Pair>| prism_rtl::Turn::Finished(Ps { toks_p: toks_p3.clone(), pairs_p: pair_brackets_f_4256, pos_p: Nat::from(0u32), diags_p: Array::new(), out_p: Array::new(), step_mode_p: false, in_trait_p: false, bad_p: false }))
    }
}

/// `Start NewPs, x`: what the function value is when passed to `@Run`.
pub fn start_new_ps_f(toks0_p0: Array<crate::syntax::lexer::Tok>) -> Rc<dyn prism_rtl::Job<Ps>> {
    Rc::new(NewPs { toks0_p0 })
}

/// ```prism
/// Sub: unbounded fn Ps, [Tok], Range -> Ps
/// ```
pub fn sub_f(p_p0: &Ps, toks_p1: &Array<crate::syntax::lexer::Tok>, end_p2: &crate::syntax::Range) -> Ps {
    let q_p3 = new_ps_f(&crate::prelude::push(toks_p1, &crate::syntax::lexer::Tok { kind_p: crate::syntax::lexer::TokKind::KEof, span_p: end_p2.clone(), touches_p: false, line_start_p: false }));
    let mut this: Ps = q_p3.clone();
    this.step_mode_p = p_p0.step_mode_p;
    this
}

/// The step machine of `Sub`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Sub: unbounded fn Ps, [Tok], Range -> Ps
/// ```
pub struct Sub {
    pub p_p0: Ps,
    pub toks_p1: Array<crate::syntax::lexer::Tok>,
    pub end_p2: crate::syntax::Range,
}

impl prism_rtl::Job<Ps> for Sub {
    fn cycle(&self) -> prism_rtl::Turn<Ps> {
        let p_p0 = &self.p_p0;
        let toks_p1 = &self.toks_p1;
        let end_p2 = &self.end_p2;
        let end_p2x = end_p2.clone();
        let p_p0x = p_p0.clone();
        let toks_p1x = toks_p1.clone();
        crate::prelude::call_then(start_new_ps_f(crate::prelude::push(&toks_p1x, &crate::syntax::lexer::Tok { kind_p: crate::syntax::lexer::TokKind::KEof, span_p: end_p2x.clone(), touches_p: false, line_start_p: false })), move |new_ps_f_4565: Ps| {
            let q_p3 = new_ps_f_4565;
            prism_rtl::Turn::Finished({
                let mut this: Ps = q_p3.clone();
                this.step_mode_p = p_p0x.step_mode_p;
                this
            })
        })
    }
}

/// `Start Sub, x`: what the function value is when passed to `@Run`.
pub fn start_sub_f(p_p0: Ps, toks_p1: Array<crate::syntax::lexer::Tok>, end_p2: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<Ps>> {
    Rc::new(Sub { p_p0, toks_p1, end_p2 })
}

/// ```prism
/// Absorb: fn Ps, Ps -> Ps
/// ```
pub fn absorb_f(p_p0: &Ps, sub_p1: &Ps) -> Ps {
    let mut this: Ps = p_p0.clone();
    this.diags_p = crate::prelude::append(&this.diags_p, &sub_p1.diags_p);
    this.out_p = crate::prelude::append(&this.out_p, &sub_p1.out_p);
    this
}

/// ```prism
/// FinishDiags: fn [Diag] -> [Diag]
/// ```
pub fn finish_diags_f(ds_p0: &Array<crate::syntax::Diag>) -> Array<crate::syntax::Diag> {
    let sorted_p1 = crate::prelude::fold(ds_p0, &Array::new(), &insert_diag_f);
    crate::prelude::fold(&sorted_p1, &Array::new(), &(|acc_p2: &Array<crate::syntax::Diag>, d_p3: &crate::syntax::Diag| match crate::syntax::lexer::chars::last_o(acc_p2) {
        Some(e_p4) if ((&e_p4.span_p == &d_p3.span_p) && (&e_p4.message_p == &d_p3.message_p)) => acc_p2.clone(),
        _ => crate::prelude::push(acc_p2, d_p3),
        _ => unreachable!("no arm matched"),
    }))
}

/// ```prism
/// StageRank: fn Text -> Nat
/// ```
pub fn stage_rank_f(text0: &Text) -> Nat {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("lex")) => Nat::from(0u32),
        c1_0 if (c1_0 == &Text::lit("parse")) => Nat::from(1u32),
        _ => Nat::from(2u32),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// DiagBefore: fn Diag, Diag -> Bool
/// ```
pub fn diag_before_f(a_p0: &crate::syntax::Diag, b_p1: &crate::syntax::Diag) -> bool {
    (&a_p0.span_p.start_p < &b_p1.span_p.start_p) || ((&a_p0.span_p.start_p == &b_p1.span_p.start_p) && (&stage_rank_f(&a_p0.stage_p) < &stage_rank_f(&b_p1.stage_p)))
}

/// ```prism
/// InsertDiag: fn [Diag], Diag -> [Diag]
/// ```
pub fn insert_diag_f(sorted_p0: &Array<crate::syntax::Diag>, d_p1: &crate::syntax::Diag) -> Array<crate::syntax::Diag> {
    let before_p2 = crate::prelude::fold(sorted_p0, &Array::new(), &(|acc_p4: &Array<crate::syntax::Diag>, e_p5: &crate::syntax::Diag| if diag_before_f(d_p1, e_p5) {
        acc_p4.clone()
    } else {
        crate::prelude::push(acc_p4, e_p5)
    }));
    let after_p3 = crate::prelude::fold(sorted_p0, &Array::new(), &(|acc_p6: &Array<crate::syntax::Diag>, e_p7: &crate::syntax::Diag| if diag_before_f(d_p1, e_p7) {
        crate::prelude::push(acc_p6, e_p7)
    } else {
        acc_p6.clone()
    }));
    crate::prelude::append(&crate::prelude::push(&before_p2, d_p1), &after_p3)
}

/// ```prism
/// PairBrackets: unbounded fn [Tok] -> [Pair]
/// ```
pub fn pair_brackets_f(toks_p0: &Array<crate::syntax::lexer::Tok>) -> Array<Pair> {
    let mut this: Array<Pair> = crate::prelude::each(toks_p0, &(|t_p1: &crate::syntax::lexer::Tok| no_pair_p()));
    let mut stack_p2: Array<(Nat, Text)> = Array::new();
    for (i6317, v6317) in toks_p0.clone().into_iter().enumerate() {
        let k6317 = crate::prelude::nat_of(i6317);
        let t_p3 = v6317.clone();
        if let Some(k_p4) = open_kind_of_o(&t_p3.kind_p) {
            stack_p2 = crate::prelude::push(&stack_p2, &(k6317.clone(), k_p4.clone()));
        }
        if let Some(k_p5) = close_kind_of_o(&t_p3.kind_p) {
            if let Some((j_p6, k2_p7)) = crate::syntax::lexer::chars::last_o(&stack_p2) {
                if &k2_p7 == &k_p5 {
                    stack_p2 = crate::syntax::lexer::chars::pop_f(&stack_p2);
                    (*at_mut(&mut this, &k6317)).partner_o = Some(j_p6.clone());
                    (*at_mut(&mut this, &j_p6)).partner_o = Some(k6317.clone());
                }
            }
        }
    }
    for (i6778, v6778) in toks_p0.clone().into_iter().enumerate() {
        let k6778 = crate::prelude::nat_of(i6778);
        let t_p8 = v6778.clone();
        let i_p9 = k6778.clone();
        if let Some(kind_pa) = open_kind_of_o(&t_p8.kind_p) {
            if (&kind_pa != &Text::lit("{")) && !crate::prelude::or(&crate::prelude::index(&this, &i_p9), &no_pair_p()).inner_p {
                if let Some(j_pb) = crate::prelude::or(&crate::prelude::index(&this, &i_p9), &no_pair_p()).partner_o.clone() {
                    if double_at_f(&this, toks_p0, &i_p9, &j_pb, &kind_pa) {
                        (*at_mut(&mut this, &i_p9)).outer_p = true;
                        (*at_mut(&mut this, &j_pb)).outer_p = true;
                        (*at_mut(&mut this, &(&i_p9 + &Nat::from(1u32)))).inner_p = true;
                        (*at_mut(&mut this, &crate::syntax::lexer::chars::dec_f(&j_pb))).inner_p = true;
                    }
                }
            }
        }
    }
    this
}

/// The step machine of `PairBrackets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PairBrackets: unbounded fn [Tok] -> [Pair]
/// ```
pub struct PairBrackets {
    pub toks_p0: Array<crate::syntax::lexer::Tok>,
}

impl prism_rtl::Job<Array<Pair>> for PairBrackets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Pair>> {
        let toks_p0 = &self.toks_p0;
        prism_rtl::Turn::Finished({
            let mut this: Array<Pair> = crate::prelude::each(toks_p0, &(|t_p1: &crate::syntax::lexer::Tok| no_pair_p()));
            let mut stack_p2: Array<(Nat, Text)> = Array::new();
            for (i6317, v6317) in toks_p0.clone().into_iter().enumerate() {
                let k6317 = crate::prelude::nat_of(i6317);
                let t_p3 = v6317.clone();
                if let Some(k_p4) = open_kind_of_o(&t_p3.kind_p) {
                    stack_p2 = crate::prelude::push(&stack_p2, &(k6317.clone(), k_p4.clone()));
                }
                if let Some(k_p5) = close_kind_of_o(&t_p3.kind_p) {
                    if let Some((j_p6, k2_p7)) = crate::syntax::lexer::chars::last_o(&stack_p2) {
                        if &k2_p7 == &k_p5 {
                            stack_p2 = crate::syntax::lexer::chars::pop_f(&stack_p2);
                            (*at_mut(&mut this, &k6317)).partner_o = Some(j_p6.clone());
                            (*at_mut(&mut this, &j_p6)).partner_o = Some(k6317.clone());
                        }
                    }
                }
            }
            for (i6778, v6778) in toks_p0.clone().into_iter().enumerate() {
                let k6778 = crate::prelude::nat_of(i6778);
                let t_p8 = v6778.clone();
                let i_p9 = k6778.clone();
                if let Some(kind_pa) = open_kind_of_o(&t_p8.kind_p) {
                    if (&kind_pa != &Text::lit("{")) && !crate::prelude::or(&crate::prelude::index(&this, &i_p9), &no_pair_p()).inner_p {
                        if let Some(j_pb) = crate::prelude::or(&crate::prelude::index(&this, &i_p9), &no_pair_p()).partner_o.clone() {
                            if double_at_f(&this, toks_p0, &i_p9, &j_pb, &kind_pa) {
                                (*at_mut(&mut this, &i_p9)).outer_p = true;
                                (*at_mut(&mut this, &j_pb)).outer_p = true;
                                (*at_mut(&mut this, &(&i_p9 + &Nat::from(1u32)))).inner_p = true;
                                (*at_mut(&mut this, &crate::syntax::lexer::chars::dec_f(&j_pb))).inner_p = true;
                            }
                        }
                    }
                }
            }
            this
        })
    }
}

/// `Start PairBrackets, x`: what the function value is when passed to `@Run`.
pub fn start_pair_brackets_f(toks_p0: Array<crate::syntax::lexer::Tok>) -> Rc<dyn prism_rtl::Job<Array<Pair>>> {
    Rc::new(PairBrackets { toks_p0 })
}

/// ```prism
/// DoubleAt: fn [Pair], [Tok], Nat, Nat, Text -> Bool
/// ```
pub fn double_at_f(pairs_p0: &Array<Pair>, toks_p1: &Array<crate::syntax::lexer::Tok>, i_p2: &Nat, j_p3: &Nat, kind_p4: &Text) -> bool {
    let next_p5 = crate::prelude::or(&crate::prelude::index(toks_p1, &(i_p2 + &Nat::from(1u32))), &eof_tok_p());
    let inner_close_o6 = crate::prelude::or(&crate::prelude::index(pairs_p0, &(i_p2 + &Nat::from(1u32))), &no_pair_p()).partner_o.clone();
    ((is_open_of_f(&next_p5.kind_p, kind_p4) && next_p5.touches_p) && (&inner_close_o6 == &Some(crate::syntax::lexer::chars::dec_f(j_p3)))) && crate::prelude::or(&crate::prelude::index(toks_p1, j_p3), &eof_tok_p()).touches_p
}

/// ```prism
/// ?OpenKindOf: fn TokKind -> ?Text
/// ```
pub fn open_kind_of_o(tok_kind0: &crate::syntax::lexer::TokKind) -> Option<Text> {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KOpen(k_p0, _) => Some(k_p0.clone()),
        _ => None,
    }
}

/// ```prism
/// ?CloseKindOf: fn TokKind -> ?Text
/// ```
pub fn close_kind_of_o(tok_kind0: &crate::syntax::lexer::TokKind) -> Option<Text> {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KClose(k_p0) => Some(k_p0.clone()),
        _ => None,
    }
}

/// ```prism
/// IsOpenOf: fn TokKind, Text -> Bool
/// ```
pub fn is_open_of_f(tok_kind0: &crate::syntax::lexer::TokKind, text1: &Text) -> bool {
    match (tok_kind0, text1) {
        (crate::syntax::lexer::TokKind::KOpen(k_p0, _), kind_p1) => k_p0 == kind_p1,
        (_, _) => false,
    }
}

/// ```prism
/// Tk: fn Ps -> Tok
/// ```
pub fn tk_f(p_p0: &Ps) -> crate::syntax::lexer::Tok {
    if p_p0.bad_p {
        eof_tok_p()
    } else {
        crate::prelude::or(&crate::prelude::index(&p_p0.toks_p, &crate::prelude::min(&p_p0.pos_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&p_p0.toks_p)))), &eof_tok_p())
    }
}

/// ```prism
/// TkAt: fn Ps, Nat -> Tok
/// ```
pub fn tk_at_f(p_p0: &Ps, n_p1: &Nat) -> crate::syntax::lexer::Tok {
    if p_p0.bad_p {
        eof_tok_p()
    } else {
        crate::prelude::or(&crate::prelude::index(&p_p0.toks_p, &crate::prelude::min(&(&p_p0.pos_p + n_p1), &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&p_p0.toks_p)))), &eof_tok_p())
    }
}

/// ```prism
/// Kind: fn Ps -> TokKind
/// ```
pub fn kind_f(p_p0: &Ps) -> crate::syntax::lexer::TokKind {
    tk_f(p_p0).kind_p.clone()
}

/// ```prism
/// KindAt: fn Ps, Nat -> TokKind
/// ```
pub fn kind_at_f(p_p0: &Ps, n_p1: &Nat) -> crate::syntax::lexer::TokKind {
    tk_at_f(p_p0, n_p1).kind_p.clone()
}

/// ```prism
/// Here: fn Ps -> Range
/// ```
pub fn here_f(p_p0: &Ps) -> crate::syntax::Range {
    tk_f(p_p0).span_p.clone()
}

/// ```prism
/// Prev: fn Ps -> Range
/// ```
pub fn prev_f(p_p0: &Ps) -> crate::syntax::Range {
    crate::prelude::or(&crate::prelude::index(&p_p0.toks_p, &crate::syntax::lexer::chars::dec_f(&p_p0.pos_p)), &eof_tok_p()).span_p.clone()
}

/// ```prism
/// To: fn Range, Range -> Range
/// ```
pub fn to_f(a_p0: &crate::syntax::Range, b_p1: &crate::syntax::Range) -> crate::syntax::Range {
    crate::syntax::Range { start_p: crate::prelude::min(&a_p0.start_p, &b_p1.start_p), end_p: crate::prelude::max(&a_p0.end_p, &b_p1.end_p) }
}

/// ```prism
/// AtEnd: fn Range -> Range
/// ```
pub fn at_end_f(r_p0: &crate::syntax::Range) -> crate::syntax::Range {
    crate::syntax::Range { start_p: r_p0.end_p.clone(), end_p: r_p0.end_p.clone() }
}

/// ```prism
/// Adv: fn Ps -> Ps
/// ```
pub fn adv_f(p_p0: &Ps) -> Ps {
    if p_p0.bad_p || (&(&p_p0.pos_p + &Nat::from(1u32)) >= &crate::prelude::len(&p_p0.toks_p)) {
        p_p0.clone()
    } else {
        {
            let mut this: Ps = p_p0.clone();
            this.pos_p = &this.pos_p + &Nat::from(1u32);
            this
        }
    }
}

/// ```prism
/// PairAt: fn Ps -> Pair
/// ```
pub fn pair_at_f(p_p0: &Ps) -> Pair {
    crate::prelude::or(&crate::prelude::index(&p_p0.pairs_p, &crate::prelude::min(&p_p0.pos_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&p_p0.pairs_p)))), &no_pair_p())
}

/// ```prism
/// AtEof: fn Ps -> Bool
/// ```
pub fn at_eof_f(p_p0: &Ps) -> bool {
    &kind_f(p_p0) == &crate::syntax::lexer::TokKind::KEof
}

/// ```prism
/// AtKw: fn Ps, Text -> Bool
/// ```
pub fn at_kw_f(p_p0: &Ps, w_p1: &Text) -> bool {
    &kind_f(p_p0) == &crate::syntax::lexer::TokKind::KKw(w_p1.clone(), Text::lit(""))
}

/// ```prism
/// AtOp: fn Ps, Text -> Bool
/// ```
pub fn at_op_f(p_p0: &Ps, op_p1: &Text) -> bool {
    match kind_f(p_p0) {
        crate::syntax::lexer::TokKind::KOp(o_p2, _) => &o_p2 == op_p1,
        _ => false,
    }
}

/// ```prism
/// AtSep: fn Ps -> Bool
/// ```
pub fn at_sep_f(p_p0: &Ps) -> bool {
    &kind_f(p_p0) == &crate::syntax::lexer::TokKind::KLaySep
}

/// ```prism
/// AtOpenL: fn Ps -> Bool
/// ```
pub fn at_open_l_f(p_p0: &Ps) -> bool {
    &kind_f(p_p0) == &crate::syntax::lexer::TokKind::KLayOpen
}

/// ```prism
/// AtCloseL: fn Ps -> Bool
/// ```
pub fn at_close_l_f(p_p0: &Ps) -> bool {
    &kind_f(p_p0) == &crate::syntax::lexer::TokKind::KLayClose
}

/// ```prism
/// AtComma: fn Ps -> Bool
/// ```
pub fn at_comma_f(p_p0: &Ps) -> bool {
    &kind_f(p_p0) == &crate::syntax::lexer::TokKind::KComma
}

/// ```prism
/// AtColon: fn Ps -> Bool
/// ```
pub fn at_colon_f(p_p0: &Ps) -> bool {
    &kind_f(p_p0) == &crate::syntax::lexer::TokKind::KColon
}

/// ```prism
/// IsOpenKind: fn TokKind, Text -> Bool
/// ```
pub fn is_open_kind_f(tok_kind0: &crate::syntax::lexer::TokKind, text1: &Text) -> bool {
    match (tok_kind0, text1) {
        (crate::syntax::lexer::TokKind::KOpen(k_p0, _), kind_p1) => k_p0 == kind_p1,
        (_, _) => false,
    }
}

/// ```prism
/// AtDoubleOpen: fn Ps, Text -> Bool
/// ```
pub fn at_double_open_f(p_p0: &Ps, kind_p1: &Text) -> bool {
    is_open_kind_f(&kind_f(p_p0), kind_p1) && pair_at_f(p_p0).outer_p
}

/// ```prism
/// AtSingleOpen: fn Ps, Text -> Bool
/// ```
pub fn at_single_open_f(p_p0: &Ps, kind_p1: &Text) -> bool {
    is_open_kind_f(&kind_f(p_p0), kind_p1) && !pair_at_f(p_p0).outer_p
}

/// ```prism
/// AtClose: fn Ps, Text -> Bool
/// ```
pub fn at_close_f(p_p0: &Ps, kind_p1: &Text) -> bool {
    &kind_f(p_p0) == &crate::syntax::lexer::TokKind::KClose(kind_p1.clone())
}

/// ```prism
/// OpenDouble: fn Ps -> Ps
/// ```
pub fn open_double_f(p_p0: &Ps) -> Ps {
    adv_f(&adv_f(p_p0))
}

/// ```prism
/// CloseDouble: fn Ps, Text -> Ps
/// ```
pub fn close_double_f(p_p0: &Ps, kind_p1: &Text) -> Ps {
    let c_p2 = crate::syntax::lexer::close_char_f(kind_p1);
    let p1_p3 = adv_f(p_p0);
    if ((at_close_f(p_p0, kind_p1) && pair_at_f(p_p0).inner_p) && at_close_f(&p1_p3, kind_p1)) && pair_at_f(&p1_p3).outer_p {
        adv_f(&p1_p3)
    } else {
        if at_close_f(p_p0, kind_p1) && pair_at_f(p_p0).inner_p {
            error_here_f(&p1_p3, &Text::from(format!("expected `{}{}` to close the double bracket", &c_p2, &c_p2)))
        } else {
            error_here_f(p_p0, &Text::from(format!("expected `{}{}` to close the double bracket", &c_p2, &c_p2)))
        }
    }
}

/// ```prism
/// ExpectClose: fn Ps, Text -> Ps
/// ```
pub fn expect_close_f(p_p0: &Ps, kind_p1: &Text) -> Ps {
    if at_close_f(p_p0, kind_p1) {
        adv_f(p_p0)
    } else {
        error_here_f(p_p0, &Text::from(format!("expected `{}`", &crate::syntax::lexer::close_char_f(kind_p1))))
    }
}

/// ```prism
/// ParseDiag: fn Range, Text -> Diag
/// ```
pub fn parse_diag_f(span_p0: &crate::syntax::Range, message_p1: &Text) -> crate::syntax::Diag {
    crate::syntax::Diag { stage_p: Text::lit("parse"), span_p: span_p0.clone(), message_p: message_p1.clone(), feature_o: None }
}

/// ```prism
/// ErrorAt: fn Ps, Range, Text -> Ps
/// ```
pub fn error_at_f(p_p0: &Ps, span_p1: &crate::syntax::Range, message_p2: &Text) -> Ps {
    if p_p0.bad_p {
        p_p0.clone()
    } else {
        {
            let mut this: Ps = p_p0.clone();
            this.diags_p = crate::prelude::push(&this.diags_p, &parse_diag_f(span_p1, message_p2));
            this.bad_p = true;
            this
        }
    }
}

/// ```prism
/// ErrorHere: fn Ps, Text -> Ps
/// ```
pub fn error_here_f(p_p0: &Ps, message_p1: &Text) -> Ps {
    error_at_f(p_p0, &here_f(p_p0), &Text::from(format!("{}, found {}", message_p1, &describe_f(&kind_f(p_p0)))))
}

/// ```prism
/// Fail: fn Ps -> Ps
/// ```
pub fn fail_f(p_p0: &Ps) -> Ps {
    let mut this: Ps = p_p0.clone();
    this.bad_p = true;
    this
}

/// ```prism
/// Unbad: fn Ps -> Ps
/// ```
pub fn unbad_f(p_p0: &Ps) -> Ps {
    let mut this: Ps = p_p0.clone();
    this.bad_p = false;
    this
}

/// ```prism
/// NoteError: fn Ps, Range, Text -> Ps
/// ```
pub fn note_error_f(p_p0: &Ps, span_p1: &crate::syntax::Range, message_p2: &Text) -> Ps {
    if p_p0.bad_p {
        p_p0.clone()
    } else {
        {
            let mut this: Ps = p_p0.clone();
            this.diags_p = crate::prelude::push(&this.diags_p, &parse_diag_f(span_p1, message_p2));
            this
        }
    }
}

/// ```prism
/// Complain: fn Ps, Text -> Ps
/// ```
pub fn complain_f(p_p0: &Ps, message_p1: &Text) -> Ps {
    unbad_f(&error_here_f(p_p0, message_p1))
}

/// ```prism
/// OutOfScope: fn Ps, Range, Text, Text -> Ps
/// ```
pub fn out_of_scope_f(p_p0: &Ps, span_p1: &crate::syntax::Range, feature_p2: &Text, message_p3: &Text) -> Ps {
    if p_p0.bad_p {
        p_p0.clone()
    } else {
        {
            let mut this: Ps = p_p0.clone();
            this.out_p = crate::prelude::push(&this.out_p, &crate::syntax::Diag { stage_p: Text::lit("out"), span_p: span_p1.clone(), message_p: message_p3.clone(), feature_o: Some(feature_p2.clone()) });
            this
        }
    }
}

/// ```prism
/// ExpectColon: fn Ps -> Ps
/// ```
pub fn expect_colon_f(p_p0: &Ps) -> Ps {
    if at_colon_f(p_p0) {
        adv_f(p_p0)
    } else {
        error_here_f(p_p0, &Text::lit("expected `:`"))
    }
}

/// ```prism
/// ExpectOp: fn Ps, Text -> Ps
/// ```
pub fn expect_op_f(p_p0: &Ps, op_p1: &Text) -> Ps {
    if at_op_f(p_p0, op_p1) {
        adv_f(p_p0)
    } else {
        error_here_f(p_p0, &Text::from(format!("expected `{}`", op_p1)))
    }
}

/// ```prism
/// ExpectKw: fn Ps, Text -> Ps
/// ```
pub fn expect_kw_f(p_p0: &Ps, w_p1: &Text) -> Ps {
    if at_kw_f(p_p0, w_p1) {
        adv_f(p_p0)
    } else {
        error_here_f(p_p0, &Text::from(format!("expected `{}`", w_p1)))
    }
}

/// ```prism
/// Recover: unbounded fn Ps -> Ps
/// ```
pub fn recover_f(p0_p0: &Ps) -> Ps {
    let mut this: Ps = unbad_f(p0_p0);
    let mut depth_p1: Nat = Nat::from(0u32);
    let mut going_p2: bool = true;
    while going_p2 {
        match &kind_f(&this) {
            crate::syntax::lexer::TokKind::KEof => {
                going_p2 = false;
                ()
            },
            crate::syntax::lexer::TokKind::KLayOpen => {
                depth_p1 = &depth_p1 + &Nat::from(1u32);
                this = adv_f(&this);
                ()
            },
            crate::syntax::lexer::TokKind::KLayClose => {
                if &depth_p1 == &Nat::from(0u32) {
                    going_p2 = false;
                } else {
                    depth_p1 = crate::syntax::lexer::chars::dec_f(&depth_p1);
                    this = adv_f(&this);
                }
                ()
            },
            crate::syntax::lexer::TokKind::KLaySep if (&depth_p1 == &Nat::from(0u32)) => {
                going_p2 = false;
                ()
            },
            _ => {
                this = adv_f(&this);
                ()
            },
            _ => unreachable!("no arm matched"),
        };
    }
    this
}

/// The step machine of `Recover`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Recover: unbounded fn Ps -> Ps
/// ```
pub struct Recover {
    pub p0_p0: Ps,
}

impl prism_rtl::Job<Ps> for Recover {
    fn cycle(&self) -> prism_rtl::Turn<Ps> {
        let p0_p0 = &self.p0_p0;
        let mut this: Ps = unbad_f(p0_p0);
        let mut depth_p1: Nat = Nat::from(0u32);
        let mut going_p2: bool = true;
        crate::prelude::call_then(crate::prelude::loop_job((this, depth_p1, going_p2), move |(mut this, mut depth_p1, mut going_p2): (Ps, Nat, bool)| if going_p2 {
            {
                match &kind_f(&this) {
                    crate::syntax::lexer::TokKind::KEof => {
                        going_p2 = false;
                        ()
                    },
                    crate::syntax::lexer::TokKind::KLayOpen => {
                        depth_p1 = &depth_p1 + &Nat::from(1u32);
                        this = adv_f(&this);
                        ()
                    },
                    crate::syntax::lexer::TokKind::KLayClose => {
                        if &depth_p1 == &Nat::from(0u32) {
                            going_p2 = false;
                        } else {
                            depth_p1 = crate::syntax::lexer::chars::dec_f(&depth_p1);
                            this = adv_f(&this);
                        }
                        ()
                    },
                    crate::syntax::lexer::TokKind::KLaySep if (&depth_p1 == &Nat::from(0u32)) => {
                        going_p2 = false;
                        ()
                    },
                    _ => {
                        this = adv_f(&this);
                        ()
                    },
                    _ => unreachable!("no arm matched"),
                };
                Ok((this, depth_p1, going_p2))
            }
        } else {
            Err((this, depth_p1, going_p2))
        }), move |(mut this, mut depth_p1, mut going_p2): (Ps, Nat, bool)| prism_rtl::Turn::Finished(this))
    }
}

/// `Start Recover, x`: what the function value is when passed to `@Run`.
pub fn start_recover_f(p0_p0: Ps) -> Rc<dyn prism_rtl::Job<Ps>> {
    Rc::new(Recover { p0_p0 })
}

/// ```prism
/// Recovered: unbounded fn Ps -> Ps
/// ```
pub fn recovered_f(p_p0: &Ps) -> Ps {
    if p_p0.bad_p { recover_f(p_p0) } else { p_p0.clone() }
}

/// The step machine of `Recovered`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Recovered: unbounded fn Ps -> Ps
/// ```
pub struct Recovered {
    pub p_p0: Ps,
}

impl prism_rtl::Job<Ps> for Recovered {
    fn cycle(&self) -> prism_rtl::Turn<Ps> {
        let p_p0 = &self.p_p0;
        if p_p0.bad_p {
            prism_rtl::Turn::More(Rc::new(Recover { p0_p0: p_p0.clone() }))
        } else {
            prism_rtl::Turn::Finished(p_p0.clone())
        }
    }
}

/// `Start Recovered, x`: what the function value is when passed to `@Run`.
pub fn start_recovered_f(p_p0: Ps) -> Rc<dyn prism_rtl::Job<Ps>> {
    Rc::new(Recovered { p_p0 })
}

/// ```prism
/// AtStmtBoundary: fn Ps -> Bool
/// ```
pub fn at_stmt_boundary_f(p_p0: &Ps) -> bool {
    match kind_f(p_p0) {
        crate::syntax::lexer::TokKind::KLaySep => true,
        crate::syntax::lexer::TokKind::KLayClose => true,
        crate::syntax::lexer::TokKind::KEof => true,
        _ => false,
    }
}

/// ```prism
/// ExpectStmtEnd: unbounded fn Ps, Text -> Ps
/// ```
pub fn expect_stmt_end_f(p_p0: &Ps, what_p1: &Text) -> Ps {
    if at_stmt_boundary_f(p_p0) {
        p_p0.clone()
    } else {
        recover_f(&note_error_f(p_p0, &here_f(p_p0), &Text::from(format!("expected the end of the {}, found {}", what_p1, &describe_f(&kind_f(p_p0))))))
    }
}

/// The step machine of `ExpectStmtEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExpectStmtEnd: unbounded fn Ps, Text -> Ps
/// ```
pub struct ExpectStmtEnd {
    pub p_p0: Ps,
    pub what_p1: Text,
}

impl prism_rtl::Job<Ps> for ExpectStmtEnd {
    fn cycle(&self) -> prism_rtl::Turn<Ps> {
        let p_p0 = &self.p_p0;
        let what_p1 = &self.what_p1;
        if at_stmt_boundary_f(p_p0) {
            prism_rtl::Turn::Finished(p_p0.clone())
        } else {
            prism_rtl::Turn::More(Rc::new(Recover { p0_p0: note_error_f(p_p0, &here_f(p_p0), &Text::from(format!("expected the end of the {}, found {}", what_p1, &describe_f(&kind_f(p_p0))))) }))
        }
    }
}

/// `Start ExpectStmtEnd, x`: what the function value is when passed to `@Run`.
pub fn start_expect_stmt_end_f(p_p0: Ps, what_p1: Text) -> Rc<dyn prism_rtl::Job<Ps>> {
    Rc::new(ExpectStmtEnd { p_p0, what_p1 })
}

/// ```prism
/// Describe: fn TokKind -> Text
/// ```
pub fn describe_f(tok_kind0: &crate::syntax::lexer::TokKind) -> Text {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KLayOpen => Text::lit("an indented block"),
        crate::syntax::lexer::TokKind::KLaySep => Text::lit("the end of the line"),
        crate::syntax::lexer::TokKind::KLayClose => Text::lit("the end of the block"),
        crate::syntax::lexer::TokKind::KEof => Text::lit("the end of the input"),
        crate::syntax::lexer::TokKind::KText(_, _) => Text::lit("a text literal"),
        crate::syntax::lexer::TokKind::KRegex(_, _) => Text::lit("a regular expression"),
        crate::syntax::lexer::TokKind::KTemplate(_) => Text::lit("a template"),
        k_p0 => Text::from(format!("`{}`", &crate::syntax::lexer::corpus::token_text_f(k_p0))),
    }
}

/// ```prism
/// Bracketed: fn Ps, (fn Ps -> ((a, Ps))) -> ((a, Ps))
/// ```
pub fn bracketed_f<A: Clone + 'static>(p_p0: &Ps, f_f1: &Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>) -> (A, Ps) {
    let (v_p2, q_p3) = crate::prelude::run_to_end(f_f1(with_step_mode_f(p_p0, &false)));
    (v_p2.clone(), with_step_mode_f(&q_p3, &p_p0.step_mode_p))
}

/// The step machine of `Bracketed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Bracketed: fn Ps, (fn Ps -> ((a, Ps))) -> ((a, Ps))
/// ```
pub struct Bracketed<A> {
    pub p_p0: Ps,
    pub f_f1: Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>,
}

impl<A: Clone + 'static> prism_rtl::Job<(A, Ps)> for Bracketed<A> {
    fn cycle(&self) -> prism_rtl::Turn<(A, Ps)> {
        let p_p0 = &self.p_p0;
        let f_f1 = &self.f_f1;
        let f_f1x = f_f1.clone();
        let p_p0x = p_p0.clone();
        crate::prelude::call_value((&f_f1x)(with_step_mode_f(&p_p0x, &false)), move |f_14196: (A, Ps)| {
            let (v_p2, q_p3) = f_14196;
            prism_rtl::Turn::Finished((v_p2.clone(), with_step_mode_f(&q_p3, &p_p0x.step_mode_p)))
        })
    }
}

/// `Start Bracketed, x`: what the function value is when passed to `@Run`.
pub fn start_bracketed_f<A: Clone + 'static>(p_p0: Ps, f_f1: Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>) -> Rc<dyn prism_rtl::Job<(A, Ps)>> {
    Rc::new(Bracketed { p_p0, f_f1 })
}

/// ```prism
/// WithStepMode: fn Ps, Bool -> Ps
/// ```
pub fn with_step_mode_f(p_p0: &Ps, flag_p1: &bool) -> Ps {
    let mut this: Ps = p_p0.clone();
    this.step_mode_p = *flag_p1;
    this
}

/// ```prism
/// LayoutItems: unbounded fn Ps, (fn Ps -> ((a, Ps))) -> (([a], Ps))
/// ```
pub fn layout_items_f<A: Clone + 'static>(p0_p0: &Ps, f_f1: &Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>) -> (Array<A>, Ps) {
    let mut this: (Array<A>, Ps) = (Array::new(), p0_p0.clone());
    let mut items_p2: Array<A> = Array::new();
    let mut p_p3: Ps = p0_p0.clone();
    let mut going_p4: bool = true;
    while going_p4 {
        let (item_p5, q_p6) = crate::prelude::run_to_end(f_f1(p_p3.clone()));
        if !q_p6.bad_p {
            items_p2 = crate::prelude::push(&items_p2, &item_p5);
        }
        p_p3 = recovered_f(&q_p6);
        match &kind_f(&p_p3) {
            crate::syntax::lexer::TokKind::KLaySep => {
                p_p3 = adv_f(&p_p3);
            }
            crate::syntax::lexer::TokKind::KLayClose => {
                p_p3 = adv_f(&p_p3);
                going_p4 = false;
            }
            crate::syntax::lexer::TokKind::KEof => {
                going_p4 = false;
            }
            _ => {
                p_p3 = recover_f(&complain_f(&p_p3, &Text::lit("expected the end of the line")));
            }
        }
    }
    this = (items_p2.clone(), p_p3.clone());
    this
}

/// The step machine of `LayoutItems`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LayoutItems: unbounded fn Ps, (fn Ps -> ((a, Ps))) -> (([a], Ps))
/// ```
pub struct LayoutItems<A> {
    pub p0_p0: Ps,
    pub f_f1: Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>,
}

impl<A: Clone + 'static> prism_rtl::Job<(Array<A>, Ps)> for LayoutItems<A> {
    fn cycle(&self) -> prism_rtl::Turn<(Array<A>, Ps)> {
        let p0_p0 = &self.p0_p0;
        let f_f1 = &self.f_f1;
        let mut this: (Array<A>, Ps) = (Array::new(), p0_p0.clone());
        let mut items_p2: Array<A> = Array::new();
        let mut p_p3: Ps = p0_p0.clone();
        let mut going_p4: bool = true;
        let f_f1z = f_f1.clone();
        crate::prelude::call_then(crate::prelude::loop_job((this, going_p4, items_p2, p_p3), {
            let f_f1x = f_f1.clone();
            move |(mut this, mut going_p4, mut items_p2, mut p_p3): ((Array<A>, Ps), bool, Array<A>, Ps)| if going_p4 {
                {
                    let (item_p5, q_p6) = crate::prelude::run_to_end((&f_f1x)(p_p3.clone()));
                    if !q_p6.bad_p {
                        items_p2 = crate::prelude::push(&items_p2, &item_p5);
                    }
                    p_p3 = recovered_f(&q_p6);
                    match &kind_f(&p_p3) {
                        crate::syntax::lexer::TokKind::KLaySep => {
                            p_p3 = adv_f(&p_p3);
                        }
                        crate::syntax::lexer::TokKind::KLayClose => {
                            p_p3 = adv_f(&p_p3);
                            going_p4 = false;
                        }
                        crate::syntax::lexer::TokKind::KEof => {
                            going_p4 = false;
                        }
                        _ => {
                            p_p3 = recover_f(&complain_f(&p_p3, &Text::lit("expected the end of the line")));
                        }
                    }
                    Ok((this, going_p4, items_p2, p_p3))
                }
            } else {
                Err((this, going_p4, items_p2, p_p3))
            }
        }), move |(mut this, mut going_p4, mut items_p2, mut p_p3): ((Array<A>, Ps), bool, Array<A>, Ps)| {
            this = (items_p2.clone(), p_p3.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start LayoutItems, x`: what the function value is when passed to `@Run`.
pub fn start_layout_items_f<A: Clone + 'static>(p0_p0: Ps, f_f1: Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>) -> Rc<dyn prism_rtl::Job<(Array<A>, Ps)>> {
    Rc::new(LayoutItems { p0_p0, f_f1 })
}

/// ```prism
/// Commas: unbounded fn Ps, (fn Ps -> ((a, Ps))) -> (([a], Ps))
/// ```
pub fn commas_f<A: Clone + 'static>(p0_p0: &Ps, f_f1: &Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>) -> (Array<A>, Ps) {
    let mut this: (Array<A>, Ps) = (Array::new(), p0_p0.clone());
    let (first_p2, p1_p3) = crate::prelude::run_to_end(f_f1(p0_p0.clone()));
    let mut items_p4: Array<A> = Array::from(vec![first_p2.clone()]);
    let mut p_p5: Ps = p1_p3.clone();
    while at_comma_f(&p_p5) && !p_p5.bad_p {
        let (item_p6, q_p7) = crate::prelude::run_to_end(f_f1(adv_f(&p_p5)));
        items_p4 = crate::prelude::push(&items_p4, &item_p6);
        p_p5 = q_p7.clone();
    }
    this = (items_p4.clone(), p_p5.clone());
    this
}

/// The step machine of `Commas`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Commas: unbounded fn Ps, (fn Ps -> ((a, Ps))) -> (([a], Ps))
/// ```
pub struct Commas<A> {
    pub p0_p0: Ps,
    pub f_f1: Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>,
}

impl<A: Clone + 'static> prism_rtl::Job<(Array<A>, Ps)> for Commas<A> {
    fn cycle(&self) -> prism_rtl::Turn<(Array<A>, Ps)> {
        let p0_p0 = &self.p0_p0;
        let f_f1 = &self.f_f1;
        let mut this: (Array<A>, Ps) = (Array::new(), p0_p0.clone());
        let (first_p2, p1_p3) = crate::prelude::run_to_end(f_f1(p0_p0.clone()));
        let mut items_p4: Array<A> = Array::from(vec![first_p2.clone()]);
        let mut p_p5: Ps = p1_p3.clone();
        crate::prelude::call_then(crate::prelude::loop_job((this, items_p4, p_p5), {
            let f_f1x = f_f1.clone();
            move |(mut this, mut items_p4, mut p_p5): ((Array<A>, Ps), Array<A>, Ps)| if at_comma_f(&p_p5) && !p_p5.bad_p {
                {
                    let (item_p6, q_p7) = crate::prelude::run_to_end((&f_f1x)(adv_f(&p_p5)));
                    items_p4 = crate::prelude::push(&items_p4, &item_p6);
                    p_p5 = q_p7.clone();
                    Ok((this, items_p4, p_p5))
                }
            } else {
                Err((this, items_p4, p_p5))
            }
        }), move |(mut this, mut items_p4, mut p_p5): ((Array<A>, Ps), Array<A>, Ps)| {
            this = (items_p4.clone(), p_p5.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start Commas, x`: what the function value is when passed to `@Run`.
pub fn start_commas_f<A: Clone + 'static>(p0_p0: Ps, f_f1: Rc<dyn Fn(Ps) -> Rc<dyn prism_rtl::Job<(A, Ps)>>>) -> Rc<dyn prism_rtl::Job<(Array<A>, Ps)>> {
    Rc::new(Commas { p0_p0, f_f1 })
}

/// ```prism
/// let noSName
/// ```
pub fn no_sname_p() -> crate::syntax::SName {
    crate::syntax::SName { sigils_p: Text::lit(""), path_p: Array::new(), span_p: no_range_p() }
}

/// ```prism
/// let noIdent
/// ```
pub fn no_ident_p() -> crate::syntax::Ident {
    crate::syntax::Ident { name_p: Text::lit(""), span_p: no_range_p() }
}

/// ```prism
/// IsUpperName: fn SName -> Bool
/// ```
pub fn is_upper_name_f(n_p0: &crate::syntax::SName) -> bool {
    crate::syntax::lexer::chars::is_upper_f(&crate::syntax::lexer::chars::head_f(&crate::prelude::or(&crate::syntax::lexer::chars::last_o(&n_p0.path_p), &Text::lit(""))))
}

/// ```prism
/// IsCallee: fn SName -> Bool
/// ```
pub fn is_callee_f(n_p0: &crate::syntax::SName) -> bool {
    is_upper_name_f(n_p0) || crate::syntax::lexer::chars::is_reserved_ctor_f(&crate::prelude::or(&crate::syntax::lexer::chars::last_o(&n_p0.path_p), &Text::lit("")))
}

/// ```prism
/// IsTopic: fn SName -> Bool
/// ```
pub fn is_topic_f(n_p0: &crate::syntax::SName) -> bool {
    &n_p0.path_p == &Array::from(vec![Text::lit("_")])
}

/// ```prism
/// NameText: fn SName -> Text
/// ```
pub fn name_text_f(n_p0: &crate::syntax::SName) -> Text {
    Text::from(format!("{}{}", &n_p0.sigils_p, &crate::syntax::lexer::chars::join_f(&n_p0.path_p, &Text::lit("."))))
}

/// ```prism
/// ParseSName: fn Ps -> ((SName, Ps))
/// ```
pub fn parse_sname_f(p_p0: &Ps) -> (crate::syntax::SName, Ps) {
    match kind_f(p_p0) {
        crate::syntax::lexer::TokKind::KName(n_p1) => (crate::syntax::SName { sigils_p: n_p1.sigils_p.clone(), path_p: n_p1.path_p.clone(), span_p: here_f(p_p0) }, adv_f(p_p0)),
        _ => (no_sname_p(), error_here_f(p_p0, &Text::lit("expected a name"))),
    }
}

/// ```prism
/// ParseIdent: fn Ps -> ((Ident, Ps))
/// ```
pub fn parse_ident_f(p_p0: &Ps) -> (crate::syntax::Ident, Ps) {
    match kind_f(p_p0) {
        crate::syntax::lexer::TokKind::KName(n_p1) if (((&n_p1.sigils_p == &Text::lit("")) && (&crate::prelude::len(&n_p1.path_p) == &Nat::from(1u32))) && (&n_p1.case_p == &crate::syntax::lexer::NameCase::CaseLower)) => (crate::syntax::Ident { name_p: crate::prelude::or(&crate::prelude::index(&n_p1.path_p, &Nat::from(0u32)), &Text::lit("")), span_p: here_f(p_p0) }, adv_f(p_p0)),
        crate::syntax::lexer::TokKind::KKw(m16396_1_0, m16396_1_1) if (&m16396_1_0 == &Text::lit("key")) && (&m16396_1_1 == &Text::lit("")) => (crate::syntax::Ident { name_p: Text::lit("key"), span_p: here_f(p_p0) }, adv_f(p_p0)),
        _ => (no_ident_p(), error_here_f(p_p0, &Text::lit("expected a lowercase name"))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParseQualName: fn Ps -> ((QualName, Ps))
/// ```
pub fn parse_qual_name_f(p_p0: &Ps) -> (crate::syntax::QualName, Ps) {
    match kind_f(p_p0) {
        crate::syntax::lexer::TokKind::KName(n_p1) if ((&n_p1.sigils_p == &Text::lit("")) && (&n_p1.case_p == &crate::syntax::lexer::NameCase::CaseUpper)) => (crate::syntax::QualName { path_p: n_p1.path_p.clone(), span_p: here_f(p_p0) }, adv_f(p_p0)),
        _ => (crate::syntax::QualName { path_p: Array::new(), span_p: no_range_p() }, error_here_f(p_p0, &Text::lit("expected an uppercase name"))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParseTraitRef: fn Ps -> ((TraitRef, Ps))
/// ```
pub fn parse_trait_ref_f(p_p0: &Ps) -> (crate::syntax::TraitRef, Ps) {
    match kind_f(p_p0) {
        crate::syntax::lexer::TokKind::KTrait(path_p1) => {
            let span_p2 = here_f(p_p0);
            let q_p3 = if &path_p1 == &Array::from(vec![Text::lit("Monad")]) {
                out_of_scope_f(p_p0, &span_p2, &Text::lit("`T monad:` blocks and `^Monad`"), &Text::lit("`^Monad` is out of this compiler"))
            } else {
                p_p0.clone()
            };
            (crate::syntax::TraitRef { path_p: path_p1.clone(), span_p: span_p2.clone() }, adv_f(&q_p3))
        },
        _ => (crate::syntax::TraitRef { path_p: Array::new(), span_p: no_range_p() }, error_here_f(p_p0, &Text::lit("expected a trait, `^Name`"))),
    }
}

/// ```prism
/// CheckNameScope: fn Ps, SName -> Ps
/// ```
pub fn check_name_scope_f(p_p0: &Ps, name_p1: &crate::syntax::SName) -> Ps {
    let text_p2 = name_text_f(name_p1);
    let feature_p3 = match &text_p2 {
        m17559_0 if (m17559_0 == &Text::lit("!Align")) => Text::lit("`!Align`"),
        m17559_1 if (m17559_1 == &Text::lit("@Collect")) => Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"),
        m17559_2 if (m17559_2 == &Text::lit("@View")) => Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"),
        m17559_3 if (m17559_3 == &Text::lit("@Edit")) => Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"),
        m17559_4 if (m17559_4 == &Text::lit("@Translate")) => Text::lit("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"),
        m17559_5 if (m17559_5 == &Text::lit("Over")) => Text::lit("named lenses `&Home` and `Over`"),
        _ => Text::lit(""),
        _ => unreachable!("no arm matched"),
    };
    if &feature_p3 == &Text::lit("") {
        p_p0.clone()
    } else {
        out_of_scope_f(p_p0, &name_p1.span_p, &feature_p3, &Text::from(format!("`{}` is out of this compiler", &text_p2)))
    }
}

/// ```prism
/// CheckTypeNameScope: fn Ps, SName -> Ps
/// ```
pub fn check_type_name_scope_f(p_p0: &Ps, name_p1: &crate::syntax::SName) -> Ps {
    let b_p2 = crate::prelude::or(&crate::syntax::lexer::chars::last_o(&name_p1.path_p), &Text::lit(""));
    let sized_p3 = crate::prelude::fold(&Array::from(vec![Text::lit("U16"), Text::lit("U32"), Text::lit("U64"), Text::lit("U128"), Text::lit("I8"), Text::lit("I16"), Text::lit("I32"), Text::lit("I64"), Text::lit("I128")]), &false, &(|seen_p4: &bool, s_p5: &Text| *seen_p4 || (s_p5 == &b_p2)));
    if &crate::prelude::len(&name_p1.path_p) != &Nat::from(1u32) {
        p_p0.clone()
    } else {
        if sized_p3 {
            out_of_scope_f(p_p0, &name_p1.span_p, &Text::lit("sized ints other than `U8`"), &Text::from(format!("`{}` is out of this compiler: the sized integer it has is `U8`", &b_p2)))
        } else {
            if &b_p2 == &Text::lit("Instant") {
                out_of_scope_f(p_p0, &name_p1.span_p, &Text::lit("`Instant`"), &Text::lit("`Instant` is out of this compiler"))
            } else {
                p_p0.clone()
            }
        }
    }
}
