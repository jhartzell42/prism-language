//! The module `Syntax.Parser.Expr`, from `target/bootstrap/src/prismc/syntax/parser/expr.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `ArgsRead`:
///
/// ```prism
/// type ArgsRead = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct ArgsRead {
    pub args_p: crate::prelude::Array<crate::syntax::Arg>,
    pub rest_p: bool,
    pub p_p: crate::syntax::parser::Ps,
    pub going_p: bool,
}

impl crate::prelude::Show for ArgsRead {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("ArgsRead", &[("args", &self.args_p), ("rest", &self.rest_p), ("p", &self.p_p), ("going", &self.going_p)]);
    }
}

impl crate::prelude::ToPod for ArgsRead {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("ArgsRead", vec![("args", self.args_p.to_pod()), ("rest", self.rest_p.to_pod()), ("p", self.p_p.to_pod()), ("going", self.going_p.to_pod())])
    }
}

impl crate::prelude::FromPod for ArgsRead {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(ArgsRead { args_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "args")?)?, rest_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "rest")?)?, p_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "p")?)?, going_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "going")?)? })
    }
}

/// `Climb`:
///
/// ```prism
/// type Climb = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Climb {
    pub lhs_p: crate::syntax::Expr,
    pub p_p: crate::syntax::parser::Ps,
    pub going_p: bool,
}

impl crate::prelude::Show for Climb {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Climb", &[("lhs", &self.lhs_p), ("p", &self.p_p), ("going", &self.going_p)]);
    }
}

impl crate::prelude::ToPod for Climb {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Climb", vec![("lhs", self.lhs_p.to_pod()), ("p", self.p_p.to_pod()), ("going", self.going_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Climb {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Climb { lhs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "lhs")?)?, p_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "p")?)?, going_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "going")?)? })
    }
}

/// ```prism
/// ParseExpr: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_expr_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    parse_expr_ctx_f(p_p0, &true)
}

/// The step machine of `ParseExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseExpr: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseExpr {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseExpr {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(ParseExprCtx { p_p0: p_p0.clone(), commas_p1: true }))
    }
}

/// `Start ParseExpr, x`: what the function value is when passed to `@Run`.
pub fn start_parse_expr_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseExpr { p_p0 })
}

/// ```prism
/// ParseArgExpr: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_arg_expr_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    parse_expr_ctx_f(p_p0, &false)
}

/// The step machine of `ParseArgExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseArgExpr: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseArgExpr {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseArgExpr {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(ParseExprCtx { p_p0: p_p0.clone(), commas_p1: false }))
    }
}

/// `Start ParseArgExpr, x`: what the function value is when passed to `@Run`.
pub fn start_parse_arg_expr_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseArgExpr { p_p0 })
}

/// ```prism
/// ParseExprCtx: unbounded fn Ps, Bool -> ((Expr, Ps))
/// ```
pub fn parse_expr_ctx_f(p_p0: &crate::syntax::parser::Ps, commas_p1: &bool) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    parse_binary_f(p_p0, &crate::prelude::Nat::from(4u32), &(*commas_p1 && !p_p0.step_mode_p))
}

/// The step machine of `ParseExprCtx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseExprCtx: unbounded fn Ps, Bool -> ((Expr, Ps))
/// ```
pub struct ParseExprCtx {
    pub p_p0: crate::syntax::parser::Ps,
    pub commas_p1: bool,
}

impl ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseExprCtx {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let commas_p1 = &self.commas_p1;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(ParseBinary { p0_p0: p_p0.clone(), min_p1: crate::prelude::Nat::from(4u32), commas_p2: *commas_p1 && !p_p0.step_mode_p }))
    }
}

/// `Start ParseExprCtx, x`: what the function value is when passed to `@Run`.
pub fn start_parse_expr_ctx_f(p_p0: crate::syntax::parser::Ps, commas_p1: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseExprCtx { p_p0, commas_p1 })
}

/// ```prism
/// ParseRhsExpr: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_rhs_expr_f(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let mut this: (crate::syntax::Expr, crate::syntax::parser::Ps) = parse_expr_f(p0_p0);
    let (e0_p1, p1_p2) = this.clone();
    let mut e_p3: crate::syntax::Expr = e0_p1.clone();
    let mut p_p4: crate::syntax::parser::Ps = p1_p2.clone();
    while at_line_method_f(&p_p4) {
        let (method_p5, p2_p6) = crate::syntax::parser::parse_sname_f(&crate::syntax::parser::adv_f(&p_p4));
        let (args_p7, p3_p8) = if arg_starts_here_f(&p2_p6) {
            parse_call_args_f(&p2_p6, &true)
        } else {
            (crate::prelude::Array::new(), p2_p6.clone())
        };
        e_p3 = crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EMethod(::std::rc::Rc::new(e_p3.clone()), method_p5.clone(), args_p7.clone())), span_p: crate::syntax::parser::to_f(&e_p3.span_p, &crate::syntax::parser::prev_f(&p3_p8)) };
        p_p4 = p3_p8.clone();
    }
    this = (e_p3.clone(), p_p4.clone());
    this
}

/// The step machine of `ParseRhsExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseRhsExpr: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseRhsExpr {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseRhsExpr {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let mut this: (crate::syntax::Expr, crate::syntax::parser::Ps) = parse_expr_f(p0_p0);
        let (e0_p1, p1_p2) = this.clone();
        let mut e_p3: crate::syntax::Expr = e0_p1.clone();
        let mut p_p4: crate::syntax::parser::Ps = p1_p2.clone();
        crate::prelude::call_then(crate::prelude::loop_job((this, e_p3, p_p4), move |(mut this, mut e_p3, mut p_p4): ((crate::syntax::Expr, crate::syntax::parser::Ps), crate::syntax::Expr, crate::syntax::parser::Ps)| if at_line_method_f(&p_p4) {
            {
                let (method_p5, p2_p6) = crate::syntax::parser::parse_sname_f(&crate::syntax::parser::adv_f(&p_p4));
                let (args_p7, p3_p8) = if arg_starts_here_f(&p2_p6) {
                    parse_call_args_f(&p2_p6, &true)
                } else {
                    (crate::prelude::Array::new(), p2_p6.clone())
                };
                e_p3 = crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EMethod(::std::rc::Rc::new(e_p3.clone()), method_p5.clone(), args_p7.clone())), span_p: crate::syntax::parser::to_f(&e_p3.span_p, &crate::syntax::parser::prev_f(&p3_p8)) };
                p_p4 = p3_p8.clone();
                ::std::result::Result::Ok((this, e_p3, p_p4))
            }
        } else {
            ::std::result::Result::Err((this, e_p3, p_p4))
        }), move |(mut this, mut e_p3, mut p_p4): ((crate::syntax::Expr, crate::syntax::parser::Ps), crate::syntax::Expr, crate::syntax::parser::Ps)| {
            this = (e_p3.clone(), p_p4.clone());
            ::prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start ParseRhsExpr, x`: what the function value is when passed to `@Run`.
pub fn start_parse_rhs_expr_f(p0_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseRhsExpr { p0_p0 })
}

/// ```prism
/// AtLineMethod: fn Ps -> Bool
/// ```
pub fn at_line_method_f(p_p0: &crate::syntax::parser::Ps) -> bool {
    ((&crate::syntax::parser::kind_f(p_p0) == &crate::syntax::lexer::TokKind::KDot(true)) && crate::syntax::parser::tk_f(p_p0).line_start_p) && is_plain_upper_f(&crate::syntax::parser::kind_at_f(p_p0, &crate::prelude::Nat::from(1u32)))
}

/// ```prism
/// IsPlainUpper: fn TokKind -> Bool
/// ```
pub fn is_plain_upper_f(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KName(n_p0) => (&n_p0.case_p == &crate::syntax::lexer::NameCase::CaseUpper) && (&n_p0.sigils_p == &crate::prelude::Text::lit("")),
        _ => false,
    }
}

/// ```prism
/// IsUpperTok: fn TokKind -> Bool
/// ```
pub fn is_upper_tok_f(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KName(n_p0) => &n_p0.case_p == &crate::syntax::lexer::NameCase::CaseUpper,
        _ => false,
    }
}

/// ```prism
/// ?PeekBinop: fn Ps -> ?((Text, ?[Text]))
/// ```
pub fn peek_binop_o(p_p0: &crate::syntax::parser::Ps) -> ::std::option::Option<(crate::prelude::Text, ::std::option::Option<crate::prelude::Array<crate::prelude::Text>>)> {
    match crate::syntax::parser::kind_f(p_p0) {
        crate::syntax::lexer::TokKind::KOp(op_p1, prefix_p2) if (!prefix_p2 || (&op_p1 == &crate::prelude::Text::lit("-?"))) => if is_binop_f(&op_p1) {
            ::std::option::Option::Some((op_p1.clone(), ::std::option::Option::None))
        } else {
            ::std::option::Option::None
        },
        crate::syntax::lexer::TokKind::KSuffixed(op_p3, ty_p4) => if is_binop_f(&op_p3) {
            ::std::option::Option::Some((op_p3.clone(), ::std::option::Option::Some(ty_p4)))
        } else {
            ::std::option::Option::None
        },
        crate::syntax::lexer::TokKind::KKw(m2766_2_0, m2766_2_1) if (&m2766_2_0 == &crate::prelude::Text::lit("on")) && (&m2766_2_1 == &crate::prelude::Text::lit("")) => ::std::option::Option::Some((crate::prelude::Text::lit("on"), ::std::option::Option::None)),
        crate::syntax::lexer::TokKind::KKw(m2766_3_0, m2766_3_1) if (&m2766_3_0 == &crate::prelude::Text::lit("or")) && (&m2766_3_1 == &crate::prelude::Text::lit("")) => ::std::option::Option::Some((crate::prelude::Text::lit("or"), ::std::option::Option::None)),
        crate::syntax::lexer::TokKind::KKw(m2766_4_0, m2766_4_1) if (&m2766_4_0 == &crate::prelude::Text::lit("and")) && (&m2766_4_1 == &crate::prelude::Text::lit("")) => ::std::option::Option::Some((crate::prelude::Text::lit("and"), ::std::option::Option::None)),
        crate::syntax::lexer::TokKind::KKw(m2766_5_0, m2766_5_1) if (&m2766_5_0 == &crate::prelude::Text::lit("mod")) && (&m2766_5_1 == &crate::prelude::Text::lit("")) => ::std::option::Option::Some((crate::prelude::Text::lit("mod"), ::std::option::Option::None)),
        _ => ::std::option::Option::None,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IsBinop: fn Text -> Bool
/// ```
pub fn is_binop_f(op_p0: &crate::prelude::Text) -> bool {
    crate::prelude::fold(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("<|"), crate::prelude::Text::lit("=="), crate::prelude::Text::lit("!="), crate::prelude::Text::lit("<"), crate::prelude::Text::lit("<="), crate::prelude::Text::lit(">"), crate::prelude::Text::lit(">="), crate::prelude::Text::lit("+"), crate::prelude::Text::lit("-"), crate::prelude::Text::lit("+?"), crate::prelude::Text::lit("-?"), crate::prelude::Text::lit("*"), crate::prelude::Text::lit("/"), crate::prelude::Text::lit("*?")]), &false, &(|seen_p1: &bool, o_p2: &crate::prelude::Text| *seen_p1 || (o_p2 == op_p0)))
}

/// ```prism
/// Level: fn Text -> Nat
/// ```
pub fn level_f(text0: &crate::prelude::Text) -> crate::prelude::Nat {
    match text0 {
        c0_0 if (c0_0 == &crate::prelude::Text::lit("<|")) => crate::prelude::Nat::from(4u32),
        c1_0 if (c1_0 == &crate::prelude::Text::lit("on")) => crate::prelude::Nat::from(5u32),
        c2_0 if (c2_0 == &crate::prelude::Text::lit("or")) => crate::prelude::Nat::from(6u32),
        c3_0 if (c3_0 == &crate::prelude::Text::lit("and")) => crate::prelude::Nat::from(7u32),
        c4_0 if (c4_0 == &crate::prelude::Text::lit("+")) => crate::prelude::Nat::from(10u32),
        c5_0 if (c5_0 == &crate::prelude::Text::lit("-")) => crate::prelude::Nat::from(10u32),
        c6_0 if (c6_0 == &crate::prelude::Text::lit("+?")) => crate::prelude::Nat::from(10u32),
        c7_0 if (c7_0 == &crate::prelude::Text::lit("-?")) => crate::prelude::Nat::from(10u32),
        c8_0 if (c8_0 == &crate::prelude::Text::lit("*")) => crate::prelude::Nat::from(11u32),
        c9_0 if (c9_0 == &crate::prelude::Text::lit("/")) => crate::prelude::Nat::from(11u32),
        c10_0 if (c10_0 == &crate::prelude::Text::lit("*?")) => crate::prelude::Nat::from(11u32),
        c11_0 if (c11_0 == &crate::prelude::Text::lit("mod")) => crate::prelude::Nat::from(11u32),
        _ => crate::prelude::Nat::from(9u32),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParseBinary: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
/// ```
pub fn parse_binary_f(p0_p0: &crate::syntax::parser::Ps, min_p1: &crate::prelude::Nat, commas_p2: &bool) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let (lhs_p4, p1_p5) = parse_prefix_f(p0_p0, min_p1, commas_p2);
    let r_p3 = {
        let mut this: Climb = Climb { lhs_p: lhs_p4.clone(), p_p: p1_p5.clone(), going_p: true };
        while this.going_p && !this.p_p.bad_p {
            this = climb_step_f(&this, min_p1, commas_p2);
        }
        this
    };
    (r_p3.lhs_p.clone(), r_p3.p_p.clone())
}

/// The step machine of `ParseBinary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseBinary: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
/// ```
pub struct ParseBinary {
    pub p0_p0: crate::syntax::parser::Ps,
    pub min_p1: crate::prelude::Nat,
    pub commas_p2: bool,
}

impl ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseBinary {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let min_p1 = &self.min_p1;
        let commas_p2 = &self.commas_p2;
        let commas_p2x = *commas_p2;
        let min_p1x = min_p1.clone();
        let p0_p0x = p0_p0.clone();
        crate::prelude::call_then(start_parse_prefix_f(p0_p0x.clone(), min_p1x.clone(), commas_p2x), move |parse_prefix_f_4034: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
            let (lhs_p4, p1_p5) = parse_prefix_f_4034;
            let mut this: Climb = Climb { lhs_p: lhs_p4.clone(), p_p: p1_p5.clone(), going_p: true };
            crate::prelude::call_then(crate::prelude::loop_job((this,), {
                let commas_p2xx = commas_p2x;
                let min_p1xx = min_p1x.clone();
                move |(mut this,): (Climb,)| if this.going_p && !this.p_p.bad_p {
                    {
                        this = climb_step_f(&this, &min_p1xx, &commas_p2xx);
                        ::std::result::Result::Ok((this,))
                    }
                } else {
                    ::std::result::Result::Err((this,))
                }
            }), move |(mut this,): (Climb,)| {
                let r_p3 = this;
                ::prism_rtl::Turn::Finished((r_p3.lhs_p.clone(), r_p3.p_p.clone()))
            })
        })
    }
}

/// `Start ParseBinary, x`: what the function value is when passed to `@Run`.
pub fn start_parse_binary_f(p0_p0: crate::syntax::parser::Ps, min_p1: crate::prelude::Nat, commas_p2: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseBinary { p0_p0, min_p1, commas_p2 })
}

/// ```prism
/// ClimbStep: unbounded fn Climb, Nat, Bool -> Climb
/// ```
pub fn climb_step_f(c_p0: &Climb, min_p1: &crate::prelude::Nat, commas_p2: &bool) -> Climb {
    let p_p3 = c_p0.p_p.clone();
    if crate::syntax::parser::at_kw_f(&p_p3, &crate::prelude::Text::lit("as")) && (min_p1 <= &crate::prelude::Nat::from(12u32)) {
        {
            let (ty0_p8, p2_p9) = crate::syntax::parser::types::parse_type_f(&crate::syntax::parser::adv_f(&p_p3));
            let after_parenthesis_p4 = crate::syntax::parser::types::plus_touches_parenthesis_f(&p2_p9, &crate::prelude::Text::lit("+?"));
            let checked_p5 = after_parenthesis_p4 || ((&crate::syntax::parser::kind_f(&p2_p9) == &crate::syntax::lexer::TokKind::KFree(crate::prelude::Text::lit("?"))) && crate::syntax::parser::tk_f(&p2_p9).touches_p);
            let ty_p6 = if after_parenthesis_p4 {
                crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TNonEmpty(::std::rc::Rc::new(ty0_p8.clone()))), span_p: crate::syntax::parser::to_f(&ty0_p8.span_p, &crate::syntax::parser::here_f(&p2_p9)) }
            } else {
                ty0_p8.clone()
            };
            let p3_p7 = if checked_p5 { crate::syntax::parser::adv_f(&p2_p9) } else { p2_p9.clone() };
            {
                let mut this: Climb = c_p0.clone();
                this.lhs_p = crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ECast(::std::rc::Rc::new(this.lhs_p.clone()), ty_p6.clone(), checked_p5)), span_p: crate::syntax::parser::to_f(&this.lhs_p.span_p, &crate::syntax::parser::prev_f(&p3_p7)) };
                this.p_p = p3_p7.clone();
                this
            }
        }
    } else {
        match peek_binop_o(&p_p3) {
            ::std::option::Option::None => {
                let mut this: Climb = c_p0.clone();
                this.going_p = false;
                this.p_p = no_operator_f(&p_p3);
                this
            },
            ::std::option::Option::Some((op_pa, suffix_ob)) => if &level_f(&op_pa) < min_p1 {
                {
                    let mut this: Climb = c_p0.clone();
                    this.going_p = false;
                    this
                }
            } else {
                {
                    let p1_pc = if &crate::syntax::parser::kind_f(&p_p3) == &crate::syntax::lexer::TokKind::KOp(crate::prelude::Text::lit("-?"), true) {
                        crate::syntax::parser::note_error_f(&p_p3, &crate::syntax::parser::here_f(&p_p3), &crate::prelude::Text::lit("`-?` is the checked subtraction by longest match; to subtract or negate an optional, write `-(?x)`"))
                    } else {
                        p_p3.clone()
                    };
                    let op_tok_pd = crate::syntax::parser::tk_f(&p1_pc);
                    let (rhs_ph, p2_pi) = parse_binary_f(&crate::syntax::parser::adv_f(&p1_pc), &(&level_f(&op_pa) + &crate::prelude::Nat::from(1u32)), commas_p2);
                    let span_pe = crate::syntax::parser::to_f(&c_p0.lhs_p.span_p, &rhs_ph.span_p);
                    let kind_pf = match &suffix_ob {
                        ::std::option::Option::None => crate::syntax::ExprKind::EBinary(op_pa.clone(), ::std::rc::Rc::new(c_p0.lhs_p.clone()), ::std::rc::Rc::new(rhs_ph.clone())),
                        ::std::option::Option::Some(ty_pj) => crate::syntax::ExprKind::ESuffixed(op_pa.clone(), crate::syntax::QualName { path_p: ty_pj.clone(), span_p: op_tok_pd.span_p.clone() }, ::std::rc::Rc::new(c_p0.lhs_p.clone()), ::std::rc::Rc::new(rhs_ph.clone())),
                    };
                    let p3_pg = if &suffix_ob == &::std::option::Option::None {
                        p2_pi.clone()
                    } else {
                        crate::syntax::parser::out_of_scope_f(&p2_pi, &op_tok_pd.span_p, &crate::prelude::Text::lit("suffixed operators"), &crate::prelude::Text::from(format!("the suffixed operator `{}` is out of this compiler", &crate::syntax::lexer::corpus::token_text_f(&op_tok_pd.kind_p))))
                    };
                    {
                        let mut this: Climb = c_p0.clone();
                        this.lhs_p = crate::syntax::Expr { kind_p: ::std::rc::Rc::new(kind_pf.clone()), span_p: span_pe.clone() };
                        this.p_p = p3_pg.clone();
                        this
                    }
                }
            },
        }
    }
}

/// The step machine of `ClimbStep`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClimbStep: unbounded fn Climb, Nat, Bool -> Climb
/// ```
pub struct ClimbStep {
    pub c_p0: Climb,
    pub min_p1: crate::prelude::Nat,
    pub commas_p2: bool,
}

impl ::prism_rtl::Job<Climb> for ClimbStep {
    fn cycle(&self) -> ::prism_rtl::Turn<Climb> {
        let c_p0 = &self.c_p0;
        let min_p1 = &self.min_p1;
        let commas_p2 = &self.commas_p2;
        let p_p3 = c_p0.p_p.clone();
        if crate::syntax::parser::at_kw_f(&p_p3, &crate::prelude::Text::lit("as")) && (min_p1 <= &crate::prelude::Nat::from(12u32)) {
            {
                let c_p0x = c_p0.clone();
                crate::prelude::call_then(crate::syntax::parser::types::start_parse_type_f(crate::syntax::parser::adv_f(&p_p3)), move |parse_type_f_4431: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (ty0_p8, p2_p9) = parse_type_f_4431;
                    let after_parenthesis_p4 = crate::syntax::parser::types::plus_touches_parenthesis_f(&p2_p9, &crate::prelude::Text::lit("+?"));
                    let checked_p5 = after_parenthesis_p4 || ((&crate::syntax::parser::kind_f(&p2_p9) == &crate::syntax::lexer::TokKind::KFree(crate::prelude::Text::lit("?"))) && crate::syntax::parser::tk_f(&p2_p9).touches_p);
                    let ty_p6 = if after_parenthesis_p4 {
                        crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TNonEmpty(::std::rc::Rc::new(ty0_p8.clone()))), span_p: crate::syntax::parser::to_f(&ty0_p8.span_p, &crate::syntax::parser::here_f(&p2_p9)) }
                    } else {
                        ty0_p8.clone()
                    };
                    let p3_p7 = if checked_p5 { crate::syntax::parser::adv_f(&p2_p9) } else { p2_p9.clone() };
                    ::prism_rtl::Turn::Finished({
                        let mut this: Climb = c_p0x.clone();
                        this.lhs_p = crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ECast(::std::rc::Rc::new(this.lhs_p.clone()), ty_p6.clone(), checked_p5)), span_p: crate::syntax::parser::to_f(&this.lhs_p.span_p, &crate::syntax::parser::prev_f(&p3_p7)) };
                        this.p_p = p3_p7.clone();
                        this
                    })
                })
            }
        } else {
            match peek_binop_o(&p_p3) {
                ::std::option::Option::None => ::prism_rtl::Turn::Finished({
                    let mut this: Climb = c_p0.clone();
                    this.going_p = false;
                    this.p_p = no_operator_f(&p_p3);
                    this
                }),
                ::std::option::Option::Some((op_pa, suffix_ob)) => if &level_f(&op_pa) < min_p1 {
                    ::prism_rtl::Turn::Finished({
                        let mut this: Climb = c_p0.clone();
                        this.going_p = false;
                        this
                    })
                } else {
                    {
                        let p1_pc = if &crate::syntax::parser::kind_f(&p_p3) == &crate::syntax::lexer::TokKind::KOp(crate::prelude::Text::lit("-?"), true) {
                            crate::syntax::parser::note_error_f(&p_p3, &crate::syntax::parser::here_f(&p_p3), &crate::prelude::Text::lit("`-?` is the checked subtraction by longest match; to subtract or negate an optional, write `-(?x)`"))
                        } else {
                            p_p3.clone()
                        };
                        let op_tok_pd = crate::syntax::parser::tk_f(&p1_pc);
                        let c_p0x = c_p0.clone();
                        let commas_p2x = *commas_p2;
                        crate::prelude::call_then(start_parse_binary_f(crate::syntax::parser::adv_f(&p1_pc), &level_f(&op_pa) + &crate::prelude::Nat::from(1u32), commas_p2x), move |parse_binary_f_5681: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                            let (rhs_ph, p2_pi) = parse_binary_f_5681;
                            let span_pe = crate::syntax::parser::to_f(&c_p0x.lhs_p.span_p, &rhs_ph.span_p);
                            let kind_pf = match &suffix_ob {
                                ::std::option::Option::None => crate::syntax::ExprKind::EBinary(op_pa.clone(), ::std::rc::Rc::new(c_p0x.lhs_p.clone()), ::std::rc::Rc::new(rhs_ph.clone())),
                                ::std::option::Option::Some(ty_pj) => crate::syntax::ExprKind::ESuffixed(op_pa.clone(), crate::syntax::QualName { path_p: ty_pj.clone(), span_p: op_tok_pd.span_p.clone() }, ::std::rc::Rc::new(c_p0x.lhs_p.clone()), ::std::rc::Rc::new(rhs_ph.clone())),
                            };
                            let p3_pg = if &suffix_ob == &::std::option::Option::None {
                                p2_pi.clone()
                            } else {
                                crate::syntax::parser::out_of_scope_f(&p2_pi, &op_tok_pd.span_p, &crate::prelude::Text::lit("suffixed operators"), &crate::prelude::Text::from(format!("the suffixed operator `{}` is out of this compiler", &crate::syntax::lexer::corpus::token_text_f(&op_tok_pd.kind_p))))
                            };
                            ::prism_rtl::Turn::Finished({
                                let mut this: Climb = c_p0x.clone();
                                this.lhs_p = crate::syntax::Expr { kind_p: ::std::rc::Rc::new(kind_pf.clone()), span_p: span_pe.clone() };
                                this.p_p = p3_pg.clone();
                                this
                            })
                        })
                    }
                },
            }
        }
    }
}

/// `Start ClimbStep, x`: what the function value is when passed to `@Run`.
pub fn start_climb_step_f(c_p0: Climb, min_p1: crate::prelude::Nat, commas_p2: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<Climb>> {
    ::std::rc::Rc::new(ClimbStep { c_p0, min_p1, commas_p2 })
}

/// ```prism
/// NoOperator: fn Ps -> Ps
/// ```
pub fn no_operator_f(p_p0: &crate::syntax::parser::Ps) -> crate::syntax::parser::Ps {
    match crate::syntax::parser::kind_f(p_p0) {
        crate::syntax::lexer::TokKind::KOp(o_p1, true) if (((&o_p1 == &crate::prelude::Text::lit("-")) || (&o_p1 == &crate::prelude::Text::lit("+"))) && !crate::syntax::parser::tk_f(p_p0).line_start_p) => crate::syntax::parser::error_at_f(p_p0, &crate::syntax::parser::here_f(p_p0), &crate::prelude::Text::from(format!("`{}` here is a prefix sign by the spacing rule (a space before it and none after); did you mean `a {} 1`, with spaces on both sides?", &o_p1, &o_p1))),
        crate::syntax::lexer::TokKind::KBar => crate::syntax::parser::error_at_f(p_p0, &crate::syntax::parser::here_f(p_p0), &crate::prelude::Text::lit("a bare `|` is not an operator: the merge is `<|`, and `|` separates the families of a row")),
        crate::syntax::lexer::TokKind::KDot(true) if (!at_line_method_f(p_p0) && is_upper_tok_f(&crate::syntax::parser::kind_at_f(p_p0, &crate::prelude::Nat::from(1u32)))) => crate::syntax::parser::error_at_f(p_p0, &crate::syntax::parser::here_f(p_p0), &crate::prelude::Text::lit("a spaced `.Method` begins its own line, below the call it takes as its receiver (layout rule 9)")),
        _ => p_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParsePrefix: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
/// ```
pub fn parse_prefix_f(p_p0: &crate::syntax::parser::Ps, min_p1: &crate::prelude::Nat, commas_p2: &bool) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let start_p3 = crate::syntax::parser::here_f(p_p0);
    if crate::syntax::parser::at_kw_f(p_p0, &crate::prelude::Text::lit("not")) {
        {
            let (operand_p4, q_p5) = parse_binary_f(&crate::syntax::parser::adv_f(p_p0), &crate::prelude::max(&crate::prelude::Nat::from(9u32), min_p1), commas_p2);
            (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EUnary(crate::prelude::Text::lit("not"), ::std::rc::Rc::new(operand_p4.clone()))), span_p: crate::syntax::parser::to_f(&start_p3, &operand_p4.span_p) }, q_p5.clone())
        }
    } else {
        match crate::syntax::parser::kind_f(p_p0) {
            crate::syntax::lexer::TokKind::KOp(op_p6, true) if ((&op_p6 == &crate::prelude::Text::lit("-")) || (&op_p6 == &crate::prelude::Text::lit("+"))) => {
                let (operand_p8, q_p9) = parse_postfix_expr_f(&crate::syntax::parser::adv_f(p_p0), commas_p2);
                let name_p7 = if &op_p6 == &crate::prelude::Text::lit("-") {
                    crate::prelude::Text::lit("neg")
                } else {
                    crate::prelude::Text::lit("pos")
                };
                (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EUnary(name_p7.clone(), ::std::rc::Rc::new(operand_p8.clone()))), span_p: crate::syntax::parser::to_f(&start_p3, &operand_p8.span_p) }, q_p9.clone())
            },
            crate::syntax::lexer::TokKind::KOp(m7474_1_0, _) if (&m7474_1_0 == &crate::prelude::Text::lit("-?")) => (crate::syntax::parser::decls::no_expr_p(), crate::syntax::parser::error_at_f(p_p0, &crate::syntax::parser::here_f(p_p0), &crate::prelude::Text::lit("`-?` is the checked subtraction and needs a left operand; to negate an optional write `-(?x)`"))),
            _ => parse_postfix_expr_f(p_p0, commas_p2),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// The step machine of `ParsePrefix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParsePrefix: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
/// ```
pub struct ParsePrefix {
    pub p_p0: crate::syntax::parser::Ps,
    pub min_p1: crate::prelude::Nat,
    pub commas_p2: bool,
}

impl ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParsePrefix {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let min_p1 = &self.min_p1;
        let commas_p2 = &self.commas_p2;
        let start_p3 = crate::syntax::parser::here_f(p_p0);
        if crate::syntax::parser::at_kw_f(p_p0, &crate::prelude::Text::lit("not")) {
            {
                let commas_p2x = *commas_p2;
                let min_p1x = min_p1.clone();
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(start_parse_binary_f(crate::syntax::parser::adv_f(&p_p0x), crate::prelude::max(&crate::prelude::Nat::from(9u32), &min_p1x), commas_p2x), move |parse_binary_f_7341: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (operand_p4, q_p5) = parse_binary_f_7341;
                    ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EUnary(crate::prelude::Text::lit("not"), ::std::rc::Rc::new(operand_p4.clone()))), span_p: crate::syntax::parser::to_f(&start_p3, &operand_p4.span_p) }, q_p5.clone()))
                })
            }
        } else {
            match crate::syntax::parser::kind_f(p_p0) {
                crate::syntax::lexer::TokKind::KOp(op_p6, true) if ((&op_p6 == &crate::prelude::Text::lit("-")) || (&op_p6 == &crate::prelude::Text::lit("+"))) => {
                    let commas_p2x = *commas_p2;
                    let p_p0x = p_p0.clone();
                    crate::prelude::call_then(start_parse_postfix_expr_f(crate::syntax::parser::adv_f(&p_p0x), commas_p2x), move |parse_postfix_expr_f_7569: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                        let (operand_p8, q_p9) = parse_postfix_expr_f_7569;
                        let name_p7 = if &op_p6 == &crate::prelude::Text::lit("-") {
                            crate::prelude::Text::lit("neg")
                        } else {
                            crate::prelude::Text::lit("pos")
                        };
                        ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EUnary(name_p7.clone(), ::std::rc::Rc::new(operand_p8.clone()))), span_p: crate::syntax::parser::to_f(&start_p3, &operand_p8.span_p) }, q_p9.clone()))
                    })
                },
                crate::syntax::lexer::TokKind::KOp(m7474_1_0, _) if (&m7474_1_0 == &crate::prelude::Text::lit("-?")) => ::prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr_p(), crate::syntax::parser::error_at_f(p_p0, &crate::syntax::parser::here_f(p_p0), &crate::prelude::Text::lit("`-?` is the checked subtraction and needs a left operand; to negate an optional write `-(?x)`")))),
                _ => ::prism_rtl::Turn::More(::std::rc::Rc::new(ParsePostfixExpr { p_p0: p_p0.clone(), commas_p1: *commas_p2 })),
                _ => unreachable!("no arm matched"),
            }
        }
    }
}

/// `Start ParsePrefix, x`: what the function value is when passed to `@Run`.
pub fn start_parse_prefix_f(p_p0: crate::syntax::parser::Ps, min_p1: crate::prelude::Nat, commas_p2: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParsePrefix { p_p0, min_p1, commas_p2 })
}

/// ```prism
/// ParsePostfixExpr: unbounded fn Ps, Bool -> ((Expr, Ps))
/// ```
pub fn parse_postfix_expr_f(p_p0: &crate::syntax::parser::Ps, commas_p1: &bool) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let (e_p2, took_rest_p3, q_p4) = parse_primary_f(p_p0, commas_p1);
    if took_rest_p3 {
        (e_p2.clone(), q_p4.clone())
    } else {
        parse_postfix_f(&e_p2, &q_p4, commas_p1)
    }
}

/// The step machine of `ParsePostfixExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParsePostfixExpr: unbounded fn Ps, Bool -> ((Expr, Ps))
/// ```
pub struct ParsePostfixExpr {
    pub p_p0: crate::syntax::parser::Ps,
    pub commas_p1: bool,
}

impl ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParsePostfixExpr {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let commas_p1 = &self.commas_p1;
        let commas_p1x = *commas_p1;
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(start_parse_primary_f(p_p0x.clone(), commas_p1x), move |parse_primary_f_8176: (crate::syntax::Expr, bool, crate::syntax::parser::Ps)| {
            let (e_p2, took_rest_p3, q_p4) = parse_primary_f_8176;
            if took_rest_p3 {
                ::prism_rtl::Turn::Finished((e_p2.clone(), q_p4.clone()))
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(ParsePostfix { e0_p0: e_p2.clone(), p0_p1: q_p4.clone(), commas_p2: commas_p1x }))
            }
        })
    }
}

/// `Start ParsePostfixExpr, x`: what the function value is when passed to `@Run`.
pub fn start_parse_postfix_expr_f(p_p0: crate::syntax::parser::Ps, commas_p1: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParsePostfixExpr { p_p0, commas_p1 })
}

/// ```prism
/// ParsePostfix: unbounded fn Expr, Ps, Bool -> ((Expr, Ps))
/// ```
pub fn parse_postfix_f(e0_p0: &crate::syntax::Expr, p0_p1: &crate::syntax::parser::Ps, commas_p2: &bool) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let mut this: (crate::syntax::Expr, crate::syntax::parser::Ps) = (e0_p0.clone(), p0_p1.clone());
    let mut e_p3: crate::syntax::Expr = e0_p0.clone();
    let mut p_p4: crate::syntax::parser::Ps = p0_p1.clone();
    let mut going_p5: bool = true;
    while going_p5 && !p_p4.bad_p {
        let (e2_p6, p2_p7, more_p8) = postfix_step_f(&e_p3, &p_p4, commas_p2);
        e_p3 = e2_p6.clone();
        p_p4 = p2_p7.clone();
        going_p5 = more_p8;
    }
    this = (e_p3.clone(), p_p4.clone());
    this
}

/// The step machine of `ParsePostfix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParsePostfix: unbounded fn Expr, Ps, Bool -> ((Expr, Ps))
/// ```
pub struct ParsePostfix {
    pub e0_p0: crate::syntax::Expr,
    pub p0_p1: crate::syntax::parser::Ps,
    pub commas_p2: bool,
}

impl ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParsePostfix {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let e0_p0 = &self.e0_p0;
        let p0_p1 = &self.p0_p1;
        let commas_p2 = &self.commas_p2;
        let mut this: (crate::syntax::Expr, crate::syntax::parser::Ps) = (e0_p0.clone(), p0_p1.clone());
        let mut e_p3: crate::syntax::Expr = e0_p0.clone();
        let mut p_p4: crate::syntax::parser::Ps = p0_p1.clone();
        let mut going_p5: bool = true;
        crate::prelude::call_then(crate::prelude::loop_job((this, e_p3, going_p5, p_p4), {
            let commas_p2x = *commas_p2;
            move |(mut this, mut e_p3, mut going_p5, mut p_p4): ((crate::syntax::Expr, crate::syntax::parser::Ps), crate::syntax::Expr, bool, crate::syntax::parser::Ps)| if going_p5 && !p_p4.bad_p {
                {
                    let (e2_p6, p2_p7, more_p8) = postfix_step_f(&e_p3, &p_p4, &commas_p2x);
                    e_p3 = e2_p6.clone();
                    p_p4 = p2_p7.clone();
                    going_p5 = more_p8;
                    ::std::result::Result::Ok((this, e_p3, going_p5, p_p4))
                }
            } else {
                ::std::result::Result::Err((this, e_p3, going_p5, p_p4))
            }
        }), move |(mut this, mut e_p3, mut going_p5, mut p_p4): ((crate::syntax::Expr, crate::syntax::parser::Ps), crate::syntax::Expr, bool, crate::syntax::parser::Ps)| {
            this = (e_p3.clone(), p_p4.clone());
            ::prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start ParsePostfix, x`: what the function value is when passed to `@Run`.
pub fn start_parse_postfix_f(e0_p0: crate::syntax::Expr, p0_p1: crate::syntax::parser::Ps, commas_p2: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParsePostfix { e0_p0, p0_p1, commas_p2 })
}

/// ```prism
/// PostfixStep: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
/// ```
pub fn postfix_step_f(e_p0: &crate::syntax::Expr, p_p1: &crate::syntax::parser::Ps, commas_p2: &bool) -> (crate::syntax::Expr, crate::syntax::parser::Ps, bool) {
    match crate::syntax::parser::kind_f(p_p1) {
        crate::syntax::lexer::TokKind::KDot(false) => field_or_method_f(e_p0, p_p1, commas_p2),
        crate::syntax::lexer::TokKind::KOpen(m8806_1_0, false) if (&m8806_1_0 == &crate::prelude::Text::lit("[")) && (crate::syntax::parser::tk_f(p_p1).touches_p && !crate::syntax::parser::at_double_open_f(p_p1, &crate::prelude::Text::lit("["))) => {
            let (index_p4, p1_p5) = crate::syntax::parser::bracketed_f(&crate::syntax::parser::adv_f(p_p1), &(::std::rc::Rc::new(|a0: crate::syntax::parser::Ps| crate::prelude::entered(start_parse_expr_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>));
            let p2_p3 = crate::syntax::parser::expect_close_f(&p1_p5, &crate::prelude::Text::lit("["));
            (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EIndex(::std::rc::Rc::new(e_p0.clone()), ::std::rc::Rc::new(index_p4.clone()))), span_p: crate::syntax::parser::to_f(&e_p0.span_p, &crate::syntax::parser::prev_f(&p2_p3)) }, p2_p3.clone(), true)
        },
        crate::syntax::lexer::TokKind::KLtLt => {
            let (types_p6, q_p7) = parse_type_args_f(p_p1);
            (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ETypeArgs(::std::rc::Rc::new(e_p0.clone()), types_p6.clone())), span_p: crate::syntax::parser::to_f(&e_p0.span_p, &crate::syntax::parser::prev_f(&q_p7)) }, q_p7.clone(), true)
        },
        crate::syntax::lexer::TokKind::KNonEmpty => {
            let span_p8 = crate::syntax::parser::here_f(p_p1);
            (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ENonEmpty(::std::rc::Rc::new(e_p0.clone()))), span_p: crate::syntax::parser::to_f(&e_p0.span_p, &span_p8) }, crate::syntax::parser::adv_f(p_p1), true)
        },
        _ => (e_p0.clone(), p_p1.clone(), false),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `PostfixStep`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PostfixStep: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
/// ```
pub struct PostfixStep {
    pub e_p0: crate::syntax::Expr,
    pub p_p1: crate::syntax::parser::Ps,
    pub commas_p2: bool,
}

impl ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps, bool)> for PostfixStep {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps, bool)> {
        let e_p0 = &self.e_p0;
        let p_p1 = &self.p_p1;
        let commas_p2 = &self.commas_p2;
        match crate::syntax::parser::kind_f(p_p1) {
            crate::syntax::lexer::TokKind::KDot(false) => ::prism_rtl::Turn::More(::std::rc::Rc::new(FieldOrMethod { e_p0: e_p0.clone(), p0_p1: p_p1.clone(), commas_p2: *commas_p2 })),
            crate::syntax::lexer::TokKind::KOpen(m8806_1_0, false) if (&m8806_1_0 == &crate::prelude::Text::lit("[")) && (crate::syntax::parser::tk_f(p_p1).touches_p && !crate::syntax::parser::at_double_open_f(p_p1, &crate::prelude::Text::lit("["))) => {
                let e_p0x = e_p0.clone();
                let p_p1x = p_p1.clone();
                crate::prelude::call_then(crate::syntax::parser::start_bracketed_f(crate::syntax::parser::adv_f(&p_p1x), ::std::rc::Rc::new(|a0: crate::syntax::parser::Ps| crate::prelude::entered(start_parse_expr_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>), move |bracketed_f_8961: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (index_p4, p1_p5) = bracketed_f_8961;
                    let p2_p3 = crate::syntax::parser::expect_close_f(&p1_p5, &crate::prelude::Text::lit("["));
                    ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EIndex(::std::rc::Rc::new(e_p0x.clone()), ::std::rc::Rc::new(index_p4.clone()))), span_p: crate::syntax::parser::to_f(&e_p0x.span_p, &crate::syntax::parser::prev_f(&p2_p3)) }, p2_p3.clone(), true))
                })
            },
            crate::syntax::lexer::TokKind::KLtLt => {
                let e_p0x = e_p0.clone();
                let p_p1x = p_p1.clone();
                crate::prelude::call_then(start_parse_type_args_f(p_p1x.clone()), move |parse_type_args_f_9145: (crate::prelude::Array<crate::syntax::Type>, crate::syntax::parser::Ps)| {
                    let (types_p6, q_p7) = parse_type_args_f_9145;
                    ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ETypeArgs(::std::rc::Rc::new(e_p0x.clone()), types_p6.clone())), span_p: crate::syntax::parser::to_f(&e_p0x.span_p, &crate::syntax::parser::prev_f(&q_p7)) }, q_p7.clone(), true))
                })
            },
            crate::syntax::lexer::TokKind::KNonEmpty => {
                let span_p8 = crate::syntax::parser::here_f(p_p1);
                ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ENonEmpty(::std::rc::Rc::new(e_p0.clone()))), span_p: crate::syntax::parser::to_f(&e_p0.span_p, &span_p8) }, crate::syntax::parser::adv_f(p_p1), true))
            },
            _ => ::prism_rtl::Turn::Finished((e_p0.clone(), p_p1.clone(), false)),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start PostfixStep, x`: what the function value is when passed to `@Run`.
pub fn start_postfix_step_f(e_p0: crate::syntax::Expr, p_p1: crate::syntax::parser::Ps, commas_p2: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps, bool)>> {
    ::std::rc::Rc::new(PostfixStep { e_p0, p_p1, commas_p2 })
}

/// ```prism
/// FieldOrMethod: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
/// ```
pub fn field_or_method_f(e_p0: &crate::syntax::Expr, p0_p1: &crate::syntax::parser::Ps, commas_p2: &bool) -> (crate::syntax::Expr, crate::syntax::parser::Ps, bool) {
    let dot_p3 = crate::syntax::parser::here_f(p0_p1);
    let p_p4 = crate::syntax::parser::adv_f(p0_p1);
    match crate::syntax::parser::kind_f(&p_p4) {
        crate::syntax::lexer::TokKind::KName(n_p5) if ((&crate::prelude::len(&n_p5.path_p) == &crate::prelude::Nat::from(1u32)) && ((&n_p5.case_p == &crate::syntax::lexer::NameCase::CaseLower) || (&n_p5.case_p == &crate::syntax::lexer::NameCase::CaseTopic))) => {
            let t_p6 = crate::syntax::parser::here_f(&p_p4);
            let field_p7 = crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EField(::std::rc::Rc::new(e_p0.clone()), n_p5.sigils_p.clone(), crate::syntax::Ident { name_p: crate::prelude::or(&crate::prelude::index(&n_p5.path_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")), span_p: t_p6.clone() })), span_p: crate::syntax::parser::to_f(&e_p0.span_p, &t_p6) };
            let p1_p8 = crate::syntax::parser::adv_f(&p_p4);
            if arg_starts_here_f(&p1_p8) && !crate::syntax::parser::tk_f(&p1_p8).line_start_p {
                {
                    let (args_p9, p2_pa) = parse_call_args_f(&p1_p8, commas_p2);
                    (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ECall(::std::rc::Rc::new(field_p7.clone()), args_p9.clone(), false, false)), span_p: crate::syntax::parser::to_f(&field_p7.span_p, &crate::syntax::parser::prev_f(&p2_pa)) }, p2_pa.clone(), false)
                }
            } else {
                (field_p7.clone(), p1_p8.clone(), true)
            }
        },
        crate::syntax::lexer::TokKind::KKw(w_pb, m9533_1_1) if (&m9533_1_1 == &crate::prelude::Text::lit("")) && crate::syntax::lexer::is_bound_word_f(&w_pb) => {
            let t_pc = crate::syntax::parser::here_f(&p_p4);
            (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EField(::std::rc::Rc::new(e_p0.clone()), crate::prelude::Text::lit(""), crate::syntax::Ident { name_p: w_pb.clone(), span_p: t_pc.clone() })), span_p: crate::syntax::parser::to_f(&e_p0.span_p, &t_pc) }, crate::syntax::parser::adv_f(&p_p4), true)
        },
        crate::syntax::lexer::TokKind::KName(n_pd) if ((&n_pd.case_p == &crate::syntax::lexer::NameCase::CaseUpper) || (&n_pd.case_p == &crate::syntax::lexer::NameCase::CaseReserved)) => {
            let (method_pe, p1_pf) = crate::syntax::parser::parse_sname_f(&p_p4);
            let (args_pg, p2_ph) = if arg_starts_here_f(&p1_pf) {
                parse_call_args_f(&p1_pf, commas_p2)
            } else {
                (crate::prelude::Array::new(), p1_pf.clone())
            };
            (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EMethod(::std::rc::Rc::new(e_p0.clone()), method_pe.clone(), args_pg.clone())), span_p: crate::syntax::parser::to_f(&e_p0.span_p, &crate::syntax::parser::prev_f(&p2_ph)) }, p2_ph.clone(), false)
        },
        _ => (e_p0.clone(), crate::syntax::parser::error_at_f(&p_p4, &dot_p3, &crate::prelude::Text::lit("expected a field name or a `.Method` after `.`")), false),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `FieldOrMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldOrMethod: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
/// ```
pub struct FieldOrMethod {
    pub e_p0: crate::syntax::Expr,
    pub p0_p1: crate::syntax::parser::Ps,
    pub commas_p2: bool,
}

impl ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps, bool)> for FieldOrMethod {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps, bool)> {
        let e_p0 = &self.e_p0;
        let p0_p1 = &self.p0_p1;
        let commas_p2 = &self.commas_p2;
        let dot_p3 = crate::syntax::parser::here_f(p0_p1);
        let p_p4 = crate::syntax::parser::adv_f(p0_p1);
        match crate::syntax::parser::kind_f(&p_p4) {
            crate::syntax::lexer::TokKind::KName(n_p5) if ((&crate::prelude::len(&n_p5.path_p) == &crate::prelude::Nat::from(1u32)) && ((&n_p5.case_p == &crate::syntax::lexer::NameCase::CaseLower) || (&n_p5.case_p == &crate::syntax::lexer::NameCase::CaseTopic))) => {
                let t_p6 = crate::syntax::parser::here_f(&p_p4);
                let field_p7 = crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EField(::std::rc::Rc::new(e_p0.clone()), n_p5.sigils_p.clone(), crate::syntax::Ident { name_p: crate::prelude::or(&crate::prelude::index(&n_p5.path_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")), span_p: t_p6.clone() })), span_p: crate::syntax::parser::to_f(&e_p0.span_p, &t_p6) };
                let p1_p8 = crate::syntax::parser::adv_f(&p_p4);
                if arg_starts_here_f(&p1_p8) && !crate::syntax::parser::tk_f(&p1_p8).line_start_p {
                    {
                        let commas_p2x = *commas_p2;
                        crate::prelude::call_then(start_parse_call_args_f(p1_p8.clone(), commas_p2x), move |parse_call_args_f_10152: (crate::prelude::Array<crate::syntax::Arg>, crate::syntax::parser::Ps)| {
                            let (args_p9, p2_pa) = parse_call_args_f_10152;
                            ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ECall(::std::rc::Rc::new(field_p7.clone()), args_p9.clone(), false, false)), span_p: crate::syntax::parser::to_f(&field_p7.span_p, &crate::syntax::parser::prev_f(&p2_pa)) }, p2_pa.clone(), false))
                        })
                    }
                } else {
                    ::prism_rtl::Turn::Finished((field_p7.clone(), p1_p8.clone(), true))
                }
            },
            crate::syntax::lexer::TokKind::KKw(w_pb, m9533_1_1) if (&m9533_1_1 == &crate::prelude::Text::lit("")) && crate::syntax::lexer::is_bound_word_f(&w_pb) => {
                let t_pc = crate::syntax::parser::here_f(&p_p4);
                ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EField(::std::rc::Rc::new(e_p0.clone()), crate::prelude::Text::lit(""), crate::syntax::Ident { name_p: w_pb.clone(), span_p: t_pc.clone() })), span_p: crate::syntax::parser::to_f(&e_p0.span_p, &t_pc) }, crate::syntax::parser::adv_f(&p_p4), true))
            },
            crate::syntax::lexer::TokKind::KName(n_pd) if ((&n_pd.case_p == &crate::syntax::lexer::NameCase::CaseUpper) || (&n_pd.case_p == &crate::syntax::lexer::NameCase::CaseReserved)) => {
                let (method_pe, p1_pf) = crate::syntax::parser::parse_sname_f(&p_p4);
                let e_p0z = e_p0.clone();
                let method_pez = method_pe.clone();
                let k_let10745 = move |v10745: (crate::prelude::Array<crate::syntax::Arg>, crate::syntax::parser::Ps)| {
                    let (args_pg, p2_ph) = v10745;
                    ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EMethod(::std::rc::Rc::new(e_p0z.clone()), method_pez.clone(), args_pg.clone())), span_p: crate::syntax::parser::to_f(&e_p0z.span_p, &crate::syntax::parser::prev_f(&p2_ph)) }, p2_ph.clone(), false))
                };
                if arg_starts_here_f(&p1_pf) {
                    {
                        let commas_p2x = *commas_p2;
                        crate::prelude::call_then(start_parse_call_args_f(p1_pf.clone(), commas_p2x), move |parse_call_args_f_10785: (crate::prelude::Array<crate::syntax::Arg>, crate::syntax::parser::Ps)| k_let10745(parse_call_args_f_10785))
                    }
                } else {
                    k_let10745((crate::prelude::Array::new(), p1_pf.clone()))
                }
            },
            _ => ::prism_rtl::Turn::Finished((e_p0.clone(), crate::syntax::parser::error_at_f(&p_p4, &dot_p3, &crate::prelude::Text::lit("expected a field name or a `.Method` after `.`")), false)),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start FieldOrMethod, x`: what the function value is when passed to `@Run`.
pub fn start_field_or_method_f(e_p0: crate::syntax::Expr, p0_p1: crate::syntax::parser::Ps, commas_p2: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps, bool)>> {
    ::std::rc::Rc::new(FieldOrMethod { e_p0, p0_p1, commas_p2 })
}

/// ```prism
/// ParseTypeArgs: unbounded fn Ps -> (([Type], Ps))
/// ```
pub fn parse_type_args_f(p_p0: &crate::syntax::parser::Ps) -> (crate::prelude::Array<crate::syntax::Type>, crate::syntax::parser::Ps) {
    let (types_p1, q_p2) = crate::syntax::parser::commas_f(&crate::syntax::parser::adv_f(p_p0), &(::std::rc::Rc::new(|a0: crate::syntax::parser::Ps| crate::prelude::entered(crate::syntax::parser::types::start_parse_type_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>>>));
    if &crate::syntax::parser::kind_f(&q_p2) == &crate::syntax::lexer::TokKind::KGtGt {
        (types_p1.clone(), crate::syntax::parser::adv_f(&q_p2))
    } else {
        (types_p1.clone(), crate::syntax::parser::error_here_f(&q_p2, &crate::prelude::Text::lit("expected `>>` to close the type arguments")))
    }
}

/// The step machine of `ParseTypeArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTypeArgs: unbounded fn Ps -> (([Type], Ps))
/// ```
pub struct ParseTypeArgs {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::Type>, crate::syntax::parser::Ps)> for ParseTypeArgs {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::syntax::Type>, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(crate::syntax::parser::start_commas_f(crate::syntax::parser::adv_f(&p_p0x), ::std::rc::Rc::new(|a0: crate::syntax::parser::Ps| crate::prelude::entered(crate::syntax::parser::types::start_parse_type_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>>>), move |commas_f_11142: (crate::prelude::Array<crate::syntax::Type>, crate::syntax::parser::Ps)| {
            let (types_p1, q_p2) = commas_f_11142;
            if &crate::syntax::parser::kind_f(&q_p2) == &crate::syntax::lexer::TokKind::KGtGt {
                ::prism_rtl::Turn::Finished((types_p1.clone(), crate::syntax::parser::adv_f(&q_p2)))
            } else {
                ::prism_rtl::Turn::Finished((types_p1.clone(), crate::syntax::parser::error_here_f(&q_p2, &crate::prelude::Text::lit("expected `>>` to close the type arguments"))))
            }
        })
    }
}

/// `Start ParseTypeArgs, x`: what the function value is when passed to `@Run`.
pub fn start_parse_type_args_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::Type>, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseTypeArgs { p_p0 })
}

/// ```prism
/// ArgStartsHere: fn Ps -> Bool
/// ```
pub fn arg_starts_here_f(p_p0: &crate::syntax::parser::Ps) -> bool {
    let t_p1 = crate::syntax::parser::tk_f(p_p0);
    match &t_p1.kind_p {
        crate::syntax::lexer::TokKind::KName(_) => true,
        crate::syntax::lexer::TokKind::KInt(_, _) => true,
        crate::syntax::lexer::TokKind::KFloat(_, _) => true,
        crate::syntax::lexer::TokKind::KDuration(_, _, _) => true,
        crate::syntax::lexer::TokKind::KChar(_, _) => true,
        crate::syntax::lexer::TokKind::KText(_, _) => true,
        crate::syntax::lexer::TokKind::KRegex(_, _) => true,
        crate::syntax::lexer::TokKind::KTemplate(_) => true,
        crate::syntax::lexer::TokKind::KFree(_) => true,
        crate::syntax::lexer::TokKind::KLensDot => true,
        crate::syntax::lexer::TokKind::KBackslash => true,
        crate::syntax::lexer::TokKind::KAbsent => true,
        crate::syntax::lexer::TokKind::KOpen(m11459_12_0, prefix_p2) if (m11459_12_0 == &crate::prelude::Text::lit("[")) => (*prefix_p2 || !t_p1.touches_p) || crate::syntax::parser::at_double_open_f(p_p0, &crate::prelude::Text::lit("[")),
        crate::syntax::lexer::TokKind::KOpen(_, _) => true,
        crate::syntax::lexer::TokKind::KOp(op_p3, true) => (op_p3 == &crate::prelude::Text::lit("+")) || (op_p3 == &crate::prelude::Text::lit("-")),
        crate::syntax::lexer::TokKind::KDot(true) => !at_line_method_f(p_p0),
        crate::syntax::lexer::TokKind::KKw(w_p4, _) => crate::prelude::fold(&arg_words_p(), &false, &(|seen_p5: &bool, x_p6: &crate::prelude::Text| *seen_p5 || (x_p6 == w_p4))),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// let argWords
/// ```
pub fn arg_words_p() -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::Array::from(vec![crate::prelude::Text::lit("unit"), crate::prelude::Text::lit("nil"), crate::prelude::Text::lit("key"), crate::prelude::Text::lit("ix"), crate::prelude::Text::lit("jx"), crate::prelude::Text::lit("kx"), crate::prelude::Text::lit("not"), crate::prelude::Text::lit("any"), crate::prelude::Text::lit("given"), crate::prelude::Text::lit("update"), crate::prelude::Text::lit("match"), crate::prelude::Text::lit("rebuild"), crate::prelude::Text::lit("widget"), crate::prelude::Text::lit("output"), crate::prelude::Text::lit("inline_text"), crate::prelude::Text::lit("raw")])
}

/// ```prism
/// ParseCallArgs: unbounded fn Ps, Bool -> (([Arg], Ps))
/// ```
pub fn parse_call_args_f(p_p0: &crate::syntax::parser::Ps, commas_p1: &bool) -> (crate::prelude::Array<crate::syntax::Arg>, crate::syntax::parser::Ps) {
    if *commas_p1 && !p_p0.step_mode_p {
        crate::syntax::parser::commas_f(p_p0, &(::std::rc::Rc::new(|a0: crate::syntax::parser::Ps| crate::prelude::entered(start_parse_arg_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Arg, crate::syntax::parser::Ps)>>>))
    } else {
        parse_one_arg_f(p_p0)
    }
}

/// The step machine of `ParseCallArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseCallArgs: unbounded fn Ps, Bool -> (([Arg], Ps))
/// ```
pub struct ParseCallArgs {
    pub p_p0: crate::syntax::parser::Ps,
    pub commas_p1: bool,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::Arg>, crate::syntax::parser::Ps)> for ParseCallArgs {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::syntax::Arg>, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let commas_p1 = &self.commas_p1;
        if *commas_p1 && !p_p0.step_mode_p {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::syntax::parser::Commas { p0_p0: p_p0.clone(), f_f1: ::std::rc::Rc::new(|a0: crate::syntax::parser::Ps| crate::prelude::entered(start_parse_arg_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Arg, crate::syntax::parser::Ps)>>> }))
        } else {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(ParseOneArg { p_p0: p_p0.clone() }))
        }
    }
}

/// `Start ParseCallArgs, x`: what the function value is when passed to `@Run`.
pub fn start_parse_call_args_f(p_p0: crate::syntax::parser::Ps, commas_p1: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::Arg>, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseCallArgs { p_p0, commas_p1 })
}

/// ```prism
/// ParseOneArg: unbounded fn Ps -> (([Arg], Ps))
/// ```
pub fn parse_one_arg_f(p_p0: &crate::syntax::parser::Ps) -> (crate::prelude::Array<crate::syntax::Arg>, crate::syntax::parser::Ps) {
    let (a_p1, q_p2) = parse_arg_f(p_p0);
    (crate::prelude::Array::from(vec![a_p1.clone()]), q_p2.clone())
}

/// The step machine of `ParseOneArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseOneArg: unbounded fn Ps -> (([Arg], Ps))
/// ```
pub struct ParseOneArg {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::Arg>, crate::syntax::parser::Ps)> for ParseOneArg {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::syntax::Arg>, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(start_parse_arg_f(p_p0x.clone()), move |parse_arg_f_12711: (crate::syntax::Arg, crate::syntax::parser::Ps)| {
            let (a_p1, q_p2) = parse_arg_f_12711;
            ::prism_rtl::Turn::Finished((crate::prelude::Array::from(vec![a_p1.clone()]), q_p2.clone()))
        })
    }
}

/// `Start ParseOneArg, x`: what the function value is when passed to `@Run`.
pub fn start_parse_one_arg_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::Arg>, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseOneArg { p_p0 })
}

/// ```prism
/// ParseArg: unbounded fn Ps -> ((Arg, Ps))
/// ```
pub fn parse_arg_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Arg, crate::syntax::parser::Ps) {
    let (value_p1, q_p2) = parse_arg_expr_f(p_p0);
    (crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: value_p1.clone(), span_p: value_p1.span_p.clone() }, q_p2.clone())
}

/// The step machine of `ParseArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseArg: unbounded fn Ps -> ((Arg, Ps))
/// ```
pub struct ParseArg {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::Arg, crate::syntax::parser::Ps)> for ParseArg {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Arg, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(start_parse_arg_expr_f(p_p0x.clone()), move |parse_arg_expr_f_12819: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
            let (value_p1, q_p2) = parse_arg_expr_f_12819;
            ::prism_rtl::Turn::Finished((crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::None, value_p: value_p1.clone(), span_p: value_p1.span_p.clone() }, q_p2.clone()))
        })
    }
}

/// `Start ParseArg, x`: what the function value is when passed to `@Run`.
pub fn start_parse_arg_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Arg, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseArg { p_p0 })
}

/// ```prism
/// ParseParenArgs: unbounded fn Ps -> (([Arg], Bool, Ps))
/// ```
pub fn parse_paren_args_f(p0_p0: &crate::syntax::parser::Ps) -> (crate::prelude::Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps) {
    let p_p1 = crate::syntax::parser::adv_f(p0_p0);
    if crate::syntax::parser::at_close_f(&p_p1, &crate::prelude::Text::lit("(")) {
        (crate::prelude::Array::new(), false, crate::syntax::parser::adv_f(&p_p1))
    } else {
        {
            let r_p2 = {
                let mut this: ArgsRead = ArgsRead { args_p: crate::prelude::Array::new(), rest_p: false, p_p: p_p1.clone(), going_p: true };
                while this.going_p && !this.p_p.bad_p {
                    if &crate::syntax::parser::kind_f(&this.p_p) == &crate::syntax::lexer::TokKind::KDotDot {
                        this.p_p = crate::syntax::parser::adv_f(&this.p_p);
                        this.rest_p = true;
                    } else {
                        let start_p3 = crate::syntax::parser::here_f(&this.p_p);
                        let (name_o4, marks_p5, p1_p6) = parse_arg_name_f(&this.p_p);
                        let (value_p7, p2_p8) = parse_arg_expr_f(&p1_p6);
                        this.args_p = crate::prelude::push(&this.args_p, &crate::syntax::Arg { marks_p: marks_p5.clone(), name_o: name_o4.clone(), value_p: value_p7.clone(), span_p: crate::syntax::parser::to_f(&start_p3, &value_p7.span_p) });
                        this.p_p = p2_p8.clone();
                    }
                    if crate::syntax::parser::at_comma_f(&this.p_p) {
                        this.p_p = crate::syntax::parser::adv_f(&this.p_p);
                    } else {
                        this.p_p = crate::syntax::parser::expect_close_f(&this.p_p, &crate::prelude::Text::lit("("));
                        this.going_p = false;
                    }
                }
                this
            };
            (r_p2.args_p.clone(), r_p2.rest_p, r_p2.p_p.clone())
        }
    }
}

/// The step machine of `ParseParenArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseParenArgs: unbounded fn Ps -> (([Arg], Bool, Ps))
/// ```
pub struct ParseParenArgs {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps)> for ParseParenArgs {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let p_p1 = crate::syntax::parser::adv_f(p0_p0);
        if crate::syntax::parser::at_close_f(&p_p1, &crate::prelude::Text::lit("(")) {
            ::prism_rtl::Turn::Finished((crate::prelude::Array::new(), false, crate::syntax::parser::adv_f(&p_p1)))
        } else {
            {
                let mut this: ArgsRead = ArgsRead { args_p: crate::prelude::Array::new(), rest_p: false, p_p: p_p1.clone(), going_p: true };
                crate::prelude::call_then(crate::prelude::loop_job((this,), move |(mut this,): (ArgsRead,)| if this.going_p && !this.p_p.bad_p {
                    {
                        if &crate::syntax::parser::kind_f(&this.p_p) == &crate::syntax::lexer::TokKind::KDotDot {
                            this.p_p = crate::syntax::parser::adv_f(&this.p_p);
                            this.rest_p = true;
                        } else {
                            let start_p3 = crate::syntax::parser::here_f(&this.p_p);
                            let (name_o4, marks_p5, p1_p6) = parse_arg_name_f(&this.p_p);
                            let (value_p7, p2_p8) = parse_arg_expr_f(&p1_p6);
                            this.args_p = crate::prelude::push(&this.args_p, &crate::syntax::Arg { marks_p: marks_p5.clone(), name_o: name_o4.clone(), value_p: value_p7.clone(), span_p: crate::syntax::parser::to_f(&start_p3, &value_p7.span_p) });
                            this.p_p = p2_p8.clone();
                        }
                        if crate::syntax::parser::at_comma_f(&this.p_p) {
                            this.p_p = crate::syntax::parser::adv_f(&this.p_p);
                        } else {
                            this.p_p = crate::syntax::parser::expect_close_f(&this.p_p, &crate::prelude::Text::lit("("));
                            this.going_p = false;
                        }
                        ::std::result::Result::Ok((this,))
                    }
                } else {
                    ::std::result::Result::Err((this,))
                }), move |(mut this,): (ArgsRead,)| {
                    let r_p2 = this;
                    ::prism_rtl::Turn::Finished((r_p2.args_p.clone(), r_p2.rest_p, r_p2.p_p.clone()))
                })
            }
        }
    }
}

/// `Start ParseParenArgs, x`: what the function value is when passed to `@Run`.
pub fn start_parse_paren_args_f(p0_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseParenArgs { p0_p0 })
}

/// ```prism
/// ParseArgName: fn Ps -> ((?Ident, Text, Ps))
/// ```
pub fn parse_arg_name_f(p_p0: &crate::syntax::parser::Ps) -> (::std::option::Option<crate::syntax::Ident>, crate::prelude::Text, crate::syntax::parser::Ps) {
    match crate::syntax::parser::kind_f(p_p0) {
        crate::syntax::lexer::TokKind::KName(n_p1) if (((&crate::prelude::len(&n_p1.path_p) == &crate::prelude::Nat::from(1u32)) && (&n_p1.case_p == &crate::syntax::lexer::NameCase::CaseLower)) && crate::syntax::parser::at_op_f(&crate::syntax::parser::adv_f(p_p0), &crate::prelude::Text::lit("="))) => (::std::option::Option::Some(crate::syntax::Ident { name_p: crate::prelude::or(&crate::prelude::index(&n_p1.path_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")), span_p: crate::syntax::parser::here_f(p_p0) }), n_p1.sigils_p.clone(), crate::syntax::parser::adv_f(&crate::syntax::parser::adv_f(p_p0))),
        _ => (::std::option::Option::None, crate::prelude::Text::lit(""), p_p0.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParsePrimary: unbounded fn Ps, Bool -> ((Expr, Bool, Ps))
/// ```
pub fn parse_primary_f(p_p0: &crate::syntax::parser::Ps, commas_p1: &bool) -> (crate::syntax::Expr, bool, crate::syntax::parser::Ps) {
    let start_p2 = crate::syntax::parser::here_f(p_p0);
    let tok_p3 = crate::syntax::parser::tk_f(p_p0);
    match &tok_p3.kind_p {
        crate::syntax::lexer::TokKind::KName(n_p4) => name_primary_f(p_p0, n_p4, commas_p1),
        crate::syntax::lexer::TokKind::KKw(w_p5, sigils_p6) => keyword_primary_f(p_p0, w_p5, sigils_p6, commas_p1),
        crate::syntax::lexer::TokKind::KInt(_, _) => literal_primary_f(p_p0),
        crate::syntax::lexer::TokKind::KFloat(_, _) => literal_primary_f(p_p0),
        crate::syntax::lexer::TokKind::KDuration(_, _, _) => literal_primary_f(p_p0),
        crate::syntax::lexer::TokKind::KChar(_, _) => literal_primary_f(p_p0),
        crate::syntax::lexer::TokKind::KText(_, _) => literal_primary_f(p_p0),
        crate::syntax::lexer::TokKind::KRegex(_, _) => literal_primary_f(p_p0),
        crate::syntax::lexer::TokKind::KTemplate(t_p7) => {
            let (tpl_p8, q_p9) = parse_template_f(&crate::syntax::parser::adv_f(p_p0), t_p7, &tok_p3.span_p);
            (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ETemplate(tpl_p8.clone())), span_p: tok_p3.span_p.clone() }, false, q_p9.clone())
        },
        crate::syntax::lexer::TokKind::KOpen(m14785_9_0, _) if (m14785_9_0 == &crate::prelude::Text::lit("(")) => paren_primary_f(p_p0),
        crate::syntax::lexer::TokKind::KOpen(m14785_10_0, _) if (m14785_10_0 == &crate::prelude::Text::lit("[")) => square_primary_f(p_p0),
        crate::syntax::lexer::TokKind::KOpen(_, _) => map_primary_f(p_p0),
        crate::syntax::lexer::TokKind::KDot(true) => {
            let p1_pa = crate::syntax::parser::adv_f(p_p0);
            match crate::syntax::parser::kind_f(&p1_pa) {
                crate::syntax::lexer::TokKind::KName(n_pb) if (((&n_pb.sigils_p == &crate::prelude::Text::lit("")) && (&crate::prelude::len(&n_pb.path_p) == &crate::prelude::Nat::from(1u32))) && (&n_pb.case_p == &crate::syntax::lexer::NameCase::CaseLower)) => {
                    let t_pc = crate::syntax::parser::here_f(&p1_pa);
                    (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ETopicField(crate::syntax::Ident { name_p: crate::prelude::or(&crate::prelude::index(&n_pb.path_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")), span_p: t_pc.clone() })), span_p: crate::syntax::parser::to_f(&start_p2, &t_pc) }, false, crate::syntax::parser::adv_f(&p1_pa))
                },
                crate::syntax::lexer::TokKind::KName(n_pd) if (&n_pd.case_p == &crate::syntax::lexer::NameCase::CaseUpper) => (crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(&p1_pa, &start_p2, &crate::prelude::Text::from(format!("a spaced `.{}` begins its own line, below the call it takes as its receiver (layout rule 9)", &crate::syntax::lexer::chars::join_f(&n_pd.path_p, &crate::prelude::Text::lit(".")))))),
                _ => (crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(&p1_pa, &start_p2, &crate::prelude::Text::lit("a prefix `.` takes a field name, applied to the topic `_`"))),
                _ => unreachable!("no arm matched"),
            }
        },
        crate::syntax::lexer::TokKind::KLensDot => lens_primary_f(p_p0),
        crate::syntax::lexer::TokKind::KFree(s_pe) => if s_pe == &crate::prelude::Text::lit("!") {
            (crate::syntax::parser::decls::no_expr_p(), true, crate::syntax::parser::error_at_f(&crate::syntax::parser::adv_f(p_p0), &tok_p3.span_p, &crate::prelude::Text::lit("`!` is never free: no event fires a constant")))
        } else {
            if s_pe == &crate::prelude::Text::lit("&") {
                (crate::syntax::parser::decls::no_expr_p(), true, crate::syntax::parser::error_at_f(&crate::syntax::parser::adv_f(p_p0), &tok_p3.span_p, &crate::prelude::Text::lit("`&` is never free: no reference exists outside the value an `update` block names")))
            } else {
                {
                    let (operand_pf, q_pg) = parse_expr_ctx_f(&crate::syntax::parser::adv_f(p_p0), commas_p1);
                    (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EFreeSigil(s_pe.clone(), ::std::rc::Rc::new(operand_pf.clone()))), span_p: crate::syntax::parser::to_f(&start_p2, &operand_pf.span_p) }, true, q_pg.clone())
                }
            }
        },
        crate::syntax::lexer::TokKind::KBackslash => {
            let (e_ph, q_pi) = parse_lambda_f(p_p0);
            (e_ph.clone(), true, q_pi.clone())
        },
        crate::syntax::lexer::TokKind::KAbsent => {
            let q_pj = crate::syntax::parser::out_of_scope_f(&crate::syntax::parser::adv_f(p_p0), &tok_p3.span_p, &crate::prelude::Text::lit("sparse tuples"), &crate::prelude::Text::lit("an absent component `-` makes a sparse tuple, which is out of this compiler"));
            (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EAbsent), span_p: tok_p3.span_p.clone() }, false, q_pj.clone())
        },
        crate::syntax::lexer::TokKind::KDotDot => (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ERest), span_p: tok_p3.span_p.clone() }, false, crate::syntax::parser::adv_f(p_p0)),
        crate::syntax::lexer::TokKind::KTrait(_) => (crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, &tok_p3.span_p, &crate::prelude::Text::lit("no trait is a value: a `^Trait` stands in a type, a bound, `derive`, `trait` or `impl`"))),
        crate::syntax::lexer::TokKind::KFamily(path_pk) => (crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, &tok_p3.span_p, &crate::prelude::Text::from(format!("`{}.*` names every tag of a family: it stands in a pattern, an `emit` row or a `use`, not in an expression", &crate::syntax::lexer::chars::join_f(path_pk, &crate::prelude::Text::lit(".")))))),
        crate::syntax::lexer::TokKind::KBar => (crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, &tok_p3.span_p, &crate::prelude::Text::lit("a bare `|` is not an operator: the merge is `<|`, and `|` separates the families of a row"))),
        _ => (crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_here_f(p_p0, &crate::prelude::Text::lit("expected an expression"))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ParsePrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParsePrimary: unbounded fn Ps, Bool -> ((Expr, Bool, Ps))
/// ```
pub struct ParsePrimary {
    pub p_p0: crate::syntax::parser::Ps,
    pub commas_p1: bool,
}

impl ::prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> for ParsePrimary {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let commas_p1 = &self.commas_p1;
        let start_p2 = crate::syntax::parser::here_f(p_p0);
        let tok_p3 = crate::syntax::parser::tk_f(p_p0);
        match &tok_p3.kind_p {
            crate::syntax::lexer::TokKind::KName(n_p4) => ::prism_rtl::Turn::More(::std::rc::Rc::new(NamePrimary { p0_p0: p_p0.clone(), n_p1: n_p4.clone(), commas_p2: *commas_p1 })),
            crate::syntax::lexer::TokKind::KKw(w_p5, sigils_p6) => ::prism_rtl::Turn::More(::std::rc::Rc::new(KeywordPrimary { p_p0: p_p0.clone(), w_p1: w_p5.clone(), sigils_p2: sigils_p6.clone(), commas_p3: *commas_p1 })),
            crate::syntax::lexer::TokKind::KInt(_, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(LiteralPrimary { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KFloat(_, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(LiteralPrimary { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KDuration(_, _, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(LiteralPrimary { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KChar(_, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(LiteralPrimary { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KText(_, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(LiteralPrimary { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KRegex(_, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(LiteralPrimary { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KTemplate(t_p7) => {
                let p_p0x = p_p0.clone();
                let t_p7x = t_p7.clone();
                crate::prelude::call_then(start_parse_template_f(crate::syntax::parser::adv_f(&p_p0x), t_p7x.clone(), tok_p3.span_p.clone()), move |parse_template_f_15247: (crate::syntax::Template, crate::syntax::parser::Ps)| {
                    let (tpl_p8, q_p9) = parse_template_f_15247;
                    ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ETemplate(tpl_p8.clone())), span_p: tok_p3.span_p.clone() }, false, q_p9.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KOpen(m14785_9_0, _) if (m14785_9_0 == &crate::prelude::Text::lit("(")) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ParenPrimary { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KOpen(m14785_10_0, _) if (m14785_10_0 == &crate::prelude::Text::lit("[")) => ::prism_rtl::Turn::More(::std::rc::Rc::new(SquarePrimary { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KOpen(_, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(MapPrimary { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KDot(true) => {
                let p1_pa = crate::syntax::parser::adv_f(p_p0);
                match crate::syntax::parser::kind_f(&p1_pa) {
                    crate::syntax::lexer::TokKind::KName(n_pb) if (((&n_pb.sigils_p == &crate::prelude::Text::lit("")) && (&crate::prelude::len(&n_pb.path_p) == &crate::prelude::Nat::from(1u32))) && (&n_pb.case_p == &crate::syntax::lexer::NameCase::CaseLower)) => {
                        let t_pc = crate::syntax::parser::here_f(&p1_pa);
                        ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ETopicField(crate::syntax::Ident { name_p: crate::prelude::or(&crate::prelude::index(&n_pb.path_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")), span_p: t_pc.clone() })), span_p: crate::syntax::parser::to_f(&start_p2, &t_pc) }, false, crate::syntax::parser::adv_f(&p1_pa)))
                    },
                    crate::syntax::lexer::TokKind::KName(n_pd) if (&n_pd.case_p == &crate::syntax::lexer::NameCase::CaseUpper) => ::prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(&p1_pa, &start_p2, &crate::prelude::Text::from(format!("a spaced `.{}` begins its own line, below the call it takes as its receiver (layout rule 9)", &crate::syntax::lexer::chars::join_f(&n_pd.path_p, &crate::prelude::Text::lit("."))))))),
                    _ => ::prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(&p1_pa, &start_p2, &crate::prelude::Text::lit("a prefix `.` takes a field name, applied to the topic `_`")))),
                    _ => unreachable!("no arm matched"),
                }
            },
            crate::syntax::lexer::TokKind::KLensDot => ::prism_rtl::Turn::More(::std::rc::Rc::new(LensPrimary { p0_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KFree(s_pe) => if s_pe == &crate::prelude::Text::lit("!") {
                ::prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr_p(), true, crate::syntax::parser::error_at_f(&crate::syntax::parser::adv_f(p_p0), &tok_p3.span_p, &crate::prelude::Text::lit("`!` is never free: no event fires a constant"))))
            } else {
                if s_pe == &crate::prelude::Text::lit("&") {
                    ::prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr_p(), true, crate::syntax::parser::error_at_f(&crate::syntax::parser::adv_f(p_p0), &tok_p3.span_p, &crate::prelude::Text::lit("`&` is never free: no reference exists outside the value an `update` block names"))))
                } else {
                    {
                        let commas_p1x = *commas_p1;
                        let p_p0x = p_p0.clone();
                        let s_pex = s_pe.clone();
                        crate::prelude::call_then(start_parse_expr_ctx_f(crate::syntax::parser::adv_f(&p_p0x), commas_p1x), move |parse_expr_ctx_f_16763: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                            let (operand_pf, q_pg) = parse_expr_ctx_f_16763;
                            ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EFreeSigil(s_pex.clone(), ::std::rc::Rc::new(operand_pf.clone()))), span_p: crate::syntax::parser::to_f(&start_p2, &operand_pf.span_p) }, true, q_pg.clone()))
                        })
                    }
                }
            },
            crate::syntax::lexer::TokKind::KBackslash => {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(start_parse_lambda_f(p_p0x.clone()), move |parse_lambda_f_16934: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (e_ph, q_pi) = parse_lambda_f_16934;
                    ::prism_rtl::Turn::Finished((e_ph.clone(), true, q_pi.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KAbsent => {
                let q_pj = crate::syntax::parser::out_of_scope_f(&crate::syntax::parser::adv_f(p_p0), &tok_p3.span_p, &crate::prelude::Text::lit("sparse tuples"), &crate::prelude::Text::lit("an absent component `-` makes a sparse tuple, which is out of this compiler"));
                ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EAbsent), span_p: tok_p3.span_p.clone() }, false, q_pj.clone()))
            },
            crate::syntax::lexer::TokKind::KDotDot => ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ERest), span_p: tok_p3.span_p.clone() }, false, crate::syntax::parser::adv_f(p_p0))),
            crate::syntax::lexer::TokKind::KTrait(_) => ::prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, &tok_p3.span_p, &crate::prelude::Text::lit("no trait is a value: a `^Trait` stands in a type, a bound, `derive`, `trait` or `impl`")))),
            crate::syntax::lexer::TokKind::KFamily(path_pk) => ::prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, &tok_p3.span_p, &crate::prelude::Text::from(format!("`{}.*` names every tag of a family: it stands in a pattern, an `emit` row or a `use`, not in an expression", &crate::syntax::lexer::chars::join_f(path_pk, &crate::prelude::Text::lit("."))))))),
            crate::syntax::lexer::TokKind::KBar => ::prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, &tok_p3.span_p, &crate::prelude::Text::lit("a bare `|` is not an operator: the merge is `<|`, and `|` separates the families of a row")))),
            _ => ::prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_here_f(p_p0, &crate::prelude::Text::lit("expected an expression")))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ParsePrimary, x`: what the function value is when passed to `@Run`.
pub fn start_parse_primary_f(p_p0: crate::syntax::parser::Ps, commas_p1: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParsePrimary { p_p0, commas_p1 })
}

/// ```prism
/// LiteralPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub fn literal_primary_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, bool, crate::syntax::parser::Ps) {
    let (lit_p1, q_p2) = parse_literal_f(p_p0);
    (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ELit(lit_p1.clone())), span_p: lit_p1.span_p.clone() }, false, q_p2.clone())
}

/// The step machine of `LiteralPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LiteralPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub struct LiteralPrimary {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> for LiteralPrimary {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(start_parse_literal_f(p_p0x.clone()), move |parse_literal_f_17930: (crate::syntax::Literal, crate::syntax::parser::Ps)| {
            let (lit_p1, q_p2) = parse_literal_f_17930;
            ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ELit(lit_p1.clone())), span_p: lit_p1.span_p.clone() }, false, q_p2.clone()))
        })
    }
}

/// `Start LiteralPrimary, x`: what the function value is when passed to `@Run`.
pub fn start_literal_primary_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(LiteralPrimary { p_p0 })
}

/// ```prism
/// NamePrimary: unbounded fn Ps, NameTok, Bool -> ((Expr, Bool, Ps))
/// ```
pub fn name_primary_f(p0_p0: &crate::syntax::parser::Ps, n_p1: &crate::syntax::lexer::NameTok, commas_p2: &bool) -> (crate::syntax::Expr, bool, crate::syntax::parser::Ps) {
    let start_p3 = crate::syntax::parser::here_f(p0_p0);
    let name_p4 = crate::syntax::SName { sigils_p: n_p1.sigils_p.clone(), path_p: n_p1.path_p.clone(), span_p: start_p3.clone() };
    let p1_p5 = crate::syntax::parser::check_name_scope_f(&crate::syntax::parser::adv_f(p0_p0), &name_p4);
    let plain_p6 = crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EName(name_p4.clone())), span_p: start_p3.clone() };
    let (e_p7, p_p8) = if &crate::syntax::parser::kind_f(&p1_p5) == &crate::syntax::lexer::TokKind::KLtLt {
        type_args_on_f(&plain_p6, &p1_p5, &start_p3)
    } else {
        (plain_p6.clone(), p1_p5.clone())
    };
    if crate::syntax::parser::is_callee_f(&name_p4) {
        if crate::syntax::parser::at_single_open_f(&p_p8, &crate::prelude::Text::lit("(")) && crate::syntax::parser::tk_f(&p_p8).touches_p {
            {
                let (args_p9, rest_pa, q_pb) = parse_paren_args_f(&p_p8);
                (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ECall(::std::rc::Rc::new(e_p7.clone()), args_p9.clone(), true, rest_pa)), span_p: crate::syntax::parser::to_f(&start_p3, &crate::syntax::parser::prev_f(&q_pb)) }, false, q_pb.clone())
            }
        } else {
            if crate::syntax::parser::at_kw_f(&p_p8, &crate::prelude::Text::lit("monad")) {
                {
                    let kw_pc = crate::syntax::parser::here_f(&p_p8);
                    let (body_pd, q_pe) = crate::syntax::parser::blocks::parse_block_after_colon_f(&crate::syntax::parser::out_of_scope_f(&crate::syntax::parser::adv_f(&p_p8), &kw_pc, &crate::prelude::Text::lit("`T monad:` blocks and `^Monad`"), &crate::prelude::Text::lit("monad blocks are out of this compiler")));
                    (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EMonad(::std::rc::Rc::new(e_p7.clone()), body_pd.clone())), span_p: crate::syntax::parser::to_f(&start_p3, &body_pd.span_p) }, true, q_pe.clone())
                }
            } else {
                if arg_starts_here_f(&p_p8) {
                    {
                        let (args_pf, q_pg) = parse_call_args_f(&p_p8, commas_p2);
                        (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ECall(::std::rc::Rc::new(e_p7.clone()), args_pf.clone(), false, false)), span_p: crate::syntax::parser::to_f(&start_p3, &crate::syntax::parser::prev_f(&q_pg)) }, true, q_pg.clone())
                    }
                } else {
                    (e_p7.clone(), false, p_p8.clone())
                }
            }
        }
    } else {
        if (crate::syntax::parser::at_single_open_f(&p_p8, &crate::prelude::Text::lit("(")) && crate::syntax::parser::tk_f(&p_p8).touches_p) && !crate::syntax::parser::is_topic_f(&name_p4) {
            (e_p7.clone(), false, crate::syntax::parser::error_at_f(&p_p8, &crate::syntax::parser::here_f(&p_p8), &crate::prelude::Text::from(format!("`{}` is a value and is not applied: a function\'s name is uppercase (case is a mark)", &crate::syntax::parser::name_text_f(&name_p4)))))
        } else {
            (e_p7.clone(), false, p_p8.clone())
        }
    }
}

/// The step machine of `NamePrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamePrimary: unbounded fn Ps, NameTok, Bool -> ((Expr, Bool, Ps))
/// ```
pub struct NamePrimary {
    pub p0_p0: crate::syntax::parser::Ps,
    pub n_p1: crate::syntax::lexer::NameTok,
    pub commas_p2: bool,
}

impl ::prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> for NamePrimary {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let n_p1 = &self.n_p1;
        let commas_p2 = &self.commas_p2;
        let start_p3 = crate::syntax::parser::here_f(p0_p0);
        let name_p4 = crate::syntax::SName { sigils_p: n_p1.sigils_p.clone(), path_p: n_p1.path_p.clone(), span_p: start_p3.clone() };
        let p1_p5 = crate::syntax::parser::check_name_scope_f(&crate::syntax::parser::adv_f(p0_p0), &name_p4);
        let plain_p6 = crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EName(name_p4.clone())), span_p: start_p3.clone() };
        let commas_p2z = *commas_p2;
        let name_p4z = name_p4.clone();
        let start_p3z = start_p3.clone();
        let k_let18283 = move |v18283: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
            let (e_p7, p_p8) = v18283;
            if crate::syntax::parser::is_callee_f(&name_p4z) {
                if crate::syntax::parser::at_single_open_f(&p_p8, &crate::prelude::Text::lit("(")) && crate::syntax::parser::tk_f(&p_p8).touches_p {
                    crate::prelude::call_then(start_parse_paren_args_f(p_p8.clone()), move |parse_paren_args_f_18553: (crate::prelude::Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps)| {
                        let (args_p9, rest_pa, q_pb) = parse_paren_args_f_18553;
                        ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ECall(::std::rc::Rc::new(e_p7.clone()), args_p9.clone(), true, rest_pa)), span_p: crate::syntax::parser::to_f(&start_p3z, &crate::syntax::parser::prev_f(&q_pb)) }, false, q_pb.clone()))
                    })
                } else {
                    if crate::syntax::parser::at_kw_f(&p_p8, &crate::prelude::Text::lit("monad")) {
                        {
                            let kw_pc = crate::syntax::parser::here_f(&p_p8);
                            crate::prelude::call_then(crate::syntax::parser::blocks::start_parse_block_after_colon_f(crate::syntax::parser::out_of_scope_f(&crate::syntax::parser::adv_f(&p_p8), &kw_pc, &crate::prelude::Text::lit("`T monad:` blocks and `^Monad`"), &crate::prelude::Text::lit("monad blocks are out of this compiler"))), move |parse_block_after_colon_f_18804: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                                let (body_pd, q_pe) = parse_block_after_colon_f_18804;
                                ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EMonad(::std::rc::Rc::new(e_p7.clone()), body_pd.clone())), span_p: crate::syntax::parser::to_f(&start_p3z, &body_pd.span_p) }, true, q_pe.clone()))
                            })
                        }
                    } else {
                        if arg_starts_here_f(&p_p8) {
                            crate::prelude::call_then(start_parse_call_args_f(p_p8.clone(), commas_p2z), move |parse_call_args_f_19070: (crate::prelude::Array<crate::syntax::Arg>, crate::syntax::parser::Ps)| {
                                let (args_pf, q_pg) = parse_call_args_f_19070;
                                ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ECall(::std::rc::Rc::new(e_p7.clone()), args_pf.clone(), false, false)), span_p: crate::syntax::parser::to_f(&start_p3z, &crate::syntax::parser::prev_f(&q_pg)) }, true, q_pg.clone()))
                            })
                        } else {
                            ::prism_rtl::Turn::Finished((e_p7.clone(), false, p_p8.clone()))
                        }
                    }
                }
            } else {
                if (crate::syntax::parser::at_single_open_f(&p_p8, &crate::prelude::Text::lit("(")) && crate::syntax::parser::tk_f(&p_p8).touches_p) && !crate::syntax::parser::is_topic_f(&name_p4z) {
                    ::prism_rtl::Turn::Finished((e_p7.clone(), false, crate::syntax::parser::error_at_f(&p_p8, &crate::syntax::parser::here_f(&p_p8), &crate::prelude::Text::from(format!("`{}` is a value and is not applied: a function\'s name is uppercase (case is a mark)", &crate::syntax::parser::name_text_f(&name_p4z))))))
                } else {
                    ::prism_rtl::Turn::Finished((e_p7.clone(), false, p_p8.clone()))
                }
            }
        };
        if &crate::syntax::parser::kind_f(&p1_p5) == &crate::syntax::lexer::TokKind::KLtLt {
            crate::prelude::call_then(start_type_args_on_f(plain_p6.clone(), p1_p5.clone(), start_p3.clone()), move |type_args_on_f_18321: (crate::syntax::Expr, crate::syntax::parser::Ps)| k_let18283(type_args_on_f_18321))
        } else {
            k_let18283((plain_p6.clone(), p1_p5.clone()))
        }
    }
}

/// `Start NamePrimary, x`: what the function value is when passed to `@Run`.
pub fn start_name_primary_f(p0_p0: crate::syntax::parser::Ps, n_p1: crate::syntax::lexer::NameTok, commas_p2: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(NamePrimary { p0_p0, n_p1, commas_p2 })
}

/// ```prism
/// TypeArgsOn: unbounded fn Expr, Ps, Range -> ((Expr, Ps))
/// ```
pub fn type_args_on_f(e_p0: &crate::syntax::Expr, p_p1: &crate::syntax::parser::Ps, start_p2: &crate::syntax::Range) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let (types_p3, q_p4) = parse_type_args_f(p_p1);
    (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ETypeArgs(::std::rc::Rc::new(e_p0.clone()), types_p3.clone())), span_p: crate::syntax::parser::to_f(start_p2, &crate::syntax::parser::prev_f(&q_p4)) }, q_p4.clone())
}

/// The step machine of `TypeArgsOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeArgsOn: unbounded fn Expr, Ps, Range -> ((Expr, Ps))
/// ```
pub struct TypeArgsOn {
    pub e_p0: crate::syntax::Expr,
    pub p_p1: crate::syntax::parser::Ps,
    pub start_p2: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for TypeArgsOn {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let e_p0 = &self.e_p0;
        let p_p1 = &self.p_p1;
        let start_p2 = &self.start_p2;
        let e_p0x = e_p0.clone();
        let p_p1x = p_p1.clone();
        let start_p2x = start_p2.clone();
        crate::prelude::call_then(start_parse_type_args_f(p_p1x.clone()), move |parse_type_args_f_19573: (crate::prelude::Array<crate::syntax::Type>, crate::syntax::parser::Ps)| {
            let (types_p3, q_p4) = parse_type_args_f_19573;
            ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ETypeArgs(::std::rc::Rc::new(e_p0x.clone()), types_p3.clone())), span_p: crate::syntax::parser::to_f(&start_p2x, &crate::syntax::parser::prev_f(&q_p4)) }, q_p4.clone()))
        })
    }
}

/// `Start TypeArgsOn, x`: what the function value is when passed to `@Run`.
pub fn start_type_args_on_f(e_p0: crate::syntax::Expr, p_p1: crate::syntax::parser::Ps, start_p2: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(TypeArgsOn { e_p0, p_p1, start_p2 })
}

/// ```prism
/// ParenPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub fn paren_primary_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, bool, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p_p0);
    if crate::syntax::parser::at_double_open_f(p_p0, &crate::prelude::Text::lit("(")) {
        {
            let (elems_p3, p1_p4) = crate::syntax::parser::commas_f(&crate::syntax::parser::open_double_f(p_p0), &(::std::rc::Rc::new(|a0: crate::syntax::parser::Ps| crate::prelude::entered(start_parse_arg_expr_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>));
            let p2_p2 = crate::syntax::parser::close_double_f(&p1_p4, &crate::prelude::Text::lit("("));
            (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ETuple(elems_p3.clone())), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&p2_p2)) }, false, p2_p2.clone())
        }
    } else {
        {
            let (inner_p5, p1_p6) = crate::syntax::parser::bracketed_f(&crate::syntax::parser::adv_f(p_p0), &(::std::rc::Rc::new(|a0: crate::syntax::parser::Ps| crate::prelude::entered(start_parse_rhs_expr_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>));
            if crate::syntax::parser::at_comma_f(&p1_p6) {
                (crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(&p1_p6, &crate::syntax::parser::here_f(&p1_p6), &crate::prelude::Text::lit("a group holds one expression: a comma here needs a call at the group\'s head, or `((` `))` for a tuple")))
            } else {
                {
                    let p2_p7 = crate::syntax::parser::expect_close_f(&p1_p6, &crate::prelude::Text::lit("("));
                    (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EGroup(::std::rc::Rc::new(inner_p5.clone()))), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&p2_p7)) }, false, p2_p7.clone())
                }
            }
        }
    }
}

/// The step machine of `ParenPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParenPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub struct ParenPrimary {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> for ParenPrimary {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here_f(p_p0);
        if crate::syntax::parser::at_double_open_f(p_p0, &crate::prelude::Text::lit("(")) {
            {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(crate::syntax::parser::start_commas_f(crate::syntax::parser::open_double_f(&p_p0x), ::std::rc::Rc::new(|a0: crate::syntax::parser::Ps| crate::prelude::entered(start_parse_arg_expr_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>), move |commas_f_19903: (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::parser::Ps)| {
                    let (elems_p3, p1_p4) = commas_f_19903;
                    let p2_p2 = crate::syntax::parser::close_double_f(&p1_p4, &crate::prelude::Text::lit("("));
                    ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ETuple(elems_p3.clone())), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&p2_p2)) }, false, p2_p2.clone()))
                })
            }
        } else {
            {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(crate::syntax::parser::start_bracketed_f(crate::syntax::parser::adv_f(&p_p0x), ::std::rc::Rc::new(|a0: crate::syntax::parser::Ps| crate::prelude::entered(start_parse_rhs_expr_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>), move |bracketed_f_20167: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (inner_p5, p1_p6) = bracketed_f_20167;
                    if crate::syntax::parser::at_comma_f(&p1_p6) {
                        ::prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(&p1_p6, &crate::syntax::parser::here_f(&p1_p6), &crate::prelude::Text::lit("a group holds one expression: a comma here needs a call at the group\'s head, or `((` `))` for a tuple"))))
                    } else {
                        {
                            let p2_p7 = crate::syntax::parser::expect_close_f(&p1_p6, &crate::prelude::Text::lit("("));
                            ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EGroup(::std::rc::Rc::new(inner_p5.clone()))), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&p2_p7)) }, false, p2_p7.clone()))
                        }
                    }
                })
            }
        }
    }
}

/// `Start ParenPrimary, x`: what the function value is when passed to `@Run`.
pub fn start_paren_primary_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParenPrimary { p_p0 })
}

/// ```prism
/// SquarePrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub fn square_primary_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, bool, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p_p0);
    if crate::syntax::parser::at_double_open_f(p_p0, &crate::prelude::Text::lit("[")) {
        {
            let p1_p2 = crate::syntax::parser::open_double_f(p_p0);
            let (elems_p4, p2_p5) = if crate::syntax::parser::at_close_f(&p1_p2, &crate::prelude::Text::lit("[")) {
                (crate::prelude::Array::new(), p1_p2.clone())
            } else {
                crate::syntax::parser::commas_f(&p1_p2, &(::std::rc::Rc::new(|a0: crate::syntax::parser::Ps| crate::prelude::entered(start_parse_arg_expr_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>))
            };
            let p3_p3 = crate::syntax::parser::close_double_f(&p2_p5, &crate::prelude::Text::lit("["));
            (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EArray(elems_p4.clone())), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&p3_p3)) }, false, p3_p3.clone())
        }
    } else {
        {
            let (index_p7, p1_p8) = crate::syntax::parser::bracketed_f(&crate::syntax::parser::adv_f(p_p0), &(::std::rc::Rc::new(|a0: crate::syntax::parser::Ps| crate::prelude::entered(start_parse_expr_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>));
            let p2_p6 = crate::syntax::parser::expect_close_f(&p1_p8, &crate::prelude::Text::lit("["));
            (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ETopicIndex(::std::rc::Rc::new(index_p7.clone()))), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&p2_p6)) }, false, p2_p6.clone())
        }
    }
}

/// The step machine of `SquarePrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SquarePrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub struct SquarePrimary {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> for SquarePrimary {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here_f(p_p0);
        if crate::syntax::parser::at_double_open_f(p_p0, &crate::prelude::Text::lit("[")) {
            {
                let p1_p2 = crate::syntax::parser::open_double_f(p_p0);
                let start_p1z = start_p1.clone();
                let k_let20756 = move |v20756: (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::parser::Ps)| {
                    let (elems_p4, p2_p5) = v20756;
                    let p3_p3 = crate::syntax::parser::close_double_f(&p2_p5, &crate::prelude::Text::lit("["));
                    ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EArray(elems_p4.clone())), span_p: crate::syntax::parser::to_f(&start_p1z, &crate::syntax::parser::prev_f(&p3_p3)) }, false, p3_p3.clone()))
                };
                if crate::syntax::parser::at_close_f(&p1_p2, &crate::prelude::Text::lit("[")) {
                    k_let20756((crate::prelude::Array::new(), p1_p2.clone()))
                } else {
                    crate::prelude::call_then(crate::syntax::parser::start_commas_f(p1_p2.clone(), ::std::rc::Rc::new(|a0: crate::syntax::parser::Ps| crate::prelude::entered(start_parse_arg_expr_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>), move |commas_f_20815: (crate::prelude::Array<crate::syntax::Expr>, crate::syntax::parser::Ps)| k_let20756(commas_f_20815))
                }
            }
        } else {
            {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(crate::syntax::parser::start_bracketed_f(crate::syntax::parser::adv_f(&p_p0x), ::std::rc::Rc::new(|a0: crate::syntax::parser::Ps| crate::prelude::entered(start_parse_expr_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>), move |bracketed_f_20991: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (index_p7, p1_p8) = bracketed_f_20991;
                    let p2_p6 = crate::syntax::parser::expect_close_f(&p1_p8, &crate::prelude::Text::lit("["));
                    ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ETopicIndex(::std::rc::Rc::new(index_p7.clone()))), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&p2_p6)) }, false, p2_p6.clone()))
                })
            }
        }
    }
}

/// `Start SquarePrimary, x`: what the function value is when passed to `@Run`.
pub fn start_square_primary_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(SquarePrimary { p_p0 })
}

/// ```prism
/// MapPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub fn map_primary_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, bool, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p_p0);
    let p1_p2 = crate::syntax::parser::adv_f(p_p0);
    let (entries_p4, p2_p5) = if crate::syntax::parser::at_close_f(&p1_p2, &crate::prelude::Text::lit("{")) {
        (crate::prelude::Array::new(), p1_p2.clone())
    } else {
        crate::syntax::parser::commas_f(&p1_p2, &(::std::rc::Rc::new(|a0: crate::syntax::parser::Ps| crate::prelude::entered(start_parse_map_entry_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<((crate::syntax::Expr, crate::syntax::Expr), crate::syntax::parser::Ps)>>>))
    };
    let p3_p3 = crate::syntax::parser::expect_close_f(&p2_p5, &crate::prelude::Text::lit("{"));
    (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EMap(entries_p4.clone())), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&p3_p3)) }, false, p3_p3.clone())
}

/// The step machine of `MapPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MapPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub struct MapPrimary {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> for MapPrimary {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here_f(p_p0);
        let p1_p2 = crate::syntax::parser::adv_f(p_p0);
        let start_p1z = start_p1.clone();
        let k_let21282 = move |v21282: (crate::prelude::Array<(crate::syntax::Expr, crate::syntax::Expr)>, crate::syntax::parser::Ps)| {
            let (entries_p4, p2_p5) = v21282;
            let p3_p3 = crate::syntax::parser::expect_close_f(&p2_p5, &crate::prelude::Text::lit("{"));
            ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EMap(entries_p4.clone())), span_p: crate::syntax::parser::to_f(&start_p1z, &crate::syntax::parser::prev_f(&p3_p3)) }, false, p3_p3.clone()))
        };
        if crate::syntax::parser::at_close_f(&p1_p2, &crate::prelude::Text::lit("{")) {
            k_let21282((crate::prelude::Array::new(), p1_p2.clone()))
        } else {
            crate::prelude::call_then(crate::syntax::parser::start_commas_f(p1_p2.clone(), ::std::rc::Rc::new(|a0: crate::syntax::parser::Ps| crate::prelude::entered(start_parse_map_entry_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<((crate::syntax::Expr, crate::syntax::Expr), crate::syntax::parser::Ps)>>>), move |commas_f_21344: (crate::prelude::Array<(crate::syntax::Expr, crate::syntax::Expr)>, crate::syntax::parser::Ps)| k_let21282(commas_f_21344))
        }
    }
}

/// `Start MapPrimary, x`: what the function value is when passed to `@Run`.
pub fn start_map_primary_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(MapPrimary { p_p0 })
}

/// ```prism
/// ParseMapEntry: unbounded fn Ps -> ((((Expr, Expr)), Ps))
/// ```
pub fn parse_map_entry_f(p_p0: &crate::syntax::parser::Ps) -> ((crate::syntax::Expr, crate::syntax::Expr), crate::syntax::parser::Ps) {
    let (k_p1, p1_p2) = parse_arg_expr_f(p_p0);
    let (v_p3, p2_p4) = parse_arg_expr_f(&crate::syntax::parser::expect_colon_f(&p1_p2));
    ((k_p1.clone(), v_p3.clone()), p2_p4.clone())
}

/// The step machine of `ParseMapEntry`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseMapEntry: unbounded fn Ps -> ((((Expr, Expr)), Ps))
/// ```
pub struct ParseMapEntry {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<((crate::syntax::Expr, crate::syntax::Expr), crate::syntax::parser::Ps)> for ParseMapEntry {
    fn cycle(&self) -> ::prism_rtl::Turn<((crate::syntax::Expr, crate::syntax::Expr), crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(start_parse_arg_expr_f(p_p0x.clone()), move |parse_arg_expr_f_21574: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
            let (k_p1, p1_p2) = parse_arg_expr_f_21574;
            crate::prelude::call_then(start_parse_arg_expr_f(crate::syntax::parser::expect_colon_f(&p1_p2)), move |parse_arg_expr_f_21609: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                let (v_p3, p2_p4) = parse_arg_expr_f_21609;
                ::prism_rtl::Turn::Finished(((k_p1.clone(), v_p3.clone()), p2_p4.clone()))
            })
        })
    }
}

/// `Start ParseMapEntry, x`: what the function value is when passed to `@Run`.
pub fn start_parse_map_entry_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<((crate::syntax::Expr, crate::syntax::Expr), crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseMapEntry { p_p0 })
}

/// ```prism
/// LensPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub fn lens_primary_f(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, bool, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p0_p0);
    let r_p2 = {
        let mut this: (crate::prelude::Array<crate::syntax::Ident>, crate::syntax::parser::Ps) = (crate::prelude::Array::new(), crate::syntax::parser::adv_f(p0_p0));
        let mut path_p3: crate::prelude::Array<crate::syntax::Ident> = crate::prelude::Array::new();
        let mut p_p4: crate::syntax::parser::Ps = crate::syntax::parser::adv_f(p0_p0);
        let mut going_p5: bool = true;
        while going_p5 && !p_p4.bad_p {
            match &crate::syntax::parser::kind_f(&p_p4) {
                crate::syntax::lexer::TokKind::KName(n_p6) if (((&n_p6.sigils_p == &crate::prelude::Text::lit("")) && (&n_p6.case_p == &crate::syntax::lexer::NameCase::CaseLower)) && (&crate::prelude::len(&n_p6.path_p) == &crate::prelude::Nat::from(1u32))) => {
                    path_p3 = crate::prelude::push(&path_p3, &crate::syntax::Ident { name_p: crate::prelude::or(&crate::prelude::index(&n_p6.path_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")), span_p: crate::syntax::parser::here_f(&p_p4) });
                    p_p4 = crate::syntax::parser::adv_f(&p_p4);
                    if &crate::syntax::parser::kind_f(&p_p4) == &crate::syntax::lexer::TokKind::KDot(false) {
                        p_p4 = crate::syntax::parser::adv_f(&p_p4);
                    } else {
                        going_p5 = false;
                    }
                    ()
                },
                _ => {
                    p_p4 = crate::syntax::parser::error_here_f(&p_p4, &crate::prelude::Text::lit("expected a field name in a lens path"));
                    ()
                },
                _ => unreachable!("no arm matched"),
            };
        }
        this = (path_p3.clone(), p_p4.clone());
        this
    };
    let (path_p7, q_p8) = r_p2.clone();
    (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ELens(path_p7.clone())), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&q_p8)) }, false, q_p8.clone())
}

/// The step machine of `LensPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LensPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub struct LensPrimary {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> for LensPrimary {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let start_p1 = crate::syntax::parser::here_f(p0_p0);
        let mut this: (crate::prelude::Array<crate::syntax::Ident>, crate::syntax::parser::Ps) = (crate::prelude::Array::new(), crate::syntax::parser::adv_f(p0_p0));
        let mut path_p3: crate::prelude::Array<crate::syntax::Ident> = crate::prelude::Array::new();
        let mut p_p4: crate::syntax::parser::Ps = crate::syntax::parser::adv_f(p0_p0);
        let mut going_p5: bool = true;
        let start_p1z = start_p1.clone();
        crate::prelude::call_then(crate::prelude::loop_job((this, going_p5, p_p4, path_p3), move |(mut this, mut going_p5, mut p_p4, mut path_p3): ((crate::prelude::Array<crate::syntax::Ident>, crate::syntax::parser::Ps), bool, crate::syntax::parser::Ps, crate::prelude::Array<crate::syntax::Ident>)| if going_p5 && !p_p4.bad_p {
            {
                match &crate::syntax::parser::kind_f(&p_p4) {
                    crate::syntax::lexer::TokKind::KName(n_p6) if (((&n_p6.sigils_p == &crate::prelude::Text::lit("")) && (&n_p6.case_p == &crate::syntax::lexer::NameCase::CaseLower)) && (&crate::prelude::len(&n_p6.path_p) == &crate::prelude::Nat::from(1u32))) => {
                        path_p3 = crate::prelude::push(&path_p3, &crate::syntax::Ident { name_p: crate::prelude::or(&crate::prelude::index(&n_p6.path_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")), span_p: crate::syntax::parser::here_f(&p_p4) });
                        p_p4 = crate::syntax::parser::adv_f(&p_p4);
                        if &crate::syntax::parser::kind_f(&p_p4) == &crate::syntax::lexer::TokKind::KDot(false) {
                            p_p4 = crate::syntax::parser::adv_f(&p_p4);
                        } else {
                            going_p5 = false;
                        }
                        ()
                    },
                    _ => {
                        p_p4 = crate::syntax::parser::error_here_f(&p_p4, &crate::prelude::Text::lit("expected a field name in a lens path"));
                        ()
                    },
                    _ => unreachable!("no arm matched"),
                };
                ::std::result::Result::Ok((this, going_p5, p_p4, path_p3))
            }
        } else {
            ::std::result::Result::Err((this, going_p5, p_p4, path_p3))
        }), move |(mut this, mut going_p5, mut p_p4, mut path_p3): ((crate::prelude::Array<crate::syntax::Ident>, crate::syntax::parser::Ps), bool, crate::syntax::parser::Ps, crate::prelude::Array<crate::syntax::Ident>)| {
            this = (path_p3.clone(), p_p4.clone());
            let r_p2 = this;
            let (path_p7, q_p8) = r_p2.clone();
            ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ELens(path_p7.clone())), span_p: crate::syntax::parser::to_f(&start_p1z, &crate::syntax::parser::prev_f(&q_p8)) }, false, q_p8.clone()))
        })
    }
}

/// `Start LensPrimary, x`: what the function value is when passed to `@Run`.
pub fn start_lens_primary_f(p0_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(LensPrimary { p0_p0 })
}

/// ```prism
/// KeywordPrimary: unbounded fn Ps, Text, Text, Bool -> ((Expr, Bool, Ps))
/// ```
pub fn keyword_primary_f(p_p0: &crate::syntax::parser::Ps, w_p1: &crate::prelude::Text, sigils_p2: &crate::prelude::Text, commas_p3: &bool) -> (crate::syntax::Expr, bool, crate::syntax::parser::Ps) {
    let start_p4 = crate::syntax::parser::here_f(p_p0);
    match w_p1 {
        m22734_0 if (m22734_0 == &crate::prelude::Text::lit("unit")) => (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EUnit(sigils_p2.clone())), span_p: start_p4.clone() }, false, crate::syntax::parser::adv_f(p_p0)),
        m22734_1 if (m22734_1 == &crate::prelude::Text::lit("nil")) => (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ENil(sigils_p2.clone())), span_p: start_p4.clone() }, false, crate::syntax::parser::adv_f(p_p0)),
        _ if crate::syntax::lexer::is_bound_word_f(w_p1) => (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EBound(w_p1.clone())), span_p: start_p4.clone() }, false, crate::syntax::parser::adv_f(p_p0)),
        m22734_3 if (m22734_3 == &crate::prelude::Text::lit("if")) => took_f(&parse_if_f(p_p0)),
        m22734_4 if (m22734_4 == &crate::prelude::Text::lit("match")) => took_f(&parse_match_f(p_p0)),
        m22734_5 if (m22734_5 == &crate::prelude::Text::lit("rebuild")) => {
            let (scrutinee_p5, p1_p6) = parse_expr_f(&crate::syntax::parser::adv_f(p_p0));
            let (body_p7, p2_p8) = crate::syntax::parser::blocks::parse_block_after_colon_f(&p1_p6);
            (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ERebuild(::std::rc::Rc::new(scrutinee_p5.clone()), body_p7.clone())), span_p: crate::syntax::parser::to_f(&start_p4, &body_p7.span_p) }, true, p2_p8.clone())
        },
        m22734_6 if (m22734_6 == &crate::prelude::Text::lit("for")) => took_f(&parse_for_f(p_p0)),
        m22734_7 if (m22734_7 == &crate::prelude::Text::lit("given")) => {
            let (body_p9, q_pa) = crate::syntax::parser::blocks::parse_block_after_colon_f(&crate::syntax::parser::adv_f(p_p0));
            (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EGiven(body_p9.clone())), span_p: crate::syntax::parser::to_f(&start_p4, &body_p9.span_p) }, true, q_pa.clone())
        },
        m22734_8 if (m22734_8 == &crate::prelude::Text::lit("update")) => {
            let (target_pb, p1_pc) = parse_expr_f(&crate::syntax::parser::adv_f(p_p0));
            let (body_pd, p2_pe) = crate::syntax::parser::blocks::parse_block_after_colon_f(&p1_pc);
            (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EUpdate(::std::rc::Rc::new(target_pb.clone()), body_pd.clone())), span_p: crate::syntax::parser::to_f(&start_p4, &body_pd.span_p) }, true, p2_pe.clone())
        },
        m22734_9 if (m22734_9 == &crate::prelude::Text::lit("widget")) => {
            let (body_pf, q_pg) = crate::syntax::parser::blocks::parse_block_after_colon_f(&crate::syntax::parser::adv_f(p_p0));
            (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EWidgetBlock(body_pf.clone())), span_p: crate::syntax::parser::to_f(&start_p4, &body_pf.span_p) }, true, q_pg.clone())
        },
        m22734_10 if (m22734_10 == &crate::prelude::Text::lit("any")) => {
            let (operand_ph, q_pi) = parse_expr_ctx_f(&crate::syntax::parser::adv_f(p_p0), commas_p3);
            (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EAny(::std::rc::Rc::new(operand_ph.clone()))), span_p: crate::syntax::parser::to_f(&start_p4, &operand_ph.span_p) }, true, q_pi.clone())
        },
        m22734_11 if (m22734_11 == &crate::prelude::Text::lit("not")) => {
            let (e_pj, q_pk) = parse_binary_f(p_p0, &crate::prelude::Nat::from(8u32), commas_p3);
            (e_pj.clone(), true, q_pk.clone())
        },
        _ if (((w_p1 == &crate::prelude::Text::lit("output")) || (w_p1 == &crate::prelude::Text::lit("inline_text"))) || (w_p1 == &crate::prelude::Text::lit("raw"))) => {
            let p1_pl = crate::syntax::parser::adv_f(p_p0);
            match crate::syntax::parser::kind_f(&p1_pl) {
                crate::syntax::lexer::TokKind::KTemplate(t_pm) => {
                    let tspan_pn = crate::syntax::parser::here_f(&p1_pl);
                    let (tpl_po, q_pp) = parse_template_f(&crate::syntax::parser::adv_f(&p1_pl), &t_pm, &tspan_pn);
                    (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ETemplate(tpl_po.clone())), span_p: crate::syntax::parser::to_f(&start_p4, &tspan_pn) }, false, q_pp.clone())
                },
                _ => (crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::fail_f(&p1_pl)),
            }
        },
        m22734_13 if (m22734_13 == &crate::prelude::Text::lit("then")) => (crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, &start_p4, &crate::prelude::Text::lit("`then` belongs to a hold: `$x <- start then step`"))),
        m22734_14 if (m22734_14 == &crate::prelude::Text::lit("else")) => (crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, &start_p4, &crate::prelude::Text::lit("`else` without its `if`"))),
        m22734_15 if (m22734_15 == &crate::prelude::Text::lit("ignore")) => (crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, &start_p4, &crate::prelude::Text::lit("`ignore` stands only inside a pattern or as the left side of a bind"))),
        m22734_16 if (m22734_16 == &crate::prelude::Text::lit("return")) => (crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, &start_p4, &crate::prelude::Text::lit("`return` ends a monad block, as its last statement"))),
        _ => (crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_here_f(p_p0, &crate::prelude::Text::lit("expected an expression"))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `KeywordPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// KeywordPrimary: unbounded fn Ps, Text, Text, Bool -> ((Expr, Bool, Ps))
/// ```
pub struct KeywordPrimary {
    pub p_p0: crate::syntax::parser::Ps,
    pub w_p1: crate::prelude::Text,
    pub sigils_p2: crate::prelude::Text,
    pub commas_p3: bool,
}

impl ::prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> for KeywordPrimary {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let w_p1 = &self.w_p1;
        let sigils_p2 = &self.sigils_p2;
        let commas_p3 = &self.commas_p3;
        let start_p4 = crate::syntax::parser::here_f(p_p0);
        match w_p1 {
            m22734_0 if (m22734_0 == &crate::prelude::Text::lit("unit")) => ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EUnit(sigils_p2.clone())), span_p: start_p4.clone() }, false, crate::syntax::parser::adv_f(p_p0))),
            m22734_1 if (m22734_1 == &crate::prelude::Text::lit("nil")) => ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ENil(sigils_p2.clone())), span_p: start_p4.clone() }, false, crate::syntax::parser::adv_f(p_p0))),
            _ if crate::syntax::lexer::is_bound_word_f(w_p1) => ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EBound(w_p1.clone())), span_p: start_p4.clone() }, false, crate::syntax::parser::adv_f(p_p0))),
            m22734_3 if (m22734_3 == &crate::prelude::Text::lit("if")) => {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(start_parse_if_f(p_p0x.clone()), move |parse_if_f_22996: (crate::syntax::Expr, crate::syntax::parser::Ps)| ::prism_rtl::Turn::Finished(took_f(&parse_if_f_22996)))
            },
            m22734_4 if (m22734_4 == &crate::prelude::Text::lit("match")) => {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(start_parse_match_f(p_p0x.clone()), move |parse_match_f_23030: (crate::syntax::Expr, crate::syntax::parser::Ps)| ::prism_rtl::Turn::Finished(took_f(&parse_match_f_23030)))
            },
            m22734_5 if (m22734_5 == &crate::prelude::Text::lit("rebuild")) => {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(start_parse_expr_f(crate::syntax::parser::adv_f(&p_p0x)), move |parse_expr_f_23099: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (scrutinee_p5, p1_p6) = parse_expr_f_23099;
                    crate::prelude::call_then(crate::syntax::parser::blocks::start_parse_block_after_colon_f(p1_p6.clone()), move |parse_block_after_colon_f_23148: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                        let (body_p7, p2_p8) = parse_block_after_colon_f_23148;
                        ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ERebuild(::std::rc::Rc::new(scrutinee_p5.clone()), body_p7.clone())), span_p: crate::syntax::parser::to_f(&start_p4, &body_p7.span_p) }, true, p2_p8.clone()))
                    })
                })
            },
            m22734_6 if (m22734_6 == &crate::prelude::Text::lit("for")) => {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(start_parse_for_f(p_p0x.clone()), move |parse_for_f_23285: (crate::syntax::Expr, crate::syntax::parser::Ps)| ::prism_rtl::Turn::Finished(took_f(&parse_for_f_23285)))
            },
            m22734_7 if (m22734_7 == &crate::prelude::Text::lit("given")) => {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(crate::syntax::parser::blocks::start_parse_block_after_colon_f(crate::syntax::parser::adv_f(&p_p0x)), move |parse_block_after_colon_f_23344: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                    let (body_p9, q_pa) = parse_block_after_colon_f_23344;
                    ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EGiven(body_p9.clone())), span_p: crate::syntax::parser::to_f(&start_p4, &body_p9.span_p) }, true, q_pa.clone()))
                })
            },
            m22734_8 if (m22734_8 == &crate::prelude::Text::lit("update")) => {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(start_parse_expr_f(crate::syntax::parser::adv_f(&p_p0x)), move |parse_expr_f_23502: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (target_pb, p1_pc) = parse_expr_f_23502;
                    crate::prelude::call_then(crate::syntax::parser::blocks::start_parse_block_after_colon_f(p1_pc.clone()), move |parse_block_after_colon_f_23551: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                        let (body_pd, p2_pe) = parse_block_after_colon_f_23551;
                        ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EUpdate(::std::rc::Rc::new(target_pb.clone()), body_pd.clone())), span_p: crate::syntax::parser::to_f(&start_p4, &body_pd.span_p) }, true, p2_pe.clone()))
                    })
                })
            },
            m22734_9 if (m22734_9 == &crate::prelude::Text::lit("widget")) => {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(crate::syntax::parser::blocks::start_parse_block_after_colon_f(crate::syntax::parser::adv_f(&p_p0x)), move |parse_block_after_colon_f_23764: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                    let (body_pf, q_pg) = parse_block_after_colon_f_23764;
                    ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EWidgetBlock(body_pf.clone())), span_p: crate::syntax::parser::to_f(&start_p4, &body_pf.span_p) }, true, q_pg.clone()))
                })
            },
            m22734_10 if (m22734_10 == &crate::prelude::Text::lit("any")) => {
                let commas_p3x = *commas_p3;
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(start_parse_expr_ctx_f(crate::syntax::parser::adv_f(&p_p0x), commas_p3x), move |parse_expr_ctx_f_23925: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (operand_ph, q_pi) = parse_expr_ctx_f_23925;
                    ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EAny(::std::rc::Rc::new(operand_ph.clone()))), span_p: crate::syntax::parser::to_f(&start_p4, &operand_ph.span_p) }, true, q_pi.clone()))
                })
            },
            m22734_11 if (m22734_11 == &crate::prelude::Text::lit("not")) => {
                let commas_p3x = *commas_p3;
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(start_parse_binary_f(p_p0x.clone(), crate::prelude::Nat::from(8u32), commas_p3x), move |parse_binary_f_24078: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (e_pj, q_pk) = parse_binary_f_24078;
                    ::prism_rtl::Turn::Finished((e_pj.clone(), true, q_pk.clone()))
                })
            },
            _ if (((w_p1 == &crate::prelude::Text::lit("output")) || (w_p1 == &crate::prelude::Text::lit("inline_text"))) || (w_p1 == &crate::prelude::Text::lit("raw"))) => {
                let p1_pl = crate::syntax::parser::adv_f(p_p0);
                match crate::syntax::parser::kind_f(&p1_pl) {
                    crate::syntax::lexer::TokKind::KTemplate(t_pm) => {
                        let tspan_pn = crate::syntax::parser::here_f(&p1_pl);
                        crate::prelude::call_then(start_parse_template_f(crate::syntax::parser::adv_f(&p1_pl), t_pm.clone(), tspan_pn.clone()), move |parse_template_f_24438: (crate::syntax::Template, crate::syntax::parser::Ps)| {
                            let (tpl_po, q_pp) = parse_template_f_24438;
                            ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ETemplate(tpl_po.clone())), span_p: crate::syntax::parser::to_f(&start_p4, &tspan_pn) }, false, q_pp.clone()))
                        })
                    },
                    _ => ::prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::fail_f(&p1_pl))),
                }
            },
            m22734_13 if (m22734_13 == &crate::prelude::Text::lit("then")) => ::prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, &start_p4, &crate::prelude::Text::lit("`then` belongs to a hold: `$x <- start then step`")))),
            m22734_14 if (m22734_14 == &crate::prelude::Text::lit("else")) => ::prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, &start_p4, &crate::prelude::Text::lit("`else` without its `if`")))),
            m22734_15 if (m22734_15 == &crate::prelude::Text::lit("ignore")) => ::prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, &start_p4, &crate::prelude::Text::lit("`ignore` stands only inside a pattern or as the left side of a bind")))),
            m22734_16 if (m22734_16 == &crate::prelude::Text::lit("return")) => ::prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_at_f(p_p0, &start_p4, &crate::prelude::Text::lit("`return` ends a monad block, as its last statement")))),
            _ => ::prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr_p(), false, crate::syntax::parser::error_here_f(p_p0, &crate::prelude::Text::lit("expected an expression")))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start KeywordPrimary, x`: what the function value is when passed to `@Run`.
pub fn start_keyword_primary_f(p_p0: crate::syntax::parser::Ps, w_p1: crate::prelude::Text, sigils_p2: crate::prelude::Text, commas_p3: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(KeywordPrimary { p_p0, w_p1, sigils_p2, commas_p3 })
}

/// ```prism
/// Took: fn ((Expr, Ps)) -> ((Expr, Bool, Ps))
/// ```
pub fn took_f(arg0: &(crate::syntax::Expr, crate::syntax::parser::Ps)) -> (crate::syntax::Expr, bool, crate::syntax::parser::Ps) {
    match arg0 {
        (e_p0, p_p1) => (e_p0.clone(), true, p_p1.clone()),
    }
}

/// ```prism
/// ParseLiteral: unbounded fn Ps -> ((Literal, Ps))
/// ```
pub fn parse_literal_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Literal, crate::syntax::parser::Ps) {
    let span_p1 = crate::syntax::parser::here_f(p_p0);
    let p1_p2 = crate::syntax::parser::adv_f(p_p0);
    match crate::syntax::parser::kind_f(p_p0) {
        crate::syntax::lexer::TokKind::KInt(s_p3, t_p4) => (crate::syntax::Literal { marks_p: s_p3, kind_p: crate::syntax::LitKind::LInt(t_p4), span_p: span_p1.clone() }, p1_p2.clone()),
        crate::syntax::lexer::TokKind::KFloat(s_p5, t_p6) => (crate::syntax::Literal { marks_p: s_p5, kind_p: crate::syntax::LitKind::LFloat(t_p6), span_p: span_p1.clone() }, p1_p2.clone()),
        crate::syntax::lexer::TokKind::KDuration(s_p7, n_p8, u_p9) => (crate::syntax::Literal { marks_p: s_p7, kind_p: crate::syntax::LitKind::LDuration(n_p8, u_p9), span_p: span_p1.clone() }, p1_p2.clone()),
        crate::syntax::lexer::TokKind::KChar(s_pa, c_pb) => (crate::syntax::Literal { marks_p: s_pa, kind_p: crate::syntax::LitKind::LChar(c_pb), span_p: span_p1.clone() }, p1_p2.clone()),
        crate::syntax::lexer::TokKind::KRegex(s_pc, r_pd) => (crate::syntax::Literal { marks_p: s_pc, kind_p: crate::syntax::LitKind::LRegex(r_pd), span_p: span_p1.clone() }, p1_p2.clone()),
        crate::syntax::lexer::TokKind::KText(s_pe, segs_pf) => {
            let (out_pj, q_pk) = crate::prelude::run_to_end(crate::prelude::fold_job(segs_pf.clone(), (crate::prelude::Array::new(), p1_p2.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps), crate::syntax::lexer::TextSegTok)| crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_pg, pp_ph) = p0;
                let seg_pi = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(TextSegment { acc_p0: acc_pg.clone(), p_p1: pp_ph.clone(), text_seg_tok2: seg_pi.clone() }))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps), crate::syntax::lexer::TextSegTok)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps)>>>));
            (crate::syntax::Literal { marks_p: s_pe.clone(), kind_p: crate::syntax::LitKind::LText(out_pj.clone()), span_p: span_p1.clone() }, q_pk.clone())
        },
        _ => (crate::syntax::Literal { marks_p: crate::prelude::Text::lit(""), kind_p: crate::syntax::LitKind::LInt(crate::prelude::Text::lit("")), span_p: span_p1.clone() }, crate::syntax::parser::error_at_f(&p1_p2, &span_p1, &crate::prelude::Text::lit("expected a literal"))),
    }
}

/// The step machine of `ParseLiteral`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseLiteral: unbounded fn Ps -> ((Literal, Ps))
/// ```
pub struct ParseLiteral {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::Literal, crate::syntax::parser::Ps)> for ParseLiteral {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Literal, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let span_p1 = crate::syntax::parser::here_f(p_p0);
        let p1_p2 = crate::syntax::parser::adv_f(p_p0);
        match crate::syntax::parser::kind_f(p_p0) {
            crate::syntax::lexer::TokKind::KInt(s_p3, t_p4) => ::prism_rtl::Turn::Finished((crate::syntax::Literal { marks_p: s_p3.clone(), kind_p: crate::syntax::LitKind::LInt(t_p4.clone()), span_p: span_p1.clone() }, p1_p2.clone())),
            crate::syntax::lexer::TokKind::KFloat(s_p5, t_p6) => ::prism_rtl::Turn::Finished((crate::syntax::Literal { marks_p: s_p5.clone(), kind_p: crate::syntax::LitKind::LFloat(t_p6.clone()), span_p: span_p1.clone() }, p1_p2.clone())),
            crate::syntax::lexer::TokKind::KDuration(s_p7, n_p8, u_p9) => ::prism_rtl::Turn::Finished((crate::syntax::Literal { marks_p: s_p7.clone(), kind_p: crate::syntax::LitKind::LDuration(n_p8.clone(), u_p9.clone()), span_p: span_p1.clone() }, p1_p2.clone())),
            crate::syntax::lexer::TokKind::KChar(s_pa, c_pb) => ::prism_rtl::Turn::Finished((crate::syntax::Literal { marks_p: s_pa.clone(), kind_p: crate::syntax::LitKind::LChar(c_pb.clone()), span_p: span_p1.clone() }, p1_p2.clone())),
            crate::syntax::lexer::TokKind::KRegex(s_pc, r_pd) => ::prism_rtl::Turn::Finished((crate::syntax::Literal { marks_p: s_pc.clone(), kind_p: crate::syntax::LitKind::LRegex(r_pd.clone()), span_p: span_p1.clone() }, p1_p2.clone())),
            crate::syntax::lexer::TokKind::KText(s_pe, segs_pf) => crate::prelude::call_value(crate::prelude::fold_job(segs_pf.clone(), (crate::prelude::Array::new(), p1_p2.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps), crate::syntax::lexer::TextSegTok)| crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_pg, pp_ph) = p0;
                let seg_pi = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(TextSegment { acc_p0: acc_pg.clone(), p_p1: pp_ph.clone(), text_seg_tok2: seg_pi.clone() }))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps), crate::syntax::lexer::TextSegTok)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps)>>>), move |fold_25826: (crate::prelude::Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps)| {
                let (out_pj, q_pk) = fold_25826;
                ::prism_rtl::Turn::Finished((crate::syntax::Literal { marks_p: s_pe.clone(), kind_p: crate::syntax::LitKind::LText(out_pj.clone()), span_p: span_p1.clone() }, q_pk.clone()))
            }),
            _ => ::prism_rtl::Turn::Finished((crate::syntax::Literal { marks_p: crate::prelude::Text::lit(""), kind_p: crate::syntax::LitKind::LInt(crate::prelude::Text::lit("")), span_p: span_p1.clone() }, crate::syntax::parser::error_at_f(&p1_p2, &span_p1, &crate::prelude::Text::lit("expected a literal")))),
        }
    }
}

/// `Start ParseLiteral, x`: what the function value is when passed to `@Run`.
pub fn start_parse_literal_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Literal, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseLiteral { p_p0 })
}

/// ```prism
/// TextSegment: unbounded fn [TextSeg], Ps, TextSegTok -> (([TextSeg], Ps))
/// ```
pub fn text_segment_f(acc_p0: &crate::prelude::Array<crate::syntax::TextSeg>, p_p1: &crate::syntax::parser::Ps, text_seg_tok2: &crate::syntax::lexer::TextSegTok) -> (crate::prelude::Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps) {
    match text_seg_tok2 {
        crate::syntax::lexer::TextSegTok::TsPlain(s_p2) => (crate::prelude::push(acc_p0, &crate::syntax::TextSeg::SegPlain(s_p2.clone())), p_p1.clone()),
        crate::syntax::lexer::TextSegTok::TsPlaceholder(toks_p5, span_p6) => {
            let (e_p7, q_p8) = parse_nested_f(p_p1, toks_p5, span_p6);
            (crate::prelude::push(acc_p0, &crate::syntax::TextSeg::SegPlaceholder(e_p7.clone())), q_p8.clone())
        },
    }
}

/// The step machine of `TextSegment`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TextSegment: unbounded fn [TextSeg], Ps, TextSegTok -> (([TextSeg], Ps))
/// ```
pub struct TextSegment {
    pub acc_p0: crate::prelude::Array<crate::syntax::TextSeg>,
    pub p_p1: crate::syntax::parser::Ps,
    pub text_seg_tok2: crate::syntax::lexer::TextSegTok,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps)> for TextSegment {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps)> {
        let acc_p0 = &self.acc_p0;
        let p_p1 = &self.p_p1;
        let text_seg_tok2 = &self.text_seg_tok2;
        match text_seg_tok2 {
            crate::syntax::lexer::TextSegTok::TsPlain(s_p2) => ::prism_rtl::Turn::Finished((crate::prelude::push(acc_p0, &crate::syntax::TextSeg::SegPlain(s_p2.clone())), p_p1.clone())),
            crate::syntax::lexer::TextSegTok::TsPlaceholder(toks_p5, span_p6) => {
                let acc_p0x = acc_p0.clone();
                let p_p1x = p_p1.clone();
                let span_p6x = span_p6.clone();
                let toks_p5x = toks_p5.clone();
                crate::prelude::call_then(start_parse_nested_f(p_p1x.clone(), toks_p5x.clone(), span_p6x.clone()), move |parse_nested_f_26284: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (e_p7, q_p8) = parse_nested_f_26284;
                    ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p0x, &crate::syntax::TextSeg::SegPlaceholder(e_p7.clone())), q_p8.clone()))
                })
            },
        }
    }
}

/// `Start TextSegment, x`: what the function value is when passed to `@Run`.
pub fn start_text_segment_f(acc_p0: crate::prelude::Array<crate::syntax::TextSeg>, p_p1: crate::syntax::parser::Ps, text_seg_tok2: crate::syntax::lexer::TextSegTok) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(TextSegment { acc_p0, p_p1, text_seg_tok2 })
}

/// ```prism
/// ParseNested: unbounded fn Ps, [Tok], Range -> ((Expr, Ps))
/// ```
pub fn parse_nested_f(p_p0: &crate::syntax::parser::Ps, toks_p1: &crate::prelude::Array<crate::syntax::lexer::Tok>, span_p2: &crate::syntax::Range) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let sub_p3 = crate::syntax::parser::with_step_mode_f(&crate::syntax::parser::sub_f(p_p0, toks_p1, &crate::syntax::parser::at_end_f(span_p2)), &false);
    let (e_p7, s1_p8) = parse_rhs_expr_f(&sub_p3);
    let s2_p4 = if !s1_p8.bad_p && !crate::syntax::parser::at_eof_f(&s1_p8) {
        crate::syntax::parser::note_error_f(&s1_p8, &crate::syntax::parser::here_f(&s1_p8), &crate::prelude::Text::from(format!("expected the end of the placeholder, found {}", &crate::syntax::parser::describe_f(&crate::syntax::parser::kind_f(&s1_p8)))))
    } else {
        s1_p8.clone()
    };
    let s3_p5 = if s2_p4.bad_p && (&crate::prelude::len(&s2_p4.diags_p) == &crate::prelude::Nat::from(0u32)) {
        crate::syntax::parser::note_error_f(&crate::syntax::parser::unbad_f(&s2_p4), span_p2, &crate::prelude::Text::lit("expected an expression in the placeholder"))
    } else {
        s2_p4.clone()
    };
    let q_p6 = crate::syntax::parser::absorb_f(p_p0, &s3_p5);
    if s1_p8.bad_p {
        (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EError), span_p: span_p2.clone() }, q_p6.clone())
    } else {
        (e_p7.clone(), q_p6.clone())
    }
}

/// The step machine of `ParseNested`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseNested: unbounded fn Ps, [Tok], Range -> ((Expr, Ps))
/// ```
pub struct ParseNested {
    pub p_p0: crate::syntax::parser::Ps,
    pub toks_p1: crate::prelude::Array<crate::syntax::lexer::Tok>,
    pub span_p2: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseNested {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let toks_p1 = &self.toks_p1;
        let span_p2 = &self.span_p2;
        let p_p0x = p_p0.clone();
        let span_p2x = span_p2.clone();
        let toks_p1x = toks_p1.clone();
        crate::prelude::call_then(crate::syntax::parser::start_sub_f(p_p0x.clone(), toks_p1x.clone(), crate::syntax::parser::at_end_f(&span_p2x)), move |sub_f_26607: crate::syntax::parser::Ps| {
            let sub_p3 = crate::syntax::parser::with_step_mode_f(&sub_f_26607, &false);
            crate::prelude::call_then(start_parse_rhs_expr_f(sub_p3.clone()), move |parse_rhs_expr_f_26661: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                let (e_p7, s1_p8) = parse_rhs_expr_f_26661;
                let s2_p4 = if !s1_p8.bad_p && !crate::syntax::parser::at_eof_f(&s1_p8) {
                    crate::syntax::parser::note_error_f(&s1_p8, &crate::syntax::parser::here_f(&s1_p8), &crate::prelude::Text::from(format!("expected the end of the placeholder, found {}", &crate::syntax::parser::describe_f(&crate::syntax::parser::kind_f(&s1_p8)))))
                } else {
                    s1_p8.clone()
                };
                let s3_p5 = if s2_p4.bad_p && (&crate::prelude::len(&s2_p4.diags_p) == &crate::prelude::Nat::from(0u32)) {
                    crate::syntax::parser::note_error_f(&crate::syntax::parser::unbad_f(&s2_p4), &span_p2x, &crate::prelude::Text::lit("expected an expression in the placeholder"))
                } else {
                    s2_p4.clone()
                };
                let q_p6 = crate::syntax::parser::absorb_f(&p_p0x, &s3_p5);
                if s1_p8.bad_p {
                    ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EError), span_p: span_p2x.clone() }, q_p6.clone()))
                } else {
                    ::prism_rtl::Turn::Finished((e_p7.clone(), q_p6.clone()))
                }
            })
        })
    }
}

/// `Start ParseNested, x`: what the function value is when passed to `@Run`.
pub fn start_parse_nested_f(p_p0: crate::syntax::parser::Ps, toks_p1: crate::prelude::Array<crate::syntax::lexer::Tok>, span_p2: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseNested { p_p0, toks_p1, span_p2 })
}

/// ```prism
/// ParseTemplate: unbounded fn Ps, TemplateTok, Range -> ((Template, Ps))
/// ```
pub fn parse_template_f(p0_p0: &crate::syntax::parser::Ps, t_p1: &crate::syntax::lexer::TemplateTok, span_p2: &crate::syntax::Range) -> (crate::syntax::Template, crate::syntax::parser::Ps) {
    let p1_p3 = if (&t_p1.delims_p == &crate::prelude::Text::lit("single")) && (&t_p1.keyword_p != &crate::prelude::Text::lit("Raw")) {
        crate::syntax::parser::out_of_scope_f(p0_p0, span_p2, &crate::prelude::Text::lit("the template notation"), &crate::prelude::Text::from(format!("a `<{}>` template is the template notation for an element language, out of this compiler (code templates only)", &t_p1.lang_p)))
    } else {
        p0_p0.clone()
    };
    let p2_p4 = if &t_p1.keyword_p == &crate::prelude::Text::lit("File") {
        crate::syntax::parser::out_of_scope_f(&p1_p3, span_p2, &crate::prelude::Text::lit("the template notation"), &crate::prelude::Text::lit("a file whose first token is a language tag is a template file, out of this compiler (code templates only)"))
    } else {
        p1_p3.clone()
    };
    let (parts_p5, p3_p6) = template_parts_f(&p2_p4, &t_p1.parts_p);
    (crate::syntax::Template { keyword_p: t_p1.keyword_p.clone(), lang_p: t_p1.lang_p.clone(), delims_p: t_p1.delims_p.clone(), parts_p: parts_p5.clone(), span_p: span_p2.clone() }, p3_p6.clone())
}

/// The step machine of `ParseTemplate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTemplate: unbounded fn Ps, TemplateTok, Range -> ((Template, Ps))
/// ```
pub struct ParseTemplate {
    pub p0_p0: crate::syntax::parser::Ps,
    pub t_p1: crate::syntax::lexer::TemplateTok,
    pub span_p2: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::syntax::Template, crate::syntax::parser::Ps)> for ParseTemplate {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Template, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let t_p1 = &self.t_p1;
        let span_p2 = &self.span_p2;
        let p1_p3 = if (&t_p1.delims_p == &crate::prelude::Text::lit("single")) && (&t_p1.keyword_p != &crate::prelude::Text::lit("Raw")) {
            crate::syntax::parser::out_of_scope_f(p0_p0, span_p2, &crate::prelude::Text::lit("the template notation"), &crate::prelude::Text::from(format!("a `<{}>` template is the template notation for an element language, out of this compiler (code templates only)", &t_p1.lang_p)))
        } else {
            p0_p0.clone()
        };
        let p2_p4 = if &t_p1.keyword_p == &crate::prelude::Text::lit("File") {
            crate::syntax::parser::out_of_scope_f(&p1_p3, span_p2, &crate::prelude::Text::lit("the template notation"), &crate::prelude::Text::lit("a file whose first token is a language tag is a template file, out of this compiler (code templates only)"))
        } else {
            p1_p3.clone()
        };
        let span_p2x = span_p2.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(start_template_parts_f(p2_p4.clone(), t_p1x.parts_p.clone()), move |template_parts_f_27656: (crate::prelude::Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)| {
            let (parts_p5, p3_p6) = template_parts_f_27656;
            ::prism_rtl::Turn::Finished((crate::syntax::Template { keyword_p: t_p1x.keyword_p.clone(), lang_p: t_p1x.lang_p.clone(), delims_p: t_p1x.delims_p.clone(), parts_p: parts_p5.clone(), span_p: span_p2x.clone() }, p3_p6.clone()))
        })
    }
}

/// `Start ParseTemplate, x`: what the function value is when passed to `@Run`.
pub fn start_parse_template_f(p0_p0: crate::syntax::parser::Ps, t_p1: crate::syntax::lexer::TemplateTok, span_p2: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Template, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseTemplate { p0_p0, t_p1, span_p2 })
}

/// ```prism
/// TemplateParts: unbounded fn Ps, [TPartTok] -> (([TemplatePart], Ps))
/// ```
pub fn template_parts_f(p_p0: &crate::syntax::parser::Ps, parts_p1: &crate::prelude::Array<crate::syntax::lexer::TPartTok>) -> (crate::prelude::Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps) {
    crate::prelude::run_to_end(crate::prelude::fold_job(parts_p1.clone(), (crate::prelude::Array::new(), p_p0.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps), crate::syntax::lexer::TPartTok)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (acc_p2, q_p3) = p0;
        let part_p4 = p1;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(TemplatePartOf { acc_p0: acc_p2.clone(), p_p1: q_p3.clone(), tpart_tok2: part_p4.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps), crate::syntax::lexer::TPartTok)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)>>>))
}

/// The step machine of `TemplateParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateParts: unbounded fn Ps, [TPartTok] -> (([TemplatePart], Ps))
/// ```
pub struct TemplateParts {
    pub p_p0: crate::syntax::parser::Ps,
    pub parts_p1: crate::prelude::Array<crate::syntax::lexer::TPartTok>,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)> for TemplateParts {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let parts_p1 = &self.parts_p1;
        crate::prelude::fold_job(parts_p1.clone(), (crate::prelude::Array::new(), p_p0.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps), crate::syntax::lexer::TPartTok)| crate::prelude::entered(crate::prelude::once_job(move || {
            let (acc_p2, q_p3) = p0;
            let part_p4 = p1;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(TemplatePartOf { acc_p0: acc_p2.clone(), p_p1: q_p3.clone(), tpart_tok2: part_p4.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps), crate::syntax::lexer::TPartTok)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)>>>).cycle()
    }
}

/// `Start TemplateParts, x`: what the function value is when passed to `@Run`.
pub fn start_template_parts_f(p_p0: crate::syntax::parser::Ps, parts_p1: crate::prelude::Array<crate::syntax::lexer::TPartTok>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(TemplateParts { p_p0, parts_p1 })
}

/// ```prism
/// TemplatePartOf: unbounded fn [TemplatePart], Ps, TPartTok -> (([TemplatePart], Ps))
/// ```
pub fn template_part_of_f(acc_p0: &crate::prelude::Array<crate::syntax::TemplatePart>, p_p1: &crate::syntax::parser::Ps, tpart_tok2: &crate::syntax::lexer::TPartTok) -> (crate::prelude::Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps) {
    match tpart_tok2 {
        crate::syntax::lexer::TPartTok::TptText(s_p2) => (crate::prelude::push(acc_p0, &crate::syntax::TemplatePart::TpText(s_p2.clone())), p_p1.clone()),
        crate::syntax::lexer::TPartTok::TptPlaceholder(toks_p5, col_o6, span_p7) => {
            let (e_p8, q_p9) = parse_nested_f(p_p1, toks_p5, span_p7);
            (crate::prelude::push(acc_p0, &crate::syntax::TemplatePart::TpPlaceholder(e_p8.clone(), col_o6.clone())), q_p9.clone())
        },
        crate::syntax::lexer::TPartTok::TptBlock(toks_pc, span_pd) => {
            let sub_pe = crate::syntax::parser::sub_f(p_p1, toks_pc, &crate::syntax::parser::at_end_f(span_pd));
            let (block_pf, s1_pg) = crate::syntax::parser::blocks::parse_block_until_eof_f(&sub_pe, span_pd);
            (crate::prelude::push(acc_p0, &crate::syntax::TemplatePart::TpBlock(block_pf.clone())), crate::syntax::parser::absorb_f(p_p1, &s1_pg))
        },
        crate::syntax::lexer::TPartTok::TptCall(name_pj, attrs_pk, body_ol, span_pm) => {
            let sname_pn = crate::syntax::SName { sigils_p: name_pj.sigils_p.clone(), path_p: name_pj.path_p.clone(), span_p: span_pm.clone() };
            let (args_pr, p1_ps) = crate::prelude::run_to_end(crate::prelude::fold_job(attrs_pk.clone(), (crate::prelude::Array::new(), p_p1.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::syntax::Arg>, crate::syntax::parser::Ps), crate::syntax::lexer::AttrTok)| crate::prelude::entered(crate::prelude::once_job(move || {
                let (done_po, q_pp) = p0;
                let a_pq = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(AttrArg { done_p0: done_po.clone(), p_p1: q_pp.clone(), a_p2: a_pq.clone() }))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::syntax::Arg>, crate::syntax::parser::Ps), crate::syntax::lexer::AttrTok)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::Arg>, crate::syntax::parser::Ps)>>>));
            let (inner_o10, p2_p11) = match body_ol {
                ::std::option::Option::Some(b_pt) => {
                    let (ps_pu, q_pv) = template_parts_f(&p1_ps, b_pt);
                    (::std::option::Option::Some(ps_pu.clone()), q_pv.clone())
                },
                ::std::option::Option::None => (::std::option::Option::None, p1_ps.clone()),
            };
            (crate::prelude::push(acc_p0, &crate::syntax::TemplatePart::TpCall(sname_pn.clone(), args_pr.clone(), inner_o10.clone(), span_pm.clone())), p2_p11.clone())
        },
    }
}

/// The step machine of `TemplatePartOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplatePartOf: unbounded fn [TemplatePart], Ps, TPartTok -> (([TemplatePart], Ps))
/// ```
pub struct TemplatePartOf {
    pub acc_p0: crate::prelude::Array<crate::syntax::TemplatePart>,
    pub p_p1: crate::syntax::parser::Ps,
    pub tpart_tok2: crate::syntax::lexer::TPartTok,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)> for TemplatePartOf {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)> {
        let acc_p0 = &self.acc_p0;
        let p_p1 = &self.p_p1;
        let tpart_tok2 = &self.tpart_tok2;
        match tpart_tok2 {
            crate::syntax::lexer::TPartTok::TptText(s_p2) => ::prism_rtl::Turn::Finished((crate::prelude::push(acc_p0, &crate::syntax::TemplatePart::TpText(s_p2.clone())), p_p1.clone())),
            crate::syntax::lexer::TPartTok::TptPlaceholder(toks_p5, col_o6, span_p7) => {
                let col_o6x = col_o6.clone();
                let acc_p0x = acc_p0.clone();
                let p_p1x = p_p1.clone();
                let span_p7x = span_p7.clone();
                let toks_p5x = toks_p5.clone();
                crate::prelude::call_then(start_parse_nested_f(p_p1x.clone(), toks_p5x.clone(), span_p7x.clone()), move |parse_nested_f_28182: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (e_p8, q_p9) = parse_nested_f_28182;
                    ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p0x, &crate::syntax::TemplatePart::TpPlaceholder(e_p8.clone(), col_o6x.clone())), q_p9.clone()))
                })
            },
            crate::syntax::lexer::TPartTok::TptBlock(toks_pc, span_pd) => {
                let acc_p0x = acc_p0.clone();
                let p_p1x = p_p1.clone();
                let span_pdx = span_pd.clone();
                let toks_pcx = toks_pc.clone();
                crate::prelude::call_then(crate::syntax::parser::start_sub_f(p_p1x.clone(), toks_pcx.clone(), crate::syntax::parser::at_end_f(&span_pdx)), move |sub_f_28318: crate::syntax::parser::Ps| {
                    let sub_pe = sub_f_28318;
                    crate::prelude::call_then(crate::syntax::parser::blocks::start_parse_block_until_eof_f(sub_pe.clone(), span_pdx.clone()), move |parse_block_until_eof_f_28368: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                        let (block_pf, s1_pg) = parse_block_until_eof_f_28368;
                        ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p0x, &crate::syntax::TemplatePart::TpBlock(block_pf.clone())), crate::syntax::parser::absorb_f(&p_p1x, &s1_pg)))
                    })
                })
            },
            crate::syntax::lexer::TPartTok::TptCall(name_pj, attrs_pk, body_ol, span_pm) => {
                let sname_pn = crate::syntax::SName { sigils_p: name_pj.sigils_p.clone(), path_p: name_pj.path_p.clone(), span_p: span_pm.clone() };
                let body_olx = body_ol.clone();
                let acc_p0x = acc_p0.clone();
                let attrs_pkx = attrs_pk.clone();
                let p_p1x = p_p1.clone();
                let span_pmx = span_pm.clone();
                crate::prelude::call_value(crate::prelude::fold_job(attrs_pkx.clone(), (crate::prelude::Array::new(), p_p1x.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::syntax::Arg>, crate::syntax::parser::Ps), crate::syntax::lexer::AttrTok)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let (done_po, q_pp) = p0;
                    let a_pq = p1;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(AttrArg { done_p0: done_po.clone(), p_p1: q_pp.clone(), a_p2: a_pq.clone() }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::syntax::Arg>, crate::syntax::parser::Ps), crate::syntax::lexer::AttrTok)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::Arg>, crate::syntax::parser::Ps)>>>), move |fold_28603: (crate::prelude::Array<crate::syntax::Arg>, crate::syntax::parser::Ps)| {
                    let (args_pr, p1_ps) = fold_28603;
                    let acc_p0xz = acc_p0x.clone();
                    let args_prz = args_pr.clone();
                    let sname_pnz = sname_pn.clone();
                    let span_pmxz = span_pmx.clone();
                    let k_let28669 = move |v28669: (::std::option::Option<crate::prelude::Array<crate::syntax::TemplatePart>>, crate::syntax::parser::Ps)| {
                        let (inner_o10, p2_p11) = v28669;
                        ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p0xz, &crate::syntax::TemplatePart::TpCall(sname_pnz.clone(), args_prz.clone(), inner_o10.clone(), span_pmxz.clone())), p2_p11.clone()))
                    };
                    match body_olx.clone() {
                        ::std::option::Option::Some(b_pt) => crate::prelude::call_then(start_template_parts_f(p1_ps.clone(), b_pt.clone()), move |template_parts_f_28744: (crate::prelude::Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)| {
                            let (ps_pu, q_pv) = template_parts_f_28744;
                            k_let28669((::std::option::Option::Some(ps_pu.clone()), q_pv.clone()))
                        }),
                        ::std::option::Option::None => k_let28669((::std::option::Option::None, p1_ps.clone())),
                    }
                })
            },
        }
    }
}

/// `Start TemplatePartOf, x`: what the function value is when passed to `@Run`.
pub fn start_template_part_of_f(acc_p0: crate::prelude::Array<crate::syntax::TemplatePart>, p_p1: crate::syntax::parser::Ps, tpart_tok2: crate::syntax::lexer::TPartTok) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(TemplatePartOf { acc_p0, p_p1, tpart_tok2 })
}

/// ```prism
/// AttrArg: unbounded fn [Arg], Ps, AttrTok -> (([Arg], Ps))
/// ```
pub fn attr_arg_f(done_p0: &crate::prelude::Array<crate::syntax::Arg>, p_p1: &crate::syntax::parser::Ps, a_p2: &crate::syntax::lexer::AttrTok) -> (crate::prelude::Array<crate::syntax::Arg>, crate::syntax::parser::Ps) {
    let (value_p3, q_p4) = parse_nested_f(p_p1, &a_p2.tokens_p, &a_p2.span_p);
    (crate::prelude::push(done_p0, &crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::Some(crate::syntax::Ident { name_p: a_p2.name_p.clone(), span_p: a_p2.span_p.clone() }), value_p: value_p3.clone(), span_p: a_p2.span_p.clone() }), q_p4.clone())
}

/// The step machine of `AttrArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AttrArg: unbounded fn [Arg], Ps, AttrTok -> (([Arg], Ps))
/// ```
pub struct AttrArg {
    pub done_p0: crate::prelude::Array<crate::syntax::Arg>,
    pub p_p1: crate::syntax::parser::Ps,
    pub a_p2: crate::syntax::lexer::AttrTok,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::Arg>, crate::syntax::parser::Ps)> for AttrArg {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::syntax::Arg>, crate::syntax::parser::Ps)> {
        let done_p0 = &self.done_p0;
        let p_p1 = &self.p_p1;
        let a_p2 = &self.a_p2;
        let a_p2x = a_p2.clone();
        let done_p0x = done_p0.clone();
        let p_p1x = p_p1.clone();
        crate::prelude::call_then(start_parse_nested_f(p_p1x.clone(), a_p2x.tokens_p.clone(), a_p2x.span_p.clone()), move |parse_nested_f_28977: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
            let (value_p3, q_p4) = parse_nested_f_28977;
            ::prism_rtl::Turn::Finished((crate::prelude::push(&done_p0x, &crate::syntax::Arg { marks_p: crate::prelude::Text::lit(""), name_o: ::std::option::Option::Some(crate::syntax::Ident { name_p: a_p2x.name_p.clone(), span_p: a_p2x.span_p.clone() }), value_p: value_p3.clone(), span_p: a_p2x.span_p.clone() }), q_p4.clone()))
        })
    }
}

/// `Start AttrArg, x`: what the function value is when passed to `@Run`.
pub fn start_attr_arg_f(done_p0: crate::prelude::Array<crate::syntax::Arg>, p_p1: crate::syntax::parser::Ps, a_p2: crate::syntax::lexer::AttrTok) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::Arg>, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(AttrArg { done_p0, p_p1, a_p2 })
}

/// ```prism
/// ParseLambda: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_lambda_f(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p0_p0);
    let p_p2 = crate::syntax::parser::adv_f(p0_p0);
    let (params_o3, p1_p4) = if &crate::syntax::parser::kind_f(&p_p2) == &crate::syntax::lexer::TokKind::KLambdaBar(true) {
        lambda_params_f(&crate::syntax::parser::adv_f(&p_p2))
    } else {
        (::std::option::Option::None, p_p2.clone())
    };
    if crate::syntax::parser::at_open_l_f(&p1_p4) {
        {
            let (block_p5, q_p6) = crate::syntax::parser::blocks::parse_indented_block_f(&p1_p4);
            (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ELambda(params_o3.clone(), ::std::rc::Rc::new(crate::syntax::LambdaBody::LbBlock(block_p5.clone())))), span_p: crate::syntax::parser::to_f(&start_p1, &block_p5.span_p) }, q_p6.clone())
        }
    } else {
        {
            let (body_p7, q_p8) = parse_expr_f(&p1_p4);
            (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ELambda(params_o3.clone(), ::std::rc::Rc::new(crate::syntax::LambdaBody::LbExpr(::std::rc::Rc::new(body_p7.clone()))))), span_p: crate::syntax::parser::to_f(&start_p1, &body_p7.span_p) }, q_p8.clone())
        }
    }
}

/// The step machine of `ParseLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseLambda: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseLambda {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseLambda {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let start_p1 = crate::syntax::parser::here_f(p0_p0);
        let p_p2 = crate::syntax::parser::adv_f(p0_p0);
        let start_p1z = start_p1.clone();
        let k_let29477 = move |v29477: (::std::option::Option<crate::prelude::Array<crate::syntax::Pattern>>, crate::syntax::parser::Ps)| {
            let (params_o3, p1_p4) = v29477;
            if crate::syntax::parser::at_open_l_f(&p1_p4) {
                crate::prelude::call_then(crate::syntax::parser::blocks::start_parse_indented_block_f(p1_p4.clone()), move |parse_indented_block_f_29617: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                    let (block_p5, q_p6) = parse_indented_block_f_29617;
                    ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ELambda(params_o3.clone(), ::std::rc::Rc::new(crate::syntax::LambdaBody::LbBlock(block_p5.clone())))), span_p: crate::syntax::parser::to_f(&start_p1z, &block_p5.span_p) }, q_p6.clone()))
                })
            } else {
                crate::prelude::call_then(start_parse_expr_f(p1_p4.clone()), move |parse_expr_f_29765: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (body_p7, q_p8) = parse_expr_f_29765;
                    ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::ELambda(params_o3.clone(), ::std::rc::Rc::new(crate::syntax::LambdaBody::LbExpr(::std::rc::Rc::new(body_p7.clone()))))), span_p: crate::syntax::parser::to_f(&start_p1z, &body_p7.span_p) }, q_p8.clone()))
                })
            }
        };
        if &crate::syntax::parser::kind_f(&p_p2) == &crate::syntax::lexer::TokKind::KLambdaBar(true) {
            crate::prelude::call_then(start_lambda_params_f(crate::syntax::parser::adv_f(&p_p2)), move |lambda_params_f_29533: (::std::option::Option<crate::prelude::Array<crate::syntax::Pattern>>, crate::syntax::parser::Ps)| k_let29477(lambda_params_f_29533))
        } else {
            k_let29477((::std::option::Option::None, p_p2.clone()))
        }
    }
}

/// `Start ParseLambda, x`: what the function value is when passed to `@Run`.
pub fn start_parse_lambda_f(p0_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseLambda { p0_p0 })
}

/// ```prism
/// LambdaParams: unbounded fn Ps -> ((?[Pattern], Ps))
/// ```
pub fn lambda_params_f(p_p0: &crate::syntax::parser::Ps) -> (::std::option::Option<crate::prelude::Array<crate::syntax::Pattern>>, crate::syntax::parser::Ps) {
    let (ps_p2, p1_p3) = if &crate::syntax::parser::kind_f(p_p0) == &crate::syntax::lexer::TokKind::KLambdaBar(false) {
        (crate::prelude::Array::new(), p_p0.clone())
    } else {
        crate::syntax::parser::commas_f(p_p0, &(::std::rc::Rc::new(move |p0: crate::syntax::parser::Ps| crate::prelude::entered(crate::prelude::once_job(move || {
            let q_p1 = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::syntax::parser::types::ParsePattern { p_p0: q_p1.clone(), commas0_p1: false }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Pattern, crate::syntax::parser::Ps)>>>))
    };
    if &crate::syntax::parser::kind_f(&p1_p3) == &crate::syntax::lexer::TokKind::KLambdaBar(false) {
        (::std::option::Option::Some(ps_p2.clone()), crate::syntax::parser::adv_f(&p1_p3))
    } else {
        (::std::option::Option::None, crate::syntax::parser::error_here_f(&p1_p3, &crate::prelude::Text::lit("expected `|` to close the lambda\'s parameters")))
    }
}

/// The step machine of `LambdaParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LambdaParams: unbounded fn Ps -> ((?[Pattern], Ps))
/// ```
pub struct LambdaParams {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(::std::option::Option<crate::prelude::Array<crate::syntax::Pattern>>, crate::syntax::parser::Ps)> for LambdaParams {
    fn cycle(&self) -> ::prism_rtl::Turn<(::std::option::Option<crate::prelude::Array<crate::syntax::Pattern>>, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let k_let29941 = move |v29941: (crate::prelude::Array<crate::syntax::Pattern>, crate::syntax::parser::Ps)| {
            let (ps_p2, p1_p3) = v29941;
            if &crate::syntax::parser::kind_f(&p1_p3) == &crate::syntax::lexer::TokKind::KLambdaBar(false) {
                ::prism_rtl::Turn::Finished((::std::option::Option::Some(ps_p2.clone()), crate::syntax::parser::adv_f(&p1_p3)))
            } else {
                ::prism_rtl::Turn::Finished((::std::option::Option::None, crate::syntax::parser::error_here_f(&p1_p3, &crate::prelude::Text::lit("expected `|` to close the lambda\'s parameters"))))
            }
        };
        if &crate::syntax::parser::kind_f(p_p0) == &crate::syntax::lexer::TokKind::KLambdaBar(false) {
            k_let29941((crate::prelude::Array::new(), p_p0.clone()))
        } else {
            {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(crate::syntax::parser::start_commas_f(p_p0x.clone(), ::std::rc::Rc::new(move |p0: crate::syntax::parser::Ps| crate::prelude::entered(crate::prelude::once_job(move || {
                    let q_p1 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::syntax::parser::types::ParsePattern { p_p0: q_p1.clone(), commas0_p1: false }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Pattern, crate::syntax::parser::Ps)>>>), move |commas_f_30011: (crate::prelude::Array<crate::syntax::Pattern>, crate::syntax::parser::Ps)| k_let29941(commas_f_30011))
            }
        }
    }
}

/// `Start LambdaParams, x`: what the function value is when passed to `@Run`.
pub fn start_lambda_params_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(::std::option::Option<crate::prelude::Array<crate::syntax::Pattern>>, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(LambdaParams { p_p0 })
}

/// ```prism
/// ParseCond: unbounded fn Ps, Bool -> ((Cond, Ps))
/// ```
pub fn parse_cond_f(p_p0: &crate::syntax::parser::Ps, allow_guard_p1: &bool) -> (crate::syntax::Cond, crate::syntax::parser::Ps) {
    let (pattern_p2, q_p3) = crate::syntax::parser::types::parse_pattern_f(p_p0, &true);
    if !q_p3.bad_p && crate::syntax::parser::at_op_f(&q_p3, &crate::prelude::Text::lit("<-")) {
        {
            let (value_p4, q1_p5) = parse_expr_f(&crate::syntax::parser::adv_f(&q_p3));
            if *allow_guard_p1 && crate::syntax::parser::at_kw_f(&q1_p5, &crate::prelude::Text::lit("if")) {
                {
                    let (guard_p6, q2_p7) = parse_expr_f(&crate::syntax::parser::adv_f(&q1_p5));
                    (crate::syntax::Cond::CondBind(pattern_p2.clone(), ::std::rc::Rc::new(value_p4.clone()), ::std::rc::Rc::new(::std::option::Option::Some(guard_p6.clone()))), q2_p7.clone())
                }
            } else {
                (crate::syntax::Cond::CondBind(pattern_p2.clone(), ::std::rc::Rc::new(value_p4.clone()), ::std::rc::Rc::new(::std::option::Option::None)), q1_p5.clone())
            }
        }
    } else {
        {
            let (e_p8, q1_p9) = parse_expr_f(p_p0);
            (crate::syntax::Cond::CondExpr(::std::rc::Rc::new(e_p8.clone())), q1_p9.clone())
        }
    }
}

/// The step machine of `ParseCond`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseCond: unbounded fn Ps, Bool -> ((Cond, Ps))
/// ```
pub struct ParseCond {
    pub p_p0: crate::syntax::parser::Ps,
    pub allow_guard_p1: bool,
}

impl ::prism_rtl::Job<(crate::syntax::Cond, crate::syntax::parser::Ps)> for ParseCond {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Cond, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let allow_guard_p1 = &self.allow_guard_p1;
        let allow_guard_p1x = *allow_guard_p1;
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(crate::syntax::parser::types::start_parse_pattern_f(p_p0x.clone(), true), move |parse_pattern_f_30350: (crate::syntax::Pattern, crate::syntax::parser::Ps)| {
            let (pattern_p2, q_p3) = parse_pattern_f_30350;
            if !q_p3.bad_p && crate::syntax::parser::at_op_f(&q_p3, &crate::prelude::Text::lit("<-")) {
                crate::prelude::call_then(start_parse_expr_f(crate::syntax::parser::adv_f(&q_p3)), move |parse_expr_f_30436: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (value_p4, q1_p5) = parse_expr_f_30436;
                    if allow_guard_p1x && crate::syntax::parser::at_kw_f(&q1_p5, &crate::prelude::Text::lit("if")) {
                        crate::prelude::call_then(start_parse_expr_f(crate::syntax::parser::adv_f(&q1_p5)), move |parse_expr_f_30529: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                            let (guard_p6, q2_p7) = parse_expr_f_30529;
                            ::prism_rtl::Turn::Finished((crate::syntax::Cond::CondBind(pattern_p2.clone(), ::std::rc::Rc::new(value_p4.clone()), ::std::rc::Rc::new(::std::option::Option::Some(guard_p6.clone()))), q2_p7.clone()))
                        })
                    } else {
                        ::prism_rtl::Turn::Finished((crate::syntax::Cond::CondBind(pattern_p2.clone(), ::std::rc::Rc::new(value_p4.clone()), ::std::rc::Rc::new(::std::option::Option::None)), q1_p5.clone()))
                    }
                })
            } else {
                crate::prelude::call_then(start_parse_expr_f(p_p0x.clone()), move |parse_expr_f_30692: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (e_p8, q1_p9) = parse_expr_f_30692;
                    ::prism_rtl::Turn::Finished((crate::syntax::Cond::CondExpr(::std::rc::Rc::new(e_p8.clone())), q1_p9.clone()))
                })
            }
        })
    }
}

/// `Start ParseCond, x`: what the function value is when passed to `@Run`.
pub fn start_parse_cond_f(p_p0: crate::syntax::parser::Ps, allow_guard_p1: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Cond, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseCond { p_p0, allow_guard_p1 })
}

/// ```prism
/// ParseIf: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_if_f(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p0_p0);
    let (cond_p3, p1_p4) = parse_cond_f(&crate::syntax::parser::adv_f(p0_p0), &false);
    let (then_block_p5, p2_p6) = crate::syntax::parser::blocks::parse_block_after_colon_f(&p1_p4);
    let p3_p2 = if crate::syntax::parser::at_sep_f(&p2_p6) && is_else_f(&crate::syntax::parser::kind_at_f(&p2_p6, &crate::prelude::Nat::from(1u32))) {
        crate::syntax::parser::adv_f(&p2_p6)
    } else {
        p2_p6.clone()
    };
    if crate::syntax::parser::at_kw_f(&p3_p2, &crate::prelude::Text::lit("else")) {
        {
            let (else_block_p7, q_p8) = crate::syntax::parser::blocks::parse_block_after_colon_f(&crate::syntax::parser::adv_f(&p3_p2));
            (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EIf(::std::rc::Rc::new(cond_p3.clone()), then_block_p5.clone(), ::std::option::Option::Some(else_block_p7.clone()))), span_p: crate::syntax::parser::to_f(&start_p1, &else_block_p7.span_p) }, q_p8.clone())
        }
    } else {
        (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EIf(::std::rc::Rc::new(cond_p3.clone()), then_block_p5.clone(), ::std::option::Option::None)), span_p: crate::syntax::parser::to_f(&start_p1, &then_block_p5.span_p) }, p3_p2.clone())
    }
}

/// The step machine of `ParseIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseIf: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseIf {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseIf {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let start_p1 = crate::syntax::parser::here_f(p0_p0);
        let p0_p0x = p0_p0.clone();
        crate::prelude::call_then(start_parse_cond_f(crate::syntax::parser::adv_f(&p0_p0x), false), move |parse_cond_f_30925: (crate::syntax::Cond, crate::syntax::parser::Ps)| {
            let (cond_p3, p1_p4) = parse_cond_f_30925;
            crate::prelude::call_then(crate::syntax::parser::blocks::start_parse_block_after_colon_f(p1_p4.clone()), move |parse_block_after_colon_f_30979: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                let (then_block_p5, p2_p6) = parse_block_after_colon_f_30979;
                let p3_p2 = if crate::syntax::parser::at_sep_f(&p2_p6) && is_else_f(&crate::syntax::parser::kind_at_f(&p2_p6, &crate::prelude::Nat::from(1u32))) {
                    crate::syntax::parser::adv_f(&p2_p6)
                } else {
                    p2_p6.clone()
                };
                if crate::syntax::parser::at_kw_f(&p3_p2, &crate::prelude::Text::lit("else")) {
                    crate::prelude::call_then(crate::syntax::parser::blocks::start_parse_block_after_colon_f(crate::syntax::parser::adv_f(&p3_p2)), move |parse_block_after_colon_f_31130: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                        let (else_block_p7, q_p8) = parse_block_after_colon_f_31130;
                        ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EIf(::std::rc::Rc::new(cond_p3.clone()), then_block_p5.clone(), ::std::option::Option::Some(else_block_p7.clone()))), span_p: crate::syntax::parser::to_f(&start_p1, &else_block_p7.span_p) }, q_p8.clone()))
                    })
                } else {
                    ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EIf(::std::rc::Rc::new(cond_p3.clone()), then_block_p5.clone(), ::std::option::Option::None)), span_p: crate::syntax::parser::to_f(&start_p1, &then_block_p5.span_p) }, p3_p2.clone()))
                }
            })
        })
    }
}

/// `Start ParseIf, x`: what the function value is when passed to `@Run`.
pub fn start_parse_if_f(p0_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseIf { p0_p0 })
}

/// ```prism
/// IsElse: fn TokKind -> Bool
/// ```
pub fn is_else_f(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KKw(c0_0_0, _) if (c0_0_0 == &crate::prelude::Text::lit("else")) => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParseMatch: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_match_f(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p0_p0);
    let (scrutinee_p3, p1_p4) = parse_expr_f(&crate::syntax::parser::adv_f(p0_p0));
    let p2_p2 = crate::syntax::parser::expect_colon_f(&p1_p4);
    if crate::syntax::parser::at_open_l_f(&p2_p2) && crate::syntax::parser::at_close_l_f(&crate::syntax::parser::adv_f(&p2_p2)) {
        (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EMatch(::std::rc::Rc::new(scrutinee_p3.clone()), crate::prelude::Array::new())), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&p2_p2)) }, crate::syntax::parser::adv_f(&crate::syntax::parser::adv_f(&p2_p2)))
    } else {
        if crate::syntax::parser::at_open_l_f(&p2_p2) {
            {
                let (arms_p5, q_p6) = match_arms_f(&crate::syntax::parser::adv_f(&p2_p2));
                (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EMatch(::std::rc::Rc::new(scrutinee_p3.clone()), arms_p5.clone())), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&q_p6)) }, q_p6.clone())
            }
        } else {
            (crate::syntax::parser::decls::no_expr_p(), crate::syntax::parser::error_here_f(&p2_p2, &crate::prelude::Text::lit("a `match`\'s arms stand in an indented block after its `:`")))
        }
    }
}

/// The step machine of `ParseMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseMatch: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseMatch {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseMatch {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let start_p1 = crate::syntax::parser::here_f(p0_p0);
        let p0_p0x = p0_p0.clone();
        crate::prelude::call_then(start_parse_expr_f(crate::syntax::parser::adv_f(&p0_p0x)), move |parse_expr_f_31711: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
            let (scrutinee_p3, p1_p4) = parse_expr_f_31711;
            let p2_p2 = crate::syntax::parser::expect_colon_f(&p1_p4);
            if crate::syntax::parser::at_open_l_f(&p2_p2) && crate::syntax::parser::at_close_l_f(&crate::syntax::parser::adv_f(&p2_p2)) {
                ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EMatch(::std::rc::Rc::new(scrutinee_p3.clone()), crate::prelude::Array::new())), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&p2_p2)) }, crate::syntax::parser::adv_f(&crate::syntax::parser::adv_f(&p2_p2))))
            } else {
                if crate::syntax::parser::at_open_l_f(&p2_p2) {
                    crate::prelude::call_then(start_match_arms_f(crate::syntax::parser::adv_f(&p2_p2)), move |match_arms_f_32049: (crate::prelude::Array<crate::syntax::Arm>, crate::syntax::parser::Ps)| {
                        let (arms_p5, q_p6) = match_arms_f_32049;
                        ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EMatch(::std::rc::Rc::new(scrutinee_p3.clone()), arms_p5.clone())), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&q_p6)) }, q_p6.clone()))
                    })
                } else {
                    ::prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr_p(), crate::syntax::parser::error_here_f(&p2_p2, &crate::prelude::Text::lit("a `match`\'s arms stand in an indented block after its `:`"))))
                }
            }
        })
    }
}

/// `Start ParseMatch, x`: what the function value is when passed to `@Run`.
pub fn start_parse_match_f(p0_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseMatch { p0_p0 })
}

/// ```prism
/// MatchArms: unbounded fn Ps -> (([Arm], Ps))
/// ```
pub fn match_arms_f(p0_p0: &crate::syntax::parser::Ps) -> (crate::prelude::Array<crate::syntax::Arm>, crate::syntax::parser::Ps) {
    let mut this: (crate::prelude::Array<crate::syntax::Arm>, crate::syntax::parser::Ps) = (crate::prelude::Array::new(), p0_p0.clone());
    let mut arms_p1: crate::prelude::Array<crate::syntax::Arm> = crate::prelude::Array::new();
    let mut p_p2: crate::syntax::parser::Ps = p0_p0.clone();
    let mut going_p3: bool = true;
    while going_p3 {
        let (arm_p4, q_p5) = parse_arm_f(&p_p2);
        if !q_p5.bad_p {
            arms_p1 = crate::prelude::push(&arms_p1, &arm_p4);
        }
        p_p2 = crate::syntax::parser::recovered_f(&q_p5);
        match &crate::syntax::parser::kind_f(&p_p2) {
            crate::syntax::lexer::TokKind::KLaySep => {
                p_p2 = crate::syntax::parser::adv_f(&p_p2);
            }
            crate::syntax::lexer::TokKind::KLayClose => {
                p_p2 = crate::syntax::parser::adv_f(&p_p2);
                going_p3 = false;
            }
            crate::syntax::lexer::TokKind::KEof => {
                going_p3 = false;
            }
            _ => {
                p_p2 = crate::syntax::parser::recover_f(&crate::syntax::parser::complain_f(&p_p2, &crate::prelude::Text::lit("expected the end of the arm")));
            }
        }
    }
    this = (arms_p1.clone(), p_p2.clone());
    this
}

/// The step machine of `MatchArms`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MatchArms: unbounded fn Ps -> (([Arm], Ps))
/// ```
pub struct MatchArms {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::Arm>, crate::syntax::parser::Ps)> for MatchArms {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::syntax::Arm>, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let mut this: (crate::prelude::Array<crate::syntax::Arm>, crate::syntax::parser::Ps) = (crate::prelude::Array::new(), p0_p0.clone());
        let mut arms_p1: crate::prelude::Array<crate::syntax::Arm> = crate::prelude::Array::new();
        let mut p_p2: crate::syntax::parser::Ps = p0_p0.clone();
        let mut going_p3: bool = true;
        crate::prelude::call_then(crate::prelude::loop_job((this, arms_p1, going_p3, p_p2), move |(mut this, mut arms_p1, mut going_p3, mut p_p2): ((crate::prelude::Array<crate::syntax::Arm>, crate::syntax::parser::Ps), crate::prelude::Array<crate::syntax::Arm>, bool, crate::syntax::parser::Ps)| if going_p3 {
            {
                let (arm_p4, q_p5) = parse_arm_f(&p_p2);
                if !q_p5.bad_p {
                    arms_p1 = crate::prelude::push(&arms_p1, &arm_p4);
                }
                p_p2 = crate::syntax::parser::recovered_f(&q_p5);
                match &crate::syntax::parser::kind_f(&p_p2) {
                    crate::syntax::lexer::TokKind::KLaySep => {
                        p_p2 = crate::syntax::parser::adv_f(&p_p2);
                    }
                    crate::syntax::lexer::TokKind::KLayClose => {
                        p_p2 = crate::syntax::parser::adv_f(&p_p2);
                        going_p3 = false;
                    }
                    crate::syntax::lexer::TokKind::KEof => {
                        going_p3 = false;
                    }
                    _ => {
                        p_p2 = crate::syntax::parser::recover_f(&crate::syntax::parser::complain_f(&p_p2, &crate::prelude::Text::lit("expected the end of the arm")));
                    }
                }
                ::std::result::Result::Ok((this, arms_p1, going_p3, p_p2))
            }
        } else {
            ::std::result::Result::Err((this, arms_p1, going_p3, p_p2))
        }), move |(mut this, mut arms_p1, mut going_p3, mut p_p2): ((crate::prelude::Array<crate::syntax::Arm>, crate::syntax::parser::Ps), crate::prelude::Array<crate::syntax::Arm>, bool, crate::syntax::parser::Ps)| {
            this = (arms_p1.clone(), p_p2.clone());
            ::prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start MatchArms, x`: what the function value is when passed to `@Run`.
pub fn start_match_arms_f(p0_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::Arm>, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(MatchArms { p0_p0 })
}

/// ```prism
/// ParseArm: unbounded fn Ps -> ((Arm, Ps))
/// ```
pub fn parse_arm_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Arm, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p_p0);
    if crate::syntax::parser::at_kw_f(p_p0, &crate::prelude::Text::lit("otherwise")) {
        {
            let (body_p2, q_p3) = crate::syntax::parser::blocks::parse_block_after_colon_f(&crate::syntax::parser::adv_f(p_p0));
            (crate::syntax::Arm { pattern_o: ::std::option::Option::None, guard_o: ::std::option::Option::None, body_p: body_p2.clone(), span_p: crate::syntax::parser::to_f(&start_p1, &body_p2.span_p) }, q_p3.clone())
        }
    } else {
        if crate::syntax::parser::at_kw_f(p_p0, &crate::prelude::Text::lit("ignore")) && (&crate::syntax::parser::kind_at_f(p_p0, &crate::prelude::Nat::from(1u32)) == &crate::syntax::lexer::TokKind::KColon) {
            (crate::syntax::Arm { pattern_o: ::std::option::Option::None, guard_o: ::std::option::Option::None, body_p: crate::syntax::parser::decls::no_block_p(), span_p: start_p1.clone() }, crate::syntax::parser::error_at_f(p_p0, &crate::syntax::parser::here_f(p_p0), &crate::prelude::Text::lit("an arm beginning `ignore:` would read as \"ignore these cases\": the catch-all is `otherwise:`")))
        } else {
            {
                let (pattern_p4, p1_p5) = crate::syntax::parser::types::parse_pattern_f(p_p0, &true);
                let (guard_o6, p2_p7) = if crate::syntax::parser::at_kw_f(&p1_p5, &crate::prelude::Text::lit("if")) {
                    optional_expr_f(&crate::syntax::parser::adv_f(&p1_p5))
                } else {
                    (::std::option::Option::None, p1_p5.clone())
                };
                let (body_p8, p3_p9) = crate::syntax::parser::blocks::parse_block_after_colon_f(&p2_p7);
                (crate::syntax::Arm { pattern_o: ::std::option::Option::Some(pattern_p4.clone()), guard_o: guard_o6.clone(), body_p: body_p8.clone(), span_p: crate::syntax::parser::to_f(&start_p1, &body_p8.span_p) }, p3_p9.clone())
            }
        }
    }
}

/// ```prism
/// OptionalExpr: unbounded fn Ps -> ((?Expr, Ps))
/// ```
pub fn optional_expr_f(p_p0: &crate::syntax::parser::Ps) -> (::std::option::Option<crate::syntax::Expr>, crate::syntax::parser::Ps) {
    let (e_p1, q_p2) = parse_expr_f(p_p0);
    (::std::option::Option::Some(e_p1.clone()), q_p2.clone())
}

/// ```prism
/// ParseFor: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_for_f(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p0_p0);
    let p_p2 = crate::syntax::parser::adv_f(p0_p0);
    let (binders_o3, p1_p4) = for_binders_of_f(&p_p2);
    let (source_p5, p2_p6) = parse_expr_f(&p1_p4);
    let (body_p7, p3_p8) = crate::syntax::parser::blocks::parse_block_after_colon_f(&p2_p6);
    (crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EFor(binders_o3.clone(), ::std::rc::Rc::new(source_p5.clone()), body_p7.clone())), span_p: crate::syntax::parser::to_f(&start_p1, &body_p7.span_p) }, p3_p8.clone())
}

/// The step machine of `ParseFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseFor: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseFor {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseFor {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let start_p1 = crate::syntax::parser::here_f(p0_p0);
        let p_p2 = crate::syntax::parser::adv_f(p0_p0);
        crate::prelude::call_then(start_for_binders_of_f(p_p2.clone()), move |for_binders_of_f_33911: (::std::option::Option<crate::syntax::ForBinders>, crate::syntax::parser::Ps)| {
            let (binders_o3, p1_p4) = for_binders_of_f_33911;
            crate::prelude::call_then(start_parse_expr_f(p1_p4.clone()), move |parse_expr_f_33951: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                let (source_p5, p2_p6) = parse_expr_f_33951;
                crate::prelude::call_then(crate::syntax::parser::blocks::start_parse_block_after_colon_f(p2_p6.clone()), move |parse_block_after_colon_f_33987: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                    let (body_p7, p3_p8) = parse_block_after_colon_f_33987;
                    ::prism_rtl::Turn::Finished((crate::syntax::Expr { kind_p: ::std::rc::Rc::new(crate::syntax::ExprKind::EFor(binders_o3.clone(), ::std::rc::Rc::new(source_p5.clone()), body_p7.clone())), span_p: crate::syntax::parser::to_f(&start_p1, &body_p7.span_p) }, p3_p8.clone()))
                })
            })
        })
    }
}

/// `Start ParseFor, x`: what the function value is when passed to `@Run`.
pub fn start_parse_for_f(p0_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseFor { p0_p0 })
}

/// ```prism
/// ForBindersOf: unbounded fn Ps -> ((?ForBinders, Ps))
/// ```
pub fn for_binders_of_f(p_p0: &crate::syntax::parser::Ps) -> (::std::option::Option<crate::syntax::ForBinders>, crate::syntax::parser::Ps) {
    let (first_p1, q1_p2) = crate::syntax::parser::types::parse_pattern_f(p_p0, &false);
    let (second_o3, q2_p4) = if crate::syntax::parser::at_comma_f(&q1_p2) {
        optional_pattern_f(&crate::syntax::parser::adv_f(&q1_p2))
    } else {
        (::std::option::Option::None, q1_p2.clone())
    };
    if !q2_p4.bad_p && crate::syntax::parser::at_op_f(&q2_p4, &crate::prelude::Text::lit("<-")) {
        (::std::option::Option::Some(crate::syntax::ForBinders { first_p: first_p1.clone(), second_o: second_o3.clone() }), crate::syntax::parser::adv_f(&q2_p4))
    } else {
        (::std::option::Option::None, p_p0.clone())
    }
}

/// The step machine of `ForBindersOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ForBindersOf: unbounded fn Ps -> ((?ForBinders, Ps))
/// ```
pub struct ForBindersOf {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(::std::option::Option<crate::syntax::ForBinders>, crate::syntax::parser::Ps)> for ForBindersOf {
    fn cycle(&self) -> ::prism_rtl::Turn<(::std::option::Option<crate::syntax::ForBinders>, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(crate::syntax::parser::types::start_parse_pattern_f(p_p0x.clone(), false), move |parse_pattern_f_34272: (crate::syntax::Pattern, crate::syntax::parser::Ps)| {
            let (first_p1, q1_p2) = parse_pattern_f_34272;
            let (second_o3, q2_p4) = if crate::syntax::parser::at_comma_f(&q1_p2) {
                optional_pattern_f(&crate::syntax::parser::adv_f(&q1_p2))
            } else {
                (::std::option::Option::None, q1_p2.clone())
            };
            if !q2_p4.bad_p && crate::syntax::parser::at_op_f(&q2_p4, &crate::prelude::Text::lit("<-")) {
                ::prism_rtl::Turn::Finished((::std::option::Option::Some(crate::syntax::ForBinders { first_p: first_p1.clone(), second_o: second_o3.clone() }), crate::syntax::parser::adv_f(&q2_p4)))
            } else {
                ::prism_rtl::Turn::Finished((::std::option::Option::None, p_p0x.clone()))
            }
        })
    }
}

/// `Start ForBindersOf, x`: what the function value is when passed to `@Run`.
pub fn start_for_binders_of_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(::std::option::Option<crate::syntax::ForBinders>, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ForBindersOf { p_p0 })
}

/// ```prism
/// OptionalPattern: unbounded fn Ps -> ((?Pattern, Ps))
/// ```
pub fn optional_pattern_f(p_p0: &crate::syntax::parser::Ps) -> (::std::option::Option<crate::syntax::Pattern>, crate::syntax::parser::Ps) {
    let (pat_p1, q_p2) = crate::syntax::parser::types::parse_pattern_f(p_p0, &false);
    (::std::option::Option::Some(pat_p1.clone()), q_p2.clone())
}
