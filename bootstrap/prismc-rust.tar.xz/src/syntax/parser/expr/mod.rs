//! The module `Syntax.Parser.Expr`, from `target/bootstrap/src/prismc/syntax/parser/expr.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `ArgsRead`:
///
/// ```prism
/// type ArgsRead = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ArgsRead {
    pub args: Array<crate::syntax::Arg>,
    pub rest: bool,
    pub p_: crate::syntax::parser::Ps,
    pub going: bool,
}

impl Show for ArgsRead {
    fn show(&self, p: &mut Printer) {
        p.record("ArgsRead", &[("args", &self.args), ("rest", &self.rest), ("p", &self.p_), ("going", &self.going)]);
    }
}

impl ToPod for ArgsRead {
    fn to_pod(&self) -> Pod {
        Pod::record("ArgsRead", vec![("args", self.args.to_pod()), ("rest", self.rest.to_pod()), ("p", self.p_.to_pod()), ("going", self.going.to_pod())])
    }
}

impl FromPod for ArgsRead {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ArgsRead { args: FromPod::from_pod(field(p, "args")?)?, rest: FromPod::from_pod(field(p, "rest")?)?, p_: FromPod::from_pod(field(p, "p")?)?, going: FromPod::from_pod(field(p, "going")?)? })
    }
}

/// `Climb`:
///
/// ```prism
/// type Climb = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Climb {
    pub lhs: crate::syntax::Expr,
    pub p_: crate::syntax::parser::Ps,
    pub going: bool,
}

impl Show for Climb {
    fn show(&self, p: &mut Printer) {
        p.record("Climb", &[("lhs", &self.lhs), ("p", &self.p_), ("going", &self.going)]);
    }
}

impl ToPod for Climb {
    fn to_pod(&self) -> Pod {
        Pod::record("Climb", vec![("lhs", self.lhs.to_pod()), ("p", self.p_.to_pod()), ("going", self.going.to_pod())])
    }
}

impl FromPod for Climb {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Climb { lhs: FromPod::from_pod(field(p, "lhs")?)?, p_: FromPod::from_pod(field(p, "p")?)?, going: FromPod::from_pod(field(p, "going")?)? })
    }
}

/// ```prism
/// ParseExpr: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_expr(p_: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    parse_expr_ctx(p_, &true)
}

/// The step machine of `ParseExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseExpr: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseExpr {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseExpr {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        prism_rtl::Turn::More(Rc::new(ParseExprCtx { p_: p_.clone(), commas: true }))
    }
}

/// `Start ParseExpr, x`: what the function value is when passed to `@Run`.
pub fn start_parse_expr(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(ParseExpr { p_ })
}

/// ```prism
/// ParseArgExpr: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_arg_expr(p_: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    parse_expr_ctx(p_, &false)
}

/// The step machine of `ParseArgExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseArgExpr: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseArgExpr {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseArgExpr {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        prism_rtl::Turn::More(Rc::new(ParseExprCtx { p_: p_.clone(), commas: false }))
    }
}

/// `Start ParseArgExpr, x`: what the function value is when passed to `@Run`.
pub fn start_parse_arg_expr(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(ParseArgExpr { p_ })
}

/// ```prism
/// ParseExprCtx: unbounded fn Ps, Bool -> ((Expr, Ps))
/// ```
pub fn parse_expr_ctx(p_: &crate::syntax::parser::Ps, commas: &bool) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    parse_binary(p_, &Nat::from(4u32), &(*commas && !p_.step_mode))
}

/// The step machine of `ParseExprCtx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseExprCtx: unbounded fn Ps, Bool -> ((Expr, Ps))
/// ```
pub struct ParseExprCtx {
    pub p_: crate::syntax::parser::Ps,
    pub commas: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseExprCtx {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let commas = &self.commas;
        prism_rtl::Turn::More(Rc::new(ParseBinary { p0: p_.clone(), min_: Nat::from(4u32), commas: *commas && !p_.step_mode }))
    }
}

/// `Start ParseExprCtx, x`: what the function value is when passed to `@Run`.
pub fn start_parse_expr_ctx(p_: crate::syntax::parser::Ps, commas: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(ParseExprCtx { p_, commas })
}

/// ```prism
/// ParseRhsExpr: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_rhs_expr(p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let mut this: (crate::syntax::Expr, crate::syntax::parser::Ps) = parse_expr(p0);
    let (e0, p1) = this.clone();
    let mut e: crate::syntax::Expr = e0.clone();
    let mut p_: crate::syntax::parser::Ps = p1.clone();
    while at_line_method(&p_) {
        let (method, p2) = crate::syntax::parser::parse_sname(&crate::syntax::parser::adv(&p_));
        let (args, p3) = if arg_starts_here(&p2) {
            parse_call_args(&p2, &true)
        } else {
            (Array::new(), p2.clone())
        };
        e = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMethod(Rc::new(e.clone()), method.clone(), args.clone())), span: crate::syntax::parser::to(&e.span, &crate::syntax::parser::prev(&p3)) };
        p_ = p3.clone();
    }
    this = (e.clone(), p_.clone());
    this
}

/// The step machine of `ParseRhsExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseRhsExpr: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseRhsExpr {
    pub p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseRhsExpr {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let mut this: (crate::syntax::Expr, crate::syntax::parser::Ps) = parse_expr(p0);
        let (e0, p1) = this.clone();
        let mut e: crate::syntax::Expr = e0.clone();
        let mut p_: crate::syntax::parser::Ps = p1.clone();
        call_then(loop_job((this, e, p_), move |(mut this, mut e, mut p_): ((crate::syntax::Expr, crate::syntax::parser::Ps), crate::syntax::Expr, crate::syntax::parser::Ps)| if at_line_method(&p_) {
            {
                let (method, p2) = crate::syntax::parser::parse_sname(&crate::syntax::parser::adv(&p_));
                let (args, p3) = if arg_starts_here(&p2) {
                    parse_call_args(&p2, &true)
                } else {
                    (Array::new(), p2.clone())
                };
                e = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMethod(Rc::new(e.clone()), method.clone(), args.clone())), span: crate::syntax::parser::to(&e.span, &crate::syntax::parser::prev(&p3)) };
                p_ = p3.clone();
                Ok((this, e, p_))
            }
        } else {
            Err((this, e, p_))
        }), move |(mut this, mut e, mut p_): ((crate::syntax::Expr, crate::syntax::parser::Ps), crate::syntax::Expr, crate::syntax::parser::Ps)| {
            this = (e.clone(), p_.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start ParseRhsExpr, x`: what the function value is when passed to `@Run`.
pub fn start_parse_rhs_expr(p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(ParseRhsExpr { p0 })
}

/// ```prism
/// AtLineMethod: fn Ps -> Bool
/// ```
pub fn at_line_method(p_: &crate::syntax::parser::Ps) -> bool {
    ((&crate::syntax::parser::kind(p_) == &crate::syntax::lexer::TokKind::KDot(true)) && crate::syntax::parser::tk(p_).line_start) && is_plain_upper(&crate::syntax::parser::kind_at(p_, &Nat::from(1u32)))
}

/// ```prism
/// IsPlainUpper: fn TokKind -> Bool
/// ```
pub fn is_plain_upper(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KName(n) => (&n.case == &crate::syntax::lexer::NameCase::CaseUpper) && (&n.sigils == &Text::lit("")),
        _ => false,
    }
}

/// ```prism
/// IsUpperTok: fn TokKind -> Bool
/// ```
pub fn is_upper_tok(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KName(n) => &n.case == &crate::syntax::lexer::NameCase::CaseUpper,
        _ => false,
    }
}

/// ```prism
/// ?PeekBinop: fn Ps -> ?((Text, ?[Text]))
/// ```
pub fn peek_binop(p_: &crate::syntax::parser::Ps) -> Option<(Text, Option<Array<Text>>)> {
    match crate::syntax::parser::kind(p_) {
        crate::syntax::lexer::TokKind::KOp(op, prefix) if (!prefix || (&op == &Text::lit("-?"))) => if is_binop(&op) { Some((op.clone(), None)) } else { None },
        crate::syntax::lexer::TokKind::KSuffixed(op, ty) => if is_binop(&op) { Some((op.clone(), Some(ty))) } else { None },
        crate::syntax::lexer::TokKind::KKw(m2766_2_0, m2766_2_1) if (&m2766_2_0 == &Text::lit("on")) && (&m2766_2_1 == &Text::lit("")) => Some((Text::lit("on"), None)),
        crate::syntax::lexer::TokKind::KKw(m2766_3_0, m2766_3_1) if (&m2766_3_0 == &Text::lit("or")) && (&m2766_3_1 == &Text::lit("")) => Some((Text::lit("or"), None)),
        crate::syntax::lexer::TokKind::KKw(m2766_4_0, m2766_4_1) if (&m2766_4_0 == &Text::lit("and")) && (&m2766_4_1 == &Text::lit("")) => Some((Text::lit("and"), None)),
        crate::syntax::lexer::TokKind::KKw(m2766_5_0, m2766_5_1) if (&m2766_5_0 == &Text::lit("mod")) && (&m2766_5_1 == &Text::lit("")) => Some((Text::lit("mod"), None)),
        _ => None,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IsBinop: fn Text -> Bool
/// ```
pub fn is_binop(op: &Text) -> bool {
    fold(&Array::from(vec![Text::lit("<|"), Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit("<="), Text::lit(">"), Text::lit(">="), Text::lit("+"), Text::lit("-"), Text::lit("+?"), Text::lit("-?"), Text::lit("*"), Text::lit("/"), Text::lit("*?")]), &false, &(|seen: &bool, o: &Text| *seen || (o == op)))
}

/// ```prism
/// Level: fn Text -> Nat
/// ```
pub fn level(text0: &Text) -> Nat {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("<|")) => Nat::from(4u32),
        c1_0 if (c1_0 == &Text::lit("on")) => Nat::from(5u32),
        c2_0 if (c2_0 == &Text::lit("or")) => Nat::from(6u32),
        c3_0 if (c3_0 == &Text::lit("and")) => Nat::from(7u32),
        c4_0 if (c4_0 == &Text::lit("+")) => Nat::from(10u32),
        c5_0 if (c5_0 == &Text::lit("-")) => Nat::from(10u32),
        c6_0 if (c6_0 == &Text::lit("+?")) => Nat::from(10u32),
        c7_0 if (c7_0 == &Text::lit("-?")) => Nat::from(10u32),
        c8_0 if (c8_0 == &Text::lit("*")) => Nat::from(11u32),
        c9_0 if (c9_0 == &Text::lit("/")) => Nat::from(11u32),
        c10_0 if (c10_0 == &Text::lit("*?")) => Nat::from(11u32),
        c11_0 if (c11_0 == &Text::lit("mod")) => Nat::from(11u32),
        _ => Nat::from(9u32),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParseBinary: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
/// ```
pub fn parse_binary(p0: &crate::syntax::parser::Ps, min_: &Nat, commas: &bool) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let (lhs, p1) = parse_prefix(p0, min_, commas);
    let r = {
        let mut this: Climb = Climb { lhs: lhs.clone(), p_: p1.clone(), going: true };
        while this.going && !this.p_.bad {
            this = climb_step(&this, min_, commas);
        }
        this
    };
    (r.lhs.clone(), r.p_.clone())
}

/// The step machine of `ParseBinary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseBinary: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
/// ```
pub struct ParseBinary {
    pub p0: crate::syntax::parser::Ps,
    pub min_: Nat,
    pub commas: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseBinary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let min_ = &self.min_;
        let commas = &self.commas;
        let commas = *commas;
        let min_ = min_.clone();
        let p0 = p0.clone();
        call_then(start_parse_prefix(p0.clone(), min_.clone(), commas), move |parse_prefix_4034: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
            let (lhs, p1) = parse_prefix_4034;
            let mut this: Climb = Climb { lhs: lhs.clone(), p_: p1.clone(), going: true };
            let lhs = lhs.clone();
            call_then(loop_job((this,), {
                let commas = commas;
                let min_ = min_.clone();
                move |(mut this,): (Climb,)| if this.going && !this.p_.bad {
                    {
                        this = climb_step(&this, &min_, &commas);
                        Ok((this,))
                    }
                } else {
                    Err((this,))
                }
            }), move |(mut this,): (Climb,)| {
                let r = this;
                prism_rtl::Turn::Finished((r.lhs.clone(), r.p_.clone()))
            })
        })
    }
}

/// `Start ParseBinary, x`: what the function value is when passed to `@Run`.
pub fn start_parse_binary(p0: crate::syntax::parser::Ps, min_: Nat, commas: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(ParseBinary { p0, min_, commas })
}

/// ```prism
/// ClimbStep: unbounded fn Climb, Nat, Bool -> Climb
/// ```
pub fn climb_step(c: &Climb, min_: &Nat, commas: &bool) -> Climb {
    let p_ = c.p_.clone();
    if crate::syntax::parser::at_kw(&p_, &Text::lit("as")) && (min_ <= &Nat::from(12u32)) {
        {
            let (ty, p2) = crate::syntax::parser::types::parse_type(&crate::syntax::parser::adv(&p_));
            let checked = (&crate::syntax::parser::kind(&p2) == &crate::syntax::lexer::TokKind::KFree(Text::lit("?"))) && crate::syntax::parser::tk(&p2).touches;
            let p3 = if checked { crate::syntax::parser::adv(&p2) } else { p2.clone() };
            {
                let mut this: Climb = c.clone();
                this.lhs = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECast(Rc::new(this.lhs.clone()), ty.clone(), checked)), span: crate::syntax::parser::to(&this.lhs.span, &crate::syntax::parser::prev(&p3)) };
                this.p_ = p3.clone();
                this
            }
        }
    } else {
        match peek_binop(&p_) {
            None => {
                let mut this: Climb = c.clone();
                this.going = false;
                this.p_ = no_operator(&p_);
                this
            },
            Some((op, suffix_opt)) => if &level(&op) < min_ {
                {
                    let mut this: Climb = c.clone();
                    this.going = false;
                    this
                }
            } else {
                {
                    let p1 = if &crate::syntax::parser::kind(&p_) == &crate::syntax::lexer::TokKind::KOp(Text::lit("-?"), true) {
                        crate::syntax::parser::note_error(&p_, &crate::syntax::parser::here(&p_), &Text::lit("`-?` is the checked subtraction by longest match; to subtract or negate an optional, write `-(?x)`"))
                    } else {
                        p_.clone()
                    };
                    let op_tok = crate::syntax::parser::tk(&p1);
                    let (rhs, p2) = parse_binary(&crate::syntax::parser::adv(&p1), &(&level(&op) + &Nat::from(1u32)), commas);
                    let span = crate::syntax::parser::to(&c.lhs.span, &rhs.span);
                    let kind = match &suffix_opt {
                        None => crate::syntax::ExprKind::EBinary(op.clone(), Rc::new(c.lhs.clone()), Rc::new(rhs.clone())),
                        Some(ty) => crate::syntax::ExprKind::ESuffixed(op.clone(), crate::syntax::QualName { path_: ty.clone(), span: op_tok.span.clone() }, Rc::new(c.lhs.clone()), Rc::new(rhs.clone())),
                    };
                    let p3 = if &suffix_opt == &None {
                        p2.clone()
                    } else {
                        crate::syntax::parser::out_of_scope(&p2, &op_tok.span, &Text::lit("suffixed operators"), &Text::from(format!("the suffixed operator `{}` is out of this compiler", &crate::syntax::lexer::corpus::token_text(&op_tok.kind))))
                    };
                    {
                        let mut this: Climb = c.clone();
                        this.lhs = crate::syntax::Expr { kind: Rc::new(kind.clone()), span: span.clone() };
                        this.p_ = p3.clone();
                        this
                    }
                }
            },
        }
    }
}

/// The step machine of `ClimbStep`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClimbStep: unbounded fn Climb, Nat, Bool -> Climb
/// ```
pub struct ClimbStep {
    pub c: Climb,
    pub min_: Nat,
    pub commas: bool,
}

impl prism_rtl::Job<Climb> for ClimbStep {
    fn cycle(&self) -> prism_rtl::Turn<Climb> {
        let c = &self.c;
        let min_ = &self.min_;
        let commas = &self.commas;
        let p_ = c.p_.clone();
        if crate::syntax::parser::at_kw(&p_, &Text::lit("as")) && (min_ <= &Nat::from(12u32)) {
            {
                let c = c.clone();
                call_then(crate::syntax::parser::types::start_parse_type(crate::syntax::parser::adv(&p_)), move |parse_type_4430: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (ty, p2) = parse_type_4430;
                    let checked = (&crate::syntax::parser::kind(&p2) == &crate::syntax::lexer::TokKind::KFree(Text::lit("?"))) && crate::syntax::parser::tk(&p2).touches;
                    let p3 = if checked { crate::syntax::parser::adv(&p2) } else { p2.clone() };
                    prism_rtl::Turn::Finished({
                        let mut this: Climb = c.clone();
                        this.lhs = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECast(Rc::new(this.lhs.clone()), ty.clone(), checked)), span: crate::syntax::parser::to(&this.lhs.span, &crate::syntax::parser::prev(&p3)) };
                        this.p_ = p3.clone();
                        this
                    })
                })
            }
        } else {
            match peek_binop(&p_) {
                None => prism_rtl::Turn::Finished({
                    let mut this: Climb = c.clone();
                    this.going = false;
                    this.p_ = no_operator(&p_);
                    this
                }),
                Some((op, suffix_opt)) => if &level(&op) < min_ {
                    prism_rtl::Turn::Finished({
                        let mut this: Climb = c.clone();
                        this.going = false;
                        this
                    })
                } else {
                    {
                        let p1 = if &crate::syntax::parser::kind(&p_) == &crate::syntax::lexer::TokKind::KOp(Text::lit("-?"), true) {
                            crate::syntax::parser::note_error(&p_, &crate::syntax::parser::here(&p_), &Text::lit("`-?` is the checked subtraction by longest match; to subtract or negate an optional, write `-(?x)`"))
                        } else {
                            p_.clone()
                        };
                        let op_tok = crate::syntax::parser::tk(&p1);
                        let c = c.clone();
                        let commas = *commas;
                        call_then(start_parse_binary(crate::syntax::parser::adv(&p1), &level(&op) + &Nat::from(1u32), commas), move |parse_binary_5342: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                            let (rhs, p2) = parse_binary_5342;
                            let span = crate::syntax::parser::to(&c.lhs.span, &rhs.span);
                            let kind = match &suffix_opt {
                                None => crate::syntax::ExprKind::EBinary(op.clone(), Rc::new(c.lhs.clone()), Rc::new(rhs.clone())),
                                Some(ty) => crate::syntax::ExprKind::ESuffixed(op.clone(), crate::syntax::QualName { path_: ty.clone(), span: op_tok.span.clone() }, Rc::new(c.lhs.clone()), Rc::new(rhs.clone())),
                            };
                            let p3 = if &suffix_opt == &None {
                                p2.clone()
                            } else {
                                crate::syntax::parser::out_of_scope(&p2, &op_tok.span, &Text::lit("suffixed operators"), &Text::from(format!("the suffixed operator `{}` is out of this compiler", &crate::syntax::lexer::corpus::token_text(&op_tok.kind))))
                            };
                            prism_rtl::Turn::Finished({
                                let mut this: Climb = c.clone();
                                this.lhs = crate::syntax::Expr { kind: Rc::new(kind.clone()), span: span.clone() };
                                this.p_ = p3.clone();
                                this
                            })
                        })
                    }
                },
            }
        }
    }
}

/// `Start ClimbStep, x`: what the function value is when passed to `@Run`.
pub fn start_climb_step(c: Climb, min_: Nat, commas: bool) -> Rc<dyn prism_rtl::Job<Climb>> {
    Rc::new(ClimbStep { c, min_, commas })
}

/// ```prism
/// NoOperator: fn Ps -> Ps
/// ```
pub fn no_operator(p_: &crate::syntax::parser::Ps) -> crate::syntax::parser::Ps {
    match crate::syntax::parser::kind(p_) {
        crate::syntax::lexer::TokKind::KOp(o, true) if (((&o == &Text::lit("-")) || (&o == &Text::lit("+"))) && !crate::syntax::parser::tk(p_).line_start) => crate::syntax::parser::error_at(p_, &crate::syntax::parser::here(p_), &Text::from(format!("`{}` here is a prefix sign by the spacing rule (a space before it and none after); did you mean `a {} 1`, with spaces on both sides?", &o, &o))),
        crate::syntax::lexer::TokKind::KBar => crate::syntax::parser::error_at(p_, &crate::syntax::parser::here(p_), &Text::lit("a bare `|` is not an operator: the merge is `<|`, and `|` separates the families of a row")),
        crate::syntax::lexer::TokKind::KDot(true) if (!at_line_method(p_) && is_upper_tok(&crate::syntax::parser::kind_at(p_, &Nat::from(1u32)))) => crate::syntax::parser::error_at(p_, &crate::syntax::parser::here(p_), &Text::lit("a spaced `.Method` begins its own line, below the call it takes as its receiver (layout rule 9)")),
        _ => p_.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParsePrefix: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
/// ```
pub fn parse_prefix(p_: &crate::syntax::parser::Ps, min_: &Nat, commas: &bool) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p_);
    if crate::syntax::parser::at_kw(p_, &Text::lit("not")) {
        {
            let (operand, q) = parse_binary(&crate::syntax::parser::adv(p_), &max(&Nat::from(9u32), min_), commas);
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EUnary(Text::lit("not"), Rc::new(operand.clone()))), span: crate::syntax::parser::to(&start, &operand.span) }, q.clone())
        }
    } else {
        match crate::syntax::parser::kind(p_) {
            crate::syntax::lexer::TokKind::KOp(op, true) if ((&op == &Text::lit("-")) || (&op == &Text::lit("+"))) => {
                let (operand, q) = parse_postfix_expr(&crate::syntax::parser::adv(p_), commas);
                let name = if &op == &Text::lit("-") { Text::lit("neg") } else { Text::lit("pos") };
                (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EUnary(name.clone(), Rc::new(operand.clone()))), span: crate::syntax::parser::to(&start, &operand.span) }, q.clone())
            },
            crate::syntax::lexer::TokKind::KOp(m7135_1_0, _) if (&m7135_1_0 == &Text::lit("-?")) => (crate::syntax::parser::decls::no_expr(), crate::syntax::parser::error_at(p_, &crate::syntax::parser::here(p_), &Text::lit("`-?` is the checked subtraction and needs a left operand; to negate an optional write `-(?x)`"))),
            _ => parse_postfix_expr(p_, commas),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// The step machine of `ParsePrefix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParsePrefix: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
/// ```
pub struct ParsePrefix {
    pub p_: crate::syntax::parser::Ps,
    pub min_: Nat,
    pub commas: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParsePrefix {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let min_ = &self.min_;
        let commas = &self.commas;
        let start = crate::syntax::parser::here(p_);
        if crate::syntax::parser::at_kw(p_, &Text::lit("not")) {
            {
                let commas = *commas;
                let min_ = min_.clone();
                let p_ = p_.clone();
                call_then(start_parse_binary(crate::syntax::parser::adv(&p_), max(&Nat::from(9u32), &min_), commas), move |parse_binary_7002: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (operand, q) = parse_binary_7002;
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EUnary(Text::lit("not"), Rc::new(operand.clone()))), span: crate::syntax::parser::to(&start, &operand.span) }, q.clone()))
                })
            }
        } else {
            match crate::syntax::parser::kind(p_) {
                crate::syntax::lexer::TokKind::KOp(op, true) if ((&op == &Text::lit("-")) || (&op == &Text::lit("+"))) => {
                    let commas = *commas;
                    let p_ = p_.clone();
                    call_then(start_parse_postfix_expr(crate::syntax::parser::adv(&p_), commas), move |parse_postfix_expr_7230: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                        let (operand, q) = parse_postfix_expr_7230;
                        let name = if &op == &Text::lit("-") { Text::lit("neg") } else { Text::lit("pos") };
                        prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EUnary(name.clone(), Rc::new(operand.clone()))), span: crate::syntax::parser::to(&start, &operand.span) }, q.clone()))
                    })
                },
                crate::syntax::lexer::TokKind::KOp(m7135_1_0, _) if (&m7135_1_0 == &Text::lit("-?")) => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), crate::syntax::parser::error_at(p_, &crate::syntax::parser::here(p_), &Text::lit("`-?` is the checked subtraction and needs a left operand; to negate an optional write `-(?x)`")))),
                _ => prism_rtl::Turn::More(Rc::new(ParsePostfixExpr { p_: p_.clone(), commas: *commas })),
                _ => unreachable!("no arm matched"),
            }
        }
    }
}

/// `Start ParsePrefix, x`: what the function value is when passed to `@Run`.
pub fn start_parse_prefix(p_: crate::syntax::parser::Ps, min_: Nat, commas: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(ParsePrefix { p_, min_, commas })
}

/// ```prism
/// ParsePostfixExpr: unbounded fn Ps, Bool -> ((Expr, Ps))
/// ```
pub fn parse_postfix_expr(p_: &crate::syntax::parser::Ps, commas: &bool) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let (e, took_rest, q) = parse_primary(p_, commas);
    if took_rest { (e.clone(), q.clone()) } else { parse_postfix(&e, &q, commas) }
}

/// The step machine of `ParsePostfixExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParsePostfixExpr: unbounded fn Ps, Bool -> ((Expr, Ps))
/// ```
pub struct ParsePostfixExpr {
    pub p_: crate::syntax::parser::Ps,
    pub commas: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParsePostfixExpr {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let commas = &self.commas;
        let commas = *commas;
        let p_ = p_.clone();
        call_then(start_parse_primary(p_.clone(), commas), move |parse_primary_7837: (crate::syntax::Expr, bool, crate::syntax::parser::Ps)| {
            let (e, took_rest, q) = parse_primary_7837;
            if took_rest {
                prism_rtl::Turn::Finished((e.clone(), q.clone()))
            } else {
                prism_rtl::Turn::More(Rc::new(ParsePostfix { e0: e.clone(), p0: q.clone(), commas }))
            }
        })
    }
}

/// `Start ParsePostfixExpr, x`: what the function value is when passed to `@Run`.
pub fn start_parse_postfix_expr(p_: crate::syntax::parser::Ps, commas: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(ParsePostfixExpr { p_, commas })
}

/// ```prism
/// ParsePostfix: unbounded fn Expr, Ps, Bool -> ((Expr, Ps))
/// ```
pub fn parse_postfix(e0: &crate::syntax::Expr, p0: &crate::syntax::parser::Ps, commas: &bool) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let mut this: (crate::syntax::Expr, crate::syntax::parser::Ps) = (e0.clone(), p0.clone());
    let mut e: crate::syntax::Expr = e0.clone();
    let mut p_: crate::syntax::parser::Ps = p0.clone();
    let mut going: bool = true;
    while going && !p_.bad {
        let (e2, p2, more_) = postfix_step(&e, &p_, commas);
        e = e2.clone();
        p_ = p2.clone();
        going = more_;
    }
    this = (e.clone(), p_.clone());
    this
}

/// The step machine of `ParsePostfix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParsePostfix: unbounded fn Expr, Ps, Bool -> ((Expr, Ps))
/// ```
pub struct ParsePostfix {
    pub e0: crate::syntax::Expr,
    pub p0: crate::syntax::parser::Ps,
    pub commas: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParsePostfix {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let e0 = &self.e0;
        let p0 = &self.p0;
        let commas = &self.commas;
        let mut this: (crate::syntax::Expr, crate::syntax::parser::Ps) = (e0.clone(), p0.clone());
        let mut e: crate::syntax::Expr = e0.clone();
        let mut p_: crate::syntax::parser::Ps = p0.clone();
        let mut going: bool = true;
        call_then(loop_job((this, e, going, p_), {
            let commas = *commas;
            move |(mut this, mut e, mut going, mut p_): ((crate::syntax::Expr, crate::syntax::parser::Ps), crate::syntax::Expr, bool, crate::syntax::parser::Ps)| if going && !p_.bad {
                {
                    let (e2, p2, more_) = postfix_step(&e, &p_, &commas);
                    e = e2.clone();
                    p_ = p2.clone();
                    going = more_;
                    Ok((this, e, going, p_))
                }
            } else {
                Err((this, e, going, p_))
            }
        }), move |(mut this, mut e, mut going, mut p_): ((crate::syntax::Expr, crate::syntax::parser::Ps), crate::syntax::Expr, bool, crate::syntax::parser::Ps)| {
            this = (e.clone(), p_.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start ParsePostfix, x`: what the function value is when passed to `@Run`.
pub fn start_parse_postfix(e0: crate::syntax::Expr, p0: crate::syntax::parser::Ps, commas: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(ParsePostfix { e0, p0, commas })
}

/// ```prism
/// PostfixStep: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
/// ```
pub fn postfix_step(e: &crate::syntax::Expr, p_: &crate::syntax::parser::Ps, commas: &bool) -> (crate::syntax::Expr, crate::syntax::parser::Ps, bool) {
    match crate::syntax::parser::kind(p_) {
        crate::syntax::lexer::TokKind::KDot(false) => field_or_method(e, p_, commas),
        crate::syntax::lexer::TokKind::KOpen(m8467_1_0, false) if (&m8467_1_0 == &Text::lit("[")) && (crate::syntax::parser::tk(p_).touches && !crate::syntax::parser::at_double_open(p_, &Text::lit("["))) => {
            let (index_, p1) = crate::syntax::parser::bracketed(&crate::syntax::parser::adv(p_), &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_expr(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>));
            let p2 = crate::syntax::parser::expect_close(&p1, &Text::lit("["));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EIndex(Rc::new(e.clone()), Rc::new(index_.clone()))), span: crate::syntax::parser::to(&e.span, &crate::syntax::parser::prev(&p2)) }, p2.clone(), true)
        },
        crate::syntax::lexer::TokKind::KLtLt => {
            let (types, q) = parse_type_args(p_);
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETypeArgs(Rc::new(e.clone()), types.clone())), span: crate::syntax::parser::to(&e.span, &crate::syntax::parser::prev(&q)) }, q.clone(), true)
        },
        crate::syntax::lexer::TokKind::KNonEmpty => {
            let span = crate::syntax::parser::here(p_);
            let q = crate::syntax::parser::out_of_scope(&crate::syntax::parser::adv(p_), &span, &Text::lit("non-empty arrays"), &Text::lit("the non-empty mark `+` is out of this compiler"));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ENonEmpty(Rc::new(e.clone()))), span: crate::syntax::parser::to(&e.span, &span) }, q.clone(), true)
        },
        _ => (e.clone(), p_.clone(), false),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `PostfixStep`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PostfixStep: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
/// ```
pub struct PostfixStep {
    pub e: crate::syntax::Expr,
    pub p_: crate::syntax::parser::Ps,
    pub commas: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps, bool)> for PostfixStep {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps, bool)> {
        let e = &self.e;
        let p_ = &self.p_;
        let commas = &self.commas;
        match crate::syntax::parser::kind(p_) {
            crate::syntax::lexer::TokKind::KDot(false) => prism_rtl::Turn::More(Rc::new(FieldOrMethod { e: e.clone(), p0: p_.clone(), commas: *commas })),
            crate::syntax::lexer::TokKind::KOpen(m8467_1_0, false) if (&m8467_1_0 == &Text::lit("[")) && (crate::syntax::parser::tk(p_).touches && !crate::syntax::parser::at_double_open(p_, &Text::lit("["))) => {
                let e = e.clone();
                let p_ = p_.clone();
                call_then(crate::syntax::parser::start_bracketed(crate::syntax::parser::adv(&p_), Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_expr(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>), move |bracketed_8622: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (index_, p1) = bracketed_8622;
                    let p2 = crate::syntax::parser::expect_close(&p1, &Text::lit("["));
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EIndex(Rc::new(e.clone()), Rc::new(index_.clone()))), span: crate::syntax::parser::to(&e.span, &crate::syntax::parser::prev(&p2)) }, p2.clone(), true))
                })
            },
            crate::syntax::lexer::TokKind::KLtLt => {
                let e = e.clone();
                let p_ = p_.clone();
                call_then(start_parse_type_args(p_.clone()), move |parse_type_args_8806: (Array<crate::syntax::Type>, crate::syntax::parser::Ps)| {
                    let (types, q) = parse_type_args_8806;
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETypeArgs(Rc::new(e.clone()), types.clone())), span: crate::syntax::parser::to(&e.span, &crate::syntax::parser::prev(&q)) }, q.clone(), true))
                })
            },
            crate::syntax::lexer::TokKind::KNonEmpty => {
                let span = crate::syntax::parser::here(p_);
                let q = crate::syntax::parser::out_of_scope(&crate::syntax::parser::adv(p_), &span, &Text::lit("non-empty arrays"), &Text::lit("the non-empty mark `+` is out of this compiler"));
                prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ENonEmpty(Rc::new(e.clone()))), span: crate::syntax::parser::to(&e.span, &span) }, q.clone(), true))
            },
            _ => prism_rtl::Turn::Finished((e.clone(), p_.clone(), false)),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start PostfixStep, x`: what the function value is when passed to `@Run`.
pub fn start_postfix_step(e: crate::syntax::Expr, p_: crate::syntax::parser::Ps, commas: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps, bool)>> {
    Rc::new(PostfixStep { e, p_, commas })
}

/// ```prism
/// FieldOrMethod: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
/// ```
pub fn field_or_method(e: &crate::syntax::Expr, p0: &crate::syntax::parser::Ps, commas: &bool) -> (crate::syntax::Expr, crate::syntax::parser::Ps, bool) {
    let dot = crate::syntax::parser::here(p0);
    let p_ = crate::syntax::parser::adv(p0);
    match crate::syntax::parser::kind(&p_) {
        crate::syntax::lexer::TokKind::KName(n) if ((&len(&n.path_) == &Nat::from(1u32)) && ((&n.case == &crate::syntax::lexer::NameCase::CaseLower) || (&n.case == &crate::syntax::lexer::NameCase::CaseTopic))) => {
            let t = crate::syntax::parser::here(&p_);
            let field_ = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EField(Rc::new(e.clone()), n.sigils.clone(), crate::syntax::Ident { name: or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")), span: t.clone() })), span: crate::syntax::parser::to(&e.span, &t) };
            let p1 = crate::syntax::parser::adv(&p_);
            if arg_starts_here(&p1) && !crate::syntax::parser::tk(&p1).line_start {
                {
                    let (args, p2) = parse_call_args(&p1, commas);
                    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECall(Rc::new(field_.clone()), args.clone(), false, false)), span: crate::syntax::parser::to(&field_.span, &crate::syntax::parser::prev(&p2)) }, p2.clone(), false)
                }
            } else {
                (field_.clone(), p1.clone(), true)
            }
        },
        crate::syntax::lexer::TokKind::KKw(w, m9299_1_1) if (&m9299_1_1 == &Text::lit("")) && crate::syntax::lexer::is_bound_word(&w) => {
            let t = crate::syntax::parser::here(&p_);
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EField(Rc::new(e.clone()), Text::lit(""), crate::syntax::Ident { name: w.clone(), span: t.clone() })), span: crate::syntax::parser::to(&e.span, &t) }, crate::syntax::parser::adv(&p_), true)
        },
        crate::syntax::lexer::TokKind::KName(n) if ((&n.case == &crate::syntax::lexer::NameCase::CaseUpper) || (&n.case == &crate::syntax::lexer::NameCase::CaseReserved)) => {
            let (method, p1) = crate::syntax::parser::parse_sname(&p_);
            let (args, p2) = if arg_starts_here(&p1) {
                parse_call_args(&p1, commas)
            } else {
                (Array::new(), p1.clone())
            };
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMethod(Rc::new(e.clone()), method.clone(), args.clone())), span: crate::syntax::parser::to(&e.span, &crate::syntax::parser::prev(&p2)) }, p2.clone(), false)
        },
        _ => (e.clone(), crate::syntax::parser::error_at(&p_, &dot, &Text::lit("expected a field name or a `.Method` after `.`")), false),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `FieldOrMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldOrMethod: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
/// ```
pub struct FieldOrMethod {
    pub e: crate::syntax::Expr,
    pub p0: crate::syntax::parser::Ps,
    pub commas: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps, bool)> for FieldOrMethod {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps, bool)> {
        let e = &self.e;
        let p0 = &self.p0;
        let commas = &self.commas;
        let dot = crate::syntax::parser::here(p0);
        let p_ = crate::syntax::parser::adv(p0);
        match crate::syntax::parser::kind(&p_) {
            crate::syntax::lexer::TokKind::KName(n) if ((&len(&n.path_) == &Nat::from(1u32)) && ((&n.case == &crate::syntax::lexer::NameCase::CaseLower) || (&n.case == &crate::syntax::lexer::NameCase::CaseTopic))) => {
                let t = crate::syntax::parser::here(&p_);
                let field_ = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EField(Rc::new(e.clone()), n.sigils.clone(), crate::syntax::Ident { name: or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")), span: t.clone() })), span: crate::syntax::parser::to(&e.span, &t) };
                let p1 = crate::syntax::parser::adv(&p_);
                if arg_starts_here(&p1) && !crate::syntax::parser::tk(&p1).line_start {
                    {
                        let commas = *commas;
                        call_then(start_parse_call_args(p1.clone(), commas), move |parse_call_args_9918: (Array<crate::syntax::Arg>, crate::syntax::parser::Ps)| {
                            let (args, p2) = parse_call_args_9918;
                            prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECall(Rc::new(field_.clone()), args.clone(), false, false)), span: crate::syntax::parser::to(&field_.span, &crate::syntax::parser::prev(&p2)) }, p2.clone(), false))
                        })
                    }
                } else {
                    prism_rtl::Turn::Finished((field_.clone(), p1.clone(), true))
                }
            },
            crate::syntax::lexer::TokKind::KKw(w, m9299_1_1) if (&m9299_1_1 == &Text::lit("")) && crate::syntax::lexer::is_bound_word(&w) => {
                let t = crate::syntax::parser::here(&p_);
                prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EField(Rc::new(e.clone()), Text::lit(""), crate::syntax::Ident { name: w.clone(), span: t.clone() })), span: crate::syntax::parser::to(&e.span, &t) }, crate::syntax::parser::adv(&p_), true))
            },
            crate::syntax::lexer::TokKind::KName(n) if ((&n.case == &crate::syntax::lexer::NameCase::CaseUpper) || (&n.case == &crate::syntax::lexer::NameCase::CaseReserved)) => {
                let (method, p1) = crate::syntax::parser::parse_sname(&p_);
                let (args, p2) = if arg_starts_here(&p1) {
                    parse_call_args(&p1, commas)
                } else {
                    (Array::new(), p1.clone())
                };
                prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMethod(Rc::new(e.clone()), method.clone(), args.clone())), span: crate::syntax::parser::to(&e.span, &crate::syntax::parser::prev(&p2)) }, p2.clone(), false))
            },
            _ => prism_rtl::Turn::Finished((e.clone(), crate::syntax::parser::error_at(&p_, &dot, &Text::lit("expected a field name or a `.Method` after `.`")), false)),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start FieldOrMethod, x`: what the function value is when passed to `@Run`.
pub fn start_field_or_method(e: crate::syntax::Expr, p0: crate::syntax::parser::Ps, commas: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps, bool)>> {
    Rc::new(FieldOrMethod { e, p0, commas })
}

/// ```prism
/// ParseTypeArgs: unbounded fn Ps -> (([Type], Ps))
/// ```
pub fn parse_type_args(p_: &crate::syntax::parser::Ps) -> (Array<crate::syntax::Type>, crate::syntax::parser::Ps) {
    let (types, q) = crate::syntax::parser::commas(&crate::syntax::parser::adv(p_), &(Rc::new(|a0: crate::syntax::parser::Ps| entered(crate::syntax::parser::types::start_parse_type(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>>>));
    if &crate::syntax::parser::kind(&q) == &crate::syntax::lexer::TokKind::KGtGt {
        (types.clone(), crate::syntax::parser::adv(&q))
    } else {
        (types.clone(), crate::syntax::parser::error_here(&q, &Text::lit("expected `>>` to close the type arguments")))
    }
}

/// The step machine of `ParseTypeArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTypeArgs: unbounded fn Ps -> (([Type], Ps))
/// ```
pub struct ParseTypeArgs {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(Array<crate::syntax::Type>, crate::syntax::parser::Ps)> for ParseTypeArgs {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::Type>, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let p_ = p_.clone();
        call_then(crate::syntax::parser::start_commas(crate::syntax::parser::adv(&p_), Rc::new(|a0: crate::syntax::parser::Ps| entered(crate::syntax::parser::types::start_parse_type(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>>>), move |commas_10908: (Array<crate::syntax::Type>, crate::syntax::parser::Ps)| {
            let (types, q) = commas_10908;
            if &crate::syntax::parser::kind(&q) == &crate::syntax::lexer::TokKind::KGtGt {
                prism_rtl::Turn::Finished((types.clone(), crate::syntax::parser::adv(&q)))
            } else {
                prism_rtl::Turn::Finished((types.clone(), crate::syntax::parser::error_here(&q, &Text::lit("expected `>>` to close the type arguments"))))
            }
        })
    }
}

/// `Start ParseTypeArgs, x`: what the function value is when passed to `@Run`.
pub fn start_parse_type_args(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Type>, crate::syntax::parser::Ps)>> {
    Rc::new(ParseTypeArgs { p_ })
}

/// ```prism
/// ArgStartsHere: fn Ps -> Bool
/// ```
pub fn arg_starts_here(p_: &crate::syntax::parser::Ps) -> bool {
    let t = crate::syntax::parser::tk(p_);
    match &t.kind {
        crate::syntax::lexer::TokKind::KName(_) => true,
        crate::syntax::lexer::TokKind::KInt(_, _) => true,
        crate::syntax::lexer::TokKind::KFloat(_, _) => true,
        crate::syntax::lexer::TokKind::KDuration(_, _, _) => true,
        crate::syntax::lexer::TokKind::KChar(_, _) => true,
        crate::syntax::lexer::TokKind::KText(_, _) => true,
        crate::syntax::lexer::TokKind::KRegex(_, _) => true,
        crate::syntax::lexer::TokKind::KTemplate(_) => true,
        crate::syntax::lexer::TokKind::KFree(_) => true,
        crate::syntax::lexer::TokKind::KLensDot => true,
        crate::syntax::lexer::TokKind::KBackslash => true,
        crate::syntax::lexer::TokKind::KAbsent => true,
        crate::syntax::lexer::TokKind::KOpen(m11225_12_0, prefix) if (m11225_12_0 == &Text::lit("[")) => (*prefix || !t.touches) || crate::syntax::parser::at_double_open(p_, &Text::lit("[")),
        crate::syntax::lexer::TokKind::KOpen(_, _) => true,
        crate::syntax::lexer::TokKind::KOp(op, true) => (op == &Text::lit("+")) || (op == &Text::lit("-")),
        crate::syntax::lexer::TokKind::KDot(true) => !at_line_method(p_),
        crate::syntax::lexer::TokKind::KKw(w, _) => fold(&arg_words(), &false, &(|seen: &bool, x: &Text| *seen || (x == w))),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// let argWords
/// ```
pub fn arg_words() -> Array<Text> {
    Array::from(vec![Text::lit("unit"), Text::lit("nil"), Text::lit("key"), Text::lit("ix"), Text::lit("jx"), Text::lit("kx"), Text::lit("not"), Text::lit("any"), Text::lit("given"), Text::lit("update"), Text::lit("match"), Text::lit("rebuild"), Text::lit("widget"), Text::lit("output"), Text::lit("inline_text"), Text::lit("raw")])
}

/// ```prism
/// ParseCallArgs: unbounded fn Ps, Bool -> (([Arg], Ps))
/// ```
pub fn parse_call_args(p_: &crate::syntax::parser::Ps, commas: &bool) -> (Array<crate::syntax::Arg>, crate::syntax::parser::Ps) {
    if *commas && !p_.step_mode {
        crate::syntax::parser::commas(p_, &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_arg(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Arg, crate::syntax::parser::Ps)>>>))
    } else {
        parse_one_arg(p_)
    }
}

/// The step machine of `ParseCallArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseCallArgs: unbounded fn Ps, Bool -> (([Arg], Ps))
/// ```
pub struct ParseCallArgs {
    pub p_: crate::syntax::parser::Ps,
    pub commas: bool,
}

impl prism_rtl::Job<(Array<crate::syntax::Arg>, crate::syntax::parser::Ps)> for ParseCallArgs {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::Arg>, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let commas = &self.commas;
        if *commas && !p_.step_mode {
            prism_rtl::Turn::More(Rc::new(crate::syntax::parser::Commas { p0: p_.clone(), f_fn: Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_arg(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Arg, crate::syntax::parser::Ps)>>> }))
        } else {
            prism_rtl::Turn::More(Rc::new(ParseOneArg { p_: p_.clone() }))
        }
    }
}

/// `Start ParseCallArgs, x`: what the function value is when passed to `@Run`.
pub fn start_parse_call_args(p_: crate::syntax::parser::Ps, commas: bool) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Arg>, crate::syntax::parser::Ps)>> {
    Rc::new(ParseCallArgs { p_, commas })
}

/// ```prism
/// ParseOneArg: unbounded fn Ps -> (([Arg], Ps))
/// ```
pub fn parse_one_arg(p_: &crate::syntax::parser::Ps) -> (Array<crate::syntax::Arg>, crate::syntax::parser::Ps) {
    let (a, q) = parse_arg(p_);
    (Array::from(vec![a.clone()]), q.clone())
}

/// The step machine of `ParseOneArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseOneArg: unbounded fn Ps -> (([Arg], Ps))
/// ```
pub struct ParseOneArg {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(Array<crate::syntax::Arg>, crate::syntax::parser::Ps)> for ParseOneArg {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::Arg>, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let p_ = p_.clone();
        call_then(start_parse_arg(p_.clone()), move |parse_arg_12477: (crate::syntax::Arg, crate::syntax::parser::Ps)| {
            let (a, q) = parse_arg_12477;
            prism_rtl::Turn::Finished((Array::from(vec![a.clone()]), q.clone()))
        })
    }
}

/// `Start ParseOneArg, x`: what the function value is when passed to `@Run`.
pub fn start_parse_one_arg(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Arg>, crate::syntax::parser::Ps)>> {
    Rc::new(ParseOneArg { p_ })
}

/// ```prism
/// ParseArg: unbounded fn Ps -> ((Arg, Ps))
/// ```
pub fn parse_arg(p_: &crate::syntax::parser::Ps) -> (crate::syntax::Arg, crate::syntax::parser::Ps) {
    let (value, q) = parse_arg_expr(p_);
    (crate::syntax::Arg { name: None, value: value.clone(), span: value.span.clone() }, q.clone())
}

/// The step machine of `ParseArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseArg: unbounded fn Ps -> ((Arg, Ps))
/// ```
pub struct ParseArg {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Arg, crate::syntax::parser::Ps)> for ParseArg {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Arg, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let p_ = p_.clone();
        call_then(start_parse_arg_expr(p_.clone()), move |parse_arg_expr_12585: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
            let (value, q) = parse_arg_expr_12585;
            prism_rtl::Turn::Finished((crate::syntax::Arg { name: None, value: value.clone(), span: value.span.clone() }, q.clone()))
        })
    }
}

/// `Start ParseArg, x`: what the function value is when passed to `@Run`.
pub fn start_parse_arg(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Arg, crate::syntax::parser::Ps)>> {
    Rc::new(ParseArg { p_ })
}

/// ```prism
/// ParseParenArgs: unbounded fn Ps -> (([Arg], Bool, Ps))
/// ```
pub fn parse_paren_args(p0: &crate::syntax::parser::Ps) -> (Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps) {
    let p_ = crate::syntax::parser::adv(p0);
    if crate::syntax::parser::at_close(&p_, &Text::lit("(")) {
        (Array::new(), false, crate::syntax::parser::adv(&p_))
    } else {
        {
            let r = {
                let mut this: ArgsRead = ArgsRead { args: Array::new(), rest: false, p_: p_.clone(), going: true };
                while this.going && !this.p_.bad {
                    if &crate::syntax::parser::kind(&this.p_) == &crate::syntax::lexer::TokKind::KDotDot {
                        this.p_ = crate::syntax::parser::adv(&this.p_);
                        this.rest = true;
                    } else {
                        let start = crate::syntax::parser::here(&this.p_);
                        let (name_opt, p1) = parse_arg_name(&this.p_);
                        let (value, p2) = parse_arg_expr(&p1);
                        this.args = push(&this.args, &crate::syntax::Arg { name: name_opt.clone(), value: value.clone(), span: crate::syntax::parser::to(&start, &value.span) });
                        this.p_ = p2.clone();
                    }
                    if crate::syntax::parser::at_comma(&this.p_) {
                        this.p_ = crate::syntax::parser::adv(&this.p_);
                    } else {
                        this.p_ = crate::syntax::parser::expect_close(&this.p_, &Text::lit("("));
                        this.going = false;
                    }
                }
                this
            };
            (r.args.clone(), r.rest, r.p_.clone())
        }
    }
}

/// The step machine of `ParseParenArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseParenArgs: unbounded fn Ps -> (([Arg], Bool, Ps))
/// ```
pub struct ParseParenArgs {
    pub p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps)> for ParseParenArgs {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let p_ = crate::syntax::parser::adv(p0);
        if crate::syntax::parser::at_close(&p_, &Text::lit("(")) {
            prism_rtl::Turn::Finished((Array::new(), false, crate::syntax::parser::adv(&p_)))
        } else {
            {
                let mut this: ArgsRead = ArgsRead { args: Array::new(), rest: false, p_: p_.clone(), going: true };
                let p_ = p_.clone();
                call_then(loop_job((this,), {
                    let p_ = p_.clone();
                    move |(mut this,): (ArgsRead,)| if this.going && !this.p_.bad {
                        {
                            if &crate::syntax::parser::kind(&this.p_) == &crate::syntax::lexer::TokKind::KDotDot {
                                this.p_ = crate::syntax::parser::adv(&this.p_);
                                this.rest = true;
                            } else {
                                let start = crate::syntax::parser::here(&this.p_);
                                let (name_opt, p1) = parse_arg_name(&this.p_);
                                let (value, p2) = parse_arg_expr(&p1);
                                this.args = push(&this.args, &crate::syntax::Arg { name: name_opt.clone(), value: value.clone(), span: crate::syntax::parser::to(&start, &value.span) });
                                this.p_ = p2.clone();
                            }
                            if crate::syntax::parser::at_comma(&this.p_) {
                                this.p_ = crate::syntax::parser::adv(&this.p_);
                            } else {
                                this.p_ = crate::syntax::parser::expect_close(&this.p_, &Text::lit("("));
                                this.going = false;
                            }
                            Ok((this,))
                        }
                    } else {
                        Err((this,))
                    }
                }), move |(mut this,): (ArgsRead,)| {
                    let r = this;
                    prism_rtl::Turn::Finished((r.args.clone(), r.rest, r.p_.clone()))
                })
            }
        }
    }
}

/// `Start ParseParenArgs, x`: what the function value is when passed to `@Run`.
pub fn start_parse_paren_args(p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps)>> {
    Rc::new(ParseParenArgs { p0 })
}

/// ```prism
/// ParseArgName: fn Ps -> ((?Ident, Ps))
/// ```
pub fn parse_arg_name(p_: &crate::syntax::parser::Ps) -> (Option<crate::syntax::Ident>, crate::syntax::parser::Ps) {
    match crate::syntax::parser::kind(p_) {
        crate::syntax::lexer::TokKind::KName(n) if ((((&n.sigils == &Text::lit("")) && (&len(&n.path_) == &Nat::from(1u32))) && (&n.case == &crate::syntax::lexer::NameCase::CaseLower)) && crate::syntax::parser::at_op(&crate::syntax::parser::adv(p_), &Text::lit("="))) => (Some(crate::syntax::Ident { name: or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")), span: crate::syntax::parser::here(p_) }), crate::syntax::parser::adv(&crate::syntax::parser::adv(p_))),
        _ => (None, p_.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParsePrimary: unbounded fn Ps, Bool -> ((Expr, Bool, Ps))
/// ```
pub fn parse_primary(p_: &crate::syntax::parser::Ps, commas: &bool) -> (crate::syntax::Expr, bool, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p_);
    let tok = crate::syntax::parser::tk(p_);
    match &tok.kind {
        crate::syntax::lexer::TokKind::KName(n) => name_primary(p_, n, commas),
        crate::syntax::lexer::TokKind::KKw(w, sigils) => keyword_primary(p_, w, sigils, commas),
        crate::syntax::lexer::TokKind::KInt(_, _) => literal_primary(p_),
        crate::syntax::lexer::TokKind::KFloat(_, _) => literal_primary(p_),
        crate::syntax::lexer::TokKind::KDuration(_, _, _) => literal_primary(p_),
        crate::syntax::lexer::TokKind::KChar(_, _) => literal_primary(p_),
        crate::syntax::lexer::TokKind::KText(_, _) => literal_primary(p_),
        crate::syntax::lexer::TokKind::KRegex(_, _) => literal_primary(p_),
        crate::syntax::lexer::TokKind::KTemplate(t) => {
            let (tpl, q) = parse_template(&crate::syntax::parser::adv(p_), t, &tok.span);
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETemplate(tpl.clone())), span: tok.span.clone() }, false, q.clone())
        },
        crate::syntax::lexer::TokKind::KOpen(m14436_9_0, _) if (m14436_9_0 == &Text::lit("(")) => paren_primary(p_),
        crate::syntax::lexer::TokKind::KOpen(m14436_10_0, _) if (m14436_10_0 == &Text::lit("[")) => square_primary(p_),
        crate::syntax::lexer::TokKind::KOpen(_, _) => map_primary(p_),
        crate::syntax::lexer::TokKind::KDot(true) => {
            let p1 = crate::syntax::parser::adv(p_);
            match crate::syntax::parser::kind(&p1) {
                crate::syntax::lexer::TokKind::KName(n) if (((&n.sigils == &Text::lit("")) && (&len(&n.path_) == &Nat::from(1u32))) && (&n.case == &crate::syntax::lexer::NameCase::CaseLower)) => {
                    let t = crate::syntax::parser::here(&p1);
                    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETopicField(crate::syntax::Ident { name: or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")), span: t.clone() })), span: crate::syntax::parser::to(&start, &t) }, false, crate::syntax::parser::adv(&p1))
                },
                crate::syntax::lexer::TokKind::KName(n) if (&n.case == &crate::syntax::lexer::NameCase::CaseUpper) => (crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(&p1, &start, &Text::from(format!("a spaced `.{}` begins its own line, below the call it takes as its receiver (layout rule 9)", &crate::syntax::lexer::chars::join(&n.path_, &Text::lit(".")))))),
                _ => (crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(&p1, &start, &Text::lit("a prefix `.` takes a field name, applied to the topic `_`"))),
                _ => unreachable!("no arm matched"),
            }
        },
        crate::syntax::lexer::TokKind::KLensDot => lens_primary(p_),
        crate::syntax::lexer::TokKind::KFree(s) => if s == &Text::lit("!") {
            (crate::syntax::parser::decls::no_expr(), true, crate::syntax::parser::error_at(&crate::syntax::parser::adv(p_), &tok.span, &Text::lit("`!` is never free: no event fires a constant")))
        } else {
            if s == &Text::lit("&") {
                (crate::syntax::parser::decls::no_expr(), true, crate::syntax::parser::error_at(&crate::syntax::parser::adv(p_), &tok.span, &Text::lit("`&` is never free: no reference exists outside the value an `update` block names")))
            } else {
                {
                    let (operand, q) = parse_expr_ctx(&crate::syntax::parser::adv(p_), commas);
                    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EFreeSigil(s.clone(), Rc::new(operand.clone()))), span: crate::syntax::parser::to(&start, &operand.span) }, true, q.clone())
                }
            }
        },
        crate::syntax::lexer::TokKind::KBackslash => {
            let (e, q) = parse_lambda(p_);
            (e.clone(), true, q.clone())
        },
        crate::syntax::lexer::TokKind::KAbsent => {
            let q = crate::syntax::parser::out_of_scope(&crate::syntax::parser::adv(p_), &tok.span, &Text::lit("sparse tuples"), &Text::lit("an absent component `-` makes a sparse tuple, which is out of this compiler"));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EAbsent), span: tok.span.clone() }, false, q.clone())
        },
        crate::syntax::lexer::TokKind::KDotDot => (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ERest), span: tok.span.clone() }, false, crate::syntax::parser::adv(p_)),
        crate::syntax::lexer::TokKind::KTrait(_) => (crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, &tok.span, &Text::lit("no trait is a value: a `^Trait` stands in a type, a bound, `derive`, `trait` or `impl`"))),
        crate::syntax::lexer::TokKind::KFamily(path_) => (crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, &tok.span, &Text::from(format!("`{}.*` names every tag of a family: it stands in a pattern, an `emit` row or a `use`, not in an expression", &crate::syntax::lexer::chars::join(path_, &Text::lit(".")))))),
        crate::syntax::lexer::TokKind::KBar => (crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, &tok.span, &Text::lit("a bare `|` is not an operator: the merge is `<|`, and `|` separates the families of a row"))),
        _ => (crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_here(p_, &Text::lit("expected an expression"))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ParsePrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParsePrimary: unbounded fn Ps, Bool -> ((Expr, Bool, Ps))
/// ```
pub struct ParsePrimary {
    pub p_: crate::syntax::parser::Ps,
    pub commas: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> for ParsePrimary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let commas = &self.commas;
        let start = crate::syntax::parser::here(p_);
        let tok = crate::syntax::parser::tk(p_);
        match &tok.kind {
            crate::syntax::lexer::TokKind::KName(n) => prism_rtl::Turn::More(Rc::new(NamePrimary { p0: p_.clone(), n: n.clone(), commas: *commas })),
            crate::syntax::lexer::TokKind::KKw(w, sigils) => prism_rtl::Turn::More(Rc::new(KeywordPrimary { p_: p_.clone(), w: w.clone(), sigils: sigils.clone(), commas: *commas })),
            crate::syntax::lexer::TokKind::KInt(_, _) => prism_rtl::Turn::More(Rc::new(LiteralPrimary { p_: p_.clone() })),
            crate::syntax::lexer::TokKind::KFloat(_, _) => prism_rtl::Turn::More(Rc::new(LiteralPrimary { p_: p_.clone() })),
            crate::syntax::lexer::TokKind::KDuration(_, _, _) => prism_rtl::Turn::More(Rc::new(LiteralPrimary { p_: p_.clone() })),
            crate::syntax::lexer::TokKind::KChar(_, _) => prism_rtl::Turn::More(Rc::new(LiteralPrimary { p_: p_.clone() })),
            crate::syntax::lexer::TokKind::KText(_, _) => prism_rtl::Turn::More(Rc::new(LiteralPrimary { p_: p_.clone() })),
            crate::syntax::lexer::TokKind::KRegex(_, _) => prism_rtl::Turn::More(Rc::new(LiteralPrimary { p_: p_.clone() })),
            crate::syntax::lexer::TokKind::KTemplate(t) => {
                let p_ = p_.clone();
                let t = t.clone();
                call_then(start_parse_template(crate::syntax::parser::adv(&p_), t.clone(), tok.span.clone()), move |parse_template_14898: (crate::syntax::Template, crate::syntax::parser::Ps)| {
                    let (tpl, q) = parse_template_14898;
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETemplate(tpl.clone())), span: tok.span.clone() }, false, q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KOpen(m14436_9_0, _) if (m14436_9_0 == &Text::lit("(")) => prism_rtl::Turn::More(Rc::new(ParenPrimary { p_: p_.clone() })),
            crate::syntax::lexer::TokKind::KOpen(m14436_10_0, _) if (m14436_10_0 == &Text::lit("[")) => prism_rtl::Turn::More(Rc::new(SquarePrimary { p_: p_.clone() })),
            crate::syntax::lexer::TokKind::KOpen(_, _) => prism_rtl::Turn::More(Rc::new(MapPrimary { p_: p_.clone() })),
            crate::syntax::lexer::TokKind::KDot(true) => {
                let p1 = crate::syntax::parser::adv(p_);
                match crate::syntax::parser::kind(&p1) {
                    crate::syntax::lexer::TokKind::KName(n) if (((&n.sigils == &Text::lit("")) && (&len(&n.path_) == &Nat::from(1u32))) && (&n.case == &crate::syntax::lexer::NameCase::CaseLower)) => {
                        let t = crate::syntax::parser::here(&p1);
                        prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETopicField(crate::syntax::Ident { name: or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")), span: t.clone() })), span: crate::syntax::parser::to(&start, &t) }, false, crate::syntax::parser::adv(&p1)))
                    },
                    crate::syntax::lexer::TokKind::KName(n) if (&n.case == &crate::syntax::lexer::NameCase::CaseUpper) => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(&p1, &start, &Text::from(format!("a spaced `.{}` begins its own line, below the call it takes as its receiver (layout rule 9)", &crate::syntax::lexer::chars::join(&n.path_, &Text::lit("."))))))),
                    _ => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(&p1, &start, &Text::lit("a prefix `.` takes a field name, applied to the topic `_`")))),
                    _ => unreachable!("no arm matched"),
                }
            },
            crate::syntax::lexer::TokKind::KLensDot => prism_rtl::Turn::More(Rc::new(LensPrimary { p0: p_.clone() })),
            crate::syntax::lexer::TokKind::KFree(s) => if s == &Text::lit("!") {
                prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), true, crate::syntax::parser::error_at(&crate::syntax::parser::adv(p_), &tok.span, &Text::lit("`!` is never free: no event fires a constant"))))
            } else {
                if s == &Text::lit("&") {
                    prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), true, crate::syntax::parser::error_at(&crate::syntax::parser::adv(p_), &tok.span, &Text::lit("`&` is never free: no reference exists outside the value an `update` block names"))))
                } else {
                    {
                        let commas = *commas;
                        let p_ = p_.clone();
                        let s = s.clone();
                        call_then(start_parse_expr_ctx(crate::syntax::parser::adv(&p_), commas), move |parse_expr_ctx_16414: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                            let (operand, q) = parse_expr_ctx_16414;
                            prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EFreeSigil(s.clone(), Rc::new(operand.clone()))), span: crate::syntax::parser::to(&start, &operand.span) }, true, q.clone()))
                        })
                    }
                }
            },
            crate::syntax::lexer::TokKind::KBackslash => {
                let p_ = p_.clone();
                call_then(start_parse_lambda(p_.clone()), move |parse_lambda_16585: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (e, q) = parse_lambda_16585;
                    prism_rtl::Turn::Finished((e.clone(), true, q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KAbsent => {
                let q = crate::syntax::parser::out_of_scope(&crate::syntax::parser::adv(p_), &tok.span, &Text::lit("sparse tuples"), &Text::lit("an absent component `-` makes a sparse tuple, which is out of this compiler"));
                prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EAbsent), span: tok.span.clone() }, false, q.clone()))
            },
            crate::syntax::lexer::TokKind::KDotDot => prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ERest), span: tok.span.clone() }, false, crate::syntax::parser::adv(p_))),
            crate::syntax::lexer::TokKind::KTrait(_) => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, &tok.span, &Text::lit("no trait is a value: a `^Trait` stands in a type, a bound, `derive`, `trait` or `impl`")))),
            crate::syntax::lexer::TokKind::KFamily(path_) => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, &tok.span, &Text::from(format!("`{}.*` names every tag of a family: it stands in a pattern, an `emit` row or a `use`, not in an expression", &crate::syntax::lexer::chars::join(path_, &Text::lit("."))))))),
            crate::syntax::lexer::TokKind::KBar => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, &tok.span, &Text::lit("a bare `|` is not an operator: the merge is `<|`, and `|` separates the families of a row")))),
            _ => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_here(p_, &Text::lit("expected an expression")))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ParsePrimary, x`: what the function value is when passed to `@Run`.
pub fn start_parse_primary(p_: crate::syntax::parser::Ps, commas: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)>> {
    Rc::new(ParsePrimary { p_, commas })
}

/// ```prism
/// LiteralPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub fn literal_primary(p_: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, bool, crate::syntax::parser::Ps) {
    let (lit, q) = parse_literal(p_);
    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELit(lit.clone())), span: lit.span.clone() }, false, q.clone())
}

/// The step machine of `LiteralPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LiteralPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub struct LiteralPrimary {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> for LiteralPrimary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let p_ = p_.clone();
        call_then(start_parse_literal(p_.clone()), move |parse_literal_17581: (crate::syntax::Literal, crate::syntax::parser::Ps)| {
            let (lit, q) = parse_literal_17581;
            prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELit(lit.clone())), span: lit.span.clone() }, false, q.clone()))
        })
    }
}

/// `Start LiteralPrimary, x`: what the function value is when passed to `@Run`.
pub fn start_literal_primary(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)>> {
    Rc::new(LiteralPrimary { p_ })
}

/// ```prism
/// NamePrimary: unbounded fn Ps, NameTok, Bool -> ((Expr, Bool, Ps))
/// ```
pub fn name_primary(p0: &crate::syntax::parser::Ps, n: &crate::syntax::lexer::NameTok, commas: &bool) -> (crate::syntax::Expr, bool, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p0);
    let name = crate::syntax::SName { sigils: n.sigils.clone(), path_: n.path_.clone(), span: start.clone() };
    let p1 = crate::syntax::parser::check_name_scope(&crate::syntax::parser::adv(p0), &name);
    let plain = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(name.clone())), span: start.clone() };
    let (e, p_) = if &crate::syntax::parser::kind(&p1) == &crate::syntax::lexer::TokKind::KLtLt {
        type_args_on(&plain, &p1, &start)
    } else {
        (plain.clone(), p1.clone())
    };
    if crate::syntax::parser::is_callee(&name) {
        if crate::syntax::parser::at_single_open(&p_, &Text::lit("(")) && crate::syntax::parser::tk(&p_).touches {
            {
                let (args, rest, q) = parse_paren_args(&p_);
                (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECall(Rc::new(e.clone()), args.clone(), true, rest)), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, false, q.clone())
            }
        } else {
            if crate::syntax::parser::at_kw(&p_, &Text::lit("monad")) {
                {
                    let kw = crate::syntax::parser::here(&p_);
                    let (body, q) = crate::syntax::parser::blocks::parse_block_after_colon(&crate::syntax::parser::out_of_scope(&crate::syntax::parser::adv(&p_), &kw, &Text::lit("`T monad:` blocks and `^Monad`"), &Text::lit("monad blocks are out of this compiler")));
                    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMonad(Rc::new(e.clone()), body.clone())), span: crate::syntax::parser::to(&start, &body.span) }, true, q.clone())
                }
            } else {
                if arg_starts_here(&p_) {
                    {
                        let (args, q) = parse_call_args(&p_, commas);
                        (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECall(Rc::new(e.clone()), args.clone(), false, false)), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, true, q.clone())
                    }
                } else {
                    (e.clone(), false, p_.clone())
                }
            }
        }
    } else {
        if (crate::syntax::parser::at_single_open(&p_, &Text::lit("(")) && crate::syntax::parser::tk(&p_).touches) && !crate::syntax::parser::is_topic(&name) {
            (e.clone(), false, crate::syntax::parser::error_at(&p_, &crate::syntax::parser::here(&p_), &Text::from(format!("`{}` is a value and is not applied: a function\'s name is uppercase (case is a mark)", &crate::syntax::parser::name_text(&name)))))
        } else {
            (e.clone(), false, p_.clone())
        }
    }
}

/// The step machine of `NamePrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamePrimary: unbounded fn Ps, NameTok, Bool -> ((Expr, Bool, Ps))
/// ```
pub struct NamePrimary {
    pub p0: crate::syntax::parser::Ps,
    pub n: crate::syntax::lexer::NameTok,
    pub commas: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> for NamePrimary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let n = &self.n;
        let commas = &self.commas;
        let start = crate::syntax::parser::here(p0);
        let name = crate::syntax::SName { sigils: n.sigils.clone(), path_: n.path_.clone(), span: start.clone() };
        let p1 = crate::syntax::parser::check_name_scope(&crate::syntax::parser::adv(p0), &name);
        let plain = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(name.clone())), span: start.clone() };
        let (e, p_) = if &crate::syntax::parser::kind(&p1) == &crate::syntax::lexer::TokKind::KLtLt {
            type_args_on(&plain, &p1, &start)
        } else {
            (plain.clone(), p1.clone())
        };
        if crate::syntax::parser::is_callee(&name) {
            if crate::syntax::parser::at_single_open(&p_, &Text::lit("(")) && crate::syntax::parser::tk(&p_).touches {
                call_then(start_parse_paren_args(p_.clone()), move |parse_paren_args_18204: (Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps)| {
                    let (args, rest, q) = parse_paren_args_18204;
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECall(Rc::new(e.clone()), args.clone(), true, rest)), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, false, q.clone()))
                })
            } else {
                if crate::syntax::parser::at_kw(&p_, &Text::lit("monad")) {
                    {
                        let kw = crate::syntax::parser::here(&p_);
                        call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(crate::syntax::parser::out_of_scope(&crate::syntax::parser::adv(&p_), &kw, &Text::lit("`T monad:` blocks and `^Monad`"), &Text::lit("monad blocks are out of this compiler"))), move |parse_block_after_colon_18455: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                            let (body, q) = parse_block_after_colon_18455;
                            prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMonad(Rc::new(e.clone()), body.clone())), span: crate::syntax::parser::to(&start, &body.span) }, true, q.clone()))
                        })
                    }
                } else {
                    if arg_starts_here(&p_) {
                        {
                            let commas = *commas;
                            call_then(start_parse_call_args(p_.clone(), commas), move |parse_call_args_18721: (Array<crate::syntax::Arg>, crate::syntax::parser::Ps)| {
                                let (args, q) = parse_call_args_18721;
                                prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECall(Rc::new(e.clone()), args.clone(), false, false)), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, true, q.clone()))
                            })
                        }
                    } else {
                        prism_rtl::Turn::Finished((e.clone(), false, p_.clone()))
                    }
                }
            }
        } else {
            if (crate::syntax::parser::at_single_open(&p_, &Text::lit("(")) && crate::syntax::parser::tk(&p_).touches) && !crate::syntax::parser::is_topic(&name) {
                prism_rtl::Turn::Finished((e.clone(), false, crate::syntax::parser::error_at(&p_, &crate::syntax::parser::here(&p_), &Text::from(format!("`{}` is a value and is not applied: a function\'s name is uppercase (case is a mark)", &crate::syntax::parser::name_text(&name))))))
            } else {
                prism_rtl::Turn::Finished((e.clone(), false, p_.clone()))
            }
        }
    }
}

/// `Start NamePrimary, x`: what the function value is when passed to `@Run`.
pub fn start_name_primary(p0: crate::syntax::parser::Ps, n: crate::syntax::lexer::NameTok, commas: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)>> {
    Rc::new(NamePrimary { p0, n, commas })
}

/// ```prism
/// TypeArgsOn: unbounded fn Expr, Ps, Range -> ((Expr, Ps))
/// ```
pub fn type_args_on(e: &crate::syntax::Expr, p_: &crate::syntax::parser::Ps, start: &crate::syntax::Range) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let (types, q) = parse_type_args(p_);
    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETypeArgs(Rc::new(e.clone()), types.clone())), span: crate::syntax::parser::to(start, &crate::syntax::parser::prev(&q)) }, q.clone())
}

/// The step machine of `TypeArgsOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeArgsOn: unbounded fn Expr, Ps, Range -> ((Expr, Ps))
/// ```
pub struct TypeArgsOn {
    pub e: crate::syntax::Expr,
    pub p_: crate::syntax::parser::Ps,
    pub start: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for TypeArgsOn {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let e = &self.e;
        let p_ = &self.p_;
        let start = &self.start;
        let e = e.clone();
        let p_ = p_.clone();
        let start = start.clone();
        call_then(start_parse_type_args(p_.clone()), move |parse_type_args_19224: (Array<crate::syntax::Type>, crate::syntax::parser::Ps)| {
            let (types, q) = parse_type_args_19224;
            prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETypeArgs(Rc::new(e.clone()), types.clone())), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone()))
        })
    }
}

/// `Start TypeArgsOn, x`: what the function value is when passed to `@Run`.
pub fn start_type_args_on(e: crate::syntax::Expr, p_: crate::syntax::parser::Ps, start: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(TypeArgsOn { e, p_, start })
}

/// ```prism
/// ParenPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub fn paren_primary(p_: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, bool, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p_);
    if crate::syntax::parser::at_double_open(p_, &Text::lit("(")) {
        {
            let (elems, p1) = crate::syntax::parser::commas(&crate::syntax::parser::open_double(p_), &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_arg_expr(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>));
            let p2 = crate::syntax::parser::close_double(&p1, &Text::lit("("));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETuple(elems.clone())), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p2)) }, false, p2.clone())
        }
    } else {
        {
            let (inner, p1) = crate::syntax::parser::bracketed(&crate::syntax::parser::adv(p_), &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_rhs_expr(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>));
            if crate::syntax::parser::at_comma(&p1) {
                (crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(&p1, &crate::syntax::parser::here(&p1), &Text::lit("a group holds one expression: a comma here needs a call at the group\'s head, or `((` `))` for a tuple")))
            } else {
                {
                    let p2 = crate::syntax::parser::expect_close(&p1, &Text::lit("("));
                    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EGroup(Rc::new(inner.clone()))), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p2)) }, false, p2.clone())
                }
            }
        }
    }
}

/// The step machine of `ParenPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParenPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub struct ParenPrimary {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> for ParenPrimary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let start = crate::syntax::parser::here(p_);
        if crate::syntax::parser::at_double_open(p_, &Text::lit("(")) {
            {
                let p_ = p_.clone();
                call_then(crate::syntax::parser::start_commas(crate::syntax::parser::open_double(&p_), Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_arg_expr(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>), move |commas_19554: (Array<crate::syntax::Expr>, crate::syntax::parser::Ps)| {
                    let (elems, p1) = commas_19554;
                    let p2 = crate::syntax::parser::close_double(&p1, &Text::lit("("));
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETuple(elems.clone())), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p2)) }, false, p2.clone()))
                })
            }
        } else {
            {
                let p_ = p_.clone();
                call_then(crate::syntax::parser::start_bracketed(crate::syntax::parser::adv(&p_), Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_rhs_expr(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>), move |bracketed_19818: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (inner, p1) = bracketed_19818;
                    if crate::syntax::parser::at_comma(&p1) {
                        prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(&p1, &crate::syntax::parser::here(&p1), &Text::lit("a group holds one expression: a comma here needs a call at the group\'s head, or `((` `))` for a tuple"))))
                    } else {
                        {
                            let p2 = crate::syntax::parser::expect_close(&p1, &Text::lit("("));
                            prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EGroup(Rc::new(inner.clone()))), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p2)) }, false, p2.clone()))
                        }
                    }
                })
            }
        }
    }
}

/// `Start ParenPrimary, x`: what the function value is when passed to `@Run`.
pub fn start_paren_primary(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)>> {
    Rc::new(ParenPrimary { p_ })
}

/// ```prism
/// SquarePrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub fn square_primary(p_: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, bool, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p_);
    if crate::syntax::parser::at_double_open(p_, &Text::lit("[")) {
        {
            let p1 = crate::syntax::parser::open_double(p_);
            let (elems, p2) = if crate::syntax::parser::at_close(&p1, &Text::lit("[")) {
                (Array::new(), p1.clone())
            } else {
                crate::syntax::parser::commas(&p1, &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_arg_expr(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>))
            };
            let p3 = crate::syntax::parser::close_double(&p2, &Text::lit("["));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EArray(elems.clone())), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p3)) }, false, p3.clone())
        }
    } else {
        {
            let (index_, p1) = crate::syntax::parser::bracketed(&crate::syntax::parser::adv(p_), &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_expr(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>));
            let p2 = crate::syntax::parser::expect_close(&p1, &Text::lit("["));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETopicIndex(Rc::new(index_.clone()))), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p2)) }, false, p2.clone())
        }
    }
}

/// The step machine of `SquarePrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SquarePrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub struct SquarePrimary {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> for SquarePrimary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let start = crate::syntax::parser::here(p_);
        if crate::syntax::parser::at_double_open(p_, &Text::lit("[")) {
            {
                let p1 = crate::syntax::parser::open_double(p_);
                let (elems, p2) = if crate::syntax::parser::at_close(&p1, &Text::lit("[")) {
                    (Array::new(), p1.clone())
                } else {
                    crate::syntax::parser::commas(&p1, &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_arg_expr(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>))
                };
                let p3 = crate::syntax::parser::close_double(&p2, &Text::lit("["));
                prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EArray(elems.clone())), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p3)) }, false, p3.clone()))
            }
        } else {
            {
                let p_ = p_.clone();
                call_then(crate::syntax::parser::start_bracketed(crate::syntax::parser::adv(&p_), Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_expr(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>), move |bracketed_20642: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (index_, p1) = bracketed_20642;
                    let p2 = crate::syntax::parser::expect_close(&p1, &Text::lit("["));
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETopicIndex(Rc::new(index_.clone()))), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p2)) }, false, p2.clone()))
                })
            }
        }
    }
}

/// `Start SquarePrimary, x`: what the function value is when passed to `@Run`.
pub fn start_square_primary(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)>> {
    Rc::new(SquarePrimary { p_ })
}

/// ```prism
/// MapPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub fn map_primary(p_: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, bool, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p_);
    let p1 = crate::syntax::parser::adv(p_);
    let (entries, p2) = if crate::syntax::parser::at_close(&p1, &Text::lit("{")) {
        (Array::new(), p1.clone())
    } else {
        crate::syntax::parser::commas(&p1, &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_map_entry(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<((crate::syntax::Expr, crate::syntax::Expr), crate::syntax::parser::Ps)>>>))
    };
    let p3 = crate::syntax::parser::expect_close(&p2, &Text::lit("{"));
    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMap(entries.clone())), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p3)) }, false, p3.clone())
}

/// The step machine of `MapPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MapPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub struct MapPrimary {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> for MapPrimary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let start = crate::syntax::parser::here(p_);
        let p1 = crate::syntax::parser::adv(p_);
        let (entries, p2) = if crate::syntax::parser::at_close(&p1, &Text::lit("{")) {
            (Array::new(), p1.clone())
        } else {
            crate::syntax::parser::commas(&p1, &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_map_entry(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<((crate::syntax::Expr, crate::syntax::Expr), crate::syntax::parser::Ps)>>>))
        };
        let p3 = crate::syntax::parser::expect_close(&p2, &Text::lit("{"));
        prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMap(entries.clone())), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p3)) }, false, p3.clone()))
    }
}

/// `Start MapPrimary, x`: what the function value is when passed to `@Run`.
pub fn start_map_primary(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)>> {
    Rc::new(MapPrimary { p_ })
}

/// ```prism
/// ParseMapEntry: unbounded fn Ps -> ((((Expr, Expr)), Ps))
/// ```
pub fn parse_map_entry(p_: &crate::syntax::parser::Ps) -> ((crate::syntax::Expr, crate::syntax::Expr), crate::syntax::parser::Ps) {
    let (k, p1) = parse_arg_expr(p_);
    let (v_, p2) = parse_arg_expr(&crate::syntax::parser::expect_colon(&p1));
    ((k.clone(), v_.clone()), p2.clone())
}

/// The step machine of `ParseMapEntry`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseMapEntry: unbounded fn Ps -> ((((Expr, Expr)), Ps))
/// ```
pub struct ParseMapEntry {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<((crate::syntax::Expr, crate::syntax::Expr), crate::syntax::parser::Ps)> for ParseMapEntry {
    fn cycle(&self) -> prism_rtl::Turn<((crate::syntax::Expr, crate::syntax::Expr), crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let p_ = p_.clone();
        call_then(start_parse_arg_expr(p_.clone()), move |parse_arg_expr_21225: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
            let (k, p1) = parse_arg_expr_21225;
            call_then(start_parse_arg_expr(crate::syntax::parser::expect_colon(&p1)), move |parse_arg_expr_21260: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                let (v_, p2) = parse_arg_expr_21260;
                prism_rtl::Turn::Finished(((k.clone(), v_.clone()), p2.clone()))
            })
        })
    }
}

/// `Start ParseMapEntry, x`: what the function value is when passed to `@Run`.
pub fn start_parse_map_entry(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<((crate::syntax::Expr, crate::syntax::Expr), crate::syntax::parser::Ps)>> {
    Rc::new(ParseMapEntry { p_ })
}

/// ```prism
/// LensPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub fn lens_primary(p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, bool, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p0);
    let r = {
        let mut this: (Array<crate::syntax::Ident>, crate::syntax::parser::Ps) = (Array::new(), crate::syntax::parser::adv(p0));
        let mut path_: Array<crate::syntax::Ident> = Array::new();
        let mut p_: crate::syntax::parser::Ps = crate::syntax::parser::adv(p0);
        let mut going: bool = true;
        while going && !p_.bad {
            match &crate::syntax::parser::kind(&p_) {
                crate::syntax::lexer::TokKind::KName(n) if (((&n.sigils == &Text::lit("")) && (&n.case == &crate::syntax::lexer::NameCase::CaseLower)) && (&len(&n.path_) == &Nat::from(1u32))) => {
                    path_ = push(&path_, &crate::syntax::Ident { name: or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")), span: crate::syntax::parser::here(&p_) });
                    p_ = crate::syntax::parser::adv(&p_);
                    if &crate::syntax::parser::kind(&p_) == &crate::syntax::lexer::TokKind::KDot(false) {
                        p_ = crate::syntax::parser::adv(&p_);
                    } else {
                        going = false;
                    }
                    ()
                },
                _ => {
                    p_ = crate::syntax::parser::error_here(&p_, &Text::lit("expected a field name in a lens path"));
                    ()
                },
                _ => unreachable!("no arm matched"),
            };
        }
        this = (path_.clone(), p_.clone());
        this
    };
    let (path_, q) = r.clone();
    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELens(path_.clone())), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, false, q.clone())
}

/// The step machine of `LensPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LensPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub struct LensPrimary {
    pub p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> for LensPrimary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let start = crate::syntax::parser::here(p0);
        let mut this: (Array<crate::syntax::Ident>, crate::syntax::parser::Ps) = (Array::new(), crate::syntax::parser::adv(p0));
        let mut path_: Array<crate::syntax::Ident> = Array::new();
        let mut p_: crate::syntax::parser::Ps = crate::syntax::parser::adv(p0);
        let mut going: bool = true;
        let start = start.clone();
        call_then(loop_job((this, going, p_, path_), move |(mut this, mut going, mut p_, mut path_): ((Array<crate::syntax::Ident>, crate::syntax::parser::Ps), bool, crate::syntax::parser::Ps, Array<crate::syntax::Ident>)| if going && !p_.bad {
            {
                match &crate::syntax::parser::kind(&p_) {
                    crate::syntax::lexer::TokKind::KName(n) if (((&n.sigils == &Text::lit("")) && (&n.case == &crate::syntax::lexer::NameCase::CaseLower)) && (&len(&n.path_) == &Nat::from(1u32))) => {
                        path_ = push(&path_, &crate::syntax::Ident { name: or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")), span: crate::syntax::parser::here(&p_) });
                        p_ = crate::syntax::parser::adv(&p_);
                        if &crate::syntax::parser::kind(&p_) == &crate::syntax::lexer::TokKind::KDot(false) {
                            p_ = crate::syntax::parser::adv(&p_);
                        } else {
                            going = false;
                        }
                        ()
                    },
                    _ => {
                        p_ = crate::syntax::parser::error_here(&p_, &Text::lit("expected a field name in a lens path"));
                        ()
                    },
                    _ => unreachable!("no arm matched"),
                };
                Ok((this, going, p_, path_))
            }
        } else {
            Err((this, going, p_, path_))
        }), move |(mut this, mut going, mut p_, mut path_): ((Array<crate::syntax::Ident>, crate::syntax::parser::Ps), bool, crate::syntax::parser::Ps, Array<crate::syntax::Ident>)| {
            this = (path_.clone(), p_.clone());
            let r = this;
            let (path_, q) = r.clone();
            prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELens(path_.clone())), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, false, q.clone()))
        })
    }
}

/// `Start LensPrimary, x`: what the function value is when passed to `@Run`.
pub fn start_lens_primary(p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)>> {
    Rc::new(LensPrimary { p0 })
}

/// ```prism
/// KeywordPrimary: unbounded fn Ps, Text, Text, Bool -> ((Expr, Bool, Ps))
/// ```
pub fn keyword_primary(p_: &crate::syntax::parser::Ps, w: &Text, sigils: &Text, commas: &bool) -> (crate::syntax::Expr, bool, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p_);
    match w {
        m22385_0 if (m22385_0 == &Text::lit("unit")) => (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EUnit(sigils.clone())), span: start.clone() }, false, crate::syntax::parser::adv(p_)),
        m22385_1 if (m22385_1 == &Text::lit("nil")) => (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ENil(sigils.clone())), span: start.clone() }, false, crate::syntax::parser::adv(p_)),
        _ if crate::syntax::lexer::is_bound_word(w) => (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EBound(w.clone())), span: start.clone() }, false, crate::syntax::parser::adv(p_)),
        m22385_3 if (m22385_3 == &Text::lit("if")) => took(&parse_if(p_)),
        m22385_4 if (m22385_4 == &Text::lit("match")) => took(&parse_match(p_)),
        m22385_5 if (m22385_5 == &Text::lit("rebuild")) => {
            let (scrutinee, p1) = parse_expr(&crate::syntax::parser::adv(p_));
            let (body, p2) = crate::syntax::parser::blocks::parse_block_after_colon(&p1);
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ERebuild(Rc::new(scrutinee.clone()), body.clone())), span: crate::syntax::parser::to(&start, &body.span) }, true, p2.clone())
        },
        m22385_6 if (m22385_6 == &Text::lit("for")) => took(&parse_for(p_)),
        m22385_7 if (m22385_7 == &Text::lit("given")) => {
            let (body, q) = crate::syntax::parser::blocks::parse_block_after_colon(&crate::syntax::parser::adv(p_));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EGiven(body.clone())), span: crate::syntax::parser::to(&start, &body.span) }, true, q.clone())
        },
        m22385_8 if (m22385_8 == &Text::lit("update")) => {
            let (target, p1) = parse_expr(&crate::syntax::parser::adv(p_));
            let (body, p2) = crate::syntax::parser::blocks::parse_block_after_colon(&p1);
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EUpdate(Rc::new(target.clone()), body.clone())), span: crate::syntax::parser::to(&start, &body.span) }, true, p2.clone())
        },
        m22385_9 if (m22385_9 == &Text::lit("widget")) => {
            let (body, q) = crate::syntax::parser::blocks::parse_block_after_colon(&crate::syntax::parser::adv(p_));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EWidgetBlock(body.clone())), span: crate::syntax::parser::to(&start, &body.span) }, true, q.clone())
        },
        m22385_10 if (m22385_10 == &Text::lit("any")) => {
            let (operand, q) = parse_expr_ctx(&crate::syntax::parser::adv(p_), commas);
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EAny(Rc::new(operand.clone()))), span: crate::syntax::parser::to(&start, &operand.span) }, true, q.clone())
        },
        m22385_11 if (m22385_11 == &Text::lit("not")) => {
            let (e, q) = parse_binary(p_, &Nat::from(8u32), commas);
            (e.clone(), true, q.clone())
        },
        _ if (((w == &Text::lit("output")) || (w == &Text::lit("inline_text"))) || (w == &Text::lit("raw"))) => {
            let p1 = crate::syntax::parser::adv(p_);
            match crate::syntax::parser::kind(&p1) {
                crate::syntax::lexer::TokKind::KTemplate(t) => {
                    let tspan = crate::syntax::parser::here(&p1);
                    let (tpl, q) = parse_template(&crate::syntax::parser::adv(&p1), &t, &tspan);
                    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETemplate(tpl.clone())), span: crate::syntax::parser::to(&start, &tspan) }, false, q.clone())
                },
                _ => (crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::fail(&p1)),
            }
        },
        m22385_13 if (m22385_13 == &Text::lit("then")) => (crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, &start, &Text::lit("`then` belongs to a hold: `$x <- start then step`"))),
        m22385_14 if (m22385_14 == &Text::lit("else")) => (crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, &start, &Text::lit("`else` without its `if`"))),
        m22385_15 if (m22385_15 == &Text::lit("ignore")) => (crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, &start, &Text::lit("`ignore` stands only inside a pattern or as the left side of a bind"))),
        m22385_16 if (m22385_16 == &Text::lit("return")) => (crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, &start, &Text::lit("`return` ends a monad block, as its last statement"))),
        _ => (crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_here(p_, &Text::lit("expected an expression"))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `KeywordPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// KeywordPrimary: unbounded fn Ps, Text, Text, Bool -> ((Expr, Bool, Ps))
/// ```
pub struct KeywordPrimary {
    pub p_: crate::syntax::parser::Ps,
    pub w: Text,
    pub sigils: Text,
    pub commas: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> for KeywordPrimary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let w = &self.w;
        let sigils = &self.sigils;
        let commas = &self.commas;
        let start = crate::syntax::parser::here(p_);
        match w {
            m22385_0 if (m22385_0 == &Text::lit("unit")) => prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EUnit(sigils.clone())), span: start.clone() }, false, crate::syntax::parser::adv(p_))),
            m22385_1 if (m22385_1 == &Text::lit("nil")) => prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ENil(sigils.clone())), span: start.clone() }, false, crate::syntax::parser::adv(p_))),
            _ if crate::syntax::lexer::is_bound_word(w) => prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EBound(w.clone())), span: start.clone() }, false, crate::syntax::parser::adv(p_))),
            m22385_3 if (m22385_3 == &Text::lit("if")) => {
                let p_ = p_.clone();
                call_then(start_parse_if(p_.clone()), move |parse_if_22647: (crate::syntax::Expr, crate::syntax::parser::Ps)| prism_rtl::Turn::Finished(took(&parse_if_22647)))
            },
            m22385_4 if (m22385_4 == &Text::lit("match")) => {
                let p_ = p_.clone();
                call_then(start_parse_match(p_.clone()), move |parse_match_22681: (crate::syntax::Expr, crate::syntax::parser::Ps)| prism_rtl::Turn::Finished(took(&parse_match_22681)))
            },
            m22385_5 if (m22385_5 == &Text::lit("rebuild")) => {
                let p_ = p_.clone();
                call_then(start_parse_expr(crate::syntax::parser::adv(&p_)), move |parse_expr_22750: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (scrutinee, p1) = parse_expr_22750;
                    call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(p1.clone()), move |parse_block_after_colon_22799: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                        let (body, p2) = parse_block_after_colon_22799;
                        prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ERebuild(Rc::new(scrutinee.clone()), body.clone())), span: crate::syntax::parser::to(&start, &body.span) }, true, p2.clone()))
                    })
                })
            },
            m22385_6 if (m22385_6 == &Text::lit("for")) => {
                let p_ = p_.clone();
                call_then(start_parse_for(p_.clone()), move |parse_for_22936: (crate::syntax::Expr, crate::syntax::parser::Ps)| prism_rtl::Turn::Finished(took(&parse_for_22936)))
            },
            m22385_7 if (m22385_7 == &Text::lit("given")) => {
                let p_ = p_.clone();
                call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(crate::syntax::parser::adv(&p_)), move |parse_block_after_colon_22995: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                    let (body, q) = parse_block_after_colon_22995;
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EGiven(body.clone())), span: crate::syntax::parser::to(&start, &body.span) }, true, q.clone()))
                })
            },
            m22385_8 if (m22385_8 == &Text::lit("update")) => {
                let p_ = p_.clone();
                call_then(start_parse_expr(crate::syntax::parser::adv(&p_)), move |parse_expr_23153: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (target, p1) = parse_expr_23153;
                    call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(p1.clone()), move |parse_block_after_colon_23202: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                        let (body, p2) = parse_block_after_colon_23202;
                        prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EUpdate(Rc::new(target.clone()), body.clone())), span: crate::syntax::parser::to(&start, &body.span) }, true, p2.clone()))
                    })
                })
            },
            m22385_9 if (m22385_9 == &Text::lit("widget")) => {
                let p_ = p_.clone();
                call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(crate::syntax::parser::adv(&p_)), move |parse_block_after_colon_23415: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                    let (body, q) = parse_block_after_colon_23415;
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EWidgetBlock(body.clone())), span: crate::syntax::parser::to(&start, &body.span) }, true, q.clone()))
                })
            },
            m22385_10 if (m22385_10 == &Text::lit("any")) => {
                let commas = *commas;
                let p_ = p_.clone();
                call_then(start_parse_expr_ctx(crate::syntax::parser::adv(&p_), commas), move |parse_expr_ctx_23576: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (operand, q) = parse_expr_ctx_23576;
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EAny(Rc::new(operand.clone()))), span: crate::syntax::parser::to(&start, &operand.span) }, true, q.clone()))
                })
            },
            m22385_11 if (m22385_11 == &Text::lit("not")) => {
                let commas = *commas;
                let p_ = p_.clone();
                call_then(start_parse_binary(p_.clone(), Nat::from(8u32), commas), move |parse_binary_23729: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (e, q) = parse_binary_23729;
                    prism_rtl::Turn::Finished((e.clone(), true, q.clone()))
                })
            },
            _ if (((w == &Text::lit("output")) || (w == &Text::lit("inline_text"))) || (w == &Text::lit("raw"))) => {
                let p1 = crate::syntax::parser::adv(p_);
                match crate::syntax::parser::kind(&p1) {
                    crate::syntax::lexer::TokKind::KTemplate(t) => {
                        let tspan = crate::syntax::parser::here(&p1);
                        call_then(start_parse_template(crate::syntax::parser::adv(&p1), t.clone(), tspan.clone()), move |parse_template_24089: (crate::syntax::Template, crate::syntax::parser::Ps)| {
                            let (tpl, q) = parse_template_24089;
                            prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETemplate(tpl.clone())), span: crate::syntax::parser::to(&start, &tspan) }, false, q.clone()))
                        })
                    },
                    _ => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::fail(&p1))),
                }
            },
            m22385_13 if (m22385_13 == &Text::lit("then")) => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, &start, &Text::lit("`then` belongs to a hold: `$x <- start then step`")))),
            m22385_14 if (m22385_14 == &Text::lit("else")) => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, &start, &Text::lit("`else` without its `if`")))),
            m22385_15 if (m22385_15 == &Text::lit("ignore")) => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, &start, &Text::lit("`ignore` stands only inside a pattern or as the left side of a bind")))),
            m22385_16 if (m22385_16 == &Text::lit("return")) => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_, &start, &Text::lit("`return` ends a monad block, as its last statement")))),
            _ => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_here(p_, &Text::lit("expected an expression")))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start KeywordPrimary, x`: what the function value is when passed to `@Run`.
pub fn start_keyword_primary(p_: crate::syntax::parser::Ps, w: Text, sigils: Text, commas: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)>> {
    Rc::new(KeywordPrimary { p_, w, sigils, commas })
}

/// ```prism
/// Took: fn ((Expr, Ps)) -> ((Expr, Bool, Ps))
/// ```
pub fn took(arg0: &(crate::syntax::Expr, crate::syntax::parser::Ps)) -> (crate::syntax::Expr, bool, crate::syntax::parser::Ps) {
    match arg0 {
        (e, p_) => (e.clone(), true, p_.clone()),
    }
}

/// ```prism
/// ParseLiteral: unbounded fn Ps -> ((Literal, Ps))
/// ```
pub fn parse_literal(p_: &crate::syntax::parser::Ps) -> (crate::syntax::Literal, crate::syntax::parser::Ps) {
    let span = crate::syntax::parser::here(p_);
    let p1 = crate::syntax::parser::adv(p_);
    match crate::syntax::parser::kind(p_) {
        crate::syntax::lexer::TokKind::KInt(s, t) => (crate::syntax::Literal { marks: s, kind: crate::syntax::LitKind::LInt(t), span: span.clone() }, p1.clone()),
        crate::syntax::lexer::TokKind::KFloat(s, t) => (crate::syntax::Literal { marks: s, kind: crate::syntax::LitKind::LFloat(t), span: span.clone() }, p1.clone()),
        crate::syntax::lexer::TokKind::KDuration(s, n, u) => (crate::syntax::Literal { marks: s, kind: crate::syntax::LitKind::LDuration(n, u), span: span.clone() }, p1.clone()),
        crate::syntax::lexer::TokKind::KChar(s, c) => (crate::syntax::Literal { marks: s, kind: crate::syntax::LitKind::LChar(c), span: span.clone() }, p1.clone()),
        crate::syntax::lexer::TokKind::KRegex(s, r) => (crate::syntax::Literal { marks: s, kind: crate::syntax::LitKind::LRegex(r), span: span.clone() }, p1.clone()),
        crate::syntax::lexer::TokKind::KText(s, segs) => {
            let (out, q) = run_to_end(fold_job(segs.clone(), (Array::new(), p1.clone()), Rc::new(move |(p0, p1): ((Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps), crate::syntax::lexer::TextSegTok)| entered(once_job(move || {
                let (acc, pp) = p0;
                let seg = p1;
                prism_rtl::Turn::More(Rc::new(TextSegment { acc: acc.clone(), p_: pp.clone(), text_seg_tok2: seg.clone() }))
            }))) as Rc<dyn Fn(((Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps), crate::syntax::lexer::TextSegTok)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps)>>>));
            (crate::syntax::Literal { marks: s.clone(), kind: crate::syntax::LitKind::LText(out.clone()), span: span.clone() }, q.clone())
        },
        _ => (crate::syntax::Literal { marks: Text::lit(""), kind: crate::syntax::LitKind::LInt(Text::lit("")), span: span.clone() }, crate::syntax::parser::error_at(&p1, &span, &Text::lit("expected a literal"))),
    }
}

/// The step machine of `ParseLiteral`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseLiteral: unbounded fn Ps -> ((Literal, Ps))
/// ```
pub struct ParseLiteral {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Literal, crate::syntax::parser::Ps)> for ParseLiteral {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Literal, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let span = crate::syntax::parser::here(p_);
        let p1 = crate::syntax::parser::adv(p_);
        match crate::syntax::parser::kind(p_) {
            crate::syntax::lexer::TokKind::KInt(s, t) => prism_rtl::Turn::Finished((crate::syntax::Literal { marks: s.clone(), kind: crate::syntax::LitKind::LInt(t.clone()), span: span.clone() }, p1.clone())),
            crate::syntax::lexer::TokKind::KFloat(s, t) => prism_rtl::Turn::Finished((crate::syntax::Literal { marks: s.clone(), kind: crate::syntax::LitKind::LFloat(t.clone()), span: span.clone() }, p1.clone())),
            crate::syntax::lexer::TokKind::KDuration(s, n, u) => prism_rtl::Turn::Finished((crate::syntax::Literal { marks: s.clone(), kind: crate::syntax::LitKind::LDuration(n.clone(), u.clone()), span: span.clone() }, p1.clone())),
            crate::syntax::lexer::TokKind::KChar(s, c) => prism_rtl::Turn::Finished((crate::syntax::Literal { marks: s.clone(), kind: crate::syntax::LitKind::LChar(c.clone()), span: span.clone() }, p1.clone())),
            crate::syntax::lexer::TokKind::KRegex(s, r) => prism_rtl::Turn::Finished((crate::syntax::Literal { marks: s.clone(), kind: crate::syntax::LitKind::LRegex(r.clone()), span: span.clone() }, p1.clone())),
            crate::syntax::lexer::TokKind::KText(s, segs) => call_value(fold_job(segs.clone(), (Array::new(), p1.clone()), Rc::new(move |(p0, p1): ((Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps), crate::syntax::lexer::TextSegTok)| entered(once_job(move || {
                let (acc, pp) = p0;
                let seg = p1;
                prism_rtl::Turn::More(Rc::new(TextSegment { acc: acc.clone(), p_: pp.clone(), text_seg_tok2: seg.clone() }))
            }))) as Rc<dyn Fn(((Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps), crate::syntax::lexer::TextSegTok)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps)>>>), move |fold_25477: (Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps)| {
                let (out, q) = fold_25477;
                prism_rtl::Turn::Finished((crate::syntax::Literal { marks: s.clone(), kind: crate::syntax::LitKind::LText(out.clone()), span: span.clone() }, q.clone()))
            }),
            _ => prism_rtl::Turn::Finished((crate::syntax::Literal { marks: Text::lit(""), kind: crate::syntax::LitKind::LInt(Text::lit("")), span: span.clone() }, crate::syntax::parser::error_at(&p1, &span, &Text::lit("expected a literal")))),
        }
    }
}

/// `Start ParseLiteral, x`: what the function value is when passed to `@Run`.
pub fn start_parse_literal(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Literal, crate::syntax::parser::Ps)>> {
    Rc::new(ParseLiteral { p_ })
}

/// ```prism
/// TextSegment: unbounded fn [TextSeg], Ps, TextSegTok -> (([TextSeg], Ps))
/// ```
pub fn text_segment(acc: &Array<crate::syntax::TextSeg>, p_: &crate::syntax::parser::Ps, text_seg_tok2: &crate::syntax::lexer::TextSegTok) -> (Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps) {
    match text_seg_tok2 {
        crate::syntax::lexer::TextSegTok::TsPlain(s) => (push(acc, &crate::syntax::TextSeg::SegPlain(s.clone())), p_.clone()),
        crate::syntax::lexer::TextSegTok::TsPlaceholder(toks, span) => {
            let (e, q) = parse_nested(p_, toks, span);
            (push(acc, &crate::syntax::TextSeg::SegPlaceholder(e.clone())), q.clone())
        },
    }
}

/// The step machine of `TextSegment`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TextSegment: unbounded fn [TextSeg], Ps, TextSegTok -> (([TextSeg], Ps))
/// ```
pub struct TextSegment {
    pub acc: Array<crate::syntax::TextSeg>,
    pub p_: crate::syntax::parser::Ps,
    pub text_seg_tok2: crate::syntax::lexer::TextSegTok,
}

impl prism_rtl::Job<(Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps)> for TextSegment {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps)> {
        let acc = &self.acc;
        let p_ = &self.p_;
        let text_seg_tok2 = &self.text_seg_tok2;
        match text_seg_tok2 {
            crate::syntax::lexer::TextSegTok::TsPlain(s) => prism_rtl::Turn::Finished((push(acc, &crate::syntax::TextSeg::SegPlain(s.clone())), p_.clone())),
            crate::syntax::lexer::TextSegTok::TsPlaceholder(toks, span) => {
                let acc = acc.clone();
                let p_ = p_.clone();
                let span = span.clone();
                let toks = toks.clone();
                call_then(start_parse_nested(p_.clone(), toks.clone(), span.clone()), move |parse_nested_25935: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (e, q) = parse_nested_25935;
                    prism_rtl::Turn::Finished((push(&acc, &crate::syntax::TextSeg::SegPlaceholder(e.clone())), q.clone()))
                })
            },
        }
    }
}

/// `Start TextSegment, x`: what the function value is when passed to `@Run`.
pub fn start_text_segment(acc: Array<crate::syntax::TextSeg>, p_: crate::syntax::parser::Ps, text_seg_tok2: crate::syntax::lexer::TextSegTok) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps)>> {
    Rc::new(TextSegment { acc, p_, text_seg_tok2 })
}

/// ```prism
/// ParseNested: unbounded fn Ps, [Tok], Range -> ((Expr, Ps))
/// ```
pub fn parse_nested(p_: &crate::syntax::parser::Ps, toks: &Array<crate::syntax::lexer::Tok>, span: &crate::syntax::Range) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let sub = crate::syntax::parser::with_step_mode(&crate::syntax::parser::sub(p_, toks, &crate::syntax::parser::at_end(span)), &false);
    let (e, s1) = parse_rhs_expr(&sub);
    let s2 = if !s1.bad && !crate::syntax::parser::at_eof(&s1) {
        crate::syntax::parser::note_error(&s1, &crate::syntax::parser::here(&s1), &Text::from(format!("expected the end of the placeholder, found {}", &crate::syntax::parser::describe(&crate::syntax::parser::kind(&s1)))))
    } else {
        s1.clone()
    };
    let s3 = if s2.bad && (&len(&s2.diags) == &Nat::from(0u32)) {
        crate::syntax::parser::note_error(&crate::syntax::parser::unbad(&s2), span, &Text::lit("expected an expression in the placeholder"))
    } else {
        s2.clone()
    };
    let q = crate::syntax::parser::absorb(p_, &s3);
    if s1.bad {
        (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span.clone() }, q.clone())
    } else {
        (e.clone(), q.clone())
    }
}

/// The step machine of `ParseNested`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseNested: unbounded fn Ps, [Tok], Range -> ((Expr, Ps))
/// ```
pub struct ParseNested {
    pub p_: crate::syntax::parser::Ps,
    pub toks: Array<crate::syntax::lexer::Tok>,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseNested {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let toks = &self.toks;
        let span = &self.span;
        let p_ = p_.clone();
        let span = span.clone();
        let toks = toks.clone();
        call_then(crate::syntax::parser::start_sub(p_.clone(), toks.clone(), crate::syntax::parser::at_end(&span)), move |sub_26258: crate::syntax::parser::Ps| {
            let sub = crate::syntax::parser::with_step_mode(&sub_26258, &false);
            call_then(start_parse_rhs_expr(sub.clone()), move |parse_rhs_expr_26312: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                let (e, s1) = parse_rhs_expr_26312;
                let s2 = if !s1.bad && !crate::syntax::parser::at_eof(&s1) {
                    crate::syntax::parser::note_error(&s1, &crate::syntax::parser::here(&s1), &Text::from(format!("expected the end of the placeholder, found {}", &crate::syntax::parser::describe(&crate::syntax::parser::kind(&s1)))))
                } else {
                    s1.clone()
                };
                let s3 = if s2.bad && (&len(&s2.diags) == &Nat::from(0u32)) {
                    crate::syntax::parser::note_error(&crate::syntax::parser::unbad(&s2), &span, &Text::lit("expected an expression in the placeholder"))
                } else {
                    s2.clone()
                };
                let q = crate::syntax::parser::absorb(&p_, &s3);
                if s1.bad {
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span.clone() }, q.clone()))
                } else {
                    prism_rtl::Turn::Finished((e.clone(), q.clone()))
                }
            })
        })
    }
}

/// `Start ParseNested, x`: what the function value is when passed to `@Run`.
pub fn start_parse_nested(p_: crate::syntax::parser::Ps, toks: Array<crate::syntax::lexer::Tok>, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(ParseNested { p_, toks, span })
}

/// ```prism
/// ParseTemplate: unbounded fn Ps, TemplateTok, Range -> ((Template, Ps))
/// ```
pub fn parse_template(p0: &crate::syntax::parser::Ps, t: &crate::syntax::lexer::TemplateTok, span: &crate::syntax::Range) -> (crate::syntax::Template, crate::syntax::parser::Ps) {
    let p1 = if (&t.delims == &Text::lit("single")) && (&t.keyword != &Text::lit("Raw")) {
        crate::syntax::parser::out_of_scope(p0, span, &Text::lit("the template notation"), &Text::from(format!("a `<{}>` template is the template notation for an element language, out of this compiler (code templates only)", &t.lang)))
    } else {
        p0.clone()
    };
    let p2 = if &t.keyword == &Text::lit("File") {
        crate::syntax::parser::out_of_scope(&p1, span, &Text::lit("the template notation"), &Text::lit("a file whose first token is a language tag is a template file, out of this compiler (code templates only)"))
    } else {
        p1.clone()
    };
    let (parts, p3) = template_parts(&p2, &t.parts);
    (crate::syntax::Template { keyword: t.keyword.clone(), lang: t.lang.clone(), delims: t.delims.clone(), parts: parts.clone(), span: span.clone() }, p3.clone())
}

/// The step machine of `ParseTemplate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTemplate: unbounded fn Ps, TemplateTok, Range -> ((Template, Ps))
/// ```
pub struct ParseTemplate {
    pub p0: crate::syntax::parser::Ps,
    pub t: crate::syntax::lexer::TemplateTok,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::syntax::Template, crate::syntax::parser::Ps)> for ParseTemplate {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Template, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let t = &self.t;
        let span = &self.span;
        let p1 = if (&t.delims == &Text::lit("single")) && (&t.keyword != &Text::lit("Raw")) {
            crate::syntax::parser::out_of_scope(p0, span, &Text::lit("the template notation"), &Text::from(format!("a `<{}>` template is the template notation for an element language, out of this compiler (code templates only)", &t.lang)))
        } else {
            p0.clone()
        };
        let p2 = if &t.keyword == &Text::lit("File") {
            crate::syntax::parser::out_of_scope(&p1, span, &Text::lit("the template notation"), &Text::lit("a file whose first token is a language tag is a template file, out of this compiler (code templates only)"))
        } else {
            p1.clone()
        };
        let span = span.clone();
        let t = t.clone();
        call_then(start_template_parts(p2.clone(), t.parts.clone()), move |template_parts_27307: (Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)| {
            let (parts, p3) = template_parts_27307;
            prism_rtl::Turn::Finished((crate::syntax::Template { keyword: t.keyword.clone(), lang: t.lang.clone(), delims: t.delims.clone(), parts: parts.clone(), span: span.clone() }, p3.clone()))
        })
    }
}

/// `Start ParseTemplate, x`: what the function value is when passed to `@Run`.
pub fn start_parse_template(p0: crate::syntax::parser::Ps, t: crate::syntax::lexer::TemplateTok, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::syntax::Template, crate::syntax::parser::Ps)>> {
    Rc::new(ParseTemplate { p0, t, span })
}

/// ```prism
/// TemplateParts: unbounded fn Ps, [TPartTok] -> (([TemplatePart], Ps))
/// ```
pub fn template_parts(p_: &crate::syntax::parser::Ps, parts: &Array<crate::syntax::lexer::TPartTok>) -> (Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps) {
    run_to_end(fold_job(parts.clone(), (Array::new(), p_.clone()), Rc::new(move |(p0, p1): ((Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps), crate::syntax::lexer::TPartTok)| entered(once_job(move || {
        let (acc, q) = p0;
        let part = p1;
        prism_rtl::Turn::More(Rc::new(TemplatePartOf { acc: acc.clone(), p_: q.clone(), tpart_tok2: part.clone() }))
    }))) as Rc<dyn Fn(((Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps), crate::syntax::lexer::TPartTok)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)>>>))
}

/// The step machine of `TemplateParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateParts: unbounded fn Ps, [TPartTok] -> (([TemplatePart], Ps))
/// ```
pub struct TemplateParts {
    pub p_: crate::syntax::parser::Ps,
    pub parts: Array<crate::syntax::lexer::TPartTok>,
}

impl prism_rtl::Job<(Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)> for TemplateParts {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let parts = &self.parts;
        fold_job(parts.clone(), (Array::new(), p_.clone()), Rc::new(move |(p0, p1): ((Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps), crate::syntax::lexer::TPartTok)| entered(once_job(move || {
            let (acc, q) = p0;
            let part = p1;
            prism_rtl::Turn::More(Rc::new(TemplatePartOf { acc: acc.clone(), p_: q.clone(), tpart_tok2: part.clone() }))
        }))) as Rc<dyn Fn(((Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps), crate::syntax::lexer::TPartTok)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)>>>).cycle()
    }
}

/// `Start TemplateParts, x`: what the function value is when passed to `@Run`.
pub fn start_template_parts(p_: crate::syntax::parser::Ps, parts: Array<crate::syntax::lexer::TPartTok>) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)>> {
    Rc::new(TemplateParts { p_, parts })
}

/// ```prism
/// TemplatePartOf: unbounded fn [TemplatePart], Ps, TPartTok -> (([TemplatePart], Ps))
/// ```
pub fn template_part_of(acc: &Array<crate::syntax::TemplatePart>, p_: &crate::syntax::parser::Ps, tpart_tok2: &crate::syntax::lexer::TPartTok) -> (Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps) {
    match tpart_tok2 {
        crate::syntax::lexer::TPartTok::TptText(s) => (push(acc, &crate::syntax::TemplatePart::TpText(s.clone())), p_.clone()),
        crate::syntax::lexer::TPartTok::TptPlaceholder(toks, col_opt, span) => {
            let (e, q) = parse_nested(p_, toks, span);
            (push(acc, &crate::syntax::TemplatePart::TpPlaceholder(e.clone(), col_opt.clone())), q.clone())
        },
        crate::syntax::lexer::TPartTok::TptBlock(toks, span) => {
            let sub = crate::syntax::parser::sub(p_, toks, &crate::syntax::parser::at_end(span));
            let (block, s1) = crate::syntax::parser::blocks::parse_block_until_eof(&sub, span);
            (push(acc, &crate::syntax::TemplatePart::TpBlock(block.clone())), crate::syntax::parser::absorb(p_, &s1))
        },
        crate::syntax::lexer::TPartTok::TptCall(name, attrs, body_opt, span) => {
            let sname = crate::syntax::SName { sigils: name.sigils.clone(), path_: name.path_.clone(), span: span.clone() };
            let (args, p1) = run_to_end(fold_job(attrs.clone(), (Array::new(), p_.clone()), Rc::new(move |(p0, p1): ((Array<crate::syntax::Arg>, crate::syntax::parser::Ps), crate::syntax::lexer::AttrTok)| entered(once_job(move || {
                let (done, q) = p0;
                let a = p1;
                prism_rtl::Turn::More(Rc::new(AttrArg { done: done.clone(), p_: q.clone(), a: a.clone() }))
            }))) as Rc<dyn Fn(((Array<crate::syntax::Arg>, crate::syntax::parser::Ps), crate::syntax::lexer::AttrTok)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Arg>, crate::syntax::parser::Ps)>>>));
            let (inner_opt, p2) = match body_opt {
                Some(b) => {
                    let (ps, q) = template_parts(&p1, b);
                    (Some(ps.clone()), q.clone())
                },
                None => (None, p1.clone()),
            };
            (push(acc, &crate::syntax::TemplatePart::TpCall(sname.clone(), args.clone(), inner_opt.clone(), span.clone())), p2.clone())
        },
    }
}

/// The step machine of `TemplatePartOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplatePartOf: unbounded fn [TemplatePart], Ps, TPartTok -> (([TemplatePart], Ps))
/// ```
pub struct TemplatePartOf {
    pub acc: Array<crate::syntax::TemplatePart>,
    pub p_: crate::syntax::parser::Ps,
    pub tpart_tok2: crate::syntax::lexer::TPartTok,
}

impl prism_rtl::Job<(Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)> for TemplatePartOf {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)> {
        let acc = &self.acc;
        let p_ = &self.p_;
        let tpart_tok2 = &self.tpart_tok2;
        match tpart_tok2 {
            crate::syntax::lexer::TPartTok::TptText(s) => prism_rtl::Turn::Finished((push(acc, &crate::syntax::TemplatePart::TpText(s.clone())), p_.clone())),
            crate::syntax::lexer::TPartTok::TptPlaceholder(toks, col_opt, span) => {
                let col_opt = col_opt.clone();
                let acc = acc.clone();
                let p_ = p_.clone();
                let span = span.clone();
                let toks = toks.clone();
                call_then(start_parse_nested(p_.clone(), toks.clone(), span.clone()), move |parse_nested_27833: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (e, q) = parse_nested_27833;
                    prism_rtl::Turn::Finished((push(&acc, &crate::syntax::TemplatePart::TpPlaceholder(e.clone(), col_opt.clone())), q.clone()))
                })
            },
            crate::syntax::lexer::TPartTok::TptBlock(toks, span) => {
                let acc = acc.clone();
                let p_ = p_.clone();
                let span = span.clone();
                let toks = toks.clone();
                call_then(crate::syntax::parser::start_sub(p_.clone(), toks.clone(), crate::syntax::parser::at_end(&span)), move |sub_27969: crate::syntax::parser::Ps| {
                    let sub = sub_27969;
                    call_then(crate::syntax::parser::blocks::start_parse_block_until_eof(sub.clone(), span.clone()), move |parse_block_until_eof_28019: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                        let (block, s1) = parse_block_until_eof_28019;
                        prism_rtl::Turn::Finished((push(&acc, &crate::syntax::TemplatePart::TpBlock(block.clone())), crate::syntax::parser::absorb(&p_, &s1)))
                    })
                })
            },
            crate::syntax::lexer::TPartTok::TptCall(name, attrs, body_opt, span) => {
                let sname = crate::syntax::SName { sigils: name.sigils.clone(), path_: name.path_.clone(), span: span.clone() };
                let body_opt = body_opt.clone();
                let acc = acc.clone();
                let attrs = attrs.clone();
                let p_ = p_.clone();
                let span = span.clone();
                call_value(fold_job(attrs.clone(), (Array::new(), p_.clone()), Rc::new(move |(p0, p1): ((Array<crate::syntax::Arg>, crate::syntax::parser::Ps), crate::syntax::lexer::AttrTok)| entered(once_job(move || {
                    let (done, q) = p0;
                    let a = p1;
                    prism_rtl::Turn::More(Rc::new(AttrArg { done: done.clone(), p_: q.clone(), a: a.clone() }))
                }))) as Rc<dyn Fn(((Array<crate::syntax::Arg>, crate::syntax::parser::Ps), crate::syntax::lexer::AttrTok)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Arg>, crate::syntax::parser::Ps)>>>), move |fold_28254: (Array<crate::syntax::Arg>, crate::syntax::parser::Ps)| {
                    let (args, p1) = fold_28254;
                    let (inner_opt, p2) = match &body_opt {
                        Some(b) => {
                            let (ps, q) = template_parts(&p1, b);
                            (Some(ps.clone()), q.clone())
                        },
                        None => (None, p1.clone()),
                    };
                    prism_rtl::Turn::Finished((push(&acc, &crate::syntax::TemplatePart::TpCall(sname.clone(), args.clone(), inner_opt.clone(), span.clone())), p2.clone()))
                })
            },
        }
    }
}

/// `Start TemplatePartOf, x`: what the function value is when passed to `@Run`.
pub fn start_template_part_of(acc: Array<crate::syntax::TemplatePart>, p_: crate::syntax::parser::Ps, tpart_tok2: crate::syntax::lexer::TPartTok) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)>> {
    Rc::new(TemplatePartOf { acc, p_, tpart_tok2 })
}

/// ```prism
/// AttrArg: unbounded fn [Arg], Ps, AttrTok -> (([Arg], Ps))
/// ```
pub fn attr_arg(done: &Array<crate::syntax::Arg>, p_: &crate::syntax::parser::Ps, a: &crate::syntax::lexer::AttrTok) -> (Array<crate::syntax::Arg>, crate::syntax::parser::Ps) {
    let (value, q) = parse_nested(p_, &a.tokens, &a.span);
    (push(done, &crate::syntax::Arg { name: Some(crate::syntax::Ident { name: a.name.clone(), span: a.span.clone() }), value: value.clone(), span: a.span.clone() }), q.clone())
}

/// The step machine of `AttrArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AttrArg: unbounded fn [Arg], Ps, AttrTok -> (([Arg], Ps))
/// ```
pub struct AttrArg {
    pub done: Array<crate::syntax::Arg>,
    pub p_: crate::syntax::parser::Ps,
    pub a: crate::syntax::lexer::AttrTok,
}

impl prism_rtl::Job<(Array<crate::syntax::Arg>, crate::syntax::parser::Ps)> for AttrArg {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::Arg>, crate::syntax::parser::Ps)> {
        let done = &self.done;
        let p_ = &self.p_;
        let a = &self.a;
        let a = a.clone();
        let done = done.clone();
        let p_ = p_.clone();
        call_then(start_parse_nested(p_.clone(), a.tokens.clone(), a.span.clone()), move |parse_nested_28628: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
            let (value, q) = parse_nested_28628;
            prism_rtl::Turn::Finished((push(&done, &crate::syntax::Arg { name: Some(crate::syntax::Ident { name: a.name.clone(), span: a.span.clone() }), value: value.clone(), span: a.span.clone() }), q.clone()))
        })
    }
}

/// `Start AttrArg, x`: what the function value is when passed to `@Run`.
pub fn start_attr_arg(done: Array<crate::syntax::Arg>, p_: crate::syntax::parser::Ps, a: crate::syntax::lexer::AttrTok) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Arg>, crate::syntax::parser::Ps)>> {
    Rc::new(AttrArg { done, p_, a })
}

/// ```prism
/// ParseLambda: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_lambda(p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p0);
    let p_ = crate::syntax::parser::adv(p0);
    let (params_opt, p1) = if &crate::syntax::parser::kind(&p_) == &crate::syntax::lexer::TokKind::KLambdaBar(true) {
        lambda_params(&crate::syntax::parser::adv(&p_))
    } else {
        (None, p_.clone())
    };
    if crate::syntax::parser::at_open_l(&p1) {
        {
            let (block, q) = crate::syntax::parser::blocks::parse_indented_block(&p1);
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELambda(params_opt.clone(), Rc::new(crate::syntax::LambdaBody::LbBlock(block.clone())))), span: crate::syntax::parser::to(&start, &block.span) }, q.clone())
        }
    } else {
        {
            let (body, q) = parse_expr(&p1);
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELambda(params_opt.clone(), Rc::new(crate::syntax::LambdaBody::LbExpr(Rc::new(body.clone()))))), span: crate::syntax::parser::to(&start, &body.span) }, q.clone())
        }
    }
}

/// The step machine of `ParseLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseLambda: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseLambda {
    pub p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseLambda {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let start = crate::syntax::parser::here(p0);
        let p_ = crate::syntax::parser::adv(p0);
        let (params_opt, p1) = if &crate::syntax::parser::kind(&p_) == &crate::syntax::lexer::TokKind::KLambdaBar(true) {
            lambda_params(&crate::syntax::parser::adv(&p_))
        } else {
            (None, p_.clone())
        };
        if crate::syntax::parser::at_open_l(&p1) {
            call_then(crate::syntax::parser::blocks::start_parse_indented_block(p1.clone()), move |parse_indented_block_29257: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                let (block, q) = parse_indented_block_29257;
                prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELambda(params_opt.clone(), Rc::new(crate::syntax::LambdaBody::LbBlock(block.clone())))), span: crate::syntax::parser::to(&start, &block.span) }, q.clone()))
            })
        } else {
            call_then(start_parse_expr(p1.clone()), move |parse_expr_29405: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                let (body, q) = parse_expr_29405;
                prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELambda(params_opt.clone(), Rc::new(crate::syntax::LambdaBody::LbExpr(Rc::new(body.clone()))))), span: crate::syntax::parser::to(&start, &body.span) }, q.clone()))
            })
        }
    }
}

/// `Start ParseLambda, x`: what the function value is when passed to `@Run`.
pub fn start_parse_lambda(p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(ParseLambda { p0 })
}

/// ```prism
/// LambdaParams: unbounded fn Ps -> ((?[Pattern], Ps))
/// ```
pub fn lambda_params(p_: &crate::syntax::parser::Ps) -> (Option<Array<crate::syntax::Pattern_>>, crate::syntax::parser::Ps) {
    let (ps, p1) = if &crate::syntax::parser::kind(p_) == &crate::syntax::lexer::TokKind::KLambdaBar(false) {
        (Array::new(), p_.clone())
    } else {
        crate::syntax::parser::commas(p_, &(Rc::new(move |p0: crate::syntax::parser::Ps| entered(once_job(move || {
            let q = p0;
            prism_rtl::Turn::More(Rc::new(crate::syntax::parser::types::ParsePattern { p_: q.clone(), commas0: false }))
        }))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>>>))
    };
    if &crate::syntax::parser::kind(&p1) == &crate::syntax::lexer::TokKind::KLambdaBar(false) {
        (Some(ps.clone()), crate::syntax::parser::adv(&p1))
    } else {
        (None, crate::syntax::parser::error_here(&p1, &Text::lit("expected `|` to close the lambda\'s parameters")))
    }
}

/// The step machine of `LambdaParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LambdaParams: unbounded fn Ps -> ((?[Pattern], Ps))
/// ```
pub struct LambdaParams {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(Option<Array<crate::syntax::Pattern_>>, crate::syntax::parser::Ps)> for LambdaParams {
    fn cycle(&self) -> prism_rtl::Turn<(Option<Array<crate::syntax::Pattern_>>, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let (ps, p1) = if &crate::syntax::parser::kind(p_) == &crate::syntax::lexer::TokKind::KLambdaBar(false) {
            (Array::new(), p_.clone())
        } else {
            crate::syntax::parser::commas(p_, &(Rc::new(move |p0: crate::syntax::parser::Ps| entered(once_job(move || {
                let q = p0;
                prism_rtl::Turn::More(Rc::new(crate::syntax::parser::types::ParsePattern { p_: q.clone(), commas0: false }))
            }))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>>>))
        };
        if &crate::syntax::parser::kind(&p1) == &crate::syntax::lexer::TokKind::KLambdaBar(false) {
            prism_rtl::Turn::Finished((Some(ps.clone()), crate::syntax::parser::adv(&p1)))
        } else {
            prism_rtl::Turn::Finished((None, crate::syntax::parser::error_here(&p1, &Text::lit("expected `|` to close the lambda\'s parameters"))))
        }
    }
}

/// `Start LambdaParams, x`: what the function value is when passed to `@Run`.
pub fn start_lambda_params(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(Option<Array<crate::syntax::Pattern_>>, crate::syntax::parser::Ps)>> {
    Rc::new(LambdaParams { p_ })
}

/// ```prism
/// ParseCond: unbounded fn Ps, Bool -> ((Cond, Ps))
/// ```
pub fn parse_cond(p_: &crate::syntax::parser::Ps, allow_guard: &bool) -> (crate::syntax::Cond, crate::syntax::parser::Ps) {
    let (pattern, q) = crate::syntax::parser::types::parse_pattern(p_, &true);
    if !q.bad && crate::syntax::parser::at_op(&q, &Text::lit("<-")) {
        {
            let (value, q1) = parse_expr(&crate::syntax::parser::adv(&q));
            if *allow_guard && crate::syntax::parser::at_kw(&q1, &Text::lit("if")) {
                {
                    let (guard, q2) = parse_expr(&crate::syntax::parser::adv(&q1));
                    (crate::syntax::Cond::CondBind(pattern.clone(), Rc::new(value.clone()), Rc::new(Some(guard.clone()))), q2.clone())
                }
            } else {
                (crate::syntax::Cond::CondBind(pattern.clone(), Rc::new(value.clone()), Rc::new(None)), q1.clone())
            }
        }
    } else {
        {
            let (e, q1) = parse_expr(p_);
            (crate::syntax::Cond::CondExpr(Rc::new(e.clone())), q1.clone())
        }
    }
}

/// The step machine of `ParseCond`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseCond: unbounded fn Ps, Bool -> ((Cond, Ps))
/// ```
pub struct ParseCond {
    pub p_: crate::syntax::parser::Ps,
    pub allow_guard: bool,
}

impl prism_rtl::Job<(crate::syntax::Cond, crate::syntax::parser::Ps)> for ParseCond {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Cond, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let allow_guard = &self.allow_guard;
        let allow_guard = *allow_guard;
        let p_ = p_.clone();
        call_then(crate::syntax::parser::types::start_parse_pattern(p_.clone(), true), move |parse_pattern_29990: (crate::syntax::Pattern_, crate::syntax::parser::Ps)| {
            let (pattern, q) = parse_pattern_29990;
            if !q.bad && crate::syntax::parser::at_op(&q, &Text::lit("<-")) {
                call_then(start_parse_expr(crate::syntax::parser::adv(&q)), move |parse_expr_30076: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (value, q1) = parse_expr_30076;
                    if allow_guard && crate::syntax::parser::at_kw(&q1, &Text::lit("if")) {
                        call_then(start_parse_expr(crate::syntax::parser::adv(&q1)), move |parse_expr_30169: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                            let (guard, q2) = parse_expr_30169;
                            prism_rtl::Turn::Finished((crate::syntax::Cond::CondBind(pattern.clone(), Rc::new(value.clone()), Rc::new(Some(guard.clone()))), q2.clone()))
                        })
                    } else {
                        prism_rtl::Turn::Finished((crate::syntax::Cond::CondBind(pattern.clone(), Rc::new(value.clone()), Rc::new(None)), q1.clone()))
                    }
                })
            } else {
                call_then(start_parse_expr(p_.clone()), move |parse_expr_30332: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (e, q1) = parse_expr_30332;
                    prism_rtl::Turn::Finished((crate::syntax::Cond::CondExpr(Rc::new(e.clone())), q1.clone()))
                })
            }
        })
    }
}

/// `Start ParseCond, x`: what the function value is when passed to `@Run`.
pub fn start_parse_cond(p_: crate::syntax::parser::Ps, allow_guard: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Cond, crate::syntax::parser::Ps)>> {
    Rc::new(ParseCond { p_, allow_guard })
}

/// ```prism
/// ParseIf: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_if(p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p0);
    let (cond, p1) = parse_cond(&crate::syntax::parser::adv(p0), &false);
    let (then_block, p2) = crate::syntax::parser::blocks::parse_block_after_colon(&p1);
    let p3 = if crate::syntax::parser::at_sep(&p2) && is_else(&crate::syntax::parser::kind_at(&p2, &Nat::from(1u32))) {
        crate::syntax::parser::adv(&p2)
    } else {
        p2.clone()
    };
    if crate::syntax::parser::at_kw(&p3, &Text::lit("else")) {
        {
            let (else_block, q) = crate::syntax::parser::blocks::parse_block_after_colon(&crate::syntax::parser::adv(&p3));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EIf(Rc::new(cond.clone()), then_block.clone(), Some(else_block.clone()))), span: crate::syntax::parser::to(&start, &else_block.span) }, q.clone())
        }
    } else {
        (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EIf(Rc::new(cond.clone()), then_block.clone(), None)), span: crate::syntax::parser::to(&start, &then_block.span) }, p3.clone())
    }
}

/// The step machine of `ParseIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseIf: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseIf {
    pub p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseIf {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let start = crate::syntax::parser::here(p0);
        let p0 = p0.clone();
        call_then(start_parse_cond(crate::syntax::parser::adv(&p0), false), move |parse_cond_30565: (crate::syntax::Cond, crate::syntax::parser::Ps)| {
            let (cond, p1) = parse_cond_30565;
            call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(p1.clone()), move |parse_block_after_colon_30619: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                let (then_block, p2) = parse_block_after_colon_30619;
                let p3 = if crate::syntax::parser::at_sep(&p2) && is_else(&crate::syntax::parser::kind_at(&p2, &Nat::from(1u32))) {
                    crate::syntax::parser::adv(&p2)
                } else {
                    p2.clone()
                };
                if crate::syntax::parser::at_kw(&p3, &Text::lit("else")) {
                    call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(crate::syntax::parser::adv(&p3)), move |parse_block_after_colon_30770: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                        let (else_block, q) = parse_block_after_colon_30770;
                        prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EIf(Rc::new(cond.clone()), then_block.clone(), Some(else_block.clone()))), span: crate::syntax::parser::to(&start, &else_block.span) }, q.clone()))
                    })
                } else {
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EIf(Rc::new(cond.clone()), then_block.clone(), None)), span: crate::syntax::parser::to(&start, &then_block.span) }, p3.clone()))
                }
            })
        })
    }
}

/// `Start ParseIf, x`: what the function value is when passed to `@Run`.
pub fn start_parse_if(p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(ParseIf { p0 })
}

/// ```prism
/// IsElse: fn TokKind -> Bool
/// ```
pub fn is_else(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KKw(c0_0_0, _) if (c0_0_0 == &Text::lit("else")) => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParseMatch: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_match(p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p0);
    let (scrutinee, p1) = parse_expr(&crate::syntax::parser::adv(p0));
    let p2 = crate::syntax::parser::expect_colon(&p1);
    if crate::syntax::parser::at_open_l(&p2) {
        {
            let (arms, q) = match_arms(&crate::syntax::parser::adv(&p2));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMatch(Rc::new(scrutinee.clone()), arms.clone())), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone())
        }
    } else {
        (crate::syntax::parser::decls::no_expr(), crate::syntax::parser::error_here(&p2, &Text::lit("a `match`\'s arms stand in an indented block after its `:`")))
    }
}

/// The step machine of `ParseMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseMatch: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseMatch {
    pub p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseMatch {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let start = crate::syntax::parser::here(p0);
        let p0 = p0.clone();
        call_then(start_parse_expr(crate::syntax::parser::adv(&p0)), move |parse_expr_31351: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
            let (scrutinee, p1) = parse_expr_31351;
            let p2 = crate::syntax::parser::expect_colon(&p1);
            if crate::syntax::parser::at_open_l(&p2) {
                call_then(start_match_arms(crate::syntax::parser::adv(&p2)), move |match_arms_31443: (Array<crate::syntax::Arm>, crate::syntax::parser::Ps)| {
                    let (arms, q) = match_arms_31443;
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMatch(Rc::new(scrutinee.clone()), arms.clone())), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone()))
                })
            } else {
                prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), crate::syntax::parser::error_here(&p2, &Text::lit("a `match`\'s arms stand in an indented block after its `:`"))))
            }
        })
    }
}

/// `Start ParseMatch, x`: what the function value is when passed to `@Run`.
pub fn start_parse_match(p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(ParseMatch { p0 })
}

/// ```prism
/// MatchArms: unbounded fn Ps -> (([Arm], Ps))
/// ```
pub fn match_arms(p0: &crate::syntax::parser::Ps) -> (Array<crate::syntax::Arm>, crate::syntax::parser::Ps) {
    let mut this: (Array<crate::syntax::Arm>, crate::syntax::parser::Ps) = (Array::new(), p0.clone());
    let mut arms: Array<crate::syntax::Arm> = Array::new();
    let mut p_: crate::syntax::parser::Ps = p0.clone();
    let mut going: bool = true;
    while going {
        let (arm, q) = parse_arm(&p_);
        if !q.bad {
            arms = push(&arms, &arm);
        }
        p_ = crate::syntax::parser::recovered(&q);
        match &crate::syntax::parser::kind(&p_) {
            crate::syntax::lexer::TokKind::KLaySep => {
                p_ = crate::syntax::parser::adv(&p_);
            }
            crate::syntax::lexer::TokKind::KLayClose => {
                p_ = crate::syntax::parser::adv(&p_);
                going = false;
            }
            crate::syntax::lexer::TokKind::KEof => {
                going = false;
            }
            _ => {
                p_ = crate::syntax::parser::recover(&crate::syntax::parser::complain(&p_, &Text::lit("expected the end of the arm")));
            }
        }
    }
    this = (arms.clone(), p_.clone());
    this
}

/// The step machine of `MatchArms`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MatchArms: unbounded fn Ps -> (([Arm], Ps))
/// ```
pub struct MatchArms {
    pub p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(Array<crate::syntax::Arm>, crate::syntax::parser::Ps)> for MatchArms {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::Arm>, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let mut this: (Array<crate::syntax::Arm>, crate::syntax::parser::Ps) = (Array::new(), p0.clone());
        let mut arms: Array<crate::syntax::Arm> = Array::new();
        let mut p_: crate::syntax::parser::Ps = p0.clone();
        let mut going: bool = true;
        call_then(loop_job((this, arms, going, p_), move |(mut this, mut arms, mut going, mut p_): ((Array<crate::syntax::Arm>, crate::syntax::parser::Ps), Array<crate::syntax::Arm>, bool, crate::syntax::parser::Ps)| if going {
            {
                let (arm, q) = parse_arm(&p_);
                if !q.bad {
                    arms = push(&arms, &arm);
                }
                p_ = crate::syntax::parser::recovered(&q);
                match &crate::syntax::parser::kind(&p_) {
                    crate::syntax::lexer::TokKind::KLaySep => {
                        p_ = crate::syntax::parser::adv(&p_);
                    }
                    crate::syntax::lexer::TokKind::KLayClose => {
                        p_ = crate::syntax::parser::adv(&p_);
                        going = false;
                    }
                    crate::syntax::lexer::TokKind::KEof => {
                        going = false;
                    }
                    _ => {
                        p_ = crate::syntax::parser::recover(&crate::syntax::parser::complain(&p_, &Text::lit("expected the end of the arm")));
                    }
                }
                Ok((this, arms, going, p_))
            }
        } else {
            Err((this, arms, going, p_))
        }), move |(mut this, mut arms, mut going, mut p_): ((Array<crate::syntax::Arm>, crate::syntax::parser::Ps), Array<crate::syntax::Arm>, bool, crate::syntax::parser::Ps)| {
            this = (arms.clone(), p_.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start MatchArms, x`: what the function value is when passed to `@Run`.
pub fn start_match_arms(p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Arm>, crate::syntax::parser::Ps)>> {
    Rc::new(MatchArms { p0 })
}

/// ```prism
/// ParseArm: unbounded fn Ps -> ((Arm, Ps))
/// ```
pub fn parse_arm(p_: &crate::syntax::parser::Ps) -> (crate::syntax::Arm, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p_);
    if crate::syntax::parser::at_kw(p_, &Text::lit("otherwise")) {
        {
            let (body, q) = crate::syntax::parser::blocks::parse_block_after_colon(&crate::syntax::parser::adv(p_));
            (crate::syntax::Arm { pattern: None, guard: None, body: body.clone(), span: crate::syntax::parser::to(&start, &body.span) }, q.clone())
        }
    } else {
        if crate::syntax::parser::at_kw(p_, &Text::lit("ignore")) && (&crate::syntax::parser::kind_at(p_, &Nat::from(1u32)) == &crate::syntax::lexer::TokKind::KColon) {
            (crate::syntax::Arm { pattern: None, guard: None, body: crate::syntax::parser::decls::no_block(), span: start.clone() }, crate::syntax::parser::error_at(p_, &crate::syntax::parser::here(p_), &Text::lit("an arm beginning `ignore:` would read as \"ignore these cases\": the catch-all is `otherwise:`")))
        } else {
            {
                let (pattern, p1) = crate::syntax::parser::types::parse_pattern(p_, &true);
                let (guard_opt, p2) = if crate::syntax::parser::at_kw(&p1, &Text::lit("if")) {
                    optional_expr(&crate::syntax::parser::adv(&p1))
                } else {
                    (None, p1.clone())
                };
                let (body, p3) = crate::syntax::parser::blocks::parse_block_after_colon(&p2);
                (crate::syntax::Arm { pattern: Some(pattern.clone()), guard: guard_opt.clone(), body: body.clone(), span: crate::syntax::parser::to(&start, &body.span) }, p3.clone())
            }
        }
    }
}

/// ```prism
/// OptionalExpr: unbounded fn Ps -> ((?Expr, Ps))
/// ```
pub fn optional_expr(p_: &crate::syntax::parser::Ps) -> (Option<crate::syntax::Expr>, crate::syntax::parser::Ps) {
    let (e, q) = parse_expr(p_);
    (Some(e.clone()), q.clone())
}

/// ```prism
/// ParseFor: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_for(p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p0);
    let p_ = crate::syntax::parser::adv(p0);
    let (binders_opt, p1) = for_binders_of(&p_);
    let (source, p2) = parse_expr(&p1);
    let (body, p3) = crate::syntax::parser::blocks::parse_block_after_colon(&p2);
    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EFor(binders_opt.clone(), Rc::new(source.clone()), body.clone())), span: crate::syntax::parser::to(&start, &body.span) }, p3.clone())
}

/// The step machine of `ParseFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseFor: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseFor {
    pub p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseFor {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let start = crate::syntax::parser::here(p0);
        let p_ = crate::syntax::parser::adv(p0);
        call_then(start_for_binders_of(p_.clone()), move |for_binders_of_33299: (Option<crate::syntax::ForBinders>, crate::syntax::parser::Ps)| {
            let (binders_opt, p1) = for_binders_of_33299;
            call_then(start_parse_expr(p1.clone()), move |parse_expr_33339: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                let (source, p2) = parse_expr_33339;
                call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(p2.clone()), move |parse_block_after_colon_33375: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                    let (body, p3) = parse_block_after_colon_33375;
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EFor(binders_opt.clone(), Rc::new(source.clone()), body.clone())), span: crate::syntax::parser::to(&start, &body.span) }, p3.clone()))
                })
            })
        })
    }
}

/// `Start ParseFor, x`: what the function value is when passed to `@Run`.
pub fn start_parse_for(p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(ParseFor { p0 })
}

/// ```prism
/// ForBindersOf: unbounded fn Ps -> ((?ForBinders, Ps))
/// ```
pub fn for_binders_of(p_: &crate::syntax::parser::Ps) -> (Option<crate::syntax::ForBinders>, crate::syntax::parser::Ps) {
    let (first_, q1) = crate::syntax::parser::types::parse_pattern(p_, &false);
    let (second_opt, q2) = if crate::syntax::parser::at_comma(&q1) {
        optional_pattern(&crate::syntax::parser::adv(&q1))
    } else {
        (None, q1.clone())
    };
    if !q2.bad && crate::syntax::parser::at_op(&q2, &Text::lit("<-")) {
        (Some(crate::syntax::ForBinders { first: first_.clone(), second: second_opt.clone() }), crate::syntax::parser::adv(&q2))
    } else {
        (None, p_.clone())
    }
}

/// The step machine of `ForBindersOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ForBindersOf: unbounded fn Ps -> ((?ForBinders, Ps))
/// ```
pub struct ForBindersOf {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(Option<crate::syntax::ForBinders>, crate::syntax::parser::Ps)> for ForBindersOf {
    fn cycle(&self) -> prism_rtl::Turn<(Option<crate::syntax::ForBinders>, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let p_ = p_.clone();
        call_then(crate::syntax::parser::types::start_parse_pattern(p_.clone(), false), move |parse_pattern_33660: (crate::syntax::Pattern_, crate::syntax::parser::Ps)| {
            let (first_, q1) = parse_pattern_33660;
            let (second_opt, q2) = if crate::syntax::parser::at_comma(&q1) {
                optional_pattern(&crate::syntax::parser::adv(&q1))
            } else {
                (None, q1.clone())
            };
            if !q2.bad && crate::syntax::parser::at_op(&q2, &Text::lit("<-")) {
                prism_rtl::Turn::Finished((Some(crate::syntax::ForBinders { first: first_.clone(), second: second_opt.clone() }), crate::syntax::parser::adv(&q2)))
            } else {
                prism_rtl::Turn::Finished((None, p_.clone()))
            }
        })
    }
}

/// `Start ForBindersOf, x`: what the function value is when passed to `@Run`.
pub fn start_for_binders_of(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(Option<crate::syntax::ForBinders>, crate::syntax::parser::Ps)>> {
    Rc::new(ForBindersOf { p_ })
}

/// ```prism
/// OptionalPattern: unbounded fn Ps -> ((?Pattern, Ps))
/// ```
pub fn optional_pattern(p_: &crate::syntax::parser::Ps) -> (Option<crate::syntax::Pattern_>, crate::syntax::parser::Ps) {
    let (pat, q) = crate::syntax::parser::types::parse_pattern(p_, &false);
    (Some(pat.clone()), q.clone())
}
