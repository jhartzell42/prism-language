//! The module `Syntax.Parser.Expr`, from `target/bootstrap/src/prismc/syntax/parser/expr.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `ArgsRead`:
///
/// ```prism
/// type ArgsRead = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ArgsRead {
    pub args: Array<crate::syntax::Arg>,
    pub rest: bool,
    pub p_: crate::syntax::parser::Ps,
    pub going: bool,
}

impl Show for ArgsRead {
    fn show(&self, p: &mut Printer) {
        p.record("ArgsRead", &[("args", &self.args), ("rest", &self.rest), ("p", &self.p_), ("going", &self.going)]);
    }
}

impl ToPod for ArgsRead {
    fn to_pod(&self) -> Pod {
        Pod::record("ArgsRead", vec![("args", self.args.to_pod()), ("rest", self.rest.to_pod()), ("p", self.p_.to_pod()), ("going", self.going.to_pod())])
    }
}

impl FromPod for ArgsRead {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ArgsRead { args: FromPod::from_pod(field(p, "args")?)?, rest: FromPod::from_pod(field(p, "rest")?)?, p_: FromPod::from_pod(field(p, "p")?)?, going: FromPod::from_pod(field(p, "going")?)? })
    }
}

/// `Climb`:
///
/// ```prism
/// type Climb = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Climb {
    pub lhs: crate::syntax::Expr,
    pub p_: crate::syntax::parser::Ps,
    pub going: bool,
}

impl Show for Climb {
    fn show(&self, p: &mut Printer) {
        p.record("Climb", &[("lhs", &self.lhs), ("p", &self.p_), ("going", &self.going)]);
    }
}

impl ToPod for Climb {
    fn to_pod(&self) -> Pod {
        Pod::record("Climb", vec![("lhs", self.lhs.to_pod()), ("p", self.p_.to_pod()), ("going", self.going.to_pod())])
    }
}

impl FromPod for Climb {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Climb { lhs: FromPod::from_pod(field(p, "lhs")?)?, p_: FromPod::from_pod(field(p, "p")?)?, going: FromPod::from_pod(field(p, "going")?)? })
    }
}

/// ```prism
/// ParseExpr: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_expr(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    parse_expr_ctx(p_p0, &true)
}

/// The step machine of `ParseExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseExpr: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseExpr {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseExpr {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        prism_rtl::Turn::More(Rc::new(ParseExprCtx { p_p0: p_p0.clone(), commas_p1: true }))
    }
}

/// `Start ParseExpr, x`: what the function value is when passed to `@Run`.
pub fn start_parse_expr(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(ParseExpr { p_p0 })
}

/// ```prism
/// ParseArgExpr: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_arg_expr(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    parse_expr_ctx(p_p0, &false)
}

/// The step machine of `ParseArgExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseArgExpr: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseArgExpr {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseArgExpr {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        prism_rtl::Turn::More(Rc::new(ParseExprCtx { p_p0: p_p0.clone(), commas_p1: false }))
    }
}

/// `Start ParseArgExpr, x`: what the function value is when passed to `@Run`.
pub fn start_parse_arg_expr(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(ParseArgExpr { p_p0 })
}

/// ```prism
/// ParseExprCtx: unbounded fn Ps, Bool -> ((Expr, Ps))
/// ```
pub fn parse_expr_ctx(p_p0: &crate::syntax::parser::Ps, commas_p1: &bool) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    parse_binary(p_p0, &Nat::from(4u32), &(*commas_p1 && !p_p0.step_mode))
}

/// The step machine of `ParseExprCtx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseExprCtx: unbounded fn Ps, Bool -> ((Expr, Ps))
/// ```
pub struct ParseExprCtx {
    pub p_p0: crate::syntax::parser::Ps,
    pub commas_p1: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseExprCtx {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let commas_p1 = &self.commas_p1;
        prism_rtl::Turn::More(Rc::new(ParseBinary { p0_p0: p_p0.clone(), min_p1: Nat::from(4u32), commas_p2: *commas_p1 && !p_p0.step_mode }))
    }
}

/// `Start ParseExprCtx, x`: what the function value is when passed to `@Run`.
pub fn start_parse_expr_ctx(p_p0: crate::syntax::parser::Ps, commas_p1: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(ParseExprCtx { p_p0, commas_p1 })
}

/// ```prism
/// ParseRhsExpr: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_rhs_expr(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let mut this: (crate::syntax::Expr, crate::syntax::parser::Ps) = parse_expr(p0_p0);
    let (e0_p1, p1_p2) = this.clone();
    let mut e_p3: crate::syntax::Expr = e0_p1.clone();
    let mut p_p4: crate::syntax::parser::Ps = p1_p2.clone();
    while at_line_method(&p_p4) {
        let (method_p5, p2_p6) = crate::syntax::parser::parse_sname(&crate::syntax::parser::adv(&p_p4));
        let (args_p7, p3_p8) = if arg_starts_here(&p2_p6) {
            parse_call_args(&p2_p6, &true)
        } else {
            (Array::new(), p2_p6.clone())
        };
        e_p3 = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMethod(Rc::new(e_p3.clone()), method_p5.clone(), args_p7.clone())), span: crate::syntax::parser::to(&e_p3.span, &crate::syntax::parser::prev(&p3_p8)) };
        p_p4 = p3_p8.clone();
    }
    this = (e_p3.clone(), p_p4.clone());
    this
}

/// The step machine of `ParseRhsExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseRhsExpr: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseRhsExpr {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseRhsExpr {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let mut this: (crate::syntax::Expr, crate::syntax::parser::Ps) = parse_expr(p0_p0);
        let (e0_p1, p1_p2) = this.clone();
        let mut e_p3: crate::syntax::Expr = e0_p1.clone();
        let mut p_p4: crate::syntax::parser::Ps = p1_p2.clone();
        call_then(loop_job((this, e_p3, p_p4), move |(mut this, mut e_p3, mut p_p4): ((crate::syntax::Expr, crate::syntax::parser::Ps), crate::syntax::Expr, crate::syntax::parser::Ps)| if at_line_method(&p_p4) {
            {
                let (method_p5, p2_p6) = crate::syntax::parser::parse_sname(&crate::syntax::parser::adv(&p_p4));
                let (args_p7, p3_p8) = if arg_starts_here(&p2_p6) {
                    parse_call_args(&p2_p6, &true)
                } else {
                    (Array::new(), p2_p6.clone())
                };
                e_p3 = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMethod(Rc::new(e_p3.clone()), method_p5.clone(), args_p7.clone())), span: crate::syntax::parser::to(&e_p3.span, &crate::syntax::parser::prev(&p3_p8)) };
                p_p4 = p3_p8.clone();
                Ok((this, e_p3, p_p4))
            }
        } else {
            Err((this, e_p3, p_p4))
        }), move |(mut this, mut e_p3, mut p_p4): ((crate::syntax::Expr, crate::syntax::parser::Ps), crate::syntax::Expr, crate::syntax::parser::Ps)| {
            this = (e_p3.clone(), p_p4.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start ParseRhsExpr, x`: what the function value is when passed to `@Run`.
pub fn start_parse_rhs_expr(p0_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(ParseRhsExpr { p0_p0 })
}

/// ```prism
/// AtLineMethod: fn Ps -> Bool
/// ```
pub fn at_line_method(p_p0: &crate::syntax::parser::Ps) -> bool {
    ((&crate::syntax::parser::kind(p_p0) == &crate::syntax::lexer::TokKind::KDot(true)) && crate::syntax::parser::tk(p_p0).line_start) && is_plain_upper(&crate::syntax::parser::kind_at(p_p0, &Nat::from(1u32)))
}

/// ```prism
/// IsPlainUpper: fn TokKind -> Bool
/// ```
pub fn is_plain_upper(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KName(n_p0) => (&n_p0.case == &crate::syntax::lexer::NameCase::CaseUpper) && (&n_p0.sigils == &Text::lit("")),
        _ => false,
    }
}

/// ```prism
/// IsUpperTok: fn TokKind -> Bool
/// ```
pub fn is_upper_tok(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KName(n_p0) => &n_p0.case == &crate::syntax::lexer::NameCase::CaseUpper,
        _ => false,
    }
}

/// ```prism
/// ?PeekBinop: fn Ps -> ?((Text, ?[Text]))
/// ```
pub fn peek_binop(p_p0: &crate::syntax::parser::Ps) -> Option<(Text, Option<Array<Text>>)> {
    match crate::syntax::parser::kind(p_p0) {
        crate::syntax::lexer::TokKind::KOp(op_p1, prefix_p2) if (!prefix_p2 || (&op_p1 == &Text::lit("-?"))) => if is_binop(&op_p1) { Some((op_p1.clone(), None)) } else { None },
        crate::syntax::lexer::TokKind::KSuffixed(op_p3, ty_p4) => if is_binop(&op_p3) { Some((op_p3.clone(), Some(ty_p4))) } else { None },
        crate::syntax::lexer::TokKind::KKw(m2766_2_0, m2766_2_1) if (&m2766_2_0 == &Text::lit("on")) && (&m2766_2_1 == &Text::lit("")) => Some((Text::lit("on"), None)),
        crate::syntax::lexer::TokKind::KKw(m2766_3_0, m2766_3_1) if (&m2766_3_0 == &Text::lit("or")) && (&m2766_3_1 == &Text::lit("")) => Some((Text::lit("or"), None)),
        crate::syntax::lexer::TokKind::KKw(m2766_4_0, m2766_4_1) if (&m2766_4_0 == &Text::lit("and")) && (&m2766_4_1 == &Text::lit("")) => Some((Text::lit("and"), None)),
        crate::syntax::lexer::TokKind::KKw(m2766_5_0, m2766_5_1) if (&m2766_5_0 == &Text::lit("mod")) && (&m2766_5_1 == &Text::lit("")) => Some((Text::lit("mod"), None)),
        _ => None,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IsBinop: fn Text -> Bool
/// ```
pub fn is_binop(op_p0: &Text) -> bool {
    fold(&Array::from(vec![Text::lit("<|"), Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit("<="), Text::lit(">"), Text::lit(">="), Text::lit("+"), Text::lit("-"), Text::lit("+?"), Text::lit("-?"), Text::lit("*"), Text::lit("/"), Text::lit("*?")]), &false, &(|seen_p1: &bool, o_p2: &Text| *seen_p1 || (o_p2 == op_p0)))
}

/// ```prism
/// Level: fn Text -> Nat
/// ```
pub fn level(text0: &Text) -> Nat {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("<|")) => Nat::from(4u32),
        c1_0 if (c1_0 == &Text::lit("on")) => Nat::from(5u32),
        c2_0 if (c2_0 == &Text::lit("or")) => Nat::from(6u32),
        c3_0 if (c3_0 == &Text::lit("and")) => Nat::from(7u32),
        c4_0 if (c4_0 == &Text::lit("+")) => Nat::from(10u32),
        c5_0 if (c5_0 == &Text::lit("-")) => Nat::from(10u32),
        c6_0 if (c6_0 == &Text::lit("+?")) => Nat::from(10u32),
        c7_0 if (c7_0 == &Text::lit("-?")) => Nat::from(10u32),
        c8_0 if (c8_0 == &Text::lit("*")) => Nat::from(11u32),
        c9_0 if (c9_0 == &Text::lit("/")) => Nat::from(11u32),
        c10_0 if (c10_0 == &Text::lit("*?")) => Nat::from(11u32),
        c11_0 if (c11_0 == &Text::lit("mod")) => Nat::from(11u32),
        _ => Nat::from(9u32),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParseBinary: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
/// ```
pub fn parse_binary(p0_p0: &crate::syntax::parser::Ps, min_p1: &Nat, commas_p2: &bool) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let (lhs_p4, p1_p5) = parse_prefix(p0_p0, min_p1, commas_p2);
    let r_p3 = {
        let mut this: Climb = Climb { lhs: lhs_p4.clone(), p_: p1_p5.clone(), going: true };
        while this.going && !this.p_.bad {
            this = climb_step(&this, min_p1, commas_p2);
        }
        this
    };
    (r_p3.lhs.clone(), r_p3.p_.clone())
}

/// The step machine of `ParseBinary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseBinary: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
/// ```
pub struct ParseBinary {
    pub p0_p0: crate::syntax::parser::Ps,
    pub min_p1: Nat,
    pub commas_p2: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseBinary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let min_p1 = &self.min_p1;
        let commas_p2 = &self.commas_p2;
        let commas_p2 = *commas_p2;
        let min_p1 = min_p1.clone();
        let p0_p0 = p0_p0.clone();
        call_then(start_parse_prefix(p0_p0.clone(), min_p1.clone(), commas_p2), move |parse_prefix_4034: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
            let (lhs_p4, p1_p5) = parse_prefix_4034;
            let mut this: Climb = Climb { lhs: lhs_p4.clone(), p_: p1_p5.clone(), going: true };
            let lhs_p4 = lhs_p4.clone();
            call_then(loop_job((this,), {
                let commas_p2 = commas_p2;
                let min_p1 = min_p1.clone();
                move |(mut this,): (Climb,)| if this.going && !this.p_.bad {
                    {
                        this = climb_step(&this, &min_p1, &commas_p2);
                        Ok((this,))
                    }
                } else {
                    Err((this,))
                }
            }), move |(mut this,): (Climb,)| {
                let r_p3 = this;
                prism_rtl::Turn::Finished((r_p3.lhs.clone(), r_p3.p_.clone()))
            })
        })
    }
}

/// `Start ParseBinary, x`: what the function value is when passed to `@Run`.
pub fn start_parse_binary(p0_p0: crate::syntax::parser::Ps, min_p1: Nat, commas_p2: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(ParseBinary { p0_p0, min_p1, commas_p2 })
}

/// ```prism
/// ClimbStep: unbounded fn Climb, Nat, Bool -> Climb
/// ```
pub fn climb_step(c_p0: &Climb, min_p1: &Nat, commas_p2: &bool) -> Climb {
    let p_p3 = c_p0.p_.clone();
    if crate::syntax::parser::at_kw(&p_p3, &Text::lit("as")) && (min_p1 <= &Nat::from(12u32)) {
        {
            let (ty_p6, p2_p7) = crate::syntax::parser::types::parse_type(&crate::syntax::parser::adv(&p_p3));
            let checked_p4 = (&crate::syntax::parser::kind(&p2_p7) == &crate::syntax::lexer::TokKind::KFree(Text::lit("?"))) && crate::syntax::parser::tk(&p2_p7).touches;
            let p3_p5 = if checked_p4 { crate::syntax::parser::adv(&p2_p7) } else { p2_p7.clone() };
            {
                let mut this: Climb = c_p0.clone();
                this.lhs = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECast(Rc::new(this.lhs.clone()), ty_p6.clone(), checked_p4)), span: crate::syntax::parser::to(&this.lhs.span, &crate::syntax::parser::prev(&p3_p5)) };
                this.p_ = p3_p5.clone();
                this
            }
        }
    } else {
        match peek_binop(&p_p3) {
            None => {
                let mut this: Climb = c_p0.clone();
                this.going = false;
                this.p_ = no_operator(&p_p3);
                this
            },
            Some((op_p8, suffix_o9)) => if &level(&op_p8) < min_p1 {
                {
                    let mut this: Climb = c_p0.clone();
                    this.going = false;
                    this
                }
            } else {
                {
                    let p1_pa = if &crate::syntax::parser::kind(&p_p3) == &crate::syntax::lexer::TokKind::KOp(Text::lit("-?"), true) {
                        crate::syntax::parser::note_error(&p_p3, &crate::syntax::parser::here(&p_p3), &Text::lit("`-?` is the checked subtraction by longest match; to subtract or negate an optional, write `-(?x)`"))
                    } else {
                        p_p3.clone()
                    };
                    let op_tok_pb = crate::syntax::parser::tk(&p1_pa);
                    let (rhs_pf, p2_pg) = parse_binary(&crate::syntax::parser::adv(&p1_pa), &(&level(&op_p8) + &Nat::from(1u32)), commas_p2);
                    let span_pc = crate::syntax::parser::to(&c_p0.lhs.span, &rhs_pf.span);
                    let kind_pd = match &suffix_o9 {
                        None => crate::syntax::ExprKind::EBinary(op_p8.clone(), Rc::new(c_p0.lhs.clone()), Rc::new(rhs_pf.clone())),
                        Some(ty_ph) => crate::syntax::ExprKind::ESuffixed(op_p8.clone(), crate::syntax::QualName { path_: ty_ph.clone(), span: op_tok_pb.span.clone() }, Rc::new(c_p0.lhs.clone()), Rc::new(rhs_pf.clone())),
                    };
                    let p3_pe = if &suffix_o9 == &None {
                        p2_pg.clone()
                    } else {
                        crate::syntax::parser::out_of_scope(&p2_pg, &op_tok_pb.span, &Text::lit("suffixed operators"), &Text::from(format!("the suffixed operator `{}` is out of this compiler", &crate::syntax::lexer::corpus::token_text(&op_tok_pb.kind))))
                    };
                    {
                        let mut this: Climb = c_p0.clone();
                        this.lhs = crate::syntax::Expr { kind: Rc::new(kind_pd.clone()), span: span_pc.clone() };
                        this.p_ = p3_pe.clone();
                        this
                    }
                }
            },
        }
    }
}

/// The step machine of `ClimbStep`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClimbStep: unbounded fn Climb, Nat, Bool -> Climb
/// ```
pub struct ClimbStep {
    pub c_p0: Climb,
    pub min_p1: Nat,
    pub commas_p2: bool,
}

impl prism_rtl::Job<Climb> for ClimbStep {
    fn cycle(&self) -> prism_rtl::Turn<Climb> {
        let c_p0 = &self.c_p0;
        let min_p1 = &self.min_p1;
        let commas_p2 = &self.commas_p2;
        let p_p3 = c_p0.p_.clone();
        if crate::syntax::parser::at_kw(&p_p3, &Text::lit("as")) && (min_p1 <= &Nat::from(12u32)) {
            {
                let c_p0 = c_p0.clone();
                call_then(crate::syntax::parser::types::start_parse_type(crate::syntax::parser::adv(&p_p3)), move |parse_type_4430: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (ty_p6, p2_p7) = parse_type_4430;
                    let checked_p4 = (&crate::syntax::parser::kind(&p2_p7) == &crate::syntax::lexer::TokKind::KFree(Text::lit("?"))) && crate::syntax::parser::tk(&p2_p7).touches;
                    let p3_p5 = if checked_p4 { crate::syntax::parser::adv(&p2_p7) } else { p2_p7.clone() };
                    prism_rtl::Turn::Finished({
                        let mut this: Climb = c_p0.clone();
                        this.lhs = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECast(Rc::new(this.lhs.clone()), ty_p6.clone(), checked_p4)), span: crate::syntax::parser::to(&this.lhs.span, &crate::syntax::parser::prev(&p3_p5)) };
                        this.p_ = p3_p5.clone();
                        this
                    })
                })
            }
        } else {
            match peek_binop(&p_p3) {
                None => prism_rtl::Turn::Finished({
                    let mut this: Climb = c_p0.clone();
                    this.going = false;
                    this.p_ = no_operator(&p_p3);
                    this
                }),
                Some((op_p8, suffix_o9)) => if &level(&op_p8) < min_p1 {
                    prism_rtl::Turn::Finished({
                        let mut this: Climb = c_p0.clone();
                        this.going = false;
                        this
                    })
                } else {
                    {
                        let p1_pa = if &crate::syntax::parser::kind(&p_p3) == &crate::syntax::lexer::TokKind::KOp(Text::lit("-?"), true) {
                            crate::syntax::parser::note_error(&p_p3, &crate::syntax::parser::here(&p_p3), &Text::lit("`-?` is the checked subtraction by longest match; to subtract or negate an optional, write `-(?x)`"))
                        } else {
                            p_p3.clone()
                        };
                        let op_tok_pb = crate::syntax::parser::tk(&p1_pa);
                        let c_p0 = c_p0.clone();
                        let commas_p2 = *commas_p2;
                        call_then(start_parse_binary(crate::syntax::parser::adv(&p1_pa), &level(&op_p8) + &Nat::from(1u32), commas_p2), move |parse_binary_5342: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                            let (rhs_pf, p2_pg) = parse_binary_5342;
                            let span_pc = crate::syntax::parser::to(&c_p0.lhs.span, &rhs_pf.span);
                            let kind_pd = match &suffix_o9 {
                                None => crate::syntax::ExprKind::EBinary(op_p8.clone(), Rc::new(c_p0.lhs.clone()), Rc::new(rhs_pf.clone())),
                                Some(ty_ph) => crate::syntax::ExprKind::ESuffixed(op_p8.clone(), crate::syntax::QualName { path_: ty_ph.clone(), span: op_tok_pb.span.clone() }, Rc::new(c_p0.lhs.clone()), Rc::new(rhs_pf.clone())),
                            };
                            let p3_pe = if &suffix_o9 == &None {
                                p2_pg.clone()
                            } else {
                                crate::syntax::parser::out_of_scope(&p2_pg, &op_tok_pb.span, &Text::lit("suffixed operators"), &Text::from(format!("the suffixed operator `{}` is out of this compiler", &crate::syntax::lexer::corpus::token_text(&op_tok_pb.kind))))
                            };
                            prism_rtl::Turn::Finished({
                                let mut this: Climb = c_p0.clone();
                                this.lhs = crate::syntax::Expr { kind: Rc::new(kind_pd.clone()), span: span_pc.clone() };
                                this.p_ = p3_pe.clone();
                                this
                            })
                        })
                    }
                },
            }
        }
    }
}

/// `Start ClimbStep, x`: what the function value is when passed to `@Run`.
pub fn start_climb_step(c_p0: Climb, min_p1: Nat, commas_p2: bool) -> Rc<dyn prism_rtl::Job<Climb>> {
    Rc::new(ClimbStep { c_p0, min_p1, commas_p2 })
}

/// ```prism
/// NoOperator: fn Ps -> Ps
/// ```
pub fn no_operator(p_p0: &crate::syntax::parser::Ps) -> crate::syntax::parser::Ps {
    match crate::syntax::parser::kind(p_p0) {
        crate::syntax::lexer::TokKind::KOp(o_p1, true) if (((&o_p1 == &Text::lit("-")) || (&o_p1 == &Text::lit("+"))) && !crate::syntax::parser::tk(p_p0).line_start) => crate::syntax::parser::error_at(p_p0, &crate::syntax::parser::here(p_p0), &Text::from(format!("`{}` here is a prefix sign by the spacing rule (a space before it and none after); did you mean `a {} 1`, with spaces on both sides?", &o_p1, &o_p1))),
        crate::syntax::lexer::TokKind::KBar => crate::syntax::parser::error_at(p_p0, &crate::syntax::parser::here(p_p0), &Text::lit("a bare `|` is not an operator: the merge is `<|`, and `|` separates the families of a row")),
        crate::syntax::lexer::TokKind::KDot(true) if (!at_line_method(p_p0) && is_upper_tok(&crate::syntax::parser::kind_at(p_p0, &Nat::from(1u32)))) => crate::syntax::parser::error_at(p_p0, &crate::syntax::parser::here(p_p0), &Text::lit("a spaced `.Method` begins its own line, below the call it takes as its receiver (layout rule 9)")),
        _ => p_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParsePrefix: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
/// ```
pub fn parse_prefix(p_p0: &crate::syntax::parser::Ps, min_p1: &Nat, commas_p2: &bool) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let start_p3 = crate::syntax::parser::here(p_p0);
    if crate::syntax::parser::at_kw(p_p0, &Text::lit("not")) {
        {
            let (operand_p4, q_p5) = parse_binary(&crate::syntax::parser::adv(p_p0), &max(&Nat::from(9u32), min_p1), commas_p2);
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EUnary(Text::lit("not"), Rc::new(operand_p4.clone()))), span: crate::syntax::parser::to(&start_p3, &operand_p4.span) }, q_p5.clone())
        }
    } else {
        match crate::syntax::parser::kind(p_p0) {
            crate::syntax::lexer::TokKind::KOp(op_p6, true) if ((&op_p6 == &Text::lit("-")) || (&op_p6 == &Text::lit("+"))) => {
                let (operand_p8, q_p9) = parse_postfix_expr(&crate::syntax::parser::adv(p_p0), commas_p2);
                let name_p7 = if &op_p6 == &Text::lit("-") { Text::lit("neg") } else { Text::lit("pos") };
                (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EUnary(name_p7.clone(), Rc::new(operand_p8.clone()))), span: crate::syntax::parser::to(&start_p3, &operand_p8.span) }, q_p9.clone())
            },
            crate::syntax::lexer::TokKind::KOp(m7135_1_0, _) if (&m7135_1_0 == &Text::lit("-?")) => (crate::syntax::parser::decls::no_expr(), crate::syntax::parser::error_at(p_p0, &crate::syntax::parser::here(p_p0), &Text::lit("`-?` is the checked subtraction and needs a left operand; to negate an optional write `-(?x)`"))),
            _ => parse_postfix_expr(p_p0, commas_p2),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// The step machine of `ParsePrefix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParsePrefix: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
/// ```
pub struct ParsePrefix {
    pub p_p0: crate::syntax::parser::Ps,
    pub min_p1: Nat,
    pub commas_p2: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParsePrefix {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let min_p1 = &self.min_p1;
        let commas_p2 = &self.commas_p2;
        let start_p3 = crate::syntax::parser::here(p_p0);
        if crate::syntax::parser::at_kw(p_p0, &Text::lit("not")) {
            {
                let commas_p2 = *commas_p2;
                let min_p1 = min_p1.clone();
                let p_p0 = p_p0.clone();
                call_then(start_parse_binary(crate::syntax::parser::adv(&p_p0), max(&Nat::from(9u32), &min_p1), commas_p2), move |parse_binary_7002: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (operand_p4, q_p5) = parse_binary_7002;
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EUnary(Text::lit("not"), Rc::new(operand_p4.clone()))), span: crate::syntax::parser::to(&start_p3, &operand_p4.span) }, q_p5.clone()))
                })
            }
        } else {
            match crate::syntax::parser::kind(p_p0) {
                crate::syntax::lexer::TokKind::KOp(op_p6, true) if ((&op_p6 == &Text::lit("-")) || (&op_p6 == &Text::lit("+"))) => {
                    let commas_p2 = *commas_p2;
                    let p_p0 = p_p0.clone();
                    call_then(start_parse_postfix_expr(crate::syntax::parser::adv(&p_p0), commas_p2), move |parse_postfix_expr_7230: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                        let (operand_p8, q_p9) = parse_postfix_expr_7230;
                        let name_p7 = if &op_p6 == &Text::lit("-") { Text::lit("neg") } else { Text::lit("pos") };
                        prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EUnary(name_p7.clone(), Rc::new(operand_p8.clone()))), span: crate::syntax::parser::to(&start_p3, &operand_p8.span) }, q_p9.clone()))
                    })
                },
                crate::syntax::lexer::TokKind::KOp(m7135_1_0, _) if (&m7135_1_0 == &Text::lit("-?")) => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), crate::syntax::parser::error_at(p_p0, &crate::syntax::parser::here(p_p0), &Text::lit("`-?` is the checked subtraction and needs a left operand; to negate an optional write `-(?x)`")))),
                _ => prism_rtl::Turn::More(Rc::new(ParsePostfixExpr { p_p0: p_p0.clone(), commas_p1: *commas_p2 })),
                _ => unreachable!("no arm matched"),
            }
        }
    }
}

/// `Start ParsePrefix, x`: what the function value is when passed to `@Run`.
pub fn start_parse_prefix(p_p0: crate::syntax::parser::Ps, min_p1: Nat, commas_p2: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(ParsePrefix { p_p0, min_p1, commas_p2 })
}

/// ```prism
/// ParsePostfixExpr: unbounded fn Ps, Bool -> ((Expr, Ps))
/// ```
pub fn parse_postfix_expr(p_p0: &crate::syntax::parser::Ps, commas_p1: &bool) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let (e_p2, took_rest_p3, q_p4) = parse_primary(p_p0, commas_p1);
    if took_rest_p3 {
        (e_p2.clone(), q_p4.clone())
    } else {
        parse_postfix(&e_p2, &q_p4, commas_p1)
    }
}

/// The step machine of `ParsePostfixExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParsePostfixExpr: unbounded fn Ps, Bool -> ((Expr, Ps))
/// ```
pub struct ParsePostfixExpr {
    pub p_p0: crate::syntax::parser::Ps,
    pub commas_p1: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParsePostfixExpr {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let commas_p1 = &self.commas_p1;
        let commas_p1 = *commas_p1;
        let p_p0 = p_p0.clone();
        call_then(start_parse_primary(p_p0.clone(), commas_p1), move |parse_primary_7837: (crate::syntax::Expr, bool, crate::syntax::parser::Ps)| {
            let (e_p2, took_rest_p3, q_p4) = parse_primary_7837;
            if took_rest_p3 {
                prism_rtl::Turn::Finished((e_p2.clone(), q_p4.clone()))
            } else {
                prism_rtl::Turn::More(Rc::new(ParsePostfix { e0_p0: e_p2.clone(), p0_p1: q_p4.clone(), commas_p2: commas_p1 }))
            }
        })
    }
}

/// `Start ParsePostfixExpr, x`: what the function value is when passed to `@Run`.
pub fn start_parse_postfix_expr(p_p0: crate::syntax::parser::Ps, commas_p1: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(ParsePostfixExpr { p_p0, commas_p1 })
}

/// ```prism
/// ParsePostfix: unbounded fn Expr, Ps, Bool -> ((Expr, Ps))
/// ```
pub fn parse_postfix(e0_p0: &crate::syntax::Expr, p0_p1: &crate::syntax::parser::Ps, commas_p2: &bool) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let mut this: (crate::syntax::Expr, crate::syntax::parser::Ps) = (e0_p0.clone(), p0_p1.clone());
    let mut e_p3: crate::syntax::Expr = e0_p0.clone();
    let mut p_p4: crate::syntax::parser::Ps = p0_p1.clone();
    let mut going_p5: bool = true;
    while going_p5 && !p_p4.bad {
        let (e2_p6, p2_p7, more_p8) = postfix_step(&e_p3, &p_p4, commas_p2);
        e_p3 = e2_p6.clone();
        p_p4 = p2_p7.clone();
        going_p5 = more_p8;
    }
    this = (e_p3.clone(), p_p4.clone());
    this
}

/// The step machine of `ParsePostfix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParsePostfix: unbounded fn Expr, Ps, Bool -> ((Expr, Ps))
/// ```
pub struct ParsePostfix {
    pub e0_p0: crate::syntax::Expr,
    pub p0_p1: crate::syntax::parser::Ps,
    pub commas_p2: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParsePostfix {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let e0_p0 = &self.e0_p0;
        let p0_p1 = &self.p0_p1;
        let commas_p2 = &self.commas_p2;
        let mut this: (crate::syntax::Expr, crate::syntax::parser::Ps) = (e0_p0.clone(), p0_p1.clone());
        let mut e_p3: crate::syntax::Expr = e0_p0.clone();
        let mut p_p4: crate::syntax::parser::Ps = p0_p1.clone();
        let mut going_p5: bool = true;
        call_then(loop_job((this, e_p3, going_p5, p_p4), {
            let commas_p2 = *commas_p2;
            move |(mut this, mut e_p3, mut going_p5, mut p_p4): ((crate::syntax::Expr, crate::syntax::parser::Ps), crate::syntax::Expr, bool, crate::syntax::parser::Ps)| if going_p5 && !p_p4.bad {
                {
                    let (e2_p6, p2_p7, more_p8) = postfix_step(&e_p3, &p_p4, &commas_p2);
                    e_p3 = e2_p6.clone();
                    p_p4 = p2_p7.clone();
                    going_p5 = more_p8;
                    Ok((this, e_p3, going_p5, p_p4))
                }
            } else {
                Err((this, e_p3, going_p5, p_p4))
            }
        }), move |(mut this, mut e_p3, mut going_p5, mut p_p4): ((crate::syntax::Expr, crate::syntax::parser::Ps), crate::syntax::Expr, bool, crate::syntax::parser::Ps)| {
            this = (e_p3.clone(), p_p4.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start ParsePostfix, x`: what the function value is when passed to `@Run`.
pub fn start_parse_postfix(e0_p0: crate::syntax::Expr, p0_p1: crate::syntax::parser::Ps, commas_p2: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(ParsePostfix { e0_p0, p0_p1, commas_p2 })
}

/// ```prism
/// PostfixStep: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
/// ```
pub fn postfix_step(e_p0: &crate::syntax::Expr, p_p1: &crate::syntax::parser::Ps, commas_p2: &bool) -> (crate::syntax::Expr, crate::syntax::parser::Ps, bool) {
    match crate::syntax::parser::kind(p_p1) {
        crate::syntax::lexer::TokKind::KDot(false) => field_or_method(e_p0, p_p1, commas_p2),
        crate::syntax::lexer::TokKind::KOpen(m8467_1_0, false) if (&m8467_1_0 == &Text::lit("[")) && (crate::syntax::parser::tk(p_p1).touches && !crate::syntax::parser::at_double_open(p_p1, &Text::lit("["))) => {
            let (index_p4, p1_p5) = crate::syntax::parser::bracketed(&crate::syntax::parser::adv(p_p1), &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_expr(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>));
            let p2_p3 = crate::syntax::parser::expect_close(&p1_p5, &Text::lit("["));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EIndex(Rc::new(e_p0.clone()), Rc::new(index_p4.clone()))), span: crate::syntax::parser::to(&e_p0.span, &crate::syntax::parser::prev(&p2_p3)) }, p2_p3.clone(), true)
        },
        crate::syntax::lexer::TokKind::KLtLt => {
            let (types_p6, q_p7) = parse_type_args(p_p1);
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETypeArgs(Rc::new(e_p0.clone()), types_p6.clone())), span: crate::syntax::parser::to(&e_p0.span, &crate::syntax::parser::prev(&q_p7)) }, q_p7.clone(), true)
        },
        crate::syntax::lexer::TokKind::KNonEmpty => {
            let span_p8 = crate::syntax::parser::here(p_p1);
            let q_p9 = crate::syntax::parser::out_of_scope(&crate::syntax::parser::adv(p_p1), &span_p8, &Text::lit("non-empty arrays"), &Text::lit("the non-empty mark `+` is out of this compiler"));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ENonEmpty(Rc::new(e_p0.clone()))), span: crate::syntax::parser::to(&e_p0.span, &span_p8) }, q_p9.clone(), true)
        },
        _ => (e_p0.clone(), p_p1.clone(), false),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `PostfixStep`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PostfixStep: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
/// ```
pub struct PostfixStep {
    pub e_p0: crate::syntax::Expr,
    pub p_p1: crate::syntax::parser::Ps,
    pub commas_p2: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps, bool)> for PostfixStep {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps, bool)> {
        let e_p0 = &self.e_p0;
        let p_p1 = &self.p_p1;
        let commas_p2 = &self.commas_p2;
        match crate::syntax::parser::kind(p_p1) {
            crate::syntax::lexer::TokKind::KDot(false) => prism_rtl::Turn::More(Rc::new(FieldOrMethod { e_p0: e_p0.clone(), p0_p1: p_p1.clone(), commas_p2: *commas_p2 })),
            crate::syntax::lexer::TokKind::KOpen(m8467_1_0, false) if (&m8467_1_0 == &Text::lit("[")) && (crate::syntax::parser::tk(p_p1).touches && !crate::syntax::parser::at_double_open(p_p1, &Text::lit("["))) => {
                let e_p0 = e_p0.clone();
                let p_p1 = p_p1.clone();
                call_then(crate::syntax::parser::start_bracketed(crate::syntax::parser::adv(&p_p1), Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_expr(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>), move |bracketed_8622: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (index_p4, p1_p5) = bracketed_8622;
                    let p2_p3 = crate::syntax::parser::expect_close(&p1_p5, &Text::lit("["));
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EIndex(Rc::new(e_p0.clone()), Rc::new(index_p4.clone()))), span: crate::syntax::parser::to(&e_p0.span, &crate::syntax::parser::prev(&p2_p3)) }, p2_p3.clone(), true))
                })
            },
            crate::syntax::lexer::TokKind::KLtLt => {
                let e_p0 = e_p0.clone();
                let p_p1 = p_p1.clone();
                call_then(start_parse_type_args(p_p1.clone()), move |parse_type_args_8806: (Array<crate::syntax::Type>, crate::syntax::parser::Ps)| {
                    let (types_p6, q_p7) = parse_type_args_8806;
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETypeArgs(Rc::new(e_p0.clone()), types_p6.clone())), span: crate::syntax::parser::to(&e_p0.span, &crate::syntax::parser::prev(&q_p7)) }, q_p7.clone(), true))
                })
            },
            crate::syntax::lexer::TokKind::KNonEmpty => {
                let span_p8 = crate::syntax::parser::here(p_p1);
                let q_p9 = crate::syntax::parser::out_of_scope(&crate::syntax::parser::adv(p_p1), &span_p8, &Text::lit("non-empty arrays"), &Text::lit("the non-empty mark `+` is out of this compiler"));
                prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ENonEmpty(Rc::new(e_p0.clone()))), span: crate::syntax::parser::to(&e_p0.span, &span_p8) }, q_p9.clone(), true))
            },
            _ => prism_rtl::Turn::Finished((e_p0.clone(), p_p1.clone(), false)),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start PostfixStep, x`: what the function value is when passed to `@Run`.
pub fn start_postfix_step(e_p0: crate::syntax::Expr, p_p1: crate::syntax::parser::Ps, commas_p2: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps, bool)>> {
    Rc::new(PostfixStep { e_p0, p_p1, commas_p2 })
}

/// ```prism
/// FieldOrMethod: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
/// ```
pub fn field_or_method(e_p0: &crate::syntax::Expr, p0_p1: &crate::syntax::parser::Ps, commas_p2: &bool) -> (crate::syntax::Expr, crate::syntax::parser::Ps, bool) {
    let dot_p3 = crate::syntax::parser::here(p0_p1);
    let p_p4 = crate::syntax::parser::adv(p0_p1);
    match crate::syntax::parser::kind(&p_p4) {
        crate::syntax::lexer::TokKind::KName(n_p5) if ((&len(&n_p5.path_) == &Nat::from(1u32)) && ((&n_p5.case == &crate::syntax::lexer::NameCase::CaseLower) || (&n_p5.case == &crate::syntax::lexer::NameCase::CaseTopic))) => {
            let t_p6 = crate::syntax::parser::here(&p_p4);
            let field_p7 = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EField(Rc::new(e_p0.clone()), n_p5.sigils.clone(), crate::syntax::Ident { name: or(&index(&n_p5.path_, &Nat::from(0u32)), &Text::lit("")), span: t_p6.clone() })), span: crate::syntax::parser::to(&e_p0.span, &t_p6) };
            let p1_p8 = crate::syntax::parser::adv(&p_p4);
            if arg_starts_here(&p1_p8) && !crate::syntax::parser::tk(&p1_p8).line_start {
                {
                    let (args_p9, p2_pa) = parse_call_args(&p1_p8, commas_p2);
                    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECall(Rc::new(field_p7.clone()), args_p9.clone(), false, false)), span: crate::syntax::parser::to(&field_p7.span, &crate::syntax::parser::prev(&p2_pa)) }, p2_pa.clone(), false)
                }
            } else {
                (field_p7.clone(), p1_p8.clone(), true)
            }
        },
        crate::syntax::lexer::TokKind::KKw(w_pb, m9299_1_1) if (&m9299_1_1 == &Text::lit("")) && crate::syntax::lexer::is_bound_word(&w_pb) => {
            let t_pc = crate::syntax::parser::here(&p_p4);
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EField(Rc::new(e_p0.clone()), Text::lit(""), crate::syntax::Ident { name: w_pb.clone(), span: t_pc.clone() })), span: crate::syntax::parser::to(&e_p0.span, &t_pc) }, crate::syntax::parser::adv(&p_p4), true)
        },
        crate::syntax::lexer::TokKind::KName(n_pd) if ((&n_pd.case == &crate::syntax::lexer::NameCase::CaseUpper) || (&n_pd.case == &crate::syntax::lexer::NameCase::CaseReserved)) => {
            let (method_pe, p1_pf) = crate::syntax::parser::parse_sname(&p_p4);
            let (args_pg, p2_ph) = if arg_starts_here(&p1_pf) {
                parse_call_args(&p1_pf, commas_p2)
            } else {
                (Array::new(), p1_pf.clone())
            };
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMethod(Rc::new(e_p0.clone()), method_pe.clone(), args_pg.clone())), span: crate::syntax::parser::to(&e_p0.span, &crate::syntax::parser::prev(&p2_ph)) }, p2_ph.clone(), false)
        },
        _ => (e_p0.clone(), crate::syntax::parser::error_at(&p_p4, &dot_p3, &Text::lit("expected a field name or a `.Method` after `.`")), false),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `FieldOrMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldOrMethod: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
/// ```
pub struct FieldOrMethod {
    pub e_p0: crate::syntax::Expr,
    pub p0_p1: crate::syntax::parser::Ps,
    pub commas_p2: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps, bool)> for FieldOrMethod {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps, bool)> {
        let e_p0 = &self.e_p0;
        let p0_p1 = &self.p0_p1;
        let commas_p2 = &self.commas_p2;
        let dot_p3 = crate::syntax::parser::here(p0_p1);
        let p_p4 = crate::syntax::parser::adv(p0_p1);
        match crate::syntax::parser::kind(&p_p4) {
            crate::syntax::lexer::TokKind::KName(n_p5) if ((&len(&n_p5.path_) == &Nat::from(1u32)) && ((&n_p5.case == &crate::syntax::lexer::NameCase::CaseLower) || (&n_p5.case == &crate::syntax::lexer::NameCase::CaseTopic))) => {
                let t_p6 = crate::syntax::parser::here(&p_p4);
                let field_p7 = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EField(Rc::new(e_p0.clone()), n_p5.sigils.clone(), crate::syntax::Ident { name: or(&index(&n_p5.path_, &Nat::from(0u32)), &Text::lit("")), span: t_p6.clone() })), span: crate::syntax::parser::to(&e_p0.span, &t_p6) };
                let p1_p8 = crate::syntax::parser::adv(&p_p4);
                if arg_starts_here(&p1_p8) && !crate::syntax::parser::tk(&p1_p8).line_start {
                    {
                        let commas_p2 = *commas_p2;
                        call_then(start_parse_call_args(p1_p8.clone(), commas_p2), move |parse_call_args_9918: (Array<crate::syntax::Arg>, crate::syntax::parser::Ps)| {
                            let (args_p9, p2_pa) = parse_call_args_9918;
                            prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECall(Rc::new(field_p7.clone()), args_p9.clone(), false, false)), span: crate::syntax::parser::to(&field_p7.span, &crate::syntax::parser::prev(&p2_pa)) }, p2_pa.clone(), false))
                        })
                    }
                } else {
                    prism_rtl::Turn::Finished((field_p7.clone(), p1_p8.clone(), true))
                }
            },
            crate::syntax::lexer::TokKind::KKw(w_pb, m9299_1_1) if (&m9299_1_1 == &Text::lit("")) && crate::syntax::lexer::is_bound_word(&w_pb) => {
                let t_pc = crate::syntax::parser::here(&p_p4);
                prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EField(Rc::new(e_p0.clone()), Text::lit(""), crate::syntax::Ident { name: w_pb.clone(), span: t_pc.clone() })), span: crate::syntax::parser::to(&e_p0.span, &t_pc) }, crate::syntax::parser::adv(&p_p4), true))
            },
            crate::syntax::lexer::TokKind::KName(n_pd) if ((&n_pd.case == &crate::syntax::lexer::NameCase::CaseUpper) || (&n_pd.case == &crate::syntax::lexer::NameCase::CaseReserved)) => {
                let (method_pe, p1_pf) = crate::syntax::parser::parse_sname(&p_p4);
                let (args_pg, p2_ph) = if arg_starts_here(&p1_pf) {
                    parse_call_args(&p1_pf, commas_p2)
                } else {
                    (Array::new(), p1_pf.clone())
                };
                prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMethod(Rc::new(e_p0.clone()), method_pe.clone(), args_pg.clone())), span: crate::syntax::parser::to(&e_p0.span, &crate::syntax::parser::prev(&p2_ph)) }, p2_ph.clone(), false))
            },
            _ => prism_rtl::Turn::Finished((e_p0.clone(), crate::syntax::parser::error_at(&p_p4, &dot_p3, &Text::lit("expected a field name or a `.Method` after `.`")), false)),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start FieldOrMethod, x`: what the function value is when passed to `@Run`.
pub fn start_field_or_method(e_p0: crate::syntax::Expr, p0_p1: crate::syntax::parser::Ps, commas_p2: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps, bool)>> {
    Rc::new(FieldOrMethod { e_p0, p0_p1, commas_p2 })
}

/// ```prism
/// ParseTypeArgs: unbounded fn Ps -> (([Type], Ps))
/// ```
pub fn parse_type_args(p_p0: &crate::syntax::parser::Ps) -> (Array<crate::syntax::Type>, crate::syntax::parser::Ps) {
    let (types_p1, q_p2) = crate::syntax::parser::commas(&crate::syntax::parser::adv(p_p0), &(Rc::new(|a0: crate::syntax::parser::Ps| entered(crate::syntax::parser::types::start_parse_type(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>>>));
    if &crate::syntax::parser::kind(&q_p2) == &crate::syntax::lexer::TokKind::KGtGt {
        (types_p1.clone(), crate::syntax::parser::adv(&q_p2))
    } else {
        (types_p1.clone(), crate::syntax::parser::error_here(&q_p2, &Text::lit("expected `>>` to close the type arguments")))
    }
}

/// The step machine of `ParseTypeArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTypeArgs: unbounded fn Ps -> (([Type], Ps))
/// ```
pub struct ParseTypeArgs {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(Array<crate::syntax::Type>, crate::syntax::parser::Ps)> for ParseTypeArgs {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::Type>, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let p_p0 = p_p0.clone();
        call_then(crate::syntax::parser::start_commas(crate::syntax::parser::adv(&p_p0), Rc::new(|a0: crate::syntax::parser::Ps| entered(crate::syntax::parser::types::start_parse_type(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>>>), move |commas_10908: (Array<crate::syntax::Type>, crate::syntax::parser::Ps)| {
            let (types_p1, q_p2) = commas_10908;
            if &crate::syntax::parser::kind(&q_p2) == &crate::syntax::lexer::TokKind::KGtGt {
                prism_rtl::Turn::Finished((types_p1.clone(), crate::syntax::parser::adv(&q_p2)))
            } else {
                prism_rtl::Turn::Finished((types_p1.clone(), crate::syntax::parser::error_here(&q_p2, &Text::lit("expected `>>` to close the type arguments"))))
            }
        })
    }
}

/// `Start ParseTypeArgs, x`: what the function value is when passed to `@Run`.
pub fn start_parse_type_args(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Type>, crate::syntax::parser::Ps)>> {
    Rc::new(ParseTypeArgs { p_p0 })
}

/// ```prism
/// ArgStartsHere: fn Ps -> Bool
/// ```
pub fn arg_starts_here(p_p0: &crate::syntax::parser::Ps) -> bool {
    let t_p1 = crate::syntax::parser::tk(p_p0);
    match &t_p1.kind {
        crate::syntax::lexer::TokKind::KName(_) => true,
        crate::syntax::lexer::TokKind::KInt(_, _) => true,
        crate::syntax::lexer::TokKind::KFloat(_, _) => true,
        crate::syntax::lexer::TokKind::KDuration(_, _, _) => true,
        crate::syntax::lexer::TokKind::KChar(_, _) => true,
        crate::syntax::lexer::TokKind::KText(_, _) => true,
        crate::syntax::lexer::TokKind::KRegex(_, _) => true,
        crate::syntax::lexer::TokKind::KTemplate(_) => true,
        crate::syntax::lexer::TokKind::KFree(_) => true,
        crate::syntax::lexer::TokKind::KLensDot => true,
        crate::syntax::lexer::TokKind::KBackslash => true,
        crate::syntax::lexer::TokKind::KAbsent => true,
        crate::syntax::lexer::TokKind::KOpen(m11225_12_0, prefix_p2) if (m11225_12_0 == &Text::lit("[")) => (*prefix_p2 || !t_p1.touches) || crate::syntax::parser::at_double_open(p_p0, &Text::lit("[")),
        crate::syntax::lexer::TokKind::KOpen(_, _) => true,
        crate::syntax::lexer::TokKind::KOp(op_p3, true) => (op_p3 == &Text::lit("+")) || (op_p3 == &Text::lit("-")),
        crate::syntax::lexer::TokKind::KDot(true) => !at_line_method(p_p0),
        crate::syntax::lexer::TokKind::KKw(w_p4, _) => fold(&arg_words(), &false, &(|seen_p5: &bool, x_p6: &Text| *seen_p5 || (x_p6 == w_p4))),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// let argWords
/// ```
pub fn arg_words() -> Array<Text> {
    Array::from(vec![Text::lit("unit"), Text::lit("nil"), Text::lit("key"), Text::lit("ix"), Text::lit("jx"), Text::lit("kx"), Text::lit("not"), Text::lit("any"), Text::lit("given"), Text::lit("update"), Text::lit("match"), Text::lit("rebuild"), Text::lit("widget"), Text::lit("output"), Text::lit("inline_text"), Text::lit("raw")])
}

/// ```prism
/// ParseCallArgs: unbounded fn Ps, Bool -> (([Arg], Ps))
/// ```
pub fn parse_call_args(p_p0: &crate::syntax::parser::Ps, commas_p1: &bool) -> (Array<crate::syntax::Arg>, crate::syntax::parser::Ps) {
    if *commas_p1 && !p_p0.step_mode {
        crate::syntax::parser::commas(p_p0, &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_arg(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Arg, crate::syntax::parser::Ps)>>>))
    } else {
        parse_one_arg(p_p0)
    }
}

/// The step machine of `ParseCallArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseCallArgs: unbounded fn Ps, Bool -> (([Arg], Ps))
/// ```
pub struct ParseCallArgs {
    pub p_p0: crate::syntax::parser::Ps,
    pub commas_p1: bool,
}

impl prism_rtl::Job<(Array<crate::syntax::Arg>, crate::syntax::parser::Ps)> for ParseCallArgs {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::Arg>, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let commas_p1 = &self.commas_p1;
        if *commas_p1 && !p_p0.step_mode {
            prism_rtl::Turn::More(Rc::new(crate::syntax::parser::Commas { p0_p0: p_p0.clone(), f_f1: Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_arg(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Arg, crate::syntax::parser::Ps)>>> }))
        } else {
            prism_rtl::Turn::More(Rc::new(ParseOneArg { p_p0: p_p0.clone() }))
        }
    }
}

/// `Start ParseCallArgs, x`: what the function value is when passed to `@Run`.
pub fn start_parse_call_args(p_p0: crate::syntax::parser::Ps, commas_p1: bool) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Arg>, crate::syntax::parser::Ps)>> {
    Rc::new(ParseCallArgs { p_p0, commas_p1 })
}

/// ```prism
/// ParseOneArg: unbounded fn Ps -> (([Arg], Ps))
/// ```
pub fn parse_one_arg(p_p0: &crate::syntax::parser::Ps) -> (Array<crate::syntax::Arg>, crate::syntax::parser::Ps) {
    let (a_p1, q_p2) = parse_arg(p_p0);
    (Array::from(vec![a_p1.clone()]), q_p2.clone())
}

/// The step machine of `ParseOneArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseOneArg: unbounded fn Ps -> (([Arg], Ps))
/// ```
pub struct ParseOneArg {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(Array<crate::syntax::Arg>, crate::syntax::parser::Ps)> for ParseOneArg {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::Arg>, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let p_p0 = p_p0.clone();
        call_then(start_parse_arg(p_p0.clone()), move |parse_arg_12477: (crate::syntax::Arg, crate::syntax::parser::Ps)| {
            let (a_p1, q_p2) = parse_arg_12477;
            prism_rtl::Turn::Finished((Array::from(vec![a_p1.clone()]), q_p2.clone()))
        })
    }
}

/// `Start ParseOneArg, x`: what the function value is when passed to `@Run`.
pub fn start_parse_one_arg(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Arg>, crate::syntax::parser::Ps)>> {
    Rc::new(ParseOneArg { p_p0 })
}

/// ```prism
/// ParseArg: unbounded fn Ps -> ((Arg, Ps))
/// ```
pub fn parse_arg(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Arg, crate::syntax::parser::Ps) {
    let (value_p1, q_p2) = parse_arg_expr(p_p0);
    (crate::syntax::Arg { name: None, value: value_p1.clone(), span: value_p1.span.clone() }, q_p2.clone())
}

/// The step machine of `ParseArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseArg: unbounded fn Ps -> ((Arg, Ps))
/// ```
pub struct ParseArg {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Arg, crate::syntax::parser::Ps)> for ParseArg {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Arg, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let p_p0 = p_p0.clone();
        call_then(start_parse_arg_expr(p_p0.clone()), move |parse_arg_expr_12585: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
            let (value_p1, q_p2) = parse_arg_expr_12585;
            prism_rtl::Turn::Finished((crate::syntax::Arg { name: None, value: value_p1.clone(), span: value_p1.span.clone() }, q_p2.clone()))
        })
    }
}

/// `Start ParseArg, x`: what the function value is when passed to `@Run`.
pub fn start_parse_arg(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Arg, crate::syntax::parser::Ps)>> {
    Rc::new(ParseArg { p_p0 })
}

/// ```prism
/// ParseParenArgs: unbounded fn Ps -> (([Arg], Bool, Ps))
/// ```
pub fn parse_paren_args(p0_p0: &crate::syntax::parser::Ps) -> (Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps) {
    let p_p1 = crate::syntax::parser::adv(p0_p0);
    if crate::syntax::parser::at_close(&p_p1, &Text::lit("(")) {
        (Array::new(), false, crate::syntax::parser::adv(&p_p1))
    } else {
        {
            let r_p2 = {
                let mut this: ArgsRead = ArgsRead { args: Array::new(), rest: false, p_: p_p1.clone(), going: true };
                while this.going && !this.p_.bad {
                    if &crate::syntax::parser::kind(&this.p_) == &crate::syntax::lexer::TokKind::KDotDot {
                        this.p_ = crate::syntax::parser::adv(&this.p_);
                        this.rest = true;
                    } else {
                        let start_p3 = crate::syntax::parser::here(&this.p_);
                        let (name_o4, p1_p5) = parse_arg_name(&this.p_);
                        let (value_p6, p2_p7) = parse_arg_expr(&p1_p5);
                        this.args = push(&this.args, &crate::syntax::Arg { name: name_o4.clone(), value: value_p6.clone(), span: crate::syntax::parser::to(&start_p3, &value_p6.span) });
                        this.p_ = p2_p7.clone();
                    }
                    if crate::syntax::parser::at_comma(&this.p_) {
                        this.p_ = crate::syntax::parser::adv(&this.p_);
                    } else {
                        this.p_ = crate::syntax::parser::expect_close(&this.p_, &Text::lit("("));
                        this.going = false;
                    }
                }
                this
            };
            (r_p2.args.clone(), r_p2.rest, r_p2.p_.clone())
        }
    }
}

/// The step machine of `ParseParenArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseParenArgs: unbounded fn Ps -> (([Arg], Bool, Ps))
/// ```
pub struct ParseParenArgs {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps)> for ParseParenArgs {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let p_p1 = crate::syntax::parser::adv(p0_p0);
        if crate::syntax::parser::at_close(&p_p1, &Text::lit("(")) {
            prism_rtl::Turn::Finished((Array::new(), false, crate::syntax::parser::adv(&p_p1)))
        } else {
            {
                let mut this: ArgsRead = ArgsRead { args: Array::new(), rest: false, p_: p_p1.clone(), going: true };
                let p_p1 = p_p1.clone();
                call_then(loop_job((this,), {
                    let p_p1 = p_p1.clone();
                    move |(mut this,): (ArgsRead,)| if this.going && !this.p_.bad {
                        {
                            if &crate::syntax::parser::kind(&this.p_) == &crate::syntax::lexer::TokKind::KDotDot {
                                this.p_ = crate::syntax::parser::adv(&this.p_);
                                this.rest = true;
                            } else {
                                let start_p3 = crate::syntax::parser::here(&this.p_);
                                let (name_o4, p1_p5) = parse_arg_name(&this.p_);
                                let (value_p6, p2_p7) = parse_arg_expr(&p1_p5);
                                this.args = push(&this.args, &crate::syntax::Arg { name: name_o4.clone(), value: value_p6.clone(), span: crate::syntax::parser::to(&start_p3, &value_p6.span) });
                                this.p_ = p2_p7.clone();
                            }
                            if crate::syntax::parser::at_comma(&this.p_) {
                                this.p_ = crate::syntax::parser::adv(&this.p_);
                            } else {
                                this.p_ = crate::syntax::parser::expect_close(&this.p_, &Text::lit("("));
                                this.going = false;
                            }
                            Ok((this,))
                        }
                    } else {
                        Err((this,))
                    }
                }), move |(mut this,): (ArgsRead,)| {
                    let r_p2 = this;
                    prism_rtl::Turn::Finished((r_p2.args.clone(), r_p2.rest, r_p2.p_.clone()))
                })
            }
        }
    }
}

/// `Start ParseParenArgs, x`: what the function value is when passed to `@Run`.
pub fn start_parse_paren_args(p0_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps)>> {
    Rc::new(ParseParenArgs { p0_p0 })
}

/// ```prism
/// ParseArgName: fn Ps -> ((?Ident, Ps))
/// ```
pub fn parse_arg_name(p_p0: &crate::syntax::parser::Ps) -> (Option<crate::syntax::Ident>, crate::syntax::parser::Ps) {
    match crate::syntax::parser::kind(p_p0) {
        crate::syntax::lexer::TokKind::KName(n_p1) if ((((&n_p1.sigils == &Text::lit("")) && (&len(&n_p1.path_) == &Nat::from(1u32))) && (&n_p1.case == &crate::syntax::lexer::NameCase::CaseLower)) && crate::syntax::parser::at_op(&crate::syntax::parser::adv(p_p0), &Text::lit("="))) => (Some(crate::syntax::Ident { name: or(&index(&n_p1.path_, &Nat::from(0u32)), &Text::lit("")), span: crate::syntax::parser::here(p_p0) }), crate::syntax::parser::adv(&crate::syntax::parser::adv(p_p0))),
        _ => (None, p_p0.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParsePrimary: unbounded fn Ps, Bool -> ((Expr, Bool, Ps))
/// ```
pub fn parse_primary(p_p0: &crate::syntax::parser::Ps, commas_p1: &bool) -> (crate::syntax::Expr, bool, crate::syntax::parser::Ps) {
    let start_p2 = crate::syntax::parser::here(p_p0);
    let tok_p3 = crate::syntax::parser::tk(p_p0);
    match &tok_p3.kind {
        crate::syntax::lexer::TokKind::KName(n_p4) => name_primary(p_p0, n_p4, commas_p1),
        crate::syntax::lexer::TokKind::KKw(w_p5, sigils_p6) => keyword_primary(p_p0, w_p5, sigils_p6, commas_p1),
        crate::syntax::lexer::TokKind::KInt(_, _) => literal_primary(p_p0),
        crate::syntax::lexer::TokKind::KFloat(_, _) => literal_primary(p_p0),
        crate::syntax::lexer::TokKind::KDuration(_, _, _) => literal_primary(p_p0),
        crate::syntax::lexer::TokKind::KChar(_, _) => literal_primary(p_p0),
        crate::syntax::lexer::TokKind::KText(_, _) => literal_primary(p_p0),
        crate::syntax::lexer::TokKind::KRegex(_, _) => literal_primary(p_p0),
        crate::syntax::lexer::TokKind::KTemplate(t_p7) => {
            let (tpl_p8, q_p9) = parse_template(&crate::syntax::parser::adv(p_p0), t_p7, &tok_p3.span);
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETemplate(tpl_p8.clone())), span: tok_p3.span.clone() }, false, q_p9.clone())
        },
        crate::syntax::lexer::TokKind::KOpen(m14436_9_0, _) if (m14436_9_0 == &Text::lit("(")) => paren_primary(p_p0),
        crate::syntax::lexer::TokKind::KOpen(m14436_10_0, _) if (m14436_10_0 == &Text::lit("[")) => square_primary(p_p0),
        crate::syntax::lexer::TokKind::KOpen(_, _) => map_primary(p_p0),
        crate::syntax::lexer::TokKind::KDot(true) => {
            let p1_pa = crate::syntax::parser::adv(p_p0);
            match crate::syntax::parser::kind(&p1_pa) {
                crate::syntax::lexer::TokKind::KName(n_pb) if (((&n_pb.sigils == &Text::lit("")) && (&len(&n_pb.path_) == &Nat::from(1u32))) && (&n_pb.case == &crate::syntax::lexer::NameCase::CaseLower)) => {
                    let t_pc = crate::syntax::parser::here(&p1_pa);
                    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETopicField(crate::syntax::Ident { name: or(&index(&n_pb.path_, &Nat::from(0u32)), &Text::lit("")), span: t_pc.clone() })), span: crate::syntax::parser::to(&start_p2, &t_pc) }, false, crate::syntax::parser::adv(&p1_pa))
                },
                crate::syntax::lexer::TokKind::KName(n_pd) if (&n_pd.case == &crate::syntax::lexer::NameCase::CaseUpper) => (crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(&p1_pa, &start_p2, &Text::from(format!("a spaced `.{}` begins its own line, below the call it takes as its receiver (layout rule 9)", &crate::syntax::lexer::chars::join(&n_pd.path_, &Text::lit(".")))))),
                _ => (crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(&p1_pa, &start_p2, &Text::lit("a prefix `.` takes a field name, applied to the topic `_`"))),
                _ => unreachable!("no arm matched"),
            }
        },
        crate::syntax::lexer::TokKind::KLensDot => lens_primary(p_p0),
        crate::syntax::lexer::TokKind::KFree(s_pe) => if s_pe == &Text::lit("!") {
            (crate::syntax::parser::decls::no_expr(), true, crate::syntax::parser::error_at(&crate::syntax::parser::adv(p_p0), &tok_p3.span, &Text::lit("`!` is never free: no event fires a constant")))
        } else {
            if s_pe == &Text::lit("&") {
                (crate::syntax::parser::decls::no_expr(), true, crate::syntax::parser::error_at(&crate::syntax::parser::adv(p_p0), &tok_p3.span, &Text::lit("`&` is never free: no reference exists outside the value an `update` block names")))
            } else {
                {
                    let (operand_pf, q_pg) = parse_expr_ctx(&crate::syntax::parser::adv(p_p0), commas_p1);
                    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EFreeSigil(s_pe.clone(), Rc::new(operand_pf.clone()))), span: crate::syntax::parser::to(&start_p2, &operand_pf.span) }, true, q_pg.clone())
                }
            }
        },
        crate::syntax::lexer::TokKind::KBackslash => {
            let (e_ph, q_pi) = parse_lambda(p_p0);
            (e_ph.clone(), true, q_pi.clone())
        },
        crate::syntax::lexer::TokKind::KAbsent => {
            let q_pj = crate::syntax::parser::out_of_scope(&crate::syntax::parser::adv(p_p0), &tok_p3.span, &Text::lit("sparse tuples"), &Text::lit("an absent component `-` makes a sparse tuple, which is out of this compiler"));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EAbsent), span: tok_p3.span.clone() }, false, q_pj.clone())
        },
        crate::syntax::lexer::TokKind::KDotDot => (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ERest), span: tok_p3.span.clone() }, false, crate::syntax::parser::adv(p_p0)),
        crate::syntax::lexer::TokKind::KTrait(_) => (crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_p0, &tok_p3.span, &Text::lit("no trait is a value: a `^Trait` stands in a type, a bound, `derive`, `trait` or `impl`"))),
        crate::syntax::lexer::TokKind::KFamily(path_pk) => (crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_p0, &tok_p3.span, &Text::from(format!("`{}.*` names every tag of a family: it stands in a pattern, an `emit` row or a `use`, not in an expression", &crate::syntax::lexer::chars::join(path_pk, &Text::lit(".")))))),
        crate::syntax::lexer::TokKind::KBar => (crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_p0, &tok_p3.span, &Text::lit("a bare `|` is not an operator: the merge is `<|`, and `|` separates the families of a row"))),
        _ => (crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_here(p_p0, &Text::lit("expected an expression"))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ParsePrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParsePrimary: unbounded fn Ps, Bool -> ((Expr, Bool, Ps))
/// ```
pub struct ParsePrimary {
    pub p_p0: crate::syntax::parser::Ps,
    pub commas_p1: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> for ParsePrimary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let commas_p1 = &self.commas_p1;
        let start_p2 = crate::syntax::parser::here(p_p0);
        let tok_p3 = crate::syntax::parser::tk(p_p0);
        match &tok_p3.kind {
            crate::syntax::lexer::TokKind::KName(n_p4) => prism_rtl::Turn::More(Rc::new(NamePrimary { p0_p0: p_p0.clone(), n_p1: n_p4.clone(), commas_p2: *commas_p1 })),
            crate::syntax::lexer::TokKind::KKw(w_p5, sigils_p6) => prism_rtl::Turn::More(Rc::new(KeywordPrimary { p_p0: p_p0.clone(), w_p1: w_p5.clone(), sigils_p2: sigils_p6.clone(), commas_p3: *commas_p1 })),
            crate::syntax::lexer::TokKind::KInt(_, _) => prism_rtl::Turn::More(Rc::new(LiteralPrimary { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KFloat(_, _) => prism_rtl::Turn::More(Rc::new(LiteralPrimary { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KDuration(_, _, _) => prism_rtl::Turn::More(Rc::new(LiteralPrimary { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KChar(_, _) => prism_rtl::Turn::More(Rc::new(LiteralPrimary { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KText(_, _) => prism_rtl::Turn::More(Rc::new(LiteralPrimary { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KRegex(_, _) => prism_rtl::Turn::More(Rc::new(LiteralPrimary { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KTemplate(t_p7) => {
                let p_p0 = p_p0.clone();
                let t_p7 = t_p7.clone();
                call_then(start_parse_template(crate::syntax::parser::adv(&p_p0), t_p7.clone(), tok_p3.span.clone()), move |parse_template_14898: (crate::syntax::Template, crate::syntax::parser::Ps)| {
                    let (tpl_p8, q_p9) = parse_template_14898;
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETemplate(tpl_p8.clone())), span: tok_p3.span.clone() }, false, q_p9.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KOpen(m14436_9_0, _) if (m14436_9_0 == &Text::lit("(")) => prism_rtl::Turn::More(Rc::new(ParenPrimary { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KOpen(m14436_10_0, _) if (m14436_10_0 == &Text::lit("[")) => prism_rtl::Turn::More(Rc::new(SquarePrimary { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KOpen(_, _) => prism_rtl::Turn::More(Rc::new(MapPrimary { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KDot(true) => {
                let p1_pa = crate::syntax::parser::adv(p_p0);
                match crate::syntax::parser::kind(&p1_pa) {
                    crate::syntax::lexer::TokKind::KName(n_pb) if (((&n_pb.sigils == &Text::lit("")) && (&len(&n_pb.path_) == &Nat::from(1u32))) && (&n_pb.case == &crate::syntax::lexer::NameCase::CaseLower)) => {
                        let t_pc = crate::syntax::parser::here(&p1_pa);
                        prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETopicField(crate::syntax::Ident { name: or(&index(&n_pb.path_, &Nat::from(0u32)), &Text::lit("")), span: t_pc.clone() })), span: crate::syntax::parser::to(&start_p2, &t_pc) }, false, crate::syntax::parser::adv(&p1_pa)))
                    },
                    crate::syntax::lexer::TokKind::KName(n_pd) if (&n_pd.case == &crate::syntax::lexer::NameCase::CaseUpper) => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(&p1_pa, &start_p2, &Text::from(format!("a spaced `.{}` begins its own line, below the call it takes as its receiver (layout rule 9)", &crate::syntax::lexer::chars::join(&n_pd.path_, &Text::lit("."))))))),
                    _ => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(&p1_pa, &start_p2, &Text::lit("a prefix `.` takes a field name, applied to the topic `_`")))),
                    _ => unreachable!("no arm matched"),
                }
            },
            crate::syntax::lexer::TokKind::KLensDot => prism_rtl::Turn::More(Rc::new(LensPrimary { p0_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KFree(s_pe) => if s_pe == &Text::lit("!") {
                prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), true, crate::syntax::parser::error_at(&crate::syntax::parser::adv(p_p0), &tok_p3.span, &Text::lit("`!` is never free: no event fires a constant"))))
            } else {
                if s_pe == &Text::lit("&") {
                    prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), true, crate::syntax::parser::error_at(&crate::syntax::parser::adv(p_p0), &tok_p3.span, &Text::lit("`&` is never free: no reference exists outside the value an `update` block names"))))
                } else {
                    {
                        let commas_p1 = *commas_p1;
                        let p_p0 = p_p0.clone();
                        let s_pe = s_pe.clone();
                        call_then(start_parse_expr_ctx(crate::syntax::parser::adv(&p_p0), commas_p1), move |parse_expr_ctx_16414: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                            let (operand_pf, q_pg) = parse_expr_ctx_16414;
                            prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EFreeSigil(s_pe.clone(), Rc::new(operand_pf.clone()))), span: crate::syntax::parser::to(&start_p2, &operand_pf.span) }, true, q_pg.clone()))
                        })
                    }
                }
            },
            crate::syntax::lexer::TokKind::KBackslash => {
                let p_p0 = p_p0.clone();
                call_then(start_parse_lambda(p_p0.clone()), move |parse_lambda_16585: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (e_ph, q_pi) = parse_lambda_16585;
                    prism_rtl::Turn::Finished((e_ph.clone(), true, q_pi.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KAbsent => {
                let q_pj = crate::syntax::parser::out_of_scope(&crate::syntax::parser::adv(p_p0), &tok_p3.span, &Text::lit("sparse tuples"), &Text::lit("an absent component `-` makes a sparse tuple, which is out of this compiler"));
                prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EAbsent), span: tok_p3.span.clone() }, false, q_pj.clone()))
            },
            crate::syntax::lexer::TokKind::KDotDot => prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ERest), span: tok_p3.span.clone() }, false, crate::syntax::parser::adv(p_p0))),
            crate::syntax::lexer::TokKind::KTrait(_) => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_p0, &tok_p3.span, &Text::lit("no trait is a value: a `^Trait` stands in a type, a bound, `derive`, `trait` or `impl`")))),
            crate::syntax::lexer::TokKind::KFamily(path_pk) => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_p0, &tok_p3.span, &Text::from(format!("`{}.*` names every tag of a family: it stands in a pattern, an `emit` row or a `use`, not in an expression", &crate::syntax::lexer::chars::join(path_pk, &Text::lit("."))))))),
            crate::syntax::lexer::TokKind::KBar => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_p0, &tok_p3.span, &Text::lit("a bare `|` is not an operator: the merge is `<|`, and `|` separates the families of a row")))),
            _ => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_here(p_p0, &Text::lit("expected an expression")))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ParsePrimary, x`: what the function value is when passed to `@Run`.
pub fn start_parse_primary(p_p0: crate::syntax::parser::Ps, commas_p1: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)>> {
    Rc::new(ParsePrimary { p_p0, commas_p1 })
}

/// ```prism
/// LiteralPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub fn literal_primary(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, bool, crate::syntax::parser::Ps) {
    let (lit_p1, q_p2) = parse_literal(p_p0);
    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELit(lit_p1.clone())), span: lit_p1.span.clone() }, false, q_p2.clone())
}

/// The step machine of `LiteralPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LiteralPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub struct LiteralPrimary {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> for LiteralPrimary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let p_p0 = p_p0.clone();
        call_then(start_parse_literal(p_p0.clone()), move |parse_literal_17581: (crate::syntax::Literal, crate::syntax::parser::Ps)| {
            let (lit_p1, q_p2) = parse_literal_17581;
            prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELit(lit_p1.clone())), span: lit_p1.span.clone() }, false, q_p2.clone()))
        })
    }
}

/// `Start LiteralPrimary, x`: what the function value is when passed to `@Run`.
pub fn start_literal_primary(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)>> {
    Rc::new(LiteralPrimary { p_p0 })
}

/// ```prism
/// NamePrimary: unbounded fn Ps, NameTok, Bool -> ((Expr, Bool, Ps))
/// ```
pub fn name_primary(p0_p0: &crate::syntax::parser::Ps, n_p1: &crate::syntax::lexer::NameTok, commas_p2: &bool) -> (crate::syntax::Expr, bool, crate::syntax::parser::Ps) {
    let start_p3 = crate::syntax::parser::here(p0_p0);
    let name_p4 = crate::syntax::SName { sigils: n_p1.sigils.clone(), path_: n_p1.path_.clone(), span: start_p3.clone() };
    let p1_p5 = crate::syntax::parser::check_name_scope(&crate::syntax::parser::adv(p0_p0), &name_p4);
    let plain_p6 = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(name_p4.clone())), span: start_p3.clone() };
    let (e_p7, p_p8) = if &crate::syntax::parser::kind(&p1_p5) == &crate::syntax::lexer::TokKind::KLtLt {
        type_args_on(&plain_p6, &p1_p5, &start_p3)
    } else {
        (plain_p6.clone(), p1_p5.clone())
    };
    if crate::syntax::parser::is_callee(&name_p4) {
        if crate::syntax::parser::at_single_open(&p_p8, &Text::lit("(")) && crate::syntax::parser::tk(&p_p8).touches {
            {
                let (args_p9, rest_pa, q_pb) = parse_paren_args(&p_p8);
                (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECall(Rc::new(e_p7.clone()), args_p9.clone(), true, rest_pa)), span: crate::syntax::parser::to(&start_p3, &crate::syntax::parser::prev(&q_pb)) }, false, q_pb.clone())
            }
        } else {
            if crate::syntax::parser::at_kw(&p_p8, &Text::lit("monad")) {
                {
                    let kw_pc = crate::syntax::parser::here(&p_p8);
                    let (body_pd, q_pe) = crate::syntax::parser::blocks::parse_block_after_colon(&crate::syntax::parser::out_of_scope(&crate::syntax::parser::adv(&p_p8), &kw_pc, &Text::lit("`T monad:` blocks and `^Monad`"), &Text::lit("monad blocks are out of this compiler")));
                    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMonad(Rc::new(e_p7.clone()), body_pd.clone())), span: crate::syntax::parser::to(&start_p3, &body_pd.span) }, true, q_pe.clone())
                }
            } else {
                if arg_starts_here(&p_p8) {
                    {
                        let (args_pf, q_pg) = parse_call_args(&p_p8, commas_p2);
                        (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECall(Rc::new(e_p7.clone()), args_pf.clone(), false, false)), span: crate::syntax::parser::to(&start_p3, &crate::syntax::parser::prev(&q_pg)) }, true, q_pg.clone())
                    }
                } else {
                    (e_p7.clone(), false, p_p8.clone())
                }
            }
        }
    } else {
        if (crate::syntax::parser::at_single_open(&p_p8, &Text::lit("(")) && crate::syntax::parser::tk(&p_p8).touches) && !crate::syntax::parser::is_topic(&name_p4) {
            (e_p7.clone(), false, crate::syntax::parser::error_at(&p_p8, &crate::syntax::parser::here(&p_p8), &Text::from(format!("`{}` is a value and is not applied: a function\'s name is uppercase (case is a mark)", &crate::syntax::parser::name_text(&name_p4)))))
        } else {
            (e_p7.clone(), false, p_p8.clone())
        }
    }
}

/// The step machine of `NamePrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamePrimary: unbounded fn Ps, NameTok, Bool -> ((Expr, Bool, Ps))
/// ```
pub struct NamePrimary {
    pub p0_p0: crate::syntax::parser::Ps,
    pub n_p1: crate::syntax::lexer::NameTok,
    pub commas_p2: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> for NamePrimary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let n_p1 = &self.n_p1;
        let commas_p2 = &self.commas_p2;
        let start_p3 = crate::syntax::parser::here(p0_p0);
        let name_p4 = crate::syntax::SName { sigils: n_p1.sigils.clone(), path_: n_p1.path_.clone(), span: start_p3.clone() };
        let p1_p5 = crate::syntax::parser::check_name_scope(&crate::syntax::parser::adv(p0_p0), &name_p4);
        let plain_p6 = crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(name_p4.clone())), span: start_p3.clone() };
        let (e_p7, p_p8) = if &crate::syntax::parser::kind(&p1_p5) == &crate::syntax::lexer::TokKind::KLtLt {
            type_args_on(&plain_p6, &p1_p5, &start_p3)
        } else {
            (plain_p6.clone(), p1_p5.clone())
        };
        if crate::syntax::parser::is_callee(&name_p4) {
            if crate::syntax::parser::at_single_open(&p_p8, &Text::lit("(")) && crate::syntax::parser::tk(&p_p8).touches {
                call_then(start_parse_paren_args(p_p8.clone()), move |parse_paren_args_18204: (Array<crate::syntax::Arg>, bool, crate::syntax::parser::Ps)| {
                    let (args_p9, rest_pa, q_pb) = parse_paren_args_18204;
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECall(Rc::new(e_p7.clone()), args_p9.clone(), true, rest_pa)), span: crate::syntax::parser::to(&start_p3, &crate::syntax::parser::prev(&q_pb)) }, false, q_pb.clone()))
                })
            } else {
                if crate::syntax::parser::at_kw(&p_p8, &Text::lit("monad")) {
                    {
                        let kw_pc = crate::syntax::parser::here(&p_p8);
                        call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(crate::syntax::parser::out_of_scope(&crate::syntax::parser::adv(&p_p8), &kw_pc, &Text::lit("`T monad:` blocks and `^Monad`"), &Text::lit("monad blocks are out of this compiler"))), move |parse_block_after_colon_18455: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                            let (body_pd, q_pe) = parse_block_after_colon_18455;
                            prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMonad(Rc::new(e_p7.clone()), body_pd.clone())), span: crate::syntax::parser::to(&start_p3, &body_pd.span) }, true, q_pe.clone()))
                        })
                    }
                } else {
                    if arg_starts_here(&p_p8) {
                        {
                            let commas_p2 = *commas_p2;
                            call_then(start_parse_call_args(p_p8.clone(), commas_p2), move |parse_call_args_18721: (Array<crate::syntax::Arg>, crate::syntax::parser::Ps)| {
                                let (args_pf, q_pg) = parse_call_args_18721;
                                prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ECall(Rc::new(e_p7.clone()), args_pf.clone(), false, false)), span: crate::syntax::parser::to(&start_p3, &crate::syntax::parser::prev(&q_pg)) }, true, q_pg.clone()))
                            })
                        }
                    } else {
                        prism_rtl::Turn::Finished((e_p7.clone(), false, p_p8.clone()))
                    }
                }
            }
        } else {
            if (crate::syntax::parser::at_single_open(&p_p8, &Text::lit("(")) && crate::syntax::parser::tk(&p_p8).touches) && !crate::syntax::parser::is_topic(&name_p4) {
                prism_rtl::Turn::Finished((e_p7.clone(), false, crate::syntax::parser::error_at(&p_p8, &crate::syntax::parser::here(&p_p8), &Text::from(format!("`{}` is a value and is not applied: a function\'s name is uppercase (case is a mark)", &crate::syntax::parser::name_text(&name_p4))))))
            } else {
                prism_rtl::Turn::Finished((e_p7.clone(), false, p_p8.clone()))
            }
        }
    }
}

/// `Start NamePrimary, x`: what the function value is when passed to `@Run`.
pub fn start_name_primary(p0_p0: crate::syntax::parser::Ps, n_p1: crate::syntax::lexer::NameTok, commas_p2: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)>> {
    Rc::new(NamePrimary { p0_p0, n_p1, commas_p2 })
}

/// ```prism
/// TypeArgsOn: unbounded fn Expr, Ps, Range -> ((Expr, Ps))
/// ```
pub fn type_args_on(e_p0: &crate::syntax::Expr, p_p1: &crate::syntax::parser::Ps, start_p2: &crate::syntax::Range) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let (types_p3, q_p4) = parse_type_args(p_p1);
    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETypeArgs(Rc::new(e_p0.clone()), types_p3.clone())), span: crate::syntax::parser::to(start_p2, &crate::syntax::parser::prev(&q_p4)) }, q_p4.clone())
}

/// The step machine of `TypeArgsOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeArgsOn: unbounded fn Expr, Ps, Range -> ((Expr, Ps))
/// ```
pub struct TypeArgsOn {
    pub e_p0: crate::syntax::Expr,
    pub p_p1: crate::syntax::parser::Ps,
    pub start_p2: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for TypeArgsOn {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let e_p0 = &self.e_p0;
        let p_p1 = &self.p_p1;
        let start_p2 = &self.start_p2;
        let e_p0 = e_p0.clone();
        let p_p1 = p_p1.clone();
        let start_p2 = start_p2.clone();
        call_then(start_parse_type_args(p_p1.clone()), move |parse_type_args_19224: (Array<crate::syntax::Type>, crate::syntax::parser::Ps)| {
            let (types_p3, q_p4) = parse_type_args_19224;
            prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETypeArgs(Rc::new(e_p0.clone()), types_p3.clone())), span: crate::syntax::parser::to(&start_p2, &crate::syntax::parser::prev(&q_p4)) }, q_p4.clone()))
        })
    }
}

/// `Start TypeArgsOn, x`: what the function value is when passed to `@Run`.
pub fn start_type_args_on(e_p0: crate::syntax::Expr, p_p1: crate::syntax::parser::Ps, start_p2: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(TypeArgsOn { e_p0, p_p1, start_p2 })
}

/// ```prism
/// ParenPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub fn paren_primary(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, bool, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here(p_p0);
    if crate::syntax::parser::at_double_open(p_p0, &Text::lit("(")) {
        {
            let (elems_p3, p1_p4) = crate::syntax::parser::commas(&crate::syntax::parser::open_double(p_p0), &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_arg_expr(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>));
            let p2_p2 = crate::syntax::parser::close_double(&p1_p4, &Text::lit("("));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETuple(elems_p3.clone())), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p2_p2)) }, false, p2_p2.clone())
        }
    } else {
        {
            let (inner_p5, p1_p6) = crate::syntax::parser::bracketed(&crate::syntax::parser::adv(p_p0), &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_rhs_expr(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>));
            if crate::syntax::parser::at_comma(&p1_p6) {
                (crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(&p1_p6, &crate::syntax::parser::here(&p1_p6), &Text::lit("a group holds one expression: a comma here needs a call at the group\'s head, or `((` `))` for a tuple")))
            } else {
                {
                    let p2_p7 = crate::syntax::parser::expect_close(&p1_p6, &Text::lit("("));
                    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EGroup(Rc::new(inner_p5.clone()))), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p2_p7)) }, false, p2_p7.clone())
                }
            }
        }
    }
}

/// The step machine of `ParenPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParenPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub struct ParenPrimary {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> for ParenPrimary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here(p_p0);
        if crate::syntax::parser::at_double_open(p_p0, &Text::lit("(")) {
            {
                let p_p0 = p_p0.clone();
                call_then(crate::syntax::parser::start_commas(crate::syntax::parser::open_double(&p_p0), Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_arg_expr(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>), move |commas_19554: (Array<crate::syntax::Expr>, crate::syntax::parser::Ps)| {
                    let (elems_p3, p1_p4) = commas_19554;
                    let p2_p2 = crate::syntax::parser::close_double(&p1_p4, &Text::lit("("));
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETuple(elems_p3.clone())), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p2_p2)) }, false, p2_p2.clone()))
                })
            }
        } else {
            {
                let p_p0 = p_p0.clone();
                call_then(crate::syntax::parser::start_bracketed(crate::syntax::parser::adv(&p_p0), Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_rhs_expr(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>), move |bracketed_19818: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (inner_p5, p1_p6) = bracketed_19818;
                    if crate::syntax::parser::at_comma(&p1_p6) {
                        prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(&p1_p6, &crate::syntax::parser::here(&p1_p6), &Text::lit("a group holds one expression: a comma here needs a call at the group\'s head, or `((` `))` for a tuple"))))
                    } else {
                        {
                            let p2_p7 = crate::syntax::parser::expect_close(&p1_p6, &Text::lit("("));
                            prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EGroup(Rc::new(inner_p5.clone()))), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p2_p7)) }, false, p2_p7.clone()))
                        }
                    }
                })
            }
        }
    }
}

/// `Start ParenPrimary, x`: what the function value is when passed to `@Run`.
pub fn start_paren_primary(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)>> {
    Rc::new(ParenPrimary { p_p0 })
}

/// ```prism
/// SquarePrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub fn square_primary(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, bool, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here(p_p0);
    if crate::syntax::parser::at_double_open(p_p0, &Text::lit("[")) {
        {
            let p1_p2 = crate::syntax::parser::open_double(p_p0);
            let (elems_p4, p2_p5) = if crate::syntax::parser::at_close(&p1_p2, &Text::lit("[")) {
                (Array::new(), p1_p2.clone())
            } else {
                crate::syntax::parser::commas(&p1_p2, &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_arg_expr(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>))
            };
            let p3_p3 = crate::syntax::parser::close_double(&p2_p5, &Text::lit("["));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EArray(elems_p4.clone())), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p3_p3)) }, false, p3_p3.clone())
        }
    } else {
        {
            let (index_p7, p1_p8) = crate::syntax::parser::bracketed(&crate::syntax::parser::adv(p_p0), &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_expr(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>));
            let p2_p6 = crate::syntax::parser::expect_close(&p1_p8, &Text::lit("["));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETopicIndex(Rc::new(index_p7.clone()))), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p2_p6)) }, false, p2_p6.clone())
        }
    }
}

/// The step machine of `SquarePrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SquarePrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub struct SquarePrimary {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> for SquarePrimary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here(p_p0);
        if crate::syntax::parser::at_double_open(p_p0, &Text::lit("[")) {
            {
                let p1_p2 = crate::syntax::parser::open_double(p_p0);
                let (elems_p4, p2_p5) = if crate::syntax::parser::at_close(&p1_p2, &Text::lit("[")) {
                    (Array::new(), p1_p2.clone())
                } else {
                    crate::syntax::parser::commas(&p1_p2, &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_arg_expr(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>))
                };
                let p3_p3 = crate::syntax::parser::close_double(&p2_p5, &Text::lit("["));
                prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EArray(elems_p4.clone())), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p3_p3)) }, false, p3_p3.clone()))
            }
        } else {
            {
                let p_p0 = p_p0.clone();
                call_then(crate::syntax::parser::start_bracketed(crate::syntax::parser::adv(&p_p0), Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_expr(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>>>), move |bracketed_20642: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (index_p7, p1_p8) = bracketed_20642;
                    let p2_p6 = crate::syntax::parser::expect_close(&p1_p8, &Text::lit("["));
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETopicIndex(Rc::new(index_p7.clone()))), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p2_p6)) }, false, p2_p6.clone()))
                })
            }
        }
    }
}

/// `Start SquarePrimary, x`: what the function value is when passed to `@Run`.
pub fn start_square_primary(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)>> {
    Rc::new(SquarePrimary { p_p0 })
}

/// ```prism
/// MapPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub fn map_primary(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, bool, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here(p_p0);
    let p1_p2 = crate::syntax::parser::adv(p_p0);
    let (entries_p4, p2_p5) = if crate::syntax::parser::at_close(&p1_p2, &Text::lit("{")) {
        (Array::new(), p1_p2.clone())
    } else {
        crate::syntax::parser::commas(&p1_p2, &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_map_entry(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<((crate::syntax::Expr, crate::syntax::Expr), crate::syntax::parser::Ps)>>>))
    };
    let p3_p3 = crate::syntax::parser::expect_close(&p2_p5, &Text::lit("{"));
    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMap(entries_p4.clone())), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p3_p3)) }, false, p3_p3.clone())
}

/// The step machine of `MapPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MapPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub struct MapPrimary {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> for MapPrimary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here(p_p0);
        let p1_p2 = crate::syntax::parser::adv(p_p0);
        let (entries_p4, p2_p5) = if crate::syntax::parser::at_close(&p1_p2, &Text::lit("{")) {
            (Array::new(), p1_p2.clone())
        } else {
            crate::syntax::parser::commas(&p1_p2, &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_map_entry(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<((crate::syntax::Expr, crate::syntax::Expr), crate::syntax::parser::Ps)>>>))
        };
        let p3_p3 = crate::syntax::parser::expect_close(&p2_p5, &Text::lit("{"));
        prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMap(entries_p4.clone())), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&p3_p3)) }, false, p3_p3.clone()))
    }
}

/// `Start MapPrimary, x`: what the function value is when passed to `@Run`.
pub fn start_map_primary(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)>> {
    Rc::new(MapPrimary { p_p0 })
}

/// ```prism
/// ParseMapEntry: unbounded fn Ps -> ((((Expr, Expr)), Ps))
/// ```
pub fn parse_map_entry(p_p0: &crate::syntax::parser::Ps) -> ((crate::syntax::Expr, crate::syntax::Expr), crate::syntax::parser::Ps) {
    let (k_p1, p1_p2) = parse_arg_expr(p_p0);
    let (v_p3, p2_p4) = parse_arg_expr(&crate::syntax::parser::expect_colon(&p1_p2));
    ((k_p1.clone(), v_p3.clone()), p2_p4.clone())
}

/// The step machine of `ParseMapEntry`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseMapEntry: unbounded fn Ps -> ((((Expr, Expr)), Ps))
/// ```
pub struct ParseMapEntry {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<((crate::syntax::Expr, crate::syntax::Expr), crate::syntax::parser::Ps)> for ParseMapEntry {
    fn cycle(&self) -> prism_rtl::Turn<((crate::syntax::Expr, crate::syntax::Expr), crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let p_p0 = p_p0.clone();
        call_then(start_parse_arg_expr(p_p0.clone()), move |parse_arg_expr_21225: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
            let (k_p1, p1_p2) = parse_arg_expr_21225;
            call_then(start_parse_arg_expr(crate::syntax::parser::expect_colon(&p1_p2)), move |parse_arg_expr_21260: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                let (v_p3, p2_p4) = parse_arg_expr_21260;
                prism_rtl::Turn::Finished(((k_p1.clone(), v_p3.clone()), p2_p4.clone()))
            })
        })
    }
}

/// `Start ParseMapEntry, x`: what the function value is when passed to `@Run`.
pub fn start_parse_map_entry(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<((crate::syntax::Expr, crate::syntax::Expr), crate::syntax::parser::Ps)>> {
    Rc::new(ParseMapEntry { p_p0 })
}

/// ```prism
/// LensPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub fn lens_primary(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, bool, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here(p0_p0);
    let r_p2 = {
        let mut this: (Array<crate::syntax::Ident>, crate::syntax::parser::Ps) = (Array::new(), crate::syntax::parser::adv(p0_p0));
        let mut path_p3: Array<crate::syntax::Ident> = Array::new();
        let mut p_p4: crate::syntax::parser::Ps = crate::syntax::parser::adv(p0_p0);
        let mut going_p5: bool = true;
        while going_p5 && !p_p4.bad {
            match &crate::syntax::parser::kind(&p_p4) {
                crate::syntax::lexer::TokKind::KName(n_p6) if (((&n_p6.sigils == &Text::lit("")) && (&n_p6.case == &crate::syntax::lexer::NameCase::CaseLower)) && (&len(&n_p6.path_) == &Nat::from(1u32))) => {
                    path_p3 = push(&path_p3, &crate::syntax::Ident { name: or(&index(&n_p6.path_, &Nat::from(0u32)), &Text::lit("")), span: crate::syntax::parser::here(&p_p4) });
                    p_p4 = crate::syntax::parser::adv(&p_p4);
                    if &crate::syntax::parser::kind(&p_p4) == &crate::syntax::lexer::TokKind::KDot(false) {
                        p_p4 = crate::syntax::parser::adv(&p_p4);
                    } else {
                        going_p5 = false;
                    }
                    ()
                },
                _ => {
                    p_p4 = crate::syntax::parser::error_here(&p_p4, &Text::lit("expected a field name in a lens path"));
                    ()
                },
                _ => unreachable!("no arm matched"),
            };
        }
        this = (path_p3.clone(), p_p4.clone());
        this
    };
    let (path_p7, q_p8) = r_p2.clone();
    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELens(path_p7.clone())), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&q_p8)) }, false, q_p8.clone())
}

/// The step machine of `LensPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LensPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
/// ```
pub struct LensPrimary {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> for LensPrimary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let start_p1 = crate::syntax::parser::here(p0_p0);
        let mut this: (Array<crate::syntax::Ident>, crate::syntax::parser::Ps) = (Array::new(), crate::syntax::parser::adv(p0_p0));
        let mut path_p3: Array<crate::syntax::Ident> = Array::new();
        let mut p_p4: crate::syntax::parser::Ps = crate::syntax::parser::adv(p0_p0);
        let mut going_p5: bool = true;
        let start_p1 = start_p1.clone();
        call_then(loop_job((this, going_p5, p_p4, path_p3), move |(mut this, mut going_p5, mut p_p4, mut path_p3): ((Array<crate::syntax::Ident>, crate::syntax::parser::Ps), bool, crate::syntax::parser::Ps, Array<crate::syntax::Ident>)| if going_p5 && !p_p4.bad {
            {
                match &crate::syntax::parser::kind(&p_p4) {
                    crate::syntax::lexer::TokKind::KName(n_p6) if (((&n_p6.sigils == &Text::lit("")) && (&n_p6.case == &crate::syntax::lexer::NameCase::CaseLower)) && (&len(&n_p6.path_) == &Nat::from(1u32))) => {
                        path_p3 = push(&path_p3, &crate::syntax::Ident { name: or(&index(&n_p6.path_, &Nat::from(0u32)), &Text::lit("")), span: crate::syntax::parser::here(&p_p4) });
                        p_p4 = crate::syntax::parser::adv(&p_p4);
                        if &crate::syntax::parser::kind(&p_p4) == &crate::syntax::lexer::TokKind::KDot(false) {
                            p_p4 = crate::syntax::parser::adv(&p_p4);
                        } else {
                            going_p5 = false;
                        }
                        ()
                    },
                    _ => {
                        p_p4 = crate::syntax::parser::error_here(&p_p4, &Text::lit("expected a field name in a lens path"));
                        ()
                    },
                    _ => unreachable!("no arm matched"),
                };
                Ok((this, going_p5, p_p4, path_p3))
            }
        } else {
            Err((this, going_p5, p_p4, path_p3))
        }), move |(mut this, mut going_p5, mut p_p4, mut path_p3): ((Array<crate::syntax::Ident>, crate::syntax::parser::Ps), bool, crate::syntax::parser::Ps, Array<crate::syntax::Ident>)| {
            this = (path_p3.clone(), p_p4.clone());
            let r_p2 = this;
            let (path_p7, q_p8) = r_p2.clone();
            prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELens(path_p7.clone())), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&q_p8)) }, false, q_p8.clone()))
        })
    }
}

/// `Start LensPrimary, x`: what the function value is when passed to `@Run`.
pub fn start_lens_primary(p0_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)>> {
    Rc::new(LensPrimary { p0_p0 })
}

/// ```prism
/// KeywordPrimary: unbounded fn Ps, Text, Text, Bool -> ((Expr, Bool, Ps))
/// ```
pub fn keyword_primary(p_p0: &crate::syntax::parser::Ps, w_p1: &Text, sigils_p2: &Text, commas_p3: &bool) -> (crate::syntax::Expr, bool, crate::syntax::parser::Ps) {
    let start_p4 = crate::syntax::parser::here(p_p0);
    match w_p1 {
        m22385_0 if (m22385_0 == &Text::lit("unit")) => (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EUnit(sigils_p2.clone())), span: start_p4.clone() }, false, crate::syntax::parser::adv(p_p0)),
        m22385_1 if (m22385_1 == &Text::lit("nil")) => (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ENil(sigils_p2.clone())), span: start_p4.clone() }, false, crate::syntax::parser::adv(p_p0)),
        _ if crate::syntax::lexer::is_bound_word(w_p1) => (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EBound(w_p1.clone())), span: start_p4.clone() }, false, crate::syntax::parser::adv(p_p0)),
        m22385_3 if (m22385_3 == &Text::lit("if")) => took(&parse_if(p_p0)),
        m22385_4 if (m22385_4 == &Text::lit("match")) => took(&parse_match(p_p0)),
        m22385_5 if (m22385_5 == &Text::lit("rebuild")) => {
            let (scrutinee_p5, p1_p6) = parse_expr(&crate::syntax::parser::adv(p_p0));
            let (body_p7, p2_p8) = crate::syntax::parser::blocks::parse_block_after_colon(&p1_p6);
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ERebuild(Rc::new(scrutinee_p5.clone()), body_p7.clone())), span: crate::syntax::parser::to(&start_p4, &body_p7.span) }, true, p2_p8.clone())
        },
        m22385_6 if (m22385_6 == &Text::lit("for")) => took(&parse_for(p_p0)),
        m22385_7 if (m22385_7 == &Text::lit("given")) => {
            let (body_p9, q_pa) = crate::syntax::parser::blocks::parse_block_after_colon(&crate::syntax::parser::adv(p_p0));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EGiven(body_p9.clone())), span: crate::syntax::parser::to(&start_p4, &body_p9.span) }, true, q_pa.clone())
        },
        m22385_8 if (m22385_8 == &Text::lit("update")) => {
            let (target_pb, p1_pc) = parse_expr(&crate::syntax::parser::adv(p_p0));
            let (body_pd, p2_pe) = crate::syntax::parser::blocks::parse_block_after_colon(&p1_pc);
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EUpdate(Rc::new(target_pb.clone()), body_pd.clone())), span: crate::syntax::parser::to(&start_p4, &body_pd.span) }, true, p2_pe.clone())
        },
        m22385_9 if (m22385_9 == &Text::lit("widget")) => {
            let (body_pf, q_pg) = crate::syntax::parser::blocks::parse_block_after_colon(&crate::syntax::parser::adv(p_p0));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EWidgetBlock(body_pf.clone())), span: crate::syntax::parser::to(&start_p4, &body_pf.span) }, true, q_pg.clone())
        },
        m22385_10 if (m22385_10 == &Text::lit("any")) => {
            let (operand_ph, q_pi) = parse_expr_ctx(&crate::syntax::parser::adv(p_p0), commas_p3);
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EAny(Rc::new(operand_ph.clone()))), span: crate::syntax::parser::to(&start_p4, &operand_ph.span) }, true, q_pi.clone())
        },
        m22385_11 if (m22385_11 == &Text::lit("not")) => {
            let (e_pj, q_pk) = parse_binary(p_p0, &Nat::from(8u32), commas_p3);
            (e_pj.clone(), true, q_pk.clone())
        },
        _ if (((w_p1 == &Text::lit("output")) || (w_p1 == &Text::lit("inline_text"))) || (w_p1 == &Text::lit("raw"))) => {
            let p1_pl = crate::syntax::parser::adv(p_p0);
            match crate::syntax::parser::kind(&p1_pl) {
                crate::syntax::lexer::TokKind::KTemplate(t_pm) => {
                    let tspan_pn = crate::syntax::parser::here(&p1_pl);
                    let (tpl_po, q_pp) = parse_template(&crate::syntax::parser::adv(&p1_pl), &t_pm, &tspan_pn);
                    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETemplate(tpl_po.clone())), span: crate::syntax::parser::to(&start_p4, &tspan_pn) }, false, q_pp.clone())
                },
                _ => (crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::fail(&p1_pl)),
            }
        },
        m22385_13 if (m22385_13 == &Text::lit("then")) => (crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_p0, &start_p4, &Text::lit("`then` belongs to a hold: `$x <- start then step`"))),
        m22385_14 if (m22385_14 == &Text::lit("else")) => (crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_p0, &start_p4, &Text::lit("`else` without its `if`"))),
        m22385_15 if (m22385_15 == &Text::lit("ignore")) => (crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_p0, &start_p4, &Text::lit("`ignore` stands only inside a pattern or as the left side of a bind"))),
        m22385_16 if (m22385_16 == &Text::lit("return")) => (crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_p0, &start_p4, &Text::lit("`return` ends a monad block, as its last statement"))),
        _ => (crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_here(p_p0, &Text::lit("expected an expression"))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `KeywordPrimary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// KeywordPrimary: unbounded fn Ps, Text, Text, Bool -> ((Expr, Bool, Ps))
/// ```
pub struct KeywordPrimary {
    pub p_p0: crate::syntax::parser::Ps,
    pub w_p1: Text,
    pub sigils_p2: Text,
    pub commas_p3: bool,
}

impl prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> for KeywordPrimary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let w_p1 = &self.w_p1;
        let sigils_p2 = &self.sigils_p2;
        let commas_p3 = &self.commas_p3;
        let start_p4 = crate::syntax::parser::here(p_p0);
        match w_p1 {
            m22385_0 if (m22385_0 == &Text::lit("unit")) => prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EUnit(sigils_p2.clone())), span: start_p4.clone() }, false, crate::syntax::parser::adv(p_p0))),
            m22385_1 if (m22385_1 == &Text::lit("nil")) => prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ENil(sigils_p2.clone())), span: start_p4.clone() }, false, crate::syntax::parser::adv(p_p0))),
            _ if crate::syntax::lexer::is_bound_word(w_p1) => prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EBound(w_p1.clone())), span: start_p4.clone() }, false, crate::syntax::parser::adv(p_p0))),
            m22385_3 if (m22385_3 == &Text::lit("if")) => {
                let p_p0 = p_p0.clone();
                call_then(start_parse_if(p_p0.clone()), move |parse_if_22647: (crate::syntax::Expr, crate::syntax::parser::Ps)| prism_rtl::Turn::Finished(took(&parse_if_22647)))
            },
            m22385_4 if (m22385_4 == &Text::lit("match")) => {
                let p_p0 = p_p0.clone();
                call_then(start_parse_match(p_p0.clone()), move |parse_match_22681: (crate::syntax::Expr, crate::syntax::parser::Ps)| prism_rtl::Turn::Finished(took(&parse_match_22681)))
            },
            m22385_5 if (m22385_5 == &Text::lit("rebuild")) => {
                let p_p0 = p_p0.clone();
                call_then(start_parse_expr(crate::syntax::parser::adv(&p_p0)), move |parse_expr_22750: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (scrutinee_p5, p1_p6) = parse_expr_22750;
                    call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(p1_p6.clone()), move |parse_block_after_colon_22799: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                        let (body_p7, p2_p8) = parse_block_after_colon_22799;
                        prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ERebuild(Rc::new(scrutinee_p5.clone()), body_p7.clone())), span: crate::syntax::parser::to(&start_p4, &body_p7.span) }, true, p2_p8.clone()))
                    })
                })
            },
            m22385_6 if (m22385_6 == &Text::lit("for")) => {
                let p_p0 = p_p0.clone();
                call_then(start_parse_for(p_p0.clone()), move |parse_for_22936: (crate::syntax::Expr, crate::syntax::parser::Ps)| prism_rtl::Turn::Finished(took(&parse_for_22936)))
            },
            m22385_7 if (m22385_7 == &Text::lit("given")) => {
                let p_p0 = p_p0.clone();
                call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(crate::syntax::parser::adv(&p_p0)), move |parse_block_after_colon_22995: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                    let (body_p9, q_pa) = parse_block_after_colon_22995;
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EGiven(body_p9.clone())), span: crate::syntax::parser::to(&start_p4, &body_p9.span) }, true, q_pa.clone()))
                })
            },
            m22385_8 if (m22385_8 == &Text::lit("update")) => {
                let p_p0 = p_p0.clone();
                call_then(start_parse_expr(crate::syntax::parser::adv(&p_p0)), move |parse_expr_23153: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (target_pb, p1_pc) = parse_expr_23153;
                    call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(p1_pc.clone()), move |parse_block_after_colon_23202: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                        let (body_pd, p2_pe) = parse_block_after_colon_23202;
                        prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EUpdate(Rc::new(target_pb.clone()), body_pd.clone())), span: crate::syntax::parser::to(&start_p4, &body_pd.span) }, true, p2_pe.clone()))
                    })
                })
            },
            m22385_9 if (m22385_9 == &Text::lit("widget")) => {
                let p_p0 = p_p0.clone();
                call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(crate::syntax::parser::adv(&p_p0)), move |parse_block_after_colon_23415: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                    let (body_pf, q_pg) = parse_block_after_colon_23415;
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EWidgetBlock(body_pf.clone())), span: crate::syntax::parser::to(&start_p4, &body_pf.span) }, true, q_pg.clone()))
                })
            },
            m22385_10 if (m22385_10 == &Text::lit("any")) => {
                let commas_p3 = *commas_p3;
                let p_p0 = p_p0.clone();
                call_then(start_parse_expr_ctx(crate::syntax::parser::adv(&p_p0), commas_p3), move |parse_expr_ctx_23576: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (operand_ph, q_pi) = parse_expr_ctx_23576;
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EAny(Rc::new(operand_ph.clone()))), span: crate::syntax::parser::to(&start_p4, &operand_ph.span) }, true, q_pi.clone()))
                })
            },
            m22385_11 if (m22385_11 == &Text::lit("not")) => {
                let commas_p3 = *commas_p3;
                let p_p0 = p_p0.clone();
                call_then(start_parse_binary(p_p0.clone(), Nat::from(8u32), commas_p3), move |parse_binary_23729: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (e_pj, q_pk) = parse_binary_23729;
                    prism_rtl::Turn::Finished((e_pj.clone(), true, q_pk.clone()))
                })
            },
            _ if (((w_p1 == &Text::lit("output")) || (w_p1 == &Text::lit("inline_text"))) || (w_p1 == &Text::lit("raw"))) => {
                let p1_pl = crate::syntax::parser::adv(p_p0);
                match crate::syntax::parser::kind(&p1_pl) {
                    crate::syntax::lexer::TokKind::KTemplate(t_pm) => {
                        let tspan_pn = crate::syntax::parser::here(&p1_pl);
                        call_then(start_parse_template(crate::syntax::parser::adv(&p1_pl), t_pm.clone(), tspan_pn.clone()), move |parse_template_24089: (crate::syntax::Template, crate::syntax::parser::Ps)| {
                            let (tpl_po, q_pp) = parse_template_24089;
                            prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ETemplate(tpl_po.clone())), span: crate::syntax::parser::to(&start_p4, &tspan_pn) }, false, q_pp.clone()))
                        })
                    },
                    _ => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::fail(&p1_pl))),
                }
            },
            m22385_13 if (m22385_13 == &Text::lit("then")) => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_p0, &start_p4, &Text::lit("`then` belongs to a hold: `$x <- start then step`")))),
            m22385_14 if (m22385_14 == &Text::lit("else")) => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_p0, &start_p4, &Text::lit("`else` without its `if`")))),
            m22385_15 if (m22385_15 == &Text::lit("ignore")) => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_p0, &start_p4, &Text::lit("`ignore` stands only inside a pattern or as the left side of a bind")))),
            m22385_16 if (m22385_16 == &Text::lit("return")) => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_at(p_p0, &start_p4, &Text::lit("`return` ends a monad block, as its last statement")))),
            _ => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), false, crate::syntax::parser::error_here(p_p0, &Text::lit("expected an expression")))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start KeywordPrimary, x`: what the function value is when passed to `@Run`.
pub fn start_keyword_primary(p_p0: crate::syntax::parser::Ps, w_p1: Text, sigils_p2: Text, commas_p3: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, bool, crate::syntax::parser::Ps)>> {
    Rc::new(KeywordPrimary { p_p0, w_p1, sigils_p2, commas_p3 })
}

/// ```prism
/// Took: fn ((Expr, Ps)) -> ((Expr, Bool, Ps))
/// ```
pub fn took(arg0: &(crate::syntax::Expr, crate::syntax::parser::Ps)) -> (crate::syntax::Expr, bool, crate::syntax::parser::Ps) {
    match arg0 {
        (e_p0, p_p1) => (e_p0.clone(), true, p_p1.clone()),
    }
}

/// ```prism
/// ParseLiteral: unbounded fn Ps -> ((Literal, Ps))
/// ```
pub fn parse_literal(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Literal, crate::syntax::parser::Ps) {
    let span_p1 = crate::syntax::parser::here(p_p0);
    let p1_p2 = crate::syntax::parser::adv(p_p0);
    match crate::syntax::parser::kind(p_p0) {
        crate::syntax::lexer::TokKind::KInt(s_p3, t_p4) => (crate::syntax::Literal { marks: s_p3, kind: crate::syntax::LitKind::LInt(t_p4), span: span_p1.clone() }, p1_p2.clone()),
        crate::syntax::lexer::TokKind::KFloat(s_p5, t_p6) => (crate::syntax::Literal { marks: s_p5, kind: crate::syntax::LitKind::LFloat(t_p6), span: span_p1.clone() }, p1_p2.clone()),
        crate::syntax::lexer::TokKind::KDuration(s_p7, n_p8, u_p9) => (crate::syntax::Literal { marks: s_p7, kind: crate::syntax::LitKind::LDuration(n_p8, u_p9), span: span_p1.clone() }, p1_p2.clone()),
        crate::syntax::lexer::TokKind::KChar(s_pa, c_pb) => (crate::syntax::Literal { marks: s_pa, kind: crate::syntax::LitKind::LChar(c_pb), span: span_p1.clone() }, p1_p2.clone()),
        crate::syntax::lexer::TokKind::KRegex(s_pc, r_pd) => (crate::syntax::Literal { marks: s_pc, kind: crate::syntax::LitKind::LRegex(r_pd), span: span_p1.clone() }, p1_p2.clone()),
        crate::syntax::lexer::TokKind::KText(s_pe, segs_pf) => {
            let (out_pj, q_pk) = run_to_end(fold_job(segs_pf.clone(), (Array::new(), p1_p2.clone()), Rc::new(move |(p0, p1): ((Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps), crate::syntax::lexer::TextSegTok)| entered(once_job(move || {
                let (acc_pg, pp_ph) = p0;
                let seg_pi = p1;
                prism_rtl::Turn::More(Rc::new(TextSegment { acc_p0: acc_pg.clone(), p_p1: pp_ph.clone(), text_seg_tok2: seg_pi.clone() }))
            }))) as Rc<dyn Fn(((Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps), crate::syntax::lexer::TextSegTok)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps)>>>));
            (crate::syntax::Literal { marks: s_pe.clone(), kind: crate::syntax::LitKind::LText(out_pj.clone()), span: span_p1.clone() }, q_pk.clone())
        },
        _ => (crate::syntax::Literal { marks: Text::lit(""), kind: crate::syntax::LitKind::LInt(Text::lit("")), span: span_p1.clone() }, crate::syntax::parser::error_at(&p1_p2, &span_p1, &Text::lit("expected a literal"))),
    }
}

/// The step machine of `ParseLiteral`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseLiteral: unbounded fn Ps -> ((Literal, Ps))
/// ```
pub struct ParseLiteral {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Literal, crate::syntax::parser::Ps)> for ParseLiteral {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Literal, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let span_p1 = crate::syntax::parser::here(p_p0);
        let p1_p2 = crate::syntax::parser::adv(p_p0);
        match crate::syntax::parser::kind(p_p0) {
            crate::syntax::lexer::TokKind::KInt(s_p3, t_p4) => prism_rtl::Turn::Finished((crate::syntax::Literal { marks: s_p3.clone(), kind: crate::syntax::LitKind::LInt(t_p4.clone()), span: span_p1.clone() }, p1_p2.clone())),
            crate::syntax::lexer::TokKind::KFloat(s_p5, t_p6) => prism_rtl::Turn::Finished((crate::syntax::Literal { marks: s_p5.clone(), kind: crate::syntax::LitKind::LFloat(t_p6.clone()), span: span_p1.clone() }, p1_p2.clone())),
            crate::syntax::lexer::TokKind::KDuration(s_p7, n_p8, u_p9) => prism_rtl::Turn::Finished((crate::syntax::Literal { marks: s_p7.clone(), kind: crate::syntax::LitKind::LDuration(n_p8.clone(), u_p9.clone()), span: span_p1.clone() }, p1_p2.clone())),
            crate::syntax::lexer::TokKind::KChar(s_pa, c_pb) => prism_rtl::Turn::Finished((crate::syntax::Literal { marks: s_pa.clone(), kind: crate::syntax::LitKind::LChar(c_pb.clone()), span: span_p1.clone() }, p1_p2.clone())),
            crate::syntax::lexer::TokKind::KRegex(s_pc, r_pd) => prism_rtl::Turn::Finished((crate::syntax::Literal { marks: s_pc.clone(), kind: crate::syntax::LitKind::LRegex(r_pd.clone()), span: span_p1.clone() }, p1_p2.clone())),
            crate::syntax::lexer::TokKind::KText(s_pe, segs_pf) => call_value(fold_job(segs_pf.clone(), (Array::new(), p1_p2.clone()), Rc::new(move |(p0, p1): ((Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps), crate::syntax::lexer::TextSegTok)| entered(once_job(move || {
                let (acc_pg, pp_ph) = p0;
                let seg_pi = p1;
                prism_rtl::Turn::More(Rc::new(TextSegment { acc_p0: acc_pg.clone(), p_p1: pp_ph.clone(), text_seg_tok2: seg_pi.clone() }))
            }))) as Rc<dyn Fn(((Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps), crate::syntax::lexer::TextSegTok)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps)>>>), move |fold_25477: (Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps)| {
                let (out_pj, q_pk) = fold_25477;
                prism_rtl::Turn::Finished((crate::syntax::Literal { marks: s_pe.clone(), kind: crate::syntax::LitKind::LText(out_pj.clone()), span: span_p1.clone() }, q_pk.clone()))
            }),
            _ => prism_rtl::Turn::Finished((crate::syntax::Literal { marks: Text::lit(""), kind: crate::syntax::LitKind::LInt(Text::lit("")), span: span_p1.clone() }, crate::syntax::parser::error_at(&p1_p2, &span_p1, &Text::lit("expected a literal")))),
        }
    }
}

/// `Start ParseLiteral, x`: what the function value is when passed to `@Run`.
pub fn start_parse_literal(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Literal, crate::syntax::parser::Ps)>> {
    Rc::new(ParseLiteral { p_p0 })
}

/// ```prism
/// TextSegment: unbounded fn [TextSeg], Ps, TextSegTok -> (([TextSeg], Ps))
/// ```
pub fn text_segment(acc_p0: &Array<crate::syntax::TextSeg>, p_p1: &crate::syntax::parser::Ps, text_seg_tok2: &crate::syntax::lexer::TextSegTok) -> (Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps) {
    match text_seg_tok2 {
        crate::syntax::lexer::TextSegTok::TsPlain(s_p2) => (push(acc_p0, &crate::syntax::TextSeg::SegPlain(s_p2.clone())), p_p1.clone()),
        crate::syntax::lexer::TextSegTok::TsPlaceholder(toks_p5, span_p6) => {
            let (e_p7, q_p8) = parse_nested(p_p1, toks_p5, span_p6);
            (push(acc_p0, &crate::syntax::TextSeg::SegPlaceholder(e_p7.clone())), q_p8.clone())
        },
    }
}

/// The step machine of `TextSegment`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TextSegment: unbounded fn [TextSeg], Ps, TextSegTok -> (([TextSeg], Ps))
/// ```
pub struct TextSegment {
    pub acc_p0: Array<crate::syntax::TextSeg>,
    pub p_p1: crate::syntax::parser::Ps,
    pub text_seg_tok2: crate::syntax::lexer::TextSegTok,
}

impl prism_rtl::Job<(Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps)> for TextSegment {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps)> {
        let acc_p0 = &self.acc_p0;
        let p_p1 = &self.p_p1;
        let text_seg_tok2 = &self.text_seg_tok2;
        match text_seg_tok2 {
            crate::syntax::lexer::TextSegTok::TsPlain(s_p2) => prism_rtl::Turn::Finished((push(acc_p0, &crate::syntax::TextSeg::SegPlain(s_p2.clone())), p_p1.clone())),
            crate::syntax::lexer::TextSegTok::TsPlaceholder(toks_p5, span_p6) => {
                let acc_p0 = acc_p0.clone();
                let p_p1 = p_p1.clone();
                let span_p6 = span_p6.clone();
                let toks_p5 = toks_p5.clone();
                call_then(start_parse_nested(p_p1.clone(), toks_p5.clone(), span_p6.clone()), move |parse_nested_25935: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (e_p7, q_p8) = parse_nested_25935;
                    prism_rtl::Turn::Finished((push(&acc_p0, &crate::syntax::TextSeg::SegPlaceholder(e_p7.clone())), q_p8.clone()))
                })
            },
        }
    }
}

/// `Start TextSegment, x`: what the function value is when passed to `@Run`.
pub fn start_text_segment(acc_p0: Array<crate::syntax::TextSeg>, p_p1: crate::syntax::parser::Ps, text_seg_tok2: crate::syntax::lexer::TextSegTok) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::TextSeg>, crate::syntax::parser::Ps)>> {
    Rc::new(TextSegment { acc_p0, p_p1, text_seg_tok2 })
}

/// ```prism
/// ParseNested: unbounded fn Ps, [Tok], Range -> ((Expr, Ps))
/// ```
pub fn parse_nested(p_p0: &crate::syntax::parser::Ps, toks_p1: &Array<crate::syntax::lexer::Tok>, span_p2: &crate::syntax::Range) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let sub_p3 = crate::syntax::parser::with_step_mode(&crate::syntax::parser::sub(p_p0, toks_p1, &crate::syntax::parser::at_end(span_p2)), &false);
    let (e_p7, s1_p8) = parse_rhs_expr(&sub_p3);
    let s2_p4 = if !s1_p8.bad && !crate::syntax::parser::at_eof(&s1_p8) {
        crate::syntax::parser::note_error(&s1_p8, &crate::syntax::parser::here(&s1_p8), &Text::from(format!("expected the end of the placeholder, found {}", &crate::syntax::parser::describe(&crate::syntax::parser::kind(&s1_p8)))))
    } else {
        s1_p8.clone()
    };
    let s3_p5 = if s2_p4.bad && (&len(&s2_p4.diags) == &Nat::from(0u32)) {
        crate::syntax::parser::note_error(&crate::syntax::parser::unbad(&s2_p4), span_p2, &Text::lit("expected an expression in the placeholder"))
    } else {
        s2_p4.clone()
    };
    let q_p6 = crate::syntax::parser::absorb(p_p0, &s3_p5);
    if s1_p8.bad {
        (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span_p2.clone() }, q_p6.clone())
    } else {
        (e_p7.clone(), q_p6.clone())
    }
}

/// The step machine of `ParseNested`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseNested: unbounded fn Ps, [Tok], Range -> ((Expr, Ps))
/// ```
pub struct ParseNested {
    pub p_p0: crate::syntax::parser::Ps,
    pub toks_p1: Array<crate::syntax::lexer::Tok>,
    pub span_p2: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseNested {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let toks_p1 = &self.toks_p1;
        let span_p2 = &self.span_p2;
        let p_p0 = p_p0.clone();
        let span_p2 = span_p2.clone();
        let toks_p1 = toks_p1.clone();
        call_then(crate::syntax::parser::start_sub(p_p0.clone(), toks_p1.clone(), crate::syntax::parser::at_end(&span_p2)), move |sub_26258: crate::syntax::parser::Ps| {
            let sub_p3 = crate::syntax::parser::with_step_mode(&sub_26258, &false);
            call_then(start_parse_rhs_expr(sub_p3.clone()), move |parse_rhs_expr_26312: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                let (e_p7, s1_p8) = parse_rhs_expr_26312;
                let s2_p4 = if !s1_p8.bad && !crate::syntax::parser::at_eof(&s1_p8) {
                    crate::syntax::parser::note_error(&s1_p8, &crate::syntax::parser::here(&s1_p8), &Text::from(format!("expected the end of the placeholder, found {}", &crate::syntax::parser::describe(&crate::syntax::parser::kind(&s1_p8)))))
                } else {
                    s1_p8.clone()
                };
                let s3_p5 = if s2_p4.bad && (&len(&s2_p4.diags) == &Nat::from(0u32)) {
                    crate::syntax::parser::note_error(&crate::syntax::parser::unbad(&s2_p4), &span_p2, &Text::lit("expected an expression in the placeholder"))
                } else {
                    s2_p4.clone()
                };
                let q_p6 = crate::syntax::parser::absorb(&p_p0, &s3_p5);
                if s1_p8.bad {
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: span_p2.clone() }, q_p6.clone()))
                } else {
                    prism_rtl::Turn::Finished((e_p7.clone(), q_p6.clone()))
                }
            })
        })
    }
}

/// `Start ParseNested, x`: what the function value is when passed to `@Run`.
pub fn start_parse_nested(p_p0: crate::syntax::parser::Ps, toks_p1: Array<crate::syntax::lexer::Tok>, span_p2: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(ParseNested { p_p0, toks_p1, span_p2 })
}

/// ```prism
/// ParseTemplate: unbounded fn Ps, TemplateTok, Range -> ((Template, Ps))
/// ```
pub fn parse_template(p0_p0: &crate::syntax::parser::Ps, t_p1: &crate::syntax::lexer::TemplateTok, span_p2: &crate::syntax::Range) -> (crate::syntax::Template, crate::syntax::parser::Ps) {
    let p1_p3 = if (&t_p1.delims == &Text::lit("single")) && (&t_p1.keyword != &Text::lit("Raw")) {
        crate::syntax::parser::out_of_scope(p0_p0, span_p2, &Text::lit("the template notation"), &Text::from(format!("a `<{}>` template is the template notation for an element language, out of this compiler (code templates only)", &t_p1.lang)))
    } else {
        p0_p0.clone()
    };
    let p2_p4 = if &t_p1.keyword == &Text::lit("File") {
        crate::syntax::parser::out_of_scope(&p1_p3, span_p2, &Text::lit("the template notation"), &Text::lit("a file whose first token is a language tag is a template file, out of this compiler (code templates only)"))
    } else {
        p1_p3.clone()
    };
    let (parts_p5, p3_p6) = template_parts(&p2_p4, &t_p1.parts);
    (crate::syntax::Template { keyword: t_p1.keyword.clone(), lang: t_p1.lang.clone(), delims: t_p1.delims.clone(), parts: parts_p5.clone(), span: span_p2.clone() }, p3_p6.clone())
}

/// The step machine of `ParseTemplate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTemplate: unbounded fn Ps, TemplateTok, Range -> ((Template, Ps))
/// ```
pub struct ParseTemplate {
    pub p0_p0: crate::syntax::parser::Ps,
    pub t_p1: crate::syntax::lexer::TemplateTok,
    pub span_p2: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::syntax::Template, crate::syntax::parser::Ps)> for ParseTemplate {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Template, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let t_p1 = &self.t_p1;
        let span_p2 = &self.span_p2;
        let p1_p3 = if (&t_p1.delims == &Text::lit("single")) && (&t_p1.keyword != &Text::lit("Raw")) {
            crate::syntax::parser::out_of_scope(p0_p0, span_p2, &Text::lit("the template notation"), &Text::from(format!("a `<{}>` template is the template notation for an element language, out of this compiler (code templates only)", &t_p1.lang)))
        } else {
            p0_p0.clone()
        };
        let p2_p4 = if &t_p1.keyword == &Text::lit("File") {
            crate::syntax::parser::out_of_scope(&p1_p3, span_p2, &Text::lit("the template notation"), &Text::lit("a file whose first token is a language tag is a template file, out of this compiler (code templates only)"))
        } else {
            p1_p3.clone()
        };
        let span_p2 = span_p2.clone();
        let t_p1 = t_p1.clone();
        call_then(start_template_parts(p2_p4.clone(), t_p1.parts.clone()), move |template_parts_27307: (Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)| {
            let (parts_p5, p3_p6) = template_parts_27307;
            prism_rtl::Turn::Finished((crate::syntax::Template { keyword: t_p1.keyword.clone(), lang: t_p1.lang.clone(), delims: t_p1.delims.clone(), parts: parts_p5.clone(), span: span_p2.clone() }, p3_p6.clone()))
        })
    }
}

/// `Start ParseTemplate, x`: what the function value is when passed to `@Run`.
pub fn start_parse_template(p0_p0: crate::syntax::parser::Ps, t_p1: crate::syntax::lexer::TemplateTok, span_p2: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::syntax::Template, crate::syntax::parser::Ps)>> {
    Rc::new(ParseTemplate { p0_p0, t_p1, span_p2 })
}

/// ```prism
/// TemplateParts: unbounded fn Ps, [TPartTok] -> (([TemplatePart], Ps))
/// ```
pub fn template_parts(p_p0: &crate::syntax::parser::Ps, parts_p1: &Array<crate::syntax::lexer::TPartTok>) -> (Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps) {
    run_to_end(fold_job(parts_p1.clone(), (Array::new(), p_p0.clone()), Rc::new(move |(p0, p1): ((Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps), crate::syntax::lexer::TPartTok)| entered(once_job(move || {
        let (acc_p2, q_p3) = p0;
        let part_p4 = p1;
        prism_rtl::Turn::More(Rc::new(TemplatePartOf { acc_p0: acc_p2.clone(), p_p1: q_p3.clone(), tpart_tok2: part_p4.clone() }))
    }))) as Rc<dyn Fn(((Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps), crate::syntax::lexer::TPartTok)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)>>>))
}

/// The step machine of `TemplateParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateParts: unbounded fn Ps, [TPartTok] -> (([TemplatePart], Ps))
/// ```
pub struct TemplateParts {
    pub p_p0: crate::syntax::parser::Ps,
    pub parts_p1: Array<crate::syntax::lexer::TPartTok>,
}

impl prism_rtl::Job<(Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)> for TemplateParts {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let parts_p1 = &self.parts_p1;
        fold_job(parts_p1.clone(), (Array::new(), p_p0.clone()), Rc::new(move |(p0, p1): ((Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps), crate::syntax::lexer::TPartTok)| entered(once_job(move || {
            let (acc_p2, q_p3) = p0;
            let part_p4 = p1;
            prism_rtl::Turn::More(Rc::new(TemplatePartOf { acc_p0: acc_p2.clone(), p_p1: q_p3.clone(), tpart_tok2: part_p4.clone() }))
        }))) as Rc<dyn Fn(((Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps), crate::syntax::lexer::TPartTok)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)>>>).cycle()
    }
}

/// `Start TemplateParts, x`: what the function value is when passed to `@Run`.
pub fn start_template_parts(p_p0: crate::syntax::parser::Ps, parts_p1: Array<crate::syntax::lexer::TPartTok>) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)>> {
    Rc::new(TemplateParts { p_p0, parts_p1 })
}

/// ```prism
/// TemplatePartOf: unbounded fn [TemplatePart], Ps, TPartTok -> (([TemplatePart], Ps))
/// ```
pub fn template_part_of(acc_p0: &Array<crate::syntax::TemplatePart>, p_p1: &crate::syntax::parser::Ps, tpart_tok2: &crate::syntax::lexer::TPartTok) -> (Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps) {
    match tpart_tok2 {
        crate::syntax::lexer::TPartTok::TptText(s_p2) => (push(acc_p0, &crate::syntax::TemplatePart::TpText(s_p2.clone())), p_p1.clone()),
        crate::syntax::lexer::TPartTok::TptPlaceholder(toks_p5, col_o6, span_p7) => {
            let (e_p8, q_p9) = parse_nested(p_p1, toks_p5, span_p7);
            (push(acc_p0, &crate::syntax::TemplatePart::TpPlaceholder(e_p8.clone(), col_o6.clone())), q_p9.clone())
        },
        crate::syntax::lexer::TPartTok::TptBlock(toks_pc, span_pd) => {
            let sub_pe = crate::syntax::parser::sub(p_p1, toks_pc, &crate::syntax::parser::at_end(span_pd));
            let (block_pf, s1_pg) = crate::syntax::parser::blocks::parse_block_until_eof(&sub_pe, span_pd);
            (push(acc_p0, &crate::syntax::TemplatePart::TpBlock(block_pf.clone())), crate::syntax::parser::absorb(p_p1, &s1_pg))
        },
        crate::syntax::lexer::TPartTok::TptCall(name_pj, attrs_pk, body_ol, span_pm) => {
            let sname_pn = crate::syntax::SName { sigils: name_pj.sigils.clone(), path_: name_pj.path_.clone(), span: span_pm.clone() };
            let (args_pr, p1_ps) = run_to_end(fold_job(attrs_pk.clone(), (Array::new(), p_p1.clone()), Rc::new(move |(p0, p1): ((Array<crate::syntax::Arg>, crate::syntax::parser::Ps), crate::syntax::lexer::AttrTok)| entered(once_job(move || {
                let (done_po, q_pp) = p0;
                let a_pq = p1;
                prism_rtl::Turn::More(Rc::new(AttrArg { done_p0: done_po.clone(), p_p1: q_pp.clone(), a_p2: a_pq.clone() }))
            }))) as Rc<dyn Fn(((Array<crate::syntax::Arg>, crate::syntax::parser::Ps), crate::syntax::lexer::AttrTok)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Arg>, crate::syntax::parser::Ps)>>>));
            let (inner_o10, p2_p11) = match body_ol {
                Some(b_pt) => {
                    let (ps_pu, q_pv) = template_parts(&p1_ps, b_pt);
                    (Some(ps_pu.clone()), q_pv.clone())
                },
                None => (None, p1_ps.clone()),
            };
            (push(acc_p0, &crate::syntax::TemplatePart::TpCall(sname_pn.clone(), args_pr.clone(), inner_o10.clone(), span_pm.clone())), p2_p11.clone())
        },
    }
}

/// The step machine of `TemplatePartOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplatePartOf: unbounded fn [TemplatePart], Ps, TPartTok -> (([TemplatePart], Ps))
/// ```
pub struct TemplatePartOf {
    pub acc_p0: Array<crate::syntax::TemplatePart>,
    pub p_p1: crate::syntax::parser::Ps,
    pub tpart_tok2: crate::syntax::lexer::TPartTok,
}

impl prism_rtl::Job<(Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)> for TemplatePartOf {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)> {
        let acc_p0 = &self.acc_p0;
        let p_p1 = &self.p_p1;
        let tpart_tok2 = &self.tpart_tok2;
        match tpart_tok2 {
            crate::syntax::lexer::TPartTok::TptText(s_p2) => prism_rtl::Turn::Finished((push(acc_p0, &crate::syntax::TemplatePart::TpText(s_p2.clone())), p_p1.clone())),
            crate::syntax::lexer::TPartTok::TptPlaceholder(toks_p5, col_o6, span_p7) => {
                let col_o6 = col_o6.clone();
                let acc_p0 = acc_p0.clone();
                let p_p1 = p_p1.clone();
                let span_p7 = span_p7.clone();
                let toks_p5 = toks_p5.clone();
                call_then(start_parse_nested(p_p1.clone(), toks_p5.clone(), span_p7.clone()), move |parse_nested_27833: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (e_p8, q_p9) = parse_nested_27833;
                    prism_rtl::Turn::Finished((push(&acc_p0, &crate::syntax::TemplatePart::TpPlaceholder(e_p8.clone(), col_o6.clone())), q_p9.clone()))
                })
            },
            crate::syntax::lexer::TPartTok::TptBlock(toks_pc, span_pd) => {
                let acc_p0 = acc_p0.clone();
                let p_p1 = p_p1.clone();
                let span_pd = span_pd.clone();
                let toks_pc = toks_pc.clone();
                call_then(crate::syntax::parser::start_sub(p_p1.clone(), toks_pc.clone(), crate::syntax::parser::at_end(&span_pd)), move |sub_27969: crate::syntax::parser::Ps| {
                    let sub_pe = sub_27969;
                    call_then(crate::syntax::parser::blocks::start_parse_block_until_eof(sub_pe.clone(), span_pd.clone()), move |parse_block_until_eof_28019: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                        let (block_pf, s1_pg) = parse_block_until_eof_28019;
                        prism_rtl::Turn::Finished((push(&acc_p0, &crate::syntax::TemplatePart::TpBlock(block_pf.clone())), crate::syntax::parser::absorb(&p_p1, &s1_pg)))
                    })
                })
            },
            crate::syntax::lexer::TPartTok::TptCall(name_pj, attrs_pk, body_ol, span_pm) => {
                let sname_pn = crate::syntax::SName { sigils: name_pj.sigils.clone(), path_: name_pj.path_.clone(), span: span_pm.clone() };
                let body_ol = body_ol.clone();
                let acc_p0 = acc_p0.clone();
                let attrs_pk = attrs_pk.clone();
                let p_p1 = p_p1.clone();
                let span_pm = span_pm.clone();
                call_value(fold_job(attrs_pk.clone(), (Array::new(), p_p1.clone()), Rc::new(move |(p0, p1): ((Array<crate::syntax::Arg>, crate::syntax::parser::Ps), crate::syntax::lexer::AttrTok)| entered(once_job(move || {
                    let (done_po, q_pp) = p0;
                    let a_pq = p1;
                    prism_rtl::Turn::More(Rc::new(AttrArg { done_p0: done_po.clone(), p_p1: q_pp.clone(), a_p2: a_pq.clone() }))
                }))) as Rc<dyn Fn(((Array<crate::syntax::Arg>, crate::syntax::parser::Ps), crate::syntax::lexer::AttrTok)) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Arg>, crate::syntax::parser::Ps)>>>), move |fold_28254: (Array<crate::syntax::Arg>, crate::syntax::parser::Ps)| {
                    let (args_pr, p1_ps) = fold_28254;
                    let (inner_o10, p2_p11) = match &body_ol {
                        Some(b_pt) => {
                            let (ps_pu, q_pv) = template_parts(&p1_ps, b_pt);
                            (Some(ps_pu.clone()), q_pv.clone())
                        },
                        None => (None, p1_ps.clone()),
                    };
                    prism_rtl::Turn::Finished((push(&acc_p0, &crate::syntax::TemplatePart::TpCall(sname_pn.clone(), args_pr.clone(), inner_o10.clone(), span_pm.clone())), p2_p11.clone()))
                })
            },
        }
    }
}

/// `Start TemplatePartOf, x`: what the function value is when passed to `@Run`.
pub fn start_template_part_of(acc_p0: Array<crate::syntax::TemplatePart>, p_p1: crate::syntax::parser::Ps, tpart_tok2: crate::syntax::lexer::TPartTok) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::TemplatePart>, crate::syntax::parser::Ps)>> {
    Rc::new(TemplatePartOf { acc_p0, p_p1, tpart_tok2 })
}

/// ```prism
/// AttrArg: unbounded fn [Arg], Ps, AttrTok -> (([Arg], Ps))
/// ```
pub fn attr_arg(done_p0: &Array<crate::syntax::Arg>, p_p1: &crate::syntax::parser::Ps, a_p2: &crate::syntax::lexer::AttrTok) -> (Array<crate::syntax::Arg>, crate::syntax::parser::Ps) {
    let (value_p3, q_p4) = parse_nested(p_p1, &a_p2.tokens, &a_p2.span);
    (push(done_p0, &crate::syntax::Arg { name: Some(crate::syntax::Ident { name: a_p2.name.clone(), span: a_p2.span.clone() }), value: value_p3.clone(), span: a_p2.span.clone() }), q_p4.clone())
}

/// The step machine of `AttrArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AttrArg: unbounded fn [Arg], Ps, AttrTok -> (([Arg], Ps))
/// ```
pub struct AttrArg {
    pub done_p0: Array<crate::syntax::Arg>,
    pub p_p1: crate::syntax::parser::Ps,
    pub a_p2: crate::syntax::lexer::AttrTok,
}

impl prism_rtl::Job<(Array<crate::syntax::Arg>, crate::syntax::parser::Ps)> for AttrArg {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::Arg>, crate::syntax::parser::Ps)> {
        let done_p0 = &self.done_p0;
        let p_p1 = &self.p_p1;
        let a_p2 = &self.a_p2;
        let a_p2 = a_p2.clone();
        let done_p0 = done_p0.clone();
        let p_p1 = p_p1.clone();
        call_then(start_parse_nested(p_p1.clone(), a_p2.tokens.clone(), a_p2.span.clone()), move |parse_nested_28628: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
            let (value_p3, q_p4) = parse_nested_28628;
            prism_rtl::Turn::Finished((push(&done_p0, &crate::syntax::Arg { name: Some(crate::syntax::Ident { name: a_p2.name.clone(), span: a_p2.span.clone() }), value: value_p3.clone(), span: a_p2.span.clone() }), q_p4.clone()))
        })
    }
}

/// `Start AttrArg, x`: what the function value is when passed to `@Run`.
pub fn start_attr_arg(done_p0: Array<crate::syntax::Arg>, p_p1: crate::syntax::parser::Ps, a_p2: crate::syntax::lexer::AttrTok) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Arg>, crate::syntax::parser::Ps)>> {
    Rc::new(AttrArg { done_p0, p_p1, a_p2 })
}

/// ```prism
/// ParseLambda: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_lambda(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here(p0_p0);
    let p_p2 = crate::syntax::parser::adv(p0_p0);
    let (params_o3, p1_p4) = if &crate::syntax::parser::kind(&p_p2) == &crate::syntax::lexer::TokKind::KLambdaBar(true) {
        lambda_params(&crate::syntax::parser::adv(&p_p2))
    } else {
        (None, p_p2.clone())
    };
    if crate::syntax::parser::at_open_l(&p1_p4) {
        {
            let (block_p5, q_p6) = crate::syntax::parser::blocks::parse_indented_block(&p1_p4);
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELambda(params_o3.clone(), Rc::new(crate::syntax::LambdaBody::LbBlock(block_p5.clone())))), span: crate::syntax::parser::to(&start_p1, &block_p5.span) }, q_p6.clone())
        }
    } else {
        {
            let (body_p7, q_p8) = parse_expr(&p1_p4);
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELambda(params_o3.clone(), Rc::new(crate::syntax::LambdaBody::LbExpr(Rc::new(body_p7.clone()))))), span: crate::syntax::parser::to(&start_p1, &body_p7.span) }, q_p8.clone())
        }
    }
}

/// The step machine of `ParseLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseLambda: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseLambda {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseLambda {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let start_p1 = crate::syntax::parser::here(p0_p0);
        let p_p2 = crate::syntax::parser::adv(p0_p0);
        let (params_o3, p1_p4) = if &crate::syntax::parser::kind(&p_p2) == &crate::syntax::lexer::TokKind::KLambdaBar(true) {
            lambda_params(&crate::syntax::parser::adv(&p_p2))
        } else {
            (None, p_p2.clone())
        };
        if crate::syntax::parser::at_open_l(&p1_p4) {
            call_then(crate::syntax::parser::blocks::start_parse_indented_block(p1_p4.clone()), move |parse_indented_block_29257: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                let (block_p5, q_p6) = parse_indented_block_29257;
                prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELambda(params_o3.clone(), Rc::new(crate::syntax::LambdaBody::LbBlock(block_p5.clone())))), span: crate::syntax::parser::to(&start_p1, &block_p5.span) }, q_p6.clone()))
            })
        } else {
            call_then(start_parse_expr(p1_p4.clone()), move |parse_expr_29405: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                let (body_p7, q_p8) = parse_expr_29405;
                prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::ELambda(params_o3.clone(), Rc::new(crate::syntax::LambdaBody::LbExpr(Rc::new(body_p7.clone()))))), span: crate::syntax::parser::to(&start_p1, &body_p7.span) }, q_p8.clone()))
            })
        }
    }
}

/// `Start ParseLambda, x`: what the function value is when passed to `@Run`.
pub fn start_parse_lambda(p0_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(ParseLambda { p0_p0 })
}

/// ```prism
/// LambdaParams: unbounded fn Ps -> ((?[Pattern], Ps))
/// ```
pub fn lambda_params(p_p0: &crate::syntax::parser::Ps) -> (Option<Array<crate::syntax::Pattern_>>, crate::syntax::parser::Ps) {
    let (ps_p2, p1_p3) = if &crate::syntax::parser::kind(p_p0) == &crate::syntax::lexer::TokKind::KLambdaBar(false) {
        (Array::new(), p_p0.clone())
    } else {
        crate::syntax::parser::commas(p_p0, &(Rc::new(move |p0: crate::syntax::parser::Ps| entered(once_job(move || {
            let q_p1 = p0;
            prism_rtl::Turn::More(Rc::new(crate::syntax::parser::types::ParsePattern { p_p0: q_p1.clone(), commas0_p1: false }))
        }))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>>>))
    };
    if &crate::syntax::parser::kind(&p1_p3) == &crate::syntax::lexer::TokKind::KLambdaBar(false) {
        (Some(ps_p2.clone()), crate::syntax::parser::adv(&p1_p3))
    } else {
        (None, crate::syntax::parser::error_here(&p1_p3, &Text::lit("expected `|` to close the lambda\'s parameters")))
    }
}

/// The step machine of `LambdaParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LambdaParams: unbounded fn Ps -> ((?[Pattern], Ps))
/// ```
pub struct LambdaParams {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(Option<Array<crate::syntax::Pattern_>>, crate::syntax::parser::Ps)> for LambdaParams {
    fn cycle(&self) -> prism_rtl::Turn<(Option<Array<crate::syntax::Pattern_>>, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let (ps_p2, p1_p3) = if &crate::syntax::parser::kind(p_p0) == &crate::syntax::lexer::TokKind::KLambdaBar(false) {
            (Array::new(), p_p0.clone())
        } else {
            crate::syntax::parser::commas(p_p0, &(Rc::new(move |p0: crate::syntax::parser::Ps| entered(once_job(move || {
                let q_p1 = p0;
                prism_rtl::Turn::More(Rc::new(crate::syntax::parser::types::ParsePattern { p_p0: q_p1.clone(), commas0_p1: false }))
            }))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>>>))
        };
        if &crate::syntax::parser::kind(&p1_p3) == &crate::syntax::lexer::TokKind::KLambdaBar(false) {
            prism_rtl::Turn::Finished((Some(ps_p2.clone()), crate::syntax::parser::adv(&p1_p3)))
        } else {
            prism_rtl::Turn::Finished((None, crate::syntax::parser::error_here(&p1_p3, &Text::lit("expected `|` to close the lambda\'s parameters"))))
        }
    }
}

/// `Start LambdaParams, x`: what the function value is when passed to `@Run`.
pub fn start_lambda_params(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(Option<Array<crate::syntax::Pattern_>>, crate::syntax::parser::Ps)>> {
    Rc::new(LambdaParams { p_p0 })
}

/// ```prism
/// ParseCond: unbounded fn Ps, Bool -> ((Cond, Ps))
/// ```
pub fn parse_cond(p_p0: &crate::syntax::parser::Ps, allow_guard_p1: &bool) -> (crate::syntax::Cond, crate::syntax::parser::Ps) {
    let (pattern_p2, q_p3) = crate::syntax::parser::types::parse_pattern(p_p0, &true);
    if !q_p3.bad && crate::syntax::parser::at_op(&q_p3, &Text::lit("<-")) {
        {
            let (value_p4, q1_p5) = parse_expr(&crate::syntax::parser::adv(&q_p3));
            if *allow_guard_p1 && crate::syntax::parser::at_kw(&q1_p5, &Text::lit("if")) {
                {
                    let (guard_p6, q2_p7) = parse_expr(&crate::syntax::parser::adv(&q1_p5));
                    (crate::syntax::Cond::CondBind(pattern_p2.clone(), Rc::new(value_p4.clone()), Rc::new(Some(guard_p6.clone()))), q2_p7.clone())
                }
            } else {
                (crate::syntax::Cond::CondBind(pattern_p2.clone(), Rc::new(value_p4.clone()), Rc::new(None)), q1_p5.clone())
            }
        }
    } else {
        {
            let (e_p8, q1_p9) = parse_expr(p_p0);
            (crate::syntax::Cond::CondExpr(Rc::new(e_p8.clone())), q1_p9.clone())
        }
    }
}

/// The step machine of `ParseCond`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseCond: unbounded fn Ps, Bool -> ((Cond, Ps))
/// ```
pub struct ParseCond {
    pub p_p0: crate::syntax::parser::Ps,
    pub allow_guard_p1: bool,
}

impl prism_rtl::Job<(crate::syntax::Cond, crate::syntax::parser::Ps)> for ParseCond {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Cond, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let allow_guard_p1 = &self.allow_guard_p1;
        let allow_guard_p1 = *allow_guard_p1;
        let p_p0 = p_p0.clone();
        call_then(crate::syntax::parser::types::start_parse_pattern(p_p0.clone(), true), move |parse_pattern_29990: (crate::syntax::Pattern_, crate::syntax::parser::Ps)| {
            let (pattern_p2, q_p3) = parse_pattern_29990;
            if !q_p3.bad && crate::syntax::parser::at_op(&q_p3, &Text::lit("<-")) {
                call_then(start_parse_expr(crate::syntax::parser::adv(&q_p3)), move |parse_expr_30076: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (value_p4, q1_p5) = parse_expr_30076;
                    if allow_guard_p1 && crate::syntax::parser::at_kw(&q1_p5, &Text::lit("if")) {
                        call_then(start_parse_expr(crate::syntax::parser::adv(&q1_p5)), move |parse_expr_30169: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                            let (guard_p6, q2_p7) = parse_expr_30169;
                            prism_rtl::Turn::Finished((crate::syntax::Cond::CondBind(pattern_p2.clone(), Rc::new(value_p4.clone()), Rc::new(Some(guard_p6.clone()))), q2_p7.clone()))
                        })
                    } else {
                        prism_rtl::Turn::Finished((crate::syntax::Cond::CondBind(pattern_p2.clone(), Rc::new(value_p4.clone()), Rc::new(None)), q1_p5.clone()))
                    }
                })
            } else {
                call_then(start_parse_expr(p_p0.clone()), move |parse_expr_30332: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                    let (e_p8, q1_p9) = parse_expr_30332;
                    prism_rtl::Turn::Finished((crate::syntax::Cond::CondExpr(Rc::new(e_p8.clone())), q1_p9.clone()))
                })
            }
        })
    }
}

/// `Start ParseCond, x`: what the function value is when passed to `@Run`.
pub fn start_parse_cond(p_p0: crate::syntax::parser::Ps, allow_guard_p1: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Cond, crate::syntax::parser::Ps)>> {
    Rc::new(ParseCond { p_p0, allow_guard_p1 })
}

/// ```prism
/// ParseIf: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_if(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here(p0_p0);
    let (cond_p3, p1_p4) = parse_cond(&crate::syntax::parser::adv(p0_p0), &false);
    let (then_block_p5, p2_p6) = crate::syntax::parser::blocks::parse_block_after_colon(&p1_p4);
    let p3_p2 = if crate::syntax::parser::at_sep(&p2_p6) && is_else(&crate::syntax::parser::kind_at(&p2_p6, &Nat::from(1u32))) {
        crate::syntax::parser::adv(&p2_p6)
    } else {
        p2_p6.clone()
    };
    if crate::syntax::parser::at_kw(&p3_p2, &Text::lit("else")) {
        {
            let (else_block_p7, q_p8) = crate::syntax::parser::blocks::parse_block_after_colon(&crate::syntax::parser::adv(&p3_p2));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EIf(Rc::new(cond_p3.clone()), then_block_p5.clone(), Some(else_block_p7.clone()))), span: crate::syntax::parser::to(&start_p1, &else_block_p7.span) }, q_p8.clone())
        }
    } else {
        (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EIf(Rc::new(cond_p3.clone()), then_block_p5.clone(), None)), span: crate::syntax::parser::to(&start_p1, &then_block_p5.span) }, p3_p2.clone())
    }
}

/// The step machine of `ParseIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseIf: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseIf {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseIf {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let start_p1 = crate::syntax::parser::here(p0_p0);
        let p0_p0 = p0_p0.clone();
        call_then(start_parse_cond(crate::syntax::parser::adv(&p0_p0), false), move |parse_cond_30565: (crate::syntax::Cond, crate::syntax::parser::Ps)| {
            let (cond_p3, p1_p4) = parse_cond_30565;
            call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(p1_p4.clone()), move |parse_block_after_colon_30619: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                let (then_block_p5, p2_p6) = parse_block_after_colon_30619;
                let p3_p2 = if crate::syntax::parser::at_sep(&p2_p6) && is_else(&crate::syntax::parser::kind_at(&p2_p6, &Nat::from(1u32))) {
                    crate::syntax::parser::adv(&p2_p6)
                } else {
                    p2_p6.clone()
                };
                if crate::syntax::parser::at_kw(&p3_p2, &Text::lit("else")) {
                    call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(crate::syntax::parser::adv(&p3_p2)), move |parse_block_after_colon_30770: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                        let (else_block_p7, q_p8) = parse_block_after_colon_30770;
                        prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EIf(Rc::new(cond_p3.clone()), then_block_p5.clone(), Some(else_block_p7.clone()))), span: crate::syntax::parser::to(&start_p1, &else_block_p7.span) }, q_p8.clone()))
                    })
                } else {
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EIf(Rc::new(cond_p3.clone()), then_block_p5.clone(), None)), span: crate::syntax::parser::to(&start_p1, &then_block_p5.span) }, p3_p2.clone()))
                }
            })
        })
    }
}

/// `Start ParseIf, x`: what the function value is when passed to `@Run`.
pub fn start_parse_if(p0_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(ParseIf { p0_p0 })
}

/// ```prism
/// IsElse: fn TokKind -> Bool
/// ```
pub fn is_else(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KKw(c0_0_0, _) if (c0_0_0 == &Text::lit("else")) => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParseMatch: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_match(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here(p0_p0);
    let (scrutinee_p3, p1_p4) = parse_expr(&crate::syntax::parser::adv(p0_p0));
    let p2_p2 = crate::syntax::parser::expect_colon(&p1_p4);
    if crate::syntax::parser::at_open_l(&p2_p2) {
        {
            let (arms_p5, q_p6) = match_arms(&crate::syntax::parser::adv(&p2_p2));
            (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMatch(Rc::new(scrutinee_p3.clone()), arms_p5.clone())), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&q_p6)) }, q_p6.clone())
        }
    } else {
        (crate::syntax::parser::decls::no_expr(), crate::syntax::parser::error_here(&p2_p2, &Text::lit("a `match`\'s arms stand in an indented block after its `:`")))
    }
}

/// The step machine of `ParseMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseMatch: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseMatch {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseMatch {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let start_p1 = crate::syntax::parser::here(p0_p0);
        let p0_p0 = p0_p0.clone();
        call_then(start_parse_expr(crate::syntax::parser::adv(&p0_p0)), move |parse_expr_31351: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
            let (scrutinee_p3, p1_p4) = parse_expr_31351;
            let p2_p2 = crate::syntax::parser::expect_colon(&p1_p4);
            if crate::syntax::parser::at_open_l(&p2_p2) {
                call_then(start_match_arms(crate::syntax::parser::adv(&p2_p2)), move |match_arms_31443: (Array<crate::syntax::Arm>, crate::syntax::parser::Ps)| {
                    let (arms_p5, q_p6) = match_arms_31443;
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EMatch(Rc::new(scrutinee_p3.clone()), arms_p5.clone())), span: crate::syntax::parser::to(&start_p1, &crate::syntax::parser::prev(&q_p6)) }, q_p6.clone()))
                })
            } else {
                prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_expr(), crate::syntax::parser::error_here(&p2_p2, &Text::lit("a `match`\'s arms stand in an indented block after its `:`"))))
            }
        })
    }
}

/// `Start ParseMatch, x`: what the function value is when passed to `@Run`.
pub fn start_parse_match(p0_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(ParseMatch { p0_p0 })
}

/// ```prism
/// MatchArms: unbounded fn Ps -> (([Arm], Ps))
/// ```
pub fn match_arms(p0_p0: &crate::syntax::parser::Ps) -> (Array<crate::syntax::Arm>, crate::syntax::parser::Ps) {
    let mut this: (Array<crate::syntax::Arm>, crate::syntax::parser::Ps) = (Array::new(), p0_p0.clone());
    let mut arms_p1: Array<crate::syntax::Arm> = Array::new();
    let mut p_p2: crate::syntax::parser::Ps = p0_p0.clone();
    let mut going_p3: bool = true;
    while going_p3 {
        let (arm_p4, q_p5) = parse_arm(&p_p2);
        if !q_p5.bad {
            arms_p1 = push(&arms_p1, &arm_p4);
        }
        p_p2 = crate::syntax::parser::recovered(&q_p5);
        match &crate::syntax::parser::kind(&p_p2) {
            crate::syntax::lexer::TokKind::KLaySep => {
                p_p2 = crate::syntax::parser::adv(&p_p2);
            }
            crate::syntax::lexer::TokKind::KLayClose => {
                p_p2 = crate::syntax::parser::adv(&p_p2);
                going_p3 = false;
            }
            crate::syntax::lexer::TokKind::KEof => {
                going_p3 = false;
            }
            _ => {
                p_p2 = crate::syntax::parser::recover(&crate::syntax::parser::complain(&p_p2, &Text::lit("expected the end of the arm")));
            }
        }
    }
    this = (arms_p1.clone(), p_p2.clone());
    this
}

/// The step machine of `MatchArms`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MatchArms: unbounded fn Ps -> (([Arm], Ps))
/// ```
pub struct MatchArms {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(Array<crate::syntax::Arm>, crate::syntax::parser::Ps)> for MatchArms {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::Arm>, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let mut this: (Array<crate::syntax::Arm>, crate::syntax::parser::Ps) = (Array::new(), p0_p0.clone());
        let mut arms_p1: Array<crate::syntax::Arm> = Array::new();
        let mut p_p2: crate::syntax::parser::Ps = p0_p0.clone();
        let mut going_p3: bool = true;
        call_then(loop_job((this, arms_p1, going_p3, p_p2), move |(mut this, mut arms_p1, mut going_p3, mut p_p2): ((Array<crate::syntax::Arm>, crate::syntax::parser::Ps), Array<crate::syntax::Arm>, bool, crate::syntax::parser::Ps)| if going_p3 {
            {
                let (arm_p4, q_p5) = parse_arm(&p_p2);
                if !q_p5.bad {
                    arms_p1 = push(&arms_p1, &arm_p4);
                }
                p_p2 = crate::syntax::parser::recovered(&q_p5);
                match &crate::syntax::parser::kind(&p_p2) {
                    crate::syntax::lexer::TokKind::KLaySep => {
                        p_p2 = crate::syntax::parser::adv(&p_p2);
                    }
                    crate::syntax::lexer::TokKind::KLayClose => {
                        p_p2 = crate::syntax::parser::adv(&p_p2);
                        going_p3 = false;
                    }
                    crate::syntax::lexer::TokKind::KEof => {
                        going_p3 = false;
                    }
                    _ => {
                        p_p2 = crate::syntax::parser::recover(&crate::syntax::parser::complain(&p_p2, &Text::lit("expected the end of the arm")));
                    }
                }
                Ok((this, arms_p1, going_p3, p_p2))
            }
        } else {
            Err((this, arms_p1, going_p3, p_p2))
        }), move |(mut this, mut arms_p1, mut going_p3, mut p_p2): ((Array<crate::syntax::Arm>, crate::syntax::parser::Ps), Array<crate::syntax::Arm>, bool, crate::syntax::parser::Ps)| {
            this = (arms_p1.clone(), p_p2.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start MatchArms, x`: what the function value is when passed to `@Run`.
pub fn start_match_arms(p0_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::Arm>, crate::syntax::parser::Ps)>> {
    Rc::new(MatchArms { p0_p0 })
}

/// ```prism
/// ParseArm: unbounded fn Ps -> ((Arm, Ps))
/// ```
pub fn parse_arm(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Arm, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here(p_p0);
    if crate::syntax::parser::at_kw(p_p0, &Text::lit("otherwise")) {
        {
            let (body_p2, q_p3) = crate::syntax::parser::blocks::parse_block_after_colon(&crate::syntax::parser::adv(p_p0));
            (crate::syntax::Arm { pattern: None, guard: None, body: body_p2.clone(), span: crate::syntax::parser::to(&start_p1, &body_p2.span) }, q_p3.clone())
        }
    } else {
        if crate::syntax::parser::at_kw(p_p0, &Text::lit("ignore")) && (&crate::syntax::parser::kind_at(p_p0, &Nat::from(1u32)) == &crate::syntax::lexer::TokKind::KColon) {
            (crate::syntax::Arm { pattern: None, guard: None, body: crate::syntax::parser::decls::no_block(), span: start_p1.clone() }, crate::syntax::parser::error_at(p_p0, &crate::syntax::parser::here(p_p0), &Text::lit("an arm beginning `ignore:` would read as \"ignore these cases\": the catch-all is `otherwise:`")))
        } else {
            {
                let (pattern_p4, p1_p5) = crate::syntax::parser::types::parse_pattern(p_p0, &true);
                let (guard_o6, p2_p7) = if crate::syntax::parser::at_kw(&p1_p5, &Text::lit("if")) {
                    optional_expr(&crate::syntax::parser::adv(&p1_p5))
                } else {
                    (None, p1_p5.clone())
                };
                let (body_p8, p3_p9) = crate::syntax::parser::blocks::parse_block_after_colon(&p2_p7);
                (crate::syntax::Arm { pattern: Some(pattern_p4.clone()), guard: guard_o6.clone(), body: body_p8.clone(), span: crate::syntax::parser::to(&start_p1, &body_p8.span) }, p3_p9.clone())
            }
        }
    }
}

/// ```prism
/// OptionalExpr: unbounded fn Ps -> ((?Expr, Ps))
/// ```
pub fn optional_expr(p_p0: &crate::syntax::parser::Ps) -> (Option<crate::syntax::Expr>, crate::syntax::parser::Ps) {
    let (e_p1, q_p2) = parse_expr(p_p0);
    (Some(e_p1.clone()), q_p2.clone())
}

/// ```prism
/// ParseFor: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub fn parse_for(p0_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Expr, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here(p0_p0);
    let p_p2 = crate::syntax::parser::adv(p0_p0);
    let (binders_o3, p1_p4) = for_binders_of(&p_p2);
    let (source_p5, p2_p6) = parse_expr(&p1_p4);
    let (body_p7, p3_p8) = crate::syntax::parser::blocks::parse_block_after_colon(&p2_p6);
    (crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EFor(binders_o3.clone(), Rc::new(source_p5.clone()), body_p7.clone())), span: crate::syntax::parser::to(&start_p1, &body_p7.span) }, p3_p8.clone())
}

/// The step machine of `ParseFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseFor: unbounded fn Ps -> ((Expr, Ps))
/// ```
pub struct ParseFor {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)> for ParseFor {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Expr, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let start_p1 = crate::syntax::parser::here(p0_p0);
        let p_p2 = crate::syntax::parser::adv(p0_p0);
        call_then(start_for_binders_of(p_p2.clone()), move |for_binders_of_33299: (Option<crate::syntax::ForBinders>, crate::syntax::parser::Ps)| {
            let (binders_o3, p1_p4) = for_binders_of_33299;
            call_then(start_parse_expr(p1_p4.clone()), move |parse_expr_33339: (crate::syntax::Expr, crate::syntax::parser::Ps)| {
                let (source_p5, p2_p6) = parse_expr_33339;
                call_then(crate::syntax::parser::blocks::start_parse_block_after_colon(p2_p6.clone()), move |parse_block_after_colon_33375: (crate::syntax::Block, crate::syntax::parser::Ps)| {
                    let (body_p7, p3_p8) = parse_block_after_colon_33375;
                    prism_rtl::Turn::Finished((crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EFor(binders_o3.clone(), Rc::new(source_p5.clone()), body_p7.clone())), span: crate::syntax::parser::to(&start_p1, &body_p7.span) }, p3_p8.clone()))
                })
            })
        })
    }
}

/// `Start ParseFor, x`: what the function value is when passed to `@Run`.
pub fn start_parse_for(p0_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Expr, crate::syntax::parser::Ps)>> {
    Rc::new(ParseFor { p0_p0 })
}

/// ```prism
/// ForBindersOf: unbounded fn Ps -> ((?ForBinders, Ps))
/// ```
pub fn for_binders_of(p_p0: &crate::syntax::parser::Ps) -> (Option<crate::syntax::ForBinders>, crate::syntax::parser::Ps) {
    let (first_p1, q1_p2) = crate::syntax::parser::types::parse_pattern(p_p0, &false);
    let (second_o3, q2_p4) = if crate::syntax::parser::at_comma(&q1_p2) {
        optional_pattern(&crate::syntax::parser::adv(&q1_p2))
    } else {
        (None, q1_p2.clone())
    };
    if !q2_p4.bad && crate::syntax::parser::at_op(&q2_p4, &Text::lit("<-")) {
        (Some(crate::syntax::ForBinders { first: first_p1.clone(), second: second_o3.clone() }), crate::syntax::parser::adv(&q2_p4))
    } else {
        (None, p_p0.clone())
    }
}

/// The step machine of `ForBindersOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ForBindersOf: unbounded fn Ps -> ((?ForBinders, Ps))
/// ```
pub struct ForBindersOf {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(Option<crate::syntax::ForBinders>, crate::syntax::parser::Ps)> for ForBindersOf {
    fn cycle(&self) -> prism_rtl::Turn<(Option<crate::syntax::ForBinders>, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let p_p0 = p_p0.clone();
        call_then(crate::syntax::parser::types::start_parse_pattern(p_p0.clone(), false), move |parse_pattern_33660: (crate::syntax::Pattern_, crate::syntax::parser::Ps)| {
            let (first_p1, q1_p2) = parse_pattern_33660;
            let (second_o3, q2_p4) = if crate::syntax::parser::at_comma(&q1_p2) {
                optional_pattern(&crate::syntax::parser::adv(&q1_p2))
            } else {
                (None, q1_p2.clone())
            };
            if !q2_p4.bad && crate::syntax::parser::at_op(&q2_p4, &Text::lit("<-")) {
                prism_rtl::Turn::Finished((Some(crate::syntax::ForBinders { first: first_p1.clone(), second: second_o3.clone() }), crate::syntax::parser::adv(&q2_p4)))
            } else {
                prism_rtl::Turn::Finished((None, p_p0.clone()))
            }
        })
    }
}

/// `Start ForBindersOf, x`: what the function value is when passed to `@Run`.
pub fn start_for_binders_of(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(Option<crate::syntax::ForBinders>, crate::syntax::parser::Ps)>> {
    Rc::new(ForBindersOf { p_p0 })
}

/// ```prism
/// OptionalPattern: unbounded fn Ps -> ((?Pattern, Ps))
/// ```
pub fn optional_pattern(p_p0: &crate::syntax::parser::Ps) -> (Option<crate::syntax::Pattern_>, crate::syntax::parser::Ps) {
    let (pat_p1, q_p2) = crate::syntax::parser::types::parse_pattern(p_p0, &false);
    (Some(pat_p1.clone()), q_p2.clone())
}
