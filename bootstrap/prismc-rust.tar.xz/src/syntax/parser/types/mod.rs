//! The module `Syntax.Parser.Types`, from `target/bootstrap/src/prismc/syntax/parser/types.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `FieldsRead`:
///
/// ```prism
/// type FieldsRead = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct FieldsRead {
    pub fields_p: crate::prelude::Array<crate::syntax::FieldPat>,
    pub rest_p: bool,
    pub p_p: crate::syntax::parser::Ps,
    pub going_p: bool,
}

impl crate::prelude::Show for FieldsRead {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("FieldsRead", &[("fields", &self.fields_p), ("rest", &self.rest_p), ("p", &self.p_p), ("going", &self.going_p)]);
    }
}

impl crate::prelude::ToPod for FieldsRead {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("FieldsRead", vec![("fields", self.fields_p.to_pod()), ("rest", self.rest_p.to_pod()), ("p", self.p_p.to_pod()), ("going", self.going_p.to_pod())])
    }
}

impl crate::prelude::FromPod for FieldsRead {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(FieldsRead { fields_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "fields")?)?, rest_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "rest")?)?, p_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "p")?)?, going_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "going")?)? })
    }
}

/// ```prism
/// ParseType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_type_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Type, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p_p0);
    let color_var_p2 = is_plain_lower_one_f(&crate::syntax::parser::kind_f(p_p0)) && is_fn_kw_f(&crate::syntax::parser::kind_at_f(p_p0, &crate::prelude::Nat::from(1u32)));
    let (color_p3, p1_p4) = if crate::syntax::parser::at_kw_f(p_p0, &crate::prelude::Text::lit("unbounded")) {
        (crate::syntax::Color::Unbounded, crate::syntax::parser::adv_f(p_p0))
    } else {
        if color_var_p2 {
            color_var_of_f(p_p0)
        } else {
            (crate::syntax::Color::Bounded, p_p0.clone())
        }
    };
    if crate::syntax::parser::at_kw_f(&p1_p4, &crate::prelude::Text::lit("fn")) {
        {
            let p2_p5 = crate::syntax::parser::adv_f(&p1_p4);
            let (params_p6, p3_p7) = if crate::syntax::parser::at_op_f(&p2_p5, &crate::prelude::Text::lit("->")) {
                (crate::prelude::Array::new(), p2_p5.clone())
            } else {
                crate::syntax::parser::commas_f(&p2_p5, &(::std::rc::Rc::new(|a0: crate::syntax::parser::Ps| crate::prelude::entered(start_parse_emit_type_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>>>))
            };
            let (result_p8, p4_p9) = parse_type_f(&crate::syntax::parser::expect_op_f(&p3_p7, &crate::prelude::Text::lit("->")));
            (crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TFn(color_p3.clone(), params_p6.clone(), ::std::rc::Rc::new(result_p8.clone()))), span_p: crate::syntax::parser::to_f(&start_p1, &result_p8.span_p) }, p4_p9.clone())
        }
    } else {
        if &color_p3 != &crate::syntax::Color::Bounded {
            (crate::syntax::parser::decls::no_type_p(), crate::syntax::parser::error_here_f(&p1_p4, &crate::prelude::Text::lit("a color (`unbounded`, or a color variable) is written before a function type\'s `fn`")))
        } else {
            {
                let (t_pa, q_pb) = parse_emit_type_f(&p1_p4);
                if crate::syntax::parser::at_op_f(&q_pb, &crate::prelude::Text::lit("->")) {
                    (t_pa.clone(), crate::syntax::parser::error_at_f(&q_pb, &crate::syntax::parser::here_f(&q_pb), &crate::prelude::Text::lit("a function type begins with `fn`: `fn A -> B`")))
                } else {
                    (t_pa.clone(), q_pb.clone())
                }
            }
        }
    }
}

/// The step machine of `ParseType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseType {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)> for ParseType {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Type, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here_f(p_p0);
        let color_var_p2 = is_plain_lower_one_f(&crate::syntax::parser::kind_f(p_p0)) && is_fn_kw_f(&crate::syntax::parser::kind_at_f(p_p0, &crate::prelude::Nat::from(1u32)));
        let (color_p3, p1_p4) = if crate::syntax::parser::at_kw_f(p_p0, &crate::prelude::Text::lit("unbounded")) {
            (crate::syntax::Color::Unbounded, crate::syntax::parser::adv_f(p_p0))
        } else {
            if color_var_p2 {
                color_var_of_f(p_p0)
            } else {
                (crate::syntax::Color::Bounded, p_p0.clone())
            }
        };
        if crate::syntax::parser::at_kw_f(&p1_p4, &crate::prelude::Text::lit("fn")) {
            {
                let p2_p5 = crate::syntax::parser::adv_f(&p1_p4);
                let color_p3z = color_p3.clone();
                let start_p1z = start_p1.clone();
                let k_let1862 = move |v1862: (crate::prelude::Array<crate::syntax::Type>, crate::syntax::parser::Ps)| {
                    let (params_p6, p3_p7) = v1862;
                    crate::prelude::call_then(start_parse_type_f(crate::syntax::parser::expect_op_f(&p3_p7, &crate::prelude::Text::lit("->"))), move |parse_type_f_1974: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                        let (result_p8, p4_p9) = parse_type_f_1974;
                        ::prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TFn(color_p3z.clone(), params_p6.clone(), ::std::rc::Rc::new(result_p8.clone()))), span_p: crate::syntax::parser::to_f(&start_p1z, &result_p8.span_p) }, p4_p9.clone()))
                    })
                };
                if crate::syntax::parser::at_op_f(&p2_p5, &crate::prelude::Text::lit("->")) {
                    k_let1862((crate::prelude::Array::new(), p2_p5.clone()))
                } else {
                    crate::prelude::call_then(crate::syntax::parser::start_commas_f(p2_p5.clone(), ::std::rc::Rc::new(|a0: crate::syntax::parser::Ps| crate::prelude::entered(start_parse_emit_type_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>>>), move |commas_f_1920: (crate::prelude::Array<crate::syntax::Type>, crate::syntax::parser::Ps)| k_let1862(commas_f_1920))
                }
            }
        } else {
            if &color_p3 != &crate::syntax::Color::Bounded {
                ::prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_type_p(), crate::syntax::parser::error_here_f(&p1_p4, &crate::prelude::Text::lit("a color (`unbounded`, or a color variable) is written before a function type\'s `fn`"))))
            } else {
                crate::prelude::call_then(start_parse_emit_type_f(p1_p4.clone()), move |parse_emit_type_f_2267: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (t_pa, q_pb) = parse_emit_type_f_2267;
                    if crate::syntax::parser::at_op_f(&q_pb, &crate::prelude::Text::lit("->")) {
                        ::prism_rtl::Turn::Finished((t_pa.clone(), crate::syntax::parser::error_at_f(&q_pb, &crate::syntax::parser::here_f(&q_pb), &crate::prelude::Text::lit("a function type begins with `fn`: `fn A -> B`"))))
                    } else {
                        ::prism_rtl::Turn::Finished((t_pa.clone(), q_pb.clone()))
                    }
                })
            }
        }
    }
}

/// `Start ParseType, x`: what the function value is when passed to `@Run`.
pub fn start_parse_type_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseType { p_p0 })
}

/// ```prism
/// IsPlainLowerOne: fn TokKind -> Bool
/// ```
pub fn is_plain_lower_one_f(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KName(n_p0) => ((&n_p0.sigils_p == &crate::prelude::Text::lit("")) && (&n_p0.case_p == &crate::syntax::lexer::NameCase::CaseLower)) && (&crate::prelude::len(&n_p0.path_p) == &crate::prelude::Nat::from(1u32)),
        _ => false,
    }
}

/// ```prism
/// IsFnKw: fn TokKind -> Bool
/// ```
pub fn is_fn_kw_f(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KKw(c0_0_0, _) if (c0_0_0 == &crate::prelude::Text::lit("fn")) => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ColorVarOf: fn Ps -> ((Color, Ps))
/// ```
pub fn color_var_of_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Color, crate::syntax::parser::Ps) {
    let (i_p1, q_p2) = crate::syntax::parser::parse_ident_f(p_p0);
    (crate::syntax::Color::ColorVar(i_p1.clone()), q_p2.clone())
}

/// ```prism
/// ParseEmitType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_emit_type_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Type, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p_p0);
    let (t_p2, p1_p3) = parse_union_type_f(p_p0);
    if crate::syntax::parser::at_kw_f(&p1_p3, &crate::prelude::Text::lit("emit")) {
        {
            let (r_p4, q_p5) = parse_union_type_f(&crate::syntax::parser::adv_f(&p1_p3));
            (crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TEmit(::std::rc::Rc::new(t_p2.clone()), ::std::rc::Rc::new(r_p4.clone()))), span_p: crate::syntax::parser::to_f(&start_p1, &r_p4.span_p) }, q_p5.clone())
        }
    } else {
        (t_p2.clone(), p1_p3.clone())
    }
}

/// The step machine of `ParseEmitType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseEmitType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseEmitType {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)> for ParseEmitType {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Type, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here_f(p_p0);
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(start_parse_union_type_f(p_p0x.clone()), move |parse_union_type_f_2872: (crate::syntax::Type, crate::syntax::parser::Ps)| {
            let (t_p2, p1_p3) = parse_union_type_f_2872;
            if crate::syntax::parser::at_kw_f(&p1_p3, &crate::prelude::Text::lit("emit")) {
                crate::prelude::call_then(start_parse_union_type_f(crate::syntax::parser::adv_f(&p1_p3)), move |parse_union_type_f_2936: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (r_p4, q_p5) = parse_union_type_f_2936;
                    ::prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TEmit(::std::rc::Rc::new(t_p2.clone()), ::std::rc::Rc::new(r_p4.clone()))), span_p: crate::syntax::parser::to_f(&start_p1, &r_p4.span_p) }, q_p5.clone()))
                })
            } else {
                ::prism_rtl::Turn::Finished((t_p2.clone(), p1_p3.clone()))
            }
        })
    }
}

/// `Start ParseEmitType, x`: what the function value is when passed to `@Run`.
pub fn start_parse_emit_type_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseEmitType { p_p0 })
}

/// ```prism
/// ParseUnionType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_union_type_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Type, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p_p0);
    let (first_p2, p1_p3) = parse_map_type_f(p_p0);
    if &crate::syntax::parser::kind_f(&p1_p3) != &crate::syntax::lexer::TokKind::KBar {
        (first_p2.clone(), p1_p3.clone())
    } else {
        {
            let r_p4 = {
                let mut this: (crate::prelude::Array<crate::syntax::Type>, crate::syntax::parser::Ps) = (crate::prelude::Array::from(vec![first_p2.clone()]), p1_p3.clone());
                let mut terms_p5: crate::prelude::Array<crate::syntax::Type> = crate::prelude::Array::from(vec![first_p2.clone()]);
                let mut q_p6: crate::syntax::parser::Ps = p1_p3.clone();
                while (&crate::syntax::parser::kind_f(&q_p6) == &crate::syntax::lexer::TokKind::KBar) && !q_p6.bad_p {
                    let (t_p7, q2_p8) = parse_map_type_f(&crate::syntax::parser::adv_f(&q_p6));
                    terms_p5 = crate::prelude::push(&terms_p5, &t_p7);
                    q_p6 = q2_p8.clone();
                }
                this = (terms_p5.clone(), q_p6.clone());
                this
            };
            let (terms_p9, q_pa) = r_p4.clone();
            (crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TRowUnion(terms_p9.clone())), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&q_pa)) }, q_pa.clone())
        }
    }
}

/// The step machine of `ParseUnionType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseUnionType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseUnionType {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)> for ParseUnionType {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Type, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here_f(p_p0);
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(start_parse_map_type_f(p_p0x.clone()), move |parse_map_type_f_3161: (crate::syntax::Type, crate::syntax::parser::Ps)| {
            let (first_p2, p1_p3) = parse_map_type_f_3161;
            if &crate::syntax::parser::kind_f(&p1_p3) != &crate::syntax::lexer::TokKind::KBar {
                ::prism_rtl::Turn::Finished((first_p2.clone(), p1_p3.clone()))
            } else {
                {
                    let mut this: (crate::prelude::Array<crate::syntax::Type>, crate::syntax::parser::Ps) = (crate::prelude::Array::from(vec![first_p2.clone()]), p1_p3.clone());
                    let mut terms_p5: crate::prelude::Array<crate::syntax::Type> = crate::prelude::Array::from(vec![first_p2.clone()]);
                    let mut q_p6: crate::syntax::parser::Ps = p1_p3.clone();
                    let start_p1z = start_p1.clone();
                    crate::prelude::call_then(crate::prelude::loop_job((this, q_p6, terms_p5), move |(mut this, mut q_p6, mut terms_p5): ((crate::prelude::Array<crate::syntax::Type>, crate::syntax::parser::Ps), crate::syntax::parser::Ps, crate::prelude::Array<crate::syntax::Type>)| if (&crate::syntax::parser::kind_f(&q_p6) == &crate::syntax::lexer::TokKind::KBar) && !q_p6.bad_p {
                        {
                            let (t_p7, q2_p8) = parse_map_type_f(&crate::syntax::parser::adv_f(&q_p6));
                            terms_p5 = crate::prelude::push(&terms_p5, &t_p7);
                            q_p6 = q2_p8.clone();
                            ::std::result::Result::Ok((this, q_p6, terms_p5))
                        }
                    } else {
                        ::std::result::Result::Err((this, q_p6, terms_p5))
                    }), move |(mut this, mut q_p6, mut terms_p5): ((crate::prelude::Array<crate::syntax::Type>, crate::syntax::parser::Ps), crate::syntax::parser::Ps, crate::prelude::Array<crate::syntax::Type>)| {
                        this = (terms_p5.clone(), q_p6.clone());
                        let r_p4 = this;
                        let (terms_p9, q_pa) = r_p4.clone();
                        ::prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TRowUnion(terms_p9.clone())), span_p: crate::syntax::parser::to_f(&start_p1z, &crate::syntax::parser::prev_f(&q_pa)) }, q_pa.clone()))
                    })
                }
            }
        })
    }
}

/// `Start ParseUnionType, x`: what the function value is when passed to `@Run`.
pub fn start_parse_union_type_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseUnionType { p_p0 })
}

/// ```prism
/// ParseMapType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_map_type_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Type, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p_p0);
    let (k_p2, p1_p3) = parse_sigiled_type_f(p_p0);
    if crate::syntax::parser::at_op_f(&p1_p3, &crate::prelude::Text::lit("==>")) {
        {
            let (value_p4, q_p5) = parse_map_type_f(&crate::syntax::parser::adv_f(&p1_p3));
            (crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TMap(::std::rc::Rc::new(k_p2.clone()), ::std::rc::Rc::new(value_p4.clone()))), span_p: crate::syntax::parser::to_f(&start_p1, &value_p4.span_p) }, q_p5.clone())
        }
    } else {
        (k_p2.clone(), p1_p3.clone())
    }
}

/// The step machine of `ParseMapType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseMapType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseMapType {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)> for ParseMapType {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Type, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here_f(p_p0);
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(start_parse_sigiled_type_f(p_p0x.clone()), move |parse_sigiled_type_f_3741: (crate::syntax::Type, crate::syntax::parser::Ps)| {
            let (k_p2, p1_p3) = parse_sigiled_type_f_3741;
            if crate::syntax::parser::at_op_f(&p1_p3, &crate::prelude::Text::lit("==>")) {
                crate::prelude::call_then(start_parse_map_type_f(crate::syntax::parser::adv_f(&p1_p3)), move |parse_map_type_f_3810: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (value_p4, q_p5) = parse_map_type_f_3810;
                    ::prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TMap(::std::rc::Rc::new(k_p2.clone()), ::std::rc::Rc::new(value_p4.clone()))), span_p: crate::syntax::parser::to_f(&start_p1, &value_p4.span_p) }, q_p5.clone()))
                })
            } else {
                ::prism_rtl::Turn::Finished((k_p2.clone(), p1_p3.clone()))
            }
        })
    }
}

/// `Start ParseMapType, x`: what the function value is when passed to `@Run`.
pub fn start_parse_map_type_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseMapType { p_p0 })
}

/// ```prism
/// ParseSigiledType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_sigiled_type_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Type, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p_p0);
    let (sigils_p2, p1_p3) = free_sigil_run_f(p_p0);
    let (inner_p4, q_p5) = parse_app_type_f(&p1_p3);
    if &sigils_p2 == &crate::prelude::Text::lit("") {
        (inner_p4.clone(), q_p5.clone())
    } else {
        (crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TSigiled(sigils_p2.clone(), ::std::rc::Rc::new(inner_p4.clone()))), span_p: crate::syntax::parser::to_f(&start_p1, &inner_p4.span_p) }, q_p5.clone())
    }
}

/// The step machine of `ParseSigiledType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseSigiledType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseSigiledType {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)> for ParseSigiledType {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Type, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here_f(p_p0);
        let (sigils_p2, p1_p3) = free_sigil_run_f(p_p0);
        crate::prelude::call_then(start_parse_app_type_f(p1_p3.clone()), move |parse_app_type_f_4083: (crate::syntax::Type, crate::syntax::parser::Ps)| {
            let (inner_p4, q_p5) = parse_app_type_f_4083;
            if &sigils_p2 == &crate::prelude::Text::lit("") {
                ::prism_rtl::Turn::Finished((inner_p4.clone(), q_p5.clone()))
            } else {
                ::prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TSigiled(sigils_p2.clone(), ::std::rc::Rc::new(inner_p4.clone()))), span_p: crate::syntax::parser::to_f(&start_p1, &inner_p4.span_p) }, q_p5.clone()))
            }
        })
    }
}

/// `Start ParseSigiledType, x`: what the function value is when passed to `@Run`.
pub fn start_parse_sigiled_type_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseSigiledType { p_p0 })
}

/// ```prism
/// FreeSigilRun: fn Ps -> ((Text, Ps))
/// ```
pub fn free_sigil_run_f(p0_p0: &crate::syntax::parser::Ps) -> (crate::prelude::Text, crate::syntax::parser::Ps) {
    let mut this: (crate::prelude::Text, crate::syntax::parser::Ps) = (crate::prelude::Text::lit(""), p0_p0.clone());
    let mut sigils_p1: crate::prelude::Text = crate::prelude::Text::lit("");
    let mut p_p2: crate::syntax::parser::Ps = p0_p0.clone();
    let mut fuel_p3: crate::prelude::Nat = crate::prelude::len(&p0_p0.toks_p);
    while let ::std::option::Option::Some(left_p4) = (&fuel_p3).checked_sub(&crate::prelude::Nat::from(1u32)) {
        fuel_p3 = left_p4.clone();
        match &crate::syntax::parser::kind_f(&p_p2) {
            crate::syntax::lexer::TokKind::KFree(s_p5) => {
                sigils_p1 = crate::prelude::Text::from(format!("{}{}", &sigils_p1, s_p5));
                p_p2 = crate::syntax::parser::adv_f(&p_p2);
            }
            _ => {
                fuel_p3 = crate::prelude::Nat::from(0u32);
            }
        }
    }
    this = (sigils_p1.clone(), p_p2.clone());
    this
}

/// ```prism
/// ParseAppType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_app_type_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Type, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p_p0);
    let (head_p2, p1_p3) = parse_type_atom_f(p_p0);
    match &*head_p2.kind_p {
        crate::syntax::TypeKind::TName(name_p4, m4714_0_1) if (m4714_0_1.len() == 0) && type_atom_starts_here_f(&p1_p3) => {
            let r_p5 = {
                let mut this: (crate::prelude::Array<crate::syntax::Type>, crate::syntax::parser::Ps) = (crate::prelude::Array::new(), p1_p3.clone());
                let mut args_p6: crate::prelude::Array<crate::syntax::Type> = crate::prelude::Array::new();
                let mut q_p7: crate::syntax::parser::Ps = p1_p3.clone();
                while type_atom_starts_here_f(&q_p7) && !q_p7.bad_p {
                    let (a_p8, q2_p9) = parse_type_atom_f(&q_p7);
                    args_p6 = crate::prelude::push(&args_p6, &a_p8);
                    q_p7 = q2_p9.clone();
                }
                this = (args_p6.clone(), q_p7.clone());
                this
            };
            let (args_pa, q_pb) = r_p5.clone();
            (crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TName(name_p4.clone(), args_pa.clone())), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&q_pb)) }, q_pb.clone())
        },
        _ => (head_p2.clone(), p1_p3.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ParseAppType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseAppType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseAppType {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)> for ParseAppType {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Type, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here_f(p_p0);
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(start_parse_type_atom_f(p_p0x.clone()), move |parse_type_atom_f_4694: (crate::syntax::Type, crate::syntax::parser::Ps)| {
            let (head_p2, p1_p3) = parse_type_atom_f_4694;
            match &*head_p2.kind_p {
                crate::syntax::TypeKind::TName(name_p4, m4714_0_1) if (m4714_0_1.len() == 0) && type_atom_starts_here_f(&p1_p3) => {
                    let mut this: (crate::prelude::Array<crate::syntax::Type>, crate::syntax::parser::Ps) = (crate::prelude::Array::new(), p1_p3.clone());
                    let mut args_p6: crate::prelude::Array<crate::syntax::Type> = crate::prelude::Array::new();
                    let mut q_p7: crate::syntax::parser::Ps = p1_p3.clone();
                    let name_p4z = name_p4.clone();
                    let start_p1z = start_p1.clone();
                    crate::prelude::call_then(crate::prelude::loop_job((this, args_p6, q_p7), move |(mut this, mut args_p6, mut q_p7): ((crate::prelude::Array<crate::syntax::Type>, crate::syntax::parser::Ps), crate::prelude::Array<crate::syntax::Type>, crate::syntax::parser::Ps)| if type_atom_starts_here_f(&q_p7) && !q_p7.bad_p {
                        {
                            let (a_p8, q2_p9) = parse_type_atom_f(&q_p7);
                            args_p6 = crate::prelude::push(&args_p6, &a_p8);
                            q_p7 = q2_p9.clone();
                            ::std::result::Result::Ok((this, args_p6, q_p7))
                        }
                    } else {
                        ::std::result::Result::Err((this, args_p6, q_p7))
                    }), move |(mut this, mut args_p6, mut q_p7): ((crate::prelude::Array<crate::syntax::Type>, crate::syntax::parser::Ps), crate::prelude::Array<crate::syntax::Type>, crate::syntax::parser::Ps)| {
                        this = (args_p6.clone(), q_p7.clone());
                        let r_p5 = this;
                        let (args_pa, q_pb) = r_p5.clone();
                        ::prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TName(name_p4z.clone(), args_pa.clone())), span_p: crate::syntax::parser::to_f(&start_p1z, &crate::syntax::parser::prev_f(&q_pb)) }, q_pb.clone()))
                    })
                },
                _ => ::prism_rtl::Turn::Finished((head_p2.clone(), p1_p3.clone())),
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start ParseAppType, x`: what the function value is when passed to `@Run`.
pub fn start_parse_app_type_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseAppType { p_p0 })
}

/// ```prism
/// TypeAtomStartsHere: fn Ps -> Bool
/// ```
pub fn type_atom_starts_here_f(p_p0: &crate::syntax::parser::Ps) -> bool {
    match crate::syntax::parser::kind_f(p_p0) {
        crate::syntax::lexer::TokKind::KName(_) => true,
        crate::syntax::lexer::TokKind::KFamily(_) => true,
        crate::syntax::lexer::TokKind::KFree(_) => true,
        crate::syntax::lexer::TokKind::KOpen(_, _) => true,
        crate::syntax::lexer::TokKind::KKw(w_p1, _) => (&w_p1 == &crate::prelude::Text::lit("unit")) || (&w_p1 == &crate::prelude::Text::lit("any")),
        _ => false,
    }
}

/// ```prism
/// ParseTypeAtom: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_type_atom_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Type, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p_p0);
    match crate::syntax::parser::kind_f(p_p0) {
        crate::syntax::lexer::TokKind::KFree(_) => parse_sigiled_type_f(p_p0),
        _ => {
            let (t_p2, p1_p3) = type_atom_body_f(p_p0, &start_p1);
            if (&crate::syntax::parser::kind_f(&p1_p3) == &crate::syntax::lexer::TokKind::KNonEmpty) || plus_touches_parenthesis_f(&p1_p3, &crate::prelude::Text::lit("+")) {
                {
                    let m_p4 = crate::syntax::parser::here_f(&p1_p3);
                    (crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TNonEmpty(::std::rc::Rc::new(t_p2.clone()))), span_p: crate::syntax::parser::to_f(&start_p1, &m_p4) }, crate::syntax::parser::adv_f(&p1_p3))
                }
            } else {
                (t_p2.clone(), p1_p3.clone())
            }
        },
    }
}

/// The step machine of `ParseTypeAtom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTypeAtom: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseTypeAtom {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)> for ParseTypeAtom {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Type, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here_f(p_p0);
        match crate::syntax::parser::kind_f(p_p0) {
            crate::syntax::lexer::TokKind::KFree(_) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ParseSigiledType { p_p0: p_p0.clone() })),
            _ => {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(start_type_atom_body_f(p_p0x.clone(), start_p1.clone()), move |type_atom_body_f_5777: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (t_p2, p1_p3) = type_atom_body_f_5777;
                    if (&crate::syntax::parser::kind_f(&p1_p3) == &crate::syntax::lexer::TokKind::KNonEmpty) || plus_touches_parenthesis_f(&p1_p3, &crate::prelude::Text::lit("+")) {
                        {
                            let m_p4 = crate::syntax::parser::here_f(&p1_p3);
                            ::prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TNonEmpty(::std::rc::Rc::new(t_p2.clone()))), span_p: crate::syntax::parser::to_f(&start_p1, &m_p4) }, crate::syntax::parser::adv_f(&p1_p3)))
                        }
                    } else {
                        ::prism_rtl::Turn::Finished((t_p2.clone(), p1_p3.clone()))
                    }
                })
            },
        }
    }
}

/// `Start ParseTypeAtom, x`: what the function value is when passed to `@Run`.
pub fn start_parse_type_atom_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseTypeAtom { p_p0 })
}

/// ```prism
/// PlusTouchesParenthesis: fn Ps, Text -> Bool
/// ```
pub fn plus_touches_parenthesis_f(p_p0: &crate::syntax::parser::Ps, op_p1: &crate::prelude::Text) -> bool {
    match crate::syntax::parser::kind_f(p_p0) {
        crate::syntax::lexer::TokKind::KOp(found_p2, _) => (((&found_p2 == op_p1) && crate::syntax::parser::tk_f(p_p0).touches_p) && (&p_p0.pos_p > &crate::prelude::Nat::from(0u32))) && (&crate::prelude::or(&crate::prelude::index(&p_p0.toks_p, &crate::syntax::lexer::chars::dec_f(&p_p0.pos_p)), &crate::syntax::parser::eof_tok_p()).kind_p == &crate::syntax::lexer::TokKind::KClose(crate::prelude::Text::lit("("))),
        _ => false,
    }
}

/// ```prism
/// TypeAtomBody: unbounded fn Ps, Range -> ((Type, Ps))
/// ```
pub fn type_atom_body_f(p_p0: &crate::syntax::parser::Ps, start_p1: &crate::syntax::Range) -> (crate::syntax::Type, crate::syntax::parser::Ps) {
    match crate::syntax::parser::kind_f(p_p0) {
        crate::syntax::lexer::TokKind::KName(n_p2) => {
            let name_p3 = crate::syntax::SName { sigils_p: n_p2.sigils_p.clone(), path_p: n_p2.path_p.clone(), span_p: start_p1.clone() };
            if (&n_p2.case_p == &crate::syntax::lexer::NameCase::CaseTopic) || (&n_p2.case_p == &crate::syntax::lexer::NameCase::CaseHole) {
                (crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::THole(name_p3.clone())), span_p: start_p1.clone() }, crate::syntax::parser::adv_f(p_p0))
            } else {
                (crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TName(name_p3.clone(), crate::prelude::Array::new())), span_p: start_p1.clone() }, crate::syntax::parser::check_type_name_scope_f(&crate::syntax::parser::adv_f(p_p0), &name_p3))
            }
        },
        crate::syntax::lexer::TokKind::KKw(m6706_1_0, sigils_p4) if (&m6706_1_0 == &crate::prelude::Text::lit("unit")) => (crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TUnit(sigils_p4)), span_p: start_p1.clone() }, crate::syntax::parser::adv_f(p_p0)),
        crate::syntax::lexer::TokKind::KKw(m6706_2_0, _) if (&m6706_2_0 == &crate::prelude::Text::lit("any")) => {
            let (tr_p5, q_p6) = crate::syntax::parser::parse_trait_ref_f(&crate::syntax::parser::adv_f(p_p0));
            (crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TAny(tr_p5.clone())), span_p: crate::syntax::parser::to_f(start_p1, &crate::syntax::parser::prev_f(&q_p6)) }, q_p6.clone())
        },
        crate::syntax::lexer::TokKind::KFamily(path_p7) => (crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TFamily(crate::syntax::QualName { path_p: path_p7.clone(), span_p: start_p1.clone() })), span_p: start_p1.clone() }, crate::syntax::parser::adv_f(p_p0)),
        crate::syntax::lexer::TokKind::KAbsent => (crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TAbsent), span_p: start_p1.clone() }, crate::syntax::parser::out_of_scope_f(&crate::syntax::parser::adv_f(p_p0), start_p1, &crate::prelude::Text::lit("sparse tuples"), &crate::prelude::Text::lit("a sparse tuple type is out of this compiler"))),
        crate::syntax::lexer::TokKind::KOpen(m6706_5_0, _) if (&m6706_5_0 == &crate::prelude::Text::lit("(")) => if crate::syntax::parser::at_double_open_f(p_p0, &crate::prelude::Text::lit("(")) {
            {
                let (elems_p9, p1_pa) = crate::syntax::parser::commas_f(&crate::syntax::parser::open_double_f(p_p0), &(::std::rc::Rc::new(|a0: crate::syntax::parser::Ps| crate::prelude::entered(start_parse_type_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>>>));
                let p2_p8 = crate::syntax::parser::close_double_f(&p1_pa, &crate::prelude::Text::lit("("));
                (crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TTuple(elems_p9.clone())), span_p: crate::syntax::parser::to_f(start_p1, &crate::syntax::parser::prev_f(&p2_p8)) }, p2_p8.clone())
            }
        } else {
            {
                let (inner_pc, p1_pd) = parse_type_f(&crate::syntax::parser::adv_f(p_p0));
                let p2_pb = crate::syntax::parser::expect_close_f(&p1_pd, &crate::prelude::Text::lit("("));
                (crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TGroup(::std::rc::Rc::new(inner_pc.clone()))), span_p: crate::syntax::parser::to_f(start_p1, &crate::syntax::parser::prev_f(&p2_pb)) }, p2_pb.clone())
            }
        },
        crate::syntax::lexer::TokKind::KOpen(m6706_6_0, _) if (&m6706_6_0 == &crate::prelude::Text::lit("[")) => {
            let doubled_pe = crate::syntax::parser::at_double_open_f(p_p0, &crate::prelude::Text::lit("["));
            let (elem_pg, p1_ph) = parse_type_f(&(if doubled_pe {
                crate::syntax::parser::open_double_f(p_p0)
            } else {
                crate::syntax::parser::adv_f(p_p0)
            }));
            let p2_pf = if doubled_pe {
                crate::syntax::parser::close_double_f(&p1_ph, &crate::prelude::Text::lit("["))
            } else {
                crate::syntax::parser::expect_close_f(&p1_ph, &crate::prelude::Text::lit("["))
            };
            (crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TArray(::std::rc::Rc::new(elem_pg.clone()), doubled_pe)), span_p: crate::syntax::parser::to_f(start_p1, &crate::syntax::parser::prev_f(&p2_pf)) }, p2_pf.clone())
        },
        _ => (crate::syntax::parser::decls::no_type_p(), crate::syntax::parser::error_here_f(p_p0, &crate::prelude::Text::lit("expected a type"))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `TypeAtomBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeAtomBody: unbounded fn Ps, Range -> ((Type, Ps))
/// ```
pub struct TypeAtomBody {
    pub p_p0: crate::syntax::parser::Ps,
    pub start_p1: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)> for TypeAtomBody {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Type, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = &self.start_p1;
        match crate::syntax::parser::kind_f(p_p0) {
            crate::syntax::lexer::TokKind::KName(n_p2) => {
                let name_p3 = crate::syntax::SName { sigils_p: n_p2.sigils_p.clone(), path_p: n_p2.path_p.clone(), span_p: start_p1.clone() };
                if (&n_p2.case_p == &crate::syntax::lexer::NameCase::CaseTopic) || (&n_p2.case_p == &crate::syntax::lexer::NameCase::CaseHole) {
                    ::prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::THole(name_p3.clone())), span_p: start_p1.clone() }, crate::syntax::parser::adv_f(p_p0)))
                } else {
                    ::prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TName(name_p3.clone(), crate::prelude::Array::new())), span_p: start_p1.clone() }, crate::syntax::parser::check_type_name_scope_f(&crate::syntax::parser::adv_f(p_p0), &name_p3)))
                }
            },
            crate::syntax::lexer::TokKind::KKw(m6706_1_0, sigils_p4) if (&m6706_1_0 == &crate::prelude::Text::lit("unit")) => ::prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TUnit(sigils_p4.clone())), span_p: start_p1.clone() }, crate::syntax::parser::adv_f(p_p0))),
            crate::syntax::lexer::TokKind::KKw(m6706_2_0, _) if (&m6706_2_0 == &crate::prelude::Text::lit("any")) => {
                let (tr_p5, q_p6) = crate::syntax::parser::parse_trait_ref_f(&crate::syntax::parser::adv_f(p_p0));
                ::prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TAny(tr_p5.clone())), span_p: crate::syntax::parser::to_f(start_p1, &crate::syntax::parser::prev_f(&q_p6)) }, q_p6.clone()))
            },
            crate::syntax::lexer::TokKind::KFamily(path_p7) => ::prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TFamily(crate::syntax::QualName { path_p: path_p7.clone(), span_p: start_p1.clone() })), span_p: start_p1.clone() }, crate::syntax::parser::adv_f(p_p0))),
            crate::syntax::lexer::TokKind::KAbsent => ::prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TAbsent), span_p: start_p1.clone() }, crate::syntax::parser::out_of_scope_f(&crate::syntax::parser::adv_f(p_p0), start_p1, &crate::prelude::Text::lit("sparse tuples"), &crate::prelude::Text::lit("a sparse tuple type is out of this compiler")))),
            crate::syntax::lexer::TokKind::KOpen(m6706_5_0, _) if (&m6706_5_0 == &crate::prelude::Text::lit("(")) => if crate::syntax::parser::at_double_open_f(p_p0, &crate::prelude::Text::lit("(")) {
                {
                    let p_p0x = p_p0.clone();
                    let start_p1x = start_p1.clone();
                    crate::prelude::call_then(crate::syntax::parser::start_commas_f(crate::syntax::parser::open_double_f(&p_p0x), ::std::rc::Rc::new(|a0: crate::syntax::parser::Ps| crate::prelude::entered(start_parse_type_f(a0))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>>>), move |commas_f_7667: (crate::prelude::Array<crate::syntax::Type>, crate::syntax::parser::Ps)| {
                        let (elems_p9, p1_pa) = commas_f_7667;
                        let p2_p8 = crate::syntax::parser::close_double_f(&p1_pa, &crate::prelude::Text::lit("("));
                        ::prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TTuple(elems_p9.clone())), span_p: crate::syntax::parser::to_f(&start_p1x, &crate::syntax::parser::prev_f(&p2_p8)) }, p2_p8.clone()))
                    })
                }
            } else {
                {
                    let p_p0x = p_p0.clone();
                    let start_p1x = start_p1.clone();
                    crate::prelude::call_then(start_parse_type_f(crate::syntax::parser::adv_f(&p_p0x)), move |parse_type_f_7861: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                        let (inner_pc, p1_pd) = parse_type_f_7861;
                        let p2_pb = crate::syntax::parser::expect_close_f(&p1_pd, &crate::prelude::Text::lit("("));
                        ::prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TGroup(::std::rc::Rc::new(inner_pc.clone()))), span_p: crate::syntax::parser::to_f(&start_p1x, &crate::syntax::parser::prev_f(&p2_pb)) }, p2_pb.clone()))
                    })
                }
            },
            crate::syntax::lexer::TokKind::KOpen(m6706_6_0, _) if (&m6706_6_0 == &crate::prelude::Text::lit("[")) => {
                let doubled_pe = crate::syntax::parser::at_double_open_f(p_p0, &crate::prelude::Text::lit("["));
                let p_p0x = p_p0.clone();
                let start_p1x = start_p1.clone();
                crate::prelude::call_then(start_parse_type_f(if doubled_pe {
                    crate::syntax::parser::open_double_f(&p_p0x)
                } else {
                    crate::syntax::parser::adv_f(&p_p0x)
                }), move |parse_type_f_8086: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (elem_pg, p1_ph) = parse_type_f_8086;
                    let p2_pf = if doubled_pe {
                        crate::syntax::parser::close_double_f(&p1_ph, &crate::prelude::Text::lit("["))
                    } else {
                        crate::syntax::parser::expect_close_f(&p1_ph, &crate::prelude::Text::lit("["))
                    };
                    ::prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: ::std::rc::Rc::new(crate::syntax::TypeKind::TArray(::std::rc::Rc::new(elem_pg.clone()), doubled_pe)), span_p: crate::syntax::parser::to_f(&start_p1x, &crate::syntax::parser::prev_f(&p2_pf)) }, p2_pf.clone()))
                })
            },
            _ => ::prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_type_p(), crate::syntax::parser::error_here_f(p_p0, &crate::prelude::Text::lit("expected a type")))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start TypeAtomBody, x`: what the function value is when passed to `@Run`.
pub fn start_type_atom_body_f(p_p0: crate::syntax::parser::Ps, start_p1: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(TypeAtomBody { p_p0, start_p1 })
}

/// ```prism
/// ParseBounds: unbounded fn Ps -> (([Bound], Ps))
/// ```
pub fn parse_bounds_f(p0_p0: &crate::syntax::parser::Ps) -> (crate::prelude::Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps) {
    let mut this: (crate::prelude::Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps) = (crate::prelude::Array::new(), p0_p0.clone());
    let mut bounds_p1: crate::prelude::Array<crate::syntax::decls::Bound> = crate::prelude::Array::new();
    let mut p_p2: crate::syntax::parser::Ps = p0_p0.clone();
    let mut going_p3: bool = true;
    while going_p3 && !p_p2.bad_p {
        let (b_p4, q_p5) = parse_bound_f(&p_p2);
        bounds_p1 = crate::prelude::push(&bounds_p1, &b_p4);
        p_p2 = q_p5.clone();
        if (crate::syntax::parser::at_comma_f(&p_p2) && is_name_kind_f(&crate::syntax::parser::kind_at_f(&p_p2, &crate::prelude::Nat::from(1u32)))) && (&crate::syntax::parser::kind_at_f(&p_p2, &crate::prelude::Nat::from(2u32)) == &crate::syntax::lexer::TokKind::KColon) {
            p_p2 = crate::syntax::parser::adv_f(&p_p2);
        } else {
            going_p3 = false;
        }
    }
    this = (bounds_p1.clone(), p_p2.clone());
    this
}

/// The step machine of `ParseBounds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseBounds: unbounded fn Ps -> (([Bound], Ps))
/// ```
pub struct ParseBounds {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps)> for ParseBounds {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let mut this: (crate::prelude::Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps) = (crate::prelude::Array::new(), p0_p0.clone());
        let mut bounds_p1: crate::prelude::Array<crate::syntax::decls::Bound> = crate::prelude::Array::new();
        let mut p_p2: crate::syntax::parser::Ps = p0_p0.clone();
        let mut going_p3: bool = true;
        crate::prelude::call_then(crate::prelude::loop_job((this, bounds_p1, going_p3, p_p2), move |(mut this, mut bounds_p1, mut going_p3, mut p_p2): ((crate::prelude::Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps), crate::prelude::Array<crate::syntax::decls::Bound>, bool, crate::syntax::parser::Ps)| if going_p3 && !p_p2.bad_p {
            {
                let (b_p4, q_p5) = parse_bound_f(&p_p2);
                bounds_p1 = crate::prelude::push(&bounds_p1, &b_p4);
                p_p2 = q_p5.clone();
                if (crate::syntax::parser::at_comma_f(&p_p2) && is_name_kind_f(&crate::syntax::parser::kind_at_f(&p_p2, &crate::prelude::Nat::from(1u32)))) && (&crate::syntax::parser::kind_at_f(&p_p2, &crate::prelude::Nat::from(2u32)) == &crate::syntax::lexer::TokKind::KColon) {
                    p_p2 = crate::syntax::parser::adv_f(&p_p2);
                } else {
                    going_p3 = false;
                }
                ::std::result::Result::Ok((this, bounds_p1, going_p3, p_p2))
            }
        } else {
            ::std::result::Result::Err((this, bounds_p1, going_p3, p_p2))
        }), move |(mut this, mut bounds_p1, mut going_p3, mut p_p2): ((crate::prelude::Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps), crate::prelude::Array<crate::syntax::decls::Bound>, bool, crate::syntax::parser::Ps)| {
            this = (bounds_p1.clone(), p_p2.clone());
            ::prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start ParseBounds, x`: what the function value is when passed to `@Run`.
pub fn start_parse_bounds_f(p0_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseBounds { p0_p0 })
}

/// ```prism
/// IsNameKind: fn TokKind -> Bool
/// ```
pub fn is_name_kind_f(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KName(_) => true,
        _ => false,
    }
}

/// ```prism
/// IsTraitKind: fn TokKind -> Bool
/// ```
pub fn is_trait_kind_f(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KTrait(_) => true,
        _ => false,
    }
}

/// ```prism
/// ParseBound: unbounded fn Ps -> ((Bound, Ps))
/// ```
pub fn parse_bound_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::Bound, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p_p0);
    let (var_p3, p1_p4) = crate::syntax::parser::parse_ident_f(p_p0);
    let (first_p5, p2_p6) = crate::syntax::parser::parse_trait_ref_f(&crate::syntax::parser::expect_colon_f(&p1_p4));
    let r_p2 = {
        let mut this: (crate::prelude::Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps) = (crate::prelude::Array::from(vec![first_p5.clone()]), p2_p6.clone());
        let mut traits_p7: crate::prelude::Array<crate::syntax::TraitRef> = crate::prelude::Array::from(vec![first_p5.clone()]);
        let mut q_p8: crate::syntax::parser::Ps = p2_p6.clone();
        while (crate::syntax::parser::at_comma_f(&q_p8) && is_trait_kind_f(&crate::syntax::parser::kind_at_f(&q_p8, &crate::prelude::Nat::from(1u32)))) && !q_p8.bad_p {
            let (t_p9, q2_pa) = crate::syntax::parser::parse_trait_ref_f(&crate::syntax::parser::adv_f(&q_p8));
            traits_p7 = crate::prelude::push(&traits_p7, &t_p9);
            q_p8 = q2_pa.clone();
        }
        this = (traits_p7.clone(), q_p8.clone());
        this
    };
    let (traits_pb, q_pc) = r_p2.clone();
    (crate::syntax::decls::Bound { var_p: var_p3.clone(), traits_p: traits_pb.clone(), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&q_pc)) }, q_pc.clone())
}

/// The step machine of `ParseBound`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseBound: unbounded fn Ps -> ((Bound, Ps))
/// ```
pub struct ParseBound {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::decls::Bound, crate::syntax::parser::Ps)> for ParseBound {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::decls::Bound, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here_f(p_p0);
        let (var_p3, p1_p4) = crate::syntax::parser::parse_ident_f(p_p0);
        let (first_p5, p2_p6) = crate::syntax::parser::parse_trait_ref_f(&crate::syntax::parser::expect_colon_f(&p1_p4));
        let mut this: (crate::prelude::Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps) = (crate::prelude::Array::from(vec![first_p5.clone()]), p2_p6.clone());
        let mut traits_p7: crate::prelude::Array<crate::syntax::TraitRef> = crate::prelude::Array::from(vec![first_p5.clone()]);
        let mut q_p8: crate::syntax::parser::Ps = p2_p6.clone();
        let start_p1z = start_p1.clone();
        let var_p3z = var_p3.clone();
        crate::prelude::call_then(crate::prelude::loop_job((this, q_p8, traits_p7), move |(mut this, mut q_p8, mut traits_p7): ((crate::prelude::Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps), crate::syntax::parser::Ps, crate::prelude::Array<crate::syntax::TraitRef>)| if (crate::syntax::parser::at_comma_f(&q_p8) && is_trait_kind_f(&crate::syntax::parser::kind_at_f(&q_p8, &crate::prelude::Nat::from(1u32)))) && !q_p8.bad_p {
            {
                let (t_p9, q2_pa) = crate::syntax::parser::parse_trait_ref_f(&crate::syntax::parser::adv_f(&q_p8));
                traits_p7 = crate::prelude::push(&traits_p7, &t_p9);
                q_p8 = q2_pa.clone();
                ::std::result::Result::Ok((this, q_p8, traits_p7))
            }
        } else {
            ::std::result::Result::Err((this, q_p8, traits_p7))
        }), move |(mut this, mut q_p8, mut traits_p7): ((crate::prelude::Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps), crate::syntax::parser::Ps, crate::prelude::Array<crate::syntax::TraitRef>)| {
            this = (traits_p7.clone(), q_p8.clone());
            let r_p2 = this;
            let (traits_pb, q_pc) = r_p2.clone();
            ::prism_rtl::Turn::Finished((crate::syntax::decls::Bound { var_p: var_p3z.clone(), traits_p: traits_pb.clone(), span_p: crate::syntax::parser::to_f(&start_p1z, &crate::syntax::parser::prev_f(&q_pc)) }, q_pc.clone()))
        })
    }
}

/// `Start ParseBound, x`: what the function value is when passed to `@Run`.
pub fn start_parse_bound_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::decls::Bound, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseBound { p_p0 })
}

/// ```prism
/// ParseRow: unbounded fn Ps -> ((Row, Ps))
/// ```
pub fn parse_row_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Row, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p_p0);
    let (first_p3, p1_p4) = parse_row_term_f(p_p0);
    let r_p2 = {
        let mut this: (crate::prelude::Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps) = (crate::prelude::Array::from(vec![first_p3.clone()]), p1_p4.clone());
        let mut terms_p5: crate::prelude::Array<crate::syntax::RowTerm> = crate::prelude::Array::from(vec![first_p3.clone()]);
        let mut q_p6: crate::syntax::parser::Ps = p1_p4.clone();
        while (&crate::syntax::parser::kind_f(&q_p6) == &crate::syntax::lexer::TokKind::KBar) && !q_p6.bad_p {
            let (t_p7, q2_p8) = parse_row_term_f(&crate::syntax::parser::adv_f(&q_p6));
            terms_p5 = crate::prelude::push(&terms_p5, &t_p7);
            q_p6 = q2_p8.clone();
        }
        this = (terms_p5.clone(), q_p6.clone());
        this
    };
    let (terms_p9, q_pa) = r_p2.clone();
    (crate::syntax::Row { terms_p: terms_p9.clone(), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&q_pa)) }, q_pa.clone())
}

/// The step machine of `ParseRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseRow: unbounded fn Ps -> ((Row, Ps))
/// ```
pub struct ParseRow {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::Row, crate::syntax::parser::Ps)> for ParseRow {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Row, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here_f(p_p0);
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(start_parse_row_term_f(p_p0x.clone()), move |parse_row_term_f_9885: (crate::syntax::RowTerm, crate::syntax::parser::Ps)| {
            let (first_p3, p1_p4) = parse_row_term_f_9885;
            let mut this: (crate::prelude::Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps) = (crate::prelude::Array::from(vec![first_p3.clone()]), p1_p4.clone());
            let mut terms_p5: crate::prelude::Array<crate::syntax::RowTerm> = crate::prelude::Array::from(vec![first_p3.clone()]);
            let mut q_p6: crate::syntax::parser::Ps = p1_p4.clone();
            let start_p1z = start_p1.clone();
            crate::prelude::call_then(crate::prelude::loop_job((this, q_p6, terms_p5), move |(mut this, mut q_p6, mut terms_p5): ((crate::prelude::Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps), crate::syntax::parser::Ps, crate::prelude::Array<crate::syntax::RowTerm>)| if (&crate::syntax::parser::kind_f(&q_p6) == &crate::syntax::lexer::TokKind::KBar) && !q_p6.bad_p {
                {
                    let (t_p7, q2_p8) = parse_row_term_f(&crate::syntax::parser::adv_f(&q_p6));
                    terms_p5 = crate::prelude::push(&terms_p5, &t_p7);
                    q_p6 = q2_p8.clone();
                    ::std::result::Result::Ok((this, q_p6, terms_p5))
                }
            } else {
                ::std::result::Result::Err((this, q_p6, terms_p5))
            }), move |(mut this, mut q_p6, mut terms_p5): ((crate::prelude::Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps), crate::syntax::parser::Ps, crate::prelude::Array<crate::syntax::RowTerm>)| {
                this = (terms_p5.clone(), q_p6.clone());
                let r_p2 = this;
                let (terms_p9, q_pa) = r_p2.clone();
                ::prism_rtl::Turn::Finished((crate::syntax::Row { terms_p: terms_p9.clone(), span_p: crate::syntax::parser::to_f(&start_p1z, &crate::syntax::parser::prev_f(&q_pa)) }, q_pa.clone()))
            })
        })
    }
}

/// `Start ParseRow, x`: what the function value is when passed to `@Run`.
pub fn start_parse_row_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Row, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseRow { p_p0 })
}

/// ```prism
/// ParseRowTerm: unbounded fn Ps -> ((RowTerm, Ps))
/// ```
pub fn parse_row_term_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::RowTerm, crate::syntax::parser::Ps) {
    match crate::syntax::parser::kind_f(p_p0) {
        crate::syntax::lexer::TokKind::KFamily(path_p1) => (crate::syntax::RowTerm::RFamily(crate::syntax::QualName { path_p: path_p1.clone(), span_p: crate::syntax::parser::here_f(p_p0) }), crate::syntax::parser::adv_f(p_p0)),
        crate::syntax::lexer::TokKind::KName(n_p2) if (is_plain_lower_one_f(&crate::syntax::lexer::TokKind::KName(n_p2.clone())) && !type_atom_after_name_f(p_p0)) => (crate::syntax::RowTerm::RVar(crate::syntax::Ident { name_p: crate::prelude::or(&crate::prelude::index(&n_p2.path_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")), span_p: crate::syntax::parser::here_f(p_p0) }), crate::syntax::parser::adv_f(p_p0)),
        _ => {
            let (t_p3, q_p4) = parse_map_type_f(p_p0);
            (crate::syntax::RowTerm::RType(t_p3.clone()), q_p4.clone())
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ParseRowTerm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseRowTerm: unbounded fn Ps -> ((RowTerm, Ps))
/// ```
pub struct ParseRowTerm {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::RowTerm, crate::syntax::parser::Ps)> for ParseRowTerm {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::RowTerm, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        match crate::syntax::parser::kind_f(p_p0) {
            crate::syntax::lexer::TokKind::KFamily(path_p1) => ::prism_rtl::Turn::Finished((crate::syntax::RowTerm::RFamily(crate::syntax::QualName { path_p: path_p1.clone(), span_p: crate::syntax::parser::here_f(p_p0) }), crate::syntax::parser::adv_f(p_p0))),
            crate::syntax::lexer::TokKind::KName(n_p2) if (is_plain_lower_one_f(&crate::syntax::lexer::TokKind::KName(n_p2.clone())) && !type_atom_after_name_f(p_p0)) => ::prism_rtl::Turn::Finished((crate::syntax::RowTerm::RVar(crate::syntax::Ident { name_p: crate::prelude::or(&crate::prelude::index(&n_p2.path_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")), span_p: crate::syntax::parser::here_f(p_p0) }), crate::syntax::parser::adv_f(p_p0))),
            _ => {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(start_parse_map_type_f(p_p0x.clone()), move |parse_map_type_f_10596: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (t_p3, q_p4) = parse_map_type_f_10596;
                    ::prism_rtl::Turn::Finished((crate::syntax::RowTerm::RType(t_p3.clone()), q_p4.clone()))
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ParseRowTerm, x`: what the function value is when passed to `@Run`.
pub fn start_parse_row_term_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::RowTerm, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseRowTerm { p_p0 })
}

/// ```prism
/// TypeAtomAfterName: fn Ps -> Bool
/// ```
pub fn type_atom_after_name_f(p_p0: &crate::syntax::parser::Ps) -> bool {
    match crate::syntax::parser::kind_at_f(p_p0, &crate::prelude::Nat::from(1u32)) {
        crate::syntax::lexer::TokKind::KName(_) => true,
        crate::syntax::lexer::TokKind::KOpen(_, _) => true,
        crate::syntax::lexer::TokKind::KFamily(_) => true,
        _ => false,
    }
}

/// ```prism
/// ParsePattern: unbounded fn Ps, Bool -> ((Pattern, Ps))
/// ```
pub fn parse_pattern_f(p_p0: &crate::syntax::parser::Ps, commas0_p1: &bool) -> (crate::syntax::Pattern, crate::syntax::parser::Ps) {
    let commas_p2 = *commas0_p1 && !p_p0.step_mode_p;
    let start_p3 = crate::syntax::parser::here_f(p_p0);
    match crate::syntax::parser::kind_f(p_p0) {
        crate::syntax::lexer::TokKind::KFree(s_p4) if ((&s_p4 == &crate::prelude::Text::lit("?")) || (&s_p4 == &crate::prelude::Text::lit("~"))) => {
            let (inner_p5, q_p6) = parse_pattern_f(&crate::syntax::parser::adv_f(p_p0), &commas_p2);
            (crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PSigil(s_p4.clone(), ::std::rc::Rc::new(inner_p5.clone()))), span_p: crate::syntax::parser::to_f(&start_p3, &inner_p5.span_p) }, q_p6.clone())
        },
        crate::syntax::lexer::TokKind::KFree(s_p7) => (crate::syntax::parser::decls::no_pattern_p(), crate::syntax::parser::error_at_f(p_p0, &start_p3, &crate::prelude::Text::from(format!("a free `{}` is not a pattern: only `? p` and `~ p` take a value apart", &s_p7)))),
        crate::syntax::lexer::TokKind::KName(n_p8) => name_pattern_f(p_p0, &n_p8, &commas_p2),
        crate::syntax::lexer::TokKind::KKw(m11380_3_0, _) if (&m11380_3_0 == &crate::prelude::Text::lit("ignore")) => (crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PIgnore), span_p: start_p3.clone() }, crate::syntax::parser::adv_f(p_p0)),
        crate::syntax::lexer::TokKind::KKw(m11380_4_0, _) if (&m11380_4_0 == &crate::prelude::Text::lit("unit")) => (crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PUnit), span_p: start_p3.clone() }, crate::syntax::parser::adv_f(p_p0)),
        crate::syntax::lexer::TokKind::KKw(m11380_5_0, _) if (&m11380_5_0 == &crate::prelude::Text::lit("nil")) => (crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PNil), span_p: start_p3.clone() }, crate::syntax::parser::adv_f(p_p0)),
        crate::syntax::lexer::TokKind::KInt(_, _) => literal_pattern_f(p_p0),
        crate::syntax::lexer::TokKind::KFloat(_, _) => literal_pattern_f(p_p0),
        crate::syntax::lexer::TokKind::KDuration(_, _, _) => literal_pattern_f(p_p0),
        crate::syntax::lexer::TokKind::KChar(_, _) => literal_pattern_f(p_p0),
        crate::syntax::lexer::TokKind::KText(_, _) => literal_pattern_f(p_p0),
        crate::syntax::lexer::TokKind::KRegex(_, _) => (crate::syntax::parser::decls::no_pattern_p(), crate::syntax::parser::error_at_f(p_p0, &start_p3, &crate::prelude::Text::lit("a regular expression is not a pattern: match a text with `?Match` or `?Find`"))),
        crate::syntax::lexer::TokKind::KOp(m11380_12_0, true) if (&m11380_12_0 == &crate::prelude::Text::lit("-")) => {
            let p1_p9 = crate::syntax::parser::adv_f(p_p0);
            if is_number_kind_f(&crate::syntax::parser::kind_f(&p1_p9)) {
                {
                    let (lit_pa, q_pb) = crate::syntax::parser::expr::parse_literal_f(&p1_p9);
                    (crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PNeg(lit_pa.clone())), span_p: crate::syntax::parser::to_f(&start_p3, &lit_pa.span_p) }, q_pb.clone())
                }
            } else {
                (crate::syntax::parser::decls::no_pattern_p(), crate::syntax::parser::error_here_f(&p1_p9, &crate::prelude::Text::lit("a `-` in a pattern is the sign of a number literal")))
            }
        },
        crate::syntax::lexer::TokKind::KOpen(m11380_13_0, _) if (&m11380_13_0 == &crate::prelude::Text::lit("(")) => if crate::syntax::parser::at_double_open_f(p_p0, &crate::prelude::Text::lit("(")) {
            {
                let (elems_pe, p1_pf) = crate::syntax::parser::commas_f(&crate::syntax::parser::open_double_f(p_p0), &(::std::rc::Rc::new(move |p0: crate::syntax::parser::Ps| crate::prelude::entered(crate::prelude::once_job(move || {
                    let q_pd = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ParsePattern { p_p0: q_pd.clone(), commas0_p1: false }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Pattern, crate::syntax::parser::Ps)>>>));
                let p2_pc = crate::syntax::parser::close_double_f(&p1_pf, &crate::prelude::Text::lit("("));
                (crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PTuple(elems_pe.clone())), span_p: crate::syntax::parser::to_f(&start_p3, &crate::syntax::parser::prev_f(&p2_pc)) }, p2_pc.clone())
            }
        } else {
            {
                let (inner_pi, p1_pj) = crate::syntax::parser::bracketed_f(&crate::syntax::parser::adv_f(p_p0), &(::std::rc::Rc::new(move |p0: crate::syntax::parser::Ps| crate::prelude::entered(crate::prelude::once_job(move || {
                    let q_ph = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ParsePattern { p_p0: q_ph.clone(), commas0_p1: true }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Pattern, crate::syntax::parser::Ps)>>>));
                let p2_pg = crate::syntax::parser::expect_close_f(&p1_pj, &crate::prelude::Text::lit("("));
                (crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PGroup(::std::rc::Rc::new(inner_pi.clone()))), span_p: crate::syntax::parser::to_f(&start_p3, &crate::syntax::parser::prev_f(&p2_pg)) }, p2_pg.clone())
            }
        },
        crate::syntax::lexer::TokKind::KOpen(m11380_14_0, _) if (&m11380_14_0 == &crate::prelude::Text::lit("[")) && crate::syntax::parser::at_double_open_f(p_p0, &crate::prelude::Text::lit("[")) => {
            let p1_pk = crate::syntax::parser::open_double_f(p_p0);
            let (elems_pn, p2_po) = if crate::syntax::parser::at_close_f(&p1_pk, &crate::prelude::Text::lit("[")) {
                (crate::prelude::Array::new(), p1_pk.clone())
            } else {
                crate::syntax::parser::commas_f(&p1_pk, &(::std::rc::Rc::new(move |p0: crate::syntax::parser::Ps| crate::prelude::entered(crate::prelude::once_job(move || {
                    let q_pm = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ParsePattern { p_p0: q_pm.clone(), commas0_p1: false }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Pattern, crate::syntax::parser::Ps)>>>))
            };
            let p3_pl = crate::syntax::parser::close_double_f(&p2_po, &crate::prelude::Text::lit("["));
            (crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PArray(elems_pn.clone())), span_p: crate::syntax::parser::to_f(&start_p3, &crate::syntax::parser::prev_f(&p3_pl)) }, p3_pl.clone())
        },
        crate::syntax::lexer::TokKind::KFamily(path_pp) => (crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PFamily(crate::syntax::QualName { path_p: path_pp.clone(), span_p: start_p3.clone() })), span_p: start_p3.clone() }, crate::syntax::parser::adv_f(p_p0)),
        crate::syntax::lexer::TokKind::KAbsent => (crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PIgnore), span_p: start_p3.clone() }, crate::syntax::parser::out_of_scope_f(&crate::syntax::parser::adv_f(p_p0), &start_p3, &crate::prelude::Text::lit("sparse tuples"), &crate::prelude::Text::lit("an absent component `-` is a sparse tuple\'s, out of this compiler"))),
        _ => (crate::syntax::parser::decls::no_pattern_p(), crate::syntax::parser::error_here_f(p_p0, &crate::prelude::Text::lit("expected a pattern"))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ParsePattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParsePattern: unbounded fn Ps, Bool -> ((Pattern, Ps))
/// ```
pub struct ParsePattern {
    pub p_p0: crate::syntax::parser::Ps,
    pub commas0_p1: bool,
}

impl ::prism_rtl::Job<(crate::syntax::Pattern, crate::syntax::parser::Ps)> for ParsePattern {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Pattern, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let commas0_p1 = &self.commas0_p1;
        let commas_p2 = *commas0_p1 && !p_p0.step_mode_p;
        let start_p3 = crate::syntax::parser::here_f(p_p0);
        match crate::syntax::parser::kind_f(p_p0) {
            crate::syntax::lexer::TokKind::KFree(s_p4) if ((&s_p4 == &crate::prelude::Text::lit("?")) || (&s_p4 == &crate::prelude::Text::lit("~"))) => {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(start_parse_pattern_f(crate::syntax::parser::adv_f(&p_p0x), commas_p2), move |parse_pattern_f_11466: (crate::syntax::Pattern, crate::syntax::parser::Ps)| {
                    let (inner_p5, q_p6) = parse_pattern_f_11466;
                    ::prism_rtl::Turn::Finished((crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PSigil(s_p4.clone(), ::std::rc::Rc::new(inner_p5.clone()))), span_p: crate::syntax::parser::to_f(&start_p3, &inner_p5.span_p) }, q_p6.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KFree(s_p7) => ::prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_pattern_p(), crate::syntax::parser::error_at_f(p_p0, &start_p3, &crate::prelude::Text::from(format!("a free `{}` is not a pattern: only `? p` and `~ p` take a value apart", &s_p7))))),
            crate::syntax::lexer::TokKind::KName(n_p8) => ::prism_rtl::Turn::More(::std::rc::Rc::new(NamePattern { p0_p0: p_p0.clone(), n_p1: n_p8.clone(), commas_p2 })),
            crate::syntax::lexer::TokKind::KKw(m11380_3_0, _) if (&m11380_3_0 == &crate::prelude::Text::lit("ignore")) => ::prism_rtl::Turn::Finished((crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PIgnore), span_p: start_p3.clone() }, crate::syntax::parser::adv_f(p_p0))),
            crate::syntax::lexer::TokKind::KKw(m11380_4_0, _) if (&m11380_4_0 == &crate::prelude::Text::lit("unit")) => ::prism_rtl::Turn::Finished((crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PUnit), span_p: start_p3.clone() }, crate::syntax::parser::adv_f(p_p0))),
            crate::syntax::lexer::TokKind::KKw(m11380_5_0, _) if (&m11380_5_0 == &crate::prelude::Text::lit("nil")) => ::prism_rtl::Turn::Finished((crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PNil), span_p: start_p3.clone() }, crate::syntax::parser::adv_f(p_p0))),
            crate::syntax::lexer::TokKind::KInt(_, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(LiteralPattern { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KFloat(_, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(LiteralPattern { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KDuration(_, _, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(LiteralPattern { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KChar(_, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(LiteralPattern { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KText(_, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(LiteralPattern { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KRegex(_, _) => ::prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_pattern_p(), crate::syntax::parser::error_at_f(p_p0, &start_p3, &crate::prelude::Text::lit("a regular expression is not a pattern: match a text with `?Match` or `?Find`")))),
            crate::syntax::lexer::TokKind::KOp(m11380_12_0, true) if (&m11380_12_0 == &crate::prelude::Text::lit("-")) => {
                let p1_p9 = crate::syntax::parser::adv_f(p_p0);
                if is_number_kind_f(&crate::syntax::parser::kind_f(&p1_p9)) {
                    crate::prelude::call_then(crate::syntax::parser::expr::start_parse_literal_f(p1_p9.clone()), move |parse_literal_f_12522: (crate::syntax::Literal, crate::syntax::parser::Ps)| {
                        let (lit_pa, q_pb) = parse_literal_f_12522;
                        ::prism_rtl::Turn::Finished((crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PNeg(lit_pa.clone())), span_p: crate::syntax::parser::to_f(&start_p3, &lit_pa.span_p) }, q_pb.clone()))
                    })
                } else {
                    ::prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_pattern_p(), crate::syntax::parser::error_here_f(&p1_p9, &crate::prelude::Text::lit("a `-` in a pattern is the sign of a number literal"))))
                }
            },
            crate::syntax::lexer::TokKind::KOpen(m11380_13_0, _) if (&m11380_13_0 == &crate::prelude::Text::lit("(")) => if crate::syntax::parser::at_double_open_f(p_p0, &crate::prelude::Text::lit("(")) {
                {
                    let p_p0x = p_p0.clone();
                    crate::prelude::call_then(crate::syntax::parser::start_commas_f(crate::syntax::parser::open_double_f(&p_p0x), ::std::rc::Rc::new(move |p0: crate::syntax::parser::Ps| crate::prelude::entered(crate::prelude::once_job(move || {
                        let q_pd = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(ParsePattern { p_p0: q_pd.clone(), commas0_p1: false }))
                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Pattern, crate::syntax::parser::Ps)>>>), move |commas_f_12814: (crate::prelude::Array<crate::syntax::Pattern>, crate::syntax::parser::Ps)| {
                        let (elems_pe, p1_pf) = commas_f_12814;
                        let p2_pc = crate::syntax::parser::close_double_f(&p1_pf, &crate::prelude::Text::lit("("));
                        ::prism_rtl::Turn::Finished((crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PTuple(elems_pe.clone())), span_p: crate::syntax::parser::to_f(&start_p3, &crate::syntax::parser::prev_f(&p2_pc)) }, p2_pc.clone()))
                    })
                }
            } else {
                {
                    let p_p0x = p_p0.clone();
                    crate::prelude::call_then(crate::syntax::parser::start_bracketed_f(crate::syntax::parser::adv_f(&p_p0x), ::std::rc::Rc::new(move |p0: crate::syntax::parser::Ps| crate::prelude::entered(crate::prelude::once_job(move || {
                        let q_ph = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(ParsePattern { p_p0: q_ph.clone(), commas0_p1: true }))
                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Pattern, crate::syntax::parser::Ps)>>>), move |bracketed_f_13201: (crate::syntax::Pattern, crate::syntax::parser::Ps)| {
                        let (inner_pi, p1_pj) = bracketed_f_13201;
                        let p2_pg = crate::syntax::parser::expect_close_f(&p1_pj, &crate::prelude::Text::lit("("));
                        ::prism_rtl::Turn::Finished((crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PGroup(::std::rc::Rc::new(inner_pi.clone()))), span_p: crate::syntax::parser::to_f(&start_p3, &crate::syntax::parser::prev_f(&p2_pg)) }, p2_pg.clone()))
                    })
                }
            },
            crate::syntax::lexer::TokKind::KOpen(m11380_14_0, _) if (&m11380_14_0 == &crate::prelude::Text::lit("[")) && crate::syntax::parser::at_double_open_f(p_p0, &crate::prelude::Text::lit("[")) => {
                let p1_pk = crate::syntax::parser::open_double_f(p_p0);
                let start_p3z = start_p3.clone();
                let k_let13468 = move |v13468: (crate::prelude::Array<crate::syntax::Pattern>, crate::syntax::parser::Ps)| {
                    let (elems_pn, p2_po) = v13468;
                    let p3_pl = crate::syntax::parser::close_double_f(&p2_po, &crate::prelude::Text::lit("["));
                    ::prism_rtl::Turn::Finished((crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PArray(elems_pn.clone())), span_p: crate::syntax::parser::to_f(&start_p3z, &crate::syntax::parser::prev_f(&p3_pl)) }, p3_pl.clone()))
                };
                if crate::syntax::parser::at_close_f(&p1_pk, &crate::prelude::Text::lit("[")) {
                    k_let13468((crate::prelude::Array::new(), p1_pk.clone()))
                } else {
                    crate::prelude::call_then(crate::syntax::parser::start_commas_f(p1_pk.clone(), ::std::rc::Rc::new(move |p0: crate::syntax::parser::Ps| crate::prelude::entered(crate::prelude::once_job(move || {
                        let q_pm = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(ParsePattern { p_p0: q_pm.clone(), commas0_p1: false }))
                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Pattern, crate::syntax::parser::Ps)>>>), move |commas_f_13527: (crate::prelude::Array<crate::syntax::Pattern>, crate::syntax::parser::Ps)| k_let13468(commas_f_13527))
                }
            },
            crate::syntax::lexer::TokKind::KFamily(path_pp) => ::prism_rtl::Turn::Finished((crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PFamily(crate::syntax::QualName { path_p: path_pp.clone(), span_p: start_p3.clone() })), span_p: start_p3.clone() }, crate::syntax::parser::adv_f(p_p0))),
            crate::syntax::lexer::TokKind::KAbsent => ::prism_rtl::Turn::Finished((crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PIgnore), span_p: start_p3.clone() }, crate::syntax::parser::out_of_scope_f(&crate::syntax::parser::adv_f(p_p0), &start_p3, &crate::prelude::Text::lit("sparse tuples"), &crate::prelude::Text::lit("an absent component `-` is a sparse tuple\'s, out of this compiler")))),
            _ => ::prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_pattern_p(), crate::syntax::parser::error_here_f(p_p0, &crate::prelude::Text::lit("expected a pattern")))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ParsePattern, x`: what the function value is when passed to `@Run`.
pub fn start_parse_pattern_f(p_p0: crate::syntax::parser::Ps, commas0_p1: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Pattern, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParsePattern { p_p0, commas0_p1 })
}

/// ```prism
/// IsNumberKind: fn TokKind -> Bool
/// ```
pub fn is_number_kind_f(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KInt(_, _) => true,
        crate::syntax::lexer::TokKind::KFloat(_, _) => true,
        crate::syntax::lexer::TokKind::KDuration(_, _, _) => true,
        _ => false,
    }
}

/// ```prism
/// LiteralPattern: unbounded fn Ps -> ((Pattern, Ps))
/// ```
pub fn literal_pattern_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Pattern, crate::syntax::parser::Ps) {
    let (lit_p1, q_p2) = crate::syntax::parser::expr::parse_literal_f(p_p0);
    (crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PLit(lit_p1.clone())), span_p: lit_p1.span_p.clone() }, q_p2.clone())
}

/// The step machine of `LiteralPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LiteralPattern: unbounded fn Ps -> ((Pattern, Ps))
/// ```
pub struct LiteralPattern {
    pub p_p0: crate::syntax::parser::Ps,
}

impl ::prism_rtl::Job<(crate::syntax::Pattern, crate::syntax::parser::Ps)> for LiteralPattern {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Pattern, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(crate::syntax::parser::expr::start_parse_literal_f(p_p0x.clone()), move |parse_literal_f_14335: (crate::syntax::Literal, crate::syntax::parser::Ps)| {
            let (lit_p1, q_p2) = parse_literal_f_14335;
            ::prism_rtl::Turn::Finished((crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PLit(lit_p1.clone())), span_p: lit_p1.span_p.clone() }, q_p2.clone()))
        })
    }
}

/// `Start LiteralPattern, x`: what the function value is when passed to `@Run`.
pub fn start_literal_pattern_f(p_p0: crate::syntax::parser::Ps) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Pattern, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(LiteralPattern { p_p0 })
}

/// ```prism
/// NamePattern: unbounded fn Ps, NameTok, Bool -> ((Pattern, Ps))
/// ```
pub fn name_pattern_f(p0_p0: &crate::syntax::parser::Ps, n_p1: &crate::syntax::lexer::NameTok, commas_p2: &bool) -> (crate::syntax::Pattern, crate::syntax::parser::Ps) {
    let start_p3 = crate::syntax::parser::here_f(p0_p0);
    let name_p4 = crate::syntax::SName { sigils_p: n_p1.sigils_p.clone(), path_p: n_p1.path_p.clone(), span_p: start_p3.clone() };
    let p_p5 = crate::syntax::parser::adv_f(p0_p0);
    if (crate::syntax::parser::is_callee_f(&name_p4) && crate::syntax::parser::at_single_open_f(&p_p5, &crate::prelude::Text::lit("("))) && crate::syntax::parser::tk_f(&p_p5).touches_p {
        parse_record_pattern_f(&p_p5, &name_p4)
    } else {
        if crate::syntax::parser::is_callee_f(&name_p4) && pat_arg_starts_here_f(&p_p5) {
            {
                let (first_p7, p1_p8) = parse_pattern_f(&p_p5, &false);
                let r_p6 = {
                    let mut this: (crate::prelude::Array<crate::syntax::Pattern>, crate::syntax::parser::Ps) = (crate::prelude::Array::from(vec![first_p7.clone()]), p1_p8.clone());
                    let mut args_p9: crate::prelude::Array<crate::syntax::Pattern> = crate::prelude::Array::from(vec![first_p7.clone()]);
                    let mut q_pa: crate::syntax::parser::Ps = p1_p8.clone();
                    while (*commas_p2 && crate::syntax::parser::at_comma_f(&q_pa)) && !q_pa.bad_p {
                        let (a_pb, q2_pc) = parse_pattern_f(&crate::syntax::parser::adv_f(&q_pa), &false);
                        args_p9 = crate::prelude::push(&args_p9, &a_pb);
                        q_pa = q2_pc.clone();
                    }
                    this = (args_p9.clone(), q_pa.clone());
                    this
                };
                let (args_pd, q_pe) = r_p6.clone();
                (crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PCtor(name_p4.clone(), args_pd.clone())), span_p: crate::syntax::parser::to_f(&start_p3, &crate::syntax::parser::prev_f(&q_pe)) }, q_pe.clone())
            }
        } else {
            (crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PName(name_p4.clone())), span_p: start_p3.clone() }, p_p5.clone())
        }
    }
}

/// The step machine of `NamePattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamePattern: unbounded fn Ps, NameTok, Bool -> ((Pattern, Ps))
/// ```
pub struct NamePattern {
    pub p0_p0: crate::syntax::parser::Ps,
    pub n_p1: crate::syntax::lexer::NameTok,
    pub commas_p2: bool,
}

impl ::prism_rtl::Job<(crate::syntax::Pattern, crate::syntax::parser::Ps)> for NamePattern {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Pattern, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let n_p1 = &self.n_p1;
        let commas_p2 = &self.commas_p2;
        let start_p3 = crate::syntax::parser::here_f(p0_p0);
        let name_p4 = crate::syntax::SName { sigils_p: n_p1.sigils_p.clone(), path_p: n_p1.path_p.clone(), span_p: start_p3.clone() };
        let p_p5 = crate::syntax::parser::adv_f(p0_p0);
        if (crate::syntax::parser::is_callee_f(&name_p4) && crate::syntax::parser::at_single_open_f(&p_p5, &crate::prelude::Text::lit("("))) && crate::syntax::parser::tk_f(&p_p5).touches_p {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(ParseRecordPattern { p0_p0: p_p5.clone(), name_p1: name_p4.clone() }))
        } else {
            if crate::syntax::parser::is_callee_f(&name_p4) && pat_arg_starts_here_f(&p_p5) {
                {
                    let commas_p2x = *commas_p2;
                    crate::prelude::call_then(start_parse_pattern_f(p_p5.clone(), false), move |parse_pattern_f_14780: (crate::syntax::Pattern, crate::syntax::parser::Ps)| {
                        let (first_p7, p1_p8) = parse_pattern_f_14780;
                        let mut this: (crate::prelude::Array<crate::syntax::Pattern>, crate::syntax::parser::Ps) = (crate::prelude::Array::from(vec![first_p7.clone()]), p1_p8.clone());
                        let mut args_p9: crate::prelude::Array<crate::syntax::Pattern> = crate::prelude::Array::from(vec![first_p7.clone()]);
                        let mut q_pa: crate::syntax::parser::Ps = p1_p8.clone();
                        let name_p4z = name_p4.clone();
                        let start_p3z = start_p3.clone();
                        crate::prelude::call_then(crate::prelude::loop_job((this, args_p9, q_pa), {
                            let commas_p2xx = commas_p2x;
                            move |(mut this, mut args_p9, mut q_pa): ((crate::prelude::Array<crate::syntax::Pattern>, crate::syntax::parser::Ps), crate::prelude::Array<crate::syntax::Pattern>, crate::syntax::parser::Ps)| if (commas_p2xx && crate::syntax::parser::at_comma_f(&q_pa)) && !q_pa.bad_p {
                                {
                                    let (a_pb, q2_pc) = parse_pattern_f(&crate::syntax::parser::adv_f(&q_pa), &false);
                                    args_p9 = crate::prelude::push(&args_p9, &a_pb);
                                    q_pa = q2_pc.clone();
                                    ::std::result::Result::Ok((this, args_p9, q_pa))
                                }
                            } else {
                                ::std::result::Result::Err((this, args_p9, q_pa))
                            }
                        }), move |(mut this, mut args_p9, mut q_pa): ((crate::prelude::Array<crate::syntax::Pattern>, crate::syntax::parser::Ps), crate::prelude::Array<crate::syntax::Pattern>, crate::syntax::parser::Ps)| {
                            this = (args_p9.clone(), q_pa.clone());
                            let r_p6 = this;
                            let (args_pd, q_pe) = r_p6.clone();
                            ::prism_rtl::Turn::Finished((crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PCtor(name_p4z.clone(), args_pd.clone())), span_p: crate::syntax::parser::to_f(&start_p3z, &crate::syntax::parser::prev_f(&q_pe)) }, q_pe.clone()))
                        })
                    })
                }
            } else {
                ::prism_rtl::Turn::Finished((crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PName(name_p4.clone())), span_p: start_p3.clone() }, p_p5.clone()))
            }
        }
    }
}

/// `Start NamePattern, x`: what the function value is when passed to `@Run`.
pub fn start_name_pattern_f(p0_p0: crate::syntax::parser::Ps, n_p1: crate::syntax::lexer::NameTok, commas_p2: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Pattern, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(NamePattern { p0_p0, n_p1, commas_p2 })
}

/// ```prism
/// PatArgStartsHere: fn Ps -> Bool
/// ```
pub fn pat_arg_starts_here_f(p_p0: &crate::syntax::parser::Ps) -> bool {
    match crate::syntax::parser::kind_f(p_p0) {
        crate::syntax::lexer::TokKind::KName(_) => true,
        crate::syntax::lexer::TokKind::KInt(_, _) => true,
        crate::syntax::lexer::TokKind::KFloat(_, _) => true,
        crate::syntax::lexer::TokKind::KDuration(_, _, _) => true,
        crate::syntax::lexer::TokKind::KChar(_, _) => true,
        crate::syntax::lexer::TokKind::KText(_, _) => true,
        crate::syntax::lexer::TokKind::KFamily(_) => true,
        crate::syntax::lexer::TokKind::KFree(s_p1) => (&s_p1 == &crate::prelude::Text::lit("?")) || (&s_p1 == &crate::prelude::Text::lit("~")),
        crate::syntax::lexer::TokKind::KOpen(m15398_8_0, _) if (&m15398_8_0 == &crate::prelude::Text::lit("(")) => !crate::syntax::parser::tk_f(p_p0).touches_p || crate::syntax::parser::at_double_open_f(p_p0, &crate::prelude::Text::lit("(")),
        crate::syntax::lexer::TokKind::KOpen(m15398_9_0, _) if (&m15398_9_0 == &crate::prelude::Text::lit("[")) => crate::syntax::parser::at_double_open_f(p_p0, &crate::prelude::Text::lit("[")),
        crate::syntax::lexer::TokKind::KOp(m15398_10_0, true) if (&m15398_10_0 == &crate::prelude::Text::lit("-")) => true,
        crate::syntax::lexer::TokKind::KKw(w_p2, _) => ((&w_p2 == &crate::prelude::Text::lit("ignore")) || (&w_p2 == &crate::prelude::Text::lit("unit"))) || (&w_p2 == &crate::prelude::Text::lit("nil")),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParseRecordPattern: unbounded fn Ps, SName -> ((Pattern, Ps))
/// ```
pub fn parse_record_pattern_f(p0_p0: &crate::syntax::parser::Ps, name_p1: &crate::syntax::SName) -> (crate::syntax::Pattern, crate::syntax::parser::Ps) {
    let p_p2 = crate::syntax::parser::adv_f(p0_p0);
    let r_p3 = {
        let mut this: FieldsRead = FieldsRead { fields_p: crate::prelude::Array::new(), rest_p: false, p_p: p_p2.clone(), going_p: !crate::syntax::parser::at_close_f(&p_p2, &crate::prelude::Text::lit("(")) };
        while this.going_p && !this.p_p.bad_p {
            if &crate::syntax::parser::kind_f(&this.p_p) == &crate::syntax::lexer::TokKind::KDotDot {
                this.p_p = crate::syntax::parser::adv_f(&this.p_p);
                this.rest_p = true;
            } else {
                let fstart_p5 = crate::syntax::parser::here_f(&this.p_p);
                let (fname_o6, marks_p7, p1_p8) = crate::syntax::parser::expr::parse_arg_name_f(&this.p_p);
                let (pattern_p9, p2_pa) = parse_pattern_f(&p1_p8, &false);
                this.fields_p = crate::prelude::push(&this.fields_p, &crate::syntax::FieldPat { marks_p: marks_p7.clone(), name_o: fname_o6.clone(), pattern_p: pattern_p9.clone(), span_p: crate::syntax::parser::to_f(&fstart_p5, &pattern_p9.span_p) });
                this.p_p = p2_pa.clone();
            }
            if crate::syntax::parser::at_comma_f(&this.p_p) {
                this.p_p = crate::syntax::parser::adv_f(&this.p_p);
            } else {
                this.going_p = false;
            }
        }
        this
    };
    let q_p4 = crate::syntax::parser::expect_close_f(&r_p3.p_p, &crate::prelude::Text::lit("("));
    (crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PRecord(name_p1.clone(), r_p3.fields_p.clone(), r_p3.rest_p)), span_p: crate::syntax::parser::to_f(&name_p1.span_p, &crate::syntax::parser::prev_f(&q_p4)) }, q_p4.clone())
}

/// The step machine of `ParseRecordPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseRecordPattern: unbounded fn Ps, SName -> ((Pattern, Ps))
/// ```
pub struct ParseRecordPattern {
    pub p0_p0: crate::syntax::parser::Ps,
    pub name_p1: crate::syntax::SName,
}

impl ::prism_rtl::Job<(crate::syntax::Pattern, crate::syntax::parser::Ps)> for ParseRecordPattern {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::Pattern, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let name_p1 = &self.name_p1;
        let p_p2 = crate::syntax::parser::adv_f(p0_p0);
        let mut this: FieldsRead = FieldsRead { fields_p: crate::prelude::Array::new(), rest_p: false, p_p: p_p2.clone(), going_p: !crate::syntax::parser::at_close_f(&p_p2, &crate::prelude::Text::lit("(")) };
        let name_p1z = name_p1.clone();
        crate::prelude::call_then(crate::prelude::loop_job((this,), move |(mut this,): (FieldsRead,)| if this.going_p && !this.p_p.bad_p {
            {
                if &crate::syntax::parser::kind_f(&this.p_p) == &crate::syntax::lexer::TokKind::KDotDot {
                    this.p_p = crate::syntax::parser::adv_f(&this.p_p);
                    this.rest_p = true;
                } else {
                    let fstart_p5 = crate::syntax::parser::here_f(&this.p_p);
                    let (fname_o6, marks_p7, p1_p8) = crate::syntax::parser::expr::parse_arg_name_f(&this.p_p);
                    let (pattern_p9, p2_pa) = parse_pattern_f(&p1_p8, &false);
                    this.fields_p = crate::prelude::push(&this.fields_p, &crate::syntax::FieldPat { marks_p: marks_p7.clone(), name_o: fname_o6.clone(), pattern_p: pattern_p9.clone(), span_p: crate::syntax::parser::to_f(&fstart_p5, &pattern_p9.span_p) });
                    this.p_p = p2_pa.clone();
                }
                if crate::syntax::parser::at_comma_f(&this.p_p) {
                    this.p_p = crate::syntax::parser::adv_f(&this.p_p);
                } else {
                    this.going_p = false;
                }
                ::std::result::Result::Ok((this,))
            }
        } else {
            ::std::result::Result::Err((this,))
        }), move |(mut this,): (FieldsRead,)| {
            let r_p3 = this;
            let q_p4 = crate::syntax::parser::expect_close_f(&r_p3.p_p, &crate::prelude::Text::lit("("));
            ::prism_rtl::Turn::Finished((crate::syntax::Pattern { kind_p: ::std::rc::Rc::new(crate::syntax::PatternKind::PRecord(name_p1z.clone(), r_p3.fields_p.clone(), r_p3.rest_p)), span_p: crate::syntax::parser::to_f(&name_p1z.span_p, &crate::syntax::parser::prev_f(&q_p4)) }, q_p4.clone()))
        })
    }
}

/// `Start ParseRecordPattern, x`: what the function value is when passed to `@Run`.
pub fn start_parse_record_pattern_f(p0_p0: crate::syntax::parser::Ps, name_p1: crate::syntax::SName) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::Pattern, crate::syntax::parser::Ps)>> {
    ::std::rc::Rc::new(ParseRecordPattern { p0_p0, name_p1 })
}
