//! The module `Syntax.Parser.Types`, from `target/bootstrap/src/prismc/syntax/parser/types.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `FieldsRead`:
///
/// ```prism
/// type FieldsRead = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct FieldsRead {
    pub fields: Array<crate::syntax::FieldPat>,
    pub rest: bool,
    pub p_: crate::syntax::parser::Ps,
    pub going: bool,
}

impl Show for FieldsRead {
    fn show(&self, p: &mut Printer) {
        p.record("FieldsRead", &[("fields", &self.fields), ("rest", &self.rest), ("p", &self.p_), ("going", &self.going)]);
    }
}

impl ToPod for FieldsRead {
    fn to_pod(&self) -> Pod {
        Pod::record("FieldsRead", vec![("fields", self.fields.to_pod()), ("rest", self.rest.to_pod()), ("p", self.p_.to_pod()), ("going", self.going.to_pod())])
    }
}

impl FromPod for FieldsRead {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(FieldsRead { fields: FromPod::from_pod(field(p, "fields")?)?, rest: FromPod::from_pod(field(p, "rest")?)?, p_: FromPod::from_pod(field(p, "p")?)?, going: FromPod::from_pod(field(p, "going")?)? })
    }
}

/// ```prism
/// ParseType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_type(p_: &crate::syntax::parser::Ps) -> (crate::syntax::Type, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p_);
    let color_var = is_plain_lower_one(&crate::syntax::parser::kind(p_)) && is_fn_kw(&crate::syntax::parser::kind_at(p_, &Nat::from(1u32)));
    let (color, p1) = if crate::syntax::parser::at_kw(p_, &Text::lit("unbounded")) {
        (crate::syntax::Color::Unbounded, crate::syntax::parser::adv(p_))
    } else {
        if color_var { color_var_of(p_) } else { (crate::syntax::Color::Bounded, p_.clone()) }
    };
    if crate::syntax::parser::at_kw(&p1, &Text::lit("fn")) {
        {
            let p2 = crate::syntax::parser::adv(&p1);
            let (params, p3) = if crate::syntax::parser::at_op(&p2, &Text::lit("->")) {
                (Array::new(), p2.clone())
            } else {
                crate::syntax::parser::commas(&p2, &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_emit_type(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>>>))
            };
            let (result, p4) = parse_type(&crate::syntax::parser::expect_op(&p3, &Text::lit("->")));
            (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TFn(color.clone(), params.clone(), Rc::new(result.clone()))), span: crate::syntax::parser::to(&start, &result.span) }, p4.clone())
        }
    } else {
        if &color != &crate::syntax::Color::Bounded {
            (crate::syntax::parser::decls::no_type(), crate::syntax::parser::error_here(&p1, &Text::lit("a color (`unbounded`, or a color variable) is written before a function type's `fn`")))
        } else {
            {
                let (t, q) = parse_emit_type(&p1);
                if crate::syntax::parser::at_op(&q, &Text::lit("->")) {
                    (t.clone(), crate::syntax::parser::error_at(&q, &crate::syntax::parser::here(&q), &Text::lit("a function type begins with `fn`: `fn A -> B`")))
                } else {
                    (t.clone(), q.clone())
                }
            }
        }
    }
}

/// The step machine of `ParseType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseType {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)> for ParseType {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Type, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let start = crate::syntax::parser::here(p_);
        let color_var = is_plain_lower_one(&crate::syntax::parser::kind(p_)) && is_fn_kw(&crate::syntax::parser::kind_at(p_, &Nat::from(1u32)));
        let (color, p1) = if crate::syntax::parser::at_kw(p_, &Text::lit("unbounded")) {
            (crate::syntax::Color::Unbounded, crate::syntax::parser::adv(p_))
        } else {
            if color_var { color_var_of(p_) } else { (crate::syntax::Color::Bounded, p_.clone()) }
        };
        if crate::syntax::parser::at_kw(&p1, &Text::lit("fn")) {
            {
                let p2 = crate::syntax::parser::adv(&p1);
                let (params, p3) = if crate::syntax::parser::at_op(&p2, &Text::lit("->")) {
                    (Array::new(), p2.clone())
                } else {
                    crate::syntax::parser::commas(&p2, &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_emit_type(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>>>))
                };
                call_then(start_parse_type(crate::syntax::parser::expect_op(&p3, &Text::lit("->"))), move |parse_type_1974: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (result, p4) = parse_type_1974;
                    prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TFn(color.clone(), params.clone(), Rc::new(result.clone()))), span: crate::syntax::parser::to(&start, &result.span) }, p4.clone()))
                })
            }
        } else {
            if &color != &crate::syntax::Color::Bounded {
                prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_type(), crate::syntax::parser::error_here(&p1, &Text::lit("a color (`unbounded`, or a color variable) is written before a function type's `fn`"))))
            } else {
                call_then(start_parse_emit_type(p1.clone()), move |parse_emit_type_2267: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (t, q) = parse_emit_type_2267;
                    if crate::syntax::parser::at_op(&q, &Text::lit("->")) {
                        prism_rtl::Turn::Finished((t.clone(), crate::syntax::parser::error_at(&q, &crate::syntax::parser::here(&q), &Text::lit("a function type begins with `fn`: `fn A -> B`"))))
                    } else {
                        prism_rtl::Turn::Finished((t.clone(), q.clone()))
                    }
                })
            }
        }
    }
}

/// `Start ParseType, x`: what the function value is when passed to `@Run`.
pub fn start_parse_type(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>> {
    Rc::new(ParseType { p_ })
}

/// ```prism
/// IsPlainLowerOne: fn TokKind -> Bool
/// ```
pub fn is_plain_lower_one(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KName(n) => ((&n.sigils == &Text::lit("")) && (&n.case == &crate::syntax::lexer::NameCase::CaseLower)) && (&len(&n.path_) == &Nat::from(1u32)),
        _ => false,
    }
}

/// ```prism
/// IsFnKw: fn TokKind -> Bool
/// ```
pub fn is_fn_kw(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KKw(c0_0_0, _) if (c0_0_0 == &Text::lit("fn")) => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ColorVarOf: fn Ps -> ((Color, Ps))
/// ```
pub fn color_var_of(p_: &crate::syntax::parser::Ps) -> (crate::syntax::Color, crate::syntax::parser::Ps) {
    let (i, q) = crate::syntax::parser::parse_ident(p_);
    (crate::syntax::Color::ColorVar(i.clone()), q.clone())
}

/// ```prism
/// ParseEmitType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_emit_type(p_: &crate::syntax::parser::Ps) -> (crate::syntax::Type, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p_);
    let (t, p1) = parse_union_type(p_);
    if crate::syntax::parser::at_kw(&p1, &Text::lit("emit")) {
        {
            let (r, q) = parse_union_type(&crate::syntax::parser::adv(&p1));
            (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TEmit(Rc::new(t.clone()), Rc::new(r.clone()))), span: crate::syntax::parser::to(&start, &r.span) }, q.clone())
        }
    } else {
        (t.clone(), p1.clone())
    }
}

/// The step machine of `ParseEmitType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseEmitType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseEmitType {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)> for ParseEmitType {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Type, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let start = crate::syntax::parser::here(p_);
        let p_ = p_.clone();
        call_then(start_parse_union_type(p_.clone()), move |parse_union_type_2872: (crate::syntax::Type, crate::syntax::parser::Ps)| {
            let (t, p1) = parse_union_type_2872;
            if crate::syntax::parser::at_kw(&p1, &Text::lit("emit")) {
                call_then(start_parse_union_type(crate::syntax::parser::adv(&p1)), move |parse_union_type_2936: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (r, q) = parse_union_type_2936;
                    prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TEmit(Rc::new(t.clone()), Rc::new(r.clone()))), span: crate::syntax::parser::to(&start, &r.span) }, q.clone()))
                })
            } else {
                prism_rtl::Turn::Finished((t.clone(), p1.clone()))
            }
        })
    }
}

/// `Start ParseEmitType, x`: what the function value is when passed to `@Run`.
pub fn start_parse_emit_type(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>> {
    Rc::new(ParseEmitType { p_ })
}

/// ```prism
/// ParseUnionType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_union_type(p_: &crate::syntax::parser::Ps) -> (crate::syntax::Type, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p_);
    let (first_, p1) = parse_map_type(p_);
    if &crate::syntax::parser::kind(&p1) != &crate::syntax::lexer::TokKind::KBar {
        (first_.clone(), p1.clone())
    } else {
        {
            let r = {
                let mut this: (Array<crate::syntax::Type>, crate::syntax::parser::Ps) = (Array::from(vec![first_.clone()]), p1.clone());
                let mut terms: Array<crate::syntax::Type> = Array::from(vec![first_.clone()]);
                let mut q: crate::syntax::parser::Ps = p1.clone();
                while (&crate::syntax::parser::kind(&q) == &crate::syntax::lexer::TokKind::KBar) && !q.bad {
                    let (t, q2) = parse_map_type(&crate::syntax::parser::adv(&q));
                    terms = push(&terms, &t);
                    q = q2.clone();
                }
                this = (terms.clone(), q.clone());
                this
            };
            let (terms, q) = r.clone();
            (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TRowUnion(terms.clone())), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone())
        }
    }
}

/// The step machine of `ParseUnionType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseUnionType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseUnionType {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)> for ParseUnionType {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Type, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let start = crate::syntax::parser::here(p_);
        let p_ = p_.clone();
        call_then(start_parse_map_type(p_.clone()), move |parse_map_type_3161: (crate::syntax::Type, crate::syntax::parser::Ps)| {
            let (first_, p1) = parse_map_type_3161;
            if &crate::syntax::parser::kind(&p1) != &crate::syntax::lexer::TokKind::KBar {
                prism_rtl::Turn::Finished((first_.clone(), p1.clone()))
            } else {
                {
                    let mut this: (Array<crate::syntax::Type>, crate::syntax::parser::Ps) = (Array::from(vec![first_.clone()]), p1.clone());
                    let mut terms: Array<crate::syntax::Type> = Array::from(vec![first_.clone()]);
                    let mut q: crate::syntax::parser::Ps = p1.clone();
                    let start = start.clone();
                    call_then(loop_job((this, q, terms), move |(mut this, mut q, mut terms): ((Array<crate::syntax::Type>, crate::syntax::parser::Ps), crate::syntax::parser::Ps, Array<crate::syntax::Type>)| if (&crate::syntax::parser::kind(&q) == &crate::syntax::lexer::TokKind::KBar) && !q.bad {
                        {
                            let (t, q2) = parse_map_type(&crate::syntax::parser::adv(&q));
                            terms = push(&terms, &t);
                            q = q2.clone();
                            Ok((this, q, terms))
                        }
                    } else {
                        Err((this, q, terms))
                    }), move |(mut this, mut q, mut terms): ((Array<crate::syntax::Type>, crate::syntax::parser::Ps), crate::syntax::parser::Ps, Array<crate::syntax::Type>)| {
                        this = (terms.clone(), q.clone());
                        let r = this;
                        let (terms, q) = r.clone();
                        prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TRowUnion(terms.clone())), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone()))
                    })
                }
            }
        })
    }
}

/// `Start ParseUnionType, x`: what the function value is when passed to `@Run`.
pub fn start_parse_union_type(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>> {
    Rc::new(ParseUnionType { p_ })
}

/// ```prism
/// ParseMapType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_map_type(p_: &crate::syntax::parser::Ps) -> (crate::syntax::Type, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p_);
    let (k, p1) = parse_sigiled_type(p_);
    if crate::syntax::parser::at_op(&p1, &Text::lit("==>")) {
        {
            let (value, q) = parse_map_type(&crate::syntax::parser::adv(&p1));
            (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TMap(Rc::new(k.clone()), Rc::new(value.clone()))), span: crate::syntax::parser::to(&start, &value.span) }, q.clone())
        }
    } else {
        (k.clone(), p1.clone())
    }
}

/// The step machine of `ParseMapType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseMapType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseMapType {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)> for ParseMapType {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Type, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let start = crate::syntax::parser::here(p_);
        let p_ = p_.clone();
        call_then(start_parse_sigiled_type(p_.clone()), move |parse_sigiled_type_3741: (crate::syntax::Type, crate::syntax::parser::Ps)| {
            let (k, p1) = parse_sigiled_type_3741;
            if crate::syntax::parser::at_op(&p1, &Text::lit("==>")) {
                call_then(start_parse_map_type(crate::syntax::parser::adv(&p1)), move |parse_map_type_3810: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (value, q) = parse_map_type_3810;
                    prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TMap(Rc::new(k.clone()), Rc::new(value.clone()))), span: crate::syntax::parser::to(&start, &value.span) }, q.clone()))
                })
            } else {
                prism_rtl::Turn::Finished((k.clone(), p1.clone()))
            }
        })
    }
}

/// `Start ParseMapType, x`: what the function value is when passed to `@Run`.
pub fn start_parse_map_type(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>> {
    Rc::new(ParseMapType { p_ })
}

/// ```prism
/// ParseSigiledType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_sigiled_type(p_: &crate::syntax::parser::Ps) -> (crate::syntax::Type, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p_);
    let (sigils, p1) = free_sigil_run(p_);
    let (inner, q) = parse_app_type(&p1);
    if &sigils == &Text::lit("") {
        (inner.clone(), q.clone())
    } else {
        (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TSigiled(sigils.clone(), Rc::new(inner.clone()))), span: crate::syntax::parser::to(&start, &inner.span) }, q.clone())
    }
}

/// The step machine of `ParseSigiledType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseSigiledType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseSigiledType {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)> for ParseSigiledType {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Type, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let start = crate::syntax::parser::here(p_);
        let (sigils, p1) = free_sigil_run(p_);
        call_then(start_parse_app_type(p1.clone()), move |parse_app_type_4083: (crate::syntax::Type, crate::syntax::parser::Ps)| {
            let (inner, q) = parse_app_type_4083;
            if &sigils == &Text::lit("") {
                prism_rtl::Turn::Finished((inner.clone(), q.clone()))
            } else {
                prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TSigiled(sigils.clone(), Rc::new(inner.clone()))), span: crate::syntax::parser::to(&start, &inner.span) }, q.clone()))
            }
        })
    }
}

/// `Start ParseSigiledType, x`: what the function value is when passed to `@Run`.
pub fn start_parse_sigiled_type(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>> {
    Rc::new(ParseSigiledType { p_ })
}

/// ```prism
/// FreeSigilRun: fn Ps -> ((Text, Ps))
/// ```
pub fn free_sigil_run(p0: &crate::syntax::parser::Ps) -> (Text, crate::syntax::parser::Ps) {
    let mut this: (Text, crate::syntax::parser::Ps) = (Text::lit(""), p0.clone());
    let mut sigils: Text = Text::lit("");
    let mut p_: crate::syntax::parser::Ps = p0.clone();
    let mut fuel: Nat = len(&p0.toks);
    while let Some(left) = (&fuel).checked_sub(&Nat::from(1u32)) {
        fuel = left.clone();
        match &crate::syntax::parser::kind(&p_) {
            crate::syntax::lexer::TokKind::KFree(s) => {
                sigils = Text::from(format!("{}{}", &sigils, s));
                p_ = crate::syntax::parser::adv(&p_);
            }
            _ => {
                fuel = Nat::from(0u32);
            }
        }
    }
    this = (sigils.clone(), p_.clone());
    this
}

/// ```prism
/// ParseAppType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_app_type(p_: &crate::syntax::parser::Ps) -> (crate::syntax::Type, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p_);
    let (head, p1) = parse_type_atom(p_);
    match &*head.kind {
        crate::syntax::TypeKind::TName(name, m4714_0_1) if (m4714_0_1.len() == 0) && type_atom_starts_here(&p1) => {
            let r = {
                let mut this: (Array<crate::syntax::Type>, crate::syntax::parser::Ps) = (Array::new(), p1.clone());
                let mut args: Array<crate::syntax::Type> = Array::new();
                let mut q: crate::syntax::parser::Ps = p1.clone();
                while type_atom_starts_here(&q) && !q.bad {
                    let (a, q2) = parse_type_atom(&q);
                    args = push(&args, &a);
                    q = q2.clone();
                }
                this = (args.clone(), q.clone());
                this
            };
            let (args, q) = r.clone();
            (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TName(name.clone(), args.clone())), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone())
        },
        _ => (head.clone(), p1.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ParseAppType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseAppType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseAppType {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)> for ParseAppType {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Type, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let start = crate::syntax::parser::here(p_);
        let p_ = p_.clone();
        call_then(start_parse_type_atom(p_.clone()), move |parse_type_atom_4694: (crate::syntax::Type, crate::syntax::parser::Ps)| {
            let (head, p1) = parse_type_atom_4694;
            match &*head.kind {
                crate::syntax::TypeKind::TName(name, m4714_0_1) if (m4714_0_1.len() == 0) && type_atom_starts_here(&p1) => {
                    let mut this: (Array<crate::syntax::Type>, crate::syntax::parser::Ps) = (Array::new(), p1.clone());
                    let mut args: Array<crate::syntax::Type> = Array::new();
                    let mut q: crate::syntax::parser::Ps = p1.clone();
                    let name = name.clone();
                    let start = start.clone();
                    call_then(loop_job((this, args, q), move |(mut this, mut args, mut q): ((Array<crate::syntax::Type>, crate::syntax::parser::Ps), Array<crate::syntax::Type>, crate::syntax::parser::Ps)| if type_atom_starts_here(&q) && !q.bad {
                        {
                            let (a, q2) = parse_type_atom(&q);
                            args = push(&args, &a);
                            q = q2.clone();
                            Ok((this, args, q))
                        }
                    } else {
                        Err((this, args, q))
                    }), move |(mut this, mut args, mut q): ((Array<crate::syntax::Type>, crate::syntax::parser::Ps), Array<crate::syntax::Type>, crate::syntax::parser::Ps)| {
                        this = (args.clone(), q.clone());
                        let r = this;
                        let (args, q) = r.clone();
                        prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TName(name.clone(), args.clone())), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone()))
                    })
                },
                _ => prism_rtl::Turn::Finished((head.clone(), p1.clone())),
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start ParseAppType, x`: what the function value is when passed to `@Run`.
pub fn start_parse_app_type(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>> {
    Rc::new(ParseAppType { p_ })
}

/// ```prism
/// TypeAtomStartsHere: fn Ps -> Bool
/// ```
pub fn type_atom_starts_here(p_: &crate::syntax::parser::Ps) -> bool {
    match crate::syntax::parser::kind(p_) {
        crate::syntax::lexer::TokKind::KName(_) => true,
        crate::syntax::lexer::TokKind::KFamily(_) => true,
        crate::syntax::lexer::TokKind::KFree(_) => true,
        crate::syntax::lexer::TokKind::KOpen(_, _) => true,
        crate::syntax::lexer::TokKind::KKw(w, _) => (&w == &Text::lit("unit")) || (&w == &Text::lit("any")),
        _ => false,
    }
}

/// ```prism
/// ParseTypeAtom: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_type_atom(p_: &crate::syntax::parser::Ps) -> (crate::syntax::Type, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p_);
    match crate::syntax::parser::kind(p_) {
        crate::syntax::lexer::TokKind::KFree(_) => parse_sigiled_type(p_),
        _ => {
            let (t, p1) = type_atom_body(p_, &start);
            if &crate::syntax::parser::kind(&p1) == &crate::syntax::lexer::TokKind::KNonEmpty {
                {
                    let m = crate::syntax::parser::here(&p1);
                    let q = crate::syntax::parser::out_of_scope(&crate::syntax::parser::adv(&p1), &m, &Text::lit("non-empty arrays"), &Text::lit("the non-empty array type `[a]+` is out of this compiler"));
                    (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TNonEmpty(Rc::new(t.clone()))), span: crate::syntax::parser::to(&start, &m) }, q.clone())
                }
            } else {
                (t.clone(), p1.clone())
            }
        },
    }
}

/// The step machine of `ParseTypeAtom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTypeAtom: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseTypeAtom {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)> for ParseTypeAtom {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Type, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let start = crate::syntax::parser::here(p_);
        match crate::syntax::parser::kind(p_) {
            crate::syntax::lexer::TokKind::KFree(_) => prism_rtl::Turn::More(Rc::new(ParseSigiledType { p_: p_.clone() })),
            _ => {
                let p_ = p_.clone();
                call_then(start_type_atom_body(p_.clone(), start.clone()), move |type_atom_body_5777: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (t, p1) = type_atom_body_5777;
                    if &crate::syntax::parser::kind(&p1) == &crate::syntax::lexer::TokKind::KNonEmpty {
                        {
                            let m = crate::syntax::parser::here(&p1);
                            let q = crate::syntax::parser::out_of_scope(&crate::syntax::parser::adv(&p1), &m, &Text::lit("non-empty arrays"), &Text::lit("the non-empty array type `[a]+` is out of this compiler"));
                            prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TNonEmpty(Rc::new(t.clone()))), span: crate::syntax::parser::to(&start, &m) }, q.clone()))
                        }
                    } else {
                        prism_rtl::Turn::Finished((t.clone(), p1.clone()))
                    }
                })
            },
        }
    }
}

/// `Start ParseTypeAtom, x`: what the function value is when passed to `@Run`.
pub fn start_parse_type_atom(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>> {
    Rc::new(ParseTypeAtom { p_ })
}

/// ```prism
/// TypeAtomBody: unbounded fn Ps, Range -> ((Type, Ps))
/// ```
pub fn type_atom_body(p_: &crate::syntax::parser::Ps, start: &crate::syntax::Range) -> (crate::syntax::Type, crate::syntax::parser::Ps) {
    match crate::syntax::parser::kind(p_) {
        crate::syntax::lexer::TokKind::KName(n) => {
            let name = crate::syntax::SName { sigils: n.sigils.clone(), path_: n.path_.clone(), span: start.clone() };
            if (&n.case == &crate::syntax::lexer::NameCase::CaseTopic) || (&n.case == &crate::syntax::lexer::NameCase::CaseHole) {
                (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::THole(name.clone())), span: start.clone() }, crate::syntax::parser::adv(p_))
            } else {
                (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TName(name.clone(), Array::new())), span: start.clone() }, crate::syntax::parser::check_type_name_scope(&crate::syntax::parser::adv(p_), &name))
            }
        },
        crate::syntax::lexer::TokKind::KKw(m6173_1_0, sigils) if (&m6173_1_0 == &Text::lit("unit")) => (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TUnit(sigils.clone())), span: start.clone() }, crate::syntax::parser::adv(p_)),
        crate::syntax::lexer::TokKind::KKw(m6173_2_0, _) if (&m6173_2_0 == &Text::lit("any")) => {
            let (tr, q) = crate::syntax::parser::parse_trait_ref(&crate::syntax::parser::adv(p_));
            (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TAny(tr.clone())), span: crate::syntax::parser::to(start, &crate::syntax::parser::prev(&q)) }, q.clone())
        },
        crate::syntax::lexer::TokKind::KFamily(path_) => (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TFamily(crate::syntax::QualName { path_: path_.clone(), span: start.clone() })), span: start.clone() }, crate::syntax::parser::adv(p_)),
        crate::syntax::lexer::TokKind::KAbsent => (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TAbsent), span: start.clone() }, crate::syntax::parser::out_of_scope(&crate::syntax::parser::adv(p_), start, &Text::lit("sparse tuples"), &Text::lit("a sparse tuple type is out of this compiler"))),
        crate::syntax::lexer::TokKind::KOpen(m6173_5_0, _) if (&m6173_5_0 == &Text::lit("(")) => if crate::syntax::parser::at_double_open(p_, &Text::lit("(")) {
            {
                let (elems, p1) = crate::syntax::parser::commas(&crate::syntax::parser::open_double(p_), &(Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_type(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>>>));
                let p2 = crate::syntax::parser::close_double(&p1, &Text::lit("("));
                (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TTuple(elems.clone())), span: crate::syntax::parser::to(start, &crate::syntax::parser::prev(&p2)) }, p2.clone())
            }
        } else {
            {
                let (inner, p1) = parse_type(&crate::syntax::parser::adv(p_));
                let p2 = crate::syntax::parser::expect_close(&p1, &Text::lit("("));
                (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TGroup(Rc::new(inner.clone()))), span: crate::syntax::parser::to(start, &crate::syntax::parser::prev(&p2)) }, p2.clone())
            }
        },
        crate::syntax::lexer::TokKind::KOpen(m6173_6_0, _) if (&m6173_6_0 == &Text::lit("[")) => {
            let doubled = crate::syntax::parser::at_double_open(p_, &Text::lit("["));
            let (elem, p1) = parse_type(&(if doubled {
                crate::syntax::parser::open_double(p_)
            } else {
                crate::syntax::parser::adv(p_)
            }));
            let p2 = if doubled {
                crate::syntax::parser::close_double(&p1, &Text::lit("["))
            } else {
                crate::syntax::parser::expect_close(&p1, &Text::lit("["))
            };
            (crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TArray(Rc::new(elem.clone()), doubled)), span: crate::syntax::parser::to(start, &crate::syntax::parser::prev(&p2)) }, p2.clone())
        },
        _ => (crate::syntax::parser::decls::no_type(), crate::syntax::parser::error_here(p_, &Text::lit("expected a type"))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `TypeAtomBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeAtomBody: unbounded fn Ps, Range -> ((Type, Ps))
/// ```
pub struct TypeAtomBody {
    pub p_: crate::syntax::parser::Ps,
    pub start: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)> for TypeAtomBody {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Type, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let start = &self.start;
        match crate::syntax::parser::kind(p_) {
            crate::syntax::lexer::TokKind::KName(n) => {
                let name = crate::syntax::SName { sigils: n.sigils.clone(), path_: n.path_.clone(), span: start.clone() };
                if (&n.case == &crate::syntax::lexer::NameCase::CaseTopic) || (&n.case == &crate::syntax::lexer::NameCase::CaseHole) {
                    prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::THole(name.clone())), span: start.clone() }, crate::syntax::parser::adv(p_)))
                } else {
                    prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TName(name.clone(), Array::new())), span: start.clone() }, crate::syntax::parser::check_type_name_scope(&crate::syntax::parser::adv(p_), &name)))
                }
            },
            crate::syntax::lexer::TokKind::KKw(m6173_1_0, sigils) if (&m6173_1_0 == &Text::lit("unit")) => prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TUnit(sigils.clone())), span: start.clone() }, crate::syntax::parser::adv(p_))),
            crate::syntax::lexer::TokKind::KKw(m6173_2_0, _) if (&m6173_2_0 == &Text::lit("any")) => {
                let (tr, q) = crate::syntax::parser::parse_trait_ref(&crate::syntax::parser::adv(p_));
                prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TAny(tr.clone())), span: crate::syntax::parser::to(start, &crate::syntax::parser::prev(&q)) }, q.clone()))
            },
            crate::syntax::lexer::TokKind::KFamily(path_) => prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TFamily(crate::syntax::QualName { path_: path_.clone(), span: start.clone() })), span: start.clone() }, crate::syntax::parser::adv(p_))),
            crate::syntax::lexer::TokKind::KAbsent => prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TAbsent), span: start.clone() }, crate::syntax::parser::out_of_scope(&crate::syntax::parser::adv(p_), start, &Text::lit("sparse tuples"), &Text::lit("a sparse tuple type is out of this compiler")))),
            crate::syntax::lexer::TokKind::KOpen(m6173_5_0, _) if (&m6173_5_0 == &Text::lit("(")) => if crate::syntax::parser::at_double_open(p_, &Text::lit("(")) {
                {
                    let p_ = p_.clone();
                    let start = start.clone();
                    call_then(crate::syntax::parser::start_commas(crate::syntax::parser::open_double(&p_), Rc::new(|a0: crate::syntax::parser::Ps| entered(start_parse_type(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>>>), move |commas_7134: (Array<crate::syntax::Type>, crate::syntax::parser::Ps)| {
                        let (elems, p1) = commas_7134;
                        let p2 = crate::syntax::parser::close_double(&p1, &Text::lit("("));
                        prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TTuple(elems.clone())), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p2)) }, p2.clone()))
                    })
                }
            } else {
                {
                    let p_ = p_.clone();
                    let start = start.clone();
                    call_then(start_parse_type(crate::syntax::parser::adv(&p_)), move |parse_type_7328: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                        let (inner, p1) = parse_type_7328;
                        let p2 = crate::syntax::parser::expect_close(&p1, &Text::lit("("));
                        prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TGroup(Rc::new(inner.clone()))), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p2)) }, p2.clone()))
                    })
                }
            },
            crate::syntax::lexer::TokKind::KOpen(m6173_6_0, _) if (&m6173_6_0 == &Text::lit("[")) => {
                let doubled = crate::syntax::parser::at_double_open(p_, &Text::lit("["));
                let p_ = p_.clone();
                let start = start.clone();
                call_then(start_parse_type(if doubled {
                    crate::syntax::parser::open_double(&p_)
                } else {
                    crate::syntax::parser::adv(&p_)
                }), move |parse_type_7553: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (elem, p1) = parse_type_7553;
                    let p2 = if doubled {
                        crate::syntax::parser::close_double(&p1, &Text::lit("["))
                    } else {
                        crate::syntax::parser::expect_close(&p1, &Text::lit("["))
                    };
                    prism_rtl::Turn::Finished((crate::syntax::Type { kind: Rc::new(crate::syntax::TypeKind::TArray(Rc::new(elem.clone()), doubled)), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p2)) }, p2.clone()))
                })
            },
            _ => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_type(), crate::syntax::parser::error_here(p_, &Text::lit("expected a type")))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start TypeAtomBody, x`: what the function value is when passed to `@Run`.
pub fn start_type_atom_body(p_: crate::syntax::parser::Ps, start: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>> {
    Rc::new(TypeAtomBody { p_, start })
}

/// ```prism
/// ParseBounds: unbounded fn Ps -> (([Bound], Ps))
/// ```
pub fn parse_bounds(p0: &crate::syntax::parser::Ps) -> (Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps) {
    let mut this: (Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps) = (Array::new(), p0.clone());
    let mut bounds: Array<crate::syntax::decls::Bound> = Array::new();
    let mut p_: crate::syntax::parser::Ps = p0.clone();
    let mut going: bool = true;
    while going && !p_.bad {
        let (b, q) = parse_bound(&p_);
        bounds = push(&bounds, &b);
        p_ = q.clone();
        if (crate::syntax::parser::at_comma(&p_) && is_name_kind(&crate::syntax::parser::kind_at(&p_, &Nat::from(1u32)))) && (&crate::syntax::parser::kind_at(&p_, &Nat::from(2u32)) == &crate::syntax::lexer::TokKind::KColon) {
            p_ = crate::syntax::parser::adv(&p_);
        } else {
            going = false;
        }
    }
    this = (bounds.clone(), p_.clone());
    this
}

/// The step machine of `ParseBounds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseBounds: unbounded fn Ps -> (([Bound], Ps))
/// ```
pub struct ParseBounds {
    pub p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps)> for ParseBounds {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let mut this: (Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps) = (Array::new(), p0.clone());
        let mut bounds: Array<crate::syntax::decls::Bound> = Array::new();
        let mut p_: crate::syntax::parser::Ps = p0.clone();
        let mut going: bool = true;
        call_then(loop_job((this, bounds, going, p_), move |(mut this, mut bounds, mut going, mut p_): ((Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps), Array<crate::syntax::decls::Bound>, bool, crate::syntax::parser::Ps)| if going && !p_.bad {
            {
                let (b, q) = parse_bound(&p_);
                bounds = push(&bounds, &b);
                p_ = q.clone();
                if (crate::syntax::parser::at_comma(&p_) && is_name_kind(&crate::syntax::parser::kind_at(&p_, &Nat::from(1u32)))) && (&crate::syntax::parser::kind_at(&p_, &Nat::from(2u32)) == &crate::syntax::lexer::TokKind::KColon) {
                    p_ = crate::syntax::parser::adv(&p_);
                } else {
                    going = false;
                }
                Ok((this, bounds, going, p_))
            }
        } else {
            Err((this, bounds, going, p_))
        }), move |(mut this, mut bounds, mut going, mut p_): ((Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps), Array<crate::syntax::decls::Bound>, bool, crate::syntax::parser::Ps)| {
            this = (bounds.clone(), p_.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start ParseBounds, x`: what the function value is when passed to `@Run`.
pub fn start_parse_bounds(p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps)>> {
    Rc::new(ParseBounds { p0 })
}

/// ```prism
/// IsNameKind: fn TokKind -> Bool
/// ```
pub fn is_name_kind(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KName(_) => true,
        _ => false,
    }
}

/// ```prism
/// IsTraitKind: fn TokKind -> Bool
/// ```
pub fn is_trait_kind(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KTrait(_) => true,
        _ => false,
    }
}

/// ```prism
/// ParseBound: unbounded fn Ps -> ((Bound, Ps))
/// ```
pub fn parse_bound(p_: &crate::syntax::parser::Ps) -> (crate::syntax::decls::Bound, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p_);
    let (var, p1) = crate::syntax::parser::parse_ident(p_);
    let (first_, p2) = crate::syntax::parser::parse_trait_ref(&crate::syntax::parser::expect_colon(&p1));
    let r = {
        let mut this: (Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps) = (Array::from(vec![first_.clone()]), p2.clone());
        let mut traits: Array<crate::syntax::TraitRef> = Array::from(vec![first_.clone()]);
        let mut q: crate::syntax::parser::Ps = p2.clone();
        while (crate::syntax::parser::at_comma(&q) && is_trait_kind(&crate::syntax::parser::kind_at(&q, &Nat::from(1u32)))) && !q.bad {
            let (t, q2) = crate::syntax::parser::parse_trait_ref(&crate::syntax::parser::adv(&q));
            traits = push(&traits, &t);
            q = q2.clone();
        }
        this = (traits.clone(), q.clone());
        this
    };
    let (traits, q) = r.clone();
    (crate::syntax::decls::Bound { var: var.clone(), traits: traits.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone())
}

/// The step machine of `ParseBound`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseBound: unbounded fn Ps -> ((Bound, Ps))
/// ```
pub struct ParseBound {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::Bound, crate::syntax::parser::Ps)> for ParseBound {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::Bound, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let start = crate::syntax::parser::here(p_);
        let (var, p1) = crate::syntax::parser::parse_ident(p_);
        let (first_, p2) = crate::syntax::parser::parse_trait_ref(&crate::syntax::parser::expect_colon(&p1));
        let mut this: (Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps) = (Array::from(vec![first_.clone()]), p2.clone());
        let mut traits: Array<crate::syntax::TraitRef> = Array::from(vec![first_.clone()]);
        let mut q: crate::syntax::parser::Ps = p2.clone();
        let start = start.clone();
        let var = var.clone();
        call_then(loop_job((this, q, traits), move |(mut this, mut q, mut traits): ((Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps), crate::syntax::parser::Ps, Array<crate::syntax::TraitRef>)| if (crate::syntax::parser::at_comma(&q) && is_trait_kind(&crate::syntax::parser::kind_at(&q, &Nat::from(1u32)))) && !q.bad {
            {
                let (t, q2) = crate::syntax::parser::parse_trait_ref(&crate::syntax::parser::adv(&q));
                traits = push(&traits, &t);
                q = q2.clone();
                Ok((this, q, traits))
            }
        } else {
            Err((this, q, traits))
        }), move |(mut this, mut q, mut traits): ((Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps), crate::syntax::parser::Ps, Array<crate::syntax::TraitRef>)| {
            this = (traits.clone(), q.clone());
            let r = this;
            let (traits, q) = r.clone();
            prism_rtl::Turn::Finished((crate::syntax::decls::Bound { var: var.clone(), traits: traits.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone()))
        })
    }
}

/// `Start ParseBound, x`: what the function value is when passed to `@Run`.
pub fn start_parse_bound(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::Bound, crate::syntax::parser::Ps)>> {
    Rc::new(ParseBound { p_ })
}

/// ```prism
/// ParseRow: unbounded fn Ps -> ((Row, Ps))
/// ```
pub fn parse_row(p_: &crate::syntax::parser::Ps) -> (crate::syntax::Row_, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p_);
    let (first_, p1) = parse_row_term(p_);
    let r = {
        let mut this: (Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps) = (Array::from(vec![first_.clone()]), p1.clone());
        let mut terms: Array<crate::syntax::RowTerm> = Array::from(vec![first_.clone()]);
        let mut q: crate::syntax::parser::Ps = p1.clone();
        while (&crate::syntax::parser::kind(&q) == &crate::syntax::lexer::TokKind::KBar) && !q.bad {
            let (t, q2) = parse_row_term(&crate::syntax::parser::adv(&q));
            terms = push(&terms, &t);
            q = q2.clone();
        }
        this = (terms.clone(), q.clone());
        this
    };
    let (terms, q) = r.clone();
    (crate::syntax::Row_ { terms: terms.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone())
}

/// The step machine of `ParseRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseRow: unbounded fn Ps -> ((Row, Ps))
/// ```
pub struct ParseRow {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Row_, crate::syntax::parser::Ps)> for ParseRow {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Row_, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let start = crate::syntax::parser::here(p_);
        let p_ = p_.clone();
        call_then(start_parse_row_term(p_.clone()), move |parse_row_term_9352: (crate::syntax::RowTerm, crate::syntax::parser::Ps)| {
            let (first_, p1) = parse_row_term_9352;
            let mut this: (Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps) = (Array::from(vec![first_.clone()]), p1.clone());
            let mut terms: Array<crate::syntax::RowTerm> = Array::from(vec![first_.clone()]);
            let mut q: crate::syntax::parser::Ps = p1.clone();
            let start = start.clone();
            call_then(loop_job((this, q, terms), move |(mut this, mut q, mut terms): ((Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps), crate::syntax::parser::Ps, Array<crate::syntax::RowTerm>)| if (&crate::syntax::parser::kind(&q) == &crate::syntax::lexer::TokKind::KBar) && !q.bad {
                {
                    let (t, q2) = parse_row_term(&crate::syntax::parser::adv(&q));
                    terms = push(&terms, &t);
                    q = q2.clone();
                    Ok((this, q, terms))
                }
            } else {
                Err((this, q, terms))
            }), move |(mut this, mut q, mut terms): ((Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps), crate::syntax::parser::Ps, Array<crate::syntax::RowTerm>)| {
                this = (terms.clone(), q.clone());
                let r = this;
                let (terms, q) = r.clone();
                prism_rtl::Turn::Finished((crate::syntax::Row_ { terms: terms.clone(), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone()))
            })
        })
    }
}

/// `Start ParseRow, x`: what the function value is when passed to `@Run`.
pub fn start_parse_row(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Row_, crate::syntax::parser::Ps)>> {
    Rc::new(ParseRow { p_ })
}

/// ```prism
/// ParseRowTerm: unbounded fn Ps -> ((RowTerm, Ps))
/// ```
pub fn parse_row_term(p_: &crate::syntax::parser::Ps) -> (crate::syntax::RowTerm, crate::syntax::parser::Ps) {
    match crate::syntax::parser::kind(p_) {
        crate::syntax::lexer::TokKind::KFamily(path_) => (crate::syntax::RowTerm::RFamily(crate::syntax::QualName { path_: path_.clone(), span: crate::syntax::parser::here(p_) }), crate::syntax::parser::adv(p_)),
        crate::syntax::lexer::TokKind::KName(n) if (is_plain_lower_one(&crate::syntax::lexer::TokKind::KName(n.clone())) && !type_atom_after_name(p_)) => (crate::syntax::RowTerm::RVar(crate::syntax::Ident { name: or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")), span: crate::syntax::parser::here(p_) }), crate::syntax::parser::adv(p_)),
        _ => {
            let (t, q) = parse_map_type(p_);
            (crate::syntax::RowTerm::RType(t.clone()), q.clone())
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ParseRowTerm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseRowTerm: unbounded fn Ps -> ((RowTerm, Ps))
/// ```
pub struct ParseRowTerm {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::RowTerm, crate::syntax::parser::Ps)> for ParseRowTerm {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::RowTerm, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        match crate::syntax::parser::kind(p_) {
            crate::syntax::lexer::TokKind::KFamily(path_) => prism_rtl::Turn::Finished((crate::syntax::RowTerm::RFamily(crate::syntax::QualName { path_: path_.clone(), span: crate::syntax::parser::here(p_) }), crate::syntax::parser::adv(p_))),
            crate::syntax::lexer::TokKind::KName(n) if (is_plain_lower_one(&crate::syntax::lexer::TokKind::KName(n.clone())) && !type_atom_after_name(p_)) => prism_rtl::Turn::Finished((crate::syntax::RowTerm::RVar(crate::syntax::Ident { name: or(&index(&n.path_, &Nat::from(0u32)), &Text::lit("")), span: crate::syntax::parser::here(p_) }), crate::syntax::parser::adv(p_))),
            _ => {
                let p_ = p_.clone();
                call_then(start_parse_map_type(p_.clone()), move |parse_map_type_10063: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (t, q) = parse_map_type_10063;
                    prism_rtl::Turn::Finished((crate::syntax::RowTerm::RType(t.clone()), q.clone()))
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ParseRowTerm, x`: what the function value is when passed to `@Run`.
pub fn start_parse_row_term(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::RowTerm, crate::syntax::parser::Ps)>> {
    Rc::new(ParseRowTerm { p_ })
}

/// ```prism
/// TypeAtomAfterName: fn Ps -> Bool
/// ```
pub fn type_atom_after_name(p_: &crate::syntax::parser::Ps) -> bool {
    match crate::syntax::parser::kind_at(p_, &Nat::from(1u32)) {
        crate::syntax::lexer::TokKind::KName(_) => true,
        crate::syntax::lexer::TokKind::KOpen(_, _) => true,
        crate::syntax::lexer::TokKind::KFamily(_) => true,
        _ => false,
    }
}

/// ```prism
/// ParsePattern: unbounded fn Ps, Bool -> ((Pattern, Ps))
/// ```
pub fn parse_pattern(p_: &crate::syntax::parser::Ps, commas0: &bool) -> (crate::syntax::Pattern_, crate::syntax::parser::Ps) {
    let commas = *commas0 && !p_.step_mode;
    let start = crate::syntax::parser::here(p_);
    match crate::syntax::parser::kind(p_) {
        crate::syntax::lexer::TokKind::KFree(s) if ((&s == &Text::lit("?")) || (&s == &Text::lit("~"))) => {
            let (inner, q) = parse_pattern(&crate::syntax::parser::adv(p_), &commas);
            (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PSigil(s.clone(), Rc::new(inner.clone()))), span: crate::syntax::parser::to(&start, &inner.span) }, q.clone())
        },
        crate::syntax::lexer::TokKind::KFree(s) => (crate::syntax::parser::decls::no_pattern(), crate::syntax::parser::error_at(p_, &start, &Text::from(format!("a free `{}` is not a pattern: only `? p` and `~ p` take a value apart", &s)))),
        crate::syntax::lexer::TokKind::KName(n) => name_pattern(p_, &n, &commas),
        crate::syntax::lexer::TokKind::KKw(m10847_3_0, _) if (&m10847_3_0 == &Text::lit("ignore")) => (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: start.clone() }, crate::syntax::parser::adv(p_)),
        crate::syntax::lexer::TokKind::KKw(m10847_4_0, _) if (&m10847_4_0 == &Text::lit("unit")) => (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PUnit), span: start.clone() }, crate::syntax::parser::adv(p_)),
        crate::syntax::lexer::TokKind::KKw(m10847_5_0, _) if (&m10847_5_0 == &Text::lit("nil")) => (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PNil), span: start.clone() }, crate::syntax::parser::adv(p_)),
        crate::syntax::lexer::TokKind::KInt(_, _) => literal_pattern(p_),
        crate::syntax::lexer::TokKind::KFloat(_, _) => literal_pattern(p_),
        crate::syntax::lexer::TokKind::KDuration(_, _, _) => literal_pattern(p_),
        crate::syntax::lexer::TokKind::KChar(_, _) => literal_pattern(p_),
        crate::syntax::lexer::TokKind::KText(_, _) => literal_pattern(p_),
        crate::syntax::lexer::TokKind::KRegex(_, _) => (crate::syntax::parser::decls::no_pattern(), crate::syntax::parser::error_at(p_, &start, &Text::lit("a regular expression is not a pattern: match a text with `?Match` or `?Find`"))),
        crate::syntax::lexer::TokKind::KOp(m10847_12_0, true) if (&m10847_12_0 == &Text::lit("-")) => {
            let p1 = crate::syntax::parser::adv(p_);
            if is_number_kind(&crate::syntax::parser::kind(&p1)) {
                {
                    let (lit, q) = crate::syntax::parser::expr::parse_literal(&p1);
                    (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PNeg(lit.clone())), span: crate::syntax::parser::to(&start, &lit.span) }, q.clone())
                }
            } else {
                (crate::syntax::parser::decls::no_pattern(), crate::syntax::parser::error_here(&p1, &Text::lit("a `-` in a pattern is the sign of a number literal")))
            }
        },
        crate::syntax::lexer::TokKind::KOpen(m10847_13_0, _) if (&m10847_13_0 == &Text::lit("(")) => if crate::syntax::parser::at_double_open(p_, &Text::lit("(")) {
            {
                let (elems, p1) = crate::syntax::parser::commas(&crate::syntax::parser::open_double(p_), &(Rc::new(move |p0: crate::syntax::parser::Ps| entered(once_job(move || {
                    let q = p0;
                    prism_rtl::Turn::More(Rc::new(ParsePattern { p_: q.clone(), commas0: false }))
                }))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>>>));
                let p2 = crate::syntax::parser::close_double(&p1, &Text::lit("("));
                (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PTuple(elems.clone())), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p2)) }, p2.clone())
            }
        } else {
            {
                let (inner, p1) = crate::syntax::parser::bracketed(&crate::syntax::parser::adv(p_), &(Rc::new(move |p0: crate::syntax::parser::Ps| entered(once_job(move || {
                    let q = p0;
                    prism_rtl::Turn::More(Rc::new(ParsePattern { p_: q.clone(), commas0: true }))
                }))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>>>));
                let p2 = crate::syntax::parser::expect_close(&p1, &Text::lit("("));
                (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PGroup(Rc::new(inner.clone()))), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p2)) }, p2.clone())
            }
        },
        crate::syntax::lexer::TokKind::KOpen(m10847_14_0, _) if (&m10847_14_0 == &Text::lit("[")) && crate::syntax::parser::at_double_open(p_, &Text::lit("[")) => {
            let p1 = crate::syntax::parser::open_double(p_);
            let (elems, p2) = if crate::syntax::parser::at_close(&p1, &Text::lit("[")) {
                (Array::new(), p1.clone())
            } else {
                crate::syntax::parser::commas(&p1, &(Rc::new(move |p0: crate::syntax::parser::Ps| entered(once_job(move || {
                    let q = p0;
                    prism_rtl::Turn::More(Rc::new(ParsePattern { p_: q.clone(), commas0: false }))
                }))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>>>))
            };
            let p3 = crate::syntax::parser::close_double(&p2, &Text::lit("["));
            (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PArray(elems.clone())), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p3)) }, p3.clone())
        },
        crate::syntax::lexer::TokKind::KFamily(path_) => (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PFamily(crate::syntax::QualName { path_: path_.clone(), span: start.clone() })), span: start.clone() }, crate::syntax::parser::adv(p_)),
        crate::syntax::lexer::TokKind::KAbsent => (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: start.clone() }, crate::syntax::parser::out_of_scope(&crate::syntax::parser::adv(p_), &start, &Text::lit("sparse tuples"), &Text::lit("an absent component `-` is a sparse tuple's, out of this compiler"))),
        _ => (crate::syntax::parser::decls::no_pattern(), crate::syntax::parser::error_here(p_, &Text::lit("expected a pattern"))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ParsePattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParsePattern: unbounded fn Ps, Bool -> ((Pattern, Ps))
/// ```
pub struct ParsePattern {
    pub p_: crate::syntax::parser::Ps,
    pub commas0: bool,
}

impl prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)> for ParsePattern {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Pattern_, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let commas0 = &self.commas0;
        let commas = *commas0 && !p_.step_mode;
        let start = crate::syntax::parser::here(p_);
        match crate::syntax::parser::kind(p_) {
            crate::syntax::lexer::TokKind::KFree(s) if ((&s == &Text::lit("?")) || (&s == &Text::lit("~"))) => {
                let p_ = p_.clone();
                call_then(start_parse_pattern(crate::syntax::parser::adv(&p_), commas), move |parse_pattern_10933: (crate::syntax::Pattern_, crate::syntax::parser::Ps)| {
                    let (inner, q) = parse_pattern_10933;
                    prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PSigil(s.clone(), Rc::new(inner.clone()))), span: crate::syntax::parser::to(&start, &inner.span) }, q.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KFree(s) => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_pattern(), crate::syntax::parser::error_at(p_, &start, &Text::from(format!("a free `{}` is not a pattern: only `? p` and `~ p` take a value apart", &s))))),
            crate::syntax::lexer::TokKind::KName(n) => prism_rtl::Turn::More(Rc::new(NamePattern { p0: p_.clone(), n: n.clone(), commas })),
            crate::syntax::lexer::TokKind::KKw(m10847_3_0, _) if (&m10847_3_0 == &Text::lit("ignore")) => prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: start.clone() }, crate::syntax::parser::adv(p_))),
            crate::syntax::lexer::TokKind::KKw(m10847_4_0, _) if (&m10847_4_0 == &Text::lit("unit")) => prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PUnit), span: start.clone() }, crate::syntax::parser::adv(p_))),
            crate::syntax::lexer::TokKind::KKw(m10847_5_0, _) if (&m10847_5_0 == &Text::lit("nil")) => prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PNil), span: start.clone() }, crate::syntax::parser::adv(p_))),
            crate::syntax::lexer::TokKind::KInt(_, _) => prism_rtl::Turn::More(Rc::new(LiteralPattern { p_: p_.clone() })),
            crate::syntax::lexer::TokKind::KFloat(_, _) => prism_rtl::Turn::More(Rc::new(LiteralPattern { p_: p_.clone() })),
            crate::syntax::lexer::TokKind::KDuration(_, _, _) => prism_rtl::Turn::More(Rc::new(LiteralPattern { p_: p_.clone() })),
            crate::syntax::lexer::TokKind::KChar(_, _) => prism_rtl::Turn::More(Rc::new(LiteralPattern { p_: p_.clone() })),
            crate::syntax::lexer::TokKind::KText(_, _) => prism_rtl::Turn::More(Rc::new(LiteralPattern { p_: p_.clone() })),
            crate::syntax::lexer::TokKind::KRegex(_, _) => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_pattern(), crate::syntax::parser::error_at(p_, &start, &Text::lit("a regular expression is not a pattern: match a text with `?Match` or `?Find`")))),
            crate::syntax::lexer::TokKind::KOp(m10847_12_0, true) if (&m10847_12_0 == &Text::lit("-")) => {
                let p1 = crate::syntax::parser::adv(p_);
                if is_number_kind(&crate::syntax::parser::kind(&p1)) {
                    call_then(crate::syntax::parser::expr::start_parse_literal(p1.clone()), move |parse_literal_11989: (crate::syntax::Literal, crate::syntax::parser::Ps)| {
                        let (lit, q) = parse_literal_11989;
                        prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PNeg(lit.clone())), span: crate::syntax::parser::to(&start, &lit.span) }, q.clone()))
                    })
                } else {
                    prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_pattern(), crate::syntax::parser::error_here(&p1, &Text::lit("a `-` in a pattern is the sign of a number literal"))))
                }
            },
            crate::syntax::lexer::TokKind::KOpen(m10847_13_0, _) if (&m10847_13_0 == &Text::lit("(")) => if crate::syntax::parser::at_double_open(p_, &Text::lit("(")) {
                {
                    let p_ = p_.clone();
                    call_then(crate::syntax::parser::start_commas(crate::syntax::parser::open_double(&p_), Rc::new(move |p0: crate::syntax::parser::Ps| entered(once_job(move || {
                        let q = p0;
                        prism_rtl::Turn::More(Rc::new(ParsePattern { p_: q.clone(), commas0: false }))
                    }))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>>>), move |commas_12281: (Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps)| {
                        let (elems, p1) = commas_12281;
                        let p2 = crate::syntax::parser::close_double(&p1, &Text::lit("("));
                        prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PTuple(elems.clone())), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p2)) }, p2.clone()))
                    })
                }
            } else {
                {
                    let p_ = p_.clone();
                    call_then(crate::syntax::parser::start_bracketed(crate::syntax::parser::adv(&p_), Rc::new(move |p0: crate::syntax::parser::Ps| entered(once_job(move || {
                        let q = p0;
                        prism_rtl::Turn::More(Rc::new(ParsePattern { p_: q.clone(), commas0: true }))
                    }))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>>>), move |bracketed_12668: (crate::syntax::Pattern_, crate::syntax::parser::Ps)| {
                        let (inner, p1) = bracketed_12668;
                        let p2 = crate::syntax::parser::expect_close(&p1, &Text::lit("("));
                        prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PGroup(Rc::new(inner.clone()))), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p2)) }, p2.clone()))
                    })
                }
            },
            crate::syntax::lexer::TokKind::KOpen(m10847_14_0, _) if (&m10847_14_0 == &Text::lit("[")) && crate::syntax::parser::at_double_open(p_, &Text::lit("[")) => {
                let p1 = crate::syntax::parser::open_double(p_);
                let (elems, p2) = if crate::syntax::parser::at_close(&p1, &Text::lit("[")) {
                    (Array::new(), p1.clone())
                } else {
                    crate::syntax::parser::commas(&p1, &(Rc::new(move |p0: crate::syntax::parser::Ps| entered(once_job(move || {
                        let q = p0;
                        prism_rtl::Turn::More(Rc::new(ParsePattern { p_: q.clone(), commas0: false }))
                    }))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>>>))
                };
                let p3 = crate::syntax::parser::close_double(&p2, &Text::lit("["));
                prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PArray(elems.clone())), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&p3)) }, p3.clone()))
            },
            crate::syntax::lexer::TokKind::KFamily(path_) => prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PFamily(crate::syntax::QualName { path_: path_.clone(), span: start.clone() })), span: start.clone() }, crate::syntax::parser::adv(p_))),
            crate::syntax::lexer::TokKind::KAbsent => prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: start.clone() }, crate::syntax::parser::out_of_scope(&crate::syntax::parser::adv(p_), &start, &Text::lit("sparse tuples"), &Text::lit("an absent component `-` is a sparse tuple's, out of this compiler")))),
            _ => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_pattern(), crate::syntax::parser::error_here(p_, &Text::lit("expected a pattern")))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ParsePattern, x`: what the function value is when passed to `@Run`.
pub fn start_parse_pattern(p_: crate::syntax::parser::Ps, commas0: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>> {
    Rc::new(ParsePattern { p_, commas0 })
}

/// ```prism
/// IsNumberKind: fn TokKind -> Bool
/// ```
pub fn is_number_kind(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KInt(_, _) => true,
        crate::syntax::lexer::TokKind::KFloat(_, _) => true,
        crate::syntax::lexer::TokKind::KDuration(_, _, _) => true,
        _ => false,
    }
}

/// ```prism
/// LiteralPattern: unbounded fn Ps -> ((Pattern, Ps))
/// ```
pub fn literal_pattern(p_: &crate::syntax::parser::Ps) -> (crate::syntax::Pattern_, crate::syntax::parser::Ps) {
    let (lit, q) = crate::syntax::parser::expr::parse_literal(p_);
    (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PLit(lit.clone())), span: lit.span.clone() }, q.clone())
}

/// The step machine of `LiteralPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LiteralPattern: unbounded fn Ps -> ((Pattern, Ps))
/// ```
pub struct LiteralPattern {
    pub p_: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)> for LiteralPattern {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Pattern_, crate::syntax::parser::Ps)> {
        let p_ = &self.p_;
        let p_ = p_.clone();
        call_then(crate::syntax::parser::expr::start_parse_literal(p_.clone()), move |parse_literal_13802: (crate::syntax::Literal, crate::syntax::parser::Ps)| {
            let (lit, q) = parse_literal_13802;
            prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PLit(lit.clone())), span: lit.span.clone() }, q.clone()))
        })
    }
}

/// `Start LiteralPattern, x`: what the function value is when passed to `@Run`.
pub fn start_literal_pattern(p_: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>> {
    Rc::new(LiteralPattern { p_ })
}

/// ```prism
/// NamePattern: unbounded fn Ps, NameTok, Bool -> ((Pattern, Ps))
/// ```
pub fn name_pattern(p0: &crate::syntax::parser::Ps, n: &crate::syntax::lexer::NameTok, commas: &bool) -> (crate::syntax::Pattern_, crate::syntax::parser::Ps) {
    let start = crate::syntax::parser::here(p0);
    let name = crate::syntax::SName { sigils: n.sigils.clone(), path_: n.path_.clone(), span: start.clone() };
    let p_ = crate::syntax::parser::adv(p0);
    if (crate::syntax::parser::is_callee(&name) && crate::syntax::parser::at_single_open(&p_, &Text::lit("("))) && crate::syntax::parser::tk(&p_).touches {
        parse_record_pattern(&p_, &name)
    } else {
        if crate::syntax::parser::is_callee(&name) && pat_arg_starts_here(&p_) {
            {
                let (first_, p1) = parse_pattern(&p_, &false);
                let r = {
                    let mut this: (Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps) = (Array::from(vec![first_.clone()]), p1.clone());
                    let mut args: Array<crate::syntax::Pattern_> = Array::from(vec![first_.clone()]);
                    let mut q: crate::syntax::parser::Ps = p1.clone();
                    while (*commas && crate::syntax::parser::at_comma(&q)) && !q.bad {
                        let (a, q2) = parse_pattern(&crate::syntax::parser::adv(&q), &false);
                        args = push(&args, &a);
                        q = q2.clone();
                    }
                    this = (args.clone(), q.clone());
                    this
                };
                let (args, q) = r.clone();
                (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PCtor(name.clone(), args.clone())), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone())
            }
        } else {
            (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PName(name.clone())), span: start.clone() }, p_.clone())
        }
    }
}

/// The step machine of `NamePattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamePattern: unbounded fn Ps, NameTok, Bool -> ((Pattern, Ps))
/// ```
pub struct NamePattern {
    pub p0: crate::syntax::parser::Ps,
    pub n: crate::syntax::lexer::NameTok,
    pub commas: bool,
}

impl prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)> for NamePattern {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Pattern_, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let n = &self.n;
        let commas = &self.commas;
        let start = crate::syntax::parser::here(p0);
        let name = crate::syntax::SName { sigils: n.sigils.clone(), path_: n.path_.clone(), span: start.clone() };
        let p_ = crate::syntax::parser::adv(p0);
        if (crate::syntax::parser::is_callee(&name) && crate::syntax::parser::at_single_open(&p_, &Text::lit("("))) && crate::syntax::parser::tk(&p_).touches {
            prism_rtl::Turn::More(Rc::new(ParseRecordPattern { p0: p_.clone(), name: name.clone() }))
        } else {
            if crate::syntax::parser::is_callee(&name) && pat_arg_starts_here(&p_) {
                {
                    let commas = *commas;
                    call_then(start_parse_pattern(p_.clone(), false), move |parse_pattern_14247: (crate::syntax::Pattern_, crate::syntax::parser::Ps)| {
                        let (first_, p1) = parse_pattern_14247;
                        let mut this: (Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps) = (Array::from(vec![first_.clone()]), p1.clone());
                        let mut args: Array<crate::syntax::Pattern_> = Array::from(vec![first_.clone()]);
                        let mut q: crate::syntax::parser::Ps = p1.clone();
                        let name = name.clone();
                        let start = start.clone();
                        call_then(loop_job((this, args, q), {
                            let commas = commas;
                            move |(mut this, mut args, mut q): ((Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps), Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps)| if (commas && crate::syntax::parser::at_comma(&q)) && !q.bad {
                                {
                                    let (a, q2) = parse_pattern(&crate::syntax::parser::adv(&q), &false);
                                    args = push(&args, &a);
                                    q = q2.clone();
                                    Ok((this, args, q))
                                }
                            } else {
                                Err((this, args, q))
                            }
                        }), move |(mut this, mut args, mut q): ((Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps), Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps)| {
                            this = (args.clone(), q.clone());
                            let r = this;
                            let (args, q) = r.clone();
                            prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PCtor(name.clone(), args.clone())), span: crate::syntax::parser::to(&start, &crate::syntax::parser::prev(&q)) }, q.clone()))
                        })
                    })
                }
            } else {
                prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PName(name.clone())), span: start.clone() }, p_.clone()))
            }
        }
    }
}

/// `Start NamePattern, x`: what the function value is when passed to `@Run`.
pub fn start_name_pattern(p0: crate::syntax::parser::Ps, n: crate::syntax::lexer::NameTok, commas: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>> {
    Rc::new(NamePattern { p0, n, commas })
}

/// ```prism
/// PatArgStartsHere: fn Ps -> Bool
/// ```
pub fn pat_arg_starts_here(p_: &crate::syntax::parser::Ps) -> bool {
    match crate::syntax::parser::kind(p_) {
        crate::syntax::lexer::TokKind::KName(_) => true,
        crate::syntax::lexer::TokKind::KInt(_, _) => true,
        crate::syntax::lexer::TokKind::KFloat(_, _) => true,
        crate::syntax::lexer::TokKind::KDuration(_, _, _) => true,
        crate::syntax::lexer::TokKind::KChar(_, _) => true,
        crate::syntax::lexer::TokKind::KText(_, _) => true,
        crate::syntax::lexer::TokKind::KFamily(_) => true,
        crate::syntax::lexer::TokKind::KFree(s) => (&s == &Text::lit("?")) || (&s == &Text::lit("~")),
        crate::syntax::lexer::TokKind::KOpen(m14865_8_0, _) if (&m14865_8_0 == &Text::lit("(")) => !crate::syntax::parser::tk(p_).touches || crate::syntax::parser::at_double_open(p_, &Text::lit("(")),
        crate::syntax::lexer::TokKind::KOpen(m14865_9_0, _) if (&m14865_9_0 == &Text::lit("[")) => crate::syntax::parser::at_double_open(p_, &Text::lit("[")),
        crate::syntax::lexer::TokKind::KOp(m14865_10_0, true) if (&m14865_10_0 == &Text::lit("-")) => true,
        crate::syntax::lexer::TokKind::KKw(w, _) => ((&w == &Text::lit("ignore")) || (&w == &Text::lit("unit"))) || (&w == &Text::lit("nil")),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParseRecordPattern: unbounded fn Ps, SName -> ((Pattern, Ps))
/// ```
pub fn parse_record_pattern(p0: &crate::syntax::parser::Ps, name: &crate::syntax::SName) -> (crate::syntax::Pattern_, crate::syntax::parser::Ps) {
    let p_ = crate::syntax::parser::adv(p0);
    let r = {
        let mut this: FieldsRead = FieldsRead { fields: Array::new(), rest: false, p_: p_.clone(), going: !crate::syntax::parser::at_close(&p_, &Text::lit("(")) };
        while this.going && !this.p_.bad {
            if &crate::syntax::parser::kind(&this.p_) == &crate::syntax::lexer::TokKind::KDotDot {
                this.p_ = crate::syntax::parser::adv(&this.p_);
                this.rest = true;
            } else {
                let fstart = crate::syntax::parser::here(&this.p_);
                let (fname_opt, p1) = crate::syntax::parser::expr::parse_arg_name(&this.p_);
                let (pattern, p2) = parse_pattern(&p1, &false);
                this.fields = push(&this.fields, &crate::syntax::FieldPat { name: fname_opt.clone(), pattern: pattern.clone(), span: crate::syntax::parser::to(&fstart, &pattern.span) });
                this.p_ = p2.clone();
            }
            if crate::syntax::parser::at_comma(&this.p_) {
                this.p_ = crate::syntax::parser::adv(&this.p_);
            } else {
                this.going = false;
            }
        }
        this
    };
    let q = crate::syntax::parser::expect_close(&r.p_, &Text::lit("("));
    (crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PRecord(name.clone(), r.fields.clone(), r.rest)), span: crate::syntax::parser::to(&name.span, &crate::syntax::parser::prev(&q)) }, q.clone())
}

/// The step machine of `ParseRecordPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseRecordPattern: unbounded fn Ps, SName -> ((Pattern, Ps))
/// ```
pub struct ParseRecordPattern {
    pub p0: crate::syntax::parser::Ps,
    pub name: crate::syntax::SName,
}

impl prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)> for ParseRecordPattern {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Pattern_, crate::syntax::parser::Ps)> {
        let p0 = &self.p0;
        let name = &self.name;
        let p_ = crate::syntax::parser::adv(p0);
        let mut this: FieldsRead = FieldsRead { fields: Array::new(), rest: false, p_: p_.clone(), going: !crate::syntax::parser::at_close(&p_, &Text::lit("(")) };
        let name = name.clone();
        let p_ = p_.clone();
        call_then(loop_job((this,), {
            let name = name.clone();
            let p_ = p_.clone();
            move |(mut this,): (FieldsRead,)| if this.going && !this.p_.bad {
                {
                    if &crate::syntax::parser::kind(&this.p_) == &crate::syntax::lexer::TokKind::KDotDot {
                        this.p_ = crate::syntax::parser::adv(&this.p_);
                        this.rest = true;
                    } else {
                        let fstart = crate::syntax::parser::here(&this.p_);
                        let (fname_opt, p1) = crate::syntax::parser::expr::parse_arg_name(&this.p_);
                        let (pattern, p2) = parse_pattern(&p1, &false);
                        this.fields = push(&this.fields, &crate::syntax::FieldPat { name: fname_opt.clone(), pattern: pattern.clone(), span: crate::syntax::parser::to(&fstart, &pattern.span) });
                        this.p_ = p2.clone();
                    }
                    if crate::syntax::parser::at_comma(&this.p_) {
                        this.p_ = crate::syntax::parser::adv(&this.p_);
                    } else {
                        this.going = false;
                    }
                    Ok((this,))
                }
            } else {
                Err((this,))
            }
        }), move |(mut this,): (FieldsRead,)| {
            let r = this;
            let q = crate::syntax::parser::expect_close(&r.p_, &Text::lit("("));
            prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PRecord(name.clone(), r.fields.clone(), r.rest)), span: crate::syntax::parser::to(&name.span, &crate::syntax::parser::prev(&q)) }, q.clone()))
        })
    }
}

/// `Start ParseRecordPattern, x`: what the function value is when passed to `@Run`.
pub fn start_parse_record_pattern(p0: crate::syntax::parser::Ps, name: crate::syntax::SName) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>> {
    Rc::new(ParseRecordPattern { p0, name })
}
