//! The module `Syntax.Parser.Types`, from `target/bootstrap/src/prismc/syntax/parser/types.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `FieldsRead`:
///
/// ```prism
/// type FieldsRead = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct FieldsRead {
    pub fields_p: Array<crate::syntax::FieldPat>,
    pub rest_p: bool,
    pub p_p: crate::syntax::parser::Ps,
    pub going_p: bool,
}

impl Show for FieldsRead {
    fn show(&self, p: &mut Printer) {
        p.record("FieldsRead", &[("fields", &self.fields_p), ("rest", &self.rest_p), ("p", &self.p_p), ("going", &self.going_p)]);
    }
}

impl ToPod for FieldsRead {
    fn to_pod(&self) -> Pod {
        Pod::record("FieldsRead", vec![("fields", self.fields_p.to_pod()), ("rest", self.rest_p.to_pod()), ("p", self.p_p.to_pod()), ("going", self.going_p.to_pod())])
    }
}

impl FromPod for FieldsRead {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(FieldsRead { fields_p: FromPod::from_pod(field(p, "fields")?)?, rest_p: FromPod::from_pod(field(p, "rest")?)?, p_p: FromPod::from_pod(field(p, "p")?)?, going_p: FromPod::from_pod(field(p, "going")?)? })
    }
}

/// ```prism
/// ParseType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_type_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Type, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p_p0);
    let color_var_p2 = is_plain_lower_one_f(&crate::syntax::parser::kind_f(p_p0)) && is_fn_kw_f(&crate::syntax::parser::kind_at_f(p_p0, &Nat::from(1u32)));
    let (color_p3, p1_p4) = if crate::syntax::parser::at_kw_f(p_p0, &Text::lit("unbounded")) {
        (crate::syntax::Color::Unbounded, crate::syntax::parser::adv_f(p_p0))
    } else {
        if color_var_p2 {
            color_var_of_f(p_p0)
        } else {
            (crate::syntax::Color::Bounded, p_p0.clone())
        }
    };
    if crate::syntax::parser::at_kw_f(&p1_p4, &Text::lit("fn")) {
        {
            let p2_p5 = crate::syntax::parser::adv_f(&p1_p4);
            let (params_p6, p3_p7) = if crate::syntax::parser::at_op_f(&p2_p5, &Text::lit("->")) {
                (Array::new(), p2_p5.clone())
            } else {
                crate::syntax::parser::commas_f(&p2_p5, &(Rc::new(|a0: crate::syntax::parser::Ps| crate::prelude::entered(start_parse_emit_type_f(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>>>))
            };
            let (result_p8, p4_p9) = parse_type_f(&crate::syntax::parser::expect_op_f(&p3_p7, &Text::lit("->")));
            (crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TFn(color_p3.clone(), params_p6.clone(), Rc::new(result_p8.clone()))), span_p: crate::syntax::parser::to_f(&start_p1, &result_p8.span_p) }, p4_p9.clone())
        }
    } else {
        if &color_p3 != &crate::syntax::Color::Bounded {
            (crate::syntax::parser::decls::no_type_p(), crate::syntax::parser::error_here_f(&p1_p4, &Text::lit("a color (`unbounded`, or a color variable) is written before a function type\'s `fn`")))
        } else {
            {
                let (t_pa, q_pb) = parse_emit_type_f(&p1_p4);
                if crate::syntax::parser::at_op_f(&q_pb, &Text::lit("->")) {
                    (t_pa.clone(), crate::syntax::parser::error_at_f(&q_pb, &crate::syntax::parser::here_f(&q_pb), &Text::lit("a function type begins with `fn`: `fn A -> B`")))
                } else {
                    (t_pa.clone(), q_pb.clone())
                }
            }
        }
    }
}

/// The step machine of `ParseType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseType {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)> for ParseType {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Type, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here_f(p_p0);
        let color_var_p2 = is_plain_lower_one_f(&crate::syntax::parser::kind_f(p_p0)) && is_fn_kw_f(&crate::syntax::parser::kind_at_f(p_p0, &Nat::from(1u32)));
        let (color_p3, p1_p4) = if crate::syntax::parser::at_kw_f(p_p0, &Text::lit("unbounded")) {
            (crate::syntax::Color::Unbounded, crate::syntax::parser::adv_f(p_p0))
        } else {
            if color_var_p2 {
                color_var_of_f(p_p0)
            } else {
                (crate::syntax::Color::Bounded, p_p0.clone())
            }
        };
        if crate::syntax::parser::at_kw_f(&p1_p4, &Text::lit("fn")) {
            {
                let p2_p5 = crate::syntax::parser::adv_f(&p1_p4);
                let (params_p6, p3_p7) = if crate::syntax::parser::at_op_f(&p2_p5, &Text::lit("->")) {
                    (Array::new(), p2_p5.clone())
                } else {
                    crate::syntax::parser::commas_f(&p2_p5, &(Rc::new(|a0: crate::syntax::parser::Ps| crate::prelude::entered(start_parse_emit_type_f(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>>>))
                };
                crate::prelude::call_then(start_parse_type_f(crate::syntax::parser::expect_op_f(&p3_p7, &Text::lit("->"))), move |parse_type_f_1974: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (result_p8, p4_p9) = parse_type_f_1974;
                    prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TFn(color_p3.clone(), params_p6.clone(), Rc::new(result_p8.clone()))), span_p: crate::syntax::parser::to_f(&start_p1, &result_p8.span_p) }, p4_p9.clone()))
                })
            }
        } else {
            if &color_p3 != &crate::syntax::Color::Bounded {
                prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_type_p(), crate::syntax::parser::error_here_f(&p1_p4, &Text::lit("a color (`unbounded`, or a color variable) is written before a function type\'s `fn`"))))
            } else {
                crate::prelude::call_then(start_parse_emit_type_f(p1_p4.clone()), move |parse_emit_type_f_2267: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (t_pa, q_pb) = parse_emit_type_f_2267;
                    if crate::syntax::parser::at_op_f(&q_pb, &Text::lit("->")) {
                        prism_rtl::Turn::Finished((t_pa.clone(), crate::syntax::parser::error_at_f(&q_pb, &crate::syntax::parser::here_f(&q_pb), &Text::lit("a function type begins with `fn`: `fn A -> B`"))))
                    } else {
                        prism_rtl::Turn::Finished((t_pa.clone(), q_pb.clone()))
                    }
                })
            }
        }
    }
}

/// `Start ParseType, x`: what the function value is when passed to `@Run`.
pub fn start_parse_type_f(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>> {
    Rc::new(ParseType { p_p0 })
}

/// ```prism
/// IsPlainLowerOne: fn TokKind -> Bool
/// ```
pub fn is_plain_lower_one_f(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KName(n_p0) => ((&n_p0.sigils_p == &Text::lit("")) && (&n_p0.case_p == &crate::syntax::lexer::NameCase::CaseLower)) && (&crate::prelude::len(&n_p0.path_p) == &Nat::from(1u32)),
        _ => false,
    }
}

/// ```prism
/// IsFnKw: fn TokKind -> Bool
/// ```
pub fn is_fn_kw_f(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KKw(c0_0_0, _) if (c0_0_0 == &Text::lit("fn")) => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ColorVarOf: fn Ps -> ((Color, Ps))
/// ```
pub fn color_var_of_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Color, crate::syntax::parser::Ps) {
    let (i_p1, q_p2) = crate::syntax::parser::parse_ident_f(p_p0);
    (crate::syntax::Color::ColorVar(i_p1.clone()), q_p2.clone())
}

/// ```prism
/// ParseEmitType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_emit_type_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Type, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p_p0);
    let (t_p2, p1_p3) = parse_union_type_f(p_p0);
    if crate::syntax::parser::at_kw_f(&p1_p3, &Text::lit("emit")) {
        {
            let (r_p4, q_p5) = parse_union_type_f(&crate::syntax::parser::adv_f(&p1_p3));
            (crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TEmit(Rc::new(t_p2.clone()), Rc::new(r_p4.clone()))), span_p: crate::syntax::parser::to_f(&start_p1, &r_p4.span_p) }, q_p5.clone())
        }
    } else {
        (t_p2.clone(), p1_p3.clone())
    }
}

/// The step machine of `ParseEmitType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseEmitType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseEmitType {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)> for ParseEmitType {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Type, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here_f(p_p0);
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(start_parse_union_type_f(p_p0x.clone()), move |parse_union_type_f_2872: (crate::syntax::Type, crate::syntax::parser::Ps)| {
            let (t_p2, p1_p3) = parse_union_type_f_2872;
            if crate::syntax::parser::at_kw_f(&p1_p3, &Text::lit("emit")) {
                crate::prelude::call_then(start_parse_union_type_f(crate::syntax::parser::adv_f(&p1_p3)), move |parse_union_type_f_2936: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (r_p4, q_p5) = parse_union_type_f_2936;
                    prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TEmit(Rc::new(t_p2.clone()), Rc::new(r_p4.clone()))), span_p: crate::syntax::parser::to_f(&start_p1, &r_p4.span_p) }, q_p5.clone()))
                })
            } else {
                prism_rtl::Turn::Finished((t_p2.clone(), p1_p3.clone()))
            }
        })
    }
}

/// `Start ParseEmitType, x`: what the function value is when passed to `@Run`.
pub fn start_parse_emit_type_f(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>> {
    Rc::new(ParseEmitType { p_p0 })
}

/// ```prism
/// ParseUnionType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_union_type_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Type, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p_p0);
    let (first_p2, p1_p3) = parse_map_type_f(p_p0);
    if &crate::syntax::parser::kind_f(&p1_p3) != &crate::syntax::lexer::TokKind::KBar {
        (first_p2.clone(), p1_p3.clone())
    } else {
        {
            let r_p4 = {
                let mut this: (Array<crate::syntax::Type>, crate::syntax::parser::Ps) = (Array::from(vec![first_p2.clone()]), p1_p3.clone());
                let mut terms_p5: Array<crate::syntax::Type> = Array::from(vec![first_p2.clone()]);
                let mut q_p6: crate::syntax::parser::Ps = p1_p3.clone();
                while (&crate::syntax::parser::kind_f(&q_p6) == &crate::syntax::lexer::TokKind::KBar) && !q_p6.bad_p {
                    let (t_p7, q2_p8) = parse_map_type_f(&crate::syntax::parser::adv_f(&q_p6));
                    terms_p5 = crate::prelude::push(&terms_p5, &t_p7);
                    q_p6 = q2_p8.clone();
                }
                this = (terms_p5.clone(), q_p6.clone());
                this
            };
            let (terms_p9, q_pa) = r_p4.clone();
            (crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TRowUnion(terms_p9.clone())), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&q_pa)) }, q_pa.clone())
        }
    }
}

/// The step machine of `ParseUnionType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseUnionType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseUnionType {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)> for ParseUnionType {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Type, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here_f(p_p0);
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(start_parse_map_type_f(p_p0x.clone()), move |parse_map_type_f_3161: (crate::syntax::Type, crate::syntax::parser::Ps)| {
            let (first_p2, p1_p3) = parse_map_type_f_3161;
            if &crate::syntax::parser::kind_f(&p1_p3) != &crate::syntax::lexer::TokKind::KBar {
                prism_rtl::Turn::Finished((first_p2.clone(), p1_p3.clone()))
            } else {
                {
                    let mut this: (Array<crate::syntax::Type>, crate::syntax::parser::Ps) = (Array::from(vec![first_p2.clone()]), p1_p3.clone());
                    let mut terms_p5: Array<crate::syntax::Type> = Array::from(vec![first_p2.clone()]);
                    let mut q_p6: crate::syntax::parser::Ps = p1_p3.clone();
                    let start_p1z = start_p1.clone();
                    crate::prelude::call_then(crate::prelude::loop_job((this, q_p6, terms_p5), move |(mut this, mut q_p6, mut terms_p5): ((Array<crate::syntax::Type>, crate::syntax::parser::Ps), crate::syntax::parser::Ps, Array<crate::syntax::Type>)| if (&crate::syntax::parser::kind_f(&q_p6) == &crate::syntax::lexer::TokKind::KBar) && !q_p6.bad_p {
                        {
                            let (t_p7, q2_p8) = parse_map_type_f(&crate::syntax::parser::adv_f(&q_p6));
                            terms_p5 = crate::prelude::push(&terms_p5, &t_p7);
                            q_p6 = q2_p8.clone();
                            Ok((this, q_p6, terms_p5))
                        }
                    } else {
                        Err((this, q_p6, terms_p5))
                    }), move |(mut this, mut q_p6, mut terms_p5): ((Array<crate::syntax::Type>, crate::syntax::parser::Ps), crate::syntax::parser::Ps, Array<crate::syntax::Type>)| {
                        this = (terms_p5.clone(), q_p6.clone());
                        let r_p4 = this;
                        let (terms_p9, q_pa) = r_p4.clone();
                        prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TRowUnion(terms_p9.clone())), span_p: crate::syntax::parser::to_f(&start_p1z, &crate::syntax::parser::prev_f(&q_pa)) }, q_pa.clone()))
                    })
                }
            }
        })
    }
}

/// `Start ParseUnionType, x`: what the function value is when passed to `@Run`.
pub fn start_parse_union_type_f(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>> {
    Rc::new(ParseUnionType { p_p0 })
}

/// ```prism
/// ParseMapType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_map_type_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Type, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p_p0);
    let (k_p2, p1_p3) = parse_sigiled_type_f(p_p0);
    if crate::syntax::parser::at_op_f(&p1_p3, &Text::lit("==>")) {
        {
            let (value_p4, q_p5) = parse_map_type_f(&crate::syntax::parser::adv_f(&p1_p3));
            (crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TMap(Rc::new(k_p2.clone()), Rc::new(value_p4.clone()))), span_p: crate::syntax::parser::to_f(&start_p1, &value_p4.span_p) }, q_p5.clone())
        }
    } else {
        (k_p2.clone(), p1_p3.clone())
    }
}

/// The step machine of `ParseMapType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseMapType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseMapType {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)> for ParseMapType {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Type, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here_f(p_p0);
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(start_parse_sigiled_type_f(p_p0x.clone()), move |parse_sigiled_type_f_3741: (crate::syntax::Type, crate::syntax::parser::Ps)| {
            let (k_p2, p1_p3) = parse_sigiled_type_f_3741;
            if crate::syntax::parser::at_op_f(&p1_p3, &Text::lit("==>")) {
                crate::prelude::call_then(start_parse_map_type_f(crate::syntax::parser::adv_f(&p1_p3)), move |parse_map_type_f_3810: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (value_p4, q_p5) = parse_map_type_f_3810;
                    prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TMap(Rc::new(k_p2.clone()), Rc::new(value_p4.clone()))), span_p: crate::syntax::parser::to_f(&start_p1, &value_p4.span_p) }, q_p5.clone()))
                })
            } else {
                prism_rtl::Turn::Finished((k_p2.clone(), p1_p3.clone()))
            }
        })
    }
}

/// `Start ParseMapType, x`: what the function value is when passed to `@Run`.
pub fn start_parse_map_type_f(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>> {
    Rc::new(ParseMapType { p_p0 })
}

/// ```prism
/// ParseSigiledType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_sigiled_type_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Type, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p_p0);
    let (sigils_p2, p1_p3) = free_sigil_run_f(p_p0);
    let (inner_p4, q_p5) = parse_app_type_f(&p1_p3);
    if &sigils_p2 == &Text::lit("") {
        (inner_p4.clone(), q_p5.clone())
    } else {
        (crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TSigiled(sigils_p2.clone(), Rc::new(inner_p4.clone()))), span_p: crate::syntax::parser::to_f(&start_p1, &inner_p4.span_p) }, q_p5.clone())
    }
}

/// The step machine of `ParseSigiledType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseSigiledType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseSigiledType {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)> for ParseSigiledType {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Type, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here_f(p_p0);
        let (sigils_p2, p1_p3) = free_sigil_run_f(p_p0);
        crate::prelude::call_then(start_parse_app_type_f(p1_p3.clone()), move |parse_app_type_f_4083: (crate::syntax::Type, crate::syntax::parser::Ps)| {
            let (inner_p4, q_p5) = parse_app_type_f_4083;
            if &sigils_p2 == &Text::lit("") {
                prism_rtl::Turn::Finished((inner_p4.clone(), q_p5.clone()))
            } else {
                prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TSigiled(sigils_p2.clone(), Rc::new(inner_p4.clone()))), span_p: crate::syntax::parser::to_f(&start_p1, &inner_p4.span_p) }, q_p5.clone()))
            }
        })
    }
}

/// `Start ParseSigiledType, x`: what the function value is when passed to `@Run`.
pub fn start_parse_sigiled_type_f(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>> {
    Rc::new(ParseSigiledType { p_p0 })
}

/// ```prism
/// FreeSigilRun: fn Ps -> ((Text, Ps))
/// ```
pub fn free_sigil_run_f(p0_p0: &crate::syntax::parser::Ps) -> (Text, crate::syntax::parser::Ps) {
    let mut this: (Text, crate::syntax::parser::Ps) = (Text::lit(""), p0_p0.clone());
    let mut sigils_p1: Text = Text::lit("");
    let mut p_p2: crate::syntax::parser::Ps = p0_p0.clone();
    let mut fuel_p3: Nat = crate::prelude::len(&p0_p0.toks_p);
    while let Some(left_p4) = (&fuel_p3).checked_sub(&Nat::from(1u32)) {
        fuel_p3 = left_p4.clone();
        match &crate::syntax::parser::kind_f(&p_p2) {
            crate::syntax::lexer::TokKind::KFree(s_p5) => {
                sigils_p1 = Text::from(format!("{}{}", &sigils_p1, s_p5));
                p_p2 = crate::syntax::parser::adv_f(&p_p2);
            }
            _ => {
                fuel_p3 = Nat::from(0u32);
            }
        }
    }
    this = (sigils_p1.clone(), p_p2.clone());
    this
}

/// ```prism
/// ParseAppType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_app_type_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Type, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p_p0);
    let (head_p2, p1_p3) = parse_type_atom_f(p_p0);
    match &*head_p2.kind_p {
        crate::syntax::TypeKind::TName(name_p4, m4714_0_1) if (m4714_0_1.len() == 0) && type_atom_starts_here_f(&p1_p3) => {
            let r_p5 = {
                let mut this: (Array<crate::syntax::Type>, crate::syntax::parser::Ps) = (Array::new(), p1_p3.clone());
                let mut args_p6: Array<crate::syntax::Type> = Array::new();
                let mut q_p7: crate::syntax::parser::Ps = p1_p3.clone();
                while type_atom_starts_here_f(&q_p7) && !q_p7.bad_p {
                    let (a_p8, q2_p9) = parse_type_atom_f(&q_p7);
                    args_p6 = crate::prelude::push(&args_p6, &a_p8);
                    q_p7 = q2_p9.clone();
                }
                this = (args_p6.clone(), q_p7.clone());
                this
            };
            let (args_pa, q_pb) = r_p5.clone();
            (crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TName(name_p4.clone(), args_pa.clone())), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&q_pb)) }, q_pb.clone())
        },
        _ => (head_p2.clone(), p1_p3.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ParseAppType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseAppType: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseAppType {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)> for ParseAppType {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Type, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here_f(p_p0);
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(start_parse_type_atom_f(p_p0x.clone()), move |parse_type_atom_f_4694: (crate::syntax::Type, crate::syntax::parser::Ps)| {
            let (head_p2, p1_p3) = parse_type_atom_f_4694;
            match &*head_p2.kind_p {
                crate::syntax::TypeKind::TName(name_p4, m4714_0_1) if (m4714_0_1.len() == 0) && type_atom_starts_here_f(&p1_p3) => {
                    let mut this: (Array<crate::syntax::Type>, crate::syntax::parser::Ps) = (Array::new(), p1_p3.clone());
                    let mut args_p6: Array<crate::syntax::Type> = Array::new();
                    let mut q_p7: crate::syntax::parser::Ps = p1_p3.clone();
                    let name_p4z = name_p4.clone();
                    let start_p1z = start_p1.clone();
                    crate::prelude::call_then(crate::prelude::loop_job((this, args_p6, q_p7), move |(mut this, mut args_p6, mut q_p7): ((Array<crate::syntax::Type>, crate::syntax::parser::Ps), Array<crate::syntax::Type>, crate::syntax::parser::Ps)| if type_atom_starts_here_f(&q_p7) && !q_p7.bad_p {
                        {
                            let (a_p8, q2_p9) = parse_type_atom_f(&q_p7);
                            args_p6 = crate::prelude::push(&args_p6, &a_p8);
                            q_p7 = q2_p9.clone();
                            Ok((this, args_p6, q_p7))
                        }
                    } else {
                        Err((this, args_p6, q_p7))
                    }), move |(mut this, mut args_p6, mut q_p7): ((Array<crate::syntax::Type>, crate::syntax::parser::Ps), Array<crate::syntax::Type>, crate::syntax::parser::Ps)| {
                        this = (args_p6.clone(), q_p7.clone());
                        let r_p5 = this;
                        let (args_pa, q_pb) = r_p5.clone();
                        prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TName(name_p4z.clone(), args_pa.clone())), span_p: crate::syntax::parser::to_f(&start_p1z, &crate::syntax::parser::prev_f(&q_pb)) }, q_pb.clone()))
                    })
                },
                _ => prism_rtl::Turn::Finished((head_p2.clone(), p1_p3.clone())),
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start ParseAppType, x`: what the function value is when passed to `@Run`.
pub fn start_parse_app_type_f(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>> {
    Rc::new(ParseAppType { p_p0 })
}

/// ```prism
/// TypeAtomStartsHere: fn Ps -> Bool
/// ```
pub fn type_atom_starts_here_f(p_p0: &crate::syntax::parser::Ps) -> bool {
    match crate::syntax::parser::kind_f(p_p0) {
        crate::syntax::lexer::TokKind::KName(_) => true,
        crate::syntax::lexer::TokKind::KFamily(_) => true,
        crate::syntax::lexer::TokKind::KFree(_) => true,
        crate::syntax::lexer::TokKind::KOpen(_, _) => true,
        crate::syntax::lexer::TokKind::KKw(w_p1, _) => (&w_p1 == &Text::lit("unit")) || (&w_p1 == &Text::lit("any")),
        _ => false,
    }
}

/// ```prism
/// ParseTypeAtom: unbounded fn Ps -> ((Type, Ps))
/// ```
pub fn parse_type_atom_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Type, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p_p0);
    match crate::syntax::parser::kind_f(p_p0) {
        crate::syntax::lexer::TokKind::KFree(_) => parse_sigiled_type_f(p_p0),
        _ => {
            let (t_p2, p1_p3) = type_atom_body_f(p_p0, &start_p1);
            if &crate::syntax::parser::kind_f(&p1_p3) == &crate::syntax::lexer::TokKind::KNonEmpty {
                {
                    let m_p4 = crate::syntax::parser::here_f(&p1_p3);
                    let q_p5 = crate::syntax::parser::out_of_scope_f(&crate::syntax::parser::adv_f(&p1_p3), &m_p4, &Text::lit("non-empty arrays"), &Text::lit("the non-empty array type `[a]+` is out of this compiler"));
                    (crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TNonEmpty(Rc::new(t_p2.clone()))), span_p: crate::syntax::parser::to_f(&start_p1, &m_p4) }, q_p5.clone())
                }
            } else {
                (t_p2.clone(), p1_p3.clone())
            }
        },
    }
}

/// The step machine of `ParseTypeAtom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseTypeAtom: unbounded fn Ps -> ((Type, Ps))
/// ```
pub struct ParseTypeAtom {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)> for ParseTypeAtom {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Type, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here_f(p_p0);
        match crate::syntax::parser::kind_f(p_p0) {
            crate::syntax::lexer::TokKind::KFree(_) => prism_rtl::Turn::More(Rc::new(ParseSigiledType { p_p0: p_p0.clone() })),
            _ => {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(start_type_atom_body_f(p_p0x.clone(), start_p1.clone()), move |type_atom_body_f_5777: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (t_p2, p1_p3) = type_atom_body_f_5777;
                    if &crate::syntax::parser::kind_f(&p1_p3) == &crate::syntax::lexer::TokKind::KNonEmpty {
                        {
                            let m_p4 = crate::syntax::parser::here_f(&p1_p3);
                            let q_p5 = crate::syntax::parser::out_of_scope_f(&crate::syntax::parser::adv_f(&p1_p3), &m_p4, &Text::lit("non-empty arrays"), &Text::lit("the non-empty array type `[a]+` is out of this compiler"));
                            prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TNonEmpty(Rc::new(t_p2.clone()))), span_p: crate::syntax::parser::to_f(&start_p1, &m_p4) }, q_p5.clone()))
                        }
                    } else {
                        prism_rtl::Turn::Finished((t_p2.clone(), p1_p3.clone()))
                    }
                })
            },
        }
    }
}

/// `Start ParseTypeAtom, x`: what the function value is when passed to `@Run`.
pub fn start_parse_type_atom_f(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>> {
    Rc::new(ParseTypeAtom { p_p0 })
}

/// ```prism
/// TypeAtomBody: unbounded fn Ps, Range -> ((Type, Ps))
/// ```
pub fn type_atom_body_f(p_p0: &crate::syntax::parser::Ps, start_p1: &crate::syntax::Range) -> (crate::syntax::Type, crate::syntax::parser::Ps) {
    match crate::syntax::parser::kind_f(p_p0) {
        crate::syntax::lexer::TokKind::KName(n_p2) => {
            let name_p3 = crate::syntax::SName { sigils_p: n_p2.sigils_p.clone(), path_p: n_p2.path_p.clone(), span_p: start_p1.clone() };
            if (&n_p2.case_p == &crate::syntax::lexer::NameCase::CaseTopic) || (&n_p2.case_p == &crate::syntax::lexer::NameCase::CaseHole) {
                (crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::THole(name_p3.clone())), span_p: start_p1.clone() }, crate::syntax::parser::adv_f(p_p0))
            } else {
                (crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TName(name_p3.clone(), Array::new())), span_p: start_p1.clone() }, crate::syntax::parser::check_type_name_scope_f(&crate::syntax::parser::adv_f(p_p0), &name_p3))
            }
        },
        crate::syntax::lexer::TokKind::KKw(m6173_1_0, sigils_p4) if (&m6173_1_0 == &Text::lit("unit")) => (crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TUnit(sigils_p4)), span_p: start_p1.clone() }, crate::syntax::parser::adv_f(p_p0)),
        crate::syntax::lexer::TokKind::KKw(m6173_2_0, _) if (&m6173_2_0 == &Text::lit("any")) => {
            let (tr_p5, q_p6) = crate::syntax::parser::parse_trait_ref_f(&crate::syntax::parser::adv_f(p_p0));
            (crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TAny(tr_p5.clone())), span_p: crate::syntax::parser::to_f(start_p1, &crate::syntax::parser::prev_f(&q_p6)) }, q_p6.clone())
        },
        crate::syntax::lexer::TokKind::KFamily(path_p7) => (crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TFamily(crate::syntax::QualName { path_p: path_p7.clone(), span_p: start_p1.clone() })), span_p: start_p1.clone() }, crate::syntax::parser::adv_f(p_p0)),
        crate::syntax::lexer::TokKind::KAbsent => (crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TAbsent), span_p: start_p1.clone() }, crate::syntax::parser::out_of_scope_f(&crate::syntax::parser::adv_f(p_p0), start_p1, &Text::lit("sparse tuples"), &Text::lit("a sparse tuple type is out of this compiler"))),
        crate::syntax::lexer::TokKind::KOpen(m6173_5_0, _) if (&m6173_5_0 == &Text::lit("(")) => if crate::syntax::parser::at_double_open_f(p_p0, &Text::lit("(")) {
            {
                let (elems_p9, p1_pa) = crate::syntax::parser::commas_f(&crate::syntax::parser::open_double_f(p_p0), &(Rc::new(|a0: crate::syntax::parser::Ps| crate::prelude::entered(start_parse_type_f(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>>>));
                let p2_p8 = crate::syntax::parser::close_double_f(&p1_pa, &Text::lit("("));
                (crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TTuple(elems_p9.clone())), span_p: crate::syntax::parser::to_f(start_p1, &crate::syntax::parser::prev_f(&p2_p8)) }, p2_p8.clone())
            }
        } else {
            {
                let (inner_pc, p1_pd) = parse_type_f(&crate::syntax::parser::adv_f(p_p0));
                let p2_pb = crate::syntax::parser::expect_close_f(&p1_pd, &Text::lit("("));
                (crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TGroup(Rc::new(inner_pc.clone()))), span_p: crate::syntax::parser::to_f(start_p1, &crate::syntax::parser::prev_f(&p2_pb)) }, p2_pb.clone())
            }
        },
        crate::syntax::lexer::TokKind::KOpen(m6173_6_0, _) if (&m6173_6_0 == &Text::lit("[")) => {
            let doubled_pe = crate::syntax::parser::at_double_open_f(p_p0, &Text::lit("["));
            let (elem_pg, p1_ph) = parse_type_f(&(if doubled_pe {
                crate::syntax::parser::open_double_f(p_p0)
            } else {
                crate::syntax::parser::adv_f(p_p0)
            }));
            let p2_pf = if doubled_pe {
                crate::syntax::parser::close_double_f(&p1_ph, &Text::lit("["))
            } else {
                crate::syntax::parser::expect_close_f(&p1_ph, &Text::lit("["))
            };
            (crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TArray(Rc::new(elem_pg.clone()), doubled_pe)), span_p: crate::syntax::parser::to_f(start_p1, &crate::syntax::parser::prev_f(&p2_pf)) }, p2_pf.clone())
        },
        _ => (crate::syntax::parser::decls::no_type_p(), crate::syntax::parser::error_here_f(p_p0, &Text::lit("expected a type"))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `TypeAtomBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeAtomBody: unbounded fn Ps, Range -> ((Type, Ps))
/// ```
pub struct TypeAtomBody {
    pub p_p0: crate::syntax::parser::Ps,
    pub start_p1: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)> for TypeAtomBody {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Type, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = &self.start_p1;
        match crate::syntax::parser::kind_f(p_p0) {
            crate::syntax::lexer::TokKind::KName(n_p2) => {
                let name_p3 = crate::syntax::SName { sigils_p: n_p2.sigils_p.clone(), path_p: n_p2.path_p.clone(), span_p: start_p1.clone() };
                if (&n_p2.case_p == &crate::syntax::lexer::NameCase::CaseTopic) || (&n_p2.case_p == &crate::syntax::lexer::NameCase::CaseHole) {
                    prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::THole(name_p3.clone())), span_p: start_p1.clone() }, crate::syntax::parser::adv_f(p_p0)))
                } else {
                    prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TName(name_p3.clone(), Array::new())), span_p: start_p1.clone() }, crate::syntax::parser::check_type_name_scope_f(&crate::syntax::parser::adv_f(p_p0), &name_p3)))
                }
            },
            crate::syntax::lexer::TokKind::KKw(m6173_1_0, sigils_p4) if (&m6173_1_0 == &Text::lit("unit")) => prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TUnit(sigils_p4.clone())), span_p: start_p1.clone() }, crate::syntax::parser::adv_f(p_p0))),
            crate::syntax::lexer::TokKind::KKw(m6173_2_0, _) if (&m6173_2_0 == &Text::lit("any")) => {
                let (tr_p5, q_p6) = crate::syntax::parser::parse_trait_ref_f(&crate::syntax::parser::adv_f(p_p0));
                prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TAny(tr_p5.clone())), span_p: crate::syntax::parser::to_f(start_p1, &crate::syntax::parser::prev_f(&q_p6)) }, q_p6.clone()))
            },
            crate::syntax::lexer::TokKind::KFamily(path_p7) => prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TFamily(crate::syntax::QualName { path_p: path_p7.clone(), span_p: start_p1.clone() })), span_p: start_p1.clone() }, crate::syntax::parser::adv_f(p_p0))),
            crate::syntax::lexer::TokKind::KAbsent => prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TAbsent), span_p: start_p1.clone() }, crate::syntax::parser::out_of_scope_f(&crate::syntax::parser::adv_f(p_p0), start_p1, &Text::lit("sparse tuples"), &Text::lit("a sparse tuple type is out of this compiler")))),
            crate::syntax::lexer::TokKind::KOpen(m6173_5_0, _) if (&m6173_5_0 == &Text::lit("(")) => if crate::syntax::parser::at_double_open_f(p_p0, &Text::lit("(")) {
                {
                    let p_p0x = p_p0.clone();
                    let start_p1x = start_p1.clone();
                    crate::prelude::call_then(crate::syntax::parser::start_commas_f(crate::syntax::parser::open_double_f(&p_p0x), Rc::new(|a0: crate::syntax::parser::Ps| crate::prelude::entered(start_parse_type_f(a0))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>>>), move |commas_f_7134: (Array<crate::syntax::Type>, crate::syntax::parser::Ps)| {
                        let (elems_p9, p1_pa) = commas_f_7134;
                        let p2_p8 = crate::syntax::parser::close_double_f(&p1_pa, &Text::lit("("));
                        prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TTuple(elems_p9.clone())), span_p: crate::syntax::parser::to_f(&start_p1x, &crate::syntax::parser::prev_f(&p2_p8)) }, p2_p8.clone()))
                    })
                }
            } else {
                {
                    let p_p0x = p_p0.clone();
                    let start_p1x = start_p1.clone();
                    crate::prelude::call_then(start_parse_type_f(crate::syntax::parser::adv_f(&p_p0x)), move |parse_type_f_7328: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                        let (inner_pc, p1_pd) = parse_type_f_7328;
                        let p2_pb = crate::syntax::parser::expect_close_f(&p1_pd, &Text::lit("("));
                        prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TGroup(Rc::new(inner_pc.clone()))), span_p: crate::syntax::parser::to_f(&start_p1x, &crate::syntax::parser::prev_f(&p2_pb)) }, p2_pb.clone()))
                    })
                }
            },
            crate::syntax::lexer::TokKind::KOpen(m6173_6_0, _) if (&m6173_6_0 == &Text::lit("[")) => {
                let doubled_pe = crate::syntax::parser::at_double_open_f(p_p0, &Text::lit("["));
                let p_p0x = p_p0.clone();
                let start_p1x = start_p1.clone();
                crate::prelude::call_then(start_parse_type_f(if doubled_pe {
                    crate::syntax::parser::open_double_f(&p_p0x)
                } else {
                    crate::syntax::parser::adv_f(&p_p0x)
                }), move |parse_type_f_7553: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (elem_pg, p1_ph) = parse_type_f_7553;
                    let p2_pf = if doubled_pe {
                        crate::syntax::parser::close_double_f(&p1_ph, &Text::lit("["))
                    } else {
                        crate::syntax::parser::expect_close_f(&p1_ph, &Text::lit("["))
                    };
                    prism_rtl::Turn::Finished((crate::syntax::Type { kind_p: Rc::new(crate::syntax::TypeKind::TArray(Rc::new(elem_pg.clone()), doubled_pe)), span_p: crate::syntax::parser::to_f(&start_p1x, &crate::syntax::parser::prev_f(&p2_pf)) }, p2_pf.clone()))
                })
            },
            _ => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_type_p(), crate::syntax::parser::error_here_f(p_p0, &Text::lit("expected a type")))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start TypeAtomBody, x`: what the function value is when passed to `@Run`.
pub fn start_type_atom_body_f(p_p0: crate::syntax::parser::Ps, start_p1: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::syntax::Type, crate::syntax::parser::Ps)>> {
    Rc::new(TypeAtomBody { p_p0, start_p1 })
}

/// ```prism
/// ParseBounds: unbounded fn Ps -> (([Bound], Ps))
/// ```
pub fn parse_bounds_f(p0_p0: &crate::syntax::parser::Ps) -> (Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps) {
    let mut this: (Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps) = (Array::new(), p0_p0.clone());
    let mut bounds_p1: Array<crate::syntax::decls::Bound> = Array::new();
    let mut p_p2: crate::syntax::parser::Ps = p0_p0.clone();
    let mut going_p3: bool = true;
    while going_p3 && !p_p2.bad_p {
        let (b_p4, q_p5) = parse_bound_f(&p_p2);
        bounds_p1 = crate::prelude::push(&bounds_p1, &b_p4);
        p_p2 = q_p5.clone();
        if (crate::syntax::parser::at_comma_f(&p_p2) && is_name_kind_f(&crate::syntax::parser::kind_at_f(&p_p2, &Nat::from(1u32)))) && (&crate::syntax::parser::kind_at_f(&p_p2, &Nat::from(2u32)) == &crate::syntax::lexer::TokKind::KColon) {
            p_p2 = crate::syntax::parser::adv_f(&p_p2);
        } else {
            going_p3 = false;
        }
    }
    this = (bounds_p1.clone(), p_p2.clone());
    this
}

/// The step machine of `ParseBounds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseBounds: unbounded fn Ps -> (([Bound], Ps))
/// ```
pub struct ParseBounds {
    pub p0_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps)> for ParseBounds {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let mut this: (Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps) = (Array::new(), p0_p0.clone());
        let mut bounds_p1: Array<crate::syntax::decls::Bound> = Array::new();
        let mut p_p2: crate::syntax::parser::Ps = p0_p0.clone();
        let mut going_p3: bool = true;
        crate::prelude::call_then(crate::prelude::loop_job((this, bounds_p1, going_p3, p_p2), move |(mut this, mut bounds_p1, mut going_p3, mut p_p2): ((Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps), Array<crate::syntax::decls::Bound>, bool, crate::syntax::parser::Ps)| if going_p3 && !p_p2.bad_p {
            {
                let (b_p4, q_p5) = parse_bound_f(&p_p2);
                bounds_p1 = crate::prelude::push(&bounds_p1, &b_p4);
                p_p2 = q_p5.clone();
                if (crate::syntax::parser::at_comma_f(&p_p2) && is_name_kind_f(&crate::syntax::parser::kind_at_f(&p_p2, &Nat::from(1u32)))) && (&crate::syntax::parser::kind_at_f(&p_p2, &Nat::from(2u32)) == &crate::syntax::lexer::TokKind::KColon) {
                    p_p2 = crate::syntax::parser::adv_f(&p_p2);
                } else {
                    going_p3 = false;
                }
                Ok((this, bounds_p1, going_p3, p_p2))
            }
        } else {
            Err((this, bounds_p1, going_p3, p_p2))
        }), move |(mut this, mut bounds_p1, mut going_p3, mut p_p2): ((Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps), Array<crate::syntax::decls::Bound>, bool, crate::syntax::parser::Ps)| {
            this = (bounds_p1.clone(), p_p2.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start ParseBounds, x`: what the function value is when passed to `@Run`.
pub fn start_parse_bounds_f(p0_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::decls::Bound>, crate::syntax::parser::Ps)>> {
    Rc::new(ParseBounds { p0_p0 })
}

/// ```prism
/// IsNameKind: fn TokKind -> Bool
/// ```
pub fn is_name_kind_f(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KName(_) => true,
        _ => false,
    }
}

/// ```prism
/// IsTraitKind: fn TokKind -> Bool
/// ```
pub fn is_trait_kind_f(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KTrait(_) => true,
        _ => false,
    }
}

/// ```prism
/// ParseBound: unbounded fn Ps -> ((Bound, Ps))
/// ```
pub fn parse_bound_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::decls::Bound, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p_p0);
    let (var_p3, p1_p4) = crate::syntax::parser::parse_ident_f(p_p0);
    let (first_p5, p2_p6) = crate::syntax::parser::parse_trait_ref_f(&crate::syntax::parser::expect_colon_f(&p1_p4));
    let r_p2 = {
        let mut this: (Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps) = (Array::from(vec![first_p5.clone()]), p2_p6.clone());
        let mut traits_p7: Array<crate::syntax::TraitRef> = Array::from(vec![first_p5.clone()]);
        let mut q_p8: crate::syntax::parser::Ps = p2_p6.clone();
        while (crate::syntax::parser::at_comma_f(&q_p8) && is_trait_kind_f(&crate::syntax::parser::kind_at_f(&q_p8, &Nat::from(1u32)))) && !q_p8.bad_p {
            let (t_p9, q2_pa) = crate::syntax::parser::parse_trait_ref_f(&crate::syntax::parser::adv_f(&q_p8));
            traits_p7 = crate::prelude::push(&traits_p7, &t_p9);
            q_p8 = q2_pa.clone();
        }
        this = (traits_p7.clone(), q_p8.clone());
        this
    };
    let (traits_pb, q_pc) = r_p2.clone();
    (crate::syntax::decls::Bound { var_p: var_p3.clone(), traits_p: traits_pb.clone(), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&q_pc)) }, q_pc.clone())
}

/// The step machine of `ParseBound`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseBound: unbounded fn Ps -> ((Bound, Ps))
/// ```
pub struct ParseBound {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::decls::Bound, crate::syntax::parser::Ps)> for ParseBound {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::decls::Bound, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here_f(p_p0);
        let (var_p3, p1_p4) = crate::syntax::parser::parse_ident_f(p_p0);
        let (first_p5, p2_p6) = crate::syntax::parser::parse_trait_ref_f(&crate::syntax::parser::expect_colon_f(&p1_p4));
        let mut this: (Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps) = (Array::from(vec![first_p5.clone()]), p2_p6.clone());
        let mut traits_p7: Array<crate::syntax::TraitRef> = Array::from(vec![first_p5.clone()]);
        let mut q_p8: crate::syntax::parser::Ps = p2_p6.clone();
        let start_p1z = start_p1.clone();
        let var_p3z = var_p3.clone();
        crate::prelude::call_then(crate::prelude::loop_job((this, q_p8, traits_p7), move |(mut this, mut q_p8, mut traits_p7): ((Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps), crate::syntax::parser::Ps, Array<crate::syntax::TraitRef>)| if (crate::syntax::parser::at_comma_f(&q_p8) && is_trait_kind_f(&crate::syntax::parser::kind_at_f(&q_p8, &Nat::from(1u32)))) && !q_p8.bad_p {
            {
                let (t_p9, q2_pa) = crate::syntax::parser::parse_trait_ref_f(&crate::syntax::parser::adv_f(&q_p8));
                traits_p7 = crate::prelude::push(&traits_p7, &t_p9);
                q_p8 = q2_pa.clone();
                Ok((this, q_p8, traits_p7))
            }
        } else {
            Err((this, q_p8, traits_p7))
        }), move |(mut this, mut q_p8, mut traits_p7): ((Array<crate::syntax::TraitRef>, crate::syntax::parser::Ps), crate::syntax::parser::Ps, Array<crate::syntax::TraitRef>)| {
            this = (traits_p7.clone(), q_p8.clone());
            let r_p2 = this;
            let (traits_pb, q_pc) = r_p2.clone();
            prism_rtl::Turn::Finished((crate::syntax::decls::Bound { var_p: var_p3z.clone(), traits_p: traits_pb.clone(), span_p: crate::syntax::parser::to_f(&start_p1z, &crate::syntax::parser::prev_f(&q_pc)) }, q_pc.clone()))
        })
    }
}

/// `Start ParseBound, x`: what the function value is when passed to `@Run`.
pub fn start_parse_bound_f(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::decls::Bound, crate::syntax::parser::Ps)>> {
    Rc::new(ParseBound { p_p0 })
}

/// ```prism
/// ParseRow: unbounded fn Ps -> ((Row, Ps))
/// ```
pub fn parse_row_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Row_, crate::syntax::parser::Ps) {
    let start_p1 = crate::syntax::parser::here_f(p_p0);
    let (first_p3, p1_p4) = parse_row_term_f(p_p0);
    let r_p2 = {
        let mut this: (Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps) = (Array::from(vec![first_p3.clone()]), p1_p4.clone());
        let mut terms_p5: Array<crate::syntax::RowTerm> = Array::from(vec![first_p3.clone()]);
        let mut q_p6: crate::syntax::parser::Ps = p1_p4.clone();
        while (&crate::syntax::parser::kind_f(&q_p6) == &crate::syntax::lexer::TokKind::KBar) && !q_p6.bad_p {
            let (t_p7, q2_p8) = parse_row_term_f(&crate::syntax::parser::adv_f(&q_p6));
            terms_p5 = crate::prelude::push(&terms_p5, &t_p7);
            q_p6 = q2_p8.clone();
        }
        this = (terms_p5.clone(), q_p6.clone());
        this
    };
    let (terms_p9, q_pa) = r_p2.clone();
    (crate::syntax::Row_ { terms_p: terms_p9.clone(), span_p: crate::syntax::parser::to_f(&start_p1, &crate::syntax::parser::prev_f(&q_pa)) }, q_pa.clone())
}

/// The step machine of `ParseRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseRow: unbounded fn Ps -> ((Row, Ps))
/// ```
pub struct ParseRow {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Row_, crate::syntax::parser::Ps)> for ParseRow {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Row_, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let start_p1 = crate::syntax::parser::here_f(p_p0);
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(start_parse_row_term_f(p_p0x.clone()), move |parse_row_term_f_9352: (crate::syntax::RowTerm, crate::syntax::parser::Ps)| {
            let (first_p3, p1_p4) = parse_row_term_f_9352;
            let mut this: (Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps) = (Array::from(vec![first_p3.clone()]), p1_p4.clone());
            let mut terms_p5: Array<crate::syntax::RowTerm> = Array::from(vec![first_p3.clone()]);
            let mut q_p6: crate::syntax::parser::Ps = p1_p4.clone();
            let start_p1z = start_p1.clone();
            crate::prelude::call_then(crate::prelude::loop_job((this, q_p6, terms_p5), move |(mut this, mut q_p6, mut terms_p5): ((Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps), crate::syntax::parser::Ps, Array<crate::syntax::RowTerm>)| if (&crate::syntax::parser::kind_f(&q_p6) == &crate::syntax::lexer::TokKind::KBar) && !q_p6.bad_p {
                {
                    let (t_p7, q2_p8) = parse_row_term_f(&crate::syntax::parser::adv_f(&q_p6));
                    terms_p5 = crate::prelude::push(&terms_p5, &t_p7);
                    q_p6 = q2_p8.clone();
                    Ok((this, q_p6, terms_p5))
                }
            } else {
                Err((this, q_p6, terms_p5))
            }), move |(mut this, mut q_p6, mut terms_p5): ((Array<crate::syntax::RowTerm>, crate::syntax::parser::Ps), crate::syntax::parser::Ps, Array<crate::syntax::RowTerm>)| {
                this = (terms_p5.clone(), q_p6.clone());
                let r_p2 = this;
                let (terms_p9, q_pa) = r_p2.clone();
                prism_rtl::Turn::Finished((crate::syntax::Row_ { terms_p: terms_p9.clone(), span_p: crate::syntax::parser::to_f(&start_p1z, &crate::syntax::parser::prev_f(&q_pa)) }, q_pa.clone()))
            })
        })
    }
}

/// `Start ParseRow, x`: what the function value is when passed to `@Run`.
pub fn start_parse_row_f(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Row_, crate::syntax::parser::Ps)>> {
    Rc::new(ParseRow { p_p0 })
}

/// ```prism
/// ParseRowTerm: unbounded fn Ps -> ((RowTerm, Ps))
/// ```
pub fn parse_row_term_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::RowTerm, crate::syntax::parser::Ps) {
    match crate::syntax::parser::kind_f(p_p0) {
        crate::syntax::lexer::TokKind::KFamily(path_p1) => (crate::syntax::RowTerm::RFamily(crate::syntax::QualName { path_p: path_p1.clone(), span_p: crate::syntax::parser::here_f(p_p0) }), crate::syntax::parser::adv_f(p_p0)),
        crate::syntax::lexer::TokKind::KName(n_p2) if (is_plain_lower_one_f(&crate::syntax::lexer::TokKind::KName(n_p2.clone())) && !type_atom_after_name_f(p_p0)) => (crate::syntax::RowTerm::RVar(crate::syntax::Ident { name_p: crate::prelude::or(&crate::prelude::index(&n_p2.path_p, &Nat::from(0u32)), &Text::lit("")), span_p: crate::syntax::parser::here_f(p_p0) }), crate::syntax::parser::adv_f(p_p0)),
        _ => {
            let (t_p3, q_p4) = parse_map_type_f(p_p0);
            (crate::syntax::RowTerm::RType(t_p3.clone()), q_p4.clone())
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ParseRowTerm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseRowTerm: unbounded fn Ps -> ((RowTerm, Ps))
/// ```
pub struct ParseRowTerm {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::RowTerm, crate::syntax::parser::Ps)> for ParseRowTerm {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::RowTerm, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        match crate::syntax::parser::kind_f(p_p0) {
            crate::syntax::lexer::TokKind::KFamily(path_p1) => prism_rtl::Turn::Finished((crate::syntax::RowTerm::RFamily(crate::syntax::QualName { path_p: path_p1.clone(), span_p: crate::syntax::parser::here_f(p_p0) }), crate::syntax::parser::adv_f(p_p0))),
            crate::syntax::lexer::TokKind::KName(n_p2) if (is_plain_lower_one_f(&crate::syntax::lexer::TokKind::KName(n_p2.clone())) && !type_atom_after_name_f(p_p0)) => prism_rtl::Turn::Finished((crate::syntax::RowTerm::RVar(crate::syntax::Ident { name_p: crate::prelude::or(&crate::prelude::index(&n_p2.path_p, &Nat::from(0u32)), &Text::lit("")), span_p: crate::syntax::parser::here_f(p_p0) }), crate::syntax::parser::adv_f(p_p0))),
            _ => {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(start_parse_map_type_f(p_p0x.clone()), move |parse_map_type_f_10063: (crate::syntax::Type, crate::syntax::parser::Ps)| {
                    let (t_p3, q_p4) = parse_map_type_f_10063;
                    prism_rtl::Turn::Finished((crate::syntax::RowTerm::RType(t_p3.clone()), q_p4.clone()))
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ParseRowTerm, x`: what the function value is when passed to `@Run`.
pub fn start_parse_row_term_f(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::RowTerm, crate::syntax::parser::Ps)>> {
    Rc::new(ParseRowTerm { p_p0 })
}

/// ```prism
/// TypeAtomAfterName: fn Ps -> Bool
/// ```
pub fn type_atom_after_name_f(p_p0: &crate::syntax::parser::Ps) -> bool {
    match crate::syntax::parser::kind_at_f(p_p0, &Nat::from(1u32)) {
        crate::syntax::lexer::TokKind::KName(_) => true,
        crate::syntax::lexer::TokKind::KOpen(_, _) => true,
        crate::syntax::lexer::TokKind::KFamily(_) => true,
        _ => false,
    }
}

/// ```prism
/// ParsePattern: unbounded fn Ps, Bool -> ((Pattern, Ps))
/// ```
pub fn parse_pattern_f(p_p0: &crate::syntax::parser::Ps, commas0_p1: &bool) -> (crate::syntax::Pattern_, crate::syntax::parser::Ps) {
    let commas_p2 = *commas0_p1 && !p_p0.step_mode_p;
    let start_p3 = crate::syntax::parser::here_f(p_p0);
    match crate::syntax::parser::kind_f(p_p0) {
        crate::syntax::lexer::TokKind::KFree(s_p4) if ((&s_p4 == &Text::lit("?")) || (&s_p4 == &Text::lit("~"))) => {
            let (inner_p5, q_p6) = parse_pattern_f(&crate::syntax::parser::adv_f(p_p0), &commas_p2);
            (crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PSigil(s_p4.clone(), Rc::new(inner_p5.clone()))), span_p: crate::syntax::parser::to_f(&start_p3, &inner_p5.span_p) }, q_p6.clone())
        },
        crate::syntax::lexer::TokKind::KFree(s_p7) => (crate::syntax::parser::decls::no_pattern_p(), crate::syntax::parser::error_at_f(p_p0, &start_p3, &Text::from(format!("a free `{}` is not a pattern: only `? p` and `~ p` take a value apart", &s_p7)))),
        crate::syntax::lexer::TokKind::KName(n_p8) => name_pattern_f(p_p0, &n_p8, &commas_p2),
        crate::syntax::lexer::TokKind::KKw(m10847_3_0, _) if (&m10847_3_0 == &Text::lit("ignore")) => (crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PIgnore), span_p: start_p3.clone() }, crate::syntax::parser::adv_f(p_p0)),
        crate::syntax::lexer::TokKind::KKw(m10847_4_0, _) if (&m10847_4_0 == &Text::lit("unit")) => (crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PUnit), span_p: start_p3.clone() }, crate::syntax::parser::adv_f(p_p0)),
        crate::syntax::lexer::TokKind::KKw(m10847_5_0, _) if (&m10847_5_0 == &Text::lit("nil")) => (crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PNil), span_p: start_p3.clone() }, crate::syntax::parser::adv_f(p_p0)),
        crate::syntax::lexer::TokKind::KInt(_, _) => literal_pattern_f(p_p0),
        crate::syntax::lexer::TokKind::KFloat(_, _) => literal_pattern_f(p_p0),
        crate::syntax::lexer::TokKind::KDuration(_, _, _) => literal_pattern_f(p_p0),
        crate::syntax::lexer::TokKind::KChar(_, _) => literal_pattern_f(p_p0),
        crate::syntax::lexer::TokKind::KText(_, _) => literal_pattern_f(p_p0),
        crate::syntax::lexer::TokKind::KRegex(_, _) => (crate::syntax::parser::decls::no_pattern_p(), crate::syntax::parser::error_at_f(p_p0, &start_p3, &Text::lit("a regular expression is not a pattern: match a text with `?Match` or `?Find`"))),
        crate::syntax::lexer::TokKind::KOp(m10847_12_0, true) if (&m10847_12_0 == &Text::lit("-")) => {
            let p1_p9 = crate::syntax::parser::adv_f(p_p0);
            if is_number_kind_f(&crate::syntax::parser::kind_f(&p1_p9)) {
                {
                    let (lit_pa, q_pb) = crate::syntax::parser::expr::parse_literal_f(&p1_p9);
                    (crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PNeg(lit_pa.clone())), span_p: crate::syntax::parser::to_f(&start_p3, &lit_pa.span_p) }, q_pb.clone())
                }
            } else {
                (crate::syntax::parser::decls::no_pattern_p(), crate::syntax::parser::error_here_f(&p1_p9, &Text::lit("a `-` in a pattern is the sign of a number literal")))
            }
        },
        crate::syntax::lexer::TokKind::KOpen(m10847_13_0, _) if (&m10847_13_0 == &Text::lit("(")) => if crate::syntax::parser::at_double_open_f(p_p0, &Text::lit("(")) {
            {
                let (elems_pe, p1_pf) = crate::syntax::parser::commas_f(&crate::syntax::parser::open_double_f(p_p0), &(Rc::new(move |p0: crate::syntax::parser::Ps| crate::prelude::entered(crate::prelude::once_job(move || {
                    let q_pd = p0;
                    prism_rtl::Turn::More(Rc::new(ParsePattern { p_p0: q_pd.clone(), commas0_p1: false }))
                }))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>>>));
                let p2_pc = crate::syntax::parser::close_double_f(&p1_pf, &Text::lit("("));
                (crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PTuple(elems_pe.clone())), span_p: crate::syntax::parser::to_f(&start_p3, &crate::syntax::parser::prev_f(&p2_pc)) }, p2_pc.clone())
            }
        } else {
            {
                let (inner_pi, p1_pj) = crate::syntax::parser::bracketed_f(&crate::syntax::parser::adv_f(p_p0), &(Rc::new(move |p0: crate::syntax::parser::Ps| crate::prelude::entered(crate::prelude::once_job(move || {
                    let q_ph = p0;
                    prism_rtl::Turn::More(Rc::new(ParsePattern { p_p0: q_ph.clone(), commas0_p1: true }))
                }))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>>>));
                let p2_pg = crate::syntax::parser::expect_close_f(&p1_pj, &Text::lit("("));
                (crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PGroup(Rc::new(inner_pi.clone()))), span_p: crate::syntax::parser::to_f(&start_p3, &crate::syntax::parser::prev_f(&p2_pg)) }, p2_pg.clone())
            }
        },
        crate::syntax::lexer::TokKind::KOpen(m10847_14_0, _) if (&m10847_14_0 == &Text::lit("[")) && crate::syntax::parser::at_double_open_f(p_p0, &Text::lit("[")) => {
            let p1_pk = crate::syntax::parser::open_double_f(p_p0);
            let (elems_pn, p2_po) = if crate::syntax::parser::at_close_f(&p1_pk, &Text::lit("[")) {
                (Array::new(), p1_pk.clone())
            } else {
                crate::syntax::parser::commas_f(&p1_pk, &(Rc::new(move |p0: crate::syntax::parser::Ps| crate::prelude::entered(crate::prelude::once_job(move || {
                    let q_pm = p0;
                    prism_rtl::Turn::More(Rc::new(ParsePattern { p_p0: q_pm.clone(), commas0_p1: false }))
                }))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>>>))
            };
            let p3_pl = crate::syntax::parser::close_double_f(&p2_po, &Text::lit("["));
            (crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PArray(elems_pn.clone())), span_p: crate::syntax::parser::to_f(&start_p3, &crate::syntax::parser::prev_f(&p3_pl)) }, p3_pl.clone())
        },
        crate::syntax::lexer::TokKind::KFamily(path_pp) => (crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PFamily(crate::syntax::QualName { path_p: path_pp.clone(), span_p: start_p3.clone() })), span_p: start_p3.clone() }, crate::syntax::parser::adv_f(p_p0)),
        crate::syntax::lexer::TokKind::KAbsent => (crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PIgnore), span_p: start_p3.clone() }, crate::syntax::parser::out_of_scope_f(&crate::syntax::parser::adv_f(p_p0), &start_p3, &Text::lit("sparse tuples"), &Text::lit("an absent component `-` is a sparse tuple\'s, out of this compiler"))),
        _ => (crate::syntax::parser::decls::no_pattern_p(), crate::syntax::parser::error_here_f(p_p0, &Text::lit("expected a pattern"))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ParsePattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParsePattern: unbounded fn Ps, Bool -> ((Pattern, Ps))
/// ```
pub struct ParsePattern {
    pub p_p0: crate::syntax::parser::Ps,
    pub commas0_p1: bool,
}

impl prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)> for ParsePattern {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Pattern_, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let commas0_p1 = &self.commas0_p1;
        let commas_p2 = *commas0_p1 && !p_p0.step_mode_p;
        let start_p3 = crate::syntax::parser::here_f(p_p0);
        match crate::syntax::parser::kind_f(p_p0) {
            crate::syntax::lexer::TokKind::KFree(s_p4) if ((&s_p4 == &Text::lit("?")) || (&s_p4 == &Text::lit("~"))) => {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(start_parse_pattern_f(crate::syntax::parser::adv_f(&p_p0x), commas_p2), move |parse_pattern_f_10933: (crate::syntax::Pattern_, crate::syntax::parser::Ps)| {
                    let (inner_p5, q_p6) = parse_pattern_f_10933;
                    prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PSigil(s_p4.clone(), Rc::new(inner_p5.clone()))), span_p: crate::syntax::parser::to_f(&start_p3, &inner_p5.span_p) }, q_p6.clone()))
                })
            },
            crate::syntax::lexer::TokKind::KFree(s_p7) => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_pattern_p(), crate::syntax::parser::error_at_f(p_p0, &start_p3, &Text::from(format!("a free `{}` is not a pattern: only `? p` and `~ p` take a value apart", &s_p7))))),
            crate::syntax::lexer::TokKind::KName(n_p8) => prism_rtl::Turn::More(Rc::new(NamePattern { p0_p0: p_p0.clone(), n_p1: n_p8.clone(), commas_p2 })),
            crate::syntax::lexer::TokKind::KKw(m10847_3_0, _) if (&m10847_3_0 == &Text::lit("ignore")) => prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PIgnore), span_p: start_p3.clone() }, crate::syntax::parser::adv_f(p_p0))),
            crate::syntax::lexer::TokKind::KKw(m10847_4_0, _) if (&m10847_4_0 == &Text::lit("unit")) => prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PUnit), span_p: start_p3.clone() }, crate::syntax::parser::adv_f(p_p0))),
            crate::syntax::lexer::TokKind::KKw(m10847_5_0, _) if (&m10847_5_0 == &Text::lit("nil")) => prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PNil), span_p: start_p3.clone() }, crate::syntax::parser::adv_f(p_p0))),
            crate::syntax::lexer::TokKind::KInt(_, _) => prism_rtl::Turn::More(Rc::new(LiteralPattern { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KFloat(_, _) => prism_rtl::Turn::More(Rc::new(LiteralPattern { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KDuration(_, _, _) => prism_rtl::Turn::More(Rc::new(LiteralPattern { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KChar(_, _) => prism_rtl::Turn::More(Rc::new(LiteralPattern { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KText(_, _) => prism_rtl::Turn::More(Rc::new(LiteralPattern { p_p0: p_p0.clone() })),
            crate::syntax::lexer::TokKind::KRegex(_, _) => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_pattern_p(), crate::syntax::parser::error_at_f(p_p0, &start_p3, &Text::lit("a regular expression is not a pattern: match a text with `?Match` or `?Find`")))),
            crate::syntax::lexer::TokKind::KOp(m10847_12_0, true) if (&m10847_12_0 == &Text::lit("-")) => {
                let p1_p9 = crate::syntax::parser::adv_f(p_p0);
                if is_number_kind_f(&crate::syntax::parser::kind_f(&p1_p9)) {
                    crate::prelude::call_then(crate::syntax::parser::expr::start_parse_literal_f(p1_p9.clone()), move |parse_literal_f_11989: (crate::syntax::Literal, crate::syntax::parser::Ps)| {
                        let (lit_pa, q_pb) = parse_literal_f_11989;
                        prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PNeg(lit_pa.clone())), span_p: crate::syntax::parser::to_f(&start_p3, &lit_pa.span_p) }, q_pb.clone()))
                    })
                } else {
                    prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_pattern_p(), crate::syntax::parser::error_here_f(&p1_p9, &Text::lit("a `-` in a pattern is the sign of a number literal"))))
                }
            },
            crate::syntax::lexer::TokKind::KOpen(m10847_13_0, _) if (&m10847_13_0 == &Text::lit("(")) => if crate::syntax::parser::at_double_open_f(p_p0, &Text::lit("(")) {
                {
                    let p_p0x = p_p0.clone();
                    crate::prelude::call_then(crate::syntax::parser::start_commas_f(crate::syntax::parser::open_double_f(&p_p0x), Rc::new(move |p0: crate::syntax::parser::Ps| crate::prelude::entered(crate::prelude::once_job(move || {
                        let q_pd = p0;
                        prism_rtl::Turn::More(Rc::new(ParsePattern { p_p0: q_pd.clone(), commas0_p1: false }))
                    }))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>>>), move |commas_f_12281: (Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps)| {
                        let (elems_pe, p1_pf) = commas_f_12281;
                        let p2_pc = crate::syntax::parser::close_double_f(&p1_pf, &Text::lit("("));
                        prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PTuple(elems_pe.clone())), span_p: crate::syntax::parser::to_f(&start_p3, &crate::syntax::parser::prev_f(&p2_pc)) }, p2_pc.clone()))
                    })
                }
            } else {
                {
                    let p_p0x = p_p0.clone();
                    crate::prelude::call_then(crate::syntax::parser::start_bracketed_f(crate::syntax::parser::adv_f(&p_p0x), Rc::new(move |p0: crate::syntax::parser::Ps| crate::prelude::entered(crate::prelude::once_job(move || {
                        let q_ph = p0;
                        prism_rtl::Turn::More(Rc::new(ParsePattern { p_p0: q_ph.clone(), commas0_p1: true }))
                    }))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>>>), move |bracketed_f_12668: (crate::syntax::Pattern_, crate::syntax::parser::Ps)| {
                        let (inner_pi, p1_pj) = bracketed_f_12668;
                        let p2_pg = crate::syntax::parser::expect_close_f(&p1_pj, &Text::lit("("));
                        prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PGroup(Rc::new(inner_pi.clone()))), span_p: crate::syntax::parser::to_f(&start_p3, &crate::syntax::parser::prev_f(&p2_pg)) }, p2_pg.clone()))
                    })
                }
            },
            crate::syntax::lexer::TokKind::KOpen(m10847_14_0, _) if (&m10847_14_0 == &Text::lit("[")) && crate::syntax::parser::at_double_open_f(p_p0, &Text::lit("[")) => {
                let p1_pk = crate::syntax::parser::open_double_f(p_p0);
                let (elems_pn, p2_po) = if crate::syntax::parser::at_close_f(&p1_pk, &Text::lit("[")) {
                    (Array::new(), p1_pk.clone())
                } else {
                    crate::syntax::parser::commas_f(&p1_pk, &(Rc::new(move |p0: crate::syntax::parser::Ps| crate::prelude::entered(crate::prelude::once_job(move || {
                        let q_pm = p0;
                        prism_rtl::Turn::More(Rc::new(ParsePattern { p_p0: q_pm.clone(), commas0_p1: false }))
                    }))) as Rc<dyn Fn(crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>>>))
                };
                let p3_pl = crate::syntax::parser::close_double_f(&p2_po, &Text::lit("["));
                prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PArray(elems_pn.clone())), span_p: crate::syntax::parser::to_f(&start_p3, &crate::syntax::parser::prev_f(&p3_pl)) }, p3_pl.clone()))
            },
            crate::syntax::lexer::TokKind::KFamily(path_pp) => prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PFamily(crate::syntax::QualName { path_p: path_pp.clone(), span_p: start_p3.clone() })), span_p: start_p3.clone() }, crate::syntax::parser::adv_f(p_p0))),
            crate::syntax::lexer::TokKind::KAbsent => prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PIgnore), span_p: start_p3.clone() }, crate::syntax::parser::out_of_scope_f(&crate::syntax::parser::adv_f(p_p0), &start_p3, &Text::lit("sparse tuples"), &Text::lit("an absent component `-` is a sparse tuple\'s, out of this compiler")))),
            _ => prism_rtl::Turn::Finished((crate::syntax::parser::decls::no_pattern_p(), crate::syntax::parser::error_here_f(p_p0, &Text::lit("expected a pattern")))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start ParsePattern, x`: what the function value is when passed to `@Run`.
pub fn start_parse_pattern_f(p_p0: crate::syntax::parser::Ps, commas0_p1: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>> {
    Rc::new(ParsePattern { p_p0, commas0_p1 })
}

/// ```prism
/// IsNumberKind: fn TokKind -> Bool
/// ```
pub fn is_number_kind_f(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KInt(_, _) => true,
        crate::syntax::lexer::TokKind::KFloat(_, _) => true,
        crate::syntax::lexer::TokKind::KDuration(_, _, _) => true,
        _ => false,
    }
}

/// ```prism
/// LiteralPattern: unbounded fn Ps -> ((Pattern, Ps))
/// ```
pub fn literal_pattern_f(p_p0: &crate::syntax::parser::Ps) -> (crate::syntax::Pattern_, crate::syntax::parser::Ps) {
    let (lit_p1, q_p2) = crate::syntax::parser::expr::parse_literal_f(p_p0);
    (crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PLit(lit_p1.clone())), span_p: lit_p1.span_p.clone() }, q_p2.clone())
}

/// The step machine of `LiteralPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LiteralPattern: unbounded fn Ps -> ((Pattern, Ps))
/// ```
pub struct LiteralPattern {
    pub p_p0: crate::syntax::parser::Ps,
}

impl prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)> for LiteralPattern {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Pattern_, crate::syntax::parser::Ps)> {
        let p_p0 = &self.p_p0;
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(crate::syntax::parser::expr::start_parse_literal_f(p_p0x.clone()), move |parse_literal_f_13802: (crate::syntax::Literal, crate::syntax::parser::Ps)| {
            let (lit_p1, q_p2) = parse_literal_f_13802;
            prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PLit(lit_p1.clone())), span_p: lit_p1.span_p.clone() }, q_p2.clone()))
        })
    }
}

/// `Start LiteralPattern, x`: what the function value is when passed to `@Run`.
pub fn start_literal_pattern_f(p_p0: crate::syntax::parser::Ps) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>> {
    Rc::new(LiteralPattern { p_p0 })
}

/// ```prism
/// NamePattern: unbounded fn Ps, NameTok, Bool -> ((Pattern, Ps))
/// ```
pub fn name_pattern_f(p0_p0: &crate::syntax::parser::Ps, n_p1: &crate::syntax::lexer::NameTok, commas_p2: &bool) -> (crate::syntax::Pattern_, crate::syntax::parser::Ps) {
    let start_p3 = crate::syntax::parser::here_f(p0_p0);
    let name_p4 = crate::syntax::SName { sigils_p: n_p1.sigils_p.clone(), path_p: n_p1.path_p.clone(), span_p: start_p3.clone() };
    let p_p5 = crate::syntax::parser::adv_f(p0_p0);
    if (crate::syntax::parser::is_callee_f(&name_p4) && crate::syntax::parser::at_single_open_f(&p_p5, &Text::lit("("))) && crate::syntax::parser::tk_f(&p_p5).touches_p {
        parse_record_pattern_f(&p_p5, &name_p4)
    } else {
        if crate::syntax::parser::is_callee_f(&name_p4) && pat_arg_starts_here_f(&p_p5) {
            {
                let (first_p7, p1_p8) = parse_pattern_f(&p_p5, &false);
                let r_p6 = {
                    let mut this: (Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps) = (Array::from(vec![first_p7.clone()]), p1_p8.clone());
                    let mut args_p9: Array<crate::syntax::Pattern_> = Array::from(vec![first_p7.clone()]);
                    let mut q_pa: crate::syntax::parser::Ps = p1_p8.clone();
                    while (*commas_p2 && crate::syntax::parser::at_comma_f(&q_pa)) && !q_pa.bad_p {
                        let (a_pb, q2_pc) = parse_pattern_f(&crate::syntax::parser::adv_f(&q_pa), &false);
                        args_p9 = crate::prelude::push(&args_p9, &a_pb);
                        q_pa = q2_pc.clone();
                    }
                    this = (args_p9.clone(), q_pa.clone());
                    this
                };
                let (args_pd, q_pe) = r_p6.clone();
                (crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PCtor(name_p4.clone(), args_pd.clone())), span_p: crate::syntax::parser::to_f(&start_p3, &crate::syntax::parser::prev_f(&q_pe)) }, q_pe.clone())
            }
        } else {
            (crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PName(name_p4.clone())), span_p: start_p3.clone() }, p_p5.clone())
        }
    }
}

/// The step machine of `NamePattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamePattern: unbounded fn Ps, NameTok, Bool -> ((Pattern, Ps))
/// ```
pub struct NamePattern {
    pub p0_p0: crate::syntax::parser::Ps,
    pub n_p1: crate::syntax::lexer::NameTok,
    pub commas_p2: bool,
}

impl prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)> for NamePattern {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Pattern_, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let n_p1 = &self.n_p1;
        let commas_p2 = &self.commas_p2;
        let start_p3 = crate::syntax::parser::here_f(p0_p0);
        let name_p4 = crate::syntax::SName { sigils_p: n_p1.sigils_p.clone(), path_p: n_p1.path_p.clone(), span_p: start_p3.clone() };
        let p_p5 = crate::syntax::parser::adv_f(p0_p0);
        if (crate::syntax::parser::is_callee_f(&name_p4) && crate::syntax::parser::at_single_open_f(&p_p5, &Text::lit("("))) && crate::syntax::parser::tk_f(&p_p5).touches_p {
            prism_rtl::Turn::More(Rc::new(ParseRecordPattern { p0_p0: p_p5.clone(), name_p1: name_p4.clone() }))
        } else {
            if crate::syntax::parser::is_callee_f(&name_p4) && pat_arg_starts_here_f(&p_p5) {
                {
                    let commas_p2x = *commas_p2;
                    crate::prelude::call_then(start_parse_pattern_f(p_p5.clone(), false), move |parse_pattern_f_14247: (crate::syntax::Pattern_, crate::syntax::parser::Ps)| {
                        let (first_p7, p1_p8) = parse_pattern_f_14247;
                        let mut this: (Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps) = (Array::from(vec![first_p7.clone()]), p1_p8.clone());
                        let mut args_p9: Array<crate::syntax::Pattern_> = Array::from(vec![first_p7.clone()]);
                        let mut q_pa: crate::syntax::parser::Ps = p1_p8.clone();
                        let name_p4z = name_p4.clone();
                        let start_p3z = start_p3.clone();
                        crate::prelude::call_then(crate::prelude::loop_job((this, args_p9, q_pa), {
                            let commas_p2xx = commas_p2x;
                            move |(mut this, mut args_p9, mut q_pa): ((Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps), Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps)| if (commas_p2xx && crate::syntax::parser::at_comma_f(&q_pa)) && !q_pa.bad_p {
                                {
                                    let (a_pb, q2_pc) = parse_pattern_f(&crate::syntax::parser::adv_f(&q_pa), &false);
                                    args_p9 = crate::prelude::push(&args_p9, &a_pb);
                                    q_pa = q2_pc.clone();
                                    Ok((this, args_p9, q_pa))
                                }
                            } else {
                                Err((this, args_p9, q_pa))
                            }
                        }), move |(mut this, mut args_p9, mut q_pa): ((Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps), Array<crate::syntax::Pattern_>, crate::syntax::parser::Ps)| {
                            this = (args_p9.clone(), q_pa.clone());
                            let r_p6 = this;
                            let (args_pd, q_pe) = r_p6.clone();
                            prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PCtor(name_p4z.clone(), args_pd.clone())), span_p: crate::syntax::parser::to_f(&start_p3z, &crate::syntax::parser::prev_f(&q_pe)) }, q_pe.clone()))
                        })
                    })
                }
            } else {
                prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PName(name_p4.clone())), span_p: start_p3.clone() }, p_p5.clone()))
            }
        }
    }
}

/// `Start NamePattern, x`: what the function value is when passed to `@Run`.
pub fn start_name_pattern_f(p0_p0: crate::syntax::parser::Ps, n_p1: crate::syntax::lexer::NameTok, commas_p2: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>> {
    Rc::new(NamePattern { p0_p0, n_p1, commas_p2 })
}

/// ```prism
/// PatArgStartsHere: fn Ps -> Bool
/// ```
pub fn pat_arg_starts_here_f(p_p0: &crate::syntax::parser::Ps) -> bool {
    match crate::syntax::parser::kind_f(p_p0) {
        crate::syntax::lexer::TokKind::KName(_) => true,
        crate::syntax::lexer::TokKind::KInt(_, _) => true,
        crate::syntax::lexer::TokKind::KFloat(_, _) => true,
        crate::syntax::lexer::TokKind::KDuration(_, _, _) => true,
        crate::syntax::lexer::TokKind::KChar(_, _) => true,
        crate::syntax::lexer::TokKind::KText(_, _) => true,
        crate::syntax::lexer::TokKind::KFamily(_) => true,
        crate::syntax::lexer::TokKind::KFree(s_p1) => (&s_p1 == &Text::lit("?")) || (&s_p1 == &Text::lit("~")),
        crate::syntax::lexer::TokKind::KOpen(m14865_8_0, _) if (&m14865_8_0 == &Text::lit("(")) => !crate::syntax::parser::tk_f(p_p0).touches_p || crate::syntax::parser::at_double_open_f(p_p0, &Text::lit("(")),
        crate::syntax::lexer::TokKind::KOpen(m14865_9_0, _) if (&m14865_9_0 == &Text::lit("[")) => crate::syntax::parser::at_double_open_f(p_p0, &Text::lit("[")),
        crate::syntax::lexer::TokKind::KOp(m14865_10_0, true) if (&m14865_10_0 == &Text::lit("-")) => true,
        crate::syntax::lexer::TokKind::KKw(w_p2, _) => ((&w_p2 == &Text::lit("ignore")) || (&w_p2 == &Text::lit("unit"))) || (&w_p2 == &Text::lit("nil")),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ParseRecordPattern: unbounded fn Ps, SName -> ((Pattern, Ps))
/// ```
pub fn parse_record_pattern_f(p0_p0: &crate::syntax::parser::Ps, name_p1: &crate::syntax::SName) -> (crate::syntax::Pattern_, crate::syntax::parser::Ps) {
    let p_p2 = crate::syntax::parser::adv_f(p0_p0);
    let r_p3 = {
        let mut this: FieldsRead = FieldsRead { fields_p: Array::new(), rest_p: false, p_p: p_p2.clone(), going_p: !crate::syntax::parser::at_close_f(&p_p2, &Text::lit("(")) };
        while this.going_p && !this.p_p.bad_p {
            if &crate::syntax::parser::kind_f(&this.p_p) == &crate::syntax::lexer::TokKind::KDotDot {
                this.p_p = crate::syntax::parser::adv_f(&this.p_p);
                this.rest_p = true;
            } else {
                let fstart_p5 = crate::syntax::parser::here_f(&this.p_p);
                let (fname_o6, p1_p7) = crate::syntax::parser::expr::parse_arg_name_f(&this.p_p);
                let (pattern_p8, p2_p9) = parse_pattern_f(&p1_p7, &false);
                this.fields_p = crate::prelude::push(&this.fields_p, &crate::syntax::FieldPat { name_o: fname_o6.clone(), pattern_p: pattern_p8.clone(), span_p: crate::syntax::parser::to_f(&fstart_p5, &pattern_p8.span_p) });
                this.p_p = p2_p9.clone();
            }
            if crate::syntax::parser::at_comma_f(&this.p_p) {
                this.p_p = crate::syntax::parser::adv_f(&this.p_p);
            } else {
                this.going_p = false;
            }
        }
        this
    };
    let q_p4 = crate::syntax::parser::expect_close_f(&r_p3.p_p, &Text::lit("("));
    (crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PRecord(name_p1.clone(), r_p3.fields_p.clone(), r_p3.rest_p)), span_p: crate::syntax::parser::to_f(&name_p1.span_p, &crate::syntax::parser::prev_f(&q_p4)) }, q_p4.clone())
}

/// The step machine of `ParseRecordPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseRecordPattern: unbounded fn Ps, SName -> ((Pattern, Ps))
/// ```
pub struct ParseRecordPattern {
    pub p0_p0: crate::syntax::parser::Ps,
    pub name_p1: crate::syntax::SName,
}

impl prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)> for ParseRecordPattern {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::Pattern_, crate::syntax::parser::Ps)> {
        let p0_p0 = &self.p0_p0;
        let name_p1 = &self.name_p1;
        let p_p2 = crate::syntax::parser::adv_f(p0_p0);
        let mut this: FieldsRead = FieldsRead { fields_p: Array::new(), rest_p: false, p_p: p_p2.clone(), going_p: !crate::syntax::parser::at_close_f(&p_p2, &Text::lit("(")) };
        let name_p1z = name_p1.clone();
        let p_p2z = p_p2.clone();
        crate::prelude::call_then(crate::prelude::loop_job((this,), {
            let name_p1x = name_p1.clone();
            let p_p2x = p_p2.clone();
            move |(mut this,): (FieldsRead,)| if this.going_p && !this.p_p.bad_p {
                {
                    if &crate::syntax::parser::kind_f(&this.p_p) == &crate::syntax::lexer::TokKind::KDotDot {
                        this.p_p = crate::syntax::parser::adv_f(&this.p_p);
                        this.rest_p = true;
                    } else {
                        let fstart_p5 = crate::syntax::parser::here_f(&this.p_p);
                        let (fname_o6, p1_p7) = crate::syntax::parser::expr::parse_arg_name_f(&this.p_p);
                        let (pattern_p8, p2_p9) = parse_pattern_f(&p1_p7, &false);
                        this.fields_p = crate::prelude::push(&this.fields_p, &crate::syntax::FieldPat { name_o: fname_o6.clone(), pattern_p: pattern_p8.clone(), span_p: crate::syntax::parser::to_f(&fstart_p5, &pattern_p8.span_p) });
                        this.p_p = p2_p9.clone();
                    }
                    if crate::syntax::parser::at_comma_f(&this.p_p) {
                        this.p_p = crate::syntax::parser::adv_f(&this.p_p);
                    } else {
                        this.going_p = false;
                    }
                    Ok((this,))
                }
            } else {
                Err((this,))
            }
        }), move |(mut this,): (FieldsRead,)| {
            let r_p3 = this;
            let q_p4 = crate::syntax::parser::expect_close_f(&r_p3.p_p, &Text::lit("("));
            prism_rtl::Turn::Finished((crate::syntax::Pattern_ { kind_p: Rc::new(crate::syntax::PatternKind::PRecord(name_p1z.clone(), r_p3.fields_p.clone(), r_p3.rest_p)), span_p: crate::syntax::parser::to_f(&name_p1z.span_p, &crate::syntax::parser::prev_f(&q_p4)) }, q_p4.clone()))
        })
    }
}

/// `Start ParseRecordPattern, x`: what the function value is when passed to `@Run`.
pub fn start_parse_record_pattern_f(p0_p0: crate::syntax::parser::Ps, name_p1: crate::syntax::SName) -> Rc<dyn prism_rtl::Job<(crate::syntax::Pattern_, crate::syntax::parser::Ps)>> {
    Rc::new(ParseRecordPattern { p0_p0, name_p1 })
}
