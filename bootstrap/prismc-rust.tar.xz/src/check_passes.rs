//! The module `CheckPasses`, from `target/bootstrap/src/prismc/check-passes.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (docs/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
#[allow(unused_imports)]
use crate::{program, ast, check_blocks, check_env, check_errors, check_expr, check_types, cpp_prelude_template, cpp_templates, emit, emit_cpp, fs, lexer, lower, parser, prelude_template, process, rust_templates, sexp, typed};

/// `Ctor`:
///
/// ```prism
/// type Ctor = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Ctor {
    pub name: Text,
    pub arity: Nat,
    pub args: Array<check_types::Ty>,
    pub shown: Text,
}

impl Show for Ctor {
    fn show(&self, p: &mut Printer) {
        p.record("Ctor", &[("name", &self.name), ("arity", &self.arity), ("args", &self.args), ("shown", &self.shown)]);
    }
}

impl ToPod for Ctor {
    fn to_pod(&self) -> Pod {
        Pod::record("Ctor", vec![("name", self.name.to_pod()), ("arity", self.arity.to_pod()), ("args", self.args.to_pod()), ("shown", self.shown.to_pod())])
    }
}

impl FromPod for Ctor {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Ctor { name: FromPod::from_pod(field(p, "name")?)?, arity: FromPod::from_pod(field(p, "arity")?)?, args: FromPod::from_pod(field(p, "args")?)?, shown: FromPod::from_pod(field(p, "shown")?)? })
    }
}

/// `Kid`:
///
/// ```prism
/// type Kid = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Kid {
    KidExpr(ast::Expr, Map<Text, Rel>),
    KidStmts(Array<ast::Stmt>, Map<Text, Rel>),
}

impl Show for Kid {
    fn show(&self, p: &mut Printer) {
        match self {
            Kid::KidExpr(a0, a1) => p.choice("KidExpr", &[a0, a1]),
            Kid::KidStmts(a0, a1) => p.choice("KidStmts", &[a0, a1]),
        }
    }
}

impl ToPod for Kid {
    fn to_pod(&self) -> Pod {
        match self {
            Kid::KidExpr(a0, a1) => Pod::Choice("KidExpr".into(), vec![a0.to_pod(), a1.to_pod()]),
            Kid::KidStmts(a0, a1) => Pod::Choice("KidStmts".into(), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl FromPod for Kid {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "KidExpr" && a.len() == 2 => Ok(Kid::KidExpr(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "KidStmts" && a.len() == 2 => Ok(Kid::KidStmts(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            other => mismatch("a Kid", other),
        }
    }
}

/// `PCx`:
///
/// ```prism
/// type PCx = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct PCx {
    pub g: check_env::G,
    pub home: Text,
    pub lams: Map<Nat, ast::Expr>,
    pub base: Map<Text, Rel>,
}

impl Show for PCx {
    fn show(&self, p: &mut Printer) {
        p.record("PCx", &[("g", &self.g), ("home", &self.home), ("lams", &self.lams), ("base", &self.base)]);
    }
}

impl ToPod for PCx {
    fn to_pod(&self) -> Pod {
        Pod::record("PCx", vec![("g", self.g.to_pod()), ("home", self.home.to_pod()), ("lams", self.lams.to_pod()), ("base", self.base.to_pod())])
    }
}

impl FromPod for PCx {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(PCx { g: FromPod::from_pod(field(p, "g")?)?, home: FromPod::from_pod(field(p, "home")?)?, lams: FromPod::from_pod(field(p, "lams")?)?, base: FromPod::from_pod(field(p, "base")?)? })
    }
}

/// `Pat`:
///
/// ```prism
/// type Pat = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Pat {
    PtAny,
    PtCon(Text, Array<Pat>),
    PtLit(Text),
    PtFam(Text),
}

impl Show for Pat {
    fn show(&self, p: &mut Printer) {
        match self {
            Pat::PtAny => p.choice("PtAny", &[]),
            Pat::PtCon(a0, a1) => p.choice("PtCon", &[a0, a1]),
            Pat::PtLit(a0) => p.choice("PtLit", &[a0]),
            Pat::PtFam(a0) => p.choice("PtFam", &[a0]),
        }
    }
}

impl ToPod for Pat {
    fn to_pod(&self) -> Pod {
        match self {
            Pat::PtAny => Pod::Choice("PtAny".into(), vec![]),
            Pat::PtCon(a0, a1) => Pod::Choice("PtCon".into(), vec![a0.to_pod(), a1.to_pod()]),
            Pat::PtLit(a0) => Pod::Choice("PtLit".into(), vec![a0.to_pod()]),
            Pat::PtFam(a0) => Pod::Choice("PtFam".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for Pat {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "PtAny" && a.len() == 0 => Ok(Pat::PtAny),
            Pod::Choice(c, a) if &**c == "PtCon" && a.len() == 2 => Ok(Pat::PtCon(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "PtLit" && a.len() == 1 => Ok(Pat::PtLit(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PtFam" && a.len() == 1 => Ok(Pat::PtFam(FromPod::from_pod(&a[0])?)),
            other => mismatch("a Pat", other),
        }
    }
}

/// `Rel`:
///
/// ```prism
/// type Rel = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Rel {
    pub param: Nat,
    pub strict: bool,
}

impl Show for Rel {
    fn show(&self, p: &mut Printer) {
        p.record("Rel", &[("param", &self.param), ("strict", &self.strict)]);
    }
}

impl ToPod for Rel {
    fn to_pod(&self) -> Pod {
        Pod::record("Rel", vec![("param", self.param.to_pod()), ("strict", self.strict.to_pod())])
    }
}

impl FromPod for Rel {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Rel { param: FromPod::from_pod(field(p, "param")?)?, strict: FromPod::from_pod(field(p, "strict")?)? })
    }
}

/// `Report`:
///
/// ```prism
/// type Report = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Report_ {
    pub text: Text,
    pub errors: Nat,
    pub root_row: Text,
    pub typed: typed::TProgram,
}

impl Show for Report_ {
    fn show(&self, p: &mut Printer) {
        p.record("Report", &[("text", &self.text), ("errors", &self.errors), ("root_row", &self.root_row), ("typed", &self.typed)]);
    }
}

impl ToPod for Report_ {
    fn to_pod(&self) -> Pod {
        Pod::record("Report", vec![("text", self.text.to_pod()), ("errors", self.errors.to_pod()), ("root_row", self.root_row.to_pod()), ("typed", self.typed.to_pod())])
    }
}

impl FromPod for Report_ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Report_ { text: FromPod::from_pod(field(p, "text")?)?, errors: FromPod::from_pod(field(p, "errors")?)?, root_row: FromPod::from_pod(field(p, "root_row")?)?, typed: FromPod::from_pod(field(p, "typed")?)? })
    }
}

/// `Sc`:
///
/// ```prism
/// type Sc = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Sc {
    pub caller: Text,
    pub callee: Text,
    pub edges: Array<(Nat, Nat, bool)>,
    pub span: ast::Range,
    pub file: Nat,
    pub arg: Text,
}

impl Show for Sc {
    fn show(&self, p: &mut Printer) {
        p.record("Sc", &[("caller", &self.caller), ("callee", &self.callee), ("edges", &self.edges), ("span", &self.span), ("file", &self.file), ("arg", &self.arg)]);
    }
}

impl ToPod for Sc {
    fn to_pod(&self) -> Pod {
        Pod::record("Sc", vec![("caller", self.caller.to_pod()), ("callee", self.callee.to_pod()), ("edges", self.edges.to_pod()), ("span", self.span.to_pod()), ("file", self.file.to_pod()), ("arg", self.arg.to_pod())])
    }
}

impl FromPod for Sc {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Sc { caller: FromPod::from_pod(field(p, "caller")?)?, callee: FromPod::from_pod(field(p, "callee")?)?, edges: FromPod::from_pod(field(p, "edges")?)?, span: FromPod::from_pod(field(p, "span")?)?, file: FromPod::from_pod(field(p, "file")?)?, arg: FromPod::from_pod(field(p, "arg")?)? })
    }
}

/// `Shrink`:
///
/// ```prism
/// type Shrink = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Shrink {
    pub g: check_env::G,
    pub fns: Array<check_env::Def>,
    pub by_key: Map<Text, check_env::Def>,
    pub targets: Map<Text, Array<Text>>,
    pub impl_defs: Map<Text, Text>,
    pub choices: Map<Text, Array<Text>>,
    pub sums: Map<Text, Nat>,
    pub seeds: Map<Text, Map<Text, Rel>>,
    pub local_of: Map<Text, Text>,
    pub local_base: Map<Text, Map<Text, Rel>>,
}

impl Show for Shrink {
    fn show(&self, p: &mut Printer) {
        p.record("Shrink", &[("g", &self.g), ("fns", &self.fns), ("by_key", &self.by_key), ("targets", &self.targets), ("impl_defs", &self.impl_defs), ("choices", &self.choices), ("sums", &self.sums), ("seeds", &self.seeds), ("local_of", &self.local_of), ("local_base", &self.local_base)]);
    }
}

impl ToPod for Shrink {
    fn to_pod(&self) -> Pod {
        Pod::record("Shrink", vec![("g", self.g.to_pod()), ("fns", self.fns.to_pod()), ("by_key", self.by_key.to_pod()), ("targets", self.targets.to_pod()), ("impl_defs", self.impl_defs.to_pod()), ("choices", self.choices.to_pod()), ("sums", self.sums.to_pod()), ("seeds", self.seeds.to_pod()), ("local_of", self.local_of.to_pod()), ("local_base", self.local_base.to_pod())])
    }
}

impl FromPod for Shrink {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Shrink { g: FromPod::from_pod(field(p, "g")?)?, fns: FromPod::from_pod(field(p, "fns")?)?, by_key: FromPod::from_pod(field(p, "by_key")?)?, targets: FromPod::from_pod(field(p, "targets")?)?, impl_defs: FromPod::from_pod(field(p, "impl_defs")?)?, choices: FromPod::from_pod(field(p, "choices")?)?, sums: FromPod::from_pod(field(p, "sums")?)?, seeds: FromPod::from_pod(field(p, "seeds")?)?, local_of: FromPod::from_pod(field(p, "local_of")?)?, local_base: FromPod::from_pod(field(p, "local_base")?)? })
    }
}

/// `Site`:
///
/// ```prism
/// type Site = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Site {
    pub callee: Text,
    pub args: Array<ast::Arg>,
    pub span: ast::Range,
    pub rels: Map<Text, Rel>,
}

impl Show for Site {
    fn show(&self, p: &mut Printer) {
        p.record("Site", &[("callee", &self.callee), ("args", &self.args), ("span", &self.span), ("rels", &self.rels)]);
    }
}

impl ToPod for Site {
    fn to_pod(&self) -> Pod {
        Pod::record("Site", vec![("callee", self.callee.to_pod()), ("args", self.args.to_pod()), ("span", self.span.to_pod()), ("rels", self.rels.to_pod())])
    }
}

impl FromPod for Site {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Site { callee: FromPod::from_pod(field(p, "callee")?)?, args: FromPod::from_pod(field(p, "args")?)?, span: FromPod::from_pod(field(p, "span")?)?, rels: FromPod::from_pod(field(p, "rels")?)? })
    }
}

/// `Slot`:
///
/// ```prism
/// type Slot = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Slot_ {
    pub owner: Text,
    pub at: Nat,
    pub arity: Nat,
}

impl Show for Slot_ {
    fn show(&self, p: &mut Printer) {
        p.record("Slot", &[("owner", &self.owner), ("at", &self.at), ("arity", &self.arity)]);
    }
}

impl ToPod for Slot_ {
    fn to_pod(&self) -> Pod {
        Pod::record("Slot", vec![("owner", self.owner.to_pod()), ("at", self.at.to_pod()), ("arity", self.arity.to_pod())])
    }
}

impl FromPod for Slot_ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Slot_ { owner: FromPod::from_pod(field(p, "owner")?)?, at: FromPod::from_pod(field(p, "at")?)?, arity: FromPod::from_pod(field(p, "arity")?)? })
    }
}

/// `Spot`:
///
/// ```prism
/// type Spot = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Spot {
    SpotExpr(ast::Expr, Map<Text, Rel>),
    SpotStmt(ast::Stmt, Map<Text, Rel>),
}

impl Show for Spot {
    fn show(&self, p: &mut Printer) {
        match self {
            Spot::SpotExpr(a0, a1) => p.choice("SpotExpr", &[a0, a1]),
            Spot::SpotStmt(a0, a1) => p.choice("SpotStmt", &[a0, a1]),
        }
    }
}

impl ToPod for Spot {
    fn to_pod(&self) -> Pod {
        match self {
            Spot::SpotExpr(a0, a1) => Pod::Choice("SpotExpr".into(), vec![a0.to_pod(), a1.to_pod()]),
            Spot::SpotStmt(a0, a1) => Pod::Choice("SpotStmt".into(), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl FromPod for Spot {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "SpotExpr" && a.len() == 2 => Ok(Spot::SpotExpr(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "SpotStmt" && a.len() == 2 => Ok(Spot::SpotStmt(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            other => mismatch("a Spot", other),
        }
    }
}

/// ```prism
/// ?CtorsOf: unbounded fn Env, St, Ty -> ?[Ctor]
/// ```
pub fn ctors_of(env: &check_expr::Env, st: &check_types::St, t: &check_types::Ty) -> Option<Array<Ctor>> {
    match check_types::walk(st, t) {
        check_types::Ty::TyCon(m2052_0_0, m2052_0_1) if (&m2052_0_0 == &Text::from("Bool")) && ((&m2052_0_1).len() == 0) => Some(Array::from(vec![Ctor { name: Text::from("True"), arity: Nat::from(0u32), args: Array::new(), shown: Text::from("True") }, Ctor { name: Text::from("False"), arity: Nat::from(0u32), args: Array::new(), shown: Text::from("False") }])),
        check_types::Ty::TyCon(m2052_1_0, m2052_1_1) if (&m2052_1_0 == &Text::from("unit")) && ((&m2052_1_1).len() == 0) => Some(Array::from(vec![Ctor { name: Text::from("unit"), arity: Nat::from(0u32), args: Array::new(), shown: Text::from("unit") }])),
        check_types::Ty::TySig(m2052_2_0, i) if (&m2052_2_0 == &Text::from("?")) => Some(Array::from(vec![Ctor { name: Text::from("?"), arity: Nat::from(1u32), args: Array::from(vec![(*i).clone()]), shown: Text::from("? _") }, Ctor { name: Text::from("nil"), arity: Nat::from(0u32), args: Array::new(), shown: Text::from("nil") }])),
        check_types::Ty::TySig(m2052_3_0, i) if (&m2052_3_0 == &Text::from("~")) => Some(Array::from(vec![Ctor { name: Text::from("~"), arity: Nat::from(1u32), args: Array::from(vec![(*i).clone()]), shown: Text::from("~ _") }, Ctor { name: Text::from("Error"), arity: Nat::from(2u32), args: Array::from(vec![check_types::Ty::TyCon(Text::from("Prelude.Fault"), Array::new()), check_types::t_text()]), shown: Text::from("Error(..)") }])),
        check_types::Ty::TyTuple(ts) => Some(Array::from(vec![Ctor { name: Text::from("tuple"), arity: len(&ts), args: ts.clone(), shown: Text::from(format!("(({}))", &lexer::join(&each(&ts, &(|_: &check_types::Ty| Text::from("_"))), &Text::from(", ")))) }])),
        check_types::Ty::TyCon(m2052_5_0, m2052_5_1) if (&m2052_5_0 == &Text::from("Prelude.Error")) && ((&m2052_5_1).len() == 0) => Some(Array::from(vec![Ctor { name: Text::from("Error"), arity: Nat::from(2u32), args: Array::from(vec![check_types::Ty::TyCon(Text::from("Prelude.Fault"), Array::new()), check_types::t_text()]), shown: Text::from("Error(..)") }])),
        check_types::Ty::TyCon(n, args) => match get(&env.g.types, &n) {
            Some(ti) => match &ti.body {
                check_env::TyBody::BChoice(cases) => Some(run_to_end(each_job(cases.clone(), {
                    let ti = ti.clone();
                    let args = args.clone();
                    Rc::new(move |p0: (Text, Array<check_types::Ty>)| {
                        let ti = ti.clone();
                        let args = args.clone();
                        entered(once_job(move || {
                            let (cn, cargs) = p0;
                            prism_rtl::Turn::More(Rc::new(CtorOfCase { ti: ti.clone(), cn: cn.clone(), cargs: cargs.clone(), args: args.clone() }))
                        }))
                    }) as Rc<dyn Fn((Text, Array<check_types::Ty>)) -> Rc<dyn prism_rtl::Job<Ctor>>>
                }))),
                check_env::TyBody::BRecord(fields) => Some(Array::from(vec![Ctor { name: n.clone(), arity: len(fields), args: run_to_end(each_job(fields.clone(), {
                    let ti = ti.clone();
                    let args = args.clone();
                    Rc::new(move |p0: (Text, check_types::Ty)| {
                        let ti = ti.clone();
                        let args = args.clone();
                        entered(once_job(move || {
                            let (_, ft) = p0;
                            prism_rtl::Turn::More(Rc::new(check_types::SubstQ { m: check_env::param_inst(&ti.params, &args), t: ft.clone() }))
                        }))
                    }) as Rc<dyn Fn((Text, check_types::Ty)) -> Rc<dyn prism_rtl::Job<check_types::Ty>>>
                })), shown: Text::from(format!("{}(..)", &check_types::bare_name(&n))) }])),
                check_env::TyBody::BRowKind => if is_root_module(env) {
                    Some(each(&tags_of_kind(env, &n), &(|tg: &check_env::TagInfo| tag_ctor(tg))))
                } else {
                    None
                },
                _ => None,
            },
            None => if (&n == &Text::from("Fault")) || (&n == &Text::from("Prelude.Fault")) {
                if is_root_module(env) {
                    Some(each(&tags_of_kind(env, &Text::from("Prelude.Fault")), &(|tg: &check_env::TagInfo| tag_ctor(tg))))
                } else {
                    None
                }
            } else {
                None
            },
        },
        check_types::Ty::TyElem(rw, _) => {
            let w = check_types::walk_row(st, &rw);
            if &w.tail != &check_types::Tail::TlClosed {
                None
            } else {
                Some(each(&tags_of_row(env, &w), &(|tg: &check_env::TagInfo| tag_ctor(tg))))
            }
        },
        check_types::Ty::TyElemAny(rw) => {
            let w = check_types::walk_row(st, &rw);
            if &w.tail != &check_types::Tail::TlClosed {
                None
            } else {
                Some(each(&tags_of_row(env, &w), &(|tg: &check_env::TagInfo| tag_ctor(tg))))
            }
        },
        _ => None,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CtorsOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?CtorsOf: unbounded fn Env, St, Ty -> ?[Ctor]
/// ```
pub struct CtorsOf {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub t: check_types::Ty,
}

impl prism_rtl::Job<Option<Array<Ctor>>> for CtorsOf {
    fn cycle(&self) -> prism_rtl::Turn<Option<Array<Ctor>>> {
        let env = &self.env;
        let st = &self.st;
        let t = &self.t;
        let env = env.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(check_types::start_walk(st.clone(), t.clone()), move |walk_2058: check_types::Ty| match walk_2058 {
            check_types::Ty::TyCon(m2052_0_0, m2052_0_1) if (&m2052_0_0 == &Text::from("Bool")) && ((&m2052_0_1).len() == 0) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: Text::from("True"), arity: Nat::from(0u32), args: Array::new(), shown: Text::from("True") }, Ctor { name: Text::from("False"), arity: Nat::from(0u32), args: Array::new(), shown: Text::from("False") }]))),
            check_types::Ty::TyCon(m2052_1_0, m2052_1_1) if (&m2052_1_0 == &Text::from("unit")) && ((&m2052_1_1).len() == 0) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: Text::from("unit"), arity: Nat::from(0u32), args: Array::new(), shown: Text::from("unit") }]))),
            check_types::Ty::TySig(m2052_2_0, i) if (&m2052_2_0 == &Text::from("?")) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: Text::from("?"), arity: Nat::from(1u32), args: Array::from(vec![(*i).clone()]), shown: Text::from("? _") }, Ctor { name: Text::from("nil"), arity: Nat::from(0u32), args: Array::new(), shown: Text::from("nil") }]))),
            check_types::Ty::TySig(m2052_3_0, i) if (&m2052_3_0 == &Text::from("~")) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: Text::from("~"), arity: Nat::from(1u32), args: Array::from(vec![(*i).clone()]), shown: Text::from("~ _") }, Ctor { name: Text::from("Error"), arity: Nat::from(2u32), args: Array::from(vec![check_types::Ty::TyCon(Text::from("Prelude.Fault"), Array::new()), check_types::t_text()]), shown: Text::from("Error(..)") }]))),
            check_types::Ty::TyTuple(ts) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: Text::from("tuple"), arity: len(&ts), args: ts.clone(), shown: Text::from(format!("(({}))", &lexer::join(&each(&ts, &(|_: &check_types::Ty| Text::from("_"))), &Text::from(", ")))) }]))),
            check_types::Ty::TyCon(m2052_5_0, m2052_5_1) if (&m2052_5_0 == &Text::from("Prelude.Error")) && ((&m2052_5_1).len() == 0) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: Text::from("Error"), arity: Nat::from(2u32), args: Array::from(vec![check_types::Ty::TyCon(Text::from("Prelude.Fault"), Array::new()), check_types::t_text()]), shown: Text::from("Error(..)") }]))),
            check_types::Ty::TyCon(n, args) => match get(&env.g.types, &n) {
                Some(ti) => match &ti.body {
                    check_env::TyBody::BChoice(cases) => prism_rtl::Turn::Finished(Some(run_to_end(each_job(cases.clone(), {
                        let ti = ti.clone();
                        let args = args.clone();
                        Rc::new(move |p0: (Text, Array<check_types::Ty>)| {
                            let ti = ti.clone();
                            let args = args.clone();
                            entered(once_job(move || {
                                let (cn, cargs) = p0;
                                prism_rtl::Turn::More(Rc::new(CtorOfCase { ti: ti.clone(), cn: cn.clone(), cargs: cargs.clone(), args: args.clone() }))
                            }))
                        }) as Rc<dyn Fn((Text, Array<check_types::Ty>)) -> Rc<dyn prism_rtl::Job<Ctor>>>
                    })))),
                    check_env::TyBody::BRecord(fields) => prism_rtl::Turn::Finished(Some(Array::from(vec![Ctor { name: n.clone(), arity: len(fields), args: run_to_end(each_job(fields.clone(), {
                        let ti = ti.clone();
                        let args = args.clone();
                        Rc::new(move |p0: (Text, check_types::Ty)| {
                            let ti = ti.clone();
                            let args = args.clone();
                            entered(once_job(move || {
                                let (_, ft) = p0;
                                prism_rtl::Turn::More(Rc::new(check_types::SubstQ { m: check_env::param_inst(&ti.params, &args), t: ft.clone() }))
                            }))
                        }) as Rc<dyn Fn((Text, check_types::Ty)) -> Rc<dyn prism_rtl::Job<check_types::Ty>>>
                    })), shown: Text::from(format!("{}(..)", &check_types::bare_name(&n))) }]))),
                    check_env::TyBody::BRowKind => if is_root_module(&env) {
                        prism_rtl::Turn::Finished(Some(each(&tags_of_kind(&env, &n), &(|tg: &check_env::TagInfo| tag_ctor(tg)))))
                    } else {
                        prism_rtl::Turn::Finished(None)
                    },
                    _ => prism_rtl::Turn::Finished(None),
                },
                None => if (&n == &Text::from("Fault")) || (&n == &Text::from("Prelude.Fault")) {
                    if is_root_module(&env) {
                        prism_rtl::Turn::Finished(Some(each(&tags_of_kind(&env, &Text::from("Prelude.Fault")), &(|tg: &check_env::TagInfo| tag_ctor(tg)))))
                    } else {
                        prism_rtl::Turn::Finished(None)
                    }
                } else {
                    prism_rtl::Turn::Finished(None)
                },
            },
            check_types::Ty::TyElem(rw, _) => call_then(check_types::start_walk_row(st.clone(), rw.clone()), move |walk_row_3487: check_types::Rw| {
                let w = walk_row_3487;
                if &w.tail != &check_types::Tail::TlClosed {
                    prism_rtl::Turn::Finished(None)
                } else {
                    prism_rtl::Turn::Finished(Some(each(&tags_of_row(&env, &w), &(|tg: &check_env::TagInfo| tag_ctor(tg)))))
                }
            }),
            check_types::Ty::TyElemAny(rw) => call_then(check_types::start_walk_row(st.clone(), rw.clone()), move |walk_row_3631: check_types::Rw| {
                let w = walk_row_3631;
                if &w.tail != &check_types::Tail::TlClosed {
                    prism_rtl::Turn::Finished(None)
                } else {
                    prism_rtl::Turn::Finished(Some(each(&tags_of_row(&env, &w), &(|tg: &check_env::TagInfo| tag_ctor(tg)))))
                }
            }),
            _ => prism_rtl::Turn::Finished(None),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start CtorsOf, x`: what the function value is when passed to `@Run`.
pub fn start_ctors_of(env: check_expr::Env, st: check_types::St, t: check_types::Ty) -> Rc<dyn prism_rtl::Job<Option<Array<Ctor>>>> {
    Rc::new(CtorsOf { env, st, t })
}

/// ```prism
/// CtorOfCase: unbounded fn TyInfo, Text, [Ty], [Ty] -> Ctor
/// ```
pub fn ctor_of_case(ti: &check_env::TyInfo, cn: &Text, cargs: &Array<check_types::Ty>, args: &Array<check_types::Ty>) -> Ctor {
    let qk = check_env::qual_key(&ti.home, cn);
    Ctor { name: qk.clone(), arity: len(cargs), args: run_to_end(each_job(cargs.clone(), {
        let ti = ti.clone();
        let args = args.clone();
        Rc::new(move |p0: check_types::Ty| {
            let ti = ti.clone();
            let args = args.clone();
            entered(once_job(move || {
                let a = p0;
                prism_rtl::Turn::More(Rc::new(check_types::SubstQ { m: check_env::param_inst(&ti.params, &args), t: a.clone() }))
            }))
        }) as Rc<dyn Fn(check_types::Ty) -> Rc<dyn prism_rtl::Job<check_types::Ty>>>
    })), shown: if &len(cargs) == &Nat::from(0u32) {
        cn.clone()
    } else {
        Text::from(format!("{} {}", cn, &lexer::join(&each(cargs, &(|_: &check_types::Ty| Text::from("_"))), &Text::from(", "))))
    } }
}

/// The step machine of `CtorOfCase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorOfCase: unbounded fn TyInfo, Text, [Ty], [Ty] -> Ctor
/// ```
pub struct CtorOfCase {
    pub ti: check_env::TyInfo,
    pub cn: Text,
    pub cargs: Array<check_types::Ty>,
    pub args: Array<check_types::Ty>,
}

impl prism_rtl::Job<Ctor> for CtorOfCase {
    fn cycle(&self) -> prism_rtl::Turn<Ctor> {
        let ti = &self.ti;
        let cn = &self.cn;
        let cargs = &self.cargs;
        let args = &self.args;
        let qk = check_env::qual_key(&ti.home, cn);
        let args = args.clone();
        let cargs = cargs.clone();
        let cn = cn.clone();
        let ti = ti.clone();
        call_value(each_job(cargs.clone(), {
            let ti = ti.clone();
            let args = args.clone();
            Rc::new(move |p0: check_types::Ty| {
                let ti = ti.clone();
                let args = args.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(check_types::SubstQ { m: check_env::param_inst(&ti.params, &args), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(check_types::Ty) -> Rc<dyn prism_rtl::Job<check_types::Ty>>>
        }), move |each_3930: Array<check_types::Ty>| prism_rtl::Turn::Finished(Ctor { name: qk.clone(), arity: len(&cargs), args: each_3930, shown: if &len(&cargs) == &Nat::from(0u32) {
            cn.clone()
        } else {
            Text::from(format!("{} {}", &cn, &lexer::join(&each(&cargs, &(|_: &check_types::Ty| Text::from("_"))), &Text::from(", "))))
        } }))
    }
}

/// `Start CtorOfCase, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_of_case(ti: check_env::TyInfo, cn: Text, cargs: Array<check_types::Ty>, args: Array<check_types::Ty>) -> Rc<dyn prism_rtl::Job<Ctor>> {
    Rc::new(CtorOfCase { ti, cn, cargs, args })
}

/// ```prism
/// TagCtor: fn TagInfo -> Ctor
/// ```
pub fn tag_ctor(tg: &check_env::TagInfo) -> Ctor {
    Ctor { name: Text::from(format!("tag:{}", &tg.name)), arity: len(&tg.fields), args: each(&tg.fields, &(|(_, ft): &(Text, check_types::Ty)| check_types::Ty::TyErr)), shown: tg.name.clone() }
}

/// ```prism
/// IsRootModule: fn Env -> Bool
/// ```
pub fn is_root_module(env: &check_expr::Env) -> bool {
    &env.home == &Text::from("")
}

/// ```prism
/// TagsOfKind: fn Env, Text -> [TagInfo]
/// ```
pub fn tags_of_kind(env: &check_expr::Env, kind: &Text) -> Array<check_env::TagInfo> {
    filter(&values(&env.g.tags), &(|tg: &check_env::TagInfo| (&tg.kind == kind) || ((&check_types::bare_name(&tg.kind) == &Text::from("Fault")) && (&check_types::bare_name(kind) == &Text::from("Fault")))))
}

/// ```prism
/// TagsOfRow: fn Env, Rw -> [TagInfo]
/// ```
pub fn tags_of_row(env: &check_expr::Env, w: &check_types::Rw) -> Array<check_env::TagInfo> {
    filter(&values(&env.g.tags), &(|tg: &check_env::TagInfo| ((&tg.kind == &Text::from("Element")) && check_types::has_text(&w.fams, &tg.family)) && !check_types::has_text(&w.minus, &tg.name)))
}

/// ```prism
/// ToPat: unbounded fn Env, Pattern -> Pat
/// ```
pub fn to_pat(env: &check_expr::Env, p_: &ast::Pattern_) -> Pat {
    match &*p_.kind {
        ast::PatternKind::PName(n) => {
            let bare = or(&index(&n.path_, &Nat::from(0u32)), &Text::from(""));
            if (&len(&n.path_) > &Nat::from(1u32)) && check_env::has_key(&env.g.tags, &check_env::dotted(&n.path_)) {
                Pat::PtCon(Text::from(format!("tag:{}", &check_env::dotted(&n.path_))), Array::new())
            } else {
                if (check_env::is_upper_text(&bare) && (&len_text(&n.sigils) == &Nat::from(0u32))) && check_expr::is_ctor_name(env, n) {
                    Pat::PtCon(ctor_key(env, n), Array::new())
                } else {
                    Pat::PtAny
                }
            }
        },
        ast::PatternKind::PIgnore => Pat::PtAny,
        ast::PatternKind::PLit(l) => Pat::PtLit(lit_text(l)),
        ast::PatternKind::PNeg(l) => Pat::PtLit(Text::from(format!("-{}", &lit_text(l)))),
        ast::PatternKind::PUnit => Pat::PtCon(Text::from("unit"), Array::new()),
        ast::PatternKind::PNil => Pat::PtCon(Text::from("nil"), Array::new()),
        ast::PatternKind::PCtor(n, args) => if check_env::has_key(&env.g.tags, &check_env::dotted(&n.path_)) {
            Pat::PtCon(Text::from(format!("tag:{}", &check_env::dotted(&n.path_))), Array::new())
        } else {
            Pat::PtCon(ctor_key(env, n), run_to_end(each_job(args.clone(), {
                let env = env.clone();
                Rc::new(move |p0: ast::Pattern_| {
                    let env = env.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: a.clone() }))
                    }))
                }) as Rc<dyn Fn(ast::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
            })))
        },
        ast::PatternKind::PRecord(n, fields, _) => record_pat(env, n, fields),
        ast::PatternKind::PSigil(s, q) => Pat::PtCon(s.clone(), Array::from(vec![to_pat(env, &**q)])),
        ast::PatternKind::PTuple(ps) => Pat::PtCon(Text::from("tuple"), run_to_end(each_job(ps.clone(), {
            let env = env.clone();
            Rc::new(move |p0: ast::Pattern_| {
                let env = env.clone();
                entered(once_job(move || {
                    let q = p0;
                    prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: q.clone() }))
                }))
            }) as Rc<dyn Fn(ast::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
        }))),
        ast::PatternKind::PArray(ps) => Pat::PtCon(Text::from(format!("len{}", &len(ps))), run_to_end(each_job(ps.clone(), {
            let env = env.clone();
            Rc::new(move |p0: ast::Pattern_| {
                let env = env.clone();
                entered(once_job(move || {
                    let q = p0;
                    prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: q.clone() }))
                }))
            }) as Rc<dyn Fn(ast::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
        }))),
        ast::PatternKind::PGroup(q) => to_pat(env, &**q),
        ast::PatternKind::PFamily(q) => Pat::PtFam(check_env::dotted(&q.path_)),
    }
}

/// The step machine of `ToPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ToPat: unbounded fn Env, Pattern -> Pat
/// ```
pub struct ToPat {
    pub env: check_expr::Env,
    pub p_: ast::Pattern_,
}

impl prism_rtl::Job<Pat> for ToPat {
    fn cycle(&self) -> prism_rtl::Turn<Pat> {
        let env = &self.env;
        let p_ = &self.p_;
        match &*p_.kind {
            ast::PatternKind::PName(n) => {
                let bare = or(&index(&n.path_, &Nat::from(0u32)), &Text::from(""));
                if (&len(&n.path_) > &Nat::from(1u32)) && check_env::has_key(&env.g.tags, &check_env::dotted(&n.path_)) {
                    prism_rtl::Turn::Finished(Pat::PtCon(Text::from(format!("tag:{}", &check_env::dotted(&n.path_))), Array::new()))
                } else {
                    if (check_env::is_upper_text(&bare) && (&len_text(&n.sigils) == &Nat::from(0u32))) && check_expr::is_ctor_name(env, n) {
                        prism_rtl::Turn::Finished(Pat::PtCon(ctor_key(env, n), Array::new()))
                    } else {
                        prism_rtl::Turn::Finished(Pat::PtAny)
                    }
                }
            },
            ast::PatternKind::PIgnore => prism_rtl::Turn::Finished(Pat::PtAny),
            ast::PatternKind::PLit(l) => prism_rtl::Turn::Finished(Pat::PtLit(lit_text(l))),
            ast::PatternKind::PNeg(l) => prism_rtl::Turn::Finished(Pat::PtLit(Text::from(format!("-{}", &lit_text(l))))),
            ast::PatternKind::PUnit => prism_rtl::Turn::Finished(Pat::PtCon(Text::from("unit"), Array::new())),
            ast::PatternKind::PNil => prism_rtl::Turn::Finished(Pat::PtCon(Text::from("nil"), Array::new())),
            ast::PatternKind::PCtor(n, args) => if check_env::has_key(&env.g.tags, &check_env::dotted(&n.path_)) {
                prism_rtl::Turn::Finished(Pat::PtCon(Text::from(format!("tag:{}", &check_env::dotted(&n.path_))), Array::new()))
            } else {
                {
                    let args = args.clone();
                    let env = env.clone();
                    let n = n.clone();
                    call_value(each_job(args.clone(), {
                        let env = env.clone();
                        Rc::new(move |p0: ast::Pattern_| {
                            let env = env.clone();
                            entered(once_job(move || {
                                let a = p0;
                                prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: a.clone() }))
                            }))
                        }) as Rc<dyn Fn(ast::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
                    }), move |each_5432: Array<Pat>| prism_rtl::Turn::Finished(Pat::PtCon(ctor_key(&env, &n), each_5432)))
                }
            },
            ast::PatternKind::PRecord(n, fields, _) => prism_rtl::Turn::More(Rc::new(RecordPat { env: env.clone(), n: n.clone(), fields: fields.clone() })),
            ast::PatternKind::PSigil(s, q) => {
                let env = env.clone();
                let q = (**q).clone();
                let s = s.clone();
                call_then(start_to_pat(env.clone(), q.clone()), move |to_pat_5547: Pat| prism_rtl::Turn::Finished(Pat::PtCon(s.clone(), Array::from(vec![to_pat_5547]))))
            },
            ast::PatternKind::PTuple(ps) => {
                let env = env.clone();
                let ps = ps.clone();
                call_value(each_job(ps.clone(), {
                    let env = env.clone();
                    Rc::new(move |p0: ast::Pattern_| {
                        let env = env.clone();
                        entered(once_job(move || {
                            let q = p0;
                            prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: q.clone() }))
                        }))
                    }) as Rc<dyn Fn(ast::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
                }), move |each_5594: Array<Pat>| prism_rtl::Turn::Finished(Pat::PtCon(Text::from("tuple"), each_5594)))
            },
            ast::PatternKind::PArray(ps) => {
                let env = env.clone();
                let ps = ps.clone();
                call_value(each_job(ps.clone(), {
                    let env = env.clone();
                    Rc::new(move |p0: ast::Pattern_| {
                        let env = env.clone();
                        entered(once_job(move || {
                            let q = p0;
                            prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: q.clone() }))
                        }))
                    }) as Rc<dyn Fn(ast::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
                }), move |each_5659: Array<Pat>| prism_rtl::Turn::Finished(Pat::PtCon(Text::from(format!("len{}", &len(&ps))), each_5659)))
            },
            ast::PatternKind::PGroup(q) => prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: (**q).clone() })),
            ast::PatternKind::PFamily(q) => prism_rtl::Turn::Finished(Pat::PtFam(check_env::dotted(&q.path_))),
        }
    }
}

/// `Start ToPat, x`: what the function value is when passed to `@Run`.
pub fn start_to_pat(env: check_expr::Env, p_: ast::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>> {
    Rc::new(ToPat { env, p_ })
}

/// ```prism
/// LitText: fn Literal -> Text
/// ```
pub fn lit_text(l: &ast::Literal) -> Text {
    match &l.kind {
        ast::LitKind::LInt(d) => d.clone(),
        ast::LitKind::LFloat(d) => d.clone(),
        ast::LitKind::LChar(c) => Text::from(format!("'{}'", c)),
        ast::LitKind::LText(segs) => concat(&each(segs, &lit_seg_text)),
        ast::LitKind::LDuration(d, u) => Text::from(format!("{}{}", d, u)),
    }
}

/// ```prism
/// LitSegText: fn TextSeg -> Text
/// ```
pub fn lit_seg_text(text_seg0: &ast::TextSeg) -> Text {
    match text_seg0 {
        ast::TextSeg::SegPlain(t) => t.clone(),
        _ => Text::from("{}"),
    }
}

/// ```prism
/// CtorKey: fn Env, SName -> Text
/// ```
pub fn ctor_key(env: &check_expr::Env, n: &ast::SName) -> Text {
    let (qk_opt, _) = check_env::resolve_value(&env.g, &env.home, n);
    or(&qk_opt, &check_env::sname_key(n))
}

/// ```prism
/// RecordPat: unbounded fn Env, SName, [FieldPat] -> Pat
/// ```
pub fn record_pat(env: &check_expr::Env, n: &ast::SName, fields: &Array<ast::FieldPat>) -> Pat {
    let name = check_env::dotted(&n.path_);
    match get(&env.g.tags, &name) {
        Some(tg) => {
            let names = each(&tg.fields, &(|(f, _): &(Text, check_types::Ty)| f.clone()));
            Pat::PtCon(Text::from(format!("tag:{}", &name)), run_to_end(each_job(names.clone(), {
                let env = env.clone();
                let fields = fields.clone();
                let names = names.clone();
                Rc::new(move |p0: Text| {
                    let env = env.clone();
                    let fields = fields.clone();
                    let names = names.clone();
                    entered(once_job(move || {
                        let f = p0;
                        prism_rtl::Turn::More(Rc::new(FieldPatFor { env: env.clone(), fields: fields.clone(), names: names.clone(), f: f.clone() }))
                    }))
                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Pat>>>
            })))
        },
        None => {
            let qk = ctor_key(env, n);
            let fnames = if &check_types::bare_name(&qk) == &Text::from("Error") {
                Array::from(vec![Text::from("kind"), Text::from("message")])
            } else {
                or(&get(&env.g.ctors, &qk), &dummy_ctor()).fields.clone()
            };
            let pkey = if &check_types::bare_name(&qk) == &Text::from("Error") {
                Text::from("Error")
            } else {
                qk.clone()
            };
            Pat::PtCon(pkey.clone(), run_to_end(each_job(fnames.clone(), {
                let env = env.clone();
                let fields = fields.clone();
                let fnames = fnames.clone();
                Rc::new(move |p0: Text| {
                    let env = env.clone();
                    let fields = fields.clone();
                    let fnames = fnames.clone();
                    entered(once_job(move || {
                        let f = p0;
                        prism_rtl::Turn::More(Rc::new(FieldPatFor { env: env.clone(), fields: fields.clone(), names: fnames.clone(), f: f.clone() }))
                    }))
                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Pat>>>
            })))
        },
    }
}

/// The step machine of `RecordPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RecordPat: unbounded fn Env, SName, [FieldPat] -> Pat
/// ```
pub struct RecordPat {
    pub env: check_expr::Env,
    pub n: ast::SName,
    pub fields: Array<ast::FieldPat>,
}

impl prism_rtl::Job<Pat> for RecordPat {
    fn cycle(&self) -> prism_rtl::Turn<Pat> {
        let env = &self.env;
        let n = &self.n;
        let fields = &self.fields;
        let name = check_env::dotted(&n.path_);
        match get(&env.g.tags, &name) {
            Some(tg) => {
                let names = each(&tg.fields, &(|(f, _): &(Text, check_types::Ty)| f.clone()));
                let env = env.clone();
                let fields = fields.clone();
                call_value(each_job(names.clone(), {
                    let env = env.clone();
                    let fields = fields.clone();
                    let names = names.clone();
                    Rc::new(move |p0: Text| {
                        let env = env.clone();
                        let fields = fields.clone();
                        let names = names.clone();
                        entered(once_job(move || {
                            let f = p0;
                            prism_rtl::Turn::More(Rc::new(FieldPatFor { env: env.clone(), fields: fields.clone(), names: names.clone(), f: f.clone() }))
                        }))
                    }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Pat>>>
                }), move |each_6498: Array<Pat>| prism_rtl::Turn::Finished(Pat::PtCon(Text::from(format!("tag:{}", &name)), each_6498)))
            },
            None => {
                let qk = ctor_key(env, n);
                let fnames = if &check_types::bare_name(&qk) == &Text::from("Error") {
                    Array::from(vec![Text::from("kind"), Text::from("message")])
                } else {
                    or(&get(&env.g.ctors, &qk), &dummy_ctor()).fields.clone()
                };
                let pkey = if &check_types::bare_name(&qk) == &Text::from("Error") {
                    Text::from("Error")
                } else {
                    qk.clone()
                };
                let env = env.clone();
                let fields = fields.clone();
                call_value(each_job(fnames.clone(), {
                    let env = env.clone();
                    let fields = fields.clone();
                    let fnames = fnames.clone();
                    Rc::new(move |p0: Text| {
                        let env = env.clone();
                        let fields = fields.clone();
                        let fnames = fnames.clone();
                        entered(once_job(move || {
                            let f = p0;
                            prism_rtl::Turn::More(Rc::new(FieldPatFor { env: env.clone(), fields: fields.clone(), names: fnames.clone(), f: f.clone() }))
                        }))
                    }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Pat>>>
                }), move |each_6814: Array<Pat>| prism_rtl::Turn::Finished(Pat::PtCon(pkey.clone(), each_6814)))
            },
        }
    }
}

/// `Start RecordPat, x`: what the function value is when passed to `@Run`.
pub fn start_record_pat(env: check_expr::Env, n: ast::SName, fields: Array<ast::FieldPat>) -> Rc<dyn prism_rtl::Job<Pat>> {
    Rc::new(RecordPat { env, n, fields })
}

/// ```prism
/// let dummyCtor
/// ```
pub fn dummy_ctor() -> check_env::CtorInfo {
    check_env::CtorInfo { name: Text::from(""), owner: Text::from(""), params: Array::new(), args: Array::new(), fields: Array::new(), ty: check_types::Ty::TyErr, index: Nat::from(0u32) }
}

/// ```prism
/// FieldPatFor: unbounded fn Env, [FieldPat], [Text], Text -> Pat
/// ```
pub fn field_pat_for(env: &check_expr::Env, fields: &Array<ast::FieldPat>, names: &Array<Text>, f: &Text) -> Pat {
    run_to_end(fold_job(check_errors::range0(&len(fields)), Pat::PtAny, {
        let fields = fields.clone();
        let names = names.clone();
        let f = f.clone();
        let env = env.clone();
        Rc::new(move |(p0, p1): (Pat, Nat)| {
            let fields = fields.clone();
            let names = names.clone();
            let f = f.clone();
            let env = env.clone();
            entered(once_job(move || {
                let acc = p0;
                let i = p1;
                match index(&fields, &i) {
                    Some(fp) => if &check_expr::field_pat_name(&fp, &names, &i) == &f {
                        prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: fp.pattern.clone() }))
                    } else {
                        prism_rtl::Turn::Finished(acc.clone())
                    },
                    None => prism_rtl::Turn::Finished(acc.clone()),
                }
            }))
        }) as Rc<dyn Fn((Pat, Nat)) -> Rc<dyn prism_rtl::Job<Pat>>>
    }))
}

/// The step machine of `FieldPatFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldPatFor: unbounded fn Env, [FieldPat], [Text], Text -> Pat
/// ```
pub struct FieldPatFor {
    pub env: check_expr::Env,
    pub fields: Array<ast::FieldPat>,
    pub names: Array<Text>,
    pub f: Text,
}

impl prism_rtl::Job<Pat> for FieldPatFor {
    fn cycle(&self) -> prism_rtl::Turn<Pat> {
        let env = &self.env;
        let fields = &self.fields;
        let names = &self.names;
        let f = &self.f;
        fold_job(check_errors::range0(&len(fields)), Pat::PtAny, {
            let fields = fields.clone();
            let names = names.clone();
            let f = f.clone();
            let env = env.clone();
            Rc::new(move |(p0, p1): (Pat, Nat)| {
                let fields = fields.clone();
                let names = names.clone();
                let f = f.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let i = p1;
                    match index(&fields, &i) {
                        Some(fp) => if &check_expr::field_pat_name(&fp, &names, &i) == &f {
                            prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: fp.pattern.clone() }))
                        } else {
                            prism_rtl::Turn::Finished(acc.clone())
                        },
                        None => prism_rtl::Turn::Finished(acc.clone()),
                    }
                }))
            }) as Rc<dyn Fn((Pat, Nat)) -> Rc<dyn prism_rtl::Job<Pat>>>
        }).cycle()
    }
}

/// `Start FieldPatFor, x`: what the function value is when passed to `@Run`.
pub fn start_field_pat_for(env: check_expr::Env, fields: Array<ast::FieldPat>, names: Array<Text>, f: Text) -> Rc<dyn prism_rtl::Job<Pat>> {
    Rc::new(FieldPatFor { env, fields, names, f })
}

/// ```prism
/// Useful: unbounded fn Env, St, [ [Pat] ], [Pat], [Ty] -> Bool
/// ```
pub fn useful(env: &check_expr::Env, st: &check_types::St, rows: &Array<Array<Pat>>, q: &Array<Pat>, tys: &Array<check_types::Ty>) -> bool {
    match index(q, &Nat::from(0u32)) {
        None => &len(rows) == &Nat::from(0u32),
        Some(q1) => {
            let t1 = or(&index(tys, &Nat::from(0u32)), &check_types::Ty::TyErr);
            let rest = drop(tys, &Nat::from(1u32));
            match &q1 {
                Pat::PtCon(c, args) => {
                    let ctor = ctor_named(env, st, &t1, c, &len(args));
                    useful(env, st, &specialize(rows, &ctor), &append(args, &drop(q, &Nat::from(1u32))), &append(&ctor.args, &rest))
                },
                Pat::PtLit(l) => useful(env, st, &specialize_lit(rows, l), &drop(q, &Nat::from(1u32)), &rest),
                Pat::PtFam(f) => match ctors_of(env, st, &t1) {
                    Some(cs) => run_to_end(fold_job(filter(&cs, &(|c: &Ctor| &ctor_family(c) == f)), false, {
                        let env = env.clone();
                        let st = st.clone();
                        let rows = rows.clone();
                        let q = q.clone();
                        let rest = rest.clone();
                        Rc::new(move |(p0, p1): (bool, Ctor)| {
                            let env = env.clone();
                            let st = st.clone();
                            let rows = rows.clone();
                            let q = q.clone();
                            let rest = rest.clone();
                            entered(once_job(move || {
                                let seen = p0;
                                let c = p1;
                                prism_rtl::Turn::Finished(seen || useful(&env, &st, &specialize(&rows, &c), &append(&wilds(&c.arity), &drop(&q, &Nat::from(1u32))), &append(&c.args, &rest)))
                            }))
                        }) as Rc<dyn Fn((bool, Ctor)) -> Rc<dyn prism_rtl::Job<bool>>>
                    })),
                    None => useful(env, st, &default_rows(rows), &drop(q, &Nat::from(1u32)), &rest),
                },
                Pat::PtAny => {
                    let heads = head_names(rows);
                    match ctors_of(env, st, &t1) {
                        Some(cs) => if complete(&cs, &heads, rows) {
                            run_to_end(fold_job(cs.clone(), false, {
                                let env = env.clone();
                                let st = st.clone();
                                let rows = rows.clone();
                                let q = q.clone();
                                let rest = rest.clone();
                                Rc::new(move |(p0, p1): (bool, Ctor)| {
                                    let env = env.clone();
                                    let st = st.clone();
                                    let rows = rows.clone();
                                    let q = q.clone();
                                    let rest = rest.clone();
                                    entered(once_job(move || {
                                        let seen = p0;
                                        let c = p1;
                                        prism_rtl::Turn::Finished(seen || useful(&env, &st, &specialize(&rows, &c), &append(&wilds(&c.arity), &drop(&q, &Nat::from(1u32))), &append(&c.args, &rest)))
                                    }))
                                }) as Rc<dyn Fn((bool, Ctor)) -> Rc<dyn prism_rtl::Job<bool>>>
                            }))
                        } else {
                            useful(env, st, &default_rows(rows), &drop(q, &Nat::from(1u32)), &rest)
                        },
                        None => useful(env, st, &default_rows(rows), &drop(q, &Nat::from(1u32)), &rest),
                    }
                },
            }
        },
    }
}

/// The step machine of `Useful`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Useful: unbounded fn Env, St, [ [Pat] ], [Pat], [Ty] -> Bool
/// ```
pub struct Useful {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub rows: Array<Array<Pat>>,
    pub q: Array<Pat>,
    pub tys: Array<check_types::Ty>,
}

impl prism_rtl::Job<bool> for Useful {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let env = &self.env;
        let st = &self.st;
        let rows = &self.rows;
        let q = &self.q;
        let tys = &self.tys;
        match index(q, &Nat::from(0u32)) {
            None => prism_rtl::Turn::Finished(&len(rows) == &Nat::from(0u32)),
            Some(q1) => {
                let t1 = or(&index(tys, &Nat::from(0u32)), &check_types::Ty::TyErr);
                let rest = drop(tys, &Nat::from(1u32));
                match &q1 {
                    Pat::PtCon(c, args) => {
                        let args = args.clone();
                        let c = c.clone();
                        let env = env.clone();
                        let q = q.clone();
                        let rows = rows.clone();
                        let st = st.clone();
                        call_then(start_ctor_named(env.clone(), st.clone(), t1.clone(), c.clone(), len(&args)), move |ctor_named_7610: Ctor| {
                            let ctor = ctor_named_7610;
                            prism_rtl::Turn::More(Rc::new(Useful { env: env.clone(), st: st.clone(), rows: specialize(&rows, &ctor), q: append(&args, &drop(&q, &Nat::from(1u32))), tys: append(&ctor.args, &rest) }))
                        })
                    },
                    Pat::PtLit(l) => prism_rtl::Turn::More(Rc::new(Useful { env: env.clone(), st: st.clone(), rows: specialize_lit(rows, l), q: drop(q, &Nat::from(1u32)), tys: rest.clone() })),
                    Pat::PtFam(f) => {
                        let env = env.clone();
                        let f = f.clone();
                        let q = q.clone();
                        let rows = rows.clone();
                        let st = st.clone();
                        call_then(start_ctors_of(env.clone(), st.clone(), t1.clone()), move |ctors_of_7864: Option<Array<Ctor>>| match ctors_of_7864 {
                            Some(cs) => fold_job(filter(&cs, &(|c: &Ctor| &ctor_family(c) == &f)), false, {
                                let env = env.clone();
                                let st = st.clone();
                                let rows = rows.clone();
                                let q = q.clone();
                                let rest = rest.clone();
                                Rc::new(move |(p0, p1): (bool, Ctor)| {
                                    let env = env.clone();
                                    let st = st.clone();
                                    let rows = rows.clone();
                                    let q = q.clone();
                                    let rest = rest.clone();
                                    entered(once_job(move || {
                                        let seen = p0;
                                        let c = p1;
                                        prism_rtl::Turn::Finished(seen || useful(&env, &st, &specialize(&rows, &c), &append(&wilds(&c.arity), &drop(&q, &Nat::from(1u32))), &append(&c.args, &rest)))
                                    }))
                                }) as Rc<dyn Fn((bool, Ctor)) -> Rc<dyn prism_rtl::Job<bool>>>
                            }).cycle(),
                            None => prism_rtl::Turn::More(Rc::new(Useful { env: env.clone(), st: st.clone(), rows: default_rows(&rows), q: drop(&q, &Nat::from(1u32)), tys: rest.clone() })),
                        })
                    },
                    Pat::PtAny => {
                        let heads = head_names(rows);
                        let env = env.clone();
                        let q = q.clone();
                        let rows = rows.clone();
                        let st = st.clone();
                        call_then(start_ctors_of(env.clone(), st.clone(), t1.clone()), move |ctors_of_8236: Option<Array<Ctor>>| match ctors_of_8236 {
                            Some(cs) => if complete(&cs, &heads, &rows) {
                                fold_job(cs.clone(), false, {
                                    let env = env.clone();
                                    let st = st.clone();
                                    let rows = rows.clone();
                                    let q = q.clone();
                                    let rest = rest.clone();
                                    Rc::new(move |(p0, p1): (bool, Ctor)| {
                                        let env = env.clone();
                                        let st = st.clone();
                                        let rows = rows.clone();
                                        let q = q.clone();
                                        let rest = rest.clone();
                                        entered(once_job(move || {
                                            let seen = p0;
                                            let c = p1;
                                            prism_rtl::Turn::Finished(seen || useful(&env, &st, &specialize(&rows, &c), &append(&wilds(&c.arity), &drop(&q, &Nat::from(1u32))), &append(&c.args, &rest)))
                                        }))
                                    }) as Rc<dyn Fn((bool, Ctor)) -> Rc<dyn prism_rtl::Job<bool>>>
                                }).cycle()
                            } else {
                                prism_rtl::Turn::More(Rc::new(Useful { env: env.clone(), st: st.clone(), rows: default_rows(&rows), q: drop(&q, &Nat::from(1u32)), tys: rest.clone() }))
                            },
                            None => prism_rtl::Turn::More(Rc::new(Useful { env: env.clone(), st: st.clone(), rows: default_rows(&rows), q: drop(&q, &Nat::from(1u32)), tys: rest.clone() })),
                        })
                    },
                }
            },
        }
    }
}

/// `Start Useful, x`: what the function value is when passed to `@Run`.
pub fn start_useful(env: check_expr::Env, st: check_types::St, rows: Array<Array<Pat>>, q: Array<Pat>, tys: Array<check_types::Ty>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(Useful { env, st, rows, q, tys })
}

/// ```prism
/// CtorFamily: fn Ctor -> Text
/// ```
pub fn ctor_family(c: &Ctor) -> Text {
    if lexer::has_prefix(&c.name, &Text::from("tag:")) {
        check_env::dotted(&lexer::pop(&split(&lexer::drop_prefix(&c.name, &Text::from("tag:")), &Text::from("."))))
    } else {
        Text::from("")
    }
}

/// ```prism
/// Wilds: fn Nat -> [Pat]
/// ```
pub fn wilds(n: &Nat) -> Array<Pat> {
    each(&check_errors::range0(n), &(|_: &Nat| Pat::PtAny))
}

/// ```prism
/// CtorNamed: unbounded fn Env, St, Ty, Text, Nat -> Ctor
/// ```
pub fn ctor_named(env: &check_expr::Env, st: &check_types::St, t: &check_types::Ty, c: &Text, arity: &Nat) -> Ctor {
    match ctors_of(env, st, t) {
        Some(cs) => match find_ctor(&cs, c) {
            Some(found) => found.clone(),
            None => Ctor { name: c.clone(), arity: arity.clone(), args: each(&check_errors::range0(arity), &(|_: &Nat| check_types::Ty::TyErr)), shown: c.clone() },
        },
        None => Ctor { name: c.clone(), arity: arity.clone(), args: each(&check_errors::range0(arity), &(|_: &Nat| check_types::Ty::TyErr)), shown: c.clone() },
    }
}

/// The step machine of `CtorNamed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorNamed: unbounded fn Env, St, Ty, Text, Nat -> Ctor
/// ```
pub struct CtorNamed {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub t: check_types::Ty,
    pub c: Text,
    pub arity: Nat,
}

impl prism_rtl::Job<Ctor> for CtorNamed {
    fn cycle(&self) -> prism_rtl::Turn<Ctor> {
        let env = &self.env;
        let st = &self.st;
        let t = &self.t;
        let c = &self.c;
        let arity = &self.arity;
        let arity = arity.clone();
        let c = c.clone();
        let env = env.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(start_ctors_of(env.clone(), st.clone(), t.clone()), move |ctors_of_9031: Option<Array<Ctor>>| match ctors_of_9031 {
            Some(cs) => match find_ctor(&cs, &c) {
                Some(found) => prism_rtl::Turn::Finished(found.clone()),
                None => prism_rtl::Turn::Finished(Ctor { name: c.clone(), arity: arity.clone(), args: each(&check_errors::range0(&arity), &(|_: &Nat| check_types::Ty::TyErr)), shown: c.clone() }),
            },
            None => prism_rtl::Turn::Finished(Ctor { name: c.clone(), arity: arity.clone(), args: each(&check_errors::range0(&arity), &(|_: &Nat| check_types::Ty::TyErr)), shown: c.clone() }),
        })
    }
}

/// `Start CtorNamed, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_named(env: check_expr::Env, st: check_types::St, t: check_types::Ty, c: Text, arity: Nat) -> Rc<dyn prism_rtl::Job<Ctor>> {
    Rc::new(CtorNamed { env, st, t, c, arity })
}

/// ```prism
/// ?FindCtor: fn [Ctor], Text -> ?Ctor
/// ```
pub fn find_ctor(cs: &Array<Ctor>, c: &Text) -> Option<Ctor> {
    fold(cs, &None, &(|found_opt: &Option<Ctor>, x: &Ctor| match found_opt {
        Some(f) => Some(f.clone()),
        None => if (&x.name == c) || (&check_types::bare_name(&x.name) == &check_types::bare_name(c)) {
            Some(x.clone())
        } else {
            None
        },
    }))
}

/// ```prism
/// Specialize: fn [ [Pat] ], Ctor -> [ [Pat] ]
/// ```
pub fn specialize(rows: &Array<Array<Pat>>, c: &Ctor) -> Array<Array<Pat>> {
    fold(rows, &Array::new(), &(|acc: &Array<Array<Pat>>, prow: &Array<Pat>| match index(prow, &Nat::from(0u32)) {
        Some(Pat::PtCon(d, args)) => if (&d == &c.name) || (&check_types::bare_name(&d) == &check_types::bare_name(&c.name)) {
            push(acc, &append(&pad(&args, &c.arity), &drop(prow, &Nat::from(1u32))))
        } else {
            acc.clone()
        },
        Some(Pat::PtAny) => push(acc, &append(&wilds(&c.arity), &drop(prow, &Nat::from(1u32)))),
        Some(Pat::PtFam(f)) => if &ctor_family(c) == &f {
            push(acc, &append(&wilds(&c.arity), &drop(prow, &Nat::from(1u32))))
        } else {
            acc.clone()
        },
        _ => acc.clone(),
    }))
}

/// ```prism
/// Pad: fn [Pat], Nat -> [Pat]
/// ```
pub fn pad(args: &Array<Pat>, n: &Nat) -> Array<Pat> {
    if &len(args) >= n {
        take(args, n)
    } else {
        append(args, &wilds(&or(&n.checked_sub(&len(args)), &Nat::from(0u32))))
    }
}

/// ```prism
/// SpecializeLit: fn [ [Pat] ], Text -> [ [Pat] ]
/// ```
pub fn specialize_lit(rows: &Array<Array<Pat>>, l: &Text) -> Array<Array<Pat>> {
    fold(rows, &Array::new(), &(|acc: &Array<Array<Pat>>, prow: &Array<Pat>| match index(prow, &Nat::from(0u32)) {
        Some(Pat::PtLit(m)) => if &m == l { push(acc, &drop(prow, &Nat::from(1u32))) } else { acc.clone() },
        Some(Pat::PtAny) => push(acc, &drop(prow, &Nat::from(1u32))),
        _ => acc.clone(),
    }))
}

/// ```prism
/// DefaultRows: fn [ [Pat] ] -> [ [Pat] ]
/// ```
pub fn default_rows(rows: &Array<Array<Pat>>) -> Array<Array<Pat>> {
    fold(rows, &Array::new(), &(|acc: &Array<Array<Pat>>, prow: &Array<Pat>| match index(prow, &Nat::from(0u32)) {
        Some(Pat::PtAny) => push(acc, &drop(prow, &Nat::from(1u32))),
        _ => acc.clone(),
    }))
}

/// ```prism
/// HeadNames: fn [ [Pat] ] -> [Text]
/// ```
pub fn head_names(rows: &Array<Array<Pat>>) -> Array<Text> {
    fold(rows, &Array::new(), &(|acc: &Array<Text>, prow: &Array<Pat>| match index(prow, &Nat::from(0u32)) {
        Some(Pat::PtCon(c, _)) => check_types::add_text(acc, &c),
        Some(Pat::PtFam(f)) => check_types::add_text(acc, &Text::from(format!("fam:{}", &f))),
        _ => acc.clone(),
    }))
}

/// ```prism
/// Complete: fn [Ctor], [Text], [ [Pat] ] -> Bool
/// ```
pub fn complete(cs: &Array<Ctor>, heads: &Array<Text>, rows: &Array<Array<Pat>>) -> bool {
    (&len(cs) > &Nat::from(0u32)) && fold(cs, &true, &(|ok: &bool, c: &Ctor| *ok && ((check_types::has_text(heads, &c.name) || check_types::has_text(&each(heads, &(|h: &Text| check_types::bare_name(h))), &check_types::bare_name(&c.name))) || check_types::has_text(heads, &Text::from(format!("fam:{}", &ctor_family(c)))))))
}

/// ```prism
/// ?Witness: unbounded fn Env, St, [ [Pat] ], [Ty] -> ?[Text]
/// ```
pub fn witness(env: &check_expr::Env, st: &check_types::St, rows: &Array<Array<Pat>>, tys: &Array<check_types::Ty>) -> Option<Array<Text>> {
    match index(tys, &Nat::from(0u32)) {
        None => if &len(rows) == &Nat::from(0u32) { Some(Array::new()) } else { None },
        Some(t1) => {
            let rest = drop(tys, &Nat::from(1u32));
            let heads = head_names(rows);
            match ctors_of(env, st, &t1) {
                Some(cs) => if complete(&cs, &heads, rows) {
                    run_to_end(fold_job(cs.clone(), None, {
                        let env = env.clone();
                        let st = st.clone();
                        let rows = rows.clone();
                        let rest = rest.clone();
                        Rc::new(move |(p0, p1): (Option<Array<Text>>, Ctor)| {
                            let env = env.clone();
                            let st = st.clone();
                            let rows = rows.clone();
                            let rest = rest.clone();
                            entered(once_job(move || {
                                let found_opt = p0;
                                let c = p1;
                                match &found_opt {
                                    Some(f) => prism_rtl::Turn::Finished(Some(f.clone())),
                                    None => call_then(start_witness(env.clone(), st.clone(), specialize(&rows, &c), append(&c.args, &rest)), move |witness_11607: Option<Array<Text>>| match witness_11607 {
                                        Some(w) => prism_rtl::Turn::Finished(Some(append(&Array::from(vec![show_witness(&c, &take(&w, &c.arity))]), &drop(&w, &c.arity)))),
                                        None => prism_rtl::Turn::Finished(None),
                                    }),
                                }
                            }))
                        }) as Rc<dyn Fn((Option<Array<Text>>, Ctor)) -> Rc<dyn prism_rtl::Job<Option<Array<Text>>>>>
                    }))
                } else {
                    match witness(env, st, &default_rows(rows), &rest) {
                        Some(w) => {
                            let missing = filter(&cs, &(|c: &Ctor| !(check_types::has_text(&heads, &c.name) || check_types::has_text(&heads, &Text::from(format!("fam:{}", &ctor_family(c)))))));
                            let shown = match index(&missing, &Nat::from(0u32)) {
                                Some(c) => c.shown.clone(),
                                None => Text::from("_"),
                            };
                            Some(append(&Array::from(vec![shown.clone()]), &w))
                        },
                        None => None,
                    }
                },
                None => match witness(env, st, &default_rows(rows), &rest) {
                    Some(w) => Some(append(&Array::from(vec![Text::from("_")]), &w)),
                    None => None,
                },
            }
        },
    }
}

/// The step machine of `Witness`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?Witness: unbounded fn Env, St, [ [Pat] ], [Ty] -> ?[Text]
/// ```
pub struct Witness {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub rows: Array<Array<Pat>>,
    pub tys: Array<check_types::Ty>,
}

impl prism_rtl::Job<Option<Array<Text>>> for Witness {
    fn cycle(&self) -> prism_rtl::Turn<Option<Array<Text>>> {
        let env = &self.env;
        let st = &self.st;
        let rows = &self.rows;
        let tys = &self.tys;
        match index(tys, &Nat::from(0u32)) {
            None => if &len(rows) == &Nat::from(0u32) {
                prism_rtl::Turn::Finished(Some(Array::new()))
            } else {
                prism_rtl::Turn::Finished(None)
            },
            Some(t1) => {
                let rest = drop(tys, &Nat::from(1u32));
                let heads = head_names(rows);
                let env = env.clone();
                let rows = rows.clone();
                let st = st.clone();
                call_then(start_ctors_of(env.clone(), st.clone(), t1.clone()), move |ctors_of_11393: Option<Array<Ctor>>| match ctors_of_11393 {
                    Some(cs) => if complete(&cs, &heads, &rows) {
                        fold_job(cs.clone(), None, {
                            let env = env.clone();
                            let st = st.clone();
                            let rows = rows.clone();
                            let rest = rest.clone();
                            Rc::new(move |(p0, p1): (Option<Array<Text>>, Ctor)| {
                                let env = env.clone();
                                let st = st.clone();
                                let rows = rows.clone();
                                let rest = rest.clone();
                                entered(once_job(move || {
                                    let found_opt = p0;
                                    let c = p1;
                                    match &found_opt {
                                        Some(f) => prism_rtl::Turn::Finished(Some(f.clone())),
                                        None => call_then(start_witness(env.clone(), st.clone(), specialize(&rows, &c), append(&c.args, &rest)), move |witness_11607: Option<Array<Text>>| match witness_11607 {
                                            Some(w) => prism_rtl::Turn::Finished(Some(append(&Array::from(vec![show_witness(&c, &take(&w, &c.arity))]), &drop(&w, &c.arity)))),
                                            None => prism_rtl::Turn::Finished(None),
                                        }),
                                    }
                                }))
                            }) as Rc<dyn Fn((Option<Array<Text>>, Ctor)) -> Rc<dyn prism_rtl::Job<Option<Array<Text>>>>>
                        }).cycle()
                    } else {
                        call_then(start_witness(env.clone(), st.clone(), default_rows(&rows), rest.clone()), move |witness_11837: Option<Array<Text>>| match witness_11837 {
                            Some(w) => {
                                let missing = filter(&cs, &(|c: &Ctor| !(check_types::has_text(&heads, &c.name) || check_types::has_text(&heads, &Text::from(format!("fam:{}", &ctor_family(c)))))));
                                let shown = match index(&missing, &Nat::from(0u32)) {
                                    Some(c) => c.shown.clone(),
                                    None => Text::from("_"),
                                };
                                prism_rtl::Turn::Finished(Some(append(&Array::from(vec![shown.clone()]), &w)))
                            },
                            None => prism_rtl::Turn::Finished(None),
                        })
                    },
                    None => call_then(start_witness(env.clone(), st.clone(), default_rows(&rows), rest.clone()), move |witness_12263: Option<Array<Text>>| match witness_12263 {
                        Some(w) => prism_rtl::Turn::Finished(Some(append(&Array::from(vec![Text::from("_")]), &w))),
                        None => prism_rtl::Turn::Finished(None),
                    }),
                })
            },
        }
    }
}

/// `Start Witness, x`: what the function value is when passed to `@Run`.
pub fn start_witness(env: check_expr::Env, st: check_types::St, rows: Array<Array<Pat>>, tys: Array<check_types::Ty>) -> Rc<dyn prism_rtl::Job<Option<Array<Text>>>> {
    Rc::new(Witness { env, st, rows, tys })
}

/// ```prism
/// ShowWitness: fn Ctor, [Text] -> Text
/// ```
pub fn show_witness(c: &Ctor, args: &Array<Text>) -> Text {
    if &c.name == &Text::from("?") {
        Text::from(format!("? {}", &or(&index(args, &Nat::from(0u32)), &Text::from("_"))))
    } else {
        if &c.name == &Text::from("~") {
            Text::from(format!("~ {}", &or(&index(args, &Nat::from(0u32)), &Text::from("_"))))
        } else {
            if &c.name == &Text::from("tuple") {
                Text::from(format!("(({}))", &lexer::join(args, &Text::from(", "))))
            } else {
                if (&len(args) == &Nat::from(0u32)) || fold(args, &true, &(|ok: &bool, a: &Text| *ok && (a == &Text::from("_")))) {
                    c.shown.clone()
                } else {
                    Text::from(format!("{} {}", &check_types::bare_name(&c.name), &lexer::join(args, &Text::from(", "))))
                }
            }
        }
    }
}

/// ```prism
/// MatchCoverage: unbounded fn Env, St, Ty, [Arm], Range -> St
/// ```
pub fn match_coverage(env: &check_expr::Env, st: &check_types::St, t: &check_types::Ty, arms: &Array<ast::Arm>, span: &ast::Range) -> check_types::St {
    let has_otherwise = fold(arms, &false, &(|seen: &bool, a: &ast::Arm| *seen || (&a.pattern == &None)));
    let tys = Array::from(vec![t.clone()]);
    let (rows, st2) = run_to_end(fold_job(arms.clone(), (Array::new(), st.clone()), {
        let env = env.clone();
        let tys = tys.clone();
        let t = t.clone();
        Rc::new(move |(p0, p1): ((Array<Array<Pat>>, check_types::St), ast::Arm)| {
            let env = env.clone();
            let tys = tys.clone();
            let t = t.clone();
            entered(once_job(move || {
                let (acc, s) = p0;
                let arm = p1;
                {
                    let q = match &arm.pattern {
                        Some(p_) => Array::from(vec![to_pat(&env, p_)]),
                        None => Array::from(vec![Pat::PtAny]),
                    };
                    call_then(start_useful(env.clone(), s.clone(), acc.clone(), q.clone(), tys.clone()), move |useful_13349: bool| {
                        let reachable = useful_13349;
                        call_then(start_owns_row(env.clone(), s.clone(), t.clone()), move |owns_row_13398: bool| {
                            let owns_all = owns_row_13398;
                            let s2 = if reachable {
                                s.clone()
                            } else {
                                if (&arm.pattern == &None) && !owns_all {
                                    s.clone()
                                } else {
                                    check_types::err_fix(&s, &Text::from("unreachable"), &arm_span(&arm), &Text::from("this arm is never reached"), &Text::from("remove it, or put it above the arm that covers it"))
                                }
                            };
                            let acc2 = if &arm.guard == &None { push(&acc, &q) } else { acc.clone() };
                            prism_rtl::Turn::Finished((acc2.clone(), s2.clone()))
                        })
                    })
                }
            }))
        }) as Rc<dyn Fn(((Array<Array<Pat>>, check_types::St), ast::Arm)) -> Rc<dyn prism_rtl::Job<(Array<Array<Pat>>, check_types::St)>>>
    }));
    if has_otherwise {
        st2.clone()
    } else {
        if is_open_row(env, &st2, t) {
            check_types::err_fix(&st2, &Text::from("row-not-closed"), span, &Text::from(format!("a match over `{}` needs `otherwise:`", &check_types::show_ty(&st2, t))), &Text::from("add an `otherwise:` arm: the row's variable may hold tags this match cannot name"))
        } else {
            match witness(env, &st2, &rows, &tys) {
                Some(w) => check_types::err_fix(&st2, &Text::from("not-exhaustive"), span, &Text::from(format!("this match misses `{}`", &lexer::join(&w, &Text::from(", ")))), &Text::from("add an arm for it, or `otherwise:`")),
                None => st2.clone(),
            }
        }
    }
}

/// The step machine of `MatchCoverage`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MatchCoverage: unbounded fn Env, St, Ty, [Arm], Range -> St
/// ```
pub struct MatchCoverage {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub t: check_types::Ty,
    pub arms: Array<ast::Arm>,
    pub span: ast::Range,
}

impl prism_rtl::Job<check_types::St> for MatchCoverage {
    fn cycle(&self) -> prism_rtl::Turn<check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let t = &self.t;
        let arms = &self.arms;
        let span = &self.span;
        let has_otherwise = fold(arms, &false, &(|seen: &bool, a: &ast::Arm| *seen || (&a.pattern == &None)));
        let tys = Array::from(vec![t.clone()]);
        let arms = arms.clone();
        let env = env.clone();
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        call_value(fold_job(arms.clone(), (Array::new(), st.clone()), {
            let env = env.clone();
            let tys = tys.clone();
            let t = t.clone();
            Rc::new(move |(p0, p1): ((Array<Array<Pat>>, check_types::St), ast::Arm)| {
                let env = env.clone();
                let tys = tys.clone();
                let t = t.clone();
                entered(once_job(move || {
                    let (acc, s) = p0;
                    let arm = p1;
                    {
                        let q = match &arm.pattern {
                            Some(p_) => Array::from(vec![to_pat(&env, p_)]),
                            None => Array::from(vec![Pat::PtAny]),
                        };
                        call_then(start_useful(env.clone(), s.clone(), acc.clone(), q.clone(), tys.clone()), move |useful_13349: bool| {
                            let reachable = useful_13349;
                            call_then(start_owns_row(env.clone(), s.clone(), t.clone()), move |owns_row_13398: bool| {
                                let owns_all = owns_row_13398;
                                let s2 = if reachable {
                                    s.clone()
                                } else {
                                    if (&arm.pattern == &None) && !owns_all {
                                        s.clone()
                                    } else {
                                        check_types::err_fix(&s, &Text::from("unreachable"), &arm_span(&arm), &Text::from("this arm is never reached"), &Text::from("remove it, or put it above the arm that covers it"))
                                    }
                                };
                                let acc2 = if &arm.guard == &None { push(&acc, &q) } else { acc.clone() };
                                prism_rtl::Turn::Finished((acc2.clone(), s2.clone()))
                            })
                        })
                    }
                }))
            }) as Rc<dyn Fn(((Array<Array<Pat>>, check_types::St), ast::Arm)) -> Rc<dyn prism_rtl::Job<(Array<Array<Pat>>, check_types::St)>>>
        }), move |fold_13182: (Array<Array<Pat>>, check_types::St)| {
            let (rows, st2) = fold_13182;
            if has_otherwise {
                prism_rtl::Turn::Finished(st2.clone())
            } else {
                call_then(start_is_open_row(env.clone(), st2.clone(), t.clone()), move |is_open_row_13746: bool| if is_open_row_13746 {
                    call_then(check_types::start_show_ty(st2.clone(), t.clone()), move |show_ty_13821: Text| prism_rtl::Turn::Finished(check_types::err_fix(&st2, &Text::from("row-not-closed"), &span, &Text::from(format!("a match over `{}` needs `otherwise:`", &show_ty_13821)), &Text::from("add an `otherwise:` arm: the row's variable may hold tags this match cannot name"))))
                } else {
                    call_then(start_witness(env.clone(), st2.clone(), rows.clone(), tys.clone()), move |witness_13957: Option<Array<Text>>| match witness_13957 {
                        Some(w) => prism_rtl::Turn::Finished(check_types::err_fix(&st2, &Text::from("not-exhaustive"), &span, &Text::from(format!("this match misses `{}`", &lexer::join(&w, &Text::from(", ")))), &Text::from("add an arm for it, or `otherwise:`"))),
                        None => prism_rtl::Turn::Finished(st2.clone()),
                    })
                })
            }
        })
    }
}

/// `Start MatchCoverage, x`: what the function value is when passed to `@Run`.
pub fn start_match_coverage(env: check_expr::Env, st: check_types::St, t: check_types::Ty, arms: Array<ast::Arm>, span: ast::Range) -> Rc<dyn prism_rtl::Job<check_types::St>> {
    Rc::new(MatchCoverage { env, st, t, arms, span })
}

/// ```prism
/// ArmSpan: fn Arm -> Range
/// ```
pub fn arm_span(a: &ast::Arm) -> ast::Range {
    match &a.pattern {
        Some(p_) => p_.span.clone(),
        None => a.span.clone(),
    }
}

/// ```prism
/// IsOpenRow: unbounded fn Env, St, Ty -> Bool
/// ```
pub fn is_open_row(env: &check_expr::Env, st: &check_types::St, t: &check_types::Ty) -> bool {
    match check_types::walk(st, t) {
        check_types::Ty::TyElem(rw, _) => &check_types::walk_row(st, &rw).tail != &check_types::Tail::TlClosed,
        check_types::Ty::TyElemAny(rw) => &check_types::walk_row(st, &rw).tail != &check_types::Tail::TlClosed,
        check_types::Ty::TyCon(n, m14379_2_1) if ((&m14379_2_1).len() == 0) => match get(&env.g.types, &n) {
            Some(ti) => (&ti.body == &check_env::TyBody::BRowKind) && !is_root_module(env),
            None => ((&n == &Text::from("Fault")) || (&n == &Text::from("Prelude.Fault"))) && !is_root_module(env),
        },
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `IsOpenRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsOpenRow: unbounded fn Env, St, Ty -> Bool
/// ```
pub struct IsOpenRow {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub t: check_types::Ty,
}

impl prism_rtl::Job<bool> for IsOpenRow {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let env = &self.env;
        let st = &self.st;
        let t = &self.t;
        let env = env.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(check_types::start_walk(st.clone(), t.clone()), move |walk_14385: check_types::Ty| match walk_14385 {
            check_types::Ty::TyElem(rw, _) => call_then(check_types::start_walk_row(st.clone(), rw.clone()), move |walk_row_14421: check_types::Rw| prism_rtl::Turn::Finished(&walk_row_14421.tail != &check_types::Tail::TlClosed)),
            check_types::Ty::TyElemAny(rw) => call_then(check_types::start_walk_row(st.clone(), rw.clone()), move |walk_row_14473: check_types::Rw| prism_rtl::Turn::Finished(&walk_row_14473.tail != &check_types::Tail::TlClosed)),
            check_types::Ty::TyCon(n, m14379_2_1) if ((&m14379_2_1).len() == 0) => match get(&env.g.types, &n) {
                Some(ti) => prism_rtl::Turn::Finished((&ti.body == &check_env::TyBody::BRowKind) && !is_root_module(&env)),
                None => prism_rtl::Turn::Finished(((&n == &Text::from("Fault")) || (&n == &Text::from("Prelude.Fault"))) && !is_root_module(&env)),
            },
            _ => prism_rtl::Turn::Finished(false),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start IsOpenRow, x`: what the function value is when passed to `@Run`.
pub fn start_is_open_row(env: check_expr::Env, st: check_types::St, t: check_types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsOpenRow { env, st, t })
}

/// ```prism
/// OwnsRow: unbounded fn Env, St, Ty -> Bool
/// ```
pub fn owns_row(env: &check_expr::Env, st: &check_types::St, t: &check_types::Ty) -> bool {
    match check_types::walk(st, t) {
        check_types::Ty::TyElem(rw, _) => fold(&check_types::walk_row(st, &rw).fams, &true, &(|ok: &bool, f: &Text| *ok && (&or(&get(&env.g.fam_owner, f), &Text::from("")) == &env.home))),
        check_types::Ty::TyCon(n, m14848_1_1) if ((&m14848_1_1).len() == 0) => match get(&env.g.types, &n) {
            Some(ti) => &ti.body != &check_env::TyBody::BRowKind,
            None => !((&n == &Text::from("Fault")) || (&n == &Text::from("Prelude.Fault"))),
        },
        _ => true,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `OwnsRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OwnsRow: unbounded fn Env, St, Ty -> Bool
/// ```
pub struct OwnsRow {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub t: check_types::Ty,
}

impl prism_rtl::Job<bool> for OwnsRow {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let env = &self.env;
        let st = &self.st;
        let t = &self.t;
        let env = env.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(check_types::start_walk(st.clone(), t.clone()), move |walk_14854: check_types::Ty| match walk_14854 {
            check_types::Ty::TyElem(rw, _) => call_then(check_types::start_walk_row(st.clone(), rw.clone()), move |walk_row_14895: check_types::Rw| prism_rtl::Turn::Finished(fold(&walk_row_14895.fams, &true, &(|ok: &bool, f: &Text| *ok && (&or(&get(&env.g.fam_owner, f), &Text::from("")) == &env.home))))),
            check_types::Ty::TyCon(n, m14848_1_1) if ((&m14848_1_1).len() == 0) => match get(&env.g.types, &n) {
                Some(ti) => prism_rtl::Turn::Finished(&ti.body != &check_env::TyBody::BRowKind),
                None => prism_rtl::Turn::Finished(!((&n == &Text::from("Fault")) || (&n == &Text::from("Prelude.Fault")))),
            },
            _ => prism_rtl::Turn::Finished(true),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start OwnsRow, x`: what the function value is when passed to `@Run`.
pub fn start_owns_row(env: check_expr::Env, st: check_types::St, t: check_types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(OwnsRow { env, st, t })
}

/// ```prism
/// ClauseCoverage: unbounded fn Env, St, [FnClause], [Ty], Range -> St
/// ```
pub fn clause_coverage(env: &check_expr::Env, st: &check_types::St, clauses: &Array<ast::FnClause>, params: &Array<check_types::Ty>, span: &ast::Range) -> check_types::St {
    let (rows, st2) = run_to_end(fold_job(clauses.clone(), (Array::new(), st.clone()), {
        let env = env.clone();
        let params = params.clone();
        Rc::new(move |(p0, p1): ((Array<Array<Pat>>, check_types::St), ast::FnClause)| {
            let env = env.clone();
            let params = params.clone();
            entered(once_job(move || {
                let (acc, s) = p0;
                let c = p1;
                call_value(each_job(c.params.clone(), {
                    let env = env.clone();
                    Rc::new(move |p0: ast::Pattern_| {
                        let env = env.clone();
                        entered(once_job(move || {
                            let p_ = p0;
                            prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: p_.clone() }))
                        }))
                    }) as Rc<dyn Fn(ast::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
                }), move |each_15391: Array<Pat>| {
                    let q = each_15391;
                    let reachable = (&len(&q) != &len(&params)) || useful(&env, &s, &acc, &q, &params);
                    let s2 = if reachable {
                        s.clone()
                    } else {
                        check_types::err_fix(&s, &Text::from("unreachable"), &c.span, &Text::from("this clause is never reached"), &Text::from("remove it, or put it above the clause that covers it"))
                    };
                    prism_rtl::Turn::Finished((push(&acc, &q), s2.clone()))
                })
            }))
        }) as Rc<dyn Fn(((Array<Array<Pat>>, check_types::St), ast::FnClause)) -> Rc<dyn prism_rtl::Job<(Array<Array<Pat>>, check_types::St)>>>
    }));
    if &len(params) == &Nat::from(0u32) {
        st2.clone()
    } else {
        match witness(env, &st2, &rows, params) {
            Some(w) => check_types::err_fix(&st2, &Text::from("not-exhaustive"), span, &Text::from(format!("these clauses miss `{}`", &lexer::join(&w, &Text::from(", ")))), &Text::from("add a clause for it")),
            None => st2.clone(),
        }
    }
}

/// The step machine of `ClauseCoverage`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseCoverage: unbounded fn Env, St, [FnClause], [Ty], Range -> St
/// ```
pub struct ClauseCoverage {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub clauses: Array<ast::FnClause>,
    pub params: Array<check_types::Ty>,
    pub span: ast::Range,
}

impl prism_rtl::Job<check_types::St> for ClauseCoverage {
    fn cycle(&self) -> prism_rtl::Turn<check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let clauses = &self.clauses;
        let params = &self.params;
        let span = &self.span;
        let clauses = clauses.clone();
        let env = env.clone();
        let params = params.clone();
        let span = span.clone();
        let st = st.clone();
        call_value(fold_job(clauses.clone(), (Array::new(), st.clone()), {
            let env = env.clone();
            let params = params.clone();
            Rc::new(move |(p0, p1): ((Array<Array<Pat>>, check_types::St), ast::FnClause)| {
                let env = env.clone();
                let params = params.clone();
                entered(once_job(move || {
                    let (acc, s) = p0;
                    let c = p1;
                    call_value(each_job(c.params.clone(), {
                        let env = env.clone();
                        Rc::new(move |p0: ast::Pattern_| {
                            let env = env.clone();
                            entered(once_job(move || {
                                let p_ = p0;
                                prism_rtl::Turn::More(Rc::new(ToPat { env: env.clone(), p_: p_.clone() }))
                            }))
                        }) as Rc<dyn Fn(ast::Pattern_) -> Rc<dyn prism_rtl::Job<Pat>>>
                    }), move |each_15391: Array<Pat>| {
                        let q = each_15391;
                        let reachable = (&len(&q) != &len(&params)) || useful(&env, &s, &acc, &q, &params);
                        let s2 = if reachable {
                            s.clone()
                        } else {
                            check_types::err_fix(&s, &Text::from("unreachable"), &c.span, &Text::from("this clause is never reached"), &Text::from("remove it, or put it above the clause that covers it"))
                        };
                        prism_rtl::Turn::Finished((push(&acc, &q), s2.clone()))
                    })
                }))
            }) as Rc<dyn Fn(((Array<Array<Pat>>, check_types::St), ast::FnClause)) -> Rc<dyn prism_rtl::Job<(Array<Array<Pat>>, check_types::St)>>>
        }), move |fold_15330: (Array<Array<Pat>>, check_types::St)| {
            let (rows, st2) = fold_15330;
            if &len(&params) == &Nat::from(0u32) {
                prism_rtl::Turn::Finished(st2.clone())
            } else {
                call_then(start_witness(env.clone(), st2.clone(), rows.clone(), params.clone()), move |witness_15740: Option<Array<Text>>| match witness_15740 {
                    Some(w) => prism_rtl::Turn::Finished(check_types::err_fix(&st2, &Text::from("not-exhaustive"), &span, &Text::from(format!("these clauses miss `{}`", &lexer::join(&w, &Text::from(", ")))), &Text::from("add a clause for it"))),
                    None => prism_rtl::Turn::Finished(st2.clone()),
                })
            }
        })
    }
}

/// `Start ClauseCoverage, x`: what the function value is when passed to `@Run`.
pub fn start_clause_coverage(env: check_expr::Env, st: check_types::St, clauses: Array<ast::FnClause>, params: Array<check_types::Ty>, span: ast::Range) -> Rc<dyn prism_rtl::Job<check_types::St>> {
    Rc::new(ClauseCoverage { env, st, clauses, params, span })
}

/// ```prism
/// IsDelayedWidget: fn Text -> Bool
/// ```
pub fn is_delayed_widget(n: &Text) -> bool {
    check_types::has_text(&Array::from(vec![Text::from("@Defer"), Text::from("@Later"), Text::from("@Run"), Text::from("@Machine"), Text::from("@started")]), n)
}

/// ```prism
/// BlockPromptCycles: unbounded fn Env, St, Block -> St
/// ```
pub fn block_prompt_cycles(env: &check_expr::Env, st: &check_types::St, b: &ast::Block) -> check_types::St {
    let defs = run_to_end(fold_job(b.stmts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, ast::Stmt)| entered(once_job(move || {
        let acc = p0;
        let s = p1;
        call_then(start_stmt_defs(s.clone()), move |stmt_defs_17015: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &stmt_defs_17015)))
    }))) as Rc<dyn Fn((Array<Text>, ast::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    let cx_ = PCx { g: env.g.clone(), home: env.home.clone(), lams: let_lambdas(&b.stmts), base: prompt_base(env, &b.stmts) };
    let edges_ = run_to_end(fold_job(b.stmts.clone(), Array::new(), {
        let env = env.clone();
        let st = st.clone();
        let cx_ = cx_.clone();
        let defs = defs.clone();
        Rc::new(move |(p0, p1): (Array<(Text, Text)>, ast::Stmt)| {
            let env = env.clone();
            let st = st.clone();
            let cx_ = cx_.clone();
            let defs = defs.clone();
            entered(once_job(move || {
                let acc = p0;
                let s = p1;
                call_then(start_prompt_edges(env.clone(), st.clone(), cx_.clone(), s.clone(), defs.clone()), move |prompt_edges_17186: Array<(Text, Text)>| prism_rtl::Turn::Finished(append(&acc, &prompt_edges_17186)))
            }))
        }) as Rc<dyn Fn((Array<(Text, Text)>, ast::Stmt)) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>>>
    }));
    let cyc = find_cycle(&defs, &edges_);
    if &len(&cyc) == &Nat::from(0u32) {
        st.clone()
    } else {
        {
            let span = run_to_end(fold_job(b.stmts.clone(), b.span.clone(), {
                let cyc = cyc.clone();
                Rc::new(move |(p0, p1): (ast::Range, ast::Stmt)| {
                    let cyc = cyc.clone();
                    entered(once_job(move || {
                        let sp = p0;
                        let s = p1;
                        call_then(start_stmt_defs(s.clone()), move |stmt_defs_17354: Array<Text>| if check_types::has_text(&stmt_defs_17354, &or(&index(&cyc, &Nat::from(0u32)), &Text::from(""))) {
                            prism_rtl::Turn::Finished(s.span.clone())
                        } else {
                            prism_rtl::Turn::Finished(sp.clone())
                        })
                    }))
                }) as Rc<dyn Fn((ast::Range, ast::Stmt)) -> Rc<dyn prism_rtl::Job<ast::Range>>>
            }));
            check_types::err_fix(st, &Text::from("prompt-cycle"), &span, &Text::from(format!("a prompt cycle: {}", &lexer::join(&each(&cyc, &(|n: &Text| Text::from(format!("`{}`", n)))), &Text::from(", ")))), &Text::from("break it with a hold: `$last <- start then ...` reads the value as the tick opened"))
        }
    }
}

/// The step machine of `BlockPromptCycles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockPromptCycles: unbounded fn Env, St, Block -> St
/// ```
pub struct BlockPromptCycles {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub b: ast::Block,
}

impl prism_rtl::Job<check_types::St> for BlockPromptCycles {
    fn cycle(&self) -> prism_rtl::Turn<check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let b = &self.b;
        let b = b.clone();
        let env = env.clone();
        let st = st.clone();
        call_value(fold_job(b.stmts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, ast::Stmt)| entered(once_job(move || {
            let acc = p0;
            let s = p1;
            call_then(start_stmt_defs(s.clone()), move |stmt_defs_17015: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &stmt_defs_17015)))
        }))) as Rc<dyn Fn((Array<Text>, ast::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_16972: Array<Text>| {
            let defs = fold_16972;
            call_then(start_let_lambdas(b.stmts.clone()), move |let_lambdas_17074: Map<Nat, ast::Expr>| call_then(start_prompt_base(env.clone(), b.stmts.clone()), move |prompt_base_17101: Map<Text, Rel>| {
                let cx_ = PCx { g: env.g.clone(), home: env.home.clone(), lams: let_lambdas_17074, base: prompt_base_17101 };
                call_value(fold_job(b.stmts.clone(), Array::new(), {
                    let env = env.clone();
                    let st = st.clone();
                    let cx_ = cx_.clone();
                    let defs = defs.clone();
                    Rc::new(move |(p0, p1): (Array<(Text, Text)>, ast::Stmt)| {
                        let env = env.clone();
                        let st = st.clone();
                        let cx_ = cx_.clone();
                        let defs = defs.clone();
                        entered(once_job(move || {
                            let acc = p0;
                            let s = p1;
                            call_then(start_prompt_edges(env.clone(), st.clone(), cx_.clone(), s.clone(), defs.clone()), move |prompt_edges_17186: Array<(Text, Text)>| prism_rtl::Turn::Finished(append(&acc, &prompt_edges_17186)))
                        }))
                    }) as Rc<dyn Fn((Array<(Text, Text)>, ast::Stmt)) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>>>
                }), move |fold_17143: Array<(Text, Text)>| {
                    let edges_ = fold_17143;
                    call_then(start_find_cycle(defs.clone(), edges_.clone()), move |find_cycle_17234: Array<Text>| {
                        let cyc = find_cycle_17234;
                        if &len(&cyc) == &Nat::from(0u32) {
                            prism_rtl::Turn::Finished(st.clone())
                        } else {
                            call_value(fold_job(b.stmts.clone(), b.span.clone(), {
                                let cyc = cyc.clone();
                                Rc::new(move |(p0, p1): (ast::Range, ast::Stmt)| {
                                    let cyc = cyc.clone();
                                    entered(once_job(move || {
                                        let sp = p0;
                                        let s = p1;
                                        call_then(start_stmt_defs(s.clone()), move |stmt_defs_17354: Array<Text>| if check_types::has_text(&stmt_defs_17354, &or(&index(&cyc, &Nat::from(0u32)), &Text::from(""))) {
                                            prism_rtl::Turn::Finished(s.span.clone())
                                        } else {
                                            prism_rtl::Turn::Finished(sp.clone())
                                        })
                                    }))
                                }) as Rc<dyn Fn((ast::Range, ast::Stmt)) -> Rc<dyn prism_rtl::Job<ast::Range>>>
                            }), move |fold_17311: ast::Range| {
                                let span = fold_17311;
                                prism_rtl::Turn::Finished(check_types::err_fix(&st, &Text::from("prompt-cycle"), &span, &Text::from(format!("a prompt cycle: {}", &lexer::join(&each(&cyc, &(|n: &Text| Text::from(format!("`{}`", n)))), &Text::from(", ")))), &Text::from("break it with a hold: `$last <- start then ...` reads the value as the tick opened")))
                            })
                        }
                    })
                })
            }))
        })
    }
}

/// `Start BlockPromptCycles, x`: what the function value is when passed to `@Run`.
pub fn start_block_prompt_cycles(env: check_expr::Env, st: check_types::St, b: ast::Block) -> Rc<dyn prism_rtl::Job<check_types::St>> {
    Rc::new(BlockPromptCycles { env, st, b })
}

/// ```prism
/// StmtDefs: unbounded fn Stmt -> [Text]
/// ```
pub fn stmt_defs(s: &ast::Stmt) -> Array<Text> {
    match &s.kind {
        ast::StmtKind::SBind(p_, _, _) => check_env::pattern_names(p_),
        ast::StmtKind::SLet(p_, _, _) => check_env::pattern_names(p_),
        _ => Array::new(),
    }
}

/// The step machine of `StmtDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtDefs: unbounded fn Stmt -> [Text]
/// ```
pub struct StmtDefs {
    pub s: ast::Stmt,
}

impl prism_rtl::Job<Array<Text>> for StmtDefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let s = &self.s;
        match &s.kind {
            ast::StmtKind::SBind(p_, _, _) => prism_rtl::Turn::More(Rc::new(check_env::PatternNames { p_: p_.clone() })),
            ast::StmtKind::SLet(p_, _, _) => prism_rtl::Turn::More(Rc::new(check_env::PatternNames { p_: p_.clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start StmtDefs, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_defs(s: ast::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(StmtDefs { s })
}

/// ```prism
/// PromptEdges: unbounded fn Env, St, PCx, Stmt, [Text] -> [((Text, Text))]
/// ```
pub fn prompt_edges(env: &check_expr::Env, st: &check_types::St, cx_: &PCx, s: &ast::Stmt, defs: &Array<Text>) -> Array<(Text, Text)> {
    match &s.kind {
        ast::StmtKind::SBind(_, _, Some(_)) => Array::new(),
        ast::StmtKind::SBind(p_, e, None) => edges(&check_env::pattern_names(p_), &prompt_reads(cx_, e, defs)),
        ast::StmtKind::SLet(p_, _, e) => {
            let names = check_env::pattern_names(p_);
            let layer = run_to_end(fold_job(names.clone(), Text::from(""), {
                let env = env.clone();
                let st = st.clone();
                Rc::new(move |(p0, p1): (Text, Text)| {
                    let env = env.clone();
                    let st = st.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let n = p1;
                        match get(&env.locals, &n) {
                            Some(sc) => prism_rtl::Turn::More(Rc::new(check_types::HeadSigil { st: st.clone(), t: sc.ty.clone() })),
                            None => prism_rtl::Turn::Finished(acc.clone()),
                        }
                    }))
                }) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            edges(&names, &run_to_end(filter_job(prompt_reads(cx_, e, defs), {
                let env = env.clone();
                let st = st.clone();
                let layer = layer.clone();
                Rc::new(move |p0: Text| {
                    let env = env.clone();
                    let st = st.clone();
                    let layer = layer.clone();
                    entered(once_job(move || {
                        let n = p0;
                        prism_rtl::Turn::More(Rc::new(ReadIsPrompt { env: env.clone(), st: st.clone(), n: n.clone(), layer: layer.clone() }))
                    }))
                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
            })))
        },
        _ => Array::new(),
    }
}

/// The step machine of `PromptEdges`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PromptEdges: unbounded fn Env, St, PCx, Stmt, [Text] -> [((Text, Text))]
/// ```
pub struct PromptEdges {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub cx_: PCx,
    pub s: ast::Stmt,
    pub defs: Array<Text>,
}

impl prism_rtl::Job<Array<(Text, Text)>> for PromptEdges {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Text, Text)>> {
        let env = &self.env;
        let st = &self.st;
        let cx_ = &self.cx_;
        let s = &self.s;
        let defs = &self.defs;
        match &s.kind {
            ast::StmtKind::SBind(_, _, Some(_)) => prism_rtl::Turn::Finished(Array::new()),
            ast::StmtKind::SBind(p_, e, None) => {
                let cx_ = cx_.clone();
                let defs = defs.clone();
                let e = e.clone();
                let p_ = p_.clone();
                call_then(check_env::start_pattern_names(p_.clone()), move |pattern_names_18078: Array<Text>| call_then(start_prompt_reads(cx_.clone(), e.clone(), defs.clone()), move |prompt_reads_18096: Array<Text>| prism_rtl::Turn::Finished(edges(&pattern_names_18078, &prompt_reads_18096))))
            },
            ast::StmtKind::SLet(p_, _, e) => {
                let cx_ = cx_.clone();
                let defs = defs.clone();
                let e = e.clone();
                let env = env.clone();
                let p_ = p_.clone();
                let st = st.clone();
                call_then(check_env::start_pattern_names(p_.clone()), move |pattern_names_18164: Array<Text>| {
                    let names = pattern_names_18164;
                    call_value(fold_job(names.clone(), Text::from(""), {
                        let env = env.clone();
                        let st = st.clone();
                        Rc::new(move |(p0, p1): (Text, Text)| {
                            let env = env.clone();
                            let st = st.clone();
                            entered(once_job(move || {
                                let acc = p0;
                                let n = p1;
                                match get(&env.locals, &n) {
                                    Some(sc) => prism_rtl::Turn::More(Rc::new(check_types::HeadSigil { st: st.clone(), t: sc.ty.clone() })),
                                    None => prism_rtl::Turn::Finished(acc.clone()),
                                }
                            }))
                        }) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
                    }), move |fold_18199: Text| {
                        let layer = fold_18199;
                        call_then(start_prompt_reads(cx_.clone(), e.clone(), defs.clone()), move |prompt_reads_18335: Array<Text>| call_value(filter_job(prompt_reads_18335, {
                            let env = env.clone();
                            let st = st.clone();
                            let layer = layer.clone();
                            Rc::new(move |p0: Text| {
                                let env = env.clone();
                                let st = st.clone();
                                let layer = layer.clone();
                                entered(once_job(move || {
                                    let n = p0;
                                    prism_rtl::Turn::More(Rc::new(ReadIsPrompt { env: env.clone(), st: st.clone(), n: n.clone(), layer: layer.clone() }))
                                }))
                            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                        }), move |filter_18327: Array<Text>| prism_rtl::Turn::Finished(edges(&names, &filter_18327))))
                    })
                })
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start PromptEdges, x`: what the function value is when passed to `@Run`.
pub fn start_prompt_edges(env: check_expr::Env, st: check_types::St, cx_: PCx, s: ast::Stmt, defs: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>> {
    Rc::new(PromptEdges { env, st, cx_, s, defs })
}

/// ```prism
/// Edges: fn [Text], [Text] -> [((Text, Text))]
/// ```
pub fn edges(froms: &Array<Text>, tos: &Array<Text>) -> Array<(Text, Text)> {
    fold(froms, &Array::new(), &(|acc: &Array<(Text, Text)>, f: &Text| append(acc, &each(tos, &(|t: &Text| (f.clone(), t.clone()))))))
}

/// ```prism
/// ReadIsPrompt: unbounded fn Env, St, Text, Text -> Bool
/// ```
pub fn read_is_prompt(env: &check_expr::Env, st: &check_types::St, n: &Text, layer: &Text) -> bool {
    match get(&env.locals, n) {
        Some(sc) => {
            let h = check_types::head_sigil(st, &sc.ty);
            if layer == &Text::from("!") {
                (&h == &Text::from("!")) || (&h == &Text::from("@"))
            } else {
                if layer == &Text::from("$") {
                    (&h == &Text::from("$")) || (&h == &Text::from("!"))
                } else {
                    match check_types::walk(st, &sc.ty) {
                        check_types::Ty::TyFn(_, _, _) => false,
                        _ => check_env::is_lower_text(&lexer::drop_prefix(n, &check_types::marks_of(n))) && (&h == &Text::from("")),
                    }
                }
            }
        },
        None => false,
    }
}

/// The step machine of `ReadIsPrompt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadIsPrompt: unbounded fn Env, St, Text, Text -> Bool
/// ```
pub struct ReadIsPrompt {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub n: Text,
    pub layer: Text,
}

impl prism_rtl::Job<bool> for ReadIsPrompt {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let env = &self.env;
        let st = &self.st;
        let n = &self.n;
        let layer = &self.layer;
        match get(&env.locals, n) {
            Some(sc) => {
                let layer = layer.clone();
                let n = n.clone();
                let st = st.clone();
                call_then(check_types::start_head_sigil(st.clone(), sc.ty.clone()), move |head_sigil_18822: Text| {
                    let h = head_sigil_18822;
                    if &layer == &Text::from("!") {
                        prism_rtl::Turn::Finished((&h == &Text::from("!")) || (&h == &Text::from("@")))
                    } else {
                        if &layer == &Text::from("$") {
                            prism_rtl::Turn::Finished((&h == &Text::from("$")) || (&h == &Text::from("!")))
                        } else {
                            call_then(check_types::start_walk(st.clone(), sc.ty.clone()), move |walk_18960: check_types::Ty| match walk_18960 {
                                check_types::Ty::TyFn(_, _, _) => prism_rtl::Turn::Finished(false),
                                _ => prism_rtl::Turn::Finished(check_env::is_lower_text(&lexer::drop_prefix(&n, &check_types::marks_of(&n))) && (&h == &Text::from(""))),
                            })
                        }
                    }
                })
            },
            None => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start ReadIsPrompt, x`: what the function value is when passed to `@Run`.
pub fn start_read_is_prompt(env: check_expr::Env, st: check_types::St, n: Text, layer: Text) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(ReadIsPrompt { env, st, n, layer })
}

/// ```prism
/// PromptBase: unbounded fn Env, [Stmt] -> (Text ==> Rel)
/// ```
pub fn prompt_base(env: &check_expr::Env, stmts: &Array<ast::Stmt>) -> Map<Text, Rel> {
    let pre = prelude_seeds(&env.g, &env.home);
    let seeds = fold(&keys(&pre), &pre, &(|m: &Map<Text, Rel>, k: &Text| if check_env::has_key(&env.locals, &lexer::drop_prefix(k, &Text::from("pre:"))) {
        remove(m, k)
    } else {
        m.clone()
    }));
    fold(stmts, &seeds, &(|m: &Map<Text, Rel>, s: &ast::Stmt| lam_let_rels(s, m)))
}

/// The step machine of `PromptBase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PromptBase: unbounded fn Env, [Stmt] -> (Text ==> Rel)
/// ```
pub struct PromptBase {
    pub env: check_expr::Env,
    pub stmts: Array<ast::Stmt>,
}

impl prism_rtl::Job<Map<Text, Rel>> for PromptBase {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Rel>> {
        let env = &self.env;
        let stmts = &self.stmts;
        let pre = prelude_seeds(&env.g, &env.home);
        let seeds = fold(&keys(&pre), &pre, &(|m: &Map<Text, Rel>, k: &Text| if check_env::has_key(&env.locals, &lexer::drop_prefix(k, &Text::from("pre:"))) {
            remove(m, k)
        } else {
            m.clone()
        }));
        prism_rtl::Turn::Finished(fold(stmts, &seeds, &(|m: &Map<Text, Rel>, s: &ast::Stmt| lam_let_rels(s, m))))
    }
}

/// `Start PromptBase, x`: what the function value is when passed to `@Run`.
pub fn start_prompt_base(env: check_expr::Env, stmts: Array<ast::Stmt>) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>> {
    Rc::new(PromptBase { env, stmts })
}

/// ```prism
/// LamLetRels: fn Stmt, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn lam_let_rels(s: &ast::Stmt, m: &Map<Text, Rel>) -> Map<Text, Rel> {
    match &s.kind {
        ast::StmtKind::SLet(p_, _, e) => match ((*p_.kind).clone(), lambda_of(e)) {
            (ast::PatternKind::PName(n), Some(lam)) => insert(m, &Text::from(format!("lamlet:{}", &check_env::sname_key(&n))), &Rel { param: lam.span.start.clone(), strict: false }),
            _ => m.clone(),
        },
        _ => m.clone(),
    }
}

/// ```prism
/// ?LambdaOf: fn Expr -> ?Expr
/// ```
pub fn lambda_of(e: &ast::Expr) -> Option<ast::Expr> {
    match &*e.kind {
        ast::ExprKind::ELambda(_, _) => Some(e.clone()),
        ast::ExprKind::EGroup(x) => lambda_of(&**x),
        _ => None,
    }
}

/// ```prism
/// LetLambdas: unbounded fn [Stmt] -> (Nat ==> Expr)
/// ```
pub fn let_lambdas(stmts: &Array<ast::Stmt>) -> Map<Nat, ast::Expr> {
    fold(&stmts_spots(stmts, &Map::new()), &Map::new(), &(|m: &Map<Nat, ast::Expr>, sp: &Spot| match sp {
        Spot::SpotStmt(s, _) => match &s.kind {
            ast::StmtKind::SLet(_, _, e) => match lambda_of(e) {
                Some(lam) => insert(m, &lam.span.start, &lam),
                None => m.clone(),
            },
            _ => m.clone(),
        },
        _ => m.clone(),
    }))
}

/// The step machine of `LetLambdas`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LetLambdas: unbounded fn [Stmt] -> (Nat ==> Expr)
/// ```
pub struct LetLambdas {
    pub stmts: Array<ast::Stmt>,
}

impl prism_rtl::Job<Map<Nat, ast::Expr>> for LetLambdas {
    fn cycle(&self) -> prism_rtl::Turn<Map<Nat, ast::Expr>> {
        let stmts = &self.stmts;
        let stmts = stmts.clone();
        call_then(start_stmts_spots(stmts.clone(), Map::new()), move |stmts_spots_20684: Array<Spot>| prism_rtl::Turn::Finished(fold(&stmts_spots_20684, &Map::new(), &(|m: &Map<Nat, ast::Expr>, sp: &Spot| match sp {
            Spot::SpotStmt(s, _) => match &s.kind {
                ast::StmtKind::SLet(_, _, e) => match lambda_of(e) {
                    Some(lam) => insert(m, &lam.span.start, &lam),
                    None => m.clone(),
                },
                _ => m.clone(),
            },
            _ => m.clone(),
        }))))
    }
}

/// `Start LetLambdas, x`: what the function value is when passed to `@Run`.
pub fn start_let_lambdas(stmts: Array<ast::Stmt>) -> Rc<dyn prism_rtl::Job<Map<Nat, ast::Expr>>> {
    Rc::new(LetLambdas { stmts })
}

/// ```prism
/// PromptReads: unbounded fn PCx, Expr, [Text] -> [Text]
/// ```
pub fn prompt_reads(cx_: &PCx, e: &ast::Expr, defs: &Array<Text>) -> Array<Text> {
    let spots = prompt_spots(cx_, e, &cx_.base);
    run_to_end(fold_job(spots.clone(), Array::new(), {
        let defs = defs.clone();
        Rc::new(move |(p0, p1): (Array<Text>, Spot)| {
            let defs = defs.clone();
            entered(once_job(move || {
                let acc = p0;
                let sp = p1;
                call_then(start_spot_sites(sp.clone()), move |spot_sites_22033: Array<Site>| prism_rtl::Turn::Finished(fold(&spot_sites_22033, &acc, &(|a2: &Array<Text>, site: &Site| if check_types::has_text(&defs, &site.callee) && !is_local(&site.rels, &site.callee) {
                    check_types::add_text(a2, &site.callee)
                } else {
                    a2.clone()
                }))))
            }))
        }) as Rc<dyn Fn((Array<Text>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `PromptReads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PromptReads: unbounded fn PCx, Expr, [Text] -> [Text]
/// ```
pub struct PromptReads {
    pub cx_: PCx,
    pub e: ast::Expr,
    pub defs: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for PromptReads {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cx_ = &self.cx_;
        let e = &self.e;
        let defs = &self.defs;
        let cx_ = cx_.clone();
        let defs = defs.clone();
        let e = e.clone();
        call_then(start_prompt_spots(cx_.clone(), e.clone(), cx_.base.clone()), move |prompt_spots_21967: Array<Spot>| {
            let spots = prompt_spots_21967;
            fold_job(spots.clone(), Array::new(), {
                let defs = defs.clone();
                Rc::new(move |(p0, p1): (Array<Text>, Spot)| {
                    let defs = defs.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let sp = p1;
                        call_then(start_spot_sites(sp.clone()), move |spot_sites_22033: Array<Site>| prism_rtl::Turn::Finished(fold(&spot_sites_22033, &acc, &(|a2: &Array<Text>, site: &Site| if check_types::has_text(&defs, &site.callee) && !is_local(&site.rels, &site.callee) {
                            check_types::add_text(a2, &site.callee)
                        } else {
                            a2.clone()
                        }))))
                    }))
                }) as Rc<dyn Fn((Array<Text>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }).cycle()
        })
    }
}

/// `Start PromptReads, x`: what the function value is when passed to `@Run`.
pub fn start_prompt_reads(cx_: PCx, e: ast::Expr, defs: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(PromptReads { cx_, e, defs })
}

/// ```prism
/// PromptSpots: unbounded fn PCx, Expr, (Text ==> Rel) -> [Spot]
/// ```
pub fn prompt_spots(cx_: &PCx, e: &ast::Expr, m: &Map<Text, Rel>) -> Array<Spot> {
    run_to_end(fold_job(prompt_kids(cx_, e, m), Array::from(vec![Spot::SpotExpr(e.clone(), m.clone())]), {
        let cx_ = cx_.clone();
        Rc::new(move |(p0, p1): (Array<Spot>, Kid)| {
            let cx_ = cx_.clone();
            entered(once_job(move || {
                let acc = p0;
                let k = p1;
                prism_rtl::Turn::Finished(append(&acc, &prompt_kid_spots(&cx_, &k)))
            }))
        }) as Rc<dyn Fn((Array<Spot>, Kid)) -> Rc<dyn prism_rtl::Job<Array<Spot>>>>
    }))
}

/// The step machine of `PromptSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PromptSpots: unbounded fn PCx, Expr, (Text ==> Rel) -> [Spot]
/// ```
pub struct PromptSpots {
    pub cx_: PCx,
    pub e: ast::Expr,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Array<Spot>> for PromptSpots {
    fn cycle(&self) -> prism_rtl::Turn<Array<Spot>> {
        let cx_ = &self.cx_;
        let e = &self.e;
        let m = &self.m;
        fold_job(prompt_kids(cx_, e, m), Array::from(vec![Spot::SpotExpr(e.clone(), m.clone())]), {
            let cx_ = cx_.clone();
            Rc::new(move |(p0, p1): (Array<Spot>, Kid)| {
                let cx_ = cx_.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let k = p1;
                    prism_rtl::Turn::Finished(append(&acc, &prompt_kid_spots(&cx_, &k)))
                }))
            }) as Rc<dyn Fn((Array<Spot>, Kid)) -> Rc<dyn prism_rtl::Job<Array<Spot>>>>
        }).cycle()
    }
}

/// `Start PromptSpots, x`: what the function value is when passed to `@Run`.
pub fn start_prompt_spots(cx_: PCx, e: ast::Expr, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Array<Spot>>> {
    Rc::new(PromptSpots { cx_, e, m })
}

/// ```prism
/// PromptKids: unbounded fn PCx, Expr, (Text ==> Rel) -> [Kid]
/// ```
pub fn prompt_kids(cx_: &PCx, e: &ast::Expr, m: &Map<Text, Rel>) -> Array<Kid> {
    match &*e.kind {
        ast::ExprKind::ELambda(_, _) => Array::new(),
        ast::ExprKind::ERebuild(_, body) => row_kids(body, m, &Array::new()),
        ast::ExprKind::EFor(binders_opt, _, body) => row_kids(body, m, &for_binder_names(binders_opt)),
        ast::ExprKind::EWidgetBlock(_) => Array::new(),
        ast::ExprKind::ECall(c, _, _, _) => prompt_call_kids(cx_, e, &callee_name(&**c), m),
        ast::ExprKind::EMethod(_, n, _) => prompt_call_kids(cx_, e, &Some(check_env::sname_key(n)), m),
        _ => expr_kids(e, m),
    }
}

/// ```prism
/// RowKids: unbounded fn Block, (Text ==> Rel), [Text] -> [Kid]
/// ```
pub fn row_kids(body: &ast::Block, m: &Map<Text, Rel>, binders: &Array<Text>) -> Array<Kid> {
    let lines = filter(&body.stmts, &(|s: &ast::Stmt| match &s.kind {
        ast::StmtKind::SBind(_, _, Some(_)) => false,
        _ => true,
    }));
    let own = run_to_end(fold_job(body.stmts.clone(), append(binders, &Array::from(vec![Text::from("_"), Text::from("$_")])), Rc::new(move |(p0, p1): (Array<Text>, ast::Stmt)| entered(once_job(move || {
        let acc = p0;
        let s = p1;
        call_then(start_stmt_defs(s.clone()), move |stmt_defs_23704: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &stmt_defs_23704)))
    }))) as Rc<dyn Fn((Array<Text>, ast::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    Array::from(vec![Kid::KidStmts(lines.clone(), hide(m, &own))])
}

/// ```prism
/// ForBinderNames: unbounded fn ?ForBinders -> [Text]
/// ```
pub fn for_binder_names(binders_opt: &Option<ast::ForBinders>) -> Array<Text> {
    match binders_opt {
        Some(fb) => match &fb.second {
            Some(second) => append(&check_env::pattern_names(&fb.first), &check_env::pattern_names(second)),
            None => check_env::pattern_names(&fb.first),
        },
        None => Array::new(),
    }
}

/// ```prism
/// PromptCallKids: unbounded fn PCx, Expr, ?Text, (Text ==> Rel) -> [Kid]
/// ```
pub fn prompt_call_kids(cx_: &PCx, e: &ast::Expr, n_opt: &Option<Text>, m: &Map<Text, Rel>) -> Array<Kid> {
    match n_opt {
        Some(n) => {
            let called = follow_lam_let(cx_, n, m);
            if is_local(m, n) {
                append(&called, &open_lambdas(cx_, &expr_kids(e, m)))
            } else {
                if &len(&called) > &Nat::from(0u32) {
                    append(&called, &open_lambdas(cx_, &expr_kids(e, m)))
                } else {
                    match resolve_callee(&cx_.g, &cx_.home, n) {
                        Some(k) => if is_prelude_key(&cx_.g, &k) && is_delayed_widget(&lexer::drop_prefix(&k, &Text::from("Prelude."))) {
                            Array::new()
                        } else {
                            if is_prelude_key(&cx_.g, &k) && lexer::has_prefix(&k, &Text::from("Prelude.@")) {
                                expr_kids(e, m)
                            } else {
                                open_lambdas(cx_, &expr_kids(e, m))
                            }
                        },
                        None => open_lambdas(cx_, &expr_kids(e, m)),
                    }
                }
            }
        },
        None => open_lambdas(cx_, &expr_kids(e, m)),
    }
}

/// ```prism
/// OpenLambdas: unbounded fn PCx, [Kid] -> [Kid]
/// ```
pub fn open_lambdas(cx_: &PCx, kids: &Array<Kid>) -> Array<Kid> {
    run_to_end(fold_job(kids.clone(), Array::new(), {
        let cx_ = cx_.clone();
        Rc::new(move |(p0, p1): (Array<Kid>, Kid)| {
            let cx_ = cx_.clone();
            entered(once_job(move || {
                let acc = p0;
                let k = p1;
                match &k {
                    Kid::KidExpr(x, m) => match &*x.kind {
                        ast::ExprKind::ELambda(ps_opt, body) => {
                            let ps_opt = ps_opt.clone();
                            let body = (**body).clone();
                            let m = m.clone();
                            call_then(start_patterns_names(or(&ps_opt, &Array::new())), move |patterns_names_25323: Array<Text>| prism_rtl::Turn::Finished(push(&acc, &lambda_kid(&body, &hide(&m, &patterns_names_25323)))))
                        },
                        ast::ExprKind::EName(n) => prism_rtl::Turn::Finished(append(&push(&acc, &k), &follow_lam_let(&cx_, &check_env::sname_key(n), m))),
                        _ => prism_rtl::Turn::Finished(push(&acc, &k)),
                    },
                    _ => prism_rtl::Turn::Finished(push(&acc, &k)),
                }
            }))
        }) as Rc<dyn Fn((Array<Kid>, Kid)) -> Rc<dyn prism_rtl::Job<Array<Kid>>>>
    }))
}

/// ```prism
/// FollowLamLet: unbounded fn PCx, Text, (Text ==> Rel) -> [Kid]
/// ```
pub fn follow_lam_let(cx_: &PCx, n: &Text, m: &Map<Text, Rel>) -> Array<Kid> {
    match get(m, &Text::from(format!("lamlet:{}", n))) {
        Some(r) => if check_env::has_key(m, &Text::from(format!("seen:{}", &r.param))) {
            Array::new()
        } else {
            match get(&cx_.lams, &r.param) {
                Some(lam) => match &*lam.kind {
                    ast::ExprKind::ELambda(ps_opt, body) => {
                        let seen = fold(&keys(m), &cx_.base, &(|m2: &Map<Text, Rel>, k: &Text| if lexer::has_prefix(k, &Text::from("seen:")) {
                            insert(m2, k, &no_rel())
                        } else {
                            m2.clone()
                        }));
                        Array::from(vec![lambda_kid(&**body, &hide(&insert(&seen, &Text::from(format!("seen:{}", &r.param)), &no_rel()), &patterns_names(&or(ps_opt, &Array::new()))))])
                    },
                    _ => Array::new(),
                },
                None => Array::new(),
            }
        },
        None => Array::new(),
    }
}

/// ```prism
/// PromptKidSpots: unbounded fn PCx, Kid -> [Spot]
/// ```
pub fn prompt_kid_spots(cx_: &PCx, k: &Kid) -> Array<Spot> {
    match k {
        Kid::KidExpr(x, m) => prompt_spots(cx_, x, m),
        Kid::KidStmts(ss, m) => {
            let bm = block_rels(ss, m);
            run_to_end(fold_job(ss.clone(), Array::new(), {
                let cx_ = cx_.clone();
                let bm = bm.clone();
                Rc::new(move |(p0, p1): (Array<Spot>, ast::Stmt)| {
                    let cx_ = cx_.clone();
                    let bm = bm.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let s = p1;
                        prism_rtl::Turn::Finished(append(&acc, &prompt_stmt_spots(&cx_, &s, &bm)))
                    }))
                }) as Rc<dyn Fn((Array<Spot>, ast::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Spot>>>>
            }))
        },
    }
}

/// ```prism
/// PromptStmtSpots: unbounded fn PCx, Stmt, (Text ==> Rel) -> [Spot]
/// ```
pub fn prompt_stmt_spots(cx_: &PCx, s: &ast::Stmt, m: &Map<Text, Rel>) -> Array<Spot> {
    match &s.kind {
        ast::StmtKind::SFn(_) => Array::from(vec![Spot::SpotStmt(s.clone(), m.clone())]),
        ast::StmtKind::SWidget(_) => Array::from(vec![Spot::SpotStmt(s.clone(), m.clone())]),
        _ => run_to_end(fold_job(stmt_kids(s, m), Array::from(vec![Spot::SpotStmt(s.clone(), m.clone())]), {
            let cx_ = cx_.clone();
            Rc::new(move |(p0, p1): (Array<Spot>, Kid)| {
                let cx_ = cx_.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let k = p1;
                    prism_rtl::Turn::Finished(append(&acc, &prompt_kid_spots(&cx_, &k)))
                }))
            }) as Rc<dyn Fn((Array<Spot>, Kid)) -> Rc<dyn prism_rtl::Job<Array<Spot>>>>
        })),
    }
}

/// ```prism
/// FindCycle: unbounded fn [Text], [((Text, Text))] -> [Text]
/// ```
pub fn find_cycle(defs: &Array<Text>, edges_: &Array<(Text, Text)>) -> Array<Text> {
    run_to_end(fold_job(defs.clone(), Array::new(), {
        let defs = defs.clone();
        let edges_ = edges_.clone();
        Rc::new(move |(p0, p1): (Array<Text>, Text)| {
            let defs = defs.clone();
            let edges_ = edges_.clone();
            entered(once_job(move || {
                let found = p0;
                let d = p1;
                if &len(&found) > &Nat::from(0u32) {
                    prism_rtl::Turn::Finished(found.clone())
                } else {
                    prism_rtl::Turn::More(Rc::new(CycleThrough { defs: defs.clone(), edges_: edges_.clone(), d: d.clone() }))
                }
            }))
        }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `FindCycle`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FindCycle: unbounded fn [Text], [((Text, Text))] -> [Text]
/// ```
pub struct FindCycle {
    pub defs: Array<Text>,
    pub edges_: Array<(Text, Text)>,
}

impl prism_rtl::Job<Array<Text>> for FindCycle {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let defs = &self.defs;
        let edges_ = &self.edges_;
        fold_job(defs.clone(), Array::new(), {
            let defs = defs.clone();
            let edges_ = edges_.clone();
            Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                let defs = defs.clone();
                let edges_ = edges_.clone();
                entered(once_job(move || {
                    let found = p0;
                    let d = p1;
                    if &len(&found) > &Nat::from(0u32) {
                        prism_rtl::Turn::Finished(found.clone())
                    } else {
                        prism_rtl::Turn::More(Rc::new(CycleThrough { defs: defs.clone(), edges_: edges_.clone(), d: d.clone() }))
                    }
                }))
            }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }).cycle()
    }
}

/// `Start FindCycle, x`: what the function value is when passed to `@Run`.
pub fn start_find_cycle(defs: Array<Text>, edges_: Array<(Text, Text)>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(FindCycle { defs, edges_ })
}

/// ```prism
/// CycleThrough: unbounded fn [Text], [((Text, Text))], Text -> [Text]
/// ```
pub fn cycle_through(defs: &Array<Text>, edges_: &Array<(Text, Text)>, d: &Text) -> Array<Text> {
    let fwd = reach_from(edges_, d);
    if check_types::has_text(&fwd, d) {
        run_to_end(filter_job(defs.clone(), {
            let fwd = fwd.clone();
            let edges_ = edges_.clone();
            let d = d.clone();
            Rc::new(move |p0: Text| {
                let fwd = fwd.clone();
                let edges_ = edges_.clone();
                let d = d.clone();
                entered(once_job(move || {
                    let x = p0;
                    prism_rtl::Turn::Finished(check_types::has_text(&fwd, &x) && check_types::has_text(&reach_from(&edges_, &x), &d))
                }))
            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
        }))
    } else {
        Array::new()
    }
}

/// The step machine of `CycleThrough`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CycleThrough: unbounded fn [Text], [((Text, Text))], Text -> [Text]
/// ```
pub struct CycleThrough {
    pub defs: Array<Text>,
    pub edges_: Array<(Text, Text)>,
    pub d: Text,
}

impl prism_rtl::Job<Array<Text>> for CycleThrough {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let defs = &self.defs;
        let edges_ = &self.edges_;
        let d = &self.d;
        let d = d.clone();
        let defs = defs.clone();
        let edges_ = edges_.clone();
        call_then(start_reach_from(edges_.clone(), d.clone()), move |reach_from_27343: Array<Text>| {
            let fwd = reach_from_27343;
            if check_types::has_text(&fwd, &d) {
                filter_job(defs.clone(), {
                    let fwd = fwd.clone();
                    let edges_ = edges_.clone();
                    let d = d.clone();
                    Rc::new(move |p0: Text| {
                        let fwd = fwd.clone();
                        let edges_ = edges_.clone();
                        let d = d.clone();
                        entered(once_job(move || {
                            let x = p0;
                            prism_rtl::Turn::Finished(check_types::has_text(&fwd, &x) && check_types::has_text(&reach_from(&edges_, &x), &d))
                        }))
                    }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                }).cycle()
            } else {
                prism_rtl::Turn::Finished(Array::new())
            }
        })
    }
}

/// `Start CycleThrough, x`: what the function value is when passed to `@Run`.
pub fn start_cycle_through(defs: Array<Text>, edges_: Array<(Text, Text)>, d: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(CycleThrough { defs, edges_, d })
}

/// ```prism
/// ReachFrom: unbounded fn [((Text, Text))], Text -> [Text]
/// ```
pub fn reach_from(edges_: &Array<(Text, Text)>, d: &Text) -> Array<Text> {
    reach(edges_, &each(&filter(edges_, &(|(f, _): &(Text, Text)| f == d)), &(|(_, t): &(Text, Text)| t.clone())), &Array::new())
}

/// The step machine of `ReachFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReachFrom: unbounded fn [((Text, Text))], Text -> [Text]
/// ```
pub struct ReachFrom {
    pub edges_: Array<(Text, Text)>,
    pub d: Text,
}

impl prism_rtl::Job<Array<Text>> for ReachFrom {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let edges_ = &self.edges_;
        let d = &self.d;
        prism_rtl::Turn::Finished(reach(edges_, &each(&filter(edges_, &(|(f, _): &(Text, Text)| f == d)), &(|(_, t): &(Text, Text)| t.clone())), &Array::new()))
    }
}

/// `Start ReachFrom, x`: what the function value is when passed to `@Run`.
pub fn start_reach_from(edges_: Array<(Text, Text)>, d: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ReachFrom { edges_, d })
}

/// ```prism
/// Reach: unbounded fn [((Text, Text))], [Text], [Text] -> [Text]
/// ```
pub fn reach(edges_: &Array<(Text, Text)>, frontier: &Array<Text>, seen: &Array<Text>) -> Array<Text> {
    match index(frontier, &Nat::from(0u32)) {
        None => seen.clone(),
        Some(x) => if check_types::has_text(seen, &x) {
            reach(edges_, &drop(frontier, &Nat::from(1u32)), seen)
        } else {
            reach(edges_, &append(&drop(frontier, &Nat::from(1u32)), &each(&filter(edges_, &(|(f, _): &(Text, Text)| f == &x)), &(|(_, t): &(Text, Text)| t.clone()))), &push(seen, &x))
        },
    }
}

/// ```prism
/// IsLocalType: unbounded fn St, Ty -> Bool
/// ```
pub fn is_local_type(st: &check_types::St, t: &check_types::Ty) -> bool {
    match check_types::walk(st, t) {
        check_types::Ty::TyCon(m28289_0_0, _) if (&m28289_0_0 == &Text::from("Buffer")) => true,
        check_types::Ty::TyCon(m28289_1_0, _) if (&m28289_1_0 == &Text::from("Table")) => true,
        check_types::Ty::TyArray(e) => is_local_type(st, &*e),
        check_types::Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), false, {
            let st = st.clone();
            Rc::new(move |(p0, p1): (bool, check_types::Ty)| {
                let st = st.clone();
                entered(once_job(move || {
                    let seen = p0;
                    let x = p1;
                    prism_rtl::Turn::Finished(seen || is_local_type(&st, &x))
                }))
            }) as Rc<dyn Fn((bool, check_types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        check_types::Ty::TyMap(k, v_) => is_local_type(st, &*k) || is_local_type(st, &*v_),
        check_types::Ty::TySig(_, i) => is_local_type(st, &*i),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `IsLocalType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsLocalType: unbounded fn St, Ty -> Bool
/// ```
pub struct IsLocalType {
    pub st: check_types::St,
    pub t: check_types::Ty,
}

impl prism_rtl::Job<bool> for IsLocalType {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let st = &self.st;
        let t = &self.t;
        let st = st.clone();
        let t = t.clone();
        call_then(check_types::start_walk(st.clone(), t.clone()), move |walk_28295: check_types::Ty| match walk_28295 {
            check_types::Ty::TyCon(m28289_0_0, _) if (&m28289_0_0 == &Text::from("Buffer")) => prism_rtl::Turn::Finished(true),
            check_types::Ty::TyCon(m28289_1_0, _) if (&m28289_1_0 == &Text::from("Table")) => prism_rtl::Turn::Finished(true),
            check_types::Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(IsLocalType { st: st.clone(), t: (*e).clone() })),
            check_types::Ty::TyTuple(ts) => fold_job(ts.clone(), false, {
                let st = st.clone();
                Rc::new(move |(p0, p1): (bool, check_types::Ty)| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let seen = p0;
                        let x = p1;
                        prism_rtl::Turn::Finished(seen || is_local_type(&st, &x))
                    }))
                }) as Rc<dyn Fn((bool, check_types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            check_types::Ty::TyMap(k, v_) => call_then(start_is_local_type(st.clone(), (*k).clone()), move |is_local_type_28491: bool| prism_rtl::Turn::Finished(is_local_type_28491 || is_local_type(&st, &*v_))),
            check_types::Ty::TySig(_, i) => prism_rtl::Turn::More(Rc::new(IsLocalType { st: st.clone(), t: (*i).clone() })),
            _ => prism_rtl::Turn::Finished(false),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start IsLocalType, x`: what the function value is when passed to `@Run`.
pub fn start_is_local_type(st: check_types::St, t: check_types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsLocalType { st, t })
}

/// ```prism
/// AndBlockChecks: unbounded fn Env, St, Block, Ty -> St
/// ```
pub fn and_block_checks(env: &check_expr::Env, st: &check_types::St, b: &ast::Block, t: &check_types::Ty) -> check_types::St {
    let st1 = if is_local_type(st, t) {
        check_types::err_fix(st, &Text::from("local-escapes"), &b.span, &Text::from(format!("a `{}` cannot leave its block", &block_local_name(st, t))), &Text::from("`Freeze` it into a plain value first"))
    } else {
        st.clone()
    };
    let st2 = escape_stmts(env, &st1, &b.stmts);
    let (_, st3) = frozen_stmts(env, &st2, &b.stmts, &Map::new());
    borrow_stmts(env, &st3, &b.stmts, &Array::new())
}

/// The step machine of `AndBlockChecks`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AndBlockChecks: unbounded fn Env, St, Block, Ty -> St
/// ```
pub struct AndBlockChecks {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub b: ast::Block,
    pub t: check_types::Ty,
}

impl prism_rtl::Job<check_types::St> for AndBlockChecks {
    fn cycle(&self) -> prism_rtl::Turn<check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let b = &self.b;
        let t = &self.t;
        let b = b.clone();
        let env = env.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(start_is_local_type(st.clone(), t.clone()), move |is_local_type_28845: bool| {
            let st1 = if is_local_type_28845 {
                check_types::err_fix(&st, &Text::from("local-escapes"), &b.span, &Text::from(format!("a `{}` cannot leave its block", &block_local_name(&st, &t))), &Text::from("`Freeze` it into a plain value first"))
            } else {
                st.clone()
            };
            call_then(start_escape_stmts(env.clone(), st1.clone(), b.stmts.clone()), move |escape_stmts_29015: check_types::St| {
                let st2 = escape_stmts_29015;
                call_then(start_frozen_stmts(env.clone(), st2.clone(), b.stmts.clone(), Map::new()), move |frozen_stmts_29071: (Map<Text, Nat>, check_types::St)| {
                    let (_, st3) = frozen_stmts_29071;
                    prism_rtl::Turn::More(Rc::new(BorrowStmts { env: env.clone(), st: st3.clone(), stmts: b.stmts.clone(), lent: Array::new() }))
                })
            })
        })
    }
}

/// `Start AndBlockChecks, x`: what the function value is when passed to `@Run`.
pub fn start_and_block_checks(env: check_expr::Env, st: check_types::St, b: ast::Block, t: check_types::Ty) -> Rc<dyn prism_rtl::Job<check_types::St>> {
    Rc::new(AndBlockChecks { env, st, b, t })
}

/// ```prism
/// BlockLocalName: unbounded fn St, Ty -> Text
/// ```
pub fn block_local_name(st: &check_types::St, t: &check_types::Ty) -> Text {
    match check_types::walk(st, t) {
        check_types::Ty::TyCon(n, _) => n.clone(),
        _ => Text::from("Buffer"),
    }
}

/// The step machine of `BlockLocalName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockLocalName: unbounded fn St, Ty -> Text
/// ```
pub struct BlockLocalName {
    pub st: check_types::St,
    pub t: check_types::Ty,
}

impl prism_rtl::Job<Text> for BlockLocalName {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let st = &self.st;
        let t = &self.t;
        let st = st.clone();
        let t = t.clone();
        call_then(check_types::start_walk(st.clone(), t.clone()), move |walk_29222: check_types::Ty| match walk_29222 {
            check_types::Ty::TyCon(n, _) => prism_rtl::Turn::Finished(n.clone()),
            _ => prism_rtl::Turn::Finished(Text::from("Buffer")),
        })
    }
}

/// `Start BlockLocalName, x`: what the function value is when passed to `@Run`.
pub fn start_block_local_name(st: check_types::St, t: check_types::Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(BlockLocalName { st, t })
}

/// ```prism
/// EscapeStmts: unbounded fn Env, St, [Stmt] -> St
/// ```
pub fn escape_stmts(env: &check_expr::Env, st: &check_types::St, stmts: &Array<ast::Stmt>) -> check_types::St {
    run_to_end(fold_job(stmts.clone(), st.clone(), {
        let env = env.clone();
        Rc::new(move |(p0, p1): (check_types::St, ast::Stmt)| {
            let env = env.clone();
            entered(once_job(move || {
                let s = p0;
                let stmt = p1;
                match &stmt.kind {
                    ast::StmtKind::SLet(p_, _, e) => match &*p_.kind {
                        ast::PatternKind::PName(n) => if lexer::has_prefix(&n.sigils, &Text::from("&")) {
                            prism_rtl::Turn::Finished(s.clone())
                        } else {
                            match get(&env.locals, &check_env::sname_key(n)) {
                                Some(_) => prism_rtl::Turn::Finished(s.clone()),
                                None => if calls_local_maker(&env, e) {
                                    prism_rtl::Turn::Finished(check_types::err_fix(&s, &Text::from("local-escapes"), &stmt.span, &Text::from(format!("a `Buffer` cannot leave its block: `{}` is no `&` local", &check_env::sname_key(n))), &Text::from(format!("write `let &{} = ...`", &check_env::sname_key(n)))))
                                } else {
                                    prism_rtl::Turn::Finished(s.clone())
                                },
                            }
                        },
                        _ => prism_rtl::Turn::Finished(s.clone()),
                    },
                    ast::StmtKind::SWhile(_, body) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env: env.clone(), st: s.clone(), stmts: body.stmts.clone() })),
                    ast::StmtKind::SExpr(e) => match &*e.kind {
                        ast::ExprKind::EIf(_, tb, eb_opt) => {
                            let eb_opt = eb_opt.clone();
                            let tb = tb.clone();
                            call_then(start_escape_stmts(env.clone(), s.clone(), tb.stmts.clone()), move |escape_stmts_29931: check_types::St| {
                                let s2 = escape_stmts_29931;
                                match &eb_opt {
                                    Some(x) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env: env.clone(), st: s2.clone(), stmts: x.stmts.clone() })),
                                    None => prism_rtl::Turn::Finished(s2.clone()),
                                }
                            })
                        },
                        ast::ExprKind::EMatch(_, arms) => fold_job(arms.clone(), s.clone(), {
                            let env = env.clone();
                            Rc::new(move |(p0, p1): (check_types::St, ast::Arm)| {
                                let env = env.clone();
                                entered(once_job(move || {
                                    let s3 = p0;
                                    let a = p1;
                                    prism_rtl::Turn::More(Rc::new(EscapeStmts { env: env.clone(), st: s3.clone(), stmts: a.body.stmts.clone() }))
                                }))
                            }) as Rc<dyn Fn((check_types::St, ast::Arm)) -> Rc<dyn prism_rtl::Job<check_types::St>>>
                        }).cycle(),
                        ast::ExprKind::EFor(_, _, body) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env: env.clone(), st: s.clone(), stmts: body.stmts.clone() })),
                        _ => prism_rtl::Turn::Finished(s.clone()),
                    },
                    _ => prism_rtl::Turn::Finished(s.clone()),
                }
            }))
        }) as Rc<dyn Fn((check_types::St, ast::Stmt)) -> Rc<dyn prism_rtl::Job<check_types::St>>>
    }))
}

/// The step machine of `EscapeStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EscapeStmts: unbounded fn Env, St, [Stmt] -> St
/// ```
pub struct EscapeStmts {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub stmts: Array<ast::Stmt>,
}

impl prism_rtl::Job<check_types::St> for EscapeStmts {
    fn cycle(&self) -> prism_rtl::Turn<check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let stmts = &self.stmts;
        fold_job(stmts.clone(), st.clone(), {
            let env = env.clone();
            Rc::new(move |(p0, p1): (check_types::St, ast::Stmt)| {
                let env = env.clone();
                entered(once_job(move || {
                    let s = p0;
                    let stmt = p1;
                    match &stmt.kind {
                        ast::StmtKind::SLet(p_, _, e) => match &*p_.kind {
                            ast::PatternKind::PName(n) => if lexer::has_prefix(&n.sigils, &Text::from("&")) {
                                prism_rtl::Turn::Finished(s.clone())
                            } else {
                                match get(&env.locals, &check_env::sname_key(n)) {
                                    Some(_) => prism_rtl::Turn::Finished(s.clone()),
                                    None => if calls_local_maker(&env, e) {
                                        prism_rtl::Turn::Finished(check_types::err_fix(&s, &Text::from("local-escapes"), &stmt.span, &Text::from(format!("a `Buffer` cannot leave its block: `{}` is no `&` local", &check_env::sname_key(n))), &Text::from(format!("write `let &{} = ...`", &check_env::sname_key(n)))))
                                    } else {
                                        prism_rtl::Turn::Finished(s.clone())
                                    },
                                }
                            },
                            _ => prism_rtl::Turn::Finished(s.clone()),
                        },
                        ast::StmtKind::SWhile(_, body) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env: env.clone(), st: s.clone(), stmts: body.stmts.clone() })),
                        ast::StmtKind::SExpr(e) => match &*e.kind {
                            ast::ExprKind::EIf(_, tb, eb_opt) => {
                                let eb_opt = eb_opt.clone();
                                let tb = tb.clone();
                                call_then(start_escape_stmts(env.clone(), s.clone(), tb.stmts.clone()), move |escape_stmts_29931: check_types::St| {
                                    let s2 = escape_stmts_29931;
                                    match &eb_opt {
                                        Some(x) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env: env.clone(), st: s2.clone(), stmts: x.stmts.clone() })),
                                        None => prism_rtl::Turn::Finished(s2.clone()),
                                    }
                                })
                            },
                            ast::ExprKind::EMatch(_, arms) => fold_job(arms.clone(), s.clone(), {
                                let env = env.clone();
                                Rc::new(move |(p0, p1): (check_types::St, ast::Arm)| {
                                    let env = env.clone();
                                    entered(once_job(move || {
                                        let s3 = p0;
                                        let a = p1;
                                        prism_rtl::Turn::More(Rc::new(EscapeStmts { env: env.clone(), st: s3.clone(), stmts: a.body.stmts.clone() }))
                                    }))
                                }) as Rc<dyn Fn((check_types::St, ast::Arm)) -> Rc<dyn prism_rtl::Job<check_types::St>>>
                            }).cycle(),
                            ast::ExprKind::EFor(_, _, body) => prism_rtl::Turn::More(Rc::new(EscapeStmts { env: env.clone(), st: s.clone(), stmts: body.stmts.clone() })),
                            _ => prism_rtl::Turn::Finished(s.clone()),
                        },
                        _ => prism_rtl::Turn::Finished(s.clone()),
                    }
                }))
            }) as Rc<dyn Fn((check_types::St, ast::Stmt)) -> Rc<dyn prism_rtl::Job<check_types::St>>>
        }).cycle()
    }
}

/// `Start EscapeStmts, x`: what the function value is when passed to `@Run`.
pub fn start_escape_stmts(env: check_expr::Env, st: check_types::St, stmts: Array<ast::Stmt>) -> Rc<dyn prism_rtl::Job<check_types::St>> {
    Rc::new(EscapeStmts { env, st, stmts })
}

/// ```prism
/// CallsLocalMaker: fn Env, Expr -> Bool
/// ```
pub fn calls_local_maker(env: &check_expr::Env, e: &ast::Expr) -> bool {
    match &*e.kind {
        ast::ExprKind::ECall(c, _, _, _) => &maker_of(env, &**c) != &None,
        ast::ExprKind::EName(_) => match maker_of(env, e) {
            Some(k) => &k != &Text::from("Buffer.Numbered"),
            None => false,
        },
        ast::ExprKind::EGroup(x) => calls_local_maker(env, &**x),
        _ => false,
    }
}

/// ```prism
/// ?MakerOf: fn Env, Expr -> ?Text
/// ```
pub fn maker_of(env: &check_expr::Env, c: &ast::Expr) -> Option<Text> {
    match callee_name(c) {
        Some(n) => if check_env::has_key(&env.locals, &n) {
            None
        } else {
            match resolve_name(&env.g, &env.home, &n) {
                Some(k) => if check_expr::is_local_maker(&k) && (&or(&get(&env.g.vals, &k), &dummy_val()).sort == &Text::from("builtin")) {
                    Some(k.clone())
                } else {
                    None
                },
                None => None,
            }
        },
        None => None,
    }
}

/// ```prism
/// FrozenStmts: unbounded fn Env, St, [Stmt], (Text ==> Nat) -> (((Text ==> Nat), St))
/// ```
pub fn frozen_stmts(env: &check_expr::Env, st: &check_types::St, stmts: &Array<ast::Stmt>, frozen: &Map<Text, Nat>) -> (Map<Text, Nat>, check_types::St) {
    let pre = prelude_seeds(&env.g, &env.home);
    let seeds = fold(&keys(&pre), &pre, &(|m: &Map<Text, Rel>, k: &Text| if check_env::has_key(&env.locals, &lexer::drop_prefix(k, &Text::from("pre:"))) {
        remove(m, k)
    } else {
        m.clone()
    }));
    let bm = block_rels(stmts, &seeds);
    run_to_end(fold_job(stmts.clone(), (frozen.clone(), st.clone()), {
        let bm = bm.clone();
        let env = env.clone();
        Rc::new(move |(p0, p1): ((Map<Text, Nat>, check_types::St), ast::Stmt)| {
            let bm = bm.clone();
            let env = env.clone();
            entered(once_job(move || {
                let (fz, s) = p0;
                let stmt = p1;
                call_then(start_stmt_spots(stmt.clone(), bm.clone()), move |stmt_spots_31796: Array<Spot>| {
                    let spots = stmt_spots_31796;
                    let reads = fold(&spots, &Array::new(), &(|acc: &Array<(Text, ast::Range)>, sp: &Spot| append(acc, &spot_refs(sp))));
                    let s2 = fold(&reads, &s, &(|s1: &check_types::St, (n, sp): &(Text, ast::Range)| match get(&fz, n) {
                        Some(line) => check_types::err_fix(s1, &Text::from("frozen"), sp, &Text::from(format!("`{}` was frozen on line {}", n, &(&line + &Nat::from(1u32)))), &Text::from("use the frozen value, or make a new local")),
                        None => s1.clone(),
                    }));
                    let fz1 = match &stmt.kind {
                        ast::StmtKind::SLet(p_, _, _) => fold(&check_env::pattern_names(p_), &fz, &(|m: &Map<Text, Nat>, n: &Text| remove(m, n))),
                        _ => fz.clone(),
                    };
                    call_value(fold_job(spots.clone(), fz1.clone(), {
                        let env = env.clone();
                        let stmt = stmt.clone();
                        Rc::new(move |(p0, p1): (Map<Text, Nat>, Spot)| {
                            let env = env.clone();
                            let stmt = stmt.clone();
                            entered(once_job(move || {
                                let m = p0;
                                let sp = p1;
                                call_then(start_spot_freezes(sp.clone()), move |spot_freezes_32294: Array<Text>| prism_rtl::Turn::Finished(fold(&spot_freezes_32294, &m, &(|m2: &Map<Text, Nat>, n: &Text| insert(m2, n, &check_errors::cline_of(&env.src.starts, &stmt.span.start))))))
                            }))
                        }) as Rc<dyn Fn((Map<Text, Nat>, Spot)) -> Rc<dyn prism_rtl::Job<Map<Text, Nat>>>>
                    }), move |fold_32262: Map<Text, Nat>| {
                        let fz2 = fold_32262;
                        prism_rtl::Turn::Finished((fz2.clone(), s2.clone()))
                    })
                })
            }))
        }) as Rc<dyn Fn(((Map<Text, Nat>, check_types::St), ast::Stmt)) -> Rc<dyn prism_rtl::Job<(Map<Text, Nat>, check_types::St)>>>
    }))
}

/// The step machine of `FrozenStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FrozenStmts: unbounded fn Env, St, [Stmt], (Text ==> Nat) -> (((Text ==> Nat), St))
/// ```
pub struct FrozenStmts {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub stmts: Array<ast::Stmt>,
    pub frozen: Map<Text, Nat>,
}

impl prism_rtl::Job<(Map<Text, Nat>, check_types::St)> for FrozenStmts {
    fn cycle(&self) -> prism_rtl::Turn<(Map<Text, Nat>, check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let stmts = &self.stmts;
        let frozen = &self.frozen;
        let pre = prelude_seeds(&env.g, &env.home);
        let seeds = fold(&keys(&pre), &pre, &(|m: &Map<Text, Rel>, k: &Text| if check_env::has_key(&env.locals, &lexer::drop_prefix(k, &Text::from("pre:"))) {
            remove(m, k)
        } else {
            m.clone()
        }));
        let env = env.clone();
        let frozen = frozen.clone();
        let st = st.clone();
        let stmts = stmts.clone();
        call_then(start_block_rels(stmts.clone(), seeds.clone()), move |block_rels_31702: Map<Text, Rel>| {
            let bm = block_rels_31702;
            fold_job(stmts.clone(), (frozen.clone(), st.clone()), {
                let bm = bm.clone();
                let env = env.clone();
                Rc::new(move |(p0, p1): ((Map<Text, Nat>, check_types::St), ast::Stmt)| {
                    let bm = bm.clone();
                    let env = env.clone();
                    entered(once_job(move || {
                        let (fz, s) = p0;
                        let stmt = p1;
                        call_then(start_stmt_spots(stmt.clone(), bm.clone()), move |stmt_spots_31796: Array<Spot>| {
                            let spots = stmt_spots_31796;
                            let reads = fold(&spots, &Array::new(), &(|acc: &Array<(Text, ast::Range)>, sp: &Spot| append(acc, &spot_refs(sp))));
                            let s2 = fold(&reads, &s, &(|s1: &check_types::St, (n, sp): &(Text, ast::Range)| match get(&fz, n) {
                                Some(line) => check_types::err_fix(s1, &Text::from("frozen"), sp, &Text::from(format!("`{}` was frozen on line {}", n, &(&line + &Nat::from(1u32)))), &Text::from("use the frozen value, or make a new local")),
                                None => s1.clone(),
                            }));
                            let fz1 = match &stmt.kind {
                                ast::StmtKind::SLet(p_, _, _) => fold(&check_env::pattern_names(p_), &fz, &(|m: &Map<Text, Nat>, n: &Text| remove(m, n))),
                                _ => fz.clone(),
                            };
                            call_value(fold_job(spots.clone(), fz1.clone(), {
                                let env = env.clone();
                                let stmt = stmt.clone();
                                Rc::new(move |(p0, p1): (Map<Text, Nat>, Spot)| {
                                    let env = env.clone();
                                    let stmt = stmt.clone();
                                    entered(once_job(move || {
                                        let m = p0;
                                        let sp = p1;
                                        call_then(start_spot_freezes(sp.clone()), move |spot_freezes_32294: Array<Text>| prism_rtl::Turn::Finished(fold(&spot_freezes_32294, &m, &(|m2: &Map<Text, Nat>, n: &Text| insert(m2, n, &check_errors::cline_of(&env.src.starts, &stmt.span.start))))))
                                    }))
                                }) as Rc<dyn Fn((Map<Text, Nat>, Spot)) -> Rc<dyn prism_rtl::Job<Map<Text, Nat>>>>
                            }), move |fold_32262: Map<Text, Nat>| {
                                let fz2 = fold_32262;
                                prism_rtl::Turn::Finished((fz2.clone(), s2.clone()))
                            })
                        })
                    }))
                }) as Rc<dyn Fn(((Map<Text, Nat>, check_types::St), ast::Stmt)) -> Rc<dyn prism_rtl::Job<(Map<Text, Nat>, check_types::St)>>>
            }).cycle()
        })
    }
}

/// `Start FrozenStmts, x`: what the function value is when passed to `@Run`.
pub fn start_frozen_stmts(env: check_expr::Env, st: check_types::St, stmts: Array<ast::Stmt>, frozen: Map<Text, Nat>) -> Rc<dyn prism_rtl::Job<(Map<Text, Nat>, check_types::St)>> {
    Rc::new(FrozenStmts { env, st, stmts, frozen })
}

/// ```prism
/// SpotRefs: fn Spot -> [((Text, Range))]
/// ```
pub fn spot_refs(spot0: &Spot) -> Array<(Text, ast::Range)> {
    match spot0 {
        Spot::SpotExpr(e, _) => match &*e.kind {
            ast::ExprKind::EName(n) => if lexer::has_prefix(&n.sigils, &Text::from("&")) {
                Array::from(vec![(check_env::sname_key(n), n.span.clone())])
            } else {
                Array::new()
            },
            _ => Array::new(),
        },
        Spot::SpotStmt(_, _) => Array::new(),
    }
}

/// ```prism
/// SpotFreezes: unbounded fn Spot -> [Text]
/// ```
pub fn spot_freezes(spot0: &Spot) -> Array<Text> {
    match spot0 {
        Spot::SpotExpr(e, m) => match call_of(e) {
            Some((c, args)) => match callee_name(&c) {
                Some(n) => if pre_is(m, &n, &Text::from("Freeze")) {
                    run_to_end(fold_job(args.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, ast::Arg)| entered(once_job(move || {
                        let acc = p0;
                        let a = p1;
                        prism_rtl::Turn::Finished(append(&acc, &each(&refs_in(&a.value), &(|(n2, _): &(Text, ast::Range)| n2.clone()))))
                    }))) as Rc<dyn Fn((Array<Text>, ast::Arg)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))
                } else {
                    Array::new()
                },
                None => Array::new(),
            },
            None => Array::new(),
        },
        Spot::SpotStmt(_, _) => Array::new(),
    }
}

/// The step machine of `SpotFreezes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotFreezes: unbounded fn Spot -> [Text]
/// ```
pub struct SpotFreezes {
    pub spot0: Spot,
}

impl prism_rtl::Job<Array<Text>> for SpotFreezes {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let spot0 = &self.spot0;
        match spot0 {
            Spot::SpotExpr(e, m) => match call_of(e) {
                Some((c, args)) => match callee_name(&c) {
                    Some(n) => if pre_is(m, &n, &Text::from("Freeze")) {
                        fold_job(args.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, ast::Arg)| entered(once_job(move || {
                            let acc = p0;
                            let a = p1;
                            prism_rtl::Turn::Finished(append(&acc, &each(&refs_in(&a.value), &(|(n2, _): &(Text, ast::Range)| n2.clone()))))
                        }))) as Rc<dyn Fn((Array<Text>, ast::Arg)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle()
                    } else {
                        prism_rtl::Turn::Finished(Array::new())
                    },
                    None => prism_rtl::Turn::Finished(Array::new()),
                },
                None => prism_rtl::Turn::Finished(Array::new()),
            },
            Spot::SpotStmt(_, _) => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start SpotFreezes, x`: what the function value is when passed to `@Run`.
pub fn start_spot_freezes(spot0: Spot) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SpotFreezes { spot0 })
}

/// ```prism
/// RefsIn: unbounded fn Expr -> [((Text, Range))]
/// ```
pub fn refs_in(e: &ast::Expr) -> Array<(Text, ast::Range)> {
    match &*e.kind {
        ast::ExprKind::EName(n) => if lexer::has_prefix(&n.sigils, &Text::from("&")) {
            Array::from(vec![(check_env::sname_key(n), n.span.clone())])
        } else {
            Array::new()
        },
        ast::ExprKind::ECall(c, args, _, _) => run_to_end(fold_job(args.clone(), refs_in(&**c), Rc::new(move |(p0, p1): (Array<(Text, ast::Range)>, ast::Arg)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            prism_rtl::Turn::Finished(append(&acc, &refs_in(&a.value)))
        }))) as Rc<dyn Fn((Array<(Text, ast::Range)>, ast::Arg)) -> Rc<dyn prism_rtl::Job<Array<(Text, ast::Range)>>>>)),
        ast::ExprKind::EBinary(_, l, r) => append(&refs_in(&**l), &refs_in(&**r)),
        ast::ExprKind::EUnary(_, x) => refs_in(&**x),
        ast::ExprKind::EFreeSigil(_, x) => refs_in(&**x),
        ast::ExprKind::EField(r, _, _) => refs_in(&**r),
        ast::ExprKind::EIndex(r, i) => append(&refs_in(&**r), &refs_in(&**i)),
        ast::ExprKind::EGroup(x) => refs_in(&**x),
        ast::ExprKind::ETuple(es) => run_to_end(fold_job(es.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, ast::Range)>, ast::Expr)| entered(once_job(move || {
            let acc = p0;
            let x = p1;
            prism_rtl::Turn::Finished(append(&acc, &refs_in(&x)))
        }))) as Rc<dyn Fn((Array<(Text, ast::Range)>, ast::Expr)) -> Rc<dyn prism_rtl::Job<Array<(Text, ast::Range)>>>>)),
        ast::ExprKind::EArray(es) => run_to_end(fold_job(es.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<(Text, ast::Range)>, ast::Expr)| entered(once_job(move || {
            let acc = p0;
            let x = p1;
            prism_rtl::Turn::Finished(append(&acc, &refs_in(&x)))
        }))) as Rc<dyn Fn((Array<(Text, ast::Range)>, ast::Expr)) -> Rc<dyn prism_rtl::Job<Array<(Text, ast::Range)>>>>)),
        _ => Array::new(),
    }
}

/// ```prism
/// BorrowStmts: unbounded fn Env, St, [Stmt], [ [Text] ] -> St
/// ```
pub fn borrow_stmts(env: &check_expr::Env, st: &check_types::St, stmts: &Array<ast::Stmt>, lent: &Array<Array<Text>>) -> check_types::St {
    run_to_end(fold_job(stmts.clone(), st.clone(), {
        let env = env.clone();
        let lent = lent.clone();
        Rc::new(move |(p0, p1): (check_types::St, ast::Stmt)| {
            let env = env.clone();
            let lent = lent.clone();
            entered(once_job(move || {
                let s = p0;
                let stmt = p1;
                match &stmt.kind {
                    ast::StmtKind::SSet(t, _) => prism_rtl::Turn::More(Rc::new(CheckLent { env: env.clone(), st: s.clone(), t: t.clone(), lent: lent.clone() })),
                    ast::StmtKind::SAccum(t, _, _) => prism_rtl::Turn::More(Rc::new(CheckLent { env: env.clone(), st: s.clone(), t: t.clone(), lent: lent.clone() })),
                    ast::StmtKind::SWhile(_, body) => prism_rtl::Turn::More(Rc::new(BorrowStmts { env: env.clone(), st: s.clone(), stmts: body.stmts.clone(), lent: lent.clone() })),
                    ast::StmtKind::SExpr(e) => match &*e.kind {
                        ast::ExprKind::EFor(binders_opt, source, body) => {
                            let binders_opt = binders_opt.clone();
                            let body = body.clone();
                            let source = (**source).clone();
                            call_then(start_ref_path(source.clone()), move |ref_path_34235: Array<Text>| {
                                let path_ = ref_path_34235;
                                let lent2 = if (&len(&path_) > &Nat::from(0u32)) && (&binders_opt != &None) {
                                    push(&lent, &path_)
                                } else {
                                    lent.clone()
                                };
                                prism_rtl::Turn::More(Rc::new(BorrowStmts { env: env.clone(), st: s.clone(), stmts: body.stmts.clone(), lent: lent2.clone() }))
                            })
                        },
                        ast::ExprKind::EIf(_, tb, eb_opt) => {
                            let eb_opt = eb_opt.clone();
                            let tb = tb.clone();
                            call_then(start_borrow_stmts(env.clone(), s.clone(), tb.stmts.clone(), lent.clone()), move |borrow_stmts_34440: check_types::St| {
                                let s2 = borrow_stmts_34440;
                                match &eb_opt {
                                    Some(x) => prism_rtl::Turn::More(Rc::new(BorrowStmts { env: env.clone(), st: s2.clone(), stmts: x.stmts.clone(), lent: lent.clone() })),
                                    None => prism_rtl::Turn::Finished(s2.clone()),
                                }
                            })
                        },
                        ast::ExprKind::EMatch(_, arms) => fold_job(arms.clone(), s.clone(), {
                            let env = env.clone();
                            let lent = lent.clone();
                            Rc::new(move |(p0, p1): (check_types::St, ast::Arm)| {
                                let env = env.clone();
                                let lent = lent.clone();
                                entered(once_job(move || {
                                    let s3 = p0;
                                    let a = p1;
                                    prism_rtl::Turn::More(Rc::new(BorrowStmts { env: env.clone(), st: s3.clone(), stmts: a.body.stmts.clone(), lent: lent.clone() }))
                                }))
                            }) as Rc<dyn Fn((check_types::St, ast::Arm)) -> Rc<dyn prism_rtl::Job<check_types::St>>>
                        }).cycle(),
                        _ => prism_rtl::Turn::Finished(s.clone()),
                    },
                    _ => prism_rtl::Turn::Finished(s.clone()),
                }
            }))
        }) as Rc<dyn Fn((check_types::St, ast::Stmt)) -> Rc<dyn prism_rtl::Job<check_types::St>>>
    }))
}

/// The step machine of `BorrowStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BorrowStmts: unbounded fn Env, St, [Stmt], [ [Text] ] -> St
/// ```
pub struct BorrowStmts {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub stmts: Array<ast::Stmt>,
    pub lent: Array<Array<Text>>,
}

impl prism_rtl::Job<check_types::St> for BorrowStmts {
    fn cycle(&self) -> prism_rtl::Turn<check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let stmts = &self.stmts;
        let lent = &self.lent;
        fold_job(stmts.clone(), st.clone(), {
            let env = env.clone();
            let lent = lent.clone();
            Rc::new(move |(p0, p1): (check_types::St, ast::Stmt)| {
                let env = env.clone();
                let lent = lent.clone();
                entered(once_job(move || {
                    let s = p0;
                    let stmt = p1;
                    match &stmt.kind {
                        ast::StmtKind::SSet(t, _) => prism_rtl::Turn::More(Rc::new(CheckLent { env: env.clone(), st: s.clone(), t: t.clone(), lent: lent.clone() })),
                        ast::StmtKind::SAccum(t, _, _) => prism_rtl::Turn::More(Rc::new(CheckLent { env: env.clone(), st: s.clone(), t: t.clone(), lent: lent.clone() })),
                        ast::StmtKind::SWhile(_, body) => prism_rtl::Turn::More(Rc::new(BorrowStmts { env: env.clone(), st: s.clone(), stmts: body.stmts.clone(), lent: lent.clone() })),
                        ast::StmtKind::SExpr(e) => match &*e.kind {
                            ast::ExprKind::EFor(binders_opt, source, body) => {
                                let binders_opt = binders_opt.clone();
                                let body = body.clone();
                                let source = (**source).clone();
                                call_then(start_ref_path(source.clone()), move |ref_path_34235: Array<Text>| {
                                    let path_ = ref_path_34235;
                                    let lent2 = if (&len(&path_) > &Nat::from(0u32)) && (&binders_opt != &None) {
                                        push(&lent, &path_)
                                    } else {
                                        lent.clone()
                                    };
                                    prism_rtl::Turn::More(Rc::new(BorrowStmts { env: env.clone(), st: s.clone(), stmts: body.stmts.clone(), lent: lent2.clone() }))
                                })
                            },
                            ast::ExprKind::EIf(_, tb, eb_opt) => {
                                let eb_opt = eb_opt.clone();
                                let tb = tb.clone();
                                call_then(start_borrow_stmts(env.clone(), s.clone(), tb.stmts.clone(), lent.clone()), move |borrow_stmts_34440: check_types::St| {
                                    let s2 = borrow_stmts_34440;
                                    match &eb_opt {
                                        Some(x) => prism_rtl::Turn::More(Rc::new(BorrowStmts { env: env.clone(), st: s2.clone(), stmts: x.stmts.clone(), lent: lent.clone() })),
                                        None => prism_rtl::Turn::Finished(s2.clone()),
                                    }
                                })
                            },
                            ast::ExprKind::EMatch(_, arms) => fold_job(arms.clone(), s.clone(), {
                                let env = env.clone();
                                let lent = lent.clone();
                                Rc::new(move |(p0, p1): (check_types::St, ast::Arm)| {
                                    let env = env.clone();
                                    let lent = lent.clone();
                                    entered(once_job(move || {
                                        let s3 = p0;
                                        let a = p1;
                                        prism_rtl::Turn::More(Rc::new(BorrowStmts { env: env.clone(), st: s3.clone(), stmts: a.body.stmts.clone(), lent: lent.clone() }))
                                    }))
                                }) as Rc<dyn Fn((check_types::St, ast::Arm)) -> Rc<dyn prism_rtl::Job<check_types::St>>>
                            }).cycle(),
                            _ => prism_rtl::Turn::Finished(s.clone()),
                        },
                        _ => prism_rtl::Turn::Finished(s.clone()),
                    }
                }))
            }) as Rc<dyn Fn((check_types::St, ast::Stmt)) -> Rc<dyn prism_rtl::Job<check_types::St>>>
        }).cycle()
    }
}

/// `Start BorrowStmts, x`: what the function value is when passed to `@Run`.
pub fn start_borrow_stmts(env: check_expr::Env, st: check_types::St, stmts: Array<ast::Stmt>, lent: Array<Array<Text>>) -> Rc<dyn prism_rtl::Job<check_types::St>> {
    Rc::new(BorrowStmts { env, st, stmts, lent })
}

/// ```prism
/// CheckLent: unbounded fn Env, St, Expr, [ [Text] ] -> St
/// ```
pub fn check_lent(env: &check_expr::Env, st: &check_types::St, t: &ast::Expr, lent: &Array<Array<Text>>) -> check_types::St {
    let path_ = ref_path(t);
    fold(lent, st, &(|s: &check_types::St, l: &Array<Text>| if ((&len(&path_) > &Nat::from(0u32)) && is_prefix(l, &path_)) || is_prefix(&path_, l) {
        check_types::err_fix(s, &Text::from("borrow-overlap"), &t.span, &Text::from(format!("`{}` is lent to the `for`", &lexer::join(l, &Text::from(".")))), &Text::from("set it after the loop, or loop over a copy"))
    } else {
        s.clone()
    }))
}

/// The step machine of `CheckLent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckLent: unbounded fn Env, St, Expr, [ [Text] ] -> St
/// ```
pub struct CheckLent {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub t: ast::Expr,
    pub lent: Array<Array<Text>>,
}

impl prism_rtl::Job<check_types::St> for CheckLent {
    fn cycle(&self) -> prism_rtl::Turn<check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let t = &self.t;
        let lent = &self.lent;
        let lent = lent.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(start_ref_path(t.clone()), move |ref_path_34811: Array<Text>| {
            let path_ = ref_path_34811;
            prism_rtl::Turn::Finished(fold(&lent, &st, &(|s: &check_types::St, l: &Array<Text>| if ((&len(&path_) > &Nat::from(0u32)) && is_prefix(l, &path_)) || is_prefix(&path_, l) {
                check_types::err_fix(s, &Text::from("borrow-overlap"), &t.span, &Text::from(format!("`{}` is lent to the `for`", &lexer::join(l, &Text::from(".")))), &Text::from("set it after the loop, or loop over a copy"))
            } else {
                s.clone()
            })))
        })
    }
}

/// `Start CheckLent, x`: what the function value is when passed to `@Run`.
pub fn start_check_lent(env: check_expr::Env, st: check_types::St, t: ast::Expr, lent: Array<Array<Text>>) -> Rc<dyn prism_rtl::Job<check_types::St>> {
    Rc::new(CheckLent { env, st, t, lent })
}

/// ```prism
/// IsPrefix: fn [Text], [Text] -> Bool
/// ```
pub fn is_prefix(a: &Array<Text>, b: &Array<Text>) -> bool {
    (&len(a) <= &len(b)) && (&take(b, &len(a)) == a)
}

/// ```prism
/// RefPath: unbounded fn Expr -> [Text]
/// ```
pub fn ref_path(e: &ast::Expr) -> Array<Text> {
    match &*e.kind {
        ast::ExprKind::EName(n) => if lexer::has_prefix(&n.sigils, &Text::from("&")) {
            Array::from(vec![check_env::sname_key(n)])
        } else {
            Array::new()
        },
        ast::ExprKind::EField(r, _, f) => {
            let p_ = ref_path(&**r);
            if &len(&p_) > &Nat::from(0u32) { push(&p_, &f.name) } else { p_.clone() }
        },
        ast::ExprKind::EIndex(r, _) => {
            let p_ = ref_path(&**r);
            if &len(&p_) > &Nat::from(0u32) { push(&p_, &Text::from("[]")) } else { p_.clone() }
        },
        ast::ExprKind::EGroup(x) => ref_path(&**x),
        _ => Array::new(),
    }
}

/// The step machine of `RefPath`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RefPath: unbounded fn Expr -> [Text]
/// ```
pub struct RefPath {
    pub e: ast::Expr,
}

impl prism_rtl::Job<Array<Text>> for RefPath {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let e = &self.e;
        match &*e.kind {
            ast::ExprKind::EName(n) => if lexer::has_prefix(&n.sigils, &Text::from("&")) {
                prism_rtl::Turn::Finished(Array::from(vec![check_env::sname_key(n)]))
            } else {
                prism_rtl::Turn::Finished(Array::new())
            },
            ast::ExprKind::EField(r, _, f) => {
                let f = f.clone();
                let r = (**r).clone();
                call_then(start_ref_path(r.clone()), move |ref_path_35401: Array<Text>| {
                    let p_ = ref_path_35401;
                    if &len(&p_) > &Nat::from(0u32) {
                        prism_rtl::Turn::Finished(push(&p_, &f.name))
                    } else {
                        prism_rtl::Turn::Finished(p_.clone())
                    }
                })
            },
            ast::ExprKind::EIndex(r, _) => {
                let r = (**r).clone();
                call_then(start_ref_path(r.clone()), move |ref_path_35496: Array<Text>| {
                    let p_ = ref_path_35496;
                    if &len(&p_) > &Nat::from(0u32) {
                        prism_rtl::Turn::Finished(push(&p_, &Text::from("[]")))
                    } else {
                        prism_rtl::Turn::Finished(p_.clone())
                    }
                })
            },
            ast::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(RefPath { e: (**x).clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start RefPath, x`: what the function value is when passed to `@Run`.
pub fn start_ref_path(e: ast::Expr) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(RefPath { e })
}

/// ```prism
/// ShrinkCheck: unbounded fn G, St, [Def] -> ((St, [((Text, [Text]))]))
/// ```
pub fn shrink_check(g: &check_env::G, st: &check_types::St, defs: &Array<check_env::Def>) -> (check_types::St, Array<(Text, Array<Text>)>) {
    let fns = each(&filter(defs, &(|d: &check_env::Def| &len(&def_clauses(d)) > &Nat::from(0u32))), &(|d: &check_env::Def| own_key(d)));
    let by_key = fold(&fns, &Map::new(), &(|m: &Map<Text, check_env::Def>, d: &check_env::Def| insert(m, &d.qk, d)));
    let homes = fold(&fns, &Array::new(), &(|acc: &Array<Text>, d: &check_env::Def| check_types::add_text(acc, &d.home)));
    let nats = nat_minus_seeds(st);
    let pre = fold(&homes, &Map::new(), &(|m: &Map<Text, Map<Text, Rel>>, h: &Text| insert(m, h, &fold(&keys(&nats), &prelude_seeds(g, h), &(|m2: &Map<Text, Rel>, k: &Text| insert(m2, k, &no_rel()))))));
    let sk0 = Shrink { g: g.clone(), fns: fns.clone(), by_key: by_key.clone(), targets: method_targets(g, &fns), impl_defs: impl_defs(g, &fns), choices: st.choices.clone(), sums: Map::new(), seeds: pre.clone(), local_of: Map::new(), local_base: Map::new() };
    let sk1 = {
        let mut this: Shrink = sk0.clone();
        this.sums = parts_summaries(&sk0, &fns);
        this
    };
    let skg = {
        let mut this: Shrink = sk1.clone();
        this.seeds = hof_seeds(&sk1, &homes);
        this
    };
    let walked = run_to_end(each_job(fns.clone(), {
        let skg = skg.clone();
        Rc::new(move |p0: check_env::Def| {
            let skg = skg.clone();
            entered(once_job(move || {
                let d = p0;
                prism_rtl::Turn::More(Rc::new(DefWalk { sk: skg.clone(), d: d.clone() }))
            }))
        }) as Rc<dyn Fn(check_env::Def) -> Rc<dyn prism_rtl::Job<(Text, Array<Text>, Array<(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)>)>>>
    }));
    let sk = with_locals(&skg, &fold(&walked, &Array::new(), &(|acc: &Array<(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)>, (_, _, ls): &(Text, Array<Text>, Array<(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)>)| append(acc, ls))));
    let refs = append(&each(&walked, &(|(k, rs, _): &(Text, Array<Text>, Array<(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)>)| (k.clone(), rs.clone()))), &run_to_end(each_job(drop(&sk.fns, &len(&fns)), {
        let sk = sk.clone();
        Rc::new(move |p0: check_env::Def| {
            let sk = sk.clone();
            entered(once_job(move || {
                let d = p0;
                call_then(start_def_refs(sk.clone(), d.clone()), move |def_refs_38255: Array<Text>| prism_rtl::Turn::Finished((d.qk.clone(), def_refs_38255)))
            }))
        }) as Rc<dyn Fn(check_env::Def) -> Rc<dyn prism_rtl::Job<(Text, Array<Text>)>>>
    })));
    let keys_ = each(&sk.fns, &(|d: &check_env::Def| d.qk.clone()));
    let sccs_ = sccs(&keys_, &refs);
    let st2 = run_to_end(fold_job(sccs_.clone(), negative_types(g, st), {
        let sk = sk.clone();
        Rc::new(move |(p0, p1): (check_types::St, Array<Text>)| {
            let sk = sk.clone();
            entered(once_job(move || {
                let s = p0;
                let comp = p1;
                prism_rtl::Turn::More(Rc::new(ShrinkComponent { sk: sk.clone(), st: s.clone(), comp: comp.clone() }))
            }))
        }) as Rc<dyn Fn((check_types::St, Array<Text>)) -> Rc<dyn prism_rtl::Job<check_types::St>>>
    }));
    let st3 = run_to_end(fold_job(fns.clone(), st2.clone(), {
        let sk = sk.clone();
        Rc::new(move |(p0, p1): (check_types::St, check_env::Def)| {
            let sk = sk.clone();
            entered(once_job(move || {
                let s = p0;
                let d = p1;
                prism_rtl::Turn::More(Rc::new(LoopsOf { sk: sk.clone(), st: s.clone(), d: d.clone() }))
            }))
        }) as Rc<dyn Fn((check_types::St, check_env::Def)) -> Rc<dyn prism_rtl::Job<check_types::St>>>
    }));
    (st3.clone(), refs.clone())
}

/// The step machine of `ShrinkCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShrinkCheck: unbounded fn G, St, [Def] -> ((St, [((Text, [Text]))]))
/// ```
pub struct ShrinkCheck {
    pub g: check_env::G,
    pub st: check_types::St,
    pub defs: Array<check_env::Def>,
}

impl prism_rtl::Job<(check_types::St, Array<(Text, Array<Text>)>)> for ShrinkCheck {
    fn cycle(&self) -> prism_rtl::Turn<(check_types::St, Array<(Text, Array<Text>)>)> {
        let g = &self.g;
        let st = &self.st;
        let defs = &self.defs;
        let fns = each(&filter(defs, &(|d: &check_env::Def| &len(&def_clauses(d)) > &Nat::from(0u32))), &(|d: &check_env::Def| own_key(d)));
        let by_key = fold(&fns, &Map::new(), &(|m: &Map<Text, check_env::Def>, d: &check_env::Def| insert(m, &d.qk, d)));
        let homes = fold(&fns, &Array::new(), &(|acc: &Array<Text>, d: &check_env::Def| check_types::add_text(acc, &d.home)));
        let g = g.clone();
        let st = st.clone();
        call_then(start_nat_minus_seeds(st.clone()), move |nat_minus_seeds_37550: Map<Text, Rel>| {
            let nats = nat_minus_seeds_37550;
            let pre = fold(&homes, &Map::new(), &(|m: &Map<Text, Map<Text, Rel>>, h: &Text| insert(m, h, &fold(&keys(&nats), &prelude_seeds(&g, h), &(|m2: &Map<Text, Rel>, k: &Text| insert(m2, k, &no_rel()))))));
            let sk0 = Shrink { g: g.clone(), fns: fns.clone(), by_key: by_key.clone(), targets: method_targets(&g, &fns), impl_defs: impl_defs(&g, &fns), choices: st.choices.clone(), sums: Map::new(), seeds: pre.clone(), local_of: Map::new(), local_base: Map::new() };
            let sk1 = {
                let mut this: Shrink = sk0.clone();
                this.sums = parts_summaries(&sk0, &fns);
                this
            };
            let skg = {
                let mut this: Shrink = sk1.clone();
                this.seeds = hof_seeds(&sk1, &homes);
                this
            };
            call_value(each_job(fns.clone(), {
                let skg = skg.clone();
                Rc::new(move |p0: check_env::Def| {
                    let skg = skg.clone();
                    entered(once_job(move || {
                        let d = p0;
                        prism_rtl::Turn::More(Rc::new(DefWalk { sk: skg.clone(), d: d.clone() }))
                    }))
                }) as Rc<dyn Fn(check_env::Def) -> Rc<dyn prism_rtl::Job<(Text, Array<Text>, Array<(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)>)>>>
            }), move |each_38014: Array<(Text, Array<Text>, Array<(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)>)>| {
                let walked = each_38014;
                call_then(start_with_locals(skg.clone(), fold(&walked, &Array::new(), &(|acc: &Array<(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)>, (_, _, ls): &(Text, Array<Text>, Array<(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)>)| append(acc, ls)))), move |with_locals_38057: Shrink| {
                    let sk = with_locals_38057;
                    call_value(each_job(drop(&sk.fns, &len(&fns)), {
                        let sk = sk.clone();
                        Rc::new(move |p0: check_env::Def| {
                            let sk = sk.clone();
                            entered(once_job(move || {
                                let d = p0;
                                call_then(start_def_refs(sk.clone(), d.clone()), move |def_refs_38255: Array<Text>| prism_rtl::Turn::Finished((d.qk.clone(), def_refs_38255)))
                            }))
                        }) as Rc<dyn Fn(check_env::Def) -> Rc<dyn prism_rtl::Job<(Text, Array<Text>)>>>
                    }), move |each_38210: Array<(Text, Array<Text>)>| {
                        let refs = append(&each(&walked, &(|(k, rs, _): &(Text, Array<Text>, Array<(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)>)| (k.clone(), rs.clone()))), &each_38210);
                        let keys_ = each(&sk.fns, &(|d: &check_env::Def| d.qk.clone()));
                        call_then(start_sccs(keys_.clone(), refs.clone()), move |sccs_38326: Array<Array<Text>>| {
                            let sccs_ = sccs_38326;
                            call_then(start_negative_types(g.clone(), st.clone()), move |negative_types_38368: check_types::St| call_value(fold_job(sccs_.clone(), negative_types_38368, {
                                let sk = sk.clone();
                                Rc::new(move |(p0, p1): (check_types::St, Array<Text>)| {
                                    let sk = sk.clone();
                                    entered(once_job(move || {
                                        let s = p0;
                                        let comp = p1;
                                        prism_rtl::Turn::More(Rc::new(ShrinkComponent { sk: sk.clone(), st: s.clone(), comp: comp.clone() }))
                                    }))
                                }) as Rc<dyn Fn((check_types::St, Array<Text>)) -> Rc<dyn prism_rtl::Job<check_types::St>>>
                            }), move |fold_38356: check_types::St| {
                                let st2 = fold_38356;
                                call_value(fold_job(fns.clone(), st2.clone(), {
                                    let sk = sk.clone();
                                    Rc::new(move |(p0, p1): (check_types::St, check_env::Def)| {
                                        let sk = sk.clone();
                                        entered(once_job(move || {
                                            let s = p0;
                                            let d = p1;
                                            prism_rtl::Turn::More(Rc::new(LoopsOf { sk: sk.clone(), st: s.clone(), d: d.clone() }))
                                        }))
                                    }) as Rc<dyn Fn((check_types::St, check_env::Def)) -> Rc<dyn prism_rtl::Job<check_types::St>>>
                                }), move |fold_38443: check_types::St| {
                                    let st3 = fold_38443;
                                    prism_rtl::Turn::Finished((st3.clone(), refs.clone()))
                                })
                            }))
                        })
                    })
                })
            })
        })
    }
}

/// `Start ShrinkCheck, x`: what the function value is when passed to `@Run`.
pub fn start_shrink_check(g: check_env::G, st: check_types::St, defs: Array<check_env::Def>) -> Rc<dyn prism_rtl::Job<(check_types::St, Array<(Text, Array<Text>)>)>> {
    Rc::new(ShrinkCheck { g, st, defs })
}

/// ```prism
/// UnusedDefs: fn [Def], [((Text, [Text]))], Nat -> [CDiag]
/// ```
pub fn unused_defs(defs: &Array<check_env::Def>, refs: &Array<(Text, Array<Text>)>, shown: &Nat) -> Array<check_errors::CDiag> {
    let used = fold(refs, &Map::new(), &(|m: &Map<Text, ()>, (k, rs): &(Text, Array<Text>)| fold(rs, m, &(|m2: &Map<Text, ()>, r: &Text| if r == k { m2.clone() } else { insert(m2, r, &()) }))));
    let own = filter(defs, &(|d: &check_env::Def| (((&d.file < shown) && !check_env::has_key(&used, &d.qk)) && (&d.name != &Text::from("@main"))) && !is_method_def(d)));
    each(&own, &(|d: &check_env::Def| check_errors::CDiag { code: Text::from("unused"), file: d.file.clone(), span: d.span.clone(), message: Text::from(format!("nothing uses `{}`", &d.name)), fix: Text::from("delete it, or use it") }))
}

/// ```prism
/// IsMethodDef: fn Def -> Bool
/// ```
pub fn is_method_def(d: &check_env::Def) -> bool {
    match &d.body {
        check_env::DefBody::DbMethod(_, _, _) => true,
        _ => false,
    }
}

/// ```prism
/// NegativeTypes: unbounded fn G, St -> St
/// ```
pub fn negative_types(g: &check_env::G, st: &check_types::St) -> check_types::St {
    let arrowy = arrowy_types(g);
    run_to_end(fold_job(keys(&g.types), st.clone(), {
        let g = g.clone();
        let arrowy = arrowy.clone();
        Rc::new(move |(p0, p1): (check_types::St, Text)| {
            let g = g.clone();
            let arrowy = arrowy.clone();
            entered(once_job(move || {
                let s = p0;
                let n = p1;
                prism_rtl::Turn::More(Rc::new(NegativeType { g: g.clone(), s: s.clone(), arrowy: arrowy.clone(), n: n.clone() }))
            }))
        }) as Rc<dyn Fn((check_types::St, Text)) -> Rc<dyn prism_rtl::Job<check_types::St>>>
    }))
}

/// The step machine of `NegativeTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NegativeTypes: unbounded fn G, St -> St
/// ```
pub struct NegativeTypes {
    pub g: check_env::G,
    pub st: check_types::St,
}

impl prism_rtl::Job<check_types::St> for NegativeTypes {
    fn cycle(&self) -> prism_rtl::Turn<check_types::St> {
        let g = &self.g;
        let st = &self.st;
        let g = g.clone();
        let st = st.clone();
        call_then(start_arrowy_types(g.clone()), move |arrowy_types_40143: Map<Text, bool>| {
            let arrowy = arrowy_types_40143;
            fold_job(keys(&g.types), st.clone(), {
                let g = g.clone();
                let arrowy = arrowy.clone();
                Rc::new(move |(p0, p1): (check_types::St, Text)| {
                    let g = g.clone();
                    let arrowy = arrowy.clone();
                    entered(once_job(move || {
                        let s = p0;
                        let n = p1;
                        prism_rtl::Turn::More(Rc::new(NegativeType { g: g.clone(), s: s.clone(), arrowy: arrowy.clone(), n: n.clone() }))
                    }))
                }) as Rc<dyn Fn((check_types::St, Text)) -> Rc<dyn prism_rtl::Job<check_types::St>>>
            }).cycle()
        })
    }
}

/// `Start NegativeTypes, x`: what the function value is when passed to `@Run`.
pub fn start_negative_types(g: check_env::G, st: check_types::St) -> Rc<dyn prism_rtl::Job<check_types::St>> {
    Rc::new(NegativeTypes { g, st })
}

/// ```prism
/// NegativeType: unbounded fn G, St, (Text ==> Bool), Text -> St
/// ```
pub fn negative_type(g: &check_env::G, s: &check_types::St, arrowy: &Map<Text, bool>, n: &Text) -> check_types::St {
    match get(&g.types, n) {
        Some(ti) => {
            let (neg, _) = if (&ti.file >= &g.prelude_from) || !check_env::has_key(arrowy, n) {
                (false, Map::new())
            } else {
                neg_walks(g, n, &body_tys(&ti), &false, &Map::new())
            };
            if !neg {
                s.clone()
            } else {
                {
                    let s0 = {
                        let mut this: check_types::St = s.clone();
                        this.file = ti.file.clone();
                        this
                    };
                    let s1 = check_types::err_fix(&s0, &Text::from("may-not-end"), &ti.span, &Text::from(format!("`{}` stands left of a function arrow in its own definition: a call through the function it holds is a cycle, and nothing in it shrinks", &check_types::bare_name(n))), &Text::from(format!("keep `{}` right of the arrow, or make the arrow `unbounded fn`, which makes every call through it unbounded", &check_types::bare_name(n))));
                    {
                        let mut this: check_types::St = s1.clone();
                        this.file = s.file.clone();
                        this
                    }
                }
            }
        },
        None => s.clone(),
    }
}

/// The step machine of `NegativeType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NegativeType: unbounded fn G, St, (Text ==> Bool), Text -> St
/// ```
pub struct NegativeType {
    pub g: check_env::G,
    pub s: check_types::St,
    pub arrowy: Map<Text, bool>,
    pub n: Text,
}

impl prism_rtl::Job<check_types::St> for NegativeType {
    fn cycle(&self) -> prism_rtl::Turn<check_types::St> {
        let g = &self.g;
        let s = &self.s;
        let arrowy = &self.arrowy;
        let n = &self.n;
        match get(&g.types, n) {
            Some(ti) => {
                let (neg, _) = if (&ti.file >= &g.prelude_from) || !check_env::has_key(arrowy, n) {
                    (false, Map::new())
                } else {
                    neg_walks(g, n, &body_tys(&ti), &false, &Map::new())
                };
                if !neg {
                    prism_rtl::Turn::Finished(s.clone())
                } else {
                    {
                        let s0 = {
                            let mut this: check_types::St = s.clone();
                            this.file = ti.file.clone();
                            this
                        };
                        let s1 = check_types::err_fix(&s0, &Text::from("may-not-end"), &ti.span, &Text::from(format!("`{}` stands left of a function arrow in its own definition: a call through the function it holds is a cycle, and nothing in it shrinks", &check_types::bare_name(n))), &Text::from(format!("keep `{}` right of the arrow, or make the arrow `unbounded fn`, which makes every call through it unbounded", &check_types::bare_name(n))));
                        prism_rtl::Turn::Finished({
                            let mut this: check_types::St = s1.clone();
                            this.file = s.file.clone();
                            this
                        })
                    }
                }
            },
            None => prism_rtl::Turn::Finished(s.clone()),
        }
    }
}

/// `Start NegativeType, x`: what the function value is when passed to `@Run`.
pub fn start_negative_type(g: check_env::G, s: check_types::St, arrowy: Map<Text, bool>, n: Text) -> Rc<dyn prism_rtl::Job<check_types::St>> {
    Rc::new(NegativeType { g, s, arrowy, n })
}

/// ```prism
/// ArrowyTypes: unbounded fn G -> (Text ==> Bool)
/// ```
pub fn arrowy_types(g: &check_env::G) -> Map<Text, bool> {
    let names = run_to_end(fold_job(keys(&g.types), Map::new(), {
        let g = g.clone();
        Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, Text)| {
            let g = g.clone();
            entered(once_job(move || {
                let m = p0;
                let n = p1;
                match get(&g.types, &n) {
                    Some(ti) => call_value(fold_job(body_tys(&ti), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, check_types::Ty)| entered(once_job(move || {
                        let acc = p0;
                        let t = p1;
                        call_then(start_ty_names_in(t.clone()), move |ty_names_in_41439: Array<Text>| prism_rtl::Turn::Finished(check_types::union_texts(&acc, &ty_names_in_41439)))
                    }))) as Rc<dyn Fn((Array<Text>, check_types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_41387: Array<Text>| prism_rtl::Turn::Finished(insert(&m, &n, &fold_41387))),
                    None => prism_rtl::Turn::Finished(m.clone()),
                }
            }))
        }) as Rc<dyn Fn((Map<Text, Array<Text>>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
    }));
    let direct = run_to_end(fold_job(keys(&g.types), Map::new(), {
        let g = g.clone();
        Rc::new(move |(p0, p1): (Map<Text, bool>, Text)| {
            let g = g.clone();
            entered(once_job(move || {
                let m = p0;
                let n = p1;
                match get(&g.types, &n) {
                    Some(ti) => call_value(fold_job(body_tys(&ti), false, Rc::new(move |(p0, p1): (bool, check_types::Ty)| entered(once_job(move || {
                        let seen = p0;
                        let t = p1;
                        prism_rtl::Turn::Finished(seen || has_arrow(&t))
                    }))) as Rc<dyn Fn((bool, check_types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>), move |fold_41553: bool| if fold_41553 {
                        prism_rtl::Turn::Finished(insert(&m, &n, &true))
                    } else {
                        prism_rtl::Turn::Finished(m.clone())
                    }),
                    None => prism_rtl::Turn::Finished(m.clone()),
                }
            }))
        }) as Rc<dyn Fn((Map<Text, bool>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, bool>>>>
    }));
    arrowy_from(&names, &direct)
}

/// The step machine of `ArrowyTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArrowyTypes: unbounded fn G -> (Text ==> Bool)
/// ```
pub struct ArrowyTypes {
    pub g: check_env::G,
}

impl prism_rtl::Job<Map<Text, bool>> for ArrowyTypes {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, bool>> {
        let g = &self.g;
        let g = g.clone();
        call_value(fold_job(keys(&g.types), Map::new(), {
            let g = g.clone();
            Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, Text)| {
                let g = g.clone();
                entered(once_job(move || {
                    let m = p0;
                    let n = p1;
                    match get(&g.types, &n) {
                        Some(ti) => call_value(fold_job(body_tys(&ti), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, check_types::Ty)| entered(once_job(move || {
                            let acc = p0;
                            let t = p1;
                            call_then(start_ty_names_in(t.clone()), move |ty_names_in_41439: Array<Text>| prism_rtl::Turn::Finished(check_types::union_texts(&acc, &ty_names_in_41439)))
                        }))) as Rc<dyn Fn((Array<Text>, check_types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_41387: Array<Text>| prism_rtl::Turn::Finished(insert(&m, &n, &fold_41387))),
                        None => prism_rtl::Turn::Finished(m.clone()),
                    }
                }))
            }) as Rc<dyn Fn((Map<Text, Array<Text>>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
        }), move |fold_41308: Map<Text, Array<Text>>| {
            let names = fold_41308;
            call_value(fold_job(keys(&g.types), Map::new(), {
                let g = g.clone();
                Rc::new(move |(p0, p1): (Map<Text, bool>, Text)| {
                    let g = g.clone();
                    entered(once_job(move || {
                        let m = p0;
                        let n = p1;
                        match get(&g.types, &n) {
                            Some(ti) => call_value(fold_job(body_tys(&ti), false, Rc::new(move |(p0, p1): (bool, check_types::Ty)| entered(once_job(move || {
                                let seen = p0;
                                let t = p1;
                                prism_rtl::Turn::Finished(seen || has_arrow(&t))
                            }))) as Rc<dyn Fn((bool, check_types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>), move |fold_41553: bool| if fold_41553 {
                                prism_rtl::Turn::Finished(insert(&m, &n, &true))
                            } else {
                                prism_rtl::Turn::Finished(m.clone())
                            }),
                            None => prism_rtl::Turn::Finished(m.clone()),
                        }
                    }))
                }) as Rc<dyn Fn((Map<Text, bool>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, bool>>>>
            }), move |fold_41485: Map<Text, bool>| {
                let direct = fold_41485;
                prism_rtl::Turn::More(Rc::new(ArrowyFrom { names: names.clone(), got: direct.clone() }))
            })
        })
    }
}

/// `Start ArrowyTypes, x`: what the function value is when passed to `@Run`.
pub fn start_arrowy_types(g: check_env::G) -> Rc<dyn prism_rtl::Job<Map<Text, bool>>> {
    Rc::new(ArrowyTypes { g })
}

/// ```prism
/// ArrowyFrom: unbounded fn (Text ==> [Text]), (Text ==> Bool) -> (Text ==> Bool)
/// ```
pub fn arrowy_from(names: &Map<Text, Array<Text>>, got: &Map<Text, bool>) -> Map<Text, bool> {
    let next = fold(&keys(names), got, &(|m: &Map<Text, bool>, n: &Text| if check_env::has_key(m, n) {
        m.clone()
    } else {
        if fold(&or(&get(names, n), &Array::new()), &false, &(|seen: &bool, r: &Text| *seen || check_env::has_key(got, r))) {
            insert(m, n, &true)
        } else {
            m.clone()
        }
    }));
    if &len(&keys(&next)) == &len(&keys(got)) {
        got.clone()
    } else {
        arrowy_from(names, &next)
    }
}

/// The step machine of `ArrowyFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArrowyFrom: unbounded fn (Text ==> [Text]), (Text ==> Bool) -> (Text ==> Bool)
/// ```
pub struct ArrowyFrom {
    pub names: Map<Text, Array<Text>>,
    pub got: Map<Text, bool>,
}

impl prism_rtl::Job<Map<Text, bool>> for ArrowyFrom {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, bool>> {
        let names = &self.names;
        let got = &self.got;
        let next = fold(&keys(names), got, &(|m: &Map<Text, bool>, n: &Text| if check_env::has_key(m, n) {
            m.clone()
        } else {
            if fold(&or(&get(names, n), &Array::new()), &false, &(|seen: &bool, r: &Text| *seen || check_env::has_key(got, r))) {
                insert(m, n, &true)
            } else {
                m.clone()
            }
        }));
        if &len(&keys(&next)) == &len(&keys(got)) {
            prism_rtl::Turn::Finished(got.clone())
        } else {
            prism_rtl::Turn::More(Rc::new(ArrowyFrom { names: names.clone(), got: next.clone() }))
        }
    }
}

/// `Start ArrowyFrom, x`: what the function value is when passed to `@Run`.
pub fn start_arrowy_from(names: Map<Text, Array<Text>>, got: Map<Text, bool>) -> Rc<dyn prism_rtl::Job<Map<Text, bool>>> {
    Rc::new(ArrowyFrom { names, got })
}

/// ```prism
/// TyNamesIn: unbounded fn Ty -> [Text]
/// ```
pub fn ty_names_in(t: &check_types::Ty) -> Array<Text> {
    match t {
        check_types::Ty::TyCon(c, args) => run_to_end(fold_job(args.clone(), Array::from(vec![c.clone()]), Rc::new(move |(p0, p1): (Array<Text>, check_types::Ty)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_ty_names_in(a.clone()), move |ty_names_in_42235: Array<Text>| prism_rtl::Turn::Finished(check_types::union_texts(&acc, &ty_names_in_42235)))
        }))) as Rc<dyn Fn((Array<Text>, check_types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        check_types::Ty::TyFn(_, ps, res) => run_to_end(fold_job(ps.clone(), ty_names_in(&**res), Rc::new(move |(p0, p1): (Array<Text>, check_types::Ty)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_ty_names_in(a.clone()), move |ty_names_in_42327: Array<Text>| prism_rtl::Turn::Finished(check_types::union_texts(&acc, &ty_names_in_42327)))
        }))) as Rc<dyn Fn((Array<Text>, check_types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        check_types::Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, check_types::Ty)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_ty_names_in(a.clone()), move |ty_names_in_42398: Array<Text>| prism_rtl::Turn::Finished(check_types::union_texts(&acc, &ty_names_in_42398)))
        }))) as Rc<dyn Fn((Array<Text>, check_types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)),
        check_types::Ty::TyArray(e) => ty_names_in(&**e),
        check_types::Ty::TyMap(k, v_) => check_types::union_texts(&ty_names_in(&**k), &ty_names_in(&**v_)),
        check_types::Ty::TySig(_, i) => ty_names_in(&**i),
        check_types::Ty::TyAt(i, _) => ty_names_in(&**i),
        check_types::Ty::TyElem(_, i) => ty_names_in(&**i),
        check_types::Ty::TyAssoc(_, i) => ty_names_in(&**i),
        _ => Array::new(),
    }
}

/// The step machine of `TyNamesIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TyNamesIn: unbounded fn Ty -> [Text]
/// ```
pub struct TyNamesIn {
    pub t: check_types::Ty,
}

impl prism_rtl::Job<Array<Text>> for TyNamesIn {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let t = &self.t;
        match t {
            check_types::Ty::TyCon(c, args) => fold_job(args.clone(), Array::from(vec![c.clone()]), Rc::new(move |(p0, p1): (Array<Text>, check_types::Ty)| entered(once_job(move || {
                let acc = p0;
                let a = p1;
                call_then(start_ty_names_in(a.clone()), move |ty_names_in_42235: Array<Text>| prism_rtl::Turn::Finished(check_types::union_texts(&acc, &ty_names_in_42235)))
            }))) as Rc<dyn Fn((Array<Text>, check_types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            check_types::Ty::TyFn(_, ps, res) => {
                let ps = ps.clone();
                let res = (**res).clone();
                call_then(start_ty_names_in(res.clone()), move |ty_names_in_42284: Array<Text>| fold_job(ps.clone(), ty_names_in_42284, Rc::new(move |(p0, p1): (Array<Text>, check_types::Ty)| entered(once_job(move || {
                    let acc = p0;
                    let a = p1;
                    call_then(start_ty_names_in(a.clone()), move |ty_names_in_42327: Array<Text>| prism_rtl::Turn::Finished(check_types::union_texts(&acc, &ty_names_in_42327)))
                }))) as Rc<dyn Fn((Array<Text>, check_types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle())
            },
            check_types::Ty::TyTuple(ts) => fold_job(ts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, check_types::Ty)| entered(once_job(move || {
                let acc = p0;
                let a = p1;
                call_then(start_ty_names_in(a.clone()), move |ty_names_in_42398: Array<Text>| prism_rtl::Turn::Finished(check_types::union_texts(&acc, &ty_names_in_42398)))
            }))) as Rc<dyn Fn((Array<Text>, check_types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle(),
            check_types::Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(TyNamesIn { t: (**e).clone() })),
            check_types::Ty::TyMap(k, v_) => {
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_ty_names_in(k.clone()), move |ty_names_in_42466: Array<Text>| call_then(start_ty_names_in(v_.clone()), move |ty_names_in_42481: Array<Text>| prism_rtl::Turn::Finished(check_types::union_texts(&ty_names_in_42466, &ty_names_in_42481))))
            },
            check_types::Ty::TySig(_, i) => prism_rtl::Turn::More(Rc::new(TyNamesIn { t: (**i).clone() })),
            check_types::Ty::TyAt(i, _) => prism_rtl::Turn::More(Rc::new(TyNamesIn { t: (**i).clone() })),
            check_types::Ty::TyElem(_, i) => prism_rtl::Turn::More(Rc::new(TyNamesIn { t: (**i).clone() })),
            check_types::Ty::TyAssoc(_, i) => prism_rtl::Turn::More(Rc::new(TyNamesIn { t: (**i).clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start TyNamesIn, x`: what the function value is when passed to `@Run`.
pub fn start_ty_names_in(t: check_types::Ty) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(TyNamesIn { t })
}

/// ```prism
/// HasArrow: unbounded fn Ty -> Bool
/// ```
pub fn has_arrow(t: &check_types::Ty) -> bool {
    match t {
        check_types::Ty::TyFn(_, _, _) => true,
        check_types::Ty::TyCon(_, args) => run_to_end(fold_job(args.clone(), false, Rc::new(move |(p0, p1): (bool, check_types::Ty)| entered(once_job(move || {
            let seen = p0;
            let a = p1;
            prism_rtl::Turn::Finished(seen || has_arrow(&a))
        }))) as Rc<dyn Fn((bool, check_types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        check_types::Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), false, Rc::new(move |(p0, p1): (bool, check_types::Ty)| entered(once_job(move || {
            let seen = p0;
            let a = p1;
            prism_rtl::Turn::Finished(seen || has_arrow(&a))
        }))) as Rc<dyn Fn((bool, check_types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        check_types::Ty::TyArray(e) => has_arrow(&**e),
        check_types::Ty::TyMap(k, v_) => has_arrow(&**k) || has_arrow(&**v_),
        check_types::Ty::TySig(_, i) => has_arrow(&**i),
        check_types::Ty::TyAt(i, _) => has_arrow(&**i),
        check_types::Ty::TyElem(_, i) => has_arrow(&**i),
        check_types::Ty::TyAssoc(_, i) => has_arrow(&**i),
        _ => false,
    }
}

/// The step machine of `HasArrow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HasArrow: unbounded fn Ty -> Bool
/// ```
pub struct HasArrow {
    pub t: check_types::Ty,
}

impl prism_rtl::Job<bool> for HasArrow {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t = &self.t;
        match t {
            check_types::Ty::TyFn(_, _, _) => prism_rtl::Turn::Finished(true),
            check_types::Ty::TyCon(_, args) => fold_job(args.clone(), false, Rc::new(move |(p0, p1): (bool, check_types::Ty)| entered(once_job(move || {
                let seen = p0;
                let a = p1;
                prism_rtl::Turn::Finished(seen || has_arrow(&a))
            }))) as Rc<dyn Fn((bool, check_types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            check_types::Ty::TyTuple(ts) => fold_job(ts.clone(), false, Rc::new(move |(p0, p1): (bool, check_types::Ty)| entered(once_job(move || {
                let seen = p0;
                let a = p1;
                prism_rtl::Turn::Finished(seen || has_arrow(&a))
            }))) as Rc<dyn Fn((bool, check_types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            check_types::Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(HasArrow { t: (**e).clone() })),
            check_types::Ty::TyMap(k, v_) => {
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_has_arrow(k.clone()), move |has_arrow_42923: bool| prism_rtl::Turn::Finished(has_arrow_42923 || has_arrow(&v_)))
            },
            check_types::Ty::TySig(_, i) => prism_rtl::Turn::More(Rc::new(HasArrow { t: (**i).clone() })),
            check_types::Ty::TyAt(i, _) => prism_rtl::Turn::More(Rc::new(HasArrow { t: (**i).clone() })),
            check_types::Ty::TyElem(_, i) => prism_rtl::Turn::More(Rc::new(HasArrow { t: (**i).clone() })),
            check_types::Ty::TyAssoc(_, i) => prism_rtl::Turn::More(Rc::new(HasArrow { t: (**i).clone() })),
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start HasArrow, x`: what the function value is when passed to `@Run`.
pub fn start_has_arrow(t: check_types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(HasArrow { t })
}

/// ```prism
/// BodyTys: fn TyInfo -> [Ty]
/// ```
pub fn body_tys(ti: &check_env::TyInfo) -> Array<check_types::Ty> {
    match &ti.body {
        check_env::TyBody::BRecord(fields) => each(fields, &(|(_, t): &(Text, check_types::Ty)| t.clone())),
        check_env::TyBody::BChoice(cases) => fold(cases, &Array::new(), &(|acc: &Array<check_types::Ty>, (_, args): &(Text, Array<check_types::Ty>)| append(acc, args))),
        check_env::TyBody::BAlias(t) => Array::from(vec![t.clone()]),
        _ => Array::new(),
    }
}

/// ```prism
/// NegWalk: unbounded fn G, Text, Ty, Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
/// ```
pub fn neg_walk(g: &check_env::G, target: &Text, t: &check_types::Ty, b: &bool, seen: &Map<Text, bool>) -> (bool, Map<Text, bool>) {
    match t {
        check_types::Ty::TyCon(c, args) => if c == target {
            (*b, seen.clone())
        } else {
            match get(&g.types, c) {
                Some(ti) => {
                    let sk = Text::from(format!("{}{}", &(if *b { Text::from("-") } else { Text::from("+") }), &check_types::show_ty(&check_types::new_st(&Nat::from(0u32)), t)));
                    if check_env::has_key(seen, &sk) {
                        (false, seen.clone())
                    } else {
                        if &len(&keys(seen)) > &Nat::from(400u32) {
                            (true, seen.clone())
                        } else {
                            neg_walks(g, target, &run_to_end(each_job(body_tys(&ti), {
                                let ti = ti.clone();
                                let args = args.clone();
                                Rc::new(move |p0: check_types::Ty| {
                                    let ti = ti.clone();
                                    let args = args.clone();
                                    entered(once_job(move || {
                                        let bt = p0;
                                        prism_rtl::Turn::More(Rc::new(check_types::SubstQ { m: check_env::param_inst(&ti.params, &args), t: bt.clone() }))
                                    }))
                                }) as Rc<dyn Fn(check_types::Ty) -> Rc<dyn prism_rtl::Job<check_types::Ty>>>
                            })), b, &insert(seen, &sk, &true))
                        }
                    }
                },
                None => neg_walks(g, target, args, b, seen),
            }
        },
        check_types::Ty::TyFn(col, ps, res) => {
            let (bad, seen2) = neg_walks(g, target, ps, &(*b || (col != &check_types::Col::CUnbound)), seen);
            if bad { (true, seen2.clone()) } else { neg_walk(g, target, &**res, b, &seen2) }
        },
        check_types::Ty::TyTuple(ts) => neg_walks(g, target, ts, b, seen),
        check_types::Ty::TyArray(e) => neg_walk(g, target, &**e, b, seen),
        check_types::Ty::TyMap(k, v_) => neg_walks(g, target, &Array::from(vec![(**k).clone(), (**v_).clone()]), b, seen),
        check_types::Ty::TySig(_, i) => neg_walk(g, target, &**i, b, seen),
        check_types::Ty::TyAt(i, _) => neg_walk(g, target, &**i, b, seen),
        check_types::Ty::TyElem(_, i) => neg_walk(g, target, &**i, b, seen),
        check_types::Ty::TyAssoc(_, i) => neg_walk(g, target, &**i, b, seen),
        _ => (false, seen.clone()),
    }
}

/// The step machine of `NegWalk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NegWalk: unbounded fn G, Text, Ty, Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
/// ```
pub struct NegWalk {
    pub g: check_env::G,
    pub target: Text,
    pub t: check_types::Ty,
    pub b: bool,
    pub seen: Map<Text, bool>,
}

impl prism_rtl::Job<(bool, Map<Text, bool>)> for NegWalk {
    fn cycle(&self) -> prism_rtl::Turn<(bool, Map<Text, bool>)> {
        let g = &self.g;
        let target = &self.target;
        let t = &self.t;
        let b = &self.b;
        let seen = &self.seen;
        match t {
            check_types::Ty::TyCon(c, args) => if c == target {
                prism_rtl::Turn::Finished((*b, seen.clone()))
            } else {
                match get(&g.types, c) {
                    Some(ti) => {
                        let args = args.clone();
                        let b = *b;
                        let g = g.clone();
                        let seen = seen.clone();
                        let t = t.clone();
                        let target = target.clone();
                        call_then(check_types::start_show_ty(check_types::new_st(&Nat::from(0u32)), t.clone()), move |show_ty_44060: Text| {
                            let sk = Text::from(format!("{}{}", &(if b { Text::from("-") } else { Text::from("+") }), &show_ty_44060));
                            if check_env::has_key(&seen, &sk) {
                                prism_rtl::Turn::Finished((false, seen.clone()))
                            } else {
                                if &len(&keys(&seen)) > &Nat::from(400u32) {
                                    prism_rtl::Turn::Finished((true, seen.clone()))
                                } else {
                                    call_value(each_job(body_tys(&ti), {
                                        let ti = ti.clone();
                                        let args = args.clone();
                                        Rc::new(move |p0: check_types::Ty| {
                                            let ti = ti.clone();
                                            let args = args.clone();
                                            entered(once_job(move || {
                                                let bt = p0;
                                                prism_rtl::Turn::More(Rc::new(check_types::SubstQ { m: check_env::param_inst(&ti.params, &args), t: bt.clone() }))
                                            }))
                                        }) as Rc<dyn Fn(check_types::Ty) -> Rc<dyn prism_rtl::Job<check_types::Ty>>>
                                    }), move |each_44242: Array<check_types::Ty>| prism_rtl::Turn::More(Rc::new(NegWalks { g: g.clone(), target: target.clone(), ts: each_44242, b, seen: insert(&seen, &sk, &true) })))
                                }
                            }
                        })
                    },
                    None => prism_rtl::Turn::More(Rc::new(NegWalks { g: g.clone(), target: target.clone(), ts: args.clone(), b: *b, seen: seen.clone() })),
                }
            },
            check_types::Ty::TyFn(col, ps, res) => {
                let b = *b;
                let col = col.clone();
                let g = g.clone();
                let ps = ps.clone();
                let res = (**res).clone();
                let seen = seen.clone();
                let target = target.clone();
                call_then(start_neg_walks(g.clone(), target.clone(), ps.clone(), b || (&col != &check_types::Col::CUnbound), seen.clone()), move |neg_walks_44438: (bool, Map<Text, bool>)| {
                    let (bad, seen2) = neg_walks_44438;
                    if bad {
                        prism_rtl::Turn::Finished((true, seen2.clone()))
                    } else {
                        prism_rtl::Turn::More(Rc::new(NegWalk { g: g.clone(), target: target.clone(), t: res.clone(), b, seen: seen2.clone() }))
                    }
                })
            },
            check_types::Ty::TyTuple(ts) => prism_rtl::Turn::More(Rc::new(NegWalks { g: g.clone(), target: target.clone(), ts: ts.clone(), b: *b, seen: seen.clone() })),
            check_types::Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(NegWalk { g: g.clone(), target: target.clone(), t: (**e).clone(), b: *b, seen: seen.clone() })),
            check_types::Ty::TyMap(k, v_) => prism_rtl::Turn::More(Rc::new(NegWalks { g: g.clone(), target: target.clone(), ts: Array::from(vec![(**k).clone(), (**v_).clone()]), b: *b, seen: seen.clone() })),
            check_types::Ty::TySig(_, i) => prism_rtl::Turn::More(Rc::new(NegWalk { g: g.clone(), target: target.clone(), t: (**i).clone(), b: *b, seen: seen.clone() })),
            check_types::Ty::TyAt(i, _) => prism_rtl::Turn::More(Rc::new(NegWalk { g: g.clone(), target: target.clone(), t: (**i).clone(), b: *b, seen: seen.clone() })),
            check_types::Ty::TyElem(_, i) => prism_rtl::Turn::More(Rc::new(NegWalk { g: g.clone(), target: target.clone(), t: (**i).clone(), b: *b, seen: seen.clone() })),
            check_types::Ty::TyAssoc(_, i) => prism_rtl::Turn::More(Rc::new(NegWalk { g: g.clone(), target: target.clone(), t: (**i).clone(), b: *b, seen: seen.clone() })),
            _ => prism_rtl::Turn::Finished((false, seen.clone())),
        }
    }
}

/// `Start NegWalk, x`: what the function value is when passed to `@Run`.
pub fn start_neg_walk(g: check_env::G, target: Text, t: check_types::Ty, b: bool, seen: Map<Text, bool>) -> Rc<dyn prism_rtl::Job<(bool, Map<Text, bool>)>> {
    Rc::new(NegWalk { g, target, t, b, seen })
}

/// ```prism
/// NegWalks: unbounded fn G, Text, [Ty], Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
/// ```
pub fn neg_walks(g: &check_env::G, target: &Text, ts: &Array<check_types::Ty>, b: &bool, seen: &Map<Text, bool>) -> (bool, Map<Text, bool>) {
    run_to_end(fold_job(ts.clone(), (false, seen.clone()), {
        let g = g.clone();
        let target = target.clone();
        let b = *b;
        Rc::new(move |(p0, p1): ((bool, Map<Text, bool>), check_types::Ty)| {
            let g = g.clone();
            let target = target.clone();
            let b = b;
            entered(once_job(move || {
                let (bad, sn) = p0;
                let t = p1;
                if bad {
                    prism_rtl::Turn::Finished((true, sn.clone()))
                } else {
                    prism_rtl::Turn::More(Rc::new(NegWalk { g: g.clone(), target: target.clone(), t: t.clone(), b, seen: sn.clone() }))
                }
            }))
        }) as Rc<dyn Fn(((bool, Map<Text, bool>), check_types::Ty)) -> Rc<dyn prism_rtl::Job<(bool, Map<Text, bool>)>>>
    }))
}

/// The step machine of `NegWalks`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NegWalks: unbounded fn G, Text, [Ty], Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
/// ```
pub struct NegWalks {
    pub g: check_env::G,
    pub target: Text,
    pub ts: Array<check_types::Ty>,
    pub b: bool,
    pub seen: Map<Text, bool>,
}

impl prism_rtl::Job<(bool, Map<Text, bool>)> for NegWalks {
    fn cycle(&self) -> prism_rtl::Turn<(bool, Map<Text, bool>)> {
        let g = &self.g;
        let target = &self.target;
        let ts = &self.ts;
        let b = &self.b;
        let seen = &self.seen;
        fold_job(ts.clone(), (false, seen.clone()), {
            let g = g.clone();
            let target = target.clone();
            let b = *b;
            Rc::new(move |(p0, p1): ((bool, Map<Text, bool>), check_types::Ty)| {
                let g = g.clone();
                let target = target.clone();
                let b = b;
                entered(once_job(move || {
                    let (bad, sn) = p0;
                    let t = p1;
                    if bad {
                        prism_rtl::Turn::Finished((true, sn.clone()))
                    } else {
                        prism_rtl::Turn::More(Rc::new(NegWalk { g: g.clone(), target: target.clone(), t: t.clone(), b, seen: sn.clone() }))
                    }
                }))
            }) as Rc<dyn Fn(((bool, Map<Text, bool>), check_types::Ty)) -> Rc<dyn prism_rtl::Job<(bool, Map<Text, bool>)>>>
        }).cycle()
    }
}

/// `Start NegWalks, x`: what the function value is when passed to `@Run`.
pub fn start_neg_walks(g: check_env::G, target: Text, ts: Array<check_types::Ty>, b: bool, seen: Map<Text, bool>) -> Rc<dyn prism_rtl::Job<(bool, Map<Text, bool>)>> {
    Rc::new(NegWalks { g, target, ts, b, seen })
}

/// ```prism
/// NatMinusSeeds: unbounded fn St -> (Text ==> Rel)
/// ```
pub fn nat_minus_seeds(st: &check_types::St) -> Map<Text, Rel> {
    run_to_end(fold_job(keys(&st.size_tys), Map::new(), {
        let st = st.clone();
        Rc::new(move |(p0, p1): (Map<Text, Rel>, Text)| {
            let st = st.clone();
            entered(once_job(move || {
                let m = p0;
                let k = p1;
                match get(&st.size_tys, &k) {
                    Some(t) => call_then(check_types::start_zonk(st.clone(), t.clone()), move |zonk_45401: check_types::Ty| if &zonk_45401 == &check_types::t_nat() {
                        prism_rtl::Turn::Finished(insert(&m, &Text::from(format!("nat:{}", &k)), &no_rel()))
                    } else {
                        prism_rtl::Turn::Finished(m.clone())
                    }),
                    None => prism_rtl::Turn::Finished(m.clone()),
                }
            }))
        }) as Rc<dyn Fn((Map<Text, Rel>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>>>
    }))
}

/// The step machine of `NatMinusSeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NatMinusSeeds: unbounded fn St -> (Text ==> Rel)
/// ```
pub struct NatMinusSeeds {
    pub st: check_types::St,
}

impl prism_rtl::Job<Map<Text, Rel>> for NatMinusSeeds {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Rel>> {
        let st = &self.st;
        fold_job(keys(&st.size_tys), Map::new(), {
            let st = st.clone();
            Rc::new(move |(p0, p1): (Map<Text, Rel>, Text)| {
                let st = st.clone();
                entered(once_job(move || {
                    let m = p0;
                    let k = p1;
                    match get(&st.size_tys, &k) {
                        Some(t) => call_then(check_types::start_zonk(st.clone(), t.clone()), move |zonk_45401: check_types::Ty| if &zonk_45401 == &check_types::t_nat() {
                            prism_rtl::Turn::Finished(insert(&m, &Text::from(format!("nat:{}", &k)), &no_rel()))
                        } else {
                            prism_rtl::Turn::Finished(m.clone())
                        }),
                        None => prism_rtl::Turn::Finished(m.clone()),
                    }
                }))
            }) as Rc<dyn Fn((Map<Text, Rel>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>>>
        }).cycle()
    }
}

/// `Start NatMinusSeeds, x`: what the function value is when passed to `@Run`.
pub fn start_nat_minus_seeds(st: check_types::St) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>> {
    Rc::new(NatMinusSeeds { st })
}

/// ```prism
/// DefClauses: fn Def -> [FnClause]
/// ```
pub fn def_clauses(d: &check_env::Def) -> Array<ast::FnClause> {
    match &d.body {
        check_env::DefBody::DbFn(clauses) => clauses.clone(),
        check_env::DefBody::DbMethod(clauses, _, _) => clauses.clone(),
        check_env::DefBody::DbDefault(clauses, _) => clauses.clone(),
        check_env::DefBody::DbWidget(w) => Array::from(vec![ast::FnClause { name: ast::DefName::DefSName(w.name.clone()), params: Array::new(), body: ast::FnBody::BodyBlock(w.body.clone()), span: w.span.clone() }]),
        check_env::DefBody::DbLet(l) => Array::from(vec![ast::FnClause { name: ast::DefName::DefOp(d.name.clone(), l.span.clone()), params: Array::new(), body: ast::FnBody::BodyExpr(l.value.clone()), span: l.span.clone() }]),
        _ => Array::new(),
    }
}

/// ```prism
/// OwnKey: fn Def -> Def
/// ```
pub fn own_key(d: &check_env::Def) -> check_env::Def {
    match &d.body {
        check_env::DefBody::DbMethod(_, _, im) => {
            let mut this: check_env::Def = d.clone();
            this.qk = Text::from(format!("{} #{}.{}", &d.qk, &im.file, &im.span.start));
            this
        },
        _ => d.clone(),
    }
}

/// ```prism
/// ?MethodOf: fn G, Def -> ?Text
/// ```
pub fn method_of(g: &check_env::G, d: &check_env::Def) -> Option<Text> {
    match &d.body {
        check_env::DefBody::DbMethod(_, cls, _) => method_key(g, cls, &d.name),
        check_env::DefBody::DbDefault(_, cls) => method_key(g, cls, &d.name),
        _ => None,
    }
}

/// ```prism
/// MethodTargets: fn G, [Def] -> (Text ==> [Text])
/// ```
pub fn method_targets(g: &check_env::G, fns: &Array<check_env::Def>) -> Map<Text, Array<Text>> {
    fold(fns, &Map::new(), &(|m: &Map<Text, Array<Text>>, d: &check_env::Def| match method_of(g, d) {
        Some(mk) => insert(m, &mk, &check_types::add_text(&or(&get(m, &mk), &Array::new()), &d.qk)),
        None => m.clone(),
    }))
}

/// ```prism
/// ImplDefs: fn G, [Def] -> (Text ==> Text)
/// ```
pub fn impl_defs(g: &check_env::G, fns: &Array<check_env::Def>) -> Map<Text, Text> {
    fold(fns, &Map::new(), &(|m: &Map<Text, Text>, d: &check_env::Def| match &d.body {
        check_env::DefBody::DbMethod(_, _, im) => match method_of(g, d) {
            Some(mk) => insert(m, &Text::from(format!("{}|{}.{}", &mk, &im.file, &im.span.start)), &d.qk),
            None => m.clone(),
        },
        _ => m.clone(),
    }))
}

/// ```prism
/// ?MethodClass: fn G, Text -> ?Text
/// ```
pub fn method_class(g: &check_env::G, k: &Text) -> Option<Text> {
    match get(&g.vals, k) {
        Some(v_) => if &v_.sort != &Text::from("method") {
            None
        } else {
            match index(&v_.scheme.bounds, &Nat::from(0u32)) {
                Some((_, cls)) => Some(cls.clone()),
                None => None,
            }
        },
        None => None,
    }
}

/// ```prism
/// DispatchTargets: unbounded fn Shrink, Def, Site, Text -> [Text]
/// ```
pub fn dispatch_targets(sk: &Shrink, d: &check_env::Def, site: &Site, k: &Text) -> Array<Text> {
    let all = targets_of(sk, k);
    match method_class(&sk.g, k) {
        None => all.clone(),
        Some(cls) => {
            let ck = check_types::choice_key(&d.file, &site.span, &cls);
            match get(&sk.choices, &ck) {
                None => all.clone(),
                Some(cs) => run_to_end(fold_job(cs.clone(), Array::new(), {
                    let sk = sk.clone();
                    let k = k.clone();
                    let cls = cls.clone();
                    let all = all.clone();
                    Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                        let sk = sk.clone();
                        let k = k.clone();
                        let cls = cls.clone();
                        let all = all.clone();
                        entered(once_job(move || {
                            let acc = p0;
                            let ch = p1;
                            call_then(start_choice_targets(sk.clone(), k.clone(), cls.clone(), all.clone(), ch.clone(), Array::new()), move |choice_targets_48794: Array<Text>| prism_rtl::Turn::Finished(check_types::union_texts(&acc, &choice_targets_48794)))
                        }))
                    }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                })),
            }
        },
    }
}

/// The step machine of `DispatchTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DispatchTargets: unbounded fn Shrink, Def, Site, Text -> [Text]
/// ```
pub struct DispatchTargets {
    pub sk: Shrink,
    pub d: check_env::Def,
    pub site: Site,
    pub k: Text,
}

impl prism_rtl::Job<Array<Text>> for DispatchTargets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let sk = &self.sk;
        let d = &self.d;
        let site = &self.site;
        let k = &self.k;
        let all = targets_of(sk, k);
        match method_class(&sk.g, k) {
            None => prism_rtl::Turn::Finished(all.clone()),
            Some(cls) => {
                let ck = check_types::choice_key(&d.file, &site.span, &cls);
                match get(&sk.choices, &ck) {
                    None => prism_rtl::Turn::Finished(all.clone()),
                    Some(cs) => fold_job(cs.clone(), Array::new(), {
                        let sk = sk.clone();
                        let k = k.clone();
                        let cls = cls.clone();
                        let all = all.clone();
                        Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                            let sk = sk.clone();
                            let k = k.clone();
                            let cls = cls.clone();
                            let all = all.clone();
                            entered(once_job(move || {
                                let acc = p0;
                                let ch = p1;
                                call_then(start_choice_targets(sk.clone(), k.clone(), cls.clone(), all.clone(), ch.clone(), Array::new()), move |choice_targets_48794: Array<Text>| prism_rtl::Turn::Finished(check_types::union_texts(&acc, &choice_targets_48794)))
                            }))
                        }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }).cycle(),
                }
            },
        }
    }
}

/// `Start DispatchTargets, x`: what the function value is when passed to `@Run`.
pub fn start_dispatch_targets(sk: Shrink, d: check_env::Def, site: Site, k: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(DispatchTargets { sk, d, site, k })
}

/// ```prism
/// ChoiceTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
/// ```
pub fn choice_targets(sk: &Shrink, k: &Text, cls: &Text, all: &Array<Text>, ch: &Text, seen: &Array<Text>) -> Array<Text> {
    if ch == &Text::from("none") {
        Array::new()
    } else {
        if lexer::has_prefix(ch, &Text::from("impl:")) {
            match get(&sk.impl_defs, &Text::from(format!("{}|{}", k, &lexer::drop_prefix(ch, &Text::from("impl:"))))) {
                Some(q) => Array::from(vec![q.clone()]),
                None => filter(all, &(|q: &Text| q == k)),
            }
        } else {
            if lexer::has_prefix(ch, &Text::from("derived:")) {
                derived_targets(sk, k, cls, all, &lexer::drop_prefix(ch, &Text::from("derived:")), seen)
            } else {
                all.clone()
            }
        }
    }
}

/// The step machine of `ChoiceTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ChoiceTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
/// ```
pub struct ChoiceTargets {
    pub sk: Shrink,
    pub k: Text,
    pub cls: Text,
    pub all: Array<Text>,
    pub ch: Text,
    pub seen: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for ChoiceTargets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let sk = &self.sk;
        let k = &self.k;
        let cls = &self.cls;
        let all = &self.all;
        let ch = &self.ch;
        let seen = &self.seen;
        if ch == &Text::from("none") {
            prism_rtl::Turn::Finished(Array::new())
        } else {
            if lexer::has_prefix(ch, &Text::from("impl:")) {
                match get(&sk.impl_defs, &Text::from(format!("{}|{}", k, &lexer::drop_prefix(ch, &Text::from("impl:"))))) {
                    Some(q) => prism_rtl::Turn::Finished(Array::from(vec![q.clone()])),
                    None => prism_rtl::Turn::Finished(filter(all, &(|q: &Text| q == k))),
                }
            } else {
                if lexer::has_prefix(ch, &Text::from("derived:")) {
                    prism_rtl::Turn::More(Rc::new(DerivedTargets { sk: sk.clone(), k: k.clone(), cls: cls.clone(), all: all.clone(), n: lexer::drop_prefix(ch, &Text::from("derived:")), seen: seen.clone() }))
                } else {
                    prism_rtl::Turn::Finished(all.clone())
                }
            }
        }
    }
}

/// `Start ChoiceTargets, x`: what the function value is when passed to `@Run`.
pub fn start_choice_targets(sk: Shrink, k: Text, cls: Text, all: Array<Text>, ch: Text, seen: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ChoiceTargets { sk, k, cls, all, ch, seen })
}

/// ```prism
/// DerivedTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
/// ```
pub fn derived_targets(sk: &Shrink, k: &Text, cls: &Text, all: &Array<Text>, n: &Text, seen: &Array<Text>) -> Array<Text> {
    if check_types::has_text(seen, n) {
        Array::new()
    } else {
        {
            let tys = match get(&sk.g.types, n) {
                Some(ti) => match &ti.body {
                    check_env::TyBody::BRecord(fields) => each(fields, &(|(_, t): &(Text, check_types::Ty)| t.clone())),
                    check_env::TyBody::BChoice(cases) => fold(cases, &Array::new(), &(|acc: &Array<check_types::Ty>, (_, args): &(Text, Array<check_types::Ty>)| append(acc, args))),
                    check_env::TyBody::BAlias(t) => Array::from(vec![t.clone()]),
                    _ => Array::new(),
                },
                None => Array::new(),
            };
            let heads = fold(&tys, &Array::new(), &(|acc: &Array<Text>, t: &check_types::Ty| check_types::union_texts(acc, &ty_heads(t))));
            run_to_end(fold_job(heads.clone(), Array::new(), {
                let sk = sk.clone();
                let k = k.clone();
                let cls = cls.clone();
                let all = all.clone();
                let seen = seen.clone();
                let n = n.clone();
                Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                    let sk = sk.clone();
                    let k = k.clone();
                    let cls = cls.clone();
                    let all = all.clone();
                    let seen = seen.clone();
                    let n = n.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let h = p1;
                        prism_rtl::Turn::Finished(check_types::union_texts(&acc, &head_targets(&sk, &k, &cls, &all, &h, &push(&seen, &n))))
                    }))
                }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }))
        }
    }
}

/// The step machine of `DerivedTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DerivedTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
/// ```
pub struct DerivedTargets {
    pub sk: Shrink,
    pub k: Text,
    pub cls: Text,
    pub all: Array<Text>,
    pub n: Text,
    pub seen: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for DerivedTargets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let sk = &self.sk;
        let k = &self.k;
        let cls = &self.cls;
        let all = &self.all;
        let n = &self.n;
        let seen = &self.seen;
        if check_types::has_text(seen, n) {
            prism_rtl::Turn::Finished(Array::new())
        } else {
            {
                let tys = match get(&sk.g.types, n) {
                    Some(ti) => match &ti.body {
                        check_env::TyBody::BRecord(fields) => each(fields, &(|(_, t): &(Text, check_types::Ty)| t.clone())),
                        check_env::TyBody::BChoice(cases) => fold(cases, &Array::new(), &(|acc: &Array<check_types::Ty>, (_, args): &(Text, Array<check_types::Ty>)| append(acc, args))),
                        check_env::TyBody::BAlias(t) => Array::from(vec![t.clone()]),
                        _ => Array::new(),
                    },
                    None => Array::new(),
                };
                let heads = fold(&tys, &Array::new(), &(|acc: &Array<Text>, t: &check_types::Ty| check_types::union_texts(acc, &ty_heads(t))));
                fold_job(heads.clone(), Array::new(), {
                    let sk = sk.clone();
                    let k = k.clone();
                    let cls = cls.clone();
                    let all = all.clone();
                    let seen = seen.clone();
                    let n = n.clone();
                    Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                        let sk = sk.clone();
                        let k = k.clone();
                        let cls = cls.clone();
                        let all = all.clone();
                        let seen = seen.clone();
                        let n = n.clone();
                        entered(once_job(move || {
                            let acc = p0;
                            let h = p1;
                            prism_rtl::Turn::Finished(check_types::union_texts(&acc, &head_targets(&sk, &k, &cls, &all, &h, &push(&seen, &n))))
                        }))
                    }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }).cycle()
            }
        }
    }
}

/// `Start DerivedTargets, x`: what the function value is when passed to `@Run`.
pub fn start_derived_targets(sk: Shrink, k: Text, cls: Text, all: Array<Text>, n: Text, seen: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(DerivedTargets { sk, k, cls, all, n, seen })
}

/// ```prism
/// TyHeads: fn Ty -> [Text]
/// ```
pub fn ty_heads(t: &check_types::Ty) -> Array<Text> {
    match t {
        check_types::Ty::TyCon(n, args) => fold(args, &Array::from(vec![n.clone()]), &(|acc: &Array<Text>, a: &check_types::Ty| check_types::union_texts(acc, &ty_heads(a)))),
        check_types::Ty::TyTuple(ts) => fold(ts, &Array::new(), &(|acc: &Array<Text>, a: &check_types::Ty| check_types::union_texts(acc, &ty_heads(a)))),
        check_types::Ty::TyArray(e) => ty_heads(&**e),
        check_types::Ty::TyMap(a, b) => check_types::union_texts(&ty_heads(&**a), &ty_heads(&**b)),
        check_types::Ty::TySig(_, i) => ty_heads(&**i),
        check_types::Ty::TyQ(_) => Array::new(),
        check_types::Ty::TyRigid(_) => Array::new(),
        check_types::Ty::TyFn(_, _, _) => Array::new(),
        check_types::Ty::TyElem(_, _) => Array::new(),
        check_types::Ty::TyElemAny(_) => Array::new(),
        _ => Array::from(vec![Text::from("?")]),
    }
}

/// ```prism
/// HeadTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
/// ```
pub fn head_targets(sk: &Shrink, k: &Text, cls: &Text, all: &Array<Text>, h: &Text, seen: &Array<Text>) -> Array<Text> {
    if h == &Text::from("?") {
        all.clone()
    } else {
        if check_env::builtin_has(cls, h) || check_env::is_prim_type(h) {
            Array::new()
        } else {
            match index(&filter(&or(&get(&sk.g.impls, cls), &Array::new()), &(|im: &check_env::ImplInfo| &head_key(&im.head) == &Some(h.clone()))), &Nat::from(0u32)) {
                Some(im) => choice_targets(sk, k, cls, all, &check_env::impl_choice(&im), seen),
                None => all.clone(),
            }
        }
    }
}

/// ```prism
/// ?HeadKey: fn Ty -> ?Text
/// ```
pub fn head_key(ty0: &check_types::Ty) -> Option<Text> {
    match ty0 {
        check_types::Ty::TyCon(n, _) => Some(n.clone()),
        _ => None,
    }
}

/// ```prism
/// TargetsOf: fn Shrink, Text -> [Text]
/// ```
pub fn targets_of(sk: &Shrink, k: &Text) -> Array<Text> {
    or(&get(&sk.targets, k), &Array::from(vec![k.clone()]))
}

/// ```prism
/// SigKeyOf: fn Shrink, Text -> Text
/// ```
pub fn sig_key_of(sk: &Shrink, k: &Text) -> Text {
    match get(&sk.by_key, k) {
        Some(d) => or(&method_of(&sk.g, &d), k),
        None => k.clone(),
    }
}

/// ```prism
/// ShownKey: fn Text -> Text
/// ```
pub fn shown_key(k: &Text) -> Text {
    check_types::bare_name(&or(&index(&split(&or(&lexer::last(&split(k, &Text::from(" impl "))), k), &Text::from(" #")), &Nat::from(0u32)), k))
}

/// ```prism
/// IsUnboundedKey: fn G, Text -> Bool
/// ```
pub fn is_unbounded_key(g: &check_env::G, k: &Text) -> bool {
    match get(&g.vals, k) {
        Some(v_) => match &v_.scheme.ty {
            check_types::Ty::TyFn(check_types::Col::CUnbound, _, _) => true,
            _ => false,
        },
        None => false,
    }
}

/// ```prism
/// HofSeeds: unbounded fn Shrink, [Text] -> (Text ==> (Text ==> Rel))
/// ```
pub fn hof_seeds(sk: &Shrink, homes: &Array<Text>) -> Map<Text, Map<Text, Rel>> {
    let cands = hof_candidates(sk);
    let cleared = clear_slots(sk, homes, &cands, &Nat::from(0u32));
    let sums = slot_sums(sk, homes, &cleared, &top_sums(&cleared), &Nat::from(0u32));
    fold(homes, &Map::new(), &(|m: &Map<Text, Map<Text, Rel>>, h: &Text| insert(m, h, &slot_seeds(sk, h, &cleared, &sums, &false))))
}

/// The step machine of `HofSeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HofSeeds: unbounded fn Shrink, [Text] -> (Text ==> (Text ==> Rel))
/// ```
pub struct HofSeeds {
    pub sk: Shrink,
    pub homes: Array<Text>,
}

impl prism_rtl::Job<Map<Text, Map<Text, Rel>>> for HofSeeds {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Map<Text, Rel>>> {
        let sk = &self.sk;
        let homes = &self.homes;
        let cands = hof_candidates(sk);
        let homes = homes.clone();
        let sk = sk.clone();
        call_then(start_clear_slots(sk.clone(), homes.clone(), cands.clone(), Nat::from(0u32)), move |clear_slots_53396: Array<Slot_>| {
            let cleared = clear_slots_53396;
            call_then(start_slot_sums(sk.clone(), homes.clone(), cleared.clone(), top_sums(&cleared), Nat::from(0u32)), move |slot_sums_53442: Map<Text, Rel>| {
                let sums = slot_sums_53442;
                prism_rtl::Turn::Finished(fold(&homes, &Map::new(), &(|m: &Map<Text, Map<Text, Rel>>, h: &Text| insert(m, h, &slot_seeds(&sk, h, &cleared, &sums, &false)))))
            })
        })
    }
}

/// `Start HofSeeds, x`: what the function value is when passed to `@Run`.
pub fn start_hof_seeds(sk: Shrink, homes: Array<Text>) -> Rc<dyn prism_rtl::Job<Map<Text, Map<Text, Rel>>>> {
    Rc::new(HofSeeds { sk, homes })
}

/// ```prism
/// HofCandidates: fn Shrink -> [Slot]
/// ```
pub fn hof_candidates(sk: &Shrink) -> Array<Slot_> {
    fold(&sk.fns, &Array::new(), &(|acc: &Array<Slot_>, d: &check_env::Def| match &d.body {
        check_env::DefBody::DbFn(clauses) => match get(&sk.g.vals, &d.qk) {
            Some(v_) => match &v_.scheme.ty {
                check_types::Ty::TyFn(_, ps, _) => fold(&check_errors::range0(&len(ps)), acc, &(|a2: &Array<Slot_>, j: &Nat| match index(ps, j) {
                    Some(check_types::Ty::TyFn(_, fps, _)) => if fold(clauses, &true, &(|ok: &bool, c: &ast::FnClause| *ok && slot_named(c, j))) {
                        push(a2, &Slot_ { owner: d.qk.clone(), at: j.clone(), arity: len(&fps) })
                    } else {
                        a2.clone()
                    },
                    _ => a2.clone(),
                })),
                _ => acc.clone(),
            },
            None => acc.clone(),
        },
        _ => acc.clone(),
    }))
}

/// ```prism
/// SlotNamed: fn FnClause, Nat -> Bool
/// ```
pub fn slot_named(c: &ast::FnClause, j: &Nat) -> bool {
    match index(&c.params, j) {
        Some(p_) => match &*p_.kind {
            ast::PatternKind::PName(_) => true,
            ast::PatternKind::PIgnore => true,
            _ => false,
        },
        None => false,
    }
}

/// ```prism
/// SlotName: fn FnClause, Nat -> Text
/// ```
pub fn slot_name(c: &ast::FnClause, j: &Nat) -> Text {
    match index(&c.params, j) {
        Some(p_) => match &*p_.kind {
            ast::PatternKind::PName(n) => check_env::sname_key(n),
            _ => Text::from(""),
        },
        None => Text::from(""),
    }
}

/// ```prism
/// SlotSeeds: fn Shrink, Text, [Slot], (Text ==> Rel), Bool -> (Text ==> Rel)
/// ```
pub fn slot_seeds(sk: &Shrink, h: &Text, slots: &Array<Slot_>, sums: &Map<Text, Rel>, with_top: &bool) -> Map<Text, Rel> {
    let pre = or(&get(&sk.seeds, h), &Map::new());
    let start = if *with_top {
        insert(&pre, &Text::from("⊤"), &Rel { param: top_param(), strict: false })
    } else {
        pre.clone()
    };
    fold(slots, &start, &(|m: &Map<Text, Rel>, sl: &Slot_| fold(&spellings(&sk.g, h, &sl.owner), m, &(|m2: &Map<Text, Rel>, sp: &Text| {
        let m3 = insert(m2, &Text::from(format!("acc:{}:{}", sp, &sl.at)), &Rel { param: sl.arity.clone(), strict: false });
        fold(&check_errors::range0(&sl.arity), &m3, &(|m4: &Map<Text, Rel>, q: &Nat| match get(sums, &Text::from(format!("{}:{}:{}", &sl.owner, &sl.at, q))) {
            Some(r) => if (&r.param == &top_param()) && !*with_top {
                m4.clone()
            } else {
                insert(m4, &Text::from(format!("sum:{}:{}:{}", sp, &sl.at, q)), &r)
            },
            None => m4.clone(),
        }))
    }))))
}

/// ```prism
/// Spellings: fn G, Text, Text -> [Text]
/// ```
pub fn spellings(g: &check_env::G, h: &Text, k: &Text) -> Array<Text> {
    filter(&check_types::add_text(&Array::from(vec![check_types::bare_name(k)]), k), &(|sp: &Text| &resolve_name(g, h, sp) == &Some(k.clone())))
}

/// ```prism
/// ClearSlots: unbounded fn Shrink, [Text], [Slot], Nat -> [Slot]
/// ```
pub fn clear_slots(sk: &Shrink, homes: &Array<Text>, slots: &Array<Slot_>, round: &Nat) -> Array<Slot_> {
    let sks = seeds_for(sk, homes, slots, &Map::new(), &false);
    let kept = run_to_end(filter_job(slots.clone(), {
        let sks = sks.clone();
        Rc::new(move |p0: Slot_| {
            let sks = sks.clone();
            entered(once_job(move || {
                let sl = p0;
                call_then(start_slot_escapes(sks.clone(), sl.clone()), move |slot_escapes_55868: bool| prism_rtl::Turn::Finished(!slot_escapes_55868))
            }))
        }) as Rc<dyn Fn(Slot_) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    if &len(&kept) == &len(slots) {
        kept.clone()
    } else {
        if round > &Nat::from(20u32) {
            Array::new()
        } else {
            clear_slots(sk, homes, &kept, &(round + &Nat::from(1u32)))
        }
    }
}

/// The step machine of `ClearSlots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClearSlots: unbounded fn Shrink, [Text], [Slot], Nat -> [Slot]
/// ```
pub struct ClearSlots {
    pub sk: Shrink,
    pub homes: Array<Text>,
    pub slots: Array<Slot_>,
    pub round: Nat,
}

impl prism_rtl::Job<Array<Slot_>> for ClearSlots {
    fn cycle(&self) -> prism_rtl::Turn<Array<Slot_>> {
        let sk = &self.sk;
        let homes = &self.homes;
        let slots = &self.slots;
        let round = &self.round;
        let sks = seeds_for(sk, homes, slots, &Map::new(), &false);
        let homes = homes.clone();
        let round = round.clone();
        let sk = sk.clone();
        let slots = slots.clone();
        call_value(filter_job(slots.clone(), {
            let sks = sks.clone();
            Rc::new(move |p0: Slot_| {
                let sks = sks.clone();
                entered(once_job(move || {
                    let sl = p0;
                    call_then(start_slot_escapes(sks.clone(), sl.clone()), move |slot_escapes_55868: bool| prism_rtl::Turn::Finished(!slot_escapes_55868))
                }))
            }) as Rc<dyn Fn(Slot_) -> Rc<dyn prism_rtl::Job<bool>>>
        }), move |filter_55843: Array<Slot_>| {
            let kept = filter_55843;
            if &len(&kept) == &len(&slots) {
                prism_rtl::Turn::Finished(kept.clone())
            } else {
                if &round > &Nat::from(20u32) {
                    prism_rtl::Turn::Finished(Array::new())
                } else {
                    prism_rtl::Turn::More(Rc::new(ClearSlots { sk: sk.clone(), homes: homes.clone(), slots: kept.clone(), round: &round + &Nat::from(1u32) }))
                }
            }
        })
    }
}

/// `Start ClearSlots, x`: what the function value is when passed to `@Run`.
pub fn start_clear_slots(sk: Shrink, homes: Array<Text>, slots: Array<Slot_>, round: Nat) -> Rc<dyn prism_rtl::Job<Array<Slot_>>> {
    Rc::new(ClearSlots { sk, homes, slots, round })
}

/// ```prism
/// SeedsFor: fn Shrink, [Text], [Slot], (Text ==> Rel), Bool -> Shrink
/// ```
pub fn seeds_for(sk: &Shrink, homes: &Array<Text>, slots: &Array<Slot_>, sums: &Map<Text, Rel>, with_top: &bool) -> Shrink {
    let mut this: Shrink = sk.clone();
    this.seeds = fold(homes, &Map::new(), &(|m: &Map<Text, Map<Text, Rel>>, h: &Text| insert(m, h, &slot_seeds(sk, h, slots, sums, with_top))));
    this
}

/// ```prism
/// SlotEscapes: unbounded fn Shrink, Slot -> Bool
/// ```
pub fn slot_escapes(sk: &Shrink, sl: &Slot_) -> bool {
    match get(&sk.by_key, &sl.owner) {
        Some(d) => run_to_end(fold_job(def_clauses(&d), false, {
            let sl = sl.clone();
            let sk = sk.clone();
            let d = d.clone();
            Rc::new(move |(p0, p1): (bool, ast::FnClause)| {
                let sl = sl.clone();
                let sk = sk.clone();
                let d = d.clone();
                entered(once_job(move || {
                    let seen = p0;
                    let c = p1;
                    {
                        let n = slot_name(&c, &sl.at);
                        if seen || (&n == &Text::from("")) {
                            prism_rtl::Turn::Finished(seen)
                        } else {
                            call_then(start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_56669: Map<Text, Rel>| call_then(start_body_spots(c.body.clone(), clause_base_56669), move |body_spots_56650: Array<Spot>| fold_job(body_spots_56650, false, {
                                let n = n.clone();
                                let sl = sl.clone();
                                Rc::new(move |(p0, p1): (bool, Spot)| {
                                    let n = n.clone();
                                    let sl = sl.clone();
                                    entered(once_job(move || {
                                        let esc = p0;
                                        let sp = p1;
                                        prism_rtl::Turn::Finished(esc || spot_escapes(&sp, &n, &sl.at))
                                    }))
                                }) as Rc<dyn Fn((bool, Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
                            }).cycle()))
                        }
                    }
                }))
            }) as Rc<dyn Fn((bool, ast::FnClause)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        None => true,
    }
}

/// The step machine of `SlotEscapes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SlotEscapes: unbounded fn Shrink, Slot -> Bool
/// ```
pub struct SlotEscapes {
    pub sk: Shrink,
    pub sl: Slot_,
}

impl prism_rtl::Job<bool> for SlotEscapes {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let sk = &self.sk;
        let sl = &self.sl;
        match get(&sk.by_key, &sl.owner) {
            Some(d) => fold_job(def_clauses(&d), false, {
                let sl = sl.clone();
                let sk = sk.clone();
                let d = d.clone();
                Rc::new(move |(p0, p1): (bool, ast::FnClause)| {
                    let sl = sl.clone();
                    let sk = sk.clone();
                    let d = d.clone();
                    entered(once_job(move || {
                        let seen = p0;
                        let c = p1;
                        {
                            let n = slot_name(&c, &sl.at);
                            if seen || (&n == &Text::from("")) {
                                prism_rtl::Turn::Finished(seen)
                            } else {
                                call_then(start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_56669: Map<Text, Rel>| call_then(start_body_spots(c.body.clone(), clause_base_56669), move |body_spots_56650: Array<Spot>| fold_job(body_spots_56650, false, {
                                    let n = n.clone();
                                    let sl = sl.clone();
                                    Rc::new(move |(p0, p1): (bool, Spot)| {
                                        let n = n.clone();
                                        let sl = sl.clone();
                                        entered(once_job(move || {
                                            let esc = p0;
                                            let sp = p1;
                                            prism_rtl::Turn::Finished(esc || spot_escapes(&sp, &n, &sl.at))
                                        }))
                                    }) as Rc<dyn Fn((bool, Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
                                }).cycle()))
                            }
                        }
                    }))
                }) as Rc<dyn Fn((bool, ast::FnClause)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            None => prism_rtl::Turn::Finished(true),
        }
    }
}

/// `Start SlotEscapes, x`: what the function value is when passed to `@Run`.
pub fn start_slot_escapes(sk: Shrink, sl: Slot_) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(SlotEscapes { sk, sl })
}

/// ```prism
/// SpotEscapes: unbounded fn Spot, Text, Nat -> Bool
/// ```
pub fn spot_escapes(sp: &Spot, n: &Text, j: &Nat) -> bool {
    match sp {
        Spot::SpotExpr(e, m) => match &*e.kind {
            ast::ExprKind::EName(x) => (&check_env::sname_key(x) == n) && is_slot_param(m, n, j),
            _ => fold(&spot_sites(sp), &false, &(|seen: &bool, site: &Site| *seen || (((&site.callee == n) && is_slot_param(&site.rels, n, j)) && check_env::has_key(&site.rels, &Text::from("lam:"))))),
        },
        Spot::SpotStmt(_, _) => false,
    }
}

/// The step machine of `SpotEscapes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotEscapes: unbounded fn Spot, Text, Nat -> Bool
/// ```
pub struct SpotEscapes {
    pub sp: Spot,
    pub n: Text,
    pub j: Nat,
}

impl prism_rtl::Job<bool> for SpotEscapes {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let sp = &self.sp;
        let n = &self.n;
        let j = &self.j;
        match sp {
            Spot::SpotExpr(e, m) => match &*e.kind {
                ast::ExprKind::EName(x) => prism_rtl::Turn::Finished((&check_env::sname_key(x) == n) && is_slot_param(m, n, j)),
                _ => {
                    let j = j.clone();
                    let n = n.clone();
                    let sp = sp.clone();
                    call_then(start_spot_sites(sp.clone()), move |spot_sites_56960: Array<Site>| prism_rtl::Turn::Finished(fold(&spot_sites_56960, &false, &(|seen: &bool, site: &Site| *seen || (((&site.callee == &n) && is_slot_param(&site.rels, &n, &j)) && check_env::has_key(&site.rels, &Text::from("lam:")))))))
                },
            },
            Spot::SpotStmt(_, _) => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start SpotEscapes, x`: what the function value is when passed to `@Run`.
pub fn start_spot_escapes(sp: Spot, n: Text, j: Nat) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(SpotEscapes { sp, n, j })
}

/// ```prism
/// IsSlotParam: fn (Text ==> Rel), Text, Nat -> Bool
/// ```
pub fn is_slot_param(m: &Map<Text, Rel>, n: &Text, j: &Nat) -> bool {
    &get(m, n) == &Some(Rel { param: j.clone(), strict: false })
}

/// ```prism
/// TopSums: fn [Slot] -> (Text ==> Rel)
/// ```
pub fn top_sums(slots: &Array<Slot_>) -> Map<Text, Rel> {
    fold(slots, &Map::new(), &(|m: &Map<Text, Rel>, sl: &Slot_| fold(&check_errors::range0(&sl.arity), m, &(|m2: &Map<Text, Rel>, q: &Nat| insert(m2, &Text::from(format!("{}:{}:{}", &sl.owner, &sl.at, q)), &Rel { param: top_param(), strict: false })))))
}

/// ```prism
/// SlotSums: unbounded fn Shrink, [Text], [Slot], (Text ==> Rel), Nat -> (Text ==> Rel)
/// ```
pub fn slot_sums(sk: &Shrink, homes: &Array<Text>, slots: &Array<Slot_>, sums: &Map<Text, Rel>, round: &Nat) -> Map<Text, Rel> {
    let sks = seeds_for(sk, homes, slots, sums, &true);
    let next = run_to_end(fold_job(slots.clone(), Map::new(), {
        let sks = sks.clone();
        Rc::new(move |(p0, p1): (Map<Text, Rel>, Slot_)| {
            let sks = sks.clone();
            entered(once_job(move || {
                let m = p0;
                let sl = p1;
                call_then(start_slot_calls(sks.clone(), sl.clone()), move |slot_calls_58105: Array<Site>| {
                    let calls = slot_calls_58105;
                    fold_job(check_errors::range0(&sl.arity), m.clone(), {
                        let calls = calls.clone();
                        let sl = sl.clone();
                        Rc::new(move |(p0, p1): (Map<Text, Rel>, Nat)| {
                            let calls = calls.clone();
                            let sl = sl.clone();
                            entered(once_job(move || {
                                let m2 = p0;
                                let q = p1;
                                call_then(start_meet_args(calls.clone(), q.clone()), move |meet_args_58173: Option<Rel>| match meet_args_58173 {
                                    Some(r) => prism_rtl::Turn::Finished(insert(&m2, &Text::from(format!("{}:{}:{}", &sl.owner, &sl.at, &q)), &r)),
                                    None => prism_rtl::Turn::Finished(m2.clone()),
                                })
                            }))
                        }) as Rc<dyn Fn((Map<Text, Rel>, Nat)) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>>>
                    }).cycle()
                })
            }))
        }) as Rc<dyn Fn((Map<Text, Rel>, Slot_)) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>>>
    }));
    if &next == sums {
        next.clone()
    } else {
        if round > &Nat::from(12u32) {
            Map::new()
        } else {
            slot_sums(sk, homes, slots, &next, &(round + &Nat::from(1u32)))
        }
    }
}

/// The step machine of `SlotSums`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SlotSums: unbounded fn Shrink, [Text], [Slot], (Text ==> Rel), Nat -> (Text ==> Rel)
/// ```
pub struct SlotSums {
    pub sk: Shrink,
    pub homes: Array<Text>,
    pub slots: Array<Slot_>,
    pub sums: Map<Text, Rel>,
    pub round: Nat,
}

impl prism_rtl::Job<Map<Text, Rel>> for SlotSums {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Rel>> {
        let sk = &self.sk;
        let homes = &self.homes;
        let slots = &self.slots;
        let sums = &self.sums;
        let round = &self.round;
        let sks = seeds_for(sk, homes, slots, sums, &true);
        let homes = homes.clone();
        let round = round.clone();
        let sk = sk.clone();
        let slots = slots.clone();
        let sums = sums.clone();
        call_value(fold_job(slots.clone(), Map::new(), {
            let sks = sks.clone();
            Rc::new(move |(p0, p1): (Map<Text, Rel>, Slot_)| {
                let sks = sks.clone();
                entered(once_job(move || {
                    let m = p0;
                    let sl = p1;
                    call_then(start_slot_calls(sks.clone(), sl.clone()), move |slot_calls_58105: Array<Site>| {
                        let calls = slot_calls_58105;
                        fold_job(check_errors::range0(&sl.arity), m.clone(), {
                            let calls = calls.clone();
                            let sl = sl.clone();
                            Rc::new(move |(p0, p1): (Map<Text, Rel>, Nat)| {
                                let calls = calls.clone();
                                let sl = sl.clone();
                                entered(once_job(move || {
                                    let m2 = p0;
                                    let q = p1;
                                    call_then(start_meet_args(calls.clone(), q.clone()), move |meet_args_58173: Option<Rel>| match meet_args_58173 {
                                        Some(r) => prism_rtl::Turn::Finished(insert(&m2, &Text::from(format!("{}:{}:{}", &sl.owner, &sl.at, &q)), &r)),
                                        None => prism_rtl::Turn::Finished(m2.clone()),
                                    })
                                }))
                            }) as Rc<dyn Fn((Map<Text, Rel>, Nat)) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>>>
                        }).cycle()
                    })
                }))
            }) as Rc<dyn Fn((Map<Text, Rel>, Slot_)) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>>>
        }), move |fold_58060: Map<Text, Rel>| {
            let next = fold_58060;
            if &next == &sums {
                prism_rtl::Turn::Finished(next.clone())
            } else {
                if &round > &Nat::from(12u32) {
                    prism_rtl::Turn::Finished(Map::new())
                } else {
                    prism_rtl::Turn::More(Rc::new(SlotSums { sk: sk.clone(), homes: homes.clone(), slots: slots.clone(), sums: next.clone(), round: &round + &Nat::from(1u32) }))
                }
            }
        })
    }
}

/// `Start SlotSums, x`: what the function value is when passed to `@Run`.
pub fn start_slot_sums(sk: Shrink, homes: Array<Text>, slots: Array<Slot_>, sums: Map<Text, Rel>, round: Nat) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>> {
    Rc::new(SlotSums { sk, homes, slots, sums, round })
}

/// ```prism
/// SlotCalls: unbounded fn Shrink, Slot -> [Site]
/// ```
pub fn slot_calls(sk: &Shrink, sl: &Slot_) -> Array<Site> {
    match get(&sk.by_key, &sl.owner) {
        Some(d) => run_to_end(fold_job(def_clauses(&d), Array::new(), {
            let sl = sl.clone();
            let sk = sk.clone();
            let d = d.clone();
            Rc::new(move |(p0, p1): (Array<Site>, ast::FnClause)| {
                let sl = sl.clone();
                let sk = sk.clone();
                let d = d.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let c = p1;
                    {
                        let n = slot_name(&c, &sl.at);
                        if &n == &Text::from("") {
                            prism_rtl::Turn::Finished(acc.clone())
                        } else {
                            call_then(start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_58698: Map<Text, Rel>| {
                                let base = clause_base_58698;
                                call_then(start_body_spots(c.body.clone(), base.clone()), move |body_spots_58762: Array<Spot>| call_then(start_summary_seeds(sk.clone(), d.clone(), body_spots_58762, base.clone()), move |summary_seeds_58741: Map<Text, Rel>| {
                                    let rels = summary_seeds_58741;
                                    call_then(start_body_spots(c.body.clone(), rels.clone()), move |body_spots_58810: Array<Spot>| fold_job(body_spots_58810, acc.clone(), {
                                        let n = n.clone();
                                        let sl = sl.clone();
                                        Rc::new(move |(p0, p1): (Array<Site>, Spot)| {
                                            let n = n.clone();
                                            let sl = sl.clone();
                                            entered(once_job(move || {
                                                let a2 = p0;
                                                let sp = p1;
                                                match &sp {
                                                    Spot::SpotExpr(e, _) => match &*e.kind {
                                                        ast::ExprKind::EName(_) => prism_rtl::Turn::Finished(a2.clone()),
                                                        _ => call_then(start_spot_sites(sp.clone()), move |spot_sites_58998: Array<Site>| prism_rtl::Turn::Finished(append(&a2, &filter(&spot_sites_58998, &(|site: &Site| (&site.callee == &n) && is_slot_param(&site.rels, &n, &sl.at)))))),
                                                    },
                                                    _ => prism_rtl::Turn::Finished(a2.clone()),
                                                }
                                            }))
                                        }) as Rc<dyn Fn((Array<Site>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Site>>>>
                                    }).cycle())
                                }))
                            })
                        }
                    }
                }))
            }) as Rc<dyn Fn((Array<Site>, ast::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Site>>>>
        })),
        None => Array::new(),
    }
}

/// The step machine of `SlotCalls`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SlotCalls: unbounded fn Shrink, Slot -> [Site]
/// ```
pub struct SlotCalls {
    pub sk: Shrink,
    pub sl: Slot_,
}

impl prism_rtl::Job<Array<Site>> for SlotCalls {
    fn cycle(&self) -> prism_rtl::Turn<Array<Site>> {
        let sk = &self.sk;
        let sl = &self.sl;
        match get(&sk.by_key, &sl.owner) {
            Some(d) => fold_job(def_clauses(&d), Array::new(), {
                let sl = sl.clone();
                let sk = sk.clone();
                let d = d.clone();
                Rc::new(move |(p0, p1): (Array<Site>, ast::FnClause)| {
                    let sl = sl.clone();
                    let sk = sk.clone();
                    let d = d.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let c = p1;
                        {
                            let n = slot_name(&c, &sl.at);
                            if &n == &Text::from("") {
                                prism_rtl::Turn::Finished(acc.clone())
                            } else {
                                call_then(start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_58698: Map<Text, Rel>| {
                                    let base = clause_base_58698;
                                    call_then(start_body_spots(c.body.clone(), base.clone()), move |body_spots_58762: Array<Spot>| call_then(start_summary_seeds(sk.clone(), d.clone(), body_spots_58762, base.clone()), move |summary_seeds_58741: Map<Text, Rel>| {
                                        let rels = summary_seeds_58741;
                                        call_then(start_body_spots(c.body.clone(), rels.clone()), move |body_spots_58810: Array<Spot>| fold_job(body_spots_58810, acc.clone(), {
                                            let n = n.clone();
                                            let sl = sl.clone();
                                            Rc::new(move |(p0, p1): (Array<Site>, Spot)| {
                                                let n = n.clone();
                                                let sl = sl.clone();
                                                entered(once_job(move || {
                                                    let a2 = p0;
                                                    let sp = p1;
                                                    match &sp {
                                                        Spot::SpotExpr(e, _) => match &*e.kind {
                                                            ast::ExprKind::EName(_) => prism_rtl::Turn::Finished(a2.clone()),
                                                            _ => call_then(start_spot_sites(sp.clone()), move |spot_sites_58998: Array<Site>| prism_rtl::Turn::Finished(append(&a2, &filter(&spot_sites_58998, &(|site: &Site| (&site.callee == &n) && is_slot_param(&site.rels, &n, &sl.at)))))),
                                                        },
                                                        _ => prism_rtl::Turn::Finished(a2.clone()),
                                                    }
                                                }))
                                            }) as Rc<dyn Fn((Array<Site>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Site>>>>
                                        }).cycle())
                                    }))
                                })
                            }
                        }
                    }))
                }) as Rc<dyn Fn((Array<Site>, ast::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Site>>>>
            }).cycle(),
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start SlotCalls, x`: what the function value is when passed to `@Run`.
pub fn start_slot_calls(sk: Shrink, sl: Slot_) -> Rc<dyn prism_rtl::Job<Array<Site>>> {
    Rc::new(SlotCalls { sk, sl })
}

/// ```prism
/// ?MeetArgs: unbounded fn [Site], Nat -> ?Rel
/// ```
pub fn meet_args(calls: &Array<Site>, q: &Nat) -> Option<Rel> {
    run_to_end(fold_job(calls.clone(), Some(Rel { param: top_param(), strict: false }), {
        let q = q.clone();
        Rc::new(move |(p0, p1): (Option<Rel>, Site)| {
            let q = q.clone();
            entered(once_job(move || {
                let acc_opt = p0;
                let site = p1;
                match &acc_opt {
                    None => prism_rtl::Turn::Finished(None),
                    Some(acc) => match index(&site.args, &q) {
                        Some(a) => if &a.name != &None {
                            prism_rtl::Turn::Finished(None)
                        } else {
                            {
                                let acc = acc.clone();
                                call_then(start_rel_of(site.rels.clone(), a.value.clone()), move |rel_of_59575: Option<Rel>| match rel_of_59575 {
                                    Some(r) => if &r.param == &top_param() {
                                        prism_rtl::Turn::Finished(Some(acc.clone()))
                                    } else {
                                        if &acc.param == &top_param() {
                                            prism_rtl::Turn::Finished(Some(r.clone()))
                                        } else {
                                            if &acc.param == &r.param {
                                                prism_rtl::Turn::Finished(Some(Rel { param: r.param.clone(), strict: acc.strict && r.strict }))
                                            } else {
                                                prism_rtl::Turn::Finished(None)
                                            }
                                        }
                                    },
                                    None => prism_rtl::Turn::Finished(None),
                                })
                            }
                        },
                        None => prism_rtl::Turn::Finished(None),
                    },
                }
            }))
        }) as Rc<dyn Fn((Option<Rel>, Site)) -> Rc<dyn prism_rtl::Job<Option<Rel>>>>
    }))
}

/// The step machine of `MeetArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?MeetArgs: unbounded fn [Site], Nat -> ?Rel
/// ```
pub struct MeetArgs {
    pub calls: Array<Site>,
    pub q: Nat,
}

impl prism_rtl::Job<Option<Rel>> for MeetArgs {
    fn cycle(&self) -> prism_rtl::Turn<Option<Rel>> {
        let calls = &self.calls;
        let q = &self.q;
        fold_job(calls.clone(), Some(Rel { param: top_param(), strict: false }), {
            let q = q.clone();
            Rc::new(move |(p0, p1): (Option<Rel>, Site)| {
                let q = q.clone();
                entered(once_job(move || {
                    let acc_opt = p0;
                    let site = p1;
                    match &acc_opt {
                        None => prism_rtl::Turn::Finished(None),
                        Some(acc) => match index(&site.args, &q) {
                            Some(a) => if &a.name != &None {
                                prism_rtl::Turn::Finished(None)
                            } else {
                                {
                                    let acc = acc.clone();
                                    call_then(start_rel_of(site.rels.clone(), a.value.clone()), move |rel_of_59575: Option<Rel>| match rel_of_59575 {
                                        Some(r) => if &r.param == &top_param() {
                                            prism_rtl::Turn::Finished(Some(acc.clone()))
                                        } else {
                                            if &acc.param == &top_param() {
                                                prism_rtl::Turn::Finished(Some(r.clone()))
                                            } else {
                                                if &acc.param == &r.param {
                                                    prism_rtl::Turn::Finished(Some(Rel { param: r.param.clone(), strict: acc.strict && r.strict }))
                                                } else {
                                                    prism_rtl::Turn::Finished(None)
                                                }
                                            }
                                        },
                                        None => prism_rtl::Turn::Finished(None),
                                    })
                                }
                            },
                            None => prism_rtl::Turn::Finished(None),
                        },
                    }
                }))
            }) as Rc<dyn Fn((Option<Rel>, Site)) -> Rc<dyn prism_rtl::Job<Option<Rel>>>>
        }).cycle()
    }
}

/// `Start MeetArgs, x`: what the function value is when passed to `@Run`.
pub fn start_meet_args(calls: Array<Site>, q: Nat) -> Rc<dyn prism_rtl::Job<Option<Rel>>> {
    Rc::new(MeetArgs { calls, q })
}

/// ```prism
/// DefRefs: unbounded fn Shrink, Def -> [Text]
/// ```
pub fn def_refs(sk: &Shrink, d: &check_env::Def) -> Array<Text> {
    run_to_end(fold_job(def_clauses(d), Array::new(), {
        let sk = sk.clone();
        let d = d.clone();
        Rc::new(move |(p0, p1): (Array<Text>, ast::FnClause)| {
            let sk = sk.clone();
            let d = d.clone();
            entered(once_job(move || {
                let acc = p0;
                let c = p1;
                call_then(start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_60112: Map<Text, Rel>| call_then(start_body_spots(c.body.clone(), clause_base_60112), move |body_spots_60093: Array<Spot>| prism_rtl::Turn::More(Rc::new(SpotsRefs { sk: sk.clone(), d: d.clone(), spots: body_spots_60093, acc: acc.clone() }))))
            }))
        }) as Rc<dyn Fn((Array<Text>, ast::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `DefRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefRefs: unbounded fn Shrink, Def -> [Text]
/// ```
pub struct DefRefs {
    pub sk: Shrink,
    pub d: check_env::Def,
}

impl prism_rtl::Job<Array<Text>> for DefRefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let sk = &self.sk;
        let d = &self.d;
        fold_job(def_clauses(d), Array::new(), {
            let sk = sk.clone();
            let d = d.clone();
            Rc::new(move |(p0, p1): (Array<Text>, ast::FnClause)| {
                let sk = sk.clone();
                let d = d.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let c = p1;
                    call_then(start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_60112: Map<Text, Rel>| call_then(start_body_spots(c.body.clone(), clause_base_60112), move |body_spots_60093: Array<Spot>| prism_rtl::Turn::More(Rc::new(SpotsRefs { sk: sk.clone(), d: d.clone(), spots: body_spots_60093, acc: acc.clone() }))))
                }))
            }) as Rc<dyn Fn((Array<Text>, ast::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }).cycle()
    }
}

/// `Start DefRefs, x`: what the function value is when passed to `@Run`.
pub fn start_def_refs(sk: Shrink, d: check_env::Def) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(DefRefs { sk, d })
}

/// ```prism
/// SpotsRefs: unbounded fn Shrink, Def, [Spot], [Text] -> [Text]
/// ```
pub fn spots_refs(sk: &Shrink, d: &check_env::Def, spots: &Array<Spot>, acc: &Array<Text>) -> Array<Text> {
    run_to_end(fold_job(spots.clone(), acc.clone(), {
        let sk = sk.clone();
        let d = d.clone();
        Rc::new(move |(p0, p1): (Array<Text>, Spot)| {
            let sk = sk.clone();
            let d = d.clone();
            entered(once_job(move || {
                let a1 = p0;
                let sp = p1;
                call_then(start_spot_sites(sp.clone()), move |spot_sites_60268: Array<Site>| prism_rtl::Turn::Finished(fold(&spot_sites_60268, &a1, &(|a2: &Array<Text>, site: &Site| match local_target(&sk, &d, site) {
                    Some(t) => check_types::add_text(a2, &t),
                    None => if is_local(&site.rels, &site.callee) || check_env::has_key(&sk.local_of, &d.qk) {
                        a2.clone()
                    } else {
                        match resolve_callee(&sk.g, &d.home, &site.callee) {
                            Some(k) => fold(&targets_of(&sk, &k), a2, &(|a3: &Array<Text>, t: &Text| if check_env::has_key(&sk.by_key, t) {
                                check_types::add_text(a3, t)
                            } else {
                                a3.clone()
                            })),
                            None => a2.clone(),
                        }
                    },
                }))))
            }))
        }) as Rc<dyn Fn((Array<Text>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `SpotsRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotsRefs: unbounded fn Shrink, Def, [Spot], [Text] -> [Text]
/// ```
pub struct SpotsRefs {
    pub sk: Shrink,
    pub d: check_env::Def,
    pub spots: Array<Spot>,
    pub acc: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for SpotsRefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let sk = &self.sk;
        let d = &self.d;
        let spots = &self.spots;
        let acc = &self.acc;
        fold_job(spots.clone(), acc.clone(), {
            let sk = sk.clone();
            let d = d.clone();
            Rc::new(move |(p0, p1): (Array<Text>, Spot)| {
                let sk = sk.clone();
                let d = d.clone();
                entered(once_job(move || {
                    let a1 = p0;
                    let sp = p1;
                    call_then(start_spot_sites(sp.clone()), move |spot_sites_60268: Array<Site>| prism_rtl::Turn::Finished(fold(&spot_sites_60268, &a1, &(|a2: &Array<Text>, site: &Site| match local_target(&sk, &d, site) {
                        Some(t) => check_types::add_text(a2, &t),
                        None => if is_local(&site.rels, &site.callee) || check_env::has_key(&sk.local_of, &d.qk) {
                            a2.clone()
                        } else {
                            match resolve_callee(&sk.g, &d.home, &site.callee) {
                                Some(k) => fold(&targets_of(&sk, &k), a2, &(|a3: &Array<Text>, t: &Text| if check_env::has_key(&sk.by_key, t) {
                                    check_types::add_text(a3, t)
                                } else {
                                    a3.clone()
                                })),
                                None => a2.clone(),
                            }
                        },
                    }))))
                }))
            }) as Rc<dyn Fn((Array<Text>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }).cycle()
    }
}

/// `Start SpotsRefs, x`: what the function value is when passed to `@Run`.
pub fn start_spots_refs(sk: Shrink, d: check_env::Def, spots: Array<Spot>, acc: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SpotsRefs { sk, d, spots, acc })
}

/// ```prism
/// WithLocals: unbounded fn Shrink, [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))] -> Shrink
/// ```
pub fn with_locals(sk: &Shrink, found: &Array<(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)>) -> Shrink {
    let (bases, owners, clauses, wdecls) = fold(found, &(Map::new(), Map::new(), Map::new(), Map::new()), &(|(bs, os, cs, ws): &(Map<Text, Map<Text, Rel>>, Map<Text, Text>, Map<Text, Array<ast::FnClause>>, Map<Text, (check_env::Def, ast::WidgetDecl)>), (d, gk, n, m, c_opt, w_opt): &(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)| {
        let qk = local_key(n, &d.qk, gk);
        let bs2 = if check_env::has_key(bs, &qk) { bs.clone() } else { insert(bs, &qk, &marks(m)) };
        let os2 = insert(os, &qk, &d.qk);
        let cs2 = match c_opt {
            Some(c) => insert(cs, &qk, &push(&or(&get(cs, &qk), &Array::new()), c)),
            None => cs.clone(),
        };
        let ws2 = match w_opt {
            Some(w) => insert(ws, &qk, &(d.clone(), w.clone())),
            None => ws.clone(),
        };
        (bs2.clone(), os2.clone(), cs2.clone(), ws2.clone())
    }));
    let fn_defs = fold(&keys(&clauses), &Array::new(), &(|acc: &Array<check_env::Def>, qk: &Text| match (get(&owners, qk), get(&clauses, qk)) {
        (Some(oq), Some(cl)) => match get(&sk.by_key, &oq) {
            Some(d) => push(acc, &check_env::Def { qk: qk.clone(), name: or(&index(&split(qk, &Text::from(" #")), &Nat::from(0u32)), qk), home: d.home.clone(), file: d.file.clone(), span: d.span.clone(), body: check_env::DefBody::DbFn(cl.clone()) }),
            None => acc.clone(),
        },
        _ => acc.clone(),
    }));
    let w_defs = fold(&keys(&wdecls), &Array::new(), &(|acc: &Array<check_env::Def>, qk: &Text| match get(&wdecls, qk) {
        Some((d, w)) => push(acc, &check_env::Def { qk: qk.clone(), name: check_env::sname_key(&w.name), home: d.home.clone(), file: d.file.clone(), span: w.span.clone(), body: check_env::DefBody::DbWidget(w.clone()) }),
        None => acc.clone(),
    }));
    let locals = append(&fn_defs, &w_defs);
    let mut this: Shrink = sk.clone();
    this.fns = append(&this.fns, &locals);
    this.by_key = fold(&locals, &this.by_key, &(|m: &Map<Text, check_env::Def>, d: &check_env::Def| insert(m, &d.qk, d)));
    this.local_of = owners.clone();
    this.local_base = bases.clone();
    this
}

/// The step machine of `WithLocals`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WithLocals: unbounded fn Shrink, [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))] -> Shrink
/// ```
pub struct WithLocals {
    pub sk: Shrink,
    pub found: Array<(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)>,
}

impl prism_rtl::Job<Shrink> for WithLocals {
    fn cycle(&self) -> prism_rtl::Turn<Shrink> {
        let sk = &self.sk;
        let found = &self.found;
        let (bases, owners, clauses, wdecls) = fold(found, &(Map::new(), Map::new(), Map::new(), Map::new()), &(|(bs, os, cs, ws): &(Map<Text, Map<Text, Rel>>, Map<Text, Text>, Map<Text, Array<ast::FnClause>>, Map<Text, (check_env::Def, ast::WidgetDecl)>), (d, gk, n, m, c_opt, w_opt): &(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)| {
            let qk = local_key(n, &d.qk, gk);
            let bs2 = if check_env::has_key(bs, &qk) { bs.clone() } else { insert(bs, &qk, &marks(m)) };
            let os2 = insert(os, &qk, &d.qk);
            let cs2 = match c_opt {
                Some(c) => insert(cs, &qk, &push(&or(&get(cs, &qk), &Array::new()), c)),
                None => cs.clone(),
            };
            let ws2 = match w_opt {
                Some(w) => insert(ws, &qk, &(d.clone(), w.clone())),
                None => ws.clone(),
            };
            (bs2.clone(), os2.clone(), cs2.clone(), ws2.clone())
        }));
        let fn_defs = fold(&keys(&clauses), &Array::new(), &(|acc: &Array<check_env::Def>, qk: &Text| match (get(&owners, qk), get(&clauses, qk)) {
            (Some(oq), Some(cl)) => match get(&sk.by_key, &oq) {
                Some(d) => push(acc, &check_env::Def { qk: qk.clone(), name: or(&index(&split(qk, &Text::from(" #")), &Nat::from(0u32)), qk), home: d.home.clone(), file: d.file.clone(), span: d.span.clone(), body: check_env::DefBody::DbFn(cl.clone()) }),
                None => acc.clone(),
            },
            _ => acc.clone(),
        }));
        let w_defs = fold(&keys(&wdecls), &Array::new(), &(|acc: &Array<check_env::Def>, qk: &Text| match get(&wdecls, qk) {
            Some((d, w)) => push(acc, &check_env::Def { qk: qk.clone(), name: check_env::sname_key(&w.name), home: d.home.clone(), file: d.file.clone(), span: w.span.clone(), body: check_env::DefBody::DbWidget(w.clone()) }),
            None => acc.clone(),
        }));
        let locals = append(&fn_defs, &w_defs);
        prism_rtl::Turn::Finished({
            let mut this: Shrink = sk.clone();
            this.fns = append(&this.fns, &locals);
            this.by_key = fold(&locals, &this.by_key, &(|m: &Map<Text, check_env::Def>, d: &check_env::Def| insert(m, &d.qk, d)));
            this.local_of = owners.clone();
            this.local_base = bases.clone();
            this
        })
    }
}

/// `Start WithLocals, x`: what the function value is when passed to `@Run`.
pub fn start_with_locals(sk: Shrink, found: Array<(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)>) -> Rc<dyn prism_rtl::Job<Shrink>> {
    Rc::new(WithLocals { sk, found })
}

/// ```prism
/// LocalKey: fn Text, Text, Text -> Text
/// ```
pub fn local_key(n: &Text, owner: &Text, gk: &Text) -> Text {
    Text::from(format!("{} #local {} {}", n, owner, gk))
}

/// ```prism
/// DefWalk: unbounded fn Shrink, Def -> ((Text, [Text], [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))]))
/// ```
pub fn def_walk(sk: &Shrink, d: &check_env::Def) -> (Text, Array<Text>, Array<(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)>) {
    let (refs, locals) = run_to_end(fold_job(def_clauses(d), (Array::new(), Array::new()), {
        let sk = sk.clone();
        let d = d.clone();
        Rc::new(move |(p0, p1): ((Array<Text>, Array<(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)>), ast::FnClause)| {
            let sk = sk.clone();
            let d = d.clone();
            entered(once_job(move || {
                let (rs, ls) = p0;
                let c = p1;
                call_then(start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_63776: Map<Text, Rel>| call_then(start_body_spots(c.body.clone(), clause_base_63776), move |body_spots_63757: Array<Spot>| {
                    let spots = body_spots_63757;
                    call_then(start_spots_refs(sk.clone(), d.clone(), spots.clone(), rs.clone()), move |spots_refs_63808: Array<Text>| prism_rtl::Turn::Finished((spots_refs_63808, fold(&spots, &ls, &(|a2: &Array<(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)>, sp: &Spot| append(a2, &spot_local(&d, sp)))))))
                }))
            }))
        }) as Rc<dyn Fn(((Array<Text>, Array<(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)>), ast::FnClause)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Array<(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)>)>>>
    }));
    (d.qk.clone(), refs.clone(), locals.clone())
}

/// The step machine of `DefWalk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefWalk: unbounded fn Shrink, Def -> ((Text, [Text], [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))]))
/// ```
pub struct DefWalk {
    pub sk: Shrink,
    pub d: check_env::Def,
}

impl prism_rtl::Job<(Text, Array<Text>, Array<(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)>)> for DefWalk {
    fn cycle(&self) -> prism_rtl::Turn<(Text, Array<Text>, Array<(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)>)> {
        let sk = &self.sk;
        let d = &self.d;
        let d = d.clone();
        let sk = sk.clone();
        call_value(fold_job(def_clauses(&d), (Array::new(), Array::new()), {
            let sk = sk.clone();
            let d = d.clone();
            Rc::new(move |(p0, p1): ((Array<Text>, Array<(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)>), ast::FnClause)| {
                let sk = sk.clone();
                let d = d.clone();
                entered(once_job(move || {
                    let (rs, ls) = p0;
                    let c = p1;
                    call_then(start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_63776: Map<Text, Rel>| call_then(start_body_spots(c.body.clone(), clause_base_63776), move |body_spots_63757: Array<Spot>| {
                        let spots = body_spots_63757;
                        call_then(start_spots_refs(sk.clone(), d.clone(), spots.clone(), rs.clone()), move |spots_refs_63808: Array<Text>| prism_rtl::Turn::Finished((spots_refs_63808, fold(&spots, &ls, &(|a2: &Array<(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)>, sp: &Spot| append(a2, &spot_local(&d, sp)))))))
                    }))
                }))
            }) as Rc<dyn Fn(((Array<Text>, Array<(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)>), ast::FnClause)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Array<(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)>)>>>
        }), move |fold_63683: (Array<Text>, Array<(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)>)| {
            let (refs, locals) = fold_63683;
            prism_rtl::Turn::Finished((d.qk.clone(), refs.clone(), locals.clone()))
        })
    }
}

/// `Start DefWalk, x`: what the function value is when passed to `@Run`.
pub fn start_def_walk(sk: Shrink, d: check_env::Def) -> Rc<dyn prism_rtl::Job<(Text, Array<Text>, Array<(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)>)>> {
    Rc::new(DefWalk { sk, d })
}

/// ```prism
/// SpotLocal: fn Def, Spot -> [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))]
/// ```
pub fn spot_local(d: &check_env::Def, sp: &Spot) -> Array<(check_env::Def, Text, Text, Map<Text, Rel>, Option<ast::FnClause>, Option<ast::WidgetDecl>)> {
    match sp {
        Spot::SpotStmt(s, m) => match &s.kind {
            ast::StmtKind::SFn(f) => {
                let n = check_env::def_name_text(&f.name);
                match get(m, &Text::from(format!("lfn:{}", &n))) {
                    Some(r) => Array::from(vec![(d.clone(), Text::from(format!("{}.{}", &d.file, &r.param)), n.clone(), m.clone(), Some(f.clone()), None)]),
                    None => Array::new(),
                }
            },
            ast::StmtKind::SWidget(w) => {
                let n = check_env::sname_key(&w.name);
                match get(m, &Text::from(format!("lfn:{}", &n))) {
                    Some(r) => Array::from(vec![(d.clone(), Text::from(format!("{}.{}", &d.file, &r.param)), n.clone(), m.clone(), None, Some(w.clone()))]),
                    None => Array::new(),
                }
            },
            _ => Array::new(),
        },
        _ => Array::new(),
    }
}

/// ```prism
/// ?LocalTarget: fn Shrink, Def, Site -> ?Text
/// ```
pub fn local_target(sk: &Shrink, d: &check_env::Def, site: &Site) -> Option<Text> {
    match get(&site.rels, &Text::from(format!("lfn:{}", &site.callee))) {
        Some(r) => Some(local_key(&site.callee, &or(&get(&sk.local_of, &d.qk), &d.qk), &Text::from(format!("{}.{}", &d.file, &r.param)))),
        None => None,
    }
}

/// ```prism
/// ClauseBase: unbounded fn Shrink, Def, FnClause -> (Text ==> Rel)
/// ```
pub fn clause_base(sk: &Shrink, d: &check_env::Def, c: &ast::FnClause) -> Map<Text, Rel> {
    match get(&sk.local_base, &d.qk) {
        Some(b) => param_rels_on(&b, &c.params),
        None => param_rels_on(&insert(&or(&get(&sk.seeds, &d.home), &Map::new()), &Text::from("file:"), &Rel { param: d.file.clone(), strict: false }), &c.params),
    }
}

/// The step machine of `ClauseBase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseBase: unbounded fn Shrink, Def, FnClause -> (Text ==> Rel)
/// ```
pub struct ClauseBase {
    pub sk: Shrink,
    pub d: check_env::Def,
    pub c: ast::FnClause,
}

impl prism_rtl::Job<Map<Text, Rel>> for ClauseBase {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Rel>> {
        let sk = &self.sk;
        let d = &self.d;
        let c = &self.c;
        match get(&sk.local_base, &d.qk) {
            Some(b) => prism_rtl::Turn::More(Rc::new(ParamRelsOn { base: b.clone(), ps: c.params.clone() })),
            None => prism_rtl::Turn::More(Rc::new(ParamRelsOn { base: insert(&or(&get(&sk.seeds, &d.home), &Map::new()), &Text::from("file:"), &Rel { param: d.file.clone(), strict: false }), ps: c.params.clone() })),
        }
    }
}

/// `Start ClauseBase, x`: what the function value is when passed to `@Run`.
pub fn start_clause_base(sk: Shrink, d: check_env::Def, c: ast::FnClause) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>> {
    Rc::new(ClauseBase { sk, d, c })
}

/// ```prism
/// ?ResolveCallee: fn G, Text, Text -> ?Text
/// ```
pub fn resolve_callee(g: &check_env::G, m: &Text, n: &Text) -> Option<Text> {
    if is_op_text(n) {
        resolve_op(g, m, n)
    } else {
        match resolve_name(g, m, n) {
            Some(k) => Some(k.clone()),
            None => if lexer::has_prefix(n, &Text::from("@")) {
                resolve_name(g, m, &lexer::after_first(n))
            } else {
                None
            },
        }
    }
}

/// ```prism
/// ?ResolveOp: fn G, Text, Text -> ?Text
/// ```
pub fn resolve_op(g: &check_env::G, m: &Text, op: &Text) -> Option<Text> {
    let (k_opt, _) = check_env::resolve_value(g, m, &ast::SName { sigils: Text::from(""), path_: Array::from(vec![op.clone()]), span: ast::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
    k_opt.clone()
}

/// ```prism
/// IsOpText: fn Text -> Bool
/// ```
pub fn is_op_text(n: &Text) -> bool {
    (&len_text(n) > &Nat::from(0u32)) && !lexer::fold_chars(n, &false, &(Rc::new(move |(p0, p1): (bool, Text)| once_job(move || {
        let seen = p0;
        let ch = p1;
        prism_rtl::Turn::Finished(((seen || lexer::is_upper(&ch)) || lexer::is_lower(&ch)) || (&ch == &Text::from("_")))
    })) as Rc<dyn Fn((bool, Text)) -> Rc<dyn prism_rtl::Job<bool>>>))
}

/// ```prism
/// ?ResolveName: fn G, Text, Text -> ?Text
/// ```
pub fn resolve_name(g: &check_env::G, m: &Text, n: &Text) -> Option<Text> {
    let marks_ = check_types::marks_of(n);
    let path_ = split(&lexer::drop_prefix(n, &marks_), &Text::from("."));
    let (k_opt, _) = check_env::resolve_value(g, m, &ast::SName { sigils: marks_.clone(), path_: path_.clone(), span: ast::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
    k_opt.clone()
}

/// ```prism
/// NamesInStmt: unbounded fn Stmt -> [Text]
/// ```
pub fn names_in_stmt(s: &ast::Stmt) -> Array<Text> {
    spots_names(&stmt_spots(s, &Map::new()))
}

/// The step machine of `NamesInStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamesInStmt: unbounded fn Stmt -> [Text]
/// ```
pub struct NamesInStmt {
    pub s: ast::Stmt,
}

impl prism_rtl::Job<Array<Text>> for NamesInStmt {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let s = &self.s;
        let s = s.clone();
        call_then(start_stmt_spots(s.clone(), Map::new()), move |stmt_spots_66279: Array<Spot>| prism_rtl::Turn::More(Rc::new(SpotsNames { spots: stmt_spots_66279 })))
    }
}

/// `Start NamesInStmt, x`: what the function value is when passed to `@Run`.
pub fn start_names_in_stmt(s: ast::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(NamesInStmt { s })
}

/// ```prism
/// Sccs: unbounded fn [Text], [((Text, [Text]))] -> [ [Text] ]
/// ```
pub fn sccs(keys_: &Array<Text>, refs: &Array<(Text, Array<Text>)>) -> Array<Array<Text>> {
    let adj = fold(refs, &Map::new(), &(|m: &Map<Text, Array<Text>>, (k, rs): &(Text, Array<Text>)| insert(m, k, rs)));
    let rev = fold(refs, &Map::new(), &(|m: &Map<Text, Array<Text>>, (k, rs): &(Text, Array<Text>)| fold(rs, m, &(|m2: &Map<Text, Array<Text>>, r: &Text| insert(m2, r, &push(&or(&get(m2, r), &Array::new()), k))))));
    let (_, post) = run_to_end(fold_job(keys_.clone(), (Map::new(), Array::new()), {
        let adj = adj.clone();
        Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Text>), Text)| {
            let adj = adj.clone();
            entered(once_job(move || {
                let (seen, out) = p0;
                let k = p1;
                prism_rtl::Turn::More(Rc::new(PostVisit { adj: adj.clone(), seen: seen.clone(), out: out.clone(), k: k.clone() }))
            }))
        }) as Rc<dyn Fn(((Map<Text, bool>, Array<Text>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>>>
    }));
    let (ignore2, comps) = run_to_end(fold_job(check_types::reverse2(&post), (Map::new(), Array::new()), {
        let rev = rev.clone();
        Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Array<Text>>), Text)| {
            let rev = rev.clone();
            entered(once_job(move || {
                let (seen, acc) = p0;
                let k = p1;
                if check_env::has_key(&seen, &k) {
                    prism_rtl::Turn::Finished((seen.clone(), acc.clone()))
                } else {
                    call_then(start_collect(rev.clone(), seen.clone(), Array::new(), k.clone()), move |collect_67121: (Map<Text, bool>, Array<Text>)| {
                        let (seen2, comp) = collect_67121;
                        prism_rtl::Turn::Finished((seen2.clone(), push(&acc, &comp)))
                    })
                }
            }))
        }) as Rc<dyn Fn(((Map<Text, bool>, Array<Array<Text>>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Array<Text>>)>>>
    }));
    filter(&comps, &(|c: &Array<Text>| (&len(c) > &Nat::from(1u32)) || fold(c, &false, &(|self_: &bool, k: &Text| *self_ || check_types::has_text(&or(&get(&adj, k), &Array::new()), k)))))
}

/// The step machine of `Sccs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Sccs: unbounded fn [Text], [((Text, [Text]))] -> [ [Text] ]
/// ```
pub struct Sccs {
    pub keys_: Array<Text>,
    pub refs: Array<(Text, Array<Text>)>,
}

impl prism_rtl::Job<Array<Array<Text>>> for Sccs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Array<Text>>> {
        let keys_ = &self.keys_;
        let refs = &self.refs;
        let adj = fold(refs, &Map::new(), &(|m: &Map<Text, Array<Text>>, (k, rs): &(Text, Array<Text>)| insert(m, k, rs)));
        let rev = fold(refs, &Map::new(), &(|m: &Map<Text, Array<Text>>, (k, rs): &(Text, Array<Text>)| fold(rs, m, &(|m2: &Map<Text, Array<Text>>, r: &Text| insert(m2, r, &push(&or(&get(m2, r), &Array::new()), k))))));
        let keys_ = keys_.clone();
        call_value(fold_job(keys_.clone(), (Map::new(), Array::new()), {
            let adj = adj.clone();
            Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Text>), Text)| {
                let adj = adj.clone();
                entered(once_job(move || {
                    let (seen, out) = p0;
                    let k = p1;
                    prism_rtl::Turn::More(Rc::new(PostVisit { adj: adj.clone(), seen: seen.clone(), out: out.clone(), k: k.clone() }))
                }))
            }) as Rc<dyn Fn(((Map<Text, bool>, Array<Text>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>>>
        }), move |fold_66874: (Map<Text, bool>, Array<Text>)| {
            let (_, post) = fold_66874;
            call_value(fold_job(check_types::reverse2(&post), (Map::new(), Array::new()), {
                let rev = rev.clone();
                Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Array<Text>>), Text)| {
                    let rev = rev.clone();
                    entered(once_job(move || {
                        let (seen, acc) = p0;
                        let k = p1;
                        if check_env::has_key(&seen, &k) {
                            prism_rtl::Turn::Finished((seen.clone(), acc.clone()))
                        } else {
                            call_then(start_collect(rev.clone(), seen.clone(), Array::new(), k.clone()), move |collect_67121: (Map<Text, bool>, Array<Text>)| {
                                let (seen2, comp) = collect_67121;
                                prism_rtl::Turn::Finished((seen2.clone(), push(&acc, &comp)))
                            })
                        }
                    }))
                }) as Rc<dyn Fn(((Map<Text, bool>, Array<Array<Text>>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Array<Text>>)>>>
            }), move |fold_66976: (Map<Text, bool>, Array<Array<Text>>)| {
                let (ignore2, comps) = fold_66976;
                prism_rtl::Turn::Finished(filter(&comps, &(|c: &Array<Text>| (&len(c) > &Nat::from(1u32)) || fold(c, &false, &(|self_: &bool, k: &Text| *self_ || check_types::has_text(&or(&get(&adj, k), &Array::new()), k))))))
            })
        })
    }
}

/// `Start Sccs, x`: what the function value is when passed to `@Run`.
pub fn start_sccs(keys_: Array<Text>, refs: Array<(Text, Array<Text>)>) -> Rc<dyn prism_rtl::Job<Array<Array<Text>>>> {
    Rc::new(Sccs { keys_, refs })
}

/// ```prism
/// PostVisit: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
/// ```
pub fn post_visit(adj: &Map<Text, Array<Text>>, seen: &Map<Text, bool>, out: &Array<Text>, k: &Text) -> (Map<Text, bool>, Array<Text>) {
    if check_env::has_key(seen, k) {
        (seen.clone(), out.clone())
    } else {
        {
            let (seen2, out2) = run_to_end(fold_job(or(&get(adj, k), &Array::new()), (insert(seen, k, &true), out.clone()), {
                let adj = adj.clone();
                Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Text>), Text)| {
                    let adj = adj.clone();
                    entered(once_job(move || {
                        let (s, o) = p0;
                        let n = p1;
                        prism_rtl::Turn::More(Rc::new(PostVisit { adj: adj.clone(), seen: s.clone(), out: o.clone(), k: n.clone() }))
                    }))
                }) as Rc<dyn Fn(((Map<Text, bool>, Array<Text>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>>>
            }));
            (seen2.clone(), push(&out2, k))
        }
    }
}

/// The step machine of `PostVisit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PostVisit: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
/// ```
pub struct PostVisit {
    pub adj: Map<Text, Array<Text>>,
    pub seen: Map<Text, bool>,
    pub out: Array<Text>,
    pub k: Text,
}

impl prism_rtl::Job<(Map<Text, bool>, Array<Text>)> for PostVisit {
    fn cycle(&self) -> prism_rtl::Turn<(Map<Text, bool>, Array<Text>)> {
        let adj = &self.adj;
        let seen = &self.seen;
        let out = &self.out;
        let k = &self.k;
        if check_env::has_key(seen, k) {
            prism_rtl::Turn::Finished((seen.clone(), out.clone()))
        } else {
            {
                let adj = adj.clone();
                let k = k.clone();
                let out = out.clone();
                let seen = seen.clone();
                call_value(fold_job(or(&get(&adj, &k), &Array::new()), (insert(&seen, &k, &true), out.clone()), {
                    let adj = adj.clone();
                    Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Text>), Text)| {
                        let adj = adj.clone();
                        entered(once_job(move || {
                            let (s, o) = p0;
                            let n = p1;
                            prism_rtl::Turn::More(Rc::new(PostVisit { adj: adj.clone(), seen: s.clone(), out: o.clone(), k: n.clone() }))
                        }))
                    }) as Rc<dyn Fn(((Map<Text, bool>, Array<Text>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>>>
                }), move |fold_67505: (Map<Text, bool>, Array<Text>)| {
                    let (seen2, out2) = fold_67505;
                    prism_rtl::Turn::Finished((seen2.clone(), push(&out2, &k)))
                })
            }
        }
    }
}

/// `Start PostVisit, x`: what the function value is when passed to `@Run`.
pub fn start_post_visit(adj: Map<Text, Array<Text>>, seen: Map<Text, bool>, out: Array<Text>, k: Text) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>> {
    Rc::new(PostVisit { adj, seen, out, k })
}

/// ```prism
/// Collect: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
/// ```
pub fn collect(rev: &Map<Text, Array<Text>>, seen: &Map<Text, bool>, comp: &Array<Text>, k: &Text) -> (Map<Text, bool>, Array<Text>) {
    if check_env::has_key(seen, k) {
        (seen.clone(), comp.clone())
    } else {
        run_to_end(fold_job(or(&get(rev, k), &Array::new()), (insert(seen, k, &true), push(comp, k)), {
            let rev = rev.clone();
            Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Text>), Text)| {
                let rev = rev.clone();
                entered(once_job(move || {
                    let (s, c) = p0;
                    let n = p1;
                    prism_rtl::Turn::More(Rc::new(Collect { rev: rev.clone(), seen: s.clone(), comp: c.clone(), k: n.clone() }))
                }))
            }) as Rc<dyn Fn(((Map<Text, bool>, Array<Text>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>>>
        }))
    }
}

/// The step machine of `Collect`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Collect: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
/// ```
pub struct Collect {
    pub rev: Map<Text, Array<Text>>,
    pub seen: Map<Text, bool>,
    pub comp: Array<Text>,
    pub k: Text,
}

impl prism_rtl::Job<(Map<Text, bool>, Array<Text>)> for Collect {
    fn cycle(&self) -> prism_rtl::Turn<(Map<Text, bool>, Array<Text>)> {
        let rev = &self.rev;
        let seen = &self.seen;
        let comp = &self.comp;
        let k = &self.k;
        if check_env::has_key(seen, k) {
            prism_rtl::Turn::Finished((seen.clone(), comp.clone()))
        } else {
            fold_job(or(&get(rev, k), &Array::new()), (insert(seen, k, &true), push(comp, k)), {
                let rev = rev.clone();
                Rc::new(move |(p0, p1): ((Map<Text, bool>, Array<Text>), Text)| {
                    let rev = rev.clone();
                    entered(once_job(move || {
                        let (s, c) = p0;
                        let n = p1;
                        prism_rtl::Turn::More(Rc::new(Collect { rev: rev.clone(), seen: s.clone(), comp: c.clone(), k: n.clone() }))
                    }))
                }) as Rc<dyn Fn(((Map<Text, bool>, Array<Text>), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>>>
            }).cycle()
        }
    }
}

/// `Start Collect, x`: what the function value is when passed to `@Run`.
pub fn start_collect(rev: Map<Text, Array<Text>>, seen: Map<Text, bool>, comp: Array<Text>, k: Text) -> Rc<dyn prism_rtl::Job<(Map<Text, bool>, Array<Text>)>> {
    Rc::new(Collect { rev, seen, comp, k })
}

/// ```prism
/// ShrinkComponent: unbounded fn Shrink, St, [Text] -> St
/// ```
pub fn shrink_component(sk: &Shrink, st: &check_types::St, comp: &Array<Text>) -> check_types::St {
    if fold(comp, &true, &(|ok: &bool, k: &Text| *ok && is_unbounded_key(&sk.g, &sig_key_of(sk, &or(&get(&sk.local_of, k), k))))) {
        st.clone()
    } else {
        {
            let graphs = run_to_end(fold_job(sk.fns.clone(), Array::new(), {
                let comp = comp.clone();
                let sk = sk.clone();
                Rc::new(move |(p0, p1): (Array<Sc>, check_env::Def)| {
                    let comp = comp.clone();
                    let sk = sk.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let d = p1;
                        if check_types::has_text(&comp, &d.qk) {
                            call_then(start_call_graphs(sk.clone(), d.clone(), comp.clone()), move |call_graphs_68420: Array<Sc>| prism_rtl::Turn::Finished(append(&acc, &call_graphs_68420)))
                        } else {
                            prism_rtl::Turn::Finished(acc.clone())
                        }
                    }))
                }) as Rc<dyn Fn((Array<Sc>, check_env::Def)) -> Rc<dyn prism_rtl::Job<Array<Sc>>>>
            }));
            let closure_ = closure(&graphs);
            let bad = filter(&closure_, &(|sc: &Sc| ((&sc.caller == &sc.callee) && (&compose(sc, sc).edges == &sc.edges)) && !fold(&sc.edges, &false, &(|seen: &bool, (a, b, s): &(Nat, Nat, bool)| *seen || ((a == b) && *s)))));
            match index(&bad, &Nat::from(0u32)) {
                Some(sc) => {
                    let s2 = {
                        let mut this: check_types::St = st.clone();
                        this.file = sc.file.clone();
                        this
                    };
                    let what = if &sc.arg == &Text::from("") {
                        Text::from("")
                    } else {
                        Text::from(format!(" on `{}`", &sc.arg))
                    };
                    let st3 = check_types::err_fix(&s2, &Text::from("may-not-end"), &sc.span, &Text::from(format!("`{}` calls {}{}, not smaller than what it was given", &shown_key(&sc.caller), &(if &sc.caller == &sc.callee {
                        Text::from("itself")
                    } else {
                        Text::from(format!("`{}`", &shown_key(&sc.callee)))
                    }), &what)), &Text::from("make an argument shrink (a part taken apart by `match`, or the `? m` of `match n -? 1`), or mark the cycle's functions `unbounded fn`"));
                    {
                        let mut this: check_types::St = st3.clone();
                        this.file = st.file.clone();
                        this
                    }
                },
                None => st.clone(),
            }
        }
    }
}

/// The step machine of `ShrinkComponent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShrinkComponent: unbounded fn Shrink, St, [Text] -> St
/// ```
pub struct ShrinkComponent {
    pub sk: Shrink,
    pub st: check_types::St,
    pub comp: Array<Text>,
}

impl prism_rtl::Job<check_types::St> for ShrinkComponent {
    fn cycle(&self) -> prism_rtl::Turn<check_types::St> {
        let sk = &self.sk;
        let st = &self.st;
        let comp = &self.comp;
        if fold(comp, &true, &(|ok: &bool, k: &Text| *ok && is_unbounded_key(&sk.g, &sig_key_of(sk, &or(&get(&sk.local_of, k), k))))) {
            prism_rtl::Turn::Finished(st.clone())
        } else {
            {
                let comp = comp.clone();
                let sk = sk.clone();
                let st = st.clone();
                call_value(fold_job(sk.fns.clone(), Array::new(), {
                    let comp = comp.clone();
                    let sk = sk.clone();
                    Rc::new(move |(p0, p1): (Array<Sc>, check_env::Def)| {
                        let comp = comp.clone();
                        let sk = sk.clone();
                        entered(once_job(move || {
                            let acc = p0;
                            let d = p1;
                            if check_types::has_text(&comp, &d.qk) {
                                call_then(start_call_graphs(sk.clone(), d.clone(), comp.clone()), move |call_graphs_68420: Array<Sc>| prism_rtl::Turn::Finished(append(&acc, &call_graphs_68420)))
                            } else {
                                prism_rtl::Turn::Finished(acc.clone())
                            }
                        }))
                    }) as Rc<dyn Fn((Array<Sc>, check_env::Def)) -> Rc<dyn prism_rtl::Job<Array<Sc>>>>
                }), move |fold_68355: Array<Sc>| {
                    let graphs = fold_68355;
                    call_then(start_closure(graphs.clone()), move |closure_68476: Array<Sc>| {
                        let closure_ = closure_68476;
                        let bad = filter(&closure_, &(|sc: &Sc| ((&sc.caller == &sc.callee) && (&compose(sc, sc).edges == &sc.edges)) && !fold(&sc.edges, &false, &(|seen: &bool, (a, b, s): &(Nat, Nat, bool)| *seen || ((a == b) && *s)))));
                        match index(&bad, &Nat::from(0u32)) {
                            Some(sc) => {
                                let s2 = {
                                    let mut this: check_types::St = st.clone();
                                    this.file = sc.file.clone();
                                    this
                                };
                                let what = if &sc.arg == &Text::from("") {
                                    Text::from("")
                                } else {
                                    Text::from(format!(" on `{}`", &sc.arg))
                                };
                                let st3 = check_types::err_fix(&s2, &Text::from("may-not-end"), &sc.span, &Text::from(format!("`{}` calls {}{}, not smaller than what it was given", &shown_key(&sc.caller), &(if &sc.caller == &sc.callee {
                                    Text::from("itself")
                                } else {
                                    Text::from(format!("`{}`", &shown_key(&sc.callee)))
                                }), &what)), &Text::from("make an argument shrink (a part taken apart by `match`, or the `? m` of `match n -? 1`), or mark the cycle's functions `unbounded fn`"));
                                prism_rtl::Turn::Finished({
                                    let mut this: check_types::St = st3.clone();
                                    this.file = st.file.clone();
                                    this
                                })
                            },
                            None => prism_rtl::Turn::Finished(st.clone()),
                        }
                    })
                })
            }
        }
    }
}

/// `Start ShrinkComponent, x`: what the function value is when passed to `@Run`.
pub fn start_shrink_component(sk: Shrink, st: check_types::St, comp: Array<Text>) -> Rc<dyn prism_rtl::Job<check_types::St>> {
    Rc::new(ShrinkComponent { sk, st, comp })
}

/// ```prism
/// CallGraphs: unbounded fn Shrink, Def, [Text] -> [Sc]
/// ```
pub fn call_graphs(sk: &Shrink, d: &check_env::Def, comp: &Array<Text>) -> Array<Sc> {
    run_to_end(fold_job(def_clauses(d), Array::new(), {
        let sk = sk.clone();
        let d = d.clone();
        let comp = comp.clone();
        Rc::new(move |(p0, p1): (Array<Sc>, ast::FnClause)| {
            let sk = sk.clone();
            let d = d.clone();
            let comp = comp.clone();
            entered(once_job(move || {
                let acc = p0;
                let c = p1;
                call_then(start_clause_graphs(sk.clone(), d.clone(), c.clone(), comp.clone()), move |clause_graphs_69538: Array<Sc>| prism_rtl::Turn::Finished(append(&acc, &clause_graphs_69538)))
            }))
        }) as Rc<dyn Fn((Array<Sc>, ast::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Sc>>>>
    }))
}

/// The step machine of `CallGraphs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallGraphs: unbounded fn Shrink, Def, [Text] -> [Sc]
/// ```
pub struct CallGraphs {
    pub sk: Shrink,
    pub d: check_env::Def,
    pub comp: Array<Text>,
}

impl prism_rtl::Job<Array<Sc>> for CallGraphs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Sc>> {
        let sk = &self.sk;
        let d = &self.d;
        let comp = &self.comp;
        fold_job(def_clauses(d), Array::new(), {
            let sk = sk.clone();
            let d = d.clone();
            let comp = comp.clone();
            Rc::new(move |(p0, p1): (Array<Sc>, ast::FnClause)| {
                let sk = sk.clone();
                let d = d.clone();
                let comp = comp.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let c = p1;
                    call_then(start_clause_graphs(sk.clone(), d.clone(), c.clone(), comp.clone()), move |clause_graphs_69538: Array<Sc>| prism_rtl::Turn::Finished(append(&acc, &clause_graphs_69538)))
                }))
            }) as Rc<dyn Fn((Array<Sc>, ast::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Sc>>>>
        }).cycle()
    }
}

/// `Start CallGraphs, x`: what the function value is when passed to `@Run`.
pub fn start_call_graphs(sk: Shrink, d: check_env::Def, comp: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Sc>>> {
    Rc::new(CallGraphs { sk, d, comp })
}

/// ```prism
/// ClauseGraphs: unbounded fn Shrink, Def, FnClause, [Text] -> [Sc]
/// ```
pub fn clause_graphs(sk: &Shrink, d: &check_env::Def, c: &ast::FnClause, comp: &Array<Text>) -> Array<Sc> {
    let base = clause_base(sk, d, c);
    let rels = summary_seeds(sk, d, &body_spots(&c.body, &base), &base);
    run_to_end(fold_job(body_sites(&c.body, &rels), Array::new(), {
        let sk = sk.clone();
        let d = d.clone();
        let comp = comp.clone();
        Rc::new(move |(p0, p1): (Array<Sc>, Site)| {
            let sk = sk.clone();
            let d = d.clone();
            let comp = comp.clone();
            entered(once_job(move || {
                let acc = p0;
                let site = p1;
                match local_target(&sk, &d, &site) {
                    Some(t) => if check_types::has_text(&comp, &t) {
                        call_then(start_site_graph(sk.clone(), d.clone(), site.clone(), t.clone()), move |site_graph_69896: Sc| prism_rtl::Turn::Finished(push(&acc, &site_graph_69896)))
                    } else {
                        prism_rtl::Turn::Finished(acc.clone())
                    },
                    None => if is_local(&site.rels, &site.callee) || check_env::has_key(&sk.local_of, &d.qk) {
                        prism_rtl::Turn::Finished(acc.clone())
                    } else {
                        match resolve_callee(&sk.g, &d.home, &site.callee) {
                            Some(k) => call_then(start_dispatch_targets(sk.clone(), d.clone(), site.clone(), k.clone()), move |dispatch_targets_70118: Array<Text>| fold_job(dispatch_targets_70118, acc.clone(), {
                                let comp = comp.clone();
                                let sk = sk.clone();
                                let d = d.clone();
                                let site = site.clone();
                                Rc::new(move |(p0, p1): (Array<Sc>, Text)| {
                                    let comp = comp.clone();
                                    let sk = sk.clone();
                                    let d = d.clone();
                                    let site = site.clone();
                                    entered(once_job(move || {
                                        let acc2 = p0;
                                        let t = p1;
                                        if check_types::has_text(&comp, &t) {
                                            call_then(start_site_graph(sk.clone(), d.clone(), site.clone(), t.clone()), move |site_graph_70199: Sc| prism_rtl::Turn::Finished(push(&acc2, &site_graph_70199)))
                                        } else {
                                            prism_rtl::Turn::Finished(acc2.clone())
                                        }
                                    }))
                                }) as Rc<dyn Fn((Array<Sc>, Text)) -> Rc<dyn prism_rtl::Job<Array<Sc>>>>
                            }).cycle()),
                            None => prism_rtl::Turn::Finished(acc.clone()),
                        }
                    },
                }
            }))
        }) as Rc<dyn Fn((Array<Sc>, Site)) -> Rc<dyn prism_rtl::Job<Array<Sc>>>>
    }))
}

/// The step machine of `ClauseGraphs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseGraphs: unbounded fn Shrink, Def, FnClause, [Text] -> [Sc]
/// ```
pub struct ClauseGraphs {
    pub sk: Shrink,
    pub d: check_env::Def,
    pub c: ast::FnClause,
    pub comp: Array<Text>,
}

impl prism_rtl::Job<Array<Sc>> for ClauseGraphs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Sc>> {
        let sk = &self.sk;
        let d = &self.d;
        let c = &self.c;
        let comp = &self.comp;
        let c = c.clone();
        let comp = comp.clone();
        let d = d.clone();
        let sk = sk.clone();
        call_then(start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_69680: Map<Text, Rel>| {
            let base = clause_base_69680;
            call_then(start_body_spots(c.body.clone(), base.clone()), move |body_spots_69736: Array<Spot>| call_then(start_summary_seeds(sk.clone(), d.clone(), body_spots_69736, base.clone()), move |summary_seeds_69715: Map<Text, Rel>| {
                let rels = summary_seeds_69715;
                call_then(start_body_sites(c.body.clone(), rels.clone()), move |body_sites_69776: Array<Site>| fold_job(body_sites_69776, Array::new(), {
                    let sk = sk.clone();
                    let d = d.clone();
                    let comp = comp.clone();
                    Rc::new(move |(p0, p1): (Array<Sc>, Site)| {
                        let sk = sk.clone();
                        let d = d.clone();
                        let comp = comp.clone();
                        entered(once_job(move || {
                            let acc = p0;
                            let site = p1;
                            match local_target(&sk, &d, &site) {
                                Some(t) => if check_types::has_text(&comp, &t) {
                                    call_then(start_site_graph(sk.clone(), d.clone(), site.clone(), t.clone()), move |site_graph_69896: Sc| prism_rtl::Turn::Finished(push(&acc, &site_graph_69896)))
                                } else {
                                    prism_rtl::Turn::Finished(acc.clone())
                                },
                                None => if is_local(&site.rels, &site.callee) || check_env::has_key(&sk.local_of, &d.qk) {
                                    prism_rtl::Turn::Finished(acc.clone())
                                } else {
                                    match resolve_callee(&sk.g, &d.home, &site.callee) {
                                        Some(k) => call_then(start_dispatch_targets(sk.clone(), d.clone(), site.clone(), k.clone()), move |dispatch_targets_70118: Array<Text>| fold_job(dispatch_targets_70118, acc.clone(), {
                                            let comp = comp.clone();
                                            let sk = sk.clone();
                                            let d = d.clone();
                                            let site = site.clone();
                                            Rc::new(move |(p0, p1): (Array<Sc>, Text)| {
                                                let comp = comp.clone();
                                                let sk = sk.clone();
                                                let d = d.clone();
                                                let site = site.clone();
                                                entered(once_job(move || {
                                                    let acc2 = p0;
                                                    let t = p1;
                                                    if check_types::has_text(&comp, &t) {
                                                        call_then(start_site_graph(sk.clone(), d.clone(), site.clone(), t.clone()), move |site_graph_70199: Sc| prism_rtl::Turn::Finished(push(&acc2, &site_graph_70199)))
                                                    } else {
                                                        prism_rtl::Turn::Finished(acc2.clone())
                                                    }
                                                }))
                                            }) as Rc<dyn Fn((Array<Sc>, Text)) -> Rc<dyn prism_rtl::Job<Array<Sc>>>>
                                        }).cycle()),
                                        None => prism_rtl::Turn::Finished(acc.clone()),
                                    }
                                },
                            }
                        }))
                    }) as Rc<dyn Fn((Array<Sc>, Site)) -> Rc<dyn prism_rtl::Job<Array<Sc>>>>
                }).cycle())
            }))
        })
    }
}

/// `Start ClauseGraphs, x`: what the function value is when passed to `@Run`.
pub fn start_clause_graphs(sk: Shrink, d: check_env::Def, c: ast::FnClause, comp: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Sc>>> {
    Rc::new(ClauseGraphs { sk, d, c, comp })
}

/// ```prism
/// SiteGraph: unbounded fn Shrink, Def, Site, Text -> Sc
/// ```
pub fn site_graph(sk: &Shrink, d: &check_env::Def, site: &Site, k: &Text) -> Sc {
    let edges_ = run_to_end(fold_job(arg_slots(sk, &site.args, k), Array::new(), {
        let site = site.clone();
        Rc::new(move |(p0, p1): (Array<(Nat, Nat, bool)>, (Nat, ast::Arg))| {
            let site = site.clone();
            entered(once_job(move || {
                let es = p0;
                let (j, a) = p1;
                call_then(start_rel_of(site.rels.clone(), a.value.clone()), move |rel_of_70537: Option<Rel>| match rel_of_70537 {
                    Some(r) => prism_rtl::Turn::Finished(push(&es, &(r.param.clone(), j.clone(), r.strict))),
                    None => prism_rtl::Turn::Finished(es.clone()),
                })
            }))
        }) as Rc<dyn Fn((Array<(Nat, Nat, bool)>, (Nat, ast::Arg))) -> Rc<dyn prism_rtl::Job<Array<(Nat, Nat, bool)>>>>
    }));
    let arg_text = match index(&site.args, &Nat::from(0u32)) {
        Some(a) => expr_name(&a.value),
        None => Text::from(""),
    };
    Sc { caller: d.qk.clone(), callee: k.clone(), edges: edges_.clone(), span: site.span.clone(), file: d.file.clone(), arg: arg_text.clone() }
}

/// The step machine of `SiteGraph`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SiteGraph: unbounded fn Shrink, Def, Site, Text -> Sc
/// ```
pub struct SiteGraph {
    pub sk: Shrink,
    pub d: check_env::Def,
    pub site: Site,
    pub k: Text,
}

impl prism_rtl::Job<Sc> for SiteGraph {
    fn cycle(&self) -> prism_rtl::Turn<Sc> {
        let sk = &self.sk;
        let d = &self.d;
        let site = &self.site;
        let k = &self.k;
        let d = d.clone();
        let k = k.clone();
        let site = site.clone();
        let sk = sk.clone();
        call_then(start_arg_slots(sk.clone(), site.args.clone(), k.clone()), move |arg_slots_70481: Array<(Nat, ast::Arg)>| call_value(fold_job(arg_slots_70481, Array::new(), {
            let site = site.clone();
            Rc::new(move |(p0, p1): (Array<(Nat, Nat, bool)>, (Nat, ast::Arg))| {
                let site = site.clone();
                entered(once_job(move || {
                    let es = p0;
                    let (j, a) = p1;
                    call_then(start_rel_of(site.rels.clone(), a.value.clone()), move |rel_of_70537: Option<Rel>| match rel_of_70537 {
                        Some(r) => prism_rtl::Turn::Finished(push(&es, &(r.param.clone(), j.clone(), r.strict))),
                        None => prism_rtl::Turn::Finished(es.clone()),
                    })
                }))
            }) as Rc<dyn Fn((Array<(Nat, Nat, bool)>, (Nat, ast::Arg))) -> Rc<dyn prism_rtl::Job<Array<(Nat, Nat, bool)>>>>
        }), move |fold_70475: Array<(Nat, Nat, bool)>| {
            let edges_ = fold_70475;
            let arg_text = match index(&site.args, &Nat::from(0u32)) {
                Some(a) => expr_name(&a.value),
                None => Text::from(""),
            };
            prism_rtl::Turn::Finished(Sc { caller: d.qk.clone(), callee: k.clone(), edges: edges_.clone(), span: site.span.clone(), file: d.file.clone(), arg: arg_text.clone() })
        }))
    }
}

/// `Start SiteGraph, x`: what the function value is when passed to `@Run`.
pub fn start_site_graph(sk: Shrink, d: check_env::Def, site: Site, k: Text) -> Rc<dyn prism_rtl::Job<Sc>> {
    Rc::new(SiteGraph { sk, d, site, k })
}

/// ```prism
/// ArgSlots: unbounded fn Shrink, [Arg], Text -> [((Nat, Arg))]
/// ```
pub fn arg_slots(sk: &Shrink, args: &Array<ast::Arg>, k: &Text) -> Array<(Nat, ast::Arg)> {
    let (_, out) = run_to_end(fold_job(args.clone(), (Nat::from(0u32), Array::new()), {
        let sk = sk.clone();
        let k = k.clone();
        Rc::new(move |(p0, p1): ((Nat, Array<(Nat, ast::Arg)>), ast::Arg)| {
            let sk = sk.clone();
            let k = k.clone();
            entered(once_job(move || {
                let (pos, acc) = p0;
                let a = p1;
                match &a.name {
                    None => prism_rtl::Turn::Finished((&pos + &Nat::from(1u32), push(&acc, &(pos.clone(), a.clone())))),
                    Some(id) => {
                        let id = id.clone();
                        call_then(start_param_named(sk.clone(), k.clone(), id.name.clone()), move |param_named_71351: Option<Nat>| match param_named_71351 {
                            Some(j) => prism_rtl::Turn::Finished((pos.clone(), push(&acc, &(j.clone(), a.clone())))),
                            None => prism_rtl::Turn::Finished((pos.clone(), acc.clone())),
                        })
                    },
                }
            }))
        }) as Rc<dyn Fn(((Nat, Array<(Nat, ast::Arg)>), ast::Arg)) -> Rc<dyn prism_rtl::Job<(Nat, Array<(Nat, ast::Arg)>)>>>
    }));
    out.clone()
}

/// The step machine of `ArgSlots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArgSlots: unbounded fn Shrink, [Arg], Text -> [((Nat, Arg))]
/// ```
pub struct ArgSlots {
    pub sk: Shrink,
    pub args: Array<ast::Arg>,
    pub k: Text,
}

impl prism_rtl::Job<Array<(Nat, ast::Arg)>> for ArgSlots {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Nat, ast::Arg)>> {
        let sk = &self.sk;
        let args = &self.args;
        let k = &self.k;
        let args = args.clone();
        let k = k.clone();
        let sk = sk.clone();
        call_value(fold_job(args.clone(), (Nat::from(0u32), Array::new()), {
            let sk = sk.clone();
            let k = k.clone();
            Rc::new(move |(p0, p1): ((Nat, Array<(Nat, ast::Arg)>), ast::Arg)| {
                let sk = sk.clone();
                let k = k.clone();
                entered(once_job(move || {
                    let (pos, acc) = p0;
                    let a = p1;
                    match &a.name {
                        None => prism_rtl::Turn::Finished((&pos + &Nat::from(1u32), push(&acc, &(pos.clone(), a.clone())))),
                        Some(id) => {
                            let id = id.clone();
                            call_then(start_param_named(sk.clone(), k.clone(), id.name.clone()), move |param_named_71351: Option<Nat>| match param_named_71351 {
                                Some(j) => prism_rtl::Turn::Finished((pos.clone(), push(&acc, &(j.clone(), a.clone())))),
                                None => prism_rtl::Turn::Finished((pos.clone(), acc.clone())),
                            })
                        },
                    }
                }))
            }) as Rc<dyn Fn(((Nat, Array<(Nat, ast::Arg)>), ast::Arg)) -> Rc<dyn prism_rtl::Job<(Nat, Array<(Nat, ast::Arg)>)>>>
        }), move |fold_71224: (Nat, Array<(Nat, ast::Arg)>)| {
            let (_, out) = fold_71224;
            prism_rtl::Turn::Finished(out.clone())
        })
    }
}

/// `Start ArgSlots, x`: what the function value is when passed to `@Run`.
pub fn start_arg_slots(sk: Shrink, args: Array<ast::Arg>, k: Text) -> Rc<dyn prism_rtl::Job<Array<(Nat, ast::Arg)>>> {
    Rc::new(ArgSlots { sk, args, k })
}

/// ```prism
/// ?ParamNamed: unbounded fn Shrink, Text, Text -> ?Nat
/// ```
pub fn param_named(sk: &Shrink, k: &Text, name: &Text) -> Option<Nat> {
    let clauses = def_clauses(&or(&get(&sk.by_key, k), &check_env::dummy_def()));
    if name == &Text::from("#body") {
        match index(&clauses, &Nat::from(0u32)) {
            Some(c) => if &len(&c.params) > &Nat::from(0u32) {
                Some(lexer::dec(&len(&c.params)))
            } else {
                None
            },
            None => None,
        }
    } else {
        param_named_in(&clauses, name)
    }
}

/// The step machine of `ParamNamed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?ParamNamed: unbounded fn Shrink, Text, Text -> ?Nat
/// ```
pub struct ParamNamed {
    pub sk: Shrink,
    pub k: Text,
    pub name: Text,
}

impl prism_rtl::Job<Option<Nat>> for ParamNamed {
    fn cycle(&self) -> prism_rtl::Turn<Option<Nat>> {
        let sk = &self.sk;
        let k = &self.k;
        let name = &self.name;
        let clauses = def_clauses(&or(&get(&sk.by_key, k), &check_env::dummy_def()));
        if name == &Text::from("#body") {
            match index(&clauses, &Nat::from(0u32)) {
                Some(c) => if &len(&c.params) > &Nat::from(0u32) {
                    prism_rtl::Turn::Finished(Some(lexer::dec(&len(&c.params))))
                } else {
                    prism_rtl::Turn::Finished(None)
                },
                None => prism_rtl::Turn::Finished(None),
            }
        } else {
            prism_rtl::Turn::Finished(param_named_in(&clauses, name))
        }
    }
}

/// `Start ParamNamed, x`: what the function value is when passed to `@Run`.
pub fn start_param_named(sk: Shrink, k: Text, name: Text) -> Rc<dyn prism_rtl::Job<Option<Nat>>> {
    Rc::new(ParamNamed { sk, k, name })
}

/// ```prism
/// ?ParamNamedIn: unbounded fn [FnClause], Text -> ?Nat
/// ```
pub fn param_named_in(clauses: &Array<ast::FnClause>, name: &Text) -> Option<Nat> {
    let found = run_to_end(fold_job(clauses.clone(), Array::new(), {
        let name = name.clone();
        Rc::new(move |(p0, p1): (Array<Nat>, ast::FnClause)| {
            let name = name.clone();
            entered(once_job(move || {
                let acc = p0;
                let c = p1;
                fold_job(check_errors::range0(&len(&c.params)), acc.clone(), {
                    let c = c.clone();
                    let name = name.clone();
                    Rc::new(move |(p0, p1): (Array<Nat>, Nat)| {
                        let c = c.clone();
                        let name = name.clone();
                        entered(once_job(move || {
                            let a2 = p0;
                            let i = p1;
                            match index(&c.params, &i) {
                                Some(p_) => if (&param_name_of(&p_) == &name) && !check_types::has_nat(&a2, &i) {
                                    prism_rtl::Turn::Finished(push(&a2, &i))
                                } else {
                                    prism_rtl::Turn::Finished(a2.clone())
                                },
                                None => prism_rtl::Turn::Finished(a2.clone()),
                            }
                        }))
                    }) as Rc<dyn Fn((Array<Nat>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
                }).cycle()
            }))
        }) as Rc<dyn Fn((Array<Nat>, ast::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
    }));
    if &len(&found) == &Nat::from(1u32) { index(&found, &Nat::from(0u32)) } else { None }
}

/// ```prism
/// ParamNameOf: unbounded fn Pattern -> Text
/// ```
pub fn param_name_of(p_: &ast::Pattern_) -> Text {
    match &*p_.kind {
        ast::PatternKind::PName(n) => {
            let text = check_env::sname_key(n);
            lexer::drop_prefix(&text, &check_types::marks_of(&text))
        },
        ast::PatternKind::PGroup(q) => param_name_of(&**q),
        _ => Text::from(""),
    }
}

/// ```prism
/// ExprName: fn Expr -> Text
/// ```
pub fn expr_name(e: &ast::Expr) -> Text {
    match &*e.kind {
        ast::ExprKind::EName(n) => check_env::sname_key(n),
        ast::ExprKind::EGroup(x) => expr_name(&**x),
        _ => Text::from(""),
    }
}

/// ```prism
/// ParamRelsOn: unbounded fn (Text ==> Rel), [Pattern] -> (Text ==> Rel)
/// ```
pub fn param_rels_on(base: &Map<Text, Rel>, ps: &Array<ast::Pattern_>) -> Map<Text, Rel> {
    run_to_end(fold_job(check_errors::range0(&len(ps)), hide(base, &patterns_names(ps)), {
        let ps = ps.clone();
        Rc::new(move |(p0, p1): (Map<Text, Rel>, Nat)| {
            let ps = ps.clone();
            entered(once_job(move || {
                let m = p0;
                let i = p1;
                match index(&ps, &i) {
                    Some(p_) => match &*p_.kind {
                        ast::PatternKind::PName(n) => prism_rtl::Turn::Finished(insert(&m, &check_env::sname_key(n), &Rel { param: i.clone(), strict: false })),
                        _ => call_then(check_env::start_pattern_names(p_.clone()), move |pattern_names_73124: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_73124, &m, &(|m2: &Map<Text, Rel>, n: &Text| insert(m2, n, &Rel { param: i.clone(), strict: true }))))),
                    },
                    None => prism_rtl::Turn::Finished(m.clone()),
                }
            }))
        }) as Rc<dyn Fn((Map<Text, Rel>, Nat)) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>>>
    }))
}

/// The step machine of `ParamRelsOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParamRelsOn: unbounded fn (Text ==> Rel), [Pattern] -> (Text ==> Rel)
/// ```
pub struct ParamRelsOn {
    pub base: Map<Text, Rel>,
    pub ps: Array<ast::Pattern_>,
}

impl prism_rtl::Job<Map<Text, Rel>> for ParamRelsOn {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Rel>> {
        let base = &self.base;
        let ps = &self.ps;
        let base = base.clone();
        let ps = ps.clone();
        call_then(start_patterns_names(ps.clone()), move |patterns_names_72967: Array<Text>| fold_job(check_errors::range0(&len(&ps)), hide(&base, &patterns_names_72967), {
            let ps = ps.clone();
            Rc::new(move |(p0, p1): (Map<Text, Rel>, Nat)| {
                let ps = ps.clone();
                entered(once_job(move || {
                    let m = p0;
                    let i = p1;
                    match index(&ps, &i) {
                        Some(p_) => match &*p_.kind {
                            ast::PatternKind::PName(n) => prism_rtl::Turn::Finished(insert(&m, &check_env::sname_key(n), &Rel { param: i.clone(), strict: false })),
                            _ => call_then(check_env::start_pattern_names(p_.clone()), move |pattern_names_73124: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_73124, &m, &(|m2: &Map<Text, Rel>, n: &Text| insert(m2, n, &Rel { param: i.clone(), strict: true }))))),
                        },
                        None => prism_rtl::Turn::Finished(m.clone()),
                    }
                }))
            }) as Rc<dyn Fn((Map<Text, Rel>, Nat)) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>>>
        }).cycle())
    }
}

/// `Start ParamRelsOn, x`: what the function value is when passed to `@Run`.
pub fn start_param_rels_on(base: Map<Text, Rel>, ps: Array<ast::Pattern_>) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>> {
    Rc::new(ParamRelsOn { base, ps })
}

/// ```prism
/// Hide: fn (Text ==> Rel), [Text] -> (Text ==> Rel)
/// ```
pub fn hide(m: &Map<Text, Rel>, names: &Array<Text>) -> Map<Text, Rel> {
    fold(names, m, &(|m2: &Map<Text, Rel>, n: &Text| insert(&remove(&remove(&remove(&remove(m2, n), &Text::from(format!("ne:{}", n))), &Text::from(format!("lamlet:{}", n))), &Text::from(format!("lfn:{}", n))), &Text::from(format!("local:{}", n)), &no_rel())))
}

/// ```prism
/// let noRel
/// ```
pub fn no_rel() -> Rel {
    Rel { param: Nat::from(0u32), strict: false }
}

/// ```prism
/// IsLocal: fn (Text ==> Rel), Text -> Bool
/// ```
pub fn is_local(m: &Map<Text, Rel>, n: &Text) -> bool {
    check_env::has_key(m, &Text::from(format!("local:{}", n)))
}

/// ```prism
/// PreIs: fn (Text ==> Rel), Text, Text -> Bool
/// ```
pub fn pre_is(m: &Map<Text, Rel>, n: &Text, bare: &Text) -> bool {
    (((n == bare) || (n == &Text::from(format!("Prelude.{}", bare)))) && check_env::has_key(m, &Text::from(format!("pre:{}", n)))) && !is_local(m, n)
}

/// ```prism
/// let preludeNames
/// ```
pub fn prelude_names() -> Array<Text> {
    Array::from(vec![Text::from("Drop"), Text::from("Take"), Text::from("Filter"), Text::from("Remove"), Text::from("Min"), Text::from("Values"), Text::from("Keys"), Text::from("?Step"), Text::from("Fold"), Text::from("Each"), Text::from("Push"), Text::from("Insert"), Text::from("Append"), Text::from("Freeze"), Text::from("-?"), Text::from("@Defer"), Text::from("@Later"), Text::from("@Run"), Text::from("@Machine"), Text::from("@started")])
}

/// ```prism
/// PreludeSeeds: fn G, Text -> (Text ==> Rel)
/// ```
pub fn prelude_seeds(g: &check_env::G, h: &Text) -> Map<Text, Rel> {
    fold(&prelude_names(), &Map::new(), &(|m: &Map<Text, Rel>, n: &Text| {
        let q = Text::from(format!("Prelude.{}", n));
        if !is_prelude_key(g, &q) {
            m.clone()
        } else {
            fold(&Array::from(vec![n.clone(), q.clone()]), m, &(|m2: &Map<Text, Rel>, sp: &Text| if &resolve_callee(g, h, sp) == &Some(q.clone()) {
                insert(m2, &Text::from(format!("pre:{}", sp)), &no_rel())
            } else {
                m2.clone()
            }))
        }
    }))
}

/// ```prism
/// IsPreludeKey: fn G, Text -> Bool
/// ```
pub fn is_prelude_key(g: &check_env::G, q: &Text) -> bool {
    match get(&g.vals, q) {
        Some(v_) => (lexer::has_prefix(q, &Text::from("Prelude.")) && (&v_.home == &Text::from("Prelude"))) && (&v_.file >= &g.prelude_from),
        None => false,
    }
}

/// ```prism
/// BlockRels: unbounded fn [Stmt], (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn block_rels(stmts: &Array<ast::Stmt>, m: &Map<Text, Rel>) -> Map<Text, Rel> {
    run_to_end(fold_job(stmts.clone(), local_fn_marks(stmts, &hide(m, &stmts_binders(stmts))), Rc::new(move |(p0, p1): (Map<Text, Rel>, ast::Stmt)| entered(once_job(move || {
        let m2 = p0;
        let s = p1;
        call_then(start_stmt_rels(s.clone(), m2.clone()), move |stmt_rels_76562: Map<Text, Rel>| prism_rtl::Turn::Finished(lam_let_rels(&s, &stmt_rels_76562)))
    }))) as Rc<dyn Fn((Map<Text, Rel>, ast::Stmt)) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>>>))
}

/// The step machine of `BlockRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockRels: unbounded fn [Stmt], (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub struct BlockRels {
    pub stmts: Array<ast::Stmt>,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Map<Text, Rel>> for BlockRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Rel>> {
        let stmts = &self.stmts;
        let m = &self.m;
        let m = m.clone();
        let stmts = stmts.clone();
        call_then(start_stmts_binders(stmts.clone()), move |stmts_binders_76515: Array<Text>| fold_job(stmts.clone(), local_fn_marks(&stmts, &hide(&m, &stmts_binders_76515)), Rc::new(move |(p0, p1): (Map<Text, Rel>, ast::Stmt)| entered(once_job(move || {
            let m2 = p0;
            let s = p1;
            call_then(start_stmt_rels(s.clone(), m2.clone()), move |stmt_rels_76562: Map<Text, Rel>| prism_rtl::Turn::Finished(lam_let_rels(&s, &stmt_rels_76562)))
        }))) as Rc<dyn Fn((Map<Text, Rel>, ast::Stmt)) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>>>).cycle())
    }
}

/// `Start BlockRels, x`: what the function value is when passed to `@Run`.
pub fn start_block_rels(stmts: Array<ast::Stmt>, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>> {
    Rc::new(BlockRels { stmts, m })
}

/// ```prism
/// LocalFnMarks: fn [Stmt], (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn local_fn_marks(stmts: &Array<ast::Stmt>, m: &Map<Text, Rel>) -> Map<Text, Rel> {
    fold(stmts, m, &(|m2: &Map<Text, Rel>, s: &ast::Stmt| {
        let n_opt = match &s.kind {
            ast::StmtKind::SFn(f) => Some(check_env::def_name_text(&f.name)),
            ast::StmtKind::SWidget(w) => Some(check_env::sname_key(&w.name)),
            _ => None,
        };
        match &n_opt {
            Some(n) => if check_env::has_key(m2, &Text::from(format!("lfn:{}", n))) {
                m2.clone()
            } else {
                insert(m2, &Text::from(format!("lfn:{}", n)), &Rel { param: s.span.start.clone(), strict: false })
            },
            None => m2.clone(),
        }
    }))
}

/// ```prism
/// StmtsBinders: unbounded fn [Stmt] -> [Text]
/// ```
pub fn stmts_binders(stmts: &Array<ast::Stmt>) -> Array<Text> {
    run_to_end(fold_job(stmts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, ast::Stmt)| entered(once_job(move || {
        let acc = p0;
        let s = p1;
        match &s.kind {
            ast::StmtKind::SLet(p_, _, _) => {
                let p_ = p_.clone();
                call_then(check_env::start_pattern_names(p_.clone()), move |pattern_names_77236: Array<Text>| prism_rtl::Turn::Finished(check_types::union_texts(&acc, &pattern_names_77236)))
            },
            ast::StmtKind::SBind(p_, _, _) => {
                let p_ = p_.clone();
                call_then(check_env::start_pattern_names(p_.clone()), move |pattern_names_77298: Array<Text>| prism_rtl::Turn::Finished(check_types::union_texts(&acc, &pattern_names_77298)))
            },
            ast::StmtKind::SFn(f) => prism_rtl::Turn::Finished(check_types::add_text(&acc, &check_env::def_name_text(&f.name))),
            ast::StmtKind::SWidget(w) => prism_rtl::Turn::Finished(check_types::add_text(&acc, &check_env::sname_key(&w.name))),
            _ => prism_rtl::Turn::Finished(acc.clone()),
        }
    }))) as Rc<dyn Fn((Array<Text>, ast::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))
}

/// The step machine of `StmtsBinders`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtsBinders: unbounded fn [Stmt] -> [Text]
/// ```
pub struct StmtsBinders {
    pub stmts: Array<ast::Stmt>,
}

impl prism_rtl::Job<Array<Text>> for StmtsBinders {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let stmts = &self.stmts;
        fold_job(stmts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, ast::Stmt)| entered(once_job(move || {
            let acc = p0;
            let s = p1;
            match &s.kind {
                ast::StmtKind::SLet(p_, _, _) => {
                    let p_ = p_.clone();
                    call_then(check_env::start_pattern_names(p_.clone()), move |pattern_names_77236: Array<Text>| prism_rtl::Turn::Finished(check_types::union_texts(&acc, &pattern_names_77236)))
                },
                ast::StmtKind::SBind(p_, _, _) => {
                    let p_ = p_.clone();
                    call_then(check_env::start_pattern_names(p_.clone()), move |pattern_names_77298: Array<Text>| prism_rtl::Turn::Finished(check_types::union_texts(&acc, &pattern_names_77298)))
                },
                ast::StmtKind::SFn(f) => prism_rtl::Turn::Finished(check_types::add_text(&acc, &check_env::def_name_text(&f.name))),
                ast::StmtKind::SWidget(w) => prism_rtl::Turn::Finished(check_types::add_text(&acc, &check_env::sname_key(&w.name))),
                _ => prism_rtl::Turn::Finished(acc.clone()),
            }
        }))) as Rc<dyn Fn((Array<Text>, ast::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle()
    }
}

/// `Start StmtsBinders, x`: what the function value is when passed to `@Run`.
pub fn start_stmts_binders(stmts: Array<ast::Stmt>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(StmtsBinders { stmts })
}

/// ```prism
/// StmtRels: unbounded fn Stmt, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn stmt_rels(s: &ast::Stmt, m: &Map<Text, Rel>) -> Map<Text, Rel> {
    match &s.kind {
        ast::StmtKind::SLet(p_, _, e) => bind_rels(p_, e, m, &false),
        ast::StmtKind::SBind(p_, e, None) => bind_rels(p_, e, m, &true),
        _ => m.clone(),
    }
}

/// The step machine of `StmtRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtRels: unbounded fn Stmt, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub struct StmtRels {
    pub s: ast::Stmt,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Map<Text, Rel>> for StmtRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Rel>> {
        let s = &self.s;
        let m = &self.m;
        match &s.kind {
            ast::StmtKind::SLet(p_, _, e) => prism_rtl::Turn::More(Rc::new(BindRels { p_: p_.clone(), e: e.clone(), m: m.clone(), refutable: false })),
            ast::StmtKind::SBind(p_, e, None) => prism_rtl::Turn::More(Rc::new(BindRels { p_: p_.clone(), e: e.clone(), m: m.clone(), refutable: true })),
            _ => prism_rtl::Turn::Finished(m.clone()),
        }
    }
}

/// `Start StmtRels, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_rels(s: ast::Stmt, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>> {
    Rc::new(StmtRels { s, m })
}

/// ```prism
/// BindRels: unbounded fn Pattern, Expr, (Text ==> Rel), Bool -> (Text ==> Rel)
/// ```
pub fn bind_rels(p_: &ast::Pattern_, e: &ast::Expr, m: &Map<Text, Rel>, refutable: &bool) -> Map<Text, Rel> {
    let base_opt = rel_of(m, e);
    let dec_opt = decrement_of(m, e);
    let h = non_empty_rels(&hide(m, &check_env::pattern_names(p_)), p_, e, refutable);
    match &*p_.kind {
        ast::PatternKind::PName(n) => match &base_opt {
            Some(r) => insert(&h, &check_env::sname_key(n), r),
            None => match &dec_opt {
                Some(r) => if *refutable { insert(&h, &check_env::sname_key(n), r) } else { h.clone() },
                None => h.clone(),
            },
        },
        ast::PatternKind::PSigil(m78062_1_0, inner) if (m78062_1_0 == &Text::from("?")) => match &dec_opt {
            Some(r) => fold(&check_env::pattern_names(&**inner), &h, &(|m2: &Map<Text, Rel>, n: &Text| insert(m2, n, r))),
            None => match &base_opt {
                Some(r) => fold(&check_env::pattern_names(&**inner), &h, &(|m2: &Map<Text, Rel>, n: &Text| insert(m2, n, &Rel { param: r.param.clone(), strict: true }))),
                None => h.clone(),
            },
        },
        _ => match &base_opt {
            Some(r) => fold(&check_env::pattern_names(p_), &h, &(|m2: &Map<Text, Rel>, n: &Text| insert(m2, n, &Rel { param: r.param.clone(), strict: true }))),
            None => h.clone(),
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `BindRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindRels: unbounded fn Pattern, Expr, (Text ==> Rel), Bool -> (Text ==> Rel)
/// ```
pub struct BindRels {
    pub p_: ast::Pattern_,
    pub e: ast::Expr,
    pub m: Map<Text, Rel>,
    pub refutable: bool,
}

impl prism_rtl::Job<Map<Text, Rel>> for BindRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Rel>> {
        let p_ = &self.p_;
        let e = &self.e;
        let m = &self.m;
        let refutable = &self.refutable;
        let e = e.clone();
        let m = m.clone();
        let p_ = p_.clone();
        let refutable = *refutable;
        call_then(start_rel_of(m.clone(), e.clone()), move |rel_of_77944: Option<Rel>| {
            let base_opt = rel_of_77944;
            call_then(start_decrement_of(m.clone(), e.clone()), move |decrement_of_77971: Option<Rel>| {
                let dec_opt = decrement_of_77971;
                call_then(check_env::start_pattern_names(p_.clone()), move |pattern_names_78024: Array<Text>| call_then(start_non_empty_rels(hide(&m, &pattern_names_78024), p_.clone(), e.clone(), refutable), move |non_empty_rels_78001: Map<Text, Rel>| {
                    let h = non_empty_rels_78001;
                    match &*p_.kind {
                        ast::PatternKind::PName(n) => match &base_opt {
                            Some(r) => prism_rtl::Turn::Finished(insert(&h, &check_env::sname_key(n), r)),
                            None => match &dec_opt {
                                Some(r) => if refutable {
                                    prism_rtl::Turn::Finished(insert(&h, &check_env::sname_key(n), r))
                                } else {
                                    prism_rtl::Turn::Finished(h.clone())
                                },
                                None => prism_rtl::Turn::Finished(h.clone()),
                            },
                        },
                        ast::PatternKind::PSigil(m78062_1_0, inner) if (m78062_1_0 == &Text::from("?")) => match &dec_opt {
                            Some(r) => {
                                let inner = (**inner).clone();
                                let r = r.clone();
                                call_then(check_env::start_pattern_names(inner.clone()), move |pattern_names_78332: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_78332, &h, &(|m2: &Map<Text, Rel>, n: &Text| insert(m2, n, &r)))))
                            },
                            None => match &base_opt {
                                Some(r) => {
                                    let inner = (**inner).clone();
                                    let r = r.clone();
                                    call_then(check_env::start_pattern_names(inner.clone()), move |pattern_names_78438: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_78438, &h, &(|m2: &Map<Text, Rel>, n: &Text| insert(m2, n, &Rel { param: r.param.clone(), strict: true })))))
                                },
                                None => prism_rtl::Turn::Finished(h.clone()),
                            },
                        },
                        _ => match &base_opt {
                            Some(r) => {
                                let r = r.clone();
                                call_then(check_env::start_pattern_names(p_.clone()), move |pattern_names_78595: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_78595, &h, &(|m2: &Map<Text, Rel>, n: &Text| insert(m2, n, &Rel { param: r.param.clone(), strict: true })))))
                            },
                            None => prism_rtl::Turn::Finished(h.clone()),
                        },
                        _ => unreachable!("no arm matched"),
                    }
                }))
            })
        })
    }
}

/// `Start BindRels, x`: what the function value is when passed to `@Run`.
pub fn start_bind_rels(p_: ast::Pattern_, e: ast::Expr, m: Map<Text, Rel>, refutable: bool) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>> {
    Rc::new(BindRels { p_, e, m, refutable })
}

/// ```prism
/// NonEmptyRels: unbounded fn (Text ==> Rel), Pattern, Expr, Bool -> (Text ==> Rel)
/// ```
pub fn non_empty_rels(m: &Map<Text, Rel>, p_: &ast::Pattern_, e: &ast::Expr, refutable: &bool) -> Map<Text, Rel> {
    if !*refutable {
        m.clone()
    } else {
        match non_empty_name(p_, e) {
            Some(n) => if check_types::has_text(&check_env::pattern_names(p_), &n) {
                m.clone()
            } else {
                insert(m, &Text::from(format!("ne:{}", &n)), &no_rel())
            },
            None => m.clone(),
        }
    }
}

/// The step machine of `NonEmptyRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NonEmptyRels: unbounded fn (Text ==> Rel), Pattern, Expr, Bool -> (Text ==> Rel)
/// ```
pub struct NonEmptyRels {
    pub m: Map<Text, Rel>,
    pub p_: ast::Pattern_,
    pub e: ast::Expr,
    pub refutable: bool,
}

impl prism_rtl::Job<Map<Text, Rel>> for NonEmptyRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Rel>> {
        let m = &self.m;
        let p_ = &self.p_;
        let e = &self.e;
        let refutable = &self.refutable;
        if !*refutable {
            prism_rtl::Turn::Finished(m.clone())
        } else {
            match non_empty_name(p_, e) {
                Some(n) => {
                    let m = m.clone();
                    let p_ = p_.clone();
                    call_then(check_env::start_pattern_names(p_.clone()), move |pattern_names_79131: Array<Text>| if check_types::has_text(&pattern_names_79131, &n) {
                        prism_rtl::Turn::Finished(m.clone())
                    } else {
                        prism_rtl::Turn::Finished(insert(&m, &Text::from(format!("ne:{}", &n)), &no_rel()))
                    })
                },
                None => prism_rtl::Turn::Finished(m.clone()),
            }
        }
    }
}

/// `Start NonEmptyRels, x`: what the function value is when passed to `@Run`.
pub fn start_non_empty_rels(m: Map<Text, Rel>, p_: ast::Pattern_, e: ast::Expr, refutable: bool) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>> {
    Rc::new(NonEmptyRels { m, p_, e, refutable })
}

/// ```prism
/// ?NonEmptyName: fn Pattern, Expr -> ?Text
/// ```
pub fn non_empty_name(p_: &ast::Pattern_, e: &ast::Expr) -> Option<Text> {
    match &*e.kind {
        ast::ExprKind::EGroup(x) => non_empty_name(p_, &**x),
        ast::ExprKind::EIndex(r, _) => match &*p_.kind {
            ast::PatternKind::PSigil(m79331_0_0, _) if (m79331_0_0 == &Text::from("?")) => name_of(&**r),
            ast::PatternKind::PGroup(q) => non_empty_name(&**q, e),
            _ => None,
            _ => unreachable!("no arm matched"),
        },
        ast::ExprKind::EName(n) => match &*p_.kind {
            ast::PatternKind::PArray(ps) => if &len(ps) > &Nat::from(0u32) { Some(check_env::sname_key(n)) } else { None },
            ast::PatternKind::PGroup(q) => non_empty_name(&**q, e),
            _ => None,
        },
        _ => None,
    }
}

/// ```prism
/// ?NameOf: fn Expr -> ?Text
/// ```
pub fn name_of(e: &ast::Expr) -> Option<Text> {
    match &*e.kind {
        ast::ExprKind::EName(n) => Some(check_env::sname_key(n)),
        ast::ExprKind::EGroup(x) => name_of(&**x),
        _ => None,
    }
}

/// ```prism
/// ArmPatRels: unbounded fn Expr, Arm, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn arm_pat_rels(s: &ast::Expr, a: &ast::Arm, m: &Map<Text, Rel>) -> Map<Text, Rel> {
    match &a.pattern {
        Some(p_) => bind_rels(p_, s, m, &true),
        None => m.clone(),
    }
}

/// The step machine of `ArmPatRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArmPatRels: unbounded fn Expr, Arm, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub struct ArmPatRels {
    pub s: ast::Expr,
    pub a: ast::Arm,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Map<Text, Rel>> for ArmPatRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Rel>> {
        let s = &self.s;
        let a = &self.a;
        let m = &self.m;
        match &a.pattern {
            Some(p_) => prism_rtl::Turn::More(Rc::new(BindRels { p_: p_.clone(), e: s.clone(), m: m.clone(), refutable: true })),
            None => prism_rtl::Turn::Finished(m.clone()),
        }
    }
}

/// `Start ArmPatRels, x`: what the function value is when passed to `@Run`.
pub fn start_arm_pat_rels(s: ast::Expr, a: ast::Arm, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>> {
    Rc::new(ArmPatRels { s, a, m })
}

/// ```prism
/// CondRels: unbounded fn Cond, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn cond_rels(c: &ast::Cond, m: &Map<Text, Rel>) -> Map<Text, Rel> {
    match c {
        ast::Cond::CondBind(p_, x, _) => bind_rels(p_, &**x, m, &true),
        ast::Cond::CondExpr(_) => m.clone(),
    }
}

/// The step machine of `CondRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondRels: unbounded fn Cond, (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub struct CondRels {
    pub c: ast::Cond,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Map<Text, Rel>> for CondRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Rel>> {
        let c = &self.c;
        let m = &self.m;
        match c {
            ast::Cond::CondBind(p_, x, _) => prism_rtl::Turn::More(Rc::new(BindRels { p_: p_.clone(), e: (**x).clone(), m: m.clone(), refutable: true })),
            ast::Cond::CondExpr(_) => prism_rtl::Turn::Finished(m.clone()),
        }
    }
}

/// `Start CondRels, x`: what the function value is when passed to `@Run`.
pub fn start_cond_rels(c: ast::Cond, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>> {
    Rc::new(CondRels { c, m })
}

/// ```prism
/// StepRels: unbounded fn (Text ==> Rel), Expr, [Pattern], Nat -> (Text ==> Rel)
/// ```
pub fn step_rels(m: &Map<Text, Rel>, coll: &ast::Expr, ps: &Array<ast::Pattern_>, at_: &Nat) -> Map<Text, Rel> {
    let h = hide(m, &run_to_end(fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, ast::Pattern_)| entered(once_job(move || {
        let a = p0;
        let p_ = p1;
        call_then(check_env::start_pattern_names(p_.clone()), move |pattern_names_80820: Array<Text>| prism_rtl::Turn::Finished(check_types::union_texts(&a, &pattern_names_80820)))
    }))) as Rc<dyn Fn((Array<Text>, ast::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)));
    match rel_of(m, coll) {
        Some(r) => run_to_end(fold_job(drop(ps, at_), h.clone(), {
            let r = r.clone();
            Rc::new(move |(p0, p1): (Map<Text, Rel>, ast::Pattern_)| {
                let r = r.clone();
                entered(once_job(move || {
                    let m2 = p0;
                    let p_ = p1;
                    call_then(check_env::start_pattern_names(p_.clone()), move |pattern_names_80914: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_80914, &m2, &(|m3: &Map<Text, Rel>, n: &Text| insert(m3, n, &Rel { param: r.param.clone(), strict: true })))))
                }))
            }) as Rc<dyn Fn((Map<Text, Rel>, ast::Pattern_)) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>>>
        })),
        None => h.clone(),
    }
}

/// The step machine of `StepRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StepRels: unbounded fn (Text ==> Rel), Expr, [Pattern], Nat -> (Text ==> Rel)
/// ```
pub struct StepRels {
    pub m: Map<Text, Rel>,
    pub coll: ast::Expr,
    pub ps: Array<ast::Pattern_>,
    pub at_: Nat,
}

impl prism_rtl::Job<Map<Text, Rel>> for StepRels {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Rel>> {
        let m = &self.m;
        let coll = &self.coll;
        let ps = &self.ps;
        let at_ = &self.at_;
        let at_ = at_.clone();
        let coll = coll.clone();
        let m = m.clone();
        let ps = ps.clone();
        call_value(fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, ast::Pattern_)| entered(once_job(move || {
            let a = p0;
            let p_ = p1;
            call_then(check_env::start_pattern_names(p_.clone()), move |pattern_names_80820: Array<Text>| prism_rtl::Turn::Finished(check_types::union_texts(&a, &pattern_names_80820)))
        }))) as Rc<dyn Fn((Array<Text>, ast::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |fold_80782: Array<Text>| {
            let h = hide(&m, &fold_80782);
            call_then(start_rel_of(m.clone(), coll.clone()), move |rel_of_80847: Option<Rel>| match rel_of_80847 {
                Some(r) => fold_job(drop(&ps, &at_), h.clone(), {
                    let r = r.clone();
                    Rc::new(move |(p0, p1): (Map<Text, Rel>, ast::Pattern_)| {
                        let r = r.clone();
                        entered(once_job(move || {
                            let m2 = p0;
                            let p_ = p1;
                            call_then(check_env::start_pattern_names(p_.clone()), move |pattern_names_80914: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_80914, &m2, &(|m3: &Map<Text, Rel>, n: &Text| insert(m3, n, &Rel { param: r.param.clone(), strict: true })))))
                        }))
                    }) as Rc<dyn Fn((Map<Text, Rel>, ast::Pattern_)) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>>>
                }).cycle(),
                None => prism_rtl::Turn::Finished(h.clone()),
            })
        })
    }
}

/// `Start StepRels, x`: what the function value is when passed to `@Run`.
pub fn start_step_rels(m: Map<Text, Rel>, coll: ast::Expr, ps: Array<ast::Pattern_>, at_: Nat) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>> {
    Rc::new(StepRels { m, coll, ps, at_ })
}

/// ```prism
/// ExprSpots: unbounded fn Expr, (Text ==> Rel) -> [Spot]
/// ```
pub fn expr_spots(e: &ast::Expr, m: &Map<Text, Rel>) -> Array<Spot> {
    run_to_end(fold_job(expr_kids(e, m), Array::from(vec![Spot::SpotExpr(e.clone(), m.clone())]), Rc::new(move |(p0, p1): (Array<Spot>, Kid)| entered(once_job(move || {
        let acc = p0;
        let k = p1;
        call_then(start_kid_spots(k.clone()), move |kid_spots_82091: Array<Spot>| prism_rtl::Turn::Finished(append(&acc, &kid_spots_82091)))
    }))) as Rc<dyn Fn((Array<Spot>, Kid)) -> Rc<dyn prism_rtl::Job<Array<Spot>>>>))
}

/// The step machine of `ExprSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExprSpots: unbounded fn Expr, (Text ==> Rel) -> [Spot]
/// ```
pub struct ExprSpots {
    pub e: ast::Expr,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Array<Spot>> for ExprSpots {
    fn cycle(&self) -> prism_rtl::Turn<Array<Spot>> {
        let e = &self.e;
        let m = &self.m;
        let e = e.clone();
        let m = m.clone();
        call_then(start_expr_kids(e.clone(), m.clone()), move |expr_kids_82031: Array<Kid>| fold_job(expr_kids_82031, Array::from(vec![Spot::SpotExpr(e.clone(), m.clone())]), Rc::new(move |(p0, p1): (Array<Spot>, Kid)| entered(once_job(move || {
            let acc = p0;
            let k = p1;
            call_then(start_kid_spots(k.clone()), move |kid_spots_82091: Array<Spot>| prism_rtl::Turn::Finished(append(&acc, &kid_spots_82091)))
        }))) as Rc<dyn Fn((Array<Spot>, Kid)) -> Rc<dyn prism_rtl::Job<Array<Spot>>>>).cycle())
    }
}

/// `Start ExprSpots, x`: what the function value is when passed to `@Run`.
pub fn start_expr_spots(e: ast::Expr, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Array<Spot>>> {
    Rc::new(ExprSpots { e, m })
}

/// ```prism
/// KidSpots: unbounded fn Kid -> [Spot]
/// ```
pub fn kid_spots(kid0: &Kid) -> Array<Spot> {
    match kid0 {
        Kid::KidExpr(x, m) => expr_spots(x, m),
        Kid::KidStmts(ss, m) => stmts_spots(ss, m),
    }
}

/// The step machine of `KidSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// KidSpots: unbounded fn Kid -> [Spot]
/// ```
pub struct KidSpots {
    pub kid0: Kid,
}

impl prism_rtl::Job<Array<Spot>> for KidSpots {
    fn cycle(&self) -> prism_rtl::Turn<Array<Spot>> {
        let kid0 = &self.kid0;
        match kid0 {
            Kid::KidExpr(x, m) => prism_rtl::Turn::More(Rc::new(ExprSpots { e: x.clone(), m: m.clone() })),
            Kid::KidStmts(ss, m) => prism_rtl::Turn::More(Rc::new(StmtsSpots { stmts: ss.clone(), m: m.clone() })),
        }
    }
}

/// `Start KidSpots, x`: what the function value is when passed to `@Run`.
pub fn start_kid_spots(kid0: Kid) -> Rc<dyn prism_rtl::Job<Array<Spot>>> {
    Rc::new(KidSpots { kid0 })
}

/// ```prism
/// StmtsSpots: unbounded fn [Stmt], (Text ==> Rel) -> [Spot]
/// ```
pub fn stmts_spots(stmts: &Array<ast::Stmt>, m: &Map<Text, Rel>) -> Array<Spot> {
    let bm = block_rels(stmts, m);
    run_to_end(fold_job(stmts.clone(), Array::new(), {
        let bm = bm.clone();
        Rc::new(move |(p0, p1): (Array<Spot>, ast::Stmt)| {
            let bm = bm.clone();
            entered(once_job(move || {
                let acc = p0;
                let s = p1;
                call_then(start_stmt_spots(s.clone(), bm.clone()), move |stmt_spots_82478: Array<Spot>| prism_rtl::Turn::Finished(append(&acc, &stmt_spots_82478)))
            }))
        }) as Rc<dyn Fn((Array<Spot>, ast::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Spot>>>>
    }))
}

/// The step machine of `StmtsSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtsSpots: unbounded fn [Stmt], (Text ==> Rel) -> [Spot]
/// ```
pub struct StmtsSpots {
    pub stmts: Array<ast::Stmt>,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Array<Spot>> for StmtsSpots {
    fn cycle(&self) -> prism_rtl::Turn<Array<Spot>> {
        let stmts = &self.stmts;
        let m = &self.m;
        let m = m.clone();
        let stmts = stmts.clone();
        call_then(start_block_rels(stmts.clone(), m.clone()), move |block_rels_82414: Map<Text, Rel>| {
            let bm = block_rels_82414;
            fold_job(stmts.clone(), Array::new(), {
                let bm = bm.clone();
                Rc::new(move |(p0, p1): (Array<Spot>, ast::Stmt)| {
                    let bm = bm.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let s = p1;
                        call_then(start_stmt_spots(s.clone(), bm.clone()), move |stmt_spots_82478: Array<Spot>| prism_rtl::Turn::Finished(append(&acc, &stmt_spots_82478)))
                    }))
                }) as Rc<dyn Fn((Array<Spot>, ast::Stmt)) -> Rc<dyn prism_rtl::Job<Array<Spot>>>>
            }).cycle()
        })
    }
}

/// `Start StmtsSpots, x`: what the function value is when passed to `@Run`.
pub fn start_stmts_spots(stmts: Array<ast::Stmt>, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Array<Spot>>> {
    Rc::new(StmtsSpots { stmts, m })
}

/// ```prism
/// StmtSpots: unbounded fn Stmt, (Text ==> Rel) -> [Spot]
/// ```
pub fn stmt_spots(s: &ast::Stmt, m: &Map<Text, Rel>) -> Array<Spot> {
    run_to_end(fold_job(stmt_kids(s, m), Array::from(vec![Spot::SpotStmt(s.clone(), m.clone())]), Rc::new(move |(p0, p1): (Array<Spot>, Kid)| entered(once_job(move || {
        let acc = p0;
        let k = p1;
        call_then(start_kid_spots(k.clone()), move |kid_spots_82637: Array<Spot>| prism_rtl::Turn::Finished(append(&acc, &kid_spots_82637)))
    }))) as Rc<dyn Fn((Array<Spot>, Kid)) -> Rc<dyn prism_rtl::Job<Array<Spot>>>>))
}

/// The step machine of `StmtSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtSpots: unbounded fn Stmt, (Text ==> Rel) -> [Spot]
/// ```
pub struct StmtSpots {
    pub s: ast::Stmt,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Array<Spot>> for StmtSpots {
    fn cycle(&self) -> prism_rtl::Turn<Array<Spot>> {
        let s = &self.s;
        let m = &self.m;
        let m = m.clone();
        let s = s.clone();
        call_then(start_stmt_kids(s.clone(), m.clone()), move |stmt_kids_82577: Array<Kid>| fold_job(stmt_kids_82577, Array::from(vec![Spot::SpotStmt(s.clone(), m.clone())]), Rc::new(move |(p0, p1): (Array<Spot>, Kid)| entered(once_job(move || {
            let acc = p0;
            let k = p1;
            call_then(start_kid_spots(k.clone()), move |kid_spots_82637: Array<Spot>| prism_rtl::Turn::Finished(append(&acc, &kid_spots_82637)))
        }))) as Rc<dyn Fn((Array<Spot>, Kid)) -> Rc<dyn prism_rtl::Job<Array<Spot>>>>).cycle())
    }
}

/// `Start StmtSpots, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_spots(s: ast::Stmt, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Array<Spot>>> {
    Rc::new(StmtSpots { s, m })
}

/// ```prism
/// BodySpots: unbounded fn FnBody, (Text ==> Rel) -> [Spot]
/// ```
pub fn body_spots(fn_body0: &ast::FnBody, m: &Map<Text, Rel>) -> Array<Spot> {
    match fn_body0 {
        ast::FnBody::BodyExpr(e) => expr_spots(e, m),
        ast::FnBody::BodyBlock(b) => stmts_spots(&b.stmts, m),
    }
}

/// The step machine of `BodySpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BodySpots: unbounded fn FnBody, (Text ==> Rel) -> [Spot]
/// ```
pub struct BodySpots {
    pub fn_body0: ast::FnBody,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Array<Spot>> for BodySpots {
    fn cycle(&self) -> prism_rtl::Turn<Array<Spot>> {
        let fn_body0 = &self.fn_body0;
        let m = &self.m;
        match fn_body0 {
            ast::FnBody::BodyExpr(e) => prism_rtl::Turn::More(Rc::new(ExprSpots { e: e.clone(), m: m.clone() })),
            ast::FnBody::BodyBlock(b) => prism_rtl::Turn::More(Rc::new(StmtsSpots { stmts: b.stmts.clone(), m: m.clone() })),
        }
    }
}

/// `Start BodySpots, x`: what the function value is when passed to `@Run`.
pub fn start_body_spots(fn_body0: ast::FnBody, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Array<Spot>>> {
    Rc::new(BodySpots { fn_body0, m })
}

/// ```prism
/// ExprKids: unbounded fn Expr, (Text ==> Rel) -> [Kid]
/// ```
pub fn expr_kids(e: &ast::Expr, m: &Map<Text, Rel>) -> Array<Kid> {
    match &*e.kind {
        ast::ExprKind::ECall(c, args, _, _) => call_kids(&**c, args, m),
        ast::ExprKind::EMethod(r, n, args) => call_kids(&method_callee(n), &method_args(&**r, args), m),
        ast::ExprKind::EBinary(_, l, r) => exprs_kids(&Array::from(vec![(**l).clone(), (**r).clone()]), m),
        ast::ExprKind::ESuffixed(_, _, l, r) => exprs_kids(&Array::from(vec![(**l).clone(), (**r).clone()]), m),
        ast::ExprKind::EIndex(r, i) => exprs_kids(&Array::from(vec![(**r).clone(), (**i).clone()]), m),
        ast::ExprKind::EUnary(_, x) => Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]),
        ast::ExprKind::EFreeSigil(_, x) => Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]),
        ast::ExprKind::EField(r, _, _) => Array::from(vec![Kid::KidExpr((**r).clone(), m.clone())]),
        ast::ExprKind::ETopicIndex(x) => Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]),
        ast::ExprKind::EGroup(x) => Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]),
        ast::ExprKind::ETypeArgs(x, _) => Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]),
        ast::ExprKind::ECast(x, _, _) => Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]),
        ast::ExprKind::ENonEmpty(x) => Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]),
        ast::ExprKind::EAny(x) => Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]),
        ast::ExprKind::ETuple(es) => exprs_kids(es, m),
        ast::ExprKind::EArray(es) => exprs_kids(es, m),
        ast::ExprKind::EMap(kvs) => fold(kvs, &Array::new(), &(|acc: &Array<Kid>, (k, v_): &(ast::Expr, ast::Expr)| append(acc, &exprs_kids(&Array::from(vec![k.clone(), v_.clone()]), m)))),
        ast::ExprKind::ELit(l) => match &l.kind {
            ast::LitKind::LText(segs) => fold(segs, &Array::new(), &(|acc: &Array<Kid>, sg: &ast::TextSeg| match sg {
                ast::TextSeg::SegPlaceholder(x) => push(acc, &Kid::KidExpr(x.clone(), m.clone())),
                _ => acc.clone(),
            })),
            _ => Array::new(),
        },
        ast::ExprKind::ELambda(ps_opt, body) => Array::from(vec![lambda_kid(&**body, &later(&hide(m, &patterns_names(&or(ps_opt, &Array::new())))))]),
        ast::ExprKind::EIf(c, t, el_opt) => {
            let with_then = push(&cond_kids(&**c, m), &Kid::KidStmts(t.stmts.clone(), cond_rels(&**c, m)));
            match el_opt {
                Some(b) => push(&with_then, &Kid::KidStmts(b.stmts.clone(), m.clone())),
                None => with_then.clone(),
            }
        },
        ast::ExprKind::EMatch(s, arms) => run_to_end(fold_job(arms.clone(), Array::from(vec![Kid::KidExpr((**s).clone(), m.clone())]), {
            let s = (**s).clone();
            let m = m.clone();
            Rc::new(move |(p0, p1): (Array<Kid>, ast::Arm)| {
                let s = s.clone();
                let m = m.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let a = p1;
                    call_then(start_arm_pat_rels(s.clone(), a.clone(), m.clone()), move |arm_pat_rels_84240: Map<Text, Rel>| {
                        let am = arm_pat_rels_84240;
                        prism_rtl::Turn::Finished(push(&append(&acc, &opt_kids(&a.guard, &am)), &Kid::KidStmts(a.body.stmts.clone(), am.clone())))
                    })
                }))
            }) as Rc<dyn Fn((Array<Kid>, ast::Arm)) -> Rc<dyn prism_rtl::Job<Array<Kid>>>>
        })),
        ast::ExprKind::ERebuild(s, b) => Array::from(vec![Kid::KidExpr((**s).clone(), m.clone()), Kid::KidStmts(b.stmts.clone(), later(m))]),
        ast::ExprKind::EUpdate(s, b) => Array::from(vec![Kid::KidExpr((**s).clone(), m.clone()), Kid::KidStmts(b.stmts.clone(), m.clone())]),
        ast::ExprKind::EMonad(s, b) => Array::from(vec![Kid::KidExpr((**s).clone(), m.clone()), Kid::KidStmts(b.stmts.clone(), m.clone())]),
        ast::ExprKind::EFor(fb_opt, s, b) => {
            let names = match fb_opt {
                Some(fb) => check_types::union_texts(&check_env::pattern_names(&fb.first), &opt_names(&fb.second)),
                None => Array::new(),
            };
            Array::from(vec![Kid::KidExpr((**s).clone(), m.clone()), Kid::KidStmts(b.stmts.clone(), hide(m, &names))])
        },
        ast::ExprKind::EGiven(b) => Array::from(vec![Kid::KidStmts(b.stmts.clone(), m.clone())]),
        ast::ExprKind::EWidgetBlock(b) => Array::from(vec![Kid::KidStmts(b.stmts.clone(), later(m))]),
        ast::ExprKind::ETemplate(t) => template_kids(&t.parts, m),
        _ => Array::new(),
    }
}

/// The step machine of `ExprKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExprKids: unbounded fn Expr, (Text ==> Rel) -> [Kid]
/// ```
pub struct ExprKids {
    pub e: ast::Expr,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Array<Kid>> for ExprKids {
    fn cycle(&self) -> prism_rtl::Turn<Array<Kid>> {
        let e = &self.e;
        let m = &self.m;
        match &*e.kind {
            ast::ExprKind::ECall(c, args, _, _) => prism_rtl::Turn::More(Rc::new(CallKids { c: (**c).clone(), args: args.clone(), m: m.clone() })),
            ast::ExprKind::EMethod(r, n, args) => prism_rtl::Turn::More(Rc::new(CallKids { c: method_callee(n), args: method_args(&**r, args), m: m.clone() })),
            ast::ExprKind::EBinary(_, l, r) => prism_rtl::Turn::Finished(exprs_kids(&Array::from(vec![(**l).clone(), (**r).clone()]), m)),
            ast::ExprKind::ESuffixed(_, _, l, r) => prism_rtl::Turn::Finished(exprs_kids(&Array::from(vec![(**l).clone(), (**r).clone()]), m)),
            ast::ExprKind::EIndex(r, i) => prism_rtl::Turn::Finished(exprs_kids(&Array::from(vec![(**r).clone(), (**i).clone()]), m)),
            ast::ExprKind::EUnary(_, x) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())])),
            ast::ExprKind::EFreeSigil(_, x) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())])),
            ast::ExprKind::EField(r, _, _) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**r).clone(), m.clone())])),
            ast::ExprKind::ETopicIndex(x) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())])),
            ast::ExprKind::EGroup(x) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())])),
            ast::ExprKind::ETypeArgs(x, _) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())])),
            ast::ExprKind::ECast(x, _, _) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())])),
            ast::ExprKind::ENonEmpty(x) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())])),
            ast::ExprKind::EAny(x) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())])),
            ast::ExprKind::ETuple(es) => prism_rtl::Turn::Finished(exprs_kids(es, m)),
            ast::ExprKind::EArray(es) => prism_rtl::Turn::Finished(exprs_kids(es, m)),
            ast::ExprKind::EMap(kvs) => prism_rtl::Turn::Finished(fold(kvs, &Array::new(), &(|acc: &Array<Kid>, (k, v_): &(ast::Expr, ast::Expr)| append(acc, &exprs_kids(&Array::from(vec![k.clone(), v_.clone()]), m))))),
            ast::ExprKind::ELit(l) => match &l.kind {
                ast::LitKind::LText(segs) => prism_rtl::Turn::Finished(fold(segs, &Array::new(), &(|acc: &Array<Kid>, sg: &ast::TextSeg| match sg {
                    ast::TextSeg::SegPlaceholder(x) => push(acc, &Kid::KidExpr(x.clone(), m.clone())),
                    _ => acc.clone(),
                }))),
                _ => prism_rtl::Turn::Finished(Array::new()),
            },
            ast::ExprKind::ELambda(ps_opt, body) => {
                let ps_opt = ps_opt.clone();
                let body = (**body).clone();
                let m = m.clone();
                call_then(start_patterns_names(or(&ps_opt, &Array::new())), move |patterns_names_83928: Array<Text>| prism_rtl::Turn::Finished(Array::from(vec![lambda_kid(&body, &later(&hide(&m, &patterns_names_83928)))])))
            },
            ast::ExprKind::EIf(c, t, el_opt) => {
                let el_opt = el_opt.clone();
                let c = (**c).clone();
                let m = m.clone();
                let t = t.clone();
                call_then(start_cond_kids(c.clone(), m.clone()), move |cond_kids_84011: Array<Kid>| call_then(start_cond_rels(c.clone(), m.clone()), move |cond_rels_84047: Map<Text, Rel>| {
                    let with_then = push(&cond_kids_84011, &Kid::KidStmts(t.stmts.clone(), cond_rels_84047));
                    match &el_opt {
                        Some(b) => prism_rtl::Turn::Finished(push(&with_then, &Kid::KidStmts(b.stmts.clone(), m.clone()))),
                        None => prism_rtl::Turn::Finished(with_then.clone()),
                    }
                }))
            },
            ast::ExprKind::EMatch(s, arms) => fold_job(arms.clone(), Array::from(vec![Kid::KidExpr((**s).clone(), m.clone())]), {
                let s = (**s).clone();
                let m = m.clone();
                Rc::new(move |(p0, p1): (Array<Kid>, ast::Arm)| {
                    let s = s.clone();
                    let m = m.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let a = p1;
                        call_then(start_arm_pat_rels(s.clone(), a.clone(), m.clone()), move |arm_pat_rels_84240: Map<Text, Rel>| {
                            let am = arm_pat_rels_84240;
                            prism_rtl::Turn::Finished(push(&append(&acc, &opt_kids(&a.guard, &am)), &Kid::KidStmts(a.body.stmts.clone(), am.clone())))
                        })
                    }))
                }) as Rc<dyn Fn((Array<Kid>, ast::Arm)) -> Rc<dyn prism_rtl::Job<Array<Kid>>>>
            }).cycle(),
            ast::ExprKind::ERebuild(s, b) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**s).clone(), m.clone()), Kid::KidStmts(b.stmts.clone(), later(m))])),
            ast::ExprKind::EUpdate(s, b) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**s).clone(), m.clone()), Kid::KidStmts(b.stmts.clone(), m.clone())])),
            ast::ExprKind::EMonad(s, b) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**s).clone(), m.clone()), Kid::KidStmts(b.stmts.clone(), m.clone())])),
            ast::ExprKind::EFor(fb_opt, s, b) => {
                let names = match fb_opt {
                    Some(fb) => check_types::union_texts(&check_env::pattern_names(&fb.first), &opt_names(&fb.second)),
                    None => Array::new(),
                };
                prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**s).clone(), m.clone()), Kid::KidStmts(b.stmts.clone(), hide(m, &names))]))
            },
            ast::ExprKind::EGiven(b) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidStmts(b.stmts.clone(), m.clone())])),
            ast::ExprKind::EWidgetBlock(b) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidStmts(b.stmts.clone(), later(m))])),
            ast::ExprKind::ETemplate(t) => prism_rtl::Turn::More(Rc::new(TemplateKids { parts: t.parts.clone(), m: m.clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start ExprKids, x`: what the function value is when passed to `@Run`.
pub fn start_expr_kids(e: ast::Expr, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Array<Kid>>> {
    Rc::new(ExprKids { e, m })
}

/// ```prism
/// StmtKids: unbounded fn Stmt, (Text ==> Rel) -> [Kid]
/// ```
pub fn stmt_kids(s: &ast::Stmt, m: &Map<Text, Rel>) -> Array<Kid> {
    match &s.kind {
        ast::StmtKind::SBind(_, e, t_opt) => append(&Array::from(vec![Kid::KidExpr(e.clone(), m.clone())]), &opt_kids(t_opt, m)),
        ast::StmtKind::SIgnore(e) => Array::from(vec![Kid::KidExpr(e.clone(), m.clone())]),
        ast::StmtKind::SLet(_, _, e) => Array::from(vec![Kid::KidExpr(e.clone(), m.clone())]),
        ast::StmtKind::SFn(f) => Array::from(vec![body_kid(&f.body, &later(&hide(m, &patterns_names(&f.params))))]),
        ast::StmtKind::SWidget(w) => Array::from(vec![Kid::KidStmts(w.body.stmts.clone(), later(m))]),
        ast::StmtKind::SSet(t, v_) => exprs_kids(&Array::from(vec![t.clone(), v_.clone()]), m),
        ast::StmtKind::SAccum(t, _, v_) => exprs_kids(&Array::from(vec![t.clone(), v_.clone()]), m),
        ast::StmtKind::SRequire(c) => Array::from(vec![Kid::KidExpr(c.clone(), m.clone())]),
        ast::StmtKind::SForbid(c) => Array::from(vec![Kid::KidExpr(c.clone(), m.clone())]),
        ast::StmtKind::SReturn(e) => Array::from(vec![Kid::KidExpr(e.clone(), m.clone())]),
        ast::StmtKind::SWhile(c, b) => push(&cond_kids(c, m), &Kid::KidStmts(b.stmts.clone(), cond_rels(c, m))),
        ast::StmtKind::SExpr(e) => Array::from(vec![Kid::KidExpr(e.clone(), m.clone())]),
        _ => Array::new(),
    }
}

/// The step machine of `StmtKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtKids: unbounded fn Stmt, (Text ==> Rel) -> [Kid]
/// ```
pub struct StmtKids {
    pub s: ast::Stmt,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Array<Kid>> for StmtKids {
    fn cycle(&self) -> prism_rtl::Turn<Array<Kid>> {
        let s = &self.s;
        let m = &self.m;
        match &s.kind {
            ast::StmtKind::SBind(_, e, t_opt) => prism_rtl::Turn::Finished(append(&Array::from(vec![Kid::KidExpr(e.clone(), m.clone())]), &opt_kids(t_opt, m))),
            ast::StmtKind::SIgnore(e) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr(e.clone(), m.clone())])),
            ast::StmtKind::SLet(_, _, e) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr(e.clone(), m.clone())])),
            ast::StmtKind::SFn(f) => {
                let f = f.clone();
                let m = m.clone();
                call_then(start_patterns_names(f.params.clone()), move |patterns_names_85177: Array<Text>| prism_rtl::Turn::Finished(Array::from(vec![body_kid(&f.body, &later(&hide(&m, &patterns_names_85177)))])))
            },
            ast::StmtKind::SWidget(w) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidStmts(w.body.stmts.clone(), later(m))])),
            ast::StmtKind::SSet(t, v_) => prism_rtl::Turn::Finished(exprs_kids(&Array::from(vec![t.clone(), v_.clone()]), m)),
            ast::StmtKind::SAccum(t, _, v_) => prism_rtl::Turn::Finished(exprs_kids(&Array::from(vec![t.clone(), v_.clone()]), m)),
            ast::StmtKind::SRequire(c) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr(c.clone(), m.clone())])),
            ast::StmtKind::SForbid(c) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr(c.clone(), m.clone())])),
            ast::StmtKind::SReturn(e) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr(e.clone(), m.clone())])),
            ast::StmtKind::SWhile(c, b) => {
                let b = b.clone();
                let c = c.clone();
                let m = m.clone();
                call_then(start_cond_kids(c.clone(), m.clone()), move |cond_kids_85470: Array<Kid>| call_then(start_cond_rels(c.clone(), m.clone()), move |cond_rels_85506: Map<Text, Rel>| prism_rtl::Turn::Finished(push(&cond_kids_85470, &Kid::KidStmts(b.stmts.clone(), cond_rels_85506)))))
            },
            ast::StmtKind::SExpr(e) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr(e.clone(), m.clone())])),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start StmtKids, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_kids(s: ast::Stmt, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Array<Kid>>> {
    Rc::new(StmtKids { s, m })
}

/// ```prism
/// CondKids: unbounded fn Cond, (Text ==> Rel) -> [Kid]
/// ```
pub fn cond_kids(c: &ast::Cond, m: &Map<Text, Rel>) -> Array<Kid> {
    match c {
        ast::Cond::CondExpr(x) => Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]),
        ast::Cond::CondBind(_, x, g_opt) => append(&Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())]), &opt_kids(&**g_opt, &cond_rels(c, m))),
    }
}

/// The step machine of `CondKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondKids: unbounded fn Cond, (Text ==> Rel) -> [Kid]
/// ```
pub struct CondKids {
    pub c: ast::Cond,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Array<Kid>> for CondKids {
    fn cycle(&self) -> prism_rtl::Turn<Array<Kid>> {
        let c = &self.c;
        let m = &self.m;
        match c {
            ast::Cond::CondExpr(x) => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr((**x).clone(), m.clone())])),
            ast::Cond::CondBind(_, x, g_opt) => {
                let g_opt = (**g_opt).clone();
                let c = c.clone();
                let m = m.clone();
                let x = (**x).clone();
                call_then(start_cond_rels(c.clone(), m.clone()), move |cond_rels_85846: Map<Text, Rel>| prism_rtl::Turn::Finished(append(&Array::from(vec![Kid::KidExpr(x.clone(), m.clone())]), &opt_kids(&g_opt, &cond_rels_85846))))
            },
        }
    }
}

/// `Start CondKids, x`: what the function value is when passed to `@Run`.
pub fn start_cond_kids(c: ast::Cond, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Array<Kid>>> {
    Rc::new(CondKids { c, m })
}

/// ```prism
/// CallKids: unbounded fn Expr, [Arg], (Text ==> Rel) -> [Kid]
/// ```
pub fn call_kids(c: &ast::Expr, args: &Array<ast::Arg>, m: &Map<Text, Rel>) -> Array<Kid> {
    let callee = match callee_name(c) {
        Some(_) => Array::new(),
        None => Array::from(vec![Kid::KidExpr(c.clone(), m.clone())]),
    };
    match traversal_of(m, c, args) {
        None => match acc_callee(m, c, args) {
            Some(cn) => append(&callee, &run_to_end(fold_job(check_errors::range0(&len(args)), Array::new(), {
                let m = m.clone();
                let cn = cn.clone();
                let args = args.clone();
                Rc::new(move |(p0, p1): (Array<Kid>, Nat)| {
                    let m = m.clone();
                    let cn = cn.clone();
                    let args = args.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let i = p1;
                        call_then(start_acc_kids(m.clone(), cn.clone(), args.clone(), i.clone()), move |acc_kids_86706: Array<Kid>| prism_rtl::Turn::Finished(append(&acc, &acc_kids_86706)))
                    }))
                }) as Rc<dyn Fn((Array<Kid>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Kid>>>>
            }))),
            None => append(&callee, &exprs_kids(&each(args, &(|a: &ast::Arg| a.value.clone())), m)),
        },
        Some((coll, step_, at_)) => {
            let others = fold(&check_errors::range0(&len(args)), &callee, &(|acc: &Array<Kid>, i: &Nat| if i == &(&at_ + &Nat::from(1u32)) {
                acc.clone()
            } else {
                match index(args, i) {
                    Some(a) => push(acc, &Kid::KidExpr(a.value.clone(), m.clone())),
                    None => acc.clone(),
                }
            }));
            match &*step_.kind {
                ast::ExprKind::ELambda(Some(ps), body) => push(&others, &lambda_kid(&**body, &step_rels(m, &coll, ps, &at_))),
                ast::ExprKind::EName(_) => others.clone(),
                _ => push(&others, &Kid::KidExpr(step_.clone(), m.clone())),
            }
        },
    }
}

/// The step machine of `CallKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallKids: unbounded fn Expr, [Arg], (Text ==> Rel) -> [Kid]
/// ```
pub struct CallKids {
    pub c: ast::Expr,
    pub args: Array<ast::Arg>,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Array<Kid>> for CallKids {
    fn cycle(&self) -> prism_rtl::Turn<Array<Kid>> {
        let c = &self.c;
        let args = &self.args;
        let m = &self.m;
        let callee = match callee_name(c) {
            Some(_) => Array::new(),
            None => Array::from(vec![Kid::KidExpr(c.clone(), m.clone())]),
        };
        match traversal_of(m, c, args) {
            None => match acc_callee(m, c, args) {
                Some(cn) => {
                    let args = args.clone();
                    let m = m.clone();
                    call_value(fold_job(check_errors::range0(&len(&args)), Array::new(), {
                        let m = m.clone();
                        let cn = cn.clone();
                        let args = args.clone();
                        Rc::new(move |(p0, p1): (Array<Kid>, Nat)| {
                            let m = m.clone();
                            let cn = cn.clone();
                            let args = args.clone();
                            entered(once_job(move || {
                                let acc = p0;
                                let i = p1;
                                call_then(start_acc_kids(m.clone(), cn.clone(), args.clone(), i.clone()), move |acc_kids_86706: Array<Kid>| prism_rtl::Turn::Finished(append(&acc, &acc_kids_86706)))
                            }))
                        }) as Rc<dyn Fn((Array<Kid>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Kid>>>>
                    }), move |fold_86651: Array<Kid>| prism_rtl::Turn::Finished(append(&callee, &fold_86651)))
                },
                None => prism_rtl::Turn::Finished(append(&callee, &exprs_kids(&each(args, &(|a: &ast::Arg| a.value.clone())), m))),
            },
            Some((coll, step_, at_)) => {
                let others = fold(&check_errors::range0(&len(args)), &callee, &(|acc: &Array<Kid>, i: &Nat| if i == &(&at_ + &Nat::from(1u32)) {
                    acc.clone()
                } else {
                    match index(args, i) {
                        Some(a) => push(acc, &Kid::KidExpr(a.value.clone(), m.clone())),
                        None => acc.clone(),
                    }
                }));
                match &*step_.kind {
                    ast::ExprKind::ELambda(Some(ps), body) => {
                        let body = (**body).clone();
                        let m = m.clone();
                        let ps = ps.clone();
                        call_then(start_step_rels(m.clone(), coll.clone(), ps.clone(), at_.clone()), move |step_rels_87119: Map<Text, Rel>| prism_rtl::Turn::Finished(push(&others, &lambda_kid(&body, &step_rels_87119))))
                    },
                    ast::ExprKind::EName(_) => prism_rtl::Turn::Finished(others.clone()),
                    _ => prism_rtl::Turn::Finished(push(&others, &Kid::KidExpr(step_.clone(), m.clone()))),
                }
            },
        }
    }
}

/// `Start CallKids, x`: what the function value is when passed to `@Run`.
pub fn start_call_kids(c: ast::Expr, args: Array<ast::Arg>, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Array<Kid>>> {
    Rc::new(CallKids { c, args, m })
}

/// ```prism
/// Later: fn (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn later(m: &Map<Text, Rel>) -> Map<Text, Rel> {
    insert(m, &Text::from("lam:"), &no_rel())
}

/// ```prism
/// ?AccCallee: fn (Text ==> Rel), Expr, [Arg] -> ?Text
/// ```
pub fn acc_callee(m: &Map<Text, Rel>, c: &ast::Expr, args: &Array<ast::Arg>) -> Option<Text> {
    match callee_name(c) {
        Some(cn) => if is_local(m, &cn) {
            None
        } else {
            if !fold(args, &true, &(|ok: &bool, a: &ast::Arg| *ok && (&a.name == &None))) {
                None
            } else {
                if fold(&check_errors::range0(&len(args)), &false, &(|seen: &bool, i: &Nat| *seen || check_env::has_key(m, &Text::from(format!("acc:{}:{}", &cn, i))))) {
                    Some(cn.clone())
                } else {
                    None
                }
            }
        },
        None => None,
    }
}

/// ```prism
/// AccKids: unbounded fn (Text ==> Rel), Text, [Arg], Nat -> [Kid]
/// ```
pub fn acc_kids(m: &Map<Text, Rel>, cn: &Text, args: &Array<ast::Arg>, i: &Nat) -> Array<Kid> {
    let a = or(&index(args, i), &dummy_arg());
    if !check_env::has_key(m, &Text::from(format!("acc:{}:{}", cn, i))) {
        Array::from(vec![Kid::KidExpr(a.value.clone(), m.clone())])
    } else {
        match &*a.value.kind {
            ast::ExprKind::ELambda(ps_opt, body) => Array::from(vec![lambda_kid(&**body, &acc_lambda_rels(m, cn, i, &or(ps_opt, &Array::new()), args))]),
            ast::ExprKind::EName(_) => Array::new(),
            _ => Array::from(vec![Kid::KidExpr(a.value.clone(), m.clone())]),
        }
    }
}

/// The step machine of `AccKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AccKids: unbounded fn (Text ==> Rel), Text, [Arg], Nat -> [Kid]
/// ```
pub struct AccKids {
    pub m: Map<Text, Rel>,
    pub cn: Text,
    pub args: Array<ast::Arg>,
    pub i: Nat,
}

impl prism_rtl::Job<Array<Kid>> for AccKids {
    fn cycle(&self) -> prism_rtl::Turn<Array<Kid>> {
        let m = &self.m;
        let cn = &self.cn;
        let args = &self.args;
        let i = &self.i;
        let a = or(&index(args, i), &dummy_arg());
        if !check_env::has_key(m, &Text::from(format!("acc:{}:{}", cn, i))) {
            prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr(a.value.clone(), m.clone())]))
        } else {
            match &*a.value.kind {
                ast::ExprKind::ELambda(ps_opt, body) => prism_rtl::Turn::Finished(Array::from(vec![lambda_kid(&**body, &acc_lambda_rels(m, cn, i, &or(ps_opt, &Array::new()), args))])),
                ast::ExprKind::EName(_) => prism_rtl::Turn::Finished(Array::new()),
                _ => prism_rtl::Turn::Finished(Array::from(vec![Kid::KidExpr(a.value.clone(), m.clone())])),
            }
        }
    }
}

/// `Start AccKids, x`: what the function value is when passed to `@Run`.
pub fn start_acc_kids(m: Map<Text, Rel>, cn: Text, args: Array<ast::Arg>, i: Nat) -> Rc<dyn prism_rtl::Job<Array<Kid>>> {
    Rc::new(AccKids { m, cn, args, i })
}

/// ```prism
/// AccLambdaRels: unbounded fn (Text ==> Rel), Text, Nat, [Pattern], [Arg] -> (Text ==> Rel)
/// ```
pub fn acc_lambda_rels(m: &Map<Text, Rel>, cn: &Text, j: &Nat, ps: &Array<ast::Pattern_>, args: &Array<ast::Arg>) -> Map<Text, Rel> {
    let h = hide(m, &patterns_names(ps));
    run_to_end(fold_job(check_errors::range0(&len(ps)), h.clone(), {
        let m = m.clone();
        let cn = cn.clone();
        let j = j.clone();
        let ps = ps.clone();
        let args = args.clone();
        Rc::new(move |(p0, p1): (Map<Text, Rel>, Nat)| {
            let m = m.clone();
            let cn = cn.clone();
            let j = j.clone();
            let ps = ps.clone();
            let args = args.clone();
            entered(once_job(move || {
                let m2 = p0;
                let q = p1;
                match (get(&m, &Text::from(format!("sum:{}:{}:{}", &cn, &j, &q))), index(&ps, &q)) {
                    (Some(s), Some(p_)) => if &s.param == &top_param() {
                        prism_rtl::Turn::Finished(m2.clone())
                    } else {
                        match index(&args, &s.param) {
                            Some(a) => call_then(start_rel_of(m.clone(), a.value.clone()), move |rel_of_89107: Option<Rel>| match rel_of_89107 {
                                Some(r) => match &*p_.kind {
                                    ast::PatternKind::PName(n) => prism_rtl::Turn::Finished(insert(&m2, &check_env::sname_key(n), &Rel { param: r.param.clone(), strict: r.strict || s.strict })),
                                    _ => call_then(check_env::start_pattern_names(p_.clone()), move |pattern_names_89302: Array<Text>| prism_rtl::Turn::Finished(fold(&pattern_names_89302, &m2, &(|m3: &Map<Text, Rel>, n: &Text| insert(m3, n, &Rel { param: r.param.clone(), strict: true }))))),
                                },
                                None => prism_rtl::Turn::Finished(m2.clone()),
                            }),
                            None => prism_rtl::Turn::Finished(m2.clone()),
                        }
                    },
                    _ => prism_rtl::Turn::Finished(m2.clone()),
                }
            }))
        }) as Rc<dyn Fn((Map<Text, Rel>, Nat)) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>>>
    }))
}

/// ```prism
/// let topParam
/// ```
pub fn top_param() -> Nat {
    Nat::from(9999u32)
}

/// ```prism
/// TemplateKids: unbounded fn [TemplatePart], (Text ==> Rel) -> [Kid]
/// ```
pub fn template_kids(parts: &Array<ast::TemplatePart>, m: &Map<Text, Rel>) -> Array<Kid> {
    fold(parts, &Array::new(), &(|acc: &Array<Kid>, p_: &ast::TemplatePart| match p_ {
        ast::TemplatePart::TpPlaceholder(x, _) => push(acc, &Kid::KidExpr(x.clone(), m.clone())),
        ast::TemplatePart::TpBlock(b) => push(acc, &Kid::KidStmts(b.stmts.clone(), m.clone())),
        ast::TemplatePart::TpCall(n, args, ps_opt, span) => push(acc, &Kid::KidExpr(template_call_expr(n, args, ps_opt, span), m.clone())),
        _ => acc.clone(),
    }))
}

/// The step machine of `TemplateKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateKids: unbounded fn [TemplatePart], (Text ==> Rel) -> [Kid]
/// ```
pub struct TemplateKids {
    pub parts: Array<ast::TemplatePart>,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Array<Kid>> for TemplateKids {
    fn cycle(&self) -> prism_rtl::Turn<Array<Kid>> {
        let parts = &self.parts;
        let m = &self.m;
        prism_rtl::Turn::Finished(fold(parts, &Array::new(), &(|acc: &Array<Kid>, p_: &ast::TemplatePart| match p_ {
            ast::TemplatePart::TpPlaceholder(x, _) => push(acc, &Kid::KidExpr(x.clone(), m.clone())),
            ast::TemplatePart::TpBlock(b) => push(acc, &Kid::KidStmts(b.stmts.clone(), m.clone())),
            ast::TemplatePart::TpCall(n, args, ps_opt, span) => push(acc, &Kid::KidExpr(template_call_expr(n, args, ps_opt, span), m.clone())),
            _ => acc.clone(),
        })))
    }
}

/// `Start TemplateKids, x`: what the function value is when passed to `@Run`.
pub fn start_template_kids(parts: Array<ast::TemplatePart>, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Array<Kid>>> {
    Rc::new(TemplateKids { parts, m })
}

/// ```prism
/// TemplateCallExpr: fn SName, [Arg], ?[TemplatePart], Range -> Expr
/// ```
pub fn template_call_expr(n: &ast::SName, args: &Array<ast::Arg>, ps_opt: &Option<Array<ast::TemplatePart>>, span: &ast::Range) -> ast::Expr {
    let body = match ps_opt {
        Some(ps) => Array::from(vec![ast::Arg { name: Some(ast::Ident { name: Text::from("#body"), span: span.clone() }), value: ast::Expr { kind: Rc::new(ast::ExprKind::ETemplate(ast::Template { keyword: Text::from("InlineText"), lang: Text::from(""), delims: Text::from("double"), parts: ps.clone(), span: span.clone() })), span: span.clone() }, span: span.clone() }]),
        None => Array::new(),
    };
    ast::Expr { kind: Rc::new(ast::ExprKind::ECall(Rc::new(ast::Expr { kind: Rc::new(ast::ExprKind::EName(n.clone())), span: n.span.clone() }), append(args, &body), false, false)), span: span.clone() }
}

/// ```prism
/// ArgOf: fn Expr -> Arg
/// ```
pub fn arg_of(x: &ast::Expr) -> ast::Arg {
    ast::Arg { name: None, value: x.clone(), span: x.span.clone() }
}

/// ```prism
/// ExprsKids: fn [Expr], (Text ==> Rel) -> [Kid]
/// ```
pub fn exprs_kids(xs: &Array<ast::Expr>, m: &Map<Text, Rel>) -> Array<Kid> {
    each(xs, &(|x: &ast::Expr| Kid::KidExpr(x.clone(), m.clone())))
}

/// ```prism
/// OptKids: fn ?Expr, (Text ==> Rel) -> [Kid]
/// ```
pub fn opt_kids(opt0: &Option<ast::Expr>, map1: &Map<Text, Rel>) -> Array<Kid> {
    match (opt0, map1) {
        (Some(x), m) => Array::from(vec![Kid::KidExpr(x.clone(), m.clone())]),
        (None, _) => Array::new(),
    }
}

/// ```prism
/// LambdaKid: fn LambdaBody, (Text ==> Rel) -> Kid
/// ```
pub fn lambda_kid(lambda_body0: &ast::LambdaBody, m: &Map<Text, Rel>) -> Kid {
    match lambda_body0 {
        ast::LambdaBody::LbExpr(x) => Kid::KidExpr((**x).clone(), m.clone()),
        ast::LambdaBody::LbBlock(b) => Kid::KidStmts(b.stmts.clone(), m.clone()),
    }
}

/// ```prism
/// BodyKid: fn FnBody, (Text ==> Rel) -> Kid
/// ```
pub fn body_kid(fn_body0: &ast::FnBody, m: &Map<Text, Rel>) -> Kid {
    match fn_body0 {
        ast::FnBody::BodyExpr(x) => Kid::KidExpr(x.clone(), m.clone()),
        ast::FnBody::BodyBlock(b) => Kid::KidStmts(b.stmts.clone(), m.clone()),
    }
}

/// ```prism
/// PatternsNames: unbounded fn [Pattern] -> [Text]
/// ```
pub fn patterns_names(ps: &Array<ast::Pattern_>) -> Array<Text> {
    run_to_end(fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, ast::Pattern_)| entered(once_job(move || {
        let a = p0;
        let p_ = p1;
        call_then(check_env::start_pattern_names(p_.clone()), move |pattern_names_91261: Array<Text>| prism_rtl::Turn::Finished(check_types::union_texts(&a, &pattern_names_91261)))
    }))) as Rc<dyn Fn((Array<Text>, ast::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))
}

/// The step machine of `PatternsNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatternsNames: unbounded fn [Pattern] -> [Text]
/// ```
pub struct PatternsNames {
    pub ps: Array<ast::Pattern_>,
}

impl prism_rtl::Job<Array<Text>> for PatternsNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let ps = &self.ps;
        fold_job(ps.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, ast::Pattern_)| entered(once_job(move || {
            let a = p0;
            let p_ = p1;
            call_then(check_env::start_pattern_names(p_.clone()), move |pattern_names_91261: Array<Text>| prism_rtl::Turn::Finished(check_types::union_texts(&a, &pattern_names_91261)))
        }))) as Rc<dyn Fn((Array<Text>, ast::Pattern_)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle()
    }
}

/// `Start PatternsNames, x`: what the function value is when passed to `@Run`.
pub fn start_patterns_names(ps: Array<ast::Pattern_>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(PatternsNames { ps })
}

/// ```prism
/// ?CalleeName: fn Expr -> ?Text
/// ```
pub fn callee_name(c: &ast::Expr) -> Option<Text> {
    match &*c.kind {
        ast::ExprKind::EName(n) => Some(check_env::sname_key(n)),
        ast::ExprKind::ETypeArgs(t, _) => match &*t.kind {
            ast::ExprKind::EName(n) => Some(check_env::sname_key(n)),
            _ => None,
        },
        _ => None,
    }
}

/// ```prism
/// MethodCallee: fn SName -> Expr
/// ```
pub fn method_callee(n: &ast::SName) -> ast::Expr {
    ast::Expr { kind: Rc::new(ast::ExprKind::EName(n.clone())), span: n.span.clone() }
}

/// ```prism
/// MethodArgs: fn Expr, [Arg] -> [Arg]
/// ```
pub fn method_args(r: &ast::Expr, args: &Array<ast::Arg>) -> Array<ast::Arg> {
    append(&Array::from(vec![ast::Arg { name: None, value: r.clone(), span: r.span.clone() }]), args)
}

/// ```prism
/// BodySites: unbounded fn FnBody, (Text ==> Rel) -> [Site]
/// ```
pub fn body_sites(body: &ast::FnBody, m: &Map<Text, Rel>) -> Array<Site> {
    run_to_end(fold_job(body_spots(body, m), Array::new(), Rc::new(move |(p0, p1): (Array<Site>, Spot)| entered(once_job(move || {
        let acc = p0;
        let sp = p1;
        call_then(start_spot_sites(sp.clone()), move |spot_sites_92218: Array<Site>| prism_rtl::Turn::Finished(append(&acc, &spot_sites_92218)))
    }))) as Rc<dyn Fn((Array<Site>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Site>>>>))
}

/// The step machine of `BodySites`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BodySites: unbounded fn FnBody, (Text ==> Rel) -> [Site]
/// ```
pub struct BodySites {
    pub body: ast::FnBody,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Array<Site>> for BodySites {
    fn cycle(&self) -> prism_rtl::Turn<Array<Site>> {
        let body = &self.body;
        let m = &self.m;
        let body = body.clone();
        let m = m.clone();
        call_then(start_body_spots(body.clone(), m.clone()), move |body_spots_92168: Array<Spot>| fold_job(body_spots_92168, Array::new(), Rc::new(move |(p0, p1): (Array<Site>, Spot)| entered(once_job(move || {
            let acc = p0;
            let sp = p1;
            call_then(start_spot_sites(sp.clone()), move |spot_sites_92218: Array<Site>| prism_rtl::Turn::Finished(append(&acc, &spot_sites_92218)))
        }))) as Rc<dyn Fn((Array<Site>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Site>>>>).cycle())
    }
}

/// `Start BodySites, x`: what the function value is when passed to `@Run`.
pub fn start_body_sites(body: ast::FnBody, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Array<Site>>> {
    Rc::new(BodySites { body, m })
}

/// ```prism
/// SpotSites: unbounded fn Spot -> [Site]
/// ```
pub fn spot_sites(spot0: &Spot) -> Array<Site> {
    match spot0 {
        Spot::SpotStmt(_, _) => Array::new(),
        Spot::SpotExpr(e, m) => match &*e.kind {
            ast::ExprKind::EName(n) => Array::from(vec![Site { callee: check_env::sname_key(n), args: Array::new(), span: e.span.clone(), rels: m.clone() }]),
            ast::ExprKind::ECall(c, args, _, _) => call_sites(&**c, args, &e.span, m),
            ast::ExprKind::EMethod(r, n, args) => call_sites(&method_callee(n), &method_args(&**r, args), &e.span, m),
            ast::ExprKind::EBinary(op, l, r) => if is_called_op(op) {
                Array::from(vec![Site { callee: op.clone(), args: Array::from(vec![arg_of(&**l), arg_of(&**r)]), span: e.span.clone(), rels: m.clone() }])
            } else {
                Array::new()
            },
            _ => Array::new(),
        },
    }
}

/// The step machine of `SpotSites`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotSites: unbounded fn Spot -> [Site]
/// ```
pub struct SpotSites {
    pub spot0: Spot,
}

impl prism_rtl::Job<Array<Site>> for SpotSites {
    fn cycle(&self) -> prism_rtl::Turn<Array<Site>> {
        let spot0 = &self.spot0;
        match spot0 {
            Spot::SpotStmt(_, _) => prism_rtl::Turn::Finished(Array::new()),
            Spot::SpotExpr(e, m) => match &*e.kind {
                ast::ExprKind::EName(n) => prism_rtl::Turn::Finished(Array::from(vec![Site { callee: check_env::sname_key(n), args: Array::new(), span: e.span.clone(), rels: m.clone() }])),
                ast::ExprKind::ECall(c, args, _, _) => prism_rtl::Turn::More(Rc::new(CallSites { c: (**c).clone(), args: args.clone(), span: e.span.clone(), m: m.clone() })),
                ast::ExprKind::EMethod(r, n, args) => prism_rtl::Turn::More(Rc::new(CallSites { c: method_callee(n), args: method_args(&**r, args), span: e.span.clone(), m: m.clone() })),
                ast::ExprKind::EBinary(op, l, r) => if is_called_op(op) {
                    prism_rtl::Turn::Finished(Array::from(vec![Site { callee: op.clone(), args: Array::from(vec![arg_of(&**l), arg_of(&**r)]), span: e.span.clone(), rels: m.clone() }]))
                } else {
                    prism_rtl::Turn::Finished(Array::new())
                },
                _ => prism_rtl::Turn::Finished(Array::new()),
            },
        }
    }
}

/// `Start SpotSites, x`: what the function value is when passed to `@Run`.
pub fn start_spot_sites(spot0: Spot) -> Rc<dyn prism_rtl::Job<Array<Site>>> {
    Rc::new(SpotSites { spot0 })
}

/// ```prism
/// IsCalledOp: fn Text -> Bool
/// ```
pub fn is_called_op(op: &Text) -> bool {
    !check_types::has_text(&Array::from(vec![Text::from("and"), Text::from("or"), Text::from("on"), Text::from("<|"), Text::from("mod")]), op)
}

/// ```prism
/// CallSites: unbounded fn Expr, [Arg], Range, (Text ==> Rel) -> [Site]
/// ```
pub fn call_sites(c: &ast::Expr, args: &Array<ast::Arg>, span: &ast::Range, m: &Map<Text, Rel>) -> Array<Site> {
    let direct = match callee_name(c) {
        Some(n) => Array::from(vec![Site { callee: n.clone(), args: args.clone(), span: span.clone(), rels: m.clone() }]),
        None => Array::new(),
    };
    match traversal_of(m, c, args) {
        Some((coll, step_, at_)) => match &*step_.kind {
            ast::ExprKind::EName(n) => {
                let call_args = if &at_ == &Nat::from(1u32) {
                    Array::from(vec![or(&index(args, &Nat::from(1u32)), &dummy_arg()), arg_of(&part_of(&coll))])
                } else {
                    Array::from(vec![arg_of(&part_of(&coll))])
                };
                push(&direct, &Site { callee: check_env::sname_key(n), args: call_args.clone(), span: step_.span.clone(), rels: m.clone() })
            },
            _ => direct.clone(),
        },
        None => match acc_callee(m, c, args) {
            Some(cn) => append(&direct, &acc_sites(m, &cn, args)),
            None => direct.clone(),
        },
    }
}

/// The step machine of `CallSites`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallSites: unbounded fn Expr, [Arg], Range, (Text ==> Rel) -> [Site]
/// ```
pub struct CallSites {
    pub c: ast::Expr,
    pub args: Array<ast::Arg>,
    pub span: ast::Range,
    pub m: Map<Text, Rel>,
}

impl prism_rtl::Job<Array<Site>> for CallSites {
    fn cycle(&self) -> prism_rtl::Turn<Array<Site>> {
        let c = &self.c;
        let args = &self.args;
        let span = &self.span;
        let m = &self.m;
        let direct = match callee_name(c) {
            Some(n) => Array::from(vec![Site { callee: n.clone(), args: args.clone(), span: span.clone(), rels: m.clone() }]),
            None => Array::new(),
        };
        match traversal_of(m, c, args) {
            Some((coll, step_, at_)) => match &*step_.kind {
                ast::ExprKind::EName(n) => {
                    let call_args = if &at_ == &Nat::from(1u32) {
                        Array::from(vec![or(&index(args, &Nat::from(1u32)), &dummy_arg()), arg_of(&part_of(&coll))])
                    } else {
                        Array::from(vec![arg_of(&part_of(&coll))])
                    };
                    prism_rtl::Turn::Finished(push(&direct, &Site { callee: check_env::sname_key(n), args: call_args.clone(), span: step_.span.clone(), rels: m.clone() }))
                },
                _ => prism_rtl::Turn::Finished(direct.clone()),
            },
            None => match acc_callee(m, c, args) {
                Some(cn) => prism_rtl::Turn::Finished(append(&direct, &acc_sites(m, &cn, args))),
                None => prism_rtl::Turn::Finished(direct.clone()),
            },
        }
    }
}

/// `Start CallSites, x`: what the function value is when passed to `@Run`.
pub fn start_call_sites(c: ast::Expr, args: Array<ast::Arg>, span: ast::Range, m: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Array<Site>>> {
    Rc::new(CallSites { c, args, span, m })
}

/// ```prism
/// PartOf: fn Expr -> Expr
/// ```
pub fn part_of(x: &ast::Expr) -> ast::Expr {
    ast::Expr { kind: Rc::new(ast::ExprKind::EField(Rc::new(x.clone()), Text::from(""), ast::Ident { name: Text::from("element"), span: x.span.clone() })), span: x.span.clone() }
}

/// ```prism
/// AccSites: fn (Text ==> Rel), Text, [Arg] -> [Site]
/// ```
pub fn acc_sites(m: &Map<Text, Rel>, cn: &Text, args: &Array<ast::Arg>) -> Array<Site> {
    fold(&check_errors::range0(&len(args)), &Array::new(), &(|acc: &Array<Site>, j: &Nat| match (get(m, &Text::from(format!("acc:{}:{}", cn, j))), index(args, j)) {
        (Some(ar), Some(a)) => match &*a.value.kind {
            ast::ExprKind::EName(f) => push(acc, &Site { callee: check_env::sname_key(f), args: each(&check_errors::range0(&ar.param), &(|q: &Nat| acc_arg(m, cn, j, q, args))), span: a.value.span.clone(), rels: m.clone() }),
            _ => acc.clone(),
        },
        _ => acc.clone(),
    }))
}

/// ```prism
/// AccArg: fn (Text ==> Rel), Text, Nat, Nat, [Arg] -> Arg
/// ```
pub fn acc_arg(m: &Map<Text, Rel>, cn: &Text, j: &Nat, q: &Nat, args: &Array<ast::Arg>) -> ast::Arg {
    match get(m, &Text::from(format!("sum:{}:{}:{}", cn, j, q))) {
        Some(s) => if &s.param == &top_param() {
            arg_of(&top_expr())
        } else {
            match index(args, &s.param) {
                Some(a) => arg_of(&(if s.strict { part_of(&a.value) } else { a.value.clone() })),
                None => dummy_arg(),
            }
        },
        None => dummy_arg(),
    }
}

/// ```prism
/// let topExpr
/// ```
pub fn top_expr() -> ast::Expr {
    ast::Expr { kind: Rc::new(ast::ExprKind::EName(ast::SName { sigils: Text::from(""), path_: Array::from(vec![Text::from("⊤")]), span: ast::Range { start: Nat::from(0u32), end: Nat::from(0u32) } })), span: ast::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// SpotsNames: unbounded fn [Spot] -> [Text]
/// ```
pub fn spots_names(spots: &Array<Spot>) -> Array<Text> {
    run_to_end(fold_job(spots.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, Spot)| entered(once_job(move || {
        let acc = p0;
        let sp = p1;
        call_then(start_spot_names(sp.clone()), move |spot_names_95559: Array<Text>| prism_rtl::Turn::Finished(check_types::union_texts(&acc, &spot_names_95559)))
    }))) as Rc<dyn Fn((Array<Text>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))
}

/// The step machine of `SpotsNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotsNames: unbounded fn [Spot] -> [Text]
/// ```
pub struct SpotsNames {
    pub spots: Array<Spot>,
}

impl prism_rtl::Job<Array<Text>> for SpotsNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let spots = &self.spots;
        fold_job(spots.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, Spot)| entered(once_job(move || {
            let acc = p0;
            let sp = p1;
            call_then(start_spot_names(sp.clone()), move |spot_names_95559: Array<Text>| prism_rtl::Turn::Finished(check_types::union_texts(&acc, &spot_names_95559)))
        }))) as Rc<dyn Fn((Array<Text>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle()
    }
}

/// `Start SpotsNames, x`: what the function value is when passed to `@Run`.
pub fn start_spots_names(spots: Array<Spot>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SpotsNames { spots })
}

/// ```prism
/// SpotNames: unbounded fn Spot -> [Text]
/// ```
pub fn spot_names(sp: &Spot) -> Array<Text> {
    let called = each(&spot_sites(sp), &(|s: &Site| s.callee.clone()));
    match sp {
        Spot::SpotExpr(_, _) => called.clone(),
        Spot::SpotStmt(s, _) => match &s.kind {
            ast::StmtKind::SWidget(w) => check_types::add_text(&called, &check_env::sname_key(&w.name)),
            _ => called.clone(),
        },
    }
}

/// The step machine of `SpotNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotNames: unbounded fn Spot -> [Text]
/// ```
pub struct SpotNames {
    pub sp: Spot,
}

impl prism_rtl::Job<Array<Text>> for SpotNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let sp = &self.sp;
        let sp = sp.clone();
        call_then(start_spot_sites(sp.clone()), move |spot_sites_95653: Array<Site>| {
            let called = each(&spot_sites_95653, &(|s: &Site| s.callee.clone()));
            match &sp {
                Spot::SpotExpr(_, _) => prism_rtl::Turn::Finished(called.clone()),
                Spot::SpotStmt(s, _) => match &s.kind {
                    ast::StmtKind::SWidget(w) => prism_rtl::Turn::Finished(check_types::add_text(&called, &check_env::sname_key(&w.name))),
                    _ => prism_rtl::Turn::Finished(called.clone()),
                },
            }
        })
    }
}

/// `Start SpotNames, x`: what the function value is when passed to `@Run`.
pub fn start_spot_names(sp: Spot) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SpotNames { sp })
}

/// ```prism
/// ?TraversalOf: fn (Text ==> Rel), Expr, [Arg] -> ?((Expr, Expr, Nat))
/// ```
pub fn traversal_of(m: &Map<Text, Rel>, c: &ast::Expr, args: &Array<ast::Arg>) -> Option<(ast::Expr, ast::Expr, Nat)> {
    match &*c.kind {
        ast::ExprKind::EName(n) => {
            let name = check_env::sname_key(n);
            if pre_is(m, &name, &Text::from("Fold")) && (&len(args) == &Nat::from(3u32)) {
                match (index(args, &Nat::from(0u32)), index(args, &Nat::from(2u32))) {
                    (Some(a), Some(s)) => Some((a.value.clone(), s.value.clone(), Nat::from(1u32))),
                    _ => None,
                }
            } else {
                if (pre_is(m, &name, &Text::from("Each")) || pre_is(m, &name, &Text::from("Filter"))) && (&len(args) == &Nat::from(2u32)) {
                    match (index(args, &Nat::from(0u32)), index(args, &Nat::from(1u32))) {
                        (Some(a), Some(s)) => Some((a.value.clone(), s.value.clone(), Nat::from(0u32))),
                        _ => None,
                    }
                } else {
                    None
                }
            }
        },
        _ => None,
    }
}

/// ```prism
/// ?LastExpr: fn Block -> ?Expr
/// ```
pub fn last_expr(b: &ast::Block) -> Option<ast::Expr> {
    match lexer::last(&b.stmts) {
        Some(s) => match &s.kind {
            ast::StmtKind::SExpr(x) => Some(x.clone()),
            _ => None,
        },
        None => None,
    }
}

/// ```prism
/// ?RelOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
/// ```
pub fn rel_of(m: &Map<Text, Rel>, e: &ast::Expr) -> Option<Rel> {
    match &*e.kind {
        ast::ExprKind::EName(n) => get(m, &check_env::sname_key(n)),
        ast::ExprKind::EField(r, _, _) => match rel_of(m, &**r) {
            Some(x) => Some(Rel { param: x.param.clone(), strict: true }),
            None => None,
        },
        ast::ExprKind::EIndex(r, _) => rel_of(m, &**r),
        ast::ExprKind::EGroup(x) => rel_of(m, &**x),
        _ => match call_of(e) {
            Some((c, args)) => if is_non_nat_min(m, e, &c) { None } else { rel_of_call(m, &c, &args) },
            None => None,
        },
    }
}

/// The step machine of `RelOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?RelOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
/// ```
pub struct RelOf {
    pub m: Map<Text, Rel>,
    pub e: ast::Expr,
}

impl prism_rtl::Job<Option<Rel>> for RelOf {
    fn cycle(&self) -> prism_rtl::Turn<Option<Rel>> {
        let m = &self.m;
        let e = &self.e;
        match &*e.kind {
            ast::ExprKind::EName(n) => prism_rtl::Turn::Finished(get(m, &check_env::sname_key(n))),
            ast::ExprKind::EField(r, _, _) => {
                let m = m.clone();
                let r = (**r).clone();
                call_then(start_rel_of(m.clone(), r.clone()), move |rel_of_97769: Option<Rel>| match rel_of_97769 {
                    Some(x) => prism_rtl::Turn::Finished(Some(Rel { param: x.param.clone(), strict: true })),
                    None => prism_rtl::Turn::Finished(None),
                })
            },
            ast::ExprKind::EIndex(r, _) => prism_rtl::Turn::More(Rc::new(RelOf { m: m.clone(), e: (**r).clone() })),
            ast::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(RelOf { m: m.clone(), e: (**x).clone() })),
            _ => match call_of(e) {
                Some((c, args)) => if is_non_nat_min(m, e, &c) {
                    prism_rtl::Turn::Finished(None)
                } else {
                    prism_rtl::Turn::More(Rc::new(RelOfCall { m: m.clone(), c: c.clone(), args: args.clone() }))
                },
                None => prism_rtl::Turn::Finished(None),
            },
        }
    }
}

/// `Start RelOf, x`: what the function value is when passed to `@Run`.
pub fn start_rel_of(m: Map<Text, Rel>, e: ast::Expr) -> Rc<dyn prism_rtl::Job<Option<Rel>>> {
    Rc::new(RelOf { m, e })
}

/// ```prism
/// IsNonNatMin: fn (Text ==> Rel), Expr, Expr -> Bool
/// ```
pub fn is_non_nat_min(m: &Map<Text, Rel>, e: &ast::Expr, c: &ast::Expr) -> bool {
    match callee_name(c) {
        Some(n) => if pre_is(m, &n, &Text::from("Min")) { !is_nat_at(m, e) } else { false },
        None => false,
    }
}

/// ```prism
/// IsNatAt: fn (Text ==> Rel), Expr -> Bool
/// ```
pub fn is_nat_at(m: &Map<Text, Rel>, e: &ast::Expr) -> bool {
    match get(m, &Text::from("file:")) {
        Some(f) => check_env::has_key(m, &Text::from(format!("nat:{}:{}:{}", &f.param, &e.span.start, &e.span.end))),
        None => false,
    }
}

/// ```prism
/// ?RelOfCall: unbounded fn (Text ==> Rel), Expr, [Arg] -> ?Rel
/// ```
pub fn rel_of_call(m: &Map<Text, Rel>, c: &ast::Expr, args: &Array<ast::Arg>) -> Option<Rel> {
    match &*c.kind {
        ast::ExprKind::EName(n) => {
            let name = check_env::sname_key(n);
            if (pre_is(m, &name, &Text::from("Drop")) && (&len(args) == &Nat::from(2u32))) && is_positive_lit(&or(&index(args, &Nat::from(1u32)), &dummy_arg()).value) {
                match index(args, &Nat::from(0u32)) {
                    Some(a) => match rel_of(m, &a.value) {
                        Some(x) => Some(Rel { param: x.param.clone(), strict: x.strict || known_non_empty(m, &a.value) }),
                        None => None,
                    },
                    None => None,
                }
            } else {
                if (pre_is(m, &name, &Text::from("Values")) || pre_is(m, &name, &Text::from("Keys"))) && (&len(args) == &Nat::from(1u32)) {
                    rel_of(m, &or(&index(args, &Nat::from(0u32)), &dummy_arg()).value)
                } else {
                    match no_larger_arg(m, c, args) {
                        Some(a) => rel_of(m, &a),
                        None => None,
                    }
                }
            }
        },
        _ => None,
    }
}

/// The step machine of `RelOfCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?RelOfCall: unbounded fn (Text ==> Rel), Expr, [Arg] -> ?Rel
/// ```
pub struct RelOfCall {
    pub m: Map<Text, Rel>,
    pub c: ast::Expr,
    pub args: Array<ast::Arg>,
}

impl prism_rtl::Job<Option<Rel>> for RelOfCall {
    fn cycle(&self) -> prism_rtl::Turn<Option<Rel>> {
        let m = &self.m;
        let c = &self.c;
        let args = &self.args;
        match &*c.kind {
            ast::ExprKind::EName(n) => {
                let name = check_env::sname_key(n);
                if (pre_is(m, &name, &Text::from("Drop")) && (&len(args) == &Nat::from(2u32))) && is_positive_lit(&or(&index(args, &Nat::from(1u32)), &dummy_arg()).value) {
                    match index(args, &Nat::from(0u32)) {
                        Some(a) => {
                            let m = m.clone();
                            call_then(start_rel_of(m.clone(), a.value.clone()), move |rel_of_98926: Option<Rel>| match rel_of_98926 {
                                Some(x) => prism_rtl::Turn::Finished(Some(Rel { param: x.param.clone(), strict: x.strict || known_non_empty(&m, &a.value) })),
                                None => prism_rtl::Turn::Finished(None),
                            })
                        },
                        None => prism_rtl::Turn::Finished(None),
                    }
                } else {
                    if (pre_is(m, &name, &Text::from("Values")) || pre_is(m, &name, &Text::from("Keys"))) && (&len(args) == &Nat::from(1u32)) {
                        prism_rtl::Turn::More(Rc::new(RelOf { m: m.clone(), e: or(&index(args, &Nat::from(0u32)), &dummy_arg()).value.clone() }))
                    } else {
                        match no_larger_arg(m, c, args) {
                            Some(a) => prism_rtl::Turn::More(Rc::new(RelOf { m: m.clone(), e: a.clone() })),
                            None => prism_rtl::Turn::Finished(None),
                        }
                    }
                }
            },
            _ => prism_rtl::Turn::Finished(None),
        }
    }
}

/// `Start RelOfCall, x`: what the function value is when passed to `@Run`.
pub fn start_rel_of_call(m: Map<Text, Rel>, c: ast::Expr, args: Array<ast::Arg>) -> Rc<dyn prism_rtl::Job<Option<Rel>>> {
    Rc::new(RelOfCall { m, c, args })
}

/// ```prism
/// KnownNonEmpty: fn (Text ==> Rel), Expr -> Bool
/// ```
pub fn known_non_empty(m: &Map<Text, Rel>, e: &ast::Expr) -> bool {
    match name_of(e) {
        Some(n) => check_env::has_key(m, &Text::from(format!("ne:{}", &n))),
        None => false,
    }
}

/// ```prism
/// ?CallOf: fn Expr -> ?((Expr, [Arg]))
/// ```
pub fn call_of(e: &ast::Expr) -> Option<(ast::Expr, Array<ast::Arg>)> {
    match &*e.kind {
        ast::ExprKind::ECall(c, args, _, _) => Some(((**c).clone(), args.clone())),
        ast::ExprKind::EMethod(r, n, args) => Some((method_callee(n), method_args(&**r, args))),
        _ => None,
    }
}

/// ```prism
/// ?NoLargerArg: fn (Text ==> Rel), Expr, [Arg] -> ?Expr
/// ```
pub fn no_larger_arg(m: &Map<Text, Rel>, c: &ast::Expr, args: &Array<ast::Arg>) -> Option<ast::Expr> {
    match callee_name(c) {
        Some(n) => if is_local(m, &n) {
            None
        } else {
            match get(m, &Text::from(format!("fn:{}", &n))) {
                Some(s) => match index(args, &s.param) {
                    Some(a) => Some(a.value.clone()),
                    None => None,
                },
                None => None,
            }
        },
        None => None,
    }
}

/// ```prism
/// IsNoLargerPrelude: fn G, Text -> Bool
/// ```
pub fn is_no_larger_prelude(g: &check_env::G, k: &Text) -> bool {
    check_types::has_text(&Array::from(vec![Text::from("Prelude.Take"), Text::from("Prelude.Drop"), Text::from("Prelude.Filter"), Text::from("Prelude.Remove"), Text::from("Prelude.Min")]), k) && is_prelude_key(g, k)
}

/// ```prism
/// PartsSummaries: unbounded fn Shrink, [Def] -> (Text ==> Nat)
/// ```
pub fn parts_summaries(sk: &Shrink, fns: &Array<check_env::Def>) -> Map<Text, Nat> {
    run_to_end(fold_job(fns.clone(), Map::new(), {
        let sk = sk.clone();
        Rc::new(move |(p0, p1): (Map<Text, Nat>, check_env::Def)| {
            let sk = sk.clone();
            entered(once_job(move || {
                let m = p0;
                let d = p1;
                match &d.body {
                    check_env::DefBody::DbFn(clauses) => {
                        let n = match index(clauses, &Nat::from(0u32)) {
                            Some(c0) => len(&c0.params),
                            None => Nat::from(0u32),
                        };
                        let clauses = clauses.clone();
                        call_value(filter_job(check_errors::range0(&n), {
                            let clauses = clauses.clone();
                            let sk = sk.clone();
                            let d = d.clone();
                            Rc::new(move |p0: Nat| {
                                let clauses = clauses.clone();
                                let sk = sk.clone();
                                let d = d.clone();
                                entered(once_job(move || {
                                    let i = p0;
                                    fold_job(clauses.clone(), true, {
                                        let sk = sk.clone();
                                        let d = d.clone();
                                        let i = i.clone();
                                        Rc::new(move |(p0, p1): (bool, ast::FnClause)| {
                                            let sk = sk.clone();
                                            let d = d.clone();
                                            let i = i.clone();
                                            entered(once_job(move || {
                                                let okc = p0;
                                                let c = p1;
                                                prism_rtl::Turn::Finished(okc && clause_within(&clause_base(&sk, &d, &c), &c, &i))
                                            }))
                                        }) as Rc<dyn Fn((bool, ast::FnClause)) -> Rc<dyn prism_rtl::Job<bool>>>
                                    }).cycle()
                                }))
                            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<bool>>>
                        }), move |filter_101585: Array<Nat>| {
                            let ok = filter_101585;
                            match index(&ok, &Nat::from(0u32)) {
                                Some(i) => prism_rtl::Turn::Finished(insert(&m, &d.qk, &i)),
                                None => prism_rtl::Turn::Finished(m.clone()),
                            }
                        })
                    },
                    _ => prism_rtl::Turn::Finished(m.clone()),
                }
            }))
        }) as Rc<dyn Fn((Map<Text, Nat>, check_env::Def)) -> Rc<dyn prism_rtl::Job<Map<Text, Nat>>>>
    }))
}

/// The step machine of `PartsSummaries`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PartsSummaries: unbounded fn Shrink, [Def] -> (Text ==> Nat)
/// ```
pub struct PartsSummaries {
    pub sk: Shrink,
    pub fns: Array<check_env::Def>,
}

impl prism_rtl::Job<Map<Text, Nat>> for PartsSummaries {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Nat>> {
        let sk = &self.sk;
        let fns = &self.fns;
        fold_job(fns.clone(), Map::new(), {
            let sk = sk.clone();
            Rc::new(move |(p0, p1): (Map<Text, Nat>, check_env::Def)| {
                let sk = sk.clone();
                entered(once_job(move || {
                    let m = p0;
                    let d = p1;
                    match &d.body {
                        check_env::DefBody::DbFn(clauses) => {
                            let n = match index(clauses, &Nat::from(0u32)) {
                                Some(c0) => len(&c0.params),
                                None => Nat::from(0u32),
                            };
                            let clauses = clauses.clone();
                            call_value(filter_job(check_errors::range0(&n), {
                                let clauses = clauses.clone();
                                let sk = sk.clone();
                                let d = d.clone();
                                Rc::new(move |p0: Nat| {
                                    let clauses = clauses.clone();
                                    let sk = sk.clone();
                                    let d = d.clone();
                                    entered(once_job(move || {
                                        let i = p0;
                                        fold_job(clauses.clone(), true, {
                                            let sk = sk.clone();
                                            let d = d.clone();
                                            let i = i.clone();
                                            Rc::new(move |(p0, p1): (bool, ast::FnClause)| {
                                                let sk = sk.clone();
                                                let d = d.clone();
                                                let i = i.clone();
                                                entered(once_job(move || {
                                                    let okc = p0;
                                                    let c = p1;
                                                    prism_rtl::Turn::Finished(okc && clause_within(&clause_base(&sk, &d, &c), &c, &i))
                                                }))
                                            }) as Rc<dyn Fn((bool, ast::FnClause)) -> Rc<dyn prism_rtl::Job<bool>>>
                                        }).cycle()
                                    }))
                                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<bool>>>
                            }), move |filter_101585: Array<Nat>| {
                                let ok = filter_101585;
                                match index(&ok, &Nat::from(0u32)) {
                                    Some(i) => prism_rtl::Turn::Finished(insert(&m, &d.qk, &i)),
                                    None => prism_rtl::Turn::Finished(m.clone()),
                                }
                            })
                        },
                        _ => prism_rtl::Turn::Finished(m.clone()),
                    }
                }))
            }) as Rc<dyn Fn((Map<Text, Nat>, check_env::Def)) -> Rc<dyn prism_rtl::Job<Map<Text, Nat>>>>
        }).cycle()
    }
}

/// `Start PartsSummaries, x`: what the function value is when passed to `@Run`.
pub fn start_parts_summaries(sk: Shrink, fns: Array<check_env::Def>) -> Rc<dyn prism_rtl::Job<Map<Text, Nat>>> {
    Rc::new(PartsSummaries { sk, fns })
}

/// ```prism
/// ClauseWithin: unbounded fn (Text ==> Rel), FnClause, Nat -> Bool
/// ```
pub fn clause_within(base: &Map<Text, Rel>, c: &ast::FnClause, i: &Nat) -> bool {
    match &c.body {
        ast::FnBody::BodyExpr(e) => within(base, i, e),
        ast::FnBody::BodyBlock(b) => within_block(base, i, b),
    }
}

/// The step machine of `ClauseWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseWithin: unbounded fn (Text ==> Rel), FnClause, Nat -> Bool
/// ```
pub struct ClauseWithin {
    pub base: Map<Text, Rel>,
    pub c: ast::FnClause,
    pub i: Nat,
}

impl prism_rtl::Job<bool> for ClauseWithin {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let base = &self.base;
        let c = &self.c;
        let i = &self.i;
        match &c.body {
            ast::FnBody::BodyExpr(e) => prism_rtl::Turn::More(Rc::new(Within { m: base.clone(), i: i.clone(), e: e.clone() })),
            ast::FnBody::BodyBlock(b) => prism_rtl::Turn::More(Rc::new(WithinBlock { m: base.clone(), i: i.clone(), b: b.clone() })),
        }
    }
}

/// `Start ClauseWithin, x`: what the function value is when passed to `@Run`.
pub fn start_clause_within(base: Map<Text, Rel>, c: ast::FnClause, i: Nat) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(ClauseWithin { base, c, i })
}

/// ```prism
/// Within: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
/// ```
pub fn within(m: &Map<Text, Rel>, i: &Nat, e: &ast::Expr) -> bool {
    match rel_of(m, e) {
        Some(r) => &r.param == i,
        None => match &*e.kind {
            ast::ExprKind::EArray(es) => run_to_end(fold_job(es.clone(), true, {
                let m = m.clone();
                let i = i.clone();
                Rc::new(move |(p0, p1): (bool, ast::Expr)| {
                    let m = m.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let ok = p0;
                        let x = p1;
                        prism_rtl::Turn::Finished(ok && part(&m, &i, &x))
                    }))
                }) as Rc<dyn Fn((bool, ast::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
            })),
            ast::ExprKind::EMap(kvs) => run_to_end(fold_job(kvs.clone(), true, {
                let m = m.clone();
                let i = i.clone();
                Rc::new(move |(p0, p1): (bool, (ast::Expr, ast::Expr))| {
                    let m = m.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let ok = p0;
                        let (k, v_) = p1;
                        prism_rtl::Turn::Finished((ok && part(&m, &i, &k)) && part(&m, &i, &v_))
                    }))
                }) as Rc<dyn Fn((bool, (ast::Expr, ast::Expr))) -> Rc<dyn prism_rtl::Job<bool>>>
            })),
            ast::ExprKind::EGroup(x) => within(m, i, &**x),
            ast::ExprKind::EMatch(s, arms) => run_to_end(fold_job(arms.clone(), true, {
                let s = (**s).clone();
                let m = m.clone();
                let i = i.clone();
                Rc::new(move |(p0, p1): (bool, ast::Arm)| {
                    let s = s.clone();
                    let m = m.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let ok = p0;
                        let a = p1;
                        prism_rtl::Turn::Finished(ok && within_block(&arm_pat_rels(&s, &a, &m), &i, &a.body))
                    }))
                }) as Rc<dyn Fn((bool, ast::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
            })),
            ast::ExprKind::EIf(c, t, Some(el)) => within_block(&cond_rels(&**c, m), i, t) && within_block(m, i, el),
            ast::ExprKind::EUpdate(start, b) => within(m, i, &**start) && update_within(&insert(m, &Text::from("&_"), &Rel { param: i.clone(), strict: false }), i, b),
            _ => match call_of(e) {
                Some((c, args)) => match traversal_of(m, &c, &args) {
                    Some((coll, step_, at_)) => within(m, i, &coll) && step_within(m, i, &expr_name(&c), &coll, &step_, &at_, &or(&index(&args, &Nat::from(1u32)), &dummy_arg()).value),
                    None => false,
                },
                None => false,
            },
        },
    }
}

/// The step machine of `Within`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Within: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
/// ```
pub struct Within {
    pub m: Map<Text, Rel>,
    pub i: Nat,
    pub e: ast::Expr,
}

impl prism_rtl::Job<bool> for Within {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m = &self.m;
        let i = &self.i;
        let e = &self.e;
        let e = e.clone();
        let i = i.clone();
        let m = m.clone();
        call_then(start_rel_of(m.clone(), e.clone()), move |rel_of_102045: Option<Rel>| match rel_of_102045 {
            Some(r) => prism_rtl::Turn::Finished(&r.param == &i),
            None => match &*e.kind {
                ast::ExprKind::EArray(es) => fold_job(es.clone(), true, {
                    let m = m.clone();
                    let i = i.clone();
                    Rc::new(move |(p0, p1): (bool, ast::Expr)| {
                        let m = m.clone();
                        let i = i.clone();
                        entered(once_job(move || {
                            let ok = p0;
                            let x = p1;
                            prism_rtl::Turn::Finished(ok && part(&m, &i, &x))
                        }))
                    }) as Rc<dyn Fn((bool, ast::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
                }).cycle(),
                ast::ExprKind::EMap(kvs) => fold_job(kvs.clone(), true, {
                    let m = m.clone();
                    let i = i.clone();
                    Rc::new(move |(p0, p1): (bool, (ast::Expr, ast::Expr))| {
                        let m = m.clone();
                        let i = i.clone();
                        entered(once_job(move || {
                            let ok = p0;
                            let (k, v_) = p1;
                            prism_rtl::Turn::Finished((ok && part(&m, &i, &k)) && part(&m, &i, &v_))
                        }))
                    }) as Rc<dyn Fn((bool, (ast::Expr, ast::Expr))) -> Rc<dyn prism_rtl::Job<bool>>>
                }).cycle(),
                ast::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(Within { m: m.clone(), i: i.clone(), e: (**x).clone() })),
                ast::ExprKind::EMatch(s, arms) => fold_job(arms.clone(), true, {
                    let s = (**s).clone();
                    let m = m.clone();
                    let i = i.clone();
                    Rc::new(move |(p0, p1): (bool, ast::Arm)| {
                        let s = s.clone();
                        let m = m.clone();
                        let i = i.clone();
                        entered(once_job(move || {
                            let ok = p0;
                            let a = p1;
                            prism_rtl::Turn::Finished(ok && within_block(&arm_pat_rels(&s, &a, &m), &i, &a.body))
                        }))
                    }) as Rc<dyn Fn((bool, ast::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
                }).cycle(),
                ast::ExprKind::EIf(c, t, Some(el)) => {
                    let c = (**c).clone();
                    let el = el.clone();
                    let t = t.clone();
                    call_then(start_cond_rels(c.clone(), m.clone()), move |cond_rels_102429: Map<Text, Rel>| call_then(start_within_block(cond_rels_102429, i.clone(), t.clone()), move |within_block_102416: bool| prism_rtl::Turn::Finished(within_block_102416 && within_block(&m, &i, &el))))
                },
                ast::ExprKind::EUpdate(start, b) => {
                    let b = b.clone();
                    let start = (**start).clone();
                    call_then(start_within(m.clone(), i.clone(), start.clone()), move |within_102503: bool| prism_rtl::Turn::Finished(within_102503 && update_within(&insert(&m, &Text::from("&_"), &Rel { param: i.clone(), strict: false }), &i, &b)))
                },
                _ => match call_of(&e) {
                    Some((c, args)) => match traversal_of(&m, &c, &args) {
                        Some((coll, step_, at_)) => call_then(start_within(m.clone(), i.clone(), coll.clone()), move |within_102724: bool| prism_rtl::Turn::Finished(within_102724 && step_within(&m, &i, &expr_name(&c), &coll, &step_, &at_, &or(&index(&args, &Nat::from(1u32)), &dummy_arg()).value))),
                        None => prism_rtl::Turn::Finished(false),
                    },
                    None => prism_rtl::Turn::Finished(false),
                },
            },
        })
    }
}

/// `Start Within, x`: what the function value is when passed to `@Run`.
pub fn start_within(m: Map<Text, Rel>, i: Nat, e: ast::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(Within { m, i, e })
}

/// ```prism
/// UpdateWithin: unbounded fn (Text ==> Rel), Nat, Block -> Bool
/// ```
pub fn update_within(m: &Map<Text, Rel>, i: &Nat, b: &ast::Block) -> bool {
    run_to_end(fold_job(stmts_spots(&b.stmts, m), true, {
        let i = i.clone();
        Rc::new(move |(p0, p1): (bool, Spot)| {
            let i = i.clone();
            entered(once_job(move || {
                let ok = p0;
                let sp = p1;
                prism_rtl::Turn::Finished(ok && spot_keeps_within(&sp, &i))
            }))
        }) as Rc<dyn Fn((bool, Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `UpdateWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateWithin: unbounded fn (Text ==> Rel), Nat, Block -> Bool
/// ```
pub struct UpdateWithin {
    pub m: Map<Text, Rel>,
    pub i: Nat,
    pub b: ast::Block,
}

impl prism_rtl::Job<bool> for UpdateWithin {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m = &self.m;
        let i = &self.i;
        let b = &self.b;
        let b = b.clone();
        let i = i.clone();
        let m = m.clone();
        call_then(start_stmts_spots(b.stmts.clone(), m.clone()), move |stmts_spots_103186: Array<Spot>| fold_job(stmts_spots_103186, true, {
            let i = i.clone();
            Rc::new(move |(p0, p1): (bool, Spot)| {
                let i = i.clone();
                entered(once_job(move || {
                    let ok = p0;
                    let sp = p1;
                    prism_rtl::Turn::Finished(ok && spot_keeps_within(&sp, &i))
                }))
            }) as Rc<dyn Fn((bool, Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
        }).cycle())
    }
}

/// `Start UpdateWithin, x`: what the function value is when passed to `@Run`.
pub fn start_update_within(m: Map<Text, Rel>, i: Nat, b: ast::Block) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(UpdateWithin { m, i, b })
}

/// ```prism
/// SpotKeepsWithin: unbounded fn Spot, Nat -> Bool
/// ```
pub fn spot_keeps_within(spot0: &Spot, n1: &Nat) -> bool {
    match (spot0, n1) {
        (Spot::SpotStmt(s, m), i) => match &s.kind {
            ast::StmtKind::SSet(t, value) => if &take(&ref_path(t), &Nat::from(1u32)) != &Array::from(vec![Text::from("&_")]) {
                true
            } else {
                (&ref_path(t) == &Array::from(vec![Text::from("&_")])) && within(m, i, value)
            },
            ast::StmtKind::SAccum(t, _, _) => &take(&ref_path(t), &Nat::from(1u32)) != &Array::from(vec![Text::from("&_")]),
            _ => true,
        },
        (Spot::SpotExpr(_, _), _) => true,
    }
}

/// The step machine of `SpotKeepsWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotKeepsWithin: unbounded fn Spot, Nat -> Bool
/// ```
pub struct SpotKeepsWithin {
    pub spot0: Spot,
    pub n1: Nat,
}

impl prism_rtl::Job<bool> for SpotKeepsWithin {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let spot0 = &self.spot0;
        let n1 = &self.n1;
        match (spot0, n1) {
            (Spot::SpotStmt(s, m), i) => match &s.kind {
                ast::StmtKind::SSet(t, value) => {
                    let i = i.clone();
                    let m = m.clone();
                    let t = t.clone();
                    let value = value.clone();
                    call_then(start_ref_path(t.clone()), move |ref_path_103395: Array<Text>| if &take(&ref_path_103395, &Nat::from(1u32)) != &Array::from(vec![Text::from("&_")]) {
                        prism_rtl::Turn::Finished(true)
                    } else {
                        call_then(start_ref_path(t.clone()), move |ref_path_103443: Array<Text>| prism_rtl::Turn::Finished((&ref_path_103443 == &Array::from(vec![Text::from("&_")])) && within(&m, &i, &value)))
                    })
                },
                ast::StmtKind::SAccum(t, _, _) => {
                    let t = t.clone();
                    call_then(start_ref_path(t.clone()), move |ref_path_103526: Array<Text>| prism_rtl::Turn::Finished(&take(&ref_path_103526, &Nat::from(1u32)) != &Array::from(vec![Text::from("&_")])))
                },
                _ => prism_rtl::Turn::Finished(true),
            },
            (Spot::SpotExpr(_, _), _) => prism_rtl::Turn::Finished(true),
        }
    }
}

/// `Start SpotKeepsWithin, x`: what the function value is when passed to `@Run`.
pub fn start_spot_keeps_within(spot0: Spot, n1: Nat) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(SpotKeepsWithin { spot0, n1 })
}

/// ```prism
/// WithinBlock: unbounded fn (Text ==> Rel), Nat, Block -> Bool
/// ```
pub fn within_block(m: &Map<Text, Rel>, i: &Nat, b: &ast::Block) -> bool {
    within(&block_rels(&b.stmts, m), i, &last_or(b))
}

/// The step machine of `WithinBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WithinBlock: unbounded fn (Text ==> Rel), Nat, Block -> Bool
/// ```
pub struct WithinBlock {
    pub m: Map<Text, Rel>,
    pub i: Nat,
    pub b: ast::Block,
}

impl prism_rtl::Job<bool> for WithinBlock {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m = &self.m;
        let i = &self.i;
        let b = &self.b;
        let b = b.clone();
        let i = i.clone();
        let m = m.clone();
        call_then(start_block_rels(b.stmts.clone(), m.clone()), move |block_rels_103790: Map<Text, Rel>| prism_rtl::Turn::More(Rc::new(Within { m: block_rels_103790, i: i.clone(), e: last_or(&b) })))
    }
}

/// `Start WithinBlock, x`: what the function value is when passed to `@Run`.
pub fn start_within_block(m: Map<Text, Rel>, i: Nat, b: ast::Block) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(WithinBlock { m, i, b })
}

/// ```prism
/// StepWithin: unbounded fn (Text ==> Rel), Nat, Text, Expr, Expr, Nat, Expr -> Bool
/// ```
pub fn step_within(m: &Map<Text, Rel>, i: &Nat, f: &Text, coll: &ast::Expr, step_: &ast::Expr, at_: &Nat, z: &ast::Expr) -> bool {
    if pre_is(m, f, &Text::from("Filter")) {
        true
    } else {
        match &*step_.kind {
            ast::ExprKind::ELambda(Some(ps), body) => {
                let sm = step_rels(m, coll, ps, at_);
                let (bm, x) = match &**body {
                    ast::LambdaBody::LbExpr(y) => (sm.clone(), (**y).clone()),
                    ast::LambdaBody::LbBlock(b) => (block_rels(&b.stmts, &sm), last_or(b)),
                };
                if pre_is(m, f, &Text::from("Each")) {
                    part(&bm, i, &x)
                } else {
                    match index(ps, &Nat::from(0u32)) {
                        Some(acc) => match &*acc.kind {
                            ast::PatternKind::PName(n) => within(m, i, z) && builds_on(&bm, i, &check_env::sname_key(n), &x),
                            _ => false,
                        },
                        None => false,
                    }
                }
            },
            _ => false,
        }
    }
}

/// The step machine of `StepWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StepWithin: unbounded fn (Text ==> Rel), Nat, Text, Expr, Expr, Nat, Expr -> Bool
/// ```
pub struct StepWithin {
    pub m: Map<Text, Rel>,
    pub i: Nat,
    pub f: Text,
    pub coll: ast::Expr,
    pub step_: ast::Expr,
    pub at_: Nat,
    pub z: ast::Expr,
}

impl prism_rtl::Job<bool> for StepWithin {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m = &self.m;
        let i = &self.i;
        let f = &self.f;
        let coll = &self.coll;
        let step_ = &self.step_;
        let at_ = &self.at_;
        let z = &self.z;
        if pre_is(m, f, &Text::from("Filter")) {
            prism_rtl::Turn::Finished(true)
        } else {
            match &*step_.kind {
                ast::ExprKind::ELambda(Some(ps), body) => {
                    let at_ = at_.clone();
                    let body = (**body).clone();
                    let coll = coll.clone();
                    let f = f.clone();
                    let i = i.clone();
                    let m = m.clone();
                    let ps = ps.clone();
                    let z = z.clone();
                    call_then(start_step_rels(m.clone(), coll.clone(), ps.clone(), at_.clone()), move |step_rels_104220: Map<Text, Rel>| {
                        let sm = step_rels_104220;
                        let (bm, x) = match &body {
                            ast::LambdaBody::LbExpr(y) => (sm.clone(), (**y).clone()),
                            ast::LambdaBody::LbBlock(b) => (block_rels(&b.stmts, &sm), last_or(b)),
                        };
                        if pre_is(&m, &f, &Text::from("Each")) {
                            prism_rtl::Turn::More(Rc::new(Part { m: bm.clone(), i: i.clone(), e: x.clone() }))
                        } else {
                            match index(&ps, &Nat::from(0u32)) {
                                Some(acc) => match &*acc.kind {
                                    ast::PatternKind::PName(n) => {
                                        let n = n.clone();
                                        call_then(start_within(m.clone(), i.clone(), z.clone()), move |within_104537: bool| prism_rtl::Turn::Finished(within_104537 && builds_on(&bm, &i, &check_env::sname_key(&n), &x)))
                                    },
                                    _ => prism_rtl::Turn::Finished(false),
                                },
                                None => prism_rtl::Turn::Finished(false),
                            }
                        }
                    })
                },
                _ => prism_rtl::Turn::Finished(false),
            }
        }
    }
}

/// `Start StepWithin, x`: what the function value is when passed to `@Run`.
pub fn start_step_within(m: Map<Text, Rel>, i: Nat, f: Text, coll: ast::Expr, step_: ast::Expr, at_: Nat, z: ast::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(StepWithin { m, i, f, coll, step_, at_, z })
}

/// ```prism
/// LastOr: fn Block -> Expr
/// ```
pub fn last_or(b: &ast::Block) -> ast::Expr {
    or(&last_expr(b), &dummy_arg().value)
}

/// ```prism
/// BuildsOn: unbounded fn (Text ==> Rel), Nat, Text, Expr -> Bool
/// ```
pub fn builds_on(m: &Map<Text, Rel>, i: &Nat, acc: &Text, e: &ast::Expr) -> bool {
    match &*e.kind {
        ast::ExprKind::EName(n) => &check_env::sname_key(n) == acc,
        ast::ExprKind::EGroup(x) => builds_on(m, i, acc, &**x),
        ast::ExprKind::EMatch(s, arms) => run_to_end(fold_job(arms.clone(), true, {
            let acc = acc.clone();
            let s = (**s).clone();
            let m = m.clone();
            let i = i.clone();
            Rc::new(move |(p0, p1): (bool, ast::Arm)| {
                let acc = acc.clone();
                let s = s.clone();
                let m = m.clone();
                let i = i.clone();
                entered(once_job(move || {
                    let ok = p0;
                    let a = p1;
                    prism_rtl::Turn::Finished((ok && !check_types::has_text(&opt_names(&a.pattern), &acc)) && builds_on_block(&arm_pat_rels(&s, &a, &m), &i, &acc, &a.body))
                }))
            }) as Rc<dyn Fn((bool, ast::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        ast::ExprKind::EIf(c, t, Some(el)) => (!check_types::has_text(&cond_names(&**c), acc) && builds_on_block(&cond_rels(&**c, m), i, acc, t)) && builds_on_block(m, i, acc, el),
        _ => match call_of(e) {
            Some((c, args)) => builds_on_call(m, i, acc, &c, &args),
            None => false,
        },
    }
}

/// The step machine of `BuildsOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildsOn: unbounded fn (Text ==> Rel), Nat, Text, Expr -> Bool
/// ```
pub struct BuildsOn {
    pub m: Map<Text, Rel>,
    pub i: Nat,
    pub acc: Text,
    pub e: ast::Expr,
}

impl prism_rtl::Job<bool> for BuildsOn {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m = &self.m;
        let i = &self.i;
        let acc = &self.acc;
        let e = &self.e;
        match &*e.kind {
            ast::ExprKind::EName(n) => prism_rtl::Turn::Finished(&check_env::sname_key(n) == acc),
            ast::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(BuildsOn { m: m.clone(), i: i.clone(), acc: acc.clone(), e: (**x).clone() })),
            ast::ExprKind::EMatch(s, arms) => fold_job(arms.clone(), true, {
                let acc = acc.clone();
                let s = (**s).clone();
                let m = m.clone();
                let i = i.clone();
                Rc::new(move |(p0, p1): (bool, ast::Arm)| {
                    let acc = acc.clone();
                    let s = s.clone();
                    let m = m.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let ok = p0;
                        let a = p1;
                        prism_rtl::Turn::Finished((ok && !check_types::has_text(&opt_names(&a.pattern), &acc)) && builds_on_block(&arm_pat_rels(&s, &a, &m), &i, &acc, &a.body))
                    }))
                }) as Rc<dyn Fn((bool, ast::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            ast::ExprKind::EIf(c, t, Some(el)) => {
                let acc = acc.clone();
                let c = (**c).clone();
                let el = el.clone();
                let i = i.clone();
                let m = m.clone();
                let t = t.clone();
                call_then(start_cond_names(c.clone()), move |cond_names_105251: Array<Text>| prism_rtl::Turn::Finished((!check_types::has_text(&cond_names_105251, &acc) && builds_on_block(&cond_rels(&c, &m), &i, &acc, &t)) && builds_on_block(&m, &i, &acc, &el)))
            },
            _ => match call_of(e) {
                Some((c, args)) => prism_rtl::Turn::More(Rc::new(BuildsOnCall { m: m.clone(), i: i.clone(), acc: acc.clone(), c: c.clone(), args: args.clone() })),
                None => prism_rtl::Turn::Finished(false),
            },
        }
    }
}

/// `Start BuildsOn, x`: what the function value is when passed to `@Run`.
pub fn start_builds_on(m: Map<Text, Rel>, i: Nat, acc: Text, e: ast::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(BuildsOn { m, i, acc, e })
}

/// ```prism
/// BuildsOnCall: unbounded fn (Text ==> Rel), Nat, Text, Expr, [Arg] -> Bool
/// ```
pub fn builds_on_call(m: &Map<Text, Rel>, i: &Nat, acc: &Text, c: &ast::Expr, args: &Array<ast::Arg>) -> bool {
    let f = expr_name(c);
    let on_acc = builds_on(m, i, acc, &or(&index(args, &Nat::from(0u32)), &dummy_arg()).value);
    let rest = each(&drop(args, &Nat::from(1u32)), &(|a: &ast::Arg| a.value.clone()));
    let parts = run_to_end(fold_job(rest.clone(), true, {
        let m = m.clone();
        let i = i.clone();
        Rc::new(move |(p0, p1): (bool, ast::Expr)| {
            let m = m.clone();
            let i = i.clone();
            entered(once_job(move || {
                let ok = p0;
                let x = p1;
                prism_rtl::Turn::Finished(ok && part(&m, &i, &x))
            }))
        }) as Rc<dyn Fn((bool, ast::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    if !on_acc {
        false
    } else {
        if pre_is(m, &f, &Text::from("Push")) && (&len(&rest) == &Nat::from(1u32)) {
            parts
        } else {
            if pre_is(m, &f, &Text::from("Insert")) && (&len(&rest) == &Nat::from(2u32)) {
                parts
            } else {
                if pre_is(m, &f, &Text::from("Append")) && (&len(&rest) == &Nat::from(1u32)) {
                    within(m, i, &or(&index(&rest, &Nat::from(0u32)), &dummy_arg().value))
                } else {
                    false
                }
            }
        }
    }
}

/// The step machine of `BuildsOnCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildsOnCall: unbounded fn (Text ==> Rel), Nat, Text, Expr, [Arg] -> Bool
/// ```
pub struct BuildsOnCall {
    pub m: Map<Text, Rel>,
    pub i: Nat,
    pub acc: Text,
    pub c: ast::Expr,
    pub args: Array<ast::Arg>,
}

impl prism_rtl::Job<bool> for BuildsOnCall {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m = &self.m;
        let i = &self.i;
        let acc = &self.acc;
        let c = &self.c;
        let args = &self.args;
        let f = expr_name(c);
        let acc = acc.clone();
        let args = args.clone();
        let i = i.clone();
        let m = m.clone();
        call_then(start_builds_on(m.clone(), i.clone(), acc.clone(), or(&index(&args, &Nat::from(0u32)), &dummy_arg()).value.clone()), move |builds_on_105681: bool| {
            let on_acc = builds_on_105681;
            let rest = each(&drop(&args, &Nat::from(1u32)), &(|a: &ast::Arg| a.value.clone()));
            call_value(fold_job(rest.clone(), true, {
                let m = m.clone();
                let i = i.clone();
                Rc::new(move |(p0, p1): (bool, ast::Expr)| {
                    let m = m.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let ok = p0;
                        let x = p1;
                        prism_rtl::Turn::Finished(ok && part(&m, &i, &x))
                    }))
                }) as Rc<dyn Fn((bool, ast::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
            }), move |fold_105795: bool| {
                let parts = fold_105795;
                if !on_acc {
                    prism_rtl::Turn::Finished(false)
                } else {
                    if pre_is(&m, &f, &Text::from("Push")) && (&len(&rest) == &Nat::from(1u32)) {
                        prism_rtl::Turn::Finished(parts)
                    } else {
                        if pre_is(&m, &f, &Text::from("Insert")) && (&len(&rest) == &Nat::from(2u32)) {
                            prism_rtl::Turn::Finished(parts)
                        } else {
                            if pre_is(&m, &f, &Text::from("Append")) && (&len(&rest) == &Nat::from(1u32)) {
                                prism_rtl::Turn::More(Rc::new(Within { m: m.clone(), i: i.clone(), e: or(&index(&rest, &Nat::from(0u32)), &dummy_arg().value) }))
                            } else {
                                prism_rtl::Turn::Finished(false)
                            }
                        }
                    }
                }
            })
        })
    }
}

/// `Start BuildsOnCall, x`: what the function value is when passed to `@Run`.
pub fn start_builds_on_call(m: Map<Text, Rel>, i: Nat, acc: Text, c: ast::Expr, args: Array<ast::Arg>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(BuildsOnCall { m, i, acc, c, args })
}

/// ```prism
/// BuildsOnBlock: unbounded fn (Text ==> Rel), Nat, Text, Block -> Bool
/// ```
pub fn builds_on_block(m: &Map<Text, Rel>, i: &Nat, acc: &Text, b: &ast::Block) -> bool {
    !check_types::has_text(&stmts_binders(&b.stmts), acc) && builds_on(&block_rels(&b.stmts, m), i, acc, &last_or(b))
}

/// The step machine of `BuildsOnBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildsOnBlock: unbounded fn (Text ==> Rel), Nat, Text, Block -> Bool
/// ```
pub struct BuildsOnBlock {
    pub m: Map<Text, Rel>,
    pub i: Nat,
    pub acc: Text,
    pub b: ast::Block,
}

impl prism_rtl::Job<bool> for BuildsOnBlock {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m = &self.m;
        let i = &self.i;
        let acc = &self.acc;
        let b = &self.b;
        let acc = acc.clone();
        let b = b.clone();
        let i = i.clone();
        let m = m.clone();
        call_then(start_stmts_binders(b.stmts.clone()), move |stmts_binders_106355: Array<Text>| prism_rtl::Turn::Finished(!check_types::has_text(&stmts_binders_106355, &acc) && builds_on(&block_rels(&b.stmts, &m), &i, &acc, &last_or(&b))))
    }
}

/// `Start BuildsOnBlock, x`: what the function value is when passed to `@Run`.
pub fn start_builds_on_block(m: Map<Text, Rel>, i: Nat, acc: Text, b: ast::Block) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(BuildsOnBlock { m, i, acc, b })
}

/// ```prism
/// CondNames: unbounded fn Cond -> [Text]
/// ```
pub fn cond_names(cond0: &ast::Cond) -> Array<Text> {
    match cond0 {
        ast::Cond::CondBind(p_, _, _) => check_env::pattern_names(p_),
        ast::Cond::CondExpr(_) => Array::new(),
    }
}

/// The step machine of `CondNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondNames: unbounded fn Cond -> [Text]
/// ```
pub struct CondNames {
    pub cond0: ast::Cond,
}

impl prism_rtl::Job<Array<Text>> for CondNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cond0 = &self.cond0;
        match cond0 {
            ast::Cond::CondBind(p_, _, _) => prism_rtl::Turn::More(Rc::new(check_env::PatternNames { p_: p_.clone() })),
            ast::Cond::CondExpr(_) => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start CondNames, x`: what the function value is when passed to `@Run`.
pub fn start_cond_names(cond0: ast::Cond) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(CondNames { cond0 })
}

/// ```prism
/// Part: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
/// ```
pub fn part(m: &Map<Text, Rel>, i: &Nat, e: &ast::Expr) -> bool {
    match &*e.kind {
        ast::ExprKind::ETuple(es) => run_to_end(fold_job(es.clone(), true, {
            let m = m.clone();
            let i = i.clone();
            Rc::new(move |(p0, p1): (bool, ast::Expr)| {
                let m = m.clone();
                let i = i.clone();
                entered(once_job(move || {
                    let ok = p0;
                    let x = p1;
                    prism_rtl::Turn::Finished(ok && part(&m, &i, &x))
                }))
            }) as Rc<dyn Fn((bool, ast::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        ast::ExprKind::EGroup(x) => part(m, i, &**x),
        _ => match rel_of(m, e) {
            Some(r) => (&r.param == i) && r.strict,
            None => false,
        },
    }
}

/// The step machine of `Part`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Part: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
/// ```
pub struct Part {
    pub m: Map<Text, Rel>,
    pub i: Nat,
    pub e: ast::Expr,
}

impl prism_rtl::Job<bool> for Part {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let m = &self.m;
        let i = &self.i;
        let e = &self.e;
        match &*e.kind {
            ast::ExprKind::ETuple(es) => fold_job(es.clone(), true, {
                let m = m.clone();
                let i = i.clone();
                Rc::new(move |(p0, p1): (bool, ast::Expr)| {
                    let m = m.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let ok = p0;
                        let x = p1;
                        prism_rtl::Turn::Finished(ok && part(&m, &i, &x))
                    }))
                }) as Rc<dyn Fn((bool, ast::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            ast::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(Part { m: m.clone(), i: i.clone(), e: (**x).clone() })),
            _ => {
                let e = e.clone();
                let i = i.clone();
                let m = m.clone();
                call_then(start_rel_of(m.clone(), e.clone()), move |rel_of_106770: Option<Rel>| match rel_of_106770 {
                    Some(r) => prism_rtl::Turn::Finished((&r.param == &i) && r.strict),
                    None => prism_rtl::Turn::Finished(false),
                })
            },
        }
    }
}

/// `Start Part, x`: what the function value is when passed to `@Run`.
pub fn start_part(m: Map<Text, Rel>, i: Nat, e: ast::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(Part { m, i, e })
}

/// ```prism
/// SummarySeeds: unbounded fn Shrink, Def, [Spot], (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn summary_seeds(sk: &Shrink, d: &check_env::Def, spots: &Array<Spot>, rels: &Map<Text, Rel>) -> Map<Text, Rel> {
    fold(&run_to_end(fold_job(spots.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Site>, Spot)| entered(once_job(move || {
        let acc = p0;
        let sp = p1;
        call_then(start_spot_sites(sp.clone()), move |spot_sites_107446: Array<Site>| prism_rtl::Turn::Finished(append(&acc, &spot_sites_107446)))
    }))) as Rc<dyn Fn((Array<Site>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Site>>>>)), rels, &(|m: &Map<Text, Rel>, site: &Site| if is_local(&site.rels, &site.callee) {
        m.clone()
    } else {
        match resolve_callee(&sk.g, &d.home, &site.callee) {
            Some(k) => match get(&sk.sums, &k) {
                Some(i) => insert(m, &Text::from(format!("fn:{}", &site.callee)), &Rel { param: i.clone(), strict: false }),
                None => if is_no_larger_prelude(&sk.g, &k) {
                    insert(m, &Text::from(format!("fn:{}", &site.callee)), &Rel { param: Nat::from(0u32), strict: false })
                } else {
                    m.clone()
                },
            },
            None => m.clone(),
        }
    }))
}

/// The step machine of `SummarySeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SummarySeeds: unbounded fn Shrink, Def, [Spot], (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub struct SummarySeeds {
    pub sk: Shrink,
    pub d: check_env::Def,
    pub spots: Array<Spot>,
    pub rels: Map<Text, Rel>,
}

impl prism_rtl::Job<Map<Text, Rel>> for SummarySeeds {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Rel>> {
        let sk = &self.sk;
        let d = &self.d;
        let spots = &self.spots;
        let rels = &self.rels;
        let d = d.clone();
        let rels = rels.clone();
        let sk = sk.clone();
        let spots = spots.clone();
        call_value(fold_job(spots.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<Site>, Spot)| entered(once_job(move || {
            let acc = p0;
            let sp = p1;
            call_then(start_spot_sites(sp.clone()), move |spot_sites_107446: Array<Site>| prism_rtl::Turn::Finished(append(&acc, &spot_sites_107446)))
        }))) as Rc<dyn Fn((Array<Site>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Site>>>>), move |fold_107404: Array<Site>| prism_rtl::Turn::Finished(fold(&fold_107404, &rels, &(|m: &Map<Text, Rel>, site: &Site| if is_local(&site.rels, &site.callee) {
            m.clone()
        } else {
            match resolve_callee(&sk.g, &d.home, &site.callee) {
                Some(k) => match get(&sk.sums, &k) {
                    Some(i) => insert(m, &Text::from(format!("fn:{}", &site.callee)), &Rel { param: i.clone(), strict: false }),
                    None => if is_no_larger_prelude(&sk.g, &k) {
                        insert(m, &Text::from(format!("fn:{}", &site.callee)), &Rel { param: Nat::from(0u32), strict: false })
                    } else {
                        m.clone()
                    },
                },
                None => m.clone(),
            }
        }))))
    }
}

/// `Start SummarySeeds, x`: what the function value is when passed to `@Run`.
pub fn start_summary_seeds(sk: Shrink, d: check_env::Def, spots: Array<Spot>, rels: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<Map<Text, Rel>>> {
    Rc::new(SummarySeeds { sk, d, spots, rels })
}

/// ```prism
/// OptNames: unbounded fn ?Pattern -> [Text]
/// ```
pub fn opt_names(opt0: &Option<ast::Pattern_>) -> Array<Text> {
    match opt0 {
        Some(p_) => check_env::pattern_names(p_),
        None => Array::new(),
    }
}

/// The step machine of `OptNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptNames: unbounded fn ?Pattern -> [Text]
/// ```
pub struct OptNames {
    pub opt0: Option<ast::Pattern_>,
}

impl prism_rtl::Job<Array<Text>> for OptNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let opt0 = &self.opt0;
        match opt0 {
            Some(p_) => prism_rtl::Turn::More(Rc::new(check_env::PatternNames { p_: p_.clone() })),
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start OptNames, x`: what the function value is when passed to `@Run`.
pub fn start_opt_names(opt0: Option<ast::Pattern_>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(OptNames { opt0 })
}

/// ```prism
/// let dummyArg
/// ```
pub fn dummy_arg() -> ast::Arg {
    ast::Arg { name: None, value: ast::Expr { kind: Rc::new(ast::ExprKind::EError), span: ast::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }, span: ast::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// ?DecrementOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
/// ```
pub fn decrement_of(m: &Map<Text, Rel>, e: &ast::Expr) -> Option<Rel> {
    match &*e.kind {
        ast::ExprKind::EBinary(m108254_0_0, l, r) if (m108254_0_0 == &Text::from("-?")) => if is_positive_lit(&**r) && is_nat_minus(m, e) { smaller(m, &**l) } else { None },
        ast::ExprKind::EGroup(x) => decrement_of(m, &**x),
        _ => match call_of(e) {
            Some((c, args)) => match callee_name(&c) {
                Some(n) => if pre_is(m, &n, &Text::from("?Step")) {
                    smaller(m, &or(&index(&args, &Nat::from(0u32)), &dummy_arg()).value)
                } else {
                    None
                },
                None => None,
            },
            None => None,
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `DecrementOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?DecrementOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
/// ```
pub struct DecrementOf {
    pub m: Map<Text, Rel>,
    pub e: ast::Expr,
}

impl prism_rtl::Job<Option<Rel>> for DecrementOf {
    fn cycle(&self) -> prism_rtl::Turn<Option<Rel>> {
        let m = &self.m;
        let e = &self.e;
        match &*e.kind {
            ast::ExprKind::EBinary(m108254_0_0, l, r) if (m108254_0_0 == &Text::from("-?")) => if is_positive_lit(&**r) && is_nat_minus(m, e) {
                prism_rtl::Turn::Finished(smaller(m, &**l))
            } else {
                prism_rtl::Turn::Finished(None)
            },
            ast::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(DecrementOf { m: m.clone(), e: (**x).clone() })),
            _ => match call_of(e) {
                Some((c, args)) => match callee_name(&c) {
                    Some(n) => if pre_is(m, &n, &Text::from("?Step")) {
                        prism_rtl::Turn::Finished(smaller(m, &or(&index(&args, &Nat::from(0u32)), &dummy_arg()).value))
                    } else {
                        prism_rtl::Turn::Finished(None)
                    },
                    None => prism_rtl::Turn::Finished(None),
                },
                None => prism_rtl::Turn::Finished(None),
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start DecrementOf, x`: what the function value is when passed to `@Run`.
pub fn start_decrement_of(m: Map<Text, Rel>, e: ast::Expr) -> Rc<dyn prism_rtl::Job<Option<Rel>>> {
    Rc::new(DecrementOf { m, e })
}

/// ```prism
/// IsNatMinus: fn (Text ==> Rel), Expr -> Bool
/// ```
pub fn is_nat_minus(m: &Map<Text, Rel>, e: &ast::Expr) -> bool {
    pre_is(m, &Text::from("-?"), &Text::from("-?")) && is_nat_at(m, e)
}

/// ```prism
/// ?Smaller: unbounded fn (Text ==> Rel), Expr -> ?Rel
/// ```
pub fn smaller(m: &Map<Text, Rel>, x: &ast::Expr) -> Option<Rel> {
    match rel_of(m, x) {
        Some(r) => Some(Rel { param: r.param.clone(), strict: true }),
        None => None,
    }
}

/// ```prism
/// IsPositiveLit: fn Expr -> Bool
/// ```
pub fn is_positive_lit(e: &ast::Expr) -> bool {
    match &*e.kind {
        ast::ExprKind::ELit(l) => match &l.kind {
            ast::LitKind::LInt(d) => d != &Text::from("0"),
            _ => false,
        },
        ast::ExprKind::EGroup(x) => is_positive_lit(&**x),
        _ => false,
    }
}

/// ```prism
/// Closure: unbounded fn [Sc] -> [Sc]
/// ```
pub fn closure(graphs: &Array<Sc>) -> Array<Sc> {
    closure_from(graphs, &dedup(graphs), &dedup(graphs))
}

/// The step machine of `Closure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Closure: unbounded fn [Sc] -> [Sc]
/// ```
pub struct Closure {
    pub graphs: Array<Sc>,
}

impl prism_rtl::Job<Array<Sc>> for Closure {
    fn cycle(&self) -> prism_rtl::Turn<Array<Sc>> {
        let graphs = &self.graphs;
        prism_rtl::Turn::More(Rc::new(ClosureFrom { base: graphs.clone(), acc: dedup(graphs), frontier: dedup(graphs) }))
    }
}

/// `Start Closure, x`: what the function value is when passed to `@Run`.
pub fn start_closure(graphs: Array<Sc>) -> Rc<dyn prism_rtl::Job<Array<Sc>>> {
    Rc::new(Closure { graphs })
}

/// ```prism
/// Dedup: fn [Sc] -> [Sc]
/// ```
pub fn dedup(gs: &Array<Sc>) -> Array<Sc> {
    fold(gs, &Array::new(), &(|acc: &Array<Sc>, g: &Sc| if has_sc(acc, g) { acc.clone() } else { push(acc, g) }))
}

/// ```prism
/// ClosureFrom: unbounded fn [Sc], [Sc], [Sc] -> [Sc]
/// ```
pub fn closure_from(base: &Array<Sc>, acc: &Array<Sc>, frontier: &Array<Sc>) -> Array<Sc> {
    let fresh = fold(frontier, &Array::new(), &(|out: &Array<Sc>, a: &Sc| fold(base, out, &(|out2: &Array<Sc>, b: &Sc| add_composed(acc, out2, a, b)))));
    if &len(&fresh) == &Nat::from(0u32) {
        acc.clone()
    } else {
        closure_from(base, &append(acc, &fresh), &fresh)
    }
}

/// The step machine of `ClosureFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosureFrom: unbounded fn [Sc], [Sc], [Sc] -> [Sc]
/// ```
pub struct ClosureFrom {
    pub base: Array<Sc>,
    pub acc: Array<Sc>,
    pub frontier: Array<Sc>,
}

impl prism_rtl::Job<Array<Sc>> for ClosureFrom {
    fn cycle(&self) -> prism_rtl::Turn<Array<Sc>> {
        let base = &self.base;
        let acc = &self.acc;
        let frontier = &self.frontier;
        let fresh = fold(frontier, &Array::new(), &(|out: &Array<Sc>, a: &Sc| fold(base, out, &(|out2: &Array<Sc>, b: &Sc| add_composed(acc, out2, a, b)))));
        if &len(&fresh) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished(acc.clone())
        } else {
            prism_rtl::Turn::More(Rc::new(ClosureFrom { base: base.clone(), acc: append(acc, &fresh), frontier: fresh.clone() }))
        }
    }
}

/// `Start ClosureFrom, x`: what the function value is when passed to `@Run`.
pub fn start_closure_from(base: Array<Sc>, acc: Array<Sc>, frontier: Array<Sc>) -> Rc<dyn prism_rtl::Job<Array<Sc>>> {
    Rc::new(ClosureFrom { base, acc, frontier })
}

/// ```prism
/// AddComposed: fn [Sc], [Sc], Sc, Sc -> [Sc]
/// ```
pub fn add_composed(acc: &Array<Sc>, out: &Array<Sc>, a: &Sc, b: &Sc) -> Array<Sc> {
    if &a.callee != &b.caller {
        out.clone()
    } else {
        {
            let c = compose(a, b);
            if has_sc(acc, &c) || has_sc(out, &c) { out.clone() } else { push(out, &c) }
        }
    }
}

/// ```prism
/// HasSc: fn [Sc], Sc -> Bool
/// ```
pub fn has_sc(xs: &Array<Sc>, c: &Sc) -> bool {
    fold(xs, &false, &(|seen: &bool, x: &Sc| *seen || (((&x.caller == &c.caller) && (&x.callee == &c.callee)) && (&x.edges == &c.edges))))
}

/// ```prism
/// Compose: fn Sc, Sc -> Sc
/// ```
pub fn compose(a: &Sc, b: &Sc) -> Sc {
    let pairs = fold(&a.edges, &Array::new(), &(|acc: &Array<(Nat, Nat, bool)>, (x, y, s1): &(Nat, Nat, bool)| fold(&b.edges, acc, &(|acc2: &Array<(Nat, Nat, bool)>, (y2, z, s2): &(Nat, Nat, bool)| if y == y2 { add_edge(acc2, x, z, &(*s1 || *s2)) } else { acc2.clone() }))));
    Sc { caller: a.caller.clone(), callee: b.callee.clone(), edges: sort_edges(&pairs), span: a.span.clone(), file: a.file.clone(), arg: a.arg.clone() }
}

/// ```prism
/// AddEdge: fn [((Nat, Nat, Bool))], Nat, Nat, Bool -> [((Nat, Nat, Bool))]
/// ```
pub fn add_edge(es: &Array<(Nat, Nat, bool)>, x: &Nat, z: &Nat, s: &bool) -> Array<(Nat, Nat, bool)> {
    let others = filter(es, &(|(a, b, _): &(Nat, Nat, bool)| !((a == x) && (b == z))));
    let had = fold(es, &false, &(|seen: &bool, (a, b, t): &(Nat, Nat, bool)| *seen || (((a == x) && (b == z)) && *t)));
    push(&others, &(x.clone(), z.clone(), *s || had))
}

/// ```prism
/// SortEdges: fn [((Nat, Nat, Bool))] -> [((Nat, Nat, Bool))]
/// ```
pub fn sort_edges(es: &Array<(Nat, Nat, bool)>) -> Array<(Nat, Nat, bool)> {
    fold(es, &Array::new(), &(|acc: &Array<(Nat, Nat, bool)>, e: &(Nat, Nat, bool)| append(&push(&filter(acc, &(|x: &(Nat, Nat, bool)| edge_before(x, e))), e), &filter(acc, &(|x: &(Nat, Nat, bool)| !edge_before(x, e))))))
}

/// ```prism
/// EdgeBefore: fn ((Nat, Nat, Bool)), ((Nat, Nat, Bool)) -> Bool
/// ```
pub fn edge_before(arg0: &(Nat, Nat, bool), arg1: &(Nat, Nat, bool)) -> bool {
    match (arg0, arg1) {
        ((a1, b1, _), (a2, b2, _)) => (a1 < a2) || ((a1 == a2) && (b1 < b2)),
    }
}

/// ```prism
/// LoopsOf: unbounded fn Shrink, St, Def -> St
/// ```
pub fn loops_of(sk: &Shrink, st: &check_types::St, d: &check_env::Def) -> check_types::St {
    let unb = is_unbounded_key(&sk.g, &sig_key_of(sk, &d.qk));
    if unb && !st.recording {
        st.clone()
    } else {
        {
            let s0 = {
                let mut this: check_types::St = st.clone();
                this.file = d.file.clone();
                this
            };
            let s1 = run_to_end(fold_job(def_clauses(d), s0.clone(), {
                let sk = sk.clone();
                let d = d.clone();
                let unb = unb;
                Rc::new(move |(p0, p1): (check_types::St, ast::FnClause)| {
                    let sk = sk.clone();
                    let d = d.clone();
                    let unb = unb;
                    entered(once_job(move || {
                        let s = p0;
                        let c = p1;
                        prism_rtl::Turn::More(Rc::new(ClauseLoops { sk: sk.clone(), st: s.clone(), d: d.clone(), c: c.clone(), unb }))
                    }))
                }) as Rc<dyn Fn((check_types::St, ast::FnClause)) -> Rc<dyn prism_rtl::Job<check_types::St>>>
            }));
            {
                let mut this: check_types::St = s1.clone();
                this.file = st.file.clone();
                this
            }
        }
    }
}

/// The step machine of `LoopsOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LoopsOf: unbounded fn Shrink, St, Def -> St
/// ```
pub struct LoopsOf {
    pub sk: Shrink,
    pub st: check_types::St,
    pub d: check_env::Def,
}

impl prism_rtl::Job<check_types::St> for LoopsOf {
    fn cycle(&self) -> prism_rtl::Turn<check_types::St> {
        let sk = &self.sk;
        let st = &self.st;
        let d = &self.d;
        let unb = is_unbounded_key(&sk.g, &sig_key_of(sk, &d.qk));
        if unb && !st.recording {
            prism_rtl::Turn::Finished(st.clone())
        } else {
            {
                let s0 = {
                    let mut this: check_types::St = st.clone();
                    this.file = d.file.clone();
                    this
                };
                let d = d.clone();
                let sk = sk.clone();
                let st = st.clone();
                call_value(fold_job(def_clauses(&d), s0.clone(), {
                    let sk = sk.clone();
                    let d = d.clone();
                    let unb = unb;
                    Rc::new(move |(p0, p1): (check_types::St, ast::FnClause)| {
                        let sk = sk.clone();
                        let d = d.clone();
                        let unb = unb;
                        entered(once_job(move || {
                            let s = p0;
                            let c = p1;
                            prism_rtl::Turn::More(Rc::new(ClauseLoops { sk: sk.clone(), st: s.clone(), d: d.clone(), c: c.clone(), unb }))
                        }))
                    }) as Rc<dyn Fn((check_types::St, ast::FnClause)) -> Rc<dyn prism_rtl::Job<check_types::St>>>
                }), move |fold_112225: check_types::St| {
                    let s1 = fold_112225;
                    prism_rtl::Turn::Finished({
                        let mut this: check_types::St = s1.clone();
                        this.file = st.file.clone();
                        this
                    })
                })
            }
        }
    }
}

/// `Start LoopsOf, x`: what the function value is when passed to `@Run`.
pub fn start_loops_of(sk: Shrink, st: check_types::St, d: check_env::Def) -> Rc<dyn prism_rtl::Job<check_types::St>> {
    Rc::new(LoopsOf { sk, st, d })
}

/// ```prism
/// ClauseLoops: unbounded fn Shrink, St, Def, FnClause, Bool -> St
/// ```
pub fn clause_loops(sk: &Shrink, st: &check_types::St, d: &check_env::Def, c: &ast::FnClause, unb: &bool) -> check_types::St {
    let base = clause_base(sk, d, c);
    let spots0 = body_spots(&c.body, &base);
    if !fold(&spots0, &false, &(|seen: &bool, sp: &Spot| *seen || is_while_spot(sp))) {
        st.clone()
    } else {
        {
            let spots = body_spots(&c.body, &summary_seeds(sk, d, &spots0, &base));
            run_to_end(fold_job(filter(&spots, &(|sp: &Spot| is_while_spot(sp))), st.clone(), {
                let d = d.clone();
                let unb = *unb;
                Rc::new(move |(p0, p1): (check_types::St, Spot)| {
                    let d = d.clone();
                    let unb = unb;
                    entered(once_job(move || {
                        let s = p0;
                        let sp = p1;
                        match &sp {
                            Spot::SpotStmt(w, m) => match &w.kind {
                                ast::StmtKind::SWhile(cond, body) => prism_rtl::Turn::More(Rc::new(CheckWhile { st: s.clone(), c: cond.clone(), body: body.clone(), span: w.span.clone(), name: d.name.clone(), seeds: marks(m), unb })),
                                _ => prism_rtl::Turn::Finished(s.clone()),
                            },
                            _ => prism_rtl::Turn::Finished(s.clone()),
                        }
                    }))
                }) as Rc<dyn Fn((check_types::St, Spot)) -> Rc<dyn prism_rtl::Job<check_types::St>>>
            }))
        }
    }
}

/// The step machine of `ClauseLoops`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseLoops: unbounded fn Shrink, St, Def, FnClause, Bool -> St
/// ```
pub struct ClauseLoops {
    pub sk: Shrink,
    pub st: check_types::St,
    pub d: check_env::Def,
    pub c: ast::FnClause,
    pub unb: bool,
}

impl prism_rtl::Job<check_types::St> for ClauseLoops {
    fn cycle(&self) -> prism_rtl::Turn<check_types::St> {
        let sk = &self.sk;
        let st = &self.st;
        let d = &self.d;
        let c = &self.c;
        let unb = &self.unb;
        let c = c.clone();
        let d = d.clone();
        let sk = sk.clone();
        let st = st.clone();
        let unb = *unb;
        call_then(start_clause_base(sk.clone(), d.clone(), c.clone()), move |clause_base_112451: Map<Text, Rel>| {
            let base = clause_base_112451;
            call_then(start_body_spots(c.body.clone(), base.clone()), move |body_spots_112488: Array<Spot>| {
                let spots0 = body_spots_112488;
                if !fold(&spots0, &false, &(|seen: &bool, sp: &Spot| *seen || is_while_spot(sp))) {
                    prism_rtl::Turn::Finished(st.clone())
                } else {
                    call_then(start_summary_seeds(sk.clone(), d.clone(), spots0.clone(), base.clone()), move |summary_seeds_112632: Map<Text, Rel>| call_then(start_body_spots(c.body.clone(), summary_seeds_112632), move |body_spots_112613: Array<Spot>| {
                        let spots = body_spots_112613;
                        fold_job(filter(&spots, &(|sp: &Spot| is_while_spot(sp))), st.clone(), {
                            let d = d.clone();
                            let unb = unb;
                            Rc::new(move |(p0, p1): (check_types::St, Spot)| {
                                let d = d.clone();
                                let unb = unb;
                                entered(once_job(move || {
                                    let s = p0;
                                    let sp = p1;
                                    match &sp {
                                        Spot::SpotStmt(w, m) => match &w.kind {
                                            ast::StmtKind::SWhile(cond, body) => prism_rtl::Turn::More(Rc::new(CheckWhile { st: s.clone(), c: cond.clone(), body: body.clone(), span: w.span.clone(), name: d.name.clone(), seeds: marks(m), unb })),
                                            _ => prism_rtl::Turn::Finished(s.clone()),
                                        },
                                        _ => prism_rtl::Turn::Finished(s.clone()),
                                    }
                                }))
                            }) as Rc<dyn Fn((check_types::St, Spot)) -> Rc<dyn prism_rtl::Job<check_types::St>>>
                        }).cycle()
                    }))
                }
            })
        })
    }
}

/// `Start ClauseLoops, x`: what the function value is when passed to `@Run`.
pub fn start_clause_loops(sk: Shrink, st: check_types::St, d: check_env::Def, c: ast::FnClause, unb: bool) -> Rc<dyn prism_rtl::Job<check_types::St>> {
    Rc::new(ClauseLoops { sk, st, d, c, unb })
}

/// ```prism
/// Marks: fn (Text ==> Rel) -> (Text ==> Rel)
/// ```
pub fn marks(m: &Map<Text, Rel>) -> Map<Text, Rel> {
    fold(&keys(m), m, &(|m2: &Map<Text, Rel>, k: &Text| if lexer::contains(k, &Text::from(":")) { m2.clone() } else { remove(m2, k) }))
}

/// ```prism
/// IsWhileSpot: fn Spot -> Bool
/// ```
pub fn is_while_spot(spot0: &Spot) -> bool {
    match spot0 {
        Spot::SpotStmt(s, _) => match &s.kind {
            ast::StmtKind::SWhile(_, _) => true,
            _ => false,
        },
        Spot::SpotExpr(_, _) => false,
    }
}

/// ```prism
/// CheckWhile: unbounded fn St, Cond, Block, Range, Text, (Text ==> Rel), Bool -> St
/// ```
pub fn check_while(st: &check_types::St, c: &ast::Cond, body: &ast::Block, span: &ast::Range, name: &Text, seeds: &Map<Text, Rel>, unb: &bool) -> check_types::St {
    let vars = set_targets(&body.stmts);
    let base = fold(&check_errors::range0(&len(&vars)), seeds, &(|m: &Map<Text, Rel>, i: &Nat| insert(m, &or(&index(&vars, i), &Text::from("")), &Rel { param: i.clone(), strict: false })));
    let rels = cond_rels(c, &base);
    let ok = run_to_end(fold_job(check_errors::range0(&len(&vars)), false, {
        let body = body.clone();
        let vars = vars.clone();
        let rels = rels.clone();
        Rc::new(move |(p0, p1): (bool, Nat)| {
            let body = body.clone();
            let vars = vars.clone();
            let rels = rels.clone();
            entered(once_job(move || {
                let seen = p0;
                let i = p1;
                prism_rtl::Turn::Finished(seen || all_paths_strict(&body.stmts, &or(&index(&vars, &i), &Text::from("")), &i, &rels))
            }))
        }) as Rc<dyn Fn((bool, Nat)) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    if ok {
        st.clone()
    } else {
        if *unb {
            note_unshrunk(st, span)
        } else {
            check_types::err_fix(st, &Text::from("may-not-end"), span, &Text::from(format!("this loop in `{}` may not end: nothing it sets gets smaller on every turn", name)), &Text::from(format!("set a local from `&x -? 1` through a pattern, as `while ? left <- &fuel -? 1:`, or mark `{}` `unbounded fn`", name)))
        }
    }
}

/// The step machine of `CheckWhile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckWhile: unbounded fn St, Cond, Block, Range, Text, (Text ==> Rel), Bool -> St
/// ```
pub struct CheckWhile {
    pub st: check_types::St,
    pub c: ast::Cond,
    pub body: ast::Block,
    pub span: ast::Range,
    pub name: Text,
    pub seeds: Map<Text, Rel>,
    pub unb: bool,
}

impl prism_rtl::Job<check_types::St> for CheckWhile {
    fn cycle(&self) -> prism_rtl::Turn<check_types::St> {
        let st = &self.st;
        let c = &self.c;
        let body = &self.body;
        let span = &self.span;
        let name = &self.name;
        let seeds = &self.seeds;
        let unb = &self.unb;
        let body = body.clone();
        let c = c.clone();
        let name = name.clone();
        let seeds = seeds.clone();
        let span = span.clone();
        let st = st.clone();
        let unb = *unb;
        call_then(start_set_targets(body.stmts.clone()), move |set_targets_113739: Array<Text>| {
            let vars = set_targets_113739;
            let base = fold(&check_errors::range0(&len(&vars)), &seeds, &(|m: &Map<Text, Rel>, i: &Nat| insert(m, &or(&index(&vars, i), &Text::from("")), &Rel { param: i.clone(), strict: false })));
            call_then(start_cond_rels(c.clone(), base.clone()), move |cond_rels_114053: Map<Text, Rel>| {
                let rels = cond_rels_114053;
                call_value(fold_job(check_errors::range0(&len(&vars)), false, {
                    let body = body.clone();
                    let vars = vars.clone();
                    let rels = rels.clone();
                    Rc::new(move |(p0, p1): (bool, Nat)| {
                        let body = body.clone();
                        let vars = vars.clone();
                        let rels = rels.clone();
                        entered(once_job(move || {
                            let seen = p0;
                            let i = p1;
                            prism_rtl::Turn::Finished(seen || all_paths_strict(&body.stmts, &or(&index(&vars, &i), &Text::from("")), &i, &rels))
                        }))
                    }) as Rc<dyn Fn((bool, Nat)) -> Rc<dyn prism_rtl::Job<bool>>>
                }), move |fold_114083: bool| {
                    let ok = fold_114083;
                    if ok {
                        prism_rtl::Turn::Finished(st.clone())
                    } else {
                        if unb {
                            prism_rtl::Turn::Finished(note_unshrunk(&st, &span))
                        } else {
                            prism_rtl::Turn::Finished(check_types::err_fix(&st, &Text::from("may-not-end"), &span, &Text::from(format!("this loop in `{}` may not end: nothing it sets gets smaller on every turn", &name)), &Text::from(format!("set a local from `&x -? 1` through a pattern, as `while ? left <- &fuel -? 1:`, or mark `{}` `unbounded fn`", &name))))
                        }
                    }
                })
            })
        })
    }
}

/// `Start CheckWhile, x`: what the function value is when passed to `@Run`.
pub fn start_check_while(st: check_types::St, c: ast::Cond, body: ast::Block, span: ast::Range, name: Text, seeds: Map<Text, Rel>, unb: bool) -> Rc<dyn prism_rtl::Job<check_types::St>> {
    Rc::new(CheckWhile { st, c, body, span, name, seeds, unb })
}

/// ```prism
/// NoteUnshrunk: fn St, Range -> St
/// ```
pub fn note_unshrunk(st: &check_types::St, span: &ast::Range) -> check_types::St {
    let mut this: check_types::St = st.clone();
    this.typed.unshrunk = push(&this.typed.unshrunk, &check_types::at_here(st, span));
    this
}

/// ```prism
/// SetTargets: unbounded fn [Stmt] -> [Text]
/// ```
pub fn set_targets(stmts: &Array<ast::Stmt>) -> Array<Text> {
    run_to_end(fold_job(stmts_spots(stmts, &Map::new()), Array::new(), Rc::new(move |(p0, p1): (Array<Text>, Spot)| entered(once_job(move || {
        let acc = p0;
        let sp = p1;
        call_then(start_spot_set_root(sp.clone()), move |spot_set_root_114949: Array<Text>| prism_rtl::Turn::Finished(check_types::union_texts(&acc, &spot_set_root_114949)))
    }))) as Rc<dyn Fn((Array<Text>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))
}

/// The step machine of `SetTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SetTargets: unbounded fn [Stmt] -> [Text]
/// ```
pub struct SetTargets {
    pub stmts: Array<ast::Stmt>,
}

impl prism_rtl::Job<Array<Text>> for SetTargets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let stmts = &self.stmts;
        let stmts = stmts.clone();
        call_then(start_stmts_spots(stmts.clone(), Map::new()), move |stmts_spots_114892: Array<Spot>| fold_job(stmts_spots_114892, Array::new(), Rc::new(move |(p0, p1): (Array<Text>, Spot)| entered(once_job(move || {
            let acc = p0;
            let sp = p1;
            call_then(start_spot_set_root(sp.clone()), move |spot_set_root_114949: Array<Text>| prism_rtl::Turn::Finished(check_types::union_texts(&acc, &spot_set_root_114949)))
        }))) as Rc<dyn Fn((Array<Text>, Spot)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>).cycle())
    }
}

/// `Start SetTargets, x`: what the function value is when passed to `@Run`.
pub fn start_set_targets(stmts: Array<ast::Stmt>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SetTargets { stmts })
}

/// ```prism
/// SpotSetRoot: unbounded fn Spot -> [Text]
/// ```
pub fn spot_set_root(spot0: &Spot) -> Array<Text> {
    match spot0 {
        Spot::SpotStmt(s, _) => match &s.kind {
            ast::StmtKind::SSet(t, _) => take(&ref_path(t), &Nat::from(1u32)),
            ast::StmtKind::SAccum(t, _, _) => take(&ref_path(t), &Nat::from(1u32)),
            _ => Array::new(),
        },
        Spot::SpotExpr(_, _) => Array::new(),
    }
}

/// The step machine of `SpotSetRoot`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotSetRoot: unbounded fn Spot -> [Text]
/// ```
pub struct SpotSetRoot {
    pub spot0: Spot,
}

impl prism_rtl::Job<Array<Text>> for SpotSetRoot {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let spot0 = &self.spot0;
        match spot0 {
            Spot::SpotStmt(s, _) => match &s.kind {
                ast::StmtKind::SSet(t, _) => {
                    let t = t.clone();
                    call_then(start_ref_path(t.clone()), move |ref_path_115085: Array<Text>| prism_rtl::Turn::Finished(take(&ref_path_115085, &Nat::from(1u32))))
                },
                ast::StmtKind::SAccum(t, _, _) => {
                    let t = t.clone();
                    call_then(start_ref_path(t.clone()), move |ref_path_115135: Array<Text>| prism_rtl::Turn::Finished(take(&ref_path_115135, &Nat::from(1u32))))
                },
                _ => prism_rtl::Turn::Finished(Array::new()),
            },
            Spot::SpotExpr(_, _) => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start SpotSetRoot, x`: what the function value is when passed to `@Run`.
pub fn start_spot_set_root(spot0: Spot) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SpotSetRoot { spot0 })
}

/// ```prism
/// AllPathsStrict: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub fn all_paths_strict(stmts: &Array<ast::Stmt>, v_: &Text, vi: &Nat, outer: &Map<Text, Rel>) -> bool {
    let rels = block_rels(stmts, outer);
    run_to_end(fold_job(stmts.clone(), false, {
        let v_ = v_.clone();
        let vi = vi.clone();
        let rels = rels.clone();
        Rc::new(move |(p0, p1): (bool, ast::Stmt)| {
            let v_ = v_.clone();
            let vi = vi.clone();
            let rels = rels.clone();
            entered(once_job(move || {
                let ok = p0;
                let s = p1;
                match &s.kind {
                    ast::StmtKind::SSet(t, value) => {
                        let t = t.clone();
                        let value = value.clone();
                        call_then(start_ref_path(t.clone()), move |ref_path_115820: Array<Text>| if &ref_path_115820 == &Array::from(vec![v_.clone()]) {
                            if is_zero_lit(&value) {
                                prism_rtl::Turn::Finished(ok)
                            } else {
                                prism_rtl::Turn::More(Rc::new(SetsStrict { e: value.clone(), v_: v_.clone(), vi: vi.clone(), rels: rels.clone() }))
                            }
                        } else {
                            prism_rtl::Turn::Finished(ok && !stmt_sets_weak(&s, &v_, &vi, &rels))
                        })
                    },
                    ast::StmtKind::SExpr(e) => match &*e.kind {
                        ast::ExprKind::EIf(c, tb, eb_opt) => {
                            let eb_opt = eb_opt.clone();
                            let c = (**c).clone();
                            let tb = tb.clone();
                            call_then(start_cond_rels(c.clone(), rels.clone()), move |cond_rels_116045: Map<Text, Rel>| {
                                let tr = cond_rels_116045;
                                match &eb_opt {
                                    Some(b) => {
                                        let b = b.clone();
                                        call_then(start_all_paths_strict(tb.stmts.clone(), v_.clone(), vi.clone(), tr.clone()), move |all_paths_strict_116118: bool| if all_paths_strict_116118 && all_paths_strict(&b.stmts, &v_, &vi, &rels) {
                                            prism_rtl::Turn::Finished(true)
                                        } else {
                                            prism_rtl::Turn::Finished((ok && !sets_weak(&tb.stmts, &v_, &vi, &tr)) && !sets_weak(&b.stmts, &v_, &vi, &rels))
                                        })
                                    },
                                    None => prism_rtl::Turn::Finished(ok && !sets_weak(&tb.stmts, &v_, &vi, &tr)),
                                }
                            })
                        },
                        ast::ExprKind::EMatch(subj, arms) => {
                            let arms = arms.clone();
                            let subj = (**subj).clone();
                            call_value(fold_job(arms.clone(), true, {
                                let v_ = v_.clone();
                                let vi = vi.clone();
                                let subj = subj.clone();
                                let rels = rels.clone();
                                Rc::new(move |(p0, p1): (bool, ast::Arm)| {
                                    let v_ = v_.clone();
                                    let vi = vi.clone();
                                    let subj = subj.clone();
                                    let rels = rels.clone();
                                    entered(once_job(move || {
                                        let all_arms = p0;
                                        let a = p1;
                                        prism_rtl::Turn::Finished(all_arms && all_paths_strict(&a.body.stmts, &v_, &vi, &arm_pat_rels(&subj, &a, &rels)))
                                    }))
                                }) as Rc<dyn Fn((bool, ast::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
                            }), move |fold_116407: bool| if fold_116407 {
                                prism_rtl::Turn::Finished(true)
                            } else {
                                prism_rtl::Turn::Finished(ok && !run_to_end(fold_job(arms.clone(), false, {
                                    let v_ = v_.clone();
                                    let vi = vi.clone();
                                    let subj = subj.clone();
                                    let rels = rels.clone();
                                    Rc::new(move |(p0, p1): (bool, ast::Arm)| {
                                        let v_ = v_.clone();
                                        let vi = vi.clone();
                                        let subj = subj.clone();
                                        let rels = rels.clone();
                                        entered(once_job(move || {
                                            let any_arm = p0;
                                            let a = p1;
                                            prism_rtl::Turn::Finished(any_arm || sets_weak(&a.body.stmts, &v_, &vi, &arm_pat_rels(&subj, &a, &rels)))
                                        }))
                                    }) as Rc<dyn Fn((bool, ast::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
                                })))
                            })
                        },
                        _ => prism_rtl::Turn::Finished(ok && !stmt_sets_weak(&s, &v_, &vi, &rels)),
                    },
                    _ => prism_rtl::Turn::Finished(ok && !stmt_sets_weak(&s, &v_, &vi, &rels)),
                }
            }))
        }) as Rc<dyn Fn((bool, ast::Stmt)) -> Rc<dyn prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `AllPathsStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AllPathsStrict: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub struct AllPathsStrict {
    pub stmts: Array<ast::Stmt>,
    pub v_: Text,
    pub vi: Nat,
    pub outer: Map<Text, Rel>,
}

impl prism_rtl::Job<bool> for AllPathsStrict {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let stmts = &self.stmts;
        let v_ = &self.v_;
        let vi = &self.vi;
        let outer = &self.outer;
        let outer = outer.clone();
        let stmts = stmts.clone();
        let v_ = v_.clone();
        let vi = vi.clone();
        call_then(start_block_rels(stmts.clone(), outer.clone()), move |block_rels_115712: Map<Text, Rel>| {
            let rels = block_rels_115712;
            fold_job(stmts.clone(), false, {
                let v_ = v_.clone();
                let vi = vi.clone();
                let rels = rels.clone();
                Rc::new(move |(p0, p1): (bool, ast::Stmt)| {
                    let v_ = v_.clone();
                    let vi = vi.clone();
                    let rels = rels.clone();
                    entered(once_job(move || {
                        let ok = p0;
                        let s = p1;
                        match &s.kind {
                            ast::StmtKind::SSet(t, value) => {
                                let t = t.clone();
                                let value = value.clone();
                                call_then(start_ref_path(t.clone()), move |ref_path_115820: Array<Text>| if &ref_path_115820 == &Array::from(vec![v_.clone()]) {
                                    if is_zero_lit(&value) {
                                        prism_rtl::Turn::Finished(ok)
                                    } else {
                                        prism_rtl::Turn::More(Rc::new(SetsStrict { e: value.clone(), v_: v_.clone(), vi: vi.clone(), rels: rels.clone() }))
                                    }
                                } else {
                                    prism_rtl::Turn::Finished(ok && !stmt_sets_weak(&s, &v_, &vi, &rels))
                                })
                            },
                            ast::StmtKind::SExpr(e) => match &*e.kind {
                                ast::ExprKind::EIf(c, tb, eb_opt) => {
                                    let eb_opt = eb_opt.clone();
                                    let c = (**c).clone();
                                    let tb = tb.clone();
                                    call_then(start_cond_rels(c.clone(), rels.clone()), move |cond_rels_116045: Map<Text, Rel>| {
                                        let tr = cond_rels_116045;
                                        match &eb_opt {
                                            Some(b) => {
                                                let b = b.clone();
                                                call_then(start_all_paths_strict(tb.stmts.clone(), v_.clone(), vi.clone(), tr.clone()), move |all_paths_strict_116118: bool| if all_paths_strict_116118 && all_paths_strict(&b.stmts, &v_, &vi, &rels) {
                                                    prism_rtl::Turn::Finished(true)
                                                } else {
                                                    prism_rtl::Turn::Finished((ok && !sets_weak(&tb.stmts, &v_, &vi, &tr)) && !sets_weak(&b.stmts, &v_, &vi, &rels))
                                                })
                                            },
                                            None => prism_rtl::Turn::Finished(ok && !sets_weak(&tb.stmts, &v_, &vi, &tr)),
                                        }
                                    })
                                },
                                ast::ExprKind::EMatch(subj, arms) => {
                                    let arms = arms.clone();
                                    let subj = (**subj).clone();
                                    call_value(fold_job(arms.clone(), true, {
                                        let v_ = v_.clone();
                                        let vi = vi.clone();
                                        let subj = subj.clone();
                                        let rels = rels.clone();
                                        Rc::new(move |(p0, p1): (bool, ast::Arm)| {
                                            let v_ = v_.clone();
                                            let vi = vi.clone();
                                            let subj = subj.clone();
                                            let rels = rels.clone();
                                            entered(once_job(move || {
                                                let all_arms = p0;
                                                let a = p1;
                                                prism_rtl::Turn::Finished(all_arms && all_paths_strict(&a.body.stmts, &v_, &vi, &arm_pat_rels(&subj, &a, &rels)))
                                            }))
                                        }) as Rc<dyn Fn((bool, ast::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
                                    }), move |fold_116407: bool| if fold_116407 {
                                        prism_rtl::Turn::Finished(true)
                                    } else {
                                        prism_rtl::Turn::Finished(ok && !run_to_end(fold_job(arms.clone(), false, {
                                            let v_ = v_.clone();
                                            let vi = vi.clone();
                                            let subj = subj.clone();
                                            let rels = rels.clone();
                                            Rc::new(move |(p0, p1): (bool, ast::Arm)| {
                                                let v_ = v_.clone();
                                                let vi = vi.clone();
                                                let subj = subj.clone();
                                                let rels = rels.clone();
                                                entered(once_job(move || {
                                                    let any_arm = p0;
                                                    let a = p1;
                                                    prism_rtl::Turn::Finished(any_arm || sets_weak(&a.body.stmts, &v_, &vi, &arm_pat_rels(&subj, &a, &rels)))
                                                }))
                                            }) as Rc<dyn Fn((bool, ast::Arm)) -> Rc<dyn prism_rtl::Job<bool>>>
                                        })))
                                    })
                                },
                                _ => prism_rtl::Turn::Finished(ok && !stmt_sets_weak(&s, &v_, &vi, &rels)),
                            },
                            _ => prism_rtl::Turn::Finished(ok && !stmt_sets_weak(&s, &v_, &vi, &rels)),
                        }
                    }))
                }) as Rc<dyn Fn((bool, ast::Stmt)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle()
        })
    }
}

/// `Start AllPathsStrict, x`: what the function value is when passed to `@Run`.
pub fn start_all_paths_strict(stmts: Array<ast::Stmt>, v_: Text, vi: Nat, outer: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(AllPathsStrict { stmts, v_, vi, outer })
}

/// ```prism
/// SetsWeak: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub fn sets_weak(stmts: &Array<ast::Stmt>, v_: &Text, vi: &Nat, outer: &Map<Text, Rel>) -> bool {
    run_to_end(fold_job(stmts_spots(stmts, outer), false, {
        let v_ = v_.clone();
        let vi = vi.clone();
        Rc::new(move |(p0, p1): (bool, Spot)| {
            let v_ = v_.clone();
            let vi = vi.clone();
            entered(once_job(move || {
                let seen = p0;
                let sp = p1;
                prism_rtl::Turn::Finished(seen || spot_sets_weak(&sp, &v_, &vi))
            }))
        }) as Rc<dyn Fn((bool, Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `SetsWeak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SetsWeak: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub struct SetsWeak {
    pub stmts: Array<ast::Stmt>,
    pub v_: Text,
    pub vi: Nat,
    pub outer: Map<Text, Rel>,
}

impl prism_rtl::Job<bool> for SetsWeak {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let stmts = &self.stmts;
        let v_ = &self.v_;
        let vi = &self.vi;
        let outer = &self.outer;
        let outer = outer.clone();
        let stmts = stmts.clone();
        let v_ = v_.clone();
        let vi = vi.clone();
        call_then(start_stmts_spots(stmts.clone(), outer.clone()), move |stmts_spots_117054: Array<Spot>| fold_job(stmts_spots_117054, false, {
            let v_ = v_.clone();
            let vi = vi.clone();
            Rc::new(move |(p0, p1): (bool, Spot)| {
                let v_ = v_.clone();
                let vi = vi.clone();
                entered(once_job(move || {
                    let seen = p0;
                    let sp = p1;
                    prism_rtl::Turn::Finished(seen || spot_sets_weak(&sp, &v_, &vi))
                }))
            }) as Rc<dyn Fn((bool, Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
        }).cycle())
    }
}

/// `Start SetsWeak, x`: what the function value is when passed to `@Run`.
pub fn start_sets_weak(stmts: Array<ast::Stmt>, v_: Text, vi: Nat, outer: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(SetsWeak { stmts, v_, vi, outer })
}

/// ```prism
/// StmtSetsWeak: unbounded fn Stmt, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub fn stmt_sets_weak(s: &ast::Stmt, v_: &Text, vi: &Nat, rels: &Map<Text, Rel>) -> bool {
    run_to_end(fold_job(stmt_spots(s, rels), false, {
        let v_ = v_.clone();
        let vi = vi.clone();
        Rc::new(move |(p0, p1): (bool, Spot)| {
            let v_ = v_.clone();
            let vi = vi.clone();
            entered(once_job(move || {
                let seen = p0;
                let sp = p1;
                prism_rtl::Turn::Finished(seen || spot_sets_weak(&sp, &v_, &vi))
            }))
        }) as Rc<dyn Fn((bool, Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `StmtSetsWeak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtSetsWeak: unbounded fn Stmt, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub struct StmtSetsWeak {
    pub s: ast::Stmt,
    pub v_: Text,
    pub vi: Nat,
    pub rels: Map<Text, Rel>,
}

impl prism_rtl::Job<bool> for StmtSetsWeak {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let s = &self.s;
        let v_ = &self.v_;
        let vi = &self.vi;
        let rels = &self.rels;
        let rels = rels.clone();
        let s = s.clone();
        let v_ = v_.clone();
        let vi = vi.clone();
        call_then(start_stmt_spots(s.clone(), rels.clone()), move |stmt_spots_117237: Array<Spot>| fold_job(stmt_spots_117237, false, {
            let v_ = v_.clone();
            let vi = vi.clone();
            Rc::new(move |(p0, p1): (bool, Spot)| {
                let v_ = v_.clone();
                let vi = vi.clone();
                entered(once_job(move || {
                    let seen = p0;
                    let sp = p1;
                    prism_rtl::Turn::Finished(seen || spot_sets_weak(&sp, &v_, &vi))
                }))
            }) as Rc<dyn Fn((bool, Spot)) -> Rc<dyn prism_rtl::Job<bool>>>
        }).cycle())
    }
}

/// `Start StmtSetsWeak, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_sets_weak(s: ast::Stmt, v_: Text, vi: Nat, rels: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(StmtSetsWeak { s, v_, vi, rels })
}

/// ```prism
/// SpotSetsWeak: unbounded fn Spot, Text, Nat -> Bool
/// ```
pub fn spot_sets_weak(spot0: &Spot, text1: &Text, n2: &Nat) -> bool {
    match (spot0, text1, n2) {
        (Spot::SpotStmt(s, m), v_, vi) => match &s.kind {
            ast::StmtKind::SSet(t, value) => ((&take(&ref_path(t), &Nat::from(1u32)) == &Array::from(vec![v_.clone()])) && !sets_strict(value, v_, vi, m)) && !((&ref_path(t) == &Array::from(vec![v_.clone()])) && is_zero_lit(value)),
            ast::StmtKind::SAccum(t, _, _) => &take(&ref_path(t), &Nat::from(1u32)) == &Array::from(vec![v_.clone()]),
            _ => false,
        },
        (Spot::SpotExpr(_, _), _, _) => false,
    }
}

/// The step machine of `SpotSetsWeak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SpotSetsWeak: unbounded fn Spot, Text, Nat -> Bool
/// ```
pub struct SpotSetsWeak {
    pub spot0: Spot,
    pub text1: Text,
    pub n2: Nat,
}

impl prism_rtl::Job<bool> for SpotSetsWeak {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let spot0 = &self.spot0;
        let text1 = &self.text1;
        let n2 = &self.n2;
        match (spot0, text1, n2) {
            (Spot::SpotStmt(s, m), v_, vi) => match &s.kind {
                ast::StmtKind::SSet(t, value) => {
                    let m = m.clone();
                    let t = t.clone();
                    let v_ = v_.clone();
                    let value = value.clone();
                    let vi = vi.clone();
                    call_then(start_ref_path(t.clone()), move |ref_path_117440: Array<Text>| prism_rtl::Turn::Finished(((&take(&ref_path_117440, &Nat::from(1u32)) == &Array::from(vec![v_.clone()])) && !sets_strict(&value, &v_, &vi, &m)) && !((&ref_path(&t) == &Array::from(vec![v_.clone()])) && is_zero_lit(&value))))
                },
                ast::StmtKind::SAccum(t, _, _) => {
                    let t = t.clone();
                    let v_ = v_.clone();
                    call_then(start_ref_path(t.clone()), move |ref_path_117589: Array<Text>| prism_rtl::Turn::Finished(&take(&ref_path_117589, &Nat::from(1u32)) == &Array::from(vec![v_.clone()])))
                },
                _ => prism_rtl::Turn::Finished(false),
            },
            (Spot::SpotExpr(_, _), _, _) => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start SpotSetsWeak, x`: what the function value is when passed to `@Run`.
pub fn start_spot_sets_weak(spot0: Spot, text1: Text, n2: Nat) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(SpotSetsWeak { spot0, text1, n2 })
}

/// ```prism
/// IsZeroLit: fn Expr -> Bool
/// ```
pub fn is_zero_lit(e: &ast::Expr) -> bool {
    match &*e.kind {
        ast::ExprKind::ELit(l) => match &l.kind {
            ast::LitKind::LInt(d) => d == &Text::from("0"),
            _ => false,
        },
        ast::ExprKind::EGroup(x) => is_zero_lit(&**x),
        _ => false,
    }
}

/// ```prism
/// SetsStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub fn sets_strict(e: &ast::Expr, v_: &Text, vi: &Nat, rels: &Map<Text, Rel>) -> bool {
    match &*e.kind {
        ast::ExprKind::EGroup(x) => sets_strict(&**x, v_, vi, rels),
        ast::ExprKind::EBinary(m118966_1_0, l, _) if (m118966_1_0 == &Text::from("-?")) => is_nat_minus(rels, e) && sets_strict(&**l, v_, vi, rels),
        _ => rel_strict(rels, e, vi) || call_strict(e, v_, vi, rels),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `SetsStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SetsStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub struct SetsStrict {
    pub e: ast::Expr,
    pub v_: Text,
    pub vi: Nat,
    pub rels: Map<Text, Rel>,
}

impl prism_rtl::Job<bool> for SetsStrict {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let e = &self.e;
        let v_ = &self.v_;
        let vi = &self.vi;
        let rels = &self.rels;
        match &*e.kind {
            ast::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(SetsStrict { e: (**x).clone(), v_: v_.clone(), vi: vi.clone(), rels: rels.clone() })),
            ast::ExprKind::EBinary(m118966_1_0, l, _) if (m118966_1_0 == &Text::from("-?")) => prism_rtl::Turn::Finished(is_nat_minus(rels, e) && sets_strict(&**l, v_, vi, rels)),
            _ => {
                let e = e.clone();
                let rels = rels.clone();
                let v_ = v_.clone();
                let vi = vi.clone();
                call_then(start_rel_strict(rels.clone(), e.clone(), vi.clone()), move |rel_strict_119116: bool| prism_rtl::Turn::Finished(rel_strict_119116 || call_strict(&e, &v_, &vi, &rels)))
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start SetsStrict, x`: what the function value is when passed to `@Run`.
pub fn start_sets_strict(e: ast::Expr, v_: Text, vi: Nat, rels: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(SetsStrict { e, v_, vi, rels })
}

/// ```prism
/// RelStrict: unbounded fn (Text ==> Rel), Expr, Nat -> Bool
/// ```
pub fn rel_strict(rels: &Map<Text, Rel>, e: &ast::Expr, vi: &Nat) -> bool {
    match rel_of(rels, e) {
        Some(r) => r.strict && (&r.param == vi),
        None => false,
    }
}

/// The step machine of `RelStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RelStrict: unbounded fn (Text ==> Rel), Expr, Nat -> Bool
/// ```
pub struct RelStrict {
    pub rels: Map<Text, Rel>,
    pub e: ast::Expr,
    pub vi: Nat,
}

impl prism_rtl::Job<bool> for RelStrict {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let rels = &self.rels;
        let e = &self.e;
        let vi = &self.vi;
        let e = e.clone();
        let rels = rels.clone();
        let vi = vi.clone();
        call_then(start_rel_of(rels.clone(), e.clone()), move |rel_of_119262: Option<Rel>| match rel_of_119262 {
            Some(r) => prism_rtl::Turn::Finished(r.strict && (&r.param == &vi)),
            None => prism_rtl::Turn::Finished(false),
        })
    }
}

/// `Start RelStrict, x`: what the function value is when passed to `@Run`.
pub fn start_rel_strict(rels: Map<Text, Rel>, e: ast::Expr, vi: Nat) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(RelStrict { rels, e, vi })
}

/// ```prism
/// CallStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub fn call_strict(e: &ast::Expr, v_: &Text, vi: &Nat, rels: &Map<Text, Rel>) -> bool {
    match call_of(e) {
        Some((c, args)) => if is_non_nat_min(rels, e, &c) {
            false
        } else {
            match no_larger_arg(rels, &c, &args) {
                Some(a) => sets_strict(&a, v_, vi, rels),
                None => false,
            }
        },
        None => false,
    }
}

/// The step machine of `CallStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
/// ```
pub struct CallStrict {
    pub e: ast::Expr,
    pub v_: Text,
    pub vi: Nat,
    pub rels: Map<Text, Rel>,
}

impl prism_rtl::Job<bool> for CallStrict {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let e = &self.e;
        let v_ = &self.v_;
        let vi = &self.vi;
        let rels = &self.rels;
        match call_of(e) {
            Some((c, args)) => if is_non_nat_min(rels, e, &c) {
                prism_rtl::Turn::Finished(false)
            } else {
                match no_larger_arg(rels, &c, &args) {
                    Some(a) => prism_rtl::Turn::More(Rc::new(SetsStrict { e: a.clone(), v_: v_.clone(), vi: vi.clone(), rels: rels.clone() })),
                    None => prism_rtl::Turn::Finished(false),
                }
            },
            None => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start CallStrict, x`: what the function value is when passed to `@Run`.
pub fn start_call_strict(e: ast::Expr, v_: Text, vi: Nat, rels: Map<Text, Rel>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(CallStrict { e, v_, vi, rels })
}

/// ```prism
/// DischargeIncls: unbounded fn G, St, Nat -> St
/// ```
pub fn discharge_incls(g: &check_env::G, st: &check_types::St, from: &Nat) -> check_types::St {
    let batch = drop(&st.incls, from);
    run_to_end(fold_job(batch.clone(), st.clone(), {
        let g = g.clone();
        let batch = batch.clone();
        Rc::new(move |(p0, p1): (check_types::St, check_types::Incl)| {
            let g = g.clone();
            let batch = batch.clone();
            entered(once_job(move || {
                let s = p0;
                let inc = p1;
                call_then(start_through(s.clone(), inc.clone(), batch.clone()), move |through_120289: check_types::Incl| prism_rtl::Turn::More(Rc::new(DischargeOne { g: g.clone(), st: s.clone(), inc: through_120289 })))
            }))
        }) as Rc<dyn Fn((check_types::St, check_types::Incl)) -> Rc<dyn prism_rtl::Job<check_types::St>>>
    }))
}

/// The step machine of `DischargeIncls`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DischargeIncls: unbounded fn G, St, Nat -> St
/// ```
pub struct DischargeIncls {
    pub g: check_env::G,
    pub st: check_types::St,
    pub from: Nat,
}

impl prism_rtl::Job<check_types::St> for DischargeIncls {
    fn cycle(&self) -> prism_rtl::Turn<check_types::St> {
        let g = &self.g;
        let st = &self.st;
        let from = &self.from;
        let batch = drop(&st.incls, from);
        fold_job(batch.clone(), st.clone(), {
            let g = g.clone();
            let batch = batch.clone();
            Rc::new(move |(p0, p1): (check_types::St, check_types::Incl)| {
                let g = g.clone();
                let batch = batch.clone();
                entered(once_job(move || {
                    let s = p0;
                    let inc = p1;
                    call_then(start_through(s.clone(), inc.clone(), batch.clone()), move |through_120289: check_types::Incl| prism_rtl::Turn::More(Rc::new(DischargeOne { g: g.clone(), st: s.clone(), inc: through_120289 })))
                }))
            }) as Rc<dyn Fn((check_types::St, check_types::Incl)) -> Rc<dyn prism_rtl::Job<check_types::St>>>
        }).cycle()
    }
}

/// `Start DischargeIncls, x`: what the function value is when passed to `@Run`.
pub fn start_discharge_incls(g: check_env::G, st: check_types::St, from: Nat) -> Rc<dyn prism_rtl::Job<check_types::St>> {
    Rc::new(DischargeIncls { g, st, from })
}

/// ```prism
/// Through: unbounded fn St, Incl, [Incl] -> Incl
/// ```
pub fn through(st: &check_types::St, inc: &check_types::Incl, batch: &Array<check_types::Incl>) -> check_types::Incl {
    let sup = check_types::walk_row(st, &inc.sup);
    match &sup.tail {
        check_types::Tail::TlFlex(n) => if &len(&sup.fams) > &Nat::from(0u32) {
            inc.clone()
        } else {
            run_to_end(fold_job(batch.clone(), inc.clone(), {
                let st = st.clone();
                let n = n.clone();
                let inc = inc.clone();
                Rc::new(move |(p0, p1): (check_types::Incl, check_types::Incl)| {
                    let st = st.clone();
                    let n = n.clone();
                    let inc = inc.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let other = p1;
                        call_then(check_types::start_walk_row(st.clone(), other.sub.clone()), move |walk_row_120803: check_types::Rw| {
                            let sub = walk_row_120803;
                            if ((&len(&sub.fams) == &Nat::from(0u32)) && (&sub.tail == &check_types::Tail::TlFlex(n.clone()))) && (&other != &inc) {
                                prism_rtl::Turn::Finished({
                                    let mut this: check_types::Incl = acc.clone();
                                    this.sup = other.sup.clone();
                                    this
                                })
                            } else {
                                prism_rtl::Turn::Finished(acc.clone())
                            }
                        })
                    }))
                }) as Rc<dyn Fn((check_types::Incl, check_types::Incl)) -> Rc<dyn prism_rtl::Job<check_types::Incl>>>
            }))
        },
        _ => inc.clone(),
    }
}

/// The step machine of `Through`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Through: unbounded fn St, Incl, [Incl] -> Incl
/// ```
pub struct Through {
    pub st: check_types::St,
    pub inc: check_types::Incl,
    pub batch: Array<check_types::Incl>,
}

impl prism_rtl::Job<check_types::Incl> for Through {
    fn cycle(&self) -> prism_rtl::Turn<check_types::Incl> {
        let st = &self.st;
        let inc = &self.inc;
        let batch = &self.batch;
        let batch = batch.clone();
        let inc = inc.clone();
        let st = st.clone();
        call_then(check_types::start_walk_row(st.clone(), inc.sup.clone()), move |walk_row_120631: check_types::Rw| {
            let sup = walk_row_120631;
            match &sup.tail {
                check_types::Tail::TlFlex(n) => if &len(&sup.fams) > &Nat::from(0u32) {
                    prism_rtl::Turn::Finished(inc.clone())
                } else {
                    fold_job(batch.clone(), inc.clone(), {
                        let st = st.clone();
                        let n = n.clone();
                        let inc = inc.clone();
                        Rc::new(move |(p0, p1): (check_types::Incl, check_types::Incl)| {
                            let st = st.clone();
                            let n = n.clone();
                            let inc = inc.clone();
                            entered(once_job(move || {
                                let acc = p0;
                                let other = p1;
                                call_then(check_types::start_walk_row(st.clone(), other.sub.clone()), move |walk_row_120803: check_types::Rw| {
                                    let sub = walk_row_120803;
                                    if ((&len(&sub.fams) == &Nat::from(0u32)) && (&sub.tail == &check_types::Tail::TlFlex(n.clone()))) && (&other != &inc) {
                                        prism_rtl::Turn::Finished({
                                            let mut this: check_types::Incl = acc.clone();
                                            this.sup = other.sup.clone();
                                            this
                                        })
                                    } else {
                                        prism_rtl::Turn::Finished(acc.clone())
                                    }
                                })
                            }))
                        }) as Rc<dyn Fn((check_types::Incl, check_types::Incl)) -> Rc<dyn prism_rtl::Job<check_types::Incl>>>
                    }).cycle()
                },
                _ => prism_rtl::Turn::Finished(inc.clone()),
            }
        })
    }
}

/// `Start Through, x`: what the function value is when passed to `@Run`.
pub fn start_through(st: check_types::St, inc: check_types::Incl, batch: Array<check_types::Incl>) -> Rc<dyn prism_rtl::Job<check_types::Incl>> {
    Rc::new(Through { st, inc, batch })
}

/// ```prism
/// DischargeOne: unbounded fn G, St, Incl -> St
/// ```
pub fn discharge_one(g: &check_env::G, st: &check_types::St, inc: &check_types::Incl) -> check_types::St {
    let sub = check_types::walk_row(st, &inc.sub);
    let sup = check_types::walk_row(st, &inc.sup);
    let st1 = match &sub.tail {
        check_types::Tail::TlFlex(n) => close_tail(st, n),
        _ => st.clone(),
    };
    let sub2 = check_types::walk_row(&st1, &inc.sub);
    let left = filter(&sub2.fams, &(|f: &Text| !check_types::has_text(&sup.fams, f) && (&len(&tags_left(g, f, &sub2.minus)) > &Nat::from(0u32))));
    let tail_bad = match (sub2.tail.clone(), sup.tail.clone()) {
        (check_types::Tail::TlRigid(a), check_types::Tail::TlRigid(b)) => &a != &b,
        (check_types::Tail::TlRigid(_), _) => true,
        _ => false,
    };
    if (&len(&left) == &Nat::from(0u32)) && !tail_bad {
        st1.clone()
    } else {
        {
            let s0 = {
                let mut this: check_types::St = st1.clone();
                this.file = inc.file.clone();
                this
            };
            let tags = fold(&left, &Array::new(), &(|acc: &Array<Text>, f: &Text| append(acc, &tags_left(g, f, &sub2.minus))));
            let s1 = if inc.forward {
                check_types::err_fix(&s0, &Text::from("forwarding"), &inc.span, &Text::from(format!("forwarding {} from a scope that emits {}", &lexer::join(&tags, &Text::from(", ")), &check_types::show_row(&sup))), &Text::from(format!("answer {} above this arm, for example `{}(..): @ never`", &(if &len(&tags) == &Nat::from(1u32) { Text::from("it") } else { Text::from("them") }), &or(&index(&tags, &Nat::from(0u32)), &Text::from("")))))
            } else {
                check_types::err_fix(&s0, &Text::from("row-outside"), &inc.span, &Text::from(format!("a child that emits `{}` in a scope that emits `{}`", &check_types::show_row(&sub2), &check_types::show_row(&sup))), &Text::from("widen the scope's `emit` row, or host the child with `@HostDocument`"))
            };
            {
                let mut this: check_types::St = s1.clone();
                this.file = st1.file.clone();
                this
            }
        }
    }
}

/// The step machine of `DischargeOne`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DischargeOne: unbounded fn G, St, Incl -> St
/// ```
pub struct DischargeOne {
    pub g: check_env::G,
    pub st: check_types::St,
    pub inc: check_types::Incl,
}

impl prism_rtl::Job<check_types::St> for DischargeOne {
    fn cycle(&self) -> prism_rtl::Turn<check_types::St> {
        let g = &self.g;
        let st = &self.st;
        let inc = &self.inc;
        let g = g.clone();
        let inc = inc.clone();
        let st = st.clone();
        call_then(check_types::start_walk_row(st.clone(), inc.sub.clone()), move |walk_row_121122: check_types::Rw| {
            let sub = walk_row_121122;
            call_then(check_types::start_walk_row(st.clone(), inc.sup.clone()), move |walk_row_121156: check_types::Rw| {
                let sup = walk_row_121156;
                let st1 = match &sub.tail {
                    check_types::Tail::TlFlex(n) => close_tail(&st, n),
                    _ => st.clone(),
                };
                call_then(check_types::start_walk_row(st1.clone(), inc.sub.clone()), move |walk_row_121277: check_types::Rw| {
                    let sub2 = walk_row_121277;
                    let left = filter(&sub2.fams, &(|f: &Text| !check_types::has_text(&sup.fams, f) && (&len(&tags_left(&g, f, &sub2.minus)) > &Nat::from(0u32))));
                    let tail_bad = match (sub2.tail.clone(), sup.tail.clone()) {
                        (check_types::Tail::TlRigid(a), check_types::Tail::TlRigid(b)) => &a != &b,
                        (check_types::Tail::TlRigid(_), _) => true,
                        _ => false,
                    };
                    if (&len(&left) == &Nat::from(0u32)) && !tail_bad {
                        prism_rtl::Turn::Finished(st1.clone())
                    } else {
                        {
                            let s0 = {
                                let mut this: check_types::St = st1.clone();
                                this.file = inc.file.clone();
                                this
                            };
                            let tags = fold(&left, &Array::new(), &(|acc: &Array<Text>, f: &Text| append(acc, &tags_left(&g, f, &sub2.minus))));
                            let s1 = if inc.forward {
                                check_types::err_fix(&s0, &Text::from("forwarding"), &inc.span, &Text::from(format!("forwarding {} from a scope that emits {}", &lexer::join(&tags, &Text::from(", ")), &check_types::show_row(&sup))), &Text::from(format!("answer {} above this arm, for example `{}(..): @ never`", &(if &len(&tags) == &Nat::from(1u32) { Text::from("it") } else { Text::from("them") }), &or(&index(&tags, &Nat::from(0u32)), &Text::from("")))))
                            } else {
                                check_types::err_fix(&s0, &Text::from("row-outside"), &inc.span, &Text::from(format!("a child that emits `{}` in a scope that emits `{}`", &check_types::show_row(&sub2), &check_types::show_row(&sup))), &Text::from("widen the scope's `emit` row, or host the child with `@HostDocument`"))
                            };
                            prism_rtl::Turn::Finished({
                                let mut this: check_types::St = s1.clone();
                                this.file = st1.file.clone();
                                this
                            })
                        }
                    }
                })
            })
        })
    }
}

/// `Start DischargeOne, x`: what the function value is when passed to `@Run`.
pub fn start_discharge_one(g: check_env::G, st: check_types::St, inc: check_types::Incl) -> Rc<dyn prism_rtl::Job<check_types::St>> {
    Rc::new(DischargeOne { g, st, inc })
}

/// ```prism
/// TagsLeft: fn G, Text, [Text] -> [Text]
/// ```
pub fn tags_left(g: &check_env::G, fam: &Text, minus: &Array<Text>) -> Array<Text> {
    filter(&or(&get(&g.families, fam), &Array::new()), &(|t: &Text| !check_types::has_text(minus, t) && is_element_tag(g, t)))
}

/// ```prism
/// IsElementTag: fn G, Text -> Bool
/// ```
pub fn is_element_tag(g: &check_env::G, t: &Text) -> bool {
    match get(&g.tags, t) {
        Some(tg) => &tg.kind == &Text::from("Element"),
        None => false,
    }
}

/// ```prism
/// CloseTail: fn St, Nat -> St
/// ```
pub fn close_tail(st: &check_types::St, n: &Nat) -> check_types::St {
    let mut this: check_types::St = st.clone();
    this.rows = insert(&this.rows, n, &check_types::empty_row());
    this
}

/// ```prism
/// CheckProgram: unbounded fn [Src], [Module], [Text], Nat, Bool, Bool -> Report
/// ```
pub fn check_program(srcs: &Array<check_errors::Src>, trees: &Array<ast::Module>, world: &Array<Text>, shown: &Nat, recording: &bool, unused: &bool) -> Report_ {
    let (g0a, stb) = check_env::build_g(srcs, trees);
    let g0 = {
        let mut this: check_env::G = g0a.clone();
        this.prelude_from = shown.clone();
        this
    };
    let st0 = {
        let mut this: check_types::St = stb.clone();
        this.recording = *recording;
        this
    };
    let (g1, st1) = top_lets(&g0, &st0);
    let (failed, st2) = run_to_end(fold_job(g1.defs.clone(), (Array::new(), st1.clone()), {
        let g1 = g1.clone();
        Rc::new(move |(p0, p1): ((Array<Text>, check_types::St), check_env::Def)| {
            let g1 = g1.clone();
            entered(once_job(move || {
                let (bad, s) = p0;
                let d = p1;
                {
                    let before_ = len(&s.diags);
                    call_then(start_check_def(g1.clone(), s.clone(), d.clone()), move |check_def_123795: check_types::St| {
                        let s2 = check_def_123795;
                        let bad2 = if &len(&s2.diags) > &before_ { push(&bad, &own_key(&d).qk) } else { bad.clone() };
                        prism_rtl::Turn::Finished((bad2.clone(), s2.clone()))
                    })
                }
            }))
        }) as Rc<dyn Fn(((Array<Text>, check_types::St), check_env::Def)) -> Rc<dyn prism_rtl::Job<(Array<Text>, check_types::St)>>>
    }));
    let st2b = {
        let mut this: check_types::St = st2.clone();
        this.level = Nat::from(0u32);
        this
    };
    let st3 = check_env::default_wants(&g1, &st2b, &Array::new());
    let good = filter(&g1.defs, &(|d: &check_env::Def| !check_types::has_text(&failed, &own_key(d).qk)));
    let (st4, refs) = shrink_check(&g1, &st3, &good);
    let (root_row_, st5) = root_row(&g1, &st4, world);
    let warnings = if *unused { unused_defs(&good, &refs, shown) } else { Array::new() };
    let diags = check_errors::sort_diags(&append(&filter(&st5.diags, &(|d: &check_errors::CDiag| &d.file < shown)), &warnings));
    let text = concat(&each(&diags, &(|d: &check_errors::CDiag| check_errors::render_cdiag(srcs, d))));
    let typed = if *recording { typed_of(&g1, &st5, shown) } else { typed::empty_typed() };
    Report_ { text: text.clone(), errors: len(&filter(&diags, &(|d: &check_errors::CDiag| !check_errors::is_warning(d)))), root_row: root_row_.clone(), typed: typed.clone() }
}

/// The step machine of `CheckProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckProgram: unbounded fn [Src], [Module], [Text], Nat, Bool, Bool -> Report
/// ```
pub struct CheckProgram {
    pub srcs: Array<check_errors::Src>,
    pub trees: Array<ast::Module>,
    pub world: Array<Text>,
    pub shown: Nat,
    pub recording: bool,
    pub unused: bool,
}

impl prism_rtl::Job<Report_> for CheckProgram {
    fn cycle(&self) -> prism_rtl::Turn<Report_> {
        let srcs = &self.srcs;
        let trees = &self.trees;
        let world = &self.world;
        let shown = &self.shown;
        let recording = &self.recording;
        let unused = &self.unused;
        let recording = *recording;
        let shown = shown.clone();
        let srcs = srcs.clone();
        let trees = trees.clone();
        let unused = *unused;
        let world = world.clone();
        call_then(check_env::start_build_g(srcs.clone(), trees.clone()), move |build_g_123354: (check_env::G, check_types::St)| {
            let (g0a, stb) = build_g_123354;
            let g0 = {
                let mut this: check_env::G = g0a.clone();
                this.prelude_from = shown.clone();
                this
            };
            let st0 = {
                let mut this: check_types::St = stb.clone();
                this.recording = recording;
                this
            };
            call_then(start_top_lets(g0.clone(), st0.clone()), move |top_lets_123657: (check_env::G, check_types::St)| {
                let (g1, st1) = top_lets_123657;
                call_value(fold_job(g1.defs.clone(), (Array::new(), st1.clone()), {
                    let g1 = g1.clone();
                    Rc::new(move |(p0, p1): ((Array<Text>, check_types::St), check_env::Def)| {
                        let g1 = g1.clone();
                        entered(once_job(move || {
                            let (bad, s) = p0;
                            let d = p1;
                            {
                                let before_ = len(&s.diags);
                                call_then(start_check_def(g1.clone(), s.clone(), d.clone()), move |check_def_123795: check_types::St| {
                                    let s2 = check_def_123795;
                                    let bad2 = if &len(&s2.diags) > &before_ { push(&bad, &own_key(&d).qk) } else { bad.clone() };
                                    prism_rtl::Turn::Finished((bad2.clone(), s2.clone()))
                                })
                            }
                        }))
                    }) as Rc<dyn Fn(((Array<Text>, check_types::St), check_env::Def)) -> Rc<dyn prism_rtl::Job<(Array<Text>, check_types::St)>>>
                }), move |fold_123699: (Array<Text>, check_types::St)| {
                    let (failed, st2) = fold_123699;
                    let st2b = {
                        let mut this: check_types::St = st2.clone();
                        this.level = Nat::from(0u32);
                        this
                    };
                    call_then(check_env::start_default_wants(g1.clone(), st2b.clone(), Array::new()), move |default_wants_123978: check_types::St| {
                        let st3 = default_wants_123978;
                        let good = filter(&g1.defs, &(|d: &check_env::Def| !check_types::has_text(&failed, &own_key(d).qk)));
                        call_then(start_shrink_check(g1.clone(), st3.clone(), good.clone()), move |shrink_check_124249: (check_types::St, Array<(Text, Array<Text>)>)| {
                            let (st4, refs) = shrink_check_124249;
                            call_then(start_root_row(g1.clone(), st4.clone(), world.clone()), move |root_row_124302: (Text, check_types::St)| {
                                let (root_row_, st5) = root_row_124302;
                                let warnings = if unused { unused_defs(&good, &refs, &shown) } else { Array::new() };
                                let diags = check_errors::sort_diags(&append(&filter(&st5.diags, &(|d: &check_errors::CDiag| &d.file < &shown)), &warnings));
                                let text = concat(&each(&diags, &(|d: &check_errors::CDiag| check_errors::render_cdiag(&srcs, d))));
                                let typed = if recording { typed_of(&g1, &st5, &shown) } else { typed::empty_typed() };
                                prism_rtl::Turn::Finished(Report_ { text: text.clone(), errors: len(&filter(&diags, &(|d: &check_errors::CDiag| !check_errors::is_warning(d)))), root_row: root_row_.clone(), typed: typed.clone() })
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start CheckProgram, x`: what the function value is when passed to `@Run`.
pub fn start_check_program(srcs: Array<check_errors::Src>, trees: Array<ast::Module>, world: Array<Text>, shown: Nat, recording: bool, unused: bool) -> Rc<dyn prism_rtl::Job<Report_>> {
    Rc::new(CheckProgram { srcs, trees, world, shown, recording, unused })
}

/// ```prism
/// TypedOf: unbounded fn G, St, Nat -> TProgram
/// ```
pub fn typed_of(g: &check_env::G, st: &check_types::St, shown: &Nat) -> typed::TProgram {
    let z = check_types::zonk_typed(st);
    let vals = filter(&values(&g.vals), &(|v_: &check_env::ValInfo| ((&v_.file < shown) && (&v_.sort != &Text::from("builtin"))) && (&or(&get(&g.mods, &v_.home), &check_env::dummy_mod()).file == &v_.file)));
    let mut this: typed::TProgram = z.clone();
    this.defs = run_to_end(each_job(vals.clone(), {
        let st = st.clone();
        Rc::new(move |p0: check_env::ValInfo| {
            let st = st.clone();
            entered(once_job(move || {
                let v_ = p0;
                call_then(start_zonk_scheme(st.clone(), v_.scheme.clone()), move |zonk_scheme_125192: check_types::Scheme| prism_rtl::Turn::Finished(typed::DefNote { at: typed::SrcAt { file: v_.file.clone(), span: v_.span.clone() }, name: v_.qk.clone(), scheme: zonk_scheme_125192 }))
            }))
        }) as Rc<dyn Fn(check_env::ValInfo) -> Rc<dyn prism_rtl::Job<typed::DefNote>>>
    }));
    this
}

/// The step machine of `TypedOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypedOf: unbounded fn G, St, Nat -> TProgram
/// ```
pub struct TypedOf {
    pub g: check_env::G,
    pub st: check_types::St,
    pub shown: Nat,
}

impl prism_rtl::Job<typed::TProgram> for TypedOf {
    fn cycle(&self) -> prism_rtl::Turn<typed::TProgram> {
        let g = &self.g;
        let st = &self.st;
        let shown = &self.shown;
        let g = g.clone();
        let shown = shown.clone();
        let st = st.clone();
        call_then(check_types::start_zonk_typed(st.clone()), move |zonk_typed_124935: typed::TProgram| {
            let z = zonk_typed_124935;
            let vals = filter(&values(&g.vals), &(|v_: &check_env::ValInfo| ((&v_.file < &shown) && (&v_.sort != &Text::from("builtin"))) && (&or(&get(&g.mods, &v_.home), &check_env::dummy_mod()).file == &v_.file)));
            prism_rtl::Turn::Finished({
                let mut this: typed::TProgram = z.clone();
                this.defs = run_to_end(each_job(vals.clone(), {
                    let st = st.clone();
                    Rc::new(move |p0: check_env::ValInfo| {
                        let st = st.clone();
                        entered(once_job(move || {
                            let v_ = p0;
                            call_then(start_zonk_scheme(st.clone(), v_.scheme.clone()), move |zonk_scheme_125192: check_types::Scheme| prism_rtl::Turn::Finished(typed::DefNote { at: typed::SrcAt { file: v_.file.clone(), span: v_.span.clone() }, name: v_.qk.clone(), scheme: zonk_scheme_125192 }))
                        }))
                    }) as Rc<dyn Fn(check_env::ValInfo) -> Rc<dyn prism_rtl::Job<typed::DefNote>>>
                }));
                this
            })
        })
    }
}

/// `Start TypedOf, x`: what the function value is when passed to `@Run`.
pub fn start_typed_of(g: check_env::G, st: check_types::St, shown: Nat) -> Rc<dyn prism_rtl::Job<typed::TProgram>> {
    Rc::new(TypedOf { g, st, shown })
}

/// ```prism
/// ZonkScheme: unbounded fn St, Scheme -> Scheme
/// ```
pub fn zonk_scheme(st: &check_types::St, sc: &check_types::Scheme) -> check_types::Scheme {
    let mut this: check_types::Scheme = sc.clone();
    this.ty = check_types::zonk(st, &this.ty);
    this
}

/// The step machine of `ZonkScheme`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ZonkScheme: unbounded fn St, Scheme -> Scheme
/// ```
pub struct ZonkScheme {
    pub st: check_types::St,
    pub sc: check_types::Scheme,
}

impl prism_rtl::Job<check_types::Scheme> for ZonkScheme {
    fn cycle(&self) -> prism_rtl::Turn<check_types::Scheme> {
        let st = &self.st;
        let sc = &self.sc;
        prism_rtl::Turn::Finished({
            let mut this: check_types::Scheme = sc.clone();
            this.ty = check_types::zonk(st, &this.ty);
            this
        })
    }
}

/// `Start ZonkScheme, x`: what the function value is when passed to `@Run`.
pub fn start_zonk_scheme(st: check_types::St, sc: check_types::Scheme) -> Rc<dyn prism_rtl::Job<check_types::Scheme>> {
    Rc::new(ZonkScheme { st, sc })
}

/// ```prism
/// TopLets: unbounded fn G, St -> ((G, St))
/// ```
pub fn top_lets(g: &check_env::G, st: &check_types::St) -> (check_env::G, check_types::St) {
    let unsigned = filter(&g.defs, &(|d: &check_env::Def| is_let_def(d) && !check_env::has_key(&g.vals, &d.qk)));
    let (g1, st1) = fold(&unsigned, &(g.clone(), st.clone()), &(|(gg, s): &(check_env::G, check_types::St), d: &check_env::Def| {
        let (v_, s2) = check_types::fresh_var(s, &false, &d.name);
        let gg2 = {
            let mut this: check_env::G = gg.clone();
            this.vals = insert(&this.vals, &d.qk, &check_env::ValInfo { qk: d.qk.clone(), scheme: check_types::mono(&v_), sort: Text::from("let"), has_sig: false, home: d.home.clone(), file: d.file.clone(), span: d.span.clone() });
            this
        };
        (gg2.clone(), s2.clone())
    }));
    run_to_end(fold_job(unsigned.clone(), (g1.clone(), st1.clone()), Rc::new(move |(p0, p1): ((check_env::G, check_types::St), check_env::Def)| entered(once_job(move || {
        let (gg, s) = p0;
        let d = p1;
        match &d.body {
            check_env::DefBody::DbLet(l) => {
                let env = def_env(&gg, &d);
                let s0 = {
                    let mut this: check_types::St = s.clone();
                    this.file = d.file.clone();
                    this.level = Nat::from(1u32);
                    this
                };
                let pre = or(&get(&gg.vals, &d.qk), &dummy_val()).scheme.ty.clone();
                let l = l.clone();
                call_then(check_expr::start_check(env.clone(), s0.clone(), l.value.clone(), pre.clone()), move |check_126287: check_types::St| {
                    let s1 = check_126287;
                    call_then(check_env::start_solve_wants(gg.clone(), s1.clone(), Array::new(), false), move |solve_wants_126336: check_types::St| {
                        let s2 = solve_wants_126336;
                        let s3 = {
                            let mut this: check_types::St = s2.clone();
                            this.level = Nat::from(0u32);
                            this
                        };
                        call_then(check_types::start_zonk(s3.clone(), pre.clone()), move |zonk_126449: check_types::Ty| {
                            let t = zonk_126449;
                            call_then(check_expr::start_wants_above(s3.clone(), t.clone(), check_expr::is_lambda(&l.value)), move |wants_above_126501: (Array<Nat>, Array<(Nat, Text)>, check_types::St)| {
                                let (keep, bounds, s4) = wants_above_126501;
                                call_then(check_types::start_holds_node(s4.clone(), t.clone()), move |holds_node_126570: bool| {
                                    let (sc, s5) = if holds_node_126570 {
                                        (check_types::mono(&t), s4.clone())
                                    } else {
                                        check_types::generalize(&s4, &t, &keep, &bounds)
                                    };
                                    let gg2 = {
                                        let mut this: check_env::G = gg.clone();
                                        this.vals = insert(&this.vals, &d.qk, &check_env::ValInfo { qk: d.qk.clone(), scheme: sc.clone(), sort: Text::from("let"), has_sig: false, home: d.home.clone(), file: d.file.clone(), span: d.span.clone() });
                                        this
                                    };
                                    call_then(check_types::start_check_colors(s5.clone()), move |check_colors_126889: check_types::St| call_then(check_env::start_resolve_fields(gg.clone(), check_colors_126889, true), move |resolve_fields_126870: check_types::St| call_then(check_types::start_layer_questions(resolve_fields_126870), move |layer_questions_126854: check_types::St| call_then(start_discharge_incls(gg.clone(), layer_questions_126854, Nat::from(0u32)), move |discharge_incls_126834: check_types::St| prism_rtl::Turn::Finished((gg2.clone(), discharge_incls_126834))))))
                                })
                            })
                        })
                    })
                })
            },
            _ => prism_rtl::Turn::Finished((gg.clone(), s.clone())),
        }
    }))) as Rc<dyn Fn(((check_env::G, check_types::St), check_env::Def)) -> Rc<dyn prism_rtl::Job<(check_env::G, check_types::St)>>>))
}

/// The step machine of `TopLets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TopLets: unbounded fn G, St -> ((G, St))
/// ```
pub struct TopLets {
    pub g: check_env::G,
    pub st: check_types::St,
}

impl prism_rtl::Job<(check_env::G, check_types::St)> for TopLets {
    fn cycle(&self) -> prism_rtl::Turn<(check_env::G, check_types::St)> {
        let g = &self.g;
        let st = &self.st;
        let unsigned = filter(&g.defs, &(|d: &check_env::Def| is_let_def(d) && !check_env::has_key(&g.vals, &d.qk)));
        let (g1, st1) = fold(&unsigned, &(g.clone(), st.clone()), &(|(gg, s): &(check_env::G, check_types::St), d: &check_env::Def| {
            let (v_, s2) = check_types::fresh_var(s, &false, &d.name);
            let gg2 = {
                let mut this: check_env::G = gg.clone();
                this.vals = insert(&this.vals, &d.qk, &check_env::ValInfo { qk: d.qk.clone(), scheme: check_types::mono(&v_), sort: Text::from("let"), has_sig: false, home: d.home.clone(), file: d.file.clone(), span: d.span.clone() });
                this
            };
            (gg2.clone(), s2.clone())
        }));
        fold_job(unsigned.clone(), (g1.clone(), st1.clone()), Rc::new(move |(p0, p1): ((check_env::G, check_types::St), check_env::Def)| entered(once_job(move || {
            let (gg, s) = p0;
            let d = p1;
            match &d.body {
                check_env::DefBody::DbLet(l) => {
                    let env = def_env(&gg, &d);
                    let s0 = {
                        let mut this: check_types::St = s.clone();
                        this.file = d.file.clone();
                        this.level = Nat::from(1u32);
                        this
                    };
                    let pre = or(&get(&gg.vals, &d.qk), &dummy_val()).scheme.ty.clone();
                    let l = l.clone();
                    call_then(check_expr::start_check(env.clone(), s0.clone(), l.value.clone(), pre.clone()), move |check_126287: check_types::St| {
                        let s1 = check_126287;
                        call_then(check_env::start_solve_wants(gg.clone(), s1.clone(), Array::new(), false), move |solve_wants_126336: check_types::St| {
                            let s2 = solve_wants_126336;
                            let s3 = {
                                let mut this: check_types::St = s2.clone();
                                this.level = Nat::from(0u32);
                                this
                            };
                            call_then(check_types::start_zonk(s3.clone(), pre.clone()), move |zonk_126449: check_types::Ty| {
                                let t = zonk_126449;
                                call_then(check_expr::start_wants_above(s3.clone(), t.clone(), check_expr::is_lambda(&l.value)), move |wants_above_126501: (Array<Nat>, Array<(Nat, Text)>, check_types::St)| {
                                    let (keep, bounds, s4) = wants_above_126501;
                                    call_then(check_types::start_holds_node(s4.clone(), t.clone()), move |holds_node_126570: bool| {
                                        let (sc, s5) = if holds_node_126570 {
                                            (check_types::mono(&t), s4.clone())
                                        } else {
                                            check_types::generalize(&s4, &t, &keep, &bounds)
                                        };
                                        let gg2 = {
                                            let mut this: check_env::G = gg.clone();
                                            this.vals = insert(&this.vals, &d.qk, &check_env::ValInfo { qk: d.qk.clone(), scheme: sc.clone(), sort: Text::from("let"), has_sig: false, home: d.home.clone(), file: d.file.clone(), span: d.span.clone() });
                                            this
                                        };
                                        call_then(check_types::start_check_colors(s5.clone()), move |check_colors_126889: check_types::St| call_then(check_env::start_resolve_fields(gg.clone(), check_colors_126889, true), move |resolve_fields_126870: check_types::St| call_then(check_types::start_layer_questions(resolve_fields_126870), move |layer_questions_126854: check_types::St| call_then(start_discharge_incls(gg.clone(), layer_questions_126854, Nat::from(0u32)), move |discharge_incls_126834: check_types::St| prism_rtl::Turn::Finished((gg2.clone(), discharge_incls_126834))))))
                                    })
                                })
                            })
                        })
                    })
                },
                _ => prism_rtl::Turn::Finished((gg.clone(), s.clone())),
            }
        }))) as Rc<dyn Fn(((check_env::G, check_types::St), check_env::Def)) -> Rc<dyn prism_rtl::Job<(check_env::G, check_types::St)>>>).cycle()
    }
}

/// `Start TopLets, x`: what the function value is when passed to `@Run`.
pub fn start_top_lets(g: check_env::G, st: check_types::St) -> Rc<dyn prism_rtl::Job<(check_env::G, check_types::St)>> {
    Rc::new(TopLets { g, st })
}

/// ```prism
/// let dummyVal
/// ```
pub fn dummy_val() -> check_env::ValInfo {
    check_env::ValInfo { qk: Text::from(""), scheme: check_types::mono(&check_types::Ty::TyErr), sort: Text::from(""), has_sig: false, home: Text::from(""), file: Nat::from(0u32), span: ast::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// IsLetDef: fn Def -> Bool
/// ```
pub fn is_let_def(d: &check_env::Def) -> bool {
    match &d.body {
        check_env::DefBody::DbLet(_) => true,
        _ => false,
    }
}

/// ```prism
/// DefEnv: fn G, Def -> Env
/// ```
pub fn def_env(g: &check_env::G, d: &check_env::Def) -> check_expr::Env {
    let info = or(&get(&g.mods, &d.home), &check_env::dummy_mod());
    let scope = match &info.emit_rw.tail {
        check_types::Tail::TlQ(v_) => check_types::Rw { fams: info.emit_rw.fams.clone(), minus: Array::new(), tail: check_types::Tail::TlRigid(v_.clone()) },
        _ => info.emit_rw.clone(),
    };
    check_expr::Env { g: g.clone(), home: d.home.clone(), file: d.file.clone(), src: or(&index(&g.srcs, &d.file), &check_errors::mk_src(&Text::from(""), &Text::from(""))), locals: Map::new(), scope: scope.clone(), givens: Array::new(), mark: Text::from(""), in_update: false, def_name: d.name.clone(), refine: Map::new(), pending: Array::new() }
}

/// ```prism
/// CheckDef: unbounded fn G, St, Def -> St
/// ```
pub fn check_def(g: &check_env::G, st: &check_types::St, d: &check_env::Def) -> check_types::St {
    let env = def_env(g, d);
    let incls_before = len(&st.incls);
    let s0 = {
        let mut this: check_types::St = st.clone();
        this.file = d.file.clone();
        this.level = Nat::from(1u32);
        this.color = check_types::Col::CBound;
        this.color_why = Text::from("");
        this.color_flex = Array::new();
        this.cleqs = Array::new();
        this
    };
    let s1 = match &d.body {
        check_env::DefBody::DbFn(clauses) => match get(&g.vals, &d.qk) {
            Some(v_) => check_expr::check_clauses(&env, &s0, &d.name, clauses, &v_.scheme, &d.span),
            None => s0.clone(),
        },
        check_env::DefBody::DbWidget(w) => check_widget_def(&env, &s0, d, w),
        check_env::DefBody::DbLet(l) => match get(&g.vals, &d.qk) {
            Some(v_) => if v_.has_sig {
                check_expr::check(&env, &s0, &l.value, &check_types::skolemize(&v_.scheme))
            } else {
                s0.clone()
            },
            None => s0.clone(),
        },
        check_env::DefBody::DbMethod(clauses, cls, im) => check_method(&env, &s0, d, clauses, cls, im),
        check_env::DefBody::DbDefault(clauses, cls) => match method_key(g, cls, &d.name) {
            Some(mk) => match get(&g.vals, &mk) {
                Some(v_) => check_expr::check_clauses(&env, &s0, &d.name, clauses, &v_.scheme, &d.span),
                None => s0.clone(),
            },
            None => s0.clone(),
        },
        check_env::DefBody::DbCheck(c) => run_to_end(fold_job(c.lines.clone(), s0.clone(), {
            let env = env.clone();
            Rc::new(move |(p0, p1): (check_types::St, ast::CheckLine)| {
                let env = env.clone();
                entered(once_job(move || {
                    let s = p0;
                    let line = p1;
                    call_then(check_expr::start_infer(env.clone(), s.clone(), line.expr.clone()), move |infer_128903: (check_types::Ty, check_types::St)| {
                        let (t, s2) = infer_128903;
                        match &line.pattern {
                            Some(p_) => {
                                let p_ = p_.clone();
                                call_then(check_expr::start_bind_pattern(env.clone(), s2.clone(), p_.clone(), t.clone(), true), move |bind_pattern_129022: (check_expr::Env, check_types::St)| {
                                    let (_, s3) = bind_pattern_129022;
                                    prism_rtl::Turn::Finished(s3.clone())
                                })
                            },
                            None => prism_rtl::Turn::Finished(s2.clone()),
                        }
                    })
                }))
            }) as Rc<dyn Fn((check_types::St, ast::CheckLine)) -> Rc<dyn prism_rtl::Job<check_types::St>>>
        })),
        check_env::DefBody::DbTest(t) => {
            let (bt, s2) = check_expr::infer(&env, &s0, &t.blueprint);
            match check_types::walk(&s2, &bt) {
                check_types::Ty::TyAt(_, _) => s2.clone(),
                check_types::Ty::TyErr => s2.clone(),
                other => check_types::err(&s2, &Text::from("mismatch"), &t.blueprint.span, &Text::from(format!("a test builds a blueprint; this is `{}`", &check_types::show_ty(&s2, &other)))),
            }
        },
    };
    let solved = check_types::check_colors(&check_env::solve_wants(g, &s1, &env.givens, &false));
    let defaulted = check_types::layer_questions(&check_env::resolve_fields(g, &default_def(g, &solved), &true));
    let discharged = discharge_incls(g, &defaulted, &incls_before);
    let mut this: check_types::St = discharged.clone();
    this.level = Nat::from(0u32);
    this
}

/// The step machine of `CheckDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckDef: unbounded fn G, St, Def -> St
/// ```
pub struct CheckDef {
    pub g: check_env::G,
    pub st: check_types::St,
    pub d: check_env::Def,
}

impl prism_rtl::Job<check_types::St> for CheckDef {
    fn cycle(&self) -> prism_rtl::Turn<check_types::St> {
        let g = &self.g;
        let st = &self.st;
        let d = &self.d;
        let env = def_env(g, d);
        let incls_before = len(&st.incls);
        let s0 = {
            let mut this: check_types::St = st.clone();
            this.file = d.file.clone();
            this.level = Nat::from(1u32);
            this.color = check_types::Col::CBound;
            this.color_why = Text::from("");
            this.color_flex = Array::new();
            this.cleqs = Array::new();
            this
        };
        let s1 = match &d.body {
            check_env::DefBody::DbFn(clauses) => match get(&g.vals, &d.qk) {
                Some(v_) => check_expr::check_clauses(&env, &s0, &d.name, clauses, &v_.scheme, &d.span),
                None => s0.clone(),
            },
            check_env::DefBody::DbWidget(w) => check_widget_def(&env, &s0, d, w),
            check_env::DefBody::DbLet(l) => match get(&g.vals, &d.qk) {
                Some(v_) => if v_.has_sig {
                    check_expr::check(&env, &s0, &l.value, &check_types::skolemize(&v_.scheme))
                } else {
                    s0.clone()
                },
                None => s0.clone(),
            },
            check_env::DefBody::DbMethod(clauses, cls, im) => check_method(&env, &s0, d, clauses, cls, im),
            check_env::DefBody::DbDefault(clauses, cls) => match method_key(g, cls, &d.name) {
                Some(mk) => match get(&g.vals, &mk) {
                    Some(v_) => check_expr::check_clauses(&env, &s0, &d.name, clauses, &v_.scheme, &d.span),
                    None => s0.clone(),
                },
                None => s0.clone(),
            },
            check_env::DefBody::DbCheck(c) => run_to_end(fold_job(c.lines.clone(), s0.clone(), {
                let env = env.clone();
                Rc::new(move |(p0, p1): (check_types::St, ast::CheckLine)| {
                    let env = env.clone();
                    entered(once_job(move || {
                        let s = p0;
                        let line = p1;
                        call_then(check_expr::start_infer(env.clone(), s.clone(), line.expr.clone()), move |infer_128903: (check_types::Ty, check_types::St)| {
                            let (t, s2) = infer_128903;
                            match &line.pattern {
                                Some(p_) => {
                                    let p_ = p_.clone();
                                    call_then(check_expr::start_bind_pattern(env.clone(), s2.clone(), p_.clone(), t.clone(), true), move |bind_pattern_129022: (check_expr::Env, check_types::St)| {
                                        let (_, s3) = bind_pattern_129022;
                                        prism_rtl::Turn::Finished(s3.clone())
                                    })
                                },
                                None => prism_rtl::Turn::Finished(s2.clone()),
                            }
                        })
                    }))
                }) as Rc<dyn Fn((check_types::St, ast::CheckLine)) -> Rc<dyn prism_rtl::Job<check_types::St>>>
            })),
            check_env::DefBody::DbTest(t) => {
                let (bt, s2) = check_expr::infer(&env, &s0, &t.blueprint);
                match check_types::walk(&s2, &bt) {
                    check_types::Ty::TyAt(_, _) => s2.clone(),
                    check_types::Ty::TyErr => s2.clone(),
                    other => check_types::err(&s2, &Text::from("mismatch"), &t.blueprint.span, &Text::from(format!("a test builds a blueprint; this is `{}`", &check_types::show_ty(&s2, &other)))),
                }
            },
        };
        let g = g.clone();
        call_then(check_env::start_solve_wants(g.clone(), s1.clone(), env.givens.clone(), false), move |solve_wants_129421: check_types::St| call_then(check_types::start_check_colors(solve_wants_129421), move |check_colors_129408: check_types::St| {
            let solved = check_colors_129408;
            call_then(start_default_def(g.clone(), solved.clone()), move |default_def_129512: check_types::St| call_then(check_env::start_resolve_fields(g.clone(), default_def_129512, true), move |resolve_fields_129494: check_types::St| call_then(check_types::start_layer_questions(resolve_fields_129494), move |layer_questions_129478: check_types::St| {
                let defaulted = layer_questions_129478;
                call_then(start_discharge_incls(g.clone(), defaulted.clone(), incls_before.clone()), move |discharge_incls_129562: check_types::St| {
                    let discharged = discharge_incls_129562;
                    prism_rtl::Turn::Finished({
                        let mut this: check_types::St = discharged.clone();
                        this.level = Nat::from(0u32);
                        this
                    })
                })
            })))
        }))
    }
}

/// `Start CheckDef, x`: what the function value is when passed to `@Run`.
pub fn start_check_def(g: check_env::G, st: check_types::St, d: check_env::Def) -> Rc<dyn prism_rtl::Job<check_types::St>> {
    Rc::new(CheckDef { g, st, d })
}

/// ```prism
/// DefaultDef: unbounded fn G, St -> St
/// ```
pub fn default_def(g: &check_env::G, st: &check_types::St) -> check_types::St {
    let mine = run_to_end(filter_job(st.wants.clone(), {
        let st = st.clone();
        Rc::new(move |p0: check_types::Want| {
            let st = st.clone();
            entered(once_job(move || {
                let w = p0;
                call_then(check_types::start_walk(st.clone(), w.ty.clone()), move |walk_129884: check_types::Ty| match walk_129884 {
                    check_types::Ty::TyFlex(n) => prism_rtl::Turn::Finished(&check_types::info_of(&st, &n).level >= &Nat::from(1u32)),
                    _ => prism_rtl::Turn::Finished(true),
                })
            }))
        }) as Rc<dyn Fn(check_types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    let theirs = run_to_end(filter_job(st.wants.clone(), {
        let st = st.clone();
        Rc::new(move |p0: check_types::Want| {
            let st = st.clone();
            entered(once_job(move || {
                let w = p0;
                call_then(check_types::start_walk(st.clone(), w.ty.clone()), move |walk_130012: check_types::Ty| match walk_130012 {
                    check_types::Ty::TyFlex(n) => prism_rtl::Turn::Finished(&check_types::info_of(&st, &n).level < &Nat::from(1u32)),
                    _ => prism_rtl::Turn::Finished(false),
                })
            }))
        }) as Rc<dyn Fn(check_types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    let st1 = {
        let mut this: check_types::St = st.clone();
        this.wants = mine.clone();
        this
    };
    let s2 = check_env::default_wants(g, &st1, &Array::new());
    let mut this: check_types::St = s2.clone();
    this.wants = append(&theirs, &this.wants);
    this
}

/// The step machine of `DefaultDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefaultDef: unbounded fn G, St -> St
/// ```
pub struct DefaultDef {
    pub g: check_env::G,
    pub st: check_types::St,
}

impl prism_rtl::Job<check_types::St> for DefaultDef {
    fn cycle(&self) -> prism_rtl::Turn<check_types::St> {
        let g = &self.g;
        let st = &self.st;
        let g = g.clone();
        let st = st.clone();
        call_value(filter_job(st.wants.clone(), {
            let st = st.clone();
            Rc::new(move |p0: check_types::Want| {
                let st = st.clone();
                entered(once_job(move || {
                    let w = p0;
                    call_then(check_types::start_walk(st.clone(), w.ty.clone()), move |walk_129884: check_types::Ty| match walk_129884 {
                        check_types::Ty::TyFlex(n) => prism_rtl::Turn::Finished(&check_types::info_of(&st, &n).level >= &Nat::from(1u32)),
                        _ => prism_rtl::Turn::Finished(true),
                    })
                }))
            }) as Rc<dyn Fn(check_types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
        }), move |filter_129856: Array<check_types::Want>| {
            let mine = filter_129856;
            call_value(filter_job(st.wants.clone(), {
                let st = st.clone();
                Rc::new(move |p0: check_types::Want| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let w = p0;
                        call_then(check_types::start_walk(st.clone(), w.ty.clone()), move |walk_130012: check_types::Ty| match walk_130012 {
                            check_types::Ty::TyFlex(n) => prism_rtl::Turn::Finished(&check_types::info_of(&st, &n).level < &Nat::from(1u32)),
                            _ => prism_rtl::Turn::Finished(false),
                        })
                    }))
                }) as Rc<dyn Fn(check_types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
            }), move |filter_129984: Array<check_types::Want>| {
                let theirs = filter_129984;
                let st1 = {
                    let mut this: check_types::St = st.clone();
                    this.wants = mine.clone();
                    this
                };
                call_then(check_env::start_default_wants(g.clone(), st1.clone(), Array::new()), move |default_wants_130158: check_types::St| {
                    let s2 = default_wants_130158;
                    prism_rtl::Turn::Finished({
                        let mut this: check_types::St = s2.clone();
                        this.wants = append(&theirs, &this.wants);
                        this
                    })
                })
            })
        })
    }
}

/// `Start DefaultDef, x`: what the function value is when passed to `@Run`.
pub fn start_default_def(g: check_env::G, st: check_types::St) -> Rc<dyn prism_rtl::Job<check_types::St>> {
    Rc::new(DefaultDef { g, st })
}

/// ```prism
/// CheckWidgetDef: unbounded fn Env, St, Def, WidgetDecl -> St
/// ```
pub fn check_widget_def(env: &check_expr::Env, st: &check_types::St, d: &check_env::Def, w: &ast::WidgetDecl) -> check_types::St {
    match get(&env.g.vals, &d.qk) {
        Some(v_) => match check_types::skolemize(&v_.scheme) {
            check_types::Ty::TyAt(inner, rw) => {
                let env2 = {
                    let mut this: check_expr::Env = env.clone();
                    this.scope = rw.clone();
                    this.mark = Text::from("@");
                    this
                };
                let (t, st2) = check_blocks::infer_widget_block(&env2, st, &w.body);
                check_types::note_fn(&check_types::unify(&st2, &*inner, &t, &w.span), &w.span, &d.name, &check_types::Col::CBound, &st2.color)
            },
            other => check_types::err(st, &Text::from("mismatch"), &w.span, &Text::from(format!("`{}` is declared `{}`; a widget block builds a blueprint", &d.name, &check_types::show_ty(st, &other)))),
        },
        None => {
            let (t, st2) = check_blocks::infer_widget_block(env, st, &w.body);
            check_types::note_fn(&st2, &w.span, &d.name, &check_types::Col::CBound, &st2.color)
        },
    }
}

/// The step machine of `CheckWidgetDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckWidgetDef: unbounded fn Env, St, Def, WidgetDecl -> St
/// ```
pub struct CheckWidgetDef {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub d: check_env::Def,
    pub w: ast::WidgetDecl,
}

impl prism_rtl::Job<check_types::St> for CheckWidgetDef {
    fn cycle(&self) -> prism_rtl::Turn<check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let d = &self.d;
        let w = &self.w;
        match get(&env.g.vals, &d.qk) {
            Some(v_) => {
                let d = d.clone();
                let env = env.clone();
                let st = st.clone();
                let w = w.clone();
                call_then(check_types::start_skolemize(v_.scheme.clone()), move |skolemize_130464: check_types::Ty| match skolemize_130464 {
                    check_types::Ty::TyAt(inner, rw) => {
                        let env2 = {
                            let mut this: check_expr::Env = env.clone();
                            this.scope = rw.clone();
                            this.mark = Text::from("@");
                            this
                        };
                        call_then(check_blocks::start_infer_widget_block(env2.clone(), st.clone(), w.body.clone()), move |infer_widget_block_130634: (check_types::Ty, check_types::St)| {
                            let (t, st2) = infer_widget_block_130634;
                            call_then(check_types::start_unify(st2.clone(), (*inner).clone(), t.clone(), w.span.clone()), move |unify_130688: check_types::St| prism_rtl::Turn::Finished(check_types::note_fn(&unify_130688, &w.span, &d.name, &check_types::Col::CBound, &st2.color)))
                        })
                    },
                    other => call_then(check_types::start_show_ty(st.clone(), other.clone()), move |show_ty_130821: Text| prism_rtl::Turn::Finished(check_types::err(&st, &Text::from("mismatch"), &w.span, &Text::from(format!("`{}` is declared `{}`; a widget block builds a blueprint", &d.name, &show_ty_130821))))),
                })
            },
            None => {
                let d = d.clone();
                let env = env.clone();
                let st = st.clone();
                let w = w.clone();
                call_then(check_blocks::start_infer_widget_block(env.clone(), st.clone(), w.body.clone()), move |infer_widget_block_130910: (check_types::Ty, check_types::St)| {
                    let (t, st2) = infer_widget_block_130910;
                    prism_rtl::Turn::Finished(check_types::note_fn(&st2, &w.span, &d.name, &check_types::Col::CBound, &st2.color))
                })
            },
        }
    }
}

/// `Start CheckWidgetDef, x`: what the function value is when passed to `@Run`.
pub fn start_check_widget_def(env: check_expr::Env, st: check_types::St, d: check_env::Def, w: ast::WidgetDecl) -> Rc<dyn prism_rtl::Job<check_types::St>> {
    Rc::new(CheckWidgetDef { env, st, d, w })
}

/// ```prism
/// ?MethodKey: fn G, Text, Text -> ?Text
/// ```
pub fn method_key(g: &check_env::G, cls: &Text, name: &Text) -> Option<Text> {
    fold(&or(&get(&g.traits, cls), &check_env::dummy_trait()).methods, &None, &(|found_opt: &Option<Text>, k: &Text| match found_opt {
        Some(f) => Some(f.clone()),
        None => if (&check_types::bare_name(k) == name) || (&lexer::drop_prefix(k, &Text::from(format!("{}.", &or(&get(&g.traits, cls), &check_env::dummy_trait()).home))) == name) {
            Some(k.clone())
        } else {
            None
        },
    }))
}

/// ```prism
/// CheckMethod: unbounded fn Env, St, Def, [FnClause], Text, ImplInfo -> St
/// ```
pub fn check_method(env: &check_expr::Env, st: &check_types::St, d: &check_env::Def, clauses: &Array<ast::FnClause>, cls: &Text, im: &check_env::ImplInfo) -> check_types::St {
    match method_key(&env.g, cls, &d.name) {
        None => check_types::err(st, &Text::from("mismatch"), &d.span, &Text::from(format!("`^{}` has no method `{}`", &check_types::bare_name(cls), &d.name))),
        Some(mk) => match get(&env.g.vals, &mk) {
            None => st.clone(),
            Some(v_) => {
                let ti = or(&get(&env.g.traits, cls), &check_env::dummy_trait());
                let head = check_types::subst_q(&check_types::Inst { tys: fold(&im.qs, &Map::new(), &(|m: &Map<Text, check_types::Ty>, q: &Text| insert(m, q, &check_types::Ty::TyRigid(q.clone())))), rows: Map::new(), cols: Map::new() }, &im.head);
                let ty = check_types::subst_q(&check_types::Inst { tys: map_of(vec![(ti.param.clone(), head.clone())]), rows: Map::new(), cols: Map::new() }, &v_.scheme.ty);
                let sc = check_types::Scheme { qs: filter(&v_.scheme.qs, &(|q: &Text| q != &ti.param)), plain_qs: Array::new(), rqs: v_.scheme.rqs.clone(), cqs: v_.scheme.cqs.clone(), cjoins: v_.scheme.cjoins.clone(), bounds: filter(&v_.scheme.bounds, &(|(q, _): &(Text, Text)| q != &ti.param)), ty: ty.clone() };
                let env2 = {
                    let mut this: check_expr::Env = env.clone();
                    this.givens = im.bounds.clone();
                    this
                };
                check_expr::check_clauses(&env2, st, &d.name, clauses, &sc, &d.span)
            },
        },
    }
}

/// The step machine of `CheckMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckMethod: unbounded fn Env, St, Def, [FnClause], Text, ImplInfo -> St
/// ```
pub struct CheckMethod {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub d: check_env::Def,
    pub clauses: Array<ast::FnClause>,
    pub cls: Text,
    pub im: check_env::ImplInfo,
}

impl prism_rtl::Job<check_types::St> for CheckMethod {
    fn cycle(&self) -> prism_rtl::Turn<check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let d = &self.d;
        let clauses = &self.clauses;
        let cls = &self.cls;
        let im = &self.im;
        match method_key(&env.g, cls, &d.name) {
            None => prism_rtl::Turn::Finished(check_types::err(st, &Text::from("mismatch"), &d.span, &Text::from(format!("`^{}` has no method `{}`", &check_types::bare_name(cls), &d.name)))),
            Some(mk) => match get(&env.g.vals, &mk) {
                None => prism_rtl::Turn::Finished(st.clone()),
                Some(v_) => {
                    let ti = or(&get(&env.g.traits, cls), &check_env::dummy_trait());
                    let clauses = clauses.clone();
                    let d = d.clone();
                    let env = env.clone();
                    let im = im.clone();
                    let st = st.clone();
                    call_then(check_types::start_subst_q(check_types::Inst { tys: fold(&im.qs, &Map::new(), &(|m: &Map<Text, check_types::Ty>, q: &Text| insert(m, q, &check_types::Ty::TyRigid(q.clone())))), rows: Map::new(), cols: Map::new() }, im.head.clone()), move |subst_q_131781: check_types::Ty| {
                        let head = subst_q_131781;
                        call_then(check_types::start_subst_q(check_types::Inst { tys: map_of(vec![(ti.param.clone(), head.clone())]), rows: Map::new(), cols: Map::new() }, v_.scheme.ty.clone()), move |subst_q_131899: check_types::Ty| {
                            let ty = subst_q_131899;
                            let sc = check_types::Scheme { qs: filter(&v_.scheme.qs, &(|q: &Text| q != &ti.param)), plain_qs: Array::new(), rqs: v_.scheme.rqs.clone(), cqs: v_.scheme.cqs.clone(), cjoins: v_.scheme.cjoins.clone(), bounds: filter(&v_.scheme.bounds, &(|(q, _): &(Text, Text)| q != &ti.param)), ty: ty.clone() };
                            let env2 = {
                                let mut this: check_expr::Env = env.clone();
                                this.givens = im.bounds.clone();
                                this
                            };
                            prism_rtl::Turn::More(Rc::new(check_expr::CheckClauses { env: env2.clone(), st: st.clone(), name: d.name.clone(), clauses: clauses.clone(), sc: sc.clone(), span: d.span.clone() }))
                        })
                    })
                },
            },
        }
    }
}

/// `Start CheckMethod, x`: what the function value is when passed to `@Run`.
pub fn start_check_method(env: check_expr::Env, st: check_types::St, d: check_env::Def, clauses: Array<ast::FnClause>, cls: Text, im: check_env::ImplInfo) -> Rc<dyn prism_rtl::Job<check_types::St>> {
    Rc::new(CheckMethod { env, st, d, clauses, cls, im })
}

/// ```prism
/// RootRow: unbounded fn G, St, [Text] -> ((Text, St))
/// ```
pub fn root_row(g: &check_env::G, st: &check_types::St, world: &Array<Text>) -> (Text, check_types::St) {
    match get(&g.mods, &Text::from("")) {
        None => (Text::from(""), st.clone()),
        Some(info) => {
            let shown = check_types::show_row(&info.emit_rw);
            if &len(world) == &Nat::from(0u32) {
                (shown.clone(), st.clone())
            } else {
                {
                    let missing = filter(&info.emit_rw.fams, &(|f: &Text| !check_types::has_text(world, f)));
                    if &len(&missing) == &Nat::from(0u32) {
                        (shown.clone(), st.clone())
                    } else {
                        {
                            let s0 = {
                                let mut this: check_types::St = st.clone();
                                this.file = info.file.clone();
                                this
                            };
                            (shown.clone(), check_types::err_fix(&s0, &Text::from("world-row"), &info.tree.span, &Text::from(format!("the program emits {}, which this World does not answer", &lexer::join(&each(&missing, &(|f: &Text| Text::from(format!("`{}.*`", f)))), &Text::from(", ")))), &Text::from("host the tags it cannot answer, or run under a World that answers them")))
                        }
                    }
                }
            }
        },
    }
}

/// The step machine of `RootRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RootRow: unbounded fn G, St, [Text] -> ((Text, St))
/// ```
pub struct RootRow {
    pub g: check_env::G,
    pub st: check_types::St,
    pub world: Array<Text>,
}

impl prism_rtl::Job<(Text, check_types::St)> for RootRow {
    fn cycle(&self) -> prism_rtl::Turn<(Text, check_types::St)> {
        let g = &self.g;
        let st = &self.st;
        let world = &self.world;
        match get(&g.mods, &Text::from("")) {
            None => prism_rtl::Turn::Finished((Text::from(""), st.clone())),
            Some(info) => {
                let shown = check_types::show_row(&info.emit_rw);
                if &len(world) == &Nat::from(0u32) {
                    prism_rtl::Turn::Finished((shown.clone(), st.clone()))
                } else {
                    {
                        let missing = filter(&info.emit_rw.fams, &(|f: &Text| !check_types::has_text(world, f)));
                        if &len(&missing) == &Nat::from(0u32) {
                            prism_rtl::Turn::Finished((shown.clone(), st.clone()))
                        } else {
                            {
                                let s0 = {
                                    let mut this: check_types::St = st.clone();
                                    this.file = info.file.clone();
                                    this
                                };
                                prism_rtl::Turn::Finished((shown.clone(), check_types::err_fix(&s0, &Text::from("world-row"), &info.tree.span, &Text::from(format!("the program emits {}, which this World does not answer", &lexer::join(&each(&missing, &(|f: &Text| Text::from(format!("`{}.*`", f)))), &Text::from(", ")))), &Text::from("host the tags it cannot answer, or run under a World that answers them"))))
                            }
                        }
                    }
                }
            },
        }
    }
}

/// `Start RootRow, x`: what the function value is when passed to `@Run`.
pub fn start_root_row(g: check_env::G, st: check_types::St, world: Array<Text>) -> Rc<dyn prism_rtl::Job<(Text, check_types::St)>> {
    Rc::new(RootRow { g, st, world })
}
