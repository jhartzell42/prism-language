//! The module `Emit.Cpp.Stmts`, from `target/bootstrap/src/prismc/emit/cpp/stmts.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// CppStatements: unbounded fn Cp, [Do] -> Text
/// ```
pub fn cpp_statements(cp: &crate::emit::cpp::Cp, dos: &Array<crate::lower::model::Do>) -> Text {
    let (st, _) = cpp_statements_cp(cp, dos);
    st.clone()
}

/// The step machine of `CppStatements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppStatements: unbounded fn Cp, [Do] -> Text
/// ```
pub struct CppStatements {
    pub cp: crate::emit::cpp::Cp,
    pub dos: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for CppStatements {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let dos = &self.dos;
        let cp = cp.clone();
        let dos = dos.clone();
        call_then(start_cpp_statements_cp(cp.clone(), dos.clone()), move |cpp_statements_cp_1153: (Text, crate::emit::cpp::Cp)| {
            let (st, _) = cpp_statements_cp_1153;
            prism_rtl::Turn::Finished(st.clone())
        })
    }
}

/// `Start CppStatements, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_statements(cp: crate::emit::cpp::Cp, dos: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppStatements { cp, dos })
}

/// ```prism
/// CppStatementsCp: unbounded fn Cp, [Do] -> ((Text, Cp))
/// ```
pub fn cpp_statements_cp(cp: &crate::emit::cpp::Cp, dos: &Array<crate::lower::model::Do>) -> (Text, crate::emit::cpp::Cp) {
    let (lines, last) = run_to_end(fold_job(dos.clone(), (Array::new(), cp.clone()), Rc::new(move |(p0, p1): ((Array<Text>, crate::emit::cpp::Cp), crate::lower::model::Do)| entered(once_job(move || {
        let (acc, c) = p0;
        let d = p1;
        call_then(start_rebound(c.clone(), d.clone()), move |rebound_1580: crate::emit::cpp::Cp| {
            let c2 = rebound_1580;
            let line = match &d {
                crate::lower::model::Do::DoLet(p_, x) => cpp_let(&c, &c2, p_, x),
                _ => cpp_statement(&c2, &d),
            };
            prism_rtl::Turn::Finished((push(&acc, &line), c2.clone()))
        })
    }))) as Rc<dyn Fn(((Array<Text>, crate::emit::cpp::Cp), crate::lower::model::Do)) -> Rc<dyn prism_rtl::Job<(Array<Text>, crate::emit::cpp::Cp)>>>));
    (crate::syntax::lexer::chars::join(&lines, &Text::lit("\n")), last.clone())
}

/// The step machine of `CppStatementsCp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppStatementsCp: unbounded fn Cp, [Do] -> ((Text, Cp))
/// ```
pub struct CppStatementsCp {
    pub cp: crate::emit::cpp::Cp,
    pub dos: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<(Text, crate::emit::cpp::Cp)> for CppStatementsCp {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::emit::cpp::Cp)> {
        let cp = &self.cp;
        let dos = &self.dos;
        let cp = cp.clone();
        let dos = dos.clone();
        call_value(fold_job(dos.clone(), (Array::new(), cp.clone()), Rc::new(move |(p0, p1): ((Array<Text>, crate::emit::cpp::Cp), crate::lower::model::Do)| entered(once_job(move || {
            let (acc, c) = p0;
            let d = p1;
            call_then(start_rebound(c.clone(), d.clone()), move |rebound_1580: crate::emit::cpp::Cp| {
                let c2 = rebound_1580;
                let line = match &d {
                    crate::lower::model::Do::DoLet(p_, x) => cpp_let(&c, &c2, p_, x),
                    _ => cpp_statement(&c2, &d),
                };
                prism_rtl::Turn::Finished((push(&acc, &line), c2.clone()))
            })
        }))) as Rc<dyn Fn(((Array<Text>, crate::emit::cpp::Cp), crate::lower::model::Do)) -> Rc<dyn prism_rtl::Job<(Array<Text>, crate::emit::cpp::Cp)>>>), move |fold_1522: (Array<Text>, crate::emit::cpp::Cp)| {
            let (lines, last) = fold_1522;
            prism_rtl::Turn::Finished((crate::syntax::lexer::chars::join(&lines, &Text::lit("\n")), last.clone()))
        })
    }
}

/// `Start CppStatementsCp, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_statements_cp(cp: crate::emit::cpp::Cp, dos: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<(Text, crate::emit::cpp::Cp)>> {
    Rc::new(CppStatementsCp { cp, dos })
}

/// ```prism
/// Unvexed: fn Text -> Text
/// ```
pub fn unvexed(t: &Text) -> Text {
    let head = or(&index(&split_on(t, &Text::lit("(")), &Nat::from(0u32)), &Text::lit(""));
    let type_like = crate::syntax::lexer::chars::contains(&head, &Text::lit(":")) || crate::syntax::lexer::chars::contains(&Text::lit("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), &crate::syntax::lexer::chars::head(&head));
    let vexing = (((&crate::syntax::lexer::chars::last_char(t) == &Text::lit(")")) && !crate::syntax::lexer::chars::contains(&head, &Text::lit(" "))) && (&head != &Text::lit(""))) && type_like;
    if vexing { Text::from(format!("({})", t)) } else { t.clone() }
}

/// ```prism
/// Rebound: unbounded fn Cp, Do -> Cp
/// ```
pub fn rebound(cp: &crate::emit::cpp::Cp, d: &crate::lower::model::Do) -> crate::emit::cpp::Cp {
    match d {
        crate::lower::model::Do::DoLetElse(p_, _, _) => unbind(cp, &pat_names(p_)),
        crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTuple(ps), _) => unbind(cp, &pat_names(&crate::lower::model::Pa::PaTuple(ps.clone()))),
        crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaCtor(c, ps), _) => unbind(cp, &pat_names(&crate::lower::model::Pa::PaCtor(c.clone(), ps.clone()))),
        crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaRecord(c, fs, r), _) => unbind(cp, &pat_names(&crate::lower::model::Pa::PaRecord(c.clone(), fs.clone(), *r))),
        crate::lower::model::Do::DoLet(p_, x) => match let_name(p_) {
            Some(n) => {
                let pointing_ = if is_pointer_let(cp, p_, x) { pointing(cp, &n) } else { known_value(cp, p_, &n) };
                if cpp_mentions(&crate::emit::cpp::expr::cpp_expr(cp, x), &var_name(cp, &n)) {
                    {
                        let fresh = Text::from(format!("{}_{}", &var_name(cp, &n), &inc(&len(&keys(&cp.renames)))));
                        {
                            let mut this: crate::emit::cpp::Cp = pointing_.clone();
                            this.renames = insert(&this.renames, &n, &fresh);
                            this
                        }
                    }
                } else {
                    pointing_.clone()
                }
            },
            None => cp.clone(),
        },
        _ => cp.clone(),
    }
}

/// The step machine of `Rebound`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Rebound: unbounded fn Cp, Do -> Cp
/// ```
pub struct Rebound {
    pub cp: crate::emit::cpp::Cp,
    pub d: crate::lower::model::Do,
}

impl prism_rtl::Job<crate::emit::cpp::Cp> for Rebound {
    fn cycle(&self) -> prism_rtl::Turn<crate::emit::cpp::Cp> {
        let cp = &self.cp;
        let d = &self.d;
        match d {
            crate::lower::model::Do::DoLetElse(p_, _, _) => {
                let cp = cp.clone();
                let p_ = p_.clone();
                call_then(start_pat_names(p_.clone()), move |pat_names_2376: Array<Text>| prism_rtl::Turn::Finished(unbind(&cp, &pat_names_2376)))
            },
            crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTuple(ps), _) => {
                let cp = cp.clone();
                let ps = ps.clone();
                call_then(start_pat_names(crate::lower::model::Pa::PaTuple(ps.clone())), move |pat_names_2432: Array<Text>| prism_rtl::Turn::Finished(unbind(&cp, &pat_names_2432)))
            },
            crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaCtor(c, ps), _) => {
                let c = c.clone();
                let cp = cp.clone();
                let ps = ps.clone();
                call_then(start_pat_names(crate::lower::model::Pa::PaCtor(c.clone(), ps.clone())), move |pat_names_2501: Array<Text>| prism_rtl::Turn::Finished(unbind(&cp, &pat_names_2501)))
            },
            crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaRecord(c, fs, r), _) => {
                let c = c.clone();
                let cp = cp.clone();
                let fs = fs.clone();
                let r = *r;
                call_then(start_pat_names(crate::lower::model::Pa::PaRecord(c.clone(), fs.clone(), r)), move |pat_names_2577: Array<Text>| prism_rtl::Turn::Finished(unbind(&cp, &pat_names_2577)))
            },
            crate::lower::model::Do::DoLet(p_, x) => match let_name(p_) {
                Some(n) => {
                    let pointing_ = if is_pointer_let(cp, p_, x) { pointing(cp, &n) } else { known_value(cp, p_, &n) };
                    let cp = cp.clone();
                    let x = x.clone();
                    call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_2776: Text| if cpp_mentions(&cpp_expr_2776, &var_name(&cp, &n)) {
                        {
                            let fresh = Text::from(format!("{}_{}", &var_name(&cp, &n), &inc(&len(&keys(&cp.renames)))));
                            prism_rtl::Turn::Finished({
                                let mut this: crate::emit::cpp::Cp = pointing_.clone();
                                this.renames = insert(&this.renames, &n, &fresh);
                                this
                            })
                        }
                    } else {
                        prism_rtl::Turn::Finished(pointing_.clone())
                    })
                },
                None => prism_rtl::Turn::Finished(cp.clone()),
            },
            _ => prism_rtl::Turn::Finished(cp.clone()),
        }
    }
}

/// `Start Rebound, x`: what the function value is when passed to `@Run`.
pub fn start_rebound(cp: crate::emit::cpp::Cp, d: crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<crate::emit::cpp::Cp>> {
    Rc::new(Rebound { cp, d })
}

/// ```prism
/// PatNames: unbounded fn Pa -> [Text]
/// ```
pub fn pat_names(p_: &crate::lower::model::Pa) -> Array<Text> {
    match p_ {
        crate::lower::model::Pa::PaBind(n) => Array::from(vec![n.clone()]),
        crate::lower::model::Pa::PaMut(n) => Array::from(vec![n.clone()]),
        crate::lower::model::Pa::PaTyped(q, _) => pat_names(&**q),
        crate::lower::model::Pa::PaCtor(_, ps) => crate::emit::cpp::patterns::concat2(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
            let q = p0;
            prism_rtl::Turn::More(Rc::new(PatNames { p_: q.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))),
        crate::lower::model::Pa::PaRecord(_, fs, _) => crate::emit::cpp::patterns::concat2(&run_to_end(each_job(fs.clone(), Rc::new(move |p0: (Text, crate::lower::model::Pa)| entered(once_job(move || {
            let (_, q) = p0;
            prism_rtl::Turn::More(Rc::new(PatNames { p_: q.clone() }))
        }))) as Rc<dyn Fn((Text, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))),
        crate::lower::model::Pa::PaTuple(ps) => crate::emit::cpp::patterns::concat2(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
            let q = p0;
            prism_rtl::Turn::More(Rc::new(PatNames { p_: q.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))),
        crate::lower::model::Pa::PaSlice(ps) => crate::emit::cpp::patterns::concat2(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
            let q = p0;
            prism_rtl::Turn::More(Rc::new(PatNames { p_: q.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))),
        crate::lower::model::Pa::PaRest(n) => if n == &Text::lit("") { Array::new() } else { Array::from(vec![n.clone()]) },
        _ => Array::new(),
    }
}

/// The step machine of `PatNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatNames: unbounded fn Pa -> [Text]
/// ```
pub struct PatNames {
    pub p_: crate::lower::model::Pa,
}

impl prism_rtl::Job<Array<Text>> for PatNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let p_ = &self.p_;
        match p_ {
            crate::lower::model::Pa::PaBind(n) => prism_rtl::Turn::Finished(Array::from(vec![n.clone()])),
            crate::lower::model::Pa::PaMut(n) => prism_rtl::Turn::Finished(Array::from(vec![n.clone()])),
            crate::lower::model::Pa::PaTyped(q, _) => prism_rtl::Turn::More(Rc::new(PatNames { p_: (**q).clone() })),
            crate::lower::model::Pa::PaCtor(_, ps) => {
                let ps = ps.clone();
                call_value(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                    let q = p0;
                    prism_rtl::Turn::More(Rc::new(PatNames { p_: q.clone() }))
                }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_3237: Array<Array<Text>>| prism_rtl::Turn::Finished(crate::emit::cpp::patterns::concat2(&each_3237)))
            },
            crate::lower::model::Pa::PaRecord(_, fs, _) => {
                let fs = fs.clone();
                call_value(each_job(fs.clone(), Rc::new(move |p0: (Text, crate::lower::model::Pa)| entered(once_job(move || {
                    let (_, q) = p0;
                    prism_rtl::Turn::More(Rc::new(PatNames { p_: q.clone() }))
                }))) as Rc<dyn Fn((Text, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_3305: Array<Array<Text>>| prism_rtl::Turn::Finished(crate::emit::cpp::patterns::concat2(&each_3305)))
            },
            crate::lower::model::Pa::PaTuple(ps) => {
                let ps = ps.clone();
                call_value(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                    let q = p0;
                    prism_rtl::Turn::More(Rc::new(PatNames { p_: q.clone() }))
                }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_3368: Array<Array<Text>>| prism_rtl::Turn::Finished(crate::emit::cpp::patterns::concat2(&each_3368)))
            },
            crate::lower::model::Pa::PaSlice(ps) => {
                let ps = ps.clone();
                call_value(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                    let q = p0;
                    prism_rtl::Turn::More(Rc::new(PatNames { p_: q.clone() }))
                }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_3419: Array<Array<Text>>| prism_rtl::Turn::Finished(crate::emit::cpp::patterns::concat2(&each_3419)))
            },
            crate::lower::model::Pa::PaRest(n) => if n == &Text::lit("") {
                prism_rtl::Turn::Finished(Array::new())
            } else {
                prism_rtl::Turn::Finished(Array::from(vec![n.clone()]))
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start PatNames, x`: what the function value is when passed to `@Run`.
pub fn start_pat_names(p_: crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(PatNames { p_ })
}

/// ```prism
/// ArmNames: unbounded fn XArm -> [Text]
/// ```
pub fn arm_names(a: &crate::lower::model::XArm) -> Array<Text> {
    append(&pat_names(&a.pat), &crate::emit::cpp::patterns::concat2(&run_to_end(each_job(a.conds.clone(), Rc::new(move |p0: crate::lower::model::Cc| entered(once_job(move || {
        let c = p0;
        prism_rtl::Turn::More(Rc::new(CondNames { cc0: c.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))))
}

/// The step machine of `ArmNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArmNames: unbounded fn XArm -> [Text]
/// ```
pub struct ArmNames {
    pub a: crate::lower::model::XArm,
}

impl prism_rtl::Job<Array<Text>> for ArmNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let a = &self.a;
        let a = a.clone();
        call_then(start_pat_names(a.pat.clone()), move |pat_names_3571: Array<Text>| call_value(each_job(a.conds.clone(), Rc::new(move |p0: crate::lower::model::Cc| entered(once_job(move || {
            let c = p0;
            prism_rtl::Turn::More(Rc::new(CondNames { cc0: c.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_3598: Array<Array<Text>>| prism_rtl::Turn::Finished(append(&pat_names_3571, &crate::emit::cpp::patterns::concat2(&each_3598)))))
    }
}

/// `Start ArmNames, x`: what the function value is when passed to `@Run`.
pub fn start_arm_names(a: crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ArmNames { a })
}

/// ```prism
/// CondNames: unbounded fn Cc -> [Text]
/// ```
pub fn cond_names(cc0: &crate::lower::model::Cc) -> Array<Text> {
    match cc0 {
        crate::lower::model::Cc::CcLet(q, _) => pat_names(q),
        crate::lower::model::Cc::CcIf(_) => Array::new(),
    }
}

/// The step machine of `CondNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondNames: unbounded fn Cc -> [Text]
/// ```
pub struct CondNames {
    pub cc0: crate::lower::model::Cc,
}

impl prism_rtl::Job<Array<Text>> for CondNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cc0 = &self.cc0;
        match cc0 {
            crate::lower::model::Cc::CcLet(q, _) => prism_rtl::Turn::More(Rc::new(PatNames { p_: q.clone() })),
            crate::lower::model::Cc::CcIf(_) => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start CondNames, x`: what the function value is when passed to `@Run`.
pub fn start_cond_names(cc0: crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(CondNames { cc0 })
}

/// ```prism
/// Unbind: fn Cp, [Text] -> Cp
/// ```
pub fn unbind(cp: &crate::emit::cpp::Cp, names: &Array<Text>) -> crate::emit::cpp::Cp {
    let mut this: crate::emit::cpp::Cp = cp.clone();
    this.renames = fold(names, &this.renames, &(|m: &Map<Text, Text>, n: &Text| remove(m, n)));
    this.pointers = fold(names, &this.pointers, &(|m: &Map<Text, bool>, n: &Text| remove(m, n)));
    this
}

/// ```prism
/// Pointing: fn Cp, Text -> Cp
/// ```
pub fn pointing(cp: &crate::emit::cpp::Cp, n: &Text) -> crate::emit::cpp::Cp {
    let mut this: crate::emit::cpp::Cp = cp.clone();
    this.pointers = insert(&this.pointers, n, &true);
    this
}

/// ```prism
/// KnownValue: fn Cp, Pa, Text -> Cp
/// ```
pub fn known_value(cp: &crate::emit::cpp::Cp, p_: &crate::lower::model::Pa, n: &Text) -> crate::emit::cpp::Cp {
    match p_ {
        crate::lower::model::Pa::PaTyped(_, _) => {
            let mut this: crate::emit::cpp::Cp = cp.clone();
            this.pointers = insert(&this.pointers, n, &false);
            this
        },
        _ => cp.clone(),
    }
}

/// ```prism
/// IsPointerLet: fn Cp, Pa, Ex -> Bool
/// ```
pub fn is_pointer_let(cp: &crate::emit::cpp::Cp, p_: &crate::lower::model::Pa, x: &crate::lower::model::Ex) -> bool {
    match p_ {
        crate::lower::model::Pa::PaTyped(_, t) => crate::emit::cpp::expr::is_pointer_ty(cp, t),
        _ => 'm4716: {
            if let crate::lower::model::Ex::XCall(m4716_0_0, _) = x && (m4716_0_0 == &Text::lit("prism_rtl::Host::new")) {
                break 'm4716 true;
            }
            if let crate::lower::model::Ex::XCall(m4716_1_0, m4716_1_1) = x && (m4716_1_0 == &Text::lit("Rc::new")) && (m4716_1_1.len() == 1) && let Some(crate::lower::model::Ex::XCall(m4716_1_1_0_0, _)) = index(m4716_1_1, &Nat::from(0u32)) && (&m4716_1_1_0_0 == &Text::lit("Port::new")) {
                break 'm4716 true;
            }
            match crate::emit::cpp::expr::pointer(cp, x) {
                Some(b) => b,
                None => false,
            }
        },
    }
}

/// ```prism
/// Inc: fn Nat -> Nat
/// ```
pub fn inc(n: &Nat) -> Nat {
    n + &Nat::from(1u32)
}

/// ```prism
/// ?LetName: fn Pa -> ?Text
/// ```
pub fn let_name(p_: &crate::lower::model::Pa) -> Option<Text> {
    match p_ {
        crate::lower::model::Pa::PaBind(n) => Some(n.clone()),
        crate::lower::model::Pa::PaMut(n) => Some(n.clone()),
        crate::lower::model::Pa::PaTyped(q, _) => let_name(&**q),
        _ => None,
    }
}

/// ```prism
/// VarName: fn Cp, Text -> Text
/// ```
pub fn var_name(cp: &crate::emit::cpp::Cp, n: &Text) -> Text {
    or(&get(&cp.renames, n), &crate::emit::cpp::cpp_id(n))
}

/// ```prism
/// CppMentions: fn Text, Text -> Bool
/// ```
pub fn cpp_mentions(t: &Text, n: &Text) -> bool {
    let parts = split_on(t, n);
    let k = len(&parts);
    fold(&crate::check::errors::range0(&crate::syntax::lexer::chars::dec(&k)), &false, &(|f: &bool, i: &Nat| *f || (!cpp_ends_ident(&or(&index(&parts, i), &Text::lit(""))) && !cpp_starts_ident(&or(&index(&parts, &(i + &Nat::from(1u32))), &Text::lit(""))))))
}

/// ```prism
/// CppEndsIdent: fn Text -> Bool
/// ```
pub fn cpp_ends_ident(t: &Text) -> bool {
    let c = crate::syntax::lexer::chars::last_char(t);
    (cpp_ident_char(&c) || (&c == &Text::lit("."))) || (&c == &Text::lit(">"))
}

/// ```prism
/// CppStartsIdent: fn Text -> Bool
/// ```
pub fn cpp_starts_ident(t: &Text) -> bool {
    cpp_ident_char(&crate::syntax::lexer::chars::head(t))
}

/// ```prism
/// CppIdentChar: fn Text -> Bool
/// ```
pub fn cpp_ident_char(c: &Text) -> bool {
    (c != &Text::lit("")) && crate::syntax::lexer::chars::contains(&Text::lit("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"), c)
}

/// ```prism
/// CppStatement: unbounded fn Cp, Do -> Text
/// ```
pub fn cpp_statement(cp: &crate::emit::cpp::Cp, d: &crate::lower::model::Do) -> Text {
    match d {
        crate::lower::model::Do::DoLet(p_, x) => cpp_let(cp, cp, p_, x),
        crate::lower::model::Do::DoLetElse(p_, x, e) => {
            let v_ = Text::from(format!("_{}", &or(&first_binder(p_), &Text::lit("m"))));
            Text::from(format!("auto&& {} = {};\nif (!({})) {{ {}; }}\n{}", &v_, &crate::emit::cpp::expr::cpp_expr(cp, x), &crate::emit::cpp::patterns::conds(&crate::emit::cpp::patterns::pat_conds(cp, p_, &v_)), &crate::emit::cpp::expr::cpp_expr(cp, e), &crate::syntax::lexer::chars::join(&crate::emit::cpp::patterns::pat_binds(cp, p_, &v_), &Text::lit("\n"))))
        },
        crate::lower::model::Do::DoAssign(p_, x) => Text::from(format!("{} = {};", &crate::emit::cpp::expr::cpp_expr(cp, p_), &crate::emit::cpp::expr::cpp_expr(cp, x))),
        crate::lower::model::Do::DoWhile(c, body) => crate::emit::cpp::templates::items::block(&Text::from(format!("while ({})", &crate::emit::cpp::expr::cpp_expr(cp, c))), &cpp_statements(cp, body)),
        crate::lower::model::Do::DoWhileLet(p_, x, body) => {
            let v_ = Text::lit("_m");
            let head = Text::from(format!("auto&& _m = {};\nif (!({})) break;", &crate::emit::cpp::expr::cpp_expr(cp, x), &crate::emit::cpp::patterns::conds(&crate::emit::cpp::patterns::pat_conds(cp, p_, &v_))));
            crate::emit::cpp::templates::items::block(&Text::lit("while (true)"), &crate::syntax::lexer::chars::join(&append(&append(&Array::from(vec![head.clone()]), &crate::emit::cpp::patterns::pat_binds(cp, p_, &v_)), &Array::from(vec![cpp_statements(cp, body)])), &Text::lit("\n")))
        },
        crate::lower::model::Do::DoFor(p_, x, body) => cpp_for(cp, p_, x, body),
        crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(l, y)) => crate::emit::cpp::patterns::cpp_break(cp, l, &**y),
        crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreakLoop) => Text::lit("break;"),
        crate::lower::model::Do::DoExpr(x) => Text::from(format!("{};", &crate::emit::cpp::expr::cpp_expr(cp, x))),
        crate::lower::model::Do::DoIf(c, t, e) => Text::from(format!("{}{}", &crate::emit::cpp::templates::items::block(&Text::from(format!("if ({})", &crate::emit::cpp::expr::cpp_expr(cp, c))), &cpp_statements(cp, t)), &cpp_else(cp, e))),
        crate::lower::model::Do::DoIfLet(p_, x, t, e) => cpp_if_let(cp, p_, x, t, e),
        crate::lower::model::Do::DoMatch(x, cases) => cpp_do_match(cp, x, cases),
        crate::lower::model::Do::DoReturn(x) => Text::from(format!("return {};", &crate::emit::cpp::expr::cpp_expr(cp, x))),
        crate::lower::model::Do::DoBlock(body) => crate::emit::cpp::templates::items::braced(&cpp_statements(cp, body)),
        crate::lower::model::Do::DoScope(body) => Text::from(format!("{{ {} }}", &cpp_inline(cp, body))),
        crate::lower::model::Do::DoLine(body) => cpp_inline(cp, body),
        crate::lower::model::Do::DoNote(t) => Text::from(format!("// {}", t)),
    }
}

/// The step machine of `CppStatement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppStatement: unbounded fn Cp, Do -> Text
/// ```
pub struct CppStatement {
    pub cp: crate::emit::cpp::Cp,
    pub d: crate::lower::model::Do,
}

impl prism_rtl::Job<Text> for CppStatement {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let d = &self.d;
        match d {
            crate::lower::model::Do::DoLet(p_, x) => prism_rtl::Turn::More(Rc::new(CppLet { cp: cp.clone(), named_: cp.clone(), p_: p_.clone(), x: x.clone() })),
            crate::lower::model::Do::DoLetElse(p_, x, e) => {
                let cp = cp.clone();
                let e = e.clone();
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_first_binder(p_.clone()), move |first_binder_6010: Option<Text>| {
                    let v_ = Text::from(format!("_{}", &or(&first_binder_6010, &Text::lit("m"))));
                    call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_6056: Text| call_then(crate::emit::cpp::patterns::start_pat_conds(cp.clone(), p_.clone(), v_.clone()), move |pat_conds_6087: Array<Text>| call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), e.clone()), move |cpp_expr_6113: Text| call_then(crate::emit::cpp::patterns::start_pat_binds(cp.clone(), p_.clone(), v_.clone()), move |pat_binds_6140: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("auto&& {} = {};\nif (!({})) {{ {}; }}\n{}", &v_, &cpp_expr_6056, &crate::emit::cpp::patterns::conds(&pat_conds_6087), &cpp_expr_6113, &crate::syntax::lexer::chars::join(&pat_binds_6140, &Text::lit("\n")))))))))
                })
            },
            crate::lower::model::Do::DoAssign(p_, x) => {
                let cp = cp.clone();
                let p_ = p_.clone();
                let x = x.clone();
                call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), p_.clone()), move |cpp_expr_6188: Text| call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_6206: Text| prism_rtl::Turn::Finished(Text::from(format!("{} = {};", &cpp_expr_6188, &cpp_expr_6206)))))
            },
            crate::lower::model::Do::DoWhile(c, body) => {
                let body = body.clone();
                let c = c.clone();
                let cp = cp.clone();
                call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), c.clone()), move |cpp_expr_6259: Text| call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_6278: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::block(&Text::from(format!("while ({})", &cpp_expr_6259)), &cpp_statements_6278))))
            },
            crate::lower::model::Do::DoWhileLet(p_, x, body) => {
                let v_ = Text::lit("_m");
                let body = body.clone();
                let cp = cp.clone();
                let p_ = p_.clone();
                let x = x.clone();
                call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_6383: Text| call_then(crate::emit::cpp::patterns::start_pat_conds(cp.clone(), p_.clone(), v_.clone()), move |pat_conds_6414: Array<Text>| {
                    let head = Text::from(format!("auto&& _m = {};\nif (!({})) break;", &cpp_expr_6383, &crate::emit::cpp::patterns::conds(&pat_conds_6414)));
                    call_then(crate::emit::cpp::patterns::start_pat_binds(cp.clone(), p_.clone(), v_.clone()), move |pat_binds_6507: Array<Text>| call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_6531: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::block(&Text::lit("while (true)"), &crate::syntax::lexer::chars::join(&append(&append(&Array::from(vec![head.clone()]), &pat_binds_6507), &Array::from(vec![cpp_statements_6531])), &Text::lit("\n"))))))
                }))
            },
            crate::lower::model::Do::DoFor(p_, x, body) => prism_rtl::Turn::More(Rc::new(CppFor { cp0: cp.clone(), p_: p_.clone(), x: x.clone(), body: body.clone() })),
            crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(l, y)) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::patterns::CppBreak { cp: cp.clone(), l: l.clone(), y: (**y).clone() })),
            crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreakLoop) => prism_rtl::Turn::Finished(Text::lit("break;")),
            crate::lower::model::Do::DoExpr(x) => {
                let cp = cp.clone();
                let x = x.clone();
                call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_6701: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &cpp_expr_6701))))
            },
            crate::lower::model::Do::DoIf(c, t, e) => {
                let c = c.clone();
                let cp = cp.clone();
                let e = e.clone();
                let t = t.clone();
                call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), c.clone()), move |cpp_expr_6750: Text| call_then(start_cpp_statements(cp.clone(), t.clone()), move |cpp_statements_6769: Text| call_then(start_cpp_else(cp.clone(), e.clone()), move |cpp_else_6791: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &crate::emit::cpp::templates::items::block(&Text::from(format!("if ({})", &cpp_expr_6750)), &cpp_statements_6769), &cpp_else_6791))))))
            },
            crate::lower::model::Do::DoIfLet(p_, x, t, e) => prism_rtl::Turn::More(Rc::new(CppIfLet { cp0: cp.clone(), p_: p_.clone(), x: x.clone(), t: t.clone(), e: e.clone() })),
            crate::lower::model::Do::DoMatch(x, cases) => prism_rtl::Turn::More(Rc::new(CppDoMatch { cp: cp.clone(), x: x.clone(), cases: cases.clone() })),
            crate::lower::model::Do::DoReturn(x) => {
                let cp = cp.clone();
                let x = x.clone();
                call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_6926: Text| prism_rtl::Turn::Finished(Text::from(format!("return {};", &cpp_expr_6926))))
            },
            crate::lower::model::Do::DoBlock(body) => {
                let body = body.clone();
                let cp = cp.clone();
                call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_6969: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::braced(&cpp_statements_6969)))
            },
            crate::lower::model::Do::DoScope(body) => {
                let body = body.clone();
                let cp = cp.clone();
                call_then(start_cpp_inline(cp.clone(), body.clone()), move |cpp_inline_7016: Text| prism_rtl::Turn::Finished(Text::from(format!("{{ {} }}", &cpp_inline_7016))))
            },
            crate::lower::model::Do::DoLine(body) => prism_rtl::Turn::More(Rc::new(CppInline { cp: cp.clone(), dos: body.clone() })),
            crate::lower::model::Do::DoNote(t) => prism_rtl::Turn::Finished(Text::from(format!("// {}", t))),
        }
    }
}

/// `Start CppStatement, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_statement(cp: crate::emit::cpp::Cp, d: crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppStatement { cp, d })
}

/// ```prism
/// CppInline: unbounded fn Cp, [Do] -> Text
/// ```
pub fn cpp_inline(cp: &crate::emit::cpp::Cp, dos: &Array<crate::lower::model::Do>) -> Text {
    crate::syntax::lexer::chars::join(&run_to_end(each_job(dos.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::Do| {
            let cp = cp.clone();
            entered(once_job(move || {
                let d = p0;
                prism_rtl::Turn::More(Rc::new(CppStatement { cp: cp.clone(), d: d.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(" "))
}

/// The step machine of `CppInline`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppInline: unbounded fn Cp, [Do] -> Text
/// ```
pub struct CppInline {
    pub cp: crate::emit::cpp::Cp,
    pub dos: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for CppInline {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let dos = &self.dos;
        let cp = cp.clone();
        let dos = dos.clone();
        call_value(each_job(dos.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: crate::lower::model::Do| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let d = p0;
                    prism_rtl::Turn::More(Rc::new(CppStatement { cp: cp.clone(), d: d.clone() }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_7170: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&each_7170, &Text::lit(" "))))
    }
}

/// `Start CppInline, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_inline(cp: crate::emit::cpp::Cp, dos: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppInline { cp, dos })
}

/// ```prism
/// CppElse: unbounded fn Cp, [Do] -> Text
/// ```
pub fn cpp_else(cp: &crate::emit::cpp::Cp, xs1: &Array<crate::lower::model::Do>) -> Text {
    'c: {
        if let c0_1 = xs1 && (c0_1.len() == 0) {
            break 'c Text::lit("");
        }
        if let c1_1 = xs1 && (c1_1.len() == 1) && let Some(crate::lower::model::Do::DoIf(c, t, e)) = index(c1_1, &Nat::from(0u32)) {
            break 'c Text::from(format!(" else {}", &cpp_statement(cp, &crate::lower::model::Do::DoIf(c.clone(), t.clone(), e.clone()))));
        }
        if let c2_1 = xs1 && (c2_1.len() == 1) && let Some(crate::lower::model::Do::DoIfLet(p_, x, t, e)) = index(c2_1, &Nat::from(0u32)) {
            break 'c Text::from(format!(" else {}", &cpp_statement(cp, &crate::lower::model::Do::DoIfLet(p_.clone(), x.clone(), t.clone(), e.clone()))));
        }
        if let body = xs1 {
            break 'c Text::from(format!(" else {}", &crate::emit::cpp::templates::items::block(&Text::lit(""), &cpp_statements(cp, body))));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `CppElse`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppElse: unbounded fn Cp, [Do] -> Text
/// ```
pub struct CppElse {
    pub cp: crate::emit::cpp::Cp,
    pub xs1: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for CppElse {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let xs1 = &self.xs1;
        'j: {
            if let j0_1 = xs1 && (j0_1.len() == 0) {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let j1_1 = xs1 && (j1_1.len() == 1) && let Some(crate::lower::model::Do::DoIf(c, t, e)) = index(j1_1, &Nat::from(0u32)) {
                break 'j {
                    let cp = cp.clone();
                    call_then(start_cpp_statement(cp.clone(), crate::lower::model::Do::DoIf(c.clone(), t.clone(), e.clone())), move |cpp_statement_7319: Text| prism_rtl::Turn::Finished(Text::from(format!(" else {}", &cpp_statement_7319))))
                };
            }
            if let j2_1 = xs1 && (j2_1.len() == 1) && let Some(crate::lower::model::Do::DoIfLet(p_, x, t, e)) = index(j2_1, &Nat::from(0u32)) {
                break 'j {
                    let cp = cp.clone();
                    call_then(start_cpp_statement(cp.clone(), crate::lower::model::Do::DoIfLet(p_.clone(), x.clone(), t.clone(), e.clone())), move |cpp_statement_7403: Text| prism_rtl::Turn::Finished(Text::from(format!(" else {}", &cpp_statement_7403))))
                };
            }
            if let body = xs1 {
                break 'j {
                    let body = body.clone();
                    let cp = cp.clone();
                    call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_7484: Text| prism_rtl::Turn::Finished(Text::from(format!(" else {}", &crate::emit::cpp::templates::items::block(&Text::lit(""), &cpp_statements_7484)))))
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start CppElse, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_else(cp: crate::emit::cpp::Cp, xs1: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppElse { cp, xs1 })
}

/// ```prism
/// CppLet: unbounded fn Cp, Cp, Pa, Ex -> Text
/// ```
pub fn cpp_let(cp: &crate::emit::cpp::Cp, named_: &crate::emit::cpp::Cp, p_: &crate::lower::model::Pa, x: &crate::lower::model::Ex) -> Text {
    'm7700: {
        if let crate::lower::model::Pa::PaWild = p_ {
            break 'm7700 Text::from(format!("static_cast<void>({});", &crate::emit::cpp::expr::cpp_expr(cp, x)));
        }
        if let crate::lower::model::Pa::PaBind(n) = p_ {
            break 'm7700 match x {
                crate::lower::model::Ex::XRef(_) => Text::from(format!("const auto& {} = {};", &var_name(named_, n), &crate::emit::cpp::expr::cpp_expr(cp, x))),
                _ => Text::from(format!("auto {} = {};", &var_name(named_, n), &crate::emit::cpp::expr::cpp_expr(cp, x))),
            };
        }
        if let crate::lower::model::Pa::PaMut(n) = p_ {
            break 'm7700 Text::from(format!("auto {} = {};", &var_name(named_, n), &crate::emit::cpp::expr::cpp_expr(cp, x)));
        }
        if let crate::lower::model::Pa::PaTyped(m7700_3_0, t) = p_ && let crate::lower::model::Pa::PaBind(n) = &**m7700_3_0 {
            break 'm7700 Text::from(format!("{} {} = {};", &crate::emit::cpp::cpp_type(cp, t), &var_name(named_, n), &crate::emit::cpp::expr::cpp_expr(cp, x)));
        }
        if let crate::lower::model::Pa::PaTyped(m7700_4_0, t) = p_ && let crate::lower::model::Pa::PaMut(n) = &**m7700_4_0 {
            break 'm7700 Text::from(format!("{} {} = {};", &crate::emit::cpp::cpp_type(cp, t), &var_name(named_, n), &crate::emit::cpp::expr::cpp_expr(cp, x)));
        }
        if let crate::lower::model::Pa::PaTuple(ps) = p_ {
            break 'm7700 if fold(ps, &true, &(|f: &bool, q: &crate::lower::model::Pa| *f && is_name(q))) {
                Text::from(format!("auto [{}] = {};", &crate::syntax::lexer::chars::join(&each(ps, &(|q: &crate::lower::model::Pa| pat_name(q))), &Text::lit(", ")), &crate::emit::cpp::expr::cpp_expr(cp, x)))
            } else {
                let_through(cp, p_, x)
            };
        }
        let_through(cp, p_, x)
    }
}

/// The step machine of `CppLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppLet: unbounded fn Cp, Cp, Pa, Ex -> Text
/// ```
pub struct CppLet {
    pub cp: crate::emit::cpp::Cp,
    pub named_: crate::emit::cpp::Cp,
    pub p_: crate::lower::model::Pa,
    pub x: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppLet {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let named_ = &self.named_;
        let p_ = &self.p_;
        let x = &self.x;
        'm7700: {
            if let crate::lower::model::Pa::PaWild = p_ {
                break 'm7700 {
                    let cp = cp.clone();
                    let x = x.clone();
                    call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_7741: Text| prism_rtl::Turn::Finished(Text::from(format!("static_cast<void>({});", &cpp_expr_7741))))
                };
            }
            if let crate::lower::model::Pa::PaBind(n) = p_ {
                break 'm7700 match x {
                    crate::lower::model::Ex::XRef(_) => {
                        let cp = cp.clone();
                        let n = n.clone();
                        let named_ = named_.clone();
                        let x = x.clone();
                        call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_7838: Text| prism_rtl::Turn::Finished(Text::from(format!("const auto& {} = {};", &var_name(&named_, &n), &cpp_expr_7838))))
                    },
                    _ => {
                        let cp = cp.clone();
                        let n = n.clone();
                        let named_ = named_.clone();
                        let x = x.clone();
                        call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_7902: Text| prism_rtl::Turn::Finished(Text::from(format!("auto {} = {};", &var_name(&named_, &n), &cpp_expr_7902))))
                    },
                };
            }
            if let crate::lower::model::Pa::PaMut(n) = p_ {
                break 'm7700 {
                    let cp = cp.clone();
                    let n = n.clone();
                    let named_ = named_.clone();
                    let x = x.clone();
                    call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_7960: Text| prism_rtl::Turn::Finished(Text::from(format!("auto {} = {};", &var_name(&named_, &n), &cpp_expr_7960))))
                };
            }
            if let crate::lower::model::Pa::PaTyped(m7700_3_0, t) = p_ && let crate::lower::model::Pa::PaBind(n) = &**m7700_3_0 {
                break 'm7700 {
                    let cp = cp.clone();
                    let n = n.clone();
                    let named_ = named_.clone();
                    let t = t.clone();
                    let x = x.clone();
                    call_then(crate::emit::cpp::start_cpp_type(cp.clone(), t.clone()), move |cpp_type_8006: Text| call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_8043: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {} = {};", &cpp_type_8006, &var_name(&named_, &n), &cpp_expr_8043)))))
                };
            }
            if let crate::lower::model::Pa::PaTyped(m7700_4_0, t) = p_ && let crate::lower::model::Pa::PaMut(n) = &**m7700_4_0 {
                break 'm7700 {
                    let cp = cp.clone();
                    let n = n.clone();
                    let named_ = named_.clone();
                    let t = t.clone();
                    let x = x.clone();
                    call_then(crate::emit::cpp::start_cpp_type(cp.clone(), t.clone()), move |cpp_type_8088: Text| call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_8125: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {} = {};", &cpp_type_8088, &var_name(&named_, &n), &cpp_expr_8125)))))
                };
            }
            if let crate::lower::model::Pa::PaTuple(ps) = p_ {
                break 'm7700 if fold(ps, &true, &(|f: &bool, q: &crate::lower::model::Pa| *f && is_name(q))) {
                    {
                        let cp = cp.clone();
                        let ps = ps.clone();
                        let x = x.clone();
                        call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_8258: Text| prism_rtl::Turn::Finished(Text::from(format!("auto [{}] = {};", &crate::syntax::lexer::chars::join(&each(&ps, &(|q: &crate::lower::model::Pa| pat_name(q))), &Text::lit(", ")), &cpp_expr_8258))))
                    }
                } else {
                    prism_rtl::Turn::More(Rc::new(LetThrough { cp: cp.clone(), p_: p_.clone(), x: x.clone() }))
                };
            }
            prism_rtl::Turn::More(Rc::new(LetThrough { cp: cp.clone(), p_: p_.clone(), x: x.clone() }))
        }
    }
}

/// `Start CppLet, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_let(cp: crate::emit::cpp::Cp, named_: crate::emit::cpp::Cp, p_: crate::lower::model::Pa, x: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppLet { cp, named_, p_, x })
}

/// ```prism
/// LetThrough: unbounded fn Cp, Pa, Ex -> Text
/// ```
pub fn let_through(cp: &crate::emit::cpp::Cp, p_: &crate::lower::model::Pa, x: &crate::lower::model::Ex) -> Text {
    let t = Text::from(format!("_{}", &or(&first_binder(p_), &Text::lit("t"))));
    Text::from(format!("auto&& {} = {};\n{}", &t, &crate::emit::cpp::expr::cpp_expr(cp, x), &crate::syntax::lexer::chars::join(&crate::emit::cpp::patterns::pat_binds(cp, p_, &t), &Text::lit("\n"))))
}

/// The step machine of `LetThrough`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LetThrough: unbounded fn Cp, Pa, Ex -> Text
/// ```
pub struct LetThrough {
    pub cp: crate::emit::cpp::Cp,
    pub p_: crate::lower::model::Pa,
    pub x: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for LetThrough {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let p_ = &self.p_;
        let x = &self.x;
        let cp = cp.clone();
        let p_ = p_.clone();
        let x = x.clone();
        call_then(start_first_binder(p_.clone()), move |first_binder_8517: Option<Text>| {
            let t = Text::from(format!("_{}", &or(&first_binder_8517, &Text::lit("t"))));
            call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_8559: Text| call_then(crate::emit::cpp::patterns::start_pat_binds(cp.clone(), p_.clone(), t.clone()), move |pat_binds_8583: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("auto&& {} = {};\n{}", &t, &cpp_expr_8559, &crate::syntax::lexer::chars::join(&pat_binds_8583, &Text::lit("\n")))))))
        })
    }
}

/// `Start LetThrough, x`: what the function value is when passed to `@Run`.
pub fn start_let_through(cp: crate::emit::cpp::Cp, p_: crate::lower::model::Pa, x: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(LetThrough { cp, p_, x })
}

/// ```prism
/// ?FirstBinder: unbounded fn Pa -> ?Text
/// ```
pub fn first_binder(p_: &crate::lower::model::Pa) -> Option<Text> {
    match p_ {
        crate::lower::model::Pa::PaBind(n) => Some(n.clone()),
        crate::lower::model::Pa::PaMut(n) => Some(n.clone()),
        crate::lower::model::Pa::PaTyped(q, _) => first_binder(&**q),
        crate::lower::model::Pa::PaCtor(_, ps) => run_to_end(fold_job(ps.clone(), None, Rc::new(move |(p0, p1): (Option<Text>, crate::lower::model::Pa)| entered(once_job(move || {
            let f_opt = p0;
            let q = p1;
            match &f_opt {
                Some(b) => prism_rtl::Turn::Finished(Some(b.clone())),
                None => prism_rtl::Turn::More(Rc::new(FirstBinder { p_: q.clone() })),
            }
        }))) as Rc<dyn Fn((Option<Text>, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Option<Text>>>>)),
        crate::lower::model::Pa::PaTuple(ps) => run_to_end(fold_job(ps.clone(), None, Rc::new(move |(p0, p1): (Option<Text>, crate::lower::model::Pa)| entered(once_job(move || {
            let f_opt = p0;
            let q = p1;
            match &f_opt {
                Some(b) => prism_rtl::Turn::Finished(Some(b.clone())),
                None => prism_rtl::Turn::More(Rc::new(FirstBinder { p_: q.clone() })),
            }
        }))) as Rc<dyn Fn((Option<Text>, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Option<Text>>>>)),
        _ => None,
    }
}

/// The step machine of `FirstBinder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?FirstBinder: unbounded fn Pa -> ?Text
/// ```
pub struct FirstBinder {
    pub p_: crate::lower::model::Pa,
}

impl prism_rtl::Job<Option<Text>> for FirstBinder {
    fn cycle(&self) -> prism_rtl::Turn<Option<Text>> {
        let p_ = &self.p_;
        match p_ {
            crate::lower::model::Pa::PaBind(n) => prism_rtl::Turn::Finished(Some(n.clone())),
            crate::lower::model::Pa::PaMut(n) => prism_rtl::Turn::Finished(Some(n.clone())),
            crate::lower::model::Pa::PaTyped(q, _) => prism_rtl::Turn::More(Rc::new(FirstBinder { p_: (**q).clone() })),
            crate::lower::model::Pa::PaCtor(_, ps) => fold_job(ps.clone(), None, Rc::new(move |(p0, p1): (Option<Text>, crate::lower::model::Pa)| entered(once_job(move || {
                let f_opt = p0;
                let q = p1;
                match &f_opt {
                    Some(b) => prism_rtl::Turn::Finished(Some(b.clone())),
                    None => prism_rtl::Turn::More(Rc::new(FirstBinder { p_: q.clone() })),
                }
            }))) as Rc<dyn Fn((Option<Text>, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Option<Text>>>>).cycle(),
            crate::lower::model::Pa::PaTuple(ps) => fold_job(ps.clone(), None, Rc::new(move |(p0, p1): (Option<Text>, crate::lower::model::Pa)| entered(once_job(move || {
                let f_opt = p0;
                let q = p1;
                match &f_opt {
                    Some(b) => prism_rtl::Turn::Finished(Some(b.clone())),
                    None => prism_rtl::Turn::More(Rc::new(FirstBinder { p_: q.clone() })),
                }
            }))) as Rc<dyn Fn((Option<Text>, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Option<Text>>>>).cycle(),
            _ => prism_rtl::Turn::Finished(None),
        }
    }
}

/// `Start FirstBinder, x`: what the function value is when passed to `@Run`.
pub fn start_first_binder(p_: crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Option<Text>>> {
    Rc::new(FirstBinder { p_ })
}

/// ```prism
/// IsName: fn Pa -> Bool
/// ```
pub fn is_name(pa0: &crate::lower::model::Pa) -> bool {
    match pa0 {
        crate::lower::model::Pa::PaBind(_) => true,
        crate::lower::model::Pa::PaMut(_) => true,
        other => false,
    }
}

/// ```prism
/// PatName: fn Pa -> Text
/// ```
pub fn pat_name(pa0: &crate::lower::model::Pa) -> Text {
    match pa0 {
        crate::lower::model::Pa::PaBind(n) => crate::emit::cpp::cpp_id(n),
        crate::lower::model::Pa::PaMut(n) => crate::emit::cpp::cpp_id(n),
        other => Text::lit("_"),
    }
}

/// ```prism
/// CppIfLet: unbounded fn Cp, Pa, Ex, [Do], [Do] -> Text
/// ```
pub fn cpp_if_let(cp0: &crate::emit::cpp::Cp, p_: &crate::lower::model::Pa, x: &crate::lower::model::Ex, t: &Array<crate::lower::model::Do>, e: &Array<crate::lower::model::Do>) -> Text {
    let cp = unbind(cp0, &pat_names(p_));
    let v_ = Text::lit("_m");
    let head = Text::from(format!("if (auto&& _m = {}; {})", &crate::emit::cpp::expr::cpp_expr(&cp, x), &crate::emit::cpp::patterns::conds(&crate::emit::cpp::patterns::pat_conds(&cp, p_, &v_))));
    let body = crate::syntax::lexer::chars::join(&append(&crate::emit::cpp::patterns::pat_binds(&cp, p_, &v_), &Array::from(vec![cpp_statements(&cp, t)])), &Text::lit("\n"));
    Text::from(format!("{}{}", &crate::emit::cpp::templates::items::block(&head, &body), &cpp_else(&cp, e)))
}

/// The step machine of `CppIfLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppIfLet: unbounded fn Cp, Pa, Ex, [Do], [Do] -> Text
/// ```
pub struct CppIfLet {
    pub cp0: crate::emit::cpp::Cp,
    pub p_: crate::lower::model::Pa,
    pub x: crate::lower::model::Ex,
    pub t: Array<crate::lower::model::Do>,
    pub e: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for CppIfLet {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp0 = &self.cp0;
        let p_ = &self.p_;
        let x = &self.x;
        let t = &self.t;
        let e = &self.e;
        let cp0 = cp0.clone();
        let e = e.clone();
        let p_ = p_.clone();
        let t = t.clone();
        let x = x.clone();
        call_then(start_pat_names(p_.clone()), move |pat_names_9370: Array<Text>| {
            let cp = unbind(&cp0, &pat_names_9370);
            let v_ = Text::lit("_m");
            call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_9432: Text| call_then(crate::emit::cpp::patterns::start_pat_conds(cp.clone(), p_.clone(), v_.clone()), move |pat_conds_9456: Array<Text>| {
                let head = Text::from(format!("if (auto&& _m = {}; {})", &cpp_expr_9432, &crate::emit::cpp::patterns::conds(&pat_conds_9456)));
                call_then(crate::emit::cpp::patterns::start_pat_binds(cp.clone(), p_.clone(), v_.clone()), move |pat_binds_9507: Array<Text>| call_then(start_cpp_statements(cp.clone(), t.clone()), move |cpp_statements_9530: Text| {
                    let body = crate::syntax::lexer::chars::join(&append(&pat_binds_9507, &Array::from(vec![cpp_statements_9530])), &Text::lit("\n"));
                    call_then(start_cpp_else(cp.clone(), e.clone()), move |cpp_else_9584: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &crate::emit::cpp::templates::items::block(&head, &body), &cpp_else_9584))))
                }))
            }))
        })
    }
}

/// `Start CppIfLet, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_if_let(cp0: crate::emit::cpp::Cp, p_: crate::lower::model::Pa, x: crate::lower::model::Ex, t: Array<crate::lower::model::Do>, e: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppIfLet { cp0, p_, x, t, e })
}

/// ```prism
/// CppDoMatch: unbounded fn Cp, Ex, [((Pa, [Do]))] -> Text
/// ```
pub fn cpp_do_match(cp: &crate::emit::cpp::Cp, x: &crate::lower::model::Ex, cases: &Array<(crate::lower::model::Pa, Array<crate::lower::model::Do>)>) -> Text {
    let v_ = Text::lit("_m");
    let arms = run_to_end(each_job(cases.clone(), {
        let cp = cp.clone();
        let v_ = v_.clone();
        Rc::new(move |p0: (crate::lower::model::Pa, Array<crate::lower::model::Do>)| {
            let cp = cp.clone();
            let v_ = v_.clone();
            entered(once_job(move || {
                let (p_, body) = p0;
                call_then(crate::emit::cpp::patterns::start_pat_conds(cp.clone(), p_.clone(), v_.clone()), move |pat_conds_9764: Array<Text>| {
                    let tests = pat_conds_9764;
                    call_then(crate::emit::cpp::patterns::start_pat_binds(cp.clone(), p_.clone(), v_.clone()), move |pat_binds_9816: Array<Text>| call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_9839: Text| {
                        let inner = crate::syntax::lexer::chars::join(&append(&pat_binds_9816, &Array::from(vec![cpp_statements_9839])), &Text::lit("\n"));
                        prism_rtl::Turn::Finished((tests.clone(), inner.clone()))
                    }))
                })
            }))
        }) as Rc<dyn Fn((crate::lower::model::Pa, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Text)>>>
    }));
    let blocks = each(&crate::check::errors::range0(&len(&arms)), &(|i: &Nat| {
        let (tests, inner) = or(&index(&arms, i), &(Array::new(), Text::lit("")));
        let head = if i == &Nat::from(0u32) {
            Text::from(format!("if ({})", &crate::emit::cpp::patterns::conds(&tests)))
        } else {
            if &len(&tests) == &Nat::from(0u32) {
                Text::lit("else")
            } else {
                Text::from(format!("else if ({})", &crate::emit::cpp::patterns::conds(&tests)))
            }
        };
        crate::emit::cpp::templates::items::block(&head, &inner)
    }));
    crate::emit::cpp::templates::items::braced(&Text::from(format!("auto&& _m = {};\n{}", &crate::emit::cpp::expr::cpp_expr(cp, x), &crate::syntax::lexer::chars::join(&blocks, &Text::lit(" ")))))
}

/// The step machine of `CppDoMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppDoMatch: unbounded fn Cp, Ex, [((Pa, [Do]))] -> Text
/// ```
pub struct CppDoMatch {
    pub cp: crate::emit::cpp::Cp,
    pub x: crate::lower::model::Ex,
    pub cases: Array<(crate::lower::model::Pa, Array<crate::lower::model::Do>)>,
}

impl prism_rtl::Job<Text> for CppDoMatch {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let x = &self.x;
        let cases = &self.cases;
        let v_ = Text::lit("_m");
        let cases = cases.clone();
        let cp = cp.clone();
        let x = x.clone();
        call_value(each_job(cases.clone(), {
            let cp = cp.clone();
            let v_ = v_.clone();
            Rc::new(move |p0: (crate::lower::model::Pa, Array<crate::lower::model::Do>)| {
                let cp = cp.clone();
                let v_ = v_.clone();
                entered(once_job(move || {
                    let (p_, body) = p0;
                    call_then(crate::emit::cpp::patterns::start_pat_conds(cp.clone(), p_.clone(), v_.clone()), move |pat_conds_9764: Array<Text>| {
                        let tests = pat_conds_9764;
                        call_then(crate::emit::cpp::patterns::start_pat_binds(cp.clone(), p_.clone(), v_.clone()), move |pat_binds_9816: Array<Text>| call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_9839: Text| {
                            let inner = crate::syntax::lexer::chars::join(&append(&pat_binds_9816, &Array::from(vec![cpp_statements_9839])), &Text::lit("\n"));
                            prism_rtl::Turn::Finished((tests.clone(), inner.clone()))
                        }))
                    })
                }))
            }) as Rc<dyn Fn((crate::lower::model::Pa, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Text)>>>
        }), move |each_9717: Array<(Array<Text>, Text)>| {
            let arms = each_9717;
            let blocks = each(&crate::check::errors::range0(&len(&arms)), &(|i: &Nat| {
                let (tests, inner) = or(&index(&arms, i), &(Array::new(), Text::lit("")));
                let head = if i == &Nat::from(0u32) {
                    Text::from(format!("if ({})", &crate::emit::cpp::patterns::conds(&tests)))
                } else {
                    if &len(&tests) == &Nat::from(0u32) {
                        Text::lit("else")
                    } else {
                        Text::from(format!("else if ({})", &crate::emit::cpp::patterns::conds(&tests)))
                    }
                };
                crate::emit::cpp::templates::items::block(&head, &inner)
            }));
            call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_10169: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::braced(&Text::from(format!("auto&& _m = {};\n{}", &cpp_expr_10169, &crate::syntax::lexer::chars::join(&blocks, &Text::lit(" ")))))))
        })
    }
}

/// `Start CppDoMatch, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_do_match(cp: crate::emit::cpp::Cp, x: crate::lower::model::Ex, cases: Array<(crate::lower::model::Pa, Array<crate::lower::model::Do>)>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppDoMatch { cp, x, cases })
}

/// ```prism
/// CppFor: unbounded fn Cp, Pa, Ex, [Do] -> Text
/// ```
pub fn cpp_for(cp0: &crate::emit::cpp::Cp, p_: &crate::lower::model::Pa, x: &crate::lower::model::Ex, body: &Array<crate::lower::model::Do>) -> Text {
    cpp_for_in(&unbind(cp0, &pat_names(p_)), p_, &crate::emit::cpp::expr::cpp_expr(cp0, x), body)
}

/// The step machine of `CppFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppFor: unbounded fn Cp, Pa, Ex, [Do] -> Text
/// ```
pub struct CppFor {
    pub cp0: crate::emit::cpp::Cp,
    pub p_: crate::lower::model::Pa,
    pub x: crate::lower::model::Ex,
    pub body: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for CppFor {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp0 = &self.cp0;
        let p_ = &self.p_;
        let x = &self.x;
        let body = &self.body;
        let body = body.clone();
        let cp0 = cp0.clone();
        let p_ = p_.clone();
        let x = x.clone();
        call_then(start_pat_names(p_.clone()), move |pat_names_10383: Array<Text>| call_then(crate::emit::cpp::expr::start_cpp_expr(cp0.clone(), x.clone()), move |cpp_expr_10401: Text| prism_rtl::Turn::More(Rc::new(CppForIn { cp: unbind(&cp0, &pat_names_10383), p_: p_.clone(), xs: cpp_expr_10401, body: body.clone() }))))
    }
}

/// `Start CppFor, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_for(cp0: crate::emit::cpp::Cp, p_: crate::lower::model::Pa, x: crate::lower::model::Ex, body: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppFor { cp0, p_, x, body })
}

/// ```prism
/// CppForIn: unbounded fn Cp, Pa, Text, [Do] -> Text
/// ```
pub fn cpp_for_in(cp: &crate::emit::cpp::Cp, p_: &crate::lower::model::Pa, xs: &Text, body: &Array<crate::lower::model::Do>) -> Text {
    match p_ {
        crate::lower::model::Pa::PaBind(n) => crate::emit::cpp::templates::items::block(&Text::from(format!("for (auto&& {} : {})", &crate::emit::cpp::cpp_id(n), xs)), &cpp_statements(cp, body)),
        crate::lower::model::Pa::PaMut(n) => crate::emit::cpp::templates::items::block(&Text::from(format!("for (auto {} : {})", &crate::emit::cpp::cpp_id(n), xs)), &cpp_statements(cp, body)),
        crate::lower::model::Pa::PaTuple(ps) => if fold(ps, &true, &(|f: &bool, q: &crate::lower::model::Pa| *f && is_name(q))) {
            crate::emit::cpp::templates::items::block(&Text::from(format!("for (auto&& [{}] : {})", &crate::syntax::lexer::chars::join(&each(ps, &(|q: &crate::lower::model::Pa| pat_name(q))), &Text::lit(", ")), xs)), &cpp_statements(cp, body))
        } else {
            crate::emit::cpp::templates::items::block(&Text::from(format!("for (auto&& _e : {})", xs)), &crate::syntax::lexer::chars::join(&append(&crate::emit::cpp::patterns::pat_binds(cp, p_, &Text::lit("_e")), &Array::from(vec![cpp_statements(cp, body)])), &Text::lit("\n")))
        },
        _ => crate::emit::cpp::templates::items::block(&Text::from(format!("for (auto&& _e : {})", xs)), &crate::syntax::lexer::chars::join(&append(&crate::emit::cpp::patterns::pat_binds(cp, p_, &Text::lit("_e")), &Array::from(vec![cpp_statements(cp, body)])), &Text::lit("\n"))),
    }
}

/// The step machine of `CppForIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppForIn: unbounded fn Cp, Pa, Text, [Do] -> Text
/// ```
pub struct CppForIn {
    pub cp: crate::emit::cpp::Cp,
    pub p_: crate::lower::model::Pa,
    pub xs: Text,
    pub body: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for CppForIn {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let p_ = &self.p_;
        let xs = &self.xs;
        let body = &self.body;
        match p_ {
            crate::lower::model::Pa::PaBind(n) => {
                let body = body.clone();
                let cp = cp.clone();
                let n = n.clone();
                let xs = xs.clone();
                call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_10567: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::block(&Text::from(format!("for (auto&& {} : {})", &crate::emit::cpp::cpp_id(&n), &xs)), &cpp_statements_10567)))
            },
            crate::lower::model::Pa::PaMut(n) => {
                let body = body.clone();
                let cp = cp.clone();
                let n = n.clone();
                let xs = xs.clone();
                call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_10642: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::block(&Text::from(format!("for (auto {} : {})", &crate::emit::cpp::cpp_id(&n), &xs)), &cpp_statements_10642)))
            },
            crate::lower::model::Pa::PaTuple(ps) => if fold(ps, &true, &(|f: &bool, q: &crate::lower::model::Pa| *f && is_name(q))) {
                {
                    let body = body.clone();
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let xs = xs.clone();
                    call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_10803: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::block(&Text::from(format!("for (auto&& [{}] : {})", &crate::syntax::lexer::chars::join(&each(&ps, &(|q: &crate::lower::model::Pa| pat_name(q))), &Text::lit(", ")), &xs)), &cpp_statements_10803)))
                }
            } else {
                {
                    let body = body.clone();
                    let cp = cp.clone();
                    let p_ = p_.clone();
                    let xs = xs.clone();
                    call_then(crate::emit::cpp::patterns::start_pat_binds(cp.clone(), p_.clone(), Text::lit("_e")), move |pat_binds_10888: Array<Text>| call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_10914: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::block(&Text::from(format!("for (auto&& _e : {})", &xs)), &crate::syntax::lexer::chars::join(&append(&pat_binds_10888, &Array::from(vec![cpp_statements_10914])), &Text::lit("\n"))))))
                }
            },
            _ => {
                let body = body.clone();
                let cp = cp.clone();
                let p_ = p_.clone();
                let xs = xs.clone();
                call_then(crate::emit::cpp::patterns::start_pat_binds(cp.clone(), p_.clone(), Text::lit("_e")), move |pat_binds_11010: Array<Text>| call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_11036: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::block(&Text::from(format!("for (auto&& _e : {})", &xs)), &crate::syntax::lexer::chars::join(&append(&pat_binds_11010, &Array::from(vec![cpp_statements_11036])), &Text::lit("\n"))))))
            },
        }
    }
}

/// `Start CppForIn, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_for_in(cp: crate::emit::cpp::Cp, p_: crate::lower::model::Pa, xs: Text, body: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppForIn { cp, p_, xs, body })
}

/// ```prism
/// CppBody: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_body(cp: &crate::emit::cpp::Cp, ex1: &crate::lower::model::Ex) -> Text {
    match ex1 {
        crate::lower::model::Ex::XBlock(dos, e) => {
            let (st, cp2) = cpp_statements_cp(cp, dos);
            if &len(dos) == &Nat::from(0u32) {
                cpp_body(cp, &**e)
            } else {
                Text::from(format!("{}\n{}", &st, &cpp_body(&cp2, &**e)))
            }
        },
        crate::lower::model::Ex::XMatch(s, arms, fallback, t) => crate::emit::cpp::patterns::return_match(cp, &**s, arms, t),
        crate::lower::model::Ex::XChain(label, s, arms, t) => crate::emit::cpp::patterns::return_match(cp, &**s, arms, t),
        x => if crate::emit::cpp::patterns::leaves(x) {
            Text::from(format!("{};", &crate::emit::cpp::expr::cpp_expr(cp, x)))
        } else {
            Text::from(format!("return {};", &crate::emit::cpp::expr::cpp_expr(cp, x)))
        },
    }
}

/// The step machine of `CppBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppBody: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppBody {
    pub cp: crate::emit::cpp::Cp,
    pub ex1: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppBody {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let ex1 = &self.ex1;
        match ex1 {
            crate::lower::model::Ex::XBlock(dos, e) => {
                let cp = cp.clone();
                let dos = dos.clone();
                let e = (**e).clone();
                call_then(start_cpp_statements_cp(cp.clone(), dos.clone()), move |cpp_statements_cp_11224: (Text, crate::emit::cpp::Cp)| {
                    let (st, cp2) = cpp_statements_cp_11224;
                    if &len(&dos) == &Nat::from(0u32) {
                        prism_rtl::Turn::More(Rc::new(CppBody { cp: cp.clone(), ex1: e.clone() }))
                    } else {
                        call_then(start_cpp_body(cp2.clone(), e.clone()), move |cpp_body_11299: Text| prism_rtl::Turn::Finished(Text::from(format!("{}\n{}", &st, &cpp_body_11299))))
                    }
                })
            },
            crate::lower::model::Ex::XMatch(s, arms, fallback, t) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::patterns::ReturnMatch { cp: cp.clone(), s: (**s).clone(), arms: arms.clone(), out_ty3: t.clone() })),
            crate::lower::model::Ex::XChain(label, s, arms, t) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::patterns::ReturnMatch { cp: cp.clone(), s: (**s).clone(), arms: arms.clone(), out_ty3: t.clone() })),
            x => if crate::emit::cpp::patterns::leaves(x) {
                {
                    let cp = cp.clone();
                    let x = x.clone();
                    call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_11495: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &cpp_expr_11495))))
                }
            } else {
                {
                    let cp = cp.clone();
                    let x = x.clone();
                    call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_11527: Text| prism_rtl::Turn::Finished(Text::from(format!("return {};", &cpp_expr_11527))))
                }
            },
        }
    }
}

/// `Start CppBody, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_body(cp: crate::emit::cpp::Cp, ex1: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppBody { cp, ex1 })
}
