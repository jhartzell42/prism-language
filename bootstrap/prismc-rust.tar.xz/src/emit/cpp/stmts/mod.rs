//! The module `Emit.Cpp.Stmts`, from `target/bootstrap/src/prismc/emit/cpp/stmts.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// CppStatements: unbounded fn Cp, [Do] -> Text
/// ```
pub fn cpp_statements(cp_p0: &crate::emit::cpp::Cp, dos_p1: &Array<crate::lower::model::Do>) -> Text {
    let (st_p2, _) = cpp_statements_cp(cp_p0, dos_p1);
    st_p2.clone()
}

/// The step machine of `CppStatements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppStatements: unbounded fn Cp, [Do] -> Text
/// ```
pub struct CppStatements {
    pub cp_p0: crate::emit::cpp::Cp,
    pub dos_p1: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for CppStatements {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let dos_p1 = &self.dos_p1;
        let cp_p0 = cp_p0.clone();
        let dos_p1 = dos_p1.clone();
        call_then(start_cpp_statements_cp(cp_p0.clone(), dos_p1.clone()), move |cpp_statements_cp_1153: (Text, crate::emit::cpp::Cp)| {
            let (st_p2, _) = cpp_statements_cp_1153;
            prism_rtl::Turn::Finished(st_p2.clone())
        })
    }
}

/// `Start CppStatements, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_statements(cp_p0: crate::emit::cpp::Cp, dos_p1: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppStatements { cp_p0, dos_p1 })
}

/// ```prism
/// CppStatementsCp: unbounded fn Cp, [Do] -> ((Text, Cp))
/// ```
pub fn cpp_statements_cp(cp_p0: &crate::emit::cpp::Cp, dos_p1: &Array<crate::lower::model::Do>) -> (Text, crate::emit::cpp::Cp) {
    let (lines_p9, last_pa) = run_to_end(fold_job(dos_p1.clone(), (Array::new(), cp_p0.clone()), Rc::new(move |(p0, p1): ((Array<Text>, crate::emit::cpp::Cp), crate::lower::model::Do)| entered(once_job(move || {
        let (acc_p2, c_p3) = p0;
        let d_p4 = p1;
        call_then(start_rebound(c_p3.clone(), d_p4.clone()), move |rebound_1580: crate::emit::cpp::Cp| {
            let c2_p5 = rebound_1580;
            let line_p6 = match &d_p4 {
                crate::lower::model::Do::DoLet(p_p7, x_p8) => cpp_let(&c_p3, &c2_p5, p_p7, x_p8),
                _ => cpp_statement(&c2_p5, &d_p4),
            };
            prism_rtl::Turn::Finished((push(&acc_p2, &line_p6), c2_p5.clone()))
        })
    }))) as Rc<dyn Fn(((Array<Text>, crate::emit::cpp::Cp), crate::lower::model::Do)) -> Rc<dyn prism_rtl::Job<(Array<Text>, crate::emit::cpp::Cp)>>>));
    (crate::syntax::lexer::chars::join(&lines_p9, &Text::lit("\n")), last_pa.clone())
}

/// The step machine of `CppStatementsCp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppStatementsCp: unbounded fn Cp, [Do] -> ((Text, Cp))
/// ```
pub struct CppStatementsCp {
    pub cp_p0: crate::emit::cpp::Cp,
    pub dos_p1: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<(Text, crate::emit::cpp::Cp)> for CppStatementsCp {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::emit::cpp::Cp)> {
        let cp_p0 = &self.cp_p0;
        let dos_p1 = &self.dos_p1;
        let cp_p0 = cp_p0.clone();
        let dos_p1 = dos_p1.clone();
        call_value(fold_job(dos_p1.clone(), (Array::new(), cp_p0.clone()), Rc::new(move |(p0, p1): ((Array<Text>, crate::emit::cpp::Cp), crate::lower::model::Do)| entered(once_job(move || {
            let (acc_p2, c_p3) = p0;
            let d_p4 = p1;
            call_then(start_rebound(c_p3.clone(), d_p4.clone()), move |rebound_1580: crate::emit::cpp::Cp| {
                let c2_p5 = rebound_1580;
                let line_p6 = match &d_p4 {
                    crate::lower::model::Do::DoLet(p_p7, x_p8) => cpp_let(&c_p3, &c2_p5, p_p7, x_p8),
                    _ => cpp_statement(&c2_p5, &d_p4),
                };
                prism_rtl::Turn::Finished((push(&acc_p2, &line_p6), c2_p5.clone()))
            })
        }))) as Rc<dyn Fn(((Array<Text>, crate::emit::cpp::Cp), crate::lower::model::Do)) -> Rc<dyn prism_rtl::Job<(Array<Text>, crate::emit::cpp::Cp)>>>), move |fold_1522: (Array<Text>, crate::emit::cpp::Cp)| {
            let (lines_p9, last_pa) = fold_1522;
            prism_rtl::Turn::Finished((crate::syntax::lexer::chars::join(&lines_p9, &Text::lit("\n")), last_pa.clone()))
        })
    }
}

/// `Start CppStatementsCp, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_statements_cp(cp_p0: crate::emit::cpp::Cp, dos_p1: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<(Text, crate::emit::cpp::Cp)>> {
    Rc::new(CppStatementsCp { cp_p0, dos_p1 })
}

/// ```prism
/// Unvexed: fn Text -> Text
/// ```
pub fn unvexed(t_p0: &Text) -> Text {
    let head_p1 = or(&index(&split_on(t_p0, &Text::lit("(")), &Nat::from(0u32)), &Text::lit(""));
    let type_like_p2 = crate::syntax::lexer::chars::contains(&head_p1, &Text::lit(":")) || crate::syntax::lexer::chars::contains(&Text::lit("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), &crate::syntax::lexer::chars::head(&head_p1));
    let vexing_p3 = (((&crate::syntax::lexer::chars::last_char(t_p0) == &Text::lit(")")) && !crate::syntax::lexer::chars::contains(&head_p1, &Text::lit(" "))) && (&head_p1 != &Text::lit(""))) && type_like_p2;
    if vexing_p3 { Text::from(format!("({})", t_p0)) } else { t_p0.clone() }
}

/// ```prism
/// Rebound: unbounded fn Cp, Do -> Cp
/// ```
pub fn rebound(cp_p0: &crate::emit::cpp::Cp, d_p1: &crate::lower::model::Do) -> crate::emit::cpp::Cp {
    match d_p1 {
        crate::lower::model::Do::DoLetElse(p_p2, _, _) => unbind(cp_p0, &pat_names(p_p2)),
        crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTuple(ps_p3), _) => unbind(cp_p0, &pat_names(&crate::lower::model::Pa::PaTuple(ps_p3.clone()))),
        crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaCtor(c_p4, ps_p5), _) => unbind(cp_p0, &pat_names(&crate::lower::model::Pa::PaCtor(c_p4.clone(), ps_p5.clone()))),
        crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaRecord(c_p6, fs_p7, r_p8), _) => unbind(cp_p0, &pat_names(&crate::lower::model::Pa::PaRecord(c_p6.clone(), fs_p7.clone(), *r_p8))),
        crate::lower::model::Do::DoLet(p_p9, x_pa) => match let_name(p_p9) {
            Some(n_pb) => {
                let pointing_pc = if is_pointer_let(cp_p0, p_p9, x_pa) {
                    pointing(cp_p0, &n_pb)
                } else {
                    known_value(cp_p0, p_p9, &n_pb)
                };
                let held_pd = if is_value_let(p_p9, x_pa) {
                    owning(&pointing_pc, &n_pb)
                } else {
                    disowning(&pointing_pc, &n_pb)
                };
                let holding_pe = match p_p9 {
                    crate::lower::model::Pa::PaTyped(_, t_pf) => {
                        let mut this: crate::emit::cpp::Cp = held_pd.clone();
                        this.local_types = insert(&this.local_types, &n_pb, t_pf);
                        this
                    },
                    _ => {
                        let mut this: crate::emit::cpp::Cp = held_pd.clone();
                        this.local_types = remove(&this.local_types, &n_pb);
                        this
                    },
                };
                if cpp_mentions(&crate::emit::cpp::expr::cpp_expr(cp_p0, x_pa), &var_name(cp_p0, &n_pb)) {
                    {
                        let fresh_pg = Text::from(format!("{}_{}", &var_name(cp_p0, &n_pb), &inc(&len(&keys(&cp_p0.renames)))));
                        {
                            let mut this: crate::emit::cpp::Cp = holding_pe.clone();
                            this.renames = insert(&this.renames, &n_pb, &fresh_pg);
                            this
                        }
                    }
                } else {
                    holding_pe.clone()
                }
            },
            None => cp_p0.clone(),
        },
        _ => cp_p0.clone(),
    }
}

/// The step machine of `Rebound`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Rebound: unbounded fn Cp, Do -> Cp
/// ```
pub struct Rebound {
    pub cp_p0: crate::emit::cpp::Cp,
    pub d_p1: crate::lower::model::Do,
}

impl prism_rtl::Job<crate::emit::cpp::Cp> for Rebound {
    fn cycle(&self) -> prism_rtl::Turn<crate::emit::cpp::Cp> {
        let cp_p0 = &self.cp_p0;
        let d_p1 = &self.d_p1;
        match d_p1 {
            crate::lower::model::Do::DoLetElse(p_p2, _, _) => {
                let cp_p0 = cp_p0.clone();
                let p_p2 = p_p2.clone();
                call_then(start_pat_names(p_p2.clone()), move |pat_names_2376: Array<Text>| prism_rtl::Turn::Finished(unbind(&cp_p0, &pat_names_2376)))
            },
            crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTuple(ps_p3), _) => {
                let cp_p0 = cp_p0.clone();
                let ps_p3 = ps_p3.clone();
                call_then(start_pat_names(crate::lower::model::Pa::PaTuple(ps_p3.clone())), move |pat_names_2432: Array<Text>| prism_rtl::Turn::Finished(unbind(&cp_p0, &pat_names_2432)))
            },
            crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaCtor(c_p4, ps_p5), _) => {
                let c_p4 = c_p4.clone();
                let cp_p0 = cp_p0.clone();
                let ps_p5 = ps_p5.clone();
                call_then(start_pat_names(crate::lower::model::Pa::PaCtor(c_p4.clone(), ps_p5.clone())), move |pat_names_2501: Array<Text>| prism_rtl::Turn::Finished(unbind(&cp_p0, &pat_names_2501)))
            },
            crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaRecord(c_p6, fs_p7, r_p8), _) => {
                let c_p6 = c_p6.clone();
                let cp_p0 = cp_p0.clone();
                let fs_p7 = fs_p7.clone();
                let r_p8 = *r_p8;
                call_then(start_pat_names(crate::lower::model::Pa::PaRecord(c_p6.clone(), fs_p7.clone(), r_p8)), move |pat_names_2577: Array<Text>| prism_rtl::Turn::Finished(unbind(&cp_p0, &pat_names_2577)))
            },
            crate::lower::model::Do::DoLet(p_p9, x_pa) => match let_name(p_p9) {
                Some(n_pb) => {
                    let pointing_pc = if is_pointer_let(cp_p0, p_p9, x_pa) {
                        pointing(cp_p0, &n_pb)
                    } else {
                        known_value(cp_p0, p_p9, &n_pb)
                    };
                    let held_pd = if is_value_let(p_p9, x_pa) {
                        owning(&pointing_pc, &n_pb)
                    } else {
                        disowning(&pointing_pc, &n_pb)
                    };
                    let holding_pe = match p_p9 {
                        crate::lower::model::Pa::PaTyped(_, t_pf) => {
                            let mut this: crate::emit::cpp::Cp = held_pd.clone();
                            this.local_types = insert(&this.local_types, &n_pb, t_pf);
                            this
                        },
                        _ => {
                            let mut this: crate::emit::cpp::Cp = held_pd.clone();
                            this.local_types = remove(&this.local_types, &n_pb);
                            this
                        },
                    };
                    let cp_p0 = cp_p0.clone();
                    let x_pa = x_pa.clone();
                    call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), x_pa.clone()), move |cpp_expr_3114: Text| if cpp_mentions(&cpp_expr_3114, &var_name(&cp_p0, &n_pb)) {
                        {
                            let fresh_pg = Text::from(format!("{}_{}", &var_name(&cp_p0, &n_pb), &inc(&len(&keys(&cp_p0.renames)))));
                            prism_rtl::Turn::Finished({
                                let mut this: crate::emit::cpp::Cp = holding_pe.clone();
                                this.renames = insert(&this.renames, &n_pb, &fresh_pg);
                                this
                            })
                        }
                    } else {
                        prism_rtl::Turn::Finished(holding_pe.clone())
                    })
                },
                None => prism_rtl::Turn::Finished(cp_p0.clone()),
            },
            _ => prism_rtl::Turn::Finished(cp_p0.clone()),
        }
    }
}

/// `Start Rebound, x`: what the function value is when passed to `@Run`.
pub fn start_rebound(cp_p0: crate::emit::cpp::Cp, d_p1: crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<crate::emit::cpp::Cp>> {
    Rc::new(Rebound { cp_p0, d_p1 })
}

/// ```prism
/// IsValueLet: fn Pa, Ex -> Bool
/// ```
pub fn is_value_let(p_p0: &crate::lower::model::Pa, x_p1: &crate::lower::model::Ex) -> bool {
    match p_p0 {
        crate::lower::model::Pa::PaBind(_) => match x_p1 {
            crate::lower::model::Ex::XRef(_) => false,
            _ => true,
        },
        crate::lower::model::Pa::PaMut(_) => true,
        crate::lower::model::Pa::PaTyped(_, crate::lower::model::OutTy::OutRef(_)) => false,
        crate::lower::model::Pa::PaTyped(_, _) => true,
        _ => false,
    }
}

/// ```prism
/// Owning: fn Cp, Text -> Cp
/// ```
pub fn owning(cp_p0: &crate::emit::cpp::Cp, n_p1: &Text) -> crate::emit::cpp::Cp {
    let mut this: crate::emit::cpp::Cp = cp_p0.clone();
    this.owned = insert(&this.owned, n_p1, &true);
    this
}

/// ```prism
/// Disowning: fn Cp, Text -> Cp
/// ```
pub fn disowning(cp_p0: &crate::emit::cpp::Cp, n_p1: &Text) -> crate::emit::cpp::Cp {
    let mut this: crate::emit::cpp::Cp = cp_p0.clone();
    this.owned = remove(&this.owned, n_p1);
    this
}

/// ```prism
/// Captured: fn Cp -> Cp
/// ```
pub fn captured(cp_p0: &crate::emit::cpp::Cp) -> crate::emit::cpp::Cp {
    let mut this: crate::emit::cpp::Cp = cp_p0.clone();
    this.owned = Map::new();
    this.move_captures = Array::new();
    this
}

/// ```prism
/// PatNames: unbounded fn Pa -> [Text]
/// ```
pub fn pat_names(p_p0: &crate::lower::model::Pa) -> Array<Text> {
    match p_p0 {
        crate::lower::model::Pa::PaBind(n_p1) => Array::from(vec![n_p1.clone()]),
        crate::lower::model::Pa::PaMut(n_p2) => Array::from(vec![n_p2.clone()]),
        crate::lower::model::Pa::PaTyped(q_p3, _) => pat_names(&**q_p3),
        crate::lower::model::Pa::PaCtor(_, ps_p4) => crate::emit::cpp::patterns::concat2(&run_to_end(each_job(ps_p4.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
            let q_p5 = p0;
            prism_rtl::Turn::More(Rc::new(PatNames { p_p0: q_p5.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))),
        crate::lower::model::Pa::PaRecord(_, fs_p6, _) => crate::emit::cpp::patterns::concat2(&run_to_end(each_job(fs_p6.clone(), Rc::new(move |p0: (Text, crate::lower::model::Pa)| entered(once_job(move || {
            let (_, q_p7) = p0;
            prism_rtl::Turn::More(Rc::new(PatNames { p_p0: q_p7.clone() }))
        }))) as Rc<dyn Fn((Text, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))),
        crate::lower::model::Pa::PaTuple(ps_p8) => crate::emit::cpp::patterns::concat2(&run_to_end(each_job(ps_p8.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
            let q_p9 = p0;
            prism_rtl::Turn::More(Rc::new(PatNames { p_p0: q_p9.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))),
        crate::lower::model::Pa::PaSlice(ps_pa) => crate::emit::cpp::patterns::concat2(&run_to_end(each_job(ps_pa.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
            let q_pb = p0;
            prism_rtl::Turn::More(Rc::new(PatNames { p_p0: q_pb.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))),
        crate::lower::model::Pa::PaRest(n_pc) => if n_pc == &Text::lit("") { Array::new() } else { Array::from(vec![n_pc.clone()]) },
        _ => Array::new(),
    }
}

/// The step machine of `PatNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatNames: unbounded fn Pa -> [Text]
/// ```
pub struct PatNames {
    pub p_p0: crate::lower::model::Pa,
}

impl prism_rtl::Job<Array<Text>> for PatNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let p_p0 = &self.p_p0;
        match p_p0 {
            crate::lower::model::Pa::PaBind(n_p1) => prism_rtl::Turn::Finished(Array::from(vec![n_p1.clone()])),
            crate::lower::model::Pa::PaMut(n_p2) => prism_rtl::Turn::Finished(Array::from(vec![n_p2.clone()])),
            crate::lower::model::Pa::PaTyped(q_p3, _) => prism_rtl::Turn::More(Rc::new(PatNames { p_p0: (**q_p3).clone() })),
            crate::lower::model::Pa::PaCtor(_, ps_p4) => {
                let ps_p4 = ps_p4.clone();
                call_value(each_job(ps_p4.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                    let q_p5 = p0;
                    prism_rtl::Turn::More(Rc::new(PatNames { p_p0: q_p5.clone() }))
                }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_4680: Array<Array<Text>>| prism_rtl::Turn::Finished(crate::emit::cpp::patterns::concat2(&each_4680)))
            },
            crate::lower::model::Pa::PaRecord(_, fs_p6, _) => {
                let fs_p6 = fs_p6.clone();
                call_value(each_job(fs_p6.clone(), Rc::new(move |p0: (Text, crate::lower::model::Pa)| entered(once_job(move || {
                    let (_, q_p7) = p0;
                    prism_rtl::Turn::More(Rc::new(PatNames { p_p0: q_p7.clone() }))
                }))) as Rc<dyn Fn((Text, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_4748: Array<Array<Text>>| prism_rtl::Turn::Finished(crate::emit::cpp::patterns::concat2(&each_4748)))
            },
            crate::lower::model::Pa::PaTuple(ps_p8) => {
                let ps_p8 = ps_p8.clone();
                call_value(each_job(ps_p8.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                    let q_p9 = p0;
                    prism_rtl::Turn::More(Rc::new(PatNames { p_p0: q_p9.clone() }))
                }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_4811: Array<Array<Text>>| prism_rtl::Turn::Finished(crate::emit::cpp::patterns::concat2(&each_4811)))
            },
            crate::lower::model::Pa::PaSlice(ps_pa) => {
                let ps_pa = ps_pa.clone();
                call_value(each_job(ps_pa.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                    let q_pb = p0;
                    prism_rtl::Turn::More(Rc::new(PatNames { p_p0: q_pb.clone() }))
                }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_4862: Array<Array<Text>>| prism_rtl::Turn::Finished(crate::emit::cpp::patterns::concat2(&each_4862)))
            },
            crate::lower::model::Pa::PaRest(n_pc) => if n_pc == &Text::lit("") {
                prism_rtl::Turn::Finished(Array::new())
            } else {
                prism_rtl::Turn::Finished(Array::from(vec![n_pc.clone()]))
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start PatNames, x`: what the function value is when passed to `@Run`.
pub fn start_pat_names(p_p0: crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(PatNames { p_p0 })
}

/// ```prism
/// ArmNames: unbounded fn XArm -> [Text]
/// ```
pub fn arm_names(a_p0: &crate::lower::model::XArm) -> Array<Text> {
    append(&pat_names(&a_p0.pat), &crate::emit::cpp::patterns::concat2(&run_to_end(each_job(a_p0.conds.clone(), Rc::new(move |p0: crate::lower::model::Cc| entered(once_job(move || {
        let c_p1 = p0;
        prism_rtl::Turn::More(Rc::new(CondNames { cc0: c_p1.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))))
}

/// The step machine of `ArmNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArmNames: unbounded fn XArm -> [Text]
/// ```
pub struct ArmNames {
    pub a_p0: crate::lower::model::XArm,
}

impl prism_rtl::Job<Array<Text>> for ArmNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let a_p0 = &self.a_p0;
        let a_p0 = a_p0.clone();
        call_then(start_pat_names(a_p0.pat.clone()), move |pat_names_5014: Array<Text>| call_value(each_job(a_p0.conds.clone(), Rc::new(move |p0: crate::lower::model::Cc| entered(once_job(move || {
            let c_p1 = p0;
            prism_rtl::Turn::More(Rc::new(CondNames { cc0: c_p1.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_5041: Array<Array<Text>>| prism_rtl::Turn::Finished(append(&pat_names_5014, &crate::emit::cpp::patterns::concat2(&each_5041)))))
    }
}

/// `Start ArmNames, x`: what the function value is when passed to `@Run`.
pub fn start_arm_names(a_p0: crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ArmNames { a_p0 })
}

/// ```prism
/// CondNames: unbounded fn Cc -> [Text]
/// ```
pub fn cond_names(cc0: &crate::lower::model::Cc) -> Array<Text> {
    match cc0 {
        crate::lower::model::Cc::CcLet(q_p0, _) => pat_names(q_p0),
        crate::lower::model::Cc::CcIf(_) => Array::new(),
    }
}

/// The step machine of `CondNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondNames: unbounded fn Cc -> [Text]
/// ```
pub struct CondNames {
    pub cc0: crate::lower::model::Cc,
}

impl prism_rtl::Job<Array<Text>> for CondNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cc0 = &self.cc0;
        match cc0 {
            crate::lower::model::Cc::CcLet(q_p0, _) => prism_rtl::Turn::More(Rc::new(PatNames { p_p0: q_p0.clone() })),
            crate::lower::model::Cc::CcIf(_) => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start CondNames, x`: what the function value is when passed to `@Run`.
pub fn start_cond_names(cc0: crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(CondNames { cc0 })
}

/// ```prism
/// Unbind: fn Cp, [Text] -> Cp
/// ```
pub fn unbind(cp_p0: &crate::emit::cpp::Cp, names_p1: &Array<Text>) -> crate::emit::cpp::Cp {
    let mut this: crate::emit::cpp::Cp = cp_p0.clone();
    this.renames = fold(names_p1, &this.renames, &(|m_p2: &Map<Text, Text>, n_p3: &Text| remove(m_p2, n_p3)));
    this.pointers = fold(names_p1, &this.pointers, &(|m_p4: &Map<Text, bool>, n_p5: &Text| remove(m_p4, n_p5)));
    this.owned = fold(names_p1, &this.owned, &(|m_p6: &Map<Text, bool>, n_p7: &Text| remove(m_p6, n_p7)));
    this.local_types = fold(names_p1, &this.local_types, &(|m_p8: &Map<Text, crate::lower::model::OutTy>, n_p9: &Text| remove(m_p8, n_p9)));
    this
}

/// ```prism
/// Pointing: fn Cp, Text -> Cp
/// ```
pub fn pointing(cp_p0: &crate::emit::cpp::Cp, n_p1: &Text) -> crate::emit::cpp::Cp {
    let mut this: crate::emit::cpp::Cp = cp_p0.clone();
    this.pointers = insert(&this.pointers, n_p1, &true);
    this
}

/// ```prism
/// KnownValue: fn Cp, Pa, Text -> Cp
/// ```
pub fn known_value(cp_p0: &crate::emit::cpp::Cp, p_p1: &crate::lower::model::Pa, n_p2: &Text) -> crate::emit::cpp::Cp {
    match p_p1 {
        crate::lower::model::Pa::PaTyped(_, _) => {
            let mut this: crate::emit::cpp::Cp = cp_p0.clone();
            this.pointers = insert(&this.pointers, n_p2, &false);
            this
        },
        _ => cp_p0.clone(),
    }
}

/// ```prism
/// IsPointerLet: fn Cp, Pa, Ex -> Bool
/// ```
pub fn is_pointer_let(cp_p0: &crate::emit::cpp::Cp, p_p1: &crate::lower::model::Pa, x_p2: &crate::lower::model::Ex) -> bool {
    match p_p1 {
        crate::lower::model::Pa::PaTyped(_, t_p3) => crate::emit::cpp::expr::is_pointer_ty(cp_p0, t_p3),
        _ => 'm6285: {
            if let crate::lower::model::Ex::XCall(m6285_0_0, _) = x_p2 && (m6285_0_0 == &Text::lit("prism_rtl::Host::new")) {
                break 'm6285 true;
            }
            if let crate::lower::model::Ex::XCall(m6285_1_0, m6285_1_1) = x_p2 && (m6285_1_0 == &Text::lit("Rc::new")) && (m6285_1_1.len() == 1) && let Some(crate::lower::model::Ex::XCall(m6285_1_1_0_0, _)) = index(m6285_1_1, &Nat::from(0u32)) && (&m6285_1_1_0_0 == &Text::lit("Port::new")) {
                break 'm6285 true;
            }
            match crate::emit::cpp::expr::pointer(cp_p0, x_p2) {
                Some(b_p4) => b_p4,
                None => false,
            }
        },
    }
}

/// ```prism
/// Inc: fn Nat -> Nat
/// ```
pub fn inc(n_p0: &Nat) -> Nat {
    n_p0 + &Nat::from(1u32)
}

/// ```prism
/// ?LetName: fn Pa -> ?Text
/// ```
pub fn let_name(p_p0: &crate::lower::model::Pa) -> Option<Text> {
    match p_p0 {
        crate::lower::model::Pa::PaBind(n_p1) => Some(n_p1.clone()),
        crate::lower::model::Pa::PaMut(n_p2) => Some(n_p2.clone()),
        crate::lower::model::Pa::PaTyped(q_p3, _) => let_name(&**q_p3),
        _ => None,
    }
}

/// ```prism
/// VarName: fn Cp, Text -> Text
/// ```
pub fn var_name(cp_p0: &crate::emit::cpp::Cp, n_p1: &Text) -> Text {
    or(&get(&cp_p0.renames, n_p1), &crate::emit::cpp::cpp_id(n_p1))
}

/// ```prism
/// CppMentions: fn Text, Text -> Bool
/// ```
pub fn cpp_mentions(t_p0: &Text, n_p1: &Text) -> bool {
    let parts_p2 = split_on(t_p0, n_p1);
    let k_p3 = len(&parts_p2);
    fold(&crate::check::errors::range0(&crate::syntax::lexer::chars::dec(&k_p3)), &false, &(|f_p4: &bool, i_p5: &Nat| *f_p4 || (!cpp_ends_ident(&or(&index(&parts_p2, i_p5), &Text::lit(""))) && !cpp_starts_ident(&or(&index(&parts_p2, &(i_p5 + &Nat::from(1u32))), &Text::lit(""))))))
}

/// ```prism
/// CppEndsIdent: fn Text -> Bool
/// ```
pub fn cpp_ends_ident(t_p0: &Text) -> bool {
    let c_p1 = crate::syntax::lexer::chars::last_char(t_p0);
    (cpp_ident_char(&c_p1) || (&c_p1 == &Text::lit("."))) || (&c_p1 == &Text::lit(">"))
}

/// ```prism
/// CppStartsIdent: fn Text -> Bool
/// ```
pub fn cpp_starts_ident(t_p0: &Text) -> bool {
    cpp_ident_char(&crate::syntax::lexer::chars::head(t_p0))
}

/// ```prism
/// CppIdentChar: fn Text -> Bool
/// ```
pub fn cpp_ident_char(c_p0: &Text) -> bool {
    (c_p0 != &Text::lit("")) && crate::syntax::lexer::chars::contains(&Text::lit("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"), c_p0)
}

/// ```prism
/// CppStatement: unbounded fn Cp, Do -> Text
/// ```
pub fn cpp_statement(cp_p0: &crate::emit::cpp::Cp, d_p1: &crate::lower::model::Do) -> Text {
    match d_p1 {
        crate::lower::model::Do::DoLet(p_p2, x_p3) => cpp_let(cp_p0, cp_p0, p_p2, x_p3),
        crate::lower::model::Do::DoLetElse(p_p4, x_p5, e_p6) => {
            let v_p7 = Text::from(format!("_{}", &or(&first_binder(p_p4), &Text::lit("m"))));
            Text::from(format!("auto&& {} = {};\nif (!({})) {{ {}; }}\n{}", &v_p7, &crate::emit::cpp::expr::cpp_expr(cp_p0, x_p5), &crate::emit::cpp::patterns::conds(&crate::emit::cpp::patterns::pat_conds(cp_p0, p_p4, &v_p7)), &crate::emit::cpp::expr::cpp_expr(cp_p0, e_p6), &crate::syntax::lexer::chars::join(&crate::emit::cpp::patterns::pat_binds(cp_p0, p_p4, &v_p7), &Text::lit("\n"))))
        },
        crate::lower::model::Do::DoAssign(p_p8, x_p9) => Text::from(format!("{} = {};", &crate::emit::cpp::expr::cpp_place(cp_p0, p_p8), &crate::emit::cpp::expr::cpp_expr(cp_p0, x_p9))),
        crate::lower::model::Do::DoWhile(c_pa, body_pb) => crate::emit::cpp::templates::items::block(&Text::from(format!("while ({})", &crate::emit::cpp::expr::cpp_expr(cp_p0, c_pa))), &cpp_statements(cp_p0, body_pb)),
        crate::lower::model::Do::DoWhileLet(p_pc, x_pd, body_pe) => {
            let v_pf = Text::lit("_m");
            let head_pg = Text::from(format!("auto&& _m = {};\nif (!({})) break;", &crate::emit::cpp::expr::cpp_expr(cp_p0, x_pd), &crate::emit::cpp::patterns::conds(&crate::emit::cpp::patterns::pat_conds(cp_p0, p_pc, &v_pf))));
            crate::emit::cpp::templates::items::block(&Text::lit("while (true)"), &crate::syntax::lexer::chars::join(&append(&append(&Array::from(vec![head_pg.clone()]), &crate::emit::cpp::patterns::pat_binds(cp_p0, p_pc, &v_pf)), &Array::from(vec![cpp_statements(cp_p0, body_pe)])), &Text::lit("\n")))
        },
        crate::lower::model::Do::DoFor(p_ph, x_pi, body_pj) => cpp_for(cp_p0, p_ph, x_pi, body_pj),
        crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(l_pk, y_pl)) => crate::emit::cpp::patterns::cpp_break(cp_p0, l_pk, &**y_pl),
        crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreakLoop) => Text::lit("break;"),
        crate::lower::model::Do::DoExpr(x_pm) => Text::from(format!("{};", &crate::emit::cpp::expr::cpp_expr(cp_p0, x_pm))),
        crate::lower::model::Do::DoIf(c_pn, t_po, e_pp) => Text::from(format!("{}{}", &crate::emit::cpp::templates::items::block(&Text::from(format!("if ({})", &crate::emit::cpp::expr::cpp_expr(cp_p0, c_pn))), &cpp_statements(cp_p0, t_po)), &cpp_else(cp_p0, e_pp))),
        crate::lower::model::Do::DoIfLet(p_pq, x_pr, t_ps, e_pt) => cpp_if_let(cp_p0, p_pq, x_pr, t_ps, e_pt),
        crate::lower::model::Do::DoMatch(x_pu, cases_pv) => cpp_do_match(cp_p0, x_pu, cases_pv),
        crate::lower::model::Do::DoReturn(x_p10) => Text::from(format!("return {};", &cpp_returned(cp_p0, x_p10))),
        crate::lower::model::Do::DoBlock(body_p11) => crate::emit::cpp::templates::items::braced(&cpp_statements(cp_p0, body_p11)),
        crate::lower::model::Do::DoScope(body_p12) => Text::from(format!("{{ {} }}", &cpp_inline(cp_p0, body_p12))),
        crate::lower::model::Do::DoLine(body_p13) => cpp_inline(cp_p0, body_p13),
        crate::lower::model::Do::DoNote(t_p14) => Text::from(format!("// {}", t_p14)),
    }
}

/// The step machine of `CppStatement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppStatement: unbounded fn Cp, Do -> Text
/// ```
pub struct CppStatement {
    pub cp_p0: crate::emit::cpp::Cp,
    pub d_p1: crate::lower::model::Do,
}

impl prism_rtl::Job<Text> for CppStatement {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let d_p1 = &self.d_p1;
        match d_p1 {
            crate::lower::model::Do::DoLet(p_p2, x_p3) => prism_rtl::Turn::More(Rc::new(CppLet { cp_p0: cp_p0.clone(), named_p1: cp_p0.clone(), p_p2: p_p2.clone(), x_p3: x_p3.clone() })),
            crate::lower::model::Do::DoLetElse(p_p4, x_p5, e_p6) => {
                let cp_p0 = cp_p0.clone();
                let e_p6 = e_p6.clone();
                let p_p4 = p_p4.clone();
                let x_p5 = x_p5.clone();
                call_then(start_first_binder(p_p4.clone()), move |first_binder_7579: Option<Text>| {
                    let v_p7 = Text::from(format!("_{}", &or(&first_binder_7579, &Text::lit("m"))));
                    call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), x_p5.clone()), move |cpp_expr_7625: Text| call_then(crate::emit::cpp::patterns::start_pat_conds(cp_p0.clone(), p_p4.clone(), v_p7.clone()), move |pat_conds_7656: Array<Text>| call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), e_p6.clone()), move |cpp_expr_7682: Text| call_then(crate::emit::cpp::patterns::start_pat_binds(cp_p0.clone(), p_p4.clone(), v_p7.clone()), move |pat_binds_7709: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("auto&& {} = {};\nif (!({})) {{ {}; }}\n{}", &v_p7, &cpp_expr_7625, &crate::emit::cpp::patterns::conds(&pat_conds_7656), &cpp_expr_7682, &crate::syntax::lexer::chars::join(&pat_binds_7709, &Text::lit("\n")))))))))
                })
            },
            crate::lower::model::Do::DoAssign(p_p8, x_p9) => {
                let cp_p0 = cp_p0.clone();
                let p_p8 = p_p8.clone();
                let x_p9 = x_p9.clone();
                call_then(crate::emit::cpp::expr::start_cpp_place(cp_p0.clone(), p_p8.clone()), move |cpp_place_7757: Text| call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), x_p9.clone()), move |cpp_expr_7776: Text| prism_rtl::Turn::Finished(Text::from(format!("{} = {};", &cpp_place_7757, &cpp_expr_7776)))))
            },
            crate::lower::model::Do::DoWhile(c_pa, body_pb) => {
                let body_pb = body_pb.clone();
                let c_pa = c_pa.clone();
                let cp_p0 = cp_p0.clone();
                call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), c_pa.clone()), move |cpp_expr_7829: Text| call_then(start_cpp_statements(cp_p0.clone(), body_pb.clone()), move |cpp_statements_7848: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::block(&Text::from(format!("while ({})", &cpp_expr_7829)), &cpp_statements_7848))))
            },
            crate::lower::model::Do::DoWhileLet(p_pc, x_pd, body_pe) => {
                let v_pf = Text::lit("_m");
                let body_pe = body_pe.clone();
                let cp_p0 = cp_p0.clone();
                let p_pc = p_pc.clone();
                let x_pd = x_pd.clone();
                call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), x_pd.clone()), move |cpp_expr_7953: Text| call_then(crate::emit::cpp::patterns::start_pat_conds(cp_p0.clone(), p_pc.clone(), v_pf.clone()), move |pat_conds_7984: Array<Text>| {
                    let head_pg = Text::from(format!("auto&& _m = {};\nif (!({})) break;", &cpp_expr_7953, &crate::emit::cpp::patterns::conds(&pat_conds_7984)));
                    call_then(crate::emit::cpp::patterns::start_pat_binds(cp_p0.clone(), p_pc.clone(), v_pf.clone()), move |pat_binds_8077: Array<Text>| call_then(start_cpp_statements(cp_p0.clone(), body_pe.clone()), move |cpp_statements_8101: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::block(&Text::lit("while (true)"), &crate::syntax::lexer::chars::join(&append(&append(&Array::from(vec![head_pg.clone()]), &pat_binds_8077), &Array::from(vec![cpp_statements_8101])), &Text::lit("\n"))))))
                }))
            },
            crate::lower::model::Do::DoFor(p_ph, x_pi, body_pj) => prism_rtl::Turn::More(Rc::new(CppFor { cp0_p0: cp_p0.clone(), p_p1: p_ph.clone(), x_p2: x_pi.clone(), body_p3: body_pj.clone() })),
            crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(l_pk, y_pl)) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::patterns::CppBreak { cp_p0: cp_p0.clone(), l_p1: l_pk.clone(), y_p2: (**y_pl).clone() })),
            crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreakLoop) => prism_rtl::Turn::Finished(Text::lit("break;")),
            crate::lower::model::Do::DoExpr(x_pm) => {
                let cp_p0 = cp_p0.clone();
                let x_pm = x_pm.clone();
                call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), x_pm.clone()), move |cpp_expr_8271: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &cpp_expr_8271))))
            },
            crate::lower::model::Do::DoIf(c_pn, t_po, e_pp) => {
                let c_pn = c_pn.clone();
                let cp_p0 = cp_p0.clone();
                let e_pp = e_pp.clone();
                let t_po = t_po.clone();
                call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), c_pn.clone()), move |cpp_expr_8320: Text| call_then(start_cpp_statements(cp_p0.clone(), t_po.clone()), move |cpp_statements_8339: Text| call_then(start_cpp_else(cp_p0.clone(), e_pp.clone()), move |cpp_else_8361: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &crate::emit::cpp::templates::items::block(&Text::from(format!("if ({})", &cpp_expr_8320)), &cpp_statements_8339), &cpp_else_8361))))))
            },
            crate::lower::model::Do::DoIfLet(p_pq, x_pr, t_ps, e_pt) => prism_rtl::Turn::More(Rc::new(CppIfLet { cp0_p0: cp_p0.clone(), p_p1: p_pq.clone(), x_p2: x_pr.clone(), t_p3: t_ps.clone(), e_p4: e_pt.clone() })),
            crate::lower::model::Do::DoMatch(x_pu, cases_pv) => prism_rtl::Turn::More(Rc::new(CppDoMatch { cp_p0: cp_p0.clone(), x_p1: x_pu.clone(), cases_p2: cases_pv.clone() })),
            crate::lower::model::Do::DoReturn(x_p10) => {
                let cp_p0 = cp_p0.clone();
                let x_p10 = x_p10.clone();
                call_then(start_cpp_returned(cp_p0.clone(), x_p10.clone()), move |cpp_returned_8496: Text| prism_rtl::Turn::Finished(Text::from(format!("return {};", &cpp_returned_8496))))
            },
            crate::lower::model::Do::DoBlock(body_p11) => {
                let body_p11 = body_p11.clone();
                let cp_p0 = cp_p0.clone();
                call_then(start_cpp_statements(cp_p0.clone(), body_p11.clone()), move |cpp_statements_8543: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::braced(&cpp_statements_8543)))
            },
            crate::lower::model::Do::DoScope(body_p12) => {
                let body_p12 = body_p12.clone();
                let cp_p0 = cp_p0.clone();
                call_then(start_cpp_inline(cp_p0.clone(), body_p12.clone()), move |cpp_inline_8590: Text| prism_rtl::Turn::Finished(Text::from(format!("{{ {} }}", &cpp_inline_8590))))
            },
            crate::lower::model::Do::DoLine(body_p13) => prism_rtl::Turn::More(Rc::new(CppInline { cp_p0: cp_p0.clone(), dos_p1: body_p13.clone() })),
            crate::lower::model::Do::DoNote(t_p14) => prism_rtl::Turn::Finished(Text::from(format!("// {}", t_p14))),
        }
    }
}

/// `Start CppStatement, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_statement(cp_p0: crate::emit::cpp::Cp, d_p1: crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppStatement { cp_p0, d_p1 })
}

/// ```prism
/// CppInline: unbounded fn Cp, [Do] -> Text
/// ```
pub fn cpp_inline(cp_p0: &crate::emit::cpp::Cp, dos_p1: &Array<crate::lower::model::Do>) -> Text {
    crate::syntax::lexer::chars::join(&run_to_end(each_job(dos_p1.clone(), {
        let cp_p0 = cp_p0.clone();
        Rc::new(move |p0: crate::lower::model::Do| {
            let cp_p0 = cp_p0.clone();
            entered(once_job(move || {
                let d_p2 = p0;
                prism_rtl::Turn::More(Rc::new(CppStatement { cp_p0: cp_p0.clone(), d_p1: d_p2.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(" "))
}

/// The step machine of `CppInline`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppInline: unbounded fn Cp, [Do] -> Text
/// ```
pub struct CppInline {
    pub cp_p0: crate::emit::cpp::Cp,
    pub dos_p1: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for CppInline {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let dos_p1 = &self.dos_p1;
        let cp_p0 = cp_p0.clone();
        let dos_p1 = dos_p1.clone();
        call_value(each_job(dos_p1.clone(), {
            let cp_p0 = cp_p0.clone();
            Rc::new(move |p0: crate::lower::model::Do| {
                let cp_p0 = cp_p0.clone();
                entered(once_job(move || {
                    let d_p2 = p0;
                    prism_rtl::Turn::More(Rc::new(CppStatement { cp_p0: cp_p0.clone(), d_p1: d_p2.clone() }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_8744: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&each_8744, &Text::lit(" "))))
    }
}

/// `Start CppInline, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_inline(cp_p0: crate::emit::cpp::Cp, dos_p1: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppInline { cp_p0, dos_p1 })
}

/// ```prism
/// CppElse: unbounded fn Cp, [Do] -> Text
/// ```
pub fn cpp_else(cp_p0: &crate::emit::cpp::Cp, xs1: &Array<crate::lower::model::Do>) -> Text {
    'c: {
        if let c0_1 = xs1 && (c0_1.len() == 0) {
            break 'c Text::lit("");
        }
        if let c1_1 = xs1 && (c1_1.len() == 1) && let Some(crate::lower::model::Do::DoIf(c_p2, t_p3, e_p4)) = index(c1_1, &Nat::from(0u32)) {
            break 'c Text::from(format!(" else {}", &cpp_statement(cp_p0, &crate::lower::model::Do::DoIf(c_p2.clone(), t_p3.clone(), e_p4.clone()))));
        }
        if let c2_1 = xs1 && (c2_1.len() == 1) && let Some(crate::lower::model::Do::DoIfLet(p_p6, x_p7, t_p8, e_p9)) = index(c2_1, &Nat::from(0u32)) {
            break 'c Text::from(format!(" else {}", &cpp_statement(cp_p0, &crate::lower::model::Do::DoIfLet(p_p6.clone(), x_p7.clone(), t_p8.clone(), e_p9.clone()))));
        }
        if let body_pb = xs1 {
            break 'c Text::from(format!(" else {}", &crate::emit::cpp::templates::items::block(&Text::lit(""), &cpp_statements(cp_p0, body_pb))));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `CppElse`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppElse: unbounded fn Cp, [Do] -> Text
/// ```
pub struct CppElse {
    pub cp_p0: crate::emit::cpp::Cp,
    pub xs1: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for CppElse {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let xs1 = &self.xs1;
        'j: {
            if let j0_1 = xs1 && (j0_1.len() == 0) {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let j1_1 = xs1 && (j1_1.len() == 1) && let Some(crate::lower::model::Do::DoIf(c_p2, t_p3, e_p4)) = index(j1_1, &Nat::from(0u32)) {
                break 'j {
                    let cp_p0 = cp_p0.clone();
                    call_then(start_cpp_statement(cp_p0.clone(), crate::lower::model::Do::DoIf(c_p2.clone(), t_p3.clone(), e_p4.clone())), move |cpp_statement_8893: Text| prism_rtl::Turn::Finished(Text::from(format!(" else {}", &cpp_statement_8893))))
                };
            }
            if let j2_1 = xs1 && (j2_1.len() == 1) && let Some(crate::lower::model::Do::DoIfLet(p_p6, x_p7, t_p8, e_p9)) = index(j2_1, &Nat::from(0u32)) {
                break 'j {
                    let cp_p0 = cp_p0.clone();
                    call_then(start_cpp_statement(cp_p0.clone(), crate::lower::model::Do::DoIfLet(p_p6.clone(), x_p7.clone(), t_p8.clone(), e_p9.clone())), move |cpp_statement_8977: Text| prism_rtl::Turn::Finished(Text::from(format!(" else {}", &cpp_statement_8977))))
                };
            }
            if let body_pb = xs1 {
                break 'j {
                    let body_pb = body_pb.clone();
                    let cp_p0 = cp_p0.clone();
                    call_then(start_cpp_statements(cp_p0.clone(), body_pb.clone()), move |cpp_statements_9058: Text| prism_rtl::Turn::Finished(Text::from(format!(" else {}", &crate::emit::cpp::templates::items::block(&Text::lit(""), &cpp_statements_9058)))))
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start CppElse, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_else(cp_p0: crate::emit::cpp::Cp, xs1: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppElse { cp_p0, xs1 })
}

/// ```prism
/// CppLet: unbounded fn Cp, Cp, Pa, Ex -> Text
/// ```
pub fn cpp_let(cp_p0: &crate::emit::cpp::Cp, named_p1: &crate::emit::cpp::Cp, p_p2: &crate::lower::model::Pa, x_p3: &crate::lower::model::Ex) -> Text {
    'm9274: {
        if let crate::lower::model::Pa::PaWild = p_p2 {
            break 'm9274 Text::from(format!("static_cast<void>({});", &crate::emit::cpp::expr::cpp_expr(cp_p0, x_p3)));
        }
        if let crate::lower::model::Pa::PaBind(n_p4) = p_p2 {
            break 'm9274 match x_p3 {
                crate::lower::model::Ex::XRef(_) => Text::from(format!("const auto& {} = {};", &var_name(named_p1, n_p4), &crate::emit::cpp::expr::cpp_expr(cp_p0, x_p3))),
                _ => Text::from(format!("auto {} = {};", &var_name(named_p1, n_p4), &crate::emit::cpp::expr::cpp_expr(cp_p0, x_p3))),
            };
        }
        if let crate::lower::model::Pa::PaMut(n_p5) = p_p2 {
            break 'm9274 Text::from(format!("auto {} = {};", &var_name(named_p1, n_p5), &crate::emit::cpp::expr::cpp_expr(cp_p0, x_p3)));
        }
        if let crate::lower::model::Pa::PaTyped(m9274_3_0, t_p7) = p_p2 && let crate::lower::model::Pa::PaBind(n_p6) = &**m9274_3_0 {
            break 'm9274 match x_p3 {
                crate::lower::model::Ex::XUnreachable => Text::from(format!("{} {} = prism_rtl::unreachable_as<{}>();", &crate::emit::cpp::cpp_type(cp_p0, t_p7), &var_name(named_p1, n_p6), &crate::emit::cpp::cpp_type(cp_p0, t_p7))),
                _ => Text::from(format!("{} {} = {};", &crate::emit::cpp::cpp_type(cp_p0, t_p7), &var_name(named_p1, n_p6), &crate::emit::cpp::expr::cpp_expr(cp_p0, x_p3))),
            };
        }
        if let crate::lower::model::Pa::PaTyped(m9274_4_0, t_p9) = p_p2 && let crate::lower::model::Pa::PaMut(n_p8) = &**m9274_4_0 {
            break 'm9274 Text::from(format!("{} {} = {};", &crate::emit::cpp::cpp_type(cp_p0, t_p9), &var_name(named_p1, n_p8), &crate::emit::cpp::expr::cpp_expr(cp_p0, x_p3)));
        }
        if let crate::lower::model::Pa::PaTuple(ps_pa) = p_p2 {
            break 'm9274 if fold(ps_pa, &true, &(|f_pb: &bool, q_pc: &crate::lower::model::Pa| *f_pb && is_name(q_pc))) {
                Text::from(format!("auto [{}] = {};", &crate::syntax::lexer::chars::join(&each(ps_pa, &(|q_pd: &crate::lower::model::Pa| pat_name(q_pd))), &Text::lit(", ")), &crate::emit::cpp::expr::cpp_expr(cp_p0, x_p3)))
            } else {
                let_through(cp_p0, p_p2, x_p3)
            };
        }
        let_through(cp_p0, p_p2, x_p3)
    }
}

/// The step machine of `CppLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppLet: unbounded fn Cp, Cp, Pa, Ex -> Text
/// ```
pub struct CppLet {
    pub cp_p0: crate::emit::cpp::Cp,
    pub named_p1: crate::emit::cpp::Cp,
    pub p_p2: crate::lower::model::Pa,
    pub x_p3: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppLet {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let named_p1 = &self.named_p1;
        let p_p2 = &self.p_p2;
        let x_p3 = &self.x_p3;
        'm9274: {
            if let crate::lower::model::Pa::PaWild = p_p2 {
                break 'm9274 {
                    let cp_p0 = cp_p0.clone();
                    let x_p3 = x_p3.clone();
                    call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), x_p3.clone()), move |cpp_expr_9315: Text| prism_rtl::Turn::Finished(Text::from(format!("static_cast<void>({});", &cpp_expr_9315))))
                };
            }
            if let crate::lower::model::Pa::PaBind(n_p4) = p_p2 {
                break 'm9274 match x_p3 {
                    crate::lower::model::Ex::XRef(_) => {
                        let cp_p0 = cp_p0.clone();
                        let n_p4 = n_p4.clone();
                        let named_p1 = named_p1.clone();
                        let x_p3 = x_p3.clone();
                        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), x_p3.clone()), move |cpp_expr_9412: Text| prism_rtl::Turn::Finished(Text::from(format!("const auto& {} = {};", &var_name(&named_p1, &n_p4), &cpp_expr_9412))))
                    },
                    _ => {
                        let cp_p0 = cp_p0.clone();
                        let n_p4 = n_p4.clone();
                        let named_p1 = named_p1.clone();
                        let x_p3 = x_p3.clone();
                        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), x_p3.clone()), move |cpp_expr_9476: Text| prism_rtl::Turn::Finished(Text::from(format!("auto {} = {};", &var_name(&named_p1, &n_p4), &cpp_expr_9476))))
                    },
                };
            }
            if let crate::lower::model::Pa::PaMut(n_p5) = p_p2 {
                break 'm9274 {
                    let cp_p0 = cp_p0.clone();
                    let n_p5 = n_p5.clone();
                    let named_p1 = named_p1.clone();
                    let x_p3 = x_p3.clone();
                    call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), x_p3.clone()), move |cpp_expr_9534: Text| prism_rtl::Turn::Finished(Text::from(format!("auto {} = {};", &var_name(&named_p1, &n_p5), &cpp_expr_9534))))
                };
            }
            if let crate::lower::model::Pa::PaTyped(m9274_3_0, t_p7) = p_p2 && let crate::lower::model::Pa::PaBind(n_p6) = &**m9274_3_0 {
                break 'm9274 match x_p3 {
                    crate::lower::model::Ex::XUnreachable => {
                        let cp_p0 = cp_p0.clone();
                        let n_p6 = n_p6.clone();
                        let named_p1 = named_p1.clone();
                        let t_p7 = t_p7.clone();
                        call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), t_p7.clone()), move |cpp_type_9787: Text| call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), t_p7.clone()), move |cpp_type_9850: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {} = prism_rtl::unreachable_as<{}>();", &cpp_type_9787, &var_name(&named_p1, &n_p6), &cpp_type_9850)))))
                    },
                    _ => {
                        let cp_p0 = cp_p0.clone();
                        let n_p6 = n_p6.clone();
                        let named_p1 = named_p1.clone();
                        let t_p7 = t_p7.clone();
                        let x_p3 = x_p3.clone();
                        call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), t_p7.clone()), move |cpp_type_9891: Text| call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), x_p3.clone()), move |cpp_expr_9928: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {} = {};", &cpp_type_9891, &var_name(&named_p1, &n_p6), &cpp_expr_9928)))))
                    },
                };
            }
            if let crate::lower::model::Pa::PaTyped(m9274_4_0, t_p9) = p_p2 && let crate::lower::model::Pa::PaMut(n_p8) = &**m9274_4_0 {
                break 'm9274 {
                    let cp_p0 = cp_p0.clone();
                    let n_p8 = n_p8.clone();
                    let named_p1 = named_p1.clone();
                    let t_p9 = t_p9.clone();
                    let x_p3 = x_p3.clone();
                    call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), t_p9.clone()), move |cpp_type_9973: Text| call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), x_p3.clone()), move |cpp_expr_10010: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {} = {};", &cpp_type_9973, &var_name(&named_p1, &n_p8), &cpp_expr_10010)))))
                };
            }
            if let crate::lower::model::Pa::PaTuple(ps_pa) = p_p2 {
                break 'm9274 if fold(ps_pa, &true, &(|f_pb: &bool, q_pc: &crate::lower::model::Pa| *f_pb && is_name(q_pc))) {
                    {
                        let cp_p0 = cp_p0.clone();
                        let ps_pa = ps_pa.clone();
                        let x_p3 = x_p3.clone();
                        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), x_p3.clone()), move |cpp_expr_10143: Text| prism_rtl::Turn::Finished(Text::from(format!("auto [{}] = {};", &crate::syntax::lexer::chars::join(&each(&ps_pa, &(|q_pd: &crate::lower::model::Pa| pat_name(q_pd))), &Text::lit(", ")), &cpp_expr_10143))))
                    }
                } else {
                    prism_rtl::Turn::More(Rc::new(LetThrough { cp_p0: cp_p0.clone(), p_p1: p_p2.clone(), x_p2: x_p3.clone() }))
                };
            }
            prism_rtl::Turn::More(Rc::new(LetThrough { cp_p0: cp_p0.clone(), p_p1: p_p2.clone(), x_p2: x_p3.clone() }))
        }
    }
}

/// `Start CppLet, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_let(cp_p0: crate::emit::cpp::Cp, named_p1: crate::emit::cpp::Cp, p_p2: crate::lower::model::Pa, x_p3: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppLet { cp_p0, named_p1, p_p2, x_p3 })
}

/// ```prism
/// LetThrough: unbounded fn Cp, Pa, Ex -> Text
/// ```
pub fn let_through(cp_p0: &crate::emit::cpp::Cp, p_p1: &crate::lower::model::Pa, x_p2: &crate::lower::model::Ex) -> Text {
    let t_p3 = Text::from(format!("_{}", &or(&first_binder(p_p1), &Text::lit("t"))));
    Text::from(format!("auto&& {} = {};\n{}", &t_p3, &crate::emit::cpp::expr::cpp_expr(cp_p0, x_p2), &crate::syntax::lexer::chars::join(&crate::emit::cpp::patterns::pat_binds(cp_p0, p_p1, &t_p3), &Text::lit("\n"))))
}

/// The step machine of `LetThrough`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LetThrough: unbounded fn Cp, Pa, Ex -> Text
/// ```
pub struct LetThrough {
    pub cp_p0: crate::emit::cpp::Cp,
    pub p_p1: crate::lower::model::Pa,
    pub x_p2: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for LetThrough {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let p_p1 = &self.p_p1;
        let x_p2 = &self.x_p2;
        let cp_p0 = cp_p0.clone();
        let p_p1 = p_p1.clone();
        let x_p2 = x_p2.clone();
        call_then(start_first_binder(p_p1.clone()), move |first_binder_10402: Option<Text>| {
            let t_p3 = Text::from(format!("_{}", &or(&first_binder_10402, &Text::lit("t"))));
            call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), x_p2.clone()), move |cpp_expr_10444: Text| call_then(crate::emit::cpp::patterns::start_pat_binds(cp_p0.clone(), p_p1.clone(), t_p3.clone()), move |pat_binds_10468: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("auto&& {} = {};\n{}", &t_p3, &cpp_expr_10444, &crate::syntax::lexer::chars::join(&pat_binds_10468, &Text::lit("\n")))))))
        })
    }
}

/// `Start LetThrough, x`: what the function value is when passed to `@Run`.
pub fn start_let_through(cp_p0: crate::emit::cpp::Cp, p_p1: crate::lower::model::Pa, x_p2: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(LetThrough { cp_p0, p_p1, x_p2 })
}

/// ```prism
/// ?FirstBinder: unbounded fn Pa -> ?Text
/// ```
pub fn first_binder(p_p0: &crate::lower::model::Pa) -> Option<Text> {
    match p_p0 {
        crate::lower::model::Pa::PaBind(n_p1) => Some(n_p1.clone()),
        crate::lower::model::Pa::PaMut(n_p2) => Some(n_p2.clone()),
        crate::lower::model::Pa::PaTyped(q_p3, _) => first_binder(&**q_p3),
        crate::lower::model::Pa::PaCtor(_, ps_p4) => run_to_end(fold_job(ps_p4.clone(), None, Rc::new(move |(p0, p1): (Option<Text>, crate::lower::model::Pa)| entered(once_job(move || {
            let f_o5 = p0;
            let q_p6 = p1;
            match &f_o5 {
                Some(b_p7) => prism_rtl::Turn::Finished(Some(b_p7.clone())),
                None => prism_rtl::Turn::More(Rc::new(FirstBinder { p_p0: q_p6.clone() })),
            }
        }))) as Rc<dyn Fn((Option<Text>, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Option<Text>>>>)),
        crate::lower::model::Pa::PaTuple(ps_p8) => run_to_end(fold_job(ps_p8.clone(), None, Rc::new(move |(p0, p1): (Option<Text>, crate::lower::model::Pa)| entered(once_job(move || {
            let f_o9 = p0;
            let q_pa = p1;
            match &f_o9 {
                Some(b_pb) => prism_rtl::Turn::Finished(Some(b_pb.clone())),
                None => prism_rtl::Turn::More(Rc::new(FirstBinder { p_p0: q_pa.clone() })),
            }
        }))) as Rc<dyn Fn((Option<Text>, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Option<Text>>>>)),
        _ => None,
    }
}

/// The step machine of `FirstBinder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?FirstBinder: unbounded fn Pa -> ?Text
/// ```
pub struct FirstBinder {
    pub p_p0: crate::lower::model::Pa,
}

impl prism_rtl::Job<Option<Text>> for FirstBinder {
    fn cycle(&self) -> prism_rtl::Turn<Option<Text>> {
        let p_p0 = &self.p_p0;
        match p_p0 {
            crate::lower::model::Pa::PaBind(n_p1) => prism_rtl::Turn::Finished(Some(n_p1.clone())),
            crate::lower::model::Pa::PaMut(n_p2) => prism_rtl::Turn::Finished(Some(n_p2.clone())),
            crate::lower::model::Pa::PaTyped(q_p3, _) => prism_rtl::Turn::More(Rc::new(FirstBinder { p_p0: (**q_p3).clone() })),
            crate::lower::model::Pa::PaCtor(_, ps_p4) => fold_job(ps_p4.clone(), None, Rc::new(move |(p0, p1): (Option<Text>, crate::lower::model::Pa)| entered(once_job(move || {
                let f_o5 = p0;
                let q_p6 = p1;
                match &f_o5 {
                    Some(b_p7) => prism_rtl::Turn::Finished(Some(b_p7.clone())),
                    None => prism_rtl::Turn::More(Rc::new(FirstBinder { p_p0: q_p6.clone() })),
                }
            }))) as Rc<dyn Fn((Option<Text>, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Option<Text>>>>).cycle(),
            crate::lower::model::Pa::PaTuple(ps_p8) => fold_job(ps_p8.clone(), None, Rc::new(move |(p0, p1): (Option<Text>, crate::lower::model::Pa)| entered(once_job(move || {
                let f_o9 = p0;
                let q_pa = p1;
                match &f_o9 {
                    Some(b_pb) => prism_rtl::Turn::Finished(Some(b_pb.clone())),
                    None => prism_rtl::Turn::More(Rc::new(FirstBinder { p_p0: q_pa.clone() })),
                }
            }))) as Rc<dyn Fn((Option<Text>, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Option<Text>>>>).cycle(),
            _ => prism_rtl::Turn::Finished(None),
        }
    }
}

/// `Start FirstBinder, x`: what the function value is when passed to `@Run`.
pub fn start_first_binder(p_p0: crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Option<Text>>> {
    Rc::new(FirstBinder { p_p0 })
}

/// ```prism
/// IsName: fn Pa -> Bool
/// ```
pub fn is_name(pa0: &crate::lower::model::Pa) -> bool {
    match pa0 {
        crate::lower::model::Pa::PaBind(_) => true,
        crate::lower::model::Pa::PaMut(_) => true,
        other_p0 => false,
    }
}

/// ```prism
/// PatName: fn Pa -> Text
/// ```
pub fn pat_name(pa0: &crate::lower::model::Pa) -> Text {
    match pa0 {
        crate::lower::model::Pa::PaBind(n_p0) => crate::emit::cpp::cpp_id(n_p0),
        crate::lower::model::Pa::PaMut(n_p1) => crate::emit::cpp::cpp_id(n_p1),
        other_p2 => Text::lit("_"),
    }
}

/// ```prism
/// CppIfLet: unbounded fn Cp, Pa, Ex, [Do], [Do] -> Text
/// ```
pub fn cpp_if_let(cp0_p0: &crate::emit::cpp::Cp, p_p1: &crate::lower::model::Pa, x_p2: &crate::lower::model::Ex, t_p3: &Array<crate::lower::model::Do>, e_p4: &Array<crate::lower::model::Do>) -> Text {
    let cp_p5 = unbind(cp0_p0, &pat_names(p_p1));
    let v_p6 = Text::lit("_m");
    let head_p7 = Text::from(format!("if (auto&& _m = {}; {})", &crate::emit::cpp::expr::cpp_expr(&cp_p5, x_p2), &crate::emit::cpp::patterns::conds(&crate::emit::cpp::patterns::pat_conds(&cp_p5, p_p1, &v_p6))));
    let body_p8 = crate::syntax::lexer::chars::join(&append(&crate::emit::cpp::patterns::pat_binds(&cp_p5, p_p1, &v_p6), &Array::from(vec![cpp_statements(&cp_p5, t_p3)])), &Text::lit("\n"));
    Text::from(format!("{}{}", &crate::emit::cpp::templates::items::block(&head_p7, &body_p8), &cpp_else(&cp_p5, e_p4)))
}

/// The step machine of `CppIfLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppIfLet: unbounded fn Cp, Pa, Ex, [Do], [Do] -> Text
/// ```
pub struct CppIfLet {
    pub cp0_p0: crate::emit::cpp::Cp,
    pub p_p1: crate::lower::model::Pa,
    pub x_p2: crate::lower::model::Ex,
    pub t_p3: Array<crate::lower::model::Do>,
    pub e_p4: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for CppIfLet {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp0_p0 = &self.cp0_p0;
        let p_p1 = &self.p_p1;
        let x_p2 = &self.x_p2;
        let t_p3 = &self.t_p3;
        let e_p4 = &self.e_p4;
        let cp0_p0 = cp0_p0.clone();
        let e_p4 = e_p4.clone();
        let p_p1 = p_p1.clone();
        let t_p3 = t_p3.clone();
        let x_p2 = x_p2.clone();
        call_then(start_pat_names(p_p1.clone()), move |pat_names_11255: Array<Text>| {
            let cp_p5 = unbind(&cp0_p0, &pat_names_11255);
            let v_p6 = Text::lit("_m");
            call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p5.clone(), x_p2.clone()), move |cpp_expr_11317: Text| call_then(crate::emit::cpp::patterns::start_pat_conds(cp_p5.clone(), p_p1.clone(), v_p6.clone()), move |pat_conds_11341: Array<Text>| {
                let head_p7 = Text::from(format!("if (auto&& _m = {}; {})", &cpp_expr_11317, &crate::emit::cpp::patterns::conds(&pat_conds_11341)));
                call_then(crate::emit::cpp::patterns::start_pat_binds(cp_p5.clone(), p_p1.clone(), v_p6.clone()), move |pat_binds_11392: Array<Text>| call_then(start_cpp_statements(cp_p5.clone(), t_p3.clone()), move |cpp_statements_11415: Text| {
                    let body_p8 = crate::syntax::lexer::chars::join(&append(&pat_binds_11392, &Array::from(vec![cpp_statements_11415])), &Text::lit("\n"));
                    call_then(start_cpp_else(cp_p5.clone(), e_p4.clone()), move |cpp_else_11469: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &crate::emit::cpp::templates::items::block(&head_p7, &body_p8), &cpp_else_11469))))
                }))
            }))
        })
    }
}

/// `Start CppIfLet, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_if_let(cp0_p0: crate::emit::cpp::Cp, p_p1: crate::lower::model::Pa, x_p2: crate::lower::model::Ex, t_p3: Array<crate::lower::model::Do>, e_p4: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppIfLet { cp0_p0, p_p1, x_p2, t_p3, e_p4 })
}

/// ```prism
/// CppDoMatch: unbounded fn Cp, Ex, [((Pa, [Do]))] -> Text
/// ```
pub fn cpp_do_match(cp_p0: &crate::emit::cpp::Cp, x_p1: &crate::lower::model::Ex, cases_p2: &Array<(crate::lower::model::Pa, Array<crate::lower::model::Do>)>) -> Text {
    let v_p3 = Text::lit("_m");
    let arms_p4 = run_to_end(each_job(cases_p2.clone(), {
        let cp_p0 = cp_p0.clone();
        let v_p3 = v_p3.clone();
        Rc::new(move |p0: (crate::lower::model::Pa, Array<crate::lower::model::Do>)| {
            let cp_p0 = cp_p0.clone();
            let v_p3 = v_p3.clone();
            entered(once_job(move || {
                let (p_p6, body_p7) = p0;
                call_then(crate::emit::cpp::patterns::start_pat_conds(cp_p0.clone(), p_p6.clone(), v_p3.clone()), move |pat_conds_11649: Array<Text>| {
                    let tests_p8 = pat_conds_11649;
                    call_then(crate::emit::cpp::patterns::start_pat_binds(cp_p0.clone(), p_p6.clone(), v_p3.clone()), move |pat_binds_11701: Array<Text>| call_then(start_cpp_statements(cp_p0.clone(), body_p7.clone()), move |cpp_statements_11724: Text| {
                        let inner_p9 = crate::syntax::lexer::chars::join(&append(&pat_binds_11701, &Array::from(vec![cpp_statements_11724])), &Text::lit("\n"));
                        prism_rtl::Turn::Finished((tests_p8.clone(), inner_p9.clone()))
                    }))
                })
            }))
        }) as Rc<dyn Fn((crate::lower::model::Pa, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Text)>>>
    }));
    let blocks_p5 = each(&crate::check::errors::range0(&len(&arms_p4)), &(|i_pa: &Nat| {
        let (tests_pc, inner_pd) = or(&index(&arms_p4, i_pa), &(Array::new(), Text::lit("")));
        let head_pb = if i_pa == &Nat::from(0u32) {
            Text::from(format!("if ({})", &crate::emit::cpp::patterns::conds(&tests_pc)))
        } else {
            if &len(&tests_pc) == &Nat::from(0u32) {
                Text::lit("else")
            } else {
                Text::from(format!("else if ({})", &crate::emit::cpp::patterns::conds(&tests_pc)))
            }
        };
        crate::emit::cpp::templates::items::block(&head_pb, &inner_pd)
    }));
    crate::emit::cpp::templates::items::braced(&Text::from(format!("auto&& _m = {};\n{}", &crate::emit::cpp::expr::cpp_expr(cp_p0, x_p1), &crate::syntax::lexer::chars::join(&blocks_p5, &Text::lit(" ")))))
}

/// The step machine of `CppDoMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppDoMatch: unbounded fn Cp, Ex, [((Pa, [Do]))] -> Text
/// ```
pub struct CppDoMatch {
    pub cp_p0: crate::emit::cpp::Cp,
    pub x_p1: crate::lower::model::Ex,
    pub cases_p2: Array<(crate::lower::model::Pa, Array<crate::lower::model::Do>)>,
}

impl prism_rtl::Job<Text> for CppDoMatch {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let x_p1 = &self.x_p1;
        let cases_p2 = &self.cases_p2;
        let v_p3 = Text::lit("_m");
        let cases_p2 = cases_p2.clone();
        let cp_p0 = cp_p0.clone();
        let x_p1 = x_p1.clone();
        call_value(each_job(cases_p2.clone(), {
            let cp_p0 = cp_p0.clone();
            let v_p3 = v_p3.clone();
            Rc::new(move |p0: (crate::lower::model::Pa, Array<crate::lower::model::Do>)| {
                let cp_p0 = cp_p0.clone();
                let v_p3 = v_p3.clone();
                entered(once_job(move || {
                    let (p_p6, body_p7) = p0;
                    call_then(crate::emit::cpp::patterns::start_pat_conds(cp_p0.clone(), p_p6.clone(), v_p3.clone()), move |pat_conds_11649: Array<Text>| {
                        let tests_p8 = pat_conds_11649;
                        call_then(crate::emit::cpp::patterns::start_pat_binds(cp_p0.clone(), p_p6.clone(), v_p3.clone()), move |pat_binds_11701: Array<Text>| call_then(start_cpp_statements(cp_p0.clone(), body_p7.clone()), move |cpp_statements_11724: Text| {
                            let inner_p9 = crate::syntax::lexer::chars::join(&append(&pat_binds_11701, &Array::from(vec![cpp_statements_11724])), &Text::lit("\n"));
                            prism_rtl::Turn::Finished((tests_p8.clone(), inner_p9.clone()))
                        }))
                    })
                }))
            }) as Rc<dyn Fn((crate::lower::model::Pa, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Text)>>>
        }), move |each_11602: Array<(Array<Text>, Text)>| {
            let arms_p4 = each_11602;
            let blocks_p5 = each(&crate::check::errors::range0(&len(&arms_p4)), &(|i_pa: &Nat| {
                let (tests_pc, inner_pd) = or(&index(&arms_p4, i_pa), &(Array::new(), Text::lit("")));
                let head_pb = if i_pa == &Nat::from(0u32) {
                    Text::from(format!("if ({})", &crate::emit::cpp::patterns::conds(&tests_pc)))
                } else {
                    if &len(&tests_pc) == &Nat::from(0u32) {
                        Text::lit("else")
                    } else {
                        Text::from(format!("else if ({})", &crate::emit::cpp::patterns::conds(&tests_pc)))
                    }
                };
                crate::emit::cpp::templates::items::block(&head_pb, &inner_pd)
            }));
            call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), x_p1.clone()), move |cpp_expr_12054: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::braced(&Text::from(format!("auto&& _m = {};\n{}", &cpp_expr_12054, &crate::syntax::lexer::chars::join(&blocks_p5, &Text::lit(" ")))))))
        })
    }
}

/// `Start CppDoMatch, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_do_match(cp_p0: crate::emit::cpp::Cp, x_p1: crate::lower::model::Ex, cases_p2: Array<(crate::lower::model::Pa, Array<crate::lower::model::Do>)>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppDoMatch { cp_p0, x_p1, cases_p2 })
}

/// ```prism
/// CppFor: unbounded fn Cp, Pa, Ex, [Do] -> Text
/// ```
pub fn cpp_for(cp0_p0: &crate::emit::cpp::Cp, p_p1: &crate::lower::model::Pa, x_p2: &crate::lower::model::Ex, body_p3: &Array<crate::lower::model::Do>) -> Text {
    cpp_for_in(&unbind(cp0_p0, &pat_names(p_p1)), p_p1, &crate::emit::cpp::expr::cpp_place(cp0_p0, x_p2), body_p3)
}

/// The step machine of `CppFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppFor: unbounded fn Cp, Pa, Ex, [Do] -> Text
/// ```
pub struct CppFor {
    pub cp0_p0: crate::emit::cpp::Cp,
    pub p_p1: crate::lower::model::Pa,
    pub x_p2: crate::lower::model::Ex,
    pub body_p3: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for CppFor {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp0_p0 = &self.cp0_p0;
        let p_p1 = &self.p_p1;
        let x_p2 = &self.x_p2;
        let body_p3 = &self.body_p3;
        let body_p3 = body_p3.clone();
        let cp0_p0 = cp0_p0.clone();
        let p_p1 = p_p1.clone();
        let x_p2 = x_p2.clone();
        call_then(start_pat_names(p_p1.clone()), move |pat_names_12268: Array<Text>| call_then(crate::emit::cpp::expr::start_cpp_place(cp0_p0.clone(), x_p2.clone()), move |cpp_place_12286: Text| prism_rtl::Turn::More(Rc::new(CppForIn { cp_p0: unbind(&cp0_p0, &pat_names_12268), p_p1: p_p1.clone(), xs_p2: cpp_place_12286, body_p3: body_p3.clone() }))))
    }
}

/// `Start CppFor, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_for(cp0_p0: crate::emit::cpp::Cp, p_p1: crate::lower::model::Pa, x_p2: crate::lower::model::Ex, body_p3: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppFor { cp0_p0, p_p1, x_p2, body_p3 })
}

/// ```prism
/// CppForIn: unbounded fn Cp, Pa, Text, [Do] -> Text
/// ```
pub fn cpp_for_in(cp_p0: &crate::emit::cpp::Cp, p_p1: &crate::lower::model::Pa, xs_p2: &Text, body_p3: &Array<crate::lower::model::Do>) -> Text {
    match p_p1 {
        crate::lower::model::Pa::PaBind(n_p4) => crate::emit::cpp::templates::items::block(&Text::from(format!("for (auto&& {} : {})", &crate::emit::cpp::cpp_id(n_p4), xs_p2)), &cpp_statements(cp_p0, body_p3)),
        crate::lower::model::Pa::PaMut(n_p5) => crate::emit::cpp::templates::items::block(&Text::from(format!("for (auto {} : {})", &crate::emit::cpp::cpp_id(n_p5), xs_p2)), &cpp_statements(cp_p0, body_p3)),
        crate::lower::model::Pa::PaTuple(ps_p6) => if fold(ps_p6, &true, &(|f_p7: &bool, q_p8: &crate::lower::model::Pa| *f_p7 && is_name(q_p8))) {
            crate::emit::cpp::templates::items::block(&Text::from(format!("for (auto&& [{}] : {})", &crate::syntax::lexer::chars::join(&each(ps_p6, &(|q_p9: &crate::lower::model::Pa| pat_name(q_p9))), &Text::lit(", ")), xs_p2)), &cpp_statements(cp_p0, body_p3))
        } else {
            crate::emit::cpp::templates::items::block(&Text::from(format!("for (auto&& _e : {})", xs_p2)), &crate::syntax::lexer::chars::join(&append(&crate::emit::cpp::patterns::pat_binds(cp_p0, p_p1, &Text::lit("_e")), &Array::from(vec![cpp_statements(cp_p0, body_p3)])), &Text::lit("\n")))
        },
        _ => crate::emit::cpp::templates::items::block(&Text::from(format!("for (auto&& _e : {})", xs_p2)), &crate::syntax::lexer::chars::join(&append(&crate::emit::cpp::patterns::pat_binds(cp_p0, p_p1, &Text::lit("_e")), &Array::from(vec![cpp_statements(cp_p0, body_p3)])), &Text::lit("\n"))),
    }
}

/// The step machine of `CppForIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppForIn: unbounded fn Cp, Pa, Text, [Do] -> Text
/// ```
pub struct CppForIn {
    pub cp_p0: crate::emit::cpp::Cp,
    pub p_p1: crate::lower::model::Pa,
    pub xs_p2: Text,
    pub body_p3: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for CppForIn {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let p_p1 = &self.p_p1;
        let xs_p2 = &self.xs_p2;
        let body_p3 = &self.body_p3;
        match p_p1 {
            crate::lower::model::Pa::PaBind(n_p4) => {
                let body_p3 = body_p3.clone();
                let cp_p0 = cp_p0.clone();
                let n_p4 = n_p4.clone();
                let xs_p2 = xs_p2.clone();
                call_then(start_cpp_statements(cp_p0.clone(), body_p3.clone()), move |cpp_statements_12453: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::block(&Text::from(format!("for (auto&& {} : {})", &crate::emit::cpp::cpp_id(&n_p4), &xs_p2)), &cpp_statements_12453)))
            },
            crate::lower::model::Pa::PaMut(n_p5) => {
                let body_p3 = body_p3.clone();
                let cp_p0 = cp_p0.clone();
                let n_p5 = n_p5.clone();
                let xs_p2 = xs_p2.clone();
                call_then(start_cpp_statements(cp_p0.clone(), body_p3.clone()), move |cpp_statements_12528: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::block(&Text::from(format!("for (auto {} : {})", &crate::emit::cpp::cpp_id(&n_p5), &xs_p2)), &cpp_statements_12528)))
            },
            crate::lower::model::Pa::PaTuple(ps_p6) => if fold(ps_p6, &true, &(|f_p7: &bool, q_p8: &crate::lower::model::Pa| *f_p7 && is_name(q_p8))) {
                {
                    let body_p3 = body_p3.clone();
                    let cp_p0 = cp_p0.clone();
                    let ps_p6 = ps_p6.clone();
                    let xs_p2 = xs_p2.clone();
                    call_then(start_cpp_statements(cp_p0.clone(), body_p3.clone()), move |cpp_statements_12689: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::block(&Text::from(format!("for (auto&& [{}] : {})", &crate::syntax::lexer::chars::join(&each(&ps_p6, &(|q_p9: &crate::lower::model::Pa| pat_name(q_p9))), &Text::lit(", ")), &xs_p2)), &cpp_statements_12689)))
                }
            } else {
                {
                    let body_p3 = body_p3.clone();
                    let cp_p0 = cp_p0.clone();
                    let p_p1 = p_p1.clone();
                    let xs_p2 = xs_p2.clone();
                    call_then(crate::emit::cpp::patterns::start_pat_binds(cp_p0.clone(), p_p1.clone(), Text::lit("_e")), move |pat_binds_12774: Array<Text>| call_then(start_cpp_statements(cp_p0.clone(), body_p3.clone()), move |cpp_statements_12800: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::block(&Text::from(format!("for (auto&& _e : {})", &xs_p2)), &crate::syntax::lexer::chars::join(&append(&pat_binds_12774, &Array::from(vec![cpp_statements_12800])), &Text::lit("\n"))))))
                }
            },
            _ => {
                let body_p3 = body_p3.clone();
                let cp_p0 = cp_p0.clone();
                let p_p1 = p_p1.clone();
                let xs_p2 = xs_p2.clone();
                call_then(crate::emit::cpp::patterns::start_pat_binds(cp_p0.clone(), p_p1.clone(), Text::lit("_e")), move |pat_binds_12896: Array<Text>| call_then(start_cpp_statements(cp_p0.clone(), body_p3.clone()), move |cpp_statements_12922: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::block(&Text::from(format!("for (auto&& _e : {})", &xs_p2)), &crate::syntax::lexer::chars::join(&append(&pat_binds_12896, &Array::from(vec![cpp_statements_12922])), &Text::lit("\n"))))))
            },
        }
    }
}

/// `Start CppForIn, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_for_in(cp_p0: crate::emit::cpp::Cp, p_p1: crate::lower::model::Pa, xs_p2: Text, body_p3: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppForIn { cp_p0, p_p1, xs_p2, body_p3 })
}

/// ```prism
/// CppBody: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_body(cp_p0: &crate::emit::cpp::Cp, ex1: &crate::lower::model::Ex) -> Text {
    match ex1 {
        crate::lower::model::Ex::XBlock(dos_p1, e_p2) => {
            let (st_p3, cp2_p4) = cpp_statements_cp(cp_p0, dos_p1);
            if &len(dos_p1) == &Nat::from(0u32) {
                cpp_body(cp_p0, &**e_p2)
            } else {
                Text::from(format!("{}\n{}", &st_p3, &cpp_body(&cp2_p4, &**e_p2)))
            }
        },
        crate::lower::model::Ex::XMatch(s_p6, arms_p7, fallback_p8, t_p9) => crate::emit::cpp::patterns::return_match(cp_p0, &**s_p6, arms_p7, t_p9),
        crate::lower::model::Ex::XChain(label_pb, s_pc, arms_pd, t_pe) => crate::emit::cpp::patterns::return_match(cp_p0, &**s_pc, arms_pd, t_pe),
        x_pg => if crate::emit::cpp::patterns::leaves(x_pg) {
            Text::from(format!("{};", &crate::emit::cpp::expr::cpp_expr(cp_p0, x_pg)))
        } else {
            Text::from(format!("return {};", &cpp_returned(cp_p0, x_pg)))
        },
    }
}

/// The step machine of `CppBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppBody: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppBody {
    pub cp_p0: crate::emit::cpp::Cp,
    pub ex1: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppBody {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let ex1 = &self.ex1;
        match ex1 {
            crate::lower::model::Ex::XBlock(dos_p1, e_p2) => {
                let cp_p0 = cp_p0.clone();
                let dos_p1 = dos_p1.clone();
                let e_p2 = (**e_p2).clone();
                call_then(start_cpp_statements_cp(cp_p0.clone(), dos_p1.clone()), move |cpp_statements_cp_13110: (Text, crate::emit::cpp::Cp)| {
                    let (st_p3, cp2_p4) = cpp_statements_cp_13110;
                    if &len(&dos_p1) == &Nat::from(0u32) {
                        prism_rtl::Turn::More(Rc::new(CppBody { cp_p0: cp_p0.clone(), ex1: e_p2.clone() }))
                    } else {
                        call_then(start_cpp_body(cp2_p4.clone(), e_p2.clone()), move |cpp_body_13185: Text| prism_rtl::Turn::Finished(Text::from(format!("{}\n{}", &st_p3, &cpp_body_13185))))
                    }
                })
            },
            crate::lower::model::Ex::XMatch(s_p6, arms_p7, fallback_p8, t_p9) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::patterns::ReturnMatch { cp_p0: cp_p0.clone(), s_p1: (**s_p6).clone(), arms_p2: arms_p7.clone(), out_ty3: t_p9.clone() })),
            crate::lower::model::Ex::XChain(label_pb, s_pc, arms_pd, t_pe) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::patterns::ReturnMatch { cp_p0: cp_p0.clone(), s_p1: (**s_pc).clone(), arms_p2: arms_pd.clone(), out_ty3: t_pe.clone() })),
            x_pg => if crate::emit::cpp::patterns::leaves(x_pg) {
                {
                    let cp_p0 = cp_p0.clone();
                    let x_pg = x_pg.clone();
                    call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), x_pg.clone()), move |cpp_expr_13381: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &cpp_expr_13381))))
                }
            } else {
                {
                    let cp_p0 = cp_p0.clone();
                    let x_pg = x_pg.clone();
                    call_then(start_cpp_returned(cp_p0.clone(), x_pg.clone()), move |cpp_returned_13413: Text| prism_rtl::Turn::Finished(Text::from(format!("return {};", &cpp_returned_13413))))
                }
            },
        }
    }
}

/// `Start CppBody, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_body(cp_p0: crate::emit::cpp::Cp, ex1: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppBody { cp_p0, ex1 })
}

/// ```prism
/// CppReturned: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_returned(cp_p0: &crate::emit::cpp::Cp, ex1: &crate::lower::model::Ex) -> Text {
    match ex1 {
        crate::lower::model::Ex::XVar(n_p1) => var_name(cp_p0, n_p1),
        x_p3 => crate::emit::cpp::expr::cpp_expr(cp_p0, x_p3),
    }
}

/// The step machine of `CppReturned`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppReturned: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppReturned {
    pub cp_p0: crate::emit::cpp::Cp,
    pub ex1: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppReturned {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let ex1 = &self.ex1;
        match ex1 {
            crate::lower::model::Ex::XVar(n_p1) => prism_rtl::Turn::Finished(var_name(cp_p0, n_p1)),
            x_p3 => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::expr::CppExpr { cp_p0: cp_p0.clone(), x_p1: x_p3.clone() })),
        }
    }
}

/// `Start CppReturned, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_returned(cp_p0: crate::emit::cpp::Cp, ex1: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppReturned { cp_p0, ex1 })
}
