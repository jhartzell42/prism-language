//! The module `Emit.Cpp.Stmts`, from `target/bootstrap/src/prismc/emit/cpp/stmts.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// CppStatements: unbounded fn Cp, [Do] -> Text
/// ```
pub fn cpp_statements_f(cp_p0: &crate::emit::cpp::Cp, dos_p1: &crate::prelude::Array<crate::lower::model::Do>) -> crate::prelude::Text {
    let (st_p2, _) = cpp_statements_cp_f(cp_p0, dos_p1);
    st_p2.clone()
}

/// The step machine of `CppStatements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppStatements: unbounded fn Cp, [Do] -> Text
/// ```
pub struct CppStatements {
    pub cp_p0: crate::emit::cpp::Cp,
    pub dos_p1: crate::prelude::Array<crate::lower::model::Do>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppStatements {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let dos_p1 = &self.dos_p1;
        let cp_p0x = cp_p0.clone();
        let dos_p1x = dos_p1.clone();
        crate::prelude::call_then(start_cpp_statements_cp_f(cp_p0x.clone(), dos_p1x.clone()), move |cpp_statements_cp_f_1153: (crate::prelude::Text, crate::emit::cpp::Cp)| {
            let (st_p2, _) = cpp_statements_cp_f_1153;
            ::prism_rtl::Turn::Finished(st_p2.clone())
        })
    }
}

/// `Start CppStatements, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_statements_f(cp_p0: crate::emit::cpp::Cp, dos_p1: crate::prelude::Array<crate::lower::model::Do>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppStatements { cp_p0, dos_p1 })
}

/// ```prism
/// CppStatementsCp: unbounded fn Cp, [Do] -> ((Text, Cp))
/// ```
pub fn cpp_statements_cp_f(cp_p0: &crate::emit::cpp::Cp, dos_p1: &crate::prelude::Array<crate::lower::model::Do>) -> (crate::prelude::Text, crate::emit::cpp::Cp) {
    let (lines_p9, last_pa) = crate::prelude::run_to_end(crate::prelude::fold_job(dos_p1.clone(), (crate::prelude::Array::new(), cp_p0.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::prelude::Text>, crate::emit::cpp::Cp), crate::lower::model::Do)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (acc_p2, c_p3) = p0;
        let d_p4 = p1;
        crate::prelude::call_then(start_rebound_f(c_p3.clone(), d_p4.clone()), move |rebound_f_1580: crate::emit::cpp::Cp| {
            let c2_p5 = rebound_f_1580;
            let acc_p2z = acc_p2.clone();
            let c2_p5z = c2_p5.clone();
            let k_let1601 = move |v1601: crate::prelude::Text| {
                let line_p6 = v1601;
                ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p2z, &line_p6), c2_p5z.clone()))
            };
            match d_p4.clone() {
                crate::lower::model::Do::DoLet(p_p7, x_p8) => crate::prelude::call_then(start_cpp_let_f(c_p3.clone(), c2_p5.clone(), p_p7.clone(), x_p8.clone()), move |cpp_let_f_1645: crate::prelude::Text| k_let1601(cpp_let_f_1645)),
                _ => crate::prelude::call_then(start_cpp_statement_f(c2_p5.clone(), d_p4.clone()), move |cpp_statement_f_1687: crate::prelude::Text| k_let1601(cpp_statement_f_1687)),
            }
        })
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::prelude::Text>, crate::emit::cpp::Cp), crate::lower::model::Do)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, crate::emit::cpp::Cp)>>>));
    (crate::syntax::lexer::chars::join_f(&lines_p9, &crate::prelude::Text::lit("\n")), last_pa.clone())
}

/// The step machine of `CppStatementsCp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppStatementsCp: unbounded fn Cp, [Do] -> ((Text, Cp))
/// ```
pub struct CppStatementsCp {
    pub cp_p0: crate::emit::cpp::Cp,
    pub dos_p1: crate::prelude::Array<crate::lower::model::Do>,
}

impl ::prism_rtl::Job<(crate::prelude::Text, crate::emit::cpp::Cp)> for CppStatementsCp {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Text, crate::emit::cpp::Cp)> {
        let cp_p0 = &self.cp_p0;
        let dos_p1 = &self.dos_p1;
        let cp_p0x = cp_p0.clone();
        let dos_p1x = dos_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(dos_p1x.clone(), (crate::prelude::Array::new(), cp_p0x.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::prelude::Text>, crate::emit::cpp::Cp), crate::lower::model::Do)| crate::prelude::entered(crate::prelude::once_job(move || {
            let (acc_p2, c_p3) = p0;
            let d_p4 = p1;
            crate::prelude::call_then(start_rebound_f(c_p3.clone(), d_p4.clone()), move |rebound_f_1580: crate::emit::cpp::Cp| {
                let c2_p5 = rebound_f_1580;
                let acc_p2z = acc_p2.clone();
                let c2_p5z = c2_p5.clone();
                let k_let1601 = move |v1601: crate::prelude::Text| {
                    let line_p6 = v1601;
                    ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_p2z, &line_p6), c2_p5z.clone()))
                };
                match d_p4.clone() {
                    crate::lower::model::Do::DoLet(p_p7, x_p8) => crate::prelude::call_then(start_cpp_let_f(c_p3.clone(), c2_p5.clone(), p_p7.clone(), x_p8.clone()), move |cpp_let_f_1645: crate::prelude::Text| k_let1601(cpp_let_f_1645)),
                    _ => crate::prelude::call_then(start_cpp_statement_f(c2_p5.clone(), d_p4.clone()), move |cpp_statement_f_1687: crate::prelude::Text| k_let1601(cpp_statement_f_1687)),
                }
            })
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::prelude::Text>, crate::emit::cpp::Cp), crate::lower::model::Do)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, crate::emit::cpp::Cp)>>>), move |fold_1522: (crate::prelude::Array<crate::prelude::Text>, crate::emit::cpp::Cp)| {
            let (lines_p9, last_pa) = fold_1522;
            ::prism_rtl::Turn::Finished((crate::syntax::lexer::chars::join_f(&lines_p9, &crate::prelude::Text::lit("\n")), last_pa.clone()))
        })
    }
}

/// `Start CppStatementsCp, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_statements_cp_f(cp_p0: crate::emit::cpp::Cp, dos_p1: crate::prelude::Array<crate::lower::model::Do>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::emit::cpp::Cp)>> {
    ::std::rc::Rc::new(CppStatementsCp { cp_p0, dos_p1 })
}

/// ```prism
/// Unvexed: fn Text -> Text
/// ```
pub fn unvexed_f(t_p0: &crate::prelude::Text) -> crate::prelude::Text {
    let head_p1 = crate::prelude::or(&crate::prelude::index(&crate::prelude::split_on(t_p0, &crate::prelude::Text::lit("(")), &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit(""));
    let type_like_p2 = crate::syntax::lexer::chars::contains_f(&head_p1, &crate::prelude::Text::lit(":")) || crate::syntax::lexer::chars::contains_f(&crate::prelude::Text::lit("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), &crate::syntax::lexer::chars::head_f(&head_p1));
    let vexing_p3 = (((&crate::syntax::lexer::chars::last_char_f(t_p0) == &crate::prelude::Text::lit(")")) && !crate::syntax::lexer::chars::contains_f(&head_p1, &crate::prelude::Text::lit(" "))) && (&head_p1 != &crate::prelude::Text::lit(""))) && type_like_p2;
    if vexing_p3 {
        crate::prelude::Text::from(format!("({})", t_p0))
    } else {
        t_p0.clone()
    }
}

/// ```prism
/// Rebound: unbounded fn Cp, Do -> Cp
/// ```
pub fn rebound_f(cp_p0: &crate::emit::cpp::Cp, d_p1: &crate::lower::model::Do) -> crate::emit::cpp::Cp {
    match d_p1 {
        crate::lower::model::Do::DoLetElse(p_p2, _, _) => unbind_f(cp_p0, &pat_names_f(p_p2)),
        crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTuple(ps_p3), _) => unbind_f(cp_p0, &pat_names_f(&crate::lower::model::Pa::PaTuple(ps_p3.clone()))),
        crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaCtor(c_p4, ps_p5), _) => unbind_f(cp_p0, &pat_names_f(&crate::lower::model::Pa::PaCtor(c_p4.clone(), ps_p5.clone()))),
        crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaRecord(c_p6, fs_p7, r_p8), _) => unbind_f(cp_p0, &pat_names_f(&crate::lower::model::Pa::PaRecord(c_p6.clone(), fs_p7.clone(), *r_p8))),
        crate::lower::model::Do::DoLet(p_p9, x_pa) => match let_name_o(p_p9) {
            ::std::option::Option::Some(n_pb) => {
                let pointing_pc = if is_pointer_let_f(cp_p0, p_p9, x_pa) {
                    pointing_f(cp_p0, &n_pb)
                } else {
                    known_value_f(cp_p0, p_p9, &n_pb)
                };
                let held_pd = if is_value_let_f(p_p9, x_pa) {
                    owning_f(&pointing_pc, &n_pb)
                } else {
                    disowning_f(&pointing_pc, &n_pb)
                };
                match p_p9 {
                    crate::lower::model::Pa::PaTyped(_, t_pe) => {
                        let mut this: crate::emit::cpp::Cp = held_pd.clone();
                        this.local_types_p = crate::prelude::insert(&this.local_types_p, &n_pb, t_pe);
                        this
                    },
                    _ => {
                        let mut this: crate::emit::cpp::Cp = held_pd.clone();
                        this.local_types_p = crate::prelude::remove(&this.local_types_p, &n_pb);
                        this
                    },
                }
            },
            ::std::option::Option::None => cp_p0.clone(),
        },
        _ => cp_p0.clone(),
    }
}

/// The step machine of `Rebound`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Rebound: unbounded fn Cp, Do -> Cp
/// ```
pub struct Rebound {
    pub cp_p0: crate::emit::cpp::Cp,
    pub d_p1: crate::lower::model::Do,
}

impl ::prism_rtl::Job<crate::emit::cpp::Cp> for Rebound {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::emit::cpp::Cp> {
        let cp_p0 = &self.cp_p0;
        let d_p1 = &self.d_p1;
        match d_p1 {
            crate::lower::model::Do::DoLetElse(p_p2, _, _) => {
                let cp_p0x = cp_p0.clone();
                let p_p2x = p_p2.clone();
                crate::prelude::call_then(start_pat_names_f(p_p2x.clone()), move |pat_names_f_2368: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(unbind_f(&cp_p0x, &pat_names_f_2368)))
            },
            crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTuple(ps_p3), _) => {
                let cp_p0x = cp_p0.clone();
                let ps_p3x = ps_p3.clone();
                crate::prelude::call_then(start_pat_names_f(crate::lower::model::Pa::PaTuple(ps_p3x.clone())), move |pat_names_f_2424: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(unbind_f(&cp_p0x, &pat_names_f_2424)))
            },
            crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaCtor(c_p4, ps_p5), _) => {
                let c_p4x = c_p4.clone();
                let cp_p0x = cp_p0.clone();
                let ps_p5x = ps_p5.clone();
                crate::prelude::call_then(start_pat_names_f(crate::lower::model::Pa::PaCtor(c_p4x.clone(), ps_p5x.clone())), move |pat_names_f_2493: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(unbind_f(&cp_p0x, &pat_names_f_2493)))
            },
            crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaRecord(c_p6, fs_p7, r_p8), _) => {
                let c_p6x = c_p6.clone();
                let cp_p0x = cp_p0.clone();
                let fs_p7x = fs_p7.clone();
                let r_p8x = *r_p8;
                crate::prelude::call_then(start_pat_names_f(crate::lower::model::Pa::PaRecord(c_p6x.clone(), fs_p7x.clone(), r_p8x)), move |pat_names_f_2569: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(unbind_f(&cp_p0x, &pat_names_f_2569)))
            },
            crate::lower::model::Do::DoLet(p_p9, x_pa) => match let_name_o(p_p9) {
                ::std::option::Option::Some(n_pb) => {
                    let pointing_pc = if is_pointer_let_f(cp_p0, p_p9, x_pa) {
                        pointing_f(cp_p0, &n_pb)
                    } else {
                        known_value_f(cp_p0, p_p9, &n_pb)
                    };
                    let held_pd = if is_value_let_f(p_p9, x_pa) {
                        owning_f(&pointing_pc, &n_pb)
                    } else {
                        disowning_f(&pointing_pc, &n_pb)
                    };
                    match p_p9 {
                        crate::lower::model::Pa::PaTyped(_, t_pe) => ::prism_rtl::Turn::Finished({
                            let mut this: crate::emit::cpp::Cp = held_pd.clone();
                            this.local_types_p = crate::prelude::insert(&this.local_types_p, &n_pb, t_pe);
                            this
                        }),
                        _ => ::prism_rtl::Turn::Finished({
                            let mut this: crate::emit::cpp::Cp = held_pd.clone();
                            this.local_types_p = crate::prelude::remove(&this.local_types_p, &n_pb);
                            this
                        }),
                    }
                },
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(cp_p0.clone()),
            },
            _ => ::prism_rtl::Turn::Finished(cp_p0.clone()),
        }
    }
}

/// `Start Rebound, x`: what the function value is when passed to `@Run`.
pub fn start_rebound_f(cp_p0: crate::emit::cpp::Cp, d_p1: crate::lower::model::Do) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::emit::cpp::Cp>> {
    ::std::rc::Rc::new(Rebound { cp_p0, d_p1 })
}

/// ```prism
/// IsValueLet: fn Pa, Ex -> Bool
/// ```
pub fn is_value_let_f(p_p0: &crate::lower::model::Pa, x_p1: &crate::lower::model::Ex) -> bool {
    match p_p0 {
        crate::lower::model::Pa::PaBind(_) => match x_p1 {
            crate::lower::model::Ex::XRef(_) => false,
            _ => true,
        },
        crate::lower::model::Pa::PaMut(_) => true,
        crate::lower::model::Pa::PaTyped(_, crate::lower::model::OutTy::OutRef(_)) => false,
        crate::lower::model::Pa::PaTyped(_, _) => true,
        _ => false,
    }
}

/// ```prism
/// Owning: fn Cp, Text -> Cp
/// ```
pub fn owning_f(cp_p0: &crate::emit::cpp::Cp, n_p1: &crate::prelude::Text) -> crate::emit::cpp::Cp {
    let mut this: crate::emit::cpp::Cp = cp_p0.clone();
    this.owned_p = crate::prelude::insert(&this.owned_p, n_p1, &true);
    this
}

/// ```prism
/// Disowning: fn Cp, Text -> Cp
/// ```
pub fn disowning_f(cp_p0: &crate::emit::cpp::Cp, n_p1: &crate::prelude::Text) -> crate::emit::cpp::Cp {
    let mut this: crate::emit::cpp::Cp = cp_p0.clone();
    this.owned_p = crate::prelude::remove(&this.owned_p, n_p1);
    this
}

/// ```prism
/// Captured: fn Cp -> Cp
/// ```
pub fn captured_f(cp_p0: &crate::emit::cpp::Cp) -> crate::emit::cpp::Cp {
    let mut this: crate::emit::cpp::Cp = cp_p0.clone();
    this.owned_p = crate::prelude::Map::new();
    this.move_captures_p = crate::prelude::Array::new();
    this
}

/// ```prism
/// PatNames: unbounded fn Pa -> [Text]
/// ```
pub fn pat_names_f(p_p0: &crate::lower::model::Pa) -> crate::prelude::Array<crate::prelude::Text> {
    match p_p0 {
        crate::lower::model::Pa::PaBind(n_p1) => crate::prelude::Array::from(vec![n_p1.clone()]),
        crate::lower::model::Pa::PaMut(n_p2) => crate::prelude::Array::from(vec![n_p2.clone()]),
        crate::lower::model::Pa::PaTyped(q_p3, _) => pat_names_f(&**q_p3),
        crate::lower::model::Pa::PaCtor(_, ps_p4) => crate::emit::cpp::patterns::concat2_f(&crate::prelude::run_to_end(crate::prelude::each_job(ps_p4.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Pa| crate::prelude::entered(crate::prelude::once_job(move || {
            let q_p5 = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(PatNames { p_p0: q_p5.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Pa) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>))),
        crate::lower::model::Pa::PaRecord(_, fs_p6, _) => crate::emit::cpp::patterns::concat2_f(&crate::prelude::run_to_end(crate::prelude::each_job(fs_p6.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::Pa)| crate::prelude::entered(crate::prelude::once_job(move || {
            let (_, q_p7) = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(PatNames { p_p0: q_p7.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::Pa)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>))),
        crate::lower::model::Pa::PaTuple(ps_p8) => crate::emit::cpp::patterns::concat2_f(&crate::prelude::run_to_end(crate::prelude::each_job(ps_p8.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Pa| crate::prelude::entered(crate::prelude::once_job(move || {
            let q_p9 = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(PatNames { p_p0: q_p9.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Pa) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>))),
        crate::lower::model::Pa::PaSlice(ps_pa) => crate::emit::cpp::patterns::concat2_f(&crate::prelude::run_to_end(crate::prelude::each_job(ps_pa.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Pa| crate::prelude::entered(crate::prelude::once_job(move || {
            let q_pb = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(PatNames { p_p0: q_pb.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Pa) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>))),
        crate::lower::model::Pa::PaRest(n_pc) => if n_pc == &crate::prelude::Text::lit("") {
            crate::prelude::Array::new()
        } else {
            crate::prelude::Array::from(vec![n_pc.clone()])
        },
        _ => crate::prelude::Array::new(),
    }
}

/// The step machine of `PatNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatNames: unbounded fn Pa -> [Text]
/// ```
pub struct PatNames {
    pub p_p0: crate::lower::model::Pa,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for PatNames {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let p_p0 = &self.p_p0;
        match p_p0 {
            crate::lower::model::Pa::PaBind(n_p1) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![n_p1.clone()])),
            crate::lower::model::Pa::PaMut(n_p2) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![n_p2.clone()])),
            crate::lower::model::Pa::PaTyped(q_p3, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(PatNames { p_p0: (**q_p3).clone() })),
            crate::lower::model::Pa::PaCtor(_, ps_p4) => {
                let ps_p4x = ps_p4.clone();
                crate::prelude::call_value(crate::prelude::each_job(ps_p4x.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Pa| crate::prelude::entered(crate::prelude::once_job(move || {
                    let q_p5 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(PatNames { p_p0: q_p5.clone() }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Pa) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>), move |each_4401: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| ::prism_rtl::Turn::Finished(crate::emit::cpp::patterns::concat2_f(&each_4401)))
            },
            crate::lower::model::Pa::PaRecord(_, fs_p6, _) => {
                let fs_p6x = fs_p6.clone();
                crate::prelude::call_value(crate::prelude::each_job(fs_p6x.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::Pa)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let (_, q_p7) = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(PatNames { p_p0: q_p7.clone() }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::Pa)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>), move |each_4469: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| ::prism_rtl::Turn::Finished(crate::emit::cpp::patterns::concat2_f(&each_4469)))
            },
            crate::lower::model::Pa::PaTuple(ps_p8) => {
                let ps_p8x = ps_p8.clone();
                crate::prelude::call_value(crate::prelude::each_job(ps_p8x.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Pa| crate::prelude::entered(crate::prelude::once_job(move || {
                    let q_p9 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(PatNames { p_p0: q_p9.clone() }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Pa) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>), move |each_4532: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| ::prism_rtl::Turn::Finished(crate::emit::cpp::patterns::concat2_f(&each_4532)))
            },
            crate::lower::model::Pa::PaSlice(ps_pa) => {
                let ps_pax = ps_pa.clone();
                crate::prelude::call_value(crate::prelude::each_job(ps_pax.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Pa| crate::prelude::entered(crate::prelude::once_job(move || {
                    let q_pb = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(PatNames { p_p0: q_pb.clone() }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Pa) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>), move |each_4583: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| ::prism_rtl::Turn::Finished(crate::emit::cpp::patterns::concat2_f(&each_4583)))
            },
            crate::lower::model::Pa::PaRest(n_pc) => if n_pc == &crate::prelude::Text::lit("") {
                ::prism_rtl::Turn::Finished(crate::prelude::Array::new())
            } else {
                ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![n_pc.clone()]))
            },
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start PatNames, x`: what the function value is when passed to `@Run`.
pub fn start_pat_names_f(p_p0: crate::lower::model::Pa) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(PatNames { p_p0 })
}

/// ```prism
/// ArmNames: unbounded fn XArm -> [Text]
/// ```
pub fn arm_names_f(a_p0: &crate::lower::model::XArm) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::append(&pat_names_f(&a_p0.pat_p), &crate::emit::cpp::patterns::concat2_f(&crate::prelude::run_to_end(crate::prelude::each_job(a_p0.conds_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Cc| crate::prelude::entered(crate::prelude::once_job(move || {
        let c_p1 = p0;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(CondNames { cc0: c_p1.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Cc) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>))))
}

/// The step machine of `ArmNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArmNames: unbounded fn XArm -> [Text]
/// ```
pub struct ArmNames {
    pub a_p0: crate::lower::model::XArm,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for ArmNames {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let a_p0 = &self.a_p0;
        let a_p0x = a_p0.clone();
        crate::prelude::call_then(start_pat_names_f(a_p0x.pat_p.clone()), move |pat_names_f_4735: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_value(crate::prelude::each_job(a_p0x.conds_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Cc| crate::prelude::entered(crate::prelude::once_job(move || {
            let c_p1 = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(CondNames { cc0: c_p1.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Cc) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>), move |each_4762: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| ::prism_rtl::Turn::Finished(crate::prelude::append(&pat_names_f_4735, &crate::emit::cpp::patterns::concat2_f(&each_4762)))))
    }
}

/// `Start ArmNames, x`: what the function value is when passed to `@Run`.
pub fn start_arm_names_f(a_p0: crate::lower::model::XArm) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(ArmNames { a_p0 })
}

/// ```prism
/// CondNames: unbounded fn Cc -> [Text]
/// ```
pub fn cond_names_f(cc0: &crate::lower::model::Cc) -> crate::prelude::Array<crate::prelude::Text> {
    match cc0 {
        crate::lower::model::Cc::CcLet(q_p0, _) => pat_names_f(q_p0),
        crate::lower::model::Cc::CcIf(_) => crate::prelude::Array::new(),
    }
}

/// The step machine of `CondNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondNames: unbounded fn Cc -> [Text]
/// ```
pub struct CondNames {
    pub cc0: crate::lower::model::Cc,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for CondNames {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let cc0 = &self.cc0;
        match cc0 {
            crate::lower::model::Cc::CcLet(q_p0, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(PatNames { p_p0: q_p0.clone() })),
            crate::lower::model::Cc::CcIf(_) => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start CondNames, x`: what the function value is when passed to `@Run`.
pub fn start_cond_names_f(cc0: crate::lower::model::Cc) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(CondNames { cc0 })
}

/// ```prism
/// Unbind: fn Cp, [Text] -> Cp
/// ```
pub fn unbind_f(cp_p0: &crate::emit::cpp::Cp, names_p1: &crate::prelude::Array<crate::prelude::Text>) -> crate::emit::cpp::Cp {
    let mut this: crate::emit::cpp::Cp = cp_p0.clone();
    this.pointers_p = crate::prelude::fold(names_p1, &this.pointers_p, &(|m_p2: &crate::prelude::Map<crate::prelude::Text, bool>, n_p3: &crate::prelude::Text| crate::prelude::remove(m_p2, n_p3)));
    this.owned_p = crate::prelude::fold(names_p1, &this.owned_p, &(|m_p4: &crate::prelude::Map<crate::prelude::Text, bool>, n_p5: &crate::prelude::Text| crate::prelude::remove(m_p4, n_p5)));
    this.local_types_p = crate::prelude::fold(names_p1, &this.local_types_p, &(|m_p6: &crate::prelude::Map<crate::prelude::Text, crate::lower::model::OutTy>, n_p7: &crate::prelude::Text| crate::prelude::remove(m_p6, n_p7)));
    this
}

/// ```prism
/// Pointing: fn Cp, Text -> Cp
/// ```
pub fn pointing_f(cp_p0: &crate::emit::cpp::Cp, n_p1: &crate::prelude::Text) -> crate::emit::cpp::Cp {
    let mut this: crate::emit::cpp::Cp = cp_p0.clone();
    this.pointers_p = crate::prelude::insert(&this.pointers_p, n_p1, &true);
    this
}

/// ```prism
/// KnownValue: fn Cp, Pa, Text -> Cp
/// ```
pub fn known_value_f(cp_p0: &crate::emit::cpp::Cp, p_p1: &crate::lower::model::Pa, n_p2: &crate::prelude::Text) -> crate::emit::cpp::Cp {
    match p_p1 {
        crate::lower::model::Pa::PaTyped(_, _) => {
            let mut this: crate::emit::cpp::Cp = cp_p0.clone();
            this.pointers_p = crate::prelude::insert(&this.pointers_p, n_p2, &false);
            this
        },
        _ => cp_p0.clone(),
    }
}

/// ```prism
/// IsPointerLet: fn Cp, Pa, Ex -> Bool
/// ```
pub fn is_pointer_let_f(cp_p0: &crate::emit::cpp::Cp, p_p1: &crate::lower::model::Pa, x_p2: &crate::lower::model::Ex) -> bool {
    match p_p1 {
        crate::lower::model::Pa::PaTyped(_, t_p3) => crate::emit::cpp::expr::is_pointer_ty_f(cp_p0, t_p3),
        _ => 'm5925: {
            if let crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(m5925_0_0_0), _) = x_p2 && (m5925_0_0_0 == &crate::prelude::Text::lit("prism_rtl::Host::new")) {
                break 'm5925 true;
            }
            if let crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(m5925_1_0_0), m5925_1_1) = x_p2 && (m5925_1_0_0 == &crate::prelude::Text::lit("std::Rc::new")) && (m5925_1_1.len() == 1) && let ::std::option::Option::Some(crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(m5925_1_1_0_0_0), _)) = crate::prelude::index(m5925_1_1, &crate::prelude::Nat::from(0u32)) && (&m5925_1_1_0_0_0 == &crate::prelude::Text::lit("rt::Port::new")) {
                break 'm5925 true;
            }
            match crate::emit::cpp::expr::pointer_o(cp_p0, x_p2) {
                ::std::option::Option::Some(b_p4) => b_p4,
                ::std::option::Option::None => false,
            }
        },
    }
}

/// ```prism
/// ?LetName: fn Pa -> ?Text
/// ```
pub fn let_name_o(p_p0: &crate::lower::model::Pa) -> ::std::option::Option<crate::prelude::Text> {
    match p_p0 {
        crate::lower::model::Pa::PaBind(n_p1) => ::std::option::Option::Some(n_p1.clone()),
        crate::lower::model::Pa::PaMut(n_p2) => ::std::option::Option::Some(n_p2.clone()),
        crate::lower::model::Pa::PaTyped(q_p3, _) => let_name_o(&**q_p3),
        _ => ::std::option::Option::None,
    }
}

/// ```prism
/// VarName: fn Cp, Text -> Text
/// ```
pub fn var_name_f(cp_p0: &crate::emit::cpp::Cp, n_p1: &crate::prelude::Text) -> crate::prelude::Text {
    crate::emit::cpp::cpp_id_f(n_p1)
}

/// ```prism
/// CppStatement: unbounded fn Cp, Do -> Text
/// ```
pub fn cpp_statement_f(cp_p0: &crate::emit::cpp::Cp, d_p1: &crate::lower::model::Do) -> crate::prelude::Text {
    match d_p1 {
        crate::lower::model::Do::DoLet(p_p2, x_p3) => cpp_let_f(cp_p0, cp_p0, p_p2, x_p3),
        crate::lower::model::Do::DoLetElse(p_p4, x_p5, e_p6) => {
            let v_p7 = crate::prelude::Text::from(format!("_{}", &crate::prelude::or(&first_binder_o(p_p4), &crate::prelude::Text::lit("m"))));
            crate::prelude::Text::from(format!("auto&& {} = {};\nif (!({})) {{ {}; }}\n{}", &v_p7, &crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p5), &crate::emit::cpp::patterns::conds_f(&crate::emit::cpp::patterns::pat_conds_f(cp_p0, p_p4, &v_p7)), &crate::emit::cpp::expr::cpp_expr_f(cp_p0, e_p6), &crate::syntax::lexer::chars::join_f(&crate::emit::cpp::patterns::pat_binds_f(cp_p0, p_p4, &v_p7), &crate::prelude::Text::lit("\n"))))
        },
        crate::lower::model::Do::DoAssign(p_p8, x_p9) => crate::prelude::Text::from(format!("{} = {};", &crate::emit::cpp::expr::cpp_place_f(cp_p0, p_p8), &crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p9))),
        crate::lower::model::Do::DoWhile(c_pa, body_pb) => crate::emit::cpp::templates::items::block_f(&crate::prelude::Text::from(format!("while ({})", &crate::emit::cpp::expr::cpp_expr_f(cp_p0, c_pa))), &cpp_statements_f(cp_p0, body_pb)),
        crate::lower::model::Do::DoWhileLet(p_pc, x_pd, body_pe) => {
            let v_pf = crate::prelude::Text::lit("_m");
            let head_pg = crate::prelude::Text::from(format!("auto&& _m = {};\nif (!({})) break;", &crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_pd), &crate::emit::cpp::patterns::conds_f(&crate::emit::cpp::patterns::pat_conds_f(cp_p0, p_pc, &v_pf))));
            crate::emit::cpp::templates::items::block_f(&crate::prelude::Text::lit("while (true)"), &crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![head_pg.clone()]), &crate::emit::cpp::patterns::pat_binds_f(cp_p0, p_pc, &v_pf)), &crate::prelude::Array::from(vec![cpp_statements_f(cp_p0, body_pe)])), &crate::prelude::Text::lit("\n")))
        },
        crate::lower::model::Do::DoFor(p_ph, x_pi, body_pj) => cpp_for_f(cp_p0, p_ph, x_pi, body_pj),
        crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(l_pk, y_pl)) => crate::emit::cpp::patterns::cpp_break_f(cp_p0, l_pk, &**y_pl),
        crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreakLoop) => crate::prelude::Text::lit("break;"),
        crate::lower::model::Do::DoExpr(x_pm) => crate::prelude::Text::from(format!("{};", &crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_pm))),
        crate::lower::model::Do::DoIf(c_pn, t_po, e_pp) => crate::prelude::Text::from(format!("{}{}", &crate::emit::cpp::templates::items::block_f(&crate::prelude::Text::from(format!("if ({})", &crate::emit::cpp::expr::cpp_expr_f(cp_p0, c_pn))), &cpp_statements_f(cp_p0, t_po)), &cpp_else_f(cp_p0, e_pp))),
        crate::lower::model::Do::DoIfLet(p_pq, x_pr, t_ps, e_pt) => cpp_if_let_f(cp_p0, p_pq, x_pr, t_ps, e_pt),
        crate::lower::model::Do::DoMatch(x_pu, cases_pv) => cpp_do_match_f(cp_p0, x_pu, cases_pv),
        crate::lower::model::Do::DoReturn(x_p10) => crate::prelude::Text::from(format!("return {};", &cpp_returned_f(cp_p0, x_p10))),
        crate::lower::model::Do::DoBlock(body_p11) => crate::emit::cpp::templates::items::braced_f(&cpp_statements_f(cp_p0, body_p11)),
        crate::lower::model::Do::DoScope(body_p12) => crate::prelude::Text::from(format!("{{ {} }}", &cpp_inline_f(cp_p0, body_p12))),
        crate::lower::model::Do::DoLine(body_p13) => cpp_inline_f(cp_p0, body_p13),
        crate::lower::model::Do::DoNote(t_p14) => crate::prelude::Text::from(format!("// {}", t_p14)),
    }
}

/// The step machine of `CppStatement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppStatement: unbounded fn Cp, Do -> Text
/// ```
pub struct CppStatement {
    pub cp_p0: crate::emit::cpp::Cp,
    pub d_p1: crate::lower::model::Do,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppStatement {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let d_p1 = &self.d_p1;
        match d_p1 {
            crate::lower::model::Do::DoLet(p_p2, x_p3) => ::prism_rtl::Turn::More(::std::rc::Rc::new(CppLet { cp_p0: cp_p0.clone(), named_p1: cp_p0.clone(), p_p2: p_p2.clone(), x_p3: x_p3.clone() })),
            crate::lower::model::Do::DoLetElse(p_p4, x_p5, e_p6) => {
                let cp_p0x = cp_p0.clone();
                let e_p6x = e_p6.clone();
                let p_p4x = p_p4.clone();
                let x_p5x = x_p5.clone();
                crate::prelude::call_then(start_first_binder_o(p_p4x.clone()), move |first_binder_o_6533: ::std::option::Option<crate::prelude::Text>| {
                    let v_p7 = crate::prelude::Text::from(format!("_{}", &crate::prelude::or(&first_binder_o_6533, &crate::prelude::Text::lit("m"))));
                    crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), x_p5x.clone()), move |cpp_expr_f_6579: crate::prelude::Text| crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_conds_f(cp_p0x.clone(), p_p4x.clone(), v_p7.clone()), move |pat_conds_f_6610: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), e_p6x.clone()), move |cpp_expr_f_6636: crate::prelude::Text| crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_binds_f(cp_p0x.clone(), p_p4x.clone(), v_p7.clone()), move |pat_binds_f_6663: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("auto&& {} = {};\nif (!({})) {{ {}; }}\n{}", &v_p7, &cpp_expr_f_6579, &crate::emit::cpp::patterns::conds_f(&pat_conds_f_6610), &cpp_expr_f_6636, &crate::syntax::lexer::chars::join_f(&pat_binds_f_6663, &crate::prelude::Text::lit("\n")))))))))
                })
            },
            crate::lower::model::Do::DoAssign(p_p8, x_p9) => {
                let cp_p0x = cp_p0.clone();
                let p_p8x = p_p8.clone();
                let x_p9x = x_p9.clone();
                crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_place_f(cp_p0x.clone(), p_p8x.clone()), move |cpp_place_f_6711: crate::prelude::Text| crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), x_p9x.clone()), move |cpp_expr_f_6730: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} = {};", &cpp_place_f_6711, &cpp_expr_f_6730)))))
            },
            crate::lower::model::Do::DoWhile(c_pa, body_pb) => {
                let body_pbx = body_pb.clone();
                let c_pax = c_pa.clone();
                let cp_p0x = cp_p0.clone();
                crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), c_pax.clone()), move |cpp_expr_f_6783: crate::prelude::Text| crate::prelude::call_then(start_cpp_statements_f(cp_p0x.clone(), body_pbx.clone()), move |cpp_statements_f_6802: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::block_f(&crate::prelude::Text::from(format!("while ({})", &cpp_expr_f_6783)), &cpp_statements_f_6802))))
            },
            crate::lower::model::Do::DoWhileLet(p_pc, x_pd, body_pe) => {
                let v_pf = crate::prelude::Text::lit("_m");
                let body_pex = body_pe.clone();
                let cp_p0x = cp_p0.clone();
                let p_pcx = p_pc.clone();
                let x_pdx = x_pd.clone();
                crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), x_pdx.clone()), move |cpp_expr_f_6907: crate::prelude::Text| crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_conds_f(cp_p0x.clone(), p_pcx.clone(), v_pf.clone()), move |pat_conds_f_6938: crate::prelude::Array<crate::prelude::Text>| {
                    let head_pg = crate::prelude::Text::from(format!("auto&& _m = {};\nif (!({})) break;", &cpp_expr_f_6907, &crate::emit::cpp::patterns::conds_f(&pat_conds_f_6938)));
                    crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_binds_f(cp_p0x.clone(), p_pcx.clone(), v_pf.clone()), move |pat_binds_f_7031: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(start_cpp_statements_f(cp_p0x.clone(), body_pex.clone()), move |cpp_statements_f_7055: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::block_f(&crate::prelude::Text::lit("while (true)"), &crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![head_pg.clone()]), &pat_binds_f_7031), &crate::prelude::Array::from(vec![cpp_statements_f_7055])), &crate::prelude::Text::lit("\n"))))))
                }))
            },
            crate::lower::model::Do::DoFor(p_ph, x_pi, body_pj) => ::prism_rtl::Turn::More(::std::rc::Rc::new(CppFor { cp0_p0: cp_p0.clone(), p_p1: p_ph.clone(), x_p2: x_pi.clone(), body_p3: body_pj.clone() })),
            crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(l_pk, y_pl)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::cpp::patterns::CppBreak { cp_p0: cp_p0.clone(), l_p1: l_pk.clone(), y_p2: (**y_pl).clone() })),
            crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreakLoop) => ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("break;")),
            crate::lower::model::Do::DoExpr(x_pm) => {
                let cp_p0x = cp_p0.clone();
                let x_pmx = x_pm.clone();
                crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), x_pmx.clone()), move |cpp_expr_f_7225: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{};", &cpp_expr_f_7225))))
            },
            crate::lower::model::Do::DoIf(c_pn, t_po, e_pp) => {
                let c_pnx = c_pn.clone();
                let cp_p0x = cp_p0.clone();
                let e_ppx = e_pp.clone();
                let t_pox = t_po.clone();
                crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), c_pnx.clone()), move |cpp_expr_f_7274: crate::prelude::Text| crate::prelude::call_then(start_cpp_statements_f(cp_p0x.clone(), t_pox.clone()), move |cpp_statements_f_7293: crate::prelude::Text| crate::prelude::call_then(start_cpp_else_f(cp_p0x.clone(), e_ppx.clone()), move |cpp_else_f_7315: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{}", &crate::emit::cpp::templates::items::block_f(&crate::prelude::Text::from(format!("if ({})", &cpp_expr_f_7274)), &cpp_statements_f_7293), &cpp_else_f_7315))))))
            },
            crate::lower::model::Do::DoIfLet(p_pq, x_pr, t_ps, e_pt) => ::prism_rtl::Turn::More(::std::rc::Rc::new(CppIfLet { cp0_p0: cp_p0.clone(), p_p1: p_pq.clone(), x_p2: x_pr.clone(), t_p3: t_ps.clone(), e_p4: e_pt.clone() })),
            crate::lower::model::Do::DoMatch(x_pu, cases_pv) => ::prism_rtl::Turn::More(::std::rc::Rc::new(CppDoMatch { cp_p0: cp_p0.clone(), x_p1: x_pu.clone(), cases_p2: cases_pv.clone() })),
            crate::lower::model::Do::DoReturn(x_p10) => {
                let cp_p0x = cp_p0.clone();
                let x_p10x = x_p10.clone();
                crate::prelude::call_then(start_cpp_returned_f(cp_p0x.clone(), x_p10x.clone()), move |cpp_returned_f_7450: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("return {};", &cpp_returned_f_7450))))
            },
            crate::lower::model::Do::DoBlock(body_p11) => {
                let body_p11x = body_p11.clone();
                let cp_p0x = cp_p0.clone();
                crate::prelude::call_then(start_cpp_statements_f(cp_p0x.clone(), body_p11x.clone()), move |cpp_statements_f_7497: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::braced_f(&cpp_statements_f_7497)))
            },
            crate::lower::model::Do::DoScope(body_p12) => {
                let body_p12x = body_p12.clone();
                let cp_p0x = cp_p0.clone();
                crate::prelude::call_then(start_cpp_inline_f(cp_p0x.clone(), body_p12x.clone()), move |cpp_inline_f_7544: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{{ {} }}", &cpp_inline_f_7544))))
            },
            crate::lower::model::Do::DoLine(body_p13) => ::prism_rtl::Turn::More(::std::rc::Rc::new(CppInline { cp_p0: cp_p0.clone(), dos_p1: body_p13.clone() })),
            crate::lower::model::Do::DoNote(t_p14) => ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("// {}", t_p14))),
        }
    }
}

/// `Start CppStatement, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_statement_f(cp_p0: crate::emit::cpp::Cp, d_p1: crate::lower::model::Do) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppStatement { cp_p0, d_p1 })
}

/// ```prism
/// CppInline: unbounded fn Cp, [Do] -> Text
/// ```
pub fn cpp_inline_f(cp_p0: &crate::emit::cpp::Cp, dos_p1: &crate::prelude::Array<crate::lower::model::Do>) -> crate::prelude::Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(dos_p1.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::Do| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let d_p2 = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(CppStatement { cp_p0: cp_p0xy.clone(), d_p1: d_p2.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Do) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    })), &crate::prelude::Text::lit(" "))
}

/// The step machine of `CppInline`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppInline: unbounded fn Cp, [Do] -> Text
/// ```
pub struct CppInline {
    pub cp_p0: crate::emit::cpp::Cp,
    pub dos_p1: crate::prelude::Array<crate::lower::model::Do>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppInline {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let dos_p1 = &self.dos_p1;
        let cp_p0x = cp_p0.clone();
        let dos_p1x = dos_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(dos_p1x.clone(), {
            let cp_p0xx = cp_p0x.clone();
            ::std::rc::Rc::new(move |p0: crate::lower::model::Do| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let d_p2 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(CppStatement { cp_p0: cp_p0xxy.clone(), d_p1: d_p2.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Do) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
        }), move |each_7698: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join_f(&each_7698, &crate::prelude::Text::lit(" "))))
    }
}

/// `Start CppInline, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_inline_f(cp_p0: crate::emit::cpp::Cp, dos_p1: crate::prelude::Array<crate::lower::model::Do>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppInline { cp_p0, dos_p1 })
}

/// ```prism
/// CppElse: unbounded fn Cp, [Do] -> Text
/// ```
pub fn cpp_else_f(cp_p0: &crate::emit::cpp::Cp, xs1: &crate::prelude::Array<crate::lower::model::Do>) -> crate::prelude::Text {
    'c: {
        if let c0_1 = xs1 && (c0_1.len() == 0) {
            break 'c crate::prelude::Text::lit("");
        }
        if let c1_1 = xs1 && (c1_1.len() == 1) && let ::std::option::Option::Some(crate::lower::model::Do::DoIf(c_p2, t_p3, e_p4)) = crate::prelude::index(c1_1, &crate::prelude::Nat::from(0u32)) {
            break 'c crate::prelude::Text::from(format!(" else {}", &cpp_statement_f(cp_p0, &crate::lower::model::Do::DoIf(c_p2.clone(), t_p3.clone(), e_p4.clone()))));
        }
        if let c2_1 = xs1 && (c2_1.len() == 1) && let ::std::option::Option::Some(crate::lower::model::Do::DoIfLet(p_p6, x_p7, t_p8, e_p9)) = crate::prelude::index(c2_1, &crate::prelude::Nat::from(0u32)) {
            break 'c crate::prelude::Text::from(format!(" else {}", &cpp_statement_f(cp_p0, &crate::lower::model::Do::DoIfLet(p_p6.clone(), x_p7.clone(), t_p8.clone(), e_p9.clone()))));
        }
        if let body_pb = xs1 {
            break 'c crate::prelude::Text::from(format!(" else {}", &crate::emit::cpp::templates::items::block_f(&crate::prelude::Text::lit(""), &cpp_statements_f(cp_p0, body_pb))));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `CppElse`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppElse: unbounded fn Cp, [Do] -> Text
/// ```
pub struct CppElse {
    pub cp_p0: crate::emit::cpp::Cp,
    pub xs1: crate::prelude::Array<crate::lower::model::Do>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppElse {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let xs1 = &self.xs1;
        'j: {
            if let j0_1 = xs1 && (j0_1.len() == 0) {
                break 'j ::prism_rtl::Turn::Finished(crate::prelude::Text::lit(""));
            }
            if let j1_1 = xs1 && (j1_1.len() == 1) && let ::std::option::Option::Some(crate::lower::model::Do::DoIf(c_p2, t_p3, e_p4)) = crate::prelude::index(j1_1, &crate::prelude::Nat::from(0u32)) {
                break 'j {
                    let cp_p0x = cp_p0.clone();
                    crate::prelude::call_then(start_cpp_statement_f(cp_p0x.clone(), crate::lower::model::Do::DoIf(c_p2.clone(), t_p3.clone(), e_p4.clone())), move |cpp_statement_f_7847: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!(" else {}", &cpp_statement_f_7847))))
                };
            }
            if let j2_1 = xs1 && (j2_1.len() == 1) && let ::std::option::Option::Some(crate::lower::model::Do::DoIfLet(p_p6, x_p7, t_p8, e_p9)) = crate::prelude::index(j2_1, &crate::prelude::Nat::from(0u32)) {
                break 'j {
                    let cp_p0x = cp_p0.clone();
                    crate::prelude::call_then(start_cpp_statement_f(cp_p0x.clone(), crate::lower::model::Do::DoIfLet(p_p6.clone(), x_p7.clone(), t_p8.clone(), e_p9.clone())), move |cpp_statement_f_7931: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!(" else {}", &cpp_statement_f_7931))))
                };
            }
            if let body_pb = xs1 {
                break 'j {
                    let body_pbx = body_pb.clone();
                    let cp_p0x = cp_p0.clone();
                    crate::prelude::call_then(start_cpp_statements_f(cp_p0x.clone(), body_pbx.clone()), move |cpp_statements_f_8012: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!(" else {}", &crate::emit::cpp::templates::items::block_f(&crate::prelude::Text::lit(""), &cpp_statements_f_8012)))))
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start CppElse, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_else_f(cp_p0: crate::emit::cpp::Cp, xs1: crate::prelude::Array<crate::lower::model::Do>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppElse { cp_p0, xs1 })
}

/// ```prism
/// CppLet: unbounded fn Cp, Cp, Pa, Ex -> Text
/// ```
pub fn cpp_let_f(cp_p0: &crate::emit::cpp::Cp, named_p1: &crate::emit::cpp::Cp, p_p2: &crate::lower::model::Pa, x_p3: &crate::lower::model::Ex) -> crate::prelude::Text {
    'm8228: {
        if let crate::lower::model::Pa::PaWild = p_p2 {
            break 'm8228 crate::prelude::Text::from(format!("static_cast<void>({});", &crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p3)));
        }
        if let crate::lower::model::Pa::PaBind(n_p4) = p_p2 {
            break 'm8228 match x_p3 {
                crate::lower::model::Ex::XRef(_) => crate::prelude::Text::from(format!("const auto& {} = {};", &var_name_f(named_p1, n_p4), &crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p3))),
                _ => crate::prelude::Text::from(format!("auto {} = {};", &var_name_f(named_p1, n_p4), &crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p3))),
            };
        }
        if let crate::lower::model::Pa::PaMut(n_p5) = p_p2 {
            break 'm8228 crate::prelude::Text::from(format!("auto {} = {};", &var_name_f(named_p1, n_p5), &crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p3)));
        }
        if let crate::lower::model::Pa::PaTyped(m8228_3_0, t_p7) = p_p2 && let crate::lower::model::Pa::PaBind(n_p6) = &**m8228_3_0 {
            break 'm8228 match x_p3 {
                crate::lower::model::Ex::XUnreachable => crate::prelude::Text::from(format!("{} {} = ::prism_rtl::unreachable_as<{}>();", &crate::emit::cpp::cpp_type_f(cp_p0, t_p7), &var_name_f(named_p1, n_p6), &crate::emit::cpp::cpp_type_f(cp_p0, t_p7))),
                _ => crate::prelude::Text::from(format!("{} {} = {};", &crate::emit::cpp::cpp_type_f(cp_p0, t_p7), &var_name_f(named_p1, n_p6), &crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p3))),
            };
        }
        if let crate::lower::model::Pa::PaTyped(m8228_4_0, t_p9) = p_p2 && let crate::lower::model::Pa::PaMut(n_p8) = &**m8228_4_0 {
            break 'm8228 crate::prelude::Text::from(format!("{} {} = {};", &crate::emit::cpp::cpp_type_f(cp_p0, t_p9), &var_name_f(named_p1, n_p8), &crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p3)));
        }
        if let crate::lower::model::Pa::PaTuple(ps_pa) = p_p2 {
            break 'm8228 if crate::prelude::fold(ps_pa, &true, &(|f_pb: &bool, q_pc: &crate::lower::model::Pa| *f_pb && is_name_f(q_pc))) {
                crate::prelude::Text::from(format!("auto [{}] = {};", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(ps_pa, &(|q_pd: &crate::lower::model::Pa| pat_name_f(q_pd))), &crate::prelude::Text::lit(", ")), &crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p3)))
            } else {
                let_through_f(cp_p0, p_p2, x_p3)
            };
        }
        let_through_f(cp_p0, p_p2, x_p3)
    }
}

/// The step machine of `CppLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppLet: unbounded fn Cp, Cp, Pa, Ex -> Text
/// ```
pub struct CppLet {
    pub cp_p0: crate::emit::cpp::Cp,
    pub named_p1: crate::emit::cpp::Cp,
    pub p_p2: crate::lower::model::Pa,
    pub x_p3: crate::lower::model::Ex,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppLet {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let named_p1 = &self.named_p1;
        let p_p2 = &self.p_p2;
        let x_p3 = &self.x_p3;
        'm8228: {
            if let crate::lower::model::Pa::PaWild = p_p2 {
                break 'm8228 {
                    let cp_p0x = cp_p0.clone();
                    let x_p3x = x_p3.clone();
                    crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), x_p3x.clone()), move |cpp_expr_f_8269: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("static_cast<void>({});", &cpp_expr_f_8269))))
                };
            }
            if let crate::lower::model::Pa::PaBind(n_p4) = p_p2 {
                break 'm8228 match x_p3 {
                    crate::lower::model::Ex::XRef(_) => {
                        let cp_p0x = cp_p0.clone();
                        let n_p4x = n_p4.clone();
                        let named_p1x = named_p1.clone();
                        let x_p3x = x_p3.clone();
                        crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), x_p3x.clone()), move |cpp_expr_f_8366: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("const auto& {} = {};", &var_name_f(&named_p1x, &n_p4x), &cpp_expr_f_8366))))
                    },
                    _ => {
                        let cp_p0x = cp_p0.clone();
                        let n_p4x = n_p4.clone();
                        let named_p1x = named_p1.clone();
                        let x_p3x = x_p3.clone();
                        crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), x_p3x.clone()), move |cpp_expr_f_8430: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("auto {} = {};", &var_name_f(&named_p1x, &n_p4x), &cpp_expr_f_8430))))
                    },
                };
            }
            if let crate::lower::model::Pa::PaMut(n_p5) = p_p2 {
                break 'm8228 {
                    let cp_p0x = cp_p0.clone();
                    let n_p5x = n_p5.clone();
                    let named_p1x = named_p1.clone();
                    let x_p3x = x_p3.clone();
                    crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), x_p3x.clone()), move |cpp_expr_f_8488: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("auto {} = {};", &var_name_f(&named_p1x, &n_p5x), &cpp_expr_f_8488))))
                };
            }
            if let crate::lower::model::Pa::PaTyped(m8228_3_0, t_p7) = p_p2 && let crate::lower::model::Pa::PaBind(n_p6) = &**m8228_3_0 {
                break 'm8228 match x_p3 {
                    crate::lower::model::Ex::XUnreachable => {
                        let cp_p0x = cp_p0.clone();
                        let n_p6x = n_p6.clone();
                        let named_p1x = named_p1.clone();
                        let t_p7x = t_p7.clone();
                        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), t_p7x.clone()), move |cpp_type_f_8741: crate::prelude::Text| crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), t_p7x.clone()), move |cpp_type_f_8806: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {} = ::prism_rtl::unreachable_as<{}>();", &cpp_type_f_8741, &var_name_f(&named_p1x, &n_p6x), &cpp_type_f_8806)))))
                    },
                    _ => {
                        let cp_p0x = cp_p0.clone();
                        let n_p6x = n_p6.clone();
                        let named_p1x = named_p1.clone();
                        let t_p7x = t_p7.clone();
                        let x_p3x = x_p3.clone();
                        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), t_p7x.clone()), move |cpp_type_f_8847: crate::prelude::Text| crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), x_p3x.clone()), move |cpp_expr_f_8884: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {} = {};", &cpp_type_f_8847, &var_name_f(&named_p1x, &n_p6x), &cpp_expr_f_8884)))))
                    },
                };
            }
            if let crate::lower::model::Pa::PaTyped(m8228_4_0, t_p9) = p_p2 && let crate::lower::model::Pa::PaMut(n_p8) = &**m8228_4_0 {
                break 'm8228 {
                    let cp_p0x = cp_p0.clone();
                    let n_p8x = n_p8.clone();
                    let named_p1x = named_p1.clone();
                    let t_p9x = t_p9.clone();
                    let x_p3x = x_p3.clone();
                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), t_p9x.clone()), move |cpp_type_f_8929: crate::prelude::Text| crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), x_p3x.clone()), move |cpp_expr_f_8966: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {} = {};", &cpp_type_f_8929, &var_name_f(&named_p1x, &n_p8x), &cpp_expr_f_8966)))))
                };
            }
            if let crate::lower::model::Pa::PaTuple(ps_pa) = p_p2 {
                break 'm8228 if crate::prelude::fold(ps_pa, &true, &(|f_pb: &bool, q_pc: &crate::lower::model::Pa| *f_pb && is_name_f(q_pc))) {
                    {
                        let cp_p0x = cp_p0.clone();
                        let ps_pax = ps_pa.clone();
                        let x_p3x = x_p3.clone();
                        crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), x_p3x.clone()), move |cpp_expr_f_9099: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("auto [{}] = {};", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&ps_pax, &(|q_pd: &crate::lower::model::Pa| pat_name_f(q_pd))), &crate::prelude::Text::lit(", ")), &cpp_expr_f_9099))))
                    }
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(LetThrough { cp_p0: cp_p0.clone(), p_p1: p_p2.clone(), x_p2: x_p3.clone() }))
                };
            }
            ::prism_rtl::Turn::More(::std::rc::Rc::new(LetThrough { cp_p0: cp_p0.clone(), p_p1: p_p2.clone(), x_p2: x_p3.clone() }))
        }
    }
}

/// `Start CppLet, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_let_f(cp_p0: crate::emit::cpp::Cp, named_p1: crate::emit::cpp::Cp, p_p2: crate::lower::model::Pa, x_p3: crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppLet { cp_p0, named_p1, p_p2, x_p3 })
}

/// ```prism
/// LetThrough: unbounded fn Cp, Pa, Ex -> Text
/// ```
pub fn let_through_f(cp_p0: &crate::emit::cpp::Cp, p_p1: &crate::lower::model::Pa, x_p2: &crate::lower::model::Ex) -> crate::prelude::Text {
    let t_p3 = crate::prelude::Text::from(format!("_{}", &crate::prelude::or(&first_binder_o(p_p1), &crate::prelude::Text::lit("t"))));
    crate::prelude::Text::from(format!("auto&& {} = {};\n{}", &t_p3, &crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p2), &crate::syntax::lexer::chars::join_f(&crate::emit::cpp::patterns::pat_binds_f(cp_p0, p_p1, &t_p3), &crate::prelude::Text::lit("\n"))))
}

/// The step machine of `LetThrough`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LetThrough: unbounded fn Cp, Pa, Ex -> Text
/// ```
pub struct LetThrough {
    pub cp_p0: crate::emit::cpp::Cp,
    pub p_p1: crate::lower::model::Pa,
    pub x_p2: crate::lower::model::Ex,
}

impl ::prism_rtl::Job<crate::prelude::Text> for LetThrough {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let p_p1 = &self.p_p1;
        let x_p2 = &self.x_p2;
        let cp_p0x = cp_p0.clone();
        let p_p1x = p_p1.clone();
        let x_p2x = x_p2.clone();
        crate::prelude::call_then(start_first_binder_o(p_p1x.clone()), move |first_binder_o_9358: ::std::option::Option<crate::prelude::Text>| {
            let t_p3 = crate::prelude::Text::from(format!("_{}", &crate::prelude::or(&first_binder_o_9358, &crate::prelude::Text::lit("t"))));
            crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), x_p2x.clone()), move |cpp_expr_f_9400: crate::prelude::Text| crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_binds_f(cp_p0x.clone(), p_p1x.clone(), t_p3.clone()), move |pat_binds_f_9424: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("auto&& {} = {};\n{}", &t_p3, &cpp_expr_f_9400, &crate::syntax::lexer::chars::join_f(&pat_binds_f_9424, &crate::prelude::Text::lit("\n")))))))
        })
    }
}

/// `Start LetThrough, x`: what the function value is when passed to `@Run`.
pub fn start_let_through_f(cp_p0: crate::emit::cpp::Cp, p_p1: crate::lower::model::Pa, x_p2: crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(LetThrough { cp_p0, p_p1, x_p2 })
}

/// ```prism
/// ?FirstBinder: unbounded fn Pa -> ?Text
/// ```
pub fn first_binder_o(p_p0: &crate::lower::model::Pa) -> ::std::option::Option<crate::prelude::Text> {
    match p_p0 {
        crate::lower::model::Pa::PaBind(n_p1) => ::std::option::Option::Some(n_p1.clone()),
        crate::lower::model::Pa::PaMut(n_p2) => ::std::option::Option::Some(n_p2.clone()),
        crate::lower::model::Pa::PaTyped(q_p3, _) => first_binder_o(&**q_p3),
        crate::lower::model::Pa::PaCtor(_, ps_p4) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_p4.clone(), ::std::option::Option::None, ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::prelude::Text>, crate::lower::model::Pa)| crate::prelude::entered(crate::prelude::once_job(move || {
            let f_o5 = p0;
            let q_p6 = p1;
            match &f_o5 {
                ::std::option::Option::Some(b_p7) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(b_p7.clone())),
                ::std::option::Option::None => ::prism_rtl::Turn::More(::std::rc::Rc::new(FirstBinder { p_p0: q_p6.clone() })),
            }
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::prelude::Text>, crate::lower::model::Pa)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Text>>>>)),
        crate::lower::model::Pa::PaTuple(ps_p8) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_p8.clone(), ::std::option::Option::None, ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::prelude::Text>, crate::lower::model::Pa)| crate::prelude::entered(crate::prelude::once_job(move || {
            let f_o9 = p0;
            let q_pa = p1;
            match &f_o9 {
                ::std::option::Option::Some(b_pb) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(b_pb.clone())),
                ::std::option::Option::None => ::prism_rtl::Turn::More(::std::rc::Rc::new(FirstBinder { p_p0: q_pa.clone() })),
            }
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::prelude::Text>, crate::lower::model::Pa)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Text>>>>)),
        _ => ::std::option::Option::None,
    }
}

/// The step machine of `FirstBinder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?FirstBinder: unbounded fn Pa -> ?Text
/// ```
pub struct FirstBinder {
    pub p_p0: crate::lower::model::Pa,
}

impl ::prism_rtl::Job<::std::option::Option<crate::prelude::Text>> for FirstBinder {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::prelude::Text>> {
        let p_p0 = &self.p_p0;
        match p_p0 {
            crate::lower::model::Pa::PaBind(n_p1) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(n_p1.clone())),
            crate::lower::model::Pa::PaMut(n_p2) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(n_p2.clone())),
            crate::lower::model::Pa::PaTyped(q_p3, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(FirstBinder { p_p0: (**q_p3).clone() })),
            crate::lower::model::Pa::PaCtor(_, ps_p4) => crate::prelude::fold_job(ps_p4.clone(), ::std::option::Option::None, ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::prelude::Text>, crate::lower::model::Pa)| crate::prelude::entered(crate::prelude::once_job(move || {
                let f_o5 = p0;
                let q_p6 = p1;
                match &f_o5 {
                    ::std::option::Option::Some(b_p7) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(b_p7.clone())),
                    ::std::option::Option::None => ::prism_rtl::Turn::More(::std::rc::Rc::new(FirstBinder { p_p0: q_p6.clone() })),
                }
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::prelude::Text>, crate::lower::model::Pa)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Text>>>>).cycle(),
            crate::lower::model::Pa::PaTuple(ps_p8) => crate::prelude::fold_job(ps_p8.clone(), ::std::option::Option::None, ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::prelude::Text>, crate::lower::model::Pa)| crate::prelude::entered(crate::prelude::once_job(move || {
                let f_o9 = p0;
                let q_pa = p1;
                match &f_o9 {
                    ::std::option::Option::Some(b_pb) => ::prism_rtl::Turn::Finished(::std::option::Option::Some(b_pb.clone())),
                    ::std::option::Option::None => ::prism_rtl::Turn::More(::std::rc::Rc::new(FirstBinder { p_p0: q_pa.clone() })),
                }
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::prelude::Text>, crate::lower::model::Pa)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Text>>>>).cycle(),
            _ => ::prism_rtl::Turn::Finished(::std::option::Option::None),
        }
    }
}

/// `Start FirstBinder, x`: what the function value is when passed to `@Run`.
pub fn start_first_binder_o(p_p0: crate::lower::model::Pa) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Text>>> {
    ::std::rc::Rc::new(FirstBinder { p_p0 })
}

/// ```prism
/// IsName: fn Pa -> Bool
/// ```
pub fn is_name_f(pa0: &crate::lower::model::Pa) -> bool {
    match pa0 {
        crate::lower::model::Pa::PaBind(_) => true,
        crate::lower::model::Pa::PaMut(_) => true,
        other_p0 => false,
    }
}

/// ```prism
/// PatName: fn Pa -> Text
/// ```
pub fn pat_name_f(pa0: &crate::lower::model::Pa) -> crate::prelude::Text {
    match pa0 {
        crate::lower::model::Pa::PaBind(n_p0) => crate::emit::cpp::cpp_id_f(n_p0),
        crate::lower::model::Pa::PaMut(n_p1) => crate::emit::cpp::cpp_id_f(n_p1),
        other_p2 => crate::prelude::Text::lit("_"),
    }
}

/// ```prism
/// CppIfLet: unbounded fn Cp, Pa, Ex, [Do], [Do] -> Text
/// ```
pub fn cpp_if_let_f(cp0_p0: &crate::emit::cpp::Cp, p_p1: &crate::lower::model::Pa, x_p2: &crate::lower::model::Ex, t_p3: &crate::prelude::Array<crate::lower::model::Do>, e_p4: &crate::prelude::Array<crate::lower::model::Do>) -> crate::prelude::Text {
    let cp_p5 = unbind_f(cp0_p0, &pat_names_f(p_p1));
    let v_p6 = crate::prelude::Text::lit("_m");
    let head_p7 = crate::prelude::Text::from(format!("if (auto&& _m = {}; {})", &crate::emit::cpp::expr::cpp_expr_f(&cp_p5, x_p2), &crate::emit::cpp::patterns::conds_f(&crate::emit::cpp::patterns::pat_conds_f(&cp_p5, p_p1, &v_p6))));
    let body_p8 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::emit::cpp::patterns::pat_binds_f(&cp_p5, p_p1, &v_p6), &crate::prelude::Array::from(vec![cpp_statements_f(&cp_p5, t_p3)])), &crate::prelude::Text::lit("\n"));
    crate::prelude::Text::from(format!("{}{}", &crate::emit::cpp::templates::items::block_f(&head_p7, &body_p8), &cpp_else_f(&cp_p5, e_p4)))
}

/// The step machine of `CppIfLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppIfLet: unbounded fn Cp, Pa, Ex, [Do], [Do] -> Text
/// ```
pub struct CppIfLet {
    pub cp0_p0: crate::emit::cpp::Cp,
    pub p_p1: crate::lower::model::Pa,
    pub x_p2: crate::lower::model::Ex,
    pub t_p3: crate::prelude::Array<crate::lower::model::Do>,
    pub e_p4: crate::prelude::Array<crate::lower::model::Do>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppIfLet {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp0_p0 = &self.cp0_p0;
        let p_p1 = &self.p_p1;
        let x_p2 = &self.x_p2;
        let t_p3 = &self.t_p3;
        let e_p4 = &self.e_p4;
        let cp0_p0x = cp0_p0.clone();
        let e_p4x = e_p4.clone();
        let p_p1x = p_p1.clone();
        let t_p3x = t_p3.clone();
        let x_p2x = x_p2.clone();
        crate::prelude::call_then(start_pat_names_f(p_p1x.clone()), move |pat_names_f_10211: crate::prelude::Array<crate::prelude::Text>| {
            let cp_p5 = unbind_f(&cp0_p0x, &pat_names_f_10211);
            let v_p6 = crate::prelude::Text::lit("_m");
            crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p5.clone(), x_p2x.clone()), move |cpp_expr_f_10273: crate::prelude::Text| crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_conds_f(cp_p5.clone(), p_p1x.clone(), v_p6.clone()), move |pat_conds_f_10297: crate::prelude::Array<crate::prelude::Text>| {
                let head_p7 = crate::prelude::Text::from(format!("if (auto&& _m = {}; {})", &cpp_expr_f_10273, &crate::emit::cpp::patterns::conds_f(&pat_conds_f_10297)));
                crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_binds_f(cp_p5.clone(), p_p1x.clone(), v_p6.clone()), move |pat_binds_f_10348: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(start_cpp_statements_f(cp_p5.clone(), t_p3x.clone()), move |cpp_statements_f_10371: crate::prelude::Text| {
                    let body_p8 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&pat_binds_f_10348, &crate::prelude::Array::from(vec![cpp_statements_f_10371])), &crate::prelude::Text::lit("\n"));
                    crate::prelude::call_then(start_cpp_else_f(cp_p5.clone(), e_p4x.clone()), move |cpp_else_f_10425: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{}", &crate::emit::cpp::templates::items::block_f(&head_p7, &body_p8), &cpp_else_f_10425))))
                }))
            }))
        })
    }
}

/// `Start CppIfLet, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_if_let_f(cp0_p0: crate::emit::cpp::Cp, p_p1: crate::lower::model::Pa, x_p2: crate::lower::model::Ex, t_p3: crate::prelude::Array<crate::lower::model::Do>, e_p4: crate::prelude::Array<crate::lower::model::Do>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppIfLet { cp0_p0, p_p1, x_p2, t_p3, e_p4 })
}

/// ```prism
/// CppDoMatch: unbounded fn Cp, Ex, [((Pa, [Do]))] -> Text
/// ```
pub fn cpp_do_match_f(cp_p0: &crate::emit::cpp::Cp, x_p1: &crate::lower::model::Ex, cases_p2: &crate::prelude::Array<(crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)>) -> crate::prelude::Text {
    let v_p3 = crate::prelude::Text::lit("_m");
    let arms_p4 = crate::prelude::run_to_end(crate::prelude::each_job(cases_p2.clone(), {
        let cp_p0x = cp_p0.clone();
        let v_p3x = v_p3.clone();
        ::std::rc::Rc::new(move |p0: (crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)| {
            let cp_p0xy = cp_p0x.clone();
            let v_p3xy = v_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (p_p6, body_p7) = p0;
                crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_conds_f(cp_p0xy.clone(), p_p6.clone(), v_p3xy.clone()), move |pat_conds_f_10605: crate::prelude::Array<crate::prelude::Text>| {
                    let tests_p8 = pat_conds_f_10605;
                    crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_binds_f(cp_p0xy.clone(), p_p6.clone(), v_p3xy.clone()), move |pat_binds_f_10657: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(start_cpp_statements_f(cp_p0xy.clone(), body_p7.clone()), move |cpp_statements_f_10680: crate::prelude::Text| {
                        let inner_p9 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&pat_binds_f_10657, &crate::prelude::Array::from(vec![cpp_statements_f_10680])), &crate::prelude::Text::lit("\n"));
                        ::prism_rtl::Turn::Finished((tests_p8.clone(), inner_p9.clone()))
                    }))
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)>>>
    }));
    let blocks_p5 = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&arms_p4)), &(|i_pa: &crate::prelude::Nat| {
        let (tests_pc, inner_pd) = crate::prelude::or(&crate::prelude::index(&arms_p4, i_pa), &(crate::prelude::Array::new(), crate::prelude::Text::lit("")));
        let head_pb = if i_pa == &crate::prelude::Nat::from(0u32) {
            crate::prelude::Text::from(format!("if ({})", &crate::emit::cpp::patterns::conds_f(&tests_pc)))
        } else {
            if &crate::prelude::len(&tests_pc) == &crate::prelude::Nat::from(0u32) {
                crate::prelude::Text::lit("else")
            } else {
                crate::prelude::Text::from(format!("else if ({})", &crate::emit::cpp::patterns::conds_f(&tests_pc)))
            }
        };
        crate::emit::cpp::templates::items::block_f(&head_pb, &inner_pd)
    }));
    crate::emit::cpp::templates::items::braced_f(&crate::prelude::Text::from(format!("auto&& _m = {};\n{}", &crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p1), &crate::syntax::lexer::chars::join_f(&blocks_p5, &crate::prelude::Text::lit(" ")))))
}

/// The step machine of `CppDoMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppDoMatch: unbounded fn Cp, Ex, [((Pa, [Do]))] -> Text
/// ```
pub struct CppDoMatch {
    pub cp_p0: crate::emit::cpp::Cp,
    pub x_p1: crate::lower::model::Ex,
    pub cases_p2: crate::prelude::Array<(crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppDoMatch {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let x_p1 = &self.x_p1;
        let cases_p2 = &self.cases_p2;
        let v_p3 = crate::prelude::Text::lit("_m");
        let cases_p2x = cases_p2.clone();
        let cp_p0x = cp_p0.clone();
        let x_p1x = x_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(cases_p2x.clone(), {
            let cp_p0xx = cp_p0x.clone();
            let v_p3x = v_p3.clone();
            ::std::rc::Rc::new(move |p0: (crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)| {
                let cp_p0xxy = cp_p0xx.clone();
                let v_p3xy = v_p3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (p_p6, body_p7) = p0;
                    crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_conds_f(cp_p0xxy.clone(), p_p6.clone(), v_p3xy.clone()), move |pat_conds_f_10605: crate::prelude::Array<crate::prelude::Text>| {
                        let tests_p8 = pat_conds_f_10605;
                        crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_binds_f(cp_p0xxy.clone(), p_p6.clone(), v_p3xy.clone()), move |pat_binds_f_10657: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(start_cpp_statements_f(cp_p0xxy.clone(), body_p7.clone()), move |cpp_statements_f_10680: crate::prelude::Text| {
                            let inner_p9 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&pat_binds_f_10657, &crate::prelude::Array::from(vec![cpp_statements_f_10680])), &crate::prelude::Text::lit("\n"));
                            ::prism_rtl::Turn::Finished((tests_p8.clone(), inner_p9.clone()))
                        }))
                    })
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)>>>
        }), move |each_10558: crate::prelude::Array<(crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)>| {
            let arms_p4 = each_10558;
            let blocks_p5 = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&arms_p4)), &(|i_pa: &crate::prelude::Nat| {
                let (tests_pc, inner_pd) = crate::prelude::or(&crate::prelude::index(&arms_p4, i_pa), &(crate::prelude::Array::new(), crate::prelude::Text::lit("")));
                let head_pb = if i_pa == &crate::prelude::Nat::from(0u32) {
                    crate::prelude::Text::from(format!("if ({})", &crate::emit::cpp::patterns::conds_f(&tests_pc)))
                } else {
                    if &crate::prelude::len(&tests_pc) == &crate::prelude::Nat::from(0u32) {
                        crate::prelude::Text::lit("else")
                    } else {
                        crate::prelude::Text::from(format!("else if ({})", &crate::emit::cpp::patterns::conds_f(&tests_pc)))
                    }
                };
                crate::emit::cpp::templates::items::block_f(&head_pb, &inner_pd)
            }));
            crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), x_p1x.clone()), move |cpp_expr_f_11010: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::braced_f(&crate::prelude::Text::from(format!("auto&& _m = {};\n{}", &cpp_expr_f_11010, &crate::syntax::lexer::chars::join_f(&blocks_p5, &crate::prelude::Text::lit(" ")))))))
        })
    }
}

/// `Start CppDoMatch, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_do_match_f(cp_p0: crate::emit::cpp::Cp, x_p1: crate::lower::model::Ex, cases_p2: crate::prelude::Array<(crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppDoMatch { cp_p0, x_p1, cases_p2 })
}

/// ```prism
/// CppFor: unbounded fn Cp, Pa, Ex, [Do] -> Text
/// ```
pub fn cpp_for_f(cp0_p0: &crate::emit::cpp::Cp, p_p1: &crate::lower::model::Pa, x_p2: &crate::lower::model::Ex, body_p3: &crate::prelude::Array<crate::lower::model::Do>) -> crate::prelude::Text {
    cpp_for_in_f(&unbind_f(cp0_p0, &pat_names_f(p_p1)), p_p1, &crate::emit::cpp::expr::cpp_place_f(cp0_p0, x_p2), body_p3)
}

/// The step machine of `CppFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppFor: unbounded fn Cp, Pa, Ex, [Do] -> Text
/// ```
pub struct CppFor {
    pub cp0_p0: crate::emit::cpp::Cp,
    pub p_p1: crate::lower::model::Pa,
    pub x_p2: crate::lower::model::Ex,
    pub body_p3: crate::prelude::Array<crate::lower::model::Do>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppFor {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp0_p0 = &self.cp0_p0;
        let p_p1 = &self.p_p1;
        let x_p2 = &self.x_p2;
        let body_p3 = &self.body_p3;
        let body_p3x = body_p3.clone();
        let cp0_p0x = cp0_p0.clone();
        let p_p1x = p_p1.clone();
        let x_p2x = x_p2.clone();
        crate::prelude::call_then(start_pat_names_f(p_p1x.clone()), move |pat_names_f_11224: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_place_f(cp0_p0x.clone(), x_p2x.clone()), move |cpp_place_f_11242: crate::prelude::Text| ::prism_rtl::Turn::More(::std::rc::Rc::new(CppForIn { cp_p0: unbind_f(&cp0_p0x, &pat_names_f_11224), p_p1: p_p1x.clone(), xs_p2: cpp_place_f_11242, body_p3: body_p3x.clone() }))))
    }
}

/// `Start CppFor, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_for_f(cp0_p0: crate::emit::cpp::Cp, p_p1: crate::lower::model::Pa, x_p2: crate::lower::model::Ex, body_p3: crate::prelude::Array<crate::lower::model::Do>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppFor { cp0_p0, p_p1, x_p2, body_p3 })
}

/// ```prism
/// CppForIn: unbounded fn Cp, Pa, Text, [Do] -> Text
/// ```
pub fn cpp_for_in_f(cp_p0: &crate::emit::cpp::Cp, p_p1: &crate::lower::model::Pa, xs_p2: &crate::prelude::Text, body_p3: &crate::prelude::Array<crate::lower::model::Do>) -> crate::prelude::Text {
    match p_p1 {
        crate::lower::model::Pa::PaBind(n_p4) => crate::emit::cpp::templates::items::block_f(&crate::prelude::Text::from(format!("for (auto&& {} : {})", &crate::emit::cpp::cpp_id_f(n_p4), xs_p2)), &cpp_statements_f(cp_p0, body_p3)),
        crate::lower::model::Pa::PaMut(n_p5) => crate::emit::cpp::templates::items::block_f(&crate::prelude::Text::from(format!("for (auto {} : {})", &crate::emit::cpp::cpp_id_f(n_p5), xs_p2)), &cpp_statements_f(cp_p0, body_p3)),
        crate::lower::model::Pa::PaTuple(ps_p6) => if crate::prelude::fold(ps_p6, &true, &(|f_p7: &bool, q_p8: &crate::lower::model::Pa| *f_p7 && is_name_f(q_p8))) {
            crate::emit::cpp::templates::items::block_f(&crate::prelude::Text::from(format!("for (auto&& [{}] : {})", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(ps_p6, &(|q_p9: &crate::lower::model::Pa| pat_name_f(q_p9))), &crate::prelude::Text::lit(", ")), xs_p2)), &cpp_statements_f(cp_p0, body_p3))
        } else {
            crate::emit::cpp::templates::items::block_f(&crate::prelude::Text::from(format!("for (auto&& _e : {})", xs_p2)), &crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::emit::cpp::patterns::pat_binds_f(cp_p0, p_p1, &crate::prelude::Text::lit("_e")), &crate::prelude::Array::from(vec![cpp_statements_f(cp_p0, body_p3)])), &crate::prelude::Text::lit("\n")))
        },
        _ => crate::emit::cpp::templates::items::block_f(&crate::prelude::Text::from(format!("for (auto&& _e : {})", xs_p2)), &crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::emit::cpp::patterns::pat_binds_f(cp_p0, p_p1, &crate::prelude::Text::lit("_e")), &crate::prelude::Array::from(vec![cpp_statements_f(cp_p0, body_p3)])), &crate::prelude::Text::lit("\n"))),
    }
}

/// The step machine of `CppForIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppForIn: unbounded fn Cp, Pa, Text, [Do] -> Text
/// ```
pub struct CppForIn {
    pub cp_p0: crate::emit::cpp::Cp,
    pub p_p1: crate::lower::model::Pa,
    pub xs_p2: crate::prelude::Text,
    pub body_p3: crate::prelude::Array<crate::lower::model::Do>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppForIn {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let p_p1 = &self.p_p1;
        let xs_p2 = &self.xs_p2;
        let body_p3 = &self.body_p3;
        match p_p1 {
            crate::lower::model::Pa::PaBind(n_p4) => {
                let body_p3x = body_p3.clone();
                let cp_p0x = cp_p0.clone();
                let n_p4x = n_p4.clone();
                let xs_p2x = xs_p2.clone();
                crate::prelude::call_then(start_cpp_statements_f(cp_p0x.clone(), body_p3x.clone()), move |cpp_statements_f_11409: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::block_f(&crate::prelude::Text::from(format!("for (auto&& {} : {})", &crate::emit::cpp::cpp_id_f(&n_p4x), &xs_p2x)), &cpp_statements_f_11409)))
            },
            crate::lower::model::Pa::PaMut(n_p5) => {
                let body_p3x = body_p3.clone();
                let cp_p0x = cp_p0.clone();
                let n_p5x = n_p5.clone();
                let xs_p2x = xs_p2.clone();
                crate::prelude::call_then(start_cpp_statements_f(cp_p0x.clone(), body_p3x.clone()), move |cpp_statements_f_11484: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::block_f(&crate::prelude::Text::from(format!("for (auto {} : {})", &crate::emit::cpp::cpp_id_f(&n_p5x), &xs_p2x)), &cpp_statements_f_11484)))
            },
            crate::lower::model::Pa::PaTuple(ps_p6) => if crate::prelude::fold(ps_p6, &true, &(|f_p7: &bool, q_p8: &crate::lower::model::Pa| *f_p7 && is_name_f(q_p8))) {
                {
                    let body_p3x = body_p3.clone();
                    let cp_p0x = cp_p0.clone();
                    let ps_p6x = ps_p6.clone();
                    let xs_p2x = xs_p2.clone();
                    crate::prelude::call_then(start_cpp_statements_f(cp_p0x.clone(), body_p3x.clone()), move |cpp_statements_f_11645: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::block_f(&crate::prelude::Text::from(format!("for (auto&& [{}] : {})", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&ps_p6x, &(|q_p9: &crate::lower::model::Pa| pat_name_f(q_p9))), &crate::prelude::Text::lit(", ")), &xs_p2x)), &cpp_statements_f_11645)))
                }
            } else {
                {
                    let body_p3x = body_p3.clone();
                    let cp_p0x = cp_p0.clone();
                    let p_p1x = p_p1.clone();
                    let xs_p2x = xs_p2.clone();
                    crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_binds_f(cp_p0x.clone(), p_p1x.clone(), crate::prelude::Text::lit("_e")), move |pat_binds_f_11730: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(start_cpp_statements_f(cp_p0x.clone(), body_p3x.clone()), move |cpp_statements_f_11756: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::block_f(&crate::prelude::Text::from(format!("for (auto&& _e : {})", &xs_p2x)), &crate::syntax::lexer::chars::join_f(&crate::prelude::append(&pat_binds_f_11730, &crate::prelude::Array::from(vec![cpp_statements_f_11756])), &crate::prelude::Text::lit("\n"))))))
                }
            },
            _ => {
                let body_p3x = body_p3.clone();
                let cp_p0x = cp_p0.clone();
                let p_p1x = p_p1.clone();
                let xs_p2x = xs_p2.clone();
                crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_binds_f(cp_p0x.clone(), p_p1x.clone(), crate::prelude::Text::lit("_e")), move |pat_binds_f_11852: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(start_cpp_statements_f(cp_p0x.clone(), body_p3x.clone()), move |cpp_statements_f_11878: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::block_f(&crate::prelude::Text::from(format!("for (auto&& _e : {})", &xs_p2x)), &crate::syntax::lexer::chars::join_f(&crate::prelude::append(&pat_binds_f_11852, &crate::prelude::Array::from(vec![cpp_statements_f_11878])), &crate::prelude::Text::lit("\n"))))))
            },
        }
    }
}

/// `Start CppForIn, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_for_in_f(cp_p0: crate::emit::cpp::Cp, p_p1: crate::lower::model::Pa, xs_p2: crate::prelude::Text, body_p3: crate::prelude::Array<crate::lower::model::Do>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppForIn { cp_p0, p_p1, xs_p2, body_p3 })
}

/// ```prism
/// CppBody: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_body_f(cp_p0: &crate::emit::cpp::Cp, ex1: &crate::lower::model::Ex) -> crate::prelude::Text {
    match ex1 {
        crate::lower::model::Ex::XBlock(dos_p1, e_p2) => {
            let (st_p3, cp2_p4) = cpp_statements_cp_f(cp_p0, dos_p1);
            if &crate::prelude::len(dos_p1) == &crate::prelude::Nat::from(0u32) {
                cpp_body_f(cp_p0, &**e_p2)
            } else {
                crate::prelude::Text::from(format!("{}\n{}", &st_p3, &cpp_body_f(&cp2_p4, &**e_p2)))
            }
        },
        crate::lower::model::Ex::XMatch(s_p6, arms_p7, fallback_p8, t_p9) => crate::emit::cpp::patterns::return_match_f(cp_p0, &**s_p6, arms_p7, t_p9),
        crate::lower::model::Ex::XChain(label_pb, s_pc, arms_pd, t_pe) => crate::emit::cpp::patterns::return_match_f(cp_p0, &**s_pc, arms_pd, t_pe),
        x_pg => if crate::emit::cpp::patterns::leaves_f(x_pg) {
            crate::prelude::Text::from(format!("{};", &crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_pg)))
        } else {
            crate::prelude::Text::from(format!("return {};", &cpp_returned_f(cp_p0, x_pg)))
        },
    }
}

/// The step machine of `CppBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppBody: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppBody {
    pub cp_p0: crate::emit::cpp::Cp,
    pub ex1: crate::lower::model::Ex,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppBody {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let ex1 = &self.ex1;
        match ex1 {
            crate::lower::model::Ex::XBlock(dos_p1, e_p2) => {
                let cp_p0x = cp_p0.clone();
                let dos_p1x = dos_p1.clone();
                let e_p2x = (**e_p2).clone();
                crate::prelude::call_then(start_cpp_statements_cp_f(cp_p0x.clone(), dos_p1x.clone()), move |cpp_statements_cp_f_12066: (crate::prelude::Text, crate::emit::cpp::Cp)| {
                    let (st_p3, cp2_p4) = cpp_statements_cp_f_12066;
                    if &crate::prelude::len(&dos_p1x) == &crate::prelude::Nat::from(0u32) {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(CppBody { cp_p0: cp_p0x.clone(), ex1: e_p2x.clone() }))
                    } else {
                        crate::prelude::call_then(start_cpp_body_f(cp2_p4.clone(), e_p2x.clone()), move |cpp_body_f_12141: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}\n{}", &st_p3, &cpp_body_f_12141))))
                    }
                })
            },
            crate::lower::model::Ex::XMatch(s_p6, arms_p7, fallback_p8, t_p9) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::cpp::patterns::ReturnMatch { cp_p0: cp_p0.clone(), s_p1: (**s_p6).clone(), arms_p2: arms_p7.clone(), out_ty3: t_p9.clone() })),
            crate::lower::model::Ex::XChain(label_pb, s_pc, arms_pd, t_pe) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::cpp::patterns::ReturnMatch { cp_p0: cp_p0.clone(), s_p1: (**s_pc).clone(), arms_p2: arms_pd.clone(), out_ty3: t_pe.clone() })),
            x_pg => if crate::emit::cpp::patterns::leaves_f(x_pg) {
                {
                    let cp_p0x = cp_p0.clone();
                    let x_pgx = x_pg.clone();
                    crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), x_pgx.clone()), move |cpp_expr_f_12337: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{};", &cpp_expr_f_12337))))
                }
            } else {
                {
                    let cp_p0x = cp_p0.clone();
                    let x_pgx = x_pg.clone();
                    crate::prelude::call_then(start_cpp_returned_f(cp_p0x.clone(), x_pgx.clone()), move |cpp_returned_f_12369: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("return {};", &cpp_returned_f_12369))))
                }
            },
        }
    }
}

/// `Start CppBody, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_body_f(cp_p0: crate::emit::cpp::Cp, ex1: crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppBody { cp_p0, ex1 })
}

/// ```prism
/// CppReturned: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_returned_f(cp_p0: &crate::emit::cpp::Cp, ex1: &crate::lower::model::Ex) -> crate::prelude::Text {
    match ex1 {
        crate::lower::model::Ex::XVar(n_p1) => var_name_f(cp_p0, n_p1),
        x_p3 => crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p3),
    }
}

/// The step machine of `CppReturned`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppReturned: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppReturned {
    pub cp_p0: crate::emit::cpp::Cp,
    pub ex1: crate::lower::model::Ex,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppReturned {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let ex1 = &self.ex1;
        match ex1 {
            crate::lower::model::Ex::XVar(n_p1) => ::prism_rtl::Turn::Finished(var_name_f(cp_p0, n_p1)),
            x_p3 => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::cpp::expr::CppExpr { cp_p0: cp_p0.clone(), x_p1: x_p3.clone() })),
        }
    }
}

/// `Start CppReturned, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_returned_f(cp_p0: crate::emit::cpp::Cp, ex1: crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppReturned { cp_p0, ex1 })
}
