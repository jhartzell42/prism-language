//! The module `Emit.Cpp.Patterns`, from `target/bootstrap/src/prismc/emit/cpp/patterns.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// PatConds: unbounded fn Cp, Pa, Text -> [Text]
/// ```
pub fn pat_conds(cp_p0: &crate::emit::cpp::Cp, p_p1: &crate::lower::model::Pa, v_p2: &Text) -> Array<Text> {
    match p_p1 {
        crate::lower::model::Pa::PaWild => Array::new(),
        crate::lower::model::Pa::PaBind(_) => Array::new(),
        crate::lower::model::Pa::PaMut(_) => Array::new(),
        crate::lower::model::Pa::PaTyped(q_p3, _) => pat_conds(cp_p0, &**q_p3, v_p2),
        crate::lower::model::Pa::PaUnit(c_p4) => Array::from(vec![crate::emit::cpp::expr::case_test(cp_p0, c_p4, v_p2)]),
        crate::lower::model::Pa::PaCtor(c_p5, ps_p6) => {
            let own_p7 = crate::emit::cpp::expr::case_test(cp_p0, c_p5, v_p2);
            let inner_p8 = concat2(&run_to_end(each_job(crate::check::errors::range0(&len(ps_p6)), {
                let cp_p0 = cp_p0.clone();
                let ps_p6 = ps_p6.clone();
                let c_p5 = c_p5.clone();
                let v_p2 = v_p2.clone();
                Rc::new(move |p0: Nat| {
                    let cp_p0 = cp_p0.clone();
                    let ps_p6 = ps_p6.clone();
                    let c_p5 = c_p5.clone();
                    let v_p2 = v_p2.clone();
                    entered(once_job(move || {
                        let i_p9 = p0;
                        prism_rtl::Turn::More(Rc::new(PatConds { cp_p0: cp_p0.clone(), p_p1: or(&index(&ps_p6, &i_p9), &crate::lower::model::Pa::PaWild), v_p2: crate::emit::cpp::expr::payload(&cp_p0, &c_p5, &v_p2, &i_p9) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            })));
            filter(&append(&Array::from(vec![own_p7.clone()]), &inner_p8), &(|t_pa: &Text| t_pa != &Text::lit("true")))
        },
        crate::lower::model::Pa::PaRecord(c_pb, fs_pc, _) => concat2(&run_to_end(each_job(fs_pc.clone(), {
            let cp_p0 = cp_p0.clone();
            let v_p2 = v_p2.clone();
            Rc::new(move |p0: (Text, crate::lower::model::Pa)| {
                let cp_p0 = cp_p0.clone();
                let v_p2 = v_p2.clone();
                entered(once_job(move || {
                    let (f_pd, q_pe) = p0;
                    prism_rtl::Turn::More(Rc::new(PatConds { cp_p0: cp_p0.clone(), p_p1: q_pe.clone(), v_p2: Text::from(format!("{}.{}", &v_p2, &crate::emit::cpp::field_id(&f_pd))) }))
                }))
            }) as Rc<dyn Fn((Text, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }))),
        crate::lower::model::Pa::PaTuple(ps_pf) => concat2(&run_to_end(each_job(crate::check::errors::range0(&len(ps_pf)), {
            let cp_p0 = cp_p0.clone();
            let ps_pf = ps_pf.clone();
            let v_p2 = v_p2.clone();
            Rc::new(move |p0: Nat| {
                let cp_p0 = cp_p0.clone();
                let ps_pf = ps_pf.clone();
                let v_p2 = v_p2.clone();
                entered(once_job(move || {
                    let i_pg = p0;
                    prism_rtl::Turn::More(Rc::new(PatConds { cp_p0: cp_p0.clone(), p_p1: or(&index(&ps_pf, &i_pg), &crate::lower::model::Pa::PaWild), v_p2: Text::from(format!("std::get<{}>({})", &i_pg, &v_p2)) }))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }))),
        crate::lower::model::Pa::PaChar(c_ph) => Array::from(vec![Text::from(format!("{} == U\'{}\'", v_p2, &crate::emit::cpp::expr::cpp_char_escape(c_ph)))]),
        crate::lower::model::Pa::PaBool(b_pi) => Array::from(vec![if *b_pi { v_p2.clone() } else { Text::from(format!("!{}", v_p2)) }]),
        crate::lower::model::Pa::PaIndex(n_pj) => Array::from(vec![Text::from(format!("{} == {}u", v_p2, n_pj))]),
        crate::lower::model::Pa::PaConst(n_pk) => Array::from(vec![Text::from(format!("{} == {}", v_p2, n_pk))]),
        crate::lower::model::Pa::PaSlice(ps_pl) => {
            let rest_pm = fold(ps_pl, &false, &(|f_pp: &bool, q_pq: &crate::lower::model::Pa| *f_pp || is_rest(q_pq)));
            let fixed_pn = len(&filter(ps_pl, &(|q_pr: &crate::lower::model::Pa| !is_rest(q_pr))));
            let size_po = if rest_pm {
                Text::from(format!("{}.size() >= {}", v_p2, &fixed_pn))
            } else {
                Text::from(format!("{}.size() == {}", v_p2, &fixed_pn))
            };
            append(&Array::from(vec![size_po.clone()]), &concat2(&run_to_end(each_job(crate::check::errors::range0(&len(ps_pl)), {
                let cp_p0 = cp_p0.clone();
                let ps_pl = ps_pl.clone();
                let v_p2 = v_p2.clone();
                Rc::new(move |p0: Nat| {
                    let cp_p0 = cp_p0.clone();
                    let ps_pl = ps_pl.clone();
                    let v_p2 = v_p2.clone();
                    entered(once_job(move || {
                        let i_ps = p0;
                        prism_rtl::Turn::More(Rc::new(PatConds { cp_p0: cp_p0.clone(), p_p1: or(&index(&ps_pl, &i_ps), &crate::lower::model::Pa::PaWild), v_p2: Text::from(format!("{}[{}]", &v_p2, &i_ps)) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }))))
        },
        crate::lower::model::Pa::PaRest(_) => Array::new(),
    }
}

/// The step machine of `PatConds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatConds: unbounded fn Cp, Pa, Text -> [Text]
/// ```
pub struct PatConds {
    pub cp_p0: crate::emit::cpp::Cp,
    pub p_p1: crate::lower::model::Pa,
    pub v_p2: Text,
}

impl prism_rtl::Job<Array<Text>> for PatConds {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cp_p0 = &self.cp_p0;
        let p_p1 = &self.p_p1;
        let v_p2 = &self.v_p2;
        match p_p1 {
            crate::lower::model::Pa::PaWild => prism_rtl::Turn::Finished(Array::new()),
            crate::lower::model::Pa::PaBind(_) => prism_rtl::Turn::Finished(Array::new()),
            crate::lower::model::Pa::PaMut(_) => prism_rtl::Turn::Finished(Array::new()),
            crate::lower::model::Pa::PaTyped(q_p3, _) => prism_rtl::Turn::More(Rc::new(PatConds { cp_p0: cp_p0.clone(), p_p1: (**q_p3).clone(), v_p2: v_p2.clone() })),
            crate::lower::model::Pa::PaUnit(c_p4) => prism_rtl::Turn::Finished(Array::from(vec![crate::emit::cpp::expr::case_test(cp_p0, c_p4, v_p2)])),
            crate::lower::model::Pa::PaCtor(c_p5, ps_p6) => {
                let own_p7 = crate::emit::cpp::expr::case_test(cp_p0, c_p5, v_p2);
                let c_p5 = c_p5.clone();
                let cp_p0 = cp_p0.clone();
                let ps_p6 = ps_p6.clone();
                let v_p2 = v_p2.clone();
                call_value(each_job(crate::check::errors::range0(&len(&ps_p6)), {
                    let cp_p0 = cp_p0.clone();
                    let ps_p6 = ps_p6.clone();
                    let c_p5 = c_p5.clone();
                    let v_p2 = v_p2.clone();
                    Rc::new(move |p0: Nat| {
                        let cp_p0 = cp_p0.clone();
                        let ps_p6 = ps_p6.clone();
                        let c_p5 = c_p5.clone();
                        let v_p2 = v_p2.clone();
                        entered(once_job(move || {
                            let i_p9 = p0;
                            prism_rtl::Turn::More(Rc::new(PatConds { cp_p0: cp_p0.clone(), p_p1: or(&index(&ps_p6, &i_p9), &crate::lower::model::Pa::PaWild), v_p2: crate::emit::cpp::expr::payload(&cp_p0, &c_p5, &v_p2, &i_p9) }))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_1488: Array<Array<Text>>| {
                    let inner_p8 = concat2(&each_1488);
                    prism_rtl::Turn::Finished(filter(&append(&Array::from(vec![own_p7.clone()]), &inner_p8), &(|t_pa: &Text| t_pa != &Text::lit("true"))))
                })
            },
            crate::lower::model::Pa::PaRecord(c_pb, fs_pc, _) => {
                let cp_p0 = cp_p0.clone();
                let fs_pc = fs_pc.clone();
                let v_p2 = v_p2.clone();
                call_value(each_job(fs_pc.clone(), {
                    let cp_p0 = cp_p0.clone();
                    let v_p2 = v_p2.clone();
                    Rc::new(move |p0: (Text, crate::lower::model::Pa)| {
                        let cp_p0 = cp_p0.clone();
                        let v_p2 = v_p2.clone();
                        entered(once_job(move || {
                            let (f_pd, q_pe) = p0;
                            prism_rtl::Turn::More(Rc::new(PatConds { cp_p0: cp_p0.clone(), p_p1: q_pe.clone(), v_p2: Text::from(format!("{}.{}", &v_p2, &crate::emit::cpp::field_id(&f_pd))) }))
                        }))
                    }) as Rc<dyn Fn((Text, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_1667: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_1667)))
            },
            crate::lower::model::Pa::PaTuple(ps_pf) => {
                let cp_p0 = cp_p0.clone();
                let ps_pf = ps_pf.clone();
                let v_p2 = v_p2.clone();
                call_value(each_job(crate::check::errors::range0(&len(&ps_pf)), {
                    let cp_p0 = cp_p0.clone();
                    let ps_pf = ps_pf.clone();
                    let v_p2 = v_p2.clone();
                    Rc::new(move |p0: Nat| {
                        let cp_p0 = cp_p0.clone();
                        let ps_pf = ps_pf.clone();
                        let v_p2 = v_p2.clone();
                        entered(once_job(move || {
                            let i_pg = p0;
                            prism_rtl::Turn::More(Rc::new(PatConds { cp_p0: cp_p0.clone(), p_p1: or(&index(&ps_pf, &i_pg), &crate::lower::model::Pa::PaWild), v_p2: Text::from(format!("std::get<{}>({})", &i_pg, &v_p2)) }))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_1748: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_1748)))
            },
            crate::lower::model::Pa::PaChar(c_ph) => prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("{} == U\'{}\'", v_p2, &crate::emit::cpp::expr::cpp_char_escape(c_ph)))])),
            crate::lower::model::Pa::PaBool(b_pi) => prism_rtl::Turn::Finished(Array::from(vec![if *b_pi { v_p2.clone() } else { Text::from(format!("!{}", v_p2)) }])),
            crate::lower::model::Pa::PaIndex(n_pj) => prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("{} == {}u", v_p2, n_pj))])),
            crate::lower::model::Pa::PaConst(n_pk) => prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("{} == {}", v_p2, n_pk))])),
            crate::lower::model::Pa::PaSlice(ps_pl) => {
                let rest_pm = fold(ps_pl, &false, &(|f_pp: &bool, q_pq: &crate::lower::model::Pa| *f_pp || is_rest(q_pq)));
                let fixed_pn = len(&filter(ps_pl, &(|q_pr: &crate::lower::model::Pa| !is_rest(q_pr))));
                let size_po = if rest_pm {
                    Text::from(format!("{}.size() >= {}", v_p2, &fixed_pn))
                } else {
                    Text::from(format!("{}.size() == {}", v_p2, &fixed_pn))
                };
                let cp_p0 = cp_p0.clone();
                let ps_pl = ps_pl.clone();
                let v_p2 = v_p2.clone();
                call_value(each_job(crate::check::errors::range0(&len(&ps_pl)), {
                    let cp_p0 = cp_p0.clone();
                    let ps_pl = ps_pl.clone();
                    let v_p2 = v_p2.clone();
                    Rc::new(move |p0: Nat| {
                        let cp_p0 = cp_p0.clone();
                        let ps_pl = ps_pl.clone();
                        let v_p2 = v_p2.clone();
                        entered(once_job(move || {
                            let i_ps = p0;
                            prism_rtl::Turn::More(Rc::new(PatConds { cp_p0: cp_p0.clone(), p_p1: or(&index(&ps_pl, &i_ps), &crate::lower::model::Pa::PaWild), v_p2: Text::from(format!("{}[{}]", &v_p2, &i_ps)) }))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_2231: Array<Array<Text>>| prism_rtl::Turn::Finished(append(&Array::from(vec![size_po.clone()]), &concat2(&each_2231))))
            },
            crate::lower::model::Pa::PaRest(_) => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start PatConds, x`: what the function value is when passed to `@Run`.
pub fn start_pat_conds(cp_p0: crate::emit::cpp::Cp, p_p1: crate::lower::model::Pa, v_p2: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(PatConds { cp_p0, p_p1, v_p2 })
}

/// ```prism
/// PatBinds: unbounded fn Cp, Pa, Text -> [Text]
/// ```
pub fn pat_binds(cp_p0: &crate::emit::cpp::Cp, p_p1: &crate::lower::model::Pa, v_p2: &Text) -> Array<Text> {
    'm2400: {
        if let crate::lower::model::Pa::PaWild = p_p1 {
            break 'm2400 Array::new();
        }
        if let crate::lower::model::Pa::PaBind(n_p3) = p_p1 {
            break 'm2400 Array::from(vec![Text::from(format!("auto&& {} = {};", &crate::emit::cpp::cpp_id(n_p3), v_p2))]);
        }
        if let crate::lower::model::Pa::PaMut(n_p4) = p_p1 {
            break 'm2400 Array::from(vec![Text::from(format!("auto {} = {};", &crate::emit::cpp::cpp_id(n_p4), v_p2))]);
        }
        if let crate::lower::model::Pa::PaTyped(m2400_3_0, t_p6) = p_p1 && let crate::lower::model::Pa::PaBind(n_p5) = &**m2400_3_0 {
            break 'm2400 Array::from(vec![Text::from(format!("{} {} = {};", &crate::emit::cpp::cpp_type(cp_p0, &crate::emit::cpp::expr::unref(t_p6)), &crate::emit::cpp::cpp_id(n_p5), v_p2))]);
        }
        if let crate::lower::model::Pa::PaTyped(q_p7, _) = p_p1 {
            break 'm2400 pat_binds(cp_p0, &**q_p7, v_p2);
        }
        if let crate::lower::model::Pa::PaUnit(_) = p_p1 {
            break 'm2400 Array::new();
        }
        if let crate::lower::model::Pa::PaCtor(c_p8, ps_p9) = p_p1 {
            break 'm2400 concat2(&run_to_end(each_job(crate::check::errors::range0(&len(ps_p9)), {
                let cp_p0 = cp_p0.clone();
                let ps_p9 = ps_p9.clone();
                let c_p8 = c_p8.clone();
                let v_p2 = v_p2.clone();
                Rc::new(move |p0: Nat| {
                    let cp_p0 = cp_p0.clone();
                    let ps_p9 = ps_p9.clone();
                    let c_p8 = c_p8.clone();
                    let v_p2 = v_p2.clone();
                    entered(once_job(move || {
                        let i_pa = p0;
                        prism_rtl::Turn::More(Rc::new(PatBinds { cp_p0: cp_p0.clone(), p_p1: or(&index(&ps_p9, &i_pa), &crate::lower::model::Pa::PaWild), v_p2: crate::emit::cpp::expr::payload(&cp_p0, &c_p8, &v_p2, &i_pa) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            })));
        }
        if let crate::lower::model::Pa::PaRecord(c_pb, fs_pc, _) = p_p1 {
            break 'm2400 concat2(&run_to_end(each_job(fs_pc.clone(), {
                let cp_p0 = cp_p0.clone();
                let v_p2 = v_p2.clone();
                Rc::new(move |p0: (Text, crate::lower::model::Pa)| {
                    let cp_p0 = cp_p0.clone();
                    let v_p2 = v_p2.clone();
                    entered(once_job(move || {
                        let (f_pd, q_pe) = p0;
                        prism_rtl::Turn::More(Rc::new(PatBinds { cp_p0: cp_p0.clone(), p_p1: q_pe.clone(), v_p2: Text::from(format!("{}.{}", &v_p2, &crate::emit::cpp::field_id(&f_pd))) }))
                    }))
                }) as Rc<dyn Fn((Text, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            })));
        }
        if let crate::lower::model::Pa::PaTuple(ps_pf) = p_p1 {
            break 'm2400 concat2(&run_to_end(each_job(crate::check::errors::range0(&len(ps_pf)), {
                let cp_p0 = cp_p0.clone();
                let ps_pf = ps_pf.clone();
                let v_p2 = v_p2.clone();
                Rc::new(move |p0: Nat| {
                    let cp_p0 = cp_p0.clone();
                    let ps_pf = ps_pf.clone();
                    let v_p2 = v_p2.clone();
                    entered(once_job(move || {
                        let i_pg = p0;
                        prism_rtl::Turn::More(Rc::new(PatBinds { cp_p0: cp_p0.clone(), p_p1: or(&index(&ps_pf, &i_pg), &crate::lower::model::Pa::PaWild), v_p2: Text::from(format!("std::get<{}>({})", &i_pg, &v_p2)) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            })));
        }
        if let crate::lower::model::Pa::PaSlice(ps_ph) = p_p1 {
            break 'm2400 concat2(&run_to_end(each_job(crate::check::errors::range0(&len(ps_ph)), {
                let cp_p0 = cp_p0.clone();
                let ps_ph = ps_ph.clone();
                let v_p2 = v_p2.clone();
                Rc::new(move |p0: Nat| {
                    let cp_p0 = cp_p0.clone();
                    let ps_ph = ps_ph.clone();
                    let v_p2 = v_p2.clone();
                    entered(once_job(move || {
                        let i_pi = p0;
                        prism_rtl::Turn::More(Rc::new(SliceBinds { cp_p0: cp_p0.clone(), pa1: or(&index(&ps_ph, &i_pi), &crate::lower::model::Pa::PaWild), v_p1: v_p2.clone(), i_p2: i_pi.clone() }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            })));
        }
        Array::new()
    }
}

/// The step machine of `PatBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatBinds: unbounded fn Cp, Pa, Text -> [Text]
/// ```
pub struct PatBinds {
    pub cp_p0: crate::emit::cpp::Cp,
    pub p_p1: crate::lower::model::Pa,
    pub v_p2: Text,
}

impl prism_rtl::Job<Array<Text>> for PatBinds {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cp_p0 = &self.cp_p0;
        let p_p1 = &self.p_p1;
        let v_p2 = &self.v_p2;
        'm2400: {
            if let crate::lower::model::Pa::PaWild = p_p1 {
                break 'm2400 prism_rtl::Turn::Finished(Array::new());
            }
            if let crate::lower::model::Pa::PaBind(n_p3) = p_p1 {
                break 'm2400 prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("auto&& {} = {};", &crate::emit::cpp::cpp_id(n_p3), v_p2))]));
            }
            if let crate::lower::model::Pa::PaMut(n_p4) = p_p1 {
                break 'm2400 prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("auto {} = {};", &crate::emit::cpp::cpp_id(n_p4), v_p2))]));
            }
            if let crate::lower::model::Pa::PaTyped(m2400_3_0, t_p6) = p_p1 && let crate::lower::model::Pa::PaBind(n_p5) = &**m2400_3_0 {
                break 'm2400 {
                    let cp_p0 = cp_p0.clone();
                    let n_p5 = n_p5.clone();
                    let t_p6 = t_p6.clone();
                    let v_p2 = v_p2.clone();
                    call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), crate::emit::cpp::expr::unref(&t_p6)), move |cpp_type_2542: Text| prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("{} {} = {};", &cpp_type_2542, &crate::emit::cpp::cpp_id(&n_p5), &v_p2))])))
                };
            }
            if let crate::lower::model::Pa::PaTyped(q_p7, _) = p_p1 {
                break 'm2400 prism_rtl::Turn::More(Rc::new(PatBinds { cp_p0: cp_p0.clone(), p_p1: (**q_p7).clone(), v_p2: v_p2.clone() }));
            }
            if let crate::lower::model::Pa::PaUnit(_) = p_p1 {
                break 'm2400 prism_rtl::Turn::Finished(Array::new());
            }
            if let crate::lower::model::Pa::PaCtor(c_p8, ps_p9) = p_p1 {
                break 'm2400 {
                    let c_p8 = c_p8.clone();
                    let cp_p0 = cp_p0.clone();
                    let ps_p9 = ps_p9.clone();
                    let v_p2 = v_p2.clone();
                    call_value(each_job(crate::check::errors::range0(&len(&ps_p9)), {
                        let cp_p0 = cp_p0.clone();
                        let ps_p9 = ps_p9.clone();
                        let c_p8 = c_p8.clone();
                        let v_p2 = v_p2.clone();
                        Rc::new(move |p0: Nat| {
                            let cp_p0 = cp_p0.clone();
                            let ps_p9 = ps_p9.clone();
                            let c_p8 = c_p8.clone();
                            let v_p2 = v_p2.clone();
                            entered(once_job(move || {
                                let i_pa = p0;
                                prism_rtl::Turn::More(Rc::new(PatBinds { cp_p0: cp_p0.clone(), p_p1: or(&index(&ps_p9, &i_pa), &crate::lower::model::Pa::PaWild), v_p2: crate::emit::cpp::expr::payload(&cp_p0, &c_p8, &v_p2, &i_pa) }))
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }), move |each_2677: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_2677)))
                };
            }
            if let crate::lower::model::Pa::PaRecord(c_pb, fs_pc, _) = p_p1 {
                break 'm2400 {
                    let cp_p0 = cp_p0.clone();
                    let fs_pc = fs_pc.clone();
                    let v_p2 = v_p2.clone();
                    call_value(each_job(fs_pc.clone(), {
                        let cp_p0 = cp_p0.clone();
                        let v_p2 = v_p2.clone();
                        Rc::new(move |p0: (Text, crate::lower::model::Pa)| {
                            let cp_p0 = cp_p0.clone();
                            let v_p2 = v_p2.clone();
                            entered(once_job(move || {
                                let (f_pd, q_pe) = p0;
                                prism_rtl::Turn::More(Rc::new(PatBinds { cp_p0: cp_p0.clone(), p_p1: q_pe.clone(), v_p2: Text::from(format!("{}.{}", &v_p2, &crate::emit::cpp::field_id(&f_pd))) }))
                            }))
                        }) as Rc<dyn Fn((Text, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }), move |each_2799: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_2799)))
                };
            }
            if let crate::lower::model::Pa::PaTuple(ps_pf) = p_p1 {
                break 'm2400 {
                    let cp_p0 = cp_p0.clone();
                    let ps_pf = ps_pf.clone();
                    let v_p2 = v_p2.clone();
                    call_value(each_job(crate::check::errors::range0(&len(&ps_pf)), {
                        let cp_p0 = cp_p0.clone();
                        let ps_pf = ps_pf.clone();
                        let v_p2 = v_p2.clone();
                        Rc::new(move |p0: Nat| {
                            let cp_p0 = cp_p0.clone();
                            let ps_pf = ps_pf.clone();
                            let v_p2 = v_p2.clone();
                            entered(once_job(move || {
                                let i_pg = p0;
                                prism_rtl::Turn::More(Rc::new(PatBinds { cp_p0: cp_p0.clone(), p_p1: or(&index(&ps_pf, &i_pg), &crate::lower::model::Pa::PaWild), v_p2: Text::from(format!("std::get<{}>({})", &i_pg, &v_p2)) }))
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }), move |each_2880: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_2880)))
                };
            }
            if let crate::lower::model::Pa::PaSlice(ps_ph) = p_p1 {
                break 'm2400 {
                    let cp_p0 = cp_p0.clone();
                    let ps_ph = ps_ph.clone();
                    let v_p2 = v_p2.clone();
                    call_value(each_job(crate::check::errors::range0(&len(&ps_ph)), {
                        let cp_p0 = cp_p0.clone();
                        let ps_ph = ps_ph.clone();
                        let v_p2 = v_p2.clone();
                        Rc::new(move |p0: Nat| {
                            let cp_p0 = cp_p0.clone();
                            let ps_ph = ps_ph.clone();
                            let v_p2 = v_p2.clone();
                            entered(once_job(move || {
                                let i_pi = p0;
                                prism_rtl::Turn::More(Rc::new(SliceBinds { cp_p0: cp_p0.clone(), pa1: or(&index(&ps_ph, &i_pi), &crate::lower::model::Pa::PaWild), v_p1: v_p2.clone(), i_p2: i_pi.clone() }))
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }), move |each_2989: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_2989)))
                };
            }
            prism_rtl::Turn::Finished(Array::new())
        }
    }
}

/// `Start PatBinds, x`: what the function value is when passed to `@Run`.
pub fn start_pat_binds(cp_p0: crate::emit::cpp::Cp, p_p1: crate::lower::model::Pa, v_p2: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(PatBinds { cp_p0, p_p1, v_p2 })
}

/// ```prism
/// SliceBinds: unbounded fn Cp, Pa, Text, Nat -> [Text]
/// ```
pub fn slice_binds(cp_p0: &crate::emit::cpp::Cp, pa1: &crate::lower::model::Pa, v_p1: &Text, i_p2: &Nat) -> Array<Text> {
    match pa1 {
        crate::lower::model::Pa::PaRest(c0_1_0) if (c0_1_0 == &Text::lit("")) => Array::new(),
        crate::lower::model::Pa::PaRest(n_p4) => Array::from(vec![Text::from(format!("auto {} = {}.subspan({});", &crate::emit::cpp::cpp_id(n_p4), v_p1, i_p2))]),
        p_p8 => pat_binds(cp_p0, p_p8, &Text::from(format!("{}[{}]", v_p1, i_p2))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `SliceBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SliceBinds: unbounded fn Cp, Pa, Text, Nat -> [Text]
/// ```
pub struct SliceBinds {
    pub cp_p0: crate::emit::cpp::Cp,
    pub pa1: crate::lower::model::Pa,
    pub v_p1: Text,
    pub i_p2: Nat,
}

impl prism_rtl::Job<Array<Text>> for SliceBinds {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cp_p0 = &self.cp_p0;
        let pa1 = &self.pa1;
        let v_p1 = &self.v_p1;
        let i_p2 = &self.i_p2;
        match pa1 {
            crate::lower::model::Pa::PaRest(j0_1_0) if (j0_1_0 == &Text::lit("")) => prism_rtl::Turn::Finished(Array::new()),
            crate::lower::model::Pa::PaRest(n_p4) => prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("auto {} = {}.subspan({});", &crate::emit::cpp::cpp_id(n_p4), v_p1, i_p2))])),
            p_p8 => prism_rtl::Turn::More(Rc::new(PatBinds { cp_p0: cp_p0.clone(), p_p1: p_p8.clone(), v_p2: Text::from(format!("{}[{}]", v_p1, i_p2)) })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start SliceBinds, x`: what the function value is when passed to `@Run`.
pub fn start_slice_binds(cp_p0: crate::emit::cpp::Cp, pa1: crate::lower::model::Pa, v_p1: Text, i_p2: Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SliceBinds { cp_p0, pa1, v_p1, i_p2 })
}

/// ```prism
/// IsRest: fn Pa -> Bool
/// ```
pub fn is_rest(pa0: &crate::lower::model::Pa) -> bool {
    match pa0 {
        crate::lower::model::Pa::PaRest(_) => true,
        other_p0 => false,
    }
}

/// ```prism
/// Concat2: fn [ [Text] ] -> [Text]
/// ```
pub fn concat2(xss_p0: &Array<Array<Text>>) -> Array<Text> {
    fold(xss_p0, &Array::new(), &(|acc_p1: &Array<Text>, xs_p2: &Array<Text>| append(acc_p1, xs_p2)))
}

/// ```prism
/// Conds: fn [Text] -> Text
/// ```
pub fn conds(xs0: &Array<Text>) -> Text {
    match xs0 {
        c0_0 if (c0_0.len() == 0) => Text::lit("true"),
        cs_p0 => crate::syntax::lexer::chars::join(cs_p0, &Text::lit(" && ")),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IsCatchAll: fn Pa -> Bool
/// ```
pub fn is_catch_all(p_p0: &crate::lower::model::Pa) -> bool {
    match p_p0 {
        crate::lower::model::Pa::PaWild => true,
        crate::lower::model::Pa::PaBind(_) => true,
        crate::lower::model::Pa::PaMut(_) => true,
        crate::lower::model::Pa::PaTyped(q_p1, _) => is_catch_all(&**q_p1),
        _ => false,
    }
}

/// ```prism
/// Leaves: fn Ex -> Bool
/// ```
pub fn leaves(x_p0: &crate::lower::model::Ex) -> bool {
    match x_p0 {
        crate::lower::model::Ex::XBreak(_, _) => true,
        crate::lower::model::Ex::XBreakLoop => true,
        crate::lower::model::Ex::XUnreachable => true,
        _ => false,
    }
}

/// ```prism
/// CppMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
/// ```
pub fn cpp_match(cp_p0: &crate::emit::cpp::Cp, s_p1: &crate::lower::model::Ex, arms_p2: &Array<crate::lower::model::XArm>, out_ty3: &crate::lower::model::OutTy) -> Text {
    match out_ty3 {
        crate::lower::model::OutTy::OutUnknown(what_p3) => ternary_match(cp_p0, s_p1, arms_p2),
        t_p7 => {
            let bound_o8 = 'm4524: {
                if let crate::lower::model::Ex::XVar(n_pc) = s_p1 {
                    break 'm4524 Some(crate::emit::cpp::stmts::var_name(cp_p0, n_pc));
                }
                if let crate::lower::model::Ex::XRef(m4524_1_0) = s_p1 && let crate::lower::model::Ex::XVar(n_pd) = &**m4524_1_0 {
                    break 'm4524 Some(crate::emit::cpp::stmts::var_name(cp_p0, n_pd));
                }
                None
            };
            let subject_p9 = or(&bound_o8, &Text::lit("_m"));
            let bind_pa = match &bound_o8 {
                Some(_) => Text::lit(""),
                None => Text::from(format!("auto&& _m = {};\n", &crate::emit::cpp::expr::cpp_expr(cp_p0, s_p1))),
            };
            let lines_pb = run_to_end(each_job(arms_p2.clone(), {
                let cp_p0 = cp_p0.clone();
                let subject_p9 = subject_p9.clone();
                Rc::new(move |p0: crate::lower::model::XArm| {
                    let cp_p0 = cp_p0.clone();
                    let subject_p9 = subject_p9.clone();
                    entered(once_job(move || {
                        let a_pe = p0;
                        prism_rtl::Turn::More(Rc::new(MatchArm { cp0_p0: cp_p0.clone(), subject_p1: subject_p9.clone(), a_p2: a_pe.clone(), returns_p3: false }))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            crate::emit::cpp::templates::items::match_expr(&crate::emit::cpp::cpp_type(cp_p0, t_p7), &Text::from(format!("{}{}\n{}", &bind_pa, &crate::syntax::lexer::chars::join(&lines_pb, &Text::lit("\n")), &match_tail(arms_p2))))
        },
    }
}

/// The step machine of `CppMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
/// ```
pub struct CppMatch {
    pub cp_p0: crate::emit::cpp::Cp,
    pub s_p1: crate::lower::model::Ex,
    pub arms_p2: Array<crate::lower::model::XArm>,
    pub out_ty3: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for CppMatch {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let s_p1 = &self.s_p1;
        let arms_p2 = &self.arms_p2;
        let out_ty3 = &self.out_ty3;
        match out_ty3 {
            crate::lower::model::OutTy::OutUnknown(what_p3) => prism_rtl::Turn::More(Rc::new(TernaryMatch { cp_p0: cp_p0.clone(), s_p1: s_p1.clone(), arms_p2: arms_p2.clone() })),
            t_p7 => {
                let bound_o8 = 'm4524: {
                    if let crate::lower::model::Ex::XVar(n_pc) = s_p1 {
                        break 'm4524 Some(crate::emit::cpp::stmts::var_name(cp_p0, n_pc));
                    }
                    if let crate::lower::model::Ex::XRef(m4524_1_0) = s_p1 && let crate::lower::model::Ex::XVar(n_pd) = &**m4524_1_0 {
                        break 'm4524 Some(crate::emit::cpp::stmts::var_name(cp_p0, n_pd));
                    }
                    None
                };
                let subject_p9 = or(&bound_o8, &Text::lit("_m"));
                let bind_pa = match &bound_o8 {
                    Some(_) => Text::lit(""),
                    None => Text::from(format!("auto&& _m = {};\n", &crate::emit::cpp::expr::cpp_expr(cp_p0, s_p1))),
                };
                let arms_p2 = arms_p2.clone();
                let cp_p0 = cp_p0.clone();
                let s_p1 = s_p1.clone();
                let t_p7 = t_p7.clone();
                call_value(each_job(arms_p2.clone(), {
                    let cp_p0 = cp_p0.clone();
                    let subject_p9 = subject_p9.clone();
                    Rc::new(move |p0: crate::lower::model::XArm| {
                        let cp_p0 = cp_p0.clone();
                        let subject_p9 = subject_p9.clone();
                        entered(once_job(move || {
                            let a_pe = p0;
                            prism_rtl::Turn::More(Rc::new(MatchArm { cp0_p0: cp_p0.clone(), subject_p1: subject_p9.clone(), a_p2: a_pe.clone(), returns_p3: false }))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_4777: Array<Text>| {
                    let lines_pb = each_4777;
                    call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), t_p7.clone()), move |cpp_type_4839: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::match_expr(&cpp_type_4839, &Text::from(format!("{}{}\n{}", &bind_pa, &crate::syntax::lexer::chars::join(&lines_pb, &Text::lit("\n")), &match_tail(&arms_p2))))))
                })
            },
        }
    }
}

/// `Start CppMatch, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_match(cp_p0: crate::emit::cpp::Cp, s_p1: crate::lower::model::Ex, arms_p2: Array<crate::lower::model::XArm>, out_ty3: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppMatch { cp_p0, s_p1, arms_p2, out_ty3 })
}

/// ```prism
/// ReturnMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
/// ```
pub fn return_match(cp_p0: &crate::emit::cpp::Cp, s_p1: &crate::lower::model::Ex, arms_p2: &Array<crate::lower::model::XArm>, out_ty3: &crate::lower::model::OutTy) -> Text {
    match out_ty3 {
        crate::lower::model::OutTy::OutUnknown(what_p3) => Text::from(format!("return {};", &ternary_match(cp_p0, s_p1, arms_p2))),
        t_p7 => {
            let bound_o8 = 'm5310: {
                if let crate::lower::model::Ex::XVar(n_pc) = s_p1 {
                    break 'm5310 Some(crate::emit::cpp::stmts::var_name(cp_p0, n_pc));
                }
                if let crate::lower::model::Ex::XRef(m5310_1_0) = s_p1 && let crate::lower::model::Ex::XVar(n_pd) = &**m5310_1_0 {
                    break 'm5310 Some(crate::emit::cpp::stmts::var_name(cp_p0, n_pd));
                }
                None
            };
            let subject_p9 = or(&bound_o8, &Text::lit("_m"));
            let bind_pa = match &bound_o8 {
                Some(_) => Text::lit(""),
                None => Text::from(format!("auto&& _m = {};\n", &crate::emit::cpp::expr::cpp_expr(cp_p0, s_p1))),
            };
            let lines_pb = run_to_end(each_job(arms_p2.clone(), {
                let cp_p0 = cp_p0.clone();
                let subject_p9 = subject_p9.clone();
                Rc::new(move |p0: crate::lower::model::XArm| {
                    let cp_p0 = cp_p0.clone();
                    let subject_p9 = subject_p9.clone();
                    entered(once_job(move || {
                        let a_pe = p0;
                        prism_rtl::Turn::More(Rc::new(MatchArm { cp0_p0: cp_p0.clone(), subject_p1: subject_p9.clone(), a_p2: a_pe.clone(), returns_p3: true }))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            Text::from(format!("{}{}\n{}", &bind_pa, &crate::syntax::lexer::chars::join(&lines_pb, &Text::lit("\n")), &match_tail(arms_p2)))
        },
    }
}

/// The step machine of `ReturnMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReturnMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
/// ```
pub struct ReturnMatch {
    pub cp_p0: crate::emit::cpp::Cp,
    pub s_p1: crate::lower::model::Ex,
    pub arms_p2: Array<crate::lower::model::XArm>,
    pub out_ty3: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for ReturnMatch {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let s_p1 = &self.s_p1;
        let arms_p2 = &self.arms_p2;
        let out_ty3 = &self.out_ty3;
        match out_ty3 {
            crate::lower::model::OutTy::OutUnknown(what_p3) => {
                let arms_p2 = arms_p2.clone();
                let cp_p0 = cp_p0.clone();
                let s_p1 = s_p1.clone();
                call_then(start_ternary_match(cp_p0.clone(), s_p1.clone(), arms_p2.clone()), move |ternary_match_5234: Text| prism_rtl::Turn::Finished(Text::from(format!("return {};", &ternary_match_5234))))
            },
            t_p7 => {
                let bound_o8 = 'm5310: {
                    if let crate::lower::model::Ex::XVar(n_pc) = s_p1 {
                        break 'm5310 Some(crate::emit::cpp::stmts::var_name(cp_p0, n_pc));
                    }
                    if let crate::lower::model::Ex::XRef(m5310_1_0) = s_p1 && let crate::lower::model::Ex::XVar(n_pd) = &**m5310_1_0 {
                        break 'm5310 Some(crate::emit::cpp::stmts::var_name(cp_p0, n_pd));
                    }
                    None
                };
                let subject_p9 = or(&bound_o8, &Text::lit("_m"));
                let bind_pa = match &bound_o8 {
                    Some(_) => Text::lit(""),
                    None => Text::from(format!("auto&& _m = {};\n", &crate::emit::cpp::expr::cpp_expr(cp_p0, s_p1))),
                };
                let arms_p2 = arms_p2.clone();
                let cp_p0 = cp_p0.clone();
                let s_p1 = s_p1.clone();
                call_value(each_job(arms_p2.clone(), {
                    let cp_p0 = cp_p0.clone();
                    let subject_p9 = subject_p9.clone();
                    Rc::new(move |p0: crate::lower::model::XArm| {
                        let cp_p0 = cp_p0.clone();
                        let subject_p9 = subject_p9.clone();
                        entered(once_job(move || {
                            let a_pe = p0;
                            prism_rtl::Turn::More(Rc::new(MatchArm { cp0_p0: cp_p0.clone(), subject_p1: subject_p9.clone(), a_p2: a_pe.clone(), returns_p3: true }))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_5563: Array<Text>| {
                    let lines_pb = each_5563;
                    prism_rtl::Turn::Finished(Text::from(format!("{}{}\n{}", &bind_pa, &crate::syntax::lexer::chars::join(&lines_pb, &Text::lit("\n")), &match_tail(&arms_p2))))
                })
            },
        }
    }
}

/// `Start ReturnMatch, x`: what the function value is when passed to `@Run`.
pub fn start_return_match(cp_p0: crate::emit::cpp::Cp, s_p1: crate::lower::model::Ex, arms_p2: Array<crate::lower::model::XArm>, out_ty3: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ReturnMatch { cp_p0, s_p1, arms_p2, out_ty3 })
}

/// ```prism
/// MatchTail: fn [XArm] -> Text
/// ```
pub fn match_tail(arms_p0: &Array<crate::lower::model::XArm>) -> Text {
    let ends_p1 = match crate::syntax::lexer::chars::last(arms_p0) {
        Some(a_p2) => is_catch_all(&a_p2.pat) && (&len(&a_p2.conds) == &Nat::from(0u32)),
        None => false,
    };
    if ends_p1 {
        Text::lit("")
    } else {
        Text::lit("prism_rtl::unreachable(\"no arm matched\");\n")
    }
}

/// ```prism
/// TernaryMatch: unbounded fn Cp, Ex, [XArm] -> Text
/// ```
pub fn ternary_match(cp_p0: &crate::emit::cpp::Cp, s_p1: &crate::lower::model::Ex, arms_p2: &Array<crate::lower::model::XArm>) -> Text {
    let bound_o3 = 'm6295: {
        if let crate::lower::model::Ex::XVar(n_p9) = s_p1 {
            break 'm6295 Some(crate::emit::cpp::stmts::var_name(cp_p0, n_p9));
        }
        if let crate::lower::model::Ex::XRef(m6295_1_0) = s_p1 && let crate::lower::model::Ex::XVar(n_pa) = &**m6295_1_0 {
            break 'm6295 Some(crate::emit::cpp::stmts::var_name(cp_p0, n_pa));
        }
        None
    };
    let subject_p4 = or(&bound_o3, &Text::lit("_m"));
    let bind_p5 = match &bound_o3 {
        Some(_) => Text::lit(""),
        None => Text::from(format!("auto&& _m = {};\n", &crate::emit::cpp::expr::cpp_expr(cp_p0, s_p1))),
    };
    let reached_p6 = run_to_end(fold_job(arms_p2.clone(), (Array::new(), false), {
        let cp_p0 = cp_p0.clone();
        let subject_p4 = subject_p4.clone();
        Rc::new(move |(p0, p1): ((Array<crate::lower::model::XArm>, bool), crate::lower::model::XArm)| {
            let cp_p0 = cp_p0.clone();
            let subject_p4 = subject_p4.clone();
            entered(once_job(move || {
                let (acc_pb, done_pc) = p0;
                let a_pd = p1;
                if done_pc {
                    prism_rtl::Turn::Finished((acc_pb.clone(), done_pc))
                } else {
                    call_then(start_pat_conds(cp_p0.clone(), a_pd.pat.clone(), subject_p4.clone()), move |pat_conds_6734: Array<Text>| prism_rtl::Turn::Finished((push(&acc_pb, &a_pd), (&len(&pat_conds_6734) == &Nat::from(0u32)) && (&len(&a_pd.conds) == &Nat::from(0u32)))))
                }
            }))
        }) as Rc<dyn Fn(((Array<crate::lower::model::XArm>, bool), crate::lower::model::XArm)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::XArm>, bool)>>>
    }));
    let (kept_pe, ends_pf) = reached_p6.clone();
    let parts_p7 = run_to_end(each_job(kept_pe.clone(), {
        let cp_p0 = cp_p0.clone();
        let subject_p4 = subject_p4.clone();
        Rc::new(move |p0: crate::lower::model::XArm| {
            let cp_p0 = cp_p0.clone();
            let subject_p4 = subject_p4.clone();
            entered(once_job(move || {
                let a_pg = p0;
                prism_rtl::Turn::More(Rc::new(TernaryArm { cp0_p0: cp_p0.clone(), subject_p1: subject_p4.clone(), a_p2: a_pg.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let last_text_p8 = if ends_pf {
        Text::lit("")
    } else {
        Text::lit("\n    : throw prism_rtl::Panic(\"no arm matched\")")
    };
    crate::emit::cpp::templates::items::stmt_expr(&Text::from(format!("{}", &bind_p5)), &Text::from(format!("{}{}", &crate::syntax::lexer::chars::join(&parts_p7, &Text::lit("\n    : ")), &last_text_p8)))
}

/// The step machine of `TernaryMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TernaryMatch: unbounded fn Cp, Ex, [XArm] -> Text
/// ```
pub struct TernaryMatch {
    pub cp_p0: crate::emit::cpp::Cp,
    pub s_p1: crate::lower::model::Ex,
    pub arms_p2: Array<crate::lower::model::XArm>,
}

impl prism_rtl::Job<Text> for TernaryMatch {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let s_p1 = &self.s_p1;
        let arms_p2 = &self.arms_p2;
        let bound_o3 = 'm6295: {
            if let crate::lower::model::Ex::XVar(n_p9) = s_p1 {
                break 'm6295 Some(crate::emit::cpp::stmts::var_name(cp_p0, n_p9));
            }
            if let crate::lower::model::Ex::XRef(m6295_1_0) = s_p1 && let crate::lower::model::Ex::XVar(n_pa) = &**m6295_1_0 {
                break 'm6295 Some(crate::emit::cpp::stmts::var_name(cp_p0, n_pa));
            }
            None
        };
        let subject_p4 = or(&bound_o3, &Text::lit("_m"));
        let bind_p5 = match &bound_o3 {
            Some(_) => Text::lit(""),
            None => Text::from(format!("auto&& _m = {};\n", &crate::emit::cpp::expr::cpp_expr(cp_p0, s_p1))),
        };
        let arms_p2 = arms_p2.clone();
        let cp_p0 = cp_p0.clone();
        call_value(fold_job(arms_p2.clone(), (Array::new(), false), {
            let cp_p0 = cp_p0.clone();
            let subject_p4 = subject_p4.clone();
            Rc::new(move |(p0, p1): ((Array<crate::lower::model::XArm>, bool), crate::lower::model::XArm)| {
                let cp_p0 = cp_p0.clone();
                let subject_p4 = subject_p4.clone();
                entered(once_job(move || {
                    let (acc_pb, done_pc) = p0;
                    let a_pd = p1;
                    if done_pc {
                        prism_rtl::Turn::Finished((acc_pb.clone(), done_pc))
                    } else {
                        call_then(start_pat_conds(cp_p0.clone(), a_pd.pat.clone(), subject_p4.clone()), move |pat_conds_6734: Array<Text>| prism_rtl::Turn::Finished((push(&acc_pb, &a_pd), (&len(&pat_conds_6734) == &Nat::from(0u32)) && (&len(&a_pd.conds) == &Nat::from(0u32)))))
                    }
                }))
            }) as Rc<dyn Fn(((Array<crate::lower::model::XArm>, bool), crate::lower::model::XArm)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::XArm>, bool)>>>
        }), move |fold_6634: (Array<crate::lower::model::XArm>, bool)| {
            let reached_p6 = fold_6634;
            let (kept_pe, ends_pf) = reached_p6.clone();
            call_value(each_job(kept_pe.clone(), {
                let cp_p0 = cp_p0.clone();
                let subject_p4 = subject_p4.clone();
                Rc::new(move |p0: crate::lower::model::XArm| {
                    let cp_p0 = cp_p0.clone();
                    let subject_p4 = subject_p4.clone();
                    entered(once_job(move || {
                        let a_pg = p0;
                        prism_rtl::Turn::More(Rc::new(TernaryArm { cp0_p0: cp_p0.clone(), subject_p1: subject_p4.clone(), a_p2: a_pg.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_6843: Array<Text>| {
                let parts_p7 = each_6843;
                let last_text_p8 = if ends_pf {
                    Text::lit("")
                } else {
                    Text::lit("\n    : throw prism_rtl::Panic(\"no arm matched\")")
                };
                prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::stmt_expr(&Text::from(format!("{}", &bind_p5)), &Text::from(format!("{}{}", &crate::syntax::lexer::chars::join(&parts_p7, &Text::lit("\n    : ")), &last_text_p8))))
            })
        })
    }
}

/// `Start TernaryMatch, x`: what the function value is when passed to `@Run`.
pub fn start_ternary_match(cp_p0: crate::emit::cpp::Cp, s_p1: crate::lower::model::Ex, arms_p2: Array<crate::lower::model::XArm>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TernaryMatch { cp_p0, s_p1, arms_p2 })
}

/// ```prism
/// TernaryArm: unbounded fn Cp, Text, XArm -> Text
/// ```
pub fn ternary_arm(cp0_p0: &crate::emit::cpp::Cp, subject_p1: &Text, a_p2: &crate::lower::model::XArm) -> Text {
    let cp_p3 = crate::emit::cpp::stmts::unbind(cp0_p0, &crate::emit::cpp::stmts::arm_names(a_p2));
    let tests_p4 = pat_conds(&cp_p3, &a_p2.pat, subject_p1);
    let binds_p5 = pat_binds(&cp_p3, &a_p2.pat, subject_p1);
    let n_p6 = len(&a_p2.conds);
    let lets_p7 = concat2(&run_to_end(each_job(crate::check::errors::range0(&n_p6), {
        let cp_p3 = cp_p3.clone();
        let a_p2 = a_p2.clone();
        let n_p6 = n_p6.clone();
        Rc::new(move |p0: Nat| {
            let cp_p3 = cp_p3.clone();
            let a_p2 = a_p2.clone();
            let n_p6 = n_p6.clone();
            entered(once_job(move || {
                let i_pb = p0;
                prism_rtl::Turn::More(Rc::new(CondBinds { cp_p0: cp_p3.clone(), cc1: or(&index(&a_p2.conds, &i_pb), &crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XUnit)), k_p3: or(&(&n_p6).checked_sub(&i_pb), &Nat::from(0u32)) }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    })));
    let value_p8 = if &(&len(&binds_p5) + &len(&lets_p7)) == &Nat::from(0u32) {
        crate::emit::cpp::expr::cpp_expr(&cp_p3, &a_p2.body)
    } else {
        crate::emit::cpp::templates::items::stmt_expr(&crate::syntax::lexer::chars::join(&append(&binds_p5, &lets_p7), &Text::lit("\n")), &crate::emit::cpp::expr::cpp_expr(&cp_p3, &a_p2.body))
    };
    let guard_p9 = if &len(&a_p2.conds) == &Nat::from(0u32) {
        Array::new()
    } else {
        Array::from(vec![crate::emit::cpp::templates::items::stmt_expr(&crate::syntax::lexer::chars::join(&binds_p5, &Text::lit("\n")), &guard_test(&cp_p3, &a_p2.conds))])
    };
    let all_pa = append(&tests_p4, &guard_p9);
    if &len(&all_pa) == &Nat::from(0u32) {
        value_p8.clone()
    } else {
        Text::from(format!("{} ? {}", &conds(&all_pa), &value_p8))
    }
}

/// The step machine of `TernaryArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TernaryArm: unbounded fn Cp, Text, XArm -> Text
/// ```
pub struct TernaryArm {
    pub cp0_p0: crate::emit::cpp::Cp,
    pub subject_p1: Text,
    pub a_p2: crate::lower::model::XArm,
}

impl prism_rtl::Job<Text> for TernaryArm {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp0_p0 = &self.cp0_p0;
        let subject_p1 = &self.subject_p1;
        let a_p2 = &self.a_p2;
        let a_p2 = a_p2.clone();
        let cp0_p0 = cp0_p0.clone();
        let subject_p1 = subject_p1.clone();
        call_then(crate::emit::cpp::stmts::start_arm_names(a_p2.clone()), move |arm_names_7141: Array<Text>| {
            let cp_p3 = crate::emit::cpp::stmts::unbind(&cp0_p0, &arm_names_7141);
            call_then(start_pat_conds(cp_p3.clone(), a_p2.pat.clone(), subject_p1.clone()), move |pat_conds_7169: Array<Text>| {
                let tests_p4 = pat_conds_7169;
                call_then(start_pat_binds(cp_p3.clone(), a_p2.pat.clone(), subject_p1.clone()), move |pat_binds_7213: Array<Text>| {
                    let binds_p5 = pat_binds_7213;
                    let n_p6 = len(&a_p2.conds);
                    call_value(each_job(crate::check::errors::range0(&n_p6), {
                        let cp_p3 = cp_p3.clone();
                        let a_p2 = a_p2.clone();
                        let n_p6 = n_p6.clone();
                        Rc::new(move |p0: Nat| {
                            let cp_p3 = cp_p3.clone();
                            let a_p2 = a_p2.clone();
                            let n_p6 = n_p6.clone();
                            entered(once_job(move || {
                                let i_pb = p0;
                                prism_rtl::Turn::More(Rc::new(CondBinds { cp_p0: cp_p3.clone(), cc1: or(&index(&a_p2.conds, &i_pb), &crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XUnit)), k_p3: or(&(&n_p6).checked_sub(&i_pb), &Nat::from(0u32)) }))
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }), move |each_7289: Array<Array<Text>>| {
                        let lets_p7 = concat2(&each_7289);
                        let value_p8 = if &(&len(&binds_p5) + &len(&lets_p7)) == &Nat::from(0u32) {
                            crate::emit::cpp::expr::cpp_expr(&cp_p3, &a_p2.body)
                        } else {
                            crate::emit::cpp::templates::items::stmt_expr(&crate::syntax::lexer::chars::join(&append(&binds_p5, &lets_p7), &Text::lit("\n")), &crate::emit::cpp::expr::cpp_expr(&cp_p3, &a_p2.body))
                        };
                        let guard_p9 = if &len(&a_p2.conds) == &Nat::from(0u32) {
                            Array::new()
                        } else {
                            Array::from(vec![crate::emit::cpp::templates::items::stmt_expr(&crate::syntax::lexer::chars::join(&binds_p5, &Text::lit("\n")), &guard_test(&cp_p3, &a_p2.conds))])
                        };
                        let all_pa = append(&tests_p4, &guard_p9);
                        if &len(&all_pa) == &Nat::from(0u32) {
                            prism_rtl::Turn::Finished(value_p8.clone())
                        } else {
                            prism_rtl::Turn::Finished(Text::from(format!("{} ? {}", &conds(&all_pa), &value_p8)))
                        }
                    })
                })
            })
        })
    }
}

/// `Start TernaryArm, x`: what the function value is when passed to `@Run`.
pub fn start_ternary_arm(cp0_p0: crate::emit::cpp::Cp, subject_p1: Text, a_p2: crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TernaryArm { cp0_p0, subject_p1, a_p2 })
}

/// ```prism
/// CondBinds: unbounded fn Cp, Cc, Nat -> [Text]
/// ```
pub fn cond_binds(cp_p0: &crate::emit::cpp::Cp, cc1: &crate::lower::model::Cc, k_p3: &Nat) -> Array<Text> {
    match cc1 {
        crate::lower::model::Cc::CcLet(p_p1, x_p2) => {
            let (v_p4, pre_p5) = cond_subject(cp_p0, x_p2, k_p3);
            append(&pre_p5, &pat_binds(cp_p0, p_p1, &v_p4))
        },
        crate::lower::model::Cc::CcIf(x_p7) => Array::new(),
    }
}

/// The step machine of `CondBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondBinds: unbounded fn Cp, Cc, Nat -> [Text]
/// ```
pub struct CondBinds {
    pub cp_p0: crate::emit::cpp::Cp,
    pub cc1: crate::lower::model::Cc,
    pub k_p3: Nat,
}

impl prism_rtl::Job<Array<Text>> for CondBinds {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cp_p0 = &self.cp_p0;
        let cc1 = &self.cc1;
        let k_p3 = &self.k_p3;
        match cc1 {
            crate::lower::model::Cc::CcLet(p_p1, x_p2) => {
                let cp_p0 = cp_p0.clone();
                let k_p3 = k_p3.clone();
                let p_p1 = p_p1.clone();
                let x_p2 = x_p2.clone();
                call_then(start_cond_subject(cp_p0.clone(), x_p2.clone(), k_p3.clone()), move |cond_subject_7818: (Text, Array<Text>)| {
                    let (v_p4, pre_p5) = cond_subject_7818;
                    call_then(start_pat_binds(cp_p0.clone(), p_p1.clone(), v_p4.clone()), move |pat_binds_7856: Array<Text>| prism_rtl::Turn::Finished(append(&pre_p5, &pat_binds_7856)))
                })
            },
            crate::lower::model::Cc::CcIf(x_p7) => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start CondBinds, x`: what the function value is when passed to `@Run`.
pub fn start_cond_binds(cp_p0: crate::emit::cpp::Cp, cc1: crate::lower::model::Cc, k_p3: Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(CondBinds { cp_p0, cc1, k_p3 })
}

/// ```prism
/// CondSubject: unbounded fn Cp, Ex, Nat -> ((Text, [Text]))
/// ```
pub fn cond_subject(cp_p0: &crate::emit::cpp::Cp, x_p1: &crate::lower::model::Ex, k_p2: &Nat) -> (Text, Array<Text>) {
    if is_place_ex(x_p1) {
        (crate::emit::cpp::expr::cpp_tight(cp_p0, x_p1), Array::new())
    } else {
        (Text::from(format!("_c{}", k_p2)), Array::from(vec![Text::from(format!("auto&& _c{} = {};", k_p2, &crate::emit::cpp::expr::cpp_expr(cp_p0, x_p1)))]))
    }
}

/// The step machine of `CondSubject`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondSubject: unbounded fn Cp, Ex, Nat -> ((Text, [Text]))
/// ```
pub struct CondSubject {
    pub cp_p0: crate::emit::cpp::Cp,
    pub x_p1: crate::lower::model::Ex,
    pub k_p2: Nat,
}

impl prism_rtl::Job<(Text, Array<Text>)> for CondSubject {
    fn cycle(&self) -> prism_rtl::Turn<(Text, Array<Text>)> {
        let cp_p0 = &self.cp_p0;
        let x_p1 = &self.x_p1;
        let k_p2 = &self.k_p2;
        if is_place_ex(x_p1) {
            {
                let cp_p0 = cp_p0.clone();
                let x_p1 = x_p1.clone();
                call_then(crate::emit::cpp::expr::start_cpp_tight(cp_p0.clone(), x_p1.clone()), move |cpp_tight_8273: Text| prism_rtl::Turn::Finished((cpp_tight_8273, Array::new())))
            }
        } else {
            {
                let cp_p0 = cp_p0.clone();
                let k_p2 = k_p2.clone();
                let x_p1 = x_p1.clone();
                call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), x_p1.clone()), move |cpp_expr_8333: Text| prism_rtl::Turn::Finished((Text::from(format!("_c{}", &k_p2)), Array::from(vec![Text::from(format!("auto&& _c{} = {};", &k_p2, &cpp_expr_8333))]))))
            }
        }
    }
}

/// `Start CondSubject, x`: what the function value is when passed to `@Run`.
pub fn start_cond_subject(cp_p0: crate::emit::cpp::Cp, x_p1: crate::lower::model::Ex, k_p2: Nat) -> Rc<dyn prism_rtl::Job<(Text, Array<Text>)>> {
    Rc::new(CondSubject { cp_p0, x_p1, k_p2 })
}

/// ```prism
/// IsPlaceEx: fn Ex -> Bool
/// ```
pub fn is_place_ex(x_p0: &crate::lower::model::Ex) -> bool {
    match x_p0 {
        crate::lower::model::Ex::XVar(_) => true,
        crate::lower::model::Ex::XField(y_p1, _) => is_place_ex(&**y_p1),
        crate::lower::model::Ex::XPart(y_p2, _) => is_place_ex(&**y_p2),
        crate::lower::model::Ex::XTarget(_) => true,
        crate::lower::model::Ex::XSelf => true,
        crate::lower::model::Ex::XRef(y_p3) => is_place_ex(&**y_p3),
        crate::lower::model::Ex::XDeref(y_p4) => is_place_ex(&**y_p4),
        _ => false,
    }
}

/// ```prism
/// GuardTest: unbounded fn Cp, [Cc] -> Text
/// ```
pub fn guard_test(cp_p0: &crate::emit::cpp::Cp, xs1: &Array<crate::lower::model::Cc>) -> Text {
    match xs1 {
        c0_1 if (c0_1.len() == 0) => Text::lit("true"),
        cs_p2 => {
            let first_p3 = or(&index(cs_p2, &Nat::from(0u32)), &crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XUnit));
            let rest_p4 = guard_test(cp_p0, &drop(cs_p2, &Nat::from(1u32)));
            match &first_p3 {
                crate::lower::model::Cc::CcIf(x_p5) => if &len(cs_p2) == &Nat::from(1u32) {
                    crate::emit::cpp::expr::cpp_tight(cp_p0, x_p5)
                } else {
                    Text::from(format!("{} && {}", &crate::emit::cpp::expr::cpp_tight(cp_p0, x_p5), &rest_p4))
                },
                crate::lower::model::Cc::CcLet(p_p6, x_p7) => {
                    let (v_pa, pre_pb) = cond_subject(cp_p0, x_p7, &len(cs_p2));
                    let tests_p8 = conds(&pat_conds(cp_p0, p_p6, &v_pa));
                    let whole_p9 = if &len(cs_p2) == &Nat::from(1u32) {
                        tests_p8.clone()
                    } else {
                        Text::from(format!("{} && {}", &tests_p8, &crate::emit::cpp::templates::items::stmt_expr(&crate::syntax::lexer::chars::join(&pat_binds(cp_p0, p_p6, &v_pa), &Text::lit("\n")), &rest_p4)))
                    };
                    if &len(&pre_pb) == &Nat::from(0u32) {
                        whole_p9.clone()
                    } else {
                        crate::emit::cpp::templates::items::stmt_expr(&crate::syntax::lexer::chars::join(&pre_pb, &Text::lit("\n")), &whole_p9)
                    }
                },
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `GuardTest`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GuardTest: unbounded fn Cp, [Cc] -> Text
/// ```
pub struct GuardTest {
    pub cp_p0: crate::emit::cpp::Cp,
    pub xs1: Array<crate::lower::model::Cc>,
}

impl prism_rtl::Job<Text> for GuardTest {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let xs1 = &self.xs1;
        match xs1 {
            j0_1 if (j0_1.len() == 0) => prism_rtl::Turn::Finished(Text::lit("true")),
            cs_p2 => {
                let first_p3 = or(&index(cs_p2, &Nat::from(0u32)), &crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XUnit));
                let cp_p0 = cp_p0.clone();
                let cs_p2 = cs_p2.clone();
                call_then(start_guard_test(cp_p0.clone(), drop(&cs_p2, &Nat::from(1u32))), move |guard_test_8837: Text| {
                    let rest_p4 = guard_test_8837;
                    match &first_p3 {
                        crate::lower::model::Cc::CcIf(x_p5) => if &len(&cs_p2) == &Nat::from(1u32) {
                            prism_rtl::Turn::More(Rc::new(crate::emit::cpp::expr::CppTight { cp_p0: cp_p0.clone(), x_p1: x_p5.clone() }))
                        } else {
                            {
                                let x_p5 = x_p5.clone();
                                call_then(crate::emit::cpp::expr::start_cpp_tight(cp_p0.clone(), x_p5.clone()), move |cpp_tight_8938: Text| prism_rtl::Turn::Finished(Text::from(format!("{} && {}", &cpp_tight_8938, &rest_p4))))
                            }
                        },
                        crate::lower::model::Cc::CcLet(p_p6, x_p7) => {
                            let p_p6 = p_p6.clone();
                            let x_p7 = x_p7.clone();
                            call_then(start_cond_subject(cp_p0.clone(), x_p7.clone(), len(&cs_p2)), move |cond_subject_9014: (Text, Array<Text>)| {
                                let (v_pa, pre_pb) = cond_subject_9014;
                                call_then(start_pat_conds(cp_p0.clone(), p_p6.clone(), v_pa.clone()), move |pat_conds_9073: Array<Text>| {
                                    let tests_p8 = conds(&pat_conds_9073);
                                    let whole_p9 = if &len(&cs_p2) == &Nat::from(1u32) {
                                        tests_p8.clone()
                                    } else {
                                        Text::from(format!("{} && {}", &tests_p8, &crate::emit::cpp::templates::items::stmt_expr(&crate::syntax::lexer::chars::join(&pat_binds(&cp_p0, &p_p6, &v_pa), &Text::lit("\n")), &rest_p4)))
                                    };
                                    if &len(&pre_pb) == &Nat::from(0u32) {
                                        prism_rtl::Turn::Finished(whole_p9.clone())
                                    } else {
                                        prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::stmt_expr(&crate::syntax::lexer::chars::join(&pre_pb, &Text::lit("\n")), &whole_p9))
                                    }
                                })
                            })
                        },
                    }
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start GuardTest, x`: what the function value is when passed to `@Run`.
pub fn start_guard_test(cp_p0: crate::emit::cpp::Cp, xs1: Array<crate::lower::model::Cc>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(GuardTest { cp_p0, xs1 })
}

/// ```prism
/// MatchArm: unbounded fn Cp, Text, XArm, Bool -> Text
/// ```
pub fn match_arm(cp0_p0: &crate::emit::cpp::Cp, subject_p1: &Text, a_p2: &crate::lower::model::XArm, returns_p3: &bool) -> Text {
    let cp_p4 = crate::emit::cpp::stmts::unbind(cp0_p0, &crate::emit::cpp::stmts::arm_names(a_p2));
    let tests_p5 = pat_conds(&cp_p4, &a_p2.pat, subject_p1);
    let binds_p6 = pat_binds(&cp_p4, &a_p2.pat, subject_p1);
    let body_p7 = if *returns_p3 {
        crate::emit::cpp::stmts::cpp_body(&cp_p4, &a_p2.body)
    } else {
        if leaves(&a_p2.body) {
            Text::from(format!("{};", &crate::emit::cpp::expr::cpp_expr(&cp_p4, &a_p2.body)))
        } else {
            Text::from(format!("_v.set({});\ngoto _done;", &crate::emit::cpp::expr::cpp_expr(&cp_p4, &a_p2.body)))
        }
    };
    let guarded_p8 = if &len(&a_p2.conds) == &Nat::from(0u32) {
        body_p7.clone()
    } else {
        guarded_arm(&cp_p4, &a_p2.conds, &body_p7)
    };
    let inner_p9 = crate::syntax::lexer::chars::join(&append(&binds_p6, &Array::from(vec![guarded_p8.clone()])), &Text::lit("\n"));
    if &len(&tests_p5) == &Nat::from(0u32) {
        crate::emit::cpp::templates::items::braced(&inner_p9)
    } else {
        crate::emit::cpp::templates::items::if_block(&conds(&tests_p5), &inner_p9)
    }
}

/// The step machine of `MatchArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MatchArm: unbounded fn Cp, Text, XArm, Bool -> Text
/// ```
pub struct MatchArm {
    pub cp0_p0: crate::emit::cpp::Cp,
    pub subject_p1: Text,
    pub a_p2: crate::lower::model::XArm,
    pub returns_p3: bool,
}

impl prism_rtl::Job<Text> for MatchArm {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp0_p0 = &self.cp0_p0;
        let subject_p1 = &self.subject_p1;
        let a_p2 = &self.a_p2;
        let returns_p3 = &self.returns_p3;
        let a_p2 = a_p2.clone();
        let cp0_p0 = cp0_p0.clone();
        let returns_p3 = *returns_p3;
        let subject_p1 = subject_p1.clone();
        call_then(crate::emit::cpp::stmts::start_arm_names(a_p2.clone()), move |arm_names_9531: Array<Text>| {
            let cp_p4 = crate::emit::cpp::stmts::unbind(&cp0_p0, &arm_names_9531);
            call_then(start_pat_conds(cp_p4.clone(), a_p2.pat.clone(), subject_p1.clone()), move |pat_conds_9559: Array<Text>| {
                let tests_p5 = pat_conds_9559;
                call_then(start_pat_binds(cp_p4.clone(), a_p2.pat.clone(), subject_p1.clone()), move |pat_binds_9603: Array<Text>| {
                    let binds_p6 = pat_binds_9603;
                    let body_p7 = if returns_p3 {
                        crate::emit::cpp::stmts::cpp_body(&cp_p4, &a_p2.body)
                    } else {
                        if leaves(&a_p2.body) {
                            Text::from(format!("{};", &crate::emit::cpp::expr::cpp_expr(&cp_p4, &a_p2.body)))
                        } else {
                            Text::from(format!("_v.set({});\ngoto _done;", &crate::emit::cpp::expr::cpp_expr(&cp_p4, &a_p2.body)))
                        }
                    };
                    let guarded_p8 = if &len(&a_p2.conds) == &Nat::from(0u32) {
                        body_p7.clone()
                    } else {
                        guarded_arm(&cp_p4, &a_p2.conds, &body_p7)
                    };
                    let inner_p9 = crate::syntax::lexer::chars::join(&append(&binds_p6, &Array::from(vec![guarded_p8.clone()])), &Text::lit("\n"));
                    if &len(&tests_p5) == &Nat::from(0u32) {
                        prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::braced(&inner_p9))
                    } else {
                        prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::if_block(&conds(&tests_p5), &inner_p9))
                    }
                })
            })
        })
    }
}

/// `Start MatchArm, x`: what the function value is when passed to `@Run`.
pub fn start_match_arm(cp0_p0: crate::emit::cpp::Cp, subject_p1: Text, a_p2: crate::lower::model::XArm, returns_p3: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(MatchArm { cp0_p0, subject_p1, a_p2, returns_p3 })
}

/// ```prism
/// GuardedArm: unbounded fn Cp, [Cc], Text -> Text
/// ```
pub fn guarded_arm(cp_p0: &crate::emit::cpp::Cp, xs1: &Array<crate::lower::model::Cc>, body_p1: &Text) -> Text {
    match xs1 {
        c0_1 if (c0_1.len() == 0) => body_p1.clone(),
        cs_p3 => {
            let first_p5 = or(&index(cs_p3, &Nat::from(0u32)), &crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XUnit));
            let rest_p6 = guarded_arm(cp_p0, &drop(cs_p3, &Nat::from(1u32)), body_p1);
            match &first_p5 {
                crate::lower::model::Cc::CcIf(x_p7) => crate::emit::cpp::templates::items::if_block(&crate::emit::cpp::expr::cpp_expr(cp_p0, x_p7), &rest_p6),
                crate::lower::model::Cc::CcLet(p_p8, x_p9) => {
                    let (v_pb, pre_pc) = cond_subject(cp_p0, x_p9, &len(cs_p3));
                    let inner_pa = crate::emit::cpp::templates::items::if_block(&conds(&pat_conds(cp_p0, p_p8, &v_pb)), &crate::syntax::lexer::chars::join(&append(&pat_binds(cp_p0, p_p8, &v_pb), &Array::from(vec![rest_p6.clone()])), &Text::lit("\n")));
                    if &len(&pre_pc) == &Nat::from(0u32) {
                        inner_pa.clone()
                    } else {
                        crate::emit::cpp::templates::items::braced(&crate::syntax::lexer::chars::join(&push(&pre_pc, &inner_pa), &Text::lit("\n")))
                    }
                },
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `GuardedArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GuardedArm: unbounded fn Cp, [Cc], Text -> Text
/// ```
pub struct GuardedArm {
    pub cp_p0: crate::emit::cpp::Cp,
    pub xs1: Array<crate::lower::model::Cc>,
    pub body_p1: Text,
}

impl prism_rtl::Job<Text> for GuardedArm {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let xs1 = &self.xs1;
        let body_p1 = &self.body_p1;
        match xs1 {
            j0_1 if (j0_1.len() == 0) => prism_rtl::Turn::Finished(body_p1.clone()),
            cs_p3 => {
                let first_p5 = or(&index(cs_p3, &Nat::from(0u32)), &crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XUnit));
                let body_p1 = body_p1.clone();
                let cp_p0 = cp_p0.clone();
                let cs_p3 = cs_p3.clone();
                call_then(start_guarded_arm(cp_p0.clone(), drop(&cs_p3, &Nat::from(1u32)), body_p1.clone()), move |guarded_arm_10240: Text| {
                    let rest_p6 = guarded_arm_10240;
                    match &first_p5 {
                        crate::lower::model::Cc::CcIf(x_p7) => {
                            let x_p7 = x_p7.clone();
                            call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), x_p7.clone()), move |cpp_expr_10316: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::if_block(&cpp_expr_10316, &rest_p6)))
                        },
                        crate::lower::model::Cc::CcLet(p_p8, x_p9) => {
                            let p_p8 = p_p8.clone();
                            let x_p9 = x_p9.clone();
                            call_then(start_cond_subject(cp_p0.clone(), x_p9.clone(), len(&cs_p3)), move |cond_subject_10386: (Text, Array<Text>)| {
                                let (v_pb, pre_pc) = cond_subject_10386;
                                call_then(start_pat_conds(cp_p0.clone(), p_p8.clone(), v_pb.clone()), move |pat_conds_10454: Array<Text>| call_then(start_pat_binds(cp_p0.clone(), p_p8.clone(), v_pb.clone()), move |pat_binds_10490: Array<Text>| {
                                    let inner_pa = crate::emit::cpp::templates::items::if_block(&conds(&pat_conds_10454), &crate::syntax::lexer::chars::join(&append(&pat_binds_10490, &Array::from(vec![rest_p6.clone()])), &Text::lit("\n")));
                                    if &len(&pre_pc) == &Nat::from(0u32) {
                                        prism_rtl::Turn::Finished(inner_pa.clone())
                                    } else {
                                        prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::braced(&crate::syntax::lexer::chars::join(&push(&pre_pc, &inner_pa), &Text::lit("\n"))))
                                    }
                                }))
                            })
                        },
                    }
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start GuardedArm, x`: what the function value is when passed to `@Run`.
pub fn start_guarded_arm(cp_p0: crate::emit::cpp::Cp, xs1: Array<crate::lower::model::Cc>, body_p1: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(GuardedArm { cp_p0, xs1, body_p1 })
}

/// ```prism
/// CppLabeled: unbounded fn Cp, Text, [Do], Ex, OutTy -> Text
/// ```
pub fn cpp_labeled(cp_p0: &crate::emit::cpp::Cp, label_p1: &Text, dos_p2: &Array<crate::lower::model::Do>, e_p3: &crate::lower::model::Ex, t_p4: &crate::lower::model::OutTy) -> Text {
    let l_p5 = cpp_label(label_p1);
    let last_p6 = if leaves(e_p3) {
        Text::from(format!("{};", &crate::emit::cpp::expr::cpp_expr(cp_p0, e_p3)))
    } else {
        Text::from(format!("{}_v.set({});", &l_p5, &crate::emit::cpp::expr::cpp_expr(cp_p0, e_p3)))
    };
    crate::emit::cpp::templates::items::labeled_expr(&l_p5, &crate::emit::cpp::cpp_type(cp_p0, t_p4), &crate::syntax::lexer::chars::join(&push(&run_to_end(each_job(dos_p2.clone(), {
        let cp_p0 = cp_p0.clone();
        Rc::new(move |p0: crate::lower::model::Do| {
            let cp_p0 = cp_p0.clone();
            entered(once_job(move || {
                let d_p7 = p0;
                prism_rtl::Turn::More(Rc::new(crate::emit::cpp::stmts::CppStatement { cp_p0: cp_p0.clone(), d_p1: d_p7.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &last_p6), &Text::lit("\n")))
}

/// The step machine of `CppLabeled`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppLabeled: unbounded fn Cp, Text, [Do], Ex, OutTy -> Text
/// ```
pub struct CppLabeled {
    pub cp_p0: crate::emit::cpp::Cp,
    pub label_p1: Text,
    pub dos_p2: Array<crate::lower::model::Do>,
    pub e_p3: crate::lower::model::Ex,
    pub t_p4: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for CppLabeled {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let label_p1 = &self.label_p1;
        let dos_p2 = &self.dos_p2;
        let e_p3 = &self.e_p3;
        let t_p4 = &self.t_p4;
        let l_p5 = cpp_label(label_p1);
        let last_p6 = if leaves(e_p3) {
            Text::from(format!("{};", &crate::emit::cpp::expr::cpp_expr(cp_p0, e_p3)))
        } else {
            Text::from(format!("{}_v.set({});", &l_p5, &crate::emit::cpp::expr::cpp_expr(cp_p0, e_p3)))
        };
        let cp_p0 = cp_p0.clone();
        let dos_p2 = dos_p2.clone();
        let t_p4 = t_p4.clone();
        call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), t_p4.clone()), move |cpp_type_10916: Text| call_value(each_job(dos_p2.clone(), {
            let cp_p0 = cp_p0.clone();
            Rc::new(move |p0: crate::lower::model::Do| {
                let cp_p0 = cp_p0.clone();
                entered(once_job(move || {
                    let d_p7 = p0;
                    prism_rtl::Turn::More(Rc::new(crate::emit::cpp::stmts::CppStatement { cp_p0: cp_p0.clone(), d_p1: d_p7.clone() }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_10945: Array<Text>| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::labeled_expr(&l_p5, &cpp_type_10916, &crate::syntax::lexer::chars::join(&push(&each_10945, &last_p6), &Text::lit("\n"))))))
    }
}

/// `Start CppLabeled, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_labeled(cp_p0: crate::emit::cpp::Cp, label_p1: Text, dos_p2: Array<crate::lower::model::Do>, e_p3: crate::lower::model::Ex, t_p4: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppLabeled { cp_p0, label_p1, dos_p2, e_p3, t_p4 })
}

/// ```prism
/// CppLabel: fn Text -> Text
/// ```
pub fn cpp_label(l_p0: &Text) -> Text {
    if crate::syntax::lexer::chars::has_prefix(l_p0, &Text::lit("\'")) {
        crate::syntax::lexer::chars::after_first(l_p0)
    } else {
        l_p0.clone()
    }
}

/// ```prism
/// CppBreak: unbounded fn Cp, Text, Ex -> Text
/// ```
pub fn cpp_break(cp_p0: &crate::emit::cpp::Cp, l_p1: &Text, y_p2: &crate::lower::model::Ex) -> Text {
    let n_p3 = cpp_label(l_p1);
    Text::from(format!("{{ {}_v.set({}); goto {}; }}", &n_p3, &crate::emit::cpp::expr::cpp_expr(cp_p0, y_p2), &n_p3))
}

/// The step machine of `CppBreak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppBreak: unbounded fn Cp, Text, Ex -> Text
/// ```
pub struct CppBreak {
    pub cp_p0: crate::emit::cpp::Cp,
    pub l_p1: Text,
    pub y_p2: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppBreak {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let l_p1 = &self.l_p1;
        let y_p2 = &self.y_p2;
        let n_p3 = cpp_label(l_p1);
        let cp_p0 = cp_p0.clone();
        let y_p2 = y_p2.clone();
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), y_p2.clone()), move |cpp_expr_11190: Text| prism_rtl::Turn::Finished(Text::from(format!("{{ {}_v.set({}); goto {}; }}", &n_p3, &cpp_expr_11190, &n_p3))))
    }
}

/// `Start CppBreak, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_break(cp_p0: crate::emit::cpp::Cp, l_p1: Text, y_p2: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppBreak { cp_p0, l_p1, y_p2 })
}
