//! The module `Emit.Cpp.Patterns`, from `target/bootstrap/src/prismc/emit/cpp/patterns.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// PatConds: unbounded fn Cp, Pa, Text -> [Text]
/// ```
pub fn pat_conds_f(cp_p0: &crate::emit::cpp::Cp, p_p1: &crate::lower::model::Pa, v_p2: &crate::prelude::Text) -> crate::prelude::Array<crate::prelude::Text> {
    match p_p1 {
        crate::lower::model::Pa::PaWild => crate::prelude::Array::new(),
        crate::lower::model::Pa::PaBind(_) => crate::prelude::Array::new(),
        crate::lower::model::Pa::PaMut(_) => crate::prelude::Array::new(),
        crate::lower::model::Pa::PaTyped(q_p3, _) => pat_conds_f(cp_p0, &**q_p3, v_p2),
        crate::lower::model::Pa::PaUnit(c_p4) => crate::prelude::Array::from(vec![crate::emit::cpp::expr::case_test_f(cp_p0, c_p4, v_p2)]),
        crate::lower::model::Pa::PaCtor(c_p5, ps_p6) => {
            let own_p7 = crate::emit::cpp::expr::case_test_f(cp_p0, c_p5, v_p2);
            let inner_p8 = concat2_f(&crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(ps_p6)), {
                let cp_p0x = cp_p0.clone();
                let ps_p6x = ps_p6.clone();
                let c_p5x = c_p5.clone();
                let v_p2x = v_p2.clone();
                ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                    let cp_p0xy = cp_p0x.clone();
                    let ps_p6xy = ps_p6x.clone();
                    let c_p5xy = c_p5x.clone();
                    let v_p2xy = v_p2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let i_p9 = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(PatConds { cp_p0: cp_p0xy.clone(), p_p1: crate::prelude::or(&crate::prelude::index(&ps_p6xy, &i_p9), &crate::lower::model::Pa::PaWild), v_p2: crate::emit::cpp::expr::payload_f(&cp_p0xy, &c_p5xy, &v_p2xy, &i_p9) }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
            })));
            crate::prelude::filter(&crate::prelude::append(&crate::prelude::Array::from(vec![own_p7.clone()]), &inner_p8), &(|t_pa: &crate::prelude::Text| t_pa != &crate::prelude::Text::lit("true")))
        },
        crate::lower::model::Pa::PaRecord(c_pb, fs_pc, _) => concat2_f(&crate::prelude::run_to_end(crate::prelude::each_job(fs_pc.clone(), {
            let cp_p0x = cp_p0.clone();
            let v_p2x = v_p2.clone();
            ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::Pa)| {
                let cp_p0xy = cp_p0x.clone();
                let v_p2xy = v_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (f_pd, q_pe) = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(PatConds { cp_p0: cp_p0xy.clone(), p_p1: q_pe.clone(), v_p2: crate::prelude::Text::from(format!("{}.{}", &v_p2xy, &crate::emit::cpp::field_id_f(&f_pd))) }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::Pa)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
        }))),
        crate::lower::model::Pa::PaTuple(ps_pf) => concat2_f(&crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(ps_pf)), {
            let cp_p0x = cp_p0.clone();
            let ps_pfx = ps_pf.clone();
            let v_p2x = v_p2.clone();
            ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                let cp_p0xy = cp_p0x.clone();
                let ps_pfxy = ps_pfx.clone();
                let v_p2xy = v_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let i_pg = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(PatConds { cp_p0: cp_p0xy.clone(), p_p1: crate::prelude::or(&crate::prelude::index(&ps_pfxy, &i_pg), &crate::lower::model::Pa::PaWild), v_p2: crate::prelude::Text::from(format!("::std::get<{}>({})", &i_pg, &v_p2xy)) }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
        }))),
        crate::lower::model::Pa::PaChar(c_ph) => crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("{} == U\'{}\'", v_p2, &crate::emit::cpp::expr::cpp_char_escape_f(c_ph)))]),
        crate::lower::model::Pa::PaBool(b_pi) => crate::prelude::Array::from(vec![if *b_pi { v_p2.clone() } else { crate::prelude::Text::from(format!("!{}", v_p2)) }]),
        crate::lower::model::Pa::PaIndex(n_pj) => crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("{} == {}u", v_p2, n_pj))]),
        crate::lower::model::Pa::PaConst(n_pk) => crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("{} == {}", v_p2, n_pk))]),
        crate::lower::model::Pa::PaSlice(ps_pl) => {
            let rest_pm = crate::prelude::fold(ps_pl, &false, &(|f_pp: &bool, q_pq: &crate::lower::model::Pa| *f_pp || is_rest_f(q_pq)));
            let fixed_pn = crate::prelude::len(&crate::prelude::filter(ps_pl, &(|q_pr: &crate::lower::model::Pa| !is_rest_f(q_pr))));
            let size_po = if rest_pm {
                crate::prelude::Text::from(format!("{}.size() >= {}", v_p2, &fixed_pn))
            } else {
                crate::prelude::Text::from(format!("{}.size() == {}", v_p2, &fixed_pn))
            };
            crate::prelude::append(&crate::prelude::Array::from(vec![size_po.clone()]), &concat2_f(&crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(ps_pl)), {
                let cp_p0x = cp_p0.clone();
                let ps_plx = ps_pl.clone();
                let v_p2x = v_p2.clone();
                ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                    let cp_p0xy = cp_p0x.clone();
                    let ps_plxy = ps_plx.clone();
                    let v_p2xy = v_p2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let i_ps = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(PatConds { cp_p0: cp_p0xy.clone(), p_p1: crate::prelude::or(&crate::prelude::index(&ps_plxy, &i_ps), &crate::lower::model::Pa::PaWild), v_p2: crate::prelude::Text::from(format!("{}[{}]", &v_p2xy, &i_ps)) }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
            }))))
        },
        crate::lower::model::Pa::PaRest(_) => crate::prelude::Array::new(),
    }
}

/// The step machine of `PatConds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatConds: unbounded fn Cp, Pa, Text -> [Text]
/// ```
pub struct PatConds {
    pub cp_p0: crate::emit::cpp::Cp,
    pub p_p1: crate::lower::model::Pa,
    pub v_p2: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for PatConds {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let cp_p0 = &self.cp_p0;
        let p_p1 = &self.p_p1;
        let v_p2 = &self.v_p2;
        match p_p1 {
            crate::lower::model::Pa::PaWild => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
            crate::lower::model::Pa::PaBind(_) => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
            crate::lower::model::Pa::PaMut(_) => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
            crate::lower::model::Pa::PaTyped(q_p3, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(PatConds { cp_p0: cp_p0.clone(), p_p1: (**q_p3).clone(), v_p2: v_p2.clone() })),
            crate::lower::model::Pa::PaUnit(c_p4) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::emit::cpp::expr::case_test_f(cp_p0, c_p4, v_p2)])),
            crate::lower::model::Pa::PaCtor(c_p5, ps_p6) => {
                let own_p7 = crate::emit::cpp::expr::case_test_f(cp_p0, c_p5, v_p2);
                let c_p5x = c_p5.clone();
                let cp_p0x = cp_p0.clone();
                let ps_p6x = ps_p6.clone();
                let v_p2x = v_p2.clone();
                crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&ps_p6x)), {
                    let cp_p0xx = cp_p0x.clone();
                    let ps_p6xx = ps_p6x.clone();
                    let c_p5xx = c_p5x.clone();
                    let v_p2xx = v_p2x.clone();
                    ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                        let cp_p0xxy = cp_p0xx.clone();
                        let ps_p6xxy = ps_p6xx.clone();
                        let c_p5xxy = c_p5xx.clone();
                        let v_p2xxy = v_p2xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let i_p9 = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(PatConds { cp_p0: cp_p0xxy.clone(), p_p1: crate::prelude::or(&crate::prelude::index(&ps_p6xxy, &i_p9), &crate::lower::model::Pa::PaWild), v_p2: crate::emit::cpp::expr::payload_f(&cp_p0xxy, &c_p5xxy, &v_p2xxy, &i_p9) }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                }), move |each_1488: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| {
                    let inner_p8 = concat2_f(&each_1488);
                    ::prism_rtl::Turn::Finished(crate::prelude::filter(&crate::prelude::append(&crate::prelude::Array::from(vec![own_p7.clone()]), &inner_p8), &(|t_pa: &crate::prelude::Text| t_pa != &crate::prelude::Text::lit("true"))))
                })
            },
            crate::lower::model::Pa::PaRecord(c_pb, fs_pc, _) => {
                let cp_p0x = cp_p0.clone();
                let fs_pcx = fs_pc.clone();
                let v_p2x = v_p2.clone();
                crate::prelude::call_value(crate::prelude::each_job(fs_pcx.clone(), {
                    let cp_p0xx = cp_p0x.clone();
                    let v_p2xx = v_p2x.clone();
                    ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::Pa)| {
                        let cp_p0xxy = cp_p0xx.clone();
                        let v_p2xxy = v_p2xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (f_pd, q_pe) = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(PatConds { cp_p0: cp_p0xxy.clone(), p_p1: q_pe.clone(), v_p2: crate::prelude::Text::from(format!("{}.{}", &v_p2xxy, &crate::emit::cpp::field_id_f(&f_pd))) }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::Pa)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                }), move |each_1667: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| ::prism_rtl::Turn::Finished(concat2_f(&each_1667)))
            },
            crate::lower::model::Pa::PaTuple(ps_pf) => {
                let cp_p0x = cp_p0.clone();
                let ps_pfx = ps_pf.clone();
                let v_p2x = v_p2.clone();
                crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&ps_pfx)), {
                    let cp_p0xx = cp_p0x.clone();
                    let ps_pfxx = ps_pfx.clone();
                    let v_p2xx = v_p2x.clone();
                    ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                        let cp_p0xxy = cp_p0xx.clone();
                        let ps_pfxxy = ps_pfxx.clone();
                        let v_p2xxy = v_p2xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let i_pg = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(PatConds { cp_p0: cp_p0xxy.clone(), p_p1: crate::prelude::or(&crate::prelude::index(&ps_pfxxy, &i_pg), &crate::lower::model::Pa::PaWild), v_p2: crate::prelude::Text::from(format!("::std::get<{}>({})", &i_pg, &v_p2xxy)) }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                }), move |each_1748: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| ::prism_rtl::Turn::Finished(concat2_f(&each_1748)))
            },
            crate::lower::model::Pa::PaChar(c_ph) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("{} == U\'{}\'", v_p2, &crate::emit::cpp::expr::cpp_char_escape_f(c_ph)))])),
            crate::lower::model::Pa::PaBool(b_pi) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![if *b_pi { v_p2.clone() } else { crate::prelude::Text::from(format!("!{}", v_p2)) }])),
            crate::lower::model::Pa::PaIndex(n_pj) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("{} == {}u", v_p2, n_pj))])),
            crate::lower::model::Pa::PaConst(n_pk) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("{} == {}", v_p2, n_pk))])),
            crate::lower::model::Pa::PaSlice(ps_pl) => {
                let rest_pm = crate::prelude::fold(ps_pl, &false, &(|f_pp: &bool, q_pq: &crate::lower::model::Pa| *f_pp || is_rest_f(q_pq)));
                let fixed_pn = crate::prelude::len(&crate::prelude::filter(ps_pl, &(|q_pr: &crate::lower::model::Pa| !is_rest_f(q_pr))));
                let size_po = if rest_pm {
                    crate::prelude::Text::from(format!("{}.size() >= {}", v_p2, &fixed_pn))
                } else {
                    crate::prelude::Text::from(format!("{}.size() == {}", v_p2, &fixed_pn))
                };
                let cp_p0x = cp_p0.clone();
                let ps_plx = ps_pl.clone();
                let v_p2x = v_p2.clone();
                crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&ps_plx)), {
                    let cp_p0xx = cp_p0x.clone();
                    let ps_plxx = ps_plx.clone();
                    let v_p2xx = v_p2x.clone();
                    ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                        let cp_p0xxy = cp_p0xx.clone();
                        let ps_plxxy = ps_plxx.clone();
                        let v_p2xxy = v_p2xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let i_ps = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(PatConds { cp_p0: cp_p0xxy.clone(), p_p1: crate::prelude::or(&crate::prelude::index(&ps_plxxy, &i_ps), &crate::lower::model::Pa::PaWild), v_p2: crate::prelude::Text::from(format!("{}[{}]", &v_p2xxy, &i_ps)) }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                }), move |each_2233: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| ::prism_rtl::Turn::Finished(crate::prelude::append(&crate::prelude::Array::from(vec![size_po.clone()]), &concat2_f(&each_2233))))
            },
            crate::lower::model::Pa::PaRest(_) => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start PatConds, x`: what the function value is when passed to `@Run`.
pub fn start_pat_conds_f(cp_p0: crate::emit::cpp::Cp, p_p1: crate::lower::model::Pa, v_p2: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(PatConds { cp_p0, p_p1, v_p2 })
}

/// ```prism
/// PatBinds: unbounded fn Cp, Pa, Text -> [Text]
/// ```
pub fn pat_binds_f(cp_p0: &crate::emit::cpp::Cp, p_p1: &crate::lower::model::Pa, v_p2: &crate::prelude::Text) -> crate::prelude::Array<crate::prelude::Text> {
    'm2402: {
        if let crate::lower::model::Pa::PaWild = p_p1 {
            break 'm2402 crate::prelude::Array::new();
        }
        if let crate::lower::model::Pa::PaBind(n_p3) = p_p1 {
            break 'm2402 crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("auto&& {} = {};", &crate::emit::cpp::cpp_id_f(n_p3), v_p2))]);
        }
        if let crate::lower::model::Pa::PaMut(n_p4) = p_p1 {
            break 'm2402 crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("auto {} = {};", &crate::emit::cpp::cpp_id_f(n_p4), v_p2))]);
        }
        if let crate::lower::model::Pa::PaTyped(m2402_3_0, t_p6) = p_p1 && let crate::lower::model::Pa::PaBind(n_p5) = &**m2402_3_0 {
            break 'm2402 crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("{} {} = {};", &crate::emit::cpp::cpp_type_f(cp_p0, &crate::emit::cpp::expr::unref_f(t_p6)), &crate::emit::cpp::cpp_id_f(n_p5), v_p2))]);
        }
        if let crate::lower::model::Pa::PaTyped(q_p7, _) = p_p1 {
            break 'm2402 pat_binds_f(cp_p0, &**q_p7, v_p2);
        }
        if let crate::lower::model::Pa::PaUnit(_) = p_p1 {
            break 'm2402 crate::prelude::Array::new();
        }
        if let crate::lower::model::Pa::PaCtor(c_p8, ps_p9) = p_p1 {
            break 'm2402 concat2_f(&crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(ps_p9)), {
                let cp_p0x = cp_p0.clone();
                let ps_p9x = ps_p9.clone();
                let c_p8x = c_p8.clone();
                let v_p2x = v_p2.clone();
                ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                    let cp_p0xy = cp_p0x.clone();
                    let ps_p9xy = ps_p9x.clone();
                    let c_p8xy = c_p8x.clone();
                    let v_p2xy = v_p2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let i_pa = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(PatBinds { cp_p0: cp_p0xy.clone(), p_p1: crate::prelude::or(&crate::prelude::index(&ps_p9xy, &i_pa), &crate::lower::model::Pa::PaWild), v_p2: crate::emit::cpp::expr::payload_f(&cp_p0xy, &c_p8xy, &v_p2xy, &i_pa) }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
            })));
        }
        if let crate::lower::model::Pa::PaRecord(c_pb, fs_pc, _) = p_p1 {
            break 'm2402 concat2_f(&crate::prelude::run_to_end(crate::prelude::each_job(fs_pc.clone(), {
                let cp_p0x = cp_p0.clone();
                let v_p2x = v_p2.clone();
                ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::Pa)| {
                    let cp_p0xy = cp_p0x.clone();
                    let v_p2xy = v_p2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (f_pd, q_pe) = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(PatBinds { cp_p0: cp_p0xy.clone(), p_p1: q_pe.clone(), v_p2: crate::prelude::Text::from(format!("{}.{}", &v_p2xy, &crate::emit::cpp::field_id_f(&f_pd))) }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::Pa)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
            })));
        }
        if let crate::lower::model::Pa::PaTuple(ps_pf) = p_p1 {
            break 'm2402 concat2_f(&crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(ps_pf)), {
                let cp_p0x = cp_p0.clone();
                let ps_pfx = ps_pf.clone();
                let v_p2x = v_p2.clone();
                ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                    let cp_p0xy = cp_p0x.clone();
                    let ps_pfxy = ps_pfx.clone();
                    let v_p2xy = v_p2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let i_pg = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(PatBinds { cp_p0: cp_p0xy.clone(), p_p1: crate::prelude::or(&crate::prelude::index(&ps_pfxy, &i_pg), &crate::lower::model::Pa::PaWild), v_p2: crate::prelude::Text::from(format!("::std::get<{}>({})", &i_pg, &v_p2xy)) }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
            })));
        }
        if let crate::lower::model::Pa::PaSlice(ps_ph) = p_p1 {
            break 'm2402 concat2_f(&crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(ps_ph)), {
                let cp_p0x = cp_p0.clone();
                let ps_phx = ps_ph.clone();
                let v_p2x = v_p2.clone();
                ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                    let cp_p0xy = cp_p0x.clone();
                    let ps_phxy = ps_phx.clone();
                    let v_p2xy = v_p2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let i_pi = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(SliceBinds { cp_p0: cp_p0xy.clone(), pa1: crate::prelude::or(&crate::prelude::index(&ps_phxy, &i_pi), &crate::lower::model::Pa::PaWild), v_p1: v_p2xy.clone(), i_p2: i_pi.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
            })));
        }
        crate::prelude::Array::new()
    }
}

/// The step machine of `PatBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatBinds: unbounded fn Cp, Pa, Text -> [Text]
/// ```
pub struct PatBinds {
    pub cp_p0: crate::emit::cpp::Cp,
    pub p_p1: crate::lower::model::Pa,
    pub v_p2: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for PatBinds {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let cp_p0 = &self.cp_p0;
        let p_p1 = &self.p_p1;
        let v_p2 = &self.v_p2;
        'm2402: {
            if let crate::lower::model::Pa::PaWild = p_p1 {
                break 'm2402 ::prism_rtl::Turn::Finished(crate::prelude::Array::new());
            }
            if let crate::lower::model::Pa::PaBind(n_p3) = p_p1 {
                break 'm2402 ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("auto&& {} = {};", &crate::emit::cpp::cpp_id_f(n_p3), v_p2))]));
            }
            if let crate::lower::model::Pa::PaMut(n_p4) = p_p1 {
                break 'm2402 ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("auto {} = {};", &crate::emit::cpp::cpp_id_f(n_p4), v_p2))]));
            }
            if let crate::lower::model::Pa::PaTyped(m2402_3_0, t_p6) = p_p1 && let crate::lower::model::Pa::PaBind(n_p5) = &**m2402_3_0 {
                break 'm2402 {
                    let cp_p0x = cp_p0.clone();
                    let n_p5x = n_p5.clone();
                    let t_p6x = t_p6.clone();
                    let v_p2x = v_p2.clone();
                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), crate::emit::cpp::expr::unref_f(&t_p6x)), move |cpp_type_f_2544: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("{} {} = {};", &cpp_type_f_2544, &crate::emit::cpp::cpp_id_f(&n_p5x), &v_p2x))])))
                };
            }
            if let crate::lower::model::Pa::PaTyped(q_p7, _) = p_p1 {
                break 'm2402 ::prism_rtl::Turn::More(::std::rc::Rc::new(PatBinds { cp_p0: cp_p0.clone(), p_p1: (**q_p7).clone(), v_p2: v_p2.clone() }));
            }
            if let crate::lower::model::Pa::PaUnit(_) = p_p1 {
                break 'm2402 ::prism_rtl::Turn::Finished(crate::prelude::Array::new());
            }
            if let crate::lower::model::Pa::PaCtor(c_p8, ps_p9) = p_p1 {
                break 'm2402 {
                    let c_p8x = c_p8.clone();
                    let cp_p0x = cp_p0.clone();
                    let ps_p9x = ps_p9.clone();
                    let v_p2x = v_p2.clone();
                    crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&ps_p9x)), {
                        let cp_p0xx = cp_p0x.clone();
                        let ps_p9xx = ps_p9x.clone();
                        let c_p8xx = c_p8x.clone();
                        let v_p2xx = v_p2x.clone();
                        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                            let cp_p0xxy = cp_p0xx.clone();
                            let ps_p9xxy = ps_p9xx.clone();
                            let c_p8xxy = c_p8xx.clone();
                            let v_p2xxy = v_p2xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let i_pa = p0;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(PatBinds { cp_p0: cp_p0xxy.clone(), p_p1: crate::prelude::or(&crate::prelude::index(&ps_p9xxy, &i_pa), &crate::lower::model::Pa::PaWild), v_p2: crate::emit::cpp::expr::payload_f(&cp_p0xxy, &c_p8xxy, &v_p2xxy, &i_pa) }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                    }), move |each_2679: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| ::prism_rtl::Turn::Finished(concat2_f(&each_2679)))
                };
            }
            if let crate::lower::model::Pa::PaRecord(c_pb, fs_pc, _) = p_p1 {
                break 'm2402 {
                    let cp_p0x = cp_p0.clone();
                    let fs_pcx = fs_pc.clone();
                    let v_p2x = v_p2.clone();
                    crate::prelude::call_value(crate::prelude::each_job(fs_pcx.clone(), {
                        let cp_p0xx = cp_p0x.clone();
                        let v_p2xx = v_p2x.clone();
                        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::Pa)| {
                            let cp_p0xxy = cp_p0xx.clone();
                            let v_p2xxy = v_p2xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (f_pd, q_pe) = p0;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(PatBinds { cp_p0: cp_p0xxy.clone(), p_p1: q_pe.clone(), v_p2: crate::prelude::Text::from(format!("{}.{}", &v_p2xxy, &crate::emit::cpp::field_id_f(&f_pd))) }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::Pa)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                    }), move |each_2801: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| ::prism_rtl::Turn::Finished(concat2_f(&each_2801)))
                };
            }
            if let crate::lower::model::Pa::PaTuple(ps_pf) = p_p1 {
                break 'm2402 {
                    let cp_p0x = cp_p0.clone();
                    let ps_pfx = ps_pf.clone();
                    let v_p2x = v_p2.clone();
                    crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&ps_pfx)), {
                        let cp_p0xx = cp_p0x.clone();
                        let ps_pfxx = ps_pfx.clone();
                        let v_p2xx = v_p2x.clone();
                        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                            let cp_p0xxy = cp_p0xx.clone();
                            let ps_pfxxy = ps_pfxx.clone();
                            let v_p2xxy = v_p2xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let i_pg = p0;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(PatBinds { cp_p0: cp_p0xxy.clone(), p_p1: crate::prelude::or(&crate::prelude::index(&ps_pfxxy, &i_pg), &crate::lower::model::Pa::PaWild), v_p2: crate::prelude::Text::from(format!("::std::get<{}>({})", &i_pg, &v_p2xxy)) }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                    }), move |each_2882: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| ::prism_rtl::Turn::Finished(concat2_f(&each_2882)))
                };
            }
            if let crate::lower::model::Pa::PaSlice(ps_ph) = p_p1 {
                break 'm2402 {
                    let cp_p0x = cp_p0.clone();
                    let ps_phx = ps_ph.clone();
                    let v_p2x = v_p2.clone();
                    crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&ps_phx)), {
                        let cp_p0xx = cp_p0x.clone();
                        let ps_phxx = ps_phx.clone();
                        let v_p2xx = v_p2x.clone();
                        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                            let cp_p0xxy = cp_p0xx.clone();
                            let ps_phxxy = ps_phxx.clone();
                            let v_p2xxy = v_p2xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let i_pi = p0;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(SliceBinds { cp_p0: cp_p0xxy.clone(), pa1: crate::prelude::or(&crate::prelude::index(&ps_phxxy, &i_pi), &crate::lower::model::Pa::PaWild), v_p1: v_p2xxy.clone(), i_p2: i_pi.clone() }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                    }), move |each_2993: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| ::prism_rtl::Turn::Finished(concat2_f(&each_2993)))
                };
            }
            ::prism_rtl::Turn::Finished(crate::prelude::Array::new())
        }
    }
}

/// `Start PatBinds, x`: what the function value is when passed to `@Run`.
pub fn start_pat_binds_f(cp_p0: crate::emit::cpp::Cp, p_p1: crate::lower::model::Pa, v_p2: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(PatBinds { cp_p0, p_p1, v_p2 })
}

/// ```prism
/// SliceBinds: unbounded fn Cp, Pa, Text, Nat -> [Text]
/// ```
pub fn slice_binds_f(cp_p0: &crate::emit::cpp::Cp, pa1: &crate::lower::model::Pa, v_p1: &crate::prelude::Text, i_p2: &crate::prelude::Nat) -> crate::prelude::Array<crate::prelude::Text> {
    match pa1 {
        crate::lower::model::Pa::PaRest(c0_1_0) if (c0_1_0 == &crate::prelude::Text::lit("")) => crate::prelude::Array::new(),
        crate::lower::model::Pa::PaRest(n_p4) => crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("auto {} = {}.subspan({});", &crate::emit::cpp::cpp_id_f(n_p4), v_p1, i_p2))]),
        p_p8 => pat_binds_f(cp_p0, p_p8, &crate::prelude::Text::from(format!("{}[{}]", v_p1, i_p2))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `SliceBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SliceBinds: unbounded fn Cp, Pa, Text, Nat -> [Text]
/// ```
pub struct SliceBinds {
    pub cp_p0: crate::emit::cpp::Cp,
    pub pa1: crate::lower::model::Pa,
    pub v_p1: crate::prelude::Text,
    pub i_p2: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for SliceBinds {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let cp_p0 = &self.cp_p0;
        let pa1 = &self.pa1;
        let v_p1 = &self.v_p1;
        let i_p2 = &self.i_p2;
        match pa1 {
            crate::lower::model::Pa::PaRest(j0_1_0) if (j0_1_0 == &crate::prelude::Text::lit("")) => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
            crate::lower::model::Pa::PaRest(n_p4) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("auto {} = {}.subspan({});", &crate::emit::cpp::cpp_id_f(n_p4), v_p1, i_p2))])),
            p_p8 => ::prism_rtl::Turn::More(::std::rc::Rc::new(PatBinds { cp_p0: cp_p0.clone(), p_p1: p_p8.clone(), v_p2: crate::prelude::Text::from(format!("{}[{}]", v_p1, i_p2)) })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start SliceBinds, x`: what the function value is when passed to `@Run`.
pub fn start_slice_binds_f(cp_p0: crate::emit::cpp::Cp, pa1: crate::lower::model::Pa, v_p1: crate::prelude::Text, i_p2: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(SliceBinds { cp_p0, pa1, v_p1, i_p2 })
}

/// ```prism
/// IsRest: fn Pa -> Bool
/// ```
pub fn is_rest_f(pa0: &crate::lower::model::Pa) -> bool {
    match pa0 {
        crate::lower::model::Pa::PaRest(_) => true,
        other_p0 => false,
    }
}

/// ```prism
/// Concat2: fn [ [Text] ] -> [Text]
/// ```
pub fn concat2_f(xss_p0: &crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::fold(xss_p0, &crate::prelude::Array::new(), &(|acc_p1: &crate::prelude::Array<crate::prelude::Text>, xs_p2: &crate::prelude::Array<crate::prelude::Text>| crate::prelude::append(acc_p1, xs_p2)))
}

/// ```prism
/// Conds: fn [Text] -> Text
/// ```
pub fn conds_f(xs0: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Text {
    match xs0 {
        c0_0 if (c0_0.len() == 0) => crate::prelude::Text::lit("true"),
        cs_p0 => crate::syntax::lexer::chars::join_f(cs_p0, &crate::prelude::Text::lit(" && ")),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IsCatchAll: fn Pa -> Bool
/// ```
pub fn is_catch_all_f(p_p0: &crate::lower::model::Pa) -> bool {
    match p_p0 {
        crate::lower::model::Pa::PaWild => true,
        crate::lower::model::Pa::PaBind(_) => true,
        crate::lower::model::Pa::PaMut(_) => true,
        crate::lower::model::Pa::PaTyped(q_p1, _) => is_catch_all_f(&**q_p1),
        _ => false,
    }
}

/// ```prism
/// Leaves: fn Ex -> Bool
/// ```
pub fn leaves_f(x_p0: &crate::lower::model::Ex) -> bool {
    match x_p0 {
        crate::lower::model::Ex::XBreak(_, _) => true,
        crate::lower::model::Ex::XBreakLoop => true,
        crate::lower::model::Ex::XUnreachable => true,
        _ => false,
    }
}

/// ```prism
/// CppMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
/// ```
pub fn cpp_match_f(cp_p0: &crate::emit::cpp::Cp, s_p1: &crate::lower::model::Ex, arms_p2: &crate::prelude::Array<crate::lower::model::XArm>, out_ty3: &crate::lower::model::OutTy) -> crate::prelude::Text {
    match out_ty3 {
        crate::lower::model::OutTy::OutTurn => ternary_match_f(cp_p0, s_p1, arms_p2),
        t_p6 => {
            let bound_o7 = 'm4518: {
                if let crate::lower::model::Ex::XVar(n_pb) = s_p1 {
                    break 'm4518 ::std::option::Option::Some(crate::emit::cpp::stmts::var_name_f(cp_p0, n_pb));
                }
                if let crate::lower::model::Ex::XRef(m4518_1_0) = s_p1 && let crate::lower::model::Ex::XVar(n_pc) = &**m4518_1_0 {
                    break 'm4518 ::std::option::Option::Some(crate::emit::cpp::stmts::var_name_f(cp_p0, n_pc));
                }
                ::std::option::Option::None
            };
            let subject_p8 = crate::prelude::or(&bound_o7, &crate::prelude::Text::lit("_m"));
            let bind_p9 = match &bound_o7 {
                ::std::option::Option::Some(_) => crate::prelude::Text::lit(""),
                ::std::option::Option::None => crate::prelude::Text::from(format!("auto&& _m = {};\n", &crate::emit::cpp::expr::cpp_expr_f(cp_p0, s_p1))),
            };
            let lines_pa = crate::prelude::run_to_end(crate::prelude::each_job(arms_p2.clone(), {
                let cp_p0x = cp_p0.clone();
                let subject_p8x = subject_p8.clone();
                ::std::rc::Rc::new(move |p0: crate::lower::model::XArm| {
                    let cp_p0xy = cp_p0x.clone();
                    let subject_p8xy = subject_p8x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_pd = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(MatchArm { cp0_p0: cp_p0xy.clone(), subject_p1: subject_p8xy.clone(), a_p2: a_pd.clone(), returns_p3: false }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::XArm) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            }));
            crate::emit::cpp::templates::items::match_expr_f(&crate::emit::cpp::cpp_type_f(cp_p0, t_p6), &crate::prelude::Text::from(format!("{}{}\n{}", &bind_p9, &crate::syntax::lexer::chars::join_f(&lines_pa, &crate::prelude::Text::lit("\n")), &match_tail_f(arms_p2))))
        },
    }
}

/// The step machine of `CppMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
/// ```
pub struct CppMatch {
    pub cp_p0: crate::emit::cpp::Cp,
    pub s_p1: crate::lower::model::Ex,
    pub arms_p2: crate::prelude::Array<crate::lower::model::XArm>,
    pub out_ty3: crate::lower::model::OutTy,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppMatch {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let s_p1 = &self.s_p1;
        let arms_p2 = &self.arms_p2;
        let out_ty3 = &self.out_ty3;
        match out_ty3 {
            crate::lower::model::OutTy::OutTurn => ::prism_rtl::Turn::More(::std::rc::Rc::new(TernaryMatch { cp_p0: cp_p0.clone(), s_p1: s_p1.clone(), arms_p2: arms_p2.clone() })),
            t_p6 => {
                let bound_o7 = 'm4518: {
                    if let crate::lower::model::Ex::XVar(n_pb) = s_p1 {
                        break 'm4518 ::std::option::Option::Some(crate::emit::cpp::stmts::var_name_f(cp_p0, n_pb));
                    }
                    if let crate::lower::model::Ex::XRef(m4518_1_0) = s_p1 && let crate::lower::model::Ex::XVar(n_pc) = &**m4518_1_0 {
                        break 'm4518 ::std::option::Option::Some(crate::emit::cpp::stmts::var_name_f(cp_p0, n_pc));
                    }
                    ::std::option::Option::None
                };
                let subject_p8 = crate::prelude::or(&bound_o7, &crate::prelude::Text::lit("_m"));
                let arms_p2z = arms_p2.clone();
                let cp_p0z = cp_p0.clone();
                let subject_p8z = subject_p8.clone();
                let t_p6z = t_p6.clone();
                let k_let4663 = move |v4663: crate::prelude::Text| {
                    let bind_p9 = v4663;
                    crate::prelude::call_value(crate::prelude::each_job(arms_p2z.clone(), {
                        let cp_p0zx = cp_p0z.clone();
                        let subject_p8zx = subject_p8z.clone();
                        ::std::rc::Rc::new(move |p0: crate::lower::model::XArm| {
                            let cp_p0zxy = cp_p0zx.clone();
                            let subject_p8zxy = subject_p8zx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let a_pd = p0;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(MatchArm { cp0_p0: cp_p0zxy.clone(), subject_p1: subject_p8zxy.clone(), a_p2: a_pd.clone(), returns_p3: false }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::XArm) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                    }), move |each_4771: crate::prelude::Array<crate::prelude::Text>| {
                        let lines_pa = each_4771;
                        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0z.clone(), t_p6z.clone()), move |cpp_type_f_4833: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::match_expr_f(&cpp_type_f_4833, &crate::prelude::Text::from(format!("{}{}\n{}", &bind_p9, &crate::syntax::lexer::chars::join_f(&lines_pa, &crate::prelude::Text::lit("\n")), &match_tail_f(&arms_p2z))))))
                    })
                };
                match bound_o7.clone() {
                    ::std::option::Option::Some(_) => k_let4663(crate::prelude::Text::lit("")),
                    ::std::option::Option::None => {
                        let cp_p0x = cp_p0.clone();
                        let s_p1x = s_p1.clone();
                        crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), s_p1x.clone()), move |cpp_expr_f_4736: crate::prelude::Text| k_let4663(crate::prelude::Text::from(format!("auto&& _m = {};\n", &cpp_expr_f_4736))))
                    },
                }
            },
        }
    }
}

/// `Start CppMatch, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_match_f(cp_p0: crate::emit::cpp::Cp, s_p1: crate::lower::model::Ex, arms_p2: crate::prelude::Array<crate::lower::model::XArm>, out_ty3: crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppMatch { cp_p0, s_p1, arms_p2, out_ty3 })
}

/// ```prism
/// ReturnMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
/// ```
pub fn return_match_f(cp_p0: &crate::emit::cpp::Cp, s_p1: &crate::lower::model::Ex, arms_p2: &crate::prelude::Array<crate::lower::model::XArm>, out_ty3: &crate::lower::model::OutTy) -> crate::prelude::Text {
    match out_ty3 {
        crate::lower::model::OutTy::OutTurn => crate::prelude::Text::from(format!("return {};", &ternary_match_f(cp_p0, s_p1, arms_p2))),
        t_p6 => {
            let bound_o7 = 'm5294: {
                if let crate::lower::model::Ex::XVar(n_pb) = s_p1 {
                    break 'm5294 ::std::option::Option::Some(crate::emit::cpp::stmts::var_name_f(cp_p0, n_pb));
                }
                if let crate::lower::model::Ex::XRef(m5294_1_0) = s_p1 && let crate::lower::model::Ex::XVar(n_pc) = &**m5294_1_0 {
                    break 'm5294 ::std::option::Option::Some(crate::emit::cpp::stmts::var_name_f(cp_p0, n_pc));
                }
                ::std::option::Option::None
            };
            let subject_p8 = crate::prelude::or(&bound_o7, &crate::prelude::Text::lit("_m"));
            let bind_p9 = match &bound_o7 {
                ::std::option::Option::Some(_) => crate::prelude::Text::lit(""),
                ::std::option::Option::None => crate::prelude::Text::from(format!("auto&& _m = {};\n", &crate::emit::cpp::expr::cpp_expr_f(cp_p0, s_p1))),
            };
            let lines_pa = crate::prelude::run_to_end(crate::prelude::each_job(arms_p2.clone(), {
                let cp_p0x = cp_p0.clone();
                let subject_p8x = subject_p8.clone();
                ::std::rc::Rc::new(move |p0: crate::lower::model::XArm| {
                    let cp_p0xy = cp_p0x.clone();
                    let subject_p8xy = subject_p8x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_pd = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(MatchArm { cp0_p0: cp_p0xy.clone(), subject_p1: subject_p8xy.clone(), a_p2: a_pd.clone(), returns_p3: true }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::XArm) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            }));
            crate::prelude::Text::from(format!("{}{}\n{}", &bind_p9, &crate::syntax::lexer::chars::join_f(&lines_pa, &crate::prelude::Text::lit("\n")), &match_tail_f(arms_p2)))
        },
    }
}

/// The step machine of `ReturnMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReturnMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
/// ```
pub struct ReturnMatch {
    pub cp_p0: crate::emit::cpp::Cp,
    pub s_p1: crate::lower::model::Ex,
    pub arms_p2: crate::prelude::Array<crate::lower::model::XArm>,
    pub out_ty3: crate::lower::model::OutTy,
}

impl ::prism_rtl::Job<crate::prelude::Text> for ReturnMatch {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let s_p1 = &self.s_p1;
        let arms_p2 = &self.arms_p2;
        let out_ty3 = &self.out_ty3;
        match out_ty3 {
            crate::lower::model::OutTy::OutTurn => {
                let arms_p2x = arms_p2.clone();
                let cp_p0x = cp_p0.clone();
                let s_p1x = s_p1.clone();
                crate::prelude::call_then(start_ternary_match_f(cp_p0x.clone(), s_p1x.clone(), arms_p2x.clone()), move |ternary_match_f_5218: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("return {};", &ternary_match_f_5218))))
            },
            t_p6 => {
                let bound_o7 = 'm5294: {
                    if let crate::lower::model::Ex::XVar(n_pb) = s_p1 {
                        break 'm5294 ::std::option::Option::Some(crate::emit::cpp::stmts::var_name_f(cp_p0, n_pb));
                    }
                    if let crate::lower::model::Ex::XRef(m5294_1_0) = s_p1 && let crate::lower::model::Ex::XVar(n_pc) = &**m5294_1_0 {
                        break 'm5294 ::std::option::Option::Some(crate::emit::cpp::stmts::var_name_f(cp_p0, n_pc));
                    }
                    ::std::option::Option::None
                };
                let subject_p8 = crate::prelude::or(&bound_o7, &crate::prelude::Text::lit("_m"));
                let arms_p2z = arms_p2.clone();
                let cp_p0z = cp_p0.clone();
                let subject_p8z = subject_p8.clone();
                let k_let5439 = move |v5439: crate::prelude::Text| {
                    let bind_p9 = v5439;
                    crate::prelude::call_value(crate::prelude::each_job(arms_p2z.clone(), {
                        let cp_p0zx = cp_p0z.clone();
                        let subject_p8zx = subject_p8z.clone();
                        ::std::rc::Rc::new(move |p0: crate::lower::model::XArm| {
                            let cp_p0zxy = cp_p0zx.clone();
                            let subject_p8zxy = subject_p8zx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let a_pd = p0;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(MatchArm { cp0_p0: cp_p0zxy.clone(), subject_p1: subject_p8zxy.clone(), a_p2: a_pd.clone(), returns_p3: true }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::XArm) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                    }), move |each_5547: crate::prelude::Array<crate::prelude::Text>| {
                        let lines_pa = each_5547;
                        ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{}\n{}", &bind_p9, &crate::syntax::lexer::chars::join_f(&lines_pa, &crate::prelude::Text::lit("\n")), &match_tail_f(&arms_p2z))))
                    })
                };
                match bound_o7.clone() {
                    ::std::option::Option::Some(_) => k_let5439(crate::prelude::Text::lit("")),
                    ::std::option::Option::None => {
                        let cp_p0x = cp_p0.clone();
                        let s_p1x = s_p1.clone();
                        crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), s_p1x.clone()), move |cpp_expr_f_5512: crate::prelude::Text| k_let5439(crate::prelude::Text::from(format!("auto&& _m = {};\n", &cpp_expr_f_5512))))
                    },
                }
            },
        }
    }
}

/// `Start ReturnMatch, x`: what the function value is when passed to `@Run`.
pub fn start_return_match_f(cp_p0: crate::emit::cpp::Cp, s_p1: crate::lower::model::Ex, arms_p2: crate::prelude::Array<crate::lower::model::XArm>, out_ty3: crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(ReturnMatch { cp_p0, s_p1, arms_p2, out_ty3 })
}

/// ```prism
/// MatchTail: fn [XArm] -> Text
/// ```
pub fn match_tail_f(arms_p0: &crate::prelude::Array<crate::lower::model::XArm>) -> crate::prelude::Text {
    let ends_p1 = match crate::syntax::lexer::chars::last_o(arms_p0) {
        ::std::option::Option::Some(a_p2) => is_catch_all_f(&a_p2.pat_p) && (&crate::prelude::len(&a_p2.conds_p) == &crate::prelude::Nat::from(0u32)),
        ::std::option::Option::None => false,
    };
    if ends_p1 {
        crate::prelude::Text::lit("")
    } else {
        crate::prelude::Text::lit("::prism_rtl::unreachable(\"no arm matched\");\n")
    }
}

/// ```prism
/// TernaryMatch: unbounded fn Cp, Ex, [XArm] -> Text
/// ```
pub fn ternary_match_f(cp_p0: &crate::emit::cpp::Cp, s_p1: &crate::lower::model::Ex, arms_p2: &crate::prelude::Array<crate::lower::model::XArm>) -> crate::prelude::Text {
    let bound_o3 = 'm6281: {
        if let crate::lower::model::Ex::XVar(n_p9) = s_p1 {
            break 'm6281 ::std::option::Option::Some(crate::emit::cpp::stmts::var_name_f(cp_p0, n_p9));
        }
        if let crate::lower::model::Ex::XRef(m6281_1_0) = s_p1 && let crate::lower::model::Ex::XVar(n_pa) = &**m6281_1_0 {
            break 'm6281 ::std::option::Option::Some(crate::emit::cpp::stmts::var_name_f(cp_p0, n_pa));
        }
        ::std::option::Option::None
    };
    let subject_p4 = crate::prelude::or(&bound_o3, &crate::prelude::Text::lit("_m"));
    let bind_p5 = match &bound_o3 {
        ::std::option::Option::Some(_) => crate::prelude::Text::lit(""),
        ::std::option::Option::None => crate::prelude::Text::from(format!("auto&& _m = {};\n", &crate::emit::cpp::expr::cpp_expr_f(cp_p0, s_p1))),
    };
    let reached_p6 = crate::prelude::run_to_end(crate::prelude::fold_job(arms_p2.clone(), (crate::prelude::Array::new(), false), {
        let cp_p0x = cp_p0.clone();
        let subject_p4x = subject_p4.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::lower::model::XArm>, bool), crate::lower::model::XArm)| {
            let cp_p0xy = cp_p0x.clone();
            let subject_p4xy = subject_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (acc_pb, done_pc) = p0;
                let a_pd = p1;
                if done_pc {
                    ::prism_rtl::Turn::Finished((acc_pb.clone(), done_pc))
                } else {
                    crate::prelude::call_then(start_pat_conds_f(cp_p0xy.clone(), a_pd.pat_p.clone(), subject_p4xy.clone()), move |pat_conds_f_6720: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_pb, &a_pd), (&crate::prelude::len(&pat_conds_f_6720) == &crate::prelude::Nat::from(0u32)) && (&crate::prelude::len(&a_pd.conds_p) == &crate::prelude::Nat::from(0u32)))))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::lower::model::XArm>, bool), crate::lower::model::XArm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::lower::model::XArm>, bool)>>>
    }));
    let (kept_pe, ends_pf) = reached_p6.clone();
    let parts_p7 = crate::prelude::run_to_end(crate::prelude::each_job(kept_pe.clone(), {
        let cp_p0x = cp_p0.clone();
        let subject_p4x = subject_p4.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::XArm| {
            let cp_p0xy = cp_p0x.clone();
            let subject_p4xy = subject_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let a_pg = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(TernaryArm { cp0_p0: cp_p0xy.clone(), subject_p1: subject_p4xy.clone(), a_p2: a_pg.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::XArm) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    }));
    let last_text_p8 = if ends_pf {
        crate::prelude::Text::lit("")
    } else {
        crate::prelude::Text::lit("\n    : throw ::prism_rtl::Panic(\"no arm matched\")")
    };
    crate::emit::cpp::templates::items::stmt_expr_f(&crate::prelude::Text::from(format!("{}", &bind_p5)), &crate::prelude::Text::from(format!("{}{}", &crate::syntax::lexer::chars::join_f(&parts_p7, &crate::prelude::Text::lit("\n    : ")), &last_text_p8)))
}

/// The step machine of `TernaryMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TernaryMatch: unbounded fn Cp, Ex, [XArm] -> Text
/// ```
pub struct TernaryMatch {
    pub cp_p0: crate::emit::cpp::Cp,
    pub s_p1: crate::lower::model::Ex,
    pub arms_p2: crate::prelude::Array<crate::lower::model::XArm>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for TernaryMatch {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let s_p1 = &self.s_p1;
        let arms_p2 = &self.arms_p2;
        let bound_o3 = 'm6281: {
            if let crate::lower::model::Ex::XVar(n_p9) = s_p1 {
                break 'm6281 ::std::option::Option::Some(crate::emit::cpp::stmts::var_name_f(cp_p0, n_p9));
            }
            if let crate::lower::model::Ex::XRef(m6281_1_0) = s_p1 && let crate::lower::model::Ex::XVar(n_pa) = &**m6281_1_0 {
                break 'm6281 ::std::option::Option::Some(crate::emit::cpp::stmts::var_name_f(cp_p0, n_pa));
            }
            ::std::option::Option::None
        };
        let subject_p4 = crate::prelude::or(&bound_o3, &crate::prelude::Text::lit("_m"));
        let arms_p2z = arms_p2.clone();
        let cp_p0z = cp_p0.clone();
        let subject_p4z = subject_p4.clone();
        let k_let6426 = move |v6426: crate::prelude::Text| {
            let bind_p5 = v6426;
            crate::prelude::call_value(crate::prelude::fold_job(arms_p2z.clone(), (crate::prelude::Array::new(), false), {
                let cp_p0zx = cp_p0z.clone();
                let subject_p4zx = subject_p4z.clone();
                ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::lower::model::XArm>, bool), crate::lower::model::XArm)| {
                    let cp_p0zxy = cp_p0zx.clone();
                    let subject_p4zxy = subject_p4zx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (acc_pb, done_pc) = p0;
                        let a_pd = p1;
                        if done_pc {
                            ::prism_rtl::Turn::Finished((acc_pb.clone(), done_pc))
                        } else {
                            crate::prelude::call_then(start_pat_conds_f(cp_p0zxy.clone(), a_pd.pat_p.clone(), subject_p4zxy.clone()), move |pat_conds_f_6720: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished((crate::prelude::push(&acc_pb, &a_pd), (&crate::prelude::len(&pat_conds_f_6720) == &crate::prelude::Nat::from(0u32)) && (&crate::prelude::len(&a_pd.conds_p) == &crate::prelude::Nat::from(0u32)))))
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::lower::model::XArm>, bool), crate::lower::model::XArm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::lower::model::XArm>, bool)>>>
            }), move |fold_6620: (crate::prelude::Array<crate::lower::model::XArm>, bool)| {
                let reached_p6 = fold_6620;
                let (kept_pe, ends_pf) = reached_p6.clone();
                crate::prelude::call_value(crate::prelude::each_job(kept_pe.clone(), {
                    let cp_p0zx = cp_p0z.clone();
                    let subject_p4zx = subject_p4z.clone();
                    ::std::rc::Rc::new(move |p0: crate::lower::model::XArm| {
                        let cp_p0zxy = cp_p0zx.clone();
                        let subject_p4zxy = subject_p4zx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_pg = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(TernaryArm { cp0_p0: cp_p0zxy.clone(), subject_p1: subject_p4zxy.clone(), a_p2: a_pg.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::XArm) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                }), move |each_6829: crate::prelude::Array<crate::prelude::Text>| {
                    let parts_p7 = each_6829;
                    let last_text_p8 = if ends_pf {
                        crate::prelude::Text::lit("")
                    } else {
                        crate::prelude::Text::lit("\n    : throw ::prism_rtl::Panic(\"no arm matched\")")
                    };
                    ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::stmt_expr_f(&crate::prelude::Text::from(format!("{}", &bind_p5)), &crate::prelude::Text::from(format!("{}{}", &crate::syntax::lexer::chars::join_f(&parts_p7, &crate::prelude::Text::lit("\n    : ")), &last_text_p8))))
                })
            })
        };
        match bound_o3.clone() {
            ::std::option::Option::Some(_) => k_let6426(crate::prelude::Text::lit("")),
            ::std::option::Option::None => {
                let cp_p0x = cp_p0.clone();
                let s_p1x = s_p1.clone();
                crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), s_p1x.clone()), move |cpp_expr_f_6499: crate::prelude::Text| k_let6426(crate::prelude::Text::from(format!("auto&& _m = {};\n", &cpp_expr_f_6499))))
            },
        }
    }
}

/// `Start TernaryMatch, x`: what the function value is when passed to `@Run`.
pub fn start_ternary_match_f(cp_p0: crate::emit::cpp::Cp, s_p1: crate::lower::model::Ex, arms_p2: crate::prelude::Array<crate::lower::model::XArm>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(TernaryMatch { cp_p0, s_p1, arms_p2 })
}

/// ```prism
/// TernaryArm: unbounded fn Cp, Text, XArm -> Text
/// ```
pub fn ternary_arm_f(cp0_p0: &crate::emit::cpp::Cp, subject_p1: &crate::prelude::Text, a_p2: &crate::lower::model::XArm) -> crate::prelude::Text {
    let cp_p3 = crate::emit::cpp::stmts::unbind_f(cp0_p0, &crate::emit::cpp::stmts::arm_names_f(a_p2));
    let tests_p4 = pat_conds_f(&cp_p3, &a_p2.pat_p, subject_p1);
    let binds_p5 = pat_binds_f(&cp_p3, &a_p2.pat_p, subject_p1);
    let n_p6 = crate::prelude::len(&a_p2.conds_p);
    let lets_p7 = concat2_f(&crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&n_p6), {
        let cp_p3x = cp_p3.clone();
        let a_p2x = a_p2.clone();
        let n_p6x = n_p6.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
            let cp_p3xy = cp_p3x.clone();
            let a_p2xy = a_p2x.clone();
            let n_p6xy = n_p6x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_pb = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(CondBinds { cp_p0: cp_p3xy.clone(), cc1: crate::prelude::or(&crate::prelude::index(&a_p2xy.conds_p, &i_pb), &crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XUnit)), k_p3: crate::prelude::or(&(&n_p6xy).checked_sub(&i_pb), &crate::prelude::Nat::from(0u32)) }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
    })));
    let value_p8 = if &(&crate::prelude::len(&binds_p5) + &crate::prelude::len(&lets_p7)) == &crate::prelude::Nat::from(0u32) {
        crate::emit::cpp::expr::cpp_expr_f(&cp_p3, &a_p2.body_p)
    } else {
        crate::emit::cpp::templates::items::stmt_expr_f(&crate::syntax::lexer::chars::join_f(&crate::prelude::append(&binds_p5, &lets_p7), &crate::prelude::Text::lit("\n")), &crate::emit::cpp::expr::cpp_expr_f(&cp_p3, &a_p2.body_p))
    };
    let guard_p9 = if &crate::prelude::len(&a_p2.conds_p) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Array::new()
    } else {
        crate::prelude::Array::from(vec![crate::emit::cpp::templates::items::stmt_expr_f(&crate::syntax::lexer::chars::join_f(&binds_p5, &crate::prelude::Text::lit("\n")), &guard_test_f(&cp_p3, &a_p2.conds_p))])
    };
    let all_pa = crate::prelude::append(&tests_p4, &guard_p9);
    if &crate::prelude::len(&all_pa) == &crate::prelude::Nat::from(0u32) {
        value_p8.clone()
    } else {
        crate::prelude::Text::from(format!("{} ? {}", &conds_f(&all_pa), &value_p8))
    }
}

/// The step machine of `TernaryArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TernaryArm: unbounded fn Cp, Text, XArm -> Text
/// ```
pub struct TernaryArm {
    pub cp0_p0: crate::emit::cpp::Cp,
    pub subject_p1: crate::prelude::Text,
    pub a_p2: crate::lower::model::XArm,
}

impl ::prism_rtl::Job<crate::prelude::Text> for TernaryArm {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp0_p0 = &self.cp0_p0;
        let subject_p1 = &self.subject_p1;
        let a_p2 = &self.a_p2;
        let a_p2x = a_p2.clone();
        let cp0_p0x = cp0_p0.clone();
        let subject_p1x = subject_p1.clone();
        crate::prelude::call_then(crate::emit::cpp::stmts::start_arm_names_f(a_p2x.clone()), move |arm_names_f_7129: crate::prelude::Array<crate::prelude::Text>| {
            let cp_p3 = crate::emit::cpp::stmts::unbind_f(&cp0_p0x, &arm_names_f_7129);
            crate::prelude::call_then(start_pat_conds_f(cp_p3.clone(), a_p2x.pat_p.clone(), subject_p1x.clone()), move |pat_conds_f_7157: crate::prelude::Array<crate::prelude::Text>| {
                let tests_p4 = pat_conds_f_7157;
                crate::prelude::call_then(start_pat_binds_f(cp_p3.clone(), a_p2x.pat_p.clone(), subject_p1x.clone()), move |pat_binds_f_7201: crate::prelude::Array<crate::prelude::Text>| {
                    let binds_p5 = pat_binds_f_7201;
                    let n_p6 = crate::prelude::len(&a_p2x.conds_p);
                    crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&n_p6), {
                        let cp_p3x = cp_p3.clone();
                        let a_p2xx = a_p2x.clone();
                        let n_p6x = n_p6.clone();
                        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                            let cp_p3xy = cp_p3x.clone();
                            let a_p2xxy = a_p2xx.clone();
                            let n_p6xy = n_p6x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let i_pb = p0;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(CondBinds { cp_p0: cp_p3xy.clone(), cc1: crate::prelude::or(&crate::prelude::index(&a_p2xxy.conds_p, &i_pb), &crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XUnit)), k_p3: crate::prelude::or(&(&n_p6xy).checked_sub(&i_pb), &crate::prelude::Nat::from(0u32)) }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                    }), move |each_7277: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| {
                        let lets_p7 = concat2_f(&each_7277);
                        let a_p2xz = a_p2x.clone();
                        let binds_p5z = binds_p5.clone();
                        let cp_p3z = cp_p3.clone();
                        let tests_p4z = tests_p4.clone();
                        let k_let7366 = move |v7366: crate::prelude::Text| {
                            let value_p8 = v7366;
                            let tests_p4zz = tests_p4z.clone();
                            let value_p8z = value_p8.clone();
                            let k_let7506 = move |v7506: crate::prelude::Array<crate::prelude::Text>| {
                                let guard_p9 = v7506;
                                let all_pa = crate::prelude::append(&tests_p4zz, &guard_p9);
                                if &crate::prelude::len(&all_pa) == &crate::prelude::Nat::from(0u32) {
                                    ::prism_rtl::Turn::Finished(value_p8z.clone())
                                } else {
                                    ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} ? {}", &conds_f(&all_pa), &value_p8z)))
                                }
                            };
                            if &crate::prelude::len(&a_p2xz.conds_p) == &crate::prelude::Nat::from(0u32) {
                                k_let7506(crate::prelude::Array::new())
                            } else {
                                crate::prelude::call_then(start_guard_test_f(cp_p3z.clone(), a_p2xz.conds_p.clone()), move |guard_test_f_7585: crate::prelude::Text| k_let7506(crate::prelude::Array::from(vec![crate::emit::cpp::templates::items::stmt_expr_f(&crate::syntax::lexer::chars::join_f(&binds_p5z, &crate::prelude::Text::lit("\n")), &guard_test_f_7585)])))
                            }
                        };
                        if &(&crate::prelude::len(&binds_p5) + &crate::prelude::len(&lets_p7)) == &crate::prelude::Nat::from(0u32) {
                            crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p3.clone(), a_p2x.body_p.clone()), move |cpp_expr_f_7412: crate::prelude::Text| k_let7366(cpp_expr_f_7412))
                        } else {
                            crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p3.clone(), a_p2x.body_p.clone()), move |cpp_expr_f_7482: crate::prelude::Text| k_let7366(crate::emit::cpp::templates::items::stmt_expr_f(&crate::syntax::lexer::chars::join_f(&crate::prelude::append(&binds_p5, &lets_p7), &crate::prelude::Text::lit("\n")), &cpp_expr_f_7482)))
                        }
                    })
                })
            })
        })
    }
}

/// `Start TernaryArm, x`: what the function value is when passed to `@Run`.
pub fn start_ternary_arm_f(cp0_p0: crate::emit::cpp::Cp, subject_p1: crate::prelude::Text, a_p2: crate::lower::model::XArm) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(TernaryArm { cp0_p0, subject_p1, a_p2 })
}

/// ```prism
/// CondBinds: unbounded fn Cp, Cc, Nat -> [Text]
/// ```
pub fn cond_binds_f(cp_p0: &crate::emit::cpp::Cp, cc1: &crate::lower::model::Cc, k_p3: &crate::prelude::Nat) -> crate::prelude::Array<crate::prelude::Text> {
    match cc1 {
        crate::lower::model::Cc::CcLet(p_p1, x_p2) => {
            let (v_p4, pre_p5) = cond_subject_f(cp_p0, x_p2, k_p3);
            crate::prelude::append(&pre_p5, &pat_binds_f(cp_p0, p_p1, &v_p4))
        },
        crate::lower::model::Cc::CcIf(x_p7) => crate::prelude::Array::new(),
    }
}

/// The step machine of `CondBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondBinds: unbounded fn Cp, Cc, Nat -> [Text]
/// ```
pub struct CondBinds {
    pub cp_p0: crate::emit::cpp::Cp,
    pub cc1: crate::lower::model::Cc,
    pub k_p3: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for CondBinds {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let cp_p0 = &self.cp_p0;
        let cc1 = &self.cc1;
        let k_p3 = &self.k_p3;
        match cc1 {
            crate::lower::model::Cc::CcLet(p_p1, x_p2) => {
                let cp_p0x = cp_p0.clone();
                let k_p3x = k_p3.clone();
                let p_p1x = p_p1.clone();
                let x_p2x = x_p2.clone();
                crate::prelude::call_then(start_cond_subject_f(cp_p0x.clone(), x_p2x.clone(), k_p3x.clone()), move |cond_subject_f_7806: (crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)| {
                    let (v_p4, pre_p5) = cond_subject_f_7806;
                    crate::prelude::call_then(start_pat_binds_f(cp_p0x.clone(), p_p1x.clone(), v_p4.clone()), move |pat_binds_f_7844: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::append(&pre_p5, &pat_binds_f_7844)))
                })
            },
            crate::lower::model::Cc::CcIf(x_p7) => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start CondBinds, x`: what the function value is when passed to `@Run`.
pub fn start_cond_binds_f(cp_p0: crate::emit::cpp::Cp, cc1: crate::lower::model::Cc, k_p3: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(CondBinds { cp_p0, cc1, k_p3 })
}

/// ```prism
/// CondSubject: unbounded fn Cp, Ex, Nat -> ((Text, [Text]))
/// ```
pub fn cond_subject_f(cp_p0: &crate::emit::cpp::Cp, x_p1: &crate::lower::model::Ex, k_p2: &crate::prelude::Nat) -> (crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>) {
    if is_place_ex_f(x_p1) {
        (crate::emit::cpp::expr::cpp_tight_f(cp_p0, x_p1), crate::prelude::Array::new())
    } else {
        (crate::prelude::Text::from(format!("_c{}", k_p2)), crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("auto&& _c{} = {};", k_p2, &crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p1)))]))
    }
}

/// The step machine of `CondSubject`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondSubject: unbounded fn Cp, Ex, Nat -> ((Text, [Text]))
/// ```
pub struct CondSubject {
    pub cp_p0: crate::emit::cpp::Cp,
    pub x_p1: crate::lower::model::Ex,
    pub k_p2: crate::prelude::Nat,
}

impl ::prism_rtl::Job<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)> for CondSubject {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)> {
        let cp_p0 = &self.cp_p0;
        let x_p1 = &self.x_p1;
        let k_p2 = &self.k_p2;
        if is_place_ex_f(x_p1) {
            {
                let cp_p0x = cp_p0.clone();
                let x_p1x = x_p1.clone();
                crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_tight_f(cp_p0x.clone(), x_p1x.clone()), move |cpp_tight_f_8261: crate::prelude::Text| ::prism_rtl::Turn::Finished((cpp_tight_f_8261, crate::prelude::Array::new())))
            }
        } else {
            {
                let cp_p0x = cp_p0.clone();
                let k_p2x = k_p2.clone();
                let x_p1x = x_p1.clone();
                crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), x_p1x.clone()), move |cpp_expr_f_8321: crate::prelude::Text| ::prism_rtl::Turn::Finished((crate::prelude::Text::from(format!("_c{}", &k_p2x)), crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("auto&& _c{} = {};", &k_p2x, &cpp_expr_f_8321))]))))
            }
        }
    }
}

/// `Start CondSubject, x`: what the function value is when passed to `@Run`.
pub fn start_cond_subject_f(cp_p0: crate::emit::cpp::Cp, x_p1: crate::lower::model::Ex, k_p2: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>> {
    ::std::rc::Rc::new(CondSubject { cp_p0, x_p1, k_p2 })
}

/// ```prism
/// IsPlaceEx: fn Ex -> Bool
/// ```
pub fn is_place_ex_f(x_p0: &crate::lower::model::Ex) -> bool {
    match x_p0 {
        crate::lower::model::Ex::XVar(_) => true,
        crate::lower::model::Ex::XField(y_p1, _) => is_place_ex_f(&**y_p1),
        crate::lower::model::Ex::XFieldOf(y_p2, _, _) => is_place_ex_f(&**y_p2),
        crate::lower::model::Ex::XPart(y_p3, _) => is_place_ex_f(&**y_p3),
        crate::lower::model::Ex::XTarget(_) => true,
        crate::lower::model::Ex::XSelf => true,
        crate::lower::model::Ex::XRef(y_p4) => is_place_ex_f(&**y_p4),
        crate::lower::model::Ex::XDeref(y_p5) => is_place_ex_f(&**y_p5),
        _ => false,
    }
}

/// ```prism
/// GuardTest: unbounded fn Cp, [Cc] -> Text
/// ```
pub fn guard_test_f(cp_p0: &crate::emit::cpp::Cp, xs1: &crate::prelude::Array<crate::lower::model::Cc>) -> crate::prelude::Text {
    match xs1 {
        c0_1 if (c0_1.len() == 0) => crate::prelude::Text::lit("true"),
        cs_p2 => {
            let first_p3 = crate::prelude::or(&crate::prelude::index(cs_p2, &crate::prelude::Nat::from(0u32)), &crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XUnit));
            let rest_p4 = guard_test_f(cp_p0, &crate::prelude::drop(cs_p2, &crate::prelude::Nat::from(1u32)));
            match &first_p3 {
                crate::lower::model::Cc::CcIf(x_p5) => if &crate::prelude::len(cs_p2) == &crate::prelude::Nat::from(1u32) {
                    crate::emit::cpp::expr::cpp_tight_f(cp_p0, x_p5)
                } else {
                    crate::prelude::Text::from(format!("{} && {}", &crate::emit::cpp::expr::cpp_tight_f(cp_p0, x_p5), &rest_p4))
                },
                crate::lower::model::Cc::CcLet(p_p6, x_p7) => {
                    let (v_pa, pre_pb) = cond_subject_f(cp_p0, x_p7, &crate::prelude::len(cs_p2));
                    let tests_p8 = conds_f(&pat_conds_f(cp_p0, p_p6, &v_pa));
                    let whole_p9 = if &crate::prelude::len(cs_p2) == &crate::prelude::Nat::from(1u32) {
                        tests_p8.clone()
                    } else {
                        crate::prelude::Text::from(format!("{} && {}", &tests_p8, &crate::emit::cpp::templates::items::stmt_expr_f(&crate::syntax::lexer::chars::join_f(&pat_binds_f(cp_p0, p_p6, &v_pa), &crate::prelude::Text::lit("\n")), &rest_p4)))
                    };
                    if &crate::prelude::len(&pre_pb) == &crate::prelude::Nat::from(0u32) {
                        whole_p9.clone()
                    } else {
                        crate::emit::cpp::templates::items::stmt_expr_f(&crate::syntax::lexer::chars::join_f(&pre_pb, &crate::prelude::Text::lit("\n")), &whole_p9)
                    }
                },
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `GuardTest`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GuardTest: unbounded fn Cp, [Cc] -> Text
/// ```
pub struct GuardTest {
    pub cp_p0: crate::emit::cpp::Cp,
    pub xs1: crate::prelude::Array<crate::lower::model::Cc>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for GuardTest {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let xs1 = &self.xs1;
        match xs1 {
            j0_1 if (j0_1.len() == 0) => ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("true")),
            cs_p2 => {
                let first_p3 = crate::prelude::or(&crate::prelude::index(cs_p2, &crate::prelude::Nat::from(0u32)), &crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XUnit));
                let cp_p0x = cp_p0.clone();
                let cs_p2x = cs_p2.clone();
                crate::prelude::call_then(start_guard_test_f(cp_p0x.clone(), crate::prelude::drop(&cs_p2x, &crate::prelude::Nat::from(1u32))), move |guard_test_f_8869: crate::prelude::Text| {
                    let rest_p4 = guard_test_f_8869;
                    match &first_p3 {
                        crate::lower::model::Cc::CcIf(x_p5) => if &crate::prelude::len(&cs_p2x) == &crate::prelude::Nat::from(1u32) {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::cpp::expr::CppTight { cp_p0: cp_p0x.clone(), x_p1: x_p5.clone() }))
                        } else {
                            {
                                let x_p5x = x_p5.clone();
                                crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_tight_f(cp_p0x.clone(), x_p5x.clone()), move |cpp_tight_f_8970: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} && {}", &cpp_tight_f_8970, &rest_p4))))
                            }
                        },
                        crate::lower::model::Cc::CcLet(p_p6, x_p7) => {
                            let p_p6x = p_p6.clone();
                            let x_p7x = x_p7.clone();
                            crate::prelude::call_then(start_cond_subject_f(cp_p0x.clone(), x_p7x.clone(), crate::prelude::len(&cs_p2x)), move |cond_subject_f_9046: (crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)| {
                                let (v_pa, pre_pb) = cond_subject_f_9046;
                                crate::prelude::call_then(start_pat_conds_f(cp_p0x.clone(), p_p6x.clone(), v_pa.clone()), move |pat_conds_f_9105: crate::prelude::Array<crate::prelude::Text>| {
                                    let tests_p8 = conds_f(&pat_conds_f_9105);
                                    let pre_pbz = pre_pb.clone();
                                    let k_let9136 = move |v9136: crate::prelude::Text| {
                                        let whole_p9 = v9136;
                                        if &crate::prelude::len(&pre_pbz) == &crate::prelude::Nat::from(0u32) {
                                            ::prism_rtl::Turn::Finished(whole_p9.clone())
                                        } else {
                                            ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::stmt_expr_f(&crate::syntax::lexer::chars::join_f(&pre_pbz, &crate::prelude::Text::lit("\n")), &whole_p9))
                                        }
                                    };
                                    if &crate::prelude::len(&cs_p2x) == &crate::prelude::Nat::from(1u32) {
                                        k_let9136(tests_p8.clone())
                                    } else {
                                        crate::prelude::call_then(start_pat_binds_f(cp_p0x.clone(), p_p6x.clone(), v_pa.clone()), move |pat_binds_f_9207: crate::prelude::Array<crate::prelude::Text>| k_let9136(crate::prelude::Text::from(format!("{} && {}", &tests_p8, &crate::emit::cpp::templates::items::stmt_expr_f(&crate::syntax::lexer::chars::join_f(&pat_binds_f_9207, &crate::prelude::Text::lit("\n")), &rest_p4)))))
                                    }
                                })
                            })
                        },
                    }
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start GuardTest, x`: what the function value is when passed to `@Run`.
pub fn start_guard_test_f(cp_p0: crate::emit::cpp::Cp, xs1: crate::prelude::Array<crate::lower::model::Cc>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(GuardTest { cp_p0, xs1 })
}

/// ```prism
/// MatchArm: unbounded fn Cp, Text, XArm, Bool -> Text
/// ```
pub fn match_arm_f(cp0_p0: &crate::emit::cpp::Cp, subject_p1: &crate::prelude::Text, a_p2: &crate::lower::model::XArm, returns_p3: &bool) -> crate::prelude::Text {
    let cp_p4 = crate::emit::cpp::stmts::unbind_f(cp0_p0, &crate::emit::cpp::stmts::arm_names_f(a_p2));
    let tests_p5 = pat_conds_f(&cp_p4, &a_p2.pat_p, subject_p1);
    let binds_p6 = pat_binds_f(&cp_p4, &a_p2.pat_p, subject_p1);
    let body_p7 = if *returns_p3 {
        crate::emit::cpp::stmts::cpp_body_f(&cp_p4, &a_p2.body_p)
    } else {
        if leaves_f(&a_p2.body_p) {
            crate::prelude::Text::from(format!("{};", &crate::emit::cpp::expr::cpp_expr_f(&cp_p4, &a_p2.body_p)))
        } else {
            crate::prelude::Text::from(format!("_v.set({});\ngoto _done;", &crate::emit::cpp::expr::cpp_expr_f(&cp_p4, &a_p2.body_p)))
        }
    };
    let guarded_p8 = if &crate::prelude::len(&a_p2.conds_p) == &crate::prelude::Nat::from(0u32) {
        body_p7.clone()
    } else {
        guarded_arm_f(&cp_p4, &a_p2.conds_p, &body_p7)
    };
    let inner_p9 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&binds_p6, &crate::prelude::Array::from(vec![guarded_p8.clone()])), &crate::prelude::Text::lit("\n"));
    if &crate::prelude::len(&tests_p5) == &crate::prelude::Nat::from(0u32) {
        crate::emit::cpp::templates::items::braced_f(&inner_p9)
    } else {
        crate::emit::cpp::templates::items::if_block_f(&conds_f(&tests_p5), &inner_p9)
    }
}

/// The step machine of `MatchArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MatchArm: unbounded fn Cp, Text, XArm, Bool -> Text
/// ```
pub struct MatchArm {
    pub cp0_p0: crate::emit::cpp::Cp,
    pub subject_p1: crate::prelude::Text,
    pub a_p2: crate::lower::model::XArm,
    pub returns_p3: bool,
}

impl ::prism_rtl::Job<crate::prelude::Text> for MatchArm {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp0_p0 = &self.cp0_p0;
        let subject_p1 = &self.subject_p1;
        let a_p2 = &self.a_p2;
        let returns_p3 = &self.returns_p3;
        let a_p2x = a_p2.clone();
        let cp0_p0x = cp0_p0.clone();
        let returns_p3x = *returns_p3;
        let subject_p1x = subject_p1.clone();
        crate::prelude::call_then(crate::emit::cpp::stmts::start_arm_names_f(a_p2x.clone()), move |arm_names_f_9563: crate::prelude::Array<crate::prelude::Text>| {
            let cp_p4 = crate::emit::cpp::stmts::unbind_f(&cp0_p0x, &arm_names_f_9563);
            crate::prelude::call_then(start_pat_conds_f(cp_p4.clone(), a_p2x.pat_p.clone(), subject_p1x.clone()), move |pat_conds_f_9591: crate::prelude::Array<crate::prelude::Text>| {
                let tests_p5 = pat_conds_f_9591;
                crate::prelude::call_then(start_pat_binds_f(cp_p4.clone(), a_p2x.pat_p.clone(), subject_p1x.clone()), move |pat_binds_f_9635: crate::prelude::Array<crate::prelude::Text>| {
                    let binds_p6 = pat_binds_f_9635;
                    let a_p2xz = a_p2x.clone();
                    let binds_p6z = binds_p6.clone();
                    let cp_p4z = cp_p4.clone();
                    let tests_p5z = tests_p5.clone();
                    let k_let9667 = move |v9667: crate::prelude::Text| {
                        let body_p7 = v9667;
                        let binds_p6zz = binds_p6z.clone();
                        let tests_p5zz = tests_p5z.clone();
                        let k_let9812 = move |v9812: crate::prelude::Text| {
                            let guarded_p8 = v9812;
                            let inner_p9 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&binds_p6zz, &crate::prelude::Array::from(vec![guarded_p8.clone()])), &crate::prelude::Text::lit("\n"));
                            if &crate::prelude::len(&tests_p5zz) == &crate::prelude::Nat::from(0u32) {
                                ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::braced_f(&inner_p9))
                            } else {
                                ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::if_block_f(&conds_f(&tests_p5zz), &inner_p9))
                            }
                        };
                        if &crate::prelude::len(&a_p2xz.conds_p) == &crate::prelude::Nat::from(0u32) {
                            k_let9812(body_p7.clone())
                        } else {
                            crate::prelude::call_then(start_guarded_arm_f(cp_p4z.clone(), a_p2xz.conds_p.clone(), body_p7.clone()), move |guarded_arm_f_9860: crate::prelude::Text| k_let9812(guarded_arm_f_9860))
                        }
                    };
                    if returns_p3x {
                        crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_body_f(cp_p4.clone(), a_p2x.body_p.clone()), move |cpp_body_f_9690: crate::prelude::Text| k_let9667(cpp_body_f_9690))
                    } else {
                        if leaves_f(&a_p2x.body_p) {
                            crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p4.clone(), a_p2x.body_p.clone()), move |cpp_expr_f_9735: crate::prelude::Text| k_let9667(crate::prelude::Text::from(format!("{};", &cpp_expr_f_9735))))
                        } else {
                            crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p4.clone(), a_p2x.body_p.clone()), move |cpp_expr_f_9772: crate::prelude::Text| k_let9667(crate::prelude::Text::from(format!("_v.set({});\ngoto _done;", &cpp_expr_f_9772))))
                        }
                    }
                })
            })
        })
    }
}

/// `Start MatchArm, x`: what the function value is when passed to `@Run`.
pub fn start_match_arm_f(cp0_p0: crate::emit::cpp::Cp, subject_p1: crate::prelude::Text, a_p2: crate::lower::model::XArm, returns_p3: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(MatchArm { cp0_p0, subject_p1, a_p2, returns_p3 })
}

/// ```prism
/// GuardedArm: unbounded fn Cp, [Cc], Text -> Text
/// ```
pub fn guarded_arm_f(cp_p0: &crate::emit::cpp::Cp, xs1: &crate::prelude::Array<crate::lower::model::Cc>, body_p1: &crate::prelude::Text) -> crate::prelude::Text {
    match xs1 {
        c0_1 if (c0_1.len() == 0) => body_p1.clone(),
        cs_p3 => {
            let first_p5 = crate::prelude::or(&crate::prelude::index(cs_p3, &crate::prelude::Nat::from(0u32)), &crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XUnit));
            let rest_p6 = guarded_arm_f(cp_p0, &crate::prelude::drop(cs_p3, &crate::prelude::Nat::from(1u32)), body_p1);
            match &first_p5 {
                crate::lower::model::Cc::CcIf(x_p7) => crate::emit::cpp::templates::items::if_block_f(&crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p7), &rest_p6),
                crate::lower::model::Cc::CcLet(p_p8, x_p9) => {
                    let (v_pb, pre_pc) = cond_subject_f(cp_p0, x_p9, &crate::prelude::len(cs_p3));
                    let inner_pa = crate::emit::cpp::templates::items::if_block_f(&conds_f(&pat_conds_f(cp_p0, p_p8, &v_pb)), &crate::syntax::lexer::chars::join_f(&crate::prelude::append(&pat_binds_f(cp_p0, p_p8, &v_pb), &crate::prelude::Array::from(vec![rest_p6.clone()])), &crate::prelude::Text::lit("\n")));
                    if &crate::prelude::len(&pre_pc) == &crate::prelude::Nat::from(0u32) {
                        inner_pa.clone()
                    } else {
                        crate::emit::cpp::templates::items::braced_f(&crate::syntax::lexer::chars::join_f(&crate::prelude::push(&pre_pc, &inner_pa), &crate::prelude::Text::lit("\n")))
                    }
                },
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `GuardedArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GuardedArm: unbounded fn Cp, [Cc], Text -> Text
/// ```
pub struct GuardedArm {
    pub cp_p0: crate::emit::cpp::Cp,
    pub xs1: crate::prelude::Array<crate::lower::model::Cc>,
    pub body_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Text> for GuardedArm {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let xs1 = &self.xs1;
        let body_p1 = &self.body_p1;
        match xs1 {
            j0_1 if (j0_1.len() == 0) => ::prism_rtl::Turn::Finished(body_p1.clone()),
            cs_p3 => {
                let first_p5 = crate::prelude::or(&crate::prelude::index(cs_p3, &crate::prelude::Nat::from(0u32)), &crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XUnit));
                let body_p1x = body_p1.clone();
                let cp_p0x = cp_p0.clone();
                let cs_p3x = cs_p3.clone();
                crate::prelude::call_then(start_guarded_arm_f(cp_p0x.clone(), crate::prelude::drop(&cs_p3x, &crate::prelude::Nat::from(1u32)), body_p1x.clone()), move |guarded_arm_f_10272: crate::prelude::Text| {
                    let rest_p6 = guarded_arm_f_10272;
                    match &first_p5 {
                        crate::lower::model::Cc::CcIf(x_p7) => {
                            let x_p7x = x_p7.clone();
                            crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), x_p7x.clone()), move |cpp_expr_f_10348: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::if_block_f(&cpp_expr_f_10348, &rest_p6)))
                        },
                        crate::lower::model::Cc::CcLet(p_p8, x_p9) => {
                            let p_p8x = p_p8.clone();
                            let x_p9x = x_p9.clone();
                            crate::prelude::call_then(start_cond_subject_f(cp_p0x.clone(), x_p9x.clone(), crate::prelude::len(&cs_p3x)), move |cond_subject_f_10418: (crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)| {
                                let (v_pb, pre_pc) = cond_subject_f_10418;
                                crate::prelude::call_then(start_pat_conds_f(cp_p0x.clone(), p_p8x.clone(), v_pb.clone()), move |pat_conds_f_10486: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(start_pat_binds_f(cp_p0x.clone(), p_p8x.clone(), v_pb.clone()), move |pat_binds_f_10522: crate::prelude::Array<crate::prelude::Text>| {
                                    let inner_pa = crate::emit::cpp::templates::items::if_block_f(&conds_f(&pat_conds_f_10486), &crate::syntax::lexer::chars::join_f(&crate::prelude::append(&pat_binds_f_10522, &crate::prelude::Array::from(vec![rest_p6.clone()])), &crate::prelude::Text::lit("\n")));
                                    if &crate::prelude::len(&pre_pc) == &crate::prelude::Nat::from(0u32) {
                                        ::prism_rtl::Turn::Finished(inner_pa.clone())
                                    } else {
                                        ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::braced_f(&crate::syntax::lexer::chars::join_f(&crate::prelude::push(&pre_pc, &inner_pa), &crate::prelude::Text::lit("\n"))))
                                    }
                                }))
                            })
                        },
                    }
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start GuardedArm, x`: what the function value is when passed to `@Run`.
pub fn start_guarded_arm_f(cp_p0: crate::emit::cpp::Cp, xs1: crate::prelude::Array<crate::lower::model::Cc>, body_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(GuardedArm { cp_p0, xs1, body_p1 })
}

/// ```prism
/// CppLabeled: unbounded fn Cp, Text, [Do], Ex, OutTy -> Text
/// ```
pub fn cpp_labeled_f(cp_p0: &crate::emit::cpp::Cp, label_p1: &crate::prelude::Text, dos_p2: &crate::prelude::Array<crate::lower::model::Do>, e_p3: &crate::lower::model::Ex, t_p4: &crate::lower::model::OutTy) -> crate::prelude::Text {
    let l_p5 = cpp_label_f(label_p1);
    let last_p6 = if leaves_f(e_p3) {
        crate::prelude::Text::from(format!("{};", &crate::emit::cpp::expr::cpp_expr_f(cp_p0, e_p3)))
    } else {
        crate::prelude::Text::from(format!("{}_v.set({});", &l_p5, &crate::emit::cpp::expr::cpp_expr_f(cp_p0, e_p3)))
    };
    crate::emit::cpp::templates::items::labeled_expr_f(&l_p5, &crate::emit::cpp::cpp_type_f(cp_p0, t_p4), &crate::syntax::lexer::chars::join_f(&crate::prelude::push(&crate::prelude::run_to_end(crate::prelude::each_job(dos_p2.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::Do| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let d_p7 = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::cpp::stmts::CppStatement { cp_p0: cp_p0xy.clone(), d_p1: d_p7.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Do) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    })), &last_p6), &crate::prelude::Text::lit("\n")))
}

/// The step machine of `CppLabeled`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppLabeled: unbounded fn Cp, Text, [Do], Ex, OutTy -> Text
/// ```
pub struct CppLabeled {
    pub cp_p0: crate::emit::cpp::Cp,
    pub label_p1: crate::prelude::Text,
    pub dos_p2: crate::prelude::Array<crate::lower::model::Do>,
    pub e_p3: crate::lower::model::Ex,
    pub t_p4: crate::lower::model::OutTy,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppLabeled {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let label_p1 = &self.label_p1;
        let dos_p2 = &self.dos_p2;
        let e_p3 = &self.e_p3;
        let t_p4 = &self.t_p4;
        let l_p5 = cpp_label_f(label_p1);
        let cp_p0z = cp_p0.clone();
        let dos_p2z = dos_p2.clone();
        let l_p5z = l_p5.clone();
        let t_p4z = t_p4.clone();
        let k_let10849 = move |v10849: crate::prelude::Text| {
            let last_p6 = v10849;
            crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0z.clone(), t_p4z.clone()), move |cpp_type_f_10948: crate::prelude::Text| crate::prelude::call_value(crate::prelude::each_job(dos_p2z.clone(), {
                let cp_p0zx = cp_p0z.clone();
                ::std::rc::Rc::new(move |p0: crate::lower::model::Do| {
                    let cp_p0zxy = cp_p0zx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let d_p7 = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::cpp::stmts::CppStatement { cp_p0: cp_p0zxy.clone(), d_p1: d_p7.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Do) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            }), move |each_10977: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::labeled_expr_f(&l_p5z, &cpp_type_f_10948, &crate::syntax::lexer::chars::join_f(&crate::prelude::push(&each_10977, &last_p6), &crate::prelude::Text::lit("\n"))))))
        };
        if leaves_f(e_p3) {
            {
                let cp_p0x = cp_p0.clone();
                let e_p3x = e_p3.clone();
                crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), e_p3x.clone()), move |cpp_expr_f_10875: crate::prelude::Text| k_let10849(crate::prelude::Text::from(format!("{};", &cpp_expr_f_10875))))
            }
        } else {
            {
                let cp_p0x = cp_p0.clone();
                let e_p3x = e_p3.clone();
                crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), e_p3x.clone()), move |cpp_expr_f_10910: crate::prelude::Text| k_let10849(crate::prelude::Text::from(format!("{}_v.set({});", &l_p5, &cpp_expr_f_10910))))
            }
        }
    }
}

/// `Start CppLabeled, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_labeled_f(cp_p0: crate::emit::cpp::Cp, label_p1: crate::prelude::Text, dos_p2: crate::prelude::Array<crate::lower::model::Do>, e_p3: crate::lower::model::Ex, t_p4: crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppLabeled { cp_p0, label_p1, dos_p2, e_p3, t_p4 })
}

/// ```prism
/// CppLabel: fn Text -> Text
/// ```
pub fn cpp_label_f(l_p0: &crate::prelude::Text) -> crate::prelude::Text {
    if crate::syntax::lexer::chars::has_prefix_f(l_p0, &crate::prelude::Text::lit("\'")) {
        crate::syntax::lexer::chars::after_first_f(l_p0)
    } else {
        l_p0.clone()
    }
}

/// ```prism
/// CppBreak: unbounded fn Cp, Text, Ex -> Text
/// ```
pub fn cpp_break_f(cp_p0: &crate::emit::cpp::Cp, l_p1: &crate::prelude::Text, y_p2: &crate::lower::model::Ex) -> crate::prelude::Text {
    let n_p3 = cpp_label_f(l_p1);
    crate::prelude::Text::from(format!("{{ {}_v.set({}); goto {}; }}", &n_p3, &crate::emit::cpp::expr::cpp_expr_f(cp_p0, y_p2), &n_p3))
}

/// The step machine of `CppBreak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppBreak: unbounded fn Cp, Text, Ex -> Text
/// ```
pub struct CppBreak {
    pub cp_p0: crate::emit::cpp::Cp,
    pub l_p1: crate::prelude::Text,
    pub y_p2: crate::lower::model::Ex,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppBreak {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let l_p1 = &self.l_p1;
        let y_p2 = &self.y_p2;
        let n_p3 = cpp_label_f(l_p1);
        let cp_p0x = cp_p0.clone();
        let y_p2x = y_p2.clone();
        crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), y_p2x.clone()), move |cpp_expr_f_11222: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{{ {}_v.set({}); goto {}; }}", &n_p3, &cpp_expr_f_11222, &n_p3))))
    }
}

/// `Start CppBreak, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_break_f(cp_p0: crate::emit::cpp::Cp, l_p1: crate::prelude::Text, y_p2: crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppBreak { cp_p0, l_p1, y_p2 })
}
