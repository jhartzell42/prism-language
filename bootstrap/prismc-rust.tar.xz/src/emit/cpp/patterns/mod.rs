//! The module `Emit.Cpp.Patterns`, from `target/bootstrap/src/prismc/emit/cpp/patterns.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// PatConds: unbounded fn Cp, Pa, Text -> [Text]
/// ```
pub fn pat_conds(cp: &crate::emit::cpp::Cp, p_: &crate::lower::model::Pa, v_: &Text) -> Array<Text> {
    match p_ {
        crate::lower::model::Pa::PaWild => Array::new(),
        crate::lower::model::Pa::PaBind(_) => Array::new(),
        crate::lower::model::Pa::PaMut(_) => Array::new(),
        crate::lower::model::Pa::PaTyped(q, _) => pat_conds(cp, &**q, v_),
        crate::lower::model::Pa::PaUnit(c) => Array::from(vec![crate::emit::cpp::expr::case_test(cp, c, v_)]),
        crate::lower::model::Pa::PaCtor(c, ps) => {
            let own = crate::emit::cpp::expr::case_test(cp, c, v_);
            let inner = concat2(&run_to_end(each_job(crate::check::errors::range0(&len(ps)), {
                let cp = cp.clone();
                let ps = ps.clone();
                let c = c.clone();
                let v_ = v_.clone();
                Rc::new(move |p0: Nat| {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let c = c.clone();
                    let v_ = v_.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(PatConds { cp: cp.clone(), p_: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), v_: crate::emit::cpp::expr::payload(&cp, &c, &v_, &i) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            })));
            filter(&append(&Array::from(vec![own.clone()]), &inner), &(|t: &Text| t != &Text::lit("true")))
        },
        crate::lower::model::Pa::PaRecord(c, fs, _) => concat2(&run_to_end(each_job(fs.clone(), {
            let cp = cp.clone();
            let v_ = v_.clone();
            Rc::new(move |p0: (Text, crate::lower::model::Pa)| {
                let cp = cp.clone();
                let v_ = v_.clone();
                entered(once_job(move || {
                    let (f, q) = p0;
                    prism_rtl::Turn::More(Rc::new(PatConds { cp: cp.clone(), p_: q.clone(), v_: Text::from(format!("{}.{}", &v_, &crate::emit::cpp::field_id(&f))) }))
                }))
            }) as Rc<dyn Fn((Text, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }))),
        crate::lower::model::Pa::PaTuple(ps) => concat2(&run_to_end(each_job(crate::check::errors::range0(&len(ps)), {
            let cp = cp.clone();
            let ps = ps.clone();
            let v_ = v_.clone();
            Rc::new(move |p0: Nat| {
                let cp = cp.clone();
                let ps = ps.clone();
                let v_ = v_.clone();
                entered(once_job(move || {
                    let i = p0;
                    prism_rtl::Turn::More(Rc::new(PatConds { cp: cp.clone(), p_: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), v_: Text::from(format!("std::get<{}>({})", &i, &v_)) }))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }))),
        crate::lower::model::Pa::PaChar(c) => Array::from(vec![Text::from(format!("{} == U\'{}\'", v_, &crate::emit::cpp::expr::cpp_char_escape(c)))]),
        crate::lower::model::Pa::PaBool(b) => Array::from(vec![if *b { v_.clone() } else { Text::from(format!("!{}", v_)) }]),
        crate::lower::model::Pa::PaIndex(n) => Array::from(vec![Text::from(format!("{} == {}u", v_, n))]),
        crate::lower::model::Pa::PaConst(n) => Array::from(vec![Text::from(format!("{} == {}", v_, n))]),
        crate::lower::model::Pa::PaSlice(ps) => {
            let rest = fold(ps, &false, &(|f: &bool, q: &crate::lower::model::Pa| *f || is_rest(q)));
            let fixed = len(&filter(ps, &(|q: &crate::lower::model::Pa| !is_rest(q))));
            let size_ = if rest {
                Text::from(format!("{}.size() >= {}", v_, &fixed))
            } else {
                Text::from(format!("{}.size() == {}", v_, &fixed))
            };
            append(&Array::from(vec![size_.clone()]), &concat2(&run_to_end(each_job(crate::check::errors::range0(&len(ps)), {
                let cp = cp.clone();
                let ps = ps.clone();
                let v_ = v_.clone();
                Rc::new(move |p0: Nat| {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let v_ = v_.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(PatConds { cp: cp.clone(), p_: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), v_: Text::from(format!("{}[{}]", &v_, &i)) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }))))
        },
        crate::lower::model::Pa::PaRest(_) => Array::new(),
    }
}

/// The step machine of `PatConds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatConds: unbounded fn Cp, Pa, Text -> [Text]
/// ```
pub struct PatConds {
    pub cp: crate::emit::cpp::Cp,
    pub p_: crate::lower::model::Pa,
    pub v_: Text,
}

impl prism_rtl::Job<Array<Text>> for PatConds {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cp = &self.cp;
        let p_ = &self.p_;
        let v_ = &self.v_;
        match p_ {
            crate::lower::model::Pa::PaWild => prism_rtl::Turn::Finished(Array::new()),
            crate::lower::model::Pa::PaBind(_) => prism_rtl::Turn::Finished(Array::new()),
            crate::lower::model::Pa::PaMut(_) => prism_rtl::Turn::Finished(Array::new()),
            crate::lower::model::Pa::PaTyped(q, _) => prism_rtl::Turn::More(Rc::new(PatConds { cp: cp.clone(), p_: (**q).clone(), v_: v_.clone() })),
            crate::lower::model::Pa::PaUnit(c) => prism_rtl::Turn::Finished(Array::from(vec![crate::emit::cpp::expr::case_test(cp, c, v_)])),
            crate::lower::model::Pa::PaCtor(c, ps) => {
                let own = crate::emit::cpp::expr::case_test(cp, c, v_);
                let c = c.clone();
                let cp = cp.clone();
                let ps = ps.clone();
                let v_ = v_.clone();
                call_value(each_job(crate::check::errors::range0(&len(&ps)), {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let c = c.clone();
                    let v_ = v_.clone();
                    Rc::new(move |p0: Nat| {
                        let cp = cp.clone();
                        let ps = ps.clone();
                        let c = c.clone();
                        let v_ = v_.clone();
                        entered(once_job(move || {
                            let i = p0;
                            prism_rtl::Turn::More(Rc::new(PatConds { cp: cp.clone(), p_: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), v_: crate::emit::cpp::expr::payload(&cp, &c, &v_, &i) }))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_1488: Array<Array<Text>>| {
                    let inner = concat2(&each_1488);
                    prism_rtl::Turn::Finished(filter(&append(&Array::from(vec![own.clone()]), &inner), &(|t: &Text| t != &Text::lit("true"))))
                })
            },
            crate::lower::model::Pa::PaRecord(c, fs, _) => {
                let cp = cp.clone();
                let fs = fs.clone();
                let v_ = v_.clone();
                call_value(each_job(fs.clone(), {
                    let cp = cp.clone();
                    let v_ = v_.clone();
                    Rc::new(move |p0: (Text, crate::lower::model::Pa)| {
                        let cp = cp.clone();
                        let v_ = v_.clone();
                        entered(once_job(move || {
                            let (f, q) = p0;
                            prism_rtl::Turn::More(Rc::new(PatConds { cp: cp.clone(), p_: q.clone(), v_: Text::from(format!("{}.{}", &v_, &crate::emit::cpp::field_id(&f))) }))
                        }))
                    }) as Rc<dyn Fn((Text, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_1667: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_1667)))
            },
            crate::lower::model::Pa::PaTuple(ps) => {
                let cp = cp.clone();
                let ps = ps.clone();
                let v_ = v_.clone();
                call_value(each_job(crate::check::errors::range0(&len(&ps)), {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let v_ = v_.clone();
                    Rc::new(move |p0: Nat| {
                        let cp = cp.clone();
                        let ps = ps.clone();
                        let v_ = v_.clone();
                        entered(once_job(move || {
                            let i = p0;
                            prism_rtl::Turn::More(Rc::new(PatConds { cp: cp.clone(), p_: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), v_: Text::from(format!("std::get<{}>({})", &i, &v_)) }))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_1748: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_1748)))
            },
            crate::lower::model::Pa::PaChar(c) => prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("{} == U\'{}\'", v_, &crate::emit::cpp::expr::cpp_char_escape(c)))])),
            crate::lower::model::Pa::PaBool(b) => prism_rtl::Turn::Finished(Array::from(vec![if *b { v_.clone() } else { Text::from(format!("!{}", v_)) }])),
            crate::lower::model::Pa::PaIndex(n) => prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("{} == {}u", v_, n))])),
            crate::lower::model::Pa::PaConst(n) => prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("{} == {}", v_, n))])),
            crate::lower::model::Pa::PaSlice(ps) => {
                let rest = fold(ps, &false, &(|f: &bool, q: &crate::lower::model::Pa| *f || is_rest(q)));
                let fixed = len(&filter(ps, &(|q: &crate::lower::model::Pa| !is_rest(q))));
                let size_ = if rest {
                    Text::from(format!("{}.size() >= {}", v_, &fixed))
                } else {
                    Text::from(format!("{}.size() == {}", v_, &fixed))
                };
                let cp = cp.clone();
                let ps = ps.clone();
                let v_ = v_.clone();
                call_value(each_job(crate::check::errors::range0(&len(&ps)), {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let v_ = v_.clone();
                    Rc::new(move |p0: Nat| {
                        let cp = cp.clone();
                        let ps = ps.clone();
                        let v_ = v_.clone();
                        entered(once_job(move || {
                            let i = p0;
                            prism_rtl::Turn::More(Rc::new(PatConds { cp: cp.clone(), p_: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), v_: Text::from(format!("{}[{}]", &v_, &i)) }))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_2231: Array<Array<Text>>| prism_rtl::Turn::Finished(append(&Array::from(vec![size_.clone()]), &concat2(&each_2231))))
            },
            crate::lower::model::Pa::PaRest(_) => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start PatConds, x`: what the function value is when passed to `@Run`.
pub fn start_pat_conds(cp: crate::emit::cpp::Cp, p_: crate::lower::model::Pa, v_: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(PatConds { cp, p_, v_ })
}

/// ```prism
/// PatBinds: unbounded fn Cp, Pa, Text -> [Text]
/// ```
pub fn pat_binds(cp: &crate::emit::cpp::Cp, p_: &crate::lower::model::Pa, v_: &Text) -> Array<Text> {
    'm2400: {
        if let crate::lower::model::Pa::PaWild = p_ {
            break 'm2400 Array::new();
        }
        if let crate::lower::model::Pa::PaBind(n) = p_ {
            break 'm2400 Array::from(vec![Text::from(format!("auto&& {} = {};", &crate::emit::cpp::cpp_id(n), v_))]);
        }
        if let crate::lower::model::Pa::PaMut(n) = p_ {
            break 'm2400 Array::from(vec![Text::from(format!("auto {} = {};", &crate::emit::cpp::cpp_id(n), v_))]);
        }
        if let crate::lower::model::Pa::PaTyped(m2400_3_0, t) = p_ && let crate::lower::model::Pa::PaBind(n) = &**m2400_3_0 {
            break 'm2400 Array::from(vec![Text::from(format!("{} {} = {};", &crate::emit::cpp::cpp_type(cp, &crate::emit::cpp::expr::unref(t)), &crate::emit::cpp::cpp_id(n), v_))]);
        }
        if let crate::lower::model::Pa::PaTyped(q, _) = p_ {
            break 'm2400 pat_binds(cp, &**q, v_);
        }
        if let crate::lower::model::Pa::PaUnit(_) = p_ {
            break 'm2400 Array::new();
        }
        if let crate::lower::model::Pa::PaCtor(c, ps) = p_ {
            break 'm2400 concat2(&run_to_end(each_job(crate::check::errors::range0(&len(ps)), {
                let cp = cp.clone();
                let ps = ps.clone();
                let c = c.clone();
                let v_ = v_.clone();
                Rc::new(move |p0: Nat| {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let c = c.clone();
                    let v_ = v_.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(PatBinds { cp: cp.clone(), p_: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), v_: crate::emit::cpp::expr::payload(&cp, &c, &v_, &i) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            })));
        }
        if let crate::lower::model::Pa::PaRecord(c, fs, _) = p_ {
            break 'm2400 concat2(&run_to_end(each_job(fs.clone(), {
                let cp = cp.clone();
                let v_ = v_.clone();
                Rc::new(move |p0: (Text, crate::lower::model::Pa)| {
                    let cp = cp.clone();
                    let v_ = v_.clone();
                    entered(once_job(move || {
                        let (f, q) = p0;
                        prism_rtl::Turn::More(Rc::new(PatBinds { cp: cp.clone(), p_: q.clone(), v_: Text::from(format!("{}.{}", &v_, &crate::emit::cpp::field_id(&f))) }))
                    }))
                }) as Rc<dyn Fn((Text, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            })));
        }
        if let crate::lower::model::Pa::PaTuple(ps) = p_ {
            break 'm2400 concat2(&run_to_end(each_job(crate::check::errors::range0(&len(ps)), {
                let cp = cp.clone();
                let ps = ps.clone();
                let v_ = v_.clone();
                Rc::new(move |p0: Nat| {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let v_ = v_.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(PatBinds { cp: cp.clone(), p_: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), v_: Text::from(format!("std::get<{}>({})", &i, &v_)) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            })));
        }
        if let crate::lower::model::Pa::PaSlice(ps) = p_ {
            break 'm2400 concat2(&run_to_end(each_job(crate::check::errors::range0(&len(ps)), {
                let cp = cp.clone();
                let ps = ps.clone();
                let v_ = v_.clone();
                Rc::new(move |p0: Nat| {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let v_ = v_.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(SliceBinds { cp: cp.clone(), pa1: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), v_: v_.clone(), i: i.clone() }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            })));
        }
        Array::new()
    }
}

/// The step machine of `PatBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatBinds: unbounded fn Cp, Pa, Text -> [Text]
/// ```
pub struct PatBinds {
    pub cp: crate::emit::cpp::Cp,
    pub p_: crate::lower::model::Pa,
    pub v_: Text,
}

impl prism_rtl::Job<Array<Text>> for PatBinds {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cp = &self.cp;
        let p_ = &self.p_;
        let v_ = &self.v_;
        'm2400: {
            if let crate::lower::model::Pa::PaWild = p_ {
                break 'm2400 prism_rtl::Turn::Finished(Array::new());
            }
            if let crate::lower::model::Pa::PaBind(n) = p_ {
                break 'm2400 prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("auto&& {} = {};", &crate::emit::cpp::cpp_id(n), v_))]));
            }
            if let crate::lower::model::Pa::PaMut(n) = p_ {
                break 'm2400 prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("auto {} = {};", &crate::emit::cpp::cpp_id(n), v_))]));
            }
            if let crate::lower::model::Pa::PaTyped(m2400_3_0, t) = p_ && let crate::lower::model::Pa::PaBind(n) = &**m2400_3_0 {
                break 'm2400 {
                    let cp = cp.clone();
                    let n = n.clone();
                    let t = t.clone();
                    let v_ = v_.clone();
                    call_then(crate::emit::cpp::start_cpp_type(cp.clone(), crate::emit::cpp::expr::unref(&t)), move |cpp_type_2542: Text| prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("{} {} = {};", &cpp_type_2542, &crate::emit::cpp::cpp_id(&n), &v_))])))
                };
            }
            if let crate::lower::model::Pa::PaTyped(q, _) = p_ {
                break 'm2400 prism_rtl::Turn::More(Rc::new(PatBinds { cp: cp.clone(), p_: (**q).clone(), v_: v_.clone() }));
            }
            if let crate::lower::model::Pa::PaUnit(_) = p_ {
                break 'm2400 prism_rtl::Turn::Finished(Array::new());
            }
            if let crate::lower::model::Pa::PaCtor(c, ps) = p_ {
                break 'm2400 {
                    let c = c.clone();
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let v_ = v_.clone();
                    call_value(each_job(crate::check::errors::range0(&len(&ps)), {
                        let cp = cp.clone();
                        let ps = ps.clone();
                        let c = c.clone();
                        let v_ = v_.clone();
                        Rc::new(move |p0: Nat| {
                            let cp = cp.clone();
                            let ps = ps.clone();
                            let c = c.clone();
                            let v_ = v_.clone();
                            entered(once_job(move || {
                                let i = p0;
                                prism_rtl::Turn::More(Rc::new(PatBinds { cp: cp.clone(), p_: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), v_: crate::emit::cpp::expr::payload(&cp, &c, &v_, &i) }))
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }), move |each_2677: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_2677)))
                };
            }
            if let crate::lower::model::Pa::PaRecord(c, fs, _) = p_ {
                break 'm2400 {
                    let cp = cp.clone();
                    let fs = fs.clone();
                    let v_ = v_.clone();
                    call_value(each_job(fs.clone(), {
                        let cp = cp.clone();
                        let v_ = v_.clone();
                        Rc::new(move |p0: (Text, crate::lower::model::Pa)| {
                            let cp = cp.clone();
                            let v_ = v_.clone();
                            entered(once_job(move || {
                                let (f, q) = p0;
                                prism_rtl::Turn::More(Rc::new(PatBinds { cp: cp.clone(), p_: q.clone(), v_: Text::from(format!("{}.{}", &v_, &crate::emit::cpp::field_id(&f))) }))
                            }))
                        }) as Rc<dyn Fn((Text, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }), move |each_2799: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_2799)))
                };
            }
            if let crate::lower::model::Pa::PaTuple(ps) = p_ {
                break 'm2400 {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let v_ = v_.clone();
                    call_value(each_job(crate::check::errors::range0(&len(&ps)), {
                        let cp = cp.clone();
                        let ps = ps.clone();
                        let v_ = v_.clone();
                        Rc::new(move |p0: Nat| {
                            let cp = cp.clone();
                            let ps = ps.clone();
                            let v_ = v_.clone();
                            entered(once_job(move || {
                                let i = p0;
                                prism_rtl::Turn::More(Rc::new(PatBinds { cp: cp.clone(), p_: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), v_: Text::from(format!("std::get<{}>({})", &i, &v_)) }))
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }), move |each_2880: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_2880)))
                };
            }
            if let crate::lower::model::Pa::PaSlice(ps) = p_ {
                break 'm2400 {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let v_ = v_.clone();
                    call_value(each_job(crate::check::errors::range0(&len(&ps)), {
                        let cp = cp.clone();
                        let ps = ps.clone();
                        let v_ = v_.clone();
                        Rc::new(move |p0: Nat| {
                            let cp = cp.clone();
                            let ps = ps.clone();
                            let v_ = v_.clone();
                            entered(once_job(move || {
                                let i = p0;
                                prism_rtl::Turn::More(Rc::new(SliceBinds { cp: cp.clone(), pa1: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), v_: v_.clone(), i: i.clone() }))
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }), move |each_2989: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_2989)))
                };
            }
            prism_rtl::Turn::Finished(Array::new())
        }
    }
}

/// `Start PatBinds, x`: what the function value is when passed to `@Run`.
pub fn start_pat_binds(cp: crate::emit::cpp::Cp, p_: crate::lower::model::Pa, v_: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(PatBinds { cp, p_, v_ })
}

/// ```prism
/// SliceBinds: unbounded fn Cp, Pa, Text, Nat -> [Text]
/// ```
pub fn slice_binds(cp: &crate::emit::cpp::Cp, pa1: &crate::lower::model::Pa, v_: &Text, i: &Nat) -> Array<Text> {
    match pa1 {
        crate::lower::model::Pa::PaRest(c0_1_0) if (c0_1_0 == &Text::lit("")) => Array::new(),
        crate::lower::model::Pa::PaRest(n) => Array::from(vec![Text::from(format!("auto {} = {}.subspan({});", &crate::emit::cpp::cpp_id(n), v_, i))]),
        p_ => pat_binds(cp, p_, &Text::from(format!("{}[{}]", v_, i))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `SliceBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SliceBinds: unbounded fn Cp, Pa, Text, Nat -> [Text]
/// ```
pub struct SliceBinds {
    pub cp: crate::emit::cpp::Cp,
    pub pa1: crate::lower::model::Pa,
    pub v_: Text,
    pub i: Nat,
}

impl prism_rtl::Job<Array<Text>> for SliceBinds {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cp = &self.cp;
        let pa1 = &self.pa1;
        let v_ = &self.v_;
        let i = &self.i;
        match pa1 {
            crate::lower::model::Pa::PaRest(j0_1_0) if (j0_1_0 == &Text::lit("")) => prism_rtl::Turn::Finished(Array::new()),
            crate::lower::model::Pa::PaRest(n) => prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("auto {} = {}.subspan({});", &crate::emit::cpp::cpp_id(n), v_, i))])),
            p_ => prism_rtl::Turn::More(Rc::new(PatBinds { cp: cp.clone(), p_: p_.clone(), v_: Text::from(format!("{}[{}]", v_, i)) })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start SliceBinds, x`: what the function value is when passed to `@Run`.
pub fn start_slice_binds(cp: crate::emit::cpp::Cp, pa1: crate::lower::model::Pa, v_: Text, i: Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SliceBinds { cp, pa1, v_, i })
}

/// ```prism
/// IsRest: fn Pa -> Bool
/// ```
pub fn is_rest(pa0: &crate::lower::model::Pa) -> bool {
    match pa0 {
        crate::lower::model::Pa::PaRest(_) => true,
        other => false,
    }
}

/// ```prism
/// Concat2: fn [ [Text] ] -> [Text]
/// ```
pub fn concat2(xss: &Array<Array<Text>>) -> Array<Text> {
    fold(xss, &Array::new(), &(|acc: &Array<Text>, xs: &Array<Text>| append(acc, xs)))
}

/// ```prism
/// Conds: fn [Text] -> Text
/// ```
pub fn conds(xs0: &Array<Text>) -> Text {
    match xs0 {
        c0_0 if (c0_0.len() == 0) => Text::lit("true"),
        cs => crate::syntax::lexer::chars::join(cs, &Text::lit(" && ")),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IsCatchAll: fn Pa -> Bool
/// ```
pub fn is_catch_all(p_: &crate::lower::model::Pa) -> bool {
    match p_ {
        crate::lower::model::Pa::PaWild => true,
        crate::lower::model::Pa::PaBind(_) => true,
        crate::lower::model::Pa::PaMut(_) => true,
        crate::lower::model::Pa::PaTyped(q, _) => is_catch_all(&**q),
        _ => false,
    }
}

/// ```prism
/// Leaves: fn Ex -> Bool
/// ```
pub fn leaves(x: &crate::lower::model::Ex) -> bool {
    match x {
        crate::lower::model::Ex::XBreak(_, _) => true,
        crate::lower::model::Ex::XBreakLoop => true,
        crate::lower::model::Ex::XUnreachable => true,
        _ => false,
    }
}

/// ```prism
/// CppMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
/// ```
pub fn cpp_match(cp: &crate::emit::cpp::Cp, s: &crate::lower::model::Ex, arms: &Array<crate::lower::model::XArm>, out_ty3: &crate::lower::model::OutTy) -> Text {
    match out_ty3 {
        crate::lower::model::OutTy::OutUnknown(what) => ternary_match(cp, s, arms),
        t => {
            let bound_opt = 'm4524: {
                if let crate::lower::model::Ex::XVar(n) = s {
                    break 'm4524 Some(crate::emit::cpp::stmts::var_name(cp, n));
                }
                if let crate::lower::model::Ex::XRef(m4524_1_0) = s && let crate::lower::model::Ex::XVar(n) = &**m4524_1_0 {
                    break 'm4524 Some(crate::emit::cpp::stmts::var_name(cp, n));
                }
                None
            };
            let subject = or(&bound_opt, &Text::lit("_m"));
            let bind = match &bound_opt {
                Some(_) => Text::lit(""),
                None => Text::from(format!("auto&& _m = {};\n", &crate::emit::cpp::expr::cpp_expr(cp, s))),
            };
            let lines = run_to_end(each_job(arms.clone(), {
                let cp = cp.clone();
                let subject = subject.clone();
                Rc::new(move |p0: crate::lower::model::XArm| {
                    let cp = cp.clone();
                    let subject = subject.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(MatchArm { cp0: cp.clone(), subject: subject.clone(), a: a.clone(), returns: false }))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            crate::emit::cpp::templates::items::match_expr(&crate::emit::cpp::cpp_type(cp, t), &Text::from(format!("{}{}\n{}", &bind, &crate::syntax::lexer::chars::join(&lines, &Text::lit("\n")), &match_tail(arms))))
        },
    }
}

/// The step machine of `CppMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
/// ```
pub struct CppMatch {
    pub cp: crate::emit::cpp::Cp,
    pub s: crate::lower::model::Ex,
    pub arms: Array<crate::lower::model::XArm>,
    pub out_ty3: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for CppMatch {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let s = &self.s;
        let arms = &self.arms;
        let out_ty3 = &self.out_ty3;
        match out_ty3 {
            crate::lower::model::OutTy::OutUnknown(what) => prism_rtl::Turn::More(Rc::new(TernaryMatch { cp: cp.clone(), s: s.clone(), arms: arms.clone() })),
            t => {
                let bound_opt = 'm4524: {
                    if let crate::lower::model::Ex::XVar(n) = s {
                        break 'm4524 Some(crate::emit::cpp::stmts::var_name(cp, n));
                    }
                    if let crate::lower::model::Ex::XRef(m4524_1_0) = s && let crate::lower::model::Ex::XVar(n) = &**m4524_1_0 {
                        break 'm4524 Some(crate::emit::cpp::stmts::var_name(cp, n));
                    }
                    None
                };
                let subject = or(&bound_opt, &Text::lit("_m"));
                let bind = match &bound_opt {
                    Some(_) => Text::lit(""),
                    None => Text::from(format!("auto&& _m = {};\n", &crate::emit::cpp::expr::cpp_expr(cp, s))),
                };
                let arms = arms.clone();
                let cp = cp.clone();
                let s = s.clone();
                let t = t.clone();
                call_value(each_job(arms.clone(), {
                    let cp = cp.clone();
                    let subject = subject.clone();
                    Rc::new(move |p0: crate::lower::model::XArm| {
                        let cp = cp.clone();
                        let subject = subject.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(MatchArm { cp0: cp.clone(), subject: subject.clone(), a: a.clone(), returns: false }))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_4777: Array<Text>| {
                    let lines = each_4777;
                    call_then(crate::emit::cpp::start_cpp_type(cp.clone(), t.clone()), move |cpp_type_4839: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::match_expr(&cpp_type_4839, &Text::from(format!("{}{}\n{}", &bind, &crate::syntax::lexer::chars::join(&lines, &Text::lit("\n")), &match_tail(&arms))))))
                })
            },
        }
    }
}

/// `Start CppMatch, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_match(cp: crate::emit::cpp::Cp, s: crate::lower::model::Ex, arms: Array<crate::lower::model::XArm>, out_ty3: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppMatch { cp, s, arms, out_ty3 })
}

/// ```prism
/// ReturnMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
/// ```
pub fn return_match(cp: &crate::emit::cpp::Cp, s: &crate::lower::model::Ex, arms: &Array<crate::lower::model::XArm>, out_ty3: &crate::lower::model::OutTy) -> Text {
    match out_ty3 {
        crate::lower::model::OutTy::OutUnknown(what) => Text::from(format!("return {};", &ternary_match(cp, s, arms))),
        t => {
            let bound_opt = 'm5310: {
                if let crate::lower::model::Ex::XVar(n) = s {
                    break 'm5310 Some(crate::emit::cpp::stmts::var_name(cp, n));
                }
                if let crate::lower::model::Ex::XRef(m5310_1_0) = s && let crate::lower::model::Ex::XVar(n) = &**m5310_1_0 {
                    break 'm5310 Some(crate::emit::cpp::stmts::var_name(cp, n));
                }
                None
            };
            let subject = or(&bound_opt, &Text::lit("_m"));
            let bind = match &bound_opt {
                Some(_) => Text::lit(""),
                None => Text::from(format!("auto&& _m = {};\n", &crate::emit::cpp::expr::cpp_expr(cp, s))),
            };
            let lines = run_to_end(each_job(arms.clone(), {
                let cp = cp.clone();
                let subject = subject.clone();
                Rc::new(move |p0: crate::lower::model::XArm| {
                    let cp = cp.clone();
                    let subject = subject.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(MatchArm { cp0: cp.clone(), subject: subject.clone(), a: a.clone(), returns: true }))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            Text::from(format!("{}{}\n{}", &bind, &crate::syntax::lexer::chars::join(&lines, &Text::lit("\n")), &match_tail(arms)))
        },
    }
}

/// The step machine of `ReturnMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReturnMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
/// ```
pub struct ReturnMatch {
    pub cp: crate::emit::cpp::Cp,
    pub s: crate::lower::model::Ex,
    pub arms: Array<crate::lower::model::XArm>,
    pub out_ty3: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for ReturnMatch {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let s = &self.s;
        let arms = &self.arms;
        let out_ty3 = &self.out_ty3;
        match out_ty3 {
            crate::lower::model::OutTy::OutUnknown(what) => {
                let arms = arms.clone();
                let cp = cp.clone();
                let s = s.clone();
                call_then(start_ternary_match(cp.clone(), s.clone(), arms.clone()), move |ternary_match_5234: Text| prism_rtl::Turn::Finished(Text::from(format!("return {};", &ternary_match_5234))))
            },
            t => {
                let bound_opt = 'm5310: {
                    if let crate::lower::model::Ex::XVar(n) = s {
                        break 'm5310 Some(crate::emit::cpp::stmts::var_name(cp, n));
                    }
                    if let crate::lower::model::Ex::XRef(m5310_1_0) = s && let crate::lower::model::Ex::XVar(n) = &**m5310_1_0 {
                        break 'm5310 Some(crate::emit::cpp::stmts::var_name(cp, n));
                    }
                    None
                };
                let subject = or(&bound_opt, &Text::lit("_m"));
                let bind = match &bound_opt {
                    Some(_) => Text::lit(""),
                    None => Text::from(format!("auto&& _m = {};\n", &crate::emit::cpp::expr::cpp_expr(cp, s))),
                };
                let arms = arms.clone();
                let cp = cp.clone();
                let s = s.clone();
                call_value(each_job(arms.clone(), {
                    let cp = cp.clone();
                    let subject = subject.clone();
                    Rc::new(move |p0: crate::lower::model::XArm| {
                        let cp = cp.clone();
                        let subject = subject.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(MatchArm { cp0: cp.clone(), subject: subject.clone(), a: a.clone(), returns: true }))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_5563: Array<Text>| {
                    let lines = each_5563;
                    prism_rtl::Turn::Finished(Text::from(format!("{}{}\n{}", &bind, &crate::syntax::lexer::chars::join(&lines, &Text::lit("\n")), &match_tail(&arms))))
                })
            },
        }
    }
}

/// `Start ReturnMatch, x`: what the function value is when passed to `@Run`.
pub fn start_return_match(cp: crate::emit::cpp::Cp, s: crate::lower::model::Ex, arms: Array<crate::lower::model::XArm>, out_ty3: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ReturnMatch { cp, s, arms, out_ty3 })
}

/// ```prism
/// MatchTail: fn [XArm] -> Text
/// ```
pub fn match_tail(arms: &Array<crate::lower::model::XArm>) -> Text {
    let ends = match crate::syntax::lexer::chars::last(arms) {
        Some(a) => is_catch_all(&a.pat) && (&len(&a.conds) == &Nat::from(0u32)),
        None => false,
    };
    if ends {
        Text::lit("")
    } else {
        Text::lit("prism_rtl::unreachable(\"no arm matched\");\n")
    }
}

/// ```prism
/// TernaryMatch: unbounded fn Cp, Ex, [XArm] -> Text
/// ```
pub fn ternary_match(cp: &crate::emit::cpp::Cp, s: &crate::lower::model::Ex, arms: &Array<crate::lower::model::XArm>) -> Text {
    let bound_opt = 'm6295: {
        if let crate::lower::model::Ex::XVar(n) = s {
            break 'm6295 Some(crate::emit::cpp::stmts::var_name(cp, n));
        }
        if let crate::lower::model::Ex::XRef(m6295_1_0) = s && let crate::lower::model::Ex::XVar(n) = &**m6295_1_0 {
            break 'm6295 Some(crate::emit::cpp::stmts::var_name(cp, n));
        }
        None
    };
    let subject = or(&bound_opt, &Text::lit("_m"));
    let bind = match &bound_opt {
        Some(_) => Text::lit(""),
        None => Text::from(format!("auto&& _m = {};\n", &crate::emit::cpp::expr::cpp_expr(cp, s))),
    };
    let reached = run_to_end(fold_job(arms.clone(), (Array::new(), false), {
        let cp = cp.clone();
        let subject = subject.clone();
        Rc::new(move |(p0, p1): ((Array<crate::lower::model::XArm>, bool), crate::lower::model::XArm)| {
            let cp = cp.clone();
            let subject = subject.clone();
            entered(once_job(move || {
                let (acc, done) = p0;
                let a = p1;
                if done {
                    prism_rtl::Turn::Finished((acc.clone(), done))
                } else {
                    call_then(start_pat_conds(cp.clone(), a.pat.clone(), subject.clone()), move |pat_conds_6734: Array<Text>| prism_rtl::Turn::Finished((push(&acc, &a), (&len(&pat_conds_6734) == &Nat::from(0u32)) && (&len(&a.conds) == &Nat::from(0u32)))))
                }
            }))
        }) as Rc<dyn Fn(((Array<crate::lower::model::XArm>, bool), crate::lower::model::XArm)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::XArm>, bool)>>>
    }));
    let (kept, ends) = reached.clone();
    let parts = run_to_end(each_job(kept.clone(), {
        let cp = cp.clone();
        let subject = subject.clone();
        Rc::new(move |p0: crate::lower::model::XArm| {
            let cp = cp.clone();
            let subject = subject.clone();
            entered(once_job(move || {
                let a = p0;
                prism_rtl::Turn::More(Rc::new(TernaryArm { cp0: cp.clone(), subject: subject.clone(), a: a.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let last_text = if ends {
        Text::lit("")
    } else {
        Text::lit("\n    : throw prism_rtl::Panic(\"no arm matched\")")
    };
    crate::emit::cpp::templates::items::stmt_expr(&Text::from(format!("{}", &bind)), &Text::from(format!("{}{}", &crate::syntax::lexer::chars::join(&parts, &Text::lit("\n    : ")), &last_text)))
}

/// The step machine of `TernaryMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TernaryMatch: unbounded fn Cp, Ex, [XArm] -> Text
/// ```
pub struct TernaryMatch {
    pub cp: crate::emit::cpp::Cp,
    pub s: crate::lower::model::Ex,
    pub arms: Array<crate::lower::model::XArm>,
}

impl prism_rtl::Job<Text> for TernaryMatch {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let s = &self.s;
        let arms = &self.arms;
        let bound_opt = 'm6295: {
            if let crate::lower::model::Ex::XVar(n) = s {
                break 'm6295 Some(crate::emit::cpp::stmts::var_name(cp, n));
            }
            if let crate::lower::model::Ex::XRef(m6295_1_0) = s && let crate::lower::model::Ex::XVar(n) = &**m6295_1_0 {
                break 'm6295 Some(crate::emit::cpp::stmts::var_name(cp, n));
            }
            None
        };
        let subject = or(&bound_opt, &Text::lit("_m"));
        let bind = match &bound_opt {
            Some(_) => Text::lit(""),
            None => Text::from(format!("auto&& _m = {};\n", &crate::emit::cpp::expr::cpp_expr(cp, s))),
        };
        let arms = arms.clone();
        let cp = cp.clone();
        call_value(fold_job(arms.clone(), (Array::new(), false), {
            let cp = cp.clone();
            let subject = subject.clone();
            Rc::new(move |(p0, p1): ((Array<crate::lower::model::XArm>, bool), crate::lower::model::XArm)| {
                let cp = cp.clone();
                let subject = subject.clone();
                entered(once_job(move || {
                    let (acc, done) = p0;
                    let a = p1;
                    if done {
                        prism_rtl::Turn::Finished((acc.clone(), done))
                    } else {
                        call_then(start_pat_conds(cp.clone(), a.pat.clone(), subject.clone()), move |pat_conds_6734: Array<Text>| prism_rtl::Turn::Finished((push(&acc, &a), (&len(&pat_conds_6734) == &Nat::from(0u32)) && (&len(&a.conds) == &Nat::from(0u32)))))
                    }
                }))
            }) as Rc<dyn Fn(((Array<crate::lower::model::XArm>, bool), crate::lower::model::XArm)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::XArm>, bool)>>>
        }), move |fold_6634: (Array<crate::lower::model::XArm>, bool)| {
            let reached = fold_6634;
            let (kept, ends) = reached.clone();
            call_value(each_job(kept.clone(), {
                let cp = cp.clone();
                let subject = subject.clone();
                Rc::new(move |p0: crate::lower::model::XArm| {
                    let cp = cp.clone();
                    let subject = subject.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(TernaryArm { cp0: cp.clone(), subject: subject.clone(), a: a.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_6843: Array<Text>| {
                let parts = each_6843;
                let last_text = if ends {
                    Text::lit("")
                } else {
                    Text::lit("\n    : throw prism_rtl::Panic(\"no arm matched\")")
                };
                prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::stmt_expr(&Text::from(format!("{}", &bind)), &Text::from(format!("{}{}", &crate::syntax::lexer::chars::join(&parts, &Text::lit("\n    : ")), &last_text))))
            })
        })
    }
}

/// `Start TernaryMatch, x`: what the function value is when passed to `@Run`.
pub fn start_ternary_match(cp: crate::emit::cpp::Cp, s: crate::lower::model::Ex, arms: Array<crate::lower::model::XArm>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TernaryMatch { cp, s, arms })
}

/// ```prism
/// TernaryArm: unbounded fn Cp, Text, XArm -> Text
/// ```
pub fn ternary_arm(cp0: &crate::emit::cpp::Cp, subject: &Text, a: &crate::lower::model::XArm) -> Text {
    let cp = crate::emit::cpp::stmts::unbind(cp0, &crate::emit::cpp::stmts::arm_names(a));
    let tests = pat_conds(&cp, &a.pat, subject);
    let binds = pat_binds(&cp, &a.pat, subject);
    let n = len(&a.conds);
    let lets = concat2(&run_to_end(each_job(crate::check::errors::range0(&n), {
        let cp = cp.clone();
        let a = a.clone();
        let n = n.clone();
        Rc::new(move |p0: Nat| {
            let cp = cp.clone();
            let a = a.clone();
            let n = n.clone();
            entered(once_job(move || {
                let i = p0;
                prism_rtl::Turn::More(Rc::new(CondBinds { cp: cp.clone(), cc1: or(&index(&a.conds, &i), &crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XUnit)), k: or(&(&n).checked_sub(&i), &Nat::from(0u32)) }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    })));
    let value = if &(&len(&binds) + &len(&lets)) == &Nat::from(0u32) {
        crate::emit::cpp::expr::cpp_expr(&cp, &a.body)
    } else {
        crate::emit::cpp::templates::items::stmt_expr(&crate::syntax::lexer::chars::join(&append(&binds, &lets), &Text::lit("\n")), &crate::emit::cpp::expr::cpp_expr(&cp, &a.body))
    };
    let guard = if &len(&a.conds) == &Nat::from(0u32) {
        Array::new()
    } else {
        Array::from(vec![crate::emit::cpp::templates::items::stmt_expr(&crate::syntax::lexer::chars::join(&binds, &Text::lit("\n")), &guard_test(&cp, &a.conds))])
    };
    let all = append(&tests, &guard);
    if &len(&all) == &Nat::from(0u32) {
        value.clone()
    } else {
        Text::from(format!("{} ? {}", &conds(&all), &value))
    }
}

/// The step machine of `TernaryArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TernaryArm: unbounded fn Cp, Text, XArm -> Text
/// ```
pub struct TernaryArm {
    pub cp0: crate::emit::cpp::Cp,
    pub subject: Text,
    pub a: crate::lower::model::XArm,
}

impl prism_rtl::Job<Text> for TernaryArm {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp0 = &self.cp0;
        let subject = &self.subject;
        let a = &self.a;
        let a = a.clone();
        let cp0 = cp0.clone();
        let subject = subject.clone();
        call_then(crate::emit::cpp::stmts::start_arm_names(a.clone()), move |arm_names_7141: Array<Text>| {
            let cp = crate::emit::cpp::stmts::unbind(&cp0, &arm_names_7141);
            call_then(start_pat_conds(cp.clone(), a.pat.clone(), subject.clone()), move |pat_conds_7169: Array<Text>| {
                let tests = pat_conds_7169;
                call_then(start_pat_binds(cp.clone(), a.pat.clone(), subject.clone()), move |pat_binds_7213: Array<Text>| {
                    let binds = pat_binds_7213;
                    let n = len(&a.conds);
                    call_value(each_job(crate::check::errors::range0(&n), {
                        let cp = cp.clone();
                        let a = a.clone();
                        let n = n.clone();
                        Rc::new(move |p0: Nat| {
                            let cp = cp.clone();
                            let a = a.clone();
                            let n = n.clone();
                            entered(once_job(move || {
                                let i = p0;
                                prism_rtl::Turn::More(Rc::new(CondBinds { cp: cp.clone(), cc1: or(&index(&a.conds, &i), &crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XUnit)), k: or(&(&n).checked_sub(&i), &Nat::from(0u32)) }))
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }), move |each_7289: Array<Array<Text>>| {
                        let lets = concat2(&each_7289);
                        let value = if &(&len(&binds) + &len(&lets)) == &Nat::from(0u32) {
                            crate::emit::cpp::expr::cpp_expr(&cp, &a.body)
                        } else {
                            crate::emit::cpp::templates::items::stmt_expr(&crate::syntax::lexer::chars::join(&append(&binds, &lets), &Text::lit("\n")), &crate::emit::cpp::expr::cpp_expr(&cp, &a.body))
                        };
                        let guard = if &len(&a.conds) == &Nat::from(0u32) {
                            Array::new()
                        } else {
                            Array::from(vec![crate::emit::cpp::templates::items::stmt_expr(&crate::syntax::lexer::chars::join(&binds, &Text::lit("\n")), &guard_test(&cp, &a.conds))])
                        };
                        let all = append(&tests, &guard);
                        if &len(&all) == &Nat::from(0u32) {
                            prism_rtl::Turn::Finished(value.clone())
                        } else {
                            prism_rtl::Turn::Finished(Text::from(format!("{} ? {}", &conds(&all), &value)))
                        }
                    })
                })
            })
        })
    }
}

/// `Start TernaryArm, x`: what the function value is when passed to `@Run`.
pub fn start_ternary_arm(cp0: crate::emit::cpp::Cp, subject: Text, a: crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TernaryArm { cp0, subject, a })
}

/// ```prism
/// CondBinds: unbounded fn Cp, Cc, Nat -> [Text]
/// ```
pub fn cond_binds(cp: &crate::emit::cpp::Cp, cc1: &crate::lower::model::Cc, k: &Nat) -> Array<Text> {
    match cc1 {
        crate::lower::model::Cc::CcLet(p_, x) => {
            let (v_, pre) = cond_subject(cp, x, k);
            append(&pre, &pat_binds(cp, p_, &v_))
        },
        crate::lower::model::Cc::CcIf(x) => Array::new(),
    }
}

/// The step machine of `CondBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondBinds: unbounded fn Cp, Cc, Nat -> [Text]
/// ```
pub struct CondBinds {
    pub cp: crate::emit::cpp::Cp,
    pub cc1: crate::lower::model::Cc,
    pub k: Nat,
}

impl prism_rtl::Job<Array<Text>> for CondBinds {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cp = &self.cp;
        let cc1 = &self.cc1;
        let k = &self.k;
        match cc1 {
            crate::lower::model::Cc::CcLet(p_, x) => {
                let cp = cp.clone();
                let k = k.clone();
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_cond_subject(cp.clone(), x.clone(), k.clone()), move |cond_subject_7818: (Text, Array<Text>)| {
                    let (v_, pre) = cond_subject_7818;
                    call_then(start_pat_binds(cp.clone(), p_.clone(), v_.clone()), move |pat_binds_7856: Array<Text>| prism_rtl::Turn::Finished(append(&pre, &pat_binds_7856)))
                })
            },
            crate::lower::model::Cc::CcIf(x) => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start CondBinds, x`: what the function value is when passed to `@Run`.
pub fn start_cond_binds(cp: crate::emit::cpp::Cp, cc1: crate::lower::model::Cc, k: Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(CondBinds { cp, cc1, k })
}

/// ```prism
/// CondSubject: unbounded fn Cp, Ex, Nat -> ((Text, [Text]))
/// ```
pub fn cond_subject(cp: &crate::emit::cpp::Cp, x: &crate::lower::model::Ex, k: &Nat) -> (Text, Array<Text>) {
    if is_place_ex(x) {
        (crate::emit::cpp::expr::cpp_tight(cp, x), Array::new())
    } else {
        (Text::from(format!("_c{}", k)), Array::from(vec![Text::from(format!("auto&& _c{} = {};", k, &crate::emit::cpp::expr::cpp_expr(cp, x)))]))
    }
}

/// The step machine of `CondSubject`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondSubject: unbounded fn Cp, Ex, Nat -> ((Text, [Text]))
/// ```
pub struct CondSubject {
    pub cp: crate::emit::cpp::Cp,
    pub x: crate::lower::model::Ex,
    pub k: Nat,
}

impl prism_rtl::Job<(Text, Array<Text>)> for CondSubject {
    fn cycle(&self) -> prism_rtl::Turn<(Text, Array<Text>)> {
        let cp = &self.cp;
        let x = &self.x;
        let k = &self.k;
        if is_place_ex(x) {
            {
                let cp = cp.clone();
                let x = x.clone();
                call_then(crate::emit::cpp::expr::start_cpp_tight(cp.clone(), x.clone()), move |cpp_tight_8273: Text| prism_rtl::Turn::Finished((cpp_tight_8273, Array::new())))
            }
        } else {
            {
                let cp = cp.clone();
                let k = k.clone();
                let x = x.clone();
                call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_8333: Text| prism_rtl::Turn::Finished((Text::from(format!("_c{}", &k)), Array::from(vec![Text::from(format!("auto&& _c{} = {};", &k, &cpp_expr_8333))]))))
            }
        }
    }
}

/// `Start CondSubject, x`: what the function value is when passed to `@Run`.
pub fn start_cond_subject(cp: crate::emit::cpp::Cp, x: crate::lower::model::Ex, k: Nat) -> Rc<dyn prism_rtl::Job<(Text, Array<Text>)>> {
    Rc::new(CondSubject { cp, x, k })
}

/// ```prism
/// IsPlaceEx: fn Ex -> Bool
/// ```
pub fn is_place_ex(x: &crate::lower::model::Ex) -> bool {
    match x {
        crate::lower::model::Ex::XVar(_) => true,
        crate::lower::model::Ex::XField(y, _) => is_place_ex(&**y),
        crate::lower::model::Ex::XPart(y, _) => is_place_ex(&**y),
        crate::lower::model::Ex::XTarget(_) => true,
        crate::lower::model::Ex::XSelf => true,
        crate::lower::model::Ex::XRef(y) => is_place_ex(&**y),
        crate::lower::model::Ex::XDeref(y) => is_place_ex(&**y),
        _ => false,
    }
}

/// ```prism
/// GuardTest: unbounded fn Cp, [Cc] -> Text
/// ```
pub fn guard_test(cp: &crate::emit::cpp::Cp, xs1: &Array<crate::lower::model::Cc>) -> Text {
    match xs1 {
        c0_1 if (c0_1.len() == 0) => Text::lit("true"),
        cs => {
            let first_ = or(&index(cs, &Nat::from(0u32)), &crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XUnit));
            let rest = guard_test(cp, &drop(cs, &Nat::from(1u32)));
            match &first_ {
                crate::lower::model::Cc::CcIf(x) => if &len(cs) == &Nat::from(1u32) {
                    crate::emit::cpp::expr::cpp_tight(cp, x)
                } else {
                    Text::from(format!("{} && {}", &crate::emit::cpp::expr::cpp_tight(cp, x), &rest))
                },
                crate::lower::model::Cc::CcLet(p_, x) => {
                    let (v_, pre) = cond_subject(cp, x, &len(cs));
                    let tests = conds(&pat_conds(cp, p_, &v_));
                    let whole = if &len(cs) == &Nat::from(1u32) {
                        tests.clone()
                    } else {
                        Text::from(format!("{} && {}", &tests, &crate::emit::cpp::templates::items::stmt_expr(&crate::syntax::lexer::chars::join(&pat_binds(cp, p_, &v_), &Text::lit("\n")), &rest)))
                    };
                    if &len(&pre) == &Nat::from(0u32) {
                        whole.clone()
                    } else {
                        crate::emit::cpp::templates::items::stmt_expr(&crate::syntax::lexer::chars::join(&pre, &Text::lit("\n")), &whole)
                    }
                },
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `GuardTest`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GuardTest: unbounded fn Cp, [Cc] -> Text
/// ```
pub struct GuardTest {
    pub cp: crate::emit::cpp::Cp,
    pub xs1: Array<crate::lower::model::Cc>,
}

impl prism_rtl::Job<Text> for GuardTest {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let xs1 = &self.xs1;
        match xs1 {
            j0_1 if (j0_1.len() == 0) => prism_rtl::Turn::Finished(Text::lit("true")),
            cs => {
                let first_ = or(&index(cs, &Nat::from(0u32)), &crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XUnit));
                let cp = cp.clone();
                let cs = cs.clone();
                call_then(start_guard_test(cp.clone(), drop(&cs, &Nat::from(1u32))), move |guard_test_8837: Text| {
                    let rest = guard_test_8837;
                    match &first_ {
                        crate::lower::model::Cc::CcIf(x) => if &len(&cs) == &Nat::from(1u32) {
                            prism_rtl::Turn::More(Rc::new(crate::emit::cpp::expr::CppTight { cp: cp.clone(), x: x.clone() }))
                        } else {
                            {
                                let x = x.clone();
                                call_then(crate::emit::cpp::expr::start_cpp_tight(cp.clone(), x.clone()), move |cpp_tight_8938: Text| prism_rtl::Turn::Finished(Text::from(format!("{} && {}", &cpp_tight_8938, &rest))))
                            }
                        },
                        crate::lower::model::Cc::CcLet(p_, x) => {
                            let p_ = p_.clone();
                            let x = x.clone();
                            call_then(start_cond_subject(cp.clone(), x.clone(), len(&cs)), move |cond_subject_9014: (Text, Array<Text>)| {
                                let (v_, pre) = cond_subject_9014;
                                call_then(start_pat_conds(cp.clone(), p_.clone(), v_.clone()), move |pat_conds_9073: Array<Text>| {
                                    let tests = conds(&pat_conds_9073);
                                    let whole = if &len(&cs) == &Nat::from(1u32) {
                                        tests.clone()
                                    } else {
                                        Text::from(format!("{} && {}", &tests, &crate::emit::cpp::templates::items::stmt_expr(&crate::syntax::lexer::chars::join(&pat_binds(&cp, &p_, &v_), &Text::lit("\n")), &rest)))
                                    };
                                    if &len(&pre) == &Nat::from(0u32) {
                                        prism_rtl::Turn::Finished(whole.clone())
                                    } else {
                                        prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::stmt_expr(&crate::syntax::lexer::chars::join(&pre, &Text::lit("\n")), &whole))
                                    }
                                })
                            })
                        },
                    }
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start GuardTest, x`: what the function value is when passed to `@Run`.
pub fn start_guard_test(cp: crate::emit::cpp::Cp, xs1: Array<crate::lower::model::Cc>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(GuardTest { cp, xs1 })
}

/// ```prism
/// MatchArm: unbounded fn Cp, Text, XArm, Bool -> Text
/// ```
pub fn match_arm(cp0: &crate::emit::cpp::Cp, subject: &Text, a: &crate::lower::model::XArm, returns: &bool) -> Text {
    let cp = crate::emit::cpp::stmts::unbind(cp0, &crate::emit::cpp::stmts::arm_names(a));
    let tests = pat_conds(&cp, &a.pat, subject);
    let binds = pat_binds(&cp, &a.pat, subject);
    let body = if *returns {
        crate::emit::cpp::stmts::cpp_body(&cp, &a.body)
    } else {
        if leaves(&a.body) {
            Text::from(format!("{};", &crate::emit::cpp::expr::cpp_expr(&cp, &a.body)))
        } else {
            Text::from(format!("_v.set({});\ngoto _done;", &crate::emit::cpp::expr::cpp_expr(&cp, &a.body)))
        }
    };
    let guarded = if &len(&a.conds) == &Nat::from(0u32) {
        body.clone()
    } else {
        guarded_arm(&cp, &a.conds, &body)
    };
    let inner = crate::syntax::lexer::chars::join(&append(&binds, &Array::from(vec![guarded.clone()])), &Text::lit("\n"));
    if &len(&tests) == &Nat::from(0u32) {
        crate::emit::cpp::templates::items::braced(&inner)
    } else {
        crate::emit::cpp::templates::items::if_block(&conds(&tests), &inner)
    }
}

/// The step machine of `MatchArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MatchArm: unbounded fn Cp, Text, XArm, Bool -> Text
/// ```
pub struct MatchArm {
    pub cp0: crate::emit::cpp::Cp,
    pub subject: Text,
    pub a: crate::lower::model::XArm,
    pub returns: bool,
}

impl prism_rtl::Job<Text> for MatchArm {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp0 = &self.cp0;
        let subject = &self.subject;
        let a = &self.a;
        let returns = &self.returns;
        let a = a.clone();
        let cp0 = cp0.clone();
        let returns = *returns;
        let subject = subject.clone();
        call_then(crate::emit::cpp::stmts::start_arm_names(a.clone()), move |arm_names_9531: Array<Text>| {
            let cp = crate::emit::cpp::stmts::unbind(&cp0, &arm_names_9531);
            call_then(start_pat_conds(cp.clone(), a.pat.clone(), subject.clone()), move |pat_conds_9559: Array<Text>| {
                let tests = pat_conds_9559;
                call_then(start_pat_binds(cp.clone(), a.pat.clone(), subject.clone()), move |pat_binds_9603: Array<Text>| {
                    let binds = pat_binds_9603;
                    let body = if returns {
                        crate::emit::cpp::stmts::cpp_body(&cp, &a.body)
                    } else {
                        if leaves(&a.body) {
                            Text::from(format!("{};", &crate::emit::cpp::expr::cpp_expr(&cp, &a.body)))
                        } else {
                            Text::from(format!("_v.set({});\ngoto _done;", &crate::emit::cpp::expr::cpp_expr(&cp, &a.body)))
                        }
                    };
                    let guarded = if &len(&a.conds) == &Nat::from(0u32) {
                        body.clone()
                    } else {
                        guarded_arm(&cp, &a.conds, &body)
                    };
                    let inner = crate::syntax::lexer::chars::join(&append(&binds, &Array::from(vec![guarded.clone()])), &Text::lit("\n"));
                    if &len(&tests) == &Nat::from(0u32) {
                        prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::braced(&inner))
                    } else {
                        prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::if_block(&conds(&tests), &inner))
                    }
                })
            })
        })
    }
}

/// `Start MatchArm, x`: what the function value is when passed to `@Run`.
pub fn start_match_arm(cp0: crate::emit::cpp::Cp, subject: Text, a: crate::lower::model::XArm, returns: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(MatchArm { cp0, subject, a, returns })
}

/// ```prism
/// GuardedArm: unbounded fn Cp, [Cc], Text -> Text
/// ```
pub fn guarded_arm(cp: &crate::emit::cpp::Cp, xs1: &Array<crate::lower::model::Cc>, body: &Text) -> Text {
    match xs1 {
        c0_1 if (c0_1.len() == 0) => body.clone(),
        cs => {
            let first_ = or(&index(cs, &Nat::from(0u32)), &crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XUnit));
            let rest = guarded_arm(cp, &drop(cs, &Nat::from(1u32)), body);
            match &first_ {
                crate::lower::model::Cc::CcIf(x) => crate::emit::cpp::templates::items::if_block(&crate::emit::cpp::expr::cpp_expr(cp, x), &rest),
                crate::lower::model::Cc::CcLet(p_, x) => {
                    let (v_, pre) = cond_subject(cp, x, &len(cs));
                    let inner = crate::emit::cpp::templates::items::if_block(&conds(&pat_conds(cp, p_, &v_)), &crate::syntax::lexer::chars::join(&append(&pat_binds(cp, p_, &v_), &Array::from(vec![rest.clone()])), &Text::lit("\n")));
                    if &len(&pre) == &Nat::from(0u32) {
                        inner.clone()
                    } else {
                        crate::emit::cpp::templates::items::braced(&crate::syntax::lexer::chars::join(&push(&pre, &inner), &Text::lit("\n")))
                    }
                },
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `GuardedArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GuardedArm: unbounded fn Cp, [Cc], Text -> Text
/// ```
pub struct GuardedArm {
    pub cp: crate::emit::cpp::Cp,
    pub xs1: Array<crate::lower::model::Cc>,
    pub body: Text,
}

impl prism_rtl::Job<Text> for GuardedArm {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let xs1 = &self.xs1;
        let body = &self.body;
        match xs1 {
            j0_1 if (j0_1.len() == 0) => prism_rtl::Turn::Finished(body.clone()),
            cs => {
                let first_ = or(&index(cs, &Nat::from(0u32)), &crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XUnit));
                let body = body.clone();
                let cp = cp.clone();
                let cs = cs.clone();
                call_then(start_guarded_arm(cp.clone(), drop(&cs, &Nat::from(1u32)), body.clone()), move |guarded_arm_10240: Text| {
                    let rest = guarded_arm_10240;
                    match &first_ {
                        crate::lower::model::Cc::CcIf(x) => {
                            let x = x.clone();
                            call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_10316: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::if_block(&cpp_expr_10316, &rest)))
                        },
                        crate::lower::model::Cc::CcLet(p_, x) => {
                            let p_ = p_.clone();
                            let x = x.clone();
                            call_then(start_cond_subject(cp.clone(), x.clone(), len(&cs)), move |cond_subject_10386: (Text, Array<Text>)| {
                                let (v_, pre) = cond_subject_10386;
                                call_then(start_pat_conds(cp.clone(), p_.clone(), v_.clone()), move |pat_conds_10454: Array<Text>| call_then(start_pat_binds(cp.clone(), p_.clone(), v_.clone()), move |pat_binds_10490: Array<Text>| {
                                    let inner = crate::emit::cpp::templates::items::if_block(&conds(&pat_conds_10454), &crate::syntax::lexer::chars::join(&append(&pat_binds_10490, &Array::from(vec![rest.clone()])), &Text::lit("\n")));
                                    if &len(&pre) == &Nat::from(0u32) {
                                        prism_rtl::Turn::Finished(inner.clone())
                                    } else {
                                        prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::braced(&crate::syntax::lexer::chars::join(&push(&pre, &inner), &Text::lit("\n"))))
                                    }
                                }))
                            })
                        },
                    }
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start GuardedArm, x`: what the function value is when passed to `@Run`.
pub fn start_guarded_arm(cp: crate::emit::cpp::Cp, xs1: Array<crate::lower::model::Cc>, body: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(GuardedArm { cp, xs1, body })
}

/// ```prism
/// CppLabeled: unbounded fn Cp, Text, [Do], Ex, OutTy -> Text
/// ```
pub fn cpp_labeled(cp: &crate::emit::cpp::Cp, label: &Text, dos: &Array<crate::lower::model::Do>, e: &crate::lower::model::Ex, t: &crate::lower::model::OutTy) -> Text {
    let l = cpp_label(label);
    let last = if leaves(e) {
        Text::from(format!("{};", &crate::emit::cpp::expr::cpp_expr(cp, e)))
    } else {
        Text::from(format!("{}_v.set({});", &l, &crate::emit::cpp::expr::cpp_expr(cp, e)))
    };
    crate::emit::cpp::templates::items::labeled_expr(&l, &crate::emit::cpp::cpp_type(cp, t), &crate::syntax::lexer::chars::join(&push(&run_to_end(each_job(dos.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::Do| {
            let cp = cp.clone();
            entered(once_job(move || {
                let d = p0;
                prism_rtl::Turn::More(Rc::new(crate::emit::cpp::stmts::CppStatement { cp: cp.clone(), d: d.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &last), &Text::lit("\n")))
}

/// The step machine of `CppLabeled`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppLabeled: unbounded fn Cp, Text, [Do], Ex, OutTy -> Text
/// ```
pub struct CppLabeled {
    pub cp: crate::emit::cpp::Cp,
    pub label: Text,
    pub dos: Array<crate::lower::model::Do>,
    pub e: crate::lower::model::Ex,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for CppLabeled {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let label = &self.label;
        let dos = &self.dos;
        let e = &self.e;
        let t = &self.t;
        let l = cpp_label(label);
        let last = if leaves(e) {
            Text::from(format!("{};", &crate::emit::cpp::expr::cpp_expr(cp, e)))
        } else {
            Text::from(format!("{}_v.set({});", &l, &crate::emit::cpp::expr::cpp_expr(cp, e)))
        };
        let cp = cp.clone();
        let dos = dos.clone();
        let t = t.clone();
        call_then(crate::emit::cpp::start_cpp_type(cp.clone(), t.clone()), move |cpp_type_10916: Text| call_value(each_job(dos.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: crate::lower::model::Do| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let d = p0;
                    prism_rtl::Turn::More(Rc::new(crate::emit::cpp::stmts::CppStatement { cp: cp.clone(), d: d.clone() }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_10945: Array<Text>| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::labeled_expr(&l, &cpp_type_10916, &crate::syntax::lexer::chars::join(&push(&each_10945, &last), &Text::lit("\n"))))))
    }
}

/// `Start CppLabeled, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_labeled(cp: crate::emit::cpp::Cp, label: Text, dos: Array<crate::lower::model::Do>, e: crate::lower::model::Ex, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppLabeled { cp, label, dos, e, t })
}

/// ```prism
/// CppLabel: fn Text -> Text
/// ```
pub fn cpp_label(l: &Text) -> Text {
    if crate::syntax::lexer::chars::has_prefix(l, &Text::lit("\'")) {
        crate::syntax::lexer::chars::after_first(l)
    } else {
        l.clone()
    }
}

/// ```prism
/// CppBreak: unbounded fn Cp, Text, Ex -> Text
/// ```
pub fn cpp_break(cp: &crate::emit::cpp::Cp, l: &Text, y: &crate::lower::model::Ex) -> Text {
    let n = cpp_label(l);
    Text::from(format!("{{ {}_v.set({}); goto {}; }}", &n, &crate::emit::cpp::expr::cpp_expr(cp, y), &n))
}

/// The step machine of `CppBreak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppBreak: unbounded fn Cp, Text, Ex -> Text
/// ```
pub struct CppBreak {
    pub cp: crate::emit::cpp::Cp,
    pub l: Text,
    pub y: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppBreak {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let l = &self.l;
        let y = &self.y;
        let n = cpp_label(l);
        let cp = cp.clone();
        let y = y.clone();
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_11190: Text| prism_rtl::Turn::Finished(Text::from(format!("{{ {}_v.set({}); goto {}; }}", &n, &cpp_expr_11190, &n))))
    }
}

/// `Start CppBreak, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_break(cp: crate::emit::cpp::Cp, l: Text, y: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppBreak { cp, l, y })
}
