//! The module `Emit.Cpp.Expr`, from `target/bootstrap/src/prismc/emit/cpp/expr.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// CppLoose: fn Ex -> Bool
/// ```
pub fn cpp_loose(x: &crate::lower::model::Ex) -> bool {
    match x {
        crate::lower::model::Ex::XBlock(m1173_0_0, inner) if (m1173_0_0.len() == 0) => cpp_loose(&**inner),
        crate::lower::model::Ex::XBin(_, _, _) => true,
        crate::lower::model::Ex::XUnary(_, _) => true,
        crate::lower::model::Ex::XIf(_, _, _) => true,
        crate::lower::model::Ex::XRef(y) => cpp_loose(&**y),
        crate::lower::model::Ex::XRefMut(y) => cpp_loose(&**y),
        crate::lower::model::Ex::XClone(y) => cpp_loose(&**y),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CppTight: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_tight(cp: &crate::emit::cpp::Cp, x: &crate::lower::model::Ex) -> Text {
    if cpp_loose(x) {
        Text::from(format!("({})", &cpp_expr(cp, x)))
    } else {
        starred(&cpp_expr(cp, x))
    }
}

/// The step machine of `CppTight`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppTight: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppTight {
    pub cp: crate::emit::cpp::Cp,
    pub x: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppTight {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let x = &self.x;
        if cpp_loose(x) {
            {
                let cp = cp.clone();
                let x = x.clone();
                call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_1500: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &cpp_expr_1500))))
            }
        } else {
            {
                let cp = cp.clone();
                let x = x.clone();
                call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_1532: Text| prism_rtl::Turn::Finished(starred(&cpp_expr_1532)))
            }
        }
    }
}

/// `Start CppTight, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_tight(cp: crate::emit::cpp::Cp, x: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppTight { cp, x })
}

/// ```prism
/// Starred: fn Text -> Text
/// ```
pub fn starred(t: &Text) -> Text {
    if crate::syntax::lexer::chars::has_prefix(t, &Text::lit("*")) {
        Text::from(format!("({})", t))
    } else {
        t.clone()
    }
}

/// ```prism
/// CppTightPlace: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_tight_place(cp: &crate::emit::cpp::Cp, x: &crate::lower::model::Ex) -> Text {
    if cpp_loose(x) {
        Text::from(format!("({})", &cpp_place(cp, x)))
    } else {
        starred(&cpp_place(cp, x))
    }
}

/// The step machine of `CppTightPlace`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppTightPlace: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppTightPlace {
    pub cp: crate::emit::cpp::Cp,
    pub x: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppTightPlace {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let x = &self.x;
        if cpp_loose(x) {
            {
                let cp = cp.clone();
                let x = x.clone();
                call_then(start_cpp_place(cp.clone(), x.clone()), move |cpp_place_1889: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &cpp_place_1889))))
            }
        } else {
            {
                let cp = cp.clone();
                let x = x.clone();
                call_then(start_cpp_place(cp.clone(), x.clone()), move |cpp_place_1922: Text| prism_rtl::Turn::Finished(starred(&cpp_place_1922)))
            }
        }
    }
}

/// `Start CppTightPlace, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_tight_place(cp: crate::emit::cpp::Cp, x: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppTightPlace { cp, x })
}

/// ```prism
/// CppPlace: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_place(cp: &crate::emit::cpp::Cp, ex1: &crate::lower::model::Ex) -> Text {
    match ex1 {
        crate::lower::model::Ex::XVar(n) => crate::emit::cpp::stmts::var_name(cp, n),
        x => cpp_expr(cp, x),
    }
}

/// The step machine of `CppPlace`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppPlace: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppPlace {
    pub cp: crate::emit::cpp::Cp,
    pub ex1: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppPlace {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let ex1 = &self.ex1;
        match ex1 {
            crate::lower::model::Ex::XVar(n) => prism_rtl::Turn::Finished(crate::emit::cpp::stmts::var_name(cp, n)),
            x => prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: x.clone() })),
        }
    }
}

/// `Start CppPlace, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_place(cp: crate::emit::cpp::Cp, ex1: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppPlace { cp, ex1 })
}

/// ```prism
/// CppVar: fn Cp, Text -> Text
/// ```
pub fn cpp_var(cp: &crate::emit::cpp::Cp, n: &Text) -> Text {
    if or(&get(&cp.owned, n), &false) {
        Text::from(format!("std::move({})", &crate::emit::cpp::stmts::var_name(cp, n)))
    } else {
        crate::emit::cpp::stmts::var_name(cp, n)
    }
}

/// ```prism
/// CppArgs: unbounded fn Cp, [Ex] -> Text
/// ```
pub fn cpp_args(cp: &crate::emit::cpp::Cp, xs: &Array<crate::lower::model::Ex>) -> Text {
    crate::syntax::lexer::chars::join(&cpp_arg_list(cp, xs), &Text::lit(", "))
}

/// The step machine of `CppArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppArgs: unbounded fn Cp, [Ex] -> Text
/// ```
pub struct CppArgs {
    pub cp: crate::emit::cpp::Cp,
    pub xs: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for CppArgs {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let xs = &self.xs;
        let cp = cp.clone();
        let xs = xs.clone();
        call_then(start_cpp_arg_list(cp.clone(), xs.clone()), move |cpp_arg_list_2810: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&cpp_arg_list_2810, &Text::lit(", "))))
    }
}

/// `Start CppArgs, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_args(cp: crate::emit::cpp::Cp, xs: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppArgs { cp, xs })
}

/// ```prism
/// CppArgList: unbounded fn Cp, [Ex] -> [Text]
/// ```
pub fn cpp_arg_list(cp: &crate::emit::cpp::Cp, xs: &Array<crate::lower::model::Ex>) -> Array<Text> {
    let texts = run_to_end(each_job(xs.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::Ex| {
            let cp = cp.clone();
            entered(once_job(move || {
                let x = p0;
                prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: x.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    each(&crate::check::errors::range0(&len(xs)), &(|i: &Nat| match or(&index(xs, i), &crate::lower::model::Ex::XUnit) {
        crate::lower::model::Ex::XVar(n) => if fold(&crate::check::errors::range0(&len(xs)), &false, &(|f: &bool, j: &Nat| *f || ((j != i) && crate::emit::cpp::stmts::cpp_mentions(&or(&index(&texts, j), &Text::lit("")), &crate::emit::cpp::stmts::var_name(cp, &n))))) {
            crate::emit::cpp::stmts::var_name(cp, &n)
        } else {
            or(&index(&texts, i), &Text::lit(""))
        },
        _ => or(&index(&texts, i), &Text::lit("")),
    }))
}

/// The step machine of `CppArgList`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppArgList: unbounded fn Cp, [Ex] -> [Text]
/// ```
pub struct CppArgList {
    pub cp: crate::emit::cpp::Cp,
    pub xs: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Array<Text>> for CppArgList {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cp = &self.cp;
        let xs = &self.xs;
        let cp = cp.clone();
        let xs = xs.clone();
        call_value(each_job(xs.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: crate::lower::model::Ex| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let x = p0;
                    prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: x.clone() }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_2918: Array<Text>| {
            let texts = each_2918;
            prism_rtl::Turn::Finished(each(&crate::check::errors::range0(&len(&xs)), &(|i: &Nat| match or(&index(&xs, i), &crate::lower::model::Ex::XUnit) {
                crate::lower::model::Ex::XVar(n) => if fold(&crate::check::errors::range0(&len(&xs)), &false, &(|f: &bool, j: &Nat| *f || ((j != i) && crate::emit::cpp::stmts::cpp_mentions(&or(&index(&texts, j), &Text::lit("")), &crate::emit::cpp::stmts::var_name(&cp, &n))))) {
                    crate::emit::cpp::stmts::var_name(&cp, &n)
                } else {
                    or(&index(&texts, i), &Text::lit(""))
                },
                _ => or(&index(&texts, i), &Text::lit("")),
            })))
        })
    }
}

/// `Start CppArgList, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_arg_list(cp: crate::emit::cpp::Cp, xs: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(CppArgList { cp, xs })
}

/// ```prism
/// CppExpr: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_expr(cp: &crate::emit::cpp::Cp, x: &crate::lower::model::Ex) -> Text {
    match x {
        crate::lower::model::Ex::XVar(n) => cpp_var(cp, n),
        crate::lower::model::Ex::XPath(p_) => path_value(cp, p_),
        crate::lower::model::Ex::XSelf => Text::lit("prism_rtl::share(this)"),
        crate::lower::model::Ex::XCx => Text::lit("cx"),
        crate::lower::model::Ex::XConst(n) => n.clone(),
        crate::lower::model::Ex::XUnit => Text::lit("Unit{}"),
        crate::lower::model::Ex::XNone => Text::lit("std::nullopt"),
        crate::lower::model::Ex::XBool(b) => if *b { Text::lit("true") } else { Text::lit("false") },
        crate::lower::model::Ex::XNat(d) => if &len_text(d) <= &Nat::from(9u32) {
            Text::from(format!("Nat({}u)", d))
        } else {
            Text::from(format!("*Nat::from_int({})", &cpp_expr(cp, &crate::lower::model::Ex::XInt(d.clone()))))
        },
        crate::lower::model::Ex::XInt(d) => if &len_text(&(if crate::syntax::lexer::chars::has_prefix(d, &Text::lit("-")) {
            crate::syntax::lexer::chars::after_first(d)
        } else {
            d.clone()
        })) <= &Nat::from(18u32) {
            Text::from(format!("Int({}ll)", d))
        } else {
            Text::from(format!("*Int::parse(\"{}\")", d))
        },
        crate::lower::model::Ex::XByte(d) => Text::from(format!("std::uint8_t({})", d)),
        crate::lower::model::Ex::XFloat(d) => Text::from(format!("Float{{{}}}", d)),
        crate::lower::model::Ex::XIndex(n) => Text::from(format!("{}u", n)),
        crate::lower::model::Ex::XChar(c) => Text::from(format!("U\'{}\'", &cpp_char_escape(c))),
        crate::lower::model::Ex::XStr(t) => cpp_string(t),
        crate::lower::model::Ex::XRegex(p_, f) => Text::from(format!("([]() -> const Regex& {{ static const Regex r = Regex::lit({}, {}); return r; }}())", &cpp_string(p_), &cpp_string(f))),
        crate::lower::model::Ex::XReplacement(p_, r, f) => Text::from(format!("([]() -> const RegexReplacement& {{ static const RegexReplacement r = RegexReplacement::lit({}, {}, {}); return r; }}())", &cpp_string(p_), &cpp_string(f), &cpp_string(r))),
        crate::lower::model::Ex::XRef(y) => cpp_place(cp, &**y),
        crate::lower::model::Ex::XRefMut(y) => cpp_place(cp, &**y),
        crate::lower::model::Ex::XDeref(y) => match ex_ty(cp, &**y) {
            Some(crate::lower::model::OutTy::OutRc(_)) => Text::from(format!("*{}", &cpp_tight_place(cp, &**y))),
            Some(crate::lower::model::OutTy::OutRef(_)) => cpp_place(cp, &**y),
            _ => Text::from(format!("prism_rtl::deref({})", &cpp_place(cp, &**y))),
        },
        crate::lower::model::Ex::XTarget(y) => cpp_place(cp, &**y),
        crate::lower::model::Ex::XClone(y) => cpp_place(cp, &**y),
        crate::lower::model::Ex::XWeak(y) => Text::from(format!("prism_rtl::weaken({})", &cpp_expr(cp, &**y))),
        crate::lower::model::Ex::XUpgrade(y) => Text::from(format!("prism_rtl::upgrade({})", &cpp_expr(cp, &**y))),
        crate::lower::model::Ex::XBreak(l, y) => Text::from(format!("({})", &crate::emit::cpp::patterns::cpp_break(cp, l, &**y))),
        crate::lower::model::Ex::XBreakLoop => Text::lit("({ break; })"),
        crate::lower::model::Ex::XLater(y) => Text::from(format!("[=](Cx& cx) -> Done {{ {}; return {{}}; }}", &cpp_expr(&crate::emit::cpp::stmts::captured(cp), &**y))),
        crate::lower::model::Ex::XFormatStr(parts) => cpp_format(cp, parts, &Text::lit("prism_rtl::str")),
        crate::lower::model::Ex::XIsCase(y, m3254_28_1) if (m3254_28_1.len() == 0) => Text::lit("false"),
        crate::lower::model::Ex::XIsCase(y, cs) => Text::from(format!("({})", &crate::syntax::lexer::chars::join(&run_to_end(each_job(cs.clone(), {
            let cp = cp.clone();
            let y = (**y).clone();
            Rc::new(move |p0: Text| {
                let cp = cp.clone();
                let y = y.clone();
                entered(once_job(move || {
                    let c = p0;
                    call_then(start_cpp_tight_place(cp.clone(), y.clone()), move |cpp_tight_place_5408: Text| prism_rtl::Turn::Finished(case_test(&cp, &c, &cpp_tight_place_5408)))
                }))
            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>
        })), &Text::lit(" || ")))),
        crate::lower::model::Ex::XRefusal(what) => Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::expr::lowering_refusal(), &crate::lower::expr::escape(what))),
        crate::lower::model::Ex::XUnreachable => Text::lit("throw prism_rtl::Panic(\"entered unreachable code\")"),
        crate::lower::model::Ex::XCall(f, args) => cpp_call(cp, f, args),
        crate::lower::model::Ex::XApply(f, args) => Text::from(format!("{}({})", &cpp_tight_place(cp, &**f), &cpp_args(cp, args))),
        crate::lower::model::Ex::XMethod(r, m, args) => cpp_method(cp, &**r, m, args),
        crate::lower::model::Ex::XBin(op, l, r) => {
            let (lt, rt) = 'm5782: {
                let scrutinee = &cpp_arg_list(cp, &Array::from(vec![(**l).clone(), (**r).clone()]));
                if let m5782_0 = scrutinee && (m5782_0.len() == 2) && let Some(a) = index(m5782_0, &Nat::from(0u32)) && let Some(b) = index(m5782_0, &Nat::from(1u32)) {
                    break 'm5782 (a.clone(), b.clone());
                }
                (Text::lit(""), Text::lit(""))
            };
            Text::from(format!("{} {} {}", &(if cpp_loose(&**l) { Text::from(format!("({})", &lt)) } else { lt.clone() }), op, &(if cpp_loose(&**r) { Text::from(format!("({})", &rt)) } else { rt.clone() })))
        },
        crate::lower::model::Ex::XUnary(op, y) => Text::from(format!("{}{}", op, &cpp_tight(cp, &**y))),
        crate::lower::model::Ex::XCtor(p_, args) => cpp_ctor(cp, p_, args),
        crate::lower::model::Ex::XRecord(p_, fs) => cpp_record(cp, p_, fs),
        crate::lower::model::Ex::XTuple(xs) => Text::from(format!("std::tuple{{{}}}", &cpp_args(cp, xs))),
        crate::lower::model::Ex::XVec(m3254_40_0) if (m3254_40_0.len() == 0) => Text::lit("{}"),
        crate::lower::model::Ex::XVec(xs) => Text::from(format!("std::vector{{{}}}", &cpp_args(cp, xs))),
        crate::lower::model::Ex::XText(t) => Text::from(format!("Text::lit({})", &cpp_string(t))),
        crate::lower::model::Ex::XFormat(parts) => if fold(parts, &true, &(|f: &bool, p_: &crate::lower::model::Ex| *f && is_text_piece(p_))) {
            Text::from(format!("Text::lit({})", &cpp_string(&concat(&each(parts, &(|p_: &crate::lower::model::Ex| text_piece(p_)))))))
        } else {
            cpp_format(cp, parts, &Text::lit("prism_rtl::cat"))
        },
        crate::lower::model::Ex::XMatch(s, arms, fallback, t) => crate::emit::cpp::patterns::cpp_match(cp, &**s, arms, t),
        crate::lower::model::Ex::XChain(label, s, arms, t) => crate::emit::cpp::patterns::cpp_match(cp, &**s, arms, t),
        crate::lower::model::Ex::XIf(c, t, e) => cpp_if(cp, &**c, &**t, &**e),
        crate::lower::model::Ex::XBlock(m3254_47_0, e) if (m3254_47_0.len() == 0) => cpp_expr(cp, &**e),
        crate::lower::model::Ex::XBlock(dos, e) => {
            let (st, cp2) = crate::emit::cpp::stmts::cpp_statements_cp(cp, dos);
            crate::emit::cpp::templates::items::stmt_expr(&st, &crate::emit::cpp::stmts::unvexed(&cpp_expr(&with_move_captures(&cp2, dos, &**e), &**e)))
        },
        crate::lower::model::Ex::XLabeled(label, dos, e, t) => crate::emit::cpp::patterns::cpp_labeled(cp, label, dos, &**e, t),
        crate::lower::model::Ex::XClosure(mv, ps, body) => cpp_closure(cp, mv, ps, &**body),
        crate::lower::model::Ex::XTry(y) => Text::from(format!("TRY({})", &cpp_expr(cp, &**y))),
        crate::lower::model::Ex::XField(r, f) => cpp_field(cp, &**r, f),
        crate::lower::model::Ex::XPart(r, k) => Text::from(format!("std::get<{}>({})", k, &as_value(cp, &**r))),
        crate::lower::model::Ex::XDecode(t, y) => Text::from(format!("TRY(prism_rtl::from_pod<{}>({}))", &crate::emit::cpp::cpp_type(cp, t), &cpp_expr(cp, &**y))),
        crate::lower::model::Ex::XCast(y, t) => Text::from(format!("static_cast<{}>({})", &crate::emit::cpp::cpp_type(cp, t), &cpp_expr(cp, &**y))),
        crate::lower::model::Ex::XTyped(y, t) => {
            let e = cpp_expr(cp, &**y);
            if (&e == &Text::lit("{}")) || (&e == &Text::lit("std::nullopt")) {
                Text::from(format!("{}{{}}", &crate::emit::cpp::cpp_type(cp, t)))
            } else {
                if is_ctor(&**y, &Text::lit("Ok")) || is_ctor(&**y, &Text::lit("Err")) {
                    Text::from(format!("{}({})", &crate::emit::cpp::cpp_type(cp, t), &e))
                } else {
                    e.clone()
                }
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CppExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppExpr: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppExpr {
    pub cp: crate::emit::cpp::Cp,
    pub x: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppExpr {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let x = &self.x;
        match x {
            crate::lower::model::Ex::XVar(n) => prism_rtl::Turn::Finished(cpp_var(cp, n)),
            crate::lower::model::Ex::XPath(p_) => prism_rtl::Turn::Finished(path_value(cp, p_)),
            crate::lower::model::Ex::XSelf => prism_rtl::Turn::Finished(Text::lit("prism_rtl::share(this)")),
            crate::lower::model::Ex::XCx => prism_rtl::Turn::Finished(Text::lit("cx")),
            crate::lower::model::Ex::XConst(n) => prism_rtl::Turn::Finished(n.clone()),
            crate::lower::model::Ex::XUnit => prism_rtl::Turn::Finished(Text::lit("Unit{}")),
            crate::lower::model::Ex::XNone => prism_rtl::Turn::Finished(Text::lit("std::nullopt")),
            crate::lower::model::Ex::XBool(b) => if *b {
                prism_rtl::Turn::Finished(Text::lit("true"))
            } else {
                prism_rtl::Turn::Finished(Text::lit("false"))
            },
            crate::lower::model::Ex::XNat(d) => if &len_text(d) <= &Nat::from(9u32) {
                prism_rtl::Turn::Finished(Text::from(format!("Nat({}u)", d)))
            } else {
                {
                    let cp = cp.clone();
                    let d = d.clone();
                    call_then(start_cpp_expr(cp.clone(), crate::lower::model::Ex::XInt(d.clone())), move |cpp_expr_3535: Text| prism_rtl::Turn::Finished(Text::from(format!("*Nat::from_int({})", &cpp_expr_3535))))
                }
            },
            crate::lower::model::Ex::XInt(d) => if &len_text(&(if crate::syntax::lexer::chars::has_prefix(d, &Text::lit("-")) {
                crate::syntax::lexer::chars::after_first(d)
            } else {
                d.clone()
            })) <= &Nat::from(18u32) {
                prism_rtl::Turn::Finished(Text::from(format!("Int({}ll)", d)))
            } else {
                prism_rtl::Turn::Finished(Text::from(format!("*Int::parse(\"{}\")", d)))
            },
            crate::lower::model::Ex::XByte(d) => prism_rtl::Turn::Finished(Text::from(format!("std::uint8_t({})", d))),
            crate::lower::model::Ex::XFloat(d) => prism_rtl::Turn::Finished(Text::from(format!("Float{{{}}}", d))),
            crate::lower::model::Ex::XIndex(n) => prism_rtl::Turn::Finished(Text::from(format!("{}u", n))),
            crate::lower::model::Ex::XChar(c) => prism_rtl::Turn::Finished(Text::from(format!("U\'{}\'", &cpp_char_escape(c)))),
            crate::lower::model::Ex::XStr(t) => prism_rtl::Turn::Finished(cpp_string(t)),
            crate::lower::model::Ex::XRegex(p_, f) => prism_rtl::Turn::Finished(Text::from(format!("([]() -> const Regex& {{ static const Regex r = Regex::lit({}, {}); return r; }}())", &cpp_string(p_), &cpp_string(f)))),
            crate::lower::model::Ex::XReplacement(p_, r, f) => prism_rtl::Turn::Finished(Text::from(format!("([]() -> const RegexReplacement& {{ static const RegexReplacement r = RegexReplacement::lit({}, {}, {}); return r; }}())", &cpp_string(p_), &cpp_string(f), &cpp_string(r)))),
            crate::lower::model::Ex::XRef(y) => prism_rtl::Turn::More(Rc::new(CppPlace { cp: cp.clone(), ex1: (**y).clone() })),
            crate::lower::model::Ex::XRefMut(y) => prism_rtl::Turn::More(Rc::new(CppPlace { cp: cp.clone(), ex1: (**y).clone() })),
            crate::lower::model::Ex::XDeref(y) => match ex_ty(cp, &**y) {
                Some(crate::lower::model::OutTy::OutRc(_)) => {
                    let cp = cp.clone();
                    let y = (**y).clone();
                    call_then(start_cpp_tight_place(cp.clone(), y.clone()), move |cpp_tight_place_4820: Text| prism_rtl::Turn::Finished(Text::from(format!("*{}", &cpp_tight_place_4820))))
                },
                Some(crate::lower::model::OutTy::OutRef(_)) => prism_rtl::Turn::More(Rc::new(CppPlace { cp: cp.clone(), ex1: (**y).clone() })),
                _ => {
                    let cp = cp.clone();
                    let y = (**y).clone();
                    call_then(start_cpp_place(cp.clone(), y.clone()), move |cpp_place_4922: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::deref({})", &cpp_place_4922))))
                },
            },
            crate::lower::model::Ex::XTarget(y) => prism_rtl::Turn::More(Rc::new(CppPlace { cp: cp.clone(), ex1: (**y).clone() })),
            crate::lower::model::Ex::XClone(y) => prism_rtl::Turn::More(Rc::new(CppPlace { cp: cp.clone(), ex1: (**y).clone() })),
            crate::lower::model::Ex::XWeak(y) => {
                let cp = cp.clone();
                let y = (**y).clone();
                call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_5032: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::weaken({})", &cpp_expr_5032))))
            },
            crate::lower::model::Ex::XUpgrade(y) => {
                let cp = cp.clone();
                let y = (**y).clone();
                call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_5086: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::upgrade({})", &cpp_expr_5086))))
            },
            crate::lower::model::Ex::XBreak(l, y) => {
                let cp = cp.clone();
                let l = l.clone();
                let y = (**y).clone();
                call_then(crate::emit::cpp::patterns::start_cpp_break(cp.clone(), l.clone(), y.clone()), move |cpp_break_5123: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &cpp_break_5123))))
            },
            crate::lower::model::Ex::XBreakLoop => prism_rtl::Turn::Finished(Text::lit("({ break; })")),
            crate::lower::model::Ex::XLater(y) => {
                let cp = cp.clone();
                let y = (**y).clone();
                call_then(start_cpp_expr(crate::emit::cpp::stmts::captured(&cp), y.clone()), move |cpp_expr_5216: Text| prism_rtl::Turn::Finished(Text::from(format!("[=](Cx& cx) -> Done {{ {}; return {{}}; }}", &cpp_expr_5216))))
            },
            crate::lower::model::Ex::XFormatStr(parts) => prism_rtl::Turn::More(Rc::new(CppFormat { cp: cp.clone(), parts: parts.clone(), how: Text::lit("prism_rtl::str") })),
            crate::lower::model::Ex::XIsCase(y, m3254_28_1) if (m3254_28_1.len() == 0) => prism_rtl::Turn::Finished(Text::lit("false")),
            crate::lower::model::Ex::XIsCase(y, cs) => {
                let cp = cp.clone();
                let cs = cs.clone();
                let y = (**y).clone();
                call_value(each_job(cs.clone(), {
                    let cp = cp.clone();
                    let y = y.clone();
                    Rc::new(move |p0: Text| {
                        let cp = cp.clone();
                        let y = y.clone();
                        entered(once_job(move || {
                            let c = p0;
                            call_then(start_cpp_tight_place(cp.clone(), y.clone()), move |cpp_tight_place_5408: Text| prism_rtl::Turn::Finished(case_test(&cp, &c, &cpp_tight_place_5408)))
                        }))
                    }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_5377: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("({})", &crate::syntax::lexer::chars::join(&each_5377, &Text::lit(" || "))))))
            },
            crate::lower::model::Ex::XRefusal(what) => prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::expr::lowering_refusal(), &crate::lower::expr::escape(what)))),
            crate::lower::model::Ex::XUnreachable => prism_rtl::Turn::Finished(Text::lit("throw prism_rtl::Panic(\"entered unreachable code\")")),
            crate::lower::model::Ex::XCall(f, args) => prism_rtl::Turn::More(Rc::new(CppCall { cp: cp.clone(), f: f.clone(), args: args.clone() })),
            crate::lower::model::Ex::XApply(f, args) => {
                let args = args.clone();
                let cp = cp.clone();
                let f = (**f).clone();
                call_then(start_cpp_tight_place(cp.clone(), f.clone()), move |cpp_tight_place_5647: Text| call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_5669: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &cpp_tight_place_5647, &cpp_args_5669)))))
            },
            crate::lower::model::Ex::XMethod(r, m, args) => prism_rtl::Turn::More(Rc::new(CppMethod { cp: cp.clone(), r: (**r).clone(), m: m.clone(), args: args.clone() })),
            crate::lower::model::Ex::XBin(op, l, r) => {
                let cp = cp.clone();
                let l = (**l).clone();
                let op = op.clone();
                let r = (**r).clone();
                call_then(start_cpp_arg_list(cp.clone(), Array::from(vec![l.clone(), r.clone()])), move |cpp_arg_list_5788: Array<Text>| {
                    let (lt, rt) = 'm5782: {
                        if let m5782_0 = &cpp_arg_list_5788 && (m5782_0.len() == 2) && let Some(a) = index(m5782_0, &Nat::from(0u32)) && let Some(b) = index(m5782_0, &Nat::from(1u32)) {
                            break 'm5782 (a.clone(), b.clone());
                        }
                        (Text::lit(""), Text::lit(""))
                    };
                    prism_rtl::Turn::Finished(Text::from(format!("{} {} {}", &(if cpp_loose(&l) { Text::from(format!("({})", &lt)) } else { lt.clone() }), &op, &(if cpp_loose(&r) { Text::from(format!("({})", &rt)) } else { rt.clone() }))))
                })
            },
            crate::lower::model::Ex::XUnary(op, y) => {
                let cp = cp.clone();
                let op = op.clone();
                let y = (**y).clone();
                call_then(start_cpp_tight(cp.clone(), y.clone()), move |cpp_tight_5987: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &op, &cpp_tight_5987))))
            },
            crate::lower::model::Ex::XCtor(p_, args) => prism_rtl::Turn::More(Rc::new(CppCtor { cp: cp.clone(), p_: p_.clone(), args: args.clone() })),
            crate::lower::model::Ex::XRecord(p_, fs) => prism_rtl::Turn::More(Rc::new(CppRecord { cp: cp.clone(), p_: p_.clone(), fs: fs.clone() })),
            crate::lower::model::Ex::XTuple(xs) => {
                let cp = cp.clone();
                let xs = xs.clone();
                call_then(start_cpp_args(cp.clone(), xs.clone()), move |cpp_args_6111: Text| prism_rtl::Turn::Finished(Text::from(format!("std::tuple{{{}}}", &cpp_args_6111))))
            },
            crate::lower::model::Ex::XVec(m3254_40_0) if (m3254_40_0.len() == 0) => prism_rtl::Turn::Finished(Text::lit("{}")),
            crate::lower::model::Ex::XVec(xs) => {
                let cp = cp.clone();
                let xs = xs.clone();
                call_then(start_cpp_args(cp.clone(), xs.clone()), move |cpp_args_6180: Text| prism_rtl::Turn::Finished(Text::from(format!("std::vector{{{}}}", &cpp_args_6180))))
            },
            crate::lower::model::Ex::XText(t) => prism_rtl::Turn::Finished(Text::from(format!("Text::lit({})", &cpp_string(t)))),
            crate::lower::model::Ex::XFormat(parts) => if fold(parts, &true, &(|f: &bool, p_: &crate::lower::model::Ex| *f && is_text_piece(p_))) {
                prism_rtl::Turn::Finished(Text::from(format!("Text::lit({})", &cpp_string(&concat(&each(parts, &(|p_: &crate::lower::model::Ex| text_piece(p_))))))))
            } else {
                prism_rtl::Turn::More(Rc::new(CppFormat { cp: cp.clone(), parts: parts.clone(), how: Text::lit("prism_rtl::cat") }))
            },
            crate::lower::model::Ex::XMatch(s, arms, fallback, t) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::patterns::CppMatch { cp: cp.clone(), s: (**s).clone(), arms: arms.clone(), out_ty3: t.clone() })),
            crate::lower::model::Ex::XChain(label, s, arms, t) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::patterns::CppMatch { cp: cp.clone(), s: (**s).clone(), arms: arms.clone(), out_ty3: t.clone() })),
            crate::lower::model::Ex::XIf(c, t, e) => prism_rtl::Turn::More(Rc::new(CppIf { cp: cp.clone(), c: (**c).clone(), t: (**t).clone(), e: (**e).clone() })),
            crate::lower::model::Ex::XBlock(m3254_47_0, e) if (m3254_47_0.len() == 0) => prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: (**e).clone() })),
            crate::lower::model::Ex::XBlock(dos, e) => {
                let cp = cp.clone();
                let dos = dos.clone();
                let e = (**e).clone();
                call_then(crate::emit::cpp::stmts::start_cpp_statements_cp(cp.clone(), dos.clone()), move |cpp_statements_cp_6642: (Text, crate::emit::cpp::Cp)| {
                    let (st, cp2) = cpp_statements_cp_6642;
                    call_then(start_with_move_captures(cp2.clone(), dos.clone(), e.clone()), move |with_move_captures_6706: crate::emit::cpp::Cp| call_then(start_cpp_expr(with_move_captures_6706, e.clone()), move |cpp_expr_6697: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::stmt_expr(&st, &crate::emit::cpp::stmts::unvexed(&cpp_expr_6697)))))
                })
            },
            crate::lower::model::Ex::XLabeled(label, dos, e, t) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::patterns::CppLabeled { cp: cp.clone(), label: label.clone(), dos: dos.clone(), e: (**e).clone(), t: t.clone() })),
            crate::lower::model::Ex::XClosure(mv, ps, body) => prism_rtl::Turn::More(Rc::new(CppClosure { cp0: cp.clone(), mv: *mv, ps: ps.clone(), body: (**body).clone() })),
            crate::lower::model::Ex::XTry(y) => {
                let cp = cp.clone();
                let y = (**y).clone();
                call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_6877: Text| prism_rtl::Turn::Finished(Text::from(format!("TRY({})", &cpp_expr_6877))))
            },
            crate::lower::model::Ex::XField(r, f) => prism_rtl::Turn::More(Rc::new(CppField { cp: cp.clone(), ex1: (**r).clone(), f: f.clone() })),
            crate::lower::model::Ex::XPart(r, k) => {
                let cp = cp.clone();
                let k = k.clone();
                let r = (**r).clone();
                call_then(start_as_value(cp.clone(), r.clone()), move |as_value_6961: Text| prism_rtl::Turn::Finished(Text::from(format!("std::get<{}>({})", &k, &as_value_6961))))
            },
            crate::lower::model::Ex::XDecode(t, y) => {
                let cp = cp.clone();
                let t = t.clone();
                let y = (**y).clone();
                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), t.clone()), move |cpp_type_7022: Text| call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_7039: Text| prism_rtl::Turn::Finished(Text::from(format!("TRY(prism_rtl::from_pod<{}>({}))", &cpp_type_7022, &cpp_expr_7039)))))
            },
            crate::lower::model::Ex::XCast(y, t) => {
                let cp = cp.clone();
                let t = t.clone();
                let y = (**y).clone();
                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), t.clone()), move |cpp_type_7087: Text| call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_7104: Text| prism_rtl::Turn::Finished(Text::from(format!("static_cast<{}>({})", &cpp_type_7087, &cpp_expr_7104)))))
            },
            crate::lower::model::Ex::XTyped(y, t) => {
                let cp = cp.clone();
                let t = t.clone();
                let y = (**y).clone();
                call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_7154: Text| {
                    let e = cpp_expr_7154;
                    if (&e == &Text::lit("{}")) || (&e == &Text::lit("std::nullopt")) {
                        call_then(crate::emit::cpp::start_cpp_type(cp.clone(), t.clone()), move |cpp_type_7217: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{{}}", &cpp_type_7217))))
                    } else {
                        if is_ctor(&y, &Text::lit("Ok")) || is_ctor(&y, &Text::lit("Err")) {
                            call_then(crate::emit::cpp::start_cpp_type(cp.clone(), t.clone()), move |cpp_type_7293: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &cpp_type_7293, &e))))
                        } else {
                            prism_rtl::Turn::Finished(e.clone())
                        }
                    }
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start CppExpr, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_expr(cp: crate::emit::cpp::Cp, x: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppExpr { cp, x })
}

/// ```prism
/// CppString: fn Text -> Text
/// ```
pub fn cpp_string(t: &Text) -> Text {
    if crate::syntax::lexer::chars::contains(t, &Text::lit("\0")) {
        Text::from(format!("\"{}\"sv", &cpp_escape(t)))
    } else {
        Text::from(format!("\"{}\"", &cpp_escape(t)))
    }
}

/// ```prism
/// CppEscape: fn Text -> Text
/// ```
pub fn cpp_escape(t: &Text) -> Text {
    crate::syntax::lexer::chars::map_chars(t, &(Rc::new(move |p0: Text| once_job(move || {
        let c = p0;
        if &c == &Text::lit("\0") {
            prism_rtl::Turn::Finished(Text::lit("\\000"))
        } else {
            prism_rtl::Turn::Finished(crate::lower::expr::char_escape(&c))
        }
    })) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>))
}

/// ```prism
/// IsTextPiece: fn Ex -> Bool
/// ```
pub fn is_text_piece(ex0: &crate::lower::model::Ex) -> bool {
    match ex0 {
        crate::lower::model::Ex::XText(_) => true,
        other => false,
    }
}

/// ```prism
/// TextPiece: fn Ex -> Text
/// ```
pub fn text_piece(ex0: &crate::lower::model::Ex) -> Text {
    match ex0 {
        crate::lower::model::Ex::XText(t) => t.clone(),
        other => Text::lit(""),
    }
}

/// ```prism
/// CppFormat: unbounded fn Cp, [Ex], Text -> Text
/// ```
pub fn cpp_format(cp: &crate::emit::cpp::Cp, parts: &Array<crate::lower::model::Ex>, how: &Text) -> Text {
    Text::from(format!("{}({})", how, &crate::syntax::lexer::chars::join(&cpp_arg_list(cp, &each(parts, &(|p_: &crate::lower::model::Ex| format_arg(p_)))), &Text::lit(", "))))
}

/// The step machine of `CppFormat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppFormat: unbounded fn Cp, [Ex], Text -> Text
/// ```
pub struct CppFormat {
    pub cp: crate::emit::cpp::Cp,
    pub parts: Array<crate::lower::model::Ex>,
    pub how: Text,
}

impl prism_rtl::Job<Text> for CppFormat {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let parts = &self.parts;
        let how = &self.how;
        let cp = cp.clone();
        let how = how.clone();
        let parts = parts.clone();
        call_then(start_cpp_arg_list(cp.clone(), each(&parts, &(|p_: &crate::lower::model::Ex| format_arg(p_)))), move |cpp_arg_list_8085: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &how, &crate::syntax::lexer::chars::join(&cpp_arg_list_8085, &Text::lit(", "))))))
    }
}

/// `Start CppFormat, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_format(cp: crate::emit::cpp::Cp, parts: Array<crate::lower::model::Ex>, how: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppFormat { cp, parts, how })
}

/// ```prism
/// FormatArg: fn Ex -> Ex
/// ```
pub fn format_arg(ex0: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    match ex0 {
        crate::lower::model::Ex::XText(t) => crate::lower::model::Ex::XStr(t.clone()),
        x => x.clone(),
    }
}

/// ```prism
/// CppCharEscape: fn Text -> Text
/// ```
pub fn cpp_char_escape(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("\'")) => Text::lit("\\\'"),
        c => crate::lower::expr::char_escape(c),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// PathValue: fn Cp, Text -> Text
/// ```
pub fn path_value(cp: &crate::emit::cpp::Cp, p_: &Text) -> Text {
    if is_node_method(cp, p_) {
        Text::from(format!("&{}::{}", &crate::emit::cpp::type_path(&crate::emit::cpp::parent_path(p_)), &node_method_name(cp, &crate::emit::cpp::last_segment(p_))))
    } else {
        match crate::emit::cpp::case_of(cp, p_) {
            Some(ty) => Text::from(format!("{}({}{{}})", &crate::emit::cpp::type_path(&ty), &crate::emit::cpp::type_path(p_))),
            None => match crate::emit::cpp::type_of(cp, p_) {
                Some(info) => if &info.kind == &Text::lit("unit") {
                    Text::from(format!("{}{{}}", &crate::emit::cpp::type_path(p_)))
                } else {
                    crate::emit::cpp::type_path(p_)
                },
                None => crate::emit::cpp::type_path(p_),
            },
        }
    }
}

/// ```prism
/// IsNodeMethod: fn Cp, Text -> Bool
/// ```
pub fn is_node_method(cp: &crate::emit::cpp::Cp, p_: &Text) -> bool {
    let named_ = match get(&cp.methods, &crate::emit::cpp::last_segment(p_)) {
        Some(_) => true,
        None => false,
    };
    named_ && is_node_type(cp, &crate::emit::cpp::parent_path(p_))
}

/// ```prism
/// IsNodeType: fn Cp, Text -> Bool
/// ```
pub fn is_node_type(cp: &crate::emit::cpp::Cp, p_: &Text) -> bool {
    match crate::emit::cpp::type_of(cp, p_) {
        Some(info) => &info.kind == &Text::lit("node"),
        None => false,
    }
}

/// ```prism
/// CppField: unbounded fn Cp, Ex, Text -> Text
/// ```
pub fn cpp_field(cp: &crate::emit::cpp::Cp, ex1: &crate::lower::model::Ex, f: &Text) -> Text {
    match ex1 {
        crate::lower::model::Ex::XSelf => Text::from(format!("this->{}", &crate::emit::cpp::field_id(f))),
        r => {
            let name = if is_digits(f) {
                Text::from(format!("a{}", f))
            } else {
                crate::emit::cpp::field_id(f)
            };
            match pointer(cp, r) {
                Some(b) => Text::from(format!("{}{}{}", &cpp_tight_place(cp, r), &(if b { Text::lit("->") } else { Text::lit(".") }), &name)),
                None => match get(&cp.members, f) {
                    Some(_) => Text::from(format!("{}->{}", &cpp_tight_place(cp, r), &name)),
                    None => Text::from(format!("{}.{}", &as_value(cp, r), &name)),
                },
            }
        },
    }
}

/// The step machine of `CppField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppField: unbounded fn Cp, Ex, Text -> Text
/// ```
pub struct CppField {
    pub cp: crate::emit::cpp::Cp,
    pub ex1: crate::lower::model::Ex,
    pub f: Text,
}

impl prism_rtl::Job<Text> for CppField {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let ex1 = &self.ex1;
        let f = &self.f;
        match ex1 {
            crate::lower::model::Ex::XSelf => prism_rtl::Turn::Finished(Text::from(format!("this->{}", &crate::emit::cpp::field_id(f)))),
            r => {
                let name = if is_digits(f) {
                    Text::from(format!("a{}", f))
                } else {
                    crate::emit::cpp::field_id(f)
                };
                match pointer(cp, r) {
                    Some(b) => {
                        let cp = cp.clone();
                        let r = r.clone();
                        call_then(start_cpp_tight_place(cp.clone(), r.clone()), move |cpp_tight_place_9818: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}{}", &cpp_tight_place_9818, &(if b { Text::lit("->") } else { Text::lit(".") }), &name))))
                    },
                    None => match get(&cp.members, f) {
                        Some(_) => {
                            let cp = cp.clone();
                            let r = r.clone();
                            call_then(start_cpp_tight_place(cp.clone(), r.clone()), move |cpp_tight_place_9926: Text| prism_rtl::Turn::Finished(Text::from(format!("{}->{}", &cpp_tight_place_9926, &name))))
                        },
                        None => {
                            let cp = cp.clone();
                            let r = r.clone();
                            call_then(start_as_value(cp.clone(), r.clone()), move |as_value_9975: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.{}", &as_value_9975, &name))))
                        },
                    },
                }
            },
        }
    }
}

/// `Start CppField, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_field(cp: crate::emit::cpp::Cp, ex1: crate::lower::model::Ex, f: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppField { cp, ex1, f })
}

/// ```prism
/// AsValue: unbounded fn Cp, Ex -> Text
/// ```
pub fn as_value(cp: &crate::emit::cpp::Cp, r: &crate::lower::model::Ex) -> Text {
    match pointer(cp, r) {
        Some(false) => cpp_tight_place(cp, r),
        _ => Text::from(format!("prism_rtl::deref({})", &cpp_place(cp, r))),
    }
}

/// The step machine of `AsValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AsValue: unbounded fn Cp, Ex -> Text
/// ```
pub struct AsValue {
    pub cp: crate::emit::cpp::Cp,
    pub r: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for AsValue {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let r = &self.r;
        match pointer(cp, r) {
            Some(false) => prism_rtl::Turn::More(Rc::new(CppTightPlace { cp: cp.clone(), x: r.clone() })),
            _ => {
                let cp = cp.clone();
                let r = r.clone();
                call_then(start_cpp_place(cp.clone(), r.clone()), move |cpp_place_10258: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::deref({})", &cpp_place_10258))))
            },
        }
    }
}

/// `Start AsValue, x`: what the function value is when passed to `@Run`.
pub fn start_as_value(cp: crate::emit::cpp::Cp, r: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(AsValue { cp, r })
}

/// ```prism
/// ?ExTy: fn Cp, Ex -> ?OutTy
/// ```
pub fn ex_ty(cp: &crate::emit::cpp::Cp, x: &crate::lower::model::Ex) -> Option<crate::lower::model::OutTy> {
    'm10495: {
        if let crate::lower::model::Ex::XVar(n) = x {
            break 'm10495 get(&cp.local_types, n);
        }
        if let crate::lower::model::Ex::XField(m10495_1_0, f) = x && let crate::lower::model::Ex::XSelf = &**m10495_1_0 {
            break 'm10495 get(&cp.fields, f);
        }
        if let crate::lower::model::Ex::XField(m10495_2_0, f) = x && let crate::lower::model::Ex::XVar(m10495_2_0_r_0) = &**m10495_2_0 && (m10495_2_0_r_0 == &Text::lit("node")) {
            break 'm10495 get(&cp.fields, f);
        }
        if let crate::lower::model::Ex::XRef(y) = x {
            break 'm10495 match ex_ty(cp, &**y) {
                Some(t) => Some(crate::lower::model::OutTy::OutRef(Rc::new(t))),
                None => None,
            };
        }
        if let crate::lower::model::Ex::XDeref(y) = x {
            break 'm10495 match ex_ty(cp, &**y) {
                Some(crate::lower::model::OutTy::OutRef(t)) => Some((*t).clone()),
                Some(crate::lower::model::OutTy::OutRc(t)) => Some((*t).clone()),
                _ => None,
            };
        }
        None
    }
}

/// ```prism
/// IsDigits: fn Text -> Bool
/// ```
pub fn is_digits(t: &Text) -> bool {
    (t != &Text::lit("")) && crate::syntax::lexer::chars::fold_chars(t, &true, &(Rc::new(move |(p0, p1): (bool, Text)| once_job(move || {
        let ok_ = p0;
        let c = p1;
        prism_rtl::Turn::Finished(ok_ && crate::syntax::lexer::chars::contains(&Text::lit("0123456789"), &c))
    })) as Rc<dyn Fn((bool, Text)) -> Rc<dyn prism_rtl::Job<bool>>>))
}

/// ```prism
/// CppCtor: unbounded fn Cp, Text, [Ex] -> Text
/// ```
pub fn cpp_ctor(cp: &crate::emit::cpp::Cp, p_: &Text, args: &Array<crate::lower::model::Ex>) -> Text {
    match p_ {
        m11127_0 if (m11127_0 == &Text::lit("Some")) => Text::from(format!("std::optional({})", &cpp_args(cp, args))),
        m11127_1 if (m11127_1 == &Text::lit("Ok")) => if args == &Array::from(vec![crate::lower::model::Ex::XUnit]) {
            Text::lit("prism_rtl::ok()")
        } else {
            cpp_args(cp, args)
        },
        m11127_2 if (m11127_2 == &Text::lit("Err")) => Text::from(format!("unexpected({})", &cpp_args(cp, args))),
        m11127_3 if (m11127_3 == &Text::lit("prism_rtl::Turn::More")) => Text::from(format!("prism_rtl::more({})", &cpp_args(cp, args))),
        m11127_4 if (m11127_4 == &Text::lit("prism_rtl::Turn::Finished")) => Text::from(format!("prism_rtl::finished({})", &cpp_args(cp, args))),
        m11127_5 if (m11127_5 == &Text::lit("Outcome::Fired")) => Text::from(format!("Outcome::fired({})", &cpp_args(cp, args))),
        m11127_6 if (m11127_6 == &Text::lit("Outcome::Value")) => Text::from(format!("Outcome::value({})", &cpp_args(cp, args))),
        m11127_7 if (m11127_7 == &Text::lit("Segment::Pos")) => Text::from(format!("Segment::pos({})", &cpp_args(cp, args))),
        m11127_8 if (m11127_8 == &Text::lit("Segment::Gen")) => Text::from(format!("Segment::gen({})", &cpp_args(cp, args))),
        m11127_9 if (m11127_9 == &Text::lit("Segment::Key")) => Text::from(format!("Segment::key({})", &cpp_args(cp, args))),
        _ => match crate::emit::cpp::case_of(cp, p_) {
            Some(ty) => Text::from(format!("{}({}{{{}}})", &crate::emit::cpp::type_path(&ty), &crate::emit::cpp::type_path(p_), &cpp_args(cp, args))),
            None => Text::from(format!("{}{{{}}}", &crate::emit::cpp::type_path(p_), &cpp_args(cp, args))),
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CppCtor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppCtor: unbounded fn Cp, Text, [Ex] -> Text
/// ```
pub struct CppCtor {
    pub cp: crate::emit::cpp::Cp,
    pub p_: Text,
    pub args: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for CppCtor {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let p_ = &self.p_;
        let args = &self.args;
        match p_ {
            m11127_0 if (m11127_0 == &Text::lit("Some")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_11164: Text| prism_rtl::Turn::Finished(Text::from(format!("std::optional({})", &cpp_args_11164))))
            },
            m11127_1 if (m11127_1 == &Text::lit("Ok")) => if args == &Array::from(vec![crate::lower::model::Ex::XUnit]) {
                prism_rtl::Turn::Finished(Text::lit("prism_rtl::ok()"))
            } else {
                prism_rtl::Turn::More(Rc::new(CppArgs { cp: cp.clone(), xs: args.clone() }))
            },
            m11127_2 if (m11127_2 == &Text::lit("Err")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_11281: Text| prism_rtl::Turn::Finished(Text::from(format!("unexpected({})", &cpp_args_11281))))
            },
            m11127_3 if (m11127_3 == &Text::lit("prism_rtl::Turn::More")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_11348: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::more({})", &cpp_args_11348))))
            },
            m11127_4 if (m11127_4 == &Text::lit("prism_rtl::Turn::Finished")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_11423: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::finished({})", &cpp_args_11423))))
            },
            m11127_5 if (m11127_5 == &Text::lit("Outcome::Fired")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_11482: Text| prism_rtl::Turn::Finished(Text::from(format!("Outcome::fired({})", &cpp_args_11482))))
            },
            m11127_6 if (m11127_6 == &Text::lit("Outcome::Value")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_11541: Text| prism_rtl::Turn::Finished(Text::from(format!("Outcome::value({})", &cpp_args_11541))))
            },
            m11127_7 if (m11127_7 == &Text::lit("Segment::Pos")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_11596: Text| prism_rtl::Turn::Finished(Text::from(format!("Segment::pos({})", &cpp_args_11596))))
            },
            m11127_8 if (m11127_8 == &Text::lit("Segment::Gen")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_11651: Text| prism_rtl::Turn::Finished(Text::from(format!("Segment::gen({})", &cpp_args_11651))))
            },
            m11127_9 if (m11127_9 == &Text::lit("Segment::Key")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_11706: Text| prism_rtl::Turn::Finished(Text::from(format!("Segment::key({})", &cpp_args_11706))))
            },
            _ => match crate::emit::cpp::case_of(cp, p_) {
                Some(ty) => {
                    let args = args.clone();
                    let cp = cp.clone();
                    let p_ = p_.clone();
                    call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_11806: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({}{{{}}})", &crate::emit::cpp::type_path(&ty), &crate::emit::cpp::type_path(&p_), &cpp_args_11806))))
                },
                None => {
                    let args = args.clone();
                    let cp = cp.clone();
                    let p_ = p_.clone();
                    call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_11857: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{{{}}}", &crate::emit::cpp::type_path(&p_), &cpp_args_11857))))
                },
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start CppCtor, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_ctor(cp: crate::emit::cpp::Cp, p_: Text, args: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppCtor { cp, p_, args })
}

/// ```prism
/// CppRecord: unbounded fn Cp, Text, [((Text, Ex))] -> Text
/// ```
pub fn cpp_record(cp: &crate::emit::cpp::Cp, p_: &Text, fs: &Array<(Text, crate::lower::model::Ex)>) -> Text {
    let ordered = match crate::emit::cpp::type_of(cp, p_) {
        Some(info) => each(&info.fields, &(|f: &Text| or(&fold(fs, &None, &(|found_opt: &Option<crate::lower::model::Ex>, (g, v_): &(Text, crate::lower::model::Ex)| if g == f { Some(v_.clone()) } else { found_opt.clone() })), &crate::lower::model::Ex::XUnit))),
        None => each(fs, &(|(_, v_): &(Text, crate::lower::model::Ex)| v_.clone())),
    };
    let names = match crate::emit::cpp::type_of(cp, p_) {
        Some(info) => info.fields.clone(),
        None => each(fs, &(|(g, _): &(Text, crate::lower::model::Ex)| g.clone())),
    };
    let kind = match crate::emit::cpp::type_of(cp, p_) {
        Some(info) => info.kind.clone(),
        None => Text::lit(""),
    };
    let values_ = cpp_arg_list(cp, &ordered);
    if &kind == &Text::lit("job") {
        Text::from(format!("{}({})", &crate::emit::cpp::type_path(p_), &crate::syntax::lexer::chars::join(&values_, &Text::lit(", "))))
    } else {
        Text::from(format!("{}{{{}}}", &crate::emit::cpp::type_path(p_), &crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&len(&names)), &(|i: &Nat| Text::from(format!(".{} = {}", &crate::emit::cpp::field_id(&or(&index(&names, i), &Text::lit(""))), &or(&index(&values_, i), &Text::lit("")))))), &Text::lit(", "))))
    }
}

/// The step machine of `CppRecord`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppRecord: unbounded fn Cp, Text, [((Text, Ex))] -> Text
/// ```
pub struct CppRecord {
    pub cp: crate::emit::cpp::Cp,
    pub p_: Text,
    pub fs: Array<(Text, crate::lower::model::Ex)>,
}

impl prism_rtl::Job<Text> for CppRecord {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let p_ = &self.p_;
        let fs = &self.fs;
        let ordered = match crate::emit::cpp::type_of(cp, p_) {
            Some(info) => each(&info.fields, &(|f: &Text| or(&fold(fs, &None, &(|found_opt: &Option<crate::lower::model::Ex>, (g, v_): &(Text, crate::lower::model::Ex)| if g == f { Some(v_.clone()) } else { found_opt.clone() })), &crate::lower::model::Ex::XUnit))),
            None => each(fs, &(|(_, v_): &(Text, crate::lower::model::Ex)| v_.clone())),
        };
        let names = match crate::emit::cpp::type_of(cp, p_) {
            Some(info) => info.fields.clone(),
            None => each(fs, &(|(g, _): &(Text, crate::lower::model::Ex)| g.clone())),
        };
        let kind = match crate::emit::cpp::type_of(cp, p_) {
            Some(info) => info.kind.clone(),
            None => Text::lit(""),
        };
        let cp = cp.clone();
        let p_ = p_.clone();
        call_then(start_cpp_arg_list(cp.clone(), ordered.clone()), move |cpp_arg_list_12456: Array<Text>| {
            let values_ = cpp_arg_list_12456;
            if &kind == &Text::lit("job") {
                prism_rtl::Turn::Finished(Text::from(format!("{}({})", &crate::emit::cpp::type_path(&p_), &crate::syntax::lexer::chars::join(&values_, &Text::lit(", ")))))
            } else {
                prism_rtl::Turn::Finished(Text::from(format!("{}{{{}}}", &crate::emit::cpp::type_path(&p_), &crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&len(&names)), &(|i: &Nat| Text::from(format!(".{} = {}", &crate::emit::cpp::field_id(&or(&index(&names, i), &Text::lit(""))), &or(&index(&values_, i), &Text::lit("")))))), &Text::lit(", ")))))
            }
        })
    }
}

/// `Start CppRecord, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_record(cp: crate::emit::cpp::Cp, p_: Text, fs: Array<(Text, crate::lower::model::Ex)>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppRecord { cp, p_, fs })
}

/// ```prism
/// CppCall: unbounded fn Cp, Text, [Ex] -> Text
/// ```
pub fn cpp_call(cp: &crate::emit::cpp::Cp, f: &Text, args: &Array<crate::lower::model::Ex>) -> Text {
    let a = cpp_args(cp, args);
    match f {
        m12901_0 if (m12901_0 == &Text::lit("Rc::new")) => if &a == &Text::lit("{}") {
            Text::lit("prism_rtl::make_new()")
        } else {
            Text::from(format!("prism_rtl::rc({})", &a))
        },
        m12901_1 if (m12901_1 == &Text::lit("is_some")) => Text::from(format!("prism_rtl::is_some({})", &a)),
        m12901_2 if (m12901_2 == &Text::lit("is_none")) => Text::from(format!("prism_rtl::is_none({})", &a)),
        m12901_3 if (m12901_3 == &Text::lit("RefCell::new")) => a.clone(),
        m12901_4 if (m12901_4 == &Text::lit("Cell::new")) => a.clone(),
        m12901_5 if (m12901_5 == &Text::lit("Hold::new")) => Text::from(format!("{{{}}}", &a)),
        m12901_6 if (m12901_6 == &Text::lit("Snapshot::new")) => Text::from(format!("snapshot({})", &a)),
        m12901_7 if (m12901_7 == &Text::lit("Path::root")) => Text::lit("Path::root()"),
        m12901_8 if (m12901_8 == &Text::lit("Fault::answer")) => Text::from(format!("Fault::answer({})", &a)),
        m12901_9 if (m12901_9 == &Text::lit("Fault::too_deep")) => Text::from(format!("Fault::too_deep({})", &a)),
        m12901_10 if (m12901_10 == &Text::lit("Error::new")) => Text::from(format!("Error({})", &a)),
        m12901_11 if (m12901_11 == &Text::lit("Text::from")) => Text::from(format!("Text({})", &a)),
        m12901_12 if (m12901_12 == &Text::lit("String::new")) => Text::lit("std::string()"),
        m12901_13 if (m12901_13 == &Text::lit("Array::from")) => Text::from(format!("Array({})", &a)),
        m12901_14 if (m12901_14 == &Text::lit("prism_rtl::Dynamic::of")) => Text::from(format!("dynamic_of({})", &a)),
        m12901_15 if (m12901_15 == &Text::lit("Dynamic::of")) => Text::from(format!("dynamic_of({})", &a)),
        m12901_16 if (m12901_16 == &Text::lit("prism_rtl::Event::of")) => Text::from(format!("event_of({})", &a)),
        m12901_17 if (m12901_17 == &Text::lit("prism_rtl::Host::new")) => Text::from(format!("host_new({})", &a)),
        m12901_18 if (m12901_18 == &Text::lit("prism_rtl::Entry::new")) => Text::from(format!("entry_new({})", &a)),
        m12901_19 if (m12901_19 == &Text::lit("prism_rtl::forward_on_none")) => Text::from(format!("prism_rtl::forward_on_none<crate::Elem, crate::Answer>({})", &a)),
        m12901_20 if (m12901_20 == &Text::lit("Event::never")) => Text::lit("never_event()"),
        _ => if is_fresh(f) {
            Text::lit("{}")
        } else {
            Text::from(format!("{}({})", &free_call_path(cp, f), &a))
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CppCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppCall: unbounded fn Cp, Text, [Ex] -> Text
/// ```
pub struct CppCall {
    pub cp: crate::emit::cpp::Cp,
    pub f: Text,
    pub args: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for CppCall {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let f = &self.f;
        let args = &self.args;
        let args = args.clone();
        let cp = cp.clone();
        let f = f.clone();
        call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_12880: Text| {
            let a = cpp_args_12880;
            match &f {
                m12901_0 if (m12901_0 == &Text::lit("Rc::new")) => if &a == &Text::lit("{}") {
                    prism_rtl::Turn::Finished(Text::lit("prism_rtl::make_new()"))
                } else {
                    prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::rc({})", &a)))
                },
                m12901_1 if (m12901_1 == &Text::lit("is_some")) => prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::is_some({})", &a))),
                m12901_2 if (m12901_2 == &Text::lit("is_none")) => prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::is_none({})", &a))),
                m12901_3 if (m12901_3 == &Text::lit("RefCell::new")) => prism_rtl::Turn::Finished(a.clone()),
                m12901_4 if (m12901_4 == &Text::lit("Cell::new")) => prism_rtl::Turn::Finished(a.clone()),
                m12901_5 if (m12901_5 == &Text::lit("Hold::new")) => prism_rtl::Turn::Finished(Text::from(format!("{{{}}}", &a))),
                m12901_6 if (m12901_6 == &Text::lit("Snapshot::new")) => prism_rtl::Turn::Finished(Text::from(format!("snapshot({})", &a))),
                m12901_7 if (m12901_7 == &Text::lit("Path::root")) => prism_rtl::Turn::Finished(Text::lit("Path::root()")),
                m12901_8 if (m12901_8 == &Text::lit("Fault::answer")) => prism_rtl::Turn::Finished(Text::from(format!("Fault::answer({})", &a))),
                m12901_9 if (m12901_9 == &Text::lit("Fault::too_deep")) => prism_rtl::Turn::Finished(Text::from(format!("Fault::too_deep({})", &a))),
                m12901_10 if (m12901_10 == &Text::lit("Error::new")) => prism_rtl::Turn::Finished(Text::from(format!("Error({})", &a))),
                m12901_11 if (m12901_11 == &Text::lit("Text::from")) => prism_rtl::Turn::Finished(Text::from(format!("Text({})", &a))),
                m12901_12 if (m12901_12 == &Text::lit("String::new")) => prism_rtl::Turn::Finished(Text::lit("std::string()")),
                m12901_13 if (m12901_13 == &Text::lit("Array::from")) => prism_rtl::Turn::Finished(Text::from(format!("Array({})", &a))),
                m12901_14 if (m12901_14 == &Text::lit("prism_rtl::Dynamic::of")) => prism_rtl::Turn::Finished(Text::from(format!("dynamic_of({})", &a))),
                m12901_15 if (m12901_15 == &Text::lit("Dynamic::of")) => prism_rtl::Turn::Finished(Text::from(format!("dynamic_of({})", &a))),
                m12901_16 if (m12901_16 == &Text::lit("prism_rtl::Event::of")) => prism_rtl::Turn::Finished(Text::from(format!("event_of({})", &a))),
                m12901_17 if (m12901_17 == &Text::lit("prism_rtl::Host::new")) => prism_rtl::Turn::Finished(Text::from(format!("host_new({})", &a))),
                m12901_18 if (m12901_18 == &Text::lit("prism_rtl::Entry::new")) => prism_rtl::Turn::Finished(Text::from(format!("entry_new({})", &a))),
                m12901_19 if (m12901_19 == &Text::lit("prism_rtl::forward_on_none")) => prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::forward_on_none<crate::Elem, crate::Answer>({})", &a))),
                m12901_20 if (m12901_20 == &Text::lit("Event::never")) => prism_rtl::Turn::Finished(Text::lit("never_event()")),
                _ => if is_fresh(&f) {
                    prism_rtl::Turn::Finished(Text::lit("{}"))
                } else {
                    prism_rtl::Turn::Finished(Text::from(format!("{}({})", &free_call_path(&cp, &f), &a)))
                },
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start CppCall, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_call(cp: crate::emit::cpp::Cp, f: Text, args: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppCall { cp, f, args })
}

/// ```prism
/// FreeCallPath: fn Cp, Text -> Text
/// ```
pub fn free_call_path(cp: &crate::emit::cpp::Cp, f: &Text) -> Text {
    let p_ = call_path(f);
    let hidden = match get(&cp.members, f) {
        Some(_) => true,
        None => crate::emit::cpp::in_list(&std_names(), &p_) || crate::emit::cpp::in_list(&cp.mods, &p_),
    };
    if crate::syntax::lexer::chars::contains(&p_, &Text::lit(":")) {
        p_.clone()
    } else {
        if hidden { qualified_call(cp, f, &p_) } else { p_.clone() }
    }
}

/// ```prism
/// QualifiedCall: fn Cp, Text, Text -> Text
/// ```
pub fn qualified_call(cp: &crate::emit::cpp::Cp, f: &Text, p_: &Text) -> Text {
    match get(&cp.fns, &Text::from(format!("{}::{}", &cp.home, f))) {
        Some(_) => Text::from(format!("crate::{}::{}", &cp.home, p_)),
        None => Text::from(format!("crate::prelude::{}", p_)),
    }
}

/// ```prism
/// let stdNames
/// ```
pub fn std_names() -> Array<Text> {
    Array::from(vec![Text::lit("apply"), Text::lit("begin"), Text::lit("end"), Text::lit("size"), Text::lit("empty"), Text::lit("data"), Text::lit("get"), Text::lit("swap"), Text::lit("move"), Text::lit("forward"), Text::lit("find"), Text::lit("count"), Text::lit("copy"), Text::lit("fill"), Text::lit("sort"), Text::lit("min"), Text::lit("max"), Text::lit("visit"), Text::lit("invoke"), Text::lit("merge"), Text::lit("remove"), Text::lit("replace"), Text::lit("reverse"), Text::lit("unique"), Text::lit("transform"), Text::lit("accumulate"), Text::lit("distance"), Text::lit("next"), Text::lit("prev"), Text::lit("exchange"), Text::lit("tie"), Text::lit("to_string"), Text::lit("clamp"), Text::lit("partition"), Text::lit("equal"), Text::lit("mismatch"), Text::lit("erase"), Text::lit("search"), Text::lit("rotate")])
}

/// ```prism
/// IsFresh: fn Text -> Bool
/// ```
pub fn is_fresh(f: &Text) -> bool {
    crate::emit::cpp::in_list(&Array::from(vec![Text::lit("Stamped::new"), Text::lit("Cache::new"), Text::lit("Port::new"), Text::lit("Map::new"), Text::lit("Array::new"), Text::lit("Vec::new"), Text::lit("Default::default"), Text::lit("Wakes::default"), Text::lit("Defer::new"), Text::lit("prism_rtl::HostDoc::new"), Text::lit("prism_rtl::Watch::new"), Text::lit("prism_rtl::PerKey::new")]), f)
}

/// ```prism
/// CallPath: fn Text -> Text
/// ```
pub fn call_path(f: &Text) -> Text {
    let last = crate::emit::cpp::last_segment(f);
    let owner = crate::emit::cpp::last_segment(&crate::emit::cpp::parent_path(f));
    let is_type = (&crate::emit::cpp::parent_path(f) != &Text::lit("")) && crate::syntax::lexer::chars::contains(&Text::lit("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), &crate::syntax::lexer::chars::head(&owner));
    if (&last == &Text::lit("build")) && is_type {
        Text::from(format!("{}::make", &crate::emit::cpp::type_path(&crate::emit::cpp::parent_path(f))))
    } else {
        if &last == &Text::lit("new") {
            crate::emit::cpp::type_path(&crate::emit::cpp::parent_path(f))
        } else {
            crate::emit::cpp::cpp_path_id(&crate::emit::cpp::type_path(f))
        }
    }
}

/// ```prism
/// CppMethod: unbounded fn Cp, Ex, Text, [Ex] -> Text
/// ```
pub fn cpp_method(cp: &crate::emit::cpp::Cp, r: &crate::lower::model::Ex, m: &Text, args: &Array<crate::lower::model::Ex>) -> Text {
    let recv = if r == &crate::lower::model::Ex::XSelf {
        Text::lit("this")
    } else {
        cpp_tight_place(cp, r)
    };
    let a = cpp_args(cp, args);
    let n = len(args);
    let sep = if &n == &Nat::from(0u32) { Text::lit("") } else { Text::lit(", ") };
    match method_form(m, &n) {
        m16237_0 if (&m16237_0 == &Text::lit("id")) => recv.clone(),
        m16237_1 if (&m16237_1 == &Text::lit("deref")) => match pointer(cp, r) {
            Some(b) => if b { Text::from(format!("(*{})", &recv)) } else { recv.clone() },
            None => recv.clone(),
        },
        m16237_2 if (&m16237_2 == &Text::lit("assign")) => Text::from(format!("{} = {}", &recv, &a)),
        m16237_3 if (&m16237_3 == &Text::lit("take")) => Text::from(format!("std::exchange({}, {{}})", &recv)),
        m16237_4 if (&m16237_4 == &Text::lit("free")) => Text::from(format!("{}({}{}{})", &free_name(m), &recv, &sep, &a)),
        m16237_5 if (&m16237_5 == &Text::lit("arrow")) => {
            let through = match pointer(cp, r) {
                Some(b) => if b { Text::lit("->") } else { Text::lit(".") },
                None => Text::lit("->"),
            };
            Text::from(format!("{}{}{}({})", &recv, &through, &member_name(m), &a))
        },
        m16237_6 if (&m16237_6 == &Text::lit("exchange")) => Text::from(format!("std::exchange({}, {})", &recv, &a)),
        _ => {
            let through = match pointer(cp, r) {
                Some(b) => if b { Text::lit("->") } else { Text::lit(".") },
                None => match get(&cp.members, m) {
                    Some(_) => Text::lit("->"),
                    None => Text::lit("."),
                },
            };
            Text::from(format!("{}{}{}({})", &recv, &through, &node_method_name(cp, m), &a))
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CppMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppMethod: unbounded fn Cp, Ex, Text, [Ex] -> Text
/// ```
pub struct CppMethod {
    pub cp: crate::emit::cpp::Cp,
    pub r: crate::lower::model::Ex,
    pub m: Text,
    pub args: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for CppMethod {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let r = &self.r;
        let m = &self.m;
        let args = &self.args;
        let recv = if r == &crate::lower::model::Ex::XSelf {
            Text::lit("this")
        } else {
            cpp_tight_place(cp, r)
        };
        let args = args.clone();
        let cp = cp.clone();
        let m = m.clone();
        let r = r.clone();
        call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_16156: Text| {
            let a = cpp_args_16156;
            let n = len(&args);
            let sep = if &n == &Nat::from(0u32) { Text::lit("") } else { Text::lit(", ") };
            match method_form(&m, &n) {
                m16237_0 if (&m16237_0 == &Text::lit("id")) => prism_rtl::Turn::Finished(recv.clone()),
                m16237_1 if (&m16237_1 == &Text::lit("deref")) => match pointer(&cp, &r) {
                    Some(b) => if b {
                        prism_rtl::Turn::Finished(Text::from(format!("(*{})", &recv)))
                    } else {
                        prism_rtl::Turn::Finished(recv.clone())
                    },
                    None => prism_rtl::Turn::Finished(recv.clone()),
                },
                m16237_2 if (&m16237_2 == &Text::lit("assign")) => prism_rtl::Turn::Finished(Text::from(format!("{} = {}", &recv, &a))),
                m16237_3 if (&m16237_3 == &Text::lit("take")) => prism_rtl::Turn::Finished(Text::from(format!("std::exchange({}, {{}})", &recv))),
                m16237_4 if (&m16237_4 == &Text::lit("free")) => prism_rtl::Turn::Finished(Text::from(format!("{}({}{}{})", &free_name(&m), &recv, &sep, &a))),
                m16237_5 if (&m16237_5 == &Text::lit("arrow")) => {
                    let through = match pointer(&cp, &r) {
                        Some(b) => if b { Text::lit("->") } else { Text::lit(".") },
                        None => Text::lit("->"),
                    };
                    prism_rtl::Turn::Finished(Text::from(format!("{}{}{}({})", &recv, &through, &member_name(&m), &a)))
                },
                m16237_6 if (&m16237_6 == &Text::lit("exchange")) => prism_rtl::Turn::Finished(Text::from(format!("std::exchange({}, {})", &recv, &a))),
                _ => {
                    let through = match pointer(&cp, &r) {
                        Some(b) => if b { Text::lit("->") } else { Text::lit(".") },
                        None => match get(&cp.members, &m) {
                            Some(_) => Text::lit("->"),
                            None => Text::lit("."),
                        },
                    };
                    prism_rtl::Turn::Finished(Text::from(format!("{}{}{}({})", &recv, &through, &node_method_name(&cp, &m), &a)))
                },
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start CppMethod, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_method(cp: crate::emit::cpp::Cp, r: crate::lower::model::Ex, m: Text, args: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppMethod { cp, r, m, args })
}

/// ```prism
/// NodeMethodName: fn Cp, Text -> Text
/// ```
pub fn node_method_name(cp: &crate::emit::cpp::Cp, m: &Text) -> Text {
    match (get(&cp.methods, m), get(&cp.field_names, m)) {
        (Some(_), Some(_)) => Text::from(format!("{}_", &crate::emit::cpp::cpp_id(m))),
        _ => member_name(m),
    }
}

/// ```prism
/// ?Pointer: fn Cp, Ex -> ?Bool
/// ```
pub fn pointer(cp: &crate::emit::cpp::Cp, r: &crate::lower::model::Ex) -> Option<bool> {
    'm17753: {
        if let crate::lower::model::Ex::XSelf = r {
            break 'm17753 Some(true);
        }
        if let crate::lower::model::Ex::XCx = r {
            break 'm17753 Some(false);
        }
        if let crate::lower::model::Ex::XVar(m17753_2_0) = r && (m17753_2_0 == &Text::lit("path")) {
            break 'm17753 Some(false);
        }
        if let crate::lower::model::Ex::XField(_, m17753_3_1) = r && (m17753_3_1 == &Text::lit("path")) {
            break 'm17753 Some(false);
        }
        if let crate::lower::model::Ex::XCall(m17753_4_0, _) = r && (m17753_4_0 == &Text::lit("Path::root")) {
            break 'm17753 Some(false);
        }
        if let crate::lower::model::Ex::XMethod(y, m, _) = r && (((m == &Text::lit("at")) || (m == &Text::lit("child"))) || (m == &Text::lit("join"))) {
            break 'm17753 match pointer(cp, &**y) {
                Some(false) => Some(false),
                _ => None,
            };
        }
        if let crate::lower::model::Ex::XVar(n) = r {
            break 'm17753 get(&cp.pointers, n);
        }
        if let crate::lower::model::Ex::XClone(y) = r {
            break 'm17753 pointer(cp, &**y);
        }
        if let crate::lower::model::Ex::XRef(y) = r {
            break 'm17753 pointer(cp, &**y);
        }
        if let crate::lower::model::Ex::XDeref(y) = r {
            break 'm17753 match ex_ty(cp, r) {
                Some(t) => Some(is_pointer_ty(cp, &unref(&t))),
                None => None,
            };
        }
        if let crate::lower::model::Ex::XField(m17753_10_0, f) = r && let crate::lower::model::Ex::XSelf = &**m17753_10_0 {
            break 'm17753 match get(&cp.fields, f) {
                Some(t) => Some(is_pointer_ty(cp, &t)),
                None => None,
            };
        }
        if let crate::lower::model::Ex::XField(m17753_11_0, f) = r && let crate::lower::model::Ex::XVar(m17753_11_0_r_0) = &**m17753_11_0 && (m17753_11_0_r_0 == &Text::lit("node")) {
            break 'm17753 match get(&cp.fields, f) {
                Some(t) => Some(is_pointer_ty(cp, &t)),
                None => None,
            };
        }
        None
    }
}

/// ```prism
/// IsPointerTy: fn Cp, OutTy -> Bool
/// ```
pub fn is_pointer_ty(cp: &crate::emit::cpp::Cp, t: &crate::lower::model::OutTy) -> bool {
    match t {
        crate::lower::model::OutTy::OutNamed(m18597_0_0, _) if (m18597_0_0 == &Text::lit("prism_rtl::Rows")) => true,
        crate::lower::model::OutTy::OutPort(_) => false,
        crate::lower::model::OutTy::OutRc(_) => true,
        crate::lower::model::OutTy::OutObj(_) => true,
        crate::lower::model::OutTy::OutJob(_) => true,
        crate::lower::model::OutTy::OutShowAny => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// MethodForm: fn Text, Nat -> Text
/// ```
pub fn method_form(m: &Text, n: &Nat) -> Text {
    match (m.clone(), n.clone()) {
        (m19124_0_0, m19124_0_1) if (&m19124_0_0 == &Text::lit("borrow")) && (&m19124_0_1 == &Nat::from(0u32)) => Text::lit("deref"),
        (m19124_1_0, m19124_1_1) if (&m19124_1_0 == &Text::lit("borrow_mut")) && (&m19124_1_1 == &Nat::from(0u32)) => Text::lit("deref"),
        (m19124_2_0, m19124_2_1) if (&m19124_2_0 == &Text::lit("clone")) && (&m19124_2_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m19124_3_0, m19124_3_1) if (&m19124_3_0 == &Text::lit("iter")) && (&m19124_3_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m19124_4_0, m19124_4_1) if (&m19124_4_0 == &Text::lit("collect")) && (&m19124_4_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m19124_5_0, m19124_5_1) if (&m19124_5_0 == &Text::lit("unwrap_or_default")) && (&m19124_5_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19124_6_0, m19124_6_1) if (&m19124_6_0 == &Text::lit("for_each")) && (&m19124_6_1 == &Nat::from(1u32)) => Text::lit("free"),
        (m19124_7_0, m19124_7_1) if (&m19124_7_0 == &Text::lit("into_iter")) && (&m19124_7_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m19124_8_0, m19124_8_1) if (&m19124_8_0 == &Text::lit("as_ref")) && (&m19124_8_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m19124_9_0, m19124_9_1) if (&m19124_9_0 == &Text::lit("get")) && (&m19124_9_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m19124_10_0, m19124_10_1) if (&m19124_10_0 == &Text::lit("set")) && (&m19124_10_1 == &Nat::from(1u32)) => Text::lit("assign"),
        (m19124_11_0, m19124_11_1) if (&m19124_11_0 == &Text::lit("take")) && (&m19124_11_1 == &Nat::from(0u32)) => Text::lit("take"),
        (m19124_12_0, m19124_12_1) if (&m19124_12_0 == &Text::lit("replace")) && (&m19124_12_1 == &Nat::from(1u32)) => Text::lit("exchange"),
        (m19124_13_0, m19124_13_1) if (&m19124_13_0 == &Text::lit("values")) && (&m19124_13_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19124_14_0, m19124_14_1) if (&m19124_14_0 == &Text::lit("keys")) && (&m19124_14_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19124_15_0, m19124_15_1) if (&m19124_15_0 == &Text::lit("enumerate")) && (&m19124_15_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19124_16_0, m19124_16_1) if (&m19124_16_0 == &Text::lit("fire")) && (&m19124_16_1 == &Nat::from(2u32)) => Text::lit("arrow"),
        (m19124_17_0, m19124_17_1) if (&m19124_17_0 == &Text::lit("subscribe")) && (&m19124_17_1 == &Nat::from(1u32)) => Text::lit("arrow"),
        (m19124_18_0, m19124_18_1) if (&m19124_18_0 == &Text::lit("unsubscribe")) && (&m19124_18_1 == &Nat::from(1u32)) => Text::lit("arrow"),
        (m19124_19_0, m19124_19_1) if (&m19124_19_0 == &Text::lit("cycle")) && (&m19124_19_1 == &Nat::from(0u32)) => Text::lit("arrow"),
        (m19124_20_0, m19124_20_1) if (&m19124_20_0 == &Text::lit("upgrade")) && (&m19124_20_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19124_21_0, m19124_21_1) if (&m19124_21_0 == &Text::lit("expect")) && (&m19124_21_1 == &Nat::from(1u32)) => Text::lit("free"),
        (m19124_22_0, m19124_22_1) if (&m19124_22_0 == &Text::lit("to_pod")) && (&m19124_22_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19124_23_0, m19124_23_1) if (&m19124_23_0 == &Text::lit("cloned")) && (&m19124_23_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19124_24_0, m19124_24_1) if (&m19124_24_0 == &Text::lit("ok")) && (&m19124_24_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19124_25_0, m19124_25_1) if (&m19124_25_0 == &Text::lit("ok_or")) && (&m19124_25_1 == &Nat::from(1u32)) => Text::lit("free"),
        (m19124_26_0, m19124_26_1) if (&m19124_26_0 == &Text::lit("map")) && (&m19124_26_1 == &Nat::from(1u32)) => Text::lit("free"),
        (m19124_27_0, m19124_27_1) if (&m19124_27_0 == &Text::lit("iter_mut")) && (&m19124_27_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19124_28_0, m19124_28_1) if (&m19124_28_0 == &Text::lit("to_vec")) && (&m19124_28_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19124_29_0, m19124_29_1) if (&m19124_29_0 == &Text::lit("filter_some")) && (&m19124_29_1 == &Nat::from(0u32)) => Text::lit("free"),
        _ => Text::lit("dot"),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// FreeName: fn Text -> Text
/// ```
pub fn free_name(m: &Text) -> Text {
    match m {
        m20061_0 if (m20061_0 == &Text::lit("to_pod")) => Text::lit("prism_rtl::to_pod"),
        m20061_1 if (m20061_1 == &Text::lit("ok")) => Text::lit("prism_rtl::ignore"),
        m20061_2 if (m20061_2 == &Text::lit("map")) => Text::lit("prism_rtl::fmap"),
        m20061_3 if (m20061_3 == &Text::lit("to_vec")) => Text::lit("path_of"),
        m20061_4 if (m20061_4 == &Text::lit("values")) => Text::lit("crate::prelude::values"),
        m20061_5 if (m20061_5 == &Text::lit("keys")) => Text::lit("crate::prelude::keys"),
        m20061_6 if (m20061_6 == &Text::lit("enumerate")) => Text::lit("prism_rtl::enumerate"),
        m20061_7 if (m20061_7 == &Text::lit("unwrap_or_default")) => Text::lit("prism_rtl::unwrap_or_default"),
        m20061_8 if (m20061_8 == &Text::lit("for_each")) => Text::lit("prism_rtl::for_each"),
        _ => m.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// MemberName: fn Text -> Text
/// ```
pub fn member_name(m: &Text) -> Text {
    match m {
        m20459_0 if (m20459_0 == &Text::lit("push_str")) => Text::lit("append"),
        m20459_1 if (m20459_1 == &Text::lit("len")) => Text::lit("size"),
        m20459_2 if (m20459_2 == &Text::lit("is_empty")) => Text::lit("empty"),
        m20459_3 if (m20459_3 == &Text::lit("push")) => Text::lit("push_back"),
        m20459_4 if (m20459_4 == &Text::lit("contains_key")) => Text::lit("contains"),
        m20459_5 if (m20459_5 == &Text::lit("build")) => Text::lit("make"),
        _ => crate::emit::cpp::cpp_id(m),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CaseTest: fn Cp, Text, Text -> Text
/// ```
pub fn case_test(cp: &crate::emit::cpp::Cp, c: &Text, v_: &Text) -> Text {
    match c {
        m20758_0 if (m20758_0 == &Text::lit("Some")) => Text::from(format!("prism_rtl::is_some({})", v_)),
        m20758_1 if (m20758_1 == &Text::lit("None")) => Text::from(format!("prism_rtl::is_none({})", v_)),
        m20758_2 if (m20758_2 == &Text::lit("Ok")) => Text::from(format!("prism_rtl::is_ok({})", v_)),
        m20758_3 if (m20758_3 == &Text::lit("Err")) => Text::from(format!("prism_rtl::is_err({})", v_)),
        m20758_4 if (m20758_4 == &Text::lit("prism_rtl::Turn::More")) => Text::from(format!("{}.if_more()", v_)),
        m20758_5 if (m20758_5 == &Text::lit("prism_rtl::Turn::Finished")) => Text::from(format!("{}.if_finished()", v_)),
        _ => match crate::emit::cpp::case_of(cp, c) {
            Some(_) => Text::from(format!("prism_rtl::is<{}>({})", &case_type(c), v_)),
            None => if is_runtime_case(c) {
                Text::from(format!("prism_rtl::is<{}>({})", &case_type(c), v_))
            } else {
                Text::lit("true")
            },
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CaseType: fn Text -> Text
/// ```
pub fn case_type(c: &Text) -> Text {
    match c {
        m21310_0 if (m21310_0 == &Text::lit("Segment::Pos")) => Text::lit("pat::Pos"),
        m21310_1 if (m21310_1 == &Text::lit("Segment::Gen")) => Text::lit("pat::Gen"),
        m21310_2 if (m21310_2 == &Text::lit("Segment::Key")) => Text::lit("pat::Key"),
        _ => crate::emit::cpp::type_path(c),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Payload: fn Cp, Text, Text, Nat -> Text
/// ```
pub fn payload(cp: &crate::emit::cpp::Cp, c: &Text, v_: &Text, i: &Nat) -> Text {
    match c {
        m21559_0 if (m21559_0 == &Text::lit("Some")) => Text::from(format!("prism_rtl::some_of({})", v_)),
        m21559_1 if (m21559_1 == &Text::lit("Ok")) => Text::from(format!("*{}", v_)),
        m21559_2 if (m21559_2 == &Text::lit("Err")) => Text::from(format!("{}.error()", v_)),
        m21559_3 if (m21559_3 == &Text::lit("prism_rtl::Turn::More")) => Text::from(format!("{}.if_more()->next", v_)),
        m21559_4 if (m21559_4 == &Text::lit("prism_rtl::Turn::Finished")) => Text::from(format!("{}.if_finished()->value", v_)),
        _ => match crate::emit::cpp::case_of(cp, c) {
            Some(_) => Text::from(format!("prism_rtl::as<{}>({}).a{}", &case_type(c), v_, i)),
            None => if is_runtime_case(c) {
                Text::from(format!("prism_rtl::as<{}>({}).a{}", &case_type(c), v_, i))
            } else {
                Text::from(format!("{}.a{}", v_, i))
            },
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IsRuntimeCase: fn Text -> Bool
/// ```
pub fn is_runtime_case(c: &Text) -> bool {
    crate::syntax::lexer::chars::has_prefix(c, &Text::lit("Segment::"))
}

/// ```prism
/// CppIf: unbounded fn Cp, Ex, Ex, Ex -> Text
/// ```
pub fn cpp_if(cp: &crate::emit::cpp::Cp, c: &crate::lower::model::Ex, t: &crate::lower::model::Ex, e: &crate::lower::model::Ex) -> Text {
    let ct = cpp_expr(cp, c);
    let err_opt = match (err_of(t), err_of(e)) {
        (Some(y), _) => Some(y),
        (None, Some(y)) => Some(y),
        _ => None,
    };
    let tt = match &err_opt {
        Some(y) => ok_branch(cp, t, y),
        None => cpp_expr(cp, t),
    };
    let et = match &err_opt {
        Some(y) => ok_branch(cp, e, y),
        None => cpp_expr(cp, e),
    };
    let short = !crate::syntax::lexer::chars::contains(&Text::from(format!("{}{}", &tt, &et)), &Text::lit("\n")) && (&len_text(&Text::from(format!("{}{}{}", &ct, &tt, &et))) < &Nat::from(70u32));
    if short {
        Text::from(format!("{} ? {} : {}", &ct, &tt, &et))
    } else {
        crate::emit::cpp::templates::items::cond_expr(&ct, &tt, &et)
    }
}

/// The step machine of `CppIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppIf: unbounded fn Cp, Ex, Ex, Ex -> Text
/// ```
pub struct CppIf {
    pub cp: crate::emit::cpp::Cp,
    pub c: crate::lower::model::Ex,
    pub t: crate::lower::model::Ex,
    pub e: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppIf {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let c = &self.c;
        let t = &self.t;
        let e = &self.e;
        let c = c.clone();
        let cp = cp.clone();
        let e = e.clone();
        let t = t.clone();
        call_then(start_cpp_expr(cp.clone(), c.clone()), move |cpp_expr_22136: Text| {
            let ct = cpp_expr_22136;
            let err_opt = match (err_of(&t), err_of(&e)) {
                (Some(y), _) => Some(y),
                (None, Some(y)) => Some(y),
                _ => None,
            };
            let tt = match &err_opt {
                Some(y) => ok_branch(&cp, &t, y),
                None => cpp_expr(&cp, &t),
            };
            let et = match &err_opt {
                Some(y) => ok_branch(&cp, &e, y),
                None => cpp_expr(&cp, &e),
            };
            let short = !crate::syntax::lexer::chars::contains(&Text::from(format!("{}{}", &tt, &et)), &Text::lit("\n")) && (&len_text(&Text::from(format!("{}{}{}", &ct, &tt, &et))) < &Nat::from(70u32));
            if short {
                prism_rtl::Turn::Finished(Text::from(format!("{} ? {} : {}", &ct, &tt, &et)))
            } else {
                prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cond_expr(&ct, &tt, &et))
            }
        })
    }
}

/// `Start CppIf, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_if(cp: crate::emit::cpp::Cp, c: crate::lower::model::Ex, t: crate::lower::model::Ex, e: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppIf { cp, c, t, e })
}

/// ```prism
/// WithMoveCaptures: unbounded fn Cp, [Do], Ex -> Cp
/// ```
pub fn with_move_captures(cp: &crate::emit::cpp::Cp, dos: &Array<crate::lower::model::Do>, e: &crate::lower::model::Ex) -> crate::emit::cpp::Cp {
    let lets = fold(dos, &Array::new(), &(|acc: &Array<Text>, d: &crate::lower::model::Do| match d {
        crate::lower::model::Do::DoLet(p_, _) => match crate::emit::cpp::stmts::let_name(p_) {
            Some(n) => if crate::emit::cpp::in_list(acc, &n) { acc.clone() } else { push(acc, &n) },
            None => acc.clone(),
        },
        _ => acc.clone(),
    }));
    if &len(&lets) == &Nat::from(0u32) {
        {
            let mut this: crate::emit::cpp::Cp = cp.clone();
            this.move_captures = Array::new();
            this
        }
    } else {
        {
            let (reads, has_move) = reads_of(e, &false, &(Array::new(), false));
            {
                let mut this: crate::emit::cpp::Cp = cp.clone();
                this.move_captures = if has_move {
                    filter(&lets, &(|n: &Text| !crate::emit::cpp::in_list(&reads, n)))
                } else {
                    Array::new()
                };
                this
            }
        }
    }
}

/// The step machine of `WithMoveCaptures`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WithMoveCaptures: unbounded fn Cp, [Do], Ex -> Cp
/// ```
pub struct WithMoveCaptures {
    pub cp: crate::emit::cpp::Cp,
    pub dos: Array<crate::lower::model::Do>,
    pub e: crate::lower::model::Ex,
}

impl prism_rtl::Job<crate::emit::cpp::Cp> for WithMoveCaptures {
    fn cycle(&self) -> prism_rtl::Turn<crate::emit::cpp::Cp> {
        let cp = &self.cp;
        let dos = &self.dos;
        let e = &self.e;
        let lets = fold(dos, &Array::new(), &(|acc: &Array<Text>, d: &crate::lower::model::Do| match d {
            crate::lower::model::Do::DoLet(p_, _) => match crate::emit::cpp::stmts::let_name(p_) {
                Some(n) => if crate::emit::cpp::in_list(acc, &n) { acc.clone() } else { push(acc, &n) },
                None => acc.clone(),
            },
            _ => acc.clone(),
        }));
        if &len(&lets) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished({
                let mut this: crate::emit::cpp::Cp = cp.clone();
                this.move_captures = Array::new();
                this
            })
        } else {
            {
                let cp = cp.clone();
                let e = e.clone();
                call_then(start_reads_of(e.clone(), false, (Array::new(), false)), move |reads_of_23385: (Array<Text>, bool)| {
                    let (reads, has_move) = reads_of_23385;
                    prism_rtl::Turn::Finished({
                        let mut this: crate::emit::cpp::Cp = cp.clone();
                        this.move_captures = if has_move {
                            filter(&lets, &(|n: &Text| !crate::emit::cpp::in_list(&reads, n)))
                        } else {
                            Array::new()
                        };
                        this
                    })
                })
            }
        }
    }
}

/// `Start WithMoveCaptures, x`: what the function value is when passed to `@Run`.
pub fn start_with_move_captures(cp: crate::emit::cpp::Cp, dos: Array<crate::lower::model::Do>, e: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<crate::emit::cpp::Cp>> {
    Rc::new(WithMoveCaptures { cp, dos, e })
}

/// ```prism
/// ReadsOf: unbounded fn Ex, Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub fn reads_of(x: &crate::lower::model::Ex, into: &bool, acc: &(Array<Text>, bool)) -> (Array<Text>, bool) {
    let (reads, has_move) = acc.clone();
    match x {
        crate::lower::model::Ex::XVar(n) => (push(&reads, n), has_move),
        crate::lower::model::Ex::XClosure(true, ps, body) => if *into {
            reads_of(&**body, into, &(reads.clone(), true))
        } else {
            (reads.clone(), true)
        },
        crate::lower::model::Ex::XClosure(false, ps, body) => reads_of(&**body, into, acc),
        crate::lower::model::Ex::XRef(y) => reads_of(&**y, into, acc),
        crate::lower::model::Ex::XRefMut(y) => reads_of(&**y, into, acc),
        crate::lower::model::Ex::XDeref(y) => reads_of(&**y, into, acc),
        crate::lower::model::Ex::XTarget(y) => reads_of(&**y, into, acc),
        crate::lower::model::Ex::XClone(y) => reads_of(&**y, into, acc),
        crate::lower::model::Ex::XWeak(y) => reads_of(&**y, into, acc),
        crate::lower::model::Ex::XUpgrade(y) => reads_of(&**y, into, acc),
        crate::lower::model::Ex::XBreak(_, y) => reads_of(&**y, into, acc),
        crate::lower::model::Ex::XLater(y) => reads_of(&**y, into, acc),
        crate::lower::model::Ex::XFormatStr(xs) => reads_each(xs, into, acc),
        crate::lower::model::Ex::XIsCase(y, _) => reads_of(&**y, into, acc),
        crate::lower::model::Ex::XCall(_, xs) => reads_each(xs, into, acc),
        crate::lower::model::Ex::XApply(f, xs) => reads_each(&append(&Array::from(vec![(**f).clone()]), xs), into, acc),
        crate::lower::model::Ex::XMethod(r, _, xs) => reads_each(&append(&Array::from(vec![(**r).clone()]), xs), into, acc),
        crate::lower::model::Ex::XBin(_, l, r) => reads_each(&Array::from(vec![(**l).clone(), (**r).clone()]), into, acc),
        crate::lower::model::Ex::XUnary(_, y) => reads_of(&**y, into, acc),
        crate::lower::model::Ex::XCtor(_, xs) => reads_each(xs, into, acc),
        crate::lower::model::Ex::XRecord(_, fs) => reads_each(&each(fs, &(|(_, v_): &(Text, crate::lower::model::Ex)| v_.clone())), into, acc),
        crate::lower::model::Ex::XTuple(xs) => reads_each(xs, into, acc),
        crate::lower::model::Ex::XVec(xs) => reads_each(xs, into, acc),
        crate::lower::model::Ex::XFormat(xs) => reads_each(xs, into, acc),
        crate::lower::model::Ex::XMatch(s, arms, _, _) => reads_arms(arms, into, &reads_of(&**s, into, acc)),
        crate::lower::model::Ex::XChain(_, s, arms, _) => reads_arms(arms, into, &reads_of(&**s, into, acc)),
        crate::lower::model::Ex::XIf(c, t, e) => reads_each(&Array::from(vec![(**c).clone(), (**t).clone(), (**e).clone()]), into, acc),
        crate::lower::model::Ex::XBlock(dos, e) => reads_of(&**e, into, &reads_dos(dos, into, acc)),
        crate::lower::model::Ex::XLabeled(_, dos, e, _) => reads_of(&**e, into, &reads_dos(dos, into, acc)),
        crate::lower::model::Ex::XTry(y) => reads_of(&**y, into, acc),
        crate::lower::model::Ex::XField(r, _) => reads_of(&**r, into, acc),
        crate::lower::model::Ex::XPart(r, _) => reads_of(&**r, into, acc),
        crate::lower::model::Ex::XDecode(_, y) => reads_of(&**y, into, acc),
        crate::lower::model::Ex::XCast(y, _) => reads_of(&**y, into, acc),
        crate::lower::model::Ex::XTyped(y, _) => reads_of(&**y, into, acc),
        _ => acc.clone(),
    }
}

/// The step machine of `ReadsOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadsOf: unbounded fn Ex, Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub struct ReadsOf {
    pub x: crate::lower::model::Ex,
    pub into: bool,
    pub acc: (Array<Text>, bool),
}

impl prism_rtl::Job<(Array<Text>, bool)> for ReadsOf {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Text>, bool)> {
        let x = &self.x;
        let into = &self.into;
        let acc = &self.acc;
        let (reads, has_move) = acc.clone();
        match x {
            crate::lower::model::Ex::XVar(n) => prism_rtl::Turn::Finished((push(&reads, n), has_move)),
            crate::lower::model::Ex::XClosure(true, ps, body) => if *into {
                prism_rtl::Turn::More(Rc::new(ReadsOf { x: (**body).clone(), into: *into, acc: (reads.clone(), true) }))
            } else {
                prism_rtl::Turn::Finished((reads.clone(), true))
            },
            crate::lower::model::Ex::XClosure(false, ps, body) => prism_rtl::Turn::More(Rc::new(ReadsOf { x: (**body).clone(), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XRef(y) => prism_rtl::Turn::More(Rc::new(ReadsOf { x: (**y).clone(), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XRefMut(y) => prism_rtl::Turn::More(Rc::new(ReadsOf { x: (**y).clone(), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XDeref(y) => prism_rtl::Turn::More(Rc::new(ReadsOf { x: (**y).clone(), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XTarget(y) => prism_rtl::Turn::More(Rc::new(ReadsOf { x: (**y).clone(), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XClone(y) => prism_rtl::Turn::More(Rc::new(ReadsOf { x: (**y).clone(), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XWeak(y) => prism_rtl::Turn::More(Rc::new(ReadsOf { x: (**y).clone(), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XUpgrade(y) => prism_rtl::Turn::More(Rc::new(ReadsOf { x: (**y).clone(), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XBreak(_, y) => prism_rtl::Turn::More(Rc::new(ReadsOf { x: (**y).clone(), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XLater(y) => prism_rtl::Turn::More(Rc::new(ReadsOf { x: (**y).clone(), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XFormatStr(xs) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs: xs.clone(), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XIsCase(y, _) => prism_rtl::Turn::More(Rc::new(ReadsOf { x: (**y).clone(), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XCall(_, xs) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs: xs.clone(), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XApply(f, xs) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs: append(&Array::from(vec![(**f).clone()]), xs), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XMethod(r, _, xs) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs: append(&Array::from(vec![(**r).clone()]), xs), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XBin(_, l, r) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs: Array::from(vec![(**l).clone(), (**r).clone()]), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XUnary(_, y) => prism_rtl::Turn::More(Rc::new(ReadsOf { x: (**y).clone(), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XCtor(_, xs) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs: xs.clone(), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XRecord(_, fs) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs: each(fs, &(|(_, v_): &(Text, crate::lower::model::Ex)| v_.clone())), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XTuple(xs) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs: xs.clone(), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XVec(xs) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs: xs.clone(), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XFormat(xs) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs: xs.clone(), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XMatch(s, arms, _, _) => {
                let acc = acc.clone();
                let arms = arms.clone();
                let into = *into;
                let s = (**s).clone();
                call_then(start_reads_of(s.clone(), into, acc.clone()), move |reads_of_25087: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsArms { arms: arms.clone(), into, acc: reads_of_25087 })))
            },
            crate::lower::model::Ex::XChain(_, s, arms, _) => {
                let acc = acc.clone();
                let arms = arms.clone();
                let into = *into;
                let s = (**s).clone();
                call_then(start_reads_of(s.clone(), into, acc.clone()), move |reads_of_25172: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsArms { arms: arms.clone(), into, acc: reads_of_25172 })))
            },
            crate::lower::model::Ex::XIf(c, t, e) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs: Array::from(vec![(**c).clone(), (**t).clone(), (**e).clone()]), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XBlock(dos, e) => {
                let acc = acc.clone();
                let dos = dos.clone();
                let e = (**e).clone();
                let into = *into;
                call_then(start_reads_dos(dos.clone(), into, acc.clone()), move |reads_dos_25289: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsOf { x: e.clone(), into, acc: reads_dos_25289 })))
            },
            crate::lower::model::Ex::XLabeled(_, dos, e, _) => {
                let acc = acc.clone();
                let dos = dos.clone();
                let e = (**e).clone();
                let into = *into;
                call_then(start_reads_dos(dos.clone(), into, acc.clone()), move |reads_dos_25373: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsOf { x: e.clone(), into, acc: reads_dos_25373 })))
            },
            crate::lower::model::Ex::XTry(y) => prism_rtl::Turn::More(Rc::new(ReadsOf { x: (**y).clone(), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XField(r, _) => prism_rtl::Turn::More(Rc::new(ReadsOf { x: (**r).clone(), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XPart(r, _) => prism_rtl::Turn::More(Rc::new(ReadsOf { x: (**r).clone(), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XDecode(_, y) => prism_rtl::Turn::More(Rc::new(ReadsOf { x: (**y).clone(), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XCast(y, _) => prism_rtl::Turn::More(Rc::new(ReadsOf { x: (**y).clone(), into: *into, acc: acc.clone() })),
            crate::lower::model::Ex::XTyped(y, _) => prism_rtl::Turn::More(Rc::new(ReadsOf { x: (**y).clone(), into: *into, acc: acc.clone() })),
            _ => prism_rtl::Turn::Finished(acc.clone()),
        }
    }
}

/// `Start ReadsOf, x`: what the function value is when passed to `@Run`.
pub fn start_reads_of(x: crate::lower::model::Ex, into: bool, acc: (Array<Text>, bool)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>> {
    Rc::new(ReadsOf { x, into, acc })
}

/// ```prism
/// ReadsEach: unbounded fn [Ex], Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub fn reads_each(xs: &Array<crate::lower::model::Ex>, into: &bool, acc: &(Array<Text>, bool)) -> (Array<Text>, bool) {
    run_to_end(fold_job(xs.clone(), acc.clone(), {
        let into = *into;
        Rc::new(move |(p0, p1): ((Array<Text>, bool), crate::lower::model::Ex)| {
            let into = into;
            entered(once_job(move || {
                let a = p0;
                let x = p1;
                prism_rtl::Turn::More(Rc::new(ReadsOf { x: x.clone(), into, acc: a.clone() }))
            }))
        }) as Rc<dyn Fn(((Array<Text>, bool), crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
    }))
}

/// The step machine of `ReadsEach`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadsEach: unbounded fn [Ex], Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub struct ReadsEach {
    pub xs: Array<crate::lower::model::Ex>,
    pub into: bool,
    pub acc: (Array<Text>, bool),
}

impl prism_rtl::Job<(Array<Text>, bool)> for ReadsEach {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Text>, bool)> {
        let xs = &self.xs;
        let into = &self.into;
        let acc = &self.acc;
        fold_job(xs.clone(), acc.clone(), {
            let into = *into;
            Rc::new(move |(p0, p1): ((Array<Text>, bool), crate::lower::model::Ex)| {
                let into = into;
                entered(once_job(move || {
                    let a = p0;
                    let x = p1;
                    prism_rtl::Turn::More(Rc::new(ReadsOf { x: x.clone(), into, acc: a.clone() }))
                }))
            }) as Rc<dyn Fn(((Array<Text>, bool), crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
        }).cycle()
    }
}

/// `Start ReadsEach, x`: what the function value is when passed to `@Run`.
pub fn start_reads_each(xs: Array<crate::lower::model::Ex>, into: bool, acc: (Array<Text>, bool)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>> {
    Rc::new(ReadsEach { xs, into, acc })
}

/// ```prism
/// ReadsArms: unbounded fn [XArm], Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub fn reads_arms(arms: &Array<crate::lower::model::XArm>, into: &bool, acc: &(Array<Text>, bool)) -> (Array<Text>, bool) {
    run_to_end(fold_job(arms.clone(), acc.clone(), {
        let into = *into;
        Rc::new(move |(p0, p1): ((Array<Text>, bool), crate::lower::model::XArm)| {
            let into = into;
            entered(once_job(move || {
                let a = p0;
                let arm = p1;
                call_value(fold_job(arm.conds.clone(), a.clone(), {
                    let into = into;
                    Rc::new(move |(p0, p1): ((Array<Text>, bool), crate::lower::model::Cc)| {
                        let into = into;
                        entered(once_job(move || {
                            let a2 = p0;
                            let c = p1;
                            prism_rtl::Turn::More(Rc::new(ReadsCond { cc0: c.clone(), into, acc: a2.clone() }))
                        }))
                    }) as Rc<dyn Fn(((Array<Text>, bool), crate::lower::model::Cc)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
                }), move |fold_25994: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsOf { x: arm.body.clone(), into, acc: fold_25994 })))
            }))
        }) as Rc<dyn Fn(((Array<Text>, bool), crate::lower::model::XArm)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
    }))
}

/// The step machine of `ReadsArms`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadsArms: unbounded fn [XArm], Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub struct ReadsArms {
    pub arms: Array<crate::lower::model::XArm>,
    pub into: bool,
    pub acc: (Array<Text>, bool),
}

impl prism_rtl::Job<(Array<Text>, bool)> for ReadsArms {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Text>, bool)> {
        let arms = &self.arms;
        let into = &self.into;
        let acc = &self.acc;
        fold_job(arms.clone(), acc.clone(), {
            let into = *into;
            Rc::new(move |(p0, p1): ((Array<Text>, bool), crate::lower::model::XArm)| {
                let into = into;
                entered(once_job(move || {
                    let a = p0;
                    let arm = p1;
                    call_value(fold_job(arm.conds.clone(), a.clone(), {
                        let into = into;
                        Rc::new(move |(p0, p1): ((Array<Text>, bool), crate::lower::model::Cc)| {
                            let into = into;
                            entered(once_job(move || {
                                let a2 = p0;
                                let c = p1;
                                prism_rtl::Turn::More(Rc::new(ReadsCond { cc0: c.clone(), into, acc: a2.clone() }))
                            }))
                        }) as Rc<dyn Fn(((Array<Text>, bool), crate::lower::model::Cc)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
                    }), move |fold_25994: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsOf { x: arm.body.clone(), into, acc: fold_25994 })))
                }))
            }) as Rc<dyn Fn(((Array<Text>, bool), crate::lower::model::XArm)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
        }).cycle()
    }
}

/// `Start ReadsArms, x`: what the function value is when passed to `@Run`.
pub fn start_reads_arms(arms: Array<crate::lower::model::XArm>, into: bool, acc: (Array<Text>, bool)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>> {
    Rc::new(ReadsArms { arms, into, acc })
}

/// ```prism
/// ReadsCond: unbounded fn Cc, Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub fn reads_cond(cc0: &crate::lower::model::Cc, into: &bool, acc: &(Array<Text>, bool)) -> (Array<Text>, bool) {
    match cc0 {
        crate::lower::model::Cc::CcLet(_, x) => reads_of(x, into, acc),
        crate::lower::model::Cc::CcIf(x) => reads_of(x, into, acc),
    }
}

/// The step machine of `ReadsCond`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadsCond: unbounded fn Cc, Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub struct ReadsCond {
    pub cc0: crate::lower::model::Cc,
    pub into: bool,
    pub acc: (Array<Text>, bool),
}

impl prism_rtl::Job<(Array<Text>, bool)> for ReadsCond {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Text>, bool)> {
        let cc0 = &self.cc0;
        let into = &self.into;
        let acc = &self.acc;
        match cc0 {
            crate::lower::model::Cc::CcLet(_, x) => prism_rtl::Turn::More(Rc::new(ReadsOf { x: x.clone(), into: *into, acc: acc.clone() })),
            crate::lower::model::Cc::CcIf(x) => prism_rtl::Turn::More(Rc::new(ReadsOf { x: x.clone(), into: *into, acc: acc.clone() })),
        }
    }
}

/// `Start ReadsCond, x`: what the function value is when passed to `@Run`.
pub fn start_reads_cond(cc0: crate::lower::model::Cc, into: bool, acc: (Array<Text>, bool)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>> {
    Rc::new(ReadsCond { cc0, into, acc })
}

/// ```prism
/// ReadsDos: unbounded fn [Do], Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub fn reads_dos(dos: &Array<crate::lower::model::Do>, into: &bool, acc: &(Array<Text>, bool)) -> (Array<Text>, bool) {
    run_to_end(fold_job(dos.clone(), acc.clone(), {
        let into = *into;
        Rc::new(move |(p0, p1): ((Array<Text>, bool), crate::lower::model::Do)| {
            let into = into;
            entered(once_job(move || {
                let a = p0;
                let d = p1;
                match &d {
                    crate::lower::model::Do::DoLet(_, x) => prism_rtl::Turn::More(Rc::new(ReadsOf { x: x.clone(), into, acc: a.clone() })),
                    crate::lower::model::Do::DoLetElse(_, x, e) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs: Array::from(vec![x.clone(), e.clone()]), into, acc: a.clone() })),
                    crate::lower::model::Do::DoAssign(p_, x) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs: Array::from(vec![p_.clone(), x.clone()]), into, acc: a.clone() })),
                    crate::lower::model::Do::DoWhile(c, body) => {
                        let body = body.clone();
                        let c = c.clone();
                        call_then(start_reads_of(c.clone(), into, a.clone()), move |reads_of_26558: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos: body.clone(), into, acc: reads_of_26558 })))
                    },
                    crate::lower::model::Do::DoWhileLet(_, x, body) => {
                        let body = body.clone();
                        let x = x.clone();
                        call_then(start_reads_of(x.clone(), into, a.clone()), move |reads_of_26632: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos: body.clone(), into, acc: reads_of_26632 })))
                    },
                    crate::lower::model::Do::DoFor(_, x, body) => {
                        let body = body.clone();
                        let x = x.clone();
                        call_then(start_reads_of(x.clone(), into, a.clone()), move |reads_of_26701: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos: body.clone(), into, acc: reads_of_26701 })))
                    },
                    crate::lower::model::Do::DoExpr(x) => prism_rtl::Turn::More(Rc::new(ReadsOf { x: x.clone(), into, acc: a.clone() })),
                    crate::lower::model::Do::DoIf(c, t, e) => {
                        let c = c.clone();
                        let e = e.clone();
                        let t = t.clone();
                        call_then(start_reads_of(c.clone(), into, a.clone()), move |reads_of_26810: (Array<Text>, bool)| call_then(start_reads_dos(t.clone(), into, reads_of_26810), move |reads_dos_26791: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos: e.clone(), into, acc: reads_dos_26791 }))))
                    },
                    crate::lower::model::Do::DoIfLet(_, x, t, e) => {
                        let e = e.clone();
                        let t = t.clone();
                        let x = x.clone();
                        call_then(start_reads_of(x.clone(), into, a.clone()), move |reads_of_26898: (Array<Text>, bool)| call_then(start_reads_dos(t.clone(), into, reads_of_26898), move |reads_dos_26879: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos: e.clone(), into, acc: reads_dos_26879 }))))
                    },
                    crate::lower::model::Do::DoMatch(x, cases) => {
                        let cases = cases.clone();
                        let x = x.clone();
                        call_then(start_reads_of(x.clone(), into, a.clone()), move |reads_of_26954: (Array<Text>, bool)| fold_job(cases.clone(), reads_of_26954, {
                            let into = into;
                            Rc::new(move |(p0, p1): ((Array<Text>, bool), (crate::lower::model::Pa, Array<crate::lower::model::Do>))| {
                                let into = into;
                                entered(once_job(move || {
                                    let a2 = p0;
                                    let (_, body) = p1;
                                    prism_rtl::Turn::More(Rc::new(ReadsDos { dos: body.clone(), into, acc: a2.clone() }))
                                }))
                            }) as Rc<dyn Fn(((Array<Text>, bool), (crate::lower::model::Pa, Array<crate::lower::model::Do>))) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
                        }).cycle())
                    },
                    crate::lower::model::Do::DoReturn(x) => prism_rtl::Turn::More(Rc::new(ReadsOf { x: x.clone(), into, acc: a.clone() })),
                    crate::lower::model::Do::DoBlock(body) => prism_rtl::Turn::More(Rc::new(ReadsDos { dos: body.clone(), into, acc: a.clone() })),
                    crate::lower::model::Do::DoScope(body) => prism_rtl::Turn::More(Rc::new(ReadsDos { dos: body.clone(), into, acc: a.clone() })),
                    crate::lower::model::Do::DoLine(body) => prism_rtl::Turn::More(Rc::new(ReadsDos { dos: body.clone(), into, acc: a.clone() })),
                    crate::lower::model::Do::DoNote(_) => prism_rtl::Turn::Finished(a.clone()),
                }
            }))
        }) as Rc<dyn Fn(((Array<Text>, bool), crate::lower::model::Do)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
    }))
}

/// The step machine of `ReadsDos`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadsDos: unbounded fn [Do], Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub struct ReadsDos {
    pub dos: Array<crate::lower::model::Do>,
    pub into: bool,
    pub acc: (Array<Text>, bool),
}

impl prism_rtl::Job<(Array<Text>, bool)> for ReadsDos {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Text>, bool)> {
        let dos = &self.dos;
        let into = &self.into;
        let acc = &self.acc;
        fold_job(dos.clone(), acc.clone(), {
            let into = *into;
            Rc::new(move |(p0, p1): ((Array<Text>, bool), crate::lower::model::Do)| {
                let into = into;
                entered(once_job(move || {
                    let a = p0;
                    let d = p1;
                    match &d {
                        crate::lower::model::Do::DoLet(_, x) => prism_rtl::Turn::More(Rc::new(ReadsOf { x: x.clone(), into, acc: a.clone() })),
                        crate::lower::model::Do::DoLetElse(_, x, e) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs: Array::from(vec![x.clone(), e.clone()]), into, acc: a.clone() })),
                        crate::lower::model::Do::DoAssign(p_, x) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs: Array::from(vec![p_.clone(), x.clone()]), into, acc: a.clone() })),
                        crate::lower::model::Do::DoWhile(c, body) => {
                            let body = body.clone();
                            let c = c.clone();
                            call_then(start_reads_of(c.clone(), into, a.clone()), move |reads_of_26558: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos: body.clone(), into, acc: reads_of_26558 })))
                        },
                        crate::lower::model::Do::DoWhileLet(_, x, body) => {
                            let body = body.clone();
                            let x = x.clone();
                            call_then(start_reads_of(x.clone(), into, a.clone()), move |reads_of_26632: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos: body.clone(), into, acc: reads_of_26632 })))
                        },
                        crate::lower::model::Do::DoFor(_, x, body) => {
                            let body = body.clone();
                            let x = x.clone();
                            call_then(start_reads_of(x.clone(), into, a.clone()), move |reads_of_26701: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos: body.clone(), into, acc: reads_of_26701 })))
                        },
                        crate::lower::model::Do::DoExpr(x) => prism_rtl::Turn::More(Rc::new(ReadsOf { x: x.clone(), into, acc: a.clone() })),
                        crate::lower::model::Do::DoIf(c, t, e) => {
                            let c = c.clone();
                            let e = e.clone();
                            let t = t.clone();
                            call_then(start_reads_of(c.clone(), into, a.clone()), move |reads_of_26810: (Array<Text>, bool)| call_then(start_reads_dos(t.clone(), into, reads_of_26810), move |reads_dos_26791: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos: e.clone(), into, acc: reads_dos_26791 }))))
                        },
                        crate::lower::model::Do::DoIfLet(_, x, t, e) => {
                            let e = e.clone();
                            let t = t.clone();
                            let x = x.clone();
                            call_then(start_reads_of(x.clone(), into, a.clone()), move |reads_of_26898: (Array<Text>, bool)| call_then(start_reads_dos(t.clone(), into, reads_of_26898), move |reads_dos_26879: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos: e.clone(), into, acc: reads_dos_26879 }))))
                        },
                        crate::lower::model::Do::DoMatch(x, cases) => {
                            let cases = cases.clone();
                            let x = x.clone();
                            call_then(start_reads_of(x.clone(), into, a.clone()), move |reads_of_26954: (Array<Text>, bool)| fold_job(cases.clone(), reads_of_26954, {
                                let into = into;
                                Rc::new(move |(p0, p1): ((Array<Text>, bool), (crate::lower::model::Pa, Array<crate::lower::model::Do>))| {
                                    let into = into;
                                    entered(once_job(move || {
                                        let a2 = p0;
                                        let (_, body) = p1;
                                        prism_rtl::Turn::More(Rc::new(ReadsDos { dos: body.clone(), into, acc: a2.clone() }))
                                    }))
                                }) as Rc<dyn Fn(((Array<Text>, bool), (crate::lower::model::Pa, Array<crate::lower::model::Do>))) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
                            }).cycle())
                        },
                        crate::lower::model::Do::DoReturn(x) => prism_rtl::Turn::More(Rc::new(ReadsOf { x: x.clone(), into, acc: a.clone() })),
                        crate::lower::model::Do::DoBlock(body) => prism_rtl::Turn::More(Rc::new(ReadsDos { dos: body.clone(), into, acc: a.clone() })),
                        crate::lower::model::Do::DoScope(body) => prism_rtl::Turn::More(Rc::new(ReadsDos { dos: body.clone(), into, acc: a.clone() })),
                        crate::lower::model::Do::DoLine(body) => prism_rtl::Turn::More(Rc::new(ReadsDos { dos: body.clone(), into, acc: a.clone() })),
                        crate::lower::model::Do::DoNote(_) => prism_rtl::Turn::Finished(a.clone()),
                    }
                }))
            }) as Rc<dyn Fn(((Array<Text>, bool), crate::lower::model::Do)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
        }).cycle()
    }
}

/// `Start ReadsDos, x`: what the function value is when passed to `@Run`.
pub fn start_reads_dos(dos: Array<crate::lower::model::Do>, into: bool, acc: (Array<Text>, bool)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>> {
    Rc::new(ReadsDos { dos, into, acc })
}

/// ```prism
/// IsCtor: fn Ex, Text -> Bool
/// ```
pub fn is_ctor(ex0: &crate::lower::model::Ex, c: &Text) -> bool {
    match ex0 {
        crate::lower::model::Ex::XCtor(p_, _) => p_ == c,
        x => false,
    }
}

/// ```prism
/// ?ErrOf: fn Ex -> ?Ex
/// ```
pub fn err_of(x: &crate::lower::model::Ex) -> Option<crate::lower::model::Ex> {
    'm27398: {
        if let crate::lower::model::Ex::XCtor(m27398_0_0, m27398_0_1) = x && (m27398_0_0 == &Text::lit("Err")) && (m27398_0_1.len() == 1) && let Some(y) = index(m27398_0_1, &Nat::from(0u32)) {
            break 'm27398 Some(y.clone());
        }
        if let crate::lower::model::Ex::XBlock(_, tail) = x {
            break 'm27398 err_of(&**tail);
        }
        None
    }
}

/// ```prism
/// OkBranch: unbounded fn Cp, Ex, Ex -> Text
/// ```
pub fn ok_branch(cp: &crate::emit::cpp::Cp, x: &crate::lower::model::Ex, y: &crate::lower::model::Ex) -> Text {
    'm27701: {
        if let crate::lower::model::Ex::XCtor(m27701_0_0, m27701_0_1) = x && (m27701_0_0 == &Text::lit("Ok")) && (m27701_0_1.len() == 1) && let Some(v_) = index(m27701_0_1, &Nat::from(0u32)) {
            break 'm27701 Text::from(format!("Expected<std::decay_t<decltype({})>, std::decay_t<decltype({})>>({})", &cpp_expr(cp, &v_), &cpp_expr(cp, y), &cpp_expr(cp, &v_)));
        }
        if let crate::lower::model::Ex::XBlock(dos, m27701_1_1) = x && let crate::lower::model::Ex::XCtor(m27701_1_1_r_0, m27701_1_1_r_1) = &**m27701_1_1 && (m27701_1_1_r_0 == &Text::lit("Ok")) && (m27701_1_1_r_1.len() == 1) && let Some(v_) = index(m27701_1_1_r_1, &Nat::from(0u32)) {
            break 'm27701 {
                let (st, cp2) = crate::emit::cpp::stmts::cpp_statements_cp(cp, dos);
                crate::emit::cpp::templates::items::stmt_expr(&st, &Text::from(format!("Expected<std::decay_t<decltype({})>, std::decay_t<decltype({})>>({})", &cpp_expr(&cp2, &v_), &cpp_expr(&cp2, y), &cpp_expr(&cp2, &v_))))
            };
        }
        cpp_expr(cp, x)
    }
}

/// The step machine of `OkBranch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OkBranch: unbounded fn Cp, Ex, Ex -> Text
/// ```
pub struct OkBranch {
    pub cp: crate::emit::cpp::Cp,
    pub x: crate::lower::model::Ex,
    pub y: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for OkBranch {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let x = &self.x;
        let y = &self.y;
        'm27701: {
            if let crate::lower::model::Ex::XCtor(m27701_0_0, m27701_0_1) = x && (m27701_0_0 == &Text::lit("Ok")) && (m27701_0_1.len() == 1) && let Some(v_) = index(m27701_0_1, &Nat::from(0u32)) {
                break 'm27701 {
                    let cp = cp.clone();
                    let y = y.clone();
                    call_then(start_cpp_expr(cp.clone(), v_.clone()), move |cpp_expr_27766: Text| call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_27807: Text| call_then(start_cpp_expr(cp.clone(), v_.clone()), move |cpp_expr_27826: Text| prism_rtl::Turn::Finished(Text::from(format!("Expected<std::decay_t<decltype({})>, std::decay_t<decltype({})>>({})", &cpp_expr_27766, &cpp_expr_27807, &cpp_expr_27826))))))
                };
            }
            if let crate::lower::model::Ex::XBlock(dos, m27701_1_1) = x && let crate::lower::model::Ex::XCtor(m27701_1_1_r_0, m27701_1_1_r_1) = &**m27701_1_1 && (m27701_1_1_r_0 == &Text::lit("Ok")) && (m27701_1_1_r_1.len() == 1) && let Some(v_) = index(m27701_1_1_r_1, &Nat::from(0u32)) {
                break 'm27701 {
                    let cp = cp.clone();
                    let dos = dos.clone();
                    let y = y.clone();
                    call_then(crate::emit::cpp::stmts::start_cpp_statements_cp(cp.clone(), dos.clone()), move |cpp_statements_cp_27906: (Text, crate::emit::cpp::Cp)| {
                        let (st, cp2) = cpp_statements_cp_27906;
                        call_then(start_cpp_expr(cp2.clone(), v_.clone()), move |cpp_expr_27984: Text| call_then(start_cpp_expr(cp2.clone(), y.clone()), move |cpp_expr_28026: Text| call_then(start_cpp_expr(cp2.clone(), v_.clone()), move |cpp_expr_28046: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::stmt_expr(&st, &Text::from(format!("Expected<std::decay_t<decltype({})>, std::decay_t<decltype({})>>({})", &cpp_expr_27984, &cpp_expr_28026, &cpp_expr_28046)))))))
                    })
                };
            }
            prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: x.clone() }))
        }
    }
}

/// `Start OkBranch, x`: what the function value is when passed to `@Run`.
pub fn start_ok_branch(cp: crate::emit::cpp::Cp, x: crate::lower::model::Ex, y: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(OkBranch { cp, x, y })
}

/// ```prism
/// CppClosure: unbounded fn Cp, Bool, [Pa], Ex -> Text
/// ```
pub fn cpp_closure(cp0: &crate::emit::cpp::Cp, mv: &bool, ps: &Array<crate::lower::model::Pa>, body: &crate::lower::model::Ex) -> Text {
    let names = crate::emit::cpp::patterns::concat2(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
        let p_ = p0;
        prism_rtl::Turn::More(Rc::new(crate::emit::cpp::stmts::PatNames { p_: p_.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)));
    let cp = fold(ps, &crate::emit::cpp::stmts::unbind(&crate::emit::cpp::stmts::captured(cp0), &names), &(|c: &crate::emit::cpp::Cp, p_: &crate::lower::model::Pa| 'm28683: {
        if let crate::lower::model::Pa::PaMut(n) = p_ {
            break 'm28683 crate::emit::cpp::stmts::owning(c, n);
        }
        if let crate::lower::model::Pa::PaTyped(m28683_1_0, _) = p_ && let crate::lower::model::Pa::PaMut(n) = &**m28683_1_0 {
            break 'm28683 crate::emit::cpp::stmts::owning(c, n);
        }
        c.clone()
    }));
    let params = crate::syntax::lexer::chars::join(&run_to_end(each_job(crate::check::errors::range0(&len(ps)), {
        let cp = cp.clone();
        let ps = ps.clone();
        Rc::new(move |p0: Nat| {
            let cp = cp.clone();
            let ps = ps.clone();
            entered(once_job(move || {
                let i = p0;
                prism_rtl::Turn::More(Rc::new(ClosureParam { cp: cp.clone(), pa1: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), i: i.clone() }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "));
    let binds = concat(&run_to_end(each_job(crate::check::errors::range0(&len(ps)), {
        let cp = cp.clone();
        let ps = ps.clone();
        Rc::new(move |p0: Nat| {
            let cp = cp.clone();
            let ps = ps.clone();
            entered(once_job(move || {
                let i = p0;
                prism_rtl::Turn::More(Rc::new(ClosureBinds { cp: cp.clone(), pa1: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), i: i.clone() }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let b = cpp_expr(&cp, body);
    let moved = if *mv {
        filter(&cp0.move_captures, &(|n: &Text| (or(&get(&cp0.owned, n), &false) && !crate::emit::cpp::in_list(&names, n)) && crate::emit::cpp::stmts::cpp_mentions(&b, &crate::emit::cpp::stmts::var_name(cp0, n))))
    } else {
        Array::new()
    };
    let capture = crate::syntax::lexer::chars::join(&append(&Array::from(vec![if *mv { Text::lit("=") } else { Text::lit("&") }]), &each(&moved, &(|n: &Text| Text::from(format!("{} = std::move({})", &crate::emit::cpp::stmts::var_name(cp0, n), &crate::emit::cpp::stmts::var_name(cp0, n)))))), &Text::lit(", "));
    let (ret, value) = match body {
        crate::lower::model::Ex::XRef(_) => (Text::lit(" -> decltype(auto)"), Text::from(format!("({})", &b))),
        crate::lower::model::Ex::XRefMut(_) => (Text::lit(" -> decltype(auto)"), Text::from(format!("({})", &b))),
        _ => (Text::lit(""), b.clone()),
    };
    if (&binds == &Text::lit("")) && !crate::syntax::lexer::chars::contains(&b, &Text::lit("\n")) {
        Text::from(format!("[{}]({}){} {{ return {}; }}", &capture, &params, &ret, &value))
    } else {
        crate::emit::cpp::templates::items::lambda(&capture, &Text::from(format!("{}){}", &params, &ret)), &Text::from(format!("{}return {};", &binds, &value)))
    }
}

/// The step machine of `CppClosure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppClosure: unbounded fn Cp, Bool, [Pa], Ex -> Text
/// ```
pub struct CppClosure {
    pub cp0: crate::emit::cpp::Cp,
    pub mv: bool,
    pub ps: Array<crate::lower::model::Pa>,
    pub body: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppClosure {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp0 = &self.cp0;
        let mv = &self.mv;
        let ps = &self.ps;
        let body = &self.body;
        let body = body.clone();
        let cp0 = cp0.clone();
        let mv = *mv;
        let ps = ps.clone();
        call_value(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
            let p_ = p0;
            prism_rtl::Turn::More(Rc::new(crate::emit::cpp::stmts::PatNames { p_: p_.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_28595: Array<Array<Text>>| {
            let names = crate::emit::cpp::patterns::concat2(&each_28595);
            let cp = fold(&ps, &crate::emit::cpp::stmts::unbind(&crate::emit::cpp::stmts::captured(&cp0), &names), &(|c: &crate::emit::cpp::Cp, p_: &crate::lower::model::Pa| 'm28683: {
                if let crate::lower::model::Pa::PaMut(n) = p_ {
                    break 'm28683 crate::emit::cpp::stmts::owning(c, n);
                }
                if let crate::lower::model::Pa::PaTyped(m28683_1_0, _) = p_ && let crate::lower::model::Pa::PaMut(n) = &**m28683_1_0 {
                    break 'm28683 crate::emit::cpp::stmts::owning(c, n);
                }
                c.clone()
            }));
            call_value(each_job(crate::check::errors::range0(&len(&ps)), {
                let cp = cp.clone();
                let ps = ps.clone();
                Rc::new(move |p0: Nat| {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(ClosureParam { cp: cp.clone(), pa1: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), i: i.clone() }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_28812: Array<Text>| {
                let params = crate::syntax::lexer::chars::join(&each_28812, &Text::lit(", "));
                call_value(each_job(crate::check::errors::range0(&len(&ps)), {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    Rc::new(move |p0: Nat| {
                        let cp = cp.clone();
                        let ps = ps.clone();
                        entered(once_job(move || {
                            let i = p0;
                            prism_rtl::Turn::More(Rc::new(ClosureBinds { cp: cp.clone(), pa1: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), i: i.clone() }))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_28911: Array<Text>| {
                    let binds = concat(&each_28911);
                    call_then(start_cpp_expr(cp.clone(), body.clone()), move |cpp_expr_28992: Text| {
                        let b = cpp_expr_28992;
                        let moved = if mv {
                            filter(&cp0.move_captures, &(|n: &Text| (or(&get(&cp0.owned, n), &false) && !crate::emit::cpp::in_list(&names, n)) && crate::emit::cpp::stmts::cpp_mentions(&b, &crate::emit::cpp::stmts::var_name(&cp0, n))))
                        } else {
                            Array::new()
                        };
                        let capture = crate::syntax::lexer::chars::join(&append(&Array::from(vec![if mv { Text::lit("=") } else { Text::lit("&") }]), &each(&moved, &(|n: &Text| Text::from(format!("{} = std::move({})", &crate::emit::cpp::stmts::var_name(&cp0, n), &crate::emit::cpp::stmts::var_name(&cp0, n)))))), &Text::lit(", "));
                        let (ret, value) = match &body {
                            crate::lower::model::Ex::XRef(_) => (Text::lit(" -> decltype(auto)"), Text::from(format!("({})", &b))),
                            crate::lower::model::Ex::XRefMut(_) => (Text::lit(" -> decltype(auto)"), Text::from(format!("({})", &b))),
                            _ => (Text::lit(""), b.clone()),
                        };
                        if (&binds == &Text::lit("")) && !crate::syntax::lexer::chars::contains(&b, &Text::lit("\n")) {
                            prism_rtl::Turn::Finished(Text::from(format!("[{}]({}){} {{ return {}; }}", &capture, &params, &ret, &value)))
                        } else {
                            prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::lambda(&capture, &Text::from(format!("{}){}", &params, &ret)), &Text::from(format!("{}return {};", &binds, &value))))
                        }
                    })
                })
            })
        })
    }
}

/// `Start CppClosure, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_closure(cp0: crate::emit::cpp::Cp, mv: bool, ps: Array<crate::lower::model::Pa>, body: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppClosure { cp0, mv, ps, body })
}

/// ```prism
/// ClosureParam: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub fn closure_param(cp: &crate::emit::cpp::Cp, pa1: &crate::lower::model::Pa, i: &Nat) -> Text {
    'c: {
        if let crate::lower::model::Pa::PaTyped(c0_1_0, t) = pa1 && let crate::lower::model::Pa::PaBind(n) = &**c0_1_0 {
            break 'c Text::from(format!("{} {}", &param_type(cp, t), &crate::emit::cpp::cpp_id(n)));
        }
        if let crate::lower::model::Pa::PaTyped(c1_1_0, t) = pa1 && let crate::lower::model::Pa::PaMut(n) = &**c1_1_0 {
            break 'c Text::from(format!("{} {}", &crate::emit::cpp::cpp_type(cp, &unref(t)), &crate::emit::cpp::cpp_id(n)));
        }
        if let crate::lower::model::Pa::PaTyped(p_, t) = pa1 {
            break 'c Text::from(format!("{} _p{}", &param_type(cp, t), i));
        }
        if let crate::lower::model::Pa::PaBind(n) = pa1 {
            break 'c Text::from(format!("auto&& {}", &crate::emit::cpp::cpp_id(n)));
        }
        if let crate::lower::model::Pa::PaMut(n) = pa1 {
            break 'c Text::from(format!("auto {}", &crate::emit::cpp::cpp_id(n)));
        }
        if let crate::lower::model::Pa::PaWild = pa1 {
            break 'c Text::lit("const auto&");
        }
        if let p_ = pa1 {
            break 'c Text::from(format!("const auto& _p{}", i));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `ClosureParam`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosureParam: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub struct ClosureParam {
    pub cp: crate::emit::cpp::Cp,
    pub pa1: crate::lower::model::Pa,
    pub i: Nat,
}

impl prism_rtl::Job<Text> for ClosureParam {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let pa1 = &self.pa1;
        let i = &self.i;
        'j: {
            if let crate::lower::model::Pa::PaTyped(j0_1_0, t) = pa1 && let crate::lower::model::Pa::PaBind(n) = &**j0_1_0 {
                break 'j {
                    let cp = cp.clone();
                    let n = n.clone();
                    let t = t.clone();
                    call_then(start_param_type(cp.clone(), t.clone()), move |param_type_29741: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_29741, &crate::emit::cpp::cpp_id(&n)))))
                };
            }
            if let crate::lower::model::Pa::PaTyped(j1_1_0, t) = pa1 && let crate::lower::model::Pa::PaMut(n) = &**j1_1_0 {
                break 'j {
                    let cp = cp.clone();
                    let n = n.clone();
                    let t = t.clone();
                    call_then(crate::emit::cpp::start_cpp_type(cp.clone(), unref(&t)), move |cpp_type_29819: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_29819, &crate::emit::cpp::cpp_id(&n)))))
                };
            }
            if let crate::lower::model::Pa::PaTyped(p_, t) = pa1 {
                break 'j {
                    let cp = cp.clone();
                    let i = i.clone();
                    let t = t.clone();
                    call_then(start_param_type(cp.clone(), t.clone()), move |param_type_29895: Text| prism_rtl::Turn::Finished(Text::from(format!("{} _p{}", &param_type_29895, &i))))
                };
            }
            if let crate::lower::model::Pa::PaBind(n) = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::from(format!("auto&& {}", &crate::emit::cpp::cpp_id(n))));
            }
            if let crate::lower::model::Pa::PaMut(n) = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::from(format!("auto {}", &crate::emit::cpp::cpp_id(n))));
            }
            if let crate::lower::model::Pa::PaWild = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::lit("const auto&"));
            }
            if let p_ = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::from(format!("const auto& _p{}", i)));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start ClosureParam, x`: what the function value is when passed to `@Run`.
pub fn start_closure_param(cp: crate::emit::cpp::Cp, pa1: crate::lower::model::Pa, i: Nat) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ClosureParam { cp, pa1, i })
}

/// ```prism
/// ClosureBinds: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub fn closure_binds(cp: &crate::emit::cpp::Cp, pa1: &crate::lower::model::Pa, i: &Nat) -> Text {
    'c: {
        if let crate::lower::model::Pa::PaTyped(c0_1_0, t) = pa1 && let crate::lower::model::Pa::PaBind(n) = &**c0_1_0 {
            break 'c Text::lit("");
        }
        if let crate::lower::model::Pa::PaTyped(c1_1_0, t) = pa1 && let crate::lower::model::Pa::PaMut(n) = &**c1_1_0 {
            break 'c Text::lit("");
        }
        if let crate::lower::model::Pa::PaTyped(p_, t) = pa1 {
            break 'c closure_binds(cp, &**p_, i);
        }
        if let crate::lower::model::Pa::PaBind(n) = pa1 {
            break 'c Text::lit("");
        }
        if let crate::lower::model::Pa::PaMut(n) = pa1 {
            break 'c Text::lit("");
        }
        if let crate::lower::model::Pa::PaWild = pa1 {
            break 'c Text::lit("");
        }
        if let p_ = pa1 {
            break 'c concat(&each(&crate::emit::cpp::patterns::pat_binds(cp, p_, &Text::from(format!("_p{}", i))), &(|b: &Text| Text::from(format!("{}\n", b)))));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `ClosureBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosureBinds: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub struct ClosureBinds {
    pub cp: crate::emit::cpp::Cp,
    pub pa1: crate::lower::model::Pa,
    pub i: Nat,
}

impl prism_rtl::Job<Text> for ClosureBinds {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let pa1 = &self.pa1;
        let i = &self.i;
        'j: {
            if let crate::lower::model::Pa::PaTyped(j0_1_0, t) = pa1 && let crate::lower::model::Pa::PaBind(n) = &**j0_1_0 {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let crate::lower::model::Pa::PaTyped(j1_1_0, t) = pa1 && let crate::lower::model::Pa::PaMut(n) = &**j1_1_0 {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let crate::lower::model::Pa::PaTyped(p_, t) = pa1 {
                break 'j prism_rtl::Turn::More(Rc::new(ClosureBinds { cp: cp.clone(), pa1: (**p_).clone(), i: i.clone() }));
            }
            if let crate::lower::model::Pa::PaBind(n) = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let crate::lower::model::Pa::PaMut(n) = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let crate::lower::model::Pa::PaWild = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let p_ = pa1 {
                break 'j {
                    let cp = cp.clone();
                    let i = i.clone();
                    let p_ = p_.clone();
                    call_then(crate::emit::cpp::patterns::start_pat_binds(cp.clone(), p_.clone(), Text::from(format!("_p{}", &i))), move |pat_binds_30485: Array<Text>| prism_rtl::Turn::Finished(concat(&each(&pat_binds_30485, &(|b: &Text| Text::from(format!("{}\n", b)))))))
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start ClosureBinds, x`: what the function value is when passed to `@Run`.
pub fn start_closure_binds(cp: crate::emit::cpp::Cp, pa1: crate::lower::model::Pa, i: Nat) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ClosureBinds { cp, pa1, i })
}

/// ```prism
/// Unref: fn OutTy -> OutTy
/// ```
pub fn unref(out_ty0: &crate::lower::model::OutTy) -> crate::lower::model::OutTy {
    match out_ty0 {
        crate::lower::model::OutTy::OutRef(t) => (**t).clone(),
        t => t.clone(),
    }
}

/// ```prism
/// ParamType: unbounded fn Cp, OutTy -> Text
/// ```
pub fn param_type(cp: &crate::emit::cpp::Cp, t: &crate::lower::model::OutTy) -> Text {
    match t {
        crate::lower::model::OutTy::OutRef(_) => crate::emit::cpp::cpp_type(cp, t),
        crate::lower::model::OutTy::OutSlice(_) => crate::emit::cpp::cpp_type(cp, t),
        crate::lower::model::OutTy::OutUnit => Text::lit("Unit"),
        _ => crate::emit::cpp::cpp_type(cp, t),
    }
}

/// The step machine of `ParamType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParamType: unbounded fn Cp, OutTy -> Text
/// ```
pub struct ParamType {
    pub cp: crate::emit::cpp::Cp,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for ParamType {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let t = &self.t;
        match t {
            crate::lower::model::OutTy::OutRef(_) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::CppType { cp: cp.clone(), t: t.clone() })),
            crate::lower::model::OutTy::OutSlice(_) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::CppType { cp: cp.clone(), t: t.clone() })),
            crate::lower::model::OutTy::OutUnit => prism_rtl::Turn::Finished(Text::lit("Unit")),
            _ => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::CppType { cp: cp.clone(), t: t.clone() })),
        }
    }
}

/// `Start ParamType, x`: what the function value is when passed to `@Run`.
pub fn start_param_type(cp: crate::emit::cpp::Cp, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ParamType { cp, t })
}
