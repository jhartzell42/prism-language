//! The module `Emit.Cpp.Expr`, from `target/bootstrap/src/prismc/emit/cpp/expr.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// CppLoose: fn Ex -> Bool
/// ```
pub fn cpp_loose_f(x_p0: &crate::lower::model::Ex) -> bool {
    match x_p0 {
        crate::lower::model::Ex::XBlock(m1173_0_0, inner_p1) if (m1173_0_0.len() == 0) => cpp_loose_f(&**inner_p1),
        crate::lower::model::Ex::XBin(_, _, _) => true,
        crate::lower::model::Ex::XUnary(_, _) => true,
        crate::lower::model::Ex::XIf(_, _, _) => true,
        crate::lower::model::Ex::XRef(y_p2) => cpp_loose_f(&**y_p2),
        crate::lower::model::Ex::XRefMut(y_p3) => cpp_loose_f(&**y_p3),
        crate::lower::model::Ex::XClone(y_p4) => cpp_loose_f(&**y_p4),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CppTight: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_tight_f(cp_p0: &crate::emit::cpp::Cp, x_p1: &crate::lower::model::Ex) -> Text {
    if cpp_loose_f(x_p1) {
        Text::from(format!("({})", &cpp_expr_f(cp_p0, x_p1)))
    } else {
        starred_f(&cpp_expr_f(cp_p0, x_p1))
    }
}

/// The step machine of `CppTight`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppTight: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppTight {
    pub cp_p0: crate::emit::cpp::Cp,
    pub x_p1: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppTight {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let x_p1 = &self.x_p1;
        if cpp_loose_f(x_p1) {
            {
                let cp_p0x = cp_p0.clone();
                let x_p1x = x_p1.clone();
                crate::prelude::call_then(start_cpp_expr_f(cp_p0x.clone(), x_p1x.clone()), move |cpp_expr_f_1500: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &cpp_expr_f_1500))))
            }
        } else {
            {
                let cp_p0x = cp_p0.clone();
                let x_p1x = x_p1.clone();
                crate::prelude::call_then(start_cpp_expr_f(cp_p0x.clone(), x_p1x.clone()), move |cpp_expr_f_1532: Text| prism_rtl::Turn::Finished(starred_f(&cpp_expr_f_1532)))
            }
        }
    }
}

/// `Start CppTight, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_tight_f(cp_p0: crate::emit::cpp::Cp, x_p1: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppTight { cp_p0, x_p1 })
}

/// ```prism
/// Starred: fn Text -> Text
/// ```
pub fn starred_f(t_p0: &Text) -> Text {
    if crate::syntax::lexer::chars::has_prefix_f(t_p0, &Text::lit("*")) {
        Text::from(format!("({})", t_p0))
    } else {
        t_p0.clone()
    }
}

/// ```prism
/// CppTightPlace: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_tight_place_f(cp_p0: &crate::emit::cpp::Cp, x_p1: &crate::lower::model::Ex) -> Text {
    if cpp_loose_f(x_p1) {
        Text::from(format!("({})", &cpp_place_f(cp_p0, x_p1)))
    } else {
        starred_f(&cpp_place_f(cp_p0, x_p1))
    }
}

/// The step machine of `CppTightPlace`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppTightPlace: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppTightPlace {
    pub cp_p0: crate::emit::cpp::Cp,
    pub x_p1: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppTightPlace {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let x_p1 = &self.x_p1;
        if cpp_loose_f(x_p1) {
            {
                let cp_p0x = cp_p0.clone();
                let x_p1x = x_p1.clone();
                crate::prelude::call_then(start_cpp_place_f(cp_p0x.clone(), x_p1x.clone()), move |cpp_place_f_1889: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &cpp_place_f_1889))))
            }
        } else {
            {
                let cp_p0x = cp_p0.clone();
                let x_p1x = x_p1.clone();
                crate::prelude::call_then(start_cpp_place_f(cp_p0x.clone(), x_p1x.clone()), move |cpp_place_f_1922: Text| prism_rtl::Turn::Finished(starred_f(&cpp_place_f_1922)))
            }
        }
    }
}

/// `Start CppTightPlace, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_tight_place_f(cp_p0: crate::emit::cpp::Cp, x_p1: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppTightPlace { cp_p0, x_p1 })
}

/// ```prism
/// CppPlace: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_place_f(cp_p0: &crate::emit::cpp::Cp, ex1: &crate::lower::model::Ex) -> Text {
    match ex1 {
        crate::lower::model::Ex::XVar(n_p1) => crate::emit::cpp::stmts::var_name_f(cp_p0, n_p1),
        x_p3 => cpp_expr_f(cp_p0, x_p3),
    }
}

/// The step machine of `CppPlace`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppPlace: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppPlace {
    pub cp_p0: crate::emit::cpp::Cp,
    pub ex1: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppPlace {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let ex1 = &self.ex1;
        match ex1 {
            crate::lower::model::Ex::XVar(n_p1) => prism_rtl::Turn::Finished(crate::emit::cpp::stmts::var_name_f(cp_p0, n_p1)),
            x_p3 => prism_rtl::Turn::More(Rc::new(CppExpr { cp_p0: cp_p0.clone(), x_p1: x_p3.clone() })),
        }
    }
}

/// `Start CppPlace, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_place_f(cp_p0: crate::emit::cpp::Cp, ex1: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppPlace { cp_p0, ex1 })
}

/// ```prism
/// CppVar: fn Cp, Text -> Text
/// ```
pub fn cpp_var_f(cp_p0: &crate::emit::cpp::Cp, n_p1: &Text) -> Text {
    if crate::prelude::or(&crate::prelude::get(&cp_p0.owned_p, n_p1), &false) {
        Text::from(format!("std::move({})", &crate::emit::cpp::stmts::var_name_f(cp_p0, n_p1)))
    } else {
        crate::emit::cpp::stmts::var_name_f(cp_p0, n_p1)
    }
}

/// ```prism
/// CppArgs: unbounded fn Cp, [Ex] -> Text
/// ```
pub fn cpp_args_f(cp_p0: &crate::emit::cpp::Cp, xs_p1: &Array<crate::lower::model::Ex>) -> Text {
    crate::syntax::lexer::chars::join_f(&cpp_arg_list_f(cp_p0, xs_p1), &Text::lit(", "))
}

/// The step machine of `CppArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppArgs: unbounded fn Cp, [Ex] -> Text
/// ```
pub struct CppArgs {
    pub cp_p0: crate::emit::cpp::Cp,
    pub xs_p1: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for CppArgs {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let xs_p1 = &self.xs_p1;
        let cp_p0x = cp_p0.clone();
        let xs_p1x = xs_p1.clone();
        crate::prelude::call_then(start_cpp_arg_list_f(cp_p0x.clone(), xs_p1x.clone()), move |cpp_arg_list_f_2810: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join_f(&cpp_arg_list_f_2810, &Text::lit(", "))))
    }
}

/// `Start CppArgs, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_args_f(cp_p0: crate::emit::cpp::Cp, xs_p1: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppArgs { cp_p0, xs_p1 })
}

/// ```prism
/// CppArgList: unbounded fn Cp, [Ex] -> [Text]
/// ```
pub fn cpp_arg_list_f(cp_p0: &crate::emit::cpp::Cp, xs_p1: &Array<crate::lower::model::Ex>) -> Array<Text> {
    let texts_p2 = crate::prelude::run_to_end(crate::prelude::each_job(xs_p1.clone(), {
        let cp_p0x = cp_p0.clone();
        Rc::new(move |p0: crate::lower::model::Ex| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let x_p3 = p0;
                prism_rtl::Turn::More(Rc::new(CppExpr { cp_p0: cp_p0xy.clone(), x_p1: x_p3.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(xs_p1)), {
        let xs_p1x = xs_p1.clone();
        let cp_p0x = cp_p0.clone();
        let texts_p2x = texts_p2.clone();
        Rc::new(move |p0: Nat| {
            let xs_p1xy = xs_p1x.clone();
            let cp_p0xy = cp_p0x.clone();
            let texts_p2xy = texts_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_p4 = p0;
                match crate::prelude::or(&crate::prelude::index(&xs_p1xy, &i_p4), &crate::lower::model::Ex::XUnit) {
                    crate::lower::model::Ex::XVar(n_p5) => crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&xs_p1xy)), false, {
                        let i_p4x = i_p4.clone();
                        let xs_p1xyx = xs_p1xy.clone();
                        let n_p5x = n_p5.clone();
                        Rc::new(move |(p0, p1): (bool, Nat)| {
                            let i_p4xy = i_p4x.clone();
                            let xs_p1xyxy = xs_p1xyx.clone();
                            let n_p5xy = n_p5x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let f_p6 = p0;
                                let j_p7 = p1;
                                prism_rtl::Turn::Finished(f_p6 || ((&j_p7 != &i_p4xy) && crate::lower::model::ex_reads_f(&crate::prelude::or(&crate::prelude::index(&xs_p1xyxy, &j_p7), &crate::lower::model::Ex::XUnit), &n_p5xy)))
                            }))
                        }) as Rc<dyn Fn((bool, Nat)) -> Rc<dyn prism_rtl::Job<bool>>>
                    }), move |fold_3021: bool| if fold_3021 {
                        prism_rtl::Turn::Finished(crate::emit::cpp::stmts::var_name_f(&cp_p0xy, &n_p5))
                    } else {
                        prism_rtl::Turn::Finished(crate::prelude::or(&crate::prelude::index(&texts_p2xy, &i_p4), &Text::lit("")))
                    }),
                    _ => prism_rtl::Turn::Finished(crate::prelude::or(&crate::prelude::index(&texts_p2xy, &i_p4), &Text::lit(""))),
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    }))
}

/// The step machine of `CppArgList`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppArgList: unbounded fn Cp, [Ex] -> [Text]
/// ```
pub struct CppArgList {
    pub cp_p0: crate::emit::cpp::Cp,
    pub xs_p1: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Array<Text>> for CppArgList {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cp_p0 = &self.cp_p0;
        let xs_p1 = &self.xs_p1;
        let cp_p0x = cp_p0.clone();
        let xs_p1x = xs_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(xs_p1x.clone(), {
            let cp_p0xx = cp_p0x.clone();
            Rc::new(move |p0: crate::lower::model::Ex| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let x_p3 = p0;
                    prism_rtl::Turn::More(Rc::new(CppExpr { cp_p0: cp_p0xxy.clone(), x_p1: x_p3.clone() }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_2918: Array<Text>| {
            let texts_p2 = each_2918;
            crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&xs_p1x)), {
                let xs_p1xx = xs_p1x.clone();
                let cp_p0xx = cp_p0x.clone();
                let texts_p2x = texts_p2.clone();
                Rc::new(move |p0: Nat| {
                    let xs_p1xxy = xs_p1xx.clone();
                    let cp_p0xxy = cp_p0xx.clone();
                    let texts_p2xy = texts_p2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let i_p4 = p0;
                        match crate::prelude::or(&crate::prelude::index(&xs_p1xxy, &i_p4), &crate::lower::model::Ex::XUnit) {
                            crate::lower::model::Ex::XVar(n_p5) => crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&xs_p1xxy)), false, {
                                let i_p4x = i_p4.clone();
                                let xs_p1xxyx = xs_p1xxy.clone();
                                let n_p5x = n_p5.clone();
                                Rc::new(move |(p0, p1): (bool, Nat)| {
                                    let i_p4xy = i_p4x.clone();
                                    let xs_p1xxyxy = xs_p1xxyx.clone();
                                    let n_p5xy = n_p5x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let f_p6 = p0;
                                        let j_p7 = p1;
                                        prism_rtl::Turn::Finished(f_p6 || ((&j_p7 != &i_p4xy) && crate::lower::model::ex_reads_f(&crate::prelude::or(&crate::prelude::index(&xs_p1xxyxy, &j_p7), &crate::lower::model::Ex::XUnit), &n_p5xy)))
                                    }))
                                }) as Rc<dyn Fn((bool, Nat)) -> Rc<dyn prism_rtl::Job<bool>>>
                            }), move |fold_3021: bool| if fold_3021 {
                                prism_rtl::Turn::Finished(crate::emit::cpp::stmts::var_name_f(&cp_p0xxy, &n_p5))
                            } else {
                                prism_rtl::Turn::Finished(crate::prelude::or(&crate::prelude::index(&texts_p2xy, &i_p4), &Text::lit("")))
                            }),
                            _ => prism_rtl::Turn::Finished(crate::prelude::or(&crate::prelude::index(&texts_p2xy, &i_p4), &Text::lit(""))),
                        }
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
            }).cycle()
        })
    }
}

/// `Start CppArgList, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_arg_list_f(cp_p0: crate::emit::cpp::Cp, xs_p1: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(CppArgList { cp_p0, xs_p1 })
}

/// ```prism
/// CppExpr: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_expr_f(cp_p0: &crate::emit::cpp::Cp, x_p1: &crate::lower::model::Ex) -> Text {
    match x_p1 {
        crate::lower::model::Ex::XVar(n_p2) => cpp_var_f(cp_p0, n_p2),
        crate::lower::model::Ex::XPath(p_p3) => path_value_f(cp_p0, p_p3),
        crate::lower::model::Ex::XSelf => Text::lit("prism_rtl::share(this)"),
        crate::lower::model::Ex::XCx => Text::lit("cx"),
        crate::lower::model::Ex::XConst(n_p4) => n_p4.clone(),
        crate::lower::model::Ex::XUnit => Text::lit("Unit{}"),
        crate::lower::model::Ex::XNone => Text::lit("std::nullopt"),
        crate::lower::model::Ex::XBool(b_p5) => if *b_p5 { Text::lit("true") } else { Text::lit("false") },
        crate::lower::model::Ex::XNat(d_p6) => if &crate::prelude::len_text(d_p6) <= &Nat::from(9u32) {
            Text::from(format!("Nat({}u)", d_p6))
        } else {
            Text::from(format!("*Nat::from_int({})", &cpp_expr_f(cp_p0, &crate::lower::model::Ex::XInt(d_p6.clone()))))
        },
        crate::lower::model::Ex::XInt(d_p7) => if &crate::prelude::len_text(&(if crate::syntax::lexer::chars::has_prefix_f(d_p7, &Text::lit("-")) {
            crate::syntax::lexer::chars::after_first_f(d_p7)
        } else {
            d_p7.clone()
        })) <= &Nat::from(18u32) {
            Text::from(format!("Int({}ll)", d_p7))
        } else {
            Text::from(format!("*Int::parse(\"{}\")", d_p7))
        },
        crate::lower::model::Ex::XByte(d_p8) => Text::from(format!("std::uint8_t({})", d_p8)),
        crate::lower::model::Ex::XFloat(d_p9) => Text::from(format!("Float{{{}}}", d_p9)),
        crate::lower::model::Ex::XIndex(n_pa) => Text::from(format!("{}u", n_pa)),
        crate::lower::model::Ex::XChar(c_pb) => Text::from(format!("U\'{}\'", &cpp_char_escape_f(c_pb))),
        crate::lower::model::Ex::XStr(t_pc) => cpp_string_f(t_pc),
        crate::lower::model::Ex::XRegex(p_pd, f_pe) => Text::from(format!("([]() -> const Regex& {{ static const Regex r = Regex::lit({}, {}); return r; }}())", &cpp_string_f(p_pd), &cpp_string_f(f_pe))),
        crate::lower::model::Ex::XReplacement(p_pf, r_pg, f_ph) => Text::from(format!("([]() -> const RegexReplacement& {{ static const RegexReplacement r = RegexReplacement::lit({}, {}, {}); return r; }}())", &cpp_string_f(p_pf), &cpp_string_f(f_ph), &cpp_string_f(r_pg))),
        crate::lower::model::Ex::XRef(y_pi) => cpp_place_f(cp_p0, &**y_pi),
        crate::lower::model::Ex::XRefMut(y_pj) => cpp_place_f(cp_p0, &**y_pj),
        crate::lower::model::Ex::XDeref(y_pk) => match ex_ty_o(cp_p0, &**y_pk) {
            Some(crate::lower::model::OutTy::OutRc(_)) => Text::from(format!("*{}", &cpp_tight_place_f(cp_p0, &**y_pk))),
            Some(crate::lower::model::OutTy::OutRef(_)) => cpp_place_f(cp_p0, &**y_pk),
            _ => Text::from(format!("prism_rtl::deref({})", &cpp_place_f(cp_p0, &**y_pk))),
        },
        crate::lower::model::Ex::XTarget(y_pl) => cpp_place_f(cp_p0, &**y_pl),
        crate::lower::model::Ex::XClone(y_pm) => cpp_place_f(cp_p0, &**y_pm),
        crate::lower::model::Ex::XWeak(y_pn) => Text::from(format!("prism_rtl::weaken({})", &cpp_expr_f(cp_p0, &**y_pn))),
        crate::lower::model::Ex::XUpgrade(y_po) => Text::from(format!("prism_rtl::upgrade({})", &cpp_expr_f(cp_p0, &**y_po))),
        crate::lower::model::Ex::XBreak(l_pp, y_pq) => Text::from(format!("({})", &crate::emit::cpp::patterns::cpp_break_f(cp_p0, l_pp, &**y_pq))),
        crate::lower::model::Ex::XBreakLoop => Text::lit("({ break; })"),
        crate::lower::model::Ex::XLater(y_pr) => Text::from(format!("[=](Cx& cx) -> Done {{ {}; return {{}}; }}", &cpp_expr_f(&crate::emit::cpp::stmts::captured_f(cp_p0), &**y_pr))),
        crate::lower::model::Ex::XFormatStr(parts_ps) => cpp_format_f(cp_p0, parts_ps, &Text::lit("prism_rtl::str")),
        crate::lower::model::Ex::XIsCase(y_pt, m3236_28_1) if (m3236_28_1.len() == 0) => Text::lit("false"),
        crate::lower::model::Ex::XIsCase(y_pu, cs_pv) => Text::from(format!("({})", &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(cs_pv.clone(), {
            let cp_p0x = cp_p0.clone();
            let y_pux = (**y_pu).clone();
            Rc::new(move |p0: Text| {
                let cp_p0xy = cp_p0x.clone();
                let y_puxy = y_pux.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let c_p10 = p0;
                    crate::prelude::call_then(start_cpp_tight_place_f(cp_p0xy.clone(), y_puxy.clone()), move |cpp_tight_place_f_5390: Text| prism_rtl::Turn::Finished(case_test_f(&cp_p0xy, &c_p10, &cpp_tight_place_f_5390)))
                }))
            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>
        })), &Text::lit(" || ")))),
        crate::lower::model::Ex::XRefusal(what_p11) => Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::expr::lowering_refusal_p(), &crate::lower::expr::escape_f(what_p11))),
        crate::lower::model::Ex::XUnreachable => Text::lit("throw prism_rtl::Panic(\"entered unreachable code\")"),
        crate::lower::model::Ex::XCall(f_p12, args_p13) => cpp_call_f(cp_p0, f_p12, args_p13),
        crate::lower::model::Ex::XApply(f_p14, args_p15) => Text::from(format!("{}({})", &cpp_tight_place_f(cp_p0, &**f_p14), &cpp_args_f(cp_p0, args_p15))),
        crate::lower::model::Ex::XMethod(r_p16, m_p17, args_p18) => cpp_method_f(cp_p0, &**r_p16, m_p17, args_p18),
        crate::lower::model::Ex::XBin(op_p19, l_p1a, r_p1b) => {
            let (lt_p1e, rt_p1f) = 'm5764: {
                let scrutinee = &cpp_arg_list_f(cp_p0, &Array::from(vec![(**l_p1a).clone(), (**r_p1b).clone()]));
                if let m5764_0 = scrutinee && (m5764_0.len() == 2) && let Some(a_p1c) = crate::prelude::index(m5764_0, &Nat::from(0u32)) && let Some(b_p1d) = crate::prelude::index(m5764_0, &Nat::from(1u32)) {
                    break 'm5764 (a_p1c.clone(), b_p1d.clone());
                }
                (Text::lit(""), Text::lit(""))
            };
            Text::from(format!("{} {} {}", &(if cpp_loose_f(&**l_p1a) {
                Text::from(format!("({})", &lt_p1e))
            } else {
                lt_p1e.clone()
            }), &crate::lower::model::bin_op_text_f(op_p19), &(if cpp_loose_f(&**r_p1b) {
                Text::from(format!("({})", &rt_p1f))
            } else {
                rt_p1f.clone()
            })))
        },
        crate::lower::model::Ex::XUnary(op_p1g, y_p1h) => Text::from(format!("{}{}", &crate::lower::model::un_op_text_f(op_p1g), &cpp_tight_f(cp_p0, &**y_p1h))),
        crate::lower::model::Ex::XCtor(p_p1i, args_p1j) => cpp_ctor_f(cp_p0, p_p1i, args_p1j),
        crate::lower::model::Ex::XRecord(p_p1k, fs_p1l) => cpp_record_f(cp_p0, p_p1k, fs_p1l),
        crate::lower::model::Ex::XTuple(xs_p1m) => Text::from(format!("std::tuple{{{}}}", &cpp_args_f(cp_p0, xs_p1m))),
        crate::lower::model::Ex::XVec(m3236_40_0) if (m3236_40_0.len() == 0) => Text::lit("{}"),
        crate::lower::model::Ex::XVec(xs_p1n) => Text::from(format!("std::vector{{{}}}", &cpp_args_f(cp_p0, xs_p1n))),
        crate::lower::model::Ex::XText(t_p1o) => Text::from(format!("Text::lit({})", &cpp_string_f(t_p1o))),
        crate::lower::model::Ex::XFormat(parts_p1p) => if crate::prelude::fold(parts_p1p, &true, &(|f_p1q: &bool, p_p1r: &crate::lower::model::Ex| *f_p1q && is_text_piece_f(p_p1r))) {
            Text::from(format!("Text::lit({})", &cpp_string_f(&crate::prelude::concat(&crate::prelude::each(parts_p1p, &(|p_p1s: &crate::lower::model::Ex| text_piece_f(p_p1s)))))))
        } else {
            cpp_format_f(cp_p0, parts_p1p, &Text::lit("prism_rtl::cat"))
        },
        crate::lower::model::Ex::XMatch(s_p1t, arms_p1u, fallback_p1v, t_p20) => crate::emit::cpp::patterns::cpp_match_f(cp_p0, &**s_p1t, arms_p1u, t_p20),
        crate::lower::model::Ex::XChain(label_p21, s_p22, arms_p23, t_p24) => crate::emit::cpp::patterns::cpp_match_f(cp_p0, &**s_p22, arms_p23, t_p24),
        crate::lower::model::Ex::XIf(c_p25, t_p26, e_p27) => cpp_if_f(cp_p0, &**c_p25, &**t_p26, &**e_p27),
        crate::lower::model::Ex::XBlock(m3236_47_0, e_p28) if (m3236_47_0.len() == 0) => cpp_expr_f(cp_p0, &**e_p28),
        crate::lower::model::Ex::XBlock(dos_p29, e_p2a) => {
            let (st_p2b, cp2_p2c) = crate::emit::cpp::stmts::cpp_statements_cp_f(cp_p0, dos_p29);
            crate::emit::cpp::templates::items::stmt_expr_f(&st_p2b, &crate::emit::cpp::stmts::unvexed_f(&cpp_expr_f(&with_move_captures_f(&cp2_p2c, dos_p29, &**e_p2a), &**e_p2a)))
        },
        crate::lower::model::Ex::XLabeled(label_p2d, dos_p2e, e_p2f, t_p2g) => crate::emit::cpp::patterns::cpp_labeled_f(cp_p0, label_p2d, dos_p2e, &**e_p2f, t_p2g),
        crate::lower::model::Ex::XClosure(mv_p2h, ps_p2i, body_p2j) => cpp_closure_f(cp_p0, mv_p2h, ps_p2i, &**body_p2j),
        crate::lower::model::Ex::XTry(y_p2k) => Text::from(format!("TRY({})", &cpp_expr_f(cp_p0, &**y_p2k))),
        crate::lower::model::Ex::XField(r_p2l, f_p2m) => cpp_field_f(cp_p0, &**r_p2l, f_p2m),
        crate::lower::model::Ex::XPart(r_p2n, k_p2o) => Text::from(format!("std::get<{}>({})", k_p2o, &as_value_f(cp_p0, &**r_p2n))),
        crate::lower::model::Ex::XDecode(t_p2p, y_p2q) => Text::from(format!("TRY(prism_rtl::from_pod<{}>({}))", &crate::emit::cpp::cpp_type_f(cp_p0, t_p2p), &cpp_expr_f(cp_p0, &**y_p2q))),
        crate::lower::model::Ex::XCast(y_p2r, t_p2s) => Text::from(format!("static_cast<{}>({})", &crate::emit::cpp::cpp_type_f(cp_p0, t_p2s), &cpp_expr_f(cp_p0, &**y_p2r))),
        crate::lower::model::Ex::XTyped(y_p2t, t_p2u) => match &**y_p2t {
            crate::lower::model::Ex::XCtor(p_p2v, args_p30) if is_generic_case_f(cp_p0, p_p2v) => {
                let tt_p31 = crate::emit::cpp::cpp_type_f(cp_p0, t_p2u);
                Text::from(format!("{}({}::{}{{{}}})", &tt_p31, &tt_p31, &crate::emit::cpp::last_segment_f(&crate::emit::cpp::type_path_f(p_p2v)), &cpp_args_f(cp_p0, args_p30)))
            },
            crate::lower::model::Ex::XPath(p_p32) if is_generic_case_f(cp_p0, p_p32) => {
                let tt_p33 = crate::emit::cpp::cpp_type_f(cp_p0, t_p2u);
                Text::from(format!("{}({}::{}{{}})", &tt_p33, &tt_p33, &crate::emit::cpp::last_segment_f(&crate::emit::cpp::type_path_f(p_p32))))
            },
            _ => {
                let e_p34 = cpp_expr_f(cp_p0, &**y_p2t);
                if (&e_p34 == &Text::lit("{}")) || (&e_p34 == &Text::lit("std::nullopt")) {
                    Text::from(format!("{}{{}}", &crate::emit::cpp::cpp_type_f(cp_p0, t_p2u)))
                } else {
                    if is_ctor_f(&**y_p2t, &Text::lit("Ok")) || is_ctor_f(&**y_p2t, &Text::lit("Err")) {
                        Text::from(format!("{}({})", &crate::emit::cpp::cpp_type_f(cp_p0, t_p2u), &e_p34))
                    } else {
                        e_p34.clone()
                    }
                }
            },
            _ => unreachable!("no arm matched"),
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CppExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppExpr: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppExpr {
    pub cp_p0: crate::emit::cpp::Cp,
    pub x_p1: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppExpr {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let x_p1 = &self.x_p1;
        match x_p1 {
            crate::lower::model::Ex::XVar(n_p2) => prism_rtl::Turn::Finished(cpp_var_f(cp_p0, n_p2)),
            crate::lower::model::Ex::XPath(p_p3) => prism_rtl::Turn::Finished(path_value_f(cp_p0, p_p3)),
            crate::lower::model::Ex::XSelf => prism_rtl::Turn::Finished(Text::lit("prism_rtl::share(this)")),
            crate::lower::model::Ex::XCx => prism_rtl::Turn::Finished(Text::lit("cx")),
            crate::lower::model::Ex::XConst(n_p4) => prism_rtl::Turn::Finished(n_p4.clone()),
            crate::lower::model::Ex::XUnit => prism_rtl::Turn::Finished(Text::lit("Unit{}")),
            crate::lower::model::Ex::XNone => prism_rtl::Turn::Finished(Text::lit("std::nullopt")),
            crate::lower::model::Ex::XBool(b_p5) => if *b_p5 {
                prism_rtl::Turn::Finished(Text::lit("true"))
            } else {
                prism_rtl::Turn::Finished(Text::lit("false"))
            },
            crate::lower::model::Ex::XNat(d_p6) => if &crate::prelude::len_text(d_p6) <= &Nat::from(9u32) {
                prism_rtl::Turn::Finished(Text::from(format!("Nat({}u)", d_p6)))
            } else {
                {
                    let cp_p0x = cp_p0.clone();
                    let d_p6x = d_p6.clone();
                    crate::prelude::call_then(start_cpp_expr_f(cp_p0x.clone(), crate::lower::model::Ex::XInt(d_p6x.clone())), move |cpp_expr_f_3517: Text| prism_rtl::Turn::Finished(Text::from(format!("*Nat::from_int({})", &cpp_expr_f_3517))))
                }
            },
            crate::lower::model::Ex::XInt(d_p7) => if &crate::prelude::len_text(&(if crate::syntax::lexer::chars::has_prefix_f(d_p7, &Text::lit("-")) {
                crate::syntax::lexer::chars::after_first_f(d_p7)
            } else {
                d_p7.clone()
            })) <= &Nat::from(18u32) {
                prism_rtl::Turn::Finished(Text::from(format!("Int({}ll)", d_p7)))
            } else {
                prism_rtl::Turn::Finished(Text::from(format!("*Int::parse(\"{}\")", d_p7)))
            },
            crate::lower::model::Ex::XByte(d_p8) => prism_rtl::Turn::Finished(Text::from(format!("std::uint8_t({})", d_p8))),
            crate::lower::model::Ex::XFloat(d_p9) => prism_rtl::Turn::Finished(Text::from(format!("Float{{{}}}", d_p9))),
            crate::lower::model::Ex::XIndex(n_pa) => prism_rtl::Turn::Finished(Text::from(format!("{}u", n_pa))),
            crate::lower::model::Ex::XChar(c_pb) => prism_rtl::Turn::Finished(Text::from(format!("U\'{}\'", &cpp_char_escape_f(c_pb)))),
            crate::lower::model::Ex::XStr(t_pc) => prism_rtl::Turn::Finished(cpp_string_f(t_pc)),
            crate::lower::model::Ex::XRegex(p_pd, f_pe) => prism_rtl::Turn::Finished(Text::from(format!("([]() -> const Regex& {{ static const Regex r = Regex::lit({}, {}); return r; }}())", &cpp_string_f(p_pd), &cpp_string_f(f_pe)))),
            crate::lower::model::Ex::XReplacement(p_pf, r_pg, f_ph) => prism_rtl::Turn::Finished(Text::from(format!("([]() -> const RegexReplacement& {{ static const RegexReplacement r = RegexReplacement::lit({}, {}, {}); return r; }}())", &cpp_string_f(p_pf), &cpp_string_f(f_ph), &cpp_string_f(r_pg)))),
            crate::lower::model::Ex::XRef(y_pi) => prism_rtl::Turn::More(Rc::new(CppPlace { cp_p0: cp_p0.clone(), ex1: (**y_pi).clone() })),
            crate::lower::model::Ex::XRefMut(y_pj) => prism_rtl::Turn::More(Rc::new(CppPlace { cp_p0: cp_p0.clone(), ex1: (**y_pj).clone() })),
            crate::lower::model::Ex::XDeref(y_pk) => match ex_ty_o(cp_p0, &**y_pk) {
                Some(crate::lower::model::OutTy::OutRc(_)) => {
                    let cp_p0x = cp_p0.clone();
                    let y_pkx = (**y_pk).clone();
                    crate::prelude::call_then(start_cpp_tight_place_f(cp_p0x.clone(), y_pkx.clone()), move |cpp_tight_place_f_4802: Text| prism_rtl::Turn::Finished(Text::from(format!("*{}", &cpp_tight_place_f_4802))))
                },
                Some(crate::lower::model::OutTy::OutRef(_)) => prism_rtl::Turn::More(Rc::new(CppPlace { cp_p0: cp_p0.clone(), ex1: (**y_pk).clone() })),
                _ => {
                    let cp_p0x = cp_p0.clone();
                    let y_pkx = (**y_pk).clone();
                    crate::prelude::call_then(start_cpp_place_f(cp_p0x.clone(), y_pkx.clone()), move |cpp_place_f_4904: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::deref({})", &cpp_place_f_4904))))
                },
            },
            crate::lower::model::Ex::XTarget(y_pl) => prism_rtl::Turn::More(Rc::new(CppPlace { cp_p0: cp_p0.clone(), ex1: (**y_pl).clone() })),
            crate::lower::model::Ex::XClone(y_pm) => prism_rtl::Turn::More(Rc::new(CppPlace { cp_p0: cp_p0.clone(), ex1: (**y_pm).clone() })),
            crate::lower::model::Ex::XWeak(y_pn) => {
                let cp_p0x = cp_p0.clone();
                let y_pnx = (**y_pn).clone();
                crate::prelude::call_then(start_cpp_expr_f(cp_p0x.clone(), y_pnx.clone()), move |cpp_expr_f_5014: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::weaken({})", &cpp_expr_f_5014))))
            },
            crate::lower::model::Ex::XUpgrade(y_po) => {
                let cp_p0x = cp_p0.clone();
                let y_pox = (**y_po).clone();
                crate::prelude::call_then(start_cpp_expr_f(cp_p0x.clone(), y_pox.clone()), move |cpp_expr_f_5068: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::upgrade({})", &cpp_expr_f_5068))))
            },
            crate::lower::model::Ex::XBreak(l_pp, y_pq) => {
                let cp_p0x = cp_p0.clone();
                let l_ppx = l_pp.clone();
                let y_pqx = (**y_pq).clone();
                crate::prelude::call_then(crate::emit::cpp::patterns::start_cpp_break_f(cp_p0x.clone(), l_ppx.clone(), y_pqx.clone()), move |cpp_break_f_5105: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &cpp_break_f_5105))))
            },
            crate::lower::model::Ex::XBreakLoop => prism_rtl::Turn::Finished(Text::lit("({ break; })")),
            crate::lower::model::Ex::XLater(y_pr) => {
                let cp_p0x = cp_p0.clone();
                let y_prx = (**y_pr).clone();
                crate::prelude::call_then(start_cpp_expr_f(crate::emit::cpp::stmts::captured_f(&cp_p0x), y_prx.clone()), move |cpp_expr_f_5198: Text| prism_rtl::Turn::Finished(Text::from(format!("[=](Cx& cx) -> Done {{ {}; return {{}}; }}", &cpp_expr_f_5198))))
            },
            crate::lower::model::Ex::XFormatStr(parts_ps) => prism_rtl::Turn::More(Rc::new(CppFormat { cp_p0: cp_p0.clone(), parts_p1: parts_ps.clone(), how_p2: Text::lit("prism_rtl::str") })),
            crate::lower::model::Ex::XIsCase(y_pt, m3236_28_1) if (m3236_28_1.len() == 0) => prism_rtl::Turn::Finished(Text::lit("false")),
            crate::lower::model::Ex::XIsCase(y_pu, cs_pv) => {
                let cp_p0x = cp_p0.clone();
                let cs_pvx = cs_pv.clone();
                let y_pux = (**y_pu).clone();
                crate::prelude::call_value(crate::prelude::each_job(cs_pvx.clone(), {
                    let cp_p0xx = cp_p0x.clone();
                    let y_puxx = y_pux.clone();
                    Rc::new(move |p0: Text| {
                        let cp_p0xxy = cp_p0xx.clone();
                        let y_puxxy = y_puxx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let c_p10 = p0;
                            crate::prelude::call_then(start_cpp_tight_place_f(cp_p0xxy.clone(), y_puxxy.clone()), move |cpp_tight_place_f_5390: Text| prism_rtl::Turn::Finished(case_test_f(&cp_p0xxy, &c_p10, &cpp_tight_place_f_5390)))
                        }))
                    }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_5359: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("({})", &crate::syntax::lexer::chars::join_f(&each_5359, &Text::lit(" || "))))))
            },
            crate::lower::model::Ex::XRefusal(what_p11) => prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::expr::lowering_refusal_p(), &crate::lower::expr::escape_f(what_p11)))),
            crate::lower::model::Ex::XUnreachable => prism_rtl::Turn::Finished(Text::lit("throw prism_rtl::Panic(\"entered unreachable code\")")),
            crate::lower::model::Ex::XCall(f_p12, args_p13) => prism_rtl::Turn::More(Rc::new(CppCall { cp_p0: cp_p0.clone(), f_p1: f_p12.clone(), args_p2: args_p13.clone() })),
            crate::lower::model::Ex::XApply(f_p14, args_p15) => {
                let args_p15x = args_p15.clone();
                let cp_p0x = cp_p0.clone();
                let f_p14x = (**f_p14).clone();
                crate::prelude::call_then(start_cpp_tight_place_f(cp_p0x.clone(), f_p14x.clone()), move |cpp_tight_place_f_5629: Text| crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p15x.clone()), move |cpp_args_f_5651: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &cpp_tight_place_f_5629, &cpp_args_f_5651)))))
            },
            crate::lower::model::Ex::XMethod(r_p16, m_p17, args_p18) => prism_rtl::Turn::More(Rc::new(CppMethod { cp_p0: cp_p0.clone(), r_p1: (**r_p16).clone(), m_p2: m_p17.clone(), args_p3: args_p18.clone() })),
            crate::lower::model::Ex::XBin(op_p19, l_p1a, r_p1b) => {
                let cp_p0x = cp_p0.clone();
                let l_p1ax = (**l_p1a).clone();
                let op_p19x = op_p19.clone();
                let r_p1bx = (**r_p1b).clone();
                crate::prelude::call_then(start_cpp_arg_list_f(cp_p0x.clone(), Array::from(vec![l_p1ax.clone(), r_p1bx.clone()])), move |cpp_arg_list_f_5770: Array<Text>| {
                    let (lt_p1e, rt_p1f) = 'm5764: {
                        if let m5764_0 = &cpp_arg_list_f_5770 && (m5764_0.len() == 2) && let Some(a_p1c) = crate::prelude::index(m5764_0, &Nat::from(0u32)) && let Some(b_p1d) = crate::prelude::index(m5764_0, &Nat::from(1u32)) {
                            break 'm5764 (a_p1c.clone(), b_p1d.clone());
                        }
                        (Text::lit(""), Text::lit(""))
                    };
                    prism_rtl::Turn::Finished(Text::from(format!("{} {} {}", &(if cpp_loose_f(&l_p1ax) {
                        Text::from(format!("({})", &lt_p1e))
                    } else {
                        lt_p1e.clone()
                    }), &crate::lower::model::bin_op_text_f(&op_p19x), &(if cpp_loose_f(&r_p1bx) {
                        Text::from(format!("({})", &rt_p1f))
                    } else {
                        rt_p1f.clone()
                    }))))
                })
            },
            crate::lower::model::Ex::XUnary(op_p1g, y_p1h) => {
                let cp_p0x = cp_p0.clone();
                let op_p1gx = op_p1g.clone();
                let y_p1hx = (**y_p1h).clone();
                crate::prelude::call_then(start_cpp_tight_f(cp_p0x.clone(), y_p1hx.clone()), move |cpp_tight_f_5988: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &crate::lower::model::un_op_text_f(&op_p1gx), &cpp_tight_f_5988))))
            },
            crate::lower::model::Ex::XCtor(p_p1i, args_p1j) => prism_rtl::Turn::More(Rc::new(CppCtor { cp_p0: cp_p0.clone(), p_p1: p_p1i.clone(), args_p2: args_p1j.clone() })),
            crate::lower::model::Ex::XRecord(p_p1k, fs_p1l) => prism_rtl::Turn::More(Rc::new(CppRecord { cp_p0: cp_p0.clone(), p_p1: p_p1k.clone(), fs_p2: fs_p1l.clone() })),
            crate::lower::model::Ex::XTuple(xs_p1m) => {
                let cp_p0x = cp_p0.clone();
                let xs_p1mx = xs_p1m.clone();
                crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), xs_p1mx.clone()), move |cpp_args_f_6112: Text| prism_rtl::Turn::Finished(Text::from(format!("std::tuple{{{}}}", &cpp_args_f_6112))))
            },
            crate::lower::model::Ex::XVec(m3236_40_0) if (m3236_40_0.len() == 0) => prism_rtl::Turn::Finished(Text::lit("{}")),
            crate::lower::model::Ex::XVec(xs_p1n) => {
                let cp_p0x = cp_p0.clone();
                let xs_p1nx = xs_p1n.clone();
                crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), xs_p1nx.clone()), move |cpp_args_f_6181: Text| prism_rtl::Turn::Finished(Text::from(format!("std::vector{{{}}}", &cpp_args_f_6181))))
            },
            crate::lower::model::Ex::XText(t_p1o) => prism_rtl::Turn::Finished(Text::from(format!("Text::lit({})", &cpp_string_f(t_p1o)))),
            crate::lower::model::Ex::XFormat(parts_p1p) => if crate::prelude::fold(parts_p1p, &true, &(|f_p1q: &bool, p_p1r: &crate::lower::model::Ex| *f_p1q && is_text_piece_f(p_p1r))) {
                prism_rtl::Turn::Finished(Text::from(format!("Text::lit({})", &cpp_string_f(&crate::prelude::concat(&crate::prelude::each(parts_p1p, &(|p_p1s: &crate::lower::model::Ex| text_piece_f(p_p1s))))))))
            } else {
                prism_rtl::Turn::More(Rc::new(CppFormat { cp_p0: cp_p0.clone(), parts_p1: parts_p1p.clone(), how_p2: Text::lit("prism_rtl::cat") }))
            },
            crate::lower::model::Ex::XMatch(s_p1t, arms_p1u, fallback_p1v, t_p20) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::patterns::CppMatch { cp_p0: cp_p0.clone(), s_p1: (**s_p1t).clone(), arms_p2: arms_p1u.clone(), out_ty3: t_p20.clone() })),
            crate::lower::model::Ex::XChain(label_p21, s_p22, arms_p23, t_p24) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::patterns::CppMatch { cp_p0: cp_p0.clone(), s_p1: (**s_p22).clone(), arms_p2: arms_p23.clone(), out_ty3: t_p24.clone() })),
            crate::lower::model::Ex::XIf(c_p25, t_p26, e_p27) => prism_rtl::Turn::More(Rc::new(CppIf { cp_p0: cp_p0.clone(), c_p1: (**c_p25).clone(), t_p2: (**t_p26).clone(), e_p3: (**e_p27).clone() })),
            crate::lower::model::Ex::XBlock(m3236_47_0, e_p28) if (m3236_47_0.len() == 0) => prism_rtl::Turn::More(Rc::new(CppExpr { cp_p0: cp_p0.clone(), x_p1: (**e_p28).clone() })),
            crate::lower::model::Ex::XBlock(dos_p29, e_p2a) => {
                let cp_p0x = cp_p0.clone();
                let dos_p29x = dos_p29.clone();
                let e_p2ax = (**e_p2a).clone();
                crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_statements_cp_f(cp_p0x.clone(), dos_p29x.clone()), move |cpp_statements_cp_f_6643: (Text, crate::emit::cpp::Cp)| {
                    let (st_p2b, cp2_p2c) = cpp_statements_cp_f_6643;
                    crate::prelude::call_then(start_with_move_captures_f(cp2_p2c.clone(), dos_p29x.clone(), e_p2ax.clone()), move |with_move_captures_f_6707: crate::emit::cpp::Cp| crate::prelude::call_then(start_cpp_expr_f(with_move_captures_f_6707, e_p2ax.clone()), move |cpp_expr_f_6698: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::stmt_expr_f(&st_p2b, &crate::emit::cpp::stmts::unvexed_f(&cpp_expr_f_6698)))))
                })
            },
            crate::lower::model::Ex::XLabeled(label_p2d, dos_p2e, e_p2f, t_p2g) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::patterns::CppLabeled { cp_p0: cp_p0.clone(), label_p1: label_p2d.clone(), dos_p2: dos_p2e.clone(), e_p3: (**e_p2f).clone(), t_p4: t_p2g.clone() })),
            crate::lower::model::Ex::XClosure(mv_p2h, ps_p2i, body_p2j) => prism_rtl::Turn::More(Rc::new(CppClosure { cp0_p0: cp_p0.clone(), mv_p1: *mv_p2h, ps_p2: ps_p2i.clone(), body_p3: (**body_p2j).clone() })),
            crate::lower::model::Ex::XTry(y_p2k) => {
                let cp_p0x = cp_p0.clone();
                let y_p2kx = (**y_p2k).clone();
                crate::prelude::call_then(start_cpp_expr_f(cp_p0x.clone(), y_p2kx.clone()), move |cpp_expr_f_6878: Text| prism_rtl::Turn::Finished(Text::from(format!("TRY({})", &cpp_expr_f_6878))))
            },
            crate::lower::model::Ex::XField(r_p2l, f_p2m) => prism_rtl::Turn::More(Rc::new(CppField { cp_p0: cp_p0.clone(), ex1: (**r_p2l).clone(), f_p1: f_p2m.clone() })),
            crate::lower::model::Ex::XPart(r_p2n, k_p2o) => {
                let cp_p0x = cp_p0.clone();
                let k_p2ox = k_p2o.clone();
                let r_p2nx = (**r_p2n).clone();
                crate::prelude::call_then(start_as_value_f(cp_p0x.clone(), r_p2nx.clone()), move |as_value_f_6962: Text| prism_rtl::Turn::Finished(Text::from(format!("std::get<{}>({})", &k_p2ox, &as_value_f_6962))))
            },
            crate::lower::model::Ex::XDecode(t_p2p, y_p2q) => {
                let cp_p0x = cp_p0.clone();
                let t_p2px = t_p2p.clone();
                let y_p2qx = (**y_p2q).clone();
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), t_p2px.clone()), move |cpp_type_f_7023: Text| crate::prelude::call_then(start_cpp_expr_f(cp_p0x.clone(), y_p2qx.clone()), move |cpp_expr_f_7040: Text| prism_rtl::Turn::Finished(Text::from(format!("TRY(prism_rtl::from_pod<{}>({}))", &cpp_type_f_7023, &cpp_expr_f_7040)))))
            },
            crate::lower::model::Ex::XCast(y_p2r, t_p2s) => {
                let cp_p0x = cp_p0.clone();
                let t_p2sx = t_p2s.clone();
                let y_p2rx = (**y_p2r).clone();
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), t_p2sx.clone()), move |cpp_type_f_7088: Text| crate::prelude::call_then(start_cpp_expr_f(cp_p0x.clone(), y_p2rx.clone()), move |cpp_expr_f_7105: Text| prism_rtl::Turn::Finished(Text::from(format!("static_cast<{}>({})", &cpp_type_f_7088, &cpp_expr_f_7105)))))
            },
            crate::lower::model::Ex::XTyped(y_p2t, t_p2u) => match &**y_p2t {
                crate::lower::model::Ex::XCtor(p_p2v, args_p30) if is_generic_case_f(cp_p0, p_p2v) => {
                    let args_p30x = args_p30.clone();
                    let cp_p0x = cp_p0.clone();
                    let p_p2vx = p_p2v.clone();
                    let t_p2ux = t_p2u.clone();
                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), t_p2ux.clone()), move |cpp_type_f_7215: Text| {
                        let tt_p31 = cpp_type_f_7215;
                        crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p30x.clone()), move |cpp_args_f_7282: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({}::{}{{{}}})", &tt_p31, &tt_p31, &crate::emit::cpp::last_segment_f(&crate::emit::cpp::type_path_f(&p_p2vx)), &cpp_args_f_7282))))
                    })
                },
                crate::lower::model::Ex::XPath(p_p32) if is_generic_case_f(cp_p0, p_p32) => {
                    let cp_p0x = cp_p0.clone();
                    let p_p32x = p_p32.clone();
                    let t_p2ux = t_p2u.clone();
                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), t_p2ux.clone()), move |cpp_type_f_7365: Text| {
                        let tt_p33 = cpp_type_f_7365;
                        prism_rtl::Turn::Finished(Text::from(format!("{}({}::{}{{}})", &tt_p33, &tt_p33, &crate::emit::cpp::last_segment_f(&crate::emit::cpp::type_path_f(&p_p32x)))))
                    })
                },
                _ => {
                    let cp_p0x = cp_p0.clone();
                    let t_p2ux = t_p2u.clone();
                    let y_p2tx = (**y_p2t).clone();
                    crate::prelude::call_then(start_cpp_expr_f(cp_p0x.clone(), y_p2tx.clone()), move |cpp_expr_f_7475: Text| {
                        let e_p34 = cpp_expr_f_7475;
                        if (&e_p34 == &Text::lit("{}")) || (&e_p34 == &Text::lit("std::nullopt")) {
                            crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), t_p2ux.clone()), move |cpp_type_f_7542: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{{}}", &cpp_type_f_7542))))
                        } else {
                            if is_ctor_f(&y_p2tx, &Text::lit("Ok")) || is_ctor_f(&y_p2tx, &Text::lit("Err")) {
                                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), t_p2ux.clone()), move |cpp_type_f_7622: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &cpp_type_f_7622, &e_p34))))
                            } else {
                                prism_rtl::Turn::Finished(e_p34.clone())
                            }
                        }
                    })
                },
                _ => unreachable!("no arm matched"),
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start CppExpr, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_expr_f(cp_p0: crate::emit::cpp::Cp, x_p1: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppExpr { cp_p0, x_p1 })
}

/// ```prism
/// CppString: fn Text -> Text
/// ```
pub fn cpp_string_f(t_p0: &Text) -> Text {
    if crate::syntax::lexer::chars::contains_f(t_p0, &Text::lit("\0")) {
        Text::from(format!("\"{}\"sv", &cpp_escape_f(t_p0)))
    } else {
        Text::from(format!("\"{}\"", &cpp_escape_f(t_p0)))
    }
}

/// ```prism
/// CppEscape: fn Text -> Text
/// ```
pub fn cpp_escape_f(t_p0: &Text) -> Text {
    crate::syntax::lexer::chars::map_chars_f(t_p0, &(Rc::new(move |p0: Text| crate::prelude::once_job(move || {
        let c_p1 = p0;
        if &c_p1 == &Text::lit("\0") {
            prism_rtl::Turn::Finished(Text::lit("\\000"))
        } else {
            prism_rtl::Turn::Finished(crate::lower::expr::char_escape_f(&c_p1))
        }
    })) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>))
}

/// ```prism
/// IsTextPiece: fn Ex -> Bool
/// ```
pub fn is_text_piece_f(ex0: &crate::lower::model::Ex) -> bool {
    match ex0 {
        crate::lower::model::Ex::XText(_) => true,
        other_p0 => false,
    }
}

/// ```prism
/// TextPiece: fn Ex -> Text
/// ```
pub fn text_piece_f(ex0: &crate::lower::model::Ex) -> Text {
    match ex0 {
        crate::lower::model::Ex::XText(t_p0) => t_p0.clone(),
        other_p1 => Text::lit(""),
    }
}

/// ```prism
/// CppFormat: unbounded fn Cp, [Ex], Text -> Text
/// ```
pub fn cpp_format_f(cp_p0: &crate::emit::cpp::Cp, parts_p1: &Array<crate::lower::model::Ex>, how_p2: &Text) -> Text {
    Text::from(format!("{}({})", how_p2, &crate::syntax::lexer::chars::join_f(&cpp_arg_list_f(cp_p0, &crate::prelude::each(parts_p1, &(|p_p3: &crate::lower::model::Ex| format_arg_f(p_p3)))), &Text::lit(", "))))
}

/// The step machine of `CppFormat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppFormat: unbounded fn Cp, [Ex], Text -> Text
/// ```
pub struct CppFormat {
    pub cp_p0: crate::emit::cpp::Cp,
    pub parts_p1: Array<crate::lower::model::Ex>,
    pub how_p2: Text,
}

impl prism_rtl::Job<Text> for CppFormat {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let parts_p1 = &self.parts_p1;
        let how_p2 = &self.how_p2;
        let cp_p0x = cp_p0.clone();
        let how_p2x = how_p2.clone();
        let parts_p1x = parts_p1.clone();
        crate::prelude::call_then(start_cpp_arg_list_f(cp_p0x.clone(), crate::prelude::each(&parts_p1x, &(|p_p3: &crate::lower::model::Ex| format_arg_f(p_p3)))), move |cpp_arg_list_f_8418: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &how_p2x, &crate::syntax::lexer::chars::join_f(&cpp_arg_list_f_8418, &Text::lit(", "))))))
    }
}

/// `Start CppFormat, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_format_f(cp_p0: crate::emit::cpp::Cp, parts_p1: Array<crate::lower::model::Ex>, how_p2: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppFormat { cp_p0, parts_p1, how_p2 })
}

/// ```prism
/// FormatArg: fn Ex -> Ex
/// ```
pub fn format_arg_f(ex0: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    match ex0 {
        crate::lower::model::Ex::XText(t_p0) => crate::lower::model::Ex::XStr(t_p0.clone()),
        x_p1 => x_p1.clone(),
    }
}

/// ```prism
/// CppCharEscape: fn Text -> Text
/// ```
pub fn cpp_char_escape_f(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("\'")) => Text::lit("\\\'"),
        c_p0 => crate::lower::expr::char_escape_f(c_p0),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// PathValue: fn Cp, Text -> Text
/// ```
pub fn path_value_f(cp_p0: &crate::emit::cpp::Cp, p_p1: &Text) -> Text {
    if is_node_method_f(cp_p0, p_p1) {
        Text::from(format!("&{}::{}", &crate::emit::cpp::type_path_f(&crate::emit::cpp::parent_path_f(p_p1)), &node_method_name_f(cp_p0, &crate::emit::cpp::last_segment_f(p_p1))))
    } else {
        match crate::emit::cpp::case_of_o(cp_p0, p_p1) {
            Some(ty_p2) => Text::from(format!("{}({}{{}})", &crate::emit::cpp::type_path_f(&ty_p2), &crate::emit::cpp::type_path_f(p_p1))),
            None => match crate::emit::cpp::type_of_o(cp_p0, p_p1) {
                Some(info_p3) => if &info_p3.kind_p == &Text::lit("unit") {
                    Text::from(format!("{}{{}}", &crate::emit::cpp::type_path_f(p_p1)))
                } else {
                    crate::emit::cpp::type_path_f(p_p1)
                },
                None => crate::emit::cpp::type_path_f(p_p1),
            },
        }
    }
}

/// ```prism
/// IsNodeMethod: fn Cp, Text -> Bool
/// ```
pub fn is_node_method_f(cp_p0: &crate::emit::cpp::Cp, p_p1: &Text) -> bool {
    let named_p2 = match crate::prelude::get(&cp_p0.methods_p, &crate::emit::cpp::last_segment_f(p_p1)) {
        Some(_) => true,
        None => false,
    };
    named_p2 && is_node_type_f(cp_p0, &crate::emit::cpp::parent_path_f(p_p1))
}

/// ```prism
/// IsNodeType: fn Cp, Text -> Bool
/// ```
pub fn is_node_type_f(cp_p0: &crate::emit::cpp::Cp, p_p1: &Text) -> bool {
    match crate::emit::cpp::type_of_o(cp_p0, p_p1) {
        Some(info_p2) => &info_p2.kind_p == &Text::lit("node"),
        None => false,
    }
}

/// ```prism
/// CppField: unbounded fn Cp, Ex, Text -> Text
/// ```
pub fn cpp_field_f(cp_p0: &crate::emit::cpp::Cp, ex1: &crate::lower::model::Ex, f_p1: &Text) -> Text {
    match ex1 {
        crate::lower::model::Ex::XSelf => Text::from(format!("this->{}", &crate::emit::cpp::field_id_f(f_p1))),
        r_p3 => {
            let name_p5 = if is_digits_f(f_p1) {
                Text::from(format!("a{}", f_p1))
            } else {
                crate::emit::cpp::field_id_f(f_p1)
            };
            match pointer_o(cp_p0, r_p3) {
                Some(b_p6) => Text::from(format!("{}{}{}", &cpp_tight_place_f(cp_p0, r_p3), &(if b_p6 { Text::lit("->") } else { Text::lit(".") }), &name_p5)),
                None => match crate::prelude::get(&cp_p0.members_p, f_p1) {
                    Some(_) => Text::from(format!("{}->{}", &cpp_tight_place_f(cp_p0, r_p3), &name_p5)),
                    None => Text::from(format!("{}.{}", &as_value_f(cp_p0, r_p3), &name_p5)),
                },
            }
        },
    }
}

/// The step machine of `CppField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppField: unbounded fn Cp, Ex, Text -> Text
/// ```
pub struct CppField {
    pub cp_p0: crate::emit::cpp::Cp,
    pub ex1: crate::lower::model::Ex,
    pub f_p1: Text,
}

impl prism_rtl::Job<Text> for CppField {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let ex1 = &self.ex1;
        let f_p1 = &self.f_p1;
        match ex1 {
            crate::lower::model::Ex::XSelf => prism_rtl::Turn::Finished(Text::from(format!("this->{}", &crate::emit::cpp::field_id_f(f_p1)))),
            r_p3 => {
                let name_p5 = if is_digits_f(f_p1) {
                    Text::from(format!("a{}", f_p1))
                } else {
                    crate::emit::cpp::field_id_f(f_p1)
                };
                match pointer_o(cp_p0, r_p3) {
                    Some(b_p6) => {
                        let cp_p0x = cp_p0.clone();
                        let r_p3x = r_p3.clone();
                        crate::prelude::call_then(start_cpp_tight_place_f(cp_p0x.clone(), r_p3x.clone()), move |cpp_tight_place_f_10151: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}{}", &cpp_tight_place_f_10151, &(if b_p6 { Text::lit("->") } else { Text::lit(".") }), &name_p5))))
                    },
                    None => match crate::prelude::get(&cp_p0.members_p, f_p1) {
                        Some(_) => {
                            let cp_p0x = cp_p0.clone();
                            let r_p3x = r_p3.clone();
                            crate::prelude::call_then(start_cpp_tight_place_f(cp_p0x.clone(), r_p3x.clone()), move |cpp_tight_place_f_10259: Text| prism_rtl::Turn::Finished(Text::from(format!("{}->{}", &cpp_tight_place_f_10259, &name_p5))))
                        },
                        None => {
                            let cp_p0x = cp_p0.clone();
                            let r_p3x = r_p3.clone();
                            crate::prelude::call_then(start_as_value_f(cp_p0x.clone(), r_p3x.clone()), move |as_value_f_10308: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.{}", &as_value_f_10308, &name_p5))))
                        },
                    },
                }
            },
        }
    }
}

/// `Start CppField, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_field_f(cp_p0: crate::emit::cpp::Cp, ex1: crate::lower::model::Ex, f_p1: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppField { cp_p0, ex1, f_p1 })
}

/// ```prism
/// AsValue: unbounded fn Cp, Ex -> Text
/// ```
pub fn as_value_f(cp_p0: &crate::emit::cpp::Cp, r_p1: &crate::lower::model::Ex) -> Text {
    match pointer_o(cp_p0, r_p1) {
        Some(false) => cpp_tight_place_f(cp_p0, r_p1),
        _ => Text::from(format!("prism_rtl::deref({})", &cpp_place_f(cp_p0, r_p1))),
    }
}

/// The step machine of `AsValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AsValue: unbounded fn Cp, Ex -> Text
/// ```
pub struct AsValue {
    pub cp_p0: crate::emit::cpp::Cp,
    pub r_p1: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for AsValue {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let r_p1 = &self.r_p1;
        match pointer_o(cp_p0, r_p1) {
            Some(false) => prism_rtl::Turn::More(Rc::new(CppTightPlace { cp_p0: cp_p0.clone(), x_p1: r_p1.clone() })),
            _ => {
                let cp_p0x = cp_p0.clone();
                let r_p1x = r_p1.clone();
                crate::prelude::call_then(start_cpp_place_f(cp_p0x.clone(), r_p1x.clone()), move |cpp_place_f_10591: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::deref({})", &cpp_place_f_10591))))
            },
        }
    }
}

/// `Start AsValue, x`: what the function value is when passed to `@Run`.
pub fn start_as_value_f(cp_p0: crate::emit::cpp::Cp, r_p1: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(AsValue { cp_p0, r_p1 })
}

/// ```prism
/// ?ExTy: fn Cp, Ex -> ?OutTy
/// ```
pub fn ex_ty_o(cp_p0: &crate::emit::cpp::Cp, x_p1: &crate::lower::model::Ex) -> Option<crate::lower::model::OutTy> {
    'm10828: {
        if let crate::lower::model::Ex::XVar(n_p2) = x_p1 {
            break 'm10828 crate::prelude::get(&cp_p0.local_types_p, n_p2);
        }
        if let crate::lower::model::Ex::XField(m10828_1_0, f_p3) = x_p1 && let crate::lower::model::Ex::XSelf = &**m10828_1_0 {
            break 'm10828 crate::prelude::get(&cp_p0.fields_p, f_p3);
        }
        if let crate::lower::model::Ex::XField(m10828_2_0, f_p4) = x_p1 && let crate::lower::model::Ex::XVar(m10828_2_0_r_0) = &**m10828_2_0 && (m10828_2_0_r_0 == &Text::lit("node")) {
            break 'm10828 crate::prelude::get(&cp_p0.fields_p, f_p4);
        }
        if let crate::lower::model::Ex::XRef(y_p5) = x_p1 {
            break 'm10828 match ex_ty_o(cp_p0, &**y_p5) {
                Some(t_p6) => Some(crate::lower::model::OutTy::OutRef(Rc::new(t_p6))),
                None => None,
            };
        }
        if let crate::lower::model::Ex::XDeref(y_p7) = x_p1 {
            break 'm10828 match ex_ty_o(cp_p0, &**y_p7) {
                Some(crate::lower::model::OutTy::OutRef(t_p8)) => Some((*t_p8).clone()),
                Some(crate::lower::model::OutTy::OutRc(t_p9)) => Some((*t_p9).clone()),
                _ => None,
            };
        }
        None
    }
}

/// ```prism
/// IsDigits: fn Text -> Bool
/// ```
pub fn is_digits_f(t_p0: &Text) -> bool {
    (t_p0 != &Text::lit("")) && crate::syntax::lexer::chars::fold_chars_f(t_p0, &true, &(Rc::new(move |(p0, p1): (bool, Text)| crate::prelude::once_job(move || {
        let ok_p1 = p0;
        let c_p2 = p1;
        prism_rtl::Turn::Finished(ok_p1 && crate::syntax::lexer::chars::contains_f(&Text::lit("0123456789"), &c_p2))
    })) as Rc<dyn Fn((bool, Text)) -> Rc<dyn prism_rtl::Job<bool>>>))
}

/// ```prism
/// CppCtor: unbounded fn Cp, Text, [Ex] -> Text
/// ```
pub fn cpp_ctor_f(cp_p0: &crate::emit::cpp::Cp, p_p1: &Text, args_p2: &Array<crate::lower::model::Ex>) -> Text {
    match p_p1 {
        m11460_0 if (m11460_0 == &Text::lit("Some")) => Text::from(format!("std::optional({})", &cpp_args_f(cp_p0, args_p2))),
        m11460_1 if (m11460_1 == &Text::lit("Ok")) => if args_p2 == &Array::from(vec![crate::lower::model::Ex::XUnit]) {
            Text::lit("prism_rtl::ok()")
        } else {
            cpp_args_f(cp_p0, args_p2)
        },
        m11460_2 if (m11460_2 == &Text::lit("Err")) => Text::from(format!("unexpected({})", &cpp_args_f(cp_p0, args_p2))),
        m11460_3 if (m11460_3 == &Text::lit("prism_rtl::Turn::More")) => Text::from(format!("prism_rtl::more({})", &cpp_args_f(cp_p0, args_p2))),
        m11460_4 if (m11460_4 == &Text::lit("prism_rtl::Turn::Finished")) => Text::from(format!("prism_rtl::finished({})", &cpp_args_f(cp_p0, args_p2))),
        m11460_5 if (m11460_5 == &Text::lit("Outcome::Fired")) => Text::from(format!("Outcome::fired({})", &cpp_args_f(cp_p0, args_p2))),
        m11460_6 if (m11460_6 == &Text::lit("Outcome::Value")) => Text::from(format!("Outcome::value({})", &cpp_args_f(cp_p0, args_p2))),
        m11460_7 if (m11460_7 == &Text::lit("Segment::Pos")) => Text::from(format!("Segment::pos({})", &cpp_args_f(cp_p0, args_p2))),
        m11460_8 if (m11460_8 == &Text::lit("Segment::Gen")) => Text::from(format!("Segment::gen({})", &cpp_args_f(cp_p0, args_p2))),
        m11460_9 if (m11460_9 == &Text::lit("Segment::Key")) => Text::from(format!("Segment::key({})", &cpp_args_f(cp_p0, args_p2))),
        _ => match crate::emit::cpp::case_of_o(cp_p0, p_p1) {
            Some(ty_p3) => Text::from(format!("{}({}{{{}}})", &crate::emit::cpp::type_path_f(&ty_p3), &crate::emit::cpp::type_path_f(p_p1), &cpp_args_f(cp_p0, args_p2))),
            None => Text::from(format!("{}{{{}}}", &crate::emit::cpp::type_path_f(p_p1), &cpp_args_f(cp_p0, args_p2))),
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CppCtor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppCtor: unbounded fn Cp, Text, [Ex] -> Text
/// ```
pub struct CppCtor {
    pub cp_p0: crate::emit::cpp::Cp,
    pub p_p1: Text,
    pub args_p2: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for CppCtor {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let p_p1 = &self.p_p1;
        let args_p2 = &self.args_p2;
        match p_p1 {
            m11460_0 if (m11460_0 == &Text::lit("Some")) => {
                let args_p2x = args_p2.clone();
                let cp_p0x = cp_p0.clone();
                crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p2x.clone()), move |cpp_args_f_11497: Text| prism_rtl::Turn::Finished(Text::from(format!("std::optional({})", &cpp_args_f_11497))))
            },
            m11460_1 if (m11460_1 == &Text::lit("Ok")) => if args_p2 == &Array::from(vec![crate::lower::model::Ex::XUnit]) {
                prism_rtl::Turn::Finished(Text::lit("prism_rtl::ok()"))
            } else {
                prism_rtl::Turn::More(Rc::new(CppArgs { cp_p0: cp_p0.clone(), xs_p1: args_p2.clone() }))
            },
            m11460_2 if (m11460_2 == &Text::lit("Err")) => {
                let args_p2x = args_p2.clone();
                let cp_p0x = cp_p0.clone();
                crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p2x.clone()), move |cpp_args_f_11614: Text| prism_rtl::Turn::Finished(Text::from(format!("unexpected({})", &cpp_args_f_11614))))
            },
            m11460_3 if (m11460_3 == &Text::lit("prism_rtl::Turn::More")) => {
                let args_p2x = args_p2.clone();
                let cp_p0x = cp_p0.clone();
                crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p2x.clone()), move |cpp_args_f_11681: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::more({})", &cpp_args_f_11681))))
            },
            m11460_4 if (m11460_4 == &Text::lit("prism_rtl::Turn::Finished")) => {
                let args_p2x = args_p2.clone();
                let cp_p0x = cp_p0.clone();
                crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p2x.clone()), move |cpp_args_f_11756: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::finished({})", &cpp_args_f_11756))))
            },
            m11460_5 if (m11460_5 == &Text::lit("Outcome::Fired")) => {
                let args_p2x = args_p2.clone();
                let cp_p0x = cp_p0.clone();
                crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p2x.clone()), move |cpp_args_f_11815: Text| prism_rtl::Turn::Finished(Text::from(format!("Outcome::fired({})", &cpp_args_f_11815))))
            },
            m11460_6 if (m11460_6 == &Text::lit("Outcome::Value")) => {
                let args_p2x = args_p2.clone();
                let cp_p0x = cp_p0.clone();
                crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p2x.clone()), move |cpp_args_f_11874: Text| prism_rtl::Turn::Finished(Text::from(format!("Outcome::value({})", &cpp_args_f_11874))))
            },
            m11460_7 if (m11460_7 == &Text::lit("Segment::Pos")) => {
                let args_p2x = args_p2.clone();
                let cp_p0x = cp_p0.clone();
                crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p2x.clone()), move |cpp_args_f_11929: Text| prism_rtl::Turn::Finished(Text::from(format!("Segment::pos({})", &cpp_args_f_11929))))
            },
            m11460_8 if (m11460_8 == &Text::lit("Segment::Gen")) => {
                let args_p2x = args_p2.clone();
                let cp_p0x = cp_p0.clone();
                crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p2x.clone()), move |cpp_args_f_11984: Text| prism_rtl::Turn::Finished(Text::from(format!("Segment::gen({})", &cpp_args_f_11984))))
            },
            m11460_9 if (m11460_9 == &Text::lit("Segment::Key")) => {
                let args_p2x = args_p2.clone();
                let cp_p0x = cp_p0.clone();
                crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p2x.clone()), move |cpp_args_f_12039: Text| prism_rtl::Turn::Finished(Text::from(format!("Segment::key({})", &cpp_args_f_12039))))
            },
            _ => match crate::emit::cpp::case_of_o(cp_p0, p_p1) {
                Some(ty_p3) => {
                    let args_p2x = args_p2.clone();
                    let cp_p0x = cp_p0.clone();
                    let p_p1x = p_p1.clone();
                    crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p2x.clone()), move |cpp_args_f_12139: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({}{{{}}})", &crate::emit::cpp::type_path_f(&ty_p3), &crate::emit::cpp::type_path_f(&p_p1x), &cpp_args_f_12139))))
                },
                None => {
                    let args_p2x = args_p2.clone();
                    let cp_p0x = cp_p0.clone();
                    let p_p1x = p_p1.clone();
                    crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p2x.clone()), move |cpp_args_f_12190: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{{{}}}", &crate::emit::cpp::type_path_f(&p_p1x), &cpp_args_f_12190))))
                },
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start CppCtor, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_ctor_f(cp_p0: crate::emit::cpp::Cp, p_p1: Text, args_p2: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppCtor { cp_p0, p_p1, args_p2 })
}

/// ```prism
/// CppRecord: unbounded fn Cp, Text, [((Text, Ex))] -> Text
/// ```
pub fn cpp_record_f(cp_p0: &crate::emit::cpp::Cp, p_p1: &Text, fs_p2: &Array<(Text, crate::lower::model::Ex)>) -> Text {
    let ordered_p3 = match crate::emit::cpp::type_of_o(cp_p0, p_p1) {
        Some(info_p7) => crate::prelude::each(&info_p7.fields_p, &(|f_p8: &Text| crate::prelude::or(&crate::prelude::fold(fs_p2, &None, &(|found_o9: &Option<crate::lower::model::Ex>, (g_pa, v_pb): &(Text, crate::lower::model::Ex)| if g_pa == f_p8 { Some(v_pb.clone()) } else { found_o9.clone() })), &crate::lower::model::Ex::XUnit))),
        None => crate::prelude::each(fs_p2, &(|(_, v_pc): &(Text, crate::lower::model::Ex)| v_pc.clone())),
    };
    let names_p4 = match crate::emit::cpp::type_of_o(cp_p0, p_p1) {
        Some(info_pd) => info_pd.fields_p.clone(),
        None => crate::prelude::each(fs_p2, &(|(g_pe, _): &(Text, crate::lower::model::Ex)| g_pe.clone())),
    };
    let kind_p5 = match crate::emit::cpp::type_of_o(cp_p0, p_p1) {
        Some(info_pf) => info_pf.kind_p.clone(),
        None => Text::lit(""),
    };
    let values_p6 = cpp_arg_list_f(cp_p0, &ordered_p3);
    if &kind_p5 == &Text::lit("job") {
        Text::from(format!("{}({})", &crate::emit::cpp::type_path_f(p_p1), &crate::syntax::lexer::chars::join_f(&values_p6, &Text::lit(", "))))
    } else {
        Text::from(format!("{}{{{}}}", &crate::emit::cpp::type_path_f(p_p1), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&names_p4)), &(|i_pg: &Nat| Text::from(format!(".{} = {}", &crate::emit::cpp::field_id_f(&crate::prelude::or(&crate::prelude::index(&names_p4, i_pg), &Text::lit(""))), &crate::prelude::or(&crate::prelude::index(&values_p6, i_pg), &Text::lit("")))))), &Text::lit(", "))))
    }
}

/// The step machine of `CppRecord`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppRecord: unbounded fn Cp, Text, [((Text, Ex))] -> Text
/// ```
pub struct CppRecord {
    pub cp_p0: crate::emit::cpp::Cp,
    pub p_p1: Text,
    pub fs_p2: Array<(Text, crate::lower::model::Ex)>,
}

impl prism_rtl::Job<Text> for CppRecord {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let p_p1 = &self.p_p1;
        let fs_p2 = &self.fs_p2;
        let ordered_p3 = match crate::emit::cpp::type_of_o(cp_p0, p_p1) {
            Some(info_p7) => crate::prelude::each(&info_p7.fields_p, &(|f_p8: &Text| crate::prelude::or(&crate::prelude::fold(fs_p2, &None, &(|found_o9: &Option<crate::lower::model::Ex>, (g_pa, v_pb): &(Text, crate::lower::model::Ex)| if g_pa == f_p8 { Some(v_pb.clone()) } else { found_o9.clone() })), &crate::lower::model::Ex::XUnit))),
            None => crate::prelude::each(fs_p2, &(|(_, v_pc): &(Text, crate::lower::model::Ex)| v_pc.clone())),
        };
        let names_p4 = match crate::emit::cpp::type_of_o(cp_p0, p_p1) {
            Some(info_pd) => info_pd.fields_p.clone(),
            None => crate::prelude::each(fs_p2, &(|(g_pe, _): &(Text, crate::lower::model::Ex)| g_pe.clone())),
        };
        let kind_p5 = match crate::emit::cpp::type_of_o(cp_p0, p_p1) {
            Some(info_pf) => info_pf.kind_p.clone(),
            None => Text::lit(""),
        };
        let cp_p0x = cp_p0.clone();
        let p_p1x = p_p1.clone();
        crate::prelude::call_then(start_cpp_arg_list_f(cp_p0x.clone(), ordered_p3.clone()), move |cpp_arg_list_f_12789: Array<Text>| {
            let values_p6 = cpp_arg_list_f_12789;
            if &kind_p5 == &Text::lit("job") {
                prism_rtl::Turn::Finished(Text::from(format!("{}({})", &crate::emit::cpp::type_path_f(&p_p1x), &crate::syntax::lexer::chars::join_f(&values_p6, &Text::lit(", ")))))
            } else {
                prism_rtl::Turn::Finished(Text::from(format!("{}{{{}}}", &crate::emit::cpp::type_path_f(&p_p1x), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&names_p4)), &(|i_pg: &Nat| Text::from(format!(".{} = {}", &crate::emit::cpp::field_id_f(&crate::prelude::or(&crate::prelude::index(&names_p4, i_pg), &Text::lit(""))), &crate::prelude::or(&crate::prelude::index(&values_p6, i_pg), &Text::lit("")))))), &Text::lit(", ")))))
            }
        })
    }
}

/// `Start CppRecord, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_record_f(cp_p0: crate::emit::cpp::Cp, p_p1: Text, fs_p2: Array<(Text, crate::lower::model::Ex)>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppRecord { cp_p0, p_p1, fs_p2 })
}

/// ```prism
/// CppCall: unbounded fn Cp, Text, [Ex] -> Text
/// ```
pub fn cpp_call_f(cp_p0: &crate::emit::cpp::Cp, f_p1: &Text, args_p2: &Array<crate::lower::model::Ex>) -> Text {
    let a_p3 = cpp_args_f(cp_p0, args_p2);
    match crate::syntax::lexer::chars::drop_prefix_f(f_p1, &Text::lit("crate::prelude::")) {
        m13234_0 if (&m13234_0 == &Text::lit("Rc::new")) => if &a_p3 == &Text::lit("{}") {
            Text::lit("prism_rtl::make_new()")
        } else {
            Text::from(format!("prism_rtl::rc({})", &a_p3))
        },
        m13234_1 if (&m13234_1 == &Text::lit("is_some")) => Text::from(format!("prism_rtl::is_some({})", &a_p3)),
        m13234_2 if (&m13234_2 == &Text::lit("is_none")) => Text::from(format!("prism_rtl::is_none({})", &a_p3)),
        m13234_3 if (&m13234_3 == &Text::lit("RefCell::new")) => a_p3.clone(),
        m13234_4 if (&m13234_4 == &Text::lit("Cell::new")) => a_p3.clone(),
        m13234_5 if (&m13234_5 == &Text::lit("Hold::new")) => Text::from(format!("{{{}}}", &a_p3)),
        m13234_6 if (&m13234_6 == &Text::lit("Snapshot::new")) => Text::from(format!("snapshot({})", &a_p3)),
        m13234_7 if (&m13234_7 == &Text::lit("Path::root")) => Text::lit("Path::root()"),
        m13234_8 if (&m13234_8 == &Text::lit("Fault::answer")) => Text::from(format!("Fault::answer({})", &a_p3)),
        m13234_9 if (&m13234_9 == &Text::lit("Fault::too_deep")) => Text::from(format!("Fault::too_deep({})", &a_p3)),
        m13234_10 if (&m13234_10 == &Text::lit("Error::new")) => Text::from(format!("Error({})", &a_p3)),
        m13234_11 if (&m13234_11 == &Text::lit("Text::from")) => Text::from(format!("Text({})", &a_p3)),
        m13234_12 if (&m13234_12 == &Text::lit("String::new")) => Text::lit("std::string()"),
        m13234_13 if (&m13234_13 == &Text::lit("Array::from")) => Text::from(format!("Array({})", &a_p3)),
        m13234_14 if (&m13234_14 == &Text::lit("prism_rtl::Dynamic::of")) => Text::from(format!("prism_rtl::dynamic_of({})", &a_p3)),
        m13234_15 if (&m13234_15 == &Text::lit("Dynamic::of")) => Text::from(format!("prism_rtl::dynamic_of({})", &a_p3)),
        m13234_16 if (&m13234_16 == &Text::lit("prism_rtl::Event::of")) => Text::from(format!("prism_rtl::event_of({})", &a_p3)),
        m13234_17 if (&m13234_17 == &Text::lit("prism_rtl::Host::new")) => Text::from(format!("host_new({})", &a_p3)),
        m13234_18 if (&m13234_18 == &Text::lit("prism_rtl::Entry::new")) => Text::from(format!("entry_new({})", &a_p3)),
        m13234_19 if (&m13234_19 == &Text::lit("prism_rtl::forward_on_none")) => Text::from(format!("prism_rtl::forward_on_none<crate::Elem, crate::Answer>({})", &a_p3)),
        m13234_20 if (&m13234_20 == &Text::lit("Event::never")) => Text::lit("prism_rtl::never_event()"),
        _ => if is_fresh_f(f_p1) {
            Text::lit("{}")
        } else {
            Text::from(format!("{}({})", &free_call_path_f(cp_p0, f_p1), &a_p3))
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CppCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppCall: unbounded fn Cp, Text, [Ex] -> Text
/// ```
pub struct CppCall {
    pub cp_p0: crate::emit::cpp::Cp,
    pub f_p1: Text,
    pub args_p2: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for CppCall {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let f_p1 = &self.f_p1;
        let args_p2 = &self.args_p2;
        let args_p2x = args_p2.clone();
        let cp_p0x = cp_p0.clone();
        let f_p1x = f_p1.clone();
        crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p2x.clone()), move |cpp_args_f_13213: Text| {
            let a_p3 = cpp_args_f_13213;
            match crate::syntax::lexer::chars::drop_prefix_f(&f_p1x, &Text::lit("crate::prelude::")) {
                m13234_0 if (&m13234_0 == &Text::lit("Rc::new")) => if &a_p3 == &Text::lit("{}") {
                    prism_rtl::Turn::Finished(Text::lit("prism_rtl::make_new()"))
                } else {
                    prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::rc({})", &a_p3)))
                },
                m13234_1 if (&m13234_1 == &Text::lit("is_some")) => prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::is_some({})", &a_p3))),
                m13234_2 if (&m13234_2 == &Text::lit("is_none")) => prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::is_none({})", &a_p3))),
                m13234_3 if (&m13234_3 == &Text::lit("RefCell::new")) => prism_rtl::Turn::Finished(a_p3.clone()),
                m13234_4 if (&m13234_4 == &Text::lit("Cell::new")) => prism_rtl::Turn::Finished(a_p3.clone()),
                m13234_5 if (&m13234_5 == &Text::lit("Hold::new")) => prism_rtl::Turn::Finished(Text::from(format!("{{{}}}", &a_p3))),
                m13234_6 if (&m13234_6 == &Text::lit("Snapshot::new")) => prism_rtl::Turn::Finished(Text::from(format!("snapshot({})", &a_p3))),
                m13234_7 if (&m13234_7 == &Text::lit("Path::root")) => prism_rtl::Turn::Finished(Text::lit("Path::root()")),
                m13234_8 if (&m13234_8 == &Text::lit("Fault::answer")) => prism_rtl::Turn::Finished(Text::from(format!("Fault::answer({})", &a_p3))),
                m13234_9 if (&m13234_9 == &Text::lit("Fault::too_deep")) => prism_rtl::Turn::Finished(Text::from(format!("Fault::too_deep({})", &a_p3))),
                m13234_10 if (&m13234_10 == &Text::lit("Error::new")) => prism_rtl::Turn::Finished(Text::from(format!("Error({})", &a_p3))),
                m13234_11 if (&m13234_11 == &Text::lit("Text::from")) => prism_rtl::Turn::Finished(Text::from(format!("Text({})", &a_p3))),
                m13234_12 if (&m13234_12 == &Text::lit("String::new")) => prism_rtl::Turn::Finished(Text::lit("std::string()")),
                m13234_13 if (&m13234_13 == &Text::lit("Array::from")) => prism_rtl::Turn::Finished(Text::from(format!("Array({})", &a_p3))),
                m13234_14 if (&m13234_14 == &Text::lit("prism_rtl::Dynamic::of")) => prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::dynamic_of({})", &a_p3))),
                m13234_15 if (&m13234_15 == &Text::lit("Dynamic::of")) => prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::dynamic_of({})", &a_p3))),
                m13234_16 if (&m13234_16 == &Text::lit("prism_rtl::Event::of")) => prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::event_of({})", &a_p3))),
                m13234_17 if (&m13234_17 == &Text::lit("prism_rtl::Host::new")) => prism_rtl::Turn::Finished(Text::from(format!("host_new({})", &a_p3))),
                m13234_18 if (&m13234_18 == &Text::lit("prism_rtl::Entry::new")) => prism_rtl::Turn::Finished(Text::from(format!("entry_new({})", &a_p3))),
                m13234_19 if (&m13234_19 == &Text::lit("prism_rtl::forward_on_none")) => prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::forward_on_none<crate::Elem, crate::Answer>({})", &a_p3))),
                m13234_20 if (&m13234_20 == &Text::lit("Event::never")) => prism_rtl::Turn::Finished(Text::lit("prism_rtl::never_event()")),
                _ => if is_fresh_f(&f_p1x) {
                    prism_rtl::Turn::Finished(Text::lit("{}"))
                } else {
                    prism_rtl::Turn::Finished(Text::from(format!("{}({})", &free_call_path_f(&cp_p0x, &f_p1x), &a_p3)))
                },
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start CppCall, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_call_f(cp_p0: crate::emit::cpp::Cp, f_p1: Text, args_p2: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppCall { cp_p0, f_p1, args_p2 })
}

/// ```prism
/// FreeCallPath: fn Cp, Text -> Text
/// ```
pub fn free_call_path_f(cp_p0: &crate::emit::cpp::Cp, f_p1: &Text) -> Text {
    let p_p2 = call_path_f(f_p1);
    let hidden_p3 = match crate::prelude::get(&cp_p0.members_p, f_p1) {
        Some(_) => true,
        None => crate::emit::cpp::in_list_f(&std_names_p(), &p_p2) || crate::emit::cpp::in_list_f(&cp_p0.mods_p, &p_p2),
    };
    if crate::syntax::lexer::chars::contains_f(&p_p2, &Text::lit(":")) {
        p_p2.clone()
    } else {
        if hidden_p3 { qualified_call_f(cp_p0, f_p1, &p_p2) } else { p_p2.clone() }
    }
}

/// ```prism
/// QualifiedCall: fn Cp, Text, Text -> Text
/// ```
pub fn qualified_call_f(cp_p0: &crate::emit::cpp::Cp, f_p1: &Text, p_p2: &Text) -> Text {
    match crate::prelude::get(&cp_p0.fns_p, &Text::from(format!("{}::{}", &cp_p0.home_p, f_p1))) {
        Some(_) => Text::from(format!("crate::{}::{}", &cp_p0.home_p, p_p2)),
        None => Text::from(format!("crate::prelude::{}", p_p2)),
    }
}

/// ```prism
/// let stdNames
/// ```
pub fn std_names_p() -> Array<Text> {
    Array::from(vec![Text::lit("apply"), Text::lit("begin"), Text::lit("end"), Text::lit("size"), Text::lit("empty"), Text::lit("data"), Text::lit("get"), Text::lit("swap"), Text::lit("move"), Text::lit("forward"), Text::lit("find"), Text::lit("count"), Text::lit("copy"), Text::lit("fill"), Text::lit("sort"), Text::lit("min"), Text::lit("max"), Text::lit("visit"), Text::lit("invoke"), Text::lit("merge"), Text::lit("remove"), Text::lit("replace"), Text::lit("reverse"), Text::lit("unique"), Text::lit("transform"), Text::lit("accumulate"), Text::lit("distance"), Text::lit("next"), Text::lit("prev"), Text::lit("exchange"), Text::lit("tie"), Text::lit("to_string"), Text::lit("clamp"), Text::lit("partition"), Text::lit("equal"), Text::lit("mismatch"), Text::lit("erase"), Text::lit("search"), Text::lit("rotate")])
}

/// ```prism
/// IsFresh: fn Text -> Bool
/// ```
pub fn is_fresh_f(f_p0: &Text) -> bool {
    crate::emit::cpp::in_list_f(&Array::from(vec![Text::lit("Stamped::new"), Text::lit("Cache::new"), Text::lit("Port::new"), Text::lit("Map::new"), Text::lit("Array::new"), Text::lit("Vec::new"), Text::lit("Default::default"), Text::lit("Wakes::default"), Text::lit("Defer::new"), Text::lit("prism_rtl::HostDoc::new"), Text::lit("prism_rtl::Watch::new"), Text::lit("prism_rtl::PerKey::new")]), f_p0)
}

/// ```prism
/// CallPath: fn Text -> Text
/// ```
pub fn call_path_f(f_p0: &Text) -> Text {
    let last_p1 = crate::emit::cpp::last_segment_f(f_p0);
    let owner_p2 = crate::emit::cpp::last_segment_f(&crate::emit::cpp::parent_path_f(f_p0));
    let is_type_p3 = (&crate::emit::cpp::parent_path_f(f_p0) != &Text::lit("")) && crate::syntax::lexer::chars::contains_f(&Text::lit("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), &crate::syntax::lexer::chars::head_f(&owner_p2));
    if (&last_p1 == &Text::lit("build")) && is_type_p3 {
        Text::from(format!("{}::make", &crate::emit::cpp::type_path_f(&crate::emit::cpp::parent_path_f(f_p0))))
    } else {
        if &last_p1 == &Text::lit("new") {
            crate::emit::cpp::type_path_f(&crate::emit::cpp::parent_path_f(f_p0))
        } else {
            crate::emit::cpp::cpp_path_id_f(&crate::emit::cpp::type_path_f(f_p0))
        }
    }
}

/// ```prism
/// CppMethod: unbounded fn Cp, Ex, Text, [Ex] -> Text
/// ```
pub fn cpp_method_f(cp_p0: &crate::emit::cpp::Cp, r_p1: &crate::lower::model::Ex, m_p2: &Text, args_p3: &Array<crate::lower::model::Ex>) -> Text {
    let recv_p4 = if r_p1 == &crate::lower::model::Ex::XSelf {
        Text::lit("this")
    } else {
        cpp_tight_place_f(cp_p0, r_p1)
    };
    let a_p5 = cpp_args_f(cp_p0, args_p3);
    let n_p6 = crate::prelude::len(args_p3);
    let sep_p7 = if &n_p6 == &Nat::from(0u32) { Text::lit("") } else { Text::lit(", ") };
    match method_form_f(m_p2, &n_p6) {
        m16645_0 if (&m16645_0 == &Text::lit("id")) => recv_p4.clone(),
        m16645_1 if (&m16645_1 == &Text::lit("deref")) => match pointer_o(cp_p0, r_p1) {
            Some(b_p8) => if b_p8 { Text::from(format!("(*{})", &recv_p4)) } else { recv_p4.clone() },
            None => recv_p4.clone(),
        },
        m16645_2 if (&m16645_2 == &Text::lit("assign")) => Text::from(format!("{} = {}", &recv_p4, &a_p5)),
        m16645_3 if (&m16645_3 == &Text::lit("take")) => Text::from(format!("std::exchange({}, {{}})", &recv_p4)),
        m16645_4 if (&m16645_4 == &Text::lit("free")) => Text::from(format!("{}({}{}{})", &free_name_f(m_p2), &recv_p4, &sep_p7, &a_p5)),
        m16645_5 if (&m16645_5 == &Text::lit("arrow")) => {
            let through_p9 = match pointer_o(cp_p0, r_p1) {
                Some(b_pa) => if b_pa { Text::lit("->") } else { Text::lit(".") },
                None => Text::lit("->"),
            };
            Text::from(format!("{}{}{}({})", &recv_p4, &through_p9, &member_name_f(m_p2), &a_p5))
        },
        m16645_6 if (&m16645_6 == &Text::lit("exchange")) => Text::from(format!("std::exchange({}, {})", &recv_p4, &a_p5)),
        _ => {
            let through_pb = match pointer_o(cp_p0, r_p1) {
                Some(b_pc) => if b_pc { Text::lit("->") } else { Text::lit(".") },
                None => match crate::prelude::get(&cp_p0.members_p, m_p2) {
                    Some(_) => Text::lit("->"),
                    None => Text::lit("."),
                },
            };
            Text::from(format!("{}{}{}({})", &recv_p4, &through_pb, &node_method_name_f(cp_p0, m_p2), &a_p5))
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CppMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppMethod: unbounded fn Cp, Ex, Text, [Ex] -> Text
/// ```
pub struct CppMethod {
    pub cp_p0: crate::emit::cpp::Cp,
    pub r_p1: crate::lower::model::Ex,
    pub m_p2: Text,
    pub args_p3: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for CppMethod {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let r_p1 = &self.r_p1;
        let m_p2 = &self.m_p2;
        let args_p3 = &self.args_p3;
        let recv_p4 = if r_p1 == &crate::lower::model::Ex::XSelf {
            Text::lit("this")
        } else {
            cpp_tight_place_f(cp_p0, r_p1)
        };
        let args_p3x = args_p3.clone();
        let cp_p0x = cp_p0.clone();
        let m_p2x = m_p2.clone();
        let r_p1x = r_p1.clone();
        crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p3x.clone()), move |cpp_args_f_16564: Text| {
            let a_p5 = cpp_args_f_16564;
            let n_p6 = crate::prelude::len(&args_p3x);
            let sep_p7 = if &n_p6 == &Nat::from(0u32) { Text::lit("") } else { Text::lit(", ") };
            match method_form_f(&m_p2x, &n_p6) {
                m16645_0 if (&m16645_0 == &Text::lit("id")) => prism_rtl::Turn::Finished(recv_p4.clone()),
                m16645_1 if (&m16645_1 == &Text::lit("deref")) => match pointer_o(&cp_p0x, &r_p1x) {
                    Some(b_p8) => if b_p8 {
                        prism_rtl::Turn::Finished(Text::from(format!("(*{})", &recv_p4)))
                    } else {
                        prism_rtl::Turn::Finished(recv_p4.clone())
                    },
                    None => prism_rtl::Turn::Finished(recv_p4.clone()),
                },
                m16645_2 if (&m16645_2 == &Text::lit("assign")) => prism_rtl::Turn::Finished(Text::from(format!("{} = {}", &recv_p4, &a_p5))),
                m16645_3 if (&m16645_3 == &Text::lit("take")) => prism_rtl::Turn::Finished(Text::from(format!("std::exchange({}, {{}})", &recv_p4))),
                m16645_4 if (&m16645_4 == &Text::lit("free")) => prism_rtl::Turn::Finished(Text::from(format!("{}({}{}{})", &free_name_f(&m_p2x), &recv_p4, &sep_p7, &a_p5))),
                m16645_5 if (&m16645_5 == &Text::lit("arrow")) => {
                    let through_p9 = match pointer_o(&cp_p0x, &r_p1x) {
                        Some(b_pa) => if b_pa { Text::lit("->") } else { Text::lit(".") },
                        None => Text::lit("->"),
                    };
                    prism_rtl::Turn::Finished(Text::from(format!("{}{}{}({})", &recv_p4, &through_p9, &member_name_f(&m_p2x), &a_p5)))
                },
                m16645_6 if (&m16645_6 == &Text::lit("exchange")) => prism_rtl::Turn::Finished(Text::from(format!("std::exchange({}, {})", &recv_p4, &a_p5))),
                _ => {
                    let through_pb = match pointer_o(&cp_p0x, &r_p1x) {
                        Some(b_pc) => if b_pc { Text::lit("->") } else { Text::lit(".") },
                        None => match crate::prelude::get(&cp_p0x.members_p, &m_p2x) {
                            Some(_) => Text::lit("->"),
                            None => Text::lit("."),
                        },
                    };
                    prism_rtl::Turn::Finished(Text::from(format!("{}{}{}({})", &recv_p4, &through_pb, &node_method_name_f(&cp_p0x, &m_p2x), &a_p5)))
                },
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start CppMethod, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_method_f(cp_p0: crate::emit::cpp::Cp, r_p1: crate::lower::model::Ex, m_p2: Text, args_p3: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppMethod { cp_p0, r_p1, m_p2, args_p3 })
}

/// ```prism
/// NodeMethodName: fn Cp, Text -> Text
/// ```
pub fn node_method_name_f(cp_p0: &crate::emit::cpp::Cp, m_p1: &Text) -> Text {
    match (crate::prelude::get(&cp_p0.methods_p, m_p1), crate::prelude::get(&cp_p0.field_names_p, m_p1)) {
        (Some(_), Some(_)) => Text::from(format!("{}_", &crate::emit::cpp::cpp_id_f(m_p1))),
        _ => member_name_f(m_p1),
    }
}

/// ```prism
/// ?Pointer: fn Cp, Ex -> ?Bool
/// ```
pub fn pointer_o(cp_p0: &crate::emit::cpp::Cp, r_p1: &crate::lower::model::Ex) -> Option<bool> {
    'm18161: {
        if let crate::lower::model::Ex::XSelf = r_p1 {
            break 'm18161 Some(true);
        }
        if let crate::lower::model::Ex::XCx = r_p1 {
            break 'm18161 Some(false);
        }
        if let crate::lower::model::Ex::XVar(m18161_2_0) = r_p1 && (m18161_2_0 == &Text::lit("path")) {
            break 'm18161 Some(false);
        }
        if let crate::lower::model::Ex::XField(_, m18161_3_1) = r_p1 && (m18161_3_1 == &Text::lit("path")) {
            break 'm18161 Some(false);
        }
        if let crate::lower::model::Ex::XCall(m18161_4_0, _) = r_p1 && (m18161_4_0 == &Text::lit("Path::root")) {
            break 'm18161 Some(false);
        }
        if let crate::lower::model::Ex::XMethod(y_p2, m_p3, _) = r_p1 && (((m_p3 == &Text::lit("at")) || (m_p3 == &Text::lit("child"))) || (m_p3 == &Text::lit("join"))) {
            break 'm18161 match pointer_o(cp_p0, &**y_p2) {
                Some(false) => Some(false),
                _ => None,
            };
        }
        if let crate::lower::model::Ex::XVar(n_p4) = r_p1 {
            break 'm18161 crate::prelude::get(&cp_p0.pointers_p, n_p4);
        }
        if let crate::lower::model::Ex::XClone(y_p5) = r_p1 {
            break 'm18161 pointer_o(cp_p0, &**y_p5);
        }
        if let crate::lower::model::Ex::XRef(y_p6) = r_p1 {
            break 'm18161 pointer_o(cp_p0, &**y_p6);
        }
        if let crate::lower::model::Ex::XDeref(y_p7) = r_p1 {
            break 'm18161 match ex_ty_o(cp_p0, r_p1) {
                Some(t_p8) => Some(is_pointer_ty_f(cp_p0, &unref_f(&t_p8))),
                None => None,
            };
        }
        if let crate::lower::model::Ex::XField(m18161_10_0, f_p9) = r_p1 && let crate::lower::model::Ex::XSelf = &**m18161_10_0 {
            break 'm18161 match crate::prelude::get(&cp_p0.fields_p, f_p9) {
                Some(t_pa) => Some(is_pointer_ty_f(cp_p0, &t_pa)),
                None => None,
            };
        }
        if let crate::lower::model::Ex::XField(m18161_11_0, f_pb) = r_p1 && let crate::lower::model::Ex::XVar(m18161_11_0_r_0) = &**m18161_11_0 && (m18161_11_0_r_0 == &Text::lit("node")) {
            break 'm18161 match crate::prelude::get(&cp_p0.fields_p, f_pb) {
                Some(t_pc) => Some(is_pointer_ty_f(cp_p0, &t_pc)),
                None => None,
            };
        }
        None
    }
}

/// ```prism
/// IsPointerTy: fn Cp, OutTy -> Bool
/// ```
pub fn is_pointer_ty_f(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::OutTy) -> bool {
    match t_p1 {
        crate::lower::model::OutTy::OutNamed(m19005_0_0, _) if (m19005_0_0 == &Text::lit("prism_rtl::Rows")) => true,
        crate::lower::model::OutTy::OutPort(_) => false,
        crate::lower::model::OutTy::OutRc(_) => true,
        crate::lower::model::OutTy::OutObj(_) => true,
        crate::lower::model::OutTy::OutJob(_) => true,
        crate::lower::model::OutTy::OutShowAny => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// MethodForm: fn Text, Nat -> Text
/// ```
pub fn method_form_f(m_p0: &Text, n_p1: &Nat) -> Text {
    match (m_p0.clone(), n_p1.clone()) {
        (m19532_0_0, m19532_0_1) if (&m19532_0_0 == &Text::lit("borrow")) && (&m19532_0_1 == &Nat::from(0u32)) => Text::lit("deref"),
        (m19532_1_0, m19532_1_1) if (&m19532_1_0 == &Text::lit("borrow_mut")) && (&m19532_1_1 == &Nat::from(0u32)) => Text::lit("deref"),
        (m19532_2_0, m19532_2_1) if (&m19532_2_0 == &Text::lit("clone")) && (&m19532_2_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m19532_3_0, m19532_3_1) if (&m19532_3_0 == &Text::lit("iter")) && (&m19532_3_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m19532_4_0, m19532_4_1) if (&m19532_4_0 == &Text::lit("collect")) && (&m19532_4_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m19532_5_0, m19532_5_1) if (&m19532_5_0 == &Text::lit("unwrap_or_default")) && (&m19532_5_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19532_6_0, m19532_6_1) if (&m19532_6_0 == &Text::lit("for_each")) && (&m19532_6_1 == &Nat::from(1u32)) => Text::lit("free"),
        (m19532_7_0, m19532_7_1) if (&m19532_7_0 == &Text::lit("into_iter")) && (&m19532_7_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m19532_8_0, m19532_8_1) if (&m19532_8_0 == &Text::lit("as_ref")) && (&m19532_8_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m19532_9_0, m19532_9_1) if (&m19532_9_0 == &Text::lit("get")) && (&m19532_9_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m19532_10_0, m19532_10_1) if (&m19532_10_0 == &Text::lit("set")) && (&m19532_10_1 == &Nat::from(1u32)) => Text::lit("assign"),
        (m19532_11_0, m19532_11_1) if (&m19532_11_0 == &Text::lit("take")) && (&m19532_11_1 == &Nat::from(0u32)) => Text::lit("take"),
        (m19532_12_0, m19532_12_1) if (&m19532_12_0 == &Text::lit("replace")) && (&m19532_12_1 == &Nat::from(1u32)) => Text::lit("exchange"),
        (m19532_13_0, m19532_13_1) if (&m19532_13_0 == &Text::lit("values")) && (&m19532_13_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19532_14_0, m19532_14_1) if (&m19532_14_0 == &Text::lit("keys")) && (&m19532_14_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19532_15_0, m19532_15_1) if (&m19532_15_0 == &Text::lit("enumerate")) && (&m19532_15_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19532_16_0, m19532_16_1) if (&m19532_16_0 == &Text::lit("fire")) && (&m19532_16_1 == &Nat::from(2u32)) => Text::lit("arrow"),
        (m19532_17_0, m19532_17_1) if (&m19532_17_0 == &Text::lit("subscribe")) && (&m19532_17_1 == &Nat::from(1u32)) => Text::lit("arrow"),
        (m19532_18_0, m19532_18_1) if (&m19532_18_0 == &Text::lit("unsubscribe")) && (&m19532_18_1 == &Nat::from(1u32)) => Text::lit("arrow"),
        (m19532_19_0, m19532_19_1) if (&m19532_19_0 == &Text::lit("cycle")) && (&m19532_19_1 == &Nat::from(0u32)) => Text::lit("arrow"),
        (m19532_20_0, m19532_20_1) if (&m19532_20_0 == &Text::lit("upgrade")) && (&m19532_20_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19532_21_0, m19532_21_1) if (&m19532_21_0 == &Text::lit("expect")) && (&m19532_21_1 == &Nat::from(1u32)) => Text::lit("free"),
        (m19532_22_0, m19532_22_1) if (&m19532_22_0 == &Text::lit("to_pod")) && (&m19532_22_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19532_23_0, m19532_23_1) if (&m19532_23_0 == &Text::lit("cloned")) && (&m19532_23_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19532_24_0, m19532_24_1) if (&m19532_24_0 == &Text::lit("ok")) && (&m19532_24_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19532_25_0, m19532_25_1) if (&m19532_25_0 == &Text::lit("ok_or")) && (&m19532_25_1 == &Nat::from(1u32)) => Text::lit("free"),
        (m19532_26_0, m19532_26_1) if (&m19532_26_0 == &Text::lit("map")) && (&m19532_26_1 == &Nat::from(1u32)) => Text::lit("free"),
        (m19532_27_0, m19532_27_1) if (&m19532_27_0 == &Text::lit("iter_mut")) && (&m19532_27_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19532_28_0, m19532_28_1) if (&m19532_28_0 == &Text::lit("to_vec")) && (&m19532_28_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19532_29_0, m19532_29_1) if (&m19532_29_0 == &Text::lit("filter_some")) && (&m19532_29_1 == &Nat::from(0u32)) => Text::lit("free"),
        _ => Text::lit("dot"),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// FreeName: fn Text -> Text
/// ```
pub fn free_name_f(m_p0: &Text) -> Text {
    match m_p0 {
        m20469_0 if (m20469_0 == &Text::lit("to_pod")) => Text::lit("prism_rtl::to_pod"),
        m20469_1 if (m20469_1 == &Text::lit("ok")) => Text::lit("prism_rtl::ignore"),
        m20469_2 if (m20469_2 == &Text::lit("map")) => Text::lit("prism_rtl::fmap"),
        m20469_3 if (m20469_3 == &Text::lit("ok_or")) => Text::lit("prism_rtl::ok_or"),
        m20469_4 if (m20469_4 == &Text::lit("to_vec")) => Text::lit("prism_rtl::path_of"),
        m20469_5 if (m20469_5 == &Text::lit("values")) => Text::lit("crate::prelude::values"),
        m20469_6 if (m20469_6 == &Text::lit("keys")) => Text::lit("crate::prelude::keys"),
        m20469_7 if (m20469_7 == &Text::lit("enumerate")) => Text::lit("prism_rtl::enumerate"),
        m20469_8 if (m20469_8 == &Text::lit("unwrap_or_default")) => Text::lit("prism_rtl::unwrap_or_default"),
        m20469_9 if (m20469_9 == &Text::lit("for_each")) => Text::lit("prism_rtl::for_each"),
        _ => m_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// MemberName: fn Text -> Text
/// ```
pub fn member_name_f(m_p0: &Text) -> Text {
    match m_p0 {
        m20910_0 if (m20910_0 == &Text::lit("push_str")) => Text::lit("append"),
        m20910_1 if (m20910_1 == &Text::lit("len")) => Text::lit("size"),
        m20910_2 if (m20910_2 == &Text::lit("is_empty")) => Text::lit("empty"),
        m20910_3 if (m20910_3 == &Text::lit("push")) => Text::lit("push_back"),
        m20910_4 if (m20910_4 == &Text::lit("contains_key")) => Text::lit("contains"),
        m20910_5 if (m20910_5 == &Text::lit("build")) => Text::lit("make"),
        _ => crate::emit::cpp::cpp_id_f(m_p0),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CaseTest: fn Cp, Text, Text -> Text
/// ```
pub fn case_test_f(cp_p0: &crate::emit::cpp::Cp, c_p1: &Text, v_p2: &Text) -> Text {
    match c_p1 {
        m21209_0 if (m21209_0 == &Text::lit("Some")) => Text::from(format!("prism_rtl::is_some({})", v_p2)),
        m21209_1 if (m21209_1 == &Text::lit("None")) => Text::from(format!("prism_rtl::is_none({})", v_p2)),
        m21209_2 if (m21209_2 == &Text::lit("Ok")) => Text::from(format!("prism_rtl::is_ok({})", v_p2)),
        m21209_3 if (m21209_3 == &Text::lit("Err")) => Text::from(format!("prism_rtl::is_err({})", v_p2)),
        m21209_4 if (m21209_4 == &Text::lit("prism_rtl::Turn::More")) => Text::from(format!("{}.if_more()", v_p2)),
        m21209_5 if (m21209_5 == &Text::lit("prism_rtl::Turn::Finished")) => Text::from(format!("{}.if_finished()", v_p2)),
        _ => match crate::emit::cpp::case_of_o(cp_p0, c_p1) {
            Some(_) => Text::from(format!("prism_rtl::is<{}>({})", &case_type_of_f(cp_p0, c_p1, v_p2), v_p2)),
            None => if is_runtime_case_f(c_p1) {
                Text::from(format!("prism_rtl::is<{}>({})", &case_type_f(c_p1), v_p2))
            } else {
                Text::lit("true")
            },
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CaseType: fn Text -> Text
/// ```
pub fn case_type_f(c_p0: &Text) -> Text {
    match c_p0 {
        m21770_0 if (m21770_0 == &Text::lit("Segment::Pos")) => Text::lit("pat::Pos"),
        m21770_1 if (m21770_1 == &Text::lit("Segment::Gen")) => Text::lit("pat::Gen"),
        m21770_2 if (m21770_2 == &Text::lit("Segment::Key")) => Text::lit("pat::Key"),
        _ => crate::emit::cpp::type_path_f(c_p0),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CaseTypeOf: fn Cp, Text, Text -> Text
/// ```
pub fn case_type_of_f(cp_p0: &crate::emit::cpp::Cp, c_p1: &Text, v_p2: &Text) -> Text {
    if is_generic_case_f(cp_p0, c_p1) {
        Text::from(format!("typename std::remove_cvref_t<decltype({})>::{}", v_p2, &crate::emit::cpp::last_segment_f(&crate::emit::cpp::type_path_f(c_p1))))
    } else {
        case_type_f(c_p1)
    }
}

/// ```prism
/// IsGenericCase: fn Cp, Text -> Bool
/// ```
pub fn is_generic_case_f(cp_p0: &crate::emit::cpp::Cp, p_p1: &Text) -> bool {
    match crate::emit::cpp::case_of_o(cp_p0, p_p1) {
        Some(ty_p2) => match crate::emit::cpp::type_of_o(cp_p0, &ty_p2) {
            Some(info_p3) => &crate::prelude::len(&info_p3.params_p) > &Nat::from(0u32),
            None => false,
        },
        None => false,
    }
}

/// ```prism
/// Payload: fn Cp, Text, Text, Nat -> Text
/// ```
pub fn payload_f(cp_p0: &crate::emit::cpp::Cp, c_p1: &Text, v_p2: &Text, i_p3: &Nat) -> Text {
    match c_p1 {
        m22630_0 if (m22630_0 == &Text::lit("Some")) => Text::from(format!("prism_rtl::some_of({})", v_p2)),
        m22630_1 if (m22630_1 == &Text::lit("Ok")) => Text::from(format!("*{}", v_p2)),
        m22630_2 if (m22630_2 == &Text::lit("Err")) => Text::from(format!("{}.error()", v_p2)),
        m22630_3 if (m22630_3 == &Text::lit("prism_rtl::Turn::More")) => Text::from(format!("{}.if_more()->next", v_p2)),
        m22630_4 if (m22630_4 == &Text::lit("prism_rtl::Turn::Finished")) => Text::from(format!("{}.if_finished()->value", v_p2)),
        _ => match crate::emit::cpp::case_of_o(cp_p0, c_p1) {
            Some(_) => Text::from(format!("prism_rtl::as<{}>({}).a{}", &case_type_of_f(cp_p0, c_p1, v_p2), v_p2, i_p3)),
            None => if is_runtime_case_f(c_p1) {
                Text::from(format!("prism_rtl::as<{}>({}).a{}", &case_type_f(c_p1), v_p2, i_p3))
            } else {
                Text::from(format!("{}.a{}", v_p2, i_p3))
            },
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IsRuntimeCase: fn Text -> Bool
/// ```
pub fn is_runtime_case_f(c_p0: &Text) -> bool {
    crate::syntax::lexer::chars::has_prefix_f(c_p0, &Text::lit("Segment::"))
}

/// ```prism
/// CppIf: unbounded fn Cp, Ex, Ex, Ex -> Text
/// ```
pub fn cpp_if_f(cp_p0: &crate::emit::cpp::Cp, c_p1: &crate::lower::model::Ex, t_p2: &crate::lower::model::Ex, e_p3: &crate::lower::model::Ex) -> Text {
    let ct_p4 = cpp_expr_f(cp_p0, c_p1);
    let err_o5 = match (err_of_o(t_p2), err_of_o(e_p3)) {
        (Some(y_p9), _) => Some(y_p9),
        (None, Some(y_pa)) => Some(y_pa),
        _ => None,
    };
    let tt_p6 = match &err_o5 {
        Some(y_pb) => ok_branch_f(cp_p0, t_p2, y_pb),
        None => cpp_expr_f(cp_p0, t_p2),
    };
    let et_p7 = match &err_o5 {
        Some(y_pc) => ok_branch_f(cp_p0, e_p3, y_pc),
        None => cpp_expr_f(cp_p0, e_p3),
    };
    let short_p8 = !crate::syntax::lexer::chars::contains_f(&Text::from(format!("{}{}", &tt_p6, &et_p7)), &Text::lit("\n")) && (&crate::prelude::len_text(&Text::from(format!("{}{}{}", &ct_p4, &tt_p6, &et_p7))) < &Nat::from(70u32));
    if short_p8 {
        Text::from(format!("{} ? {} : {}", &ct_p4, &tt_p6, &et_p7))
    } else {
        crate::emit::cpp::templates::items::cond_expr_f(&ct_p4, &tt_p6, &et_p7)
    }
}

/// The step machine of `CppIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppIf: unbounded fn Cp, Ex, Ex, Ex -> Text
/// ```
pub struct CppIf {
    pub cp_p0: crate::emit::cpp::Cp,
    pub c_p1: crate::lower::model::Ex,
    pub t_p2: crate::lower::model::Ex,
    pub e_p3: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppIf {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let c_p1 = &self.c_p1;
        let t_p2 = &self.t_p2;
        let e_p3 = &self.e_p3;
        let c_p1x = c_p1.clone();
        let cp_p0x = cp_p0.clone();
        let e_p3x = e_p3.clone();
        let t_p2x = t_p2.clone();
        crate::prelude::call_then(start_cpp_expr_f(cp_p0x.clone(), c_p1x.clone()), move |cpp_expr_f_23216: Text| {
            let ct_p4 = cpp_expr_f_23216;
            let err_o5 = match (err_of_o(&t_p2x), err_of_o(&e_p3x)) {
                (Some(y_p9), _) => Some(y_p9),
                (None, Some(y_pa)) => Some(y_pa),
                _ => None,
            };
            let tt_p6 = match &err_o5 {
                Some(y_pb) => ok_branch_f(&cp_p0x, &t_p2x, y_pb),
                None => cpp_expr_f(&cp_p0x, &t_p2x),
            };
            let et_p7 = match &err_o5 {
                Some(y_pc) => ok_branch_f(&cp_p0x, &e_p3x, y_pc),
                None => cpp_expr_f(&cp_p0x, &e_p3x),
            };
            let short_p8 = !crate::syntax::lexer::chars::contains_f(&Text::from(format!("{}{}", &tt_p6, &et_p7)), &Text::lit("\n")) && (&crate::prelude::len_text(&Text::from(format!("{}{}{}", &ct_p4, &tt_p6, &et_p7))) < &Nat::from(70u32));
            if short_p8 {
                prism_rtl::Turn::Finished(Text::from(format!("{} ? {} : {}", &ct_p4, &tt_p6, &et_p7)))
            } else {
                prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cond_expr_f(&ct_p4, &tt_p6, &et_p7))
            }
        })
    }
}

/// `Start CppIf, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_if_f(cp_p0: crate::emit::cpp::Cp, c_p1: crate::lower::model::Ex, t_p2: crate::lower::model::Ex, e_p3: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppIf { cp_p0, c_p1, t_p2, e_p3 })
}

/// ```prism
/// WithMoveCaptures: unbounded fn Cp, [Do], Ex -> Cp
/// ```
pub fn with_move_captures_f(cp_p0: &crate::emit::cpp::Cp, dos_p1: &Array<crate::lower::model::Do>, e_p2: &crate::lower::model::Ex) -> crate::emit::cpp::Cp {
    let lets_p3 = crate::prelude::fold(dos_p1, &Array::new(), &(|acc_p4: &Array<Text>, d_p5: &crate::lower::model::Do| match d_p5 {
        crate::lower::model::Do::DoLet(p_p6, _) => match crate::emit::cpp::stmts::let_name_o(p_p6) {
            Some(n_p7) => if crate::emit::cpp::in_list_f(acc_p4, &n_p7) {
                acc_p4.clone()
            } else {
                crate::prelude::push(acc_p4, &n_p7)
            },
            None => acc_p4.clone(),
        },
        _ => acc_p4.clone(),
    }));
    if &crate::prelude::len(&lets_p3) == &Nat::from(0u32) {
        {
            let mut this: crate::emit::cpp::Cp = cp_p0.clone();
            this.move_captures_p = Array::new();
            this
        }
    } else {
        {
            let (reads_p8, has_move_p9) = reads_of_f(e_p2, &false, &(Array::new(), false));
            {
                let mut this: crate::emit::cpp::Cp = cp_p0.clone();
                this.move_captures_p = if has_move_p9 {
                    crate::prelude::filter(&lets_p3, &(|n_pa: &Text| !crate::emit::cpp::in_list_f(&reads_p8, n_pa)))
                } else {
                    Array::new()
                };
                this
            }
        }
    }
}

/// The step machine of `WithMoveCaptures`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WithMoveCaptures: unbounded fn Cp, [Do], Ex -> Cp
/// ```
pub struct WithMoveCaptures {
    pub cp_p0: crate::emit::cpp::Cp,
    pub dos_p1: Array<crate::lower::model::Do>,
    pub e_p2: crate::lower::model::Ex,
}

impl prism_rtl::Job<crate::emit::cpp::Cp> for WithMoveCaptures {
    fn cycle(&self) -> prism_rtl::Turn<crate::emit::cpp::Cp> {
        let cp_p0 = &self.cp_p0;
        let dos_p1 = &self.dos_p1;
        let e_p2 = &self.e_p2;
        let lets_p3 = crate::prelude::fold(dos_p1, &Array::new(), &(|acc_p4: &Array<Text>, d_p5: &crate::lower::model::Do| match d_p5 {
            crate::lower::model::Do::DoLet(p_p6, _) => match crate::emit::cpp::stmts::let_name_o(p_p6) {
                Some(n_p7) => if crate::emit::cpp::in_list_f(acc_p4, &n_p7) {
                    acc_p4.clone()
                } else {
                    crate::prelude::push(acc_p4, &n_p7)
                },
                None => acc_p4.clone(),
            },
            _ => acc_p4.clone(),
        }));
        if &crate::prelude::len(&lets_p3) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished({
                let mut this: crate::emit::cpp::Cp = cp_p0.clone();
                this.move_captures_p = Array::new();
                this
            })
        } else {
            {
                let cp_p0x = cp_p0.clone();
                let e_p2x = e_p2.clone();
                crate::prelude::call_then(start_reads_of_f(e_p2x.clone(), false, (Array::new(), false)), move |reads_of_f_24465: (Array<Text>, bool)| {
                    let (reads_p8, has_move_p9) = reads_of_f_24465;
                    prism_rtl::Turn::Finished({
                        let mut this: crate::emit::cpp::Cp = cp_p0x.clone();
                        this.move_captures_p = if has_move_p9 {
                            crate::prelude::filter(&lets_p3, &(|n_pa: &Text| !crate::emit::cpp::in_list_f(&reads_p8, n_pa)))
                        } else {
                            Array::new()
                        };
                        this
                    })
                })
            }
        }
    }
}

/// `Start WithMoveCaptures, x`: what the function value is when passed to `@Run`.
pub fn start_with_move_captures_f(cp_p0: crate::emit::cpp::Cp, dos_p1: Array<crate::lower::model::Do>, e_p2: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<crate::emit::cpp::Cp>> {
    Rc::new(WithMoveCaptures { cp_p0, dos_p1, e_p2 })
}

/// ```prism
/// ReadsOf: unbounded fn Ex, Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub fn reads_of_f(x_p0: &crate::lower::model::Ex, into_p1: &bool, acc_p2: &(Array<Text>, bool)) -> (Array<Text>, bool) {
    let (reads_p3, has_move_p4) = acc_p2.clone();
    match x_p0 {
        crate::lower::model::Ex::XVar(n_p5) => (crate::prelude::push(&reads_p3, n_p5), has_move_p4),
        crate::lower::model::Ex::XClosure(true, ps_p6, body_p7) => if *into_p1 {
            reads_of_f(&**body_p7, into_p1, &(reads_p3.clone(), true))
        } else {
            (reads_p3.clone(), true)
        },
        crate::lower::model::Ex::XClosure(false, ps_p8, body_p9) => reads_of_f(&**body_p9, into_p1, acc_p2),
        crate::lower::model::Ex::XRef(y_pa) => reads_of_f(&**y_pa, into_p1, acc_p2),
        crate::lower::model::Ex::XRefMut(y_pb) => reads_of_f(&**y_pb, into_p1, acc_p2),
        crate::lower::model::Ex::XDeref(y_pc) => reads_of_f(&**y_pc, into_p1, acc_p2),
        crate::lower::model::Ex::XTarget(y_pd) => reads_of_f(&**y_pd, into_p1, acc_p2),
        crate::lower::model::Ex::XClone(y_pe) => reads_of_f(&**y_pe, into_p1, acc_p2),
        crate::lower::model::Ex::XWeak(y_pf) => reads_of_f(&**y_pf, into_p1, acc_p2),
        crate::lower::model::Ex::XUpgrade(y_pg) => reads_of_f(&**y_pg, into_p1, acc_p2),
        crate::lower::model::Ex::XBreak(_, y_ph) => reads_of_f(&**y_ph, into_p1, acc_p2),
        crate::lower::model::Ex::XLater(y_pi) => reads_of_f(&**y_pi, into_p1, acc_p2),
        crate::lower::model::Ex::XFormatStr(xs_pj) => reads_each_f(xs_pj, into_p1, acc_p2),
        crate::lower::model::Ex::XIsCase(y_pk, _) => reads_of_f(&**y_pk, into_p1, acc_p2),
        crate::lower::model::Ex::XCall(_, xs_pl) => reads_each_f(xs_pl, into_p1, acc_p2),
        crate::lower::model::Ex::XApply(f_pm, xs_pn) => reads_each_f(&crate::prelude::append(&Array::from(vec![(**f_pm).clone()]), xs_pn), into_p1, acc_p2),
        crate::lower::model::Ex::XMethod(r_po, _, xs_pp) => reads_each_f(&crate::prelude::append(&Array::from(vec![(**r_po).clone()]), xs_pp), into_p1, acc_p2),
        crate::lower::model::Ex::XBin(_, l_pq, r_pr) => reads_each_f(&Array::from(vec![(**l_pq).clone(), (**r_pr).clone()]), into_p1, acc_p2),
        crate::lower::model::Ex::XUnary(_, y_ps) => reads_of_f(&**y_ps, into_p1, acc_p2),
        crate::lower::model::Ex::XCtor(_, xs_pt) => reads_each_f(xs_pt, into_p1, acc_p2),
        crate::lower::model::Ex::XRecord(_, fs_pu) => reads_each_f(&crate::prelude::each(fs_pu, &(|(_, v_pv): &(Text, crate::lower::model::Ex)| v_pv.clone())), into_p1, acc_p2),
        crate::lower::model::Ex::XTuple(xs_p10) => reads_each_f(xs_p10, into_p1, acc_p2),
        crate::lower::model::Ex::XVec(xs_p11) => reads_each_f(xs_p11, into_p1, acc_p2),
        crate::lower::model::Ex::XFormat(xs_p12) => reads_each_f(xs_p12, into_p1, acc_p2),
        crate::lower::model::Ex::XMatch(s_p13, arms_p14, _, _) => reads_arms_f(arms_p14, into_p1, &reads_of_f(&**s_p13, into_p1, acc_p2)),
        crate::lower::model::Ex::XChain(_, s_p15, arms_p16, _) => reads_arms_f(arms_p16, into_p1, &reads_of_f(&**s_p15, into_p1, acc_p2)),
        crate::lower::model::Ex::XIf(c_p17, t_p18, e_p19) => reads_each_f(&Array::from(vec![(**c_p17).clone(), (**t_p18).clone(), (**e_p19).clone()]), into_p1, acc_p2),
        crate::lower::model::Ex::XBlock(dos_p1a, e_p1b) => reads_of_f(&**e_p1b, into_p1, &reads_dos_f(dos_p1a, into_p1, acc_p2)),
        crate::lower::model::Ex::XLabeled(_, dos_p1c, e_p1d, _) => reads_of_f(&**e_p1d, into_p1, &reads_dos_f(dos_p1c, into_p1, acc_p2)),
        crate::lower::model::Ex::XTry(y_p1e) => reads_of_f(&**y_p1e, into_p1, acc_p2),
        crate::lower::model::Ex::XField(r_p1f, _) => reads_of_f(&**r_p1f, into_p1, acc_p2),
        crate::lower::model::Ex::XPart(r_p1g, _) => reads_of_f(&**r_p1g, into_p1, acc_p2),
        crate::lower::model::Ex::XDecode(_, y_p1h) => reads_of_f(&**y_p1h, into_p1, acc_p2),
        crate::lower::model::Ex::XCast(y_p1i, _) => reads_of_f(&**y_p1i, into_p1, acc_p2),
        crate::lower::model::Ex::XTyped(y_p1j, _) => reads_of_f(&**y_p1j, into_p1, acc_p2),
        _ => acc_p2.clone(),
    }
}

/// The step machine of `ReadsOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadsOf: unbounded fn Ex, Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub struct ReadsOf {
    pub x_p0: crate::lower::model::Ex,
    pub into_p1: bool,
    pub acc_p2: (Array<Text>, bool),
}

impl prism_rtl::Job<(Array<Text>, bool)> for ReadsOf {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Text>, bool)> {
        let x_p0 = &self.x_p0;
        let into_p1 = &self.into_p1;
        let acc_p2 = &self.acc_p2;
        let (reads_p3, has_move_p4) = acc_p2.clone();
        match x_p0 {
            crate::lower::model::Ex::XVar(n_p5) => prism_rtl::Turn::Finished((crate::prelude::push(&reads_p3, n_p5), has_move_p4)),
            crate::lower::model::Ex::XClosure(true, ps_p6, body_p7) => if *into_p1 {
                prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**body_p7).clone(), into_p1: *into_p1, acc_p2: (reads_p3.clone(), true) }))
            } else {
                prism_rtl::Turn::Finished((reads_p3.clone(), true))
            },
            crate::lower::model::Ex::XClosure(false, ps_p8, body_p9) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**body_p9).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XRef(y_pa) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_pa).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XRefMut(y_pb) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_pb).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XDeref(y_pc) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_pc).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XTarget(y_pd) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_pd).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XClone(y_pe) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_pe).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XWeak(y_pf) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_pf).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XUpgrade(y_pg) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_pg).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XBreak(_, y_ph) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_ph).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XLater(y_pi) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_pi).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XFormatStr(xs_pj) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: xs_pj.clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XIsCase(y_pk, _) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_pk).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XCall(_, xs_pl) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: xs_pl.clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XApply(f_pm, xs_pn) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: crate::prelude::append(&Array::from(vec![(**f_pm).clone()]), xs_pn), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XMethod(r_po, _, xs_pp) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: crate::prelude::append(&Array::from(vec![(**r_po).clone()]), xs_pp), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XBin(_, l_pq, r_pr) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: Array::from(vec![(**l_pq).clone(), (**r_pr).clone()]), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XUnary(_, y_ps) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_ps).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XCtor(_, xs_pt) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: xs_pt.clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XRecord(_, fs_pu) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: crate::prelude::each(fs_pu, &(|(_, v_pv): &(Text, crate::lower::model::Ex)| v_pv.clone())), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XTuple(xs_p10) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: xs_p10.clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XVec(xs_p11) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: xs_p11.clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XFormat(xs_p12) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: xs_p12.clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XMatch(s_p13, arms_p14, _, _) => {
                let acc_p2x = acc_p2.clone();
                let arms_p14x = arms_p14.clone();
                let into_p1x = *into_p1;
                let s_p13x = (**s_p13).clone();
                crate::prelude::call_then(start_reads_of_f(s_p13x.clone(), into_p1x, acc_p2x.clone()), move |reads_of_f_26167: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsArms { arms_p0: arms_p14x.clone(), into_p1: into_p1x, acc_p2: reads_of_f_26167 })))
            },
            crate::lower::model::Ex::XChain(_, s_p15, arms_p16, _) => {
                let acc_p2x = acc_p2.clone();
                let arms_p16x = arms_p16.clone();
                let into_p1x = *into_p1;
                let s_p15x = (**s_p15).clone();
                crate::prelude::call_then(start_reads_of_f(s_p15x.clone(), into_p1x, acc_p2x.clone()), move |reads_of_f_26252: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsArms { arms_p0: arms_p16x.clone(), into_p1: into_p1x, acc_p2: reads_of_f_26252 })))
            },
            crate::lower::model::Ex::XIf(c_p17, t_p18, e_p19) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: Array::from(vec![(**c_p17).clone(), (**t_p18).clone(), (**e_p19).clone()]), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XBlock(dos_p1a, e_p1b) => {
                let acc_p2x = acc_p2.clone();
                let dos_p1ax = dos_p1a.clone();
                let e_p1bx = (**e_p1b).clone();
                let into_p1x = *into_p1;
                crate::prelude::call_then(start_reads_dos_f(dos_p1ax.clone(), into_p1x, acc_p2x.clone()), move |reads_dos_f_26369: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: e_p1bx.clone(), into_p1: into_p1x, acc_p2: reads_dos_f_26369 })))
            },
            crate::lower::model::Ex::XLabeled(_, dos_p1c, e_p1d, _) => {
                let acc_p2x = acc_p2.clone();
                let dos_p1cx = dos_p1c.clone();
                let e_p1dx = (**e_p1d).clone();
                let into_p1x = *into_p1;
                crate::prelude::call_then(start_reads_dos_f(dos_p1cx.clone(), into_p1x, acc_p2x.clone()), move |reads_dos_f_26453: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: e_p1dx.clone(), into_p1: into_p1x, acc_p2: reads_dos_f_26453 })))
            },
            crate::lower::model::Ex::XTry(y_p1e) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_p1e).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XField(r_p1f, _) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**r_p1f).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XPart(r_p1g, _) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**r_p1g).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XDecode(_, y_p1h) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_p1h).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XCast(y_p1i, _) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_p1i).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XTyped(y_p1j, _) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_p1j).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            _ => prism_rtl::Turn::Finished(acc_p2.clone()),
        }
    }
}

/// `Start ReadsOf, x`: what the function value is when passed to `@Run`.
pub fn start_reads_of_f(x_p0: crate::lower::model::Ex, into_p1: bool, acc_p2: (Array<Text>, bool)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>> {
    Rc::new(ReadsOf { x_p0, into_p1, acc_p2 })
}

/// ```prism
/// ReadsEach: unbounded fn [Ex], Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub fn reads_each_f(xs_p0: &Array<crate::lower::model::Ex>, into_p1: &bool, acc_p2: &(Array<Text>, bool)) -> (Array<Text>, bool) {
    crate::prelude::run_to_end(crate::prelude::fold_job(xs_p0.clone(), acc_p2.clone(), {
        let into_p1x = *into_p1;
        Rc::new(move |(p0, p1): ((Array<Text>, bool), crate::lower::model::Ex)| {
            let into_p1xy = into_p1x;
            crate::prelude::entered(crate::prelude::once_job(move || {
                let a_p3 = p0;
                let x_p4 = p1;
                prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: x_p4.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() }))
            }))
        }) as Rc<dyn Fn(((Array<Text>, bool), crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
    }))
}

/// The step machine of `ReadsEach`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadsEach: unbounded fn [Ex], Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub struct ReadsEach {
    pub xs_p0: Array<crate::lower::model::Ex>,
    pub into_p1: bool,
    pub acc_p2: (Array<Text>, bool),
}

impl prism_rtl::Job<(Array<Text>, bool)> for ReadsEach {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Text>, bool)> {
        let xs_p0 = &self.xs_p0;
        let into_p1 = &self.into_p1;
        let acc_p2 = &self.acc_p2;
        crate::prelude::fold_job(xs_p0.clone(), acc_p2.clone(), {
            let into_p1x = *into_p1;
            Rc::new(move |(p0, p1): ((Array<Text>, bool), crate::lower::model::Ex)| {
                let into_p1xy = into_p1x;
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p3 = p0;
                    let x_p4 = p1;
                    prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: x_p4.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() }))
                }))
            }) as Rc<dyn Fn(((Array<Text>, bool), crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
        }).cycle()
    }
}

/// `Start ReadsEach, x`: what the function value is when passed to `@Run`.
pub fn start_reads_each_f(xs_p0: Array<crate::lower::model::Ex>, into_p1: bool, acc_p2: (Array<Text>, bool)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>> {
    Rc::new(ReadsEach { xs_p0, into_p1, acc_p2 })
}

/// ```prism
/// ReadsArms: unbounded fn [XArm], Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub fn reads_arms_f(arms_p0: &Array<crate::lower::model::XArm>, into_p1: &bool, acc_p2: &(Array<Text>, bool)) -> (Array<Text>, bool) {
    crate::prelude::run_to_end(crate::prelude::fold_job(arms_p0.clone(), acc_p2.clone(), {
        let into_p1x = *into_p1;
        Rc::new(move |(p0, p1): ((Array<Text>, bool), crate::lower::model::XArm)| {
            let into_p1xy = into_p1x;
            crate::prelude::entered(crate::prelude::once_job(move || {
                let a_p3 = p0;
                let arm_p4 = p1;
                crate::prelude::call_value(crate::prelude::fold_job(arm_p4.conds_p.clone(), a_p3.clone(), {
                    let into_p1xyx = into_p1xy;
                    Rc::new(move |(p0, p1): ((Array<Text>, bool), crate::lower::model::Cc)| {
                        let into_p1xyxy = into_p1xyx;
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a2_p5 = p0;
                            let c_p6 = p1;
                            prism_rtl::Turn::More(Rc::new(ReadsCond { cc0: c_p6.clone(), into_p1: into_p1xyxy, acc_p2: a2_p5.clone() }))
                        }))
                    }) as Rc<dyn Fn(((Array<Text>, bool), crate::lower::model::Cc)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
                }), move |fold_27074: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: arm_p4.body_p.clone(), into_p1: into_p1xy, acc_p2: fold_27074 })))
            }))
        }) as Rc<dyn Fn(((Array<Text>, bool), crate::lower::model::XArm)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
    }))
}

/// The step machine of `ReadsArms`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadsArms: unbounded fn [XArm], Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub struct ReadsArms {
    pub arms_p0: Array<crate::lower::model::XArm>,
    pub into_p1: bool,
    pub acc_p2: (Array<Text>, bool),
}

impl prism_rtl::Job<(Array<Text>, bool)> for ReadsArms {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Text>, bool)> {
        let arms_p0 = &self.arms_p0;
        let into_p1 = &self.into_p1;
        let acc_p2 = &self.acc_p2;
        crate::prelude::fold_job(arms_p0.clone(), acc_p2.clone(), {
            let into_p1x = *into_p1;
            Rc::new(move |(p0, p1): ((Array<Text>, bool), crate::lower::model::XArm)| {
                let into_p1xy = into_p1x;
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p3 = p0;
                    let arm_p4 = p1;
                    crate::prelude::call_value(crate::prelude::fold_job(arm_p4.conds_p.clone(), a_p3.clone(), {
                        let into_p1xyx = into_p1xy;
                        Rc::new(move |(p0, p1): ((Array<Text>, bool), crate::lower::model::Cc)| {
                            let into_p1xyxy = into_p1xyx;
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let a2_p5 = p0;
                                let c_p6 = p1;
                                prism_rtl::Turn::More(Rc::new(ReadsCond { cc0: c_p6.clone(), into_p1: into_p1xyxy, acc_p2: a2_p5.clone() }))
                            }))
                        }) as Rc<dyn Fn(((Array<Text>, bool), crate::lower::model::Cc)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
                    }), move |fold_27074: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: arm_p4.body_p.clone(), into_p1: into_p1xy, acc_p2: fold_27074 })))
                }))
            }) as Rc<dyn Fn(((Array<Text>, bool), crate::lower::model::XArm)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
        }).cycle()
    }
}

/// `Start ReadsArms, x`: what the function value is when passed to `@Run`.
pub fn start_reads_arms_f(arms_p0: Array<crate::lower::model::XArm>, into_p1: bool, acc_p2: (Array<Text>, bool)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>> {
    Rc::new(ReadsArms { arms_p0, into_p1, acc_p2 })
}

/// ```prism
/// ReadsCond: unbounded fn Cc, Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub fn reads_cond_f(cc0: &crate::lower::model::Cc, into_p1: &bool, acc_p2: &(Array<Text>, bool)) -> (Array<Text>, bool) {
    match cc0 {
        crate::lower::model::Cc::CcLet(_, x_p0) => reads_of_f(x_p0, into_p1, acc_p2),
        crate::lower::model::Cc::CcIf(x_p3) => reads_of_f(x_p3, into_p1, acc_p2),
    }
}

/// The step machine of `ReadsCond`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadsCond: unbounded fn Cc, Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub struct ReadsCond {
    pub cc0: crate::lower::model::Cc,
    pub into_p1: bool,
    pub acc_p2: (Array<Text>, bool),
}

impl prism_rtl::Job<(Array<Text>, bool)> for ReadsCond {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Text>, bool)> {
        let cc0 = &self.cc0;
        let into_p1 = &self.into_p1;
        let acc_p2 = &self.acc_p2;
        match cc0 {
            crate::lower::model::Cc::CcLet(_, x_p0) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: x_p0.clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Cc::CcIf(x_p3) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: x_p3.clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
        }
    }
}

/// `Start ReadsCond, x`: what the function value is when passed to `@Run`.
pub fn start_reads_cond_f(cc0: crate::lower::model::Cc, into_p1: bool, acc_p2: (Array<Text>, bool)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>> {
    Rc::new(ReadsCond { cc0, into_p1, acc_p2 })
}

/// ```prism
/// ReadsDos: unbounded fn [Do], Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub fn reads_dos_f(dos_p0: &Array<crate::lower::model::Do>, into_p1: &bool, acc_p2: &(Array<Text>, bool)) -> (Array<Text>, bool) {
    crate::prelude::run_to_end(crate::prelude::fold_job(dos_p0.clone(), acc_p2.clone(), {
        let into_p1x = *into_p1;
        Rc::new(move |(p0, p1): ((Array<Text>, bool), crate::lower::model::Do)| {
            let into_p1xy = into_p1x;
            crate::prelude::entered(crate::prelude::once_job(move || {
                let a_p3 = p0;
                let d_p4 = p1;
                match &d_p4 {
                    crate::lower::model::Do::DoLet(_, x_p5) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: x_p5.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                    crate::lower::model::Do::DoLetElse(_, x_p6, e_p7) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: Array::from(vec![x_p6.clone(), e_p7.clone()]), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                    crate::lower::model::Do::DoAssign(p_p8, x_p9) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: Array::from(vec![p_p8.clone(), x_p9.clone()]), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                    crate::lower::model::Do::DoWhile(c_pa, body_pb) => {
                        let body_pbx = body_pb.clone();
                        let c_pax = c_pa.clone();
                        crate::prelude::call_then(start_reads_of_f(c_pax.clone(), into_p1xy, a_p3.clone()), move |reads_of_f_27638: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_pbx.clone(), into_p1: into_p1xy, acc_p2: reads_of_f_27638 })))
                    },
                    crate::lower::model::Do::DoWhileLet(_, x_pc, body_pd) => {
                        let body_pdx = body_pd.clone();
                        let x_pcx = x_pc.clone();
                        crate::prelude::call_then(start_reads_of_f(x_pcx.clone(), into_p1xy, a_p3.clone()), move |reads_of_f_27712: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_pdx.clone(), into_p1: into_p1xy, acc_p2: reads_of_f_27712 })))
                    },
                    crate::lower::model::Do::DoFor(_, x_pe, body_pf) => {
                        let body_pfx = body_pf.clone();
                        let x_pex = x_pe.clone();
                        crate::prelude::call_then(start_reads_of_f(x_pex.clone(), into_p1xy, a_p3.clone()), move |reads_of_f_27781: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_pfx.clone(), into_p1: into_p1xy, acc_p2: reads_of_f_27781 })))
                    },
                    crate::lower::model::Do::DoExpr(x_pg) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: x_pg.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                    crate::lower::model::Do::DoIf(c_ph, t_pi, e_pj) => {
                        let c_phx = c_ph.clone();
                        let e_pjx = e_pj.clone();
                        let t_pix = t_pi.clone();
                        crate::prelude::call_then(start_reads_of_f(c_phx.clone(), into_p1xy, a_p3.clone()), move |reads_of_f_27890: (Array<Text>, bool)| crate::prelude::call_then(start_reads_dos_f(t_pix.clone(), into_p1xy, reads_of_f_27890), move |reads_dos_f_27871: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: e_pjx.clone(), into_p1: into_p1xy, acc_p2: reads_dos_f_27871 }))))
                    },
                    crate::lower::model::Do::DoIfLet(_, x_pk, t_pl, e_pm) => {
                        let e_pmx = e_pm.clone();
                        let t_plx = t_pl.clone();
                        let x_pkx = x_pk.clone();
                        crate::prelude::call_then(start_reads_of_f(x_pkx.clone(), into_p1xy, a_p3.clone()), move |reads_of_f_27978: (Array<Text>, bool)| crate::prelude::call_then(start_reads_dos_f(t_plx.clone(), into_p1xy, reads_of_f_27978), move |reads_dos_f_27959: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: e_pmx.clone(), into_p1: into_p1xy, acc_p2: reads_dos_f_27959 }))))
                    },
                    crate::lower::model::Do::DoMatch(x_pn, cases_po) => {
                        let cases_pox = cases_po.clone();
                        let x_pnx = x_pn.clone();
                        crate::prelude::call_then(start_reads_of_f(x_pnx.clone(), into_p1xy, a_p3.clone()), move |reads_of_f_28034: (Array<Text>, bool)| crate::prelude::fold_job(cases_pox.clone(), reads_of_f_28034, {
                            let into_p1xyx = into_p1xy;
                            Rc::new(move |(p0, p1): ((Array<Text>, bool), (crate::lower::model::Pa, Array<crate::lower::model::Do>))| {
                                let into_p1xyxy = into_p1xyx;
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let a2_pp = p0;
                                    let (_, body_pq) = p1;
                                    prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_pq.clone(), into_p1: into_p1xyxy, acc_p2: a2_pp.clone() }))
                                }))
                            }) as Rc<dyn Fn(((Array<Text>, bool), (crate::lower::model::Pa, Array<crate::lower::model::Do>))) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
                        }).cycle())
                    },
                    crate::lower::model::Do::DoReturn(x_pr) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: x_pr.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                    crate::lower::model::Do::DoBlock(body_ps) => prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_ps.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                    crate::lower::model::Do::DoScope(body_pt) => prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_pt.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                    crate::lower::model::Do::DoLine(body_pu) => prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_pu.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                    crate::lower::model::Do::DoNote(_) => prism_rtl::Turn::Finished(a_p3.clone()),
                }
            }))
        }) as Rc<dyn Fn(((Array<Text>, bool), crate::lower::model::Do)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
    }))
}

/// The step machine of `ReadsDos`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadsDos: unbounded fn [Do], Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub struct ReadsDos {
    pub dos_p0: Array<crate::lower::model::Do>,
    pub into_p1: bool,
    pub acc_p2: (Array<Text>, bool),
}

impl prism_rtl::Job<(Array<Text>, bool)> for ReadsDos {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Text>, bool)> {
        let dos_p0 = &self.dos_p0;
        let into_p1 = &self.into_p1;
        let acc_p2 = &self.acc_p2;
        crate::prelude::fold_job(dos_p0.clone(), acc_p2.clone(), {
            let into_p1x = *into_p1;
            Rc::new(move |(p0, p1): ((Array<Text>, bool), crate::lower::model::Do)| {
                let into_p1xy = into_p1x;
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p3 = p0;
                    let d_p4 = p1;
                    match &d_p4 {
                        crate::lower::model::Do::DoLet(_, x_p5) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: x_p5.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                        crate::lower::model::Do::DoLetElse(_, x_p6, e_p7) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: Array::from(vec![x_p6.clone(), e_p7.clone()]), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                        crate::lower::model::Do::DoAssign(p_p8, x_p9) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: Array::from(vec![p_p8.clone(), x_p9.clone()]), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                        crate::lower::model::Do::DoWhile(c_pa, body_pb) => {
                            let body_pbx = body_pb.clone();
                            let c_pax = c_pa.clone();
                            crate::prelude::call_then(start_reads_of_f(c_pax.clone(), into_p1xy, a_p3.clone()), move |reads_of_f_27638: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_pbx.clone(), into_p1: into_p1xy, acc_p2: reads_of_f_27638 })))
                        },
                        crate::lower::model::Do::DoWhileLet(_, x_pc, body_pd) => {
                            let body_pdx = body_pd.clone();
                            let x_pcx = x_pc.clone();
                            crate::prelude::call_then(start_reads_of_f(x_pcx.clone(), into_p1xy, a_p3.clone()), move |reads_of_f_27712: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_pdx.clone(), into_p1: into_p1xy, acc_p2: reads_of_f_27712 })))
                        },
                        crate::lower::model::Do::DoFor(_, x_pe, body_pf) => {
                            let body_pfx = body_pf.clone();
                            let x_pex = x_pe.clone();
                            crate::prelude::call_then(start_reads_of_f(x_pex.clone(), into_p1xy, a_p3.clone()), move |reads_of_f_27781: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_pfx.clone(), into_p1: into_p1xy, acc_p2: reads_of_f_27781 })))
                        },
                        crate::lower::model::Do::DoExpr(x_pg) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: x_pg.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                        crate::lower::model::Do::DoIf(c_ph, t_pi, e_pj) => {
                            let c_phx = c_ph.clone();
                            let e_pjx = e_pj.clone();
                            let t_pix = t_pi.clone();
                            crate::prelude::call_then(start_reads_of_f(c_phx.clone(), into_p1xy, a_p3.clone()), move |reads_of_f_27890: (Array<Text>, bool)| crate::prelude::call_then(start_reads_dos_f(t_pix.clone(), into_p1xy, reads_of_f_27890), move |reads_dos_f_27871: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: e_pjx.clone(), into_p1: into_p1xy, acc_p2: reads_dos_f_27871 }))))
                        },
                        crate::lower::model::Do::DoIfLet(_, x_pk, t_pl, e_pm) => {
                            let e_pmx = e_pm.clone();
                            let t_plx = t_pl.clone();
                            let x_pkx = x_pk.clone();
                            crate::prelude::call_then(start_reads_of_f(x_pkx.clone(), into_p1xy, a_p3.clone()), move |reads_of_f_27978: (Array<Text>, bool)| crate::prelude::call_then(start_reads_dos_f(t_plx.clone(), into_p1xy, reads_of_f_27978), move |reads_dos_f_27959: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: e_pmx.clone(), into_p1: into_p1xy, acc_p2: reads_dos_f_27959 }))))
                        },
                        crate::lower::model::Do::DoMatch(x_pn, cases_po) => {
                            let cases_pox = cases_po.clone();
                            let x_pnx = x_pn.clone();
                            crate::prelude::call_then(start_reads_of_f(x_pnx.clone(), into_p1xy, a_p3.clone()), move |reads_of_f_28034: (Array<Text>, bool)| crate::prelude::fold_job(cases_pox.clone(), reads_of_f_28034, {
                                let into_p1xyx = into_p1xy;
                                Rc::new(move |(p0, p1): ((Array<Text>, bool), (crate::lower::model::Pa, Array<crate::lower::model::Do>))| {
                                    let into_p1xyxy = into_p1xyx;
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let a2_pp = p0;
                                        let (_, body_pq) = p1;
                                        prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_pq.clone(), into_p1: into_p1xyxy, acc_p2: a2_pp.clone() }))
                                    }))
                                }) as Rc<dyn Fn(((Array<Text>, bool), (crate::lower::model::Pa, Array<crate::lower::model::Do>))) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
                            }).cycle())
                        },
                        crate::lower::model::Do::DoReturn(x_pr) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: x_pr.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                        crate::lower::model::Do::DoBlock(body_ps) => prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_ps.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                        crate::lower::model::Do::DoScope(body_pt) => prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_pt.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                        crate::lower::model::Do::DoLine(body_pu) => prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_pu.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                        crate::lower::model::Do::DoNote(_) => prism_rtl::Turn::Finished(a_p3.clone()),
                    }
                }))
            }) as Rc<dyn Fn(((Array<Text>, bool), crate::lower::model::Do)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
        }).cycle()
    }
}

/// `Start ReadsDos, x`: what the function value is when passed to `@Run`.
pub fn start_reads_dos_f(dos_p0: Array<crate::lower::model::Do>, into_p1: bool, acc_p2: (Array<Text>, bool)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>> {
    Rc::new(ReadsDos { dos_p0, into_p1, acc_p2 })
}

/// ```prism
/// IsCtor: fn Ex, Text -> Bool
/// ```
pub fn is_ctor_f(ex0: &crate::lower::model::Ex, c_p1: &Text) -> bool {
    match ex0 {
        crate::lower::model::Ex::XCtor(p_p0, _) => p_p0 == c_p1,
        x_p2 => false,
    }
}

/// ```prism
/// ?ErrOf: fn Ex -> ?Ex
/// ```
pub fn err_of_o(x_p0: &crate::lower::model::Ex) -> Option<crate::lower::model::Ex> {
    'm28478: {
        if let crate::lower::model::Ex::XCtor(m28478_0_0, m28478_0_1) = x_p0 && (m28478_0_0 == &Text::lit("Err")) && (m28478_0_1.len() == 1) && let Some(y_p1) = crate::prelude::index(m28478_0_1, &Nat::from(0u32)) {
            break 'm28478 Some(y_p1.clone());
        }
        if let crate::lower::model::Ex::XBlock(_, tail_p2) = x_p0 {
            break 'm28478 err_of_o(&**tail_p2);
        }
        None
    }
}

/// ```prism
/// OkBranch: unbounded fn Cp, Ex, Ex -> Text
/// ```
pub fn ok_branch_f(cp_p0: &crate::emit::cpp::Cp, x_p1: &crate::lower::model::Ex, y_p2: &crate::lower::model::Ex) -> Text {
    'm28781: {
        if let crate::lower::model::Ex::XCtor(m28781_0_0, m28781_0_1) = x_p1 && (m28781_0_0 == &Text::lit("Ok")) && (m28781_0_1.len() == 1) && let Some(v_p3) = crate::prelude::index(m28781_0_1, &Nat::from(0u32)) {
            break 'm28781 Text::from(format!("Expected<std::decay_t<decltype({})>, std::decay_t<decltype({})>>({})", &cpp_expr_f(cp_p0, &v_p3), &cpp_expr_f(cp_p0, y_p2), &cpp_expr_f(cp_p0, &v_p3)));
        }
        if let crate::lower::model::Ex::XBlock(dos_p4, m28781_1_1) = x_p1 && let crate::lower::model::Ex::XCtor(m28781_1_1_r_0, m28781_1_1_r_1) = &**m28781_1_1 && (m28781_1_1_r_0 == &Text::lit("Ok")) && (m28781_1_1_r_1.len() == 1) && let Some(v_p5) = crate::prelude::index(m28781_1_1_r_1, &Nat::from(0u32)) {
            break 'm28781 {
                let (st_p6, cp2_p7) = crate::emit::cpp::stmts::cpp_statements_cp_f(cp_p0, dos_p4);
                crate::emit::cpp::templates::items::stmt_expr_f(&st_p6, &Text::from(format!("Expected<std::decay_t<decltype({})>, std::decay_t<decltype({})>>({})", &cpp_expr_f(&cp2_p7, &v_p5), &cpp_expr_f(&cp2_p7, y_p2), &cpp_expr_f(&cp2_p7, &v_p5))))
            };
        }
        cpp_expr_f(cp_p0, x_p1)
    }
}

/// The step machine of `OkBranch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OkBranch: unbounded fn Cp, Ex, Ex -> Text
/// ```
pub struct OkBranch {
    pub cp_p0: crate::emit::cpp::Cp,
    pub x_p1: crate::lower::model::Ex,
    pub y_p2: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for OkBranch {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let x_p1 = &self.x_p1;
        let y_p2 = &self.y_p2;
        'm28781: {
            if let crate::lower::model::Ex::XCtor(m28781_0_0, m28781_0_1) = x_p1 && (m28781_0_0 == &Text::lit("Ok")) && (m28781_0_1.len() == 1) && let Some(v_p3) = crate::prelude::index(m28781_0_1, &Nat::from(0u32)) {
                break 'm28781 {
                    let cp_p0x = cp_p0.clone();
                    let y_p2x = y_p2.clone();
                    crate::prelude::call_then(start_cpp_expr_f(cp_p0x.clone(), v_p3.clone()), move |cpp_expr_f_28846: Text| crate::prelude::call_then(start_cpp_expr_f(cp_p0x.clone(), y_p2x.clone()), move |cpp_expr_f_28887: Text| crate::prelude::call_then(start_cpp_expr_f(cp_p0x.clone(), v_p3.clone()), move |cpp_expr_f_28906: Text| prism_rtl::Turn::Finished(Text::from(format!("Expected<std::decay_t<decltype({})>, std::decay_t<decltype({})>>({})", &cpp_expr_f_28846, &cpp_expr_f_28887, &cpp_expr_f_28906))))))
                };
            }
            if let crate::lower::model::Ex::XBlock(dos_p4, m28781_1_1) = x_p1 && let crate::lower::model::Ex::XCtor(m28781_1_1_r_0, m28781_1_1_r_1) = &**m28781_1_1 && (m28781_1_1_r_0 == &Text::lit("Ok")) && (m28781_1_1_r_1.len() == 1) && let Some(v_p5) = crate::prelude::index(m28781_1_1_r_1, &Nat::from(0u32)) {
                break 'm28781 {
                    let cp_p0x = cp_p0.clone();
                    let dos_p4x = dos_p4.clone();
                    let y_p2x = y_p2.clone();
                    crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_statements_cp_f(cp_p0x.clone(), dos_p4x.clone()), move |cpp_statements_cp_f_28986: (Text, crate::emit::cpp::Cp)| {
                        let (st_p6, cp2_p7) = cpp_statements_cp_f_28986;
                        crate::prelude::call_then(start_cpp_expr_f(cp2_p7.clone(), v_p5.clone()), move |cpp_expr_f_29064: Text| crate::prelude::call_then(start_cpp_expr_f(cp2_p7.clone(), y_p2x.clone()), move |cpp_expr_f_29106: Text| crate::prelude::call_then(start_cpp_expr_f(cp2_p7.clone(), v_p5.clone()), move |cpp_expr_f_29126: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::stmt_expr_f(&st_p6, &Text::from(format!("Expected<std::decay_t<decltype({})>, std::decay_t<decltype({})>>({})", &cpp_expr_f_29064, &cpp_expr_f_29106, &cpp_expr_f_29126)))))))
                    })
                };
            }
            prism_rtl::Turn::More(Rc::new(CppExpr { cp_p0: cp_p0.clone(), x_p1: x_p1.clone() }))
        }
    }
}

/// `Start OkBranch, x`: what the function value is when passed to `@Run`.
pub fn start_ok_branch_f(cp_p0: crate::emit::cpp::Cp, x_p1: crate::lower::model::Ex, y_p2: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(OkBranch { cp_p0, x_p1, y_p2 })
}

/// ```prism
/// CppClosure: unbounded fn Cp, Bool, [Pa], Ex -> Text
/// ```
pub fn cpp_closure_f(cp0_p0: &crate::emit::cpp::Cp, mv_p1: &bool, ps_p2: &Array<crate::lower::model::Pa>, body_p3: &crate::lower::model::Ex) -> Text {
    let names_p4 = crate::emit::cpp::patterns::concat2_f(&crate::prelude::run_to_end(crate::prelude::each_job(ps_p2.clone(), Rc::new(move |p0: crate::lower::model::Pa| crate::prelude::entered(crate::prelude::once_job(move || {
        let p_pb = p0;
        prism_rtl::Turn::More(Rc::new(crate::emit::cpp::stmts::PatNames { p_p0: p_pb.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)));
    let cp_p5 = crate::prelude::fold(ps_p2, &crate::emit::cpp::stmts::unbind_f(&crate::emit::cpp::stmts::captured_f(cp0_p0), &names_p4), &(|c_pc: &crate::emit::cpp::Cp, p_pd: &crate::lower::model::Pa| 'm29763: {
        if let crate::lower::model::Pa::PaMut(n_pe) = p_pd {
            break 'm29763 crate::emit::cpp::stmts::owning_f(c_pc, n_pe);
        }
        if let crate::lower::model::Pa::PaTyped(m29763_1_0, _) = p_pd && let crate::lower::model::Pa::PaMut(n_pf) = &**m29763_1_0 {
            break 'm29763 crate::emit::cpp::stmts::owning_f(c_pc, n_pf);
        }
        c_pc.clone()
    }));
    let params_p6 = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(ps_p2)), {
        let cp_p5x = cp_p5.clone();
        let ps_p2x = ps_p2.clone();
        Rc::new(move |p0: Nat| {
            let cp_p5xy = cp_p5x.clone();
            let ps_p2xy = ps_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_pg = p0;
                prism_rtl::Turn::More(Rc::new(ClosureParam { cp_p0: cp_p5xy.clone(), pa1: crate::prelude::or(&crate::prelude::index(&ps_p2xy, &i_pg), &crate::lower::model::Pa::PaWild), i_p3: i_pg.clone() }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "));
    let binds_p7 = crate::prelude::concat(&crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(ps_p2)), {
        let cp_p5x = cp_p5.clone();
        let ps_p2x = ps_p2.clone();
        Rc::new(move |p0: Nat| {
            let cp_p5xy = cp_p5x.clone();
            let ps_p2xy = ps_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_ph = p0;
                prism_rtl::Turn::More(Rc::new(ClosureBinds { cp_p0: cp_p5xy.clone(), pa1: crate::prelude::or(&crate::prelude::index(&ps_p2xy, &i_ph), &crate::lower::model::Pa::PaWild), i_p3: i_ph.clone() }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let b_p8 = cpp_expr_f(&cp_p5, body_p3);
    let moved_p9 = if *mv_p1 {
        crate::prelude::run_to_end(crate::prelude::filter_job(cp0_p0.move_captures_p.clone(), {
            let cp0_p0x = cp0_p0.clone();
            let names_p4x = names_p4.clone();
            let body_p3x = body_p3.clone();
            Rc::new(move |p0: Text| {
                let cp0_p0xy = cp0_p0x.clone();
                let names_p4xy = names_p4x.clone();
                let body_p3xy = body_p3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let n_pi = p0;
                    prism_rtl::Turn::Finished((crate::prelude::or(&crate::prelude::get(&cp0_p0xy.owned_p, &n_pi), &false) && !crate::emit::cpp::in_list_f(&names_p4xy, &n_pi)) && crate::lower::model::ex_reads_f(&body_p3xy, &n_pi))
                }))
            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
        }))
    } else {
        Array::new()
    };
    let capture_pa = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&Array::from(vec![if *mv_p1 { Text::lit("=") } else { Text::lit("&") }]), &crate::prelude::each(&moved_p9, &(|n_pj: &Text| Text::from(format!("{} = std::move({})", &crate::emit::cpp::stmts::var_name_f(cp0_p0, n_pj), &crate::emit::cpp::stmts::var_name_f(cp0_p0, n_pj)))))), &Text::lit(", "));
    let (ret_pk, value_pl) = match body_p3 {
        crate::lower::model::Ex::XRef(_) => (Text::lit(" -> decltype(auto)"), Text::from(format!("({})", &b_p8))),
        crate::lower::model::Ex::XRefMut(_) => (Text::lit(" -> decltype(auto)"), Text::from(format!("({})", &b_p8))),
        _ => (Text::lit(""), b_p8.clone()),
    };
    if (&binds_p7 == &Text::lit("")) && !crate::syntax::lexer::chars::contains_f(&b_p8, &Text::lit("\n")) {
        Text::from(format!("[{}]({}){} {{ return {}; }}", &capture_pa, &params_p6, &ret_pk, &value_pl))
    } else {
        crate::emit::cpp::templates::items::lambda_f(&capture_pa, &Text::from(format!("{}){}", &params_p6, &ret_pk)), &Text::from(format!("{}return {};", &binds_p7, &value_pl)))
    }
}

/// The step machine of `CppClosure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppClosure: unbounded fn Cp, Bool, [Pa], Ex -> Text
/// ```
pub struct CppClosure {
    pub cp0_p0: crate::emit::cpp::Cp,
    pub mv_p1: bool,
    pub ps_p2: Array<crate::lower::model::Pa>,
    pub body_p3: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppClosure {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp0_p0 = &self.cp0_p0;
        let mv_p1 = &self.mv_p1;
        let ps_p2 = &self.ps_p2;
        let body_p3 = &self.body_p3;
        let body_p3x = body_p3.clone();
        let cp0_p0x = cp0_p0.clone();
        let mv_p1x = *mv_p1;
        let ps_p2x = ps_p2.clone();
        crate::prelude::call_value(crate::prelude::each_job(ps_p2x.clone(), Rc::new(move |p0: crate::lower::model::Pa| crate::prelude::entered(crate::prelude::once_job(move || {
            let p_pb = p0;
            prism_rtl::Turn::More(Rc::new(crate::emit::cpp::stmts::PatNames { p_p0: p_pb.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_29675: Array<Array<Text>>| {
            let names_p4 = crate::emit::cpp::patterns::concat2_f(&each_29675);
            let cp_p5 = crate::prelude::fold(&ps_p2x, &crate::emit::cpp::stmts::unbind_f(&crate::emit::cpp::stmts::captured_f(&cp0_p0x), &names_p4), &(|c_pc: &crate::emit::cpp::Cp, p_pd: &crate::lower::model::Pa| 'm29763: {
                if let crate::lower::model::Pa::PaMut(n_pe) = p_pd {
                    break 'm29763 crate::emit::cpp::stmts::owning_f(c_pc, n_pe);
                }
                if let crate::lower::model::Pa::PaTyped(m29763_1_0, _) = p_pd && let crate::lower::model::Pa::PaMut(n_pf) = &**m29763_1_0 {
                    break 'm29763 crate::emit::cpp::stmts::owning_f(c_pc, n_pf);
                }
                c_pc.clone()
            }));
            crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&ps_p2x)), {
                let cp_p5x = cp_p5.clone();
                let ps_p2xx = ps_p2x.clone();
                Rc::new(move |p0: Nat| {
                    let cp_p5xy = cp_p5x.clone();
                    let ps_p2xxy = ps_p2xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let i_pg = p0;
                        prism_rtl::Turn::More(Rc::new(ClosureParam { cp_p0: cp_p5xy.clone(), pa1: crate::prelude::or(&crate::prelude::index(&ps_p2xxy, &i_pg), &crate::lower::model::Pa::PaWild), i_p3: i_pg.clone() }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_29892: Array<Text>| {
                let params_p6 = crate::syntax::lexer::chars::join_f(&each_29892, &Text::lit(", "));
                crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&ps_p2x)), {
                    let cp_p5x = cp_p5.clone();
                    let ps_p2xx = ps_p2x.clone();
                    Rc::new(move |p0: Nat| {
                        let cp_p5xy = cp_p5x.clone();
                        let ps_p2xxy = ps_p2xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let i_ph = p0;
                            prism_rtl::Turn::More(Rc::new(ClosureBinds { cp_p0: cp_p5xy.clone(), pa1: crate::prelude::or(&crate::prelude::index(&ps_p2xxy, &i_ph), &crate::lower::model::Pa::PaWild), i_p3: i_ph.clone() }))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_29991: Array<Text>| {
                    let binds_p7 = crate::prelude::concat(&each_29991);
                    crate::prelude::call_then(start_cpp_expr_f(cp_p5.clone(), body_p3x.clone()), move |cpp_expr_f_30072: Text| {
                        let b_p8 = cpp_expr_f_30072;
                        let moved_p9 = if mv_p1x {
                            crate::prelude::run_to_end(crate::prelude::filter_job(cp0_p0x.move_captures_p.clone(), {
                                let cp0_p0xx = cp0_p0x.clone();
                                let names_p4x = names_p4.clone();
                                let body_p3xx = body_p3x.clone();
                                Rc::new(move |p0: Text| {
                                    let cp0_p0xxy = cp0_p0xx.clone();
                                    let names_p4xy = names_p4x.clone();
                                    let body_p3xxy = body_p3xx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let n_pi = p0;
                                        prism_rtl::Turn::Finished((crate::prelude::or(&crate::prelude::get(&cp0_p0xxy.owned_p, &n_pi), &false) && !crate::emit::cpp::in_list_f(&names_p4xy, &n_pi)) && crate::lower::model::ex_reads_f(&body_p3xxy, &n_pi))
                                    }))
                                }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                            }))
                        } else {
                            Array::new()
                        };
                        let capture_pa = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&Array::from(vec![if mv_p1x { Text::lit("=") } else { Text::lit("&") }]), &crate::prelude::each(&moved_p9, &(|n_pj: &Text| Text::from(format!("{} = std::move({})", &crate::emit::cpp::stmts::var_name_f(&cp0_p0x, n_pj), &crate::emit::cpp::stmts::var_name_f(&cp0_p0x, n_pj)))))), &Text::lit(", "));
                        let (ret_pk, value_pl) = match &body_p3x {
                            crate::lower::model::Ex::XRef(_) => (Text::lit(" -> decltype(auto)"), Text::from(format!("({})", &b_p8))),
                            crate::lower::model::Ex::XRefMut(_) => (Text::lit(" -> decltype(auto)"), Text::from(format!("({})", &b_p8))),
                            _ => (Text::lit(""), b_p8.clone()),
                        };
                        if (&binds_p7 == &Text::lit("")) && !crate::syntax::lexer::chars::contains_f(&b_p8, &Text::lit("\n")) {
                            prism_rtl::Turn::Finished(Text::from(format!("[{}]({}){} {{ return {}; }}", &capture_pa, &params_p6, &ret_pk, &value_pl)))
                        } else {
                            prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::lambda_f(&capture_pa, &Text::from(format!("{}){}", &params_p6, &ret_pk)), &Text::from(format!("{}return {};", &binds_p7, &value_pl))))
                        }
                    })
                })
            })
        })
    }
}

/// `Start CppClosure, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_closure_f(cp0_p0: crate::emit::cpp::Cp, mv_p1: bool, ps_p2: Array<crate::lower::model::Pa>, body_p3: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppClosure { cp0_p0, mv_p1, ps_p2, body_p3 })
}

/// ```prism
/// ClosureParam: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub fn closure_param_f(cp_p0: &crate::emit::cpp::Cp, pa1: &crate::lower::model::Pa, i_p3: &Nat) -> Text {
    'c: {
        if let crate::lower::model::Pa::PaTyped(c0_1_0, t_p2) = pa1 && let crate::lower::model::Pa::PaBind(n_p1) = &**c0_1_0 {
            break 'c Text::from(format!("{} {}", &param_type_f(cp_p0, t_p2), &crate::emit::cpp::cpp_id_f(n_p1)));
        }
        if let crate::lower::model::Pa::PaTyped(c1_1_0, t_p6) = pa1 && let crate::lower::model::Pa::PaMut(n_p5) = &**c1_1_0 {
            break 'c Text::from(format!("{} {}", &crate::emit::cpp::cpp_type_f(cp_p0, &unref_f(t_p6)), &crate::emit::cpp::cpp_id_f(n_p5)));
        }
        if let crate::lower::model::Pa::PaTyped(p_p9, t_pa) = pa1 {
            break 'c Text::from(format!("{} _p{}", &param_type_f(cp_p0, t_pa), i_p3));
        }
        if let crate::lower::model::Pa::PaBind(n_pd) = pa1 {
            break 'c Text::from(format!("auto&& {}", &crate::emit::cpp::cpp_id_f(n_pd)));
        }
        if let crate::lower::model::Pa::PaMut(n_pg) = pa1 {
            break 'c Text::from(format!("auto {}", &crate::emit::cpp::cpp_id_f(n_pg)));
        }
        if let crate::lower::model::Pa::PaWild = pa1 {
            break 'c Text::lit("const auto&");
        }
        if let p_pl = pa1 {
            break 'c Text::from(format!("const auto& _p{}", i_p3));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `ClosureParam`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosureParam: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub struct ClosureParam {
    pub cp_p0: crate::emit::cpp::Cp,
    pub pa1: crate::lower::model::Pa,
    pub i_p3: Nat,
}

impl prism_rtl::Job<Text> for ClosureParam {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let pa1 = &self.pa1;
        let i_p3 = &self.i_p3;
        'j: {
            if let crate::lower::model::Pa::PaTyped(j0_1_0, t_p2) = pa1 && let crate::lower::model::Pa::PaBind(n_p1) = &**j0_1_0 {
                break 'j {
                    let cp_p0x = cp_p0.clone();
                    let n_p1x = n_p1.clone();
                    let t_p2x = t_p2.clone();
                    crate::prelude::call_then(start_param_type_f(cp_p0x.clone(), t_p2x.clone()), move |param_type_f_30805: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_f_30805, &crate::emit::cpp::cpp_id_f(&n_p1x)))))
                };
            }
            if let crate::lower::model::Pa::PaTyped(j1_1_0, t_p6) = pa1 && let crate::lower::model::Pa::PaMut(n_p5) = &**j1_1_0 {
                break 'j {
                    let cp_p0x = cp_p0.clone();
                    let n_p5x = n_p5.clone();
                    let t_p6x = t_p6.clone();
                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), unref_f(&t_p6x)), move |cpp_type_f_30883: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_f_30883, &crate::emit::cpp::cpp_id_f(&n_p5x)))))
                };
            }
            if let crate::lower::model::Pa::PaTyped(p_p9, t_pa) = pa1 {
                break 'j {
                    let cp_p0x = cp_p0.clone();
                    let i_p3x = i_p3.clone();
                    let t_pax = t_pa.clone();
                    crate::prelude::call_then(start_param_type_f(cp_p0x.clone(), t_pax.clone()), move |param_type_f_30959: Text| prism_rtl::Turn::Finished(Text::from(format!("{} _p{}", &param_type_f_30959, &i_p3x))))
                };
            }
            if let crate::lower::model::Pa::PaBind(n_pd) = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::from(format!("auto&& {}", &crate::emit::cpp::cpp_id_f(n_pd))));
            }
            if let crate::lower::model::Pa::PaMut(n_pg) = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::from(format!("auto {}", &crate::emit::cpp::cpp_id_f(n_pg))));
            }
            if let crate::lower::model::Pa::PaWild = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::lit("const auto&"));
            }
            if let p_pl = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::from(format!("const auto& _p{}", i_p3)));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start ClosureParam, x`: what the function value is when passed to `@Run`.
pub fn start_closure_param_f(cp_p0: crate::emit::cpp::Cp, pa1: crate::lower::model::Pa, i_p3: Nat) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ClosureParam { cp_p0, pa1, i_p3 })
}

/// ```prism
/// ClosureBinds: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub fn closure_binds_f(cp_p0: &crate::emit::cpp::Cp, pa1: &crate::lower::model::Pa, i_p3: &Nat) -> Text {
    'c: {
        if let crate::lower::model::Pa::PaTyped(c0_1_0, t_p2) = pa1 && let crate::lower::model::Pa::PaBind(n_p1) = &**c0_1_0 {
            break 'c Text::lit("");
        }
        if let crate::lower::model::Pa::PaTyped(c1_1_0, t_p6) = pa1 && let crate::lower::model::Pa::PaMut(n_p5) = &**c1_1_0 {
            break 'c Text::lit("");
        }
        if let crate::lower::model::Pa::PaTyped(p_p9, t_pa) = pa1 {
            break 'c closure_binds_f(cp_p0, &**p_p9, i_p3);
        }
        if let crate::lower::model::Pa::PaBind(n_pd) = pa1 {
            break 'c Text::lit("");
        }
        if let crate::lower::model::Pa::PaMut(n_pg) = pa1 {
            break 'c Text::lit("");
        }
        if let crate::lower::model::Pa::PaWild = pa1 {
            break 'c Text::lit("");
        }
        if let p_pl = pa1 {
            break 'c crate::prelude::concat(&crate::prelude::each(&crate::emit::cpp::patterns::pat_binds_f(cp_p0, p_pl, &Text::from(format!("_p{}", i_p3))), &(|b_pn: &Text| Text::from(format!("{}\n", b_pn)))));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `ClosureBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosureBinds: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub struct ClosureBinds {
    pub cp_p0: crate::emit::cpp::Cp,
    pub pa1: crate::lower::model::Pa,
    pub i_p3: Nat,
}

impl prism_rtl::Job<Text> for ClosureBinds {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let pa1 = &self.pa1;
        let i_p3 = &self.i_p3;
        'j: {
            if let crate::lower::model::Pa::PaTyped(j0_1_0, t_p2) = pa1 && let crate::lower::model::Pa::PaBind(n_p1) = &**j0_1_0 {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let crate::lower::model::Pa::PaTyped(j1_1_0, t_p6) = pa1 && let crate::lower::model::Pa::PaMut(n_p5) = &**j1_1_0 {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let crate::lower::model::Pa::PaTyped(p_p9, t_pa) = pa1 {
                break 'j prism_rtl::Turn::More(Rc::new(ClosureBinds { cp_p0: cp_p0.clone(), pa1: (**p_p9).clone(), i_p3: i_p3.clone() }));
            }
            if let crate::lower::model::Pa::PaBind(n_pd) = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let crate::lower::model::Pa::PaMut(n_pg) = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let crate::lower::model::Pa::PaWild = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let p_pl = pa1 {
                break 'j {
                    let cp_p0x = cp_p0.clone();
                    let i_p3x = i_p3.clone();
                    let p_plx = p_pl.clone();
                    crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_binds_f(cp_p0x.clone(), p_plx.clone(), Text::from(format!("_p{}", &i_p3x))), move |pat_binds_f_31549: Array<Text>| prism_rtl::Turn::Finished(crate::prelude::concat(&crate::prelude::each(&pat_binds_f_31549, &(|b_pn: &Text| Text::from(format!("{}\n", b_pn)))))))
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start ClosureBinds, x`: what the function value is when passed to `@Run`.
pub fn start_closure_binds_f(cp_p0: crate::emit::cpp::Cp, pa1: crate::lower::model::Pa, i_p3: Nat) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ClosureBinds { cp_p0, pa1, i_p3 })
}

/// ```prism
/// Unref: fn OutTy -> OutTy
/// ```
pub fn unref_f(out_ty0: &crate::lower::model::OutTy) -> crate::lower::model::OutTy {
    match out_ty0 {
        crate::lower::model::OutTy::OutRef(t_p0) => (**t_p0).clone(),
        t_p1 => t_p1.clone(),
    }
}

/// ```prism
/// ParamType: unbounded fn Cp, OutTy -> Text
/// ```
pub fn param_type_f(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::OutTy) -> Text {
    match t_p1 {
        crate::lower::model::OutTy::OutRef(_) => crate::emit::cpp::cpp_type_f(cp_p0, t_p1),
        crate::lower::model::OutTy::OutSlice(_) => crate::emit::cpp::cpp_type_f(cp_p0, t_p1),
        crate::lower::model::OutTy::OutUnit => Text::lit("Unit"),
        _ => crate::emit::cpp::cpp_type_f(cp_p0, t_p1),
    }
}

/// The step machine of `ParamType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParamType: unbounded fn Cp, OutTy -> Text
/// ```
pub struct ParamType {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for ParamType {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        match t_p1 {
            crate::lower::model::OutTy::OutRef(_) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::CppType { cp_p0: cp_p0.clone(), t_p1: t_p1.clone() })),
            crate::lower::model::OutTy::OutSlice(_) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::CppType { cp_p0: cp_p0.clone(), t_p1: t_p1.clone() })),
            crate::lower::model::OutTy::OutUnit => prism_rtl::Turn::Finished(Text::lit("Unit")),
            _ => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::CppType { cp_p0: cp_p0.clone(), t_p1: t_p1.clone() })),
        }
    }
}

/// `Start ParamType, x`: what the function value is when passed to `@Run`.
pub fn start_param_type_f(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ParamType { cp_p0, t_p1 })
}
