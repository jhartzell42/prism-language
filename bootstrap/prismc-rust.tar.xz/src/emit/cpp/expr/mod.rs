//! The module `Emit.Cpp.Expr`, from `target/bootstrap/src/prismc/emit/cpp/expr.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// CppLoose: fn Ex -> Bool
/// ```
pub fn cpp_loose(x: &crate::lower::model::Ex) -> bool {
    match x {
        crate::lower::model::Ex::XBlock(m1173_0_0, inner) if (m1173_0_0.len() == 0) => cpp_loose(&**inner),
        crate::lower::model::Ex::XBin(_, _, _) => true,
        crate::lower::model::Ex::XUnary(_, _) => true,
        crate::lower::model::Ex::XIf(_, _, _) => true,
        crate::lower::model::Ex::XRef(y) => cpp_loose(&**y),
        crate::lower::model::Ex::XRefMut(y) => cpp_loose(&**y),
        crate::lower::model::Ex::XDeref(y) => cpp_loose(&**y),
        crate::lower::model::Ex::XClone(y) => cpp_loose(&**y),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CppTight: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_tight(cp: &crate::emit::cpp::Cp, x: &crate::lower::model::Ex) -> Text {
    if cpp_loose(x) {
        Text::from(format!("({})", &cpp_expr(cp, x)))
    } else {
        cpp_expr(cp, x)
    }
}

/// The step machine of `CppTight`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppTight: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppTight {
    pub cp: crate::emit::cpp::Cp,
    pub x: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppTight {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let x = &self.x;
        if cpp_loose(x) {
            {
                let cp = cp.clone();
                let x = x.clone();
                call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_1525: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &cpp_expr_1525))))
            }
        } else {
            prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: x.clone() }))
        }
    }
}

/// `Start CppTight, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_tight(cp: crate::emit::cpp::Cp, x: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppTight { cp, x })
}

/// ```prism
/// CppArgs: unbounded fn Cp, [Ex] -> Text
/// ```
pub fn cpp_args(cp: &crate::emit::cpp::Cp, xs: &Array<crate::lower::model::Ex>) -> Text {
    crate::syntax::lexer::chars::join(&run_to_end(each_job(xs.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::Ex| {
            let cp = cp.clone();
            entered(once_job(move || {
                let x = p0;
                prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: x.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "))
}

/// The step machine of `CppArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppArgs: unbounded fn Cp, [Ex] -> Text
/// ```
pub struct CppArgs {
    pub cp: crate::emit::cpp::Cp,
    pub xs: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for CppArgs {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let xs = &self.xs;
        let cp = cp.clone();
        let xs = xs.clone();
        call_value(each_job(xs.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: crate::lower::model::Ex| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let x = p0;
                    prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: x.clone() }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_1628: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&each_1628, &Text::lit(", "))))
    }
}

/// `Start CppArgs, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_args(cp: crate::emit::cpp::Cp, xs: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppArgs { cp, xs })
}

/// ```prism
/// CppExpr: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_expr(cp: &crate::emit::cpp::Cp, x: &crate::lower::model::Ex) -> Text {
    match x {
        crate::lower::model::Ex::XVar(n) => crate::emit::cpp::stmts::var_name(cp, n),
        crate::lower::model::Ex::XPath(p_) => path_value(cp, p_),
        crate::lower::model::Ex::XSelf => Text::lit("prism_rtl::share(this)"),
        crate::lower::model::Ex::XCx => Text::lit("cx"),
        crate::lower::model::Ex::XConst(n) => n.clone(),
        crate::lower::model::Ex::XUnit => Text::lit("Unit{}"),
        crate::lower::model::Ex::XNone => Text::lit("std::nullopt"),
        crate::lower::model::Ex::XBool(b) => if *b { Text::lit("true") } else { Text::lit("false") },
        crate::lower::model::Ex::XNat(d) => if &len_text(d) <= &Nat::from(9u32) {
            Text::from(format!("Nat({}u)", d))
        } else {
            Text::from(format!("*Nat::from_int({})", &cpp_expr(cp, &crate::lower::model::Ex::XInt(d.clone()))))
        },
        crate::lower::model::Ex::XInt(d) => if &len_text(&(if crate::syntax::lexer::chars::has_prefix(d, &Text::lit("-")) {
            crate::syntax::lexer::chars::after_first(d)
        } else {
            d.clone()
        })) <= &Nat::from(18u32) {
            Text::from(format!("Int({}ll)", d))
        } else {
            Text::from(format!("*Int::parse(\"{}\")", d))
        },
        crate::lower::model::Ex::XByte(d) => Text::from(format!("std::uint8_t({})", d)),
        crate::lower::model::Ex::XFloat(d) => d.clone(),
        crate::lower::model::Ex::XIndex(n) => Text::from(format!("{}u", n)),
        crate::lower::model::Ex::XChar(c) => Text::from(format!("U\'{}\'", &cpp_char_escape(c))),
        crate::lower::model::Ex::XStr(t) => cpp_string(t),
        crate::lower::model::Ex::XRef(y) => cpp_expr(cp, &**y),
        crate::lower::model::Ex::XRefMut(y) => cpp_expr(cp, &**y),
        crate::lower::model::Ex::XDeref(y) => cpp_expr(cp, &**y),
        crate::lower::model::Ex::XTarget(y) => cpp_expr(cp, &**y),
        crate::lower::model::Ex::XClone(y) => cpp_expr(cp, &**y),
        crate::lower::model::Ex::XWeak(y) => Text::from(format!("prism_rtl::weaken({})", &cpp_expr(cp, &**y))),
        crate::lower::model::Ex::XUpgrade(y) => Text::from(format!("prism_rtl::upgrade({})", &cpp_expr(cp, &**y))),
        crate::lower::model::Ex::XBreak(l, y) => Text::from(format!("({})", &crate::emit::cpp::patterns::cpp_break(cp, l, &**y))),
        crate::lower::model::Ex::XBreakLoop => Text::lit("({ break; })"),
        crate::lower::model::Ex::XLater(y) => Text::from(format!("[=](Cx& cx) -> Done {{ {}; return {{}}; }}", &cpp_expr(cp, &**y))),
        crate::lower::model::Ex::XFormatStr(parts) => cpp_format(cp, parts, &Text::lit("prism_rtl::str")),
        crate::lower::model::Ex::XIsCase(y, m1720_26_1) if (m1720_26_1.len() == 0) => Text::lit("false"),
        crate::lower::model::Ex::XIsCase(y, cs) => Text::from(format!("({})", &crate::syntax::lexer::chars::join(&run_to_end(each_job(cs.clone(), {
            let cp = cp.clone();
            let y = (**y).clone();
            Rc::new(move |p0: Text| {
                let cp = cp.clone();
                let y = y.clone();
                entered(once_job(move || {
                    let c = p0;
                    call_then(start_cpp_tight(cp.clone(), y.clone()), move |cpp_tight_2810: Text| prism_rtl::Turn::Finished(case_test(&cp, &c, &cpp_tight_2810)))
                }))
            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>
        })), &Text::lit(" || ")))),
        crate::lower::model::Ex::XRefusal(what) => Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::expr::lowering_refusal(), &crate::lower::expr::escape(what))),
        crate::lower::model::Ex::XUnreachable => Text::lit("throw prism_rtl::Panic(\"entered unreachable code\")"),
        crate::lower::model::Ex::XCall(f, args) => cpp_call(cp, f, args),
        crate::lower::model::Ex::XApply(f, args) => Text::from(format!("{}({})", &cpp_tight(cp, &**f), &cpp_args(cp, args))),
        crate::lower::model::Ex::XMethod(r, m, args) => cpp_method(cp, &**r, m, args),
        crate::lower::model::Ex::XBin(op, l, r) => Text::from(format!("{} {} {}", &cpp_tight(cp, &**l), op, &cpp_tight(cp, &**r))),
        crate::lower::model::Ex::XUnary(op, y) => Text::from(format!("{}{}", op, &cpp_tight(cp, &**y))),
        crate::lower::model::Ex::XCtor(p_, args) => cpp_ctor(cp, p_, args),
        crate::lower::model::Ex::XRecord(p_, fs) => cpp_record(cp, p_, fs),
        crate::lower::model::Ex::XTuple(xs) => Text::from(format!("std::tuple{{{}}}", &cpp_args(cp, xs))),
        crate::lower::model::Ex::XVec(m1720_38_0) if (m1720_38_0.len() == 0) => Text::lit("{}"),
        crate::lower::model::Ex::XVec(xs) => Text::from(format!("std::vector{{{}}}", &cpp_args(cp, xs))),
        crate::lower::model::Ex::XText(t) => Text::from(format!("Text::lit({})", &cpp_string(t))),
        crate::lower::model::Ex::XFormat(parts) => if fold(parts, &true, &(|f: &bool, p_: &crate::lower::model::Ex| *f && is_text_piece(p_))) {
            Text::from(format!("Text::lit({})", &cpp_string(&concat(&each(parts, &(|p_: &crate::lower::model::Ex| text_piece(p_)))))))
        } else {
            cpp_format(cp, parts, &Text::lit("prism_rtl::cat"))
        },
        crate::lower::model::Ex::XMatch(s, arms, fallback, t) => crate::emit::cpp::patterns::cpp_match(cp, &**s, arms, t),
        crate::lower::model::Ex::XChain(label, s, arms, t) => crate::emit::cpp::patterns::cpp_match(cp, &**s, arms, t),
        crate::lower::model::Ex::XIf(c, t, e) => cpp_if(cp, &**c, &**t, &**e),
        crate::lower::model::Ex::XBlock(m1720_45_0, e) if (m1720_45_0.len() == 0) => cpp_expr(cp, &**e),
        crate::lower::model::Ex::XBlock(dos, e) => {
            let (st, cp2) = crate::emit::cpp::stmts::cpp_statements_cp(cp, dos);
            crate::emit::cpp::templates::items::stmt_expr(&st, &crate::emit::cpp::stmts::unvexed(&cpp_expr(&cp2, &**e)))
        },
        crate::lower::model::Ex::XLabeled(label, dos, e, t) => crate::emit::cpp::patterns::cpp_labeled(cp, label, dos, &**e, t),
        crate::lower::model::Ex::XClosure(mv, ps, body) => cpp_closure(cp, mv, ps, &**body),
        crate::lower::model::Ex::XTry(y) => Text::from(format!("TRY({})", &cpp_expr(cp, &**y))),
        crate::lower::model::Ex::XField(r, f) => cpp_field(cp, &**r, f),
        crate::lower::model::Ex::XPart(r, k) => Text::from(format!("std::get<{}>({})", k, &cpp_expr(cp, &**r))),
        crate::lower::model::Ex::XDecode(t, y) => Text::from(format!("TRY(prism_rtl::from_pod<{}>({}))", &crate::emit::cpp::cpp_type(cp, t), &cpp_expr(cp, &**y))),
        crate::lower::model::Ex::XCast(y, t) => Text::from(format!("static_cast<{}>({})", &crate::emit::cpp::cpp_type(cp, t), &cpp_expr(cp, &**y))),
        crate::lower::model::Ex::XTyped(y, t) => {
            let e = cpp_expr(cp, &**y);
            if (&e == &Text::lit("{}")) || (&e == &Text::lit("std::nullopt")) {
                Text::from(format!("{}{{}}", &crate::emit::cpp::cpp_type(cp, t)))
            } else {
                if is_ctor(&**y, &Text::lit("Ok")) || is_ctor(&**y, &Text::lit("Err")) {
                    Text::from(format!("{}({})", &crate::emit::cpp::cpp_type(cp, t), &e))
                } else {
                    e.clone()
                }
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CppExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppExpr: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppExpr {
    pub cp: crate::emit::cpp::Cp,
    pub x: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppExpr {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let x = &self.x;
        match x {
            crate::lower::model::Ex::XVar(n) => prism_rtl::Turn::Finished(crate::emit::cpp::stmts::var_name(cp, n)),
            crate::lower::model::Ex::XPath(p_) => prism_rtl::Turn::Finished(path_value(cp, p_)),
            crate::lower::model::Ex::XSelf => prism_rtl::Turn::Finished(Text::lit("prism_rtl::share(this)")),
            crate::lower::model::Ex::XCx => prism_rtl::Turn::Finished(Text::lit("cx")),
            crate::lower::model::Ex::XConst(n) => prism_rtl::Turn::Finished(n.clone()),
            crate::lower::model::Ex::XUnit => prism_rtl::Turn::Finished(Text::lit("Unit{}")),
            crate::lower::model::Ex::XNone => prism_rtl::Turn::Finished(Text::lit("std::nullopt")),
            crate::lower::model::Ex::XBool(b) => if *b {
                prism_rtl::Turn::Finished(Text::lit("true"))
            } else {
                prism_rtl::Turn::Finished(Text::lit("false"))
            },
            crate::lower::model::Ex::XNat(d) => if &len_text(d) <= &Nat::from(9u32) {
                prism_rtl::Turn::Finished(Text::from(format!("Nat({}u)", d)))
            } else {
                {
                    let cp = cp.clone();
                    let d = d.clone();
                    call_then(start_cpp_expr(cp.clone(), crate::lower::model::Ex::XInt(d.clone())), move |cpp_expr_2002: Text| prism_rtl::Turn::Finished(Text::from(format!("*Nat::from_int({})", &cpp_expr_2002))))
                }
            },
            crate::lower::model::Ex::XInt(d) => if &len_text(&(if crate::syntax::lexer::chars::has_prefix(d, &Text::lit("-")) {
                crate::syntax::lexer::chars::after_first(d)
            } else {
                d.clone()
            })) <= &Nat::from(18u32) {
                prism_rtl::Turn::Finished(Text::from(format!("Int({}ll)", d)))
            } else {
                prism_rtl::Turn::Finished(Text::from(format!("*Int::parse(\"{}\")", d)))
            },
            crate::lower::model::Ex::XByte(d) => prism_rtl::Turn::Finished(Text::from(format!("std::uint8_t({})", d))),
            crate::lower::model::Ex::XFloat(d) => prism_rtl::Turn::Finished(d.clone()),
            crate::lower::model::Ex::XIndex(n) => prism_rtl::Turn::Finished(Text::from(format!("{}u", n))),
            crate::lower::model::Ex::XChar(c) => prism_rtl::Turn::Finished(Text::from(format!("U\'{}\'", &cpp_char_escape(c)))),
            crate::lower::model::Ex::XStr(t) => prism_rtl::Turn::Finished(cpp_string(t)),
            crate::lower::model::Ex::XRef(y) => prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: (**y).clone() })),
            crate::lower::model::Ex::XRefMut(y) => prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: (**y).clone() })),
            crate::lower::model::Ex::XDeref(y) => prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: (**y).clone() })),
            crate::lower::model::Ex::XTarget(y) => prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: (**y).clone() })),
            crate::lower::model::Ex::XClone(y) => prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: (**y).clone() })),
            crate::lower::model::Ex::XWeak(y) => {
                let cp = cp.clone();
                let y = (**y).clone();
                call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_2445: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::weaken({})", &cpp_expr_2445))))
            },
            crate::lower::model::Ex::XUpgrade(y) => {
                let cp = cp.clone();
                let y = (**y).clone();
                call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_2499: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::upgrade({})", &cpp_expr_2499))))
            },
            crate::lower::model::Ex::XBreak(l, y) => {
                let cp = cp.clone();
                let l = l.clone();
                let y = (**y).clone();
                call_then(crate::emit::cpp::patterns::start_cpp_break(cp.clone(), l.clone(), y.clone()), move |cpp_break_2536: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &cpp_break_2536))))
            },
            crate::lower::model::Ex::XBreakLoop => prism_rtl::Turn::Finished(Text::lit("({ break; })")),
            crate::lower::model::Ex::XLater(y) => {
                let cp = cp.clone();
                let y = (**y).clone();
                call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_2629: Text| prism_rtl::Turn::Finished(Text::from(format!("[=](Cx& cx) -> Done {{ {}; return {{}}; }}", &cpp_expr_2629))))
            },
            crate::lower::model::Ex::XFormatStr(parts) => prism_rtl::Turn::More(Rc::new(CppFormat { cp: cp.clone(), parts: parts.clone(), how: Text::lit("prism_rtl::str") })),
            crate::lower::model::Ex::XIsCase(y, m1720_26_1) if (m1720_26_1.len() == 0) => prism_rtl::Turn::Finished(Text::lit("false")),
            crate::lower::model::Ex::XIsCase(y, cs) => {
                let cp = cp.clone();
                let cs = cs.clone();
                let y = (**y).clone();
                call_value(each_job(cs.clone(), {
                    let cp = cp.clone();
                    let y = y.clone();
                    Rc::new(move |p0: Text| {
                        let cp = cp.clone();
                        let y = y.clone();
                        entered(once_job(move || {
                            let c = p0;
                            call_then(start_cpp_tight(cp.clone(), y.clone()), move |cpp_tight_2810: Text| prism_rtl::Turn::Finished(case_test(&cp, &c, &cpp_tight_2810)))
                        }))
                    }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_2779: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("({})", &crate::syntax::lexer::chars::join(&each_2779, &Text::lit(" || "))))))
            },
            crate::lower::model::Ex::XRefusal(what) => prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::expr::lowering_refusal(), &crate::lower::expr::escape(what)))),
            crate::lower::model::Ex::XUnreachable => prism_rtl::Turn::Finished(Text::lit("throw prism_rtl::Panic(\"entered unreachable code\")")),
            crate::lower::model::Ex::XCall(f, args) => prism_rtl::Turn::More(Rc::new(CppCall { cp: cp.clone(), f: f.clone(), args: args.clone() })),
            crate::lower::model::Ex::XApply(f, args) => {
                let args = args.clone();
                let cp = cp.clone();
                let f = (**f).clone();
                call_then(start_cpp_tight(cp.clone(), f.clone()), move |cpp_tight_3044: Text| call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_3061: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &cpp_tight_3044, &cpp_args_3061)))))
            },
            crate::lower::model::Ex::XMethod(r, m, args) => prism_rtl::Turn::More(Rc::new(CppMethod { cp: cp.clone(), r: (**r).clone(), m: m.clone(), args: args.clone() })),
            crate::lower::model::Ex::XBin(op, l, r) => {
                let cp = cp.clone();
                let l = (**l).clone();
                let op = op.clone();
                let r = (**r).clone();
                call_then(start_cpp_tight(cp.clone(), l.clone()), move |cpp_tight_3151: Text| call_then(start_cpp_tight(cp.clone(), r.clone()), move |cpp_tight_3173: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {} {}", &cpp_tight_3151, &op, &cpp_tight_3173)))))
            },
            crate::lower::model::Ex::XUnary(op, y) => {
                let cp = cp.clone();
                let op = op.clone();
                let y = (**y).clone();
                call_then(start_cpp_tight(cp.clone(), y.clone()), move |cpp_tight_3214: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &op, &cpp_tight_3214))))
            },
            crate::lower::model::Ex::XCtor(p_, args) => prism_rtl::Turn::More(Rc::new(CppCtor { cp: cp.clone(), p_: p_.clone(), args: args.clone() })),
            crate::lower::model::Ex::XRecord(p_, fs) => prism_rtl::Turn::More(Rc::new(CppRecord { cp: cp.clone(), p_: p_.clone(), fs: fs.clone() })),
            crate::lower::model::Ex::XTuple(xs) => {
                let cp = cp.clone();
                let xs = xs.clone();
                call_then(start_cpp_args(cp.clone(), xs.clone()), move |cpp_args_3338: Text| prism_rtl::Turn::Finished(Text::from(format!("std::tuple{{{}}}", &cpp_args_3338))))
            },
            crate::lower::model::Ex::XVec(m1720_38_0) if (m1720_38_0.len() == 0) => prism_rtl::Turn::Finished(Text::lit("{}")),
            crate::lower::model::Ex::XVec(xs) => {
                let cp = cp.clone();
                let xs = xs.clone();
                call_then(start_cpp_args(cp.clone(), xs.clone()), move |cpp_args_3407: Text| prism_rtl::Turn::Finished(Text::from(format!("std::vector{{{}}}", &cpp_args_3407))))
            },
            crate::lower::model::Ex::XText(t) => prism_rtl::Turn::Finished(Text::from(format!("Text::lit({})", &cpp_string(t)))),
            crate::lower::model::Ex::XFormat(parts) => if fold(parts, &true, &(|f: &bool, p_: &crate::lower::model::Ex| *f && is_text_piece(p_))) {
                prism_rtl::Turn::Finished(Text::from(format!("Text::lit({})", &cpp_string(&concat(&each(parts, &(|p_: &crate::lower::model::Ex| text_piece(p_))))))))
            } else {
                prism_rtl::Turn::More(Rc::new(CppFormat { cp: cp.clone(), parts: parts.clone(), how: Text::lit("prism_rtl::cat") }))
            },
            crate::lower::model::Ex::XMatch(s, arms, fallback, t) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::patterns::CppMatch { cp: cp.clone(), s: (**s).clone(), arms: arms.clone(), out_ty3: t.clone() })),
            crate::lower::model::Ex::XChain(label, s, arms, t) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::patterns::CppMatch { cp: cp.clone(), s: (**s).clone(), arms: arms.clone(), out_ty3: t.clone() })),
            crate::lower::model::Ex::XIf(c, t, e) => prism_rtl::Turn::More(Rc::new(CppIf { cp: cp.clone(), c: (**c).clone(), t: (**t).clone(), e: (**e).clone() })),
            crate::lower::model::Ex::XBlock(m1720_45_0, e) if (m1720_45_0.len() == 0) => prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: (**e).clone() })),
            crate::lower::model::Ex::XBlock(dos, e) => {
                let cp = cp.clone();
                let dos = dos.clone();
                let e = (**e).clone();
                call_then(crate::emit::cpp::stmts::start_cpp_statements_cp(cp.clone(), dos.clone()), move |cpp_statements_cp_3869: (Text, crate::emit::cpp::Cp)| {
                    let (st, cp2) = cpp_statements_cp_3869;
                    call_then(start_cpp_expr(cp2.clone(), e.clone()), move |cpp_expr_3924: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::stmt_expr(&st, &crate::emit::cpp::stmts::unvexed(&cpp_expr_3924))))
                })
            },
            crate::lower::model::Ex::XLabeled(label, dos, e, t) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::patterns::CppLabeled { cp: cp.clone(), label: label.clone(), dos: dos.clone(), e: (**e).clone(), t: t.clone() })),
            crate::lower::model::Ex::XClosure(mv, ps, body) => prism_rtl::Turn::More(Rc::new(CppClosure { cp0: cp.clone(), mv: *mv, ps: ps.clone(), body: (**body).clone() })),
            crate::lower::model::Ex::XTry(y) => {
                let cp = cp.clone();
                let y = (**y).clone();
                call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_4077: Text| prism_rtl::Turn::Finished(Text::from(format!("TRY({})", &cpp_expr_4077))))
            },
            crate::lower::model::Ex::XField(r, f) => prism_rtl::Turn::More(Rc::new(CppField { cp: cp.clone(), ex1: (**r).clone(), f: f.clone() })),
            crate::lower::model::Ex::XPart(r, k) => {
                let cp = cp.clone();
                let k = k.clone();
                let r = (**r).clone();
                call_then(start_cpp_expr(cp.clone(), r.clone()), move |cpp_expr_4161: Text| prism_rtl::Turn::Finished(Text::from(format!("std::get<{}>({})", &k, &cpp_expr_4161))))
            },
            crate::lower::model::Ex::XDecode(t, y) => {
                let cp = cp.clone();
                let t = t.clone();
                let y = (**y).clone();
                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), t.clone()), move |cpp_type_4222: Text| call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_4239: Text| prism_rtl::Turn::Finished(Text::from(format!("TRY(prism_rtl::from_pod<{}>({}))", &cpp_type_4222, &cpp_expr_4239)))))
            },
            crate::lower::model::Ex::XCast(y, t) => {
                let cp = cp.clone();
                let t = t.clone();
                let y = (**y).clone();
                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), t.clone()), move |cpp_type_4287: Text| call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_4304: Text| prism_rtl::Turn::Finished(Text::from(format!("static_cast<{}>({})", &cpp_type_4287, &cpp_expr_4304)))))
            },
            crate::lower::model::Ex::XTyped(y, t) => {
                let cp = cp.clone();
                let t = t.clone();
                let y = (**y).clone();
                call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_4354: Text| {
                    let e = cpp_expr_4354;
                    if (&e == &Text::lit("{}")) || (&e == &Text::lit("std::nullopt")) {
                        call_then(crate::emit::cpp::start_cpp_type(cp.clone(), t.clone()), move |cpp_type_4417: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{{}}", &cpp_type_4417))))
                    } else {
                        if is_ctor(&y, &Text::lit("Ok")) || is_ctor(&y, &Text::lit("Err")) {
                            call_then(crate::emit::cpp::start_cpp_type(cp.clone(), t.clone()), move |cpp_type_4493: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &cpp_type_4493, &e))))
                        } else {
                            prism_rtl::Turn::Finished(e.clone())
                        }
                    }
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start CppExpr, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_expr(cp: crate::emit::cpp::Cp, x: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppExpr { cp, x })
}

/// ```prism
/// CppString: fn Text -> Text
/// ```
pub fn cpp_string(t: &Text) -> Text {
    if crate::syntax::lexer::chars::contains(t, &Text::lit("\0")) {
        Text::from(format!("\"{}\"sv", &cpp_escape(t)))
    } else {
        Text::from(format!("\"{}\"", &cpp_escape(t)))
    }
}

/// ```prism
/// CppEscape: fn Text -> Text
/// ```
pub fn cpp_escape(t: &Text) -> Text {
    crate::syntax::lexer::chars::map_chars(t, &(Rc::new(move |p0: Text| once_job(move || {
        let c = p0;
        if &c == &Text::lit("\0") {
            prism_rtl::Turn::Finished(Text::lit("\\000"))
        } else {
            prism_rtl::Turn::Finished(crate::lower::expr::char_escape(&c))
        }
    })) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>))
}

/// ```prism
/// IsTextPiece: fn Ex -> Bool
/// ```
pub fn is_text_piece(ex0: &crate::lower::model::Ex) -> bool {
    match ex0 {
        crate::lower::model::Ex::XText(_) => true,
        other => false,
    }
}

/// ```prism
/// TextPiece: fn Ex -> Text
/// ```
pub fn text_piece(ex0: &crate::lower::model::Ex) -> Text {
    match ex0 {
        crate::lower::model::Ex::XText(t) => t.clone(),
        other => Text::lit(""),
    }
}

/// ```prism
/// CppFormat: unbounded fn Cp, [Ex], Text -> Text
/// ```
pub fn cpp_format(cp: &crate::emit::cpp::Cp, parts: &Array<crate::lower::model::Ex>, how: &Text) -> Text {
    Text::from(format!("{}({})", how, &crate::syntax::lexer::chars::join(&run_to_end(each_job(parts.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::Ex| {
            let cp = cp.clone();
            entered(once_job(move || {
                let p_ = p0;
                prism_rtl::Turn::More(Rc::new(FormatArg { cp: cp.clone(), ex1: p_.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "))))
}

/// The step machine of `CppFormat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppFormat: unbounded fn Cp, [Ex], Text -> Text
/// ```
pub struct CppFormat {
    pub cp: crate::emit::cpp::Cp,
    pub parts: Array<crate::lower::model::Ex>,
    pub how: Text,
}

impl prism_rtl::Job<Text> for CppFormat {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let parts = &self.parts;
        let how = &self.how;
        let cp = cp.clone();
        let how = how.clone();
        let parts = parts.clone();
        call_value(each_job(parts.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: crate::lower::model::Ex| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let p_ = p0;
                    prism_rtl::Turn::More(Rc::new(FormatArg { cp: cp.clone(), ex1: p_.clone() }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_5285: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &how, &crate::syntax::lexer::chars::join(&each_5285, &Text::lit(", "))))))
    }
}

/// `Start CppFormat, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_format(cp: crate::emit::cpp::Cp, parts: Array<crate::lower::model::Ex>, how: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppFormat { cp, parts, how })
}

/// ```prism
/// FormatArg: unbounded fn Cp, Ex -> Text
/// ```
pub fn format_arg(cp: &crate::emit::cpp::Cp, ex1: &crate::lower::model::Ex) -> Text {
    match ex1 {
        crate::lower::model::Ex::XText(t) => cpp_string(t),
        x => cpp_expr(cp, x),
    }
}

/// The step machine of `FormatArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FormatArg: unbounded fn Cp, Ex -> Text
/// ```
pub struct FormatArg {
    pub cp: crate::emit::cpp::Cp,
    pub ex1: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for FormatArg {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let ex1 = &self.ex1;
        match ex1 {
            crate::lower::model::Ex::XText(t) => prism_rtl::Turn::Finished(cpp_string(t)),
            x => prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: x.clone() })),
        }
    }
}

/// `Start FormatArg, x`: what the function value is when passed to `@Run`.
pub fn start_format_arg(cp: crate::emit::cpp::Cp, ex1: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FormatArg { cp, ex1 })
}

/// ```prism
/// CppCharEscape: fn Text -> Text
/// ```
pub fn cpp_char_escape(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("\'")) => Text::lit("\\\'"),
        c => crate::lower::expr::char_escape(c),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// PathValue: fn Cp, Text -> Text
/// ```
pub fn path_value(cp: &crate::emit::cpp::Cp, p_: &Text) -> Text {
    if is_node_method(cp, p_) {
        Text::from(format!("&{}::{}", &crate::emit::cpp::type_path(&crate::emit::cpp::parent_path(p_)), &node_method_name(cp, &crate::emit::cpp::last_segment(p_))))
    } else {
        match crate::emit::cpp::case_of(cp, p_) {
            Some(ty) => Text::from(format!("{}({}{{}})", &crate::emit::cpp::type_path(&ty), &crate::emit::cpp::type_path(p_))),
            None => match crate::emit::cpp::type_of(cp, p_) {
                Some(info) => if &info.kind == &Text::lit("unit") {
                    Text::from(format!("{}{{}}", &crate::emit::cpp::type_path(p_)))
                } else {
                    crate::emit::cpp::type_path(p_)
                },
                None => crate::emit::cpp::type_path(p_),
            },
        }
    }
}

/// ```prism
/// IsNodeMethod: fn Cp, Text -> Bool
/// ```
pub fn is_node_method(cp: &crate::emit::cpp::Cp, p_: &Text) -> bool {
    let named = match get(&cp.methods, &crate::emit::cpp::last_segment(p_)) {
        Some(_) => true,
        None => false,
    };
    named && is_node_type(cp, &crate::emit::cpp::parent_path(p_))
}

/// ```prism
/// IsNodeType: fn Cp, Text -> Bool
/// ```
pub fn is_node_type(cp: &crate::emit::cpp::Cp, p_: &Text) -> bool {
    match crate::emit::cpp::type_of(cp, p_) {
        Some(info) => &info.kind == &Text::lit("node"),
        None => false,
    }
}

/// ```prism
/// CppField: unbounded fn Cp, Ex, Text -> Text
/// ```
pub fn cpp_field(cp: &crate::emit::cpp::Cp, ex1: &crate::lower::model::Ex, f: &Text) -> Text {
    match ex1 {
        crate::lower::model::Ex::XSelf => Text::from(format!("this->{}", &crate::emit::cpp::field_id(f))),
        r => {
            let name = if is_digits(f) {
                Text::from(format!("a{}", f))
            } else {
                crate::emit::cpp::field_id(f)
            };
            let through = match pointer(cp, r) {
                Some(b) => if b { Text::lit("->") } else { Text::lit(".") },
                None => match get(&cp.members, f) {
                    Some(_) => Text::lit("->"),
                    None => Text::lit("."),
                },
            };
            Text::from(format!("{}{}{}", &cpp_tight(cp, r), &through, &name))
        },
    }
}

/// The step machine of `CppField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppField: unbounded fn Cp, Ex, Text -> Text
/// ```
pub struct CppField {
    pub cp: crate::emit::cpp::Cp,
    pub ex1: crate::lower::model::Ex,
    pub f: Text,
}

impl prism_rtl::Job<Text> for CppField {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let ex1 = &self.ex1;
        let f = &self.f;
        match ex1 {
            crate::lower::model::Ex::XSelf => prism_rtl::Turn::Finished(Text::from(format!("this->{}", &crate::emit::cpp::field_id(f)))),
            r => {
                let name = if is_digits(f) {
                    Text::from(format!("a{}", f))
                } else {
                    crate::emit::cpp::field_id(f)
                };
                let through = match pointer(cp, r) {
                    Some(b) => if b { Text::lit("->") } else { Text::lit(".") },
                    None => match get(&cp.members, f) {
                        Some(_) => Text::lit("->"),
                        None => Text::lit("."),
                    },
                };
                let cp = cp.clone();
                let r = r.clone();
                call_then(start_cpp_tight(cp.clone(), r.clone()), move |cpp_tight_6884: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}{}", &cpp_tight_6884, &through, &name))))
            },
        }
    }
}

/// `Start CppField, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_field(cp: crate::emit::cpp::Cp, ex1: crate::lower::model::Ex, f: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppField { cp, ex1, f })
}

/// ```prism
/// IsDigits: fn Text -> Bool
/// ```
pub fn is_digits(t: &Text) -> bool {
    (t != &Text::lit("")) && crate::syntax::lexer::chars::fold_chars(t, &true, &(Rc::new(move |(p0, p1): (bool, Text)| once_job(move || {
        let ok = p0;
        let c = p1;
        prism_rtl::Turn::Finished(ok && crate::syntax::lexer::chars::contains(&Text::lit("0123456789"), &c))
    })) as Rc<dyn Fn((bool, Text)) -> Rc<dyn prism_rtl::Job<bool>>>))
}

/// ```prism
/// CppCtor: unbounded fn Cp, Text, [Ex] -> Text
/// ```
pub fn cpp_ctor(cp: &crate::emit::cpp::Cp, p_: &Text, args: &Array<crate::lower::model::Ex>) -> Text {
    match p_ {
        m7234_0 if (m7234_0 == &Text::lit("Some")) => Text::from(format!("std::optional({})", &cpp_args(cp, args))),
        m7234_1 if (m7234_1 == &Text::lit("Ok")) => if args == &Array::from(vec![crate::lower::model::Ex::XUnit]) {
            Text::lit("prism_rtl::ok()")
        } else {
            cpp_args(cp, args)
        },
        m7234_2 if (m7234_2 == &Text::lit("Err")) => Text::from(format!("unexpected({})", &cpp_args(cp, args))),
        m7234_3 if (m7234_3 == &Text::lit("prism_rtl::Turn::More")) => Text::from(format!("prism_rtl::more({})", &cpp_args(cp, args))),
        m7234_4 if (m7234_4 == &Text::lit("prism_rtl::Turn::Finished")) => Text::from(format!("prism_rtl::finished({})", &cpp_args(cp, args))),
        m7234_5 if (m7234_5 == &Text::lit("Outcome::Fired")) => Text::from(format!("Outcome::fired({})", &cpp_args(cp, args))),
        m7234_6 if (m7234_6 == &Text::lit("Outcome::Value")) => Text::from(format!("Outcome::value({})", &cpp_args(cp, args))),
        m7234_7 if (m7234_7 == &Text::lit("Segment::Pos")) => Text::from(format!("Segment::pos({})", &cpp_args(cp, args))),
        m7234_8 if (m7234_8 == &Text::lit("Segment::Gen")) => Text::from(format!("Segment::gen({})", &cpp_args(cp, args))),
        m7234_9 if (m7234_9 == &Text::lit("Segment::Key")) => Text::from(format!("Segment::key({})", &cpp_args(cp, args))),
        _ => match crate::emit::cpp::case_of(cp, p_) {
            Some(ty) => Text::from(format!("{}({}{{{}}})", &crate::emit::cpp::type_path(&ty), &crate::emit::cpp::type_path(p_), &cpp_args(cp, args))),
            None => Text::from(format!("{}{{{}}}", &crate::emit::cpp::type_path(p_), &cpp_args(cp, args))),
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CppCtor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppCtor: unbounded fn Cp, Text, [Ex] -> Text
/// ```
pub struct CppCtor {
    pub cp: crate::emit::cpp::Cp,
    pub p_: Text,
    pub args: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for CppCtor {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let p_ = &self.p_;
        let args = &self.args;
        match p_ {
            m7234_0 if (m7234_0 == &Text::lit("Some")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_7271: Text| prism_rtl::Turn::Finished(Text::from(format!("std::optional({})", &cpp_args_7271))))
            },
            m7234_1 if (m7234_1 == &Text::lit("Ok")) => if args == &Array::from(vec![crate::lower::model::Ex::XUnit]) {
                prism_rtl::Turn::Finished(Text::lit("prism_rtl::ok()"))
            } else {
                prism_rtl::Turn::More(Rc::new(CppArgs { cp: cp.clone(), xs: args.clone() }))
            },
            m7234_2 if (m7234_2 == &Text::lit("Err")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_7388: Text| prism_rtl::Turn::Finished(Text::from(format!("unexpected({})", &cpp_args_7388))))
            },
            m7234_3 if (m7234_3 == &Text::lit("prism_rtl::Turn::More")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_7455: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::more({})", &cpp_args_7455))))
            },
            m7234_4 if (m7234_4 == &Text::lit("prism_rtl::Turn::Finished")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_7530: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::finished({})", &cpp_args_7530))))
            },
            m7234_5 if (m7234_5 == &Text::lit("Outcome::Fired")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_7589: Text| prism_rtl::Turn::Finished(Text::from(format!("Outcome::fired({})", &cpp_args_7589))))
            },
            m7234_6 if (m7234_6 == &Text::lit("Outcome::Value")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_7648: Text| prism_rtl::Turn::Finished(Text::from(format!("Outcome::value({})", &cpp_args_7648))))
            },
            m7234_7 if (m7234_7 == &Text::lit("Segment::Pos")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_7703: Text| prism_rtl::Turn::Finished(Text::from(format!("Segment::pos({})", &cpp_args_7703))))
            },
            m7234_8 if (m7234_8 == &Text::lit("Segment::Gen")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_7758: Text| prism_rtl::Turn::Finished(Text::from(format!("Segment::gen({})", &cpp_args_7758))))
            },
            m7234_9 if (m7234_9 == &Text::lit("Segment::Key")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_7813: Text| prism_rtl::Turn::Finished(Text::from(format!("Segment::key({})", &cpp_args_7813))))
            },
            _ => match crate::emit::cpp::case_of(cp, p_) {
                Some(ty) => {
                    let args = args.clone();
                    let cp = cp.clone();
                    let p_ = p_.clone();
                    call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_7913: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({}{{{}}})", &crate::emit::cpp::type_path(&ty), &crate::emit::cpp::type_path(&p_), &cpp_args_7913))))
                },
                None => {
                    let args = args.clone();
                    let cp = cp.clone();
                    let p_ = p_.clone();
                    call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_7964: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{{{}}}", &crate::emit::cpp::type_path(&p_), &cpp_args_7964))))
                },
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start CppCtor, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_ctor(cp: crate::emit::cpp::Cp, p_: Text, args: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppCtor { cp, p_, args })
}

/// ```prism
/// CppRecord: unbounded fn Cp, Text, [((Text, Ex))] -> Text
/// ```
pub fn cpp_record(cp: &crate::emit::cpp::Cp, p_: &Text, fs: &Array<(Text, crate::lower::model::Ex)>) -> Text {
    let ordered = match crate::emit::cpp::type_of(cp, p_) {
        Some(info) => each(&info.fields, &(|f: &Text| or(&fold(fs, &None, &(|found_opt: &Option<crate::lower::model::Ex>, (g, v_): &(Text, crate::lower::model::Ex)| if g == f { Some(v_.clone()) } else { found_opt.clone() })), &crate::lower::model::Ex::XUnit))),
        None => each(fs, &(|(_, v_): &(Text, crate::lower::model::Ex)| v_.clone())),
    };
    let names = match crate::emit::cpp::type_of(cp, p_) {
        Some(info) => info.fields.clone(),
        None => each(fs, &(|(g, _): &(Text, crate::lower::model::Ex)| g.clone())),
    };
    let kind = match crate::emit::cpp::type_of(cp, p_) {
        Some(info) => info.kind.clone(),
        None => Text::lit(""),
    };
    if &kind == &Text::lit("job") {
        Text::from(format!("{}({})", &crate::emit::cpp::type_path(p_), &cpp_args(cp, &ordered)))
    } else {
        Text::from(format!("{}{{{}}}", &crate::emit::cpp::type_path(p_), &crate::syntax::lexer::chars::join(&run_to_end(each_job(crate::check::errors::range0(&len(&names)), {
            let names = names.clone();
            let cp = cp.clone();
            let ordered = ordered.clone();
            Rc::new(move |p0: Nat| {
                let names = names.clone();
                let cp = cp.clone();
                let ordered = ordered.clone();
                entered(once_job(move || {
                    let i = p0;
                    call_then(start_cpp_expr(cp.clone(), or(&index(&ordered, &i), &crate::lower::model::Ex::XUnit)), move |cpp_expr_8703: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = {}", &crate::emit::cpp::field_id(&or(&index(&names, &i), &Text::lit(""))), &cpp_expr_8703))))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
        })), &Text::lit(", "))))
    }
}

/// The step machine of `CppRecord`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppRecord: unbounded fn Cp, Text, [((Text, Ex))] -> Text
/// ```
pub struct CppRecord {
    pub cp: crate::emit::cpp::Cp,
    pub p_: Text,
    pub fs: Array<(Text, crate::lower::model::Ex)>,
}

impl prism_rtl::Job<Text> for CppRecord {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let p_ = &self.p_;
        let fs = &self.fs;
        let ordered = match crate::emit::cpp::type_of(cp, p_) {
            Some(info) => each(&info.fields, &(|f: &Text| or(&fold(fs, &None, &(|found_opt: &Option<crate::lower::model::Ex>, (g, v_): &(Text, crate::lower::model::Ex)| if g == f { Some(v_.clone()) } else { found_opt.clone() })), &crate::lower::model::Ex::XUnit))),
            None => each(fs, &(|(_, v_): &(Text, crate::lower::model::Ex)| v_.clone())),
        };
        let names = match crate::emit::cpp::type_of(cp, p_) {
            Some(info) => info.fields.clone(),
            None => each(fs, &(|(g, _): &(Text, crate::lower::model::Ex)| g.clone())),
        };
        let kind = match crate::emit::cpp::type_of(cp, p_) {
            Some(info) => info.kind.clone(),
            None => Text::lit(""),
        };
        if &kind == &Text::lit("job") {
            {
                let cp = cp.clone();
                let p_ = p_.clone();
                call_then(start_cpp_args(cp.clone(), ordered.clone()), move |cpp_args_8583: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &crate::emit::cpp::type_path(&p_), &cpp_args_8583))))
            }
        } else {
            {
                let cp = cp.clone();
                let p_ = p_.clone();
                call_value(each_job(crate::check::errors::range0(&len(&names)), {
                    let names = names.clone();
                    let cp = cp.clone();
                    let ordered = ordered.clone();
                    Rc::new(move |p0: Nat| {
                        let names = names.clone();
                        let cp = cp.clone();
                        let ordered = ordered.clone();
                        entered(once_job(move || {
                            let i = p0;
                            call_then(start_cpp_expr(cp.clone(), or(&index(&ordered, &i), &crate::lower::model::Ex::XUnit)), move |cpp_expr_8703: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = {}", &crate::emit::cpp::field_id(&or(&index(&names, &i), &Text::lit(""))), &cpp_expr_8703))))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_8638: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{}{{{}}}", &crate::emit::cpp::type_path(&p_), &crate::syntax::lexer::chars::join(&each_8638, &Text::lit(", "))))))
            }
        }
    }
}

/// `Start CppRecord, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_record(cp: crate::emit::cpp::Cp, p_: Text, fs: Array<(Text, crate::lower::model::Ex)>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppRecord { cp, p_, fs })
}

/// ```prism
/// CppCall: unbounded fn Cp, Text, [Ex] -> Text
/// ```
pub fn cpp_call(cp: &crate::emit::cpp::Cp, f: &Text, args: &Array<crate::lower::model::Ex>) -> Text {
    let a = cpp_args(cp, args);
    match f {
        m8988_0 if (m8988_0 == &Text::lit("Rc::new")) => if &a == &Text::lit("{}") {
            Text::lit("prism_rtl::make_new()")
        } else {
            Text::from(format!("prism_rtl::rc({})", &a))
        },
        m8988_1 if (m8988_1 == &Text::lit("is_some")) => Text::from(format!("prism_rtl::is_some({})", &a)),
        m8988_2 if (m8988_2 == &Text::lit("is_none")) => Text::from(format!("prism_rtl::is_none({})", &a)),
        m8988_3 if (m8988_3 == &Text::lit("RefCell::new")) => a.clone(),
        m8988_4 if (m8988_4 == &Text::lit("Cell::new")) => a.clone(),
        m8988_5 if (m8988_5 == &Text::lit("Hold::new")) => Text::from(format!("{{{}}}", &a)),
        m8988_6 if (m8988_6 == &Text::lit("Snapshot::new")) => Text::from(format!("snapshot({})", &a)),
        m8988_7 if (m8988_7 == &Text::lit("Path::root")) => Text::lit("Path::root()"),
        m8988_8 if (m8988_8 == &Text::lit("Fault::answer")) => Text::from(format!("Fault::answer({})", &a)),
        m8988_9 if (m8988_9 == &Text::lit("Error::new")) => Text::from(format!("Error({})", &a)),
        m8988_10 if (m8988_10 == &Text::lit("Text::from")) => Text::from(format!("Text({})", &a)),
        m8988_11 if (m8988_11 == &Text::lit("String::new")) => Text::lit("std::string()"),
        m8988_12 if (m8988_12 == &Text::lit("Array::from")) => Text::from(format!("Array({})", &a)),
        m8988_13 if (m8988_13 == &Text::lit("prism_rtl::Dynamic::of")) => Text::from(format!("dynamic_of({})", &a)),
        m8988_14 if (m8988_14 == &Text::lit("Dynamic::of")) => Text::from(format!("dynamic_of({})", &a)),
        m8988_15 if (m8988_15 == &Text::lit("prism_rtl::Event::of")) => Text::from(format!("event_of({})", &a)),
        m8988_16 if (m8988_16 == &Text::lit("prism_rtl::Host::new")) => Text::from(format!("host_new({})", &a)),
        m8988_17 if (m8988_17 == &Text::lit("prism_rtl::forward_on_none")) => Text::from(format!("prism_rtl::forward_on_none<crate::Elem, crate::Answer>({})", &a)),
        m8988_18 if (m8988_18 == &Text::lit("Event::never")) => Text::lit("never_event()"),
        _ => if is_fresh(f) {
            Text::lit("{}")
        } else {
            Text::from(format!("{}({})", &free_call_path(cp, f), &a))
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CppCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppCall: unbounded fn Cp, Text, [Ex] -> Text
/// ```
pub struct CppCall {
    pub cp: crate::emit::cpp::Cp,
    pub f: Text,
    pub args: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for CppCall {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let f = &self.f;
        let args = &self.args;
        let args = args.clone();
        let cp = cp.clone();
        let f = f.clone();
        call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_8967: Text| {
            let a = cpp_args_8967;
            match &f {
                m8988_0 if (m8988_0 == &Text::lit("Rc::new")) => if &a == &Text::lit("{}") {
                    prism_rtl::Turn::Finished(Text::lit("prism_rtl::make_new()"))
                } else {
                    prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::rc({})", &a)))
                },
                m8988_1 if (m8988_1 == &Text::lit("is_some")) => prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::is_some({})", &a))),
                m8988_2 if (m8988_2 == &Text::lit("is_none")) => prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::is_none({})", &a))),
                m8988_3 if (m8988_3 == &Text::lit("RefCell::new")) => prism_rtl::Turn::Finished(a.clone()),
                m8988_4 if (m8988_4 == &Text::lit("Cell::new")) => prism_rtl::Turn::Finished(a.clone()),
                m8988_5 if (m8988_5 == &Text::lit("Hold::new")) => prism_rtl::Turn::Finished(Text::from(format!("{{{}}}", &a))),
                m8988_6 if (m8988_6 == &Text::lit("Snapshot::new")) => prism_rtl::Turn::Finished(Text::from(format!("snapshot({})", &a))),
                m8988_7 if (m8988_7 == &Text::lit("Path::root")) => prism_rtl::Turn::Finished(Text::lit("Path::root()")),
                m8988_8 if (m8988_8 == &Text::lit("Fault::answer")) => prism_rtl::Turn::Finished(Text::from(format!("Fault::answer({})", &a))),
                m8988_9 if (m8988_9 == &Text::lit("Error::new")) => prism_rtl::Turn::Finished(Text::from(format!("Error({})", &a))),
                m8988_10 if (m8988_10 == &Text::lit("Text::from")) => prism_rtl::Turn::Finished(Text::from(format!("Text({})", &a))),
                m8988_11 if (m8988_11 == &Text::lit("String::new")) => prism_rtl::Turn::Finished(Text::lit("std::string()")),
                m8988_12 if (m8988_12 == &Text::lit("Array::from")) => prism_rtl::Turn::Finished(Text::from(format!("Array({})", &a))),
                m8988_13 if (m8988_13 == &Text::lit("prism_rtl::Dynamic::of")) => prism_rtl::Turn::Finished(Text::from(format!("dynamic_of({})", &a))),
                m8988_14 if (m8988_14 == &Text::lit("Dynamic::of")) => prism_rtl::Turn::Finished(Text::from(format!("dynamic_of({})", &a))),
                m8988_15 if (m8988_15 == &Text::lit("prism_rtl::Event::of")) => prism_rtl::Turn::Finished(Text::from(format!("event_of({})", &a))),
                m8988_16 if (m8988_16 == &Text::lit("prism_rtl::Host::new")) => prism_rtl::Turn::Finished(Text::from(format!("host_new({})", &a))),
                m8988_17 if (m8988_17 == &Text::lit("prism_rtl::forward_on_none")) => prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::forward_on_none<crate::Elem, crate::Answer>({})", &a))),
                m8988_18 if (m8988_18 == &Text::lit("Event::never")) => prism_rtl::Turn::Finished(Text::lit("never_event()")),
                _ => if is_fresh(&f) {
                    prism_rtl::Turn::Finished(Text::lit("{}"))
                } else {
                    prism_rtl::Turn::Finished(Text::from(format!("{}({})", &free_call_path(&cp, &f), &a)))
                },
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start CppCall, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_call(cp: crate::emit::cpp::Cp, f: Text, args: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppCall { cp, f, args })
}

/// ```prism
/// FreeCallPath: fn Cp, Text -> Text
/// ```
pub fn free_call_path(cp: &crate::emit::cpp::Cp, f: &Text) -> Text {
    let p_ = call_path(f);
    let hidden = match get(&cp.members, f) {
        Some(_) => true,
        None => crate::emit::cpp::in_list(&std_names(), &p_) || crate::emit::cpp::in_list(&cp.mods, &p_),
    };
    if crate::syntax::lexer::chars::contains(&p_, &Text::lit(":")) {
        p_.clone()
    } else {
        if hidden { qualified_call(cp, f, &p_) } else { p_.clone() }
    }
}

/// ```prism
/// QualifiedCall: fn Cp, Text, Text -> Text
/// ```
pub fn qualified_call(cp: &crate::emit::cpp::Cp, f: &Text, p_: &Text) -> Text {
    match get(&cp.fns, &Text::from(format!("{}::{}", &cp.home, f))) {
        Some(_) => Text::from(format!("crate::{}::{}", &cp.home, p_)),
        None => Text::from(format!("crate::prelude::{}", p_)),
    }
}

/// ```prism
/// let stdNames
/// ```
pub fn std_names() -> Array<Text> {
    Array::from(vec![Text::lit("apply"), Text::lit("begin"), Text::lit("end"), Text::lit("size"), Text::lit("empty"), Text::lit("data"), Text::lit("get"), Text::lit("swap"), Text::lit("move"), Text::lit("forward"), Text::lit("find"), Text::lit("count"), Text::lit("copy"), Text::lit("fill"), Text::lit("sort"), Text::lit("min"), Text::lit("max"), Text::lit("visit"), Text::lit("invoke"), Text::lit("merge"), Text::lit("remove"), Text::lit("replace"), Text::lit("reverse"), Text::lit("unique"), Text::lit("transform"), Text::lit("accumulate"), Text::lit("distance"), Text::lit("next"), Text::lit("prev"), Text::lit("exchange"), Text::lit("tie"), Text::lit("to_string"), Text::lit("clamp"), Text::lit("partition"), Text::lit("equal"), Text::lit("mismatch"), Text::lit("erase"), Text::lit("search"), Text::lit("rotate")])
}

/// ```prism
/// IsFresh: fn Text -> Bool
/// ```
pub fn is_fresh(f: &Text) -> bool {
    crate::emit::cpp::in_list(&Array::from(vec![Text::lit("Stamped::new"), Text::lit("Cache::new"), Text::lit("Port::new"), Text::lit("Map::new"), Text::lit("Array::new"), Text::lit("Vec::new"), Text::lit("Default::default"), Text::lit("Wakes::default"), Text::lit("Defer::new")]), f)
}

/// ```prism
/// CallPath: fn Text -> Text
/// ```
pub fn call_path(f: &Text) -> Text {
    let last = crate::emit::cpp::last_segment(f);
    let owner = crate::emit::cpp::last_segment(&crate::emit::cpp::parent_path(f));
    let is_type = (&crate::emit::cpp::parent_path(f) != &Text::lit("")) && crate::syntax::lexer::chars::contains(&Text::lit("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), &crate::syntax::lexer::chars::head(&owner));
    if (&last == &Text::lit("build")) && is_type {
        Text::from(format!("{}::make", &crate::emit::cpp::type_path(&crate::emit::cpp::parent_path(f))))
    } else {
        if &last == &Text::lit("new") {
            crate::emit::cpp::type_path(&crate::emit::cpp::parent_path(f))
        } else {
            crate::emit::cpp::cpp_path_id(&crate::emit::cpp::type_path(f))
        }
    }
}

/// ```prism
/// CppMethod: unbounded fn Cp, Ex, Text, [Ex] -> Text
/// ```
pub fn cpp_method(cp: &crate::emit::cpp::Cp, r: &crate::lower::model::Ex, m: &Text, args: &Array<crate::lower::model::Ex>) -> Text {
    let recv = if r == &crate::lower::model::Ex::XSelf { Text::lit("this") } else { cpp_tight(cp, r) };
    let a = cpp_args(cp, args);
    let n = len(args);
    let sep = if &n == &Nat::from(0u32) { Text::lit("") } else { Text::lit(", ") };
    match method_form(m, &n) {
        m12141_0 if (&m12141_0 == &Text::lit("id")) => recv.clone(),
        m12141_1 if (&m12141_1 == &Text::lit("deref")) => match pointer(cp, r) {
            Some(b) => if b { Text::from(format!("(*{})", &recv)) } else { recv.clone() },
            None => recv.clone(),
        },
        m12141_2 if (&m12141_2 == &Text::lit("assign")) => Text::from(format!("{} = {}", &recv, &a)),
        m12141_3 if (&m12141_3 == &Text::lit("take")) => Text::from(format!("std::exchange({}, {{}})", &recv)),
        m12141_4 if (&m12141_4 == &Text::lit("free")) => Text::from(format!("{}({}{}{})", &free_name(m), &recv, &sep, &a)),
        m12141_5 if (&m12141_5 == &Text::lit("arrow")) => {
            let through = match pointer(cp, r) {
                Some(b) => if b { Text::lit("->") } else { Text::lit(".") },
                None => Text::lit("->"),
            };
            Text::from(format!("{}{}{}({})", &recv, &through, &member_name(m), &a))
        },
        m12141_6 if (&m12141_6 == &Text::lit("exchange")) => Text::from(format!("std::exchange({}, {})", &recv, &a)),
        _ => {
            let through = match pointer(cp, r) {
                Some(b) => if b { Text::lit("->") } else { Text::lit(".") },
                None => match get(&cp.members, m) {
                    Some(_) => Text::lit("->"),
                    None => Text::lit("."),
                },
            };
            Text::from(format!("{}{}{}({})", &recv, &through, &node_method_name(cp, m), &a))
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CppMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppMethod: unbounded fn Cp, Ex, Text, [Ex] -> Text
/// ```
pub struct CppMethod {
    pub cp: crate::emit::cpp::Cp,
    pub r: crate::lower::model::Ex,
    pub m: Text,
    pub args: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for CppMethod {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let r = &self.r;
        let m = &self.m;
        let args = &self.args;
        let recv = if r == &crate::lower::model::Ex::XSelf { Text::lit("this") } else { cpp_tight(cp, r) };
        let args = args.clone();
        let cp = cp.clone();
        let m = m.clone();
        let r = r.clone();
        call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_12060: Text| {
            let a = cpp_args_12060;
            let n = len(&args);
            let sep = if &n == &Nat::from(0u32) { Text::lit("") } else { Text::lit(", ") };
            match method_form(&m, &n) {
                m12141_0 if (&m12141_0 == &Text::lit("id")) => prism_rtl::Turn::Finished(recv.clone()),
                m12141_1 if (&m12141_1 == &Text::lit("deref")) => match pointer(&cp, &r) {
                    Some(b) => if b {
                        prism_rtl::Turn::Finished(Text::from(format!("(*{})", &recv)))
                    } else {
                        prism_rtl::Turn::Finished(recv.clone())
                    },
                    None => prism_rtl::Turn::Finished(recv.clone()),
                },
                m12141_2 if (&m12141_2 == &Text::lit("assign")) => prism_rtl::Turn::Finished(Text::from(format!("{} = {}", &recv, &a))),
                m12141_3 if (&m12141_3 == &Text::lit("take")) => prism_rtl::Turn::Finished(Text::from(format!("std::exchange({}, {{}})", &recv))),
                m12141_4 if (&m12141_4 == &Text::lit("free")) => prism_rtl::Turn::Finished(Text::from(format!("{}({}{}{})", &free_name(&m), &recv, &sep, &a))),
                m12141_5 if (&m12141_5 == &Text::lit("arrow")) => {
                    let through = match pointer(&cp, &r) {
                        Some(b) => if b { Text::lit("->") } else { Text::lit(".") },
                        None => Text::lit("->"),
                    };
                    prism_rtl::Turn::Finished(Text::from(format!("{}{}{}({})", &recv, &through, &member_name(&m), &a)))
                },
                m12141_6 if (&m12141_6 == &Text::lit("exchange")) => prism_rtl::Turn::Finished(Text::from(format!("std::exchange({}, {})", &recv, &a))),
                _ => {
                    let through = match pointer(&cp, &r) {
                        Some(b) => if b { Text::lit("->") } else { Text::lit(".") },
                        None => match get(&cp.members, &m) {
                            Some(_) => Text::lit("->"),
                            None => Text::lit("."),
                        },
                    };
                    prism_rtl::Turn::Finished(Text::from(format!("{}{}{}({})", &recv, &through, &node_method_name(&cp, &m), &a)))
                },
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start CppMethod, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_method(cp: crate::emit::cpp::Cp, r: crate::lower::model::Ex, m: Text, args: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppMethod { cp, r, m, args })
}

/// ```prism
/// NodeMethodName: fn Cp, Text -> Text
/// ```
pub fn node_method_name(cp: &crate::emit::cpp::Cp, m: &Text) -> Text {
    match (get(&cp.methods, m), get(&cp.field_names, m)) {
        (Some(_), Some(_)) => Text::from(format!("{}_", &crate::emit::cpp::cpp_id(m))),
        _ => member_name(m),
    }
}

/// ```prism
/// ?Pointer: fn Cp, Ex -> ?Bool
/// ```
pub fn pointer(cp: &crate::emit::cpp::Cp, r: &crate::lower::model::Ex) -> Option<bool> {
    'm13657: {
        if let crate::lower::model::Ex::XSelf = r {
            break 'm13657 Some(true);
        }
        if let crate::lower::model::Ex::XCx = r {
            break 'm13657 Some(false);
        }
        if let crate::lower::model::Ex::XVar(m13657_2_0) = r && (m13657_2_0 == &Text::lit("path")) {
            break 'm13657 Some(false);
        }
        if let crate::lower::model::Ex::XField(_, m13657_3_1) = r && (m13657_3_1 == &Text::lit("path")) {
            break 'm13657 Some(false);
        }
        if let crate::lower::model::Ex::XCall(m13657_4_0, _) = r && (m13657_4_0 == &Text::lit("Path::root")) {
            break 'm13657 Some(false);
        }
        if let crate::lower::model::Ex::XMethod(y, m, _) = r && (((m == &Text::lit("at")) || (m == &Text::lit("child"))) || (m == &Text::lit("join"))) {
            break 'm13657 match pointer(cp, &**y) {
                Some(false) => Some(false),
                _ => None,
            };
        }
        if let crate::lower::model::Ex::XVar(n) = r {
            break 'm13657 get(&cp.pointers, n);
        }
        if let crate::lower::model::Ex::XClone(y) = r {
            break 'm13657 pointer(cp, &**y);
        }
        if let crate::lower::model::Ex::XRef(y) = r {
            break 'm13657 pointer(cp, &**y);
        }
        if let crate::lower::model::Ex::XField(m13657_9_0, f) = r && let crate::lower::model::Ex::XSelf = &**m13657_9_0 {
            break 'm13657 match get(&cp.fields, f) {
                Some(t) => Some(is_pointer_ty(cp, &t)),
                None => None,
            };
        }
        if let crate::lower::model::Ex::XField(m13657_10_0, f) = r && let crate::lower::model::Ex::XVar(m13657_10_0_r_0) = &**m13657_10_0 && (m13657_10_0_r_0 == &Text::lit("node")) {
            break 'm13657 match get(&cp.fields, f) {
                Some(t) => Some(is_pointer_ty(cp, &t)),
                None => None,
            };
        }
        None
    }
}

/// ```prism
/// IsPointerTy: fn Cp, OutTy -> Bool
/// ```
pub fn is_pointer_ty(cp: &crate::emit::cpp::Cp, t: &crate::lower::model::OutTy) -> bool {
    match t {
        crate::lower::model::OutTy::OutNamed(m14295_0_0, _) if (m14295_0_0 == &Text::lit("prism_rtl::Rows")) => true,
        crate::lower::model::OutTy::OutPort(_) => false,
        crate::lower::model::OutTy::OutRc(i) => !crate::emit::cpp::is_value_ty(cp, &**i),
        crate::lower::model::OutTy::OutObj(_) => true,
        crate::lower::model::OutTy::OutJob(_) => true,
        crate::lower::model::OutTy::OutShowAny => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// MethodForm: fn Text, Nat -> Text
/// ```
pub fn method_form(m: &Text, n: &Nat) -> Text {
    match (m.clone(), n.clone()) {
        (m14834_0_0, m14834_0_1) if (&m14834_0_0 == &Text::lit("borrow")) && (&m14834_0_1 == &Nat::from(0u32)) => Text::lit("deref"),
        (m14834_1_0, m14834_1_1) if (&m14834_1_0 == &Text::lit("borrow_mut")) && (&m14834_1_1 == &Nat::from(0u32)) => Text::lit("deref"),
        (m14834_2_0, m14834_2_1) if (&m14834_2_0 == &Text::lit("clone")) && (&m14834_2_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m14834_3_0, m14834_3_1) if (&m14834_3_0 == &Text::lit("iter")) && (&m14834_3_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m14834_4_0, m14834_4_1) if (&m14834_4_0 == &Text::lit("collect")) && (&m14834_4_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m14834_5_0, m14834_5_1) if (&m14834_5_0 == &Text::lit("unwrap_or_default")) && (&m14834_5_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m14834_6_0, m14834_6_1) if (&m14834_6_0 == &Text::lit("for_each")) && (&m14834_6_1 == &Nat::from(1u32)) => Text::lit("free"),
        (m14834_7_0, m14834_7_1) if (&m14834_7_0 == &Text::lit("into_iter")) && (&m14834_7_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m14834_8_0, m14834_8_1) if (&m14834_8_0 == &Text::lit("as_ref")) && (&m14834_8_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m14834_9_0, m14834_9_1) if (&m14834_9_0 == &Text::lit("get")) && (&m14834_9_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m14834_10_0, m14834_10_1) if (&m14834_10_0 == &Text::lit("set")) && (&m14834_10_1 == &Nat::from(1u32)) => Text::lit("assign"),
        (m14834_11_0, m14834_11_1) if (&m14834_11_0 == &Text::lit("take")) && (&m14834_11_1 == &Nat::from(0u32)) => Text::lit("take"),
        (m14834_12_0, m14834_12_1) if (&m14834_12_0 == &Text::lit("replace")) && (&m14834_12_1 == &Nat::from(1u32)) => Text::lit("exchange"),
        (m14834_13_0, m14834_13_1) if (&m14834_13_0 == &Text::lit("values")) && (&m14834_13_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m14834_14_0, m14834_14_1) if (&m14834_14_0 == &Text::lit("keys")) && (&m14834_14_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m14834_15_0, m14834_15_1) if (&m14834_15_0 == &Text::lit("enumerate")) && (&m14834_15_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m14834_16_0, m14834_16_1) if (&m14834_16_0 == &Text::lit("fire")) && (&m14834_16_1 == &Nat::from(2u32)) => Text::lit("arrow"),
        (m14834_17_0, m14834_17_1) if (&m14834_17_0 == &Text::lit("subscribe")) && (&m14834_17_1 == &Nat::from(1u32)) => Text::lit("arrow"),
        (m14834_18_0, m14834_18_1) if (&m14834_18_0 == &Text::lit("unsubscribe")) && (&m14834_18_1 == &Nat::from(1u32)) => Text::lit("arrow"),
        (m14834_19_0, m14834_19_1) if (&m14834_19_0 == &Text::lit("cycle")) && (&m14834_19_1 == &Nat::from(0u32)) => Text::lit("arrow"),
        (m14834_20_0, m14834_20_1) if (&m14834_20_0 == &Text::lit("upgrade")) && (&m14834_20_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m14834_21_0, m14834_21_1) if (&m14834_21_0 == &Text::lit("expect")) && (&m14834_21_1 == &Nat::from(1u32)) => Text::lit("free"),
        (m14834_22_0, m14834_22_1) if (&m14834_22_0 == &Text::lit("to_pod")) && (&m14834_22_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m14834_23_0, m14834_23_1) if (&m14834_23_0 == &Text::lit("cloned")) && (&m14834_23_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m14834_24_0, m14834_24_1) if (&m14834_24_0 == &Text::lit("ok")) && (&m14834_24_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m14834_25_0, m14834_25_1) if (&m14834_25_0 == &Text::lit("ok_or")) && (&m14834_25_1 == &Nat::from(1u32)) => Text::lit("free"),
        (m14834_26_0, m14834_26_1) if (&m14834_26_0 == &Text::lit("map")) && (&m14834_26_1 == &Nat::from(1u32)) => Text::lit("free"),
        (m14834_27_0, m14834_27_1) if (&m14834_27_0 == &Text::lit("iter_mut")) && (&m14834_27_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m14834_28_0, m14834_28_1) if (&m14834_28_0 == &Text::lit("to_vec")) && (&m14834_28_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m14834_29_0, m14834_29_1) if (&m14834_29_0 == &Text::lit("filter_some")) && (&m14834_29_1 == &Nat::from(0u32)) => Text::lit("free"),
        _ => Text::lit("dot"),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// FreeName: fn Text -> Text
/// ```
pub fn free_name(m: &Text) -> Text {
    match m {
        m15771_0 if (m15771_0 == &Text::lit("to_pod")) => Text::lit("prism_rtl::to_pod"),
        m15771_1 if (m15771_1 == &Text::lit("ok")) => Text::lit("prism_rtl::ignore"),
        m15771_2 if (m15771_2 == &Text::lit("map")) => Text::lit("prism_rtl::fmap"),
        m15771_3 if (m15771_3 == &Text::lit("to_vec")) => Text::lit("path_of"),
        m15771_4 if (m15771_4 == &Text::lit("values")) => Text::lit("crate::prelude::values"),
        m15771_5 if (m15771_5 == &Text::lit("keys")) => Text::lit("crate::prelude::keys"),
        m15771_6 if (m15771_6 == &Text::lit("enumerate")) => Text::lit("prism_rtl::enumerate"),
        m15771_7 if (m15771_7 == &Text::lit("unwrap_or_default")) => Text::lit("prism_rtl::unwrap_or_default"),
        m15771_8 if (m15771_8 == &Text::lit("for_each")) => Text::lit("prism_rtl::for_each"),
        _ => m.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// MemberName: fn Text -> Text
/// ```
pub fn member_name(m: &Text) -> Text {
    match m {
        m16169_0 if (m16169_0 == &Text::lit("push_str")) => Text::lit("append"),
        m16169_1 if (m16169_1 == &Text::lit("len")) => Text::lit("size"),
        m16169_2 if (m16169_2 == &Text::lit("is_empty")) => Text::lit("empty"),
        m16169_3 if (m16169_3 == &Text::lit("push")) => Text::lit("push_back"),
        m16169_4 if (m16169_4 == &Text::lit("contains_key")) => Text::lit("contains"),
        m16169_5 if (m16169_5 == &Text::lit("build")) => Text::lit("make"),
        _ => crate::emit::cpp::cpp_id(m),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CaseTest: fn Cp, Text, Text -> Text
/// ```
pub fn case_test(cp: &crate::emit::cpp::Cp, c: &Text, v_: &Text) -> Text {
    match c {
        m16468_0 if (m16468_0 == &Text::lit("Some")) => Text::from(format!("prism_rtl::is_some({})", v_)),
        m16468_1 if (m16468_1 == &Text::lit("None")) => Text::from(format!("prism_rtl::is_none({})", v_)),
        m16468_2 if (m16468_2 == &Text::lit("Ok")) => Text::from(format!("prism_rtl::is_ok({})", v_)),
        m16468_3 if (m16468_3 == &Text::lit("Err")) => Text::from(format!("prism_rtl::is_err({})", v_)),
        m16468_4 if (m16468_4 == &Text::lit("prism_rtl::Turn::More")) => Text::from(format!("{}.if_more()", v_)),
        m16468_5 if (m16468_5 == &Text::lit("prism_rtl::Turn::Finished")) => Text::from(format!("{}.if_finished()", v_)),
        _ => match crate::emit::cpp::case_of(cp, c) {
            Some(_) => Text::from(format!("prism_rtl::is<{}>({})", &case_type(c), v_)),
            None => if is_runtime_case(c) {
                Text::from(format!("prism_rtl::is<{}>({})", &case_type(c), v_))
            } else {
                Text::lit("true")
            },
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CaseType: fn Text -> Text
/// ```
pub fn case_type(c: &Text) -> Text {
    match c {
        m17020_0 if (m17020_0 == &Text::lit("Segment::Pos")) => Text::lit("pat::Pos"),
        m17020_1 if (m17020_1 == &Text::lit("Segment::Gen")) => Text::lit("pat::Gen"),
        m17020_2 if (m17020_2 == &Text::lit("Segment::Key")) => Text::lit("pat::Key"),
        _ => crate::emit::cpp::type_path(c),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Payload: fn Cp, Text, Text, Nat -> Text
/// ```
pub fn payload(cp: &crate::emit::cpp::Cp, c: &Text, v_: &Text, i: &Nat) -> Text {
    match c {
        m17269_0 if (m17269_0 == &Text::lit("Some")) => Text::from(format!("prism_rtl::some_of({})", v_)),
        m17269_1 if (m17269_1 == &Text::lit("Ok")) => Text::from(format!("*{}", v_)),
        m17269_2 if (m17269_2 == &Text::lit("Err")) => Text::from(format!("{}.error()", v_)),
        m17269_3 if (m17269_3 == &Text::lit("prism_rtl::Turn::More")) => Text::from(format!("{}.if_more()->next", v_)),
        m17269_4 if (m17269_4 == &Text::lit("prism_rtl::Turn::Finished")) => Text::from(format!("{}.if_finished()->value", v_)),
        _ => match crate::emit::cpp::case_of(cp, c) {
            Some(_) => Text::from(format!("prism_rtl::as<{}>({}).a{}", &case_type(c), v_, i)),
            None => if is_runtime_case(c) {
                Text::from(format!("prism_rtl::as<{}>({}).a{}", &case_type(c), v_, i))
            } else {
                Text::from(format!("{}.a{}", v_, i))
            },
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IsRuntimeCase: fn Text -> Bool
/// ```
pub fn is_runtime_case(c: &Text) -> bool {
    crate::syntax::lexer::chars::has_prefix(c, &Text::lit("Segment::"))
}

/// ```prism
/// CppIf: unbounded fn Cp, Ex, Ex, Ex -> Text
/// ```
pub fn cpp_if(cp: &crate::emit::cpp::Cp, c: &crate::lower::model::Ex, t: &crate::lower::model::Ex, e: &crate::lower::model::Ex) -> Text {
    let ct = cpp_expr(cp, c);
    let err_opt = match (err_of(t), err_of(e)) {
        (Some(y), _) => Some(y.clone()),
        (None, Some(y)) => Some(y.clone()),
        _ => None,
    };
    let tt = match &err_opt {
        Some(y) => ok_branch(cp, t, y),
        None => cpp_expr(cp, t),
    };
    let et = match &err_opt {
        Some(y) => ok_branch(cp, e, y),
        None => cpp_expr(cp, e),
    };
    let short = !crate::syntax::lexer::chars::contains(&Text::from(format!("{}{}", &tt, &et)), &Text::lit("\n")) && (&len_text(&Text::from(format!("{}{}{}", &ct, &tt, &et))) < &Nat::from(70u32));
    if short {
        Text::from(format!("{} ? {} : {}", &ct, &tt, &et))
    } else {
        crate::emit::cpp::templates::items::cond_expr(&ct, &tt, &et)
    }
}

/// The step machine of `CppIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppIf: unbounded fn Cp, Ex, Ex, Ex -> Text
/// ```
pub struct CppIf {
    pub cp: crate::emit::cpp::Cp,
    pub c: crate::lower::model::Ex,
    pub t: crate::lower::model::Ex,
    pub e: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppIf {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let c = &self.c;
        let t = &self.t;
        let e = &self.e;
        let c = c.clone();
        let cp = cp.clone();
        let e = e.clone();
        let t = t.clone();
        call_then(start_cpp_expr(cp.clone(), c.clone()), move |cpp_expr_17846: Text| {
            let ct = cpp_expr_17846;
            let err_opt = match (err_of(&t), err_of(&e)) {
                (Some(y), _) => Some(y.clone()),
                (None, Some(y)) => Some(y.clone()),
                _ => None,
            };
            let tt = match &err_opt {
                Some(y) => ok_branch(&cp, &t, y),
                None => cpp_expr(&cp, &t),
            };
            let et = match &err_opt {
                Some(y) => ok_branch(&cp, &e, y),
                None => cpp_expr(&cp, &e),
            };
            let short = !crate::syntax::lexer::chars::contains(&Text::from(format!("{}{}", &tt, &et)), &Text::lit("\n")) && (&len_text(&Text::from(format!("{}{}{}", &ct, &tt, &et))) < &Nat::from(70u32));
            if short {
                prism_rtl::Turn::Finished(Text::from(format!("{} ? {} : {}", &ct, &tt, &et)))
            } else {
                prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cond_expr(&ct, &tt, &et))
            }
        })
    }
}

/// `Start CppIf, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_if(cp: crate::emit::cpp::Cp, c: crate::lower::model::Ex, t: crate::lower::model::Ex, e: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppIf { cp, c, t, e })
}

/// ```prism
/// IsCtor: fn Ex, Text -> Bool
/// ```
pub fn is_ctor(ex0: &crate::lower::model::Ex, c: &Text) -> bool {
    match ex0 {
        crate::lower::model::Ex::XCtor(p_, _) => p_ == c,
        x => false,
    }
}

/// ```prism
/// ?ErrOf: fn Ex -> ?Ex
/// ```
pub fn err_of(x: &crate::lower::model::Ex) -> Option<crate::lower::model::Ex> {
    'm18485: {
        if let crate::lower::model::Ex::XCtor(m18485_0_0, m18485_0_1) = x && (m18485_0_0 == &Text::lit("Err")) && (m18485_0_1.len() == 1) && let Some(y) = index(m18485_0_1, &Nat::from(0u32)) {
            break 'm18485 Some(y.clone());
        }
        if let crate::lower::model::Ex::XBlock(_, tail) = x {
            break 'm18485 err_of(&**tail);
        }
        None
    }
}

/// ```prism
/// OkBranch: unbounded fn Cp, Ex, Ex -> Text
/// ```
pub fn ok_branch(cp: &crate::emit::cpp::Cp, x: &crate::lower::model::Ex, y: &crate::lower::model::Ex) -> Text {
    'm18788: {
        if let crate::lower::model::Ex::XCtor(m18788_0_0, m18788_0_1) = x && (m18788_0_0 == &Text::lit("Ok")) && (m18788_0_1.len() == 1) && let Some(v_) = index(m18788_0_1, &Nat::from(0u32)) {
            break 'm18788 Text::from(format!("Expected<std::decay_t<decltype({})>, std::decay_t<decltype({})>>({})", &cpp_expr(cp, &v_), &cpp_expr(cp, y), &cpp_expr(cp, &v_)));
        }
        if let crate::lower::model::Ex::XBlock(dos, m18788_1_1) = x && let crate::lower::model::Ex::XCtor(m18788_1_1_r_0, m18788_1_1_r_1) = &**m18788_1_1 && (m18788_1_1_r_0 == &Text::lit("Ok")) && (m18788_1_1_r_1.len() == 1) && let Some(v_) = index(m18788_1_1_r_1, &Nat::from(0u32)) {
            break 'm18788 {
                let (st, cp2) = crate::emit::cpp::stmts::cpp_statements_cp(cp, dos);
                crate::emit::cpp::templates::items::stmt_expr(&st, &Text::from(format!("Expected<std::decay_t<decltype({})>, std::decay_t<decltype({})>>({})", &cpp_expr(&cp2, &v_), &cpp_expr(&cp2, y), &cpp_expr(&cp2, &v_))))
            };
        }
        cpp_expr(cp, x)
    }
}

/// The step machine of `OkBranch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OkBranch: unbounded fn Cp, Ex, Ex -> Text
/// ```
pub struct OkBranch {
    pub cp: crate::emit::cpp::Cp,
    pub x: crate::lower::model::Ex,
    pub y: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for OkBranch {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let x = &self.x;
        let y = &self.y;
        'm18788: {
            if let crate::lower::model::Ex::XCtor(m18788_0_0, m18788_0_1) = x && (m18788_0_0 == &Text::lit("Ok")) && (m18788_0_1.len() == 1) && let Some(v_) = index(m18788_0_1, &Nat::from(0u32)) {
                break 'm18788 {
                    let cp = cp.clone();
                    let y = y.clone();
                    call_then(start_cpp_expr(cp.clone(), v_.clone()), move |cpp_expr_18853: Text| call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_18894: Text| call_then(start_cpp_expr(cp.clone(), v_.clone()), move |cpp_expr_18913: Text| prism_rtl::Turn::Finished(Text::from(format!("Expected<std::decay_t<decltype({})>, std::decay_t<decltype({})>>({})", &cpp_expr_18853, &cpp_expr_18894, &cpp_expr_18913))))))
                };
            }
            if let crate::lower::model::Ex::XBlock(dos, m18788_1_1) = x && let crate::lower::model::Ex::XCtor(m18788_1_1_r_0, m18788_1_1_r_1) = &**m18788_1_1 && (m18788_1_1_r_0 == &Text::lit("Ok")) && (m18788_1_1_r_1.len() == 1) && let Some(v_) = index(m18788_1_1_r_1, &Nat::from(0u32)) {
                break 'm18788 {
                    let cp = cp.clone();
                    let dos = dos.clone();
                    let y = y.clone();
                    call_then(crate::emit::cpp::stmts::start_cpp_statements_cp(cp.clone(), dos.clone()), move |cpp_statements_cp_18993: (Text, crate::emit::cpp::Cp)| {
                        let (st, cp2) = cpp_statements_cp_18993;
                        call_then(start_cpp_expr(cp2.clone(), v_.clone()), move |cpp_expr_19071: Text| call_then(start_cpp_expr(cp2.clone(), y.clone()), move |cpp_expr_19113: Text| call_then(start_cpp_expr(cp2.clone(), v_.clone()), move |cpp_expr_19133: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::stmt_expr(&st, &Text::from(format!("Expected<std::decay_t<decltype({})>, std::decay_t<decltype({})>>({})", &cpp_expr_19071, &cpp_expr_19113, &cpp_expr_19133)))))))
                    })
                };
            }
            prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: x.clone() }))
        }
    }
}

/// `Start OkBranch, x`: what the function value is when passed to `@Run`.
pub fn start_ok_branch(cp: crate::emit::cpp::Cp, x: crate::lower::model::Ex, y: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(OkBranch { cp, x, y })
}

/// ```prism
/// CppClosure: unbounded fn Cp, Bool, [Pa], Ex -> Text
/// ```
pub fn cpp_closure(cp0: &crate::emit::cpp::Cp, mv: &bool, ps: &Array<crate::lower::model::Pa>, body: &crate::lower::model::Ex) -> Text {
    let cp = crate::emit::cpp::stmts::unbind(cp0, &crate::emit::cpp::patterns::concat2(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
        let p_ = p0;
        prism_rtl::Turn::More(Rc::new(crate::emit::cpp::stmts::PatNames { p_: p_.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))));
    let params = crate::syntax::lexer::chars::join(&run_to_end(each_job(crate::check::errors::range0(&len(ps)), {
        let cp = cp.clone();
        let ps = ps.clone();
        Rc::new(move |p0: Nat| {
            let cp = cp.clone();
            let ps = ps.clone();
            entered(once_job(move || {
                let i = p0;
                prism_rtl::Turn::More(Rc::new(ClosureParam { cp: cp.clone(), pa1: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), i: i.clone() }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "));
    let binds = concat(&run_to_end(each_job(crate::check::errors::range0(&len(ps)), {
        let cp = cp.clone();
        let ps = ps.clone();
        Rc::new(move |p0: Nat| {
            let cp = cp.clone();
            let ps = ps.clone();
            entered(once_job(move || {
                let i = p0;
                prism_rtl::Turn::More(Rc::new(ClosureBinds { cp: cp.clone(), pa1: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), i: i.clone() }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let capture = if *mv { Text::lit("=") } else { Text::lit("&") };
    let b = cpp_expr(&cp, body);
    let (ret, value) = match body {
        crate::lower::model::Ex::XRef(_) => (Text::lit(" -> decltype(auto)"), Text::from(format!("({})", &b))),
        crate::lower::model::Ex::XRefMut(_) => (Text::lit(" -> decltype(auto)"), Text::from(format!("({})", &b))),
        _ => (Text::lit(""), b.clone()),
    };
    if (&binds == &Text::lit("")) && !crate::syntax::lexer::chars::contains(&b, &Text::lit("\n")) {
        Text::from(format!("[{}]({}){} {{ return {}; }}", &capture, &params, &ret, &value))
    } else {
        crate::emit::cpp::templates::items::lambda(&capture, &Text::from(format!("{}){}", &params, &ret)), &Text::from(format!("{}return {};", &binds, &value)))
    }
}

/// The step machine of `CppClosure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppClosure: unbounded fn Cp, Bool, [Pa], Ex -> Text
/// ```
pub struct CppClosure {
    pub cp0: crate::emit::cpp::Cp,
    pub mv: bool,
    pub ps: Array<crate::lower::model::Pa>,
    pub body: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppClosure {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp0 = &self.cp0;
        let mv = &self.mv;
        let ps = &self.ps;
        let body = &self.body;
        let body = body.clone();
        let cp0 = cp0.clone();
        let mv = *mv;
        let ps = ps.clone();
        call_value(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
            let p_ = p0;
            prism_rtl::Turn::More(Rc::new(crate::emit::cpp::stmts::PatNames { p_: p_.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_19368: Array<Array<Text>>| {
            let cp = crate::emit::cpp::stmts::unbind(&cp0, &crate::emit::cpp::patterns::concat2(&each_19368));
            call_value(each_job(crate::check::errors::range0(&len(&ps)), {
                let cp = cp.clone();
                let ps = ps.clone();
                Rc::new(move |p0: Nat| {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(ClosureParam { cp: cp.clone(), pa1: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), i: i.clone() }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_19418: Array<Text>| {
                let params = crate::syntax::lexer::chars::join(&each_19418, &Text::lit(", "));
                call_value(each_job(crate::check::errors::range0(&len(&ps)), {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    Rc::new(move |p0: Nat| {
                        let cp = cp.clone();
                        let ps = ps.clone();
                        entered(once_job(move || {
                            let i = p0;
                            prism_rtl::Turn::More(Rc::new(ClosureBinds { cp: cp.clone(), pa1: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), i: i.clone() }))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_19517: Array<Text>| {
                    let binds = concat(&each_19517);
                    let capture = if mv { Text::lit("=") } else { Text::lit("&") };
                    call_then(start_cpp_expr(cp.clone(), body.clone()), move |cpp_expr_19637: Text| {
                        let b = cpp_expr_19637;
                        let (ret, value) = match &body {
                            crate::lower::model::Ex::XRef(_) => (Text::lit(" -> decltype(auto)"), Text::from(format!("({})", &b))),
                            crate::lower::model::Ex::XRefMut(_) => (Text::lit(" -> decltype(auto)"), Text::from(format!("({})", &b))),
                            _ => (Text::lit(""), b.clone()),
                        };
                        if (&binds == &Text::lit("")) && !crate::syntax::lexer::chars::contains(&b, &Text::lit("\n")) {
                            prism_rtl::Turn::Finished(Text::from(format!("[{}]({}){} {{ return {}; }}", &capture, &params, &ret, &value)))
                        } else {
                            prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::lambda(&capture, &Text::from(format!("{}){}", &params, &ret)), &Text::from(format!("{}return {};", &binds, &value))))
                        }
                    })
                })
            })
        })
    }
}

/// `Start CppClosure, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_closure(cp0: crate::emit::cpp::Cp, mv: bool, ps: Array<crate::lower::model::Pa>, body: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppClosure { cp0, mv, ps, body })
}

/// ```prism
/// ClosureParam: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub fn closure_param(cp: &crate::emit::cpp::Cp, pa1: &crate::lower::model::Pa, i: &Nat) -> Text {
    'c: {
        if let crate::lower::model::Pa::PaTyped(c0_1_0, t) = pa1 && let crate::lower::model::Pa::PaBind(n) = &**c0_1_0 {
            break 'c Text::from(format!("{} {}", &param_type(cp, t), &crate::emit::cpp::cpp_id(n)));
        }
        if let crate::lower::model::Pa::PaTyped(c1_1_0, t) = pa1 && let crate::lower::model::Pa::PaMut(n) = &**c1_1_0 {
            break 'c Text::from(format!("{} {}", &crate::emit::cpp::cpp_type(cp, &unref(t)), &crate::emit::cpp::cpp_id(n)));
        }
        if let crate::lower::model::Pa::PaTyped(p_, t) = pa1 {
            break 'c Text::from(format!("{} _p{}", &param_type(cp, t), i));
        }
        if let crate::lower::model::Pa::PaBind(n) = pa1 {
            break 'c Text::from(format!("auto&& {}", &crate::emit::cpp::cpp_id(n)));
        }
        if let crate::lower::model::Pa::PaMut(n) = pa1 {
            break 'c Text::from(format!("auto {}", &crate::emit::cpp::cpp_id(n)));
        }
        if let crate::lower::model::Pa::PaWild = pa1 {
            break 'c Text::lit("const auto&");
        }
        if let p_ = pa1 {
            break 'c Text::from(format!("const auto& _p{}", i));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `ClosureParam`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosureParam: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub struct ClosureParam {
    pub cp: crate::emit::cpp::Cp,
    pub pa1: crate::lower::model::Pa,
    pub i: Nat,
}

impl prism_rtl::Job<Text> for ClosureParam {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let pa1 = &self.pa1;
        let i = &self.i;
        'j: {
            if let crate::lower::model::Pa::PaTyped(j0_1_0, t) = pa1 && let crate::lower::model::Pa::PaBind(n) = &**j0_1_0 {
                break 'j {
                    let cp = cp.clone();
                    let n = n.clone();
                    let t = t.clone();
                    call_then(start_param_type(cp.clone(), t.clone()), move |param_type_20099: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_20099, &crate::emit::cpp::cpp_id(&n)))))
                };
            }
            if let crate::lower::model::Pa::PaTyped(j1_1_0, t) = pa1 && let crate::lower::model::Pa::PaMut(n) = &**j1_1_0 {
                break 'j {
                    let cp = cp.clone();
                    let n = n.clone();
                    let t = t.clone();
                    call_then(crate::emit::cpp::start_cpp_type(cp.clone(), unref(&t)), move |cpp_type_20177: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_20177, &crate::emit::cpp::cpp_id(&n)))))
                };
            }
            if let crate::lower::model::Pa::PaTyped(p_, t) = pa1 {
                break 'j {
                    let cp = cp.clone();
                    let i = i.clone();
                    let t = t.clone();
                    call_then(start_param_type(cp.clone(), t.clone()), move |param_type_20253: Text| prism_rtl::Turn::Finished(Text::from(format!("{} _p{}", &param_type_20253, &i))))
                };
            }
            if let crate::lower::model::Pa::PaBind(n) = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::from(format!("auto&& {}", &crate::emit::cpp::cpp_id(n))));
            }
            if let crate::lower::model::Pa::PaMut(n) = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::from(format!("auto {}", &crate::emit::cpp::cpp_id(n))));
            }
            if let crate::lower::model::Pa::PaWild = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::lit("const auto&"));
            }
            if let p_ = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::from(format!("const auto& _p{}", i)));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start ClosureParam, x`: what the function value is when passed to `@Run`.
pub fn start_closure_param(cp: crate::emit::cpp::Cp, pa1: crate::lower::model::Pa, i: Nat) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ClosureParam { cp, pa1, i })
}

/// ```prism
/// ClosureBinds: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub fn closure_binds(cp: &crate::emit::cpp::Cp, pa1: &crate::lower::model::Pa, i: &Nat) -> Text {
    'c: {
        if let crate::lower::model::Pa::PaTyped(c0_1_0, t) = pa1 && let crate::lower::model::Pa::PaBind(n) = &**c0_1_0 {
            break 'c Text::lit("");
        }
        if let crate::lower::model::Pa::PaTyped(c1_1_0, t) = pa1 && let crate::lower::model::Pa::PaMut(n) = &**c1_1_0 {
            break 'c Text::lit("");
        }
        if let crate::lower::model::Pa::PaTyped(p_, t) = pa1 {
            break 'c closure_binds(cp, &**p_, i);
        }
        if let crate::lower::model::Pa::PaBind(n) = pa1 {
            break 'c Text::lit("");
        }
        if let crate::lower::model::Pa::PaMut(n) = pa1 {
            break 'c Text::lit("");
        }
        if let crate::lower::model::Pa::PaWild = pa1 {
            break 'c Text::lit("");
        }
        if let p_ = pa1 {
            break 'c concat(&each(&crate::emit::cpp::patterns::pat_binds(cp, p_, &Text::from(format!("_p{}", i))), &(|b: &Text| Text::from(format!("{}\n", b)))));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `ClosureBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosureBinds: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub struct ClosureBinds {
    pub cp: crate::emit::cpp::Cp,
    pub pa1: crate::lower::model::Pa,
    pub i: Nat,
}

impl prism_rtl::Job<Text> for ClosureBinds {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let pa1 = &self.pa1;
        let i = &self.i;
        'j: {
            if let crate::lower::model::Pa::PaTyped(j0_1_0, t) = pa1 && let crate::lower::model::Pa::PaBind(n) = &**j0_1_0 {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let crate::lower::model::Pa::PaTyped(j1_1_0, t) = pa1 && let crate::lower::model::Pa::PaMut(n) = &**j1_1_0 {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let crate::lower::model::Pa::PaTyped(p_, t) = pa1 {
                break 'j prism_rtl::Turn::More(Rc::new(ClosureBinds { cp: cp.clone(), pa1: (**p_).clone(), i: i.clone() }));
            }
            if let crate::lower::model::Pa::PaBind(n) = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let crate::lower::model::Pa::PaMut(n) = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let crate::lower::model::Pa::PaWild = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let p_ = pa1 {
                break 'j {
                    let cp = cp.clone();
                    let i = i.clone();
                    let p_ = p_.clone();
                    call_then(crate::emit::cpp::patterns::start_pat_binds(cp.clone(), p_.clone(), Text::from(format!("_p{}", &i))), move |pat_binds_20843: Array<Text>| prism_rtl::Turn::Finished(concat(&each(&pat_binds_20843, &(|b: &Text| Text::from(format!("{}\n", b)))))))
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start ClosureBinds, x`: what the function value is when passed to `@Run`.
pub fn start_closure_binds(cp: crate::emit::cpp::Cp, pa1: crate::lower::model::Pa, i: Nat) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ClosureBinds { cp, pa1, i })
}

/// ```prism
/// Unref: fn OutTy -> OutTy
/// ```
pub fn unref(out_ty0: &crate::lower::model::OutTy) -> crate::lower::model::OutTy {
    match out_ty0 {
        crate::lower::model::OutTy::OutRef(t) => (**t).clone(),
        t => t.clone(),
    }
}

/// ```prism
/// ParamType: unbounded fn Cp, OutTy -> Text
/// ```
pub fn param_type(cp: &crate::emit::cpp::Cp, t: &crate::lower::model::OutTy) -> Text {
    match t {
        crate::lower::model::OutTy::OutRef(_) => crate::emit::cpp::cpp_type(cp, t),
        crate::lower::model::OutTy::OutSlice(_) => crate::emit::cpp::cpp_type(cp, t),
        crate::lower::model::OutTy::OutUnit => Text::lit("Unit"),
        _ => crate::emit::cpp::cpp_type(cp, t),
    }
}

/// The step machine of `ParamType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParamType: unbounded fn Cp, OutTy -> Text
/// ```
pub struct ParamType {
    pub cp: crate::emit::cpp::Cp,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for ParamType {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let t = &self.t;
        match t {
            crate::lower::model::OutTy::OutRef(_) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::CppType { cp: cp.clone(), t: t.clone() })),
            crate::lower::model::OutTy::OutSlice(_) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::CppType { cp: cp.clone(), t: t.clone() })),
            crate::lower::model::OutTy::OutUnit => prism_rtl::Turn::Finished(Text::lit("Unit")),
            _ => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::CppType { cp: cp.clone(), t: t.clone() })),
        }
    }
}

/// `Start ParamType, x`: what the function value is when passed to `@Run`.
pub fn start_param_type(cp: crate::emit::cpp::Cp, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ParamType { cp, t })
}
