//! The module `Emit.Cpp.Expr`, from `target/bootstrap/src/prismc/emit/cpp/expr.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// CppLoose: fn Ex -> Bool
/// ```
pub fn cpp_loose(x_p0: &crate::lower::model::Ex) -> bool {
    match x_p0 {
        crate::lower::model::Ex::XBlock(m1173_0_0, inner_p1) if (m1173_0_0.len() == 0) => cpp_loose(&**inner_p1),
        crate::lower::model::Ex::XBin(_, _, _) => true,
        crate::lower::model::Ex::XUnary(_, _) => true,
        crate::lower::model::Ex::XIf(_, _, _) => true,
        crate::lower::model::Ex::XRef(y_p2) => cpp_loose(&**y_p2),
        crate::lower::model::Ex::XRefMut(y_p3) => cpp_loose(&**y_p3),
        crate::lower::model::Ex::XClone(y_p4) => cpp_loose(&**y_p4),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CppTight: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_tight(cp_p0: &crate::emit::cpp::Cp, x_p1: &crate::lower::model::Ex) -> Text {
    if cpp_loose(x_p1) {
        Text::from(format!("({})", &cpp_expr(cp_p0, x_p1)))
    } else {
        starred(&cpp_expr(cp_p0, x_p1))
    }
}

/// The step machine of `CppTight`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppTight: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppTight {
    pub cp_p0: crate::emit::cpp::Cp,
    pub x_p1: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppTight {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let x_p1 = &self.x_p1;
        if cpp_loose(x_p1) {
            {
                let cp_p0 = cp_p0.clone();
                let x_p1 = x_p1.clone();
                call_then(start_cpp_expr(cp_p0.clone(), x_p1.clone()), move |cpp_expr_1500: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &cpp_expr_1500))))
            }
        } else {
            {
                let cp_p0 = cp_p0.clone();
                let x_p1 = x_p1.clone();
                call_then(start_cpp_expr(cp_p0.clone(), x_p1.clone()), move |cpp_expr_1532: Text| prism_rtl::Turn::Finished(starred(&cpp_expr_1532)))
            }
        }
    }
}

/// `Start CppTight, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_tight(cp_p0: crate::emit::cpp::Cp, x_p1: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppTight { cp_p0, x_p1 })
}

/// ```prism
/// Starred: fn Text -> Text
/// ```
pub fn starred(t_p0: &Text) -> Text {
    if crate::syntax::lexer::chars::has_prefix(t_p0, &Text::lit("*")) {
        Text::from(format!("({})", t_p0))
    } else {
        t_p0.clone()
    }
}

/// ```prism
/// CppTightPlace: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_tight_place(cp_p0: &crate::emit::cpp::Cp, x_p1: &crate::lower::model::Ex) -> Text {
    if cpp_loose(x_p1) {
        Text::from(format!("({})", &cpp_place(cp_p0, x_p1)))
    } else {
        starred(&cpp_place(cp_p0, x_p1))
    }
}

/// The step machine of `CppTightPlace`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppTightPlace: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppTightPlace {
    pub cp_p0: crate::emit::cpp::Cp,
    pub x_p1: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppTightPlace {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let x_p1 = &self.x_p1;
        if cpp_loose(x_p1) {
            {
                let cp_p0 = cp_p0.clone();
                let x_p1 = x_p1.clone();
                call_then(start_cpp_place(cp_p0.clone(), x_p1.clone()), move |cpp_place_1889: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &cpp_place_1889))))
            }
        } else {
            {
                let cp_p0 = cp_p0.clone();
                let x_p1 = x_p1.clone();
                call_then(start_cpp_place(cp_p0.clone(), x_p1.clone()), move |cpp_place_1922: Text| prism_rtl::Turn::Finished(starred(&cpp_place_1922)))
            }
        }
    }
}

/// `Start CppTightPlace, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_tight_place(cp_p0: crate::emit::cpp::Cp, x_p1: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppTightPlace { cp_p0, x_p1 })
}

/// ```prism
/// CppPlace: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_place(cp_p0: &crate::emit::cpp::Cp, ex1: &crate::lower::model::Ex) -> Text {
    match ex1 {
        crate::lower::model::Ex::XVar(n_p1) => crate::emit::cpp::stmts::var_name(cp_p0, n_p1),
        x_p3 => cpp_expr(cp_p0, x_p3),
    }
}

/// The step machine of `CppPlace`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppPlace: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppPlace {
    pub cp_p0: crate::emit::cpp::Cp,
    pub ex1: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppPlace {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let ex1 = &self.ex1;
        match ex1 {
            crate::lower::model::Ex::XVar(n_p1) => prism_rtl::Turn::Finished(crate::emit::cpp::stmts::var_name(cp_p0, n_p1)),
            x_p3 => prism_rtl::Turn::More(Rc::new(CppExpr { cp_p0: cp_p0.clone(), x_p1: x_p3.clone() })),
        }
    }
}

/// `Start CppPlace, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_place(cp_p0: crate::emit::cpp::Cp, ex1: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppPlace { cp_p0, ex1 })
}

/// ```prism
/// CppVar: fn Cp, Text -> Text
/// ```
pub fn cpp_var(cp_p0: &crate::emit::cpp::Cp, n_p1: &Text) -> Text {
    if or(&get(&cp_p0.owned, n_p1), &false) {
        Text::from(format!("std::move({})", &crate::emit::cpp::stmts::var_name(cp_p0, n_p1)))
    } else {
        crate::emit::cpp::stmts::var_name(cp_p0, n_p1)
    }
}

/// ```prism
/// CppArgs: unbounded fn Cp, [Ex] -> Text
/// ```
pub fn cpp_args(cp_p0: &crate::emit::cpp::Cp, xs_p1: &Array<crate::lower::model::Ex>) -> Text {
    crate::syntax::lexer::chars::join(&cpp_arg_list(cp_p0, xs_p1), &Text::lit(", "))
}

/// The step machine of `CppArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppArgs: unbounded fn Cp, [Ex] -> Text
/// ```
pub struct CppArgs {
    pub cp_p0: crate::emit::cpp::Cp,
    pub xs_p1: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for CppArgs {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let xs_p1 = &self.xs_p1;
        let cp_p0 = cp_p0.clone();
        let xs_p1 = xs_p1.clone();
        call_then(start_cpp_arg_list(cp_p0.clone(), xs_p1.clone()), move |cpp_arg_list_2810: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&cpp_arg_list_2810, &Text::lit(", "))))
    }
}

/// `Start CppArgs, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_args(cp_p0: crate::emit::cpp::Cp, xs_p1: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppArgs { cp_p0, xs_p1 })
}

/// ```prism
/// CppArgList: unbounded fn Cp, [Ex] -> [Text]
/// ```
pub fn cpp_arg_list(cp_p0: &crate::emit::cpp::Cp, xs_p1: &Array<crate::lower::model::Ex>) -> Array<Text> {
    let texts_p2 = run_to_end(each_job(xs_p1.clone(), {
        let cp_p0 = cp_p0.clone();
        Rc::new(move |p0: crate::lower::model::Ex| {
            let cp_p0 = cp_p0.clone();
            entered(once_job(move || {
                let x_p3 = p0;
                prism_rtl::Turn::More(Rc::new(CppExpr { cp_p0: cp_p0.clone(), x_p1: x_p3.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    each(&crate::check::errors::range0(&len(xs_p1)), &(|i_p4: &Nat| match or(&index(xs_p1, i_p4), &crate::lower::model::Ex::XUnit) {
        crate::lower::model::Ex::XVar(n_p5) => if fold(&crate::check::errors::range0(&len(xs_p1)), &false, &(|f_p6: &bool, j_p7: &Nat| *f_p6 || ((j_p7 != i_p4) && crate::emit::cpp::stmts::cpp_mentions(&or(&index(&texts_p2, j_p7), &Text::lit("")), &crate::emit::cpp::stmts::var_name(cp_p0, &n_p5))))) {
            crate::emit::cpp::stmts::var_name(cp_p0, &n_p5)
        } else {
            or(&index(&texts_p2, i_p4), &Text::lit(""))
        },
        _ => or(&index(&texts_p2, i_p4), &Text::lit("")),
    }))
}

/// The step machine of `CppArgList`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppArgList: unbounded fn Cp, [Ex] -> [Text]
/// ```
pub struct CppArgList {
    pub cp_p0: crate::emit::cpp::Cp,
    pub xs_p1: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Array<Text>> for CppArgList {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cp_p0 = &self.cp_p0;
        let xs_p1 = &self.xs_p1;
        let cp_p0 = cp_p0.clone();
        let xs_p1 = xs_p1.clone();
        call_value(each_job(xs_p1.clone(), {
            let cp_p0 = cp_p0.clone();
            Rc::new(move |p0: crate::lower::model::Ex| {
                let cp_p0 = cp_p0.clone();
                entered(once_job(move || {
                    let x_p3 = p0;
                    prism_rtl::Turn::More(Rc::new(CppExpr { cp_p0: cp_p0.clone(), x_p1: x_p3.clone() }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_2918: Array<Text>| {
            let texts_p2 = each_2918;
            prism_rtl::Turn::Finished(each(&crate::check::errors::range0(&len(&xs_p1)), &(|i_p4: &Nat| match or(&index(&xs_p1, i_p4), &crate::lower::model::Ex::XUnit) {
                crate::lower::model::Ex::XVar(n_p5) => if fold(&crate::check::errors::range0(&len(&xs_p1)), &false, &(|f_p6: &bool, j_p7: &Nat| *f_p6 || ((j_p7 != i_p4) && crate::emit::cpp::stmts::cpp_mentions(&or(&index(&texts_p2, j_p7), &Text::lit("")), &crate::emit::cpp::stmts::var_name(&cp_p0, &n_p5))))) {
                    crate::emit::cpp::stmts::var_name(&cp_p0, &n_p5)
                } else {
                    or(&index(&texts_p2, i_p4), &Text::lit(""))
                },
                _ => or(&index(&texts_p2, i_p4), &Text::lit("")),
            })))
        })
    }
}

/// `Start CppArgList, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_arg_list(cp_p0: crate::emit::cpp::Cp, xs_p1: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(CppArgList { cp_p0, xs_p1 })
}

/// ```prism
/// CppExpr: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_expr(cp_p0: &crate::emit::cpp::Cp, x_p1: &crate::lower::model::Ex) -> Text {
    match x_p1 {
        crate::lower::model::Ex::XVar(n_p2) => cpp_var(cp_p0, n_p2),
        crate::lower::model::Ex::XPath(p_p3) => path_value(cp_p0, p_p3),
        crate::lower::model::Ex::XSelf => Text::lit("prism_rtl::share(this)"),
        crate::lower::model::Ex::XCx => Text::lit("cx"),
        crate::lower::model::Ex::XConst(n_p4) => n_p4.clone(),
        crate::lower::model::Ex::XUnit => Text::lit("Unit{}"),
        crate::lower::model::Ex::XNone => Text::lit("std::nullopt"),
        crate::lower::model::Ex::XBool(b_p5) => if *b_p5 { Text::lit("true") } else { Text::lit("false") },
        crate::lower::model::Ex::XNat(d_p6) => if &len_text(d_p6) <= &Nat::from(9u32) {
            Text::from(format!("Nat({}u)", d_p6))
        } else {
            Text::from(format!("*Nat::from_int({})", &cpp_expr(cp_p0, &crate::lower::model::Ex::XInt(d_p6.clone()))))
        },
        crate::lower::model::Ex::XInt(d_p7) => if &len_text(&(if crate::syntax::lexer::chars::has_prefix(d_p7, &Text::lit("-")) {
            crate::syntax::lexer::chars::after_first(d_p7)
        } else {
            d_p7.clone()
        })) <= &Nat::from(18u32) {
            Text::from(format!("Int({}ll)", d_p7))
        } else {
            Text::from(format!("*Int::parse(\"{}\")", d_p7))
        },
        crate::lower::model::Ex::XByte(d_p8) => Text::from(format!("std::uint8_t({})", d_p8)),
        crate::lower::model::Ex::XFloat(d_p9) => Text::from(format!("Float{{{}}}", d_p9)),
        crate::lower::model::Ex::XIndex(n_pa) => Text::from(format!("{}u", n_pa)),
        crate::lower::model::Ex::XChar(c_pb) => Text::from(format!("U\'{}\'", &cpp_char_escape(c_pb))),
        crate::lower::model::Ex::XStr(t_pc) => cpp_string(t_pc),
        crate::lower::model::Ex::XRegex(p_pd, f_pe) => Text::from(format!("([]() -> const Regex& {{ static const Regex r = Regex::lit({}, {}); return r; }}())", &cpp_string(p_pd), &cpp_string(f_pe))),
        crate::lower::model::Ex::XReplacement(p_pf, r_pg, f_ph) => Text::from(format!("([]() -> const RegexReplacement& {{ static const RegexReplacement r = RegexReplacement::lit({}, {}, {}); return r; }}())", &cpp_string(p_pf), &cpp_string(f_ph), &cpp_string(r_pg))),
        crate::lower::model::Ex::XRef(y_pi) => cpp_place(cp_p0, &**y_pi),
        crate::lower::model::Ex::XRefMut(y_pj) => cpp_place(cp_p0, &**y_pj),
        crate::lower::model::Ex::XDeref(y_pk) => match ex_ty(cp_p0, &**y_pk) {
            Some(crate::lower::model::OutTy::OutRc(_)) => Text::from(format!("*{}", &cpp_tight_place(cp_p0, &**y_pk))),
            Some(crate::lower::model::OutTy::OutRef(_)) => cpp_place(cp_p0, &**y_pk),
            _ => Text::from(format!("prism_rtl::deref({})", &cpp_place(cp_p0, &**y_pk))),
        },
        crate::lower::model::Ex::XTarget(y_pl) => cpp_place(cp_p0, &**y_pl),
        crate::lower::model::Ex::XClone(y_pm) => cpp_place(cp_p0, &**y_pm),
        crate::lower::model::Ex::XWeak(y_pn) => Text::from(format!("prism_rtl::weaken({})", &cpp_expr(cp_p0, &**y_pn))),
        crate::lower::model::Ex::XUpgrade(y_po) => Text::from(format!("prism_rtl::upgrade({})", &cpp_expr(cp_p0, &**y_po))),
        crate::lower::model::Ex::XBreak(l_pp, y_pq) => Text::from(format!("({})", &crate::emit::cpp::patterns::cpp_break(cp_p0, l_pp, &**y_pq))),
        crate::lower::model::Ex::XBreakLoop => Text::lit("({ break; })"),
        crate::lower::model::Ex::XLater(y_pr) => Text::from(format!("[=](Cx& cx) -> Done {{ {}; return {{}}; }}", &cpp_expr(&crate::emit::cpp::stmts::captured(cp_p0), &**y_pr))),
        crate::lower::model::Ex::XFormatStr(parts_ps) => cpp_format(cp_p0, parts_ps, &Text::lit("prism_rtl::str")),
        crate::lower::model::Ex::XIsCase(y_pt, m3254_28_1) if (m3254_28_1.len() == 0) => Text::lit("false"),
        crate::lower::model::Ex::XIsCase(y_pu, cs_pv) => Text::from(format!("({})", &crate::syntax::lexer::chars::join(&run_to_end(each_job(cs_pv.clone(), {
            let cp_p0 = cp_p0.clone();
            let y_pu = (**y_pu).clone();
            Rc::new(move |p0: Text| {
                let cp_p0 = cp_p0.clone();
                let y_pu = y_pu.clone();
                entered(once_job(move || {
                    let c_p10 = p0;
                    call_then(start_cpp_tight_place(cp_p0.clone(), y_pu.clone()), move |cpp_tight_place_5408: Text| prism_rtl::Turn::Finished(case_test(&cp_p0, &c_p10, &cpp_tight_place_5408)))
                }))
            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>
        })), &Text::lit(" || ")))),
        crate::lower::model::Ex::XRefusal(what_p11) => Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::expr::lowering_refusal(), &crate::lower::expr::escape(what_p11))),
        crate::lower::model::Ex::XUnreachable => Text::lit("throw prism_rtl::Panic(\"entered unreachable code\")"),
        crate::lower::model::Ex::XCall(f_p12, args_p13) => cpp_call(cp_p0, f_p12, args_p13),
        crate::lower::model::Ex::XApply(f_p14, args_p15) => Text::from(format!("{}({})", &cpp_tight_place(cp_p0, &**f_p14), &cpp_args(cp_p0, args_p15))),
        crate::lower::model::Ex::XMethod(r_p16, m_p17, args_p18) => cpp_method(cp_p0, &**r_p16, m_p17, args_p18),
        crate::lower::model::Ex::XBin(op_p19, l_p1a, r_p1b) => {
            let (lt_p1e, rt_p1f) = 'm5782: {
                let scrutinee = &cpp_arg_list(cp_p0, &Array::from(vec![(**l_p1a).clone(), (**r_p1b).clone()]));
                if let m5782_0 = scrutinee && (m5782_0.len() == 2) && let Some(a_p1c) = index(m5782_0, &Nat::from(0u32)) && let Some(b_p1d) = index(m5782_0, &Nat::from(1u32)) {
                    break 'm5782 (a_p1c.clone(), b_p1d.clone());
                }
                (Text::lit(""), Text::lit(""))
            };
            Text::from(format!("{} {} {}", &(if cpp_loose(&**l_p1a) { Text::from(format!("({})", &lt_p1e)) } else { lt_p1e.clone() }), op_p19, &(if cpp_loose(&**r_p1b) { Text::from(format!("({})", &rt_p1f)) } else { rt_p1f.clone() })))
        },
        crate::lower::model::Ex::XUnary(op_p1g, y_p1h) => Text::from(format!("{}{}", op_p1g, &cpp_tight(cp_p0, &**y_p1h))),
        crate::lower::model::Ex::XCtor(p_p1i, args_p1j) => cpp_ctor(cp_p0, p_p1i, args_p1j),
        crate::lower::model::Ex::XRecord(p_p1k, fs_p1l) => cpp_record(cp_p0, p_p1k, fs_p1l),
        crate::lower::model::Ex::XTuple(xs_p1m) => Text::from(format!("std::tuple{{{}}}", &cpp_args(cp_p0, xs_p1m))),
        crate::lower::model::Ex::XVec(m3254_40_0) if (m3254_40_0.len() == 0) => Text::lit("{}"),
        crate::lower::model::Ex::XVec(xs_p1n) => Text::from(format!("std::vector{{{}}}", &cpp_args(cp_p0, xs_p1n))),
        crate::lower::model::Ex::XText(t_p1o) => Text::from(format!("Text::lit({})", &cpp_string(t_p1o))),
        crate::lower::model::Ex::XFormat(parts_p1p) => if fold(parts_p1p, &true, &(|f_p1q: &bool, p_p1r: &crate::lower::model::Ex| *f_p1q && is_text_piece(p_p1r))) {
            Text::from(format!("Text::lit({})", &cpp_string(&concat(&each(parts_p1p, &(|p_p1s: &crate::lower::model::Ex| text_piece(p_p1s)))))))
        } else {
            cpp_format(cp_p0, parts_p1p, &Text::lit("prism_rtl::cat"))
        },
        crate::lower::model::Ex::XMatch(s_p1t, arms_p1u, fallback_p1v, t_p20) => crate::emit::cpp::patterns::cpp_match(cp_p0, &**s_p1t, arms_p1u, t_p20),
        crate::lower::model::Ex::XChain(label_p21, s_p22, arms_p23, t_p24) => crate::emit::cpp::patterns::cpp_match(cp_p0, &**s_p22, arms_p23, t_p24),
        crate::lower::model::Ex::XIf(c_p25, t_p26, e_p27) => cpp_if(cp_p0, &**c_p25, &**t_p26, &**e_p27),
        crate::lower::model::Ex::XBlock(m3254_47_0, e_p28) if (m3254_47_0.len() == 0) => cpp_expr(cp_p0, &**e_p28),
        crate::lower::model::Ex::XBlock(dos_p29, e_p2a) => {
            let (st_p2b, cp2_p2c) = crate::emit::cpp::stmts::cpp_statements_cp(cp_p0, dos_p29);
            crate::emit::cpp::templates::items::stmt_expr(&st_p2b, &crate::emit::cpp::stmts::unvexed(&cpp_expr(&with_move_captures(&cp2_p2c, dos_p29, &**e_p2a), &**e_p2a)))
        },
        crate::lower::model::Ex::XLabeled(label_p2d, dos_p2e, e_p2f, t_p2g) => crate::emit::cpp::patterns::cpp_labeled(cp_p0, label_p2d, dos_p2e, &**e_p2f, t_p2g),
        crate::lower::model::Ex::XClosure(mv_p2h, ps_p2i, body_p2j) => cpp_closure(cp_p0, mv_p2h, ps_p2i, &**body_p2j),
        crate::lower::model::Ex::XTry(y_p2k) => Text::from(format!("TRY({})", &cpp_expr(cp_p0, &**y_p2k))),
        crate::lower::model::Ex::XField(r_p2l, f_p2m) => cpp_field(cp_p0, &**r_p2l, f_p2m),
        crate::lower::model::Ex::XPart(r_p2n, k_p2o) => Text::from(format!("std::get<{}>({})", k_p2o, &as_value(cp_p0, &**r_p2n))),
        crate::lower::model::Ex::XDecode(t_p2p, y_p2q) => Text::from(format!("TRY(prism_rtl::from_pod<{}>({}))", &crate::emit::cpp::cpp_type(cp_p0, t_p2p), &cpp_expr(cp_p0, &**y_p2q))),
        crate::lower::model::Ex::XCast(y_p2r, t_p2s) => Text::from(format!("static_cast<{}>({})", &crate::emit::cpp::cpp_type(cp_p0, t_p2s), &cpp_expr(cp_p0, &**y_p2r))),
        crate::lower::model::Ex::XTyped(y_p2t, t_p2u) => match &**y_p2t {
            crate::lower::model::Ex::XCtor(p_p2v, args_p30) if is_generic_case(cp_p0, p_p2v) => {
                let tt_p31 = crate::emit::cpp::cpp_type(cp_p0, t_p2u);
                Text::from(format!("{}({}::{}{{{}}})", &tt_p31, &tt_p31, &crate::emit::cpp::last_segment(&crate::emit::cpp::type_path(p_p2v)), &cpp_args(cp_p0, args_p30)))
            },
            crate::lower::model::Ex::XPath(p_p32) if is_generic_case(cp_p0, p_p32) => {
                let tt_p33 = crate::emit::cpp::cpp_type(cp_p0, t_p2u);
                Text::from(format!("{}({}::{}{{}})", &tt_p33, &tt_p33, &crate::emit::cpp::last_segment(&crate::emit::cpp::type_path(p_p32))))
            },
            _ => {
                let e_p34 = cpp_expr(cp_p0, &**y_p2t);
                if (&e_p34 == &Text::lit("{}")) || (&e_p34 == &Text::lit("std::nullopt")) {
                    Text::from(format!("{}{{}}", &crate::emit::cpp::cpp_type(cp_p0, t_p2u)))
                } else {
                    if is_ctor(&**y_p2t, &Text::lit("Ok")) || is_ctor(&**y_p2t, &Text::lit("Err")) {
                        Text::from(format!("{}({})", &crate::emit::cpp::cpp_type(cp_p0, t_p2u), &e_p34))
                    } else {
                        e_p34.clone()
                    }
                }
            },
            _ => unreachable!("no arm matched"),
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CppExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppExpr: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppExpr {
    pub cp_p0: crate::emit::cpp::Cp,
    pub x_p1: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppExpr {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let x_p1 = &self.x_p1;
        match x_p1 {
            crate::lower::model::Ex::XVar(n_p2) => prism_rtl::Turn::Finished(cpp_var(cp_p0, n_p2)),
            crate::lower::model::Ex::XPath(p_p3) => prism_rtl::Turn::Finished(path_value(cp_p0, p_p3)),
            crate::lower::model::Ex::XSelf => prism_rtl::Turn::Finished(Text::lit("prism_rtl::share(this)")),
            crate::lower::model::Ex::XCx => prism_rtl::Turn::Finished(Text::lit("cx")),
            crate::lower::model::Ex::XConst(n_p4) => prism_rtl::Turn::Finished(n_p4.clone()),
            crate::lower::model::Ex::XUnit => prism_rtl::Turn::Finished(Text::lit("Unit{}")),
            crate::lower::model::Ex::XNone => prism_rtl::Turn::Finished(Text::lit("std::nullopt")),
            crate::lower::model::Ex::XBool(b_p5) => if *b_p5 {
                prism_rtl::Turn::Finished(Text::lit("true"))
            } else {
                prism_rtl::Turn::Finished(Text::lit("false"))
            },
            crate::lower::model::Ex::XNat(d_p6) => if &len_text(d_p6) <= &Nat::from(9u32) {
                prism_rtl::Turn::Finished(Text::from(format!("Nat({}u)", d_p6)))
            } else {
                {
                    let cp_p0 = cp_p0.clone();
                    let d_p6 = d_p6.clone();
                    call_then(start_cpp_expr(cp_p0.clone(), crate::lower::model::Ex::XInt(d_p6.clone())), move |cpp_expr_3535: Text| prism_rtl::Turn::Finished(Text::from(format!("*Nat::from_int({})", &cpp_expr_3535))))
                }
            },
            crate::lower::model::Ex::XInt(d_p7) => if &len_text(&(if crate::syntax::lexer::chars::has_prefix(d_p7, &Text::lit("-")) {
                crate::syntax::lexer::chars::after_first(d_p7)
            } else {
                d_p7.clone()
            })) <= &Nat::from(18u32) {
                prism_rtl::Turn::Finished(Text::from(format!("Int({}ll)", d_p7)))
            } else {
                prism_rtl::Turn::Finished(Text::from(format!("*Int::parse(\"{}\")", d_p7)))
            },
            crate::lower::model::Ex::XByte(d_p8) => prism_rtl::Turn::Finished(Text::from(format!("std::uint8_t({})", d_p8))),
            crate::lower::model::Ex::XFloat(d_p9) => prism_rtl::Turn::Finished(Text::from(format!("Float{{{}}}", d_p9))),
            crate::lower::model::Ex::XIndex(n_pa) => prism_rtl::Turn::Finished(Text::from(format!("{}u", n_pa))),
            crate::lower::model::Ex::XChar(c_pb) => prism_rtl::Turn::Finished(Text::from(format!("U\'{}\'", &cpp_char_escape(c_pb)))),
            crate::lower::model::Ex::XStr(t_pc) => prism_rtl::Turn::Finished(cpp_string(t_pc)),
            crate::lower::model::Ex::XRegex(p_pd, f_pe) => prism_rtl::Turn::Finished(Text::from(format!("([]() -> const Regex& {{ static const Regex r = Regex::lit({}, {}); return r; }}())", &cpp_string(p_pd), &cpp_string(f_pe)))),
            crate::lower::model::Ex::XReplacement(p_pf, r_pg, f_ph) => prism_rtl::Turn::Finished(Text::from(format!("([]() -> const RegexReplacement& {{ static const RegexReplacement r = RegexReplacement::lit({}, {}, {}); return r; }}())", &cpp_string(p_pf), &cpp_string(f_ph), &cpp_string(r_pg)))),
            crate::lower::model::Ex::XRef(y_pi) => prism_rtl::Turn::More(Rc::new(CppPlace { cp_p0: cp_p0.clone(), ex1: (**y_pi).clone() })),
            crate::lower::model::Ex::XRefMut(y_pj) => prism_rtl::Turn::More(Rc::new(CppPlace { cp_p0: cp_p0.clone(), ex1: (**y_pj).clone() })),
            crate::lower::model::Ex::XDeref(y_pk) => match ex_ty(cp_p0, &**y_pk) {
                Some(crate::lower::model::OutTy::OutRc(_)) => {
                    let cp_p0 = cp_p0.clone();
                    let y_pk = (**y_pk).clone();
                    call_then(start_cpp_tight_place(cp_p0.clone(), y_pk.clone()), move |cpp_tight_place_4820: Text| prism_rtl::Turn::Finished(Text::from(format!("*{}", &cpp_tight_place_4820))))
                },
                Some(crate::lower::model::OutTy::OutRef(_)) => prism_rtl::Turn::More(Rc::new(CppPlace { cp_p0: cp_p0.clone(), ex1: (**y_pk).clone() })),
                _ => {
                    let cp_p0 = cp_p0.clone();
                    let y_pk = (**y_pk).clone();
                    call_then(start_cpp_place(cp_p0.clone(), y_pk.clone()), move |cpp_place_4922: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::deref({})", &cpp_place_4922))))
                },
            },
            crate::lower::model::Ex::XTarget(y_pl) => prism_rtl::Turn::More(Rc::new(CppPlace { cp_p0: cp_p0.clone(), ex1: (**y_pl).clone() })),
            crate::lower::model::Ex::XClone(y_pm) => prism_rtl::Turn::More(Rc::new(CppPlace { cp_p0: cp_p0.clone(), ex1: (**y_pm).clone() })),
            crate::lower::model::Ex::XWeak(y_pn) => {
                let cp_p0 = cp_p0.clone();
                let y_pn = (**y_pn).clone();
                call_then(start_cpp_expr(cp_p0.clone(), y_pn.clone()), move |cpp_expr_5032: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::weaken({})", &cpp_expr_5032))))
            },
            crate::lower::model::Ex::XUpgrade(y_po) => {
                let cp_p0 = cp_p0.clone();
                let y_po = (**y_po).clone();
                call_then(start_cpp_expr(cp_p0.clone(), y_po.clone()), move |cpp_expr_5086: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::upgrade({})", &cpp_expr_5086))))
            },
            crate::lower::model::Ex::XBreak(l_pp, y_pq) => {
                let cp_p0 = cp_p0.clone();
                let l_pp = l_pp.clone();
                let y_pq = (**y_pq).clone();
                call_then(crate::emit::cpp::patterns::start_cpp_break(cp_p0.clone(), l_pp.clone(), y_pq.clone()), move |cpp_break_5123: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &cpp_break_5123))))
            },
            crate::lower::model::Ex::XBreakLoop => prism_rtl::Turn::Finished(Text::lit("({ break; })")),
            crate::lower::model::Ex::XLater(y_pr) => {
                let cp_p0 = cp_p0.clone();
                let y_pr = (**y_pr).clone();
                call_then(start_cpp_expr(crate::emit::cpp::stmts::captured(&cp_p0), y_pr.clone()), move |cpp_expr_5216: Text| prism_rtl::Turn::Finished(Text::from(format!("[=](Cx& cx) -> Done {{ {}; return {{}}; }}", &cpp_expr_5216))))
            },
            crate::lower::model::Ex::XFormatStr(parts_ps) => prism_rtl::Turn::More(Rc::new(CppFormat { cp_p0: cp_p0.clone(), parts_p1: parts_ps.clone(), how_p2: Text::lit("prism_rtl::str") })),
            crate::lower::model::Ex::XIsCase(y_pt, m3254_28_1) if (m3254_28_1.len() == 0) => prism_rtl::Turn::Finished(Text::lit("false")),
            crate::lower::model::Ex::XIsCase(y_pu, cs_pv) => {
                let cp_p0 = cp_p0.clone();
                let cs_pv = cs_pv.clone();
                let y_pu = (**y_pu).clone();
                call_value(each_job(cs_pv.clone(), {
                    let cp_p0 = cp_p0.clone();
                    let y_pu = y_pu.clone();
                    Rc::new(move |p0: Text| {
                        let cp_p0 = cp_p0.clone();
                        let y_pu = y_pu.clone();
                        entered(once_job(move || {
                            let c_p10 = p0;
                            call_then(start_cpp_tight_place(cp_p0.clone(), y_pu.clone()), move |cpp_tight_place_5408: Text| prism_rtl::Turn::Finished(case_test(&cp_p0, &c_p10, &cpp_tight_place_5408)))
                        }))
                    }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_5377: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("({})", &crate::syntax::lexer::chars::join(&each_5377, &Text::lit(" || "))))))
            },
            crate::lower::model::Ex::XRefusal(what_p11) => prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::expr::lowering_refusal(), &crate::lower::expr::escape(what_p11)))),
            crate::lower::model::Ex::XUnreachable => prism_rtl::Turn::Finished(Text::lit("throw prism_rtl::Panic(\"entered unreachable code\")")),
            crate::lower::model::Ex::XCall(f_p12, args_p13) => prism_rtl::Turn::More(Rc::new(CppCall { cp_p0: cp_p0.clone(), f_p1: f_p12.clone(), args_p2: args_p13.clone() })),
            crate::lower::model::Ex::XApply(f_p14, args_p15) => {
                let args_p15 = args_p15.clone();
                let cp_p0 = cp_p0.clone();
                let f_p14 = (**f_p14).clone();
                call_then(start_cpp_tight_place(cp_p0.clone(), f_p14.clone()), move |cpp_tight_place_5647: Text| call_then(start_cpp_args(cp_p0.clone(), args_p15.clone()), move |cpp_args_5669: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &cpp_tight_place_5647, &cpp_args_5669)))))
            },
            crate::lower::model::Ex::XMethod(r_p16, m_p17, args_p18) => prism_rtl::Turn::More(Rc::new(CppMethod { cp_p0: cp_p0.clone(), r_p1: (**r_p16).clone(), m_p2: m_p17.clone(), args_p3: args_p18.clone() })),
            crate::lower::model::Ex::XBin(op_p19, l_p1a, r_p1b) => {
                let cp_p0 = cp_p0.clone();
                let l_p1a = (**l_p1a).clone();
                let op_p19 = op_p19.clone();
                let r_p1b = (**r_p1b).clone();
                call_then(start_cpp_arg_list(cp_p0.clone(), Array::from(vec![l_p1a.clone(), r_p1b.clone()])), move |cpp_arg_list_5788: Array<Text>| {
                    let (lt_p1e, rt_p1f) = 'm5782: {
                        if let m5782_0 = &cpp_arg_list_5788 && (m5782_0.len() == 2) && let Some(a_p1c) = index(m5782_0, &Nat::from(0u32)) && let Some(b_p1d) = index(m5782_0, &Nat::from(1u32)) {
                            break 'm5782 (a_p1c.clone(), b_p1d.clone());
                        }
                        (Text::lit(""), Text::lit(""))
                    };
                    prism_rtl::Turn::Finished(Text::from(format!("{} {} {}", &(if cpp_loose(&l_p1a) { Text::from(format!("({})", &lt_p1e)) } else { lt_p1e.clone() }), &op_p19, &(if cpp_loose(&r_p1b) { Text::from(format!("({})", &rt_p1f)) } else { rt_p1f.clone() }))))
                })
            },
            crate::lower::model::Ex::XUnary(op_p1g, y_p1h) => {
                let cp_p0 = cp_p0.clone();
                let op_p1g = op_p1g.clone();
                let y_p1h = (**y_p1h).clone();
                call_then(start_cpp_tight(cp_p0.clone(), y_p1h.clone()), move |cpp_tight_5987: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &op_p1g, &cpp_tight_5987))))
            },
            crate::lower::model::Ex::XCtor(p_p1i, args_p1j) => prism_rtl::Turn::More(Rc::new(CppCtor { cp_p0: cp_p0.clone(), p_p1: p_p1i.clone(), args_p2: args_p1j.clone() })),
            crate::lower::model::Ex::XRecord(p_p1k, fs_p1l) => prism_rtl::Turn::More(Rc::new(CppRecord { cp_p0: cp_p0.clone(), p_p1: p_p1k.clone(), fs_p2: fs_p1l.clone() })),
            crate::lower::model::Ex::XTuple(xs_p1m) => {
                let cp_p0 = cp_p0.clone();
                let xs_p1m = xs_p1m.clone();
                call_then(start_cpp_args(cp_p0.clone(), xs_p1m.clone()), move |cpp_args_6111: Text| prism_rtl::Turn::Finished(Text::from(format!("std::tuple{{{}}}", &cpp_args_6111))))
            },
            crate::lower::model::Ex::XVec(m3254_40_0) if (m3254_40_0.len() == 0) => prism_rtl::Turn::Finished(Text::lit("{}")),
            crate::lower::model::Ex::XVec(xs_p1n) => {
                let cp_p0 = cp_p0.clone();
                let xs_p1n = xs_p1n.clone();
                call_then(start_cpp_args(cp_p0.clone(), xs_p1n.clone()), move |cpp_args_6180: Text| prism_rtl::Turn::Finished(Text::from(format!("std::vector{{{}}}", &cpp_args_6180))))
            },
            crate::lower::model::Ex::XText(t_p1o) => prism_rtl::Turn::Finished(Text::from(format!("Text::lit({})", &cpp_string(t_p1o)))),
            crate::lower::model::Ex::XFormat(parts_p1p) => if fold(parts_p1p, &true, &(|f_p1q: &bool, p_p1r: &crate::lower::model::Ex| *f_p1q && is_text_piece(p_p1r))) {
                prism_rtl::Turn::Finished(Text::from(format!("Text::lit({})", &cpp_string(&concat(&each(parts_p1p, &(|p_p1s: &crate::lower::model::Ex| text_piece(p_p1s))))))))
            } else {
                prism_rtl::Turn::More(Rc::new(CppFormat { cp_p0: cp_p0.clone(), parts_p1: parts_p1p.clone(), how_p2: Text::lit("prism_rtl::cat") }))
            },
            crate::lower::model::Ex::XMatch(s_p1t, arms_p1u, fallback_p1v, t_p20) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::patterns::CppMatch { cp_p0: cp_p0.clone(), s_p1: (**s_p1t).clone(), arms_p2: arms_p1u.clone(), out_ty3: t_p20.clone() })),
            crate::lower::model::Ex::XChain(label_p21, s_p22, arms_p23, t_p24) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::patterns::CppMatch { cp_p0: cp_p0.clone(), s_p1: (**s_p22).clone(), arms_p2: arms_p23.clone(), out_ty3: t_p24.clone() })),
            crate::lower::model::Ex::XIf(c_p25, t_p26, e_p27) => prism_rtl::Turn::More(Rc::new(CppIf { cp_p0: cp_p0.clone(), c_p1: (**c_p25).clone(), t_p2: (**t_p26).clone(), e_p3: (**e_p27).clone() })),
            crate::lower::model::Ex::XBlock(m3254_47_0, e_p28) if (m3254_47_0.len() == 0) => prism_rtl::Turn::More(Rc::new(CppExpr { cp_p0: cp_p0.clone(), x_p1: (**e_p28).clone() })),
            crate::lower::model::Ex::XBlock(dos_p29, e_p2a) => {
                let cp_p0 = cp_p0.clone();
                let dos_p29 = dos_p29.clone();
                let e_p2a = (**e_p2a).clone();
                call_then(crate::emit::cpp::stmts::start_cpp_statements_cp(cp_p0.clone(), dos_p29.clone()), move |cpp_statements_cp_6642: (Text, crate::emit::cpp::Cp)| {
                    let (st_p2b, cp2_p2c) = cpp_statements_cp_6642;
                    call_then(start_with_move_captures(cp2_p2c.clone(), dos_p29.clone(), e_p2a.clone()), move |with_move_captures_6706: crate::emit::cpp::Cp| call_then(start_cpp_expr(with_move_captures_6706, e_p2a.clone()), move |cpp_expr_6697: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::stmt_expr(&st_p2b, &crate::emit::cpp::stmts::unvexed(&cpp_expr_6697)))))
                })
            },
            crate::lower::model::Ex::XLabeled(label_p2d, dos_p2e, e_p2f, t_p2g) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::patterns::CppLabeled { cp_p0: cp_p0.clone(), label_p1: label_p2d.clone(), dos_p2: dos_p2e.clone(), e_p3: (**e_p2f).clone(), t_p4: t_p2g.clone() })),
            crate::lower::model::Ex::XClosure(mv_p2h, ps_p2i, body_p2j) => prism_rtl::Turn::More(Rc::new(CppClosure { cp0_p0: cp_p0.clone(), mv_p1: *mv_p2h, ps_p2: ps_p2i.clone(), body_p3: (**body_p2j).clone() })),
            crate::lower::model::Ex::XTry(y_p2k) => {
                let cp_p0 = cp_p0.clone();
                let y_p2k = (**y_p2k).clone();
                call_then(start_cpp_expr(cp_p0.clone(), y_p2k.clone()), move |cpp_expr_6877: Text| prism_rtl::Turn::Finished(Text::from(format!("TRY({})", &cpp_expr_6877))))
            },
            crate::lower::model::Ex::XField(r_p2l, f_p2m) => prism_rtl::Turn::More(Rc::new(CppField { cp_p0: cp_p0.clone(), ex1: (**r_p2l).clone(), f_p1: f_p2m.clone() })),
            crate::lower::model::Ex::XPart(r_p2n, k_p2o) => {
                let cp_p0 = cp_p0.clone();
                let k_p2o = k_p2o.clone();
                let r_p2n = (**r_p2n).clone();
                call_then(start_as_value(cp_p0.clone(), r_p2n.clone()), move |as_value_6961: Text| prism_rtl::Turn::Finished(Text::from(format!("std::get<{}>({})", &k_p2o, &as_value_6961))))
            },
            crate::lower::model::Ex::XDecode(t_p2p, y_p2q) => {
                let cp_p0 = cp_p0.clone();
                let t_p2p = t_p2p.clone();
                let y_p2q = (**y_p2q).clone();
                call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), t_p2p.clone()), move |cpp_type_7022: Text| call_then(start_cpp_expr(cp_p0.clone(), y_p2q.clone()), move |cpp_expr_7039: Text| prism_rtl::Turn::Finished(Text::from(format!("TRY(prism_rtl::from_pod<{}>({}))", &cpp_type_7022, &cpp_expr_7039)))))
            },
            crate::lower::model::Ex::XCast(y_p2r, t_p2s) => {
                let cp_p0 = cp_p0.clone();
                let t_p2s = t_p2s.clone();
                let y_p2r = (**y_p2r).clone();
                call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), t_p2s.clone()), move |cpp_type_7087: Text| call_then(start_cpp_expr(cp_p0.clone(), y_p2r.clone()), move |cpp_expr_7104: Text| prism_rtl::Turn::Finished(Text::from(format!("static_cast<{}>({})", &cpp_type_7087, &cpp_expr_7104)))))
            },
            crate::lower::model::Ex::XTyped(y_p2t, t_p2u) => match &**y_p2t {
                crate::lower::model::Ex::XCtor(p_p2v, args_p30) if is_generic_case(cp_p0, p_p2v) => {
                    let args_p30 = args_p30.clone();
                    let cp_p0 = cp_p0.clone();
                    let p_p2v = p_p2v.clone();
                    let t_p2u = t_p2u.clone();
                    call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), t_p2u.clone()), move |cpp_type_7214: Text| {
                        let tt_p31 = cpp_type_7214;
                        call_then(start_cpp_args(cp_p0.clone(), args_p30.clone()), move |cpp_args_7281: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({}::{}{{{}}})", &tt_p31, &tt_p31, &crate::emit::cpp::last_segment(&crate::emit::cpp::type_path(&p_p2v)), &cpp_args_7281))))
                    })
                },
                crate::lower::model::Ex::XPath(p_p32) if is_generic_case(cp_p0, p_p32) => {
                    let cp_p0 = cp_p0.clone();
                    let p_p32 = p_p32.clone();
                    let t_p2u = t_p2u.clone();
                    call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), t_p2u.clone()), move |cpp_type_7364: Text| {
                        let tt_p33 = cpp_type_7364;
                        prism_rtl::Turn::Finished(Text::from(format!("{}({}::{}{{}})", &tt_p33, &tt_p33, &crate::emit::cpp::last_segment(&crate::emit::cpp::type_path(&p_p32)))))
                    })
                },
                _ => {
                    let cp_p0 = cp_p0.clone();
                    let t_p2u = t_p2u.clone();
                    let y_p2t = (**y_p2t).clone();
                    call_then(start_cpp_expr(cp_p0.clone(), y_p2t.clone()), move |cpp_expr_7474: Text| {
                        let e_p34 = cpp_expr_7474;
                        if (&e_p34 == &Text::lit("{}")) || (&e_p34 == &Text::lit("std::nullopt")) {
                            call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), t_p2u.clone()), move |cpp_type_7541: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{{}}", &cpp_type_7541))))
                        } else {
                            if is_ctor(&y_p2t, &Text::lit("Ok")) || is_ctor(&y_p2t, &Text::lit("Err")) {
                                call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), t_p2u.clone()), move |cpp_type_7621: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &cpp_type_7621, &e_p34))))
                            } else {
                                prism_rtl::Turn::Finished(e_p34.clone())
                            }
                        }
                    })
                },
                _ => unreachable!("no arm matched"),
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start CppExpr, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_expr(cp_p0: crate::emit::cpp::Cp, x_p1: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppExpr { cp_p0, x_p1 })
}

/// ```prism
/// CppString: fn Text -> Text
/// ```
pub fn cpp_string(t_p0: &Text) -> Text {
    if crate::syntax::lexer::chars::contains(t_p0, &Text::lit("\0")) {
        Text::from(format!("\"{}\"sv", &cpp_escape(t_p0)))
    } else {
        Text::from(format!("\"{}\"", &cpp_escape(t_p0)))
    }
}

/// ```prism
/// CppEscape: fn Text -> Text
/// ```
pub fn cpp_escape(t_p0: &Text) -> Text {
    crate::syntax::lexer::chars::map_chars(t_p0, &(Rc::new(move |p0: Text| once_job(move || {
        let c_p1 = p0;
        if &c_p1 == &Text::lit("\0") {
            prism_rtl::Turn::Finished(Text::lit("\\000"))
        } else {
            prism_rtl::Turn::Finished(crate::lower::expr::char_escape(&c_p1))
        }
    })) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>))
}

/// ```prism
/// IsTextPiece: fn Ex -> Bool
/// ```
pub fn is_text_piece(ex0: &crate::lower::model::Ex) -> bool {
    match ex0 {
        crate::lower::model::Ex::XText(_) => true,
        other_p0 => false,
    }
}

/// ```prism
/// TextPiece: fn Ex -> Text
/// ```
pub fn text_piece(ex0: &crate::lower::model::Ex) -> Text {
    match ex0 {
        crate::lower::model::Ex::XText(t_p0) => t_p0.clone(),
        other_p1 => Text::lit(""),
    }
}

/// ```prism
/// CppFormat: unbounded fn Cp, [Ex], Text -> Text
/// ```
pub fn cpp_format(cp_p0: &crate::emit::cpp::Cp, parts_p1: &Array<crate::lower::model::Ex>, how_p2: &Text) -> Text {
    Text::from(format!("{}({})", how_p2, &crate::syntax::lexer::chars::join(&cpp_arg_list(cp_p0, &each(parts_p1, &(|p_p3: &crate::lower::model::Ex| format_arg(p_p3)))), &Text::lit(", "))))
}

/// The step machine of `CppFormat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppFormat: unbounded fn Cp, [Ex], Text -> Text
/// ```
pub struct CppFormat {
    pub cp_p0: crate::emit::cpp::Cp,
    pub parts_p1: Array<crate::lower::model::Ex>,
    pub how_p2: Text,
}

impl prism_rtl::Job<Text> for CppFormat {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let parts_p1 = &self.parts_p1;
        let how_p2 = &self.how_p2;
        let cp_p0 = cp_p0.clone();
        let how_p2 = how_p2.clone();
        let parts_p1 = parts_p1.clone();
        call_then(start_cpp_arg_list(cp_p0.clone(), each(&parts_p1, &(|p_p3: &crate::lower::model::Ex| format_arg(p_p3)))), move |cpp_arg_list_8417: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &how_p2, &crate::syntax::lexer::chars::join(&cpp_arg_list_8417, &Text::lit(", "))))))
    }
}

/// `Start CppFormat, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_format(cp_p0: crate::emit::cpp::Cp, parts_p1: Array<crate::lower::model::Ex>, how_p2: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppFormat { cp_p0, parts_p1, how_p2 })
}

/// ```prism
/// FormatArg: fn Ex -> Ex
/// ```
pub fn format_arg(ex0: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    match ex0 {
        crate::lower::model::Ex::XText(t_p0) => crate::lower::model::Ex::XStr(t_p0.clone()),
        x_p1 => x_p1.clone(),
    }
}

/// ```prism
/// CppCharEscape: fn Text -> Text
/// ```
pub fn cpp_char_escape(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("\'")) => Text::lit("\\\'"),
        c_p0 => crate::lower::expr::char_escape(c_p0),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// PathValue: fn Cp, Text -> Text
/// ```
pub fn path_value(cp_p0: &crate::emit::cpp::Cp, p_p1: &Text) -> Text {
    if is_node_method(cp_p0, p_p1) {
        Text::from(format!("&{}::{}", &crate::emit::cpp::type_path(&crate::emit::cpp::parent_path(p_p1)), &node_method_name(cp_p0, &crate::emit::cpp::last_segment(p_p1))))
    } else {
        match crate::emit::cpp::case_of(cp_p0, p_p1) {
            Some(ty_p2) => Text::from(format!("{}({}{{}})", &crate::emit::cpp::type_path(&ty_p2), &crate::emit::cpp::type_path(p_p1))),
            None => match crate::emit::cpp::type_of(cp_p0, p_p1) {
                Some(info_p3) => if &info_p3.kind == &Text::lit("unit") {
                    Text::from(format!("{}{{}}", &crate::emit::cpp::type_path(p_p1)))
                } else {
                    crate::emit::cpp::type_path(p_p1)
                },
                None => crate::emit::cpp::type_path(p_p1),
            },
        }
    }
}

/// ```prism
/// IsNodeMethod: fn Cp, Text -> Bool
/// ```
pub fn is_node_method(cp_p0: &crate::emit::cpp::Cp, p_p1: &Text) -> bool {
    let named_p2 = match get(&cp_p0.methods, &crate::emit::cpp::last_segment(p_p1)) {
        Some(_) => true,
        None => false,
    };
    named_p2 && is_node_type(cp_p0, &crate::emit::cpp::parent_path(p_p1))
}

/// ```prism
/// IsNodeType: fn Cp, Text -> Bool
/// ```
pub fn is_node_type(cp_p0: &crate::emit::cpp::Cp, p_p1: &Text) -> bool {
    match crate::emit::cpp::type_of(cp_p0, p_p1) {
        Some(info_p2) => &info_p2.kind == &Text::lit("node"),
        None => false,
    }
}

/// ```prism
/// CppField: unbounded fn Cp, Ex, Text -> Text
/// ```
pub fn cpp_field(cp_p0: &crate::emit::cpp::Cp, ex1: &crate::lower::model::Ex, f_p1: &Text) -> Text {
    match ex1 {
        crate::lower::model::Ex::XSelf => Text::from(format!("this->{}", &crate::emit::cpp::field_id(f_p1))),
        r_p3 => {
            let name_p5 = if is_digits(f_p1) {
                Text::from(format!("a{}", f_p1))
            } else {
                crate::emit::cpp::field_id(f_p1)
            };
            match pointer(cp_p0, r_p3) {
                Some(b_p6) => Text::from(format!("{}{}{}", &cpp_tight_place(cp_p0, r_p3), &(if b_p6 { Text::lit("->") } else { Text::lit(".") }), &name_p5)),
                None => match get(&cp_p0.members, f_p1) {
                    Some(_) => Text::from(format!("{}->{}", &cpp_tight_place(cp_p0, r_p3), &name_p5)),
                    None => Text::from(format!("{}.{}", &as_value(cp_p0, r_p3), &name_p5)),
                },
            }
        },
    }
}

/// The step machine of `CppField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppField: unbounded fn Cp, Ex, Text -> Text
/// ```
pub struct CppField {
    pub cp_p0: crate::emit::cpp::Cp,
    pub ex1: crate::lower::model::Ex,
    pub f_p1: Text,
}

impl prism_rtl::Job<Text> for CppField {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let ex1 = &self.ex1;
        let f_p1 = &self.f_p1;
        match ex1 {
            crate::lower::model::Ex::XSelf => prism_rtl::Turn::Finished(Text::from(format!("this->{}", &crate::emit::cpp::field_id(f_p1)))),
            r_p3 => {
                let name_p5 = if is_digits(f_p1) {
                    Text::from(format!("a{}", f_p1))
                } else {
                    crate::emit::cpp::field_id(f_p1)
                };
                match pointer(cp_p0, r_p3) {
                    Some(b_p6) => {
                        let cp_p0 = cp_p0.clone();
                        let r_p3 = r_p3.clone();
                        call_then(start_cpp_tight_place(cp_p0.clone(), r_p3.clone()), move |cpp_tight_place_10150: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}{}", &cpp_tight_place_10150, &(if b_p6 { Text::lit("->") } else { Text::lit(".") }), &name_p5))))
                    },
                    None => match get(&cp_p0.members, f_p1) {
                        Some(_) => {
                            let cp_p0 = cp_p0.clone();
                            let r_p3 = r_p3.clone();
                            call_then(start_cpp_tight_place(cp_p0.clone(), r_p3.clone()), move |cpp_tight_place_10258: Text| prism_rtl::Turn::Finished(Text::from(format!("{}->{}", &cpp_tight_place_10258, &name_p5))))
                        },
                        None => {
                            let cp_p0 = cp_p0.clone();
                            let r_p3 = r_p3.clone();
                            call_then(start_as_value(cp_p0.clone(), r_p3.clone()), move |as_value_10307: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.{}", &as_value_10307, &name_p5))))
                        },
                    },
                }
            },
        }
    }
}

/// `Start CppField, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_field(cp_p0: crate::emit::cpp::Cp, ex1: crate::lower::model::Ex, f_p1: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppField { cp_p0, ex1, f_p1 })
}

/// ```prism
/// AsValue: unbounded fn Cp, Ex -> Text
/// ```
pub fn as_value(cp_p0: &crate::emit::cpp::Cp, r_p1: &crate::lower::model::Ex) -> Text {
    match pointer(cp_p0, r_p1) {
        Some(false) => cpp_tight_place(cp_p0, r_p1),
        _ => Text::from(format!("prism_rtl::deref({})", &cpp_place(cp_p0, r_p1))),
    }
}

/// The step machine of `AsValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AsValue: unbounded fn Cp, Ex -> Text
/// ```
pub struct AsValue {
    pub cp_p0: crate::emit::cpp::Cp,
    pub r_p1: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for AsValue {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let r_p1 = &self.r_p1;
        match pointer(cp_p0, r_p1) {
            Some(false) => prism_rtl::Turn::More(Rc::new(CppTightPlace { cp_p0: cp_p0.clone(), x_p1: r_p1.clone() })),
            _ => {
                let cp_p0 = cp_p0.clone();
                let r_p1 = r_p1.clone();
                call_then(start_cpp_place(cp_p0.clone(), r_p1.clone()), move |cpp_place_10590: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::deref({})", &cpp_place_10590))))
            },
        }
    }
}

/// `Start AsValue, x`: what the function value is when passed to `@Run`.
pub fn start_as_value(cp_p0: crate::emit::cpp::Cp, r_p1: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(AsValue { cp_p0, r_p1 })
}

/// ```prism
/// ?ExTy: fn Cp, Ex -> ?OutTy
/// ```
pub fn ex_ty(cp_p0: &crate::emit::cpp::Cp, x_p1: &crate::lower::model::Ex) -> Option<crate::lower::model::OutTy> {
    'm10827: {
        if let crate::lower::model::Ex::XVar(n_p2) = x_p1 {
            break 'm10827 get(&cp_p0.local_types, n_p2);
        }
        if let crate::lower::model::Ex::XField(m10827_1_0, f_p3) = x_p1 && let crate::lower::model::Ex::XSelf = &**m10827_1_0 {
            break 'm10827 get(&cp_p0.fields, f_p3);
        }
        if let crate::lower::model::Ex::XField(m10827_2_0, f_p4) = x_p1 && let crate::lower::model::Ex::XVar(m10827_2_0_r_0) = &**m10827_2_0 && (m10827_2_0_r_0 == &Text::lit("node")) {
            break 'm10827 get(&cp_p0.fields, f_p4);
        }
        if let crate::lower::model::Ex::XRef(y_p5) = x_p1 {
            break 'm10827 match ex_ty(cp_p0, &**y_p5) {
                Some(t_p6) => Some(crate::lower::model::OutTy::OutRef(Rc::new(t_p6))),
                None => None,
            };
        }
        if let crate::lower::model::Ex::XDeref(y_p7) = x_p1 {
            break 'm10827 match ex_ty(cp_p0, &**y_p7) {
                Some(crate::lower::model::OutTy::OutRef(t_p8)) => Some((*t_p8).clone()),
                Some(crate::lower::model::OutTy::OutRc(t_p9)) => Some((*t_p9).clone()),
                _ => None,
            };
        }
        None
    }
}

/// ```prism
/// IsDigits: fn Text -> Bool
/// ```
pub fn is_digits(t_p0: &Text) -> bool {
    (t_p0 != &Text::lit("")) && crate::syntax::lexer::chars::fold_chars(t_p0, &true, &(Rc::new(move |(p0, p1): (bool, Text)| once_job(move || {
        let ok_p1 = p0;
        let c_p2 = p1;
        prism_rtl::Turn::Finished(ok_p1 && crate::syntax::lexer::chars::contains(&Text::lit("0123456789"), &c_p2))
    })) as Rc<dyn Fn((bool, Text)) -> Rc<dyn prism_rtl::Job<bool>>>))
}

/// ```prism
/// CppCtor: unbounded fn Cp, Text, [Ex] -> Text
/// ```
pub fn cpp_ctor(cp_p0: &crate::emit::cpp::Cp, p_p1: &Text, args_p2: &Array<crate::lower::model::Ex>) -> Text {
    match p_p1 {
        m11459_0 if (m11459_0 == &Text::lit("Some")) => Text::from(format!("std::optional({})", &cpp_args(cp_p0, args_p2))),
        m11459_1 if (m11459_1 == &Text::lit("Ok")) => if args_p2 == &Array::from(vec![crate::lower::model::Ex::XUnit]) {
            Text::lit("prism_rtl::ok()")
        } else {
            cpp_args(cp_p0, args_p2)
        },
        m11459_2 if (m11459_2 == &Text::lit("Err")) => Text::from(format!("unexpected({})", &cpp_args(cp_p0, args_p2))),
        m11459_3 if (m11459_3 == &Text::lit("prism_rtl::Turn::More")) => Text::from(format!("prism_rtl::more({})", &cpp_args(cp_p0, args_p2))),
        m11459_4 if (m11459_4 == &Text::lit("prism_rtl::Turn::Finished")) => Text::from(format!("prism_rtl::finished({})", &cpp_args(cp_p0, args_p2))),
        m11459_5 if (m11459_5 == &Text::lit("Outcome::Fired")) => Text::from(format!("Outcome::fired({})", &cpp_args(cp_p0, args_p2))),
        m11459_6 if (m11459_6 == &Text::lit("Outcome::Value")) => Text::from(format!("Outcome::value({})", &cpp_args(cp_p0, args_p2))),
        m11459_7 if (m11459_7 == &Text::lit("Segment::Pos")) => Text::from(format!("Segment::pos({})", &cpp_args(cp_p0, args_p2))),
        m11459_8 if (m11459_8 == &Text::lit("Segment::Gen")) => Text::from(format!("Segment::gen({})", &cpp_args(cp_p0, args_p2))),
        m11459_9 if (m11459_9 == &Text::lit("Segment::Key")) => Text::from(format!("Segment::key({})", &cpp_args(cp_p0, args_p2))),
        _ => match crate::emit::cpp::case_of(cp_p0, p_p1) {
            Some(ty_p3) => Text::from(format!("{}({}{{{}}})", &crate::emit::cpp::type_path(&ty_p3), &crate::emit::cpp::type_path(p_p1), &cpp_args(cp_p0, args_p2))),
            None => Text::from(format!("{}{{{}}}", &crate::emit::cpp::type_path(p_p1), &cpp_args(cp_p0, args_p2))),
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CppCtor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppCtor: unbounded fn Cp, Text, [Ex] -> Text
/// ```
pub struct CppCtor {
    pub cp_p0: crate::emit::cpp::Cp,
    pub p_p1: Text,
    pub args_p2: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for CppCtor {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let p_p1 = &self.p_p1;
        let args_p2 = &self.args_p2;
        match p_p1 {
            m11459_0 if (m11459_0 == &Text::lit("Some")) => {
                let args_p2 = args_p2.clone();
                let cp_p0 = cp_p0.clone();
                call_then(start_cpp_args(cp_p0.clone(), args_p2.clone()), move |cpp_args_11496: Text| prism_rtl::Turn::Finished(Text::from(format!("std::optional({})", &cpp_args_11496))))
            },
            m11459_1 if (m11459_1 == &Text::lit("Ok")) => if args_p2 == &Array::from(vec![crate::lower::model::Ex::XUnit]) {
                prism_rtl::Turn::Finished(Text::lit("prism_rtl::ok()"))
            } else {
                prism_rtl::Turn::More(Rc::new(CppArgs { cp_p0: cp_p0.clone(), xs_p1: args_p2.clone() }))
            },
            m11459_2 if (m11459_2 == &Text::lit("Err")) => {
                let args_p2 = args_p2.clone();
                let cp_p0 = cp_p0.clone();
                call_then(start_cpp_args(cp_p0.clone(), args_p2.clone()), move |cpp_args_11613: Text| prism_rtl::Turn::Finished(Text::from(format!("unexpected({})", &cpp_args_11613))))
            },
            m11459_3 if (m11459_3 == &Text::lit("prism_rtl::Turn::More")) => {
                let args_p2 = args_p2.clone();
                let cp_p0 = cp_p0.clone();
                call_then(start_cpp_args(cp_p0.clone(), args_p2.clone()), move |cpp_args_11680: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::more({})", &cpp_args_11680))))
            },
            m11459_4 if (m11459_4 == &Text::lit("prism_rtl::Turn::Finished")) => {
                let args_p2 = args_p2.clone();
                let cp_p0 = cp_p0.clone();
                call_then(start_cpp_args(cp_p0.clone(), args_p2.clone()), move |cpp_args_11755: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::finished({})", &cpp_args_11755))))
            },
            m11459_5 if (m11459_5 == &Text::lit("Outcome::Fired")) => {
                let args_p2 = args_p2.clone();
                let cp_p0 = cp_p0.clone();
                call_then(start_cpp_args(cp_p0.clone(), args_p2.clone()), move |cpp_args_11814: Text| prism_rtl::Turn::Finished(Text::from(format!("Outcome::fired({})", &cpp_args_11814))))
            },
            m11459_6 if (m11459_6 == &Text::lit("Outcome::Value")) => {
                let args_p2 = args_p2.clone();
                let cp_p0 = cp_p0.clone();
                call_then(start_cpp_args(cp_p0.clone(), args_p2.clone()), move |cpp_args_11873: Text| prism_rtl::Turn::Finished(Text::from(format!("Outcome::value({})", &cpp_args_11873))))
            },
            m11459_7 if (m11459_7 == &Text::lit("Segment::Pos")) => {
                let args_p2 = args_p2.clone();
                let cp_p0 = cp_p0.clone();
                call_then(start_cpp_args(cp_p0.clone(), args_p2.clone()), move |cpp_args_11928: Text| prism_rtl::Turn::Finished(Text::from(format!("Segment::pos({})", &cpp_args_11928))))
            },
            m11459_8 if (m11459_8 == &Text::lit("Segment::Gen")) => {
                let args_p2 = args_p2.clone();
                let cp_p0 = cp_p0.clone();
                call_then(start_cpp_args(cp_p0.clone(), args_p2.clone()), move |cpp_args_11983: Text| prism_rtl::Turn::Finished(Text::from(format!("Segment::gen({})", &cpp_args_11983))))
            },
            m11459_9 if (m11459_9 == &Text::lit("Segment::Key")) => {
                let args_p2 = args_p2.clone();
                let cp_p0 = cp_p0.clone();
                call_then(start_cpp_args(cp_p0.clone(), args_p2.clone()), move |cpp_args_12038: Text| prism_rtl::Turn::Finished(Text::from(format!("Segment::key({})", &cpp_args_12038))))
            },
            _ => match crate::emit::cpp::case_of(cp_p0, p_p1) {
                Some(ty_p3) => {
                    let args_p2 = args_p2.clone();
                    let cp_p0 = cp_p0.clone();
                    let p_p1 = p_p1.clone();
                    call_then(start_cpp_args(cp_p0.clone(), args_p2.clone()), move |cpp_args_12138: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({}{{{}}})", &crate::emit::cpp::type_path(&ty_p3), &crate::emit::cpp::type_path(&p_p1), &cpp_args_12138))))
                },
                None => {
                    let args_p2 = args_p2.clone();
                    let cp_p0 = cp_p0.clone();
                    let p_p1 = p_p1.clone();
                    call_then(start_cpp_args(cp_p0.clone(), args_p2.clone()), move |cpp_args_12189: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{{{}}}", &crate::emit::cpp::type_path(&p_p1), &cpp_args_12189))))
                },
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start CppCtor, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_ctor(cp_p0: crate::emit::cpp::Cp, p_p1: Text, args_p2: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppCtor { cp_p0, p_p1, args_p2 })
}

/// ```prism
/// CppRecord: unbounded fn Cp, Text, [((Text, Ex))] -> Text
/// ```
pub fn cpp_record(cp_p0: &crate::emit::cpp::Cp, p_p1: &Text, fs_p2: &Array<(Text, crate::lower::model::Ex)>) -> Text {
    let ordered_p3 = match crate::emit::cpp::type_of(cp_p0, p_p1) {
        Some(info_p7) => each(&info_p7.fields, &(|f_p8: &Text| or(&fold(fs_p2, &None, &(|found_o9: &Option<crate::lower::model::Ex>, (g_pa, v_pb): &(Text, crate::lower::model::Ex)| if g_pa == f_p8 { Some(v_pb.clone()) } else { found_o9.clone() })), &crate::lower::model::Ex::XUnit))),
        None => each(fs_p2, &(|(_, v_pc): &(Text, crate::lower::model::Ex)| v_pc.clone())),
    };
    let names_p4 = match crate::emit::cpp::type_of(cp_p0, p_p1) {
        Some(info_pd) => info_pd.fields.clone(),
        None => each(fs_p2, &(|(g_pe, _): &(Text, crate::lower::model::Ex)| g_pe.clone())),
    };
    let kind_p5 = match crate::emit::cpp::type_of(cp_p0, p_p1) {
        Some(info_pf) => info_pf.kind.clone(),
        None => Text::lit(""),
    };
    let values_p6 = cpp_arg_list(cp_p0, &ordered_p3);
    if &kind_p5 == &Text::lit("job") {
        Text::from(format!("{}({})", &crate::emit::cpp::type_path(p_p1), &crate::syntax::lexer::chars::join(&values_p6, &Text::lit(", "))))
    } else {
        Text::from(format!("{}{{{}}}", &crate::emit::cpp::type_path(p_p1), &crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&len(&names_p4)), &(|i_pg: &Nat| Text::from(format!(".{} = {}", &crate::emit::cpp::field_id(&or(&index(&names_p4, i_pg), &Text::lit(""))), &or(&index(&values_p6, i_pg), &Text::lit("")))))), &Text::lit(", "))))
    }
}

/// The step machine of `CppRecord`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppRecord: unbounded fn Cp, Text, [((Text, Ex))] -> Text
/// ```
pub struct CppRecord {
    pub cp_p0: crate::emit::cpp::Cp,
    pub p_p1: Text,
    pub fs_p2: Array<(Text, crate::lower::model::Ex)>,
}

impl prism_rtl::Job<Text> for CppRecord {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let p_p1 = &self.p_p1;
        let fs_p2 = &self.fs_p2;
        let ordered_p3 = match crate::emit::cpp::type_of(cp_p0, p_p1) {
            Some(info_p7) => each(&info_p7.fields, &(|f_p8: &Text| or(&fold(fs_p2, &None, &(|found_o9: &Option<crate::lower::model::Ex>, (g_pa, v_pb): &(Text, crate::lower::model::Ex)| if g_pa == f_p8 { Some(v_pb.clone()) } else { found_o9.clone() })), &crate::lower::model::Ex::XUnit))),
            None => each(fs_p2, &(|(_, v_pc): &(Text, crate::lower::model::Ex)| v_pc.clone())),
        };
        let names_p4 = match crate::emit::cpp::type_of(cp_p0, p_p1) {
            Some(info_pd) => info_pd.fields.clone(),
            None => each(fs_p2, &(|(g_pe, _): &(Text, crate::lower::model::Ex)| g_pe.clone())),
        };
        let kind_p5 = match crate::emit::cpp::type_of(cp_p0, p_p1) {
            Some(info_pf) => info_pf.kind.clone(),
            None => Text::lit(""),
        };
        let cp_p0 = cp_p0.clone();
        let p_p1 = p_p1.clone();
        call_then(start_cpp_arg_list(cp_p0.clone(), ordered_p3.clone()), move |cpp_arg_list_12788: Array<Text>| {
            let values_p6 = cpp_arg_list_12788;
            if &kind_p5 == &Text::lit("job") {
                prism_rtl::Turn::Finished(Text::from(format!("{}({})", &crate::emit::cpp::type_path(&p_p1), &crate::syntax::lexer::chars::join(&values_p6, &Text::lit(", ")))))
            } else {
                prism_rtl::Turn::Finished(Text::from(format!("{}{{{}}}", &crate::emit::cpp::type_path(&p_p1), &crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&len(&names_p4)), &(|i_pg: &Nat| Text::from(format!(".{} = {}", &crate::emit::cpp::field_id(&or(&index(&names_p4, i_pg), &Text::lit(""))), &or(&index(&values_p6, i_pg), &Text::lit("")))))), &Text::lit(", ")))))
            }
        })
    }
}

/// `Start CppRecord, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_record(cp_p0: crate::emit::cpp::Cp, p_p1: Text, fs_p2: Array<(Text, crate::lower::model::Ex)>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppRecord { cp_p0, p_p1, fs_p2 })
}

/// ```prism
/// CppCall: unbounded fn Cp, Text, [Ex] -> Text
/// ```
pub fn cpp_call(cp_p0: &crate::emit::cpp::Cp, f_p1: &Text, args_p2: &Array<crate::lower::model::Ex>) -> Text {
    let a_p3 = cpp_args(cp_p0, args_p2);
    match f_p1 {
        m13233_0 if (m13233_0 == &Text::lit("Rc::new")) => if &a_p3 == &Text::lit("{}") {
            Text::lit("prism_rtl::make_new()")
        } else {
            Text::from(format!("prism_rtl::rc({})", &a_p3))
        },
        m13233_1 if (m13233_1 == &Text::lit("is_some")) => Text::from(format!("prism_rtl::is_some({})", &a_p3)),
        m13233_2 if (m13233_2 == &Text::lit("is_none")) => Text::from(format!("prism_rtl::is_none({})", &a_p3)),
        m13233_3 if (m13233_3 == &Text::lit("RefCell::new")) => a_p3.clone(),
        m13233_4 if (m13233_4 == &Text::lit("Cell::new")) => a_p3.clone(),
        m13233_5 if (m13233_5 == &Text::lit("Hold::new")) => Text::from(format!("{{{}}}", &a_p3)),
        m13233_6 if (m13233_6 == &Text::lit("Snapshot::new")) => Text::from(format!("snapshot({})", &a_p3)),
        m13233_7 if (m13233_7 == &Text::lit("Path::root")) => Text::lit("Path::root()"),
        m13233_8 if (m13233_8 == &Text::lit("Fault::answer")) => Text::from(format!("Fault::answer({})", &a_p3)),
        m13233_9 if (m13233_9 == &Text::lit("Fault::too_deep")) => Text::from(format!("Fault::too_deep({})", &a_p3)),
        m13233_10 if (m13233_10 == &Text::lit("Error::new")) => Text::from(format!("Error({})", &a_p3)),
        m13233_11 if (m13233_11 == &Text::lit("Text::from")) => Text::from(format!("Text({})", &a_p3)),
        m13233_12 if (m13233_12 == &Text::lit("String::new")) => Text::lit("std::string()"),
        m13233_13 if (m13233_13 == &Text::lit("Array::from")) => Text::from(format!("Array({})", &a_p3)),
        m13233_14 if (m13233_14 == &Text::lit("prism_rtl::Dynamic::of")) => Text::from(format!("dynamic_of({})", &a_p3)),
        m13233_15 if (m13233_15 == &Text::lit("Dynamic::of")) => Text::from(format!("dynamic_of({})", &a_p3)),
        m13233_16 if (m13233_16 == &Text::lit("prism_rtl::Event::of")) => Text::from(format!("event_of({})", &a_p3)),
        m13233_17 if (m13233_17 == &Text::lit("prism_rtl::Host::new")) => Text::from(format!("host_new({})", &a_p3)),
        m13233_18 if (m13233_18 == &Text::lit("prism_rtl::Entry::new")) => Text::from(format!("entry_new({})", &a_p3)),
        m13233_19 if (m13233_19 == &Text::lit("prism_rtl::forward_on_none")) => Text::from(format!("prism_rtl::forward_on_none<crate::Elem, crate::Answer>({})", &a_p3)),
        m13233_20 if (m13233_20 == &Text::lit("Event::never")) => Text::lit("never_event()"),
        _ => if is_fresh(f_p1) {
            Text::lit("{}")
        } else {
            Text::from(format!("{}({})", &free_call_path(cp_p0, f_p1), &a_p3))
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CppCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppCall: unbounded fn Cp, Text, [Ex] -> Text
/// ```
pub struct CppCall {
    pub cp_p0: crate::emit::cpp::Cp,
    pub f_p1: Text,
    pub args_p2: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for CppCall {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let f_p1 = &self.f_p1;
        let args_p2 = &self.args_p2;
        let args_p2 = args_p2.clone();
        let cp_p0 = cp_p0.clone();
        let f_p1 = f_p1.clone();
        call_then(start_cpp_args(cp_p0.clone(), args_p2.clone()), move |cpp_args_13212: Text| {
            let a_p3 = cpp_args_13212;
            match &f_p1 {
                m13233_0 if (m13233_0 == &Text::lit("Rc::new")) => if &a_p3 == &Text::lit("{}") {
                    prism_rtl::Turn::Finished(Text::lit("prism_rtl::make_new()"))
                } else {
                    prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::rc({})", &a_p3)))
                },
                m13233_1 if (m13233_1 == &Text::lit("is_some")) => prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::is_some({})", &a_p3))),
                m13233_2 if (m13233_2 == &Text::lit("is_none")) => prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::is_none({})", &a_p3))),
                m13233_3 if (m13233_3 == &Text::lit("RefCell::new")) => prism_rtl::Turn::Finished(a_p3.clone()),
                m13233_4 if (m13233_4 == &Text::lit("Cell::new")) => prism_rtl::Turn::Finished(a_p3.clone()),
                m13233_5 if (m13233_5 == &Text::lit("Hold::new")) => prism_rtl::Turn::Finished(Text::from(format!("{{{}}}", &a_p3))),
                m13233_6 if (m13233_6 == &Text::lit("Snapshot::new")) => prism_rtl::Turn::Finished(Text::from(format!("snapshot({})", &a_p3))),
                m13233_7 if (m13233_7 == &Text::lit("Path::root")) => prism_rtl::Turn::Finished(Text::lit("Path::root()")),
                m13233_8 if (m13233_8 == &Text::lit("Fault::answer")) => prism_rtl::Turn::Finished(Text::from(format!("Fault::answer({})", &a_p3))),
                m13233_9 if (m13233_9 == &Text::lit("Fault::too_deep")) => prism_rtl::Turn::Finished(Text::from(format!("Fault::too_deep({})", &a_p3))),
                m13233_10 if (m13233_10 == &Text::lit("Error::new")) => prism_rtl::Turn::Finished(Text::from(format!("Error({})", &a_p3))),
                m13233_11 if (m13233_11 == &Text::lit("Text::from")) => prism_rtl::Turn::Finished(Text::from(format!("Text({})", &a_p3))),
                m13233_12 if (m13233_12 == &Text::lit("String::new")) => prism_rtl::Turn::Finished(Text::lit("std::string()")),
                m13233_13 if (m13233_13 == &Text::lit("Array::from")) => prism_rtl::Turn::Finished(Text::from(format!("Array({})", &a_p3))),
                m13233_14 if (m13233_14 == &Text::lit("prism_rtl::Dynamic::of")) => prism_rtl::Turn::Finished(Text::from(format!("dynamic_of({})", &a_p3))),
                m13233_15 if (m13233_15 == &Text::lit("Dynamic::of")) => prism_rtl::Turn::Finished(Text::from(format!("dynamic_of({})", &a_p3))),
                m13233_16 if (m13233_16 == &Text::lit("prism_rtl::Event::of")) => prism_rtl::Turn::Finished(Text::from(format!("event_of({})", &a_p3))),
                m13233_17 if (m13233_17 == &Text::lit("prism_rtl::Host::new")) => prism_rtl::Turn::Finished(Text::from(format!("host_new({})", &a_p3))),
                m13233_18 if (m13233_18 == &Text::lit("prism_rtl::Entry::new")) => prism_rtl::Turn::Finished(Text::from(format!("entry_new({})", &a_p3))),
                m13233_19 if (m13233_19 == &Text::lit("prism_rtl::forward_on_none")) => prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::forward_on_none<crate::Elem, crate::Answer>({})", &a_p3))),
                m13233_20 if (m13233_20 == &Text::lit("Event::never")) => prism_rtl::Turn::Finished(Text::lit("never_event()")),
                _ => if is_fresh(&f_p1) {
                    prism_rtl::Turn::Finished(Text::lit("{}"))
                } else {
                    prism_rtl::Turn::Finished(Text::from(format!("{}({})", &free_call_path(&cp_p0, &f_p1), &a_p3)))
                },
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start CppCall, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_call(cp_p0: crate::emit::cpp::Cp, f_p1: Text, args_p2: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppCall { cp_p0, f_p1, args_p2 })
}

/// ```prism
/// FreeCallPath: fn Cp, Text -> Text
/// ```
pub fn free_call_path(cp_p0: &crate::emit::cpp::Cp, f_p1: &Text) -> Text {
    let p_p2 = call_path(f_p1);
    let hidden_p3 = match get(&cp_p0.members, f_p1) {
        Some(_) => true,
        None => crate::emit::cpp::in_list(&std_names(), &p_p2) || crate::emit::cpp::in_list(&cp_p0.mods, &p_p2),
    };
    if crate::syntax::lexer::chars::contains(&p_p2, &Text::lit(":")) {
        p_p2.clone()
    } else {
        if hidden_p3 { qualified_call(cp_p0, f_p1, &p_p2) } else { p_p2.clone() }
    }
}

/// ```prism
/// QualifiedCall: fn Cp, Text, Text -> Text
/// ```
pub fn qualified_call(cp_p0: &crate::emit::cpp::Cp, f_p1: &Text, p_p2: &Text) -> Text {
    match get(&cp_p0.fns, &Text::from(format!("{}::{}", &cp_p0.home, f_p1))) {
        Some(_) => Text::from(format!("crate::{}::{}", &cp_p0.home, p_p2)),
        None => Text::from(format!("crate::prelude::{}", p_p2)),
    }
}

/// ```prism
/// let stdNames
/// ```
pub fn std_names() -> Array<Text> {
    Array::from(vec![Text::lit("apply"), Text::lit("begin"), Text::lit("end"), Text::lit("size"), Text::lit("empty"), Text::lit("data"), Text::lit("get"), Text::lit("swap"), Text::lit("move"), Text::lit("forward"), Text::lit("find"), Text::lit("count"), Text::lit("copy"), Text::lit("fill"), Text::lit("sort"), Text::lit("min"), Text::lit("max"), Text::lit("visit"), Text::lit("invoke"), Text::lit("merge"), Text::lit("remove"), Text::lit("replace"), Text::lit("reverse"), Text::lit("unique"), Text::lit("transform"), Text::lit("accumulate"), Text::lit("distance"), Text::lit("next"), Text::lit("prev"), Text::lit("exchange"), Text::lit("tie"), Text::lit("to_string"), Text::lit("clamp"), Text::lit("partition"), Text::lit("equal"), Text::lit("mismatch"), Text::lit("erase"), Text::lit("search"), Text::lit("rotate")])
}

/// ```prism
/// IsFresh: fn Text -> Bool
/// ```
pub fn is_fresh(f_p0: &Text) -> bool {
    crate::emit::cpp::in_list(&Array::from(vec![Text::lit("Stamped::new"), Text::lit("Cache::new"), Text::lit("Port::new"), Text::lit("Map::new"), Text::lit("Array::new"), Text::lit("Vec::new"), Text::lit("Default::default"), Text::lit("Wakes::default"), Text::lit("Defer::new"), Text::lit("prism_rtl::HostDoc::new"), Text::lit("prism_rtl::Watch::new"), Text::lit("prism_rtl::PerKey::new")]), f_p0)
}

/// ```prism
/// CallPath: fn Text -> Text
/// ```
pub fn call_path(f_p0: &Text) -> Text {
    let last_p1 = crate::emit::cpp::last_segment(f_p0);
    let owner_p2 = crate::emit::cpp::last_segment(&crate::emit::cpp::parent_path(f_p0));
    let is_type_p3 = (&crate::emit::cpp::parent_path(f_p0) != &Text::lit("")) && crate::syntax::lexer::chars::contains(&Text::lit("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), &crate::syntax::lexer::chars::head(&owner_p2));
    if (&last_p1 == &Text::lit("build")) && is_type_p3 {
        Text::from(format!("{}::make", &crate::emit::cpp::type_path(&crate::emit::cpp::parent_path(f_p0))))
    } else {
        if &last_p1 == &Text::lit("new") {
            crate::emit::cpp::type_path(&crate::emit::cpp::parent_path(f_p0))
        } else {
            crate::emit::cpp::cpp_path_id(&crate::emit::cpp::type_path(f_p0))
        }
    }
}

/// ```prism
/// CppMethod: unbounded fn Cp, Ex, Text, [Ex] -> Text
/// ```
pub fn cpp_method(cp_p0: &crate::emit::cpp::Cp, r_p1: &crate::lower::model::Ex, m_p2: &Text, args_p3: &Array<crate::lower::model::Ex>) -> Text {
    let recv_p4 = if r_p1 == &crate::lower::model::Ex::XSelf {
        Text::lit("this")
    } else {
        cpp_tight_place(cp_p0, r_p1)
    };
    let a_p5 = cpp_args(cp_p0, args_p3);
    let n_p6 = len(args_p3);
    let sep_p7 = if &n_p6 == &Nat::from(0u32) { Text::lit("") } else { Text::lit(", ") };
    match method_form(m_p2, &n_p6) {
        m16569_0 if (&m16569_0 == &Text::lit("id")) => recv_p4.clone(),
        m16569_1 if (&m16569_1 == &Text::lit("deref")) => match pointer(cp_p0, r_p1) {
            Some(b_p8) => if b_p8 { Text::from(format!("(*{})", &recv_p4)) } else { recv_p4.clone() },
            None => recv_p4.clone(),
        },
        m16569_2 if (&m16569_2 == &Text::lit("assign")) => Text::from(format!("{} = {}", &recv_p4, &a_p5)),
        m16569_3 if (&m16569_3 == &Text::lit("take")) => Text::from(format!("std::exchange({}, {{}})", &recv_p4)),
        m16569_4 if (&m16569_4 == &Text::lit("free")) => Text::from(format!("{}({}{}{})", &free_name(m_p2), &recv_p4, &sep_p7, &a_p5)),
        m16569_5 if (&m16569_5 == &Text::lit("arrow")) => {
            let through_p9 = match pointer(cp_p0, r_p1) {
                Some(b_pa) => if b_pa { Text::lit("->") } else { Text::lit(".") },
                None => Text::lit("->"),
            };
            Text::from(format!("{}{}{}({})", &recv_p4, &through_p9, &member_name(m_p2), &a_p5))
        },
        m16569_6 if (&m16569_6 == &Text::lit("exchange")) => Text::from(format!("std::exchange({}, {})", &recv_p4, &a_p5)),
        _ => {
            let through_pb = match pointer(cp_p0, r_p1) {
                Some(b_pc) => if b_pc { Text::lit("->") } else { Text::lit(".") },
                None => match get(&cp_p0.members, m_p2) {
                    Some(_) => Text::lit("->"),
                    None => Text::lit("."),
                },
            };
            Text::from(format!("{}{}{}({})", &recv_p4, &through_pb, &node_method_name(cp_p0, m_p2), &a_p5))
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CppMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppMethod: unbounded fn Cp, Ex, Text, [Ex] -> Text
/// ```
pub struct CppMethod {
    pub cp_p0: crate::emit::cpp::Cp,
    pub r_p1: crate::lower::model::Ex,
    pub m_p2: Text,
    pub args_p3: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for CppMethod {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let r_p1 = &self.r_p1;
        let m_p2 = &self.m_p2;
        let args_p3 = &self.args_p3;
        let recv_p4 = if r_p1 == &crate::lower::model::Ex::XSelf {
            Text::lit("this")
        } else {
            cpp_tight_place(cp_p0, r_p1)
        };
        let args_p3 = args_p3.clone();
        let cp_p0 = cp_p0.clone();
        let m_p2 = m_p2.clone();
        let r_p1 = r_p1.clone();
        call_then(start_cpp_args(cp_p0.clone(), args_p3.clone()), move |cpp_args_16488: Text| {
            let a_p5 = cpp_args_16488;
            let n_p6 = len(&args_p3);
            let sep_p7 = if &n_p6 == &Nat::from(0u32) { Text::lit("") } else { Text::lit(", ") };
            match method_form(&m_p2, &n_p6) {
                m16569_0 if (&m16569_0 == &Text::lit("id")) => prism_rtl::Turn::Finished(recv_p4.clone()),
                m16569_1 if (&m16569_1 == &Text::lit("deref")) => match pointer(&cp_p0, &r_p1) {
                    Some(b_p8) => if b_p8 {
                        prism_rtl::Turn::Finished(Text::from(format!("(*{})", &recv_p4)))
                    } else {
                        prism_rtl::Turn::Finished(recv_p4.clone())
                    },
                    None => prism_rtl::Turn::Finished(recv_p4.clone()),
                },
                m16569_2 if (&m16569_2 == &Text::lit("assign")) => prism_rtl::Turn::Finished(Text::from(format!("{} = {}", &recv_p4, &a_p5))),
                m16569_3 if (&m16569_3 == &Text::lit("take")) => prism_rtl::Turn::Finished(Text::from(format!("std::exchange({}, {{}})", &recv_p4))),
                m16569_4 if (&m16569_4 == &Text::lit("free")) => prism_rtl::Turn::Finished(Text::from(format!("{}({}{}{})", &free_name(&m_p2), &recv_p4, &sep_p7, &a_p5))),
                m16569_5 if (&m16569_5 == &Text::lit("arrow")) => {
                    let through_p9 = match pointer(&cp_p0, &r_p1) {
                        Some(b_pa) => if b_pa { Text::lit("->") } else { Text::lit(".") },
                        None => Text::lit("->"),
                    };
                    prism_rtl::Turn::Finished(Text::from(format!("{}{}{}({})", &recv_p4, &through_p9, &member_name(&m_p2), &a_p5)))
                },
                m16569_6 if (&m16569_6 == &Text::lit("exchange")) => prism_rtl::Turn::Finished(Text::from(format!("std::exchange({}, {})", &recv_p4, &a_p5))),
                _ => {
                    let through_pb = match pointer(&cp_p0, &r_p1) {
                        Some(b_pc) => if b_pc { Text::lit("->") } else { Text::lit(".") },
                        None => match get(&cp_p0.members, &m_p2) {
                            Some(_) => Text::lit("->"),
                            None => Text::lit("."),
                        },
                    };
                    prism_rtl::Turn::Finished(Text::from(format!("{}{}{}({})", &recv_p4, &through_pb, &node_method_name(&cp_p0, &m_p2), &a_p5)))
                },
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start CppMethod, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_method(cp_p0: crate::emit::cpp::Cp, r_p1: crate::lower::model::Ex, m_p2: Text, args_p3: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppMethod { cp_p0, r_p1, m_p2, args_p3 })
}

/// ```prism
/// NodeMethodName: fn Cp, Text -> Text
/// ```
pub fn node_method_name(cp_p0: &crate::emit::cpp::Cp, m_p1: &Text) -> Text {
    match (get(&cp_p0.methods, m_p1), get(&cp_p0.field_names, m_p1)) {
        (Some(_), Some(_)) => Text::from(format!("{}_", &crate::emit::cpp::cpp_id(m_p1))),
        _ => member_name(m_p1),
    }
}

/// ```prism
/// ?Pointer: fn Cp, Ex -> ?Bool
/// ```
pub fn pointer(cp_p0: &crate::emit::cpp::Cp, r_p1: &crate::lower::model::Ex) -> Option<bool> {
    'm18085: {
        if let crate::lower::model::Ex::XSelf = r_p1 {
            break 'm18085 Some(true);
        }
        if let crate::lower::model::Ex::XCx = r_p1 {
            break 'm18085 Some(false);
        }
        if let crate::lower::model::Ex::XVar(m18085_2_0) = r_p1 && (m18085_2_0 == &Text::lit("path")) {
            break 'm18085 Some(false);
        }
        if let crate::lower::model::Ex::XField(_, m18085_3_1) = r_p1 && (m18085_3_1 == &Text::lit("path")) {
            break 'm18085 Some(false);
        }
        if let crate::lower::model::Ex::XCall(m18085_4_0, _) = r_p1 && (m18085_4_0 == &Text::lit("Path::root")) {
            break 'm18085 Some(false);
        }
        if let crate::lower::model::Ex::XMethod(y_p2, m_p3, _) = r_p1 && (((m_p3 == &Text::lit("at")) || (m_p3 == &Text::lit("child"))) || (m_p3 == &Text::lit("join"))) {
            break 'm18085 match pointer(cp_p0, &**y_p2) {
                Some(false) => Some(false),
                _ => None,
            };
        }
        if let crate::lower::model::Ex::XVar(n_p4) = r_p1 {
            break 'm18085 get(&cp_p0.pointers, n_p4);
        }
        if let crate::lower::model::Ex::XClone(y_p5) = r_p1 {
            break 'm18085 pointer(cp_p0, &**y_p5);
        }
        if let crate::lower::model::Ex::XRef(y_p6) = r_p1 {
            break 'm18085 pointer(cp_p0, &**y_p6);
        }
        if let crate::lower::model::Ex::XDeref(y_p7) = r_p1 {
            break 'm18085 match ex_ty(cp_p0, r_p1) {
                Some(t_p8) => Some(is_pointer_ty(cp_p0, &unref(&t_p8))),
                None => None,
            };
        }
        if let crate::lower::model::Ex::XField(m18085_10_0, f_p9) = r_p1 && let crate::lower::model::Ex::XSelf = &**m18085_10_0 {
            break 'm18085 match get(&cp_p0.fields, f_p9) {
                Some(t_pa) => Some(is_pointer_ty(cp_p0, &t_pa)),
                None => None,
            };
        }
        if let crate::lower::model::Ex::XField(m18085_11_0, f_pb) = r_p1 && let crate::lower::model::Ex::XVar(m18085_11_0_r_0) = &**m18085_11_0 && (m18085_11_0_r_0 == &Text::lit("node")) {
            break 'm18085 match get(&cp_p0.fields, f_pb) {
                Some(t_pc) => Some(is_pointer_ty(cp_p0, &t_pc)),
                None => None,
            };
        }
        None
    }
}

/// ```prism
/// IsPointerTy: fn Cp, OutTy -> Bool
/// ```
pub fn is_pointer_ty(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::OutTy) -> bool {
    match t_p1 {
        crate::lower::model::OutTy::OutNamed(m18929_0_0, _) if (m18929_0_0 == &Text::lit("prism_rtl::Rows")) => true,
        crate::lower::model::OutTy::OutPort(_) => false,
        crate::lower::model::OutTy::OutRc(_) => true,
        crate::lower::model::OutTy::OutObj(_) => true,
        crate::lower::model::OutTy::OutJob(_) => true,
        crate::lower::model::OutTy::OutShowAny => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// MethodForm: fn Text, Nat -> Text
/// ```
pub fn method_form(m_p0: &Text, n_p1: &Nat) -> Text {
    match (m_p0.clone(), n_p1.clone()) {
        (m19456_0_0, m19456_0_1) if (&m19456_0_0 == &Text::lit("borrow")) && (&m19456_0_1 == &Nat::from(0u32)) => Text::lit("deref"),
        (m19456_1_0, m19456_1_1) if (&m19456_1_0 == &Text::lit("borrow_mut")) && (&m19456_1_1 == &Nat::from(0u32)) => Text::lit("deref"),
        (m19456_2_0, m19456_2_1) if (&m19456_2_0 == &Text::lit("clone")) && (&m19456_2_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m19456_3_0, m19456_3_1) if (&m19456_3_0 == &Text::lit("iter")) && (&m19456_3_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m19456_4_0, m19456_4_1) if (&m19456_4_0 == &Text::lit("collect")) && (&m19456_4_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m19456_5_0, m19456_5_1) if (&m19456_5_0 == &Text::lit("unwrap_or_default")) && (&m19456_5_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19456_6_0, m19456_6_1) if (&m19456_6_0 == &Text::lit("for_each")) && (&m19456_6_1 == &Nat::from(1u32)) => Text::lit("free"),
        (m19456_7_0, m19456_7_1) if (&m19456_7_0 == &Text::lit("into_iter")) && (&m19456_7_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m19456_8_0, m19456_8_1) if (&m19456_8_0 == &Text::lit("as_ref")) && (&m19456_8_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m19456_9_0, m19456_9_1) if (&m19456_9_0 == &Text::lit("get")) && (&m19456_9_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m19456_10_0, m19456_10_1) if (&m19456_10_0 == &Text::lit("set")) && (&m19456_10_1 == &Nat::from(1u32)) => Text::lit("assign"),
        (m19456_11_0, m19456_11_1) if (&m19456_11_0 == &Text::lit("take")) && (&m19456_11_1 == &Nat::from(0u32)) => Text::lit("take"),
        (m19456_12_0, m19456_12_1) if (&m19456_12_0 == &Text::lit("replace")) && (&m19456_12_1 == &Nat::from(1u32)) => Text::lit("exchange"),
        (m19456_13_0, m19456_13_1) if (&m19456_13_0 == &Text::lit("values")) && (&m19456_13_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19456_14_0, m19456_14_1) if (&m19456_14_0 == &Text::lit("keys")) && (&m19456_14_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19456_15_0, m19456_15_1) if (&m19456_15_0 == &Text::lit("enumerate")) && (&m19456_15_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19456_16_0, m19456_16_1) if (&m19456_16_0 == &Text::lit("fire")) && (&m19456_16_1 == &Nat::from(2u32)) => Text::lit("arrow"),
        (m19456_17_0, m19456_17_1) if (&m19456_17_0 == &Text::lit("subscribe")) && (&m19456_17_1 == &Nat::from(1u32)) => Text::lit("arrow"),
        (m19456_18_0, m19456_18_1) if (&m19456_18_0 == &Text::lit("unsubscribe")) && (&m19456_18_1 == &Nat::from(1u32)) => Text::lit("arrow"),
        (m19456_19_0, m19456_19_1) if (&m19456_19_0 == &Text::lit("cycle")) && (&m19456_19_1 == &Nat::from(0u32)) => Text::lit("arrow"),
        (m19456_20_0, m19456_20_1) if (&m19456_20_0 == &Text::lit("upgrade")) && (&m19456_20_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19456_21_0, m19456_21_1) if (&m19456_21_0 == &Text::lit("expect")) && (&m19456_21_1 == &Nat::from(1u32)) => Text::lit("free"),
        (m19456_22_0, m19456_22_1) if (&m19456_22_0 == &Text::lit("to_pod")) && (&m19456_22_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19456_23_0, m19456_23_1) if (&m19456_23_0 == &Text::lit("cloned")) && (&m19456_23_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19456_24_0, m19456_24_1) if (&m19456_24_0 == &Text::lit("ok")) && (&m19456_24_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19456_25_0, m19456_25_1) if (&m19456_25_0 == &Text::lit("ok_or")) && (&m19456_25_1 == &Nat::from(1u32)) => Text::lit("free"),
        (m19456_26_0, m19456_26_1) if (&m19456_26_0 == &Text::lit("map")) && (&m19456_26_1 == &Nat::from(1u32)) => Text::lit("free"),
        (m19456_27_0, m19456_27_1) if (&m19456_27_0 == &Text::lit("iter_mut")) && (&m19456_27_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19456_28_0, m19456_28_1) if (&m19456_28_0 == &Text::lit("to_vec")) && (&m19456_28_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m19456_29_0, m19456_29_1) if (&m19456_29_0 == &Text::lit("filter_some")) && (&m19456_29_1 == &Nat::from(0u32)) => Text::lit("free"),
        _ => Text::lit("dot"),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// FreeName: fn Text -> Text
/// ```
pub fn free_name(m_p0: &Text) -> Text {
    match m_p0 {
        m20393_0 if (m20393_0 == &Text::lit("to_pod")) => Text::lit("prism_rtl::to_pod"),
        m20393_1 if (m20393_1 == &Text::lit("ok")) => Text::lit("prism_rtl::ignore"),
        m20393_2 if (m20393_2 == &Text::lit("map")) => Text::lit("prism_rtl::fmap"),
        m20393_3 if (m20393_3 == &Text::lit("to_vec")) => Text::lit("path_of"),
        m20393_4 if (m20393_4 == &Text::lit("values")) => Text::lit("crate::prelude::values"),
        m20393_5 if (m20393_5 == &Text::lit("keys")) => Text::lit("crate::prelude::keys"),
        m20393_6 if (m20393_6 == &Text::lit("enumerate")) => Text::lit("prism_rtl::enumerate"),
        m20393_7 if (m20393_7 == &Text::lit("unwrap_or_default")) => Text::lit("prism_rtl::unwrap_or_default"),
        m20393_8 if (m20393_8 == &Text::lit("for_each")) => Text::lit("prism_rtl::for_each"),
        _ => m_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// MemberName: fn Text -> Text
/// ```
pub fn member_name(m_p0: &Text) -> Text {
    match m_p0 {
        m20791_0 if (m20791_0 == &Text::lit("push_str")) => Text::lit("append"),
        m20791_1 if (m20791_1 == &Text::lit("len")) => Text::lit("size"),
        m20791_2 if (m20791_2 == &Text::lit("is_empty")) => Text::lit("empty"),
        m20791_3 if (m20791_3 == &Text::lit("push")) => Text::lit("push_back"),
        m20791_4 if (m20791_4 == &Text::lit("contains_key")) => Text::lit("contains"),
        m20791_5 if (m20791_5 == &Text::lit("build")) => Text::lit("make"),
        _ => crate::emit::cpp::cpp_id(m_p0),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CaseTest: fn Cp, Text, Text -> Text
/// ```
pub fn case_test(cp_p0: &crate::emit::cpp::Cp, c_p1: &Text, v_p2: &Text) -> Text {
    match c_p1 {
        m21090_0 if (m21090_0 == &Text::lit("Some")) => Text::from(format!("prism_rtl::is_some({})", v_p2)),
        m21090_1 if (m21090_1 == &Text::lit("None")) => Text::from(format!("prism_rtl::is_none({})", v_p2)),
        m21090_2 if (m21090_2 == &Text::lit("Ok")) => Text::from(format!("prism_rtl::is_ok({})", v_p2)),
        m21090_3 if (m21090_3 == &Text::lit("Err")) => Text::from(format!("prism_rtl::is_err({})", v_p2)),
        m21090_4 if (m21090_4 == &Text::lit("prism_rtl::Turn::More")) => Text::from(format!("{}.if_more()", v_p2)),
        m21090_5 if (m21090_5 == &Text::lit("prism_rtl::Turn::Finished")) => Text::from(format!("{}.if_finished()", v_p2)),
        _ => match crate::emit::cpp::case_of(cp_p0, c_p1) {
            Some(_) => Text::from(format!("prism_rtl::is<{}>({})", &case_type_of(cp_p0, c_p1, v_p2), v_p2)),
            None => if is_runtime_case(c_p1) {
                Text::from(format!("prism_rtl::is<{}>({})", &case_type(c_p1), v_p2))
            } else {
                Text::lit("true")
            },
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CaseType: fn Text -> Text
/// ```
pub fn case_type(c_p0: &Text) -> Text {
    match c_p0 {
        m21651_0 if (m21651_0 == &Text::lit("Segment::Pos")) => Text::lit("pat::Pos"),
        m21651_1 if (m21651_1 == &Text::lit("Segment::Gen")) => Text::lit("pat::Gen"),
        m21651_2 if (m21651_2 == &Text::lit("Segment::Key")) => Text::lit("pat::Key"),
        _ => crate::emit::cpp::type_path(c_p0),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CaseTypeOf: fn Cp, Text, Text -> Text
/// ```
pub fn case_type_of(cp_p0: &crate::emit::cpp::Cp, c_p1: &Text, v_p2: &Text) -> Text {
    if is_generic_case(cp_p0, c_p1) {
        Text::from(format!("typename std::remove_cvref_t<decltype({})>::{}", v_p2, &crate::emit::cpp::last_segment(&crate::emit::cpp::type_path(c_p1))))
    } else {
        case_type(c_p1)
    }
}

/// ```prism
/// IsGenericCase: fn Cp, Text -> Bool
/// ```
pub fn is_generic_case(cp_p0: &crate::emit::cpp::Cp, p_p1: &Text) -> bool {
    match crate::emit::cpp::case_of(cp_p0, p_p1) {
        Some(ty_p2) => match crate::emit::cpp::type_of(cp_p0, &ty_p2) {
            Some(info_p3) => &len(&info_p3.params) > &Nat::from(0u32),
            None => false,
        },
        None => false,
    }
}

/// ```prism
/// Payload: fn Cp, Text, Text, Nat -> Text
/// ```
pub fn payload(cp_p0: &crate::emit::cpp::Cp, c_p1: &Text, v_p2: &Text, i_p3: &Nat) -> Text {
    match c_p1 {
        m22511_0 if (m22511_0 == &Text::lit("Some")) => Text::from(format!("prism_rtl::some_of({})", v_p2)),
        m22511_1 if (m22511_1 == &Text::lit("Ok")) => Text::from(format!("*{}", v_p2)),
        m22511_2 if (m22511_2 == &Text::lit("Err")) => Text::from(format!("{}.error()", v_p2)),
        m22511_3 if (m22511_3 == &Text::lit("prism_rtl::Turn::More")) => Text::from(format!("{}.if_more()->next", v_p2)),
        m22511_4 if (m22511_4 == &Text::lit("prism_rtl::Turn::Finished")) => Text::from(format!("{}.if_finished()->value", v_p2)),
        _ => match crate::emit::cpp::case_of(cp_p0, c_p1) {
            Some(_) => Text::from(format!("prism_rtl::as<{}>({}).a{}", &case_type_of(cp_p0, c_p1, v_p2), v_p2, i_p3)),
            None => if is_runtime_case(c_p1) {
                Text::from(format!("prism_rtl::as<{}>({}).a{}", &case_type(c_p1), v_p2, i_p3))
            } else {
                Text::from(format!("{}.a{}", v_p2, i_p3))
            },
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IsRuntimeCase: fn Text -> Bool
/// ```
pub fn is_runtime_case(c_p0: &Text) -> bool {
    crate::syntax::lexer::chars::has_prefix(c_p0, &Text::lit("Segment::"))
}

/// ```prism
/// CppIf: unbounded fn Cp, Ex, Ex, Ex -> Text
/// ```
pub fn cpp_if(cp_p0: &crate::emit::cpp::Cp, c_p1: &crate::lower::model::Ex, t_p2: &crate::lower::model::Ex, e_p3: &crate::lower::model::Ex) -> Text {
    let ct_p4 = cpp_expr(cp_p0, c_p1);
    let err_o5 = match (err_of(t_p2), err_of(e_p3)) {
        (Some(y_p9), _) => Some(y_p9),
        (None, Some(y_pa)) => Some(y_pa),
        _ => None,
    };
    let tt_p6 = match &err_o5 {
        Some(y_pb) => ok_branch(cp_p0, t_p2, y_pb),
        None => cpp_expr(cp_p0, t_p2),
    };
    let et_p7 = match &err_o5 {
        Some(y_pc) => ok_branch(cp_p0, e_p3, y_pc),
        None => cpp_expr(cp_p0, e_p3),
    };
    let short_p8 = !crate::syntax::lexer::chars::contains(&Text::from(format!("{}{}", &tt_p6, &et_p7)), &Text::lit("\n")) && (&len_text(&Text::from(format!("{}{}{}", &ct_p4, &tt_p6, &et_p7))) < &Nat::from(70u32));
    if short_p8 {
        Text::from(format!("{} ? {} : {}", &ct_p4, &tt_p6, &et_p7))
    } else {
        crate::emit::cpp::templates::items::cond_expr(&ct_p4, &tt_p6, &et_p7)
    }
}

/// The step machine of `CppIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppIf: unbounded fn Cp, Ex, Ex, Ex -> Text
/// ```
pub struct CppIf {
    pub cp_p0: crate::emit::cpp::Cp,
    pub c_p1: crate::lower::model::Ex,
    pub t_p2: crate::lower::model::Ex,
    pub e_p3: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppIf {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let c_p1 = &self.c_p1;
        let t_p2 = &self.t_p2;
        let e_p3 = &self.e_p3;
        let c_p1 = c_p1.clone();
        let cp_p0 = cp_p0.clone();
        let e_p3 = e_p3.clone();
        let t_p2 = t_p2.clone();
        call_then(start_cpp_expr(cp_p0.clone(), c_p1.clone()), move |cpp_expr_23097: Text| {
            let ct_p4 = cpp_expr_23097;
            let err_o5 = match (err_of(&t_p2), err_of(&e_p3)) {
                (Some(y_p9), _) => Some(y_p9),
                (None, Some(y_pa)) => Some(y_pa),
                _ => None,
            };
            let tt_p6 = match &err_o5 {
                Some(y_pb) => ok_branch(&cp_p0, &t_p2, y_pb),
                None => cpp_expr(&cp_p0, &t_p2),
            };
            let et_p7 = match &err_o5 {
                Some(y_pc) => ok_branch(&cp_p0, &e_p3, y_pc),
                None => cpp_expr(&cp_p0, &e_p3),
            };
            let short_p8 = !crate::syntax::lexer::chars::contains(&Text::from(format!("{}{}", &tt_p6, &et_p7)), &Text::lit("\n")) && (&len_text(&Text::from(format!("{}{}{}", &ct_p4, &tt_p6, &et_p7))) < &Nat::from(70u32));
            if short_p8 {
                prism_rtl::Turn::Finished(Text::from(format!("{} ? {} : {}", &ct_p4, &tt_p6, &et_p7)))
            } else {
                prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cond_expr(&ct_p4, &tt_p6, &et_p7))
            }
        })
    }
}

/// `Start CppIf, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_if(cp_p0: crate::emit::cpp::Cp, c_p1: crate::lower::model::Ex, t_p2: crate::lower::model::Ex, e_p3: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppIf { cp_p0, c_p1, t_p2, e_p3 })
}

/// ```prism
/// WithMoveCaptures: unbounded fn Cp, [Do], Ex -> Cp
/// ```
pub fn with_move_captures(cp_p0: &crate::emit::cpp::Cp, dos_p1: &Array<crate::lower::model::Do>, e_p2: &crate::lower::model::Ex) -> crate::emit::cpp::Cp {
    let lets_p3 = fold(dos_p1, &Array::new(), &(|acc_p4: &Array<Text>, d_p5: &crate::lower::model::Do| match d_p5 {
        crate::lower::model::Do::DoLet(p_p6, _) => match crate::emit::cpp::stmts::let_name(p_p6) {
            Some(n_p7) => if crate::emit::cpp::in_list(acc_p4, &n_p7) {
                acc_p4.clone()
            } else {
                push(acc_p4, &n_p7)
            },
            None => acc_p4.clone(),
        },
        _ => acc_p4.clone(),
    }));
    if &len(&lets_p3) == &Nat::from(0u32) {
        {
            let mut this: crate::emit::cpp::Cp = cp_p0.clone();
            this.move_captures = Array::new();
            this
        }
    } else {
        {
            let (reads_p8, has_move_p9) = reads_of(e_p2, &false, &(Array::new(), false));
            {
                let mut this: crate::emit::cpp::Cp = cp_p0.clone();
                this.move_captures = if has_move_p9 {
                    filter(&lets_p3, &(|n_pa: &Text| !crate::emit::cpp::in_list(&reads_p8, n_pa)))
                } else {
                    Array::new()
                };
                this
            }
        }
    }
}

/// The step machine of `WithMoveCaptures`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WithMoveCaptures: unbounded fn Cp, [Do], Ex -> Cp
/// ```
pub struct WithMoveCaptures {
    pub cp_p0: crate::emit::cpp::Cp,
    pub dos_p1: Array<crate::lower::model::Do>,
    pub e_p2: crate::lower::model::Ex,
}

impl prism_rtl::Job<crate::emit::cpp::Cp> for WithMoveCaptures {
    fn cycle(&self) -> prism_rtl::Turn<crate::emit::cpp::Cp> {
        let cp_p0 = &self.cp_p0;
        let dos_p1 = &self.dos_p1;
        let e_p2 = &self.e_p2;
        let lets_p3 = fold(dos_p1, &Array::new(), &(|acc_p4: &Array<Text>, d_p5: &crate::lower::model::Do| match d_p5 {
            crate::lower::model::Do::DoLet(p_p6, _) => match crate::emit::cpp::stmts::let_name(p_p6) {
                Some(n_p7) => if crate::emit::cpp::in_list(acc_p4, &n_p7) {
                    acc_p4.clone()
                } else {
                    push(acc_p4, &n_p7)
                },
                None => acc_p4.clone(),
            },
            _ => acc_p4.clone(),
        }));
        if &len(&lets_p3) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished({
                let mut this: crate::emit::cpp::Cp = cp_p0.clone();
                this.move_captures = Array::new();
                this
            })
        } else {
            {
                let cp_p0 = cp_p0.clone();
                let e_p2 = e_p2.clone();
                call_then(start_reads_of(e_p2.clone(), false, (Array::new(), false)), move |reads_of_24346: (Array<Text>, bool)| {
                    let (reads_p8, has_move_p9) = reads_of_24346;
                    prism_rtl::Turn::Finished({
                        let mut this: crate::emit::cpp::Cp = cp_p0.clone();
                        this.move_captures = if has_move_p9 {
                            filter(&lets_p3, &(|n_pa: &Text| !crate::emit::cpp::in_list(&reads_p8, n_pa)))
                        } else {
                            Array::new()
                        };
                        this
                    })
                })
            }
        }
    }
}

/// `Start WithMoveCaptures, x`: what the function value is when passed to `@Run`.
pub fn start_with_move_captures(cp_p0: crate::emit::cpp::Cp, dos_p1: Array<crate::lower::model::Do>, e_p2: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<crate::emit::cpp::Cp>> {
    Rc::new(WithMoveCaptures { cp_p0, dos_p1, e_p2 })
}

/// ```prism
/// ReadsOf: unbounded fn Ex, Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub fn reads_of(x_p0: &crate::lower::model::Ex, into_p1: &bool, acc_p2: &(Array<Text>, bool)) -> (Array<Text>, bool) {
    let (reads_p3, has_move_p4) = acc_p2.clone();
    match x_p0 {
        crate::lower::model::Ex::XVar(n_p5) => (push(&reads_p3, n_p5), has_move_p4),
        crate::lower::model::Ex::XClosure(true, ps_p6, body_p7) => if *into_p1 {
            reads_of(&**body_p7, into_p1, &(reads_p3.clone(), true))
        } else {
            (reads_p3.clone(), true)
        },
        crate::lower::model::Ex::XClosure(false, ps_p8, body_p9) => reads_of(&**body_p9, into_p1, acc_p2),
        crate::lower::model::Ex::XRef(y_pa) => reads_of(&**y_pa, into_p1, acc_p2),
        crate::lower::model::Ex::XRefMut(y_pb) => reads_of(&**y_pb, into_p1, acc_p2),
        crate::lower::model::Ex::XDeref(y_pc) => reads_of(&**y_pc, into_p1, acc_p2),
        crate::lower::model::Ex::XTarget(y_pd) => reads_of(&**y_pd, into_p1, acc_p2),
        crate::lower::model::Ex::XClone(y_pe) => reads_of(&**y_pe, into_p1, acc_p2),
        crate::lower::model::Ex::XWeak(y_pf) => reads_of(&**y_pf, into_p1, acc_p2),
        crate::lower::model::Ex::XUpgrade(y_pg) => reads_of(&**y_pg, into_p1, acc_p2),
        crate::lower::model::Ex::XBreak(_, y_ph) => reads_of(&**y_ph, into_p1, acc_p2),
        crate::lower::model::Ex::XLater(y_pi) => reads_of(&**y_pi, into_p1, acc_p2),
        crate::lower::model::Ex::XFormatStr(xs_pj) => reads_each(xs_pj, into_p1, acc_p2),
        crate::lower::model::Ex::XIsCase(y_pk, _) => reads_of(&**y_pk, into_p1, acc_p2),
        crate::lower::model::Ex::XCall(_, xs_pl) => reads_each(xs_pl, into_p1, acc_p2),
        crate::lower::model::Ex::XApply(f_pm, xs_pn) => reads_each(&append(&Array::from(vec![(**f_pm).clone()]), xs_pn), into_p1, acc_p2),
        crate::lower::model::Ex::XMethod(r_po, _, xs_pp) => reads_each(&append(&Array::from(vec![(**r_po).clone()]), xs_pp), into_p1, acc_p2),
        crate::lower::model::Ex::XBin(_, l_pq, r_pr) => reads_each(&Array::from(vec![(**l_pq).clone(), (**r_pr).clone()]), into_p1, acc_p2),
        crate::lower::model::Ex::XUnary(_, y_ps) => reads_of(&**y_ps, into_p1, acc_p2),
        crate::lower::model::Ex::XCtor(_, xs_pt) => reads_each(xs_pt, into_p1, acc_p2),
        crate::lower::model::Ex::XRecord(_, fs_pu) => reads_each(&each(fs_pu, &(|(_, v_pv): &(Text, crate::lower::model::Ex)| v_pv.clone())), into_p1, acc_p2),
        crate::lower::model::Ex::XTuple(xs_p10) => reads_each(xs_p10, into_p1, acc_p2),
        crate::lower::model::Ex::XVec(xs_p11) => reads_each(xs_p11, into_p1, acc_p2),
        crate::lower::model::Ex::XFormat(xs_p12) => reads_each(xs_p12, into_p1, acc_p2),
        crate::lower::model::Ex::XMatch(s_p13, arms_p14, _, _) => reads_arms(arms_p14, into_p1, &reads_of(&**s_p13, into_p1, acc_p2)),
        crate::lower::model::Ex::XChain(_, s_p15, arms_p16, _) => reads_arms(arms_p16, into_p1, &reads_of(&**s_p15, into_p1, acc_p2)),
        crate::lower::model::Ex::XIf(c_p17, t_p18, e_p19) => reads_each(&Array::from(vec![(**c_p17).clone(), (**t_p18).clone(), (**e_p19).clone()]), into_p1, acc_p2),
        crate::lower::model::Ex::XBlock(dos_p1a, e_p1b) => reads_of(&**e_p1b, into_p1, &reads_dos(dos_p1a, into_p1, acc_p2)),
        crate::lower::model::Ex::XLabeled(_, dos_p1c, e_p1d, _) => reads_of(&**e_p1d, into_p1, &reads_dos(dos_p1c, into_p1, acc_p2)),
        crate::lower::model::Ex::XTry(y_p1e) => reads_of(&**y_p1e, into_p1, acc_p2),
        crate::lower::model::Ex::XField(r_p1f, _) => reads_of(&**r_p1f, into_p1, acc_p2),
        crate::lower::model::Ex::XPart(r_p1g, _) => reads_of(&**r_p1g, into_p1, acc_p2),
        crate::lower::model::Ex::XDecode(_, y_p1h) => reads_of(&**y_p1h, into_p1, acc_p2),
        crate::lower::model::Ex::XCast(y_p1i, _) => reads_of(&**y_p1i, into_p1, acc_p2),
        crate::lower::model::Ex::XTyped(y_p1j, _) => reads_of(&**y_p1j, into_p1, acc_p2),
        _ => acc_p2.clone(),
    }
}

/// The step machine of `ReadsOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadsOf: unbounded fn Ex, Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub struct ReadsOf {
    pub x_p0: crate::lower::model::Ex,
    pub into_p1: bool,
    pub acc_p2: (Array<Text>, bool),
}

impl prism_rtl::Job<(Array<Text>, bool)> for ReadsOf {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Text>, bool)> {
        let x_p0 = &self.x_p0;
        let into_p1 = &self.into_p1;
        let acc_p2 = &self.acc_p2;
        let (reads_p3, has_move_p4) = acc_p2.clone();
        match x_p0 {
            crate::lower::model::Ex::XVar(n_p5) => prism_rtl::Turn::Finished((push(&reads_p3, n_p5), has_move_p4)),
            crate::lower::model::Ex::XClosure(true, ps_p6, body_p7) => if *into_p1 {
                prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**body_p7).clone(), into_p1: *into_p1, acc_p2: (reads_p3.clone(), true) }))
            } else {
                prism_rtl::Turn::Finished((reads_p3.clone(), true))
            },
            crate::lower::model::Ex::XClosure(false, ps_p8, body_p9) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**body_p9).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XRef(y_pa) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_pa).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XRefMut(y_pb) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_pb).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XDeref(y_pc) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_pc).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XTarget(y_pd) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_pd).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XClone(y_pe) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_pe).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XWeak(y_pf) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_pf).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XUpgrade(y_pg) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_pg).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XBreak(_, y_ph) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_ph).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XLater(y_pi) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_pi).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XFormatStr(xs_pj) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: xs_pj.clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XIsCase(y_pk, _) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_pk).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XCall(_, xs_pl) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: xs_pl.clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XApply(f_pm, xs_pn) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: append(&Array::from(vec![(**f_pm).clone()]), xs_pn), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XMethod(r_po, _, xs_pp) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: append(&Array::from(vec![(**r_po).clone()]), xs_pp), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XBin(_, l_pq, r_pr) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: Array::from(vec![(**l_pq).clone(), (**r_pr).clone()]), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XUnary(_, y_ps) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_ps).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XCtor(_, xs_pt) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: xs_pt.clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XRecord(_, fs_pu) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: each(fs_pu, &(|(_, v_pv): &(Text, crate::lower::model::Ex)| v_pv.clone())), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XTuple(xs_p10) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: xs_p10.clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XVec(xs_p11) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: xs_p11.clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XFormat(xs_p12) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: xs_p12.clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XMatch(s_p13, arms_p14, _, _) => {
                let acc_p2 = acc_p2.clone();
                let arms_p14 = arms_p14.clone();
                let into_p1 = *into_p1;
                let s_p13 = (**s_p13).clone();
                call_then(start_reads_of(s_p13.clone(), into_p1, acc_p2.clone()), move |reads_of_26048: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsArms { arms_p0: arms_p14.clone(), into_p1, acc_p2: reads_of_26048 })))
            },
            crate::lower::model::Ex::XChain(_, s_p15, arms_p16, _) => {
                let acc_p2 = acc_p2.clone();
                let arms_p16 = arms_p16.clone();
                let into_p1 = *into_p1;
                let s_p15 = (**s_p15).clone();
                call_then(start_reads_of(s_p15.clone(), into_p1, acc_p2.clone()), move |reads_of_26133: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsArms { arms_p0: arms_p16.clone(), into_p1, acc_p2: reads_of_26133 })))
            },
            crate::lower::model::Ex::XIf(c_p17, t_p18, e_p19) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: Array::from(vec![(**c_p17).clone(), (**t_p18).clone(), (**e_p19).clone()]), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XBlock(dos_p1a, e_p1b) => {
                let acc_p2 = acc_p2.clone();
                let dos_p1a = dos_p1a.clone();
                let e_p1b = (**e_p1b).clone();
                let into_p1 = *into_p1;
                call_then(start_reads_dos(dos_p1a.clone(), into_p1, acc_p2.clone()), move |reads_dos_26250: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: e_p1b.clone(), into_p1, acc_p2: reads_dos_26250 })))
            },
            crate::lower::model::Ex::XLabeled(_, dos_p1c, e_p1d, _) => {
                let acc_p2 = acc_p2.clone();
                let dos_p1c = dos_p1c.clone();
                let e_p1d = (**e_p1d).clone();
                let into_p1 = *into_p1;
                call_then(start_reads_dos(dos_p1c.clone(), into_p1, acc_p2.clone()), move |reads_dos_26334: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: e_p1d.clone(), into_p1, acc_p2: reads_dos_26334 })))
            },
            crate::lower::model::Ex::XTry(y_p1e) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_p1e).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XField(r_p1f, _) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**r_p1f).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XPart(r_p1g, _) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**r_p1g).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XDecode(_, y_p1h) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_p1h).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XCast(y_p1i, _) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_p1i).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XTyped(y_p1j, _) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: (**y_p1j).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            _ => prism_rtl::Turn::Finished(acc_p2.clone()),
        }
    }
}

/// `Start ReadsOf, x`: what the function value is when passed to `@Run`.
pub fn start_reads_of(x_p0: crate::lower::model::Ex, into_p1: bool, acc_p2: (Array<Text>, bool)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>> {
    Rc::new(ReadsOf { x_p0, into_p1, acc_p2 })
}

/// ```prism
/// ReadsEach: unbounded fn [Ex], Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub fn reads_each(xs_p0: &Array<crate::lower::model::Ex>, into_p1: &bool, acc_p2: &(Array<Text>, bool)) -> (Array<Text>, bool) {
    run_to_end(fold_job(xs_p0.clone(), acc_p2.clone(), {
        let into_p1 = *into_p1;
        Rc::new(move |(p0, p1): ((Array<Text>, bool), crate::lower::model::Ex)| {
            let into_p1 = into_p1;
            entered(once_job(move || {
                let a_p3 = p0;
                let x_p4 = p1;
                prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: x_p4.clone(), into_p1, acc_p2: a_p3.clone() }))
            }))
        }) as Rc<dyn Fn(((Array<Text>, bool), crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
    }))
}

/// The step machine of `ReadsEach`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadsEach: unbounded fn [Ex], Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub struct ReadsEach {
    pub xs_p0: Array<crate::lower::model::Ex>,
    pub into_p1: bool,
    pub acc_p2: (Array<Text>, bool),
}

impl prism_rtl::Job<(Array<Text>, bool)> for ReadsEach {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Text>, bool)> {
        let xs_p0 = &self.xs_p0;
        let into_p1 = &self.into_p1;
        let acc_p2 = &self.acc_p2;
        fold_job(xs_p0.clone(), acc_p2.clone(), {
            let into_p1 = *into_p1;
            Rc::new(move |(p0, p1): ((Array<Text>, bool), crate::lower::model::Ex)| {
                let into_p1 = into_p1;
                entered(once_job(move || {
                    let a_p3 = p0;
                    let x_p4 = p1;
                    prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: x_p4.clone(), into_p1, acc_p2: a_p3.clone() }))
                }))
            }) as Rc<dyn Fn(((Array<Text>, bool), crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
        }).cycle()
    }
}

/// `Start ReadsEach, x`: what the function value is when passed to `@Run`.
pub fn start_reads_each(xs_p0: Array<crate::lower::model::Ex>, into_p1: bool, acc_p2: (Array<Text>, bool)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>> {
    Rc::new(ReadsEach { xs_p0, into_p1, acc_p2 })
}

/// ```prism
/// ReadsArms: unbounded fn [XArm], Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub fn reads_arms(arms_p0: &Array<crate::lower::model::XArm>, into_p1: &bool, acc_p2: &(Array<Text>, bool)) -> (Array<Text>, bool) {
    run_to_end(fold_job(arms_p0.clone(), acc_p2.clone(), {
        let into_p1 = *into_p1;
        Rc::new(move |(p0, p1): ((Array<Text>, bool), crate::lower::model::XArm)| {
            let into_p1 = into_p1;
            entered(once_job(move || {
                let a_p3 = p0;
                let arm_p4 = p1;
                call_value(fold_job(arm_p4.conds.clone(), a_p3.clone(), {
                    let into_p1 = into_p1;
                    Rc::new(move |(p0, p1): ((Array<Text>, bool), crate::lower::model::Cc)| {
                        let into_p1 = into_p1;
                        entered(once_job(move || {
                            let a2_p5 = p0;
                            let c_p6 = p1;
                            prism_rtl::Turn::More(Rc::new(ReadsCond { cc0: c_p6.clone(), into_p1, acc_p2: a2_p5.clone() }))
                        }))
                    }) as Rc<dyn Fn(((Array<Text>, bool), crate::lower::model::Cc)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
                }), move |fold_26955: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: arm_p4.body.clone(), into_p1, acc_p2: fold_26955 })))
            }))
        }) as Rc<dyn Fn(((Array<Text>, bool), crate::lower::model::XArm)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
    }))
}

/// The step machine of `ReadsArms`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadsArms: unbounded fn [XArm], Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub struct ReadsArms {
    pub arms_p0: Array<crate::lower::model::XArm>,
    pub into_p1: bool,
    pub acc_p2: (Array<Text>, bool),
}

impl prism_rtl::Job<(Array<Text>, bool)> for ReadsArms {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Text>, bool)> {
        let arms_p0 = &self.arms_p0;
        let into_p1 = &self.into_p1;
        let acc_p2 = &self.acc_p2;
        fold_job(arms_p0.clone(), acc_p2.clone(), {
            let into_p1 = *into_p1;
            Rc::new(move |(p0, p1): ((Array<Text>, bool), crate::lower::model::XArm)| {
                let into_p1 = into_p1;
                entered(once_job(move || {
                    let a_p3 = p0;
                    let arm_p4 = p1;
                    call_value(fold_job(arm_p4.conds.clone(), a_p3.clone(), {
                        let into_p1 = into_p1;
                        Rc::new(move |(p0, p1): ((Array<Text>, bool), crate::lower::model::Cc)| {
                            let into_p1 = into_p1;
                            entered(once_job(move || {
                                let a2_p5 = p0;
                                let c_p6 = p1;
                                prism_rtl::Turn::More(Rc::new(ReadsCond { cc0: c_p6.clone(), into_p1, acc_p2: a2_p5.clone() }))
                            }))
                        }) as Rc<dyn Fn(((Array<Text>, bool), crate::lower::model::Cc)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
                    }), move |fold_26955: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: arm_p4.body.clone(), into_p1, acc_p2: fold_26955 })))
                }))
            }) as Rc<dyn Fn(((Array<Text>, bool), crate::lower::model::XArm)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
        }).cycle()
    }
}

/// `Start ReadsArms, x`: what the function value is when passed to `@Run`.
pub fn start_reads_arms(arms_p0: Array<crate::lower::model::XArm>, into_p1: bool, acc_p2: (Array<Text>, bool)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>> {
    Rc::new(ReadsArms { arms_p0, into_p1, acc_p2 })
}

/// ```prism
/// ReadsCond: unbounded fn Cc, Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub fn reads_cond(cc0: &crate::lower::model::Cc, into_p1: &bool, acc_p2: &(Array<Text>, bool)) -> (Array<Text>, bool) {
    match cc0 {
        crate::lower::model::Cc::CcLet(_, x_p0) => reads_of(x_p0, into_p1, acc_p2),
        crate::lower::model::Cc::CcIf(x_p3) => reads_of(x_p3, into_p1, acc_p2),
    }
}

/// The step machine of `ReadsCond`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadsCond: unbounded fn Cc, Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub struct ReadsCond {
    pub cc0: crate::lower::model::Cc,
    pub into_p1: bool,
    pub acc_p2: (Array<Text>, bool),
}

impl prism_rtl::Job<(Array<Text>, bool)> for ReadsCond {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Text>, bool)> {
        let cc0 = &self.cc0;
        let into_p1 = &self.into_p1;
        let acc_p2 = &self.acc_p2;
        match cc0 {
            crate::lower::model::Cc::CcLet(_, x_p0) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: x_p0.clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Cc::CcIf(x_p3) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: x_p3.clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
        }
    }
}

/// `Start ReadsCond, x`: what the function value is when passed to `@Run`.
pub fn start_reads_cond(cc0: crate::lower::model::Cc, into_p1: bool, acc_p2: (Array<Text>, bool)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>> {
    Rc::new(ReadsCond { cc0, into_p1, acc_p2 })
}

/// ```prism
/// ReadsDos: unbounded fn [Do], Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub fn reads_dos(dos_p0: &Array<crate::lower::model::Do>, into_p1: &bool, acc_p2: &(Array<Text>, bool)) -> (Array<Text>, bool) {
    run_to_end(fold_job(dos_p0.clone(), acc_p2.clone(), {
        let into_p1 = *into_p1;
        Rc::new(move |(p0, p1): ((Array<Text>, bool), crate::lower::model::Do)| {
            let into_p1 = into_p1;
            entered(once_job(move || {
                let a_p3 = p0;
                let d_p4 = p1;
                match &d_p4 {
                    crate::lower::model::Do::DoLet(_, x_p5) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: x_p5.clone(), into_p1, acc_p2: a_p3.clone() })),
                    crate::lower::model::Do::DoLetElse(_, x_p6, e_p7) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: Array::from(vec![x_p6.clone(), e_p7.clone()]), into_p1, acc_p2: a_p3.clone() })),
                    crate::lower::model::Do::DoAssign(p_p8, x_p9) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: Array::from(vec![p_p8.clone(), x_p9.clone()]), into_p1, acc_p2: a_p3.clone() })),
                    crate::lower::model::Do::DoWhile(c_pa, body_pb) => {
                        let body_pb = body_pb.clone();
                        let c_pa = c_pa.clone();
                        call_then(start_reads_of(c_pa.clone(), into_p1, a_p3.clone()), move |reads_of_27519: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_pb.clone(), into_p1, acc_p2: reads_of_27519 })))
                    },
                    crate::lower::model::Do::DoWhileLet(_, x_pc, body_pd) => {
                        let body_pd = body_pd.clone();
                        let x_pc = x_pc.clone();
                        call_then(start_reads_of(x_pc.clone(), into_p1, a_p3.clone()), move |reads_of_27593: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_pd.clone(), into_p1, acc_p2: reads_of_27593 })))
                    },
                    crate::lower::model::Do::DoFor(_, x_pe, body_pf) => {
                        let body_pf = body_pf.clone();
                        let x_pe = x_pe.clone();
                        call_then(start_reads_of(x_pe.clone(), into_p1, a_p3.clone()), move |reads_of_27662: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_pf.clone(), into_p1, acc_p2: reads_of_27662 })))
                    },
                    crate::lower::model::Do::DoExpr(x_pg) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: x_pg.clone(), into_p1, acc_p2: a_p3.clone() })),
                    crate::lower::model::Do::DoIf(c_ph, t_pi, e_pj) => {
                        let c_ph = c_ph.clone();
                        let e_pj = e_pj.clone();
                        let t_pi = t_pi.clone();
                        call_then(start_reads_of(c_ph.clone(), into_p1, a_p3.clone()), move |reads_of_27771: (Array<Text>, bool)| call_then(start_reads_dos(t_pi.clone(), into_p1, reads_of_27771), move |reads_dos_27752: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: e_pj.clone(), into_p1, acc_p2: reads_dos_27752 }))))
                    },
                    crate::lower::model::Do::DoIfLet(_, x_pk, t_pl, e_pm) => {
                        let e_pm = e_pm.clone();
                        let t_pl = t_pl.clone();
                        let x_pk = x_pk.clone();
                        call_then(start_reads_of(x_pk.clone(), into_p1, a_p3.clone()), move |reads_of_27859: (Array<Text>, bool)| call_then(start_reads_dos(t_pl.clone(), into_p1, reads_of_27859), move |reads_dos_27840: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: e_pm.clone(), into_p1, acc_p2: reads_dos_27840 }))))
                    },
                    crate::lower::model::Do::DoMatch(x_pn, cases_po) => {
                        let cases_po = cases_po.clone();
                        let x_pn = x_pn.clone();
                        call_then(start_reads_of(x_pn.clone(), into_p1, a_p3.clone()), move |reads_of_27915: (Array<Text>, bool)| fold_job(cases_po.clone(), reads_of_27915, {
                            let into_p1 = into_p1;
                            Rc::new(move |(p0, p1): ((Array<Text>, bool), (crate::lower::model::Pa, Array<crate::lower::model::Do>))| {
                                let into_p1 = into_p1;
                                entered(once_job(move || {
                                    let a2_pp = p0;
                                    let (_, body_pq) = p1;
                                    prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_pq.clone(), into_p1, acc_p2: a2_pp.clone() }))
                                }))
                            }) as Rc<dyn Fn(((Array<Text>, bool), (crate::lower::model::Pa, Array<crate::lower::model::Do>))) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
                        }).cycle())
                    },
                    crate::lower::model::Do::DoReturn(x_pr) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: x_pr.clone(), into_p1, acc_p2: a_p3.clone() })),
                    crate::lower::model::Do::DoBlock(body_ps) => prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_ps.clone(), into_p1, acc_p2: a_p3.clone() })),
                    crate::lower::model::Do::DoScope(body_pt) => prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_pt.clone(), into_p1, acc_p2: a_p3.clone() })),
                    crate::lower::model::Do::DoLine(body_pu) => prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_pu.clone(), into_p1, acc_p2: a_p3.clone() })),
                    crate::lower::model::Do::DoNote(_) => prism_rtl::Turn::Finished(a_p3.clone()),
                }
            }))
        }) as Rc<dyn Fn(((Array<Text>, bool), crate::lower::model::Do)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
    }))
}

/// The step machine of `ReadsDos`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadsDos: unbounded fn [Do], Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub struct ReadsDos {
    pub dos_p0: Array<crate::lower::model::Do>,
    pub into_p1: bool,
    pub acc_p2: (Array<Text>, bool),
}

impl prism_rtl::Job<(Array<Text>, bool)> for ReadsDos {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Text>, bool)> {
        let dos_p0 = &self.dos_p0;
        let into_p1 = &self.into_p1;
        let acc_p2 = &self.acc_p2;
        fold_job(dos_p0.clone(), acc_p2.clone(), {
            let into_p1 = *into_p1;
            Rc::new(move |(p0, p1): ((Array<Text>, bool), crate::lower::model::Do)| {
                let into_p1 = into_p1;
                entered(once_job(move || {
                    let a_p3 = p0;
                    let d_p4 = p1;
                    match &d_p4 {
                        crate::lower::model::Do::DoLet(_, x_p5) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: x_p5.clone(), into_p1, acc_p2: a_p3.clone() })),
                        crate::lower::model::Do::DoLetElse(_, x_p6, e_p7) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: Array::from(vec![x_p6.clone(), e_p7.clone()]), into_p1, acc_p2: a_p3.clone() })),
                        crate::lower::model::Do::DoAssign(p_p8, x_p9) => prism_rtl::Turn::More(Rc::new(ReadsEach { xs_p0: Array::from(vec![p_p8.clone(), x_p9.clone()]), into_p1, acc_p2: a_p3.clone() })),
                        crate::lower::model::Do::DoWhile(c_pa, body_pb) => {
                            let body_pb = body_pb.clone();
                            let c_pa = c_pa.clone();
                            call_then(start_reads_of(c_pa.clone(), into_p1, a_p3.clone()), move |reads_of_27519: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_pb.clone(), into_p1, acc_p2: reads_of_27519 })))
                        },
                        crate::lower::model::Do::DoWhileLet(_, x_pc, body_pd) => {
                            let body_pd = body_pd.clone();
                            let x_pc = x_pc.clone();
                            call_then(start_reads_of(x_pc.clone(), into_p1, a_p3.clone()), move |reads_of_27593: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_pd.clone(), into_p1, acc_p2: reads_of_27593 })))
                        },
                        crate::lower::model::Do::DoFor(_, x_pe, body_pf) => {
                            let body_pf = body_pf.clone();
                            let x_pe = x_pe.clone();
                            call_then(start_reads_of(x_pe.clone(), into_p1, a_p3.clone()), move |reads_of_27662: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_pf.clone(), into_p1, acc_p2: reads_of_27662 })))
                        },
                        crate::lower::model::Do::DoExpr(x_pg) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: x_pg.clone(), into_p1, acc_p2: a_p3.clone() })),
                        crate::lower::model::Do::DoIf(c_ph, t_pi, e_pj) => {
                            let c_ph = c_ph.clone();
                            let e_pj = e_pj.clone();
                            let t_pi = t_pi.clone();
                            call_then(start_reads_of(c_ph.clone(), into_p1, a_p3.clone()), move |reads_of_27771: (Array<Text>, bool)| call_then(start_reads_dos(t_pi.clone(), into_p1, reads_of_27771), move |reads_dos_27752: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: e_pj.clone(), into_p1, acc_p2: reads_dos_27752 }))))
                        },
                        crate::lower::model::Do::DoIfLet(_, x_pk, t_pl, e_pm) => {
                            let e_pm = e_pm.clone();
                            let t_pl = t_pl.clone();
                            let x_pk = x_pk.clone();
                            call_then(start_reads_of(x_pk.clone(), into_p1, a_p3.clone()), move |reads_of_27859: (Array<Text>, bool)| call_then(start_reads_dos(t_pl.clone(), into_p1, reads_of_27859), move |reads_dos_27840: (Array<Text>, bool)| prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: e_pm.clone(), into_p1, acc_p2: reads_dos_27840 }))))
                        },
                        crate::lower::model::Do::DoMatch(x_pn, cases_po) => {
                            let cases_po = cases_po.clone();
                            let x_pn = x_pn.clone();
                            call_then(start_reads_of(x_pn.clone(), into_p1, a_p3.clone()), move |reads_of_27915: (Array<Text>, bool)| fold_job(cases_po.clone(), reads_of_27915, {
                                let into_p1 = into_p1;
                                Rc::new(move |(p0, p1): ((Array<Text>, bool), (crate::lower::model::Pa, Array<crate::lower::model::Do>))| {
                                    let into_p1 = into_p1;
                                    entered(once_job(move || {
                                        let a2_pp = p0;
                                        let (_, body_pq) = p1;
                                        prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_pq.clone(), into_p1, acc_p2: a2_pp.clone() }))
                                    }))
                                }) as Rc<dyn Fn(((Array<Text>, bool), (crate::lower::model::Pa, Array<crate::lower::model::Do>))) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
                            }).cycle())
                        },
                        crate::lower::model::Do::DoReturn(x_pr) => prism_rtl::Turn::More(Rc::new(ReadsOf { x_p0: x_pr.clone(), into_p1, acc_p2: a_p3.clone() })),
                        crate::lower::model::Do::DoBlock(body_ps) => prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_ps.clone(), into_p1, acc_p2: a_p3.clone() })),
                        crate::lower::model::Do::DoScope(body_pt) => prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_pt.clone(), into_p1, acc_p2: a_p3.clone() })),
                        crate::lower::model::Do::DoLine(body_pu) => prism_rtl::Turn::More(Rc::new(ReadsDos { dos_p0: body_pu.clone(), into_p1, acc_p2: a_p3.clone() })),
                        crate::lower::model::Do::DoNote(_) => prism_rtl::Turn::Finished(a_p3.clone()),
                    }
                }))
            }) as Rc<dyn Fn(((Array<Text>, bool), crate::lower::model::Do)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>>>
        }).cycle()
    }
}

/// `Start ReadsDos, x`: what the function value is when passed to `@Run`.
pub fn start_reads_dos(dos_p0: Array<crate::lower::model::Do>, into_p1: bool, acc_p2: (Array<Text>, bool)) -> Rc<dyn prism_rtl::Job<(Array<Text>, bool)>> {
    Rc::new(ReadsDos { dos_p0, into_p1, acc_p2 })
}

/// ```prism
/// IsCtor: fn Ex, Text -> Bool
/// ```
pub fn is_ctor(ex0: &crate::lower::model::Ex, c_p1: &Text) -> bool {
    match ex0 {
        crate::lower::model::Ex::XCtor(p_p0, _) => p_p0 == c_p1,
        x_p2 => false,
    }
}

/// ```prism
/// ?ErrOf: fn Ex -> ?Ex
/// ```
pub fn err_of(x_p0: &crate::lower::model::Ex) -> Option<crate::lower::model::Ex> {
    'm28359: {
        if let crate::lower::model::Ex::XCtor(m28359_0_0, m28359_0_1) = x_p0 && (m28359_0_0 == &Text::lit("Err")) && (m28359_0_1.len() == 1) && let Some(y_p1) = index(m28359_0_1, &Nat::from(0u32)) {
            break 'm28359 Some(y_p1.clone());
        }
        if let crate::lower::model::Ex::XBlock(_, tail_p2) = x_p0 {
            break 'm28359 err_of(&**tail_p2);
        }
        None
    }
}

/// ```prism
/// OkBranch: unbounded fn Cp, Ex, Ex -> Text
/// ```
pub fn ok_branch(cp_p0: &crate::emit::cpp::Cp, x_p1: &crate::lower::model::Ex, y_p2: &crate::lower::model::Ex) -> Text {
    'm28662: {
        if let crate::lower::model::Ex::XCtor(m28662_0_0, m28662_0_1) = x_p1 && (m28662_0_0 == &Text::lit("Ok")) && (m28662_0_1.len() == 1) && let Some(v_p3) = index(m28662_0_1, &Nat::from(0u32)) {
            break 'm28662 Text::from(format!("Expected<std::decay_t<decltype({})>, std::decay_t<decltype({})>>({})", &cpp_expr(cp_p0, &v_p3), &cpp_expr(cp_p0, y_p2), &cpp_expr(cp_p0, &v_p3)));
        }
        if let crate::lower::model::Ex::XBlock(dos_p4, m28662_1_1) = x_p1 && let crate::lower::model::Ex::XCtor(m28662_1_1_r_0, m28662_1_1_r_1) = &**m28662_1_1 && (m28662_1_1_r_0 == &Text::lit("Ok")) && (m28662_1_1_r_1.len() == 1) && let Some(v_p5) = index(m28662_1_1_r_1, &Nat::from(0u32)) {
            break 'm28662 {
                let (st_p6, cp2_p7) = crate::emit::cpp::stmts::cpp_statements_cp(cp_p0, dos_p4);
                crate::emit::cpp::templates::items::stmt_expr(&st_p6, &Text::from(format!("Expected<std::decay_t<decltype({})>, std::decay_t<decltype({})>>({})", &cpp_expr(&cp2_p7, &v_p5), &cpp_expr(&cp2_p7, y_p2), &cpp_expr(&cp2_p7, &v_p5))))
            };
        }
        cpp_expr(cp_p0, x_p1)
    }
}

/// The step machine of `OkBranch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OkBranch: unbounded fn Cp, Ex, Ex -> Text
/// ```
pub struct OkBranch {
    pub cp_p0: crate::emit::cpp::Cp,
    pub x_p1: crate::lower::model::Ex,
    pub y_p2: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for OkBranch {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let x_p1 = &self.x_p1;
        let y_p2 = &self.y_p2;
        'm28662: {
            if let crate::lower::model::Ex::XCtor(m28662_0_0, m28662_0_1) = x_p1 && (m28662_0_0 == &Text::lit("Ok")) && (m28662_0_1.len() == 1) && let Some(v_p3) = index(m28662_0_1, &Nat::from(0u32)) {
                break 'm28662 {
                    let cp_p0 = cp_p0.clone();
                    let y_p2 = y_p2.clone();
                    call_then(start_cpp_expr(cp_p0.clone(), v_p3.clone()), move |cpp_expr_28727: Text| call_then(start_cpp_expr(cp_p0.clone(), y_p2.clone()), move |cpp_expr_28768: Text| call_then(start_cpp_expr(cp_p0.clone(), v_p3.clone()), move |cpp_expr_28787: Text| prism_rtl::Turn::Finished(Text::from(format!("Expected<std::decay_t<decltype({})>, std::decay_t<decltype({})>>({})", &cpp_expr_28727, &cpp_expr_28768, &cpp_expr_28787))))))
                };
            }
            if let crate::lower::model::Ex::XBlock(dos_p4, m28662_1_1) = x_p1 && let crate::lower::model::Ex::XCtor(m28662_1_1_r_0, m28662_1_1_r_1) = &**m28662_1_1 && (m28662_1_1_r_0 == &Text::lit("Ok")) && (m28662_1_1_r_1.len() == 1) && let Some(v_p5) = index(m28662_1_1_r_1, &Nat::from(0u32)) {
                break 'm28662 {
                    let cp_p0 = cp_p0.clone();
                    let dos_p4 = dos_p4.clone();
                    let y_p2 = y_p2.clone();
                    call_then(crate::emit::cpp::stmts::start_cpp_statements_cp(cp_p0.clone(), dos_p4.clone()), move |cpp_statements_cp_28867: (Text, crate::emit::cpp::Cp)| {
                        let (st_p6, cp2_p7) = cpp_statements_cp_28867;
                        call_then(start_cpp_expr(cp2_p7.clone(), v_p5.clone()), move |cpp_expr_28945: Text| call_then(start_cpp_expr(cp2_p7.clone(), y_p2.clone()), move |cpp_expr_28987: Text| call_then(start_cpp_expr(cp2_p7.clone(), v_p5.clone()), move |cpp_expr_29007: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::stmt_expr(&st_p6, &Text::from(format!("Expected<std::decay_t<decltype({})>, std::decay_t<decltype({})>>({})", &cpp_expr_28945, &cpp_expr_28987, &cpp_expr_29007)))))))
                    })
                };
            }
            prism_rtl::Turn::More(Rc::new(CppExpr { cp_p0: cp_p0.clone(), x_p1: x_p1.clone() }))
        }
    }
}

/// `Start OkBranch, x`: what the function value is when passed to `@Run`.
pub fn start_ok_branch(cp_p0: crate::emit::cpp::Cp, x_p1: crate::lower::model::Ex, y_p2: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(OkBranch { cp_p0, x_p1, y_p2 })
}

/// ```prism
/// CppClosure: unbounded fn Cp, Bool, [Pa], Ex -> Text
/// ```
pub fn cpp_closure(cp0_p0: &crate::emit::cpp::Cp, mv_p1: &bool, ps_p2: &Array<crate::lower::model::Pa>, body_p3: &crate::lower::model::Ex) -> Text {
    let names_p4 = crate::emit::cpp::patterns::concat2(&run_to_end(each_job(ps_p2.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
        let p_pb = p0;
        prism_rtl::Turn::More(Rc::new(crate::emit::cpp::stmts::PatNames { p_p0: p_pb.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>)));
    let cp_p5 = fold(ps_p2, &crate::emit::cpp::stmts::unbind(&crate::emit::cpp::stmts::captured(cp0_p0), &names_p4), &(|c_pc: &crate::emit::cpp::Cp, p_pd: &crate::lower::model::Pa| 'm29644: {
        if let crate::lower::model::Pa::PaMut(n_pe) = p_pd {
            break 'm29644 crate::emit::cpp::stmts::owning(c_pc, n_pe);
        }
        if let crate::lower::model::Pa::PaTyped(m29644_1_0, _) = p_pd && let crate::lower::model::Pa::PaMut(n_pf) = &**m29644_1_0 {
            break 'm29644 crate::emit::cpp::stmts::owning(c_pc, n_pf);
        }
        c_pc.clone()
    }));
    let params_p6 = crate::syntax::lexer::chars::join(&run_to_end(each_job(crate::check::errors::range0(&len(ps_p2)), {
        let cp_p5 = cp_p5.clone();
        let ps_p2 = ps_p2.clone();
        Rc::new(move |p0: Nat| {
            let cp_p5 = cp_p5.clone();
            let ps_p2 = ps_p2.clone();
            entered(once_job(move || {
                let i_pg = p0;
                prism_rtl::Turn::More(Rc::new(ClosureParam { cp_p0: cp_p5.clone(), pa1: or(&index(&ps_p2, &i_pg), &crate::lower::model::Pa::PaWild), i_p3: i_pg.clone() }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "));
    let binds_p7 = concat(&run_to_end(each_job(crate::check::errors::range0(&len(ps_p2)), {
        let cp_p5 = cp_p5.clone();
        let ps_p2 = ps_p2.clone();
        Rc::new(move |p0: Nat| {
            let cp_p5 = cp_p5.clone();
            let ps_p2 = ps_p2.clone();
            entered(once_job(move || {
                let i_ph = p0;
                prism_rtl::Turn::More(Rc::new(ClosureBinds { cp_p0: cp_p5.clone(), pa1: or(&index(&ps_p2, &i_ph), &crate::lower::model::Pa::PaWild), i_p3: i_ph.clone() }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let b_p8 = cpp_expr(&cp_p5, body_p3);
    let moved_p9 = if *mv_p1 {
        filter(&cp0_p0.move_captures, &(|n_pi: &Text| (or(&get(&cp0_p0.owned, n_pi), &false) && !crate::emit::cpp::in_list(&names_p4, n_pi)) && crate::emit::cpp::stmts::cpp_mentions(&b_p8, &crate::emit::cpp::stmts::var_name(cp0_p0, n_pi))))
    } else {
        Array::new()
    };
    let capture_pa = crate::syntax::lexer::chars::join(&append(&Array::from(vec![if *mv_p1 { Text::lit("=") } else { Text::lit("&") }]), &each(&moved_p9, &(|n_pj: &Text| Text::from(format!("{} = std::move({})", &crate::emit::cpp::stmts::var_name(cp0_p0, n_pj), &crate::emit::cpp::stmts::var_name(cp0_p0, n_pj)))))), &Text::lit(", "));
    let (ret_pk, value_pl) = match body_p3 {
        crate::lower::model::Ex::XRef(_) => (Text::lit(" -> decltype(auto)"), Text::from(format!("({})", &b_p8))),
        crate::lower::model::Ex::XRefMut(_) => (Text::lit(" -> decltype(auto)"), Text::from(format!("({})", &b_p8))),
        _ => (Text::lit(""), b_p8.clone()),
    };
    if (&binds_p7 == &Text::lit("")) && !crate::syntax::lexer::chars::contains(&b_p8, &Text::lit("\n")) {
        Text::from(format!("[{}]({}){} {{ return {}; }}", &capture_pa, &params_p6, &ret_pk, &value_pl))
    } else {
        crate::emit::cpp::templates::items::lambda(&capture_pa, &Text::from(format!("{}){}", &params_p6, &ret_pk)), &Text::from(format!("{}return {};", &binds_p7, &value_pl)))
    }
}

/// The step machine of `CppClosure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppClosure: unbounded fn Cp, Bool, [Pa], Ex -> Text
/// ```
pub struct CppClosure {
    pub cp0_p0: crate::emit::cpp::Cp,
    pub mv_p1: bool,
    pub ps_p2: Array<crate::lower::model::Pa>,
    pub body_p3: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppClosure {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp0_p0 = &self.cp0_p0;
        let mv_p1 = &self.mv_p1;
        let ps_p2 = &self.ps_p2;
        let body_p3 = &self.body_p3;
        let body_p3 = body_p3.clone();
        let cp0_p0 = cp0_p0.clone();
        let mv_p1 = *mv_p1;
        let ps_p2 = ps_p2.clone();
        call_value(each_job(ps_p2.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
            let p_pb = p0;
            prism_rtl::Turn::More(Rc::new(crate::emit::cpp::stmts::PatNames { p_p0: p_pb.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_29556: Array<Array<Text>>| {
            let names_p4 = crate::emit::cpp::patterns::concat2(&each_29556);
            let cp_p5 = fold(&ps_p2, &crate::emit::cpp::stmts::unbind(&crate::emit::cpp::stmts::captured(&cp0_p0), &names_p4), &(|c_pc: &crate::emit::cpp::Cp, p_pd: &crate::lower::model::Pa| 'm29644: {
                if let crate::lower::model::Pa::PaMut(n_pe) = p_pd {
                    break 'm29644 crate::emit::cpp::stmts::owning(c_pc, n_pe);
                }
                if let crate::lower::model::Pa::PaTyped(m29644_1_0, _) = p_pd && let crate::lower::model::Pa::PaMut(n_pf) = &**m29644_1_0 {
                    break 'm29644 crate::emit::cpp::stmts::owning(c_pc, n_pf);
                }
                c_pc.clone()
            }));
            call_value(each_job(crate::check::errors::range0(&len(&ps_p2)), {
                let cp_p5 = cp_p5.clone();
                let ps_p2 = ps_p2.clone();
                Rc::new(move |p0: Nat| {
                    let cp_p5 = cp_p5.clone();
                    let ps_p2 = ps_p2.clone();
                    entered(once_job(move || {
                        let i_pg = p0;
                        prism_rtl::Turn::More(Rc::new(ClosureParam { cp_p0: cp_p5.clone(), pa1: or(&index(&ps_p2, &i_pg), &crate::lower::model::Pa::PaWild), i_p3: i_pg.clone() }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_29773: Array<Text>| {
                let params_p6 = crate::syntax::lexer::chars::join(&each_29773, &Text::lit(", "));
                call_value(each_job(crate::check::errors::range0(&len(&ps_p2)), {
                    let cp_p5 = cp_p5.clone();
                    let ps_p2 = ps_p2.clone();
                    Rc::new(move |p0: Nat| {
                        let cp_p5 = cp_p5.clone();
                        let ps_p2 = ps_p2.clone();
                        entered(once_job(move || {
                            let i_ph = p0;
                            prism_rtl::Turn::More(Rc::new(ClosureBinds { cp_p0: cp_p5.clone(), pa1: or(&index(&ps_p2, &i_ph), &crate::lower::model::Pa::PaWild), i_p3: i_ph.clone() }))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_29872: Array<Text>| {
                    let binds_p7 = concat(&each_29872);
                    call_then(start_cpp_expr(cp_p5.clone(), body_p3.clone()), move |cpp_expr_29953: Text| {
                        let b_p8 = cpp_expr_29953;
                        let moved_p9 = if mv_p1 {
                            filter(&cp0_p0.move_captures, &(|n_pi: &Text| (or(&get(&cp0_p0.owned, n_pi), &false) && !crate::emit::cpp::in_list(&names_p4, n_pi)) && crate::emit::cpp::stmts::cpp_mentions(&b_p8, &crate::emit::cpp::stmts::var_name(&cp0_p0, n_pi))))
                        } else {
                            Array::new()
                        };
                        let capture_pa = crate::syntax::lexer::chars::join(&append(&Array::from(vec![if mv_p1 { Text::lit("=") } else { Text::lit("&") }]), &each(&moved_p9, &(|n_pj: &Text| Text::from(format!("{} = std::move({})", &crate::emit::cpp::stmts::var_name(&cp0_p0, n_pj), &crate::emit::cpp::stmts::var_name(&cp0_p0, n_pj)))))), &Text::lit(", "));
                        let (ret_pk, value_pl) = match &body_p3 {
                            crate::lower::model::Ex::XRef(_) => (Text::lit(" -> decltype(auto)"), Text::from(format!("({})", &b_p8))),
                            crate::lower::model::Ex::XRefMut(_) => (Text::lit(" -> decltype(auto)"), Text::from(format!("({})", &b_p8))),
                            _ => (Text::lit(""), b_p8.clone()),
                        };
                        if (&binds_p7 == &Text::lit("")) && !crate::syntax::lexer::chars::contains(&b_p8, &Text::lit("\n")) {
                            prism_rtl::Turn::Finished(Text::from(format!("[{}]({}){} {{ return {}; }}", &capture_pa, &params_p6, &ret_pk, &value_pl)))
                        } else {
                            prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::lambda(&capture_pa, &Text::from(format!("{}){}", &params_p6, &ret_pk)), &Text::from(format!("{}return {};", &binds_p7, &value_pl))))
                        }
                    })
                })
            })
        })
    }
}

/// `Start CppClosure, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_closure(cp0_p0: crate::emit::cpp::Cp, mv_p1: bool, ps_p2: Array<crate::lower::model::Pa>, body_p3: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppClosure { cp0_p0, mv_p1, ps_p2, body_p3 })
}

/// ```prism
/// ClosureParam: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub fn closure_param(cp_p0: &crate::emit::cpp::Cp, pa1: &crate::lower::model::Pa, i_p3: &Nat) -> Text {
    'c: {
        if let crate::lower::model::Pa::PaTyped(c0_1_0, t_p2) = pa1 && let crate::lower::model::Pa::PaBind(n_p1) = &**c0_1_0 {
            break 'c Text::from(format!("{} {}", &param_type(cp_p0, t_p2), &crate::emit::cpp::cpp_id(n_p1)));
        }
        if let crate::lower::model::Pa::PaTyped(c1_1_0, t_p6) = pa1 && let crate::lower::model::Pa::PaMut(n_p5) = &**c1_1_0 {
            break 'c Text::from(format!("{} {}", &crate::emit::cpp::cpp_type(cp_p0, &unref(t_p6)), &crate::emit::cpp::cpp_id(n_p5)));
        }
        if let crate::lower::model::Pa::PaTyped(p_p9, t_pa) = pa1 {
            break 'c Text::from(format!("{} _p{}", &param_type(cp_p0, t_pa), i_p3));
        }
        if let crate::lower::model::Pa::PaBind(n_pd) = pa1 {
            break 'c Text::from(format!("auto&& {}", &crate::emit::cpp::cpp_id(n_pd)));
        }
        if let crate::lower::model::Pa::PaMut(n_pg) = pa1 {
            break 'c Text::from(format!("auto {}", &crate::emit::cpp::cpp_id(n_pg)));
        }
        if let crate::lower::model::Pa::PaWild = pa1 {
            break 'c Text::lit("const auto&");
        }
        if let p_pl = pa1 {
            break 'c Text::from(format!("const auto& _p{}", i_p3));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `ClosureParam`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosureParam: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub struct ClosureParam {
    pub cp_p0: crate::emit::cpp::Cp,
    pub pa1: crate::lower::model::Pa,
    pub i_p3: Nat,
}

impl prism_rtl::Job<Text> for ClosureParam {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let pa1 = &self.pa1;
        let i_p3 = &self.i_p3;
        'j: {
            if let crate::lower::model::Pa::PaTyped(j0_1_0, t_p2) = pa1 && let crate::lower::model::Pa::PaBind(n_p1) = &**j0_1_0 {
                break 'j {
                    let cp_p0 = cp_p0.clone();
                    let n_p1 = n_p1.clone();
                    let t_p2 = t_p2.clone();
                    call_then(start_param_type(cp_p0.clone(), t_p2.clone()), move |param_type_30702: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_30702, &crate::emit::cpp::cpp_id(&n_p1)))))
                };
            }
            if let crate::lower::model::Pa::PaTyped(j1_1_0, t_p6) = pa1 && let crate::lower::model::Pa::PaMut(n_p5) = &**j1_1_0 {
                break 'j {
                    let cp_p0 = cp_p0.clone();
                    let n_p5 = n_p5.clone();
                    let t_p6 = t_p6.clone();
                    call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), unref(&t_p6)), move |cpp_type_30780: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_30780, &crate::emit::cpp::cpp_id(&n_p5)))))
                };
            }
            if let crate::lower::model::Pa::PaTyped(p_p9, t_pa) = pa1 {
                break 'j {
                    let cp_p0 = cp_p0.clone();
                    let i_p3 = i_p3.clone();
                    let t_pa = t_pa.clone();
                    call_then(start_param_type(cp_p0.clone(), t_pa.clone()), move |param_type_30856: Text| prism_rtl::Turn::Finished(Text::from(format!("{} _p{}", &param_type_30856, &i_p3))))
                };
            }
            if let crate::lower::model::Pa::PaBind(n_pd) = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::from(format!("auto&& {}", &crate::emit::cpp::cpp_id(n_pd))));
            }
            if let crate::lower::model::Pa::PaMut(n_pg) = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::from(format!("auto {}", &crate::emit::cpp::cpp_id(n_pg))));
            }
            if let crate::lower::model::Pa::PaWild = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::lit("const auto&"));
            }
            if let p_pl = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::from(format!("const auto& _p{}", i_p3)));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start ClosureParam, x`: what the function value is when passed to `@Run`.
pub fn start_closure_param(cp_p0: crate::emit::cpp::Cp, pa1: crate::lower::model::Pa, i_p3: Nat) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ClosureParam { cp_p0, pa1, i_p3 })
}

/// ```prism
/// ClosureBinds: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub fn closure_binds(cp_p0: &crate::emit::cpp::Cp, pa1: &crate::lower::model::Pa, i_p3: &Nat) -> Text {
    'c: {
        if let crate::lower::model::Pa::PaTyped(c0_1_0, t_p2) = pa1 && let crate::lower::model::Pa::PaBind(n_p1) = &**c0_1_0 {
            break 'c Text::lit("");
        }
        if let crate::lower::model::Pa::PaTyped(c1_1_0, t_p6) = pa1 && let crate::lower::model::Pa::PaMut(n_p5) = &**c1_1_0 {
            break 'c Text::lit("");
        }
        if let crate::lower::model::Pa::PaTyped(p_p9, t_pa) = pa1 {
            break 'c closure_binds(cp_p0, &**p_p9, i_p3);
        }
        if let crate::lower::model::Pa::PaBind(n_pd) = pa1 {
            break 'c Text::lit("");
        }
        if let crate::lower::model::Pa::PaMut(n_pg) = pa1 {
            break 'c Text::lit("");
        }
        if let crate::lower::model::Pa::PaWild = pa1 {
            break 'c Text::lit("");
        }
        if let p_pl = pa1 {
            break 'c concat(&each(&crate::emit::cpp::patterns::pat_binds(cp_p0, p_pl, &Text::from(format!("_p{}", i_p3))), &(|b_pn: &Text| Text::from(format!("{}\n", b_pn)))));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `ClosureBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosureBinds: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub struct ClosureBinds {
    pub cp_p0: crate::emit::cpp::Cp,
    pub pa1: crate::lower::model::Pa,
    pub i_p3: Nat,
}

impl prism_rtl::Job<Text> for ClosureBinds {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let pa1 = &self.pa1;
        let i_p3 = &self.i_p3;
        'j: {
            if let crate::lower::model::Pa::PaTyped(j0_1_0, t_p2) = pa1 && let crate::lower::model::Pa::PaBind(n_p1) = &**j0_1_0 {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let crate::lower::model::Pa::PaTyped(j1_1_0, t_p6) = pa1 && let crate::lower::model::Pa::PaMut(n_p5) = &**j1_1_0 {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let crate::lower::model::Pa::PaTyped(p_p9, t_pa) = pa1 {
                break 'j prism_rtl::Turn::More(Rc::new(ClosureBinds { cp_p0: cp_p0.clone(), pa1: (**p_p9).clone(), i_p3: i_p3.clone() }));
            }
            if let crate::lower::model::Pa::PaBind(n_pd) = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let crate::lower::model::Pa::PaMut(n_pg) = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let crate::lower::model::Pa::PaWild = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let p_pl = pa1 {
                break 'j {
                    let cp_p0 = cp_p0.clone();
                    let i_p3 = i_p3.clone();
                    let p_pl = p_pl.clone();
                    call_then(crate::emit::cpp::patterns::start_pat_binds(cp_p0.clone(), p_pl.clone(), Text::from(format!("_p{}", &i_p3))), move |pat_binds_31446: Array<Text>| prism_rtl::Turn::Finished(concat(&each(&pat_binds_31446, &(|b_pn: &Text| Text::from(format!("{}\n", b_pn)))))))
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start ClosureBinds, x`: what the function value is when passed to `@Run`.
pub fn start_closure_binds(cp_p0: crate::emit::cpp::Cp, pa1: crate::lower::model::Pa, i_p3: Nat) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ClosureBinds { cp_p0, pa1, i_p3 })
}

/// ```prism
/// Unref: fn OutTy -> OutTy
/// ```
pub fn unref(out_ty0: &crate::lower::model::OutTy) -> crate::lower::model::OutTy {
    match out_ty0 {
        crate::lower::model::OutTy::OutRef(t_p0) => (**t_p0).clone(),
        t_p1 => t_p1.clone(),
    }
}

/// ```prism
/// ParamType: unbounded fn Cp, OutTy -> Text
/// ```
pub fn param_type(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::OutTy) -> Text {
    match t_p1 {
        crate::lower::model::OutTy::OutRef(_) => crate::emit::cpp::cpp_type(cp_p0, t_p1),
        crate::lower::model::OutTy::OutSlice(_) => crate::emit::cpp::cpp_type(cp_p0, t_p1),
        crate::lower::model::OutTy::OutUnit => Text::lit("Unit"),
        _ => crate::emit::cpp::cpp_type(cp_p0, t_p1),
    }
}

/// The step machine of `ParamType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParamType: unbounded fn Cp, OutTy -> Text
/// ```
pub struct ParamType {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for ParamType {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        match t_p1 {
            crate::lower::model::OutTy::OutRef(_) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::CppType { cp_p0: cp_p0.clone(), t_p1: t_p1.clone() })),
            crate::lower::model::OutTy::OutSlice(_) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::CppType { cp_p0: cp_p0.clone(), t_p1: t_p1.clone() })),
            crate::lower::model::OutTy::OutUnit => prism_rtl::Turn::Finished(Text::lit("Unit")),
            _ => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::CppType { cp_p0: cp_p0.clone(), t_p1: t_p1.clone() })),
        }
    }
}

/// `Start ParamType, x`: what the function value is when passed to `@Run`.
pub fn start_param_type(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ParamType { cp_p0, t_p1 })
}
