//! The module `Emit.Cpp.Expr`, from `target/bootstrap/src/prismc/emit/cpp/expr.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// CppLoose: fn Ex -> Bool
/// ```
pub fn cpp_loose_f(x_p0: &crate::lower::model::Ex) -> bool {
    match x_p0 {
        crate::lower::model::Ex::XBlock(m1173_0_0, inner_p1) if (m1173_0_0.len() == 0) => cpp_loose_f(&**inner_p1),
        crate::lower::model::Ex::XBin(_, _, _) => true,
        crate::lower::model::Ex::XUnary(_, _) => true,
        crate::lower::model::Ex::XIf(_, _, _) => true,
        crate::lower::model::Ex::XRef(y_p2) => cpp_loose_f(&**y_p2),
        crate::lower::model::Ex::XRefMut(y_p3) => cpp_loose_f(&**y_p3),
        crate::lower::model::Ex::XClone(y_p4) => cpp_loose_f(&**y_p4),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CppTight: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_tight_f(cp_p0: &crate::emit::cpp::Cp, x_p1: &crate::lower::model::Ex) -> crate::prelude::Text {
    if cpp_loose_f(x_p1) {
        crate::prelude::Text::from(format!("({})", &cpp_expr_f(cp_p0, x_p1)))
    } else {
        starred_f(&cpp_expr_f(cp_p0, x_p1))
    }
}

/// The step machine of `CppTight`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppTight: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppTight {
    pub cp_p0: crate::emit::cpp::Cp,
    pub x_p1: crate::lower::model::Ex,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppTight {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let x_p1 = &self.x_p1;
        if cpp_loose_f(x_p1) {
            {
                let cp_p0x = cp_p0.clone();
                let x_p1x = x_p1.clone();
                crate::prelude::call_then(start_cpp_expr_f(cp_p0x.clone(), x_p1x.clone()), move |cpp_expr_f_1500: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("({})", &cpp_expr_f_1500))))
            }
        } else {
            {
                let cp_p0x = cp_p0.clone();
                let x_p1x = x_p1.clone();
                crate::prelude::call_then(start_cpp_expr_f(cp_p0x.clone(), x_p1x.clone()), move |cpp_expr_f_1532: crate::prelude::Text| ::prism_rtl::Turn::Finished(starred_f(&cpp_expr_f_1532)))
            }
        }
    }
}

/// `Start CppTight, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_tight_f(cp_p0: crate::emit::cpp::Cp, x_p1: crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppTight { cp_p0, x_p1 })
}

/// ```prism
/// Starred: fn Text -> Text
/// ```
pub fn starred_f(t_p0: &crate::prelude::Text) -> crate::prelude::Text {
    if crate::syntax::lexer::chars::has_prefix_f(t_p0, &crate::prelude::Text::lit("*")) {
        crate::prelude::Text::from(format!("({})", t_p0))
    } else {
        t_p0.clone()
    }
}

/// ```prism
/// CppTightPlace: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_tight_place_f(cp_p0: &crate::emit::cpp::Cp, x_p1: &crate::lower::model::Ex) -> crate::prelude::Text {
    if cpp_loose_f(x_p1) {
        crate::prelude::Text::from(format!("({})", &cpp_place_f(cp_p0, x_p1)))
    } else {
        starred_f(&cpp_place_f(cp_p0, x_p1))
    }
}

/// The step machine of `CppTightPlace`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppTightPlace: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppTightPlace {
    pub cp_p0: crate::emit::cpp::Cp,
    pub x_p1: crate::lower::model::Ex,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppTightPlace {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let x_p1 = &self.x_p1;
        if cpp_loose_f(x_p1) {
            {
                let cp_p0x = cp_p0.clone();
                let x_p1x = x_p1.clone();
                crate::prelude::call_then(start_cpp_place_f(cp_p0x.clone(), x_p1x.clone()), move |cpp_place_f_1889: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("({})", &cpp_place_f_1889))))
            }
        } else {
            {
                let cp_p0x = cp_p0.clone();
                let x_p1x = x_p1.clone();
                crate::prelude::call_then(start_cpp_place_f(cp_p0x.clone(), x_p1x.clone()), move |cpp_place_f_1922: crate::prelude::Text| ::prism_rtl::Turn::Finished(starred_f(&cpp_place_f_1922)))
            }
        }
    }
}

/// `Start CppTightPlace, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_tight_place_f(cp_p0: crate::emit::cpp::Cp, x_p1: crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppTightPlace { cp_p0, x_p1 })
}

/// ```prism
/// CppPlace: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_place_f(cp_p0: &crate::emit::cpp::Cp, ex1: &crate::lower::model::Ex) -> crate::prelude::Text {
    match ex1 {
        crate::lower::model::Ex::XVar(n_p1) => crate::emit::cpp::stmts::var_name_f(cp_p0, n_p1),
        x_p3 => cpp_expr_f(cp_p0, x_p3),
    }
}

/// The step machine of `CppPlace`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppPlace: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppPlace {
    pub cp_p0: crate::emit::cpp::Cp,
    pub ex1: crate::lower::model::Ex,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppPlace {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let ex1 = &self.ex1;
        match ex1 {
            crate::lower::model::Ex::XVar(n_p1) => ::prism_rtl::Turn::Finished(crate::emit::cpp::stmts::var_name_f(cp_p0, n_p1)),
            x_p3 => ::prism_rtl::Turn::More(::std::rc::Rc::new(CppExpr { cp_p0: cp_p0.clone(), x_p1: x_p3.clone() })),
        }
    }
}

/// `Start CppPlace, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_place_f(cp_p0: crate::emit::cpp::Cp, ex1: crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppPlace { cp_p0, ex1 })
}

/// ```prism
/// CppVar: fn Cp, Text -> Text
/// ```
pub fn cpp_var_f(cp_p0: &crate::emit::cpp::Cp, n_p1: &crate::prelude::Text) -> crate::prelude::Text {
    if crate::prelude::or(&crate::prelude::get(&cp_p0.owned_p, n_p1), &false) {
        crate::prelude::Text::from(format!("::std::move({})", &crate::emit::cpp::stmts::var_name_f(cp_p0, n_p1)))
    } else {
        crate::emit::cpp::stmts::var_name_f(cp_p0, n_p1)
    }
}

/// ```prism
/// CppArgs: unbounded fn Cp, [Ex] -> Text
/// ```
pub fn cpp_args_f(cp_p0: &crate::emit::cpp::Cp, xs_p1: &crate::prelude::Array<crate::lower::model::Ex>) -> crate::prelude::Text {
    crate::syntax::lexer::chars::join_f(&cpp_arg_list_f(cp_p0, xs_p1), &crate::prelude::Text::lit(", "))
}

/// The step machine of `CppArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppArgs: unbounded fn Cp, [Ex] -> Text
/// ```
pub struct CppArgs {
    pub cp_p0: crate::emit::cpp::Cp,
    pub xs_p1: crate::prelude::Array<crate::lower::model::Ex>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppArgs {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let xs_p1 = &self.xs_p1;
        let cp_p0x = cp_p0.clone();
        let xs_p1x = xs_p1.clone();
        crate::prelude::call_then(start_cpp_arg_list_f(cp_p0x.clone(), xs_p1x.clone()), move |cpp_arg_list_f_2812: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join_f(&cpp_arg_list_f_2812, &crate::prelude::Text::lit(", "))))
    }
}

/// `Start CppArgs, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_args_f(cp_p0: crate::emit::cpp::Cp, xs_p1: crate::prelude::Array<crate::lower::model::Ex>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppArgs { cp_p0, xs_p1 })
}

/// ```prism
/// CppArgList: unbounded fn Cp, [Ex] -> [Text]
/// ```
pub fn cpp_arg_list_f(cp_p0: &crate::emit::cpp::Cp, xs_p1: &crate::prelude::Array<crate::lower::model::Ex>) -> crate::prelude::Array<crate::prelude::Text> {
    let texts_p2 = crate::prelude::run_to_end(crate::prelude::each_job(xs_p1.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::Ex| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let x_p3 = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(CppExpr { cp_p0: cp_p0xy.clone(), x_p1: x_p3.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    }));
    crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(xs_p1)), {
        let xs_p1x = xs_p1.clone();
        let cp_p0x = cp_p0.clone();
        let texts_p2x = texts_p2.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
            let xs_p1xy = xs_p1x.clone();
            let cp_p0xy = cp_p0x.clone();
            let texts_p2xy = texts_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_p4 = p0;
                match crate::prelude::or(&crate::prelude::index(&xs_p1xy, &i_p4), &crate::lower::model::Ex::XUnit) {
                    crate::lower::model::Ex::XVar(n_p5) => crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&xs_p1xy)), false, {
                        let i_p4x = i_p4.clone();
                        let xs_p1xyx = xs_p1xy.clone();
                        let n_p5x = n_p5.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::prelude::Nat)| {
                            let i_p4xy = i_p4x.clone();
                            let xs_p1xyxy = xs_p1xyx.clone();
                            let n_p5xy = n_p5x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let f_p6 = p0;
                                let j_p7 = p1;
                                if f_p6 {
                                    ::prism_rtl::Turn::Finished(true)
                                } else {
                                    if &j_p7 != &i_p4xy {
                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::model::ExReads { x_p0: crate::prelude::or(&crate::prelude::index(&xs_p1xyxy, &j_p7), &crate::lower::model::Ex::XUnit), n_p1: n_p5xy.clone() }))
                                    } else {
                                        ::prism_rtl::Turn::Finished(false)
                                    }
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                    }), move |fold_3023: bool| if fold_3023 {
                        ::prism_rtl::Turn::Finished(crate::emit::cpp::stmts::var_name_f(&cp_p0xy, &n_p5))
                    } else {
                        ::prism_rtl::Turn::Finished(crate::prelude::or(&crate::prelude::index(&texts_p2xy, &i_p4), &crate::prelude::Text::lit("")))
                    }),
                    _ => ::prism_rtl::Turn::Finished(crate::prelude::or(&crate::prelude::index(&texts_p2xy, &i_p4), &crate::prelude::Text::lit(""))),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    }))
}

/// The step machine of `CppArgList`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppArgList: unbounded fn Cp, [Ex] -> [Text]
/// ```
pub struct CppArgList {
    pub cp_p0: crate::emit::cpp::Cp,
    pub xs_p1: crate::prelude::Array<crate::lower::model::Ex>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for CppArgList {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let cp_p0 = &self.cp_p0;
        let xs_p1 = &self.xs_p1;
        let cp_p0x = cp_p0.clone();
        let xs_p1x = xs_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(xs_p1x.clone(), {
            let cp_p0xx = cp_p0x.clone();
            ::std::rc::Rc::new(move |p0: crate::lower::model::Ex| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let x_p3 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(CppExpr { cp_p0: cp_p0xxy.clone(), x_p1: x_p3.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
        }), move |each_2920: crate::prelude::Array<crate::prelude::Text>| {
            let texts_p2 = each_2920;
            crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&xs_p1x)), {
                let xs_p1xx = xs_p1x.clone();
                let cp_p0xx = cp_p0x.clone();
                let texts_p2x = texts_p2.clone();
                ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                    let xs_p1xxy = xs_p1xx.clone();
                    let cp_p0xxy = cp_p0xx.clone();
                    let texts_p2xy = texts_p2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let i_p4 = p0;
                        match crate::prelude::or(&crate::prelude::index(&xs_p1xxy, &i_p4), &crate::lower::model::Ex::XUnit) {
                            crate::lower::model::Ex::XVar(n_p5) => crate::prelude::call_value(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(&xs_p1xxy)), false, {
                                let i_p4x = i_p4.clone();
                                let xs_p1xxyx = xs_p1xxy.clone();
                                let n_p5x = n_p5.clone();
                                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::prelude::Nat)| {
                                    let i_p4xy = i_p4x.clone();
                                    let xs_p1xxyxy = xs_p1xxyx.clone();
                                    let n_p5xy = n_p5x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let f_p6 = p0;
                                        let j_p7 = p1;
                                        if f_p6 {
                                            ::prism_rtl::Turn::Finished(true)
                                        } else {
                                            if &j_p7 != &i_p4xy {
                                                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::model::ExReads { x_p0: crate::prelude::or(&crate::prelude::index(&xs_p1xxyxy, &j_p7), &crate::lower::model::Ex::XUnit), n_p1: n_p5xy.clone() }))
                                            } else {
                                                ::prism_rtl::Turn::Finished(false)
                                            }
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                            }), move |fold_3023: bool| if fold_3023 {
                                ::prism_rtl::Turn::Finished(crate::emit::cpp::stmts::var_name_f(&cp_p0xxy, &n_p5))
                            } else {
                                ::prism_rtl::Turn::Finished(crate::prelude::or(&crate::prelude::index(&texts_p2xy, &i_p4), &crate::prelude::Text::lit("")))
                            }),
                            _ => ::prism_rtl::Turn::Finished(crate::prelude::or(&crate::prelude::index(&texts_p2xy, &i_p4), &crate::prelude::Text::lit(""))),
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            }).cycle()
        })
    }
}

/// `Start CppArgList, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_arg_list_f(cp_p0: crate::emit::cpp::Cp, xs_p1: crate::prelude::Array<crate::lower::model::Ex>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(CppArgList { cp_p0, xs_p1 })
}

/// ```prism
/// CppExpr: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_expr_f(cp_p0: &crate::emit::cpp::Cp, x_p1: &crate::lower::model::Ex) -> crate::prelude::Text {
    'm3238: {
        if let crate::lower::model::Ex::XVar(n_p2) = x_p1 {
            break 'm3238 cpp_var_f(cp_p0, n_p2);
        }
        if let crate::lower::model::Ex::XPath(p_p3) = x_p1 {
            break 'm3238 path_value_f(cp_p0, p_p3);
        }
        if let crate::lower::model::Ex::XSelf = x_p1 {
            break 'm3238 crate::prelude::Text::lit("::prism_rtl::share(this)");
        }
        if let crate::lower::model::Ex::XCx = x_p1 {
            break 'm3238 crate::prelude::Text::lit("cx");
        }
        if let crate::lower::model::Ex::XConst(n_p4) = x_p1 {
            break 'm3238 n_p4.clone();
        }
        if let crate::lower::model::Ex::XUnit = x_p1 {
            break 'm3238 crate::prelude::Text::lit("crate::prelude::Unit{}");
        }
        if let crate::lower::model::Ex::XNone = x_p1 {
            break 'm3238 crate::prelude::Text::lit("::std::nullopt");
        }
        if let crate::lower::model::Ex::XBool(b_p5) = x_p1 {
            break 'm3238 if *b_p5 {
                crate::prelude::Text::lit("true")
            } else {
                crate::prelude::Text::lit("false")
            };
        }
        if let crate::lower::model::Ex::XNat(d_p6) = x_p1 {
            break 'm3238 if &crate::prelude::len_text(d_p6) <= &crate::prelude::Nat::from(9u32) {
                crate::prelude::Text::from(format!("crate::prelude::Nat({}u)", d_p6))
            } else {
                crate::prelude::Text::from(format!("*crate::prelude::Nat::from_int({})", &cpp_expr_f(cp_p0, &crate::lower::model::Ex::XInt(d_p6.clone()))))
            };
        }
        if let crate::lower::model::Ex::XInt(d_p7) = x_p1 {
            break 'm3238 if &crate::prelude::len_text(&(if crate::syntax::lexer::chars::has_prefix_f(d_p7, &crate::prelude::Text::lit("-")) {
                crate::syntax::lexer::chars::after_first_f(d_p7)
            } else {
                d_p7.clone()
            })) <= &crate::prelude::Nat::from(18u32) {
                crate::prelude::Text::from(format!("crate::prelude::Int({}ll)", d_p7))
            } else {
                crate::prelude::Text::from(format!("*crate::prelude::Int::parse(\"{}\")", d_p7))
            };
        }
        if let crate::lower::model::Ex::XByte(d_p8) = x_p1 {
            break 'm3238 crate::prelude::Text::from(format!("::std::uint8_t({})", d_p8));
        }
        if let crate::lower::model::Ex::XFloat(d_p9) = x_p1 {
            break 'm3238 crate::prelude::Text::from(format!("crate::prelude::Float{{{}}}", d_p9));
        }
        if let crate::lower::model::Ex::XDuration(n_pa) = x_p1 {
            break 'm3238 crate::prelude::Text::from(format!("crate::prelude::Duration{{{}}}", &cpp_nanos_f(n_pa)));
        }
        if let crate::lower::model::Ex::XIndex(n_pb) = x_p1 {
            break 'm3238 crate::prelude::Text::from(format!("{}u", n_pb));
        }
        if let crate::lower::model::Ex::XChar(c_pc) = x_p1 {
            break 'm3238 crate::prelude::Text::from(format!("U\'{}\'", &cpp_char_escape_f(c_pc)));
        }
        if let crate::lower::model::Ex::XStr(t_pd) = x_p1 {
            break 'm3238 cpp_string_f(t_pd);
        }
        if let crate::lower::model::Ex::XRegex(p_pe, f_pf) = x_p1 {
            break 'm3238 crate::prelude::Text::from(format!("([]() -> const crate::prelude::Regex& {{ static const crate::prelude::Regex r = crate::prelude::Regex::lit({}, {}); return r; }}())", &cpp_string_f(p_pe), &cpp_string_f(f_pf)));
        }
        if let crate::lower::model::Ex::XReplacement(p_pg, r_ph, f_pi) = x_p1 {
            break 'm3238 crate::prelude::Text::from(format!("([]() -> const crate::prelude::RegexReplacement& {{ static const crate::prelude::RegexReplacement r = crate::prelude::RegexReplacement::lit({}, {}, {}); return r; }}())", &cpp_string_f(p_pg), &cpp_string_f(f_pi), &cpp_string_f(r_ph)));
        }
        if let crate::lower::model::Ex::XRef(y_pj) = x_p1 {
            break 'm3238 cpp_place_f(cp_p0, &**y_pj);
        }
        if let crate::lower::model::Ex::XRefMut(y_pk) = x_p1 {
            break 'm3238 cpp_place_f(cp_p0, &**y_pk);
        }
        if let crate::lower::model::Ex::XDeref(y_pl) = x_p1 {
            break 'm3238 match ex_ty_o(cp_p0, &**y_pl) {
                ::std::option::Option::Some(crate::lower::model::OutTy::OutRc(_)) => crate::prelude::Text::from(format!("*{}", &cpp_tight_place_f(cp_p0, &**y_pl))),
                ::std::option::Option::Some(crate::lower::model::OutTy::OutRef(_)) => cpp_place_f(cp_p0, &**y_pl),
                _ => crate::prelude::Text::from(format!("::prism_rtl::deref({})", &cpp_place_f(cp_p0, &**y_pl))),
            };
        }
        if let crate::lower::model::Ex::XTarget(y_pm) = x_p1 {
            break 'm3238 cpp_place_f(cp_p0, &**y_pm);
        }
        if let crate::lower::model::Ex::XClone(y_pn) = x_p1 {
            break 'm3238 cpp_place_f(cp_p0, &**y_pn);
        }
        if let crate::lower::model::Ex::XWeak(y_po) = x_p1 {
            break 'm3238 crate::prelude::Text::from(format!("::prism_rtl::weaken({})", &cpp_expr_f(cp_p0, &**y_po)));
        }
        if let crate::lower::model::Ex::XUpgrade(y_pp) = x_p1 {
            break 'm3238 crate::prelude::Text::from(format!("::prism_rtl::upgrade({})", &cpp_expr_f(cp_p0, &**y_pp)));
        }
        if let crate::lower::model::Ex::XBreak(l_pq, y_pr) = x_p1 {
            break 'm3238 crate::prelude::Text::from(format!("({})", &crate::emit::cpp::patterns::cpp_break_f(cp_p0, l_pq, &**y_pr)));
        }
        if let crate::lower::model::Ex::XBreakLoop = x_p1 {
            break 'm3238 crate::prelude::Text::lit("({ break; })");
        }
        if let crate::lower::model::Ex::XLater(y_ps) = x_p1 {
            break 'm3238 crate::prelude::Text::from(format!("[=](crate::prelude::Cx& cx) -> crate::prelude::Done {{ {}; return {{}}; }}", &cpp_expr_f(&crate::emit::cpp::stmts::captured_f(cp_p0), &**y_ps)));
        }
        if let crate::lower::model::Ex::XFormatStr(parts_pt) = x_p1 {
            break 'm3238 cpp_format_f(cp_p0, parts_pt, &crate::prelude::Text::lit("::prism_rtl::str"));
        }
        if let crate::lower::model::Ex::XIsCase(y_pu, m3238_29_1) = x_p1 && (m3238_29_1.len() == 0) {
            break 'm3238 crate::prelude::Text::lit("false");
        }
        if let crate::lower::model::Ex::XIsCase(y_pv, cs_p10) = x_p1 {
            break 'm3238 crate::prelude::Text::from(format!("({})", &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(cs_p10.clone(), {
                let cp_p0x = cp_p0.clone();
                let y_pvx = (**y_pv).clone();
                ::std::rc::Rc::new(move |p0: crate::lower::model::Ref| {
                    let cp_p0xy = cp_p0x.clone();
                    let y_pvxy = y_pvx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let c_p11 = p0;
                        crate::prelude::call_then(start_cpp_tight_place_f(cp_p0xy.clone(), y_pvxy.clone()), move |cpp_tight_place_f_5692: crate::prelude::Text| ::prism_rtl::Turn::Finished(case_test_f(&cp_p0xy, &c_p11, &cpp_tight_place_f_5692)))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ref) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            })), &crate::prelude::Text::lit(" || "))));
        }
        if let crate::lower::model::Ex::XRefusal(what_p12) = x_p1 {
            break 'm3238 crate::prelude::Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::expr::lowering_refusal_p(), &crate::lower::expr::escape_f(what_p12)));
        }
        if let crate::lower::model::Ex::XUnreachable = x_p1 {
            break 'm3238 crate::prelude::Text::lit("throw ::prism_rtl::Panic(\"entered unreachable code\")");
        }
        if let crate::lower::model::Ex::XCall(f_p13, args_p14) = x_p1 {
            break 'm3238 cpp_call_f(cp_p0, f_p13, args_p14);
        }
        if let crate::lower::model::Ex::XCallAt(f_p15, tys_p16, args_p17) = x_p1 {
            break 'm3238 crate::prelude::Text::from(format!("{}<{}>({})", &free_call_path_f(cp_p0, f_p15), &crate::emit::cpp::cpp_types_f(cp_p0, tys_p16), &cpp_args_f(cp_p0, args_p17)));
        }
        if let crate::lower::model::Ex::XCallSelf(tr_p18, m_p19, self_p1a, args_p1b) = x_p1 {
            break 'm3238 crate::prelude::Text::from(format!("{}::{}_at<{}>::call({})", &free_call_path_f(cp_p0, tr_p18), &crate::emit::cpp::cpp_id_f(m_p19), &crate::emit::cpp::cpp_type_f(cp_p0, self_p1a), &cpp_args_f(cp_p0, args_p1b)));
        }
        if let crate::lower::model::Ex::XApply(f_p1c, args_p1d) = x_p1 {
            break 'm3238 crate::prelude::Text::from(format!("{}({})", &cpp_tight_place_f(cp_p0, &**f_p1c), &cpp_args_f(cp_p0, args_p1d)));
        }
        if let crate::lower::model::Ex::XMethod(r_p1e, m_p1f, args_p1g) = x_p1 {
            break 'm3238 cpp_method_f(cp_p0, &**r_p1e, m_p1f, args_p1g);
        }
        if let crate::lower::model::Ex::XBin(op_p1h, l_p1i, r_p1j) = x_p1 {
            break 'm3238 {
                let (lt_p1m, rt_p1n) = 'm6274: {
                    let scrutinee = &cpp_arg_list_f(cp_p0, &crate::prelude::Array::from(vec![(**l_p1i).clone(), (**r_p1j).clone()]));
                    if let m6274_0 = scrutinee && (m6274_0.len() == 2) && let ::std::option::Option::Some(a_p1k) = crate::prelude::index(m6274_0, &crate::prelude::Nat::from(0u32)) && let ::std::option::Option::Some(b_p1l) = crate::prelude::index(m6274_0, &crate::prelude::Nat::from(1u32)) {
                        break 'm6274 (a_p1k.clone(), b_p1l.clone());
                    }
                    (crate::prelude::Text::lit(""), crate::prelude::Text::lit(""))
                };
                crate::prelude::Text::from(format!("{} {} {}", &(if cpp_loose_f(&**l_p1i) {
                    crate::prelude::Text::from(format!("({})", &lt_p1m))
                } else {
                    lt_p1m.clone()
                }), &crate::lower::model::bin_op_text_f(op_p1h), &(if cpp_loose_f(&**r_p1j) {
                    crate::prelude::Text::from(format!("({})", &rt_p1n))
                } else {
                    rt_p1n.clone()
                })))
            };
        }
        if let crate::lower::model::Ex::XUnary(op_p1o, y_p1p) = x_p1 {
            break 'm3238 crate::prelude::Text::from(format!("{}{}", &crate::lower::model::un_op_text_f(op_p1o), &cpp_tight_f(cp_p0, &**y_p1p)));
        }
        if let crate::lower::model::Ex::XCtor(p_p1q, args_p1r) = x_p1 {
            break 'm3238 cpp_ctor_f(cp_p0, p_p1q, args_p1r);
        }
        if let crate::lower::model::Ex::XRecord(p_p1s, fs_p1t) = x_p1 {
            break 'm3238 cpp_record_f(cp_p0, p_p1s, fs_p1t);
        }
        if let crate::lower::model::Ex::XTuple(m3238_42_0) = x_p1 && (m3238_42_0.len() == 1) && let ::std::option::Option::Some(x_p1u) = crate::prelude::index(m3238_42_0, &crate::prelude::Nat::from(0u32)) {
            break 'm3238 crate::prelude::Text::from(format!("::std::make_tuple({})", &cpp_args_f(cp_p0, &crate::prelude::Array::from(vec![x_p1u.clone()]))));
        }
        if let crate::lower::model::Ex::XTuple(xs_p1v) = x_p1 {
            break 'm3238 crate::prelude::Text::from(format!("::std::tuple{{{}}}", &cpp_args_f(cp_p0, xs_p1v)));
        }
        if let crate::lower::model::Ex::XVec(m3238_44_0) = x_p1 && (m3238_44_0.len() == 0) {
            break 'm3238 crate::prelude::Text::lit("{}");
        }
        if let crate::lower::model::Ex::XVec(xs_p20) = x_p1 {
            break 'm3238 crate::prelude::Text::from(format!("::std::vector{{{}}}", &cpp_args_f(cp_p0, xs_p20)));
        }
        if let crate::lower::model::Ex::XText(t_p21) = x_p1 {
            break 'm3238 crate::prelude::Text::from(format!("crate::prelude::Text::lit({})", &cpp_string_f(t_p21)));
        }
        if let crate::lower::model::Ex::XFormat(parts_p22) = x_p1 {
            break 'm3238 if crate::prelude::fold(parts_p22, &true, &(|f_p23: &bool, p_p24: &crate::lower::model::Ex| *f_p23 && is_text_piece_f(p_p24))) {
                crate::prelude::Text::from(format!("crate::prelude::Text::lit({})", &cpp_string_f(&crate::prelude::concat(&crate::prelude::each(parts_p22, &(|p_p25: &crate::lower::model::Ex| text_piece_f(p_p25)))))))
            } else {
                cpp_format_f(cp_p0, parts_p22, &crate::prelude::Text::lit("::prism_rtl::cat"))
            };
        }
        if let crate::lower::model::Ex::XMatch(s_p26, arms_p27, fallback_p28, t_p29) = x_p1 {
            break 'm3238 crate::emit::cpp::patterns::cpp_match_f(cp_p0, &**s_p26, arms_p27, t_p29);
        }
        if let crate::lower::model::Ex::XChain(label_p2a, s_p2b, arms_p2c, t_p2d) = x_p1 {
            break 'm3238 crate::emit::cpp::patterns::cpp_match_f(cp_p0, &**s_p2b, arms_p2c, t_p2d);
        }
        if let crate::lower::model::Ex::XIf(c_p2e, t_p2f, e_p2g) = x_p1 {
            break 'm3238 cpp_if_f(cp_p0, &**c_p2e, &**t_p2f, &**e_p2g);
        }
        if let crate::lower::model::Ex::XBlock(m3238_51_0, e_p2h) = x_p1 && (m3238_51_0.len() == 0) {
            break 'm3238 cpp_expr_f(cp_p0, &**e_p2h);
        }
        if let crate::lower::model::Ex::XBlock(dos_p2i, e_p2j) = x_p1 {
            break 'm3238 {
                let (st_p2k, cp2_p2l) = crate::emit::cpp::stmts::cpp_statements_cp_f(cp_p0, dos_p2i);
                crate::emit::cpp::templates::items::stmt_expr_f(&st_p2k, &crate::emit::cpp::stmts::unvexed_f(&cpp_expr_f(&with_move_captures_f(&cp2_p2l, dos_p2i, &**e_p2j), &**e_p2j)))
            };
        }
        if let crate::lower::model::Ex::XLabeled(label_p2m, dos_p2n, e_p2o, t_p2p) = x_p1 {
            break 'm3238 crate::emit::cpp::patterns::cpp_labeled_f(cp_p0, label_p2m, dos_p2n, &**e_p2o, t_p2p);
        }
        if let crate::lower::model::Ex::XClosure(mv_p2q, ps_p2r, body_p2s) = x_p1 {
            break 'm3238 cpp_closure_f(cp_p0, mv_p2q, ps_p2r, &**body_p2s);
        }
        if let crate::lower::model::Ex::XTry(y_p2t) = x_p1 {
            break 'm3238 crate::prelude::Text::from(format!("TRY({})", &cpp_expr_f(cp_p0, &**y_p2t)));
        }
        if let crate::lower::model::Ex::XField(r_p2u, f_p2v) = x_p1 {
            break 'm3238 cpp_field_f(cp_p0, &**r_p2u, f_p2v);
        }
        if let crate::lower::model::Ex::XFieldOf(r_p30, _, f_p31) = x_p1 {
            break 'm3238 cpp_field_of_f(cp_p0, &**r_p30, f_p31);
        }
        if let crate::lower::model::Ex::XPart(r_p32, k_p33) = x_p1 {
            break 'm3238 crate::prelude::Text::from(format!("::std::get<{}>({})", k_p33, &as_value_f(cp_p0, &**r_p32)));
        }
        if let crate::lower::model::Ex::XDecode(t_p34, y_p35) = x_p1 {
            break 'm3238 crate::prelude::Text::from(format!("TRY(::prism_rtl::from_pod<{}>({}))", &crate::emit::cpp::cpp_type_f(cp_p0, t_p34), &cpp_expr_f(cp_p0, &**y_p35)));
        }
        if let crate::lower::model::Ex::XCast(y_p36, t_p37) = x_p1 {
            break 'm3238 crate::prelude::Text::from(format!("static_cast<{}>({})", &crate::emit::cpp::cpp_type_f(cp_p0, t_p37), &cpp_expr_f(cp_p0, &**y_p36)));
        }
        if let crate::lower::model::Ex::XTyped(y_p38, t_p39) = x_p1 {
            break 'm3238 match &**y_p38 {
                crate::lower::model::Ex::XCtor(p_p3a, args_p3b) if is_generic_case_f(cp_p0, p_p3a) => {
                    let tt_p3c = crate::emit::cpp::cpp_type_f(cp_p0, t_p39);
                    crate::prelude::Text::from(format!("{}(typename {}::{}{{{}}})", &tt_p3c, &tt_p3c, &crate::emit::cpp::case_id_of_f(p_p3a), &cpp_args_f(cp_p0, args_p3b)))
                },
                crate::lower::model::Ex::XPath(p_p3d) if is_generic_case_f(cp_p0, p_p3d) => {
                    let tt_p3e = crate::emit::cpp::cpp_type_f(cp_p0, t_p39);
                    crate::prelude::Text::from(format!("{}(typename {}::{}{{}})", &tt_p3e, &tt_p3e, &crate::emit::cpp::case_id_of_f(p_p3d)))
                },
                crate::lower::model::Ex::XRecord(p_p3f, fs_p3g) => cpp_record_as_f(cp_p0, p_p3f, fs_p3g, &crate::emit::cpp::cpp_type_f(cp_p0, t_p39)),
                _ => {
                    let e_p3h = cpp_expr_f(cp_p0, &**y_p38);
                    if (&e_p3h == &crate::prelude::Text::lit("{}")) || (&e_p3h == &crate::prelude::Text::lit("::std::nullopt")) {
                        crate::prelude::Text::from(format!("{}{{}}", &crate::emit::cpp::cpp_type_f(cp_p0, t_p39)))
                    } else {
                        if (is_ctor_f(&**y_p38, &crate::prelude::Text::lit("Ok")) || is_ctor_f(&**y_p38, &crate::prelude::Text::lit("Err"))) || is_ctor_f(&**y_p38, &crate::prelude::Text::lit("Some")) {
                            crate::prelude::Text::from(format!("{}({})", &crate::emit::cpp::cpp_type_f(cp_p0, t_p39), &e_p3h))
                        } else {
                            e_p3h.clone()
                        }
                    }
                },
                _ => unreachable!("no arm matched"),
            };
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `CppExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppExpr: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppExpr {
    pub cp_p0: crate::emit::cpp::Cp,
    pub x_p1: crate::lower::model::Ex,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppExpr {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let x_p1 = &self.x_p1;
        'm3238: {
            if let crate::lower::model::Ex::XVar(n_p2) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::Finished(cpp_var_f(cp_p0, n_p2));
            }
            if let crate::lower::model::Ex::XPath(p_p3) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::Finished(path_value_f(cp_p0, p_p3));
            }
            if let crate::lower::model::Ex::XSelf = x_p1 {
                break 'm3238 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("::prism_rtl::share(this)"));
            }
            if let crate::lower::model::Ex::XCx = x_p1 {
                break 'm3238 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("cx"));
            }
            if let crate::lower::model::Ex::XConst(n_p4) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::Finished(n_p4.clone());
            }
            if let crate::lower::model::Ex::XUnit = x_p1 {
                break 'm3238 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Unit{}"));
            }
            if let crate::lower::model::Ex::XNone = x_p1 {
                break 'm3238 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("::std::nullopt"));
            }
            if let crate::lower::model::Ex::XBool(b_p5) = x_p1 {
                break 'm3238 if *b_p5 {
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("true"))
                } else {
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("false"))
                };
            }
            if let crate::lower::model::Ex::XNat(d_p6) = x_p1 {
                break 'm3238 if &crate::prelude::len_text(d_p6) <= &crate::prelude::Nat::from(9u32) {
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Nat({}u)", d_p6)))
                } else {
                    {
                        let cp_p0x = cp_p0.clone();
                        let d_p6x = d_p6.clone();
                        crate::prelude::call_then(start_cpp_expr_f(cp_p0x.clone(), crate::lower::model::Ex::XInt(d_p6x.clone())), move |cpp_expr_f_3571: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("*crate::prelude::Nat::from_int({})", &cpp_expr_f_3571))))
                    }
                };
            }
            if let crate::lower::model::Ex::XInt(d_p7) = x_p1 {
                break 'm3238 if &crate::prelude::len_text(&(if crate::syntax::lexer::chars::has_prefix_f(d_p7, &crate::prelude::Text::lit("-")) {
                    crate::syntax::lexer::chars::after_first_f(d_p7)
                } else {
                    d_p7.clone()
                })) <= &crate::prelude::Nat::from(18u32) {
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Int({}ll)", d_p7)))
                } else {
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("*crate::prelude::Int::parse(\"{}\")", d_p7)))
                };
            }
            if let crate::lower::model::Ex::XByte(d_p8) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::std::uint8_t({})", d_p8)));
            }
            if let crate::lower::model::Ex::XFloat(d_p9) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Float{{{}}}", d_p9)));
            }
            if let crate::lower::model::Ex::XDuration(n_pa) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Duration{{{}}}", &cpp_nanos_f(n_pa))));
            }
            if let crate::lower::model::Ex::XIndex(n_pb) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}u", n_pb)));
            }
            if let crate::lower::model::Ex::XChar(c_pc) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("U\'{}\'", &cpp_char_escape_f(c_pc))));
            }
            if let crate::lower::model::Ex::XStr(t_pd) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::Finished(cpp_string_f(t_pd));
            }
            if let crate::lower::model::Ex::XRegex(p_pe, f_pf) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("([]() -> const crate::prelude::Regex& {{ static const crate::prelude::Regex r = crate::prelude::Regex::lit({}, {}); return r; }}())", &cpp_string_f(p_pe), &cpp_string_f(f_pf))));
            }
            if let crate::lower::model::Ex::XReplacement(p_pg, r_ph, f_pi) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("([]() -> const crate::prelude::RegexReplacement& {{ static const crate::prelude::RegexReplacement r = crate::prelude::RegexReplacement::lit({}, {}, {}); return r; }}())", &cpp_string_f(p_pg), &cpp_string_f(f_pi), &cpp_string_f(r_ph))));
            }
            if let crate::lower::model::Ex::XRef(y_pj) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::More(::std::rc::Rc::new(CppPlace { cp_p0: cp_p0.clone(), ex1: (**y_pj).clone() }));
            }
            if let crate::lower::model::Ex::XRefMut(y_pk) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::More(::std::rc::Rc::new(CppPlace { cp_p0: cp_p0.clone(), ex1: (**y_pk).clone() }));
            }
            if let crate::lower::model::Ex::XDeref(y_pl) = x_p1 {
                break 'm3238 match ex_ty_o(cp_p0, &**y_pl) {
                    ::std::option::Option::Some(crate::lower::model::OutTy::OutRc(_)) => {
                        let cp_p0x = cp_p0.clone();
                        let y_plx = (**y_pl).clone();
                        crate::prelude::call_then(start_cpp_tight_place_f(cp_p0x.clone(), y_plx.clone()), move |cpp_tight_place_f_5064: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("*{}", &cpp_tight_place_f_5064))))
                    },
                    ::std::option::Option::Some(crate::lower::model::OutTy::OutRef(_)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(CppPlace { cp_p0: cp_p0.clone(), ex1: (**y_pl).clone() })),
                    _ => {
                        let cp_p0x = cp_p0.clone();
                        let y_plx = (**y_pl).clone();
                        crate::prelude::call_then(start_cpp_place_f(cp_p0x.clone(), y_plx.clone()), move |cpp_place_f_5168: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::prism_rtl::deref({})", &cpp_place_f_5168))))
                    },
                };
            }
            if let crate::lower::model::Ex::XTarget(y_pm) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::More(::std::rc::Rc::new(CppPlace { cp_p0: cp_p0.clone(), ex1: (**y_pm).clone() }));
            }
            if let crate::lower::model::Ex::XClone(y_pn) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::More(::std::rc::Rc::new(CppPlace { cp_p0: cp_p0.clone(), ex1: (**y_pn).clone() }));
            }
            if let crate::lower::model::Ex::XWeak(y_po) = x_p1 {
                break 'm3238 {
                    let cp_p0x = cp_p0.clone();
                    let y_pox = (**y_po).clone();
                    crate::prelude::call_then(start_cpp_expr_f(cp_p0x.clone(), y_pox.clone()), move |cpp_expr_f_5280: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::prism_rtl::weaken({})", &cpp_expr_f_5280))))
                };
            }
            if let crate::lower::model::Ex::XUpgrade(y_pp) = x_p1 {
                break 'm3238 {
                    let cp_p0x = cp_p0.clone();
                    let y_ppx = (**y_pp).clone();
                    crate::prelude::call_then(start_cpp_expr_f(cp_p0x.clone(), y_ppx.clone()), move |cpp_expr_f_5336: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::prism_rtl::upgrade({})", &cpp_expr_f_5336))))
                };
            }
            if let crate::lower::model::Ex::XBreak(l_pq, y_pr) = x_p1 {
                break 'm3238 {
                    let cp_p0x = cp_p0.clone();
                    let l_pqx = l_pq.clone();
                    let y_prx = (**y_pr).clone();
                    crate::prelude::call_then(crate::emit::cpp::patterns::start_cpp_break_f(cp_p0x.clone(), l_pqx.clone(), y_prx.clone()), move |cpp_break_f_5373: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("({})", &cpp_break_f_5373))))
                };
            }
            if let crate::lower::model::Ex::XBreakLoop = x_p1 {
                break 'm3238 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("({ break; })"));
            }
            if let crate::lower::model::Ex::XLater(y_ps) = x_p1 {
                break 'm3238 {
                    let cp_p0x = cp_p0.clone();
                    let y_psx = (**y_ps).clone();
                    crate::prelude::call_then(start_cpp_expr_f(crate::emit::cpp::stmts::captured_f(&cp_p0x), y_psx.clone()), move |cpp_expr_f_5498: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("[=](crate::prelude::Cx& cx) -> crate::prelude::Done {{ {}; return {{}}; }}", &cpp_expr_f_5498))))
                };
            }
            if let crate::lower::model::Ex::XFormatStr(parts_pt) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::More(::std::rc::Rc::new(CppFormat { cp_p0: cp_p0.clone(), parts_p1: parts_pt.clone(), how_p2: crate::prelude::Text::lit("::prism_rtl::str") }));
            }
            if let crate::lower::model::Ex::XIsCase(y_pu, m3238_29_1) = x_p1 && (m3238_29_1.len() == 0) {
                break 'm3238 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("false"));
            }
            if let crate::lower::model::Ex::XIsCase(y_pv, cs_p10) = x_p1 {
                break 'm3238 {
                    let cp_p0x = cp_p0.clone();
                    let cs_p10x = cs_p10.clone();
                    let y_pvx = (**y_pv).clone();
                    crate::prelude::call_value(crate::prelude::each_job(cs_p10x.clone(), {
                        let cp_p0xx = cp_p0x.clone();
                        let y_pvxx = y_pvx.clone();
                        ::std::rc::Rc::new(move |p0: crate::lower::model::Ref| {
                            let cp_p0xxy = cp_p0xx.clone();
                            let y_pvxxy = y_pvxx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let c_p11 = p0;
                                crate::prelude::call_then(start_cpp_tight_place_f(cp_p0xxy.clone(), y_pvxxy.clone()), move |cpp_tight_place_f_5692: crate::prelude::Text| ::prism_rtl::Turn::Finished(case_test_f(&cp_p0xxy, &c_p11, &cpp_tight_place_f_5692)))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ref) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                    }), move |each_5661: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("({})", &crate::syntax::lexer::chars::join_f(&each_5661, &crate::prelude::Text::lit(" || "))))))
                };
            }
            if let crate::lower::model::Ex::XRefusal(what_p12) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::expr::lowering_refusal_p(), &crate::lower::expr::escape_f(what_p12))));
            }
            if let crate::lower::model::Ex::XUnreachable = x_p1 {
                break 'm3238 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("throw ::prism_rtl::Panic(\"entered unreachable code\")"));
            }
            if let crate::lower::model::Ex::XCall(f_p13, args_p14) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::More(::std::rc::Rc::new(CppCall { cp_p0: cp_p0.clone(), f_p1: f_p13.clone(), args_p2: args_p14.clone() }));
            }
            if let crate::lower::model::Ex::XCallAt(f_p15, tys_p16, args_p17) = x_p1 {
                break 'm3238 {
                    let args_p17x = args_p17.clone();
                    let cp_p0x = cp_p0.clone();
                    let f_p15x = f_p15.clone();
                    let tys_p16x = tys_p16.clone();
                    crate::prelude::call_then(crate::emit::cpp::start_cpp_types_f(cp_p0x.clone(), tys_p16x.clone()), move |cpp_types_f_5960: crate::prelude::Text| crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p17x.clone()), move |cpp_args_f_5980: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}<{}>({})", &free_call_path_f(&cp_p0x, &f_p15x), &cpp_types_f_5960, &cpp_args_f_5980)))))
                };
            }
            if let crate::lower::model::Ex::XCallSelf(tr_p18, m_p19, self_p1a, args_p1b) = x_p1 {
                break 'm3238 {
                    let args_p1bx = args_p1b.clone();
                    let cp_p0x = cp_p0.clone();
                    let m_p19x = m_p19.clone();
                    let self_p1ax = self_p1a.clone();
                    let tr_p18x = tr_p18.clone();
                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), self_p1ax.clone()), move |cpp_type_f_6071: crate::prelude::Text| crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p1bx.clone()), move |cpp_args_f_6097: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}::{}_at<{}>::call({})", &free_call_path_f(&cp_p0x, &tr_p18x), &crate::emit::cpp::cpp_id_f(&m_p19x), &cpp_type_f_6071, &cpp_args_f_6097)))))
                };
            }
            if let crate::lower::model::Ex::XApply(f_p1c, args_p1d) = x_p1 {
                break 'm3238 {
                    let args_p1dx = args_p1d.clone();
                    let cp_p0x = cp_p0.clone();
                    let f_p1cx = (**f_p1c).clone();
                    crate::prelude::call_then(start_cpp_tight_place_f(cp_p0x.clone(), f_p1cx.clone()), move |cpp_tight_place_f_6139: crate::prelude::Text| crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p1dx.clone()), move |cpp_args_f_6161: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}({})", &cpp_tight_place_f_6139, &cpp_args_f_6161)))))
                };
            }
            if let crate::lower::model::Ex::XMethod(r_p1e, m_p1f, args_p1g) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::More(::std::rc::Rc::new(CppMethod { cp_p0: cp_p0.clone(), r_p1: (**r_p1e).clone(), m_p2: m_p1f.clone(), args_p3: args_p1g.clone() }));
            }
            if let crate::lower::model::Ex::XBin(op_p1h, l_p1i, r_p1j) = x_p1 {
                break 'm3238 {
                    let cp_p0x = cp_p0.clone();
                    let l_p1ix = (**l_p1i).clone();
                    let op_p1hx = op_p1h.clone();
                    let r_p1jx = (**r_p1j).clone();
                    crate::prelude::call_then(start_cpp_arg_list_f(cp_p0x.clone(), crate::prelude::Array::from(vec![l_p1ix.clone(), r_p1jx.clone()])), move |cpp_arg_list_f_6280: crate::prelude::Array<crate::prelude::Text>| {
                        let (lt_p1m, rt_p1n) = 'm6274: {
                            if let m6274_0 = &cpp_arg_list_f_6280 && (m6274_0.len() == 2) && let ::std::option::Option::Some(a_p1k) = crate::prelude::index(m6274_0, &crate::prelude::Nat::from(0u32)) && let ::std::option::Option::Some(b_p1l) = crate::prelude::index(m6274_0, &crate::prelude::Nat::from(1u32)) {
                                break 'm6274 (a_p1k.clone(), b_p1l.clone());
                            }
                            (crate::prelude::Text::lit(""), crate::prelude::Text::lit(""))
                        };
                        ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {} {}", &(if cpp_loose_f(&l_p1ix) {
                            crate::prelude::Text::from(format!("({})", &lt_p1m))
                        } else {
                            lt_p1m.clone()
                        }), &crate::lower::model::bin_op_text_f(&op_p1hx), &(if cpp_loose_f(&r_p1jx) {
                            crate::prelude::Text::from(format!("({})", &rt_p1n))
                        } else {
                            rt_p1n.clone()
                        }))))
                    })
                };
            }
            if let crate::lower::model::Ex::XUnary(op_p1o, y_p1p) = x_p1 {
                break 'm3238 {
                    let cp_p0x = cp_p0.clone();
                    let op_p1ox = op_p1o.clone();
                    let y_p1px = (**y_p1p).clone();
                    crate::prelude::call_then(start_cpp_tight_f(cp_p0x.clone(), y_p1px.clone()), move |cpp_tight_f_6498: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{}", &crate::lower::model::un_op_text_f(&op_p1ox), &cpp_tight_f_6498))))
                };
            }
            if let crate::lower::model::Ex::XCtor(p_p1q, args_p1r) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::More(::std::rc::Rc::new(CppCtor { cp_p0: cp_p0.clone(), r_p1: p_p1q.clone(), args_p2: args_p1r.clone() }));
            }
            if let crate::lower::model::Ex::XRecord(p_p1s, fs_p1t) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::More(::std::rc::Rc::new(CppRecord { cp_p0: cp_p0.clone(), p_p1: p_p1s.clone(), fs_p2: fs_p1t.clone() }));
            }
            if let crate::lower::model::Ex::XTuple(m3238_42_0) = x_p1 && (m3238_42_0.len() == 1) && let ::std::option::Option::Some(x_p1u) = crate::prelude::index(m3238_42_0, &crate::prelude::Nat::from(0u32)) {
                break 'm3238 {
                    let cp_p0x = cp_p0.clone();
                    crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), crate::prelude::Array::from(vec![x_p1u.clone()])), move |cpp_args_f_6722: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::std::make_tuple({})", &cpp_args_f_6722))))
                };
            }
            if let crate::lower::model::Ex::XTuple(xs_p1v) = x_p1 {
                break 'm3238 {
                    let cp_p0x = cp_p0.clone();
                    let xs_p1vx = xs_p1v.clone();
                    crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), xs_p1vx.clone()), move |cpp_args_f_6774: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::std::tuple{{{}}}", &cpp_args_f_6774))))
                };
            }
            if let crate::lower::model::Ex::XVec(m3238_44_0) = x_p1 && (m3238_44_0.len() == 0) {
                break 'm3238 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("{}"));
            }
            if let crate::lower::model::Ex::XVec(xs_p20) = x_p1 {
                break 'm3238 {
                    let cp_p0x = cp_p0.clone();
                    let xs_p20x = xs_p20.clone();
                    crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), xs_p20x.clone()), move |cpp_args_f_6845: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::std::vector{{{}}}", &cpp_args_f_6845))))
                };
            }
            if let crate::lower::model::Ex::XText(t_p21) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Text::lit({})", &cpp_string_f(t_p21))));
            }
            if let crate::lower::model::Ex::XFormat(parts_p22) = x_p1 {
                break 'm3238 if crate::prelude::fold(parts_p22, &true, &(|f_p23: &bool, p_p24: &crate::lower::model::Ex| *f_p23 && is_text_piece_f(p_p24))) {
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Text::lit({})", &cpp_string_f(&crate::prelude::concat(&crate::prelude::each(parts_p22, &(|p_p25: &crate::lower::model::Ex| text_piece_f(p_p25))))))))
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(CppFormat { cp_p0: cp_p0.clone(), parts_p1: parts_p22.clone(), how_p2: crate::prelude::Text::lit("::prism_rtl::cat") }))
                };
            }
            if let crate::lower::model::Ex::XMatch(s_p26, arms_p27, fallback_p28, t_p29) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::cpp::patterns::CppMatch { cp_p0: cp_p0.clone(), s_p1: (**s_p26).clone(), arms_p2: arms_p27.clone(), out_ty3: t_p29.clone() }));
            }
            if let crate::lower::model::Ex::XChain(label_p2a, s_p2b, arms_p2c, t_p2d) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::cpp::patterns::CppMatch { cp_p0: cp_p0.clone(), s_p1: (**s_p2b).clone(), arms_p2: arms_p2c.clone(), out_ty3: t_p2d.clone() }));
            }
            if let crate::lower::model::Ex::XIf(c_p2e, t_p2f, e_p2g) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::More(::std::rc::Rc::new(CppIf { cp_p0: cp_p0.clone(), c_p1: (**c_p2e).clone(), t_p2: (**t_p2f).clone(), e_p3: (**e_p2g).clone() }));
            }
            if let crate::lower::model::Ex::XBlock(m3238_51_0, e_p2h) = x_p1 && (m3238_51_0.len() == 0) {
                break 'm3238 ::prism_rtl::Turn::More(::std::rc::Rc::new(CppExpr { cp_p0: cp_p0.clone(), x_p1: (**e_p2h).clone() }));
            }
            if let crate::lower::model::Ex::XBlock(dos_p2i, e_p2j) = x_p1 {
                break 'm3238 {
                    let cp_p0x = cp_p0.clone();
                    let dos_p2ix = dos_p2i.clone();
                    let e_p2jx = (**e_p2j).clone();
                    crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_statements_cp_f(cp_p0x.clone(), dos_p2ix.clone()), move |cpp_statements_cp_f_7341: (crate::prelude::Text, crate::emit::cpp::Cp)| {
                        let (st_p2k, cp2_p2l) = cpp_statements_cp_f_7341;
                        crate::prelude::call_then(start_with_move_captures_f(cp2_p2l.clone(), dos_p2ix.clone(), e_p2jx.clone()), move |with_move_captures_f_7405: crate::emit::cpp::Cp| crate::prelude::call_then(start_cpp_expr_f(with_move_captures_f_7405, e_p2jx.clone()), move |cpp_expr_f_7396: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::stmt_expr_f(&st_p2k, &crate::emit::cpp::stmts::unvexed_f(&cpp_expr_f_7396)))))
                    })
                };
            }
            if let crate::lower::model::Ex::XLabeled(label_p2m, dos_p2n, e_p2o, t_p2p) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::cpp::patterns::CppLabeled { cp_p0: cp_p0.clone(), label_p1: label_p2m.clone(), dos_p2: dos_p2n.clone(), e_p3: (**e_p2o).clone(), t_p4: t_p2p.clone() }));
            }
            if let crate::lower::model::Ex::XClosure(mv_p2q, ps_p2r, body_p2s) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::More(::std::rc::Rc::new(CppClosure { cp0_p0: cp_p0.clone(), mv_p1: *mv_p2q, ps_p2: ps_p2r.clone(), body_p3: (**body_p2s).clone() }));
            }
            if let crate::lower::model::Ex::XTry(y_p2t) = x_p1 {
                break 'm3238 {
                    let cp_p0x = cp_p0.clone();
                    let y_p2tx = (**y_p2t).clone();
                    crate::prelude::call_then(start_cpp_expr_f(cp_p0x.clone(), y_p2tx.clone()), move |cpp_expr_f_7576: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("TRY({})", &cpp_expr_f_7576))))
                };
            }
            if let crate::lower::model::Ex::XField(r_p2u, f_p2v) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::More(::std::rc::Rc::new(CppField { cp_p0: cp_p0.clone(), ex1: (**r_p2u).clone(), f_p1: f_p2v.clone() }));
            }
            if let crate::lower::model::Ex::XFieldOf(r_p30, _, f_p31) = x_p1 {
                break 'm3238 ::prism_rtl::Turn::More(::std::rc::Rc::new(CppFieldOf { cp_p0: cp_p0.clone(), r_p1: (**r_p30).clone(), f_p2: f_p31.clone() }));
            }
            if let crate::lower::model::Ex::XPart(r_p32, k_p33) = x_p1 {
                break 'm3238 {
                    let cp_p0x = cp_p0.clone();
                    let k_p33x = k_p33.clone();
                    let r_p32x = (**r_p32).clone();
                    crate::prelude::call_then(start_as_value_f(cp_p0x.clone(), r_p32x.clone()), move |as_value_f_7709: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::std::get<{}>({})", &k_p33x, &as_value_f_7709))))
                };
            }
            if let crate::lower::model::Ex::XDecode(t_p34, y_p35) = x_p1 {
                break 'm3238 {
                    let cp_p0x = cp_p0.clone();
                    let t_p34x = t_p34.clone();
                    let y_p35x = (**y_p35).clone();
                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), t_p34x.clone()), move |cpp_type_f_7772: crate::prelude::Text| crate::prelude::call_then(start_cpp_expr_f(cp_p0x.clone(), y_p35x.clone()), move |cpp_expr_f_7789: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("TRY(::prism_rtl::from_pod<{}>({}))", &cpp_type_f_7772, &cpp_expr_f_7789)))))
                };
            }
            if let crate::lower::model::Ex::XCast(y_p36, t_p37) = x_p1 {
                break 'm3238 {
                    let cp_p0x = cp_p0.clone();
                    let t_p37x = t_p37.clone();
                    let y_p36x = (**y_p36).clone();
                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), t_p37x.clone()), move |cpp_type_f_7837: crate::prelude::Text| crate::prelude::call_then(start_cpp_expr_f(cp_p0x.clone(), y_p36x.clone()), move |cpp_expr_f_7854: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("static_cast<{}>({})", &cpp_type_f_7837, &cpp_expr_f_7854)))))
                };
            }
            if let crate::lower::model::Ex::XTyped(y_p38, t_p39) = x_p1 {
                break 'm3238 match &**y_p38 {
                    crate::lower::model::Ex::XCtor(p_p3a, args_p3b) if is_generic_case_f(cp_p0, p_p3a) => {
                        let args_p3bx = args_p3b.clone();
                        let cp_p0x = cp_p0.clone();
                        let p_p3ax = p_p3a.clone();
                        let t_p39x = t_p39.clone();
                        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), t_p39x.clone()), move |cpp_type_f_8103: crate::prelude::Text| {
                            let tt_p3c = cpp_type_f_8103;
                            crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p3bx.clone()), move |cpp_args_f_8165: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}(typename {}::{}{{{}}})", &tt_p3c, &tt_p3c, &crate::emit::cpp::case_id_of_f(&p_p3ax), &cpp_args_f_8165))))
                        })
                    },
                    crate::lower::model::Ex::XPath(p_p3d) if is_generic_case_f(cp_p0, p_p3d) => {
                        let cp_p0x = cp_p0.clone();
                        let p_p3dx = p_p3d.clone();
                        let t_p39x = t_p39.clone();
                        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), t_p39x.clone()), move |cpp_type_f_8248: crate::prelude::Text| {
                            let tt_p3e = cpp_type_f_8248;
                            ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}(typename {}::{}{{}})", &tt_p3e, &tt_p3e, &crate::emit::cpp::case_id_of_f(&p_p3dx))))
                        })
                    },
                    crate::lower::model::Ex::XRecord(p_p3f, fs_p3g) => {
                        let cp_p0x = cp_p0.clone();
                        let fs_p3gx = fs_p3g.clone();
                        let p_p3fx = p_p3f.clone();
                        let t_p39x = t_p39.clone();
                        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), t_p39x.clone()), move |cpp_type_f_8431: crate::prelude::Text| ::prism_rtl::Turn::More(::std::rc::Rc::new(CppRecordAs { cp_p0: cp_p0x.clone(), p_p1: p_p3fx.clone(), fs_p2: fs_p3gx.clone(), head_p3: cpp_type_f_8431 })))
                    },
                    _ => {
                        let cp_p0x = cp_p0.clone();
                        let t_p39x = t_p39.clone();
                        let y_p38x = (**y_p38).clone();
                        crate::prelude::call_then(start_cpp_expr_f(cp_p0x.clone(), y_p38x.clone()), move |cpp_expr_f_8485: crate::prelude::Text| {
                            let e_p3h = cpp_expr_f_8485;
                            if (&e_p3h == &crate::prelude::Text::lit("{}")) || (&e_p3h == &crate::prelude::Text::lit("::std::nullopt")) {
                                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), t_p39x.clone()), move |cpp_type_f_8554: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{{}}", &cpp_type_f_8554))))
                            } else {
                                if (is_ctor_f(&y_p38x, &crate::prelude::Text::lit("Ok")) || is_ctor_f(&y_p38x, &crate::prelude::Text::lit("Err"))) || is_ctor_f(&y_p38x, &crate::prelude::Text::lit("Some")) {
                                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), t_p39x.clone()), move |cpp_type_f_8656: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}({})", &cpp_type_f_8656, &e_p3h))))
                                } else {
                                    ::prism_rtl::Turn::Finished(e_p3h.clone())
                                }
                            }
                        })
                    },
                    _ => unreachable!("no arm matched"),
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start CppExpr, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_expr_f(cp_p0: crate::emit::cpp::Cp, x_p1: crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppExpr { cp_p0, x_p1 })
}

/// ```prism
/// CppString: fn Text -> Text
/// ```
pub fn cpp_string_f(t_p0: &crate::prelude::Text) -> crate::prelude::Text {
    if crate::syntax::lexer::chars::contains_f(t_p0, &crate::prelude::Text::lit("\0")) {
        crate::prelude::Text::from(format!("\"{}\"sv", &cpp_escape_f(t_p0)))
    } else {
        crate::prelude::Text::from(format!("\"{}\"", &cpp_escape_f(t_p0)))
    }
}

/// ```prism
/// CppEscape: fn Text -> Text
/// ```
pub fn cpp_escape_f(t_p0: &crate::prelude::Text) -> crate::prelude::Text {
    crate::syntax::lexer::chars::map_chars_f(t_p0, &(::std::rc::Rc::new(move |p0: crate::prelude::Text| crate::prelude::once_job(move || {
        let c_p1 = p0;
        if &c_p1 == &crate::prelude::Text::lit("\0") {
            ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("\\000"))
        } else {
            ::prism_rtl::Turn::Finished(crate::lower::expr::char_escape_f(&c_p1))
        }
    })) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>))
}

/// ```prism
/// IsTextPiece: fn Ex -> Bool
/// ```
pub fn is_text_piece_f(ex0: &crate::lower::model::Ex) -> bool {
    match ex0 {
        crate::lower::model::Ex::XText(_) => true,
        other_p0 => false,
    }
}

/// ```prism
/// TextPiece: fn Ex -> Text
/// ```
pub fn text_piece_f(ex0: &crate::lower::model::Ex) -> crate::prelude::Text {
    match ex0 {
        crate::lower::model::Ex::XText(t_p0) => t_p0.clone(),
        other_p1 => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// CppFormat: unbounded fn Cp, [Ex], Text -> Text
/// ```
pub fn cpp_format_f(cp_p0: &crate::emit::cpp::Cp, parts_p1: &crate::prelude::Array<crate::lower::model::Ex>, how_p2: &crate::prelude::Text) -> crate::prelude::Text {
    crate::prelude::Text::from(format!("{}({})", how_p2, &crate::syntax::lexer::chars::join_f(&cpp_arg_list_f(cp_p0, &crate::prelude::each(parts_p1, &(|p_p3: &crate::lower::model::Ex| format_arg_f(p_p3)))), &crate::prelude::Text::lit(", "))))
}

/// The step machine of `CppFormat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppFormat: unbounded fn Cp, [Ex], Text -> Text
/// ```
pub struct CppFormat {
    pub cp_p0: crate::emit::cpp::Cp,
    pub parts_p1: crate::prelude::Array<crate::lower::model::Ex>,
    pub how_p2: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppFormat {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let parts_p1 = &self.parts_p1;
        let how_p2 = &self.how_p2;
        let cp_p0x = cp_p0.clone();
        let how_p2x = how_p2.clone();
        let parts_p1x = parts_p1.clone();
        crate::prelude::call_then(start_cpp_arg_list_f(cp_p0x.clone(), crate::prelude::each(&parts_p1x, &(|p_p3: &crate::lower::model::Ex| format_arg_f(p_p3)))), move |cpp_arg_list_f_9452: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}({})", &how_p2x, &crate::syntax::lexer::chars::join_f(&cpp_arg_list_f_9452, &crate::prelude::Text::lit(", "))))))
    }
}

/// `Start CppFormat, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_format_f(cp_p0: crate::emit::cpp::Cp, parts_p1: crate::prelude::Array<crate::lower::model::Ex>, how_p2: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppFormat { cp_p0, parts_p1, how_p2 })
}

/// ```prism
/// FormatArg: fn Ex -> Ex
/// ```
pub fn format_arg_f(ex0: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    match ex0 {
        crate::lower::model::Ex::XText(t_p0) => crate::lower::model::Ex::XStr(t_p0.clone()),
        x_p1 => x_p1.clone(),
    }
}

/// ```prism
/// CppNanos: fn Text -> Text
/// ```
pub fn cpp_nanos_f(n_p0: &crate::prelude::Text) -> crate::prelude::Text {
    if crate::syntax::lexer::chars::has_prefix_f(n_p0, &crate::prelude::Text::lit("-")) {
        crate::prelude::Text::from(format!("(-{})", &cpp_nanos_of_f(&crate::prelude::or(&crate::prelude::parse_nat_opt(&crate::syntax::lexer::chars::after_first_f(n_p0)), &crate::prelude::Nat::from(0u32)))))
    } else {
        cpp_nanos_of_f(&crate::prelude::or(&crate::prelude::parse_nat_opt(n_p0), &crate::prelude::Nat::from(0u32)))
    }
}

/// ```prism
/// CppNanosOf: fn Nat -> Text
/// ```
pub fn cpp_nanos_of_f(n_p0: &crate::prelude::Nat) -> crate::prelude::Text {
    let base_p1 = crate::prelude::Nat::from_int(crate::prelude::Int::parse("1000000000000000000").unwrap()).unwrap();
    let part_f2 = ::std::rc::Rc::new(move |k_p5: &crate::prelude::Nat| crate::prelude::Text::from(format!("prism_rtl::Nanos({}ll)", k_p5))) as ::std::rc::Rc<dyn ::std::ops::Fn(&crate::prelude::Nat) -> crate::prelude::Text>;
    let low_p3 = crate::prelude::or(&crate::prelude::mod_(n_p0, &base_p1), &crate::prelude::Nat::from(0u32));
    let high_p4 = crate::prelude::or(&crate::prelude::div(n_p0, &base_p1), &crate::prelude::Nat::from(0u32));
    if &high_p4 == &crate::prelude::Nat::from(0u32) {
        (&part_f2)(&low_p3)
    } else {
        {
            let mid_p6 = crate::prelude::or(&crate::prelude::mod_(&high_p4, &base_p1), &crate::prelude::Nat::from(0u32));
            let top_p7 = crate::prelude::or(&crate::prelude::div(&high_p4, &base_p1), &crate::prelude::Nat::from(0u32));
            let upper_p8 = if &top_p7 == &crate::prelude::Nat::from(0u32) {
                (&part_f2)(&mid_p6)
            } else {
                crate::prelude::Text::from(format!("({} * {} + {})", &(&part_f2)(&top_p7), &(&part_f2)(&base_p1), &(&part_f2)(&mid_p6)))
            };
            crate::prelude::Text::from(format!("({} * {} + {})", &upper_p8, &(&part_f2)(&base_p1), &(&part_f2)(&low_p3)))
        }
    }
}

/// ```prism
/// CppCharEscape: fn Text -> Text
/// ```
pub fn cpp_char_escape_f(text0: &crate::prelude::Text) -> crate::prelude::Text {
    match text0 {
        c0_0 if (c0_0 == &crate::prelude::Text::lit("\'")) => crate::prelude::Text::lit("\\\'"),
        c_p0 => crate::lower::expr::char_escape_f(c_p0),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// PathValue: fn Cp, Ref -> Text
/// ```
pub fn path_value_f(cp_p0: &crate::emit::cpp::Cp, p_p1: &crate::lower::model::Ref) -> crate::prelude::Text {
    if is_node_method_f(cp_p0, p_p1) {
        crate::prelude::Text::from(format!("&{}::{}", &crate::emit::cpp::type_path_f(&crate::lower::model::ref_spelled_f(&crate::lower::model::ref_parent_f(p_p1))), &node_method_name_f(cp_p0, &crate::lower::model::ref_last_f(p_p1))))
    } else {
        match crate::emit::cpp::case_of_o(cp_p0, p_p1) {
            ::std::option::Option::Some(ty_p2) => crate::prelude::Text::from(format!("{}({}{{}})", &crate::emit::cpp::own_type_path_f(cp_p0, &ty_p2), &crate::emit::cpp::own_type_path_f(cp_p0, p_p1))),
            ::std::option::Option::None => match crate::emit::cpp::type_of_o(cp_p0, p_p1) {
                ::std::option::Option::Some(info_p3) => if &info_p3.kind_p == &crate::prelude::Text::lit("unit") {
                    crate::prelude::Text::from(format!("{}{{}}", &crate::emit::cpp::own_type_path_f(cp_p0, p_p1)))
                } else {
                    crate::emit::cpp::own_type_path_f(cp_p0, p_p1)
                },
                ::std::option::Option::None => match p_p1 {
                    crate::lower::model::Ref::RefRuntime(t_p4) => crate::emit::cpp::type_path_f(&crate::lower::model::runtime_path_f(t_p4)),
                    _ => crate::emit::cpp::type_path_f(&crate::lower::model::ref_spelled_f(p_p1)),
                },
            },
        }
    }
}

/// ```prism
/// IsNodeMethod: fn Cp, Ref -> Bool
/// ```
pub fn is_node_method_f(cp_p0: &crate::emit::cpp::Cp, p_p1: &crate::lower::model::Ref) -> bool {
    match p_p1 {
        crate::lower::model::Ref::RefItem(_, _, _) => {
            let named_p2 = match crate::prelude::get(&cp_p0.methods_p, &crate::lower::model::ref_last_f(p_p1)) {
                ::std::option::Option::Some(_) => true,
                ::std::option::Option::None => false,
            };
            named_p2 && is_node_type_f(cp_p0, &crate::lower::model::ref_parent_f(p_p1))
        },
        _ => false,
    }
}

/// ```prism
/// IsNodeType: fn Cp, Ref -> Bool
/// ```
pub fn is_node_type_f(cp_p0: &crate::emit::cpp::Cp, p_p1: &crate::lower::model::Ref) -> bool {
    match crate::emit::cpp::type_of_o(cp_p0, p_p1) {
        ::std::option::Option::Some(info_p2) => &info_p2.kind_p == &crate::prelude::Text::lit("node"),
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// CppField: unbounded fn Cp, Ex, Text -> Text
/// ```
pub fn cpp_field_f(cp_p0: &crate::emit::cpp::Cp, ex1: &crate::lower::model::Ex, f_p1: &crate::prelude::Text) -> crate::prelude::Text {
    match ex1 {
        crate::lower::model::Ex::XSelf => crate::prelude::Text::from(format!("this->{}", &crate::emit::cpp::field_id_f(f_p1))),
        r_p3 => {
            let name_p5 = if is_digits_f(f_p1) {
                crate::prelude::Text::from(format!("a{}", f_p1))
            } else {
                crate::emit::cpp::field_id_f(f_p1)
            };
            match pointer_o(cp_p0, r_p3) {
                ::std::option::Option::Some(b_p6) => crate::prelude::Text::from(format!("{}{}{}", &cpp_tight_place_f(cp_p0, r_p3), &(if b_p6 { crate::prelude::Text::lit("->") } else { crate::prelude::Text::lit(".") }), &name_p5)),
                ::std::option::Option::None => match crate::prelude::get(&cp_p0.members_p, f_p1) {
                    ::std::option::Option::Some(_) => crate::prelude::Text::from(format!("{}->{}", &cpp_tight_place_f(cp_p0, r_p3), &name_p5)),
                    ::std::option::Option::None => crate::prelude::Text::from(format!("{}.{}", &as_value_f(cp_p0, r_p3), &name_p5)),
                },
            }
        },
    }
}

/// The step machine of `CppField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppField: unbounded fn Cp, Ex, Text -> Text
/// ```
pub struct CppField {
    pub cp_p0: crate::emit::cpp::Cp,
    pub ex1: crate::lower::model::Ex,
    pub f_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppField {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let ex1 = &self.ex1;
        let f_p1 = &self.f_p1;
        match ex1 {
            crate::lower::model::Ex::XSelf => ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("this->{}", &crate::emit::cpp::field_id_f(f_p1)))),
            r_p3 => {
                let name_p5 = if is_digits_f(f_p1) {
                    crate::prelude::Text::from(format!("a{}", f_p1))
                } else {
                    crate::emit::cpp::field_id_f(f_p1)
                };
                match pointer_o(cp_p0, r_p3) {
                    ::std::option::Option::Some(b_p6) => {
                        let cp_p0x = cp_p0.clone();
                        let r_p3x = r_p3.clone();
                        crate::prelude::call_then(start_cpp_tight_place_f(cp_p0x.clone(), r_p3x.clone()), move |cpp_tight_place_f_12466: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{}{}", &cpp_tight_place_f_12466, &(if b_p6 { crate::prelude::Text::lit("->") } else { crate::prelude::Text::lit(".") }), &name_p5))))
                    },
                    ::std::option::Option::None => match crate::prelude::get(&cp_p0.members_p, f_p1) {
                        ::std::option::Option::Some(_) => {
                            let cp_p0x = cp_p0.clone();
                            let r_p3x = r_p3.clone();
                            crate::prelude::call_then(start_cpp_tight_place_f(cp_p0x.clone(), r_p3x.clone()), move |cpp_tight_place_f_12574: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}->{}", &cpp_tight_place_f_12574, &name_p5))))
                        },
                        ::std::option::Option::None => {
                            let cp_p0x = cp_p0.clone();
                            let r_p3x = r_p3.clone();
                            crate::prelude::call_then(start_as_value_f(cp_p0x.clone(), r_p3x.clone()), move |as_value_f_12623: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}.{}", &as_value_f_12623, &name_p5))))
                        },
                    },
                }
            },
        }
    }
}

/// `Start CppField, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_field_f(cp_p0: crate::emit::cpp::Cp, ex1: crate::lower::model::Ex, f_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppField { cp_p0, ex1, f_p1 })
}

/// ```prism
/// CppFieldOf: unbounded fn Cp, Ex, Text -> Text
/// ```
pub fn cpp_field_of_f(cp_p0: &crate::emit::cpp::Cp, r_p1: &crate::lower::model::Ex, f_p2: &crate::prelude::Text) -> crate::prelude::Text {
    let name_p3 = if is_digits_f(f_p2) {
        crate::prelude::Text::from(format!("a{}", f_p2))
    } else {
        crate::emit::cpp::field_id_f(f_p2)
    };
    match pointer_o(cp_p0, r_p1) {
        ::std::option::Option::Some(b_p4) => crate::prelude::Text::from(format!("{}{}{}", &cpp_tight_place_f(cp_p0, r_p1), &(if b_p4 { crate::prelude::Text::lit("->") } else { crate::prelude::Text::lit(".") }), &name_p3)),
        ::std::option::Option::None => crate::prelude::Text::from(format!("{}.{}", &as_value_f(cp_p0, r_p1), &name_p3)),
    }
}

/// The step machine of `CppFieldOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppFieldOf: unbounded fn Cp, Ex, Text -> Text
/// ```
pub struct CppFieldOf {
    pub cp_p0: crate::emit::cpp::Cp,
    pub r_p1: crate::lower::model::Ex,
    pub f_p2: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppFieldOf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let r_p1 = &self.r_p1;
        let f_p2 = &self.f_p2;
        let name_p3 = if is_digits_f(f_p2) {
            crate::prelude::Text::from(format!("a{}", f_p2))
        } else {
            crate::emit::cpp::field_id_f(f_p2)
        };
        match pointer_o(cp_p0, r_p1) {
            ::std::option::Option::Some(b_p4) => {
                let cp_p0x = cp_p0.clone();
                let r_p1x = r_p1.clone();
                crate::prelude::call_then(start_cpp_tight_place_f(cp_p0x.clone(), r_p1x.clone()), move |cpp_tight_place_f_12909: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{}{}", &cpp_tight_place_f_12909, &(if b_p4 { crate::prelude::Text::lit("->") } else { crate::prelude::Text::lit(".") }), &name_p3))))
            },
            ::std::option::Option::None => {
                let cp_p0x = cp_p0.clone();
                let r_p1x = r_p1.clone();
                crate::prelude::call_then(start_as_value_f(cp_p0x.clone(), r_p1x.clone()), move |as_value_f_12974: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}.{}", &as_value_f_12974, &name_p3))))
            },
        }
    }
}

/// `Start CppFieldOf, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_field_of_f(cp_p0: crate::emit::cpp::Cp, r_p1: crate::lower::model::Ex, f_p2: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppFieldOf { cp_p0, r_p1, f_p2 })
}

/// ```prism
/// AsValue: unbounded fn Cp, Ex -> Text
/// ```
pub fn as_value_f(cp_p0: &crate::emit::cpp::Cp, r_p1: &crate::lower::model::Ex) -> crate::prelude::Text {
    match pointer_o(cp_p0, r_p1) {
        ::std::option::Option::Some(false) => cpp_tight_place_f(cp_p0, r_p1),
        _ => crate::prelude::Text::from(format!("::prism_rtl::deref({})", &cpp_place_f(cp_p0, r_p1))),
    }
}

/// The step machine of `AsValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AsValue: unbounded fn Cp, Ex -> Text
/// ```
pub struct AsValue {
    pub cp_p0: crate::emit::cpp::Cp,
    pub r_p1: crate::lower::model::Ex,
}

impl ::prism_rtl::Job<crate::prelude::Text> for AsValue {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let r_p1 = &self.r_p1;
        match pointer_o(cp_p0, r_p1) {
            ::std::option::Option::Some(false) => ::prism_rtl::Turn::More(::std::rc::Rc::new(CppTightPlace { cp_p0: cp_p0.clone(), x_p1: r_p1.clone() })),
            _ => {
                let cp_p0x = cp_p0.clone();
                let r_p1x = r_p1.clone();
                crate::prelude::call_then(start_cpp_place_f(cp_p0x.clone(), r_p1x.clone()), move |cpp_place_f_13259: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::prism_rtl::deref({})", &cpp_place_f_13259))))
            },
        }
    }
}

/// `Start AsValue, x`: what the function value is when passed to `@Run`.
pub fn start_as_value_f(cp_p0: crate::emit::cpp::Cp, r_p1: crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(AsValue { cp_p0, r_p1 })
}

/// ```prism
/// ?ExTy: fn Cp, Ex -> ?OutTy
/// ```
pub fn ex_ty_o(cp_p0: &crate::emit::cpp::Cp, x_p1: &crate::lower::model::Ex) -> ::std::option::Option<crate::lower::model::OutTy> {
    'm13496: {
        if let crate::lower::model::Ex::XVar(n_p2) = x_p1 {
            break 'm13496 crate::prelude::get(&cp_p0.local_types_p, n_p2);
        }
        if let crate::lower::model::Ex::XField(m13496_1_0, f_p3) = x_p1 && let crate::lower::model::Ex::XSelf = &**m13496_1_0 {
            break 'm13496 crate::prelude::get(&cp_p0.fields_p, f_p3);
        }
        if let crate::lower::model::Ex::XField(m13496_2_0, f_p4) = x_p1 && let crate::lower::model::Ex::XVar(m13496_2_0_r_0) = &**m13496_2_0 && (m13496_2_0_r_0 == &crate::prelude::Text::lit("node")) {
            break 'm13496 crate::prelude::get(&cp_p0.fields_p, f_p4);
        }
        if let crate::lower::model::Ex::XRef(y_p5) = x_p1 {
            break 'm13496 match ex_ty_o(cp_p0, &**y_p5) {
                ::std::option::Option::Some(t_p6) => ::std::option::Option::Some(crate::lower::model::OutTy::OutRef(::std::rc::Rc::new(t_p6))),
                ::std::option::Option::None => ::std::option::Option::None,
            };
        }
        if let crate::lower::model::Ex::XDeref(y_p7) = x_p1 {
            break 'm13496 match ex_ty_o(cp_p0, &**y_p7) {
                ::std::option::Option::Some(crate::lower::model::OutTy::OutRef(t_p8)) => ::std::option::Option::Some((*t_p8).clone()),
                ::std::option::Option::Some(crate::lower::model::OutTy::OutRc(t_p9)) => ::std::option::Option::Some((*t_p9).clone()),
                _ => ::std::option::Option::None,
            };
        }
        ::std::option::Option::None
    }
}

/// ```prism
/// IsDigits: fn Text -> Bool
/// ```
pub fn is_digits_f(t_p0: &crate::prelude::Text) -> bool {
    (t_p0 != &crate::prelude::Text::lit("")) && crate::syntax::lexer::chars::fold_chars_f(t_p0, &true, &(::std::rc::Rc::new(move |(p0, p1): (bool, crate::prelude::Text)| crate::prelude::once_job(move || {
        let ok_p1 = p0;
        let c_p2 = p1;
        ::prism_rtl::Turn::Finished(ok_p1 && crate::syntax::lexer::chars::contains_f(&crate::prelude::Text::lit("0123456789"), &c_p2))
    })) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>))
}

/// ```prism
/// CppCtor: unbounded fn Cp, Ref, [Ex] -> Text
/// ```
pub fn cpp_ctor_f(cp_p0: &crate::emit::cpp::Cp, r_p1: &crate::lower::model::Ref, args_p2: &crate::prelude::Array<crate::lower::model::Ex>) -> crate::prelude::Text {
    match r_p1 {
        crate::lower::model::Ref::RefRuntime(t_p3) => match crate::emit::cpp::bare_f(t_p3) {
            m14154_0 if (&m14154_0 == &crate::prelude::Text::lit("Some")) => crate::prelude::Text::from(format!("::std::optional({})", &cpp_args_f(cp_p0, args_p2))),
            m14154_1 if (&m14154_1 == &crate::prelude::Text::lit("Ok")) => if args_p2 == &crate::prelude::Array::from(vec![crate::lower::model::Ex::XUnit]) {
                crate::prelude::Text::lit("::prism_rtl::ok()")
            } else {
                cpp_args_f(cp_p0, args_p2)
            },
            m14154_2 if (&m14154_2 == &crate::prelude::Text::lit("Err")) => crate::prelude::Text::from(format!("crate::prelude::unexpected({})", &cpp_args_f(cp_p0, args_p2))),
            m14154_3 if (&m14154_3 == &crate::prelude::Text::lit("prism_rtl::Turn::More")) => crate::prelude::Text::from(format!("::prism_rtl::more({})", &cpp_args_f(cp_p0, args_p2))),
            m14154_4 if (&m14154_4 == &crate::prelude::Text::lit("prism_rtl::Turn::Finished")) => crate::prelude::Text::from(format!("::prism_rtl::finished({})", &cpp_args_f(cp_p0, args_p2))),
            m14154_5 if (&m14154_5 == &crate::prelude::Text::lit("Outcome::Fired")) => crate::prelude::Text::from(format!("crate::prelude::Outcome::fired({})", &cpp_args_f(cp_p0, args_p2))),
            m14154_6 if (&m14154_6 == &crate::prelude::Text::lit("Outcome::Value")) => crate::prelude::Text::from(format!("crate::prelude::Outcome::value({})", &cpp_args_f(cp_p0, args_p2))),
            m14154_7 if (&m14154_7 == &crate::prelude::Text::lit("Segment::Pos")) => crate::prelude::Text::from(format!("crate::prelude::Segment::pos({})", &cpp_args_f(cp_p0, args_p2))),
            m14154_8 if (&m14154_8 == &crate::prelude::Text::lit("Segment::Gen")) => crate::prelude::Text::from(format!("crate::prelude::Segment::gen({})", &cpp_args_f(cp_p0, args_p2))),
            m14154_9 if (&m14154_9 == &crate::prelude::Text::lit("Segment::Key")) => crate::prelude::Text::from(format!("crate::prelude::Segment::key({})", &cpp_args_f(cp_p0, args_p2))),
            _ => crate::prelude::Text::from(format!("{}{{{}}}", &crate::emit::cpp::type_path_f(&crate::lower::model::runtime_path_f(t_p3)), &cpp_args_f(cp_p0, args_p2))),
            _ => unreachable!("no arm matched"),
        },
        _ => match crate::emit::cpp::case_of_o(cp_p0, r_p1) {
            ::std::option::Option::Some(ty_p4) => crate::prelude::Text::from(format!("{}({}{{{}}})", &crate::emit::cpp::own_type_path_f(cp_p0, &ty_p4), &crate::emit::cpp::own_type_path_f(cp_p0, r_p1), &cpp_args_f(cp_p0, args_p2))),
            ::std::option::Option::None => match crate::emit::cpp::type_of_o(cp_p0, r_p1) {
                ::std::option::Option::Some(_) => crate::prelude::Text::from(format!("{}{{{}}}", &crate::emit::cpp::own_type_path_f(cp_p0, r_p1), &cpp_args_f(cp_p0, args_p2))),
                ::std::option::Option::None => crate::emit::cpp::printer_refusal_f(&crate::prelude::Text::from(format!("a constructor of no type it knows ({})", &crate::lower::model::ref_spelled_f(r_p1)))),
            },
        },
    }
}

/// The step machine of `CppCtor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppCtor: unbounded fn Cp, Ref, [Ex] -> Text
/// ```
pub struct CppCtor {
    pub cp_p0: crate::emit::cpp::Cp,
    pub r_p1: crate::lower::model::Ref,
    pub args_p2: crate::prelude::Array<crate::lower::model::Ex>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppCtor {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let r_p1 = &self.r_p1;
        let args_p2 = &self.args_p2;
        match r_p1 {
            crate::lower::model::Ref::RefRuntime(t_p3) => match crate::emit::cpp::bare_f(t_p3) {
                m14154_0 if (&m14154_0 == &crate::prelude::Text::lit("Some")) => {
                    let args_p2x = args_p2.clone();
                    let cp_p0x = cp_p0.clone();
                    crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p2x.clone()), move |cpp_args_f_14202: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::std::optional({})", &cpp_args_f_14202))))
                },
                m14154_1 if (&m14154_1 == &crate::prelude::Text::lit("Ok")) => if args_p2 == &crate::prelude::Array::from(vec![crate::lower::model::Ex::XUnit]) {
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("::prism_rtl::ok()"))
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(CppArgs { cp_p0: cp_p0.clone(), xs_p1: args_p2.clone() }))
                },
                m14154_2 if (&m14154_2 == &crate::prelude::Text::lit("Err")) => {
                    let args_p2x = args_p2.clone();
                    let cp_p0x = cp_p0.clone();
                    crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p2x.clone()), move |cpp_args_f_14345: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::unexpected({})", &cpp_args_f_14345))))
                },
                m14154_3 if (&m14154_3 == &crate::prelude::Text::lit("prism_rtl::Turn::More")) => {
                    let args_p2x = args_p2.clone();
                    let cp_p0x = cp_p0.clone();
                    crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p2x.clone()), move |cpp_args_f_14418: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::prism_rtl::more({})", &cpp_args_f_14418))))
                },
                m14154_4 if (&m14154_4 == &crate::prelude::Text::lit("prism_rtl::Turn::Finished")) => {
                    let args_p2x = args_p2.clone();
                    let cp_p0x = cp_p0.clone();
                    crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p2x.clone()), move |cpp_args_f_14499: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::prism_rtl::finished({})", &cpp_args_f_14499))))
                },
                m14154_5 if (&m14154_5 == &crate::prelude::Text::lit("Outcome::Fired")) => {
                    let args_p2x = args_p2.clone();
                    let cp_p0x = cp_p0.clone();
                    crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p2x.clone()), move |cpp_args_f_14578: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Outcome::fired({})", &cpp_args_f_14578))))
                },
                m14154_6 if (&m14154_6 == &crate::prelude::Text::lit("Outcome::Value")) => {
                    let args_p2x = args_p2.clone();
                    let cp_p0x = cp_p0.clone();
                    crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p2x.clone()), move |cpp_args_f_14657: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Outcome::value({})", &cpp_args_f_14657))))
                },
                m14154_7 if (&m14154_7 == &crate::prelude::Text::lit("Segment::Pos")) => {
                    let args_p2x = args_p2.clone();
                    let cp_p0x = cp_p0.clone();
                    crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p2x.clone()), move |cpp_args_f_14732: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Segment::pos({})", &cpp_args_f_14732))))
                },
                m14154_8 if (&m14154_8 == &crate::prelude::Text::lit("Segment::Gen")) => {
                    let args_p2x = args_p2.clone();
                    let cp_p0x = cp_p0.clone();
                    crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p2x.clone()), move |cpp_args_f_14807: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Segment::gen({})", &cpp_args_f_14807))))
                },
                m14154_9 if (&m14154_9 == &crate::prelude::Text::lit("Segment::Key")) => {
                    let args_p2x = args_p2.clone();
                    let cp_p0x = cp_p0.clone();
                    crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p2x.clone()), move |cpp_args_f_14882: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Segment::key({})", &cpp_args_f_14882))))
                },
                _ => {
                    let args_p2x = args_p2.clone();
                    let cp_p0x = cp_p0.clone();
                    let t_p3x = t_p3.clone();
                    crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p2x.clone()), move |cpp_args_f_15017: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{{{}}}", &crate::emit::cpp::type_path_f(&crate::lower::model::runtime_path_f(&t_p3x)), &cpp_args_f_15017))))
                },
                _ => unreachable!("no arm matched"),
            },
            _ => match crate::emit::cpp::case_of_o(cp_p0, r_p1) {
                ::std::option::Option::Some(ty_p4) => {
                    let args_p2x = args_p2.clone();
                    let cp_p0x = cp_p0.clone();
                    let r_p1x = r_p1.clone();
                    crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p2x.clone()), move |cpp_args_f_15132: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}({}{{{}}})", &crate::emit::cpp::own_type_path_f(&cp_p0x, &ty_p4), &crate::emit::cpp::own_type_path_f(&cp_p0x, &r_p1x), &cpp_args_f_15132))))
                },
                ::std::option::Option::None => match crate::emit::cpp::type_of_o(cp_p0, r_p1) {
                    ::std::option::Option::Some(_) => {
                        let args_p2x = args_p2.clone();
                        let cp_p0x = cp_p0.clone();
                        let r_p1x = r_p1.clone();
                        crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p2x.clone()), move |cpp_args_f_15233: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{{{}}}", &crate::emit::cpp::own_type_path_f(&cp_p0x, &r_p1x), &cpp_args_f_15233))))
                    },
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::emit::cpp::printer_refusal_f(&crate::prelude::Text::from(format!("a constructor of no type it knows ({})", &crate::lower::model::ref_spelled_f(r_p1))))),
                },
            },
        }
    }
}

/// `Start CppCtor, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_ctor_f(cp_p0: crate::emit::cpp::Cp, r_p1: crate::lower::model::Ref, args_p2: crate::prelude::Array<crate::lower::model::Ex>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppCtor { cp_p0, r_p1, args_p2 })
}

/// ```prism
/// CppRecord: unbounded fn Cp, Ref, [((Text, Ex))] -> Text
/// ```
pub fn cpp_record_f(cp_p0: &crate::emit::cpp::Cp, p_p1: &crate::lower::model::Ref, fs_p2: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>) -> crate::prelude::Text {
    cpp_record_as_f(cp_p0, p_p1, fs_p2, &crate::emit::cpp::own_type_path_f(cp_p0, p_p1))
}

/// The step machine of `CppRecord`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppRecord: unbounded fn Cp, Ref, [((Text, Ex))] -> Text
/// ```
pub struct CppRecord {
    pub cp_p0: crate::emit::cpp::Cp,
    pub p_p1: crate::lower::model::Ref,
    pub fs_p2: crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppRecord {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let p_p1 = &self.p_p1;
        let fs_p2 = &self.fs_p2;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(CppRecordAs { cp_p0: cp_p0.clone(), p_p1: p_p1.clone(), fs_p2: fs_p2.clone(), head_p3: crate::emit::cpp::own_type_path_f(cp_p0, p_p1) }))
    }
}

/// `Start CppRecord, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_record_f(cp_p0: crate::emit::cpp::Cp, p_p1: crate::lower::model::Ref, fs_p2: crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppRecord { cp_p0, p_p1, fs_p2 })
}

/// ```prism
/// CppRecordAs: unbounded fn Cp, Ref, [((Text, Ex))], Text -> Text
/// ```
pub fn cpp_record_as_f(cp_p0: &crate::emit::cpp::Cp, p_p1: &crate::lower::model::Ref, fs_p2: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>, head_p3: &crate::prelude::Text) -> crate::prelude::Text {
    match crate::emit::cpp::type_of_o(cp_p0, p_p1) {
        ::std::option::Option::Some(info_p4) => {
            let ordered_p5 = crate::prelude::each(&info_p4.fields_p, &(|f_p7: &crate::prelude::Text| crate::prelude::or(&crate::prelude::fold(fs_p2, &::std::option::Option::None, &(|found_o8: &::std::option::Option<crate::lower::model::Ex>, (g_p9, v_pa): &(crate::prelude::Text, crate::lower::model::Ex)| if g_p9 == f_p7 { ::std::option::Option::Some(v_pa.clone()) } else { found_o8.clone() })), &crate::lower::model::Ex::XUnit)));
            let values_p6 = cpp_arg_list_f(cp_p0, &ordered_p5);
            if &info_p4.kind_p == &crate::prelude::Text::lit("job") {
                crate::prelude::Text::from(format!("{}({})", &crate::emit::cpp::type_path_f(&crate::lower::model::ref_spelled_f(p_p1)), &crate::syntax::lexer::chars::join_f(&values_p6, &crate::prelude::Text::lit(", "))))
            } else {
                crate::prelude::Text::from(format!("{}{{{}}}", head_p3, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&info_p4.fields_p)), &(|i_pb: &crate::prelude::Nat| crate::prelude::Text::from(format!(".{} = {}", &crate::emit::cpp::field_id_f(&crate::prelude::or(&crate::prelude::index(&info_p4.fields_p, i_pb), &crate::prelude::Text::lit(""))), &crate::prelude::or(&crate::prelude::index(&values_p6, i_pb), &crate::prelude::Text::lit("")))))), &crate::prelude::Text::lit(", "))))
            }
        },
        ::std::option::Option::None => crate::emit::cpp::printer_refusal_f(&crate::prelude::Text::from(format!("a record of no type it knows ({})", &crate::lower::model::ref_spelled_f(p_p1)))),
    }
}

/// The step machine of `CppRecordAs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppRecordAs: unbounded fn Cp, Ref, [((Text, Ex))], Text -> Text
/// ```
pub struct CppRecordAs {
    pub cp_p0: crate::emit::cpp::Cp,
    pub p_p1: crate::lower::model::Ref,
    pub fs_p2: crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>,
    pub head_p3: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppRecordAs {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let p_p1 = &self.p_p1;
        let fs_p2 = &self.fs_p2;
        let head_p3 = &self.head_p3;
        match crate::emit::cpp::type_of_o(cp_p0, p_p1) {
            ::std::option::Option::Some(info_p4) => {
                let ordered_p5 = crate::prelude::each(&info_p4.fields_p, &(|f_p7: &crate::prelude::Text| crate::prelude::or(&crate::prelude::fold(fs_p2, &::std::option::Option::None, &(|found_o8: &::std::option::Option<crate::lower::model::Ex>, (g_p9, v_pa): &(crate::prelude::Text, crate::lower::model::Ex)| if g_p9 == f_p7 { ::std::option::Option::Some(v_pa.clone()) } else { found_o8.clone() })), &crate::lower::model::Ex::XUnit)));
                let cp_p0x = cp_p0.clone();
                let head_p3x = head_p3.clone();
                let p_p1x = p_p1.clone();
                crate::prelude::call_then(start_cpp_arg_list_f(cp_p0x.clone(), ordered_p5.clone()), move |cpp_arg_list_f_15888: crate::prelude::Array<crate::prelude::Text>| {
                    let values_p6 = cpp_arg_list_f_15888;
                    if &info_p4.kind_p == &crate::prelude::Text::lit("job") {
                        ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}({})", &crate::emit::cpp::type_path_f(&crate::lower::model::ref_spelled_f(&p_p1x)), &crate::syntax::lexer::chars::join_f(&values_p6, &crate::prelude::Text::lit(", ")))))
                    } else {
                        ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{{{}}}", &head_p3x, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&info_p4.fields_p)), &(|i_pb: &crate::prelude::Nat| crate::prelude::Text::from(format!(".{} = {}", &crate::emit::cpp::field_id_f(&crate::prelude::or(&crate::prelude::index(&info_p4.fields_p, i_pb), &crate::prelude::Text::lit(""))), &crate::prelude::or(&crate::prelude::index(&values_p6, i_pb), &crate::prelude::Text::lit("")))))), &crate::prelude::Text::lit(", ")))))
                    }
                })
            },
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::emit::cpp::printer_refusal_f(&crate::prelude::Text::from(format!("a record of no type it knows ({})", &crate::lower::model::ref_spelled_f(p_p1))))),
        }
    }
}

/// `Start CppRecordAs, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_record_as_f(cp_p0: crate::emit::cpp::Cp, p_p1: crate::lower::model::Ref, fs_p2: crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Ex)>, head_p3: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppRecordAs { cp_p0, p_p1, fs_p2, head_p3 })
}

/// ```prism
/// CppCall: unbounded fn Cp, Ref, [Ex] -> Text
/// ```
pub fn cpp_call_f(cp_p0: &crate::emit::cpp::Cp, f_p1: &crate::lower::model::Ref, args_p2: &crate::prelude::Array<crate::lower::model::Ex>) -> crate::prelude::Text {
    let a_p3 = cpp_args_f(cp_p0, args_p2);
    let runtime_name_p4 = match f_p1 {
        crate::lower::model::Ref::RefRuntime(t_p5) => crate::emit::cpp::bare_f(t_p5),
        crate::lower::model::Ref::RefItem(m16540_1_0, p_p6, _) if (m16540_1_0 == &crate::prelude::Text::lit("prelude")) => p_p6.clone(),
        _ => crate::prelude::Text::lit(""),
        _ => unreachable!("no arm matched"),
    };
    match &runtime_name_p4 {
        m16644_0 if (m16644_0 == &crate::prelude::Text::lit("Rc::new")) => if &a_p3 == &crate::prelude::Text::lit("{}") {
            crate::prelude::Text::lit("::prism_rtl::make_new()")
        } else {
            crate::prelude::Text::from(format!("::prism_rtl::rc({})", &a_p3))
        },
        m16644_1 if (m16644_1 == &crate::prelude::Text::lit("is_some")) => crate::prelude::Text::from(format!("::prism_rtl::is_some({})", &a_p3)),
        m16644_2 if (m16644_2 == &crate::prelude::Text::lit("is_none")) => crate::prelude::Text::from(format!("::prism_rtl::is_none({})", &a_p3)),
        m16644_3 if (m16644_3 == &crate::prelude::Text::lit("RefCell::new")) => a_p3.clone(),
        m16644_4 if (m16644_4 == &crate::prelude::Text::lit("Cell::new")) => a_p3.clone(),
        m16644_5 if (m16644_5 == &crate::prelude::Text::lit("Hold::new")) => crate::prelude::Text::from(format!("{{{}}}", &a_p3)),
        m16644_6 if (m16644_6 == &crate::prelude::Text::lit("Heights::new")) => crate::prelude::Text::from(format!("crate::prelude::Heights({})", &a_p3)),
        m16644_7 if (m16644_7 == &crate::prelude::Text::lit("Snapshot::new")) => crate::prelude::Text::from(format!("crate::prelude::snapshot({})", &a_p3)),
        m16644_8 if (m16644_8 == &crate::prelude::Text::lit("Path::root")) => crate::prelude::Text::lit("crate::prelude::Path::root()"),
        m16644_9 if (m16644_9 == &crate::prelude::Text::lit("Fault::answer")) => crate::prelude::Text::from(format!("crate::prelude::Fault::answer({})", &a_p3)),
        m16644_10 if (m16644_10 == &crate::prelude::Text::lit("Fault::too_deep")) => crate::prelude::Text::from(format!("crate::prelude::Fault::too_deep({})", &a_p3)),
        m16644_11 if (m16644_11 == &crate::prelude::Text::lit("Error::new")) => crate::prelude::Text::from(format!("crate::prelude::Error({})", &a_p3)),
        m16644_12 if (m16644_12 == &crate::prelude::Text::lit("Text::from")) => crate::prelude::Text::from(format!("crate::prelude::Text({})", &a_p3)),
        m16644_13 if (m16644_13 == &crate::prelude::Text::lit("String::new")) => crate::prelude::Text::lit("::std::string()"),
        m16644_14 if (m16644_14 == &crate::prelude::Text::lit("Array::from")) => crate::prelude::Text::from(format!("crate::prelude::Array({})", &a_p3)),
        m16644_15 if (m16644_15 == &crate::prelude::Text::lit("prism_rtl::Dynamic::of")) => crate::prelude::Text::from(format!("::prism_rtl::dynamic_of({})", &a_p3)),
        m16644_16 if (m16644_16 == &crate::prelude::Text::lit("Dynamic::of")) => crate::prelude::Text::from(format!("::prism_rtl::dynamic_of({})", &a_p3)),
        m16644_17 if (m16644_17 == &crate::prelude::Text::lit("prism_rtl::Event::of")) => crate::prelude::Text::from(format!("::prism_rtl::event_of({})", &a_p3)),
        m16644_18 if (m16644_18 == &crate::prelude::Text::lit("prism_rtl::Host::new")) => crate::prelude::Text::from(format!("crate::prelude::host_new({})", &a_p3)),
        m16644_19 if (m16644_19 == &crate::prelude::Text::lit("prism_rtl::Entry::new")) => crate::prelude::Text::from(format!("crate::prelude::entry_new({})", &a_p3)),
        m16644_20 if (m16644_20 == &crate::prelude::Text::lit("prism_rtl::forward_on_none")) => crate::prelude::Text::from(format!("::prism_rtl::forward_on_none<crate::Elem, crate::Answer>({})", &a_p3)),
        m16644_21 if (m16644_21 == &crate::prelude::Text::lit("Event::never")) => crate::prelude::Text::lit("::prism_rtl::never_event()"),
        _ => if is_fresh_f(f_p1) {
            crate::prelude::Text::lit("{}")
        } else {
            crate::prelude::Text::from(format!("{}({})", &free_call_path_f(cp_p0, f_p1), &a_p3))
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CppCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppCall: unbounded fn Cp, Ref, [Ex] -> Text
/// ```
pub struct CppCall {
    pub cp_p0: crate::emit::cpp::Cp,
    pub f_p1: crate::lower::model::Ref,
    pub args_p2: crate::prelude::Array<crate::lower::model::Ex>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppCall {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let f_p1 = &self.f_p1;
        let args_p2 = &self.args_p2;
        let args_p2x = args_p2.clone();
        let cp_p0x = cp_p0.clone();
        let f_p1x = f_p1.clone();
        crate::prelude::call_then(start_cpp_args_f(cp_p0x.clone(), args_p2x.clone()), move |cpp_args_f_16501: crate::prelude::Text| {
            let a_p3 = cpp_args_f_16501;
            let runtime_name_p4 = match &f_p1x {
                crate::lower::model::Ref::RefRuntime(t_p5) => crate::emit::cpp::bare_f(t_p5),
                crate::lower::model::Ref::RefItem(m16540_1_0, p_p6, _) if (m16540_1_0 == &crate::prelude::Text::lit("prelude")) => p_p6.clone(),
                _ => crate::prelude::Text::lit(""),
                _ => unreachable!("no arm matched"),
            };
            match &runtime_name_p4 {
                m16644_0 if (m16644_0 == &crate::prelude::Text::lit("Rc::new")) => if &a_p3 == &crate::prelude::Text::lit("{}") {
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("::prism_rtl::make_new()"))
                } else {
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::prism_rtl::rc({})", &a_p3)))
                },
                m16644_1 if (m16644_1 == &crate::prelude::Text::lit("is_some")) => ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::prism_rtl::is_some({})", &a_p3))),
                m16644_2 if (m16644_2 == &crate::prelude::Text::lit("is_none")) => ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::prism_rtl::is_none({})", &a_p3))),
                m16644_3 if (m16644_3 == &crate::prelude::Text::lit("RefCell::new")) => ::prism_rtl::Turn::Finished(a_p3.clone()),
                m16644_4 if (m16644_4 == &crate::prelude::Text::lit("Cell::new")) => ::prism_rtl::Turn::Finished(a_p3.clone()),
                m16644_5 if (m16644_5 == &crate::prelude::Text::lit("Hold::new")) => ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{{{}}}", &a_p3))),
                m16644_6 if (m16644_6 == &crate::prelude::Text::lit("Heights::new")) => ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Heights({})", &a_p3))),
                m16644_7 if (m16644_7 == &crate::prelude::Text::lit("Snapshot::new")) => ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::snapshot({})", &a_p3))),
                m16644_8 if (m16644_8 == &crate::prelude::Text::lit("Path::root")) => ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Path::root()")),
                m16644_9 if (m16644_9 == &crate::prelude::Text::lit("Fault::answer")) => ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Fault::answer({})", &a_p3))),
                m16644_10 if (m16644_10 == &crate::prelude::Text::lit("Fault::too_deep")) => ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Fault::too_deep({})", &a_p3))),
                m16644_11 if (m16644_11 == &crate::prelude::Text::lit("Error::new")) => ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Error({})", &a_p3))),
                m16644_12 if (m16644_12 == &crate::prelude::Text::lit("Text::from")) => ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Text({})", &a_p3))),
                m16644_13 if (m16644_13 == &crate::prelude::Text::lit("String::new")) => ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("::std::string()")),
                m16644_14 if (m16644_14 == &crate::prelude::Text::lit("Array::from")) => ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Array({})", &a_p3))),
                m16644_15 if (m16644_15 == &crate::prelude::Text::lit("prism_rtl::Dynamic::of")) => ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::prism_rtl::dynamic_of({})", &a_p3))),
                m16644_16 if (m16644_16 == &crate::prelude::Text::lit("Dynamic::of")) => ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::prism_rtl::dynamic_of({})", &a_p3))),
                m16644_17 if (m16644_17 == &crate::prelude::Text::lit("prism_rtl::Event::of")) => ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::prism_rtl::event_of({})", &a_p3))),
                m16644_18 if (m16644_18 == &crate::prelude::Text::lit("prism_rtl::Host::new")) => ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::host_new({})", &a_p3))),
                m16644_19 if (m16644_19 == &crate::prelude::Text::lit("prism_rtl::Entry::new")) => ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::entry_new({})", &a_p3))),
                m16644_20 if (m16644_20 == &crate::prelude::Text::lit("prism_rtl::forward_on_none")) => ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::prism_rtl::forward_on_none<crate::Elem, crate::Answer>({})", &a_p3))),
                m16644_21 if (m16644_21 == &crate::prelude::Text::lit("Event::never")) => ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("::prism_rtl::never_event()")),
                _ => if is_fresh_f(&f_p1x) {
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("{}"))
                } else {
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}({})", &free_call_path_f(&cp_p0x, &f_p1x), &a_p3)))
                },
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start CppCall, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_call_f(cp_p0: crate::emit::cpp::Cp, f_p1: crate::lower::model::Ref, args_p2: crate::prelude::Array<crate::lower::model::Ex>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppCall { cp_p0, f_p1, args_p2 })
}

/// ```prism
/// FreeCallPath: fn Cp, Ref -> Text
/// ```
pub fn free_call_path_f(cp_p0: &crate::emit::cpp::Cp, f_p1: &crate::lower::model::Ref) -> crate::prelude::Text {
    let p_p2 = call_path_f(cp_p0, f_p1);
    let hidden_p3 = match crate::prelude::get(&cp_p0.members_p, &crate::lower::model::ref_spelled_f(f_p1)) {
        ::std::option::Option::Some(_) => true,
        ::std::option::Option::None => crate::emit::cpp::in_list_f(&cp_p0.mods_p, &p_p2),
    };
    if crate::syntax::lexer::chars::contains_f(&p_p2, &crate::prelude::Text::lit(":")) {
        p_p2.clone()
    } else {
        if hidden_p3 { qualified_call_f(f_p1, &p_p2) } else { p_p2.clone() }
    }
}

/// ```prism
/// QualifiedCall: fn Ref, Text -> Text
/// ```
pub fn qualified_call_f(ref_0: &crate::lower::model::Ref, p_p1: &crate::prelude::Text) -> crate::prelude::Text {
    match ref_0 {
        crate::lower::model::Ref::RefItem(m_p0, _, _) => crate::prelude::Text::from(format!("crate::{}::{}", m_p0, p_p1)),
        crate::lower::model::Ref::RefRuntime(_) => p_p1.clone(),
    }
}

/// ```prism
/// IsFresh: fn Ref -> Bool
/// ```
pub fn is_fresh_f(ref_0: &crate::lower::model::Ref) -> bool {
    match ref_0 {
        crate::lower::model::Ref::RefRuntime(f_p0) => crate::emit::cpp::in_list_f(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("rt::Stamped::new"), crate::prelude::Text::lit("rt::Cache::new"), crate::prelude::Text::lit("rt::Port::new"), crate::prelude::Text::lit("rt::Map::new"), crate::prelude::Text::lit("rt::Array::new"), crate::prelude::Text::lit("std::Vec::new"), crate::prelude::Text::lit("std::Default::default"), crate::prelude::Text::lit("rt::Defer::new"), crate::prelude::Text::lit("prism_rtl::LaterQueue::new"), crate::prelude::Text::lit("prism_rtl::HostDoc::new"), crate::prelude::Text::lit("prism_rtl::Watch::new"), crate::prelude::Text::lit("prism_rtl::PerKey::new")]), f_p0),
        other_p1 => false,
    }
}

/// ```prism
/// CallPath: fn Cp, Ref -> Text
/// ```
pub fn call_path_f(cp_p0: &crate::emit::cpp::Cp, f_p1: &crate::lower::model::Ref) -> crate::prelude::Text {
    match f_p1 {
        crate::lower::model::Ref::RefItem(_, _, s_p2) => if (&crate::lower::model::ref_last_f(f_p1) == &crate::prelude::Text::lit("build")) && is_node_type_f(cp_p0, &crate::lower::model::ref_parent_f(f_p1)) {
            crate::prelude::Text::from(format!("{}::make", &crate::emit::cpp::type_path_f(&crate::lower::model::ref_spelled_f(&crate::lower::model::ref_parent_f(f_p1)))))
        } else {
            crate::emit::cpp::cpp_path_id_f(&crate::emit::cpp::type_path_f(s_p2))
        },
        crate::lower::model::Ref::RefRuntime(t_p3) => if &crate::emit::cpp::last_segment_f(t_p3) == &crate::prelude::Text::lit("new") {
            crate::emit::cpp::type_path_f(&crate::lower::model::runtime_path_f(&crate::emit::cpp::parent_path_f(t_p3)))
        } else {
            crate::emit::cpp::cpp_path_id_f(&crate::emit::cpp::type_path_f(&crate::lower::model::runtime_path_f(t_p3)))
        },
    }
}

/// ```prism
/// CppMethod: unbounded fn Cp, Ex, Text, [Ex] -> Text
/// ```
pub fn cpp_method_f(cp_p0: &crate::emit::cpp::Cp, r_p1: &crate::lower::model::Ex, m_p2: &crate::prelude::Text, args_p3: &crate::prelude::Array<crate::lower::model::Ex>) -> crate::prelude::Text {
    let recv_p4 = if r_p1 == &crate::lower::model::Ex::XSelf {
        crate::prelude::Text::lit("this")
    } else {
        cpp_tight_place_f(cp_p0, r_p1)
    };
    let a_p5 = cpp_args_f(cp_p0, args_p3);
    let n_p6 = crate::prelude::len(args_p3);
    let sep_p7 = if &n_p6 == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::lit("")
    } else {
        crate::prelude::Text::lit(", ")
    };
    match method_form_f(m_p2, &n_p6) {
        m19803_0 if (&m19803_0 == &crate::prelude::Text::lit("id")) => recv_p4.clone(),
        m19803_1 if (&m19803_1 == &crate::prelude::Text::lit("deref")) => match pointer_o(cp_p0, r_p1) {
            ::std::option::Option::Some(b_p8) => if b_p8 {
                crate::prelude::Text::from(format!("(*{})", &recv_p4))
            } else {
                recv_p4.clone()
            },
            ::std::option::Option::None => recv_p4.clone(),
        },
        m19803_2 if (&m19803_2 == &crate::prelude::Text::lit("assign")) => crate::prelude::Text::from(format!("{} = {}", &recv_p4, &a_p5)),
        m19803_3 if (&m19803_3 == &crate::prelude::Text::lit("take")) => crate::prelude::Text::from(format!("::std::exchange({}, {{}})", &recv_p4)),
        m19803_4 if (&m19803_4 == &crate::prelude::Text::lit("free")) => crate::prelude::Text::from(format!("{}({}{}{})", &free_name_f(m_p2), &recv_p4, &sep_p7, &a_p5)),
        m19803_5 if (&m19803_5 == &crate::prelude::Text::lit("arrow")) => {
            let through_p9 = match pointer_o(cp_p0, r_p1) {
                ::std::option::Option::Some(b_pa) => if b_pa { crate::prelude::Text::lit("->") } else { crate::prelude::Text::lit(".") },
                ::std::option::Option::None => crate::prelude::Text::lit("->"),
            };
            crate::prelude::Text::from(format!("{}{}{}({})", &recv_p4, &through_p9, &member_name_f(m_p2), &a_p5))
        },
        m19803_6 if (&m19803_6 == &crate::prelude::Text::lit("exchange")) => crate::prelude::Text::from(format!("::std::exchange({}, {})", &recv_p4, &a_p5)),
        _ => {
            let through_pb = match pointer_o(cp_p0, r_p1) {
                ::std::option::Option::Some(b_pc) => if b_pc { crate::prelude::Text::lit("->") } else { crate::prelude::Text::lit(".") },
                ::std::option::Option::None => match crate::prelude::get(&cp_p0.members_p, m_p2) {
                    ::std::option::Option::Some(_) => crate::prelude::Text::lit("->"),
                    ::std::option::Option::None => crate::prelude::Text::lit("."),
                },
            };
            crate::prelude::Text::from(format!("{}{}{}({})", &recv_p4, &through_pb, &node_method_name_f(cp_p0, m_p2), &a_p5))
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CppMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppMethod: unbounded fn Cp, Ex, Text, [Ex] -> Text
/// ```
pub struct CppMethod {
    pub cp_p0: crate::emit::cpp::Cp,
    pub r_p1: crate::lower::model::Ex,
    pub m_p2: crate::prelude::Text,
    pub args_p3: crate::prelude::Array<crate::lower::model::Ex>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppMethod {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let r_p1 = &self.r_p1;
        let m_p2 = &self.m_p2;
        let args_p3 = &self.args_p3;
        let args_p3z = args_p3.clone();
        let cp_p0z = cp_p0.clone();
        let m_p2z = m_p2.clone();
        let r_p1z = r_p1.clone();
        let k_let19651 = move |v19651: crate::prelude::Text| {
            let recv_p4 = v19651;
            crate::prelude::call_then(start_cpp_args_f(cp_p0z.clone(), args_p3z.clone()), move |cpp_args_f_19722: crate::prelude::Text| {
                let a_p5 = cpp_args_f_19722;
                let n_p6 = crate::prelude::len(&args_p3z);
                let sep_p7 = if &n_p6 == &crate::prelude::Nat::from(0u32) {
                    crate::prelude::Text::lit("")
                } else {
                    crate::prelude::Text::lit(", ")
                };
                match method_form_f(&m_p2z, &n_p6) {
                    m19803_0 if (&m19803_0 == &crate::prelude::Text::lit("id")) => ::prism_rtl::Turn::Finished(recv_p4.clone()),
                    m19803_1 if (&m19803_1 == &crate::prelude::Text::lit("deref")) => match pointer_o(&cp_p0z, &r_p1z) {
                        ::std::option::Option::Some(b_p8) => if b_p8 {
                            ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("(*{})", &recv_p4)))
                        } else {
                            ::prism_rtl::Turn::Finished(recv_p4.clone())
                        },
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(recv_p4.clone()),
                    },
                    m19803_2 if (&m19803_2 == &crate::prelude::Text::lit("assign")) => ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} = {}", &recv_p4, &a_p5))),
                    m19803_3 if (&m19803_3 == &crate::prelude::Text::lit("take")) => ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::std::exchange({}, {{}})", &recv_p4))),
                    m19803_4 if (&m19803_4 == &crate::prelude::Text::lit("free")) => ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}({}{}{})", &free_name_f(&m_p2z), &recv_p4, &sep_p7, &a_p5))),
                    m19803_5 if (&m19803_5 == &crate::prelude::Text::lit("arrow")) => {
                        let through_p9 = match pointer_o(&cp_p0z, &r_p1z) {
                            ::std::option::Option::Some(b_pa) => if b_pa { crate::prelude::Text::lit("->") } else { crate::prelude::Text::lit(".") },
                            ::std::option::Option::None => crate::prelude::Text::lit("->"),
                        };
                        ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{}{}({})", &recv_p4, &through_p9, &member_name_f(&m_p2z), &a_p5)))
                    },
                    m19803_6 if (&m19803_6 == &crate::prelude::Text::lit("exchange")) => ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::std::exchange({}, {})", &recv_p4, &a_p5))),
                    _ => {
                        let through_pb = match pointer_o(&cp_p0z, &r_p1z) {
                            ::std::option::Option::Some(b_pc) => if b_pc { crate::prelude::Text::lit("->") } else { crate::prelude::Text::lit(".") },
                            ::std::option::Option::None => match crate::prelude::get(&cp_p0z.members_p, &m_p2z) {
                                ::std::option::Option::Some(_) => crate::prelude::Text::lit("->"),
                                ::std::option::Option::None => crate::prelude::Text::lit("."),
                            },
                        };
                        ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{}{}({})", &recv_p4, &through_pb, &node_method_name_f(&cp_p0z, &m_p2z), &a_p5)))
                    },
                    _ => unreachable!("no arm matched"),
                }
            })
        };
        if r_p1 == &crate::lower::model::Ex::XSelf {
            k_let19651(crate::prelude::Text::lit("this"))
        } else {
            {
                let cp_p0x = cp_p0.clone();
                let r_p1x = r_p1.clone();
                crate::prelude::call_then(start_cpp_tight_place_f(cp_p0x.clone(), r_p1x.clone()), move |cpp_tight_place_f_19690: crate::prelude::Text| k_let19651(cpp_tight_place_f_19690))
            }
        }
    }
}

/// `Start CppMethod, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_method_f(cp_p0: crate::emit::cpp::Cp, r_p1: crate::lower::model::Ex, m_p2: crate::prelude::Text, args_p3: crate::prelude::Array<crate::lower::model::Ex>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppMethod { cp_p0, r_p1, m_p2, args_p3 })
}

/// ```prism
/// NodeMethodName: fn Cp, Text -> Text
/// ```
pub fn node_method_name_f(cp_p0: &crate::emit::cpp::Cp, m_p1: &crate::prelude::Text) -> crate::prelude::Text {
    match (crate::prelude::get(&cp_p0.methods_p, m_p1), crate::prelude::get(&cp_p0.field_names_p, m_p1)) {
        (::std::option::Option::Some(_), ::std::option::Option::Some(_)) => crate::prelude::Text::from(format!("{}_", &crate::emit::cpp::cpp_id_f(m_p1))),
        _ => member_name_f(m_p1),
    }
}

/// ```prism
/// ?Pointer: fn Cp, Ex -> ?Bool
/// ```
pub fn pointer_o(cp_p0: &crate::emit::cpp::Cp, r_p1: &crate::lower::model::Ex) -> ::std::option::Option<bool> {
    'm21323: {
        if let crate::lower::model::Ex::XSelf = r_p1 {
            break 'm21323 ::std::option::Option::Some(true);
        }
        if let crate::lower::model::Ex::XCx = r_p1 {
            break 'm21323 ::std::option::Option::Some(false);
        }
        if let crate::lower::model::Ex::XVar(m21323_2_0) = r_p1 && (m21323_2_0 == &crate::prelude::Text::lit("path")) {
            break 'm21323 ::std::option::Option::Some(false);
        }
        if let crate::lower::model::Ex::XField(_, m21323_3_1) = r_p1 && (m21323_3_1 == &crate::prelude::Text::lit("path")) {
            break 'm21323 ::std::option::Option::Some(false);
        }
        if let crate::lower::model::Ex::XCall(crate::lower::model::Ref::RefRuntime(m21323_4_0_0), _) = r_p1 && (m21323_4_0_0 == &crate::prelude::Text::lit("rt::Path::root")) {
            break 'm21323 ::std::option::Option::Some(false);
        }
        if let crate::lower::model::Ex::XMethod(y_p2, m_p3, _) = r_p1 && (((m_p3 == &crate::prelude::Text::lit("at")) || (m_p3 == &crate::prelude::Text::lit("child"))) || (m_p3 == &crate::prelude::Text::lit("join"))) {
            break 'm21323 match pointer_o(cp_p0, &**y_p2) {
                ::std::option::Option::Some(false) => ::std::option::Option::Some(false),
                _ => ::std::option::Option::None,
            };
        }
        if let crate::lower::model::Ex::XVar(n_p4) = r_p1 {
            break 'm21323 crate::prelude::get(&cp_p0.pointers_p, n_p4);
        }
        if let crate::lower::model::Ex::XClone(y_p5) = r_p1 {
            break 'm21323 pointer_o(cp_p0, &**y_p5);
        }
        if let crate::lower::model::Ex::XRef(y_p6) = r_p1 {
            break 'm21323 pointer_o(cp_p0, &**y_p6);
        }
        if let crate::lower::model::Ex::XDeref(y_p7) = r_p1 {
            break 'm21323 match ex_ty_o(cp_p0, r_p1) {
                ::std::option::Option::Some(t_p8) => ::std::option::Option::Some(is_pointer_ty_f(cp_p0, &unref_f(&t_p8))),
                ::std::option::Option::None => ::std::option::Option::None,
            };
        }
        if let crate::lower::model::Ex::XField(m21323_10_0, f_p9) = r_p1 && let crate::lower::model::Ex::XSelf = &**m21323_10_0 {
            break 'm21323 match crate::prelude::get(&cp_p0.fields_p, f_p9) {
                ::std::option::Option::Some(t_pa) => ::std::option::Option::Some(is_pointer_ty_f(cp_p0, &t_pa)),
                ::std::option::Option::None => ::std::option::Option::None,
            };
        }
        if let crate::lower::model::Ex::XField(m21323_11_0, f_pb) = r_p1 && let crate::lower::model::Ex::XVar(m21323_11_0_r_0) = &**m21323_11_0 && (m21323_11_0_r_0 == &crate::prelude::Text::lit("node")) {
            break 'm21323 match crate::prelude::get(&cp_p0.fields_p, f_pb) {
                ::std::option::Option::Some(t_pc) => ::std::option::Option::Some(is_pointer_ty_f(cp_p0, &t_pc)),
                ::std::option::Option::None => ::std::option::Option::None,
            };
        }
        ::std::option::Option::None
    }
}

/// ```prism
/// IsPointerTy: fn Cp, OutTy -> Bool
/// ```
pub fn is_pointer_ty_f(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::OutTy) -> bool {
    match t_p1 {
        crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(m22184_0_0_0), _) if (m22184_0_0_0 == &crate::prelude::Text::lit("prism_rtl::Rows")) => true,
        crate::lower::model::OutTy::OutPort(_) => false,
        crate::lower::model::OutTy::OutRc(_) => true,
        crate::lower::model::OutTy::OutObj(_) => true,
        crate::lower::model::OutTy::OutJob(_) => true,
        crate::lower::model::OutTy::OutShowAny => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// MethodForm: fn Text, Nat -> Text
/// ```
pub fn method_form_f(m_p0: &crate::prelude::Text, n_p1: &crate::prelude::Nat) -> crate::prelude::Text {
    match (m_p0.clone(), n_p1.clone()) {
        (m22724_0_0, m22724_0_1) if (&m22724_0_0 == &crate::prelude::Text::lit("borrow")) && (&m22724_0_1 == &crate::prelude::Nat::from(0u32)) => crate::prelude::Text::lit("deref"),
        (m22724_1_0, m22724_1_1) if (&m22724_1_0 == &crate::prelude::Text::lit("borrow_mut")) && (&m22724_1_1 == &crate::prelude::Nat::from(0u32)) => crate::prelude::Text::lit("deref"),
        (m22724_2_0, m22724_2_1) if (&m22724_2_0 == &crate::prelude::Text::lit("clone")) && (&m22724_2_1 == &crate::prelude::Nat::from(0u32)) => crate::prelude::Text::lit("id"),
        (m22724_3_0, m22724_3_1) if (&m22724_3_0 == &crate::prelude::Text::lit("iter")) && (&m22724_3_1 == &crate::prelude::Nat::from(0u32)) => crate::prelude::Text::lit("id"),
        (m22724_4_0, m22724_4_1) if (&m22724_4_0 == &crate::prelude::Text::lit("collect")) && (&m22724_4_1 == &crate::prelude::Nat::from(0u32)) => crate::prelude::Text::lit("id"),
        (m22724_5_0, m22724_5_1) if (&m22724_5_0 == &crate::prelude::Text::lit("unwrap_or_default")) && (&m22724_5_1 == &crate::prelude::Nat::from(0u32)) => crate::prelude::Text::lit("free"),
        (m22724_6_0, m22724_6_1) if (&m22724_6_0 == &crate::prelude::Text::lit("for_each")) && (&m22724_6_1 == &crate::prelude::Nat::from(1u32)) => crate::prelude::Text::lit("free"),
        (m22724_7_0, m22724_7_1) if (&m22724_7_0 == &crate::prelude::Text::lit("into_iter")) && (&m22724_7_1 == &crate::prelude::Nat::from(0u32)) => crate::prelude::Text::lit("id"),
        (m22724_8_0, m22724_8_1) if (&m22724_8_0 == &crate::prelude::Text::lit("as_ref")) && (&m22724_8_1 == &crate::prelude::Nat::from(0u32)) => crate::prelude::Text::lit("id"),
        (m22724_9_0, m22724_9_1) if (&m22724_9_0 == &crate::prelude::Text::lit("get")) && (&m22724_9_1 == &crate::prelude::Nat::from(0u32)) => crate::prelude::Text::lit("id"),
        (m22724_10_0, m22724_10_1) if (&m22724_10_0 == &crate::prelude::Text::lit("set")) && (&m22724_10_1 == &crate::prelude::Nat::from(1u32)) => crate::prelude::Text::lit("assign"),
        (m22724_11_0, m22724_11_1) if (&m22724_11_0 == &crate::prelude::Text::lit("take")) && (&m22724_11_1 == &crate::prelude::Nat::from(0u32)) => crate::prelude::Text::lit("take"),
        (m22724_12_0, m22724_12_1) if (&m22724_12_0 == &crate::prelude::Text::lit("replace")) && (&m22724_12_1 == &crate::prelude::Nat::from(1u32)) => crate::prelude::Text::lit("exchange"),
        (m22724_13_0, m22724_13_1) if (&m22724_13_0 == &crate::prelude::Text::lit("values")) && (&m22724_13_1 == &crate::prelude::Nat::from(0u32)) => crate::prelude::Text::lit("free"),
        (m22724_14_0, m22724_14_1) if (&m22724_14_0 == &crate::prelude::Text::lit("keys")) && (&m22724_14_1 == &crate::prelude::Nat::from(0u32)) => crate::prelude::Text::lit("free"),
        (m22724_15_0, m22724_15_1) if (&m22724_15_0 == &crate::prelude::Text::lit("enumerate")) && (&m22724_15_1 == &crate::prelude::Nat::from(0u32)) => crate::prelude::Text::lit("free"),
        (m22724_16_0, m22724_16_1) if (&m22724_16_0 == &crate::prelude::Text::lit("fire")) && (&m22724_16_1 == &crate::prelude::Nat::from(2u32)) => crate::prelude::Text::lit("arrow"),
        (m22724_17_0, m22724_17_1) if (&m22724_17_0 == &crate::prelude::Text::lit("subscribe")) && (&m22724_17_1 == &crate::prelude::Nat::from(1u32)) => crate::prelude::Text::lit("arrow"),
        (m22724_18_0, m22724_18_1) if (&m22724_18_0 == &crate::prelude::Text::lit("unsubscribe")) && (&m22724_18_1 == &crate::prelude::Nat::from(1u32)) => crate::prelude::Text::lit("arrow"),
        (m22724_19_0, m22724_19_1) if (&m22724_19_0 == &crate::prelude::Text::lit("cycle")) && (&m22724_19_1 == &crate::prelude::Nat::from(0u32)) => crate::prelude::Text::lit("arrow"),
        (m22724_20_0, m22724_20_1) if (&m22724_20_0 == &crate::prelude::Text::lit("upgrade")) && (&m22724_20_1 == &crate::prelude::Nat::from(0u32)) => crate::prelude::Text::lit("free"),
        (m22724_21_0, m22724_21_1) if (&m22724_21_0 == &crate::prelude::Text::lit("expect")) && (&m22724_21_1 == &crate::prelude::Nat::from(1u32)) => crate::prelude::Text::lit("free"),
        (m22724_22_0, m22724_22_1) if (&m22724_22_0 == &crate::prelude::Text::lit("to_pod")) && (&m22724_22_1 == &crate::prelude::Nat::from(0u32)) => crate::prelude::Text::lit("free"),
        (m22724_23_0, m22724_23_1) if (&m22724_23_0 == &crate::prelude::Text::lit("cloned")) && (&m22724_23_1 == &crate::prelude::Nat::from(0u32)) => crate::prelude::Text::lit("free"),
        (m22724_24_0, m22724_24_1) if (&m22724_24_0 == &crate::prelude::Text::lit("ok")) && (&m22724_24_1 == &crate::prelude::Nat::from(0u32)) => crate::prelude::Text::lit("free"),
        (m22724_25_0, m22724_25_1) if (&m22724_25_0 == &crate::prelude::Text::lit("ok_or")) && (&m22724_25_1 == &crate::prelude::Nat::from(1u32)) => crate::prelude::Text::lit("free"),
        (m22724_26_0, m22724_26_1) if (&m22724_26_0 == &crate::prelude::Text::lit("map")) && (&m22724_26_1 == &crate::prelude::Nat::from(1u32)) => crate::prelude::Text::lit("free"),
        (m22724_27_0, m22724_27_1) if (&m22724_27_0 == &crate::prelude::Text::lit("iter_mut")) && (&m22724_27_1 == &crate::prelude::Nat::from(0u32)) => crate::prelude::Text::lit("free"),
        (m22724_28_0, m22724_28_1) if (&m22724_28_0 == &crate::prelude::Text::lit("to_vec")) && (&m22724_28_1 == &crate::prelude::Nat::from(0u32)) => crate::prelude::Text::lit("free"),
        (m22724_29_0, m22724_29_1) if (&m22724_29_0 == &crate::prelude::Text::lit("filter_some")) && (&m22724_29_1 == &crate::prelude::Nat::from(0u32)) => crate::prelude::Text::lit("free"),
        _ => crate::prelude::Text::lit("dot"),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// FreeName: fn Text -> Text
/// ```
pub fn free_name_f(m_p0: &crate::prelude::Text) -> crate::prelude::Text {
    match m_p0 {
        m23661_0 if (m23661_0 == &crate::prelude::Text::lit("to_pod")) => crate::prelude::Text::lit("::prism_rtl::to_pod"),
        m23661_1 if (m23661_1 == &crate::prelude::Text::lit("ok")) => crate::prelude::Text::lit("::prism_rtl::ignore"),
        m23661_2 if (m23661_2 == &crate::prelude::Text::lit("map")) => crate::prelude::Text::lit("::prism_rtl::fmap"),
        m23661_3 if (m23661_3 == &crate::prelude::Text::lit("ok_or")) => crate::prelude::Text::lit("::prism_rtl::ok_or"),
        m23661_4 if (m23661_4 == &crate::prelude::Text::lit("to_vec")) => crate::prelude::Text::lit("::prism_rtl::path_of"),
        m23661_5 if (m23661_5 == &crate::prelude::Text::lit("values")) => crate::prelude::Text::lit("crate::prelude::values"),
        m23661_6 if (m23661_6 == &crate::prelude::Text::lit("keys")) => crate::prelude::Text::lit("crate::prelude::keys"),
        m23661_7 if (m23661_7 == &crate::prelude::Text::lit("enumerate")) => crate::prelude::Text::lit("::prism_rtl::enumerate"),
        m23661_8 if (m23661_8 == &crate::prelude::Text::lit("unwrap_or_default")) => crate::prelude::Text::lit("::prism_rtl::unwrap_or_default"),
        m23661_9 if (m23661_9 == &crate::prelude::Text::lit("for_each")) => crate::prelude::Text::lit("::prism_rtl::for_each"),
        _ => crate::prelude::Text::from(format!("crate::prelude::{}", m_p0)),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// MemberName: fn Text -> Text
/// ```
pub fn member_name_f(m_p0: &crate::prelude::Text) -> crate::prelude::Text {
    match m_p0 {
        m24138_0 if (m24138_0 == &crate::prelude::Text::lit("push_str")) => crate::prelude::Text::lit("append"),
        m24138_1 if (m24138_1 == &crate::prelude::Text::lit("len")) => crate::prelude::Text::lit("size"),
        m24138_2 if (m24138_2 == &crate::prelude::Text::lit("is_empty")) => crate::prelude::Text::lit("empty"),
        m24138_3 if (m24138_3 == &crate::prelude::Text::lit("push")) => crate::prelude::Text::lit("push_back"),
        m24138_4 if (m24138_4 == &crate::prelude::Text::lit("contains_key")) => crate::prelude::Text::lit("contains"),
        m24138_5 if (m24138_5 == &crate::prelude::Text::lit("build")) => crate::prelude::Text::lit("make"),
        _ => crate::emit::cpp::cpp_id_f(m_p0),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CaseTest: fn Cp, Ref, Text -> Text
/// ```
pub fn case_test_f(cp_p0: &crate::emit::cpp::Cp, c_p1: &crate::lower::model::Ref, v_p2: &crate::prelude::Text) -> crate::prelude::Text {
    match c_p1 {
        crate::lower::model::Ref::RefRuntime(t_p3) => match crate::emit::cpp::bare_f(t_p3) {
            m24577_0 if (&m24577_0 == &crate::prelude::Text::lit("Some")) => crate::prelude::Text::from(format!("::prism_rtl::is_some({})", v_p2)),
            m24577_1 if (&m24577_1 == &crate::prelude::Text::lit("None")) => crate::prelude::Text::from(format!("::prism_rtl::is_none({})", v_p2)),
            m24577_2 if (&m24577_2 == &crate::prelude::Text::lit("Ok")) => crate::prelude::Text::from(format!("::prism_rtl::is_ok({})", v_p2)),
            m24577_3 if (&m24577_3 == &crate::prelude::Text::lit("Err")) => crate::prelude::Text::from(format!("::prism_rtl::is_err({})", v_p2)),
            m24577_4 if (&m24577_4 == &crate::prelude::Text::lit("prism_rtl::Turn::More")) => crate::prelude::Text::from(format!("{}.if_more()", v_p2)),
            m24577_5 if (&m24577_5 == &crate::prelude::Text::lit("prism_rtl::Turn::Finished")) => crate::prelude::Text::from(format!("{}.if_finished()", v_p2)),
            _ => crate::prelude::Text::from(format!("::prism_rtl::is<{}>({})", &case_type_f(t_p3), v_p2)),
            _ => unreachable!("no arm matched"),
        },
        _ => match crate::emit::cpp::case_of_o(cp_p0, c_p1) {
            ::std::option::Option::Some(_) => crate::prelude::Text::from(format!("::prism_rtl::is<{}>({})", &case_type_of_f(cp_p0, c_p1, v_p2), v_p2)),
            ::std::option::Option::None => match crate::emit::cpp::type_of_o(cp_p0, c_p1) {
                ::std::option::Option::Some(_) => crate::prelude::Text::lit("true"),
                ::std::option::Option::None => crate::emit::cpp::printer_refusal_f(&crate::prelude::Text::from(format!("a pattern of no type it knows ({})", &crate::lower::model::ref_spelled_f(c_p1)))),
            },
        },
    }
}

/// ```prism
/// CaseType: fn Text -> Text
/// ```
pub fn case_type_f(c_p0: &crate::prelude::Text) -> crate::prelude::Text {
    match crate::emit::cpp::bare_f(c_p0) {
        m25249_0 if (&m25249_0 == &crate::prelude::Text::lit("Segment::Pos")) => crate::prelude::Text::lit("crate::prelude::pat::Pos"),
        m25249_1 if (&m25249_1 == &crate::prelude::Text::lit("Segment::Gen")) => crate::prelude::Text::lit("crate::prelude::pat::Gen"),
        m25249_2 if (&m25249_2 == &crate::prelude::Text::lit("Segment::Key")) => crate::prelude::Text::lit("crate::prelude::pat::Key"),
        _ => crate::emit::cpp::printer_refusal_f(&crate::prelude::Text::from(format!("a pattern of the runtime\'s {}, which it has no case of", c_p0))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CaseTypeOf: fn Cp, Ref, Text -> Text
/// ```
pub fn case_type_of_f(cp_p0: &crate::emit::cpp::Cp, c_p1: &crate::lower::model::Ref, v_p2: &crate::prelude::Text) -> crate::prelude::Text {
    if is_generic_case_f(cp_p0, c_p1) {
        crate::prelude::Text::from(format!("typename ::std::remove_cvref_t<decltype({})>::{}", v_p2, &crate::emit::cpp::case_id_of_f(c_p1)))
    } else {
        crate::emit::cpp::own_type_path_f(cp_p0, c_p1)
    }
}

/// ```prism
/// IsGenericCase: fn Cp, Ref -> Bool
/// ```
pub fn is_generic_case_f(cp_p0: &crate::emit::cpp::Cp, p_p1: &crate::lower::model::Ref) -> bool {
    match crate::emit::cpp::case_of_o(cp_p0, p_p1) {
        ::std::option::Option::Some(ty_p2) => match crate::emit::cpp::type_of_o(cp_p0, &ty_p2) {
            ::std::option::Option::Some(info_p3) => &crate::prelude::len(&info_p3.params_p) > &crate::prelude::Nat::from(0u32),
            ::std::option::Option::None => false,
        },
        ::std::option::Option::None => false,
    }
}

/// ```prism
/// Payload: fn Cp, Ref, Text, Nat -> Text
/// ```
pub fn payload_f(cp_p0: &crate::emit::cpp::Cp, c_p1: &crate::lower::model::Ref, v_p2: &crate::prelude::Text, i_p3: &crate::prelude::Nat) -> crate::prelude::Text {
    match c_p1 {
        crate::lower::model::Ref::RefRuntime(t_p4) => match crate::emit::cpp::bare_f(t_p4) {
            m26238_0 if (&m26238_0 == &crate::prelude::Text::lit("Some")) => crate::prelude::Text::from(format!("::prism_rtl::some_of({})", v_p2)),
            m26238_1 if (&m26238_1 == &crate::prelude::Text::lit("Ok")) => crate::prelude::Text::from(format!("*{}", v_p2)),
            m26238_2 if (&m26238_2 == &crate::prelude::Text::lit("Err")) => crate::prelude::Text::from(format!("{}.error()", v_p2)),
            m26238_3 if (&m26238_3 == &crate::prelude::Text::lit("prism_rtl::Turn::More")) => crate::prelude::Text::from(format!("{}.if_more()->next", v_p2)),
            m26238_4 if (&m26238_4 == &crate::prelude::Text::lit("prism_rtl::Turn::Finished")) => crate::prelude::Text::from(format!("{}.if_finished()->value", v_p2)),
            _ => crate::prelude::Text::from(format!("::prism_rtl::as<{}>({}).a{}", &case_type_f(t_p4), v_p2, i_p3)),
            _ => unreachable!("no arm matched"),
        },
        _ => match crate::emit::cpp::case_of_o(cp_p0, c_p1) {
            ::std::option::Option::Some(_) => crate::prelude::Text::from(format!("::prism_rtl::as<{}>({}).a{}", &case_type_of_f(cp_p0, c_p1, v_p2), v_p2, i_p3)),
            ::std::option::Option::None => crate::prelude::Text::from(format!("{}.a{}", v_p2, i_p3)),
        },
    }
}

/// ```prism
/// CppIf: unbounded fn Cp, Ex, Ex, Ex -> Text
/// ```
pub fn cpp_if_f(cp_p0: &crate::emit::cpp::Cp, c_p1: &crate::lower::model::Ex, t_p2: &crate::lower::model::Ex, e_p3: &crate::lower::model::Ex) -> crate::prelude::Text {
    let ct_p4 = cpp_expr_f(cp_p0, c_p1);
    let err_o5 = match (err_of_o(t_p2), err_of_o(e_p3)) {
        (::std::option::Option::Some(y_p9), _) => ::std::option::Option::Some(y_p9),
        (::std::option::Option::None, ::std::option::Option::Some(y_pa)) => ::std::option::Option::Some(y_pa),
        _ => ::std::option::Option::None,
    };
    let tt_p6 = match &err_o5 {
        ::std::option::Option::Some(y_pb) => ok_branch_f(cp_p0, t_p2, y_pb),
        ::std::option::Option::None => cpp_expr_f(cp_p0, t_p2),
    };
    let et_p7 = match &err_o5 {
        ::std::option::Option::Some(y_pc) => ok_branch_f(cp_p0, e_p3, y_pc),
        ::std::option::Option::None => cpp_expr_f(cp_p0, e_p3),
    };
    let short_p8 = !crate::syntax::lexer::chars::contains_f(&crate::prelude::Text::from(format!("{}{}", &tt_p6, &et_p7)), &crate::prelude::Text::lit("\n")) && (&crate::prelude::len_text(&crate::prelude::Text::from(format!("{}{}{}", &ct_p4, &tt_p6, &et_p7))) < &crate::prelude::Nat::from(70u32));
    if short_p8 {
        crate::prelude::Text::from(format!("{} ? {} : {}", &ct_p4, &tt_p6, &et_p7))
    } else {
        crate::emit::cpp::templates::items::cond_expr_f(&ct_p4, &tt_p6, &et_p7)
    }
}

/// The step machine of `CppIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppIf: unbounded fn Cp, Ex, Ex, Ex -> Text
/// ```
pub struct CppIf {
    pub cp_p0: crate::emit::cpp::Cp,
    pub c_p1: crate::lower::model::Ex,
    pub t_p2: crate::lower::model::Ex,
    pub e_p3: crate::lower::model::Ex,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppIf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let c_p1 = &self.c_p1;
        let t_p2 = &self.t_p2;
        let e_p3 = &self.e_p3;
        let c_p1x = c_p1.clone();
        let cp_p0x = cp_p0.clone();
        let e_p3x = e_p3.clone();
        let t_p2x = t_p2.clone();
        crate::prelude::call_then(start_cpp_expr_f(cp_p0x.clone(), c_p1x.clone()), move |cpp_expr_f_26768: crate::prelude::Text| {
            let ct_p4 = cpp_expr_f_26768;
            let err_o5 = match (err_of_o(&t_p2x), err_of_o(&e_p3x)) {
                (::std::option::Option::Some(y_p9), _) => ::std::option::Option::Some(y_p9),
                (::std::option::Option::None, ::std::option::Option::Some(y_pa)) => ::std::option::Option::Some(y_pa),
                _ => ::std::option::Option::None,
            };
            let err_o5z = err_o5.clone();
            let cp_p0xz = cp_p0x.clone();
            let ct_p4z = ct_p4.clone();
            let e_p3xz = e_p3x.clone();
            let k_let26909 = move |v26909: crate::prelude::Text| {
                let tt_p6 = v26909;
                let ct_p4zz = ct_p4z.clone();
                let tt_p6z = tt_p6.clone();
                let k_let26992 = move |v26992: crate::prelude::Text| {
                    let et_p7 = v26992;
                    let short_p8 = !crate::syntax::lexer::chars::contains_f(&crate::prelude::Text::from(format!("{}{}", &tt_p6z, &et_p7)), &crate::prelude::Text::lit("\n")) && (&crate::prelude::len_text(&crate::prelude::Text::from(format!("{}{}{}", &ct_p4zz, &tt_p6z, &et_p7))) < &crate::prelude::Nat::from(70u32));
                    if short_p8 {
                        ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} ? {} : {}", &ct_p4zz, &tt_p6z, &et_p7)))
                    } else {
                        ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cond_expr_f(&ct_p4zz, &tt_p6z, &et_p7))
                    }
                };
                match err_o5z.clone() {
                    ::std::option::Option::Some(y_pc) => crate::prelude::call_then(start_ok_branch_f(cp_p0xz.clone(), e_p3xz.clone(), y_pc.clone()), move |ok_branch_f_27026: crate::prelude::Text| k_let26992(ok_branch_f_27026)),
                    ::std::option::Option::None => crate::prelude::call_then(start_cpp_expr_f(cp_p0xz.clone(), e_p3xz.clone()), move |cpp_expr_f_27057: crate::prelude::Text| k_let26992(cpp_expr_f_27057)),
                }
            };
            match err_o5.clone() {
                ::std::option::Option::Some(y_pb) => crate::prelude::call_then(start_ok_branch_f(cp_p0x.clone(), t_p2x.clone(), y_pb.clone()), move |ok_branch_f_26943: crate::prelude::Text| k_let26909(ok_branch_f_26943)),
                ::std::option::Option::None => crate::prelude::call_then(start_cpp_expr_f(cp_p0x.clone(), t_p2x.clone()), move |cpp_expr_f_26974: crate::prelude::Text| k_let26909(cpp_expr_f_26974)),
            }
        })
    }
}

/// `Start CppIf, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_if_f(cp_p0: crate::emit::cpp::Cp, c_p1: crate::lower::model::Ex, t_p2: crate::lower::model::Ex, e_p3: crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppIf { cp_p0, c_p1, t_p2, e_p3 })
}

/// ```prism
/// WithMoveCaptures: unbounded fn Cp, [Do], Ex -> Cp
/// ```
pub fn with_move_captures_f(cp_p0: &crate::emit::cpp::Cp, dos_p1: &crate::prelude::Array<crate::lower::model::Do>, e_p2: &crate::lower::model::Ex) -> crate::emit::cpp::Cp {
    let lets_p3 = crate::prelude::fold(dos_p1, &crate::prelude::Array::new(), &(|acc_p4: &crate::prelude::Array<crate::prelude::Text>, d_p5: &crate::lower::model::Do| match d_p5 {
        crate::lower::model::Do::DoLet(p_p6, _) => match crate::emit::cpp::stmts::let_name_o(p_p6) {
            ::std::option::Option::Some(n_p7) => if crate::emit::cpp::in_list_f(acc_p4, &n_p7) {
                acc_p4.clone()
            } else {
                crate::prelude::push(acc_p4, &n_p7)
            },
            ::std::option::Option::None => acc_p4.clone(),
        },
        _ => acc_p4.clone(),
    }));
    if &crate::prelude::len(&lets_p3) == &crate::prelude::Nat::from(0u32) {
        {
            let mut this: crate::emit::cpp::Cp = cp_p0.clone();
            this.move_captures_p = crate::prelude::Array::new();
            this
        }
    } else {
        {
            let (reads_p8, has_move_p9) = reads_of_f(e_p2, &false, &(crate::prelude::Array::new(), false));
            {
                let mut this: crate::emit::cpp::Cp = cp_p0.clone();
                this.move_captures_p = if has_move_p9 {
                    crate::prelude::filter(&lets_p3, &(|n_pa: &crate::prelude::Text| !crate::emit::cpp::in_list_f(&reads_p8, n_pa)))
                } else {
                    crate::prelude::Array::new()
                };
                this
            }
        }
    }
}

/// The step machine of `WithMoveCaptures`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WithMoveCaptures: unbounded fn Cp, [Do], Ex -> Cp
/// ```
pub struct WithMoveCaptures {
    pub cp_p0: crate::emit::cpp::Cp,
    pub dos_p1: crate::prelude::Array<crate::lower::model::Do>,
    pub e_p2: crate::lower::model::Ex,
}

impl ::prism_rtl::Job<crate::emit::cpp::Cp> for WithMoveCaptures {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::emit::cpp::Cp> {
        let cp_p0 = &self.cp_p0;
        let dos_p1 = &self.dos_p1;
        let e_p2 = &self.e_p2;
        let lets_p3 = crate::prelude::fold(dos_p1, &crate::prelude::Array::new(), &(|acc_p4: &crate::prelude::Array<crate::prelude::Text>, d_p5: &crate::lower::model::Do| match d_p5 {
            crate::lower::model::Do::DoLet(p_p6, _) => match crate::emit::cpp::stmts::let_name_o(p_p6) {
                ::std::option::Option::Some(n_p7) => if crate::emit::cpp::in_list_f(acc_p4, &n_p7) {
                    acc_p4.clone()
                } else {
                    crate::prelude::push(acc_p4, &n_p7)
                },
                ::std::option::Option::None => acc_p4.clone(),
            },
            _ => acc_p4.clone(),
        }));
        if &crate::prelude::len(&lets_p3) == &crate::prelude::Nat::from(0u32) {
            ::prism_rtl::Turn::Finished({
                let mut this: crate::emit::cpp::Cp = cp_p0.clone();
                this.move_captures_p = crate::prelude::Array::new();
                this
            })
        } else {
            {
                let cp_p0x = cp_p0.clone();
                let e_p2x = e_p2.clone();
                crate::prelude::call_then(start_reads_of_f(e_p2x.clone(), false, (crate::prelude::Array::new(), false)), move |reads_of_f_28017: (crate::prelude::Array<crate::prelude::Text>, bool)| {
                    let (reads_p8, has_move_p9) = reads_of_f_28017;
                    ::prism_rtl::Turn::Finished({
                        let mut this: crate::emit::cpp::Cp = cp_p0x.clone();
                        this.move_captures_p = if has_move_p9 {
                            crate::prelude::filter(&lets_p3, &(|n_pa: &crate::prelude::Text| !crate::emit::cpp::in_list_f(&reads_p8, n_pa)))
                        } else {
                            crate::prelude::Array::new()
                        };
                        this
                    })
                })
            }
        }
    }
}

/// `Start WithMoveCaptures, x`: what the function value is when passed to `@Run`.
pub fn start_with_move_captures_f(cp_p0: crate::emit::cpp::Cp, dos_p1: crate::prelude::Array<crate::lower::model::Do>, e_p2: crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::emit::cpp::Cp>> {
    ::std::rc::Rc::new(WithMoveCaptures { cp_p0, dos_p1, e_p2 })
}

/// ```prism
/// ReadsOf: unbounded fn Ex, Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub fn reads_of_f(x_p0: &crate::lower::model::Ex, into_p1: &bool, acc_p2: &(crate::prelude::Array<crate::prelude::Text>, bool)) -> (crate::prelude::Array<crate::prelude::Text>, bool) {
    let (reads_p3, has_move_p4) = acc_p2.clone();
    match x_p0 {
        crate::lower::model::Ex::XVar(n_p5) => (crate::prelude::push(&reads_p3, n_p5), has_move_p4),
        crate::lower::model::Ex::XClosure(true, ps_p6, body_p7) => if *into_p1 {
            reads_of_f(&**body_p7, into_p1, &(reads_p3.clone(), true))
        } else {
            (reads_p3.clone(), true)
        },
        crate::lower::model::Ex::XClosure(false, ps_p8, body_p9) => reads_of_f(&**body_p9, into_p1, acc_p2),
        crate::lower::model::Ex::XRef(y_pa) => reads_of_f(&**y_pa, into_p1, acc_p2),
        crate::lower::model::Ex::XRefMut(y_pb) => reads_of_f(&**y_pb, into_p1, acc_p2),
        crate::lower::model::Ex::XDeref(y_pc) => reads_of_f(&**y_pc, into_p1, acc_p2),
        crate::lower::model::Ex::XTarget(y_pd) => reads_of_f(&**y_pd, into_p1, acc_p2),
        crate::lower::model::Ex::XClone(y_pe) => reads_of_f(&**y_pe, into_p1, acc_p2),
        crate::lower::model::Ex::XWeak(y_pf) => reads_of_f(&**y_pf, into_p1, acc_p2),
        crate::lower::model::Ex::XUpgrade(y_pg) => reads_of_f(&**y_pg, into_p1, acc_p2),
        crate::lower::model::Ex::XBreak(_, y_ph) => reads_of_f(&**y_ph, into_p1, acc_p2),
        crate::lower::model::Ex::XLater(y_pi) => reads_of_f(&**y_pi, into_p1, acc_p2),
        crate::lower::model::Ex::XFormatStr(xs_pj) => reads_each_f(xs_pj, into_p1, acc_p2),
        crate::lower::model::Ex::XIsCase(y_pk, _) => reads_of_f(&**y_pk, into_p1, acc_p2),
        crate::lower::model::Ex::XCall(_, xs_pl) => reads_each_f(xs_pl, into_p1, acc_p2),
        crate::lower::model::Ex::XCallAt(_, _, xs_pm) => reads_each_f(xs_pm, into_p1, acc_p2),
        crate::lower::model::Ex::XCallSelf(_, _, _, xs_pn) => reads_each_f(xs_pn, into_p1, acc_p2),
        crate::lower::model::Ex::XApply(f_po, xs_pp) => reads_each_f(&crate::prelude::append(&crate::prelude::Array::from(vec![(**f_po).clone()]), xs_pp), into_p1, acc_p2),
        crate::lower::model::Ex::XMethod(r_pq, _, xs_pr) => reads_each_f(&crate::prelude::append(&crate::prelude::Array::from(vec![(**r_pq).clone()]), xs_pr), into_p1, acc_p2),
        crate::lower::model::Ex::XBin(_, l_ps, r_pt) => reads_each_f(&crate::prelude::Array::from(vec![(**l_ps).clone(), (**r_pt).clone()]), into_p1, acc_p2),
        crate::lower::model::Ex::XUnary(_, y_pu) => reads_of_f(&**y_pu, into_p1, acc_p2),
        crate::lower::model::Ex::XCtor(_, xs_pv) => reads_each_f(xs_pv, into_p1, acc_p2),
        crate::lower::model::Ex::XRecord(_, fs_p10) => reads_each_f(&crate::prelude::each(fs_p10, &(|(_, v_p11): &(crate::prelude::Text, crate::lower::model::Ex)| v_p11.clone())), into_p1, acc_p2),
        crate::lower::model::Ex::XTuple(xs_p12) => reads_each_f(xs_p12, into_p1, acc_p2),
        crate::lower::model::Ex::XVec(xs_p13) => reads_each_f(xs_p13, into_p1, acc_p2),
        crate::lower::model::Ex::XFormat(xs_p14) => reads_each_f(xs_p14, into_p1, acc_p2),
        crate::lower::model::Ex::XMatch(s_p15, arms_p16, _, _) => reads_arms_f(arms_p16, into_p1, &reads_of_f(&**s_p15, into_p1, acc_p2)),
        crate::lower::model::Ex::XChain(_, s_p17, arms_p18, _) => reads_arms_f(arms_p18, into_p1, &reads_of_f(&**s_p17, into_p1, acc_p2)),
        crate::lower::model::Ex::XIf(c_p19, t_p1a, e_p1b) => reads_each_f(&crate::prelude::Array::from(vec![(**c_p19).clone(), (**t_p1a).clone(), (**e_p1b).clone()]), into_p1, acc_p2),
        crate::lower::model::Ex::XBlock(dos_p1c, e_p1d) => reads_of_f(&**e_p1d, into_p1, &reads_dos_f(dos_p1c, into_p1, acc_p2)),
        crate::lower::model::Ex::XLabeled(_, dos_p1e, e_p1f, _) => reads_of_f(&**e_p1f, into_p1, &reads_dos_f(dos_p1e, into_p1, acc_p2)),
        crate::lower::model::Ex::XTry(y_p1g) => reads_of_f(&**y_p1g, into_p1, acc_p2),
        crate::lower::model::Ex::XField(r_p1h, _) => reads_of_f(&**r_p1h, into_p1, acc_p2),
        crate::lower::model::Ex::XFieldOf(r_p1i, _, _) => reads_of_f(&**r_p1i, into_p1, acc_p2),
        crate::lower::model::Ex::XPart(r_p1j, _) => reads_of_f(&**r_p1j, into_p1, acc_p2),
        crate::lower::model::Ex::XDecode(_, y_p1k) => reads_of_f(&**y_p1k, into_p1, acc_p2),
        crate::lower::model::Ex::XCast(y_p1l, _) => reads_of_f(&**y_p1l, into_p1, acc_p2),
        crate::lower::model::Ex::XTyped(y_p1m, _) => reads_of_f(&**y_p1m, into_p1, acc_p2),
        _ => acc_p2.clone(),
    }
}

/// The step machine of `ReadsOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadsOf: unbounded fn Ex, Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub struct ReadsOf {
    pub x_p0: crate::lower::model::Ex,
    pub into_p1: bool,
    pub acc_p2: (crate::prelude::Array<crate::prelude::Text>, bool),
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, bool)> for ReadsOf {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::prelude::Text>, bool)> {
        let x_p0 = &self.x_p0;
        let into_p1 = &self.into_p1;
        let acc_p2 = &self.acc_p2;
        let (reads_p3, has_move_p4) = acc_p2.clone();
        match x_p0 {
            crate::lower::model::Ex::XVar(n_p5) => ::prism_rtl::Turn::Finished((crate::prelude::push(&reads_p3, n_p5), has_move_p4)),
            crate::lower::model::Ex::XClosure(true, ps_p6, body_p7) => if *into_p1 {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: (**body_p7).clone(), into_p1: *into_p1, acc_p2: (reads_p3.clone(), true) }))
            } else {
                ::prism_rtl::Turn::Finished((reads_p3.clone(), true))
            },
            crate::lower::model::Ex::XClosure(false, ps_p8, body_p9) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: (**body_p9).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XRef(y_pa) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: (**y_pa).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XRefMut(y_pb) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: (**y_pb).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XDeref(y_pc) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: (**y_pc).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XTarget(y_pd) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: (**y_pd).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XClone(y_pe) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: (**y_pe).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XWeak(y_pf) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: (**y_pf).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XUpgrade(y_pg) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: (**y_pg).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XBreak(_, y_ph) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: (**y_ph).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XLater(y_pi) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: (**y_pi).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XFormatStr(xs_pj) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsEach { xs_p0: xs_pj.clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XIsCase(y_pk, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: (**y_pk).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XCall(_, xs_pl) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsEach { xs_p0: xs_pl.clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XCallAt(_, _, xs_pm) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsEach { xs_p0: xs_pm.clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XCallSelf(_, _, _, xs_pn) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsEach { xs_p0: xs_pn.clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XApply(f_po, xs_pp) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsEach { xs_p0: crate::prelude::append(&crate::prelude::Array::from(vec![(**f_po).clone()]), xs_pp), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XMethod(r_pq, _, xs_pr) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsEach { xs_p0: crate::prelude::append(&crate::prelude::Array::from(vec![(**r_pq).clone()]), xs_pr), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XBin(_, l_ps, r_pt) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsEach { xs_p0: crate::prelude::Array::from(vec![(**l_ps).clone(), (**r_pt).clone()]), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XUnary(_, y_pu) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: (**y_pu).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XCtor(_, xs_pv) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsEach { xs_p0: xs_pv.clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XRecord(_, fs_p10) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsEach { xs_p0: crate::prelude::each(fs_p10, &(|(_, v_p11): &(crate::prelude::Text, crate::lower::model::Ex)| v_p11.clone())), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XTuple(xs_p12) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsEach { xs_p0: xs_p12.clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XVec(xs_p13) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsEach { xs_p0: xs_p13.clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XFormat(xs_p14) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsEach { xs_p0: xs_p14.clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XMatch(s_p15, arms_p16, _, _) => {
                let acc_p2x = acc_p2.clone();
                let arms_p16x = arms_p16.clone();
                let into_p1x = *into_p1;
                let s_p15x = (**s_p15).clone();
                crate::prelude::call_then(start_reads_of_f(s_p15x.clone(), into_p1x, acc_p2x.clone()), move |reads_of_f_29849: (crate::prelude::Array<crate::prelude::Text>, bool)| ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsArms { arms_p0: arms_p16x.clone(), into_p1: into_p1x, acc_p2: reads_of_f_29849 })))
            },
            crate::lower::model::Ex::XChain(_, s_p17, arms_p18, _) => {
                let acc_p2x = acc_p2.clone();
                let arms_p18x = arms_p18.clone();
                let into_p1x = *into_p1;
                let s_p17x = (**s_p17).clone();
                crate::prelude::call_then(start_reads_of_f(s_p17x.clone(), into_p1x, acc_p2x.clone()), move |reads_of_f_29934: (crate::prelude::Array<crate::prelude::Text>, bool)| ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsArms { arms_p0: arms_p18x.clone(), into_p1: into_p1x, acc_p2: reads_of_f_29934 })))
            },
            crate::lower::model::Ex::XIf(c_p19, t_p1a, e_p1b) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsEach { xs_p0: crate::prelude::Array::from(vec![(**c_p19).clone(), (**t_p1a).clone(), (**e_p1b).clone()]), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XBlock(dos_p1c, e_p1d) => {
                let acc_p2x = acc_p2.clone();
                let dos_p1cx = dos_p1c.clone();
                let e_p1dx = (**e_p1d).clone();
                let into_p1x = *into_p1;
                crate::prelude::call_then(start_reads_dos_f(dos_p1cx.clone(), into_p1x, acc_p2x.clone()), move |reads_dos_f_30051: (crate::prelude::Array<crate::prelude::Text>, bool)| ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: e_p1dx.clone(), into_p1: into_p1x, acc_p2: reads_dos_f_30051 })))
            },
            crate::lower::model::Ex::XLabeled(_, dos_p1e, e_p1f, _) => {
                let acc_p2x = acc_p2.clone();
                let dos_p1ex = dos_p1e.clone();
                let e_p1fx = (**e_p1f).clone();
                let into_p1x = *into_p1;
                crate::prelude::call_then(start_reads_dos_f(dos_p1ex.clone(), into_p1x, acc_p2x.clone()), move |reads_dos_f_30135: (crate::prelude::Array<crate::prelude::Text>, bool)| ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: e_p1fx.clone(), into_p1: into_p1x, acc_p2: reads_dos_f_30135 })))
            },
            crate::lower::model::Ex::XTry(y_p1g) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: (**y_p1g).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XField(r_p1h, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: (**r_p1h).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XFieldOf(r_p1i, _, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: (**r_p1i).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XPart(r_p1j, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: (**r_p1j).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XDecode(_, y_p1k) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: (**y_p1k).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XCast(y_p1l, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: (**y_p1l).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Ex::XTyped(y_p1m, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: (**y_p1m).clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            _ => ::prism_rtl::Turn::Finished(acc_p2.clone()),
        }
    }
}

/// `Start ReadsOf, x`: what the function value is when passed to `@Run`.
pub fn start_reads_of_f(x_p0: crate::lower::model::Ex, into_p1: bool, acc_p2: (crate::prelude::Array<crate::prelude::Text>, bool)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, bool)>> {
    ::std::rc::Rc::new(ReadsOf { x_p0, into_p1, acc_p2 })
}

/// ```prism
/// ReadsEach: unbounded fn [Ex], Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub fn reads_each_f(xs_p0: &crate::prelude::Array<crate::lower::model::Ex>, into_p1: &bool, acc_p2: &(crate::prelude::Array<crate::prelude::Text>, bool)) -> (crate::prelude::Array<crate::prelude::Text>, bool) {
    crate::prelude::run_to_end(crate::prelude::fold_job(xs_p0.clone(), acc_p2.clone(), {
        let into_p1x = *into_p1;
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::prelude::Text>, bool), crate::lower::model::Ex)| {
            let into_p1xy = into_p1x;
            crate::prelude::entered(crate::prelude::once_job(move || {
                let a_p3 = p0;
                let x_p4 = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: x_p4.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::prelude::Text>, bool), crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, bool)>>>
    }))
}

/// The step machine of `ReadsEach`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadsEach: unbounded fn [Ex], Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub struct ReadsEach {
    pub xs_p0: crate::prelude::Array<crate::lower::model::Ex>,
    pub into_p1: bool,
    pub acc_p2: (crate::prelude::Array<crate::prelude::Text>, bool),
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, bool)> for ReadsEach {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::prelude::Text>, bool)> {
        let xs_p0 = &self.xs_p0;
        let into_p1 = &self.into_p1;
        let acc_p2 = &self.acc_p2;
        crate::prelude::fold_job(xs_p0.clone(), acc_p2.clone(), {
            let into_p1x = *into_p1;
            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::prelude::Text>, bool), crate::lower::model::Ex)| {
                let into_p1xy = into_p1x;
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p3 = p0;
                    let x_p4 = p1;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: x_p4.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::prelude::Text>, bool), crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, bool)>>>
        }).cycle()
    }
}

/// `Start ReadsEach, x`: what the function value is when passed to `@Run`.
pub fn start_reads_each_f(xs_p0: crate::prelude::Array<crate::lower::model::Ex>, into_p1: bool, acc_p2: (crate::prelude::Array<crate::prelude::Text>, bool)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, bool)>> {
    ::std::rc::Rc::new(ReadsEach { xs_p0, into_p1, acc_p2 })
}

/// ```prism
/// ReadsArms: unbounded fn [XArm], Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub fn reads_arms_f(arms_p0: &crate::prelude::Array<crate::lower::model::XArm>, into_p1: &bool, acc_p2: &(crate::prelude::Array<crate::prelude::Text>, bool)) -> (crate::prelude::Array<crate::prelude::Text>, bool) {
    crate::prelude::run_to_end(crate::prelude::fold_job(arms_p0.clone(), acc_p2.clone(), {
        let into_p1x = *into_p1;
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::prelude::Text>, bool), crate::lower::model::XArm)| {
            let into_p1xy = into_p1x;
            crate::prelude::entered(crate::prelude::once_job(move || {
                let a_p3 = p0;
                let arm_p4 = p1;
                crate::prelude::call_value(crate::prelude::fold_job(arm_p4.conds_p.clone(), a_p3.clone(), {
                    let into_p1xyx = into_p1xy;
                    ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::prelude::Text>, bool), crate::lower::model::Cc)| {
                        let into_p1xyxy = into_p1xyx;
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a2_p5 = p0;
                            let c_p6 = p1;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsCond { cc0: c_p6.clone(), into_p1: into_p1xyxy, acc_p2: a2_p5.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::prelude::Text>, bool), crate::lower::model::Cc)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, bool)>>>
                }), move |fold_30813: (crate::prelude::Array<crate::prelude::Text>, bool)| ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: arm_p4.body_p.clone(), into_p1: into_p1xy, acc_p2: fold_30813 })))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::prelude::Text>, bool), crate::lower::model::XArm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, bool)>>>
    }))
}

/// The step machine of `ReadsArms`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadsArms: unbounded fn [XArm], Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub struct ReadsArms {
    pub arms_p0: crate::prelude::Array<crate::lower::model::XArm>,
    pub into_p1: bool,
    pub acc_p2: (crate::prelude::Array<crate::prelude::Text>, bool),
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, bool)> for ReadsArms {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::prelude::Text>, bool)> {
        let arms_p0 = &self.arms_p0;
        let into_p1 = &self.into_p1;
        let acc_p2 = &self.acc_p2;
        crate::prelude::fold_job(arms_p0.clone(), acc_p2.clone(), {
            let into_p1x = *into_p1;
            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::prelude::Text>, bool), crate::lower::model::XArm)| {
                let into_p1xy = into_p1x;
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p3 = p0;
                    let arm_p4 = p1;
                    crate::prelude::call_value(crate::prelude::fold_job(arm_p4.conds_p.clone(), a_p3.clone(), {
                        let into_p1xyx = into_p1xy;
                        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::prelude::Text>, bool), crate::lower::model::Cc)| {
                            let into_p1xyxy = into_p1xyx;
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let a2_p5 = p0;
                                let c_p6 = p1;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsCond { cc0: c_p6.clone(), into_p1: into_p1xyxy, acc_p2: a2_p5.clone() }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::prelude::Text>, bool), crate::lower::model::Cc)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, bool)>>>
                    }), move |fold_30813: (crate::prelude::Array<crate::prelude::Text>, bool)| ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: arm_p4.body_p.clone(), into_p1: into_p1xy, acc_p2: fold_30813 })))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::prelude::Text>, bool), crate::lower::model::XArm)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, bool)>>>
        }).cycle()
    }
}

/// `Start ReadsArms, x`: what the function value is when passed to `@Run`.
pub fn start_reads_arms_f(arms_p0: crate::prelude::Array<crate::lower::model::XArm>, into_p1: bool, acc_p2: (crate::prelude::Array<crate::prelude::Text>, bool)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, bool)>> {
    ::std::rc::Rc::new(ReadsArms { arms_p0, into_p1, acc_p2 })
}

/// ```prism
/// ReadsCond: unbounded fn Cc, Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub fn reads_cond_f(cc0: &crate::lower::model::Cc, into_p1: &bool, acc_p2: &(crate::prelude::Array<crate::prelude::Text>, bool)) -> (crate::prelude::Array<crate::prelude::Text>, bool) {
    match cc0 {
        crate::lower::model::Cc::CcLet(_, x_p0) => reads_of_f(x_p0, into_p1, acc_p2),
        crate::lower::model::Cc::CcIf(x_p3) => reads_of_f(x_p3, into_p1, acc_p2),
    }
}

/// The step machine of `ReadsCond`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadsCond: unbounded fn Cc, Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub struct ReadsCond {
    pub cc0: crate::lower::model::Cc,
    pub into_p1: bool,
    pub acc_p2: (crate::prelude::Array<crate::prelude::Text>, bool),
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, bool)> for ReadsCond {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::prelude::Text>, bool)> {
        let cc0 = &self.cc0;
        let into_p1 = &self.into_p1;
        let acc_p2 = &self.acc_p2;
        match cc0 {
            crate::lower::model::Cc::CcLet(_, x_p0) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: x_p0.clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
            crate::lower::model::Cc::CcIf(x_p3) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: x_p3.clone(), into_p1: *into_p1, acc_p2: acc_p2.clone() })),
        }
    }
}

/// `Start ReadsCond, x`: what the function value is when passed to `@Run`.
pub fn start_reads_cond_f(cc0: crate::lower::model::Cc, into_p1: bool, acc_p2: (crate::prelude::Array<crate::prelude::Text>, bool)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, bool)>> {
    ::std::rc::Rc::new(ReadsCond { cc0, into_p1, acc_p2 })
}

/// ```prism
/// ReadsDos: unbounded fn [Do], Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub fn reads_dos_f(dos_p0: &crate::prelude::Array<crate::lower::model::Do>, into_p1: &bool, acc_p2: &(crate::prelude::Array<crate::prelude::Text>, bool)) -> (crate::prelude::Array<crate::prelude::Text>, bool) {
    crate::prelude::run_to_end(crate::prelude::fold_job(dos_p0.clone(), acc_p2.clone(), {
        let into_p1x = *into_p1;
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::prelude::Text>, bool), crate::lower::model::Do)| {
            let into_p1xy = into_p1x;
            crate::prelude::entered(crate::prelude::once_job(move || {
                let a_p3 = p0;
                let d_p4 = p1;
                match &d_p4 {
                    crate::lower::model::Do::DoLet(_, x_p5) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: x_p5.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                    crate::lower::model::Do::DoLetElse(_, x_p6, e_p7) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsEach { xs_p0: crate::prelude::Array::from(vec![x_p6.clone(), e_p7.clone()]), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                    crate::lower::model::Do::DoAssign(p_p8, x_p9) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsEach { xs_p0: crate::prelude::Array::from(vec![p_p8.clone(), x_p9.clone()]), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                    crate::lower::model::Do::DoWhile(c_pa, body_pb) => {
                        let body_pbx = body_pb.clone();
                        let c_pax = c_pa.clone();
                        crate::prelude::call_then(start_reads_of_f(c_pax.clone(), into_p1xy, a_p3.clone()), move |reads_of_f_31377: (crate::prelude::Array<crate::prelude::Text>, bool)| ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsDos { dos_p0: body_pbx.clone(), into_p1: into_p1xy, acc_p2: reads_of_f_31377 })))
                    },
                    crate::lower::model::Do::DoWhileLet(_, x_pc, body_pd) => {
                        let body_pdx = body_pd.clone();
                        let x_pcx = x_pc.clone();
                        crate::prelude::call_then(start_reads_of_f(x_pcx.clone(), into_p1xy, a_p3.clone()), move |reads_of_f_31451: (crate::prelude::Array<crate::prelude::Text>, bool)| ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsDos { dos_p0: body_pdx.clone(), into_p1: into_p1xy, acc_p2: reads_of_f_31451 })))
                    },
                    crate::lower::model::Do::DoFor(_, x_pe, body_pf) => {
                        let body_pfx = body_pf.clone();
                        let x_pex = x_pe.clone();
                        crate::prelude::call_then(start_reads_of_f(x_pex.clone(), into_p1xy, a_p3.clone()), move |reads_of_f_31520: (crate::prelude::Array<crate::prelude::Text>, bool)| ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsDos { dos_p0: body_pfx.clone(), into_p1: into_p1xy, acc_p2: reads_of_f_31520 })))
                    },
                    crate::lower::model::Do::DoExpr(x_pg) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: x_pg.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                    crate::lower::model::Do::DoIf(c_ph, t_pi, e_pj) => {
                        let c_phx = c_ph.clone();
                        let e_pjx = e_pj.clone();
                        let t_pix = t_pi.clone();
                        crate::prelude::call_then(start_reads_of_f(c_phx.clone(), into_p1xy, a_p3.clone()), move |reads_of_f_31629: (crate::prelude::Array<crate::prelude::Text>, bool)| crate::prelude::call_then(start_reads_dos_f(t_pix.clone(), into_p1xy, reads_of_f_31629), move |reads_dos_f_31610: (crate::prelude::Array<crate::prelude::Text>, bool)| ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsDos { dos_p0: e_pjx.clone(), into_p1: into_p1xy, acc_p2: reads_dos_f_31610 }))))
                    },
                    crate::lower::model::Do::DoIfLet(_, x_pk, t_pl, e_pm) => {
                        let e_pmx = e_pm.clone();
                        let t_plx = t_pl.clone();
                        let x_pkx = x_pk.clone();
                        crate::prelude::call_then(start_reads_of_f(x_pkx.clone(), into_p1xy, a_p3.clone()), move |reads_of_f_31717: (crate::prelude::Array<crate::prelude::Text>, bool)| crate::prelude::call_then(start_reads_dos_f(t_plx.clone(), into_p1xy, reads_of_f_31717), move |reads_dos_f_31698: (crate::prelude::Array<crate::prelude::Text>, bool)| ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsDos { dos_p0: e_pmx.clone(), into_p1: into_p1xy, acc_p2: reads_dos_f_31698 }))))
                    },
                    crate::lower::model::Do::DoMatch(x_pn, cases_po) => {
                        let cases_pox = cases_po.clone();
                        let x_pnx = x_pn.clone();
                        crate::prelude::call_then(start_reads_of_f(x_pnx.clone(), into_p1xy, a_p3.clone()), move |reads_of_f_31773: (crate::prelude::Array<crate::prelude::Text>, bool)| crate::prelude::fold_job(cases_pox.clone(), reads_of_f_31773, {
                            let into_p1xyx = into_p1xy;
                            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::prelude::Text>, bool), (crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>))| {
                                let into_p1xyxy = into_p1xyx;
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let a2_pp = p0;
                                    let (_, body_pq) = p1;
                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsDos { dos_p0: body_pq.clone(), into_p1: into_p1xyxy, acc_p2: a2_pp.clone() }))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::prelude::Text>, bool), (crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, bool)>>>
                        }).cycle())
                    },
                    crate::lower::model::Do::DoReturn(x_pr) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: x_pr.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                    crate::lower::model::Do::DoBlock(body_ps) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsDos { dos_p0: body_ps.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                    crate::lower::model::Do::DoScope(body_pt) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsDos { dos_p0: body_pt.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                    crate::lower::model::Do::DoLine(body_pu) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsDos { dos_p0: body_pu.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                    crate::lower::model::Do::DoNote(_) => ::prism_rtl::Turn::Finished(a_p3.clone()),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::prelude::Text>, bool), crate::lower::model::Do)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, bool)>>>
    }))
}

/// The step machine of `ReadsDos`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadsDos: unbounded fn [Do], Bool, (([Text], Bool)) -> (([Text], Bool))
/// ```
pub struct ReadsDos {
    pub dos_p0: crate::prelude::Array<crate::lower::model::Do>,
    pub into_p1: bool,
    pub acc_p2: (crate::prelude::Array<crate::prelude::Text>, bool),
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, bool)> for ReadsDos {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::prelude::Text>, bool)> {
        let dos_p0 = &self.dos_p0;
        let into_p1 = &self.into_p1;
        let acc_p2 = &self.acc_p2;
        crate::prelude::fold_job(dos_p0.clone(), acc_p2.clone(), {
            let into_p1x = *into_p1;
            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::prelude::Text>, bool), crate::lower::model::Do)| {
                let into_p1xy = into_p1x;
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p3 = p0;
                    let d_p4 = p1;
                    match &d_p4 {
                        crate::lower::model::Do::DoLet(_, x_p5) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: x_p5.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                        crate::lower::model::Do::DoLetElse(_, x_p6, e_p7) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsEach { xs_p0: crate::prelude::Array::from(vec![x_p6.clone(), e_p7.clone()]), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                        crate::lower::model::Do::DoAssign(p_p8, x_p9) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsEach { xs_p0: crate::prelude::Array::from(vec![p_p8.clone(), x_p9.clone()]), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                        crate::lower::model::Do::DoWhile(c_pa, body_pb) => {
                            let body_pbx = body_pb.clone();
                            let c_pax = c_pa.clone();
                            crate::prelude::call_then(start_reads_of_f(c_pax.clone(), into_p1xy, a_p3.clone()), move |reads_of_f_31377: (crate::prelude::Array<crate::prelude::Text>, bool)| ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsDos { dos_p0: body_pbx.clone(), into_p1: into_p1xy, acc_p2: reads_of_f_31377 })))
                        },
                        crate::lower::model::Do::DoWhileLet(_, x_pc, body_pd) => {
                            let body_pdx = body_pd.clone();
                            let x_pcx = x_pc.clone();
                            crate::prelude::call_then(start_reads_of_f(x_pcx.clone(), into_p1xy, a_p3.clone()), move |reads_of_f_31451: (crate::prelude::Array<crate::prelude::Text>, bool)| ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsDos { dos_p0: body_pdx.clone(), into_p1: into_p1xy, acc_p2: reads_of_f_31451 })))
                        },
                        crate::lower::model::Do::DoFor(_, x_pe, body_pf) => {
                            let body_pfx = body_pf.clone();
                            let x_pex = x_pe.clone();
                            crate::prelude::call_then(start_reads_of_f(x_pex.clone(), into_p1xy, a_p3.clone()), move |reads_of_f_31520: (crate::prelude::Array<crate::prelude::Text>, bool)| ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsDos { dos_p0: body_pfx.clone(), into_p1: into_p1xy, acc_p2: reads_of_f_31520 })))
                        },
                        crate::lower::model::Do::DoExpr(x_pg) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: x_pg.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                        crate::lower::model::Do::DoIf(c_ph, t_pi, e_pj) => {
                            let c_phx = c_ph.clone();
                            let e_pjx = e_pj.clone();
                            let t_pix = t_pi.clone();
                            crate::prelude::call_then(start_reads_of_f(c_phx.clone(), into_p1xy, a_p3.clone()), move |reads_of_f_31629: (crate::prelude::Array<crate::prelude::Text>, bool)| crate::prelude::call_then(start_reads_dos_f(t_pix.clone(), into_p1xy, reads_of_f_31629), move |reads_dos_f_31610: (crate::prelude::Array<crate::prelude::Text>, bool)| ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsDos { dos_p0: e_pjx.clone(), into_p1: into_p1xy, acc_p2: reads_dos_f_31610 }))))
                        },
                        crate::lower::model::Do::DoIfLet(_, x_pk, t_pl, e_pm) => {
                            let e_pmx = e_pm.clone();
                            let t_plx = t_pl.clone();
                            let x_pkx = x_pk.clone();
                            crate::prelude::call_then(start_reads_of_f(x_pkx.clone(), into_p1xy, a_p3.clone()), move |reads_of_f_31717: (crate::prelude::Array<crate::prelude::Text>, bool)| crate::prelude::call_then(start_reads_dos_f(t_plx.clone(), into_p1xy, reads_of_f_31717), move |reads_dos_f_31698: (crate::prelude::Array<crate::prelude::Text>, bool)| ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsDos { dos_p0: e_pmx.clone(), into_p1: into_p1xy, acc_p2: reads_dos_f_31698 }))))
                        },
                        crate::lower::model::Do::DoMatch(x_pn, cases_po) => {
                            let cases_pox = cases_po.clone();
                            let x_pnx = x_pn.clone();
                            crate::prelude::call_then(start_reads_of_f(x_pnx.clone(), into_p1xy, a_p3.clone()), move |reads_of_f_31773: (crate::prelude::Array<crate::prelude::Text>, bool)| crate::prelude::fold_job(cases_pox.clone(), reads_of_f_31773, {
                                let into_p1xyx = into_p1xy;
                                ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::prelude::Text>, bool), (crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>))| {
                                    let into_p1xyxy = into_p1xyx;
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let a2_pp = p0;
                                        let (_, body_pq) = p1;
                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsDos { dos_p0: body_pq.clone(), into_p1: into_p1xyxy, acc_p2: a2_pp.clone() }))
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::prelude::Text>, bool), (crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, bool)>>>
                            }).cycle())
                        },
                        crate::lower::model::Do::DoReturn(x_pr) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsOf { x_p0: x_pr.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                        crate::lower::model::Do::DoBlock(body_ps) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsDos { dos_p0: body_ps.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                        crate::lower::model::Do::DoScope(body_pt) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsDos { dos_p0: body_pt.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                        crate::lower::model::Do::DoLine(body_pu) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ReadsDos { dos_p0: body_pu.clone(), into_p1: into_p1xy, acc_p2: a_p3.clone() })),
                        crate::lower::model::Do::DoNote(_) => ::prism_rtl::Turn::Finished(a_p3.clone()),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::prelude::Text>, bool), crate::lower::model::Do)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, bool)>>>
        }).cycle()
    }
}

/// `Start ReadsDos, x`: what the function value is when passed to `@Run`.
pub fn start_reads_dos_f(dos_p0: crate::prelude::Array<crate::lower::model::Do>, into_p1: bool, acc_p2: (crate::prelude::Array<crate::prelude::Text>, bool)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, bool)>> {
    ::std::rc::Rc::new(ReadsDos { dos_p0, into_p1, acc_p2 })
}

/// ```prism
/// IsCtor: fn Ex, Text -> Bool
/// ```
pub fn is_ctor_f(ex0: &crate::lower::model::Ex, c_p1: &crate::prelude::Text) -> bool {
    match ex0 {
        crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(p_p0), _) => &crate::emit::cpp::bare_f(p_p0) == c_p1,
        x_p2 => false,
    }
}

/// ```prism
/// ?ErrOf: fn Ex -> ?Ex
/// ```
pub fn err_of_o(x_p0: &crate::lower::model::Ex) -> ::std::option::Option<crate::lower::model::Ex> {
    'm32237: {
        if let crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(m32237_0_0_0), m32237_0_1) = x_p0 && (m32237_0_0_0 == &crate::prelude::Text::lit("std::Err")) && (m32237_0_1.len() == 1) && let ::std::option::Option::Some(y_p1) = crate::prelude::index(m32237_0_1, &crate::prelude::Nat::from(0u32)) {
            break 'm32237 ::std::option::Option::Some(y_p1.clone());
        }
        if let crate::lower::model::Ex::XBlock(_, tail_p2) = x_p0 {
            break 'm32237 err_of_o(&**tail_p2);
        }
        ::std::option::Option::None
    }
}

/// ```prism
/// OkBranch: unbounded fn Cp, Ex, Ex -> Text
/// ```
pub fn ok_branch_f(cp_p0: &crate::emit::cpp::Cp, x_p1: &crate::lower::model::Ex, y_p2: &crate::lower::model::Ex) -> crate::prelude::Text {
    'm32558: {
        if let crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(m32558_0_0_0), m32558_0_1) = x_p1 && (m32558_0_0_0 == &crate::prelude::Text::lit("std::Ok")) && (m32558_0_1.len() == 1) && let ::std::option::Option::Some(v_p3) = crate::prelude::index(m32558_0_1, &crate::prelude::Nat::from(0u32)) {
            break 'm32558 crate::prelude::Text::from(format!("crate::prelude::Expected<::std::decay_t<decltype({})>, ::std::decay_t<decltype({})>>({})", &cpp_expr_f(cp_p0, &v_p3), &cpp_expr_f(cp_p0, y_p2), &cpp_expr_f(cp_p0, &v_p3)));
        }
        if let crate::lower::model::Ex::XBlock(dos_p4, m32558_1_1) = x_p1 && let crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(m32558_1_1_r_0_0), m32558_1_1_r_1) = &**m32558_1_1 && (m32558_1_1_r_0_0 == &crate::prelude::Text::lit("std::Ok")) && (m32558_1_1_r_1.len() == 1) && let ::std::option::Option::Some(v_p5) = crate::prelude::index(m32558_1_1_r_1, &crate::prelude::Nat::from(0u32)) {
            break 'm32558 {
                let (st_p6, cp2_p7) = crate::emit::cpp::stmts::cpp_statements_cp_f(cp_p0, dos_p4);
                crate::emit::cpp::templates::items::stmt_expr_f(&st_p6, &crate::prelude::Text::from(format!("crate::prelude::Expected<::std::decay_t<decltype({})>, ::std::decay_t<decltype({})>>({})", &cpp_expr_f(&cp2_p7, &v_p5), &cpp_expr_f(&cp2_p7, y_p2), &cpp_expr_f(&cp2_p7, &v_p5))))
            };
        }
        cpp_expr_f(cp_p0, x_p1)
    }
}

/// The step machine of `OkBranch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OkBranch: unbounded fn Cp, Ex, Ex -> Text
/// ```
pub struct OkBranch {
    pub cp_p0: crate::emit::cpp::Cp,
    pub x_p1: crate::lower::model::Ex,
    pub y_p2: crate::lower::model::Ex,
}

impl ::prism_rtl::Job<crate::prelude::Text> for OkBranch {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let x_p1 = &self.x_p1;
        let y_p2 = &self.y_p2;
        'm32558: {
            if let crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(m32558_0_0_0), m32558_0_1) = x_p1 && (m32558_0_0_0 == &crate::prelude::Text::lit("std::Ok")) && (m32558_0_1.len() == 1) && let ::std::option::Option::Some(v_p3) = crate::prelude::index(m32558_0_1, &crate::prelude::Nat::from(0u32)) {
                break 'm32558 {
                    let cp_p0x = cp_p0.clone();
                    let y_p2x = y_p2.clone();
                    crate::prelude::call_then(start_cpp_expr_f(cp_p0x.clone(), v_p3.clone()), move |cpp_expr_f_32659: crate::prelude::Text| crate::prelude::call_then(start_cpp_expr_f(cp_p0x.clone(), y_p2x.clone()), move |cpp_expr_f_32702: crate::prelude::Text| crate::prelude::call_then(start_cpp_expr_f(cp_p0x.clone(), v_p3.clone()), move |cpp_expr_f_32721: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Expected<::std::decay_t<decltype({})>, ::std::decay_t<decltype({})>>({})", &cpp_expr_f_32659, &cpp_expr_f_32702, &cpp_expr_f_32721))))))
                };
            }
            if let crate::lower::model::Ex::XBlock(dos_p4, m32558_1_1) = x_p1 && let crate::lower::model::Ex::XCtor(crate::lower::model::Ref::RefRuntime(m32558_1_1_r_0_0), m32558_1_1_r_1) = &**m32558_1_1 && (m32558_1_1_r_0_0 == &crate::prelude::Text::lit("std::Ok")) && (m32558_1_1_r_1.len() == 1) && let ::std::option::Option::Some(v_p5) = crate::prelude::index(m32558_1_1_r_1, &crate::prelude::Nat::from(0u32)) {
                break 'm32558 {
                    let cp_p0x = cp_p0.clone();
                    let dos_p4x = dos_p4.clone();
                    let y_p2x = y_p2.clone();
                    crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_statements_cp_f(cp_p0x.clone(), dos_p4x.clone()), move |cpp_statements_cp_f_32819: (crate::prelude::Text, crate::emit::cpp::Cp)| {
                        let (st_p6, cp2_p7) = cpp_statements_cp_f_32819;
                        crate::prelude::call_then(start_cpp_expr_f(cp2_p7.clone(), v_p5.clone()), move |cpp_expr_f_32915: crate::prelude::Text| crate::prelude::call_then(start_cpp_expr_f(cp2_p7.clone(), y_p2x.clone()), move |cpp_expr_f_32959: crate::prelude::Text| crate::prelude::call_then(start_cpp_expr_f(cp2_p7.clone(), v_p5.clone()), move |cpp_expr_f_32979: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::stmt_expr_f(&st_p6, &crate::prelude::Text::from(format!("crate::prelude::Expected<::std::decay_t<decltype({})>, ::std::decay_t<decltype({})>>({})", &cpp_expr_f_32915, &cpp_expr_f_32959, &cpp_expr_f_32979)))))))
                    })
                };
            }
            ::prism_rtl::Turn::More(::std::rc::Rc::new(CppExpr { cp_p0: cp_p0.clone(), x_p1: x_p1.clone() }))
        }
    }
}

/// `Start OkBranch, x`: what the function value is when passed to `@Run`.
pub fn start_ok_branch_f(cp_p0: crate::emit::cpp::Cp, x_p1: crate::lower::model::Ex, y_p2: crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(OkBranch { cp_p0, x_p1, y_p2 })
}

/// ```prism
/// CppClosure: unbounded fn Cp, Bool, [Pa], Ex -> Text
/// ```
pub fn cpp_closure_f(cp0_p0: &crate::emit::cpp::Cp, mv_p1: &bool, ps_p2: &crate::prelude::Array<crate::lower::model::Pa>, body_p3: &crate::lower::model::Ex) -> crate::prelude::Text {
    let names_p4 = crate::emit::cpp::patterns::concat2_f(&crate::prelude::run_to_end(crate::prelude::each_job(ps_p2.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Pa| crate::prelude::entered(crate::prelude::once_job(move || {
        let p_pb = p0;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::cpp::stmts::PatNames { p_p0: p_pb.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Pa) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)));
    let cp_p5 = crate::prelude::fold(ps_p2, &crate::emit::cpp::stmts::unbind_f(&crate::emit::cpp::stmts::captured_f(cp0_p0), &names_p4), &(|c_pc: &crate::emit::cpp::Cp, p_pd: &crate::lower::model::Pa| 'm33616: {
        if let crate::lower::model::Pa::PaMut(n_pe) = p_pd {
            break 'm33616 crate::emit::cpp::stmts::owning_f(c_pc, n_pe);
        }
        if let crate::lower::model::Pa::PaTyped(m33616_1_0, _) = p_pd && let crate::lower::model::Pa::PaMut(n_pf) = &**m33616_1_0 {
            break 'm33616 crate::emit::cpp::stmts::owning_f(c_pc, n_pf);
        }
        c_pc.clone()
    }));
    let params_p6 = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(ps_p2)), {
        let cp_p5x = cp_p5.clone();
        let ps_p2x = ps_p2.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
            let cp_p5xy = cp_p5x.clone();
            let ps_p2xy = ps_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_pg = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(ClosureParam { cp_p0: cp_p5xy.clone(), pa1: crate::prelude::or(&crate::prelude::index(&ps_p2xy, &i_pg), &crate::lower::model::Pa::PaWild), i_p3: i_pg.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    })), &crate::prelude::Text::lit(", "));
    let binds_p7 = crate::prelude::concat(&crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(ps_p2)), {
        let cp_p5x = cp_p5.clone();
        let ps_p2x = ps_p2.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
            let cp_p5xy = cp_p5x.clone();
            let ps_p2xy = ps_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_ph = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(ClosureBinds { cp_p0: cp_p5xy.clone(), pa1: crate::prelude::or(&crate::prelude::index(&ps_p2xy, &i_ph), &crate::lower::model::Pa::PaWild), i_p3: i_ph.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    })));
    let b_p8 = cpp_expr_f(&cp_p5, body_p3);
    let moved_p9 = if *mv_p1 {
        crate::prelude::run_to_end(crate::prelude::filter_job(cp0_p0.move_captures_p.clone(), {
            let cp0_p0x = cp0_p0.clone();
            let names_p4x = names_p4.clone();
            let body_p3x = body_p3.clone();
            ::std::rc::Rc::new(move |p0: crate::prelude::Text| {
                let cp0_p0xy = cp0_p0x.clone();
                let names_p4xy = names_p4x.clone();
                let body_p3xy = body_p3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let n_pi = p0;
                    if crate::prelude::or(&crate::prelude::get(&cp0_p0xy.owned_p, &n_pi), &false) && !crate::emit::cpp::in_list_f(&names_p4xy, &n_pi) {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::model::ExReads { x_p0: body_p3xy.clone(), n_p1: n_pi.clone() }))
                    } else {
                        ::prism_rtl::Turn::Finished(false)
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        }))
    } else {
        crate::prelude::Array::new()
    };
    let capture_pa = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::Array::from(vec![if *mv_p1 { crate::prelude::Text::lit("=") } else { crate::prelude::Text::lit("&") }]), &crate::prelude::each(&moved_p9, &(|n_pj: &crate::prelude::Text| crate::prelude::Text::from(format!("{} = ::std::move({})", &crate::emit::cpp::stmts::var_name_f(cp0_p0, n_pj), &crate::emit::cpp::stmts::var_name_f(cp0_p0, n_pj)))))), &crate::prelude::Text::lit(", "));
    let (ret_pk, value_pl) = match body_p3 {
        crate::lower::model::Ex::XRef(_) => (crate::prelude::Text::lit(" -> decltype(auto)"), crate::prelude::Text::from(format!("({})", &b_p8))),
        crate::lower::model::Ex::XRefMut(_) => (crate::prelude::Text::lit(" -> decltype(auto)"), crate::prelude::Text::from(format!("({})", &b_p8))),
        _ => (crate::prelude::Text::lit(""), b_p8.clone()),
    };
    if (&binds_p7 == &crate::prelude::Text::lit("")) && !crate::syntax::lexer::chars::contains_f(&b_p8, &crate::prelude::Text::lit("\n")) {
        crate::prelude::Text::from(format!("[{}]({}){} {{ return {}; }}", &capture_pa, &params_p6, &ret_pk, &value_pl))
    } else {
        crate::emit::cpp::templates::items::lambda_f(&capture_pa, &crate::prelude::Text::from(format!("{}){}", &params_p6, &ret_pk)), &crate::prelude::Text::from(format!("{}return {};", &binds_p7, &value_pl)))
    }
}

/// The step machine of `CppClosure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppClosure: unbounded fn Cp, Bool, [Pa], Ex -> Text
/// ```
pub struct CppClosure {
    pub cp0_p0: crate::emit::cpp::Cp,
    pub mv_p1: bool,
    pub ps_p2: crate::prelude::Array<crate::lower::model::Pa>,
    pub body_p3: crate::lower::model::Ex,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppClosure {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp0_p0 = &self.cp0_p0;
        let mv_p1 = &self.mv_p1;
        let ps_p2 = &self.ps_p2;
        let body_p3 = &self.body_p3;
        let body_p3x = body_p3.clone();
        let cp0_p0x = cp0_p0.clone();
        let mv_p1x = *mv_p1;
        let ps_p2x = ps_p2.clone();
        crate::prelude::call_value(crate::prelude::each_job(ps_p2x.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Pa| crate::prelude::entered(crate::prelude::once_job(move || {
            let p_pb = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::cpp::stmts::PatNames { p_p0: p_pb.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Pa) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>), move |each_33528: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| {
            let names_p4 = crate::emit::cpp::patterns::concat2_f(&each_33528);
            let cp_p5 = crate::prelude::fold(&ps_p2x, &crate::emit::cpp::stmts::unbind_f(&crate::emit::cpp::stmts::captured_f(&cp0_p0x), &names_p4), &(|c_pc: &crate::emit::cpp::Cp, p_pd: &crate::lower::model::Pa| 'm33616: {
                if let crate::lower::model::Pa::PaMut(n_pe) = p_pd {
                    break 'm33616 crate::emit::cpp::stmts::owning_f(c_pc, n_pe);
                }
                if let crate::lower::model::Pa::PaTyped(m33616_1_0, _) = p_pd && let crate::lower::model::Pa::PaMut(n_pf) = &**m33616_1_0 {
                    break 'm33616 crate::emit::cpp::stmts::owning_f(c_pc, n_pf);
                }
                c_pc.clone()
            }));
            crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&ps_p2x)), {
                let cp_p5x = cp_p5.clone();
                let ps_p2xx = ps_p2x.clone();
                ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                    let cp_p5xy = cp_p5x.clone();
                    let ps_p2xxy = ps_p2xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let i_pg = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(ClosureParam { cp_p0: cp_p5xy.clone(), pa1: crate::prelude::or(&crate::prelude::index(&ps_p2xxy, &i_pg), &crate::lower::model::Pa::PaWild), i_p3: i_pg.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            }), move |each_33745: crate::prelude::Array<crate::prelude::Text>| {
                let params_p6 = crate::syntax::lexer::chars::join_f(&each_33745, &crate::prelude::Text::lit(", "));
                crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&ps_p2x)), {
                    let cp_p5x = cp_p5.clone();
                    let ps_p2xx = ps_p2x.clone();
                    ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                        let cp_p5xy = cp_p5x.clone();
                        let ps_p2xxy = ps_p2xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let i_ph = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(ClosureBinds { cp_p0: cp_p5xy.clone(), pa1: crate::prelude::or(&crate::prelude::index(&ps_p2xxy, &i_ph), &crate::lower::model::Pa::PaWild), i_p3: i_ph.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                }), move |each_33844: crate::prelude::Array<crate::prelude::Text>| {
                    let binds_p7 = crate::prelude::concat(&each_33844);
                    crate::prelude::call_then(start_cpp_expr_f(cp_p5.clone(), body_p3x.clone()), move |cpp_expr_f_33925: crate::prelude::Text| {
                        let b_p8 = cpp_expr_f_33925;
                        let b_p8z = b_p8.clone();
                        let binds_p7z = binds_p7.clone();
                        let body_p3xz = body_p3x.clone();
                        let cp0_p0xz = cp0_p0x.clone();
                        let mv_p1xz = mv_p1x;
                        let params_p6z = params_p6.clone();
                        let k_let33946 = move |v33946: crate::prelude::Array<crate::prelude::Text>| {
                            let moved_p9 = v33946;
                            let capture_pa = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::Array::from(vec![if mv_p1xz { crate::prelude::Text::lit("=") } else { crate::prelude::Text::lit("&") }]), &crate::prelude::each(&moved_p9, &(|n_pj: &crate::prelude::Text| crate::prelude::Text::from(format!("{} = ::std::move({})", &crate::emit::cpp::stmts::var_name_f(&cp0_p0xz, n_pj), &crate::emit::cpp::stmts::var_name_f(&cp0_p0xz, n_pj)))))), &crate::prelude::Text::lit(", "));
                            let (ret_pk, value_pl) = match &body_p3xz {
                                crate::lower::model::Ex::XRef(_) => (crate::prelude::Text::lit(" -> decltype(auto)"), crate::prelude::Text::from(format!("({})", &b_p8z))),
                                crate::lower::model::Ex::XRefMut(_) => (crate::prelude::Text::lit(" -> decltype(auto)"), crate::prelude::Text::from(format!("({})", &b_p8z))),
                                _ => (crate::prelude::Text::lit(""), b_p8z.clone()),
                            };
                            if (&binds_p7z == &crate::prelude::Text::lit("")) && !crate::syntax::lexer::chars::contains_f(&b_p8z, &crate::prelude::Text::lit("\n")) {
                                ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("[{}]({}){} {{ return {}; }}", &capture_pa, &params_p6z, &ret_pk, &value_pl)))
                            } else {
                                ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::lambda_f(&capture_pa, &crate::prelude::Text::from(format!("{}){}", &params_p6z, &ret_pk)), &crate::prelude::Text::from(format!("{}return {};", &binds_p7z, &value_pl))))
                            }
                        };
                        if mv_p1x {
                            crate::prelude::call_value(crate::prelude::filter_job(cp0_p0x.move_captures_p.clone(), {
                                let cp0_p0xx = cp0_p0x.clone();
                                let names_p4x = names_p4.clone();
                                let body_p3xx = body_p3x.clone();
                                ::std::rc::Rc::new(move |p0: crate::prelude::Text| {
                                    let cp0_p0xxy = cp0_p0xx.clone();
                                    let names_p4xy = names_p4x.clone();
                                    let body_p3xxy = body_p3xx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let n_pi = p0;
                                        if crate::prelude::or(&crate::prelude::get(&cp0_p0xxy.owned_p, &n_pi), &false) && !crate::emit::cpp::in_list_f(&names_p4xy, &n_pi) {
                                            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::model::ExReads { x_p0: body_p3xxy.clone(), n_p1: n_pi.clone() }))
                                        } else {
                                            ::prism_rtl::Turn::Finished(false)
                                        }
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                            }), move |filter_33965: crate::prelude::Array<crate::prelude::Text>| k_let33946(filter_33965))
                        } else {
                            k_let33946(crate::prelude::Array::new())
                        }
                    })
                })
            })
        })
    }
}

/// `Start CppClosure, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_closure_f(cp0_p0: crate::emit::cpp::Cp, mv_p1: bool, ps_p2: crate::prelude::Array<crate::lower::model::Pa>, body_p3: crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppClosure { cp0_p0, mv_p1, ps_p2, body_p3 })
}

/// ```prism
/// ClosureParam: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub fn closure_param_f(cp_p0: &crate::emit::cpp::Cp, pa1: &crate::lower::model::Pa, i_p3: &crate::prelude::Nat) -> crate::prelude::Text {
    'c: {
        if let crate::lower::model::Pa::PaTyped(c0_1_0, t_p2) = pa1 && let crate::lower::model::Pa::PaBind(n_p1) = &**c0_1_0 {
            break 'c crate::prelude::Text::from(format!("{} {}", &param_type_f(cp_p0, t_p2), &crate::emit::cpp::cpp_id_f(n_p1)));
        }
        if let crate::lower::model::Pa::PaTyped(c1_1_0, t_p6) = pa1 && let crate::lower::model::Pa::PaMut(n_p5) = &**c1_1_0 {
            break 'c crate::prelude::Text::from(format!("{} {}", &crate::emit::cpp::cpp_type_f(cp_p0, &unref_f(t_p6)), &crate::emit::cpp::cpp_id_f(n_p5)));
        }
        if let crate::lower::model::Pa::PaTyped(p_p9, t_pa) = pa1 {
            break 'c crate::prelude::Text::from(format!("{} _p{}", &param_type_f(cp_p0, t_pa), i_p3));
        }
        if let crate::lower::model::Pa::PaBind(n_pd) = pa1 {
            break 'c crate::prelude::Text::from(format!("auto&& {}", &crate::emit::cpp::cpp_id_f(n_pd)));
        }
        if let crate::lower::model::Pa::PaMut(n_pg) = pa1 {
            break 'c crate::prelude::Text::from(format!("auto {}", &crate::emit::cpp::cpp_id_f(n_pg)));
        }
        if let crate::lower::model::Pa::PaWild = pa1 {
            break 'c crate::prelude::Text::lit("const auto&");
        }
        if let p_pl = pa1 {
            break 'c crate::prelude::Text::from(format!("const auto& _p{}", i_p3));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `ClosureParam`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosureParam: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub struct ClosureParam {
    pub cp_p0: crate::emit::cpp::Cp,
    pub pa1: crate::lower::model::Pa,
    pub i_p3: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::prelude::Text> for ClosureParam {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let pa1 = &self.pa1;
        let i_p3 = &self.i_p3;
        'j: {
            if let crate::lower::model::Pa::PaTyped(j0_1_0, t_p2) = pa1 && let crate::lower::model::Pa::PaBind(n_p1) = &**j0_1_0 {
                break 'j {
                    let cp_p0x = cp_p0.clone();
                    let n_p1x = n_p1.clone();
                    let t_p2x = t_p2.clone();
                    crate::prelude::call_then(start_param_type_f(cp_p0x.clone(), t_p2x.clone()), move |param_type_f_34660: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {}", &param_type_f_34660, &crate::emit::cpp::cpp_id_f(&n_p1x)))))
                };
            }
            if let crate::lower::model::Pa::PaTyped(j1_1_0, t_p6) = pa1 && let crate::lower::model::Pa::PaMut(n_p5) = &**j1_1_0 {
                break 'j {
                    let cp_p0x = cp_p0.clone();
                    let n_p5x = n_p5.clone();
                    let t_p6x = t_p6.clone();
                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), unref_f(&t_p6x)), move |cpp_type_f_34738: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {}", &cpp_type_f_34738, &crate::emit::cpp::cpp_id_f(&n_p5x)))))
                };
            }
            if let crate::lower::model::Pa::PaTyped(p_p9, t_pa) = pa1 {
                break 'j {
                    let cp_p0x = cp_p0.clone();
                    let i_p3x = i_p3.clone();
                    let t_pax = t_pa.clone();
                    crate::prelude::call_then(start_param_type_f(cp_p0x.clone(), t_pax.clone()), move |param_type_f_34814: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} _p{}", &param_type_f_34814, &i_p3x))))
                };
            }
            if let crate::lower::model::Pa::PaBind(n_pd) = pa1 {
                break 'j ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("auto&& {}", &crate::emit::cpp::cpp_id_f(n_pd))));
            }
            if let crate::lower::model::Pa::PaMut(n_pg) = pa1 {
                break 'j ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("auto {}", &crate::emit::cpp::cpp_id_f(n_pg))));
            }
            if let crate::lower::model::Pa::PaWild = pa1 {
                break 'j ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("const auto&"));
            }
            if let p_pl = pa1 {
                break 'j ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("const auto& _p{}", i_p3)));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start ClosureParam, x`: what the function value is when passed to `@Run`.
pub fn start_closure_param_f(cp_p0: crate::emit::cpp::Cp, pa1: crate::lower::model::Pa, i_p3: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(ClosureParam { cp_p0, pa1, i_p3 })
}

/// ```prism
/// ClosureBinds: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub fn closure_binds_f(cp_p0: &crate::emit::cpp::Cp, pa1: &crate::lower::model::Pa, i_p3: &crate::prelude::Nat) -> crate::prelude::Text {
    'c: {
        if let crate::lower::model::Pa::PaTyped(c0_1_0, t_p2) = pa1 && let crate::lower::model::Pa::PaBind(n_p1) = &**c0_1_0 {
            break 'c crate::prelude::Text::lit("");
        }
        if let crate::lower::model::Pa::PaTyped(c1_1_0, t_p6) = pa1 && let crate::lower::model::Pa::PaMut(n_p5) = &**c1_1_0 {
            break 'c crate::prelude::Text::lit("");
        }
        if let crate::lower::model::Pa::PaTyped(p_p9, t_pa) = pa1 {
            break 'c closure_binds_f(cp_p0, &**p_p9, i_p3);
        }
        if let crate::lower::model::Pa::PaBind(n_pd) = pa1 {
            break 'c crate::prelude::Text::lit("");
        }
        if let crate::lower::model::Pa::PaMut(n_pg) = pa1 {
            break 'c crate::prelude::Text::lit("");
        }
        if let crate::lower::model::Pa::PaWild = pa1 {
            break 'c crate::prelude::Text::lit("");
        }
        if let p_pl = pa1 {
            break 'c crate::prelude::concat(&crate::prelude::each(&crate::emit::cpp::patterns::pat_binds_f(cp_p0, p_pl, &crate::prelude::Text::from(format!("_p{}", i_p3))), &(|b_pn: &crate::prelude::Text| crate::prelude::Text::from(format!("{}\n", b_pn)))));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `ClosureBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosureBinds: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub struct ClosureBinds {
    pub cp_p0: crate::emit::cpp::Cp,
    pub pa1: crate::lower::model::Pa,
    pub i_p3: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::prelude::Text> for ClosureBinds {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let pa1 = &self.pa1;
        let i_p3 = &self.i_p3;
        'j: {
            if let crate::lower::model::Pa::PaTyped(j0_1_0, t_p2) = pa1 && let crate::lower::model::Pa::PaBind(n_p1) = &**j0_1_0 {
                break 'j ::prism_rtl::Turn::Finished(crate::prelude::Text::lit(""));
            }
            if let crate::lower::model::Pa::PaTyped(j1_1_0, t_p6) = pa1 && let crate::lower::model::Pa::PaMut(n_p5) = &**j1_1_0 {
                break 'j ::prism_rtl::Turn::Finished(crate::prelude::Text::lit(""));
            }
            if let crate::lower::model::Pa::PaTyped(p_p9, t_pa) = pa1 {
                break 'j ::prism_rtl::Turn::More(::std::rc::Rc::new(ClosureBinds { cp_p0: cp_p0.clone(), pa1: (**p_p9).clone(), i_p3: i_p3.clone() }));
            }
            if let crate::lower::model::Pa::PaBind(n_pd) = pa1 {
                break 'j ::prism_rtl::Turn::Finished(crate::prelude::Text::lit(""));
            }
            if let crate::lower::model::Pa::PaMut(n_pg) = pa1 {
                break 'j ::prism_rtl::Turn::Finished(crate::prelude::Text::lit(""));
            }
            if let crate::lower::model::Pa::PaWild = pa1 {
                break 'j ::prism_rtl::Turn::Finished(crate::prelude::Text::lit(""));
            }
            if let p_pl = pa1 {
                break 'j {
                    let cp_p0x = cp_p0.clone();
                    let i_p3x = i_p3.clone();
                    let p_plx = p_pl.clone();
                    crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_binds_f(cp_p0x.clone(), p_plx.clone(), crate::prelude::Text::from(format!("_p{}", &i_p3x))), move |pat_binds_f_35404: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::concat(&crate::prelude::each(&pat_binds_f_35404, &(|b_pn: &crate::prelude::Text| crate::prelude::Text::from(format!("{}\n", b_pn)))))))
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start ClosureBinds, x`: what the function value is when passed to `@Run`.
pub fn start_closure_binds_f(cp_p0: crate::emit::cpp::Cp, pa1: crate::lower::model::Pa, i_p3: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(ClosureBinds { cp_p0, pa1, i_p3 })
}

/// ```prism
/// Unref: fn OutTy -> OutTy
/// ```
pub fn unref_f(out_ty0: &crate::lower::model::OutTy) -> crate::lower::model::OutTy {
    match out_ty0 {
        crate::lower::model::OutTy::OutRef(t_p0) => (**t_p0).clone(),
        crate::lower::model::OutTy::OutRefMut(t_p1) => (**t_p1).clone(),
        t_p2 => t_p2.clone(),
    }
}

/// ```prism
/// ParamType: unbounded fn Cp, OutTy -> Text
/// ```
pub fn param_type_f(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::OutTy) -> crate::prelude::Text {
    match t_p1 {
        crate::lower::model::OutTy::OutRef(_) => crate::emit::cpp::cpp_type_f(cp_p0, t_p1),
        crate::lower::model::OutTy::OutSlice(_) => crate::emit::cpp::cpp_type_f(cp_p0, t_p1),
        crate::lower::model::OutTy::OutUnit => crate::prelude::Text::lit("crate::prelude::Unit"),
        _ => crate::emit::cpp::cpp_type_f(cp_p0, t_p1),
    }
}

/// The step machine of `ParamType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParamType: unbounded fn Cp, OutTy -> Text
/// ```
pub struct ParamType {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::OutTy,
}

impl ::prism_rtl::Job<crate::prelude::Text> for ParamType {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        match t_p1 {
            crate::lower::model::OutTy::OutRef(_) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::cpp::CppType { cp_p0: cp_p0.clone(), t_p1: t_p1.clone() })),
            crate::lower::model::OutTy::OutSlice(_) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::cpp::CppType { cp_p0: cp_p0.clone(), t_p1: t_p1.clone() })),
            crate::lower::model::OutTy::OutUnit => ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Unit")),
            _ => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::cpp::CppType { cp_p0: cp_p0.clone(), t_p1: t_p1.clone() })),
        }
    }
}

/// `Start ParamType, x`: what the function value is when passed to `@Run`.
pub fn start_param_type_f(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(ParamType { cp_p0, t_p1 })
}
