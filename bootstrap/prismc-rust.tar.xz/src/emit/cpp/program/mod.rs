//! The module `Emit.Cpp.Program`, from `target/bootstrap/src/prismc/emit/cpp/program.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Piece`:
///
/// ```prism
/// type Piece = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Piece {
    pub title: Text,
    pub prism: Text,
    pub path_: Text,
    pub ns: Text,
    pub needs: Array<Text>,
    pub defs: Text,
}

impl Show for Piece {
    fn show(&self, p: &mut Printer) {
        p.record("Piece", &[("title", &self.title), ("prism", &self.prism), ("path", &self.path_), ("ns", &self.ns), ("needs", &self.needs), ("defs", &self.defs)]);
    }
}

impl ToPod for Piece {
    fn to_pod(&self) -> Pod {
        Pod::record("Piece", vec![("title", self.title.to_pod()), ("prism", self.prism.to_pod()), ("path", self.path_.to_pod()), ("ns", self.ns.to_pod()), ("needs", self.needs.to_pod()), ("defs", self.defs.to_pod())])
    }
}

impl FromPod for Piece {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Piece { title: FromPod::from_pod(field(p, "title")?)?, prism: FromPod::from_pod(field(p, "prism")?)?, path_: FromPod::from_pod(field(p, "path")?)?, ns: FromPod::from_pod(field(p, "ns")?)?, needs: FromPod::from_pod(field(p, "needs")?)?, defs: FromPod::from_pod(field(p, "defs")?)? })
    }
}

/// ```prism
/// NodeParts: unbounded fn Cp, NodeDef -> Parts
/// ```
pub fn node_parts(cp: &crate::emit::cpp::Cp, n: &crate::lower::model::NodeDef) -> crate::emit::cpp::items::Parts {
    let ncp = crate::emit::cpp::with_fields(cp, &each(&n.fields, &(|(f, t, _): &(Text, crate::lower::model::OutTy, Text)| (f.clone(), t.clone()))));
    let base = if (&n.row_kind == &crate::lower::model::RowKind::NotARow) && (&len(&n.hosted) == &Nat::from(0u32)) {
        Text::lit("Node")
    } else {
        Text::lit("Row")
    };
    let fields = crate::syntax::lexer::chars::join(&run_to_end(each_job(n.fields.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy, Text)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (f, t, doc) = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), t.clone()), move |cpp_type_1357: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{} {};", &crate::emit::cpp::items::cpp_doc(&doc), &cpp_type_1357, &crate::emit::cpp::field_id(&f)))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let consts = crate::syntax::lexer::chars::join(&each(&n.consts, &(|(c, h, doc): &(Text, Nat, Text)| Text::from(format!("{}static constexpr std::uint32_t {} = {};", &crate::emit::cpp::items::cpp_doc(&Text::from(format!("The {}.", doc))), c, h)))), &Text::lit("\n"));
    let ctor_params = crate::syntax::lexer::chars::join(&append(&Array::from(vec![Text::lit("Path path")]), &run_to_end(each_job(n.fields.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy, Text)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (f, t, _) = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), t.clone()), move |cpp_type_1609: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_1609, &crate::emit::cpp::field_id(&f)))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
    }))), &Text::lit(", "));
    let ctor_inits = crate::syntax::lexer::chars::join(&append(&Array::from(vec![Text::lit("path(std::move(path))")]), &each(&n.fields, &(|(f, _, _): &(Text, crate::lower::model::OutTy, Text)| Text::from(format!("{}(std::move({}))", &crate::emit::cpp::field_id(f), &crate::emit::cpp::field_id(f)))))), &Text::lit(", "));
    let params = concat(&run_to_end(each_job(n.params.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (p_, t) = p0;
                call_then(crate::emit::cpp::expr::start_param_type(cp.clone(), t.clone()), move |param_type_1848: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}, ", &param_type_1848, &p_))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let ret = if n.fallible {
        Text::from(format!("Result<prism_rtl::Rc<{}>>", &n.name))
    } else {
        Text::from(format!("prism_rtl::Rc<{}>", &n.name))
    };
    let make_decl = Text::from(format!("static {} make(Path path, {}Cx& cx);", &ret, &params));
    let method_decls = run_to_end(each_job(append(&n.methods, &n.hosted), {
        let ncp = ncp.clone();
        Rc::new(move |p0: crate::lower::model::MethDef| {
            let ncp = ncp.clone();
            entered(once_job(move || {
                let m = p0;
                call_then(start_method_sig(ncp.clone(), m.clone(), Text::lit("")), move |method_sig_2099: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &method_sig_2099))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let builder_decls = append(&each(&n.builders, &(|b: &crate::lower::model::ForDef| Text::from(format!("Done {}_build(Cx& cx);", &b.name)))), &each(&n.gens, &(|g: &crate::lower::model::GenDef| Text::from(format!("Done {}_build(Cx& cx);", &g.name)))));
    let hook_decls = each(&n.hooks, &(|(h, _): &(Text, Array<crate::lower::model::Do>)| Text::from(format!("{} override;", &hook_sig(h, &Text::lit(""))))));
    let answer_decl = if &len(&n.answers) == &Nat::from(0u32) {
        Array::new()
    } else {
        Array::from(vec![Text::lit("Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;")])
    };
    let row_decl = if &n.row_kind == &crate::lower::model::RowKind::NotARow {
        Array::new()
    } else {
        Array::from(vec![Text::lit("void leave_row(Cx& cx) override;")])
    };
    let decls = crate::syntax::lexer::chars::join(&append(&append(&append(&append(&append(&Array::from(vec![make_decl.clone()]), &method_decls), &builder_decls), &hook_decls), &answer_decl), &row_decl), &Text::lit("\n"));
    let doc = crate::emit::cpp::items::cpp_source_doc(&Text::from(format!("`{}`: a node of its own (claude/backend.md, \"A widget block\").", &n.prism)), &n.doc);
    let decl = crate::emit::cpp::templates::items::node_class(&doc, &n.name, &base, &fields, &consts, &Text::from(format!("{}({}) : {} {{}}", &n.name, &ctor_params, &ctor_inits)), &decls);
    let by_field = each(&n.fields, &(|(f, _, _): &(Text, crate::lower::model::OutTy, Text)| or(&fold(&n.inits, &None, &(|found_opt: &Option<crate::lower::model::Ex>, (g, v_): &(Text, crate::lower::model::Ex)| if g == f { Some(v_.clone()) } else { found_opt.clone() })), &crate::lower::model::Ex::XVar(f.clone()))));
    let (lets_text, lcp) = crate::emit::cpp::stmts::cpp_statements_cp(&ncp, &n.lets);
    let args = crate::syntax::lexer::chars::join(&append(&Array::from(vec![Text::lit("path")]), &run_to_end(each_job(by_field.clone(), {
        let lcp = lcp.clone();
        Rc::new(move |p0: crate::lower::model::Ex| {
            let lcp = lcp.clone();
            entered(once_job(move || {
                let v_ = p0;
                prism_rtl::Turn::More(Rc::new(crate::emit::cpp::expr::CppExpr { cp: lcp.clone(), x: v_.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
    }))), &Text::lit(", "));
    let tail = if n.fallible { Text::lit("return node;") } else { Text::lit("return node;") };
    let make = crate::emit::cpp::templates::items::node_make(&n.name, &Text::from(format!("{} {}::make(Path path, {}Cx& cx)", &ret, &n.name, &params)), &lets_text, &args, &crate::syntax::lexer::chars::join(&filter(&Array::from(vec![crate::emit::cpp::stmts::cpp_statements(&crate::emit::cpp::stmts::pointing(&lcp, &Text::lit("node")), &n.build), tail.clone()]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n")));
    let methods = run_to_end(each_job(append(&n.methods, &n.hosted), {
        let ncp = ncp.clone();
        let n = n.clone();
        Rc::new(move |p0: crate::lower::model::MethDef| {
            let ncp = ncp.clone();
            let n = n.clone();
            entered(once_job(move || {
                let m = p0;
                prism_rtl::Turn::More(Rc::new(MethodDef { cp: ncp.clone(), owner: n.name.clone(), m: m.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let builders = append(&run_to_end(each_job(n.builders.clone(), {
        let ncp = ncp.clone();
        let n = n.clone();
        Rc::new(move |p0: crate::lower::model::ForDef| {
            let ncp = ncp.clone();
            let n = n.clone();
            entered(once_job(move || {
                let b = p0;
                prism_rtl::Turn::More(Rc::new(ForBuildCpp { cp: ncp.clone(), owner: n.name.clone(), b: b.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::ForDef) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &run_to_end(each_job(n.gens.clone(), {
        let ncp = ncp.clone();
        let n = n.clone();
        Rc::new(move |p0: crate::lower::model::GenDef| {
            let ncp = ncp.clone();
            let n = n.clone();
            entered(once_job(move || {
                let g = p0;
                prism_rtl::Turn::More(Rc::new(GenBuildCpp { cp: ncp.clone(), owner: n.name.clone(), gd: g.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::GenDef) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let hooks = run_to_end(each_job(n.hooks.clone(), {
        let n = n.clone();
        let ncp = ncp.clone();
        Rc::new(move |p0: (Text, Array<crate::lower::model::Do>)| {
            let n = n.clone();
            let ncp = ncp.clone();
            entered(once_job(move || {
                let (h, body) = p0;
                call_then(crate::emit::cpp::stmts::start_cpp_statements(ncp.clone(), body.clone()), move |cpp_statements_3838: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &hook_sig(&h, &Text::from(format!("{}::", &n.name))), &Text::from(format!("{}\nreturn {{}};", &cpp_statements_3838)))))
            }))
        }) as Rc<dyn Fn((Text, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let answer = if &len(&n.answers) == &Nat::from(0u32) {
        Array::new()
    } else {
        Array::from(vec![answer_def_cpp(&ncp, n)])
    };
    let leaving = if &n.row_kind == &crate::lower::model::RowKind::NotARow {
        Array::new()
    } else {
        Array::from(vec![row_leaving(&ncp, n)])
    };
    let defs = append(&append(&append(&append(&append(&Array::from(vec![make.clone()]), &methods), &builders), &hooks), &answer), &leaving);
    let own = crate::emit::cpp::items::Parts { forward: Array::from(vec![Text::from(format!("class {};", &n.name))]), handles: Array::new(), values: Array::new(), cases: Array::new(), protos: Array::new(), classes: Array::from(vec![decl.clone()]), outer: Array::new(), generic: Array::new(), defs: defs.clone() };
    own.clone()
}

/// The step machine of `NodeParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NodeParts: unbounded fn Cp, NodeDef -> Parts
/// ```
pub struct NodeParts {
    pub cp: crate::emit::cpp::Cp,
    pub n: crate::lower::model::NodeDef,
}

impl prism_rtl::Job<crate::emit::cpp::items::Parts> for NodeParts {
    fn cycle(&self) -> prism_rtl::Turn<crate::emit::cpp::items::Parts> {
        let cp = &self.cp;
        let n = &self.n;
        let ncp = crate::emit::cpp::with_fields(cp, &each(&n.fields, &(|(f, t, _): &(Text, crate::lower::model::OutTy, Text)| (f.clone(), t.clone()))));
        let base = if (&n.row_kind == &crate::lower::model::RowKind::NotARow) && (&len(&n.hosted) == &Nat::from(0u32)) {
            Text::lit("Node")
        } else {
            Text::lit("Row")
        };
        let cp = cp.clone();
        let n = n.clone();
        call_value(each_job(n.fields.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: (Text, crate::lower::model::OutTy, Text)| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let (f, t, doc) = p0;
                    call_then(crate::emit::cpp::start_cpp_type(cp.clone(), t.clone()), move |cpp_type_1357: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{} {};", &crate::emit::cpp::items::cpp_doc(&doc), &cpp_type_1357, &crate::emit::cpp::field_id(&f)))))
                }))
            }) as Rc<dyn Fn((Text, crate::lower::model::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_1311: Array<Text>| {
            let fields = crate::syntax::lexer::chars::join(&each_1311, &Text::lit("\n"));
            let consts = crate::syntax::lexer::chars::join(&each(&n.consts, &(|(c, h, doc): &(Text, Nat, Text)| Text::from(format!("{}static constexpr std::uint32_t {} = {};", &crate::emit::cpp::items::cpp_doc(&Text::from(format!("The {}.", doc))), c, h)))), &Text::lit("\n"));
            call_value(each_job(n.fields.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: (Text, crate::lower::model::OutTy, Text)| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let (f, t, _) = p0;
                        call_then(crate::emit::cpp::start_cpp_type(cp.clone(), t.clone()), move |cpp_type_1609: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_1609, &crate::emit::cpp::field_id(&f)))))
                    }))
                }) as Rc<dyn Fn((Text, crate::lower::model::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_1572: Array<Text>| {
                let ctor_params = crate::syntax::lexer::chars::join(&append(&Array::from(vec![Text::lit("Path path")]), &each_1572), &Text::lit(", "));
                let ctor_inits = crate::syntax::lexer::chars::join(&append(&Array::from(vec![Text::lit("path(std::move(path))")]), &each(&n.fields, &(|(f, _, _): &(Text, crate::lower::model::OutTy, Text)| Text::from(format!("{}(std::move({}))", &crate::emit::cpp::field_id(f), &crate::emit::cpp::field_id(f)))))), &Text::lit(", "));
                call_value(each_job(n.params.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let (p_, t) = p0;
                            call_then(crate::emit::cpp::expr::start_param_type(cp.clone(), t.clone()), move |param_type_1848: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}, ", &param_type_1848, &p_))))
                        }))
                    }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_1819: Array<Text>| {
                    let params = concat(&each_1819);
                    let ret = if n.fallible {
                        Text::from(format!("Result<prism_rtl::Rc<{}>>", &n.name))
                    } else {
                        Text::from(format!("prism_rtl::Rc<{}>", &n.name))
                    };
                    let make_decl = Text::from(format!("static {} make(Path path, {}Cx& cx);", &ret, &params));
                    call_value(each_job(append(&n.methods, &n.hosted), {
                        let ncp = ncp.clone();
                        Rc::new(move |p0: crate::lower::model::MethDef| {
                            let ncp = ncp.clone();
                            entered(once_job(move || {
                                let m = p0;
                                call_then(start_method_sig(ncp.clone(), m.clone(), Text::lit("")), move |method_sig_2099: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &method_sig_2099))))
                            }))
                        }) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>
                    }), move |each_2057: Array<Text>| {
                        let method_decls = each_2057;
                        let builder_decls = append(&each(&n.builders, &(|b: &crate::lower::model::ForDef| Text::from(format!("Done {}_build(Cx& cx);", &b.name)))), &each(&n.gens, &(|g: &crate::lower::model::GenDef| Text::from(format!("Done {}_build(Cx& cx);", &g.name)))));
                        let hook_decls = each(&n.hooks, &(|(h, _): &(Text, Array<crate::lower::model::Do>)| Text::from(format!("{} override;", &hook_sig(h, &Text::lit(""))))));
                        let answer_decl = if &len(&n.answers) == &Nat::from(0u32) {
                            Array::new()
                        } else {
                            Array::from(vec![Text::lit("Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;")])
                        };
                        let row_decl = if &n.row_kind == &crate::lower::model::RowKind::NotARow {
                            Array::new()
                        } else {
                            Array::from(vec![Text::lit("void leave_row(Cx& cx) override;")])
                        };
                        let decls = crate::syntax::lexer::chars::join(&append(&append(&append(&append(&append(&Array::from(vec![make_decl.clone()]), &method_decls), &builder_decls), &hook_decls), &answer_decl), &row_decl), &Text::lit("\n"));
                        let doc = crate::emit::cpp::items::cpp_source_doc(&Text::from(format!("`{}`: a node of its own (claude/backend.md, \"A widget block\").", &n.prism)), &n.doc);
                        let decl = crate::emit::cpp::templates::items::node_class(&doc, &n.name, &base, &fields, &consts, &Text::from(format!("{}({}) : {} {{}}", &n.name, &ctor_params, &ctor_inits)), &decls);
                        let by_field = each(&n.fields, &(|(f, _, _): &(Text, crate::lower::model::OutTy, Text)| or(&fold(&n.inits, &None, &(|found_opt: &Option<crate::lower::model::Ex>, (g, v_): &(Text, crate::lower::model::Ex)| if g == f { Some(v_.clone()) } else { found_opt.clone() })), &crate::lower::model::Ex::XVar(f.clone()))));
                        call_then(crate::emit::cpp::stmts::start_cpp_statements_cp(ncp.clone(), n.lets.clone()), move |cpp_statements_cp_3170: (Text, crate::emit::cpp::Cp)| {
                            let (lets_text, lcp) = cpp_statements_cp_3170;
                            call_value(each_job(by_field.clone(), {
                                let lcp = lcp.clone();
                                Rc::new(move |p0: crate::lower::model::Ex| {
                                    let lcp = lcp.clone();
                                    entered(once_job(move || {
                                        let v_ = p0;
                                        prism_rtl::Turn::More(Rc::new(crate::emit::cpp::expr::CppExpr { cp: lcp.clone(), x: v_.clone() }))
                                    }))
                                }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
                            }), move |each_3239: Array<Text>| {
                                let args = crate::syntax::lexer::chars::join(&append(&Array::from(vec![Text::lit("path")]), &each_3239), &Text::lit(", "));
                                let tail = if n.fallible { Text::lit("return node;") } else { Text::lit("return node;") };
                                call_then(crate::emit::cpp::stmts::start_cpp_statements(crate::emit::cpp::stmts::pointing(&lcp, &Text::lit("node")), n.build.clone()), move |cpp_statements_3463: Text| {
                                    let make = crate::emit::cpp::templates::items::node_make(&n.name, &Text::from(format!("{} {}::make(Path path, {}Cx& cx)", &ret, &n.name, &params)), &lets_text, &args, &crate::syntax::lexer::chars::join(&filter(&Array::from(vec![cpp_statements_3463, tail.clone()]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n")));
                                    call_value(each_job(append(&n.methods, &n.hosted), {
                                        let ncp = ncp.clone();
                                        let n = n.clone();
                                        Rc::new(move |p0: crate::lower::model::MethDef| {
                                            let ncp = ncp.clone();
                                            let n = n.clone();
                                            entered(once_job(move || {
                                                let m = p0;
                                                prism_rtl::Turn::More(Rc::new(MethodDef { cp: ncp.clone(), owner: n.name.clone(), m: m.clone() }))
                                            }))
                                        }) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>
                                    }), move |each_3558: Array<Text>| {
                                        let methods = each_3558;
                                        call_value(each_job(n.builders.clone(), {
                                            let ncp = ncp.clone();
                                            let n = n.clone();
                                            Rc::new(move |p0: crate::lower::model::ForDef| {
                                                let ncp = ncp.clone();
                                                let n = n.clone();
                                                entered(once_job(move || {
                                                    let b = p0;
                                                    prism_rtl::Turn::More(Rc::new(ForBuildCpp { cp: ncp.clone(), owner: n.name.clone(), b: b.clone() }))
                                                }))
                                            }) as Rc<dyn Fn(crate::lower::model::ForDef) -> Rc<dyn prism_rtl::Job<Text>>>
                                        }), move |each_3650: Array<Text>| call_value(each_job(n.gens.clone(), {
                                            let ncp = ncp.clone();
                                            let n = n.clone();
                                            Rc::new(move |p0: crate::lower::model::GenDef| {
                                                let ncp = ncp.clone();
                                                let n = n.clone();
                                                entered(once_job(move || {
                                                    let g = p0;
                                                    prism_rtl::Turn::More(Rc::new(GenBuildCpp { cp: ncp.clone(), owner: n.name.clone(), gd: g.clone() }))
                                                }))
                                            }) as Rc<dyn Fn(crate::lower::model::GenDef) -> Rc<dyn prism_rtl::Job<Text>>>
                                        }), move |each_3702: Array<Text>| {
                                            let builders = append(&each_3650, &each_3702);
                                            call_value(each_job(n.hooks.clone(), {
                                                let n = n.clone();
                                                let ncp = ncp.clone();
                                                Rc::new(move |p0: (Text, Array<crate::lower::model::Do>)| {
                                                    let n = n.clone();
                                                    let ncp = ncp.clone();
                                                    entered(once_job(move || {
                                                        let (h, body) = p0;
                                                        call_then(crate::emit::cpp::stmts::start_cpp_statements(ncp.clone(), body.clone()), move |cpp_statements_3838: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &hook_sig(&h, &Text::from(format!("{}::", &n.name))), &Text::from(format!("{}\nreturn {{}};", &cpp_statements_3838)))))
                                                    }))
                                                }) as Rc<dyn Fn((Text, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>
                                            }), move |each_3764: Array<Text>| {
                                                let hooks = each_3764;
                                                let answer = if &len(&n.answers) == &Nat::from(0u32) {
                                                    Array::new()
                                                } else {
                                                    Array::from(vec![answer_def_cpp(&ncp, &n)])
                                                };
                                                let leaving = if &n.row_kind == &crate::lower::model::RowKind::NotARow {
                                                    Array::new()
                                                } else {
                                                    Array::from(vec![row_leaving(&ncp, &n)])
                                                };
                                                let defs = append(&append(&append(&append(&append(&Array::from(vec![make.clone()]), &methods), &builders), &hooks), &answer), &leaving);
                                                let own = crate::emit::cpp::items::Parts { forward: Array::from(vec![Text::from(format!("class {};", &n.name))]), handles: Array::new(), values: Array::new(), cases: Array::new(), protos: Array::new(), classes: Array::from(vec![decl.clone()]), outer: Array::new(), generic: Array::new(), defs: defs.clone() };
                                                prism_rtl::Turn::Finished(own.clone())
                                            })
                                        }))
                                    })
                                })
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start NodeParts, x`: what the function value is when passed to `@Run`.
pub fn start_node_parts(cp: crate::emit::cpp::Cp, n: crate::lower::model::NodeDef) -> Rc<dyn prism_rtl::Job<crate::emit::cpp::items::Parts>> {
    Rc::new(NodeParts { cp, n })
}

/// ```prism
/// MethodSig: unbounded fn Cp, MethDef, Text -> Text
/// ```
pub fn method_sig(cp: &crate::emit::cpp::Cp, m: &crate::lower::model::MethDef, owner: &Text) -> Text {
    let cx_ = match &m.cx_ {
        crate::lower::model::CxArg::CxMut => Array::from(vec![Text::lit("Cx& cx")]),
        crate::lower::model::CxArg::CxRef => Array::from(vec![Text::lit("const Cx& cx")]),
        crate::lower::model::CxArg::CxNone => Array::new(),
    };
    let params = crate::syntax::lexer::chars::join(&append(&run_to_end(each_job(m.params.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (p_, t) = p0;
                call_then(crate::emit::cpp::expr::start_param_type(cp.clone(), t.clone()), move |param_type_4557: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_4557, &p_))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &cx_), &Text::lit(", "));
    let constness = if &m.recv == &crate::lower::model::Recv::RecvRef {
        Text::lit(" const")
    } else {
        Text::lit("")
    };
    Text::from(format!("{} {}{}({}){}", &crate::emit::cpp::cpp_type(cp, &m.ret), owner, &crate::emit::cpp::expr::node_method_name(cp, &m.name), &params, &constness))
}

/// The step machine of `MethodSig`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MethodSig: unbounded fn Cp, MethDef, Text -> Text
/// ```
pub struct MethodSig {
    pub cp: crate::emit::cpp::Cp,
    pub m: crate::lower::model::MethDef,
    pub owner: Text,
}

impl prism_rtl::Job<Text> for MethodSig {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let m = &self.m;
        let owner = &self.owner;
        let cx_ = match &m.cx_ {
            crate::lower::model::CxArg::CxMut => Array::from(vec![Text::lit("Cx& cx")]),
            crate::lower::model::CxArg::CxRef => Array::from(vec![Text::lit("const Cx& cx")]),
            crate::lower::model::CxArg::CxNone => Array::new(),
        };
        let cp = cp.clone();
        let m = m.clone();
        let owner = owner.clone();
        call_value(each_job(m.params.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let (p_, t) = p0;
                    call_then(crate::emit::cpp::expr::start_param_type(cp.clone(), t.clone()), move |param_type_4557: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_4557, &p_))))
                }))
            }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_4528: Array<Text>| {
            let params = crate::syntax::lexer::chars::join(&append(&each_4528, &cx_), &Text::lit(", "));
            let constness = if &m.recv == &crate::lower::model::Recv::RecvRef {
                Text::lit(" const")
            } else {
                Text::lit("")
            };
            call_then(crate::emit::cpp::start_cpp_type(cp.clone(), m.ret.clone()), move |cpp_type_4657: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}{}({}){}", &cpp_type_4657, &owner, &crate::emit::cpp::expr::node_method_name(&cp, &m.name), &params, &constness))))
        })
    }
}

/// `Start MethodSig, x`: what the function value is when passed to `@Run`.
pub fn start_method_sig(cp: crate::emit::cpp::Cp, m: crate::lower::model::MethDef, owner: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(MethodSig { cp, m, owner })
}

/// ```prism
/// MethodDef: unbounded fn Cp, Text, MethDef -> Text
/// ```
pub fn method_def(cp: &crate::emit::cpp::Cp, owner: &Text, m: &crate::lower::model::MethDef) -> Text {
    let (st, cp2) = crate::emit::cpp::stmts::cpp_statements_cp(cp, &m.body);
    let body = if &m.ret == &crate::lower::model::OutTy::OutUnit {
        Text::from(format!("{}\nreturn Unit{{}};", &st))
    } else {
        if &len(&m.body) == &Nat::from(0u32) {
            crate::emit::cpp::stmts::cpp_body(cp, &m.tail)
        } else {
            Text::from(format!("{}\n{}", &st, &crate::emit::cpp::stmts::cpp_body(&cp2, &m.tail)))
        }
    };
    crate::emit::cpp::templates::items::cpp_function(&crate::emit::cpp::items::cpp_doc(&m.doc), &method_sig(cp, m, &Text::from(format!("{}::", owner))), &body)
}

/// The step machine of `MethodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MethodDef: unbounded fn Cp, Text, MethDef -> Text
/// ```
pub struct MethodDef {
    pub cp: crate::emit::cpp::Cp,
    pub owner: Text,
    pub m: crate::lower::model::MethDef,
}

impl prism_rtl::Job<Text> for MethodDef {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let owner = &self.owner;
        let m = &self.m;
        let cp = cp.clone();
        let m = m.clone();
        let owner = owner.clone();
        call_then(crate::emit::cpp::stmts::start_cpp_statements_cp(cp.clone(), m.body.clone()), move |cpp_statements_cp_4833: (Text, crate::emit::cpp::Cp)| {
            let (st, cp2) = cpp_statements_cp_4833;
            let body = if &m.ret == &crate::lower::model::OutTy::OutUnit {
                Text::from(format!("{}\nreturn Unit{{}};", &st))
            } else {
                if &len(&m.body) == &Nat::from(0u32) {
                    crate::emit::cpp::stmts::cpp_body(&cp, &m.tail)
                } else {
                    Text::from(format!("{}\n{}", &st, &crate::emit::cpp::stmts::cpp_body(&cp2, &m.tail)))
                }
            };
            call_then(start_method_sig(cp.clone(), m.clone(), Text::from(format!("{}::", &owner))), move |method_sig_5037: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&crate::emit::cpp::items::cpp_doc(&m.doc), &method_sig_5037, &body)))
        })
    }
}

/// `Start MethodDef, x`: what the function value is when passed to `@Run`.
pub fn start_method_def(cp: crate::emit::cpp::Cp, owner: Text, m: crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(MethodDef { cp, owner, m })
}

/// ```prism
/// HookSig: fn Text, Text -> Text
/// ```
pub fn hook_sig(text0: &Text, owner: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("push")) => Text::from(format!("Done {}push(const Pod& element, const Pod& v, Cx& cx)", owner)),
        h => Text::from(format!("Done {}{}(Cx& cx)", owner, h)),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// AnswerDefCpp: unbounded fn Cp, NodeDef -> Text
/// ```
pub fn answer_def_cpp(cp: &crate::emit::cpp::Cp, n: &crate::lower::model::NodeDef) -> Text {
    let arms = run_to_end(each_job(n.answers.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (crate::lower::model::Pa, crate::lower::model::Ex)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (pat, call) = p0;
                call_then(crate::emit::cpp::patterns::start_pat_conds(cp.clone(), pat.clone(), Text::lit("at")), move |pat_conds_5380: Array<Text>| {
                    let tests = pat_conds_5380;
                    call_then(crate::emit::cpp::patterns::start_pat_binds(cp.clone(), pat.clone(), Text::lit("at")), move |pat_binds_5423: Array<Text>| {
                        let binds = pat_binds_5423;
                        call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), call.clone()), move |cpp_expr_5484: Text| prism_rtl::Turn::Finished((tests.clone(), crate::syntax::lexer::chars::join(&push(&binds, &Text::from(format!("{};", &cpp_expr_5484))), &Text::lit("\n")))))
                    })
                })
            }))
        }) as Rc<dyn Fn((crate::lower::model::Pa, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Text)>>>
    }));
    let blocks = each(&crate::check::errors::range0(&len(&arms)), &(|i: &Nat| {
        let (tests, inner) = or(&index(&arms, i), &(Array::new(), Text::lit("")));
        crate::emit::cpp::templates::items::block(&Text::from(format!("{} ({})", &(if i == &Nat::from(0u32) { Text::lit("if") } else { Text::lit("else if") }), &crate::emit::cpp::patterns::conds(&tests))), &inner)
    }));
    crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Done {}::answer(std::span<const Segment> at, const Pod& v, Cx& cx)", &n.name)), &Text::from(format!("{} else {{\n    return unexpected(Fault::answer(str(\"no answering place at \", path_of(at))));\n}}\nreturn {{}};", &crate::syntax::lexer::chars::join(&blocks, &Text::lit(" ")))))
}

/// The step machine of `AnswerDefCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnswerDefCpp: unbounded fn Cp, NodeDef -> Text
/// ```
pub struct AnswerDefCpp {
    pub cp: crate::emit::cpp::Cp,
    pub n: crate::lower::model::NodeDef,
}

impl prism_rtl::Job<Text> for AnswerDefCpp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let n = &self.n;
        let cp = cp.clone();
        let n = n.clone();
        call_value(each_job(n.answers.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: (crate::lower::model::Pa, crate::lower::model::Ex)| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let (pat, call) = p0;
                    call_then(crate::emit::cpp::patterns::start_pat_conds(cp.clone(), pat.clone(), Text::lit("at")), move |pat_conds_5380: Array<Text>| {
                        let tests = pat_conds_5380;
                        call_then(crate::emit::cpp::patterns::start_pat_binds(cp.clone(), pat.clone(), Text::lit("at")), move |pat_binds_5423: Array<Text>| {
                            let binds = pat_binds_5423;
                            call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), call.clone()), move |cpp_expr_5484: Text| prism_rtl::Turn::Finished((tests.clone(), crate::syntax::lexer::chars::join(&push(&binds, &Text::from(format!("{};", &cpp_expr_5484))), &Text::lit("\n")))))
                        })
                    })
                }))
            }) as Rc<dyn Fn((crate::lower::model::Pa, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Text)>>>
        }), move |each_5327: Array<(Array<Text>, Text)>| {
            let arms = each_5327;
            let blocks = each(&crate::check::errors::range0(&len(&arms)), &(|i: &Nat| {
                let (tests, inner) = or(&index(&arms, i), &(Array::new(), Text::lit("")));
                crate::emit::cpp::templates::items::block(&Text::from(format!("{} ({})", &(if i == &Nat::from(0u32) { Text::lit("if") } else { Text::lit("else if") }), &crate::emit::cpp::patterns::conds(&tests))), &inner)
            }));
            prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Done {}::answer(std::span<const Segment> at, const Pod& v, Cx& cx)", &n.name)), &Text::from(format!("{} else {{\n    return unexpected(Fault::answer(str(\"no answering place at \", path_of(at))));\n}}\nreturn {{}};", &crate::syntax::lexer::chars::join(&blocks, &Text::lit(" "))))))
        })
    }
}

/// `Start AnswerDefCpp, x`: what the function value is when passed to `@Run`.
pub fn start_answer_def_cpp(cp: crate::emit::cpp::Cp, n: crate::lower::model::NodeDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(AnswerDefCpp { cp, n })
}

/// ```prism
/// RowLeaving: unbounded fn Cp, NodeDef -> Text
/// ```
pub fn row_leaving(cp: &crate::emit::cpp::Cp, n: &crate::lower::model::NodeDef) -> Text {
    let kept = if &n.row_kind == &crate::lower::model::RowKind::ForRow {
        Array::from(vec![Text::lit("this->left_entry = entry(cx);")])
    } else {
        Array::new()
    };
    let unsubscribe = each(&n.subs, &(|(ev, m, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("if (auto p = parent.lock(); p && {}_sub) deref(p->{}_port).unsubscribe(*std::exchange({}_sub, std::nullopt));", m, ev, m))));
    crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("void {}::leave_row(Cx& cx)", &n.name)), &crate::syntax::lexer::chars::join(&append(&push(&kept, &Text::lit("remove_places(cx);")), &unsubscribe), &Text::lit("\n")))
}

/// The step machine of `RowLeaving`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowLeaving: unbounded fn Cp, NodeDef -> Text
/// ```
pub struct RowLeaving {
    pub cp: crate::emit::cpp::Cp,
    pub n: crate::lower::model::NodeDef,
}

impl prism_rtl::Job<Text> for RowLeaving {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let n = &self.n;
        let kept = if &n.row_kind == &crate::lower::model::RowKind::ForRow {
            Array::from(vec![Text::lit("this->left_entry = entry(cx);")])
        } else {
            Array::new()
        };
        let unsubscribe = each(&n.subs, &(|(ev, m, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("if (auto p = parent.lock(); p && {}_sub) deref(p->{}_port).unsubscribe(*std::exchange({}_sub, std::nullopt));", m, ev, m))));
        prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("void {}::leave_row(Cx& cx)", &n.name)), &crate::syntax::lexer::chars::join(&append(&push(&kept, &Text::lit("remove_places(cx);")), &unsubscribe), &Text::lit("\n"))))
    }
}

/// `Start RowLeaving, x`: what the function value is when passed to `@Run`.
pub fn start_row_leaving(cp: crate::emit::cpp::Cp, n: crate::lower::model::NodeDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RowLeaving { cp, n })
}

/// ```prism
/// ForBuildCpp: unbounded fn Cp, Text, ForDef -> Text
/// ```
pub fn for_build_cpp(cp: &crate::emit::cpp::Cp, owner: &Text, b: &crate::lower::model::ForDef) -> Text {
    crate::emit::cpp::templates::items::for_build_template(owner, &b.name, &crate::emit::cpp::expr::cpp_expr(cp, &b.at), &crate::emit::cpp::cpp_type(cp, &b.key_ty), &crate::emit::cpp::cpp_type(cp, &b.value_ty), &crate::emit::cpp::expr::call_path(&Text::from(format!("{}::build", &b.row_node))), &b.source, &crate::emit::cpp::expr::cpp_expr(cp, &b.parent), &concat(&run_to_end(each_job(b.passed.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::Ex| {
            let cp = cp.clone();
            entered(once_job(move || {
                let x = p0;
                call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_6788: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}", &cpp_expr_6788))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
    }))), &moved_call_cpp(&b.moved), &from_kept_cpp(&b.name, &b.replaced), &replaced_call_cpp(&b.replaced))
}

/// The step machine of `ForBuildCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ForBuildCpp: unbounded fn Cp, Text, ForDef -> Text
/// ```
pub struct ForBuildCpp {
    pub cp: crate::emit::cpp::Cp,
    pub owner: Text,
    pub b: crate::lower::model::ForDef,
}

impl prism_rtl::Job<Text> for ForBuildCpp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let owner = &self.owner;
        let b = &self.b;
        let b = b.clone();
        let cp = cp.clone();
        let owner = owner.clone();
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), b.at.clone()), move |cpp_expr_6621: Text| call_then(crate::emit::cpp::start_cpp_type(cp.clone(), b.key_ty.clone()), move |cpp_type_6641: Text| call_then(crate::emit::cpp::start_cpp_type(cp.clone(), b.value_ty.clone()), move |cpp_type_6664: Text| call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), b.parent.clone()), move |cpp_expr_6732: Text| call_value(each_job(b.passed.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: crate::lower::model::Ex| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let x = p0;
                    call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_6788: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}", &cpp_expr_6788))))
                }))
            }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_6764: Array<Text>| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::for_build_template(&owner, &b.name, &cpp_expr_6621, &cpp_type_6641, &cpp_type_6664, &crate::emit::cpp::expr::call_path(&Text::from(format!("{}::build", &b.row_node))), &b.source, &cpp_expr_6732, &concat(&each_6764), &moved_call_cpp(&b.moved), &from_kept_cpp(&b.name, &b.replaced), &replaced_call_cpp(&b.replaced))))))))
    }
}

/// `Start ForBuildCpp, x`: what the function value is when passed to `@Run`.
pub fn start_for_build_cpp(cp: crate::emit::cpp::Cp, owner: Text, b: crate::lower::model::ForDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ForBuildCpp { cp, owner, b })
}

/// ```prism
/// FromKeptCpp: fn Text, [Text] -> Text
/// ```
pub fn from_kept_cpp(name: &Text, replaced: &Array<Text>) -> Text {
    if &len(replaced) == &Nat::from(0u32) {
        Text::from(format!("this->{}_from = items;", name))
    } else {
        Text::from(format!("auto from = std::exchange(this->{}_from, items);", name))
    }
}

/// ```prism
/// ReplacedCallCpp: fn [Text] -> Text
/// ```
pub fn replaced_call_cpp(replaced: &Array<Text>) -> Text {
    if &len(replaced) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" else if (auto was = from.get(k), is = items.get(k); !was || !is || !(*was == *is)) {{\n            // the dynamic under a kept key was replaced: that row follows it from the next tick\n{}        }}", &concat(&each(replaced, &(|m: &Text| Text::from(format!("            row->{}(cx);\n", m)))))))
    }
}

/// ```prism
/// MovedCallCpp: fn Text -> Text
/// ```
pub fn moved_call_cpp(m: &Text) -> Text {
    if m == &Text::lit("") {
        Text::lit("")
    } else {
        Text::from(format!("\n    // the places of the host\'s child came or went: its document\'s outer moves\n    if (!prism_rtl::same_keys(next, old)) this->{}(cx);", m))
    }
}

/// ```prism
/// GenMovedCallCpp: fn Text -> Text
/// ```
pub fn gen_moved_call_cpp(m: &Text) -> Text {
    if m == &Text::lit("") {
        Text::lit("")
    } else {
        Text::from(format!("\n    // the places of the host\'s child came or went: its document\'s outer moves\n    this->{}(cx);", m))
    }
}

/// ```prism
/// GenBuildCpp: unbounded fn Cp, Text, GenDef -> Text
/// ```
pub fn gen_build_cpp(cp: &crate::emit::cpp::Cp, owner: &Text, gd: &crate::lower::model::GenDef) -> Text {
    let path_ = if gd.transparent {
        Text::lit("this->path")
    } else {
        Text::from(format!("{}.child(Segment::gen(g))", &crate::emit::cpp::expr::cpp_expr(cp, &gd.at)))
    };
    crate::emit::cpp::templates::items::gen_build_template(owner, &gd.name, &crate::emit::cpp::expr::cpp_expr(cp, &gd.at), &path_, &crate::emit::cpp::expr::cpp_expr(cp, &gd.source), &crate::emit::cpp::cpp_type(cp, &gd.value_ty), &crate::emit::cpp::expr::cpp_expr(cp, &gd.select), &gen_moved_call_cpp(&gd.moved))
}

/// The step machine of `GenBuildCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GenBuildCpp: unbounded fn Cp, Text, GenDef -> Text
/// ```
pub struct GenBuildCpp {
    pub cp: crate::emit::cpp::Cp,
    pub owner: Text,
    pub gd: crate::lower::model::GenDef,
}

impl prism_rtl::Job<Text> for GenBuildCpp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let owner = &self.owner;
        let gd = &self.gd;
        let path_ = if gd.transparent {
            Text::lit("this->path")
        } else {
            Text::from(format!("{}.child(Segment::gen(g))", &crate::emit::cpp::expr::cpp_expr(cp, &gd.at)))
        };
        let cp = cp.clone();
        let gd = gd.clone();
        let owner = owner.clone();
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), gd.at.clone()), move |cpp_expr_8673: Text| call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), gd.source.clone()), move |cpp_expr_8700: Text| call_then(crate::emit::cpp::start_cpp_type(cp.clone(), gd.value_ty.clone()), move |cpp_type_8725: Text| call_then(crate::emit::cpp::expr::start_cpp_expr(cp.clone(), gd.select.clone()), move |cpp_expr_8751: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::gen_build_template(&owner, &gd.name, &cpp_expr_8673, &path_, &cpp_expr_8700, &cpp_type_8725, &cpp_expr_8751, &gen_moved_call_cpp(&gd.moved)))))))
    }
}

/// `Start GenBuildCpp, x`: what the function value is when passed to `@Run`.
pub fn start_gen_build_cpp(cp: crate::emit::cpp::Cp, owner: Text, gd: crate::lower::model::GenDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(GenBuildCpp { cp, owner, gd })
}

/// ```prism
/// ProgramCpp: unbounded fn Cp, ProgDef, Bool -> Text
/// ```
pub fn program_cpp(cp: &crate::emit::cpp::Cp, p_: &crate::lower::model::ProgDef, fallible: &bool) -> Text {
    let n = len(&p_.params);
    let names = each(&p_.params, &(|(a, _): &(Text, crate::lower::model::OutTy)| a.clone()));
    let plural = if &n == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") };
    let decode = if &n == &Nat::from(0u32) {
        Text::lit("static_cast<void>(args);")
    } else {
        crate::syntax::lexer::chars::join(&append(&Array::from(vec![Text::from(format!("if (args.size() != {}) return unexpected(Fault::answer(\"@{} takes {} argument{}\"));", &n, &p_.prism, &n, &plural))]), &run_to_end(each_job(crate::check::errors::range0(&n), {
            let cp = cp.clone();
            let p_ = p_.clone();
            Rc::new(move |p0: Nat| {
                let cp = cp.clone();
                let p_ = p_.clone();
                entered(once_job(move || {
                    let i = p0;
                    prism_rtl::Turn::More(Rc::new(DecodeArg { cp: cp.clone(), ps: p_.params.clone(), i: i.clone() }))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
        }))), &Text::lit("\n"))
    };
    let call = Text::from(format!("{}(Path::root(), {}cx)", &crate::emit::cpp::expr::call_path(&Text::from(format!("{}::build", &p_.node_))), &concat(&each(&names, &(|a: &Text| Text::from(format!("{}, ", a)))))));
    let root = if *fallible { Text::from(format!("TRY({})", &call)) } else { call.clone() };
    crate::emit::cpp::templates::items::program_class(&p_.name, &p_.prism, &crate::emit::cpp::type_path(&p_.node_), &decode, &root)
}

/// The step machine of `ProgramCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ProgramCpp: unbounded fn Cp, ProgDef, Bool -> Text
/// ```
pub struct ProgramCpp {
    pub cp: crate::emit::cpp::Cp,
    pub p_: crate::lower::model::ProgDef,
    pub fallible: bool,
}

impl prism_rtl::Job<Text> for ProgramCpp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let p_ = &self.p_;
        let fallible = &self.fallible;
        let n = len(&p_.params);
        let names = each(&p_.params, &(|(a, _): &(Text, crate::lower::model::OutTy)| a.clone()));
        let plural = if &n == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") };
        let decode = if &n == &Nat::from(0u32) {
            Text::lit("static_cast<void>(args);")
        } else {
            crate::syntax::lexer::chars::join(&append(&Array::from(vec![Text::from(format!("if (args.size() != {}) return unexpected(Fault::answer(\"@{} takes {} argument{}\"));", &n, &p_.prism, &n, &plural))]), &run_to_end(each_job(crate::check::errors::range0(&n), {
                let cp = cp.clone();
                let p_ = p_.clone();
                Rc::new(move |p0: Nat| {
                    let cp = cp.clone();
                    let p_ = p_.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(DecodeArg { cp: cp.clone(), ps: p_.params.clone(), i: i.clone() }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
            }))), &Text::lit("\n"))
        };
        let call = Text::from(format!("{}(Path::root(), {}cx)", &crate::emit::cpp::expr::call_path(&Text::from(format!("{}::build", &p_.node_))), &concat(&each(&names, &(|a: &Text| Text::from(format!("{}, ", a)))))));
        let root = if *fallible { Text::from(format!("TRY({})", &call)) } else { call.clone() };
        prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::program_class(&p_.name, &p_.prism, &crate::emit::cpp::type_path(&p_.node_), &decode, &root))
    }
}

/// `Start ProgramCpp, x`: what the function value is when passed to `@Run`.
pub fn start_program_cpp(cp: crate::emit::cpp::Cp, p_: crate::lower::model::ProgDef, fallible: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ProgramCpp { cp, p_, fallible })
}

/// ```prism
/// DecodeArg: unbounded fn Cp, [((Text, OutTy))], Nat -> Text
/// ```
pub fn decode_arg(cp: &crate::emit::cpp::Cp, ps: &Array<(Text, crate::lower::model::OutTy)>, i: &Nat) -> Text {
    match index(ps, i) {
        Some((a, t)) => Text::from(format!("auto {} = TRY(prism_rtl::from_pod<{}>(args[{}]));", &a, &crate::emit::cpp::cpp_type(cp, &t), i)),
        None => Text::lit(""),
    }
}

/// The step machine of `DecodeArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DecodeArg: unbounded fn Cp, [((Text, OutTy))], Nat -> Text
/// ```
pub struct DecodeArg {
    pub cp: crate::emit::cpp::Cp,
    pub ps: Array<(Text, crate::lower::model::OutTy)>,
    pub i: Nat,
}

impl prism_rtl::Job<Text> for DecodeArg {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let ps = &self.ps;
        let i = &self.i;
        match index(ps, i) {
            Some((a, t)) => {
                let cp = cp.clone();
                let i = i.clone();
                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), t.clone()), move |cpp_type_9609: Text| prism_rtl::Turn::Finished(Text::from(format!("auto {} = TRY(prism_rtl::from_pod<{}>(args[{}]));", &a, &cpp_type_9609, &i))))
            },
            None => prism_rtl::Turn::Finished(Text::lit("")),
        }
    }
}

/// `Start DecodeArg, x`: what the function value is when passed to `@Run`.
pub fn start_decode_arg(cp: crate::emit::cpp::Cp, ps: Array<(Text, crate::lower::model::OutTy)>, i: Nat) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(DecodeArg { cp, ps, i })
}

/// ```prism
/// ModuleParts: unbounded fn Cp, ModDef -> Parts
/// ```
pub fn module_parts(cp: &crate::emit::cpp::Cp, m: &crate::lower::model::ModDef) -> crate::emit::cpp::items::Parts {
    let mcp = crate::emit::cpp::in_home(cp, &m.name);
    let all = run_to_end(fold_job(m.items.clone(), crate::emit::cpp::items::no_parts(), {
        let mcp = mcp.clone();
        Rc::new(move |(p0, p1): (crate::emit::cpp::items::Parts, crate::lower::model::Item)| {
            let mcp = mcp.clone();
            entered(once_job(move || {
                let acc = p0;
                let it = p1;
                call_then(crate::emit::cpp::items::start_item_parts(mcp.clone(), it.clone()), move |item_parts_10058: crate::emit::cpp::items::Parts| prism_rtl::Turn::Finished(crate::emit::cpp::items::join_parts(&acc, &item_parts_10058)))
            }))
        }) as Rc<dyn Fn((crate::emit::cpp::items::Parts, crate::lower::model::Item)) -> Rc<dyn prism_rtl::Job<crate::emit::cpp::items::Parts>>>
    }));
    crate::emit::cpp::items::Parts { forward: in_ns(&m.name, &all.forward), handles: in_ns(&m.name, &all.handles), values: each(&all.values, &(|v_: &crate::emit::cpp::items::ValueDecl| in_ns_value(&m.name, v_))), cases: in_ns(&m.name, &all.cases), protos: in_ns(&m.name, &all.protos), classes: in_ns(&m.name, &all.classes), outer: all.outer.clone(), generic: in_ns(&m.name, &all.generic), defs: all.defs.clone() }
}

/// The step machine of `ModuleParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModuleParts: unbounded fn Cp, ModDef -> Parts
/// ```
pub struct ModuleParts {
    pub cp: crate::emit::cpp::Cp,
    pub m: crate::lower::model::ModDef,
}

impl prism_rtl::Job<crate::emit::cpp::items::Parts> for ModuleParts {
    fn cycle(&self) -> prism_rtl::Turn<crate::emit::cpp::items::Parts> {
        let cp = &self.cp;
        let m = &self.m;
        let mcp = crate::emit::cpp::in_home(cp, &m.name);
        let m = m.clone();
        call_value(fold_job(m.items.clone(), crate::emit::cpp::items::no_parts(), {
            let mcp = mcp.clone();
            Rc::new(move |(p0, p1): (crate::emit::cpp::items::Parts, crate::lower::model::Item)| {
                let mcp = mcp.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let it = p1;
                    call_then(crate::emit::cpp::items::start_item_parts(mcp.clone(), it.clone()), move |item_parts_10058: crate::emit::cpp::items::Parts| prism_rtl::Turn::Finished(crate::emit::cpp::items::join_parts(&acc, &item_parts_10058)))
                }))
            }) as Rc<dyn Fn((crate::emit::cpp::items::Parts, crate::lower::model::Item)) -> Rc<dyn prism_rtl::Job<crate::emit::cpp::items::Parts>>>
        }), move |fold_10008: crate::emit::cpp::items::Parts| {
            let all = fold_10008;
            prism_rtl::Turn::Finished(crate::emit::cpp::items::Parts { forward: in_ns(&m.name, &all.forward), handles: in_ns(&m.name, &all.handles), values: each(&all.values, &(|v_: &crate::emit::cpp::items::ValueDecl| in_ns_value(&m.name, v_))), cases: in_ns(&m.name, &all.cases), protos: in_ns(&m.name, &all.protos), classes: in_ns(&m.name, &all.classes), outer: all.outer.clone(), generic: in_ns(&m.name, &all.generic), defs: all.defs.clone() })
        })
    }
}

/// `Start ModuleParts, x`: what the function value is when passed to `@Run`.
pub fn start_module_parts(cp: crate::emit::cpp::Cp, m: crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<crate::emit::cpp::items::Parts>> {
    Rc::new(ModuleParts { cp, m })
}

/// ```prism
/// InNsValue: fn Text, ValueDecl -> ValueDecl
/// ```
pub fn in_ns_value(ns: &Text, v_: &crate::emit::cpp::items::ValueDecl) -> crate::emit::cpp::items::ValueDecl {
    let mut this: crate::emit::cpp::items::ValueDecl = v_.clone();
    this.text = Text::from(format!("namespace {} {{\n\n{}\n\n}}  // namespace {}", ns, &this.text, ns));
    this
}

/// ```prism
/// InNs: fn Text, [Text] -> [Text]
/// ```
pub fn in_ns(ns: &Text, xs1: &Array<Text>) -> Array<Text> {
    match xs1 {
        c0_1 if (c0_1.len() == 0) => Array::new(),
        xs => Array::from(vec![Text::from(format!("namespace {} {{\n\n{}\n\n}}  // namespace {}", ns, &crate::syntax::lexer::chars::join(xs, &Text::lit("\n\n")), ns))]),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// NodeFallibleCpp: fn Model, Text -> Bool
/// ```
pub fn node_fallible_cpp(model: &crate::lower::model::Model, path_: &Text) -> bool {
    fold(&model.mods, &false, &(|f: &bool, m: &crate::lower::model::ModDef| fold(&m.items, f, &(|f2: &bool, it: &crate::lower::model::Item| match it {
        crate::lower::model::Item::ItNode(n) => *f2 || ((&Text::from(format!("{}::{}", &m.name, &n.name)) == path_) && n.fallible),
        _ => *f2,
    }))))
}

/// ```prism
/// EmitCpp: unbounded fn Model, Text, [Text] -> [((Text, Text))]
/// ```
pub fn emit_cpp(model: &crate::lower::model::Model, runtime: &Text, scripts: &Array<Text>) -> Array<(Text, Text)> {
    let cp = crate::emit::cpp::context(model);
    let crate_ = crate::emit::cpp::in_home(&cp, &Text::lit(""));
    let elem = crate::emit::cpp::items::row_parts(&crate_, &Text::lit(""), &model.elem);
    let answer = crate::emit::cpp::items::answer_parts(&crate_, &model.answer);
    let mods = run_to_end(each_job(model.mods.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::ModDef| {
            let cp = cp.clone();
            entered(once_job(move || {
                let m = p0;
                prism_rtl::Turn::More(Rc::new(ModuleParts { cp: cp.clone(), m: m.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<crate::emit::cpp::items::Parts>>>
    }));
    let programs = crate::syntax::lexer::chars::join(&run_to_end(each_job(all_programs_cpp(model), {
        let crate_ = crate_.clone();
        let model = model.clone();
        Rc::new(move |p0: crate::lower::model::ProgDef| {
            let crate_ = crate_.clone();
            let model = model.clone();
            entered(once_job(move || {
                let p_ = p0;
                prism_rtl::Turn::More(Rc::new(ProgramCpp { cp: crate_.clone(), p_: p_.clone(), fallible: node_fallible_cpp(&model, &p_.node_) }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::ProgDef) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n\n"));
    let regs = concat(&each(&model.programs, &(|p_: &crate::lower::model::ProgDef| Text::from(format!("\n.program<{}>(\"{}\")", &p_.name, &p_.prism)))));
    let checks = concat(&run_to_end(each_job(model.checks.clone(), {
        let crate_ = crate_.clone();
        Rc::new(move |p0: crate::lower::model::CheckDef| {
            let crate_ = crate_.clone();
            entered(once_job(move || {
                let c = p0;
                call_value(each_job(c.lines.clone(), {
                    let crate_ = crate_.clone();
                    Rc::new(move |p0: crate::lower::model::Ex| {
                        let crate_ = crate_.clone();
                        entered(once_job(move || {
                            let l = p0;
                            prism_rtl::Turn::More(Rc::new(crate::emit::cpp::expr::CppExpr { cp: crate_.clone(), x: l.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_11629: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("\n.check(\"{}\", [] {{ return std::vector<Result<Pod>>{{{}}}; }})", &c.name, &crate::syntax::lexer::chars::join(&each_11629, &Text::lit(", "))))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::CheckDef) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let script_list = crate::syntax::lexer::chars::join(&each(scripts, &(|s: &Text| Text::from(format!("\"{}\",", &crate::lower::expr::escape(s))))), &Text::lit("\n"));
    let world = match &model.root {
        Some(r) => r.world.clone(),
        None => Text::lit("test"),
    };
    let canvas = &world == &Text::lit("canvas");
    let run_root = match &model.root {
        Some(r) => crate::emit::cpp::templates::cpp_run_root(&r.name, &(if canvas {
            crate::emit::cpp::templates::cpp_canvas_run(&r.name)
        } else {
            crate::emit::cpp::templates::cpp_no_canvas(&r.name)
        })),
        None => crate::emit::cpp::templates::cpp_no_root(&model.name),
    };
    let both_ = crate::emit::cpp::items::join_parts(&elem, &answer);
    let elem_decl = crate::emit::cpp::templates::cpp_elem_decl(&includes(&Text::lit("decl"), &append(&model.elem_complete, &model.elem_declared)), &crate::syntax::lexer::chars::join(&both_.forward, &Text::lit("\n\n")), &crate::syntax::lexer::chars::join(&both_.handles, &Text::lit("\n\n")), &crate::emit::cpp::prelude::cpp_prelude_rows(&Text::lit("")));
    let elem_types = crate::emit::cpp::templates::cpp_elem_types(&crate::syntax::lexer::chars::join(&filter(&Array::from(vec![includes(&Text::lit("types"), &model.elem_complete), includes(&Text::lit("decl"), &model.elem_declared)]), &(|t: &Text| t != &Text::lit(""))), &Text::lit("\n")), &crate::syntax::lexer::chars::join(&both_.cases, &Text::lit("\n\n")));
    let pairs = each(&crate::check::errors::range0(&len(&model.mods)), &(|i: &Nat| (or(&index(&model.mods, i), &no_mod()), or(&index(&mods, i), &crate::emit::cpp::items::no_parts()))));
    let generics = fold(&pairs, &Array::new(), &(|acc: &Array<Text>, (m, p_): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| if &len(&p_.generic) > &Nat::from(0u32) { push(acc, &m.name) } else { acc.clone() }));
    let per_module = run_to_end(each_job(pairs.clone(), Rc::new(move |p0: (crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| entered(once_job(move || {
        let (m, p_) = p0;
        prism_rtl::Turn::More(Rc::new(ModuleFiles { m: m.clone(), p_: p_.clone() }))
    }))) as Rc<dyn Fn((crate::lower::model::ModDef, crate::emit::cpp::items::Parts)) -> Rc<dyn prism_rtl::Job<(Array<(Text, Text)>, Array<Piece>)>>>));
    let pieces = fold(&per_module, &Array::new(), &(|acc: &Array<Piece>, (_, ps): &(Array<(Text, Text)>, Array<Piece>)| append(acc, ps)));
    let units_ = units(&pieces);
    let unit_files = each(&crate::check::errors::range0(&len(&units_)), &(|k: &Nat| unit_file(k, &or(&index(&units_, k), &Array::new()), &generics)));
    let main_includes = crate::syntax::lexer::chars::join(&append(&append(&Array::from(vec![Text::lit("#include \"elem.types.hpp\"")]), &Array::from(vec![includes(&Text::lit(""), &each(&model.mods, &(|m: &crate::lower::model::ModDef| m.name.clone())))])), &Array::from(vec![includes(&Text::lit("generic"), &generics)])), &Text::lit("\n"));
    let canvas_include = if canvas {
        crate::emit::cpp::templates::cpp_canvas_include(&Text::lit(""))
    } else {
        Text::lit("")
    };
    let main = crate::emit::cpp::templates::cpp_main(&model.name, &Text::from(format!("#include \"programs.hpp\"\n{}", &canvas_include)), &regs, &checks, &script_list, &world, &run_root, &crate::syntax::lexer::chars::join(&crate::emit::cpp::patterns::concat2(&each(&Array::from(vec![elem.clone(), answer.clone()]), &(|p_: &crate::emit::cpp::items::Parts| p_.defs.clone()))), &Text::lit("\n\n")));
    let groups = run_to_end(each_job(filter(&model.mods, &(|m: &crate::lower::model::ModDef| (&len(&m.types_with) > &Nat::from(1u32)) && (&or(&index(&m.types_with, &Nat::from(0u32)), &Text::lit("")) == &m.name))), {
        let pairs = pairs.clone();
        Rc::new(move |p0: crate::lower::model::ModDef| {
            let pairs = pairs.clone();
            entered(once_job(move || {
                let m = p0;
                prism_rtl::Turn::More(Rc::new(GroupTypesFile { pairs: pairs.clone(), group: m.types_with.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<(Text, Text)>>>
    }));
    let files = append(&fold(&per_module, &Array::new(), &(|acc: &Array<(Text, Text)>, (fs, _): &(Array<(Text, Text)>, Array<Piece>)| append(acc, fs))), &unit_files);
    let sources = crate::syntax::lexer::chars::join(&filter(&each(&files, &(|(f, _): &(Text, Text)| f.clone())), &(|f: &Text| crate::syntax::lexer::chars::contains(f, &Text::lit(".cpp")))), &Text::lit(" "));
    append(&Array::from(vec![(Text::lit("Makefile"), crate::emit::cpp::templates::cpp_makefile(&model.name, runtime, &sources, &(if canvas {
        crate::emit::cpp::templates::cpp_makefile_canvas(runtime)
    } else {
        Text::lit("")
    }))), (Text::lit("src/elem.decl.hpp"), elem_decl.clone()), (Text::lit("src/elem.types.hpp"), elem_types.clone()), (Text::lit("src/programs.hpp"), crate::emit::cpp::templates::cpp_programs_header(&model.name, &main_includes, &programs)), (Text::lit("src/main.cpp"), main.clone()), (Text::lit("src/prelude.hpp"), crate::emit::cpp::prelude::cpp_prelude_source(&Text::lit("")))]), &append(&groups, &files))
}

/// The step machine of `EmitCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EmitCpp: unbounded fn Model, Text, [Text] -> [((Text, Text))]
/// ```
pub struct EmitCpp {
    pub model: crate::lower::model::Model,
    pub runtime: Text,
    pub scripts: Array<Text>,
}

impl prism_rtl::Job<Array<(Text, Text)>> for EmitCpp {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Text, Text)>> {
        let model = &self.model;
        let runtime = &self.runtime;
        let scripts = &self.scripts;
        let cp = crate::emit::cpp::context(model);
        let crate_ = crate::emit::cpp::in_home(&cp, &Text::lit(""));
        let model = model.clone();
        let runtime = runtime.clone();
        let scripts = scripts.clone();
        call_then(crate::emit::cpp::items::start_row_parts(crate_.clone(), Text::lit(""), model.elem.clone()), move |row_parts_11166: crate::emit::cpp::items::Parts| {
            let elem = row_parts_11166;
            call_then(crate::emit::cpp::items::start_answer_parts(crate_.clone(), model.answer.clone()), move |answer_parts_11214: crate::emit::cpp::items::Parts| {
                let answer = answer_parts_11214;
                call_value(each_job(model.mods.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: crate::lower::model::ModDef| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let m = p0;
                            prism_rtl::Turn::More(Rc::new(ModuleParts { cp: cp.clone(), m: m.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<crate::emit::cpp::items::Parts>>>
                }), move |each_11261: Array<crate::emit::cpp::items::Parts>| {
                    let mods = each_11261;
                    call_value(each_job(all_programs_cpp(&model), {
                        let crate_ = crate_.clone();
                        let model = model.clone();
                        Rc::new(move |p0: crate::lower::model::ProgDef| {
                            let crate_ = crate_.clone();
                            let model = model.clone();
                            entered(once_job(move || {
                                let p_ = p0;
                                prism_rtl::Turn::More(Rc::new(ProgramCpp { cp: crate_.clone(), p_: p_.clone(), fallible: node_fallible_cpp(&model, &p_.node_) }))
                            }))
                        }) as Rc<dyn Fn(crate::lower::model::ProgDef) -> Rc<dyn prism_rtl::Job<Text>>>
                    }), move |each_11326: Array<Text>| {
                        let programs = crate::syntax::lexer::chars::join(&each_11326, &Text::lit("\n\n"));
                        let regs = concat(&each(&model.programs, &(|p_: &crate::lower::model::ProgDef| Text::from(format!("\n.program<{}>(\"{}\")", &p_.name, &p_.prism)))));
                        call_value(each_job(model.checks.clone(), {
                            let crate_ = crate_.clone();
                            Rc::new(move |p0: crate::lower::model::CheckDef| {
                                let crate_ = crate_.clone();
                                entered(once_job(move || {
                                    let c = p0;
                                    call_value(each_job(c.lines.clone(), {
                                        let crate_ = crate_.clone();
                                        Rc::new(move |p0: crate::lower::model::Ex| {
                                            let crate_ = crate_.clone();
                                            entered(once_job(move || {
                                                let l = p0;
                                                prism_rtl::Turn::More(Rc::new(crate::emit::cpp::expr::CppExpr { cp: crate_.clone(), x: l.clone() }))
                                            }))
                                        }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
                                    }), move |each_11629: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("\n.check(\"{}\", [] {{ return std::vector<Result<Pod>>{{{}}}; }})", &c.name, &crate::syntax::lexer::chars::join(&each_11629, &Text::lit(", "))))))
                                }))
                            }) as Rc<dyn Fn(crate::lower::model::CheckDef) -> Rc<dyn prism_rtl::Job<Text>>>
                        }), move |each_11535: Array<Text>| {
                            let checks = concat(&each_11535);
                            let script_list = crate::syntax::lexer::chars::join(&each(&scripts, &(|s: &Text| Text::from(format!("\"{}\",", &crate::lower::expr::escape(s))))), &Text::lit("\n"));
                            let world = match &model.root {
                                Some(r) => r.world.clone(),
                                None => Text::lit("test"),
                            };
                            let canvas = &world == &Text::lit("canvas");
                            let run_root = match &model.root {
                                Some(r) => crate::emit::cpp::templates::cpp_run_root(&r.name, &(if canvas {
                                    crate::emit::cpp::templates::cpp_canvas_run(&r.name)
                                } else {
                                    crate::emit::cpp::templates::cpp_no_canvas(&r.name)
                                })),
                                None => crate::emit::cpp::templates::cpp_no_root(&model.name),
                            };
                            let both_ = crate::emit::cpp::items::join_parts(&elem, &answer);
                            let elem_decl = crate::emit::cpp::templates::cpp_elem_decl(&includes(&Text::lit("decl"), &append(&model.elem_complete, &model.elem_declared)), &crate::syntax::lexer::chars::join(&both_.forward, &Text::lit("\n\n")), &crate::syntax::lexer::chars::join(&both_.handles, &Text::lit("\n\n")), &crate::emit::cpp::prelude::cpp_prelude_rows(&Text::lit("")));
                            let elem_types = crate::emit::cpp::templates::cpp_elem_types(&crate::syntax::lexer::chars::join(&filter(&Array::from(vec![includes(&Text::lit("types"), &model.elem_complete), includes(&Text::lit("decl"), &model.elem_declared)]), &(|t: &Text| t != &Text::lit(""))), &Text::lit("\n")), &crate::syntax::lexer::chars::join(&both_.cases, &Text::lit("\n\n")));
                            let pairs = each(&crate::check::errors::range0(&len(&model.mods)), &(|i: &Nat| (or(&index(&model.mods, i), &no_mod()), or(&index(&mods, i), &crate::emit::cpp::items::no_parts()))));
                            let generics = fold(&pairs, &Array::new(), &(|acc: &Array<Text>, (m, p_): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| if &len(&p_.generic) > &Nat::from(0u32) { push(acc, &m.name) } else { acc.clone() }));
                            call_value(each_job(pairs.clone(), Rc::new(move |p0: (crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| entered(once_job(move || {
                                let (m, p_) = p0;
                                prism_rtl::Turn::More(Rc::new(ModuleFiles { m: m.clone(), p_: p_.clone() }))
                            }))) as Rc<dyn Fn((crate::lower::model::ModDef, crate::emit::cpp::items::Parts)) -> Rc<dyn prism_rtl::Job<(Array<(Text, Text)>, Array<Piece>)>>>), move |each_12649: Array<(Array<(Text, Text)>, Array<Piece>)>| {
                                let per_module = each_12649;
                                let pieces = fold(&per_module, &Array::new(), &(|acc: &Array<Piece>, (_, ps): &(Array<(Text, Text)>, Array<Piece>)| append(acc, ps)));
                                let units_ = units(&pieces);
                                let unit_files = each(&crate::check::errors::range0(&len(&units_)), &(|k: &Nat| unit_file(k, &or(&index(&units_, k), &Array::new()), &generics)));
                                let main_includes = crate::syntax::lexer::chars::join(&append(&append(&Array::from(vec![Text::lit("#include \"elem.types.hpp\"")]), &Array::from(vec![includes(&Text::lit(""), &each(&model.mods, &(|m: &crate::lower::model::ModDef| m.name.clone())))])), &Array::from(vec![includes(&Text::lit("generic"), &generics)])), &Text::lit("\n"));
                                let canvas_include = if canvas {
                                    crate::emit::cpp::templates::cpp_canvas_include(&Text::lit(""))
                                } else {
                                    Text::lit("")
                                };
                                let main = crate::emit::cpp::templates::cpp_main(&model.name, &Text::from(format!("#include \"programs.hpp\"\n{}", &canvas_include)), &regs, &checks, &script_list, &world, &run_root, &crate::syntax::lexer::chars::join(&crate::emit::cpp::patterns::concat2(&each(&Array::from(vec![elem.clone(), answer.clone()]), &(|p_: &crate::emit::cpp::items::Parts| p_.defs.clone()))), &Text::lit("\n\n")));
                                call_value(each_job(filter(&model.mods, &(|m: &crate::lower::model::ModDef| (&len(&m.types_with) > &Nat::from(1u32)) && (&or(&index(&m.types_with, &Nat::from(0u32)), &Text::lit("")) == &m.name))), {
                                    let pairs = pairs.clone();
                                    Rc::new(move |p0: crate::lower::model::ModDef| {
                                        let pairs = pairs.clone();
                                        entered(once_job(move || {
                                            let m = p0;
                                            prism_rtl::Turn::More(Rc::new(GroupTypesFile { pairs: pairs.clone(), group: m.types_with.clone() }))
                                        }))
                                    }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<(Text, Text)>>>
                                }), move |each_13329: Array<(Text, Text)>| {
                                    let groups = each_13329;
                                    let files = append(&fold(&per_module, &Array::new(), &(|acc: &Array<(Text, Text)>, (fs, _): &(Array<(Text, Text)>, Array<Piece>)| append(acc, fs))), &unit_files);
                                    let sources = crate::syntax::lexer::chars::join(&filter(&each(&files, &(|(f, _): &(Text, Text)| f.clone())), &(|f: &Text| crate::syntax::lexer::chars::contains(f, &Text::lit(".cpp")))), &Text::lit(" "));
                                    prism_rtl::Turn::Finished(append(&Array::from(vec![(Text::lit("Makefile"), crate::emit::cpp::templates::cpp_makefile(&model.name, &runtime, &sources, &(if canvas {
                                        crate::emit::cpp::templates::cpp_makefile_canvas(&runtime)
                                    } else {
                                        Text::lit("")
                                    }))), (Text::lit("src/elem.decl.hpp"), elem_decl.clone()), (Text::lit("src/elem.types.hpp"), elem_types.clone()), (Text::lit("src/programs.hpp"), crate::emit::cpp::templates::cpp_programs_header(&model.name, &main_includes, &programs)), (Text::lit("src/main.cpp"), main.clone()), (Text::lit("src/prelude.hpp"), crate::emit::cpp::prelude::cpp_prelude_source(&Text::lit("")))]), &append(&groups, &files)))
                                })
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start EmitCpp, x`: what the function value is when passed to `@Run`.
pub fn start_emit_cpp(model: crate::lower::model::Model, runtime: Text, scripts: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>> {
    Rc::new(EmitCpp { model, runtime, scripts })
}

/// ```prism
/// let noMod
/// ```
pub fn no_mod() -> crate::lower::model::ModDef {
    crate::lower::model::ModDef { name: Text::lit(""), prism: Text::lit(""), path_: Text::lit(""), uses: Array::new(), complete: Array::new(), declared: Array::new(), types_with: Array::new(), items: Array::new() }
}

/// ```prism
/// GroupTypesFile: unbounded fn [((ModDef, Parts))], [Text] -> ((Text, Text))
/// ```
pub fn group_types_file(pairs: &Array<(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)>, group: &Array<Text>) -> (Text, Text) {
    let members = filter(pairs, &(|(m, _): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| among(group, &m.name)));
    let p_ = fold(&members, &crate::emit::cpp::items::no_parts(), &(|acc: &crate::emit::cpp::items::Parts, (_, q): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| crate::emit::cpp::items::join_parts(acc, q)));
    let complete = fold(&members, &Array::new(), &(|acc: &Array<Text>, (m, _): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| fold(&m.complete, acc, &(|a: &Array<Text>, n: &Text| if among(a, n) || among(group, n) { a.clone() } else { push(a, n) }))));
    let declared_ = fold(&members, &Array::new(), &(|acc: &Array<Text>, (m, _): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| fold(&m.declared, acc, &(|a: &Array<Text>, n: &Text| if (among(a, n) || among(group, n)) || among(&complete, n) {
        a.clone()
    } else {
        push(a, n)
    }))));
    let title = Text::from(format!("The modules {}", &crate::syntax::lexer::chars::join(&each(group, &(|n: &Text| Text::from(format!("`{}`", n)))), &Text::lit(", "))));
    (Text::from(format!("src/{}.types.hpp", &group_name(group))), types_header(&title, group, &declared_, &complete, &p_))
}

/// The step machine of `GroupTypesFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GroupTypesFile: unbounded fn [((ModDef, Parts))], [Text] -> ((Text, Text))
/// ```
pub struct GroupTypesFile {
    pub pairs: Array<(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)>,
    pub group: Array<Text>,
}

impl prism_rtl::Job<(Text, Text)> for GroupTypesFile {
    fn cycle(&self) -> prism_rtl::Turn<(Text, Text)> {
        let pairs = &self.pairs;
        let group = &self.group;
        let members = filter(pairs, &(|(m, _): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| among(group, &m.name)));
        let p_ = fold(&members, &crate::emit::cpp::items::no_parts(), &(|acc: &crate::emit::cpp::items::Parts, (_, q): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| crate::emit::cpp::items::join_parts(acc, q)));
        let complete = fold(&members, &Array::new(), &(|acc: &Array<Text>, (m, _): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| fold(&m.complete, acc, &(|a: &Array<Text>, n: &Text| if among(a, n) || among(group, n) { a.clone() } else { push(a, n) }))));
        let declared_ = fold(&members, &Array::new(), &(|acc: &Array<Text>, (m, _): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| fold(&m.declared, acc, &(|a: &Array<Text>, n: &Text| if (among(a, n) || among(group, n)) || among(&complete, n) {
            a.clone()
        } else {
            push(a, n)
        }))));
        let title = Text::from(format!("The modules {}", &crate::syntax::lexer::chars::join(&each(group, &(|n: &Text| Text::from(format!("`{}`", n)))), &Text::lit(", "))));
        let group = group.clone();
        call_then(start_types_header(title.clone(), group.clone(), declared_.clone(), complete.clone(), p_.clone()), move |types_header_14999: Text| prism_rtl::Turn::Finished((Text::from(format!("src/{}.types.hpp", &group_name(&group))), types_header_14999)))
    }
}

/// `Start GroupTypesFile, x`: what the function value is when passed to `@Run`.
pub fn start_group_types_file(pairs: Array<(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)>, group: Array<Text>) -> Rc<dyn prism_rtl::Job<(Text, Text)>> {
    Rc::new(GroupTypesFile { pairs, group })
}

/// ```prism
/// GroupName: fn [Text] -> Text
/// ```
pub fn group_name(group: &Array<Text>) -> Text {
    crate::syntax::lexer::chars::join(&each(group, &(|n: &Text| crate::syntax::lexer::chars::join(&split_on(n, &Text::lit("::")), &Text::lit("_")))), &Text::lit("-"))
}

/// ```prism
/// ModDir: fn Text -> Text
/// ```
pub fn mod_dir(m: &Text) -> Text {
    crate::syntax::lexer::chars::join(&split_on(m, &Text::lit("::")), &Text::lit("/"))
}

/// ```prism
/// Among: fn [Text], Text -> Bool
/// ```
pub fn among(xs: &Array<Text>, x: &Text) -> bool {
    fold(xs, &false, &(|f: &bool, y: &Text| *f || (y == x)))
}

/// ```prism
/// TypesHeader: unbounded fn Text, [Text], [Text], [Text], Parts -> Text
/// ```
pub fn types_header(title: &Text, members: &Array<Text>, declared_: &Array<Text>, complete: &Array<Text>, p_: &crate::emit::cpp::items::Parts) -> Text {
    let includes_ = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![includes(&Text::lit("decl"), members), Text::lit("#include \"elem.decl.hpp\""), includes(&Text::lit("decl"), declared_), includes(&Text::lit("types"), complete)]), &(|t: &Text| t != &Text::lit(""))), &Text::lit("\n"));
    let values_ = crate::syntax::lexer::chars::join(&order_values(&p_.values, &fold(&p_.values, &Map::new(), &(|acc: &Map<Text, bool>, v_: &crate::emit::cpp::items::ValueDecl| insert(acc, &v_.path_, &false))), &Array::new()), &Text::lit("\n\n"));
    crate::emit::cpp::templates::cpp_types_header(title, &includes_, &values_, &crate::syntax::lexer::chars::join(&p_.cases, &Text::lit("\n\n")))
}

/// The step machine of `TypesHeader`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypesHeader: unbounded fn Text, [Text], [Text], [Text], Parts -> Text
/// ```
pub struct TypesHeader {
    pub title: Text,
    pub members: Array<Text>,
    pub declared_: Array<Text>,
    pub complete: Array<Text>,
    pub p_: crate::emit::cpp::items::Parts,
}

impl prism_rtl::Job<Text> for TypesHeader {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let title = &self.title;
        let members = &self.members;
        let declared_ = &self.declared_;
        let complete = &self.complete;
        let p_ = &self.p_;
        let includes_ = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![includes(&Text::lit("decl"), members), Text::lit("#include \"elem.decl.hpp\""), includes(&Text::lit("decl"), declared_), includes(&Text::lit("types"), complete)]), &(|t: &Text| t != &Text::lit(""))), &Text::lit("\n"));
        let p_ = p_.clone();
        let title = title.clone();
        call_then(start_order_values(p_.values.clone(), fold(&p_.values, &Map::new(), &(|acc: &Map<Text, bool>, v_: &crate::emit::cpp::items::ValueDecl| insert(acc, &v_.path_, &false))), Array::new()), move |order_values_16098: Array<Text>| {
            let values_ = crate::syntax::lexer::chars::join(&order_values_16098, &Text::lit("\n\n"));
            prism_rtl::Turn::Finished(crate::emit::cpp::templates::cpp_types_header(&title, &includes_, &values_, &crate::syntax::lexer::chars::join(&p_.cases, &Text::lit("\n\n"))))
        })
    }
}

/// `Start TypesHeader, x`: what the function value is when passed to `@Run`.
pub fn start_types_header(title: Text, members: Array<Text>, declared_: Array<Text>, complete: Array<Text>, p_: crate::emit::cpp::items::Parts) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TypesHeader { title, members, declared_, complete, p_ })
}

/// ```prism
/// Includes: fn Text, [Text] -> Text
/// ```
pub fn includes(layer: &Text, ms: &Array<Text>) -> Text {
    crate::syntax::lexer::chars::join(&each(ms, &(|m: &Text| Text::from(format!("#include <{}/{}.hpp>", &mod_dir(m), &(if layer == &Text::lit("") { Text::lit("module") } else { layer.clone() }))))), &Text::lit("\n"))
}

/// ```prism
/// Chunks: fn [Text] -> [ [Text] ]
/// ```
pub fn chunks(defs: &Array<Text>) -> Array<Array<Text>> {
    let (done, current, size_) = fold(defs, &(Array::new(), Array::new(), Nat::from(0u32)), &(|(acc, cur, n): &(Array<Array<Text>>, Array<Text>, Nat), d: &Text| if (n > &chunk_size()) && (&len(cur) > &Nat::from(0u32)) {
        (push(acc, cur), Array::from(vec![d.clone()]), len_text(d))
    } else {
        (acc.clone(), push(cur, d), n + &len_text(d))
    }));
    if (&len(&current) == &Nat::from(0u32)) && (&len(&done) > &Nat::from(0u32)) {
        done.clone()
    } else {
        push(&done, &current)
    }
}

/// ```prism
/// let chunkSize
/// ```
pub fn chunk_size() -> Nat {
    Nat::from(250000u32)
}

/// ```prism
/// ModuleFiles: unbounded fn ModDef, Parts -> (([((Text, Text))], [Piece]))
/// ```
pub fn module_files(m: &crate::lower::model::ModDef, p_: &crate::emit::cpp::items::Parts) -> (Array<(Text, Text)>, Array<Piece>) {
    let title = if &m.prism == &Text::lit("") {
        Text::lit("The root module")
    } else {
        Text::from(format!("The module `{}`", &m.prism))
    };
    let needed = append(&m.complete, &m.declared);
    let decl = crate::emit::cpp::templates::cpp_decl_header(&title, &Text::lit(""), &crate::syntax::lexer::chars::join(&p_.forward, &Text::lit("\n\n")), &crate::syntax::lexer::chars::join(&p_.handles, &Text::lit("\n\n")));
    let types = if &len(&m.types_with) > &Nat::from(1u32) {
        crate::emit::cpp::templates::cpp_types_in_group(&title, &group_name(&m.types_with))
    } else {
        types_header(&title, &Array::from(vec![m.name.clone()]), &m.declared, &m.complete, p_)
    };
    let head_includes = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![Text::from(format!("{}\n#include \"elem.types.hpp\"", &includes(&Text::lit("types"), &Array::from(vec![m.name.clone()])))), includes(&Text::lit("types"), &needed)]), &(|t: &Text| t != &Text::lit(""))), &Text::lit("\n"));
    let head = crate::emit::cpp::templates::cpp_mod_header(&title, &head_includes, &crate::syntax::lexer::chars::join(&p_.protos, &Text::lit("\n")), &crate::syntax::lexer::chars::join(&p_.outer, &Text::lit("\n\n")), &crate::syntax::lexer::chars::join(&p_.classes, &Text::lit("\n\n")));
    let with_mine = append(&Array::from(vec![m.name.clone()]), &needed);
    let generic = if &len(&p_.generic) == &Nat::from(0u32) {
        Array::new()
    } else {
        Array::from(vec![(Text::from(format!("src/{}/generic.hpp", &mod_dir(&m.name))), crate::emit::cpp::templates::cpp_generic_header(&title, &includes(&Text::lit(""), &with_mine), &crate::syntax::lexer::chars::join(&p_.generic, &Text::lit("\n\n"))))])
    };
    let chunks_ = if &len(&p_.defs) == &Nat::from(0u32) { Array::new() } else { chunks(&p_.defs) };
    let pieces = each(&chunks_, &(|c: &Array<Text>| Piece { title: title.clone(), prism: m.prism.clone(), path_: m.path_.clone(), ns: m.name.clone(), needs: with_mine.clone(), defs: crate::syntax::lexer::chars::join(c, &Text::lit("\n\n")) }));
    let dir = mod_dir(&m.name);
    (append(&Array::from(vec![(Text::from(format!("src/{}/decl.hpp", &dir)), decl.clone()), (Text::from(format!("src/{}/types.hpp", &dir)), types.clone()), (Text::from(format!("src/{}/module.hpp", &dir)), head.clone())]), &generic), pieces.clone())
}

/// The step machine of `ModuleFiles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModuleFiles: unbounded fn ModDef, Parts -> (([((Text, Text))], [Piece]))
/// ```
pub struct ModuleFiles {
    pub m: crate::lower::model::ModDef,
    pub p_: crate::emit::cpp::items::Parts,
}

impl prism_rtl::Job<(Array<(Text, Text)>, Array<Piece>)> for ModuleFiles {
    fn cycle(&self) -> prism_rtl::Turn<(Array<(Text, Text)>, Array<Piece>)> {
        let m = &self.m;
        let p_ = &self.p_;
        let title = if &m.prism == &Text::lit("") {
            Text::lit("The root module")
        } else {
            Text::from(format!("The module `{}`", &m.prism))
        };
        let needed = append(&m.complete, &m.declared);
        let decl = crate::emit::cpp::templates::cpp_decl_header(&title, &Text::lit(""), &crate::syntax::lexer::chars::join(&p_.forward, &Text::lit("\n\n")), &crate::syntax::lexer::chars::join(&p_.handles, &Text::lit("\n\n")));
        let types = if &len(&m.types_with) > &Nat::from(1u32) {
            crate::emit::cpp::templates::cpp_types_in_group(&title, &group_name(&m.types_with))
        } else {
            types_header(&title, &Array::from(vec![m.name.clone()]), &m.declared, &m.complete, p_)
        };
        let head_includes = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![Text::from(format!("{}\n#include \"elem.types.hpp\"", &includes(&Text::lit("types"), &Array::from(vec![m.name.clone()])))), includes(&Text::lit("types"), &needed)]), &(|t: &Text| t != &Text::lit(""))), &Text::lit("\n"));
        let head = crate::emit::cpp::templates::cpp_mod_header(&title, &head_includes, &crate::syntax::lexer::chars::join(&p_.protos, &Text::lit("\n")), &crate::syntax::lexer::chars::join(&p_.outer, &Text::lit("\n\n")), &crate::syntax::lexer::chars::join(&p_.classes, &Text::lit("\n\n")));
        let with_mine = append(&Array::from(vec![m.name.clone()]), &needed);
        let generic = if &len(&p_.generic) == &Nat::from(0u32) {
            Array::new()
        } else {
            Array::from(vec![(Text::from(format!("src/{}/generic.hpp", &mod_dir(&m.name))), crate::emit::cpp::templates::cpp_generic_header(&title, &includes(&Text::lit(""), &with_mine), &crate::syntax::lexer::chars::join(&p_.generic, &Text::lit("\n\n"))))])
        };
        let chunks_ = if &len(&p_.defs) == &Nat::from(0u32) { Array::new() } else { chunks(&p_.defs) };
        let pieces = each(&chunks_, &(|c: &Array<Text>| Piece { title: title.clone(), prism: m.prism.clone(), path_: m.path_.clone(), ns: m.name.clone(), needs: with_mine.clone(), defs: crate::syntax::lexer::chars::join(c, &Text::lit("\n\n")) }));
        let dir = mod_dir(&m.name);
        prism_rtl::Turn::Finished((append(&Array::from(vec![(Text::from(format!("src/{}/decl.hpp", &dir)), decl.clone()), (Text::from(format!("src/{}/types.hpp", &dir)), types.clone()), (Text::from(format!("src/{}/module.hpp", &dir)), head.clone())]), &generic), pieces.clone()))
    }
}

/// `Start ModuleFiles, x`: what the function value is when passed to `@Run`.
pub fn start_module_files(m: crate::lower::model::ModDef, p_: crate::emit::cpp::items::Parts) -> Rc<dyn prism_rtl::Job<(Array<(Text, Text)>, Array<Piece>)>> {
    Rc::new(ModuleFiles { m, p_ })
}

/// ```prism
/// Units: fn [Piece] -> [ [Piece] ]
/// ```
pub fn units(pieces: &Array<Piece>) -> Array<Array<Piece>> {
    let (done, current, size_) = fold(pieces, &(Array::new(), Array::new(), Nat::from(0u32)), &(|(acc, cur, n): &(Array<Array<Piece>>, Array<Piece>, Nat), pc: &Piece| if (&len(cur) > &Nat::from(0u32)) && (&(n + &len_text(&pc.defs)) > &unit_size()) {
        (push(acc, cur), Array::from(vec![pc.clone()]), len_text(&pc.defs))
    } else {
        (acc.clone(), push(cur, pc), n + &len_text(&pc.defs))
    }));
    if &len(&current) == &Nat::from(0u32) { done.clone() } else { push(&done, &current) }
}

/// ```prism
/// let unitSize
/// ```
pub fn unit_size() -> Nat {
    Nat::from(125000u32)
}

/// ```prism
/// UnitFile: fn Nat, [Piece], [Text] -> ((Text, Text))
/// ```
pub fn unit_file(k: &Nat, pieces: &Array<Piece>, generics: &Array<Text>) -> (Text, Text) {
    let needs = fold(pieces, &Array::new(), &(|acc: &Array<Text>, pc: &Piece| fold(&pc.needs, acc, &(|a: &Array<Text>, n: &Text| if among(a, n) { a.clone() } else { push(a, n) }))));
    let includes_ = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![includes(&Text::lit(""), &needs), includes(&Text::lit("generic"), &filter(&needs, &(|n: &Text| among(generics, n))))]), &(|t: &Text| t != &Text::lit(""))), &Text::lit("\n"));
    let names = fold(pieces, &Array::new(), &(|acc: &Array<Text>, pc: &Piece| if among(acc, &pc.prism) { acc.clone() } else { push(acc, &pc.prism) }));
    let title = if &len(&names) == &Nat::from(1u32) {
        or(&index(pieces, &Nat::from(0u32)), &dummy_piece()).title.clone()
    } else {
        Text::from(format!("The modules {}", &crate::syntax::lexer::chars::join(&each(&names, &(|n: &Text| if n == &Text::lit("") {
            Text::lit("the root")
        } else {
            Text::from(format!("`{}`", n))
        })), &Text::lit(", "))))
    };
    let parts = crate::syntax::lexer::chars::join(&each(pieces, &(|pc: &Piece| crate::emit::cpp::templates::cpp_unit_part(&pc.title, &pc.path_, &pc.ns, &pc.defs))), &Text::lit("\n\n"));
    (Text::from(format!("src/unit_{}.cpp", &(k + &Nat::from(1u32)))), crate::emit::cpp::templates::cpp_unit(&title, &includes_, &parts))
}

/// ```prism
/// let dummyPiece
/// ```
pub fn dummy_piece() -> Piece {
    Piece { title: Text::lit(""), prism: Text::lit(""), path_: Text::lit(""), ns: Text::lit(""), needs: Array::new(), defs: Text::lit("") }
}

/// ```prism
/// AllProgramsCpp: fn Model -> [ProgDef]
/// ```
pub fn all_programs_cpp(model: &crate::lower::model::Model) -> Array<crate::lower::model::ProgDef> {
    match &model.root {
        Some(r) => if fold(&model.programs, &false, &(|f: &bool, p_: &crate::lower::model::ProgDef| *f || (&p_.name == &r.name))) {
            model.programs.clone()
        } else {
            push(&model.programs, r)
        },
        None => model.programs.clone(),
    }
}

/// ```prism
/// OrderValues: unbounded fn [ValueDecl], (Text ==> Bool), [Text] -> [Text]
/// ```
pub fn order_values(left: &Array<crate::emit::cpp::items::ValueDecl>, done: &Map<Text, bool>, acc: &Array<Text>) -> Array<Text> {
    let ready = filter(left, &(|v_: &crate::emit::cpp::items::ValueDecl| fold(&v_.deps, &true, &(|ok_: &bool, d: &Text| *ok_ && ((d == &v_.path_) || declared(done, d))))));
    if &len(left) == &Nat::from(0u32) {
        acc.clone()
    } else {
        if &len(&ready) == &Nat::from(0u32) {
            append(acc, &each(left, &(|v_: &crate::emit::cpp::items::ValueDecl| v_.text.clone())))
        } else {
            {
                let later_ = filter(left, &(|v_: &crate::emit::cpp::items::ValueDecl| !fold(&v_.deps, &true, &(|ok_: &bool, d: &Text| *ok_ && ((d == &v_.path_) || declared(done, d))))));
                let done2 = fold(&ready, done, &(|m: &Map<Text, bool>, v_: &crate::emit::cpp::items::ValueDecl| insert(m, &v_.path_, &true)));
                order_values(&later_, &done2, &append(acc, &each(&ready, &(|v_: &crate::emit::cpp::items::ValueDecl| v_.text.clone()))))
            }
        }
    }
}

/// The step machine of `OrderValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OrderValues: unbounded fn [ValueDecl], (Text ==> Bool), [Text] -> [Text]
/// ```
pub struct OrderValues {
    pub left: Array<crate::emit::cpp::items::ValueDecl>,
    pub done: Map<Text, bool>,
    pub acc: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for OrderValues {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let left = &self.left;
        let done = &self.done;
        let acc = &self.acc;
        let ready = filter(left, &(|v_: &crate::emit::cpp::items::ValueDecl| fold(&v_.deps, &true, &(|ok_: &bool, d: &Text| *ok_ && ((d == &v_.path_) || declared(done, d))))));
        if &len(left) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished(acc.clone())
        } else {
            if &len(&ready) == &Nat::from(0u32) {
                prism_rtl::Turn::Finished(append(acc, &each(left, &(|v_: &crate::emit::cpp::items::ValueDecl| v_.text.clone()))))
            } else {
                {
                    let later_ = filter(left, &(|v_: &crate::emit::cpp::items::ValueDecl| !fold(&v_.deps, &true, &(|ok_: &bool, d: &Text| *ok_ && ((d == &v_.path_) || declared(done, d))))));
                    let done2 = fold(&ready, done, &(|m: &Map<Text, bool>, v_: &crate::emit::cpp::items::ValueDecl| insert(m, &v_.path_, &true)));
                    prism_rtl::Turn::More(Rc::new(OrderValues { left: later_.clone(), done: done2.clone(), acc: append(acc, &each(&ready, &(|v_: &crate::emit::cpp::items::ValueDecl| v_.text.clone()))) }))
                }
            }
        }
    }
}

/// `Start OrderValues, x`: what the function value is when passed to `@Run`.
pub fn start_order_values(left: Array<crate::emit::cpp::items::ValueDecl>, done: Map<Text, bool>, acc: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(OrderValues { left, done, acc })
}

/// ```prism
/// Declared: fn (Text ==> Bool), Text -> Bool
/// ```
pub fn declared(done: &Map<Text, bool>, d: &Text) -> bool {
    match get(done, d) {
        Some(b) => b,
        None => true,
    }
}
