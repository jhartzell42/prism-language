//! The module `Emit.Cpp.Program`, from `target/bootstrap/src/prismc/emit/cpp/program.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Piece`:
///
/// ```prism
/// type Piece = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Piece {
    pub title_p: Text,
    pub prism_p: Text,
    pub path_p: Text,
    pub ns_p: Text,
    pub needs_p: Array<Text>,
    pub defs_p: Text,
}

impl Show for Piece {
    fn show(&self, p: &mut Printer) {
        p.record("Piece", &[("title", &self.title_p), ("prism", &self.prism_p), ("path", &self.path_p), ("ns", &self.ns_p), ("needs", &self.needs_p), ("defs", &self.defs_p)]);
    }
}

impl ToPod for Piece {
    fn to_pod(&self) -> Pod {
        Pod::record("Piece", vec![("title", self.title_p.to_pod()), ("prism", self.prism_p.to_pod()), ("path", self.path_p.to_pod()), ("ns", self.ns_p.to_pod()), ("needs", self.needs_p.to_pod()), ("defs", self.defs_p.to_pod())])
    }
}

impl FromPod for Piece {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Piece { title_p: FromPod::from_pod(field(p, "title")?)?, prism_p: FromPod::from_pod(field(p, "prism")?)?, path_p: FromPod::from_pod(field(p, "path")?)?, ns_p: FromPod::from_pod(field(p, "ns")?)?, needs_p: FromPod::from_pod(field(p, "needs")?)?, defs_p: FromPod::from_pod(field(p, "defs")?)? })
    }
}

/// ```prism
/// NodeParts: unbounded fn Cp, NodeDef -> Parts
/// ```
pub fn node_parts_f(cp_p0: &crate::emit::cpp::Cp, n_p1: &crate::lower::model::NodeDef) -> crate::emit::cpp::items::Parts {
    let ncp_p2 = crate::emit::cpp::with_fields_f(cp_p0, &crate::prelude::each(&n_p1.fields_p, &(|(f_pu, t_pv, _): &(Text, crate::lower::model::OutTy, Text)| (f_pu.clone(), t_pv.clone()))));
    let base_p3 = if (&n_p1.row_kind_p == &crate::lower::model::RowKind::NotARow) && (&crate::prelude::len(&n_p1.hosted_p) == &Nat::from(0u32)) {
        Text::lit("Node")
    } else {
        Text::lit("Row")
    };
    let fields_p4 = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(n_p1.fields_p.clone(), {
        let cp_p0x = cp_p0.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy, Text)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (f_p10, t_p11, doc_p12) = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), t_p11.clone()), move |cpp_type_f_1357: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{} {};", &crate::emit::cpp::items::cpp_doc_f(&doc_p12), &cpp_type_f_1357, &crate::emit::cpp::field_id_f(&f_p10)))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let consts_p5 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&n_p1.consts_p, &(|(c_p13, h_p14, doc_p15): &(Text, Nat, Text)| Text::from(format!("{}static constexpr std::uint32_t {} = {};", &crate::emit::cpp::items::cpp_doc_f(&Text::from(format!("The {}.", doc_p15))), c_p13, h_p14)))), &Text::lit("\n"));
    let ctor_params_p6 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&Array::from(vec![Text::lit("Path path")]), &crate::prelude::run_to_end(crate::prelude::each_job(n_p1.fields_p.clone(), {
        let cp_p0x = cp_p0.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy, Text)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (f_p16, t_p17, _) = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), t_p17.clone()), move |cpp_type_f_1609: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_f_1609, &crate::emit::cpp::field_id_f(&f_p16)))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
    }))), &Text::lit(", "));
    let ctor_inits_p7 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&Array::from(vec![Text::lit("path(std::move(path))")]), &crate::prelude::each(&n_p1.fields_p, &(|(f_p18, _, _): &(Text, crate::lower::model::OutTy, Text)| Text::from(format!("{}(std::move({}))", &crate::emit::cpp::field_id_f(f_p18), &crate::emit::cpp::field_id_f(f_p18)))))), &Text::lit(", "));
    let params_p8 = crate::prelude::concat(&crate::prelude::run_to_end(crate::prelude::each_job(n_p1.params_p.clone(), {
        let cp_p0x = cp_p0.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (p_p19, t_p1a) = p0;
                crate::prelude::call_then(crate::emit::cpp::expr::start_param_type_f(cp_p0xy.clone(), t_p1a.clone()), move |param_type_f_1848: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}, ", &param_type_f_1848, &p_p19))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let ret_p9 = if n_p1.fallible_p {
        Text::from(format!("Result<prism_rtl::Rc<{}>>", &n_p1.name_p))
    } else {
        Text::from(format!("prism_rtl::Rc<{}>", &n_p1.name_p))
    };
    let make_decl_pa = Text::from(format!("static {} make(Path path, {}Cx& cx);", &ret_p9, &params_p8));
    let method_decls_pb = crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::append(&n_p1.methods_p, &n_p1.hosted_p), {
        let ncp_p2x = ncp_p2.clone();
        Rc::new(move |p0: crate::lower::model::MethDef| {
            let ncp_p2xy = ncp_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_p1b = p0;
                crate::prelude::call_then(start_method_sig_f(ncp_p2xy.clone(), m_p1b.clone(), Text::lit("")), move |method_sig_f_2099: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &method_sig_f_2099))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let builder_decls_pc = crate::prelude::append(&crate::prelude::each(&n_p1.builders_p, &(|b_p1c: &crate::lower::model::ForDef| Text::from(format!("Done {}_build(Cx& cx);", &b_p1c.name_p)))), &crate::prelude::each(&n_p1.gens_p, &(|g_p1d: &crate::lower::model::GenDef| Text::from(format!("Done {}_build(Cx& cx);", &g_p1d.name_p)))));
    let hook_decls_pd = crate::prelude::each(&n_p1.hooks_p, &(|(h_p1e, _): &(Text, Array<crate::lower::model::Do>)| Text::from(format!("{} override;", &hook_sig_f(h_p1e, &Text::lit(""))))));
    let answer_decl_pe = if &crate::prelude::len(&n_p1.answers_p) == &Nat::from(0u32) {
        Array::new()
    } else {
        Array::from(vec![Text::lit("Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;")])
    };
    let row_decl_pf = if &n_p1.row_kind_p == &crate::lower::model::RowKind::NotARow {
        Array::new()
    } else {
        Array::from(vec![Text::lit("void leave_row(Cx& cx) override;")])
    };
    let decls_pg = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&Array::from(vec![make_decl_pa.clone()]), &method_decls_pb), &builder_decls_pc), &hook_decls_pd), &answer_decl_pe), &row_decl_pf), &Text::lit("\n"));
    let doc_ph = crate::emit::cpp::items::cpp_source_doc_f(&Text::from(format!("`{}`: a node of its own (claude/backend.md, \"A widget block\").", &n_p1.prism_p)), &n_p1.doc_p);
    let decl_pi = crate::emit::cpp::templates::items::node_class_f(&doc_ph, &n_p1.name_p, &base_p3, &fields_p4, &consts_p5, &Text::from(format!("{}({}) : {} {{}}", &n_p1.name_p, &ctor_params_p6, &ctor_inits_p7)), &decls_pg);
    let by_field_pj = crate::prelude::each(&n_p1.fields_p, &(|(f_p1f, _, _): &(Text, crate::lower::model::OutTy, Text)| crate::prelude::or(&crate::prelude::fold(&n_p1.inits_p, &None, &(|found_o1g: &Option<crate::lower::model::Ex>, (g_p1h, v_p1i): &(Text, crate::lower::model::Ex)| if g_p1h == f_p1f { Some(v_p1i.clone()) } else { found_o1g.clone() })), &crate::lower::model::Ex::XVar(f_p1f.clone()))));
    let (lets_text_p1j, lcp_p1k) = crate::emit::cpp::stmts::cpp_statements_cp_f(&ncp_p2, &n_p1.lets_p);
    let args_pk = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&Array::from(vec![Text::lit("path")]), &crate::prelude::run_to_end(crate::prelude::each_job(by_field_pj.clone(), {
        let lcp_p1kx = lcp_p1k.clone();
        Rc::new(move |p0: crate::lower::model::Ex| {
            let lcp_p1kxy = lcp_p1kx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let v_p1l = p0;
                prism_rtl::Turn::More(Rc::new(crate::emit::cpp::expr::CppExpr { cp_p0: lcp_p1kxy.clone(), x_p1: v_p1l.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
    }))), &Text::lit(", "));
    let tail_pl = if n_p1.fallible_p { Text::lit("return node;") } else { Text::lit("return node;") };
    let make_pm = crate::emit::cpp::templates::items::node_make_f(&n_p1.name_p, &Text::from(format!("{} {}::make(Path path, {}Cx& cx)", &ret_p9, &n_p1.name_p, &params_p8)), &lets_text_p1j, &args_pk, &crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&Array::from(vec![crate::emit::cpp::stmts::cpp_statements_f(&crate::emit::cpp::stmts::pointing_f(&lcp_p1k, &Text::lit("node")), &n_p1.build_p), tail_pl.clone()]), &(|s_p1m: &Text| s_p1m != &Text::lit(""))), &Text::lit("\n")));
    let methods_pn = crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::append(&n_p1.methods_p, &n_p1.hosted_p), {
        let ncp_p2x = ncp_p2.clone();
        let n_p1x = n_p1.clone();
        Rc::new(move |p0: crate::lower::model::MethDef| {
            let ncp_p2xy = ncp_p2x.clone();
            let n_p1xy = n_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_p1n = p0;
                prism_rtl::Turn::More(Rc::new(MethodDef { cp_p0: ncp_p2xy.clone(), owner_p1: n_p1xy.name_p.clone(), m_p2: m_p1n.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let builders_po = crate::prelude::append(&crate::prelude::run_to_end(crate::prelude::each_job(n_p1.builders_p.clone(), {
        let ncp_p2x = ncp_p2.clone();
        let n_p1x = n_p1.clone();
        Rc::new(move |p0: crate::lower::model::ForDef| {
            let ncp_p2xy = ncp_p2x.clone();
            let n_p1xy = n_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let b_p1o = p0;
                prism_rtl::Turn::More(Rc::new(ForBuildCpp { cp_p0: ncp_p2xy.clone(), owner_p1: n_p1xy.name_p.clone(), b_p2: b_p1o.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::ForDef) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &crate::prelude::run_to_end(crate::prelude::each_job(n_p1.gens_p.clone(), {
        let ncp_p2x = ncp_p2.clone();
        let n_p1x = n_p1.clone();
        Rc::new(move |p0: crate::lower::model::GenDef| {
            let ncp_p2xy = ncp_p2x.clone();
            let n_p1xy = n_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let g_p1p = p0;
                prism_rtl::Turn::More(Rc::new(GenBuildCpp { cp_p0: ncp_p2xy.clone(), owner_p1: n_p1xy.name_p.clone(), gd_p2: g_p1p.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::GenDef) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let hooks_pp = crate::prelude::run_to_end(crate::prelude::each_job(n_p1.hooks_p.clone(), {
        let n_p1x = n_p1.clone();
        let ncp_p2x = ncp_p2.clone();
        Rc::new(move |p0: (Text, Array<crate::lower::model::Do>)| {
            let n_p1xy = n_p1x.clone();
            let ncp_p2xy = ncp_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (h_p1q, body_p1r) = p0;
                crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_statements_f(ncp_p2xy.clone(), body_p1r.clone()), move |cpp_statements_f_3838: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &hook_sig_f(&h_p1q, &Text::from(format!("{}::", &n_p1xy.name_p))), &Text::from(format!("{}\nreturn {{}};", &cpp_statements_f_3838)))))
            }))
        }) as Rc<dyn Fn((Text, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let answer_pq = if &crate::prelude::len(&n_p1.answers_p) == &Nat::from(0u32) {
        Array::new()
    } else {
        Array::from(vec![answer_def_cpp_f(&ncp_p2, n_p1)])
    };
    let leaving_pr = if &n_p1.row_kind_p == &crate::lower::model::RowKind::NotARow {
        Array::new()
    } else {
        Array::from(vec![row_leaving_f(&ncp_p2, n_p1)])
    };
    let defs_ps = crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&Array::from(vec![make_pm.clone()]), &methods_pn), &builders_po), &hooks_pp), &answer_pq), &leaving_pr);
    let own_pt = crate::emit::cpp::items::Parts { forward_p: Array::from(vec![Text::from(format!("class {};", &n_p1.name_p))]), values_p: Array::new(), protos_p: Array::new(), classes_p: Array::from(vec![decl_pi.clone()]), outer_p: Array::new(), generic_p: Array::new(), defs_p: defs_ps.clone() };
    own_pt.clone()
}

/// The step machine of `NodeParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NodeParts: unbounded fn Cp, NodeDef -> Parts
/// ```
pub struct NodeParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub n_p1: crate::lower::model::NodeDef,
}

impl prism_rtl::Job<crate::emit::cpp::items::Parts> for NodeParts {
    fn cycle(&self) -> prism_rtl::Turn<crate::emit::cpp::items::Parts> {
        let cp_p0 = &self.cp_p0;
        let n_p1 = &self.n_p1;
        let ncp_p2 = crate::emit::cpp::with_fields_f(cp_p0, &crate::prelude::each(&n_p1.fields_p, &(|(f_pu, t_pv, _): &(Text, crate::lower::model::OutTy, Text)| (f_pu.clone(), t_pv.clone()))));
        let base_p3 = if (&n_p1.row_kind_p == &crate::lower::model::RowKind::NotARow) && (&crate::prelude::len(&n_p1.hosted_p) == &Nat::from(0u32)) {
            Text::lit("Node")
        } else {
            Text::lit("Row")
        };
        let cp_p0x = cp_p0.clone();
        let n_p1x = n_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(n_p1x.fields_p.clone(), {
            let cp_p0xx = cp_p0x.clone();
            Rc::new(move |p0: (Text, crate::lower::model::OutTy, Text)| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (f_p10, t_p11, doc_p12) = p0;
                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), t_p11.clone()), move |cpp_type_f_1357: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{} {};", &crate::emit::cpp::items::cpp_doc_f(&doc_p12), &cpp_type_f_1357, &crate::emit::cpp::field_id_f(&f_p10)))))
                }))
            }) as Rc<dyn Fn((Text, crate::lower::model::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_1311: Array<Text>| {
            let fields_p4 = crate::syntax::lexer::chars::join_f(&each_1311, &Text::lit("\n"));
            let consts_p5 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&n_p1x.consts_p, &(|(c_p13, h_p14, doc_p15): &(Text, Nat, Text)| Text::from(format!("{}static constexpr std::uint32_t {} = {};", &crate::emit::cpp::items::cpp_doc_f(&Text::from(format!("The {}.", doc_p15))), c_p13, h_p14)))), &Text::lit("\n"));
            crate::prelude::call_value(crate::prelude::each_job(n_p1x.fields_p.clone(), {
                let cp_p0xx = cp_p0x.clone();
                Rc::new(move |p0: (Text, crate::lower::model::OutTy, Text)| {
                    let cp_p0xxy = cp_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (f_p16, t_p17, _) = p0;
                        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), t_p17.clone()), move |cpp_type_f_1609: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_f_1609, &crate::emit::cpp::field_id_f(&f_p16)))))
                    }))
                }) as Rc<dyn Fn((Text, crate::lower::model::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_1572: Array<Text>| {
                let ctor_params_p6 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&Array::from(vec![Text::lit("Path path")]), &each_1572), &Text::lit(", "));
                let ctor_inits_p7 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&Array::from(vec![Text::lit("path(std::move(path))")]), &crate::prelude::each(&n_p1x.fields_p, &(|(f_p18, _, _): &(Text, crate::lower::model::OutTy, Text)| Text::from(format!("{}(std::move({}))", &crate::emit::cpp::field_id_f(f_p18), &crate::emit::cpp::field_id_f(f_p18)))))), &Text::lit(", "));
                crate::prelude::call_value(crate::prelude::each_job(n_p1x.params_p.clone(), {
                    let cp_p0xx = cp_p0x.clone();
                    Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                        let cp_p0xxy = cp_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (p_p19, t_p1a) = p0;
                            crate::prelude::call_then(crate::emit::cpp::expr::start_param_type_f(cp_p0xxy.clone(), t_p1a.clone()), move |param_type_f_1848: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}, ", &param_type_f_1848, &p_p19))))
                        }))
                    }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_1819: Array<Text>| {
                    let params_p8 = crate::prelude::concat(&each_1819);
                    let ret_p9 = if n_p1x.fallible_p {
                        Text::from(format!("Result<prism_rtl::Rc<{}>>", &n_p1x.name_p))
                    } else {
                        Text::from(format!("prism_rtl::Rc<{}>", &n_p1x.name_p))
                    };
                    let make_decl_pa = Text::from(format!("static {} make(Path path, {}Cx& cx);", &ret_p9, &params_p8));
                    crate::prelude::call_value(crate::prelude::each_job(crate::prelude::append(&n_p1x.methods_p, &n_p1x.hosted_p), {
                        let ncp_p2x = ncp_p2.clone();
                        Rc::new(move |p0: crate::lower::model::MethDef| {
                            let ncp_p2xy = ncp_p2x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let m_p1b = p0;
                                crate::prelude::call_then(start_method_sig_f(ncp_p2xy.clone(), m_p1b.clone(), Text::lit("")), move |method_sig_f_2099: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &method_sig_f_2099))))
                            }))
                        }) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>
                    }), move |each_2057: Array<Text>| {
                        let method_decls_pb = each_2057;
                        let builder_decls_pc = crate::prelude::append(&crate::prelude::each(&n_p1x.builders_p, &(|b_p1c: &crate::lower::model::ForDef| Text::from(format!("Done {}_build(Cx& cx);", &b_p1c.name_p)))), &crate::prelude::each(&n_p1x.gens_p, &(|g_p1d: &crate::lower::model::GenDef| Text::from(format!("Done {}_build(Cx& cx);", &g_p1d.name_p)))));
                        let hook_decls_pd = crate::prelude::each(&n_p1x.hooks_p, &(|(h_p1e, _): &(Text, Array<crate::lower::model::Do>)| Text::from(format!("{} override;", &hook_sig_f(h_p1e, &Text::lit(""))))));
                        let answer_decl_pe = if &crate::prelude::len(&n_p1x.answers_p) == &Nat::from(0u32) {
                            Array::new()
                        } else {
                            Array::from(vec![Text::lit("Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;")])
                        };
                        let row_decl_pf = if &n_p1x.row_kind_p == &crate::lower::model::RowKind::NotARow {
                            Array::new()
                        } else {
                            Array::from(vec![Text::lit("void leave_row(Cx& cx) override;")])
                        };
                        let decls_pg = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&Array::from(vec![make_decl_pa.clone()]), &method_decls_pb), &builder_decls_pc), &hook_decls_pd), &answer_decl_pe), &row_decl_pf), &Text::lit("\n"));
                        let doc_ph = crate::emit::cpp::items::cpp_source_doc_f(&Text::from(format!("`{}`: a node of its own (claude/backend.md, \"A widget block\").", &n_p1x.prism_p)), &n_p1x.doc_p);
                        let decl_pi = crate::emit::cpp::templates::items::node_class_f(&doc_ph, &n_p1x.name_p, &base_p3, &fields_p4, &consts_p5, &Text::from(format!("{}({}) : {} {{}}", &n_p1x.name_p, &ctor_params_p6, &ctor_inits_p7)), &decls_pg);
                        let by_field_pj = crate::prelude::each(&n_p1x.fields_p, &(|(f_p1f, _, _): &(Text, crate::lower::model::OutTy, Text)| crate::prelude::or(&crate::prelude::fold(&n_p1x.inits_p, &None, &(|found_o1g: &Option<crate::lower::model::Ex>, (g_p1h, v_p1i): &(Text, crate::lower::model::Ex)| if g_p1h == f_p1f { Some(v_p1i.clone()) } else { found_o1g.clone() })), &crate::lower::model::Ex::XVar(f_p1f.clone()))));
                        crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_statements_cp_f(ncp_p2.clone(), n_p1x.lets_p.clone()), move |cpp_statements_cp_f_3170: (Text, crate::emit::cpp::Cp)| {
                            let (lets_text_p1j, lcp_p1k) = cpp_statements_cp_f_3170;
                            crate::prelude::call_value(crate::prelude::each_job(by_field_pj.clone(), {
                                let lcp_p1kx = lcp_p1k.clone();
                                Rc::new(move |p0: crate::lower::model::Ex| {
                                    let lcp_p1kxy = lcp_p1kx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let v_p1l = p0;
                                        prism_rtl::Turn::More(Rc::new(crate::emit::cpp::expr::CppExpr { cp_p0: lcp_p1kxy.clone(), x_p1: v_p1l.clone() }))
                                    }))
                                }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
                            }), move |each_3239: Array<Text>| {
                                let args_pk = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&Array::from(vec![Text::lit("path")]), &each_3239), &Text::lit(", "));
                                let tail_pl = if n_p1x.fallible_p { Text::lit("return node;") } else { Text::lit("return node;") };
                                crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_statements_f(crate::emit::cpp::stmts::pointing_f(&lcp_p1k, &Text::lit("node")), n_p1x.build_p.clone()), move |cpp_statements_f_3463: Text| {
                                    let make_pm = crate::emit::cpp::templates::items::node_make_f(&n_p1x.name_p, &Text::from(format!("{} {}::make(Path path, {}Cx& cx)", &ret_p9, &n_p1x.name_p, &params_p8)), &lets_text_p1j, &args_pk, &crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&Array::from(vec![cpp_statements_f_3463, tail_pl.clone()]), &(|s_p1m: &Text| s_p1m != &Text::lit(""))), &Text::lit("\n")));
                                    crate::prelude::call_value(crate::prelude::each_job(crate::prelude::append(&n_p1x.methods_p, &n_p1x.hosted_p), {
                                        let ncp_p2x = ncp_p2.clone();
                                        let n_p1xx = n_p1x.clone();
                                        Rc::new(move |p0: crate::lower::model::MethDef| {
                                            let ncp_p2xy = ncp_p2x.clone();
                                            let n_p1xxy = n_p1xx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let m_p1n = p0;
                                                prism_rtl::Turn::More(Rc::new(MethodDef { cp_p0: ncp_p2xy.clone(), owner_p1: n_p1xxy.name_p.clone(), m_p2: m_p1n.clone() }))
                                            }))
                                        }) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>
                                    }), move |each_3558: Array<Text>| {
                                        let methods_pn = each_3558;
                                        crate::prelude::call_value(crate::prelude::each_job(n_p1x.builders_p.clone(), {
                                            let ncp_p2x = ncp_p2.clone();
                                            let n_p1xx = n_p1x.clone();
                                            Rc::new(move |p0: crate::lower::model::ForDef| {
                                                let ncp_p2xy = ncp_p2x.clone();
                                                let n_p1xxy = n_p1xx.clone();
                                                crate::prelude::entered(crate::prelude::once_job(move || {
                                                    let b_p1o = p0;
                                                    prism_rtl::Turn::More(Rc::new(ForBuildCpp { cp_p0: ncp_p2xy.clone(), owner_p1: n_p1xxy.name_p.clone(), b_p2: b_p1o.clone() }))
                                                }))
                                            }) as Rc<dyn Fn(crate::lower::model::ForDef) -> Rc<dyn prism_rtl::Job<Text>>>
                                        }), move |each_3650: Array<Text>| crate::prelude::call_value(crate::prelude::each_job(n_p1x.gens_p.clone(), {
                                            let ncp_p2x = ncp_p2.clone();
                                            let n_p1xx = n_p1x.clone();
                                            Rc::new(move |p0: crate::lower::model::GenDef| {
                                                let ncp_p2xy = ncp_p2x.clone();
                                                let n_p1xxy = n_p1xx.clone();
                                                crate::prelude::entered(crate::prelude::once_job(move || {
                                                    let g_p1p = p0;
                                                    prism_rtl::Turn::More(Rc::new(GenBuildCpp { cp_p0: ncp_p2xy.clone(), owner_p1: n_p1xxy.name_p.clone(), gd_p2: g_p1p.clone() }))
                                                }))
                                            }) as Rc<dyn Fn(crate::lower::model::GenDef) -> Rc<dyn prism_rtl::Job<Text>>>
                                        }), move |each_3702: Array<Text>| {
                                            let builders_po = crate::prelude::append(&each_3650, &each_3702);
                                            crate::prelude::call_value(crate::prelude::each_job(n_p1x.hooks_p.clone(), {
                                                let n_p1xx = n_p1x.clone();
                                                let ncp_p2x = ncp_p2.clone();
                                                Rc::new(move |p0: (Text, Array<crate::lower::model::Do>)| {
                                                    let n_p1xxy = n_p1xx.clone();
                                                    let ncp_p2xy = ncp_p2x.clone();
                                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                                        let (h_p1q, body_p1r) = p0;
                                                        crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_statements_f(ncp_p2xy.clone(), body_p1r.clone()), move |cpp_statements_f_3838: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &hook_sig_f(&h_p1q, &Text::from(format!("{}::", &n_p1xxy.name_p))), &Text::from(format!("{}\nreturn {{}};", &cpp_statements_f_3838)))))
                                                    }))
                                                }) as Rc<dyn Fn((Text, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>
                                            }), move |each_3764: Array<Text>| {
                                                let hooks_pp = each_3764;
                                                let answer_pq = if &crate::prelude::len(&n_p1x.answers_p) == &Nat::from(0u32) {
                                                    Array::new()
                                                } else {
                                                    Array::from(vec![answer_def_cpp_f(&ncp_p2, &n_p1x)])
                                                };
                                                let leaving_pr = if &n_p1x.row_kind_p == &crate::lower::model::RowKind::NotARow {
                                                    Array::new()
                                                } else {
                                                    Array::from(vec![row_leaving_f(&ncp_p2, &n_p1x)])
                                                };
                                                let defs_ps = crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&Array::from(vec![make_pm.clone()]), &methods_pn), &builders_po), &hooks_pp), &answer_pq), &leaving_pr);
                                                let own_pt = crate::emit::cpp::items::Parts { forward_p: Array::from(vec![Text::from(format!("class {};", &n_p1x.name_p))]), values_p: Array::new(), protos_p: Array::new(), classes_p: Array::from(vec![decl_pi.clone()]), outer_p: Array::new(), generic_p: Array::new(), defs_p: defs_ps.clone() };
                                                prism_rtl::Turn::Finished(own_pt.clone())
                                            })
                                        }))
                                    })
                                })
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start NodeParts, x`: what the function value is when passed to `@Run`.
pub fn start_node_parts_f(cp_p0: crate::emit::cpp::Cp, n_p1: crate::lower::model::NodeDef) -> Rc<dyn prism_rtl::Job<crate::emit::cpp::items::Parts>> {
    Rc::new(NodeParts { cp_p0, n_p1 })
}

/// ```prism
/// MethodSig: unbounded fn Cp, MethDef, Text -> Text
/// ```
pub fn method_sig_f(cp_p0: &crate::emit::cpp::Cp, m_p1: &crate::lower::model::MethDef, owner_p2: &Text) -> Text {
    let cx_p3 = match &m_p1.cx_p {
        crate::lower::model::CxArg::CxMut => Array::from(vec![Text::lit("Cx& cx")]),
        crate::lower::model::CxArg::CxRef => Array::from(vec![Text::lit("const Cx& cx")]),
        crate::lower::model::CxArg::CxNone => Array::new(),
    };
    let params_p4 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::run_to_end(crate::prelude::each_job(m_p1.params_p.clone(), {
        let cp_p0x = cp_p0.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (p_p6, t_p7) = p0;
                crate::prelude::call_then(crate::emit::cpp::expr::start_param_type_f(cp_p0xy.clone(), t_p7.clone()), move |param_type_f_4531: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_f_4531, &p_p6))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &cx_p3), &Text::lit(", "));
    let constness_p5 = if &m_p1.recv_p == &crate::lower::model::Recv::RecvRef {
        Text::lit(" const")
    } else {
        Text::lit("")
    };
    Text::from(format!("{} {}{}({}){}", &crate::emit::cpp::cpp_type_f(cp_p0, &m_p1.ret_p), owner_p2, &crate::emit::cpp::expr::node_method_name_f(cp_p0, &m_p1.name_p), &params_p4, &constness_p5))
}

/// The step machine of `MethodSig`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MethodSig: unbounded fn Cp, MethDef, Text -> Text
/// ```
pub struct MethodSig {
    pub cp_p0: crate::emit::cpp::Cp,
    pub m_p1: crate::lower::model::MethDef,
    pub owner_p2: Text,
}

impl prism_rtl::Job<Text> for MethodSig {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let m_p1 = &self.m_p1;
        let owner_p2 = &self.owner_p2;
        let cx_p3 = match &m_p1.cx_p {
            crate::lower::model::CxArg::CxMut => Array::from(vec![Text::lit("Cx& cx")]),
            crate::lower::model::CxArg::CxRef => Array::from(vec![Text::lit("const Cx& cx")]),
            crate::lower::model::CxArg::CxNone => Array::new(),
        };
        let cp_p0x = cp_p0.clone();
        let m_p1x = m_p1.clone();
        let owner_p2x = owner_p2.clone();
        crate::prelude::call_value(crate::prelude::each_job(m_p1x.params_p.clone(), {
            let cp_p0xx = cp_p0x.clone();
            Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (p_p6, t_p7) = p0;
                    crate::prelude::call_then(crate::emit::cpp::expr::start_param_type_f(cp_p0xxy.clone(), t_p7.clone()), move |param_type_f_4531: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_f_4531, &p_p6))))
                }))
            }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_4502: Array<Text>| {
            let params_p4 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&each_4502, &cx_p3), &Text::lit(", "));
            let constness_p5 = if &m_p1x.recv_p == &crate::lower::model::Recv::RecvRef {
                Text::lit(" const")
            } else {
                Text::lit("")
            };
            crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), m_p1x.ret_p.clone()), move |cpp_type_f_4631: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}{}({}){}", &cpp_type_f_4631, &owner_p2x, &crate::emit::cpp::expr::node_method_name_f(&cp_p0x, &m_p1x.name_p), &params_p4, &constness_p5))))
        })
    }
}

/// `Start MethodSig, x`: what the function value is when passed to `@Run`.
pub fn start_method_sig_f(cp_p0: crate::emit::cpp::Cp, m_p1: crate::lower::model::MethDef, owner_p2: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(MethodSig { cp_p0, m_p1, owner_p2 })
}

/// ```prism
/// MethodDef: unbounded fn Cp, Text, MethDef -> Text
/// ```
pub fn method_def_f(cp_p0: &crate::emit::cpp::Cp, owner_p1: &Text, m_p2: &crate::lower::model::MethDef) -> Text {
    let (st_p4, cp2_p5) = crate::emit::cpp::stmts::cpp_statements_cp_f(cp_p0, &m_p2.body_p);
    let body_p3 = if &m_p2.ret_p == &crate::lower::model::OutTy::OutUnit {
        Text::from(format!("{}\nreturn Unit{{}};", &st_p4))
    } else {
        if &crate::prelude::len(&m_p2.body_p) == &Nat::from(0u32) {
            crate::emit::cpp::stmts::cpp_body_f(cp_p0, &m_p2.tail_p)
        } else {
            Text::from(format!("{}\n{}", &st_p4, &crate::emit::cpp::stmts::cpp_body_f(&cp2_p5, &m_p2.tail_p)))
        }
    };
    crate::emit::cpp::templates::items::cpp_function_f(&crate::emit::cpp::items::cpp_doc_f(&m_p2.doc_p), &method_sig_f(cp_p0, m_p2, &Text::from(format!("{}::", owner_p1))), &body_p3)
}

/// The step machine of `MethodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MethodDef: unbounded fn Cp, Text, MethDef -> Text
/// ```
pub struct MethodDef {
    pub cp_p0: crate::emit::cpp::Cp,
    pub owner_p1: Text,
    pub m_p2: crate::lower::model::MethDef,
}

impl prism_rtl::Job<Text> for MethodDef {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let owner_p1 = &self.owner_p1;
        let m_p2 = &self.m_p2;
        let cp_p0x = cp_p0.clone();
        let m_p2x = m_p2.clone();
        let owner_p1x = owner_p1.clone();
        crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_statements_cp_f(cp_p0x.clone(), m_p2x.body_p.clone()), move |cpp_statements_cp_f_4807: (Text, crate::emit::cpp::Cp)| {
            let (st_p4, cp2_p5) = cpp_statements_cp_f_4807;
            let body_p3 = if &m_p2x.ret_p == &crate::lower::model::OutTy::OutUnit {
                Text::from(format!("{}\nreturn Unit{{}};", &st_p4))
            } else {
                if &crate::prelude::len(&m_p2x.body_p) == &Nat::from(0u32) {
                    crate::emit::cpp::stmts::cpp_body_f(&cp_p0x, &m_p2x.tail_p)
                } else {
                    Text::from(format!("{}\n{}", &st_p4, &crate::emit::cpp::stmts::cpp_body_f(&cp2_p5, &m_p2x.tail_p)))
                }
            };
            crate::prelude::call_then(start_method_sig_f(cp_p0x.clone(), m_p2x.clone(), Text::from(format!("{}::", &owner_p1x))), move |method_sig_f_5011: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function_f(&crate::emit::cpp::items::cpp_doc_f(&m_p2x.doc_p), &method_sig_f_5011, &body_p3)))
        })
    }
}

/// `Start MethodDef, x`: what the function value is when passed to `@Run`.
pub fn start_method_def_f(cp_p0: crate::emit::cpp::Cp, owner_p1: Text, m_p2: crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(MethodDef { cp_p0, owner_p1, m_p2 })
}

/// ```prism
/// HookSig: fn Text, Text -> Text
/// ```
pub fn hook_sig_f(text0: &Text, owner_p0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("push")) => Text::from(format!("Done {}push(const Pod& element, const Pod& v, Cx& cx)", owner_p0)),
        h_p1 => Text::from(format!("Done {}{}(Cx& cx)", owner_p0, h_p1)),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// AnswerDefCpp: unbounded fn Cp, NodeDef -> Text
/// ```
pub fn answer_def_cpp_f(cp_p0: &crate::emit::cpp::Cp, n_p1: &crate::lower::model::NodeDef) -> Text {
    let arms_p2 = crate::prelude::run_to_end(crate::prelude::each_job(n_p1.answers_p.clone(), {
        let cp_p0x = cp_p0.clone();
        Rc::new(move |p0: (crate::lower::model::Pa, crate::lower::model::Ex)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (pat_p4, call_p5) = p0;
                crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_conds_f(cp_p0xy.clone(), pat_p4.clone(), Text::lit("at")), move |pat_conds_f_5354: Array<Text>| {
                    let tests_p6 = pat_conds_f_5354;
                    crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_binds_f(cp_p0xy.clone(), pat_p4.clone(), Text::lit("at")), move |pat_binds_f_5397: Array<Text>| {
                        let binds_p7 = pat_binds_f_5397;
                        crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0xy.clone(), call_p5.clone()), move |cpp_expr_f_5458: Text| prism_rtl::Turn::Finished((tests_p6.clone(), crate::syntax::lexer::chars::join_f(&crate::prelude::push(&binds_p7, &Text::from(format!("{};", &cpp_expr_f_5458))), &Text::lit("\n")))))
                    })
                })
            }))
        }) as Rc<dyn Fn((crate::lower::model::Pa, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Text)>>>
    }));
    let blocks_p3 = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&arms_p2)), &(|i_p8: &Nat| {
        let (tests_p9, inner_pa) = crate::prelude::or(&crate::prelude::index(&arms_p2, i_p8), &(Array::new(), Text::lit("")));
        crate::emit::cpp::templates::items::block_f(&Text::from(format!("{} ({})", &(if i_p8 == &Nat::from(0u32) { Text::lit("if") } else { Text::lit("else if") }), &crate::emit::cpp::patterns::conds_f(&tests_p9))), &inner_pa)
    }));
    crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("Done {}::answer(std::span<const Segment> at, const Pod& v, Cx& cx)", &n_p1.name_p)), &Text::from(format!("{} else {{\n    return unexpected(Fault::answer(str(\"no answering place at \", path_of(at))));\n}}\nreturn {{}};", &crate::syntax::lexer::chars::join_f(&blocks_p3, &Text::lit(" ")))))
}

/// The step machine of `AnswerDefCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnswerDefCpp: unbounded fn Cp, NodeDef -> Text
/// ```
pub struct AnswerDefCpp {
    pub cp_p0: crate::emit::cpp::Cp,
    pub n_p1: crate::lower::model::NodeDef,
}

impl prism_rtl::Job<Text> for AnswerDefCpp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let n_p1 = &self.n_p1;
        let cp_p0x = cp_p0.clone();
        let n_p1x = n_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(n_p1x.answers_p.clone(), {
            let cp_p0xx = cp_p0x.clone();
            Rc::new(move |p0: (crate::lower::model::Pa, crate::lower::model::Ex)| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (pat_p4, call_p5) = p0;
                    crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_conds_f(cp_p0xxy.clone(), pat_p4.clone(), Text::lit("at")), move |pat_conds_f_5354: Array<Text>| {
                        let tests_p6 = pat_conds_f_5354;
                        crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_binds_f(cp_p0xxy.clone(), pat_p4.clone(), Text::lit("at")), move |pat_binds_f_5397: Array<Text>| {
                            let binds_p7 = pat_binds_f_5397;
                            crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0xxy.clone(), call_p5.clone()), move |cpp_expr_f_5458: Text| prism_rtl::Turn::Finished((tests_p6.clone(), crate::syntax::lexer::chars::join_f(&crate::prelude::push(&binds_p7, &Text::from(format!("{};", &cpp_expr_f_5458))), &Text::lit("\n")))))
                        })
                    })
                }))
            }) as Rc<dyn Fn((crate::lower::model::Pa, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Text)>>>
        }), move |each_5301: Array<(Array<Text>, Text)>| {
            let arms_p2 = each_5301;
            let blocks_p3 = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&arms_p2)), &(|i_p8: &Nat| {
                let (tests_p9, inner_pa) = crate::prelude::or(&crate::prelude::index(&arms_p2, i_p8), &(Array::new(), Text::lit("")));
                crate::emit::cpp::templates::items::block_f(&Text::from(format!("{} ({})", &(if i_p8 == &Nat::from(0u32) { Text::lit("if") } else { Text::lit("else if") }), &crate::emit::cpp::patterns::conds_f(&tests_p9))), &inner_pa)
            }));
            prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("Done {}::answer(std::span<const Segment> at, const Pod& v, Cx& cx)", &n_p1x.name_p)), &Text::from(format!("{} else {{\n    return unexpected(Fault::answer(str(\"no answering place at \", path_of(at))));\n}}\nreturn {{}};", &crate::syntax::lexer::chars::join_f(&blocks_p3, &Text::lit(" "))))))
        })
    }
}

/// `Start AnswerDefCpp, x`: what the function value is when passed to `@Run`.
pub fn start_answer_def_cpp_f(cp_p0: crate::emit::cpp::Cp, n_p1: crate::lower::model::NodeDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(AnswerDefCpp { cp_p0, n_p1 })
}

/// ```prism
/// RowLeaving: unbounded fn Cp, NodeDef -> Text
/// ```
pub fn row_leaving_f(cp_p0: &crate::emit::cpp::Cp, n_p1: &crate::lower::model::NodeDef) -> Text {
    let kept_p2 = if &n_p1.row_kind_p == &crate::lower::model::RowKind::ForRow {
        Array::from(vec![Text::lit("this->left_entry = entry(cx);")])
    } else {
        Array::new()
    };
    let unsubscribe_p3 = crate::prelude::each(&n_p1.subs_p, &(|(ev_p4, m_p5, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("if (auto p = parent.lock(); p && {}_sub) deref(p->{}_port).unsubscribe(*std::exchange({}_sub, std::nullopt));", m_p5, ev_p4, m_p5))));
    crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("void {}::leave_row(Cx& cx)", &n_p1.name_p)), &crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::push(&kept_p2, &Text::lit("remove_places(cx);")), &unsubscribe_p3), &Text::lit("\n")))
}

/// The step machine of `RowLeaving`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowLeaving: unbounded fn Cp, NodeDef -> Text
/// ```
pub struct RowLeaving {
    pub cp_p0: crate::emit::cpp::Cp,
    pub n_p1: crate::lower::model::NodeDef,
}

impl prism_rtl::Job<Text> for RowLeaving {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let n_p1 = &self.n_p1;
        let kept_p2 = if &n_p1.row_kind_p == &crate::lower::model::RowKind::ForRow {
            Array::from(vec![Text::lit("this->left_entry = entry(cx);")])
        } else {
            Array::new()
        };
        let unsubscribe_p3 = crate::prelude::each(&n_p1.subs_p, &(|(ev_p4, m_p5, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("if (auto p = parent.lock(); p && {}_sub) deref(p->{}_port).unsubscribe(*std::exchange({}_sub, std::nullopt));", m_p5, ev_p4, m_p5))));
        prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("void {}::leave_row(Cx& cx)", &n_p1.name_p)), &crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::push(&kept_p2, &Text::lit("remove_places(cx);")), &unsubscribe_p3), &Text::lit("\n"))))
    }
}

/// `Start RowLeaving, x`: what the function value is when passed to `@Run`.
pub fn start_row_leaving_f(cp_p0: crate::emit::cpp::Cp, n_p1: crate::lower::model::NodeDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RowLeaving { cp_p0, n_p1 })
}

/// ```prism
/// ForBuildCpp: unbounded fn Cp, Text, ForDef -> Text
/// ```
pub fn for_build_cpp_f(cp_p0: &crate::emit::cpp::Cp, owner_p1: &Text, b_p2: &crate::lower::model::ForDef) -> Text {
    crate::emit::cpp::templates::items::for_build_template_f(owner_p1, &b_p2.name_p, &crate::emit::cpp::expr::cpp_expr_f(cp_p0, &b_p2.at_p), &crate::emit::cpp::cpp_type_f(cp_p0, &b_p2.key_ty_p), &crate::emit::cpp::cpp_type_f(cp_p0, &b_p2.value_ty_p), &crate::emit::cpp::expr::call_path_f(&Text::from(format!("{}::build", &b_p2.row_node_p))), &b_p2.source_p, &crate::emit::cpp::expr::cpp_expr_f(cp_p0, &b_p2.parent_p), &crate::prelude::concat(&crate::prelude::run_to_end(crate::prelude::each_job(b_p2.passed_p.clone(), {
        let cp_p0x = cp_p0.clone();
        Rc::new(move |p0: crate::lower::model::Ex| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let x_p3 = p0;
                crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0xy.clone(), x_p3.clone()), move |cpp_expr_f_6762: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}", &cpp_expr_f_6762))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
    }))), &moved_call_cpp_f(&b_p2.moved_p), &from_kept_cpp_f(&b_p2.name_p, &b_p2.replaced_p), &replaced_call_cpp_f(&b_p2.replaced_p))
}

/// The step machine of `ForBuildCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ForBuildCpp: unbounded fn Cp, Text, ForDef -> Text
/// ```
pub struct ForBuildCpp {
    pub cp_p0: crate::emit::cpp::Cp,
    pub owner_p1: Text,
    pub b_p2: crate::lower::model::ForDef,
}

impl prism_rtl::Job<Text> for ForBuildCpp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let owner_p1 = &self.owner_p1;
        let b_p2 = &self.b_p2;
        let b_p2x = b_p2.clone();
        let cp_p0x = cp_p0.clone();
        let owner_p1x = owner_p1.clone();
        crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), b_p2x.at_p.clone()), move |cpp_expr_f_6595: Text| crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), b_p2x.key_ty_p.clone()), move |cpp_type_f_6615: Text| crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), b_p2x.value_ty_p.clone()), move |cpp_type_f_6638: Text| crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), b_p2x.parent_p.clone()), move |cpp_expr_f_6706: Text| crate::prelude::call_value(crate::prelude::each_job(b_p2x.passed_p.clone(), {
            let cp_p0xx = cp_p0x.clone();
            Rc::new(move |p0: crate::lower::model::Ex| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let x_p3 = p0;
                    crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0xxy.clone(), x_p3.clone()), move |cpp_expr_f_6762: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}", &cpp_expr_f_6762))))
                }))
            }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_6738: Array<Text>| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::for_build_template_f(&owner_p1x, &b_p2x.name_p, &cpp_expr_f_6595, &cpp_type_f_6615, &cpp_type_f_6638, &crate::emit::cpp::expr::call_path_f(&Text::from(format!("{}::build", &b_p2x.row_node_p))), &b_p2x.source_p, &cpp_expr_f_6706, &crate::prelude::concat(&each_6738), &moved_call_cpp_f(&b_p2x.moved_p), &from_kept_cpp_f(&b_p2x.name_p, &b_p2x.replaced_p), &replaced_call_cpp_f(&b_p2x.replaced_p))))))))
    }
}

/// `Start ForBuildCpp, x`: what the function value is when passed to `@Run`.
pub fn start_for_build_cpp_f(cp_p0: crate::emit::cpp::Cp, owner_p1: Text, b_p2: crate::lower::model::ForDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ForBuildCpp { cp_p0, owner_p1, b_p2 })
}

/// ```prism
/// FromKeptCpp: fn Text, [Text] -> Text
/// ```
pub fn from_kept_cpp_f(name_p0: &Text, replaced_p1: &Array<Text>) -> Text {
    if &crate::prelude::len(replaced_p1) == &Nat::from(0u32) {
        Text::from(format!("this->{}_from = items;", name_p0))
    } else {
        Text::from(format!("auto from = std::exchange(this->{}_from, items);", name_p0))
    }
}

/// ```prism
/// ReplacedCallCpp: fn [Text] -> Text
/// ```
pub fn replaced_call_cpp_f(replaced_p0: &Array<Text>) -> Text {
    if &crate::prelude::len(replaced_p0) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" else if (auto was = from.get(k), is = items.get(k); !was || !is || !(*was == *is)) {{\n            // the dynamic under a kept key was replaced: that row follows it from the next tick\n{}        }}", &crate::prelude::concat(&crate::prelude::each(replaced_p0, &(|m_p1: &Text| Text::from(format!("            row->{}(cx);\n", m_p1)))))))
    }
}

/// ```prism
/// MovedCallCpp: fn Text -> Text
/// ```
pub fn moved_call_cpp_f(m_p0: &Text) -> Text {
    if m_p0 == &Text::lit("") {
        Text::lit("")
    } else {
        Text::from(format!("\n    // the places of the host\'s child came or went: its document\'s outer moves\n    if (!prism_rtl::same_keys(next, old)) this->{}(cx);", m_p0))
    }
}

/// ```prism
/// GenMovedCallCpp: fn Text -> Text
/// ```
pub fn gen_moved_call_cpp_f(m_p0: &Text) -> Text {
    if m_p0 == &Text::lit("") {
        Text::lit("")
    } else {
        Text::from(format!("\n    // the places of the host\'s child came or went: its document\'s outer moves\n    this->{}(cx);", m_p0))
    }
}

/// ```prism
/// GenBuildCpp: unbounded fn Cp, Text, GenDef -> Text
/// ```
pub fn gen_build_cpp_f(cp_p0: &crate::emit::cpp::Cp, owner_p1: &Text, gd_p2: &crate::lower::model::GenDef) -> Text {
    let path_p3 = if gd_p2.transparent_p {
        Text::lit("this->path")
    } else {
        Text::from(format!("{}.child(Segment::gen(g))", &crate::emit::cpp::expr::cpp_expr_f(cp_p0, &gd_p2.at_p)))
    };
    crate::emit::cpp::templates::items::gen_build_template_f(owner_p1, &gd_p2.name_p, &crate::emit::cpp::expr::cpp_expr_f(cp_p0, &gd_p2.at_p), &path_p3, &crate::emit::cpp::expr::cpp_expr_f(cp_p0, &gd_p2.source_p), &crate::emit::cpp::cpp_type_f(cp_p0, &gd_p2.value_ty_p), &crate::emit::cpp::expr::cpp_expr_f(cp_p0, &gd_p2.select_p), &gen_moved_call_cpp_f(&gd_p2.moved_p))
}

/// The step machine of `GenBuildCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GenBuildCpp: unbounded fn Cp, Text, GenDef -> Text
/// ```
pub struct GenBuildCpp {
    pub cp_p0: crate::emit::cpp::Cp,
    pub owner_p1: Text,
    pub gd_p2: crate::lower::model::GenDef,
}

impl prism_rtl::Job<Text> for GenBuildCpp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let owner_p1 = &self.owner_p1;
        let gd_p2 = &self.gd_p2;
        let path_p3 = if gd_p2.transparent_p {
            Text::lit("this->path")
        } else {
            Text::from(format!("{}.child(Segment::gen(g))", &crate::emit::cpp::expr::cpp_expr_f(cp_p0, &gd_p2.at_p)))
        };
        let cp_p0x = cp_p0.clone();
        let gd_p2x = gd_p2.clone();
        let owner_p1x = owner_p1.clone();
        crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), gd_p2x.at_p.clone()), move |cpp_expr_f_8647: Text| crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), gd_p2x.source_p.clone()), move |cpp_expr_f_8674: Text| crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), gd_p2x.value_ty_p.clone()), move |cpp_type_f_8699: Text| crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), gd_p2x.select_p.clone()), move |cpp_expr_f_8725: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::gen_build_template_f(&owner_p1x, &gd_p2x.name_p, &cpp_expr_f_8647, &path_p3, &cpp_expr_f_8674, &cpp_type_f_8699, &cpp_expr_f_8725, &gen_moved_call_cpp_f(&gd_p2x.moved_p)))))))
    }
}

/// `Start GenBuildCpp, x`: what the function value is when passed to `@Run`.
pub fn start_gen_build_cpp_f(cp_p0: crate::emit::cpp::Cp, owner_p1: Text, gd_p2: crate::lower::model::GenDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(GenBuildCpp { cp_p0, owner_p1, gd_p2 })
}

/// ```prism
/// ProgramCpp: unbounded fn Cp, ProgDef, Bool -> Text
/// ```
pub fn program_cpp_f(cp_p0: &crate::emit::cpp::Cp, p_p1: &crate::lower::model::ProgDef, fallible_p2: &bool) -> Text {
    let n_p3 = crate::prelude::len(&p_p1.params_p);
    let names_p4 = crate::prelude::each(&p_p1.params_p, &(|(a_p9, _): &(Text, crate::lower::model::OutTy)| a_p9.clone()));
    let plural_p5 = if &n_p3 == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") };
    let decode_p6 = if &n_p3 == &Nat::from(0u32) {
        Text::lit("static_cast<void>(args);")
    } else {
        crate::syntax::lexer::chars::join_f(&crate::prelude::append(&Array::from(vec![Text::from(format!("if (args.size() != {}) return unexpected(Fault::answer(\"@{} takes {} argument{}\"));", &n_p3, &p_p1.prism_p, &n_p3, &plural_p5))]), &crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&n_p3), {
            let cp_p0x = cp_p0.clone();
            let p_p1x = p_p1.clone();
            Rc::new(move |p0: Nat| {
                let cp_p0xy = cp_p0x.clone();
                let p_p1xy = p_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let i_pa = p0;
                    prism_rtl::Turn::More(Rc::new(DecodeArg { cp_p0: cp_p0xy.clone(), ps_p1: p_p1xy.params_p.clone(), i_p2: i_pa.clone() }))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
        }))), &Text::lit("\n"))
    };
    let call_p7 = Text::from(format!("{}(Path::root(), {}cx)", &crate::emit::cpp::expr::call_path_f(&Text::from(format!("{}::build", &p_p1.node_p))), &crate::prelude::concat(&crate::prelude::each(&names_p4, &(|a_pb: &Text| Text::from(format!("{}, ", a_pb)))))));
    let root_p8 = if *fallible_p2 { Text::from(format!("TRY({})", &call_p7)) } else { call_p7.clone() };
    crate::emit::cpp::templates::items::program_class_f(&p_p1.name_p, &p_p1.prism_p, &crate::emit::cpp::type_path_f(&p_p1.node_p), &decode_p6, &root_p8)
}

/// The step machine of `ProgramCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ProgramCpp: unbounded fn Cp, ProgDef, Bool -> Text
/// ```
pub struct ProgramCpp {
    pub cp_p0: crate::emit::cpp::Cp,
    pub p_p1: crate::lower::model::ProgDef,
    pub fallible_p2: bool,
}

impl prism_rtl::Job<Text> for ProgramCpp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let p_p1 = &self.p_p1;
        let fallible_p2 = &self.fallible_p2;
        let n_p3 = crate::prelude::len(&p_p1.params_p);
        let names_p4 = crate::prelude::each(&p_p1.params_p, &(|(a_p9, _): &(Text, crate::lower::model::OutTy)| a_p9.clone()));
        let plural_p5 = if &n_p3 == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") };
        let decode_p6 = if &n_p3 == &Nat::from(0u32) {
            Text::lit("static_cast<void>(args);")
        } else {
            crate::syntax::lexer::chars::join_f(&crate::prelude::append(&Array::from(vec![Text::from(format!("if (args.size() != {}) return unexpected(Fault::answer(\"@{} takes {} argument{}\"));", &n_p3, &p_p1.prism_p, &n_p3, &plural_p5))]), &crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&n_p3), {
                let cp_p0x = cp_p0.clone();
                let p_p1x = p_p1.clone();
                Rc::new(move |p0: Nat| {
                    let cp_p0xy = cp_p0x.clone();
                    let p_p1xy = p_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let i_pa = p0;
                        prism_rtl::Turn::More(Rc::new(DecodeArg { cp_p0: cp_p0xy.clone(), ps_p1: p_p1xy.params_p.clone(), i_p2: i_pa.clone() }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
            }))), &Text::lit("\n"))
        };
        let call_p7 = Text::from(format!("{}(Path::root(), {}cx)", &crate::emit::cpp::expr::call_path_f(&Text::from(format!("{}::build", &p_p1.node_p))), &crate::prelude::concat(&crate::prelude::each(&names_p4, &(|a_pb: &Text| Text::from(format!("{}, ", a_pb)))))));
        let root_p8 = if *fallible_p2 { Text::from(format!("TRY({})", &call_p7)) } else { call_p7.clone() };
        prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::program_class_f(&p_p1.name_p, &p_p1.prism_p, &crate::emit::cpp::type_path_f(&p_p1.node_p), &decode_p6, &root_p8))
    }
}

/// `Start ProgramCpp, x`: what the function value is when passed to `@Run`.
pub fn start_program_cpp_f(cp_p0: crate::emit::cpp::Cp, p_p1: crate::lower::model::ProgDef, fallible_p2: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ProgramCpp { cp_p0, p_p1, fallible_p2 })
}

/// ```prism
/// DecodeArg: unbounded fn Cp, [((Text, OutTy))], Nat -> Text
/// ```
pub fn decode_arg_f(cp_p0: &crate::emit::cpp::Cp, ps_p1: &Array<(Text, crate::lower::model::OutTy)>, i_p2: &Nat) -> Text {
    match crate::prelude::index(ps_p1, i_p2) {
        Some((a_p3, t_p4)) => Text::from(format!("auto {} = TRY(prism_rtl::from_pod<{}>(args[{}]));", &a_p3, &crate::emit::cpp::cpp_type_f(cp_p0, &t_p4), i_p2)),
        None => Text::lit(""),
    }
}

/// The step machine of `DecodeArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DecodeArg: unbounded fn Cp, [((Text, OutTy))], Nat -> Text
/// ```
pub struct DecodeArg {
    pub cp_p0: crate::emit::cpp::Cp,
    pub ps_p1: Array<(Text, crate::lower::model::OutTy)>,
    pub i_p2: Nat,
}

impl prism_rtl::Job<Text> for DecodeArg {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let ps_p1 = &self.ps_p1;
        let i_p2 = &self.i_p2;
        match crate::prelude::index(ps_p1, i_p2) {
            Some((a_p3, t_p4)) => {
                let cp_p0x = cp_p0.clone();
                let i_p2x = i_p2.clone();
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), t_p4.clone()), move |cpp_type_f_9583: Text| prism_rtl::Turn::Finished(Text::from(format!("auto {} = TRY(prism_rtl::from_pod<{}>(args[{}]));", &a_p3, &cpp_type_f_9583, &i_p2x))))
            },
            None => prism_rtl::Turn::Finished(Text::lit("")),
        }
    }
}

/// `Start DecodeArg, x`: what the function value is when passed to `@Run`.
pub fn start_decode_arg_f(cp_p0: crate::emit::cpp::Cp, ps_p1: Array<(Text, crate::lower::model::OutTy)>, i_p2: Nat) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(DecodeArg { cp_p0, ps_p1, i_p2 })
}

/// ```prism
/// ModuleParts: unbounded fn Cp, ModDef -> Parts
/// ```
pub fn module_parts_f(cp_p0: &crate::emit::cpp::Cp, m_p1: &crate::lower::model::ModDef) -> crate::emit::cpp::items::Parts {
    let mcp_p2 = crate::emit::cpp::in_home_f(cp_p0, &m_p1.name_p);
    let all_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(m_p1.items_p.clone(), crate::emit::cpp::items::no_parts_p(), {
        let mcp_p2x = mcp_p2.clone();
        Rc::new(move |(p0, p1): (crate::emit::cpp::items::Parts, crate::lower::model::Item)| {
            let mcp_p2xy = mcp_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p4 = p0;
                let it_p5 = p1;
                crate::prelude::call_then(crate::emit::cpp::items::start_item_parts_f(mcp_p2xy.clone(), it_p5.clone()), move |item_parts_f_10032: crate::emit::cpp::items::Parts| prism_rtl::Turn::Finished(crate::emit::cpp::items::join_parts_f(&acc_p4, &item_parts_f_10032)))
            }))
        }) as Rc<dyn Fn((crate::emit::cpp::items::Parts, crate::lower::model::Item)) -> Rc<dyn prism_rtl::Job<crate::emit::cpp::items::Parts>>>
    }));
    crate::emit::cpp::items::Parts { forward_p: in_ns_f(&m_p1.name_p, &all_p3.forward_p), values_p: crate::prelude::each(&all_p3.values_p, &(|v_p6: &crate::emit::cpp::items::ValueDecl| in_ns_value_f(&m_p1.name_p, v_p6))), protos_p: in_ns_f(&m_p1.name_p, &all_p3.protos_p), classes_p: in_ns_f(&m_p1.name_p, &all_p3.classes_p), outer_p: all_p3.outer_p.clone(), generic_p: in_ns_f(&m_p1.name_p, &all_p3.generic_p), defs_p: all_p3.defs_p.clone() }
}

/// The step machine of `ModuleParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModuleParts: unbounded fn Cp, ModDef -> Parts
/// ```
pub struct ModuleParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub m_p1: crate::lower::model::ModDef,
}

impl prism_rtl::Job<crate::emit::cpp::items::Parts> for ModuleParts {
    fn cycle(&self) -> prism_rtl::Turn<crate::emit::cpp::items::Parts> {
        let cp_p0 = &self.cp_p0;
        let m_p1 = &self.m_p1;
        let mcp_p2 = crate::emit::cpp::in_home_f(cp_p0, &m_p1.name_p);
        let m_p1x = m_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(m_p1x.items_p.clone(), crate::emit::cpp::items::no_parts_p(), {
            let mcp_p2x = mcp_p2.clone();
            Rc::new(move |(p0, p1): (crate::emit::cpp::items::Parts, crate::lower::model::Item)| {
                let mcp_p2xy = mcp_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p4 = p0;
                    let it_p5 = p1;
                    crate::prelude::call_then(crate::emit::cpp::items::start_item_parts_f(mcp_p2xy.clone(), it_p5.clone()), move |item_parts_f_10032: crate::emit::cpp::items::Parts| prism_rtl::Turn::Finished(crate::emit::cpp::items::join_parts_f(&acc_p4, &item_parts_f_10032)))
                }))
            }) as Rc<dyn Fn((crate::emit::cpp::items::Parts, crate::lower::model::Item)) -> Rc<dyn prism_rtl::Job<crate::emit::cpp::items::Parts>>>
        }), move |fold_9982: crate::emit::cpp::items::Parts| {
            let all_p3 = fold_9982;
            prism_rtl::Turn::Finished(crate::emit::cpp::items::Parts { forward_p: in_ns_f(&m_p1x.name_p, &all_p3.forward_p), values_p: crate::prelude::each(&all_p3.values_p, &(|v_p6: &crate::emit::cpp::items::ValueDecl| in_ns_value_f(&m_p1x.name_p, v_p6))), protos_p: in_ns_f(&m_p1x.name_p, &all_p3.protos_p), classes_p: in_ns_f(&m_p1x.name_p, &all_p3.classes_p), outer_p: all_p3.outer_p.clone(), generic_p: in_ns_f(&m_p1x.name_p, &all_p3.generic_p), defs_p: all_p3.defs_p.clone() })
        })
    }
}

/// `Start ModuleParts, x`: what the function value is when passed to `@Run`.
pub fn start_module_parts_f(cp_p0: crate::emit::cpp::Cp, m_p1: crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<crate::emit::cpp::items::Parts>> {
    Rc::new(ModuleParts { cp_p0, m_p1 })
}

/// ```prism
/// InNsValue: fn Text, ValueDecl -> ValueDecl
/// ```
pub fn in_ns_value_f(ns_p0: &Text, v_p1: &crate::emit::cpp::items::ValueDecl) -> crate::emit::cpp::items::ValueDecl {
    let mut this: crate::emit::cpp::items::ValueDecl = v_p1.clone();
    this.text_p = Text::from(format!("namespace {} {{\n\n{}\n\n}}  // namespace {}", ns_p0, &this.text_p, ns_p0));
    this
}

/// ```prism
/// InNs: fn Text, [Text] -> [Text]
/// ```
pub fn in_ns_f(ns_p0: &Text, xs1: &Array<Text>) -> Array<Text> {
    match xs1 {
        c0_1 if (c0_1.len() == 0) => Array::new(),
        xs_p2 => Array::from(vec![Text::from(format!("namespace {} {{\n\n{}\n\n}}  // namespace {}", ns_p0, &crate::syntax::lexer::chars::join_f(xs_p2, &Text::lit("\n\n")), ns_p0))]),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// NodeFallibleCpp: fn Model, Text -> Bool
/// ```
pub fn node_fallible_cpp_f(model_p0: &crate::lower::model::Model, path_p1: &Text) -> bool {
    crate::prelude::fold(&model_p0.mods_p, &false, &(|f_p2: &bool, m_p3: &crate::lower::model::ModDef| crate::prelude::fold(&m_p3.items_p, f_p2, &(|f2_p4: &bool, it_p5: &crate::lower::model::Item| match it_p5 {
        crate::lower::model::Item::ItNode(n_p6) => *f2_p4 || ((&Text::from(format!("{}::{}", &m_p3.name_p, &n_p6.name_p)) == path_p1) && n_p6.fallible_p),
        _ => *f2_p4,
    }))))
}

/// ```prism
/// EmitCpp: unbounded fn Model, Text, [Text] -> [((Text, Text))]
/// ```
pub fn emit_cpp_f(model_p0: &crate::lower::model::Model, runtime_p1: &Text, scripts_p2: &Array<Text>) -> Array<(Text, Text)> {
    let cp_p3 = crate::emit::cpp::context_f(model_p0);
    let crate_p4 = crate::emit::cpp::in_home_f(&cp_p3, &Text::lit(""));
    let elem_p5 = crate::emit::cpp::items::row_parts_f(&crate_p4, &Text::lit(""), &model_p0.elem_p);
    let answer_p6 = crate::emit::cpp::items::answer_parts_f(&crate_p4, &model_p0.answer_p);
    let mods_p7 = crate::prelude::run_to_end(crate::prelude::each_job(model_p0.mods_p.clone(), {
        let cp_p3x = cp_p3.clone();
        Rc::new(move |p0: crate::lower::model::ModDef| {
            let cp_p3xy = cp_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_pu = p0;
                prism_rtl::Turn::More(Rc::new(ModuleParts { cp_p0: cp_p3xy.clone(), m_p1: m_pu.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<crate::emit::cpp::items::Parts>>>
    }));
    let programs_p8 = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(all_programs_cpp_f(model_p0), {
        let crate_p4x = crate_p4.clone();
        let model_p0x = model_p0.clone();
        Rc::new(move |p0: crate::lower::model::ProgDef| {
            let crate_p4xy = crate_p4x.clone();
            let model_p0xy = model_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let p_pv = p0;
                prism_rtl::Turn::More(Rc::new(ProgramCpp { cp_p0: crate_p4xy.clone(), p_p1: p_pv.clone(), fallible_p2: node_fallible_cpp_f(&model_p0xy, &p_pv.node_p) }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::ProgDef) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n\n"));
    let regs_p9 = crate::prelude::concat(&crate::prelude::each(&model_p0.programs_p, &(|p_p10: &crate::lower::model::ProgDef| Text::from(format!("\n.program<{}>(\"{}\")", &p_p10.name_p, &p_p10.prism_p)))));
    let checks_pa = crate::prelude::concat(&crate::prelude::run_to_end(crate::prelude::each_job(model_p0.checks_p.clone(), {
        let crate_p4x = crate_p4.clone();
        Rc::new(move |p0: crate::lower::model::CheckDef| {
            let crate_p4xy = crate_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let c_p11 = p0;
                crate::prelude::call_value(crate::prelude::each_job(c_p11.lines_p.clone(), {
                    let crate_p4xyx = crate_p4xy.clone();
                    Rc::new(move |p0: crate::lower::model::Ex| {
                        let crate_p4xyxy = crate_p4xyx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let l_p12 = p0;
                            prism_rtl::Turn::More(Rc::new(crate::emit::cpp::expr::CppExpr { cp_p0: crate_p4xyxy.clone(), x_p1: l_p12.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_11535: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("\n.check(\"{}\", [] {{ return std::vector<Result<Pod>>{{{}}}; }})", &c_p11.name_p, &crate::syntax::lexer::chars::join_f(&each_11535, &Text::lit(", "))))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::CheckDef) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let script_list_pb = crate::syntax::lexer::chars::join_f(&crate::prelude::each(scripts_p2, &(|s_p13: &Text| Text::from(format!("\"{}\",", &crate::lower::expr::escape_f(s_p13))))), &Text::lit("\n"));
    let world_pc = match &model_p0.root_o {
        Some(r_p14) => r_p14.world_p.clone(),
        None => Text::lit("test"),
    };
    let canvas_pd = &world_pc == &Text::lit("canvas");
    let run_root_pe = match &model_p0.root_o {
        Some(r_p15) => crate::emit::cpp::templates::cpp_run_root_f(&r_p15.name_p, &(if canvas_pd {
            crate::emit::cpp::templates::cpp_canvas_run_f(&r_p15.name_p)
        } else {
            crate::emit::cpp::templates::cpp_no_canvas_f(&r_p15.name_p)
        })),
        None => crate::emit::cpp::templates::cpp_no_root_f(&model_p0.name_p),
    };
    let both_pf = crate::emit::cpp::items::join_parts_f(&elem_p5, &answer_p6);
    let elem_decl_pg = crate::emit::cpp::templates::cpp_elem_decl_f(&includes_f(&Text::lit("decl"), &crate::prelude::append(&model_p0.elem_complete_p, &model_p0.elem_declared_p)), &crate::syntax::lexer::chars::join_f(&both_pf.forward_p, &Text::lit("\n\n")), &crate::emit::cpp::prelude::cpp_prelude_rows_f(&Text::lit("")));
    let elem_types_ph = crate::emit::cpp::templates::cpp_elem_types_f(&crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&Array::from(vec![includes_f(&Text::lit("types"), &model_p0.elem_complete_p), includes_f(&Text::lit("decl"), &model_p0.elem_declared_p)]), &(|t_p16: &Text| t_p16 != &Text::lit(""))), &Text::lit("\n")), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&both_pf.values_p, &(|v_p17: &crate::emit::cpp::items::ValueDecl| v_p17.text_p.clone())), &Text::lit("\n\n")));
    let pairs_pi = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&model_p0.mods_p)), &(|i_p18: &Nat| (crate::prelude::or(&crate::prelude::index(&model_p0.mods_p, i_p18), &no_mod_p()), crate::prelude::or(&crate::prelude::index(&mods_p7, i_p18), &crate::emit::cpp::items::no_parts_p()))));
    let generics_pj = crate::prelude::fold(&pairs_pi, &Array::new(), &(|acc_p19: &Array<Text>, (m_p1a, p_p1b): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| if &crate::prelude::len(&p_p1b.generic_p) > &Nat::from(0u32) {
        crate::prelude::push(acc_p19, &m_p1a.name_p)
    } else {
        acc_p19.clone()
    }));
    let per_module_pk = crate::prelude::run_to_end(crate::prelude::each_job(pairs_pi.clone(), Rc::new(move |p0: (crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (m_p1c, p_p1d) = p0;
        prism_rtl::Turn::More(Rc::new(ModuleFiles { m_p0: m_p1c.clone(), p_p1: p_p1d.clone() }))
    }))) as Rc<dyn Fn((crate::lower::model::ModDef, crate::emit::cpp::items::Parts)) -> Rc<dyn prism_rtl::Job<(Array<(Text, Text)>, Array<Piece>)>>>));
    let pieces_pl = crate::prelude::fold(&per_module_pk, &Array::new(), &(|acc_p1e: &Array<Piece>, (_, ps_p1f): &(Array<(Text, Text)>, Array<Piece>)| crate::prelude::append(acc_p1e, ps_p1f)));
    let units_pm = units_f(&pieces_pl);
    let unit_files_pn = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&units_pm)), &(|k_p1g: &Nat| unit_file_f(k_p1g, &crate::prelude::or(&crate::prelude::index(&units_pm, k_p1g), &Array::new()), &generics_pj)));
    let main_includes_po = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::append(&Array::from(vec![Text::lit("#include \"elem.types.hpp\"")]), &Array::from(vec![includes_f(&Text::lit(""), &crate::prelude::each(&model_p0.mods_p, &(|m_p1h: &crate::lower::model::ModDef| m_p1h.name_p.clone())))])), &Array::from(vec![includes_f(&Text::lit("generic"), &generics_pj)])), &Text::lit("\n"));
    let canvas_include_pp = if canvas_pd {
        crate::emit::cpp::templates::cpp_canvas_include_f(&Text::lit(""))
    } else {
        Text::lit("")
    };
    let main_pq = crate::emit::cpp::templates::cpp_main_f(&model_p0.name_p, &Text::from(format!("#include \"programs.hpp\"\n{}", &canvas_include_pp)), &regs_p9, &checks_pa, &script_list_pb, &world_pc, &run_root_pe, &crate::syntax::lexer::chars::join_f(&crate::emit::cpp::patterns::concat2_f(&crate::prelude::each(&Array::from(vec![elem_p5.clone(), answer_p6.clone()]), &(|p_p1i: &crate::emit::cpp::items::Parts| p_p1i.defs_p.clone()))), &Text::lit("\n\n")));
    let groups_pr = crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::filter(&model_p0.mods_p, &(|m_p1j: &crate::lower::model::ModDef| (&crate::prelude::len(&m_p1j.types_with_p) > &Nat::from(1u32)) && (&crate::prelude::or(&crate::prelude::index(&m_p1j.types_with_p, &Nat::from(0u32)), &Text::lit("")) == &m_p1j.name_p))), {
        let pairs_pix = pairs_pi.clone();
        Rc::new(move |p0: crate::lower::model::ModDef| {
            let pairs_pixy = pairs_pix.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_p1k = p0;
                prism_rtl::Turn::More(Rc::new(GroupTypesFile { pairs_p0: pairs_pixy.clone(), group_p1: m_p1k.types_with_p.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<(Text, Text)>>>
    }));
    let files_ps = crate::prelude::append(&crate::prelude::fold(&per_module_pk, &Array::new(), &(|acc_p1l: &Array<(Text, Text)>, (fs_p1m, _): &(Array<(Text, Text)>, Array<Piece>)| crate::prelude::append(acc_p1l, fs_p1m))), &unit_files_pn);
    let sources_pt = crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::each(&files_ps, &(|(f_p1n, _): &(Text, Text)| f_p1n.clone())), &(|f_p1o: &Text| crate::syntax::lexer::chars::contains_f(f_p1o, &Text::lit(".cpp")))), &Text::lit(" "));
    crate::prelude::append(&Array::from(vec![(Text::lit("Makefile"), crate::emit::cpp::templates::cpp_makefile_f(&model_p0.name_p, runtime_p1, &sources_pt, &(if canvas_pd {
        crate::emit::cpp::templates::cpp_makefile_canvas_f(runtime_p1)
    } else {
        Text::lit("")
    }))), (Text::lit("src/elem.decl.hpp"), elem_decl_pg.clone()), (Text::lit("src/elem.types.hpp"), elem_types_ph.clone()), (Text::lit("src/programs.hpp"), crate::emit::cpp::templates::cpp_programs_header_f(&model_p0.name_p, &main_includes_po, &programs_p8)), (Text::lit("src/main.cpp"), main_pq.clone()), (Text::lit("src/prelude.hpp"), crate::emit::cpp::prelude::cpp_prelude_source_f(&Text::lit("")))]), &crate::prelude::append(&groups_pr, &files_ps))
}

/// The step machine of `EmitCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EmitCpp: unbounded fn Model, Text, [Text] -> [((Text, Text))]
/// ```
pub struct EmitCpp {
    pub model_p0: crate::lower::model::Model,
    pub runtime_p1: Text,
    pub scripts_p2: Array<Text>,
}

impl prism_rtl::Job<Array<(Text, Text)>> for EmitCpp {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Text, Text)>> {
        let model_p0 = &self.model_p0;
        let runtime_p1 = &self.runtime_p1;
        let scripts_p2 = &self.scripts_p2;
        let cp_p3 = crate::emit::cpp::context_f(model_p0);
        let crate_p4 = crate::emit::cpp::in_home_f(&cp_p3, &Text::lit(""));
        let model_p0x = model_p0.clone();
        let runtime_p1x = runtime_p1.clone();
        let scripts_p2x = scripts_p2.clone();
        crate::prelude::call_then(crate::emit::cpp::items::start_row_parts_f(crate_p4.clone(), Text::lit(""), model_p0x.elem_p.clone()), move |row_parts_f_11072: crate::emit::cpp::items::Parts| {
            let elem_p5 = row_parts_f_11072;
            crate::prelude::call_then(crate::emit::cpp::items::start_answer_parts_f(crate_p4.clone(), model_p0x.answer_p.clone()), move |answer_parts_f_11120: crate::emit::cpp::items::Parts| {
                let answer_p6 = answer_parts_f_11120;
                crate::prelude::call_value(crate::prelude::each_job(model_p0x.mods_p.clone(), {
                    let cp_p3x = cp_p3.clone();
                    Rc::new(move |p0: crate::lower::model::ModDef| {
                        let cp_p3xy = cp_p3x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let m_pu = p0;
                            prism_rtl::Turn::More(Rc::new(ModuleParts { cp_p0: cp_p3xy.clone(), m_p1: m_pu.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<crate::emit::cpp::items::Parts>>>
                }), move |each_11167: Array<crate::emit::cpp::items::Parts>| {
                    let mods_p7 = each_11167;
                    crate::prelude::call_value(crate::prelude::each_job(all_programs_cpp_f(&model_p0x), {
                        let crate_p4x = crate_p4.clone();
                        let model_p0xx = model_p0x.clone();
                        Rc::new(move |p0: crate::lower::model::ProgDef| {
                            let crate_p4xy = crate_p4x.clone();
                            let model_p0xxy = model_p0xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let p_pv = p0;
                                prism_rtl::Turn::More(Rc::new(ProgramCpp { cp_p0: crate_p4xy.clone(), p_p1: p_pv.clone(), fallible_p2: node_fallible_cpp_f(&model_p0xxy, &p_pv.node_p) }))
                            }))
                        }) as Rc<dyn Fn(crate::lower::model::ProgDef) -> Rc<dyn prism_rtl::Job<Text>>>
                    }), move |each_11232: Array<Text>| {
                        let programs_p8 = crate::syntax::lexer::chars::join_f(&each_11232, &Text::lit("\n\n"));
                        let regs_p9 = crate::prelude::concat(&crate::prelude::each(&model_p0x.programs_p, &(|p_p10: &crate::lower::model::ProgDef| Text::from(format!("\n.program<{}>(\"{}\")", &p_p10.name_p, &p_p10.prism_p)))));
                        crate::prelude::call_value(crate::prelude::each_job(model_p0x.checks_p.clone(), {
                            let crate_p4x = crate_p4.clone();
                            Rc::new(move |p0: crate::lower::model::CheckDef| {
                                let crate_p4xy = crate_p4x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let c_p11 = p0;
                                    crate::prelude::call_value(crate::prelude::each_job(c_p11.lines_p.clone(), {
                                        let crate_p4xyx = crate_p4xy.clone();
                                        Rc::new(move |p0: crate::lower::model::Ex| {
                                            let crate_p4xyxy = crate_p4xyx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let l_p12 = p0;
                                                prism_rtl::Turn::More(Rc::new(crate::emit::cpp::expr::CppExpr { cp_p0: crate_p4xyxy.clone(), x_p1: l_p12.clone() }))
                                            }))
                                        }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
                                    }), move |each_11535: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("\n.check(\"{}\", [] {{ return std::vector<Result<Pod>>{{{}}}; }})", &c_p11.name_p, &crate::syntax::lexer::chars::join_f(&each_11535, &Text::lit(", "))))))
                                }))
                            }) as Rc<dyn Fn(crate::lower::model::CheckDef) -> Rc<dyn prism_rtl::Job<Text>>>
                        }), move |each_11441: Array<Text>| {
                            let checks_pa = crate::prelude::concat(&each_11441);
                            let script_list_pb = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&scripts_p2x, &(|s_p13: &Text| Text::from(format!("\"{}\",", &crate::lower::expr::escape_f(s_p13))))), &Text::lit("\n"));
                            let world_pc = match &model_p0x.root_o {
                                Some(r_p14) => r_p14.world_p.clone(),
                                None => Text::lit("test"),
                            };
                            let canvas_pd = &world_pc == &Text::lit("canvas");
                            let run_root_pe = match &model_p0x.root_o {
                                Some(r_p15) => crate::emit::cpp::templates::cpp_run_root_f(&r_p15.name_p, &(if canvas_pd {
                                    crate::emit::cpp::templates::cpp_canvas_run_f(&r_p15.name_p)
                                } else {
                                    crate::emit::cpp::templates::cpp_no_canvas_f(&r_p15.name_p)
                                })),
                                None => crate::emit::cpp::templates::cpp_no_root_f(&model_p0x.name_p),
                            };
                            let both_pf = crate::emit::cpp::items::join_parts_f(&elem_p5, &answer_p6);
                            let elem_decl_pg = crate::emit::cpp::templates::cpp_elem_decl_f(&includes_f(&Text::lit("decl"), &crate::prelude::append(&model_p0x.elem_complete_p, &model_p0x.elem_declared_p)), &crate::syntax::lexer::chars::join_f(&both_pf.forward_p, &Text::lit("\n\n")), &crate::emit::cpp::prelude::cpp_prelude_rows_f(&Text::lit("")));
                            let elem_types_ph = crate::emit::cpp::templates::cpp_elem_types_f(&crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&Array::from(vec![includes_f(&Text::lit("types"), &model_p0x.elem_complete_p), includes_f(&Text::lit("decl"), &model_p0x.elem_declared_p)]), &(|t_p16: &Text| t_p16 != &Text::lit(""))), &Text::lit("\n")), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&both_pf.values_p, &(|v_p17: &crate::emit::cpp::items::ValueDecl| v_p17.text_p.clone())), &Text::lit("\n\n")));
                            let pairs_pi = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&model_p0x.mods_p)), &(|i_p18: &Nat| (crate::prelude::or(&crate::prelude::index(&model_p0x.mods_p, i_p18), &no_mod_p()), crate::prelude::or(&crate::prelude::index(&mods_p7, i_p18), &crate::emit::cpp::items::no_parts_p()))));
                            let generics_pj = crate::prelude::fold(&pairs_pi, &Array::new(), &(|acc_p19: &Array<Text>, (m_p1a, p_p1b): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| if &crate::prelude::len(&p_p1b.generic_p) > &Nat::from(0u32) {
                                crate::prelude::push(acc_p19, &m_p1a.name_p)
                            } else {
                                acc_p19.clone()
                            }));
                            crate::prelude::call_value(crate::prelude::each_job(pairs_pi.clone(), Rc::new(move |p0: (crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| crate::prelude::entered(crate::prelude::once_job(move || {
                                let (m_p1c, p_p1d) = p0;
                                prism_rtl::Turn::More(Rc::new(ModuleFiles { m_p0: m_p1c.clone(), p_p1: p_p1d.clone() }))
                            }))) as Rc<dyn Fn((crate::lower::model::ModDef, crate::emit::cpp::items::Parts)) -> Rc<dyn prism_rtl::Job<(Array<(Text, Text)>, Array<Piece>)>>>), move |each_12547: Array<(Array<(Text, Text)>, Array<Piece>)>| {
                                let per_module_pk = each_12547;
                                let pieces_pl = crate::prelude::fold(&per_module_pk, &Array::new(), &(|acc_p1e: &Array<Piece>, (_, ps_p1f): &(Array<(Text, Text)>, Array<Piece>)| crate::prelude::append(acc_p1e, ps_p1f)));
                                let units_pm = units_f(&pieces_pl);
                                let unit_files_pn = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&units_pm)), &(|k_p1g: &Nat| unit_file_f(k_p1g, &crate::prelude::or(&crate::prelude::index(&units_pm, k_p1g), &Array::new()), &generics_pj)));
                                let main_includes_po = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::append(&Array::from(vec![Text::lit("#include \"elem.types.hpp\"")]), &Array::from(vec![includes_f(&Text::lit(""), &crate::prelude::each(&model_p0x.mods_p, &(|m_p1h: &crate::lower::model::ModDef| m_p1h.name_p.clone())))])), &Array::from(vec![includes_f(&Text::lit("generic"), &generics_pj)])), &Text::lit("\n"));
                                let canvas_include_pp = if canvas_pd {
                                    crate::emit::cpp::templates::cpp_canvas_include_f(&Text::lit(""))
                                } else {
                                    Text::lit("")
                                };
                                let main_pq = crate::emit::cpp::templates::cpp_main_f(&model_p0x.name_p, &Text::from(format!("#include \"programs.hpp\"\n{}", &canvas_include_pp)), &regs_p9, &checks_pa, &script_list_pb, &world_pc, &run_root_pe, &crate::syntax::lexer::chars::join_f(&crate::emit::cpp::patterns::concat2_f(&crate::prelude::each(&Array::from(vec![elem_p5.clone(), answer_p6.clone()]), &(|p_p1i: &crate::emit::cpp::items::Parts| p_p1i.defs_p.clone()))), &Text::lit("\n\n")));
                                crate::prelude::call_value(crate::prelude::each_job(crate::prelude::filter(&model_p0x.mods_p, &(|m_p1j: &crate::lower::model::ModDef| (&crate::prelude::len(&m_p1j.types_with_p) > &Nat::from(1u32)) && (&crate::prelude::or(&crate::prelude::index(&m_p1j.types_with_p, &Nat::from(0u32)), &Text::lit("")) == &m_p1j.name_p))), {
                                    let pairs_pix = pairs_pi.clone();
                                    Rc::new(move |p0: crate::lower::model::ModDef| {
                                        let pairs_pixy = pairs_pix.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let m_p1k = p0;
                                            prism_rtl::Turn::More(Rc::new(GroupTypesFile { pairs_p0: pairs_pixy.clone(), group_p1: m_p1k.types_with_p.clone() }))
                                        }))
                                    }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<(Text, Text)>>>
                                }), move |each_13227: Array<(Text, Text)>| {
                                    let groups_pr = each_13227;
                                    let files_ps = crate::prelude::append(&crate::prelude::fold(&per_module_pk, &Array::new(), &(|acc_p1l: &Array<(Text, Text)>, (fs_p1m, _): &(Array<(Text, Text)>, Array<Piece>)| crate::prelude::append(acc_p1l, fs_p1m))), &unit_files_pn);
                                    let sources_pt = crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::each(&files_ps, &(|(f_p1n, _): &(Text, Text)| f_p1n.clone())), &(|f_p1o: &Text| crate::syntax::lexer::chars::contains_f(f_p1o, &Text::lit(".cpp")))), &Text::lit(" "));
                                    prism_rtl::Turn::Finished(crate::prelude::append(&Array::from(vec![(Text::lit("Makefile"), crate::emit::cpp::templates::cpp_makefile_f(&model_p0x.name_p, &runtime_p1x, &sources_pt, &(if canvas_pd {
                                        crate::emit::cpp::templates::cpp_makefile_canvas_f(&runtime_p1x)
                                    } else {
                                        Text::lit("")
                                    }))), (Text::lit("src/elem.decl.hpp"), elem_decl_pg.clone()), (Text::lit("src/elem.types.hpp"), elem_types_ph.clone()), (Text::lit("src/programs.hpp"), crate::emit::cpp::templates::cpp_programs_header_f(&model_p0x.name_p, &main_includes_po, &programs_p8)), (Text::lit("src/main.cpp"), main_pq.clone()), (Text::lit("src/prelude.hpp"), crate::emit::cpp::prelude::cpp_prelude_source_f(&Text::lit("")))]), &crate::prelude::append(&groups_pr, &files_ps)))
                                })
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start EmitCpp, x`: what the function value is when passed to `@Run`.
pub fn start_emit_cpp_f(model_p0: crate::lower::model::Model, runtime_p1: Text, scripts_p2: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>> {
    Rc::new(EmitCpp { model_p0, runtime_p1, scripts_p2 })
}

/// ```prism
/// let noMod
/// ```
pub fn no_mod_p() -> crate::lower::model::ModDef {
    crate::lower::model::ModDef { name_p: Text::lit(""), prism_p: Text::lit(""), path_p: Text::lit(""), uses_p: Array::new(), complete_p: Array::new(), declared_p: Array::new(), types_with_p: Array::new(), items_p: Array::new() }
}

/// ```prism
/// GroupTypesFile: unbounded fn [((ModDef, Parts))], [Text] -> ((Text, Text))
/// ```
pub fn group_types_file_f(pairs_p0: &Array<(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)>, group_p1: &Array<Text>) -> (Text, Text) {
    let members_p2 = crate::prelude::filter(pairs_p0, &(|(m_p7, _): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| among_f(group_p1, &m_p7.name_p)));
    let p_p3 = crate::prelude::fold(&members_p2, &crate::emit::cpp::items::no_parts_p(), &(|acc_p8: &crate::emit::cpp::items::Parts, (_, q_p9): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| crate::emit::cpp::items::join_parts_f(acc_p8, q_p9)));
    let complete_p4 = crate::prelude::fold(&members_p2, &Array::new(), &(|acc_pa: &Array<Text>, (m_pb, _): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| crate::prelude::fold(&m_pb.complete_p, acc_pa, &(|a_pc: &Array<Text>, n_pd: &Text| if among_f(a_pc, n_pd) || among_f(group_p1, n_pd) {
        a_pc.clone()
    } else {
        crate::prelude::push(a_pc, n_pd)
    }))));
    let declared_p5 = crate::prelude::fold(&members_p2, &Array::new(), &(|acc_pe: &Array<Text>, (m_pf, _): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| crate::prelude::fold(&m_pf.declared_p, acc_pe, &(|a_pg: &Array<Text>, n_ph: &Text| if (among_f(a_pg, n_ph) || among_f(group_p1, n_ph)) || among_f(&complete_p4, n_ph) {
        a_pg.clone()
    } else {
        crate::prelude::push(a_pg, n_ph)
    }))));
    let title_p6 = Text::from(format!("The modules {}", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(group_p1, &(|n_pi: &Text| Text::from(format!("`{}`", n_pi)))), &Text::lit(", "))));
    (Text::from(format!("src/{}.types.hpp", &group_name_f(group_p1))), types_header_f(&title_p6, group_p1, &declared_p5, &complete_p4, &p_p3))
}

/// The step machine of `GroupTypesFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GroupTypesFile: unbounded fn [((ModDef, Parts))], [Text] -> ((Text, Text))
/// ```
pub struct GroupTypesFile {
    pub pairs_p0: Array<(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)>,
    pub group_p1: Array<Text>,
}

impl prism_rtl::Job<(Text, Text)> for GroupTypesFile {
    fn cycle(&self) -> prism_rtl::Turn<(Text, Text)> {
        let pairs_p0 = &self.pairs_p0;
        let group_p1 = &self.group_p1;
        let members_p2 = crate::prelude::filter(pairs_p0, &(|(m_p7, _): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| among_f(group_p1, &m_p7.name_p)));
        let p_p3 = crate::prelude::fold(&members_p2, &crate::emit::cpp::items::no_parts_p(), &(|acc_p8: &crate::emit::cpp::items::Parts, (_, q_p9): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| crate::emit::cpp::items::join_parts_f(acc_p8, q_p9)));
        let complete_p4 = crate::prelude::fold(&members_p2, &Array::new(), &(|acc_pa: &Array<Text>, (m_pb, _): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| crate::prelude::fold(&m_pb.complete_p, acc_pa, &(|a_pc: &Array<Text>, n_pd: &Text| if among_f(a_pc, n_pd) || among_f(group_p1, n_pd) {
            a_pc.clone()
        } else {
            crate::prelude::push(a_pc, n_pd)
        }))));
        let declared_p5 = crate::prelude::fold(&members_p2, &Array::new(), &(|acc_pe: &Array<Text>, (m_pf, _): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| crate::prelude::fold(&m_pf.declared_p, acc_pe, &(|a_pg: &Array<Text>, n_ph: &Text| if (among_f(a_pg, n_ph) || among_f(group_p1, n_ph)) || among_f(&complete_p4, n_ph) {
            a_pg.clone()
        } else {
            crate::prelude::push(a_pg, n_ph)
        }))));
        let title_p6 = Text::from(format!("The modules {}", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(group_p1, &(|n_pi: &Text| Text::from(format!("`{}`", n_pi)))), &Text::lit(", "))));
        let group_p1x = group_p1.clone();
        crate::prelude::call_then(start_types_header_f(title_p6.clone(), group_p1x.clone(), declared_p5.clone(), complete_p4.clone(), p_p3.clone()), move |types_header_f_14897: Text| prism_rtl::Turn::Finished((Text::from(format!("src/{}.types.hpp", &group_name_f(&group_p1x))), types_header_f_14897)))
    }
}

/// `Start GroupTypesFile, x`: what the function value is when passed to `@Run`.
pub fn start_group_types_file_f(pairs_p0: Array<(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)>, group_p1: Array<Text>) -> Rc<dyn prism_rtl::Job<(Text, Text)>> {
    Rc::new(GroupTypesFile { pairs_p0, group_p1 })
}

/// ```prism
/// GroupName: fn [Text] -> Text
/// ```
pub fn group_name_f(group_p0: &Array<Text>) -> Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::each(group_p0, &(|n_p1: &Text| crate::syntax::lexer::chars::join_f(&crate::prelude::split_on(n_p1, &Text::lit("::")), &Text::lit("_")))), &Text::lit("-"))
}

/// ```prism
/// ModDir: fn Text -> Text
/// ```
pub fn mod_dir_f(m_p0: &Text) -> Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::split_on(m_p0, &Text::lit("::")), &Text::lit("/"))
}

/// ```prism
/// Among: fn [Text], Text -> Bool
/// ```
pub fn among_f(xs_p0: &Array<Text>, x_p1: &Text) -> bool {
    crate::prelude::fold(xs_p0, &false, &(|f_p2: &bool, y_p3: &Text| *f_p2 || (y_p3 == x_p1)))
}

/// ```prism
/// TypesHeader: unbounded fn Text, [Text], [Text], [Text], Parts -> Text
/// ```
pub fn types_header_f(title_p0: &Text, members_p1: &Array<Text>, declared_p2: &Array<Text>, complete_p3: &Array<Text>, p_p4: &crate::emit::cpp::items::Parts) -> Text {
    let holds_elem_p5 = crate::prelude::fold(&p_p4.values_p, &false, &(|f_p9: &bool, v_pa: &crate::emit::cpp::items::ValueDecl| *f_p9 || crate::prelude::fold(&v_pa.deps_p, &false, &(|g_pb: &bool, d_pc: &Text| (*g_pb || (d_pc == &Text::lit("Elem"))) || (d_pc == &Text::lit("Answer"))))));
    let elem_p6 = if holds_elem_p5 {
        Text::lit("#include \"elem.types.hpp\"")
    } else {
        Text::lit("#include \"elem.decl.hpp\"")
    };
    let includes_p7 = crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&Array::from(vec![includes_f(&Text::lit("decl"), members_p1), elem_p6.clone(), includes_f(&Text::lit("decl"), declared_p2), includes_f(&Text::lit("types"), complete_p3)]), &(|t_pd: &Text| t_pd != &Text::lit(""))), &Text::lit("\n"));
    let values_p8 = crate::syntax::lexer::chars::join_f(&order_values_f(&p_p4.values_p, &crate::prelude::fold(&p_p4.values_p, &Map::new(), &(|acc_pe: &Map<Text, bool>, v_pf: &crate::emit::cpp::items::ValueDecl| crate::prelude::insert(acc_pe, &v_pf.path_p, &false))), &Array::new()), &Text::lit("\n\n"));
    crate::emit::cpp::templates::cpp_types_header_f(title_p0, &includes_p7, &values_p8)
}

/// The step machine of `TypesHeader`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypesHeader: unbounded fn Text, [Text], [Text], [Text], Parts -> Text
/// ```
pub struct TypesHeader {
    pub title_p0: Text,
    pub members_p1: Array<Text>,
    pub declared_p2: Array<Text>,
    pub complete_p3: Array<Text>,
    pub p_p4: crate::emit::cpp::items::Parts,
}

impl prism_rtl::Job<Text> for TypesHeader {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let title_p0 = &self.title_p0;
        let members_p1 = &self.members_p1;
        let declared_p2 = &self.declared_p2;
        let complete_p3 = &self.complete_p3;
        let p_p4 = &self.p_p4;
        let holds_elem_p5 = crate::prelude::fold(&p_p4.values_p, &false, &(|f_p9: &bool, v_pa: &crate::emit::cpp::items::ValueDecl| *f_p9 || crate::prelude::fold(&v_pa.deps_p, &false, &(|g_pb: &bool, d_pc: &Text| (*g_pb || (d_pc == &Text::lit("Elem"))) || (d_pc == &Text::lit("Answer"))))));
        let elem_p6 = if holds_elem_p5 {
            Text::lit("#include \"elem.types.hpp\"")
        } else {
            Text::lit("#include \"elem.decl.hpp\"")
        };
        let includes_p7 = crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&Array::from(vec![includes_f(&Text::lit("decl"), members_p1), elem_p6.clone(), includes_f(&Text::lit("decl"), declared_p2), includes_f(&Text::lit("types"), complete_p3)]), &(|t_pd: &Text| t_pd != &Text::lit(""))), &Text::lit("\n"));
        let p_p4x = p_p4.clone();
        let title_p0x = title_p0.clone();
        crate::prelude::call_then(start_order_values_f(p_p4x.values_p.clone(), crate::prelude::fold(&p_p4x.values_p, &Map::new(), &(|acc_pe: &Map<Text, bool>, v_pf: &crate::emit::cpp::items::ValueDecl| crate::prelude::insert(acc_pe, &v_pf.path_p, &false))), Array::new()), move |order_values_f_16279: Array<Text>| {
            let values_p8 = crate::syntax::lexer::chars::join_f(&order_values_f_16279, &Text::lit("\n\n"));
            prism_rtl::Turn::Finished(crate::emit::cpp::templates::cpp_types_header_f(&title_p0x, &includes_p7, &values_p8))
        })
    }
}

/// `Start TypesHeader, x`: what the function value is when passed to `@Run`.
pub fn start_types_header_f(title_p0: Text, members_p1: Array<Text>, declared_p2: Array<Text>, complete_p3: Array<Text>, p_p4: crate::emit::cpp::items::Parts) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TypesHeader { title_p0, members_p1, declared_p2, complete_p3, p_p4 })
}

/// ```prism
/// Includes: fn Text, [Text] -> Text
/// ```
pub fn includes_f(layer_p0: &Text, ms_p1: &Array<Text>) -> Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::each(ms_p1, &(|m_p2: &Text| Text::from(format!("#include <{}/{}.hpp>", &mod_dir_f(m_p2), &(if layer_p0 == &Text::lit("") { Text::lit("module") } else { layer_p0.clone() }))))), &Text::lit("\n"))
}

/// ```prism
/// Chunks: fn [Text] -> [ [Text] ]
/// ```
pub fn chunks_f(defs_p0: &Array<Text>) -> Array<Array<Text>> {
    let (done_p5, current_p6, size_p7) = crate::prelude::fold(defs_p0, &(Array::new(), Array::new(), Nat::from(0u32)), &(|(acc_p1, cur_p2, n_p3): &(Array<Array<Text>>, Array<Text>, Nat), d_p4: &Text| if (n_p3 > &chunk_size_p()) && (&crate::prelude::len(cur_p2) > &Nat::from(0u32)) {
        (crate::prelude::push(acc_p1, cur_p2), Array::from(vec![d_p4.clone()]), crate::prelude::len_text(d_p4))
    } else {
        (acc_p1.clone(), crate::prelude::push(cur_p2, d_p4), n_p3 + &crate::prelude::len_text(d_p4))
    }));
    if (&crate::prelude::len(&current_p6) == &Nat::from(0u32)) && (&crate::prelude::len(&done_p5) > &Nat::from(0u32)) {
        done_p5.clone()
    } else {
        crate::prelude::push(&done_p5, &current_p6)
    }
}

/// ```prism
/// let chunkSize
/// ```
pub fn chunk_size_p() -> Nat {
    Nat::from(250000u32)
}

/// ```prism
/// ModuleFiles: unbounded fn ModDef, Parts -> (([((Text, Text))], [Piece]))
/// ```
pub fn module_files_f(m_p0: &crate::lower::model::ModDef, p_p1: &crate::emit::cpp::items::Parts) -> (Array<(Text, Text)>, Array<Piece>) {
    let title_p2 = if &m_p0.prism_p == &Text::lit("") {
        Text::lit("The root module")
    } else {
        Text::from(format!("The module `{}`", &m_p0.prism_p))
    };
    let needed_p3 = crate::prelude::append(&m_p0.complete_p, &m_p0.declared_p);
    let decl_p4 = crate::emit::cpp::templates::cpp_decl_header_f(&title_p2, &Text::lit(""), &crate::syntax::lexer::chars::join_f(&p_p1.forward_p, &Text::lit("\n\n")));
    let types_p5 = if &crate::prelude::len(&m_p0.types_with_p) > &Nat::from(1u32) {
        crate::emit::cpp::templates::cpp_types_in_group_f(&title_p2, &group_name_f(&m_p0.types_with_p))
    } else {
        types_header_f(&title_p2, &Array::from(vec![m_p0.name_p.clone()]), &m_p0.declared_p, &m_p0.complete_p, p_p1)
    };
    let head_includes_p6 = crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&Array::from(vec![Text::from(format!("{}\n#include \"elem.types.hpp\"", &includes_f(&Text::lit("types"), &Array::from(vec![m_p0.name_p.clone()])))), includes_f(&Text::lit("types"), &needed_p3)]), &(|t_pd: &Text| t_pd != &Text::lit(""))), &Text::lit("\n"));
    let head_p7 = crate::emit::cpp::templates::cpp_mod_header_f(&title_p2, &head_includes_p6, &crate::syntax::lexer::chars::join_f(&p_p1.protos_p, &Text::lit("\n")), &crate::syntax::lexer::chars::join_f(&p_p1.outer_p, &Text::lit("\n\n")), &crate::syntax::lexer::chars::join_f(&p_p1.classes_p, &Text::lit("\n\n")));
    let with_mine_p8 = crate::prelude::append(&Array::from(vec![m_p0.name_p.clone()]), &needed_p3);
    let generic_p9 = if &crate::prelude::len(&p_p1.generic_p) == &Nat::from(0u32) {
        Array::new()
    } else {
        Array::from(vec![(Text::from(format!("src/{}/generic.hpp", &mod_dir_f(&m_p0.name_p))), crate::emit::cpp::templates::cpp_generic_header_f(&title_p2, &includes_f(&Text::lit(""), &with_mine_p8), &crate::syntax::lexer::chars::join_f(&p_p1.generic_p, &Text::lit("\n\n"))))])
    };
    let chunks_pa = if &crate::prelude::len(&p_p1.defs_p) == &Nat::from(0u32) {
        Array::new()
    } else {
        chunks_f(&p_p1.defs_p)
    };
    let pieces_pb = crate::prelude::each(&chunks_pa, &(|c_pe: &Array<Text>| Piece { title_p: title_p2.clone(), prism_p: m_p0.prism_p.clone(), path_p: m_p0.path_p.clone(), ns_p: m_p0.name_p.clone(), needs_p: with_mine_p8.clone(), defs_p: crate::syntax::lexer::chars::join_f(c_pe, &Text::lit("\n\n")) }));
    let dir_pc = mod_dir_f(&m_p0.name_p);
    (crate::prelude::append(&Array::from(vec![(Text::from(format!("src/{}/decl.hpp", &dir_pc)), decl_p4.clone()), (Text::from(format!("src/{}/types.hpp", &dir_pc)), types_p5.clone()), (Text::from(format!("src/{}/module.hpp", &dir_pc)), head_p7.clone())]), &generic_p9), pieces_pb.clone())
}

/// The step machine of `ModuleFiles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModuleFiles: unbounded fn ModDef, Parts -> (([((Text, Text))], [Piece]))
/// ```
pub struct ModuleFiles {
    pub m_p0: crate::lower::model::ModDef,
    pub p_p1: crate::emit::cpp::items::Parts,
}

impl prism_rtl::Job<(Array<(Text, Text)>, Array<Piece>)> for ModuleFiles {
    fn cycle(&self) -> prism_rtl::Turn<(Array<(Text, Text)>, Array<Piece>)> {
        let m_p0 = &self.m_p0;
        let p_p1 = &self.p_p1;
        let title_p2 = if &m_p0.prism_p == &Text::lit("") {
            Text::lit("The root module")
        } else {
            Text::from(format!("The module `{}`", &m_p0.prism_p))
        };
        let needed_p3 = crate::prelude::append(&m_p0.complete_p, &m_p0.declared_p);
        let decl_p4 = crate::emit::cpp::templates::cpp_decl_header_f(&title_p2, &Text::lit(""), &crate::syntax::lexer::chars::join_f(&p_p1.forward_p, &Text::lit("\n\n")));
        let types_p5 = if &crate::prelude::len(&m_p0.types_with_p) > &Nat::from(1u32) {
            crate::emit::cpp::templates::cpp_types_in_group_f(&title_p2, &group_name_f(&m_p0.types_with_p))
        } else {
            types_header_f(&title_p2, &Array::from(vec![m_p0.name_p.clone()]), &m_p0.declared_p, &m_p0.complete_p, p_p1)
        };
        let head_includes_p6 = crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&Array::from(vec![Text::from(format!("{}\n#include \"elem.types.hpp\"", &includes_f(&Text::lit("types"), &Array::from(vec![m_p0.name_p.clone()])))), includes_f(&Text::lit("types"), &needed_p3)]), &(|t_pd: &Text| t_pd != &Text::lit(""))), &Text::lit("\n"));
        let head_p7 = crate::emit::cpp::templates::cpp_mod_header_f(&title_p2, &head_includes_p6, &crate::syntax::lexer::chars::join_f(&p_p1.protos_p, &Text::lit("\n")), &crate::syntax::lexer::chars::join_f(&p_p1.outer_p, &Text::lit("\n\n")), &crate::syntax::lexer::chars::join_f(&p_p1.classes_p, &Text::lit("\n\n")));
        let with_mine_p8 = crate::prelude::append(&Array::from(vec![m_p0.name_p.clone()]), &needed_p3);
        let generic_p9 = if &crate::prelude::len(&p_p1.generic_p) == &Nat::from(0u32) {
            Array::new()
        } else {
            Array::from(vec![(Text::from(format!("src/{}/generic.hpp", &mod_dir_f(&m_p0.name_p))), crate::emit::cpp::templates::cpp_generic_header_f(&title_p2, &includes_f(&Text::lit(""), &with_mine_p8), &crate::syntax::lexer::chars::join_f(&p_p1.generic_p, &Text::lit("\n\n"))))])
        };
        let chunks_pa = if &crate::prelude::len(&p_p1.defs_p) == &Nat::from(0u32) {
            Array::new()
        } else {
            chunks_f(&p_p1.defs_p)
        };
        let pieces_pb = crate::prelude::each(&chunks_pa, &(|c_pe: &Array<Text>| Piece { title_p: title_p2.clone(), prism_p: m_p0.prism_p.clone(), path_p: m_p0.path_p.clone(), ns_p: m_p0.name_p.clone(), needs_p: with_mine_p8.clone(), defs_p: crate::syntax::lexer::chars::join_f(c_pe, &Text::lit("\n\n")) }));
        let dir_pc = mod_dir_f(&m_p0.name_p);
        prism_rtl::Turn::Finished((crate::prelude::append(&Array::from(vec![(Text::from(format!("src/{}/decl.hpp", &dir_pc)), decl_p4.clone()), (Text::from(format!("src/{}/types.hpp", &dir_pc)), types_p5.clone()), (Text::from(format!("src/{}/module.hpp", &dir_pc)), head_p7.clone())]), &generic_p9), pieces_pb.clone()))
    }
}

/// `Start ModuleFiles, x`: what the function value is when passed to `@Run`.
pub fn start_module_files_f(m_p0: crate::lower::model::ModDef, p_p1: crate::emit::cpp::items::Parts) -> Rc<dyn prism_rtl::Job<(Array<(Text, Text)>, Array<Piece>)>> {
    Rc::new(ModuleFiles { m_p0, p_p1 })
}

/// ```prism
/// Units: fn [Piece] -> [ [Piece] ]
/// ```
pub fn units_f(pieces_p0: &Array<Piece>) -> Array<Array<Piece>> {
    let (done_p5, current_p6, size_p7) = crate::prelude::fold(pieces_p0, &(Array::new(), Array::new(), Nat::from(0u32)), &(|(acc_p1, cur_p2, n_p3): &(Array<Array<Piece>>, Array<Piece>, Nat), pc_p4: &Piece| if (&crate::prelude::len(cur_p2) > &Nat::from(0u32)) && (&(n_p3 + &crate::prelude::len_text(&pc_p4.defs_p)) > &unit_size_p()) {
        (crate::prelude::push(acc_p1, cur_p2), Array::from(vec![pc_p4.clone()]), crate::prelude::len_text(&pc_p4.defs_p))
    } else {
        (acc_p1.clone(), crate::prelude::push(cur_p2, pc_p4), n_p3 + &crate::prelude::len_text(&pc_p4.defs_p))
    }));
    if &crate::prelude::len(&current_p6) == &Nat::from(0u32) {
        done_p5.clone()
    } else {
        crate::prelude::push(&done_p5, &current_p6)
    }
}

/// ```prism
/// let unitSize
/// ```
pub fn unit_size_p() -> Nat {
    Nat::from(125000u32)
}

/// ```prism
/// UnitFile: fn Nat, [Piece], [Text] -> ((Text, Text))
/// ```
pub fn unit_file_f(k_p0: &Nat, pieces_p1: &Array<Piece>, generics_p2: &Array<Text>) -> (Text, Text) {
    let needs_p3 = crate::prelude::fold(pieces_p1, &Array::new(), &(|acc_p8: &Array<Text>, pc_p9: &Piece| crate::prelude::fold(&pc_p9.needs_p, acc_p8, &(|a_pa: &Array<Text>, n_pb: &Text| if among_f(a_pa, n_pb) { a_pa.clone() } else { crate::prelude::push(a_pa, n_pb) }))));
    let includes_p4 = crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&Array::from(vec![includes_f(&Text::lit(""), &needs_p3), includes_f(&Text::lit("generic"), &crate::prelude::filter(&needs_p3, &(|n_pc: &Text| among_f(generics_p2, n_pc))))]), &(|t_pd: &Text| t_pd != &Text::lit(""))), &Text::lit("\n"));
    let names_p5 = crate::prelude::fold(pieces_p1, &Array::new(), &(|acc_pe: &Array<Text>, pc_pf: &Piece| if among_f(acc_pe, &pc_pf.prism_p) {
        acc_pe.clone()
    } else {
        crate::prelude::push(acc_pe, &pc_pf.prism_p)
    }));
    let title_p6 = if &crate::prelude::len(&names_p5) == &Nat::from(1u32) {
        crate::prelude::or(&crate::prelude::index(pieces_p1, &Nat::from(0u32)), &dummy_piece_p()).title_p.clone()
    } else {
        Text::from(format!("The modules {}", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&names_p5, &(|n_pg: &Text| if n_pg == &Text::lit("") {
            Text::lit("the root")
        } else {
            Text::from(format!("`{}`", n_pg))
        })), &Text::lit(", "))))
    };
    let parts_p7 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(pieces_p1, &(|pc_ph: &Piece| crate::emit::cpp::templates::cpp_unit_part_f(&pc_ph.title_p, &pc_ph.path_p, &pc_ph.ns_p, &pc_ph.defs_p))), &Text::lit("\n\n"));
    (Text::from(format!("src/unit_{}.cpp", &(k_p0 + &Nat::from(1u32)))), crate::emit::cpp::templates::cpp_unit_f(&title_p6, &includes_p4, &parts_p7))
}

/// ```prism
/// let dummyPiece
/// ```
pub fn dummy_piece_p() -> Piece {
    Piece { title_p: Text::lit(""), prism_p: Text::lit(""), path_p: Text::lit(""), ns_p: Text::lit(""), needs_p: Array::new(), defs_p: Text::lit("") }
}

/// ```prism
/// AllProgramsCpp: fn Model -> [ProgDef]
/// ```
pub fn all_programs_cpp_f(model_p0: &crate::lower::model::Model) -> Array<crate::lower::model::ProgDef> {
    match &model_p0.root_o {
        Some(r_p1) => if crate::prelude::fold(&model_p0.programs_p, &false, &(|f_p2: &bool, p_p3: &crate::lower::model::ProgDef| *f_p2 || (&p_p3.name_p == &r_p1.name_p))) {
            model_p0.programs_p.clone()
        } else {
            crate::prelude::push(&model_p0.programs_p, r_p1)
        },
        None => model_p0.programs_p.clone(),
    }
}

/// ```prism
/// OrderValues: unbounded fn [ValueDecl], (Text ==> Bool), [Text] -> [Text]
/// ```
pub fn order_values_f(left_p0: &Array<crate::emit::cpp::items::ValueDecl>, done_p1: &Map<Text, bool>, acc_p2: &Array<Text>) -> Array<Text> {
    let ready_p3 = crate::prelude::filter(left_p0, &(|v_p4: &crate::emit::cpp::items::ValueDecl| crate::prelude::fold(&v_p4.deps_p, &true, &(|ok_p5: &bool, d_p6: &Text| *ok_p5 && ((d_p6 == &v_p4.path_p) || declared_f(done_p1, d_p6))))));
    if &crate::prelude::len(left_p0) == &Nat::from(0u32) {
        acc_p2.clone()
    } else {
        if &crate::prelude::len(&ready_p3) == &Nat::from(0u32) {
            crate::prelude::append(acc_p2, &crate::prelude::each(left_p0, &(|v_p7: &crate::emit::cpp::items::ValueDecl| v_p7.text_p.clone())))
        } else {
            {
                let later_p8 = crate::prelude::filter(left_p0, &(|v_pa: &crate::emit::cpp::items::ValueDecl| !crate::prelude::fold(&v_pa.deps_p, &true, &(|ok_pb: &bool, d_pc: &Text| *ok_pb && ((d_pc == &v_pa.path_p) || declared_f(done_p1, d_pc))))));
                let done2_p9 = crate::prelude::fold(&ready_p3, done_p1, &(|m_pd: &Map<Text, bool>, v_pe: &crate::emit::cpp::items::ValueDecl| crate::prelude::insert(m_pd, &v_pe.path_p, &true)));
                order_values_f(&later_p8, &done2_p9, &crate::prelude::append(acc_p2, &crate::prelude::each(&ready_p3, &(|v_pf: &crate::emit::cpp::items::ValueDecl| v_pf.text_p.clone()))))
            }
        }
    }
}

/// The step machine of `OrderValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OrderValues: unbounded fn [ValueDecl], (Text ==> Bool), [Text] -> [Text]
/// ```
pub struct OrderValues {
    pub left_p0: Array<crate::emit::cpp::items::ValueDecl>,
    pub done_p1: Map<Text, bool>,
    pub acc_p2: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for OrderValues {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let left_p0 = &self.left_p0;
        let done_p1 = &self.done_p1;
        let acc_p2 = &self.acc_p2;
        let ready_p3 = crate::prelude::filter(left_p0, &(|v_p4: &crate::emit::cpp::items::ValueDecl| crate::prelude::fold(&v_p4.deps_p, &true, &(|ok_p5: &bool, d_p6: &Text| *ok_p5 && ((d_p6 == &v_p4.path_p) || declared_f(done_p1, d_p6))))));
        if &crate::prelude::len(left_p0) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished(acc_p2.clone())
        } else {
            if &crate::prelude::len(&ready_p3) == &Nat::from(0u32) {
                prism_rtl::Turn::Finished(crate::prelude::append(acc_p2, &crate::prelude::each(left_p0, &(|v_p7: &crate::emit::cpp::items::ValueDecl| v_p7.text_p.clone()))))
            } else {
                {
                    let later_p8 = crate::prelude::filter(left_p0, &(|v_pa: &crate::emit::cpp::items::ValueDecl| !crate::prelude::fold(&v_pa.deps_p, &true, &(|ok_pb: &bool, d_pc: &Text| *ok_pb && ((d_pc == &v_pa.path_p) || declared_f(done_p1, d_pc))))));
                    let done2_p9 = crate::prelude::fold(&ready_p3, done_p1, &(|m_pd: &Map<Text, bool>, v_pe: &crate::emit::cpp::items::ValueDecl| crate::prelude::insert(m_pd, &v_pe.path_p, &true)));
                    prism_rtl::Turn::More(Rc::new(OrderValues { left_p0: later_p8.clone(), done_p1: done2_p9.clone(), acc_p2: crate::prelude::append(acc_p2, &crate::prelude::each(&ready_p3, &(|v_pf: &crate::emit::cpp::items::ValueDecl| v_pf.text_p.clone()))) }))
                }
            }
        }
    }
}

/// `Start OrderValues, x`: what the function value is when passed to `@Run`.
pub fn start_order_values_f(left_p0: Array<crate::emit::cpp::items::ValueDecl>, done_p1: Map<Text, bool>, acc_p2: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(OrderValues { left_p0, done_p1, acc_p2 })
}

/// ```prism
/// Declared: fn (Text ==> Bool), Text -> Bool
/// ```
pub fn declared_f(done_p0: &Map<Text, bool>, d_p1: &Text) -> bool {
    match crate::prelude::get(done_p0, d_p1) {
        Some(b_p2) => b_p2,
        None => true,
    }
}
