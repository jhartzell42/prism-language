//! The module `Emit.Cpp.Program`, from `target/bootstrap/src/prismc/emit/cpp/program.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `Piece`:
///
/// ```prism
/// type Piece = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Piece {
    pub title_p: crate::prelude::Text,
    pub prism_p: crate::prelude::Text,
    pub path_p: crate::prelude::Text,
    pub ns_p: crate::prelude::Text,
    pub needs_p: crate::prelude::Array<crate::prelude::Text>,
    pub defs_p: crate::prelude::Text,
}

impl crate::prelude::Show for Piece {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Piece", &[("title", &self.title_p), ("prism", &self.prism_p), ("path", &self.path_p), ("ns", &self.ns_p), ("needs", &self.needs_p), ("defs", &self.defs_p)]);
    }
}

impl crate::prelude::ToPod for Piece {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Piece", vec![("title", self.title_p.to_pod()), ("prism", self.prism_p.to_pod()), ("path", self.path_p.to_pod()), ("ns", self.ns_p.to_pod()), ("needs", self.needs_p.to_pod()), ("defs", self.defs_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Piece {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Piece { title_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "title")?)?, prism_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "prism")?)?, path_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "path")?)?, ns_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "ns")?)?, needs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "needs")?)?, defs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "defs")?)? })
    }
}

/// ```prism
/// NodeParts: unbounded fn Cp, NodeDef -> Parts
/// ```
pub fn node_parts_f(cp_p0: &crate::emit::cpp::Cp, n_p1: &crate::lower::model::NodeDef) -> crate::emit::cpp::items::Parts {
    let ncp_p2 = crate::emit::cpp::with_fields_f(cp_p0, &crate::prelude::each(&n_p1.fields_p, &(|(f_pu, t_pv, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| (f_pu.clone(), t_pv.clone()))));
    let base_p3 = if (&n_p1.row_kind_p == &crate::lower::model::RowKind::NotARow) && (&crate::prelude::len(&n_p1.hosted_p) == &crate::prelude::Nat::from(0u32)) {
        crate::prelude::Text::lit("crate::prelude::Node")
    } else {
        crate::prelude::Text::lit("crate::prelude::Row")
    };
    let fields_p4 = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(n_p1.fields_p.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (f_p10, t_p11, doc_p12) = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), t_p11.clone()), move |cpp_type_f_1402: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{}{} {};", &crate::emit::cpp::items::cpp_doc_f(&doc_p12), &mutable_of_f(&t_p11), &cpp_type_f_1402, &crate::emit::cpp::field_id_f(&f_p10)))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    })), &crate::prelude::Text::lit("\n"));
    let consts_p5 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&n_p1.consts_p, &(|(c_p13, h_p14, doc_p15): &(crate::prelude::Text, crate::prelude::Nat, crate::prelude::Text)| crate::prelude::Text::from(format!("{}static constexpr ::std::uint32_t {} = {};", &crate::emit::cpp::items::cpp_doc_f(&crate::prelude::Text::from(format!("The {}.", doc_p15))), c_p13, h_p14)))), &crate::prelude::Text::lit("\n"));
    let ctor_params_p6 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("crate::prelude::Path path")]), &crate::prelude::run_to_end(crate::prelude::each_job(n_p1.fields_p.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (f_p16, t_p17, _) = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), t_p17.clone()), move |cpp_type_f_1672: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {}", &cpp_type_f_1672, &crate::emit::cpp::field_id_f(&f_p16)))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    }))), &crate::prelude::Text::lit(", "));
    let ctor_inits_p7 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("path(::std::move(path))")]), &crate::prelude::each(&n_p1.fields_p, &(|(f_p18, _, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| crate::prelude::Text::from(format!("{}(::std::move({}))", &crate::emit::cpp::field_id_f(f_p18), &crate::emit::cpp::field_id_f(f_p18)))))), &crate::prelude::Text::lit(", "));
    let params_p8 = crate::prelude::concat(&crate::prelude::run_to_end(crate::prelude::each_job(n_p1.params_p.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (p_p19, t_p1a) = p0;
                crate::prelude::call_then(crate::emit::cpp::expr::start_param_type_f(cp_p0xy.clone(), t_p1a.clone()), move |param_type_f_1915: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {}, ", &param_type_f_1915, &p_p19))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    })));
    let ret_p9 = if n_p1.fallible_p {
        crate::prelude::Text::from(format!("crate::prelude::Result<::prism_rtl::Rc<{}>>", &n_p1.name_p))
    } else {
        crate::prelude::Text::from(format!("::prism_rtl::Rc<{}>", &n_p1.name_p))
    };
    let make_decl_pa = crate::prelude::Text::from(format!("static {} make(crate::prelude::Path path, {}crate::prelude::Cx& cx);", &ret_p9, &params_p8));
    let method_decls_pb = crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::append(&n_p1.methods_p, &n_p1.hosted_p), {
        let ncp_p2x = ncp_p2.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::MethDef| {
            let ncp_p2xy = ncp_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_p1b = p0;
                crate::prelude::call_then(start_method_sig_f(ncp_p2xy.clone(), m_p1b.clone(), crate::prelude::Text::lit("")), move |method_sig_f_2218: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{};", &method_sig_f_2218))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::MethDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    }));
    let builder_decls_pc = crate::prelude::append(&crate::prelude::each(&n_p1.builders_p, &(|b_p1c: &crate::lower::model::ForDef| crate::prelude::Text::from(format!("crate::prelude::Done {}_build(crate::prelude::Cx& cx);", &b_p1c.name_p)))), &crate::prelude::each(&n_p1.gens_p, &(|g_p1d: &crate::lower::model::GenDef| crate::prelude::Text::from(format!("crate::prelude::Done {}_build(crate::prelude::Cx& cx);", &g_p1d.name_p)))));
    let hook_decls_pd = crate::prelude::each(&n_p1.hooks_p, &(|(h_p1e, _): &(crate::prelude::Text, crate::prelude::Array<crate::lower::model::Do>)| crate::prelude::Text::from(format!("{} override;", &hook_sig_f(h_p1e, &crate::prelude::Text::lit(""))))));
    let answer_decl_pe = if &crate::prelude::len(&n_p1.answers_p) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Array::new()
    } else {
        crate::prelude::Array::from(vec![crate::prelude::Text::lit("crate::prelude::Done answer(::std::span<const crate::prelude::Segment> at, const crate::prelude::Pod& v, crate::prelude::Cx& cx) override;")])
    };
    let row_decl_pf = if &n_p1.row_kind_p == &crate::lower::model::RowKind::NotARow {
        crate::prelude::Array::new()
    } else {
        crate::prelude::Array::from(vec![crate::prelude::Text::lit("void leave_row(crate::prelude::Cx& cx) override;")])
    };
    let decls_pg = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![make_decl_pa.clone()]), &method_decls_pb), &builder_decls_pc), &hook_decls_pd), &answer_decl_pe), &row_decl_pf), &crate::prelude::Text::lit("\n"));
    let doc_ph = crate::emit::cpp::items::cpp_source_doc_f(&crate::prelude::Text::from(format!("`{}`: a node of its own (claude/backend.md, \"A widget block\").", &n_p1.prism_p)), &n_p1.doc_p);
    let decl_pi = crate::emit::cpp::templates::items::node_class_f(&doc_ph, &n_p1.name_p, &base_p3, &fields_p4, &consts_p5, &crate::prelude::Text::from(format!("{}({}) : {} {{}}", &n_p1.name_p, &ctor_params_p6, &ctor_inits_p7)), &decls_pg);
    let by_field_pj = crate::prelude::each(&n_p1.fields_p, &(|(f_p1f, _, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| crate::prelude::or(&crate::prelude::fold(&n_p1.inits_p, &::std::option::Option::None, &(|found_o1g: &::std::option::Option<crate::lower::model::Ex>, (g_p1h, v_p1i): &(crate::prelude::Text, crate::lower::model::Ex)| if g_p1h == f_p1f {
        ::std::option::Option::Some(v_p1i.clone())
    } else {
        found_o1g.clone()
    })), &crate::lower::model::Ex::XVar(f_p1f.clone()))));
    let (lets_text_p1j, lcp_p1k) = crate::emit::cpp::stmts::cpp_statements_cp_f(&ncp_p2, &n_p1.lets_p);
    let args_pk = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("path")]), &crate::prelude::run_to_end(crate::prelude::each_job(by_field_pj.clone(), {
        let lcp_p1kx = lcp_p1k.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::Ex| {
            let lcp_p1kxy = lcp_p1kx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let v_p1l = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::cpp::expr::CppExpr { cp_p0: lcp_p1kxy.clone(), x_p1: v_p1l.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    }))), &crate::prelude::Text::lit(", "));
    let tail_pl = if n_p1.fallible_p {
        crate::prelude::Text::lit("return node;")
    } else {
        crate::prelude::Text::lit("return node;")
    };
    let make_pm = crate::emit::cpp::templates::items::node_make_f(&n_p1.name_p, &crate::prelude::Text::from(format!("{} {}::make(crate::prelude::Path path, {}crate::prelude::Cx& cx)", &ret_p9, &n_p1.name_p, &params_p8)), &lets_text_p1j, &args_pk, &crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::Array::from(vec![crate::emit::cpp::stmts::cpp_statements_f(&crate::emit::cpp::stmts::pointing_f(&lcp_p1k, &crate::prelude::Text::lit("node")), &n_p1.build_p), tail_pl.clone()]), &(|s_p1m: &crate::prelude::Text| s_p1m != &crate::prelude::Text::lit(""))), &crate::prelude::Text::lit("\n")));
    let methods_pn = crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::append(&n_p1.methods_p, &n_p1.hosted_p), {
        let ncp_p2x = ncp_p2.clone();
        let n_p1x = n_p1.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::MethDef| {
            let ncp_p2xy = ncp_p2x.clone();
            let n_p1xy = n_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_p1n = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(MethodDef { cp_p0: ncp_p2xy.clone(), owner_p1: n_p1xy.name_p.clone(), m_p2: m_p1n.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::MethDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    }));
    let builders_po = crate::prelude::append(&crate::prelude::run_to_end(crate::prelude::each_job(n_p1.builders_p.clone(), {
        let ncp_p2x = ncp_p2.clone();
        let n_p1x = n_p1.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::ForDef| {
            let ncp_p2xy = ncp_p2x.clone();
            let n_p1xy = n_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let b_p1o = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(ForBuildCpp { cp_p0: ncp_p2xy.clone(), owner_p1: n_p1xy.name_p.clone(), b_p2: b_p1o.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::ForDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    })), &crate::prelude::run_to_end(crate::prelude::each_job(n_p1.gens_p.clone(), {
        let ncp_p2x = ncp_p2.clone();
        let n_p1x = n_p1.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::GenDef| {
            let ncp_p2xy = ncp_p2x.clone();
            let n_p1xy = n_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let g_p1p = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(GenBuildCpp { cp_p0: ncp_p2xy.clone(), owner_p1: n_p1xy.name_p.clone(), gd_p2: g_p1p.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::GenDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    })));
    let hooks_pp = crate::prelude::run_to_end(crate::prelude::each_job(n_p1.hooks_p.clone(), {
        let n_p1x = n_p1.clone();
        let ncp_p2x = ncp_p2.clone();
        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::prelude::Array<crate::lower::model::Do>)| {
            let n_p1xy = n_p1x.clone();
            let ncp_p2xy = ncp_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (h_p1q, body_p1r) = p0;
                crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_statements_f(ncp_p2xy.clone(), body_p1r.clone()), move |cpp_statements_f_4135: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &hook_sig_f(&h_p1q, &crate::prelude::Text::from(format!("{}::", &n_p1xy.name_p))), &crate::prelude::Text::from(format!("{}\nreturn {{}};", &cpp_statements_f_4135)))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::prelude::Array<crate::lower::model::Do>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    }));
    let answer_pq = if &crate::prelude::len(&n_p1.answers_p) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Array::new()
    } else {
        crate::prelude::Array::from(vec![answer_def_cpp_f(&ncp_p2, n_p1)])
    };
    let leaving_pr = if &n_p1.row_kind_p == &crate::lower::model::RowKind::NotARow {
        crate::prelude::Array::new()
    } else {
        crate::prelude::Array::from(vec![row_leaving_f(&ncp_p2, n_p1)])
    };
    let defs_ps = crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![make_pm.clone()]), &methods_pn), &builders_po), &hooks_pp), &answer_pq), &leaving_pr);
    let own_pt = crate::emit::cpp::items::Parts { forward_p: crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("class {};", &n_p1.name_p))]), values_p: crate::prelude::Array::new(), protos_p: crate::prelude::Array::new(), classes_p: crate::prelude::Array::from(vec![decl_pi.clone()]), outer_p: crate::prelude::Array::new(), generic_p: crate::prelude::Array::new(), defs_p: defs_ps.clone() };
    own_pt.clone()
}

/// The step machine of `NodeParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NodeParts: unbounded fn Cp, NodeDef -> Parts
/// ```
pub struct NodeParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub n_p1: crate::lower::model::NodeDef,
}

impl ::prism_rtl::Job<crate::emit::cpp::items::Parts> for NodeParts {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::emit::cpp::items::Parts> {
        let cp_p0 = &self.cp_p0;
        let n_p1 = &self.n_p1;
        let ncp_p2 = crate::emit::cpp::with_fields_f(cp_p0, &crate::prelude::each(&n_p1.fields_p, &(|(f_pu, t_pv, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| (f_pu.clone(), t_pv.clone()))));
        let base_p3 = if (&n_p1.row_kind_p == &crate::lower::model::RowKind::NotARow) && (&crate::prelude::len(&n_p1.hosted_p) == &crate::prelude::Nat::from(0u32)) {
            crate::prelude::Text::lit("crate::prelude::Node")
        } else {
            crate::prelude::Text::lit("crate::prelude::Row")
        };
        let cp_p0x = cp_p0.clone();
        let n_p1x = n_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(n_p1x.fields_p.clone(), {
            let cp_p0xx = cp_p0x.clone();
            ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (f_p10, t_p11, doc_p12) = p0;
                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), t_p11.clone()), move |cpp_type_f_1402: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{}{} {};", &crate::emit::cpp::items::cpp_doc_f(&doc_p12), &mutable_of_f(&t_p11), &cpp_type_f_1402, &crate::emit::cpp::field_id_f(&f_p10)))))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
        }), move |each_1343: crate::prelude::Array<crate::prelude::Text>| {
            let fields_p4 = crate::syntax::lexer::chars::join_f(&each_1343, &crate::prelude::Text::lit("\n"));
            let consts_p5 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&n_p1x.consts_p, &(|(c_p13, h_p14, doc_p15): &(crate::prelude::Text, crate::prelude::Nat, crate::prelude::Text)| crate::prelude::Text::from(format!("{}static constexpr ::std::uint32_t {} = {};", &crate::emit::cpp::items::cpp_doc_f(&crate::prelude::Text::from(format!("The {}.", doc_p15))), c_p13, h_p14)))), &crate::prelude::Text::lit("\n"));
            crate::prelude::call_value(crate::prelude::each_job(n_p1x.fields_p.clone(), {
                let cp_p0xx = cp_p0x.clone();
                ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| {
                    let cp_p0xxy = cp_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (f_p16, t_p17, _) = p0;
                        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), t_p17.clone()), move |cpp_type_f_1672: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {}", &cpp_type_f_1672, &crate::emit::cpp::field_id_f(&f_p16)))))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            }), move |each_1635: crate::prelude::Array<crate::prelude::Text>| {
                let ctor_params_p6 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("crate::prelude::Path path")]), &each_1635), &crate::prelude::Text::lit(", "));
                let ctor_inits_p7 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("path(::std::move(path))")]), &crate::prelude::each(&n_p1x.fields_p, &(|(f_p18, _, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| crate::prelude::Text::from(format!("{}(::std::move({}))", &crate::emit::cpp::field_id_f(f_p18), &crate::emit::cpp::field_id_f(f_p18)))))), &crate::prelude::Text::lit(", "));
                crate::prelude::call_value(crate::prelude::each_job(n_p1x.params_p.clone(), {
                    let cp_p0xx = cp_p0x.clone();
                    ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| {
                        let cp_p0xxy = cp_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (p_p19, t_p1a) = p0;
                            crate::prelude::call_then(crate::emit::cpp::expr::start_param_type_f(cp_p0xxy.clone(), t_p1a.clone()), move |param_type_f_1915: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {}, ", &param_type_f_1915, &p_p19))))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                }), move |each_1886: crate::prelude::Array<crate::prelude::Text>| {
                    let params_p8 = crate::prelude::concat(&each_1886);
                    let ret_p9 = if n_p1x.fallible_p {
                        crate::prelude::Text::from(format!("crate::prelude::Result<::prism_rtl::Rc<{}>>", &n_p1x.name_p))
                    } else {
                        crate::prelude::Text::from(format!("::prism_rtl::Rc<{}>", &n_p1x.name_p))
                    };
                    let make_decl_pa = crate::prelude::Text::from(format!("static {} make(crate::prelude::Path path, {}crate::prelude::Cx& cx);", &ret_p9, &params_p8));
                    crate::prelude::call_value(crate::prelude::each_job(crate::prelude::append(&n_p1x.methods_p, &n_p1x.hosted_p), {
                        let ncp_p2x = ncp_p2.clone();
                        ::std::rc::Rc::new(move |p0: crate::lower::model::MethDef| {
                            let ncp_p2xy = ncp_p2x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let m_p1b = p0;
                                crate::prelude::call_then(start_method_sig_f(ncp_p2xy.clone(), m_p1b.clone(), crate::prelude::Text::lit("")), move |method_sig_f_2218: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{};", &method_sig_f_2218))))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::MethDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                    }), move |each_2176: crate::prelude::Array<crate::prelude::Text>| {
                        let method_decls_pb = each_2176;
                        let builder_decls_pc = crate::prelude::append(&crate::prelude::each(&n_p1x.builders_p, &(|b_p1c: &crate::lower::model::ForDef| crate::prelude::Text::from(format!("crate::prelude::Done {}_build(crate::prelude::Cx& cx);", &b_p1c.name_p)))), &crate::prelude::each(&n_p1x.gens_p, &(|g_p1d: &crate::lower::model::GenDef| crate::prelude::Text::from(format!("crate::prelude::Done {}_build(crate::prelude::Cx& cx);", &g_p1d.name_p)))));
                        let hook_decls_pd = crate::prelude::each(&n_p1x.hooks_p, &(|(h_p1e, _): &(crate::prelude::Text, crate::prelude::Array<crate::lower::model::Do>)| crate::prelude::Text::from(format!("{} override;", &hook_sig_f(h_p1e, &crate::prelude::Text::lit(""))))));
                        let answer_decl_pe = if &crate::prelude::len(&n_p1x.answers_p) == &crate::prelude::Nat::from(0u32) {
                            crate::prelude::Array::new()
                        } else {
                            crate::prelude::Array::from(vec![crate::prelude::Text::lit("crate::prelude::Done answer(::std::span<const crate::prelude::Segment> at, const crate::prelude::Pod& v, crate::prelude::Cx& cx) override;")])
                        };
                        let row_decl_pf = if &n_p1x.row_kind_p == &crate::lower::model::RowKind::NotARow {
                            crate::prelude::Array::new()
                        } else {
                            crate::prelude::Array::from(vec![crate::prelude::Text::lit("void leave_row(crate::prelude::Cx& cx) override;")])
                        };
                        let decls_pg = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![make_decl_pa.clone()]), &method_decls_pb), &builder_decls_pc), &hook_decls_pd), &answer_decl_pe), &row_decl_pf), &crate::prelude::Text::lit("\n"));
                        let doc_ph = crate::emit::cpp::items::cpp_source_doc_f(&crate::prelude::Text::from(format!("`{}`: a node of its own (claude/backend.md, \"A widget block\").", &n_p1x.prism_p)), &n_p1x.doc_p);
                        let decl_pi = crate::emit::cpp::templates::items::node_class_f(&doc_ph, &n_p1x.name_p, &base_p3, &fields_p4, &consts_p5, &crate::prelude::Text::from(format!("{}({}) : {} {{}}", &n_p1x.name_p, &ctor_params_p6, &ctor_inits_p7)), &decls_pg);
                        let by_field_pj = crate::prelude::each(&n_p1x.fields_p, &(|(f_p1f, _, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| crate::prelude::or(&crate::prelude::fold(&n_p1x.inits_p, &::std::option::Option::None, &(|found_o1g: &::std::option::Option<crate::lower::model::Ex>, (g_p1h, v_p1i): &(crate::prelude::Text, crate::lower::model::Ex)| if g_p1h == f_p1f {
                            ::std::option::Option::Some(v_p1i.clone())
                        } else {
                            found_o1g.clone()
                        })), &crate::lower::model::Ex::XVar(f_p1f.clone()))));
                        crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_statements_cp_f(ncp_p2.clone(), n_p1x.lets_p.clone()), move |cpp_statements_cp_f_3435: (crate::prelude::Text, crate::emit::cpp::Cp)| {
                            let (lets_text_p1j, lcp_p1k) = cpp_statements_cp_f_3435;
                            crate::prelude::call_value(crate::prelude::each_job(by_field_pj.clone(), {
                                let lcp_p1kx = lcp_p1k.clone();
                                ::std::rc::Rc::new(move |p0: crate::lower::model::Ex| {
                                    let lcp_p1kxy = lcp_p1kx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let v_p1l = p0;
                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::cpp::expr::CppExpr { cp_p0: lcp_p1kxy.clone(), x_p1: v_p1l.clone() }))
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                            }), move |each_3504: crate::prelude::Array<crate::prelude::Text>| {
                                let args_pk = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("path")]), &each_3504), &crate::prelude::Text::lit(", "));
                                let tail_pl = if n_p1x.fallible_p {
                                    crate::prelude::Text::lit("return node;")
                                } else {
                                    crate::prelude::Text::lit("return node;")
                                };
                                crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_statements_f(crate::emit::cpp::stmts::pointing_f(&lcp_p1k, &crate::prelude::Text::lit("node")), n_p1x.build_p.clone()), move |cpp_statements_f_3760: crate::prelude::Text| {
                                    let make_pm = crate::emit::cpp::templates::items::node_make_f(&n_p1x.name_p, &crate::prelude::Text::from(format!("{} {}::make(crate::prelude::Path path, {}crate::prelude::Cx& cx)", &ret_p9, &n_p1x.name_p, &params_p8)), &lets_text_p1j, &args_pk, &crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::Array::from(vec![cpp_statements_f_3760, tail_pl.clone()]), &(|s_p1m: &crate::prelude::Text| s_p1m != &crate::prelude::Text::lit(""))), &crate::prelude::Text::lit("\n")));
                                    crate::prelude::call_value(crate::prelude::each_job(crate::prelude::append(&n_p1x.methods_p, &n_p1x.hosted_p), {
                                        let ncp_p2x = ncp_p2.clone();
                                        let n_p1xx = n_p1x.clone();
                                        ::std::rc::Rc::new(move |p0: crate::lower::model::MethDef| {
                                            let ncp_p2xy = ncp_p2x.clone();
                                            let n_p1xxy = n_p1xx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let m_p1n = p0;
                                                ::prism_rtl::Turn::More(::std::rc::Rc::new(MethodDef { cp_p0: ncp_p2xy.clone(), owner_p1: n_p1xxy.name_p.clone(), m_p2: m_p1n.clone() }))
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::MethDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                                    }), move |each_3855: crate::prelude::Array<crate::prelude::Text>| {
                                        let methods_pn = each_3855;
                                        crate::prelude::call_value(crate::prelude::each_job(n_p1x.builders_p.clone(), {
                                            let ncp_p2x = ncp_p2.clone();
                                            let n_p1xx = n_p1x.clone();
                                            ::std::rc::Rc::new(move |p0: crate::lower::model::ForDef| {
                                                let ncp_p2xy = ncp_p2x.clone();
                                                let n_p1xxy = n_p1xx.clone();
                                                crate::prelude::entered(crate::prelude::once_job(move || {
                                                    let b_p1o = p0;
                                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ForBuildCpp { cp_p0: ncp_p2xy.clone(), owner_p1: n_p1xxy.name_p.clone(), b_p2: b_p1o.clone() }))
                                                }))
                                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::ForDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                                        }), move |each_3947: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_value(crate::prelude::each_job(n_p1x.gens_p.clone(), {
                                            let ncp_p2x = ncp_p2.clone();
                                            let n_p1xx = n_p1x.clone();
                                            ::std::rc::Rc::new(move |p0: crate::lower::model::GenDef| {
                                                let ncp_p2xy = ncp_p2x.clone();
                                                let n_p1xxy = n_p1xx.clone();
                                                crate::prelude::entered(crate::prelude::once_job(move || {
                                                    let g_p1p = p0;
                                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(GenBuildCpp { cp_p0: ncp_p2xy.clone(), owner_p1: n_p1xxy.name_p.clone(), gd_p2: g_p1p.clone() }))
                                                }))
                                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::GenDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                                        }), move |each_3999: crate::prelude::Array<crate::prelude::Text>| {
                                            let builders_po = crate::prelude::append(&each_3947, &each_3999);
                                            crate::prelude::call_value(crate::prelude::each_job(n_p1x.hooks_p.clone(), {
                                                let n_p1xx = n_p1x.clone();
                                                let ncp_p2x = ncp_p2.clone();
                                                ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::prelude::Array<crate::lower::model::Do>)| {
                                                    let n_p1xxy = n_p1xx.clone();
                                                    let ncp_p2xy = ncp_p2x.clone();
                                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                                        let (h_p1q, body_p1r) = p0;
                                                        crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_statements_f(ncp_p2xy.clone(), body_p1r.clone()), move |cpp_statements_f_4135: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &hook_sig_f(&h_p1q, &crate::prelude::Text::from(format!("{}::", &n_p1xxy.name_p))), &crate::prelude::Text::from(format!("{}\nreturn {{}};", &cpp_statements_f_4135)))))
                                                    }))
                                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::prelude::Array<crate::lower::model::Do>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                                            }), move |each_4061: crate::prelude::Array<crate::prelude::Text>| {
                                                let hooks_pp = each_4061;
                                                let builders_poz = builders_po.clone();
                                                let decl_piz = decl_pi.clone();
                                                let hooks_ppz = hooks_pp.clone();
                                                let make_pmz = make_pm.clone();
                                                let methods_pnz = methods_pn.clone();
                                                let n_p1xz = n_p1x.clone();
                                                let ncp_p2z = ncp_p2.clone();
                                                let k_let4179 = move |v4179: crate::prelude::Array<crate::prelude::Text>| {
                                                    let answer_pq = v4179;
                                                    let answer_pqz = answer_pq.clone();
                                                    let builders_pozz = builders_poz.clone();
                                                    let decl_pizz = decl_piz.clone();
                                                    let hooks_ppzz = hooks_ppz.clone();
                                                    let make_pmzz = make_pmz.clone();
                                                    let methods_pnzz = methods_pnz.clone();
                                                    let n_p1xzz = n_p1xz.clone();
                                                    let k_let4258 = move |v4258: crate::prelude::Array<crate::prelude::Text>| {
                                                        let leaving_pr = v4258;
                                                        let defs_ps = crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![make_pmzz.clone()]), &methods_pnzz), &builders_pozz), &hooks_ppzz), &answer_pqz), &leaving_pr);
                                                        let own_pt = crate::emit::cpp::items::Parts { forward_p: crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("class {};", &n_p1xzz.name_p))]), values_p: crate::prelude::Array::new(), protos_p: crate::prelude::Array::new(), classes_p: crate::prelude::Array::from(vec![decl_pizz.clone()]), outer_p: crate::prelude::Array::new(), generic_p: crate::prelude::Array::new(), defs_p: defs_ps.clone() };
                                                        ::prism_rtl::Turn::Finished(own_pt.clone())
                                                    };
                                                    if &n_p1xz.row_kind_p == &crate::lower::model::RowKind::NotARow {
                                                        k_let4258(crate::prelude::Array::new())
                                                    } else {
                                                        crate::prelude::call_then(start_row_leaving_f(ncp_p2z.clone(), n_p1xz.clone()), move |row_leaving_f_4311: crate::prelude::Text| k_let4258(crate::prelude::Array::from(vec![row_leaving_f_4311])))
                                                    }
                                                };
                                                if &crate::prelude::len(&n_p1x.answers_p) == &crate::prelude::Nat::from(0u32) {
                                                    k_let4179(crate::prelude::Array::new())
                                                } else {
                                                    crate::prelude::call_then(start_answer_def_cpp_f(ncp_p2.clone(), n_p1x.clone()), move |answer_def_cpp_f_4231: crate::prelude::Text| k_let4179(crate::prelude::Array::from(vec![answer_def_cpp_f_4231])))
                                                }
                                            })
                                        }))
                                    })
                                })
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start NodeParts, x`: what the function value is when passed to `@Run`.
pub fn start_node_parts_f(cp_p0: crate::emit::cpp::Cp, n_p1: crate::lower::model::NodeDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::emit::cpp::items::Parts>> {
    ::std::rc::Rc::new(NodeParts { cp_p0, n_p1 })
}

/// ```prism
/// MethodSig: unbounded fn Cp, MethDef, Text -> Text
/// ```
pub fn method_sig_f(cp_p0: &crate::emit::cpp::Cp, m_p1: &crate::lower::model::MethDef, owner_p2: &crate::prelude::Text) -> crate::prelude::Text {
    let cx_p3 = match &m_p1.cx_p {
        crate::lower::model::CxArg::CxMut => crate::prelude::Array::from(vec![crate::prelude::Text::lit("crate::prelude::Cx& cx")]),
        crate::lower::model::CxArg::CxRef => crate::prelude::Array::from(vec![crate::prelude::Text::lit("const crate::prelude::Cx& cx")]),
        crate::lower::model::CxArg::CxNone => crate::prelude::Array::new(),
    };
    let params_p4 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::run_to_end(crate::prelude::each_job(m_p1.params_p.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (p_p6, t_p7) = p0;
                crate::prelude::call_then(crate::emit::cpp::expr::start_param_type_f(cp_p0xy.clone(), t_p7.clone()), move |param_type_f_4860: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {}", &param_type_f_4860, &p_p6))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    })), &cx_p3), &crate::prelude::Text::lit(", "));
    let constness_p5 = if &m_p1.recv_p == &crate::lower::model::Recv::RecvRef {
        crate::prelude::Text::lit(" const")
    } else {
        crate::prelude::Text::lit("")
    };
    crate::prelude::Text::from(format!("{} {}{}({}){}", &crate::emit::cpp::cpp_type_f(cp_p0, &m_p1.ret_p), owner_p2, &crate::emit::cpp::expr::node_method_name_f(cp_p0, &m_p1.name_p), &params_p4, &constness_p5))
}

/// The step machine of `MethodSig`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MethodSig: unbounded fn Cp, MethDef, Text -> Text
/// ```
pub struct MethodSig {
    pub cp_p0: crate::emit::cpp::Cp,
    pub m_p1: crate::lower::model::MethDef,
    pub owner_p2: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Text> for MethodSig {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let m_p1 = &self.m_p1;
        let owner_p2 = &self.owner_p2;
        let cx_p3 = match &m_p1.cx_p {
            crate::lower::model::CxArg::CxMut => crate::prelude::Array::from(vec![crate::prelude::Text::lit("crate::prelude::Cx& cx")]),
            crate::lower::model::CxArg::CxRef => crate::prelude::Array::from(vec![crate::prelude::Text::lit("const crate::prelude::Cx& cx")]),
            crate::lower::model::CxArg::CxNone => crate::prelude::Array::new(),
        };
        let cp_p0x = cp_p0.clone();
        let m_p1x = m_p1.clone();
        let owner_p2x = owner_p2.clone();
        crate::prelude::call_value(crate::prelude::each_job(m_p1x.params_p.clone(), {
            let cp_p0xx = cp_p0x.clone();
            ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (p_p6, t_p7) = p0;
                    crate::prelude::call_then(crate::emit::cpp::expr::start_param_type_f(cp_p0xxy.clone(), t_p7.clone()), move |param_type_f_4860: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {}", &param_type_f_4860, &p_p6))))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
        }), move |each_4831: crate::prelude::Array<crate::prelude::Text>| {
            let params_p4 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&each_4831, &cx_p3), &crate::prelude::Text::lit(", "));
            let constness_p5 = if &m_p1x.recv_p == &crate::lower::model::Recv::RecvRef {
                crate::prelude::Text::lit(" const")
            } else {
                crate::prelude::Text::lit("")
            };
            crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), m_p1x.ret_p.clone()), move |cpp_type_f_4960: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {}{}({}){}", &cpp_type_f_4960, &owner_p2x, &crate::emit::cpp::expr::node_method_name_f(&cp_p0x, &m_p1x.name_p), &params_p4, &constness_p5))))
        })
    }
}

/// `Start MethodSig, x`: what the function value is when passed to `@Run`.
pub fn start_method_sig_f(cp_p0: crate::emit::cpp::Cp, m_p1: crate::lower::model::MethDef, owner_p2: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(MethodSig { cp_p0, m_p1, owner_p2 })
}

/// ```prism
/// MethodDef: unbounded fn Cp, Text, MethDef -> Text
/// ```
pub fn method_def_f(cp_p0: &crate::emit::cpp::Cp, owner_p1: &crate::prelude::Text, m_p2: &crate::lower::model::MethDef) -> crate::prelude::Text {
    let (st_p4, cp2_p5) = crate::emit::cpp::stmts::cpp_statements_cp_f(cp_p0, &m_p2.body_p);
    let body_p3 = if &m_p2.ret_p == &crate::lower::model::OutTy::OutUnit {
        crate::prelude::Text::from(format!("{}\nreturn crate::prelude::Unit{{}};", &st_p4))
    } else {
        if &crate::prelude::len(&m_p2.body_p) == &crate::prelude::Nat::from(0u32) {
            crate::emit::cpp::stmts::cpp_body_f(cp_p0, &m_p2.tail_p)
        } else {
            crate::prelude::Text::from(format!("{}\n{}", &st_p4, &crate::emit::cpp::stmts::cpp_body_f(&cp2_p5, &m_p2.tail_p)))
        }
    };
    crate::emit::cpp::templates::items::cpp_function_f(&crate::emit::cpp::items::cpp_doc_f(&m_p2.doc_p), &method_sig_f(cp_p0, m_p2, &crate::prelude::Text::from(format!("{}::", owner_p1))), &body_p3)
}

/// The step machine of `MethodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MethodDef: unbounded fn Cp, Text, MethDef -> Text
/// ```
pub struct MethodDef {
    pub cp_p0: crate::emit::cpp::Cp,
    pub owner_p1: crate::prelude::Text,
    pub m_p2: crate::lower::model::MethDef,
}

impl ::prism_rtl::Job<crate::prelude::Text> for MethodDef {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let owner_p1 = &self.owner_p1;
        let m_p2 = &self.m_p2;
        let cp_p0x = cp_p0.clone();
        let m_p2x = m_p2.clone();
        let owner_p1x = owner_p1.clone();
        crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_statements_cp_f(cp_p0x.clone(), m_p2x.body_p.clone()), move |cpp_statements_cp_f_5136: (crate::prelude::Text, crate::emit::cpp::Cp)| {
            let (st_p4, cp2_p5) = cpp_statements_cp_f_5136;
            let cp_p0xz = cp_p0x.clone();
            let m_p2xz = m_p2x.clone();
            let owner_p1xz = owner_p1x.clone();
            let k_let5167 = move |v5167: crate::prelude::Text| {
                let body_p3 = v5167;
                crate::prelude::call_then(start_method_sig_f(cp_p0xz.clone(), m_p2xz.clone(), crate::prelude::Text::from(format!("{}::", &owner_p1xz))), move |method_sig_f_5356: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function_f(&crate::emit::cpp::items::cpp_doc_f(&m_p2xz.doc_p), &method_sig_f_5356, &body_p3)))
            };
            if &m_p2x.ret_p == &crate::lower::model::OutTy::OutUnit {
                k_let5167(crate::prelude::Text::from(format!("{}\nreturn crate::prelude::Unit{{}};", &st_p4)))
            } else {
                if &crate::prelude::len(&m_p2x.body_p) == &crate::prelude::Nat::from(0u32) {
                    crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_body_f(cp_p0x.clone(), m_p2x.tail_p.clone()), move |cpp_body_f_5268: crate::prelude::Text| k_let5167(cpp_body_f_5268))
                } else {
                    crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_body_f(cp2_p5.clone(), m_p2x.tail_p.clone()), move |cpp_body_f_5301: crate::prelude::Text| k_let5167(crate::prelude::Text::from(format!("{}\n{}", &st_p4, &cpp_body_f_5301))))
                }
            }
        })
    }
}

/// `Start MethodDef, x`: what the function value is when passed to `@Run`.
pub fn start_method_def_f(cp_p0: crate::emit::cpp::Cp, owner_p1: crate::prelude::Text, m_p2: crate::lower::model::MethDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(MethodDef { cp_p0, owner_p1, m_p2 })
}

/// ```prism
/// HookSig: fn Text, Text -> Text
/// ```
pub fn hook_sig_f(text0: &crate::prelude::Text, owner_p0: &crate::prelude::Text) -> crate::prelude::Text {
    match text0 {
        c0_0 if (c0_0 == &crate::prelude::Text::lit("push")) => crate::prelude::Text::from(format!("crate::prelude::Done {}push(const crate::prelude::Pod& element, const crate::prelude::Pod& v, crate::prelude::Cx& cx)", owner_p0)),
        h_p1 => crate::prelude::Text::from(format!("crate::prelude::Done {}{}(crate::prelude::Cx& cx)", owner_p0, h_p1)),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// AnswerDefCpp: unbounded fn Cp, NodeDef -> Text
/// ```
pub fn answer_def_cpp_f(cp_p0: &crate::emit::cpp::Cp, n_p1: &crate::lower::model::NodeDef) -> crate::prelude::Text {
    let arms_p2 = crate::prelude::run_to_end(crate::prelude::each_job(n_p1.answers_p.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: (crate::lower::model::Pa, crate::lower::model::Ex)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (pat_p5, call_p6) = p0;
                crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_conds_f(cp_p0xy.clone(), pat_p5.clone(), crate::prelude::Text::lit("at")), move |pat_conds_f_5795: crate::prelude::Array<crate::prelude::Text>| {
                    let tests_p7 = pat_conds_f_5795;
                    crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_binds_f(cp_p0xy.clone(), pat_p5.clone(), crate::prelude::Text::lit("at")), move |pat_binds_f_5838: crate::prelude::Array<crate::prelude::Text>| {
                        let binds_p8 = pat_binds_f_5838;
                        crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0xy.clone(), call_p6.clone()), move |cpp_expr_f_5899: crate::prelude::Text| ::prism_rtl::Turn::Finished((tests_p7.clone(), crate::syntax::lexer::chars::join_f(&crate::prelude::push(&binds_p8, &crate::prelude::Text::from(format!("{};", &cpp_expr_f_5899))), &crate::prelude::Text::lit("\n")))))
                    })
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Pa, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)>>>
    }));
    let blocks_p3 = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&arms_p2)), &(|i_p9: &crate::prelude::Nat| {
        let (tests_pa, inner_pb) = crate::prelude::or(&crate::prelude::index(&arms_p2, i_p9), &(crate::prelude::Array::new(), crate::prelude::Text::lit("")));
        crate::emit::cpp::templates::items::block_f(&crate::prelude::Text::from(format!("{} ({})", &(if i_p9 == &crate::prelude::Nat::from(0u32) {
            crate::prelude::Text::lit("if")
        } else {
            crate::prelude::Text::lit("else if")
        }), &crate::emit::cpp::patterns::conds_f(&tests_pa))), &inner_pb)
    }));
    let seating_p4 = if crate::prelude::fold(&n_p1.methods_p, &false, &(|f_pc: &bool, m_pd: &crate::lower::model::MethDef| *f_pc || (&m_pd.name_p == &crate::prelude::Text::lit("seat")))) {
        crate::prelude::Text::lit("auto seated = crate::prelude::seated(at, [this](::std::uint32_t a) { return this->seat(a); });\nat = crate::prelude::segments_of(seated);\n")
    } else {
        crate::prelude::Text::lit("")
    };
    crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("crate::prelude::Done {}::answer(::std::span<const crate::prelude::Segment> at, const crate::prelude::Pod& v, crate::prelude::Cx& cx)", &n_p1.name_p)), &crate::prelude::Text::from(format!("{}{} else {{\n    return crate::prelude::unexpected(crate::prelude::Fault::answer(crate::prelude::str(\"no answering place at \", crate::prelude::path_of(at))));\n}}\nreturn {{}};", &seating_p4, &crate::syntax::lexer::chars::join_f(&blocks_p3, &crate::prelude::Text::lit(" ")))))
}

/// The step machine of `AnswerDefCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnswerDefCpp: unbounded fn Cp, NodeDef -> Text
/// ```
pub struct AnswerDefCpp {
    pub cp_p0: crate::emit::cpp::Cp,
    pub n_p1: crate::lower::model::NodeDef,
}

impl ::prism_rtl::Job<crate::prelude::Text> for AnswerDefCpp {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let n_p1 = &self.n_p1;
        let cp_p0x = cp_p0.clone();
        let n_p1x = n_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(n_p1x.answers_p.clone(), {
            let cp_p0xx = cp_p0x.clone();
            ::std::rc::Rc::new(move |p0: (crate::lower::model::Pa, crate::lower::model::Ex)| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (pat_p5, call_p6) = p0;
                    crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_conds_f(cp_p0xxy.clone(), pat_p5.clone(), crate::prelude::Text::lit("at")), move |pat_conds_f_5795: crate::prelude::Array<crate::prelude::Text>| {
                        let tests_p7 = pat_conds_f_5795;
                        crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_binds_f(cp_p0xxy.clone(), pat_p5.clone(), crate::prelude::Text::lit("at")), move |pat_binds_f_5838: crate::prelude::Array<crate::prelude::Text>| {
                            let binds_p8 = pat_binds_f_5838;
                            crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0xxy.clone(), call_p6.clone()), move |cpp_expr_f_5899: crate::prelude::Text| ::prism_rtl::Turn::Finished((tests_p7.clone(), crate::syntax::lexer::chars::join_f(&crate::prelude::push(&binds_p8, &crate::prelude::Text::from(format!("{};", &cpp_expr_f_5899))), &crate::prelude::Text::lit("\n")))))
                        })
                    })
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Pa, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)>>>
        }), move |each_5742: crate::prelude::Array<(crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)>| {
            let arms_p2 = each_5742;
            let blocks_p3 = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&arms_p2)), &(|i_p9: &crate::prelude::Nat| {
                let (tests_pa, inner_pb) = crate::prelude::or(&crate::prelude::index(&arms_p2, i_p9), &(crate::prelude::Array::new(), crate::prelude::Text::lit("")));
                crate::emit::cpp::templates::items::block_f(&crate::prelude::Text::from(format!("{} ({})", &(if i_p9 == &crate::prelude::Nat::from(0u32) {
                    crate::prelude::Text::lit("if")
                } else {
                    crate::prelude::Text::lit("else if")
                }), &crate::emit::cpp::patterns::conds_f(&tests_pa))), &inner_pb)
            }));
            let seating_p4 = if crate::prelude::fold(&n_p1x.methods_p, &false, &(|f_pc: &bool, m_pd: &crate::lower::model::MethDef| *f_pc || (&m_pd.name_p == &crate::prelude::Text::lit("seat")))) {
                crate::prelude::Text::lit("auto seated = crate::prelude::seated(at, [this](::std::uint32_t a) { return this->seat(a); });\nat = crate::prelude::segments_of(seated);\n")
            } else {
                crate::prelude::Text::lit("")
            };
            ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("crate::prelude::Done {}::answer(::std::span<const crate::prelude::Segment> at, const crate::prelude::Pod& v, crate::prelude::Cx& cx)", &n_p1x.name_p)), &crate::prelude::Text::from(format!("{}{} else {{\n    return crate::prelude::unexpected(crate::prelude::Fault::answer(crate::prelude::str(\"no answering place at \", crate::prelude::path_of(at))));\n}}\nreturn {{}};", &seating_p4, &crate::syntax::lexer::chars::join_f(&blocks_p3, &crate::prelude::Text::lit(" "))))))
        })
    }
}

/// `Start AnswerDefCpp, x`: what the function value is when passed to `@Run`.
pub fn start_answer_def_cpp_f(cp_p0: crate::emit::cpp::Cp, n_p1: crate::lower::model::NodeDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(AnswerDefCpp { cp_p0, n_p1 })
}

/// ```prism
/// RowLeaving: unbounded fn Cp, NodeDef -> Text
/// ```
pub fn row_leaving_f(cp_p0: &crate::emit::cpp::Cp, n_p1: &crate::lower::model::NodeDef) -> crate::prelude::Text {
    let kept_p2 = if &n_p1.row_kind_p == &crate::lower::model::RowKind::ForRow {
        crate::prelude::Array::from(vec![crate::prelude::Text::lit("this->left_entry = entry(cx);")])
    } else {
        crate::prelude::Array::new()
    };
    let unsubscribe_p3 = crate::prelude::each(&n_p1.subs_p, &(|(ev_p4, m_p5, _): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("if (auto p = parent.lock(); p && {}_sub) crate::prelude::deref(p->{}_port).unsubscribe(*::std::exchange({}_sub, ::std::nullopt));", m_p5, ev_p4, m_p5))));
    crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("void {}::leave_row(crate::prelude::Cx& cx)", &n_p1.name_p)), &crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::push(&kept_p2, &crate::prelude::Text::lit("remove_places(cx);")), &unsubscribe_p3), &crate::prelude::Text::lit("\n")))
}

/// The step machine of `RowLeaving`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowLeaving: unbounded fn Cp, NodeDef -> Text
/// ```
pub struct RowLeaving {
    pub cp_p0: crate::emit::cpp::Cp,
    pub n_p1: crate::lower::model::NodeDef,
}

impl ::prism_rtl::Job<crate::prelude::Text> for RowLeaving {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let n_p1 = &self.n_p1;
        let kept_p2 = if &n_p1.row_kind_p == &crate::lower::model::RowKind::ForRow {
            crate::prelude::Array::from(vec![crate::prelude::Text::lit("this->left_entry = entry(cx);")])
        } else {
            crate::prelude::Array::new()
        };
        let unsubscribe_p3 = crate::prelude::each(&n_p1.subs_p, &(|(ev_p4, m_p5, _): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("if (auto p = parent.lock(); p && {}_sub) crate::prelude::deref(p->{}_port).unsubscribe(*::std::exchange({}_sub, ::std::nullopt));", m_p5, ev_p4, m_p5))));
        ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("void {}::leave_row(crate::prelude::Cx& cx)", &n_p1.name_p)), &crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::push(&kept_p2, &crate::prelude::Text::lit("remove_places(cx);")), &unsubscribe_p3), &crate::prelude::Text::lit("\n"))))
    }
}

/// `Start RowLeaving, x`: what the function value is when passed to `@Run`.
pub fn start_row_leaving_f(cp_p0: crate::emit::cpp::Cp, n_p1: crate::lower::model::NodeDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(RowLeaving { cp_p0, n_p1 })
}

/// ```prism
/// ForBuildCpp: unbounded fn Cp, Text, ForDef -> Text
/// ```
pub fn for_build_cpp_f(cp_p0: &crate::emit::cpp::Cp, owner_p1: &crate::prelude::Text, b_p2: &crate::lower::model::ForDef) -> crate::prelude::Text {
    crate::emit::cpp::templates::items::for_build_template_f(owner_p1, &b_p2.name_p, &crate::emit::cpp::expr::cpp_expr_f(cp_p0, &b_p2.at_p), &crate::emit::cpp::cpp_type_f(cp_p0, &b_p2.key_ty_p), &crate::emit::cpp::cpp_type_f(cp_p0, &b_p2.value_ty_p), &crate::prelude::Text::from(format!("{}::make", &crate::emit::cpp::type_path_f(&crate::lower::model::runtime_path_f(&b_p2.row_node_p)))), &b_p2.source_p, &crate::emit::cpp::expr::cpp_expr_f(cp_p0, &b_p2.parent_p), &crate::prelude::concat(&crate::prelude::run_to_end(crate::prelude::each_job(b_p2.passed_p.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::Ex| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let x_p3 = p0;
                crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0xy.clone(), x_p3.clone()), move |cpp_expr_f_7708: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!(", {}", &cpp_expr_f_7708))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    }))), &moved_call_cpp_f(&b_p2.moved_p), &from_kept_cpp_f(&b_p2.name_p, &b_p2.replaced_p), &replaced_call_cpp_f(&b_p2.replaced_p))
}

/// The step machine of `ForBuildCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ForBuildCpp: unbounded fn Cp, Text, ForDef -> Text
/// ```
pub struct ForBuildCpp {
    pub cp_p0: crate::emit::cpp::Cp,
    pub owner_p1: crate::prelude::Text,
    pub b_p2: crate::lower::model::ForDef,
}

impl ::prism_rtl::Job<crate::prelude::Text> for ForBuildCpp {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let owner_p1 = &self.owner_p1;
        let b_p2 = &self.b_p2;
        let b_p2x = b_p2.clone();
        let cp_p0x = cp_p0.clone();
        let owner_p1x = owner_p1.clone();
        crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), b_p2x.at_p.clone()), move |cpp_expr_f_7530: crate::prelude::Text| crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), b_p2x.key_ty_p.clone()), move |cpp_type_f_7550: crate::prelude::Text| crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), b_p2x.value_ty_p.clone()), move |cpp_type_f_7573: crate::prelude::Text| crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), b_p2x.parent_p.clone()), move |cpp_expr_f_7652: crate::prelude::Text| crate::prelude::call_value(crate::prelude::each_job(b_p2x.passed_p.clone(), {
            let cp_p0xx = cp_p0x.clone();
            ::std::rc::Rc::new(move |p0: crate::lower::model::Ex| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let x_p3 = p0;
                    crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0xxy.clone(), x_p3.clone()), move |cpp_expr_f_7708: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!(", {}", &cpp_expr_f_7708))))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
        }), move |each_7684: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::for_build_template_f(&owner_p1x, &b_p2x.name_p, &cpp_expr_f_7530, &cpp_type_f_7550, &cpp_type_f_7573, &crate::prelude::Text::from(format!("{}::make", &crate::emit::cpp::type_path_f(&crate::lower::model::runtime_path_f(&b_p2x.row_node_p)))), &b_p2x.source_p, &cpp_expr_f_7652, &crate::prelude::concat(&each_7684), &moved_call_cpp_f(&b_p2x.moved_p), &from_kept_cpp_f(&b_p2x.name_p, &b_p2x.replaced_p), &replaced_call_cpp_f(&b_p2x.replaced_p))))))))
    }
}

/// `Start ForBuildCpp, x`: what the function value is when passed to `@Run`.
pub fn start_for_build_cpp_f(cp_p0: crate::emit::cpp::Cp, owner_p1: crate::prelude::Text, b_p2: crate::lower::model::ForDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(ForBuildCpp { cp_p0, owner_p1, b_p2 })
}

/// ```prism
/// FromKeptCpp: fn Text, [Text] -> Text
/// ```
pub fn from_kept_cpp_f(name_p0: &crate::prelude::Text, replaced_p1: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Text {
    if &crate::prelude::len(replaced_p1) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::from(format!("this->{}_from = items;", name_p0))
    } else {
        crate::prelude::Text::from(format!("auto from = ::std::exchange(this->{}_from, items);", name_p0))
    }
}

/// ```prism
/// ReplacedCallCpp: fn [Text] -> Text
/// ```
pub fn replaced_call_cpp_f(replaced_p0: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Text {
    if &crate::prelude::len(replaced_p0) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::lit("")
    } else {
        crate::prelude::Text::from(format!(" else if (auto was = from.get(k), is = items.get(k); !was || !is || !(*was == *is)) {{\n            // the dynamic under a kept key was replaced: that row follows it from the next tick\n{}        }}", &crate::prelude::concat(&crate::prelude::each(replaced_p0, &(|m_p1: &crate::prelude::Text| crate::prelude::Text::from(format!("            row->{}(cx);\n", m_p1)))))))
    }
}

/// ```prism
/// MovedCallCpp: fn Text -> Text
/// ```
pub fn moved_call_cpp_f(m_p0: &crate::prelude::Text) -> crate::prelude::Text {
    if m_p0 == &crate::prelude::Text::lit("") {
        crate::prelude::Text::lit("")
    } else {
        crate::prelude::Text::from(format!("\n    // the places of the host\'s child came or went: its document\'s outer moves\n    if (!::prism_rtl::same_keys(next, old)) this->{}(cx);", m_p0))
    }
}

/// ```prism
/// GenMovedCallCpp: fn Text -> Text
/// ```
pub fn gen_moved_call_cpp_f(m_p0: &crate::prelude::Text) -> crate::prelude::Text {
    if m_p0 == &crate::prelude::Text::lit("") {
        crate::prelude::Text::lit("")
    } else {
        crate::prelude::Text::from(format!("\n    // the places of the host\'s child came or went: its document\'s outer moves\n    this->{}(cx);", m_p0))
    }
}

/// ```prism
/// GenBuildCpp: unbounded fn Cp, Text, GenDef -> Text
/// ```
pub fn gen_build_cpp_f(cp_p0: &crate::emit::cpp::Cp, owner_p1: &crate::prelude::Text, gd_p2: &crate::lower::model::GenDef) -> crate::prelude::Text {
    let path_p3 = if gd_p2.transparent_p {
        crate::prelude::Text::lit("this->path")
    } else {
        crate::prelude::Text::from(format!("{}.child(crate::prelude::Segment::gen(g))", &crate::emit::cpp::expr::cpp_expr_f(cp_p0, &gd_p2.at_p)))
    };
    crate::emit::cpp::templates::items::gen_build_template_f(owner_p1, &gd_p2.name_p, &crate::emit::cpp::expr::cpp_expr_f(cp_p0, &gd_p2.at_p), &path_p3, &crate::emit::cpp::expr::cpp_expr_f(cp_p0, &gd_p2.source_p), &crate::emit::cpp::cpp_type_f(cp_p0, &gd_p2.value_ty_p), &crate::emit::cpp::expr::cpp_expr_f(cp_p0, &gd_p2.select_p), &gen_moved_call_cpp_f(&gd_p2.moved_p))
}

/// The step machine of `GenBuildCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GenBuildCpp: unbounded fn Cp, Text, GenDef -> Text
/// ```
pub struct GenBuildCpp {
    pub cp_p0: crate::emit::cpp::Cp,
    pub owner_p1: crate::prelude::Text,
    pub gd_p2: crate::lower::model::GenDef,
}

impl ::prism_rtl::Job<crate::prelude::Text> for GenBuildCpp {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let owner_p1 = &self.owner_p1;
        let gd_p2 = &self.gd_p2;
        let cp_p0z = cp_p0.clone();
        let gd_p2z = gd_p2.clone();
        let owner_p1z = owner_p1.clone();
        let k_let9465 = move |v9465: crate::prelude::Text| {
            let path_p3 = v9465;
            crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0z.clone(), gd_p2z.at_p.clone()), move |cpp_expr_f_9613: crate::prelude::Text| crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0z.clone(), gd_p2z.source_p.clone()), move |cpp_expr_f_9640: crate::prelude::Text| crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0z.clone(), gd_p2z.value_ty_p.clone()), move |cpp_type_f_9665: crate::prelude::Text| crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0z.clone(), gd_p2z.select_p.clone()), move |cpp_expr_f_9691: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::gen_build_template_f(&owner_p1z, &gd_p2z.name_p, &cpp_expr_f_9613, &path_p3, &cpp_expr_f_9640, &cpp_type_f_9665, &cpp_expr_f_9691, &gen_moved_call_cpp_f(&gd_p2z.moved_p)))))))
        };
        if gd_p2.transparent_p {
            k_let9465(crate::prelude::Text::lit("this->path"))
        } else {
            {
                let cp_p0x = cp_p0.clone();
                let gd_p2x = gd_p2.clone();
                crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x.clone(), gd_p2x.at_p.clone()), move |cpp_expr_f_9516: crate::prelude::Text| k_let9465(crate::prelude::Text::from(format!("{}.child(crate::prelude::Segment::gen(g))", &cpp_expr_f_9516))))
            }
        }
    }
}

/// `Start GenBuildCpp, x`: what the function value is when passed to `@Run`.
pub fn start_gen_build_cpp_f(cp_p0: crate::emit::cpp::Cp, owner_p1: crate::prelude::Text, gd_p2: crate::lower::model::GenDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(GenBuildCpp { cp_p0, owner_p1, gd_p2 })
}

/// ```prism
/// ProgramCpp: unbounded fn Cp, ProgDef, Bool -> Text
/// ```
pub fn program_cpp_f(cp_p0: &crate::emit::cpp::Cp, p_p1: &crate::lower::model::ProgDef, fallible_p2: &bool) -> crate::prelude::Text {
    let n_p3 = crate::prelude::len(&p_p1.params_p);
    let names_p4 = crate::prelude::each(&p_p1.params_p, &(|(a_p9, _): &(crate::prelude::Text, crate::lower::model::OutTy)| a_p9.clone()));
    let plural_p5 = if &n_p3 == &crate::prelude::Nat::from(1u32) {
        crate::prelude::Text::lit("")
    } else {
        crate::prelude::Text::lit("s")
    };
    let decode_p6 = if &n_p3 == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::lit("static_cast<void>(args);")
    } else {
        crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("if (args.size() != {}) return crate::prelude::unexpected(crate::prelude::Fault::answer(\"@{} takes {} argument{}\"));", &n_p3, &p_p1.prism_p, &n_p3, &plural_p5))]), &crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&n_p3), {
            let cp_p0x = cp_p0.clone();
            let p_p1x = p_p1.clone();
            ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                let cp_p0xy = cp_p0x.clone();
                let p_p1xy = p_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let i_pa = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(DecodeArg { cp_p0: cp_p0xy.clone(), ps_p1: p_p1xy.params_p.clone(), i_p2: i_pa.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
        }))), &crate::prelude::Text::lit("\n"))
    };
    let call_p7 = crate::prelude::Text::from(format!("{}::make(crate::prelude::Path::root(), {}cx)", &crate::emit::cpp::type_path_f(&p_p1.node_p), &crate::prelude::concat(&crate::prelude::each(&names_p4, &(|a_pb: &crate::prelude::Text| crate::prelude::Text::from(format!("{}, ", a_pb)))))));
    let root_p8 = if *fallible_p2 {
        crate::prelude::Text::from(format!("TRY({})", &call_p7))
    } else {
        call_p7.clone()
    };
    crate::emit::cpp::templates::items::program_class_f(&p_p1.name_p, &p_p1.prism_p, &crate::emit::cpp::type_path_f(&p_p1.node_p), &decode_p6, &root_p8)
}

/// The step machine of `ProgramCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ProgramCpp: unbounded fn Cp, ProgDef, Bool -> Text
/// ```
pub struct ProgramCpp {
    pub cp_p0: crate::emit::cpp::Cp,
    pub p_p1: crate::lower::model::ProgDef,
    pub fallible_p2: bool,
}

impl ::prism_rtl::Job<crate::prelude::Text> for ProgramCpp {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let p_p1 = &self.p_p1;
        let fallible_p2 = &self.fallible_p2;
        let n_p3 = crate::prelude::len(&p_p1.params_p);
        let names_p4 = crate::prelude::each(&p_p1.params_p, &(|(a_p9, _): &(crate::prelude::Text, crate::lower::model::OutTy)| a_p9.clone()));
        let plural_p5 = if &n_p3 == &crate::prelude::Nat::from(1u32) {
            crate::prelude::Text::lit("")
        } else {
            crate::prelude::Text::lit("s")
        };
        let fallible_p2z = *fallible_p2;
        let names_p4z = names_p4.clone();
        let p_p1z = p_p1.clone();
        let k_let9945 = move |v9945: crate::prelude::Text| {
            let decode_p6 = v9945;
            let call_p7 = crate::prelude::Text::from(format!("{}::make(crate::prelude::Path::root(), {}cx)", &crate::emit::cpp::type_path_f(&p_p1z.node_p), &crate::prelude::concat(&crate::prelude::each(&names_p4z, &(|a_pb: &crate::prelude::Text| crate::prelude::Text::from(format!("{}, ", a_pb)))))));
            let root_p8 = if fallible_p2z {
                crate::prelude::Text::from(format!("TRY({})", &call_p7))
            } else {
                call_p7.clone()
            };
            ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::program_class_f(&p_p1z.name_p, &p_p1z.prism_p, &crate::emit::cpp::type_path_f(&p_p1z.node_p), &decode_p6, &root_p8))
        };
        if &n_p3 == &crate::prelude::Nat::from(0u32) {
            k_let9945(crate::prelude::Text::lit("static_cast<void>(args);"))
        } else {
            {
                let cp_p0x = cp_p0.clone();
                let p_p1x = p_p1.clone();
                crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&n_p3), {
                    let cp_p0xx = cp_p0x.clone();
                    let p_p1xx = p_p1x.clone();
                    ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                        let cp_p0xxy = cp_p0xx.clone();
                        let p_p1xxy = p_p1xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let i_pa = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(DecodeArg { cp_p0: cp_p0xxy.clone(), ps_p1: p_p1xxy.params_p.clone(), i_p2: i_pa.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                }), move |each_10156: crate::prelude::Array<crate::prelude::Text>| k_let9945(crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("if (args.size() != {}) return crate::prelude::unexpected(crate::prelude::Fault::answer(\"@{} takes {} argument{}\"));", &n_p3, &p_p1x.prism_p, &n_p3, &plural_p5))]), &each_10156), &crate::prelude::Text::lit("\n"))))
            }
        }
    }
}

/// `Start ProgramCpp, x`: what the function value is when passed to `@Run`.
pub fn start_program_cpp_f(cp_p0: crate::emit::cpp::Cp, p_p1: crate::lower::model::ProgDef, fallible_p2: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(ProgramCpp { cp_p0, p_p1, fallible_p2 })
}

/// ```prism
/// DecodeArg: unbounded fn Cp, [((Text, OutTy))], Nat -> Text
/// ```
pub fn decode_arg_f(cp_p0: &crate::emit::cpp::Cp, ps_p1: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>, i_p2: &crate::prelude::Nat) -> crate::prelude::Text {
    match crate::prelude::index(ps_p1, i_p2) {
        ::std::option::Option::Some((a_p3, t_p4)) => crate::prelude::Text::from(format!("auto {} = TRY(::prism_rtl::from_pod<{}>(args[{}]));", &a_p3, &crate::emit::cpp::cpp_type_f(cp_p0, &t_p4), i_p2)),
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    }
}

/// The step machine of `DecodeArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DecodeArg: unbounded fn Cp, [((Text, OutTy))], Nat -> Text
/// ```
pub struct DecodeArg {
    pub cp_p0: crate::emit::cpp::Cp,
    pub ps_p1: crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>,
    pub i_p2: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::prelude::Text> for DecodeArg {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let ps_p1 = &self.ps_p1;
        let i_p2 = &self.i_p2;
        match crate::prelude::index(ps_p1, i_p2) {
            ::std::option::Option::Some((a_p3, t_p4)) => {
                let cp_p0x = cp_p0.clone();
                let i_p2x = i_p2.clone();
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), t_p4.clone()), move |cpp_type_f_10594: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("auto {} = TRY(::prism_rtl::from_pod<{}>(args[{}]));", &a_p3, &cpp_type_f_10594, &i_p2x))))
            },
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("")),
        }
    }
}

/// `Start DecodeArg, x`: what the function value is when passed to `@Run`.
pub fn start_decode_arg_f(cp_p0: crate::emit::cpp::Cp, ps_p1: crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>, i_p2: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(DecodeArg { cp_p0, ps_p1, i_p2 })
}

/// ```prism
/// ModuleParts: unbounded fn Cp, ModDef -> Parts
/// ```
pub fn module_parts_f(cp_p0: &crate::emit::cpp::Cp, m_p1: &crate::lower::model::ModDef) -> crate::emit::cpp::items::Parts {
    let mcp_p2 = crate::emit::cpp::in_home_f(cp_p0, &m_p1.name_p);
    let all_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(m_p1.items_p.clone(), crate::emit::cpp::items::no_parts_p(), {
        let mcp_p2x = mcp_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::emit::cpp::items::Parts, crate::lower::model::Item)| {
            let mcp_p2xy = mcp_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p4 = p0;
                let it_p5 = p1;
                crate::prelude::call_then(crate::emit::cpp::items::start_item_parts_f(mcp_p2xy.clone(), it_p5.clone()), move |item_parts_f_11043: crate::emit::cpp::items::Parts| ::prism_rtl::Turn::Finished(crate::emit::cpp::items::join_parts_f(&acc_p4, &item_parts_f_11043)))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::emit::cpp::items::Parts, crate::lower::model::Item)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::emit::cpp::items::Parts>>>
    }));
    crate::emit::cpp::items::Parts { forward_p: in_ns_f(&m_p1.name_p, &all_p3.forward_p), values_p: crate::prelude::each(&all_p3.values_p, &(|v_p6: &crate::emit::cpp::items::ValueDecl| in_ns_value_f(&m_p1.name_p, v_p6))), protos_p: in_ns_f(&m_p1.name_p, &all_p3.protos_p), classes_p: in_ns_f(&m_p1.name_p, &all_p3.classes_p), outer_p: all_p3.outer_p.clone(), generic_p: in_ns_f(&m_p1.name_p, &all_p3.generic_p), defs_p: all_p3.defs_p.clone() }
}

/// The step machine of `ModuleParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModuleParts: unbounded fn Cp, ModDef -> Parts
/// ```
pub struct ModuleParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub m_p1: crate::lower::model::ModDef,
}

impl ::prism_rtl::Job<crate::emit::cpp::items::Parts> for ModuleParts {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::emit::cpp::items::Parts> {
        let cp_p0 = &self.cp_p0;
        let m_p1 = &self.m_p1;
        let mcp_p2 = crate::emit::cpp::in_home_f(cp_p0, &m_p1.name_p);
        let m_p1x = m_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(m_p1x.items_p.clone(), crate::emit::cpp::items::no_parts_p(), {
            let mcp_p2x = mcp_p2.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::emit::cpp::items::Parts, crate::lower::model::Item)| {
                let mcp_p2xy = mcp_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p4 = p0;
                    let it_p5 = p1;
                    crate::prelude::call_then(crate::emit::cpp::items::start_item_parts_f(mcp_p2xy.clone(), it_p5.clone()), move |item_parts_f_11043: crate::emit::cpp::items::Parts| ::prism_rtl::Turn::Finished(crate::emit::cpp::items::join_parts_f(&acc_p4, &item_parts_f_11043)))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::emit::cpp::items::Parts, crate::lower::model::Item)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::emit::cpp::items::Parts>>>
        }), move |fold_10993: crate::emit::cpp::items::Parts| {
            let all_p3 = fold_10993;
            ::prism_rtl::Turn::Finished(crate::emit::cpp::items::Parts { forward_p: in_ns_f(&m_p1x.name_p, &all_p3.forward_p), values_p: crate::prelude::each(&all_p3.values_p, &(|v_p6: &crate::emit::cpp::items::ValueDecl| in_ns_value_f(&m_p1x.name_p, v_p6))), protos_p: in_ns_f(&m_p1x.name_p, &all_p3.protos_p), classes_p: in_ns_f(&m_p1x.name_p, &all_p3.classes_p), outer_p: all_p3.outer_p.clone(), generic_p: in_ns_f(&m_p1x.name_p, &all_p3.generic_p), defs_p: all_p3.defs_p.clone() })
        })
    }
}

/// `Start ModuleParts, x`: what the function value is when passed to `@Run`.
pub fn start_module_parts_f(cp_p0: crate::emit::cpp::Cp, m_p1: crate::lower::model::ModDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::emit::cpp::items::Parts>> {
    ::std::rc::Rc::new(ModuleParts { cp_p0, m_p1 })
}

/// ```prism
/// InNsValue: fn Text, ValueDecl -> ValueDecl
/// ```
pub fn in_ns_value_f(ns_p0: &crate::prelude::Text, v_p1: &crate::emit::cpp::items::ValueDecl) -> crate::emit::cpp::items::ValueDecl {
    let mut this: crate::emit::cpp::items::ValueDecl = v_p1.clone();
    this.text_p = crate::prelude::Text::from(format!("namespace {} {{\n\n{}\n\n}}  // namespace {}", ns_p0, &this.text_p, ns_p0));
    this
}

/// ```prism
/// InNs: fn Text, [Text] -> [Text]
/// ```
pub fn in_ns_f(ns_p0: &crate::prelude::Text, xs1: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<crate::prelude::Text> {
    match xs1 {
        c0_1 if (c0_1.len() == 0) => crate::prelude::Array::new(),
        xs_p2 => crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("namespace {} {{\n\n{}\n\n}}  // namespace {}", ns_p0, &crate::syntax::lexer::chars::join_f(xs_p2, &crate::prelude::Text::lit("\n\n")), ns_p0))]),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// NodeFallibleCpp: fn Model, Text -> Bool
/// ```
pub fn node_fallible_cpp_f(model_p0: &crate::lower::model::Model, path_p1: &crate::prelude::Text) -> bool {
    crate::prelude::fold(&model_p0.mods_p, &false, &(|f_p2: &bool, m_p3: &crate::lower::model::ModDef| crate::prelude::fold(&m_p3.items_p, f_p2, &(|f2_p4: &bool, it_p5: &crate::lower::model::Item| match it_p5 {
        crate::lower::model::Item::ItNode(n_p6) => *f2_p4 || ((&crate::prelude::Text::from(format!("{}::{}", &m_p3.name_p, &n_p6.name_p)) == path_p1) && n_p6.fallible_p),
        _ => *f2_p4,
    }))))
}

/// ```prism
/// EmitCpp: unbounded fn Model, Text, [Text] -> [((Text, Text))]
/// ```
pub fn emit_cpp_f(model_p0: &crate::lower::model::Model, runtime_p1: &crate::prelude::Text, scripts_p2: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)> {
    let cp_p3 = crate::emit::cpp::context_f(model_p0);
    let crate_p4 = crate::emit::cpp::in_home_f(&cp_p3, &crate::prelude::Text::lit(""));
    let elem_p5 = crate::emit::cpp::items::row_parts_f(&crate_p4, &crate::prelude::Text::lit(""), &model_p0.elem_p);
    let answer_p6 = crate::emit::cpp::items::answer_parts_f(&crate_p4, &model_p0.answer_p);
    let mods_p7 = crate::prelude::run_to_end(crate::prelude::each_job(model_p0.mods_p.clone(), {
        let cp_p3x = cp_p3.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::ModDef| {
            let cp_p3xy = cp_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_pu = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(ModuleParts { cp_p0: cp_p3xy.clone(), m_p1: m_pu.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::ModDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::emit::cpp::items::Parts>>>
    }));
    let programs_p8 = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(all_programs_cpp_f(model_p0), {
        let crate_p4x = crate_p4.clone();
        let model_p0x = model_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::ProgDef| {
            let crate_p4xy = crate_p4x.clone();
            let model_p0xy = model_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let p_pv = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(ProgramCpp { cp_p0: crate_p4xy.clone(), p_p1: p_pv.clone(), fallible_p2: node_fallible_cpp_f(&model_p0xy, &p_pv.node_p) }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::ProgDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    })), &crate::prelude::Text::lit("\n\n"));
    let regs_p9 = crate::prelude::concat(&crate::prelude::each(&model_p0.programs_p, &(|p_p10: &crate::lower::model::ProgDef| crate::prelude::Text::from(format!("\n.program<{}>(\"{}\")", &p_p10.name_p, &p_p10.prism_p)))));
    let checks_pa = crate::prelude::concat(&crate::prelude::run_to_end(crate::prelude::each_job(model_p0.checks_p.clone(), {
        let crate_p4x = crate_p4.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::CheckDef| {
            let crate_p4xy = crate_p4x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let c_p11 = p0;
                crate::prelude::call_value(crate::prelude::each_job(c_p11.lines_p.clone(), {
                    let crate_p4xyx = crate_p4xy.clone();
                    ::std::rc::Rc::new(move |p0: crate::lower::model::Ex| {
                        let crate_p4xyxy = crate_p4xyx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let l_p12 = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::cpp::expr::CppExpr { cp_p0: crate_p4xyxy.clone(), x_p1: l_p12.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                }), move |each_12580: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("\n.check(\"{}\", [] {{ return ::std::vector<crate::prelude::Result<crate::prelude::Pod>>{{{}}}; }})", &c_p11.name_p, &crate::syntax::lexer::chars::join_f(&each_12580, &crate::prelude::Text::lit(", "))))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::CheckDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    })));
    let script_list_pb = crate::syntax::lexer::chars::join_f(&crate::prelude::each(scripts_p2, &(|s_p13: &crate::prelude::Text| crate::prelude::Text::from(format!("\"{}\",", &crate::lower::expr::escape_f(s_p13))))), &crate::prelude::Text::lit("\n"));
    let world_pc = match &model_p0.root_o {
        ::std::option::Option::Some(r_p14) => r_p14.world_p.clone(),
        ::std::option::Option::None => crate::prelude::Text::lit("test"),
    };
    let canvas_pd = &world_pc == &crate::prelude::Text::lit("canvas");
    let run_root_pe = match &model_p0.root_o {
        ::std::option::Option::Some(r_p15) => crate::emit::cpp::templates::cpp_run_root_f(&r_p15.name_p, &(if canvas_pd {
            crate::emit::cpp::templates::cpp_canvas_run_f(&r_p15.name_p)
        } else {
            crate::emit::cpp::templates::cpp_no_canvas_f(&r_p15.name_p)
        })),
        ::std::option::Option::None => crate::emit::cpp::templates::cpp_no_root_f(&model_p0.name_p),
    };
    let both_pf = crate::emit::cpp::items::join_parts_f(&elem_p5, &answer_p6);
    let elem_decl_pg = crate::emit::cpp::templates::cpp_elem_decl_f(&includes_f(&crate::prelude::Text::lit("decl"), &crate::prelude::append(&model_p0.elem_complete_p, &model_p0.elem_declared_p)), &crate::syntax::lexer::chars::join_f(&both_pf.forward_p, &crate::prelude::Text::lit("\n\n")), &crate::emit::cpp::prelude::cpp_prelude_rows_f(&crate::prelude::Text::lit("")));
    let elem_types_ph = crate::emit::cpp::templates::cpp_elem_types_f(&crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::Array::from(vec![includes_f(&crate::prelude::Text::lit("types"), &model_p0.elem_complete_p), includes_f(&crate::prelude::Text::lit("decl"), &model_p0.elem_declared_p)]), &(|t_p16: &crate::prelude::Text| t_p16 != &crate::prelude::Text::lit(""))), &crate::prelude::Text::lit("\n")), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&both_pf.values_p, &(|v_p17: &crate::emit::cpp::items::ValueDecl| v_p17.text_p.clone())), &crate::prelude::Text::lit("\n\n")));
    let pairs_pi = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&model_p0.mods_p)), &(|i_p18: &crate::prelude::Nat| (crate::prelude::or(&crate::prelude::index(&model_p0.mods_p, i_p18), &no_mod_p()), crate::prelude::or(&crate::prelude::index(&mods_p7, i_p18), &crate::emit::cpp::items::no_parts_p()))));
    let generics_pj = crate::prelude::fold(&pairs_pi, &crate::prelude::Array::new(), &(|acc_p19: &crate::prelude::Array<crate::prelude::Text>, (m_p1a, p_p1b): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| if &crate::prelude::len(&p_p1b.generic_p) > &crate::prelude::Nat::from(0u32) {
        crate::prelude::push(acc_p19, &m_p1a.name_p)
    } else {
        acc_p19.clone()
    }));
    let per_module_pk = crate::prelude::run_to_end(crate::prelude::each_job(pairs_pi.clone(), ::std::rc::Rc::new(move |p0: (crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (m_p1c, p_p1d) = p0;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(ModuleFiles { m_p0: m_p1c.clone(), p_p1: p_p1d.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::ModDef, crate::emit::cpp::items::Parts)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::prelude::Array<Piece>)>>>));
    let pieces_pl = crate::prelude::fold(&per_module_pk, &crate::prelude::Array::new(), &(|acc_p1e: &crate::prelude::Array<Piece>, (_, ps_p1f): &(crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::prelude::Array<Piece>)| crate::prelude::append(acc_p1e, ps_p1f)));
    let units_pm = units_f(&pieces_pl);
    let unit_files_pn = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&units_pm)), &(|k_p1g: &crate::prelude::Nat| unit_file_f(k_p1g, &crate::prelude::or(&crate::prelude::index(&units_pm, k_p1g), &crate::prelude::Array::new()), &generics_pj)));
    let main_includes_po = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("#include \"elem.types.hpp\"")]), &crate::prelude::Array::from(vec![includes_f(&crate::prelude::Text::lit(""), &crate::prelude::each(&model_p0.mods_p, &(|m_p1h: &crate::lower::model::ModDef| m_p1h.name_p.clone())))])), &crate::prelude::Array::from(vec![includes_f(&crate::prelude::Text::lit("generic"), &generics_pj)])), &crate::prelude::Text::lit("\n"));
    let canvas_include_pp = if canvas_pd {
        crate::emit::cpp::templates::cpp_canvas_include_f(&crate::prelude::Text::lit(""))
    } else {
        crate::prelude::Text::lit("")
    };
    let main_pq = crate::emit::cpp::templates::cpp_main_f(&model_p0.name_p, &crate::prelude::Text::from(format!("#include \"programs.hpp\"\n{}", &canvas_include_pp)), &regs_p9, &checks_pa, &script_list_pb, &world_pc, &run_root_pe, &crate::syntax::lexer::chars::join_f(&crate::emit::cpp::patterns::concat2_f(&crate::prelude::each(&crate::prelude::Array::from(vec![elem_p5.clone(), answer_p6.clone()]), &(|p_p1i: &crate::emit::cpp::items::Parts| p_p1i.defs_p.clone()))), &crate::prelude::Text::lit("\n\n")));
    let groups_pr = crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::filter(&model_p0.mods_p, &(|m_p1j: &crate::lower::model::ModDef| (&crate::prelude::len(&m_p1j.types_with_p) > &crate::prelude::Nat::from(1u32)) && (&crate::prelude::or(&crate::prelude::index(&m_p1j.types_with_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")) == &m_p1j.name_p))), {
        let pairs_pix = pairs_pi.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::ModDef| {
            let pairs_pixy = pairs_pix.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_p1k = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(GroupTypesFile { pairs_p0: pairs_pixy.clone(), group_p1: m_p1k.types_with_p.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::ModDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::prelude::Text)>>>
    }));
    let files_ps = crate::prelude::append(&crate::prelude::fold(&per_module_pk, &crate::prelude::Array::new(), &(|acc_p1l: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, (fs_p1m, _): &(crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::prelude::Array<Piece>)| crate::prelude::append(acc_p1l, fs_p1m))), &unit_files_pn);
    let sources_pt = crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::each(&files_ps, &(|(f_p1n, _): &(crate::prelude::Text, crate::prelude::Text)| f_p1n.clone())), &(|f_p1o: &crate::prelude::Text| crate::syntax::lexer::chars::contains_f(f_p1o, &crate::prelude::Text::lit(".cpp")))), &crate::prelude::Text::lit(" "));
    crate::prelude::append(&crate::prelude::Array::from(vec![(crate::prelude::Text::lit("Makefile"), crate::emit::cpp::templates::cpp_makefile_f(&model_p0.name_p, runtime_p1, &sources_pt, &(if canvas_pd {
        crate::emit::cpp::templates::cpp_makefile_canvas_f(runtime_p1)
    } else {
        crate::prelude::Text::lit("")
    }))), (crate::prelude::Text::lit("src/elem.decl.hpp"), elem_decl_pg.clone()), (crate::prelude::Text::lit("src/elem.types.hpp"), elem_types_ph.clone()), (crate::prelude::Text::lit("src/programs.hpp"), crate::emit::cpp::templates::cpp_programs_header_f(&model_p0.name_p, &main_includes_po, &programs_p8)), (crate::prelude::Text::lit("src/main.cpp"), main_pq.clone()), (crate::prelude::Text::lit("src/prelude.hpp"), crate::emit::cpp::prelude::cpp_prelude_source_f(&crate::prelude::Text::lit("")))]), &crate::prelude::append(&groups_pr, &files_ps))
}

/// The step machine of `EmitCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EmitCpp: unbounded fn Model, Text, [Text] -> [((Text, Text))]
/// ```
pub struct EmitCpp {
    pub model_p0: crate::lower::model::Model,
    pub runtime_p1: crate::prelude::Text,
    pub scripts_p2: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>> for EmitCpp {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>> {
        let model_p0 = &self.model_p0;
        let runtime_p1 = &self.runtime_p1;
        let scripts_p2 = &self.scripts_p2;
        let cp_p3 = crate::emit::cpp::context_f(model_p0);
        let crate_p4 = crate::emit::cpp::in_home_f(&cp_p3, &crate::prelude::Text::lit(""));
        let model_p0x = model_p0.clone();
        let runtime_p1x = runtime_p1.clone();
        let scripts_p2x = scripts_p2.clone();
        crate::prelude::call_then(crate::emit::cpp::items::start_row_parts_f(crate_p4.clone(), crate::prelude::Text::lit(""), model_p0x.elem_p.clone()), move |row_parts_f_12083: crate::emit::cpp::items::Parts| {
            let elem_p5 = row_parts_f_12083;
            crate::prelude::call_then(crate::emit::cpp::items::start_answer_parts_f(crate_p4.clone(), model_p0x.answer_p.clone()), move |answer_parts_f_12131: crate::emit::cpp::items::Parts| {
                let answer_p6 = answer_parts_f_12131;
                crate::prelude::call_value(crate::prelude::each_job(model_p0x.mods_p.clone(), {
                    let cp_p3x = cp_p3.clone();
                    ::std::rc::Rc::new(move |p0: crate::lower::model::ModDef| {
                        let cp_p3xy = cp_p3x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let m_pu = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(ModuleParts { cp_p0: cp_p3xy.clone(), m_p1: m_pu.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::ModDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::emit::cpp::items::Parts>>>
                }), move |each_12178: crate::prelude::Array<crate::emit::cpp::items::Parts>| {
                    let mods_p7 = each_12178;
                    crate::prelude::call_value(crate::prelude::each_job(all_programs_cpp_f(&model_p0x), {
                        let crate_p4x = crate_p4.clone();
                        let model_p0xx = model_p0x.clone();
                        ::std::rc::Rc::new(move |p0: crate::lower::model::ProgDef| {
                            let crate_p4xy = crate_p4x.clone();
                            let model_p0xxy = model_p0xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let p_pv = p0;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(ProgramCpp { cp_p0: crate_p4xy.clone(), p_p1: p_pv.clone(), fallible_p2: node_fallible_cpp_f(&model_p0xxy, &p_pv.node_p) }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::ProgDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                    }), move |each_12243: crate::prelude::Array<crate::prelude::Text>| {
                        let programs_p8 = crate::syntax::lexer::chars::join_f(&each_12243, &crate::prelude::Text::lit("\n\n"));
                        let regs_p9 = crate::prelude::concat(&crate::prelude::each(&model_p0x.programs_p, &(|p_p10: &crate::lower::model::ProgDef| crate::prelude::Text::from(format!("\n.program<{}>(\"{}\")", &p_p10.name_p, &p_p10.prism_p)))));
                        crate::prelude::call_value(crate::prelude::each_job(model_p0x.checks_p.clone(), {
                            let crate_p4x = crate_p4.clone();
                            ::std::rc::Rc::new(move |p0: crate::lower::model::CheckDef| {
                                let crate_p4xy = crate_p4x.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let c_p11 = p0;
                                    crate::prelude::call_value(crate::prelude::each_job(c_p11.lines_p.clone(), {
                                        let crate_p4xyx = crate_p4xy.clone();
                                        ::std::rc::Rc::new(move |p0: crate::lower::model::Ex| {
                                            let crate_p4xyxy = crate_p4xyx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let l_p12 = p0;
                                                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::cpp::expr::CppExpr { cp_p0: crate_p4xyxy.clone(), x_p1: l_p12.clone() }))
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                                    }), move |each_12580: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("\n.check(\"{}\", [] {{ return ::std::vector<crate::prelude::Result<crate::prelude::Pod>>{{{}}}; }})", &c_p11.name_p, &crate::syntax::lexer::chars::join_f(&each_12580, &crate::prelude::Text::lit(", "))))))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::CheckDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                        }), move |each_12452: crate::prelude::Array<crate::prelude::Text>| {
                            let checks_pa = crate::prelude::concat(&each_12452);
                            let script_list_pb = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&scripts_p2x, &(|s_p13: &crate::prelude::Text| crate::prelude::Text::from(format!("\"{}\",", &crate::lower::expr::escape_f(s_p13))))), &crate::prelude::Text::lit("\n"));
                            let world_pc = match &model_p0x.root_o {
                                ::std::option::Option::Some(r_p14) => r_p14.world_p.clone(),
                                ::std::option::Option::None => crate::prelude::Text::lit("test"),
                            };
                            let canvas_pd = &world_pc == &crate::prelude::Text::lit("canvas");
                            let run_root_pe = match &model_p0x.root_o {
                                ::std::option::Option::Some(r_p15) => crate::emit::cpp::templates::cpp_run_root_f(&r_p15.name_p, &(if canvas_pd {
                                    crate::emit::cpp::templates::cpp_canvas_run_f(&r_p15.name_p)
                                } else {
                                    crate::emit::cpp::templates::cpp_no_canvas_f(&r_p15.name_p)
                                })),
                                ::std::option::Option::None => crate::emit::cpp::templates::cpp_no_root_f(&model_p0x.name_p),
                            };
                            let both_pf = crate::emit::cpp::items::join_parts_f(&elem_p5, &answer_p6);
                            let elem_decl_pg = crate::emit::cpp::templates::cpp_elem_decl_f(&includes_f(&crate::prelude::Text::lit("decl"), &crate::prelude::append(&model_p0x.elem_complete_p, &model_p0x.elem_declared_p)), &crate::syntax::lexer::chars::join_f(&both_pf.forward_p, &crate::prelude::Text::lit("\n\n")), &crate::emit::cpp::prelude::cpp_prelude_rows_f(&crate::prelude::Text::lit("")));
                            let elem_types_ph = crate::emit::cpp::templates::cpp_elem_types_f(&crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::Array::from(vec![includes_f(&crate::prelude::Text::lit("types"), &model_p0x.elem_complete_p), includes_f(&crate::prelude::Text::lit("decl"), &model_p0x.elem_declared_p)]), &(|t_p16: &crate::prelude::Text| t_p16 != &crate::prelude::Text::lit(""))), &crate::prelude::Text::lit("\n")), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&both_pf.values_p, &(|v_p17: &crate::emit::cpp::items::ValueDecl| v_p17.text_p.clone())), &crate::prelude::Text::lit("\n\n")));
                            let pairs_pi = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&model_p0x.mods_p)), &(|i_p18: &crate::prelude::Nat| (crate::prelude::or(&crate::prelude::index(&model_p0x.mods_p, i_p18), &no_mod_p()), crate::prelude::or(&crate::prelude::index(&mods_p7, i_p18), &crate::emit::cpp::items::no_parts_p()))));
                            let generics_pj = crate::prelude::fold(&pairs_pi, &crate::prelude::Array::new(), &(|acc_p19: &crate::prelude::Array<crate::prelude::Text>, (m_p1a, p_p1b): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| if &crate::prelude::len(&p_p1b.generic_p) > &crate::prelude::Nat::from(0u32) {
                                crate::prelude::push(acc_p19, &m_p1a.name_p)
                            } else {
                                acc_p19.clone()
                            }));
                            crate::prelude::call_value(crate::prelude::each_job(pairs_pi.clone(), ::std::rc::Rc::new(move |p0: (crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| crate::prelude::entered(crate::prelude::once_job(move || {
                                let (m_p1c, p_p1d) = p0;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(ModuleFiles { m_p0: m_p1c.clone(), p_p1: p_p1d.clone() }))
                            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::ModDef, crate::emit::cpp::items::Parts)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::prelude::Array<Piece>)>>>), move |each_13592: crate::prelude::Array<(crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::prelude::Array<Piece>)>| {
                                let per_module_pk = each_13592;
                                let pieces_pl = crate::prelude::fold(&per_module_pk, &crate::prelude::Array::new(), &(|acc_p1e: &crate::prelude::Array<Piece>, (_, ps_p1f): &(crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::prelude::Array<Piece>)| crate::prelude::append(acc_p1e, ps_p1f)));
                                let units_pm = units_f(&pieces_pl);
                                let unit_files_pn = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&units_pm)), &(|k_p1g: &crate::prelude::Nat| unit_file_f(k_p1g, &crate::prelude::or(&crate::prelude::index(&units_pm, k_p1g), &crate::prelude::Array::new()), &generics_pj)));
                                let main_includes_po = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("#include \"elem.types.hpp\"")]), &crate::prelude::Array::from(vec![includes_f(&crate::prelude::Text::lit(""), &crate::prelude::each(&model_p0x.mods_p, &(|m_p1h: &crate::lower::model::ModDef| m_p1h.name_p.clone())))])), &crate::prelude::Array::from(vec![includes_f(&crate::prelude::Text::lit("generic"), &generics_pj)])), &crate::prelude::Text::lit("\n"));
                                let canvas_include_pp = if canvas_pd {
                                    crate::emit::cpp::templates::cpp_canvas_include_f(&crate::prelude::Text::lit(""))
                                } else {
                                    crate::prelude::Text::lit("")
                                };
                                let main_pq = crate::emit::cpp::templates::cpp_main_f(&model_p0x.name_p, &crate::prelude::Text::from(format!("#include \"programs.hpp\"\n{}", &canvas_include_pp)), &regs_p9, &checks_pa, &script_list_pb, &world_pc, &run_root_pe, &crate::syntax::lexer::chars::join_f(&crate::emit::cpp::patterns::concat2_f(&crate::prelude::each(&crate::prelude::Array::from(vec![elem_p5.clone(), answer_p6.clone()]), &(|p_p1i: &crate::emit::cpp::items::Parts| p_p1i.defs_p.clone()))), &crate::prelude::Text::lit("\n\n")));
                                crate::prelude::call_value(crate::prelude::each_job(crate::prelude::filter(&model_p0x.mods_p, &(|m_p1j: &crate::lower::model::ModDef| (&crate::prelude::len(&m_p1j.types_with_p) > &crate::prelude::Nat::from(1u32)) && (&crate::prelude::or(&crate::prelude::index(&m_p1j.types_with_p, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")) == &m_p1j.name_p))), {
                                    let pairs_pix = pairs_pi.clone();
                                    ::std::rc::Rc::new(move |p0: crate::lower::model::ModDef| {
                                        let pairs_pixy = pairs_pix.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let m_p1k = p0;
                                            ::prism_rtl::Turn::More(::std::rc::Rc::new(GroupTypesFile { pairs_p0: pairs_pixy.clone(), group_p1: m_p1k.types_with_p.clone() }))
                                        }))
                                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::ModDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::prelude::Text)>>>
                                }), move |each_14272: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>| {
                                    let groups_pr = each_14272;
                                    let files_ps = crate::prelude::append(&crate::prelude::fold(&per_module_pk, &crate::prelude::Array::new(), &(|acc_p1l: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, (fs_p1m, _): &(crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::prelude::Array<Piece>)| crate::prelude::append(acc_p1l, fs_p1m))), &unit_files_pn);
                                    let sources_pt = crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::each(&files_ps, &(|(f_p1n, _): &(crate::prelude::Text, crate::prelude::Text)| f_p1n.clone())), &(|f_p1o: &crate::prelude::Text| crate::syntax::lexer::chars::contains_f(f_p1o, &crate::prelude::Text::lit(".cpp")))), &crate::prelude::Text::lit(" "));
                                    ::prism_rtl::Turn::Finished(crate::prelude::append(&crate::prelude::Array::from(vec![(crate::prelude::Text::lit("Makefile"), crate::emit::cpp::templates::cpp_makefile_f(&model_p0x.name_p, &runtime_p1x, &sources_pt, &(if canvas_pd {
                                        crate::emit::cpp::templates::cpp_makefile_canvas_f(&runtime_p1x)
                                    } else {
                                        crate::prelude::Text::lit("")
                                    }))), (crate::prelude::Text::lit("src/elem.decl.hpp"), elem_decl_pg.clone()), (crate::prelude::Text::lit("src/elem.types.hpp"), elem_types_ph.clone()), (crate::prelude::Text::lit("src/programs.hpp"), crate::emit::cpp::templates::cpp_programs_header_f(&model_p0x.name_p, &main_includes_po, &programs_p8)), (crate::prelude::Text::lit("src/main.cpp"), main_pq.clone()), (crate::prelude::Text::lit("src/prelude.hpp"), crate::emit::cpp::prelude::cpp_prelude_source_f(&crate::prelude::Text::lit("")))]), &crate::prelude::append(&groups_pr, &files_ps)))
                                })
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start EmitCpp, x`: what the function value is when passed to `@Run`.
pub fn start_emit_cpp_f(model_p0: crate::lower::model::Model, runtime_p1: crate::prelude::Text, scripts_p2: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>>> {
    ::std::rc::Rc::new(EmitCpp { model_p0, runtime_p1, scripts_p2 })
}

/// ```prism
/// let noMod
/// ```
pub fn no_mod_p() -> crate::lower::model::ModDef {
    crate::lower::model::ModDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), path_p: crate::prelude::Text::lit(""), uses_p: crate::prelude::Array::new(), complete_p: crate::prelude::Array::new(), declared_p: crate::prelude::Array::new(), types_with_p: crate::prelude::Array::new(), items_p: crate::prelude::Array::new() }
}

/// ```prism
/// GroupTypesFile: unbounded fn [((ModDef, Parts))], [Text] -> ((Text, Text))
/// ```
pub fn group_types_file_f(pairs_p0: &crate::prelude::Array<(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)>, group_p1: &crate::prelude::Array<crate::prelude::Text>) -> (crate::prelude::Text, crate::prelude::Text) {
    let members_p2 = crate::prelude::filter(pairs_p0, &(|(m_p7, _): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| among_f(group_p1, &m_p7.name_p)));
    let p_p3 = crate::prelude::fold(&members_p2, &crate::emit::cpp::items::no_parts_p(), &(|acc_p8: &crate::emit::cpp::items::Parts, (_, q_p9): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| crate::emit::cpp::items::join_parts_f(acc_p8, q_p9)));
    let complete_p4 = crate::prelude::fold(&members_p2, &crate::prelude::Array::new(), &(|acc_pa: &crate::prelude::Array<crate::prelude::Text>, (m_pb, _): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| crate::prelude::fold(&m_pb.complete_p, acc_pa, &(|a_pc: &crate::prelude::Array<crate::prelude::Text>, n_pd: &crate::prelude::Text| if among_f(a_pc, n_pd) || among_f(group_p1, n_pd) {
        a_pc.clone()
    } else {
        crate::prelude::push(a_pc, n_pd)
    }))));
    let declared_p5 = crate::prelude::fold(&members_p2, &crate::prelude::Array::new(), &(|acc_pe: &crate::prelude::Array<crate::prelude::Text>, (m_pf, _): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| crate::prelude::fold(&m_pf.declared_p, acc_pe, &(|a_pg: &crate::prelude::Array<crate::prelude::Text>, n_ph: &crate::prelude::Text| if (among_f(a_pg, n_ph) || among_f(group_p1, n_ph)) || among_f(&complete_p4, n_ph) {
        a_pg.clone()
    } else {
        crate::prelude::push(a_pg, n_ph)
    }))));
    let title_p6 = crate::prelude::Text::from(format!("The modules {}", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(group_p1, &(|n_pi: &crate::prelude::Text| crate::prelude::Text::from(format!("`{}`", n_pi)))), &crate::prelude::Text::lit(", "))));
    (crate::prelude::Text::from(format!("src/{}.types.hpp", &group_name_f(group_p1))), types_header_f(&title_p6, group_p1, &declared_p5, &complete_p4, &p_p3))
}

/// The step machine of `GroupTypesFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GroupTypesFile: unbounded fn [((ModDef, Parts))], [Text] -> ((Text, Text))
/// ```
pub struct GroupTypesFile {
    pub pairs_p0: crate::prelude::Array<(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)>,
    pub group_p1: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<(crate::prelude::Text, crate::prelude::Text)> for GroupTypesFile {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Text, crate::prelude::Text)> {
        let pairs_p0 = &self.pairs_p0;
        let group_p1 = &self.group_p1;
        let members_p2 = crate::prelude::filter(pairs_p0, &(|(m_p7, _): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| among_f(group_p1, &m_p7.name_p)));
        let p_p3 = crate::prelude::fold(&members_p2, &crate::emit::cpp::items::no_parts_p(), &(|acc_p8: &crate::emit::cpp::items::Parts, (_, q_p9): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| crate::emit::cpp::items::join_parts_f(acc_p8, q_p9)));
        let complete_p4 = crate::prelude::fold(&members_p2, &crate::prelude::Array::new(), &(|acc_pa: &crate::prelude::Array<crate::prelude::Text>, (m_pb, _): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| crate::prelude::fold(&m_pb.complete_p, acc_pa, &(|a_pc: &crate::prelude::Array<crate::prelude::Text>, n_pd: &crate::prelude::Text| if among_f(a_pc, n_pd) || among_f(group_p1, n_pd) {
            a_pc.clone()
        } else {
            crate::prelude::push(a_pc, n_pd)
        }))));
        let declared_p5 = crate::prelude::fold(&members_p2, &crate::prelude::Array::new(), &(|acc_pe: &crate::prelude::Array<crate::prelude::Text>, (m_pf, _): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| crate::prelude::fold(&m_pf.declared_p, acc_pe, &(|a_pg: &crate::prelude::Array<crate::prelude::Text>, n_ph: &crate::prelude::Text| if (among_f(a_pg, n_ph) || among_f(group_p1, n_ph)) || among_f(&complete_p4, n_ph) {
            a_pg.clone()
        } else {
            crate::prelude::push(a_pg, n_ph)
        }))));
        let title_p6 = crate::prelude::Text::from(format!("The modules {}", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(group_p1, &(|n_pi: &crate::prelude::Text| crate::prelude::Text::from(format!("`{}`", n_pi)))), &crate::prelude::Text::lit(", "))));
        let group_p1x = group_p1.clone();
        crate::prelude::call_then(start_types_header_f(title_p6.clone(), group_p1x.clone(), declared_p5.clone(), complete_p4.clone(), p_p3.clone()), move |types_header_f_15942: crate::prelude::Text| ::prism_rtl::Turn::Finished((crate::prelude::Text::from(format!("src/{}.types.hpp", &group_name_f(&group_p1x))), types_header_f_15942)))
    }
}

/// `Start GroupTypesFile, x`: what the function value is when passed to `@Run`.
pub fn start_group_types_file_f(pairs_p0: crate::prelude::Array<(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)>, group_p1: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::prelude::Text)>> {
    ::std::rc::Rc::new(GroupTypesFile { pairs_p0, group_p1 })
}

/// ```prism
/// GroupName: fn [Text] -> Text
/// ```
pub fn group_name_f(group_p0: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::each(group_p0, &(|n_p1: &crate::prelude::Text| crate::syntax::lexer::chars::join_f(&crate::prelude::split_on(n_p1, &crate::prelude::Text::lit("::")), &crate::prelude::Text::lit("_")))), &crate::prelude::Text::lit("-"))
}

/// ```prism
/// ModDir: fn Text -> Text
/// ```
pub fn mod_dir_f(m_p0: &crate::prelude::Text) -> crate::prelude::Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::split_on(m_p0, &crate::prelude::Text::lit("::")), &crate::prelude::Text::lit("/"))
}

/// ```prism
/// Among: fn [Text], Text -> Bool
/// ```
pub fn among_f(xs_p0: &crate::prelude::Array<crate::prelude::Text>, x_p1: &crate::prelude::Text) -> bool {
    crate::prelude::fold(xs_p0, &false, &(|f_p2: &bool, y_p3: &crate::prelude::Text| *f_p2 || (y_p3 == x_p1)))
}

/// ```prism
/// TypesHeader: unbounded fn Text, [Text], [Text], [Text], Parts -> Text
/// ```
pub fn types_header_f(title_p0: &crate::prelude::Text, members_p1: &crate::prelude::Array<crate::prelude::Text>, declared_p2: &crate::prelude::Array<crate::prelude::Text>, complete_p3: &crate::prelude::Array<crate::prelude::Text>, p_p4: &crate::emit::cpp::items::Parts) -> crate::prelude::Text {
    let holds_elem_p5 = crate::prelude::fold(&p_p4.values_p, &false, &(|f_p9: &bool, v_pa: &crate::emit::cpp::items::ValueDecl| *f_p9 || crate::prelude::fold(&v_pa.deps_p, &false, &(|g_pb: &bool, d_pc: &crate::prelude::Text| (*g_pb || (d_pc == &crate::prelude::Text::lit("Elem"))) || (d_pc == &crate::prelude::Text::lit("Answer"))))));
    let elem_p6 = if holds_elem_p5 {
        crate::prelude::Text::lit("#include \"elem.types.hpp\"")
    } else {
        crate::prelude::Text::lit("#include \"elem.decl.hpp\"")
    };
    let includes_p7 = crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::Array::from(vec![includes_f(&crate::prelude::Text::lit("decl"), members_p1), elem_p6.clone(), includes_f(&crate::prelude::Text::lit("decl"), declared_p2), includes_f(&crate::prelude::Text::lit("types"), complete_p3)]), &(|t_pd: &crate::prelude::Text| t_pd != &crate::prelude::Text::lit(""))), &crate::prelude::Text::lit("\n"));
    let values_p8 = crate::syntax::lexer::chars::join_f(&order_values_f(&p_p4.values_p, &crate::prelude::fold(&p_p4.values_p, &crate::prelude::Map::new(), &(|acc_pe: &crate::prelude::Map<crate::prelude::Text, bool>, v_pf: &crate::emit::cpp::items::ValueDecl| crate::prelude::insert(acc_pe, &v_pf.path_p, &false))), &crate::prelude::Array::new()), &crate::prelude::Text::lit("\n\n"));
    crate::emit::cpp::templates::cpp_types_header_f(title_p0, &includes_p7, &values_p8)
}

/// The step machine of `TypesHeader`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypesHeader: unbounded fn Text, [Text], [Text], [Text], Parts -> Text
/// ```
pub struct TypesHeader {
    pub title_p0: crate::prelude::Text,
    pub members_p1: crate::prelude::Array<crate::prelude::Text>,
    pub declared_p2: crate::prelude::Array<crate::prelude::Text>,
    pub complete_p3: crate::prelude::Array<crate::prelude::Text>,
    pub p_p4: crate::emit::cpp::items::Parts,
}

impl ::prism_rtl::Job<crate::prelude::Text> for TypesHeader {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let title_p0 = &self.title_p0;
        let members_p1 = &self.members_p1;
        let declared_p2 = &self.declared_p2;
        let complete_p3 = &self.complete_p3;
        let p_p4 = &self.p_p4;
        let holds_elem_p5 = crate::prelude::fold(&p_p4.values_p, &false, &(|f_p9: &bool, v_pa: &crate::emit::cpp::items::ValueDecl| *f_p9 || crate::prelude::fold(&v_pa.deps_p, &false, &(|g_pb: &bool, d_pc: &crate::prelude::Text| (*g_pb || (d_pc == &crate::prelude::Text::lit("Elem"))) || (d_pc == &crate::prelude::Text::lit("Answer"))))));
        let elem_p6 = if holds_elem_p5 {
            crate::prelude::Text::lit("#include \"elem.types.hpp\"")
        } else {
            crate::prelude::Text::lit("#include \"elem.decl.hpp\"")
        };
        let includes_p7 = crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::Array::from(vec![includes_f(&crate::prelude::Text::lit("decl"), members_p1), elem_p6.clone(), includes_f(&crate::prelude::Text::lit("decl"), declared_p2), includes_f(&crate::prelude::Text::lit("types"), complete_p3)]), &(|t_pd: &crate::prelude::Text| t_pd != &crate::prelude::Text::lit(""))), &crate::prelude::Text::lit("\n"));
        let p_p4x = p_p4.clone();
        let title_p0x = title_p0.clone();
        crate::prelude::call_then(start_order_values_f(p_p4x.values_p.clone(), crate::prelude::fold(&p_p4x.values_p, &crate::prelude::Map::new(), &(|acc_pe: &crate::prelude::Map<crate::prelude::Text, bool>, v_pf: &crate::emit::cpp::items::ValueDecl| crate::prelude::insert(acc_pe, &v_pf.path_p, &false))), crate::prelude::Array::new()), move |order_values_f_17324: crate::prelude::Array<crate::prelude::Text>| {
            let values_p8 = crate::syntax::lexer::chars::join_f(&order_values_f_17324, &crate::prelude::Text::lit("\n\n"));
            ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::cpp_types_header_f(&title_p0x, &includes_p7, &values_p8))
        })
    }
}

/// `Start TypesHeader, x`: what the function value is when passed to `@Run`.
pub fn start_types_header_f(title_p0: crate::prelude::Text, members_p1: crate::prelude::Array<crate::prelude::Text>, declared_p2: crate::prelude::Array<crate::prelude::Text>, complete_p3: crate::prelude::Array<crate::prelude::Text>, p_p4: crate::emit::cpp::items::Parts) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(TypesHeader { title_p0, members_p1, declared_p2, complete_p3, p_p4 })
}

/// ```prism
/// Includes: fn Text, [Text] -> Text
/// ```
pub fn includes_f(layer_p0: &crate::prelude::Text, ms_p1: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::each(ms_p1, &(|m_p2: &crate::prelude::Text| crate::prelude::Text::from(format!("#include <{}/{}.hpp>", &mod_dir_f(m_p2), &(if layer_p0 == &crate::prelude::Text::lit("") {
        crate::prelude::Text::lit("module")
    } else {
        layer_p0.clone()
    }))))), &crate::prelude::Text::lit("\n"))
}

/// ```prism
/// Chunks: fn [Text] -> [ [Text] ]
/// ```
pub fn chunks_f(defs_p0: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>> {
    let (done_p5, current_p6, size_p7) = crate::prelude::fold(defs_p0, &(crate::prelude::Array::new(), crate::prelude::Array::new(), crate::prelude::Nat::from(0u32)), &(|(acc_p1, cur_p2, n_p3): &(crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>, crate::prelude::Array<crate::prelude::Text>, crate::prelude::Nat), d_p4: &crate::prelude::Text| if (n_p3 > &chunk_size_p()) && (&crate::prelude::len(cur_p2) > &crate::prelude::Nat::from(0u32)) {
        (crate::prelude::push(acc_p1, cur_p2), crate::prelude::Array::from(vec![d_p4.clone()]), crate::prelude::len_text(d_p4))
    } else {
        (acc_p1.clone(), crate::prelude::push(cur_p2, d_p4), n_p3 + &crate::prelude::len_text(d_p4))
    }));
    if (&crate::prelude::len(&current_p6) == &crate::prelude::Nat::from(0u32)) && (&crate::prelude::len(&done_p5) > &crate::prelude::Nat::from(0u32)) {
        done_p5.clone()
    } else {
        crate::prelude::push(&done_p5, &current_p6)
    }
}

/// ```prism
/// let chunkSize
/// ```
pub fn chunk_size_p() -> crate::prelude::Nat {
    crate::prelude::Nat::from(250000u32)
}

/// ```prism
/// ModuleFiles: unbounded fn ModDef, Parts -> (([((Text, Text))], [Piece]))
/// ```
pub fn module_files_f(m_p0: &crate::lower::model::ModDef, p_p1: &crate::emit::cpp::items::Parts) -> (crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::prelude::Array<Piece>) {
    let title_p2 = if &m_p0.prism_p == &crate::prelude::Text::lit("") {
        crate::prelude::Text::lit("The root module")
    } else {
        crate::prelude::Text::from(format!("The module `{}`", &m_p0.prism_p))
    };
    let needed_p3 = crate::prelude::append(&m_p0.complete_p, &m_p0.declared_p);
    let decl_p4 = crate::emit::cpp::templates::cpp_decl_header_f(&title_p2, &crate::prelude::Text::lit(""), &crate::syntax::lexer::chars::join_f(&p_p1.forward_p, &crate::prelude::Text::lit("\n\n")));
    let types_p5 = if &crate::prelude::len(&m_p0.types_with_p) > &crate::prelude::Nat::from(1u32) {
        crate::emit::cpp::templates::cpp_types_in_group_f(&title_p2, &group_name_f(&m_p0.types_with_p))
    } else {
        types_header_f(&title_p2, &crate::prelude::Array::from(vec![m_p0.name_p.clone()]), &m_p0.declared_p, &m_p0.complete_p, p_p1)
    };
    let head_includes_p6 = crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("{}\n#include \"elem.types.hpp\"", &includes_f(&crate::prelude::Text::lit("types"), &crate::prelude::Array::from(vec![m_p0.name_p.clone()])))), includes_f(&crate::prelude::Text::lit("types"), &needed_p3)]), &(|t_pd: &crate::prelude::Text| t_pd != &crate::prelude::Text::lit(""))), &crate::prelude::Text::lit("\n"));
    let head_p7 = crate::emit::cpp::templates::cpp_mod_header_f(&title_p2, &head_includes_p6, &crate::syntax::lexer::chars::join_f(&p_p1.protos_p, &crate::prelude::Text::lit("\n")), &crate::syntax::lexer::chars::join_f(&p_p1.outer_p, &crate::prelude::Text::lit("\n\n")), &crate::syntax::lexer::chars::join_f(&p_p1.classes_p, &crate::prelude::Text::lit("\n\n")));
    let with_mine_p8 = crate::prelude::append(&crate::prelude::Array::from(vec![m_p0.name_p.clone()]), &needed_p3);
    let generic_p9 = if &crate::prelude::len(&p_p1.generic_p) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Array::new()
    } else {
        crate::prelude::Array::from(vec![(crate::prelude::Text::from(format!("src/{}/generic.hpp", &mod_dir_f(&m_p0.name_p))), crate::emit::cpp::templates::cpp_generic_header_f(&title_p2, &includes_f(&crate::prelude::Text::lit(""), &with_mine_p8), &crate::syntax::lexer::chars::join_f(&p_p1.generic_p, &crate::prelude::Text::lit("\n\n"))))])
    };
    let chunks_pa = if &crate::prelude::len(&p_p1.defs_p) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Array::new()
    } else {
        chunks_f(&p_p1.defs_p)
    };
    let pieces_pb = crate::prelude::each(&chunks_pa, &(|c_pe: &crate::prelude::Array<crate::prelude::Text>| Piece { title_p: title_p2.clone(), prism_p: m_p0.prism_p.clone(), path_p: m_p0.path_p.clone(), ns_p: m_p0.name_p.clone(), needs_p: with_mine_p8.clone(), defs_p: crate::syntax::lexer::chars::join_f(c_pe, &crate::prelude::Text::lit("\n\n")) }));
    let dir_pc = mod_dir_f(&m_p0.name_p);
    (crate::prelude::append(&crate::prelude::Array::from(vec![(crate::prelude::Text::from(format!("src/{}/decl.hpp", &dir_pc)), decl_p4.clone()), (crate::prelude::Text::from(format!("src/{}/types.hpp", &dir_pc)), types_p5.clone()), (crate::prelude::Text::from(format!("src/{}/module.hpp", &dir_pc)), head_p7.clone())]), &generic_p9), pieces_pb.clone())
}

/// The step machine of `ModuleFiles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModuleFiles: unbounded fn ModDef, Parts -> (([((Text, Text))], [Piece]))
/// ```
pub struct ModuleFiles {
    pub m_p0: crate::lower::model::ModDef,
    pub p_p1: crate::emit::cpp::items::Parts,
}

impl ::prism_rtl::Job<(crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::prelude::Array<Piece>)> for ModuleFiles {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::prelude::Array<Piece>)> {
        let m_p0 = &self.m_p0;
        let p_p1 = &self.p_p1;
        let title_p2 = if &m_p0.prism_p == &crate::prelude::Text::lit("") {
            crate::prelude::Text::lit("The root module")
        } else {
            crate::prelude::Text::from(format!("The module `{}`", &m_p0.prism_p))
        };
        let needed_p3 = crate::prelude::append(&m_p0.complete_p, &m_p0.declared_p);
        let decl_p4 = crate::emit::cpp::templates::cpp_decl_header_f(&title_p2, &crate::prelude::Text::lit(""), &crate::syntax::lexer::chars::join_f(&p_p1.forward_p, &crate::prelude::Text::lit("\n\n")));
        let decl_p4z = decl_p4.clone();
        let m_p0z = m_p0.clone();
        let needed_p3z = needed_p3.clone();
        let p_p1z = p_p1.clone();
        let title_p2z = title_p2.clone();
        let k_let19173 = move |v19173: crate::prelude::Text| {
            let types_p5 = v19173;
            let head_includes_p6 = crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("{}\n#include \"elem.types.hpp\"", &includes_f(&crate::prelude::Text::lit("types"), &crate::prelude::Array::from(vec![m_p0z.name_p.clone()])))), includes_f(&crate::prelude::Text::lit("types"), &needed_p3z)]), &(|t_pd: &crate::prelude::Text| t_pd != &crate::prelude::Text::lit(""))), &crate::prelude::Text::lit("\n"));
            let head_p7 = crate::emit::cpp::templates::cpp_mod_header_f(&title_p2z, &head_includes_p6, &crate::syntax::lexer::chars::join_f(&p_p1z.protos_p, &crate::prelude::Text::lit("\n")), &crate::syntax::lexer::chars::join_f(&p_p1z.outer_p, &crate::prelude::Text::lit("\n\n")), &crate::syntax::lexer::chars::join_f(&p_p1z.classes_p, &crate::prelude::Text::lit("\n\n")));
            let with_mine_p8 = crate::prelude::append(&crate::prelude::Array::from(vec![m_p0z.name_p.clone()]), &needed_p3z);
            let generic_p9 = if &crate::prelude::len(&p_p1z.generic_p) == &crate::prelude::Nat::from(0u32) {
                crate::prelude::Array::new()
            } else {
                crate::prelude::Array::from(vec![(crate::prelude::Text::from(format!("src/{}/generic.hpp", &mod_dir_f(&m_p0z.name_p))), crate::emit::cpp::templates::cpp_generic_header_f(&title_p2z, &includes_f(&crate::prelude::Text::lit(""), &with_mine_p8), &crate::syntax::lexer::chars::join_f(&p_p1z.generic_p, &crate::prelude::Text::lit("\n\n"))))])
            };
            let chunks_pa = if &crate::prelude::len(&p_p1z.defs_p) == &crate::prelude::Nat::from(0u32) {
                crate::prelude::Array::new()
            } else {
                chunks_f(&p_p1z.defs_p)
            };
            let pieces_pb = crate::prelude::each(&chunks_pa, &(|c_pe: &crate::prelude::Array<crate::prelude::Text>| Piece { title_p: title_p2z.clone(), prism_p: m_p0z.prism_p.clone(), path_p: m_p0z.path_p.clone(), ns_p: m_p0z.name_p.clone(), needs_p: with_mine_p8.clone(), defs_p: crate::syntax::lexer::chars::join_f(c_pe, &crate::prelude::Text::lit("\n\n")) }));
            let dir_pc = mod_dir_f(&m_p0z.name_p);
            ::prism_rtl::Turn::Finished((crate::prelude::append(&crate::prelude::Array::from(vec![(crate::prelude::Text::from(format!("src/{}/decl.hpp", &dir_pc)), decl_p4z.clone()), (crate::prelude::Text::from(format!("src/{}/types.hpp", &dir_pc)), types_p5.clone()), (crate::prelude::Text::from(format!("src/{}/module.hpp", &dir_pc)), head_p7.clone())]), &generic_p9), pieces_pb.clone()))
        };
        if &crate::prelude::len(&m_p0.types_with_p) > &crate::prelude::Nat::from(1u32) {
            k_let19173(crate::emit::cpp::templates::cpp_types_in_group_f(&title_p2, &group_name_f(&m_p0.types_with_p)))
        } else {
            {
                let m_p0x = m_p0.clone();
                let p_p1x = p_p1.clone();
                crate::prelude::call_then(start_types_header_f(title_p2.clone(), crate::prelude::Array::from(vec![m_p0x.name_p.clone()]), m_p0x.declared_p.clone(), m_p0x.complete_p.clone(), p_p1x.clone()), move |types_header_f_19264: crate::prelude::Text| k_let19173(types_header_f_19264))
            }
        }
    }
}

/// `Start ModuleFiles, x`: what the function value is when passed to `@Run`.
pub fn start_module_files_f(m_p0: crate::lower::model::ModDef, p_p1: crate::emit::cpp::items::Parts) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>, crate::prelude::Array<Piece>)>> {
    ::std::rc::Rc::new(ModuleFiles { m_p0, p_p1 })
}

/// ```prism
/// Units: fn [Piece] -> [ [Piece] ]
/// ```
pub fn units_f(pieces_p0: &crate::prelude::Array<Piece>) -> crate::prelude::Array<crate::prelude::Array<Piece>> {
    let (done_p5, current_p6, size_p7) = crate::prelude::fold(pieces_p0, &(crate::prelude::Array::new(), crate::prelude::Array::new(), crate::prelude::Nat::from(0u32)), &(|(acc_p1, cur_p2, n_p3): &(crate::prelude::Array<crate::prelude::Array<Piece>>, crate::prelude::Array<Piece>, crate::prelude::Nat), pc_p4: &Piece| if (&crate::prelude::len(cur_p2) > &crate::prelude::Nat::from(0u32)) && (&(n_p3 + &crate::prelude::len_text(&pc_p4.defs_p)) > &unit_size_p()) {
        (crate::prelude::push(acc_p1, cur_p2), crate::prelude::Array::from(vec![pc_p4.clone()]), crate::prelude::len_text(&pc_p4.defs_p))
    } else {
        (acc_p1.clone(), crate::prelude::push(cur_p2, pc_p4), n_p3 + &crate::prelude::len_text(&pc_p4.defs_p))
    }));
    if &crate::prelude::len(&current_p6) == &crate::prelude::Nat::from(0u32) {
        done_p5.clone()
    } else {
        crate::prelude::push(&done_p5, &current_p6)
    }
}

/// ```prism
/// let unitSize
/// ```
pub fn unit_size_p() -> crate::prelude::Nat {
    crate::prelude::Nat::from(125000u32)
}

/// ```prism
/// UnitFile: fn Nat, [Piece], [Text] -> ((Text, Text))
/// ```
pub fn unit_file_f(k_p0: &crate::prelude::Nat, pieces_p1: &crate::prelude::Array<Piece>, generics_p2: &crate::prelude::Array<crate::prelude::Text>) -> (crate::prelude::Text, crate::prelude::Text) {
    let needs_p3 = crate::prelude::fold(pieces_p1, &crate::prelude::Array::new(), &(|acc_p8: &crate::prelude::Array<crate::prelude::Text>, pc_p9: &Piece| crate::prelude::fold(&pc_p9.needs_p, acc_p8, &(|a_pa: &crate::prelude::Array<crate::prelude::Text>, n_pb: &crate::prelude::Text| if among_f(a_pa, n_pb) { a_pa.clone() } else { crate::prelude::push(a_pa, n_pb) }))));
    let includes_p4 = crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::Array::from(vec![includes_f(&crate::prelude::Text::lit(""), &needs_p3), includes_f(&crate::prelude::Text::lit("generic"), &crate::prelude::filter(&needs_p3, &(|n_pc: &crate::prelude::Text| among_f(generics_p2, n_pc))))]), &(|t_pd: &crate::prelude::Text| t_pd != &crate::prelude::Text::lit(""))), &crate::prelude::Text::lit("\n"));
    let names_p5 = crate::prelude::fold(pieces_p1, &crate::prelude::Array::new(), &(|acc_pe: &crate::prelude::Array<crate::prelude::Text>, pc_pf: &Piece| if among_f(acc_pe, &pc_pf.prism_p) {
        acc_pe.clone()
    } else {
        crate::prelude::push(acc_pe, &pc_pf.prism_p)
    }));
    let title_p6 = if &crate::prelude::len(&names_p5) == &crate::prelude::Nat::from(1u32) {
        crate::prelude::or(&crate::prelude::index(pieces_p1, &crate::prelude::Nat::from(0u32)), &dummy_piece_p()).title_p.clone()
    } else {
        crate::prelude::Text::from(format!("The modules {}", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&names_p5, &(|n_pg: &crate::prelude::Text| if n_pg == &crate::prelude::Text::lit("") {
            crate::prelude::Text::lit("the root")
        } else {
            crate::prelude::Text::from(format!("`{}`", n_pg))
        })), &crate::prelude::Text::lit(", "))))
    };
    let parts_p7 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(pieces_p1, &(|pc_ph: &Piece| crate::emit::cpp::templates::cpp_unit_part_f(&pc_ph.title_p, &pc_ph.path_p, &pc_ph.ns_p, &pc_ph.defs_p))), &crate::prelude::Text::lit("\n\n"));
    (crate::prelude::Text::from(format!("src/unit_{}.cpp", &(k_p0 + &crate::prelude::Nat::from(1u32)))), crate::emit::cpp::templates::cpp_unit_f(&title_p6, &includes_p4, &parts_p7))
}

/// ```prism
/// let dummyPiece
/// ```
pub fn dummy_piece_p() -> Piece {
    Piece { title_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), path_p: crate::prelude::Text::lit(""), ns_p: crate::prelude::Text::lit(""), needs_p: crate::prelude::Array::new(), defs_p: crate::prelude::Text::lit("") }
}

/// ```prism
/// AllProgramsCpp: fn Model -> [ProgDef]
/// ```
pub fn all_programs_cpp_f(model_p0: &crate::lower::model::Model) -> crate::prelude::Array<crate::lower::model::ProgDef> {
    match &model_p0.root_o {
        ::std::option::Option::Some(r_p1) => if crate::prelude::fold(&model_p0.programs_p, &false, &(|f_p2: &bool, p_p3: &crate::lower::model::ProgDef| *f_p2 || (&p_p3.name_p == &r_p1.name_p))) {
            model_p0.programs_p.clone()
        } else {
            crate::prelude::push(&model_p0.programs_p, r_p1)
        },
        ::std::option::Option::None => model_p0.programs_p.clone(),
    }
}

/// ```prism
/// OrderValues: unbounded fn [ValueDecl], (Text ==> Bool), [Text] -> [Text]
/// ```
pub fn order_values_f(left_p0: &crate::prelude::Array<crate::emit::cpp::items::ValueDecl>, done_p1: &crate::prelude::Map<crate::prelude::Text, bool>, acc_p2: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<crate::prelude::Text> {
    let ready_p3 = crate::prelude::filter(left_p0, &(|v_p4: &crate::emit::cpp::items::ValueDecl| crate::prelude::fold(&v_p4.deps_p, &true, &(|ok_p5: &bool, d_p6: &crate::prelude::Text| *ok_p5 && ((d_p6 == &v_p4.path_p) || declared_f(done_p1, d_p6))))));
    if &crate::prelude::len(left_p0) == &crate::prelude::Nat::from(0u32) {
        acc_p2.clone()
    } else {
        if &crate::prelude::len(&ready_p3) == &crate::prelude::Nat::from(0u32) {
            crate::prelude::append(acc_p2, &crate::prelude::each(left_p0, &(|v_p7: &crate::emit::cpp::items::ValueDecl| v_p7.text_p.clone())))
        } else {
            {
                let later_p8 = crate::prelude::filter(left_p0, &(|v_pa: &crate::emit::cpp::items::ValueDecl| !crate::prelude::fold(&v_pa.deps_p, &true, &(|ok_pb: &bool, d_pc: &crate::prelude::Text| *ok_pb && ((d_pc == &v_pa.path_p) || declared_f(done_p1, d_pc))))));
                let done2_p9 = crate::prelude::fold(&ready_p3, done_p1, &(|m_pd: &crate::prelude::Map<crate::prelude::Text, bool>, v_pe: &crate::emit::cpp::items::ValueDecl| crate::prelude::insert(m_pd, &v_pe.path_p, &true)));
                order_values_f(&later_p8, &done2_p9, &crate::prelude::append(acc_p2, &crate::prelude::each(&ready_p3, &(|v_pf: &crate::emit::cpp::items::ValueDecl| v_pf.text_p.clone()))))
            }
        }
    }
}

/// The step machine of `OrderValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OrderValues: unbounded fn [ValueDecl], (Text ==> Bool), [Text] -> [Text]
/// ```
pub struct OrderValues {
    pub left_p0: crate::prelude::Array<crate::emit::cpp::items::ValueDecl>,
    pub done_p1: crate::prelude::Map<crate::prelude::Text, bool>,
    pub acc_p2: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for OrderValues {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let left_p0 = &self.left_p0;
        let done_p1 = &self.done_p1;
        let acc_p2 = &self.acc_p2;
        let ready_p3 = crate::prelude::filter(left_p0, &(|v_p4: &crate::emit::cpp::items::ValueDecl| crate::prelude::fold(&v_p4.deps_p, &true, &(|ok_p5: &bool, d_p6: &crate::prelude::Text| *ok_p5 && ((d_p6 == &v_p4.path_p) || declared_f(done_p1, d_p6))))));
        if &crate::prelude::len(left_p0) == &crate::prelude::Nat::from(0u32) {
            ::prism_rtl::Turn::Finished(acc_p2.clone())
        } else {
            if &crate::prelude::len(&ready_p3) == &crate::prelude::Nat::from(0u32) {
                ::prism_rtl::Turn::Finished(crate::prelude::append(acc_p2, &crate::prelude::each(left_p0, &(|v_p7: &crate::emit::cpp::items::ValueDecl| v_p7.text_p.clone()))))
            } else {
                {
                    let later_p8 = crate::prelude::filter(left_p0, &(|v_pa: &crate::emit::cpp::items::ValueDecl| !crate::prelude::fold(&v_pa.deps_p, &true, &(|ok_pb: &bool, d_pc: &crate::prelude::Text| *ok_pb && ((d_pc == &v_pa.path_p) || declared_f(done_p1, d_pc))))));
                    let done2_p9 = crate::prelude::fold(&ready_p3, done_p1, &(|m_pd: &crate::prelude::Map<crate::prelude::Text, bool>, v_pe: &crate::emit::cpp::items::ValueDecl| crate::prelude::insert(m_pd, &v_pe.path_p, &true)));
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(OrderValues { left_p0: later_p8.clone(), done_p1: done2_p9.clone(), acc_p2: crate::prelude::append(acc_p2, &crate::prelude::each(&ready_p3, &(|v_pf: &crate::emit::cpp::items::ValueDecl| v_pf.text_p.clone()))) }))
                }
            }
        }
    }
}

/// `Start OrderValues, x`: what the function value is when passed to `@Run`.
pub fn start_order_values_f(left_p0: crate::prelude::Array<crate::emit::cpp::items::ValueDecl>, done_p1: crate::prelude::Map<crate::prelude::Text, bool>, acc_p2: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(OrderValues { left_p0, done_p1, acc_p2 })
}

/// ```prism
/// Declared: fn (Text ==> Bool), Text -> Bool
/// ```
pub fn declared_f(done_p0: &crate::prelude::Map<crate::prelude::Text, bool>, d_p1: &crate::prelude::Text) -> bool {
    match crate::prelude::get(done_p0, d_p1) {
        ::std::option::Option::Some(b_p2) => b_p2,
        ::std::option::Option::None => true,
    }
}

/// ```prism
/// MutableOf: fn OutTy -> Text
/// ```
pub fn mutable_of_f(out_ty0: &crate::lower::model::OutTy) -> crate::prelude::Text {
    match out_ty0 {
        crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(c0_0_0_0), _) if (c0_0_0_0 == &crate::prelude::Text::lit("std::Cell")) => crate::prelude::Text::lit("mutable "),
        other_p0 => crate::prelude::Text::lit(""),
        _ => unreachable!("no arm matched"),
    }
}
