//! The module `Emit.Cpp.Program`, from `target/bootstrap/src/prismc/emit/cpp/program.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Piece`:
///
/// ```prism
/// type Piece = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Piece {
    pub title: Text,
    pub prism: Text,
    pub path_: Text,
    pub ns: Text,
    pub needs: Array<Text>,
    pub defs: Text,
}

impl Show for Piece {
    fn show(&self, p: &mut Printer) {
        p.record("Piece", &[("title", &self.title), ("prism", &self.prism), ("path", &self.path_), ("ns", &self.ns), ("needs", &self.needs), ("defs", &self.defs)]);
    }
}

impl ToPod for Piece {
    fn to_pod(&self) -> Pod {
        Pod::record("Piece", vec![("title", self.title.to_pod()), ("prism", self.prism.to_pod()), ("path", self.path_.to_pod()), ("ns", self.ns.to_pod()), ("needs", self.needs.to_pod()), ("defs", self.defs.to_pod())])
    }
}

impl FromPod for Piece {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Piece { title: FromPod::from_pod(field(p, "title")?)?, prism: FromPod::from_pod(field(p, "prism")?)?, path_: FromPod::from_pod(field(p, "path")?)?, ns: FromPod::from_pod(field(p, "ns")?)?, needs: FromPod::from_pod(field(p, "needs")?)?, defs: FromPod::from_pod(field(p, "defs")?)? })
    }
}

/// ```prism
/// NodeParts: unbounded fn Cp, NodeDef -> Parts
/// ```
pub fn node_parts(cp_p0: &crate::emit::cpp::Cp, n_p1: &crate::lower::model::NodeDef) -> crate::emit::cpp::items::Parts {
    let ncp_p2 = crate::emit::cpp::with_fields(cp_p0, &each(&n_p1.fields, &(|(f_pu, t_pv, _): &(Text, crate::lower::model::OutTy, Text)| (f_pu.clone(), t_pv.clone()))));
    let base_p3 = if (&n_p1.row_kind == &crate::lower::model::RowKind::NotARow) && (&len(&n_p1.hosted) == &Nat::from(0u32)) {
        Text::lit("Node")
    } else {
        Text::lit("Row")
    };
    let fields_p4 = crate::syntax::lexer::chars::join(&run_to_end(each_job(n_p1.fields.clone(), {
        let cp_p0 = cp_p0.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy, Text)| {
            let cp_p0 = cp_p0.clone();
            entered(once_job(move || {
                let (f_p10, t_p11, doc_p12) = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), t_p11.clone()), move |cpp_type_1357: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{} {};", &crate::emit::cpp::items::cpp_doc(&doc_p12), &cpp_type_1357, &crate::emit::cpp::field_id(&f_p10)))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let consts_p5 = crate::syntax::lexer::chars::join(&each(&n_p1.consts, &(|(c_p13, h_p14, doc_p15): &(Text, Nat, Text)| Text::from(format!("{}static constexpr std::uint32_t {} = {};", &crate::emit::cpp::items::cpp_doc(&Text::from(format!("The {}.", doc_p15))), c_p13, h_p14)))), &Text::lit("\n"));
    let ctor_params_p6 = crate::syntax::lexer::chars::join(&append(&Array::from(vec![Text::lit("Path path")]), &run_to_end(each_job(n_p1.fields.clone(), {
        let cp_p0 = cp_p0.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy, Text)| {
            let cp_p0 = cp_p0.clone();
            entered(once_job(move || {
                let (f_p16, t_p17, _) = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), t_p17.clone()), move |cpp_type_1609: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_1609, &crate::emit::cpp::field_id(&f_p16)))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
    }))), &Text::lit(", "));
    let ctor_inits_p7 = crate::syntax::lexer::chars::join(&append(&Array::from(vec![Text::lit("path(std::move(path))")]), &each(&n_p1.fields, &(|(f_p18, _, _): &(Text, crate::lower::model::OutTy, Text)| Text::from(format!("{}(std::move({}))", &crate::emit::cpp::field_id(f_p18), &crate::emit::cpp::field_id(f_p18)))))), &Text::lit(", "));
    let params_p8 = concat(&run_to_end(each_job(n_p1.params.clone(), {
        let cp_p0 = cp_p0.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
            let cp_p0 = cp_p0.clone();
            entered(once_job(move || {
                let (p_p19, t_p1a) = p0;
                call_then(crate::emit::cpp::expr::start_param_type(cp_p0.clone(), t_p1a.clone()), move |param_type_1848: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}, ", &param_type_1848, &p_p19))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let ret_p9 = if n_p1.fallible {
        Text::from(format!("Result<prism_rtl::Rc<{}>>", &n_p1.name))
    } else {
        Text::from(format!("prism_rtl::Rc<{}>", &n_p1.name))
    };
    let make_decl_pa = Text::from(format!("static {} make(Path path, {}Cx& cx);", &ret_p9, &params_p8));
    let method_decls_pb = run_to_end(each_job(append(&n_p1.methods, &n_p1.hosted), {
        let ncp_p2 = ncp_p2.clone();
        Rc::new(move |p0: crate::lower::model::MethDef| {
            let ncp_p2 = ncp_p2.clone();
            entered(once_job(move || {
                let m_p1b = p0;
                call_then(start_method_sig(ncp_p2.clone(), m_p1b.clone(), Text::lit("")), move |method_sig_2099: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &method_sig_2099))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let builder_decls_pc = append(&each(&n_p1.builders, &(|b_p1c: &crate::lower::model::ForDef| Text::from(format!("Done {}_build(Cx& cx);", &b_p1c.name)))), &each(&n_p1.gens, &(|g_p1d: &crate::lower::model::GenDef| Text::from(format!("Done {}_build(Cx& cx);", &g_p1d.name)))));
    let hook_decls_pd = each(&n_p1.hooks, &(|(h_p1e, _): &(Text, Array<crate::lower::model::Do>)| Text::from(format!("{} override;", &hook_sig(h_p1e, &Text::lit(""))))));
    let answer_decl_pe = if &len(&n_p1.answers) == &Nat::from(0u32) {
        Array::new()
    } else {
        Array::from(vec![Text::lit("Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;")])
    };
    let row_decl_pf = if &n_p1.row_kind == &crate::lower::model::RowKind::NotARow {
        Array::new()
    } else {
        Array::from(vec![Text::lit("void leave_row(Cx& cx) override;")])
    };
    let decls_pg = crate::syntax::lexer::chars::join(&append(&append(&append(&append(&append(&Array::from(vec![make_decl_pa.clone()]), &method_decls_pb), &builder_decls_pc), &hook_decls_pd), &answer_decl_pe), &row_decl_pf), &Text::lit("\n"));
    let doc_ph = crate::emit::cpp::items::cpp_source_doc(&Text::from(format!("`{}`: a node of its own (claude/backend.md, \"A widget block\").", &n_p1.prism)), &n_p1.doc);
    let decl_pi = crate::emit::cpp::templates::items::node_class(&doc_ph, &n_p1.name, &base_p3, &fields_p4, &consts_p5, &Text::from(format!("{}({}) : {} {{}}", &n_p1.name, &ctor_params_p6, &ctor_inits_p7)), &decls_pg);
    let by_field_pj = each(&n_p1.fields, &(|(f_p1f, _, _): &(Text, crate::lower::model::OutTy, Text)| or(&fold(&n_p1.inits, &None, &(|found_o1g: &Option<crate::lower::model::Ex>, (g_p1h, v_p1i): &(Text, crate::lower::model::Ex)| if g_p1h == f_p1f { Some(v_p1i.clone()) } else { found_o1g.clone() })), &crate::lower::model::Ex::XVar(f_p1f.clone()))));
    let (lets_text_p1j, lcp_p1k) = crate::emit::cpp::stmts::cpp_statements_cp(&ncp_p2, &n_p1.lets);
    let args_pk = crate::syntax::lexer::chars::join(&append(&Array::from(vec![Text::lit("path")]), &run_to_end(each_job(by_field_pj.clone(), {
        let lcp_p1k = lcp_p1k.clone();
        Rc::new(move |p0: crate::lower::model::Ex| {
            let lcp_p1k = lcp_p1k.clone();
            entered(once_job(move || {
                let v_p1l = p0;
                prism_rtl::Turn::More(Rc::new(crate::emit::cpp::expr::CppExpr { cp_p0: lcp_p1k.clone(), x_p1: v_p1l.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
    }))), &Text::lit(", "));
    let tail_pl = if n_p1.fallible { Text::lit("return node;") } else { Text::lit("return node;") };
    let make_pm = crate::emit::cpp::templates::items::node_make(&n_p1.name, &Text::from(format!("{} {}::make(Path path, {}Cx& cx)", &ret_p9, &n_p1.name, &params_p8)), &lets_text_p1j, &args_pk, &crate::syntax::lexer::chars::join(&filter(&Array::from(vec![crate::emit::cpp::stmts::cpp_statements(&crate::emit::cpp::stmts::pointing(&lcp_p1k, &Text::lit("node")), &n_p1.build), tail_pl.clone()]), &(|s_p1m: &Text| s_p1m != &Text::lit(""))), &Text::lit("\n")));
    let methods_pn = run_to_end(each_job(append(&n_p1.methods, &n_p1.hosted), {
        let ncp_p2 = ncp_p2.clone();
        let n_p1 = n_p1.clone();
        Rc::new(move |p0: crate::lower::model::MethDef| {
            let ncp_p2 = ncp_p2.clone();
            let n_p1 = n_p1.clone();
            entered(once_job(move || {
                let m_p1n = p0;
                prism_rtl::Turn::More(Rc::new(MethodDef { cp_p0: ncp_p2.clone(), owner_p1: n_p1.name.clone(), m_p2: m_p1n.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let builders_po = append(&run_to_end(each_job(n_p1.builders.clone(), {
        let ncp_p2 = ncp_p2.clone();
        let n_p1 = n_p1.clone();
        Rc::new(move |p0: crate::lower::model::ForDef| {
            let ncp_p2 = ncp_p2.clone();
            let n_p1 = n_p1.clone();
            entered(once_job(move || {
                let b_p1o = p0;
                prism_rtl::Turn::More(Rc::new(ForBuildCpp { cp_p0: ncp_p2.clone(), owner_p1: n_p1.name.clone(), b_p2: b_p1o.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::ForDef) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &run_to_end(each_job(n_p1.gens.clone(), {
        let ncp_p2 = ncp_p2.clone();
        let n_p1 = n_p1.clone();
        Rc::new(move |p0: crate::lower::model::GenDef| {
            let ncp_p2 = ncp_p2.clone();
            let n_p1 = n_p1.clone();
            entered(once_job(move || {
                let g_p1p = p0;
                prism_rtl::Turn::More(Rc::new(GenBuildCpp { cp_p0: ncp_p2.clone(), owner_p1: n_p1.name.clone(), gd_p2: g_p1p.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::GenDef) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let hooks_pp = run_to_end(each_job(n_p1.hooks.clone(), {
        let n_p1 = n_p1.clone();
        let ncp_p2 = ncp_p2.clone();
        Rc::new(move |p0: (Text, Array<crate::lower::model::Do>)| {
            let n_p1 = n_p1.clone();
            let ncp_p2 = ncp_p2.clone();
            entered(once_job(move || {
                let (h_p1q, body_p1r) = p0;
                call_then(crate::emit::cpp::stmts::start_cpp_statements(ncp_p2.clone(), body_p1r.clone()), move |cpp_statements_3838: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &hook_sig(&h_p1q, &Text::from(format!("{}::", &n_p1.name))), &Text::from(format!("{}\nreturn {{}};", &cpp_statements_3838)))))
            }))
        }) as Rc<dyn Fn((Text, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let answer_pq = if &len(&n_p1.answers) == &Nat::from(0u32) {
        Array::new()
    } else {
        Array::from(vec![answer_def_cpp(&ncp_p2, n_p1)])
    };
    let leaving_pr = if &n_p1.row_kind == &crate::lower::model::RowKind::NotARow {
        Array::new()
    } else {
        Array::from(vec![row_leaving(&ncp_p2, n_p1)])
    };
    let defs_ps = append(&append(&append(&append(&append(&Array::from(vec![make_pm.clone()]), &methods_pn), &builders_po), &hooks_pp), &answer_pq), &leaving_pr);
    let own_pt = crate::emit::cpp::items::Parts { forward: Array::from(vec![Text::from(format!("class {};", &n_p1.name))]), values: Array::new(), protos: Array::new(), classes: Array::from(vec![decl_pi.clone()]), outer: Array::new(), generic: Array::new(), defs: defs_ps.clone() };
    own_pt.clone()
}

/// The step machine of `NodeParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NodeParts: unbounded fn Cp, NodeDef -> Parts
/// ```
pub struct NodeParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub n_p1: crate::lower::model::NodeDef,
}

impl prism_rtl::Job<crate::emit::cpp::items::Parts> for NodeParts {
    fn cycle(&self) -> prism_rtl::Turn<crate::emit::cpp::items::Parts> {
        let cp_p0 = &self.cp_p0;
        let n_p1 = &self.n_p1;
        let ncp_p2 = crate::emit::cpp::with_fields(cp_p0, &each(&n_p1.fields, &(|(f_pu, t_pv, _): &(Text, crate::lower::model::OutTy, Text)| (f_pu.clone(), t_pv.clone()))));
        let base_p3 = if (&n_p1.row_kind == &crate::lower::model::RowKind::NotARow) && (&len(&n_p1.hosted) == &Nat::from(0u32)) {
            Text::lit("Node")
        } else {
            Text::lit("Row")
        };
        let cp_p0 = cp_p0.clone();
        let n_p1 = n_p1.clone();
        call_value(each_job(n_p1.fields.clone(), {
            let cp_p0 = cp_p0.clone();
            Rc::new(move |p0: (Text, crate::lower::model::OutTy, Text)| {
                let cp_p0 = cp_p0.clone();
                entered(once_job(move || {
                    let (f_p10, t_p11, doc_p12) = p0;
                    call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), t_p11.clone()), move |cpp_type_1357: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{} {};", &crate::emit::cpp::items::cpp_doc(&doc_p12), &cpp_type_1357, &crate::emit::cpp::field_id(&f_p10)))))
                }))
            }) as Rc<dyn Fn((Text, crate::lower::model::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_1311: Array<Text>| {
            let fields_p4 = crate::syntax::lexer::chars::join(&each_1311, &Text::lit("\n"));
            let consts_p5 = crate::syntax::lexer::chars::join(&each(&n_p1.consts, &(|(c_p13, h_p14, doc_p15): &(Text, Nat, Text)| Text::from(format!("{}static constexpr std::uint32_t {} = {};", &crate::emit::cpp::items::cpp_doc(&Text::from(format!("The {}.", doc_p15))), c_p13, h_p14)))), &Text::lit("\n"));
            call_value(each_job(n_p1.fields.clone(), {
                let cp_p0 = cp_p0.clone();
                Rc::new(move |p0: (Text, crate::lower::model::OutTy, Text)| {
                    let cp_p0 = cp_p0.clone();
                    entered(once_job(move || {
                        let (f_p16, t_p17, _) = p0;
                        call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), t_p17.clone()), move |cpp_type_1609: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_1609, &crate::emit::cpp::field_id(&f_p16)))))
                    }))
                }) as Rc<dyn Fn((Text, crate::lower::model::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_1572: Array<Text>| {
                let ctor_params_p6 = crate::syntax::lexer::chars::join(&append(&Array::from(vec![Text::lit("Path path")]), &each_1572), &Text::lit(", "));
                let ctor_inits_p7 = crate::syntax::lexer::chars::join(&append(&Array::from(vec![Text::lit("path(std::move(path))")]), &each(&n_p1.fields, &(|(f_p18, _, _): &(Text, crate::lower::model::OutTy, Text)| Text::from(format!("{}(std::move({}))", &crate::emit::cpp::field_id(f_p18), &crate::emit::cpp::field_id(f_p18)))))), &Text::lit(", "));
                call_value(each_job(n_p1.params.clone(), {
                    let cp_p0 = cp_p0.clone();
                    Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                        let cp_p0 = cp_p0.clone();
                        entered(once_job(move || {
                            let (p_p19, t_p1a) = p0;
                            call_then(crate::emit::cpp::expr::start_param_type(cp_p0.clone(), t_p1a.clone()), move |param_type_1848: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}, ", &param_type_1848, &p_p19))))
                        }))
                    }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_1819: Array<Text>| {
                    let params_p8 = concat(&each_1819);
                    let ret_p9 = if n_p1.fallible {
                        Text::from(format!("Result<prism_rtl::Rc<{}>>", &n_p1.name))
                    } else {
                        Text::from(format!("prism_rtl::Rc<{}>", &n_p1.name))
                    };
                    let make_decl_pa = Text::from(format!("static {} make(Path path, {}Cx& cx);", &ret_p9, &params_p8));
                    call_value(each_job(append(&n_p1.methods, &n_p1.hosted), {
                        let ncp_p2 = ncp_p2.clone();
                        Rc::new(move |p0: crate::lower::model::MethDef| {
                            let ncp_p2 = ncp_p2.clone();
                            entered(once_job(move || {
                                let m_p1b = p0;
                                call_then(start_method_sig(ncp_p2.clone(), m_p1b.clone(), Text::lit("")), move |method_sig_2099: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &method_sig_2099))))
                            }))
                        }) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>
                    }), move |each_2057: Array<Text>| {
                        let method_decls_pb = each_2057;
                        let builder_decls_pc = append(&each(&n_p1.builders, &(|b_p1c: &crate::lower::model::ForDef| Text::from(format!("Done {}_build(Cx& cx);", &b_p1c.name)))), &each(&n_p1.gens, &(|g_p1d: &crate::lower::model::GenDef| Text::from(format!("Done {}_build(Cx& cx);", &g_p1d.name)))));
                        let hook_decls_pd = each(&n_p1.hooks, &(|(h_p1e, _): &(Text, Array<crate::lower::model::Do>)| Text::from(format!("{} override;", &hook_sig(h_p1e, &Text::lit(""))))));
                        let answer_decl_pe = if &len(&n_p1.answers) == &Nat::from(0u32) {
                            Array::new()
                        } else {
                            Array::from(vec![Text::lit("Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;")])
                        };
                        let row_decl_pf = if &n_p1.row_kind == &crate::lower::model::RowKind::NotARow {
                            Array::new()
                        } else {
                            Array::from(vec![Text::lit("void leave_row(Cx& cx) override;")])
                        };
                        let decls_pg = crate::syntax::lexer::chars::join(&append(&append(&append(&append(&append(&Array::from(vec![make_decl_pa.clone()]), &method_decls_pb), &builder_decls_pc), &hook_decls_pd), &answer_decl_pe), &row_decl_pf), &Text::lit("\n"));
                        let doc_ph = crate::emit::cpp::items::cpp_source_doc(&Text::from(format!("`{}`: a node of its own (claude/backend.md, \"A widget block\").", &n_p1.prism)), &n_p1.doc);
                        let decl_pi = crate::emit::cpp::templates::items::node_class(&doc_ph, &n_p1.name, &base_p3, &fields_p4, &consts_p5, &Text::from(format!("{}({}) : {} {{}}", &n_p1.name, &ctor_params_p6, &ctor_inits_p7)), &decls_pg);
                        let by_field_pj = each(&n_p1.fields, &(|(f_p1f, _, _): &(Text, crate::lower::model::OutTy, Text)| or(&fold(&n_p1.inits, &None, &(|found_o1g: &Option<crate::lower::model::Ex>, (g_p1h, v_p1i): &(Text, crate::lower::model::Ex)| if g_p1h == f_p1f { Some(v_p1i.clone()) } else { found_o1g.clone() })), &crate::lower::model::Ex::XVar(f_p1f.clone()))));
                        call_then(crate::emit::cpp::stmts::start_cpp_statements_cp(ncp_p2.clone(), n_p1.lets.clone()), move |cpp_statements_cp_3170: (Text, crate::emit::cpp::Cp)| {
                            let (lets_text_p1j, lcp_p1k) = cpp_statements_cp_3170;
                            call_value(each_job(by_field_pj.clone(), {
                                let lcp_p1k = lcp_p1k.clone();
                                Rc::new(move |p0: crate::lower::model::Ex| {
                                    let lcp_p1k = lcp_p1k.clone();
                                    entered(once_job(move || {
                                        let v_p1l = p0;
                                        prism_rtl::Turn::More(Rc::new(crate::emit::cpp::expr::CppExpr { cp_p0: lcp_p1k.clone(), x_p1: v_p1l.clone() }))
                                    }))
                                }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
                            }), move |each_3239: Array<Text>| {
                                let args_pk = crate::syntax::lexer::chars::join(&append(&Array::from(vec![Text::lit("path")]), &each_3239), &Text::lit(", "));
                                let tail_pl = if n_p1.fallible { Text::lit("return node;") } else { Text::lit("return node;") };
                                call_then(crate::emit::cpp::stmts::start_cpp_statements(crate::emit::cpp::stmts::pointing(&lcp_p1k, &Text::lit("node")), n_p1.build.clone()), move |cpp_statements_3463: Text| {
                                    let make_pm = crate::emit::cpp::templates::items::node_make(&n_p1.name, &Text::from(format!("{} {}::make(Path path, {}Cx& cx)", &ret_p9, &n_p1.name, &params_p8)), &lets_text_p1j, &args_pk, &crate::syntax::lexer::chars::join(&filter(&Array::from(vec![cpp_statements_3463, tail_pl.clone()]), &(|s_p1m: &Text| s_p1m != &Text::lit(""))), &Text::lit("\n")));
                                    call_value(each_job(append(&n_p1.methods, &n_p1.hosted), {
                                        let ncp_p2 = ncp_p2.clone();
                                        let n_p1 = n_p1.clone();
                                        Rc::new(move |p0: crate::lower::model::MethDef| {
                                            let ncp_p2 = ncp_p2.clone();
                                            let n_p1 = n_p1.clone();
                                            entered(once_job(move || {
                                                let m_p1n = p0;
                                                prism_rtl::Turn::More(Rc::new(MethodDef { cp_p0: ncp_p2.clone(), owner_p1: n_p1.name.clone(), m_p2: m_p1n.clone() }))
                                            }))
                                        }) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>
                                    }), move |each_3558: Array<Text>| {
                                        let methods_pn = each_3558;
                                        call_value(each_job(n_p1.builders.clone(), {
                                            let ncp_p2 = ncp_p2.clone();
                                            let n_p1 = n_p1.clone();
                                            Rc::new(move |p0: crate::lower::model::ForDef| {
                                                let ncp_p2 = ncp_p2.clone();
                                                let n_p1 = n_p1.clone();
                                                entered(once_job(move || {
                                                    let b_p1o = p0;
                                                    prism_rtl::Turn::More(Rc::new(ForBuildCpp { cp_p0: ncp_p2.clone(), owner_p1: n_p1.name.clone(), b_p2: b_p1o.clone() }))
                                                }))
                                            }) as Rc<dyn Fn(crate::lower::model::ForDef) -> Rc<dyn prism_rtl::Job<Text>>>
                                        }), move |each_3650: Array<Text>| call_value(each_job(n_p1.gens.clone(), {
                                            let ncp_p2 = ncp_p2.clone();
                                            let n_p1 = n_p1.clone();
                                            Rc::new(move |p0: crate::lower::model::GenDef| {
                                                let ncp_p2 = ncp_p2.clone();
                                                let n_p1 = n_p1.clone();
                                                entered(once_job(move || {
                                                    let g_p1p = p0;
                                                    prism_rtl::Turn::More(Rc::new(GenBuildCpp { cp_p0: ncp_p2.clone(), owner_p1: n_p1.name.clone(), gd_p2: g_p1p.clone() }))
                                                }))
                                            }) as Rc<dyn Fn(crate::lower::model::GenDef) -> Rc<dyn prism_rtl::Job<Text>>>
                                        }), move |each_3702: Array<Text>| {
                                            let builders_po = append(&each_3650, &each_3702);
                                            call_value(each_job(n_p1.hooks.clone(), {
                                                let n_p1 = n_p1.clone();
                                                let ncp_p2 = ncp_p2.clone();
                                                Rc::new(move |p0: (Text, Array<crate::lower::model::Do>)| {
                                                    let n_p1 = n_p1.clone();
                                                    let ncp_p2 = ncp_p2.clone();
                                                    entered(once_job(move || {
                                                        let (h_p1q, body_p1r) = p0;
                                                        call_then(crate::emit::cpp::stmts::start_cpp_statements(ncp_p2.clone(), body_p1r.clone()), move |cpp_statements_3838: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &hook_sig(&h_p1q, &Text::from(format!("{}::", &n_p1.name))), &Text::from(format!("{}\nreturn {{}};", &cpp_statements_3838)))))
                                                    }))
                                                }) as Rc<dyn Fn((Text, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>
                                            }), move |each_3764: Array<Text>| {
                                                let hooks_pp = each_3764;
                                                let answer_pq = if &len(&n_p1.answers) == &Nat::from(0u32) {
                                                    Array::new()
                                                } else {
                                                    Array::from(vec![answer_def_cpp(&ncp_p2, &n_p1)])
                                                };
                                                let leaving_pr = if &n_p1.row_kind == &crate::lower::model::RowKind::NotARow {
                                                    Array::new()
                                                } else {
                                                    Array::from(vec![row_leaving(&ncp_p2, &n_p1)])
                                                };
                                                let defs_ps = append(&append(&append(&append(&append(&Array::from(vec![make_pm.clone()]), &methods_pn), &builders_po), &hooks_pp), &answer_pq), &leaving_pr);
                                                let own_pt = crate::emit::cpp::items::Parts { forward: Array::from(vec![Text::from(format!("class {};", &n_p1.name))]), values: Array::new(), protos: Array::new(), classes: Array::from(vec![decl_pi.clone()]), outer: Array::new(), generic: Array::new(), defs: defs_ps.clone() };
                                                prism_rtl::Turn::Finished(own_pt.clone())
                                            })
                                        }))
                                    })
                                })
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start NodeParts, x`: what the function value is when passed to `@Run`.
pub fn start_node_parts(cp_p0: crate::emit::cpp::Cp, n_p1: crate::lower::model::NodeDef) -> Rc<dyn prism_rtl::Job<crate::emit::cpp::items::Parts>> {
    Rc::new(NodeParts { cp_p0, n_p1 })
}

/// ```prism
/// MethodSig: unbounded fn Cp, MethDef, Text -> Text
/// ```
pub fn method_sig(cp_p0: &crate::emit::cpp::Cp, m_p1: &crate::lower::model::MethDef, owner_p2: &Text) -> Text {
    let cx_p3 = match &m_p1.cx_ {
        crate::lower::model::CxArg::CxMut => Array::from(vec![Text::lit("Cx& cx")]),
        crate::lower::model::CxArg::CxRef => Array::from(vec![Text::lit("const Cx& cx")]),
        crate::lower::model::CxArg::CxNone => Array::new(),
    };
    let params_p4 = crate::syntax::lexer::chars::join(&append(&run_to_end(each_job(m_p1.params.clone(), {
        let cp_p0 = cp_p0.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
            let cp_p0 = cp_p0.clone();
            entered(once_job(move || {
                let (p_p6, t_p7) = p0;
                call_then(crate::emit::cpp::expr::start_param_type(cp_p0.clone(), t_p7.clone()), move |param_type_4531: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_4531, &p_p6))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &cx_p3), &Text::lit(", "));
    let constness_p5 = if &m_p1.recv == &crate::lower::model::Recv::RecvRef {
        Text::lit(" const")
    } else {
        Text::lit("")
    };
    Text::from(format!("{} {}{}({}){}", &crate::emit::cpp::cpp_type(cp_p0, &m_p1.ret), owner_p2, &crate::emit::cpp::expr::node_method_name(cp_p0, &m_p1.name), &params_p4, &constness_p5))
}

/// The step machine of `MethodSig`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MethodSig: unbounded fn Cp, MethDef, Text -> Text
/// ```
pub struct MethodSig {
    pub cp_p0: crate::emit::cpp::Cp,
    pub m_p1: crate::lower::model::MethDef,
    pub owner_p2: Text,
}

impl prism_rtl::Job<Text> for MethodSig {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let m_p1 = &self.m_p1;
        let owner_p2 = &self.owner_p2;
        let cx_p3 = match &m_p1.cx_ {
            crate::lower::model::CxArg::CxMut => Array::from(vec![Text::lit("Cx& cx")]),
            crate::lower::model::CxArg::CxRef => Array::from(vec![Text::lit("const Cx& cx")]),
            crate::lower::model::CxArg::CxNone => Array::new(),
        };
        let cp_p0 = cp_p0.clone();
        let m_p1 = m_p1.clone();
        let owner_p2 = owner_p2.clone();
        call_value(each_job(m_p1.params.clone(), {
            let cp_p0 = cp_p0.clone();
            Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                let cp_p0 = cp_p0.clone();
                entered(once_job(move || {
                    let (p_p6, t_p7) = p0;
                    call_then(crate::emit::cpp::expr::start_param_type(cp_p0.clone(), t_p7.clone()), move |param_type_4531: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_4531, &p_p6))))
                }))
            }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_4502: Array<Text>| {
            let params_p4 = crate::syntax::lexer::chars::join(&append(&each_4502, &cx_p3), &Text::lit(", "));
            let constness_p5 = if &m_p1.recv == &crate::lower::model::Recv::RecvRef {
                Text::lit(" const")
            } else {
                Text::lit("")
            };
            call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), m_p1.ret.clone()), move |cpp_type_4631: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}{}({}){}", &cpp_type_4631, &owner_p2, &crate::emit::cpp::expr::node_method_name(&cp_p0, &m_p1.name), &params_p4, &constness_p5))))
        })
    }
}

/// `Start MethodSig, x`: what the function value is when passed to `@Run`.
pub fn start_method_sig(cp_p0: crate::emit::cpp::Cp, m_p1: crate::lower::model::MethDef, owner_p2: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(MethodSig { cp_p0, m_p1, owner_p2 })
}

/// ```prism
/// MethodDef: unbounded fn Cp, Text, MethDef -> Text
/// ```
pub fn method_def(cp_p0: &crate::emit::cpp::Cp, owner_p1: &Text, m_p2: &crate::lower::model::MethDef) -> Text {
    let (st_p4, cp2_p5) = crate::emit::cpp::stmts::cpp_statements_cp(cp_p0, &m_p2.body);
    let body_p3 = if &m_p2.ret == &crate::lower::model::OutTy::OutUnit {
        Text::from(format!("{}\nreturn Unit{{}};", &st_p4))
    } else {
        if &len(&m_p2.body) == &Nat::from(0u32) {
            crate::emit::cpp::stmts::cpp_body(cp_p0, &m_p2.tail)
        } else {
            Text::from(format!("{}\n{}", &st_p4, &crate::emit::cpp::stmts::cpp_body(&cp2_p5, &m_p2.tail)))
        }
    };
    crate::emit::cpp::templates::items::cpp_function(&crate::emit::cpp::items::cpp_doc(&m_p2.doc), &method_sig(cp_p0, m_p2, &Text::from(format!("{}::", owner_p1))), &body_p3)
}

/// The step machine of `MethodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MethodDef: unbounded fn Cp, Text, MethDef -> Text
/// ```
pub struct MethodDef {
    pub cp_p0: crate::emit::cpp::Cp,
    pub owner_p1: Text,
    pub m_p2: crate::lower::model::MethDef,
}

impl prism_rtl::Job<Text> for MethodDef {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let owner_p1 = &self.owner_p1;
        let m_p2 = &self.m_p2;
        let cp_p0 = cp_p0.clone();
        let m_p2 = m_p2.clone();
        let owner_p1 = owner_p1.clone();
        call_then(crate::emit::cpp::stmts::start_cpp_statements_cp(cp_p0.clone(), m_p2.body.clone()), move |cpp_statements_cp_4807: (Text, crate::emit::cpp::Cp)| {
            let (st_p4, cp2_p5) = cpp_statements_cp_4807;
            let body_p3 = if &m_p2.ret == &crate::lower::model::OutTy::OutUnit {
                Text::from(format!("{}\nreturn Unit{{}};", &st_p4))
            } else {
                if &len(&m_p2.body) == &Nat::from(0u32) {
                    crate::emit::cpp::stmts::cpp_body(&cp_p0, &m_p2.tail)
                } else {
                    Text::from(format!("{}\n{}", &st_p4, &crate::emit::cpp::stmts::cpp_body(&cp2_p5, &m_p2.tail)))
                }
            };
            call_then(start_method_sig(cp_p0.clone(), m_p2.clone(), Text::from(format!("{}::", &owner_p1))), move |method_sig_5011: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&crate::emit::cpp::items::cpp_doc(&m_p2.doc), &method_sig_5011, &body_p3)))
        })
    }
}

/// `Start MethodDef, x`: what the function value is when passed to `@Run`.
pub fn start_method_def(cp_p0: crate::emit::cpp::Cp, owner_p1: Text, m_p2: crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(MethodDef { cp_p0, owner_p1, m_p2 })
}

/// ```prism
/// HookSig: fn Text, Text -> Text
/// ```
pub fn hook_sig(text0: &Text, owner_p0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("push")) => Text::from(format!("Done {}push(const Pod& element, const Pod& v, Cx& cx)", owner_p0)),
        h_p1 => Text::from(format!("Done {}{}(Cx& cx)", owner_p0, h_p1)),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// AnswerDefCpp: unbounded fn Cp, NodeDef -> Text
/// ```
pub fn answer_def_cpp(cp_p0: &crate::emit::cpp::Cp, n_p1: &crate::lower::model::NodeDef) -> Text {
    let arms_p2 = run_to_end(each_job(n_p1.answers.clone(), {
        let cp_p0 = cp_p0.clone();
        Rc::new(move |p0: (crate::lower::model::Pa, crate::lower::model::Ex)| {
            let cp_p0 = cp_p0.clone();
            entered(once_job(move || {
                let (pat_p4, call_p5) = p0;
                call_then(crate::emit::cpp::patterns::start_pat_conds(cp_p0.clone(), pat_p4.clone(), Text::lit("at")), move |pat_conds_5354: Array<Text>| {
                    let tests_p6 = pat_conds_5354;
                    call_then(crate::emit::cpp::patterns::start_pat_binds(cp_p0.clone(), pat_p4.clone(), Text::lit("at")), move |pat_binds_5397: Array<Text>| {
                        let binds_p7 = pat_binds_5397;
                        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), call_p5.clone()), move |cpp_expr_5458: Text| prism_rtl::Turn::Finished((tests_p6.clone(), crate::syntax::lexer::chars::join(&push(&binds_p7, &Text::from(format!("{};", &cpp_expr_5458))), &Text::lit("\n")))))
                    })
                })
            }))
        }) as Rc<dyn Fn((crate::lower::model::Pa, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Text)>>>
    }));
    let blocks_p3 = each(&crate::check::errors::range0(&len(&arms_p2)), &(|i_p8: &Nat| {
        let (tests_p9, inner_pa) = or(&index(&arms_p2, i_p8), &(Array::new(), Text::lit("")));
        crate::emit::cpp::templates::items::block(&Text::from(format!("{} ({})", &(if i_p8 == &Nat::from(0u32) { Text::lit("if") } else { Text::lit("else if") }), &crate::emit::cpp::patterns::conds(&tests_p9))), &inner_pa)
    }));
    crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Done {}::answer(std::span<const Segment> at, const Pod& v, Cx& cx)", &n_p1.name)), &Text::from(format!("{} else {{\n    return unexpected(Fault::answer(str(\"no answering place at \", path_of(at))));\n}}\nreturn {{}};", &crate::syntax::lexer::chars::join(&blocks_p3, &Text::lit(" ")))))
}

/// The step machine of `AnswerDefCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnswerDefCpp: unbounded fn Cp, NodeDef -> Text
/// ```
pub struct AnswerDefCpp {
    pub cp_p0: crate::emit::cpp::Cp,
    pub n_p1: crate::lower::model::NodeDef,
}

impl prism_rtl::Job<Text> for AnswerDefCpp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let n_p1 = &self.n_p1;
        let cp_p0 = cp_p0.clone();
        let n_p1 = n_p1.clone();
        call_value(each_job(n_p1.answers.clone(), {
            let cp_p0 = cp_p0.clone();
            Rc::new(move |p0: (crate::lower::model::Pa, crate::lower::model::Ex)| {
                let cp_p0 = cp_p0.clone();
                entered(once_job(move || {
                    let (pat_p4, call_p5) = p0;
                    call_then(crate::emit::cpp::patterns::start_pat_conds(cp_p0.clone(), pat_p4.clone(), Text::lit("at")), move |pat_conds_5354: Array<Text>| {
                        let tests_p6 = pat_conds_5354;
                        call_then(crate::emit::cpp::patterns::start_pat_binds(cp_p0.clone(), pat_p4.clone(), Text::lit("at")), move |pat_binds_5397: Array<Text>| {
                            let binds_p7 = pat_binds_5397;
                            call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), call_p5.clone()), move |cpp_expr_5458: Text| prism_rtl::Turn::Finished((tests_p6.clone(), crate::syntax::lexer::chars::join(&push(&binds_p7, &Text::from(format!("{};", &cpp_expr_5458))), &Text::lit("\n")))))
                        })
                    })
                }))
            }) as Rc<dyn Fn((crate::lower::model::Pa, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Text)>>>
        }), move |each_5301: Array<(Array<Text>, Text)>| {
            let arms_p2 = each_5301;
            let blocks_p3 = each(&crate::check::errors::range0(&len(&arms_p2)), &(|i_p8: &Nat| {
                let (tests_p9, inner_pa) = or(&index(&arms_p2, i_p8), &(Array::new(), Text::lit("")));
                crate::emit::cpp::templates::items::block(&Text::from(format!("{} ({})", &(if i_p8 == &Nat::from(0u32) { Text::lit("if") } else { Text::lit("else if") }), &crate::emit::cpp::patterns::conds(&tests_p9))), &inner_pa)
            }));
            prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Done {}::answer(std::span<const Segment> at, const Pod& v, Cx& cx)", &n_p1.name)), &Text::from(format!("{} else {{\n    return unexpected(Fault::answer(str(\"no answering place at \", path_of(at))));\n}}\nreturn {{}};", &crate::syntax::lexer::chars::join(&blocks_p3, &Text::lit(" "))))))
        })
    }
}

/// `Start AnswerDefCpp, x`: what the function value is when passed to `@Run`.
pub fn start_answer_def_cpp(cp_p0: crate::emit::cpp::Cp, n_p1: crate::lower::model::NodeDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(AnswerDefCpp { cp_p0, n_p1 })
}

/// ```prism
/// RowLeaving: unbounded fn Cp, NodeDef -> Text
/// ```
pub fn row_leaving(cp_p0: &crate::emit::cpp::Cp, n_p1: &crate::lower::model::NodeDef) -> Text {
    let kept_p2 = if &n_p1.row_kind == &crate::lower::model::RowKind::ForRow {
        Array::from(vec![Text::lit("this->left_entry = entry(cx);")])
    } else {
        Array::new()
    };
    let unsubscribe_p3 = each(&n_p1.subs, &(|(ev_p4, m_p5, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("if (auto p = parent.lock(); p && {}_sub) deref(p->{}_port).unsubscribe(*std::exchange({}_sub, std::nullopt));", m_p5, ev_p4, m_p5))));
    crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("void {}::leave_row(Cx& cx)", &n_p1.name)), &crate::syntax::lexer::chars::join(&append(&push(&kept_p2, &Text::lit("remove_places(cx);")), &unsubscribe_p3), &Text::lit("\n")))
}

/// The step machine of `RowLeaving`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowLeaving: unbounded fn Cp, NodeDef -> Text
/// ```
pub struct RowLeaving {
    pub cp_p0: crate::emit::cpp::Cp,
    pub n_p1: crate::lower::model::NodeDef,
}

impl prism_rtl::Job<Text> for RowLeaving {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let n_p1 = &self.n_p1;
        let kept_p2 = if &n_p1.row_kind == &crate::lower::model::RowKind::ForRow {
            Array::from(vec![Text::lit("this->left_entry = entry(cx);")])
        } else {
            Array::new()
        };
        let unsubscribe_p3 = each(&n_p1.subs, &(|(ev_p4, m_p5, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("if (auto p = parent.lock(); p && {}_sub) deref(p->{}_port).unsubscribe(*std::exchange({}_sub, std::nullopt));", m_p5, ev_p4, m_p5))));
        prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("void {}::leave_row(Cx& cx)", &n_p1.name)), &crate::syntax::lexer::chars::join(&append(&push(&kept_p2, &Text::lit("remove_places(cx);")), &unsubscribe_p3), &Text::lit("\n"))))
    }
}

/// `Start RowLeaving, x`: what the function value is when passed to `@Run`.
pub fn start_row_leaving(cp_p0: crate::emit::cpp::Cp, n_p1: crate::lower::model::NodeDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RowLeaving { cp_p0, n_p1 })
}

/// ```prism
/// ForBuildCpp: unbounded fn Cp, Text, ForDef -> Text
/// ```
pub fn for_build_cpp(cp_p0: &crate::emit::cpp::Cp, owner_p1: &Text, b_p2: &crate::lower::model::ForDef) -> Text {
    crate::emit::cpp::templates::items::for_build_template(owner_p1, &b_p2.name, &crate::emit::cpp::expr::cpp_expr(cp_p0, &b_p2.at), &crate::emit::cpp::cpp_type(cp_p0, &b_p2.key_ty), &crate::emit::cpp::cpp_type(cp_p0, &b_p2.value_ty), &crate::emit::cpp::expr::call_path(&Text::from(format!("{}::build", &b_p2.row_node))), &b_p2.source, &crate::emit::cpp::expr::cpp_expr(cp_p0, &b_p2.parent), &concat(&run_to_end(each_job(b_p2.passed.clone(), {
        let cp_p0 = cp_p0.clone();
        Rc::new(move |p0: crate::lower::model::Ex| {
            let cp_p0 = cp_p0.clone();
            entered(once_job(move || {
                let x_p3 = p0;
                call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), x_p3.clone()), move |cpp_expr_6762: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}", &cpp_expr_6762))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
    }))), &moved_call_cpp(&b_p2.moved), &from_kept_cpp(&b_p2.name, &b_p2.replaced), &replaced_call_cpp(&b_p2.replaced))
}

/// The step machine of `ForBuildCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ForBuildCpp: unbounded fn Cp, Text, ForDef -> Text
/// ```
pub struct ForBuildCpp {
    pub cp_p0: crate::emit::cpp::Cp,
    pub owner_p1: Text,
    pub b_p2: crate::lower::model::ForDef,
}

impl prism_rtl::Job<Text> for ForBuildCpp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let owner_p1 = &self.owner_p1;
        let b_p2 = &self.b_p2;
        let b_p2 = b_p2.clone();
        let cp_p0 = cp_p0.clone();
        let owner_p1 = owner_p1.clone();
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), b_p2.at.clone()), move |cpp_expr_6595: Text| call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), b_p2.key_ty.clone()), move |cpp_type_6615: Text| call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), b_p2.value_ty.clone()), move |cpp_type_6638: Text| call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), b_p2.parent.clone()), move |cpp_expr_6706: Text| call_value(each_job(b_p2.passed.clone(), {
            let cp_p0 = cp_p0.clone();
            Rc::new(move |p0: crate::lower::model::Ex| {
                let cp_p0 = cp_p0.clone();
                entered(once_job(move || {
                    let x_p3 = p0;
                    call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), x_p3.clone()), move |cpp_expr_6762: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}", &cpp_expr_6762))))
                }))
            }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_6738: Array<Text>| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::for_build_template(&owner_p1, &b_p2.name, &cpp_expr_6595, &cpp_type_6615, &cpp_type_6638, &crate::emit::cpp::expr::call_path(&Text::from(format!("{}::build", &b_p2.row_node))), &b_p2.source, &cpp_expr_6706, &concat(&each_6738), &moved_call_cpp(&b_p2.moved), &from_kept_cpp(&b_p2.name, &b_p2.replaced), &replaced_call_cpp(&b_p2.replaced))))))))
    }
}

/// `Start ForBuildCpp, x`: what the function value is when passed to `@Run`.
pub fn start_for_build_cpp(cp_p0: crate::emit::cpp::Cp, owner_p1: Text, b_p2: crate::lower::model::ForDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ForBuildCpp { cp_p0, owner_p1, b_p2 })
}

/// ```prism
/// FromKeptCpp: fn Text, [Text] -> Text
/// ```
pub fn from_kept_cpp(name_p0: &Text, replaced_p1: &Array<Text>) -> Text {
    if &len(replaced_p1) == &Nat::from(0u32) {
        Text::from(format!("this->{}_from = items;", name_p0))
    } else {
        Text::from(format!("auto from = std::exchange(this->{}_from, items);", name_p0))
    }
}

/// ```prism
/// ReplacedCallCpp: fn [Text] -> Text
/// ```
pub fn replaced_call_cpp(replaced_p0: &Array<Text>) -> Text {
    if &len(replaced_p0) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" else if (auto was = from.get(k), is = items.get(k); !was || !is || !(*was == *is)) {{\n            // the dynamic under a kept key was replaced: that row follows it from the next tick\n{}        }}", &concat(&each(replaced_p0, &(|m_p1: &Text| Text::from(format!("            row->{}(cx);\n", m_p1)))))))
    }
}

/// ```prism
/// MovedCallCpp: fn Text -> Text
/// ```
pub fn moved_call_cpp(m_p0: &Text) -> Text {
    if m_p0 == &Text::lit("") {
        Text::lit("")
    } else {
        Text::from(format!("\n    // the places of the host\'s child came or went: its document\'s outer moves\n    if (!prism_rtl::same_keys(next, old)) this->{}(cx);", m_p0))
    }
}

/// ```prism
/// GenMovedCallCpp: fn Text -> Text
/// ```
pub fn gen_moved_call_cpp(m_p0: &Text) -> Text {
    if m_p0 == &Text::lit("") {
        Text::lit("")
    } else {
        Text::from(format!("\n    // the places of the host\'s child came or went: its document\'s outer moves\n    this->{}(cx);", m_p0))
    }
}

/// ```prism
/// GenBuildCpp: unbounded fn Cp, Text, GenDef -> Text
/// ```
pub fn gen_build_cpp(cp_p0: &crate::emit::cpp::Cp, owner_p1: &Text, gd_p2: &crate::lower::model::GenDef) -> Text {
    let path_p3 = if gd_p2.transparent {
        Text::lit("this->path")
    } else {
        Text::from(format!("{}.child(Segment::gen(g))", &crate::emit::cpp::expr::cpp_expr(cp_p0, &gd_p2.at)))
    };
    crate::emit::cpp::templates::items::gen_build_template(owner_p1, &gd_p2.name, &crate::emit::cpp::expr::cpp_expr(cp_p0, &gd_p2.at), &path_p3, &crate::emit::cpp::expr::cpp_expr(cp_p0, &gd_p2.source), &crate::emit::cpp::cpp_type(cp_p0, &gd_p2.value_ty), &crate::emit::cpp::expr::cpp_expr(cp_p0, &gd_p2.select), &gen_moved_call_cpp(&gd_p2.moved))
}

/// The step machine of `GenBuildCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GenBuildCpp: unbounded fn Cp, Text, GenDef -> Text
/// ```
pub struct GenBuildCpp {
    pub cp_p0: crate::emit::cpp::Cp,
    pub owner_p1: Text,
    pub gd_p2: crate::lower::model::GenDef,
}

impl prism_rtl::Job<Text> for GenBuildCpp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let owner_p1 = &self.owner_p1;
        let gd_p2 = &self.gd_p2;
        let path_p3 = if gd_p2.transparent {
            Text::lit("this->path")
        } else {
            Text::from(format!("{}.child(Segment::gen(g))", &crate::emit::cpp::expr::cpp_expr(cp_p0, &gd_p2.at)))
        };
        let cp_p0 = cp_p0.clone();
        let gd_p2 = gd_p2.clone();
        let owner_p1 = owner_p1.clone();
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), gd_p2.at.clone()), move |cpp_expr_8647: Text| call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), gd_p2.source.clone()), move |cpp_expr_8674: Text| call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), gd_p2.value_ty.clone()), move |cpp_type_8699: Text| call_then(crate::emit::cpp::expr::start_cpp_expr(cp_p0.clone(), gd_p2.select.clone()), move |cpp_expr_8725: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::gen_build_template(&owner_p1, &gd_p2.name, &cpp_expr_8647, &path_p3, &cpp_expr_8674, &cpp_type_8699, &cpp_expr_8725, &gen_moved_call_cpp(&gd_p2.moved)))))))
    }
}

/// `Start GenBuildCpp, x`: what the function value is when passed to `@Run`.
pub fn start_gen_build_cpp(cp_p0: crate::emit::cpp::Cp, owner_p1: Text, gd_p2: crate::lower::model::GenDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(GenBuildCpp { cp_p0, owner_p1, gd_p2 })
}

/// ```prism
/// ProgramCpp: unbounded fn Cp, ProgDef, Bool -> Text
/// ```
pub fn program_cpp(cp_p0: &crate::emit::cpp::Cp, p_p1: &crate::lower::model::ProgDef, fallible_p2: &bool) -> Text {
    let n_p3 = len(&p_p1.params);
    let names_p4 = each(&p_p1.params, &(|(a_p9, _): &(Text, crate::lower::model::OutTy)| a_p9.clone()));
    let plural_p5 = if &n_p3 == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") };
    let decode_p6 = if &n_p3 == &Nat::from(0u32) {
        Text::lit("static_cast<void>(args);")
    } else {
        crate::syntax::lexer::chars::join(&append(&Array::from(vec![Text::from(format!("if (args.size() != {}) return unexpected(Fault::answer(\"@{} takes {} argument{}\"));", &n_p3, &p_p1.prism, &n_p3, &plural_p5))]), &run_to_end(each_job(crate::check::errors::range0(&n_p3), {
            let cp_p0 = cp_p0.clone();
            let p_p1 = p_p1.clone();
            Rc::new(move |p0: Nat| {
                let cp_p0 = cp_p0.clone();
                let p_p1 = p_p1.clone();
                entered(once_job(move || {
                    let i_pa = p0;
                    prism_rtl::Turn::More(Rc::new(DecodeArg { cp_p0: cp_p0.clone(), ps_p1: p_p1.params.clone(), i_p2: i_pa.clone() }))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
        }))), &Text::lit("\n"))
    };
    let call_p7 = Text::from(format!("{}(Path::root(), {}cx)", &crate::emit::cpp::expr::call_path(&Text::from(format!("{}::build", &p_p1.node_))), &concat(&each(&names_p4, &(|a_pb: &Text| Text::from(format!("{}, ", a_pb)))))));
    let root_p8 = if *fallible_p2 { Text::from(format!("TRY({})", &call_p7)) } else { call_p7.clone() };
    crate::emit::cpp::templates::items::program_class(&p_p1.name, &p_p1.prism, &crate::emit::cpp::type_path(&p_p1.node_), &decode_p6, &root_p8)
}

/// The step machine of `ProgramCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ProgramCpp: unbounded fn Cp, ProgDef, Bool -> Text
/// ```
pub struct ProgramCpp {
    pub cp_p0: crate::emit::cpp::Cp,
    pub p_p1: crate::lower::model::ProgDef,
    pub fallible_p2: bool,
}

impl prism_rtl::Job<Text> for ProgramCpp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let p_p1 = &self.p_p1;
        let fallible_p2 = &self.fallible_p2;
        let n_p3 = len(&p_p1.params);
        let names_p4 = each(&p_p1.params, &(|(a_p9, _): &(Text, crate::lower::model::OutTy)| a_p9.clone()));
        let plural_p5 = if &n_p3 == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") };
        let decode_p6 = if &n_p3 == &Nat::from(0u32) {
            Text::lit("static_cast<void>(args);")
        } else {
            crate::syntax::lexer::chars::join(&append(&Array::from(vec![Text::from(format!("if (args.size() != {}) return unexpected(Fault::answer(\"@{} takes {} argument{}\"));", &n_p3, &p_p1.prism, &n_p3, &plural_p5))]), &run_to_end(each_job(crate::check::errors::range0(&n_p3), {
                let cp_p0 = cp_p0.clone();
                let p_p1 = p_p1.clone();
                Rc::new(move |p0: Nat| {
                    let cp_p0 = cp_p0.clone();
                    let p_p1 = p_p1.clone();
                    entered(once_job(move || {
                        let i_pa = p0;
                        prism_rtl::Turn::More(Rc::new(DecodeArg { cp_p0: cp_p0.clone(), ps_p1: p_p1.params.clone(), i_p2: i_pa.clone() }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
            }))), &Text::lit("\n"))
        };
        let call_p7 = Text::from(format!("{}(Path::root(), {}cx)", &crate::emit::cpp::expr::call_path(&Text::from(format!("{}::build", &p_p1.node_))), &concat(&each(&names_p4, &(|a_pb: &Text| Text::from(format!("{}, ", a_pb)))))));
        let root_p8 = if *fallible_p2 { Text::from(format!("TRY({})", &call_p7)) } else { call_p7.clone() };
        prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::program_class(&p_p1.name, &p_p1.prism, &crate::emit::cpp::type_path(&p_p1.node_), &decode_p6, &root_p8))
    }
}

/// `Start ProgramCpp, x`: what the function value is when passed to `@Run`.
pub fn start_program_cpp(cp_p0: crate::emit::cpp::Cp, p_p1: crate::lower::model::ProgDef, fallible_p2: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ProgramCpp { cp_p0, p_p1, fallible_p2 })
}

/// ```prism
/// DecodeArg: unbounded fn Cp, [((Text, OutTy))], Nat -> Text
/// ```
pub fn decode_arg(cp_p0: &crate::emit::cpp::Cp, ps_p1: &Array<(Text, crate::lower::model::OutTy)>, i_p2: &Nat) -> Text {
    match index(ps_p1, i_p2) {
        Some((a_p3, t_p4)) => Text::from(format!("auto {} = TRY(prism_rtl::from_pod<{}>(args[{}]));", &a_p3, &crate::emit::cpp::cpp_type(cp_p0, &t_p4), i_p2)),
        None => Text::lit(""),
    }
}

/// The step machine of `DecodeArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DecodeArg: unbounded fn Cp, [((Text, OutTy))], Nat -> Text
/// ```
pub struct DecodeArg {
    pub cp_p0: crate::emit::cpp::Cp,
    pub ps_p1: Array<(Text, crate::lower::model::OutTy)>,
    pub i_p2: Nat,
}

impl prism_rtl::Job<Text> for DecodeArg {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let ps_p1 = &self.ps_p1;
        let i_p2 = &self.i_p2;
        match index(ps_p1, i_p2) {
            Some((a_p3, t_p4)) => {
                let cp_p0 = cp_p0.clone();
                let i_p2 = i_p2.clone();
                call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), t_p4.clone()), move |cpp_type_9583: Text| prism_rtl::Turn::Finished(Text::from(format!("auto {} = TRY(prism_rtl::from_pod<{}>(args[{}]));", &a_p3, &cpp_type_9583, &i_p2))))
            },
            None => prism_rtl::Turn::Finished(Text::lit("")),
        }
    }
}

/// `Start DecodeArg, x`: what the function value is when passed to `@Run`.
pub fn start_decode_arg(cp_p0: crate::emit::cpp::Cp, ps_p1: Array<(Text, crate::lower::model::OutTy)>, i_p2: Nat) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(DecodeArg { cp_p0, ps_p1, i_p2 })
}

/// ```prism
/// ModuleParts: unbounded fn Cp, ModDef -> Parts
/// ```
pub fn module_parts(cp_p0: &crate::emit::cpp::Cp, m_p1: &crate::lower::model::ModDef) -> crate::emit::cpp::items::Parts {
    let mcp_p2 = crate::emit::cpp::in_home(cp_p0, &m_p1.name);
    let all_p3 = run_to_end(fold_job(m_p1.items.clone(), crate::emit::cpp::items::no_parts(), {
        let mcp_p2 = mcp_p2.clone();
        Rc::new(move |(p0, p1): (crate::emit::cpp::items::Parts, crate::lower::model::Item)| {
            let mcp_p2 = mcp_p2.clone();
            entered(once_job(move || {
                let acc_p4 = p0;
                let it_p5 = p1;
                call_then(crate::emit::cpp::items::start_item_parts(mcp_p2.clone(), it_p5.clone()), move |item_parts_10032: crate::emit::cpp::items::Parts| prism_rtl::Turn::Finished(crate::emit::cpp::items::join_parts(&acc_p4, &item_parts_10032)))
            }))
        }) as Rc<dyn Fn((crate::emit::cpp::items::Parts, crate::lower::model::Item)) -> Rc<dyn prism_rtl::Job<crate::emit::cpp::items::Parts>>>
    }));
    crate::emit::cpp::items::Parts { forward: in_ns(&m_p1.name, &all_p3.forward), values: each(&all_p3.values, &(|v_p6: &crate::emit::cpp::items::ValueDecl| in_ns_value(&m_p1.name, v_p6))), protos: in_ns(&m_p1.name, &all_p3.protos), classes: in_ns(&m_p1.name, &all_p3.classes), outer: all_p3.outer.clone(), generic: in_ns(&m_p1.name, &all_p3.generic), defs: all_p3.defs.clone() }
}

/// The step machine of `ModuleParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModuleParts: unbounded fn Cp, ModDef -> Parts
/// ```
pub struct ModuleParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub m_p1: crate::lower::model::ModDef,
}

impl prism_rtl::Job<crate::emit::cpp::items::Parts> for ModuleParts {
    fn cycle(&self) -> prism_rtl::Turn<crate::emit::cpp::items::Parts> {
        let cp_p0 = &self.cp_p0;
        let m_p1 = &self.m_p1;
        let mcp_p2 = crate::emit::cpp::in_home(cp_p0, &m_p1.name);
        let m_p1 = m_p1.clone();
        call_value(fold_job(m_p1.items.clone(), crate::emit::cpp::items::no_parts(), {
            let mcp_p2 = mcp_p2.clone();
            Rc::new(move |(p0, p1): (crate::emit::cpp::items::Parts, crate::lower::model::Item)| {
                let mcp_p2 = mcp_p2.clone();
                entered(once_job(move || {
                    let acc_p4 = p0;
                    let it_p5 = p1;
                    call_then(crate::emit::cpp::items::start_item_parts(mcp_p2.clone(), it_p5.clone()), move |item_parts_10032: crate::emit::cpp::items::Parts| prism_rtl::Turn::Finished(crate::emit::cpp::items::join_parts(&acc_p4, &item_parts_10032)))
                }))
            }) as Rc<dyn Fn((crate::emit::cpp::items::Parts, crate::lower::model::Item)) -> Rc<dyn prism_rtl::Job<crate::emit::cpp::items::Parts>>>
        }), move |fold_9982: crate::emit::cpp::items::Parts| {
            let all_p3 = fold_9982;
            prism_rtl::Turn::Finished(crate::emit::cpp::items::Parts { forward: in_ns(&m_p1.name, &all_p3.forward), values: each(&all_p3.values, &(|v_p6: &crate::emit::cpp::items::ValueDecl| in_ns_value(&m_p1.name, v_p6))), protos: in_ns(&m_p1.name, &all_p3.protos), classes: in_ns(&m_p1.name, &all_p3.classes), outer: all_p3.outer.clone(), generic: in_ns(&m_p1.name, &all_p3.generic), defs: all_p3.defs.clone() })
        })
    }
}

/// `Start ModuleParts, x`: what the function value is when passed to `@Run`.
pub fn start_module_parts(cp_p0: crate::emit::cpp::Cp, m_p1: crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<crate::emit::cpp::items::Parts>> {
    Rc::new(ModuleParts { cp_p0, m_p1 })
}

/// ```prism
/// InNsValue: fn Text, ValueDecl -> ValueDecl
/// ```
pub fn in_ns_value(ns_p0: &Text, v_p1: &crate::emit::cpp::items::ValueDecl) -> crate::emit::cpp::items::ValueDecl {
    let mut this: crate::emit::cpp::items::ValueDecl = v_p1.clone();
    this.text = Text::from(format!("namespace {} {{\n\n{}\n\n}}  // namespace {}", ns_p0, &this.text, ns_p0));
    this
}

/// ```prism
/// InNs: fn Text, [Text] -> [Text]
/// ```
pub fn in_ns(ns_p0: &Text, xs1: &Array<Text>) -> Array<Text> {
    match xs1 {
        c0_1 if (c0_1.len() == 0) => Array::new(),
        xs_p2 => Array::from(vec![Text::from(format!("namespace {} {{\n\n{}\n\n}}  // namespace {}", ns_p0, &crate::syntax::lexer::chars::join(xs_p2, &Text::lit("\n\n")), ns_p0))]),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// NodeFallibleCpp: fn Model, Text -> Bool
/// ```
pub fn node_fallible_cpp(model_p0: &crate::lower::model::Model, path_p1: &Text) -> bool {
    fold(&model_p0.mods, &false, &(|f_p2: &bool, m_p3: &crate::lower::model::ModDef| fold(&m_p3.items, f_p2, &(|f2_p4: &bool, it_p5: &crate::lower::model::Item| match it_p5 {
        crate::lower::model::Item::ItNode(n_p6) => *f2_p4 || ((&Text::from(format!("{}::{}", &m_p3.name, &n_p6.name)) == path_p1) && n_p6.fallible),
        _ => *f2_p4,
    }))))
}

/// ```prism
/// EmitCpp: unbounded fn Model, Text, [Text] -> [((Text, Text))]
/// ```
pub fn emit_cpp(model_p0: &crate::lower::model::Model, runtime_p1: &Text, scripts_p2: &Array<Text>) -> Array<(Text, Text)> {
    let cp_p3 = crate::emit::cpp::context(model_p0);
    let crate_p4 = crate::emit::cpp::in_home(&cp_p3, &Text::lit(""));
    let elem_p5 = crate::emit::cpp::items::row_parts(&crate_p4, &Text::lit(""), &model_p0.elem);
    let answer_p6 = crate::emit::cpp::items::answer_parts(&crate_p4, &model_p0.answer);
    let mods_p7 = run_to_end(each_job(model_p0.mods.clone(), {
        let cp_p3 = cp_p3.clone();
        Rc::new(move |p0: crate::lower::model::ModDef| {
            let cp_p3 = cp_p3.clone();
            entered(once_job(move || {
                let m_pu = p0;
                prism_rtl::Turn::More(Rc::new(ModuleParts { cp_p0: cp_p3.clone(), m_p1: m_pu.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<crate::emit::cpp::items::Parts>>>
    }));
    let programs_p8 = crate::syntax::lexer::chars::join(&run_to_end(each_job(all_programs_cpp(model_p0), {
        let crate_p4 = crate_p4.clone();
        let model_p0 = model_p0.clone();
        Rc::new(move |p0: crate::lower::model::ProgDef| {
            let crate_p4 = crate_p4.clone();
            let model_p0 = model_p0.clone();
            entered(once_job(move || {
                let p_pv = p0;
                prism_rtl::Turn::More(Rc::new(ProgramCpp { cp_p0: crate_p4.clone(), p_p1: p_pv.clone(), fallible_p2: node_fallible_cpp(&model_p0, &p_pv.node_) }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::ProgDef) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n\n"));
    let regs_p9 = concat(&each(&model_p0.programs, &(|p_p10: &crate::lower::model::ProgDef| Text::from(format!("\n.program<{}>(\"{}\")", &p_p10.name, &p_p10.prism)))));
    let checks_pa = concat(&run_to_end(each_job(model_p0.checks.clone(), {
        let crate_p4 = crate_p4.clone();
        Rc::new(move |p0: crate::lower::model::CheckDef| {
            let crate_p4 = crate_p4.clone();
            entered(once_job(move || {
                let c_p11 = p0;
                call_value(each_job(c_p11.lines.clone(), {
                    let crate_p4 = crate_p4.clone();
                    Rc::new(move |p0: crate::lower::model::Ex| {
                        let crate_p4 = crate_p4.clone();
                        entered(once_job(move || {
                            let l_p12 = p0;
                            prism_rtl::Turn::More(Rc::new(crate::emit::cpp::expr::CppExpr { cp_p0: crate_p4.clone(), x_p1: l_p12.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_11535: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("\n.check(\"{}\", [] {{ return std::vector<Result<Pod>>{{{}}}; }})", &c_p11.name, &crate::syntax::lexer::chars::join(&each_11535, &Text::lit(", "))))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::CheckDef) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let script_list_pb = crate::syntax::lexer::chars::join(&each(scripts_p2, &(|s_p13: &Text| Text::from(format!("\"{}\",", &crate::lower::expr::escape(s_p13))))), &Text::lit("\n"));
    let world_pc = match &model_p0.root {
        Some(r_p14) => r_p14.world.clone(),
        None => Text::lit("test"),
    };
    let canvas_pd = &world_pc == &Text::lit("canvas");
    let run_root_pe = match &model_p0.root {
        Some(r_p15) => crate::emit::cpp::templates::cpp_run_root(&r_p15.name, &(if canvas_pd {
            crate::emit::cpp::templates::cpp_canvas_run(&r_p15.name)
        } else {
            crate::emit::cpp::templates::cpp_no_canvas(&r_p15.name)
        })),
        None => crate::emit::cpp::templates::cpp_no_root(&model_p0.name),
    };
    let both_pf = crate::emit::cpp::items::join_parts(&elem_p5, &answer_p6);
    let elem_decl_pg = crate::emit::cpp::templates::cpp_elem_decl(&includes(&Text::lit("decl"), &append(&model_p0.elem_complete, &model_p0.elem_declared)), &crate::syntax::lexer::chars::join(&both_pf.forward, &Text::lit("\n\n")), &crate::emit::cpp::prelude::cpp_prelude_rows(&Text::lit("")));
    let elem_types_ph = crate::emit::cpp::templates::cpp_elem_types(&crate::syntax::lexer::chars::join(&filter(&Array::from(vec![includes(&Text::lit("types"), &model_p0.elem_complete), includes(&Text::lit("decl"), &model_p0.elem_declared)]), &(|t_p16: &Text| t_p16 != &Text::lit(""))), &Text::lit("\n")), &crate::syntax::lexer::chars::join(&each(&both_pf.values, &(|v_p17: &crate::emit::cpp::items::ValueDecl| v_p17.text.clone())), &Text::lit("\n\n")));
    let pairs_pi = each(&crate::check::errors::range0(&len(&model_p0.mods)), &(|i_p18: &Nat| (or(&index(&model_p0.mods, i_p18), &no_mod()), or(&index(&mods_p7, i_p18), &crate::emit::cpp::items::no_parts()))));
    let generics_pj = fold(&pairs_pi, &Array::new(), &(|acc_p19: &Array<Text>, (m_p1a, p_p1b): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| if &len(&p_p1b.generic) > &Nat::from(0u32) {
        push(acc_p19, &m_p1a.name)
    } else {
        acc_p19.clone()
    }));
    let per_module_pk = run_to_end(each_job(pairs_pi.clone(), Rc::new(move |p0: (crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| entered(once_job(move || {
        let (m_p1c, p_p1d) = p0;
        prism_rtl::Turn::More(Rc::new(ModuleFiles { m_p0: m_p1c.clone(), p_p1: p_p1d.clone() }))
    }))) as Rc<dyn Fn((crate::lower::model::ModDef, crate::emit::cpp::items::Parts)) -> Rc<dyn prism_rtl::Job<(Array<(Text, Text)>, Array<Piece>)>>>));
    let pieces_pl = fold(&per_module_pk, &Array::new(), &(|acc_p1e: &Array<Piece>, (_, ps_p1f): &(Array<(Text, Text)>, Array<Piece>)| append(acc_p1e, ps_p1f)));
    let units_pm = units(&pieces_pl);
    let unit_files_pn = each(&crate::check::errors::range0(&len(&units_pm)), &(|k_p1g: &Nat| unit_file(k_p1g, &or(&index(&units_pm, k_p1g), &Array::new()), &generics_pj)));
    let main_includes_po = crate::syntax::lexer::chars::join(&append(&append(&Array::from(vec![Text::lit("#include \"elem.types.hpp\"")]), &Array::from(vec![includes(&Text::lit(""), &each(&model_p0.mods, &(|m_p1h: &crate::lower::model::ModDef| m_p1h.name.clone())))])), &Array::from(vec![includes(&Text::lit("generic"), &generics_pj)])), &Text::lit("\n"));
    let canvas_include_pp = if canvas_pd {
        crate::emit::cpp::templates::cpp_canvas_include(&Text::lit(""))
    } else {
        Text::lit("")
    };
    let main_pq = crate::emit::cpp::templates::cpp_main(&model_p0.name, &Text::from(format!("#include \"programs.hpp\"\n{}", &canvas_include_pp)), &regs_p9, &checks_pa, &script_list_pb, &world_pc, &run_root_pe, &crate::syntax::lexer::chars::join(&crate::emit::cpp::patterns::concat2(&each(&Array::from(vec![elem_p5.clone(), answer_p6.clone()]), &(|p_p1i: &crate::emit::cpp::items::Parts| p_p1i.defs.clone()))), &Text::lit("\n\n")));
    let groups_pr = run_to_end(each_job(filter(&model_p0.mods, &(|m_p1j: &crate::lower::model::ModDef| (&len(&m_p1j.types_with) > &Nat::from(1u32)) && (&or(&index(&m_p1j.types_with, &Nat::from(0u32)), &Text::lit("")) == &m_p1j.name))), {
        let pairs_pi = pairs_pi.clone();
        Rc::new(move |p0: crate::lower::model::ModDef| {
            let pairs_pi = pairs_pi.clone();
            entered(once_job(move || {
                let m_p1k = p0;
                prism_rtl::Turn::More(Rc::new(GroupTypesFile { pairs_p0: pairs_pi.clone(), group_p1: m_p1k.types_with.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<(Text, Text)>>>
    }));
    let files_ps = append(&fold(&per_module_pk, &Array::new(), &(|acc_p1l: &Array<(Text, Text)>, (fs_p1m, _): &(Array<(Text, Text)>, Array<Piece>)| append(acc_p1l, fs_p1m))), &unit_files_pn);
    let sources_pt = crate::syntax::lexer::chars::join(&filter(&each(&files_ps, &(|(f_p1n, _): &(Text, Text)| f_p1n.clone())), &(|f_p1o: &Text| crate::syntax::lexer::chars::contains(f_p1o, &Text::lit(".cpp")))), &Text::lit(" "));
    append(&Array::from(vec![(Text::lit("Makefile"), crate::emit::cpp::templates::cpp_makefile(&model_p0.name, runtime_p1, &sources_pt, &(if canvas_pd {
        crate::emit::cpp::templates::cpp_makefile_canvas(runtime_p1)
    } else {
        Text::lit("")
    }))), (Text::lit("src/elem.decl.hpp"), elem_decl_pg.clone()), (Text::lit("src/elem.types.hpp"), elem_types_ph.clone()), (Text::lit("src/programs.hpp"), crate::emit::cpp::templates::cpp_programs_header(&model_p0.name, &main_includes_po, &programs_p8)), (Text::lit("src/main.cpp"), main_pq.clone()), (Text::lit("src/prelude.hpp"), crate::emit::cpp::prelude::cpp_prelude_source(&Text::lit("")))]), &append(&groups_pr, &files_ps))
}

/// The step machine of `EmitCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EmitCpp: unbounded fn Model, Text, [Text] -> [((Text, Text))]
/// ```
pub struct EmitCpp {
    pub model_p0: crate::lower::model::Model,
    pub runtime_p1: Text,
    pub scripts_p2: Array<Text>,
}

impl prism_rtl::Job<Array<(Text, Text)>> for EmitCpp {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Text, Text)>> {
        let model_p0 = &self.model_p0;
        let runtime_p1 = &self.runtime_p1;
        let scripts_p2 = &self.scripts_p2;
        let cp_p3 = crate::emit::cpp::context(model_p0);
        let crate_p4 = crate::emit::cpp::in_home(&cp_p3, &Text::lit(""));
        let model_p0 = model_p0.clone();
        let runtime_p1 = runtime_p1.clone();
        let scripts_p2 = scripts_p2.clone();
        call_then(crate::emit::cpp::items::start_row_parts(crate_p4.clone(), Text::lit(""), model_p0.elem.clone()), move |row_parts_11072: crate::emit::cpp::items::Parts| {
            let elem_p5 = row_parts_11072;
            call_then(crate::emit::cpp::items::start_answer_parts(crate_p4.clone(), model_p0.answer.clone()), move |answer_parts_11120: crate::emit::cpp::items::Parts| {
                let answer_p6 = answer_parts_11120;
                call_value(each_job(model_p0.mods.clone(), {
                    let cp_p3 = cp_p3.clone();
                    Rc::new(move |p0: crate::lower::model::ModDef| {
                        let cp_p3 = cp_p3.clone();
                        entered(once_job(move || {
                            let m_pu = p0;
                            prism_rtl::Turn::More(Rc::new(ModuleParts { cp_p0: cp_p3.clone(), m_p1: m_pu.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<crate::emit::cpp::items::Parts>>>
                }), move |each_11167: Array<crate::emit::cpp::items::Parts>| {
                    let mods_p7 = each_11167;
                    call_value(each_job(all_programs_cpp(&model_p0), {
                        let crate_p4 = crate_p4.clone();
                        let model_p0 = model_p0.clone();
                        Rc::new(move |p0: crate::lower::model::ProgDef| {
                            let crate_p4 = crate_p4.clone();
                            let model_p0 = model_p0.clone();
                            entered(once_job(move || {
                                let p_pv = p0;
                                prism_rtl::Turn::More(Rc::new(ProgramCpp { cp_p0: crate_p4.clone(), p_p1: p_pv.clone(), fallible_p2: node_fallible_cpp(&model_p0, &p_pv.node_) }))
                            }))
                        }) as Rc<dyn Fn(crate::lower::model::ProgDef) -> Rc<dyn prism_rtl::Job<Text>>>
                    }), move |each_11232: Array<Text>| {
                        let programs_p8 = crate::syntax::lexer::chars::join(&each_11232, &Text::lit("\n\n"));
                        let regs_p9 = concat(&each(&model_p0.programs, &(|p_p10: &crate::lower::model::ProgDef| Text::from(format!("\n.program<{}>(\"{}\")", &p_p10.name, &p_p10.prism)))));
                        call_value(each_job(model_p0.checks.clone(), {
                            let crate_p4 = crate_p4.clone();
                            Rc::new(move |p0: crate::lower::model::CheckDef| {
                                let crate_p4 = crate_p4.clone();
                                entered(once_job(move || {
                                    let c_p11 = p0;
                                    call_value(each_job(c_p11.lines.clone(), {
                                        let crate_p4 = crate_p4.clone();
                                        Rc::new(move |p0: crate::lower::model::Ex| {
                                            let crate_p4 = crate_p4.clone();
                                            entered(once_job(move || {
                                                let l_p12 = p0;
                                                prism_rtl::Turn::More(Rc::new(crate::emit::cpp::expr::CppExpr { cp_p0: crate_p4.clone(), x_p1: l_p12.clone() }))
                                            }))
                                        }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
                                    }), move |each_11535: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("\n.check(\"{}\", [] {{ return std::vector<Result<Pod>>{{{}}}; }})", &c_p11.name, &crate::syntax::lexer::chars::join(&each_11535, &Text::lit(", "))))))
                                }))
                            }) as Rc<dyn Fn(crate::lower::model::CheckDef) -> Rc<dyn prism_rtl::Job<Text>>>
                        }), move |each_11441: Array<Text>| {
                            let checks_pa = concat(&each_11441);
                            let script_list_pb = crate::syntax::lexer::chars::join(&each(&scripts_p2, &(|s_p13: &Text| Text::from(format!("\"{}\",", &crate::lower::expr::escape(s_p13))))), &Text::lit("\n"));
                            let world_pc = match &model_p0.root {
                                Some(r_p14) => r_p14.world.clone(),
                                None => Text::lit("test"),
                            };
                            let canvas_pd = &world_pc == &Text::lit("canvas");
                            let run_root_pe = match &model_p0.root {
                                Some(r_p15) => crate::emit::cpp::templates::cpp_run_root(&r_p15.name, &(if canvas_pd {
                                    crate::emit::cpp::templates::cpp_canvas_run(&r_p15.name)
                                } else {
                                    crate::emit::cpp::templates::cpp_no_canvas(&r_p15.name)
                                })),
                                None => crate::emit::cpp::templates::cpp_no_root(&model_p0.name),
                            };
                            let both_pf = crate::emit::cpp::items::join_parts(&elem_p5, &answer_p6);
                            let elem_decl_pg = crate::emit::cpp::templates::cpp_elem_decl(&includes(&Text::lit("decl"), &append(&model_p0.elem_complete, &model_p0.elem_declared)), &crate::syntax::lexer::chars::join(&both_pf.forward, &Text::lit("\n\n")), &crate::emit::cpp::prelude::cpp_prelude_rows(&Text::lit("")));
                            let elem_types_ph = crate::emit::cpp::templates::cpp_elem_types(&crate::syntax::lexer::chars::join(&filter(&Array::from(vec![includes(&Text::lit("types"), &model_p0.elem_complete), includes(&Text::lit("decl"), &model_p0.elem_declared)]), &(|t_p16: &Text| t_p16 != &Text::lit(""))), &Text::lit("\n")), &crate::syntax::lexer::chars::join(&each(&both_pf.values, &(|v_p17: &crate::emit::cpp::items::ValueDecl| v_p17.text.clone())), &Text::lit("\n\n")));
                            let pairs_pi = each(&crate::check::errors::range0(&len(&model_p0.mods)), &(|i_p18: &Nat| (or(&index(&model_p0.mods, i_p18), &no_mod()), or(&index(&mods_p7, i_p18), &crate::emit::cpp::items::no_parts()))));
                            let generics_pj = fold(&pairs_pi, &Array::new(), &(|acc_p19: &Array<Text>, (m_p1a, p_p1b): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| if &len(&p_p1b.generic) > &Nat::from(0u32) {
                                push(acc_p19, &m_p1a.name)
                            } else {
                                acc_p19.clone()
                            }));
                            call_value(each_job(pairs_pi.clone(), Rc::new(move |p0: (crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| entered(once_job(move || {
                                let (m_p1c, p_p1d) = p0;
                                prism_rtl::Turn::More(Rc::new(ModuleFiles { m_p0: m_p1c.clone(), p_p1: p_p1d.clone() }))
                            }))) as Rc<dyn Fn((crate::lower::model::ModDef, crate::emit::cpp::items::Parts)) -> Rc<dyn prism_rtl::Job<(Array<(Text, Text)>, Array<Piece>)>>>), move |each_12547: Array<(Array<(Text, Text)>, Array<Piece>)>| {
                                let per_module_pk = each_12547;
                                let pieces_pl = fold(&per_module_pk, &Array::new(), &(|acc_p1e: &Array<Piece>, (_, ps_p1f): &(Array<(Text, Text)>, Array<Piece>)| append(acc_p1e, ps_p1f)));
                                let units_pm = units(&pieces_pl);
                                let unit_files_pn = each(&crate::check::errors::range0(&len(&units_pm)), &(|k_p1g: &Nat| unit_file(k_p1g, &or(&index(&units_pm, k_p1g), &Array::new()), &generics_pj)));
                                let main_includes_po = crate::syntax::lexer::chars::join(&append(&append(&Array::from(vec![Text::lit("#include \"elem.types.hpp\"")]), &Array::from(vec![includes(&Text::lit(""), &each(&model_p0.mods, &(|m_p1h: &crate::lower::model::ModDef| m_p1h.name.clone())))])), &Array::from(vec![includes(&Text::lit("generic"), &generics_pj)])), &Text::lit("\n"));
                                let canvas_include_pp = if canvas_pd {
                                    crate::emit::cpp::templates::cpp_canvas_include(&Text::lit(""))
                                } else {
                                    Text::lit("")
                                };
                                let main_pq = crate::emit::cpp::templates::cpp_main(&model_p0.name, &Text::from(format!("#include \"programs.hpp\"\n{}", &canvas_include_pp)), &regs_p9, &checks_pa, &script_list_pb, &world_pc, &run_root_pe, &crate::syntax::lexer::chars::join(&crate::emit::cpp::patterns::concat2(&each(&Array::from(vec![elem_p5.clone(), answer_p6.clone()]), &(|p_p1i: &crate::emit::cpp::items::Parts| p_p1i.defs.clone()))), &Text::lit("\n\n")));
                                call_value(each_job(filter(&model_p0.mods, &(|m_p1j: &crate::lower::model::ModDef| (&len(&m_p1j.types_with) > &Nat::from(1u32)) && (&or(&index(&m_p1j.types_with, &Nat::from(0u32)), &Text::lit("")) == &m_p1j.name))), {
                                    let pairs_pi = pairs_pi.clone();
                                    Rc::new(move |p0: crate::lower::model::ModDef| {
                                        let pairs_pi = pairs_pi.clone();
                                        entered(once_job(move || {
                                            let m_p1k = p0;
                                            prism_rtl::Turn::More(Rc::new(GroupTypesFile { pairs_p0: pairs_pi.clone(), group_p1: m_p1k.types_with.clone() }))
                                        }))
                                    }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<(Text, Text)>>>
                                }), move |each_13227: Array<(Text, Text)>| {
                                    let groups_pr = each_13227;
                                    let files_ps = append(&fold(&per_module_pk, &Array::new(), &(|acc_p1l: &Array<(Text, Text)>, (fs_p1m, _): &(Array<(Text, Text)>, Array<Piece>)| append(acc_p1l, fs_p1m))), &unit_files_pn);
                                    let sources_pt = crate::syntax::lexer::chars::join(&filter(&each(&files_ps, &(|(f_p1n, _): &(Text, Text)| f_p1n.clone())), &(|f_p1o: &Text| crate::syntax::lexer::chars::contains(f_p1o, &Text::lit(".cpp")))), &Text::lit(" "));
                                    prism_rtl::Turn::Finished(append(&Array::from(vec![(Text::lit("Makefile"), crate::emit::cpp::templates::cpp_makefile(&model_p0.name, &runtime_p1, &sources_pt, &(if canvas_pd {
                                        crate::emit::cpp::templates::cpp_makefile_canvas(&runtime_p1)
                                    } else {
                                        Text::lit("")
                                    }))), (Text::lit("src/elem.decl.hpp"), elem_decl_pg.clone()), (Text::lit("src/elem.types.hpp"), elem_types_ph.clone()), (Text::lit("src/programs.hpp"), crate::emit::cpp::templates::cpp_programs_header(&model_p0.name, &main_includes_po, &programs_p8)), (Text::lit("src/main.cpp"), main_pq.clone()), (Text::lit("src/prelude.hpp"), crate::emit::cpp::prelude::cpp_prelude_source(&Text::lit("")))]), &append(&groups_pr, &files_ps)))
                                })
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start EmitCpp, x`: what the function value is when passed to `@Run`.
pub fn start_emit_cpp(model_p0: crate::lower::model::Model, runtime_p1: Text, scripts_p2: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>> {
    Rc::new(EmitCpp { model_p0, runtime_p1, scripts_p2 })
}

/// ```prism
/// let noMod
/// ```
pub fn no_mod() -> crate::lower::model::ModDef {
    crate::lower::model::ModDef { name: Text::lit(""), prism: Text::lit(""), path_: Text::lit(""), uses: Array::new(), complete: Array::new(), declared: Array::new(), types_with: Array::new(), items: Array::new() }
}

/// ```prism
/// GroupTypesFile: unbounded fn [((ModDef, Parts))], [Text] -> ((Text, Text))
/// ```
pub fn group_types_file(pairs_p0: &Array<(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)>, group_p1: &Array<Text>) -> (Text, Text) {
    let members_p2 = filter(pairs_p0, &(|(m_p7, _): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| among(group_p1, &m_p7.name)));
    let p_p3 = fold(&members_p2, &crate::emit::cpp::items::no_parts(), &(|acc_p8: &crate::emit::cpp::items::Parts, (_, q_p9): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| crate::emit::cpp::items::join_parts(acc_p8, q_p9)));
    let complete_p4 = fold(&members_p2, &Array::new(), &(|acc_pa: &Array<Text>, (m_pb, _): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| fold(&m_pb.complete, acc_pa, &(|a_pc: &Array<Text>, n_pd: &Text| if among(a_pc, n_pd) || among(group_p1, n_pd) {
        a_pc.clone()
    } else {
        push(a_pc, n_pd)
    }))));
    let declared_p5 = fold(&members_p2, &Array::new(), &(|acc_pe: &Array<Text>, (m_pf, _): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| fold(&m_pf.declared, acc_pe, &(|a_pg: &Array<Text>, n_ph: &Text| if (among(a_pg, n_ph) || among(group_p1, n_ph)) || among(&complete_p4, n_ph) {
        a_pg.clone()
    } else {
        push(a_pg, n_ph)
    }))));
    let title_p6 = Text::from(format!("The modules {}", &crate::syntax::lexer::chars::join(&each(group_p1, &(|n_pi: &Text| Text::from(format!("`{}`", n_pi)))), &Text::lit(", "))));
    (Text::from(format!("src/{}.types.hpp", &group_name(group_p1))), types_header(&title_p6, group_p1, &declared_p5, &complete_p4, &p_p3))
}

/// The step machine of `GroupTypesFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GroupTypesFile: unbounded fn [((ModDef, Parts))], [Text] -> ((Text, Text))
/// ```
pub struct GroupTypesFile {
    pub pairs_p0: Array<(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)>,
    pub group_p1: Array<Text>,
}

impl prism_rtl::Job<(Text, Text)> for GroupTypesFile {
    fn cycle(&self) -> prism_rtl::Turn<(Text, Text)> {
        let pairs_p0 = &self.pairs_p0;
        let group_p1 = &self.group_p1;
        let members_p2 = filter(pairs_p0, &(|(m_p7, _): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| among(group_p1, &m_p7.name)));
        let p_p3 = fold(&members_p2, &crate::emit::cpp::items::no_parts(), &(|acc_p8: &crate::emit::cpp::items::Parts, (_, q_p9): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| crate::emit::cpp::items::join_parts(acc_p8, q_p9)));
        let complete_p4 = fold(&members_p2, &Array::new(), &(|acc_pa: &Array<Text>, (m_pb, _): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| fold(&m_pb.complete, acc_pa, &(|a_pc: &Array<Text>, n_pd: &Text| if among(a_pc, n_pd) || among(group_p1, n_pd) {
            a_pc.clone()
        } else {
            push(a_pc, n_pd)
        }))));
        let declared_p5 = fold(&members_p2, &Array::new(), &(|acc_pe: &Array<Text>, (m_pf, _): &(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)| fold(&m_pf.declared, acc_pe, &(|a_pg: &Array<Text>, n_ph: &Text| if (among(a_pg, n_ph) || among(group_p1, n_ph)) || among(&complete_p4, n_ph) {
            a_pg.clone()
        } else {
            push(a_pg, n_ph)
        }))));
        let title_p6 = Text::from(format!("The modules {}", &crate::syntax::lexer::chars::join(&each(group_p1, &(|n_pi: &Text| Text::from(format!("`{}`", n_pi)))), &Text::lit(", "))));
        let group_p1 = group_p1.clone();
        call_then(start_types_header(title_p6.clone(), group_p1.clone(), declared_p5.clone(), complete_p4.clone(), p_p3.clone()), move |types_header_14897: Text| prism_rtl::Turn::Finished((Text::from(format!("src/{}.types.hpp", &group_name(&group_p1))), types_header_14897)))
    }
}

/// `Start GroupTypesFile, x`: what the function value is when passed to `@Run`.
pub fn start_group_types_file(pairs_p0: Array<(crate::lower::model::ModDef, crate::emit::cpp::items::Parts)>, group_p1: Array<Text>) -> Rc<dyn prism_rtl::Job<(Text, Text)>> {
    Rc::new(GroupTypesFile { pairs_p0, group_p1 })
}

/// ```prism
/// GroupName: fn [Text] -> Text
/// ```
pub fn group_name(group_p0: &Array<Text>) -> Text {
    crate::syntax::lexer::chars::join(&each(group_p0, &(|n_p1: &Text| crate::syntax::lexer::chars::join(&split_on(n_p1, &Text::lit("::")), &Text::lit("_")))), &Text::lit("-"))
}

/// ```prism
/// ModDir: fn Text -> Text
/// ```
pub fn mod_dir(m_p0: &Text) -> Text {
    crate::syntax::lexer::chars::join(&split_on(m_p0, &Text::lit("::")), &Text::lit("/"))
}

/// ```prism
/// Among: fn [Text], Text -> Bool
/// ```
pub fn among(xs_p0: &Array<Text>, x_p1: &Text) -> bool {
    fold(xs_p0, &false, &(|f_p2: &bool, y_p3: &Text| *f_p2 || (y_p3 == x_p1)))
}

/// ```prism
/// TypesHeader: unbounded fn Text, [Text], [Text], [Text], Parts -> Text
/// ```
pub fn types_header(title_p0: &Text, members_p1: &Array<Text>, declared_p2: &Array<Text>, complete_p3: &Array<Text>, p_p4: &crate::emit::cpp::items::Parts) -> Text {
    let holds_elem_p5 = fold(&p_p4.values, &false, &(|f_p9: &bool, v_pa: &crate::emit::cpp::items::ValueDecl| *f_p9 || fold(&v_pa.deps, &false, &(|g_pb: &bool, d_pc: &Text| (*g_pb || (d_pc == &Text::lit("Elem"))) || (d_pc == &Text::lit("Answer"))))));
    let elem_p6 = if holds_elem_p5 {
        Text::lit("#include \"elem.types.hpp\"")
    } else {
        Text::lit("#include \"elem.decl.hpp\"")
    };
    let includes_p7 = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![includes(&Text::lit("decl"), members_p1), elem_p6.clone(), includes(&Text::lit("decl"), declared_p2), includes(&Text::lit("types"), complete_p3)]), &(|t_pd: &Text| t_pd != &Text::lit(""))), &Text::lit("\n"));
    let values_p8 = crate::syntax::lexer::chars::join(&order_values(&p_p4.values, &fold(&p_p4.values, &Map::new(), &(|acc_pe: &Map<Text, bool>, v_pf: &crate::emit::cpp::items::ValueDecl| insert(acc_pe, &v_pf.path_, &false))), &Array::new()), &Text::lit("\n\n"));
    crate::emit::cpp::templates::cpp_types_header(title_p0, &includes_p7, &values_p8)
}

/// The step machine of `TypesHeader`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypesHeader: unbounded fn Text, [Text], [Text], [Text], Parts -> Text
/// ```
pub struct TypesHeader {
    pub title_p0: Text,
    pub members_p1: Array<Text>,
    pub declared_p2: Array<Text>,
    pub complete_p3: Array<Text>,
    pub p_p4: crate::emit::cpp::items::Parts,
}

impl prism_rtl::Job<Text> for TypesHeader {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let title_p0 = &self.title_p0;
        let members_p1 = &self.members_p1;
        let declared_p2 = &self.declared_p2;
        let complete_p3 = &self.complete_p3;
        let p_p4 = &self.p_p4;
        let holds_elem_p5 = fold(&p_p4.values, &false, &(|f_p9: &bool, v_pa: &crate::emit::cpp::items::ValueDecl| *f_p9 || fold(&v_pa.deps, &false, &(|g_pb: &bool, d_pc: &Text| (*g_pb || (d_pc == &Text::lit("Elem"))) || (d_pc == &Text::lit("Answer"))))));
        let elem_p6 = if holds_elem_p5 {
            Text::lit("#include \"elem.types.hpp\"")
        } else {
            Text::lit("#include \"elem.decl.hpp\"")
        };
        let includes_p7 = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![includes(&Text::lit("decl"), members_p1), elem_p6.clone(), includes(&Text::lit("decl"), declared_p2), includes(&Text::lit("types"), complete_p3)]), &(|t_pd: &Text| t_pd != &Text::lit(""))), &Text::lit("\n"));
        let p_p4 = p_p4.clone();
        let title_p0 = title_p0.clone();
        call_then(start_order_values(p_p4.values.clone(), fold(&p_p4.values, &Map::new(), &(|acc_pe: &Map<Text, bool>, v_pf: &crate::emit::cpp::items::ValueDecl| insert(acc_pe, &v_pf.path_, &false))), Array::new()), move |order_values_16279: Array<Text>| {
            let values_p8 = crate::syntax::lexer::chars::join(&order_values_16279, &Text::lit("\n\n"));
            prism_rtl::Turn::Finished(crate::emit::cpp::templates::cpp_types_header(&title_p0, &includes_p7, &values_p8))
        })
    }
}

/// `Start TypesHeader, x`: what the function value is when passed to `@Run`.
pub fn start_types_header(title_p0: Text, members_p1: Array<Text>, declared_p2: Array<Text>, complete_p3: Array<Text>, p_p4: crate::emit::cpp::items::Parts) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TypesHeader { title_p0, members_p1, declared_p2, complete_p3, p_p4 })
}

/// ```prism
/// Includes: fn Text, [Text] -> Text
/// ```
pub fn includes(layer_p0: &Text, ms_p1: &Array<Text>) -> Text {
    crate::syntax::lexer::chars::join(&each(ms_p1, &(|m_p2: &Text| Text::from(format!("#include <{}/{}.hpp>", &mod_dir(m_p2), &(if layer_p0 == &Text::lit("") { Text::lit("module") } else { layer_p0.clone() }))))), &Text::lit("\n"))
}

/// ```prism
/// Chunks: fn [Text] -> [ [Text] ]
/// ```
pub fn chunks(defs_p0: &Array<Text>) -> Array<Array<Text>> {
    let (done_p5, current_p6, size_p7) = fold(defs_p0, &(Array::new(), Array::new(), Nat::from(0u32)), &(|(acc_p1, cur_p2, n_p3): &(Array<Array<Text>>, Array<Text>, Nat), d_p4: &Text| if (n_p3 > &chunk_size()) && (&len(cur_p2) > &Nat::from(0u32)) {
        (push(acc_p1, cur_p2), Array::from(vec![d_p4.clone()]), len_text(d_p4))
    } else {
        (acc_p1.clone(), push(cur_p2, d_p4), n_p3 + &len_text(d_p4))
    }));
    if (&len(&current_p6) == &Nat::from(0u32)) && (&len(&done_p5) > &Nat::from(0u32)) {
        done_p5.clone()
    } else {
        push(&done_p5, &current_p6)
    }
}

/// ```prism
/// let chunkSize
/// ```
pub fn chunk_size() -> Nat {
    Nat::from(250000u32)
}

/// ```prism
/// ModuleFiles: unbounded fn ModDef, Parts -> (([((Text, Text))], [Piece]))
/// ```
pub fn module_files(m_p0: &crate::lower::model::ModDef, p_p1: &crate::emit::cpp::items::Parts) -> (Array<(Text, Text)>, Array<Piece>) {
    let title_p2 = if &m_p0.prism == &Text::lit("") {
        Text::lit("The root module")
    } else {
        Text::from(format!("The module `{}`", &m_p0.prism))
    };
    let needed_p3 = append(&m_p0.complete, &m_p0.declared);
    let decl_p4 = crate::emit::cpp::templates::cpp_decl_header(&title_p2, &Text::lit(""), &crate::syntax::lexer::chars::join(&p_p1.forward, &Text::lit("\n\n")));
    let types_p5 = if &len(&m_p0.types_with) > &Nat::from(1u32) {
        crate::emit::cpp::templates::cpp_types_in_group(&title_p2, &group_name(&m_p0.types_with))
    } else {
        types_header(&title_p2, &Array::from(vec![m_p0.name.clone()]), &m_p0.declared, &m_p0.complete, p_p1)
    };
    let head_includes_p6 = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![Text::from(format!("{}\n#include \"elem.types.hpp\"", &includes(&Text::lit("types"), &Array::from(vec![m_p0.name.clone()])))), includes(&Text::lit("types"), &needed_p3)]), &(|t_pd: &Text| t_pd != &Text::lit(""))), &Text::lit("\n"));
    let head_p7 = crate::emit::cpp::templates::cpp_mod_header(&title_p2, &head_includes_p6, &crate::syntax::lexer::chars::join(&p_p1.protos, &Text::lit("\n")), &crate::syntax::lexer::chars::join(&p_p1.outer, &Text::lit("\n\n")), &crate::syntax::lexer::chars::join(&p_p1.classes, &Text::lit("\n\n")));
    let with_mine_p8 = append(&Array::from(vec![m_p0.name.clone()]), &needed_p3);
    let generic_p9 = if &len(&p_p1.generic) == &Nat::from(0u32) {
        Array::new()
    } else {
        Array::from(vec![(Text::from(format!("src/{}/generic.hpp", &mod_dir(&m_p0.name))), crate::emit::cpp::templates::cpp_generic_header(&title_p2, &includes(&Text::lit(""), &with_mine_p8), &crate::syntax::lexer::chars::join(&p_p1.generic, &Text::lit("\n\n"))))])
    };
    let chunks_pa = if &len(&p_p1.defs) == &Nat::from(0u32) { Array::new() } else { chunks(&p_p1.defs) };
    let pieces_pb = each(&chunks_pa, &(|c_pe: &Array<Text>| Piece { title: title_p2.clone(), prism: m_p0.prism.clone(), path_: m_p0.path_.clone(), ns: m_p0.name.clone(), needs: with_mine_p8.clone(), defs: crate::syntax::lexer::chars::join(c_pe, &Text::lit("\n\n")) }));
    let dir_pc = mod_dir(&m_p0.name);
    (append(&Array::from(vec![(Text::from(format!("src/{}/decl.hpp", &dir_pc)), decl_p4.clone()), (Text::from(format!("src/{}/types.hpp", &dir_pc)), types_p5.clone()), (Text::from(format!("src/{}/module.hpp", &dir_pc)), head_p7.clone())]), &generic_p9), pieces_pb.clone())
}

/// The step machine of `ModuleFiles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModuleFiles: unbounded fn ModDef, Parts -> (([((Text, Text))], [Piece]))
/// ```
pub struct ModuleFiles {
    pub m_p0: crate::lower::model::ModDef,
    pub p_p1: crate::emit::cpp::items::Parts,
}

impl prism_rtl::Job<(Array<(Text, Text)>, Array<Piece>)> for ModuleFiles {
    fn cycle(&self) -> prism_rtl::Turn<(Array<(Text, Text)>, Array<Piece>)> {
        let m_p0 = &self.m_p0;
        let p_p1 = &self.p_p1;
        let title_p2 = if &m_p0.prism == &Text::lit("") {
            Text::lit("The root module")
        } else {
            Text::from(format!("The module `{}`", &m_p0.prism))
        };
        let needed_p3 = append(&m_p0.complete, &m_p0.declared);
        let decl_p4 = crate::emit::cpp::templates::cpp_decl_header(&title_p2, &Text::lit(""), &crate::syntax::lexer::chars::join(&p_p1.forward, &Text::lit("\n\n")));
        let types_p5 = if &len(&m_p0.types_with) > &Nat::from(1u32) {
            crate::emit::cpp::templates::cpp_types_in_group(&title_p2, &group_name(&m_p0.types_with))
        } else {
            types_header(&title_p2, &Array::from(vec![m_p0.name.clone()]), &m_p0.declared, &m_p0.complete, p_p1)
        };
        let head_includes_p6 = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![Text::from(format!("{}\n#include \"elem.types.hpp\"", &includes(&Text::lit("types"), &Array::from(vec![m_p0.name.clone()])))), includes(&Text::lit("types"), &needed_p3)]), &(|t_pd: &Text| t_pd != &Text::lit(""))), &Text::lit("\n"));
        let head_p7 = crate::emit::cpp::templates::cpp_mod_header(&title_p2, &head_includes_p6, &crate::syntax::lexer::chars::join(&p_p1.protos, &Text::lit("\n")), &crate::syntax::lexer::chars::join(&p_p1.outer, &Text::lit("\n\n")), &crate::syntax::lexer::chars::join(&p_p1.classes, &Text::lit("\n\n")));
        let with_mine_p8 = append(&Array::from(vec![m_p0.name.clone()]), &needed_p3);
        let generic_p9 = if &len(&p_p1.generic) == &Nat::from(0u32) {
            Array::new()
        } else {
            Array::from(vec![(Text::from(format!("src/{}/generic.hpp", &mod_dir(&m_p0.name))), crate::emit::cpp::templates::cpp_generic_header(&title_p2, &includes(&Text::lit(""), &with_mine_p8), &crate::syntax::lexer::chars::join(&p_p1.generic, &Text::lit("\n\n"))))])
        };
        let chunks_pa = if &len(&p_p1.defs) == &Nat::from(0u32) { Array::new() } else { chunks(&p_p1.defs) };
        let pieces_pb = each(&chunks_pa, &(|c_pe: &Array<Text>| Piece { title: title_p2.clone(), prism: m_p0.prism.clone(), path_: m_p0.path_.clone(), ns: m_p0.name.clone(), needs: with_mine_p8.clone(), defs: crate::syntax::lexer::chars::join(c_pe, &Text::lit("\n\n")) }));
        let dir_pc = mod_dir(&m_p0.name);
        prism_rtl::Turn::Finished((append(&Array::from(vec![(Text::from(format!("src/{}/decl.hpp", &dir_pc)), decl_p4.clone()), (Text::from(format!("src/{}/types.hpp", &dir_pc)), types_p5.clone()), (Text::from(format!("src/{}/module.hpp", &dir_pc)), head_p7.clone())]), &generic_p9), pieces_pb.clone()))
    }
}

/// `Start ModuleFiles, x`: what the function value is when passed to `@Run`.
pub fn start_module_files(m_p0: crate::lower::model::ModDef, p_p1: crate::emit::cpp::items::Parts) -> Rc<dyn prism_rtl::Job<(Array<(Text, Text)>, Array<Piece>)>> {
    Rc::new(ModuleFiles { m_p0, p_p1 })
}

/// ```prism
/// Units: fn [Piece] -> [ [Piece] ]
/// ```
pub fn units(pieces_p0: &Array<Piece>) -> Array<Array<Piece>> {
    let (done_p5, current_p6, size_p7) = fold(pieces_p0, &(Array::new(), Array::new(), Nat::from(0u32)), &(|(acc_p1, cur_p2, n_p3): &(Array<Array<Piece>>, Array<Piece>, Nat), pc_p4: &Piece| if (&len(cur_p2) > &Nat::from(0u32)) && (&(n_p3 + &len_text(&pc_p4.defs)) > &unit_size()) {
        (push(acc_p1, cur_p2), Array::from(vec![pc_p4.clone()]), len_text(&pc_p4.defs))
    } else {
        (acc_p1.clone(), push(cur_p2, pc_p4), n_p3 + &len_text(&pc_p4.defs))
    }));
    if &len(&current_p6) == &Nat::from(0u32) {
        done_p5.clone()
    } else {
        push(&done_p5, &current_p6)
    }
}

/// ```prism
/// let unitSize
/// ```
pub fn unit_size() -> Nat {
    Nat::from(125000u32)
}

/// ```prism
/// UnitFile: fn Nat, [Piece], [Text] -> ((Text, Text))
/// ```
pub fn unit_file(k_p0: &Nat, pieces_p1: &Array<Piece>, generics_p2: &Array<Text>) -> (Text, Text) {
    let needs_p3 = fold(pieces_p1, &Array::new(), &(|acc_p8: &Array<Text>, pc_p9: &Piece| fold(&pc_p9.needs, acc_p8, &(|a_pa: &Array<Text>, n_pb: &Text| if among(a_pa, n_pb) { a_pa.clone() } else { push(a_pa, n_pb) }))));
    let includes_p4 = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![includes(&Text::lit(""), &needs_p3), includes(&Text::lit("generic"), &filter(&needs_p3, &(|n_pc: &Text| among(generics_p2, n_pc))))]), &(|t_pd: &Text| t_pd != &Text::lit(""))), &Text::lit("\n"));
    let names_p5 = fold(pieces_p1, &Array::new(), &(|acc_pe: &Array<Text>, pc_pf: &Piece| if among(acc_pe, &pc_pf.prism) { acc_pe.clone() } else { push(acc_pe, &pc_pf.prism) }));
    let title_p6 = if &len(&names_p5) == &Nat::from(1u32) {
        or(&index(pieces_p1, &Nat::from(0u32)), &dummy_piece()).title.clone()
    } else {
        Text::from(format!("The modules {}", &crate::syntax::lexer::chars::join(&each(&names_p5, &(|n_pg: &Text| if n_pg == &Text::lit("") {
            Text::lit("the root")
        } else {
            Text::from(format!("`{}`", n_pg))
        })), &Text::lit(", "))))
    };
    let parts_p7 = crate::syntax::lexer::chars::join(&each(pieces_p1, &(|pc_ph: &Piece| crate::emit::cpp::templates::cpp_unit_part(&pc_ph.title, &pc_ph.path_, &pc_ph.ns, &pc_ph.defs))), &Text::lit("\n\n"));
    (Text::from(format!("src/unit_{}.cpp", &(k_p0 + &Nat::from(1u32)))), crate::emit::cpp::templates::cpp_unit(&title_p6, &includes_p4, &parts_p7))
}

/// ```prism
/// let dummyPiece
/// ```
pub fn dummy_piece() -> Piece {
    Piece { title: Text::lit(""), prism: Text::lit(""), path_: Text::lit(""), ns: Text::lit(""), needs: Array::new(), defs: Text::lit("") }
}

/// ```prism
/// AllProgramsCpp: fn Model -> [ProgDef]
/// ```
pub fn all_programs_cpp(model_p0: &crate::lower::model::Model) -> Array<crate::lower::model::ProgDef> {
    match &model_p0.root {
        Some(r_p1) => if fold(&model_p0.programs, &false, &(|f_p2: &bool, p_p3: &crate::lower::model::ProgDef| *f_p2 || (&p_p3.name == &r_p1.name))) {
            model_p0.programs.clone()
        } else {
            push(&model_p0.programs, r_p1)
        },
        None => model_p0.programs.clone(),
    }
}

/// ```prism
/// OrderValues: unbounded fn [ValueDecl], (Text ==> Bool), [Text] -> [Text]
/// ```
pub fn order_values(left_p0: &Array<crate::emit::cpp::items::ValueDecl>, done_p1: &Map<Text, bool>, acc_p2: &Array<Text>) -> Array<Text> {
    let ready_p3 = filter(left_p0, &(|v_p4: &crate::emit::cpp::items::ValueDecl| fold(&v_p4.deps, &true, &(|ok_p5: &bool, d_p6: &Text| *ok_p5 && ((d_p6 == &v_p4.path_) || declared(done_p1, d_p6))))));
    if &len(left_p0) == &Nat::from(0u32) {
        acc_p2.clone()
    } else {
        if &len(&ready_p3) == &Nat::from(0u32) {
            append(acc_p2, &each(left_p0, &(|v_p7: &crate::emit::cpp::items::ValueDecl| v_p7.text.clone())))
        } else {
            {
                let later_p8 = filter(left_p0, &(|v_pa: &crate::emit::cpp::items::ValueDecl| !fold(&v_pa.deps, &true, &(|ok_pb: &bool, d_pc: &Text| *ok_pb && ((d_pc == &v_pa.path_) || declared(done_p1, d_pc))))));
                let done2_p9 = fold(&ready_p3, done_p1, &(|m_pd: &Map<Text, bool>, v_pe: &crate::emit::cpp::items::ValueDecl| insert(m_pd, &v_pe.path_, &true)));
                order_values(&later_p8, &done2_p9, &append(acc_p2, &each(&ready_p3, &(|v_pf: &crate::emit::cpp::items::ValueDecl| v_pf.text.clone()))))
            }
        }
    }
}

/// The step machine of `OrderValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OrderValues: unbounded fn [ValueDecl], (Text ==> Bool), [Text] -> [Text]
/// ```
pub struct OrderValues {
    pub left_p0: Array<crate::emit::cpp::items::ValueDecl>,
    pub done_p1: Map<Text, bool>,
    pub acc_p2: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for OrderValues {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let left_p0 = &self.left_p0;
        let done_p1 = &self.done_p1;
        let acc_p2 = &self.acc_p2;
        let ready_p3 = filter(left_p0, &(|v_p4: &crate::emit::cpp::items::ValueDecl| fold(&v_p4.deps, &true, &(|ok_p5: &bool, d_p6: &Text| *ok_p5 && ((d_p6 == &v_p4.path_) || declared(done_p1, d_p6))))));
        if &len(left_p0) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished(acc_p2.clone())
        } else {
            if &len(&ready_p3) == &Nat::from(0u32) {
                prism_rtl::Turn::Finished(append(acc_p2, &each(left_p0, &(|v_p7: &crate::emit::cpp::items::ValueDecl| v_p7.text.clone()))))
            } else {
                {
                    let later_p8 = filter(left_p0, &(|v_pa: &crate::emit::cpp::items::ValueDecl| !fold(&v_pa.deps, &true, &(|ok_pb: &bool, d_pc: &Text| *ok_pb && ((d_pc == &v_pa.path_) || declared(done_p1, d_pc))))));
                    let done2_p9 = fold(&ready_p3, done_p1, &(|m_pd: &Map<Text, bool>, v_pe: &crate::emit::cpp::items::ValueDecl| insert(m_pd, &v_pe.path_, &true)));
                    prism_rtl::Turn::More(Rc::new(OrderValues { left_p0: later_p8.clone(), done_p1: done2_p9.clone(), acc_p2: append(acc_p2, &each(&ready_p3, &(|v_pf: &crate::emit::cpp::items::ValueDecl| v_pf.text.clone()))) }))
                }
            }
        }
    }
}

/// `Start OrderValues, x`: what the function value is when passed to `@Run`.
pub fn start_order_values(left_p0: Array<crate::emit::cpp::items::ValueDecl>, done_p1: Map<Text, bool>, acc_p2: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(OrderValues { left_p0, done_p1, acc_p2 })
}

/// ```prism
/// Declared: fn (Text ==> Bool), Text -> Bool
/// ```
pub fn declared(done_p0: &Map<Text, bool>, d_p1: &Text) -> bool {
    match get(done_p0, d_p1) {
        Some(b_p2) => b_p2,
        None => true,
    }
}
