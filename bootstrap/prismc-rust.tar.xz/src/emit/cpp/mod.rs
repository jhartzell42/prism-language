//! The module `Emit.Cpp`, from `target/bootstrap/src/prismc/emit/cpp/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;
pub mod expr;
pub mod items;
pub mod patterns;
pub mod prelude;
pub mod program;
pub mod stmts;
pub mod templates;

/// `Cp`:
///
/// ```prism
/// type Cp = record:
/// ```
#[derive(::std::clone::Clone)]
pub struct Cp {
    pub home_p: crate::prelude::Text,
    pub mods_p: crate::prelude::Array<crate::prelude::Text>,
    pub types_p: crate::prelude::Map<crate::prelude::Text, TyInfo>,
    pub ctors_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>,
    pub members_p: crate::prelude::Map<crate::prelude::Text, bool>,
    pub methods_p: crate::prelude::Map<crate::prelude::Text, bool>,
    pub field_names_p: crate::prelude::Map<crate::prelude::Text, bool>,
    pub fields_p: crate::prelude::Map<crate::prelude::Text, crate::lower::model::OutTy>,
    pub pointers_p: crate::prelude::Map<crate::prelude::Text, bool>,
    pub owned_p: crate::prelude::Map<crate::prelude::Text, bool>,
    pub move_captures_p: crate::prelude::Array<crate::prelude::Text>,
    pub local_types_p: crate::prelude::Map<crate::prelude::Text, crate::lower::model::OutTy>,
}

impl crate::prelude::ToPod for Cp {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Cp", vec![("home", self.home_p.to_pod()), ("mods", self.mods_p.to_pod()), ("types", self.types_p.to_pod()), ("ctors", self.ctors_p.to_pod()), ("members", self.members_p.to_pod()), ("methods", self.methods_p.to_pod()), ("fieldNames", self.field_names_p.to_pod()), ("fields", self.fields_p.to_pod()), ("pointers", self.pointers_p.to_pod()), ("owned", self.owned_p.to_pod()), ("moveCaptures", self.move_captures_p.to_pod()), ("localTypes", self.local_types_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Cp {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Cp { home_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "home")?)?, mods_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "mods")?)?, types_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "types")?)?, ctors_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "ctors")?)?, members_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "members")?)?, methods_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "methods")?)?, field_names_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "fieldNames")?)?, fields_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "fields")?)?, pointers_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "pointers")?)?, owned_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "owned")?)?, move_captures_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "moveCaptures")?)?, local_types_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "localTypes")?)? })
    }
}

/// `TyInfo`:
///
/// ```prism
/// type TyInfo = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct TyInfo {
    pub kind_p: crate::prelude::Text,
    pub fields_p: crate::prelude::Array<crate::prelude::Text>,
    pub params_p: crate::prelude::Array<crate::prelude::Text>,
}

impl crate::prelude::Show for TyInfo {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("TyInfo", &[("kind", &self.kind_p), ("fields", &self.fields_p), ("params", &self.params_p)]);
    }
}

impl crate::prelude::ToPod for TyInfo {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("TyInfo", vec![("kind", self.kind_p.to_pod()), ("fields", self.fields_p.to_pod()), ("params", self.params_p.to_pod())])
    }
}

impl crate::prelude::FromPod for TyInfo {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(TyInfo { kind_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "kind")?)?, fields_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "fields")?)?, params_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "params")?)? })
    }
}

/// ```prism
/// CppId: fn Text -> Text
/// ```
pub fn cpp_id_f(n_p0: &crate::prelude::Text) -> crate::prelude::Text {
    if in_list_f(&crate::lower::cpp_keywords_p(), n_p0) {
        crate::prelude::Text::from(format!("{}_", n_p0))
    } else {
        n_p0.clone()
    }
}

/// ```prism
/// FieldId: fn Text -> Text
/// ```
pub fn field_id_f(f_p0: &crate::prelude::Text) -> crate::prelude::Text {
    cpp_id_f(f_p0)
}

/// ```prism
/// CppPathId: fn Text -> Text
/// ```
pub fn cpp_path_id_f(p_p0: &crate::prelude::Text) -> crate::prelude::Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::prelude::split_on(p_p0, &crate::prelude::Text::lit("::")), &(|s_p1: &crate::prelude::Text| cpp_id_f(s_p1))), &crate::prelude::Text::lit("::"))
}

/// ```prism
/// Bare: fn Text -> Text
/// ```
pub fn bare_f(p_p0: &crate::prelude::Text) -> crate::prelude::Text {
    crate::syntax::lexer::chars::drop_prefix_f(&crate::syntax::lexer::chars::drop_prefix_f(p_p0, &crate::prelude::Text::lit("rt::")), &crate::prelude::Text::lit("std::"))
}

/// ```prism
/// InList: fn [Text], Text -> Bool
/// ```
pub fn in_list_f(xs_p0: &crate::prelude::Array<crate::prelude::Text>, x_p1: &crate::prelude::Text) -> bool {
    crate::prelude::fold(xs_p0, &false, &(|seen_p2: &bool, y_p3: &crate::prelude::Text| *seen_p2 || (y_p3 == x_p1)))
}

/// ```prism
/// ?TypeOf: fn Cp, Ref -> ?TyInfo
/// ```
pub fn type_of_o(cp_p0: &Cp, r_p1: &crate::lower::model::Ref) -> ::std::option::Option<TyInfo> {
    match crate::lower::model::ref_key_o(r_p1) {
        ::std::option::Option::Some(k_p2) => crate::prelude::get(&cp_p0.types_p, &k_p2),
        ::std::option::Option::None => ::std::option::Option::None,
    }
}

/// ```prism
/// ?CaseOf: fn Cp, Ref -> ?Ref
/// ```
pub fn case_of_o(cp_p0: &Cp, r_p1: &crate::lower::model::Ref) -> ::std::option::Option<crate::lower::model::Ref> {
    match crate::lower::model::ref_key_o(r_p1) {
        ::std::option::Option::Some(k_p2) => match crate::prelude::get(&cp_p0.ctors_p, &k_p2) {
            ::std::option::Option::Some(_) => ::std::option::Option::Some(crate::lower::model::ref_parent_f(r_p1)),
            ::std::option::Option::None => ::std::option::Option::None,
        },
        ::std::option::Option::None => ::std::option::Option::None,
    }
}

/// ```prism
/// PrinterRefusal: fn Text -> Text
/// ```
pub fn printer_refusal_f(what_p0: &crate::prelude::Text) -> crate::prelude::Text {
    crate::prelude::Text::from(format!("compile_error!(\"prismc\'s C++ printer: {}\")", what_p0))
}

/// ```prism
/// CaseId: fn Text, Text -> Text
/// ```
pub fn case_id_f(ty_p0: &crate::prelude::Text, c_p1: &crate::prelude::Text) -> crate::prelude::Text {
    if c_p1 == ty_p0 {
        crate::prelude::Text::from(format!("{}_", c_p1))
    } else {
        c_p1.clone()
    }
}

/// ```prism
/// CaseIdOf: fn Ref -> Text
/// ```
pub fn case_id_of_f(r_p0: &crate::lower::model::Ref) -> crate::prelude::Text {
    case_id_f(&crate::lower::model::ref_last_f(&crate::lower::model::ref_parent_f(r_p0)), &crate::lower::model::ref_last_f(r_p0))
}

/// ```prism
/// CppCases: fn TyDef -> TyDef
/// ```
pub fn cpp_cases_f(t_p0: &crate::lower::model::TyDef) -> crate::lower::model::TyDef {
    if &t_p0.shape_p != &crate::lower::model::TyShape::ShapeChoice {
        t_p0.clone()
    } else {
        {
            let mut this: crate::lower::model::TyDef = t_p0.clone();
            this.cases_p = crate::prelude::each(&this.cases_p, &(|c_p1: &crate::lower::model::CaseDef| {
                let mut this: crate::lower::model::CaseDef = c_p1.clone();
                this.name_p = case_id_f(&t_p0.name_p, &this.name_p);
                this
            }));
            this
        }
    }
}

/// ```prism
/// ParentPath: fn Text -> Text
/// ```
pub fn parent_path_f(p_p0: &crate::prelude::Text) -> crate::prelude::Text {
    let segs_p1 = crate::prelude::split_on(p_p0, &crate::prelude::Text::lit("::"));
    crate::syntax::lexer::chars::join_f(&crate::prelude::take(&segs_p1, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&segs_p1))), &crate::prelude::Text::lit("::"))
}

/// ```prism
/// LastSegment: fn Text -> Text
/// ```
pub fn last_segment_f(p_p0: &crate::prelude::Text) -> crate::prelude::Text {
    crate::prelude::or(&crate::syntax::lexer::chars::last_o(&crate::prelude::split_on(p_p0, &crate::prelude::Text::lit("::"))), p_p0)
}

/// ```prism
/// Context: fn Model -> Cp
/// ```
pub fn context_f(model_p0: &crate::lower::model::Model) -> Cp {
    let names_p1 = crate::prelude::each(&model_p0.mods_p, &(|m_p6: &crate::lower::model::ModDef| m_p6.name_p.clone()));
    let tops_p2 = crate::prelude::fold(&names_p1, &crate::prelude::Array::new(), &(|acc_p7: &crate::prelude::Array<crate::prelude::Text>, n_p8: &crate::prelude::Text| {
        let top_p9 = crate::prelude::or(&crate::prelude::index(&crate::prelude::split_on(n_p8, &crate::prelude::Text::lit("::")), &crate::prelude::Nat::from(0u32)), n_p8);
        if in_list_f(&names_p1, &top_p9) || in_list_f(acc_p7, &top_p9) {
            acc_p7.clone()
        } else {
            crate::prelude::push(acc_p7, &top_p9)
        }
    }));
    let mods_p3 = crate::prelude::push(&crate::prelude::append(&names_p1, &tops_p2), &crate::prelude::Text::lit("prelude"));
    let base_p4 = Cp { home_p: crate::prelude::Text::lit(""), mods_p: mods_p3.clone(), types_p: prelude_types_p(), ctors_p: prelude_ctors_p(), members_p: node_base_p(), methods_p: crate::prelude::Map::new(), field_names_p: crate::prelude::Map::new(), fields_p: crate::prelude::Map::new(), pointers_p: crate::prelude::Map::new(), owned_p: crate::prelude::Map::new(), move_captures_p: crate::prelude::Array::new(), local_types_p: crate::prelude::Map::new() };
    let with_elem_p5 = add_row_f(&add_answer_f(&base_p4, &model_p0.answer_p), &crate::prelude::Text::lit(""), &model_p0.elem_p);
    crate::prelude::fold(&model_p0.mods_p, &with_elem_p5, &(|cp_pa: &Cp, m_pb: &crate::lower::model::ModDef| crate::prelude::fold(&m_pb.items_p, cp_pa, &(|c_pc: &Cp, it_pd: &crate::lower::model::Item| add_model_item_f(c_pc, &m_pb.name_p, it_pd)))))
}

/// ```prism
/// let preludeTypes
/// ```
pub fn prelude_types_p() -> crate::prelude::Map<crate::prelude::Text, TyInfo> {
    crate::prelude::map_of(vec![(crate::prelude::Text::lit("prelude::Ordering"), TyInfo { kind_p: crate::prelude::Text::lit("choice"), fields_p: crate::prelude::Array::new(), params_p: crate::prelude::Array::new() }), (crate::prelude::Text::lit("prelude::Span"), TyInfo { kind_p: crate::prelude::Text::lit("record"), fields_p: crate::prelude::Array::from(vec![crate::prelude::Text::lit("file_p"), crate::prelude::Text::lit("line_p"), crate::prelude::Text::lit("column_p"), crate::prelude::Text::lit("binding_p")]), params_p: crate::prelude::Array::new() }), (crate::prelude::Text::lit("prelude::Exception"), TyInfo { kind_p: crate::prelude::Text::lit("record"), fields_p: crate::prelude::Array::from(vec![crate::prelude::Text::lit("kind_p"), crate::prelude::Text::lit("message_p"), crate::prelude::Text::lit("spans_p"), crate::prelude::Text::lit("path_o")]), params_p: crate::prelude::Array::new() }), (crate::prelude::Text::lit("prelude::Duration"), TyInfo { kind_p: crate::prelude::Text::lit("newtype"), fields_p: crate::prelude::Array::new(), params_p: crate::prelude::Array::new() }), (crate::prelude::Text::lit("prelude::PreludeUnwrap"), TyInfo { kind_p: crate::prelude::Text::lit("tag"), fields_p: crate::prelude::Array::new(), params_p: crate::prelude::Array::new() }), (crate::prelude::Text::lit("prelude::PreludeExceptions"), TyInfo { kind_p: crate::prelude::Text::lit("tag"), fields_p: crate::prelude::Array::new(), params_p: crate::prelude::Array::new() })])
}

/// ```prism
/// let preludeCtors
/// ```
pub fn prelude_ctors_p() -> crate::prelude::Map<crate::prelude::Text, crate::prelude::Text> {
    crate::prelude::map_of(vec![(crate::prelude::Text::lit("prelude::Ordering::Less"), crate::prelude::Text::lit("choice")), (crate::prelude::Text::lit("prelude::Ordering::Equal"), crate::prelude::Text::lit("choice")), (crate::prelude::Text::lit("prelude::Ordering::Greater"), crate::prelude::Text::lit("choice"))])
}

/// ```prism
/// let nodeBase
/// ```
pub fn node_base_p() -> crate::prelude::Map<crate::prelude::Text, bool> {
    crate::prelude::map_of(vec![(crate::prelude::Text::lit("make"), true), (crate::prelude::Text::lit("push"), true), (crate::prelude::Text::lit("wake"), true), (crate::prelude::Text::lit("started"), true), (crate::prelude::Text::lit("deferred"), true), (crate::prelude::Text::lit("build"), true), (crate::prelude::Text::lit("swap"), true), (crate::prelude::Text::lit("leave"), true), (crate::prelude::Text::lit("patch"), true), (crate::prelude::Text::lit("edges"), true), (crate::prelude::Text::lit("release"), true), (crate::prelude::Text::lit("clean_up"), true), (crate::prelude::Text::lit("path"), true), (crate::prelude::Text::lit("leave_row"), true), (crate::prelude::Text::lit("answer"), true), (crate::prelude::Text::lit("document"), true), (crate::prelude::Text::lit("entries"), true), (crate::prelude::Text::lit("deliver"), true), (crate::prelude::Text::lit("document_moved"), true), (crate::prelude::Text::lit("me"), true), (crate::prelude::Text::lit("result_dynamic"), true)])
}

/// ```prism
/// AddModelItem: fn Cp, Text, Item -> Cp
/// ```
pub fn add_model_item_f(cp_p0: &Cp, m_p1: &crate::prelude::Text, it_p2: &crate::lower::model::Item) -> Cp {
    match it_p2 {
        crate::lower::model::Item::ItType(t_p3) => add_type_f(cp_p0, m_p1, t_p3),
        crate::lower::model::Item::ItTag(t_p4) => add_ty_f(cp_p0, &crate::prelude::Text::from(format!("{}::{}", m_p1, &t_p4.name_p)), &TyInfo { kind_p: crate::prelude::Text::lit("tag"), fields_p: crate::prelude::each(&t_p4.fields_p, &(|(_, f_p5, _): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| f_p5.clone())), params_p: crate::prelude::Array::new() }),
        crate::lower::model::Item::ItRow(r_p6) => add_row_f(cp_p0, m_p1, r_p6),
        crate::lower::model::Item::ItJob(j_p7) => add_ty_f(cp_p0, &crate::prelude::Text::from(format!("{}::{}", m_p1, &j_p7.name_p)), &TyInfo { kind_p: crate::prelude::Text::lit("job"), fields_p: crate::prelude::each(&j_p7.fields_p, &(|(f_p8, _): &(crate::prelude::Text, crate::lower::model::OutTy)| f_p8.clone())), params_p: crate::prelude::each(&j_p7.generics_p, &(|(g_p9, _): &(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)| g_p9.clone())) }),
        crate::lower::model::Item::ItNode(n_pa) => add_node_f(cp_p0, m_p1, n_pa),
        _ => cp_p0.clone(),
    }
}

/// ```prism
/// AddTy: fn Cp, Text, TyInfo -> Cp
/// ```
pub fn add_ty_f(cp_p0: &Cp, path_p1: &crate::prelude::Text, info_p2: &TyInfo) -> Cp {
    let mut this: Cp = cp_p0.clone();
    this.types_p = crate::prelude::insert(&this.types_p, path_p1, info_p2);
    this
}

/// ```prism
/// AddCtor: fn Cp, Text, Text -> Cp
/// ```
pub fn add_ctor_f(cp_p0: &Cp, path_p1: &crate::prelude::Text, kind_p2: &crate::prelude::Text) -> Cp {
    let mut this: Cp = cp_p0.clone();
    this.ctors_p = crate::prelude::insert(&this.ctors_p, path_p1, kind_p2);
    this
}

/// ```prism
/// AddMember: fn Cp, Text -> Cp
/// ```
pub fn add_member_f(cp_p0: &Cp, name_p1: &crate::prelude::Text) -> Cp {
    let mut this: Cp = cp_p0.clone();
    this.members_p = crate::prelude::insert(&this.members_p, name_p1, &true);
    this
}

/// ```prism
/// AddType: fn Cp, Text, TyDef -> Cp
/// ```
pub fn add_type_f(cp_p0: &Cp, m_p1: &crate::prelude::Text, t_p2: &crate::lower::model::TyDef) -> Cp {
    let path_p3 = crate::prelude::Text::from(format!("{}::{}", m_p1, &t_p2.name_p));
    let first_p4 = crate::prelude::or(&crate::prelude::index(&t_p2.cases_p, &crate::prelude::Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() });
    match &t_p2.shape_p {
        crate::lower::model::TyShape::ShapeRecord => add_ty_f(cp_p0, &path_p3, &TyInfo { kind_p: crate::prelude::Text::lit("record"), fields_p: crate::prelude::each(&first_p4.fields_p, &(|(f_p5, _): &(crate::prelude::Text, crate::lower::model::OutTy)| f_p5.clone())), params_p: t_p2.params_p.clone() }),
        crate::lower::model::TyShape::ShapeNewtype => add_ty_f(cp_p0, &path_p3, &TyInfo { kind_p: crate::prelude::Text::lit("newtype"), fields_p: crate::prelude::Array::new(), params_p: t_p2.params_p.clone() }),
        crate::lower::model::TyShape::ShapeUnit => add_ty_f(cp_p0, &path_p3, &TyInfo { kind_p: crate::prelude::Text::lit("unit"), fields_p: crate::prelude::Array::new(), params_p: t_p2.params_p.clone() }),
        crate::lower::model::TyShape::ShapeChoice => crate::prelude::fold(&t_p2.cases_p, &add_ty_f(cp_p0, &path_p3, &TyInfo { kind_p: crate::prelude::Text::lit("choice"), fields_p: crate::prelude::Array::new(), params_p: t_p2.params_p.clone() }), &(|c_p6: &Cp, k_p7: &crate::lower::model::CaseDef| add_ctor_f(c_p6, &crate::prelude::Text::from(format!("{}::{}", &path_p3, &k_p7.name_p)), &crate::prelude::Text::lit("choice")))),
    }
}

/// ```prism
/// AddRow: fn Cp, Text, RowDef -> Cp
/// ```
pub fn add_row_f(cp_p0: &Cp, m_p1: &crate::prelude::Text, r_p2: &crate::lower::model::RowDef) -> Cp {
    let path_p3 = if m_p1 == &crate::prelude::Text::lit("") {
        r_p2.name_p.clone()
    } else {
        crate::prelude::Text::from(format!("{}::{}", m_p1, &r_p2.name_p))
    };
    crate::prelude::fold(&r_p2.cases_p, &add_ty_f(cp_p0, &path_p3, &TyInfo { kind_p: crate::prelude::Text::lit("choice"), fields_p: crate::prelude::Array::new(), params_p: crate::prelude::Array::new() }), &(|c_p4: &Cp, (v_p5, _): &(crate::prelude::Text, crate::lower::model::Ref)| add_ctor_f(c_p4, &crate::prelude::Text::from(format!("{}::{}", &path_p3, v_p5)), &crate::prelude::Text::lit("choice"))))
}

/// ```prism
/// AddAnswer: fn Cp, AnswerDef -> Cp
/// ```
pub fn add_answer_f(cp_p0: &Cp, a_p1: &crate::lower::model::AnswerDef) -> Cp {
    crate::prelude::fold(&a_p1.cases_p, &add_ctor_f(&add_ctor_f(&add_ty_f(cp_p0, &crate::prelude::Text::lit("Answer"), &TyInfo { kind_p: crate::prelude::Text::lit("choice"), fields_p: crate::prelude::Array::new(), params_p: crate::prelude::Array::new() }), &crate::prelude::Text::lit("Answer::Untagged_a"), &crate::prelude::Text::lit("choice")), &crate::prelude::Text::lit("Answer::Held_a"), &crate::prelude::Text::lit("choice")), &(|c_p2: &Cp, k_p3: &crate::lower::model::AnswerCase| add_answer_case_f(c_p2, k_p3)))
}

/// ```prism
/// AddAnswerCase: fn Cp, AnswerCase -> Cp
/// ```
pub fn add_answer_case_f(c_p0: &Cp, k_p1: &crate::lower::model::AnswerCase) -> Cp {
    let c1_p2 = add_ctor_f(c_p0, &crate::prelude::Text::from(format!("Answer::{}", &k_p1.variant_p)), &crate::prelude::Text::lit("choice"));
    match &k_p1.first_o {
        ::std::option::Option::Some(_) => add_ctor_f(&c1_p2, &crate::prelude::Text::from(format!("Answer::{}First", &k_p1.variant_p)), &crate::prelude::Text::lit("choice")),
        ::std::option::Option::None => c1_p2.clone(),
    }
}

/// ```prism
/// AddNode: fn Cp, Text, NodeDef -> Cp
/// ```
pub fn add_node_f(cp_p0: &Cp, m_p1: &crate::prelude::Text, n_p2: &crate::lower::model::NodeDef) -> Cp {
    let with_fields_p3 = crate::prelude::fold(&n_p2.fields_p, cp_p0, &(|c_p7: &Cp, (f_p8, _, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| {
        let mut this: Cp = add_member_f(c_p7, f_p8);
        this.field_names_p = crate::prelude::insert(&this.field_names_p, f_p8, &true);
        this
    }));
    let with_methods_p4 = crate::prelude::fold(&crate::prelude::append(&n_p2.methods_p, &n_p2.hosted_p), &with_fields_p3, &(|c_p9: &Cp, md_pa: &crate::lower::model::MethDef| {
        let mut this: Cp = add_member_f(c_p9, &md_pa.name_p);
        this.methods_p = crate::prelude::insert(&this.methods_p, &md_pa.name_p, &true);
        this
    }));
    let with_builders_p5 = crate::prelude::fold(&n_p2.builders_p, &with_methods_p4, &(|c_pb: &Cp, b_pc: &crate::lower::model::ForDef| add_member_f(c_pb, &crate::prelude::Text::from(format!("{}_build", &b_pc.name_p)))));
    let with_gens_p6 = crate::prelude::fold(&n_p2.gens_p, &with_builders_p5, &(|c_pd: &Cp, g_pe: &crate::lower::model::GenDef| add_member_f(c_pd, &crate::prelude::Text::from(format!("{}_build", &g_pe.name_p)))));
    add_ty_f(&with_gens_p6, &crate::prelude::Text::from(format!("{}::{}", m_p1, &n_p2.name_p)), &TyInfo { kind_p: crate::prelude::Text::lit("node"), fields_p: crate::prelude::each(&n_p2.fields_p, &(|(f_pf, _, _): &(crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| f_pf.clone())), params_p: crate::prelude::Array::new() })
}

/// ```prism
/// InHome: fn Cp, Text -> Cp
/// ```
pub fn in_home_f(cp_p0: &Cp, m_p1: &crate::prelude::Text) -> Cp {
    let mut this: Cp = cp_p0.clone();
    this.home_p = m_p1.clone();
    this
}

/// ```prism
/// WithFields: fn Cp, [((Text, OutTy))] -> Cp
/// ```
pub fn with_fields_f(cp_p0: &Cp, fs_p1: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>) -> Cp {
    let mut this: Cp = cp_p0.clone();
    this.fields_p = crate::prelude::fold(fs_p1, &crate::prelude::Map::new(), &(|acc_p2: &crate::prelude::Map<crate::prelude::Text, crate::lower::model::OutTy>, (f_p3, t_p4): &(crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::insert(acc_p2, f_p3, t_p4)));
    this
}

/// ```prism
/// CppType: unbounded fn Cp, OutTy -> Text
/// ```
pub fn cpp_type_f(cp_p0: &Cp, t_p1: &crate::lower::model::OutTy) -> crate::prelude::Text {
    'm12316: {
        if let crate::lower::model::OutTy::OutNat = t_p1 {
            break 'm12316 crate::prelude::Text::lit("crate::prelude::Nat");
        }
        if let crate::lower::model::OutTy::OutInt = t_p1 {
            break 'm12316 crate::prelude::Text::lit("crate::prelude::Int");
        }
        if let crate::lower::model::OutTy::OutU8 = t_p1 {
            break 'm12316 crate::prelude::Text::lit("::std::uint8_t");
        }
        if let crate::lower::model::OutTy::OutFloat = t_p1 {
            break 'm12316 crate::prelude::Text::lit("crate::prelude::Float");
        }
        if let crate::lower::model::OutTy::OutBool = t_p1 {
            break 'm12316 crate::prelude::Text::lit("bool");
        }
        if let crate::lower::model::OutTy::OutChar = t_p1 {
            break 'm12316 crate::prelude::Text::lit("char32_t");
        }
        if let crate::lower::model::OutTy::OutText = t_p1 {
            break 'm12316 crate::prelude::Text::lit("crate::prelude::Text");
        }
        if let crate::lower::model::OutTy::OutCursor = t_p1 {
            break 'm12316 crate::prelude::Text::lit("crate::prelude::Cursor");
        }
        if let crate::lower::model::OutTy::OutRegex = t_p1 {
            break 'm12316 crate::prelude::Text::lit("crate::prelude::Regex");
        }
        if let crate::lower::model::OutTy::OutReplacement = t_p1 {
            break 'm12316 crate::prelude::Text::lit("crate::prelude::RegexReplacement");
        }
        if let crate::lower::model::OutTy::OutUnit = t_p1 {
            break 'm12316 crate::prelude::Text::lit("crate::prelude::Unit");
        }
        if let crate::lower::model::OutTy::OutPath = t_p1 {
            break 'm12316 crate::prelude::Text::lit("crate::prelude::Path");
        }
        if let crate::lower::model::OutTy::OutDuration = t_p1 {
            break 'm12316 crate::prelude::Text::lit("crate::prelude::Duration");
        }
        if let crate::lower::model::OutTy::OutError = t_p1 {
            break 'm12316 crate::prelude::Text::lit("crate::prelude::Error");
        }
        if let crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(m12316_14_0_0), m12316_14_1) = t_p1 && (m12316_14_0_0 == &crate::prelude::Text::lit("std::Cell")) && (m12316_14_1.len() == 1) && let ::std::option::Option::Some(i_p2) = crate::prelude::index(m12316_14_1, &crate::prelude::Nat::from(0u32)) {
            break 'm12316 cpp_type_f(cp_p0, &i_p2);
        }
        if let crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(m12316_15_0_0), m12316_15_1) = t_p1 && (m12316_15_0_0 == &crate::prelude::Text::lit("std::RefCell")) && (m12316_15_1.len() == 1) && let ::std::option::Option::Some(i_p3) = crate::prelude::index(m12316_15_1, &crate::prelude::Nat::from(0u32)) {
            break 'm12316 cpp_type_f(cp_p0, &i_p3);
        }
        if let crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(m12316_16_0_0), m12316_16_1) = t_p1 && (m12316_16_0_0 == &crate::prelude::Text::lit("std::Vec")) && (m12316_16_1.len() == 1) && let ::std::option::Option::Some(i_p4) = crate::prelude::index(m12316_16_1, &crate::prelude::Nat::from(0u32)) {
            break 'm12316 crate::prelude::Text::from(format!("::std::vector<{}>", &cpp_type_f(cp_p0, &i_p4)));
        }
        if let crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(m12316_17_0_0), m12316_17_1) = t_p1 && (m12316_17_0_0 == &crate::prelude::Text::lit("std::Result")) && (m12316_17_1.len() == 2) && let ::std::option::Option::Some(a_p5) = crate::prelude::index(m12316_17_1, &crate::prelude::Nat::from(0u32)) && let ::std::option::Option::Some(b_p6) = crate::prelude::index(m12316_17_1, &crate::prelude::Nat::from(1u32)) {
            break 'm12316 crate::prelude::Text::from(format!("crate::prelude::Expected<{}, {}>", &cpp_type_f(cp_p0, &a_p5), &cpp_type_f(cp_p0, &b_p6)));
        }
        if let crate::lower::model::OutTy::OutNamed(n_p7, m12316_18_1) = t_p1 && (m12316_18_1.len() == 0) {
            break 'm12316 own_type_path_f(cp_p0, n_p7);
        }
        if let crate::lower::model::OutTy::OutNamed(n_p8, args_p9) = t_p1 {
            break 'm12316 crate::prelude::Text::from(format!("{}<{}>", &own_type_path_f(cp_p0, n_p8), &cpp_types_f(cp_p0, args_p9)));
        }
        if let crate::lower::model::OutTy::OutOpt(m12316_20_0) = t_p1 && let crate::lower::model::OutTy::OutRefMut(i_pa) = &**m12316_20_0 {
            break 'm12316 crate::prelude::Text::from(format!("{}*", &cpp_type_f(cp_p0, &**i_pa)));
        }
        if let crate::lower::model::OutTy::OutOpt(i_pb) = t_p1 {
            break 'm12316 crate::prelude::Text::from(format!("::std::optional<{}>", &cpp_type_f(cp_p0, &**i_pb)));
        }
        if let crate::lower::model::OutTy::OutRes(i_pc) = t_p1 {
            break 'm12316 crate::prelude::Text::from(format!("crate::prelude::Fallible<{}>", &cpp_type_f(cp_p0, &**i_pc)));
        }
        if let crate::lower::model::OutTy::OutTuple(ts_pd) = t_p1 {
            break 'm12316 crate::prelude::Text::from(format!("::std::tuple<{}>", &cpp_types_f(cp_p0, ts_pd)));
        }
        if let crate::lower::model::OutTy::OutArray(e_pe) = t_p1 {
            break 'm12316 crate::prelude::Text::from(format!("crate::prelude::Array<{}>", &cpp_type_f(cp_p0, &**e_pe)));
        }
        if let crate::lower::model::OutTy::OutMap(k_pf, v_pg) = t_p1 {
            break 'm12316 crate::prelude::Text::from(format!("crate::prelude::Map<{}, {}>", &cpp_type_f(cp_p0, &**k_pf), &cpp_type_f(cp_p0, &**v_pg)));
        }
        if let crate::lower::model::OutTy::OutFn(ps_ph, r_pi) = t_p1 {
            break 'm12316 crate::prelude::Text::from(format!("crate::prelude::Fn<{}({})>", &cpp_type_f(cp_p0, &**r_pi), &param_types_f(cp_p0, ps_ph)));
        }
        if let crate::lower::model::OutTy::OutRef(m12316_27_0) = t_p1 && let crate::lower::model::OutTy::OutFn(ps_pj, r_pk) = &**m12316_27_0 {
            break 'm12316 crate::prelude::Text::from(format!("const ::std::function<{}({})>&", &cpp_type_f(cp_p0, &**r_pk), &param_types_f(cp_p0, ps_pj)));
        }
        if let crate::lower::model::OutTy::OutRef(m12316_28_0) = t_p1 && let crate::lower::model::OutTy::OutSlice(i_pl) = &**m12316_28_0 {
            break 'm12316 crate::prelude::Text::from(format!("::std::span<const {}>", &cpp_type_f(cp_p0, &**i_pl)));
        }
        if let crate::lower::model::OutTy::OutRef(i_pm) = t_p1 {
            break 'm12316 crate::prelude::Text::from(format!("const {}&", &cpp_type_f(cp_p0, &**i_pm)));
        }
        if let crate::lower::model::OutTy::OutRefMut(i_pn) = t_p1 {
            break 'm12316 crate::prelude::Text::from(format!("{}&", &cpp_type_f(cp_p0, &**i_pn)));
        }
        if let crate::lower::model::OutTy::OutJobFn(a_po, b_pp) = t_p1 {
            break 'm12316 crate::prelude::Text::from(format!("::prism_rtl::Fn<::prism_rtl::JobRef<{}>({})>", &cpp_type_f(cp_p0, &**b_pp), &cpp_type_f(cp_p0, &**a_po)));
        }
        if let crate::lower::model::OutTy::OutJob(b_pq) = t_p1 {
            break 'm12316 crate::prelude::Text::from(format!("::prism_rtl::JobRef<{}>", &cpp_type_f(cp_p0, &**b_pq)));
        }
        if let crate::lower::model::OutTy::OutEvent(i_pr) = t_p1 {
            break 'm12316 crate::prelude::Text::from(format!("crate::prelude::Event<{}>", &cpp_type_f(cp_p0, &**i_pr)));
        }
        if let crate::lower::model::OutTy::OutDyn(i_ps) = t_p1 {
            break 'm12316 crate::prelude::Text::from(format!("crate::prelude::Dynamic<{}>", &cpp_type_f(cp_p0, &**i_ps)));
        }
        if let crate::lower::model::OutTy::OutGen(n_pt) = t_p1 {
            break 'm12316 n_pt.clone();
        }
        if let crate::lower::model::OutTy::OutRc(i_pu) = t_p1 {
            break 'm12316 if is_value_ty_f(cp_p0, &**i_pu) {
                crate::prelude::Text::from(format!("::prism_rtl::Rc<const {}>", &cpp_type_f(cp_p0, &**i_pu)))
            } else {
                crate::prelude::Text::from(format!("::prism_rtl::Rc<{}>", &cpp_type_f(cp_p0, &**i_pu)))
            };
        }
        if let crate::lower::model::OutTy::OutPod = t_p1 {
            break 'm12316 crate::prelude::Text::lit("crate::prelude::Pod");
        }
        if let crate::lower::model::OutTy::OutShowAny = t_p1 {
            break 'm12316 crate::prelude::Text::lit("::prism_rtl::Rc<const crate::prelude::DynShow>");
        }
        if let crate::lower::model::OutTy::OutHold(i_pv) = t_p1 {
            break 'm12316 crate::prelude::Text::from(format!("crate::prelude::Hold<{}>", &cpp_type_f(cp_p0, &**i_pv)));
        }
        if let crate::lower::model::OutTy::OutStamped(i_p10) = t_p1 {
            break 'm12316 crate::prelude::Text::from(format!("crate::prelude::Stamped<{}>", &cpp_type_f(cp_p0, &**i_p10)));
        }
        if let crate::lower::model::OutTy::OutSnapshot(i_p11) = t_p1 {
            break 'm12316 crate::prelude::Text::from(format!("crate::prelude::Snapshot<{}>", &cpp_type_f(cp_p0, &**i_p11)));
        }
        if let crate::lower::model::OutTy::OutDefer(i_p12) = t_p1 {
            break 'm12316 crate::prelude::Text::from(format!("crate::prelude::Defer<{}>", &cpp_type_f(cp_p0, &**i_p12)));
        }
        if let crate::lower::model::OutTy::OutWeak(n_p13) = t_p1 {
            break 'm12316 crate::prelude::Text::from(format!("::prism_rtl::Weak<{}>", &type_path_f(n_p13)));
        }
        if let crate::lower::model::OutTy::OutCell(i_p14) = t_p1 {
            break 'm12316 cpp_type_f(cp_p0, &**i_p14);
        }
        if let crate::lower::model::OutTy::OutWakes = t_p1 {
            break 'm12316 crate::prelude::Text::lit("crate::prelude::Wakes");
        }
        if let crate::lower::model::OutTy::OutCount = t_p1 {
            break 'm12316 crate::prelude::Text::lit("::std::uint32_t");
        }
        if let crate::lower::model::OutTy::OutObj(i_p15) = t_p1 {
            break 'm12316 crate::prelude::Text::from(format!("::prism_rtl::Rc<{}>", &cpp_type_f(cp_p0, &**i_p15)));
        }
        if let crate::lower::model::OutTy::OutSlice(i_p16) = t_p1 {
            break 'm12316 crate::prelude::Text::from(format!("::std::span<const {}>", &cpp_type_f(cp_p0, &**i_p16)));
        }
        if let crate::lower::model::OutTy::OutPort(i_p17) = t_p1 {
            break 'm12316 crate::prelude::Text::from(format!("crate::prelude::Port<{}>", &cpp_type_f(cp_p0, &**i_p17)));
        }
        if let crate::lower::model::OutTy::OutLive(i_p18) = t_p1 {
            break 'm12316 crate::prelude::Text::from(format!("crate::prelude::Element<{}>", &cpp_type_f(cp_p0, &**i_p18)));
        }
        if let crate::lower::model::OutTy::OutTurn = t_p1 {
            break 'm12316 crate::prelude::Text::lit("decltype(this->cycle())");
        }
        if let crate::lower::model::OutTy::OutAssoc(tr_p19, n_p1a, a_p1b) = t_p1 {
            break 'm12316 crate::prelude::Text::from(format!("typename {}::{}<{}>::type", &type_path_f(tr_p19), n_p1a, &cpp_type_f(cp_p0, &**a_p1b)));
        }
        if let crate::lower::model::OutTy::OutRefused(what_p1c) = t_p1 {
            break 'm12316 crate::prelude::Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::expr::lowering_refusal_p(), what_p1c));
        }
        if let crate::lower::model::OutTy::OutQuantified(b_p1d) = t_p1 {
            break 'm12316 crate::prelude::Text::from(format!("compile_error!(\"{}a quantified type variable of `{}`: no instantiation gives it a type\")", &crate::lower::expr::lowering_refusal_p(), b_p1d));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `CppType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppType: unbounded fn Cp, OutTy -> Text
/// ```
pub struct CppType {
    pub cp_p0: Cp,
    pub t_p1: crate::lower::model::OutTy,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppType {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        'm12316: {
            if let crate::lower::model::OutTy::OutNat = t_p1 {
                break 'm12316 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Nat"));
            }
            if let crate::lower::model::OutTy::OutInt = t_p1 {
                break 'm12316 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Int"));
            }
            if let crate::lower::model::OutTy::OutU8 = t_p1 {
                break 'm12316 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("::std::uint8_t"));
            }
            if let crate::lower::model::OutTy::OutFloat = t_p1 {
                break 'm12316 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Float"));
            }
            if let crate::lower::model::OutTy::OutBool = t_p1 {
                break 'm12316 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("bool"));
            }
            if let crate::lower::model::OutTy::OutChar = t_p1 {
                break 'm12316 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("char32_t"));
            }
            if let crate::lower::model::OutTy::OutText = t_p1 {
                break 'm12316 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Text"));
            }
            if let crate::lower::model::OutTy::OutCursor = t_p1 {
                break 'm12316 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Cursor"));
            }
            if let crate::lower::model::OutTy::OutRegex = t_p1 {
                break 'm12316 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Regex"));
            }
            if let crate::lower::model::OutTy::OutReplacement = t_p1 {
                break 'm12316 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::RegexReplacement"));
            }
            if let crate::lower::model::OutTy::OutUnit = t_p1 {
                break 'm12316 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Unit"));
            }
            if let crate::lower::model::OutTy::OutPath = t_p1 {
                break 'm12316 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Path"));
            }
            if let crate::lower::model::OutTy::OutDuration = t_p1 {
                break 'm12316 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Duration"));
            }
            if let crate::lower::model::OutTy::OutError = t_p1 {
                break 'm12316 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Error"));
            }
            if let crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(m12316_14_0_0), m12316_14_1) = t_p1 && (m12316_14_0_0 == &crate::prelude::Text::lit("std::Cell")) && (m12316_14_1.len() == 1) && let ::std::option::Option::Some(i_p2) = crate::prelude::index(m12316_14_1, &crate::prelude::Nat::from(0u32)) {
                break 'm12316 ::prism_rtl::Turn::More(::std::rc::Rc::new(CppType { cp_p0: cp_p0.clone(), t_p1: i_p2.clone() }));
            }
            if let crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(m12316_15_0_0), m12316_15_1) = t_p1 && (m12316_15_0_0 == &crate::prelude::Text::lit("std::RefCell")) && (m12316_15_1.len() == 1) && let ::std::option::Option::Some(i_p3) = crate::prelude::index(m12316_15_1, &crate::prelude::Nat::from(0u32)) {
                break 'm12316 ::prism_rtl::Turn::More(::std::rc::Rc::new(CppType { cp_p0: cp_p0.clone(), t_p1: i_p3.clone() }));
            }
            if let crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(m12316_16_0_0), m12316_16_1) = t_p1 && (m12316_16_0_0 == &crate::prelude::Text::lit("std::Vec")) && (m12316_16_1.len() == 1) && let ::std::option::Option::Some(i_p4) = crate::prelude::index(m12316_16_1, &crate::prelude::Nat::from(0u32)) {
                break 'm12316 {
                    let cp_p0x = cp_p0.clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_p4.clone()), move |cpp_type_f_13010: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::std::vector<{}>", &cpp_type_f_13010))))
                };
            }
            if let crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(m12316_17_0_0), m12316_17_1) = t_p1 && (m12316_17_0_0 == &crate::prelude::Text::lit("std::Result")) && (m12316_17_1.len() == 2) && let ::std::option::Option::Some(a_p5) = crate::prelude::index(m12316_17_1, &crate::prelude::Nat::from(0u32)) && let ::std::option::Option::Some(b_p6) = crate::prelude::index(m12316_17_1, &crate::prelude::Nat::from(1u32)) {
                break 'm12316 {
                    let cp_p0x = cp_p0.clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), a_p5.clone()), move |cpp_type_f_13105: crate::prelude::Text| crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), b_p6.clone()), move |cpp_type_f_13122: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Expected<{}, {}>", &cpp_type_f_13105, &cpp_type_f_13122)))))
                };
            }
            if let crate::lower::model::OutTy::OutNamed(n_p7, m12316_18_1) = t_p1 && (m12316_18_1.len() == 0) {
                break 'm12316 ::prism_rtl::Turn::Finished(own_type_path_f(cp_p0, n_p7));
            }
            if let crate::lower::model::OutTy::OutNamed(n_p8, args_p9) = t_p1 {
                break 'm12316 {
                    let args_p9x = args_p9.clone();
                    let cp_p0x = cp_p0.clone();
                    let n_p8x = n_p8.clone();
                    crate::prelude::call_then(start_cpp_types_f(cp_p0x.clone(), args_p9x.clone()), move |cpp_types_f_13223: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}<{}>", &own_type_path_f(&cp_p0x, &n_p8x), &cpp_types_f_13223))))
                };
            }
            if let crate::lower::model::OutTy::OutOpt(m12316_20_0) = t_p1 && let crate::lower::model::OutTy::OutRefMut(i_pa) = &**m12316_20_0 {
                break 'm12316 {
                    let cp_p0x = cp_p0.clone();
                    let i_pax = (**i_pa).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_pax.clone()), move |cpp_type_f_13272: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}*", &cpp_type_f_13272))))
                };
            }
            if let crate::lower::model::OutTy::OutOpt(i_pb) = t_p1 {
                break 'm12316 {
                    let cp_p0x = cp_p0.clone();
                    let i_pbx = (**i_pb).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_pbx.clone()), move |cpp_type_f_13321: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::std::optional<{}>", &cpp_type_f_13321))))
                };
            }
            if let crate::lower::model::OutTy::OutRes(i_pc) = t_p1 {
                break 'm12316 {
                    let cp_p0x = cp_p0.clone();
                    let i_pcx = (**i_pc).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_pcx.clone()), move |cpp_type_f_13379: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Fallible<{}>", &cpp_type_f_13379))))
                };
            }
            if let crate::lower::model::OutTy::OutTuple(ts_pd) = t_p1 {
                break 'm12316 {
                    let cp_p0x = cp_p0.clone();
                    let ts_pdx = ts_pd.clone();
                    crate::prelude::call_then(start_cpp_types_f(cp_p0x.clone(), ts_pdx.clone()), move |cpp_types_f_13428: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::std::tuple<{}>", &cpp_types_f_13428))))
                };
            }
            if let crate::lower::model::OutTy::OutArray(e_pe) = t_p1 {
                break 'm12316 {
                    let cp_p0x = cp_p0.clone();
                    let e_pex = (**e_pe).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), e_pex.clone()), move |cpp_type_f_13487: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Array<{}>", &cpp_type_f_13487))))
                };
            }
            if let crate::lower::model::OutTy::OutMap(k_pf, v_pg) = t_p1 {
                break 'm12316 {
                    let cp_p0x = cp_p0.clone();
                    let k_pfx = (**k_pf).clone();
                    let v_pgx = (**v_pg).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), k_pfx.clone()), move |cpp_type_f_13543: crate::prelude::Text| crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), v_pgx.clone()), move |cpp_type_f_13560: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Map<{}, {}>", &cpp_type_f_13543, &cpp_type_f_13560)))))
                };
            }
            if let crate::lower::model::OutTy::OutFn(ps_ph, r_pi) = t_p1 {
                break 'm12316 {
                    let cp_p0x = cp_p0.clone();
                    let ps_phx = ps_ph.clone();
                    let r_pix = (**r_pi).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), r_pix.clone()), move |cpp_type_f_13615: crate::prelude::Text| crate::prelude::call_then(start_param_types_f(cp_p0x.clone(), ps_phx.clone()), move |param_types_f_13631: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Fn<{}({})>", &cpp_type_f_13615, &param_types_f_13631)))))
                };
            }
            if let crate::lower::model::OutTy::OutRef(m12316_27_0) = t_p1 && let crate::lower::model::OutTy::OutFn(ps_pj, r_pk) = &**m12316_27_0 {
                break 'm12316 {
                    let cp_p0x = cp_p0.clone();
                    let ps_pjx = ps_pj.clone();
                    let r_pkx = (**r_pk).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), r_pkx.clone()), move |cpp_type_f_13703: crate::prelude::Text| crate::prelude::call_then(start_param_types_f(cp_p0x.clone(), ps_pjx.clone()), move |param_types_f_13719: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("const ::std::function<{}({})>&", &cpp_type_f_13703, &param_types_f_13719)))))
                };
            }
            if let crate::lower::model::OutTy::OutRef(m12316_28_0) = t_p1 && let crate::lower::model::OutTy::OutSlice(i_pl) = &**m12316_28_0 {
                break 'm12316 {
                    let cp_p0x = cp_p0.clone();
                    let i_plx = (**i_pl).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_plx.clone()), move |cpp_type_f_13787: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::std::span<const {}>", &cpp_type_f_13787))))
                };
            }
            if let crate::lower::model::OutTy::OutRef(i_pm) = t_p1 {
                break 'm12316 {
                    let cp_p0x = cp_p0.clone();
                    let i_pmx = (**i_pm).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_pmx.clone()), move |cpp_type_f_13826: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("const {}&", &cpp_type_f_13826))))
                };
            }
            if let crate::lower::model::OutTy::OutRefMut(i_pn) = t_p1 {
                break 'm12316 {
                    let cp_p0x = cp_p0.clone();
                    let i_pnx = (**i_pn).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_pnx.clone()), move |cpp_type_f_13979: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}&", &cpp_type_f_13979))))
                };
            }
            if let crate::lower::model::OutTy::OutJobFn(a_po, b_pp) = t_p1 {
                break 'm12316 {
                    let a_pox = (**a_po).clone();
                    let b_ppx = (**b_pp).clone();
                    let cp_p0x = cp_p0.clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), b_ppx.clone()), move |cpp_type_f_14053: crate::prelude::Text| crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), a_pox.clone()), move |cpp_type_f_14070: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::prism_rtl::Fn<::prism_rtl::JobRef<{}>({})>", &cpp_type_f_14053, &cpp_type_f_14070)))))
                };
            }
            if let crate::lower::model::OutTy::OutJob(b_pq) = t_p1 {
                break 'm12316 {
                    let b_pqx = (**b_pq).clone();
                    let cp_p0x = cp_p0.clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), b_pqx.clone()), move |cpp_type_f_14124: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::prism_rtl::JobRef<{}>", &cpp_type_f_14124))))
                };
            }
            if let crate::lower::model::OutTy::OutEvent(i_pr) = t_p1 {
                break 'm12316 {
                    let cp_p0x = cp_p0.clone();
                    let i_prx = (**i_pr).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_prx.clone()), move |cpp_type_f_14181: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Event<{}>", &cpp_type_f_14181))))
                };
            }
            if let crate::lower::model::OutTy::OutDyn(i_ps) = t_p1 {
                break 'm12316 {
                    let cp_p0x = cp_p0.clone();
                    let i_psx = (**i_ps).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_psx.clone()), move |cpp_type_f_14238: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Dynamic<{}>", &cpp_type_f_14238))))
                };
            }
            if let crate::lower::model::OutTy::OutGen(n_pt) = t_p1 {
                break 'm12316 ::prism_rtl::Turn::Finished(n_pt.clone());
            }
            if let crate::lower::model::OutTy::OutRc(i_pu) = t_p1 {
                break 'm12316 if is_value_ty_f(cp_p0, &**i_pu) {
                    {
                        let cp_p0x = cp_p0.clone();
                        let i_pux = (**i_pu).clone();
                        crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_pux.clone()), move |cpp_type_f_14328: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::prism_rtl::Rc<const {}>", &cpp_type_f_14328))))
                    }
                } else {
                    {
                        let cp_p0x = cp_p0.clone();
                        let i_pux = (**i_pu).clone();
                        crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_pux.clone()), move |cpp_type_f_14369: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::prism_rtl::Rc<{}>", &cpp_type_f_14369))))
                    }
                };
            }
            if let crate::lower::model::OutTy::OutPod = t_p1 {
                break 'm12316 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Pod"));
            }
            if let crate::lower::model::OutTy::OutShowAny = t_p1 {
                break 'm12316 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("::prism_rtl::Rc<const crate::prelude::DynShow>"));
            }
            if let crate::lower::model::OutTy::OutHold(i_pv) = t_p1 {
                break 'm12316 {
                    let cp_p0x = cp_p0.clone();
                    let i_pvx = (**i_pv).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_pvx.clone()), move |cpp_type_f_14523: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Hold<{}>", &cpp_type_f_14523))))
                };
            }
            if let crate::lower::model::OutTy::OutStamped(i_p10) = t_p1 {
                break 'm12316 {
                    let cp_p0x = cp_p0.clone();
                    let i_p10x = (**i_p10).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_p10x.clone()), move |cpp_type_f_14584: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Stamped<{}>", &cpp_type_f_14584))))
                };
            }
            if let crate::lower::model::OutTy::OutSnapshot(i_p11) = t_p1 {
                break 'm12316 {
                    let cp_p0x = cp_p0.clone();
                    let i_p11x = (**i_p11).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_p11x.clone()), move |cpp_type_f_14647: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Snapshot<{}>", &cpp_type_f_14647))))
                };
            }
            if let crate::lower::model::OutTy::OutDefer(i_p12) = t_p1 {
                break 'm12316 {
                    let cp_p0x = cp_p0.clone();
                    let i_p12x = (**i_p12).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_p12x.clone()), move |cpp_type_f_14704: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Defer<{}>", &cpp_type_f_14704))))
                };
            }
            if let crate::lower::model::OutTy::OutWeak(n_p13) = t_p1 {
                break 'm12316 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::prism_rtl::Weak<{}>", &type_path_f(n_p13))));
            }
            if let crate::lower::model::OutTy::OutCell(i_p14) = t_p1 {
                break 'm12316 ::prism_rtl::Turn::More(::std::rc::Rc::new(CppType { cp_p0: cp_p0.clone(), t_p1: (**i_p14).clone() }));
            }
            if let crate::lower::model::OutTy::OutWakes = t_p1 {
                break 'm12316 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Wakes"));
            }
            if let crate::lower::model::OutTy::OutCount = t_p1 {
                break 'm12316 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("::std::uint32_t"));
            }
            if let crate::lower::model::OutTy::OutObj(i_p15) = t_p1 {
                break 'm12316 {
                    let cp_p0x = cp_p0.clone();
                    let i_p15x = (**i_p15).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_p15x.clone()), move |cpp_type_f_14901: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::prism_rtl::Rc<{}>", &cpp_type_f_14901))))
                };
            }
            if let crate::lower::model::OutTy::OutSlice(i_p16) = t_p1 {
                break 'm12316 {
                    let cp_p0x = cp_p0.clone();
                    let i_p16x = (**i_p16).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_p16x.clone()), move |cpp_type_f_14954: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::std::span<const {}>", &cpp_type_f_14954))))
                };
            }
            if let crate::lower::model::OutTy::OutPort(i_p17) = t_p1 {
                break 'm12316 {
                    let cp_p0x = cp_p0.clone();
                    let i_p17x = (**i_p17).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_p17x.clone()), move |cpp_type_f_15009: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Port<{}>", &cpp_type_f_15009))))
                };
            }
            if let crate::lower::model::OutTy::OutLive(i_p18) = t_p1 {
                break 'm12316 {
                    let cp_p0x = cp_p0.clone();
                    let i_p18x = (**i_p18).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_p18x.clone()), move |cpp_type_f_15067: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Element<{}>", &cpp_type_f_15067))))
                };
            }
            if let crate::lower::model::OutTy::OutTurn = t_p1 {
                break 'm12316 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("decltype(this->cycle())"));
            }
            if let crate::lower::model::OutTy::OutAssoc(tr_p19, n_p1a, a_p1b) = t_p1 {
                break 'm12316 {
                    let a_p1bx = (**a_p1b).clone();
                    let cp_p0x = cp_p0.clone();
                    let n_p1ax = n_p1a.clone();
                    let tr_p19x = tr_p19.clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), a_p1bx.clone()), move |cpp_type_f_15335: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("typename {}::{}<{}>::type", &type_path_f(&tr_p19x), &n_p1ax, &cpp_type_f_15335))))
                };
            }
            if let crate::lower::model::OutTy::OutRefused(what_p1c) = t_p1 {
                break 'm12316 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::expr::lowering_refusal_p(), what_p1c)));
            }
            if let crate::lower::model::OutTy::OutQuantified(b_p1d) = t_p1 {
                break 'm12316 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("compile_error!(\"{}a quantified type variable of `{}`: no instantiation gives it a type\")", &crate::lower::expr::lowering_refusal_p(), b_p1d)));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start CppType, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_type_f(cp_p0: Cp, t_p1: crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppType { cp_p0, t_p1 })
}

/// ```prism
/// CppTypes: unbounded fn Cp, [OutTy] -> Text
/// ```
pub fn cpp_types_f(cp_p0: &Cp, ts_p1: &crate::prelude::Array<crate::lower::model::OutTy>) -> crate::prelude::Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(ts_p1.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::OutTy| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let t_p2 = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(CppType { cp_p0: cp_p0xy.clone(), t_p1: t_p2.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    })), &crate::prelude::Text::lit(", "))
}

/// The step machine of `CppTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppTypes: unbounded fn Cp, [OutTy] -> Text
/// ```
pub struct CppTypes {
    pub cp_p0: Cp,
    pub ts_p1: crate::prelude::Array<crate::lower::model::OutTy>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppTypes {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let ts_p1 = &self.ts_p1;
        let cp_p0x = cp_p0.clone();
        let ts_p1x = ts_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(ts_p1x.clone(), {
            let cp_p0xx = cp_p0x.clone();
            ::std::rc::Rc::new(move |p0: crate::lower::model::OutTy| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let t_p2 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(CppType { cp_p0: cp_p0xxy.clone(), t_p1: t_p2.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
        }), move |each_15626: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join_f(&each_15626, &crate::prelude::Text::lit(", "))))
    }
}

/// `Start CppTypes, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_types_f(cp_p0: Cp, ts_p1: crate::prelude::Array<crate::lower::model::OutTy>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppTypes { cp_p0, ts_p1 })
}

/// ```prism
/// ParamTypes: unbounded fn Cp, [OutTy] -> Text
/// ```
pub fn param_types_f(cp_p0: &Cp, ts_p1: &crate::prelude::Array<crate::lower::model::OutTy>) -> crate::prelude::Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(ts_p1.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::OutTy| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let t_p2 = p0;
                crate::prelude::call_then(start_cpp_type_f(cp_p0xy.clone(), t_p2.clone()), move |cpp_type_f_15841: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("const {}&", &cpp_type_f_15841))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    })), &crate::prelude::Text::lit(", "))
}

/// The step machine of `ParamTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParamTypes: unbounded fn Cp, [OutTy] -> Text
/// ```
pub struct ParamTypes {
    pub cp_p0: Cp,
    pub ts_p1: crate::prelude::Array<crate::lower::model::OutTy>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for ParamTypes {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let ts_p1 = &self.ts_p1;
        let cp_p0x = cp_p0.clone();
        let ts_p1x = ts_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(ts_p1x.clone(), {
            let cp_p0xx = cp_p0x.clone();
            ::std::rc::Rc::new(move |p0: crate::lower::model::OutTy| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let t_p2 = p0;
                    crate::prelude::call_then(start_cpp_type_f(cp_p0xxy.clone(), t_p2.clone()), move |cpp_type_f_15841: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("const {}&", &cpp_type_f_15841))))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
        }), move |each_15819: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join_f(&each_15819, &crate::prelude::Text::lit(", "))))
    }
}

/// `Start ParamTypes, x`: what the function value is when passed to `@Run`.
pub fn start_param_types_f(cp_p0: Cp, ts_p1: crate::prelude::Array<crate::lower::model::OutTy>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(ParamTypes { cp_p0, ts_p1 })
}

/// ```prism
/// OwnTypePath: fn Cp, Ref -> Text
/// ```
pub fn own_type_path_f(cp_p0: &Cp, r_p1: &crate::lower::model::Ref) -> crate::prelude::Text {
    match case_of_o(cp_p0, r_p1) {
        ::std::option::Option::Some(ty_p2) => crate::prelude::Text::from(format!("{}::{}", &own_item_path_f(&ty_p2), &case_id_of_f(r_p1))),
        ::std::option::Option::None => own_item_path_f(r_p1),
    }
}

/// ```prism
/// OwnItemPath: fn Ref -> Text
/// ```
pub fn own_item_path_f(r_p0: &crate::lower::model::Ref) -> crate::prelude::Text {
    match r_p0 {
        crate::lower::model::Ref::RefItem(m16337_0_0, p_p1, _) if (m16337_0_0 == &crate::prelude::Text::lit("")) => crate::prelude::Text::from(format!("crate::{}", &type_path_f(p_p1))),
        crate::lower::model::Ref::RefItem(m_p2, p_p3, _) => crate::prelude::Text::from(format!("crate::{}::{}", m_p2, &type_path_f(p_p3))),
        crate::lower::model::Ref::RefRuntime(t_p4) => type_path_f(&crate::lower::model::runtime_path_f(t_p4)),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// TypePath: fn Text -> Text
/// ```
pub fn type_path_f(p_p0: &crate::prelude::Text) -> crate::prelude::Text {
    let no_fish_p1 = crate::syntax::lexer::chars::join_f(&crate::prelude::split_on(p_p0, &crate::prelude::Text::lit("::<")), &crate::prelude::Text::lit("<"));
    let no_holes_p2 = crate::syntax::lexer::chars::join_f(&crate::prelude::split_on(&no_fish_p1, &crate::prelude::Text::lit(", _>")), &crate::prelude::Text::lit(">"));
    crate::syntax::lexer::chars::join_f(&crate::prelude::split_on(&no_holes_p2, &crate::prelude::Text::lit("<_>")), &crate::prelude::Text::lit(""))
}

/// ```prism
/// IsValueTy: fn Cp, OutTy -> Bool
/// ```
pub fn is_value_ty_f(cp_p0: &Cp, t_p1: &crate::lower::model::OutTy) -> bool {
    match t_p1 {
        crate::lower::model::OutTy::OutNamed(n_p2, _) => match type_of_o(cp_p0, n_p2) {
            ::std::option::Option::Some(info_p3) => (&info_p3.kind_p != &crate::prelude::Text::lit("node")) && (&info_p3.kind_p != &crate::prelude::Text::lit("job")),
            ::std::option::Option::None => false,
        },
        crate::lower::model::OutTy::OutCell(_) => false,
        crate::lower::model::OutTy::OutPort(_) => false,
        crate::lower::model::OutTy::OutHold(_) => false,
        crate::lower::model::OutTy::OutStamped(_) => false,
        crate::lower::model::OutTy::OutSnapshot(_) => false,
        crate::lower::model::OutTy::OutDefer(_) => false,
        crate::lower::model::OutTy::OutObj(_) => false,
        crate::lower::model::OutTy::OutWakes => false,
        _ => true,
    }
}
