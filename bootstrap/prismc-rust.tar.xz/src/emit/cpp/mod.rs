//! The module `Emit.Cpp`, from `target/bootstrap/src/prismc/emit/cpp/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod expr;
pub mod items;
pub mod patterns;
pub mod prelude;
pub mod program;
pub mod stmts;
pub mod templates;

/// `Cp`:
///
/// ```prism
/// type Cp = record:
/// ```
#[derive(Clone)]
pub struct Cp {
    pub home: Text,
    pub mods: Array<Text>,
    pub types: Map<Text, TyInfo>,
    pub ctors: Map<Text, Text>,
    pub members: Map<Text, bool>,
    pub methods: Map<Text, bool>,
    pub field_names: Map<Text, bool>,
    pub fns: Map<Text, bool>,
    pub fields: Map<Text, crate::lower::model::OutTy>,
    pub renames: Map<Text, Text>,
    pub pointers: Map<Text, bool>,
    pub owned: Map<Text, bool>,
    pub move_captures: Array<Text>,
    pub local_types: Map<Text, crate::lower::model::OutTy>,
}

impl ToPod for Cp {
    fn to_pod(&self) -> Pod {
        Pod::record("Cp", vec![("home", self.home.to_pod()), ("mods", self.mods.to_pod()), ("types", self.types.to_pod()), ("ctors", self.ctors.to_pod()), ("members", self.members.to_pod()), ("methods", self.methods.to_pod()), ("field_names", self.field_names.to_pod()), ("fns", self.fns.to_pod()), ("fields", self.fields.to_pod()), ("renames", self.renames.to_pod()), ("pointers", self.pointers.to_pod()), ("owned", self.owned.to_pod()), ("move_captures", self.move_captures.to_pod()), ("local_types", self.local_types.to_pod())])
    }
}

impl FromPod for Cp {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Cp { home: FromPod::from_pod(field(p, "home")?)?, mods: FromPod::from_pod(field(p, "mods")?)?, types: FromPod::from_pod(field(p, "types")?)?, ctors: FromPod::from_pod(field(p, "ctors")?)?, members: FromPod::from_pod(field(p, "members")?)?, methods: FromPod::from_pod(field(p, "methods")?)?, field_names: FromPod::from_pod(field(p, "field_names")?)?, fns: FromPod::from_pod(field(p, "fns")?)?, fields: FromPod::from_pod(field(p, "fields")?)?, renames: FromPod::from_pod(field(p, "renames")?)?, pointers: FromPod::from_pod(field(p, "pointers")?)?, owned: FromPod::from_pod(field(p, "owned")?)?, move_captures: FromPod::from_pod(field(p, "move_captures")?)?, local_types: FromPod::from_pod(field(p, "local_types")?)? })
    }
}

/// `TyInfo`:
///
/// ```prism
/// type TyInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TyInfo {
    pub kind: Text,
    pub fields: Array<Text>,
    pub params: Array<Text>,
}

impl Show for TyInfo {
    fn show(&self, p: &mut Printer) {
        p.record("TyInfo", &[("kind", &self.kind), ("fields", &self.fields), ("params", &self.params)]);
    }
}

impl ToPod for TyInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("TyInfo", vec![("kind", self.kind.to_pod()), ("fields", self.fields.to_pod()), ("params", self.params.to_pod())])
    }
}

impl FromPod for TyInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TyInfo { kind: FromPod::from_pod(field(p, "kind")?)?, fields: FromPod::from_pod(field(p, "fields")?)?, params: FromPod::from_pod(field(p, "params")?)? })
    }
}

/// ```prism
/// CppId: fn Text -> Text
/// ```
pub fn cpp_id(n: &Text) -> Text {
    if in_list(&crate::lower::cpp_keywords(), n) {
        Text::from(format!("{}_", n))
    } else {
        n.clone()
    }
}

/// ```prism
/// FieldId: fn Text -> Text
/// ```
pub fn field_id(f: &Text) -> Text {
    if in_list(&Array::from(vec![Text::lit("show"), Text::lit("to_pod"), Text::lit("from_pod"), Text::lit("cases")]), f) {
        Text::from(format!("{}_", f))
    } else {
        cpp_id(f)
    }
}

/// ```prism
/// CppPathId: fn Text -> Text
/// ```
pub fn cpp_path_id(p_: &Text) -> Text {
    crate::syntax::lexer::chars::join(&each(&split_on(p_, &Text::lit("::")), &(|s: &Text| cpp_id(s))), &Text::lit("::"))
}

/// ```prism
/// InList: fn [Text], Text -> Bool
/// ```
pub fn in_list(xs: &Array<Text>, x: &Text) -> bool {
    fold(xs, &false, &(|seen: &bool, y: &Text| *seen || (y == x)))
}

/// ```prism
/// Absolute: fn Cp, Text -> Text
/// ```
pub fn absolute(cp: &Cp, p_: &Text) -> Text {
    let q = crate::syntax::lexer::chars::drop_prefix(p_, &Text::lit("crate::"));
    if fold(&cp.mods, &false, &(|f: &bool, m: &Text| *f || crate::syntax::lexer::chars::has_prefix(&q, &Text::from(format!("{}::", m))))) {
        q.clone()
    } else {
        Text::from(format!("{}::{}", &cp.home, &q))
    }
}

/// ```prism
/// ?TypeOf: fn Cp, Text -> ?TyInfo
/// ```
pub fn type_of(cp: &Cp, p_: &Text) -> Option<TyInfo> {
    let q = crate::syntax::lexer::chars::drop_prefix(p_, &Text::lit("crate::"));
    match get(&cp.types, &absolute(cp, &q)) {
        Some(t) => Some(t),
        None => match get(&cp.types, &Text::from(format!("prelude::{}", &q))) {
            Some(t) => Some(t),
            None => get(&cp.types, &q),
        },
    }
}

/// ```prism
/// ?CaseOf: fn Cp, Text -> ?Text
/// ```
pub fn case_of(cp: &Cp, p_: &Text) -> Option<Text> {
    let q = crate::syntax::lexer::chars::drop_prefix(p_, &Text::lit("crate::"));
    match get(&cp.ctors, &absolute(cp, &q)) {
        Some(_) => Some(parent_path(p_)),
        None => match get(&cp.ctors, &Text::from(format!("prelude::{}", &q))) {
            Some(_) => Some(parent_path(p_)),
            None => match get(&cp.ctors, &q) {
                Some(_) => Some(parent_path(p_)),
                None => None,
            },
        },
    }
}

/// ```prism
/// ParentPath: fn Text -> Text
/// ```
pub fn parent_path(p_: &Text) -> Text {
    let segs = split_on(p_, &Text::lit("::"));
    crate::syntax::lexer::chars::join(&take(&segs, &crate::syntax::lexer::chars::dec(&len(&segs))), &Text::lit("::"))
}

/// ```prism
/// LastSegment: fn Text -> Text
/// ```
pub fn last_segment(p_: &Text) -> Text {
    or(&crate::syntax::lexer::chars::last(&split_on(p_, &Text::lit("::"))), p_)
}

/// ```prism
/// Context: fn Model -> Cp
/// ```
pub fn context(model: &crate::lower::model::Model) -> Cp {
    let names = each(&model.mods, &(|m: &crate::lower::model::ModDef| m.name.clone()));
    let tops = fold(&names, &Array::new(), &(|acc: &Array<Text>, n: &Text| {
        let top = or(&index(&split_on(n, &Text::lit("::")), &Nat::from(0u32)), n);
        if in_list(&names, &top) || in_list(acc, &top) { acc.clone() } else { push(acc, &top) }
    }));
    let mods = push(&append(&names, &tops), &Text::lit("prelude"));
    let base = Cp { home: Text::lit(""), mods: mods.clone(), types: prelude_types(), ctors: prelude_ctors(), members: node_base(), methods: Map::new(), field_names: Map::new(), fns: Map::new(), fields: Map::new(), renames: Map::new(), pointers: Map::new(), owned: Map::new(), move_captures: Array::new(), local_types: Map::new() };
    let with_elem = add_row(&add_answer(&base, &model.answer), &Text::lit(""), &model.elem);
    fold(&model.mods, &with_elem, &(|cp: &Cp, m: &crate::lower::model::ModDef| fold(&m.items, cp, &(|c: &Cp, it: &crate::lower::model::Item| add_model_item(c, &m.name, it)))))
}

/// ```prism
/// let preludeTypes
/// ```
pub fn prelude_types() -> Map<Text, TyInfo> {
    map_of(vec![(Text::lit("prelude::Ordering"), TyInfo { kind: Text::lit("choice"), fields: Array::new(), params: Array::new() }), (Text::lit("prelude::Span"), TyInfo { kind: Text::lit("record"), fields: Array::from(vec![Text::lit("file"), Text::lit("line"), Text::lit("column"), Text::lit("binding")]), params: Array::new() }), (Text::lit("prelude::Exception"), TyInfo { kind: Text::lit("record"), fields: Array::from(vec![Text::lit("kind"), Text::lit("message"), Text::lit("spans"), Text::lit("path_")]), params: Array::new() }), (Text::lit("prelude::Duration"), TyInfo { kind: Text::lit("newtype"), fields: Array::new(), params: Array::new() }), (Text::lit("prelude::PreludeUnwrap"), TyInfo { kind: Text::lit("tag"), fields: Array::new(), params: Array::new() }), (Text::lit("prelude::PreludeExceptions"), TyInfo { kind: Text::lit("tag"), fields: Array::new(), params: Array::new() })])
}

/// ```prism
/// let preludeCtors
/// ```
pub fn prelude_ctors() -> Map<Text, Text> {
    map_of(vec![(Text::lit("prelude::Ordering::Less"), Text::lit("choice")), (Text::lit("prelude::Ordering::Equal"), Text::lit("choice")), (Text::lit("prelude::Ordering::Greater"), Text::lit("choice"))])
}

/// ```prism
/// let nodeBase
/// ```
pub fn node_base() -> Map<Text, bool> {
    map_of(vec![(Text::lit("make"), true), (Text::lit("push"), true), (Text::lit("wake"), true), (Text::lit("started"), true), (Text::lit("deferred"), true), (Text::lit("build"), true), (Text::lit("swap"), true), (Text::lit("leave"), true), (Text::lit("patch"), true), (Text::lit("edges"), true), (Text::lit("release"), true), (Text::lit("clean_up"), true), (Text::lit("path"), true), (Text::lit("leave_row"), true), (Text::lit("answer"), true), (Text::lit("document"), true), (Text::lit("entries"), true), (Text::lit("deliver"), true), (Text::lit("document_moved"), true), (Text::lit("me"), true), (Text::lit("result_dynamic"), true)])
}

/// ```prism
/// AddModelItem: fn Cp, Text, Item -> Cp
/// ```
pub fn add_model_item(cp: &Cp, m: &Text, it: &crate::lower::model::Item) -> Cp {
    match it {
        crate::lower::model::Item::ItType(t) => add_type(cp, m, t),
        crate::lower::model::Item::ItTag(t) => add_ty(cp, &Text::from(format!("{}::{}", m, &t.name)), &TyInfo { kind: Text::lit("tag"), fields: each(&t.fields, &(|(_, f, _): &(Text, Text, crate::lower::model::OutTy)| f.clone())), params: Array::new() }),
        crate::lower::model::Item::ItRow(r) => add_row(cp, m, r),
        crate::lower::model::Item::ItJob(j) => add_ty(cp, &Text::from(format!("{}::{}", m, &j.name)), &TyInfo { kind: Text::lit("job"), fields: each(&j.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| f.clone())), params: each(&j.generics, &(|(g, _): &(Text, Array<Text>)| g.clone())) }),
        crate::lower::model::Item::ItNode(n) => add_node(cp, m, n),
        crate::lower::model::Item::ItFn(f) => {
            let mut this: Cp = cp.clone();
            this.fns = insert(&this.fns, &Text::from(format!("{}::{}", m, &f.name)), &true);
            this
        },
        _ => cp.clone(),
    }
}

/// ```prism
/// AddTy: fn Cp, Text, TyInfo -> Cp
/// ```
pub fn add_ty(cp: &Cp, path_: &Text, info: &TyInfo) -> Cp {
    let mut this: Cp = cp.clone();
    this.types = insert(&this.types, path_, info);
    this
}

/// ```prism
/// AddCtor: fn Cp, Text, Text -> Cp
/// ```
pub fn add_ctor(cp: &Cp, path_: &Text, kind: &Text) -> Cp {
    let mut this: Cp = cp.clone();
    this.ctors = insert(&this.ctors, path_, kind);
    this
}

/// ```prism
/// AddMember: fn Cp, Text -> Cp
/// ```
pub fn add_member(cp: &Cp, name: &Text) -> Cp {
    let mut this: Cp = cp.clone();
    this.members = insert(&this.members, name, &true);
    this
}

/// ```prism
/// AddType: fn Cp, Text, TyDef -> Cp
/// ```
pub fn add_type(cp: &Cp, m: &Text, t: &crate::lower::model::TyDef) -> Cp {
    let path_ = Text::from(format!("{}::{}", m, &t.name));
    let first_ = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
    match &t.shape {
        crate::lower::model::TyShape::ShapeRecord => add_ty(cp, &path_, &TyInfo { kind: Text::lit("record"), fields: each(&first_.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| f.clone())), params: t.params.clone() }),
        crate::lower::model::TyShape::ShapeNewtype => add_ty(cp, &path_, &TyInfo { kind: Text::lit("newtype"), fields: Array::new(), params: t.params.clone() }),
        crate::lower::model::TyShape::ShapeUnit => add_ty(cp, &path_, &TyInfo { kind: Text::lit("unit"), fields: Array::new(), params: t.params.clone() }),
        crate::lower::model::TyShape::ShapeChoice => fold(&t.cases, &add_ty(cp, &path_, &TyInfo { kind: Text::lit("choice"), fields: Array::new(), params: t.params.clone() }), &(|c: &Cp, k: &crate::lower::model::CaseDef| add_ctor(c, &Text::from(format!("{}::{}", &path_, &k.name)), &Text::lit("choice")))),
    }
}

/// ```prism
/// AddRow: fn Cp, Text, RowDef -> Cp
/// ```
pub fn add_row(cp: &Cp, m: &Text, r: &crate::lower::model::RowDef) -> Cp {
    let path_ = if m == &Text::lit("") {
        r.name.clone()
    } else {
        Text::from(format!("{}::{}", m, &r.name))
    };
    fold(&r.cases, &add_ty(cp, &path_, &TyInfo { kind: Text::lit("choice"), fields: Array::new(), params: Array::new() }), &(|c: &Cp, (v_, _): &(Text, Text)| add_ctor(c, &Text::from(format!("{}::{}", &path_, v_)), &Text::lit("choice"))))
}

/// ```prism
/// AddAnswer: fn Cp, AnswerDef -> Cp
/// ```
pub fn add_answer(cp: &Cp, a: &crate::lower::model::AnswerDef) -> Cp {
    fold(&a.cases, &add_ty(cp, &Text::lit("Answer"), &TyInfo { kind: Text::lit("choice"), fields: Array::new(), params: Array::new() }), &(|c: &Cp, k: &crate::lower::model::AnswerCase| add_ctor(c, &Text::from(format!("Answer::{}", &k.variant)), &Text::lit("choice"))))
}

/// ```prism
/// AddNode: fn Cp, Text, NodeDef -> Cp
/// ```
pub fn add_node(cp: &Cp, m: &Text, n: &crate::lower::model::NodeDef) -> Cp {
    let with_fields_ = fold(&n.fields, cp, &(|c: &Cp, (f, _, _): &(Text, crate::lower::model::OutTy, Text)| {
        let mut this: Cp = add_member(c, f);
        this.field_names = insert(&this.field_names, f, &true);
        this
    }));
    let with_methods = fold(&append(&n.methods, &n.hosted), &with_fields_, &(|c: &Cp, md: &crate::lower::model::MethDef| {
        let mut this: Cp = add_member(c, &md.name);
        this.methods = insert(&this.methods, &md.name, &true);
        this
    }));
    let with_builders = fold(&n.builders, &with_methods, &(|c: &Cp, b: &crate::lower::model::ForDef| add_member(c, &Text::from(format!("{}_build", &b.name)))));
    let with_gens = fold(&n.gens, &with_builders, &(|c: &Cp, g: &crate::lower::model::GenDef| add_member(c, &Text::from(format!("{}_build", &g.name)))));
    add_ty(&with_gens, &Text::from(format!("{}::{}", m, &n.name)), &TyInfo { kind: Text::lit("node"), fields: each(&n.fields, &(|(f, _, _): &(Text, crate::lower::model::OutTy, Text)| f.clone())), params: Array::new() })
}

/// ```prism
/// InHome: fn Cp, Text -> Cp
/// ```
pub fn in_home(cp: &Cp, m: &Text) -> Cp {
    let mut this: Cp = cp.clone();
    this.home = m.clone();
    this
}

/// ```prism
/// WithFields: fn Cp, [((Text, OutTy))] -> Cp
/// ```
pub fn with_fields(cp: &Cp, fs: &Array<(Text, crate::lower::model::OutTy)>) -> Cp {
    let mut this: Cp = cp.clone();
    this.fields = fold(fs, &Map::new(), &(|acc: &Map<Text, crate::lower::model::OutTy>, (f, t): &(Text, crate::lower::model::OutTy)| insert(acc, f, t)));
    this
}

/// ```prism
/// CppType: unbounded fn Cp, OutTy -> Text
/// ```
pub fn cpp_type(cp: &Cp, t: &crate::lower::model::OutTy) -> Text {
    'm11561: {
        if let crate::lower::model::OutTy::OutNat = t {
            break 'm11561 Text::lit("Nat");
        }
        if let crate::lower::model::OutTy::OutInt = t {
            break 'm11561 Text::lit("Int");
        }
        if let crate::lower::model::OutTy::OutU8 = t {
            break 'm11561 Text::lit("std::uint8_t");
        }
        if let crate::lower::model::OutTy::OutFloat = t {
            break 'm11561 Text::lit("double");
        }
        if let crate::lower::model::OutTy::OutBool = t {
            break 'm11561 Text::lit("bool");
        }
        if let crate::lower::model::OutTy::OutChar = t {
            break 'm11561 Text::lit("char32_t");
        }
        if let crate::lower::model::OutTy::OutText = t {
            break 'm11561 Text::lit("Text");
        }
        if let crate::lower::model::OutTy::OutCursor = t {
            break 'm11561 Text::lit("Cursor");
        }
        if let crate::lower::model::OutTy::OutRegex = t {
            break 'm11561 Text::lit("Regex");
        }
        if let crate::lower::model::OutTy::OutReplacement = t {
            break 'm11561 Text::lit("RegexReplacement");
        }
        if let crate::lower::model::OutTy::OutUnit = t {
            break 'm11561 Text::lit("Unit");
        }
        if let crate::lower::model::OutTy::OutPath = t {
            break 'm11561 Text::lit("Path");
        }
        if let crate::lower::model::OutTy::OutDuration = t {
            break 'm11561 Text::lit("Duration");
        }
        if let crate::lower::model::OutTy::OutError = t {
            break 'm11561 Text::lit("Error");
        }
        if let crate::lower::model::OutTy::OutNamed(m11561_14_0, m11561_14_1) = t && (m11561_14_0 == &Text::lit("Cell")) && (m11561_14_1.len() == 1) && let Some(i) = index(m11561_14_1, &Nat::from(0u32)) {
            break 'm11561 cpp_type(cp, &i);
        }
        if let crate::lower::model::OutTy::OutNamed(m11561_15_0, m11561_15_1) = t && (m11561_15_0 == &Text::lit("RefCell")) && (m11561_15_1.len() == 1) && let Some(i) = index(m11561_15_1, &Nat::from(0u32)) {
            break 'm11561 cpp_type(cp, &i);
        }
        if let crate::lower::model::OutTy::OutNamed(m11561_16_0, m11561_16_1) = t && (m11561_16_0 == &Text::lit("Vec")) && (m11561_16_1.len() == 1) && let Some(i) = index(m11561_16_1, &Nat::from(0u32)) {
            break 'm11561 Text::from(format!("std::vector<{}>", &cpp_type(cp, &i)));
        }
        if let crate::lower::model::OutTy::OutNamed(m11561_17_0, m11561_17_1) = t && (m11561_17_0 == &Text::lit("Result")) && (m11561_17_1.len() == 2) && let Some(a) = index(m11561_17_1, &Nat::from(0u32)) && let Some(b) = index(m11561_17_1, &Nat::from(1u32)) {
            break 'm11561 Text::from(format!("Expected<{}, {}>", &cpp_type(cp, &a), &cpp_type(cp, &b)));
        }
        if let crate::lower::model::OutTy::OutNamed(n, m11561_18_1) = t && (m11561_18_1.len() == 0) {
            break 'm11561 own_type_path(cp, n);
        }
        if let crate::lower::model::OutTy::OutNamed(n, args) = t {
            break 'm11561 Text::from(format!("{}<{}>", &own_type_path(cp, n), &cpp_types(cp, args)));
        }
        if let crate::lower::model::OutTy::OutOpt(i) = t {
            break 'm11561 Text::from(format!("std::optional<{}>", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutRes(i) = t {
            break 'm11561 Text::from(format!("Fallible<{}>", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutTuple(ts) = t {
            break 'm11561 Text::from(format!("std::tuple<{}>", &cpp_types(cp, ts)));
        }
        if let crate::lower::model::OutTy::OutArray(e) = t {
            break 'm11561 Text::from(format!("Array<{}>", &cpp_type(cp, &**e)));
        }
        if let crate::lower::model::OutTy::OutMap(k, v_) = t {
            break 'm11561 Text::from(format!("Map<{}, {}>", &cpp_type(cp, &**k), &cpp_type(cp, &**v_)));
        }
        if let crate::lower::model::OutTy::OutFn(ps, r) = t {
            break 'm11561 Text::from(format!("Fn<{}({})>", &cpp_type(cp, &**r), &param_types(cp, ps)));
        }
        if let crate::lower::model::OutTy::OutRef(m11561_26_0) = t && let crate::lower::model::OutTy::OutFn(ps, r) = &**m11561_26_0 {
            break 'm11561 Text::from(format!("const std::function<{}({})>&", &cpp_type(cp, &**r), &param_types(cp, ps)));
        }
        if let crate::lower::model::OutTy::OutRef(m11561_27_0) = t && let crate::lower::model::OutTy::OutSlice(i) = &**m11561_27_0 {
            break 'm11561 Text::from(format!("std::span<const {}>", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutRef(i) = t {
            break 'm11561 Text::from(format!("const {}&", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutJobFn(a, b) = t {
            break 'm11561 Text::from(format!("prism_rtl::Fn<prism_rtl::JobRef<{}>({})>", &cpp_type(cp, &**b), &cpp_type(cp, &**a)));
        }
        if let crate::lower::model::OutTy::OutJob(b) = t {
            break 'm11561 Text::from(format!("prism_rtl::JobRef<{}>", &cpp_type(cp, &**b)));
        }
        if let crate::lower::model::OutTy::OutEvent(i) = t {
            break 'm11561 Text::from(format!("Event<{}>", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutDyn(i) = t {
            break 'm11561 Text::from(format!("Dynamic<{}>", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutGen(n) = t {
            break 'm11561 n.clone();
        }
        if let crate::lower::model::OutTy::OutRc(i) = t {
            break 'm11561 if is_value_ty(cp, &**i) {
                Text::from(format!("prism_rtl::Rc<const {}>", &cpp_type(cp, &**i)))
            } else {
                Text::from(format!("prism_rtl::Rc<{}>", &cpp_type(cp, &**i)))
            };
        }
        if let crate::lower::model::OutTy::OutPod = t {
            break 'm11561 Text::lit("Pod");
        }
        if let crate::lower::model::OutTy::OutShowAny = t {
            break 'm11561 Text::lit("prism_rtl::Rc<const DynShow>");
        }
        if let crate::lower::model::OutTy::OutHold(i) = t {
            break 'm11561 Text::from(format!("Hold<{}>", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutStamped(i) = t {
            break 'm11561 Text::from(format!("Stamped<{}>", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutSnapshot(i) = t {
            break 'm11561 Text::from(format!("Snapshot<{}>", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutDefer(i) = t {
            break 'm11561 Text::from(format!("Defer<{}>", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutWeak(n) = t {
            break 'm11561 Text::from(format!("prism_rtl::Weak<{}>", &type_path(n)));
        }
        if let crate::lower::model::OutTy::OutCell(i) = t {
            break 'm11561 cpp_type(cp, &**i);
        }
        if let crate::lower::model::OutTy::OutWakes = t {
            break 'm11561 Text::lit("Wakes");
        }
        if let crate::lower::model::OutTy::OutCount = t {
            break 'm11561 Text::lit("std::uint32_t");
        }
        if let crate::lower::model::OutTy::OutObj(i) = t {
            break 'm11561 Text::from(format!("prism_rtl::Rc<{}>", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutSlice(i) = t {
            break 'm11561 Text::from(format!("std::span<const {}>", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutPort(i) = t {
            break 'm11561 Text::from(format!("Port<{}>", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutLive(i) = t {
            break 'm11561 Text::from(format!("Live<{}>", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutUnknown(m11561_49_0) = t && (m11561_49_0 == &Text::lit("the job\'s turn")) {
            break 'm11561 Text::lit("decltype(this->cycle())");
        }
        if let crate::lower::model::OutTy::OutUnknown(what) = t {
            break 'm11561 Text::from(format!("Unit /* {} */", what));
        }
        if let crate::lower::model::OutTy::OutQuantified(b) = t {
            break 'm11561 Text::from(format!("compile_error!(\"{}a quantified type variable of `{}`: no instantiation gives it a type\")", &crate::lower::expr::lowering_refusal(), b));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `CppType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppType: unbounded fn Cp, OutTy -> Text
/// ```
pub struct CppType {
    pub cp: Cp,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for CppType {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let t = &self.t;
        'm11561: {
            if let crate::lower::model::OutTy::OutNat = t {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("Nat"));
            }
            if let crate::lower::model::OutTy::OutInt = t {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("Int"));
            }
            if let crate::lower::model::OutTy::OutU8 = t {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("std::uint8_t"));
            }
            if let crate::lower::model::OutTy::OutFloat = t {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("double"));
            }
            if let crate::lower::model::OutTy::OutBool = t {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("bool"));
            }
            if let crate::lower::model::OutTy::OutChar = t {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("char32_t"));
            }
            if let crate::lower::model::OutTy::OutText = t {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("Text"));
            }
            if let crate::lower::model::OutTy::OutCursor = t {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("Cursor"));
            }
            if let crate::lower::model::OutTy::OutRegex = t {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("Regex"));
            }
            if let crate::lower::model::OutTy::OutReplacement = t {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("RegexReplacement"));
            }
            if let crate::lower::model::OutTy::OutUnit = t {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("Unit"));
            }
            if let crate::lower::model::OutTy::OutPath = t {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("Path"));
            }
            if let crate::lower::model::OutTy::OutDuration = t {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("Duration"));
            }
            if let crate::lower::model::OutTy::OutError = t {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("Error"));
            }
            if let crate::lower::model::OutTy::OutNamed(m11561_14_0, m11561_14_1) = t && (m11561_14_0 == &Text::lit("Cell")) && (m11561_14_1.len() == 1) && let Some(i) = index(m11561_14_1, &Nat::from(0u32)) {
                break 'm11561 prism_rtl::Turn::More(Rc::new(CppType { cp: cp.clone(), t: i.clone() }));
            }
            if let crate::lower::model::OutTy::OutNamed(m11561_15_0, m11561_15_1) = t && (m11561_15_0 == &Text::lit("RefCell")) && (m11561_15_1.len() == 1) && let Some(i) = index(m11561_15_1, &Nat::from(0u32)) {
                break 'm11561 prism_rtl::Turn::More(Rc::new(CppType { cp: cp.clone(), t: i.clone() }));
            }
            if let crate::lower::model::OutTy::OutNamed(m11561_16_0, m11561_16_1) = t && (m11561_16_0 == &Text::lit("Vec")) && (m11561_16_1.len() == 1) && let Some(i) = index(m11561_16_1, &Nat::from(0u32)) {
                break 'm11561 {
                    let cp = cp.clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_12022: Text| prism_rtl::Turn::Finished(Text::from(format!("std::vector<{}>", &cpp_type_12022))))
                };
            }
            if let crate::lower::model::OutTy::OutNamed(m11561_17_0, m11561_17_1) = t && (m11561_17_0 == &Text::lit("Result")) && (m11561_17_1.len() == 2) && let Some(a) = index(m11561_17_1, &Nat::from(0u32)) && let Some(b) = index(m11561_17_1, &Nat::from(1u32)) {
                break 'm11561 {
                    let cp = cp.clone();
                    call_then(start_cpp_type(cp.clone(), a.clone()), move |cpp_type_12083: Text| call_then(start_cpp_type(cp.clone(), b.clone()), move |cpp_type_12100: Text| prism_rtl::Turn::Finished(Text::from(format!("Expected<{}, {}>", &cpp_type_12083, &cpp_type_12100)))))
                };
            }
            if let crate::lower::model::OutTy::OutNamed(n, m11561_18_1) = t && (m11561_18_1.len() == 0) {
                break 'm11561 prism_rtl::Turn::Finished(own_type_path(cp, n));
            }
            if let crate::lower::model::OutTy::OutNamed(n, args) = t {
                break 'm11561 {
                    let args = args.clone();
                    let cp = cp.clone();
                    let n = n.clone();
                    call_then(start_cpp_types(cp.clone(), args.clone()), move |cpp_types_12201: Text| prism_rtl::Turn::Finished(Text::from(format!("{}<{}>", &own_type_path(&cp, &n), &cpp_types_12201))))
                };
            }
            if let crate::lower::model::OutTy::OutOpt(i) = t {
                break 'm11561 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_12252: Text| prism_rtl::Turn::Finished(Text::from(format!("std::optional<{}>", &cpp_type_12252))))
                };
            }
            if let crate::lower::model::OutTy::OutRes(i) = t {
                break 'm11561 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_12294: Text| prism_rtl::Turn::Finished(Text::from(format!("Fallible<{}>", &cpp_type_12294))))
                };
            }
            if let crate::lower::model::OutTy::OutTuple(ts) = t {
                break 'm11561 {
                    let cp = cp.clone();
                    let ts = ts.clone();
                    call_then(start_cpp_types(cp.clone(), ts.clone()), move |cpp_types_12341: Text| prism_rtl::Turn::Finished(Text::from(format!("std::tuple<{}>", &cpp_types_12341))))
                };
            }
            if let crate::lower::model::OutTy::OutArray(e) = t {
                break 'm11561 {
                    let cp = cp.clone();
                    let e = (**e).clone();
                    call_then(start_cpp_type(cp.clone(), e.clone()), move |cpp_type_12384: Text| prism_rtl::Turn::Finished(Text::from(format!("Array<{}>", &cpp_type_12384))))
                };
            }
            if let crate::lower::model::OutTy::OutMap(k, v_) = t {
                break 'm11561 {
                    let cp = cp.clone();
                    let k = (**k).clone();
                    let v_ = (**v_).clone();
                    call_then(start_cpp_type(cp.clone(), k.clone()), move |cpp_type_12424: Text| call_then(start_cpp_type(cp.clone(), v_.clone()), move |cpp_type_12441: Text| prism_rtl::Turn::Finished(Text::from(format!("Map<{}, {}>", &cpp_type_12424, &cpp_type_12441)))))
                };
            }
            if let crate::lower::model::OutTy::OutFn(ps, r) = t {
                break 'm11561 {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let r = (**r).clone();
                    call_then(start_cpp_type(cp.clone(), r.clone()), move |cpp_type_12480: Text| call_then(start_param_types(cp.clone(), ps.clone()), move |param_types_12496: Text| prism_rtl::Turn::Finished(Text::from(format!("Fn<{}({})>", &cpp_type_12480, &param_types_12496)))))
                };
            }
            if let crate::lower::model::OutTy::OutRef(m11561_26_0) = t && let crate::lower::model::OutTy::OutFn(ps, r) = &**m11561_26_0 {
                break 'm11561 {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let r = (**r).clone();
                    call_then(start_cpp_type(cp.clone(), r.clone()), move |cpp_type_12566: Text| call_then(start_param_types(cp.clone(), ps.clone()), move |param_types_12582: Text| prism_rtl::Turn::Finished(Text::from(format!("const std::function<{}({})>&", &cpp_type_12566, &param_types_12582)))))
                };
            }
            if let crate::lower::model::OutTy::OutRef(m11561_27_0) = t && let crate::lower::model::OutTy::OutSlice(i) = &**m11561_27_0 {
                break 'm11561 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_12648: Text| prism_rtl::Turn::Finished(Text::from(format!("std::span<const {}>", &cpp_type_12648))))
                };
            }
            if let crate::lower::model::OutTy::OutRef(i) = t {
                break 'm11561 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_12687: Text| prism_rtl::Turn::Finished(Text::from(format!("const {}&", &cpp_type_12687))))
                };
            }
            if let crate::lower::model::OutTy::OutJobFn(a, b) = t {
                break 'm11561 {
                    let a = (**a).clone();
                    let b = (**b).clone();
                    let cp = cp.clone();
                    call_then(start_cpp_type(cp.clone(), b.clone()), move |cpp_type_12757: Text| call_then(start_cpp_type(cp.clone(), a.clone()), move |cpp_type_12774: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::Fn<prism_rtl::JobRef<{}>({})>", &cpp_type_12757, &cpp_type_12774)))))
                };
            }
            if let crate::lower::model::OutTy::OutJob(b) = t {
                break 'm11561 {
                    let b = (**b).clone();
                    let cp = cp.clone();
                    call_then(start_cpp_type(cp.clone(), b.clone()), move |cpp_type_12826: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::JobRef<{}>", &cpp_type_12826))))
                };
            }
            if let crate::lower::model::OutTy::OutEvent(i) = t {
                break 'm11561 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_12867: Text| prism_rtl::Turn::Finished(Text::from(format!("Event<{}>", &cpp_type_12867))))
                };
            }
            if let crate::lower::model::OutTy::OutDyn(i) = t {
                break 'm11561 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_12908: Text| prism_rtl::Turn::Finished(Text::from(format!("Dynamic<{}>", &cpp_type_12908))))
                };
            }
            if let crate::lower::model::OutTy::OutGen(n) = t {
                break 'm11561 prism_rtl::Turn::Finished(n.clone());
            }
            if let crate::lower::model::OutTy::OutRc(i) = t {
                break 'm11561 if is_value_ty(cp, &**i) {
                    {
                        let cp = cp.clone();
                        let i = (**i).clone();
                        call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_12996: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::Rc<const {}>", &cpp_type_12996))))
                    }
                } else {
                    {
                        let cp = cp.clone();
                        let i = (**i).clone();
                        call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_13035: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::Rc<{}>", &cpp_type_13035))))
                    }
                };
            }
            if let crate::lower::model::OutTy::OutPod = t {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("Pod"));
            }
            if let crate::lower::model::OutTy::OutShowAny = t {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("prism_rtl::Rc<const DynShow>"));
            }
            if let crate::lower::model::OutTy::OutHold(i) = t {
                break 'm11561 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_13139: Text| prism_rtl::Turn::Finished(Text::from(format!("Hold<{}>", &cpp_type_13139))))
                };
            }
            if let crate::lower::model::OutTy::OutStamped(i) = t {
                break 'm11561 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_13184: Text| prism_rtl::Turn::Finished(Text::from(format!("Stamped<{}>", &cpp_type_13184))))
                };
            }
            if let crate::lower::model::OutTy::OutSnapshot(i) = t {
                break 'm11561 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_13231: Text| prism_rtl::Turn::Finished(Text::from(format!("Snapshot<{}>", &cpp_type_13231))))
                };
            }
            if let crate::lower::model::OutTy::OutDefer(i) = t {
                break 'm11561 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_13272: Text| prism_rtl::Turn::Finished(Text::from(format!("Defer<{}>", &cpp_type_13272))))
                };
            }
            if let crate::lower::model::OutTy::OutWeak(n) = t {
                break 'm11561 prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::Weak<{}>", &type_path(n))));
            }
            if let crate::lower::model::OutTy::OutCell(i) = t {
                break 'm11561 prism_rtl::Turn::More(Rc::new(CppType { cp: cp.clone(), t: (**i).clone() }));
            }
            if let crate::lower::model::OutTy::OutWakes = t {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("Wakes"));
            }
            if let crate::lower::model::OutTy::OutCount = t {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("std::uint32_t"));
            }
            if let crate::lower::model::OutTy::OutObj(i) = t {
                break 'm11561 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_13447: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::Rc<{}>", &cpp_type_13447))))
                };
            }
            if let crate::lower::model::OutTy::OutSlice(i) = t {
                break 'm11561 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_13498: Text| prism_rtl::Turn::Finished(Text::from(format!("std::span<const {}>", &cpp_type_13498))))
                };
            }
            if let crate::lower::model::OutTy::OutPort(i) = t {
                break 'm11561 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_13537: Text| prism_rtl::Turn::Finished(Text::from(format!("Port<{}>", &cpp_type_13537))))
                };
            }
            if let crate::lower::model::OutTy::OutLive(i) = t {
                break 'm11561 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_13576: Text| prism_rtl::Turn::Finished(Text::from(format!("Live<{}>", &cpp_type_13576))))
                };
            }
            if let crate::lower::model::OutTy::OutUnknown(m11561_49_0) = t && (m11561_49_0 == &Text::lit("the job\'s turn")) {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("decltype(this->cycle())"));
            }
            if let crate::lower::model::OutTy::OutUnknown(what) = t {
                break 'm11561 prism_rtl::Turn::Finished(Text::from(format!("Unit /* {} */", what)));
            }
            if let crate::lower::model::OutTy::OutQuantified(b) = t {
                break 'm11561 prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}a quantified type variable of `{}`: no instantiation gives it a type\")", &crate::lower::expr::lowering_refusal(), b)));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start CppType, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_type(cp: Cp, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppType { cp, t })
}

/// ```prism
/// CppTypes: unbounded fn Cp, [OutTy] -> Text
/// ```
pub fn cpp_types(cp: &Cp, ts: &Array<crate::lower::model::OutTy>) -> Text {
    crate::syntax::lexer::chars::join(&run_to_end(each_job(ts.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::OutTy| {
            let cp = cp.clone();
            entered(once_job(move || {
                let t = p0;
                prism_rtl::Turn::More(Rc::new(CppType { cp: cp.clone(), t: t.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "))
}

/// The step machine of `CppTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppTypes: unbounded fn Cp, [OutTy] -> Text
/// ```
pub struct CppTypes {
    pub cp: Cp,
    pub ts: Array<crate::lower::model::OutTy>,
}

impl prism_rtl::Job<Text> for CppTypes {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let ts = &self.ts;
        let cp = cp.clone();
        let ts = ts.clone();
        call_value(each_job(ts.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: crate::lower::model::OutTy| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let t = p0;
                    prism_rtl::Turn::More(Rc::new(CppType { cp: cp.clone(), t: t.clone() }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_13894: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&each_13894, &Text::lit(", "))))
    }
}

/// `Start CppTypes, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_types(cp: Cp, ts: Array<crate::lower::model::OutTy>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppTypes { cp, ts })
}

/// ```prism
/// ParamTypes: unbounded fn Cp, [OutTy] -> Text
/// ```
pub fn param_types(cp: &Cp, ts: &Array<crate::lower::model::OutTy>) -> Text {
    crate::syntax::lexer::chars::join(&run_to_end(each_job(ts.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::OutTy| {
            let cp = cp.clone();
            entered(once_job(move || {
                let t = p0;
                call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_14109: Text| prism_rtl::Turn::Finished(Text::from(format!("const {}&", &cpp_type_14109))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "))
}

/// The step machine of `ParamTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParamTypes: unbounded fn Cp, [OutTy] -> Text
/// ```
pub struct ParamTypes {
    pub cp: Cp,
    pub ts: Array<crate::lower::model::OutTy>,
}

impl prism_rtl::Job<Text> for ParamTypes {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let ts = &self.ts;
        let cp = cp.clone();
        let ts = ts.clone();
        call_value(each_job(ts.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: crate::lower::model::OutTy| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let t = p0;
                    call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_14109: Text| prism_rtl::Turn::Finished(Text::from(format!("const {}&", &cpp_type_14109))))
                }))
            }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_14087: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&each_14087, &Text::lit(", "))))
    }
}

/// `Start ParamTypes, x`: what the function value is when passed to `@Run`.
pub fn start_param_types(cp: Cp, ts: Array<crate::lower::model::OutTy>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ParamTypes { cp, ts })
}

/// ```prism
/// OwnTypePath: fn Cp, Text -> Text
/// ```
pub fn own_type_path(cp: &Cp, n: &Text) -> Text {
    let shadowed = !crate::syntax::lexer::chars::contains(n, &Text::lit(":")) && in_list(&Array::from(vec![Text::lit("Job"), Text::lit("Node"), Text::lit("Row"), Text::lit("Turn"), Text::lit("Program")]), n);
    match type_of(cp, n) {
        Some(_) => if shadowed { Text::from(format!("crate::{}::{}", &cp.home, n)) } else { type_path(n) },
        None => type_path(n),
    }
}

/// ```prism
/// TypePath: fn Text -> Text
/// ```
pub fn type_path(p_: &Text) -> Text {
    let no_fish = crate::syntax::lexer::chars::join(&split_on(p_, &Text::lit("::<")), &Text::lit("<"));
    let no_holes = crate::syntax::lexer::chars::join(&split_on(&no_fish, &Text::lit(", _>")), &Text::lit(">"));
    crate::syntax::lexer::chars::join(&split_on(&no_holes, &Text::lit("<_>")), &Text::lit(""))
}

/// ```prism
/// IsValueTy: fn Cp, OutTy -> Bool
/// ```
pub fn is_value_ty(cp: &Cp, t: &crate::lower::model::OutTy) -> bool {
    match t {
        crate::lower::model::OutTy::OutNamed(n, _) => match type_of(cp, n) {
            Some(info) => (&info.kind != &Text::lit("node")) && (&info.kind != &Text::lit("job")),
            None => false,
        },
        crate::lower::model::OutTy::OutCell(_) => false,
        crate::lower::model::OutTy::OutPort(_) => false,
        crate::lower::model::OutTy::OutHold(_) => false,
        crate::lower::model::OutTy::OutStamped(_) => false,
        crate::lower::model::OutTy::OutSnapshot(_) => false,
        crate::lower::model::OutTy::OutDefer(_) => false,
        crate::lower::model::OutTy::OutObj(_) => false,
        crate::lower::model::OutTy::OutWakes => false,
        _ => true,
    }
}
