//! The module `Emit.Cpp`, from `target/bootstrap/src/prismc/emit/cpp/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (docs/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod prelude;
pub mod templates;

/// `Cp`:
///
/// ```prism
/// type Cp = record:
/// ```
#[derive(Clone)]
pub struct Cp {
    pub home: Text,
    pub mods: Array<Text>,
    pub types: Map<Text, TyInfo>,
    pub ctors: Map<Text, Text>,
    pub members: Map<Text, bool>,
    pub methods: Map<Text, bool>,
    pub field_names: Map<Text, bool>,
    pub fns: Map<Text, bool>,
    pub fields: Map<Text, crate::lower::model::OutTy>,
    pub renames: Map<Text, Text>,
    pub pointers: Map<Text, bool>,
}

impl ToPod for Cp {
    fn to_pod(&self) -> Pod {
        Pod::record("Cp", vec![("home", self.home.to_pod()), ("mods", self.mods.to_pod()), ("types", self.types.to_pod()), ("ctors", self.ctors.to_pod()), ("members", self.members.to_pod()), ("methods", self.methods.to_pod()), ("field_names", self.field_names.to_pod()), ("fns", self.fns.to_pod()), ("fields", self.fields.to_pod()), ("renames", self.renames.to_pod()), ("pointers", self.pointers.to_pod())])
    }
}

impl FromPod for Cp {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Cp { home: FromPod::from_pod(field(p, "home")?)?, mods: FromPod::from_pod(field(p, "mods")?)?, types: FromPod::from_pod(field(p, "types")?)?, ctors: FromPod::from_pod(field(p, "ctors")?)?, members: FromPod::from_pod(field(p, "members")?)?, methods: FromPod::from_pod(field(p, "methods")?)?, field_names: FromPod::from_pod(field(p, "field_names")?)?, fns: FromPod::from_pod(field(p, "fns")?)?, fields: FromPod::from_pod(field(p, "fields")?)?, renames: FromPod::from_pod(field(p, "renames")?)?, pointers: FromPod::from_pod(field(p, "pointers")?)? })
    }
}

/// `Parts`:
///
/// ```prism
/// type Parts = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Parts {
    pub forward: Array<Text>,
    pub handles: Array<Text>,
    pub values: Array<ValueDecl>,
    pub cases: Array<Text>,
    pub protos: Array<Text>,
    pub classes: Array<Text>,
    pub outer: Array<Text>,
    pub generic: Array<Text>,
    pub defs: Array<Text>,
}

impl Show for Parts {
    fn show(&self, p: &mut Printer) {
        p.record("Parts", &[("forward", &self.forward), ("handles", &self.handles), ("values", &self.values), ("cases", &self.cases), ("protos", &self.protos), ("classes", &self.classes), ("outer", &self.outer), ("generic", &self.generic), ("defs", &self.defs)]);
    }
}

impl ToPod for Parts {
    fn to_pod(&self) -> Pod {
        Pod::record("Parts", vec![("forward", self.forward.to_pod()), ("handles", self.handles.to_pod()), ("values", self.values.to_pod()), ("cases", self.cases.to_pod()), ("protos", self.protos.to_pod()), ("classes", self.classes.to_pod()), ("outer", self.outer.to_pod()), ("generic", self.generic.to_pod()), ("defs", self.defs.to_pod())])
    }
}

impl FromPod for Parts {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Parts { forward: FromPod::from_pod(field(p, "forward")?)?, handles: FromPod::from_pod(field(p, "handles")?)?, values: FromPod::from_pod(field(p, "values")?)?, cases: FromPod::from_pod(field(p, "cases")?)?, protos: FromPod::from_pod(field(p, "protos")?)?, classes: FromPod::from_pod(field(p, "classes")?)?, outer: FromPod::from_pod(field(p, "outer")?)?, generic: FromPod::from_pod(field(p, "generic")?)?, defs: FromPod::from_pod(field(p, "defs")?)? })
    }
}

/// `TyInfo`:
///
/// ```prism
/// type TyInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TyInfo {
    pub kind: Text,
    pub fields: Array<Text>,
    pub params: Array<Text>,
}

impl Show for TyInfo {
    fn show(&self, p: &mut Printer) {
        p.record("TyInfo", &[("kind", &self.kind), ("fields", &self.fields), ("params", &self.params)]);
    }
}

impl ToPod for TyInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("TyInfo", vec![("kind", self.kind.to_pod()), ("fields", self.fields.to_pod()), ("params", self.params.to_pod())])
    }
}

impl FromPod for TyInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TyInfo { kind: FromPod::from_pod(field(p, "kind")?)?, fields: FromPod::from_pod(field(p, "fields")?)?, params: FromPod::from_pod(field(p, "params")?)? })
    }
}

/// `ValueDecl`:
///
/// ```prism
/// type ValueDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ValueDecl {
    pub path_: Text,
    pub deps: Array<Text>,
    pub text: Text,
}

impl Show for ValueDecl {
    fn show(&self, p: &mut Printer) {
        p.record("ValueDecl", &[("path", &self.path_), ("deps", &self.deps), ("text", &self.text)]);
    }
}

impl ToPod for ValueDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("ValueDecl", vec![("path", self.path_.to_pod()), ("deps", self.deps.to_pod()), ("text", self.text.to_pod())])
    }
}

impl FromPod for ValueDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ValueDecl { path_: FromPod::from_pod(field(p, "path")?)?, deps: FromPod::from_pod(field(p, "deps")?)?, text: FromPod::from_pod(field(p, "text")?)? })
    }
}

/// ```prism
/// CppId: fn Text -> Text
/// ```
pub fn cpp_id(n: &Text) -> Text {
    if in_list(&cpp_keywords(), n) { Text::from(format!("{}_", n)) } else { n.clone() }
}

/// ```prism
/// let cppKeywords
/// ```
pub fn cpp_keywords() -> Array<Text> {
    Array::from(vec![Text::lit("explicit"), Text::lit("and"), Text::lit("and_eq"), Text::lit("asm"), Text::lit("auto"), Text::lit("bitand"), Text::lit("bitor"), Text::lit("bool"), Text::lit("case"), Text::lit("catch"), Text::lit("char"), Text::lit("char8_t"), Text::lit("char16_t"), Text::lit("char32_t"), Text::lit("class"), Text::lit("compl"), Text::lit("concept"), Text::lit("const_cast"), Text::lit("consteval"), Text::lit("constexpr"), Text::lit("constinit"), Text::lit("co_await"), Text::lit("co_return"), Text::lit("co_yield"), Text::lit("decltype"), Text::lit("default"), Text::lit("delete"), Text::lit("double"), Text::lit("dynamic_cast"), Text::lit("explicit"), Text::lit("export"), Text::lit("extern"), Text::lit("float"), Text::lit("friend"), Text::lit("goto"), Text::lit("inline"), Text::lit("int"), Text::lit("long"), Text::lit("mutable"), Text::lit("namespace"), Text::lit("new"), Text::lit("noexcept"), Text::lit("not"), Text::lit("not_eq"), Text::lit("nullptr"), Text::lit("operator"), Text::lit("or"), Text::lit("or_eq"), Text::lit("private"), Text::lit("protected"), Text::lit("public"), Text::lit("register"), Text::lit("reinterpret_cast"), Text::lit("requires"), Text::lit("short"), Text::lit("signed"), Text::lit("sizeof"), Text::lit("static_assert"), Text::lit("static_cast"), Text::lit("switch"), Text::lit("template"), Text::lit("this"), Text::lit("thread_local"), Text::lit("throw"), Text::lit("try"), Text::lit("typedef"), Text::lit("typeid"), Text::lit("typename"), Text::lit("union"), Text::lit("unsigned"), Text::lit("using"), Text::lit("virtual"), Text::lit("void"), Text::lit("volatile"), Text::lit("wchar_t"), Text::lit("xor"), Text::lit("xor_eq"), Text::lit("errno"), Text::lit("assert"), Text::lit("NULL"), Text::lit("EOF"), Text::lit("stdin"), Text::lit("stdout"), Text::lit("stderr"), Text::lit("major"), Text::lit("minor")])
}

/// ```prism
/// FieldId: fn Text -> Text
/// ```
pub fn field_id(f: &Text) -> Text {
    if in_list(&Array::from(vec![Text::lit("show"), Text::lit("to_pod"), Text::lit("from_pod"), Text::lit("cases")]), f) {
        Text::from(format!("{}_", f))
    } else {
        cpp_id(f)
    }
}

/// ```prism
/// CppPathId: fn Text -> Text
/// ```
pub fn cpp_path_id(p_: &Text) -> Text {
    crate::syntax::lexer::join(&each(&split(p_, &Text::lit("::")), &(|s: &Text| cpp_id(s))), &Text::lit("::"))
}

/// ```prism
/// InList: fn [Text], Text -> Bool
/// ```
pub fn in_list(xs: &Array<Text>, x: &Text) -> bool {
    fold(xs, &false, &(|seen: &bool, y: &Text| *seen || (y == x)))
}

/// ```prism
/// Absolute: fn Cp, Text -> Text
/// ```
pub fn absolute(cp: &Cp, p_: &Text) -> Text {
    let q = crate::syntax::lexer::drop_prefix(p_, &Text::lit("crate::"));
    if fold(&cp.mods, &false, &(|f: &bool, m: &Text| *f || crate::syntax::lexer::has_prefix(&q, &Text::from(format!("{}::", m))))) {
        q.clone()
    } else {
        Text::from(format!("{}::{}", &cp.home, &q))
    }
}

/// ```prism
/// ?TypeOf: fn Cp, Text -> ?TyInfo
/// ```
pub fn type_of(cp: &Cp, p_: &Text) -> Option<TyInfo> {
    let q = crate::syntax::lexer::drop_prefix(p_, &Text::lit("crate::"));
    match get(&cp.types, &absolute(cp, &q)) {
        Some(t) => Some(t.clone()),
        None => match get(&cp.types, &Text::from(format!("prelude::{}", &q))) {
            Some(t) => Some(t.clone()),
            None => get(&cp.types, &q),
        },
    }
}

/// ```prism
/// ?CaseOf: fn Cp, Text -> ?Text
/// ```
pub fn case_of(cp: &Cp, p_: &Text) -> Option<Text> {
    let q = crate::syntax::lexer::drop_prefix(p_, &Text::lit("crate::"));
    match get(&cp.ctors, &absolute(cp, &q)) {
        Some(_) => Some(parent_path(p_)),
        None => match get(&cp.ctors, &Text::from(format!("prelude::{}", &q))) {
            Some(_) => Some(parent_path(p_)),
            None => match get(&cp.ctors, &q) {
                Some(_) => Some(parent_path(p_)),
                None => None,
            },
        },
    }
}

/// ```prism
/// ParentPath: fn Text -> Text
/// ```
pub fn parent_path(p_: &Text) -> Text {
    let segs = split(p_, &Text::lit("::"));
    crate::syntax::lexer::join(&take(&segs, &crate::syntax::lexer::dec(&len(&segs))), &Text::lit("::"))
}

/// ```prism
/// LastSegment: fn Text -> Text
/// ```
pub fn last_segment(p_: &Text) -> Text {
    or(&crate::syntax::lexer::last(&split(p_, &Text::lit("::"))), p_)
}

/// ```prism
/// Context: fn Model -> Cp
/// ```
pub fn context(model: &crate::lower::model::Model) -> Cp {
    let names = each(&model.mods, &(|m: &crate::lower::model::ModDef| m.name.clone()));
    let tops = fold(&names, &Array::new(), &(|acc: &Array<Text>, n: &Text| {
        let top = or(&index(&split(n, &Text::lit("::")), &Nat::from(0u32)), n);
        if in_list(&names, &top) || in_list(acc, &top) { acc.clone() } else { push(acc, &top) }
    }));
    let mods = push(&append(&names, &tops), &Text::lit("prelude"));
    let base = Cp { home: Text::lit(""), mods: mods.clone(), types: prelude_types(), ctors: prelude_ctors(), members: node_base(), methods: Map::new(), field_names: Map::new(), fns: Map::new(), fields: Map::new(), renames: Map::new(), pointers: Map::new() };
    let with_elem = add_row(&add_answer(&base, &model.answer), &Text::lit(""), &model.elem);
    fold(&model.mods, &with_elem, &(|cp: &Cp, m: &crate::lower::model::ModDef| fold(&m.items, cp, &(|c: &Cp, it: &crate::lower::model::Item| add_model_item(c, &m.name, it)))))
}

/// ```prism
/// let preludeTypes
/// ```
pub fn prelude_types() -> Map<Text, TyInfo> {
    map_of(vec![(Text::lit("prelude::Ordering"), TyInfo { kind: Text::lit("choice"), fields: Array::new(), params: Array::new() }), (Text::lit("prelude::Span"), TyInfo { kind: Text::lit("record"), fields: Array::from(vec![Text::lit("file"), Text::lit("line"), Text::lit("column"), Text::lit("binding")]), params: Array::new() }), (Text::lit("prelude::Exception"), TyInfo { kind: Text::lit("record"), fields: Array::from(vec![Text::lit("kind"), Text::lit("message"), Text::lit("spans"), Text::lit("path_")]), params: Array::new() }), (Text::lit("prelude::Duration"), TyInfo { kind: Text::lit("newtype"), fields: Array::new(), params: Array::new() }), (Text::lit("prelude::PreludeUnwrap"), TyInfo { kind: Text::lit("tag"), fields: Array::new(), params: Array::new() }), (Text::lit("prelude::PreludeExceptions"), TyInfo { kind: Text::lit("tag"), fields: Array::new(), params: Array::new() })])
}

/// ```prism
/// let preludeCtors
/// ```
pub fn prelude_ctors() -> Map<Text, Text> {
    map_of(vec![(Text::lit("prelude::Ordering::Less"), Text::lit("choice")), (Text::lit("prelude::Ordering::Equal"), Text::lit("choice")), (Text::lit("prelude::Ordering::Greater"), Text::lit("choice"))])
}

/// ```prism
/// let nodeBase
/// ```
pub fn node_base() -> Map<Text, bool> {
    map_of(vec![(Text::lit("make"), true), (Text::lit("push"), true), (Text::lit("wake"), true), (Text::lit("started"), true), (Text::lit("deferred"), true), (Text::lit("build"), true), (Text::lit("swap"), true), (Text::lit("leave"), true), (Text::lit("patch"), true), (Text::lit("edges"), true), (Text::lit("release"), true), (Text::lit("clean_up"), true), (Text::lit("path"), true), (Text::lit("leave_row"), true), (Text::lit("answer"), true), (Text::lit("document"), true), (Text::lit("deliver"), true), (Text::lit("document_moved"), true), (Text::lit("me"), true), (Text::lit("result_dynamic"), true)])
}

/// ```prism
/// AddModelItem: fn Cp, Text, Item -> Cp
/// ```
pub fn add_model_item(cp: &Cp, m: &Text, it: &crate::lower::model::Item) -> Cp {
    match it {
        crate::lower::model::Item::ItType(t) => add_type(cp, m, t),
        crate::lower::model::Item::ItTag(t) => add_ty(cp, &Text::from(format!("{}::{}", m, &t.name)), &TyInfo { kind: Text::lit("tag"), fields: each(&t.fields, &(|(_, f, _): &(Text, Text, crate::lower::model::OutTy)| f.clone())), params: Array::new() }),
        crate::lower::model::Item::ItRow(r) => add_row(cp, m, r),
        crate::lower::model::Item::ItJob(j) => add_ty(cp, &Text::from(format!("{}::{}", m, &j.name)), &TyInfo { kind: Text::lit("job"), fields: each(&j.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| f.clone())), params: each(&j.generics, &(|(g, _): &(Text, Array<Text>)| g.clone())) }),
        crate::lower::model::Item::ItNode(n) => add_node(cp, m, n),
        crate::lower::model::Item::ItFn(f) => {
            let mut this: Cp = cp.clone();
            this.fns = insert(&this.fns, &Text::from(format!("{}::{}", m, &f.name)), &true);
            this
        },
        _ => cp.clone(),
    }
}

/// ```prism
/// AddTy: fn Cp, Text, TyInfo -> Cp
/// ```
pub fn add_ty(cp: &Cp, path_: &Text, info: &TyInfo) -> Cp {
    let mut this: Cp = cp.clone();
    this.types = insert(&this.types, path_, info);
    this
}

/// ```prism
/// AddCtor: fn Cp, Text, Text -> Cp
/// ```
pub fn add_ctor(cp: &Cp, path_: &Text, kind: &Text) -> Cp {
    let mut this: Cp = cp.clone();
    this.ctors = insert(&this.ctors, path_, kind);
    this
}

/// ```prism
/// AddMember: fn Cp, Text -> Cp
/// ```
pub fn add_member(cp: &Cp, name: &Text) -> Cp {
    let mut this: Cp = cp.clone();
    this.members = insert(&this.members, name, &true);
    this
}

/// ```prism
/// AddType: fn Cp, Text, TyDef -> Cp
/// ```
pub fn add_type(cp: &Cp, m: &Text, t: &crate::lower::model::TyDef) -> Cp {
    let path_ = Text::from(format!("{}::{}", m, &t.name));
    let first_ = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
    match &t.shape {
        crate::lower::model::TyShape::ShapeRecord => add_ty(cp, &path_, &TyInfo { kind: Text::lit("record"), fields: each(&first_.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| f.clone())), params: t.params.clone() }),
        crate::lower::model::TyShape::ShapeNewtype => add_ty(cp, &path_, &TyInfo { kind: Text::lit("newtype"), fields: Array::new(), params: t.params.clone() }),
        crate::lower::model::TyShape::ShapeUnit => add_ty(cp, &path_, &TyInfo { kind: Text::lit("unit"), fields: Array::new(), params: t.params.clone() }),
        crate::lower::model::TyShape::ShapeChoice => fold(&t.cases, &add_ty(cp, &path_, &TyInfo { kind: Text::lit("choice"), fields: Array::new(), params: t.params.clone() }), &(|c: &Cp, k: &crate::lower::model::CaseDef| add_ctor(c, &Text::from(format!("{}::{}", &path_, &k.name)), &Text::lit("choice")))),
    }
}

/// ```prism
/// AddRow: fn Cp, Text, RowDef -> Cp
/// ```
pub fn add_row(cp: &Cp, m: &Text, r: &crate::lower::model::RowDef) -> Cp {
    let path_ = if m == &Text::lit("") {
        r.name.clone()
    } else {
        Text::from(format!("{}::{}", m, &r.name))
    };
    fold(&r.cases, &add_ty(cp, &path_, &TyInfo { kind: Text::lit("choice"), fields: Array::new(), params: Array::new() }), &(|c: &Cp, (v_, _): &(Text, Text)| add_ctor(c, &Text::from(format!("{}::{}", &path_, v_)), &Text::lit("choice"))))
}

/// ```prism
/// AddAnswer: fn Cp, AnswerDef -> Cp
/// ```
pub fn add_answer(cp: &Cp, a: &crate::lower::model::AnswerDef) -> Cp {
    fold(&a.cases, &add_ty(cp, &Text::lit("Answer"), &TyInfo { kind: Text::lit("choice"), fields: Array::new(), params: Array::new() }), &(|c: &Cp, k: &crate::lower::model::AnswerCase| add_ctor(c, &Text::from(format!("Answer::{}", &k.variant)), &Text::lit("choice"))))
}

/// ```prism
/// AddNode: fn Cp, Text, NodeDef -> Cp
/// ```
pub fn add_node(cp: &Cp, m: &Text, n: &crate::lower::model::NodeDef) -> Cp {
    let with_fields_ = fold(&n.fields, cp, &(|c: &Cp, (f, _, _): &(Text, crate::lower::model::OutTy, Text)| {
        let mut this: Cp = add_member(c, f);
        this.field_names = insert(&this.field_names, f, &true);
        this
    }));
    let with_methods = fold(&append(&n.methods, &n.hosted), &with_fields_, &(|c: &Cp, md: &crate::lower::model::MethDef| {
        let mut this: Cp = add_member(c, &md.name);
        this.methods = insert(&this.methods, &md.name, &true);
        this
    }));
    let with_builders = fold(&n.builders, &with_methods, &(|c: &Cp, b: &crate::lower::model::ForDef| add_member(c, &Text::from(format!("{}_build", &b.name)))));
    let with_gens = fold(&n.gens, &with_builders, &(|c: &Cp, g: &crate::lower::model::GenDef| add_member(c, &Text::from(format!("{}_build", &g.name)))));
    add_ty(&with_gens, &Text::from(format!("{}::{}", m, &n.name)), &TyInfo { kind: Text::lit("node"), fields: each(&n.fields, &(|(f, _, _): &(Text, crate::lower::model::OutTy, Text)| f.clone())), params: Array::new() })
}

/// ```prism
/// InHome: fn Cp, Text -> Cp
/// ```
pub fn in_home(cp: &Cp, m: &Text) -> Cp {
    let mut this: Cp = cp.clone();
    this.home = m.clone();
    this
}

/// ```prism
/// WithFields: fn Cp, [((Text, OutTy))] -> Cp
/// ```
pub fn with_fields(cp: &Cp, fs: &Array<(Text, crate::lower::model::OutTy)>) -> Cp {
    let mut this: Cp = cp.clone();
    this.fields = fold(fs, &Map::new(), &(|acc: &Map<Text, crate::lower::model::OutTy>, (f, t): &(Text, crate::lower::model::OutTy)| insert(acc, f, t)));
    this
}

/// ```prism
/// CppType: unbounded fn Cp, OutTy -> Text
/// ```
pub fn cpp_type(cp: &Cp, t: &crate::lower::model::OutTy) -> Text {
    'm11017: {
        if let crate::lower::model::OutTy::OutNat = t {
            break 'm11017 Text::lit("Nat");
        }
        if let crate::lower::model::OutTy::OutInt = t {
            break 'm11017 Text::lit("Int");
        }
        if let crate::lower::model::OutTy::OutU8 = t {
            break 'm11017 Text::lit("std::uint8_t");
        }
        if let crate::lower::model::OutTy::OutFloat = t {
            break 'm11017 Text::lit("double");
        }
        if let crate::lower::model::OutTy::OutBool = t {
            break 'm11017 Text::lit("bool");
        }
        if let crate::lower::model::OutTy::OutChar = t {
            break 'm11017 Text::lit("char32_t");
        }
        if let crate::lower::model::OutTy::OutText = t {
            break 'm11017 Text::lit("Text");
        }
        if let crate::lower::model::OutTy::OutCursor = t {
            break 'm11017 Text::lit("Cursor");
        }
        if let crate::lower::model::OutTy::OutUnit = t {
            break 'm11017 Text::lit("Unit");
        }
        if let crate::lower::model::OutTy::OutPath = t {
            break 'm11017 Text::lit("Path");
        }
        if let crate::lower::model::OutTy::OutDuration = t {
            break 'm11017 Text::lit("Duration");
        }
        if let crate::lower::model::OutTy::OutError = t {
            break 'm11017 Text::lit("Error");
        }
        if let crate::lower::model::OutTy::OutNamed(m11017_12_0, m11017_12_1) = t && (m11017_12_0 == &Text::lit("Cell")) && (m11017_12_1.len() == 1) && let Some(i) = index(m11017_12_1, &Nat::from(0u32)) {
            break 'm11017 cpp_type(cp, &i);
        }
        if let crate::lower::model::OutTy::OutNamed(m11017_13_0, m11017_13_1) = t && (m11017_13_0 == &Text::lit("RefCell")) && (m11017_13_1.len() == 1) && let Some(i) = index(m11017_13_1, &Nat::from(0u32)) {
            break 'm11017 cpp_type(cp, &i);
        }
        if let crate::lower::model::OutTy::OutNamed(m11017_14_0, m11017_14_1) = t && (m11017_14_0 == &Text::lit("Vec")) && (m11017_14_1.len() == 1) && let Some(i) = index(m11017_14_1, &Nat::from(0u32)) {
            break 'm11017 Text::from(format!("std::vector<{}>", &cpp_type(cp, &i)));
        }
        if let crate::lower::model::OutTy::OutNamed(m11017_15_0, m11017_15_1) = t && (m11017_15_0 == &Text::lit("Result")) && (m11017_15_1.len() == 2) && let Some(a) = index(m11017_15_1, &Nat::from(0u32)) && let Some(b) = index(m11017_15_1, &Nat::from(1u32)) {
            break 'm11017 Text::from(format!("Expected<{}, {}>", &cpp_type(cp, &a), &cpp_type(cp, &b)));
        }
        if let crate::lower::model::OutTy::OutNamed(n, m11017_16_1) = t && (m11017_16_1.len() == 0) {
            break 'm11017 own_type_path(cp, n);
        }
        if let crate::lower::model::OutTy::OutNamed(n, args) = t {
            break 'm11017 Text::from(format!("{}<{}>", &own_type_path(cp, n), &cpp_types(cp, args)));
        }
        if let crate::lower::model::OutTy::OutOpt(i) = t {
            break 'm11017 Text::from(format!("std::optional<{}>", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutRes(i) = t {
            break 'm11017 Text::from(format!("Fallible<{}>", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutTuple(ts) = t {
            break 'm11017 Text::from(format!("std::tuple<{}>", &cpp_types(cp, ts)));
        }
        if let crate::lower::model::OutTy::OutArray(e) = t {
            break 'm11017 Text::from(format!("Array<{}>", &cpp_type(cp, &**e)));
        }
        if let crate::lower::model::OutTy::OutMap(k, v_) = t {
            break 'm11017 Text::from(format!("Map<{}, {}>", &cpp_type(cp, &**k), &cpp_type(cp, &**v_)));
        }
        if let crate::lower::model::OutTy::OutFn(ps, r) = t {
            break 'm11017 Text::from(format!("Fn<{}({})>", &cpp_type(cp, &**r), &param_types(cp, ps)));
        }
        if let crate::lower::model::OutTy::OutRef(m11017_24_0) = t && let crate::lower::model::OutTy::OutFn(ps, r) = &**m11017_24_0 {
            break 'm11017 Text::from(format!("const std::function<{}({})>&", &cpp_type(cp, &**r), &param_types(cp, ps)));
        }
        if let crate::lower::model::OutTy::OutRef(m11017_25_0) = t && let crate::lower::model::OutTy::OutSlice(i) = &**m11017_25_0 {
            break 'm11017 Text::from(format!("std::span<const {}>", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutRef(i) = t {
            break 'm11017 Text::from(format!("const {}&", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutJobFn(a, b) = t {
            break 'm11017 Text::from(format!("prism_rtl::Fn<prism_rtl::JobRef<{}>({})>", &cpp_type(cp, &**b), &cpp_type(cp, &**a)));
        }
        if let crate::lower::model::OutTy::OutJob(b) = t {
            break 'm11017 Text::from(format!("prism_rtl::JobRef<{}>", &cpp_type(cp, &**b)));
        }
        if let crate::lower::model::OutTy::OutEvent(i) = t {
            break 'm11017 Text::from(format!("Event<{}>", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutDyn(i) = t {
            break 'm11017 Text::from(format!("Dynamic<{}>", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutGen(n) = t {
            break 'm11017 n.clone();
        }
        if let crate::lower::model::OutTy::OutRc(i) = t {
            break 'm11017 if is_value_ty(cp, &**i) {
                cpp_type(cp, &**i)
            } else {
                Text::from(format!("prism_rtl::Rc<{}>", &cpp_type(cp, &**i)))
            };
        }
        if let crate::lower::model::OutTy::OutPod = t {
            break 'm11017 Text::lit("Pod");
        }
        if let crate::lower::model::OutTy::OutShowAny = t {
            break 'm11017 Text::lit("prism_rtl::Rc<const DynShow>");
        }
        if let crate::lower::model::OutTy::OutHold(i) = t {
            break 'm11017 Text::from(format!("Hold<{}>", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutStamped(i) = t {
            break 'm11017 Text::from(format!("Stamped<{}>", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutSnapshot(i) = t {
            break 'm11017 Text::from(format!("Snapshot<{}>", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutDefer(i) = t {
            break 'm11017 Text::from(format!("Defer<{}>", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutWeak(n) = t {
            break 'm11017 Text::from(format!("prism_rtl::Weak<{}>", &type_path(n)));
        }
        if let crate::lower::model::OutTy::OutCell(i) = t {
            break 'm11017 cpp_type(cp, &**i);
        }
        if let crate::lower::model::OutTy::OutWakes = t {
            break 'm11017 Text::lit("Wakes");
        }
        if let crate::lower::model::OutTy::OutCount = t {
            break 'm11017 Text::lit("std::uint32_t");
        }
        if let crate::lower::model::OutTy::OutObj(i) = t {
            break 'm11017 Text::from(format!("prism_rtl::Rc<{}>", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutSlice(i) = t {
            break 'm11017 Text::from(format!("std::span<const {}>", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutPort(i) = t {
            break 'm11017 Text::from(format!("Port<{}>", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutLive(i) = t {
            break 'm11017 Text::from(format!("Live<{}>", &cpp_type(cp, &**i)));
        }
        if let crate::lower::model::OutTy::OutUnknown(m11017_47_0) = t && (m11017_47_0 == &Text::lit("the job's turn")) {
            break 'm11017 Text::lit("decltype(this->cycle())");
        }
        if let crate::lower::model::OutTy::OutUnknown(what) = t {
            break 'm11017 Text::from(format!("Unit /* {} */", what));
        }
        if let crate::lower::model::OutTy::OutQuantified(b) = t {
            break 'm11017 Text::from(format!("compile_error!(\"{}a quantified type variable of `{}`: no instantiation gives it a type\")", &crate::lower::lowering_refusal(), b));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `CppType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppType: unbounded fn Cp, OutTy -> Text
/// ```
pub struct CppType {
    pub cp: Cp,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for CppType {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let t = &self.t;
        'm11017: {
            if let crate::lower::model::OutTy::OutNat = t {
                break 'm11017 prism_rtl::Turn::Finished(Text::lit("Nat"));
            }
            if let crate::lower::model::OutTy::OutInt = t {
                break 'm11017 prism_rtl::Turn::Finished(Text::lit("Int"));
            }
            if let crate::lower::model::OutTy::OutU8 = t {
                break 'm11017 prism_rtl::Turn::Finished(Text::lit("std::uint8_t"));
            }
            if let crate::lower::model::OutTy::OutFloat = t {
                break 'm11017 prism_rtl::Turn::Finished(Text::lit("double"));
            }
            if let crate::lower::model::OutTy::OutBool = t {
                break 'm11017 prism_rtl::Turn::Finished(Text::lit("bool"));
            }
            if let crate::lower::model::OutTy::OutChar = t {
                break 'm11017 prism_rtl::Turn::Finished(Text::lit("char32_t"));
            }
            if let crate::lower::model::OutTy::OutText = t {
                break 'm11017 prism_rtl::Turn::Finished(Text::lit("Text"));
            }
            if let crate::lower::model::OutTy::OutCursor = t {
                break 'm11017 prism_rtl::Turn::Finished(Text::lit("Cursor"));
            }
            if let crate::lower::model::OutTy::OutUnit = t {
                break 'm11017 prism_rtl::Turn::Finished(Text::lit("Unit"));
            }
            if let crate::lower::model::OutTy::OutPath = t {
                break 'm11017 prism_rtl::Turn::Finished(Text::lit("Path"));
            }
            if let crate::lower::model::OutTy::OutDuration = t {
                break 'm11017 prism_rtl::Turn::Finished(Text::lit("Duration"));
            }
            if let crate::lower::model::OutTy::OutError = t {
                break 'm11017 prism_rtl::Turn::Finished(Text::lit("Error"));
            }
            if let crate::lower::model::OutTy::OutNamed(m11017_12_0, m11017_12_1) = t && (m11017_12_0 == &Text::lit("Cell")) && (m11017_12_1.len() == 1) && let Some(i) = index(m11017_12_1, &Nat::from(0u32)) {
                break 'm11017 prism_rtl::Turn::More(Rc::new(CppType { cp: cp.clone(), t: i.clone() }));
            }
            if let crate::lower::model::OutTy::OutNamed(m11017_13_0, m11017_13_1) = t && (m11017_13_0 == &Text::lit("RefCell")) && (m11017_13_1.len() == 1) && let Some(i) = index(m11017_13_1, &Nat::from(0u32)) {
                break 'm11017 prism_rtl::Turn::More(Rc::new(CppType { cp: cp.clone(), t: i.clone() }));
            }
            if let crate::lower::model::OutTy::OutNamed(m11017_14_0, m11017_14_1) = t && (m11017_14_0 == &Text::lit("Vec")) && (m11017_14_1.len() == 1) && let Some(i) = index(m11017_14_1, &Nat::from(0u32)) {
                break 'm11017 {
                    let cp = cp.clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_11417: Text| prism_rtl::Turn::Finished(Text::from(format!("std::vector<{}>", &cpp_type_11417))))
                };
            }
            if let crate::lower::model::OutTy::OutNamed(m11017_15_0, m11017_15_1) = t && (m11017_15_0 == &Text::lit("Result")) && (m11017_15_1.len() == 2) && let Some(a) = index(m11017_15_1, &Nat::from(0u32)) && let Some(b) = index(m11017_15_1, &Nat::from(1u32)) {
                break 'm11017 {
                    let cp = cp.clone();
                    call_then(start_cpp_type(cp.clone(), a.clone()), move |cpp_type_11478: Text| call_then(start_cpp_type(cp.clone(), b.clone()), move |cpp_type_11495: Text| prism_rtl::Turn::Finished(Text::from(format!("Expected<{}, {}>", &cpp_type_11478, &cpp_type_11495)))))
                };
            }
            if let crate::lower::model::OutTy::OutNamed(n, m11017_16_1) = t && (m11017_16_1.len() == 0) {
                break 'm11017 prism_rtl::Turn::Finished(own_type_path(cp, n));
            }
            if let crate::lower::model::OutTy::OutNamed(n, args) = t {
                break 'm11017 {
                    let args = args.clone();
                    let cp = cp.clone();
                    let n = n.clone();
                    call_then(start_cpp_types(cp.clone(), args.clone()), move |cpp_types_11596: Text| prism_rtl::Turn::Finished(Text::from(format!("{}<{}>", &own_type_path(&cp, &n), &cpp_types_11596))))
                };
            }
            if let crate::lower::model::OutTy::OutOpt(i) = t {
                break 'm11017 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_11647: Text| prism_rtl::Turn::Finished(Text::from(format!("std::optional<{}>", &cpp_type_11647))))
                };
            }
            if let crate::lower::model::OutTy::OutRes(i) = t {
                break 'm11017 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_11689: Text| prism_rtl::Turn::Finished(Text::from(format!("Fallible<{}>", &cpp_type_11689))))
                };
            }
            if let crate::lower::model::OutTy::OutTuple(ts) = t {
                break 'm11017 {
                    let cp = cp.clone();
                    let ts = ts.clone();
                    call_then(start_cpp_types(cp.clone(), ts.clone()), move |cpp_types_11736: Text| prism_rtl::Turn::Finished(Text::from(format!("std::tuple<{}>", &cpp_types_11736))))
                };
            }
            if let crate::lower::model::OutTy::OutArray(e) = t {
                break 'm11017 {
                    let cp = cp.clone();
                    let e = (**e).clone();
                    call_then(start_cpp_type(cp.clone(), e.clone()), move |cpp_type_11779: Text| prism_rtl::Turn::Finished(Text::from(format!("Array<{}>", &cpp_type_11779))))
                };
            }
            if let crate::lower::model::OutTy::OutMap(k, v_) = t {
                break 'm11017 {
                    let cp = cp.clone();
                    let k = (**k).clone();
                    let v_ = (**v_).clone();
                    call_then(start_cpp_type(cp.clone(), k.clone()), move |cpp_type_11819: Text| call_then(start_cpp_type(cp.clone(), v_.clone()), move |cpp_type_11836: Text| prism_rtl::Turn::Finished(Text::from(format!("Map<{}, {}>", &cpp_type_11819, &cpp_type_11836)))))
                };
            }
            if let crate::lower::model::OutTy::OutFn(ps, r) = t {
                break 'm11017 {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let r = (**r).clone();
                    call_then(start_cpp_type(cp.clone(), r.clone()), move |cpp_type_11875: Text| call_then(start_param_types(cp.clone(), ps.clone()), move |param_types_11891: Text| prism_rtl::Turn::Finished(Text::from(format!("Fn<{}({})>", &cpp_type_11875, &param_types_11891)))))
                };
            }
            if let crate::lower::model::OutTy::OutRef(m11017_24_0) = t && let crate::lower::model::OutTy::OutFn(ps, r) = &**m11017_24_0 {
                break 'm11017 {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let r = (**r).clone();
                    call_then(start_cpp_type(cp.clone(), r.clone()), move |cpp_type_11961: Text| call_then(start_param_types(cp.clone(), ps.clone()), move |param_types_11977: Text| prism_rtl::Turn::Finished(Text::from(format!("const std::function<{}({})>&", &cpp_type_11961, &param_types_11977)))))
                };
            }
            if let crate::lower::model::OutTy::OutRef(m11017_25_0) = t && let crate::lower::model::OutTy::OutSlice(i) = &**m11017_25_0 {
                break 'm11017 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_12043: Text| prism_rtl::Turn::Finished(Text::from(format!("std::span<const {}>", &cpp_type_12043))))
                };
            }
            if let crate::lower::model::OutTy::OutRef(i) = t {
                break 'm11017 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_12082: Text| prism_rtl::Turn::Finished(Text::from(format!("const {}&", &cpp_type_12082))))
                };
            }
            if let crate::lower::model::OutTy::OutJobFn(a, b) = t {
                break 'm11017 {
                    let a = (**a).clone();
                    let b = (**b).clone();
                    let cp = cp.clone();
                    call_then(start_cpp_type(cp.clone(), b.clone()), move |cpp_type_12152: Text| call_then(start_cpp_type(cp.clone(), a.clone()), move |cpp_type_12169: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::Fn<prism_rtl::JobRef<{}>({})>", &cpp_type_12152, &cpp_type_12169)))))
                };
            }
            if let crate::lower::model::OutTy::OutJob(b) = t {
                break 'm11017 {
                    let b = (**b).clone();
                    let cp = cp.clone();
                    call_then(start_cpp_type(cp.clone(), b.clone()), move |cpp_type_12221: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::JobRef<{}>", &cpp_type_12221))))
                };
            }
            if let crate::lower::model::OutTy::OutEvent(i) = t {
                break 'm11017 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_12262: Text| prism_rtl::Turn::Finished(Text::from(format!("Event<{}>", &cpp_type_12262))))
                };
            }
            if let crate::lower::model::OutTy::OutDyn(i) = t {
                break 'm11017 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_12303: Text| prism_rtl::Turn::Finished(Text::from(format!("Dynamic<{}>", &cpp_type_12303))))
                };
            }
            if let crate::lower::model::OutTy::OutGen(n) = t {
                break 'm11017 prism_rtl::Turn::Finished(n.clone());
            }
            if let crate::lower::model::OutTy::OutRc(i) = t {
                break 'm11017 if is_value_ty(cp, &**i) {
                    prism_rtl::Turn::More(Rc::new(CppType { cp: cp.clone(), t: (**i).clone() }))
                } else {
                    {
                        let cp = cp.clone();
                        let i = (**i).clone();
                        call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_12405: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::Rc<{}>", &cpp_type_12405))))
                    }
                };
            }
            if let crate::lower::model::OutTy::OutPod = t {
                break 'm11017 prism_rtl::Turn::Finished(Text::lit("Pod"));
            }
            if let crate::lower::model::OutTy::OutShowAny = t {
                break 'm11017 prism_rtl::Turn::Finished(Text::lit("prism_rtl::Rc<const DynShow>"));
            }
            if let crate::lower::model::OutTy::OutHold(i) = t {
                break 'm11017 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_12509: Text| prism_rtl::Turn::Finished(Text::from(format!("Hold<{}>", &cpp_type_12509))))
                };
            }
            if let crate::lower::model::OutTy::OutStamped(i) = t {
                break 'm11017 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_12554: Text| prism_rtl::Turn::Finished(Text::from(format!("Stamped<{}>", &cpp_type_12554))))
                };
            }
            if let crate::lower::model::OutTy::OutSnapshot(i) = t {
                break 'm11017 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_12601: Text| prism_rtl::Turn::Finished(Text::from(format!("Snapshot<{}>", &cpp_type_12601))))
                };
            }
            if let crate::lower::model::OutTy::OutDefer(i) = t {
                break 'm11017 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_12642: Text| prism_rtl::Turn::Finished(Text::from(format!("Defer<{}>", &cpp_type_12642))))
                };
            }
            if let crate::lower::model::OutTy::OutWeak(n) = t {
                break 'm11017 prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::Weak<{}>", &type_path(n))));
            }
            if let crate::lower::model::OutTy::OutCell(i) = t {
                break 'm11017 prism_rtl::Turn::More(Rc::new(CppType { cp: cp.clone(), t: (**i).clone() }));
            }
            if let crate::lower::model::OutTy::OutWakes = t {
                break 'm11017 prism_rtl::Turn::Finished(Text::lit("Wakes"));
            }
            if let crate::lower::model::OutTy::OutCount = t {
                break 'm11017 prism_rtl::Turn::Finished(Text::lit("std::uint32_t"));
            }
            if let crate::lower::model::OutTy::OutObj(i) = t {
                break 'm11017 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_12817: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::Rc<{}>", &cpp_type_12817))))
                };
            }
            if let crate::lower::model::OutTy::OutSlice(i) = t {
                break 'm11017 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_12868: Text| prism_rtl::Turn::Finished(Text::from(format!("std::span<const {}>", &cpp_type_12868))))
                };
            }
            if let crate::lower::model::OutTy::OutPort(i) = t {
                break 'm11017 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_12907: Text| prism_rtl::Turn::Finished(Text::from(format!("Port<{}>", &cpp_type_12907))))
                };
            }
            if let crate::lower::model::OutTy::OutLive(i) = t {
                break 'm11017 {
                    let cp = cp.clone();
                    let i = (**i).clone();
                    call_then(start_cpp_type(cp.clone(), i.clone()), move |cpp_type_12946: Text| prism_rtl::Turn::Finished(Text::from(format!("Live<{}>", &cpp_type_12946))))
                };
            }
            if let crate::lower::model::OutTy::OutUnknown(m11017_47_0) = t && (m11017_47_0 == &Text::lit("the job's turn")) {
                break 'm11017 prism_rtl::Turn::Finished(Text::lit("decltype(this->cycle())"));
            }
            if let crate::lower::model::OutTy::OutUnknown(what) = t {
                break 'm11017 prism_rtl::Turn::Finished(Text::from(format!("Unit /* {} */", what)));
            }
            if let crate::lower::model::OutTy::OutQuantified(b) = t {
                break 'm11017 prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}a quantified type variable of `{}`: no instantiation gives it a type\")", &crate::lower::lowering_refusal(), b)));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start CppType, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_type(cp: Cp, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppType { cp, t })
}

/// ```prism
/// CppTypes: unbounded fn Cp, [OutTy] -> Text
/// ```
pub fn cpp_types(cp: &Cp, ts: &Array<crate::lower::model::OutTy>) -> Text {
    crate::syntax::lexer::join(&run_to_end(each_job(ts.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::OutTy| {
            let cp = cp.clone();
            entered(once_job(move || {
                let t = p0;
                prism_rtl::Turn::More(Rc::new(CppType { cp: cp.clone(), t: t.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "))
}

/// The step machine of `CppTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppTypes: unbounded fn Cp, [OutTy] -> Text
/// ```
pub struct CppTypes {
    pub cp: Cp,
    pub ts: Array<crate::lower::model::OutTy>,
}

impl prism_rtl::Job<Text> for CppTypes {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let ts = &self.ts;
        let cp = cp.clone();
        let ts = ts.clone();
        call_value(each_job(ts.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: crate::lower::model::OutTy| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let t = p0;
                    prism_rtl::Turn::More(Rc::new(CppType { cp: cp.clone(), t: t.clone() }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_13264: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::join(&each_13264, &Text::lit(", "))))
    }
}

/// `Start CppTypes, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_types(cp: Cp, ts: Array<crate::lower::model::OutTy>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppTypes { cp, ts })
}

/// ```prism
/// ParamTypes: unbounded fn Cp, [OutTy] -> Text
/// ```
pub fn param_types(cp: &Cp, ts: &Array<crate::lower::model::OutTy>) -> Text {
    crate::syntax::lexer::join(&run_to_end(each_job(ts.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::OutTy| {
            let cp = cp.clone();
            entered(once_job(move || {
                let t = p0;
                call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_13479: Text| prism_rtl::Turn::Finished(Text::from(format!("const {}&", &cpp_type_13479))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "))
}

/// The step machine of `ParamTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParamTypes: unbounded fn Cp, [OutTy] -> Text
/// ```
pub struct ParamTypes {
    pub cp: Cp,
    pub ts: Array<crate::lower::model::OutTy>,
}

impl prism_rtl::Job<Text> for ParamTypes {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let ts = &self.ts;
        let cp = cp.clone();
        let ts = ts.clone();
        call_value(each_job(ts.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: crate::lower::model::OutTy| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let t = p0;
                    call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_13479: Text| prism_rtl::Turn::Finished(Text::from(format!("const {}&", &cpp_type_13479))))
                }))
            }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_13457: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::join(&each_13457, &Text::lit(", "))))
    }
}

/// `Start ParamTypes, x`: what the function value is when passed to `@Run`.
pub fn start_param_types(cp: Cp, ts: Array<crate::lower::model::OutTy>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ParamTypes { cp, ts })
}

/// ```prism
/// OwnTypePath: fn Cp, Text -> Text
/// ```
pub fn own_type_path(cp: &Cp, n: &Text) -> Text {
    let shadowed = !crate::syntax::lexer::contains(n, &Text::lit(":")) && in_list(&Array::from(vec![Text::lit("Job"), Text::lit("Node"), Text::lit("Row"), Text::lit("Turn"), Text::lit("Program")]), n);
    match type_of(cp, n) {
        Some(_) => if shadowed { Text::from(format!("crate::{}::{}", &cp.home, n)) } else { type_path(n) },
        None => type_path(n),
    }
}

/// ```prism
/// TypePath: fn Text -> Text
/// ```
pub fn type_path(p_: &Text) -> Text {
    let no_fish = crate::syntax::lexer::join(&split(p_, &Text::lit("::<")), &Text::lit("<"));
    let no_holes = crate::syntax::lexer::join(&split(&no_fish, &Text::lit(", _>")), &Text::lit(">"));
    crate::syntax::lexer::join(&split(&no_holes, &Text::lit("<_>")), &Text::lit(""))
}

/// ```prism
/// IsValueTy: fn Cp, OutTy -> Bool
/// ```
pub fn is_value_ty(cp: &Cp, t: &crate::lower::model::OutTy) -> bool {
    match t {
        crate::lower::model::OutTy::OutNamed(n, _) => match type_of(cp, n) {
            Some(info) => (&info.kind != &Text::lit("node")) && (&info.kind != &Text::lit("job")),
            None => false,
        },
        crate::lower::model::OutTy::OutCell(_) => false,
        crate::lower::model::OutTy::OutPort(_) => false,
        crate::lower::model::OutTy::OutHold(_) => false,
        crate::lower::model::OutTy::OutStamped(_) => false,
        crate::lower::model::OutTy::OutSnapshot(_) => false,
        crate::lower::model::OutTy::OutDefer(_) => false,
        crate::lower::model::OutTy::OutObj(_) => false,
        crate::lower::model::OutTy::OutWakes => false,
        _ => true,
    }
}

/// ```prism
/// CppLoose: fn Ex -> Bool
/// ```
pub fn cpp_loose(x: &crate::lower::model::Ex) -> bool {
    match x {
        crate::lower::model::Ex::XBlock(m15184_0_0, inner) if (m15184_0_0.len() == 0) => cpp_loose(&**inner),
        crate::lower::model::Ex::XBin(_, _, _) => true,
        crate::lower::model::Ex::XUnary(_, _) => true,
        crate::lower::model::Ex::XIf(_, _, _) => true,
        crate::lower::model::Ex::XRef(y) => cpp_loose(&**y),
        crate::lower::model::Ex::XRefMut(y) => cpp_loose(&**y),
        crate::lower::model::Ex::XDeref(y) => cpp_loose(&**y),
        crate::lower::model::Ex::XClone(y) => cpp_loose(&**y),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CppTight: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_tight(cp: &Cp, x: &crate::lower::model::Ex) -> Text {
    if cpp_loose(x) {
        Text::from(format!("({})", &cpp_expr(cp, x)))
    } else {
        cpp_expr(cp, x)
    }
}

/// The step machine of `CppTight`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppTight: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppTight {
    pub cp: Cp,
    pub x: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppTight {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let x = &self.x;
        if cpp_loose(x) {
            {
                let cp = cp.clone();
                let x = x.clone();
                call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_15536: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &cpp_expr_15536))))
            }
        } else {
            prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: x.clone() }))
        }
    }
}

/// `Start CppTight, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_tight(cp: Cp, x: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppTight { cp, x })
}

/// ```prism
/// CppArgs: unbounded fn Cp, [Ex] -> Text
/// ```
pub fn cpp_args(cp: &Cp, xs: &Array<crate::lower::model::Ex>) -> Text {
    crate::syntax::lexer::join(&run_to_end(each_job(xs.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::Ex| {
            let cp = cp.clone();
            entered(once_job(move || {
                let x = p0;
                prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: x.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "))
}

/// The step machine of `CppArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppArgs: unbounded fn Cp, [Ex] -> Text
/// ```
pub struct CppArgs {
    pub cp: Cp,
    pub xs: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for CppArgs {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let xs = &self.xs;
        let cp = cp.clone();
        let xs = xs.clone();
        call_value(each_job(xs.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: crate::lower::model::Ex| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let x = p0;
                    prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: x.clone() }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_15639: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::join(&each_15639, &Text::lit(", "))))
    }
}

/// `Start CppArgs, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_args(cp: Cp, xs: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppArgs { cp, xs })
}

/// ```prism
/// CppExpr: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_expr(cp: &Cp, x: &crate::lower::model::Ex) -> Text {
    match x {
        crate::lower::model::Ex::XVar(n) => var_name(cp, n),
        crate::lower::model::Ex::XPath(p_) => path_value(cp, p_),
        crate::lower::model::Ex::XSelf => Text::lit("prism_rtl::share(this)"),
        crate::lower::model::Ex::XCx => Text::lit("cx"),
        crate::lower::model::Ex::XConst(n) => n.clone(),
        crate::lower::model::Ex::XUnit => Text::lit("Unit{}"),
        crate::lower::model::Ex::XNone => Text::lit("std::nullopt"),
        crate::lower::model::Ex::XBool(b) => if *b { Text::lit("true") } else { Text::lit("false") },
        crate::lower::model::Ex::XNat(d) => if &len_text(d) <= &Nat::from(9u32) {
            Text::from(format!("Nat({}u)", d))
        } else {
            Text::from(format!("*Nat::from_int({})", &cpp_expr(cp, &crate::lower::model::Ex::XInt(d.clone()))))
        },
        crate::lower::model::Ex::XInt(d) => if &len_text(&(if crate::syntax::lexer::has_prefix(d, &Text::lit("-")) {
            crate::syntax::lexer::after_first(d)
        } else {
            d.clone()
        })) <= &Nat::from(18u32) {
            Text::from(format!("Int({}ll)", d))
        } else {
            Text::from(format!("*Int::parse(\"{}\")", d))
        },
        crate::lower::model::Ex::XByte(d) => Text::from(format!("std::uint8_t({})", d)),
        crate::lower::model::Ex::XFloat(d) => d.clone(),
        crate::lower::model::Ex::XIndex(n) => Text::from(format!("{}u", n)),
        crate::lower::model::Ex::XChar(c) => Text::from(format!("U'{}'", &cpp_char_escape(c))),
        crate::lower::model::Ex::XStr(t) => cpp_string(t),
        crate::lower::model::Ex::XRef(y) => cpp_expr(cp, &**y),
        crate::lower::model::Ex::XRefMut(y) => cpp_expr(cp, &**y),
        crate::lower::model::Ex::XDeref(y) => cpp_expr(cp, &**y),
        crate::lower::model::Ex::XTarget(y) => cpp_expr(cp, &**y),
        crate::lower::model::Ex::XClone(y) => cpp_expr(cp, &**y),
        crate::lower::model::Ex::XWeak(y) => Text::from(format!("prism_rtl::weaken({})", &cpp_expr(cp, &**y))),
        crate::lower::model::Ex::XUpgrade(y) => Text::from(format!("prism_rtl::upgrade({})", &cpp_expr(cp, &**y))),
        crate::lower::model::Ex::XBreak(l, y) => Text::from(format!("({})", &cpp_break(cp, l, &**y))),
        crate::lower::model::Ex::XBreakLoop => Text::lit("({ break; })"),
        crate::lower::model::Ex::XLater(y) => Text::from(format!("[=](Cx& cx) -> Done {{ {}; return {{}}; }}", &cpp_expr(cp, &**y))),
        crate::lower::model::Ex::XFormatStr(parts) => cpp_format(cp, parts, &Text::lit("prism_rtl::str")),
        crate::lower::model::Ex::XIsCase(y, m15731_26_1) if (m15731_26_1.len() == 0) => Text::lit("false"),
        crate::lower::model::Ex::XIsCase(y, cs) => Text::from(format!("({})", &crate::syntax::lexer::join(&run_to_end(each_job(cs.clone(), {
            let cp = cp.clone();
            let y = (**y).clone();
            Rc::new(move |p0: Text| {
                let cp = cp.clone();
                let y = y.clone();
                entered(once_job(move || {
                    let c = p0;
                    call_then(start_cpp_tight(cp.clone(), y.clone()), move |cpp_tight_16821: Text| prism_rtl::Turn::Finished(case_test(&cp, &c, &cpp_tight_16821)))
                }))
            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>
        })), &Text::lit(" || ")))),
        crate::lower::model::Ex::XRefusal(what) => Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::lowering_refusal(), &crate::lower::escape(what))),
        crate::lower::model::Ex::XUnreachable => Text::lit("throw prism_rtl::Panic(\"entered unreachable code\")"),
        crate::lower::model::Ex::XCall(f, args) => cpp_call(cp, f, args),
        crate::lower::model::Ex::XApply(f, args) => Text::from(format!("{}({})", &cpp_tight(cp, &**f), &cpp_args(cp, args))),
        crate::lower::model::Ex::XMethod(r, m, args) => cpp_method(cp, &**r, m, args),
        crate::lower::model::Ex::XBin(op, l, r) => Text::from(format!("{} {} {}", &cpp_tight(cp, &**l), op, &cpp_tight(cp, &**r))),
        crate::lower::model::Ex::XUnary(op, y) => Text::from(format!("{}{}", op, &cpp_tight(cp, &**y))),
        crate::lower::model::Ex::XCtor(p_, args) => cpp_ctor(cp, p_, args),
        crate::lower::model::Ex::XRecord(p_, fs) => cpp_record(cp, p_, fs),
        crate::lower::model::Ex::XTuple(xs) => Text::from(format!("std::tuple{{{}}}", &cpp_args(cp, xs))),
        crate::lower::model::Ex::XVec(m15731_38_0) if (m15731_38_0.len() == 0) => Text::lit("{}"),
        crate::lower::model::Ex::XVec(xs) => Text::from(format!("std::vector{{{}}}", &cpp_args(cp, xs))),
        crate::lower::model::Ex::XText(t) => Text::from(format!("Text::lit({})", &cpp_string(t))),
        crate::lower::model::Ex::XFormat(parts) => if fold(parts, &true, &(|f: &bool, p_: &crate::lower::model::Ex| *f && is_text_piece(p_))) {
            Text::from(format!("Text::lit({})", &cpp_string(&concat(&each(parts, &(|p_: &crate::lower::model::Ex| text_piece(p_)))))))
        } else {
            cpp_format(cp, parts, &Text::lit("prism_rtl::cat"))
        },
        crate::lower::model::Ex::XMatch(s, arms, fallback, t) => cpp_match(cp, &**s, arms, t),
        crate::lower::model::Ex::XChain(label, s, arms, t) => cpp_match(cp, &**s, arms, t),
        crate::lower::model::Ex::XIf(c, t, e) => cpp_if(cp, &**c, &**t, &**e),
        crate::lower::model::Ex::XBlock(m15731_45_0, e) if (m15731_45_0.len() == 0) => cpp_expr(cp, &**e),
        crate::lower::model::Ex::XBlock(dos, e) => {
            let (st, cp2) = cpp_statements_cp(cp, dos);
            crate::emit::cpp::templates::stmt_expr(&st, &unvexed(&cpp_expr(&cp2, &**e)))
        },
        crate::lower::model::Ex::XLabeled(label, dos, e, t) => cpp_labeled(cp, label, dos, &**e, t),
        crate::lower::model::Ex::XClosure(mv, ps, body) => cpp_closure(cp, mv, ps, &**body),
        crate::lower::model::Ex::XTry(y) => Text::from(format!("TRY({})", &cpp_expr(cp, &**y))),
        crate::lower::model::Ex::XField(r, f) => cpp_field(cp, &**r, f),
        crate::lower::model::Ex::XPart(r, k) => Text::from(format!("std::get<{}>({})", k, &cpp_expr(cp, &**r))),
        crate::lower::model::Ex::XDecode(t, y) => Text::from(format!("TRY(prism_rtl::from_pod<{}>({}))", &cpp_type(cp, t), &cpp_expr(cp, &**y))),
        crate::lower::model::Ex::XCast(y, t) => Text::from(format!("static_cast<{}>({})", &cpp_type(cp, t), &cpp_expr(cp, &**y))),
        crate::lower::model::Ex::XTyped(y, t) => {
            let e = cpp_expr(cp, &**y);
            if (&e == &Text::lit("{}")) || (&e == &Text::lit("std::nullopt")) {
                Text::from(format!("{}{{}}", &cpp_type(cp, t)))
            } else {
                if is_ctor(&**y, &Text::lit("Ok")) || is_ctor(&**y, &Text::lit("Err")) {
                    Text::from(format!("{}({})", &cpp_type(cp, t), &e))
                } else {
                    e.clone()
                }
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CppExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppExpr: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppExpr {
    pub cp: Cp,
    pub x: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppExpr {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let x = &self.x;
        match x {
            crate::lower::model::Ex::XVar(n) => prism_rtl::Turn::Finished(var_name(cp, n)),
            crate::lower::model::Ex::XPath(p_) => prism_rtl::Turn::Finished(path_value(cp, p_)),
            crate::lower::model::Ex::XSelf => prism_rtl::Turn::Finished(Text::lit("prism_rtl::share(this)")),
            crate::lower::model::Ex::XCx => prism_rtl::Turn::Finished(Text::lit("cx")),
            crate::lower::model::Ex::XConst(n) => prism_rtl::Turn::Finished(n.clone()),
            crate::lower::model::Ex::XUnit => prism_rtl::Turn::Finished(Text::lit("Unit{}")),
            crate::lower::model::Ex::XNone => prism_rtl::Turn::Finished(Text::lit("std::nullopt")),
            crate::lower::model::Ex::XBool(b) => if *b {
                prism_rtl::Turn::Finished(Text::lit("true"))
            } else {
                prism_rtl::Turn::Finished(Text::lit("false"))
            },
            crate::lower::model::Ex::XNat(d) => if &len_text(d) <= &Nat::from(9u32) {
                prism_rtl::Turn::Finished(Text::from(format!("Nat({}u)", d)))
            } else {
                {
                    let cp = cp.clone();
                    let d = d.clone();
                    call_then(start_cpp_expr(cp.clone(), crate::lower::model::Ex::XInt(d.clone())), move |cpp_expr_16013: Text| prism_rtl::Turn::Finished(Text::from(format!("*Nat::from_int({})", &cpp_expr_16013))))
                }
            },
            crate::lower::model::Ex::XInt(d) => if &len_text(&(if crate::syntax::lexer::has_prefix(d, &Text::lit("-")) {
                crate::syntax::lexer::after_first(d)
            } else {
                d.clone()
            })) <= &Nat::from(18u32) {
                prism_rtl::Turn::Finished(Text::from(format!("Int({}ll)", d)))
            } else {
                prism_rtl::Turn::Finished(Text::from(format!("*Int::parse(\"{}\")", d)))
            },
            crate::lower::model::Ex::XByte(d) => prism_rtl::Turn::Finished(Text::from(format!("std::uint8_t({})", d))),
            crate::lower::model::Ex::XFloat(d) => prism_rtl::Turn::Finished(d.clone()),
            crate::lower::model::Ex::XIndex(n) => prism_rtl::Turn::Finished(Text::from(format!("{}u", n))),
            crate::lower::model::Ex::XChar(c) => prism_rtl::Turn::Finished(Text::from(format!("U'{}'", &cpp_char_escape(c)))),
            crate::lower::model::Ex::XStr(t) => prism_rtl::Turn::Finished(cpp_string(t)),
            crate::lower::model::Ex::XRef(y) => prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: (**y).clone() })),
            crate::lower::model::Ex::XRefMut(y) => prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: (**y).clone() })),
            crate::lower::model::Ex::XDeref(y) => prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: (**y).clone() })),
            crate::lower::model::Ex::XTarget(y) => prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: (**y).clone() })),
            crate::lower::model::Ex::XClone(y) => prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: (**y).clone() })),
            crate::lower::model::Ex::XWeak(y) => {
                let cp = cp.clone();
                let y = (**y).clone();
                call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_16456: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::weaken({})", &cpp_expr_16456))))
            },
            crate::lower::model::Ex::XUpgrade(y) => {
                let cp = cp.clone();
                let y = (**y).clone();
                call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_16510: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::upgrade({})", &cpp_expr_16510))))
            },
            crate::lower::model::Ex::XBreak(l, y) => {
                let cp = cp.clone();
                let l = l.clone();
                let y = (**y).clone();
                call_then(start_cpp_break(cp.clone(), l.clone(), y.clone()), move |cpp_break_16547: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &cpp_break_16547))))
            },
            crate::lower::model::Ex::XBreakLoop => prism_rtl::Turn::Finished(Text::lit("({ break; })")),
            crate::lower::model::Ex::XLater(y) => {
                let cp = cp.clone();
                let y = (**y).clone();
                call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_16640: Text| prism_rtl::Turn::Finished(Text::from(format!("[=](Cx& cx) -> Done {{ {}; return {{}}; }}", &cpp_expr_16640))))
            },
            crate::lower::model::Ex::XFormatStr(parts) => prism_rtl::Turn::More(Rc::new(CppFormat { cp: cp.clone(), parts: parts.clone(), how: Text::lit("prism_rtl::str") })),
            crate::lower::model::Ex::XIsCase(y, m15731_26_1) if (m15731_26_1.len() == 0) => prism_rtl::Turn::Finished(Text::lit("false")),
            crate::lower::model::Ex::XIsCase(y, cs) => {
                let cp = cp.clone();
                let cs = cs.clone();
                let y = (**y).clone();
                call_value(each_job(cs.clone(), {
                    let cp = cp.clone();
                    let y = y.clone();
                    Rc::new(move |p0: Text| {
                        let cp = cp.clone();
                        let y = y.clone();
                        entered(once_job(move || {
                            let c = p0;
                            call_then(start_cpp_tight(cp.clone(), y.clone()), move |cpp_tight_16821: Text| prism_rtl::Turn::Finished(case_test(&cp, &c, &cpp_tight_16821)))
                        }))
                    }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_16790: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("({})", &crate::syntax::lexer::join(&each_16790, &Text::lit(" || "))))))
            },
            crate::lower::model::Ex::XRefusal(what) => prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::lowering_refusal(), &crate::lower::escape(what)))),
            crate::lower::model::Ex::XUnreachable => prism_rtl::Turn::Finished(Text::lit("throw prism_rtl::Panic(\"entered unreachable code\")")),
            crate::lower::model::Ex::XCall(f, args) => prism_rtl::Turn::More(Rc::new(CppCall { cp: cp.clone(), f: f.clone(), args: args.clone() })),
            crate::lower::model::Ex::XApply(f, args) => {
                let args = args.clone();
                let cp = cp.clone();
                let f = (**f).clone();
                call_then(start_cpp_tight(cp.clone(), f.clone()), move |cpp_tight_17055: Text| call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_17072: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &cpp_tight_17055, &cpp_args_17072)))))
            },
            crate::lower::model::Ex::XMethod(r, m, args) => prism_rtl::Turn::More(Rc::new(CppMethod { cp: cp.clone(), r: (**r).clone(), m: m.clone(), args: args.clone() })),
            crate::lower::model::Ex::XBin(op, l, r) => {
                let cp = cp.clone();
                let l = (**l).clone();
                let op = op.clone();
                let r = (**r).clone();
                call_then(start_cpp_tight(cp.clone(), l.clone()), move |cpp_tight_17162: Text| call_then(start_cpp_tight(cp.clone(), r.clone()), move |cpp_tight_17184: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {} {}", &cpp_tight_17162, &op, &cpp_tight_17184)))))
            },
            crate::lower::model::Ex::XUnary(op, y) => {
                let cp = cp.clone();
                let op = op.clone();
                let y = (**y).clone();
                call_then(start_cpp_tight(cp.clone(), y.clone()), move |cpp_tight_17225: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &op, &cpp_tight_17225))))
            },
            crate::lower::model::Ex::XCtor(p_, args) => prism_rtl::Turn::More(Rc::new(CppCtor { cp: cp.clone(), p_: p_.clone(), args: args.clone() })),
            crate::lower::model::Ex::XRecord(p_, fs) => prism_rtl::Turn::More(Rc::new(CppRecord { cp: cp.clone(), p_: p_.clone(), fs: fs.clone() })),
            crate::lower::model::Ex::XTuple(xs) => {
                let cp = cp.clone();
                let xs = xs.clone();
                call_then(start_cpp_args(cp.clone(), xs.clone()), move |cpp_args_17349: Text| prism_rtl::Turn::Finished(Text::from(format!("std::tuple{{{}}}", &cpp_args_17349))))
            },
            crate::lower::model::Ex::XVec(m15731_38_0) if (m15731_38_0.len() == 0) => prism_rtl::Turn::Finished(Text::lit("{}")),
            crate::lower::model::Ex::XVec(xs) => {
                let cp = cp.clone();
                let xs = xs.clone();
                call_then(start_cpp_args(cp.clone(), xs.clone()), move |cpp_args_17418: Text| prism_rtl::Turn::Finished(Text::from(format!("std::vector{{{}}}", &cpp_args_17418))))
            },
            crate::lower::model::Ex::XText(t) => prism_rtl::Turn::Finished(Text::from(format!("Text::lit({})", &cpp_string(t)))),
            crate::lower::model::Ex::XFormat(parts) => if fold(parts, &true, &(|f: &bool, p_: &crate::lower::model::Ex| *f && is_text_piece(p_))) {
                prism_rtl::Turn::Finished(Text::from(format!("Text::lit({})", &cpp_string(&concat(&each(parts, &(|p_: &crate::lower::model::Ex| text_piece(p_))))))))
            } else {
                prism_rtl::Turn::More(Rc::new(CppFormat { cp: cp.clone(), parts: parts.clone(), how: Text::lit("prism_rtl::cat") }))
            },
            crate::lower::model::Ex::XMatch(s, arms, fallback, t) => prism_rtl::Turn::More(Rc::new(CppMatch { cp: cp.clone(), s: (**s).clone(), arms: arms.clone(), out_ty3: t.clone() })),
            crate::lower::model::Ex::XChain(label, s, arms, t) => prism_rtl::Turn::More(Rc::new(CppMatch { cp: cp.clone(), s: (**s).clone(), arms: arms.clone(), out_ty3: t.clone() })),
            crate::lower::model::Ex::XIf(c, t, e) => prism_rtl::Turn::More(Rc::new(CppIf { cp: cp.clone(), c: (**c).clone(), t: (**t).clone(), e: (**e).clone() })),
            crate::lower::model::Ex::XBlock(m15731_45_0, e) if (m15731_45_0.len() == 0) => prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: (**e).clone() })),
            crate::lower::model::Ex::XBlock(dos, e) => {
                let cp = cp.clone();
                let dos = dos.clone();
                let e = (**e).clone();
                call_then(start_cpp_statements_cp(cp.clone(), dos.clone()), move |cpp_statements_cp_17880: (Text, Cp)| {
                    let (st, cp2) = cpp_statements_cp_17880;
                    call_then(start_cpp_expr(cp2.clone(), e.clone()), move |cpp_expr_17935: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::stmt_expr(&st, &unvexed(&cpp_expr_17935))))
                })
            },
            crate::lower::model::Ex::XLabeled(label, dos, e, t) => prism_rtl::Turn::More(Rc::new(CppLabeled { cp: cp.clone(), label: label.clone(), dos: dos.clone(), e: (**e).clone(), t: t.clone() })),
            crate::lower::model::Ex::XClosure(mv, ps, body) => prism_rtl::Turn::More(Rc::new(CppClosure { cp0: cp.clone(), mv: *mv, ps: ps.clone(), body: (**body).clone() })),
            crate::lower::model::Ex::XTry(y) => {
                let cp = cp.clone();
                let y = (**y).clone();
                call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_18088: Text| prism_rtl::Turn::Finished(Text::from(format!("TRY({})", &cpp_expr_18088))))
            },
            crate::lower::model::Ex::XField(r, f) => prism_rtl::Turn::More(Rc::new(CppField { cp: cp.clone(), ex1: (**r).clone(), f: f.clone() })),
            crate::lower::model::Ex::XPart(r, k) => {
                let cp = cp.clone();
                let k = k.clone();
                let r = (**r).clone();
                call_then(start_cpp_expr(cp.clone(), r.clone()), move |cpp_expr_18172: Text| prism_rtl::Turn::Finished(Text::from(format!("std::get<{}>({})", &k, &cpp_expr_18172))))
            },
            crate::lower::model::Ex::XDecode(t, y) => {
                let cp = cp.clone();
                let t = t.clone();
                let y = (**y).clone();
                call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_18233: Text| call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_18250: Text| prism_rtl::Turn::Finished(Text::from(format!("TRY(prism_rtl::from_pod<{}>({}))", &cpp_type_18233, &cpp_expr_18250)))))
            },
            crate::lower::model::Ex::XCast(y, t) => {
                let cp = cp.clone();
                let t = t.clone();
                let y = (**y).clone();
                call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_18298: Text| call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_18315: Text| prism_rtl::Turn::Finished(Text::from(format!("static_cast<{}>({})", &cpp_type_18298, &cpp_expr_18315)))))
            },
            crate::lower::model::Ex::XTyped(y, t) => {
                let cp = cp.clone();
                let t = t.clone();
                let y = (**y).clone();
                call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_18365: Text| {
                    let e = cpp_expr_18365;
                    if (&e == &Text::lit("{}")) || (&e == &Text::lit("std::nullopt")) {
                        call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_18428: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{{}}", &cpp_type_18428))))
                    } else {
                        if is_ctor(&y, &Text::lit("Ok")) || is_ctor(&y, &Text::lit("Err")) {
                            call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_18504: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &cpp_type_18504, &e))))
                        } else {
                            prism_rtl::Turn::Finished(e.clone())
                        }
                    }
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start CppExpr, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_expr(cp: Cp, x: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppExpr { cp, x })
}

/// ```prism
/// CppString: fn Text -> Text
/// ```
pub fn cpp_string(t: &Text) -> Text {
    if crate::syntax::lexer::contains(t, &Text::lit("\0")) {
        Text::from(format!("\"{}\"sv", &cpp_escape(t)))
    } else {
        Text::from(format!("\"{}\"", &cpp_escape(t)))
    }
}

/// ```prism
/// CppEscape: fn Text -> Text
/// ```
pub fn cpp_escape(t: &Text) -> Text {
    crate::syntax::lexer::map_chars(t, &(Rc::new(move |p0: Text| once_job(move || {
        let c = p0;
        if &c == &Text::lit("\0") {
            prism_rtl::Turn::Finished(Text::lit("\\000"))
        } else {
            prism_rtl::Turn::Finished(crate::lower::char_escape(&c))
        }
    })) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>))
}

/// ```prism
/// IsTextPiece: fn Ex -> Bool
/// ```
pub fn is_text_piece(ex0: &crate::lower::model::Ex) -> bool {
    match ex0 {
        crate::lower::model::Ex::XText(_) => true,
        other => false,
    }
}

/// ```prism
/// TextPiece: fn Ex -> Text
/// ```
pub fn text_piece(ex0: &crate::lower::model::Ex) -> Text {
    match ex0 {
        crate::lower::model::Ex::XText(t) => t.clone(),
        other => Text::lit(""),
    }
}

/// ```prism
/// CppFormat: unbounded fn Cp, [Ex], Text -> Text
/// ```
pub fn cpp_format(cp: &Cp, parts: &Array<crate::lower::model::Ex>, how: &Text) -> Text {
    Text::from(format!("{}({})", how, &crate::syntax::lexer::join(&run_to_end(each_job(parts.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::Ex| {
            let cp = cp.clone();
            entered(once_job(move || {
                let p_ = p0;
                prism_rtl::Turn::More(Rc::new(FormatArg { cp: cp.clone(), ex1: p_.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "))))
}

/// The step machine of `CppFormat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppFormat: unbounded fn Cp, [Ex], Text -> Text
/// ```
pub struct CppFormat {
    pub cp: Cp,
    pub parts: Array<crate::lower::model::Ex>,
    pub how: Text,
}

impl prism_rtl::Job<Text> for CppFormat {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let parts = &self.parts;
        let how = &self.how;
        let cp = cp.clone();
        let how = how.clone();
        let parts = parts.clone();
        call_value(each_job(parts.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: crate::lower::model::Ex| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let p_ = p0;
                    prism_rtl::Turn::More(Rc::new(FormatArg { cp: cp.clone(), ex1: p_.clone() }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_19296: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &how, &crate::syntax::lexer::join(&each_19296, &Text::lit(", "))))))
    }
}

/// `Start CppFormat, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_format(cp: Cp, parts: Array<crate::lower::model::Ex>, how: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppFormat { cp, parts, how })
}

/// ```prism
/// FormatArg: unbounded fn Cp, Ex -> Text
/// ```
pub fn format_arg(cp: &Cp, ex1: &crate::lower::model::Ex) -> Text {
    match ex1 {
        crate::lower::model::Ex::XText(t) => cpp_string(t),
        x => cpp_expr(cp, x),
    }
}

/// The step machine of `FormatArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FormatArg: unbounded fn Cp, Ex -> Text
/// ```
pub struct FormatArg {
    pub cp: Cp,
    pub ex1: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for FormatArg {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let ex1 = &self.ex1;
        match ex1 {
            crate::lower::model::Ex::XText(t) => prism_rtl::Turn::Finished(cpp_string(t)),
            x => prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: x.clone() })),
        }
    }
}

/// `Start FormatArg, x`: what the function value is when passed to `@Run`.
pub fn start_format_arg(cp: Cp, ex1: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FormatArg { cp, ex1 })
}

/// ```prism
/// CppCharEscape: fn Text -> Text
/// ```
pub fn cpp_char_escape(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("'")) => Text::lit("\\'"),
        c => crate::lower::char_escape(c),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// PathValue: fn Cp, Text -> Text
/// ```
pub fn path_value(cp: &Cp, p_: &Text) -> Text {
    if is_node_method(cp, p_) {
        Text::from(format!("&{}::{}", &type_path(&parent_path(p_)), &node_method_name(cp, &last_segment(p_))))
    } else {
        match case_of(cp, p_) {
            Some(ty) => Text::from(format!("{}({}{{}})", &type_path(&ty), &type_path(p_))),
            None => match type_of(cp, p_) {
                Some(info) => if &info.kind == &Text::lit("unit") {
                    Text::from(format!("{}{{}}", &type_path(p_)))
                } else {
                    type_path(p_)
                },
                None => type_path(p_),
            },
        }
    }
}

/// ```prism
/// IsNodeMethod: fn Cp, Text -> Bool
/// ```
pub fn is_node_method(cp: &Cp, p_: &Text) -> bool {
    let named = match get(&cp.methods, &last_segment(p_)) {
        Some(_) => true,
        None => false,
    };
    named && is_node_type(cp, &parent_path(p_))
}

/// ```prism
/// IsNodeType: fn Cp, Text -> Bool
/// ```
pub fn is_node_type(cp: &Cp, p_: &Text) -> bool {
    match type_of(cp, p_) {
        Some(info) => &info.kind == &Text::lit("node"),
        None => false,
    }
}

/// ```prism
/// CppField: unbounded fn Cp, Ex, Text -> Text
/// ```
pub fn cpp_field(cp: &Cp, ex1: &crate::lower::model::Ex, f: &Text) -> Text {
    match ex1 {
        crate::lower::model::Ex::XSelf => Text::from(format!("this->{}", &field_id(f))),
        r => {
            let name = if is_digits(f) { Text::from(format!("a{}", f)) } else { field_id(f) };
            let through = match pointer(cp, r) {
                Some(b) => if b { Text::lit("->") } else { Text::lit(".") },
                None => match get(&cp.members, f) {
                    Some(_) => Text::lit("->"),
                    None => Text::lit("."),
                },
            };
            Text::from(format!("{}{}{}", &cpp_tight(cp, r), &through, &name))
        },
    }
}

/// The step machine of `CppField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppField: unbounded fn Cp, Ex, Text -> Text
/// ```
pub struct CppField {
    pub cp: Cp,
    pub ex1: crate::lower::model::Ex,
    pub f: Text,
}

impl prism_rtl::Job<Text> for CppField {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let ex1 = &self.ex1;
        let f = &self.f;
        match ex1 {
            crate::lower::model::Ex::XSelf => prism_rtl::Turn::Finished(Text::from(format!("this->{}", &field_id(f)))),
            r => {
                let name = if is_digits(f) { Text::from(format!("a{}", f)) } else { field_id(f) };
                let through = match pointer(cp, r) {
                    Some(b) => if b { Text::lit("->") } else { Text::lit(".") },
                    None => match get(&cp.members, f) {
                        Some(_) => Text::lit("->"),
                        None => Text::lit("."),
                    },
                };
                let cp = cp.clone();
                let r = r.clone();
                call_then(start_cpp_tight(cp.clone(), r.clone()), move |cpp_tight_20895: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}{}", &cpp_tight_20895, &through, &name))))
            },
        }
    }
}

/// `Start CppField, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_field(cp: Cp, ex1: crate::lower::model::Ex, f: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppField { cp, ex1, f })
}

/// ```prism
/// IsDigits: fn Text -> Bool
/// ```
pub fn is_digits(t: &Text) -> bool {
    (t != &Text::lit("")) && crate::syntax::lexer::fold_chars(t, &true, &(Rc::new(move |(p0, p1): (bool, Text)| once_job(move || {
        let ok = p0;
        let c = p1;
        prism_rtl::Turn::Finished(ok && crate::syntax::lexer::contains(&Text::lit("0123456789"), &c))
    })) as Rc<dyn Fn((bool, Text)) -> Rc<dyn prism_rtl::Job<bool>>>))
}

/// ```prism
/// CppCtor: unbounded fn Cp, Text, [Ex] -> Text
/// ```
pub fn cpp_ctor(cp: &Cp, p_: &Text, args: &Array<crate::lower::model::Ex>) -> Text {
    match p_ {
        m21245_0 if (m21245_0 == &Text::lit("Some")) => Text::from(format!("std::optional({})", &cpp_args(cp, args))),
        m21245_1 if (m21245_1 == &Text::lit("Ok")) => if args == &Array::from(vec![crate::lower::model::Ex::XUnit]) {
            Text::lit("prism_rtl::ok()")
        } else {
            cpp_args(cp, args)
        },
        m21245_2 if (m21245_2 == &Text::lit("Err")) => Text::from(format!("unexpected({})", &cpp_args(cp, args))),
        m21245_3 if (m21245_3 == &Text::lit("prism_rtl::Turn::More")) => Text::from(format!("prism_rtl::more({})", &cpp_args(cp, args))),
        m21245_4 if (m21245_4 == &Text::lit("prism_rtl::Turn::Finished")) => Text::from(format!("prism_rtl::finished({})", &cpp_args(cp, args))),
        m21245_5 if (m21245_5 == &Text::lit("Outcome::Fired")) => Text::from(format!("Outcome::fired({})", &cpp_args(cp, args))),
        m21245_6 if (m21245_6 == &Text::lit("Outcome::Value")) => Text::from(format!("Outcome::value({})", &cpp_args(cp, args))),
        m21245_7 if (m21245_7 == &Text::lit("Segment::Pos")) => Text::from(format!("Segment::pos({})", &cpp_args(cp, args))),
        m21245_8 if (m21245_8 == &Text::lit("Segment::Gen")) => Text::from(format!("Segment::gen({})", &cpp_args(cp, args))),
        m21245_9 if (m21245_9 == &Text::lit("Segment::Key")) => Text::from(format!("Segment::key({})", &cpp_args(cp, args))),
        _ => match case_of(cp, p_) {
            Some(ty) => Text::from(format!("{}({}{{{}}})", &type_path(&ty), &type_path(p_), &cpp_args(cp, args))),
            None => Text::from(format!("{}{{{}}}", &type_path(p_), &cpp_args(cp, args))),
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CppCtor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppCtor: unbounded fn Cp, Text, [Ex] -> Text
/// ```
pub struct CppCtor {
    pub cp: Cp,
    pub p_: Text,
    pub args: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for CppCtor {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let p_ = &self.p_;
        let args = &self.args;
        match p_ {
            m21245_0 if (m21245_0 == &Text::lit("Some")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_21282: Text| prism_rtl::Turn::Finished(Text::from(format!("std::optional({})", &cpp_args_21282))))
            },
            m21245_1 if (m21245_1 == &Text::lit("Ok")) => if args == &Array::from(vec![crate::lower::model::Ex::XUnit]) {
                prism_rtl::Turn::Finished(Text::lit("prism_rtl::ok()"))
            } else {
                prism_rtl::Turn::More(Rc::new(CppArgs { cp: cp.clone(), xs: args.clone() }))
            },
            m21245_2 if (m21245_2 == &Text::lit("Err")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_21399: Text| prism_rtl::Turn::Finished(Text::from(format!("unexpected({})", &cpp_args_21399))))
            },
            m21245_3 if (m21245_3 == &Text::lit("prism_rtl::Turn::More")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_21466: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::more({})", &cpp_args_21466))))
            },
            m21245_4 if (m21245_4 == &Text::lit("prism_rtl::Turn::Finished")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_21541: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::finished({})", &cpp_args_21541))))
            },
            m21245_5 if (m21245_5 == &Text::lit("Outcome::Fired")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_21600: Text| prism_rtl::Turn::Finished(Text::from(format!("Outcome::fired({})", &cpp_args_21600))))
            },
            m21245_6 if (m21245_6 == &Text::lit("Outcome::Value")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_21659: Text| prism_rtl::Turn::Finished(Text::from(format!("Outcome::value({})", &cpp_args_21659))))
            },
            m21245_7 if (m21245_7 == &Text::lit("Segment::Pos")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_21714: Text| prism_rtl::Turn::Finished(Text::from(format!("Segment::pos({})", &cpp_args_21714))))
            },
            m21245_8 if (m21245_8 == &Text::lit("Segment::Gen")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_21769: Text| prism_rtl::Turn::Finished(Text::from(format!("Segment::gen({})", &cpp_args_21769))))
            },
            m21245_9 if (m21245_9 == &Text::lit("Segment::Key")) => {
                let args = args.clone();
                let cp = cp.clone();
                call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_21824: Text| prism_rtl::Turn::Finished(Text::from(format!("Segment::key({})", &cpp_args_21824))))
            },
            _ => match case_of(cp, p_) {
                Some(ty) => {
                    let args = args.clone();
                    let cp = cp.clone();
                    let p_ = p_.clone();
                    call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_21924: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({}{{{}}})", &type_path(&ty), &type_path(&p_), &cpp_args_21924))))
                },
                None => {
                    let args = args.clone();
                    let cp = cp.clone();
                    let p_ = p_.clone();
                    call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_21975: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{{{}}}", &type_path(&p_), &cpp_args_21975))))
                },
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start CppCtor, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_ctor(cp: Cp, p_: Text, args: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppCtor { cp, p_, args })
}

/// ```prism
/// CppRecord: unbounded fn Cp, Text, [((Text, Ex))] -> Text
/// ```
pub fn cpp_record(cp: &Cp, p_: &Text, fs: &Array<(Text, crate::lower::model::Ex)>) -> Text {
    let ordered = match type_of(cp, p_) {
        Some(info) => each(&info.fields, &(|f: &Text| or(&fold(fs, &None, &(|found_opt: &Option<crate::lower::model::Ex>, (g, v_): &(Text, crate::lower::model::Ex)| if g == f { Some(v_.clone()) } else { found_opt.clone() })), &crate::lower::model::Ex::XUnit))),
        None => each(fs, &(|(_, v_): &(Text, crate::lower::model::Ex)| v_.clone())),
    };
    let names = match type_of(cp, p_) {
        Some(info) => info.fields.clone(),
        None => each(fs, &(|(g, _): &(Text, crate::lower::model::Ex)| g.clone())),
    };
    let kind = match type_of(cp, p_) {
        Some(info) => info.kind.clone(),
        None => Text::lit(""),
    };
    if &kind == &Text::lit("job") {
        Text::from(format!("{}({})", &type_path(p_), &cpp_args(cp, &ordered)))
    } else {
        Text::from(format!("{}{{{}}}", &type_path(p_), &crate::syntax::lexer::join(&run_to_end(each_job(crate::check::errors::range0(&len(&names)), {
            let names = names.clone();
            let cp = cp.clone();
            let ordered = ordered.clone();
            Rc::new(move |p0: Nat| {
                let names = names.clone();
                let cp = cp.clone();
                let ordered = ordered.clone();
                entered(once_job(move || {
                    let i = p0;
                    call_then(start_cpp_expr(cp.clone(), or(&index(&ordered, &i), &crate::lower::model::Ex::XUnit)), move |cpp_expr_22714: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = {}", &field_id(&or(&index(&names, &i), &Text::lit(""))), &cpp_expr_22714))))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
        })), &Text::lit(", "))))
    }
}

/// The step machine of `CppRecord`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppRecord: unbounded fn Cp, Text, [((Text, Ex))] -> Text
/// ```
pub struct CppRecord {
    pub cp: Cp,
    pub p_: Text,
    pub fs: Array<(Text, crate::lower::model::Ex)>,
}

impl prism_rtl::Job<Text> for CppRecord {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let p_ = &self.p_;
        let fs = &self.fs;
        let ordered = match type_of(cp, p_) {
            Some(info) => each(&info.fields, &(|f: &Text| or(&fold(fs, &None, &(|found_opt: &Option<crate::lower::model::Ex>, (g, v_): &(Text, crate::lower::model::Ex)| if g == f { Some(v_.clone()) } else { found_opt.clone() })), &crate::lower::model::Ex::XUnit))),
            None => each(fs, &(|(_, v_): &(Text, crate::lower::model::Ex)| v_.clone())),
        };
        let names = match type_of(cp, p_) {
            Some(info) => info.fields.clone(),
            None => each(fs, &(|(g, _): &(Text, crate::lower::model::Ex)| g.clone())),
        };
        let kind = match type_of(cp, p_) {
            Some(info) => info.kind.clone(),
            None => Text::lit(""),
        };
        if &kind == &Text::lit("job") {
            {
                let cp = cp.clone();
                let p_ = p_.clone();
                call_then(start_cpp_args(cp.clone(), ordered.clone()), move |cpp_args_22594: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &type_path(&p_), &cpp_args_22594))))
            }
        } else {
            {
                let cp = cp.clone();
                let p_ = p_.clone();
                call_value(each_job(crate::check::errors::range0(&len(&names)), {
                    let names = names.clone();
                    let cp = cp.clone();
                    let ordered = ordered.clone();
                    Rc::new(move |p0: Nat| {
                        let names = names.clone();
                        let cp = cp.clone();
                        let ordered = ordered.clone();
                        entered(once_job(move || {
                            let i = p0;
                            call_then(start_cpp_expr(cp.clone(), or(&index(&ordered, &i), &crate::lower::model::Ex::XUnit)), move |cpp_expr_22714: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = {}", &field_id(&or(&index(&names, &i), &Text::lit(""))), &cpp_expr_22714))))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_22649: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{}{{{}}}", &type_path(&p_), &crate::syntax::lexer::join(&each_22649, &Text::lit(", "))))))
            }
        }
    }
}

/// `Start CppRecord, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_record(cp: Cp, p_: Text, fs: Array<(Text, crate::lower::model::Ex)>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppRecord { cp, p_, fs })
}

/// ```prism
/// CppCall: unbounded fn Cp, Text, [Ex] -> Text
/// ```
pub fn cpp_call(cp: &Cp, f: &Text, args: &Array<crate::lower::model::Ex>) -> Text {
    let a = cpp_args(cp, args);
    match f {
        m22999_0 if (m22999_0 == &Text::lit("Rc::new")) => if &a == &Text::lit("{}") {
            Text::lit("prism_rtl::make_new()")
        } else {
            Text::from(format!("prism_rtl::rc({})", &a))
        },
        m22999_1 if (m22999_1 == &Text::lit("is_some")) => Text::from(format!("prism_rtl::is_some({})", &a)),
        m22999_2 if (m22999_2 == &Text::lit("is_none")) => Text::from(format!("prism_rtl::is_none({})", &a)),
        m22999_3 if (m22999_3 == &Text::lit("RefCell::new")) => a.clone(),
        m22999_4 if (m22999_4 == &Text::lit("Cell::new")) => a.clone(),
        m22999_5 if (m22999_5 == &Text::lit("Hold::new")) => Text::from(format!("{{{}}}", &a)),
        m22999_6 if (m22999_6 == &Text::lit("Snapshot::new")) => Text::from(format!("snapshot({})", &a)),
        m22999_7 if (m22999_7 == &Text::lit("Path::root")) => Text::lit("Path::root()"),
        m22999_8 if (m22999_8 == &Text::lit("Fault::answer")) => Text::from(format!("Fault::answer({})", &a)),
        m22999_9 if (m22999_9 == &Text::lit("Error::new")) => Text::from(format!("Error({})", &a)),
        m22999_10 if (m22999_10 == &Text::lit("Text::from")) => Text::from(format!("Text({})", &a)),
        m22999_11 if (m22999_11 == &Text::lit("String::new")) => Text::lit("std::string()"),
        m22999_12 if (m22999_12 == &Text::lit("Array::from")) => Text::from(format!("Array({})", &a)),
        m22999_13 if (m22999_13 == &Text::lit("prism_rtl::Dynamic::of")) => Text::from(format!("dynamic_of({})", &a)),
        m22999_14 if (m22999_14 == &Text::lit("Dynamic::of")) => Text::from(format!("dynamic_of({})", &a)),
        m22999_15 if (m22999_15 == &Text::lit("prism_rtl::Event::of")) => Text::from(format!("event_of({})", &a)),
        m22999_16 if (m22999_16 == &Text::lit("prism_rtl::Host::new")) => Text::from(format!("host_new({})", &a)),
        m22999_17 if (m22999_17 == &Text::lit("prism_rtl::forward_on_none")) => Text::from(format!("prism_rtl::forward_on_none<crate::Elem, crate::Answer>({})", &a)),
        m22999_18 if (m22999_18 == &Text::lit("Event::never")) => Text::lit("never_event()"),
        _ => if is_fresh(f) {
            Text::lit("{}")
        } else {
            Text::from(format!("{}({})", &free_call_path(cp, f), &a))
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CppCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppCall: unbounded fn Cp, Text, [Ex] -> Text
/// ```
pub struct CppCall {
    pub cp: Cp,
    pub f: Text,
    pub args: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for CppCall {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let f = &self.f;
        let args = &self.args;
        let args = args.clone();
        let cp = cp.clone();
        let f = f.clone();
        call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_22978: Text| {
            let a = cpp_args_22978;
            match &f {
                m22999_0 if (m22999_0 == &Text::lit("Rc::new")) => if &a == &Text::lit("{}") {
                    prism_rtl::Turn::Finished(Text::lit("prism_rtl::make_new()"))
                } else {
                    prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::rc({})", &a)))
                },
                m22999_1 if (m22999_1 == &Text::lit("is_some")) => prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::is_some({})", &a))),
                m22999_2 if (m22999_2 == &Text::lit("is_none")) => prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::is_none({})", &a))),
                m22999_3 if (m22999_3 == &Text::lit("RefCell::new")) => prism_rtl::Turn::Finished(a.clone()),
                m22999_4 if (m22999_4 == &Text::lit("Cell::new")) => prism_rtl::Turn::Finished(a.clone()),
                m22999_5 if (m22999_5 == &Text::lit("Hold::new")) => prism_rtl::Turn::Finished(Text::from(format!("{{{}}}", &a))),
                m22999_6 if (m22999_6 == &Text::lit("Snapshot::new")) => prism_rtl::Turn::Finished(Text::from(format!("snapshot({})", &a))),
                m22999_7 if (m22999_7 == &Text::lit("Path::root")) => prism_rtl::Turn::Finished(Text::lit("Path::root()")),
                m22999_8 if (m22999_8 == &Text::lit("Fault::answer")) => prism_rtl::Turn::Finished(Text::from(format!("Fault::answer({})", &a))),
                m22999_9 if (m22999_9 == &Text::lit("Error::new")) => prism_rtl::Turn::Finished(Text::from(format!("Error({})", &a))),
                m22999_10 if (m22999_10 == &Text::lit("Text::from")) => prism_rtl::Turn::Finished(Text::from(format!("Text({})", &a))),
                m22999_11 if (m22999_11 == &Text::lit("String::new")) => prism_rtl::Turn::Finished(Text::lit("std::string()")),
                m22999_12 if (m22999_12 == &Text::lit("Array::from")) => prism_rtl::Turn::Finished(Text::from(format!("Array({})", &a))),
                m22999_13 if (m22999_13 == &Text::lit("prism_rtl::Dynamic::of")) => prism_rtl::Turn::Finished(Text::from(format!("dynamic_of({})", &a))),
                m22999_14 if (m22999_14 == &Text::lit("Dynamic::of")) => prism_rtl::Turn::Finished(Text::from(format!("dynamic_of({})", &a))),
                m22999_15 if (m22999_15 == &Text::lit("prism_rtl::Event::of")) => prism_rtl::Turn::Finished(Text::from(format!("event_of({})", &a))),
                m22999_16 if (m22999_16 == &Text::lit("prism_rtl::Host::new")) => prism_rtl::Turn::Finished(Text::from(format!("host_new({})", &a))),
                m22999_17 if (m22999_17 == &Text::lit("prism_rtl::forward_on_none")) => prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::forward_on_none<crate::Elem, crate::Answer>({})", &a))),
                m22999_18 if (m22999_18 == &Text::lit("Event::never")) => prism_rtl::Turn::Finished(Text::lit("never_event()")),
                _ => if is_fresh(&f) {
                    prism_rtl::Turn::Finished(Text::lit("{}"))
                } else {
                    prism_rtl::Turn::Finished(Text::from(format!("{}({})", &free_call_path(&cp, &f), &a)))
                },
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start CppCall, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_call(cp: Cp, f: Text, args: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppCall { cp, f, args })
}

/// ```prism
/// FreeCallPath: fn Cp, Text -> Text
/// ```
pub fn free_call_path(cp: &Cp, f: &Text) -> Text {
    let p_ = call_path(f);
    let hidden = match get(&cp.members, f) {
        Some(_) => true,
        None => in_list(&std_names(), &p_) || in_list(&cp.mods, &p_),
    };
    if crate::syntax::lexer::contains(&p_, &Text::lit(":")) {
        p_.clone()
    } else {
        if hidden { qualified_call(cp, f, &p_) } else { p_.clone() }
    }
}

/// ```prism
/// QualifiedCall: fn Cp, Text, Text -> Text
/// ```
pub fn qualified_call(cp: &Cp, f: &Text, p_: &Text) -> Text {
    match get(&cp.fns, &Text::from(format!("{}::{}", &cp.home, f))) {
        Some(_) => Text::from(format!("crate::{}::{}", &cp.home, p_)),
        None => Text::from(format!("crate::prelude::{}", p_)),
    }
}

/// ```prism
/// let stdNames
/// ```
pub fn std_names() -> Array<Text> {
    Array::from(vec![Text::lit("apply"), Text::lit("begin"), Text::lit("end"), Text::lit("size"), Text::lit("empty"), Text::lit("data"), Text::lit("get"), Text::lit("swap"), Text::lit("move"), Text::lit("forward"), Text::lit("find"), Text::lit("count"), Text::lit("copy"), Text::lit("fill"), Text::lit("sort"), Text::lit("min"), Text::lit("max"), Text::lit("visit"), Text::lit("invoke"), Text::lit("merge"), Text::lit("remove"), Text::lit("replace"), Text::lit("reverse"), Text::lit("unique"), Text::lit("transform"), Text::lit("accumulate"), Text::lit("distance"), Text::lit("next"), Text::lit("prev"), Text::lit("exchange"), Text::lit("tie"), Text::lit("to_string"), Text::lit("clamp"), Text::lit("partition"), Text::lit("equal"), Text::lit("mismatch"), Text::lit("erase"), Text::lit("search"), Text::lit("rotate")])
}

/// ```prism
/// IsFresh: fn Text -> Bool
/// ```
pub fn is_fresh(f: &Text) -> bool {
    in_list(&Array::from(vec![Text::lit("Stamped::new"), Text::lit("Cache::new"), Text::lit("Port::new"), Text::lit("Map::new"), Text::lit("Array::new"), Text::lit("Vec::new"), Text::lit("Default::default"), Text::lit("Wakes::default"), Text::lit("Defer::new")]), f)
}

/// ```prism
/// CallPath: fn Text -> Text
/// ```
pub fn call_path(f: &Text) -> Text {
    let last = last_segment(f);
    let owner = last_segment(&parent_path(f));
    let is_type = (&parent_path(f) != &Text::lit("")) && crate::syntax::lexer::contains(&Text::lit("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), &crate::syntax::lexer::head(&owner));
    if (&last == &Text::lit("build")) && is_type {
        Text::from(format!("{}::make", &type_path(&parent_path(f))))
    } else {
        if &last == &Text::lit("new") {
            type_path(&parent_path(f))
        } else {
            cpp_path_id(&type_path(f))
        }
    }
}

/// ```prism
/// CppMethod: unbounded fn Cp, Ex, Text, [Ex] -> Text
/// ```
pub fn cpp_method(cp: &Cp, r: &crate::lower::model::Ex, m: &Text, args: &Array<crate::lower::model::Ex>) -> Text {
    let recv = if r == &crate::lower::model::Ex::XSelf { Text::lit("this") } else { cpp_tight(cp, r) };
    let a = cpp_args(cp, args);
    let n = len(args);
    let sep = if &n == &Nat::from(0u32) { Text::lit("") } else { Text::lit(", ") };
    match method_form(m, &n) {
        m26152_0 if (&m26152_0 == &Text::lit("id")) => recv.clone(),
        m26152_1 if (&m26152_1 == &Text::lit("deref")) => match pointer(cp, r) {
            Some(b) => if b { Text::from(format!("(*{})", &recv)) } else { recv.clone() },
            None => recv.clone(),
        },
        m26152_2 if (&m26152_2 == &Text::lit("assign")) => Text::from(format!("{} = {}", &recv, &a)),
        m26152_3 if (&m26152_3 == &Text::lit("take")) => Text::from(format!("std::exchange({}, {{}})", &recv)),
        m26152_4 if (&m26152_4 == &Text::lit("free")) => Text::from(format!("{}({}{}{})", &free_name(m), &recv, &sep, &a)),
        m26152_5 if (&m26152_5 == &Text::lit("arrow")) => {
            let through = match pointer(cp, r) {
                Some(b) => if b { Text::lit("->") } else { Text::lit(".") },
                None => Text::lit("->"),
            };
            Text::from(format!("{}{}{}({})", &recv, &through, &member_name(m), &a))
        },
        m26152_6 if (&m26152_6 == &Text::lit("exchange")) => Text::from(format!("std::exchange({}, {})", &recv, &a)),
        _ => {
            let through = match pointer(cp, r) {
                Some(b) => if b { Text::lit("->") } else { Text::lit(".") },
                None => match get(&cp.members, m) {
                    Some(_) => Text::lit("->"),
                    None => Text::lit("."),
                },
            };
            Text::from(format!("{}{}{}({})", &recv, &through, &node_method_name(cp, m), &a))
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CppMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppMethod: unbounded fn Cp, Ex, Text, [Ex] -> Text
/// ```
pub struct CppMethod {
    pub cp: Cp,
    pub r: crate::lower::model::Ex,
    pub m: Text,
    pub args: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for CppMethod {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let r = &self.r;
        let m = &self.m;
        let args = &self.args;
        let recv = if r == &crate::lower::model::Ex::XSelf { Text::lit("this") } else { cpp_tight(cp, r) };
        let args = args.clone();
        let cp = cp.clone();
        let m = m.clone();
        let r = r.clone();
        call_then(start_cpp_args(cp.clone(), args.clone()), move |cpp_args_26071: Text| {
            let a = cpp_args_26071;
            let n = len(&args);
            let sep = if &n == &Nat::from(0u32) { Text::lit("") } else { Text::lit(", ") };
            match method_form(&m, &n) {
                m26152_0 if (&m26152_0 == &Text::lit("id")) => prism_rtl::Turn::Finished(recv.clone()),
                m26152_1 if (&m26152_1 == &Text::lit("deref")) => match pointer(&cp, &r) {
                    Some(b) => if b {
                        prism_rtl::Turn::Finished(Text::from(format!("(*{})", &recv)))
                    } else {
                        prism_rtl::Turn::Finished(recv.clone())
                    },
                    None => prism_rtl::Turn::Finished(recv.clone()),
                },
                m26152_2 if (&m26152_2 == &Text::lit("assign")) => prism_rtl::Turn::Finished(Text::from(format!("{} = {}", &recv, &a))),
                m26152_3 if (&m26152_3 == &Text::lit("take")) => prism_rtl::Turn::Finished(Text::from(format!("std::exchange({}, {{}})", &recv))),
                m26152_4 if (&m26152_4 == &Text::lit("free")) => prism_rtl::Turn::Finished(Text::from(format!("{}({}{}{})", &free_name(&m), &recv, &sep, &a))),
                m26152_5 if (&m26152_5 == &Text::lit("arrow")) => {
                    let through = match pointer(&cp, &r) {
                        Some(b) => if b { Text::lit("->") } else { Text::lit(".") },
                        None => Text::lit("->"),
                    };
                    prism_rtl::Turn::Finished(Text::from(format!("{}{}{}({})", &recv, &through, &member_name(&m), &a)))
                },
                m26152_6 if (&m26152_6 == &Text::lit("exchange")) => prism_rtl::Turn::Finished(Text::from(format!("std::exchange({}, {})", &recv, &a))),
                _ => {
                    let through = match pointer(&cp, &r) {
                        Some(b) => if b { Text::lit("->") } else { Text::lit(".") },
                        None => match get(&cp.members, &m) {
                            Some(_) => Text::lit("->"),
                            None => Text::lit("."),
                        },
                    };
                    prism_rtl::Turn::Finished(Text::from(format!("{}{}{}({})", &recv, &through, &node_method_name(&cp, &m), &a)))
                },
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start CppMethod, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_method(cp: Cp, r: crate::lower::model::Ex, m: Text, args: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppMethod { cp, r, m, args })
}

/// ```prism
/// NodeMethodName: fn Cp, Text -> Text
/// ```
pub fn node_method_name(cp: &Cp, m: &Text) -> Text {
    match (get(&cp.methods, m), get(&cp.field_names, m)) {
        (Some(_), Some(_)) => Text::from(format!("{}_", &cpp_id(m))),
        _ => member_name(m),
    }
}

/// ```prism
/// ?Pointer: fn Cp, Ex -> ?Bool
/// ```
pub fn pointer(cp: &Cp, r: &crate::lower::model::Ex) -> Option<bool> {
    'm27432: {
        if let crate::lower::model::Ex::XSelf = r {
            break 'm27432 Some(true);
        }
        if let crate::lower::model::Ex::XCx = r {
            break 'm27432 Some(false);
        }
        if let crate::lower::model::Ex::XVar(n) = r {
            break 'm27432 get(&cp.pointers, n);
        }
        if let crate::lower::model::Ex::XClone(y) = r {
            break 'm27432 pointer(cp, &**y);
        }
        if let crate::lower::model::Ex::XRef(y) = r {
            break 'm27432 pointer(cp, &**y);
        }
        if let crate::lower::model::Ex::XField(m27432_5_0, f) = r && let crate::lower::model::Ex::XSelf = &**m27432_5_0 {
            break 'm27432 match get(&cp.fields, f) {
                Some(t) => Some(is_pointer_ty(cp, &t)),
                None => None,
            };
        }
        if let crate::lower::model::Ex::XField(m27432_6_0, f) = r && let crate::lower::model::Ex::XVar(m27432_6_0_r_0) = &**m27432_6_0 && (m27432_6_0_r_0 == &Text::lit("node")) {
            break 'm27432 match get(&cp.fields, f) {
                Some(t) => Some(is_pointer_ty(cp, &t)),
                None => None,
            };
        }
        None
    }
}

/// ```prism
/// IsPointerTy: fn Cp, OutTy -> Bool
/// ```
pub fn is_pointer_ty(cp: &Cp, t: &crate::lower::model::OutTy) -> bool {
    match t {
        crate::lower::model::OutTy::OutNamed(m27830_0_0, _) if (m27830_0_0 == &Text::lit("prism_rtl::Rows")) => true,
        crate::lower::model::OutTy::OutPort(_) => false,
        crate::lower::model::OutTy::OutRc(i) => !is_value_ty(cp, &**i),
        crate::lower::model::OutTy::OutObj(_) => true,
        crate::lower::model::OutTy::OutJob(_) => true,
        crate::lower::model::OutTy::OutShowAny => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// MethodForm: fn Text, Nat -> Text
/// ```
pub fn method_form(m: &Text, n: &Nat) -> Text {
    match (m.clone(), n.clone()) {
        (m28369_0_0, m28369_0_1) if (&m28369_0_0 == &Text::lit("borrow")) && (&m28369_0_1 == &Nat::from(0u32)) => Text::lit("deref"),
        (m28369_1_0, m28369_1_1) if (&m28369_1_0 == &Text::lit("borrow_mut")) && (&m28369_1_1 == &Nat::from(0u32)) => Text::lit("deref"),
        (m28369_2_0, m28369_2_1) if (&m28369_2_0 == &Text::lit("clone")) && (&m28369_2_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m28369_3_0, m28369_3_1) if (&m28369_3_0 == &Text::lit("iter")) && (&m28369_3_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m28369_4_0, m28369_4_1) if (&m28369_4_0 == &Text::lit("collect")) && (&m28369_4_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m28369_5_0, m28369_5_1) if (&m28369_5_0 == &Text::lit("unwrap_or_default")) && (&m28369_5_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m28369_6_0, m28369_6_1) if (&m28369_6_0 == &Text::lit("for_each")) && (&m28369_6_1 == &Nat::from(1u32)) => Text::lit("free"),
        (m28369_7_0, m28369_7_1) if (&m28369_7_0 == &Text::lit("into_iter")) && (&m28369_7_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m28369_8_0, m28369_8_1) if (&m28369_8_0 == &Text::lit("as_ref")) && (&m28369_8_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m28369_9_0, m28369_9_1) if (&m28369_9_0 == &Text::lit("get")) && (&m28369_9_1 == &Nat::from(0u32)) => Text::lit("id"),
        (m28369_10_0, m28369_10_1) if (&m28369_10_0 == &Text::lit("set")) && (&m28369_10_1 == &Nat::from(1u32)) => Text::lit("assign"),
        (m28369_11_0, m28369_11_1) if (&m28369_11_0 == &Text::lit("take")) && (&m28369_11_1 == &Nat::from(0u32)) => Text::lit("take"),
        (m28369_12_0, m28369_12_1) if (&m28369_12_0 == &Text::lit("replace")) && (&m28369_12_1 == &Nat::from(1u32)) => Text::lit("exchange"),
        (m28369_13_0, m28369_13_1) if (&m28369_13_0 == &Text::lit("values")) && (&m28369_13_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m28369_14_0, m28369_14_1) if (&m28369_14_0 == &Text::lit("keys")) && (&m28369_14_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m28369_15_0, m28369_15_1) if (&m28369_15_0 == &Text::lit("enumerate")) && (&m28369_15_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m28369_16_0, m28369_16_1) if (&m28369_16_0 == &Text::lit("fire")) && (&m28369_16_1 == &Nat::from(2u32)) => Text::lit("arrow"),
        (m28369_17_0, m28369_17_1) if (&m28369_17_0 == &Text::lit("subscribe")) && (&m28369_17_1 == &Nat::from(1u32)) => Text::lit("arrow"),
        (m28369_18_0, m28369_18_1) if (&m28369_18_0 == &Text::lit("unsubscribe")) && (&m28369_18_1 == &Nat::from(1u32)) => Text::lit("arrow"),
        (m28369_19_0, m28369_19_1) if (&m28369_19_0 == &Text::lit("cycle")) && (&m28369_19_1 == &Nat::from(0u32)) => Text::lit("arrow"),
        (m28369_20_0, m28369_20_1) if (&m28369_20_0 == &Text::lit("upgrade")) && (&m28369_20_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m28369_21_0, m28369_21_1) if (&m28369_21_0 == &Text::lit("expect")) && (&m28369_21_1 == &Nat::from(1u32)) => Text::lit("free"),
        (m28369_22_0, m28369_22_1) if (&m28369_22_0 == &Text::lit("to_pod")) && (&m28369_22_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m28369_23_0, m28369_23_1) if (&m28369_23_0 == &Text::lit("cloned")) && (&m28369_23_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m28369_24_0, m28369_24_1) if (&m28369_24_0 == &Text::lit("ok")) && (&m28369_24_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m28369_25_0, m28369_25_1) if (&m28369_25_0 == &Text::lit("ok_or")) && (&m28369_25_1 == &Nat::from(1u32)) => Text::lit("free"),
        (m28369_26_0, m28369_26_1) if (&m28369_26_0 == &Text::lit("map")) && (&m28369_26_1 == &Nat::from(1u32)) => Text::lit("free"),
        (m28369_27_0, m28369_27_1) if (&m28369_27_0 == &Text::lit("iter_mut")) && (&m28369_27_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m28369_28_0, m28369_28_1) if (&m28369_28_0 == &Text::lit("to_vec")) && (&m28369_28_1 == &Nat::from(0u32)) => Text::lit("free"),
        (m28369_29_0, m28369_29_1) if (&m28369_29_0 == &Text::lit("filter_some")) && (&m28369_29_1 == &Nat::from(0u32)) => Text::lit("free"),
        _ => Text::lit("dot"),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// FreeName: fn Text -> Text
/// ```
pub fn free_name(m: &Text) -> Text {
    match m {
        m29306_0 if (m29306_0 == &Text::lit("to_pod")) => Text::lit("prism_rtl::to_pod"),
        m29306_1 if (m29306_1 == &Text::lit("ok")) => Text::lit("prism_rtl::ignore"),
        m29306_2 if (m29306_2 == &Text::lit("map")) => Text::lit("prism_rtl::fmap"),
        m29306_3 if (m29306_3 == &Text::lit("to_vec")) => Text::lit("path_of"),
        m29306_4 if (m29306_4 == &Text::lit("values")) => Text::lit("crate::prelude::values"),
        m29306_5 if (m29306_5 == &Text::lit("keys")) => Text::lit("crate::prelude::keys"),
        m29306_6 if (m29306_6 == &Text::lit("enumerate")) => Text::lit("prism_rtl::enumerate"),
        m29306_7 if (m29306_7 == &Text::lit("unwrap_or_default")) => Text::lit("prism_rtl::unwrap_or_default"),
        m29306_8 if (m29306_8 == &Text::lit("for_each")) => Text::lit("prism_rtl::for_each"),
        _ => m.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// MemberName: fn Text -> Text
/// ```
pub fn member_name(m: &Text) -> Text {
    match m {
        m29704_0 if (m29704_0 == &Text::lit("push_str")) => Text::lit("append"),
        m29704_1 if (m29704_1 == &Text::lit("len")) => Text::lit("size"),
        m29704_2 if (m29704_2 == &Text::lit("is_empty")) => Text::lit("empty"),
        m29704_3 if (m29704_3 == &Text::lit("push")) => Text::lit("push_back"),
        m29704_4 if (m29704_4 == &Text::lit("contains_key")) => Text::lit("contains"),
        m29704_5 if (m29704_5 == &Text::lit("build")) => Text::lit("make"),
        _ => cpp_id(m),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CaseTest: fn Cp, Text, Text -> Text
/// ```
pub fn case_test(cp: &Cp, c: &Text, v_: &Text) -> Text {
    match c {
        m30003_0 if (m30003_0 == &Text::lit("Some")) => Text::from(format!("prism_rtl::is_some({})", v_)),
        m30003_1 if (m30003_1 == &Text::lit("None")) => Text::from(format!("prism_rtl::is_none({})", v_)),
        m30003_2 if (m30003_2 == &Text::lit("Ok")) => Text::from(format!("prism_rtl::is_ok({})", v_)),
        m30003_3 if (m30003_3 == &Text::lit("Err")) => Text::from(format!("prism_rtl::is_err({})", v_)),
        m30003_4 if (m30003_4 == &Text::lit("prism_rtl::Turn::More")) => Text::from(format!("{}.if_more()", v_)),
        m30003_5 if (m30003_5 == &Text::lit("prism_rtl::Turn::Finished")) => Text::from(format!("{}.if_finished()", v_)),
        _ => match case_of(cp, c) {
            Some(_) => Text::from(format!("prism_rtl::is<{}>({})", &case_type(c), v_)),
            None => if is_runtime_case(c) {
                Text::from(format!("prism_rtl::is<{}>({})", &case_type(c), v_))
            } else {
                Text::lit("true")
            },
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CaseType: fn Text -> Text
/// ```
pub fn case_type(c: &Text) -> Text {
    match c {
        m30555_0 if (m30555_0 == &Text::lit("Segment::Pos")) => Text::lit("pat::Pos"),
        m30555_1 if (m30555_1 == &Text::lit("Segment::Gen")) => Text::lit("pat::Gen"),
        m30555_2 if (m30555_2 == &Text::lit("Segment::Key")) => Text::lit("pat::Key"),
        _ => type_path(c),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Payload: fn Cp, Text, Text, Nat -> Text
/// ```
pub fn payload(cp: &Cp, c: &Text, v_: &Text, i: &Nat) -> Text {
    match c {
        m30804_0 if (m30804_0 == &Text::lit("Some")) => Text::from(format!("prism_rtl::some_of({})", v_)),
        m30804_1 if (m30804_1 == &Text::lit("Ok")) => Text::from(format!("*{}", v_)),
        m30804_2 if (m30804_2 == &Text::lit("Err")) => Text::from(format!("{}.error()", v_)),
        m30804_3 if (m30804_3 == &Text::lit("prism_rtl::Turn::More")) => Text::from(format!("{}.if_more()->next", v_)),
        m30804_4 if (m30804_4 == &Text::lit("prism_rtl::Turn::Finished")) => Text::from(format!("{}.if_finished()->value", v_)),
        _ => match case_of(cp, c) {
            Some(_) => Text::from(format!("prism_rtl::as<{}>({}).a{}", &case_type(c), v_, i)),
            None => if is_runtime_case(c) {
                Text::from(format!("prism_rtl::as<{}>({}).a{}", &case_type(c), v_, i))
            } else {
                Text::from(format!("{}.a{}", v_, i))
            },
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IsRuntimeCase: fn Text -> Bool
/// ```
pub fn is_runtime_case(c: &Text) -> bool {
    crate::syntax::lexer::has_prefix(c, &Text::lit("Segment::"))
}

/// ```prism
/// CppIf: unbounded fn Cp, Ex, Ex, Ex -> Text
/// ```
pub fn cpp_if(cp: &Cp, c: &crate::lower::model::Ex, t: &crate::lower::model::Ex, e: &crate::lower::model::Ex) -> Text {
    let ct = cpp_expr(cp, c);
    let err_opt = match (err_of(t), err_of(e)) {
        (Some(y), _) => Some(y.clone()),
        (None, Some(y)) => Some(y.clone()),
        _ => None,
    };
    let tt = match &err_opt {
        Some(y) => ok_branch(cp, t, y),
        None => cpp_expr(cp, t),
    };
    let et = match &err_opt {
        Some(y) => ok_branch(cp, e, y),
        None => cpp_expr(cp, e),
    };
    let short = !crate::syntax::lexer::contains(&Text::from(format!("{}{}", &tt, &et)), &Text::lit("\n")) && (&len_text(&Text::from(format!("{}{}{}", &ct, &tt, &et))) < &Nat::from(70u32));
    if short {
        Text::from(format!("{} ? {} : {}", &ct, &tt, &et))
    } else {
        crate::emit::cpp::templates::cond_expr(&ct, &tt, &et)
    }
}

/// The step machine of `CppIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppIf: unbounded fn Cp, Ex, Ex, Ex -> Text
/// ```
pub struct CppIf {
    pub cp: Cp,
    pub c: crate::lower::model::Ex,
    pub t: crate::lower::model::Ex,
    pub e: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppIf {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let c = &self.c;
        let t = &self.t;
        let e = &self.e;
        let c = c.clone();
        let cp = cp.clone();
        let e = e.clone();
        let t = t.clone();
        call_then(start_cpp_expr(cp.clone(), c.clone()), move |cpp_expr_31381: Text| {
            let ct = cpp_expr_31381;
            let err_opt = match (err_of(&t), err_of(&e)) {
                (Some(y), _) => Some(y.clone()),
                (None, Some(y)) => Some(y.clone()),
                _ => None,
            };
            let tt = match &err_opt {
                Some(y) => ok_branch(&cp, &t, y),
                None => cpp_expr(&cp, &t),
            };
            let et = match &err_opt {
                Some(y) => ok_branch(&cp, &e, y),
                None => cpp_expr(&cp, &e),
            };
            let short = !crate::syntax::lexer::contains(&Text::from(format!("{}{}", &tt, &et)), &Text::lit("\n")) && (&len_text(&Text::from(format!("{}{}{}", &ct, &tt, &et))) < &Nat::from(70u32));
            if short {
                prism_rtl::Turn::Finished(Text::from(format!("{} ? {} : {}", &ct, &tt, &et)))
            } else {
                prism_rtl::Turn::Finished(crate::emit::cpp::templates::cond_expr(&ct, &tt, &et))
            }
        })
    }
}

/// `Start CppIf, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_if(cp: Cp, c: crate::lower::model::Ex, t: crate::lower::model::Ex, e: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppIf { cp, c, t, e })
}

/// ```prism
/// IsCtor: fn Ex, Text -> Bool
/// ```
pub fn is_ctor(ex0: &crate::lower::model::Ex, c: &Text) -> bool {
    match ex0 {
        crate::lower::model::Ex::XCtor(p_, _) => p_ == c,
        x => false,
    }
}

/// ```prism
/// ?ErrOf: fn Ex -> ?Ex
/// ```
pub fn err_of(x: &crate::lower::model::Ex) -> Option<crate::lower::model::Ex> {
    'm32020: {
        if let crate::lower::model::Ex::XCtor(m32020_0_0, m32020_0_1) = x && (m32020_0_0 == &Text::lit("Err")) && (m32020_0_1.len() == 1) && let Some(y) = index(m32020_0_1, &Nat::from(0u32)) {
            break 'm32020 Some(y.clone());
        }
        if let crate::lower::model::Ex::XBlock(_, tail) = x {
            break 'm32020 err_of(&**tail);
        }
        None
    }
}

/// ```prism
/// OkBranch: unbounded fn Cp, Ex, Ex -> Text
/// ```
pub fn ok_branch(cp: &Cp, x: &crate::lower::model::Ex, y: &crate::lower::model::Ex) -> Text {
    'm32323: {
        if let crate::lower::model::Ex::XCtor(m32323_0_0, m32323_0_1) = x && (m32323_0_0 == &Text::lit("Ok")) && (m32323_0_1.len() == 1) && let Some(v_) = index(m32323_0_1, &Nat::from(0u32)) {
            break 'm32323 Text::from(format!("Expected<std::decay_t<decltype({})>, std::decay_t<decltype({})>>({})", &cpp_expr(cp, &v_), &cpp_expr(cp, y), &cpp_expr(cp, &v_)));
        }
        if let crate::lower::model::Ex::XBlock(dos, m32323_1_1) = x && let crate::lower::model::Ex::XCtor(m32323_1_1_r_0, m32323_1_1_r_1) = &**m32323_1_1 && (m32323_1_1_r_0 == &Text::lit("Ok")) && (m32323_1_1_r_1.len() == 1) && let Some(v_) = index(m32323_1_1_r_1, &Nat::from(0u32)) {
            break 'm32323 {
                let (st, cp2) = cpp_statements_cp(cp, dos);
                crate::emit::cpp::templates::stmt_expr(&st, &Text::from(format!("Expected<std::decay_t<decltype({})>, std::decay_t<decltype({})>>({})", &cpp_expr(&cp2, &v_), &cpp_expr(&cp2, y), &cpp_expr(&cp2, &v_))))
            };
        }
        cpp_expr(cp, x)
    }
}

/// The step machine of `OkBranch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OkBranch: unbounded fn Cp, Ex, Ex -> Text
/// ```
pub struct OkBranch {
    pub cp: Cp,
    pub x: crate::lower::model::Ex,
    pub y: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for OkBranch {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let x = &self.x;
        let y = &self.y;
        'm32323: {
            if let crate::lower::model::Ex::XCtor(m32323_0_0, m32323_0_1) = x && (m32323_0_0 == &Text::lit("Ok")) && (m32323_0_1.len() == 1) && let Some(v_) = index(m32323_0_1, &Nat::from(0u32)) {
                break 'm32323 {
                    let cp = cp.clone();
                    let y = y.clone();
                    call_then(start_cpp_expr(cp.clone(), v_.clone()), move |cpp_expr_32388: Text| call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_32429: Text| call_then(start_cpp_expr(cp.clone(), v_.clone()), move |cpp_expr_32448: Text| prism_rtl::Turn::Finished(Text::from(format!("Expected<std::decay_t<decltype({})>, std::decay_t<decltype({})>>({})", &cpp_expr_32388, &cpp_expr_32429, &cpp_expr_32448))))))
                };
            }
            if let crate::lower::model::Ex::XBlock(dos, m32323_1_1) = x && let crate::lower::model::Ex::XCtor(m32323_1_1_r_0, m32323_1_1_r_1) = &**m32323_1_1 && (m32323_1_1_r_0 == &Text::lit("Ok")) && (m32323_1_1_r_1.len() == 1) && let Some(v_) = index(m32323_1_1_r_1, &Nat::from(0u32)) {
                break 'm32323 {
                    let cp = cp.clone();
                    let dos = dos.clone();
                    let y = y.clone();
                    call_then(start_cpp_statements_cp(cp.clone(), dos.clone()), move |cpp_statements_cp_32528: (Text, Cp)| {
                        let (st, cp2) = cpp_statements_cp_32528;
                        call_then(start_cpp_expr(cp2.clone(), v_.clone()), move |cpp_expr_32606: Text| call_then(start_cpp_expr(cp2.clone(), y.clone()), move |cpp_expr_32648: Text| call_then(start_cpp_expr(cp2.clone(), v_.clone()), move |cpp_expr_32668: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::stmt_expr(&st, &Text::from(format!("Expected<std::decay_t<decltype({})>, std::decay_t<decltype({})>>({})", &cpp_expr_32606, &cpp_expr_32648, &cpp_expr_32668)))))))
                    })
                };
            }
            prism_rtl::Turn::More(Rc::new(CppExpr { cp: cp.clone(), x: x.clone() }))
        }
    }
}

/// `Start OkBranch, x`: what the function value is when passed to `@Run`.
pub fn start_ok_branch(cp: Cp, x: crate::lower::model::Ex, y: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(OkBranch { cp, x, y })
}

/// ```prism
/// CppClosure: unbounded fn Cp, Bool, [Pa], Ex -> Text
/// ```
pub fn cpp_closure(cp0: &Cp, mv: &bool, ps: &Array<crate::lower::model::Pa>, body: &crate::lower::model::Ex) -> Text {
    let cp = unbind(cp0, &concat2(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
        let p_ = p0;
        prism_rtl::Turn::More(Rc::new(PatNames { p_: p_.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))));
    let params = crate::syntax::lexer::join(&run_to_end(each_job(crate::check::errors::range0(&len(ps)), {
        let cp = cp.clone();
        let ps = ps.clone();
        Rc::new(move |p0: Nat| {
            let cp = cp.clone();
            let ps = ps.clone();
            entered(once_job(move || {
                let i = p0;
                prism_rtl::Turn::More(Rc::new(ClosureParam { cp: cp.clone(), pa1: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), i: i.clone() }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "));
    let binds = concat(&run_to_end(each_job(crate::check::errors::range0(&len(ps)), {
        let cp = cp.clone();
        let ps = ps.clone();
        Rc::new(move |p0: Nat| {
            let cp = cp.clone();
            let ps = ps.clone();
            entered(once_job(move || {
                let i = p0;
                prism_rtl::Turn::More(Rc::new(ClosureBinds { cp: cp.clone(), pa1: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), i: i.clone() }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let capture = if *mv { Text::lit("=") } else { Text::lit("&") };
    let b = cpp_expr(&cp, body);
    let (ret, value) = match body {
        crate::lower::model::Ex::XRef(_) => (Text::lit(" -> decltype(auto)"), Text::from(format!("({})", &b))),
        crate::lower::model::Ex::XRefMut(_) => (Text::lit(" -> decltype(auto)"), Text::from(format!("({})", &b))),
        _ => (Text::lit(""), b.clone()),
    };
    if (&binds == &Text::lit("")) && !crate::syntax::lexer::contains(&b, &Text::lit("\n")) {
        Text::from(format!("[{}]({}){} {{ return {}; }}", &capture, &params, &ret, &value))
    } else {
        crate::emit::cpp::templates::lambda(&capture, &Text::from(format!("{}){}", &params, &ret)), &Text::from(format!("{}return {};", &binds, &value)))
    }
}

/// The step machine of `CppClosure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppClosure: unbounded fn Cp, Bool, [Pa], Ex -> Text
/// ```
pub struct CppClosure {
    pub cp0: Cp,
    pub mv: bool,
    pub ps: Array<crate::lower::model::Pa>,
    pub body: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppClosure {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp0 = &self.cp0;
        let mv = &self.mv;
        let ps = &self.ps;
        let body = &self.body;
        let body = body.clone();
        let cp0 = cp0.clone();
        let mv = *mv;
        let ps = ps.clone();
        call_value(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
            let p_ = p0;
            prism_rtl::Turn::More(Rc::new(PatNames { p_: p_.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_32903: Array<Array<Text>>| {
            let cp = unbind(&cp0, &concat2(&each_32903));
            call_value(each_job(crate::check::errors::range0(&len(&ps)), {
                let cp = cp.clone();
                let ps = ps.clone();
                Rc::new(move |p0: Nat| {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(ClosureParam { cp: cp.clone(), pa1: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), i: i.clone() }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_32953: Array<Text>| {
                let params = crate::syntax::lexer::join(&each_32953, &Text::lit(", "));
                call_value(each_job(crate::check::errors::range0(&len(&ps)), {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    Rc::new(move |p0: Nat| {
                        let cp = cp.clone();
                        let ps = ps.clone();
                        entered(once_job(move || {
                            let i = p0;
                            prism_rtl::Turn::More(Rc::new(ClosureBinds { cp: cp.clone(), pa1: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), i: i.clone() }))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_33052: Array<Text>| {
                    let binds = concat(&each_33052);
                    let capture = if mv { Text::lit("=") } else { Text::lit("&") };
                    call_then(start_cpp_expr(cp.clone(), body.clone()), move |cpp_expr_33172: Text| {
                        let b = cpp_expr_33172;
                        let (ret, value) = match &body {
                            crate::lower::model::Ex::XRef(_) => (Text::lit(" -> decltype(auto)"), Text::from(format!("({})", &b))),
                            crate::lower::model::Ex::XRefMut(_) => (Text::lit(" -> decltype(auto)"), Text::from(format!("({})", &b))),
                            _ => (Text::lit(""), b.clone()),
                        };
                        if (&binds == &Text::lit("")) && !crate::syntax::lexer::contains(&b, &Text::lit("\n")) {
                            prism_rtl::Turn::Finished(Text::from(format!("[{}]({}){} {{ return {}; }}", &capture, &params, &ret, &value)))
                        } else {
                            prism_rtl::Turn::Finished(crate::emit::cpp::templates::lambda(&capture, &Text::from(format!("{}){}", &params, &ret)), &Text::from(format!("{}return {};", &binds, &value))))
                        }
                    })
                })
            })
        })
    }
}

/// `Start CppClosure, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_closure(cp0: Cp, mv: bool, ps: Array<crate::lower::model::Pa>, body: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppClosure { cp0, mv, ps, body })
}

/// ```prism
/// ClosureParam: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub fn closure_param(cp: &Cp, pa1: &crate::lower::model::Pa, i: &Nat) -> Text {
    'c: {
        if let crate::lower::model::Pa::PaTyped(c0_1_0, t) = pa1 && let crate::lower::model::Pa::PaBind(n) = &**c0_1_0 {
            break 'c Text::from(format!("{} {}", &param_type(cp, t), &cpp_id(n)));
        }
        if let crate::lower::model::Pa::PaTyped(c1_1_0, t) = pa1 && let crate::lower::model::Pa::PaMut(n) = &**c1_1_0 {
            break 'c Text::from(format!("{} {}", &cpp_type(cp, &unref(t)), &cpp_id(n)));
        }
        if let crate::lower::model::Pa::PaTyped(p_, t) = pa1 {
            break 'c Text::from(format!("{} _p{}", &param_type(cp, t), i));
        }
        if let crate::lower::model::Pa::PaBind(n) = pa1 {
            break 'c Text::from(format!("auto&& {}", &cpp_id(n)));
        }
        if let crate::lower::model::Pa::PaMut(n) = pa1 {
            break 'c Text::from(format!("auto {}", &cpp_id(n)));
        }
        if let crate::lower::model::Pa::PaWild = pa1 {
            break 'c Text::lit("const auto&");
        }
        if let p_ = pa1 {
            break 'c Text::from(format!("const auto& _p{}", i));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `ClosureParam`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosureParam: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub struct ClosureParam {
    pub cp: Cp,
    pub pa1: crate::lower::model::Pa,
    pub i: Nat,
}

impl prism_rtl::Job<Text> for ClosureParam {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let pa1 = &self.pa1;
        let i = &self.i;
        'j: {
            if let crate::lower::model::Pa::PaTyped(j0_1_0, t) = pa1 && let crate::lower::model::Pa::PaBind(n) = &**j0_1_0 {
                break 'j {
                    let cp = cp.clone();
                    let n = n.clone();
                    let t = t.clone();
                    call_then(start_param_type(cp.clone(), t.clone()), move |param_type_33634: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_33634, &cpp_id(&n)))))
                };
            }
            if let crate::lower::model::Pa::PaTyped(j1_1_0, t) = pa1 && let crate::lower::model::Pa::PaMut(n) = &**j1_1_0 {
                break 'j {
                    let cp = cp.clone();
                    let n = n.clone();
                    let t = t.clone();
                    call_then(start_cpp_type(cp.clone(), unref(&t)), move |cpp_type_33712: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_33712, &cpp_id(&n)))))
                };
            }
            if let crate::lower::model::Pa::PaTyped(p_, t) = pa1 {
                break 'j {
                    let cp = cp.clone();
                    let i = i.clone();
                    let t = t.clone();
                    call_then(start_param_type(cp.clone(), t.clone()), move |param_type_33788: Text| prism_rtl::Turn::Finished(Text::from(format!("{} _p{}", &param_type_33788, &i))))
                };
            }
            if let crate::lower::model::Pa::PaBind(n) = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::from(format!("auto&& {}", &cpp_id(n))));
            }
            if let crate::lower::model::Pa::PaMut(n) = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::from(format!("auto {}", &cpp_id(n))));
            }
            if let crate::lower::model::Pa::PaWild = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::lit("const auto&"));
            }
            if let p_ = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::from(format!("const auto& _p{}", i)));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start ClosureParam, x`: what the function value is when passed to `@Run`.
pub fn start_closure_param(cp: Cp, pa1: crate::lower::model::Pa, i: Nat) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ClosureParam { cp, pa1, i })
}

/// ```prism
/// ClosureBinds: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub fn closure_binds(cp: &Cp, pa1: &crate::lower::model::Pa, i: &Nat) -> Text {
    'c: {
        if let crate::lower::model::Pa::PaTyped(c0_1_0, t) = pa1 && let crate::lower::model::Pa::PaBind(n) = &**c0_1_0 {
            break 'c Text::lit("");
        }
        if let crate::lower::model::Pa::PaTyped(c1_1_0, t) = pa1 && let crate::lower::model::Pa::PaMut(n) = &**c1_1_0 {
            break 'c Text::lit("");
        }
        if let crate::lower::model::Pa::PaTyped(p_, t) = pa1 {
            break 'c closure_binds(cp, &**p_, i);
        }
        if let crate::lower::model::Pa::PaBind(n) = pa1 {
            break 'c Text::lit("");
        }
        if let crate::lower::model::Pa::PaMut(n) = pa1 {
            break 'c Text::lit("");
        }
        if let crate::lower::model::Pa::PaWild = pa1 {
            break 'c Text::lit("");
        }
        if let p_ = pa1 {
            break 'c concat(&each(&pat_binds(cp, p_, &Text::from(format!("_p{}", i))), &(|b: &Text| Text::from(format!("{}\n", b)))));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `ClosureBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosureBinds: unbounded fn Cp, Pa, Nat -> Text
/// ```
pub struct ClosureBinds {
    pub cp: Cp,
    pub pa1: crate::lower::model::Pa,
    pub i: Nat,
}

impl prism_rtl::Job<Text> for ClosureBinds {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let pa1 = &self.pa1;
        let i = &self.i;
        'j: {
            if let crate::lower::model::Pa::PaTyped(j0_1_0, t) = pa1 && let crate::lower::model::Pa::PaBind(n) = &**j0_1_0 {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let crate::lower::model::Pa::PaTyped(j1_1_0, t) = pa1 && let crate::lower::model::Pa::PaMut(n) = &**j1_1_0 {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let crate::lower::model::Pa::PaTyped(p_, t) = pa1 {
                break 'j prism_rtl::Turn::More(Rc::new(ClosureBinds { cp: cp.clone(), pa1: (**p_).clone(), i: i.clone() }));
            }
            if let crate::lower::model::Pa::PaBind(n) = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let crate::lower::model::Pa::PaMut(n) = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let crate::lower::model::Pa::PaWild = pa1 {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let p_ = pa1 {
                break 'j {
                    let cp = cp.clone();
                    let i = i.clone();
                    let p_ = p_.clone();
                    call_then(start_pat_binds(cp.clone(), p_.clone(), Text::from(format!("_p{}", &i))), move |pat_binds_34378: Array<Text>| prism_rtl::Turn::Finished(concat(&each(&pat_binds_34378, &(|b: &Text| Text::from(format!("{}\n", b)))))))
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start ClosureBinds, x`: what the function value is when passed to `@Run`.
pub fn start_closure_binds(cp: Cp, pa1: crate::lower::model::Pa, i: Nat) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ClosureBinds { cp, pa1, i })
}

/// ```prism
/// Unref: fn OutTy -> OutTy
/// ```
pub fn unref(out_ty0: &crate::lower::model::OutTy) -> crate::lower::model::OutTy {
    match out_ty0 {
        crate::lower::model::OutTy::OutRef(t) => (**t).clone(),
        t => t.clone(),
    }
}

/// ```prism
/// ParamType: unbounded fn Cp, OutTy -> Text
/// ```
pub fn param_type(cp: &Cp, t: &crate::lower::model::OutTy) -> Text {
    match t {
        crate::lower::model::OutTy::OutRef(_) => cpp_type(cp, t),
        crate::lower::model::OutTy::OutSlice(_) => cpp_type(cp, t),
        crate::lower::model::OutTy::OutUnit => Text::lit("Unit"),
        _ => cpp_type(cp, t),
    }
}

/// The step machine of `ParamType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParamType: unbounded fn Cp, OutTy -> Text
/// ```
pub struct ParamType {
    pub cp: Cp,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for ParamType {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let t = &self.t;
        match t {
            crate::lower::model::OutTy::OutRef(_) => prism_rtl::Turn::More(Rc::new(CppType { cp: cp.clone(), t: t.clone() })),
            crate::lower::model::OutTy::OutSlice(_) => prism_rtl::Turn::More(Rc::new(CppType { cp: cp.clone(), t: t.clone() })),
            crate::lower::model::OutTy::OutUnit => prism_rtl::Turn::Finished(Text::lit("Unit")),
            _ => prism_rtl::Turn::More(Rc::new(CppType { cp: cp.clone(), t: t.clone() })),
        }
    }
}

/// `Start ParamType, x`: what the function value is when passed to `@Run`.
pub fn start_param_type(cp: Cp, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ParamType { cp, t })
}

/// ```prism
/// PatConds: unbounded fn Cp, Pa, Text -> [Text]
/// ```
pub fn pat_conds(cp: &Cp, p_: &crate::lower::model::Pa, v_: &Text) -> Array<Text> {
    match p_ {
        crate::lower::model::Pa::PaWild => Array::new(),
        crate::lower::model::Pa::PaBind(_) => Array::new(),
        crate::lower::model::Pa::PaMut(_) => Array::new(),
        crate::lower::model::Pa::PaTyped(q, _) => pat_conds(cp, &**q, v_),
        crate::lower::model::Pa::PaUnit(c) => Array::from(vec![case_test(cp, c, v_)]),
        crate::lower::model::Pa::PaCtor(c, ps) => {
            let own = case_test(cp, c, v_);
            let inner = concat2(&run_to_end(each_job(crate::check::errors::range0(&len(ps)), {
                let cp = cp.clone();
                let ps = ps.clone();
                let c = c.clone();
                let v_ = v_.clone();
                Rc::new(move |p0: Nat| {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let c = c.clone();
                    let v_ = v_.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(PatConds { cp: cp.clone(), p_: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), v_: payload(&cp, &c, &v_, &i) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            })));
            filter(&append(&Array::from(vec![own.clone()]), &inner), &(|t: &Text| t != &Text::lit("true")))
        },
        crate::lower::model::Pa::PaRecord(c, fs, _) => concat2(&run_to_end(each_job(fs.clone(), {
            let cp = cp.clone();
            let v_ = v_.clone();
            Rc::new(move |p0: (Text, crate::lower::model::Pa)| {
                let cp = cp.clone();
                let v_ = v_.clone();
                entered(once_job(move || {
                    let (f, q) = p0;
                    prism_rtl::Turn::More(Rc::new(PatConds { cp: cp.clone(), p_: q.clone(), v_: Text::from(format!("{}.{}", &v_, &field_id(&f))) }))
                }))
            }) as Rc<dyn Fn((Text, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }))),
        crate::lower::model::Pa::PaTuple(ps) => concat2(&run_to_end(each_job(crate::check::errors::range0(&len(ps)), {
            let cp = cp.clone();
            let ps = ps.clone();
            let v_ = v_.clone();
            Rc::new(move |p0: Nat| {
                let cp = cp.clone();
                let ps = ps.clone();
                let v_ = v_.clone();
                entered(once_job(move || {
                    let i = p0;
                    prism_rtl::Turn::More(Rc::new(PatConds { cp: cp.clone(), p_: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), v_: Text::from(format!("std::get<{}>({})", &i, &v_)) }))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }))),
        crate::lower::model::Pa::PaChar(c) => Array::from(vec![Text::from(format!("{} == U'{}'", v_, &cpp_char_escape(c)))]),
        crate::lower::model::Pa::PaBool(b) => Array::from(vec![if *b { v_.clone() } else { Text::from(format!("!{}", v_)) }]),
        crate::lower::model::Pa::PaIndex(n) => Array::from(vec![Text::from(format!("{} == {}u", v_, n))]),
        crate::lower::model::Pa::PaConst(n) => Array::from(vec![Text::from(format!("{} == {}", v_, n))]),
        crate::lower::model::Pa::PaSlice(ps) => {
            let rest = fold(ps, &false, &(|f: &bool, q: &crate::lower::model::Pa| *f || is_rest(q)));
            let fixed = len(&filter(ps, &(|q: &crate::lower::model::Pa| !is_rest(q))));
            let size_ = if rest {
                Text::from(format!("{}.size() >= {}", v_, &fixed))
            } else {
                Text::from(format!("{}.size() == {}", v_, &fixed))
            };
            append(&Array::from(vec![size_.clone()]), &concat2(&run_to_end(each_job(crate::check::errors::range0(&len(ps)), {
                let cp = cp.clone();
                let ps = ps.clone();
                let v_ = v_.clone();
                Rc::new(move |p0: Nat| {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let v_ = v_.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(PatConds { cp: cp.clone(), p_: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), v_: Text::from(format!("{}[{}]", &v_, &i)) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }))))
        },
        crate::lower::model::Pa::PaRest(_) => Array::new(),
    }
}

/// The step machine of `PatConds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatConds: unbounded fn Cp, Pa, Text -> [Text]
/// ```
pub struct PatConds {
    pub cp: Cp,
    pub p_: crate::lower::model::Pa,
    pub v_: Text,
}

impl prism_rtl::Job<Array<Text>> for PatConds {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cp = &self.cp;
        let p_ = &self.p_;
        let v_ = &self.v_;
        match p_ {
            crate::lower::model::Pa::PaWild => prism_rtl::Turn::Finished(Array::new()),
            crate::lower::model::Pa::PaBind(_) => prism_rtl::Turn::Finished(Array::new()),
            crate::lower::model::Pa::PaMut(_) => prism_rtl::Turn::Finished(Array::new()),
            crate::lower::model::Pa::PaTyped(q, _) => prism_rtl::Turn::More(Rc::new(PatConds { cp: cp.clone(), p_: (**q).clone(), v_: v_.clone() })),
            crate::lower::model::Pa::PaUnit(c) => prism_rtl::Turn::Finished(Array::from(vec![case_test(cp, c, v_)])),
            crate::lower::model::Pa::PaCtor(c, ps) => {
                let own = case_test(cp, c, v_);
                let c = c.clone();
                let cp = cp.clone();
                let ps = ps.clone();
                let v_ = v_.clone();
                call_value(each_job(crate::check::errors::range0(&len(&ps)), {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let c = c.clone();
                    let v_ = v_.clone();
                    Rc::new(move |p0: Nat| {
                        let cp = cp.clone();
                        let ps = ps.clone();
                        let c = c.clone();
                        let v_ = v_.clone();
                        entered(once_job(move || {
                            let i = p0;
                            prism_rtl::Turn::More(Rc::new(PatConds { cp: cp.clone(), p_: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), v_: payload(&cp, &c, &v_, &i) }))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_35483: Array<Array<Text>>| {
                    let inner = concat2(&each_35483);
                    prism_rtl::Turn::Finished(filter(&append(&Array::from(vec![own.clone()]), &inner), &(|t: &Text| t != &Text::lit("true"))))
                })
            },
            crate::lower::model::Pa::PaRecord(c, fs, _) => {
                let cp = cp.clone();
                let fs = fs.clone();
                let v_ = v_.clone();
                call_value(each_job(fs.clone(), {
                    let cp = cp.clone();
                    let v_ = v_.clone();
                    Rc::new(move |p0: (Text, crate::lower::model::Pa)| {
                        let cp = cp.clone();
                        let v_ = v_.clone();
                        entered(once_job(move || {
                            let (f, q) = p0;
                            prism_rtl::Turn::More(Rc::new(PatConds { cp: cp.clone(), p_: q.clone(), v_: Text::from(format!("{}.{}", &v_, &field_id(&f))) }))
                        }))
                    }) as Rc<dyn Fn((Text, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_35662: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_35662)))
            },
            crate::lower::model::Pa::PaTuple(ps) => {
                let cp = cp.clone();
                let ps = ps.clone();
                let v_ = v_.clone();
                call_value(each_job(crate::check::errors::range0(&len(&ps)), {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let v_ = v_.clone();
                    Rc::new(move |p0: Nat| {
                        let cp = cp.clone();
                        let ps = ps.clone();
                        let v_ = v_.clone();
                        entered(once_job(move || {
                            let i = p0;
                            prism_rtl::Turn::More(Rc::new(PatConds { cp: cp.clone(), p_: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), v_: Text::from(format!("std::get<{}>({})", &i, &v_)) }))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_35743: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_35743)))
            },
            crate::lower::model::Pa::PaChar(c) => prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("{} == U'{}'", v_, &cpp_char_escape(c)))])),
            crate::lower::model::Pa::PaBool(b) => prism_rtl::Turn::Finished(Array::from(vec![if *b { v_.clone() } else { Text::from(format!("!{}", v_)) }])),
            crate::lower::model::Pa::PaIndex(n) => prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("{} == {}u", v_, n))])),
            crate::lower::model::Pa::PaConst(n) => prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("{} == {}", v_, n))])),
            crate::lower::model::Pa::PaSlice(ps) => {
                let rest = fold(ps, &false, &(|f: &bool, q: &crate::lower::model::Pa| *f || is_rest(q)));
                let fixed = len(&filter(ps, &(|q: &crate::lower::model::Pa| !is_rest(q))));
                let size_ = if rest {
                    Text::from(format!("{}.size() >= {}", v_, &fixed))
                } else {
                    Text::from(format!("{}.size() == {}", v_, &fixed))
                };
                let cp = cp.clone();
                let ps = ps.clone();
                let v_ = v_.clone();
                call_value(each_job(crate::check::errors::range0(&len(&ps)), {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let v_ = v_.clone();
                    Rc::new(move |p0: Nat| {
                        let cp = cp.clone();
                        let ps = ps.clone();
                        let v_ = v_.clone();
                        entered(once_job(move || {
                            let i = p0;
                            prism_rtl::Turn::More(Rc::new(PatConds { cp: cp.clone(), p_: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), v_: Text::from(format!("{}[{}]", &v_, &i)) }))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_36226: Array<Array<Text>>| prism_rtl::Turn::Finished(append(&Array::from(vec![size_.clone()]), &concat2(&each_36226))))
            },
            crate::lower::model::Pa::PaRest(_) => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start PatConds, x`: what the function value is when passed to `@Run`.
pub fn start_pat_conds(cp: Cp, p_: crate::lower::model::Pa, v_: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(PatConds { cp, p_, v_ })
}

/// ```prism
/// PatBinds: unbounded fn Cp, Pa, Text -> [Text]
/// ```
pub fn pat_binds(cp: &Cp, p_: &crate::lower::model::Pa, v_: &Text) -> Array<Text> {
    'm36395: {
        if let crate::lower::model::Pa::PaWild = p_ {
            break 'm36395 Array::new();
        }
        if let crate::lower::model::Pa::PaBind(n) = p_ {
            break 'm36395 Array::from(vec![Text::from(format!("auto&& {} = {};", &cpp_id(n), v_))]);
        }
        if let crate::lower::model::Pa::PaMut(n) = p_ {
            break 'm36395 Array::from(vec![Text::from(format!("auto {} = {};", &cpp_id(n), v_))]);
        }
        if let crate::lower::model::Pa::PaTyped(m36395_3_0, t) = p_ && let crate::lower::model::Pa::PaBind(n) = &**m36395_3_0 {
            break 'm36395 Array::from(vec![Text::from(format!("{} {} = {};", &cpp_type(cp, &unref(t)), &cpp_id(n), v_))]);
        }
        if let crate::lower::model::Pa::PaTyped(q, _) = p_ {
            break 'm36395 pat_binds(cp, &**q, v_);
        }
        if let crate::lower::model::Pa::PaUnit(_) = p_ {
            break 'm36395 Array::new();
        }
        if let crate::lower::model::Pa::PaCtor(c, ps) = p_ {
            break 'm36395 concat2(&run_to_end(each_job(crate::check::errors::range0(&len(ps)), {
                let cp = cp.clone();
                let ps = ps.clone();
                let c = c.clone();
                let v_ = v_.clone();
                Rc::new(move |p0: Nat| {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let c = c.clone();
                    let v_ = v_.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(PatBinds { cp: cp.clone(), p_: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), v_: payload(&cp, &c, &v_, &i) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            })));
        }
        if let crate::lower::model::Pa::PaRecord(c, fs, _) = p_ {
            break 'm36395 concat2(&run_to_end(each_job(fs.clone(), {
                let cp = cp.clone();
                let v_ = v_.clone();
                Rc::new(move |p0: (Text, crate::lower::model::Pa)| {
                    let cp = cp.clone();
                    let v_ = v_.clone();
                    entered(once_job(move || {
                        let (f, q) = p0;
                        prism_rtl::Turn::More(Rc::new(PatBinds { cp: cp.clone(), p_: q.clone(), v_: Text::from(format!("{}.{}", &v_, &field_id(&f))) }))
                    }))
                }) as Rc<dyn Fn((Text, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            })));
        }
        if let crate::lower::model::Pa::PaTuple(ps) = p_ {
            break 'm36395 concat2(&run_to_end(each_job(crate::check::errors::range0(&len(ps)), {
                let cp = cp.clone();
                let ps = ps.clone();
                let v_ = v_.clone();
                Rc::new(move |p0: Nat| {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let v_ = v_.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(PatBinds { cp: cp.clone(), p_: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), v_: Text::from(format!("std::get<{}>({})", &i, &v_)) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            })));
        }
        if let crate::lower::model::Pa::PaSlice(ps) = p_ {
            break 'm36395 concat2(&run_to_end(each_job(crate::check::errors::range0(&len(ps)), {
                let cp = cp.clone();
                let ps = ps.clone();
                let v_ = v_.clone();
                Rc::new(move |p0: Nat| {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let v_ = v_.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(SliceBinds { cp: cp.clone(), pa1: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), v_: v_.clone(), i: i.clone() }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            })));
        }
        Array::new()
    }
}

/// The step machine of `PatBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatBinds: unbounded fn Cp, Pa, Text -> [Text]
/// ```
pub struct PatBinds {
    pub cp: Cp,
    pub p_: crate::lower::model::Pa,
    pub v_: Text,
}

impl prism_rtl::Job<Array<Text>> for PatBinds {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cp = &self.cp;
        let p_ = &self.p_;
        let v_ = &self.v_;
        'm36395: {
            if let crate::lower::model::Pa::PaWild = p_ {
                break 'm36395 prism_rtl::Turn::Finished(Array::new());
            }
            if let crate::lower::model::Pa::PaBind(n) = p_ {
                break 'm36395 prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("auto&& {} = {};", &cpp_id(n), v_))]));
            }
            if let crate::lower::model::Pa::PaMut(n) = p_ {
                break 'm36395 prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("auto {} = {};", &cpp_id(n), v_))]));
            }
            if let crate::lower::model::Pa::PaTyped(m36395_3_0, t) = p_ && let crate::lower::model::Pa::PaBind(n) = &**m36395_3_0 {
                break 'm36395 {
                    let cp = cp.clone();
                    let n = n.clone();
                    let t = t.clone();
                    let v_ = v_.clone();
                    call_then(start_cpp_type(cp.clone(), unref(&t)), move |cpp_type_36537: Text| prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("{} {} = {};", &cpp_type_36537, &cpp_id(&n), &v_))])))
                };
            }
            if let crate::lower::model::Pa::PaTyped(q, _) = p_ {
                break 'm36395 prism_rtl::Turn::More(Rc::new(PatBinds { cp: cp.clone(), p_: (**q).clone(), v_: v_.clone() }));
            }
            if let crate::lower::model::Pa::PaUnit(_) = p_ {
                break 'm36395 prism_rtl::Turn::Finished(Array::new());
            }
            if let crate::lower::model::Pa::PaCtor(c, ps) = p_ {
                break 'm36395 {
                    let c = c.clone();
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let v_ = v_.clone();
                    call_value(each_job(crate::check::errors::range0(&len(&ps)), {
                        let cp = cp.clone();
                        let ps = ps.clone();
                        let c = c.clone();
                        let v_ = v_.clone();
                        Rc::new(move |p0: Nat| {
                            let cp = cp.clone();
                            let ps = ps.clone();
                            let c = c.clone();
                            let v_ = v_.clone();
                            entered(once_job(move || {
                                let i = p0;
                                prism_rtl::Turn::More(Rc::new(PatBinds { cp: cp.clone(), p_: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), v_: payload(&cp, &c, &v_, &i) }))
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }), move |each_36672: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_36672)))
                };
            }
            if let crate::lower::model::Pa::PaRecord(c, fs, _) = p_ {
                break 'm36395 {
                    let cp = cp.clone();
                    let fs = fs.clone();
                    let v_ = v_.clone();
                    call_value(each_job(fs.clone(), {
                        let cp = cp.clone();
                        let v_ = v_.clone();
                        Rc::new(move |p0: (Text, crate::lower::model::Pa)| {
                            let cp = cp.clone();
                            let v_ = v_.clone();
                            entered(once_job(move || {
                                let (f, q) = p0;
                                prism_rtl::Turn::More(Rc::new(PatBinds { cp: cp.clone(), p_: q.clone(), v_: Text::from(format!("{}.{}", &v_, &field_id(&f))) }))
                            }))
                        }) as Rc<dyn Fn((Text, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }), move |each_36794: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_36794)))
                };
            }
            if let crate::lower::model::Pa::PaTuple(ps) = p_ {
                break 'm36395 {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let v_ = v_.clone();
                    call_value(each_job(crate::check::errors::range0(&len(&ps)), {
                        let cp = cp.clone();
                        let ps = ps.clone();
                        let v_ = v_.clone();
                        Rc::new(move |p0: Nat| {
                            let cp = cp.clone();
                            let ps = ps.clone();
                            let v_ = v_.clone();
                            entered(once_job(move || {
                                let i = p0;
                                prism_rtl::Turn::More(Rc::new(PatBinds { cp: cp.clone(), p_: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), v_: Text::from(format!("std::get<{}>({})", &i, &v_)) }))
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }), move |each_36875: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_36875)))
                };
            }
            if let crate::lower::model::Pa::PaSlice(ps) = p_ {
                break 'm36395 {
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let v_ = v_.clone();
                    call_value(each_job(crate::check::errors::range0(&len(&ps)), {
                        let cp = cp.clone();
                        let ps = ps.clone();
                        let v_ = v_.clone();
                        Rc::new(move |p0: Nat| {
                            let cp = cp.clone();
                            let ps = ps.clone();
                            let v_ = v_.clone();
                            entered(once_job(move || {
                                let i = p0;
                                prism_rtl::Turn::More(Rc::new(SliceBinds { cp: cp.clone(), pa1: or(&index(&ps, &i), &crate::lower::model::Pa::PaWild), v_: v_.clone(), i: i.clone() }))
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }), move |each_36984: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_36984)))
                };
            }
            prism_rtl::Turn::Finished(Array::new())
        }
    }
}

/// `Start PatBinds, x`: what the function value is when passed to `@Run`.
pub fn start_pat_binds(cp: Cp, p_: crate::lower::model::Pa, v_: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(PatBinds { cp, p_, v_ })
}

/// ```prism
/// SliceBinds: unbounded fn Cp, Pa, Text, Nat -> [Text]
/// ```
pub fn slice_binds(cp: &Cp, pa1: &crate::lower::model::Pa, v_: &Text, i: &Nat) -> Array<Text> {
    match pa1 {
        crate::lower::model::Pa::PaRest(c0_1_0) if (c0_1_0 == &Text::lit("")) => Array::new(),
        crate::lower::model::Pa::PaRest(n) => Array::from(vec![Text::from(format!("auto {} = {}.subspan({});", &cpp_id(n), v_, i))]),
        p_ => pat_binds(cp, p_, &Text::from(format!("{}[{}]", v_, i))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `SliceBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SliceBinds: unbounded fn Cp, Pa, Text, Nat -> [Text]
/// ```
pub struct SliceBinds {
    pub cp: Cp,
    pub pa1: crate::lower::model::Pa,
    pub v_: Text,
    pub i: Nat,
}

impl prism_rtl::Job<Array<Text>> for SliceBinds {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cp = &self.cp;
        let pa1 = &self.pa1;
        let v_ = &self.v_;
        let i = &self.i;
        match pa1 {
            crate::lower::model::Pa::PaRest(j0_1_0) if (j0_1_0 == &Text::lit("")) => prism_rtl::Turn::Finished(Array::new()),
            crate::lower::model::Pa::PaRest(n) => prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("auto {} = {}.subspan({});", &cpp_id(n), v_, i))])),
            p_ => prism_rtl::Turn::More(Rc::new(PatBinds { cp: cp.clone(), p_: p_.clone(), v_: Text::from(format!("{}[{}]", v_, i)) })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start SliceBinds, x`: what the function value is when passed to `@Run`.
pub fn start_slice_binds(cp: Cp, pa1: crate::lower::model::Pa, v_: Text, i: Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(SliceBinds { cp, pa1, v_, i })
}

/// ```prism
/// IsRest: fn Pa -> Bool
/// ```
pub fn is_rest(pa0: &crate::lower::model::Pa) -> bool {
    match pa0 {
        crate::lower::model::Pa::PaRest(_) => true,
        other => false,
    }
}

/// ```prism
/// Concat2: fn [ [Text] ] -> [Text]
/// ```
pub fn concat2(xss: &Array<Array<Text>>) -> Array<Text> {
    fold(xss, &Array::new(), &(|acc: &Array<Text>, xs: &Array<Text>| append(acc, xs)))
}

/// ```prism
/// Conds: fn [Text] -> Text
/// ```
pub fn conds(xs0: &Array<Text>) -> Text {
    match xs0 {
        c0_0 if (c0_0.len() == 0) => Text::lit("true"),
        cs => crate::syntax::lexer::join(cs, &Text::lit(" && ")),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IsCatchAll: fn Pa -> Bool
/// ```
pub fn is_catch_all(p_: &crate::lower::model::Pa) -> bool {
    match p_ {
        crate::lower::model::Pa::PaWild => true,
        crate::lower::model::Pa::PaBind(_) => true,
        crate::lower::model::Pa::PaMut(_) => true,
        crate::lower::model::Pa::PaTyped(q, _) => is_catch_all(&**q),
        _ => false,
    }
}

/// ```prism
/// Leaves: fn Ex -> Bool
/// ```
pub fn leaves(x: &crate::lower::model::Ex) -> bool {
    match x {
        crate::lower::model::Ex::XBreak(_, _) => true,
        crate::lower::model::Ex::XBreakLoop => true,
        crate::lower::model::Ex::XUnreachable => true,
        _ => false,
    }
}

/// ```prism
/// CppMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
/// ```
pub fn cpp_match(cp: &Cp, s: &crate::lower::model::Ex, arms: &Array<crate::lower::model::XArm>, out_ty3: &crate::lower::model::OutTy) -> Text {
    match out_ty3 {
        crate::lower::model::OutTy::OutUnknown(what) => ternary_match(cp, s, arms),
        t => {
            let bound_opt = 'm38482: {
                if let crate::lower::model::Ex::XVar(n) = s {
                    break 'm38482 Some(cpp_id(n));
                }
                if let crate::lower::model::Ex::XRef(m38482_1_0) = s && let crate::lower::model::Ex::XVar(n) = &**m38482_1_0 {
                    break 'm38482 Some(cpp_id(n));
                }
                None
            };
            let subject = or(&bound_opt, &Text::lit("_m"));
            let bind = match &bound_opt {
                Some(_) => Text::lit(""),
                None => Text::from(format!("auto&& _m = {};\n", &cpp_expr(cp, s))),
            };
            let lines = run_to_end(each_job(arms.clone(), {
                let cp = cp.clone();
                let subject = subject.clone();
                Rc::new(move |p0: crate::lower::model::XArm| {
                    let cp = cp.clone();
                    let subject = subject.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(MatchArm { cp0: cp.clone(), subject: subject.clone(), a: a.clone(), returns: false }))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            crate::emit::cpp::templates::match_expr(&cpp_type(cp, t), &Text::from(format!("{}{}\n{}", &bind, &crate::syntax::lexer::join(&lines, &Text::lit("\n")), &match_tail(arms))))
        },
    }
}

/// The step machine of `CppMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
/// ```
pub struct CppMatch {
    pub cp: Cp,
    pub s: crate::lower::model::Ex,
    pub arms: Array<crate::lower::model::XArm>,
    pub out_ty3: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for CppMatch {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let s = &self.s;
        let arms = &self.arms;
        let out_ty3 = &self.out_ty3;
        match out_ty3 {
            crate::lower::model::OutTy::OutUnknown(what) => prism_rtl::Turn::More(Rc::new(TernaryMatch { cp: cp.clone(), s: s.clone(), arms: arms.clone() })),
            t => {
                let bound_opt = 'm38482: {
                    if let crate::lower::model::Ex::XVar(n) = s {
                        break 'm38482 Some(cpp_id(n));
                    }
                    if let crate::lower::model::Ex::XRef(m38482_1_0) = s && let crate::lower::model::Ex::XVar(n) = &**m38482_1_0 {
                        break 'm38482 Some(cpp_id(n));
                    }
                    None
                };
                let subject = or(&bound_opt, &Text::lit("_m"));
                let bind = match &bound_opt {
                    Some(_) => Text::lit(""),
                    None => Text::from(format!("auto&& _m = {};\n", &cpp_expr(cp, s))),
                };
                let arms = arms.clone();
                let cp = cp.clone();
                let s = s.clone();
                let t = t.clone();
                call_value(each_job(arms.clone(), {
                    let cp = cp.clone();
                    let subject = subject.clone();
                    Rc::new(move |p0: crate::lower::model::XArm| {
                        let cp = cp.clone();
                        let subject = subject.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(MatchArm { cp0: cp.clone(), subject: subject.clone(), a: a.clone(), returns: false }))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_38723: Array<Text>| {
                    let lines = each_38723;
                    call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_38785: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::match_expr(&cpp_type_38785, &Text::from(format!("{}{}\n{}", &bind, &crate::syntax::lexer::join(&lines, &Text::lit("\n")), &match_tail(&arms))))))
                })
            },
        }
    }
}

/// `Start CppMatch, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_match(cp: Cp, s: crate::lower::model::Ex, arms: Array<crate::lower::model::XArm>, out_ty3: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppMatch { cp, s, arms, out_ty3 })
}

/// ```prism
/// ReturnMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
/// ```
pub fn return_match(cp: &Cp, s: &crate::lower::model::Ex, arms: &Array<crate::lower::model::XArm>, out_ty3: &crate::lower::model::OutTy) -> Text {
    match out_ty3 {
        crate::lower::model::OutTy::OutUnknown(what) => Text::from(format!("return {};", &ternary_match(cp, s, arms))),
        t => {
            let bound_opt = 'm39256: {
                if let crate::lower::model::Ex::XVar(n) = s {
                    break 'm39256 Some(cpp_id(n));
                }
                if let crate::lower::model::Ex::XRef(m39256_1_0) = s && let crate::lower::model::Ex::XVar(n) = &**m39256_1_0 {
                    break 'm39256 Some(cpp_id(n));
                }
                None
            };
            let subject = or(&bound_opt, &Text::lit("_m"));
            let bind = match &bound_opt {
                Some(_) => Text::lit(""),
                None => Text::from(format!("auto&& _m = {};\n", &cpp_expr(cp, s))),
            };
            let lines = run_to_end(each_job(arms.clone(), {
                let cp = cp.clone();
                let subject = subject.clone();
                Rc::new(move |p0: crate::lower::model::XArm| {
                    let cp = cp.clone();
                    let subject = subject.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(MatchArm { cp0: cp.clone(), subject: subject.clone(), a: a.clone(), returns: true }))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            Text::from(format!("{}{}\n{}", &bind, &crate::syntax::lexer::join(&lines, &Text::lit("\n")), &match_tail(arms)))
        },
    }
}

/// The step machine of `ReturnMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReturnMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
/// ```
pub struct ReturnMatch {
    pub cp: Cp,
    pub s: crate::lower::model::Ex,
    pub arms: Array<crate::lower::model::XArm>,
    pub out_ty3: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for ReturnMatch {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let s = &self.s;
        let arms = &self.arms;
        let out_ty3 = &self.out_ty3;
        match out_ty3 {
            crate::lower::model::OutTy::OutUnknown(what) => {
                let arms = arms.clone();
                let cp = cp.clone();
                let s = s.clone();
                call_then(start_ternary_match(cp.clone(), s.clone(), arms.clone()), move |ternary_match_39180: Text| prism_rtl::Turn::Finished(Text::from(format!("return {};", &ternary_match_39180))))
            },
            t => {
                let bound_opt = 'm39256: {
                    if let crate::lower::model::Ex::XVar(n) = s {
                        break 'm39256 Some(cpp_id(n));
                    }
                    if let crate::lower::model::Ex::XRef(m39256_1_0) = s && let crate::lower::model::Ex::XVar(n) = &**m39256_1_0 {
                        break 'm39256 Some(cpp_id(n));
                    }
                    None
                };
                let subject = or(&bound_opt, &Text::lit("_m"));
                let bind = match &bound_opt {
                    Some(_) => Text::lit(""),
                    None => Text::from(format!("auto&& _m = {};\n", &cpp_expr(cp, s))),
                };
                let arms = arms.clone();
                let cp = cp.clone();
                let s = s.clone();
                call_value(each_job(arms.clone(), {
                    let cp = cp.clone();
                    let subject = subject.clone();
                    Rc::new(move |p0: crate::lower::model::XArm| {
                        let cp = cp.clone();
                        let subject = subject.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(MatchArm { cp0: cp.clone(), subject: subject.clone(), a: a.clone(), returns: true }))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_39497: Array<Text>| {
                    let lines = each_39497;
                    prism_rtl::Turn::Finished(Text::from(format!("{}{}\n{}", &bind, &crate::syntax::lexer::join(&lines, &Text::lit("\n")), &match_tail(&arms))))
                })
            },
        }
    }
}

/// `Start ReturnMatch, x`: what the function value is when passed to `@Run`.
pub fn start_return_match(cp: Cp, s: crate::lower::model::Ex, arms: Array<crate::lower::model::XArm>, out_ty3: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ReturnMatch { cp, s, arms, out_ty3 })
}

/// ```prism
/// MatchTail: fn [XArm] -> Text
/// ```
pub fn match_tail(arms: &Array<crate::lower::model::XArm>) -> Text {
    let ends = match crate::syntax::lexer::last(arms) {
        Some(a) => is_catch_all(&a.pat) && (&len(&a.conds) == &Nat::from(0u32)),
        None => false,
    };
    if ends {
        Text::lit("")
    } else {
        Text::lit("prism_rtl::unreachable(\"no arm matched\");\n")
    }
}

/// ```prism
/// TernaryMatch: unbounded fn Cp, Ex, [XArm] -> Text
/// ```
pub fn ternary_match(cp: &Cp, s: &crate::lower::model::Ex, arms: &Array<crate::lower::model::XArm>) -> Text {
    let bound_opt = 'm40229: {
        if let crate::lower::model::Ex::XVar(n) = s {
            break 'm40229 Some(var_name(cp, n));
        }
        if let crate::lower::model::Ex::XRef(m40229_1_0) = s && let crate::lower::model::Ex::XVar(n) = &**m40229_1_0 {
            break 'm40229 Some(var_name(cp, n));
        }
        None
    };
    let subject = or(&bound_opt, &Text::lit("_m"));
    let bind = match &bound_opt {
        Some(_) => Text::lit(""),
        None => Text::from(format!("auto&& _m = {};\n", &cpp_expr(cp, s))),
    };
    let reached = run_to_end(fold_job(arms.clone(), (Array::new(), false), {
        let cp = cp.clone();
        let subject = subject.clone();
        Rc::new(move |(p0, p1): ((Array<crate::lower::model::XArm>, bool), crate::lower::model::XArm)| {
            let cp = cp.clone();
            let subject = subject.clone();
            entered(once_job(move || {
                let (acc, done) = p0;
                let a = p1;
                if done {
                    prism_rtl::Turn::Finished((acc.clone(), done))
                } else {
                    call_then(start_pat_conds(cp.clone(), a.pat.clone(), subject.clone()), move |pat_conds_40668: Array<Text>| prism_rtl::Turn::Finished((push(&acc, &a), (&len(&pat_conds_40668) == &Nat::from(0u32)) && (&len(&a.conds) == &Nat::from(0u32)))))
                }
            }))
        }) as Rc<dyn Fn(((Array<crate::lower::model::XArm>, bool), crate::lower::model::XArm)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::XArm>, bool)>>>
    }));
    let (kept, ends) = reached.clone();
    let parts = run_to_end(each_job(kept.clone(), {
        let cp = cp.clone();
        let subject = subject.clone();
        Rc::new(move |p0: crate::lower::model::XArm| {
            let cp = cp.clone();
            let subject = subject.clone();
            entered(once_job(move || {
                let a = p0;
                prism_rtl::Turn::More(Rc::new(TernaryArm { cp0: cp.clone(), subject: subject.clone(), a: a.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let last_text = if ends {
        Text::lit("")
    } else {
        Text::lit("\n    : throw prism_rtl::Panic(\"no arm matched\")")
    };
    crate::emit::cpp::templates::stmt_expr(&Text::from(format!("{}", &bind)), &Text::from(format!("{}{}", &crate::syntax::lexer::join(&parts, &Text::lit("\n    : ")), &last_text)))
}

/// The step machine of `TernaryMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TernaryMatch: unbounded fn Cp, Ex, [XArm] -> Text
/// ```
pub struct TernaryMatch {
    pub cp: Cp,
    pub s: crate::lower::model::Ex,
    pub arms: Array<crate::lower::model::XArm>,
}

impl prism_rtl::Job<Text> for TernaryMatch {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let s = &self.s;
        let arms = &self.arms;
        let bound_opt = 'm40229: {
            if let crate::lower::model::Ex::XVar(n) = s {
                break 'm40229 Some(var_name(cp, n));
            }
            if let crate::lower::model::Ex::XRef(m40229_1_0) = s && let crate::lower::model::Ex::XVar(n) = &**m40229_1_0 {
                break 'm40229 Some(var_name(cp, n));
            }
            None
        };
        let subject = or(&bound_opt, &Text::lit("_m"));
        let bind = match &bound_opt {
            Some(_) => Text::lit(""),
            None => Text::from(format!("auto&& _m = {};\n", &cpp_expr(cp, s))),
        };
        let arms = arms.clone();
        let cp = cp.clone();
        call_value(fold_job(arms.clone(), (Array::new(), false), {
            let cp = cp.clone();
            let subject = subject.clone();
            Rc::new(move |(p0, p1): ((Array<crate::lower::model::XArm>, bool), crate::lower::model::XArm)| {
                let cp = cp.clone();
                let subject = subject.clone();
                entered(once_job(move || {
                    let (acc, done) = p0;
                    let a = p1;
                    if done {
                        prism_rtl::Turn::Finished((acc.clone(), done))
                    } else {
                        call_then(start_pat_conds(cp.clone(), a.pat.clone(), subject.clone()), move |pat_conds_40668: Array<Text>| prism_rtl::Turn::Finished((push(&acc, &a), (&len(&pat_conds_40668) == &Nat::from(0u32)) && (&len(&a.conds) == &Nat::from(0u32)))))
                    }
                }))
            }) as Rc<dyn Fn(((Array<crate::lower::model::XArm>, bool), crate::lower::model::XArm)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::XArm>, bool)>>>
        }), move |fold_40568: (Array<crate::lower::model::XArm>, bool)| {
            let reached = fold_40568;
            let (kept, ends) = reached.clone();
            call_value(each_job(kept.clone(), {
                let cp = cp.clone();
                let subject = subject.clone();
                Rc::new(move |p0: crate::lower::model::XArm| {
                    let cp = cp.clone();
                    let subject = subject.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(TernaryArm { cp0: cp.clone(), subject: subject.clone(), a: a.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_40777: Array<Text>| {
                let parts = each_40777;
                let last_text = if ends {
                    Text::lit("")
                } else {
                    Text::lit("\n    : throw prism_rtl::Panic(\"no arm matched\")")
                };
                prism_rtl::Turn::Finished(crate::emit::cpp::templates::stmt_expr(&Text::from(format!("{}", &bind)), &Text::from(format!("{}{}", &crate::syntax::lexer::join(&parts, &Text::lit("\n    : ")), &last_text))))
            })
        })
    }
}

/// `Start TernaryMatch, x`: what the function value is when passed to `@Run`.
pub fn start_ternary_match(cp: Cp, s: crate::lower::model::Ex, arms: Array<crate::lower::model::XArm>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TernaryMatch { cp, s, arms })
}

/// ```prism
/// TernaryArm: unbounded fn Cp, Text, XArm -> Text
/// ```
pub fn ternary_arm(cp0: &Cp, subject: &Text, a: &crate::lower::model::XArm) -> Text {
    let cp = unbind(cp0, &arm_names(a));
    let tests = pat_conds(&cp, &a.pat, subject);
    let binds = pat_binds(&cp, &a.pat, subject);
    let n = len(&a.conds);
    let lets = concat2(&run_to_end(each_job(crate::check::errors::range0(&n), {
        let cp = cp.clone();
        let a = a.clone();
        let n = n.clone();
        Rc::new(move |p0: Nat| {
            let cp = cp.clone();
            let a = a.clone();
            let n = n.clone();
            entered(once_job(move || {
                let i = p0;
                prism_rtl::Turn::More(Rc::new(CondBinds { cp: cp.clone(), cc1: or(&index(&a.conds, &i), &crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XUnit)), k: or(&(&n).checked_sub(&i), &Nat::from(0u32)) }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    })));
    let value = if &(&len(&binds) + &len(&lets)) == &Nat::from(0u32) {
        cpp_expr(&cp, &a.body)
    } else {
        crate::emit::cpp::templates::stmt_expr(&crate::syntax::lexer::join(&append(&binds, &lets), &Text::lit("\n")), &cpp_expr(&cp, &a.body))
    };
    let guard = if &len(&a.conds) == &Nat::from(0u32) {
        Array::new()
    } else {
        Array::from(vec![crate::emit::cpp::templates::stmt_expr(&crate::syntax::lexer::join(&binds, &Text::lit("\n")), &guard_test(&cp, &a.conds))])
    };
    let all = append(&tests, &guard);
    if &len(&all) == &Nat::from(0u32) {
        value.clone()
    } else {
        Text::from(format!("{} ? {}", &conds(&all), &value))
    }
}

/// The step machine of `TernaryArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TernaryArm: unbounded fn Cp, Text, XArm -> Text
/// ```
pub struct TernaryArm {
    pub cp0: Cp,
    pub subject: Text,
    pub a: crate::lower::model::XArm,
}

impl prism_rtl::Job<Text> for TernaryArm {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp0 = &self.cp0;
        let subject = &self.subject;
        let a = &self.a;
        let a = a.clone();
        let cp0 = cp0.clone();
        let subject = subject.clone();
        call_then(start_arm_names(a.clone()), move |arm_names_41075: Array<Text>| {
            let cp = unbind(&cp0, &arm_names_41075);
            call_then(start_pat_conds(cp.clone(), a.pat.clone(), subject.clone()), move |pat_conds_41103: Array<Text>| {
                let tests = pat_conds_41103;
                call_then(start_pat_binds(cp.clone(), a.pat.clone(), subject.clone()), move |pat_binds_41147: Array<Text>| {
                    let binds = pat_binds_41147;
                    let n = len(&a.conds);
                    call_value(each_job(crate::check::errors::range0(&n), {
                        let cp = cp.clone();
                        let a = a.clone();
                        let n = n.clone();
                        Rc::new(move |p0: Nat| {
                            let cp = cp.clone();
                            let a = a.clone();
                            let n = n.clone();
                            entered(once_job(move || {
                                let i = p0;
                                prism_rtl::Turn::More(Rc::new(CondBinds { cp: cp.clone(), cc1: or(&index(&a.conds, &i), &crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XUnit)), k: or(&(&n).checked_sub(&i), &Nat::from(0u32)) }))
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }), move |each_41223: Array<Array<Text>>| {
                        let lets = concat2(&each_41223);
                        let value = if &(&len(&binds) + &len(&lets)) == &Nat::from(0u32) {
                            cpp_expr(&cp, &a.body)
                        } else {
                            crate::emit::cpp::templates::stmt_expr(&crate::syntax::lexer::join(&append(&binds, &lets), &Text::lit("\n")), &cpp_expr(&cp, &a.body))
                        };
                        let guard = if &len(&a.conds) == &Nat::from(0u32) {
                            Array::new()
                        } else {
                            Array::from(vec![crate::emit::cpp::templates::stmt_expr(&crate::syntax::lexer::join(&binds, &Text::lit("\n")), &guard_test(&cp, &a.conds))])
                        };
                        let all = append(&tests, &guard);
                        if &len(&all) == &Nat::from(0u32) {
                            prism_rtl::Turn::Finished(value.clone())
                        } else {
                            prism_rtl::Turn::Finished(Text::from(format!("{} ? {}", &conds(&all), &value)))
                        }
                    })
                })
            })
        })
    }
}

/// `Start TernaryArm, x`: what the function value is when passed to `@Run`.
pub fn start_ternary_arm(cp0: Cp, subject: Text, a: crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TernaryArm { cp0, subject, a })
}

/// ```prism
/// CondBinds: unbounded fn Cp, Cc, Nat -> [Text]
/// ```
pub fn cond_binds(cp: &Cp, cc1: &crate::lower::model::Cc, k: &Nat) -> Array<Text> {
    match cc1 {
        crate::lower::model::Cc::CcLet(p_, x) => {
            let (v_, pre) = cond_subject(cp, x, k);
            append(&pre, &pat_binds(cp, p_, &v_))
        },
        crate::lower::model::Cc::CcIf(x) => Array::new(),
    }
}

/// The step machine of `CondBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondBinds: unbounded fn Cp, Cc, Nat -> [Text]
/// ```
pub struct CondBinds {
    pub cp: Cp,
    pub cc1: crate::lower::model::Cc,
    pub k: Nat,
}

impl prism_rtl::Job<Array<Text>> for CondBinds {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cp = &self.cp;
        let cc1 = &self.cc1;
        let k = &self.k;
        match cc1 {
            crate::lower::model::Cc::CcLet(p_, x) => {
                let cp = cp.clone();
                let k = k.clone();
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_cond_subject(cp.clone(), x.clone(), k.clone()), move |cond_subject_41752: (Text, Array<Text>)| {
                    let (v_, pre) = cond_subject_41752;
                    call_then(start_pat_binds(cp.clone(), p_.clone(), v_.clone()), move |pat_binds_41790: Array<Text>| prism_rtl::Turn::Finished(append(&pre, &pat_binds_41790)))
                })
            },
            crate::lower::model::Cc::CcIf(x) => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start CondBinds, x`: what the function value is when passed to `@Run`.
pub fn start_cond_binds(cp: Cp, cc1: crate::lower::model::Cc, k: Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(CondBinds { cp, cc1, k })
}

/// ```prism
/// CondSubject: unbounded fn Cp, Ex, Nat -> ((Text, [Text]))
/// ```
pub fn cond_subject(cp: &Cp, x: &crate::lower::model::Ex, k: &Nat) -> (Text, Array<Text>) {
    if is_place_ex(x) {
        (cpp_tight(cp, x), Array::new())
    } else {
        (Text::from(format!("_c{}", k)), Array::from(vec![Text::from(format!("auto&& _c{} = {};", k, &cpp_expr(cp, x)))]))
    }
}

/// The step machine of `CondSubject`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondSubject: unbounded fn Cp, Ex, Nat -> ((Text, [Text]))
/// ```
pub struct CondSubject {
    pub cp: Cp,
    pub x: crate::lower::model::Ex,
    pub k: Nat,
}

impl prism_rtl::Job<(Text, Array<Text>)> for CondSubject {
    fn cycle(&self) -> prism_rtl::Turn<(Text, Array<Text>)> {
        let cp = &self.cp;
        let x = &self.x;
        let k = &self.k;
        if is_place_ex(x) {
            {
                let cp = cp.clone();
                let x = x.clone();
                call_then(start_cpp_tight(cp.clone(), x.clone()), move |cpp_tight_42207: Text| prism_rtl::Turn::Finished((cpp_tight_42207, Array::new())))
            }
        } else {
            {
                let cp = cp.clone();
                let k = k.clone();
                let x = x.clone();
                call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_42267: Text| prism_rtl::Turn::Finished((Text::from(format!("_c{}", &k)), Array::from(vec![Text::from(format!("auto&& _c{} = {};", &k, &cpp_expr_42267))]))))
            }
        }
    }
}

/// `Start CondSubject, x`: what the function value is when passed to `@Run`.
pub fn start_cond_subject(cp: Cp, x: crate::lower::model::Ex, k: Nat) -> Rc<dyn prism_rtl::Job<(Text, Array<Text>)>> {
    Rc::new(CondSubject { cp, x, k })
}

/// ```prism
/// IsPlaceEx: fn Ex -> Bool
/// ```
pub fn is_place_ex(x: &crate::lower::model::Ex) -> bool {
    match x {
        crate::lower::model::Ex::XVar(_) => true,
        crate::lower::model::Ex::XField(y, _) => is_place_ex(&**y),
        crate::lower::model::Ex::XPart(y, _) => is_place_ex(&**y),
        crate::lower::model::Ex::XTarget(_) => true,
        crate::lower::model::Ex::XSelf => true,
        crate::lower::model::Ex::XRef(y) => is_place_ex(&**y),
        crate::lower::model::Ex::XDeref(y) => is_place_ex(&**y),
        _ => false,
    }
}

/// ```prism
/// GuardTest: unbounded fn Cp, [Cc] -> Text
/// ```
pub fn guard_test(cp: &Cp, xs1: &Array<crate::lower::model::Cc>) -> Text {
    match xs1 {
        c0_1 if (c0_1.len() == 0) => Text::lit("true"),
        cs => {
            let first_ = or(&index(cs, &Nat::from(0u32)), &crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XUnit));
            let rest = guard_test(cp, &drop(cs, &Nat::from(1u32)));
            match &first_ {
                crate::lower::model::Cc::CcIf(x) => if &len(cs) == &Nat::from(1u32) {
                    cpp_tight(cp, x)
                } else {
                    Text::from(format!("{} && {}", &cpp_tight(cp, x), &rest))
                },
                crate::lower::model::Cc::CcLet(p_, x) => {
                    let (v_, pre) = cond_subject(cp, x, &len(cs));
                    let tests = conds(&pat_conds(cp, p_, &v_));
                    let whole = if &len(cs) == &Nat::from(1u32) {
                        tests.clone()
                    } else {
                        Text::from(format!("{} && {}", &tests, &crate::emit::cpp::templates::stmt_expr(&crate::syntax::lexer::join(&pat_binds(cp, p_, &v_), &Text::lit("\n")), &rest)))
                    };
                    if &len(&pre) == &Nat::from(0u32) {
                        whole.clone()
                    } else {
                        crate::emit::cpp::templates::stmt_expr(&crate::syntax::lexer::join(&pre, &Text::lit("\n")), &whole)
                    }
                },
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `GuardTest`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GuardTest: unbounded fn Cp, [Cc] -> Text
/// ```
pub struct GuardTest {
    pub cp: Cp,
    pub xs1: Array<crate::lower::model::Cc>,
}

impl prism_rtl::Job<Text> for GuardTest {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let xs1 = &self.xs1;
        match xs1 {
            j0_1 if (j0_1.len() == 0) => prism_rtl::Turn::Finished(Text::lit("true")),
            cs => {
                let first_ = or(&index(cs, &Nat::from(0u32)), &crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XUnit));
                let cp = cp.clone();
                let cs = cs.clone();
                call_then(start_guard_test(cp.clone(), drop(&cs, &Nat::from(1u32))), move |guard_test_42771: Text| {
                    let rest = guard_test_42771;
                    match &first_ {
                        crate::lower::model::Cc::CcIf(x) => if &len(&cs) == &Nat::from(1u32) {
                            prism_rtl::Turn::More(Rc::new(CppTight { cp: cp.clone(), x: x.clone() }))
                        } else {
                            {
                                let x = x.clone();
                                call_then(start_cpp_tight(cp.clone(), x.clone()), move |cpp_tight_42872: Text| prism_rtl::Turn::Finished(Text::from(format!("{} && {}", &cpp_tight_42872, &rest))))
                            }
                        },
                        crate::lower::model::Cc::CcLet(p_, x) => {
                            let p_ = p_.clone();
                            let x = x.clone();
                            call_then(start_cond_subject(cp.clone(), x.clone(), len(&cs)), move |cond_subject_42948: (Text, Array<Text>)| {
                                let (v_, pre) = cond_subject_42948;
                                call_then(start_pat_conds(cp.clone(), p_.clone(), v_.clone()), move |pat_conds_43007: Array<Text>| {
                                    let tests = conds(&pat_conds_43007);
                                    let whole = if &len(&cs) == &Nat::from(1u32) {
                                        tests.clone()
                                    } else {
                                        Text::from(format!("{} && {}", &tests, &crate::emit::cpp::templates::stmt_expr(&crate::syntax::lexer::join(&pat_binds(&cp, &p_, &v_), &Text::lit("\n")), &rest)))
                                    };
                                    if &len(&pre) == &Nat::from(0u32) {
                                        prism_rtl::Turn::Finished(whole.clone())
                                    } else {
                                        prism_rtl::Turn::Finished(crate::emit::cpp::templates::stmt_expr(&crate::syntax::lexer::join(&pre, &Text::lit("\n")), &whole))
                                    }
                                })
                            })
                        },
                    }
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start GuardTest, x`: what the function value is when passed to `@Run`.
pub fn start_guard_test(cp: Cp, xs1: Array<crate::lower::model::Cc>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(GuardTest { cp, xs1 })
}

/// ```prism
/// MatchArm: unbounded fn Cp, Text, XArm, Bool -> Text
/// ```
pub fn match_arm(cp0: &Cp, subject: &Text, a: &crate::lower::model::XArm, returns: &bool) -> Text {
    let cp = unbind(cp0, &arm_names(a));
    let tests = pat_conds(&cp, &a.pat, subject);
    let binds = pat_binds(&cp, &a.pat, subject);
    let body = if *returns {
        cpp_body(&cp, &a.body)
    } else {
        if leaves(&a.body) {
            Text::from(format!("{};", &cpp_expr(&cp, &a.body)))
        } else {
            Text::from(format!("_v.set({});\ngoto _done;", &cpp_expr(&cp, &a.body)))
        }
    };
    let guarded = if &len(&a.conds) == &Nat::from(0u32) {
        body.clone()
    } else {
        guarded_arm(&cp, &a.conds, &body)
    };
    let inner = crate::syntax::lexer::join(&append(&binds, &Array::from(vec![guarded.clone()])), &Text::lit("\n"));
    if &len(&tests) == &Nat::from(0u32) {
        crate::emit::cpp::templates::braced(&inner)
    } else {
        crate::emit::cpp::templates::if_block(&conds(&tests), &inner)
    }
}

/// The step machine of `MatchArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MatchArm: unbounded fn Cp, Text, XArm, Bool -> Text
/// ```
pub struct MatchArm {
    pub cp0: Cp,
    pub subject: Text,
    pub a: crate::lower::model::XArm,
    pub returns: bool,
}

impl prism_rtl::Job<Text> for MatchArm {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp0 = &self.cp0;
        let subject = &self.subject;
        let a = &self.a;
        let returns = &self.returns;
        let a = a.clone();
        let cp0 = cp0.clone();
        let returns = *returns;
        let subject = subject.clone();
        call_then(start_arm_names(a.clone()), move |arm_names_43465: Array<Text>| {
            let cp = unbind(&cp0, &arm_names_43465);
            call_then(start_pat_conds(cp.clone(), a.pat.clone(), subject.clone()), move |pat_conds_43493: Array<Text>| {
                let tests = pat_conds_43493;
                call_then(start_pat_binds(cp.clone(), a.pat.clone(), subject.clone()), move |pat_binds_43537: Array<Text>| {
                    let binds = pat_binds_43537;
                    let body = if returns {
                        cpp_body(&cp, &a.body)
                    } else {
                        if leaves(&a.body) {
                            Text::from(format!("{};", &cpp_expr(&cp, &a.body)))
                        } else {
                            Text::from(format!("_v.set({});\ngoto _done;", &cpp_expr(&cp, &a.body)))
                        }
                    };
                    let guarded = if &len(&a.conds) == &Nat::from(0u32) {
                        body.clone()
                    } else {
                        guarded_arm(&cp, &a.conds, &body)
                    };
                    let inner = crate::syntax::lexer::join(&append(&binds, &Array::from(vec![guarded.clone()])), &Text::lit("\n"));
                    if &len(&tests) == &Nat::from(0u32) {
                        prism_rtl::Turn::Finished(crate::emit::cpp::templates::braced(&inner))
                    } else {
                        prism_rtl::Turn::Finished(crate::emit::cpp::templates::if_block(&conds(&tests), &inner))
                    }
                })
            })
        })
    }
}

/// `Start MatchArm, x`: what the function value is when passed to `@Run`.
pub fn start_match_arm(cp0: Cp, subject: Text, a: crate::lower::model::XArm, returns: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(MatchArm { cp0, subject, a, returns })
}

/// ```prism
/// GuardedArm: unbounded fn Cp, [Cc], Text -> Text
/// ```
pub fn guarded_arm(cp: &Cp, xs1: &Array<crate::lower::model::Cc>, body: &Text) -> Text {
    match xs1 {
        c0_1 if (c0_1.len() == 0) => body.clone(),
        cs => {
            let first_ = or(&index(cs, &Nat::from(0u32)), &crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XUnit));
            let rest = guarded_arm(cp, &drop(cs, &Nat::from(1u32)), body);
            match &first_ {
                crate::lower::model::Cc::CcIf(x) => crate::emit::cpp::templates::if_block(&cpp_expr(cp, x), &rest),
                crate::lower::model::Cc::CcLet(p_, x) => {
                    let (v_, pre) = cond_subject(cp, x, &len(cs));
                    let inner = crate::emit::cpp::templates::if_block(&conds(&pat_conds(cp, p_, &v_)), &crate::syntax::lexer::join(&append(&pat_binds(cp, p_, &v_), &Array::from(vec![rest.clone()])), &Text::lit("\n")));
                    if &len(&pre) == &Nat::from(0u32) {
                        inner.clone()
                    } else {
                        crate::emit::cpp::templates::braced(&crate::syntax::lexer::join(&push(&pre, &inner), &Text::lit("\n")))
                    }
                },
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `GuardedArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GuardedArm: unbounded fn Cp, [Cc], Text -> Text
/// ```
pub struct GuardedArm {
    pub cp: Cp,
    pub xs1: Array<crate::lower::model::Cc>,
    pub body: Text,
}

impl prism_rtl::Job<Text> for GuardedArm {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let xs1 = &self.xs1;
        let body = &self.body;
        match xs1 {
            j0_1 if (j0_1.len() == 0) => prism_rtl::Turn::Finished(body.clone()),
            cs => {
                let first_ = or(&index(cs, &Nat::from(0u32)), &crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XUnit));
                let body = body.clone();
                let cp = cp.clone();
                let cs = cs.clone();
                call_then(start_guarded_arm(cp.clone(), drop(&cs, &Nat::from(1u32)), body.clone()), move |guarded_arm_44174: Text| {
                    let rest = guarded_arm_44174;
                    match &first_ {
                        crate::lower::model::Cc::CcIf(x) => {
                            let x = x.clone();
                            call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_44250: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::if_block(&cpp_expr_44250, &rest)))
                        },
                        crate::lower::model::Cc::CcLet(p_, x) => {
                            let p_ = p_.clone();
                            let x = x.clone();
                            call_then(start_cond_subject(cp.clone(), x.clone(), len(&cs)), move |cond_subject_44320: (Text, Array<Text>)| {
                                let (v_, pre) = cond_subject_44320;
                                call_then(start_pat_conds(cp.clone(), p_.clone(), v_.clone()), move |pat_conds_44388: Array<Text>| call_then(start_pat_binds(cp.clone(), p_.clone(), v_.clone()), move |pat_binds_44424: Array<Text>| {
                                    let inner = crate::emit::cpp::templates::if_block(&conds(&pat_conds_44388), &crate::syntax::lexer::join(&append(&pat_binds_44424, &Array::from(vec![rest.clone()])), &Text::lit("\n")));
                                    if &len(&pre) == &Nat::from(0u32) {
                                        prism_rtl::Turn::Finished(inner.clone())
                                    } else {
                                        prism_rtl::Turn::Finished(crate::emit::cpp::templates::braced(&crate::syntax::lexer::join(&push(&pre, &inner), &Text::lit("\n"))))
                                    }
                                }))
                            })
                        },
                    }
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start GuardedArm, x`: what the function value is when passed to `@Run`.
pub fn start_guarded_arm(cp: Cp, xs1: Array<crate::lower::model::Cc>, body: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(GuardedArm { cp, xs1, body })
}

/// ```prism
/// CppLabeled: unbounded fn Cp, Text, [Do], Ex, OutTy -> Text
/// ```
pub fn cpp_labeled(cp: &Cp, label: &Text, dos: &Array<crate::lower::model::Do>, e: &crate::lower::model::Ex, t: &crate::lower::model::OutTy) -> Text {
    let l = cpp_label(label);
    let last = if leaves(e) {
        Text::from(format!("{};", &cpp_expr(cp, e)))
    } else {
        Text::from(format!("{}_v.set({});", &l, &cpp_expr(cp, e)))
    };
    crate::emit::cpp::templates::labeled_expr(&l, &cpp_type(cp, t), &crate::syntax::lexer::join(&push(&run_to_end(each_job(dos.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::Do| {
            let cp = cp.clone();
            entered(once_job(move || {
                let d = p0;
                prism_rtl::Turn::More(Rc::new(CppStatement { cp: cp.clone(), d: d.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &last), &Text::lit("\n")))
}

/// The step machine of `CppLabeled`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppLabeled: unbounded fn Cp, Text, [Do], Ex, OutTy -> Text
/// ```
pub struct CppLabeled {
    pub cp: Cp,
    pub label: Text,
    pub dos: Array<crate::lower::model::Do>,
    pub e: crate::lower::model::Ex,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for CppLabeled {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let label = &self.label;
        let dos = &self.dos;
        let e = &self.e;
        let t = &self.t;
        let l = cpp_label(label);
        let last = if leaves(e) {
            Text::from(format!("{};", &cpp_expr(cp, e)))
        } else {
            Text::from(format!("{}_v.set({});", &l, &cpp_expr(cp, e)))
        };
        let cp = cp.clone();
        let dos = dos.clone();
        let t = t.clone();
        call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_44850: Text| call_value(each_job(dos.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: crate::lower::model::Do| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let d = p0;
                    prism_rtl::Turn::More(Rc::new(CppStatement { cp: cp.clone(), d: d.clone() }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_44879: Array<Text>| prism_rtl::Turn::Finished(crate::emit::cpp::templates::labeled_expr(&l, &cpp_type_44850, &crate::syntax::lexer::join(&push(&each_44879, &last), &Text::lit("\n"))))))
    }
}

/// `Start CppLabeled, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_labeled(cp: Cp, label: Text, dos: Array<crate::lower::model::Do>, e: crate::lower::model::Ex, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppLabeled { cp, label, dos, e, t })
}

/// ```prism
/// CppLabel: fn Text -> Text
/// ```
pub fn cpp_label(l: &Text) -> Text {
    if crate::syntax::lexer::has_prefix(l, &Text::lit("'")) {
        crate::syntax::lexer::after_first(l)
    } else {
        l.clone()
    }
}

/// ```prism
/// CppBreak: unbounded fn Cp, Text, Ex -> Text
/// ```
pub fn cpp_break(cp: &Cp, l: &Text, y: &crate::lower::model::Ex) -> Text {
    let n = cpp_label(l);
    Text::from(format!("{{ {}_v.set({}); goto {}; }}", &n, &cpp_expr(cp, y), &n))
}

/// The step machine of `CppBreak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppBreak: unbounded fn Cp, Text, Ex -> Text
/// ```
pub struct CppBreak {
    pub cp: Cp,
    pub l: Text,
    pub y: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppBreak {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let l = &self.l;
        let y = &self.y;
        let n = cpp_label(l);
        let cp = cp.clone();
        let y = y.clone();
        call_then(start_cpp_expr(cp.clone(), y.clone()), move |cpp_expr_45124: Text| prism_rtl::Turn::Finished(Text::from(format!("{{ {}_v.set({}); goto {}; }}", &n, &cpp_expr_45124, &n))))
    }
}

/// `Start CppBreak, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_break(cp: Cp, l: Text, y: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppBreak { cp, l, y })
}

/// ```prism
/// CppStatements: unbounded fn Cp, [Do] -> Text
/// ```
pub fn cpp_statements(cp: &Cp, dos: &Array<crate::lower::model::Do>) -> Text {
    let (st, _) = cpp_statements_cp(cp, dos);
    st.clone()
}

/// The step machine of `CppStatements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppStatements: unbounded fn Cp, [Do] -> Text
/// ```
pub struct CppStatements {
    pub cp: Cp,
    pub dos: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for CppStatements {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let dos = &self.dos;
        let cp = cp.clone();
        let dos = dos.clone();
        call_then(start_cpp_statements_cp(cp.clone(), dos.clone()), move |cpp_statements_cp_45553: (Text, Cp)| {
            let (st, _) = cpp_statements_cp_45553;
            prism_rtl::Turn::Finished(st.clone())
        })
    }
}

/// `Start CppStatements, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_statements(cp: Cp, dos: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppStatements { cp, dos })
}

/// ```prism
/// CppStatementsCp: unbounded fn Cp, [Do] -> ((Text, Cp))
/// ```
pub fn cpp_statements_cp(cp: &Cp, dos: &Array<crate::lower::model::Do>) -> (Text, Cp) {
    let (lines, last) = run_to_end(fold_job(dos.clone(), (Array::new(), cp.clone()), Rc::new(move |(p0, p1): ((Array<Text>, Cp), crate::lower::model::Do)| entered(once_job(move || {
        let (acc, c) = p0;
        let d = p1;
        call_then(start_rebound(c.clone(), d.clone()), move |rebound_45980: Cp| {
            let c2 = rebound_45980;
            let line = match &d {
                crate::lower::model::Do::DoLet(p_, x) => cpp_let(&c, &c2, p_, x),
                _ => cpp_statement(&c2, &d),
            };
            prism_rtl::Turn::Finished((push(&acc, &line), c2.clone()))
        })
    }))) as Rc<dyn Fn(((Array<Text>, Cp), crate::lower::model::Do)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Cp)>>>));
    (crate::syntax::lexer::join(&lines, &Text::lit("\n")), last.clone())
}

/// The step machine of `CppStatementsCp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppStatementsCp: unbounded fn Cp, [Do] -> ((Text, Cp))
/// ```
pub struct CppStatementsCp {
    pub cp: Cp,
    pub dos: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<(Text, Cp)> for CppStatementsCp {
    fn cycle(&self) -> prism_rtl::Turn<(Text, Cp)> {
        let cp = &self.cp;
        let dos = &self.dos;
        let cp = cp.clone();
        let dos = dos.clone();
        call_value(fold_job(dos.clone(), (Array::new(), cp.clone()), Rc::new(move |(p0, p1): ((Array<Text>, Cp), crate::lower::model::Do)| entered(once_job(move || {
            let (acc, c) = p0;
            let d = p1;
            call_then(start_rebound(c.clone(), d.clone()), move |rebound_45980: Cp| {
                let c2 = rebound_45980;
                let line = match &d {
                    crate::lower::model::Do::DoLet(p_, x) => cpp_let(&c, &c2, p_, x),
                    _ => cpp_statement(&c2, &d),
                };
                prism_rtl::Turn::Finished((push(&acc, &line), c2.clone()))
            })
        }))) as Rc<dyn Fn(((Array<Text>, Cp), crate::lower::model::Do)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Cp)>>>), move |fold_45922: (Array<Text>, Cp)| {
            let (lines, last) = fold_45922;
            prism_rtl::Turn::Finished((crate::syntax::lexer::join(&lines, &Text::lit("\n")), last.clone()))
        })
    }
}

/// `Start CppStatementsCp, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_statements_cp(cp: Cp, dos: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<(Text, Cp)>> {
    Rc::new(CppStatementsCp { cp, dos })
}

/// ```prism
/// Unvexed: fn Text -> Text
/// ```
pub fn unvexed(t: &Text) -> Text {
    let head = or(&index(&split(t, &Text::lit("(")), &Nat::from(0u32)), &Text::lit(""));
    let type_like = crate::syntax::lexer::contains(&head, &Text::lit(":")) || crate::syntax::lexer::contains(&Text::lit("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), &crate::syntax::lexer::head(&head));
    let vexing = (((&crate::syntax::lexer::last_char(t) == &Text::lit(")")) && !crate::syntax::lexer::contains(&head, &Text::lit(" "))) && (&head != &Text::lit(""))) && type_like;
    if vexing { Text::from(format!("({})", t)) } else { t.clone() }
}

/// ```prism
/// Rebound: unbounded fn Cp, Do -> Cp
/// ```
pub fn rebound(cp: &Cp, d: &crate::lower::model::Do) -> Cp {
    match d {
        crate::lower::model::Do::DoLetElse(p_, _, _) => unbind(cp, &pat_names(p_)),
        crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTuple(ps), _) => unbind(cp, &pat_names(&crate::lower::model::Pa::PaTuple(ps.clone()))),
        crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaCtor(c, ps), _) => unbind(cp, &pat_names(&crate::lower::model::Pa::PaCtor(c.clone(), ps.clone()))),
        crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaRecord(c, fs, r), _) => unbind(cp, &pat_names(&crate::lower::model::Pa::PaRecord(c.clone(), fs.clone(), *r))),
        crate::lower::model::Do::DoLet(p_, x) => match let_name(p_) {
            Some(n) => {
                let pointing_ = if is_pointer_let(cp, p_, x) { pointing(cp, &n) } else { known_value(cp, p_, &n) };
                if cpp_mentions(&cpp_expr(cp, x), &var_name(cp, &n)) {
                    {
                        let fresh = Text::from(format!("{}_{}", &var_name(cp, &n), &inc(&len(&keys(&cp.renames)))));
                        {
                            let mut this: Cp = pointing_.clone();
                            this.renames = insert(&this.renames, &n, &fresh);
                            this
                        }
                    }
                } else {
                    pointing_.clone()
                }
            },
            None => cp.clone(),
        },
        _ => cp.clone(),
    }
}

/// The step machine of `Rebound`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Rebound: unbounded fn Cp, Do -> Cp
/// ```
pub struct Rebound {
    pub cp: Cp,
    pub d: crate::lower::model::Do,
}

impl prism_rtl::Job<Cp> for Rebound {
    fn cycle(&self) -> prism_rtl::Turn<Cp> {
        let cp = &self.cp;
        let d = &self.d;
        match d {
            crate::lower::model::Do::DoLetElse(p_, _, _) => {
                let cp = cp.clone();
                let p_ = p_.clone();
                call_then(start_pat_names(p_.clone()), move |pat_names_46774: Array<Text>| prism_rtl::Turn::Finished(unbind(&cp, &pat_names_46774)))
            },
            crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTuple(ps), _) => {
                let cp = cp.clone();
                let ps = ps.clone();
                call_then(start_pat_names(crate::lower::model::Pa::PaTuple(ps.clone())), move |pat_names_46830: Array<Text>| prism_rtl::Turn::Finished(unbind(&cp, &pat_names_46830)))
            },
            crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaCtor(c, ps), _) => {
                let c = c.clone();
                let cp = cp.clone();
                let ps = ps.clone();
                call_then(start_pat_names(crate::lower::model::Pa::PaCtor(c.clone(), ps.clone())), move |pat_names_46899: Array<Text>| prism_rtl::Turn::Finished(unbind(&cp, &pat_names_46899)))
            },
            crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaRecord(c, fs, r), _) => {
                let c = c.clone();
                let cp = cp.clone();
                let fs = fs.clone();
                let r = *r;
                call_then(start_pat_names(crate::lower::model::Pa::PaRecord(c.clone(), fs.clone(), r)), move |pat_names_46975: Array<Text>| prism_rtl::Turn::Finished(unbind(&cp, &pat_names_46975)))
            },
            crate::lower::model::Do::DoLet(p_, x) => match let_name(p_) {
                Some(n) => {
                    let pointing_ = if is_pointer_let(cp, p_, x) { pointing(cp, &n) } else { known_value(cp, p_, &n) };
                    let cp = cp.clone();
                    let x = x.clone();
                    call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_47174: Text| if cpp_mentions(&cpp_expr_47174, &var_name(&cp, &n)) {
                        {
                            let fresh = Text::from(format!("{}_{}", &var_name(&cp, &n), &inc(&len(&keys(&cp.renames)))));
                            prism_rtl::Turn::Finished({
                                let mut this: Cp = pointing_.clone();
                                this.renames = insert(&this.renames, &n, &fresh);
                                this
                            })
                        }
                    } else {
                        prism_rtl::Turn::Finished(pointing_.clone())
                    })
                },
                None => prism_rtl::Turn::Finished(cp.clone()),
            },
            _ => prism_rtl::Turn::Finished(cp.clone()),
        }
    }
}

/// `Start Rebound, x`: what the function value is when passed to `@Run`.
pub fn start_rebound(cp: Cp, d: crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Cp>> {
    Rc::new(Rebound { cp, d })
}

/// ```prism
/// PatNames: unbounded fn Pa -> [Text]
/// ```
pub fn pat_names(p_: &crate::lower::model::Pa) -> Array<Text> {
    match p_ {
        crate::lower::model::Pa::PaBind(n) => Array::from(vec![n.clone()]),
        crate::lower::model::Pa::PaMut(n) => Array::from(vec![n.clone()]),
        crate::lower::model::Pa::PaTyped(q, _) => pat_names(&**q),
        crate::lower::model::Pa::PaCtor(_, ps) => concat2(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
            let q = p0;
            prism_rtl::Turn::More(Rc::new(PatNames { p_: q.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))),
        crate::lower::model::Pa::PaRecord(_, fs, _) => concat2(&run_to_end(each_job(fs.clone(), Rc::new(move |p0: (Text, crate::lower::model::Pa)| entered(once_job(move || {
            let (_, q) = p0;
            prism_rtl::Turn::More(Rc::new(PatNames { p_: q.clone() }))
        }))) as Rc<dyn Fn((Text, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))),
        crate::lower::model::Pa::PaTuple(ps) => concat2(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
            let q = p0;
            prism_rtl::Turn::More(Rc::new(PatNames { p_: q.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))),
        crate::lower::model::Pa::PaSlice(ps) => concat2(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
            let q = p0;
            prism_rtl::Turn::More(Rc::new(PatNames { p_: q.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))),
        crate::lower::model::Pa::PaRest(n) => if n == &Text::lit("") { Array::new() } else { Array::from(vec![n.clone()]) },
        _ => Array::new(),
    }
}

/// The step machine of `PatNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PatNames: unbounded fn Pa -> [Text]
/// ```
pub struct PatNames {
    pub p_: crate::lower::model::Pa,
}

impl prism_rtl::Job<Array<Text>> for PatNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let p_ = &self.p_;
        match p_ {
            crate::lower::model::Pa::PaBind(n) => prism_rtl::Turn::Finished(Array::from(vec![n.clone()])),
            crate::lower::model::Pa::PaMut(n) => prism_rtl::Turn::Finished(Array::from(vec![n.clone()])),
            crate::lower::model::Pa::PaTyped(q, _) => prism_rtl::Turn::More(Rc::new(PatNames { p_: (**q).clone() })),
            crate::lower::model::Pa::PaCtor(_, ps) => {
                let ps = ps.clone();
                call_value(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                    let q = p0;
                    prism_rtl::Turn::More(Rc::new(PatNames { p_: q.clone() }))
                }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_47635: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_47635)))
            },
            crate::lower::model::Pa::PaRecord(_, fs, _) => {
                let fs = fs.clone();
                call_value(each_job(fs.clone(), Rc::new(move |p0: (Text, crate::lower::model::Pa)| entered(once_job(move || {
                    let (_, q) = p0;
                    prism_rtl::Turn::More(Rc::new(PatNames { p_: q.clone() }))
                }))) as Rc<dyn Fn((Text, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_47703: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_47703)))
            },
            crate::lower::model::Pa::PaTuple(ps) => {
                let ps = ps.clone();
                call_value(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                    let q = p0;
                    prism_rtl::Turn::More(Rc::new(PatNames { p_: q.clone() }))
                }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_47766: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_47766)))
            },
            crate::lower::model::Pa::PaSlice(ps) => {
                let ps = ps.clone();
                call_value(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                    let q = p0;
                    prism_rtl::Turn::More(Rc::new(PatNames { p_: q.clone() }))
                }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_47817: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_47817)))
            },
            crate::lower::model::Pa::PaRest(n) => if n == &Text::lit("") {
                prism_rtl::Turn::Finished(Array::new())
            } else {
                prism_rtl::Turn::Finished(Array::from(vec![n.clone()]))
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start PatNames, x`: what the function value is when passed to `@Run`.
pub fn start_pat_names(p_: crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(PatNames { p_ })
}

/// ```prism
/// ArmNames: unbounded fn XArm -> [Text]
/// ```
pub fn arm_names(a: &crate::lower::model::XArm) -> Array<Text> {
    append(&pat_names(&a.pat), &concat2(&run_to_end(each_job(a.conds.clone(), Rc::new(move |p0: crate::lower::model::Cc| entered(once_job(move || {
        let c = p0;
        prism_rtl::Turn::More(Rc::new(CondNames { cc0: c.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Array<Text>>>>))))
}

/// The step machine of `ArmNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArmNames: unbounded fn XArm -> [Text]
/// ```
pub struct ArmNames {
    pub a: crate::lower::model::XArm,
}

impl prism_rtl::Job<Array<Text>> for ArmNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let a = &self.a;
        let a = a.clone();
        call_then(start_pat_names(a.pat.clone()), move |pat_names_47969: Array<Text>| call_value(each_job(a.conds.clone(), Rc::new(move |p0: crate::lower::model::Cc| entered(once_job(move || {
            let c = p0;
            prism_rtl::Turn::More(Rc::new(CondNames { cc0: c.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_47996: Array<Array<Text>>| prism_rtl::Turn::Finished(append(&pat_names_47969, &concat2(&each_47996)))))
    }
}

/// `Start ArmNames, x`: what the function value is when passed to `@Run`.
pub fn start_arm_names(a: crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ArmNames { a })
}

/// ```prism
/// CondNames: unbounded fn Cc -> [Text]
/// ```
pub fn cond_names(cc0: &crate::lower::model::Cc) -> Array<Text> {
    match cc0 {
        crate::lower::model::Cc::CcLet(q, _) => pat_names(q),
        crate::lower::model::Cc::CcIf(_) => Array::new(),
    }
}

/// The step machine of `CondNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondNames: unbounded fn Cc -> [Text]
/// ```
pub struct CondNames {
    pub cc0: crate::lower::model::Cc,
}

impl prism_rtl::Job<Array<Text>> for CondNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cc0 = &self.cc0;
        match cc0 {
            crate::lower::model::Cc::CcLet(q, _) => prism_rtl::Turn::More(Rc::new(PatNames { p_: q.clone() })),
            crate::lower::model::Cc::CcIf(_) => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start CondNames, x`: what the function value is when passed to `@Run`.
pub fn start_cond_names(cc0: crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(CondNames { cc0 })
}

/// ```prism
/// Unbind: fn Cp, [Text] -> Cp
/// ```
pub fn unbind(cp: &Cp, names: &Array<Text>) -> Cp {
    let mut this: Cp = cp.clone();
    this.renames = fold(names, &this.renames, &(|m: &Map<Text, Text>, n: &Text| remove(m, n)));
    this.pointers = fold(names, &this.pointers, &(|m: &Map<Text, bool>, n: &Text| remove(m, n)));
    this
}

/// ```prism
/// Pointing: fn Cp, Text -> Cp
/// ```
pub fn pointing(cp: &Cp, n: &Text) -> Cp {
    let mut this: Cp = cp.clone();
    this.pointers = insert(&this.pointers, n, &true);
    this
}

/// ```prism
/// KnownValue: fn Cp, Pa, Text -> Cp
/// ```
pub fn known_value(cp: &Cp, p_: &crate::lower::model::Pa, n: &Text) -> Cp {
    match p_ {
        crate::lower::model::Pa::PaTyped(_, _) => {
            let mut this: Cp = cp.clone();
            this.pointers = insert(&this.pointers, n, &false);
            this
        },
        _ => cp.clone(),
    }
}

/// ```prism
/// IsPointerLet: fn Cp, Pa, Ex -> Bool
/// ```
pub fn is_pointer_let(cp: &Cp, p_: &crate::lower::model::Pa, x: &crate::lower::model::Ex) -> bool {
    match p_ {
        crate::lower::model::Pa::PaTyped(_, t) => is_pointer_ty(cp, t),
        _ => 'm49114: {
            if let crate::lower::model::Ex::XCall(m49114_0_0, _) = x && (m49114_0_0 == &Text::lit("prism_rtl::Host::new")) {
                break 'm49114 true;
            }
            if let crate::lower::model::Ex::XCall(m49114_1_0, m49114_1_1) = x && (m49114_1_0 == &Text::lit("Rc::new")) && (m49114_1_1.len() == 1) && let Some(crate::lower::model::Ex::XCall(m49114_1_1_0_0, _)) = index(m49114_1_1, &Nat::from(0u32)) && (&m49114_1_1_0_0 == &Text::lit("Port::new")) {
                break 'm49114 true;
            }
            match pointer(cp, x) {
                Some(b) => b,
                None => false,
            }
        },
    }
}

/// ```prism
/// Inc: fn Nat -> Nat
/// ```
pub fn inc(n: &Nat) -> Nat {
    n + &Nat::from(1u32)
}

/// ```prism
/// ?LetName: fn Pa -> ?Text
/// ```
pub fn let_name(p_: &crate::lower::model::Pa) -> Option<Text> {
    match p_ {
        crate::lower::model::Pa::PaBind(n) => Some(n.clone()),
        crate::lower::model::Pa::PaMut(n) => Some(n.clone()),
        crate::lower::model::Pa::PaTyped(q, _) => let_name(&**q),
        _ => None,
    }
}

/// ```prism
/// VarName: fn Cp, Text -> Text
/// ```
pub fn var_name(cp: &Cp, n: &Text) -> Text {
    or(&get(&cp.renames, n), &cpp_id(n))
}

/// ```prism
/// CppMentions: fn Text, Text -> Bool
/// ```
pub fn cpp_mentions(t: &Text, n: &Text) -> bool {
    let parts = split(t, n);
    let k = len(&parts);
    fold(&crate::check::errors::range0(&crate::syntax::lexer::dec(&k)), &false, &(|f: &bool, i: &Nat| *f || (!cpp_ends_ident(&or(&index(&parts, i), &Text::lit(""))) && !cpp_starts_ident(&or(&index(&parts, &(i + &Nat::from(1u32))), &Text::lit(""))))))
}

/// ```prism
/// CppEndsIdent: fn Text -> Bool
/// ```
pub fn cpp_ends_ident(t: &Text) -> bool {
    let c = crate::syntax::lexer::last_char(t);
    (cpp_ident_char(&c) || (&c == &Text::lit("."))) || (&c == &Text::lit(">"))
}

/// ```prism
/// CppStartsIdent: fn Text -> Bool
/// ```
pub fn cpp_starts_ident(t: &Text) -> bool {
    cpp_ident_char(&crate::syntax::lexer::head(t))
}

/// ```prism
/// CppIdentChar: fn Text -> Bool
/// ```
pub fn cpp_ident_char(c: &Text) -> bool {
    (c != &Text::lit("")) && crate::syntax::lexer::contains(&Text::lit("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"), c)
}

/// ```prism
/// CppStatement: unbounded fn Cp, Do -> Text
/// ```
pub fn cpp_statement(cp: &Cp, d: &crate::lower::model::Do) -> Text {
    match d {
        crate::lower::model::Do::DoLet(p_, x) => cpp_let(cp, cp, p_, x),
        crate::lower::model::Do::DoLetElse(p_, x, e) => {
            let v_ = Text::from(format!("_{}", &or(&first_binder(p_), &Text::lit("m"))));
            Text::from(format!("auto&& {} = {};\nif (!({})) {{ {}; }}\n{}", &v_, &cpp_expr(cp, x), &conds(&pat_conds(cp, p_, &v_)), &cpp_expr(cp, e), &crate::syntax::lexer::join(&pat_binds(cp, p_, &v_), &Text::lit("\n"))))
        },
        crate::lower::model::Do::DoAssign(p_, x) => Text::from(format!("{} = {};", &cpp_expr(cp, p_), &cpp_expr(cp, x))),
        crate::lower::model::Do::DoWhile(c, body) => crate::emit::cpp::templates::block(&Text::from(format!("while ({})", &cpp_expr(cp, c))), &cpp_statements(cp, body)),
        crate::lower::model::Do::DoWhileLet(p_, x, body) => {
            let v_ = Text::lit("_m");
            let head = Text::from(format!("auto&& _m = {};\nif (!({})) break;", &cpp_expr(cp, x), &conds(&pat_conds(cp, p_, &v_))));
            crate::emit::cpp::templates::block(&Text::lit("while (true)"), &crate::syntax::lexer::join(&append(&append(&Array::from(vec![head.clone()]), &pat_binds(cp, p_, &v_)), &Array::from(vec![cpp_statements(cp, body)])), &Text::lit("\n")))
        },
        crate::lower::model::Do::DoFor(p_, x, body) => cpp_for(cp, p_, x, body),
        crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(l, y)) => cpp_break(cp, l, &**y),
        crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreakLoop) => Text::lit("break;"),
        crate::lower::model::Do::DoExpr(x) => Text::from(format!("{};", &cpp_expr(cp, x))),
        crate::lower::model::Do::DoIf(c, t, e) => Text::from(format!("{}{}", &crate::emit::cpp::templates::block(&Text::from(format!("if ({})", &cpp_expr(cp, c))), &cpp_statements(cp, t)), &cpp_else(cp, e))),
        crate::lower::model::Do::DoIfLet(p_, x, t, e) => cpp_if_let(cp, p_, x, t, e),
        crate::lower::model::Do::DoMatch(x, cases) => cpp_do_match(cp, x, cases),
        crate::lower::model::Do::DoReturn(x) => Text::from(format!("return {};", &cpp_expr(cp, x))),
        crate::lower::model::Do::DoBlock(body) => crate::emit::cpp::templates::braced(&cpp_statements(cp, body)),
        crate::lower::model::Do::DoScope(body) => Text::from(format!("{{ {} }}", &cpp_inline(cp, body))),
        crate::lower::model::Do::DoLine(body) => cpp_inline(cp, body),
        crate::lower::model::Do::DoNote(t) => Text::from(format!("// {}", t)),
    }
}

/// The step machine of `CppStatement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppStatement: unbounded fn Cp, Do -> Text
/// ```
pub struct CppStatement {
    pub cp: Cp,
    pub d: crate::lower::model::Do,
}

impl prism_rtl::Job<Text> for CppStatement {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let d = &self.d;
        match d {
            crate::lower::model::Do::DoLet(p_, x) => prism_rtl::Turn::More(Rc::new(CppLet { cp: cp.clone(), named: cp.clone(), p_: p_.clone(), x: x.clone() })),
            crate::lower::model::Do::DoLetElse(p_, x, e) => {
                let cp = cp.clone();
                let e = e.clone();
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_first_binder(p_.clone()), move |first_binder_50406: Option<Text>| {
                    let v_ = Text::from(format!("_{}", &or(&first_binder_50406, &Text::lit("m"))));
                    call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_50452: Text| call_then(start_pat_conds(cp.clone(), p_.clone(), v_.clone()), move |pat_conds_50483: Array<Text>| call_then(start_cpp_expr(cp.clone(), e.clone()), move |cpp_expr_50509: Text| call_then(start_pat_binds(cp.clone(), p_.clone(), v_.clone()), move |pat_binds_50536: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("auto&& {} = {};\nif (!({})) {{ {}; }}\n{}", &v_, &cpp_expr_50452, &conds(&pat_conds_50483), &cpp_expr_50509, &crate::syntax::lexer::join(&pat_binds_50536, &Text::lit("\n")))))))))
                })
            },
            crate::lower::model::Do::DoAssign(p_, x) => {
                let cp = cp.clone();
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_cpp_expr(cp.clone(), p_.clone()), move |cpp_expr_50584: Text| call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_50602: Text| prism_rtl::Turn::Finished(Text::from(format!("{} = {};", &cpp_expr_50584, &cpp_expr_50602)))))
            },
            crate::lower::model::Do::DoWhile(c, body) => {
                let body = body.clone();
                let c = c.clone();
                let cp = cp.clone();
                call_then(start_cpp_expr(cp.clone(), c.clone()), move |cpp_expr_50655: Text| call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_50674: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::block(&Text::from(format!("while ({})", &cpp_expr_50655)), &cpp_statements_50674))))
            },
            crate::lower::model::Do::DoWhileLet(p_, x, body) => {
                let v_ = Text::lit("_m");
                let body = body.clone();
                let cp = cp.clone();
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_50779: Text| call_then(start_pat_conds(cp.clone(), p_.clone(), v_.clone()), move |pat_conds_50810: Array<Text>| {
                    let head = Text::from(format!("auto&& _m = {};\nif (!({})) break;", &cpp_expr_50779, &conds(&pat_conds_50810)));
                    call_then(start_pat_binds(cp.clone(), p_.clone(), v_.clone()), move |pat_binds_50903: Array<Text>| call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_50927: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::block(&Text::lit("while (true)"), &crate::syntax::lexer::join(&append(&append(&Array::from(vec![head.clone()]), &pat_binds_50903), &Array::from(vec![cpp_statements_50927])), &Text::lit("\n"))))))
                }))
            },
            crate::lower::model::Do::DoFor(p_, x, body) => prism_rtl::Turn::More(Rc::new(CppFor { cp0: cp.clone(), p_: p_.clone(), x: x.clone(), body: body.clone() })),
            crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(l, y)) => prism_rtl::Turn::More(Rc::new(CppBreak { cp: cp.clone(), l: l.clone(), y: (**y).clone() })),
            crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreakLoop) => prism_rtl::Turn::Finished(Text::lit("break;")),
            crate::lower::model::Do::DoExpr(x) => {
                let cp = cp.clone();
                let x = x.clone();
                call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_51097: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &cpp_expr_51097))))
            },
            crate::lower::model::Do::DoIf(c, t, e) => {
                let c = c.clone();
                let cp = cp.clone();
                let e = e.clone();
                let t = t.clone();
                call_then(start_cpp_expr(cp.clone(), c.clone()), move |cpp_expr_51146: Text| call_then(start_cpp_statements(cp.clone(), t.clone()), move |cpp_statements_51165: Text| call_then(start_cpp_else(cp.clone(), e.clone()), move |cpp_else_51187: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &crate::emit::cpp::templates::block(&Text::from(format!("if ({})", &cpp_expr_51146)), &cpp_statements_51165), &cpp_else_51187))))))
            },
            crate::lower::model::Do::DoIfLet(p_, x, t, e) => prism_rtl::Turn::More(Rc::new(CppIfLet { cp0: cp.clone(), p_: p_.clone(), x: x.clone(), t: t.clone(), e: e.clone() })),
            crate::lower::model::Do::DoMatch(x, cases) => prism_rtl::Turn::More(Rc::new(CppDoMatch { cp: cp.clone(), x: x.clone(), cases: cases.clone() })),
            crate::lower::model::Do::DoReturn(x) => {
                let cp = cp.clone();
                let x = x.clone();
                call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_51322: Text| prism_rtl::Turn::Finished(Text::from(format!("return {};", &cpp_expr_51322))))
            },
            crate::lower::model::Do::DoBlock(body) => {
                let body = body.clone();
                let cp = cp.clone();
                call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_51365: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::braced(&cpp_statements_51365)))
            },
            crate::lower::model::Do::DoScope(body) => {
                let body = body.clone();
                let cp = cp.clone();
                call_then(start_cpp_inline(cp.clone(), body.clone()), move |cpp_inline_51412: Text| prism_rtl::Turn::Finished(Text::from(format!("{{ {} }}", &cpp_inline_51412))))
            },
            crate::lower::model::Do::DoLine(body) => prism_rtl::Turn::More(Rc::new(CppInline { cp: cp.clone(), dos: body.clone() })),
            crate::lower::model::Do::DoNote(t) => prism_rtl::Turn::Finished(Text::from(format!("// {}", t))),
        }
    }
}

/// `Start CppStatement, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_statement(cp: Cp, d: crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppStatement { cp, d })
}

/// ```prism
/// CppInline: unbounded fn Cp, [Do] -> Text
/// ```
pub fn cpp_inline(cp: &Cp, dos: &Array<crate::lower::model::Do>) -> Text {
    crate::syntax::lexer::join(&run_to_end(each_job(dos.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::Do| {
            let cp = cp.clone();
            entered(once_job(move || {
                let d = p0;
                prism_rtl::Turn::More(Rc::new(CppStatement { cp: cp.clone(), d: d.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(" "))
}

/// The step machine of `CppInline`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppInline: unbounded fn Cp, [Do] -> Text
/// ```
pub struct CppInline {
    pub cp: Cp,
    pub dos: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for CppInline {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let dos = &self.dos;
        let cp = cp.clone();
        let dos = dos.clone();
        call_value(each_job(dos.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: crate::lower::model::Do| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let d = p0;
                    prism_rtl::Turn::More(Rc::new(CppStatement { cp: cp.clone(), d: d.clone() }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_51566: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::join(&each_51566, &Text::lit(" "))))
    }
}

/// `Start CppInline, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_inline(cp: Cp, dos: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppInline { cp, dos })
}

/// ```prism
/// CppElse: unbounded fn Cp, [Do] -> Text
/// ```
pub fn cpp_else(cp: &Cp, xs1: &Array<crate::lower::model::Do>) -> Text {
    'c: {
        if let c0_1 = xs1 && (c0_1.len() == 0) {
            break 'c Text::lit("");
        }
        if let c1_1 = xs1 && (c1_1.len() == 1) && let Some(crate::lower::model::Do::DoIf(c, t, e)) = index(c1_1, &Nat::from(0u32)) {
            break 'c Text::from(format!(" else {}", &cpp_statement(cp, &crate::lower::model::Do::DoIf(c.clone(), t.clone(), e.clone()))));
        }
        if let c2_1 = xs1 && (c2_1.len() == 1) && let Some(crate::lower::model::Do::DoIfLet(p_, x, t, e)) = index(c2_1, &Nat::from(0u32)) {
            break 'c Text::from(format!(" else {}", &cpp_statement(cp, &crate::lower::model::Do::DoIfLet(p_.clone(), x.clone(), t.clone(), e.clone()))));
        }
        if let body = xs1 {
            break 'c Text::from(format!(" else {}", &crate::emit::cpp::templates::block(&Text::lit(""), &cpp_statements(cp, body))));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `CppElse`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppElse: unbounded fn Cp, [Do] -> Text
/// ```
pub struct CppElse {
    pub cp: Cp,
    pub xs1: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for CppElse {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let xs1 = &self.xs1;
        'j: {
            if let j0_1 = xs1 && (j0_1.len() == 0) {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let j1_1 = xs1 && (j1_1.len() == 1) && let Some(crate::lower::model::Do::DoIf(c, t, e)) = index(j1_1, &Nat::from(0u32)) {
                break 'j {
                    let cp = cp.clone();
                    call_then(start_cpp_statement(cp.clone(), crate::lower::model::Do::DoIf(c.clone(), t.clone(), e.clone())), move |cpp_statement_51715: Text| prism_rtl::Turn::Finished(Text::from(format!(" else {}", &cpp_statement_51715))))
                };
            }
            if let j2_1 = xs1 && (j2_1.len() == 1) && let Some(crate::lower::model::Do::DoIfLet(p_, x, t, e)) = index(j2_1, &Nat::from(0u32)) {
                break 'j {
                    let cp = cp.clone();
                    call_then(start_cpp_statement(cp.clone(), crate::lower::model::Do::DoIfLet(p_.clone(), x.clone(), t.clone(), e.clone())), move |cpp_statement_51799: Text| prism_rtl::Turn::Finished(Text::from(format!(" else {}", &cpp_statement_51799))))
                };
            }
            if let body = xs1 {
                break 'j {
                    let body = body.clone();
                    let cp = cp.clone();
                    call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_51880: Text| prism_rtl::Turn::Finished(Text::from(format!(" else {}", &crate::emit::cpp::templates::block(&Text::lit(""), &cpp_statements_51880)))))
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start CppElse, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_else(cp: Cp, xs1: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppElse { cp, xs1 })
}

/// ```prism
/// CppLet: unbounded fn Cp, Cp, Pa, Ex -> Text
/// ```
pub fn cpp_let(cp: &Cp, named: &Cp, p_: &crate::lower::model::Pa, x: &crate::lower::model::Ex) -> Text {
    'm52096: {
        if let crate::lower::model::Pa::PaWild = p_ {
            break 'm52096 Text::from(format!("static_cast<void>({});", &cpp_expr(cp, x)));
        }
        if let crate::lower::model::Pa::PaBind(n) = p_ {
            break 'm52096 match x {
                crate::lower::model::Ex::XRef(_) => Text::from(format!("const auto& {} = {};", &var_name(named, n), &cpp_expr(cp, x))),
                _ => Text::from(format!("auto {} = {};", &var_name(named, n), &cpp_expr(cp, x))),
            };
        }
        if let crate::lower::model::Pa::PaMut(n) = p_ {
            break 'm52096 Text::from(format!("auto {} = {};", &var_name(named, n), &cpp_expr(cp, x)));
        }
        if let crate::lower::model::Pa::PaTyped(m52096_3_0, t) = p_ && let crate::lower::model::Pa::PaBind(n) = &**m52096_3_0 {
            break 'm52096 Text::from(format!("{} {} = {};", &cpp_type(cp, t), &var_name(named, n), &cpp_expr(cp, x)));
        }
        if let crate::lower::model::Pa::PaTyped(m52096_4_0, t) = p_ && let crate::lower::model::Pa::PaMut(n) = &**m52096_4_0 {
            break 'm52096 Text::from(format!("{} {} = {};", &cpp_type(cp, t), &var_name(named, n), &cpp_expr(cp, x)));
        }
        if let crate::lower::model::Pa::PaTuple(ps) = p_ {
            break 'm52096 if fold(ps, &true, &(|f: &bool, q: &crate::lower::model::Pa| *f && is_name(q))) {
                Text::from(format!("auto [{}] = {};", &crate::syntax::lexer::join(&each(ps, &(|q: &crate::lower::model::Pa| pat_name(q))), &Text::lit(", ")), &cpp_expr(cp, x)))
            } else {
                let_through(cp, p_, x)
            };
        }
        let_through(cp, p_, x)
    }
}

/// The step machine of `CppLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppLet: unbounded fn Cp, Cp, Pa, Ex -> Text
/// ```
pub struct CppLet {
    pub cp: Cp,
    pub named: Cp,
    pub p_: crate::lower::model::Pa,
    pub x: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppLet {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let named = &self.named;
        let p_ = &self.p_;
        let x = &self.x;
        'm52096: {
            if let crate::lower::model::Pa::PaWild = p_ {
                break 'm52096 {
                    let cp = cp.clone();
                    let x = x.clone();
                    call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_52137: Text| prism_rtl::Turn::Finished(Text::from(format!("static_cast<void>({});", &cpp_expr_52137))))
                };
            }
            if let crate::lower::model::Pa::PaBind(n) = p_ {
                break 'm52096 match x {
                    crate::lower::model::Ex::XRef(_) => {
                        let cp = cp.clone();
                        let n = n.clone();
                        let named = named.clone();
                        let x = x.clone();
                        call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_52234: Text| prism_rtl::Turn::Finished(Text::from(format!("const auto& {} = {};", &var_name(&named, &n), &cpp_expr_52234))))
                    },
                    _ => {
                        let cp = cp.clone();
                        let n = n.clone();
                        let named = named.clone();
                        let x = x.clone();
                        call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_52298: Text| prism_rtl::Turn::Finished(Text::from(format!("auto {} = {};", &var_name(&named, &n), &cpp_expr_52298))))
                    },
                };
            }
            if let crate::lower::model::Pa::PaMut(n) = p_ {
                break 'm52096 {
                    let cp = cp.clone();
                    let n = n.clone();
                    let named = named.clone();
                    let x = x.clone();
                    call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_52356: Text| prism_rtl::Turn::Finished(Text::from(format!("auto {} = {};", &var_name(&named, &n), &cpp_expr_52356))))
                };
            }
            if let crate::lower::model::Pa::PaTyped(m52096_3_0, t) = p_ && let crate::lower::model::Pa::PaBind(n) = &**m52096_3_0 {
                break 'm52096 {
                    let cp = cp.clone();
                    let n = n.clone();
                    let named = named.clone();
                    let t = t.clone();
                    let x = x.clone();
                    call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_52402: Text| call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_52439: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {} = {};", &cpp_type_52402, &var_name(&named, &n), &cpp_expr_52439)))))
                };
            }
            if let crate::lower::model::Pa::PaTyped(m52096_4_0, t) = p_ && let crate::lower::model::Pa::PaMut(n) = &**m52096_4_0 {
                break 'm52096 {
                    let cp = cp.clone();
                    let n = n.clone();
                    let named = named.clone();
                    let t = t.clone();
                    let x = x.clone();
                    call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_52484: Text| call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_52521: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {} = {};", &cpp_type_52484, &var_name(&named, &n), &cpp_expr_52521)))))
                };
            }
            if let crate::lower::model::Pa::PaTuple(ps) = p_ {
                break 'm52096 if fold(ps, &true, &(|f: &bool, q: &crate::lower::model::Pa| *f && is_name(q))) {
                    {
                        let cp = cp.clone();
                        let ps = ps.clone();
                        let x = x.clone();
                        call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_52654: Text| prism_rtl::Turn::Finished(Text::from(format!("auto [{}] = {};", &crate::syntax::lexer::join(&each(&ps, &(|q: &crate::lower::model::Pa| pat_name(q))), &Text::lit(", ")), &cpp_expr_52654))))
                    }
                } else {
                    prism_rtl::Turn::More(Rc::new(LetThrough { cp: cp.clone(), p_: p_.clone(), x: x.clone() }))
                };
            }
            prism_rtl::Turn::More(Rc::new(LetThrough { cp: cp.clone(), p_: p_.clone(), x: x.clone() }))
        }
    }
}

/// `Start CppLet, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_let(cp: Cp, named: Cp, p_: crate::lower::model::Pa, x: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppLet { cp, named, p_, x })
}

/// ```prism
/// LetThrough: unbounded fn Cp, Pa, Ex -> Text
/// ```
pub fn let_through(cp: &Cp, p_: &crate::lower::model::Pa, x: &crate::lower::model::Ex) -> Text {
    let t = Text::from(format!("_{}", &or(&first_binder(p_), &Text::lit("t"))));
    Text::from(format!("auto&& {} = {};\n{}", &t, &cpp_expr(cp, x), &crate::syntax::lexer::join(&pat_binds(cp, p_, &t), &Text::lit("\n"))))
}

/// The step machine of `LetThrough`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LetThrough: unbounded fn Cp, Pa, Ex -> Text
/// ```
pub struct LetThrough {
    pub cp: Cp,
    pub p_: crate::lower::model::Pa,
    pub x: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for LetThrough {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let p_ = &self.p_;
        let x = &self.x;
        let cp = cp.clone();
        let p_ = p_.clone();
        let x = x.clone();
        call_then(start_first_binder(p_.clone()), move |first_binder_52913: Option<Text>| {
            let t = Text::from(format!("_{}", &or(&first_binder_52913, &Text::lit("t"))));
            call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_52955: Text| call_then(start_pat_binds(cp.clone(), p_.clone(), t.clone()), move |pat_binds_52979: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("auto&& {} = {};\n{}", &t, &cpp_expr_52955, &crate::syntax::lexer::join(&pat_binds_52979, &Text::lit("\n")))))))
        })
    }
}

/// `Start LetThrough, x`: what the function value is when passed to `@Run`.
pub fn start_let_through(cp: Cp, p_: crate::lower::model::Pa, x: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(LetThrough { cp, p_, x })
}

/// ```prism
/// ?FirstBinder: unbounded fn Pa -> ?Text
/// ```
pub fn first_binder(p_: &crate::lower::model::Pa) -> Option<Text> {
    match p_ {
        crate::lower::model::Pa::PaBind(n) => Some(n.clone()),
        crate::lower::model::Pa::PaMut(n) => Some(n.clone()),
        crate::lower::model::Pa::PaTyped(q, _) => first_binder(&**q),
        crate::lower::model::Pa::PaCtor(_, ps) => run_to_end(fold_job(ps.clone(), None, Rc::new(move |(p0, p1): (Option<Text>, crate::lower::model::Pa)| entered(once_job(move || {
            let f_opt = p0;
            let q = p1;
            match &f_opt {
                Some(b) => prism_rtl::Turn::Finished(Some(b.clone())),
                None => prism_rtl::Turn::More(Rc::new(FirstBinder { p_: q.clone() })),
            }
        }))) as Rc<dyn Fn((Option<Text>, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Option<Text>>>>)),
        crate::lower::model::Pa::PaTuple(ps) => run_to_end(fold_job(ps.clone(), None, Rc::new(move |(p0, p1): (Option<Text>, crate::lower::model::Pa)| entered(once_job(move || {
            let f_opt = p0;
            let q = p1;
            match &f_opt {
                Some(b) => prism_rtl::Turn::Finished(Some(b.clone())),
                None => prism_rtl::Turn::More(Rc::new(FirstBinder { p_: q.clone() })),
            }
        }))) as Rc<dyn Fn((Option<Text>, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Option<Text>>>>)),
        _ => None,
    }
}

/// The step machine of `FirstBinder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?FirstBinder: unbounded fn Pa -> ?Text
/// ```
pub struct FirstBinder {
    pub p_: crate::lower::model::Pa,
}

impl prism_rtl::Job<Option<Text>> for FirstBinder {
    fn cycle(&self) -> prism_rtl::Turn<Option<Text>> {
        let p_ = &self.p_;
        match p_ {
            crate::lower::model::Pa::PaBind(n) => prism_rtl::Turn::Finished(Some(n.clone())),
            crate::lower::model::Pa::PaMut(n) => prism_rtl::Turn::Finished(Some(n.clone())),
            crate::lower::model::Pa::PaTyped(q, _) => prism_rtl::Turn::More(Rc::new(FirstBinder { p_: (**q).clone() })),
            crate::lower::model::Pa::PaCtor(_, ps) => fold_job(ps.clone(), None, Rc::new(move |(p0, p1): (Option<Text>, crate::lower::model::Pa)| entered(once_job(move || {
                let f_opt = p0;
                let q = p1;
                match &f_opt {
                    Some(b) => prism_rtl::Turn::Finished(Some(b.clone())),
                    None => prism_rtl::Turn::More(Rc::new(FirstBinder { p_: q.clone() })),
                }
            }))) as Rc<dyn Fn((Option<Text>, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Option<Text>>>>).cycle(),
            crate::lower::model::Pa::PaTuple(ps) => fold_job(ps.clone(), None, Rc::new(move |(p0, p1): (Option<Text>, crate::lower::model::Pa)| entered(once_job(move || {
                let f_opt = p0;
                let q = p1;
                match &f_opt {
                    Some(b) => prism_rtl::Turn::Finished(Some(b.clone())),
                    None => prism_rtl::Turn::More(Rc::new(FirstBinder { p_: q.clone() })),
                }
            }))) as Rc<dyn Fn((Option<Text>, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Option<Text>>>>).cycle(),
            _ => prism_rtl::Turn::Finished(None),
        }
    }
}

/// `Start FirstBinder, x`: what the function value is when passed to `@Run`.
pub fn start_first_binder(p_: crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Option<Text>>> {
    Rc::new(FirstBinder { p_ })
}

/// ```prism
/// IsName: fn Pa -> Bool
/// ```
pub fn is_name(pa0: &crate::lower::model::Pa) -> bool {
    match pa0 {
        crate::lower::model::Pa::PaBind(_) => true,
        crate::lower::model::Pa::PaMut(_) => true,
        other => false,
    }
}

/// ```prism
/// PatName: fn Pa -> Text
/// ```
pub fn pat_name(pa0: &crate::lower::model::Pa) -> Text {
    match pa0 {
        crate::lower::model::Pa::PaBind(n) => cpp_id(n),
        crate::lower::model::Pa::PaMut(n) => cpp_id(n),
        other => Text::lit("_"),
    }
}

/// ```prism
/// CppIfLet: unbounded fn Cp, Pa, Ex, [Do], [Do] -> Text
/// ```
pub fn cpp_if_let(cp0: &Cp, p_: &crate::lower::model::Pa, x: &crate::lower::model::Ex, t: &Array<crate::lower::model::Do>, e: &Array<crate::lower::model::Do>) -> Text {
    let cp = unbind(cp0, &pat_names(p_));
    let v_ = Text::lit("_m");
    let head = Text::from(format!("if (auto&& _m = {}; {})", &cpp_expr(&cp, x), &conds(&pat_conds(&cp, p_, &v_))));
    let body = crate::syntax::lexer::join(&append(&pat_binds(&cp, p_, &v_), &Array::from(vec![cpp_statements(&cp, t)])), &Text::lit("\n"));
    Text::from(format!("{}{}", &crate::emit::cpp::templates::block(&head, &body), &cpp_else(&cp, e)))
}

/// The step machine of `CppIfLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppIfLet: unbounded fn Cp, Pa, Ex, [Do], [Do] -> Text
/// ```
pub struct CppIfLet {
    pub cp0: Cp,
    pub p_: crate::lower::model::Pa,
    pub x: crate::lower::model::Ex,
    pub t: Array<crate::lower::model::Do>,
    pub e: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for CppIfLet {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp0 = &self.cp0;
        let p_ = &self.p_;
        let x = &self.x;
        let t = &self.t;
        let e = &self.e;
        let cp0 = cp0.clone();
        let e = e.clone();
        let p_ = p_.clone();
        let t = t.clone();
        let x = x.clone();
        call_then(start_pat_names(p_.clone()), move |pat_names_53766: Array<Text>| {
            let cp = unbind(&cp0, &pat_names_53766);
            let v_ = Text::lit("_m");
            call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_53828: Text| call_then(start_pat_conds(cp.clone(), p_.clone(), v_.clone()), move |pat_conds_53852: Array<Text>| {
                let head = Text::from(format!("if (auto&& _m = {}; {})", &cpp_expr_53828, &conds(&pat_conds_53852)));
                call_then(start_pat_binds(cp.clone(), p_.clone(), v_.clone()), move |pat_binds_53903: Array<Text>| call_then(start_cpp_statements(cp.clone(), t.clone()), move |cpp_statements_53926: Text| {
                    let body = crate::syntax::lexer::join(&append(&pat_binds_53903, &Array::from(vec![cpp_statements_53926])), &Text::lit("\n"));
                    call_then(start_cpp_else(cp.clone(), e.clone()), move |cpp_else_53980: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &crate::emit::cpp::templates::block(&head, &body), &cpp_else_53980))))
                }))
            }))
        })
    }
}

/// `Start CppIfLet, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_if_let(cp0: Cp, p_: crate::lower::model::Pa, x: crate::lower::model::Ex, t: Array<crate::lower::model::Do>, e: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppIfLet { cp0, p_, x, t, e })
}

/// ```prism
/// CppDoMatch: unbounded fn Cp, Ex, [((Pa, [Do]))] -> Text
/// ```
pub fn cpp_do_match(cp: &Cp, x: &crate::lower::model::Ex, cases: &Array<(crate::lower::model::Pa, Array<crate::lower::model::Do>)>) -> Text {
    let v_ = Text::lit("_m");
    let arms = run_to_end(each_job(cases.clone(), {
        let cp = cp.clone();
        let v_ = v_.clone();
        Rc::new(move |p0: (crate::lower::model::Pa, Array<crate::lower::model::Do>)| {
            let cp = cp.clone();
            let v_ = v_.clone();
            entered(once_job(move || {
                let (p_, body) = p0;
                call_then(start_pat_conds(cp.clone(), p_.clone(), v_.clone()), move |pat_conds_54160: Array<Text>| {
                    let tests = pat_conds_54160;
                    call_then(start_pat_binds(cp.clone(), p_.clone(), v_.clone()), move |pat_binds_54212: Array<Text>| call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_54235: Text| {
                        let inner = crate::syntax::lexer::join(&append(&pat_binds_54212, &Array::from(vec![cpp_statements_54235])), &Text::lit("\n"));
                        prism_rtl::Turn::Finished((tests.clone(), inner.clone()))
                    }))
                })
            }))
        }) as Rc<dyn Fn((crate::lower::model::Pa, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Text)>>>
    }));
    let blocks = each(&crate::check::errors::range0(&len(&arms)), &(|i: &Nat| {
        let (tests, inner) = or(&index(&arms, i), &(Array::new(), Text::lit("")));
        let head = if i == &Nat::from(0u32) {
            Text::from(format!("if ({})", &conds(&tests)))
        } else {
            if &len(&tests) == &Nat::from(0u32) {
                Text::lit("else")
            } else {
                Text::from(format!("else if ({})", &conds(&tests)))
            }
        };
        crate::emit::cpp::templates::block(&head, &inner)
    }));
    crate::emit::cpp::templates::braced(&Text::from(format!("auto&& _m = {};\n{}", &cpp_expr(cp, x), &crate::syntax::lexer::join(&blocks, &Text::lit(" ")))))
}

/// The step machine of `CppDoMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppDoMatch: unbounded fn Cp, Ex, [((Pa, [Do]))] -> Text
/// ```
pub struct CppDoMatch {
    pub cp: Cp,
    pub x: crate::lower::model::Ex,
    pub cases: Array<(crate::lower::model::Pa, Array<crate::lower::model::Do>)>,
}

impl prism_rtl::Job<Text> for CppDoMatch {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let x = &self.x;
        let cases = &self.cases;
        let v_ = Text::lit("_m");
        let cases = cases.clone();
        let cp = cp.clone();
        let x = x.clone();
        call_value(each_job(cases.clone(), {
            let cp = cp.clone();
            let v_ = v_.clone();
            Rc::new(move |p0: (crate::lower::model::Pa, Array<crate::lower::model::Do>)| {
                let cp = cp.clone();
                let v_ = v_.clone();
                entered(once_job(move || {
                    let (p_, body) = p0;
                    call_then(start_pat_conds(cp.clone(), p_.clone(), v_.clone()), move |pat_conds_54160: Array<Text>| {
                        let tests = pat_conds_54160;
                        call_then(start_pat_binds(cp.clone(), p_.clone(), v_.clone()), move |pat_binds_54212: Array<Text>| call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_54235: Text| {
                            let inner = crate::syntax::lexer::join(&append(&pat_binds_54212, &Array::from(vec![cpp_statements_54235])), &Text::lit("\n"));
                            prism_rtl::Turn::Finished((tests.clone(), inner.clone()))
                        }))
                    })
                }))
            }) as Rc<dyn Fn((crate::lower::model::Pa, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Text)>>>
        }), move |each_54113: Array<(Array<Text>, Text)>| {
            let arms = each_54113;
            let blocks = each(&crate::check::errors::range0(&len(&arms)), &(|i: &Nat| {
                let (tests, inner) = or(&index(&arms, i), &(Array::new(), Text::lit("")));
                let head = if i == &Nat::from(0u32) {
                    Text::from(format!("if ({})", &conds(&tests)))
                } else {
                    if &len(&tests) == &Nat::from(0u32) {
                        Text::lit("else")
                    } else {
                        Text::from(format!("else if ({})", &conds(&tests)))
                    }
                };
                crate::emit::cpp::templates::block(&head, &inner)
            }));
            call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_54565: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::braced(&Text::from(format!("auto&& _m = {};\n{}", &cpp_expr_54565, &crate::syntax::lexer::join(&blocks, &Text::lit(" ")))))))
        })
    }
}

/// `Start CppDoMatch, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_do_match(cp: Cp, x: crate::lower::model::Ex, cases: Array<(crate::lower::model::Pa, Array<crate::lower::model::Do>)>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppDoMatch { cp, x, cases })
}

/// ```prism
/// CppFor: unbounded fn Cp, Pa, Ex, [Do] -> Text
/// ```
pub fn cpp_for(cp0: &Cp, p_: &crate::lower::model::Pa, x: &crate::lower::model::Ex, body: &Array<crate::lower::model::Do>) -> Text {
    cpp_for_in(&unbind(cp0, &pat_names(p_)), p_, &cpp_expr(cp0, x), body)
}

/// The step machine of `CppFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppFor: unbounded fn Cp, Pa, Ex, [Do] -> Text
/// ```
pub struct CppFor {
    pub cp0: Cp,
    pub p_: crate::lower::model::Pa,
    pub x: crate::lower::model::Ex,
    pub body: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for CppFor {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp0 = &self.cp0;
        let p_ = &self.p_;
        let x = &self.x;
        let body = &self.body;
        let body = body.clone();
        let cp0 = cp0.clone();
        let p_ = p_.clone();
        let x = x.clone();
        call_then(start_pat_names(p_.clone()), move |pat_names_54779: Array<Text>| call_then(start_cpp_expr(cp0.clone(), x.clone()), move |cpp_expr_54797: Text| prism_rtl::Turn::More(Rc::new(CppForIn { cp: unbind(&cp0, &pat_names_54779), p_: p_.clone(), xs: cpp_expr_54797, body: body.clone() }))))
    }
}

/// `Start CppFor, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_for(cp0: Cp, p_: crate::lower::model::Pa, x: crate::lower::model::Ex, body: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppFor { cp0, p_, x, body })
}

/// ```prism
/// CppForIn: unbounded fn Cp, Pa, Text, [Do] -> Text
/// ```
pub fn cpp_for_in(cp: &Cp, p_: &crate::lower::model::Pa, xs: &Text, body: &Array<crate::lower::model::Do>) -> Text {
    match p_ {
        crate::lower::model::Pa::PaBind(n) => crate::emit::cpp::templates::block(&Text::from(format!("for (auto&& {} : {})", &cpp_id(n), xs)), &cpp_statements(cp, body)),
        crate::lower::model::Pa::PaMut(n) => crate::emit::cpp::templates::block(&Text::from(format!("for (auto {} : {})", &cpp_id(n), xs)), &cpp_statements(cp, body)),
        crate::lower::model::Pa::PaTuple(ps) => if fold(ps, &true, &(|f: &bool, q: &crate::lower::model::Pa| *f && is_name(q))) {
            crate::emit::cpp::templates::block(&Text::from(format!("for (auto&& [{}] : {})", &crate::syntax::lexer::join(&each(ps, &(|q: &crate::lower::model::Pa| pat_name(q))), &Text::lit(", ")), xs)), &cpp_statements(cp, body))
        } else {
            crate::emit::cpp::templates::block(&Text::from(format!("for (auto&& _e : {})", xs)), &crate::syntax::lexer::join(&append(&pat_binds(cp, p_, &Text::lit("_e")), &Array::from(vec![cpp_statements(cp, body)])), &Text::lit("\n")))
        },
        _ => crate::emit::cpp::templates::block(&Text::from(format!("for (auto&& _e : {})", xs)), &crate::syntax::lexer::join(&append(&pat_binds(cp, p_, &Text::lit("_e")), &Array::from(vec![cpp_statements(cp, body)])), &Text::lit("\n"))),
    }
}

/// The step machine of `CppForIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppForIn: unbounded fn Cp, Pa, Text, [Do] -> Text
/// ```
pub struct CppForIn {
    pub cp: Cp,
    pub p_: crate::lower::model::Pa,
    pub xs: Text,
    pub body: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for CppForIn {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let p_ = &self.p_;
        let xs = &self.xs;
        let body = &self.body;
        match p_ {
            crate::lower::model::Pa::PaBind(n) => {
                let body = body.clone();
                let cp = cp.clone();
                let n = n.clone();
                let xs = xs.clone();
                call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_54963: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::block(&Text::from(format!("for (auto&& {} : {})", &cpp_id(&n), &xs)), &cpp_statements_54963)))
            },
            crate::lower::model::Pa::PaMut(n) => {
                let body = body.clone();
                let cp = cp.clone();
                let n = n.clone();
                let xs = xs.clone();
                call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_55038: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::block(&Text::from(format!("for (auto {} : {})", &cpp_id(&n), &xs)), &cpp_statements_55038)))
            },
            crate::lower::model::Pa::PaTuple(ps) => if fold(ps, &true, &(|f: &bool, q: &crate::lower::model::Pa| *f && is_name(q))) {
                {
                    let body = body.clone();
                    let cp = cp.clone();
                    let ps = ps.clone();
                    let xs = xs.clone();
                    call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_55199: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::block(&Text::from(format!("for (auto&& [{}] : {})", &crate::syntax::lexer::join(&each(&ps, &(|q: &crate::lower::model::Pa| pat_name(q))), &Text::lit(", ")), &xs)), &cpp_statements_55199)))
                }
            } else {
                {
                    let body = body.clone();
                    let cp = cp.clone();
                    let p_ = p_.clone();
                    let xs = xs.clone();
                    call_then(start_pat_binds(cp.clone(), p_.clone(), Text::lit("_e")), move |pat_binds_55284: Array<Text>| call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_55310: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::block(&Text::from(format!("for (auto&& _e : {})", &xs)), &crate::syntax::lexer::join(&append(&pat_binds_55284, &Array::from(vec![cpp_statements_55310])), &Text::lit("\n"))))))
                }
            },
            _ => {
                let body = body.clone();
                let cp = cp.clone();
                let p_ = p_.clone();
                let xs = xs.clone();
                call_then(start_pat_binds(cp.clone(), p_.clone(), Text::lit("_e")), move |pat_binds_55406: Array<Text>| call_then(start_cpp_statements(cp.clone(), body.clone()), move |cpp_statements_55432: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::block(&Text::from(format!("for (auto&& _e : {})", &xs)), &crate::syntax::lexer::join(&append(&pat_binds_55406, &Array::from(vec![cpp_statements_55432])), &Text::lit("\n"))))))
            },
        }
    }
}

/// `Start CppForIn, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_for_in(cp: Cp, p_: crate::lower::model::Pa, xs: Text, body: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppForIn { cp, p_, xs, body })
}

/// ```prism
/// CppBody: unbounded fn Cp, Ex -> Text
/// ```
pub fn cpp_body(cp: &Cp, ex1: &crate::lower::model::Ex) -> Text {
    match ex1 {
        crate::lower::model::Ex::XBlock(dos, e) => {
            let (st, cp2) = cpp_statements_cp(cp, dos);
            if &len(dos) == &Nat::from(0u32) {
                cpp_body(cp, &**e)
            } else {
                Text::from(format!("{}\n{}", &st, &cpp_body(&cp2, &**e)))
            }
        },
        crate::lower::model::Ex::XMatch(s, arms, fallback, t) => return_match(cp, &**s, arms, t),
        crate::lower::model::Ex::XChain(label, s, arms, t) => return_match(cp, &**s, arms, t),
        x => if leaves(x) {
            Text::from(format!("{};", &cpp_expr(cp, x)))
        } else {
            Text::from(format!("return {};", &cpp_expr(cp, x)))
        },
    }
}

/// The step machine of `CppBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppBody: unbounded fn Cp, Ex -> Text
/// ```
pub struct CppBody {
    pub cp: Cp,
    pub ex1: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for CppBody {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let ex1 = &self.ex1;
        match ex1 {
            crate::lower::model::Ex::XBlock(dos, e) => {
                let cp = cp.clone();
                let dos = dos.clone();
                let e = (**e).clone();
                call_then(start_cpp_statements_cp(cp.clone(), dos.clone()), move |cpp_statements_cp_55620: (Text, Cp)| {
                    let (st, cp2) = cpp_statements_cp_55620;
                    if &len(&dos) == &Nat::from(0u32) {
                        prism_rtl::Turn::More(Rc::new(CppBody { cp: cp.clone(), ex1: e.clone() }))
                    } else {
                        call_then(start_cpp_body(cp2.clone(), e.clone()), move |cpp_body_55695: Text| prism_rtl::Turn::Finished(Text::from(format!("{}\n{}", &st, &cpp_body_55695))))
                    }
                })
            },
            crate::lower::model::Ex::XMatch(s, arms, fallback, t) => prism_rtl::Turn::More(Rc::new(ReturnMatch { cp: cp.clone(), s: (**s).clone(), arms: arms.clone(), out_ty3: t.clone() })),
            crate::lower::model::Ex::XChain(label, s, arms, t) => prism_rtl::Turn::More(Rc::new(ReturnMatch { cp: cp.clone(), s: (**s).clone(), arms: arms.clone(), out_ty3: t.clone() })),
            x => if leaves(x) {
                {
                    let cp = cp.clone();
                    let x = x.clone();
                    call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_55891: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &cpp_expr_55891))))
                }
            } else {
                {
                    let cp = cp.clone();
                    let x = x.clone();
                    call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_55923: Text| prism_rtl::Turn::Finished(Text::from(format!("return {};", &cpp_expr_55923))))
                }
            },
        }
    }
}

/// `Start CppBody, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_body(cp: Cp, ex1: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppBody { cp, ex1 })
}

/// ```prism
/// CppTemplateHead: fn [Text] -> Text
/// ```
pub fn cpp_template_head(xs0: &Array<Text>) -> Text {
    match xs0 {
        c0_0 if (c0_0.len() == 0) => Text::lit(""),
        ps => Text::from(format!("template <{}>\n", &crate::syntax::lexer::join(&each(ps, &(|p_: &Text| Text::from(format!("class {}", p_)))), &Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// GenericNamesOf: fn [((Text, [Text]))] -> [Text]
/// ```
pub fn generic_names_of(gs: &Array<(Text, Array<Text>)>) -> Array<Text> {
    each(gs, &(|(g, _): &(Text, Array<Text>)| g.clone()))
}

/// ```prism
/// HeadOf: fn Text, [Text] -> Text
/// ```
pub fn head_of(name: &Text, xs1: &Array<Text>) -> Text {
    match xs1 {
        c0_1 if (c0_1.len() == 0) => name.clone(),
        ps => Text::from(format!("{}<{}>", name, &crate::syntax::lexer::join(ps, &Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CppParams: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub fn cpp_params(cp: &Cp, ps: &Array<(Text, crate::lower::model::OutTy)>) -> Text {
    crate::syntax::lexer::join(&run_to_end(each_job(ps.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (n, t) = p0;
                call_then(start_param_type(cp.clone(), t.clone()), move |param_type_56695: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_56695, &cpp_id(&n)))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "))
}

/// The step machine of `CppParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppParams: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub struct CppParams {
    pub cp: Cp,
    pub ps: Array<(Text, crate::lower::model::OutTy)>,
}

impl prism_rtl::Job<Text> for CppParams {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let ps = &self.ps;
        let cp = cp.clone();
        let ps = ps.clone();
        call_value(each_job(ps.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let (n, t) = p0;
                    call_then(start_param_type(cp.clone(), t.clone()), move |param_type_56695: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_56695, &cpp_id(&n)))))
                }))
            }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_56672: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::join(&each_56672, &Text::lit(", "))))
    }
}

/// `Start CppParams, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_params(cp: Cp, ps: Array<(Text, crate::lower::model::OutTy)>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppParams { cp, ps })
}

/// ```prism
/// FnSignature: unbounded fn Cp, FnDef -> Text
/// ```
pub fn fn_signature(cp: &Cp, f: &crate::lower::model::FnDef) -> Text {
    Text::from(format!("{}{} {}({})", &cpp_template_head(&generic_names_of(&f.generics)), &cpp_type(cp, &f.ret), &cpp_id(&f.name), &cpp_params(cp, &f.params)))
}

/// The step machine of `FnSignature`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnSignature: unbounded fn Cp, FnDef -> Text
/// ```
pub struct FnSignature {
    pub cp: Cp,
    pub f: crate::lower::model::FnDef,
}

impl prism_rtl::Job<Text> for FnSignature {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let f = &self.f;
        let cp = cp.clone();
        let f = f.clone();
        call_then(start_cpp_type(cp.clone(), f.ret.clone()), move |cpp_type_56926: Text| call_then(start_cpp_params(cp.clone(), f.params.clone()), move |cpp_params_56961: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{} {}({})", &cpp_template_head(&generic_names_of(&f.generics)), &cpp_type_56926, &cpp_id(&f.name), &cpp_params_56961)))))
    }
}

/// `Start FnSignature, x`: what the function value is when passed to `@Run`.
pub fn start_fn_signature(cp: Cp, f: crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FnSignature { cp, f })
}

/// ```prism
/// FnDefinition: unbounded fn Cp, FnDef -> Text
/// ```
pub fn fn_definition(cp: &Cp, f: &crate::lower::model::FnDef) -> Text {
    crate::emit::cpp::templates::cpp_function(&cpp_doc(&f.doc), &fn_signature(cp, f), &cpp_body(cp, &f.body))
}

/// The step machine of `FnDefinition`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnDefinition: unbounded fn Cp, FnDef -> Text
/// ```
pub struct FnDefinition {
    pub cp: Cp,
    pub f: crate::lower::model::FnDef,
}

impl prism_rtl::Job<Text> for FnDefinition {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let f = &self.f;
        let cp = cp.clone();
        let f = f.clone();
        call_then(start_fn_signature(cp.clone(), f.clone()), move |fn_signature_57086: Text| call_then(start_cpp_body(cp.clone(), f.body.clone()), move |cpp_body_57107: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::cpp_function(&cpp_doc(&f.doc), &fn_signature_57086, &cpp_body_57107))))
    }
}

/// `Start FnDefinition, x`: what the function value is when passed to `@Run`.
pub fn start_fn_definition(cp: Cp, f: crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FnDefinition { cp, f })
}

/// ```prism
/// ValueDeps: unbounded fn Cp, OutTy -> [Text]
/// ```
pub fn value_deps(cp: &Cp, t: &crate::lower::model::OutTy) -> Array<Text> {
    match t {
        crate::lower::model::OutTy::OutNamed(n, args) => {
            let own = match type_of(cp, n) {
                Some(info) => if (((&info.kind == &Text::lit("record")) || (&info.kind == &Text::lit("newtype"))) || (&info.kind == &Text::lit("unit"))) || (&info.kind == &Text::lit("tag")) {
                    Array::from(vec![absolute(cp, n)])
                } else {
                    Array::new()
                },
                None => Array::new(),
            };
            append(&own, &concat2(&run_to_end(each_job(args.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: crate::lower::model::OutTy| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: a.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }))))
        },
        crate::lower::model::OutTy::OutOpt(i) => value_deps(cp, &**i),
        crate::lower::model::OutTy::OutRes(i) => value_deps(cp, &**i),
        crate::lower::model::OutTy::OutRc(i) => value_deps(cp, &**i),
        crate::lower::model::OutTy::OutCell(i) => value_deps(cp, &**i),
        crate::lower::model::OutTy::OutTuple(ts) => concat2(&run_to_end(each_job(ts.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: crate::lower::model::OutTy| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }))),
        _ => Array::new(),
    }
}

/// The step machine of `ValueDeps`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ValueDeps: unbounded fn Cp, OutTy -> [Text]
/// ```
pub struct ValueDeps {
    pub cp: Cp,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Array<Text>> for ValueDeps {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cp = &self.cp;
        let t = &self.t;
        match t {
            crate::lower::model::OutTy::OutNamed(n, args) => {
                let own = match type_of(cp, n) {
                    Some(info) => if (((&info.kind == &Text::lit("record")) || (&info.kind == &Text::lit("newtype"))) || (&info.kind == &Text::lit("unit"))) || (&info.kind == &Text::lit("tag")) {
                        Array::from(vec![absolute(cp, n)])
                    } else {
                        Array::new()
                    },
                    None => Array::new(),
                };
                let args = args.clone();
                let cp = cp.clone();
                call_value(each_job(args.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: crate::lower::model::OutTy| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: a.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_58222: Array<Array<Text>>| prism_rtl::Turn::Finished(append(&own, &concat2(&each_58222))))
            },
            crate::lower::model::OutTy::OutOpt(i) => prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: (**i).clone() })),
            crate::lower::model::OutTy::OutRes(i) => prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: (**i).clone() })),
            crate::lower::model::OutTy::OutRc(i) => prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: (**i).clone() })),
            crate::lower::model::OutTy::OutCell(i) => prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: (**i).clone() })),
            crate::lower::model::OutTy::OutTuple(ts) => {
                let cp = cp.clone();
                let ts = ts.clone();
                call_value(each_job(ts.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: crate::lower::model::OutTy| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: a.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_58402: Array<Array<Text>>| prism_rtl::Turn::Finished(concat2(&each_58402)))
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start ValueDeps, x`: what the function value is when passed to `@Run`.
pub fn start_value_deps(cp: Cp, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ValueDeps { cp, t })
}

/// ```prism
/// let noParts
/// ```
pub fn no_parts() -> Parts {
    Parts { forward: Array::new(), handles: Array::new(), values: Array::new(), cases: Array::new(), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: Array::new() }
}

/// ```prism
/// JoinParts: fn Parts, Parts -> Parts
/// ```
pub fn join_parts(a: &Parts, b: &Parts) -> Parts {
    Parts { forward: append(&a.forward, &b.forward), handles: append(&a.handles, &b.handles), values: append(&a.values, &b.values), cases: append(&a.cases, &b.cases), protos: append(&a.protos, &b.protos), classes: append(&a.classes, &b.classes), outer: append(&a.outer, &b.outer), generic: append(&a.generic, &b.generic), defs: append(&a.defs, &b.defs) }
}

/// ```prism
/// ItemParts: unbounded fn Cp, Item -> Parts
/// ```
pub fn item_parts(cp: &Cp, it: &crate::lower::model::Item) -> Parts {
    match it {
        crate::lower::model::Item::ItType(t) => type_parts(cp, t),
        crate::lower::model::Item::ItTag(t) => tag_parts(cp, t),
        crate::lower::model::Item::ItRow(r) => row_parts(cp, &cp.home, r),
        crate::lower::model::Item::ItFn(f) => fn_parts(cp, f),
        crate::lower::model::Item::ItJob(j) => job_parts(cp, j),
        crate::lower::model::Item::ItNode(n) => node_parts(cp, n),
        crate::lower::model::Item::ItTrait(t) => trait_parts(cp, t),
        crate::lower::model::Item::ItImpl(i) => impl_parts(cp, i),
        crate::lower::model::Item::ItNote(t) => protos_defs(&Array::new(), &Array::from(vec![Text::from(format!("// {}", t))])),
        crate::lower::model::Item::ItRefused(t) => protos_defs(&Array::new(), &Array::from(vec![Text::from(format!("compile_error!(\"{}{}\");", &crate::lower::lowering_refusal(), &crate::lower::escape(t)))])),
    }
}

/// The step machine of `ItemParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ItemParts: unbounded fn Cp, Item -> Parts
/// ```
pub struct ItemParts {
    pub cp: Cp,
    pub it: crate::lower::model::Item,
}

impl prism_rtl::Job<Parts> for ItemParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let it = &self.it;
        match it {
            crate::lower::model::Item::ItType(t) => prism_rtl::Turn::More(Rc::new(TypeParts { cp: cp.clone(), t: t.clone() })),
            crate::lower::model::Item::ItTag(t) => prism_rtl::Turn::More(Rc::new(TagParts { cp: cp.clone(), t: t.clone() })),
            crate::lower::model::Item::ItRow(r) => prism_rtl::Turn::More(Rc::new(RowParts { cp: cp.clone(), m: cp.home.clone(), r: r.clone() })),
            crate::lower::model::Item::ItFn(f) => prism_rtl::Turn::More(Rc::new(FnParts { cp: cp.clone(), f: f.clone() })),
            crate::lower::model::Item::ItJob(j) => prism_rtl::Turn::More(Rc::new(JobParts { cp: cp.clone(), j: j.clone() })),
            crate::lower::model::Item::ItNode(n) => prism_rtl::Turn::More(Rc::new(NodeParts { cp: cp.clone(), n: n.clone() })),
            crate::lower::model::Item::ItTrait(t) => prism_rtl::Turn::More(Rc::new(TraitParts { cp: cp.clone(), t: t.clone() })),
            crate::lower::model::Item::ItImpl(i) => prism_rtl::Turn::More(Rc::new(ImplParts { cp: cp.clone(), i: i.clone() })),
            crate::lower::model::Item::ItNote(t) => prism_rtl::Turn::Finished(protos_defs(&Array::new(), &Array::from(vec![Text::from(format!("// {}", t))]))),
            crate::lower::model::Item::ItRefused(t) => prism_rtl::Turn::Finished(protos_defs(&Array::new(), &Array::from(vec![Text::from(format!("compile_error!(\"{}{}\");", &crate::lower::lowering_refusal(), &crate::lower::escape(t)))]))),
        }
    }
}

/// `Start ItemParts, x`: what the function value is when passed to `@Run`.
pub fn start_item_parts(cp: Cp, it: crate::lower::model::Item) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(ItemParts { cp, it })
}

/// ```prism
/// FnParts: unbounded fn Cp, FnDef -> Parts
/// ```
pub fn fn_parts(cp: &Cp, f: &crate::lower::model::FnDef) -> Parts {
    if &len(&f.generics) > &Nat::from(0u32) {
        {
            let mut this: Parts = generic_only(&Array::from(vec![fn_definition(cp, f)]));
            this.protos = Array::from(vec![Text::from(format!("{};", &fn_signature(cp, f)))]);
            this
        }
    } else {
        protos_defs(&Array::from(vec![Text::from(format!("{};", &fn_signature(cp, f)))]), &Array::from(vec![fn_definition(cp, f)]))
    }
}

/// The step machine of `FnParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnParts: unbounded fn Cp, FnDef -> Parts
/// ```
pub struct FnParts {
    pub cp: Cp,
    pub f: crate::lower::model::FnDef,
}

impl prism_rtl::Job<Parts> for FnParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let f = &self.f;
        if &len(&f.generics) > &Nat::from(0u32) {
            prism_rtl::Turn::Finished({
                let mut this: Parts = generic_only(&Array::from(vec![fn_definition(cp, f)]));
                this.protos = Array::from(vec![Text::from(format!("{};", &fn_signature(cp, f)))]);
                this
            })
        } else {
            {
                let cp = cp.clone();
                let f = f.clone();
                call_then(start_fn_signature(cp.clone(), f.clone()), move |fn_signature_59636: Text| call_then(start_fn_definition(cp.clone(), f.clone()), move |fn_definition_59663: Text| prism_rtl::Turn::Finished(protos_defs(&Array::from(vec![Text::from(format!("{};", &fn_signature_59636))]), &Array::from(vec![fn_definition_59663])))))
            }
        }
    }
}

/// `Start FnParts, x`: what the function value is when passed to `@Run`.
pub fn start_fn_parts(cp: Cp, f: crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(FnParts { cp, f })
}

/// ```prism
/// CppDoc: fn Text -> Text
/// ```
pub fn cpp_doc(text: &Text) -> Text {
    if text == &Text::lit("") {
        Text::lit("")
    } else {
        concat(&each(&split(text, &Text::lit("\n")), &(|l: &Text| if l == &Text::lit("") {
            Text::lit("///\n")
        } else {
            Text::from(format!("/// {}\n", l))
        })))
    }
}

/// ```prism
/// CppSourceDoc: fn Text, Text -> Text
/// ```
pub fn cpp_source_doc(lead: &Text, source: &Text) -> Text {
    let quoted = concat(&each(&split(source, &Text::lit("\n")), &(|l: &Text| if l == &Text::lit("") {
        Text::lit("///\n")
    } else {
        Text::from(format!("/// {}\n", l))
    })));
    if source == &Text::lit("") {
        cpp_doc(lead)
    } else {
        if lead == &Text::lit("") {
            Text::from(format!("/// ```prism\n{}/// ```\n", &quoted))
        } else {
            Text::from(format!("/// {}\n///\n/// ```prism\n{}/// ```\n", lead, &quoted))
        }
    }
}

/// ```prism
/// TypeParts: unbounded fn Cp, TyDef -> Parts
/// ```
pub fn type_parts(cp: &Cp, t: &crate::lower::model::TyDef) -> Parts {
    let eq = t.eq;
    let ord = t.ord && !t.floaty;
    let gens = cpp_template_head(&t.params);
    let head = head_of(&t.name, &t.params);
    let doc = cpp_source_doc(&Text::from(format!("`{}`:", &t.prism)), &t.doc);
    let members_ = members(&(&t.show != &crate::lower::model::Shown::NotShown), &t.pod, &head);
    let generic = &len(&t.params) > &Nat::from(0u32);
    let fwd = Text::from(format!("{}{} {};", &gens, &(if &t.shape == &crate::lower::model::TyShape::ShapeChoice {
        Text::lit("class")
    } else {
        Text::lit("struct")
    }), &t.name));
    match &t.shape {
        crate::lower::model::TyShape::ShapeChoice => {
            let names = each(&t.cases, &(|c: &crate::lower::model::CaseDef| c.name.clone()));
            let friend_eq = if eq && !generic {
                Text::from(format!("\nfriend inline bool operator==(const {}& a, const {}& b);", &head, &head))
            } else {
                Text::lit("")
            };
            let handle = crate::emit::cpp::templates::choice_handle(&doc, &gens, &t.name, &crate::syntax::lexer::join(&each(&names, &(|n: &Text| Text::from(format!("struct {};", n)))), &Text::lit("\n")), &crate::syntax::lexer::join(&names, &Text::lit(", ")), &Text::from(format!("{}{}", &members_, &friend_eq)));
            let cases = run_to_end(each_job(t.cases.clone(), {
                let cp = cp.clone();
                let gens = gens.clone();
                let head = head.clone();
                let eq = eq;
                let ord = ord;
                Rc::new(move |p0: crate::lower::model::CaseDef| {
                    let cp = cp.clone();
                    let gens = gens.clone();
                    let head = head.clone();
                    let eq = eq;
                    let ord = ord;
                    entered(once_job(move || {
                        let c = p0;
                        prism_rtl::Turn::More(Rc::new(CaseStruct { cp: cp.clone(), gens: gens.clone(), head: head.clone(), c: c.clone(), eq, ord }))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            let cmp = crate::syntax::lexer::join(&filter(&Array::from(vec![if eq {
                Text::from(format!("{}inline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &gens, &head, &head))
            } else {
                Text::lit("")
            }, if ord {
                Text::from(format!("{}inline auto operator<=>(const {}& a, const {}& b) {{ return a.cases() <=> b.cases(); }}", &gens, &head, &head))
            } else {
                Text::lit("")
            }]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n"));
            let defs = type_defs(cp, t, &head);
            Parts { forward: Array::from(vec![fwd.clone()]), handles: Array::from(vec![handle.clone()]), values: Array::new(), cases: append(&cases, &Array::from(vec![cases_accessor(&gens, &head), cmp.clone()])), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: if generic { Array::from(vec![defs.clone()]) } else { Array::new() }, defs: if generic { Array::new() } else { Array::from(vec![defs.clone()]) } }
        },
        _ => {
            let first_ = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            let fields = match &t.shape {
                crate::lower::model::TyShape::ShapeRecord => crate::syntax::lexer::join(&run_to_end(each_job(first_.fields.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let (f, ft) = p0;
                            call_then(start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_62275: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_62275, &field_id(&f)))))
                        }))
                    }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
                })), &Text::lit("\n")),
                crate::lower::model::TyShape::ShapeNewtype => positional_fields(cp, &first_.fields),
                _ => Text::lit(""),
            };
            let cmps = crate::syntax::lexer::join(&filter(&Array::from(vec![if eq {
                Text::from(format!("bool operator==(const {}&) const = default;", &t.name))
            } else {
                Text::lit("")
            }, if ord {
                Text::from(format!("auto operator<=>(const {}&) const = default;", &t.name))
            } else {
                Text::lit("")
            }]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n"));
            let decl = crate::emit::cpp::templates::value_struct(&doc, &gens, &t.name, &fields, &crate::syntax::lexer::join(&filter(&Array::from(vec![cmps.clone(), members_.clone()]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n")));
            let defs = type_defs(cp, t, &head);
            let deps = concat2(&run_to_end(each_job(first_.fields.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let (_, ft) = p0;
                        prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: ft.clone() }))
                    }))
                }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            })));
            Parts { forward: Array::from(vec![fwd.clone()]), handles: Array::new(), values: Array::from(vec![ValueDecl { path_: Text::from(format!("{}::{}", &cp.home, &t.name)), deps: deps.clone(), text: decl.clone() }]), cases: Array::new(), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: if generic { Array::from(vec![defs.clone()]) } else { Array::new() }, defs: if generic { Array::new() } else { Array::from(vec![defs.clone()]) } }
        },
    }
}

/// The step machine of `TypeParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeParts: unbounded fn Cp, TyDef -> Parts
/// ```
pub struct TypeParts {
    pub cp: Cp,
    pub t: crate::lower::model::TyDef,
}

impl prism_rtl::Job<Parts> for TypeParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let t = &self.t;
        let eq = t.eq;
        let ord = t.ord && !t.floaty;
        let gens = cpp_template_head(&t.params);
        let head = head_of(&t.name, &t.params);
        let doc = cpp_source_doc(&Text::from(format!("`{}`:", &t.prism)), &t.doc);
        let members_ = members(&(&t.show != &crate::lower::model::Shown::NotShown), &t.pod, &head);
        let generic = &len(&t.params) > &Nat::from(0u32);
        let fwd = Text::from(format!("{}{} {};", &gens, &(if &t.shape == &crate::lower::model::TyShape::ShapeChoice {
            Text::lit("class")
        } else {
            Text::lit("struct")
        }), &t.name));
        match &t.shape {
            crate::lower::model::TyShape::ShapeChoice => {
                let names = each(&t.cases, &(|c: &crate::lower::model::CaseDef| c.name.clone()));
                let friend_eq = if eq && !generic {
                    Text::from(format!("\nfriend inline bool operator==(const {}& a, const {}& b);", &head, &head))
                } else {
                    Text::lit("")
                };
                let handle = crate::emit::cpp::templates::choice_handle(&doc, &gens, &t.name, &crate::syntax::lexer::join(&each(&names, &(|n: &Text| Text::from(format!("struct {};", n)))), &Text::lit("\n")), &crate::syntax::lexer::join(&names, &Text::lit(", ")), &Text::from(format!("{}{}", &members_, &friend_eq)));
                let cp = cp.clone();
                let t = t.clone();
                call_value(each_job(t.cases.clone(), {
                    let cp = cp.clone();
                    let gens = gens.clone();
                    let head = head.clone();
                    let eq = eq;
                    let ord = ord;
                    Rc::new(move |p0: crate::lower::model::CaseDef| {
                        let cp = cp.clone();
                        let gens = gens.clone();
                        let head = head.clone();
                        let eq = eq;
                        let ord = ord;
                        entered(once_job(move || {
                            let c = p0;
                            prism_rtl::Turn::More(Rc::new(CaseStruct { cp: cp.clone(), gens: gens.clone(), head: head.clone(), c: c.clone(), eq, ord }))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_61412: Array<Text>| {
                    let cases = each_61412;
                    let cmp = crate::syntax::lexer::join(&filter(&Array::from(vec![if eq {
                        Text::from(format!("{}inline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &gens, &head, &head))
                    } else {
                        Text::lit("")
                    }, if ord {
                        Text::from(format!("{}inline auto operator<=>(const {}& a, const {}& b) {{ return a.cases() <=> b.cases(); }}", &gens, &head, &head))
                    } else {
                        Text::lit("")
                    }]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n"));
                    call_then(start_type_defs(cp.clone(), t.clone(), head.clone()), move |type_defs_61796: Text| {
                        let defs = type_defs_61796;
                        prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![fwd.clone()]), handles: Array::from(vec![handle.clone()]), values: Array::new(), cases: append(&cases, &Array::from(vec![cases_accessor(&gens, &head), cmp.clone()])), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: if generic { Array::from(vec![defs.clone()]) } else { Array::new() }, defs: if generic { Array::new() } else { Array::from(vec![defs.clone()]) } })
                    })
                })
            },
            _ => {
                let first_ = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                let fields = match &t.shape {
                    crate::lower::model::TyShape::ShapeRecord => crate::syntax::lexer::join(&run_to_end(each_job(first_.fields.clone(), {
                        let cp = cp.clone();
                        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                            let cp = cp.clone();
                            entered(once_job(move || {
                                let (f, ft) = p0;
                                call_then(start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_62275: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_62275, &field_id(&f)))))
                            }))
                        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
                    })), &Text::lit("\n")),
                    crate::lower::model::TyShape::ShapeNewtype => positional_fields(cp, &first_.fields),
                    _ => Text::lit(""),
                };
                let cmps = crate::syntax::lexer::join(&filter(&Array::from(vec![if eq {
                    Text::from(format!("bool operator==(const {}&) const = default;", &t.name))
                } else {
                    Text::lit("")
                }, if ord {
                    Text::from(format!("auto operator<=>(const {}&) const = default;", &t.name))
                } else {
                    Text::lit("")
                }]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n"));
                let decl = crate::emit::cpp::templates::value_struct(&doc, &gens, &t.name, &fields, &crate::syntax::lexer::join(&filter(&Array::from(vec![cmps.clone(), members_.clone()]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n")));
                let cp = cp.clone();
                let t = t.clone();
                call_then(start_type_defs(cp.clone(), t.clone(), head.clone()), move |type_defs_62749: Text| {
                    let defs = type_defs_62749;
                    call_value(each_job(first_.fields.clone(), {
                        let cp = cp.clone();
                        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                            let cp = cp.clone();
                            entered(once_job(move || {
                                let (_, ft) = p0;
                                prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: ft.clone() }))
                            }))
                        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }), move |each_62802: Array<Array<Text>>| {
                        let deps = concat2(&each_62802);
                        prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![fwd.clone()]), handles: Array::new(), values: Array::from(vec![ValueDecl { path_: Text::from(format!("{}::{}", &cp.home, &t.name)), deps: deps.clone(), text: decl.clone() }]), cases: Array::new(), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: if generic { Array::from(vec![defs.clone()]) } else { Array::new() }, defs: if generic { Array::new() } else { Array::from(vec![defs.clone()]) } })
                    })
                })
            },
        }
    }
}

/// `Start TypeParts, x`: what the function value is when passed to `@Run`.
pub fn start_type_parts(cp: Cp, t: crate::lower::model::TyDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(TypeParts { cp, t })
}

/// ```prism
/// CasesAccessor: fn Text, Text -> Text
/// ```
pub fn cases_accessor(gens: &Text, head: &Text) -> Text {
    Text::from(format!("{}inline const {}{}::Cases& {}::cases() const {{ return *cases_; }}", gens, &(if gens == &Text::lit("") { Text::lit("") } else { Text::lit("typename ") }), head, head))
}

/// ```prism
/// Members: fn Bool, Bool, Text -> Text
/// ```
pub fn members(shown: &bool, pod: &bool, head: &Text) -> Text {
    let s = if *shown {
        Array::from(vec![Text::lit("void show(Printer& p) const;")])
    } else {
        Array::new()
    };
    let d = if *pod {
        Array::from(vec![Text::lit("Pod to_pod() const;"), Text::from(format!("static Result<{}> from_pod(const Pod& whole);", head))])
    } else {
        Array::new()
    };
    crate::syntax::lexer::join(&append(&s, &d), &Text::lit("\n"))
}

/// ```prism
/// CaseStruct: unbounded fn Cp, Text, Text, CaseDef, Bool, Bool -> Text
/// ```
pub fn case_struct(cp: &Cp, gens: &Text, head: &Text, c: &crate::lower::model::CaseDef, eq: &bool, ord: &bool) -> Text {
    let fields = positional_fields(cp, &c.fields);
    let cmps = crate::syntax::lexer::join(&filter(&Array::from(vec![if *eq {
        Text::from(format!("bool operator==(const {}&) const = default;", &c.name))
    } else {
        Text::lit("")
    }, if *ord {
        Text::from(format!("auto operator<=>(const {}&) const = default;", &c.name))
    } else {
        Text::lit("")
    }]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n"));
    crate::emit::cpp::templates::case_decl(gens, &Text::from(format!("{}::{}", head, &c.name)), &crate::syntax::lexer::join(&filter(&Array::from(vec![fields.clone(), cmps.clone()]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n")))
}

/// The step machine of `CaseStruct`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CaseStruct: unbounded fn Cp, Text, Text, CaseDef, Bool, Bool -> Text
/// ```
pub struct CaseStruct {
    pub cp: Cp,
    pub gens: Text,
    pub head: Text,
    pub c: crate::lower::model::CaseDef,
    pub eq: bool,
    pub ord: bool,
}

impl prism_rtl::Job<Text> for CaseStruct {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let gens = &self.gens;
        let head = &self.head;
        let c = &self.c;
        let eq = &self.eq;
        let ord = &self.ord;
        let c = c.clone();
        let cp = cp.clone();
        let eq = *eq;
        let gens = gens.clone();
        let head = head.clone();
        let ord = *ord;
        call_then(start_positional_fields(cp.clone(), c.fields.clone()), move |positional_fields_63829: Text| {
            let fields = positional_fields_63829;
            let cmps = crate::syntax::lexer::join(&filter(&Array::from(vec![if eq {
                Text::from(format!("bool operator==(const {}&) const = default;", &c.name))
            } else {
                Text::lit("")
            }, if ord {
                Text::from(format!("auto operator<=>(const {}&) const = default;", &c.name))
            } else {
                Text::lit("")
            }]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n"));
            prism_rtl::Turn::Finished(crate::emit::cpp::templates::case_decl(&gens, &Text::from(format!("{}::{}", &head, &c.name)), &crate::syntax::lexer::join(&filter(&Array::from(vec![fields.clone(), cmps.clone()]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n"))))
        })
    }
}

/// `Start CaseStruct, x`: what the function value is when passed to `@Run`.
pub fn start_case_struct(cp: Cp, gens: Text, head: Text, c: crate::lower::model::CaseDef, eq: bool, ord: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CaseStruct { cp, gens, head, c, eq, ord })
}

/// ```prism
/// TypeDefs: unbounded fn Cp, TyDef, Text -> Text
/// ```
pub fn type_defs(cp: &Cp, t: &crate::lower::model::TyDef, head: &Text) -> Text {
    let gens = cpp_template_head(&t.params);
    let show_ = if &t.show == &crate::lower::model::Shown::ShownDerived {
        Array::from(vec![show_def(cp, t, head, &gens)])
    } else {
        Array::new()
    };
    let pod = if t.pod {
        Array::from(vec![to_pod_def(cp, t, head, &gens), from_pod_def(cp, t, head, &gens)])
    } else {
        Array::new()
    };
    crate::syntax::lexer::join(&append(&show_, &pod), &Text::lit("\n"))
}

/// The step machine of `TypeDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeDefs: unbounded fn Cp, TyDef, Text -> Text
/// ```
pub struct TypeDefs {
    pub cp: Cp,
    pub t: crate::lower::model::TyDef,
    pub head: Text,
}

impl prism_rtl::Job<Text> for TypeDefs {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let t = &self.t;
        let head = &self.head;
        let gens = cpp_template_head(&t.params);
        let show_ = if &t.show == &crate::lower::model::Shown::ShownDerived {
            Array::from(vec![show_def(cp, t, head, &gens)])
        } else {
            Array::new()
        };
        let pod = if t.pod {
            Array::from(vec![to_pod_def(cp, t, head, &gens), from_pod_def(cp, t, head, &gens)])
        } else {
            Array::new()
        };
        prism_rtl::Turn::Finished(crate::syntax::lexer::join(&append(&show_, &pod), &Text::lit("\n")))
    }
}

/// `Start TypeDefs, x`: what the function value is when passed to `@Run`.
pub fn start_type_defs(cp: Cp, t: crate::lower::model::TyDef, head: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TypeDefs { cp, t, head })
}

/// ```prism
/// ShowDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub fn show_def(cp: &Cp, t: &crate::lower::model::TyDef, head: &Text, gens: &Text) -> Text {
    let body = match &t.shape {
        crate::lower::model::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            Text::from(format!("p.record(\"{}\", {{{}}});", &t.prism, &crate::syntax::lexer::join(&each(&c.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", {}}}", &prism_field(f), &field_id(f))))), &Text::lit(", "))))
        },
        crate::lower::model::TyShape::ShapeChoice => crate::syntax::lexer::join(&each(&crate::check::errors::range0(&len(&t.cases)), &(|i: &Nat| show_case(t, i))), &Text::lit("\n")),
        crate::lower::model::TyShape::ShapeNewtype => Text::from(format!("p.choice(\"{}\", {{{}}});", &first_case(t), &crate::syntax::lexer::join(&each(&crate::check::errors::range0(&first_arity(t)), &(|k: &Nat| Text::from(format!("a{}", k)))), &Text::lit(", ")))),
        crate::lower::model::TyShape::ShapeUnit => Text::from(format!("p.choice(\"{}\", {{}});", &first_case(t))),
    };
    crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("{}void {}::show(Printer& p) const", gens, head)), &body)
}

/// The step machine of `ShowDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub struct ShowDef {
    pub cp: Cp,
    pub t: crate::lower::model::TyDef,
    pub head: Text,
    pub gens: Text,
}

impl prism_rtl::Job<Text> for ShowDef {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let t = &self.t;
        let head = &self.head;
        let gens = &self.gens;
        let body = match &t.shape {
            crate::lower::model::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                Text::from(format!("p.record(\"{}\", {{{}}});", &t.prism, &crate::syntax::lexer::join(&each(&c.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", {}}}", &prism_field(f), &field_id(f))))), &Text::lit(", "))))
            },
            crate::lower::model::TyShape::ShapeChoice => crate::syntax::lexer::join(&each(&crate::check::errors::range0(&len(&t.cases)), &(|i: &Nat| show_case(t, i))), &Text::lit("\n")),
            crate::lower::model::TyShape::ShapeNewtype => Text::from(format!("p.choice(\"{}\", {{{}}});", &first_case(t), &crate::syntax::lexer::join(&each(&crate::check::errors::range0(&first_arity(t)), &(|k: &Nat| Text::from(format!("a{}", k)))), &Text::lit(", ")))),
            crate::lower::model::TyShape::ShapeUnit => Text::from(format!("p.choice(\"{}\", {{}});", &first_case(t))),
        };
        prism_rtl::Turn::Finished(crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("{}void {}::show(Printer& p) const", gens, head)), &body))
    }
}

/// `Start ShowDef, x`: what the function value is when passed to `@Run`.
pub fn start_show_def(cp: Cp, t: crate::lower::model::TyDef, head: Text, gens: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ShowDef { cp, t, head, gens })
}

/// ```prism
/// ShowCase: fn TyDef, Nat -> Text
/// ```
pub fn show_case(t: &crate::lower::model::TyDef, i: &Nat) -> Text {
    let c = or(&index(&t.cases, i), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
    let head = Text::from(format!("{} (auto c = std::get_if<{}>(&cases()))", &(if i == &Nat::from(0u32) { Text::lit("if") } else { Text::lit("else if") }), &c.name));
    Text::from(format!("{} p.choice(\"{}\", {{{}}});", &head, &c.prism, &crate::syntax::lexer::join(&each(&crate::check::errors::range0(&len(&c.fields)), &(|k: &Nat| Text::from(format!("c->a{}", k)))), &Text::lit(", "))))
}

/// ```prism
/// FirstCase: fn TyDef -> Text
/// ```
pub fn first_case(t: &crate::lower::model::TyDef) -> Text {
    or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: t.prism.clone(), fields: Array::new() }).prism.clone()
}

/// ```prism
/// FirstArity: fn TyDef -> Nat
/// ```
pub fn first_arity(t: &crate::lower::model::TyDef) -> Nat {
    len(&or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() }).fields)
}

/// ```prism
/// FieldTypes: fn [((Text, OutTy))] -> [OutTy]
/// ```
pub fn field_types(fs: &Array<(Text, crate::lower::model::OutTy)>) -> Array<crate::lower::model::OutTy> {
    each(fs, &(|(_, t): &(Text, crate::lower::model::OutTy)| t.clone()))
}

/// ```prism
/// PositionalFields: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub fn positional_fields(cp: &Cp, fs: &Array<(Text, crate::lower::model::OutTy)>) -> Text {
    let tys = field_types(fs);
    crate::syntax::lexer::join(&run_to_end(each_job(crate::check::errors::range0(&len(&tys)), {
        let cp = cp.clone();
        let tys = tys.clone();
        Rc::new(move |p0: Nat| {
            let cp = cp.clone();
            let tys = tys.clone();
            entered(once_job(move || {
                let i = p0;
                call_then(start_cpp_type(cp.clone(), or(&index(&tys, &i), &crate::lower::model::OutTy::OutUnit)), move |cpp_type_66087: Text| prism_rtl::Turn::Finished(Text::from(format!("{} a{};", &cpp_type_66087, &i))))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"))
}

/// The step machine of `PositionalFields`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PositionalFields: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub struct PositionalFields {
    pub cp: Cp,
    pub fs: Array<(Text, crate::lower::model::OutTy)>,
}

impl prism_rtl::Job<Text> for PositionalFields {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let fs = &self.fs;
        let tys = field_types(fs);
        let cp = cp.clone();
        call_value(each_job(crate::check::errors::range0(&len(&tys)), {
            let cp = cp.clone();
            let tys = tys.clone();
            Rc::new(move |p0: Nat| {
                let cp = cp.clone();
                let tys = tys.clone();
                entered(once_job(move || {
                    let i = p0;
                    call_then(start_cpp_type(cp.clone(), or(&index(&tys, &i), &crate::lower::model::OutTy::OutUnit)), move |cpp_type_66087: Text| prism_rtl::Turn::Finished(Text::from(format!("{} a{};", &cpp_type_66087, &i))))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_66055: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::join(&each_66055, &Text::lit("\n"))))
    }
}

/// `Start PositionalFields, x`: what the function value is when passed to `@Run`.
pub fn start_positional_fields(cp: Cp, fs: Array<(Text, crate::lower::model::OutTy)>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(PositionalFields { cp, fs })
}

/// ```prism
/// ToPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub fn to_pod_def(cp: &Cp, t: &crate::lower::model::TyDef, head: &Text, gens: &Text) -> Text {
    let structure = match &t.shape {
        crate::lower::model::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            Text::from(format!("Pod::record(\"{}\", {{{}}})", &t.prism, &crate::syntax::lexer::join(&each(&c.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", prism_rtl::to_pod({})}}", &prism_field(f), &field_id(f))))), &Text::lit(", "))))
        },
        crate::lower::model::TyShape::ShapeChoice => choice_pod(t),
        crate::lower::model::TyShape::ShapeNewtype => Text::from(format!("Pod::choice(\"{}\", {{{}}})", &first_case(t), &crate::syntax::lexer::join(&each(&crate::check::errors::range0(&first_arity(t)), &(|k: &Nat| Text::from(format!("prism_rtl::to_pod(a{})", k)))), &Text::lit(", ")))),
        crate::lower::model::TyShape::ShapeUnit => Text::from(format!("Pod::choice(\"{}\", {{}})", &first_case(t))),
    };
    let body = if &t.show == &crate::lower::model::Shown::ShownOwn {
        Text::from(format!("Pod structure = {};\nreturn Pod::shown(prism_rtl::show(*this), structure);", &structure))
    } else {
        Text::from(format!("return {};", &structure))
    };
    crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("{}Pod {}::to_pod() const", gens, head)), &body)
}

/// The step machine of `ToPodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ToPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub struct ToPodDef {
    pub cp: Cp,
    pub t: crate::lower::model::TyDef,
    pub head: Text,
    pub gens: Text,
}

impl prism_rtl::Job<Text> for ToPodDef {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let t = &self.t;
        let head = &self.head;
        let gens = &self.gens;
        let structure = match &t.shape {
            crate::lower::model::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                Text::from(format!("Pod::record(\"{}\", {{{}}})", &t.prism, &crate::syntax::lexer::join(&each(&c.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", prism_rtl::to_pod({})}}", &prism_field(f), &field_id(f))))), &Text::lit(", "))))
            },
            crate::lower::model::TyShape::ShapeChoice => choice_pod(t),
            crate::lower::model::TyShape::ShapeNewtype => Text::from(format!("Pod::choice(\"{}\", {{{}}})", &first_case(t), &crate::syntax::lexer::join(&each(&crate::check::errors::range0(&first_arity(t)), &(|k: &Nat| Text::from(format!("prism_rtl::to_pod(a{})", k)))), &Text::lit(", ")))),
            crate::lower::model::TyShape::ShapeUnit => Text::from(format!("Pod::choice(\"{}\", {{}})", &first_case(t))),
        };
        let body = if &t.show == &crate::lower::model::Shown::ShownOwn {
            Text::from(format!("Pod structure = {};\nreturn Pod::shown(prism_rtl::show(*this), structure);", &structure))
        } else {
            Text::from(format!("return {};", &structure))
        };
        prism_rtl::Turn::Finished(crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("{}Pod {}::to_pod() const", gens, head)), &body))
    }
}

/// `Start ToPodDef, x`: what the function value is when passed to `@Run`.
pub fn start_to_pod_def(cp: Cp, t: crate::lower::model::TyDef, head: Text, gens: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ToPodDef { cp, t, head, gens })
}

/// ```prism
/// ChoicePod: fn TyDef -> Text
/// ```
pub fn choice_pod(t: &crate::lower::model::TyDef) -> Text {
    let arms = each(&crate::check::errors::range0(&len(&t.cases)), &(|i: &Nat| {
        let c = or(&index(&t.cases, i), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
        Text::from(format!("std::holds_alternative<{}>(cases()) ? Pod::choice(\"{}\", {{{}}})", &c.name, &c.prism, &crate::syntax::lexer::join(&each(&crate::check::errors::range0(&len(&c.fields)), &(|k: &Nat| Text::from(format!("prism_rtl::to_pod(std::get<{}>(cases()).a{})", &c.name, k)))), &Text::lit(", "))))
    }));
    Text::from(format!("{}\n    : Pod()", &crate::syntax::lexer::join(&arms, &Text::lit("\n    : "))))
}

/// ```prism
/// FromPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub fn from_pod_def(cp: &Cp, t: &crate::lower::model::TyDef, head: &Text, gens: &Text) -> Text {
    let body = match &t.shape {
        crate::lower::model::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            let reads = crate::syntax::lexer::join(&run_to_end(each_job(c.fields.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let (f, ft) = p0;
                        call_then(start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_67659: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = TRY(prism_rtl::from_pod<{}>(TRY(crate::prelude::field(whole, \"{}\"))))", &field_id(&f), &cpp_type_67659, &prism_field(&f)))))
                    }))
                }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
            })), &Text::lit(", "));
            Text::from(format!("return {}{{{}}};", head, &reads))
        },
        _ => {
            let arms = run_to_end(each_job(t.cases.clone(), {
                let cp = cp.clone();
                let t = t.clone();
                let head = head.clone();
                Rc::new(move |p0: crate::lower::model::CaseDef| {
                    let cp = cp.clone();
                    let t = t.clone();
                    let head = head.clone();
                    entered(once_job(move || {
                        let c = p0;
                        {
                            let n = len(&c.fields);
                            let tys = field_types(&c.fields);
                            call_value(each_job(crate::check::errors::range0(&n), {
                                let cp = cp.clone();
                                let tys = tys.clone();
                                Rc::new(move |p0: Nat| {
                                    let cp = cp.clone();
                                    let tys = tys.clone();
                                    entered(once_job(move || {
                                        let i = p0;
                                        call_then(start_cpp_type(cp.clone(), or(&index(&tys, &i), &crate::lower::model::OutTy::OutUnit)), move |cpp_type_68005: Text| prism_rtl::Turn::Finished(Text::from(format!("TRY(prism_rtl::from_pod<{}>(c->args[{}]))", &cpp_type_68005, &i))))
                                    }))
                                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
                            }), move |each_67957: Array<Text>| {
                                let args = crate::syntax::lexer::join(&each_67957, &Text::lit(", "));
                                let made = match &t.shape {
                                    crate::lower::model::TyShape::ShapeChoice => Text::from(format!("{}({}{{{}}})", &head, &c.name, &args)),
                                    _ => Text::from(format!("{}{{{}}}", &head, &args)),
                                };
                                prism_rtl::Turn::Finished(Text::from(format!("if (c->ctor == \"{}\" && c->args.size() == {}) return {};", &c.prism, &n, &made)))
                            })
                        }
                    }))
                }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            Text::from(format!("const Pod& p = whole.structure();\nif (auto c = p.if_choice()) {{\n{}\n}}\nreturn mismatch<{}>(\"a {}\", p);", &indent_cpp(&crate::syntax::lexer::join(&arms, &Text::lit("\n"))), head, &t.prism))
        },
    };
    crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("{}Result<{}> {}::from_pod(const Pod& whole)", gens, head, head)), &body)
}

/// The step machine of `FromPodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FromPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub struct FromPodDef {
    pub cp: Cp,
    pub t: crate::lower::model::TyDef,
    pub head: Text,
    pub gens: Text,
}

impl prism_rtl::Job<Text> for FromPodDef {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let t = &self.t;
        let head = &self.head;
        let gens = &self.gens;
        let body = match &t.shape {
            crate::lower::model::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                let reads = crate::syntax::lexer::join(&run_to_end(each_job(c.fields.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let (f, ft) = p0;
                            call_then(start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_67659: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = TRY(prism_rtl::from_pod<{}>(TRY(crate::prelude::field(whole, \"{}\"))))", &field_id(&f), &cpp_type_67659, &prism_field(&f)))))
                        }))
                    }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
                })), &Text::lit(", "));
                Text::from(format!("return {}{{{}}};", head, &reads))
            },
            _ => {
                let arms = run_to_end(each_job(t.cases.clone(), {
                    let cp = cp.clone();
                    let t = t.clone();
                    let head = head.clone();
                    Rc::new(move |p0: crate::lower::model::CaseDef| {
                        let cp = cp.clone();
                        let t = t.clone();
                        let head = head.clone();
                        entered(once_job(move || {
                            let c = p0;
                            {
                                let n = len(&c.fields);
                                let tys = field_types(&c.fields);
                                call_value(each_job(crate::check::errors::range0(&n), {
                                    let cp = cp.clone();
                                    let tys = tys.clone();
                                    Rc::new(move |p0: Nat| {
                                        let cp = cp.clone();
                                        let tys = tys.clone();
                                        entered(once_job(move || {
                                            let i = p0;
                                            call_then(start_cpp_type(cp.clone(), or(&index(&tys, &i), &crate::lower::model::OutTy::OutUnit)), move |cpp_type_68005: Text| prism_rtl::Turn::Finished(Text::from(format!("TRY(prism_rtl::from_pod<{}>(c->args[{}]))", &cpp_type_68005, &i))))
                                        }))
                                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
                                }), move |each_67957: Array<Text>| {
                                    let args = crate::syntax::lexer::join(&each_67957, &Text::lit(", "));
                                    let made = match &t.shape {
                                        crate::lower::model::TyShape::ShapeChoice => Text::from(format!("{}({}{{{}}})", &head, &c.name, &args)),
                                        _ => Text::from(format!("{}{{{}}}", &head, &args)),
                                    };
                                    prism_rtl::Turn::Finished(Text::from(format!("if (c->ctor == \"{}\" && c->args.size() == {}) return {};", &c.prism, &n, &made)))
                                })
                            }
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
                }));
                Text::from(format!("const Pod& p = whole.structure();\nif (auto c = p.if_choice()) {{\n{}\n}}\nreturn mismatch<{}>(\"a {}\", p);", &indent_cpp(&crate::syntax::lexer::join(&arms, &Text::lit("\n"))), head, &t.prism))
            },
        };
        prism_rtl::Turn::Finished(crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("{}Result<{}> {}::from_pod(const Pod& whole)", gens, head, head)), &body))
    }
}

/// `Start FromPodDef, x`: what the function value is when passed to `@Run`.
pub fn start_from_pod_def(cp: Cp, t: crate::lower::model::TyDef, head: Text, gens: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FromPodDef { cp, t, head, gens })
}

/// ```prism
/// PrismField: fn Text -> Text
/// ```
pub fn prism_field(f: &Text) -> Text {
    if &crate::syntax::lexer::last_char(f) == &Text::lit("_") {
        crate::syntax::lexer::before_last(f)
    } else {
        f.clone()
    }
}

/// ```prism
/// IndentCpp: fn Text -> Text
/// ```
pub fn indent_cpp(t: &Text) -> Text {
    crate::syntax::lexer::join(&each(&split(t, &Text::lit("\n")), &(|l: &Text| if l == &Text::lit("") { Text::lit("") } else { Text::from(format!("    {}", l)) })), &Text::lit("\n"))
}

/// ```prism
/// TagParts: unbounded fn Cp, TagDef -> Parts
/// ```
pub fn tag_parts(cp: &Cp, t: &crate::lower::model::TagDef) -> Parts {
    let fields = crate::syntax::lexer::join(&run_to_end(each_job(t.fields.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (_, f, ft) = p0;
                call_then(start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_69031: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_69031, &field_id(&f)))))
            }))
        }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let pods = crate::syntax::lexer::join(&each(&t.fields, &(|(p_, f, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", prism_rtl::to_pod({})}}", p_, &field_id(f))))), &Text::lit(", "));
    let reads = crate::syntax::lexer::join(&run_to_end(each_job(t.fields.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (p_, f, ft) = p0;
                call_then(start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_69271: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = TRY(prism_rtl::from_pod<{}>(TRY(crate::prelude::field(p, \"{}\"))))", &field_id(&f), &cpp_type_69271, &p_))))
            }))
        }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "));
    let eq = if t.pod {
        Text::from(format!("bool operator==(const {}&) const = default;", &t.name))
    } else {
        Text::lit("")
    };
    let back_ = if t.pod {
        Text::from(format!("static Result<{}> from_pod(const Pod& p);", &t.name))
    } else {
        Text::lit("")
    };
    let decl = crate::emit::cpp::templates::cpp_tag_struct(&cpp_source_doc(&Text::from(format!("The `Level` of `{}`:", &t.tag_name)), &t.doc), &t.name, &fields, &t.tag_name, &crate::syntax::lexer::join(&filter(&Array::from(vec![eq.clone(), back_.clone()]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n")));
    let to_pod = crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("Pod {}::to_pod() const", &t.name)), &Text::from(format!("return Pod::element(TAG, {{{}}});", &pods)));
    let show_ = crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("void {}::show(Printer& p) const", &t.name)), &Text::lit("prism_rtl::to_pod(*this).structure();\nShow<Pod>::show(prism_rtl::to_pod(*this), p);"));
    let from_pod = if t.pod {
        Array::from(vec![crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("Result<{}> {}::from_pod(const Pod& p)", &t.name, &t.name)), &Text::from(format!("if (auto t = p.tag(); t && *t == TAG) return {}{{{}}};\nreturn mismatch<{}>(\"a {}\", p);", &t.name, &reads, &t.name, &t.tag_name)))])
    } else {
        Array::new()
    };
    let deps = concat2(&run_to_end(each_job(t.fields.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (_, _, ft) = p0;
                prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: ft.clone() }))
            }))
        }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    })));
    Parts { forward: Array::from(vec![Text::from(format!("struct {};", &t.name))]), handles: Array::new(), values: Array::from(vec![ValueDecl { path_: Text::from(format!("{}::{}", &cp.home, &t.name)), deps: deps.clone(), text: decl.clone() }]), cases: Array::new(), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: append(&Array::from(vec![to_pod.clone(), show_.clone()]), &from_pod) }
}

/// The step machine of `TagParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagParts: unbounded fn Cp, TagDef -> Parts
/// ```
pub struct TagParts {
    pub cp: Cp,
    pub t: crate::lower::model::TagDef,
}

impl prism_rtl::Job<Parts> for TagParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let t = &self.t;
        let cp = cp.clone();
        let t = t.clone();
        call_value(each_job(t.fields.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let (_, f, ft) = p0;
                    call_then(start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_69031: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_69031, &field_id(&f)))))
                }))
            }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_68993: Array<Text>| {
            let fields = crate::syntax::lexer::join(&each_68993, &Text::lit("\n"));
            let pods = crate::syntax::lexer::join(&each(&t.fields, &(|(p_, f, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", prism_rtl::to_pod({})}}", p_, &field_id(f))))), &Text::lit(", "));
            call_value(each_job(t.fields.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let (p_, f, ft) = p0;
                        call_then(start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_69271: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = TRY(prism_rtl::from_pod<{}>(TRY(crate::prelude::field(p, \"{}\"))))", &field_id(&f), &cpp_type_69271, &p_))))
                    }))
                }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_69199: Array<Text>| {
                let reads = crate::syntax::lexer::join(&each_69199, &Text::lit(", "));
                let eq = if t.pod {
                    Text::from(format!("bool operator==(const {}&) const = default;", &t.name))
                } else {
                    Text::lit("")
                };
                let back_ = if t.pod {
                    Text::from(format!("static Result<{}> from_pod(const Pod& p);", &t.name))
                } else {
                    Text::lit("")
                };
                let decl = crate::emit::cpp::templates::cpp_tag_struct(&cpp_source_doc(&Text::from(format!("The `Level` of `{}`:", &t.tag_name)), &t.doc), &t.name, &fields, &t.tag_name, &crate::syntax::lexer::join(&filter(&Array::from(vec![eq.clone(), back_.clone()]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n")));
                let to_pod = crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("Pod {}::to_pod() const", &t.name)), &Text::from(format!("return Pod::element(TAG, {{{}}});", &pods)));
                let show_ = crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("void {}::show(Printer& p) const", &t.name)), &Text::lit("prism_rtl::to_pod(*this).structure();\nShow<Pod>::show(prism_rtl::to_pod(*this), p);"));
                let from_pod = if t.pod {
                    Array::from(vec![crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("Result<{}> {}::from_pod(const Pod& p)", &t.name, &t.name)), &Text::from(format!("if (auto t = p.tag(); t && *t == TAG) return {}{{{}}};\nreturn mismatch<{}>(\"a {}\", p);", &t.name, &reads, &t.name, &t.tag_name)))])
                } else {
                    Array::new()
                };
                call_value(each_job(t.fields.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let (_, _, ft) = p0;
                            prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: ft.clone() }))
                        }))
                    }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_70183: Array<Array<Text>>| {
                    let deps = concat2(&each_70183);
                    prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![Text::from(format!("struct {};", &t.name))]), handles: Array::new(), values: Array::from(vec![ValueDecl { path_: Text::from(format!("{}::{}", &cp.home, &t.name)), deps: deps.clone(), text: decl.clone() }]), cases: Array::new(), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: append(&Array::from(vec![to_pod.clone(), show_.clone()]), &from_pod) })
                })
            })
        })
    }
}

/// `Start TagParts, x`: what the function value is when passed to `@Run`.
pub fn start_tag_parts(cp: Cp, t: crate::lower::model::TagDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(TagParts { cp, t })
}

/// ```prism
/// RowParts: unbounded fn Cp, Text, RowDef -> Parts
/// ```
pub fn row_parts(cp: &Cp, m: &Text, r: &crate::lower::model::RowDef) -> Parts {
    let names = each(&r.cases, &(|(v_, _): &(Text, Text)| v_.clone()));
    let pod = Text::from(format!("Pod to_pod() const;\nvoid show(Printer& p) const;{}", &(if r.pod {
        Text::from(format!("\nstatic Result<{}> from_pod(const Pod& p);", &r.name))
    } else {
        Text::lit("")
    })));
    let handle = crate::emit::cpp::templates::choice_handle(&cpp_source_doc(&Text::from(format!("`{}`, a row kind's values:", &r.prism)), &r.doc), &Text::lit(""), &r.name, &crate::syntax::lexer::join(&each(&names, &(|n: &Text| Text::from(format!("struct {};", n)))), &Text::lit("\n")), &crate::syntax::lexer::join(&names, &Text::lit(", ")), &pod);
    let cases = each(&r.cases, &(|(v_, st): &(Text, Text)| crate::emit::cpp::templates::case_decl(&Text::lit(""), &Text::from(format!("{}::{}", &r.name, v_)), &Text::from(format!("{} a0;{}", &row_struct(m, st), &(if r.pod {
        Text::from(format!("\nbool operator==(const {}&) const = default;", v_))
    } else {
        Text::lit("")
    }))))));
    let eq = if r.pod {
        Array::from(vec![Text::from(format!("inline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &r.name, &r.name))])
    } else {
        Array::new()
    };
    let to_pod = crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("Pod {}::to_pod() const", &r.name)), &Text::lit("return std::visit([](const auto& c) { return prism_rtl::to_pod(c.a0); }, cases());"));
    let show_ = crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("void {}::show(Printer& p) const", &r.name)), &Text::lit("Show<Pod>::show(to_pod(), p);"));
    let reads = crate::syntax::lexer::join(&each(&r.cases, &(|(v_, st): &(Text, Text)| Text::from(format!("if (*t == {}::TAG) return {}({}{{TRY(prism_rtl::from_pod<{}>(p))}});", &row_struct(m, st), &r.name, v_, &row_struct(m, st))))), &Text::lit("\n"));
    let from_pod = if r.pod {
        Array::from(vec![crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("Result<{}> {}::from_pod(const Pod& p)", &r.name, &r.name)), &Text::from(format!("if (auto t = p.tag()) {{\n{}\n}}\nreturn mismatch<{}>(\"a {}\", p);", &indent_cpp(&reads), &r.name, &r.name)))])
    } else {
        Array::new()
    };
    Parts { forward: Array::from(vec![Text::from(format!("class {};", &r.name))]), handles: Array::from(vec![handle.clone()]), values: Array::new(), cases: append(&push(&cases, &cases_accessor(&Text::lit(""), &r.name)), &eq), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: append(&Array::from(vec![to_pod.clone(), show_.clone()]), &from_pod) }
}

/// The step machine of `RowParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowParts: unbounded fn Cp, Text, RowDef -> Parts
/// ```
pub struct RowParts {
    pub cp: Cp,
    pub m: Text,
    pub r: crate::lower::model::RowDef,
}

impl prism_rtl::Job<Parts> for RowParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let m = &self.m;
        let r = &self.r;
        let names = each(&r.cases, &(|(v_, _): &(Text, Text)| v_.clone()));
        let pod = Text::from(format!("Pod to_pod() const;\nvoid show(Printer& p) const;{}", &(if r.pod {
            Text::from(format!("\nstatic Result<{}> from_pod(const Pod& p);", &r.name))
        } else {
            Text::lit("")
        })));
        let handle = crate::emit::cpp::templates::choice_handle(&cpp_source_doc(&Text::from(format!("`{}`, a row kind's values:", &r.prism)), &r.doc), &Text::lit(""), &r.name, &crate::syntax::lexer::join(&each(&names, &(|n: &Text| Text::from(format!("struct {};", n)))), &Text::lit("\n")), &crate::syntax::lexer::join(&names, &Text::lit(", ")), &pod);
        let cases = each(&r.cases, &(|(v_, st): &(Text, Text)| crate::emit::cpp::templates::case_decl(&Text::lit(""), &Text::from(format!("{}::{}", &r.name, v_)), &Text::from(format!("{} a0;{}", &row_struct(m, st), &(if r.pod {
            Text::from(format!("\nbool operator==(const {}&) const = default;", v_))
        } else {
            Text::lit("")
        }))))));
        let eq = if r.pod {
            Array::from(vec![Text::from(format!("inline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &r.name, &r.name))])
        } else {
            Array::new()
        };
        let to_pod = crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("Pod {}::to_pod() const", &r.name)), &Text::lit("return std::visit([](const auto& c) { return prism_rtl::to_pod(c.a0); }, cases());"));
        let show_ = crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("void {}::show(Printer& p) const", &r.name)), &Text::lit("Show<Pod>::show(to_pod(), p);"));
        let reads = crate::syntax::lexer::join(&each(&r.cases, &(|(v_, st): &(Text, Text)| Text::from(format!("if (*t == {}::TAG) return {}({}{{TRY(prism_rtl::from_pod<{}>(p))}});", &row_struct(m, st), &r.name, v_, &row_struct(m, st))))), &Text::lit("\n"));
        let from_pod = if r.pod {
            Array::from(vec![crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("Result<{}> {}::from_pod(const Pod& p)", &r.name, &r.name)), &Text::from(format!("if (auto t = p.tag()) {{\n{}\n}}\nreturn mismatch<{}>(\"a {}\", p);", &indent_cpp(&reads), &r.name, &r.name)))])
        } else {
            Array::new()
        };
        prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![Text::from(format!("class {};", &r.name))]), handles: Array::from(vec![handle.clone()]), values: Array::new(), cases: append(&push(&cases, &cases_accessor(&Text::lit(""), &r.name)), &eq), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: append(&Array::from(vec![to_pod.clone(), show_.clone()]), &from_pod) })
    }
}

/// `Start RowParts, x`: what the function value is when passed to `@Run`.
pub fn start_row_parts(cp: Cp, m: Text, r: crate::lower::model::RowDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(RowParts { cp, m, r })
}

/// ```prism
/// RowStruct: fn Text, Text -> Text
/// ```
pub fn row_struct(m: &Text, st: &Text) -> Text {
    if crate::syntax::lexer::contains(st, &Text::lit(":")) || (m == &Text::lit("")) {
        type_path(st)
    } else {
        Text::from(format!("crate::{}::{}", m, st))
    }
}

/// ```prism
/// AnswerParts: unbounded fn Cp, AnswerDef -> Parts
/// ```
pub fn answer_parts(cp: &Cp, a: &crate::lower::model::AnswerDef) -> Parts {
    let names = each(&a.cases, &(|c: &crate::lower::model::AnswerCase| c.variant.clone()));
    let accessors = crate::syntax::lexer::join(&run_to_end(each_job(a.cases.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::AnswerCase| {
            let cp = cp.clone();
            entered(once_job(move || {
                let c = p0;
                call_then(start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_72720: Text| prism_rtl::Turn::Finished(Text::from(format!("Result<{}> {}() const;", &cpp_type_72720, &c.accessor))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let members_ = Text::from(format!("const char* tag() const;\n{}\nstatic Result<Answer> decode(const Elem& e, const Pod& v);", &accessors));
    let handle = crate::emit::cpp::templates::choice_handle(&cpp_doc(&Text::lit("`Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host's\nsupplier answers a child place with, and what a World's answer to a forwarded element\ndecodes to, carrying the tag's output.")), &Text::lit(""), &Text::lit("Answer"), &crate::syntax::lexer::join(&each(&names, &(|n: &Text| Text::from(format!("struct {};", n)))), &Text::lit("\n")), &crate::syntax::lexer::join(&names, &Text::lit(", ")), &members_);
    let cases = run_to_end(each_job(a.cases.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::AnswerCase| {
            let cp = cp.clone();
            entered(once_job(move || {
                let c = p0;
                call_then(start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_73305: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::case_decl(&Text::lit(""), &Text::from(format!("Answer::{}", &c.variant)), &Text::from(format!("{} a0;", &cpp_type_73305)))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let tags = crate::syntax::lexer::join(&each(&a.cases, &(|c: &crate::lower::model::AnswerCase| Text::from(format!("if (std::holds_alternative<{}>(cases())) return {}::TAG;", &c.variant, &type_path(&c.struct_path))))), &Text::lit("\n"));
    let tag_fn = crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::lit("const char* Answer::tag() const"), &Text::from(format!("{}\nprism_rtl::unreachable();", &tags)));
    let getters = run_to_end(each_job(a.cases.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::AnswerCase| {
            let cp = cp.clone();
            entered(once_job(move || {
                let c = p0;
                call_then(start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_73663: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::cpp_function(&cpp_doc(&Text::from(format!("A `{}`'s answer.", &c.tag_name))), &Text::from(format!("Result<{}> Answer::{}() const", &cpp_type_73663, &c.accessor)), &Text::from(format!("if (auto c = std::get_if<{}>(&cases())) return c->a0;\nreturn unexpected(Fault::answer(str(\"an answer for \", tag(), \", where {}'s was expected\")));", &c.variant, &c.tag_name)))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let decodes = crate::syntax::lexer::join(&run_to_end(each_job(a.cases.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::AnswerCase| {
            let cp = cp.clone();
            entered(once_job(move || {
                let c = p0;
                call_then(start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_74011: Text| prism_rtl::Turn::Finished(Text::from(format!("if (is<Elem::{}>(e)) return Answer({}{{TRY(prism_rtl::from_pod<{}>(v))}});", &c.variant, &c.variant, &cpp_type_74011))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let decode = crate::emit::cpp::templates::cpp_function(&cpp_doc(&Text::lit("A World's answer to the element `e`, decoded by its tag.")), &Text::lit("Result<Answer> Answer::decode(const Elem& e, const Pod& v)"), &Text::from(format!("{}\nprism_rtl::unreachable();", &decodes)));
    Parts { forward: Array::from(vec![Text::lit("class Answer;")]), handles: Array::from(vec![handle.clone()]), values: Array::new(), cases: push(&cases, &cases_accessor(&Text::lit(""), &Text::lit("Answer"))), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: append(&Array::from(vec![tag_fn.clone()]), &push(&getters, &decode)) }
}

/// The step machine of `AnswerParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnswerParts: unbounded fn Cp, AnswerDef -> Parts
/// ```
pub struct AnswerParts {
    pub cp: Cp,
    pub a: crate::lower::model::AnswerDef,
}

impl prism_rtl::Job<Parts> for AnswerParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let a = &self.a;
        let names = each(&a.cases, &(|c: &crate::lower::model::AnswerCase| c.variant.clone()));
        let a = a.clone();
        let cp = cp.clone();
        call_value(each_job(a.cases.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: crate::lower::model::AnswerCase| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let c = p0;
                    call_then(start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_72720: Text| prism_rtl::Turn::Finished(Text::from(format!("Result<{}> {}() const;", &cpp_type_72720, &c.accessor))))
                }))
            }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_72692: Array<Text>| {
            let accessors = crate::syntax::lexer::join(&each_72692, &Text::lit("\n"));
            let members_ = Text::from(format!("const char* tag() const;\n{}\nstatic Result<Answer> decode(const Elem& e, const Pod& v);", &accessors));
            let handle = crate::emit::cpp::templates::choice_handle(&cpp_doc(&Text::lit("`Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host's\nsupplier answers a child place with, and what a World's answer to a forwarded element\ndecodes to, carrying the tag's output.")), &Text::lit(""), &Text::lit("Answer"), &crate::syntax::lexer::join(&each(&names, &(|n: &Text| Text::from(format!("struct {};", n)))), &Text::lit("\n")), &crate::syntax::lexer::join(&names, &Text::lit(", ")), &members_);
            call_value(each_job(a.cases.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: crate::lower::model::AnswerCase| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let c = p0;
                        call_then(start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_73305: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::case_decl(&Text::lit(""), &Text::from(format!("Answer::{}", &c.variant)), &Text::from(format!("{} a0;", &cpp_type_73305)))))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_73248: Array<Text>| {
                let cases = each_73248;
                let tags = crate::syntax::lexer::join(&each(&a.cases, &(|c: &crate::lower::model::AnswerCase| Text::from(format!("if (std::holds_alternative<{}>(cases())) return {}::TAG;", &c.variant, &type_path(&c.struct_path))))), &Text::lit("\n"));
                let tag_fn = crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::lit("const char* Answer::tag() const"), &Text::from(format!("{}\nprism_rtl::unreachable();", &tags)));
                call_value(each_job(a.cases.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: crate::lower::model::AnswerCase| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let c = p0;
                            call_then(start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_73663: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::cpp_function(&cpp_doc(&Text::from(format!("A `{}`'s answer.", &c.tag_name))), &Text::from(format!("Result<{}> Answer::{}() const", &cpp_type_73663, &c.accessor)), &Text::from(format!("if (auto c = std::get_if<{}>(&cases())) return c->a0;\nreturn unexpected(Fault::answer(str(\"an answer for \", tag(), \", where {}'s was expected\")));", &c.variant, &c.tag_name)))))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_73585: Array<Text>| {
                    let getters = each_73585;
                    call_value(each_job(a.cases.clone(), {
                        let cp = cp.clone();
                        Rc::new(move |p0: crate::lower::model::AnswerCase| {
                            let cp = cp.clone();
                            entered(once_job(move || {
                                let c = p0;
                                call_then(start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_74011: Text| prism_rtl::Turn::Finished(Text::from(format!("if (is<Elem::{}>(e)) return Answer({}{{TRY(prism_rtl::from_pod<{}>(v))}});", &c.variant, &c.variant, &cpp_type_74011))))
                            }))
                        }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
                    }), move |each_73909: Array<Text>| {
                        let decodes = crate::syntax::lexer::join(&each_73909, &Text::lit("\n"));
                        let decode = crate::emit::cpp::templates::cpp_function(&cpp_doc(&Text::lit("A World's answer to the element `e`, decoded by its tag.")), &Text::lit("Result<Answer> Answer::decode(const Elem& e, const Pod& v)"), &Text::from(format!("{}\nprism_rtl::unreachable();", &decodes)));
                        prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![Text::lit("class Answer;")]), handles: Array::from(vec![handle.clone()]), values: Array::new(), cases: push(&cases, &cases_accessor(&Text::lit(""), &Text::lit("Answer"))), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: append(&Array::from(vec![tag_fn.clone()]), &push(&getters, &decode)) })
                    })
                })
            })
        })
    }
}

/// `Start AnswerParts, x`: what the function value is when passed to `@Run`.
pub fn start_answer_parts(cp: Cp, a: crate::lower::model::AnswerDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(AnswerParts { cp, a })
}

/// ```prism
/// JobParts: unbounded fn Cp, JobDef -> Parts
/// ```
pub fn job_parts(cp: &Cp, j: &crate::lower::model::JobDef) -> Parts {
    let gens = cpp_template_head(&generic_names_of(&j.generics));
    let head = head_of(&j.name, &generic_names_of(&j.generics));
    let jcp = with_fields(cp, &j.fields);
    let fields = crate::syntax::lexer::join(&run_to_end(each_job(j.fields.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (n, t) = p0;
                call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_74802: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_74802, &field_id(&n)))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let params = crate::syntax::lexer::join(&run_to_end(each_job(j.fields.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (n, t) = p0;
                call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_74890: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_74890, &field_id(&n)))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "));
    let inits = crate::syntax::lexer::join(&each(&j.fields, &(|(n, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{}(std::move({}))", &field_id(n), &field_id(n))))), &Text::lit(", "));
    let ctor = if &len(&j.fields) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!("{}({}) : {} {{}}", &j.name, &params, &inits))
    };
    let ret = cpp_type(cp, &j.ret);
    let decl = crate::emit::cpp::templates::job_struct(&cpp_doc(&j.doc), &gens, &j.name, &ret, &fields, &ctor);
    let cycle = crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("{}prism_rtl::Turn<{}> {}::cycle() const", &gens, &ret, &head)), &cpp_body(&jcp, &j.body));
    let start = crate::emit::cpp::templates::cpp_function(&cpp_doc(&Text::from(format!("`Start {}, x`: what the function value is when passed to `@Run`.", &j.name))), &Text::from(format!("{}prism_rtl::JobRef<{}> {}({})", &gens, &ret, &j.start, &params)), &Text::from(format!("return prism_rtl::make_rc<{}>({});", &head, &crate::syntax::lexer::join(&each(&j.fields, &(|(n, _): &(Text, crate::lower::model::OutTy)| field_id(n))), &Text::lit(", ")))));
    let generic = &len(&j.generics) > &Nat::from(0u32);
    Parts { forward: Array::from(vec![Text::from(format!("{}struct {};", &gens, &j.name))]), handles: Array::new(), values: Array::new(), cases: Array::new(), protos: Array::from(vec![Text::from(format!("{}prism_rtl::JobRef<{}> {}({});", &gens, &ret, &j.start, &params))]), classes: Array::from(vec![decl.clone()]), outer: Array::new(), generic: if generic { Array::from(vec![cycle.clone(), start.clone()]) } else { Array::new() }, defs: if generic { Array::new() } else { Array::from(vec![cycle.clone(), start.clone()]) } }
}

/// The step machine of `JobParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobParts: unbounded fn Cp, JobDef -> Parts
/// ```
pub struct JobParts {
    pub cp: Cp,
    pub j: crate::lower::model::JobDef,
}

impl prism_rtl::Job<Parts> for JobParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let j = &self.j;
        let gens = cpp_template_head(&generic_names_of(&j.generics));
        let head = head_of(&j.name, &generic_names_of(&j.generics));
        let jcp = with_fields(cp, &j.fields);
        let cp = cp.clone();
        let j = j.clone();
        call_value(each_job(j.fields.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let (n, t) = p0;
                    call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_74802: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_74802, &field_id(&n)))))
                }))
            }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_74773: Array<Text>| {
            let fields = crate::syntax::lexer::join(&each_74773, &Text::lit("\n"));
            call_value(each_job(j.fields.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let (n, t) = p0;
                        call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_74890: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_74890, &field_id(&n)))))
                    }))
                }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_74861: Array<Text>| {
                let params = crate::syntax::lexer::join(&each_74861, &Text::lit(", "));
                let inits = crate::syntax::lexer::join(&each(&j.fields, &(|(n, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{}(std::move({}))", &field_id(n), &field_id(n))))), &Text::lit(", "));
                let ctor = if &len(&j.fields) == &Nat::from(0u32) {
                    Text::lit("")
                } else {
                    Text::from(format!("{}({}) : {} {{}}", &j.name, &params, &inits))
                };
                call_then(start_cpp_type(cp.clone(), j.ret.clone()), move |cpp_type_75122: Text| {
                    let ret = cpp_type_75122;
                    let decl = crate::emit::cpp::templates::job_struct(&cpp_doc(&j.doc), &gens, &j.name, &ret, &fields, &ctor);
                    call_then(start_cpp_body(jcp.clone(), j.body.clone()), move |cpp_body_75300: Text| {
                        let cycle = crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("{}prism_rtl::Turn<{}> {}::cycle() const", &gens, &ret, &head)), &cpp_body_75300);
                        let start = crate::emit::cpp::templates::cpp_function(&cpp_doc(&Text::from(format!("`Start {}, x`: what the function value is when passed to `@Run`.", &j.name))), &Text::from(format!("{}prism_rtl::JobRef<{}> {}({})", &gens, &ret, &j.start, &params)), &Text::from(format!("return prism_rtl::make_rc<{}>({});", &head, &crate::syntax::lexer::join(&each(&j.fields, &(|(n, _): &(Text, crate::lower::model::OutTy)| field_id(n))), &Text::lit(", ")))));
                        let generic = &len(&j.generics) > &Nat::from(0u32);
                        prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![Text::from(format!("{}struct {};", &gens, &j.name))]), handles: Array::new(), values: Array::new(), cases: Array::new(), protos: Array::from(vec![Text::from(format!("{}prism_rtl::JobRef<{}> {}({});", &gens, &ret, &j.start, &params))]), classes: Array::from(vec![decl.clone()]), outer: Array::new(), generic: if generic { Array::from(vec![cycle.clone(), start.clone()]) } else { Array::new() }, defs: if generic { Array::new() } else { Array::from(vec![cycle.clone(), start.clone()]) } })
                    })
                })
            })
        })
    }
}

/// `Start JobParts, x`: what the function value is when passed to `@Run`.
pub fn start_job_parts(cp: Cp, j: crate::lower::model::JobDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(JobParts { cp, j })
}

/// ```prism
/// TraitParts: unbounded fn Cp, TraitDef -> Parts
/// ```
pub fn trait_parts(cp: &Cp, t: &crate::lower::model::TraitDef) -> Parts {
    let defaults = filter(&t.methods, &(|f: &crate::lower::model::FnDef| f.public));
    let defs = run_to_end(each_job(defaults.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::FnDef| {
            let cp = cp.clone();
            entered(once_job(move || {
                let f = p0;
                prism_rtl::Turn::More(Rc::new(FnDefinition { cp: cp.clone(), f: with_generics(&f, &Array::from(vec![(Text::lit("Self"), Array::new())])) }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let protos = run_to_end(each_job(t.methods.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::FnDef| {
            let cp = cp.clone();
            entered(once_job(move || {
                let f = p0;
                call_then(start_fn_signature(cp.clone(), with_generics(&f, &Array::from(vec![(Text::lit("Self"), Array::new())]))), move |fn_signature_76566: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{};", &fn_signature_76566, &(if f.public { Text::lit("") } else { Text::lit(" = delete") })))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let generic = if &len(&defaults) == &Nat::from(0u32) {
        Array::new()
    } else {
        Array::from(vec![crate::emit::cpp::templates::trait_namespace(&t.name, &crate::syntax::lexer::join(&defs, &Text::lit("\n")))])
    };
    let mut this: Parts = generic_only(&generic);
    this.protos = Array::from(vec![crate::emit::cpp::templates::trait_namespace(&t.name, &crate::syntax::lexer::join(&protos, &Text::lit("\n")))]);
    this
}

/// The step machine of `TraitParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TraitParts: unbounded fn Cp, TraitDef -> Parts
/// ```
pub struct TraitParts {
    pub cp: Cp,
    pub t: crate::lower::model::TraitDef,
}

impl prism_rtl::Job<Parts> for TraitParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let t = &self.t;
        let defaults = filter(&t.methods, &(|f: &crate::lower::model::FnDef| f.public));
        let cp = cp.clone();
        let t = t.clone();
        call_value(each_job(defaults.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: crate::lower::model::FnDef| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let f = p0;
                    prism_rtl::Turn::More(Rc::new(FnDefinition { cp: cp.clone(), f: with_generics(&f, &Array::from(vec![(Text::lit("Self"), Array::new())])) }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_76450: Array<Text>| {
            let defs = each_76450;
            call_value(each_job(t.methods.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: crate::lower::model::FnDef| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let f = p0;
                        call_then(start_fn_signature(cp.clone(), with_generics(&f, &Array::from(vec![(Text::lit("Self"), Array::new())]))), move |fn_signature_76566: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{};", &fn_signature_76566, &(if f.public { Text::lit("") } else { Text::lit(" = delete") })))))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_76543: Array<Text>| {
                let protos = each_76543;
                let generic = if &len(&defaults) == &Nat::from(0u32) {
                    Array::new()
                } else {
                    Array::from(vec![crate::emit::cpp::templates::trait_namespace(&t.name, &crate::syntax::lexer::join(&defs, &Text::lit("\n")))])
                };
                prism_rtl::Turn::Finished({
                    let mut this: Parts = generic_only(&generic);
                    this.protos = Array::from(vec![crate::emit::cpp::templates::trait_namespace(&t.name, &crate::syntax::lexer::join(&protos, &Text::lit("\n")))]);
                    this
                })
            })
        })
    }
}

/// `Start TraitParts, x`: what the function value is when passed to `@Run`.
pub fn start_trait_parts(cp: Cp, t: crate::lower::model::TraitDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(TraitParts { cp, t })
}

/// ```prism
/// ImplParts: unbounded fn Cp, ImplDef -> Parts
/// ```
pub fn impl_parts(cp: &Cp, i: &crate::lower::model::ImplDef) -> Parts {
    let head = cpp_type(cp, &i.head);
    let gens = cpp_template_head(&generic_names_of(&i.generics));
    let fns = run_to_end(each_job(i.methods.clone(), {
        let cp = cp.clone();
        let i = i.clone();
        Rc::new(move |p0: crate::lower::model::FnDef| {
            let cp = cp.clone();
            let i = i.clone();
            entered(once_job(move || {
                let f = p0;
                prism_rtl::Turn::More(Rc::new(FnParts { cp: cp.clone(), f: with_generics(&f, &i.generics) }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Parts>>>
    }));
    let own = fold(&fns, &no_parts(), &(|acc: &Parts, p_: &Parts| join_parts(acc, p_)));
    match &i.cls {
        m77553_0 if (m77553_0 == &Text::lit("Prelude.Show")) => {
            let shown = or(&index(&each(&i.methods, &(|f: &crate::lower::model::FnDef| f.name.clone())), &Nat::from(0u32)), &Text::lit("show"));
            join_parts(&own, &protos_defs(&Array::new(), &Array::from(vec![crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("{}void {}::show(Printer& p) const", &gens, &head)), &Text::from(format!("p.raw({}(*this).to_string());", &shown)))])))
        },
        m77553_1 if (m77553_1 == &Text::lit("Prelude.Eq")) => {
            let eq = fold(&i.methods, &Text::lit(""), &(|acc: &Text, f: &crate::lower::model::FnDef| if !crate::syntax::lexer::has_prefix(&f.name, &Text::lit("ne")) && (acc == &Text::lit("")) {
                f.name.clone()
            } else {
                acc.clone()
            }));
            join_parts(&own, &protos_defs(&Array::from(vec![Text::from(format!("{}bool operator==(const {}& a, const {}& b);", &gens, &head, &head))]), &Array::from(vec![crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("{}bool operator==(const {}& a, const {}& b)", &gens, &head, &head)), &Text::from(format!("return {}(a, b);", &eq)))])))
        },
        _ => {
            let tr = crate::syntax::lexer::drop_prefix(&type_path(&i.tr), &Text::lit("crate::"));
            let own = !crate::syntax::lexer::contains(&tr, &Text::lit("::"));
            let ns = if own {
                tr.clone()
            } else {
                Text::from(format!("impl_{}", &crate::syntax::lexer::join(&split(&tr, &Text::lit("::")), &Text::lit("_"))))
            };
            let in_trait = run_to_end(each_job(i.methods.clone(), {
                let ns = ns.clone();
                let cp = cp.clone();
                let i = i.clone();
                Rc::new(move |p0: crate::lower::model::FnDef| {
                    let ns = ns.clone();
                    let cp = cp.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let f = p0;
                        call_then(start_fn_definition(cp.clone(), with_generics(&f, &i.generics)), move |fn_definition_78418: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::trait_namespace(&ns, &fn_definition_78418)))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            let protos = run_to_end(each_job(i.methods.clone(), {
                let ns = ns.clone();
                let cp = cp.clone();
                let i = i.clone();
                Rc::new(move |p0: crate::lower::model::FnDef| {
                    let ns = ns.clone();
                    let cp = cp.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let f = p0;
                        call_then(start_fn_signature(cp.clone(), with_generics(&f, &i.generics)), move |fn_signature_78532: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::trait_namespace(&ns, &Text::from(format!("{};", &fn_signature_78532)))))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            let outer = if own {
                Array::new()
            } else {
                Array::from(vec![crate::emit::cpp::templates::trait_namespace(&tr, &crate::syntax::lexer::join(&each(&i.methods, &(|f: &crate::lower::model::FnDef| Text::from(format!("using ::crate::{}::{}::{};", &cp.home, &ns, &cpp_id(&f.name))))), &Text::lit("\n")))])
            };
            {
                let mut this: Parts = protos_defs(&protos, &in_trait);
                this.outer = outer.clone();
                this
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ImplParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ImplParts: unbounded fn Cp, ImplDef -> Parts
/// ```
pub struct ImplParts {
    pub cp: Cp,
    pub i: crate::lower::model::ImplDef,
}

impl prism_rtl::Job<Parts> for ImplParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let i = &self.i;
        let cp = cp.clone();
        let i = i.clone();
        call_then(start_cpp_type(cp.clone(), i.head.clone()), move |cpp_type_77335: Text| {
            let head = cpp_type_77335;
            let gens = cpp_template_head(&generic_names_of(&i.generics));
            call_value(each_job(i.methods.clone(), {
                let cp = cp.clone();
                let i = i.clone();
                Rc::new(move |p0: crate::lower::model::FnDef| {
                    let cp = cp.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let f = p0;
                        prism_rtl::Turn::More(Rc::new(FnParts { cp: cp.clone(), f: with_generics(&f, &i.generics) }))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Parts>>>
            }), move |each_77427: Array<Parts>| {
                let fns = each_77427;
                let own = fold(&fns, &no_parts(), &(|acc: &Parts, p_: &Parts| join_parts(acc, p_)));
                match &i.cls {
                    m77553_0 if (m77553_0 == &Text::lit("Prelude.Show")) => {
                        let shown = or(&index(&each(&i.methods, &(|f: &crate::lower::model::FnDef| f.name.clone())), &Nat::from(0u32)), &Text::lit("show"));
                        prism_rtl::Turn::Finished(join_parts(&own, &protos_defs(&Array::new(), &Array::from(vec![crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("{}void {}::show(Printer& p) const", &gens, &head)), &Text::from(format!("p.raw({}(*this).to_string());", &shown)))]))))
                    },
                    m77553_1 if (m77553_1 == &Text::lit("Prelude.Eq")) => {
                        let eq = fold(&i.methods, &Text::lit(""), &(|acc: &Text, f: &crate::lower::model::FnDef| if !crate::syntax::lexer::has_prefix(&f.name, &Text::lit("ne")) && (acc == &Text::lit("")) {
                            f.name.clone()
                        } else {
                            acc.clone()
                        }));
                        prism_rtl::Turn::Finished(join_parts(&own, &protos_defs(&Array::from(vec![Text::from(format!("{}bool operator==(const {}& a, const {}& b);", &gens, &head, &head))]), &Array::from(vec![crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("{}bool operator==(const {}& a, const {}& b)", &gens, &head, &head)), &Text::from(format!("return {}(a, b);", &eq)))]))))
                    },
                    _ => {
                        let tr = crate::syntax::lexer::drop_prefix(&type_path(&i.tr), &Text::lit("crate::"));
                        let own = !crate::syntax::lexer::contains(&tr, &Text::lit("::"));
                        let ns = if own {
                            tr.clone()
                        } else {
                            Text::from(format!("impl_{}", &crate::syntax::lexer::join(&split(&tr, &Text::lit("::")), &Text::lit("_"))))
                        };
                        call_value(each_job(i.methods.clone(), {
                            let ns = ns.clone();
                            let cp = cp.clone();
                            let i = i.clone();
                            Rc::new(move |p0: crate::lower::model::FnDef| {
                                let ns = ns.clone();
                                let cp = cp.clone();
                                let i = i.clone();
                                entered(once_job(move || {
                                    let f = p0;
                                    call_then(start_fn_definition(cp.clone(), with_generics(&f, &i.generics)), move |fn_definition_78418: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::trait_namespace(&ns, &fn_definition_78418)))
                                }))
                            }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
                        }), move |each_78377: Array<Text>| {
                            let in_trait = each_78377;
                            call_value(each_job(i.methods.clone(), {
                                let ns = ns.clone();
                                let cp = cp.clone();
                                let i = i.clone();
                                Rc::new(move |p0: crate::lower::model::FnDef| {
                                    let ns = ns.clone();
                                    let cp = cp.clone();
                                    let i = i.clone();
                                    entered(once_job(move || {
                                        let f = p0;
                                        call_then(start_fn_signature(cp.clone(), with_generics(&f, &i.generics)), move |fn_signature_78532: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::trait_namespace(&ns, &Text::from(format!("{};", &fn_signature_78532)))))
                                    }))
                                }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
                            }), move |each_78490: Array<Text>| {
                                let protos = each_78490;
                                let outer = if own {
                                    Array::new()
                                } else {
                                    Array::from(vec![crate::emit::cpp::templates::trait_namespace(&tr, &crate::syntax::lexer::join(&each(&i.methods, &(|f: &crate::lower::model::FnDef| Text::from(format!("using ::crate::{}::{}::{};", &cp.home, &ns, &cpp_id(&f.name))))), &Text::lit("\n")))])
                                };
                                prism_rtl::Turn::Finished({
                                    let mut this: Parts = protos_defs(&protos, &in_trait);
                                    this.outer = outer.clone();
                                    this
                                })
                            })
                        })
                    },
                    _ => unreachable!("no arm matched"),
                }
            })
        })
    }
}

/// `Start ImplParts, x`: what the function value is when passed to `@Run`.
pub fn start_impl_parts(cp: Cp, i: crate::lower::model::ImplDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(ImplParts { cp, i })
}

/// ```prism
/// WithGenerics: fn FnDef, [((Text, [Text]))] -> FnDef
/// ```
pub fn with_generics(f: &crate::lower::model::FnDef, gs: &Array<(Text, Array<Text>)>) -> crate::lower::model::FnDef {
    let mut this: crate::lower::model::FnDef = f.clone();
    this.generics = append(gs, &this.generics);
    this
}

/// ```prism
/// GenericOnly: fn [Text] -> Parts
/// ```
pub fn generic_only(xs: &Array<Text>) -> Parts {
    let mut this: Parts = no_parts();
    this.generic = xs.clone();
    this
}

/// ```prism
/// ProtosDefs: fn [Text], [Text] -> Parts
/// ```
pub fn protos_defs(ps: &Array<Text>, ds: &Array<Text>) -> Parts {
    let mut this: Parts = no_parts();
    this.protos = ps.clone();
    this.defs = ds.clone();
    this
}

/// ```prism
/// NodeParts: unbounded fn Cp, NodeDef -> Parts
/// ```
pub fn node_parts(cp: &Cp, n: &crate::lower::model::NodeDef) -> Parts {
    let ncp = with_fields(cp, &each(&n.fields, &(|(f, t, _): &(Text, crate::lower::model::OutTy, Text)| (f.clone(), t.clone()))));
    let base = if (&n.row_kind == &crate::lower::model::RowKind::NotARow) && (&len(&n.hosted) == &Nat::from(0u32)) {
        Text::lit("Node")
    } else {
        Text::lit("Row")
    };
    let fields = crate::syntax::lexer::join(&run_to_end(each_job(n.fields.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy, Text)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (f, t, doc) = p0;
                call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_79807: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{} {};", &cpp_doc(&doc), &cpp_type_79807, &field_id(&f)))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let consts = crate::syntax::lexer::join(&each(&n.consts, &(|(c, h, doc): &(Text, Nat, Text)| Text::from(format!("{}static constexpr std::uint32_t {} = {};", &cpp_doc(&Text::from(format!("The {}.", doc))), c, h)))), &Text::lit("\n"));
    let ctor_params = crate::syntax::lexer::join(&append(&Array::from(vec![Text::lit("Path path")]), &run_to_end(each_job(n.fields.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy, Text)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (f, t, _) = p0;
                call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_80059: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_80059, &field_id(&f)))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
    }))), &Text::lit(", "));
    let ctor_inits = crate::syntax::lexer::join(&append(&Array::from(vec![Text::lit("path(std::move(path))")]), &each(&n.fields, &(|(f, _, _): &(Text, crate::lower::model::OutTy, Text)| Text::from(format!("{}(std::move({}))", &field_id(f), &field_id(f)))))), &Text::lit(", "));
    let params = concat(&run_to_end(each_job(n.params.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (p_, t) = p0;
                call_then(start_param_type(cp.clone(), t.clone()), move |param_type_80298: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}, ", &param_type_80298, &p_))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let ret = if n.fallible {
        Text::from(format!("Result<prism_rtl::Rc<{}>>", &n.name))
    } else {
        Text::from(format!("prism_rtl::Rc<{}>", &n.name))
    };
    let make_decl = Text::from(format!("static {} make(Path path, {}Cx& cx);", &ret, &params));
    let method_decls = run_to_end(each_job(append(&n.methods, &n.hosted), {
        let ncp = ncp.clone();
        Rc::new(move |p0: crate::lower::model::MethDef| {
            let ncp = ncp.clone();
            entered(once_job(move || {
                let m = p0;
                call_then(start_method_sig(ncp.clone(), m.clone(), Text::lit("")), move |method_sig_80549: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &method_sig_80549))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let builder_decls = append(&each(&n.builders, &(|b: &crate::lower::model::ForDef| Text::from(format!("Done {}_build(Cx& cx);", &b.name)))), &each(&n.gens, &(|g: &crate::lower::model::GenDef| Text::from(format!("Done {}_build(Cx& cx);", &g.name)))));
    let hook_decls = each(&n.hooks, &(|(h, _): &(Text, Array<crate::lower::model::Do>)| Text::from(format!("{} override;", &hook_sig(h, &Text::lit(""))))));
    let answer_decl = if &len(&n.answers) == &Nat::from(0u32) {
        Array::new()
    } else {
        Array::from(vec![Text::lit("Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;")])
    };
    let row_decl = if &n.row_kind == &crate::lower::model::RowKind::NotARow {
        Array::new()
    } else {
        Array::from(vec![Text::lit("void leave_row(Cx& cx) override;")])
    };
    let decls = crate::syntax::lexer::join(&append(&append(&append(&append(&append(&Array::from(vec![make_decl.clone()]), &method_decls), &builder_decls), &hook_decls), &answer_decl), &row_decl), &Text::lit("\n"));
    let doc = cpp_source_doc(&Text::from(format!("`{}`: a node of its own (docs/backend.md, \"A widget block\").", &n.prism)), &n.doc);
    let decl = crate::emit::cpp::templates::node_class(&doc, &n.name, &base, &fields, &consts, &Text::from(format!("{}({}) : {} {{}}", &n.name, &ctor_params, &ctor_inits)), &decls);
    let by_field = each(&n.fields, &(|(f, _, _): &(Text, crate::lower::model::OutTy, Text)| or(&fold(&n.inits, &None, &(|found_opt: &Option<crate::lower::model::Ex>, (g, v_): &(Text, crate::lower::model::Ex)| if g == f { Some(v_.clone()) } else { found_opt.clone() })), &crate::lower::model::Ex::XVar(f.clone()))));
    let (lets_text, lcp) = cpp_statements_cp(&ncp, &n.lets);
    let args = crate::syntax::lexer::join(&append(&Array::from(vec![Text::lit("path")]), &run_to_end(each_job(by_field.clone(), {
        let lcp = lcp.clone();
        Rc::new(move |p0: crate::lower::model::Ex| {
            let lcp = lcp.clone();
            entered(once_job(move || {
                let v_ = p0;
                prism_rtl::Turn::More(Rc::new(CppExpr { cp: lcp.clone(), x: v_.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
    }))), &Text::lit(", "));
    let tail = if n.fallible { Text::lit("return node;") } else { Text::lit("return node;") };
    let make = crate::emit::cpp::templates::node_make(&n.name, &Text::from(format!("{} {}::make(Path path, {}Cx& cx)", &ret, &n.name, &params)), &lets_text, &args, &crate::syntax::lexer::join(&filter(&Array::from(vec![cpp_statements(&pointing(&lcp, &Text::lit("node")), &n.build), tail.clone()]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n")));
    let methods = run_to_end(each_job(append(&n.methods, &n.hosted), {
        let ncp = ncp.clone();
        let n = n.clone();
        Rc::new(move |p0: crate::lower::model::MethDef| {
            let ncp = ncp.clone();
            let n = n.clone();
            entered(once_job(move || {
                let m = p0;
                prism_rtl::Turn::More(Rc::new(MethodDef { cp: ncp.clone(), owner: n.name.clone(), m: m.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let builders = append(&run_to_end(each_job(n.builders.clone(), {
        let ncp = ncp.clone();
        let n = n.clone();
        Rc::new(move |p0: crate::lower::model::ForDef| {
            let ncp = ncp.clone();
            let n = n.clone();
            entered(once_job(move || {
                let b = p0;
                prism_rtl::Turn::More(Rc::new(ForBuildCpp { cp: ncp.clone(), owner: n.name.clone(), b: b.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::ForDef) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &run_to_end(each_job(n.gens.clone(), {
        let ncp = ncp.clone();
        let n = n.clone();
        Rc::new(move |p0: crate::lower::model::GenDef| {
            let ncp = ncp.clone();
            let n = n.clone();
            entered(once_job(move || {
                let g = p0;
                prism_rtl::Turn::More(Rc::new(GenBuildCpp { cp: ncp.clone(), owner: n.name.clone(), gd: g.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::GenDef) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let hooks = run_to_end(each_job(n.hooks.clone(), {
        let n = n.clone();
        let ncp = ncp.clone();
        Rc::new(move |p0: (Text, Array<crate::lower::model::Do>)| {
            let n = n.clone();
            let ncp = ncp.clone();
            entered(once_job(move || {
                let (h, body) = p0;
                call_then(start_cpp_statements(ncp.clone(), body.clone()), move |cpp_statements_82286: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::cpp_function(&Text::lit(""), &hook_sig(&h, &Text::from(format!("{}::", &n.name))), &Text::from(format!("{}\nreturn {{}};", &cpp_statements_82286)))))
            }))
        }) as Rc<dyn Fn((Text, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let answer = if &len(&n.answers) == &Nat::from(0u32) {
        Array::new()
    } else {
        Array::from(vec![answer_def_cpp(&ncp, n)])
    };
    let leaving = if &n.row_kind == &crate::lower::model::RowKind::NotARow {
        Array::new()
    } else {
        Array::from(vec![row_leaving(&ncp, n)])
    };
    let defs = append(&append(&append(&append(&append(&Array::from(vec![make.clone()]), &methods), &builders), &hooks), &answer), &leaving);
    let own = Parts { forward: Array::from(vec![Text::from(format!("class {};", &n.name))]), handles: Array::new(), values: Array::new(), cases: Array::new(), protos: Array::new(), classes: Array::from(vec![decl.clone()]), outer: Array::new(), generic: Array::new(), defs: defs.clone() };
    own.clone()
}

/// The step machine of `NodeParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NodeParts: unbounded fn Cp, NodeDef -> Parts
/// ```
pub struct NodeParts {
    pub cp: Cp,
    pub n: crate::lower::model::NodeDef,
}

impl prism_rtl::Job<Parts> for NodeParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let n = &self.n;
        let ncp = with_fields(cp, &each(&n.fields, &(|(f, t, _): &(Text, crate::lower::model::OutTy, Text)| (f.clone(), t.clone()))));
        let base = if (&n.row_kind == &crate::lower::model::RowKind::NotARow) && (&len(&n.hosted) == &Nat::from(0u32)) {
            Text::lit("Node")
        } else {
            Text::lit("Row")
        };
        let cp = cp.clone();
        let n = n.clone();
        call_value(each_job(n.fields.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: (Text, crate::lower::model::OutTy, Text)| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let (f, t, doc) = p0;
                    call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_79807: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{} {};", &cpp_doc(&doc), &cpp_type_79807, &field_id(&f)))))
                }))
            }) as Rc<dyn Fn((Text, crate::lower::model::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_79761: Array<Text>| {
            let fields = crate::syntax::lexer::join(&each_79761, &Text::lit("\n"));
            let consts = crate::syntax::lexer::join(&each(&n.consts, &(|(c, h, doc): &(Text, Nat, Text)| Text::from(format!("{}static constexpr std::uint32_t {} = {};", &cpp_doc(&Text::from(format!("The {}.", doc))), c, h)))), &Text::lit("\n"));
            call_value(each_job(n.fields.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: (Text, crate::lower::model::OutTy, Text)| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let (f, t, _) = p0;
                        call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_80059: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_80059, &field_id(&f)))))
                    }))
                }) as Rc<dyn Fn((Text, crate::lower::model::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_80022: Array<Text>| {
                let ctor_params = crate::syntax::lexer::join(&append(&Array::from(vec![Text::lit("Path path")]), &each_80022), &Text::lit(", "));
                let ctor_inits = crate::syntax::lexer::join(&append(&Array::from(vec![Text::lit("path(std::move(path))")]), &each(&n.fields, &(|(f, _, _): &(Text, crate::lower::model::OutTy, Text)| Text::from(format!("{}(std::move({}))", &field_id(f), &field_id(f)))))), &Text::lit(", "));
                call_value(each_job(n.params.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let (p_, t) = p0;
                            call_then(start_param_type(cp.clone(), t.clone()), move |param_type_80298: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}, ", &param_type_80298, &p_))))
                        }))
                    }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_80269: Array<Text>| {
                    let params = concat(&each_80269);
                    let ret = if n.fallible {
                        Text::from(format!("Result<prism_rtl::Rc<{}>>", &n.name))
                    } else {
                        Text::from(format!("prism_rtl::Rc<{}>", &n.name))
                    };
                    let make_decl = Text::from(format!("static {} make(Path path, {}Cx& cx);", &ret, &params));
                    call_value(each_job(append(&n.methods, &n.hosted), {
                        let ncp = ncp.clone();
                        Rc::new(move |p0: crate::lower::model::MethDef| {
                            let ncp = ncp.clone();
                            entered(once_job(move || {
                                let m = p0;
                                call_then(start_method_sig(ncp.clone(), m.clone(), Text::lit("")), move |method_sig_80549: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &method_sig_80549))))
                            }))
                        }) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>
                    }), move |each_80507: Array<Text>| {
                        let method_decls = each_80507;
                        let builder_decls = append(&each(&n.builders, &(|b: &crate::lower::model::ForDef| Text::from(format!("Done {}_build(Cx& cx);", &b.name)))), &each(&n.gens, &(|g: &crate::lower::model::GenDef| Text::from(format!("Done {}_build(Cx& cx);", &g.name)))));
                        let hook_decls = each(&n.hooks, &(|(h, _): &(Text, Array<crate::lower::model::Do>)| Text::from(format!("{} override;", &hook_sig(h, &Text::lit(""))))));
                        let answer_decl = if &len(&n.answers) == &Nat::from(0u32) {
                            Array::new()
                        } else {
                            Array::from(vec![Text::lit("Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;")])
                        };
                        let row_decl = if &n.row_kind == &crate::lower::model::RowKind::NotARow {
                            Array::new()
                        } else {
                            Array::from(vec![Text::lit("void leave_row(Cx& cx) override;")])
                        };
                        let decls = crate::syntax::lexer::join(&append(&append(&append(&append(&append(&Array::from(vec![make_decl.clone()]), &method_decls), &builder_decls), &hook_decls), &answer_decl), &row_decl), &Text::lit("\n"));
                        let doc = cpp_source_doc(&Text::from(format!("`{}`: a node of its own (docs/backend.md, \"A widget block\").", &n.prism)), &n.doc);
                        let decl = crate::emit::cpp::templates::node_class(&doc, &n.name, &base, &fields, &consts, &Text::from(format!("{}({}) : {} {{}}", &n.name, &ctor_params, &ctor_inits)), &decls);
                        let by_field = each(&n.fields, &(|(f, _, _): &(Text, crate::lower::model::OutTy, Text)| or(&fold(&n.inits, &None, &(|found_opt: &Option<crate::lower::model::Ex>, (g, v_): &(Text, crate::lower::model::Ex)| if g == f { Some(v_.clone()) } else { found_opt.clone() })), &crate::lower::model::Ex::XVar(f.clone()))));
                        call_then(start_cpp_statements_cp(ncp.clone(), n.lets.clone()), move |cpp_statements_cp_81618: (Text, Cp)| {
                            let (lets_text, lcp) = cpp_statements_cp_81618;
                            call_value(each_job(by_field.clone(), {
                                let lcp = lcp.clone();
                                Rc::new(move |p0: crate::lower::model::Ex| {
                                    let lcp = lcp.clone();
                                    entered(once_job(move || {
                                        let v_ = p0;
                                        prism_rtl::Turn::More(Rc::new(CppExpr { cp: lcp.clone(), x: v_.clone() }))
                                    }))
                                }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
                            }), move |each_81687: Array<Text>| {
                                let args = crate::syntax::lexer::join(&append(&Array::from(vec![Text::lit("path")]), &each_81687), &Text::lit(", "));
                                let tail = if n.fallible { Text::lit("return node;") } else { Text::lit("return node;") };
                                call_then(start_cpp_statements(pointing(&lcp, &Text::lit("node")), n.build.clone()), move |cpp_statements_81911: Text| {
                                    let make = crate::emit::cpp::templates::node_make(&n.name, &Text::from(format!("{} {}::make(Path path, {}Cx& cx)", &ret, &n.name, &params)), &lets_text, &args, &crate::syntax::lexer::join(&filter(&Array::from(vec![cpp_statements_81911, tail.clone()]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n")));
                                    call_value(each_job(append(&n.methods, &n.hosted), {
                                        let ncp = ncp.clone();
                                        let n = n.clone();
                                        Rc::new(move |p0: crate::lower::model::MethDef| {
                                            let ncp = ncp.clone();
                                            let n = n.clone();
                                            entered(once_job(move || {
                                                let m = p0;
                                                prism_rtl::Turn::More(Rc::new(MethodDef { cp: ncp.clone(), owner: n.name.clone(), m: m.clone() }))
                                            }))
                                        }) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>
                                    }), move |each_82006: Array<Text>| {
                                        let methods = each_82006;
                                        call_value(each_job(n.builders.clone(), {
                                            let ncp = ncp.clone();
                                            let n = n.clone();
                                            Rc::new(move |p0: crate::lower::model::ForDef| {
                                                let ncp = ncp.clone();
                                                let n = n.clone();
                                                entered(once_job(move || {
                                                    let b = p0;
                                                    prism_rtl::Turn::More(Rc::new(ForBuildCpp { cp: ncp.clone(), owner: n.name.clone(), b: b.clone() }))
                                                }))
                                            }) as Rc<dyn Fn(crate::lower::model::ForDef) -> Rc<dyn prism_rtl::Job<Text>>>
                                        }), move |each_82098: Array<Text>| call_value(each_job(n.gens.clone(), {
                                            let ncp = ncp.clone();
                                            let n = n.clone();
                                            Rc::new(move |p0: crate::lower::model::GenDef| {
                                                let ncp = ncp.clone();
                                                let n = n.clone();
                                                entered(once_job(move || {
                                                    let g = p0;
                                                    prism_rtl::Turn::More(Rc::new(GenBuildCpp { cp: ncp.clone(), owner: n.name.clone(), gd: g.clone() }))
                                                }))
                                            }) as Rc<dyn Fn(crate::lower::model::GenDef) -> Rc<dyn prism_rtl::Job<Text>>>
                                        }), move |each_82150: Array<Text>| {
                                            let builders = append(&each_82098, &each_82150);
                                            call_value(each_job(n.hooks.clone(), {
                                                let n = n.clone();
                                                let ncp = ncp.clone();
                                                Rc::new(move |p0: (Text, Array<crate::lower::model::Do>)| {
                                                    let n = n.clone();
                                                    let ncp = ncp.clone();
                                                    entered(once_job(move || {
                                                        let (h, body) = p0;
                                                        call_then(start_cpp_statements(ncp.clone(), body.clone()), move |cpp_statements_82286: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::cpp_function(&Text::lit(""), &hook_sig(&h, &Text::from(format!("{}::", &n.name))), &Text::from(format!("{}\nreturn {{}};", &cpp_statements_82286)))))
                                                    }))
                                                }) as Rc<dyn Fn((Text, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>
                                            }), move |each_82212: Array<Text>| {
                                                let hooks = each_82212;
                                                let answer = if &len(&n.answers) == &Nat::from(0u32) {
                                                    Array::new()
                                                } else {
                                                    Array::from(vec![answer_def_cpp(&ncp, &n)])
                                                };
                                                let leaving = if &n.row_kind == &crate::lower::model::RowKind::NotARow {
                                                    Array::new()
                                                } else {
                                                    Array::from(vec![row_leaving(&ncp, &n)])
                                                };
                                                let defs = append(&append(&append(&append(&append(&Array::from(vec![make.clone()]), &methods), &builders), &hooks), &answer), &leaving);
                                                let own = Parts { forward: Array::from(vec![Text::from(format!("class {};", &n.name))]), handles: Array::new(), values: Array::new(), cases: Array::new(), protos: Array::new(), classes: Array::from(vec![decl.clone()]), outer: Array::new(), generic: Array::new(), defs: defs.clone() };
                                                prism_rtl::Turn::Finished(own.clone())
                                            })
                                        }))
                                    })
                                })
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start NodeParts, x`: what the function value is when passed to `@Run`.
pub fn start_node_parts(cp: Cp, n: crate::lower::model::NodeDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(NodeParts { cp, n })
}

/// ```prism
/// MethodSig: unbounded fn Cp, MethDef, Text -> Text
/// ```
pub fn method_sig(cp: &Cp, m: &crate::lower::model::MethDef, owner: &Text) -> Text {
    let cx_ = match &m.cx_ {
        crate::lower::model::CxArg::CxMut => Array::from(vec![Text::lit("Cx& cx")]),
        crate::lower::model::CxArg::CxRef => Array::from(vec![Text::lit("const Cx& cx")]),
        crate::lower::model::CxArg::CxNone => Array::new(),
    };
    let params = crate::syntax::lexer::join(&append(&run_to_end(each_job(m.params.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (p_, t) = p0;
                call_then(start_param_type(cp.clone(), t.clone()), move |param_type_83005: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_83005, &p_))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &cx_), &Text::lit(", "));
    let constness = if &m.recv == &crate::lower::model::Recv::RecvRef {
        Text::lit(" const")
    } else {
        Text::lit("")
    };
    Text::from(format!("{} {}{}({}){}", &cpp_type(cp, &m.ret), owner, &node_method_name(cp, &m.name), &params, &constness))
}

/// The step machine of `MethodSig`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MethodSig: unbounded fn Cp, MethDef, Text -> Text
/// ```
pub struct MethodSig {
    pub cp: Cp,
    pub m: crate::lower::model::MethDef,
    pub owner: Text,
}

impl prism_rtl::Job<Text> for MethodSig {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let m = &self.m;
        let owner = &self.owner;
        let cx_ = match &m.cx_ {
            crate::lower::model::CxArg::CxMut => Array::from(vec![Text::lit("Cx& cx")]),
            crate::lower::model::CxArg::CxRef => Array::from(vec![Text::lit("const Cx& cx")]),
            crate::lower::model::CxArg::CxNone => Array::new(),
        };
        let cp = cp.clone();
        let m = m.clone();
        let owner = owner.clone();
        call_value(each_job(m.params.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let (p_, t) = p0;
                    call_then(start_param_type(cp.clone(), t.clone()), move |param_type_83005: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_83005, &p_))))
                }))
            }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_82976: Array<Text>| {
            let params = crate::syntax::lexer::join(&append(&each_82976, &cx_), &Text::lit(", "));
            let constness = if &m.recv == &crate::lower::model::Recv::RecvRef {
                Text::lit(" const")
            } else {
                Text::lit("")
            };
            call_then(start_cpp_type(cp.clone(), m.ret.clone()), move |cpp_type_83105: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}{}({}){}", &cpp_type_83105, &owner, &node_method_name(&cp, &m.name), &params, &constness))))
        })
    }
}

/// `Start MethodSig, x`: what the function value is when passed to `@Run`.
pub fn start_method_sig(cp: Cp, m: crate::lower::model::MethDef, owner: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(MethodSig { cp, m, owner })
}

/// ```prism
/// MethodDef: unbounded fn Cp, Text, MethDef -> Text
/// ```
pub fn method_def(cp: &Cp, owner: &Text, m: &crate::lower::model::MethDef) -> Text {
    let (st, cp2) = cpp_statements_cp(cp, &m.body);
    let body = if &m.ret == &crate::lower::model::OutTy::OutUnit {
        Text::from(format!("{}\nreturn Unit{{}};", &st))
    } else {
        if &len(&m.body) == &Nat::from(0u32) {
            cpp_body(cp, &m.tail)
        } else {
            Text::from(format!("{}\n{}", &st, &cpp_body(&cp2, &m.tail)))
        }
    };
    crate::emit::cpp::templates::cpp_function(&cpp_doc(&m.doc), &method_sig(cp, m, &Text::from(format!("{}::", owner))), &body)
}

/// The step machine of `MethodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MethodDef: unbounded fn Cp, Text, MethDef -> Text
/// ```
pub struct MethodDef {
    pub cp: Cp,
    pub owner: Text,
    pub m: crate::lower::model::MethDef,
}

impl prism_rtl::Job<Text> for MethodDef {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let owner = &self.owner;
        let m = &self.m;
        let cp = cp.clone();
        let m = m.clone();
        let owner = owner.clone();
        call_then(start_cpp_statements_cp(cp.clone(), m.body.clone()), move |cpp_statements_cp_83281: (Text, Cp)| {
            let (st, cp2) = cpp_statements_cp_83281;
            let body = if &m.ret == &crate::lower::model::OutTy::OutUnit {
                Text::from(format!("{}\nreturn Unit{{}};", &st))
            } else {
                if &len(&m.body) == &Nat::from(0u32) {
                    cpp_body(&cp, &m.tail)
                } else {
                    Text::from(format!("{}\n{}", &st, &cpp_body(&cp2, &m.tail)))
                }
            };
            call_then(start_method_sig(cp.clone(), m.clone(), Text::from(format!("{}::", &owner))), move |method_sig_83485: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::cpp_function(&cpp_doc(&m.doc), &method_sig_83485, &body)))
        })
    }
}

/// `Start MethodDef, x`: what the function value is when passed to `@Run`.
pub fn start_method_def(cp: Cp, owner: Text, m: crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(MethodDef { cp, owner, m })
}

/// ```prism
/// HookSig: fn Text, Text -> Text
/// ```
pub fn hook_sig(text0: &Text, owner: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("push")) => Text::from(format!("Done {}push(const Pod& element, const Pod& v, Cx& cx)", owner)),
        h => Text::from(format!("Done {}{}(Cx& cx)", owner, h)),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// AnswerDefCpp: unbounded fn Cp, NodeDef -> Text
/// ```
pub fn answer_def_cpp(cp: &Cp, n: &crate::lower::model::NodeDef) -> Text {
    let arms = run_to_end(each_job(n.answers.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (crate::lower::model::Pa, crate::lower::model::Ex)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (pat, call) = p0;
                call_then(start_pat_conds(cp.clone(), pat.clone(), Text::lit("at")), move |pat_conds_83828: Array<Text>| {
                    let tests = pat_conds_83828;
                    call_then(start_pat_binds(cp.clone(), pat.clone(), Text::lit("at")), move |pat_binds_83871: Array<Text>| {
                        let binds = pat_binds_83871;
                        call_then(start_cpp_expr(cp.clone(), call.clone()), move |cpp_expr_83932: Text| prism_rtl::Turn::Finished((tests.clone(), crate::syntax::lexer::join(&push(&binds, &Text::from(format!("{};", &cpp_expr_83932))), &Text::lit("\n")))))
                    })
                })
            }))
        }) as Rc<dyn Fn((crate::lower::model::Pa, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Text)>>>
    }));
    let blocks = each(&crate::check::errors::range0(&len(&arms)), &(|i: &Nat| {
        let (tests, inner) = or(&index(&arms, i), &(Array::new(), Text::lit("")));
        crate::emit::cpp::templates::block(&Text::from(format!("{} ({})", &(if i == &Nat::from(0u32) { Text::lit("if") } else { Text::lit("else if") }), &conds(&tests))), &inner)
    }));
    crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("Done {}::answer(std::span<const Segment> at, const Pod& v, Cx& cx)", &n.name)), &Text::from(format!("{} else {{\n    return unexpected(Fault::answer(str(\"no answering place at \", path_of(at))));\n}}\nreturn {{}};", &crate::syntax::lexer::join(&blocks, &Text::lit(" ")))))
}

/// The step machine of `AnswerDefCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnswerDefCpp: unbounded fn Cp, NodeDef -> Text
/// ```
pub struct AnswerDefCpp {
    pub cp: Cp,
    pub n: crate::lower::model::NodeDef,
}

impl prism_rtl::Job<Text> for AnswerDefCpp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let n = &self.n;
        let cp = cp.clone();
        let n = n.clone();
        call_value(each_job(n.answers.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: (crate::lower::model::Pa, crate::lower::model::Ex)| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let (pat, call) = p0;
                    call_then(start_pat_conds(cp.clone(), pat.clone(), Text::lit("at")), move |pat_conds_83828: Array<Text>| {
                        let tests = pat_conds_83828;
                        call_then(start_pat_binds(cp.clone(), pat.clone(), Text::lit("at")), move |pat_binds_83871: Array<Text>| {
                            let binds = pat_binds_83871;
                            call_then(start_cpp_expr(cp.clone(), call.clone()), move |cpp_expr_83932: Text| prism_rtl::Turn::Finished((tests.clone(), crate::syntax::lexer::join(&push(&binds, &Text::from(format!("{};", &cpp_expr_83932))), &Text::lit("\n")))))
                        })
                    })
                }))
            }) as Rc<dyn Fn((crate::lower::model::Pa, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<(Array<Text>, Text)>>>
        }), move |each_83775: Array<(Array<Text>, Text)>| {
            let arms = each_83775;
            let blocks = each(&crate::check::errors::range0(&len(&arms)), &(|i: &Nat| {
                let (tests, inner) = or(&index(&arms, i), &(Array::new(), Text::lit("")));
                crate::emit::cpp::templates::block(&Text::from(format!("{} ({})", &(if i == &Nat::from(0u32) { Text::lit("if") } else { Text::lit("else if") }), &conds(&tests))), &inner)
            }));
            prism_rtl::Turn::Finished(crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("Done {}::answer(std::span<const Segment> at, const Pod& v, Cx& cx)", &n.name)), &Text::from(format!("{} else {{\n    return unexpected(Fault::answer(str(\"no answering place at \", path_of(at))));\n}}\nreturn {{}};", &crate::syntax::lexer::join(&blocks, &Text::lit(" "))))))
        })
    }
}

/// `Start AnswerDefCpp, x`: what the function value is when passed to `@Run`.
pub fn start_answer_def_cpp(cp: Cp, n: crate::lower::model::NodeDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(AnswerDefCpp { cp, n })
}

/// ```prism
/// RowLeaving: unbounded fn Cp, NodeDef -> Text
/// ```
pub fn row_leaving(cp: &Cp, n: &crate::lower::model::NodeDef) -> Text {
    let kept = if &n.row_kind == &crate::lower::model::RowKind::ForRow {
        Array::from(vec![Text::lit("this->left_entry = entry(cx);")])
    } else {
        Array::new()
    };
    let unsubscribe = each(&n.subs, &(|(ev, m, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("if (auto p = parent.lock(); p && {}_sub) deref(p->{}_port).unsubscribe(*std::exchange({}_sub, std::nullopt));", m, ev, m))));
    crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("void {}::leave_row(Cx& cx)", &n.name)), &crate::syntax::lexer::join(&append(&push(&kept, &Text::lit("remove_places(cx);")), &unsubscribe), &Text::lit("\n")))
}

/// The step machine of `RowLeaving`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowLeaving: unbounded fn Cp, NodeDef -> Text
/// ```
pub struct RowLeaving {
    pub cp: Cp,
    pub n: crate::lower::model::NodeDef,
}

impl prism_rtl::Job<Text> for RowLeaving {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let n = &self.n;
        let kept = if &n.row_kind == &crate::lower::model::RowKind::ForRow {
            Array::from(vec![Text::lit("this->left_entry = entry(cx);")])
        } else {
            Array::new()
        };
        let unsubscribe = each(&n.subs, &(|(ev, m, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("if (auto p = parent.lock(); p && {}_sub) deref(p->{}_port).unsubscribe(*std::exchange({}_sub, std::nullopt));", m, ev, m))));
        prism_rtl::Turn::Finished(crate::emit::cpp::templates::cpp_function(&Text::lit(""), &Text::from(format!("void {}::leave_row(Cx& cx)", &n.name)), &crate::syntax::lexer::join(&append(&push(&kept, &Text::lit("remove_places(cx);")), &unsubscribe), &Text::lit("\n"))))
    }
}

/// `Start RowLeaving, x`: what the function value is when passed to `@Run`.
pub fn start_row_leaving(cp: Cp, n: crate::lower::model::NodeDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RowLeaving { cp, n })
}

/// ```prism
/// ForBuildCpp: unbounded fn Cp, Text, ForDef -> Text
/// ```
pub fn for_build_cpp(cp: &Cp, owner: &Text, b: &crate::lower::model::ForDef) -> Text {
    crate::emit::cpp::templates::for_build_template(owner, &b.name, &cpp_expr(cp, &b.at), &cpp_type(cp, &b.key_ty), &cpp_type(cp, &b.value_ty), &call_path(&Text::from(format!("{}::build", &b.row_node))), &b.source, &cpp_expr(cp, &b.parent), &concat(&run_to_end(each_job(b.passed.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::Ex| {
            let cp = cp.clone();
            entered(once_job(move || {
                let x = p0;
                call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_85236: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}", &cpp_expr_85236))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
    }))))
}

/// The step machine of `ForBuildCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ForBuildCpp: unbounded fn Cp, Text, ForDef -> Text
/// ```
pub struct ForBuildCpp {
    pub cp: Cp,
    pub owner: Text,
    pub b: crate::lower::model::ForDef,
}

impl prism_rtl::Job<Text> for ForBuildCpp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let owner = &self.owner;
        let b = &self.b;
        let b = b.clone();
        let cp = cp.clone();
        let owner = owner.clone();
        call_then(start_cpp_expr(cp.clone(), b.at.clone()), move |cpp_expr_85069: Text| call_then(start_cpp_type(cp.clone(), b.key_ty.clone()), move |cpp_type_85089: Text| call_then(start_cpp_type(cp.clone(), b.value_ty.clone()), move |cpp_type_85112: Text| call_then(start_cpp_expr(cp.clone(), b.parent.clone()), move |cpp_expr_85180: Text| call_value(each_job(b.passed.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: crate::lower::model::Ex| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let x = p0;
                    call_then(start_cpp_expr(cp.clone(), x.clone()), move |cpp_expr_85236: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}", &cpp_expr_85236))))
                }))
            }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_85212: Array<Text>| prism_rtl::Turn::Finished(crate::emit::cpp::templates::for_build_template(&owner, &b.name, &cpp_expr_85069, &cpp_type_85089, &cpp_type_85112, &call_path(&Text::from(format!("{}::build", &b.row_node))), &b.source, &cpp_expr_85180, &concat(&each_85212))))))))
    }
}

/// `Start ForBuildCpp, x`: what the function value is when passed to `@Run`.
pub fn start_for_build_cpp(cp: Cp, owner: Text, b: crate::lower::model::ForDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ForBuildCpp { cp, owner, b })
}

/// ```prism
/// GenBuildCpp: unbounded fn Cp, Text, GenDef -> Text
/// ```
pub fn gen_build_cpp(cp: &Cp, owner: &Text, gd: &crate::lower::model::GenDef) -> Text {
    let path_ = if gd.transparent {
        Text::lit("this->path")
    } else {
        Text::from(format!("{}.child(Segment::gen(g))", &cpp_expr(cp, &gd.at)))
    };
    crate::emit::cpp::templates::gen_build_template(owner, &gd.name, &cpp_expr(cp, &gd.at), &path_, &cpp_expr(cp, &gd.source), &cpp_type(cp, &gd.value_ty), &cpp_expr(cp, &gd.select))
}

/// The step machine of `GenBuildCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GenBuildCpp: unbounded fn Cp, Text, GenDef -> Text
/// ```
pub struct GenBuildCpp {
    pub cp: Cp,
    pub owner: Text,
    pub gd: crate::lower::model::GenDef,
}

impl prism_rtl::Job<Text> for GenBuildCpp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let owner = &self.owner;
        let gd = &self.gd;
        let path_ = if gd.transparent {
            Text::lit("this->path")
        } else {
            Text::from(format!("{}.child(Segment::gen(g))", &cpp_expr(cp, &gd.at)))
        };
        let cp = cp.clone();
        let gd = gd.clone();
        let owner = owner.clone();
        call_then(start_cpp_expr(cp.clone(), gd.at.clone()), move |cpp_expr_85472: Text| call_then(start_cpp_expr(cp.clone(), gd.source.clone()), move |cpp_expr_85499: Text| call_then(start_cpp_type(cp.clone(), gd.value_ty.clone()), move |cpp_type_85524: Text| call_then(start_cpp_expr(cp.clone(), gd.select.clone()), move |cpp_expr_85550: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::gen_build_template(&owner, &gd.name, &cpp_expr_85472, &path_, &cpp_expr_85499, &cpp_type_85524, &cpp_expr_85550))))))
    }
}

/// `Start GenBuildCpp, x`: what the function value is when passed to `@Run`.
pub fn start_gen_build_cpp(cp: Cp, owner: Text, gd: crate::lower::model::GenDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(GenBuildCpp { cp, owner, gd })
}

/// ```prism
/// ProgramCpp: unbounded fn Cp, ProgDef, Bool -> Text
/// ```
pub fn program_cpp(cp: &Cp, p_: &crate::lower::model::ProgDef, fallible: &bool) -> Text {
    let n = len(&p_.params);
    let names = each(&p_.params, &(|(a, _): &(Text, crate::lower::model::OutTy)| a.clone()));
    let plural = if &n == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") };
    let decode = if &n == &Nat::from(0u32) {
        Text::lit("static_cast<void>(args);")
    } else {
        crate::syntax::lexer::join(&append(&Array::from(vec![Text::from(format!("if (args.size() != {}) return unexpected(Fault::answer(\"@{} takes {} argument{}\"));", &n, &p_.prism, &n, &plural))]), &run_to_end(each_job(crate::check::errors::range0(&n), {
            let cp = cp.clone();
            let p_ = p_.clone();
            Rc::new(move |p0: Nat| {
                let cp = cp.clone();
                let p_ = p_.clone();
                entered(once_job(move || {
                    let i = p0;
                    prism_rtl::Turn::More(Rc::new(DecodeArg { cp: cp.clone(), ps: p_.params.clone(), i: i.clone() }))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
        }))), &Text::lit("\n"))
    };
    let call = Text::from(format!("{}(Path::root(), {}cx)", &call_path(&Text::from(format!("{}::build", &p_.node_))), &concat(&each(&names, &(|a: &Text| Text::from(format!("{}, ", a)))))));
    let root = if *fallible { Text::from(format!("TRY({})", &call)) } else { call.clone() };
    crate::emit::cpp::templates::program_class(&p_.name, &p_.prism, &type_path(&p_.node_), &decode, &root)
}

/// The step machine of `ProgramCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ProgramCpp: unbounded fn Cp, ProgDef, Bool -> Text
/// ```
pub struct ProgramCpp {
    pub cp: Cp,
    pub p_: crate::lower::model::ProgDef,
    pub fallible: bool,
}

impl prism_rtl::Job<Text> for ProgramCpp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let p_ = &self.p_;
        let fallible = &self.fallible;
        let n = len(&p_.params);
        let names = each(&p_.params, &(|(a, _): &(Text, crate::lower::model::OutTy)| a.clone()));
        let plural = if &n == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") };
        let decode = if &n == &Nat::from(0u32) {
            Text::lit("static_cast<void>(args);")
        } else {
            crate::syntax::lexer::join(&append(&Array::from(vec![Text::from(format!("if (args.size() != {}) return unexpected(Fault::answer(\"@{} takes {} argument{}\"));", &n, &p_.prism, &n, &plural))]), &run_to_end(each_job(crate::check::errors::range0(&n), {
                let cp = cp.clone();
                let p_ = p_.clone();
                Rc::new(move |p0: Nat| {
                    let cp = cp.clone();
                    let p_ = p_.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(DecodeArg { cp: cp.clone(), ps: p_.params.clone(), i: i.clone() }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
            }))), &Text::lit("\n"))
        };
        let call = Text::from(format!("{}(Path::root(), {}cx)", &call_path(&Text::from(format!("{}::build", &p_.node_))), &concat(&each(&names, &(|a: &Text| Text::from(format!("{}, ", a)))))));
        let root = if *fallible { Text::from(format!("TRY({})", &call)) } else { call.clone() };
        prism_rtl::Turn::Finished(crate::emit::cpp::templates::program_class(&p_.name, &p_.prism, &type_path(&p_.node_), &decode, &root))
    }
}

/// `Start ProgramCpp, x`: what the function value is when passed to `@Run`.
pub fn start_program_cpp(cp: Cp, p_: crate::lower::model::ProgDef, fallible: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ProgramCpp { cp, p_, fallible })
}

/// ```prism
/// DecodeArg: unbounded fn Cp, [((Text, OutTy))], Nat -> Text
/// ```
pub fn decode_arg(cp: &Cp, ps: &Array<(Text, crate::lower::model::OutTy)>, i: &Nat) -> Text {
    match index(ps, i) {
        Some((a, t)) => Text::from(format!("auto {} = TRY(prism_rtl::from_pod<{}>(args[{}]));", &a, &cpp_type(cp, &t), i)),
        None => Text::lit(""),
    }
}

/// The step machine of `DecodeArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DecodeArg: unbounded fn Cp, [((Text, OutTy))], Nat -> Text
/// ```
pub struct DecodeArg {
    pub cp: Cp,
    pub ps: Array<(Text, crate::lower::model::OutTy)>,
    pub i: Nat,
}

impl prism_rtl::Job<Text> for DecodeArg {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let ps = &self.ps;
        let i = &self.i;
        match index(ps, i) {
            Some((a, t)) => {
                let cp = cp.clone();
                let i = i.clone();
                call_then(start_cpp_type(cp.clone(), t.clone()), move |cpp_type_86380: Text| prism_rtl::Turn::Finished(Text::from(format!("auto {} = TRY(prism_rtl::from_pod<{}>(args[{}]));", &a, &cpp_type_86380, &i))))
            },
            None => prism_rtl::Turn::Finished(Text::lit("")),
        }
    }
}

/// `Start DecodeArg, x`: what the function value is when passed to `@Run`.
pub fn start_decode_arg(cp: Cp, ps: Array<(Text, crate::lower::model::OutTy)>, i: Nat) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(DecodeArg { cp, ps, i })
}

/// ```prism
/// ModuleParts: unbounded fn Cp, ModDef -> Parts
/// ```
pub fn module_parts(cp: &Cp, m: &crate::lower::model::ModDef) -> Parts {
    let mcp = in_home(cp, &m.name);
    let all = run_to_end(fold_job(m.items.clone(), no_parts(), {
        let mcp = mcp.clone();
        Rc::new(move |(p0, p1): (Parts, crate::lower::model::Item)| {
            let mcp = mcp.clone();
            entered(once_job(move || {
                let acc = p0;
                let it = p1;
                call_then(start_item_parts(mcp.clone(), it.clone()), move |item_parts_86829: Parts| prism_rtl::Turn::Finished(join_parts(&acc, &item_parts_86829)))
            }))
        }) as Rc<dyn Fn((Parts, crate::lower::model::Item)) -> Rc<dyn prism_rtl::Job<Parts>>>
    }));
    Parts { forward: in_ns(&m.name, &all.forward), handles: in_ns(&m.name, &all.handles), values: each(&all.values, &(|v_: &ValueDecl| in_ns_value(&m.name, v_))), cases: in_ns(&m.name, &all.cases), protos: in_ns(&m.name, &all.protos), classes: in_ns(&m.name, &all.classes), outer: all.outer.clone(), generic: in_ns(&m.name, &all.generic), defs: all.defs.clone() }
}

/// The step machine of `ModuleParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModuleParts: unbounded fn Cp, ModDef -> Parts
/// ```
pub struct ModuleParts {
    pub cp: Cp,
    pub m: crate::lower::model::ModDef,
}

impl prism_rtl::Job<Parts> for ModuleParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let m = &self.m;
        let mcp = in_home(cp, &m.name);
        let m = m.clone();
        call_value(fold_job(m.items.clone(), no_parts(), {
            let mcp = mcp.clone();
            Rc::new(move |(p0, p1): (Parts, crate::lower::model::Item)| {
                let mcp = mcp.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let it = p1;
                    call_then(start_item_parts(mcp.clone(), it.clone()), move |item_parts_86829: Parts| prism_rtl::Turn::Finished(join_parts(&acc, &item_parts_86829)))
                }))
            }) as Rc<dyn Fn((Parts, crate::lower::model::Item)) -> Rc<dyn prism_rtl::Job<Parts>>>
        }), move |fold_86779: Parts| {
            let all = fold_86779;
            prism_rtl::Turn::Finished(Parts { forward: in_ns(&m.name, &all.forward), handles: in_ns(&m.name, &all.handles), values: each(&all.values, &(|v_: &ValueDecl| in_ns_value(&m.name, v_))), cases: in_ns(&m.name, &all.cases), protos: in_ns(&m.name, &all.protos), classes: in_ns(&m.name, &all.classes), outer: all.outer.clone(), generic: in_ns(&m.name, &all.generic), defs: all.defs.clone() })
        })
    }
}

/// `Start ModuleParts, x`: what the function value is when passed to `@Run`.
pub fn start_module_parts(cp: Cp, m: crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(ModuleParts { cp, m })
}

/// ```prism
/// InNsValue: fn Text, ValueDecl -> ValueDecl
/// ```
pub fn in_ns_value(ns: &Text, v_: &ValueDecl) -> ValueDecl {
    let mut this: ValueDecl = v_.clone();
    this.text = Text::from(format!("namespace {} {{\n\n{}\n\n}}  // namespace {}", ns, &this.text, ns));
    this
}

/// ```prism
/// InNs: fn Text, [Text] -> [Text]
/// ```
pub fn in_ns(ns: &Text, xs1: &Array<Text>) -> Array<Text> {
    match xs1 {
        c0_1 if (c0_1.len() == 0) => Array::new(),
        xs => Array::from(vec![Text::from(format!("namespace {} {{\n\n{}\n\n}}  // namespace {}", ns, &crate::syntax::lexer::join(xs, &Text::lit("\n\n")), ns))]),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// NodeFallibleCpp: fn Model, Text -> Bool
/// ```
pub fn node_fallible_cpp(model: &crate::lower::model::Model, path_: &Text) -> bool {
    fold(&model.mods, &false, &(|f: &bool, m: &crate::lower::model::ModDef| fold(&m.items, f, &(|f2: &bool, it: &crate::lower::model::Item| match it {
        crate::lower::model::Item::ItNode(n) => *f2 || ((&Text::from(format!("{}::{}", &m.name, &n.name)) == path_) && n.fallible),
        _ => *f2,
    }))))
}

/// ```prism
/// EmitCpp: unbounded fn Model, Text, [Text] -> [((Text, Text))]
/// ```
pub fn emit_cpp(model: &crate::lower::model::Model, runtime: &Text, scripts: &Array<Text>) -> Array<(Text, Text)> {
    let cp = context(model);
    let crate_ = in_home(&cp, &Text::lit(""));
    let elem = row_parts(&crate_, &Text::lit(""), &model.elem);
    let answer = answer_parts(&crate_, &model.answer);
    let mods = run_to_end(each_job(model.mods.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::ModDef| {
            let cp = cp.clone();
            entered(once_job(move || {
                let m = p0;
                prism_rtl::Turn::More(Rc::new(ModuleParts { cp: cp.clone(), m: m.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<Parts>>>
    }));
    let programs = crate::syntax::lexer::join(&run_to_end(each_job(all_programs_cpp(model), {
        let crate_ = crate_.clone();
        let model = model.clone();
        Rc::new(move |p0: crate::lower::model::ProgDef| {
            let crate_ = crate_.clone();
            let model = model.clone();
            entered(once_job(move || {
                let p_ = p0;
                prism_rtl::Turn::More(Rc::new(ProgramCpp { cp: crate_.clone(), p_: p_.clone(), fallible: node_fallible_cpp(&model, &p_.node_) }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::ProgDef) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n\n"));
    let regs = concat(&each(&model.programs, &(|p_: &crate::lower::model::ProgDef| Text::from(format!("\n.program<{}>(\"{}\")", &p_.name, &p_.prism)))));
    let checks = concat(&run_to_end(each_job(model.checks.clone(), {
        let crate_ = crate_.clone();
        Rc::new(move |p0: crate::lower::model::CheckDef| {
            let crate_ = crate_.clone();
            entered(once_job(move || {
                let c = p0;
                call_value(each_job(c.lines.clone(), {
                    let crate_ = crate_.clone();
                    Rc::new(move |p0: crate::lower::model::Ex| {
                        let crate_ = crate_.clone();
                        entered(once_job(move || {
                            let l = p0;
                            prism_rtl::Turn::More(Rc::new(CppExpr { cp: crate_.clone(), x: l.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_88400: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("\n.check(\"{}\", [] {{ return std::vector<Result<Pod>>{{{}}}; }})", &c.name, &crate::syntax::lexer::join(&each_88400, &Text::lit(", "))))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::CheckDef) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let script_list = crate::syntax::lexer::join(&each(scripts, &(|s: &Text| Text::from(format!("\"{}\",", &crate::lower::escape(s))))), &Text::lit("\n"));
    let world = match &model.root {
        Some(r) => r.world.clone(),
        None => Text::lit("test"),
    };
    let canvas = &world == &Text::lit("canvas");
    let run_root = match &model.root {
        Some(r) => crate::emit::cpp::templates::cpp_run_root(&r.name, &(if canvas {
            crate::emit::cpp::templates::cpp_canvas_run(&r.name)
        } else {
            crate::emit::cpp::templates::cpp_no_canvas(&r.name)
        })),
        None => crate::emit::cpp::templates::cpp_no_root(&model.name),
    };
    let both_ = join_parts(&elem, &answer);
    let elem_decl = crate::emit::cpp::templates::cpp_elem_decl(&includes(&Text::lit("decl"), &append(&model.elem_complete, &model.elem_declared)), &crate::syntax::lexer::join(&both_.forward, &Text::lit("\n\n")), &crate::syntax::lexer::join(&both_.handles, &Text::lit("\n\n")), &crate::emit::cpp::prelude::cpp_prelude_rows(&Text::lit("")));
    let elem_types = crate::emit::cpp::templates::cpp_elem_types(&crate::syntax::lexer::join(&filter(&Array::from(vec![includes(&Text::lit("types"), &model.elem_complete), includes(&Text::lit("decl"), &model.elem_declared)]), &(|t: &Text| t != &Text::lit(""))), &Text::lit("\n")), &crate::syntax::lexer::join(&both_.cases, &Text::lit("\n\n")));
    let pairs = each(&crate::check::errors::range0(&len(&model.mods)), &(|i: &Nat| (or(&index(&model.mods, i), &no_mod()), or(&index(&mods, i), &no_parts()))));
    let generics = fold(&pairs, &Array::new(), &(|acc: &Array<Text>, (m, p_): &(crate::lower::model::ModDef, Parts)| if &len(&p_.generic) > &Nat::from(0u32) { push(acc, &m.name) } else { acc.clone() }));
    let per_module = run_to_end(each_job(pairs.clone(), {
        let generics = generics.clone();
        Rc::new(move |p0: (crate::lower::model::ModDef, Parts)| {
            let generics = generics.clone();
            entered(once_job(move || {
                let (m, p_) = p0;
                prism_rtl::Turn::More(Rc::new(ModuleFiles { m: m.clone(), p_: p_.clone(), generics: generics.clone() }))
            }))
        }) as Rc<dyn Fn((crate::lower::model::ModDef, Parts)) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>>>
    }));
    let main_includes = crate::syntax::lexer::join(&append(&append(&Array::from(vec![Text::lit("#include \"elem.types.hpp\"")]), &Array::from(vec![includes(&Text::lit(""), &each(&model.mods, &(|m: &crate::lower::model::ModDef| m.name.clone())))])), &Array::from(vec![includes(&Text::lit("generic"), &generics)])), &Text::lit("\n"));
    let canvas_include = if canvas {
        crate::emit::cpp::templates::cpp_canvas_include(&Text::lit(""))
    } else {
        Text::lit("")
    };
    let main = crate::emit::cpp::templates::cpp_main(&model.name, &Text::from(format!("#include \"programs.hpp\"\n{}", &canvas_include)), &regs, &checks, &script_list, &world, &run_root, &crate::syntax::lexer::join(&concat2(&each(&Array::from(vec![elem.clone(), answer.clone()]), &(|p_: &Parts| p_.defs.clone()))), &Text::lit("\n\n")));
    let groups = run_to_end(each_job(filter(&model.mods, &(|m: &crate::lower::model::ModDef| (&len(&m.types_with) > &Nat::from(1u32)) && (&or(&index(&m.types_with, &Nat::from(0u32)), &Text::lit("")) == &m.name))), {
        let pairs = pairs.clone();
        Rc::new(move |p0: crate::lower::model::ModDef| {
            let pairs = pairs.clone();
            entered(once_job(move || {
                let m = p0;
                prism_rtl::Turn::More(Rc::new(GroupTypesFile { pairs: pairs.clone(), group: m.types_with.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<(Text, Text)>>>
    }));
    let files = fold(&per_module, &Array::new(), &(|acc: &Array<(Text, Text)>, fs: &Array<(Text, Text)>| append(acc, fs)));
    let sources = crate::syntax::lexer::join(&filter(&each(&files, &(|(f, _): &(Text, Text)| f.clone())), &(|f: &Text| crate::syntax::lexer::contains(f, &Text::lit(".cpp")))), &Text::lit(" "));
    append(&Array::from(vec![(Text::lit("Makefile"), crate::emit::cpp::templates::cpp_makefile(&model.name, runtime, &sources, &(if canvas {
        crate::emit::cpp::templates::cpp_makefile_canvas(runtime)
    } else {
        Text::lit("")
    }))), (Text::lit("src/elem.decl.hpp"), elem_decl.clone()), (Text::lit("src/elem.types.hpp"), elem_types.clone()), (Text::lit("src/programs.hpp"), crate::emit::cpp::templates::cpp_programs_header(&model.name, &main_includes, &programs)), (Text::lit("src/main.cpp"), main.clone()), (Text::lit("src/prelude.hpp"), crate::emit::cpp::prelude::cpp_prelude_source(&Text::lit("")))]), &append(&groups, &files))
}

/// The step machine of `EmitCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EmitCpp: unbounded fn Model, Text, [Text] -> [((Text, Text))]
/// ```
pub struct EmitCpp {
    pub model: crate::lower::model::Model,
    pub runtime: Text,
    pub scripts: Array<Text>,
}

impl prism_rtl::Job<Array<(Text, Text)>> for EmitCpp {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Text, Text)>> {
        let model = &self.model;
        let runtime = &self.runtime;
        let scripts = &self.scripts;
        let cp = context(model);
        let crate_ = in_home(&cp, &Text::lit(""));
        let model = model.clone();
        let runtime = runtime.clone();
        let scripts = scripts.clone();
        call_then(start_row_parts(crate_.clone(), Text::lit(""), model.elem.clone()), move |row_parts_87937: Parts| {
            let elem = row_parts_87937;
            call_then(start_answer_parts(crate_.clone(), model.answer.clone()), move |answer_parts_87985: Parts| {
                let answer = answer_parts_87985;
                call_value(each_job(model.mods.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: crate::lower::model::ModDef| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let m = p0;
                            prism_rtl::Turn::More(Rc::new(ModuleParts { cp: cp.clone(), m: m.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<Parts>>>
                }), move |each_88032: Array<Parts>| {
                    let mods = each_88032;
                    call_value(each_job(all_programs_cpp(&model), {
                        let crate_ = crate_.clone();
                        let model = model.clone();
                        Rc::new(move |p0: crate::lower::model::ProgDef| {
                            let crate_ = crate_.clone();
                            let model = model.clone();
                            entered(once_job(move || {
                                let p_ = p0;
                                prism_rtl::Turn::More(Rc::new(ProgramCpp { cp: crate_.clone(), p_: p_.clone(), fallible: node_fallible_cpp(&model, &p_.node_) }))
                            }))
                        }) as Rc<dyn Fn(crate::lower::model::ProgDef) -> Rc<dyn prism_rtl::Job<Text>>>
                    }), move |each_88097: Array<Text>| {
                        let programs = crate::syntax::lexer::join(&each_88097, &Text::lit("\n\n"));
                        let regs = concat(&each(&model.programs, &(|p_: &crate::lower::model::ProgDef| Text::from(format!("\n.program<{}>(\"{}\")", &p_.name, &p_.prism)))));
                        call_value(each_job(model.checks.clone(), {
                            let crate_ = crate_.clone();
                            Rc::new(move |p0: crate::lower::model::CheckDef| {
                                let crate_ = crate_.clone();
                                entered(once_job(move || {
                                    let c = p0;
                                    call_value(each_job(c.lines.clone(), {
                                        let crate_ = crate_.clone();
                                        Rc::new(move |p0: crate::lower::model::Ex| {
                                            let crate_ = crate_.clone();
                                            entered(once_job(move || {
                                                let l = p0;
                                                prism_rtl::Turn::More(Rc::new(CppExpr { cp: crate_.clone(), x: l.clone() }))
                                            }))
                                        }) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>
                                    }), move |each_88400: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("\n.check(\"{}\", [] {{ return std::vector<Result<Pod>>{{{}}}; }})", &c.name, &crate::syntax::lexer::join(&each_88400, &Text::lit(", "))))))
                                }))
                            }) as Rc<dyn Fn(crate::lower::model::CheckDef) -> Rc<dyn prism_rtl::Job<Text>>>
                        }), move |each_88306: Array<Text>| {
                            let checks = concat(&each_88306);
                            let script_list = crate::syntax::lexer::join(&each(&scripts, &(|s: &Text| Text::from(format!("\"{}\",", &crate::lower::escape(s))))), &Text::lit("\n"));
                            let world = match &model.root {
                                Some(r) => r.world.clone(),
                                None => Text::lit("test"),
                            };
                            let canvas = &world == &Text::lit("canvas");
                            let run_root = match &model.root {
                                Some(r) => crate::emit::cpp::templates::cpp_run_root(&r.name, &(if canvas {
                                    crate::emit::cpp::templates::cpp_canvas_run(&r.name)
                                } else {
                                    crate::emit::cpp::templates::cpp_no_canvas(&r.name)
                                })),
                                None => crate::emit::cpp::templates::cpp_no_root(&model.name),
                            };
                            let both_ = join_parts(&elem, &answer);
                            let elem_decl = crate::emit::cpp::templates::cpp_elem_decl(&includes(&Text::lit("decl"), &append(&model.elem_complete, &model.elem_declared)), &crate::syntax::lexer::join(&both_.forward, &Text::lit("\n\n")), &crate::syntax::lexer::join(&both_.handles, &Text::lit("\n\n")), &crate::emit::cpp::prelude::cpp_prelude_rows(&Text::lit("")));
                            let elem_types = crate::emit::cpp::templates::cpp_elem_types(&crate::syntax::lexer::join(&filter(&Array::from(vec![includes(&Text::lit("types"), &model.elem_complete), includes(&Text::lit("decl"), &model.elem_declared)]), &(|t: &Text| t != &Text::lit(""))), &Text::lit("\n")), &crate::syntax::lexer::join(&both_.cases, &Text::lit("\n\n")));
                            let pairs = each(&crate::check::errors::range0(&len(&model.mods)), &(|i: &Nat| (or(&index(&model.mods, i), &no_mod()), or(&index(&mods, i), &no_parts()))));
                            let generics = fold(&pairs, &Array::new(), &(|acc: &Array<Text>, (m, p_): &(crate::lower::model::ModDef, Parts)| if &len(&p_.generic) > &Nat::from(0u32) { push(acc, &m.name) } else { acc.clone() }));
                            call_value(each_job(pairs.clone(), {
                                let generics = generics.clone();
                                Rc::new(move |p0: (crate::lower::model::ModDef, Parts)| {
                                    let generics = generics.clone();
                                    entered(once_job(move || {
                                        let (m, p_) = p0;
                                        prism_rtl::Turn::More(Rc::new(ModuleFiles { m: m.clone(), p_: p_.clone(), generics: generics.clone() }))
                                    }))
                                }) as Rc<dyn Fn((crate::lower::model::ModDef, Parts)) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>>>
                            }), move |each_89420: Array<Array<(Text, Text)>>| {
                                let per_module = each_89420;
                                let main_includes = crate::syntax::lexer::join(&append(&append(&Array::from(vec![Text::lit("#include \"elem.types.hpp\"")]), &Array::from(vec![includes(&Text::lit(""), &each(&model.mods, &(|m: &crate::lower::model::ModDef| m.name.clone())))])), &Array::from(vec![includes(&Text::lit("generic"), &generics)])), &Text::lit("\n"));
                                let canvas_include = if canvas {
                                    crate::emit::cpp::templates::cpp_canvas_include(&Text::lit(""))
                                } else {
                                    Text::lit("")
                                };
                                let main = crate::emit::cpp::templates::cpp_main(&model.name, &Text::from(format!("#include \"programs.hpp\"\n{}", &canvas_include)), &regs, &checks, &script_list, &world, &run_root, &crate::syntax::lexer::join(&concat2(&each(&Array::from(vec![elem.clone(), answer.clone()]), &(|p_: &Parts| p_.defs.clone()))), &Text::lit("\n\n")));
                                call_value(each_job(filter(&model.mods, &(|m: &crate::lower::model::ModDef| (&len(&m.types_with) > &Nat::from(1u32)) && (&or(&index(&m.types_with, &Nat::from(0u32)), &Text::lit("")) == &m.name))), {
                                    let pairs = pairs.clone();
                                    Rc::new(move |p0: crate::lower::model::ModDef| {
                                        let pairs = pairs.clone();
                                        entered(once_job(move || {
                                            let m = p0;
                                            prism_rtl::Turn::More(Rc::new(GroupTypesFile { pairs: pairs.clone(), group: m.types_with.clone() }))
                                        }))
                                    }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<(Text, Text)>>>
                                }), move |each_89910: Array<(Text, Text)>| {
                                    let groups = each_89910;
                                    let files = fold(&per_module, &Array::new(), &(|acc: &Array<(Text, Text)>, fs: &Array<(Text, Text)>| append(acc, fs)));
                                    let sources = crate::syntax::lexer::join(&filter(&each(&files, &(|(f, _): &(Text, Text)| f.clone())), &(|f: &Text| crate::syntax::lexer::contains(f, &Text::lit(".cpp")))), &Text::lit(" "));
                                    prism_rtl::Turn::Finished(append(&Array::from(vec![(Text::lit("Makefile"), crate::emit::cpp::templates::cpp_makefile(&model.name, &runtime, &sources, &(if canvas {
                                        crate::emit::cpp::templates::cpp_makefile_canvas(&runtime)
                                    } else {
                                        Text::lit("")
                                    }))), (Text::lit("src/elem.decl.hpp"), elem_decl.clone()), (Text::lit("src/elem.types.hpp"), elem_types.clone()), (Text::lit("src/programs.hpp"), crate::emit::cpp::templates::cpp_programs_header(&model.name, &main_includes, &programs)), (Text::lit("src/main.cpp"), main.clone()), (Text::lit("src/prelude.hpp"), crate::emit::cpp::prelude::cpp_prelude_source(&Text::lit("")))]), &append(&groups, &files)))
                                })
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start EmitCpp, x`: what the function value is when passed to `@Run`.
pub fn start_emit_cpp(model: crate::lower::model::Model, runtime: Text, scripts: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>> {
    Rc::new(EmitCpp { model, runtime, scripts })
}

/// ```prism
/// let noMod
/// ```
pub fn no_mod() -> crate::lower::model::ModDef {
    crate::lower::model::ModDef { name: Text::lit(""), prism: Text::lit(""), path_: Text::lit(""), uses: Array::new(), complete: Array::new(), declared: Array::new(), types_with: Array::new(), items: Array::new() }
}

/// ```prism
/// GroupTypesFile: unbounded fn [((ModDef, Parts))], [Text] -> ((Text, Text))
/// ```
pub fn group_types_file(pairs: &Array<(crate::lower::model::ModDef, Parts)>, group: &Array<Text>) -> (Text, Text) {
    let members_ = filter(pairs, &(|(m, _): &(crate::lower::model::ModDef, Parts)| among(group, &m.name)));
    let p_ = fold(&members_, &no_parts(), &(|acc: &Parts, (_, q): &(crate::lower::model::ModDef, Parts)| join_parts(acc, q)));
    let complete = fold(&members_, &Array::new(), &(|acc: &Array<Text>, (m, _): &(crate::lower::model::ModDef, Parts)| fold(&m.complete, acc, &(|a: &Array<Text>, n: &Text| if among(a, n) || among(group, n) { a.clone() } else { push(a, n) }))));
    let declared_ = fold(&members_, &Array::new(), &(|acc: &Array<Text>, (m, _): &(crate::lower::model::ModDef, Parts)| fold(&m.declared, acc, &(|a: &Array<Text>, n: &Text| if (among(a, n) || among(group, n)) || among(&complete, n) {
        a.clone()
    } else {
        push(a, n)
    }))));
    let title = Text::from(format!("The modules {}", &crate::syntax::lexer::join(&each(group, &(|n: &Text| Text::from(format!("`{}`", n)))), &Text::lit(", "))));
    (Text::from(format!("src/{}.types.hpp", &group_name(group))), types_header(&title, group, &declared_, &complete, &p_))
}

/// The step machine of `GroupTypesFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GroupTypesFile: unbounded fn [((ModDef, Parts))], [Text] -> ((Text, Text))
/// ```
pub struct GroupTypesFile {
    pub pairs: Array<(crate::lower::model::ModDef, Parts)>,
    pub group: Array<Text>,
}

impl prism_rtl::Job<(Text, Text)> for GroupTypesFile {
    fn cycle(&self) -> prism_rtl::Turn<(Text, Text)> {
        let pairs = &self.pairs;
        let group = &self.group;
        let members_ = filter(pairs, &(|(m, _): &(crate::lower::model::ModDef, Parts)| among(group, &m.name)));
        let p_ = fold(&members_, &no_parts(), &(|acc: &Parts, (_, q): &(crate::lower::model::ModDef, Parts)| join_parts(acc, q)));
        let complete = fold(&members_, &Array::new(), &(|acc: &Array<Text>, (m, _): &(crate::lower::model::ModDef, Parts)| fold(&m.complete, acc, &(|a: &Array<Text>, n: &Text| if among(a, n) || among(group, n) { a.clone() } else { push(a, n) }))));
        let declared_ = fold(&members_, &Array::new(), &(|acc: &Array<Text>, (m, _): &(crate::lower::model::ModDef, Parts)| fold(&m.declared, acc, &(|a: &Array<Text>, n: &Text| if (among(a, n) || among(group, n)) || among(&complete, n) {
            a.clone()
        } else {
            push(a, n)
        }))));
        let title = Text::from(format!("The modules {}", &crate::syntax::lexer::join(&each(group, &(|n: &Text| Text::from(format!("`{}`", n)))), &Text::lit(", "))));
        let group = group.clone();
        call_then(start_types_header(title.clone(), group.clone(), declared_.clone(), complete.clone(), p_.clone()), move |types_header_91548: Text| prism_rtl::Turn::Finished((Text::from(format!("src/{}.types.hpp", &group_name(&group))), types_header_91548)))
    }
}

/// `Start GroupTypesFile, x`: what the function value is when passed to `@Run`.
pub fn start_group_types_file(pairs: Array<(crate::lower::model::ModDef, Parts)>, group: Array<Text>) -> Rc<dyn prism_rtl::Job<(Text, Text)>> {
    Rc::new(GroupTypesFile { pairs, group })
}

/// ```prism
/// GroupName: fn [Text] -> Text
/// ```
pub fn group_name(group: &Array<Text>) -> Text {
    crate::syntax::lexer::join(&each(group, &(|n: &Text| crate::syntax::lexer::join(&split(n, &Text::lit("::")), &Text::lit("_")))), &Text::lit("-"))
}

/// ```prism
/// ModDir: fn Text -> Text
/// ```
pub fn mod_dir(m: &Text) -> Text {
    crate::syntax::lexer::join(&split(m, &Text::lit("::")), &Text::lit("/"))
}

/// ```prism
/// Among: fn [Text], Text -> Bool
/// ```
pub fn among(xs: &Array<Text>, x: &Text) -> bool {
    fold(xs, &false, &(|f: &bool, y: &Text| *f || (y == x)))
}

/// ```prism
/// TypesHeader: unbounded fn Text, [Text], [Text], [Text], Parts -> Text
/// ```
pub fn types_header(title: &Text, members_: &Array<Text>, declared_: &Array<Text>, complete: &Array<Text>, p_: &Parts) -> Text {
    let includes_ = crate::syntax::lexer::join(&filter(&Array::from(vec![includes(&Text::lit("decl"), members_), Text::lit("#include \"elem.decl.hpp\""), includes(&Text::lit("decl"), declared_), includes(&Text::lit("types"), complete)]), &(|t: &Text| t != &Text::lit(""))), &Text::lit("\n"));
    let values_ = crate::syntax::lexer::join(&order_values(&p_.values, &fold(&p_.values, &Map::new(), &(|acc: &Map<Text, bool>, v_: &ValueDecl| insert(acc, &v_.path_, &false))), &Array::new()), &Text::lit("\n\n"));
    crate::emit::cpp::templates::cpp_types_header(title, &includes_, &values_, &crate::syntax::lexer::join(&p_.cases, &Text::lit("\n\n")))
}

/// The step machine of `TypesHeader`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypesHeader: unbounded fn Text, [Text], [Text], [Text], Parts -> Text
/// ```
pub struct TypesHeader {
    pub title: Text,
    pub members_: Array<Text>,
    pub declared_: Array<Text>,
    pub complete: Array<Text>,
    pub p_: Parts,
}

impl prism_rtl::Job<Text> for TypesHeader {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let title = &self.title;
        let members_ = &self.members_;
        let declared_ = &self.declared_;
        let complete = &self.complete;
        let p_ = &self.p_;
        let includes_ = crate::syntax::lexer::join(&filter(&Array::from(vec![includes(&Text::lit("decl"), members_), Text::lit("#include \"elem.decl.hpp\""), includes(&Text::lit("decl"), declared_), includes(&Text::lit("types"), complete)]), &(|t: &Text| t != &Text::lit(""))), &Text::lit("\n"));
        let p_ = p_.clone();
        let title = title.clone();
        call_then(start_order_values(p_.values.clone(), fold(&p_.values, &Map::new(), &(|acc: &Map<Text, bool>, v_: &ValueDecl| insert(acc, &v_.path_, &false))), Array::new()), move |order_values_92643: Array<Text>| {
            let values_ = crate::syntax::lexer::join(&order_values_92643, &Text::lit("\n\n"));
            prism_rtl::Turn::Finished(crate::emit::cpp::templates::cpp_types_header(&title, &includes_, &values_, &crate::syntax::lexer::join(&p_.cases, &Text::lit("\n\n"))))
        })
    }
}

/// `Start TypesHeader, x`: what the function value is when passed to `@Run`.
pub fn start_types_header(title: Text, members_: Array<Text>, declared_: Array<Text>, complete: Array<Text>, p_: Parts) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TypesHeader { title, members_, declared_, complete, p_ })
}

/// ```prism
/// Includes: fn Text, [Text] -> Text
/// ```
pub fn includes(layer: &Text, ms: &Array<Text>) -> Text {
    crate::syntax::lexer::join(&each(ms, &(|m: &Text| Text::from(format!("#include <{}/{}.hpp>", &mod_dir(m), &(if layer == &Text::lit("") { Text::lit("module") } else { layer.clone() }))))), &Text::lit("\n"))
}

/// ```prism
/// Chunks: fn [Text] -> [ [Text] ]
/// ```
pub fn chunks(defs: &Array<Text>) -> Array<Array<Text>> {
    let (done, current, size_) = fold(defs, &(Array::new(), Array::new(), Nat::from(0u32)), &(|(acc, cur, n): &(Array<Array<Text>>, Array<Text>, Nat), d: &Text| if (n > &chunk_size()) && (&len(cur) > &Nat::from(0u32)) {
        (push(acc, cur), Array::from(vec![d.clone()]), len_text(d))
    } else {
        (acc.clone(), push(cur, d), n + &len_text(d))
    }));
    if (&len(&current) == &Nat::from(0u32)) && (&len(&done) > &Nat::from(0u32)) {
        done.clone()
    } else {
        push(&done, &current)
    }
}

/// ```prism
/// let chunkSize
/// ```
pub fn chunk_size() -> Nat {
    Nat::from(250000u32)
}

/// ```prism
/// ModuleFiles: unbounded fn ModDef, Parts, [Text] -> [((Text, Text))]
/// ```
pub fn module_files(m: &crate::lower::model::ModDef, p_: &Parts, generics: &Array<Text>) -> Array<(Text, Text)> {
    let title = if &m.prism == &Text::lit("") {
        Text::lit("The root module")
    } else {
        Text::from(format!("The module `{}`", &m.prism))
    };
    let needed = append(&m.complete, &m.declared);
    let decl = crate::emit::cpp::templates::cpp_decl_header(&title, &Text::lit(""), &crate::syntax::lexer::join(&p_.forward, &Text::lit("\n\n")), &crate::syntax::lexer::join(&p_.handles, &Text::lit("\n\n")));
    let types = if &len(&m.types_with) > &Nat::from(1u32) {
        crate::emit::cpp::templates::cpp_types_in_group(&title, &group_name(&m.types_with))
    } else {
        types_header(&title, &Array::from(vec![m.name.clone()]), &m.declared, &m.complete, p_)
    };
    let head_includes = crate::syntax::lexer::join(&filter(&Array::from(vec![Text::from(format!("{}\n#include \"elem.types.hpp\"", &includes(&Text::lit("types"), &Array::from(vec![m.name.clone()])))), includes(&Text::lit("types"), &needed)]), &(|t: &Text| t != &Text::lit(""))), &Text::lit("\n"));
    let head = crate::emit::cpp::templates::cpp_mod_header(&title, &head_includes, &crate::syntax::lexer::join(&p_.protos, &Text::lit("\n")), &crate::syntax::lexer::join(&p_.outer, &Text::lit("\n\n")), &crate::syntax::lexer::join(&p_.classes, &Text::lit("\n\n")));
    let with_mine = append(&Array::from(vec![m.name.clone()]), &needed);
    let generic = if &len(&p_.generic) == &Nat::from(0u32) {
        Array::new()
    } else {
        Array::from(vec![(Text::from(format!("src/{}/generic.hpp", &mod_dir(&m.name))), crate::emit::cpp::templates::cpp_generic_header(&title, &includes(&Text::lit(""), &with_mine), &crate::syntax::lexer::join(&p_.generic, &Text::lit("\n\n"))))])
    };
    let body_includes = crate::syntax::lexer::join(&filter(&Array::from(vec![includes(&Text::lit(""), &with_mine), includes(&Text::lit("generic"), &filter(&with_mine, &(|n: &Text| among(generics, n))))]), &(|t: &Text| t != &Text::lit(""))), &Text::lit("\n"));
    let chunks_ = chunks(&p_.defs);
    let sources = each(&crate::check::errors::range0(&len(&chunks_)), &(|k: &Nat| (chunk_file(&m.name, k), crate::emit::cpp::templates::cpp_module(&title, &m.path_, &m.name, &body_includes, &crate::syntax::lexer::join(&or(&index(&chunks_, k), &Array::new()), &Text::lit("\n\n"))))));
    let dir = mod_dir(&m.name);
    append(&append(&Array::from(vec![(Text::from(format!("src/{}/decl.hpp", &dir)), decl.clone()), (Text::from(format!("src/{}/types.hpp", &dir)), types.clone()), (Text::from(format!("src/{}/module.hpp", &dir)), head.clone())]), &generic), &sources)
}

/// The step machine of `ModuleFiles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModuleFiles: unbounded fn ModDef, Parts, [Text] -> [((Text, Text))]
/// ```
pub struct ModuleFiles {
    pub m: crate::lower::model::ModDef,
    pub p_: Parts,
    pub generics: Array<Text>,
}

impl prism_rtl::Job<Array<(Text, Text)>> for ModuleFiles {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Text, Text)>> {
        let m = &self.m;
        let p_ = &self.p_;
        let generics = &self.generics;
        let title = if &m.prism == &Text::lit("") {
            Text::lit("The root module")
        } else {
            Text::from(format!("The module `{}`", &m.prism))
        };
        let needed = append(&m.complete, &m.declared);
        let decl = crate::emit::cpp::templates::cpp_decl_header(&title, &Text::lit(""), &crate::syntax::lexer::join(&p_.forward, &Text::lit("\n\n")), &crate::syntax::lexer::join(&p_.handles, &Text::lit("\n\n")));
        let types = if &len(&m.types_with) > &Nat::from(1u32) {
            crate::emit::cpp::templates::cpp_types_in_group(&title, &group_name(&m.types_with))
        } else {
            types_header(&title, &Array::from(vec![m.name.clone()]), &m.declared, &m.complete, p_)
        };
        let head_includes = crate::syntax::lexer::join(&filter(&Array::from(vec![Text::from(format!("{}\n#include \"elem.types.hpp\"", &includes(&Text::lit("types"), &Array::from(vec![m.name.clone()])))), includes(&Text::lit("types"), &needed)]), &(|t: &Text| t != &Text::lit(""))), &Text::lit("\n"));
        let head = crate::emit::cpp::templates::cpp_mod_header(&title, &head_includes, &crate::syntax::lexer::join(&p_.protos, &Text::lit("\n")), &crate::syntax::lexer::join(&p_.outer, &Text::lit("\n\n")), &crate::syntax::lexer::join(&p_.classes, &Text::lit("\n\n")));
        let with_mine = append(&Array::from(vec![m.name.clone()]), &needed);
        let generic = if &len(&p_.generic) == &Nat::from(0u32) {
            Array::new()
        } else {
            Array::from(vec![(Text::from(format!("src/{}/generic.hpp", &mod_dir(&m.name))), crate::emit::cpp::templates::cpp_generic_header(&title, &includes(&Text::lit(""), &with_mine), &crate::syntax::lexer::join(&p_.generic, &Text::lit("\n\n"))))])
        };
        let body_includes = crate::syntax::lexer::join(&filter(&Array::from(vec![includes(&Text::lit(""), &with_mine), includes(&Text::lit("generic"), &filter(&with_mine, &(|n: &Text| among(generics, n))))]), &(|t: &Text| t != &Text::lit(""))), &Text::lit("\n"));
        let chunks_ = chunks(&p_.defs);
        let sources = each(&crate::check::errors::range0(&len(&chunks_)), &(|k: &Nat| (chunk_file(&m.name, k), crate::emit::cpp::templates::cpp_module(&title, &m.path_, &m.name, &body_includes, &crate::syntax::lexer::join(&or(&index(&chunks_, k), &Array::new()), &Text::lit("\n\n"))))));
        let dir = mod_dir(&m.name);
        prism_rtl::Turn::Finished(append(&append(&Array::from(vec![(Text::from(format!("src/{}/decl.hpp", &dir)), decl.clone()), (Text::from(format!("src/{}/types.hpp", &dir)), types.clone()), (Text::from(format!("src/{}/module.hpp", &dir)), head.clone())]), &generic), &sources))
    }
}

/// `Start ModuleFiles, x`: what the function value is when passed to `@Run`.
pub fn start_module_files(m: crate::lower::model::ModDef, p_: Parts, generics: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>> {
    Rc::new(ModuleFiles { m, p_, generics })
}

/// ```prism
/// ChunkFile: fn Text, Nat -> Text
/// ```
pub fn chunk_file(m: &Text, k: &Nat) -> Text {
    if k == &Nat::from(0u32) {
        Text::from(format!("src/{}/mod.cpp", &mod_dir(m)))
    } else {
        Text::from(format!("src/{}/mod_{}.cpp", &mod_dir(m), &(k + &Nat::from(1u32))))
    }
}

/// ```prism
/// AllProgramsCpp: fn Model -> [ProgDef]
/// ```
pub fn all_programs_cpp(model: &crate::lower::model::Model) -> Array<crate::lower::model::ProgDef> {
    match &model.root {
        Some(r) => if fold(&model.programs, &false, &(|f: &bool, p_: &crate::lower::model::ProgDef| *f || (&p_.name == &r.name))) {
            model.programs.clone()
        } else {
            push(&model.programs, r)
        },
        None => model.programs.clone(),
    }
}

/// ```prism
/// OrderValues: unbounded fn [ValueDecl], (Text ==> Bool), [Text] -> [Text]
/// ```
pub fn order_values(left: &Array<ValueDecl>, done: &Map<Text, bool>, acc: &Array<Text>) -> Array<Text> {
    let ready = filter(left, &(|v_: &ValueDecl| fold(&v_.deps, &true, &(|ok: &bool, d: &Text| *ok && ((d == &v_.path_) || declared(done, d))))));
    if &len(left) == &Nat::from(0u32) {
        acc.clone()
    } else {
        if &len(&ready) == &Nat::from(0u32) {
            append(acc, &each(left, &(|v_: &ValueDecl| v_.text.clone())))
        } else {
            {
                let later_ = filter(left, &(|v_: &ValueDecl| !fold(&v_.deps, &true, &(|ok: &bool, d: &Text| *ok && ((d == &v_.path_) || declared(done, d))))));
                let done2 = fold(&ready, done, &(|m: &Map<Text, bool>, v_: &ValueDecl| insert(m, &v_.path_, &true)));
                order_values(&later_, &done2, &append(acc, &each(&ready, &(|v_: &ValueDecl| v_.text.clone()))))
            }
        }
    }
}

/// The step machine of `OrderValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OrderValues: unbounded fn [ValueDecl], (Text ==> Bool), [Text] -> [Text]
/// ```
pub struct OrderValues {
    pub left: Array<ValueDecl>,
    pub done: Map<Text, bool>,
    pub acc: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for OrderValues {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let left = &self.left;
        let done = &self.done;
        let acc = &self.acc;
        let ready = filter(left, &(|v_: &ValueDecl| fold(&v_.deps, &true, &(|ok: &bool, d: &Text| *ok && ((d == &v_.path_) || declared(done, d))))));
        if &len(left) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished(acc.clone())
        } else {
            if &len(&ready) == &Nat::from(0u32) {
                prism_rtl::Turn::Finished(append(acc, &each(left, &(|v_: &ValueDecl| v_.text.clone()))))
            } else {
                {
                    let later_ = filter(left, &(|v_: &ValueDecl| !fold(&v_.deps, &true, &(|ok: &bool, d: &Text| *ok && ((d == &v_.path_) || declared(done, d))))));
                    let done2 = fold(&ready, done, &(|m: &Map<Text, bool>, v_: &ValueDecl| insert(m, &v_.path_, &true)));
                    prism_rtl::Turn::More(Rc::new(OrderValues { left: later_.clone(), done: done2.clone(), acc: append(acc, &each(&ready, &(|v_: &ValueDecl| v_.text.clone()))) }))
                }
            }
        }
    }
}

/// `Start OrderValues, x`: what the function value is when passed to `@Run`.
pub fn start_order_values(left: Array<ValueDecl>, done: Map<Text, bool>, acc: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(OrderValues { left, done, acc })
}

/// ```prism
/// Declared: fn (Text ==> Bool), Text -> Bool
/// ```
pub fn declared(done: &Map<Text, bool>, d: &Text) -> bool {
    match get(done, d) {
        Some(b) => b,
        None => true,
    }
}
