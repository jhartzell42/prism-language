//! The module `Emit.Cpp`, from `target/bootstrap/src/prismc/emit/cpp/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod expr;
pub mod items;
pub mod patterns;
pub mod prelude;
pub mod program;
pub mod stmts;
pub mod templates;

/// `Cp`:
///
/// ```prism
/// type Cp = record:
/// ```
#[derive(Clone)]
pub struct Cp {
    pub home_p: Text,
    pub mods_p: Array<Text>,
    pub types_p: Map<Text, TyInfo>,
    pub ctors_p: Map<Text, Text>,
    pub members_p: Map<Text, bool>,
    pub methods_p: Map<Text, bool>,
    pub field_names_p: Map<Text, bool>,
    pub fns_p: Map<Text, bool>,
    pub fields_p: Map<Text, crate::lower::model::OutTy>,
    pub pointers_p: Map<Text, bool>,
    pub owned_p: Map<Text, bool>,
    pub move_captures_p: Array<Text>,
    pub local_types_p: Map<Text, crate::lower::model::OutTy>,
}

impl ToPod for Cp {
    fn to_pod(&self) -> Pod {
        Pod::record("Cp", vec![("home", self.home_p.to_pod()), ("mods", self.mods_p.to_pod()), ("types", self.types_p.to_pod()), ("ctors", self.ctors_p.to_pod()), ("members", self.members_p.to_pod()), ("methods", self.methods_p.to_pod()), ("fieldNames", self.field_names_p.to_pod()), ("fns", self.fns_p.to_pod()), ("fields", self.fields_p.to_pod()), ("pointers", self.pointers_p.to_pod()), ("owned", self.owned_p.to_pod()), ("moveCaptures", self.move_captures_p.to_pod()), ("localTypes", self.local_types_p.to_pod())])
    }
}

impl FromPod for Cp {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Cp { home_p: FromPod::from_pod(field(p, "home")?)?, mods_p: FromPod::from_pod(field(p, "mods")?)?, types_p: FromPod::from_pod(field(p, "types")?)?, ctors_p: FromPod::from_pod(field(p, "ctors")?)?, members_p: FromPod::from_pod(field(p, "members")?)?, methods_p: FromPod::from_pod(field(p, "methods")?)?, field_names_p: FromPod::from_pod(field(p, "fieldNames")?)?, fns_p: FromPod::from_pod(field(p, "fns")?)?, fields_p: FromPod::from_pod(field(p, "fields")?)?, pointers_p: FromPod::from_pod(field(p, "pointers")?)?, owned_p: FromPod::from_pod(field(p, "owned")?)?, move_captures_p: FromPod::from_pod(field(p, "moveCaptures")?)?, local_types_p: FromPod::from_pod(field(p, "localTypes")?)? })
    }
}

/// `TyInfo`:
///
/// ```prism
/// type TyInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TyInfo {
    pub kind_p: Text,
    pub fields_p: Array<Text>,
    pub params_p: Array<Text>,
}

impl Show for TyInfo {
    fn show(&self, p: &mut Printer) {
        p.record("TyInfo", &[("kind", &self.kind_p), ("fields", &self.fields_p), ("params", &self.params_p)]);
    }
}

impl ToPod for TyInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("TyInfo", vec![("kind", self.kind_p.to_pod()), ("fields", self.fields_p.to_pod()), ("params", self.params_p.to_pod())])
    }
}

impl FromPod for TyInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TyInfo { kind_p: FromPod::from_pod(field(p, "kind")?)?, fields_p: FromPod::from_pod(field(p, "fields")?)?, params_p: FromPod::from_pod(field(p, "params")?)? })
    }
}

/// ```prism
/// CppId: fn Text -> Text
/// ```
pub fn cpp_id_f(n_p0: &Text) -> Text {
    if in_list_f(&crate::lower::cpp_keywords_p(), n_p0) {
        Text::from(format!("{}_", n_p0))
    } else {
        n_p0.clone()
    }
}

/// ```prism
/// FieldId: fn Text -> Text
/// ```
pub fn field_id_f(f_p0: &Text) -> Text {
    cpp_id_f(f_p0)
}

/// ```prism
/// CppPathId: fn Text -> Text
/// ```
pub fn cpp_path_id_f(p_p0: &Text) -> Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::prelude::split_on(p_p0, &Text::lit("::")), &(|s_p1: &Text| cpp_id_f(s_p1))), &Text::lit("::"))
}

/// ```prism
/// InList: fn [Text], Text -> Bool
/// ```
pub fn in_list_f(xs_p0: &Array<Text>, x_p1: &Text) -> bool {
    crate::prelude::fold(xs_p0, &false, &(|seen_p2: &bool, y_p3: &Text| *seen_p2 || (y_p3 == x_p1)))
}

/// ```prism
/// Absolute: fn Cp, Text -> Text
/// ```
pub fn absolute_f(cp_p0: &Cp, p_p1: &Text) -> Text {
    let q_p2 = crate::syntax::lexer::chars::drop_prefix_f(p_p1, &Text::lit("crate::"));
    if crate::prelude::fold(&cp_p0.mods_p, &false, &(|f_p3: &bool, m_p4: &Text| *f_p3 || crate::syntax::lexer::chars::has_prefix_f(&q_p2, &Text::from(format!("{}::", m_p4))))) {
        q_p2.clone()
    } else {
        Text::from(format!("{}::{}", &cp_p0.home_p, &q_p2))
    }
}

/// ```prism
/// ?TypeOf: fn Cp, Text -> ?TyInfo
/// ```
pub fn type_of_o(cp_p0: &Cp, p_p1: &Text) -> Option<TyInfo> {
    let q_p2 = crate::syntax::lexer::chars::drop_prefix_f(p_p1, &Text::lit("crate::"));
    match crate::prelude::get(&cp_p0.types_p, &absolute_f(cp_p0, &q_p2)) {
        Some(t_p3) => Some(t_p3),
        None => match crate::prelude::get(&cp_p0.types_p, &Text::from(format!("prelude::{}", &q_p2))) {
            Some(t_p4) => Some(t_p4),
            None => crate::prelude::get(&cp_p0.types_p, &q_p2),
        },
    }
}

/// ```prism
/// ?CaseOf: fn Cp, Text -> ?Text
/// ```
pub fn case_of_o(cp_p0: &Cp, p_p1: &Text) -> Option<Text> {
    let q_p2 = crate::syntax::lexer::chars::drop_prefix_f(p_p1, &Text::lit("crate::"));
    match crate::prelude::get(&cp_p0.ctors_p, &absolute_f(cp_p0, &q_p2)) {
        Some(_) => Some(parent_path_f(p_p1)),
        None => match crate::prelude::get(&cp_p0.ctors_p, &Text::from(format!("prelude::{}", &q_p2))) {
            Some(_) => Some(parent_path_f(p_p1)),
            None => match crate::prelude::get(&cp_p0.ctors_p, &q_p2) {
                Some(_) => Some(parent_path_f(p_p1)),
                None => None,
            },
        },
    }
}

/// ```prism
/// ParentPath: fn Text -> Text
/// ```
pub fn parent_path_f(p_p0: &Text) -> Text {
    let segs_p1 = crate::prelude::split_on(p_p0, &Text::lit("::"));
    crate::syntax::lexer::chars::join_f(&crate::prelude::take(&segs_p1, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&segs_p1))), &Text::lit("::"))
}

/// ```prism
/// LastSegment: fn Text -> Text
/// ```
pub fn last_segment_f(p_p0: &Text) -> Text {
    crate::prelude::or(&crate::syntax::lexer::chars::last_o(&crate::prelude::split_on(p_p0, &Text::lit("::"))), p_p0)
}

/// ```prism
/// Context: fn Model -> Cp
/// ```
pub fn context_f(model_p0: &crate::lower::model::Model) -> Cp {
    let names_p1 = crate::prelude::each(&model_p0.mods_p, &(|m_p6: &crate::lower::model::ModDef| m_p6.name_p.clone()));
    let tops_p2 = crate::prelude::fold(&names_p1, &Array::new(), &(|acc_p7: &Array<Text>, n_p8: &Text| {
        let top_p9 = crate::prelude::or(&crate::prelude::index(&crate::prelude::split_on(n_p8, &Text::lit("::")), &Nat::from(0u32)), n_p8);
        if in_list_f(&names_p1, &top_p9) || in_list_f(acc_p7, &top_p9) {
            acc_p7.clone()
        } else {
            crate::prelude::push(acc_p7, &top_p9)
        }
    }));
    let mods_p3 = crate::prelude::push(&crate::prelude::append(&names_p1, &tops_p2), &Text::lit("prelude"));
    let base_p4 = Cp { home_p: Text::lit(""), mods_p: mods_p3.clone(), types_p: prelude_types_p(), ctors_p: prelude_ctors_p(), members_p: node_base_p(), methods_p: Map::new(), field_names_p: Map::new(), fns_p: Map::new(), fields_p: Map::new(), pointers_p: Map::new(), owned_p: Map::new(), move_captures_p: Array::new(), local_types_p: Map::new() };
    let with_elem_p5 = add_row_f(&add_answer_f(&base_p4, &model_p0.answer_p), &Text::lit(""), &model_p0.elem_p);
    crate::prelude::fold(&model_p0.mods_p, &with_elem_p5, &(|cp_pa: &Cp, m_pb: &crate::lower::model::ModDef| crate::prelude::fold(&m_pb.items_p, cp_pa, &(|c_pc: &Cp, it_pd: &crate::lower::model::Item| add_model_item_f(c_pc, &m_pb.name_p, it_pd)))))
}

/// ```prism
/// let preludeTypes
/// ```
pub fn prelude_types_p() -> Map<Text, TyInfo> {
    crate::prelude::map_of(vec![(Text::lit("prelude::Ordering"), TyInfo { kind_p: Text::lit("choice"), fields_p: Array::new(), params_p: Array::new() }), (Text::lit("prelude::Span"), TyInfo { kind_p: Text::lit("record"), fields_p: Array::from(vec![Text::lit("file_p"), Text::lit("line_p"), Text::lit("column_p"), Text::lit("binding_p")]), params_p: Array::new() }), (Text::lit("prelude::Exception"), TyInfo { kind_p: Text::lit("record"), fields_p: Array::from(vec![Text::lit("kind_p"), Text::lit("message_p"), Text::lit("spans_p"), Text::lit("path_o")]), params_p: Array::new() }), (Text::lit("prelude::Duration"), TyInfo { kind_p: Text::lit("newtype"), fields_p: Array::new(), params_p: Array::new() }), (Text::lit("prelude::PreludeUnwrap"), TyInfo { kind_p: Text::lit("tag"), fields_p: Array::new(), params_p: Array::new() }), (Text::lit("prelude::PreludeExceptions"), TyInfo { kind_p: Text::lit("tag"), fields_p: Array::new(), params_p: Array::new() })])
}

/// ```prism
/// let preludeCtors
/// ```
pub fn prelude_ctors_p() -> Map<Text, Text> {
    crate::prelude::map_of(vec![(Text::lit("prelude::Ordering::Less"), Text::lit("choice")), (Text::lit("prelude::Ordering::Equal"), Text::lit("choice")), (Text::lit("prelude::Ordering::Greater"), Text::lit("choice"))])
}

/// ```prism
/// let nodeBase
/// ```
pub fn node_base_p() -> Map<Text, bool> {
    crate::prelude::map_of(vec![(Text::lit("make"), true), (Text::lit("push"), true), (Text::lit("wake"), true), (Text::lit("started"), true), (Text::lit("deferred"), true), (Text::lit("build"), true), (Text::lit("swap"), true), (Text::lit("leave"), true), (Text::lit("patch"), true), (Text::lit("edges"), true), (Text::lit("release"), true), (Text::lit("clean_up"), true), (Text::lit("path"), true), (Text::lit("leave_row"), true), (Text::lit("answer"), true), (Text::lit("document"), true), (Text::lit("entries"), true), (Text::lit("deliver"), true), (Text::lit("document_moved"), true), (Text::lit("me"), true), (Text::lit("result_dynamic"), true)])
}

/// ```prism
/// AddModelItem: fn Cp, Text, Item -> Cp
/// ```
pub fn add_model_item_f(cp_p0: &Cp, m_p1: &Text, it_p2: &crate::lower::model::Item) -> Cp {
    match it_p2 {
        crate::lower::model::Item::ItType(t_p3) => add_type_f(cp_p0, m_p1, t_p3),
        crate::lower::model::Item::ItTag(t_p4) => add_ty_f(cp_p0, &Text::from(format!("{}::{}", m_p1, &t_p4.name_p)), &TyInfo { kind_p: Text::lit("tag"), fields_p: crate::prelude::each(&t_p4.fields_p, &(|(_, f_p5, _): &(Text, Text, crate::lower::model::OutTy)| f_p5.clone())), params_p: Array::new() }),
        crate::lower::model::Item::ItRow(r_p6) => add_row_f(cp_p0, m_p1, r_p6),
        crate::lower::model::Item::ItJob(j_p7) => add_ty_f(cp_p0, &Text::from(format!("{}::{}", m_p1, &j_p7.name_p)), &TyInfo { kind_p: Text::lit("job"), fields_p: crate::prelude::each(&j_p7.fields_p, &(|(f_p8, _): &(Text, crate::lower::model::OutTy)| f_p8.clone())), params_p: crate::prelude::each(&j_p7.generics_p, &(|(g_p9, _): &(Text, Array<Text>)| g_p9.clone())) }),
        crate::lower::model::Item::ItNode(n_pa) => add_node_f(cp_p0, m_p1, n_pa),
        crate::lower::model::Item::ItFn(f_pb) => {
            let mut this: Cp = cp_p0.clone();
            this.fns_p = crate::prelude::insert(&this.fns_p, &Text::from(format!("{}::{}", m_p1, &f_pb.name_p)), &true);
            this
        },
        _ => cp_p0.clone(),
    }
}

/// ```prism
/// AddTy: fn Cp, Text, TyInfo -> Cp
/// ```
pub fn add_ty_f(cp_p0: &Cp, path_p1: &Text, info_p2: &TyInfo) -> Cp {
    let mut this: Cp = cp_p0.clone();
    this.types_p = crate::prelude::insert(&this.types_p, path_p1, info_p2);
    this
}

/// ```prism
/// AddCtor: fn Cp, Text, Text -> Cp
/// ```
pub fn add_ctor_f(cp_p0: &Cp, path_p1: &Text, kind_p2: &Text) -> Cp {
    let mut this: Cp = cp_p0.clone();
    this.ctors_p = crate::prelude::insert(&this.ctors_p, path_p1, kind_p2);
    this
}

/// ```prism
/// AddMember: fn Cp, Text -> Cp
/// ```
pub fn add_member_f(cp_p0: &Cp, name_p1: &Text) -> Cp {
    let mut this: Cp = cp_p0.clone();
    this.members_p = crate::prelude::insert(&this.members_p, name_p1, &true);
    this
}

/// ```prism
/// AddType: fn Cp, Text, TyDef -> Cp
/// ```
pub fn add_type_f(cp_p0: &Cp, m_p1: &Text, t_p2: &crate::lower::model::TyDef) -> Cp {
    let path_p3 = Text::from(format!("{}::{}", m_p1, &t_p2.name_p));
    let first_p4 = crate::prelude::or(&crate::prelude::index(&t_p2.cases_p, &Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: Text::lit(""), prism_p: Text::lit(""), fields_p: Array::new(), labels_p: Array::new() });
    match &t_p2.shape_p {
        crate::lower::model::TyShape::ShapeRecord => add_ty_f(cp_p0, &path_p3, &TyInfo { kind_p: Text::lit("record"), fields_p: crate::prelude::each(&first_p4.fields_p, &(|(f_p5, _): &(Text, crate::lower::model::OutTy)| f_p5.clone())), params_p: t_p2.params_p.clone() }),
        crate::lower::model::TyShape::ShapeNewtype => add_ty_f(cp_p0, &path_p3, &TyInfo { kind_p: Text::lit("newtype"), fields_p: Array::new(), params_p: t_p2.params_p.clone() }),
        crate::lower::model::TyShape::ShapeUnit => add_ty_f(cp_p0, &path_p3, &TyInfo { kind_p: Text::lit("unit"), fields_p: Array::new(), params_p: t_p2.params_p.clone() }),
        crate::lower::model::TyShape::ShapeChoice => crate::prelude::fold(&t_p2.cases_p, &add_ty_f(cp_p0, &path_p3, &TyInfo { kind_p: Text::lit("choice"), fields_p: Array::new(), params_p: t_p2.params_p.clone() }), &(|c_p6: &Cp, k_p7: &crate::lower::model::CaseDef| add_ctor_f(c_p6, &Text::from(format!("{}::{}", &path_p3, &k_p7.name_p)), &Text::lit("choice")))),
    }
}

/// ```prism
/// AddRow: fn Cp, Text, RowDef -> Cp
/// ```
pub fn add_row_f(cp_p0: &Cp, m_p1: &Text, r_p2: &crate::lower::model::RowDef) -> Cp {
    let path_p3 = if m_p1 == &Text::lit("") {
        r_p2.name_p.clone()
    } else {
        Text::from(format!("{}::{}", m_p1, &r_p2.name_p))
    };
    crate::prelude::fold(&r_p2.cases_p, &add_ty_f(cp_p0, &path_p3, &TyInfo { kind_p: Text::lit("choice"), fields_p: Array::new(), params_p: Array::new() }), &(|c_p4: &Cp, (v_p5, _): &(Text, Text)| add_ctor_f(c_p4, &Text::from(format!("{}::{}", &path_p3, v_p5)), &Text::lit("choice"))))
}

/// ```prism
/// AddAnswer: fn Cp, AnswerDef -> Cp
/// ```
pub fn add_answer_f(cp_p0: &Cp, a_p1: &crate::lower::model::AnswerDef) -> Cp {
    crate::prelude::fold(&a_p1.cases_p, &add_ty_f(cp_p0, &Text::lit("Answer"), &TyInfo { kind_p: Text::lit("choice"), fields_p: Array::new(), params_p: Array::new() }), &(|c_p2: &Cp, k_p3: &crate::lower::model::AnswerCase| add_ctor_f(c_p2, &Text::from(format!("Answer::{}", &k_p3.variant_p)), &Text::lit("choice"))))
}

/// ```prism
/// AddNode: fn Cp, Text, NodeDef -> Cp
/// ```
pub fn add_node_f(cp_p0: &Cp, m_p1: &Text, n_p2: &crate::lower::model::NodeDef) -> Cp {
    let with_fields_p3 = crate::prelude::fold(&n_p2.fields_p, cp_p0, &(|c_p7: &Cp, (f_p8, _, _): &(Text, crate::lower::model::OutTy, Text)| {
        let mut this: Cp = add_member_f(c_p7, f_p8);
        this.field_names_p = crate::prelude::insert(&this.field_names_p, f_p8, &true);
        this
    }));
    let with_methods_p4 = crate::prelude::fold(&crate::prelude::append(&n_p2.methods_p, &n_p2.hosted_p), &with_fields_p3, &(|c_p9: &Cp, md_pa: &crate::lower::model::MethDef| {
        let mut this: Cp = add_member_f(c_p9, &md_pa.name_p);
        this.methods_p = crate::prelude::insert(&this.methods_p, &md_pa.name_p, &true);
        this
    }));
    let with_builders_p5 = crate::prelude::fold(&n_p2.builders_p, &with_methods_p4, &(|c_pb: &Cp, b_pc: &crate::lower::model::ForDef| add_member_f(c_pb, &Text::from(format!("{}_build", &b_pc.name_p)))));
    let with_gens_p6 = crate::prelude::fold(&n_p2.gens_p, &with_builders_p5, &(|c_pd: &Cp, g_pe: &crate::lower::model::GenDef| add_member_f(c_pd, &Text::from(format!("{}_build", &g_pe.name_p)))));
    add_ty_f(&with_gens_p6, &Text::from(format!("{}::{}", m_p1, &n_p2.name_p)), &TyInfo { kind_p: Text::lit("node"), fields_p: crate::prelude::each(&n_p2.fields_p, &(|(f_pf, _, _): &(Text, crate::lower::model::OutTy, Text)| f_pf.clone())), params_p: Array::new() })
}

/// ```prism
/// InHome: fn Cp, Text -> Cp
/// ```
pub fn in_home_f(cp_p0: &Cp, m_p1: &Text) -> Cp {
    let mut this: Cp = cp_p0.clone();
    this.home_p = m_p1.clone();
    this
}

/// ```prism
/// WithFields: fn Cp, [((Text, OutTy))] -> Cp
/// ```
pub fn with_fields_f(cp_p0: &Cp, fs_p1: &Array<(Text, crate::lower::model::OutTy)>) -> Cp {
    let mut this: Cp = cp_p0.clone();
    this.fields_p = crate::prelude::fold(fs_p1, &Map::new(), &(|acc_p2: &Map<Text, crate::lower::model::OutTy>, (f_p3, t_p4): &(Text, crate::lower::model::OutTy)| crate::prelude::insert(acc_p2, f_p3, t_p4)));
    this
}

/// ```prism
/// CppType: unbounded fn Cp, OutTy -> Text
/// ```
pub fn cpp_type_f(cp_p0: &Cp, t_p1: &crate::lower::model::OutTy) -> Text {
    'm11530: {
        if let crate::lower::model::OutTy::OutNat = t_p1 {
            break 'm11530 Text::lit("Nat");
        }
        if let crate::lower::model::OutTy::OutInt = t_p1 {
            break 'm11530 Text::lit("Int");
        }
        if let crate::lower::model::OutTy::OutU8 = t_p1 {
            break 'm11530 Text::lit("std::uint8_t");
        }
        if let crate::lower::model::OutTy::OutFloat = t_p1 {
            break 'm11530 Text::lit("Float");
        }
        if let crate::lower::model::OutTy::OutBool = t_p1 {
            break 'm11530 Text::lit("bool");
        }
        if let crate::lower::model::OutTy::OutChar = t_p1 {
            break 'm11530 Text::lit("char32_t");
        }
        if let crate::lower::model::OutTy::OutText = t_p1 {
            break 'm11530 Text::lit("Text");
        }
        if let crate::lower::model::OutTy::OutCursor = t_p1 {
            break 'm11530 Text::lit("Cursor");
        }
        if let crate::lower::model::OutTy::OutRegex = t_p1 {
            break 'm11530 Text::lit("Regex");
        }
        if let crate::lower::model::OutTy::OutReplacement = t_p1 {
            break 'm11530 Text::lit("RegexReplacement");
        }
        if let crate::lower::model::OutTy::OutUnit = t_p1 {
            break 'm11530 Text::lit("Unit");
        }
        if let crate::lower::model::OutTy::OutPath = t_p1 {
            break 'm11530 Text::lit("Path");
        }
        if let crate::lower::model::OutTy::OutDuration = t_p1 {
            break 'm11530 Text::lit("Duration");
        }
        if let crate::lower::model::OutTy::OutError = t_p1 {
            break 'm11530 Text::lit("Error");
        }
        if let crate::lower::model::OutTy::OutNamed(m11530_14_0, m11530_14_1) = t_p1 && (m11530_14_0 == &Text::lit("Cell")) && (m11530_14_1.len() == 1) && let Some(i_p2) = crate::prelude::index(m11530_14_1, &Nat::from(0u32)) {
            break 'm11530 cpp_type_f(cp_p0, &i_p2);
        }
        if let crate::lower::model::OutTy::OutNamed(m11530_15_0, m11530_15_1) = t_p1 && (m11530_15_0 == &Text::lit("RefCell")) && (m11530_15_1.len() == 1) && let Some(i_p3) = crate::prelude::index(m11530_15_1, &Nat::from(0u32)) {
            break 'm11530 cpp_type_f(cp_p0, &i_p3);
        }
        if let crate::lower::model::OutTy::OutNamed(m11530_16_0, m11530_16_1) = t_p1 && (m11530_16_0 == &Text::lit("Vec")) && (m11530_16_1.len() == 1) && let Some(i_p4) = crate::prelude::index(m11530_16_1, &Nat::from(0u32)) {
            break 'm11530 Text::from(format!("std::vector<{}>", &cpp_type_f(cp_p0, &i_p4)));
        }
        if let crate::lower::model::OutTy::OutNamed(m11530_17_0, m11530_17_1) = t_p1 && (m11530_17_0 == &Text::lit("Result")) && (m11530_17_1.len() == 2) && let Some(a_p5) = crate::prelude::index(m11530_17_1, &Nat::from(0u32)) && let Some(b_p6) = crate::prelude::index(m11530_17_1, &Nat::from(1u32)) {
            break 'm11530 Text::from(format!("Expected<{}, {}>", &cpp_type_f(cp_p0, &a_p5), &cpp_type_f(cp_p0, &b_p6)));
        }
        if let crate::lower::model::OutTy::OutNamed(n_p7, m11530_18_1) = t_p1 && (m11530_18_1.len() == 0) {
            break 'm11530 own_type_path_f(cp_p0, n_p7);
        }
        if let crate::lower::model::OutTy::OutNamed(n_p8, args_p9) = t_p1 {
            break 'm11530 Text::from(format!("{}<{}>", &own_type_path_f(cp_p0, n_p8), &cpp_types_f(cp_p0, args_p9)));
        }
        if let crate::lower::model::OutTy::OutOpt(i_pa) = t_p1 {
            break 'm11530 Text::from(format!("std::optional<{}>", &cpp_type_f(cp_p0, &**i_pa)));
        }
        if let crate::lower::model::OutTy::OutRes(i_pb) = t_p1 {
            break 'm11530 Text::from(format!("Fallible<{}>", &cpp_type_f(cp_p0, &**i_pb)));
        }
        if let crate::lower::model::OutTy::OutTuple(ts_pc) = t_p1 {
            break 'm11530 Text::from(format!("std::tuple<{}>", &cpp_types_f(cp_p0, ts_pc)));
        }
        if let crate::lower::model::OutTy::OutArray(e_pd) = t_p1 {
            break 'm11530 Text::from(format!("Array<{}>", &cpp_type_f(cp_p0, &**e_pd)));
        }
        if let crate::lower::model::OutTy::OutMap(k_pe, v_pf) = t_p1 {
            break 'm11530 Text::from(format!("Map<{}, {}>", &cpp_type_f(cp_p0, &**k_pe), &cpp_type_f(cp_p0, &**v_pf)));
        }
        if let crate::lower::model::OutTy::OutFn(ps_pg, r_ph) = t_p1 {
            break 'm11530 Text::from(format!("Fn<{}({})>", &cpp_type_f(cp_p0, &**r_ph), &param_types_f(cp_p0, ps_pg)));
        }
        if let crate::lower::model::OutTy::OutRef(m11530_26_0) = t_p1 && let crate::lower::model::OutTy::OutFn(ps_pi, r_pj) = &**m11530_26_0 {
            break 'm11530 Text::from(format!("const std::function<{}({})>&", &cpp_type_f(cp_p0, &**r_pj), &param_types_f(cp_p0, ps_pi)));
        }
        if let crate::lower::model::OutTy::OutRef(m11530_27_0) = t_p1 && let crate::lower::model::OutTy::OutSlice(i_pk) = &**m11530_27_0 {
            break 'm11530 Text::from(format!("std::span<const {}>", &cpp_type_f(cp_p0, &**i_pk)));
        }
        if let crate::lower::model::OutTy::OutRef(i_pl) = t_p1 {
            break 'm11530 Text::from(format!("const {}&", &cpp_type_f(cp_p0, &**i_pl)));
        }
        if let crate::lower::model::OutTy::OutJobFn(a_pm, b_pn) = t_p1 {
            break 'm11530 Text::from(format!("prism_rtl::Fn<prism_rtl::JobRef<{}>({})>", &cpp_type_f(cp_p0, &**b_pn), &cpp_type_f(cp_p0, &**a_pm)));
        }
        if let crate::lower::model::OutTy::OutJob(b_po) = t_p1 {
            break 'm11530 Text::from(format!("prism_rtl::JobRef<{}>", &cpp_type_f(cp_p0, &**b_po)));
        }
        if let crate::lower::model::OutTy::OutEvent(i_pp) = t_p1 {
            break 'm11530 Text::from(format!("Event<{}>", &cpp_type_f(cp_p0, &**i_pp)));
        }
        if let crate::lower::model::OutTy::OutDyn(i_pq) = t_p1 {
            break 'm11530 Text::from(format!("Dynamic<{}>", &cpp_type_f(cp_p0, &**i_pq)));
        }
        if let crate::lower::model::OutTy::OutGen(n_pr) = t_p1 {
            break 'm11530 n_pr.clone();
        }
        if let crate::lower::model::OutTy::OutRc(i_ps) = t_p1 {
            break 'm11530 if is_value_ty_f(cp_p0, &**i_ps) {
                Text::from(format!("prism_rtl::Rc<const {}>", &cpp_type_f(cp_p0, &**i_ps)))
            } else {
                Text::from(format!("prism_rtl::Rc<{}>", &cpp_type_f(cp_p0, &**i_ps)))
            };
        }
        if let crate::lower::model::OutTy::OutPod = t_p1 {
            break 'm11530 Text::lit("Pod");
        }
        if let crate::lower::model::OutTy::OutShowAny = t_p1 {
            break 'm11530 Text::lit("prism_rtl::Rc<const DynShow>");
        }
        if let crate::lower::model::OutTy::OutHold(i_pt) = t_p1 {
            break 'm11530 Text::from(format!("Hold<{}>", &cpp_type_f(cp_p0, &**i_pt)));
        }
        if let crate::lower::model::OutTy::OutStamped(i_pu) = t_p1 {
            break 'm11530 Text::from(format!("Stamped<{}>", &cpp_type_f(cp_p0, &**i_pu)));
        }
        if let crate::lower::model::OutTy::OutSnapshot(i_pv) = t_p1 {
            break 'm11530 Text::from(format!("Snapshot<{}>", &cpp_type_f(cp_p0, &**i_pv)));
        }
        if let crate::lower::model::OutTy::OutDefer(i_p10) = t_p1 {
            break 'm11530 Text::from(format!("Defer<{}>", &cpp_type_f(cp_p0, &**i_p10)));
        }
        if let crate::lower::model::OutTy::OutWeak(n_p11) = t_p1 {
            break 'm11530 Text::from(format!("prism_rtl::Weak<{}>", &type_path_f(n_p11)));
        }
        if let crate::lower::model::OutTy::OutCell(i_p12) = t_p1 {
            break 'm11530 cpp_type_f(cp_p0, &**i_p12);
        }
        if let crate::lower::model::OutTy::OutWakes = t_p1 {
            break 'm11530 Text::lit("Wakes");
        }
        if let crate::lower::model::OutTy::OutCount = t_p1 {
            break 'm11530 Text::lit("std::uint32_t");
        }
        if let crate::lower::model::OutTy::OutObj(i_p13) = t_p1 {
            break 'm11530 Text::from(format!("prism_rtl::Rc<{}>", &cpp_type_f(cp_p0, &**i_p13)));
        }
        if let crate::lower::model::OutTy::OutSlice(i_p14) = t_p1 {
            break 'm11530 Text::from(format!("std::span<const {}>", &cpp_type_f(cp_p0, &**i_p14)));
        }
        if let crate::lower::model::OutTy::OutPort(i_p15) = t_p1 {
            break 'm11530 Text::from(format!("Port<{}>", &cpp_type_f(cp_p0, &**i_p15)));
        }
        if let crate::lower::model::OutTy::OutLive(i_p16) = t_p1 {
            break 'm11530 Text::from(format!("Live<{}>", &cpp_type_f(cp_p0, &**i_p16)));
        }
        if let crate::lower::model::OutTy::OutTurn = t_p1 {
            break 'm11530 Text::lit("decltype(this->cycle())");
        }
        if let crate::lower::model::OutTy::OutRefused(what_p17) = t_p1 {
            break 'm11530 Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::expr::lowering_refusal_p(), what_p17));
        }
        if let crate::lower::model::OutTy::OutQuantified(b_p18) = t_p1 {
            break 'm11530 Text::from(format!("compile_error!(\"{}a quantified type variable of `{}`: no instantiation gives it a type\")", &crate::lower::expr::lowering_refusal_p(), b_p18));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `CppType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppType: unbounded fn Cp, OutTy -> Text
/// ```
pub struct CppType {
    pub cp_p0: Cp,
    pub t_p1: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for CppType {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        'm11530: {
            if let crate::lower::model::OutTy::OutNat = t_p1 {
                break 'm11530 prism_rtl::Turn::Finished(Text::lit("Nat"));
            }
            if let crate::lower::model::OutTy::OutInt = t_p1 {
                break 'm11530 prism_rtl::Turn::Finished(Text::lit("Int"));
            }
            if let crate::lower::model::OutTy::OutU8 = t_p1 {
                break 'm11530 prism_rtl::Turn::Finished(Text::lit("std::uint8_t"));
            }
            if let crate::lower::model::OutTy::OutFloat = t_p1 {
                break 'm11530 prism_rtl::Turn::Finished(Text::lit("Float"));
            }
            if let crate::lower::model::OutTy::OutBool = t_p1 {
                break 'm11530 prism_rtl::Turn::Finished(Text::lit("bool"));
            }
            if let crate::lower::model::OutTy::OutChar = t_p1 {
                break 'm11530 prism_rtl::Turn::Finished(Text::lit("char32_t"));
            }
            if let crate::lower::model::OutTy::OutText = t_p1 {
                break 'm11530 prism_rtl::Turn::Finished(Text::lit("Text"));
            }
            if let crate::lower::model::OutTy::OutCursor = t_p1 {
                break 'm11530 prism_rtl::Turn::Finished(Text::lit("Cursor"));
            }
            if let crate::lower::model::OutTy::OutRegex = t_p1 {
                break 'm11530 prism_rtl::Turn::Finished(Text::lit("Regex"));
            }
            if let crate::lower::model::OutTy::OutReplacement = t_p1 {
                break 'm11530 prism_rtl::Turn::Finished(Text::lit("RegexReplacement"));
            }
            if let crate::lower::model::OutTy::OutUnit = t_p1 {
                break 'm11530 prism_rtl::Turn::Finished(Text::lit("Unit"));
            }
            if let crate::lower::model::OutTy::OutPath = t_p1 {
                break 'm11530 prism_rtl::Turn::Finished(Text::lit("Path"));
            }
            if let crate::lower::model::OutTy::OutDuration = t_p1 {
                break 'm11530 prism_rtl::Turn::Finished(Text::lit("Duration"));
            }
            if let crate::lower::model::OutTy::OutError = t_p1 {
                break 'm11530 prism_rtl::Turn::Finished(Text::lit("Error"));
            }
            if let crate::lower::model::OutTy::OutNamed(m11530_14_0, m11530_14_1) = t_p1 && (m11530_14_0 == &Text::lit("Cell")) && (m11530_14_1.len() == 1) && let Some(i_p2) = crate::prelude::index(m11530_14_1, &Nat::from(0u32)) {
                break 'm11530 prism_rtl::Turn::More(Rc::new(CppType { cp_p0: cp_p0.clone(), t_p1: i_p2.clone() }));
            }
            if let crate::lower::model::OutTy::OutNamed(m11530_15_0, m11530_15_1) = t_p1 && (m11530_15_0 == &Text::lit("RefCell")) && (m11530_15_1.len() == 1) && let Some(i_p3) = crate::prelude::index(m11530_15_1, &Nat::from(0u32)) {
                break 'm11530 prism_rtl::Turn::More(Rc::new(CppType { cp_p0: cp_p0.clone(), t_p1: i_p3.clone() }));
            }
            if let crate::lower::model::OutTy::OutNamed(m11530_16_0, m11530_16_1) = t_p1 && (m11530_16_0 == &Text::lit("Vec")) && (m11530_16_1.len() == 1) && let Some(i_p4) = crate::prelude::index(m11530_16_1, &Nat::from(0u32)) {
                break 'm11530 {
                    let cp_p0x = cp_p0.clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_p4.clone()), move |cpp_type_f_11990: Text| prism_rtl::Turn::Finished(Text::from(format!("std::vector<{}>", &cpp_type_f_11990))))
                };
            }
            if let crate::lower::model::OutTy::OutNamed(m11530_17_0, m11530_17_1) = t_p1 && (m11530_17_0 == &Text::lit("Result")) && (m11530_17_1.len() == 2) && let Some(a_p5) = crate::prelude::index(m11530_17_1, &Nat::from(0u32)) && let Some(b_p6) = crate::prelude::index(m11530_17_1, &Nat::from(1u32)) {
                break 'm11530 {
                    let cp_p0x = cp_p0.clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), a_p5.clone()), move |cpp_type_f_12051: Text| crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), b_p6.clone()), move |cpp_type_f_12068: Text| prism_rtl::Turn::Finished(Text::from(format!("Expected<{}, {}>", &cpp_type_f_12051, &cpp_type_f_12068)))))
                };
            }
            if let crate::lower::model::OutTy::OutNamed(n_p7, m11530_18_1) = t_p1 && (m11530_18_1.len() == 0) {
                break 'm11530 prism_rtl::Turn::Finished(own_type_path_f(cp_p0, n_p7));
            }
            if let crate::lower::model::OutTy::OutNamed(n_p8, args_p9) = t_p1 {
                break 'm11530 {
                    let args_p9x = args_p9.clone();
                    let cp_p0x = cp_p0.clone();
                    let n_p8x = n_p8.clone();
                    crate::prelude::call_then(start_cpp_types_f(cp_p0x.clone(), args_p9x.clone()), move |cpp_types_f_12169: Text| prism_rtl::Turn::Finished(Text::from(format!("{}<{}>", &own_type_path_f(&cp_p0x, &n_p8x), &cpp_types_f_12169))))
                };
            }
            if let crate::lower::model::OutTy::OutOpt(i_pa) = t_p1 {
                break 'm11530 {
                    let cp_p0x = cp_p0.clone();
                    let i_pax = (**i_pa).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_pax.clone()), move |cpp_type_f_12220: Text| prism_rtl::Turn::Finished(Text::from(format!("std::optional<{}>", &cpp_type_f_12220))))
                };
            }
            if let crate::lower::model::OutTy::OutRes(i_pb) = t_p1 {
                break 'm11530 {
                    let cp_p0x = cp_p0.clone();
                    let i_pbx = (**i_pb).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_pbx.clone()), move |cpp_type_f_12262: Text| prism_rtl::Turn::Finished(Text::from(format!("Fallible<{}>", &cpp_type_f_12262))))
                };
            }
            if let crate::lower::model::OutTy::OutTuple(ts_pc) = t_p1 {
                break 'm11530 {
                    let cp_p0x = cp_p0.clone();
                    let ts_pcx = ts_pc.clone();
                    crate::prelude::call_then(start_cpp_types_f(cp_p0x.clone(), ts_pcx.clone()), move |cpp_types_f_12309: Text| prism_rtl::Turn::Finished(Text::from(format!("std::tuple<{}>", &cpp_types_f_12309))))
                };
            }
            if let crate::lower::model::OutTy::OutArray(e_pd) = t_p1 {
                break 'm11530 {
                    let cp_p0x = cp_p0.clone();
                    let e_pdx = (**e_pd).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), e_pdx.clone()), move |cpp_type_f_12352: Text| prism_rtl::Turn::Finished(Text::from(format!("Array<{}>", &cpp_type_f_12352))))
                };
            }
            if let crate::lower::model::OutTy::OutMap(k_pe, v_pf) = t_p1 {
                break 'm11530 {
                    let cp_p0x = cp_p0.clone();
                    let k_pex = (**k_pe).clone();
                    let v_pfx = (**v_pf).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), k_pex.clone()), move |cpp_type_f_12392: Text| crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), v_pfx.clone()), move |cpp_type_f_12409: Text| prism_rtl::Turn::Finished(Text::from(format!("Map<{}, {}>", &cpp_type_f_12392, &cpp_type_f_12409)))))
                };
            }
            if let crate::lower::model::OutTy::OutFn(ps_pg, r_ph) = t_p1 {
                break 'm11530 {
                    let cp_p0x = cp_p0.clone();
                    let ps_pgx = ps_pg.clone();
                    let r_phx = (**r_ph).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), r_phx.clone()), move |cpp_type_f_12448: Text| crate::prelude::call_then(start_param_types_f(cp_p0x.clone(), ps_pgx.clone()), move |param_types_f_12464: Text| prism_rtl::Turn::Finished(Text::from(format!("Fn<{}({})>", &cpp_type_f_12448, &param_types_f_12464)))))
                };
            }
            if let crate::lower::model::OutTy::OutRef(m11530_26_0) = t_p1 && let crate::lower::model::OutTy::OutFn(ps_pi, r_pj) = &**m11530_26_0 {
                break 'm11530 {
                    let cp_p0x = cp_p0.clone();
                    let ps_pix = ps_pi.clone();
                    let r_pjx = (**r_pj).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), r_pjx.clone()), move |cpp_type_f_12534: Text| crate::prelude::call_then(start_param_types_f(cp_p0x.clone(), ps_pix.clone()), move |param_types_f_12550: Text| prism_rtl::Turn::Finished(Text::from(format!("const std::function<{}({})>&", &cpp_type_f_12534, &param_types_f_12550)))))
                };
            }
            if let crate::lower::model::OutTy::OutRef(m11530_27_0) = t_p1 && let crate::lower::model::OutTy::OutSlice(i_pk) = &**m11530_27_0 {
                break 'm11530 {
                    let cp_p0x = cp_p0.clone();
                    let i_pkx = (**i_pk).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_pkx.clone()), move |cpp_type_f_12616: Text| prism_rtl::Turn::Finished(Text::from(format!("std::span<const {}>", &cpp_type_f_12616))))
                };
            }
            if let crate::lower::model::OutTy::OutRef(i_pl) = t_p1 {
                break 'm11530 {
                    let cp_p0x = cp_p0.clone();
                    let i_plx = (**i_pl).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_plx.clone()), move |cpp_type_f_12655: Text| prism_rtl::Turn::Finished(Text::from(format!("const {}&", &cpp_type_f_12655))))
                };
            }
            if let crate::lower::model::OutTy::OutJobFn(a_pm, b_pn) = t_p1 {
                break 'm11530 {
                    let a_pmx = (**a_pm).clone();
                    let b_pnx = (**b_pn).clone();
                    let cp_p0x = cp_p0.clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), b_pnx.clone()), move |cpp_type_f_12725: Text| crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), a_pmx.clone()), move |cpp_type_f_12742: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::Fn<prism_rtl::JobRef<{}>({})>", &cpp_type_f_12725, &cpp_type_f_12742)))))
                };
            }
            if let crate::lower::model::OutTy::OutJob(b_po) = t_p1 {
                break 'm11530 {
                    let b_pox = (**b_po).clone();
                    let cp_p0x = cp_p0.clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), b_pox.clone()), move |cpp_type_f_12794: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::JobRef<{}>", &cpp_type_f_12794))))
                };
            }
            if let crate::lower::model::OutTy::OutEvent(i_pp) = t_p1 {
                break 'm11530 {
                    let cp_p0x = cp_p0.clone();
                    let i_ppx = (**i_pp).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_ppx.clone()), move |cpp_type_f_12835: Text| prism_rtl::Turn::Finished(Text::from(format!("Event<{}>", &cpp_type_f_12835))))
                };
            }
            if let crate::lower::model::OutTy::OutDyn(i_pq) = t_p1 {
                break 'm11530 {
                    let cp_p0x = cp_p0.clone();
                    let i_pqx = (**i_pq).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_pqx.clone()), move |cpp_type_f_12876: Text| prism_rtl::Turn::Finished(Text::from(format!("Dynamic<{}>", &cpp_type_f_12876))))
                };
            }
            if let crate::lower::model::OutTy::OutGen(n_pr) = t_p1 {
                break 'm11530 prism_rtl::Turn::Finished(n_pr.clone());
            }
            if let crate::lower::model::OutTy::OutRc(i_ps) = t_p1 {
                break 'm11530 if is_value_ty_f(cp_p0, &**i_ps) {
                    {
                        let cp_p0x = cp_p0.clone();
                        let i_psx = (**i_ps).clone();
                        crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_psx.clone()), move |cpp_type_f_12964: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::Rc<const {}>", &cpp_type_f_12964))))
                    }
                } else {
                    {
                        let cp_p0x = cp_p0.clone();
                        let i_psx = (**i_ps).clone();
                        crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_psx.clone()), move |cpp_type_f_13003: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::Rc<{}>", &cpp_type_f_13003))))
                    }
                };
            }
            if let crate::lower::model::OutTy::OutPod = t_p1 {
                break 'm11530 prism_rtl::Turn::Finished(Text::lit("Pod"));
            }
            if let crate::lower::model::OutTy::OutShowAny = t_p1 {
                break 'm11530 prism_rtl::Turn::Finished(Text::lit("prism_rtl::Rc<const DynShow>"));
            }
            if let crate::lower::model::OutTy::OutHold(i_pt) = t_p1 {
                break 'm11530 {
                    let cp_p0x = cp_p0.clone();
                    let i_ptx = (**i_pt).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_ptx.clone()), move |cpp_type_f_13107: Text| prism_rtl::Turn::Finished(Text::from(format!("Hold<{}>", &cpp_type_f_13107))))
                };
            }
            if let crate::lower::model::OutTy::OutStamped(i_pu) = t_p1 {
                break 'm11530 {
                    let cp_p0x = cp_p0.clone();
                    let i_pux = (**i_pu).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_pux.clone()), move |cpp_type_f_13152: Text| prism_rtl::Turn::Finished(Text::from(format!("Stamped<{}>", &cpp_type_f_13152))))
                };
            }
            if let crate::lower::model::OutTy::OutSnapshot(i_pv) = t_p1 {
                break 'm11530 {
                    let cp_p0x = cp_p0.clone();
                    let i_pvx = (**i_pv).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_pvx.clone()), move |cpp_type_f_13199: Text| prism_rtl::Turn::Finished(Text::from(format!("Snapshot<{}>", &cpp_type_f_13199))))
                };
            }
            if let crate::lower::model::OutTy::OutDefer(i_p10) = t_p1 {
                break 'm11530 {
                    let cp_p0x = cp_p0.clone();
                    let i_p10x = (**i_p10).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_p10x.clone()), move |cpp_type_f_13240: Text| prism_rtl::Turn::Finished(Text::from(format!("Defer<{}>", &cpp_type_f_13240))))
                };
            }
            if let crate::lower::model::OutTy::OutWeak(n_p11) = t_p1 {
                break 'm11530 prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::Weak<{}>", &type_path_f(n_p11))));
            }
            if let crate::lower::model::OutTy::OutCell(i_p12) = t_p1 {
                break 'm11530 prism_rtl::Turn::More(Rc::new(CppType { cp_p0: cp_p0.clone(), t_p1: (**i_p12).clone() }));
            }
            if let crate::lower::model::OutTy::OutWakes = t_p1 {
                break 'm11530 prism_rtl::Turn::Finished(Text::lit("Wakes"));
            }
            if let crate::lower::model::OutTy::OutCount = t_p1 {
                break 'm11530 prism_rtl::Turn::Finished(Text::lit("std::uint32_t"));
            }
            if let crate::lower::model::OutTy::OutObj(i_p13) = t_p1 {
                break 'm11530 {
                    let cp_p0x = cp_p0.clone();
                    let i_p13x = (**i_p13).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_p13x.clone()), move |cpp_type_f_13415: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::Rc<{}>", &cpp_type_f_13415))))
                };
            }
            if let crate::lower::model::OutTy::OutSlice(i_p14) = t_p1 {
                break 'm11530 {
                    let cp_p0x = cp_p0.clone();
                    let i_p14x = (**i_p14).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_p14x.clone()), move |cpp_type_f_13466: Text| prism_rtl::Turn::Finished(Text::from(format!("std::span<const {}>", &cpp_type_f_13466))))
                };
            }
            if let crate::lower::model::OutTy::OutPort(i_p15) = t_p1 {
                break 'm11530 {
                    let cp_p0x = cp_p0.clone();
                    let i_p15x = (**i_p15).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_p15x.clone()), move |cpp_type_f_13505: Text| prism_rtl::Turn::Finished(Text::from(format!("Port<{}>", &cpp_type_f_13505))))
                };
            }
            if let crate::lower::model::OutTy::OutLive(i_p16) = t_p1 {
                break 'm11530 {
                    let cp_p0x = cp_p0.clone();
                    let i_p16x = (**i_p16).clone();
                    crate::prelude::call_then(start_cpp_type_f(cp_p0x.clone(), i_p16x.clone()), move |cpp_type_f_13544: Text| prism_rtl::Turn::Finished(Text::from(format!("Live<{}>", &cpp_type_f_13544))))
                };
            }
            if let crate::lower::model::OutTy::OutTurn = t_p1 {
                break 'm11530 prism_rtl::Turn::Finished(Text::lit("decltype(this->cycle())"));
            }
            if let crate::lower::model::OutTy::OutRefused(what_p17) = t_p1 {
                break 'm11530 prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::expr::lowering_refusal_p(), what_p17)));
            }
            if let crate::lower::model::OutTy::OutQuantified(b_p18) = t_p1 {
                break 'm11530 prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}a quantified type variable of `{}`: no instantiation gives it a type\")", &crate::lower::expr::lowering_refusal_p(), b_p18)));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start CppType, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_type_f(cp_p0: Cp, t_p1: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppType { cp_p0, t_p1 })
}

/// ```prism
/// CppTypes: unbounded fn Cp, [OutTy] -> Text
/// ```
pub fn cpp_types_f(cp_p0: &Cp, ts_p1: &Array<crate::lower::model::OutTy>) -> Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(ts_p1.clone(), {
        let cp_p0x = cp_p0.clone();
        Rc::new(move |p0: crate::lower::model::OutTy| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let t_p2 = p0;
                prism_rtl::Turn::More(Rc::new(CppType { cp_p0: cp_p0xy.clone(), t_p1: t_p2.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "))
}

/// The step machine of `CppTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppTypes: unbounded fn Cp, [OutTy] -> Text
/// ```
pub struct CppTypes {
    pub cp_p0: Cp,
    pub ts_p1: Array<crate::lower::model::OutTy>,
}

impl prism_rtl::Job<Text> for CppTypes {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let ts_p1 = &self.ts_p1;
        let cp_p0x = cp_p0.clone();
        let ts_p1x = ts_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(ts_p1x.clone(), {
            let cp_p0xx = cp_p0x.clone();
            Rc::new(move |p0: crate::lower::model::OutTy| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let t_p2 = p0;
                    prism_rtl::Turn::More(Rc::new(CppType { cp_p0: cp_p0xxy.clone(), t_p1: t_p2.clone() }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_13868: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join_f(&each_13868, &Text::lit(", "))))
    }
}

/// `Start CppTypes, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_types_f(cp_p0: Cp, ts_p1: Array<crate::lower::model::OutTy>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppTypes { cp_p0, ts_p1 })
}

/// ```prism
/// ParamTypes: unbounded fn Cp, [OutTy] -> Text
/// ```
pub fn param_types_f(cp_p0: &Cp, ts_p1: &Array<crate::lower::model::OutTy>) -> Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(ts_p1.clone(), {
        let cp_p0x = cp_p0.clone();
        Rc::new(move |p0: crate::lower::model::OutTy| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let t_p2 = p0;
                crate::prelude::call_then(start_cpp_type_f(cp_p0xy.clone(), t_p2.clone()), move |cpp_type_f_14083: Text| prism_rtl::Turn::Finished(Text::from(format!("const {}&", &cpp_type_f_14083))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "))
}

/// The step machine of `ParamTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParamTypes: unbounded fn Cp, [OutTy] -> Text
/// ```
pub struct ParamTypes {
    pub cp_p0: Cp,
    pub ts_p1: Array<crate::lower::model::OutTy>,
}

impl prism_rtl::Job<Text> for ParamTypes {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let ts_p1 = &self.ts_p1;
        let cp_p0x = cp_p0.clone();
        let ts_p1x = ts_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(ts_p1x.clone(), {
            let cp_p0xx = cp_p0x.clone();
            Rc::new(move |p0: crate::lower::model::OutTy| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let t_p2 = p0;
                    crate::prelude::call_then(start_cpp_type_f(cp_p0xxy.clone(), t_p2.clone()), move |cpp_type_f_14083: Text| prism_rtl::Turn::Finished(Text::from(format!("const {}&", &cpp_type_f_14083))))
                }))
            }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_14061: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join_f(&each_14061, &Text::lit(", "))))
    }
}

/// `Start ParamTypes, x`: what the function value is when passed to `@Run`.
pub fn start_param_types_f(cp_p0: Cp, ts_p1: Array<crate::lower::model::OutTy>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ParamTypes { cp_p0, ts_p1 })
}

/// ```prism
/// OwnTypePath: fn Cp, Text -> Text
/// ```
pub fn own_type_path_f(cp_p0: &Cp, n_p1: &Text) -> Text {
    let shadowed_p2 = !crate::syntax::lexer::chars::contains_f(n_p1, &Text::lit(":")) && in_list_f(&Array::from(vec![Text::lit("Job"), Text::lit("Node"), Text::lit("Row"), Text::lit("Turn"), Text::lit("Program")]), n_p1);
    match type_of_o(cp_p0, n_p1) {
        Some(_) => if shadowed_p2 {
            Text::from(format!("crate::{}::{}", &cp_p0.home_p, n_p1))
        } else {
            type_path_f(n_p1)
        },
        None => type_path_f(n_p1),
    }
}

/// ```prism
/// TypePath: fn Text -> Text
/// ```
pub fn type_path_f(p_p0: &Text) -> Text {
    let no_fish_p1 = crate::syntax::lexer::chars::join_f(&crate::prelude::split_on(p_p0, &Text::lit("::<")), &Text::lit("<"));
    let no_holes_p2 = crate::syntax::lexer::chars::join_f(&crate::prelude::split_on(&no_fish_p1, &Text::lit(", _>")), &Text::lit(">"));
    crate::syntax::lexer::chars::join_f(&crate::prelude::split_on(&no_holes_p2, &Text::lit("<_>")), &Text::lit(""))
}

/// ```prism
/// IsValueTy: fn Cp, OutTy -> Bool
/// ```
pub fn is_value_ty_f(cp_p0: &Cp, t_p1: &crate::lower::model::OutTy) -> bool {
    match t_p1 {
        crate::lower::model::OutTy::OutNamed(n_p2, _) => match type_of_o(cp_p0, n_p2) {
            Some(info_p3) => (&info_p3.kind_p != &Text::lit("node")) && (&info_p3.kind_p != &Text::lit("job")),
            None => false,
        },
        crate::lower::model::OutTy::OutCell(_) => false,
        crate::lower::model::OutTy::OutPort(_) => false,
        crate::lower::model::OutTy::OutHold(_) => false,
        crate::lower::model::OutTy::OutStamped(_) => false,
        crate::lower::model::OutTy::OutSnapshot(_) => false,
        crate::lower::model::OutTy::OutDefer(_) => false,
        crate::lower::model::OutTy::OutObj(_) => false,
        crate::lower::model::OutTy::OutWakes => false,
        _ => true,
    }
}
