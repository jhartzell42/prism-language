//! The module `Emit.Cpp`, from `target/bootstrap/src/prismc/emit/cpp/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod expr;
pub mod items;
pub mod patterns;
pub mod prelude;
pub mod program;
pub mod stmts;
pub mod templates;

/// `Cp`:
///
/// ```prism
/// type Cp = record:
/// ```
#[derive(Clone)]
pub struct Cp {
    pub home: Text,
    pub mods: Array<Text>,
    pub types: Map<Text, TyInfo>,
    pub ctors: Map<Text, Text>,
    pub members: Map<Text, bool>,
    pub methods: Map<Text, bool>,
    pub field_names: Map<Text, bool>,
    pub fns: Map<Text, bool>,
    pub fields: Map<Text, crate::lower::model::OutTy>,
    pub renames: Map<Text, Text>,
    pub pointers: Map<Text, bool>,
    pub owned: Map<Text, bool>,
    pub move_captures: Array<Text>,
    pub local_types: Map<Text, crate::lower::model::OutTy>,
}

impl ToPod for Cp {
    fn to_pod(&self) -> Pod {
        Pod::record("Cp", vec![("home", self.home.to_pod()), ("mods", self.mods.to_pod()), ("types", self.types.to_pod()), ("ctors", self.ctors.to_pod()), ("members", self.members.to_pod()), ("methods", self.methods.to_pod()), ("field_names", self.field_names.to_pod()), ("fns", self.fns.to_pod()), ("fields", self.fields.to_pod()), ("renames", self.renames.to_pod()), ("pointers", self.pointers.to_pod()), ("owned", self.owned.to_pod()), ("move_captures", self.move_captures.to_pod()), ("local_types", self.local_types.to_pod())])
    }
}

impl FromPod for Cp {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Cp { home: FromPod::from_pod(field(p, "home")?)?, mods: FromPod::from_pod(field(p, "mods")?)?, types: FromPod::from_pod(field(p, "types")?)?, ctors: FromPod::from_pod(field(p, "ctors")?)?, members: FromPod::from_pod(field(p, "members")?)?, methods: FromPod::from_pod(field(p, "methods")?)?, field_names: FromPod::from_pod(field(p, "field_names")?)?, fns: FromPod::from_pod(field(p, "fns")?)?, fields: FromPod::from_pod(field(p, "fields")?)?, renames: FromPod::from_pod(field(p, "renames")?)?, pointers: FromPod::from_pod(field(p, "pointers")?)?, owned: FromPod::from_pod(field(p, "owned")?)?, move_captures: FromPod::from_pod(field(p, "move_captures")?)?, local_types: FromPod::from_pod(field(p, "local_types")?)? })
    }
}

/// `TyInfo`:
///
/// ```prism
/// type TyInfo = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TyInfo {
    pub kind: Text,
    pub fields: Array<Text>,
    pub params: Array<Text>,
}

impl Show for TyInfo {
    fn show(&self, p: &mut Printer) {
        p.record("TyInfo", &[("kind", &self.kind), ("fields", &self.fields), ("params", &self.params)]);
    }
}

impl ToPod for TyInfo {
    fn to_pod(&self) -> Pod {
        Pod::record("TyInfo", vec![("kind", self.kind.to_pod()), ("fields", self.fields.to_pod()), ("params", self.params.to_pod())])
    }
}

impl FromPod for TyInfo {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TyInfo { kind: FromPod::from_pod(field(p, "kind")?)?, fields: FromPod::from_pod(field(p, "fields")?)?, params: FromPod::from_pod(field(p, "params")?)? })
    }
}

/// ```prism
/// CppId: fn Text -> Text
/// ```
pub fn cpp_id(n_p0: &Text) -> Text {
    if in_list(&crate::lower::cpp_keywords(), n_p0) {
        Text::from(format!("{}_", n_p0))
    } else {
        n_p0.clone()
    }
}

/// ```prism
/// FieldId: fn Text -> Text
/// ```
pub fn field_id(f_p0: &Text) -> Text {
    if in_list(&Array::from(vec![Text::lit("show"), Text::lit("to_pod"), Text::lit("from_pod"), Text::lit("cases")]), f_p0) {
        Text::from(format!("{}_", f_p0))
    } else {
        cpp_id(f_p0)
    }
}

/// ```prism
/// CppPathId: fn Text -> Text
/// ```
pub fn cpp_path_id(p_p0: &Text) -> Text {
    crate::syntax::lexer::chars::join(&each(&split_on(p_p0, &Text::lit("::")), &(|s_p1: &Text| cpp_id(s_p1))), &Text::lit("::"))
}

/// ```prism
/// InList: fn [Text], Text -> Bool
/// ```
pub fn in_list(xs_p0: &Array<Text>, x_p1: &Text) -> bool {
    fold(xs_p0, &false, &(|seen_p2: &bool, y_p3: &Text| *seen_p2 || (y_p3 == x_p1)))
}

/// ```prism
/// Absolute: fn Cp, Text -> Text
/// ```
pub fn absolute(cp_p0: &Cp, p_p1: &Text) -> Text {
    let q_p2 = crate::syntax::lexer::chars::drop_prefix(p_p1, &Text::lit("crate::"));
    if fold(&cp_p0.mods, &false, &(|f_p3: &bool, m_p4: &Text| *f_p3 || crate::syntax::lexer::chars::has_prefix(&q_p2, &Text::from(format!("{}::", m_p4))))) {
        q_p2.clone()
    } else {
        Text::from(format!("{}::{}", &cp_p0.home, &q_p2))
    }
}

/// ```prism
/// ?TypeOf: fn Cp, Text -> ?TyInfo
/// ```
pub fn type_of(cp_p0: &Cp, p_p1: &Text) -> Option<TyInfo> {
    let q_p2 = crate::syntax::lexer::chars::drop_prefix(p_p1, &Text::lit("crate::"));
    match get(&cp_p0.types, &absolute(cp_p0, &q_p2)) {
        Some(t_p3) => Some(t_p3),
        None => match get(&cp_p0.types, &Text::from(format!("prelude::{}", &q_p2))) {
            Some(t_p4) => Some(t_p4),
            None => get(&cp_p0.types, &q_p2),
        },
    }
}

/// ```prism
/// ?CaseOf: fn Cp, Text -> ?Text
/// ```
pub fn case_of(cp_p0: &Cp, p_p1: &Text) -> Option<Text> {
    let q_p2 = crate::syntax::lexer::chars::drop_prefix(p_p1, &Text::lit("crate::"));
    match get(&cp_p0.ctors, &absolute(cp_p0, &q_p2)) {
        Some(_) => Some(parent_path(p_p1)),
        None => match get(&cp_p0.ctors, &Text::from(format!("prelude::{}", &q_p2))) {
            Some(_) => Some(parent_path(p_p1)),
            None => match get(&cp_p0.ctors, &q_p2) {
                Some(_) => Some(parent_path(p_p1)),
                None => None,
            },
        },
    }
}

/// ```prism
/// ParentPath: fn Text -> Text
/// ```
pub fn parent_path(p_p0: &Text) -> Text {
    let segs_p1 = split_on(p_p0, &Text::lit("::"));
    crate::syntax::lexer::chars::join(&take(&segs_p1, &crate::syntax::lexer::chars::dec(&len(&segs_p1))), &Text::lit("::"))
}

/// ```prism
/// LastSegment: fn Text -> Text
/// ```
pub fn last_segment(p_p0: &Text) -> Text {
    or(&crate::syntax::lexer::chars::last(&split_on(p_p0, &Text::lit("::"))), p_p0)
}

/// ```prism
/// Context: fn Model -> Cp
/// ```
pub fn context(model_p0: &crate::lower::model::Model) -> Cp {
    let names_p1 = each(&model_p0.mods, &(|m_p6: &crate::lower::model::ModDef| m_p6.name.clone()));
    let tops_p2 = fold(&names_p1, &Array::new(), &(|acc_p7: &Array<Text>, n_p8: &Text| {
        let top_p9 = or(&index(&split_on(n_p8, &Text::lit("::")), &Nat::from(0u32)), n_p8);
        if in_list(&names_p1, &top_p9) || in_list(acc_p7, &top_p9) {
            acc_p7.clone()
        } else {
            push(acc_p7, &top_p9)
        }
    }));
    let mods_p3 = push(&append(&names_p1, &tops_p2), &Text::lit("prelude"));
    let base_p4 = Cp { home: Text::lit(""), mods: mods_p3.clone(), types: prelude_types(), ctors: prelude_ctors(), members: node_base(), methods: Map::new(), field_names: Map::new(), fns: Map::new(), fields: Map::new(), renames: Map::new(), pointers: Map::new(), owned: Map::new(), move_captures: Array::new(), local_types: Map::new() };
    let with_elem_p5 = add_row(&add_answer(&base_p4, &model_p0.answer), &Text::lit(""), &model_p0.elem);
    fold(&model_p0.mods, &with_elem_p5, &(|cp_pa: &Cp, m_pb: &crate::lower::model::ModDef| fold(&m_pb.items, cp_pa, &(|c_pc: &Cp, it_pd: &crate::lower::model::Item| add_model_item(c_pc, &m_pb.name, it_pd)))))
}

/// ```prism
/// let preludeTypes
/// ```
pub fn prelude_types() -> Map<Text, TyInfo> {
    map_of(vec![(Text::lit("prelude::Ordering"), TyInfo { kind: Text::lit("choice"), fields: Array::new(), params: Array::new() }), (Text::lit("prelude::Span"), TyInfo { kind: Text::lit("record"), fields: Array::from(vec![Text::lit("file"), Text::lit("line"), Text::lit("column"), Text::lit("binding")]), params: Array::new() }), (Text::lit("prelude::Exception"), TyInfo { kind: Text::lit("record"), fields: Array::from(vec![Text::lit("kind"), Text::lit("message"), Text::lit("spans"), Text::lit("path_")]), params: Array::new() }), (Text::lit("prelude::Duration"), TyInfo { kind: Text::lit("newtype"), fields: Array::new(), params: Array::new() }), (Text::lit("prelude::PreludeUnwrap"), TyInfo { kind: Text::lit("tag"), fields: Array::new(), params: Array::new() }), (Text::lit("prelude::PreludeExceptions"), TyInfo { kind: Text::lit("tag"), fields: Array::new(), params: Array::new() })])
}

/// ```prism
/// let preludeCtors
/// ```
pub fn prelude_ctors() -> Map<Text, Text> {
    map_of(vec![(Text::lit("prelude::Ordering::Less"), Text::lit("choice")), (Text::lit("prelude::Ordering::Equal"), Text::lit("choice")), (Text::lit("prelude::Ordering::Greater"), Text::lit("choice"))])
}

/// ```prism
/// let nodeBase
/// ```
pub fn node_base() -> Map<Text, bool> {
    map_of(vec![(Text::lit("make"), true), (Text::lit("push"), true), (Text::lit("wake"), true), (Text::lit("started"), true), (Text::lit("deferred"), true), (Text::lit("build"), true), (Text::lit("swap"), true), (Text::lit("leave"), true), (Text::lit("patch"), true), (Text::lit("edges"), true), (Text::lit("release"), true), (Text::lit("clean_up"), true), (Text::lit("path"), true), (Text::lit("leave_row"), true), (Text::lit("answer"), true), (Text::lit("document"), true), (Text::lit("entries"), true), (Text::lit("deliver"), true), (Text::lit("document_moved"), true), (Text::lit("me"), true), (Text::lit("result_dynamic"), true)])
}

/// ```prism
/// AddModelItem: fn Cp, Text, Item -> Cp
/// ```
pub fn add_model_item(cp_p0: &Cp, m_p1: &Text, it_p2: &crate::lower::model::Item) -> Cp {
    match it_p2 {
        crate::lower::model::Item::ItType(t_p3) => add_type(cp_p0, m_p1, t_p3),
        crate::lower::model::Item::ItTag(t_p4) => add_ty(cp_p0, &Text::from(format!("{}::{}", m_p1, &t_p4.name)), &TyInfo { kind: Text::lit("tag"), fields: each(&t_p4.fields, &(|(_, f_p5, _): &(Text, Text, crate::lower::model::OutTy)| f_p5.clone())), params: Array::new() }),
        crate::lower::model::Item::ItRow(r_p6) => add_row(cp_p0, m_p1, r_p6),
        crate::lower::model::Item::ItJob(j_p7) => add_ty(cp_p0, &Text::from(format!("{}::{}", m_p1, &j_p7.name)), &TyInfo { kind: Text::lit("job"), fields: each(&j_p7.fields, &(|(f_p8, _): &(Text, crate::lower::model::OutTy)| f_p8.clone())), params: each(&j_p7.generics, &(|(g_p9, _): &(Text, Array<Text>)| g_p9.clone())) }),
        crate::lower::model::Item::ItNode(n_pa) => add_node(cp_p0, m_p1, n_pa),
        crate::lower::model::Item::ItFn(f_pb) => {
            let mut this: Cp = cp_p0.clone();
            this.fns = insert(&this.fns, &Text::from(format!("{}::{}", m_p1, &f_pb.name)), &true);
            this
        },
        _ => cp_p0.clone(),
    }
}

/// ```prism
/// AddTy: fn Cp, Text, TyInfo -> Cp
/// ```
pub fn add_ty(cp_p0: &Cp, path_p1: &Text, info_p2: &TyInfo) -> Cp {
    let mut this: Cp = cp_p0.clone();
    this.types = insert(&this.types, path_p1, info_p2);
    this
}

/// ```prism
/// AddCtor: fn Cp, Text, Text -> Cp
/// ```
pub fn add_ctor(cp_p0: &Cp, path_p1: &Text, kind_p2: &Text) -> Cp {
    let mut this: Cp = cp_p0.clone();
    this.ctors = insert(&this.ctors, path_p1, kind_p2);
    this
}

/// ```prism
/// AddMember: fn Cp, Text -> Cp
/// ```
pub fn add_member(cp_p0: &Cp, name_p1: &Text) -> Cp {
    let mut this: Cp = cp_p0.clone();
    this.members = insert(&this.members, name_p1, &true);
    this
}

/// ```prism
/// AddType: fn Cp, Text, TyDef -> Cp
/// ```
pub fn add_type(cp_p0: &Cp, m_p1: &Text, t_p2: &crate::lower::model::TyDef) -> Cp {
    let path_p3 = Text::from(format!("{}::{}", m_p1, &t_p2.name));
    let first_p4 = or(&index(&t_p2.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
    match &t_p2.shape {
        crate::lower::model::TyShape::ShapeRecord => add_ty(cp_p0, &path_p3, &TyInfo { kind: Text::lit("record"), fields: each(&first_p4.fields, &(|(f_p5, _): &(Text, crate::lower::model::OutTy)| f_p5.clone())), params: t_p2.params.clone() }),
        crate::lower::model::TyShape::ShapeNewtype => add_ty(cp_p0, &path_p3, &TyInfo { kind: Text::lit("newtype"), fields: Array::new(), params: t_p2.params.clone() }),
        crate::lower::model::TyShape::ShapeUnit => add_ty(cp_p0, &path_p3, &TyInfo { kind: Text::lit("unit"), fields: Array::new(), params: t_p2.params.clone() }),
        crate::lower::model::TyShape::ShapeChoice => fold(&t_p2.cases, &add_ty(cp_p0, &path_p3, &TyInfo { kind: Text::lit("choice"), fields: Array::new(), params: t_p2.params.clone() }), &(|c_p6: &Cp, k_p7: &crate::lower::model::CaseDef| add_ctor(c_p6, &Text::from(format!("{}::{}", &path_p3, &k_p7.name)), &Text::lit("choice")))),
    }
}

/// ```prism
/// AddRow: fn Cp, Text, RowDef -> Cp
/// ```
pub fn add_row(cp_p0: &Cp, m_p1: &Text, r_p2: &crate::lower::model::RowDef) -> Cp {
    let path_p3 = if m_p1 == &Text::lit("") {
        r_p2.name.clone()
    } else {
        Text::from(format!("{}::{}", m_p1, &r_p2.name))
    };
    fold(&r_p2.cases, &add_ty(cp_p0, &path_p3, &TyInfo { kind: Text::lit("choice"), fields: Array::new(), params: Array::new() }), &(|c_p4: &Cp, (v_p5, _): &(Text, Text)| add_ctor(c_p4, &Text::from(format!("{}::{}", &path_p3, v_p5)), &Text::lit("choice"))))
}

/// ```prism
/// AddAnswer: fn Cp, AnswerDef -> Cp
/// ```
pub fn add_answer(cp_p0: &Cp, a_p1: &crate::lower::model::AnswerDef) -> Cp {
    fold(&a_p1.cases, &add_ty(cp_p0, &Text::lit("Answer"), &TyInfo { kind: Text::lit("choice"), fields: Array::new(), params: Array::new() }), &(|c_p2: &Cp, k_p3: &crate::lower::model::AnswerCase| add_ctor(c_p2, &Text::from(format!("Answer::{}", &k_p3.variant)), &Text::lit("choice"))))
}

/// ```prism
/// AddNode: fn Cp, Text, NodeDef -> Cp
/// ```
pub fn add_node(cp_p0: &Cp, m_p1: &Text, n_p2: &crate::lower::model::NodeDef) -> Cp {
    let with_fields_p3 = fold(&n_p2.fields, cp_p0, &(|c_p7: &Cp, (f_p8, _, _): &(Text, crate::lower::model::OutTy, Text)| {
        let mut this: Cp = add_member(c_p7, f_p8);
        this.field_names = insert(&this.field_names, f_p8, &true);
        this
    }));
    let with_methods_p4 = fold(&append(&n_p2.methods, &n_p2.hosted), &with_fields_p3, &(|c_p9: &Cp, md_pa: &crate::lower::model::MethDef| {
        let mut this: Cp = add_member(c_p9, &md_pa.name);
        this.methods = insert(&this.methods, &md_pa.name, &true);
        this
    }));
    let with_builders_p5 = fold(&n_p2.builders, &with_methods_p4, &(|c_pb: &Cp, b_pc: &crate::lower::model::ForDef| add_member(c_pb, &Text::from(format!("{}_build", &b_pc.name)))));
    let with_gens_p6 = fold(&n_p2.gens, &with_builders_p5, &(|c_pd: &Cp, g_pe: &crate::lower::model::GenDef| add_member(c_pd, &Text::from(format!("{}_build", &g_pe.name)))));
    add_ty(&with_gens_p6, &Text::from(format!("{}::{}", m_p1, &n_p2.name)), &TyInfo { kind: Text::lit("node"), fields: each(&n_p2.fields, &(|(f_pf, _, _): &(Text, crate::lower::model::OutTy, Text)| f_pf.clone())), params: Array::new() })
}

/// ```prism
/// InHome: fn Cp, Text -> Cp
/// ```
pub fn in_home(cp_p0: &Cp, m_p1: &Text) -> Cp {
    let mut this: Cp = cp_p0.clone();
    this.home = m_p1.clone();
    this
}

/// ```prism
/// WithFields: fn Cp, [((Text, OutTy))] -> Cp
/// ```
pub fn with_fields(cp_p0: &Cp, fs_p1: &Array<(Text, crate::lower::model::OutTy)>) -> Cp {
    let mut this: Cp = cp_p0.clone();
    this.fields = fold(fs_p1, &Map::new(), &(|acc_p2: &Map<Text, crate::lower::model::OutTy>, (f_p3, t_p4): &(Text, crate::lower::model::OutTy)| insert(acc_p2, f_p3, t_p4)));
    this
}

/// ```prism
/// CppType: unbounded fn Cp, OutTy -> Text
/// ```
pub fn cpp_type(cp_p0: &Cp, t_p1: &crate::lower::model::OutTy) -> Text {
    'm11561: {
        if let crate::lower::model::OutTy::OutNat = t_p1 {
            break 'm11561 Text::lit("Nat");
        }
        if let crate::lower::model::OutTy::OutInt = t_p1 {
            break 'm11561 Text::lit("Int");
        }
        if let crate::lower::model::OutTy::OutU8 = t_p1 {
            break 'm11561 Text::lit("std::uint8_t");
        }
        if let crate::lower::model::OutTy::OutFloat = t_p1 {
            break 'm11561 Text::lit("Float");
        }
        if let crate::lower::model::OutTy::OutBool = t_p1 {
            break 'm11561 Text::lit("bool");
        }
        if let crate::lower::model::OutTy::OutChar = t_p1 {
            break 'm11561 Text::lit("char32_t");
        }
        if let crate::lower::model::OutTy::OutText = t_p1 {
            break 'm11561 Text::lit("Text");
        }
        if let crate::lower::model::OutTy::OutCursor = t_p1 {
            break 'm11561 Text::lit("Cursor");
        }
        if let crate::lower::model::OutTy::OutRegex = t_p1 {
            break 'm11561 Text::lit("Regex");
        }
        if let crate::lower::model::OutTy::OutReplacement = t_p1 {
            break 'm11561 Text::lit("RegexReplacement");
        }
        if let crate::lower::model::OutTy::OutUnit = t_p1 {
            break 'm11561 Text::lit("Unit");
        }
        if let crate::lower::model::OutTy::OutPath = t_p1 {
            break 'm11561 Text::lit("Path");
        }
        if let crate::lower::model::OutTy::OutDuration = t_p1 {
            break 'm11561 Text::lit("Duration");
        }
        if let crate::lower::model::OutTy::OutError = t_p1 {
            break 'm11561 Text::lit("Error");
        }
        if let crate::lower::model::OutTy::OutNamed(m11561_14_0, m11561_14_1) = t_p1 && (m11561_14_0 == &Text::lit("Cell")) && (m11561_14_1.len() == 1) && let Some(i_p2) = index(m11561_14_1, &Nat::from(0u32)) {
            break 'm11561 cpp_type(cp_p0, &i_p2);
        }
        if let crate::lower::model::OutTy::OutNamed(m11561_15_0, m11561_15_1) = t_p1 && (m11561_15_0 == &Text::lit("RefCell")) && (m11561_15_1.len() == 1) && let Some(i_p3) = index(m11561_15_1, &Nat::from(0u32)) {
            break 'm11561 cpp_type(cp_p0, &i_p3);
        }
        if let crate::lower::model::OutTy::OutNamed(m11561_16_0, m11561_16_1) = t_p1 && (m11561_16_0 == &Text::lit("Vec")) && (m11561_16_1.len() == 1) && let Some(i_p4) = index(m11561_16_1, &Nat::from(0u32)) {
            break 'm11561 Text::from(format!("std::vector<{}>", &cpp_type(cp_p0, &i_p4)));
        }
        if let crate::lower::model::OutTy::OutNamed(m11561_17_0, m11561_17_1) = t_p1 && (m11561_17_0 == &Text::lit("Result")) && (m11561_17_1.len() == 2) && let Some(a_p5) = index(m11561_17_1, &Nat::from(0u32)) && let Some(b_p6) = index(m11561_17_1, &Nat::from(1u32)) {
            break 'm11561 Text::from(format!("Expected<{}, {}>", &cpp_type(cp_p0, &a_p5), &cpp_type(cp_p0, &b_p6)));
        }
        if let crate::lower::model::OutTy::OutNamed(n_p7, m11561_18_1) = t_p1 && (m11561_18_1.len() == 0) {
            break 'm11561 own_type_path(cp_p0, n_p7);
        }
        if let crate::lower::model::OutTy::OutNamed(n_p8, args_p9) = t_p1 {
            break 'm11561 Text::from(format!("{}<{}>", &own_type_path(cp_p0, n_p8), &cpp_types(cp_p0, args_p9)));
        }
        if let crate::lower::model::OutTy::OutOpt(i_pa) = t_p1 {
            break 'm11561 Text::from(format!("std::optional<{}>", &cpp_type(cp_p0, &**i_pa)));
        }
        if let crate::lower::model::OutTy::OutRes(i_pb) = t_p1 {
            break 'm11561 Text::from(format!("Fallible<{}>", &cpp_type(cp_p0, &**i_pb)));
        }
        if let crate::lower::model::OutTy::OutTuple(ts_pc) = t_p1 {
            break 'm11561 Text::from(format!("std::tuple<{}>", &cpp_types(cp_p0, ts_pc)));
        }
        if let crate::lower::model::OutTy::OutArray(e_pd) = t_p1 {
            break 'm11561 Text::from(format!("Array<{}>", &cpp_type(cp_p0, &**e_pd)));
        }
        if let crate::lower::model::OutTy::OutMap(k_pe, v_pf) = t_p1 {
            break 'm11561 Text::from(format!("Map<{}, {}>", &cpp_type(cp_p0, &**k_pe), &cpp_type(cp_p0, &**v_pf)));
        }
        if let crate::lower::model::OutTy::OutFn(ps_pg, r_ph) = t_p1 {
            break 'm11561 Text::from(format!("Fn<{}({})>", &cpp_type(cp_p0, &**r_ph), &param_types(cp_p0, ps_pg)));
        }
        if let crate::lower::model::OutTy::OutRef(m11561_26_0) = t_p1 && let crate::lower::model::OutTy::OutFn(ps_pi, r_pj) = &**m11561_26_0 {
            break 'm11561 Text::from(format!("const std::function<{}({})>&", &cpp_type(cp_p0, &**r_pj), &param_types(cp_p0, ps_pi)));
        }
        if let crate::lower::model::OutTy::OutRef(m11561_27_0) = t_p1 && let crate::lower::model::OutTy::OutSlice(i_pk) = &**m11561_27_0 {
            break 'm11561 Text::from(format!("std::span<const {}>", &cpp_type(cp_p0, &**i_pk)));
        }
        if let crate::lower::model::OutTy::OutRef(i_pl) = t_p1 {
            break 'm11561 Text::from(format!("const {}&", &cpp_type(cp_p0, &**i_pl)));
        }
        if let crate::lower::model::OutTy::OutJobFn(a_pm, b_pn) = t_p1 {
            break 'm11561 Text::from(format!("prism_rtl::Fn<prism_rtl::JobRef<{}>({})>", &cpp_type(cp_p0, &**b_pn), &cpp_type(cp_p0, &**a_pm)));
        }
        if let crate::lower::model::OutTy::OutJob(b_po) = t_p1 {
            break 'm11561 Text::from(format!("prism_rtl::JobRef<{}>", &cpp_type(cp_p0, &**b_po)));
        }
        if let crate::lower::model::OutTy::OutEvent(i_pp) = t_p1 {
            break 'm11561 Text::from(format!("Event<{}>", &cpp_type(cp_p0, &**i_pp)));
        }
        if let crate::lower::model::OutTy::OutDyn(i_pq) = t_p1 {
            break 'm11561 Text::from(format!("Dynamic<{}>", &cpp_type(cp_p0, &**i_pq)));
        }
        if let crate::lower::model::OutTy::OutGen(n_pr) = t_p1 {
            break 'm11561 n_pr.clone();
        }
        if let crate::lower::model::OutTy::OutRc(i_ps) = t_p1 {
            break 'm11561 if is_value_ty(cp_p0, &**i_ps) {
                Text::from(format!("prism_rtl::Rc<const {}>", &cpp_type(cp_p0, &**i_ps)))
            } else {
                Text::from(format!("prism_rtl::Rc<{}>", &cpp_type(cp_p0, &**i_ps)))
            };
        }
        if let crate::lower::model::OutTy::OutPod = t_p1 {
            break 'm11561 Text::lit("Pod");
        }
        if let crate::lower::model::OutTy::OutShowAny = t_p1 {
            break 'm11561 Text::lit("prism_rtl::Rc<const DynShow>");
        }
        if let crate::lower::model::OutTy::OutHold(i_pt) = t_p1 {
            break 'm11561 Text::from(format!("Hold<{}>", &cpp_type(cp_p0, &**i_pt)));
        }
        if let crate::lower::model::OutTy::OutStamped(i_pu) = t_p1 {
            break 'm11561 Text::from(format!("Stamped<{}>", &cpp_type(cp_p0, &**i_pu)));
        }
        if let crate::lower::model::OutTy::OutSnapshot(i_pv) = t_p1 {
            break 'm11561 Text::from(format!("Snapshot<{}>", &cpp_type(cp_p0, &**i_pv)));
        }
        if let crate::lower::model::OutTy::OutDefer(i_p10) = t_p1 {
            break 'm11561 Text::from(format!("Defer<{}>", &cpp_type(cp_p0, &**i_p10)));
        }
        if let crate::lower::model::OutTy::OutWeak(n_p11) = t_p1 {
            break 'm11561 Text::from(format!("prism_rtl::Weak<{}>", &type_path(n_p11)));
        }
        if let crate::lower::model::OutTy::OutCell(i_p12) = t_p1 {
            break 'm11561 cpp_type(cp_p0, &**i_p12);
        }
        if let crate::lower::model::OutTy::OutWakes = t_p1 {
            break 'm11561 Text::lit("Wakes");
        }
        if let crate::lower::model::OutTy::OutCount = t_p1 {
            break 'm11561 Text::lit("std::uint32_t");
        }
        if let crate::lower::model::OutTy::OutObj(i_p13) = t_p1 {
            break 'm11561 Text::from(format!("prism_rtl::Rc<{}>", &cpp_type(cp_p0, &**i_p13)));
        }
        if let crate::lower::model::OutTy::OutSlice(i_p14) = t_p1 {
            break 'm11561 Text::from(format!("std::span<const {}>", &cpp_type(cp_p0, &**i_p14)));
        }
        if let crate::lower::model::OutTy::OutPort(i_p15) = t_p1 {
            break 'm11561 Text::from(format!("Port<{}>", &cpp_type(cp_p0, &**i_p15)));
        }
        if let crate::lower::model::OutTy::OutLive(i_p16) = t_p1 {
            break 'm11561 Text::from(format!("Live<{}>", &cpp_type(cp_p0, &**i_p16)));
        }
        if let crate::lower::model::OutTy::OutUnknown(m11561_49_0) = t_p1 && (m11561_49_0 == &Text::lit("the job\'s turn")) {
            break 'm11561 Text::lit("decltype(this->cycle())");
        }
        if let crate::lower::model::OutTy::OutUnknown(what_p17) = t_p1 {
            break 'm11561 Text::from(format!("Unit /* {} */", what_p17));
        }
        if let crate::lower::model::OutTy::OutQuantified(b_p18) = t_p1 {
            break 'm11561 Text::from(format!("compile_error!(\"{}a quantified type variable of `{}`: no instantiation gives it a type\")", &crate::lower::expr::lowering_refusal(), b_p18));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `CppType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppType: unbounded fn Cp, OutTy -> Text
/// ```
pub struct CppType {
    pub cp_p0: Cp,
    pub t_p1: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for CppType {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        'm11561: {
            if let crate::lower::model::OutTy::OutNat = t_p1 {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("Nat"));
            }
            if let crate::lower::model::OutTy::OutInt = t_p1 {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("Int"));
            }
            if let crate::lower::model::OutTy::OutU8 = t_p1 {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("std::uint8_t"));
            }
            if let crate::lower::model::OutTy::OutFloat = t_p1 {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("Float"));
            }
            if let crate::lower::model::OutTy::OutBool = t_p1 {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("bool"));
            }
            if let crate::lower::model::OutTy::OutChar = t_p1 {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("char32_t"));
            }
            if let crate::lower::model::OutTy::OutText = t_p1 {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("Text"));
            }
            if let crate::lower::model::OutTy::OutCursor = t_p1 {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("Cursor"));
            }
            if let crate::lower::model::OutTy::OutRegex = t_p1 {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("Regex"));
            }
            if let crate::lower::model::OutTy::OutReplacement = t_p1 {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("RegexReplacement"));
            }
            if let crate::lower::model::OutTy::OutUnit = t_p1 {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("Unit"));
            }
            if let crate::lower::model::OutTy::OutPath = t_p1 {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("Path"));
            }
            if let crate::lower::model::OutTy::OutDuration = t_p1 {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("Duration"));
            }
            if let crate::lower::model::OutTy::OutError = t_p1 {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("Error"));
            }
            if let crate::lower::model::OutTy::OutNamed(m11561_14_0, m11561_14_1) = t_p1 && (m11561_14_0 == &Text::lit("Cell")) && (m11561_14_1.len() == 1) && let Some(i_p2) = index(m11561_14_1, &Nat::from(0u32)) {
                break 'm11561 prism_rtl::Turn::More(Rc::new(CppType { cp_p0: cp_p0.clone(), t_p1: i_p2.clone() }));
            }
            if let crate::lower::model::OutTy::OutNamed(m11561_15_0, m11561_15_1) = t_p1 && (m11561_15_0 == &Text::lit("RefCell")) && (m11561_15_1.len() == 1) && let Some(i_p3) = index(m11561_15_1, &Nat::from(0u32)) {
                break 'm11561 prism_rtl::Turn::More(Rc::new(CppType { cp_p0: cp_p0.clone(), t_p1: i_p3.clone() }));
            }
            if let crate::lower::model::OutTy::OutNamed(m11561_16_0, m11561_16_1) = t_p1 && (m11561_16_0 == &Text::lit("Vec")) && (m11561_16_1.len() == 1) && let Some(i_p4) = index(m11561_16_1, &Nat::from(0u32)) {
                break 'm11561 {
                    let cp_p0 = cp_p0.clone();
                    call_then(start_cpp_type(cp_p0.clone(), i_p4.clone()), move |cpp_type_12021: Text| prism_rtl::Turn::Finished(Text::from(format!("std::vector<{}>", &cpp_type_12021))))
                };
            }
            if let crate::lower::model::OutTy::OutNamed(m11561_17_0, m11561_17_1) = t_p1 && (m11561_17_0 == &Text::lit("Result")) && (m11561_17_1.len() == 2) && let Some(a_p5) = index(m11561_17_1, &Nat::from(0u32)) && let Some(b_p6) = index(m11561_17_1, &Nat::from(1u32)) {
                break 'm11561 {
                    let cp_p0 = cp_p0.clone();
                    call_then(start_cpp_type(cp_p0.clone(), a_p5.clone()), move |cpp_type_12082: Text| call_then(start_cpp_type(cp_p0.clone(), b_p6.clone()), move |cpp_type_12099: Text| prism_rtl::Turn::Finished(Text::from(format!("Expected<{}, {}>", &cpp_type_12082, &cpp_type_12099)))))
                };
            }
            if let crate::lower::model::OutTy::OutNamed(n_p7, m11561_18_1) = t_p1 && (m11561_18_1.len() == 0) {
                break 'm11561 prism_rtl::Turn::Finished(own_type_path(cp_p0, n_p7));
            }
            if let crate::lower::model::OutTy::OutNamed(n_p8, args_p9) = t_p1 {
                break 'm11561 {
                    let args_p9 = args_p9.clone();
                    let cp_p0 = cp_p0.clone();
                    let n_p8 = n_p8.clone();
                    call_then(start_cpp_types(cp_p0.clone(), args_p9.clone()), move |cpp_types_12200: Text| prism_rtl::Turn::Finished(Text::from(format!("{}<{}>", &own_type_path(&cp_p0, &n_p8), &cpp_types_12200))))
                };
            }
            if let crate::lower::model::OutTy::OutOpt(i_pa) = t_p1 {
                break 'm11561 {
                    let cp_p0 = cp_p0.clone();
                    let i_pa = (**i_pa).clone();
                    call_then(start_cpp_type(cp_p0.clone(), i_pa.clone()), move |cpp_type_12251: Text| prism_rtl::Turn::Finished(Text::from(format!("std::optional<{}>", &cpp_type_12251))))
                };
            }
            if let crate::lower::model::OutTy::OutRes(i_pb) = t_p1 {
                break 'm11561 {
                    let cp_p0 = cp_p0.clone();
                    let i_pb = (**i_pb).clone();
                    call_then(start_cpp_type(cp_p0.clone(), i_pb.clone()), move |cpp_type_12293: Text| prism_rtl::Turn::Finished(Text::from(format!("Fallible<{}>", &cpp_type_12293))))
                };
            }
            if let crate::lower::model::OutTy::OutTuple(ts_pc) = t_p1 {
                break 'm11561 {
                    let cp_p0 = cp_p0.clone();
                    let ts_pc = ts_pc.clone();
                    call_then(start_cpp_types(cp_p0.clone(), ts_pc.clone()), move |cpp_types_12340: Text| prism_rtl::Turn::Finished(Text::from(format!("std::tuple<{}>", &cpp_types_12340))))
                };
            }
            if let crate::lower::model::OutTy::OutArray(e_pd) = t_p1 {
                break 'm11561 {
                    let cp_p0 = cp_p0.clone();
                    let e_pd = (**e_pd).clone();
                    call_then(start_cpp_type(cp_p0.clone(), e_pd.clone()), move |cpp_type_12383: Text| prism_rtl::Turn::Finished(Text::from(format!("Array<{}>", &cpp_type_12383))))
                };
            }
            if let crate::lower::model::OutTy::OutMap(k_pe, v_pf) = t_p1 {
                break 'm11561 {
                    let cp_p0 = cp_p0.clone();
                    let k_pe = (**k_pe).clone();
                    let v_pf = (**v_pf).clone();
                    call_then(start_cpp_type(cp_p0.clone(), k_pe.clone()), move |cpp_type_12423: Text| call_then(start_cpp_type(cp_p0.clone(), v_pf.clone()), move |cpp_type_12440: Text| prism_rtl::Turn::Finished(Text::from(format!("Map<{}, {}>", &cpp_type_12423, &cpp_type_12440)))))
                };
            }
            if let crate::lower::model::OutTy::OutFn(ps_pg, r_ph) = t_p1 {
                break 'm11561 {
                    let cp_p0 = cp_p0.clone();
                    let ps_pg = ps_pg.clone();
                    let r_ph = (**r_ph).clone();
                    call_then(start_cpp_type(cp_p0.clone(), r_ph.clone()), move |cpp_type_12479: Text| call_then(start_param_types(cp_p0.clone(), ps_pg.clone()), move |param_types_12495: Text| prism_rtl::Turn::Finished(Text::from(format!("Fn<{}({})>", &cpp_type_12479, &param_types_12495)))))
                };
            }
            if let crate::lower::model::OutTy::OutRef(m11561_26_0) = t_p1 && let crate::lower::model::OutTy::OutFn(ps_pi, r_pj) = &**m11561_26_0 {
                break 'm11561 {
                    let cp_p0 = cp_p0.clone();
                    let ps_pi = ps_pi.clone();
                    let r_pj = (**r_pj).clone();
                    call_then(start_cpp_type(cp_p0.clone(), r_pj.clone()), move |cpp_type_12565: Text| call_then(start_param_types(cp_p0.clone(), ps_pi.clone()), move |param_types_12581: Text| prism_rtl::Turn::Finished(Text::from(format!("const std::function<{}({})>&", &cpp_type_12565, &param_types_12581)))))
                };
            }
            if let crate::lower::model::OutTy::OutRef(m11561_27_0) = t_p1 && let crate::lower::model::OutTy::OutSlice(i_pk) = &**m11561_27_0 {
                break 'm11561 {
                    let cp_p0 = cp_p0.clone();
                    let i_pk = (**i_pk).clone();
                    call_then(start_cpp_type(cp_p0.clone(), i_pk.clone()), move |cpp_type_12647: Text| prism_rtl::Turn::Finished(Text::from(format!("std::span<const {}>", &cpp_type_12647))))
                };
            }
            if let crate::lower::model::OutTy::OutRef(i_pl) = t_p1 {
                break 'm11561 {
                    let cp_p0 = cp_p0.clone();
                    let i_pl = (**i_pl).clone();
                    call_then(start_cpp_type(cp_p0.clone(), i_pl.clone()), move |cpp_type_12686: Text| prism_rtl::Turn::Finished(Text::from(format!("const {}&", &cpp_type_12686))))
                };
            }
            if let crate::lower::model::OutTy::OutJobFn(a_pm, b_pn) = t_p1 {
                break 'm11561 {
                    let a_pm = (**a_pm).clone();
                    let b_pn = (**b_pn).clone();
                    let cp_p0 = cp_p0.clone();
                    call_then(start_cpp_type(cp_p0.clone(), b_pn.clone()), move |cpp_type_12756: Text| call_then(start_cpp_type(cp_p0.clone(), a_pm.clone()), move |cpp_type_12773: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::Fn<prism_rtl::JobRef<{}>({})>", &cpp_type_12756, &cpp_type_12773)))))
                };
            }
            if let crate::lower::model::OutTy::OutJob(b_po) = t_p1 {
                break 'm11561 {
                    let b_po = (**b_po).clone();
                    let cp_p0 = cp_p0.clone();
                    call_then(start_cpp_type(cp_p0.clone(), b_po.clone()), move |cpp_type_12825: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::JobRef<{}>", &cpp_type_12825))))
                };
            }
            if let crate::lower::model::OutTy::OutEvent(i_pp) = t_p1 {
                break 'm11561 {
                    let cp_p0 = cp_p0.clone();
                    let i_pp = (**i_pp).clone();
                    call_then(start_cpp_type(cp_p0.clone(), i_pp.clone()), move |cpp_type_12866: Text| prism_rtl::Turn::Finished(Text::from(format!("Event<{}>", &cpp_type_12866))))
                };
            }
            if let crate::lower::model::OutTy::OutDyn(i_pq) = t_p1 {
                break 'm11561 {
                    let cp_p0 = cp_p0.clone();
                    let i_pq = (**i_pq).clone();
                    call_then(start_cpp_type(cp_p0.clone(), i_pq.clone()), move |cpp_type_12907: Text| prism_rtl::Turn::Finished(Text::from(format!("Dynamic<{}>", &cpp_type_12907))))
                };
            }
            if let crate::lower::model::OutTy::OutGen(n_pr) = t_p1 {
                break 'm11561 prism_rtl::Turn::Finished(n_pr.clone());
            }
            if let crate::lower::model::OutTy::OutRc(i_ps) = t_p1 {
                break 'm11561 if is_value_ty(cp_p0, &**i_ps) {
                    {
                        let cp_p0 = cp_p0.clone();
                        let i_ps = (**i_ps).clone();
                        call_then(start_cpp_type(cp_p0.clone(), i_ps.clone()), move |cpp_type_12995: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::Rc<const {}>", &cpp_type_12995))))
                    }
                } else {
                    {
                        let cp_p0 = cp_p0.clone();
                        let i_ps = (**i_ps).clone();
                        call_then(start_cpp_type(cp_p0.clone(), i_ps.clone()), move |cpp_type_13034: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::Rc<{}>", &cpp_type_13034))))
                    }
                };
            }
            if let crate::lower::model::OutTy::OutPod = t_p1 {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("Pod"));
            }
            if let crate::lower::model::OutTy::OutShowAny = t_p1 {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("prism_rtl::Rc<const DynShow>"));
            }
            if let crate::lower::model::OutTy::OutHold(i_pt) = t_p1 {
                break 'm11561 {
                    let cp_p0 = cp_p0.clone();
                    let i_pt = (**i_pt).clone();
                    call_then(start_cpp_type(cp_p0.clone(), i_pt.clone()), move |cpp_type_13138: Text| prism_rtl::Turn::Finished(Text::from(format!("Hold<{}>", &cpp_type_13138))))
                };
            }
            if let crate::lower::model::OutTy::OutStamped(i_pu) = t_p1 {
                break 'm11561 {
                    let cp_p0 = cp_p0.clone();
                    let i_pu = (**i_pu).clone();
                    call_then(start_cpp_type(cp_p0.clone(), i_pu.clone()), move |cpp_type_13183: Text| prism_rtl::Turn::Finished(Text::from(format!("Stamped<{}>", &cpp_type_13183))))
                };
            }
            if let crate::lower::model::OutTy::OutSnapshot(i_pv) = t_p1 {
                break 'm11561 {
                    let cp_p0 = cp_p0.clone();
                    let i_pv = (**i_pv).clone();
                    call_then(start_cpp_type(cp_p0.clone(), i_pv.clone()), move |cpp_type_13230: Text| prism_rtl::Turn::Finished(Text::from(format!("Snapshot<{}>", &cpp_type_13230))))
                };
            }
            if let crate::lower::model::OutTy::OutDefer(i_p10) = t_p1 {
                break 'm11561 {
                    let cp_p0 = cp_p0.clone();
                    let i_p10 = (**i_p10).clone();
                    call_then(start_cpp_type(cp_p0.clone(), i_p10.clone()), move |cpp_type_13271: Text| prism_rtl::Turn::Finished(Text::from(format!("Defer<{}>", &cpp_type_13271))))
                };
            }
            if let crate::lower::model::OutTy::OutWeak(n_p11) = t_p1 {
                break 'm11561 prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::Weak<{}>", &type_path(n_p11))));
            }
            if let crate::lower::model::OutTy::OutCell(i_p12) = t_p1 {
                break 'm11561 prism_rtl::Turn::More(Rc::new(CppType { cp_p0: cp_p0.clone(), t_p1: (**i_p12).clone() }));
            }
            if let crate::lower::model::OutTy::OutWakes = t_p1 {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("Wakes"));
            }
            if let crate::lower::model::OutTy::OutCount = t_p1 {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("std::uint32_t"));
            }
            if let crate::lower::model::OutTy::OutObj(i_p13) = t_p1 {
                break 'm11561 {
                    let cp_p0 = cp_p0.clone();
                    let i_p13 = (**i_p13).clone();
                    call_then(start_cpp_type(cp_p0.clone(), i_p13.clone()), move |cpp_type_13446: Text| prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::Rc<{}>", &cpp_type_13446))))
                };
            }
            if let crate::lower::model::OutTy::OutSlice(i_p14) = t_p1 {
                break 'm11561 {
                    let cp_p0 = cp_p0.clone();
                    let i_p14 = (**i_p14).clone();
                    call_then(start_cpp_type(cp_p0.clone(), i_p14.clone()), move |cpp_type_13497: Text| prism_rtl::Turn::Finished(Text::from(format!("std::span<const {}>", &cpp_type_13497))))
                };
            }
            if let crate::lower::model::OutTy::OutPort(i_p15) = t_p1 {
                break 'm11561 {
                    let cp_p0 = cp_p0.clone();
                    let i_p15 = (**i_p15).clone();
                    call_then(start_cpp_type(cp_p0.clone(), i_p15.clone()), move |cpp_type_13536: Text| prism_rtl::Turn::Finished(Text::from(format!("Port<{}>", &cpp_type_13536))))
                };
            }
            if let crate::lower::model::OutTy::OutLive(i_p16) = t_p1 {
                break 'm11561 {
                    let cp_p0 = cp_p0.clone();
                    let i_p16 = (**i_p16).clone();
                    call_then(start_cpp_type(cp_p0.clone(), i_p16.clone()), move |cpp_type_13575: Text| prism_rtl::Turn::Finished(Text::from(format!("Live<{}>", &cpp_type_13575))))
                };
            }
            if let crate::lower::model::OutTy::OutUnknown(m11561_49_0) = t_p1 && (m11561_49_0 == &Text::lit("the job\'s turn")) {
                break 'm11561 prism_rtl::Turn::Finished(Text::lit("decltype(this->cycle())"));
            }
            if let crate::lower::model::OutTy::OutUnknown(what_p17) = t_p1 {
                break 'm11561 prism_rtl::Turn::Finished(Text::from(format!("Unit /* {} */", what_p17)));
            }
            if let crate::lower::model::OutTy::OutQuantified(b_p18) = t_p1 {
                break 'm11561 prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}a quantified type variable of `{}`: no instantiation gives it a type\")", &crate::lower::expr::lowering_refusal(), b_p18)));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start CppType, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_type(cp_p0: Cp, t_p1: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppType { cp_p0, t_p1 })
}

/// ```prism
/// CppTypes: unbounded fn Cp, [OutTy] -> Text
/// ```
pub fn cpp_types(cp_p0: &Cp, ts_p1: &Array<crate::lower::model::OutTy>) -> Text {
    crate::syntax::lexer::chars::join(&run_to_end(each_job(ts_p1.clone(), {
        let cp_p0 = cp_p0.clone();
        Rc::new(move |p0: crate::lower::model::OutTy| {
            let cp_p0 = cp_p0.clone();
            entered(once_job(move || {
                let t_p2 = p0;
                prism_rtl::Turn::More(Rc::new(CppType { cp_p0: cp_p0.clone(), t_p1: t_p2.clone() }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "))
}

/// The step machine of `CppTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppTypes: unbounded fn Cp, [OutTy] -> Text
/// ```
pub struct CppTypes {
    pub cp_p0: Cp,
    pub ts_p1: Array<crate::lower::model::OutTy>,
}

impl prism_rtl::Job<Text> for CppTypes {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let ts_p1 = &self.ts_p1;
        let cp_p0 = cp_p0.clone();
        let ts_p1 = ts_p1.clone();
        call_value(each_job(ts_p1.clone(), {
            let cp_p0 = cp_p0.clone();
            Rc::new(move |p0: crate::lower::model::OutTy| {
                let cp_p0 = cp_p0.clone();
                entered(once_job(move || {
                    let t_p2 = p0;
                    prism_rtl::Turn::More(Rc::new(CppType { cp_p0: cp_p0.clone(), t_p1: t_p2.clone() }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_13893: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&each_13893, &Text::lit(", "))))
    }
}

/// `Start CppTypes, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_types(cp_p0: Cp, ts_p1: Array<crate::lower::model::OutTy>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppTypes { cp_p0, ts_p1 })
}

/// ```prism
/// ParamTypes: unbounded fn Cp, [OutTy] -> Text
/// ```
pub fn param_types(cp_p0: &Cp, ts_p1: &Array<crate::lower::model::OutTy>) -> Text {
    crate::syntax::lexer::chars::join(&run_to_end(each_job(ts_p1.clone(), {
        let cp_p0 = cp_p0.clone();
        Rc::new(move |p0: crate::lower::model::OutTy| {
            let cp_p0 = cp_p0.clone();
            entered(once_job(move || {
                let t_p2 = p0;
                call_then(start_cpp_type(cp_p0.clone(), t_p2.clone()), move |cpp_type_14108: Text| prism_rtl::Turn::Finished(Text::from(format!("const {}&", &cpp_type_14108))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "))
}

/// The step machine of `ParamTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParamTypes: unbounded fn Cp, [OutTy] -> Text
/// ```
pub struct ParamTypes {
    pub cp_p0: Cp,
    pub ts_p1: Array<crate::lower::model::OutTy>,
}

impl prism_rtl::Job<Text> for ParamTypes {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let ts_p1 = &self.ts_p1;
        let cp_p0 = cp_p0.clone();
        let ts_p1 = ts_p1.clone();
        call_value(each_job(ts_p1.clone(), {
            let cp_p0 = cp_p0.clone();
            Rc::new(move |p0: crate::lower::model::OutTy| {
                let cp_p0 = cp_p0.clone();
                entered(once_job(move || {
                    let t_p2 = p0;
                    call_then(start_cpp_type(cp_p0.clone(), t_p2.clone()), move |cpp_type_14108: Text| prism_rtl::Turn::Finished(Text::from(format!("const {}&", &cpp_type_14108))))
                }))
            }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_14086: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&each_14086, &Text::lit(", "))))
    }
}

/// `Start ParamTypes, x`: what the function value is when passed to `@Run`.
pub fn start_param_types(cp_p0: Cp, ts_p1: Array<crate::lower::model::OutTy>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ParamTypes { cp_p0, ts_p1 })
}

/// ```prism
/// OwnTypePath: fn Cp, Text -> Text
/// ```
pub fn own_type_path(cp_p0: &Cp, n_p1: &Text) -> Text {
    let shadowed_p2 = !crate::syntax::lexer::chars::contains(n_p1, &Text::lit(":")) && in_list(&Array::from(vec![Text::lit("Job"), Text::lit("Node"), Text::lit("Row"), Text::lit("Turn"), Text::lit("Program")]), n_p1);
    match type_of(cp_p0, n_p1) {
        Some(_) => if shadowed_p2 {
            Text::from(format!("crate::{}::{}", &cp_p0.home, n_p1))
        } else {
            type_path(n_p1)
        },
        None => type_path(n_p1),
    }
}

/// ```prism
/// TypePath: fn Text -> Text
/// ```
pub fn type_path(p_p0: &Text) -> Text {
    let no_fish_p1 = crate::syntax::lexer::chars::join(&split_on(p_p0, &Text::lit("::<")), &Text::lit("<"));
    let no_holes_p2 = crate::syntax::lexer::chars::join(&split_on(&no_fish_p1, &Text::lit(", _>")), &Text::lit(">"));
    crate::syntax::lexer::chars::join(&split_on(&no_holes_p2, &Text::lit("<_>")), &Text::lit(""))
}

/// ```prism
/// IsValueTy: fn Cp, OutTy -> Bool
/// ```
pub fn is_value_ty(cp_p0: &Cp, t_p1: &crate::lower::model::OutTy) -> bool {
    match t_p1 {
        crate::lower::model::OutTy::OutNamed(n_p2, _) => match type_of(cp_p0, n_p2) {
            Some(info_p3) => (&info_p3.kind != &Text::lit("node")) && (&info_p3.kind != &Text::lit("job")),
            None => false,
        },
        crate::lower::model::OutTy::OutCell(_) => false,
        crate::lower::model::OutTy::OutPort(_) => false,
        crate::lower::model::OutTy::OutHold(_) => false,
        crate::lower::model::OutTy::OutStamped(_) => false,
        crate::lower::model::OutTy::OutSnapshot(_) => false,
        crate::lower::model::OutTy::OutDefer(_) => false,
        crate::lower::model::OutTy::OutObj(_) => false,
        crate::lower::model::OutTy::OutWakes => false,
        _ => true,
    }
}
