//! The module `Emit.Cpp.Items`, from `target/bootstrap/src/prismc/emit/cpp/items.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Parts`:
///
/// ```prism
/// type Parts = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Parts {
    pub forward: Array<Text>,
    pub handles: Array<Text>,
    pub values: Array<ValueDecl>,
    pub cases: Array<Text>,
    pub protos: Array<Text>,
    pub classes: Array<Text>,
    pub outer: Array<Text>,
    pub generic: Array<Text>,
    pub defs: Array<Text>,
}

impl Show for Parts {
    fn show(&self, p: &mut Printer) {
        p.record("Parts", &[("forward", &self.forward), ("handles", &self.handles), ("values", &self.values), ("cases", &self.cases), ("protos", &self.protos), ("classes", &self.classes), ("outer", &self.outer), ("generic", &self.generic), ("defs", &self.defs)]);
    }
}

impl ToPod for Parts {
    fn to_pod(&self) -> Pod {
        Pod::record("Parts", vec![("forward", self.forward.to_pod()), ("handles", self.handles.to_pod()), ("values", self.values.to_pod()), ("cases", self.cases.to_pod()), ("protos", self.protos.to_pod()), ("classes", self.classes.to_pod()), ("outer", self.outer.to_pod()), ("generic", self.generic.to_pod()), ("defs", self.defs.to_pod())])
    }
}

impl FromPod for Parts {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Parts { forward: FromPod::from_pod(field(p, "forward")?)?, handles: FromPod::from_pod(field(p, "handles")?)?, values: FromPod::from_pod(field(p, "values")?)?, cases: FromPod::from_pod(field(p, "cases")?)?, protos: FromPod::from_pod(field(p, "protos")?)?, classes: FromPod::from_pod(field(p, "classes")?)?, outer: FromPod::from_pod(field(p, "outer")?)?, generic: FromPod::from_pod(field(p, "generic")?)?, defs: FromPod::from_pod(field(p, "defs")?)? })
    }
}

/// `ValueDecl`:
///
/// ```prism
/// type ValueDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ValueDecl {
    pub path_: Text,
    pub deps: Array<Text>,
    pub text: Text,
}

impl Show for ValueDecl {
    fn show(&self, p: &mut Printer) {
        p.record("ValueDecl", &[("path", &self.path_), ("deps", &self.deps), ("text", &self.text)]);
    }
}

impl ToPod for ValueDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("ValueDecl", vec![("path", self.path_.to_pod()), ("deps", self.deps.to_pod()), ("text", self.text.to_pod())])
    }
}

impl FromPod for ValueDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ValueDecl { path_: FromPod::from_pod(field(p, "path")?)?, deps: FromPod::from_pod(field(p, "deps")?)?, text: FromPod::from_pod(field(p, "text")?)? })
    }
}

/// ```prism
/// CppTemplateHead: fn [Text] -> Text
/// ```
pub fn cpp_template_head(xs0: &Array<Text>) -> Text {
    match xs0 {
        c0_0 if (c0_0.len() == 0) => Text::lit(""),
        ps => Text::from(format!("template <{}>\n", &crate::syntax::lexer::chars::join(&each(ps, &(|p_: &Text| Text::from(format!("class {}", p_)))), &Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// GenericNamesOf: fn [((Text, [Text]))] -> [Text]
/// ```
pub fn generic_names_of(gs: &Array<(Text, Array<Text>)>) -> Array<Text> {
    each(gs, &(|(g, _): &(Text, Array<Text>)| g.clone()))
}

/// ```prism
/// HeadOf: fn Text, [Text] -> Text
/// ```
pub fn head_of(name: &Text, xs1: &Array<Text>) -> Text {
    match xs1 {
        c0_1 if (c0_1.len() == 0) => name.clone(),
        ps => Text::from(format!("{}<{}>", name, &crate::syntax::lexer::chars::join(ps, &Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CppParams: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub fn cpp_params(cp: &crate::emit::cpp::Cp, ps: &Array<(Text, crate::lower::model::OutTy)>) -> Text {
    crate::syntax::lexer::chars::join(&run_to_end(each_job(ps.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (n, t) = p0;
                call_then(crate::emit::cpp::expr::start_param_type(cp.clone(), t.clone()), move |param_type_1510: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_1510, &crate::emit::cpp::cpp_id(&n)))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "))
}

/// The step machine of `CppParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppParams: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub struct CppParams {
    pub cp: crate::emit::cpp::Cp,
    pub ps: Array<(Text, crate::lower::model::OutTy)>,
}

impl prism_rtl::Job<Text> for CppParams {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let ps = &self.ps;
        let cp = cp.clone();
        let ps = ps.clone();
        call_value(each_job(ps.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let (n, t) = p0;
                    call_then(crate::emit::cpp::expr::start_param_type(cp.clone(), t.clone()), move |param_type_1510: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_1510, &crate::emit::cpp::cpp_id(&n)))))
                }))
            }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_1487: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&each_1487, &Text::lit(", "))))
    }
}

/// `Start CppParams, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_params(cp: crate::emit::cpp::Cp, ps: Array<(Text, crate::lower::model::OutTy)>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppParams { cp, ps })
}

/// ```prism
/// FnSignature: unbounded fn Cp, FnDef -> Text
/// ```
pub fn fn_signature(cp: &crate::emit::cpp::Cp, f: &crate::lower::model::FnDef) -> Text {
    Text::from(format!("{}{} {}({})", &cpp_template_head(&generic_names_of(&f.generics)), &crate::emit::cpp::cpp_type(cp, &f.ret), &crate::emit::cpp::cpp_id(&f.name), &cpp_params(cp, &f.params)))
}

/// The step machine of `FnSignature`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnSignature: unbounded fn Cp, FnDef -> Text
/// ```
pub struct FnSignature {
    pub cp: crate::emit::cpp::Cp,
    pub f: crate::lower::model::FnDef,
}

impl prism_rtl::Job<Text> for FnSignature {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let f = &self.f;
        let cp = cp.clone();
        let f = f.clone();
        call_then(crate::emit::cpp::start_cpp_type(cp.clone(), f.ret.clone()), move |cpp_type_1741: Text| call_then(start_cpp_params(cp.clone(), f.params.clone()), move |cpp_params_1776: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{} {}({})", &cpp_template_head(&generic_names_of(&f.generics)), &cpp_type_1741, &crate::emit::cpp::cpp_id(&f.name), &cpp_params_1776)))))
    }
}

/// `Start FnSignature, x`: what the function value is when passed to `@Run`.
pub fn start_fn_signature(cp: crate::emit::cpp::Cp, f: crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FnSignature { cp, f })
}

/// ```prism
/// FnDefinition: unbounded fn Cp, FnDef -> Text
/// ```
pub fn fn_definition(cp: &crate::emit::cpp::Cp, f: &crate::lower::model::FnDef) -> Text {
    crate::emit::cpp::templates::items::cpp_function(&cpp_doc(&f.doc), &fn_signature(cp, f), &crate::emit::cpp::stmts::cpp_body(cp, &f.body))
}

/// The step machine of `FnDefinition`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnDefinition: unbounded fn Cp, FnDef -> Text
/// ```
pub struct FnDefinition {
    pub cp: crate::emit::cpp::Cp,
    pub f: crate::lower::model::FnDef,
}

impl prism_rtl::Job<Text> for FnDefinition {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let f = &self.f;
        let cp = cp.clone();
        let f = f.clone();
        call_then(start_fn_signature(cp.clone(), f.clone()), move |fn_signature_1901: Text| call_then(crate::emit::cpp::stmts::start_cpp_body(cp.clone(), f.body.clone()), move |cpp_body_1922: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&cpp_doc(&f.doc), &fn_signature_1901, &cpp_body_1922))))
    }
}

/// `Start FnDefinition, x`: what the function value is when passed to `@Run`.
pub fn start_fn_definition(cp: crate::emit::cpp::Cp, f: crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FnDefinition { cp, f })
}

/// ```prism
/// ValueDeps: unbounded fn Cp, OutTy -> [Text]
/// ```
pub fn value_deps(cp: &crate::emit::cpp::Cp, t: &crate::lower::model::OutTy) -> Array<Text> {
    match t {
        crate::lower::model::OutTy::OutNamed(n, args) => {
            let own = match crate::emit::cpp::type_of(cp, n) {
                Some(info) => if (((&info.kind == &Text::lit("record")) || (&info.kind == &Text::lit("newtype"))) || (&info.kind == &Text::lit("unit"))) || (&info.kind == &Text::lit("tag")) {
                    Array::from(vec![crate::emit::cpp::absolute(cp, n)])
                } else {
                    Array::new()
                },
                None => Array::new(),
            };
            append(&own, &crate::emit::cpp::patterns::concat2(&run_to_end(each_job(args.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: crate::lower::model::OutTy| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: a.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }))))
        },
        crate::lower::model::OutTy::OutOpt(i) => value_deps(cp, &**i),
        crate::lower::model::OutTy::OutRes(i) => value_deps(cp, &**i),
        crate::lower::model::OutTy::OutRc(i) => value_deps(cp, &**i),
        crate::lower::model::OutTy::OutCell(i) => value_deps(cp, &**i),
        crate::lower::model::OutTy::OutTuple(ts) => crate::emit::cpp::patterns::concat2(&run_to_end(each_job(ts.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: crate::lower::model::OutTy| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }))),
        _ => Array::new(),
    }
}

/// The step machine of `ValueDeps`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ValueDeps: unbounded fn Cp, OutTy -> [Text]
/// ```
pub struct ValueDeps {
    pub cp: crate::emit::cpp::Cp,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Array<Text>> for ValueDeps {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cp = &self.cp;
        let t = &self.t;
        match t {
            crate::lower::model::OutTy::OutNamed(n, args) => {
                let own = match crate::emit::cpp::type_of(cp, n) {
                    Some(info) => if (((&info.kind == &Text::lit("record")) || (&info.kind == &Text::lit("newtype"))) || (&info.kind == &Text::lit("unit"))) || (&info.kind == &Text::lit("tag")) {
                        Array::from(vec![crate::emit::cpp::absolute(cp, n)])
                    } else {
                        Array::new()
                    },
                    None => Array::new(),
                };
                let args = args.clone();
                let cp = cp.clone();
                call_value(each_job(args.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: crate::lower::model::OutTy| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: a.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_3037: Array<Array<Text>>| prism_rtl::Turn::Finished(append(&own, &crate::emit::cpp::patterns::concat2(&each_3037))))
            },
            crate::lower::model::OutTy::OutOpt(i) => prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: (**i).clone() })),
            crate::lower::model::OutTy::OutRes(i) => prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: (**i).clone() })),
            crate::lower::model::OutTy::OutRc(i) => prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: (**i).clone() })),
            crate::lower::model::OutTy::OutCell(i) => prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: (**i).clone() })),
            crate::lower::model::OutTy::OutTuple(ts) => {
                let cp = cp.clone();
                let ts = ts.clone();
                call_value(each_job(ts.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: crate::lower::model::OutTy| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: a.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_3217: Array<Array<Text>>| prism_rtl::Turn::Finished(crate::emit::cpp::patterns::concat2(&each_3217)))
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start ValueDeps, x`: what the function value is when passed to `@Run`.
pub fn start_value_deps(cp: crate::emit::cpp::Cp, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ValueDeps { cp, t })
}

/// ```prism
/// let noParts
/// ```
pub fn no_parts() -> Parts {
    Parts { forward: Array::new(), handles: Array::new(), values: Array::new(), cases: Array::new(), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: Array::new() }
}

/// ```prism
/// JoinParts: fn Parts, Parts -> Parts
/// ```
pub fn join_parts(a: &Parts, b: &Parts) -> Parts {
    Parts { forward: append(&a.forward, &b.forward), handles: append(&a.handles, &b.handles), values: append(&a.values, &b.values), cases: append(&a.cases, &b.cases), protos: append(&a.protos, &b.protos), classes: append(&a.classes, &b.classes), outer: append(&a.outer, &b.outer), generic: append(&a.generic, &b.generic), defs: append(&a.defs, &b.defs) }
}

/// ```prism
/// ItemParts: unbounded fn Cp, Item -> Parts
/// ```
pub fn item_parts(cp: &crate::emit::cpp::Cp, it: &crate::lower::model::Item) -> Parts {
    match it {
        crate::lower::model::Item::ItType(t) => type_parts(cp, t),
        crate::lower::model::Item::ItTag(t) => tag_parts(cp, t),
        crate::lower::model::Item::ItRow(r) => row_parts(cp, &cp.home, r),
        crate::lower::model::Item::ItFn(f) => fn_parts(cp, f),
        crate::lower::model::Item::ItJob(j) => job_parts(cp, j),
        crate::lower::model::Item::ItNode(n) => crate::emit::cpp::program::node_parts(cp, n),
        crate::lower::model::Item::ItTrait(t) => trait_parts(cp, t),
        crate::lower::model::Item::ItImpl(i) => impl_parts(cp, i),
        crate::lower::model::Item::ItNote(t) => protos_defs(&Array::new(), &Array::from(vec![Text::from(format!("// {}", t))])),
        crate::lower::model::Item::ItRefused(t) => protos_defs(&Array::new(), &Array::from(vec![Text::from(format!("compile_error!(\"{}{}\");", &crate::lower::expr::lowering_refusal(), &crate::lower::expr::escape(t)))])),
    }
}

/// The step machine of `ItemParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ItemParts: unbounded fn Cp, Item -> Parts
/// ```
pub struct ItemParts {
    pub cp: crate::emit::cpp::Cp,
    pub it: crate::lower::model::Item,
}

impl prism_rtl::Job<Parts> for ItemParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let it = &self.it;
        match it {
            crate::lower::model::Item::ItType(t) => prism_rtl::Turn::More(Rc::new(TypeParts { cp: cp.clone(), t: t.clone() })),
            crate::lower::model::Item::ItTag(t) => prism_rtl::Turn::More(Rc::new(TagParts { cp: cp.clone(), t: t.clone() })),
            crate::lower::model::Item::ItRow(r) => prism_rtl::Turn::More(Rc::new(RowParts { cp: cp.clone(), m: cp.home.clone(), r: r.clone() })),
            crate::lower::model::Item::ItFn(f) => prism_rtl::Turn::More(Rc::new(FnParts { cp: cp.clone(), f: f.clone() })),
            crate::lower::model::Item::ItJob(j) => prism_rtl::Turn::More(Rc::new(JobParts { cp: cp.clone(), j: j.clone() })),
            crate::lower::model::Item::ItNode(n) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::program::NodeParts { cp: cp.clone(), n: n.clone() })),
            crate::lower::model::Item::ItTrait(t) => prism_rtl::Turn::More(Rc::new(TraitParts { cp: cp.clone(), t: t.clone() })),
            crate::lower::model::Item::ItImpl(i) => prism_rtl::Turn::More(Rc::new(ImplParts { cp: cp.clone(), i: i.clone() })),
            crate::lower::model::Item::ItNote(t) => prism_rtl::Turn::Finished(protos_defs(&Array::new(), &Array::from(vec![Text::from(format!("// {}", t))]))),
            crate::lower::model::Item::ItRefused(t) => prism_rtl::Turn::Finished(protos_defs(&Array::new(), &Array::from(vec![Text::from(format!("compile_error!(\"{}{}\");", &crate::lower::expr::lowering_refusal(), &crate::lower::expr::escape(t)))]))),
        }
    }
}

/// `Start ItemParts, x`: what the function value is when passed to `@Run`.
pub fn start_item_parts(cp: crate::emit::cpp::Cp, it: crate::lower::model::Item) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(ItemParts { cp, it })
}

/// ```prism
/// FnParts: unbounded fn Cp, FnDef -> Parts
/// ```
pub fn fn_parts(cp: &crate::emit::cpp::Cp, f: &crate::lower::model::FnDef) -> Parts {
    if &len(&f.generics) > &Nat::from(0u32) {
        {
            let mut this: Parts = generic_only(&Array::from(vec![fn_definition(cp, f)]));
            this.protos = Array::from(vec![Text::from(format!("{};", &fn_signature(cp, f)))]);
            this
        }
    } else {
        protos_defs(&Array::from(vec![Text::from(format!("{};", &fn_signature(cp, f)))]), &Array::from(vec![fn_definition(cp, f)]))
    }
}

/// The step machine of `FnParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnParts: unbounded fn Cp, FnDef -> Parts
/// ```
pub struct FnParts {
    pub cp: crate::emit::cpp::Cp,
    pub f: crate::lower::model::FnDef,
}

impl prism_rtl::Job<Parts> for FnParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let f = &self.f;
        if &len(&f.generics) > &Nat::from(0u32) {
            prism_rtl::Turn::Finished({
                let mut this: Parts = generic_only(&Array::from(vec![fn_definition(cp, f)]));
                this.protos = Array::from(vec![Text::from(format!("{};", &fn_signature(cp, f)))]);
                this
            })
        } else {
            {
                let cp = cp.clone();
                let f = f.clone();
                call_then(start_fn_signature(cp.clone(), f.clone()), move |fn_signature_4451: Text| call_then(start_fn_definition(cp.clone(), f.clone()), move |fn_definition_4478: Text| prism_rtl::Turn::Finished(protos_defs(&Array::from(vec![Text::from(format!("{};", &fn_signature_4451))]), &Array::from(vec![fn_definition_4478])))))
            }
        }
    }
}

/// `Start FnParts, x`: what the function value is when passed to `@Run`.
pub fn start_fn_parts(cp: crate::emit::cpp::Cp, f: crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(FnParts { cp, f })
}

/// ```prism
/// CppDoc: fn Text -> Text
/// ```
pub fn cpp_doc(text: &Text) -> Text {
    if text == &Text::lit("") {
        Text::lit("")
    } else {
        concat(&each(&split_on(text, &Text::lit("\n")), &(|l: &Text| if l == &Text::lit("") {
            Text::lit("///\n")
        } else {
            Text::from(format!("/// {}\n", l))
        })))
    }
}

/// ```prism
/// CppSourceDoc: fn Text, Text -> Text
/// ```
pub fn cpp_source_doc(lead: &Text, source: &Text) -> Text {
    let quoted = concat(&each(&split_on(source, &Text::lit("\n")), &(|l: &Text| if l == &Text::lit("") {
        Text::lit("///\n")
    } else {
        Text::from(format!("/// {}\n", l))
    })));
    if source == &Text::lit("") {
        cpp_doc(lead)
    } else {
        if lead == &Text::lit("") {
            Text::from(format!("/// ```prism\n{}/// ```\n", &quoted))
        } else {
            Text::from(format!("/// {}\n///\n/// ```prism\n{}/// ```\n", lead, &quoted))
        }
    }
}

/// ```prism
/// TypeParts: unbounded fn Cp, TyDef -> Parts
/// ```
pub fn type_parts(cp: &crate::emit::cpp::Cp, t: &crate::lower::model::TyDef) -> Parts {
    let eq = t.eq;
    let ord = t.ord && !t.floaty;
    let gens = cpp_template_head(&t.params);
    let head = head_of(&t.name, &t.params);
    let doc = cpp_source_doc(&Text::from(format!("`{}`:", &t.prism)), &t.doc);
    let members_ = members(&(&t.show != &crate::lower::model::Shown::NotShown), &t.pod, &head);
    let generic = &len(&t.params) > &Nat::from(0u32);
    let fwd = Text::from(format!("{}{} {};", &gens, &(if &t.shape == &crate::lower::model::TyShape::ShapeChoice {
        Text::lit("class")
    } else {
        Text::lit("struct")
    }), &t.name));
    match &t.shape {
        crate::lower::model::TyShape::ShapeChoice => {
            let names = each(&t.cases, &(|c: &crate::lower::model::CaseDef| c.name.clone()));
            let friend_eq = if eq && !generic {
                Text::from(format!("\nfriend inline bool operator==(const {}& a, const {}& b);", &head, &head))
            } else {
                Text::lit("")
            };
            let handle = crate::emit::cpp::templates::items::choice_handle(&doc, &gens, &t.name, &crate::syntax::lexer::chars::join(&each(&names, &(|n: &Text| Text::from(format!("struct {};", n)))), &Text::lit("\n")), &crate::syntax::lexer::chars::join(&names, &Text::lit(", ")), &Text::from(format!("{}{}", &members_, &friend_eq)));
            let cases = run_to_end(each_job(t.cases.clone(), {
                let cp = cp.clone();
                let gens = gens.clone();
                let head = head.clone();
                let eq = eq;
                let ord = ord;
                Rc::new(move |p0: crate::lower::model::CaseDef| {
                    let cp = cp.clone();
                    let gens = gens.clone();
                    let head = head.clone();
                    let eq = eq;
                    let ord = ord;
                    entered(once_job(move || {
                        let c = p0;
                        prism_rtl::Turn::More(Rc::new(CaseStruct { cp: cp.clone(), gens: gens.clone(), head: head.clone(), c: c.clone(), eq, ord }))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            let cmp = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![if eq {
                Text::from(format!("{}inline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &gens, &head, &head))
            } else {
                Text::lit("")
            }, if ord {
                Text::from(format!("{}inline auto operator<=>(const {}& a, const {}& b) {{ return a.cases() <=> b.cases(); }}", &gens, &head, &head))
            } else {
                Text::lit("")
            }]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n"));
            let defs = type_defs(cp, t, &head);
            Parts { forward: Array::from(vec![fwd.clone()]), handles: Array::from(vec![handle.clone()]), values: Array::new(), cases: append(&cases, &Array::from(vec![cases_accessor(&gens, &head), cmp.clone()])), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: if generic { Array::from(vec![defs.clone()]) } else { Array::new() }, defs: if generic { Array::new() } else { Array::from(vec![defs.clone()]) } }
        },
        _ => {
            let first_ = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            let fields = match &t.shape {
                crate::lower::model::TyShape::ShapeRecord => crate::syntax::lexer::chars::join(&run_to_end(each_job(first_.fields.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let (f, ft) = p0;
                            call_then(crate::emit::cpp::start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_7094: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_7094, &crate::emit::cpp::field_id(&f)))))
                        }))
                    }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
                })), &Text::lit("\n")),
                crate::lower::model::TyShape::ShapeNewtype => positional_fields(cp, &first_.fields),
                _ => Text::lit(""),
            };
            let cmps = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![if eq {
                Text::from(format!("bool operator==(const {}&) const = default;", &t.name))
            } else {
                Text::lit("")
            }, if ord {
                Text::from(format!("auto operator<=>(const {}&) const = default;", &t.name))
            } else {
                Text::lit("")
            }]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n"));
            let decl = crate::emit::cpp::templates::items::value_struct(&doc, &gens, &t.name, &fields, &crate::syntax::lexer::chars::join(&filter(&Array::from(vec![cmps.clone(), members_.clone()]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n")));
            let defs = type_defs(cp, t, &head);
            let deps = crate::emit::cpp::patterns::concat2(&run_to_end(each_job(first_.fields.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let (_, ft) = p0;
                        prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: ft.clone() }))
                    }))
                }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            })));
            Parts { forward: Array::from(vec![fwd.clone()]), handles: Array::new(), values: Array::from(vec![ValueDecl { path_: Text::from(format!("{}::{}", &cp.home, &t.name)), deps: deps.clone(), text: decl.clone() }]), cases: Array::new(), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: if generic { Array::from(vec![defs.clone()]) } else { Array::new() }, defs: if generic { Array::new() } else { Array::from(vec![defs.clone()]) } }
        },
    }
}

/// The step machine of `TypeParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeParts: unbounded fn Cp, TyDef -> Parts
/// ```
pub struct TypeParts {
    pub cp: crate::emit::cpp::Cp,
    pub t: crate::lower::model::TyDef,
}

impl prism_rtl::Job<Parts> for TypeParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let t = &self.t;
        let eq = t.eq;
        let ord = t.ord && !t.floaty;
        let gens = cpp_template_head(&t.params);
        let head = head_of(&t.name, &t.params);
        let doc = cpp_source_doc(&Text::from(format!("`{}`:", &t.prism)), &t.doc);
        let members_ = members(&(&t.show != &crate::lower::model::Shown::NotShown), &t.pod, &head);
        let generic = &len(&t.params) > &Nat::from(0u32);
        let fwd = Text::from(format!("{}{} {};", &gens, &(if &t.shape == &crate::lower::model::TyShape::ShapeChoice {
            Text::lit("class")
        } else {
            Text::lit("struct")
        }), &t.name));
        match &t.shape {
            crate::lower::model::TyShape::ShapeChoice => {
                let names = each(&t.cases, &(|c: &crate::lower::model::CaseDef| c.name.clone()));
                let friend_eq = if eq && !generic {
                    Text::from(format!("\nfriend inline bool operator==(const {}& a, const {}& b);", &head, &head))
                } else {
                    Text::lit("")
                };
                let handle = crate::emit::cpp::templates::items::choice_handle(&doc, &gens, &t.name, &crate::syntax::lexer::chars::join(&each(&names, &(|n: &Text| Text::from(format!("struct {};", n)))), &Text::lit("\n")), &crate::syntax::lexer::chars::join(&names, &Text::lit(", ")), &Text::from(format!("{}{}", &members_, &friend_eq)));
                let cp = cp.clone();
                let t = t.clone();
                call_value(each_job(t.cases.clone(), {
                    let cp = cp.clone();
                    let gens = gens.clone();
                    let head = head.clone();
                    let eq = eq;
                    let ord = ord;
                    Rc::new(move |p0: crate::lower::model::CaseDef| {
                        let cp = cp.clone();
                        let gens = gens.clone();
                        let head = head.clone();
                        let eq = eq;
                        let ord = ord;
                        entered(once_job(move || {
                            let c = p0;
                            prism_rtl::Turn::More(Rc::new(CaseStruct { cp: cp.clone(), gens: gens.clone(), head: head.clone(), c: c.clone(), eq, ord }))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_6231: Array<Text>| {
                    let cases = each_6231;
                    let cmp = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![if eq {
                        Text::from(format!("{}inline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &gens, &head, &head))
                    } else {
                        Text::lit("")
                    }, if ord {
                        Text::from(format!("{}inline auto operator<=>(const {}& a, const {}& b) {{ return a.cases() <=> b.cases(); }}", &gens, &head, &head))
                    } else {
                        Text::lit("")
                    }]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n"));
                    call_then(start_type_defs(cp.clone(), t.clone(), head.clone()), move |type_defs_6615: Text| {
                        let defs = type_defs_6615;
                        prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![fwd.clone()]), handles: Array::from(vec![handle.clone()]), values: Array::new(), cases: append(&cases, &Array::from(vec![cases_accessor(&gens, &head), cmp.clone()])), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: if generic { Array::from(vec![defs.clone()]) } else { Array::new() }, defs: if generic { Array::new() } else { Array::from(vec![defs.clone()]) } })
                    })
                })
            },
            _ => {
                let first_ = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                let fields = match &t.shape {
                    crate::lower::model::TyShape::ShapeRecord => crate::syntax::lexer::chars::join(&run_to_end(each_job(first_.fields.clone(), {
                        let cp = cp.clone();
                        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                            let cp = cp.clone();
                            entered(once_job(move || {
                                let (f, ft) = p0;
                                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_7094: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_7094, &crate::emit::cpp::field_id(&f)))))
                            }))
                        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
                    })), &Text::lit("\n")),
                    crate::lower::model::TyShape::ShapeNewtype => positional_fields(cp, &first_.fields),
                    _ => Text::lit(""),
                };
                let cmps = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![if eq {
                    Text::from(format!("bool operator==(const {}&) const = default;", &t.name))
                } else {
                    Text::lit("")
                }, if ord {
                    Text::from(format!("auto operator<=>(const {}&) const = default;", &t.name))
                } else {
                    Text::lit("")
                }]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n"));
                let decl = crate::emit::cpp::templates::items::value_struct(&doc, &gens, &t.name, &fields, &crate::syntax::lexer::chars::join(&filter(&Array::from(vec![cmps.clone(), members_.clone()]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n")));
                let cp = cp.clone();
                let t = t.clone();
                call_then(start_type_defs(cp.clone(), t.clone(), head.clone()), move |type_defs_7568: Text| {
                    let defs = type_defs_7568;
                    call_value(each_job(first_.fields.clone(), {
                        let cp = cp.clone();
                        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                            let cp = cp.clone();
                            entered(once_job(move || {
                                let (_, ft) = p0;
                                prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: ft.clone() }))
                            }))
                        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }), move |each_7621: Array<Array<Text>>| {
                        let deps = crate::emit::cpp::patterns::concat2(&each_7621);
                        prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![fwd.clone()]), handles: Array::new(), values: Array::from(vec![ValueDecl { path_: Text::from(format!("{}::{}", &cp.home, &t.name)), deps: deps.clone(), text: decl.clone() }]), cases: Array::new(), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: if generic { Array::from(vec![defs.clone()]) } else { Array::new() }, defs: if generic { Array::new() } else { Array::from(vec![defs.clone()]) } })
                    })
                })
            },
        }
    }
}

/// `Start TypeParts, x`: what the function value is when passed to `@Run`.
pub fn start_type_parts(cp: crate::emit::cpp::Cp, t: crate::lower::model::TyDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(TypeParts { cp, t })
}

/// ```prism
/// CasesAccessor: fn Text, Text -> Text
/// ```
pub fn cases_accessor(gens: &Text, head: &Text) -> Text {
    Text::from(format!("{}inline const {}{}::Cases& {}::cases() const {{ return *cases_; }}", gens, &(if gens == &Text::lit("") { Text::lit("") } else { Text::lit("typename ") }), head, head))
}

/// ```prism
/// Members: fn Bool, Bool, Text -> Text
/// ```
pub fn members(shown: &bool, pod: &bool, head: &Text) -> Text {
    let s = if *shown {
        Array::from(vec![Text::lit("void show(Printer& p) const;")])
    } else {
        Array::new()
    };
    let d = if *pod {
        Array::from(vec![Text::lit("Pod to_pod() const;"), Text::from(format!("static Result<{}> from_pod(const Pod& whole);", head))])
    } else {
        Array::new()
    };
    crate::syntax::lexer::chars::join(&append(&s, &d), &Text::lit("\n"))
}

/// ```prism
/// CaseStruct: unbounded fn Cp, Text, Text, CaseDef, Bool, Bool -> Text
/// ```
pub fn case_struct(cp: &crate::emit::cpp::Cp, gens: &Text, head: &Text, c: &crate::lower::model::CaseDef, eq: &bool, ord: &bool) -> Text {
    let fields = positional_fields(cp, &c.fields);
    let cmps = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![if *eq {
        Text::from(format!("bool operator==(const {}&) const = default;", &c.name))
    } else {
        Text::lit("")
    }, if *ord {
        Text::from(format!("auto operator<=>(const {}&) const = default;", &c.name))
    } else {
        Text::lit("")
    }]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n"));
    crate::emit::cpp::templates::items::case_decl(gens, &Text::from(format!("{}::{}", head, &c.name)), &crate::syntax::lexer::chars::join(&filter(&Array::from(vec![fields.clone(), cmps.clone()]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n")))
}

/// The step machine of `CaseStruct`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CaseStruct: unbounded fn Cp, Text, Text, CaseDef, Bool, Bool -> Text
/// ```
pub struct CaseStruct {
    pub cp: crate::emit::cpp::Cp,
    pub gens: Text,
    pub head: Text,
    pub c: crate::lower::model::CaseDef,
    pub eq: bool,
    pub ord: bool,
}

impl prism_rtl::Job<Text> for CaseStruct {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let gens = &self.gens;
        let head = &self.head;
        let c = &self.c;
        let eq = &self.eq;
        let ord = &self.ord;
        let c = c.clone();
        let cp = cp.clone();
        let eq = *eq;
        let gens = gens.clone();
        let head = head.clone();
        let ord = *ord;
        call_then(start_positional_fields(cp.clone(), c.fields.clone()), move |positional_fields_8648: Text| {
            let fields = positional_fields_8648;
            let cmps = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![if eq {
                Text::from(format!("bool operator==(const {}&) const = default;", &c.name))
            } else {
                Text::lit("")
            }, if ord {
                Text::from(format!("auto operator<=>(const {}&) const = default;", &c.name))
            } else {
                Text::lit("")
            }]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n"));
            prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::case_decl(&gens, &Text::from(format!("{}::{}", &head, &c.name)), &crate::syntax::lexer::chars::join(&filter(&Array::from(vec![fields.clone(), cmps.clone()]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n"))))
        })
    }
}

/// `Start CaseStruct, x`: what the function value is when passed to `@Run`.
pub fn start_case_struct(cp: crate::emit::cpp::Cp, gens: Text, head: Text, c: crate::lower::model::CaseDef, eq: bool, ord: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CaseStruct { cp, gens, head, c, eq, ord })
}

/// ```prism
/// TypeDefs: unbounded fn Cp, TyDef, Text -> Text
/// ```
pub fn type_defs(cp: &crate::emit::cpp::Cp, t: &crate::lower::model::TyDef, head: &Text) -> Text {
    let gens = cpp_template_head(&t.params);
    let show_ = if &t.show == &crate::lower::model::Shown::ShownDerived {
        Array::from(vec![show_def(cp, t, head, &gens)])
    } else {
        Array::new()
    };
    let pod = if t.pod {
        Array::from(vec![to_pod_def(cp, t, head, &gens), from_pod_def(cp, t, head, &gens)])
    } else {
        Array::new()
    };
    crate::syntax::lexer::chars::join(&append(&show_, &pod), &Text::lit("\n"))
}

/// The step machine of `TypeDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeDefs: unbounded fn Cp, TyDef, Text -> Text
/// ```
pub struct TypeDefs {
    pub cp: crate::emit::cpp::Cp,
    pub t: crate::lower::model::TyDef,
    pub head: Text,
}

impl prism_rtl::Job<Text> for TypeDefs {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let t = &self.t;
        let head = &self.head;
        let gens = cpp_template_head(&t.params);
        let show_ = if &t.show == &crate::lower::model::Shown::ShownDerived {
            Array::from(vec![show_def(cp, t, head, &gens)])
        } else {
            Array::new()
        };
        let pod = if t.pod {
            Array::from(vec![to_pod_def(cp, t, head, &gens), from_pod_def(cp, t, head, &gens)])
        } else {
            Array::new()
        };
        prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&append(&show_, &pod), &Text::lit("\n")))
    }
}

/// `Start TypeDefs, x`: what the function value is when passed to `@Run`.
pub fn start_type_defs(cp: crate::emit::cpp::Cp, t: crate::lower::model::TyDef, head: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TypeDefs { cp, t, head })
}

/// ```prism
/// ShowDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub fn show_def(cp: &crate::emit::cpp::Cp, t: &crate::lower::model::TyDef, head: &Text, gens: &Text) -> Text {
    let body = match &t.shape {
        crate::lower::model::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            Text::from(format!("p.record(\"{}\", {{{}}});", &t.prism, &crate::syntax::lexer::chars::join(&each(&c.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", {}}}", &prism_field(f), &crate::emit::cpp::field_id(f))))), &Text::lit(", "))))
        },
        crate::lower::model::TyShape::ShapeChoice => crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&len(&t.cases)), &(|i: &Nat| show_case(t, i))), &Text::lit("\n")),
        crate::lower::model::TyShape::ShapeNewtype => Text::from(format!("p.choice(\"{}\", {{{}}});", &first_case(t), &crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&first_arity(t)), &(|k: &Nat| Text::from(format!("a{}", k)))), &Text::lit(", ")))),
        crate::lower::model::TyShape::ShapeUnit => Text::from(format!("p.choice(\"{}\", {{}});", &first_case(t))),
    };
    crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}void {}::show(Printer& p) const", gens, head)), &body)
}

/// The step machine of `ShowDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub struct ShowDef {
    pub cp: crate::emit::cpp::Cp,
    pub t: crate::lower::model::TyDef,
    pub head: Text,
    pub gens: Text,
}

impl prism_rtl::Job<Text> for ShowDef {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let t = &self.t;
        let head = &self.head;
        let gens = &self.gens;
        let body = match &t.shape {
            crate::lower::model::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                Text::from(format!("p.record(\"{}\", {{{}}});", &t.prism, &crate::syntax::lexer::chars::join(&each(&c.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", {}}}", &prism_field(f), &crate::emit::cpp::field_id(f))))), &Text::lit(", "))))
            },
            crate::lower::model::TyShape::ShapeChoice => crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&len(&t.cases)), &(|i: &Nat| show_case(t, i))), &Text::lit("\n")),
            crate::lower::model::TyShape::ShapeNewtype => Text::from(format!("p.choice(\"{}\", {{{}}});", &first_case(t), &crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&first_arity(t)), &(|k: &Nat| Text::from(format!("a{}", k)))), &Text::lit(", ")))),
            crate::lower::model::TyShape::ShapeUnit => Text::from(format!("p.choice(\"{}\", {{}});", &first_case(t))),
        };
        prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}void {}::show(Printer& p) const", gens, head)), &body))
    }
}

/// `Start ShowDef, x`: what the function value is when passed to `@Run`.
pub fn start_show_def(cp: crate::emit::cpp::Cp, t: crate::lower::model::TyDef, head: Text, gens: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ShowDef { cp, t, head, gens })
}

/// ```prism
/// ShowCase: fn TyDef, Nat -> Text
/// ```
pub fn show_case(t: &crate::lower::model::TyDef, i: &Nat) -> Text {
    let c = or(&index(&t.cases, i), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
    let head = Text::from(format!("{} (auto c = std::get_if<{}>(&cases()))", &(if i == &Nat::from(0u32) { Text::lit("if") } else { Text::lit("else if") }), &c.name));
    Text::from(format!("{} p.choice(\"{}\", {{{}}});", &head, &c.prism, &crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&len(&c.fields)), &(|k: &Nat| Text::from(format!("c->a{}", k)))), &Text::lit(", "))))
}

/// ```prism
/// FirstCase: fn TyDef -> Text
/// ```
pub fn first_case(t: &crate::lower::model::TyDef) -> Text {
    or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: t.prism.clone(), fields: Array::new() }).prism.clone()
}

/// ```prism
/// FirstArity: fn TyDef -> Nat
/// ```
pub fn first_arity(t: &crate::lower::model::TyDef) -> Nat {
    len(&or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() }).fields)
}

/// ```prism
/// FieldTypes: fn [((Text, OutTy))] -> [OutTy]
/// ```
pub fn field_types(fs: &Array<(Text, crate::lower::model::OutTy)>) -> Array<crate::lower::model::OutTy> {
    each(fs, &(|(_, t): &(Text, crate::lower::model::OutTy)| t.clone()))
}

/// ```prism
/// PositionalFields: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub fn positional_fields(cp: &crate::emit::cpp::Cp, fs: &Array<(Text, crate::lower::model::OutTy)>) -> Text {
    let tys = field_types(fs);
    crate::syntax::lexer::chars::join(&run_to_end(each_job(crate::check::errors::range0(&len(&tys)), {
        let cp = cp.clone();
        let tys = tys.clone();
        Rc::new(move |p0: Nat| {
            let cp = cp.clone();
            let tys = tys.clone();
            entered(once_job(move || {
                let i = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), or(&index(&tys, &i), &crate::lower::model::OutTy::OutUnit)), move |cpp_type_10908: Text| prism_rtl::Turn::Finished(Text::from(format!("{} a{};", &cpp_type_10908, &i))))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"))
}

/// The step machine of `PositionalFields`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PositionalFields: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub struct PositionalFields {
    pub cp: crate::emit::cpp::Cp,
    pub fs: Array<(Text, crate::lower::model::OutTy)>,
}

impl prism_rtl::Job<Text> for PositionalFields {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let fs = &self.fs;
        let tys = field_types(fs);
        let cp = cp.clone();
        call_value(each_job(crate::check::errors::range0(&len(&tys)), {
            let cp = cp.clone();
            let tys = tys.clone();
            Rc::new(move |p0: Nat| {
                let cp = cp.clone();
                let tys = tys.clone();
                entered(once_job(move || {
                    let i = p0;
                    call_then(crate::emit::cpp::start_cpp_type(cp.clone(), or(&index(&tys, &i), &crate::lower::model::OutTy::OutUnit)), move |cpp_type_10908: Text| prism_rtl::Turn::Finished(Text::from(format!("{} a{};", &cpp_type_10908, &i))))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_10876: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&each_10876, &Text::lit("\n"))))
    }
}

/// `Start PositionalFields, x`: what the function value is when passed to `@Run`.
pub fn start_positional_fields(cp: crate::emit::cpp::Cp, fs: Array<(Text, crate::lower::model::OutTy)>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(PositionalFields { cp, fs })
}

/// ```prism
/// ToPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub fn to_pod_def(cp: &crate::emit::cpp::Cp, t: &crate::lower::model::TyDef, head: &Text, gens: &Text) -> Text {
    let structure = match &t.shape {
        crate::lower::model::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            Text::from(format!("Pod::record(\"{}\", {{{}}})", &t.prism, &crate::syntax::lexer::chars::join(&each(&c.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", prism_rtl::to_pod({})}}", &prism_field(f), &crate::emit::cpp::field_id(f))))), &Text::lit(", "))))
        },
        crate::lower::model::TyShape::ShapeChoice => choice_pod(t),
        crate::lower::model::TyShape::ShapeNewtype => Text::from(format!("Pod::choice(\"{}\", {{{}}})", &first_case(t), &crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&first_arity(t)), &(|k: &Nat| Text::from(format!("prism_rtl::to_pod(a{})", k)))), &Text::lit(", ")))),
        crate::lower::model::TyShape::ShapeUnit => Text::from(format!("Pod::choice(\"{}\", {{}})", &first_case(t))),
    };
    let body = if &t.show == &crate::lower::model::Shown::ShownOwn {
        Text::from(format!("Pod structure = {};\nreturn Pod::shown(prism_rtl::show(*this), structure);", &structure))
    } else {
        Text::from(format!("return {};", &structure))
    };
    crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}Pod {}::to_pod() const", gens, head)), &body)
}

/// The step machine of `ToPodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ToPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub struct ToPodDef {
    pub cp: crate::emit::cpp::Cp,
    pub t: crate::lower::model::TyDef,
    pub head: Text,
    pub gens: Text,
}

impl prism_rtl::Job<Text> for ToPodDef {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let t = &self.t;
        let head = &self.head;
        let gens = &self.gens;
        let structure = match &t.shape {
            crate::lower::model::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                Text::from(format!("Pod::record(\"{}\", {{{}}})", &t.prism, &crate::syntax::lexer::chars::join(&each(&c.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", prism_rtl::to_pod({})}}", &prism_field(f), &crate::emit::cpp::field_id(f))))), &Text::lit(", "))))
            },
            crate::lower::model::TyShape::ShapeChoice => choice_pod(t),
            crate::lower::model::TyShape::ShapeNewtype => Text::from(format!("Pod::choice(\"{}\", {{{}}})", &first_case(t), &crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&first_arity(t)), &(|k: &Nat| Text::from(format!("prism_rtl::to_pod(a{})", k)))), &Text::lit(", ")))),
            crate::lower::model::TyShape::ShapeUnit => Text::from(format!("Pod::choice(\"{}\", {{}})", &first_case(t))),
        };
        let body = if &t.show == &crate::lower::model::Shown::ShownOwn {
            Text::from(format!("Pod structure = {};\nreturn Pod::shown(prism_rtl::show(*this), structure);", &structure))
        } else {
            Text::from(format!("return {};", &structure))
        };
        prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}Pod {}::to_pod() const", gens, head)), &body))
    }
}

/// `Start ToPodDef, x`: what the function value is when passed to `@Run`.
pub fn start_to_pod_def(cp: crate::emit::cpp::Cp, t: crate::lower::model::TyDef, head: Text, gens: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ToPodDef { cp, t, head, gens })
}

/// ```prism
/// ChoicePod: fn TyDef -> Text
/// ```
pub fn choice_pod(t: &crate::lower::model::TyDef) -> Text {
    let arms = each(&crate::check::errors::range0(&len(&t.cases)), &(|i: &Nat| {
        let c = or(&index(&t.cases, i), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
        Text::from(format!("std::holds_alternative<{}>(cases()) ? Pod::choice(\"{}\", {{{}}})", &c.name, &c.prism, &crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&len(&c.fields)), &(|k: &Nat| Text::from(format!("prism_rtl::to_pod(std::get<{}>(cases()).a{})", &c.name, k)))), &Text::lit(", "))))
    }));
    Text::from(format!("{}\n    : Pod()", &crate::syntax::lexer::chars::join(&arms, &Text::lit("\n    : "))))
}

/// ```prism
/// FromPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub fn from_pod_def(cp: &crate::emit::cpp::Cp, t: &crate::lower::model::TyDef, head: &Text, gens: &Text) -> Text {
    let body = match &t.shape {
        crate::lower::model::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            let reads = crate::syntax::lexer::chars::join(&run_to_end(each_job(c.fields.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let (f, ft) = p0;
                        call_then(crate::emit::cpp::start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_12480: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = TRY(prism_rtl::from_pod<{}>(TRY(crate::prelude::field(whole, \"{}\"))))", &crate::emit::cpp::field_id(&f), &cpp_type_12480, &prism_field(&f)))))
                    }))
                }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
            })), &Text::lit(", "));
            Text::from(format!("return {}{{{}}};", head, &reads))
        },
        _ => {
            let arms = run_to_end(each_job(t.cases.clone(), {
                let cp = cp.clone();
                let t = t.clone();
                let head = head.clone();
                Rc::new(move |p0: crate::lower::model::CaseDef| {
                    let cp = cp.clone();
                    let t = t.clone();
                    let head = head.clone();
                    entered(once_job(move || {
                        let c = p0;
                        {
                            let n = len(&c.fields);
                            let tys = field_types(&c.fields);
                            call_value(each_job(crate::check::errors::range0(&n), {
                                let cp = cp.clone();
                                let tys = tys.clone();
                                Rc::new(move |p0: Nat| {
                                    let cp = cp.clone();
                                    let tys = tys.clone();
                                    entered(once_job(move || {
                                        let i = p0;
                                        call_then(crate::emit::cpp::start_cpp_type(cp.clone(), or(&index(&tys, &i), &crate::lower::model::OutTy::OutUnit)), move |cpp_type_12826: Text| prism_rtl::Turn::Finished(Text::from(format!("TRY(prism_rtl::from_pod<{}>(c->args[{}]))", &cpp_type_12826, &i))))
                                    }))
                                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
                            }), move |each_12778: Array<Text>| {
                                let args = crate::syntax::lexer::chars::join(&each_12778, &Text::lit(", "));
                                let made = match &t.shape {
                                    crate::lower::model::TyShape::ShapeChoice => Text::from(format!("{}({}{{{}}})", &head, &c.name, &args)),
                                    _ => Text::from(format!("{}{{{}}}", &head, &args)),
                                };
                                prism_rtl::Turn::Finished(Text::from(format!("if (c->ctor == \"{}\" && c->args.size() == {}) return {};", &c.prism, &n, &made)))
                            })
                        }
                    }))
                }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            Text::from(format!("const Pod& p = whole.structure();\nif (auto c = p.if_choice()) {{\n{}\n}}\nreturn mismatch<{}>(\"a {}\", p);", &indent_cpp(&crate::syntax::lexer::chars::join(&arms, &Text::lit("\n"))), head, &t.prism))
        },
    };
    crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}Result<{}> {}::from_pod(const Pod& whole)", gens, head, head)), &body)
}

/// The step machine of `FromPodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FromPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub struct FromPodDef {
    pub cp: crate::emit::cpp::Cp,
    pub t: crate::lower::model::TyDef,
    pub head: Text,
    pub gens: Text,
}

impl prism_rtl::Job<Text> for FromPodDef {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let t = &self.t;
        let head = &self.head;
        let gens = &self.gens;
        let body = match &t.shape {
            crate::lower::model::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                let reads = crate::syntax::lexer::chars::join(&run_to_end(each_job(c.fields.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let (f, ft) = p0;
                            call_then(crate::emit::cpp::start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_12480: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = TRY(prism_rtl::from_pod<{}>(TRY(crate::prelude::field(whole, \"{}\"))))", &crate::emit::cpp::field_id(&f), &cpp_type_12480, &prism_field(&f)))))
                        }))
                    }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
                })), &Text::lit(", "));
                Text::from(format!("return {}{{{}}};", head, &reads))
            },
            _ => {
                let arms = run_to_end(each_job(t.cases.clone(), {
                    let cp = cp.clone();
                    let t = t.clone();
                    let head = head.clone();
                    Rc::new(move |p0: crate::lower::model::CaseDef| {
                        let cp = cp.clone();
                        let t = t.clone();
                        let head = head.clone();
                        entered(once_job(move || {
                            let c = p0;
                            {
                                let n = len(&c.fields);
                                let tys = field_types(&c.fields);
                                call_value(each_job(crate::check::errors::range0(&n), {
                                    let cp = cp.clone();
                                    let tys = tys.clone();
                                    Rc::new(move |p0: Nat| {
                                        let cp = cp.clone();
                                        let tys = tys.clone();
                                        entered(once_job(move || {
                                            let i = p0;
                                            call_then(crate::emit::cpp::start_cpp_type(cp.clone(), or(&index(&tys, &i), &crate::lower::model::OutTy::OutUnit)), move |cpp_type_12826: Text| prism_rtl::Turn::Finished(Text::from(format!("TRY(prism_rtl::from_pod<{}>(c->args[{}]))", &cpp_type_12826, &i))))
                                        }))
                                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
                                }), move |each_12778: Array<Text>| {
                                    let args = crate::syntax::lexer::chars::join(&each_12778, &Text::lit(", "));
                                    let made = match &t.shape {
                                        crate::lower::model::TyShape::ShapeChoice => Text::from(format!("{}({}{{{}}})", &head, &c.name, &args)),
                                        _ => Text::from(format!("{}{{{}}}", &head, &args)),
                                    };
                                    prism_rtl::Turn::Finished(Text::from(format!("if (c->ctor == \"{}\" && c->args.size() == {}) return {};", &c.prism, &n, &made)))
                                })
                            }
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
                }));
                Text::from(format!("const Pod& p = whole.structure();\nif (auto c = p.if_choice()) {{\n{}\n}}\nreturn mismatch<{}>(\"a {}\", p);", &indent_cpp(&crate::syntax::lexer::chars::join(&arms, &Text::lit("\n"))), head, &t.prism))
            },
        };
        prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}Result<{}> {}::from_pod(const Pod& whole)", gens, head, head)), &body))
    }
}

/// `Start FromPodDef, x`: what the function value is when passed to `@Run`.
pub fn start_from_pod_def(cp: crate::emit::cpp::Cp, t: crate::lower::model::TyDef, head: Text, gens: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FromPodDef { cp, t, head, gens })
}

/// ```prism
/// PrismField: fn Text -> Text
/// ```
pub fn prism_field(f: &Text) -> Text {
    if &crate::syntax::lexer::chars::last_char(f) == &Text::lit("_") {
        crate::syntax::lexer::chars::before_last(f)
    } else {
        f.clone()
    }
}

/// ```prism
/// IndentCpp: fn Text -> Text
/// ```
pub fn indent_cpp(t: &Text) -> Text {
    crate::syntax::lexer::chars::join(&each(&split_on(t, &Text::lit("\n")), &(|l: &Text| if l == &Text::lit("") { Text::lit("") } else { Text::from(format!("    {}", l)) })), &Text::lit("\n"))
}

/// ```prism
/// TagParts: unbounded fn Cp, TagDef -> Parts
/// ```
pub fn tag_parts(cp: &crate::emit::cpp::Cp, t: &crate::lower::model::TagDef) -> Parts {
    let fields = crate::syntax::lexer::chars::join(&run_to_end(each_job(t.fields.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (_, f, ft) = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_13854: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_13854, &crate::emit::cpp::field_id(&f)))))
            }))
        }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let pods = crate::syntax::lexer::chars::join(&each(&t.fields, &(|(p_, f, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", prism_rtl::to_pod({})}}", p_, &crate::emit::cpp::field_id(f))))), &Text::lit(", "));
    let reads = crate::syntax::lexer::chars::join(&run_to_end(each_job(t.fields.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (p_, f, ft) = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_14094: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = TRY(prism_rtl::from_pod<{}>(TRY(crate::prelude::field(p, \"{}\"))))", &crate::emit::cpp::field_id(&f), &cpp_type_14094, &p_))))
            }))
        }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "));
    let eq = if t.pod {
        Text::from(format!("bool operator==(const {}&) const = default;", &t.name))
    } else {
        Text::lit("")
    };
    let back_ = if t.pod {
        Text::from(format!("static Result<{}> from_pod(const Pod& p);", &t.name))
    } else {
        Text::lit("")
    };
    let decl = crate::emit::cpp::templates::items::cpp_tag_struct(&cpp_source_doc(&Text::from(format!("The `Level` of `{}`:", &t.tag_name)), &t.doc), &t.name, &fields, &t.tag_name, &crate::syntax::lexer::chars::join(&filter(&Array::from(vec![eq.clone(), back_.clone()]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n")));
    let to_pod = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Pod {}::to_pod() const", &t.name)), &Text::from(format!("return Pod::element(TAG, {{{}}});", &pods)));
    let show_ = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("void {}::show(Printer& p) const", &t.name)), &Text::lit("prism_rtl::to_pod(*this).structure();\nShow<Pod>::show(prism_rtl::to_pod(*this), p);"));
    let from_pod = if t.pod {
        Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Result<{}> {}::from_pod(const Pod& p)", &t.name, &t.name)), &Text::from(format!("if (auto t = p.tag(); t && *t == TAG) return {}{{{}}};\nreturn mismatch<{}>(\"a {}\", p);", &t.name, &reads, &t.name, &t.tag_name)))])
    } else {
        Array::new()
    };
    let deps = crate::emit::cpp::patterns::concat2(&run_to_end(each_job(t.fields.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (_, _, ft) = p0;
                prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: ft.clone() }))
            }))
        }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    })));
    Parts { forward: Array::from(vec![Text::from(format!("struct {};", &t.name))]), handles: Array::new(), values: Array::from(vec![ValueDecl { path_: Text::from(format!("{}::{}", &cp.home, &t.name)), deps: deps.clone(), text: decl.clone() }]), cases: Array::new(), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: append(&Array::from(vec![to_pod.clone(), show_.clone()]), &from_pod) }
}

/// The step machine of `TagParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagParts: unbounded fn Cp, TagDef -> Parts
/// ```
pub struct TagParts {
    pub cp: crate::emit::cpp::Cp,
    pub t: crate::lower::model::TagDef,
}

impl prism_rtl::Job<Parts> for TagParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let t = &self.t;
        let cp = cp.clone();
        let t = t.clone();
        call_value(each_job(t.fields.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let (_, f, ft) = p0;
                    call_then(crate::emit::cpp::start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_13854: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_13854, &crate::emit::cpp::field_id(&f)))))
                }))
            }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_13816: Array<Text>| {
            let fields = crate::syntax::lexer::chars::join(&each_13816, &Text::lit("\n"));
            let pods = crate::syntax::lexer::chars::join(&each(&t.fields, &(|(p_, f, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", prism_rtl::to_pod({})}}", p_, &crate::emit::cpp::field_id(f))))), &Text::lit(", "));
            call_value(each_job(t.fields.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let (p_, f, ft) = p0;
                        call_then(crate::emit::cpp::start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_14094: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = TRY(prism_rtl::from_pod<{}>(TRY(crate::prelude::field(p, \"{}\"))))", &crate::emit::cpp::field_id(&f), &cpp_type_14094, &p_))))
                    }))
                }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_14022: Array<Text>| {
                let reads = crate::syntax::lexer::chars::join(&each_14022, &Text::lit(", "));
                let eq = if t.pod {
                    Text::from(format!("bool operator==(const {}&) const = default;", &t.name))
                } else {
                    Text::lit("")
                };
                let back_ = if t.pod {
                    Text::from(format!("static Result<{}> from_pod(const Pod& p);", &t.name))
                } else {
                    Text::lit("")
                };
                let decl = crate::emit::cpp::templates::items::cpp_tag_struct(&cpp_source_doc(&Text::from(format!("The `Level` of `{}`:", &t.tag_name)), &t.doc), &t.name, &fields, &t.tag_name, &crate::syntax::lexer::chars::join(&filter(&Array::from(vec![eq.clone(), back_.clone()]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n")));
                let to_pod = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Pod {}::to_pod() const", &t.name)), &Text::from(format!("return Pod::element(TAG, {{{}}});", &pods)));
                let show_ = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("void {}::show(Printer& p) const", &t.name)), &Text::lit("prism_rtl::to_pod(*this).structure();\nShow<Pod>::show(prism_rtl::to_pod(*this), p);"));
                let from_pod = if t.pod {
                    Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Result<{}> {}::from_pod(const Pod& p)", &t.name, &t.name)), &Text::from(format!("if (auto t = p.tag(); t && *t == TAG) return {}{{{}}};\nreturn mismatch<{}>(\"a {}\", p);", &t.name, &reads, &t.name, &t.tag_name)))])
                } else {
                    Array::new()
                };
                call_value(each_job(t.fields.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let (_, _, ft) = p0;
                            prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: ft.clone() }))
                        }))
                    }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_15006: Array<Array<Text>>| {
                    let deps = crate::emit::cpp::patterns::concat2(&each_15006);
                    prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![Text::from(format!("struct {};", &t.name))]), handles: Array::new(), values: Array::from(vec![ValueDecl { path_: Text::from(format!("{}::{}", &cp.home, &t.name)), deps: deps.clone(), text: decl.clone() }]), cases: Array::new(), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: append(&Array::from(vec![to_pod.clone(), show_.clone()]), &from_pod) })
                })
            })
        })
    }
}

/// `Start TagParts, x`: what the function value is when passed to `@Run`.
pub fn start_tag_parts(cp: crate::emit::cpp::Cp, t: crate::lower::model::TagDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(TagParts { cp, t })
}

/// ```prism
/// RowParts: unbounded fn Cp, Text, RowDef -> Parts
/// ```
pub fn row_parts(cp: &crate::emit::cpp::Cp, m: &Text, r: &crate::lower::model::RowDef) -> Parts {
    let names = each(&r.cases, &(|(v_, _): &(Text, Text)| v_.clone()));
    let pod = Text::from(format!("Pod to_pod() const;\nvoid show(Printer& p) const;{}", &(if r.pod {
        Text::from(format!("\nstatic Result<{}> from_pod(const Pod& p);", &r.name))
    } else {
        Text::lit("")
    })));
    let handle = crate::emit::cpp::templates::items::choice_handle(&cpp_source_doc(&Text::from(format!("`{}`, a row kind's values:", &r.prism)), &r.doc), &Text::lit(""), &r.name, &crate::syntax::lexer::chars::join(&each(&names, &(|n: &Text| Text::from(format!("struct {};", n)))), &Text::lit("\n")), &crate::syntax::lexer::chars::join(&names, &Text::lit(", ")), &pod);
    let cases = each(&r.cases, &(|(v_, st): &(Text, Text)| crate::emit::cpp::templates::items::case_decl(&Text::lit(""), &Text::from(format!("{}::{}", &r.name, v_)), &Text::from(format!("{} a0;{}", &row_struct(m, st), &(if r.pod {
        Text::from(format!("\nbool operator==(const {}&) const = default;", v_))
    } else {
        Text::lit("")
    }))))));
    let eq = if r.pod {
        Array::from(vec![Text::from(format!("inline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &r.name, &r.name))])
    } else {
        Array::new()
    };
    let to_pod = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Pod {}::to_pod() const", &r.name)), &Text::lit("return std::visit([](const auto& c) { return prism_rtl::to_pod(c.a0); }, cases());"));
    let show_ = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("void {}::show(Printer& p) const", &r.name)), &Text::lit("Show<Pod>::show(to_pod(), p);"));
    let reads = crate::syntax::lexer::chars::join(&each(&r.cases, &(|(v_, st): &(Text, Text)| Text::from(format!("if (*t == {}::TAG) return {}({}{{TRY(prism_rtl::from_pod<{}>(p))}});", &row_struct(m, st), &r.name, v_, &row_struct(m, st))))), &Text::lit("\n"));
    let from_pod = if r.pod {
        Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Result<{}> {}::from_pod(const Pod& p)", &r.name, &r.name)), &Text::from(format!("if (auto t = p.tag()) {{\n{}\n}}\nreturn mismatch<{}>(\"a {}\", p);", &indent_cpp(&reads), &r.name, &r.name)))])
    } else {
        Array::new()
    };
    Parts { forward: Array::from(vec![Text::from(format!("class {};", &r.name))]), handles: Array::from(vec![handle.clone()]), values: Array::new(), cases: append(&push(&cases, &cases_accessor(&Text::lit(""), &r.name)), &eq), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: append(&Array::from(vec![to_pod.clone(), show_.clone()]), &from_pod) }
}

/// The step machine of `RowParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowParts: unbounded fn Cp, Text, RowDef -> Parts
/// ```
pub struct RowParts {
    pub cp: crate::emit::cpp::Cp,
    pub m: Text,
    pub r: crate::lower::model::RowDef,
}

impl prism_rtl::Job<Parts> for RowParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let m = &self.m;
        let r = &self.r;
        let names = each(&r.cases, &(|(v_, _): &(Text, Text)| v_.clone()));
        let pod = Text::from(format!("Pod to_pod() const;\nvoid show(Printer& p) const;{}", &(if r.pod {
            Text::from(format!("\nstatic Result<{}> from_pod(const Pod& p);", &r.name))
        } else {
            Text::lit("")
        })));
        let handle = crate::emit::cpp::templates::items::choice_handle(&cpp_source_doc(&Text::from(format!("`{}`, a row kind's values:", &r.prism)), &r.doc), &Text::lit(""), &r.name, &crate::syntax::lexer::chars::join(&each(&names, &(|n: &Text| Text::from(format!("struct {};", n)))), &Text::lit("\n")), &crate::syntax::lexer::chars::join(&names, &Text::lit(", ")), &pod);
        let cases = each(&r.cases, &(|(v_, st): &(Text, Text)| crate::emit::cpp::templates::items::case_decl(&Text::lit(""), &Text::from(format!("{}::{}", &r.name, v_)), &Text::from(format!("{} a0;{}", &row_struct(m, st), &(if r.pod {
            Text::from(format!("\nbool operator==(const {}&) const = default;", v_))
        } else {
            Text::lit("")
        }))))));
        let eq = if r.pod {
            Array::from(vec![Text::from(format!("inline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &r.name, &r.name))])
        } else {
            Array::new()
        };
        let to_pod = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Pod {}::to_pod() const", &r.name)), &Text::lit("return std::visit([](const auto& c) { return prism_rtl::to_pod(c.a0); }, cases());"));
        let show_ = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("void {}::show(Printer& p) const", &r.name)), &Text::lit("Show<Pod>::show(to_pod(), p);"));
        let reads = crate::syntax::lexer::chars::join(&each(&r.cases, &(|(v_, st): &(Text, Text)| Text::from(format!("if (*t == {}::TAG) return {}({}{{TRY(prism_rtl::from_pod<{}>(p))}});", &row_struct(m, st), &r.name, v_, &row_struct(m, st))))), &Text::lit("\n"));
        let from_pod = if r.pod {
            Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Result<{}> {}::from_pod(const Pod& p)", &r.name, &r.name)), &Text::from(format!("if (auto t = p.tag()) {{\n{}\n}}\nreturn mismatch<{}>(\"a {}\", p);", &indent_cpp(&reads), &r.name, &r.name)))])
        } else {
            Array::new()
        };
        prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![Text::from(format!("class {};", &r.name))]), handles: Array::from(vec![handle.clone()]), values: Array::new(), cases: append(&push(&cases, &cases_accessor(&Text::lit(""), &r.name)), &eq), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: append(&Array::from(vec![to_pod.clone(), show_.clone()]), &from_pod) })
    }
}

/// `Start RowParts, x`: what the function value is when passed to `@Run`.
pub fn start_row_parts(cp: crate::emit::cpp::Cp, m: Text, r: crate::lower::model::RowDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(RowParts { cp, m, r })
}

/// ```prism
/// RowStruct: fn Text, Text -> Text
/// ```
pub fn row_struct(m: &Text, st: &Text) -> Text {
    if crate::syntax::lexer::chars::contains(st, &Text::lit(":")) || (m == &Text::lit("")) {
        crate::emit::cpp::type_path(st)
    } else {
        Text::from(format!("crate::{}::{}", m, st))
    }
}

/// ```prism
/// AnswerParts: unbounded fn Cp, AnswerDef -> Parts
/// ```
pub fn answer_parts(cp: &crate::emit::cpp::Cp, a: &crate::lower::model::AnswerDef) -> Parts {
    let names = each(&a.cases, &(|c: &crate::lower::model::AnswerCase| c.variant.clone()));
    let accessors = crate::syntax::lexer::chars::join(&run_to_end(each_job(a.cases.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::AnswerCase| {
            let cp = cp.clone();
            entered(once_job(move || {
                let c = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_17543: Text| prism_rtl::Turn::Finished(Text::from(format!("Result<{}> {}() const;", &cpp_type_17543, &c.accessor))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let members_ = Text::from(format!("const char* tag() const;\n{}\nstatic Result<Answer> decode(const Elem& e, const Pod& v);", &accessors));
    let handle = crate::emit::cpp::templates::items::choice_handle(&cpp_doc(&Text::lit("`Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host's\nsupplier answers a child place with, and what a World's answer to a forwarded element\ndecodes to, carrying the tag's output.")), &Text::lit(""), &Text::lit("Answer"), &crate::syntax::lexer::chars::join(&each(&names, &(|n: &Text| Text::from(format!("struct {};", n)))), &Text::lit("\n")), &crate::syntax::lexer::chars::join(&names, &Text::lit(", ")), &members_);
    let cases = run_to_end(each_job(a.cases.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::AnswerCase| {
            let cp = cp.clone();
            entered(once_job(move || {
                let c = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_18128: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::case_decl(&Text::lit(""), &Text::from(format!("Answer::{}", &c.variant)), &Text::from(format!("{} a0;", &cpp_type_18128)))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let tags = crate::syntax::lexer::chars::join(&each(&a.cases, &(|c: &crate::lower::model::AnswerCase| Text::from(format!("if (std::holds_alternative<{}>(cases())) return {}::TAG;", &c.variant, &crate::emit::cpp::type_path(&c.struct_path))))), &Text::lit("\n"));
    let tag_fn = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::lit("const char* Answer::tag() const"), &Text::from(format!("{}\nprism_rtl::unreachable();", &tags)));
    let getters = run_to_end(each_job(a.cases.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::AnswerCase| {
            let cp = cp.clone();
            entered(once_job(move || {
                let c = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_18486: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&cpp_doc(&Text::from(format!("A `{}`'s answer.", &c.tag_name))), &Text::from(format!("Result<{}> Answer::{}() const", &cpp_type_18486, &c.accessor)), &Text::from(format!("if (auto c = std::get_if<{}>(&cases())) return c->a0;\nreturn unexpected(Fault::answer(str(\"an answer for \", tag(), \", where {}'s was expected\")));", &c.variant, &c.tag_name)))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let decodes = crate::syntax::lexer::chars::join(&run_to_end(each_job(a.cases.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::AnswerCase| {
            let cp = cp.clone();
            entered(once_job(move || {
                let c = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_18834: Text| prism_rtl::Turn::Finished(Text::from(format!("if (is<Elem::{}>(e)) return Answer({}{{TRY(prism_rtl::from_pod<{}>(v))}});", &c.variant, &c.variant, &cpp_type_18834))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let decode = crate::emit::cpp::templates::items::cpp_function(&cpp_doc(&Text::lit("A World's answer to the element `e`, decoded by its tag.")), &Text::lit("Result<Answer> Answer::decode(const Elem& e, const Pod& v)"), &Text::from(format!("{}\nprism_rtl::unreachable();", &decodes)));
    Parts { forward: Array::from(vec![Text::lit("class Answer;")]), handles: Array::from(vec![handle.clone()]), values: Array::new(), cases: push(&cases, &cases_accessor(&Text::lit(""), &Text::lit("Answer"))), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: append(&Array::from(vec![tag_fn.clone()]), &push(&getters, &decode)) }
}

/// The step machine of `AnswerParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnswerParts: unbounded fn Cp, AnswerDef -> Parts
/// ```
pub struct AnswerParts {
    pub cp: crate::emit::cpp::Cp,
    pub a: crate::lower::model::AnswerDef,
}

impl prism_rtl::Job<Parts> for AnswerParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let a = &self.a;
        let names = each(&a.cases, &(|c: &crate::lower::model::AnswerCase| c.variant.clone()));
        let a = a.clone();
        let cp = cp.clone();
        call_value(each_job(a.cases.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: crate::lower::model::AnswerCase| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let c = p0;
                    call_then(crate::emit::cpp::start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_17543: Text| prism_rtl::Turn::Finished(Text::from(format!("Result<{}> {}() const;", &cpp_type_17543, &c.accessor))))
                }))
            }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_17515: Array<Text>| {
            let accessors = crate::syntax::lexer::chars::join(&each_17515, &Text::lit("\n"));
            let members_ = Text::from(format!("const char* tag() const;\n{}\nstatic Result<Answer> decode(const Elem& e, const Pod& v);", &accessors));
            let handle = crate::emit::cpp::templates::items::choice_handle(&cpp_doc(&Text::lit("`Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host's\nsupplier answers a child place with, and what a World's answer to a forwarded element\ndecodes to, carrying the tag's output.")), &Text::lit(""), &Text::lit("Answer"), &crate::syntax::lexer::chars::join(&each(&names, &(|n: &Text| Text::from(format!("struct {};", n)))), &Text::lit("\n")), &crate::syntax::lexer::chars::join(&names, &Text::lit(", ")), &members_);
            call_value(each_job(a.cases.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: crate::lower::model::AnswerCase| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let c = p0;
                        call_then(crate::emit::cpp::start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_18128: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::case_decl(&Text::lit(""), &Text::from(format!("Answer::{}", &c.variant)), &Text::from(format!("{} a0;", &cpp_type_18128)))))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_18071: Array<Text>| {
                let cases = each_18071;
                let tags = crate::syntax::lexer::chars::join(&each(&a.cases, &(|c: &crate::lower::model::AnswerCase| Text::from(format!("if (std::holds_alternative<{}>(cases())) return {}::TAG;", &c.variant, &crate::emit::cpp::type_path(&c.struct_path))))), &Text::lit("\n"));
                let tag_fn = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::lit("const char* Answer::tag() const"), &Text::from(format!("{}\nprism_rtl::unreachable();", &tags)));
                call_value(each_job(a.cases.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: crate::lower::model::AnswerCase| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let c = p0;
                            call_then(crate::emit::cpp::start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_18486: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&cpp_doc(&Text::from(format!("A `{}`'s answer.", &c.tag_name))), &Text::from(format!("Result<{}> Answer::{}() const", &cpp_type_18486, &c.accessor)), &Text::from(format!("if (auto c = std::get_if<{}>(&cases())) return c->a0;\nreturn unexpected(Fault::answer(str(\"an answer for \", tag(), \", where {}'s was expected\")));", &c.variant, &c.tag_name)))))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_18408: Array<Text>| {
                    let getters = each_18408;
                    call_value(each_job(a.cases.clone(), {
                        let cp = cp.clone();
                        Rc::new(move |p0: crate::lower::model::AnswerCase| {
                            let cp = cp.clone();
                            entered(once_job(move || {
                                let c = p0;
                                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_18834: Text| prism_rtl::Turn::Finished(Text::from(format!("if (is<Elem::{}>(e)) return Answer({}{{TRY(prism_rtl::from_pod<{}>(v))}});", &c.variant, &c.variant, &cpp_type_18834))))
                            }))
                        }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
                    }), move |each_18732: Array<Text>| {
                        let decodes = crate::syntax::lexer::chars::join(&each_18732, &Text::lit("\n"));
                        let decode = crate::emit::cpp::templates::items::cpp_function(&cpp_doc(&Text::lit("A World's answer to the element `e`, decoded by its tag.")), &Text::lit("Result<Answer> Answer::decode(const Elem& e, const Pod& v)"), &Text::from(format!("{}\nprism_rtl::unreachable();", &decodes)));
                        prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![Text::lit("class Answer;")]), handles: Array::from(vec![handle.clone()]), values: Array::new(), cases: push(&cases, &cases_accessor(&Text::lit(""), &Text::lit("Answer"))), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: append(&Array::from(vec![tag_fn.clone()]), &push(&getters, &decode)) })
                    })
                })
            })
        })
    }
}

/// `Start AnswerParts, x`: what the function value is when passed to `@Run`.
pub fn start_answer_parts(cp: crate::emit::cpp::Cp, a: crate::lower::model::AnswerDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(AnswerParts { cp, a })
}

/// ```prism
/// JobParts: unbounded fn Cp, JobDef -> Parts
/// ```
pub fn job_parts(cp: &crate::emit::cpp::Cp, j: &crate::lower::model::JobDef) -> Parts {
    let gens = cpp_template_head(&generic_names_of(&j.generics));
    let head = head_of(&j.name, &generic_names_of(&j.generics));
    let jcp = crate::emit::cpp::with_fields(cp, &j.fields);
    let fields = crate::syntax::lexer::chars::join(&run_to_end(each_job(j.fields.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (n, t) = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), t.clone()), move |cpp_type_19625: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_19625, &crate::emit::cpp::field_id(&n)))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let params = crate::syntax::lexer::chars::join(&run_to_end(each_job(j.fields.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (n, t) = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), t.clone()), move |cpp_type_19713: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_19713, &crate::emit::cpp::field_id(&n)))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "));
    let inits = crate::syntax::lexer::chars::join(&each(&j.fields, &(|(n, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{}(std::move({}))", &crate::emit::cpp::field_id(n), &crate::emit::cpp::field_id(n))))), &Text::lit(", "));
    let ctor = if &len(&j.fields) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!("{}({}) : {} {{}}", &j.name, &params, &inits))
    };
    let ret = crate::emit::cpp::cpp_type(cp, &j.ret);
    let decl = crate::emit::cpp::templates::items::job_struct(&cpp_doc(&j.doc), &gens, &j.name, &ret, &fields, &ctor);
    let cycle = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}prism_rtl::Turn<{}> {}::cycle() const", &gens, &ret, &head)), &crate::emit::cpp::stmts::cpp_body(&jcp, &j.body));
    let start = crate::emit::cpp::templates::items::cpp_function(&cpp_doc(&Text::from(format!("`Start {}, x`: what the function value is when passed to `@Run`.", &j.name))), &Text::from(format!("{}prism_rtl::JobRef<{}> {}({})", &gens, &ret, &j.start, &params)), &Text::from(format!("return prism_rtl::make_rc<{}>({});", &head, &crate::syntax::lexer::chars::join(&each(&j.fields, &(|(n, _): &(Text, crate::lower::model::OutTy)| crate::emit::cpp::field_id(n))), &Text::lit(", ")))));
    let generic = &len(&j.generics) > &Nat::from(0u32);
    Parts { forward: Array::from(vec![Text::from(format!("{}struct {};", &gens, &j.name))]), handles: Array::new(), values: Array::new(), cases: Array::new(), protos: Array::from(vec![Text::from(format!("{}prism_rtl::JobRef<{}> {}({});", &gens, &ret, &j.start, &params))]), classes: Array::from(vec![decl.clone()]), outer: Array::new(), generic: if generic { Array::from(vec![cycle.clone(), start.clone()]) } else { Array::new() }, defs: if generic { Array::new() } else { Array::from(vec![cycle.clone(), start.clone()]) } }
}

/// The step machine of `JobParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobParts: unbounded fn Cp, JobDef -> Parts
/// ```
pub struct JobParts {
    pub cp: crate::emit::cpp::Cp,
    pub j: crate::lower::model::JobDef,
}

impl prism_rtl::Job<Parts> for JobParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let j = &self.j;
        let gens = cpp_template_head(&generic_names_of(&j.generics));
        let head = head_of(&j.name, &generic_names_of(&j.generics));
        let jcp = crate::emit::cpp::with_fields(cp, &j.fields);
        let cp = cp.clone();
        let j = j.clone();
        call_value(each_job(j.fields.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let (n, t) = p0;
                    call_then(crate::emit::cpp::start_cpp_type(cp.clone(), t.clone()), move |cpp_type_19625: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_19625, &crate::emit::cpp::field_id(&n)))))
                }))
            }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_19596: Array<Text>| {
            let fields = crate::syntax::lexer::chars::join(&each_19596, &Text::lit("\n"));
            call_value(each_job(j.fields.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let (n, t) = p0;
                        call_then(crate::emit::cpp::start_cpp_type(cp.clone(), t.clone()), move |cpp_type_19713: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_19713, &crate::emit::cpp::field_id(&n)))))
                    }))
                }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_19684: Array<Text>| {
                let params = crate::syntax::lexer::chars::join(&each_19684, &Text::lit(", "));
                let inits = crate::syntax::lexer::chars::join(&each(&j.fields, &(|(n, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{}(std::move({}))", &crate::emit::cpp::field_id(n), &crate::emit::cpp::field_id(n))))), &Text::lit(", "));
                let ctor = if &len(&j.fields) == &Nat::from(0u32) {
                    Text::lit("")
                } else {
                    Text::from(format!("{}({}) : {} {{}}", &j.name, &params, &inits))
                };
                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), j.ret.clone()), move |cpp_type_19945: Text| {
                    let ret = cpp_type_19945;
                    let decl = crate::emit::cpp::templates::items::job_struct(&cpp_doc(&j.doc), &gens, &j.name, &ret, &fields, &ctor);
                    call_then(crate::emit::cpp::stmts::start_cpp_body(jcp.clone(), j.body.clone()), move |cpp_body_20123: Text| {
                        let cycle = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}prism_rtl::Turn<{}> {}::cycle() const", &gens, &ret, &head)), &cpp_body_20123);
                        let start = crate::emit::cpp::templates::items::cpp_function(&cpp_doc(&Text::from(format!("`Start {}, x`: what the function value is when passed to `@Run`.", &j.name))), &Text::from(format!("{}prism_rtl::JobRef<{}> {}({})", &gens, &ret, &j.start, &params)), &Text::from(format!("return prism_rtl::make_rc<{}>({});", &head, &crate::syntax::lexer::chars::join(&each(&j.fields, &(|(n, _): &(Text, crate::lower::model::OutTy)| crate::emit::cpp::field_id(n))), &Text::lit(", ")))));
                        let generic = &len(&j.generics) > &Nat::from(0u32);
                        prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![Text::from(format!("{}struct {};", &gens, &j.name))]), handles: Array::new(), values: Array::new(), cases: Array::new(), protos: Array::from(vec![Text::from(format!("{}prism_rtl::JobRef<{}> {}({});", &gens, &ret, &j.start, &params))]), classes: Array::from(vec![decl.clone()]), outer: Array::new(), generic: if generic { Array::from(vec![cycle.clone(), start.clone()]) } else { Array::new() }, defs: if generic { Array::new() } else { Array::from(vec![cycle.clone(), start.clone()]) } })
                    })
                })
            })
        })
    }
}

/// `Start JobParts, x`: what the function value is when passed to `@Run`.
pub fn start_job_parts(cp: crate::emit::cpp::Cp, j: crate::lower::model::JobDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(JobParts { cp, j })
}

/// ```prism
/// TraitParts: unbounded fn Cp, TraitDef -> Parts
/// ```
pub fn trait_parts(cp: &crate::emit::cpp::Cp, t: &crate::lower::model::TraitDef) -> Parts {
    let defaults = filter(&t.methods, &(|f: &crate::lower::model::FnDef| f.public));
    let defs = run_to_end(each_job(defaults.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::FnDef| {
            let cp = cp.clone();
            entered(once_job(move || {
                let f = p0;
                prism_rtl::Turn::More(Rc::new(FnDefinition { cp: cp.clone(), f: with_generics(&f, &Array::from(vec![(Text::lit("Self"), Array::new())])) }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let protos = run_to_end(each_job(t.methods.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::FnDef| {
            let cp = cp.clone();
            entered(once_job(move || {
                let f = p0;
                call_then(start_fn_signature(cp.clone(), with_generics(&f, &Array::from(vec![(Text::lit("Self"), Array::new())]))), move |fn_signature_21389: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{};", &fn_signature_21389, &(if f.public { Text::lit("") } else { Text::lit(" = delete") })))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let generic = if &len(&defaults) == &Nat::from(0u32) {
        Array::new()
    } else {
        Array::from(vec![crate::emit::cpp::templates::items::trait_namespace(&t.name, &crate::syntax::lexer::chars::join(&defs, &Text::lit("\n")))])
    };
    let mut this: Parts = generic_only(&generic);
    this.protos = Array::from(vec![crate::emit::cpp::templates::items::trait_namespace(&t.name, &crate::syntax::lexer::chars::join(&protos, &Text::lit("\n")))]);
    this
}

/// The step machine of `TraitParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TraitParts: unbounded fn Cp, TraitDef -> Parts
/// ```
pub struct TraitParts {
    pub cp: crate::emit::cpp::Cp,
    pub t: crate::lower::model::TraitDef,
}

impl prism_rtl::Job<Parts> for TraitParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let t = &self.t;
        let defaults = filter(&t.methods, &(|f: &crate::lower::model::FnDef| f.public));
        let cp = cp.clone();
        let t = t.clone();
        call_value(each_job(defaults.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: crate::lower::model::FnDef| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let f = p0;
                    prism_rtl::Turn::More(Rc::new(FnDefinition { cp: cp.clone(), f: with_generics(&f, &Array::from(vec![(Text::lit("Self"), Array::new())])) }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_21273: Array<Text>| {
            let defs = each_21273;
            call_value(each_job(t.methods.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: crate::lower::model::FnDef| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let f = p0;
                        call_then(start_fn_signature(cp.clone(), with_generics(&f, &Array::from(vec![(Text::lit("Self"), Array::new())]))), move |fn_signature_21389: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{};", &fn_signature_21389, &(if f.public { Text::lit("") } else { Text::lit(" = delete") })))))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_21366: Array<Text>| {
                let protos = each_21366;
                let generic = if &len(&defaults) == &Nat::from(0u32) {
                    Array::new()
                } else {
                    Array::from(vec![crate::emit::cpp::templates::items::trait_namespace(&t.name, &crate::syntax::lexer::chars::join(&defs, &Text::lit("\n")))])
                };
                prism_rtl::Turn::Finished({
                    let mut this: Parts = generic_only(&generic);
                    this.protos = Array::from(vec![crate::emit::cpp::templates::items::trait_namespace(&t.name, &crate::syntax::lexer::chars::join(&protos, &Text::lit("\n")))]);
                    this
                })
            })
        })
    }
}

/// `Start TraitParts, x`: what the function value is when passed to `@Run`.
pub fn start_trait_parts(cp: crate::emit::cpp::Cp, t: crate::lower::model::TraitDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(TraitParts { cp, t })
}

/// ```prism
/// ImplParts: unbounded fn Cp, ImplDef -> Parts
/// ```
pub fn impl_parts(cp: &crate::emit::cpp::Cp, i: &crate::lower::model::ImplDef) -> Parts {
    let head = crate::emit::cpp::cpp_type(cp, &i.head);
    let gens = cpp_template_head(&generic_names_of(&i.generics));
    let fns = run_to_end(each_job(i.methods.clone(), {
        let cp = cp.clone();
        let i = i.clone();
        Rc::new(move |p0: crate::lower::model::FnDef| {
            let cp = cp.clone();
            let i = i.clone();
            entered(once_job(move || {
                let f = p0;
                prism_rtl::Turn::More(Rc::new(FnParts { cp: cp.clone(), f: with_generics(&f, &i.generics) }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Parts>>>
    }));
    let own = fold(&fns, &no_parts(), &(|acc: &Parts, p_: &Parts| join_parts(acc, p_)));
    match &i.cls {
        m22376_0 if (m22376_0 == &Text::lit("Prelude.Show")) => {
            let shown = or(&index(&each(&i.methods, &(|f: &crate::lower::model::FnDef| f.name.clone())), &Nat::from(0u32)), &Text::lit("show"));
            join_parts(&own, &protos_defs(&Array::new(), &Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}void {}::show(Printer& p) const", &gens, &head)), &Text::from(format!("p.raw({}(*this).to_string());", &shown)))])))
        },
        m22376_1 if (m22376_1 == &Text::lit("Prelude.Eq")) => {
            let eq = fold(&i.methods, &Text::lit(""), &(|acc: &Text, f: &crate::lower::model::FnDef| if !crate::syntax::lexer::chars::has_prefix(&f.name, &Text::lit("ne")) && (acc == &Text::lit("")) {
                f.name.clone()
            } else {
                acc.clone()
            }));
            join_parts(&own, &protos_defs(&Array::from(vec![Text::from(format!("{}bool operator==(const {}& a, const {}& b);", &gens, &head, &head))]), &Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}bool operator==(const {}& a, const {}& b)", &gens, &head, &head)), &Text::from(format!("return {}(a, b);", &eq)))])))
        },
        _ => {
            let tr = crate::syntax::lexer::chars::drop_prefix(&crate::emit::cpp::type_path(&i.tr), &Text::lit("crate::"));
            let own = !crate::syntax::lexer::chars::contains(&tr, &Text::lit("::"));
            let ns = if own {
                tr.clone()
            } else {
                Text::from(format!("impl_{}", &crate::syntax::lexer::chars::join(&split_on(&tr, &Text::lit("::")), &Text::lit("_"))))
            };
            let in_trait = run_to_end(each_job(i.methods.clone(), {
                let ns = ns.clone();
                let cp = cp.clone();
                let i = i.clone();
                Rc::new(move |p0: crate::lower::model::FnDef| {
                    let ns = ns.clone();
                    let cp = cp.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let f = p0;
                        call_then(start_fn_definition(cp.clone(), with_generics(&f, &i.generics)), move |fn_definition_23243: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::trait_namespace(&ns, &fn_definition_23243)))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            let protos = run_to_end(each_job(i.methods.clone(), {
                let ns = ns.clone();
                let cp = cp.clone();
                let i = i.clone();
                Rc::new(move |p0: crate::lower::model::FnDef| {
                    let ns = ns.clone();
                    let cp = cp.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let f = p0;
                        call_then(start_fn_signature(cp.clone(), with_generics(&f, &i.generics)), move |fn_signature_23357: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::trait_namespace(&ns, &Text::from(format!("{};", &fn_signature_23357)))))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            let outer = if own {
                Array::new()
            } else {
                Array::from(vec![crate::emit::cpp::templates::items::trait_namespace(&tr, &crate::syntax::lexer::chars::join(&each(&i.methods, &(|f: &crate::lower::model::FnDef| Text::from(format!("using ::crate::{}::{}::{};", &cp.home, &ns, &crate::emit::cpp::cpp_id(&f.name))))), &Text::lit("\n")))])
            };
            {
                let mut this: Parts = protos_defs(&protos, &in_trait);
                this.outer = outer.clone();
                this
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ImplParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ImplParts: unbounded fn Cp, ImplDef -> Parts
/// ```
pub struct ImplParts {
    pub cp: crate::emit::cpp::Cp,
    pub i: crate::lower::model::ImplDef,
}

impl prism_rtl::Job<Parts> for ImplParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let i = &self.i;
        let cp = cp.clone();
        let i = i.clone();
        call_then(crate::emit::cpp::start_cpp_type(cp.clone(), i.head.clone()), move |cpp_type_22158: Text| {
            let head = cpp_type_22158;
            let gens = cpp_template_head(&generic_names_of(&i.generics));
            call_value(each_job(i.methods.clone(), {
                let cp = cp.clone();
                let i = i.clone();
                Rc::new(move |p0: crate::lower::model::FnDef| {
                    let cp = cp.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let f = p0;
                        prism_rtl::Turn::More(Rc::new(FnParts { cp: cp.clone(), f: with_generics(&f, &i.generics) }))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Parts>>>
            }), move |each_22250: Array<Parts>| {
                let fns = each_22250;
                let own = fold(&fns, &no_parts(), &(|acc: &Parts, p_: &Parts| join_parts(acc, p_)));
                match &i.cls {
                    m22376_0 if (m22376_0 == &Text::lit("Prelude.Show")) => {
                        let shown = or(&index(&each(&i.methods, &(|f: &crate::lower::model::FnDef| f.name.clone())), &Nat::from(0u32)), &Text::lit("show"));
                        prism_rtl::Turn::Finished(join_parts(&own, &protos_defs(&Array::new(), &Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}void {}::show(Printer& p) const", &gens, &head)), &Text::from(format!("p.raw({}(*this).to_string());", &shown)))]))))
                    },
                    m22376_1 if (m22376_1 == &Text::lit("Prelude.Eq")) => {
                        let eq = fold(&i.methods, &Text::lit(""), &(|acc: &Text, f: &crate::lower::model::FnDef| if !crate::syntax::lexer::chars::has_prefix(&f.name, &Text::lit("ne")) && (acc == &Text::lit("")) {
                            f.name.clone()
                        } else {
                            acc.clone()
                        }));
                        prism_rtl::Turn::Finished(join_parts(&own, &protos_defs(&Array::from(vec![Text::from(format!("{}bool operator==(const {}& a, const {}& b);", &gens, &head, &head))]), &Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}bool operator==(const {}& a, const {}& b)", &gens, &head, &head)), &Text::from(format!("return {}(a, b);", &eq)))]))))
                    },
                    _ => {
                        let tr = crate::syntax::lexer::chars::drop_prefix(&crate::emit::cpp::type_path(&i.tr), &Text::lit("crate::"));
                        let own = !crate::syntax::lexer::chars::contains(&tr, &Text::lit("::"));
                        let ns = if own {
                            tr.clone()
                        } else {
                            Text::from(format!("impl_{}", &crate::syntax::lexer::chars::join(&split_on(&tr, &Text::lit("::")), &Text::lit("_"))))
                        };
                        call_value(each_job(i.methods.clone(), {
                            let ns = ns.clone();
                            let cp = cp.clone();
                            let i = i.clone();
                            Rc::new(move |p0: crate::lower::model::FnDef| {
                                let ns = ns.clone();
                                let cp = cp.clone();
                                let i = i.clone();
                                entered(once_job(move || {
                                    let f = p0;
                                    call_then(start_fn_definition(cp.clone(), with_generics(&f, &i.generics)), move |fn_definition_23243: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::trait_namespace(&ns, &fn_definition_23243)))
                                }))
                            }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
                        }), move |each_23202: Array<Text>| {
                            let in_trait = each_23202;
                            call_value(each_job(i.methods.clone(), {
                                let ns = ns.clone();
                                let cp = cp.clone();
                                let i = i.clone();
                                Rc::new(move |p0: crate::lower::model::FnDef| {
                                    let ns = ns.clone();
                                    let cp = cp.clone();
                                    let i = i.clone();
                                    entered(once_job(move || {
                                        let f = p0;
                                        call_then(start_fn_signature(cp.clone(), with_generics(&f, &i.generics)), move |fn_signature_23357: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::trait_namespace(&ns, &Text::from(format!("{};", &fn_signature_23357)))))
                                    }))
                                }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
                            }), move |each_23315: Array<Text>| {
                                let protos = each_23315;
                                let outer = if own {
                                    Array::new()
                                } else {
                                    Array::from(vec![crate::emit::cpp::templates::items::trait_namespace(&tr, &crate::syntax::lexer::chars::join(&each(&i.methods, &(|f: &crate::lower::model::FnDef| Text::from(format!("using ::crate::{}::{}::{};", &cp.home, &ns, &crate::emit::cpp::cpp_id(&f.name))))), &Text::lit("\n")))])
                                };
                                prism_rtl::Turn::Finished({
                                    let mut this: Parts = protos_defs(&protos, &in_trait);
                                    this.outer = outer.clone();
                                    this
                                })
                            })
                        })
                    },
                    _ => unreachable!("no arm matched"),
                }
            })
        })
    }
}

/// `Start ImplParts, x`: what the function value is when passed to `@Run`.
pub fn start_impl_parts(cp: crate::emit::cpp::Cp, i: crate::lower::model::ImplDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(ImplParts { cp, i })
}

/// ```prism
/// WithGenerics: fn FnDef, [((Text, [Text]))] -> FnDef
/// ```
pub fn with_generics(f: &crate::lower::model::FnDef, gs: &Array<(Text, Array<Text>)>) -> crate::lower::model::FnDef {
    let mut this: crate::lower::model::FnDef = f.clone();
    this.generics = append(gs, &this.generics);
    this
}

/// ```prism
/// GenericOnly: fn [Text] -> Parts
/// ```
pub fn generic_only(xs: &Array<Text>) -> Parts {
    let mut this: Parts = no_parts();
    this.generic = xs.clone();
    this
}

/// ```prism
/// ProtosDefs: fn [Text], [Text] -> Parts
/// ```
pub fn protos_defs(ps: &Array<Text>, ds: &Array<Text>) -> Parts {
    let mut this: Parts = no_parts();
    this.protos = ps.clone();
    this.defs = ds.clone();
    this
}
