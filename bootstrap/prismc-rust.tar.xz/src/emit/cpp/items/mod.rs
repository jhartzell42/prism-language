//! The module `Emit.Cpp.Items`, from `target/bootstrap/src/prismc/emit/cpp/items.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Parts`:
///
/// ```prism
/// type Parts = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Parts {
    pub forward: Array<Text>,
    pub values: Array<ValueDecl>,
    pub protos: Array<Text>,
    pub classes: Array<Text>,
    pub outer: Array<Text>,
    pub generic: Array<Text>,
    pub defs: Array<Text>,
}

impl Show for Parts {
    fn show(&self, p: &mut Printer) {
        p.record("Parts", &[("forward", &self.forward), ("values", &self.values), ("protos", &self.protos), ("classes", &self.classes), ("outer", &self.outer), ("generic", &self.generic), ("defs", &self.defs)]);
    }
}

impl ToPod for Parts {
    fn to_pod(&self) -> Pod {
        Pod::record("Parts", vec![("forward", self.forward.to_pod()), ("values", self.values.to_pod()), ("protos", self.protos.to_pod()), ("classes", self.classes.to_pod()), ("outer", self.outer.to_pod()), ("generic", self.generic.to_pod()), ("defs", self.defs.to_pod())])
    }
}

impl FromPod for Parts {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Parts { forward: FromPod::from_pod(field(p, "forward")?)?, values: FromPod::from_pod(field(p, "values")?)?, protos: FromPod::from_pod(field(p, "protos")?)?, classes: FromPod::from_pod(field(p, "classes")?)?, outer: FromPod::from_pod(field(p, "outer")?)?, generic: FromPod::from_pod(field(p, "generic")?)?, defs: FromPod::from_pod(field(p, "defs")?)? })
    }
}

/// `ValueDecl`:
///
/// ```prism
/// type ValueDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ValueDecl {
    pub path_: Text,
    pub deps: Array<Text>,
    pub text: Text,
}

impl Show for ValueDecl {
    fn show(&self, p: &mut Printer) {
        p.record("ValueDecl", &[("path", &self.path_), ("deps", &self.deps), ("text", &self.text)]);
    }
}

impl ToPod for ValueDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("ValueDecl", vec![("path", self.path_.to_pod()), ("deps", self.deps.to_pod()), ("text", self.text.to_pod())])
    }
}

impl FromPod for ValueDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ValueDecl { path_: FromPod::from_pod(field(p, "path")?)?, deps: FromPod::from_pod(field(p, "deps")?)?, text: FromPod::from_pod(field(p, "text")?)? })
    }
}

/// ```prism
/// CppTemplateHead: fn [Text] -> Text
/// ```
pub fn cpp_template_head(xs0: &Array<Text>) -> Text {
    match xs0 {
        c0_0 if (c0_0.len() == 0) => Text::lit(""),
        ps => Text::from(format!("template <{}>\n", &crate::syntax::lexer::chars::join(&each(ps, &(|p_: &Text| Text::from(format!("class {}", p_)))), &Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// GenericNamesOf: fn [((Text, [Text]))] -> [Text]
/// ```
pub fn generic_names_of(gs: &Array<(Text, Array<Text>)>) -> Array<Text> {
    each(gs, &(|(g, _): &(Text, Array<Text>)| g.clone()))
}

/// ```prism
/// HeadOf: fn Text, [Text] -> Text
/// ```
pub fn head_of(name: &Text, xs1: &Array<Text>) -> Text {
    match xs1 {
        c0_1 if (c0_1.len() == 0) => name.clone(),
        ps => Text::from(format!("{}<{}>", name, &crate::syntax::lexer::chars::join(ps, &Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CppParams: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub fn cpp_params(cp: &crate::emit::cpp::Cp, ps: &Array<(Text, crate::lower::model::OutTy)>) -> Text {
    crate::syntax::lexer::chars::join(&run_to_end(each_job(ps.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (n, t) = p0;
                call_then(crate::emit::cpp::expr::start_param_type(cp.clone(), t.clone()), move |param_type_1510: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_1510, &crate::emit::cpp::cpp_id(&n)))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "))
}

/// The step machine of `CppParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppParams: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub struct CppParams {
    pub cp: crate::emit::cpp::Cp,
    pub ps: Array<(Text, crate::lower::model::OutTy)>,
}

impl prism_rtl::Job<Text> for CppParams {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let ps = &self.ps;
        let cp = cp.clone();
        let ps = ps.clone();
        call_value(each_job(ps.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let (n, t) = p0;
                    call_then(crate::emit::cpp::expr::start_param_type(cp.clone(), t.clone()), move |param_type_1510: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_1510, &crate::emit::cpp::cpp_id(&n)))))
                }))
            }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_1487: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&each_1487, &Text::lit(", "))))
    }
}

/// `Start CppParams, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_params(cp: crate::emit::cpp::Cp, ps: Array<(Text, crate::lower::model::OutTy)>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppParams { cp, ps })
}

/// ```prism
/// FnSignature: unbounded fn Cp, FnDef -> Text
/// ```
pub fn fn_signature(cp: &crate::emit::cpp::Cp, f: &crate::lower::model::FnDef) -> Text {
    Text::from(format!("{}{} {}({})", &cpp_template_head(&generic_names_of(&f.generics)), &crate::emit::cpp::cpp_type(cp, &f.ret), &crate::emit::cpp::cpp_id(&f.name), &cpp_params(cp, &f.params)))
}

/// The step machine of `FnSignature`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnSignature: unbounded fn Cp, FnDef -> Text
/// ```
pub struct FnSignature {
    pub cp: crate::emit::cpp::Cp,
    pub f: crate::lower::model::FnDef,
}

impl prism_rtl::Job<Text> for FnSignature {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let f = &self.f;
        let cp = cp.clone();
        let f = f.clone();
        call_then(crate::emit::cpp::start_cpp_type(cp.clone(), f.ret.clone()), move |cpp_type_1741: Text| call_then(start_cpp_params(cp.clone(), f.params.clone()), move |cpp_params_1776: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{} {}({})", &cpp_template_head(&generic_names_of(&f.generics)), &cpp_type_1741, &crate::emit::cpp::cpp_id(&f.name), &cpp_params_1776)))))
    }
}

/// `Start FnSignature, x`: what the function value is when passed to `@Run`.
pub fn start_fn_signature(cp: crate::emit::cpp::Cp, f: crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FnSignature { cp, f })
}

/// ```prism
/// FnDefinition: unbounded fn Cp, FnDef -> Text
/// ```
pub fn fn_definition(cp: &crate::emit::cpp::Cp, f: &crate::lower::model::FnDef) -> Text {
    crate::emit::cpp::templates::items::cpp_function(&cpp_doc(&f.doc), &fn_signature(cp, f), &crate::emit::cpp::stmts::cpp_body(&with_params(cp, &f.params), &f.body))
}

/// The step machine of `FnDefinition`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnDefinition: unbounded fn Cp, FnDef -> Text
/// ```
pub struct FnDefinition {
    pub cp: crate::emit::cpp::Cp,
    pub f: crate::lower::model::FnDef,
}

impl prism_rtl::Job<Text> for FnDefinition {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let f = &self.f;
        let cp = cp.clone();
        let f = f.clone();
        call_then(start_fn_signature(cp.clone(), f.clone()), move |fn_signature_1901: Text| call_then(crate::emit::cpp::stmts::start_cpp_body(with_params(&cp, &f.params), f.body.clone()), move |cpp_body_1922: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&cpp_doc(&f.doc), &fn_signature_1901, &cpp_body_1922))))
    }
}

/// `Start FnDefinition, x`: what the function value is when passed to `@Run`.
pub fn start_fn_definition(cp: crate::emit::cpp::Cp, f: crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FnDefinition { cp, f })
}

/// ```prism
/// WithParams: fn Cp, [((Text, OutTy))] -> Cp
/// ```
pub fn with_params(cp: &crate::emit::cpp::Cp, ps: &Array<(Text, crate::lower::model::OutTy)>) -> crate::emit::cpp::Cp {
    fold(ps, cp, &(|c: &crate::emit::cpp::Cp, (n, t): &(Text, crate::lower::model::OutTy)| {
        let mut this: crate::emit::cpp::Cp = c.clone();
        this.pointers = insert(&this.pointers, n, &crate::emit::cpp::expr::is_pointer_ty(c, &crate::emit::cpp::expr::unref(t)));
        this.local_types = insert(&this.local_types, n, t);
        this
    }))
}

/// ```prism
/// ValueDeps: unbounded fn Cp, OutTy -> [Text]
/// ```
pub fn value_deps(cp: &crate::emit::cpp::Cp, t: &crate::lower::model::OutTy) -> Array<Text> {
    match t {
        crate::lower::model::OutTy::OutNamed(n, args) => {
            let own = match crate::emit::cpp::type_of(cp, n) {
                Some(info) => if ((((&info.kind == &Text::lit("record")) || (&info.kind == &Text::lit("newtype"))) || (&info.kind == &Text::lit("unit"))) || (&info.kind == &Text::lit("tag"))) || (&info.kind == &Text::lit("choice")) {
                    Array::from(vec![dep_path(cp, n)])
                } else {
                    Array::new()
                },
                None => Array::new(),
            };
            append(&own, &crate::emit::cpp::patterns::concat2(&run_to_end(each_job(args.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: crate::lower::model::OutTy| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: a.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }))))
        },
        crate::lower::model::OutTy::OutOpt(i) => value_deps(cp, &**i),
        crate::lower::model::OutTy::OutRes(i) => value_deps(cp, &**i),
        crate::lower::model::OutTy::OutCell(i) => value_deps(cp, &**i),
        crate::lower::model::OutTy::OutTuple(ts) => crate::emit::cpp::patterns::concat2(&run_to_end(each_job(ts.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: crate::lower::model::OutTy| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }))),
        _ => Array::new(),
    }
}

/// The step machine of `ValueDeps`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ValueDeps: unbounded fn Cp, OutTy -> [Text]
/// ```
pub struct ValueDeps {
    pub cp: crate::emit::cpp::Cp,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Array<Text>> for ValueDeps {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cp = &self.cp;
        let t = &self.t;
        match t {
            crate::lower::model::OutTy::OutNamed(n, args) => {
                let own = match crate::emit::cpp::type_of(cp, n) {
                    Some(info) => if ((((&info.kind == &Text::lit("record")) || (&info.kind == &Text::lit("newtype"))) || (&info.kind == &Text::lit("unit"))) || (&info.kind == &Text::lit("tag"))) || (&info.kind == &Text::lit("choice")) {
                        Array::from(vec![dep_path(cp, n)])
                    } else {
                        Array::new()
                    },
                    None => Array::new(),
                };
                let args = args.clone();
                let cp = cp.clone();
                call_value(each_job(args.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: crate::lower::model::OutTy| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: a.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_3884: Array<Array<Text>>| prism_rtl::Turn::Finished(append(&own, &crate::emit::cpp::patterns::concat2(&each_3884))))
            },
            crate::lower::model::OutTy::OutOpt(i) => prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: (**i).clone() })),
            crate::lower::model::OutTy::OutRes(i) => prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: (**i).clone() })),
            crate::lower::model::OutTy::OutCell(i) => prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: (**i).clone() })),
            crate::lower::model::OutTy::OutTuple(ts) => {
                let cp = cp.clone();
                let ts = ts.clone();
                call_value(each_job(ts.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: crate::lower::model::OutTy| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: a.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_4035: Array<Array<Text>>| prism_rtl::Turn::Finished(crate::emit::cpp::patterns::concat2(&each_4035)))
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start ValueDeps, x`: what the function value is when passed to `@Run`.
pub fn start_value_deps(cp: crate::emit::cpp::Cp, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ValueDeps { cp, t })
}

/// ```prism
/// DepPath: fn Cp, Text -> Text
/// ```
pub fn dep_path(cp: &crate::emit::cpp::Cp, n: &Text) -> Text {
    let abs_ = crate::emit::cpp::absolute(cp, n);
    let q = crate::syntax::lexer::chars::drop_prefix(n, &Text::lit("crate::"));
    match get(&cp.types, &abs_) {
        Some(_) => abs_.clone(),
        None => q.clone(),
    }
}

/// ```prism
/// Behind: unbounded fn Cp, OutTy -> Bool
/// ```
pub fn behind(cp: &crate::emit::cpp::Cp, t: &crate::lower::model::OutTy) -> bool {
    match t {
        crate::lower::model::OutTy::OutRc(_) => true,
        crate::lower::model::OutTy::OutOpt(i) => behind(cp, &**i),
        crate::lower::model::OutTy::OutRes(i) => behind(cp, &**i),
        crate::lower::model::OutTy::OutCell(i) => behind(cp, &**i),
        crate::lower::model::OutTy::OutTuple(ts) => run_to_end(fold_job(ts.clone(), false, {
            let cp = cp.clone();
            Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let f = p0;
                    let x = p1;
                    prism_rtl::Turn::Finished(f || behind(&cp, &x))
                }))
            }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::lower::model::OutTy::OutArray(i) => names_program_type(cp, &**i),
        crate::lower::model::OutTy::OutMap(k, v_) => names_program_type(cp, &**k) || names_program_type(cp, &**v_),
        crate::lower::model::OutTy::OutFn(ps, r) => run_to_end(fold_job(ps.clone(), names_program_type(cp, &**r), {
            let cp = cp.clone();
            Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let f = p0;
                    let x = p1;
                    prism_rtl::Turn::Finished(f || names_program_type(&cp, &x))
                }))
            }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::lower::model::OutTy::OutDyn(i) => names_program_type(cp, &**i),
        crate::lower::model::OutTy::OutEvent(i) => names_program_type(cp, &**i),
        crate::lower::model::OutTy::OutNamed(_, args) => run_to_end(fold_job(args.clone(), false, {
            let cp = cp.clone();
            Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let f = p0;
                    let x = p1;
                    prism_rtl::Turn::Finished(f || behind(&cp, &x))
                }))
            }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        _ => false,
    }
}

/// The step machine of `Behind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Behind: unbounded fn Cp, OutTy -> Bool
/// ```
pub struct Behind {
    pub cp: crate::emit::cpp::Cp,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<bool> for Behind {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let cp = &self.cp;
        let t = &self.t;
        match t {
            crate::lower::model::OutTy::OutRc(_) => prism_rtl::Turn::Finished(true),
            crate::lower::model::OutTy::OutOpt(i) => prism_rtl::Turn::More(Rc::new(Behind { cp: cp.clone(), t: (**i).clone() })),
            crate::lower::model::OutTy::OutRes(i) => prism_rtl::Turn::More(Rc::new(Behind { cp: cp.clone(), t: (**i).clone() })),
            crate::lower::model::OutTy::OutCell(i) => prism_rtl::Turn::More(Rc::new(Behind { cp: cp.clone(), t: (**i).clone() })),
            crate::lower::model::OutTy::OutTuple(ts) => fold_job(ts.clone(), false, {
                let cp = cp.clone();
                Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let f = p0;
                        let x = p1;
                        prism_rtl::Turn::Finished(f || behind(&cp, &x))
                    }))
                }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            crate::lower::model::OutTy::OutArray(i) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp: cp.clone(), t: (**i).clone() })),
            crate::lower::model::OutTy::OutMap(k, v_) => {
                let cp = cp.clone();
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_names_program_type(cp.clone(), k.clone()), move |names_program_type_5369: bool| prism_rtl::Turn::Finished(names_program_type_5369 || names_program_type(&cp, &v_)))
            },
            crate::lower::model::OutTy::OutFn(ps, r) => {
                let cp = cp.clone();
                let ps = ps.clone();
                let r = (**r).clone();
                call_then(start_names_program_type(cp.clone(), r.clone()), move |names_program_type_5446: bool| fold_job(ps.clone(), names_program_type_5446, {
                    let cp = cp.clone();
                    Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let f = p0;
                            let x = p1;
                            prism_rtl::Turn::Finished(f || names_program_type(&cp, &x))
                        }))
                    }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
                }).cycle())
            },
            crate::lower::model::OutTy::OutDyn(i) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp: cp.clone(), t: (**i).clone() })),
            crate::lower::model::OutTy::OutEvent(i) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp: cp.clone(), t: (**i).clone() })),
            crate::lower::model::OutTy::OutNamed(_, args) => fold_job(args.clone(), false, {
                let cp = cp.clone();
                Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let f = p0;
                        let x = p1;
                        prism_rtl::Turn::Finished(f || behind(&cp, &x))
                    }))
                }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start Behind, x`: what the function value is when passed to `@Run`.
pub fn start_behind(cp: crate::emit::cpp::Cp, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(Behind { cp, t })
}

/// ```prism
/// NamesProgramType: unbounded fn Cp, OutTy -> Bool
/// ```
pub fn names_program_type(cp: &crate::emit::cpp::Cp, t: &crate::lower::model::OutTy) -> bool {
    match t {
        crate::lower::model::OutTy::OutNamed(n, args) => {
            let own = match crate::emit::cpp::type_of(cp, n) {
                Some(info) => (&info.kind != &Text::lit("node")) && (&info.kind != &Text::lit("job")),
                None => false,
            };
            own || run_to_end(fold_job(args.clone(), false, {
                let cp = cp.clone();
                Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let f = p0;
                        let x = p1;
                        prism_rtl::Turn::Finished(f || names_program_type(&cp, &x))
                    }))
                }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
            }))
        },
        crate::lower::model::OutTy::OutOpt(i) => names_program_type(cp, &**i),
        crate::lower::model::OutTy::OutRes(i) => names_program_type(cp, &**i),
        crate::lower::model::OutTy::OutRc(i) => names_program_type(cp, &**i),
        crate::lower::model::OutTy::OutCell(i) => names_program_type(cp, &**i),
        crate::lower::model::OutTy::OutArray(i) => names_program_type(cp, &**i),
        crate::lower::model::OutTy::OutMap(k, v_) => names_program_type(cp, &**k) || names_program_type(cp, &**v_),
        crate::lower::model::OutTy::OutTuple(ts) => run_to_end(fold_job(ts.clone(), false, {
            let cp = cp.clone();
            Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let f = p0;
                    let x = p1;
                    prism_rtl::Turn::Finished(f || names_program_type(&cp, &x))
                }))
            }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::lower::model::OutTy::OutFn(ps, r) => run_to_end(fold_job(ps.clone(), names_program_type(cp, &**r), {
            let cp = cp.clone();
            Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let f = p0;
                    let x = p1;
                    prism_rtl::Turn::Finished(f || names_program_type(&cp, &x))
                }))
            }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::lower::model::OutTy::OutDyn(i) => names_program_type(cp, &**i),
        crate::lower::model::OutTy::OutEvent(i) => names_program_type(cp, &**i),
        _ => false,
    }
}

/// The step machine of `NamesProgramType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamesProgramType: unbounded fn Cp, OutTy -> Bool
/// ```
pub struct NamesProgramType {
    pub cp: crate::emit::cpp::Cp,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<bool> for NamesProgramType {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let cp = &self.cp;
        let t = &self.t;
        match t {
            crate::lower::model::OutTy::OutNamed(n, args) => {
                let own = match crate::emit::cpp::type_of(cp, n) {
                    Some(info) => (&info.kind != &Text::lit("node")) && (&info.kind != &Text::lit("job")),
                    None => false,
                };
                prism_rtl::Turn::Finished(own || run_to_end(fold_job(args.clone(), false, {
                    let cp = cp.clone();
                    Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let f = p0;
                            let x = p1;
                            prism_rtl::Turn::Finished(f || names_program_type(&cp, &x))
                        }))
                    }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
                })))
            },
            crate::lower::model::OutTy::OutOpt(i) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp: cp.clone(), t: (**i).clone() })),
            crate::lower::model::OutTy::OutRes(i) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp: cp.clone(), t: (**i).clone() })),
            crate::lower::model::OutTy::OutRc(i) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp: cp.clone(), t: (**i).clone() })),
            crate::lower::model::OutTy::OutCell(i) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp: cp.clone(), t: (**i).clone() })),
            crate::lower::model::OutTy::OutArray(i) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp: cp.clone(), t: (**i).clone() })),
            crate::lower::model::OutTy::OutMap(k, v_) => {
                let cp = cp.clone();
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_names_program_type(cp.clone(), k.clone()), move |names_program_type_6249: bool| prism_rtl::Turn::Finished(names_program_type_6249 || names_program_type(&cp, &v_)))
            },
            crate::lower::model::OutTy::OutTuple(ts) => fold_job(ts.clone(), false, {
                let cp = cp.clone();
                Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let f = p0;
                        let x = p1;
                        prism_rtl::Turn::Finished(f || names_program_type(&cp, &x))
                    }))
                }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            crate::lower::model::OutTy::OutFn(ps, r) => {
                let cp = cp.clone();
                let ps = ps.clone();
                let r = (**r).clone();
                call_then(start_names_program_type(cp.clone(), r.clone()), move |names_program_type_6395: bool| fold_job(ps.clone(), names_program_type_6395, {
                    let cp = cp.clone();
                    Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let f = p0;
                            let x = p1;
                            prism_rtl::Turn::Finished(f || names_program_type(&cp, &x))
                        }))
                    }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
                }).cycle())
            },
            crate::lower::model::OutTy::OutDyn(i) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp: cp.clone(), t: (**i).clone() })),
            crate::lower::model::OutTy::OutEvent(i) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp: cp.clone(), t: (**i).clone() })),
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start NamesProgramType, x`: what the function value is when passed to `@Run`.
pub fn start_names_program_type(cp: crate::emit::cpp::Cp, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(NamesProgramType { cp, t })
}

/// ```prism
/// let noParts
/// ```
pub fn no_parts() -> Parts {
    Parts { forward: Array::new(), values: Array::new(), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: Array::new() }
}

/// ```prism
/// JoinParts: fn Parts, Parts -> Parts
/// ```
pub fn join_parts(a: &Parts, b: &Parts) -> Parts {
    Parts { forward: append(&a.forward, &b.forward), values: append(&a.values, &b.values), protos: append(&a.protos, &b.protos), classes: append(&a.classes, &b.classes), outer: append(&a.outer, &b.outer), generic: append(&a.generic, &b.generic), defs: append(&a.defs, &b.defs) }
}

/// ```prism
/// ItemParts: unbounded fn Cp, Item -> Parts
/// ```
pub fn item_parts(cp: &crate::emit::cpp::Cp, it: &crate::lower::model::Item) -> Parts {
    match it {
        crate::lower::model::Item::ItType(t) => type_parts(cp, t),
        crate::lower::model::Item::ItTag(t) => tag_parts(cp, t),
        crate::lower::model::Item::ItRow(r) => row_parts(cp, &cp.home, r),
        crate::lower::model::Item::ItFn(f) => fn_parts(cp, f),
        crate::lower::model::Item::ItJob(j) => job_parts(cp, j),
        crate::lower::model::Item::ItNode(n) => crate::emit::cpp::program::node_parts(cp, n),
        crate::lower::model::Item::ItTrait(t) => trait_parts(cp, t),
        crate::lower::model::Item::ItImpl(i) => impl_parts(cp, i),
        crate::lower::model::Item::ItNote(t) => protos_defs(&Array::new(), &Array::from(vec![Text::from(format!("// {}", t))])),
        crate::lower::model::Item::ItRefused(t) => protos_defs(&Array::new(), &Array::from(vec![Text::from(format!("compile_error!(\"{}{}\");", &crate::lower::expr::lowering_refusal(), &crate::lower::expr::escape(t)))])),
    }
}

/// The step machine of `ItemParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ItemParts: unbounded fn Cp, Item -> Parts
/// ```
pub struct ItemParts {
    pub cp: crate::emit::cpp::Cp,
    pub it: crate::lower::model::Item,
}

impl prism_rtl::Job<Parts> for ItemParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let it = &self.it;
        match it {
            crate::lower::model::Item::ItType(t) => prism_rtl::Turn::More(Rc::new(TypeParts { cp: cp.clone(), t: t.clone() })),
            crate::lower::model::Item::ItTag(t) => prism_rtl::Turn::More(Rc::new(TagParts { cp: cp.clone(), t: t.clone() })),
            crate::lower::model::Item::ItRow(r) => prism_rtl::Turn::More(Rc::new(RowParts { cp: cp.clone(), m: cp.home.clone(), r: r.clone() })),
            crate::lower::model::Item::ItFn(f) => prism_rtl::Turn::More(Rc::new(FnParts { cp: cp.clone(), f: f.clone() })),
            crate::lower::model::Item::ItJob(j) => prism_rtl::Turn::More(Rc::new(JobParts { cp: cp.clone(), j: j.clone() })),
            crate::lower::model::Item::ItNode(n) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::program::NodeParts { cp: cp.clone(), n: n.clone() })),
            crate::lower::model::Item::ItTrait(t) => prism_rtl::Turn::More(Rc::new(TraitParts { cp: cp.clone(), t: t.clone() })),
            crate::lower::model::Item::ItImpl(i) => prism_rtl::Turn::More(Rc::new(ImplParts { cp: cp.clone(), i: i.clone() })),
            crate::lower::model::Item::ItNote(t) => prism_rtl::Turn::Finished(protos_defs(&Array::new(), &Array::from(vec![Text::from(format!("// {}", t))]))),
            crate::lower::model::Item::ItRefused(t) => prism_rtl::Turn::Finished(protos_defs(&Array::new(), &Array::from(vec![Text::from(format!("compile_error!(\"{}{}\");", &crate::lower::expr::lowering_refusal(), &crate::lower::expr::escape(t)))]))),
        }
    }
}

/// `Start ItemParts, x`: what the function value is when passed to `@Run`.
pub fn start_item_parts(cp: crate::emit::cpp::Cp, it: crate::lower::model::Item) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(ItemParts { cp, it })
}

/// ```prism
/// FnParts: unbounded fn Cp, FnDef -> Parts
/// ```
pub fn fn_parts(cp: &crate::emit::cpp::Cp, f: &crate::lower::model::FnDef) -> Parts {
    if &len(&f.generics) > &Nat::from(0u32) {
        {
            let mut this: Parts = generic_only(&Array::from(vec![fn_definition(cp, f)]));
            this.protos = Array::from(vec![Text::from(format!("{};", &fn_signature(cp, f)))]);
            this
        }
    } else {
        protos_defs(&Array::from(vec![Text::from(format!("{};", &fn_signature(cp, f)))]), &Array::from(vec![fn_definition(cp, f)]))
    }
}

/// The step machine of `FnParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnParts: unbounded fn Cp, FnDef -> Parts
/// ```
pub struct FnParts {
    pub cp: crate::emit::cpp::Cp,
    pub f: crate::lower::model::FnDef,
}

impl prism_rtl::Job<Parts> for FnParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let f = &self.f;
        if &len(&f.generics) > &Nat::from(0u32) {
            prism_rtl::Turn::Finished({
                let mut this: Parts = generic_only(&Array::from(vec![fn_definition(cp, f)]));
                this.protos = Array::from(vec![Text::from(format!("{};", &fn_signature(cp, f)))]);
                this
            })
        } else {
            {
                let cp = cp.clone();
                let f = f.clone();
                call_then(start_fn_signature(cp.clone(), f.clone()), move |fn_signature_7638: Text| call_then(start_fn_definition(cp.clone(), f.clone()), move |fn_definition_7665: Text| prism_rtl::Turn::Finished(protos_defs(&Array::from(vec![Text::from(format!("{};", &fn_signature_7638))]), &Array::from(vec![fn_definition_7665])))))
            }
        }
    }
}

/// `Start FnParts, x`: what the function value is when passed to `@Run`.
pub fn start_fn_parts(cp: crate::emit::cpp::Cp, f: crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(FnParts { cp, f })
}

/// ```prism
/// CppDoc: fn Text -> Text
/// ```
pub fn cpp_doc(text_: &Text) -> Text {
    if text_ == &Text::lit("") {
        Text::lit("")
    } else {
        concat(&each(&split_on(text_, &Text::lit("\n")), &(|l: &Text| if l == &Text::lit("") {
            Text::lit("///\n")
        } else {
            Text::from(format!("/// {}\n", l))
        })))
    }
}

/// ```prism
/// CppSourceDoc: fn Text, Text -> Text
/// ```
pub fn cpp_source_doc(lead: &Text, source: &Text) -> Text {
    let quoted = concat(&each(&split_on(source, &Text::lit("\n")), &(|l: &Text| if l == &Text::lit("") {
        Text::lit("///\n")
    } else {
        Text::from(format!("/// {}\n", l))
    })));
    if source == &Text::lit("") {
        cpp_doc(lead)
    } else {
        if lead == &Text::lit("") {
            Text::from(format!("/// ```prism\n{}/// ```\n", &quoted))
        } else {
            Text::from(format!("/// {}\n///\n/// ```prism\n{}/// ```\n", lead, &quoted))
        }
    }
}

/// ```prism
/// TypeParts: unbounded fn Cp, TyDef -> Parts
/// ```
pub fn type_parts(cp: &crate::emit::cpp::Cp, t: &crate::lower::model::TyDef) -> Parts {
    let eq = t.eq;
    let ord = t.ord;
    let gens = cpp_template_head(&t.params);
    let head = head_of(&t.name, &t.params);
    let doc = cpp_source_doc(&Text::from(format!("`{}`:", &t.prism)), &t.doc);
    let members_ = members(&(&t.show != &crate::lower::model::Shown::NotShown), &t.pod, &head);
    let generic = &len(&t.params) > &Nat::from(0u32);
    let fwd = Text::from(format!("{}{} {};", &gens, &(if &t.shape == &crate::lower::model::TyShape::ShapeChoice {
        Text::lit("class")
    } else {
        Text::lit("struct")
    }), &t.name));
    let deps = crate::emit::cpp::patterns::concat2(&run_to_end(each_job(t.cases.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::CaseDef| {
            let cp = cp.clone();
            entered(once_job(move || {
                let c = p0;
                call_value(each_job(c.fields.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let (_, ft) = p0;
                            prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: ft.clone() }))
                        }))
                    }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_9019: Array<Array<Text>>| prism_rtl::Turn::Finished(crate::emit::cpp::patterns::concat2(&each_9019)))
            }))
        }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    })));
    let (text_, cmp_defs) = match &t.shape {
        crate::lower::model::TyShape::ShapeChoice => {
            let names = each(&t.cases, &(|c: &crate::lower::model::CaseDef| c.name.clone()));
            let cases = crate::syntax::lexer::chars::join(&run_to_end(each_job(t.cases.clone(), {
                let cp = cp.clone();
                let eq = eq;
                let ord = ord;
                Rc::new(move |p0: crate::lower::model::CaseDef| {
                    let cp = cp.clone();
                    let eq = eq;
                    let ord = ord;
                    entered(once_job(move || {
                        let c = p0;
                        prism_rtl::Turn::More(Rc::new(CaseStruct { cp: cp.clone(), c: c.clone(), eq, ord }))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
            })), &Text::lit("\n"));
            let cls = crate::emit::cpp::templates::items::choice_class(&doc, &gens, &t.name, &cases, &crate::syntax::lexer::chars::join(&names, &Text::lit(", ")), &members_);
            let cmp = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![if eq {
                Text::from(format!("{}inline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &gens, &head, &head))
            } else {
                Text::lit("")
            }, if ord {
                Text::from(format!("{}inline std::strong_ordering operator<=>(const {}& a, const {}& b) {{ return a.cases() <=> b.cases(); }}", &gens, &head, &head))
            } else {
                Text::lit("")
            }]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n"));
            let case_defs = filter(&run_to_end(each_job(t.cases.clone(), {
                let cp = cp.clone();
                let gens = gens.clone();
                let head = head.clone();
                let eq = eq;
                let ord = ord;
                Rc::new(move |p0: crate::lower::model::CaseDef| {
                    let cp = cp.clone();
                    let gens = gens.clone();
                    let head = head.clone();
                    let eq = eq;
                    let ord = ord;
                    entered(once_job(move || {
                        let c = p0;
                        prism_rtl::Turn::More(Rc::new(CaseCmpDefs { cp: cp.clone(), gens: gens.clone(), head: head.clone(), c: c.clone(), eq, ord }))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
            })), &(|s: &Text| s != &Text::lit("")));
            (crate::syntax::lexer::chars::join(&filter(&Array::from(vec![cls.clone(), cmp.clone()]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n")), case_defs.clone())
        },
        _ => {
            let first_ = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            let fields = match &t.shape {
                crate::lower::model::TyShape::ShapeRecord => crate::syntax::lexer::chars::join(&run_to_end(each_job(first_.fields.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let (f, ft) = p0;
                            call_then(crate::emit::cpp::start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_10229: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_10229, &crate::emit::cpp::field_id(&f)))))
                        }))
                    }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
                })), &Text::lit("\n")),
                crate::lower::model::TyShape::ShapeNewtype => positional_fields(cp, &first_.fields),
                _ => Text::lit(""),
            };
            let names = match &t.shape {
                crate::lower::model::TyShape::ShapeRecord => each(&first_.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| crate::emit::cpp::field_id(f))),
                crate::lower::model::TyShape::ShapeNewtype => each(&crate::check::errors::range0(&len(&first_.fields)), &(|i: &Nat| Text::from(format!("a{}", i)))),
                _ => Array::new(),
            };
            let behind_ = run_to_end(fold_job(first_.fields.clone(), false, {
                let cp = cp.clone();
                Rc::new(move |(p0, p1): (bool, (Text, crate::lower::model::OutTy))| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let f = p0;
                        let (_, ft) = p1;
                        prism_rtl::Turn::Finished(f || behind(&cp, &ft))
                    }))
                }) as Rc<dyn Fn((bool, (Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>
            }));
            let (cmps, cmp_defs) = comparisons(&gens, &head, &t.name, &names, &eq, &ord, &behind_);
            let decl = crate::emit::cpp::templates::items::value_struct(&doc, &gens, &t.name, &fields, &crate::syntax::lexer::chars::join(&filter(&Array::from(vec![cmps.clone(), members_.clone()]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n")));
            (decl.clone(), if &cmp_defs == &Text::lit("") {
                Array::new()
            } else {
                Array::from(vec![cmp_defs.clone()])
            })
        },
    };
    let defs = append(&cmp_defs, &Array::from(vec![type_defs(cp, t, &head)]));
    Parts { forward: Array::from(vec![fwd.clone()]), values: Array::from(vec![ValueDecl { path_: decl_path(cp, &t.name), deps: deps.clone(), text: text_.clone() }]), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: if generic { defs.clone() } else { Array::new() }, defs: if generic { Array::new() } else { defs.clone() } }
}

/// The step machine of `TypeParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeParts: unbounded fn Cp, TyDef -> Parts
/// ```
pub struct TypeParts {
    pub cp: crate::emit::cpp::Cp,
    pub t: crate::lower::model::TyDef,
}

impl prism_rtl::Job<Parts> for TypeParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let t = &self.t;
        let eq = t.eq;
        let ord = t.ord;
        let gens = cpp_template_head(&t.params);
        let head = head_of(&t.name, &t.params);
        let doc = cpp_source_doc(&Text::from(format!("`{}`:", &t.prism)), &t.doc);
        let members_ = members(&(&t.show != &crate::lower::model::Shown::NotShown), &t.pod, &head);
        let generic = &len(&t.params) > &Nat::from(0u32);
        let fwd = Text::from(format!("{}{} {};", &gens, &(if &t.shape == &crate::lower::model::TyShape::ShapeChoice {
            Text::lit("class")
        } else {
            Text::lit("struct")
        }), &t.name));
        let cp = cp.clone();
        let t = t.clone();
        call_value(each_job(t.cases.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: crate::lower::model::CaseDef| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let c = p0;
                    call_value(each_job(c.fields.clone(), {
                        let cp = cp.clone();
                        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                            let cp = cp.clone();
                            entered(once_job(move || {
                                let (_, ft) = p0;
                                prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: ft.clone() }))
                            }))
                        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }), move |each_9019: Array<Array<Text>>| prism_rtl::Turn::Finished(crate::emit::cpp::patterns::concat2(&each_9019)))
                }))
            }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }), move |each_8991: Array<Array<Text>>| {
            let deps = crate::emit::cpp::patterns::concat2(&each_8991);
            let (text_, cmp_defs) = match &t.shape {
                crate::lower::model::TyShape::ShapeChoice => {
                    let names = each(&t.cases, &(|c: &crate::lower::model::CaseDef| c.name.clone()));
                    let cases = crate::syntax::lexer::chars::join(&run_to_end(each_job(t.cases.clone(), {
                        let cp = cp.clone();
                        let eq = eq;
                        let ord = ord;
                        Rc::new(move |p0: crate::lower::model::CaseDef| {
                            let cp = cp.clone();
                            let eq = eq;
                            let ord = ord;
                            entered(once_job(move || {
                                let c = p0;
                                prism_rtl::Turn::More(Rc::new(CaseStruct { cp: cp.clone(), c: c.clone(), eq, ord }))
                            }))
                        }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
                    })), &Text::lit("\n"));
                    let cls = crate::emit::cpp::templates::items::choice_class(&doc, &gens, &t.name, &cases, &crate::syntax::lexer::chars::join(&names, &Text::lit(", ")), &members_);
                    let cmp = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![if eq {
                        Text::from(format!("{}inline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &gens, &head, &head))
                    } else {
                        Text::lit("")
                    }, if ord {
                        Text::from(format!("{}inline std::strong_ordering operator<=>(const {}& a, const {}& b) {{ return a.cases() <=> b.cases(); }}", &gens, &head, &head))
                    } else {
                        Text::lit("")
                    }]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n"));
                    let case_defs = filter(&run_to_end(each_job(t.cases.clone(), {
                        let cp = cp.clone();
                        let gens = gens.clone();
                        let head = head.clone();
                        let eq = eq;
                        let ord = ord;
                        Rc::new(move |p0: crate::lower::model::CaseDef| {
                            let cp = cp.clone();
                            let gens = gens.clone();
                            let head = head.clone();
                            let eq = eq;
                            let ord = ord;
                            entered(once_job(move || {
                                let c = p0;
                                prism_rtl::Turn::More(Rc::new(CaseCmpDefs { cp: cp.clone(), gens: gens.clone(), head: head.clone(), c: c.clone(), eq, ord }))
                            }))
                        }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
                    })), &(|s: &Text| s != &Text::lit("")));
                    (crate::syntax::lexer::chars::join(&filter(&Array::from(vec![cls.clone(), cmp.clone()]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n")), case_defs.clone())
                },
                _ => {
                    let first_ = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                    let fields = match &t.shape {
                        crate::lower::model::TyShape::ShapeRecord => crate::syntax::lexer::chars::join(&run_to_end(each_job(first_.fields.clone(), {
                            let cp = cp.clone();
                            Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                                let cp = cp.clone();
                                entered(once_job(move || {
                                    let (f, ft) = p0;
                                    call_then(crate::emit::cpp::start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_10229: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_10229, &crate::emit::cpp::field_id(&f)))))
                                }))
                            }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
                        })), &Text::lit("\n")),
                        crate::lower::model::TyShape::ShapeNewtype => positional_fields(&cp, &first_.fields),
                        _ => Text::lit(""),
                    };
                    let names = match &t.shape {
                        crate::lower::model::TyShape::ShapeRecord => each(&first_.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| crate::emit::cpp::field_id(f))),
                        crate::lower::model::TyShape::ShapeNewtype => each(&crate::check::errors::range0(&len(&first_.fields)), &(|i: &Nat| Text::from(format!("a{}", i)))),
                        _ => Array::new(),
                    };
                    let behind_ = run_to_end(fold_job(first_.fields.clone(), false, {
                        let cp = cp.clone();
                        Rc::new(move |(p0, p1): (bool, (Text, crate::lower::model::OutTy))| {
                            let cp = cp.clone();
                            entered(once_job(move || {
                                let f = p0;
                                let (_, ft) = p1;
                                prism_rtl::Turn::Finished(f || behind(&cp, &ft))
                            }))
                        }) as Rc<dyn Fn((bool, (Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>
                    }));
                    let (cmps, cmp_defs) = comparisons(&gens, &head, &t.name, &names, &eq, &ord, &behind_);
                    let decl = crate::emit::cpp::templates::items::value_struct(&doc, &gens, &t.name, &fields, &crate::syntax::lexer::chars::join(&filter(&Array::from(vec![cmps.clone(), members_.clone()]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n")));
                    (decl.clone(), if &cmp_defs == &Text::lit("") {
                        Array::new()
                    } else {
                        Array::from(vec![cmp_defs.clone()])
                    })
                },
            };
            call_then(start_type_defs(cp.clone(), t.clone(), head.clone()), move |type_defs_10979: Text| {
                let defs = append(&cmp_defs, &Array::from(vec![type_defs_10979]));
                prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![fwd.clone()]), values: Array::from(vec![ValueDecl { path_: decl_path(&cp, &t.name), deps: deps.clone(), text: text_.clone() }]), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: if generic { defs.clone() } else { Array::new() }, defs: if generic { Array::new() } else { defs.clone() } })
            })
        })
    }
}

/// `Start TypeParts, x`: what the function value is when passed to `@Run`.
pub fn start_type_parts(cp: crate::emit::cpp::Cp, t: crate::lower::model::TyDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(TypeParts { cp, t })
}

/// ```prism
/// DeclPath: fn Cp, Text -> Text
/// ```
pub fn decl_path(cp: &crate::emit::cpp::Cp, name: &Text) -> Text {
    if &cp.home == &Text::lit("") {
        name.clone()
    } else {
        Text::from(format!("{}::{}", &cp.home, name))
    }
}

/// ```prism
/// Comparisons: fn Text, Text, Text, [Text], Bool, Bool, Bool -> ((Text, Text))
/// ```
pub fn comparisons(gens: &Text, owner: &Text, self_: &Text, names: &Array<Text>, eq: &bool, ord: &bool, behind_: &bool) -> (Text, Text) {
    if !*behind_ {
        (crate::syntax::lexer::chars::join(&filter(&Array::from(vec![if *eq {
            Text::from(format!("bool operator==(const {}&) const = default;", self_))
        } else {
            Text::lit("")
        }, if *ord {
            Text::from(format!("auto operator<=>(const {}&) const = default;", self_))
        } else {
            Text::lit("")
        }]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n")), Text::lit(""))
    } else {
        {
            let decls = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![if *eq {
                Text::from(format!("bool operator==(const {}&) const;", self_))
            } else {
                Text::lit("")
            }, if *ord {
                Text::from(format!("std::strong_ordering operator<=>(const {}&) const;", self_))
            } else {
                Text::lit("")
            }]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n"));
            let eq_body = if &len(names) == &Nat::from(0u32) {
                Text::lit("true")
            } else {
                crate::syntax::lexer::chars::join(&each(names, &(|n: &Text| Text::from(format!("{} == o.{}", n, n)))), &Text::lit(" && "))
            };
            let ord_body = if &len(names) == &Nat::from(0u32) {
                Text::lit("std::strong_ordering::equal")
            } else {
                Text::from(format!("std::tie({}) <=> std::tie({})", &crate::syntax::lexer::chars::join(names, &Text::lit(", ")), &crate::syntax::lexer::chars::join(&each(names, &(|n: &Text| Text::from(format!("o.{}", n)))), &Text::lit(", "))))
            };
            let defs = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![if *eq {
                Text::from(format!("{}bool {}::operator==(const {}& o) const {{ return {}; }}", gens, owner, self_, &eq_body))
            } else {
                Text::lit("")
            }, if *ord {
                Text::from(format!("{}std::strong_ordering {}::operator<=>(const {}& o) const {{ return {}; }}", gens, owner, self_, &ord_body))
            } else {
                Text::lit("")
            }]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n"));
            (decls.clone(), defs.clone())
        }
    }
}

/// ```prism
/// Members: fn Bool, Bool, Text -> Text
/// ```
pub fn members(shown: &bool, pod: &bool, head: &Text) -> Text {
    let s = if *shown {
        Array::from(vec![Text::lit("void show(Printer& p) const;")])
    } else {
        Array::new()
    };
    let d = if *pod {
        Array::from(vec![Text::lit("Pod to_pod() const;"), Text::from(format!("static Result<{}> from_pod(const Pod& whole);", head))])
    } else {
        Array::new()
    };
    crate::syntax::lexer::chars::join(&append(&s, &d), &Text::lit("\n"))
}

/// ```prism
/// CaseStruct: unbounded fn Cp, CaseDef, Bool, Bool -> Text
/// ```
pub fn case_struct(cp: &crate::emit::cpp::Cp, c: &crate::lower::model::CaseDef, eq: &bool, ord: &bool) -> Text {
    let fields = positional_fields(cp, &c.fields);
    let (cmps, _) = comparisons(&Text::lit(""), &Text::lit(""), &c.name, &case_names(c), eq, ord, &case_behind(cp, c));
    crate::emit::cpp::templates::items::case_decl(&c.name, &crate::syntax::lexer::chars::join(&filter(&Array::from(vec![fields.clone(), cmps.clone()]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n")))
}

/// The step machine of `CaseStruct`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CaseStruct: unbounded fn Cp, CaseDef, Bool, Bool -> Text
/// ```
pub struct CaseStruct {
    pub cp: crate::emit::cpp::Cp,
    pub c: crate::lower::model::CaseDef,
    pub eq: bool,
    pub ord: bool,
}

impl prism_rtl::Job<Text> for CaseStruct {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let c = &self.c;
        let eq = &self.eq;
        let ord = &self.ord;
        let c = c.clone();
        let cp = cp.clone();
        let eq = *eq;
        let ord = *ord;
        call_then(start_positional_fields(cp.clone(), c.fields.clone()), move |positional_fields_13260: Text| {
            let fields = positional_fields_13260;
            call_then(start_case_behind(cp.clone(), c.clone()), move |case_behind_13370: bool| {
                let (cmps, _) = comparisons(&Text::lit(""), &Text::lit(""), &c.name, &case_names(&c), &eq, &ord, &case_behind_13370);
                prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::case_decl(&c.name, &crate::syntax::lexer::chars::join(&filter(&Array::from(vec![fields.clone(), cmps.clone()]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n"))))
            })
        })
    }
}

/// `Start CaseStruct, x`: what the function value is when passed to `@Run`.
pub fn start_case_struct(cp: crate::emit::cpp::Cp, c: crate::lower::model::CaseDef, eq: bool, ord: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CaseStruct { cp, c, eq, ord })
}

/// ```prism
/// CaseCmpDefs: unbounded fn Cp, Text, Text, CaseDef, Bool, Bool -> Text
/// ```
pub fn case_cmp_defs(cp: &crate::emit::cpp::Cp, gens: &Text, head: &Text, c: &crate::lower::model::CaseDef, eq: &bool, ord: &bool) -> Text {
    let (_, defs) = comparisons(gens, &Text::from(format!("{}::{}", head, &c.name)), &c.name, &case_names(c), eq, ord, &case_behind(cp, c));
    defs.clone()
}

/// The step machine of `CaseCmpDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CaseCmpDefs: unbounded fn Cp, Text, Text, CaseDef, Bool, Bool -> Text
/// ```
pub struct CaseCmpDefs {
    pub cp: crate::emit::cpp::Cp,
    pub gens: Text,
    pub head: Text,
    pub c: crate::lower::model::CaseDef,
    pub eq: bool,
    pub ord: bool,
}

impl prism_rtl::Job<Text> for CaseCmpDefs {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let gens = &self.gens;
        let head = &self.head;
        let c = &self.c;
        let eq = &self.eq;
        let ord = &self.ord;
        let c = c.clone();
        let cp = cp.clone();
        let eq = *eq;
        let gens = gens.clone();
        let head = head.clone();
        let ord = *ord;
        call_then(start_case_behind(cp.clone(), c.clone()), move |case_behind_13763: bool| {
            let (_, defs) = comparisons(&gens, &Text::from(format!("{}::{}", &head, &c.name)), &c.name, &case_names(&c), &eq, &ord, &case_behind_13763);
            prism_rtl::Turn::Finished(defs.clone())
        })
    }
}

/// `Start CaseCmpDefs, x`: what the function value is when passed to `@Run`.
pub fn start_case_cmp_defs(cp: crate::emit::cpp::Cp, gens: Text, head: Text, c: crate::lower::model::CaseDef, eq: bool, ord: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CaseCmpDefs { cp, gens, head, c, eq, ord })
}

/// ```prism
/// CaseNames: fn CaseDef -> [Text]
/// ```
pub fn case_names(c: &crate::lower::model::CaseDef) -> Array<Text> {
    each(&crate::check::errors::range0(&len(&c.fields)), &(|i: &Nat| Text::from(format!("a{}", i))))
}

/// ```prism
/// CaseBehind: unbounded fn Cp, CaseDef -> Bool
/// ```
pub fn case_behind(cp: &crate::emit::cpp::Cp, c: &crate::lower::model::CaseDef) -> bool {
    run_to_end(fold_job(c.fields.clone(), false, {
        let cp = cp.clone();
        Rc::new(move |(p0, p1): (bool, (Text, crate::lower::model::OutTy))| {
            let cp = cp.clone();
            entered(once_job(move || {
                let f = p0;
                let (_, ft) = p1;
                prism_rtl::Turn::Finished(f || behind(&cp, &ft))
            }))
        }) as Rc<dyn Fn((bool, (Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `CaseBehind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CaseBehind: unbounded fn Cp, CaseDef -> Bool
/// ```
pub struct CaseBehind {
    pub cp: crate::emit::cpp::Cp,
    pub c: crate::lower::model::CaseDef,
}

impl prism_rtl::Job<bool> for CaseBehind {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let cp = &self.cp;
        let c = &self.c;
        fold_job(c.fields.clone(), false, {
            let cp = cp.clone();
            Rc::new(move |(p0, p1): (bool, (Text, crate::lower::model::OutTy))| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let f = p0;
                    let (_, ft) = p1;
                    prism_rtl::Turn::Finished(f || behind(&cp, &ft))
                }))
            }) as Rc<dyn Fn((bool, (Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>
        }).cycle()
    }
}

/// `Start CaseBehind, x`: what the function value is when passed to `@Run`.
pub fn start_case_behind(cp: crate::emit::cpp::Cp, c: crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(CaseBehind { cp, c })
}

/// ```prism
/// TypeDefs: unbounded fn Cp, TyDef, Text -> Text
/// ```
pub fn type_defs(cp: &crate::emit::cpp::Cp, t: &crate::lower::model::TyDef, head: &Text) -> Text {
    let gens = cpp_template_head(&t.params);
    let show_ = if &t.show == &crate::lower::model::Shown::ShownDerived {
        Array::from(vec![show_def(cp, t, head, &gens)])
    } else {
        Array::new()
    };
    let pod = if t.pod {
        Array::from(vec![to_pod_def(cp, t, head, &gens), from_pod_def(cp, t, head, &gens)])
    } else {
        Array::new()
    };
    crate::syntax::lexer::chars::join(&append(&show_, &pod), &Text::lit("\n"))
}

/// The step machine of `TypeDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeDefs: unbounded fn Cp, TyDef, Text -> Text
/// ```
pub struct TypeDefs {
    pub cp: crate::emit::cpp::Cp,
    pub t: crate::lower::model::TyDef,
    pub head: Text,
}

impl prism_rtl::Job<Text> for TypeDefs {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let t = &self.t;
        let head = &self.head;
        let gens = cpp_template_head(&t.params);
        let show_ = if &t.show == &crate::lower::model::Shown::ShownDerived {
            Array::from(vec![show_def(cp, t, head, &gens)])
        } else {
            Array::new()
        };
        let pod = if t.pod {
            Array::from(vec![to_pod_def(cp, t, head, &gens), from_pod_def(cp, t, head, &gens)])
        } else {
            Array::new()
        };
        prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&append(&show_, &pod), &Text::lit("\n")))
    }
}

/// `Start TypeDefs, x`: what the function value is when passed to `@Run`.
pub fn start_type_defs(cp: crate::emit::cpp::Cp, t: crate::lower::model::TyDef, head: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TypeDefs { cp, t, head })
}

/// ```prism
/// ShowDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub fn show_def(cp: &crate::emit::cpp::Cp, t: &crate::lower::model::TyDef, head: &Text, gens: &Text) -> Text {
    let body = match &t.shape {
        crate::lower::model::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            Text::from(format!("p.record(\"{}\", {{{}}});", &t.prism, &crate::syntax::lexer::chars::join(&each(&c.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", {}}}", &prism_field(f), &crate::emit::cpp::field_id(f))))), &Text::lit(", "))))
        },
        crate::lower::model::TyShape::ShapeChoice => crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&len(&t.cases)), &(|i: &Nat| show_case(t, i))), &Text::lit("\n")),
        crate::lower::model::TyShape::ShapeNewtype => Text::from(format!("p.choice(\"{}\", {{{}}});", &first_case(t), &crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&first_arity(t)), &(|k: &Nat| Text::from(format!("a{}", k)))), &Text::lit(", ")))),
        crate::lower::model::TyShape::ShapeUnit => Text::from(format!("p.choice(\"{}\", {{}});", &first_case(t))),
    };
    crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}void {}::show(Printer& p) const", gens, head)), &body)
}

/// The step machine of `ShowDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub struct ShowDef {
    pub cp: crate::emit::cpp::Cp,
    pub t: crate::lower::model::TyDef,
    pub head: Text,
    pub gens: Text,
}

impl prism_rtl::Job<Text> for ShowDef {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let t = &self.t;
        let head = &self.head;
        let gens = &self.gens;
        let body = match &t.shape {
            crate::lower::model::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                Text::from(format!("p.record(\"{}\", {{{}}});", &t.prism, &crate::syntax::lexer::chars::join(&each(&c.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", {}}}", &prism_field(f), &crate::emit::cpp::field_id(f))))), &Text::lit(", "))))
            },
            crate::lower::model::TyShape::ShapeChoice => crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&len(&t.cases)), &(|i: &Nat| show_case(t, i))), &Text::lit("\n")),
            crate::lower::model::TyShape::ShapeNewtype => Text::from(format!("p.choice(\"{}\", {{{}}});", &first_case(t), &crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&first_arity(t)), &(|k: &Nat| Text::from(format!("a{}", k)))), &Text::lit(", ")))),
            crate::lower::model::TyShape::ShapeUnit => Text::from(format!("p.choice(\"{}\", {{}});", &first_case(t))),
        };
        prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}void {}::show(Printer& p) const", gens, head)), &body))
    }
}

/// `Start ShowDef, x`: what the function value is when passed to `@Run`.
pub fn start_show_def(cp: crate::emit::cpp::Cp, t: crate::lower::model::TyDef, head: Text, gens: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ShowDef { cp, t, head, gens })
}

/// ```prism
/// ShowCase: fn TyDef, Nat -> Text
/// ```
pub fn show_case(t: &crate::lower::model::TyDef, i: &Nat) -> Text {
    let c = or(&index(&t.cases, i), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
    let head = Text::from(format!("{} (auto c = std::get_if<{}>(&cases()))", &(if i == &Nat::from(0u32) { Text::lit("if") } else { Text::lit("else if") }), &c.name));
    Text::from(format!("{} p.choice(\"{}\", {{{}}});", &head, &c.prism, &crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&len(&c.fields)), &(|k: &Nat| Text::from(format!("c->a{}", k)))), &Text::lit(", "))))
}

/// ```prism
/// FirstCase: fn TyDef -> Text
/// ```
pub fn first_case(t: &crate::lower::model::TyDef) -> Text {
    or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: t.prism.clone(), fields: Array::new() }).prism.clone()
}

/// ```prism
/// FirstArity: fn TyDef -> Nat
/// ```
pub fn first_arity(t: &crate::lower::model::TyDef) -> Nat {
    len(&or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() }).fields)
}

/// ```prism
/// FieldTypes: fn [((Text, OutTy))] -> [OutTy]
/// ```
pub fn field_types(fs: &Array<(Text, crate::lower::model::OutTy)>) -> Array<crate::lower::model::OutTy> {
    each(fs, &(|(_, t): &(Text, crate::lower::model::OutTy)| t.clone()))
}

/// ```prism
/// PositionalFields: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub fn positional_fields(cp: &crate::emit::cpp::Cp, fs: &Array<(Text, crate::lower::model::OutTy)>) -> Text {
    let tys = field_types(fs);
    crate::syntax::lexer::chars::join(&run_to_end(each_job(crate::check::errors::range0(&len(&tys)), {
        let cp = cp.clone();
        let tys = tys.clone();
        Rc::new(move |p0: Nat| {
            let cp = cp.clone();
            let tys = tys.clone();
            entered(once_job(move || {
                let i = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), or(&index(&tys, &i), &crate::lower::model::OutTy::OutUnit)), move |cpp_type_15954: Text| prism_rtl::Turn::Finished(Text::from(format!("{} a{};", &cpp_type_15954, &i))))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"))
}

/// The step machine of `PositionalFields`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PositionalFields: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub struct PositionalFields {
    pub cp: crate::emit::cpp::Cp,
    pub fs: Array<(Text, crate::lower::model::OutTy)>,
}

impl prism_rtl::Job<Text> for PositionalFields {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let fs = &self.fs;
        let tys = field_types(fs);
        let cp = cp.clone();
        call_value(each_job(crate::check::errors::range0(&len(&tys)), {
            let cp = cp.clone();
            let tys = tys.clone();
            Rc::new(move |p0: Nat| {
                let cp = cp.clone();
                let tys = tys.clone();
                entered(once_job(move || {
                    let i = p0;
                    call_then(crate::emit::cpp::start_cpp_type(cp.clone(), or(&index(&tys, &i), &crate::lower::model::OutTy::OutUnit)), move |cpp_type_15954: Text| prism_rtl::Turn::Finished(Text::from(format!("{} a{};", &cpp_type_15954, &i))))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_15922: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&each_15922, &Text::lit("\n"))))
    }
}

/// `Start PositionalFields, x`: what the function value is when passed to `@Run`.
pub fn start_positional_fields(cp: crate::emit::cpp::Cp, fs: Array<(Text, crate::lower::model::OutTy)>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(PositionalFields { cp, fs })
}

/// ```prism
/// ToPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub fn to_pod_def(cp: &crate::emit::cpp::Cp, t: &crate::lower::model::TyDef, head: &Text, gens: &Text) -> Text {
    let structure = match &t.shape {
        crate::lower::model::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            Text::from(format!("Pod::record(\"{}\", {{{}}})", &t.prism, &crate::syntax::lexer::chars::join(&each(&c.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", prism_rtl::to_pod({})}}", &prism_field(f), &crate::emit::cpp::field_id(f))))), &Text::lit(", "))))
        },
        crate::lower::model::TyShape::ShapeChoice => choice_pod(t),
        crate::lower::model::TyShape::ShapeNewtype => Text::from(format!("Pod::choice(\"{}\", {{{}}})", &first_case(t), &crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&first_arity(t)), &(|k: &Nat| Text::from(format!("prism_rtl::to_pod(a{})", k)))), &Text::lit(", ")))),
        crate::lower::model::TyShape::ShapeUnit => Text::from(format!("Pod::choice(\"{}\", {{}})", &first_case(t))),
    };
    let body = if &t.show == &crate::lower::model::Shown::ShownOwn {
        Text::from(format!("Pod structure = {};\nreturn Pod::shown(prism_rtl::show(*this), structure);", &structure))
    } else {
        Text::from(format!("return {};", &structure))
    };
    crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}Pod {}::to_pod() const", gens, head)), &body)
}

/// The step machine of `ToPodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ToPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub struct ToPodDef {
    pub cp: crate::emit::cpp::Cp,
    pub t: crate::lower::model::TyDef,
    pub head: Text,
    pub gens: Text,
}

impl prism_rtl::Job<Text> for ToPodDef {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let t = &self.t;
        let head = &self.head;
        let gens = &self.gens;
        let structure = match &t.shape {
            crate::lower::model::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                Text::from(format!("Pod::record(\"{}\", {{{}}})", &t.prism, &crate::syntax::lexer::chars::join(&each(&c.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", prism_rtl::to_pod({})}}", &prism_field(f), &crate::emit::cpp::field_id(f))))), &Text::lit(", "))))
            },
            crate::lower::model::TyShape::ShapeChoice => choice_pod(t),
            crate::lower::model::TyShape::ShapeNewtype => Text::from(format!("Pod::choice(\"{}\", {{{}}})", &first_case(t), &crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&first_arity(t)), &(|k: &Nat| Text::from(format!("prism_rtl::to_pod(a{})", k)))), &Text::lit(", ")))),
            crate::lower::model::TyShape::ShapeUnit => Text::from(format!("Pod::choice(\"{}\", {{}})", &first_case(t))),
        };
        let body = if &t.show == &crate::lower::model::Shown::ShownOwn {
            Text::from(format!("Pod structure = {};\nreturn Pod::shown(prism_rtl::show(*this), structure);", &structure))
        } else {
            Text::from(format!("return {};", &structure))
        };
        prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}Pod {}::to_pod() const", gens, head)), &body))
    }
}

/// `Start ToPodDef, x`: what the function value is when passed to `@Run`.
pub fn start_to_pod_def(cp: crate::emit::cpp::Cp, t: crate::lower::model::TyDef, head: Text, gens: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ToPodDef { cp, t, head, gens })
}

/// ```prism
/// ChoicePod: fn TyDef -> Text
/// ```
pub fn choice_pod(t: &crate::lower::model::TyDef) -> Text {
    let arms = each(&crate::check::errors::range0(&len(&t.cases)), &(|i: &Nat| {
        let c = or(&index(&t.cases, i), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
        Text::from(format!("std::holds_alternative<{}>(cases()) ? Pod::choice(\"{}\", {{{}}})", &c.name, &c.prism, &crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&len(&c.fields)), &(|k: &Nat| Text::from(format!("prism_rtl::to_pod(std::get<{}>(cases()).a{})", &c.name, k)))), &Text::lit(", "))))
    }));
    Text::from(format!("{}\n    : Pod()", &crate::syntax::lexer::chars::join(&arms, &Text::lit("\n    : "))))
}

/// ```prism
/// FromPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub fn from_pod_def(cp: &crate::emit::cpp::Cp, t: &crate::lower::model::TyDef, head: &Text, gens: &Text) -> Text {
    let body = match &t.shape {
        crate::lower::model::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            let reads = crate::syntax::lexer::chars::join(&run_to_end(each_job(c.fields.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let (f, ft) = p0;
                        call_then(crate::emit::cpp::start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_17526: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = TRY(prism_rtl::from_pod<{}>(TRY(crate::prelude::field(whole, \"{}\"))))", &crate::emit::cpp::field_id(&f), &cpp_type_17526, &prism_field(&f)))))
                    }))
                }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
            })), &Text::lit(", "));
            Text::from(format!("return {}{{{}}};", head, &reads))
        },
        _ => {
            let arms = run_to_end(each_job(t.cases.clone(), {
                let cp = cp.clone();
                let t = t.clone();
                let head = head.clone();
                Rc::new(move |p0: crate::lower::model::CaseDef| {
                    let cp = cp.clone();
                    let t = t.clone();
                    let head = head.clone();
                    entered(once_job(move || {
                        let c = p0;
                        {
                            let n = len(&c.fields);
                            let tys = field_types(&c.fields);
                            call_value(each_job(crate::check::errors::range0(&n), {
                                let cp = cp.clone();
                                let tys = tys.clone();
                                Rc::new(move |p0: Nat| {
                                    let cp = cp.clone();
                                    let tys = tys.clone();
                                    entered(once_job(move || {
                                        let i = p0;
                                        call_then(crate::emit::cpp::start_cpp_type(cp.clone(), or(&index(&tys, &i), &crate::lower::model::OutTy::OutUnit)), move |cpp_type_17872: Text| prism_rtl::Turn::Finished(Text::from(format!("TRY(prism_rtl::from_pod<{}>(c->args[{}]))", &cpp_type_17872, &i))))
                                    }))
                                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
                            }), move |each_17824: Array<Text>| {
                                let args = crate::syntax::lexer::chars::join(&each_17824, &Text::lit(", "));
                                let made = match &t.shape {
                                    crate::lower::model::TyShape::ShapeChoice => Text::from(format!("{}({}{{{}}})", &head, &c.name, &args)),
                                    _ => Text::from(format!("{}{{{}}}", &head, &args)),
                                };
                                prism_rtl::Turn::Finished(Text::from(format!("if (c->ctor == \"{}\" && c->args.size() == {}) return {};", &c.prism, &n, &made)))
                            })
                        }
                    }))
                }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            Text::from(format!("const Pod& p = whole.structure();\nif (auto c = p.if_choice()) {{\n{}\n}}\nreturn mismatch<{}>(\"a {}\", p);", &indent_cpp(&crate::syntax::lexer::chars::join(&arms, &Text::lit("\n"))), head, &t.prism))
        },
    };
    crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}Result<{}> {}::from_pod(const Pod& whole)", gens, head, head)), &body)
}

/// The step machine of `FromPodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FromPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub struct FromPodDef {
    pub cp: crate::emit::cpp::Cp,
    pub t: crate::lower::model::TyDef,
    pub head: Text,
    pub gens: Text,
}

impl prism_rtl::Job<Text> for FromPodDef {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp = &self.cp;
        let t = &self.t;
        let head = &self.head;
        let gens = &self.gens;
        let body = match &t.shape {
            crate::lower::model::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                let reads = crate::syntax::lexer::chars::join(&run_to_end(each_job(c.fields.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let (f, ft) = p0;
                            call_then(crate::emit::cpp::start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_17526: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = TRY(prism_rtl::from_pod<{}>(TRY(crate::prelude::field(whole, \"{}\"))))", &crate::emit::cpp::field_id(&f), &cpp_type_17526, &prism_field(&f)))))
                        }))
                    }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
                })), &Text::lit(", "));
                Text::from(format!("return {}{{{}}};", head, &reads))
            },
            _ => {
                let arms = run_to_end(each_job(t.cases.clone(), {
                    let cp = cp.clone();
                    let t = t.clone();
                    let head = head.clone();
                    Rc::new(move |p0: crate::lower::model::CaseDef| {
                        let cp = cp.clone();
                        let t = t.clone();
                        let head = head.clone();
                        entered(once_job(move || {
                            let c = p0;
                            {
                                let n = len(&c.fields);
                                let tys = field_types(&c.fields);
                                call_value(each_job(crate::check::errors::range0(&n), {
                                    let cp = cp.clone();
                                    let tys = tys.clone();
                                    Rc::new(move |p0: Nat| {
                                        let cp = cp.clone();
                                        let tys = tys.clone();
                                        entered(once_job(move || {
                                            let i = p0;
                                            call_then(crate::emit::cpp::start_cpp_type(cp.clone(), or(&index(&tys, &i), &crate::lower::model::OutTy::OutUnit)), move |cpp_type_17872: Text| prism_rtl::Turn::Finished(Text::from(format!("TRY(prism_rtl::from_pod<{}>(c->args[{}]))", &cpp_type_17872, &i))))
                                        }))
                                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
                                }), move |each_17824: Array<Text>| {
                                    let args = crate::syntax::lexer::chars::join(&each_17824, &Text::lit(", "));
                                    let made = match &t.shape {
                                        crate::lower::model::TyShape::ShapeChoice => Text::from(format!("{}({}{{{}}})", &head, &c.name, &args)),
                                        _ => Text::from(format!("{}{{{}}}", &head, &args)),
                                    };
                                    prism_rtl::Turn::Finished(Text::from(format!("if (c->ctor == \"{}\" && c->args.size() == {}) return {};", &c.prism, &n, &made)))
                                })
                            }
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
                }));
                Text::from(format!("const Pod& p = whole.structure();\nif (auto c = p.if_choice()) {{\n{}\n}}\nreturn mismatch<{}>(\"a {}\", p);", &indent_cpp(&crate::syntax::lexer::chars::join(&arms, &Text::lit("\n"))), head, &t.prism))
            },
        };
        prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}Result<{}> {}::from_pod(const Pod& whole)", gens, head, head)), &body))
    }
}

/// `Start FromPodDef, x`: what the function value is when passed to `@Run`.
pub fn start_from_pod_def(cp: crate::emit::cpp::Cp, t: crate::lower::model::TyDef, head: Text, gens: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FromPodDef { cp, t, head, gens })
}

/// ```prism
/// PrismField: fn Text -> Text
/// ```
pub fn prism_field(f: &Text) -> Text {
    if &crate::syntax::lexer::chars::last_char(f) == &Text::lit("_") {
        crate::syntax::lexer::chars::before_last(f)
    } else {
        f.clone()
    }
}

/// ```prism
/// IndentCpp: fn Text -> Text
/// ```
pub fn indent_cpp(t: &Text) -> Text {
    crate::syntax::lexer::chars::join(&each(&split_on(t, &Text::lit("\n")), &(|l: &Text| if l == &Text::lit("") { Text::lit("") } else { Text::from(format!("    {}", l)) })), &Text::lit("\n"))
}

/// ```prism
/// TagParts: unbounded fn Cp, TagDef -> Parts
/// ```
pub fn tag_parts(cp: &crate::emit::cpp::Cp, t: &crate::lower::model::TagDef) -> Parts {
    let fields = crate::syntax::lexer::chars::join(&run_to_end(each_job(t.fields.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (_, f, ft) = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_18900: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_18900, &crate::emit::cpp::field_id(&f)))))
            }))
        }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let pods = crate::syntax::lexer::chars::join(&each(&t.fields, &(|(p_, f, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", prism_rtl::to_pod({})}}", p_, &crate::emit::cpp::field_id(f))))), &Text::lit(", "));
    let reads = crate::syntax::lexer::chars::join(&run_to_end(each_job(t.fields.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (p_, f, ft) = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_19140: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = TRY(prism_rtl::from_pod<{}>(TRY(crate::prelude::field(p, \"{}\"))))", &crate::emit::cpp::field_id(&f), &cpp_type_19140, &p_))))
            }))
        }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "));
    let eq = if t.eq {
        Text::from(format!("bool operator==(const {}&) const = default;", &t.name))
    } else {
        Text::lit("")
    };
    let back_ = if t.pod {
        Text::from(format!("static Result<{}> from_pod(const Pod& p);", &t.name))
    } else {
        Text::lit("")
    };
    let deep = run_to_end(fold_job(t.fields.clone(), false, Rc::new(move |(p0, p1): (bool, (Text, Text, crate::lower::model::OutTy))| entered(once_job(move || {
        let d = p0;
        let (_, _, ft) = p1;
        prism_rtl::Turn::Finished(d || crate::lower::types::holds_dyn(&ft))
    }))) as Rc<dyn Fn((bool, (Text, Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>));
    let level_decl = if deep {
        Text::lit("/// The level as a World reads it: each dynamic it holds sampled at the read point.\nPod level_pod(const Cx& cx) const;\n/// The update events of the dynamics it holds, and of theirs.\nvoid level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const;")
    } else {
        Text::lit("")
    };
    let decl = crate::emit::cpp::templates::items::cpp_tag_struct(&cpp_source_doc(&Text::from(format!("The `Level` of `{}`:", &t.tag_name)), &t.doc), &t.name, &fields, &t.tag_name, &crate::syntax::lexer::chars::join(&filter(&Array::from(vec![eq.clone(), back_.clone(), level_decl.clone()]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n")));
    let deep_pods = crate::syntax::lexer::chars::join(&run_to_end(each_job(t.fields.clone(), Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (p_, f, ft) = p0;
        prism_rtl::Turn::More(Rc::new(CppDeepField { p_: p_.clone(), f: f.clone(), ft: ft.clone() }))
    }))) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "));
    let deep_ports = crate::syntax::lexer::chars::join(&filter(&run_to_end(each_job(t.fields.clone(), Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (_, f, ft) = p0;
        prism_rtl::Turn::More(Rc::new(CppDeepPorts { f: f.clone(), ft: ft.clone() }))
    }))) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n"));
    let level_defs = if deep {
        Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Pod {}::level_pod(const Cx& cx) const", &t.name)), &Text::from(format!("static_cast<void>(cx);\nreturn Pod::element(TAG, {{{}}});", &deep_pods))), crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("void {}::level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const", &t.name)), &Text::from(format!("static_cast<void>(cx);\nstatic_cast<void>(out);{}", &(if &deep_ports == &Text::lit("") {
            Text::lit("")
        } else {
            Text::from(format!("\n{}", &deep_ports))
        }))))])
    } else {
        Array::new()
    };
    let to_pod_ = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Pod {}::to_pod() const", &t.name)), &Text::from(format!("return Pod::element(TAG, {{{}}});", &pods)));
    let show_ = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("void {}::show(Printer& p) const", &t.name)), &Text::lit("prism_rtl::to_pod(*this).structure();\nShow<Pod>::show(prism_rtl::to_pod(*this), p);"));
    let from_pod_ = if t.pod {
        Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Result<{}> {}::from_pod(const Pod& p)", &t.name, &t.name)), &Text::from(format!("if (auto t = p.tag(); t && *t == TAG) return {}{{{}}};\nreturn mismatch<{}>(\"a {}\", p);", &t.name, &reads, &t.name, &t.tag_name)))])
    } else {
        Array::new()
    };
    let deps = crate::emit::cpp::patterns::concat2(&run_to_end(each_job(t.fields.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (_, _, ft) = p0;
                prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: ft.clone() }))
            }))
        }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    })));
    Parts { forward: Array::from(vec![Text::from(format!("struct {};", &t.name))]), values: Array::from(vec![ValueDecl { path_: decl_path(cp, &t.name), deps: deps.clone(), text: decl.clone() }]), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: append(&append(&Array::from(vec![to_pod_.clone(), show_.clone()]), &from_pod_), &level_defs) }
}

/// The step machine of `TagParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagParts: unbounded fn Cp, TagDef -> Parts
/// ```
pub struct TagParts {
    pub cp: crate::emit::cpp::Cp,
    pub t: crate::lower::model::TagDef,
}

impl prism_rtl::Job<Parts> for TagParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let t = &self.t;
        let cp = cp.clone();
        let t = t.clone();
        call_value(each_job(t.fields.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let (_, f, ft) = p0;
                    call_then(crate::emit::cpp::start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_18900: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_18900, &crate::emit::cpp::field_id(&f)))))
                }))
            }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_18862: Array<Text>| {
            let fields = crate::syntax::lexer::chars::join(&each_18862, &Text::lit("\n"));
            let pods = crate::syntax::lexer::chars::join(&each(&t.fields, &(|(p_, f, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", prism_rtl::to_pod({})}}", p_, &crate::emit::cpp::field_id(f))))), &Text::lit(", "));
            call_value(each_job(t.fields.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let (p_, f, ft) = p0;
                        call_then(crate::emit::cpp::start_cpp_type(cp.clone(), ft.clone()), move |cpp_type_19140: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = TRY(prism_rtl::from_pod<{}>(TRY(crate::prelude::field(p, \"{}\"))))", &crate::emit::cpp::field_id(&f), &cpp_type_19140, &p_))))
                    }))
                }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_19068: Array<Text>| {
                let reads = crate::syntax::lexer::chars::join(&each_19068, &Text::lit(", "));
                let eq = if t.eq {
                    Text::from(format!("bool operator==(const {}&) const = default;", &t.name))
                } else {
                    Text::lit("")
                };
                let back_ = if t.pod {
                    Text::from(format!("static Result<{}> from_pod(const Pod& p);", &t.name))
                } else {
                    Text::lit("")
                };
                call_value(fold_job(t.fields.clone(), false, Rc::new(move |(p0, p1): (bool, (Text, Text, crate::lower::model::OutTy))| entered(once_job(move || {
                    let d = p0;
                    let (_, _, ft) = p1;
                    prism_rtl::Turn::Finished(d || crate::lower::types::holds_dyn(&ft))
                }))) as Rc<dyn Fn((bool, (Text, Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>), move |fold_19459: bool| {
                    let deep = fold_19459;
                    let level_decl = if deep {
                        Text::lit("/// The level as a World reads it: each dynamic it holds sampled at the read point.\nPod level_pod(const Cx& cx) const;\n/// The update events of the dynamics it holds, and of theirs.\nvoid level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const;")
                    } else {
                        Text::lit("")
                    };
                    let decl = crate::emit::cpp::templates::items::cpp_tag_struct(&cpp_source_doc(&Text::from(format!("The `Level` of `{}`:", &t.tag_name)), &t.doc), &t.name, &fields, &t.tag_name, &crate::syntax::lexer::chars::join(&filter(&Array::from(vec![eq.clone(), back_.clone(), level_decl.clone()]), &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n")));
                    call_value(each_job(t.fields.clone(), Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| entered(once_job(move || {
                        let (p_, f, ft) = p0;
                        prism_rtl::Turn::More(Rc::new(CppDeepField { p_: p_.clone(), f: f.clone(), ft: ft.clone() }))
                    }))) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_20041: Array<Text>| {
                        let deep_pods = crate::syntax::lexer::chars::join(&each_20041, &Text::lit(", "));
                        call_value(each_job(t.fields.clone(), Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| entered(once_job(move || {
                            let (_, f, ft) = p0;
                            prism_rtl::Turn::More(Rc::new(CppDeepPorts { f: f.clone(), ft: ft.clone() }))
                        }))) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_20135: Array<Text>| {
                            let deep_ports = crate::syntax::lexer::chars::join(&filter(&each_20135, &(|s: &Text| s != &Text::lit(""))), &Text::lit("\n"));
                            let level_defs = if deep {
                                Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Pod {}::level_pod(const Cx& cx) const", &t.name)), &Text::from(format!("static_cast<void>(cx);\nreturn Pod::element(TAG, {{{}}});", &deep_pods))), crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("void {}::level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const", &t.name)), &Text::from(format!("static_cast<void>(cx);\nstatic_cast<void>(out);{}", &(if &deep_ports == &Text::lit("") {
                                    Text::lit("")
                                } else {
                                    Text::from(format!("\n{}", &deep_ports))
                                }))))])
                            } else {
                                Array::new()
                            };
                            let to_pod_ = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Pod {}::to_pod() const", &t.name)), &Text::from(format!("return Pod::element(TAG, {{{}}});", &pods)));
                            let show_ = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("void {}::show(Printer& p) const", &t.name)), &Text::lit("prism_rtl::to_pod(*this).structure();\nShow<Pod>::show(prism_rtl::to_pod(*this), p);"));
                            let from_pod_ = if t.pod {
                                Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Result<{}> {}::from_pod(const Pod& p)", &t.name, &t.name)), &Text::from(format!("if (auto t = p.tag(); t && *t == TAG) return {}{{{}}};\nreturn mismatch<{}>(\"a {}\", p);", &t.name, &reads, &t.name, &t.tag_name)))])
                            } else {
                                Array::new()
                            };
                            call_value(each_job(t.fields.clone(), {
                                let cp = cp.clone();
                                Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
                                    let cp = cp.clone();
                                    entered(once_job(move || {
                                        let (_, _, ft) = p0;
                                        prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: ft.clone() }))
                                    }))
                                }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                            }), move |each_21129: Array<Array<Text>>| {
                                let deps = crate::emit::cpp::patterns::concat2(&each_21129);
                                prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![Text::from(format!("struct {};", &t.name))]), values: Array::from(vec![ValueDecl { path_: decl_path(&cp, &t.name), deps: deps.clone(), text: decl.clone() }]), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: append(&append(&Array::from(vec![to_pod_.clone(), show_.clone()]), &from_pod_), &level_defs) })
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start TagParts, x`: what the function value is when passed to `@Run`.
pub fn start_tag_parts(cp: crate::emit::cpp::Cp, t: crate::lower::model::TagDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(TagParts { cp, t })
}

/// ```prism
/// CppDeepField: unbounded fn Text, Text, OutTy -> Text
/// ```
pub fn cpp_deep_field(p_: &Text, f: &Text, ft: &crate::lower::model::OutTy) -> Text {
    Text::from(format!("{{\"{}\", {}}}", p_, &cpp_deep_pod(f, ft)))
}

/// The step machine of `CppDeepField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppDeepField: unbounded fn Text, Text, OutTy -> Text
/// ```
pub struct CppDeepField {
    pub p_: Text,
    pub f: Text,
    pub ft: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for CppDeepField {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let p_ = &self.p_;
        let f = &self.f;
        let ft = &self.ft;
        let f = f.clone();
        let ft = ft.clone();
        let p_ = p_.clone();
        call_then(start_cpp_deep_pod(f.clone(), ft.clone()), move |cpp_deep_pod_21684: Text| prism_rtl::Turn::Finished(Text::from(format!("{{\"{}\", {}}}", &p_, &cpp_deep_pod_21684))))
    }
}

/// `Start CppDeepField, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_deep_field(p_: Text, f: Text, ft: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppDeepField { p_, f, ft })
}

/// ```prism
/// CppDeepPod: unbounded fn Text, OutTy -> Text
/// ```
pub fn cpp_deep_pod(f: &Text, ft: &crate::lower::model::OutTy) -> Text {
    'm21773: {
        if let crate::lower::model::OutTy::OutMap(_, m21773_0_1) = ft && let crate::lower::model::OutTy::OutDyn(m21773_0_1_r_0) = &**m21773_0_1 && let crate::lower::model::OutTy::OutNamed(m21773_0_1_r_0_r_0, _) = &**m21773_0_1_r_0 && (m21773_0_1_r_0_r_0 == &Text::lit("crate::Elem")) {
            break 'm21773 Text::from(format!("prism_rtl::dynamics_pod({}, cx)", &crate::emit::cpp::field_id(f)));
        }
        if let crate::lower::model::OutTy::OutDyn(m21773_1_0) = ft && let crate::lower::model::OutTy::OutNamed(m21773_1_0_r_0, _) = &**m21773_1_0 && (m21773_1_0_r_0 == &Text::lit("crate::Elem")) {
            break 'm21773 Text::from(format!("prism_rtl::level_pod({}.sample(cx), cx)", &crate::emit::cpp::field_id(f)));
        }
        if let other = ft {
            break 'm21773 if crate::lower::types::holds_dyn(other) {
                Text::lit("[] { static_assert(false, \"prismc: a tag field holding a dynamic other than `$Elem` or a map of them is not read deep (claude/incremental-host-document.md, doubt WD)\"); return Pod(); }()")
            } else {
                Text::from(format!("prism_rtl::to_pod({})", &crate::emit::cpp::field_id(f)))
            };
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `CppDeepPod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppDeepPod: unbounded fn Text, OutTy -> Text
/// ```
pub struct CppDeepPod {
    pub f: Text,
    pub ft: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for CppDeepPod {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f = &self.f;
        let ft = &self.ft;
        'm21773: {
            if let crate::lower::model::OutTy::OutMap(_, m21773_0_1) = ft && let crate::lower::model::OutTy::OutDyn(m21773_0_1_r_0) = &**m21773_0_1 && let crate::lower::model::OutTy::OutNamed(m21773_0_1_r_0_r_0, _) = &**m21773_0_1_r_0 && (m21773_0_1_r_0_r_0 == &Text::lit("crate::Elem")) {
                break 'm21773 prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::dynamics_pod({}, cx)", &crate::emit::cpp::field_id(f))));
            }
            if let crate::lower::model::OutTy::OutDyn(m21773_1_0) = ft && let crate::lower::model::OutTy::OutNamed(m21773_1_0_r_0, _) = &**m21773_1_0 && (m21773_1_0_r_0 == &Text::lit("crate::Elem")) {
                break 'm21773 prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::level_pod({}.sample(cx), cx)", &crate::emit::cpp::field_id(f))));
            }
            if let other = ft {
                break 'm21773 {
                    let f = f.clone();
                    let other = other.clone();
                    call_then(crate::lower::types::start_holds_dyn(other.clone()), move |holds_dyn_21998: bool| if holds_dyn_21998 {
                        prism_rtl::Turn::Finished(Text::lit("[] { static_assert(false, \"prismc: a tag field holding a dynamic other than `$Elem` or a map of them is not read deep (claude/incremental-host-document.md, doubt WD)\"); return Pod(); }()"))
                    } else {
                        prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::to_pod({})", &crate::emit::cpp::field_id(&f))))
                    })
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start CppDeepPod, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_deep_pod(f: Text, ft: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppDeepPod { f, ft })
}

/// ```prism
/// CppDeepPorts: unbounded fn Text, OutTy -> Text
/// ```
pub fn cpp_deep_ports(f: &Text, ft: &crate::lower::model::OutTy) -> Text {
    'm22318: {
        if let crate::lower::model::OutTy::OutMap(_, m22318_0_1) = ft && let crate::lower::model::OutTy::OutDyn(m22318_0_1_r_0) = &**m22318_0_1 && let crate::lower::model::OutTy::OutNamed(m22318_0_1_r_0_r_0, _) = &**m22318_0_1_r_0 && (m22318_0_1_r_0_r_0 == &Text::lit("crate::Elem")) {
            break 'm22318 Text::from(format!("prism_rtl::dynamics_ports({}, cx, out);", &crate::emit::cpp::field_id(f)));
        }
        if let crate::lower::model::OutTy::OutDyn(m22318_1_0) = ft && let crate::lower::model::OutTy::OutNamed(m22318_1_0_r_0, _) = &**m22318_1_0 && (m22318_1_0_r_0 == &Text::lit("crate::Elem")) {
            break 'm22318 Text::from(format!("out.push_back({}.updates);\nprism_rtl::level_ports({}.sample(cx), cx, out);", &crate::emit::cpp::field_id(f), &crate::emit::cpp::field_id(f)));
        }
        Text::lit("")
    }
}

/// The step machine of `CppDeepPorts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppDeepPorts: unbounded fn Text, OutTy -> Text
/// ```
pub struct CppDeepPorts {
    pub f: Text,
    pub ft: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for CppDeepPorts {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f = &self.f;
        let ft = &self.ft;
        'm22318: {
            if let crate::lower::model::OutTy::OutMap(_, m22318_0_1) = ft && let crate::lower::model::OutTy::OutDyn(m22318_0_1_r_0) = &**m22318_0_1 && let crate::lower::model::OutTy::OutNamed(m22318_0_1_r_0_r_0, _) = &**m22318_0_1_r_0 && (m22318_0_1_r_0_r_0 == &Text::lit("crate::Elem")) {
                break 'm22318 prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::dynamics_ports({}, cx, out);", &crate::emit::cpp::field_id(f))));
            }
            if let crate::lower::model::OutTy::OutDyn(m22318_1_0) = ft && let crate::lower::model::OutTy::OutNamed(m22318_1_0_r_0, _) = &**m22318_1_0 && (m22318_1_0_r_0 == &Text::lit("crate::Elem")) {
                break 'm22318 prism_rtl::Turn::Finished(Text::from(format!("out.push_back({}.updates);\nprism_rtl::level_ports({}.sample(cx), cx, out);", &crate::emit::cpp::field_id(f), &crate::emit::cpp::field_id(f))));
            }
            prism_rtl::Turn::Finished(Text::lit(""))
        }
    }
}

/// `Start CppDeepPorts, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_deep_ports(f: Text, ft: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppDeepPorts { f, ft })
}

/// ```prism
/// RowParts: unbounded fn Cp, Text, RowDef -> Parts
/// ```
pub fn row_parts(cp: &crate::emit::cpp::Cp, m: &Text, r: &crate::lower::model::RowDef) -> Parts {
    let names = each(&r.cases, &(|(v_, _): &(Text, Text)| v_.clone()));
    let levels = if r.level {
        Text::lit("\nPod level_pod(const Cx& cx) const;\nvoid level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const;")
    } else {
        Text::lit("")
    };
    let pod = Text::from(format!("Pod to_pod() const;\nvoid show(Printer& p) const;{}{}", &(if r.pod {
        Text::from(format!("\nstatic Result<{}> from_pod(const Pod& p);", &r.name))
    } else {
        Text::lit("")
    }), &levels));
    let cases = crate::syntax::lexer::chars::join(&each(&r.cases, &(|(v_, st): &(Text, Text)| crate::emit::cpp::templates::items::case_decl(v_, &Text::from(format!("{} a0;{}", &row_struct(m, st), &(if r.eq {
        Text::from(format!("\nbool operator==(const {}&) const = default;", v_))
    } else {
        Text::lit("")
    })))))), &Text::lit("\n"));
    let cls = crate::emit::cpp::templates::items::choice_class(&cpp_source_doc(&Text::from(format!("`{}`, a row kind\'s values:", &r.prism)), &r.doc), &Text::lit(""), &r.name, &cases, &crate::syntax::lexer::chars::join(&names, &Text::lit(", ")), &pod);
    let eq = if r.eq {
        Text::from(format!("\ninline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &r.name, &r.name))
    } else {
        Text::lit("")
    };
    let level_defs = if r.level {
        Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Pod {}::level_pod(const Cx& cx) const", &r.name)), &Text::lit("return std::visit([&](const auto& c) { return prism_rtl::level_pod(c.a0, cx); }, cases());")), crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("void {}::level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const", &r.name)), &Text::lit("std::visit([&](const auto& c) { prism_rtl::level_ports(c.a0, cx, out); }, cases());"))])
    } else {
        Array::new()
    };
    let to_pod_ = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Pod {}::to_pod() const", &r.name)), &Text::lit("return std::visit([](const auto& c) { return prism_rtl::to_pod(c.a0); }, cases());"));
    let show_ = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("void {}::show(Printer& p) const", &r.name)), &Text::lit("Show<Pod>::show(to_pod(), p);"));
    let reads = crate::syntax::lexer::chars::join(&each(&r.cases, &(|(v_, st): &(Text, Text)| Text::from(format!("if (*t == {}::TAG) return {}({}{{TRY(prism_rtl::from_pod<{}>(p))}});", &row_struct(m, st), &r.name, v_, &row_struct(m, st))))), &Text::lit("\n"));
    let from_pod_ = if r.pod {
        Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Result<{}> {}::from_pod(const Pod& p)", &r.name, &r.name)), &Text::from(format!("if (auto t = p.tag()) {{\n{}\n}}\nreturn mismatch<{}>(\"a {}\", p);", &indent_cpp(&reads), &r.name, &r.name)))])
    } else {
        Array::new()
    };
    let deps = crate::emit::cpp::patterns::concat2(&run_to_end(each_job(r.cases.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, Text)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (_, st) = p0;
                prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: crate::lower::model::OutTy::OutNamed(st.clone(), Array::new()) }))
            }))
        }) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    })));
    Parts { forward: Array::from(vec![Text::from(format!("class {};", &r.name))]), values: Array::from(vec![ValueDecl { path_: decl_path(cp, &r.name), deps: deps.clone(), text: Text::from(format!("{}{}", &cls, &eq)) }]), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: append(&append(&Array::from(vec![to_pod_.clone(), show_.clone()]), &from_pod_), &level_defs) }
}

/// The step machine of `RowParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowParts: unbounded fn Cp, Text, RowDef -> Parts
/// ```
pub struct RowParts {
    pub cp: crate::emit::cpp::Cp,
    pub m: Text,
    pub r: crate::lower::model::RowDef,
}

impl prism_rtl::Job<Parts> for RowParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let m = &self.m;
        let r = &self.r;
        let names = each(&r.cases, &(|(v_, _): &(Text, Text)| v_.clone()));
        let levels = if r.level {
            Text::lit("\nPod level_pod(const Cx& cx) const;\nvoid level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const;")
        } else {
            Text::lit("")
        };
        let pod = Text::from(format!("Pod to_pod() const;\nvoid show(Printer& p) const;{}{}", &(if r.pod {
            Text::from(format!("\nstatic Result<{}> from_pod(const Pod& p);", &r.name))
        } else {
            Text::lit("")
        }), &levels));
        let cases = crate::syntax::lexer::chars::join(&each(&r.cases, &(|(v_, st): &(Text, Text)| crate::emit::cpp::templates::items::case_decl(v_, &Text::from(format!("{} a0;{}", &row_struct(m, st), &(if r.eq {
            Text::from(format!("\nbool operator==(const {}&) const = default;", v_))
        } else {
            Text::lit("")
        })))))), &Text::lit("\n"));
        let cls = crate::emit::cpp::templates::items::choice_class(&cpp_source_doc(&Text::from(format!("`{}`, a row kind\'s values:", &r.prism)), &r.doc), &Text::lit(""), &r.name, &cases, &crate::syntax::lexer::chars::join(&names, &Text::lit(", ")), &pod);
        let eq = if r.eq {
            Text::from(format!("\ninline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &r.name, &r.name))
        } else {
            Text::lit("")
        };
        let level_defs = if r.level {
            Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Pod {}::level_pod(const Cx& cx) const", &r.name)), &Text::lit("return std::visit([&](const auto& c) { return prism_rtl::level_pod(c.a0, cx); }, cases());")), crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("void {}::level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const", &r.name)), &Text::lit("std::visit([&](const auto& c) { prism_rtl::level_ports(c.a0, cx, out); }, cases());"))])
        } else {
            Array::new()
        };
        let to_pod_ = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Pod {}::to_pod() const", &r.name)), &Text::lit("return std::visit([](const auto& c) { return prism_rtl::to_pod(c.a0); }, cases());"));
        let show_ = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("void {}::show(Printer& p) const", &r.name)), &Text::lit("Show<Pod>::show(to_pod(), p);"));
        let reads = crate::syntax::lexer::chars::join(&each(&r.cases, &(|(v_, st): &(Text, Text)| Text::from(format!("if (*t == {}::TAG) return {}({}{{TRY(prism_rtl::from_pod<{}>(p))}});", &row_struct(m, st), &r.name, v_, &row_struct(m, st))))), &Text::lit("\n"));
        let from_pod_ = if r.pod {
            Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Result<{}> {}::from_pod(const Pod& p)", &r.name, &r.name)), &Text::from(format!("if (auto t = p.tag()) {{\n{}\n}}\nreturn mismatch<{}>(\"a {}\", p);", &indent_cpp(&reads), &r.name, &r.name)))])
        } else {
            Array::new()
        };
        let cp = cp.clone();
        let r = r.clone();
        call_value(each_job(r.cases.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: (Text, Text)| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let (_, st) = p0;
                    prism_rtl::Turn::More(Rc::new(ValueDeps { cp: cp.clone(), t: crate::lower::model::OutTy::OutNamed(st.clone(), Array::new()) }))
                }))
            }) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }), move |each_24756: Array<Array<Text>>| {
            let deps = crate::emit::cpp::patterns::concat2(&each_24756);
            prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![Text::from(format!("class {};", &r.name))]), values: Array::from(vec![ValueDecl { path_: decl_path(&cp, &r.name), deps: deps.clone(), text: Text::from(format!("{}{}", &cls, &eq)) }]), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: append(&append(&Array::from(vec![to_pod_.clone(), show_.clone()]), &from_pod_), &level_defs) })
        })
    }
}

/// `Start RowParts, x`: what the function value is when passed to `@Run`.
pub fn start_row_parts(cp: crate::emit::cpp::Cp, m: Text, r: crate::lower::model::RowDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(RowParts { cp, m, r })
}

/// ```prism
/// RowStruct: fn Text, Text -> Text
/// ```
pub fn row_struct(m: &Text, st: &Text) -> Text {
    if crate::syntax::lexer::chars::contains(st, &Text::lit(":")) || (m == &Text::lit("")) {
        crate::emit::cpp::type_path(st)
    } else {
        Text::from(format!("crate::{}::{}", m, st))
    }
}

/// ```prism
/// AnswerParts: unbounded fn Cp, AnswerDef -> Parts
/// ```
pub fn answer_parts(cp: &crate::emit::cpp::Cp, a: &crate::lower::model::AnswerDef) -> Parts {
    let names = each(&a.cases, &(|c: &crate::lower::model::AnswerCase| c.variant.clone()));
    let accessors = crate::syntax::lexer::chars::join(&run_to_end(each_job(a.cases.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::AnswerCase| {
            let cp = cp.clone();
            entered(once_job(move || {
                let c = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_25615: Text| prism_rtl::Turn::Finished(Text::from(format!("Result<{}> {}() const;", &cpp_type_25615, &c.accessor))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let members_ = Text::from(format!("const char* tag() const;\n{}\nstatic Result<Answer> decode(const Elem& e, const Pod& v);", &accessors));
    let cases = crate::syntax::lexer::chars::join(&run_to_end(each_job(a.cases.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::AnswerCase| {
            let cp = cp.clone();
            entered(once_job(move || {
                let c = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_25845: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::case_decl(&c.variant, &Text::from(format!("{} a0;", &cpp_type_25845)))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let cls = crate::emit::cpp::templates::items::choice_class(&cpp_doc(&Text::lit("`Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host\'s\nsupplier answers a child place with, and what a World\'s answer to a forwarded element\ndecodes to, carrying the tag\'s output.")), &Text::lit(""), &Text::lit("Answer"), &cases, &crate::syntax::lexer::chars::join(&names, &Text::lit(", ")), &members_);
    let tags = crate::syntax::lexer::chars::join(&each(&a.cases, &(|c: &crate::lower::model::AnswerCase| Text::from(format!("if (std::holds_alternative<{}>(cases())) return {}::TAG;", &c.variant, &crate::emit::cpp::type_path(&c.struct_path))))), &Text::lit("\n"));
    let tag_fn = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::lit("const char* Answer::tag() const"), &Text::from(format!("{}\nprism_rtl::unreachable();", &tags)));
    let getters = run_to_end(each_job(a.cases.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::AnswerCase| {
            let cp = cp.clone();
            entered(once_job(move || {
                let c = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_26511: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&cpp_doc(&Text::from(format!("A `{}`\'s answer.", &c.tag_name))), &Text::from(format!("Result<{}> Answer::{}() const", &cpp_type_26511, &c.accessor)), &Text::from(format!("if (auto c = std::get_if<{}>(&cases())) return c->a0;\nreturn unexpected(Fault::answer(str(\"an answer for \", tag(), \", where {}\'s was expected\")));", &c.variant, &c.tag_name)))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let decodes = crate::syntax::lexer::chars::join(&run_to_end(each_job(a.cases.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::AnswerCase| {
            let cp = cp.clone();
            entered(once_job(move || {
                let c = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_26859: Text| prism_rtl::Turn::Finished(Text::from(format!("if (is<Elem::{}>(e)) return Answer({}{{TRY(prism_rtl::from_pod<{}>(v))}});", &c.variant, &c.variant, &cpp_type_26859))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let decode = crate::emit::cpp::templates::items::cpp_function(&cpp_doc(&Text::lit("A World\'s answer to the element `e`, decoded by its tag.")), &Text::lit("Result<Answer> Answer::decode(const Elem& e, const Pod& v)"), &Text::from(format!("{}\nprism_rtl::unreachable();", &decodes)));
    Parts { forward: Array::from(vec![Text::lit("class Answer;")]), values: Array::from(vec![ValueDecl { path_: Text::lit("Answer"), deps: Array::new(), text: cls.clone() }]), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: append(&Array::from(vec![tag_fn.clone()]), &push(&getters, &decode)) }
}

/// The step machine of `AnswerParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnswerParts: unbounded fn Cp, AnswerDef -> Parts
/// ```
pub struct AnswerParts {
    pub cp: crate::emit::cpp::Cp,
    pub a: crate::lower::model::AnswerDef,
}

impl prism_rtl::Job<Parts> for AnswerParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let a = &self.a;
        let names = each(&a.cases, &(|c: &crate::lower::model::AnswerCase| c.variant.clone()));
        let a = a.clone();
        let cp = cp.clone();
        call_value(each_job(a.cases.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: crate::lower::model::AnswerCase| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let c = p0;
                    call_then(crate::emit::cpp::start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_25615: Text| prism_rtl::Turn::Finished(Text::from(format!("Result<{}> {}() const;", &cpp_type_25615, &c.accessor))))
                }))
            }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_25587: Array<Text>| {
            let accessors = crate::syntax::lexer::chars::join(&each_25587, &Text::lit("\n"));
            let members_ = Text::from(format!("const char* tag() const;\n{}\nstatic Result<Answer> decode(const Elem& e, const Pod& v);", &accessors));
            call_value(each_job(a.cases.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: crate::lower::model::AnswerCase| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let c = p0;
                        call_then(crate::emit::cpp::start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_25845: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::case_decl(&c.variant, &Text::from(format!("{} a0;", &cpp_type_25845)))))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_25804: Array<Text>| {
                let cases = crate::syntax::lexer::chars::join(&each_25804, &Text::lit("\n"));
                let cls = crate::emit::cpp::templates::items::choice_class(&cpp_doc(&Text::lit("`Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host\'s\nsupplier answers a child place with, and what a World\'s answer to a forwarded element\ndecodes to, carrying the tag\'s output.")), &Text::lit(""), &Text::lit("Answer"), &cases, &crate::syntax::lexer::chars::join(&names, &Text::lit(", ")), &members_);
                let tags = crate::syntax::lexer::chars::join(&each(&a.cases, &(|c: &crate::lower::model::AnswerCase| Text::from(format!("if (std::holds_alternative<{}>(cases())) return {}::TAG;", &c.variant, &crate::emit::cpp::type_path(&c.struct_path))))), &Text::lit("\n"));
                let tag_fn = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::lit("const char* Answer::tag() const"), &Text::from(format!("{}\nprism_rtl::unreachable();", &tags)));
                call_value(each_job(a.cases.clone(), {
                    let cp = cp.clone();
                    Rc::new(move |p0: crate::lower::model::AnswerCase| {
                        let cp = cp.clone();
                        entered(once_job(move || {
                            let c = p0;
                            call_then(crate::emit::cpp::start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_26511: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&cpp_doc(&Text::from(format!("A `{}`\'s answer.", &c.tag_name))), &Text::from(format!("Result<{}> Answer::{}() const", &cpp_type_26511, &c.accessor)), &Text::from(format!("if (auto c = std::get_if<{}>(&cases())) return c->a0;\nreturn unexpected(Fault::answer(str(\"an answer for \", tag(), \", where {}\'s was expected\")));", &c.variant, &c.tag_name)))))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_26433: Array<Text>| {
                    let getters = each_26433;
                    call_value(each_job(a.cases.clone(), {
                        let cp = cp.clone();
                        Rc::new(move |p0: crate::lower::model::AnswerCase| {
                            let cp = cp.clone();
                            entered(once_job(move || {
                                let c = p0;
                                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), c.ty.clone()), move |cpp_type_26859: Text| prism_rtl::Turn::Finished(Text::from(format!("if (is<Elem::{}>(e)) return Answer({}{{TRY(prism_rtl::from_pod<{}>(v))}});", &c.variant, &c.variant, &cpp_type_26859))))
                            }))
                        }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
                    }), move |each_26757: Array<Text>| {
                        let decodes = crate::syntax::lexer::chars::join(&each_26757, &Text::lit("\n"));
                        let decode = crate::emit::cpp::templates::items::cpp_function(&cpp_doc(&Text::lit("A World\'s answer to the element `e`, decoded by its tag.")), &Text::lit("Result<Answer> Answer::decode(const Elem& e, const Pod& v)"), &Text::from(format!("{}\nprism_rtl::unreachable();", &decodes)));
                        prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![Text::lit("class Answer;")]), values: Array::from(vec![ValueDecl { path_: Text::lit("Answer"), deps: Array::new(), text: cls.clone() }]), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: append(&Array::from(vec![tag_fn.clone()]), &push(&getters, &decode)) })
                    })
                })
            })
        })
    }
}

/// `Start AnswerParts, x`: what the function value is when passed to `@Run`.
pub fn start_answer_parts(cp: crate::emit::cpp::Cp, a: crate::lower::model::AnswerDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(AnswerParts { cp, a })
}

/// ```prism
/// JobParts: unbounded fn Cp, JobDef -> Parts
/// ```
pub fn job_parts(cp: &crate::emit::cpp::Cp, j: &crate::lower::model::JobDef) -> Parts {
    let gens = cpp_template_head(&generic_names_of(&j.generics));
    let head = head_of(&j.name, &generic_names_of(&j.generics));
    let jcp = crate::emit::cpp::with_fields(cp, &j.fields);
    let fields = crate::syntax::lexer::chars::join(&run_to_end(each_job(j.fields.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (n, t) = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), t.clone()), move |cpp_type_27625: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_27625, &crate::emit::cpp::field_id(&n)))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let params = crate::syntax::lexer::chars::join(&run_to_end(each_job(j.fields.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
            let cp = cp.clone();
            entered(once_job(move || {
                let (n, t) = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), t.clone()), move |cpp_type_27713: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_27713, &crate::emit::cpp::field_id(&n)))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "));
    let inits = crate::syntax::lexer::chars::join(&each(&j.fields, &(|(n, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{}(std::move({}))", &crate::emit::cpp::field_id(n), &crate::emit::cpp::field_id(n))))), &Text::lit(", "));
    let ctor = if &len(&j.fields) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!("{}({}) : {} {{}}", &j.name, &params, &inits))
    };
    let ret = crate::emit::cpp::cpp_type(cp, &j.ret);
    let decl = crate::emit::cpp::templates::items::job_struct(&cpp_doc(&j.doc), &gens, &j.name, &ret, &fields, &ctor);
    let cycle = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}prism_rtl::Turn<{}> {}::cycle() const", &gens, &ret, &head)), &crate::emit::cpp::stmts::cpp_body(&jcp, &j.body));
    let start = crate::emit::cpp::templates::items::cpp_function(&cpp_doc(&Text::from(format!("`Start {}, x`: what the function value is when passed to `@Run`.", &j.name))), &Text::from(format!("{}prism_rtl::JobRef<{}> {}({})", &gens, &ret, &j.start, &params)), &Text::from(format!("return prism_rtl::make_rc<{}>({});", &head, &crate::syntax::lexer::chars::join(&each(&j.fields, &(|(n, _): &(Text, crate::lower::model::OutTy)| crate::emit::cpp::field_id(n))), &Text::lit(", ")))));
    let generic = &len(&j.generics) > &Nat::from(0u32);
    Parts { forward: Array::from(vec![Text::from(format!("{}struct {};", &gens, &j.name))]), values: Array::new(), protos: Array::from(vec![Text::from(format!("{}prism_rtl::JobRef<{}> {}({});", &gens, &ret, &j.start, &params))]), classes: Array::from(vec![decl.clone()]), outer: Array::new(), generic: if generic { Array::from(vec![cycle.clone(), start.clone()]) } else { Array::new() }, defs: if generic { Array::new() } else { Array::from(vec![cycle.clone(), start.clone()]) } }
}

/// The step machine of `JobParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobParts: unbounded fn Cp, JobDef -> Parts
/// ```
pub struct JobParts {
    pub cp: crate::emit::cpp::Cp,
    pub j: crate::lower::model::JobDef,
}

impl prism_rtl::Job<Parts> for JobParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let j = &self.j;
        let gens = cpp_template_head(&generic_names_of(&j.generics));
        let head = head_of(&j.name, &generic_names_of(&j.generics));
        let jcp = crate::emit::cpp::with_fields(cp, &j.fields);
        let cp = cp.clone();
        let j = j.clone();
        call_value(each_job(j.fields.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let (n, t) = p0;
                    call_then(crate::emit::cpp::start_cpp_type(cp.clone(), t.clone()), move |cpp_type_27625: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_27625, &crate::emit::cpp::field_id(&n)))))
                }))
            }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_27596: Array<Text>| {
            let fields = crate::syntax::lexer::chars::join(&each_27596, &Text::lit("\n"));
            call_value(each_job(j.fields.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let (n, t) = p0;
                        call_then(crate::emit::cpp::start_cpp_type(cp.clone(), t.clone()), move |cpp_type_27713: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_27713, &crate::emit::cpp::field_id(&n)))))
                    }))
                }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_27684: Array<Text>| {
                let params = crate::syntax::lexer::chars::join(&each_27684, &Text::lit(", "));
                let inits = crate::syntax::lexer::chars::join(&each(&j.fields, &(|(n, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{}(std::move({}))", &crate::emit::cpp::field_id(n), &crate::emit::cpp::field_id(n))))), &Text::lit(", "));
                let ctor = if &len(&j.fields) == &Nat::from(0u32) {
                    Text::lit("")
                } else {
                    Text::from(format!("{}({}) : {} {{}}", &j.name, &params, &inits))
                };
                call_then(crate::emit::cpp::start_cpp_type(cp.clone(), j.ret.clone()), move |cpp_type_27945: Text| {
                    let ret = cpp_type_27945;
                    let decl = crate::emit::cpp::templates::items::job_struct(&cpp_doc(&j.doc), &gens, &j.name, &ret, &fields, &ctor);
                    call_then(crate::emit::cpp::stmts::start_cpp_body(jcp.clone(), j.body.clone()), move |cpp_body_28123: Text| {
                        let cycle = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}prism_rtl::Turn<{}> {}::cycle() const", &gens, &ret, &head)), &cpp_body_28123);
                        let start = crate::emit::cpp::templates::items::cpp_function(&cpp_doc(&Text::from(format!("`Start {}, x`: what the function value is when passed to `@Run`.", &j.name))), &Text::from(format!("{}prism_rtl::JobRef<{}> {}({})", &gens, &ret, &j.start, &params)), &Text::from(format!("return prism_rtl::make_rc<{}>({});", &head, &crate::syntax::lexer::chars::join(&each(&j.fields, &(|(n, _): &(Text, crate::lower::model::OutTy)| crate::emit::cpp::field_id(n))), &Text::lit(", ")))));
                        let generic = &len(&j.generics) > &Nat::from(0u32);
                        prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![Text::from(format!("{}struct {};", &gens, &j.name))]), values: Array::new(), protos: Array::from(vec![Text::from(format!("{}prism_rtl::JobRef<{}> {}({});", &gens, &ret, &j.start, &params))]), classes: Array::from(vec![decl.clone()]), outer: Array::new(), generic: if generic { Array::from(vec![cycle.clone(), start.clone()]) } else { Array::new() }, defs: if generic { Array::new() } else { Array::from(vec![cycle.clone(), start.clone()]) } })
                    })
                })
            })
        })
    }
}

/// `Start JobParts, x`: what the function value is when passed to `@Run`.
pub fn start_job_parts(cp: crate::emit::cpp::Cp, j: crate::lower::model::JobDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(JobParts { cp, j })
}

/// ```prism
/// TraitParts: unbounded fn Cp, TraitDef -> Parts
/// ```
pub fn trait_parts(cp: &crate::emit::cpp::Cp, t: &crate::lower::model::TraitDef) -> Parts {
    let defaults = filter(&t.methods, &(|f: &crate::lower::model::FnDef| f.public));
    let defs = run_to_end(each_job(defaults.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::FnDef| {
            let cp = cp.clone();
            entered(once_job(move || {
                let f = p0;
                prism_rtl::Turn::More(Rc::new(FnDefinition { cp: cp.clone(), f: with_generics(&f, &Array::from(vec![(Text::lit("Self"), Array::new())])) }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let protos = run_to_end(each_job(t.methods.clone(), {
        let cp = cp.clone();
        Rc::new(move |p0: crate::lower::model::FnDef| {
            let cp = cp.clone();
            entered(once_job(move || {
                let f = p0;
                call_then(start_fn_signature(cp.clone(), with_generics(&f, &Array::from(vec![(Text::lit("Self"), Array::new())]))), move |fn_signature_29363: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{};", &fn_signature_29363, &(if f.public { Text::lit("") } else { Text::lit(" = delete") })))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let generic = if &len(&defaults) == &Nat::from(0u32) {
        Array::new()
    } else {
        Array::from(vec![crate::emit::cpp::templates::items::trait_namespace(&t.name, &crate::syntax::lexer::chars::join(&defs, &Text::lit("\n")))])
    };
    let mut this: Parts = generic_only(&generic);
    this.protos = Array::from(vec![crate::emit::cpp::templates::items::trait_namespace(&t.name, &crate::syntax::lexer::chars::join(&protos, &Text::lit("\n")))]);
    this
}

/// The step machine of `TraitParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TraitParts: unbounded fn Cp, TraitDef -> Parts
/// ```
pub struct TraitParts {
    pub cp: crate::emit::cpp::Cp,
    pub t: crate::lower::model::TraitDef,
}

impl prism_rtl::Job<Parts> for TraitParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let t = &self.t;
        let defaults = filter(&t.methods, &(|f: &crate::lower::model::FnDef| f.public));
        let cp = cp.clone();
        let t = t.clone();
        call_value(each_job(defaults.clone(), {
            let cp = cp.clone();
            Rc::new(move |p0: crate::lower::model::FnDef| {
                let cp = cp.clone();
                entered(once_job(move || {
                    let f = p0;
                    prism_rtl::Turn::More(Rc::new(FnDefinition { cp: cp.clone(), f: with_generics(&f, &Array::from(vec![(Text::lit("Self"), Array::new())])) }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_29247: Array<Text>| {
            let defs = each_29247;
            call_value(each_job(t.methods.clone(), {
                let cp = cp.clone();
                Rc::new(move |p0: crate::lower::model::FnDef| {
                    let cp = cp.clone();
                    entered(once_job(move || {
                        let f = p0;
                        call_then(start_fn_signature(cp.clone(), with_generics(&f, &Array::from(vec![(Text::lit("Self"), Array::new())]))), move |fn_signature_29363: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{};", &fn_signature_29363, &(if f.public { Text::lit("") } else { Text::lit(" = delete") })))))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_29340: Array<Text>| {
                let protos = each_29340;
                let generic = if &len(&defaults) == &Nat::from(0u32) {
                    Array::new()
                } else {
                    Array::from(vec![crate::emit::cpp::templates::items::trait_namespace(&t.name, &crate::syntax::lexer::chars::join(&defs, &Text::lit("\n")))])
                };
                prism_rtl::Turn::Finished({
                    let mut this: Parts = generic_only(&generic);
                    this.protos = Array::from(vec![crate::emit::cpp::templates::items::trait_namespace(&t.name, &crate::syntax::lexer::chars::join(&protos, &Text::lit("\n")))]);
                    this
                })
            })
        })
    }
}

/// `Start TraitParts, x`: what the function value is when passed to `@Run`.
pub fn start_trait_parts(cp: crate::emit::cpp::Cp, t: crate::lower::model::TraitDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(TraitParts { cp, t })
}

/// ```prism
/// ImplParts: unbounded fn Cp, ImplDef -> Parts
/// ```
pub fn impl_parts(cp: &crate::emit::cpp::Cp, i: &crate::lower::model::ImplDef) -> Parts {
    let head = crate::emit::cpp::cpp_type(cp, &i.head);
    let gens = cpp_template_head(&generic_names_of(&i.generics));
    let fns = run_to_end(each_job(i.methods.clone(), {
        let cp = cp.clone();
        let i = i.clone();
        Rc::new(move |p0: crate::lower::model::FnDef| {
            let cp = cp.clone();
            let i = i.clone();
            entered(once_job(move || {
                let f = p0;
                prism_rtl::Turn::More(Rc::new(FnParts { cp: cp.clone(), f: with_generics(&f, &i.generics) }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Parts>>>
    }));
    let own = fold(&fns, &no_parts(), &(|acc: &Parts, p_: &Parts| join_parts(acc, p_)));
    match &i.cls {
        m30350_0 if (m30350_0 == &Text::lit("Prelude.Show")) => {
            let shown = or(&index(&each(&i.methods, &(|f: &crate::lower::model::FnDef| f.name.clone())), &Nat::from(0u32)), &Text::lit("show"));
            join_parts(&own, &protos_defs(&Array::new(), &Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}void {}::show(Printer& p) const", &gens, &head)), &Text::from(format!("p.raw({}(*this).to_string());", &shown)))])))
        },
        m30350_1 if (m30350_1 == &Text::lit("Prelude.Eq")) => {
            let eq = fold(&i.methods, &Text::lit(""), &(|acc: &Text, f: &crate::lower::model::FnDef| if !crate::syntax::lexer::chars::has_prefix(&f.name, &Text::lit("ne")) && (acc == &Text::lit("")) {
                f.name.clone()
            } else {
                acc.clone()
            }));
            join_parts(&own, &protos_defs(&Array::from(vec![Text::from(format!("{}bool operator==(const {}& a, const {}& b);", &gens, &head, &head))]), &Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}bool operator==(const {}& a, const {}& b)", &gens, &head, &head)), &Text::from(format!("return {}(a, b);", &eq)))])))
        },
        _ => {
            let tr = crate::syntax::lexer::chars::drop_prefix(&crate::emit::cpp::type_path(&i.tr), &Text::lit("crate::"));
            let own = !crate::syntax::lexer::chars::contains(&tr, &Text::lit("::"));
            let ns = if own {
                tr.clone()
            } else {
                Text::from(format!("impl_{}", &crate::syntax::lexer::chars::join(&split_on(&tr, &Text::lit("::")), &Text::lit("_"))))
            };
            let in_trait = run_to_end(each_job(i.methods.clone(), {
                let ns = ns.clone();
                let cp = cp.clone();
                let i = i.clone();
                Rc::new(move |p0: crate::lower::model::FnDef| {
                    let ns = ns.clone();
                    let cp = cp.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let f = p0;
                        call_then(start_fn_definition(cp.clone(), with_generics(&f, &i.generics)), move |fn_definition_31217: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::trait_namespace(&ns, &fn_definition_31217)))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            let protos = run_to_end(each_job(i.methods.clone(), {
                let ns = ns.clone();
                let cp = cp.clone();
                let i = i.clone();
                Rc::new(move |p0: crate::lower::model::FnDef| {
                    let ns = ns.clone();
                    let cp = cp.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let f = p0;
                        call_then(start_fn_signature(cp.clone(), with_generics(&f, &i.generics)), move |fn_signature_31331: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::trait_namespace(&ns, &Text::from(format!("{};", &fn_signature_31331)))))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            let outer = if own {
                Array::new()
            } else {
                Array::from(vec![crate::emit::cpp::templates::items::trait_namespace(&tr, &crate::syntax::lexer::chars::join(&each(&i.methods, &(|f: &crate::lower::model::FnDef| Text::from(format!("using ::crate::{}::{}::{};", &cp.home, &ns, &crate::emit::cpp::cpp_id(&f.name))))), &Text::lit("\n")))])
            };
            {
                let mut this: Parts = protos_defs(&protos, &in_trait);
                this.outer = outer.clone();
                this
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ImplParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ImplParts: unbounded fn Cp, ImplDef -> Parts
/// ```
pub struct ImplParts {
    pub cp: crate::emit::cpp::Cp,
    pub i: crate::lower::model::ImplDef,
}

impl prism_rtl::Job<Parts> for ImplParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp = &self.cp;
        let i = &self.i;
        let cp = cp.clone();
        let i = i.clone();
        call_then(crate::emit::cpp::start_cpp_type(cp.clone(), i.head.clone()), move |cpp_type_30132: Text| {
            let head = cpp_type_30132;
            let gens = cpp_template_head(&generic_names_of(&i.generics));
            call_value(each_job(i.methods.clone(), {
                let cp = cp.clone();
                let i = i.clone();
                Rc::new(move |p0: crate::lower::model::FnDef| {
                    let cp = cp.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let f = p0;
                        prism_rtl::Turn::More(Rc::new(FnParts { cp: cp.clone(), f: with_generics(&f, &i.generics) }))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Parts>>>
            }), move |each_30224: Array<Parts>| {
                let fns = each_30224;
                let own = fold(&fns, &no_parts(), &(|acc: &Parts, p_: &Parts| join_parts(acc, p_)));
                match &i.cls {
                    m30350_0 if (m30350_0 == &Text::lit("Prelude.Show")) => {
                        let shown = or(&index(&each(&i.methods, &(|f: &crate::lower::model::FnDef| f.name.clone())), &Nat::from(0u32)), &Text::lit("show"));
                        prism_rtl::Turn::Finished(join_parts(&own, &protos_defs(&Array::new(), &Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}void {}::show(Printer& p) const", &gens, &head)), &Text::from(format!("p.raw({}(*this).to_string());", &shown)))]))))
                    },
                    m30350_1 if (m30350_1 == &Text::lit("Prelude.Eq")) => {
                        let eq = fold(&i.methods, &Text::lit(""), &(|acc: &Text, f: &crate::lower::model::FnDef| if !crate::syntax::lexer::chars::has_prefix(&f.name, &Text::lit("ne")) && (acc == &Text::lit("")) {
                            f.name.clone()
                        } else {
                            acc.clone()
                        }));
                        prism_rtl::Turn::Finished(join_parts(&own, &protos_defs(&Array::from(vec![Text::from(format!("{}bool operator==(const {}& a, const {}& b);", &gens, &head, &head))]), &Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}bool operator==(const {}& a, const {}& b)", &gens, &head, &head)), &Text::from(format!("return {}(a, b);", &eq)))]))))
                    },
                    _ => {
                        let tr = crate::syntax::lexer::chars::drop_prefix(&crate::emit::cpp::type_path(&i.tr), &Text::lit("crate::"));
                        let own = !crate::syntax::lexer::chars::contains(&tr, &Text::lit("::"));
                        let ns = if own {
                            tr.clone()
                        } else {
                            Text::from(format!("impl_{}", &crate::syntax::lexer::chars::join(&split_on(&tr, &Text::lit("::")), &Text::lit("_"))))
                        };
                        call_value(each_job(i.methods.clone(), {
                            let ns = ns.clone();
                            let cp = cp.clone();
                            let i = i.clone();
                            Rc::new(move |p0: crate::lower::model::FnDef| {
                                let ns = ns.clone();
                                let cp = cp.clone();
                                let i = i.clone();
                                entered(once_job(move || {
                                    let f = p0;
                                    call_then(start_fn_definition(cp.clone(), with_generics(&f, &i.generics)), move |fn_definition_31217: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::trait_namespace(&ns, &fn_definition_31217)))
                                }))
                            }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
                        }), move |each_31176: Array<Text>| {
                            let in_trait = each_31176;
                            call_value(each_job(i.methods.clone(), {
                                let ns = ns.clone();
                                let cp = cp.clone();
                                let i = i.clone();
                                Rc::new(move |p0: crate::lower::model::FnDef| {
                                    let ns = ns.clone();
                                    let cp = cp.clone();
                                    let i = i.clone();
                                    entered(once_job(move || {
                                        let f = p0;
                                        call_then(start_fn_signature(cp.clone(), with_generics(&f, &i.generics)), move |fn_signature_31331: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::trait_namespace(&ns, &Text::from(format!("{};", &fn_signature_31331)))))
                                    }))
                                }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
                            }), move |each_31289: Array<Text>| {
                                let protos = each_31289;
                                let outer = if own {
                                    Array::new()
                                } else {
                                    Array::from(vec![crate::emit::cpp::templates::items::trait_namespace(&tr, &crate::syntax::lexer::chars::join(&each(&i.methods, &(|f: &crate::lower::model::FnDef| Text::from(format!("using ::crate::{}::{}::{};", &cp.home, &ns, &crate::emit::cpp::cpp_id(&f.name))))), &Text::lit("\n")))])
                                };
                                prism_rtl::Turn::Finished({
                                    let mut this: Parts = protos_defs(&protos, &in_trait);
                                    this.outer = outer.clone();
                                    this
                                })
                            })
                        })
                    },
                    _ => unreachable!("no arm matched"),
                }
            })
        })
    }
}

/// `Start ImplParts, x`: what the function value is when passed to `@Run`.
pub fn start_impl_parts(cp: crate::emit::cpp::Cp, i: crate::lower::model::ImplDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(ImplParts { cp, i })
}

/// ```prism
/// WithGenerics: fn FnDef, [((Text, [Text]))] -> FnDef
/// ```
pub fn with_generics(f: &crate::lower::model::FnDef, gs: &Array<(Text, Array<Text>)>) -> crate::lower::model::FnDef {
    let mut this: crate::lower::model::FnDef = f.clone();
    this.generics = append(gs, &this.generics);
    this
}

/// ```prism
/// GenericOnly: fn [Text] -> Parts
/// ```
pub fn generic_only(xs: &Array<Text>) -> Parts {
    let mut this: Parts = no_parts();
    this.generic = xs.clone();
    this
}

/// ```prism
/// ProtosDefs: fn [Text], [Text] -> Parts
/// ```
pub fn protos_defs(ps: &Array<Text>, ds: &Array<Text>) -> Parts {
    let mut this: Parts = no_parts();
    this.protos = ps.clone();
    this.defs = ds.clone();
    this
}
