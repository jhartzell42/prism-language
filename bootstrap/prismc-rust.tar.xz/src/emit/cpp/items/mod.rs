//! The module `Emit.Cpp.Items`, from `target/bootstrap/src/prismc/emit/cpp/items.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `Parts`:
///
/// ```prism
/// type Parts = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Parts {
    pub forward_p: crate::prelude::Array<crate::prelude::Text>,
    pub values_p: crate::prelude::Array<ValueDecl>,
    pub protos_p: crate::prelude::Array<crate::prelude::Text>,
    pub classes_p: crate::prelude::Array<crate::prelude::Text>,
    pub outer_p: crate::prelude::Array<crate::prelude::Text>,
    pub generic_p: crate::prelude::Array<crate::prelude::Text>,
    pub defs_p: crate::prelude::Array<crate::prelude::Text>,
}

impl crate::prelude::Show for Parts {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Parts", &[("forward", &self.forward_p), ("values", &self.values_p), ("protos", &self.protos_p), ("classes", &self.classes_p), ("outer", &self.outer_p), ("generic", &self.generic_p), ("defs", &self.defs_p)]);
    }
}

impl crate::prelude::ToPod for Parts {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Parts", vec![("forward", self.forward_p.to_pod()), ("values", self.values_p.to_pod()), ("protos", self.protos_p.to_pod()), ("classes", self.classes_p.to_pod()), ("outer", self.outer_p.to_pod()), ("generic", self.generic_p.to_pod()), ("defs", self.defs_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Parts {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Parts { forward_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "forward")?)?, values_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "values")?)?, protos_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "protos")?)?, classes_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "classes")?)?, outer_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "outer")?)?, generic_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "generic")?)?, defs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "defs")?)? })
    }
}

/// `ValueDecl`:
///
/// ```prism
/// type ValueDecl = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct ValueDecl {
    pub path_p: crate::prelude::Text,
    pub deps_p: crate::prelude::Array<crate::prelude::Text>,
    pub text_p: crate::prelude::Text,
}

impl crate::prelude::Show for ValueDecl {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("ValueDecl", &[("path", &self.path_p), ("deps", &self.deps_p), ("text", &self.text_p)]);
    }
}

impl crate::prelude::ToPod for ValueDecl {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("ValueDecl", vec![("path", self.path_p.to_pod()), ("deps", self.deps_p.to_pod()), ("text", self.text_p.to_pod())])
    }
}

impl crate::prelude::FromPod for ValueDecl {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(ValueDecl { path_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "path")?)?, deps_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "deps")?)?, text_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "text")?)? })
    }
}

/// ```prism
/// CppTemplateHead: fn [Text] -> Text
/// ```
pub fn cpp_template_head_f(xs0: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Text {
    match xs0 {
        c0_0 if (c0_0.len() == 0) => crate::prelude::Text::lit(""),
        ps_p0 => crate::prelude::Text::from(format!("template <{}>\n", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(ps_p0, &(|p_p1: &crate::prelude::Text| crate::prelude::Text::from(format!("class {}", p_p1)))), &crate::prelude::Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// GenericNamesOf: fn [((Text, [Text]))] -> [Text]
/// ```
pub fn generic_names_of_f(gs_p0: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::each(gs_p0, &(|(g_p1, _): &(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)| g_p1.clone()))
}

/// ```prism
/// HeadOf: fn Text, [Text] -> Text
/// ```
pub fn head_of_f(name_p0: &crate::prelude::Text, xs1: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Text {
    match xs1 {
        c0_1 if (c0_1.len() == 0) => name_p0.clone(),
        ps_p2 => crate::prelude::Text::from(format!("{}<{}>", name_p0, &crate::syntax::lexer::chars::join_f(ps_p2, &crate::prelude::Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CppParams: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub fn cpp_params_f(cp_p0: &crate::emit::cpp::Cp, ps_p1: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>) -> crate::prelude::Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(ps_p1.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (n_p2, t_p3) = p0;
                crate::prelude::call_then(crate::emit::cpp::expr::start_param_type_f(cp_p0xy.clone(), t_p3.clone()), move |param_type_f_1510: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {}", &param_type_f_1510, &crate::emit::cpp::cpp_id_f(&n_p2)))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    })), &crate::prelude::Text::lit(", "))
}

/// The step machine of `CppParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppParams: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub struct CppParams {
    pub cp_p0: crate::emit::cpp::Cp,
    pub ps_p1: crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppParams {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let ps_p1 = &self.ps_p1;
        let cp_p0x = cp_p0.clone();
        let ps_p1x = ps_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(ps_p1x.clone(), {
            let cp_p0xx = cp_p0x.clone();
            ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (n_p2, t_p3) = p0;
                    crate::prelude::call_then(crate::emit::cpp::expr::start_param_type_f(cp_p0xxy.clone(), t_p3.clone()), move |param_type_f_1510: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {}", &param_type_f_1510, &crate::emit::cpp::cpp_id_f(&n_p2)))))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
        }), move |each_1487: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join_f(&each_1487, &crate::prelude::Text::lit(", "))))
    }
}

/// `Start CppParams, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_params_f(cp_p0: crate::emit::cpp::Cp, ps_p1: crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppParams { cp_p0, ps_p1 })
}

/// ```prism
/// FnSignature: unbounded fn Cp, FnDef -> Text
/// ```
pub fn fn_signature_f(cp_p0: &crate::emit::cpp::Cp, f_p1: &crate::lower::model::FnDef) -> crate::prelude::Text {
    crate::prelude::Text::from(format!("{}{} {}({})", &cpp_template_head_f(&generic_names_of_f(&f_p1.generics_p)), &crate::emit::cpp::cpp_type_f(cp_p0, &f_p1.ret_p), &crate::emit::cpp::cpp_id_f(&f_p1.name_p), &cpp_params_f(cp_p0, &f_p1.params_p)))
}

/// The step machine of `FnSignature`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnSignature: unbounded fn Cp, FnDef -> Text
/// ```
pub struct FnSignature {
    pub cp_p0: crate::emit::cpp::Cp,
    pub f_p1: crate::lower::model::FnDef,
}

impl ::prism_rtl::Job<crate::prelude::Text> for FnSignature {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let f_p1 = &self.f_p1;
        let cp_p0x = cp_p0.clone();
        let f_p1x = f_p1.clone();
        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), f_p1x.ret_p.clone()), move |cpp_type_f_1741: crate::prelude::Text| crate::prelude::call_then(start_cpp_params_f(cp_p0x.clone(), f_p1x.params_p.clone()), move |cpp_params_f_1776: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{} {}({})", &cpp_template_head_f(&generic_names_of_f(&f_p1x.generics_p)), &cpp_type_f_1741, &crate::emit::cpp::cpp_id_f(&f_p1x.name_p), &cpp_params_f_1776)))))
    }
}

/// `Start FnSignature, x`: what the function value is when passed to `@Run`.
pub fn start_fn_signature_f(cp_p0: crate::emit::cpp::Cp, f_p1: crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(FnSignature { cp_p0, f_p1 })
}

/// ```prism
/// FnDefinition: unbounded fn Cp, FnDef -> Text
/// ```
pub fn fn_definition_f(cp_p0: &crate::emit::cpp::Cp, f_p1: &crate::lower::model::FnDef) -> crate::prelude::Text {
    crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&f_p1.doc_p), &fn_signature_f(cp_p0, f_p1), &crate::emit::cpp::stmts::cpp_body_f(&with_params_f(cp_p0, &f_p1.params_p), &f_p1.body_p))
}

/// The step machine of `FnDefinition`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnDefinition: unbounded fn Cp, FnDef -> Text
/// ```
pub struct FnDefinition {
    pub cp_p0: crate::emit::cpp::Cp,
    pub f_p1: crate::lower::model::FnDef,
}

impl ::prism_rtl::Job<crate::prelude::Text> for FnDefinition {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let f_p1 = &self.f_p1;
        let cp_p0x = cp_p0.clone();
        let f_p1x = f_p1.clone();
        crate::prelude::call_then(start_fn_signature_f(cp_p0x.clone(), f_p1x.clone()), move |fn_signature_f_1901: crate::prelude::Text| crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_body_f(with_params_f(&cp_p0x, &f_p1x.params_p), f_p1x.body_p.clone()), move |cpp_body_f_1922: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&f_p1x.doc_p), &fn_signature_f_1901, &cpp_body_f_1922))))
    }
}

/// `Start FnDefinition, x`: what the function value is when passed to `@Run`.
pub fn start_fn_definition_f(cp_p0: crate::emit::cpp::Cp, f_p1: crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(FnDefinition { cp_p0, f_p1 })
}

/// ```prism
/// WithParams: fn Cp, [((Text, OutTy))] -> Cp
/// ```
pub fn with_params_f(cp_p0: &crate::emit::cpp::Cp, ps_p1: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>) -> crate::emit::cpp::Cp {
    crate::prelude::fold(ps_p1, cp_p0, &(|c_p2: &crate::emit::cpp::Cp, (n_p3, t_p4): &(crate::prelude::Text, crate::lower::model::OutTy)| {
        let mut this: crate::emit::cpp::Cp = c_p2.clone();
        this.pointers_p = crate::prelude::insert(&this.pointers_p, n_p3, &crate::emit::cpp::expr::is_pointer_ty_f(c_p2, &crate::emit::cpp::expr::unref_f(t_p4)));
        this.local_types_p = crate::prelude::insert(&this.local_types_p, n_p3, t_p4);
        this
    }))
}

/// ```prism
/// ValueDeps: unbounded fn Cp, OutTy -> [Text]
/// ```
pub fn value_deps_f(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::OutTy) -> crate::prelude::Array<crate::prelude::Text> {
    match t_p1 {
        crate::lower::model::OutTy::OutNamed(n_p2, args_p3) => {
            let own_p4 = match crate::emit::cpp::type_of_o(cp_p0, n_p2) {
                ::std::option::Option::Some(info_p5) => if ((((&info_p5.kind_p == &crate::prelude::Text::lit("record")) || (&info_p5.kind_p == &crate::prelude::Text::lit("newtype"))) || (&info_p5.kind_p == &crate::prelude::Text::lit("unit"))) || (&info_p5.kind_p == &crate::prelude::Text::lit("tag"))) || (&info_p5.kind_p == &crate::prelude::Text::lit("choice")) {
                    crate::prelude::Array::from(vec![dep_path_f(cp_p0, n_p2)])
                } else {
                    crate::prelude::Array::new()
                },
                ::std::option::Option::None => crate::prelude::Array::new(),
            };
            crate::prelude::append(&own_p4, &crate::emit::cpp::patterns::concat2_f(&crate::prelude::run_to_end(crate::prelude::each_job(args_p3.clone(), {
                let cp_p0x = cp_p0.clone();
                ::std::rc::Rc::new(move |p0: crate::lower::model::OutTy| {
                    let cp_p0xy = cp_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_p6 = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(ValueDeps { cp_p0: cp_p0xy.clone(), t_p1: a_p6.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
            }))))
        },
        crate::lower::model::OutTy::OutOpt(i_p7) => value_deps_f(cp_p0, &**i_p7),
        crate::lower::model::OutTy::OutRes(i_p8) => value_deps_f(cp_p0, &**i_p8),
        crate::lower::model::OutTy::OutCell(i_p9) => value_deps_f(cp_p0, &**i_p9),
        crate::lower::model::OutTy::OutTuple(ts_pa) => crate::emit::cpp::patterns::concat2_f(&crate::prelude::run_to_end(crate::prelude::each_job(ts_pa.clone(), {
            let cp_p0x = cp_p0.clone();
            ::std::rc::Rc::new(move |p0: crate::lower::model::OutTy| {
                let cp_p0xy = cp_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pb = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ValueDeps { cp_p0: cp_p0xy.clone(), t_p1: a_pb.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
        }))),
        _ => crate::prelude::Array::new(),
    }
}

/// The step machine of `ValueDeps`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ValueDeps: unbounded fn Cp, OutTy -> [Text]
/// ```
pub struct ValueDeps {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::OutTy,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for ValueDeps {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        match t_p1 {
            crate::lower::model::OutTy::OutNamed(n_p2, args_p3) => {
                let own_p4 = match crate::emit::cpp::type_of_o(cp_p0, n_p2) {
                    ::std::option::Option::Some(info_p5) => if ((((&info_p5.kind_p == &crate::prelude::Text::lit("record")) || (&info_p5.kind_p == &crate::prelude::Text::lit("newtype"))) || (&info_p5.kind_p == &crate::prelude::Text::lit("unit"))) || (&info_p5.kind_p == &crate::prelude::Text::lit("tag"))) || (&info_p5.kind_p == &crate::prelude::Text::lit("choice")) {
                        crate::prelude::Array::from(vec![dep_path_f(cp_p0, n_p2)])
                    } else {
                        crate::prelude::Array::new()
                    },
                    ::std::option::Option::None => crate::prelude::Array::new(),
                };
                let args_p3x = args_p3.clone();
                let cp_p0x = cp_p0.clone();
                crate::prelude::call_value(crate::prelude::each_job(args_p3x.clone(), {
                    let cp_p0xx = cp_p0x.clone();
                    ::std::rc::Rc::new(move |p0: crate::lower::model::OutTy| {
                        let cp_p0xxy = cp_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_p6 = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(ValueDeps { cp_p0: cp_p0xxy.clone(), t_p1: a_p6.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                }), move |each_3884: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| ::prism_rtl::Turn::Finished(crate::prelude::append(&own_p4, &crate::emit::cpp::patterns::concat2_f(&each_3884))))
            },
            crate::lower::model::OutTy::OutOpt(i_p7) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ValueDeps { cp_p0: cp_p0.clone(), t_p1: (**i_p7).clone() })),
            crate::lower::model::OutTy::OutRes(i_p8) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ValueDeps { cp_p0: cp_p0.clone(), t_p1: (**i_p8).clone() })),
            crate::lower::model::OutTy::OutCell(i_p9) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ValueDeps { cp_p0: cp_p0.clone(), t_p1: (**i_p9).clone() })),
            crate::lower::model::OutTy::OutTuple(ts_pa) => {
                let cp_p0x = cp_p0.clone();
                let ts_pax = ts_pa.clone();
                crate::prelude::call_value(crate::prelude::each_job(ts_pax.clone(), {
                    let cp_p0xx = cp_p0x.clone();
                    ::std::rc::Rc::new(move |p0: crate::lower::model::OutTy| {
                        let cp_p0xxy = cp_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_pb = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(ValueDeps { cp_p0: cp_p0xxy.clone(), t_p1: a_pb.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                }), move |each_4035: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| ::prism_rtl::Turn::Finished(crate::emit::cpp::patterns::concat2_f(&each_4035)))
            },
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start ValueDeps, x`: what the function value is when passed to `@Run`.
pub fn start_value_deps_f(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(ValueDeps { cp_p0, t_p1 })
}

/// ```prism
/// DepPath: fn Cp, Ref -> Text
/// ```
pub fn dep_path_f(cp_p0: &crate::emit::cpp::Cp, n_p1: &crate::lower::model::Ref) -> crate::prelude::Text {
    crate::prelude::or(&crate::lower::model::ref_key_o(n_p1), &crate::lower::model::ref_spelled_f(n_p1))
}

/// ```prism
/// Behind: unbounded fn Cp, OutTy -> Bool
/// ```
pub fn behind_f(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::OutTy) -> bool {
    match t_p1 {
        crate::lower::model::OutTy::OutRc(_) => true,
        crate::lower::model::OutTy::OutOpt(i_p2) => behind_f(cp_p0, &**i_p2),
        crate::lower::model::OutTy::OutRes(i_p3) => behind_f(cp_p0, &**i_p3),
        crate::lower::model::OutTy::OutCell(i_p4) => behind_f(cp_p0, &**i_p4),
        crate::lower::model::OutTy::OutTuple(ts_p5) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_p5.clone(), false, {
            let cp_p0x = cp_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                let cp_p0xy = cp_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let f_p6 = p0;
                    let x_p7 = p1;
                    if f_p6 {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(Behind { cp_p0: cp_p0xy.clone(), t_p1: x_p7.clone() }))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        })),
        crate::lower::model::OutTy::OutArray(i_p8) => names_program_type_f(cp_p0, &**i_p8),
        crate::lower::model::OutTy::OutMap(k_p9, v_pa) => names_program_type_f(cp_p0, &**k_p9) || names_program_type_f(cp_p0, &**v_pa),
        crate::lower::model::OutTy::OutFn(ps_pb, r_pc) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_pb.clone(), names_program_type_f(cp_p0, &**r_pc), {
            let cp_p0x = cp_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                let cp_p0xy = cp_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let f_pd = p0;
                    let x_pe = p1;
                    if f_pd {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesProgramType { cp_p0: cp_p0xy.clone(), t_p1: x_pe.clone() }))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        })),
        crate::lower::model::OutTy::OutDyn(i_pf) => names_program_type_f(cp_p0, &**i_pf),
        crate::lower::model::OutTy::OutEvent(i_pg) => names_program_type_f(cp_p0, &**i_pg),
        crate::lower::model::OutTy::OutNamed(_, args_ph) => crate::prelude::run_to_end(crate::prelude::fold_job(args_ph.clone(), false, {
            let cp_p0x = cp_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                let cp_p0xy = cp_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let f_pi = p0;
                    let x_pj = p1;
                    if f_pi {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(Behind { cp_p0: cp_p0xy.clone(), t_p1: x_pj.clone() }))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        })),
        _ => false,
    }
}

/// The step machine of `Behind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Behind: unbounded fn Cp, OutTy -> Bool
/// ```
pub struct Behind {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::OutTy,
}

impl ::prism_rtl::Job<bool> for Behind {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        match t_p1 {
            crate::lower::model::OutTy::OutRc(_) => ::prism_rtl::Turn::Finished(true),
            crate::lower::model::OutTy::OutOpt(i_p2) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Behind { cp_p0: cp_p0.clone(), t_p1: (**i_p2).clone() })),
            crate::lower::model::OutTy::OutRes(i_p3) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Behind { cp_p0: cp_p0.clone(), t_p1: (**i_p3).clone() })),
            crate::lower::model::OutTy::OutCell(i_p4) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Behind { cp_p0: cp_p0.clone(), t_p1: (**i_p4).clone() })),
            crate::lower::model::OutTy::OutTuple(ts_p5) => crate::prelude::fold_job(ts_p5.clone(), false, {
                let cp_p0x = cp_p0.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                    let cp_p0xy = cp_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_p6 = p0;
                        let x_p7 = p1;
                        if f_p6 {
                            ::prism_rtl::Turn::Finished(true)
                        } else {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(Behind { cp_p0: cp_p0xy.clone(), t_p1: x_p7.clone() }))
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }).cycle(),
            crate::lower::model::OutTy::OutArray(i_p8) => ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_p8).clone() })),
            crate::lower::model::OutTy::OutMap(k_p9, v_pa) => {
                let cp_p0x = cp_p0.clone();
                let k_p9x = (**k_p9).clone();
                let v_pax = (**v_pa).clone();
                crate::prelude::call_then(start_names_program_type_f(cp_p0x.clone(), k_p9x.clone()), move |names_program_type_f_5273: bool| if names_program_type_f_5273 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesProgramType { cp_p0: cp_p0x.clone(), t_p1: v_pax.clone() }))
                })
            },
            crate::lower::model::OutTy::OutFn(ps_pb, r_pc) => {
                let cp_p0x = cp_p0.clone();
                let ps_pbx = ps_pb.clone();
                let r_pcx = (**r_pc).clone();
                crate::prelude::call_then(start_names_program_type_f(cp_p0x.clone(), r_pcx.clone()), move |names_program_type_f_5350: bool| crate::prelude::fold_job(ps_pbx.clone(), names_program_type_f_5350, {
                    let cp_p0xx = cp_p0x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                        let cp_p0xxy = cp_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let f_pd = p0;
                            let x_pe = p1;
                            if f_pd {
                                ::prism_rtl::Turn::Finished(true)
                            } else {
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesProgramType { cp_p0: cp_p0xxy.clone(), t_p1: x_pe.clone() }))
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                }).cycle())
            },
            crate::lower::model::OutTy::OutDyn(i_pf) => ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_pf).clone() })),
            crate::lower::model::OutTy::OutEvent(i_pg) => ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_pg).clone() })),
            crate::lower::model::OutTy::OutNamed(_, args_ph) => crate::prelude::fold_job(args_ph.clone(), false, {
                let cp_p0x = cp_p0.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                    let cp_p0xy = cp_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_pi = p0;
                        let x_pj = p1;
                        if f_pi {
                            ::prism_rtl::Turn::Finished(true)
                        } else {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(Behind { cp_p0: cp_p0xy.clone(), t_p1: x_pj.clone() }))
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }).cycle(),
            _ => ::prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start Behind, x`: what the function value is when passed to `@Run`.
pub fn start_behind_f(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(Behind { cp_p0, t_p1 })
}

/// ```prism
/// NamesProgramType: unbounded fn Cp, OutTy -> Bool
/// ```
pub fn names_program_type_f(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::OutTy) -> bool {
    match t_p1 {
        crate::lower::model::OutTy::OutNamed(n_p2, args_p3) => {
            let own_p4 = match crate::emit::cpp::type_of_o(cp_p0, n_p2) {
                ::std::option::Option::Some(info_p5) => (&info_p5.kind_p != &crate::prelude::Text::lit("node")) && (&info_p5.kind_p != &crate::prelude::Text::lit("job")),
                ::std::option::Option::None => false,
            };
            own_p4 || crate::prelude::run_to_end(crate::prelude::fold_job(args_p3.clone(), false, {
                let cp_p0x = cp_p0.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                    let cp_p0xy = cp_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_p6 = p0;
                        let x_p7 = p1;
                        if f_p6 {
                            ::prism_rtl::Turn::Finished(true)
                        } else {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesProgramType { cp_p0: cp_p0xy.clone(), t_p1: x_p7.clone() }))
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }))
        },
        crate::lower::model::OutTy::OutOpt(i_p8) => names_program_type_f(cp_p0, &**i_p8),
        crate::lower::model::OutTy::OutRes(i_p9) => names_program_type_f(cp_p0, &**i_p9),
        crate::lower::model::OutTy::OutRc(i_pa) => names_program_type_f(cp_p0, &**i_pa),
        crate::lower::model::OutTy::OutCell(i_pb) => names_program_type_f(cp_p0, &**i_pb),
        crate::lower::model::OutTy::OutArray(i_pc) => names_program_type_f(cp_p0, &**i_pc),
        crate::lower::model::OutTy::OutMap(k_pd, v_pe) => names_program_type_f(cp_p0, &**k_pd) || names_program_type_f(cp_p0, &**v_pe),
        crate::lower::model::OutTy::OutTuple(ts_pf) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_pf.clone(), false, {
            let cp_p0x = cp_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                let cp_p0xy = cp_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let f_pg = p0;
                    let x_ph = p1;
                    if f_pg {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesProgramType { cp_p0: cp_p0xy.clone(), t_p1: x_ph.clone() }))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        })),
        crate::lower::model::OutTy::OutFn(ps_pi, r_pj) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_pi.clone(), names_program_type_f(cp_p0, &**r_pj), {
            let cp_p0x = cp_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                let cp_p0xy = cp_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let f_pk = p0;
                    let x_pl = p1;
                    if f_pk {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesProgramType { cp_p0: cp_p0xy.clone(), t_p1: x_pl.clone() }))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        })),
        crate::lower::model::OutTy::OutDyn(i_pm) => names_program_type_f(cp_p0, &**i_pm),
        crate::lower::model::OutTy::OutEvent(i_pn) => names_program_type_f(cp_p0, &**i_pn),
        _ => false,
    }
}

/// The step machine of `NamesProgramType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamesProgramType: unbounded fn Cp, OutTy -> Bool
/// ```
pub struct NamesProgramType {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::OutTy,
}

impl ::prism_rtl::Job<bool> for NamesProgramType {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        match t_p1 {
            crate::lower::model::OutTy::OutNamed(n_p2, args_p3) => {
                let own_p4 = match crate::emit::cpp::type_of_o(cp_p0, n_p2) {
                    ::std::option::Option::Some(info_p5) => (&info_p5.kind_p != &crate::prelude::Text::lit("node")) && (&info_p5.kind_p != &crate::prelude::Text::lit("job")),
                    ::std::option::Option::None => false,
                };
                if own_p4 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    crate::prelude::fold_job(args_p3.clone(), false, {
                        let cp_p0x = cp_p0.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                            let cp_p0xy = cp_p0x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let f_p6 = p0;
                                let x_p7 = p1;
                                if f_p6 {
                                    ::prism_rtl::Turn::Finished(true)
                                } else {
                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesProgramType { cp_p0: cp_p0xy.clone(), t_p1: x_p7.clone() }))
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                    }).cycle()
                }
            },
            crate::lower::model::OutTy::OutOpt(i_p8) => ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_p8).clone() })),
            crate::lower::model::OutTy::OutRes(i_p9) => ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_p9).clone() })),
            crate::lower::model::OutTy::OutRc(i_pa) => ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_pa).clone() })),
            crate::lower::model::OutTy::OutCell(i_pb) => ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_pb).clone() })),
            crate::lower::model::OutTy::OutArray(i_pc) => ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_pc).clone() })),
            crate::lower::model::OutTy::OutMap(k_pd, v_pe) => {
                let cp_p0x = cp_p0.clone();
                let k_pdx = (**k_pd).clone();
                let v_pex = (**v_pe).clone();
                crate::prelude::call_then(start_names_program_type_f(cp_p0x.clone(), k_pdx.clone()), move |names_program_type_f_6153: bool| if names_program_type_f_6153 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesProgramType { cp_p0: cp_p0x.clone(), t_p1: v_pex.clone() }))
                })
            },
            crate::lower::model::OutTy::OutTuple(ts_pf) => crate::prelude::fold_job(ts_pf.clone(), false, {
                let cp_p0x = cp_p0.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                    let cp_p0xy = cp_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_pg = p0;
                        let x_ph = p1;
                        if f_pg {
                            ::prism_rtl::Turn::Finished(true)
                        } else {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesProgramType { cp_p0: cp_p0xy.clone(), t_p1: x_ph.clone() }))
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }).cycle(),
            crate::lower::model::OutTy::OutFn(ps_pi, r_pj) => {
                let cp_p0x = cp_p0.clone();
                let ps_pix = ps_pi.clone();
                let r_pjx = (**r_pj).clone();
                crate::prelude::call_then(start_names_program_type_f(cp_p0x.clone(), r_pjx.clone()), move |names_program_type_f_6299: bool| crate::prelude::fold_job(ps_pix.clone(), names_program_type_f_6299, {
                    let cp_p0xx = cp_p0x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                        let cp_p0xxy = cp_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let f_pk = p0;
                            let x_pl = p1;
                            if f_pk {
                                ::prism_rtl::Turn::Finished(true)
                            } else {
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesProgramType { cp_p0: cp_p0xxy.clone(), t_p1: x_pl.clone() }))
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                }).cycle())
            },
            crate::lower::model::OutTy::OutDyn(i_pm) => ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_pm).clone() })),
            crate::lower::model::OutTy::OutEvent(i_pn) => ::prism_rtl::Turn::More(::std::rc::Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_pn).clone() })),
            _ => ::prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start NamesProgramType, x`: what the function value is when passed to `@Run`.
pub fn start_names_program_type_f(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(NamesProgramType { cp_p0, t_p1 })
}

/// ```prism
/// let noParts
/// ```
pub fn no_parts_p() -> Parts {
    Parts { forward_p: crate::prelude::Array::new(), values_p: crate::prelude::Array::new(), protos_p: crate::prelude::Array::new(), classes_p: crate::prelude::Array::new(), outer_p: crate::prelude::Array::new(), generic_p: crate::prelude::Array::new(), defs_p: crate::prelude::Array::new() }
}

/// ```prism
/// JoinParts: fn Parts, Parts -> Parts
/// ```
pub fn join_parts_f(a_p0: &Parts, b_p1: &Parts) -> Parts {
    Parts { forward_p: crate::prelude::append(&a_p0.forward_p, &b_p1.forward_p), values_p: crate::prelude::append(&a_p0.values_p, &b_p1.values_p), protos_p: crate::prelude::append(&a_p0.protos_p, &b_p1.protos_p), classes_p: crate::prelude::append(&a_p0.classes_p, &b_p1.classes_p), outer_p: crate::prelude::append(&a_p0.outer_p, &b_p1.outer_p), generic_p: crate::prelude::append(&a_p0.generic_p, &b_p1.generic_p), defs_p: crate::prelude::append(&a_p0.defs_p, &b_p1.defs_p) }
}

/// ```prism
/// ItemParts: unbounded fn Cp, Item -> Parts
/// ```
pub fn item_parts_f(cp_p0: &crate::emit::cpp::Cp, it_p1: &crate::lower::model::Item) -> Parts {
    match it_p1 {
        crate::lower::model::Item::ItType(t_p2) => type_parts_f(cp_p0, t_p2),
        crate::lower::model::Item::ItTag(t_p3) => tag_parts_f(cp_p0, t_p3),
        crate::lower::model::Item::ItRow(r_p4) => row_parts_f(cp_p0, &cp_p0.home_p, r_p4),
        crate::lower::model::Item::ItFn(f_p5) => fn_parts_f(cp_p0, f_p5),
        crate::lower::model::Item::ItJob(j_p6) => job_parts_f(cp_p0, j_p6),
        crate::lower::model::Item::ItNode(n_p7) => crate::emit::cpp::program::node_parts_f(cp_p0, n_p7),
        crate::lower::model::Item::ItTrait(t_p8) => trait_parts_f(cp_p0, t_p8),
        crate::lower::model::Item::ItImpl(i_p9) => impl_parts_f(cp_p0, i_p9),
        crate::lower::model::Item::ItPacked(d_pa) => packed_parts_f(cp_p0, d_pa),
        crate::lower::model::Item::ItNote(t_pb) => protos_defs_f(&crate::prelude::Array::new(), &crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("// {}", t_pb))])),
        crate::lower::model::Item::ItRefused(t_pc) => protos_defs_f(&crate::prelude::Array::new(), &crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("compile_error!(\"{}{}\");", &crate::lower::expr::lowering_refusal_p(), &crate::lower::expr::escape_f(t_pc)))])),
    }
}

/// The step machine of `ItemParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ItemParts: unbounded fn Cp, Item -> Parts
/// ```
pub struct ItemParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub it_p1: crate::lower::model::Item,
}

impl ::prism_rtl::Job<Parts> for ItemParts {
    fn cycle(&self) -> ::prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let it_p1 = &self.it_p1;
        match it_p1 {
            crate::lower::model::Item::ItType(t_p2) => ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeParts { cp_p0: cp_p0.clone(), t0_p1: t_p2.clone() })),
            crate::lower::model::Item::ItTag(t_p3) => ::prism_rtl::Turn::More(::std::rc::Rc::new(TagParts { cp_p0: cp_p0.clone(), t_p1: t_p3.clone() })),
            crate::lower::model::Item::ItRow(r_p4) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RowParts { cp_p0: cp_p0.clone(), m_p1: cp_p0.home_p.clone(), r_p2: r_p4.clone() })),
            crate::lower::model::Item::ItFn(f_p5) => ::prism_rtl::Turn::More(::std::rc::Rc::new(FnParts { cp_p0: cp_p0.clone(), f_p1: f_p5.clone() })),
            crate::lower::model::Item::ItJob(j_p6) => ::prism_rtl::Turn::More(::std::rc::Rc::new(JobParts { cp_p0: cp_p0.clone(), j_p1: j_p6.clone() })),
            crate::lower::model::Item::ItNode(n_p7) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::cpp::program::NodeParts { cp_p0: cp_p0.clone(), n_p1: n_p7.clone() })),
            crate::lower::model::Item::ItTrait(t_p8) => ::prism_rtl::Turn::More(::std::rc::Rc::new(TraitParts { cp_p0: cp_p0.clone(), t_p1: t_p8.clone() })),
            crate::lower::model::Item::ItImpl(i_p9) => ::prism_rtl::Turn::More(::std::rc::Rc::new(ImplParts { cp_p0: cp_p0.clone(), i_p1: i_p9.clone() })),
            crate::lower::model::Item::ItPacked(d_pa) => ::prism_rtl::Turn::More(::std::rc::Rc::new(PackedParts { cp_p0: cp_p0.clone(), d_p1: d_pa.clone() })),
            crate::lower::model::Item::ItNote(t_pb) => ::prism_rtl::Turn::Finished(protos_defs_f(&crate::prelude::Array::new(), &crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("// {}", t_pb))]))),
            crate::lower::model::Item::ItRefused(t_pc) => ::prism_rtl::Turn::Finished(protos_defs_f(&crate::prelude::Array::new(), &crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("compile_error!(\"{}{}\");", &crate::lower::expr::lowering_refusal_p(), &crate::lower::expr::escape_f(t_pc)))]))),
        }
    }
}

/// `Start ItemParts, x`: what the function value is when passed to `@Run`.
pub fn start_item_parts_f(cp_p0: crate::emit::cpp::Cp, it_p1: crate::lower::model::Item) -> ::std::rc::Rc<dyn ::prism_rtl::Job<Parts>> {
    ::std::rc::Rc::new(ItemParts { cp_p0, it_p1 })
}

/// ```prism
/// FnParts: unbounded fn Cp, FnDef -> Parts
/// ```
pub fn fn_parts_f(cp_p0: &crate::emit::cpp::Cp, f_p1: &crate::lower::model::FnDef) -> Parts {
    if &crate::prelude::len(&f_p1.generics_p) > &crate::prelude::Nat::from(0u32) {
        {
            let mut this: Parts = generic_only_f(&crate::prelude::Array::from(vec![fn_definition_f(cp_p0, f_p1)]));
            this.protos_p = crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("{};", &fn_signature_f(cp_p0, f_p1)))]);
            this
        }
    } else {
        protos_defs_f(&crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("{};", &fn_signature_f(cp_p0, f_p1)))]), &crate::prelude::Array::from(vec![fn_definition_f(cp_p0, f_p1)]))
    }
}

/// The step machine of `FnParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnParts: unbounded fn Cp, FnDef -> Parts
/// ```
pub struct FnParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub f_p1: crate::lower::model::FnDef,
}

impl ::prism_rtl::Job<Parts> for FnParts {
    fn cycle(&self) -> ::prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let f_p1 = &self.f_p1;
        if &crate::prelude::len(&f_p1.generics_p) > &crate::prelude::Nat::from(0u32) {
            ::prism_rtl::Turn::Finished({
                let mut this: Parts = generic_only_f(&crate::prelude::Array::from(vec![fn_definition_f(cp_p0, f_p1)]));
                this.protos_p = crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("{};", &fn_signature_f(cp_p0, f_p1)))]);
                this
            })
        } else {
            {
                let cp_p0x = cp_p0.clone();
                let f_p1x = f_p1.clone();
                crate::prelude::call_then(start_fn_signature_f(cp_p0x.clone(), f_p1x.clone()), move |fn_signature_f_7576: crate::prelude::Text| crate::prelude::call_then(start_fn_definition_f(cp_p0x.clone(), f_p1x.clone()), move |fn_definition_f_7603: crate::prelude::Text| ::prism_rtl::Turn::Finished(protos_defs_f(&crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("{};", &fn_signature_f_7576))]), &crate::prelude::Array::from(vec![fn_definition_f_7603])))))
            }
        }
    }
}

/// `Start FnParts, x`: what the function value is when passed to `@Run`.
pub fn start_fn_parts_f(cp_p0: crate::emit::cpp::Cp, f_p1: crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<Parts>> {
    ::std::rc::Rc::new(FnParts { cp_p0, f_p1 })
}

/// ```prism
/// CppDoc: fn Text -> Text
/// ```
pub fn cpp_doc_f(text_p0: &crate::prelude::Text) -> crate::prelude::Text {
    if text_p0 == &crate::prelude::Text::lit("") {
        crate::prelude::Text::lit("")
    } else {
        crate::prelude::concat(&crate::prelude::each(&crate::prelude::split_on(text_p0, &crate::prelude::Text::lit("\n")), &(|l_p1: &crate::prelude::Text| if l_p1 == &crate::prelude::Text::lit("") {
            crate::prelude::Text::lit("///\n")
        } else {
            crate::prelude::Text::from(format!("/// {}\n", l_p1))
        })))
    }
}

/// ```prism
/// CppSourceDoc: fn Text, Text -> Text
/// ```
pub fn cpp_source_doc_f(lead_p0: &crate::prelude::Text, source_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let quoted_p2 = crate::prelude::concat(&crate::prelude::each(&crate::prelude::split_on(source_p1, &crate::prelude::Text::lit("\n")), &(|l_p3: &crate::prelude::Text| if l_p3 == &crate::prelude::Text::lit("") {
        crate::prelude::Text::lit("///\n")
    } else {
        crate::prelude::Text::from(format!("/// {}\n", l_p3))
    })));
    if source_p1 == &crate::prelude::Text::lit("") {
        cpp_doc_f(lead_p0)
    } else {
        if lead_p0 == &crate::prelude::Text::lit("") {
            crate::prelude::Text::from(format!("/// ```prism\n{}/// ```\n", &quoted_p2))
        } else {
            crate::prelude::Text::from(format!("/// {}\n///\n/// ```prism\n{}/// ```\n", lead_p0, &quoted_p2))
        }
    }
}

/// ```prism
/// TypeParts: unbounded fn Cp, TyDef -> Parts
/// ```
pub fn type_parts_f(cp_p0: &crate::emit::cpp::Cp, t0_p1: &crate::lower::model::TyDef) -> Parts {
    let t_p2 = crate::emit::cpp::cpp_cases_f(t0_p1);
    let eq_p3 = t_p2.eq_p;
    let ord_p4 = t_p2.ord_p;
    let gens_p5 = cpp_template_head_f(&t_p2.params_p);
    let head_p6 = head_of_f(&t_p2.name_p, &t_p2.params_p);
    let doc_p7 = cpp_source_doc_f(&crate::prelude::Text::from(format!("`{}`:", &t_p2.prism_p)), &t_p2.doc_p);
    let members_p8 = members_f(&(&t_p2.show_p != &crate::lower::model::Shown::NotShown), &t_p2.pod_p, &head_p6);
    let generic_p9 = &crate::prelude::len(&t_p2.params_p) > &crate::prelude::Nat::from(0u32);
    let fwd_pa = crate::prelude::Text::from(format!("{}{} {};", &gens_p5, &(if &t_p2.shape_p == &crate::lower::model::TyShape::ShapeChoice {
        crate::prelude::Text::lit("class")
    } else {
        crate::prelude::Text::lit("struct")
    }), &t_p2.name_p));
    let deps_pb = crate::emit::cpp::patterns::concat2_f(&crate::prelude::run_to_end(crate::prelude::each_job(t_p2.cases_p.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::CaseDef| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let c_pd = p0;
                crate::prelude::call_value(crate::prelude::each_job(c_pd.fields_p.clone(), {
                    let cp_p0xyx = cp_p0xy.clone();
                    ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| {
                        let cp_p0xyxy = cp_p0xyx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (_, ft_pe) = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(ValueDeps { cp_p0: cp_p0xyxy.clone(), t_p1: ft_pe.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                }), move |each_8982: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| ::prism_rtl::Turn::Finished(crate::emit::cpp::patterns::concat2_f(&each_8982)))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::CaseDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
    })));
    let (text_p18, cmp_defs_p19) = match &t_p2.shape_p {
        crate::lower::model::TyShape::ShapeChoice => {
            let names_pf = crate::prelude::each(&t_p2.cases_p, &(|c_pk: &crate::lower::model::CaseDef| c_pk.name_p.clone()));
            let cases_pg = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(t_p2.cases_p.clone(), {
                let cp_p0x = cp_p0.clone();
                let eq_p3x = eq_p3;
                let ord_p4x = ord_p4;
                ::std::rc::Rc::new(move |p0: crate::lower::model::CaseDef| {
                    let cp_p0xy = cp_p0x.clone();
                    let eq_p3xy = eq_p3x;
                    let ord_p4xy = ord_p4x;
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let c_pl = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(CaseStruct { cp_p0: cp_p0xy.clone(), c_p1: c_pl.clone(), eq_p2: eq_p3xy, ord_p3: ord_p4xy }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::CaseDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            })), &crate::prelude::Text::lit("\n"));
            let cls_ph = crate::emit::cpp::templates::items::choice_class_f(&doc_p7, &gens_p5, &t_p2.name_p, &cases_pg, &(if &crate::prelude::len(&names_pf) == &crate::prelude::Nat::from(0u32) {
                crate::prelude::Text::lit("::prism_rtl::NoCase")
            } else {
                crate::syntax::lexer::chars::join_f(&names_pf, &crate::prelude::Text::lit(", "))
            }), &members_p8);
            let cmp_pi = crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::Array::from(vec![if eq_p3 {
                crate::prelude::Text::from(format!("{}inline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &gens_p5, &head_p6, &head_p6))
            } else {
                crate::prelude::Text::lit("")
            }, if ord_p4 {
                crate::prelude::Text::from(format!("{}inline ::std::strong_ordering operator<=>(const {}& a, const {}& b) {{ return a.cases() <=> b.cases(); }}", &gens_p5, &head_p6, &head_p6))
            } else {
                crate::prelude::Text::lit("")
            }]), &(|s_pm: &crate::prelude::Text| s_pm != &crate::prelude::Text::lit(""))), &crate::prelude::Text::lit("\n"));
            let case_defs_pj = crate::prelude::filter(&crate::prelude::run_to_end(crate::prelude::each_job(t_p2.cases_p.clone(), {
                let cp_p0x = cp_p0.clone();
                let gens_p5x = gens_p5.clone();
                let head_p6x = head_p6.clone();
                let eq_p3x = eq_p3;
                let ord_p4x = ord_p4;
                ::std::rc::Rc::new(move |p0: crate::lower::model::CaseDef| {
                    let cp_p0xy = cp_p0x.clone();
                    let gens_p5xy = gens_p5x.clone();
                    let head_p6xy = head_p6x.clone();
                    let eq_p3xy = eq_p3x;
                    let ord_p4xy = ord_p4x;
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let c_pn = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(CaseCmpDefs { cp_p0: cp_p0xy.clone(), gens_p1: gens_p5xy.clone(), head_p2: head_p6xy.clone(), c_p3: c_pn.clone(), eq_p4: eq_p3xy, ord_p5: ord_p4xy }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::CaseDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            })), &(|s_po: &crate::prelude::Text| s_po != &crate::prelude::Text::lit("")));
            (crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::Array::from(vec![cls_ph.clone(), cmp_pi.clone()]), &(|s_pp: &crate::prelude::Text| s_pp != &crate::prelude::Text::lit(""))), &crate::prelude::Text::lit("\n")), case_defs_pj.clone())
        },
        _ => {
            let first_pq = crate::prelude::or(&crate::prelude::index(&t_p2.cases_p, &crate::prelude::Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() });
            let fields_pr = match &t_p2.shape_p {
                crate::lower::model::TyShape::ShapeRecord => crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(first_pq.fields_p.clone(), {
                    let cp_p0x = cp_p0.clone();
                    ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| {
                        let cp_p0xy = cp_p0x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (f_pv, ft_p10) = p0;
                            crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), ft_p10.clone()), move |cpp_type_f_10401: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {};", &cpp_type_f_10401, &crate::emit::cpp::field_id_f(&f_pv)))))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                })), &crate::prelude::Text::lit("\n")),
                crate::lower::model::TyShape::ShapeNewtype => positional_fields_f(cp_p0, &first_pq.fields_p),
                _ => crate::prelude::Text::lit(""),
            };
            let names_ps = match &t_p2.shape_p {
                crate::lower::model::TyShape::ShapeRecord => crate::prelude::each(&first_pq.fields_p, &(|(f_p11, _): &(crate::prelude::Text, crate::lower::model::OutTy)| crate::emit::cpp::field_id_f(f_p11))),
                crate::lower::model::TyShape::ShapeNewtype => crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&first_pq.fields_p)), &(|i_p12: &crate::prelude::Nat| crate::prelude::Text::from(format!("a{}", i_p12)))),
                _ => crate::prelude::Array::new(),
            };
            let behind_pt = crate::prelude::run_to_end(crate::prelude::fold_job(first_pq.fields_p.clone(), false, {
                let cp_p0x = cp_p0.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::lower::model::OutTy))| {
                    let cp_p0xy = cp_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_p13 = p0;
                        let (_, ft_p14) = p1;
                        if f_p13 {
                            ::prism_rtl::Turn::Finished(true)
                        } else {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(Behind { cp_p0: cp_p0xy.clone(), t_p1: ft_p14.clone() }))
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::lower::model::OutTy))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }));
            let (cmps_p15, cmp_defs_p16) = comparisons_f(&gens_p5, &head_p6, &t_p2.name_p, &names_ps, &eq_p3, &ord_p4, &behind_pt);
            let decl_pu = crate::emit::cpp::templates::items::value_struct_f(&doc_p7, &gens_p5, &t_p2.name_p, &fields_pr, &crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::Array::from(vec![cmps_p15.clone(), members_p8.clone()]), &(|s_p17: &crate::prelude::Text| s_p17 != &crate::prelude::Text::lit(""))), &crate::prelude::Text::lit("\n")));
            (decl_pu.clone(), if &cmp_defs_p16 == &crate::prelude::Text::lit("") {
                crate::prelude::Array::new()
            } else {
                crate::prelude::Array::from(vec![cmp_defs_p16.clone()])
            })
        },
    };
    let defs_pc = crate::prelude::append(&cmp_defs_p19, &crate::prelude::Array::from(vec![type_defs_f(cp_p0, &t_p2, &head_p6)]));
    Parts { forward_p: crate::prelude::Array::from(vec![fwd_pa.clone()]), values_p: crate::prelude::Array::from(vec![ValueDecl { path_p: decl_path_f(cp_p0, &t_p2.name_p), deps_p: deps_pb.clone(), text_p: text_p18.clone() }]), protos_p: crate::prelude::Array::new(), classes_p: crate::prelude::Array::new(), outer_p: crate::prelude::Array::new(), generic_p: if generic_p9 { defs_pc.clone() } else { crate::prelude::Array::new() }, defs_p: if generic_p9 { crate::prelude::Array::new() } else { defs_pc.clone() } }
}

/// The step machine of `TypeParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeParts: unbounded fn Cp, TyDef -> Parts
/// ```
pub struct TypeParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t0_p1: crate::lower::model::TyDef,
}

impl ::prism_rtl::Job<Parts> for TypeParts {
    fn cycle(&self) -> ::prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let t0_p1 = &self.t0_p1;
        let t_p2 = crate::emit::cpp::cpp_cases_f(t0_p1);
        let eq_p3 = t_p2.eq_p;
        let ord_p4 = t_p2.ord_p;
        let gens_p5 = cpp_template_head_f(&t_p2.params_p);
        let head_p6 = head_of_f(&t_p2.name_p, &t_p2.params_p);
        let doc_p7 = cpp_source_doc_f(&crate::prelude::Text::from(format!("`{}`:", &t_p2.prism_p)), &t_p2.doc_p);
        let members_p8 = members_f(&(&t_p2.show_p != &crate::lower::model::Shown::NotShown), &t_p2.pod_p, &head_p6);
        let generic_p9 = &crate::prelude::len(&t_p2.params_p) > &crate::prelude::Nat::from(0u32);
        let fwd_pa = crate::prelude::Text::from(format!("{}{} {};", &gens_p5, &(if &t_p2.shape_p == &crate::lower::model::TyShape::ShapeChoice {
            crate::prelude::Text::lit("class")
        } else {
            crate::prelude::Text::lit("struct")
        }), &t_p2.name_p));
        let cp_p0x = cp_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(t_p2.cases_p.clone(), {
            let cp_p0xx = cp_p0x.clone();
            ::std::rc::Rc::new(move |p0: crate::lower::model::CaseDef| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let c_pd = p0;
                    crate::prelude::call_value(crate::prelude::each_job(c_pd.fields_p.clone(), {
                        let cp_p0xxyx = cp_p0xxy.clone();
                        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| {
                            let cp_p0xxyxy = cp_p0xxyx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (_, ft_pe) = p0;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(ValueDeps { cp_p0: cp_p0xxyxy.clone(), t_p1: ft_pe.clone() }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                    }), move |each_8982: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| ::prism_rtl::Turn::Finished(crate::emit::cpp::patterns::concat2_f(&each_8982)))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::CaseDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
        }), move |each_8954: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| {
            let deps_pb = crate::emit::cpp::patterns::concat2_f(&each_8954);
            let cp_p0xz = cp_p0x.clone();
            let deps_pbz = deps_pb.clone();
            let fwd_paz = fwd_pa.clone();
            let generic_p9z = generic_p9;
            let head_p6z = head_p6.clone();
            let t_p2z = t_p2.clone();
            let k_let9038 = move |v9038: (crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)| {
                let (text_p18, cmp_defs_p19) = v9038;
                crate::prelude::call_then(start_type_defs_f(cp_p0xz.clone(), t_p2z.clone(), head_p6z.clone()), move |type_defs_f_11151: crate::prelude::Text| {
                    let defs_pc = crate::prelude::append(&cmp_defs_p19, &crate::prelude::Array::from(vec![type_defs_f_11151]));
                    ::prism_rtl::Turn::Finished(Parts { forward_p: crate::prelude::Array::from(vec![fwd_paz.clone()]), values_p: crate::prelude::Array::from(vec![ValueDecl { path_p: decl_path_f(&cp_p0xz, &t_p2z.name_p), deps_p: deps_pbz.clone(), text_p: text_p18.clone() }]), protos_p: crate::prelude::Array::new(), classes_p: crate::prelude::Array::new(), outer_p: crate::prelude::Array::new(), generic_p: if generic_p9z { defs_pc.clone() } else { crate::prelude::Array::new() }, defs_p: if generic_p9z { crate::prelude::Array::new() } else { defs_pc.clone() } })
                })
            };
            match t_p2.shape_p.clone() {
                crate::lower::model::TyShape::ShapeChoice => {
                    let names_pf = crate::prelude::each(&t_p2.cases_p, &(|c_pk: &crate::lower::model::CaseDef| c_pk.name_p.clone()));
                    crate::prelude::call_value(crate::prelude::each_job(t_p2.cases_p.clone(), {
                        let cp_p0xx = cp_p0x.clone();
                        let eq_p3x = eq_p3;
                        let ord_p4x = ord_p4;
                        ::std::rc::Rc::new(move |p0: crate::lower::model::CaseDef| {
                            let cp_p0xxy = cp_p0xx.clone();
                            let eq_p3xy = eq_p3x;
                            let ord_p4xy = ord_p4x;
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let c_pl = p0;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(CaseStruct { cp_p0: cp_p0xxy.clone(), c_p1: c_pl.clone(), eq_p2: eq_p3xy, ord_p3: ord_p4xy }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::CaseDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                    }), move |each_9178: crate::prelude::Array<crate::prelude::Text>| {
                        let cases_pg = crate::syntax::lexer::chars::join_f(&each_9178, &crate::prelude::Text::lit("\n"));
                        let cls_ph = crate::emit::cpp::templates::items::choice_class_f(&doc_p7, &gens_p5, &t_p2.name_p, &cases_pg, &(if &crate::prelude::len(&names_pf) == &crate::prelude::Nat::from(0u32) {
                            crate::prelude::Text::lit("::prism_rtl::NoCase")
                        } else {
                            crate::syntax::lexer::chars::join_f(&names_pf, &crate::prelude::Text::lit(", "))
                        }), &members_p8);
                        let cmp_pi = crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::Array::from(vec![if eq_p3 {
                            crate::prelude::Text::from(format!("{}inline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &gens_p5, &head_p6, &head_p6))
                        } else {
                            crate::prelude::Text::lit("")
                        }, if ord_p4 {
                            crate::prelude::Text::from(format!("{}inline ::std::strong_ordering operator<=>(const {}& a, const {}& b) {{ return a.cases() <=> b.cases(); }}", &gens_p5, &head_p6, &head_p6))
                        } else {
                            crate::prelude::Text::lit("")
                        }]), &(|s_pm: &crate::prelude::Text| s_pm != &crate::prelude::Text::lit(""))), &crate::prelude::Text::lit("\n"));
                        crate::prelude::call_value(crate::prelude::each_job(t_p2.cases_p.clone(), {
                            let cp_p0xx = cp_p0x.clone();
                            let gens_p5x = gens_p5.clone();
                            let head_p6x = head_p6.clone();
                            let eq_p3x = eq_p3;
                            let ord_p4x = ord_p4;
                            ::std::rc::Rc::new(move |p0: crate::lower::model::CaseDef| {
                                let cp_p0xxy = cp_p0xx.clone();
                                let gens_p5xy = gens_p5x.clone();
                                let head_p6xy = head_p6x.clone();
                                let eq_p3xy = eq_p3x;
                                let ord_p4xy = ord_p4x;
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let c_pn = p0;
                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(CaseCmpDefs { cp_p0: cp_p0xxy.clone(), gens_p1: gens_p5xy.clone(), head_p2: head_p6xy.clone(), c_p3: c_pn.clone(), eq_p4: eq_p3xy, ord_p5: ord_p4xy }))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::CaseDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                        }), move |each_10031: crate::prelude::Array<crate::prelude::Text>| {
                            let case_defs_pj = crate::prelude::filter(&each_10031, &(|s_po: &crate::prelude::Text| s_po != &crate::prelude::Text::lit("")));
                            k_let9038((crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::Array::from(vec![cls_ph.clone(), cmp_pi.clone()]), &(|s_pp: &crate::prelude::Text| s_pp != &crate::prelude::Text::lit(""))), &crate::prelude::Text::lit("\n")), case_defs_pj.clone()))
                        })
                    })
                },
                _ => {
                    let first_pq = crate::prelude::or(&crate::prelude::index(&t_p2.cases_p, &crate::prelude::Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() });
                    let cp_p0xz = cp_p0x.clone();
                    let doc_p7z = doc_p7.clone();
                    let eq_p3z = eq_p3;
                    let first_pqz = first_pq.clone();
                    let gens_p5z = gens_p5.clone();
                    let head_p6z = head_p6.clone();
                    let members_p8z = members_p8.clone();
                    let ord_p4z = ord_p4;
                    let t_p2z = t_p2.clone();
                    let k_let10304 = move |v10304: crate::prelude::Text| {
                        let fields_pr = v10304;
                        let names_ps = match &t_p2z.shape_p {
                            crate::lower::model::TyShape::ShapeRecord => crate::prelude::each(&first_pqz.fields_p, &(|(f_p11, _): &(crate::prelude::Text, crate::lower::model::OutTy)| crate::emit::cpp::field_id_f(f_p11))),
                            crate::lower::model::TyShape::ShapeNewtype => crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&first_pqz.fields_p)), &(|i_p12: &crate::prelude::Nat| crate::prelude::Text::from(format!("a{}", i_p12)))),
                            _ => crate::prelude::Array::new(),
                        };
                        crate::prelude::call_value(crate::prelude::fold_job(first_pqz.fields_p.clone(), false, {
                            let cp_p0xzx = cp_p0xz.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::lower::model::OutTy))| {
                                let cp_p0xzxy = cp_p0xzx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let f_p13 = p0;
                                    let (_, ft_p14) = p1;
                                    if f_p13 {
                                        ::prism_rtl::Turn::Finished(true)
                                    } else {
                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(Behind { cp_p0: cp_p0xzxy.clone(), t_p1: ft_p14.clone() }))
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::lower::model::OutTy))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                        }), move |fold_10779: bool| {
                            let behind_pt = fold_10779;
                            let (cmps_p15, cmp_defs_p16) = comparisons_f(&gens_p5z, &head_p6z, &t_p2z.name_p, &names_ps, &eq_p3z, &ord_p4z, &behind_pt);
                            let decl_pu = crate::emit::cpp::templates::items::value_struct_f(&doc_p7z, &gens_p5z, &t_p2z.name_p, &fields_pr, &crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::Array::from(vec![cmps_p15.clone(), members_p8z.clone()]), &(|s_p17: &crate::prelude::Text| s_p17 != &crate::prelude::Text::lit(""))), &crate::prelude::Text::lit("\n")));
                            k_let9038((decl_pu.clone(), if &cmp_defs_p16 == &crate::prelude::Text::lit("") {
                                crate::prelude::Array::new()
                            } else {
                                crate::prelude::Array::from(vec![cmp_defs_p16.clone()])
                            }))
                        })
                    };
                    match t_p2.shape_p.clone() {
                        crate::lower::model::TyShape::ShapeRecord => crate::prelude::call_value(crate::prelude::each_job(first_pq.fields_p.clone(), {
                            let cp_p0xx = cp_p0x.clone();
                            ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| {
                                let cp_p0xxy = cp_p0xx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let (f_pv, ft_p10) = p0;
                                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), ft_p10.clone()), move |cpp_type_f_10401: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {};", &cpp_type_f_10401, &crate::emit::cpp::field_id_f(&f_pv)))))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                        }), move |each_10367: crate::prelude::Array<crate::prelude::Text>| k_let10304(crate::syntax::lexer::chars::join_f(&each_10367, &crate::prelude::Text::lit("\n")))),
                        crate::lower::model::TyShape::ShapeNewtype => crate::prelude::call_then(start_positional_fields_f(cp_p0x.clone(), first_pq.fields_p.clone()), move |positional_fields_f_10468: crate::prelude::Text| k_let10304(positional_fields_f_10468)),
                        _ => k_let10304(crate::prelude::Text::lit("")),
                    }
                },
            }
        })
    }
}

/// `Start TypeParts, x`: what the function value is when passed to `@Run`.
pub fn start_type_parts_f(cp_p0: crate::emit::cpp::Cp, t0_p1: crate::lower::model::TyDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<Parts>> {
    ::std::rc::Rc::new(TypeParts { cp_p0, t0_p1 })
}

/// ```prism
/// DeclPath: fn Cp, Text -> Text
/// ```
pub fn decl_path_f(cp_p0: &crate::emit::cpp::Cp, name_p1: &crate::prelude::Text) -> crate::prelude::Text {
    if &cp_p0.home_p == &crate::prelude::Text::lit("") {
        name_p1.clone()
    } else {
        crate::prelude::Text::from(format!("{}::{}", &cp_p0.home_p, name_p1))
    }
}

/// ```prism
/// Comparisons: fn Text, Text, Text, [Text], Bool, Bool, Bool -> ((Text, Text))
/// ```
pub fn comparisons_f(gens_p0: &crate::prelude::Text, owner_p1: &crate::prelude::Text, self_p2: &crate::prelude::Text, names_p3: &crate::prelude::Array<crate::prelude::Text>, eq_p4: &bool, ord_p5: &bool, behind_p6: &bool) -> (crate::prelude::Text, crate::prelude::Text) {
    if !*behind_p6 {
        (crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::Array::from(vec![if *eq_p4 {
            crate::prelude::Text::from(format!("bool operator==(const {}&) const = default;", self_p2))
        } else {
            crate::prelude::Text::lit("")
        }, if *ord_p5 {
            crate::prelude::Text::from(format!("auto operator<=>(const {}&) const = default;", self_p2))
        } else {
            crate::prelude::Text::lit("")
        }]), &(|s_p7: &crate::prelude::Text| s_p7 != &crate::prelude::Text::lit(""))), &crate::prelude::Text::lit("\n")), crate::prelude::Text::lit(""))
    } else {
        {
            let decls_p8 = crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::Array::from(vec![if *eq_p4 {
                crate::prelude::Text::from(format!("bool operator==(const {}&) const;", self_p2))
            } else {
                crate::prelude::Text::lit("")
            }, if *ord_p5 {
                crate::prelude::Text::from(format!("::std::strong_ordering operator<=>(const {}&) const;", self_p2))
            } else {
                crate::prelude::Text::lit("")
            }]), &(|s_pc: &crate::prelude::Text| s_pc != &crate::prelude::Text::lit(""))), &crate::prelude::Text::lit("\n"));
            let eq_body_p9 = if &crate::prelude::len(names_p3) == &crate::prelude::Nat::from(0u32) {
                crate::prelude::Text::lit("true")
            } else {
                crate::syntax::lexer::chars::join_f(&crate::prelude::each(names_p3, &(|n_pd: &crate::prelude::Text| crate::prelude::Text::from(format!("{} == o.{}", n_pd, n_pd)))), &crate::prelude::Text::lit(" && "))
            };
            let ord_body_pa = if &crate::prelude::len(names_p3) == &crate::prelude::Nat::from(0u32) {
                crate::prelude::Text::lit("::std::strong_ordering::equal")
            } else {
                crate::prelude::Text::from(format!("::std::tie({}) <=> ::std::tie({})", &crate::syntax::lexer::chars::join_f(names_p3, &crate::prelude::Text::lit(", ")), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(names_p3, &(|n_pe: &crate::prelude::Text| crate::prelude::Text::from(format!("o.{}", n_pe)))), &crate::prelude::Text::lit(", "))))
            };
            let defs_pb = crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::Array::from(vec![if *eq_p4 {
                crate::prelude::Text::from(format!("{}bool {}::operator==(const {}& o) const {{ return {}; }}", gens_p0, owner_p1, self_p2, &eq_body_p9))
            } else {
                crate::prelude::Text::lit("")
            }, if *ord_p5 {
                crate::prelude::Text::from(format!("{}::std::strong_ordering {}::operator<=>(const {}& o) const {{ return {}; }}", gens_p0, owner_p1, self_p2, &ord_body_pa))
            } else {
                crate::prelude::Text::lit("")
            }]), &(|s_pf: &crate::prelude::Text| s_pf != &crate::prelude::Text::lit(""))), &crate::prelude::Text::lit("\n"));
            (decls_p8.clone(), defs_pb.clone())
        }
    }
}

/// ```prism
/// Members: fn Bool, Bool, Text -> Text
/// ```
pub fn members_f(shown_p0: &bool, pod_p1: &bool, head_p2: &crate::prelude::Text) -> crate::prelude::Text {
    let s_p3 = if *shown_p0 {
        crate::prelude::Array::from(vec![crate::prelude::Text::lit("void show(crate::prelude::Printer& p) const;")])
    } else {
        crate::prelude::Array::new()
    };
    let d_p4 = if *pod_p1 {
        crate::prelude::Array::from(vec![crate::prelude::Text::lit("crate::prelude::Pod to_pod() const;"), crate::prelude::Text::from(format!("static crate::prelude::Result<{}> from_pod(const crate::prelude::Pod& whole);", head_p2))])
    } else {
        crate::prelude::Array::new()
    };
    crate::syntax::lexer::chars::join_f(&crate::prelude::append(&s_p3, &d_p4), &crate::prelude::Text::lit("\n"))
}

/// ```prism
/// CaseStruct: unbounded fn Cp, CaseDef, Bool, Bool -> Text
/// ```
pub fn case_struct_f(cp_p0: &crate::emit::cpp::Cp, c_p1: &crate::lower::model::CaseDef, eq_p2: &bool, ord_p3: &bool) -> crate::prelude::Text {
    let fields_p4 = positional_fields_f(cp_p0, &c_p1.fields_p);
    let (cmps_p5, _) = comparisons_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::lit(""), &c_p1.name_p, &case_names_f(c_p1), eq_p2, ord_p3, &case_behind_f(cp_p0, c_p1));
    crate::emit::cpp::templates::items::case_decl_f(&c_p1.name_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::Array::from(vec![fields_p4.clone(), cmps_p5.clone()]), &(|s_p6: &crate::prelude::Text| s_p6 != &crate::prelude::Text::lit(""))), &crate::prelude::Text::lit("\n")))
}

/// The step machine of `CaseStruct`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CaseStruct: unbounded fn Cp, CaseDef, Bool, Bool -> Text
/// ```
pub struct CaseStruct {
    pub cp_p0: crate::emit::cpp::Cp,
    pub c_p1: crate::lower::model::CaseDef,
    pub eq_p2: bool,
    pub ord_p3: bool,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CaseStruct {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let c_p1 = &self.c_p1;
        let eq_p2 = &self.eq_p2;
        let ord_p3 = &self.ord_p3;
        let c_p1x = c_p1.clone();
        let cp_p0x = cp_p0.clone();
        let eq_p2x = *eq_p2;
        let ord_p3x = *ord_p3;
        crate::prelude::call_then(start_positional_fields_f(cp_p0x.clone(), c_p1x.fields_p.clone()), move |positional_fields_f_13506: crate::prelude::Text| {
            let fields_p4 = positional_fields_f_13506;
            crate::prelude::call_then(start_case_behind_f(cp_p0x.clone(), c_p1x.clone()), move |case_behind_f_13616: bool| {
                let (cmps_p5, _) = comparisons_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::lit(""), &c_p1x.name_p, &case_names_f(&c_p1x), &eq_p2x, &ord_p3x, &case_behind_f_13616);
                ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::case_decl_f(&c_p1x.name_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::Array::from(vec![fields_p4.clone(), cmps_p5.clone()]), &(|s_p6: &crate::prelude::Text| s_p6 != &crate::prelude::Text::lit(""))), &crate::prelude::Text::lit("\n"))))
            })
        })
    }
}

/// `Start CaseStruct, x`: what the function value is when passed to `@Run`.
pub fn start_case_struct_f(cp_p0: crate::emit::cpp::Cp, c_p1: crate::lower::model::CaseDef, eq_p2: bool, ord_p3: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CaseStruct { cp_p0, c_p1, eq_p2, ord_p3 })
}

/// ```prism
/// CaseCmpDefs: unbounded fn Cp, Text, Text, CaseDef, Bool, Bool -> Text
/// ```
pub fn case_cmp_defs_f(cp_p0: &crate::emit::cpp::Cp, gens_p1: &crate::prelude::Text, head_p2: &crate::prelude::Text, c_p3: &crate::lower::model::CaseDef, eq_p4: &bool, ord_p5: &bool) -> crate::prelude::Text {
    let (_, defs_p6) = comparisons_f(gens_p1, &crate::prelude::Text::from(format!("{}::{}", head_p2, &c_p3.name_p)), &c_p3.name_p, &case_names_f(c_p3), eq_p4, ord_p5, &case_behind_f(cp_p0, c_p3));
    defs_p6.clone()
}

/// The step machine of `CaseCmpDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CaseCmpDefs: unbounded fn Cp, Text, Text, CaseDef, Bool, Bool -> Text
/// ```
pub struct CaseCmpDefs {
    pub cp_p0: crate::emit::cpp::Cp,
    pub gens_p1: crate::prelude::Text,
    pub head_p2: crate::prelude::Text,
    pub c_p3: crate::lower::model::CaseDef,
    pub eq_p4: bool,
    pub ord_p5: bool,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CaseCmpDefs {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let gens_p1 = &self.gens_p1;
        let head_p2 = &self.head_p2;
        let c_p3 = &self.c_p3;
        let eq_p4 = &self.eq_p4;
        let ord_p5 = &self.ord_p5;
        let c_p3x = c_p3.clone();
        let cp_p0x = cp_p0.clone();
        let eq_p4x = *eq_p4;
        let gens_p1x = gens_p1.clone();
        let head_p2x = head_p2.clone();
        let ord_p5x = *ord_p5;
        crate::prelude::call_then(start_case_behind_f(cp_p0x.clone(), c_p3x.clone()), move |case_behind_f_14009: bool| {
            let (_, defs_p6) = comparisons_f(&gens_p1x, &crate::prelude::Text::from(format!("{}::{}", &head_p2x, &c_p3x.name_p)), &c_p3x.name_p, &case_names_f(&c_p3x), &eq_p4x, &ord_p5x, &case_behind_f_14009);
            ::prism_rtl::Turn::Finished(defs_p6.clone())
        })
    }
}

/// `Start CaseCmpDefs, x`: what the function value is when passed to `@Run`.
pub fn start_case_cmp_defs_f(cp_p0: crate::emit::cpp::Cp, gens_p1: crate::prelude::Text, head_p2: crate::prelude::Text, c_p3: crate::lower::model::CaseDef, eq_p4: bool, ord_p5: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CaseCmpDefs { cp_p0, gens_p1, head_p2, c_p3, eq_p4, ord_p5 })
}

/// ```prism
/// CaseNames: fn CaseDef -> [Text]
/// ```
pub fn case_names_f(c_p0: &crate::lower::model::CaseDef) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&c_p0.fields_p)), &(|i_p1: &crate::prelude::Nat| crate::prelude::Text::from(format!("a{}", i_p1))))
}

/// ```prism
/// CaseBehind: unbounded fn Cp, CaseDef -> Bool
/// ```
pub fn case_behind_f(cp_p0: &crate::emit::cpp::Cp, c_p1: &crate::lower::model::CaseDef) -> bool {
    crate::prelude::run_to_end(crate::prelude::fold_job(c_p1.fields_p.clone(), false, {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::lower::model::OutTy))| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let f_p2 = p0;
                let (_, ft_p3) = p1;
                if f_p2 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(Behind { cp_p0: cp_p0xy.clone(), t_p1: ft_p3.clone() }))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::lower::model::OutTy))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `CaseBehind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CaseBehind: unbounded fn Cp, CaseDef -> Bool
/// ```
pub struct CaseBehind {
    pub cp_p0: crate::emit::cpp::Cp,
    pub c_p1: crate::lower::model::CaseDef,
}

impl ::prism_rtl::Job<bool> for CaseBehind {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let cp_p0 = &self.cp_p0;
        let c_p1 = &self.c_p1;
        crate::prelude::fold_job(c_p1.fields_p.clone(), false, {
            let cp_p0x = cp_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::lower::model::OutTy))| {
                let cp_p0xy = cp_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let f_p2 = p0;
                    let (_, ft_p3) = p1;
                    if f_p2 {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(Behind { cp_p0: cp_p0xy.clone(), t_p1: ft_p3.clone() }))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::lower::model::OutTy))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        }).cycle()
    }
}

/// `Start CaseBehind, x`: what the function value is when passed to `@Run`.
pub fn start_case_behind_f(cp_p0: crate::emit::cpp::Cp, c_p1: crate::lower::model::CaseDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(CaseBehind { cp_p0, c_p1 })
}

/// ```prism
/// TypeDefs: unbounded fn Cp, TyDef, Text -> Text
/// ```
pub fn type_defs_f(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::TyDef, head_p2: &crate::prelude::Text) -> crate::prelude::Text {
    let gens_p3 = cpp_template_head_f(&t_p1.params_p);
    let show_p4 = if &t_p1.show_p == &crate::lower::model::Shown::ShownDerived {
        crate::prelude::Array::from(vec![show_def_f(cp_p0, t_p1, head_p2, &gens_p3)])
    } else {
        crate::prelude::Array::new()
    };
    let pod_p5 = if t_p1.pod_p {
        crate::prelude::Array::from(vec![to_pod_def_f(cp_p0, t_p1, head_p2, &gens_p3), from_pod_def_f(cp_p0, t_p1, head_p2, &gens_p3)])
    } else {
        crate::prelude::Array::new()
    };
    crate::syntax::lexer::chars::join_f(&crate::prelude::append(&show_p4, &pod_p5), &crate::prelude::Text::lit("\n"))
}

/// The step machine of `TypeDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeDefs: unbounded fn Cp, TyDef, Text -> Text
/// ```
pub struct TypeDefs {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::TyDef,
    pub head_p2: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Text> for TypeDefs {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        let head_p2 = &self.head_p2;
        let gens_p3 = cpp_template_head_f(&t_p1.params_p);
        let cp_p0z = cp_p0.clone();
        let gens_p3z = gens_p3.clone();
        let head_p2z = head_p2.clone();
        let t_p1z = t_p1.clone();
        let k_let14442 = move |v14442: crate::prelude::Array<crate::prelude::Text>| {
            let show_p4 = v14442;
            let show_p4z = show_p4.clone();
            let k_let14527 = move |v14527: crate::prelude::Array<crate::prelude::Text>| {
                let pod_p5 = v14527;
                ::prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join_f(&crate::prelude::append(&show_p4z, &pod_p5), &crate::prelude::Text::lit("\n")))
            };
            if t_p1z.pod_p {
                crate::prelude::call_then(start_to_pod_def_f(cp_p0z.clone(), t_p1z.clone(), head_p2z.clone(), gens_p3z.clone()), move |to_pod_def_f_14550: crate::prelude::Text| crate::prelude::call_then(start_from_pod_def_f(cp_p0z.clone(), t_p1z.clone(), head_p2z.clone(), gens_p3z.clone()), move |from_pod_def_f_14580: crate::prelude::Text| k_let14527(crate::prelude::Array::from(vec![to_pod_def_f_14550, from_pod_def_f_14580]))))
            } else {
                k_let14527(crate::prelude::Array::new())
            }
        };
        if &t_p1.show_p == &crate::lower::model::Shown::ShownDerived {
            {
                let cp_p0x = cp_p0.clone();
                let head_p2x = head_p2.clone();
                let t_p1x = t_p1.clone();
                crate::prelude::call_then(start_show_def_f(cp_p0x.clone(), t_p1x.clone(), head_p2x.clone(), gens_p3.clone()), move |show_def_f_14483: crate::prelude::Text| k_let14442(crate::prelude::Array::from(vec![show_def_f_14483])))
            }
        } else {
            k_let14442(crate::prelude::Array::new())
        }
    }
}

/// `Start TypeDefs, x`: what the function value is when passed to `@Run`.
pub fn start_type_defs_f(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::TyDef, head_p2: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(TypeDefs { cp_p0, t_p1, head_p2 })
}

/// ```prism
/// ShowDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub fn show_def_f(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::TyDef, head_p2: &crate::prelude::Text, gens_p3: &crate::prelude::Text) -> crate::prelude::Text {
    let body_p4 = match &t_p1.shape_p {
        crate::lower::model::TyShape::ShapeRecord => {
            let c_p5 = crate::prelude::or(&crate::prelude::index(&t_p1.cases_p, &crate::prelude::Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() });
            crate::prelude::Text::from(format!("p.record(\"{}\", {{{}}});", &t_p1.prism_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&c_p5.fields_p, &(|(f_p6, _): &(crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("{{\"{}\", {}}}", &prism_field_of_f(&c_p5, f_p6), &crate::emit::cpp::field_id_f(f_p6))))), &crate::prelude::Text::lit(", "))))
        },
        crate::lower::model::TyShape::ShapeChoice => crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&t_p1.cases_p)), &(|i_p7: &crate::prelude::Nat| show_case_f(t_p1, i_p7))), &crate::prelude::Text::lit("\n")),
        crate::lower::model::TyShape::ShapeNewtype => crate::prelude::Text::from(format!("p.choice(\"{}\", {{{}}});", &first_case_f(t_p1), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::check::errors::range0_f(&first_arity_f(t_p1)), &(|k_p8: &crate::prelude::Nat| crate::prelude::Text::from(format!("a{}", k_p8)))), &crate::prelude::Text::lit(", ")))),
        crate::lower::model::TyShape::ShapeUnit => crate::prelude::Text::from(format!("p.choice(\"{}\", {{}});", &first_case_f(t_p1))),
    };
    crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("{}void {}::show(crate::prelude::Printer& p) const", gens_p3, head_p2)), &body_p4)
}

/// The step machine of `ShowDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub struct ShowDef {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::TyDef,
    pub head_p2: crate::prelude::Text,
    pub gens_p3: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Text> for ShowDef {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        let head_p2 = &self.head_p2;
        let gens_p3 = &self.gens_p3;
        let body_p4 = match &t_p1.shape_p {
            crate::lower::model::TyShape::ShapeRecord => {
                let c_p5 = crate::prelude::or(&crate::prelude::index(&t_p1.cases_p, &crate::prelude::Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() });
                crate::prelude::Text::from(format!("p.record(\"{}\", {{{}}});", &t_p1.prism_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&c_p5.fields_p, &(|(f_p6, _): &(crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("{{\"{}\", {}}}", &prism_field_of_f(&c_p5, f_p6), &crate::emit::cpp::field_id_f(f_p6))))), &crate::prelude::Text::lit(", "))))
            },
            crate::lower::model::TyShape::ShapeChoice => crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&t_p1.cases_p)), &(|i_p7: &crate::prelude::Nat| show_case_f(t_p1, i_p7))), &crate::prelude::Text::lit("\n")),
            crate::lower::model::TyShape::ShapeNewtype => crate::prelude::Text::from(format!("p.choice(\"{}\", {{{}}});", &first_case_f(t_p1), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::check::errors::range0_f(&first_arity_f(t_p1)), &(|k_p8: &crate::prelude::Nat| crate::prelude::Text::from(format!("a{}", k_p8)))), &crate::prelude::Text::lit(", ")))),
            crate::lower::model::TyShape::ShapeUnit => crate::prelude::Text::from(format!("p.choice(\"{}\", {{}});", &first_case_f(t_p1))),
        };
        ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("{}void {}::show(crate::prelude::Printer& p) const", gens_p3, head_p2)), &body_p4))
    }
}

/// `Start ShowDef, x`: what the function value is when passed to `@Run`.
pub fn start_show_def_f(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::TyDef, head_p2: crate::prelude::Text, gens_p3: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(ShowDef { cp_p0, t_p1, head_p2, gens_p3 })
}

/// ```prism
/// ShowCase: fn TyDef, Nat -> Text
/// ```
pub fn show_case_f(t_p0: &crate::lower::model::TyDef, i_p1: &crate::prelude::Nat) -> crate::prelude::Text {
    let c_p2 = crate::prelude::or(&crate::prelude::index(&t_p0.cases_p, i_p1), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() });
    let head_p3 = crate::prelude::Text::from(format!("{} (auto c = ::std::get_if<{}>(&cases()))", &(if i_p1 == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::lit("if")
    } else {
        crate::prelude::Text::lit("else if")
    }), &c_p2.name_p));
    crate::prelude::Text::from(format!("{} p.choice(\"{}\", {{{}}});", &head_p3, &c_p2.prism_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&c_p2.fields_p)), &(|k_p4: &crate::prelude::Nat| crate::prelude::Text::from(format!("c->a{}", k_p4)))), &crate::prelude::Text::lit(", "))))
}

/// ```prism
/// FirstCase: fn TyDef -> Text
/// ```
pub fn first_case_f(t_p0: &crate::lower::model::TyDef) -> crate::prelude::Text {
    crate::prelude::or(&crate::prelude::index(&t_p0.cases_p, &crate::prelude::Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: t_p0.prism_p.clone(), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() }).prism_p.clone()
}

/// ```prism
/// FirstArity: fn TyDef -> Nat
/// ```
pub fn first_arity_f(t_p0: &crate::lower::model::TyDef) -> crate::prelude::Nat {
    crate::prelude::len(&crate::prelude::or(&crate::prelude::index(&t_p0.cases_p, &crate::prelude::Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() }).fields_p)
}

/// ```prism
/// FieldTypes: fn [((Text, OutTy))] -> [OutTy]
/// ```
pub fn field_types_f(fs_p0: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>) -> crate::prelude::Array<crate::lower::model::OutTy> {
    crate::prelude::each(fs_p0, &(|(_, t_p1): &(crate::prelude::Text, crate::lower::model::OutTy)| t_p1.clone()))
}

/// ```prism
/// PositionalFields: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub fn positional_fields_f(cp_p0: &crate::emit::cpp::Cp, fs_p1: &crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>) -> crate::prelude::Text {
    let tys_p2 = field_types_f(fs_p1);
    crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&tys_p2)), {
        let cp_p0x = cp_p0.clone();
        let tys_p2x = tys_p2.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
            let cp_p0xy = cp_p0x.clone();
            let tys_p2xy = tys_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_p3 = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), crate::prelude::or(&crate::prelude::index(&tys_p2xy, &i_p3), &crate::lower::model::OutTy::OutUnit)), move |cpp_type_f_16275: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} a{};", &cpp_type_f_16275, &i_p3))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    })), &crate::prelude::Text::lit("\n"))
}

/// The step machine of `PositionalFields`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PositionalFields: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub struct PositionalFields {
    pub cp_p0: crate::emit::cpp::Cp,
    pub fs_p1: crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for PositionalFields {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let fs_p1 = &self.fs_p1;
        let tys_p2 = field_types_f(fs_p1);
        let cp_p0x = cp_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&tys_p2)), {
            let cp_p0xx = cp_p0x.clone();
            let tys_p2x = tys_p2.clone();
            ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                let cp_p0xxy = cp_p0xx.clone();
                let tys_p2xy = tys_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let i_p3 = p0;
                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), crate::prelude::or(&crate::prelude::index(&tys_p2xy, &i_p3), &crate::lower::model::OutTy::OutUnit)), move |cpp_type_f_16275: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} a{};", &cpp_type_f_16275, &i_p3))))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
        }), move |each_16243: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join_f(&each_16243, &crate::prelude::Text::lit("\n"))))
    }
}

/// `Start PositionalFields, x`: what the function value is when passed to `@Run`.
pub fn start_positional_fields_f(cp_p0: crate::emit::cpp::Cp, fs_p1: crate::prelude::Array<(crate::prelude::Text, crate::lower::model::OutTy)>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(PositionalFields { cp_p0, fs_p1 })
}

/// ```prism
/// ToPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub fn to_pod_def_f(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::TyDef, head_p2: &crate::prelude::Text, gens_p3: &crate::prelude::Text) -> crate::prelude::Text {
    let structure_p4 = match &t_p1.shape_p {
        crate::lower::model::TyShape::ShapeRecord => {
            let c_p6 = crate::prelude::or(&crate::prelude::index(&t_p1.cases_p, &crate::prelude::Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() });
            crate::prelude::Text::from(format!("crate::prelude::Pod::record(\"{}\", {{{}}})", &t_p1.prism_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&c_p6.fields_p, &(|(f_p7, _): &(crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("{{\"{}\", ::prism_rtl::to_pod({})}}", &prism_field_of_f(&c_p6, f_p7), &crate::emit::cpp::field_id_f(f_p7))))), &crate::prelude::Text::lit(", "))))
        },
        crate::lower::model::TyShape::ShapeChoice => choice_pod_f(t_p1),
        crate::lower::model::TyShape::ShapeNewtype => crate::prelude::Text::from(format!("crate::prelude::Pod::choice(\"{}\", {{{}}})", &first_case_f(t_p1), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::check::errors::range0_f(&first_arity_f(t_p1)), &(|k_p8: &crate::prelude::Nat| crate::prelude::Text::from(format!("::prism_rtl::to_pod(a{})", k_p8)))), &crate::prelude::Text::lit(", ")))),
        crate::lower::model::TyShape::ShapeUnit => crate::prelude::Text::from(format!("crate::prelude::Pod::choice(\"{}\", {{}})", &first_case_f(t_p1))),
    };
    let body_p5 = if &t_p1.show_p == &crate::lower::model::Shown::ShownOwn {
        crate::prelude::Text::from(format!("crate::prelude::Pod structure = {};\nreturn crate::prelude::Pod::shown(::prism_rtl::show(*this), structure);", &structure_p4))
    } else {
        crate::prelude::Text::from(format!("return {};", &structure_p4))
    };
    crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("{}crate::prelude::Pod {}::to_pod() const", gens_p3, head_p2)), &body_p5)
}

/// The step machine of `ToPodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ToPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub struct ToPodDef {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::TyDef,
    pub head_p2: crate::prelude::Text,
    pub gens_p3: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Text> for ToPodDef {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        let head_p2 = &self.head_p2;
        let gens_p3 = &self.gens_p3;
        let structure_p4 = match &t_p1.shape_p {
            crate::lower::model::TyShape::ShapeRecord => {
                let c_p6 = crate::prelude::or(&crate::prelude::index(&t_p1.cases_p, &crate::prelude::Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() });
                crate::prelude::Text::from(format!("crate::prelude::Pod::record(\"{}\", {{{}}})", &t_p1.prism_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&c_p6.fields_p, &(|(f_p7, _): &(crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("{{\"{}\", ::prism_rtl::to_pod({})}}", &prism_field_of_f(&c_p6, f_p7), &crate::emit::cpp::field_id_f(f_p7))))), &crate::prelude::Text::lit(", "))))
            },
            crate::lower::model::TyShape::ShapeChoice => choice_pod_f(t_p1),
            crate::lower::model::TyShape::ShapeNewtype => crate::prelude::Text::from(format!("crate::prelude::Pod::choice(\"{}\", {{{}}})", &first_case_f(t_p1), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::check::errors::range0_f(&first_arity_f(t_p1)), &(|k_p8: &crate::prelude::Nat| crate::prelude::Text::from(format!("::prism_rtl::to_pod(a{})", k_p8)))), &crate::prelude::Text::lit(", ")))),
            crate::lower::model::TyShape::ShapeUnit => crate::prelude::Text::from(format!("crate::prelude::Pod::choice(\"{}\", {{}})", &first_case_f(t_p1))),
        };
        let body_p5 = if &t_p1.show_p == &crate::lower::model::Shown::ShownOwn {
            crate::prelude::Text::from(format!("crate::prelude::Pod structure = {};\nreturn crate::prelude::Pod::shown(::prism_rtl::show(*this), structure);", &structure_p4))
        } else {
            crate::prelude::Text::from(format!("return {};", &structure_p4))
        };
        ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("{}crate::prelude::Pod {}::to_pod() const", gens_p3, head_p2)), &body_p5))
    }
}

/// `Start ToPodDef, x`: what the function value is when passed to `@Run`.
pub fn start_to_pod_def_f(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::TyDef, head_p2: crate::prelude::Text, gens_p3: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(ToPodDef { cp_p0, t_p1, head_p2, gens_p3 })
}

/// ```prism
/// ChoicePod: fn TyDef -> Text
/// ```
pub fn choice_pod_f(t_p0: &crate::lower::model::TyDef) -> crate::prelude::Text {
    let arms_p1 = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&t_p0.cases_p)), &(|i_p2: &crate::prelude::Nat| {
        let c_p3 = crate::prelude::or(&crate::prelude::index(&t_p0.cases_p, i_p2), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() });
        crate::prelude::Text::from(format!("::std::holds_alternative<{}>(cases()) ? crate::prelude::Pod::choice_at(\"{}\", {}, {{{}}})", &c_p3.name_p, &c_p3.prism_p, i_p2, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&c_p3.fields_p)), &(|k_p4: &crate::prelude::Nat| crate::prelude::Text::from(format!("::prism_rtl::to_pod(::std::get<{}>(cases()).a{})", &c_p3.name_p, k_p4)))), &crate::prelude::Text::lit(", "))))
    }));
    crate::prelude::Text::from(format!("{}\n    : crate::prelude::Pod()", &crate::syntax::lexer::chars::join_f(&arms_p1, &crate::prelude::Text::lit("\n    : "))))
}

/// ```prism
/// FromPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub fn from_pod_def_f(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::TyDef, head_p2: &crate::prelude::Text, gens_p3: &crate::prelude::Text) -> crate::prelude::Text {
    let body_p4 = match &t_p1.shape_p {
        crate::lower::model::TyShape::ShapeRecord => {
            let c_p5 = crate::prelude::or(&crate::prelude::index(&t_p1.cases_p, &crate::prelude::Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() });
            let reads_p6 = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(c_p5.fields_p.clone(), {
                let cp_p0x = cp_p0.clone();
                let c_p5x = c_p5.clone();
                ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| {
                    let cp_p0xy = cp_p0x.clone();
                    let c_p5xy = c_p5x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (f_p7, ft_p8) = p0;
                        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), ft_p8.clone()), move |cpp_type_f_18041: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!(".{} = TRY(::prism_rtl::from_pod<{}>(TRY(crate::prelude::field(whole, \"{}\"))))", &crate::emit::cpp::field_id_f(&f_p7), &cpp_type_f_18041, &prism_field_of_f(&c_p5xy, &f_p7)))))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            })), &crate::prelude::Text::lit(", "));
            crate::prelude::Text::from(format!("return {}{{{}}};", head_p2, &reads_p6))
        },
        _ => {
            let arms_p9 = crate::prelude::run_to_end(crate::prelude::each_job(t_p1.cases_p.clone(), {
                let cp_p0x = cp_p0.clone();
                let t_p1x = t_p1.clone();
                let head_p2x = head_p2.clone();
                ::std::rc::Rc::new(move |p0: crate::lower::model::CaseDef| {
                    let cp_p0xy = cp_p0x.clone();
                    let t_p1xy = t_p1x.clone();
                    let head_p2xy = head_p2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let c_pa = p0;
                        {
                            let n_pb = crate::prelude::len(&c_pa.fields_p);
                            let tys_pc = field_types_f(&c_pa.fields_p);
                            crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&n_pb), {
                                let cp_p0xyx = cp_p0xy.clone();
                                let tys_pcx = tys_pc.clone();
                                ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                                    let cp_p0xyxy = cp_p0xyx.clone();
                                    let tys_pcxy = tys_pcx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let i_pf = p0;
                                        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xyxy.clone(), crate::prelude::or(&crate::prelude::index(&tys_pcxy, &i_pf), &crate::lower::model::OutTy::OutUnit)), move |cpp_type_f_18394: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("TRY(::prism_rtl::from_pod<{}>(c->args[{}]))", &cpp_type_f_18394, &i_pf))))
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                            }), move |each_18344: crate::prelude::Array<crate::prelude::Text>| {
                                let args_pd = crate::syntax::lexer::chars::join_f(&each_18344, &crate::prelude::Text::lit(", "));
                                let made_pe = match &t_p1xy.shape_p {
                                    crate::lower::model::TyShape::ShapeChoice => crate::prelude::Text::from(format!("{}({}{{{}}})", &head_p2xy, &c_pa.name_p, &args_pd)),
                                    _ => crate::prelude::Text::from(format!("{}{{{}}}", &head_p2xy, &args_pd)),
                                };
                                ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("if (c->ctor == \"{}\" && c->args.size() == {}) return {};", &c_pa.prism_p, &n_pb, &made_pe)))
                            })
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::CaseDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            }));
            crate::prelude::Text::from(format!("const crate::prelude::Pod& p = whole.structure();\nif (auto c = p.if_choice()) {{\n{}\n}}\nreturn crate::prelude::mismatch<{}>(\"a {}\", p);", &indent_cpp_f(&crate::syntax::lexer::chars::join_f(&arms_p9, &crate::prelude::Text::lit("\n"))), head_p2, &t_p1.prism_p))
        },
    };
    crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("{}crate::prelude::Result<{}> {}::from_pod(const crate::prelude::Pod& whole)", gens_p3, head_p2, head_p2)), &body_p4)
}

/// The step machine of `FromPodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FromPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub struct FromPodDef {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::TyDef,
    pub head_p2: crate::prelude::Text,
    pub gens_p3: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Text> for FromPodDef {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        let head_p2 = &self.head_p2;
        let gens_p3 = &self.gens_p3;
        let gens_p3z = gens_p3.clone();
        let head_p2z = head_p2.clone();
        let k_let17803 = move |v17803: crate::prelude::Text| {
            let body_p4 = v17803;
            ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("{}crate::prelude::Result<{}> {}::from_pod(const crate::prelude::Pod& whole)", &gens_p3z, &head_p2z, &head_p2z)), &body_p4))
        };
        match t_p1.shape_p.clone() {
            crate::lower::model::TyShape::ShapeRecord => {
                let c_p5 = crate::prelude::or(&crate::prelude::index(&t_p1.cases_p, &crate::prelude::Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() });
                let cp_p0x = cp_p0.clone();
                let head_p2x = head_p2.clone();
                crate::prelude::call_value(crate::prelude::each_job(c_p5.fields_p.clone(), {
                    let cp_p0xx = cp_p0x.clone();
                    let c_p5x = c_p5.clone();
                    ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| {
                        let cp_p0xxy = cp_p0xx.clone();
                        let c_p5xy = c_p5x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (f_p7, ft_p8) = p0;
                            crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), ft_p8.clone()), move |cpp_type_f_18041: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!(".{} = TRY(::prism_rtl::from_pod<{}>(TRY(crate::prelude::field(whole, \"{}\"))))", &crate::emit::cpp::field_id_f(&f_p7), &cpp_type_f_18041, &prism_field_of_f(&c_p5xy, &f_p7)))))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                }), move |each_17970: crate::prelude::Array<crate::prelude::Text>| {
                    let reads_p6 = crate::syntax::lexer::chars::join_f(&each_17970, &crate::prelude::Text::lit(", "));
                    k_let17803(crate::prelude::Text::from(format!("return {}{{{}}};", &head_p2x, &reads_p6)))
                })
            },
            _ => {
                let cp_p0x = cp_p0.clone();
                let head_p2x = head_p2.clone();
                let t_p1x = t_p1.clone();
                crate::prelude::call_value(crate::prelude::each_job(t_p1x.cases_p.clone(), {
                    let cp_p0xx = cp_p0x.clone();
                    let t_p1xx = t_p1x.clone();
                    let head_p2xx = head_p2x.clone();
                    ::std::rc::Rc::new(move |p0: crate::lower::model::CaseDef| {
                        let cp_p0xxy = cp_p0xx.clone();
                        let t_p1xxy = t_p1xx.clone();
                        let head_p2xxy = head_p2xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let c_pa = p0;
                            {
                                let n_pb = crate::prelude::len(&c_pa.fields_p);
                                let tys_pc = field_types_f(&c_pa.fields_p);
                                crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&n_pb), {
                                    let cp_p0xxyx = cp_p0xxy.clone();
                                    let tys_pcx = tys_pc.clone();
                                    ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                                        let cp_p0xxyxy = cp_p0xxyx.clone();
                                        let tys_pcxy = tys_pcx.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let i_pf = p0;
                                            crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxyxy.clone(), crate::prelude::or(&crate::prelude::index(&tys_pcxy, &i_pf), &crate::lower::model::OutTy::OutUnit)), move |cpp_type_f_18394: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("TRY(::prism_rtl::from_pod<{}>(c->args[{}]))", &cpp_type_f_18394, &i_pf))))
                                        }))
                                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                                }), move |each_18344: crate::prelude::Array<crate::prelude::Text>| {
                                    let args_pd = crate::syntax::lexer::chars::join_f(&each_18344, &crate::prelude::Text::lit(", "));
                                    let made_pe = match &t_p1xxy.shape_p {
                                        crate::lower::model::TyShape::ShapeChoice => crate::prelude::Text::from(format!("{}({}{{{}}})", &head_p2xxy, &c_pa.name_p, &args_pd)),
                                        _ => crate::prelude::Text::from(format!("{}{{{}}}", &head_p2xxy, &args_pd)),
                                    };
                                    ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("if (c->ctor == \"{}\" && c->args.size() == {}) return {};", &c_pa.prism_p, &n_pb, &made_pe)))
                                })
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::CaseDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                }), move |each_18209: crate::prelude::Array<crate::prelude::Text>| {
                    let arms_p9 = each_18209;
                    k_let17803(crate::prelude::Text::from(format!("const crate::prelude::Pod& p = whole.structure();\nif (auto c = p.if_choice()) {{\n{}\n}}\nreturn crate::prelude::mismatch<{}>(\"a {}\", p);", &indent_cpp_f(&crate::syntax::lexer::chars::join_f(&arms_p9, &crate::prelude::Text::lit("\n"))), &head_p2x, &t_p1x.prism_p)))
                })
            },
        }
    }
}

/// `Start FromPodDef, x`: what the function value is when passed to `@Run`.
pub fn start_from_pod_def_f(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::TyDef, head_p2: crate::prelude::Text, gens_p3: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(FromPodDef { cp_p0, t_p1, head_p2, gens_p3 })
}

/// ```prism
/// PrismField: fn Text -> Text
/// ```
pub fn prism_field_f(f_p0: &crate::prelude::Text) -> crate::prelude::Text {
    if &crate::syntax::lexer::chars::last_char_f(f_p0) == &crate::prelude::Text::lit("_") {
        crate::syntax::lexer::chars::before_last_f(f_p0)
    } else {
        f_p0.clone()
    }
}

/// ```prism
/// PrismFieldOf: fn CaseDef, Text -> Text
/// ```
pub fn prism_field_of_f(c_p0: &crate::lower::model::CaseDef, f_p1: &crate::prelude::Text) -> crate::prelude::Text {
    crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&c_p0.fields_p)), &prism_field_f(f_p1), &(|found_p2: &crate::prelude::Text, i_p3: &crate::prelude::Nat| match (crate::prelude::index(&c_p0.fields_p, i_p3), crate::prelude::index(&c_p0.labels_p, i_p3)) {
        (::std::option::Option::Some((g_p4, _)), ::std::option::Option::Some(label_p5)) => if &g_p4 == f_p1 { label_p5 } else { found_p2.clone() },
        _ => found_p2.clone(),
    }))
}

/// ```prism
/// IndentCpp: fn Text -> Text
/// ```
pub fn indent_cpp_f(t_p0: &crate::prelude::Text) -> crate::prelude::Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::prelude::split_on(t_p0, &crate::prelude::Text::lit("\n")), &(|l_p1: &crate::prelude::Text| if l_p1 == &crate::prelude::Text::lit("") {
        crate::prelude::Text::lit("")
    } else {
        crate::prelude::Text::from(format!("    {}", l_p1))
    })), &crate::prelude::Text::lit("\n"))
}

/// ```prism
/// TagParts: unbounded fn Cp, TagDef -> Parts
/// ```
pub fn tag_parts_f(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::TagDef) -> Parts {
    let fields_p2 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::run_to_end(crate::prelude::each_job(t_p1.fields_p.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (_, f_ph, ft_pi) = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), ft_pi.clone()), move |cpp_type_f_19817: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {};", &cpp_type_f_19817, &crate::emit::cpp::field_id_f(&f_ph)))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    })), &crate::prelude::run_to_end(crate::prelude::each_job(t_p1.events_p.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (f_pj, et_pk) = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(et_pk.clone()))), move |cpp_type_f_19880: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {};", &cpp_type_f_19880, &crate::emit::cpp::field_id_f(&f_pj)))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    }))), &crate::prelude::Text::lit("\n"));
    let pods_p3 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&t_p1.fields_p, &(|(p_pl, f_pm, _): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("{{\"{}\", ::prism_rtl::to_pod({})}}", p_pl, &crate::emit::cpp::field_id_f(f_pm))))), &crate::prelude::Text::lit(", "));
    let reads_p4 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::run_to_end(crate::prelude::each_job(t_p1.fields_p.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (p_pn, f_po, ft_pp) = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), ft_pp.clone()), move |cpp_type_f_20228: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!(".{} = TRY(::prism_rtl::from_pod<{}>(TRY(crate::prelude::field(p, \"{}\"))))", &crate::emit::cpp::field_id_f(&f_po), &cpp_type_f_20228, &p_pn))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    })), &crate::prelude::run_to_end(crate::prelude::each_job(t_p1.events_p.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (f_pq, et_pr) = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(et_pr.clone()))), move |cpp_type_f_20335: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!(".{} = {}::never()", &crate::emit::cpp::field_id_f(&f_pq), &cpp_type_f_20335))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    }))), &crate::prelude::Text::lit(", "));
    let eq_p5 = if t_p1.eq_p {
        crate::prelude::Text::from(format!("bool operator==(const {}&) const = default;", &t_p1.name_p))
    } else {
        crate::prelude::Text::lit("")
    };
    let back_p6 = if t_p1.pod_p {
        crate::prelude::Text::from(format!("static crate::prelude::Result<{}> from_pod(const crate::prelude::Pod& p);", &t_p1.name_p))
    } else {
        crate::prelude::Text::lit("")
    };
    let deep_p7 = crate::prelude::run_to_end(crate::prelude::fold_job(t_p1.fields_p.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy))| crate::prelude::entered(crate::prelude::once_job(move || {
        let d_ps = p0;
        let (_, _, ft_pt) = p1;
        if d_ps {
            ::prism_rtl::Turn::Finished(true)
        } else {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::HoldsDyn { t_p0: ft_pt.clone() }))
        }
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>));
    let level_decl_p8 = if deep_p7 {
        crate::prelude::Text::lit("/// The level as a World reads it: each dynamic it holds sampled at the read point.\ncrate::prelude::Pod level_pod(const crate::prelude::Cx& cx) const;\n/// The update events of the dynamics it holds, and of theirs.\nvoid level_ports(const crate::prelude::Cx& cx, ::std::vector<::prism_rtl::Rc<::prism_rtl::Port<crate::prelude::Unit>>>& out) const;")
    } else {
        crate::prelude::Text::lit("")
    };
    let decl_p9 = crate::emit::cpp::templates::items::cpp_tag_struct_f(&cpp_source_doc_f(&crate::prelude::Text::from(format!("The `Level` of `{}`:", &t_p1.tag_name_p)), &t_p1.doc_p), &t_p1.name_p, &fields_p2, &t_p1.tag_name_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::Array::from(vec![eq_p5.clone(), back_p6.clone(), level_decl_p8.clone()]), &(|s_pu: &crate::prelude::Text| s_pu != &crate::prelude::Text::lit(""))), &crate::prelude::Text::lit("\n")));
    let deep_pods_pa = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(t_p1.fields_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (p_pv, f_p10, ft_p11) = p0;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(CppDeepField { p_p0: p_pv.clone(), f_p1: f_p10.clone(), ft_p2: ft_p11.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit(", "));
    let deep_ports_pb = crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::run_to_end(crate::prelude::each_job(t_p1.fields_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (_, f_p12, ft_p13) = p0;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(CppDeepPorts { f_p0: f_p12.clone(), ft_p1: ft_p13.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &(|s_p14: &crate::prelude::Text| s_p14 != &crate::prelude::Text::lit(""))), &crate::prelude::Text::lit("\n"));
    let level_defs_pc = if deep_p7 {
        crate::prelude::Array::from(vec![crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("crate::prelude::Pod {}::level_pod(const crate::prelude::Cx& cx) const", &t_p1.name_p)), &crate::prelude::Text::from(format!("static_cast<void>(cx);\nreturn crate::prelude::Pod::element(TAG, {{{}}});", &deep_pods_pa))), crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("void {}::level_ports(const crate::prelude::Cx& cx, ::std::vector<::prism_rtl::Rc<::prism_rtl::Port<crate::prelude::Unit>>>& out) const", &t_p1.name_p)), &crate::prelude::Text::from(format!("static_cast<void>(cx);\nstatic_cast<void>(out);{}", &(if &deep_ports_pb == &crate::prelude::Text::lit("") {
            crate::prelude::Text::lit("")
        } else {
            crate::prelude::Text::from(format!("\n{}", &deep_ports_pb))
        }))))])
    } else {
        crate::prelude::Array::new()
    };
    let to_pod_pd = crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("crate::prelude::Pod {}::to_pod() const", &t_p1.name_p)), &crate::prelude::Text::from(format!("return crate::prelude::Pod::element(TAG, {{{}}});", &pods_p3)));
    let show_pe = crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("void {}::show(crate::prelude::Printer& p) const", &t_p1.name_p)), &crate::prelude::Text::lit("::prism_rtl::to_pod(*this).structure();\ncrate::prelude::Show<crate::prelude::Pod>::show(::prism_rtl::to_pod(*this), p);"));
    let from_pod_pf = if t_p1.pod_p {
        crate::prelude::Array::from(vec![crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("crate::prelude::Result<{}> {}::from_pod(const crate::prelude::Pod& p)", &t_p1.name_p, &t_p1.name_p)), &crate::prelude::Text::from(format!("if (auto t = p.tag(); t && *t == TAG) return {}{{{}}};\nreturn crate::prelude::mismatch<{}>(\"a {}\", p);", &t_p1.name_p, &reads_p4, &t_p1.name_p, &t_p1.tag_name_p)))])
    } else {
        crate::prelude::Array::new()
    };
    let deps_pg = crate::emit::cpp::patterns::concat2_f(&crate::prelude::append(&crate::prelude::run_to_end(crate::prelude::each_job(t_p1.fields_p.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (_, _, ft_p15) = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(ValueDeps { cp_p0: cp_p0xy.clone(), t_p1: ft_p15.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
    })), &crate::prelude::run_to_end(crate::prelude::each_job(t_p1.events_p.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (_, et_p16) = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(ValueDeps { cp_p0: cp_p0xy.clone(), t_p1: et_p16.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
    }))));
    Parts { forward_p: crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("struct {};", &t_p1.name_p))]), values_p: crate::prelude::Array::from(vec![ValueDecl { path_p: decl_path_f(cp_p0, &t_p1.name_p), deps_p: deps_pg.clone(), text_p: decl_p9.clone() }]), protos_p: crate::prelude::Array::new(), classes_p: crate::prelude::Array::new(), outer_p: crate::prelude::Array::new(), generic_p: crate::prelude::Array::new(), defs_p: crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![to_pod_pd.clone(), show_pe.clone()]), &from_pod_pf), &level_defs_pc) }
}

/// The step machine of `TagParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagParts: unbounded fn Cp, TagDef -> Parts
/// ```
pub struct TagParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::TagDef,
}

impl ::prism_rtl::Job<Parts> for TagParts {
    fn cycle(&self) -> ::prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        let cp_p0x = cp_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(t_p1x.fields_p.clone(), {
            let cp_p0xx = cp_p0x.clone();
            ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (_, f_ph, ft_pi) = p0;
                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), ft_pi.clone()), move |cpp_type_f_19817: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {};", &cpp_type_f_19817, &crate::emit::cpp::field_id_f(&f_ph)))))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
        }), move |each_19779: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_value(crate::prelude::each_job(t_p1x.events_p.clone(), {
            let cp_p0xx = cp_p0x.clone();
            ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (f_pj, et_pk) = p0;
                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(et_pk.clone()))), move |cpp_type_f_19880: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {};", &cpp_type_f_19880, &crate::emit::cpp::field_id_f(&f_pj)))))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
        }), move |each_19850: crate::prelude::Array<crate::prelude::Text>| {
            let fields_p2 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&each_19779, &each_19850), &crate::prelude::Text::lit("\n"));
            let pods_p3 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&t_p1x.fields_p, &(|(p_pl, f_pm, _): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("{{\"{}\", ::prism_rtl::to_pod({})}}", p_pl, &crate::emit::cpp::field_id_f(f_pm))))), &crate::prelude::Text::lit(", "));
            crate::prelude::call_value(crate::prelude::each_job(t_p1x.fields_p.clone(), {
                let cp_p0xx = cp_p0x.clone();
                ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| {
                    let cp_p0xxy = cp_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (p_pn, f_po, ft_pp) = p0;
                        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), ft_pp.clone()), move |cpp_type_f_20228: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!(".{} = TRY(::prism_rtl::from_pod<{}>(TRY(crate::prelude::field(p, \"{}\"))))", &crate::emit::cpp::field_id_f(&f_po), &cpp_type_f_20228, &p_pn))))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            }), move |each_20154: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_value(crate::prelude::each_job(t_p1x.events_p.clone(), {
                let cp_p0xx = cp_p0x.clone();
                ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| {
                    let cp_p0xxy = cp_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (f_pq, et_pr) = p0;
                        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(et_pr.clone()))), move |cpp_type_f_20335: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!(".{} = {}::never()", &crate::emit::cpp::field_id_f(&f_pq), &cpp_type_f_20335))))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            }), move |each_20290: crate::prelude::Array<crate::prelude::Text>| {
                let reads_p4 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&each_20154, &each_20290), &crate::prelude::Text::lit(", "));
                let eq_p5 = if t_p1x.eq_p {
                    crate::prelude::Text::from(format!("bool operator==(const {}&) const = default;", &t_p1x.name_p))
                } else {
                    crate::prelude::Text::lit("")
                };
                let back_p6 = if t_p1x.pod_p {
                    crate::prelude::Text::from(format!("static crate::prelude::Result<{}> from_pod(const crate::prelude::Pod& p);", &t_p1x.name_p))
                } else {
                    crate::prelude::Text::lit("")
                };
                crate::prelude::call_value(crate::prelude::fold_job(t_p1x.fields_p.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy))| crate::prelude::entered(crate::prelude::once_job(move || {
                    let d_ps = p0;
                    let (_, _, ft_pt) = p1;
                    if d_ps {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::HoldsDyn { t_p0: ft_pt.clone() }))
                    }
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>), move |fold_20665: bool| {
                    let deep_p7 = fold_20665;
                    let level_decl_p8 = if deep_p7 {
                        crate::prelude::Text::lit("/// The level as a World reads it: each dynamic it holds sampled at the read point.\ncrate::prelude::Pod level_pod(const crate::prelude::Cx& cx) const;\n/// The update events of the dynamics it holds, and of theirs.\nvoid level_ports(const crate::prelude::Cx& cx, ::std::vector<::prism_rtl::Rc<::prism_rtl::Port<crate::prelude::Unit>>>& out) const;")
                    } else {
                        crate::prelude::Text::lit("")
                    };
                    let decl_p9 = crate::emit::cpp::templates::items::cpp_tag_struct_f(&cpp_source_doc_f(&crate::prelude::Text::from(format!("The `Level` of `{}`:", &t_p1x.tag_name_p)), &t_p1x.doc_p), &t_p1x.name_p, &fields_p2, &t_p1x.tag_name_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::Array::from(vec![eq_p5.clone(), back_p6.clone(), level_decl_p8.clone()]), &(|s_pu: &crate::prelude::Text| s_pu != &crate::prelude::Text::lit(""))), &crate::prelude::Text::lit("\n")));
                    crate::prelude::call_value(crate::prelude::each_job(t_p1x.fields_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
                        let (p_pv, f_p10, ft_p11) = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(CppDeepField { p_p0: p_pv.clone(), f_p1: f_p10.clone(), ft_p2: ft_p11.clone() }))
                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_21317: crate::prelude::Array<crate::prelude::Text>| {
                        let deep_pods_pa = crate::syntax::lexer::chars::join_f(&each_21317, &crate::prelude::Text::lit(", "));
                        crate::prelude::call_value(crate::prelude::each_job(t_p1x.fields_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
                            let (_, f_p12, ft_p13) = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(CppDeepPorts { f_p0: f_p12.clone(), ft_p1: ft_p13.clone() }))
                        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_21411: crate::prelude::Array<crate::prelude::Text>| {
                            let deep_ports_pb = crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&each_21411, &(|s_p14: &crate::prelude::Text| s_p14 != &crate::prelude::Text::lit(""))), &crate::prelude::Text::lit("\n"));
                            let level_defs_pc = if deep_p7 {
                                crate::prelude::Array::from(vec![crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("crate::prelude::Pod {}::level_pod(const crate::prelude::Cx& cx) const", &t_p1x.name_p)), &crate::prelude::Text::from(format!("static_cast<void>(cx);\nreturn crate::prelude::Pod::element(TAG, {{{}}});", &deep_pods_pa))), crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("void {}::level_ports(const crate::prelude::Cx& cx, ::std::vector<::prism_rtl::Rc<::prism_rtl::Port<crate::prelude::Unit>>>& out) const", &t_p1x.name_p)), &crate::prelude::Text::from(format!("static_cast<void>(cx);\nstatic_cast<void>(out);{}", &(if &deep_ports_pb == &crate::prelude::Text::lit("") {
                                    crate::prelude::Text::lit("")
                                } else {
                                    crate::prelude::Text::from(format!("\n{}", &deep_ports_pb))
                                }))))])
                            } else {
                                crate::prelude::Array::new()
                            };
                            let to_pod_pd = crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("crate::prelude::Pod {}::to_pod() const", &t_p1x.name_p)), &crate::prelude::Text::from(format!("return crate::prelude::Pod::element(TAG, {{{}}});", &pods_p3)));
                            let show_pe = crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("void {}::show(crate::prelude::Printer& p) const", &t_p1x.name_p)), &crate::prelude::Text::lit("::prism_rtl::to_pod(*this).structure();\ncrate::prelude::Show<crate::prelude::Pod>::show(::prism_rtl::to_pod(*this), p);"));
                            let from_pod_pf = if t_p1x.pod_p {
                                crate::prelude::Array::from(vec![crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("crate::prelude::Result<{}> {}::from_pod(const crate::prelude::Pod& p)", &t_p1x.name_p, &t_p1x.name_p)), &crate::prelude::Text::from(format!("if (auto t = p.tag(); t && *t == TAG) return {}{{{}}};\nreturn crate::prelude::mismatch<{}>(\"a {}\", p);", &t_p1x.name_p, &reads_p4, &t_p1x.name_p, &t_p1x.tag_name_p)))])
                            } else {
                                crate::prelude::Array::new()
                            };
                            crate::prelude::call_value(crate::prelude::each_job(t_p1x.fields_p.clone(), {
                                let cp_p0xx = cp_p0x.clone();
                                ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| {
                                    let cp_p0xxy = cp_p0xx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let (_, _, ft_p15) = p0;
                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(ValueDeps { cp_p0: cp_p0xxy.clone(), t_p1: ft_p15.clone() }))
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                            }), move |each_22631: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| crate::prelude::call_value(crate::prelude::each_job(t_p1x.events_p.clone(), {
                                let cp_p0xx = cp_p0x.clone();
                                ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| {
                                    let cp_p0xxy = cp_p0xx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let (_, et_p16) = p0;
                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(ValueDeps { cp_p0: cp_p0xxy.clone(), t_p1: et_p16.clone() }))
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                            }), move |each_22692: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| {
                                let deps_pg = crate::emit::cpp::patterns::concat2_f(&crate::prelude::append(&each_22631, &each_22692));
                                ::prism_rtl::Turn::Finished(Parts { forward_p: crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("struct {};", &t_p1x.name_p))]), values_p: crate::prelude::Array::from(vec![ValueDecl { path_p: decl_path_f(&cp_p0x, &t_p1x.name_p), deps_p: deps_pg.clone(), text_p: decl_p9.clone() }]), protos_p: crate::prelude::Array::new(), classes_p: crate::prelude::Array::new(), outer_p: crate::prelude::Array::new(), generic_p: crate::prelude::Array::new(), defs_p: crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![to_pod_pd.clone(), show_pe.clone()]), &from_pod_pf), &level_defs_pc) })
                            }))
                        })
                    })
                })
            }))
        }))
    }
}

/// `Start TagParts, x`: what the function value is when passed to `@Run`.
pub fn start_tag_parts_f(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::TagDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<Parts>> {
    ::std::rc::Rc::new(TagParts { cp_p0, t_p1 })
}

/// ```prism
/// CppDeepField: unbounded fn Text, Text, OutTy -> Text
/// ```
pub fn cpp_deep_field_f(p_p0: &crate::prelude::Text, f_p1: &crate::prelude::Text, ft_p2: &crate::lower::model::OutTy) -> crate::prelude::Text {
    crate::prelude::Text::from(format!("{{\"{}\", {}}}", p_p0, &cpp_deep_pod_f(f_p1, ft_p2)))
}

/// The step machine of `CppDeepField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppDeepField: unbounded fn Text, Text, OutTy -> Text
/// ```
pub struct CppDeepField {
    pub p_p0: crate::prelude::Text,
    pub f_p1: crate::prelude::Text,
    pub ft_p2: crate::lower::model::OutTy,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppDeepField {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let p_p0 = &self.p_p0;
        let f_p1 = &self.f_p1;
        let ft_p2 = &self.ft_p2;
        let f_p1x = f_p1.clone();
        let ft_p2x = ft_p2.clone();
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(start_cpp_deep_pod_f(f_p1x.clone(), ft_p2x.clone()), move |cpp_deep_pod_f_23240: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{{\"{}\", {}}}", &p_p0x, &cpp_deep_pod_f_23240))))
    }
}

/// `Start CppDeepField, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_deep_field_f(p_p0: crate::prelude::Text, f_p1: crate::prelude::Text, ft_p2: crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppDeepField { p_p0, f_p1, ft_p2 })
}

/// ```prism
/// CppDeepPod: unbounded fn Text, OutTy -> Text
/// ```
pub fn cpp_deep_pod_f(f_p0: &crate::prelude::Text, ft_p1: &crate::lower::model::OutTy) -> crate::prelude::Text {
    'm23329: {
        if let crate::lower::model::OutTy::OutMap(_, m23329_0_1) = ft_p1 && let crate::lower::model::OutTy::OutDyn(m23329_0_1_r_0) = &**m23329_0_1 && let crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefItem(m23329_0_1_r_0_r_0_0, m23329_0_1_r_0_r_0_1, _), _) = &**m23329_0_1_r_0 && (m23329_0_1_r_0_r_0_0 == &crate::prelude::Text::lit("")) && (m23329_0_1_r_0_r_0_1 == &crate::prelude::Text::lit("Elem")) {
            break 'm23329 crate::prelude::Text::from(format!("::prism_rtl::dynamics_pod({}, cx)", &crate::emit::cpp::field_id_f(f_p0)));
        }
        if let crate::lower::model::OutTy::OutDyn(m23329_1_0) = ft_p1 && let crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefItem(m23329_1_0_r_0_0, m23329_1_0_r_0_1, _), _) = &**m23329_1_0 && (m23329_1_0_r_0_0 == &crate::prelude::Text::lit("")) && (m23329_1_0_r_0_1 == &crate::prelude::Text::lit("Elem")) {
            break 'm23329 crate::prelude::Text::from(format!("::prism_rtl::level_pod({}.sample(cx), cx)", &crate::emit::cpp::field_id_f(f_p0)));
        }
        if let other_p2 = ft_p1 {
            break 'm23329 if crate::lower::types::holds_dyn_f(other_p2) {
                crate::prelude::Text::lit("[] { static_assert(false, \"prismc: a tag field holding a dynamic other than `$Elem` or a map of them is not read deep (claude/incremental-host-document.md, doubt WD)\"); return crate::prelude::Pod(); }()")
            } else {
                crate::prelude::Text::from(format!("::prism_rtl::to_pod({})", &crate::emit::cpp::field_id_f(f_p0)))
            };
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `CppDeepPod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppDeepPod: unbounded fn Text, OutTy -> Text
/// ```
pub struct CppDeepPod {
    pub f_p0: crate::prelude::Text,
    pub ft_p1: crate::lower::model::OutTy,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppDeepPod {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let f_p0 = &self.f_p0;
        let ft_p1 = &self.ft_p1;
        'm23329: {
            if let crate::lower::model::OutTy::OutMap(_, m23329_0_1) = ft_p1 && let crate::lower::model::OutTy::OutDyn(m23329_0_1_r_0) = &**m23329_0_1 && let crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefItem(m23329_0_1_r_0_r_0_0, m23329_0_1_r_0_r_0_1, _), _) = &**m23329_0_1_r_0 && (m23329_0_1_r_0_r_0_0 == &crate::prelude::Text::lit("")) && (m23329_0_1_r_0_r_0_1 == &crate::prelude::Text::lit("Elem")) {
                break 'm23329 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::prism_rtl::dynamics_pod({}, cx)", &crate::emit::cpp::field_id_f(f_p0))));
            }
            if let crate::lower::model::OutTy::OutDyn(m23329_1_0) = ft_p1 && let crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefItem(m23329_1_0_r_0_0, m23329_1_0_r_0_1, _), _) = &**m23329_1_0 && (m23329_1_0_r_0_0 == &crate::prelude::Text::lit("")) && (m23329_1_0_r_0_1 == &crate::prelude::Text::lit("Elem")) {
                break 'm23329 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::prism_rtl::level_pod({}.sample(cx), cx)", &crate::emit::cpp::field_id_f(f_p0))));
            }
            if let other_p2 = ft_p1 {
                break 'm23329 {
                    let f_p0x = f_p0.clone();
                    let other_p2x = other_p2.clone();
                    crate::prelude::call_then(crate::lower::types::start_holds_dyn_f(other_p2x.clone()), move |holds_dyn_f_23588: bool| if holds_dyn_f_23588 {
                        ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("[] { static_assert(false, \"prismc: a tag field holding a dynamic other than `$Elem` or a map of them is not read deep (claude/incremental-host-document.md, doubt WD)\"); return crate::prelude::Pod(); }()"))
                    } else {
                        ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::prism_rtl::to_pod({})", &crate::emit::cpp::field_id_f(&f_p0x))))
                    })
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start CppDeepPod, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_deep_pod_f(f_p0: crate::prelude::Text, ft_p1: crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppDeepPod { f_p0, ft_p1 })
}

/// ```prism
/// CppDeepPorts: unbounded fn Text, OutTy -> Text
/// ```
pub fn cpp_deep_ports_f(f_p0: &crate::prelude::Text, ft_p1: &crate::lower::model::OutTy) -> crate::prelude::Text {
    'm23926: {
        if let crate::lower::model::OutTy::OutMap(_, m23926_0_1) = ft_p1 && let crate::lower::model::OutTy::OutDyn(m23926_0_1_r_0) = &**m23926_0_1 && let crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefItem(m23926_0_1_r_0_r_0_0, m23926_0_1_r_0_r_0_1, _), _) = &**m23926_0_1_r_0 && (m23926_0_1_r_0_r_0_0 == &crate::prelude::Text::lit("")) && (m23926_0_1_r_0_r_0_1 == &crate::prelude::Text::lit("Elem")) {
            break 'm23926 crate::prelude::Text::from(format!("::prism_rtl::dynamics_ports({}, cx, out);", &crate::emit::cpp::field_id_f(f_p0)));
        }
        if let crate::lower::model::OutTy::OutDyn(m23926_1_0) = ft_p1 && let crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefItem(m23926_1_0_r_0_0, m23926_1_0_r_0_1, _), _) = &**m23926_1_0 && (m23926_1_0_r_0_0 == &crate::prelude::Text::lit("")) && (m23926_1_0_r_0_1 == &crate::prelude::Text::lit("Elem")) {
            break 'm23926 crate::prelude::Text::from(format!("out.push_back({}.updates);\n::prism_rtl::level_ports({}.sample(cx), cx, out);", &crate::emit::cpp::field_id_f(f_p0), &crate::emit::cpp::field_id_f(f_p0)));
        }
        crate::prelude::Text::lit("")
    }
}

/// The step machine of `CppDeepPorts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppDeepPorts: unbounded fn Text, OutTy -> Text
/// ```
pub struct CppDeepPorts {
    pub f_p0: crate::prelude::Text,
    pub ft_p1: crate::lower::model::OutTy,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppDeepPorts {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let f_p0 = &self.f_p0;
        let ft_p1 = &self.ft_p1;
        'm23926: {
            if let crate::lower::model::OutTy::OutMap(_, m23926_0_1) = ft_p1 && let crate::lower::model::OutTy::OutDyn(m23926_0_1_r_0) = &**m23926_0_1 && let crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefItem(m23926_0_1_r_0_r_0_0, m23926_0_1_r_0_r_0_1, _), _) = &**m23926_0_1_r_0 && (m23926_0_1_r_0_r_0_0 == &crate::prelude::Text::lit("")) && (m23926_0_1_r_0_r_0_1 == &crate::prelude::Text::lit("Elem")) {
                break 'm23926 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::prism_rtl::dynamics_ports({}, cx, out);", &crate::emit::cpp::field_id_f(f_p0))));
            }
            if let crate::lower::model::OutTy::OutDyn(m23926_1_0) = ft_p1 && let crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefItem(m23926_1_0_r_0_0, m23926_1_0_r_0_1, _), _) = &**m23926_1_0 && (m23926_1_0_r_0_0 == &crate::prelude::Text::lit("")) && (m23926_1_0_r_0_1 == &crate::prelude::Text::lit("Elem")) {
                break 'm23926 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("out.push_back({}.updates);\n::prism_rtl::level_ports({}.sample(cx), cx, out);", &crate::emit::cpp::field_id_f(f_p0), &crate::emit::cpp::field_id_f(f_p0))));
            }
            ::prism_rtl::Turn::Finished(crate::prelude::Text::lit(""))
        }
    }
}

/// `Start CppDeepPorts, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_deep_ports_f(f_p0: crate::prelude::Text, ft_p1: crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppDeepPorts { f_p0, ft_p1 })
}

/// ```prism
/// RowParts: unbounded fn Cp, Text, RowDef -> Parts
/// ```
pub fn row_parts_f(cp_p0: &crate::emit::cpp::Cp, m_p1: &crate::prelude::Text, r_p2: &crate::lower::model::RowDef) -> Parts {
    let names_p3 = crate::prelude::each(&r_p2.cases_p, &(|(v_pf, _): &(crate::prelude::Text, crate::lower::model::Ref)| v_pf.clone()));
    let levels_p4 = if r_p2.level_p {
        crate::prelude::Text::lit("\ncrate::prelude::Pod level_pod(const crate::prelude::Cx& cx) const;\nvoid level_ports(const crate::prelude::Cx& cx, ::std::vector<::prism_rtl::Rc<::prism_rtl::Port<crate::prelude::Unit>>>& out) const;")
    } else {
        crate::prelude::Text::lit("")
    };
    let pod_p5 = crate::prelude::Text::from(format!("crate::prelude::Pod to_pod() const;\nvoid show(crate::prelude::Printer& p) const;{}{}", &(if r_p2.pod_p {
        crate::prelude::Text::from(format!("\nstatic crate::prelude::Result<{}> from_pod(const crate::prelude::Pod& p);", &r_p2.name_p))
    } else {
        crate::prelude::Text::lit("")
    }), &levels_p4));
    let cases_p6 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&r_p2.cases_p, &(|(v_pg, st_ph): &(crate::prelude::Text, crate::lower::model::Ref)| crate::emit::cpp::templates::items::case_decl_f(v_pg, &crate::prelude::Text::from(format!("{} a0;{}", &row_struct_f(m_p1, st_ph), &(if r_p2.eq_p {
        crate::prelude::Text::from(format!("\nbool operator==(const {}&) const = default;", v_pg))
    } else {
        crate::prelude::Text::lit("")
    })))))), &crate::prelude::Text::lit("\n"));
    let cls_p7 = crate::emit::cpp::templates::items::choice_class_f(&cpp_source_doc_f(&crate::prelude::Text::from(format!("`{}`, a row kind\'s values:", &r_p2.prism_p)), &r_p2.doc_p), &crate::prelude::Text::lit(""), &r_p2.name_p, &cases_p6, &crate::syntax::lexer::chars::join_f(&names_p3, &crate::prelude::Text::lit(", ")), &pod_p5);
    let eq_p8 = if r_p2.eq_p {
        crate::prelude::Text::from(format!("\ninline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &r_p2.name_p, &r_p2.name_p))
    } else {
        crate::prelude::Text::lit("")
    };
    let level_defs_p9 = if r_p2.level_p {
        crate::prelude::Array::from(vec![crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("crate::prelude::Pod {}::level_pod(const crate::prelude::Cx& cx) const", &r_p2.name_p)), &crate::prelude::Text::lit("return ::std::visit([&](const auto& c) { return ::prism_rtl::level_pod(c.a0, cx); }, cases());")), crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("void {}::level_ports(const crate::prelude::Cx& cx, ::std::vector<::prism_rtl::Rc<::prism_rtl::Port<crate::prelude::Unit>>>& out) const", &r_p2.name_p)), &crate::prelude::Text::lit("::std::visit([&](const auto& c) { ::prism_rtl::level_ports(c.a0, cx, out); }, cases());"))])
    } else {
        crate::prelude::Array::new()
    };
    let to_pod_pa = crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("crate::prelude::Pod {}::to_pod() const", &r_p2.name_p)), &crate::prelude::Text::lit("return ::std::visit([](const auto& c) { return ::prism_rtl::to_pod(c.a0); }, cases());"));
    let show_pb = crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("void {}::show(crate::prelude::Printer& p) const", &r_p2.name_p)), &crate::prelude::Text::lit("crate::prelude::Show<crate::prelude::Pod>::show(to_pod(), p);"));
    let reads_pc = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&r_p2.cases_p, &(|(v_pi, st_pj): &(crate::prelude::Text, crate::lower::model::Ref)| crate::prelude::Text::from(format!("if (*t == {}::TAG) return {}({}{{TRY(::prism_rtl::from_pod<{}>(p))}});", &row_struct_f(m_p1, st_pj), &r_p2.name_p, v_pi, &row_struct_f(m_p1, st_pj))))), &crate::prelude::Text::lit("\n"));
    let from_pod_pd = if r_p2.pod_p {
        crate::prelude::Array::from(vec![crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("crate::prelude::Result<{}> {}::from_pod(const crate::prelude::Pod& p)", &r_p2.name_p, &r_p2.name_p)), &crate::prelude::Text::from(format!("if (auto t = p.tag()) {{\n{}\n}}\nreturn crate::prelude::mismatch<{}>(\"a {}\", p);", &indent_cpp_f(&reads_pc), &r_p2.name_p, &r_p2.name_p)))])
    } else {
        crate::prelude::Array::new()
    };
    let deps_pe = crate::emit::cpp::patterns::concat2_f(&crate::prelude::run_to_end(crate::prelude::each_job(r_p2.cases_p.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::Ref)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (_, st_pk) = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(ValueDeps { cp_p0: cp_p0xy.clone(), t_p1: crate::lower::model::OutTy::OutNamed(st_pk.clone(), crate::prelude::Array::new()) }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::Ref)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
    })));
    Parts { forward_p: crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("class {};", &r_p2.name_p))]), values_p: crate::prelude::Array::from(vec![ValueDecl { path_p: decl_path_f(cp_p0, &r_p2.name_p), deps_p: deps_pe.clone(), text_p: crate::prelude::Text::from(format!("{}{}", &cls_p7, &eq_p8)) }]), protos_p: crate::prelude::Array::new(), classes_p: crate::prelude::Array::new(), outer_p: crate::prelude::Array::new(), generic_p: crate::prelude::Array::new(), defs_p: crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![to_pod_pa.clone(), show_pb.clone()]), &from_pod_pd), &level_defs_p9) }
}

/// The step machine of `RowParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowParts: unbounded fn Cp, Text, RowDef -> Parts
/// ```
pub struct RowParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub m_p1: crate::prelude::Text,
    pub r_p2: crate::lower::model::RowDef,
}

impl ::prism_rtl::Job<Parts> for RowParts {
    fn cycle(&self) -> ::prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let m_p1 = &self.m_p1;
        let r_p2 = &self.r_p2;
        let names_p3 = crate::prelude::each(&r_p2.cases_p, &(|(v_pf, _): &(crate::prelude::Text, crate::lower::model::Ref)| v_pf.clone()));
        let levels_p4 = if r_p2.level_p {
            crate::prelude::Text::lit("\ncrate::prelude::Pod level_pod(const crate::prelude::Cx& cx) const;\nvoid level_ports(const crate::prelude::Cx& cx, ::std::vector<::prism_rtl::Rc<::prism_rtl::Port<crate::prelude::Unit>>>& out) const;")
        } else {
            crate::prelude::Text::lit("")
        };
        let pod_p5 = crate::prelude::Text::from(format!("crate::prelude::Pod to_pod() const;\nvoid show(crate::prelude::Printer& p) const;{}{}", &(if r_p2.pod_p {
            crate::prelude::Text::from(format!("\nstatic crate::prelude::Result<{}> from_pod(const crate::prelude::Pod& p);", &r_p2.name_p))
        } else {
            crate::prelude::Text::lit("")
        }), &levels_p4));
        let cases_p6 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&r_p2.cases_p, &(|(v_pg, st_ph): &(crate::prelude::Text, crate::lower::model::Ref)| crate::emit::cpp::templates::items::case_decl_f(v_pg, &crate::prelude::Text::from(format!("{} a0;{}", &row_struct_f(m_p1, st_ph), &(if r_p2.eq_p {
            crate::prelude::Text::from(format!("\nbool operator==(const {}&) const = default;", v_pg))
        } else {
            crate::prelude::Text::lit("")
        })))))), &crate::prelude::Text::lit("\n"));
        let cls_p7 = crate::emit::cpp::templates::items::choice_class_f(&cpp_source_doc_f(&crate::prelude::Text::from(format!("`{}`, a row kind\'s values:", &r_p2.prism_p)), &r_p2.doc_p), &crate::prelude::Text::lit(""), &r_p2.name_p, &cases_p6, &crate::syntax::lexer::chars::join_f(&names_p3, &crate::prelude::Text::lit(", ")), &pod_p5);
        let eq_p8 = if r_p2.eq_p {
            crate::prelude::Text::from(format!("\ninline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &r_p2.name_p, &r_p2.name_p))
        } else {
            crate::prelude::Text::lit("")
        };
        let level_defs_p9 = if r_p2.level_p {
            crate::prelude::Array::from(vec![crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("crate::prelude::Pod {}::level_pod(const crate::prelude::Cx& cx) const", &r_p2.name_p)), &crate::prelude::Text::lit("return ::std::visit([&](const auto& c) { return ::prism_rtl::level_pod(c.a0, cx); }, cases());")), crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("void {}::level_ports(const crate::prelude::Cx& cx, ::std::vector<::prism_rtl::Rc<::prism_rtl::Port<crate::prelude::Unit>>>& out) const", &r_p2.name_p)), &crate::prelude::Text::lit("::std::visit([&](const auto& c) { ::prism_rtl::level_ports(c.a0, cx, out); }, cases());"))])
        } else {
            crate::prelude::Array::new()
        };
        let to_pod_pa = crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("crate::prelude::Pod {}::to_pod() const", &r_p2.name_p)), &crate::prelude::Text::lit("return ::std::visit([](const auto& c) { return ::prism_rtl::to_pod(c.a0); }, cases());"));
        let show_pb = crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("void {}::show(crate::prelude::Printer& p) const", &r_p2.name_p)), &crate::prelude::Text::lit("crate::prelude::Show<crate::prelude::Pod>::show(to_pod(), p);"));
        let reads_pc = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&r_p2.cases_p, &(|(v_pi, st_pj): &(crate::prelude::Text, crate::lower::model::Ref)| crate::prelude::Text::from(format!("if (*t == {}::TAG) return {}({}{{TRY(::prism_rtl::from_pod<{}>(p))}});", &row_struct_f(m_p1, st_pj), &r_p2.name_p, v_pi, &row_struct_f(m_p1, st_pj))))), &crate::prelude::Text::lit("\n"));
        let from_pod_pd = if r_p2.pod_p {
            crate::prelude::Array::from(vec![crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("crate::prelude::Result<{}> {}::from_pod(const crate::prelude::Pod& p)", &r_p2.name_p, &r_p2.name_p)), &crate::prelude::Text::from(format!("if (auto t = p.tag()) {{\n{}\n}}\nreturn crate::prelude::mismatch<{}>(\"a {}\", p);", &indent_cpp_f(&reads_pc), &r_p2.name_p, &r_p2.name_p)))])
        } else {
            crate::prelude::Array::new()
        };
        let cp_p0x = cp_p0.clone();
        let r_p2x = r_p2.clone();
        crate::prelude::call_value(crate::prelude::each_job(r_p2x.cases_p.clone(), {
            let cp_p0xx = cp_p0x.clone();
            ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::Ref)| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (_, st_pk) = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ValueDeps { cp_p0: cp_p0xxy.clone(), t_p1: crate::lower::model::OutTy::OutNamed(st_pk.clone(), crate::prelude::Array::new()) }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::Ref)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
        }), move |each_26728: crate::prelude::Array<crate::prelude::Array<crate::prelude::Text>>| {
            let deps_pe = crate::emit::cpp::patterns::concat2_f(&each_26728);
            ::prism_rtl::Turn::Finished(Parts { forward_p: crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("class {};", &r_p2x.name_p))]), values_p: crate::prelude::Array::from(vec![ValueDecl { path_p: decl_path_f(&cp_p0x, &r_p2x.name_p), deps_p: deps_pe.clone(), text_p: crate::prelude::Text::from(format!("{}{}", &cls_p7, &eq_p8)) }]), protos_p: crate::prelude::Array::new(), classes_p: crate::prelude::Array::new(), outer_p: crate::prelude::Array::new(), generic_p: crate::prelude::Array::new(), defs_p: crate::prelude::append(&crate::prelude::append(&crate::prelude::Array::from(vec![to_pod_pa.clone(), show_pb.clone()]), &from_pod_pd), &level_defs_p9) })
        })
    }
}

/// `Start RowParts, x`: what the function value is when passed to `@Run`.
pub fn start_row_parts_f(cp_p0: crate::emit::cpp::Cp, m_p1: crate::prelude::Text, r_p2: crate::lower::model::RowDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<Parts>> {
    ::std::rc::Rc::new(RowParts { cp_p0, m_p1, r_p2 })
}

/// ```prism
/// RowStruct: fn Text, Ref -> Text
/// ```
pub fn row_struct_f(m_p0: &crate::prelude::Text, st_p1: &crate::lower::model::Ref) -> crate::prelude::Text {
    match st_p1 {
        crate::lower::model::Ref::RefItem(sm_p2, p_p3, s_p4) => if m_p0 == &crate::prelude::Text::lit("") {
            crate::emit::cpp::type_path_f(s_p4)
        } else {
            crate::prelude::Text::from(format!("crate::{}::{}", sm_p2, p_p3))
        },
        crate::lower::model::Ref::RefRuntime(t_p5) => crate::emit::cpp::type_path_f(t_p5),
    }
}

/// ```prism
/// CppOutsideArm: unbounded fn Cp, OutTy -> Text
/// ```
pub fn cpp_outside_arm_f(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::OutTy) -> crate::prelude::Text {
    if crate::lower::types::podable_f(t_p1) {
        crate::prelude::Text::from(format!("if (auto u = ::std::get_if<Untagged_a>(&cases())) return ::prism_rtl::from_pod<{}>(u->a0);", &crate::emit::cpp::cpp_type_f(cp_p0, t_p1)))
    } else {
        crate::prelude::Text::from(format!("if (auto h = held_as<{}>()) return *h;", &crate::emit::cpp::cpp_type_f(cp_p0, t_p1)))
    }
}

/// The step machine of `CppOutsideArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppOutsideArm: unbounded fn Cp, OutTy -> Text
/// ```
pub struct CppOutsideArm {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::OutTy,
}

impl ::prism_rtl::Job<crate::prelude::Text> for CppOutsideArm {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        let cp_p0x = cp_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::lower::types::start_podable_f(t_p1x.clone()), move |podable_f_27600: bool| if podable_f_27600 {
            crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), t_p1x.clone()), move |cpp_type_f_27692: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("if (auto u = ::std::get_if<Untagged_a>(&cases())) return ::prism_rtl::from_pod<{}>(u->a0);", &cpp_type_f_27692))))
        } else {
            crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), t_p1x.clone()), move |cpp_type_f_27746: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("if (auto h = held_as<{}>()) return *h;", &cpp_type_f_27746))))
        })
    }
}

/// `Start CppOutsideArm, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_outside_arm_f(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(CppOutsideArm { cp_p0, t_p1 })
}

/// ```prism
/// CppNoWorldAnswer: fn Text -> Text
/// ```
pub fn cpp_no_world_answer_f(tag_name_p0: &crate::prelude::Text) -> crate::prelude::Text {
    crate::prelude::Text::from(format!("return crate::prelude::unexpected(crate::prelude::Fault::answer(crate::prelude::str(\"a World\'s answer for {}, whose output is no plain data: a host answers it\")));", tag_name_p0))
}

/// ```prism
/// AnswerParts: unbounded fn Cp, AnswerDef -> Parts
/// ```
pub fn answer_parts_f(cp_p0: &crate::emit::cpp::Cp, a_p1: &crate::lower::model::AnswerDef) -> Parts {
    let firsts_p2 = crate::prelude::fold(&a_p1.cases_p, &crate::prelude::Array::new(), &(|acc_pp: &crate::prelude::Array<(crate::lower::model::AnswerCase, crate::lower::model::OutTy)>, c_pq: &crate::lower::model::AnswerCase| match &c_pq.first_o {
        ::std::option::Option::Some(ft_pr) => crate::prelude::push(acc_pp, &(c_pq.clone(), ft_pr.clone())),
        ::std::option::Option::None => acc_pp.clone(),
    }));
    let names0_p3 = crate::prelude::push(&crate::prelude::append(&crate::prelude::each(&a_p1.cases_p, &(|c_ps: &crate::lower::model::AnswerCase| c_ps.variant_p.clone())), &crate::prelude::each(&firsts_p2, &(|(c_pt, ft_pu): &(crate::lower::model::AnswerCase, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("{}First", &c_pt.variant_p))))), &crate::prelude::Text::lit("Untagged_a"));
    let names_p4 = crate::prelude::push(&names0_p3, &crate::prelude::Text::lit("Held_a"));
    let held_p5 = crate::prelude::Text::lit("template <class T> ::std::optional<T> held_as() const { if (auto h = ::std::get_if<Held_a>(&cases())) if (auto v = ::std::any_cast<T>(&h->a0)) return *v; return ::std::nullopt; }\ntemplate <class T> crate::prelude::Result<T> held() const { if (auto v = held_as<T>()) return *v; return crate::prelude::unexpected(crate::prelude::Fault::answer(crate::prelude::str(\"an answer for \", tag(), \", where a blueprint value\'s result that is no plain data was expected\"))); }");
    let accessors_p6 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::run_to_end(crate::prelude::each_job(a_p1.cases_p.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::AnswerCase| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let c_pv = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), c_pv.ty_p.clone()), move |cpp_type_f_29654: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Result<{}> {}() const;", &cpp_type_f_29654, &c_pv.accessor_p))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::AnswerCase) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    })), &crate::prelude::run_to_end(crate::prelude::each_job(firsts_p2.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: (crate::lower::model::AnswerCase, crate::lower::model::OutTy)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (c_p10, ft_p11) = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), ft_p11.clone()), move |cpp_type_f_29750: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Result<{}> {}_first() const;", &cpp_type_f_29750, &c_p10.accessor_p))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::AnswerCase, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    }))), &crate::prelude::Text::lit("\n"));
    let plain_p7 = crate::prelude::Text::lit("template <class T> crate::prelude::Result<T> plain() const { if (auto u = ::std::get_if<Untagged_a>(&cases())) return ::prism_rtl::from_pod<T>(u->a0); return crate::prelude::unexpected(crate::prelude::Fault::answer(crate::prelude::str(\"an answer for \", tag(), \", where a blueprint value\'s plain result was expected\"))); }");
    let members_p8 = crate::prelude::Text::from(format!("const char* tag() const;\nAnswer untagged() const;\n{}\n{}\n{}\nstatic crate::prelude::Result<Answer> decode(const Elem& e, const crate::prelude::Pod& v);\nstatic crate::prelude::Result<Answer> decode_first(const Elem& e, const crate::prelude::Pod& v);\nstatic ::std::optional<::prism_rtl::PartsAnswer<Answer>> held_parts(const Elem& e, const Answer& answer);", &accessors_p6, &plain_p7, &held_p5));
    let cases0_p9 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::run_to_end(crate::prelude::each_job(a_p1.cases_p.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::AnswerCase| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let c_p12 = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), c_p12.ty_p.clone()), move |cpp_type_f_30620: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::case_decl_f(&c_p12.variant_p, &crate::prelude::Text::from(format!("{} a0;", &cpp_type_f_30620)))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::AnswerCase) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    })), &crate::prelude::run_to_end(crate::prelude::each_job(firsts_p2.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: (crate::lower::model::AnswerCase, crate::lower::model::OutTy)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (c_p13, ft_p14) = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), ft_p14.clone()), move |cpp_type_f_30703: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::case_decl_f(&crate::prelude::Text::from(format!("{}First", &c_p13.variant_p)), &crate::prelude::Text::from(format!("{} a0;", &cpp_type_f_30703)))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::AnswerCase, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    }))), &crate::prelude::Text::lit("\n"));
    let cases_pa = crate::prelude::Text::from(format!("{}\n{}\n{}", &cases0_p9, &crate::emit::cpp::templates::items::case_decl_f(&crate::prelude::Text::lit("Untagged_a"), &crate::prelude::Text::lit("crate::prelude::Pod a0;")), &crate::emit::cpp::templates::items::case_decl_f(&crate::prelude::Text::lit("Held_a"), &crate::prelude::Text::lit("::std::any a0;"))));
    let cls_pb = crate::emit::cpp::templates::items::choice_class_f(&cpp_doc_f(&crate::prelude::Text::lit("`Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host\'s\nsupplier answers a child place with, and what a World\'s answer to a forwarded element\ndecodes to, carrying the tag\'s output.")), &crate::prelude::Text::lit(""), &crate::prelude::Text::lit("Answer"), &cases_pa, &crate::syntax::lexer::chars::join_f(&names_p4, &crate::prelude::Text::lit(", ")), &members_p8);
    let tags_pc = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::each(&a_p1.cases_p, &(|c_p15: &crate::lower::model::AnswerCase| crate::prelude::Text::from(format!("if (::std::holds_alternative<{}>(cases())) return {}::TAG;", &c_p15.variant_p, &crate::emit::cpp::type_path_f(&crate::lower::model::ref_spelled_f(&c_p15.struct_path_p)))))), &crate::prelude::each(&firsts_p2, &(|(c_p16, ft_p17): &(crate::lower::model::AnswerCase, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("if (::std::holds_alternative<{}First>(cases())) return {}::TAG;", &c_p16.variant_p, &crate::emit::cpp::type_path_f(&crate::lower::model::ref_spelled_f(&c_p16.struct_path_p))))))), &crate::prelude::Text::lit("\n"));
    let tag_fn_pd = crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::lit("const char* Answer::tag() const"), &crate::prelude::Text::from(format!("{}\nif (::std::holds_alternative<Held_a>(cases())) return \"no tag (an answer made outside a tag\'s arm that is no plain data)\";\nreturn \"no tag (an answer made outside a tag\'s arm)\";", &tags_pc)));
    let first_getters_pe = crate::prelude::run_to_end(crate::prelude::each_job(firsts_p2.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: (crate::lower::model::AnswerCase, crate::lower::model::OutTy)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (c_p18, ft_p19) = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), ft_p19.clone()), move |cpp_type_f_31837: crate::prelude::Text| crate::prelude::call_then(start_cpp_outside_arm_f(cp_p0xy.clone(), ft_p19.clone()), move |cpp_outside_arm_f_31964: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&crate::prelude::Text::from(format!("A `{}`\'s first value.", &c_p18.tag_name_p))), &crate::prelude::Text::from(format!("crate::prelude::Result<{}> Answer::{}_first() const", &cpp_type_f_31837, &c_p18.accessor_p)), &crate::prelude::Text::from(format!("if (auto c = ::std::get_if<{}First>(&cases())) return c->a0;\n{}\nreturn crate::prelude::unexpected(crate::prelude::Fault::answer(crate::prelude::str(\"an answer for \", tag(), \", where {}\'s first value was expected\")));", &c_p18.variant_p, &cpp_outside_arm_f_31964, &c_p18.tag_name_p))))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::AnswerCase, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    }));
    let decode_firsts_pf = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(firsts_p2.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: (crate::lower::model::AnswerCase, crate::lower::model::OutTy)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (c_p1a, ft_p1b) = p0;
                crate::prelude::call_then(crate::lower::types::start_podable_f(ft_p1b.clone()), move |podable_f_32212: bool| if podable_f_32212 {
                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), ft_p1b.clone()), move |cpp_type_f_32314: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("if (is<Elem::{}>(e)) return Answer({}First{{TRY(::prism_rtl::from_pod<{}>(v))}});", &c_p1a.variant_p, &c_p1a.variant_p, &cpp_type_f_32314))))
                } else {
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("if (is<Elem::{}>(e)) {}", &c_p1a.variant_p, &cpp_no_world_answer_f(&c_p1a.tag_name_p))))
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::AnswerCase, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    })), &crate::prelude::Text::lit("\n"));
    let decode_first_pg = crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&crate::prelude::Text::lit("A World\'s first value for the element `e`: a bundle\'s plain parts, any other tag\'s answer.")), &crate::prelude::Text::lit("crate::prelude::Result<Answer> Answer::decode_first(const Elem& e, const crate::prelude::Pod& v)"), &crate::prelude::Text::from(format!("{}\nreturn decode(e, v);", &decode_firsts_pf)));
    let getters_ph = crate::prelude::run_to_end(crate::prelude::each_job(a_p1.cases_p.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::AnswerCase| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let c_p1c = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), c_p1c.ty_p.clone()), move |cpp_type_f_32802: crate::prelude::Text| crate::prelude::call_then(start_cpp_outside_arm_f(cp_p0xy.clone(), c_p1c.ty_p.clone()), move |cpp_outside_arm_f_32920: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&crate::prelude::Text::from(format!("A `{}`\'s answer.", &c_p1c.tag_name_p))), &crate::prelude::Text::from(format!("crate::prelude::Result<{}> Answer::{}() const", &cpp_type_f_32802, &c_p1c.accessor_p)), &crate::prelude::Text::from(format!("if (auto c = ::std::get_if<{}>(&cases())) return c->a0;\n{}\nreturn crate::prelude::unexpected(crate::prelude::Fault::answer(crate::prelude::str(\"an answer for \", tag(), \", where {}\'s was expected\")));", &c_p1c.variant_p, &cpp_outside_arm_f_32920, &c_p1c.tag_name_p))))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::AnswerCase) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    }));
    let decodes_pi = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(a_p1.cases_p.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::AnswerCase| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let c_p1d = p0;
                crate::prelude::call_then(crate::lower::types::start_podable_f(c_p1d.ty_p.clone()), move |podable_f_33146: bool| if podable_f_33146 {
                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), c_p1d.ty_p.clone()), move |cpp_type_f_33245: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("if (is<Elem::{}>(e)) return Answer({}{{TRY(::prism_rtl::from_pod<{}>(v))}});", &c_p1d.variant_p, &c_p1d.variant_p, &cpp_type_f_33245))))
                } else {
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("if (is<Elem::{}>(e)) {}", &c_p1d.variant_p, &cpp_no_world_answer_f(&c_p1d.tag_name_p))))
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::AnswerCase) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    })), &crate::prelude::Text::lit("\n"));
    let decode_pj = crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&crate::prelude::Text::lit("A World\'s answer to the element `e`, decoded by its tag.")), &crate::prelude::Text::lit("crate::prelude::Result<Answer> Answer::decode(const Elem& e, const crate::prelude::Pod& v)"), &crate::prelude::Text::from(format!("{}\n::prism_rtl::unreachable();", &decodes_pi)));
    let held_arms_pk = crate::prelude::run_to_end(crate::prelude::fold_job(a_p1.cases_p.clone(), crate::prelude::Array::new(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::lower::model::AnswerCase)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p1e = p0;
                let c_p1f = p1;
                match (c_p1f.held_whole_o.clone(), c_p1f.held_parts_o.clone()) {
                    (::std::option::Option::Some(whole_p1g), ::std::option::Option::Some(parts_p1h)) => crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), whole_p1g.clone()), move |cpp_type_f_33855: crate::prelude::Text| crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0xy.clone(), parts_p1h.clone()), move |cpp_expr_f_33887: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p1e, &crate::prelude::Text::from(format!("if (is<Elem::{}>(e)) {{ if (auto whole = answer.held_as<{}>()) return ({})(*whole); return ::std::nullopt; }}", &c_p1f.variant_p, &cpp_type_f_33855, &cpp_expr_f_33887)))))),
                    _ => ::prism_rtl::Turn::Finished(acc_p1e.clone()),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::lower::model::AnswerCase)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
    }));
    let helds_pl = crate::syntax::lexer::chars::join_f(&held_arms_pk, &crate::prelude::Text::lit("\n"));
    let held_parts_pm = crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&crate::prelude::Text::lit("An answer held whole (a bundle with a part that is no plain data, made outside a tag\'s\narm) as the parts the tag of `e` takes.")), &crate::prelude::Text::lit("::std::optional<::prism_rtl::PartsAnswer<Answer>> Answer::held_parts(const Elem& e, const Answer& answer)"), &crate::prelude::Text::from(format!("{}\nreturn ::std::nullopt;", &helds_pl)));
    let untagged_arms_pn = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::fold_job(a_p1.cases_p.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::lower::model::AnswerCase)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_p1i = p0;
        let c_p1j = p1;
        crate::prelude::call_then(crate::lower::types::start_podable_f(c_p1j.ty_p.clone()), move |podable_f_34471: bool| if podable_f_34471 {
            ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p1i, &crate::prelude::Text::from(format!("if (auto c = ::std::get_if<{}>(&cases())) return Answer(Untagged_a{{::prism_rtl::to_pod(c->a0)}});", &c_p1j.variant_p))))
        } else {
            ::prism_rtl::Turn::Finished(acc_p1i.clone())
        })
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::lower::model::AnswerCase)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)), &crate::prelude::Text::lit("\n"));
    let untagged_fn_po = crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&crate::prelude::Text::lit("The answer as one made outside a tag\'s arm, where it is plain data: what a place of\nanother tag reads at its own type. Any other answer is itself.")), &crate::prelude::Text::lit("Answer Answer::untagged() const"), &crate::prelude::Text::from(format!("{}\nreturn *this;", &untagged_arms_pn)));
    Parts { forward_p: crate::prelude::Array::from(vec![crate::prelude::Text::lit("class Answer;")]), values_p: crate::prelude::Array::from(vec![ValueDecl { path_p: crate::prelude::Text::lit("Answer"), deps_p: crate::prelude::Array::new(), text_p: cls_pb.clone() }]), protos_p: crate::prelude::Array::new(), classes_p: crate::prelude::Array::new(), outer_p: crate::prelude::Array::new(), generic_p: crate::prelude::Array::new(), defs_p: crate::prelude::append(&crate::prelude::Array::from(vec![tag_fn_pd.clone(), untagged_fn_po.clone()]), &crate::prelude::append(&crate::prelude::append(&getters_ph, &first_getters_pe), &crate::prelude::Array::from(vec![decode_pj.clone(), decode_first_pg.clone(), held_parts_pm.clone()]))) }
}

/// The step machine of `AnswerParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnswerParts: unbounded fn Cp, AnswerDef -> Parts
/// ```
pub struct AnswerParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub a_p1: crate::lower::model::AnswerDef,
}

impl ::prism_rtl::Job<Parts> for AnswerParts {
    fn cycle(&self) -> ::prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let a_p1 = &self.a_p1;
        let firsts_p2 = crate::prelude::fold(&a_p1.cases_p, &crate::prelude::Array::new(), &(|acc_pp: &crate::prelude::Array<(crate::lower::model::AnswerCase, crate::lower::model::OutTy)>, c_pq: &crate::lower::model::AnswerCase| match &c_pq.first_o {
            ::std::option::Option::Some(ft_pr) => crate::prelude::push(acc_pp, &(c_pq.clone(), ft_pr.clone())),
            ::std::option::Option::None => acc_pp.clone(),
        }));
        let names0_p3 = crate::prelude::push(&crate::prelude::append(&crate::prelude::each(&a_p1.cases_p, &(|c_ps: &crate::lower::model::AnswerCase| c_ps.variant_p.clone())), &crate::prelude::each(&firsts_p2, &(|(c_pt, ft_pu): &(crate::lower::model::AnswerCase, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("{}First", &c_pt.variant_p))))), &crate::prelude::Text::lit("Untagged_a"));
        let names_p4 = crate::prelude::push(&names0_p3, &crate::prelude::Text::lit("Held_a"));
        let held_p5 = crate::prelude::Text::lit("template <class T> ::std::optional<T> held_as() const { if (auto h = ::std::get_if<Held_a>(&cases())) if (auto v = ::std::any_cast<T>(&h->a0)) return *v; return ::std::nullopt; }\ntemplate <class T> crate::prelude::Result<T> held() const { if (auto v = held_as<T>()) return *v; return crate::prelude::unexpected(crate::prelude::Fault::answer(crate::prelude::str(\"an answer for \", tag(), \", where a blueprint value\'s result that is no plain data was expected\"))); }");
        let a_p1x = a_p1.clone();
        let cp_p0x = cp_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(a_p1x.cases_p.clone(), {
            let cp_p0xx = cp_p0x.clone();
            ::std::rc::Rc::new(move |p0: crate::lower::model::AnswerCase| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let c_pv = p0;
                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), c_pv.ty_p.clone()), move |cpp_type_f_29654: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Result<{}> {}() const;", &cpp_type_f_29654, &c_pv.accessor_p))))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::AnswerCase) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
        }), move |each_29610: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_value(crate::prelude::each_job(firsts_p2.clone(), {
            let cp_p0xx = cp_p0x.clone();
            ::std::rc::Rc::new(move |p0: (crate::lower::model::AnswerCase, crate::lower::model::OutTy)| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (c_p10, ft_p11) = p0;
                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), ft_p11.clone()), move |cpp_type_f_29750: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Result<{}> {}_first() const;", &cpp_type_f_29750, &c_p10.accessor_p))))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::AnswerCase, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
        }), move |each_29699: crate::prelude::Array<crate::prelude::Text>| {
            let accessors_p6 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&each_29610, &each_29699), &crate::prelude::Text::lit("\n"));
            let plain_p7 = crate::prelude::Text::lit("template <class T> crate::prelude::Result<T> plain() const { if (auto u = ::std::get_if<Untagged_a>(&cases())) return ::prism_rtl::from_pod<T>(u->a0); return crate::prelude::unexpected(crate::prelude::Fault::answer(crate::prelude::str(\"an answer for \", tag(), \", where a blueprint value\'s plain result was expected\"))); }");
            let members_p8 = crate::prelude::Text::from(format!("const char* tag() const;\nAnswer untagged() const;\n{}\n{}\n{}\nstatic crate::prelude::Result<Answer> decode(const Elem& e, const crate::prelude::Pod& v);\nstatic crate::prelude::Result<Answer> decode_first(const Elem& e, const crate::prelude::Pod& v);\nstatic ::std::optional<::prism_rtl::PartsAnswer<Answer>> held_parts(const Elem& e, const Answer& answer);", &accessors_p6, &plain_p7, &held_p5));
            crate::prelude::call_value(crate::prelude::each_job(a_p1x.cases_p.clone(), {
                let cp_p0xx = cp_p0x.clone();
                ::std::rc::Rc::new(move |p0: crate::lower::model::AnswerCase| {
                    let cp_p0xxy = cp_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let c_p12 = p0;
                        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), c_p12.ty_p.clone()), move |cpp_type_f_30620: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::case_decl_f(&c_p12.variant_p, &crate::prelude::Text::from(format!("{} a0;", &cpp_type_f_30620)))))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::AnswerCase) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            }), move |each_30579: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_value(crate::prelude::each_job(firsts_p2.clone(), {
                let cp_p0xx = cp_p0x.clone();
                ::std::rc::Rc::new(move |p0: (crate::lower::model::AnswerCase, crate::lower::model::OutTy)| {
                    let cp_p0xxy = cp_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (c_p13, ft_p14) = p0;
                        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), ft_p14.clone()), move |cpp_type_f_30703: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::case_decl_f(&crate::prelude::Text::from(format!("{}First", &c_p13.variant_p)), &crate::prelude::Text::from(format!("{} a0;", &cpp_type_f_30703)))))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::AnswerCase, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            }), move |each_30646: crate::prelude::Array<crate::prelude::Text>| {
                let cases0_p9 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&each_30579, &each_30646), &crate::prelude::Text::lit("\n"));
                let cases_pa = crate::prelude::Text::from(format!("{}\n{}\n{}", &cases0_p9, &crate::emit::cpp::templates::items::case_decl_f(&crate::prelude::Text::lit("Untagged_a"), &crate::prelude::Text::lit("crate::prelude::Pod a0;")), &crate::emit::cpp::templates::items::case_decl_f(&crate::prelude::Text::lit("Held_a"), &crate::prelude::Text::lit("::std::any a0;"))));
                let cls_pb = crate::emit::cpp::templates::items::choice_class_f(&cpp_doc_f(&crate::prelude::Text::lit("`Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host\'s\nsupplier answers a child place with, and what a World\'s answer to a forwarded element\ndecodes to, carrying the tag\'s output.")), &crate::prelude::Text::lit(""), &crate::prelude::Text::lit("Answer"), &cases_pa, &crate::syntax::lexer::chars::join_f(&names_p4, &crate::prelude::Text::lit(", ")), &members_p8);
                let tags_pc = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::each(&a_p1x.cases_p, &(|c_p15: &crate::lower::model::AnswerCase| crate::prelude::Text::from(format!("if (::std::holds_alternative<{}>(cases())) return {}::TAG;", &c_p15.variant_p, &crate::emit::cpp::type_path_f(&crate::lower::model::ref_spelled_f(&c_p15.struct_path_p)))))), &crate::prelude::each(&firsts_p2, &(|(c_p16, ft_p17): &(crate::lower::model::AnswerCase, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("if (::std::holds_alternative<{}First>(cases())) return {}::TAG;", &c_p16.variant_p, &crate::emit::cpp::type_path_f(&crate::lower::model::ref_spelled_f(&c_p16.struct_path_p))))))), &crate::prelude::Text::lit("\n"));
                let tag_fn_pd = crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::lit("const char* Answer::tag() const"), &crate::prelude::Text::from(format!("{}\nif (::std::holds_alternative<Held_a>(cases())) return \"no tag (an answer made outside a tag\'s arm that is no plain data)\";\nreturn \"no tag (an answer made outside a tag\'s arm)\";", &tags_pc)));
                crate::prelude::call_value(crate::prelude::each_job(firsts_p2.clone(), {
                    let cp_p0xx = cp_p0x.clone();
                    ::std::rc::Rc::new(move |p0: (crate::lower::model::AnswerCase, crate::lower::model::OutTy)| {
                        let cp_p0xxy = cp_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (c_p18, ft_p19) = p0;
                            crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), ft_p19.clone()), move |cpp_type_f_31837: crate::prelude::Text| crate::prelude::call_then(start_cpp_outside_arm_f(cp_p0xxy.clone(), ft_p19.clone()), move |cpp_outside_arm_f_31964: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&crate::prelude::Text::from(format!("A `{}`\'s first value.", &c_p18.tag_name_p))), &crate::prelude::Text::from(format!("crate::prelude::Result<{}> Answer::{}_first() const", &cpp_type_f_31837, &c_p18.accessor_p)), &crate::prelude::Text::from(format!("if (auto c = ::std::get_if<{}First>(&cases())) return c->a0;\n{}\nreturn crate::prelude::unexpected(crate::prelude::Fault::answer(crate::prelude::str(\"an answer for \", tag(), \", where {}\'s first value was expected\")));", &c_p18.variant_p, &cpp_outside_arm_f_31964, &c_p18.tag_name_p))))))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::AnswerCase, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                }), move |each_31731: crate::prelude::Array<crate::prelude::Text>| {
                    let first_getters_pe = each_31731;
                    crate::prelude::call_value(crate::prelude::each_job(firsts_p2.clone(), {
                        let cp_p0xx = cp_p0x.clone();
                        ::std::rc::Rc::new(move |p0: (crate::lower::model::AnswerCase, crate::lower::model::OutTy)| {
                            let cp_p0xxy = cp_p0xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (c_p1a, ft_p1b) = p0;
                                crate::prelude::call_then(crate::lower::types::start_podable_f(ft_p1b.clone()), move |podable_f_32212: bool| if podable_f_32212 {
                                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), ft_p1b.clone()), move |cpp_type_f_32314: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("if (is<Elem::{}>(e)) return Answer({}First{{TRY(::prism_rtl::from_pod<{}>(v))}});", &c_p1a.variant_p, &c_p1a.variant_p, &cpp_type_f_32314))))
                                } else {
                                    ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("if (is<Elem::{}>(e)) {}", &c_p1a.variant_p, &cpp_no_world_answer_f(&c_p1a.tag_name_p))))
                                })
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::AnswerCase, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                    }), move |each_32183: crate::prelude::Array<crate::prelude::Text>| {
                        let decode_firsts_pf = crate::syntax::lexer::chars::join_f(&each_32183, &crate::prelude::Text::lit("\n"));
                        let decode_first_pg = crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&crate::prelude::Text::lit("A World\'s first value for the element `e`: a bundle\'s plain parts, any other tag\'s answer.")), &crate::prelude::Text::lit("crate::prelude::Result<Answer> Answer::decode_first(const Elem& e, const crate::prelude::Pod& v)"), &crate::prelude::Text::from(format!("{}\nreturn decode(e, v);", &decode_firsts_pf)));
                        crate::prelude::call_value(crate::prelude::each_job(a_p1x.cases_p.clone(), {
                            let cp_p0xx = cp_p0x.clone();
                            ::std::rc::Rc::new(move |p0: crate::lower::model::AnswerCase| {
                                let cp_p0xxy = cp_p0xx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let c_p1c = p0;
                                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), c_p1c.ty_p.clone()), move |cpp_type_f_32802: crate::prelude::Text| crate::prelude::call_then(start_cpp_outside_arm_f(cp_p0xxy.clone(), c_p1c.ty_p.clone()), move |cpp_outside_arm_f_32920: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&crate::prelude::Text::from(format!("A `{}`\'s answer.", &c_p1c.tag_name_p))), &crate::prelude::Text::from(format!("crate::prelude::Result<{}> Answer::{}() const", &cpp_type_f_32802, &c_p1c.accessor_p)), &crate::prelude::Text::from(format!("if (auto c = ::std::get_if<{}>(&cases())) return c->a0;\n{}\nreturn crate::prelude::unexpected(crate::prelude::Fault::answer(crate::prelude::str(\"an answer for \", tag(), \", where {}\'s was expected\")));", &c_p1c.variant_p, &cpp_outside_arm_f_32920, &c_p1c.tag_name_p))))))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::AnswerCase) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                        }), move |each_32708: crate::prelude::Array<crate::prelude::Text>| {
                            let getters_ph = each_32708;
                            crate::prelude::call_value(crate::prelude::each_job(a_p1x.cases_p.clone(), {
                                let cp_p0xx = cp_p0x.clone();
                                ::std::rc::Rc::new(move |p0: crate::lower::model::AnswerCase| {
                                    let cp_p0xxy = cp_p0xx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let c_p1d = p0;
                                        crate::prelude::call_then(crate::lower::types::start_podable_f(c_p1d.ty_p.clone()), move |podable_f_33146: bool| if podable_f_33146 {
                                            crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), c_p1d.ty_p.clone()), move |cpp_type_f_33245: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("if (is<Elem::{}>(e)) return Answer({}{{TRY(::prism_rtl::from_pod<{}>(v))}});", &c_p1d.variant_p, &c_p1d.variant_p, &cpp_type_f_33245))))
                                        } else {
                                            ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("if (is<Elem::{}>(e)) {}", &c_p1d.variant_p, &cpp_no_world_answer_f(&c_p1d.tag_name_p))))
                                        })
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::AnswerCase) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                            }), move |each_33124: crate::prelude::Array<crate::prelude::Text>| {
                                let decodes_pi = crate::syntax::lexer::chars::join_f(&each_33124, &crate::prelude::Text::lit("\n"));
                                let decode_pj = crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&crate::prelude::Text::lit("A World\'s answer to the element `e`, decoded by its tag.")), &crate::prelude::Text::lit("crate::prelude::Result<Answer> Answer::decode(const Elem& e, const crate::prelude::Pod& v)"), &crate::prelude::Text::from(format!("{}\n::prism_rtl::unreachable();", &decodes_pi)));
                                crate::prelude::call_value(crate::prelude::fold_job(a_p1x.cases_p.clone(), crate::prelude::Array::new(), {
                                    let cp_p0xx = cp_p0x.clone();
                                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::lower::model::AnswerCase)| {
                                        let cp_p0xxy = cp_p0xx.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let acc_p1e = p0;
                                            let c_p1f = p1;
                                            match (c_p1f.held_whole_o.clone(), c_p1f.held_parts_o.clone()) {
                                                (::std::option::Option::Some(whole_p1g), ::std::option::Option::Some(parts_p1h)) => crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), whole_p1g.clone()), move |cpp_type_f_33855: crate::prelude::Text| crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0xxy.clone(), parts_p1h.clone()), move |cpp_expr_f_33887: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p1e, &crate::prelude::Text::from(format!("if (is<Elem::{}>(e)) {{ if (auto whole = answer.held_as<{}>()) return ({})(*whole); return ::std::nullopt; }}", &c_p1f.variant_p, &cpp_type_f_33855, &cpp_expr_f_33887)))))),
                                                _ => ::prism_rtl::Turn::Finished(acc_p1e.clone()),
                                            }
                                        }))
                                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::lower::model::AnswerCase)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                                }), move |fold_33680: crate::prelude::Array<crate::prelude::Text>| {
                                    let held_arms_pk = fold_33680;
                                    let helds_pl = crate::syntax::lexer::chars::join_f(&held_arms_pk, &crate::prelude::Text::lit("\n"));
                                    let held_parts_pm = crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&crate::prelude::Text::lit("An answer held whole (a bundle with a part that is no plain data, made outside a tag\'s\narm) as the parts the tag of `e` takes.")), &crate::prelude::Text::lit("::std::optional<::prism_rtl::PartsAnswer<Answer>> Answer::held_parts(const Elem& e, const Answer& answer)"), &crate::prelude::Text::from(format!("{}\nreturn ::std::nullopt;", &helds_pl)));
                                    crate::prelude::call_value(crate::prelude::fold_job(a_p1x.cases_p.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::lower::model::AnswerCase)| crate::prelude::entered(crate::prelude::once_job(move || {
                                        let acc_p1i = p0;
                                        let c_p1j = p1;
                                        crate::prelude::call_then(crate::lower::types::start_podable_f(c_p1j.ty_p.clone()), move |podable_f_34471: bool| if podable_f_34471 {
                                            ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_p1i, &crate::prelude::Text::from(format!("if (auto c = ::std::get_if<{}>(&cases())) return Answer(Untagged_a{{::prism_rtl::to_pod(c->a0)}});", &c_p1j.variant_p))))
                                        } else {
                                            ::prism_rtl::Turn::Finished(acc_p1i.clone())
                                        })
                                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::lower::model::AnswerCase)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>), move |fold_34438: crate::prelude::Array<crate::prelude::Text>| {
                                        let untagged_arms_pn = crate::syntax::lexer::chars::join_f(&fold_34438, &crate::prelude::Text::lit("\n"));
                                        let untagged_fn_po = crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&crate::prelude::Text::lit("The answer as one made outside a tag\'s arm, where it is plain data: what a place of\nanother tag reads at its own type. Any other answer is itself.")), &crate::prelude::Text::lit("Answer Answer::untagged() const"), &crate::prelude::Text::from(format!("{}\nreturn *this;", &untagged_arms_pn)));
                                        ::prism_rtl::Turn::Finished(Parts { forward_p: crate::prelude::Array::from(vec![crate::prelude::Text::lit("class Answer;")]), values_p: crate::prelude::Array::from(vec![ValueDecl { path_p: crate::prelude::Text::lit("Answer"), deps_p: crate::prelude::Array::new(), text_p: cls_pb.clone() }]), protos_p: crate::prelude::Array::new(), classes_p: crate::prelude::Array::new(), outer_p: crate::prelude::Array::new(), generic_p: crate::prelude::Array::new(), defs_p: crate::prelude::append(&crate::prelude::Array::from(vec![tag_fn_pd.clone(), untagged_fn_po.clone()]), &crate::prelude::append(&crate::prelude::append(&getters_ph, &first_getters_pe), &crate::prelude::Array::from(vec![decode_pj.clone(), decode_first_pg.clone(), held_parts_pm.clone()]))) })
                                    })
                                })
                            })
                        })
                    })
                })
            }))
        }))
    }
}

/// `Start AnswerParts, x`: what the function value is when passed to `@Run`.
pub fn start_answer_parts_f(cp_p0: crate::emit::cpp::Cp, a_p1: crate::lower::model::AnswerDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<Parts>> {
    ::std::rc::Rc::new(AnswerParts { cp_p0, a_p1 })
}

/// ```prism
/// JobParts: unbounded fn Cp, JobDef -> Parts
/// ```
pub fn job_parts_f(cp_p0: &crate::emit::cpp::Cp, j_p1: &crate::lower::model::JobDef) -> Parts {
    let gens_p2 = cpp_template_head_f(&generic_names_of_f(&j_p1.generics_p));
    let head_p3 = head_of_f(&j_p1.name_p, &generic_names_of_f(&j_p1.generics_p));
    let jcp_p4 = crate::emit::cpp::with_fields_f(cp_p0, &j_p1.fields_p);
    let fields_p5 = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(j_p1.fields_p.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (n_pe, t_pf) = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), t_pf.clone()), move |cpp_type_f_35479: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {};", &cpp_type_f_35479, &crate::emit::cpp::field_id_f(&n_pe)))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    })), &crate::prelude::Text::lit("\n"));
    let params_p6 = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(j_p1.fields_p.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (n_pg, t_ph) = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), t_ph.clone()), move |cpp_type_f_35567: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {}", &cpp_type_f_35567, &crate::emit::cpp::field_id_f(&n_pg)))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    })), &crate::prelude::Text::lit(", "));
    let inits_p7 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&j_p1.fields_p, &(|(n_pi, _): &(crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("{}(::std::move({}))", &crate::emit::cpp::field_id_f(n_pi), &crate::emit::cpp::field_id_f(n_pi))))), &crate::prelude::Text::lit(", "));
    let ctor_p8 = if &crate::prelude::len(&j_p1.fields_p) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::lit("")
    } else {
        crate::prelude::Text::from(format!("{}({}) : {} {{}}", &j_p1.name_p, &params_p6, &inits_p7))
    };
    let ret_p9 = crate::emit::cpp::cpp_type_f(cp_p0, &j_p1.ret_p);
    let decl_pa = crate::emit::cpp::templates::items::job_struct_f(&cpp_doc_f(&j_p1.doc_p), &gens_p2, &j_p1.name_p, &ret_p9, &fields_p5, &ctor_p8);
    let cycle_pb = crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("{}::prism_rtl::Turn<{}> {}::cycle() const", &gens_p2, &ret_p9, &head_p3)), &crate::emit::cpp::stmts::cpp_body_f(&jcp_p4, &j_p1.body_p));
    let start_pc = crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&crate::prelude::Text::from(format!("`Start {}, x`: what the function value is when passed to `@Run`.", &j_p1.name_p))), &crate::prelude::Text::from(format!("{}::prism_rtl::JobRef<{}> {}({})", &gens_p2, &ret_p9, &j_p1.start_p, &params_p6)), &crate::prelude::Text::from(format!("return ::prism_rtl::make_rc<{}>({});", &head_p3, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&j_p1.fields_p, &(|(n_pj, _): &(crate::prelude::Text, crate::lower::model::OutTy)| crate::emit::cpp::field_id_f(n_pj))), &crate::prelude::Text::lit(", ")))));
    let generic_pd = &crate::prelude::len(&j_p1.generics_p) > &crate::prelude::Nat::from(0u32);
    Parts { forward_p: crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("{}struct {};", &gens_p2, &j_p1.name_p))]), values_p: crate::prelude::Array::new(), protos_p: crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("{}::prism_rtl::JobRef<{}> {}({});", &gens_p2, &ret_p9, &j_p1.start_p, &params_p6))]), classes_p: crate::prelude::Array::from(vec![decl_pa.clone()]), outer_p: crate::prelude::Array::new(), generic_p: if generic_pd {
        crate::prelude::Array::from(vec![cycle_pb.clone(), start_pc.clone()])
    } else {
        crate::prelude::Array::new()
    }, defs_p: if generic_pd {
        crate::prelude::Array::new()
    } else {
        crate::prelude::Array::from(vec![cycle_pb.clone(), start_pc.clone()])
    } }
}

/// The step machine of `JobParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobParts: unbounded fn Cp, JobDef -> Parts
/// ```
pub struct JobParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub j_p1: crate::lower::model::JobDef,
}

impl ::prism_rtl::Job<Parts> for JobParts {
    fn cycle(&self) -> ::prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let j_p1 = &self.j_p1;
        let gens_p2 = cpp_template_head_f(&generic_names_of_f(&j_p1.generics_p));
        let head_p3 = head_of_f(&j_p1.name_p, &generic_names_of_f(&j_p1.generics_p));
        let jcp_p4 = crate::emit::cpp::with_fields_f(cp_p0, &j_p1.fields_p);
        let cp_p0x = cp_p0.clone();
        let j_p1x = j_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(j_p1x.fields_p.clone(), {
            let cp_p0xx = cp_p0x.clone();
            ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (n_pe, t_pf) = p0;
                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), t_pf.clone()), move |cpp_type_f_35479: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {};", &cpp_type_f_35479, &crate::emit::cpp::field_id_f(&n_pe)))))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
        }), move |each_35450: crate::prelude::Array<crate::prelude::Text>| {
            let fields_p5 = crate::syntax::lexer::chars::join_f(&each_35450, &crate::prelude::Text::lit("\n"));
            crate::prelude::call_value(crate::prelude::each_job(j_p1x.fields_p.clone(), {
                let cp_p0xx = cp_p0x.clone();
                ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| {
                    let cp_p0xxy = cp_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (n_pg, t_ph) = p0;
                        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), t_ph.clone()), move |cpp_type_f_35567: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {}", &cpp_type_f_35567, &crate::emit::cpp::field_id_f(&n_pg)))))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            }), move |each_35538: crate::prelude::Array<crate::prelude::Text>| {
                let params_p6 = crate::syntax::lexer::chars::join_f(&each_35538, &crate::prelude::Text::lit(", "));
                let inits_p7 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&j_p1x.fields_p, &(|(n_pi, _): &(crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("{}(::std::move({}))", &crate::emit::cpp::field_id_f(n_pi), &crate::emit::cpp::field_id_f(n_pi))))), &crate::prelude::Text::lit(", "));
                let ctor_p8 = if &crate::prelude::len(&j_p1x.fields_p) == &crate::prelude::Nat::from(0u32) {
                    crate::prelude::Text::lit("")
                } else {
                    crate::prelude::Text::from(format!("{}({}) : {} {{}}", &j_p1x.name_p, &params_p6, &inits_p7))
                };
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), j_p1x.ret_p.clone()), move |cpp_type_f_35801: crate::prelude::Text| {
                    let ret_p9 = cpp_type_f_35801;
                    let decl_pa = crate::emit::cpp::templates::items::job_struct_f(&cpp_doc_f(&j_p1x.doc_p), &gens_p2, &j_p1x.name_p, &ret_p9, &fields_p5, &ctor_p8);
                    crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_body_f(jcp_p4.clone(), j_p1x.body_p.clone()), move |cpp_body_f_35981: crate::prelude::Text| {
                        let cycle_pb = crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("{}::prism_rtl::Turn<{}> {}::cycle() const", &gens_p2, &ret_p9, &head_p3)), &cpp_body_f_35981);
                        let start_pc = crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&crate::prelude::Text::from(format!("`Start {}, x`: what the function value is when passed to `@Run`.", &j_p1x.name_p))), &crate::prelude::Text::from(format!("{}::prism_rtl::JobRef<{}> {}({})", &gens_p2, &ret_p9, &j_p1x.start_p, &params_p6)), &crate::prelude::Text::from(format!("return ::prism_rtl::make_rc<{}>({});", &head_p3, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&j_p1x.fields_p, &(|(n_pj, _): &(crate::prelude::Text, crate::lower::model::OutTy)| crate::emit::cpp::field_id_f(n_pj))), &crate::prelude::Text::lit(", ")))));
                        let generic_pd = &crate::prelude::len(&j_p1x.generics_p) > &crate::prelude::Nat::from(0u32);
                        ::prism_rtl::Turn::Finished(Parts { forward_p: crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("{}struct {};", &gens_p2, &j_p1x.name_p))]), values_p: crate::prelude::Array::new(), protos_p: crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("{}::prism_rtl::JobRef<{}> {}({});", &gens_p2, &ret_p9, &j_p1x.start_p, &params_p6))]), classes_p: crate::prelude::Array::from(vec![decl_pa.clone()]), outer_p: crate::prelude::Array::new(), generic_p: if generic_pd {
                            crate::prelude::Array::from(vec![cycle_pb.clone(), start_pc.clone()])
                        } else {
                            crate::prelude::Array::new()
                        }, defs_p: if generic_pd {
                            crate::prelude::Array::new()
                        } else {
                            crate::prelude::Array::from(vec![cycle_pb.clone(), start_pc.clone()])
                        } })
                    })
                })
            })
        })
    }
}

/// `Start JobParts, x`: what the function value is when passed to `@Run`.
pub fn start_job_parts_f(cp_p0: crate::emit::cpp::Cp, j_p1: crate::lower::model::JobDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<Parts>> {
    ::std::rc::Rc::new(JobParts { cp_p0, j_p1 })
}

/// ```prism
/// TraitParts: unbounded fn Cp, TraitDef -> Parts
/// ```
pub fn trait_parts_f(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::TraitDef) -> Parts {
    let overloads_p2 = crate::prelude::filter(&t_p1.methods_p, &(|f_pc: &crate::lower::model::FnDef| !crate::emit::cpp::in_list_f(&t_p1.result_only_p, &f_pc.name_p)));
    let at_types_p3 = crate::prelude::filter(&t_p1.methods_p, &(|f_pd: &crate::lower::model::FnDef| crate::emit::cpp::in_list_f(&t_p1.result_only_p, &f_pd.name_p)));
    let defaults_p4 = crate::prelude::filter(&overloads_p2, &(|f_pe: &crate::lower::model::FnDef| f_pe.public_p));
    let defs_p5 = crate::prelude::run_to_end(crate::prelude::each_job(defaults_p4.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let f_pf = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(FnDefinition { cp_p0: cp_p0xy.clone(), f_p1: with_generics_f(&f_pf, &crate::prelude::Array::from(vec![(crate::prelude::Text::lit("Self"), crate::prelude::Array::new())])) }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    }));
    let at_defs_p6 = crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::filter(&at_types_p3, &(|f_pg: &crate::lower::model::FnDef| f_pg.public_p)), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let f_ph = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), f_ph.ret_p.clone()), move |cpp_type_f_38112: crate::prelude::Text| crate::prelude::call_then(start_cpp_params_f(cp_p0xy.clone(), f_ph.params_p.clone()), move |cpp_params_f_38162: crate::prelude::Text| crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_body_f(with_params_f(&cp_p0xy, &f_ph.params_p), f_ph.body_p.clone()), move |cpp_body_f_38190: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&f_ph.doc_p), &crate::prelude::Text::from(format!("template <class Self>\n{} {}_at<Self>::call({})", &cpp_type_f_38112, &crate::emit::cpp::cpp_id_f(&f_ph.name_p), &cpp_params_f_38162)), &cpp_body_f_38190)))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    }));
    let protos_p7 = crate::prelude::run_to_end(crate::prelude::each_job(overloads_p2.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let f_pi = p0;
                crate::prelude::call_then(start_fn_signature_f(cp_p0xy.clone(), with_generics_f(&f_pi, &crate::prelude::Array::from(vec![(crate::prelude::Text::lit("Self"), crate::prelude::Array::new())]))), move |fn_signature_f_38273: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{};", &fn_signature_f_38273, &(if f_pi.public_p {
                    crate::prelude::Text::lit("")
                } else {
                    crate::prelude::Text::lit(" = delete")
                })))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    }));
    let at_protos_p8 = crate::prelude::run_to_end(crate::prelude::each_job(crate::prelude::filter(&at_types_p3, &(|f_pj: &crate::lower::model::FnDef| f_pj.public_p)), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let f_pk = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), f_pk.ret_p.clone()), move |cpp_type_f_38493: crate::prelude::Text| crate::prelude::call_then(start_cpp_params_f(cp_p0xy.clone(), f_pk.params_p.clone()), move |cpp_params_f_38518: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("template <class Self>\nstruct {}_at {{\n    static {} call({});\n}};", &crate::emit::cpp::cpp_id_f(&f_pk.name_p), &cpp_type_f_38493, &cpp_params_f_38518)))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    }));
    let all_defs_p9 = crate::prelude::append(&defs_p5, &at_defs_p6);
    let generic_pa = if &crate::prelude::len(&all_defs_p9) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Array::new()
    } else {
        crate::prelude::Array::from(vec![crate::emit::cpp::templates::items::trait_namespace_f(&t_p1.name_p, &crate::syntax::lexer::chars::join_f(&all_defs_p9, &crate::prelude::Text::lit("\n")))])
    };
    let declared_pb = crate::prelude::append(&crate::prelude::each(&t_p1.assocs_p, &(|n_pl: &crate::prelude::Text| crate::prelude::Text::from(format!("template <class Self>\nstruct {};", n_pl)))), &crate::prelude::each(&at_types_p3, &(|f_pm: &crate::lower::model::FnDef| crate::prelude::Text::from(format!("template <class Self>\nstruct {}_at;", &crate::emit::cpp::cpp_id_f(&f_pm.name_p))))));
    let mut this: Parts = generic_only_f(&generic_pa);
    this.protos_p = crate::prelude::Array::from(vec![crate::emit::cpp::templates::items::trait_namespace_f(&t_p1.name_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::append(&protos_p7, &at_protos_p8), &crate::prelude::Text::lit("\n")))]);
    this.forward_p = if &crate::prelude::len(&declared_pb) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Array::new()
    } else {
        crate::prelude::Array::from(vec![crate::emit::cpp::templates::items::trait_namespace_f(&t_p1.name_p, &crate::syntax::lexer::chars::join_f(&declared_pb, &crate::prelude::Text::lit("\n")))])
    };
    this
}

/// The step machine of `TraitParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TraitParts: unbounded fn Cp, TraitDef -> Parts
/// ```
pub struct TraitParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::TraitDef,
}

impl ::prism_rtl::Job<Parts> for TraitParts {
    fn cycle(&self) -> ::prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        let overloads_p2 = crate::prelude::filter(&t_p1.methods_p, &(|f_pc: &crate::lower::model::FnDef| !crate::emit::cpp::in_list_f(&t_p1.result_only_p, &f_pc.name_p)));
        let at_types_p3 = crate::prelude::filter(&t_p1.methods_p, &(|f_pd: &crate::lower::model::FnDef| crate::emit::cpp::in_list_f(&t_p1.result_only_p, &f_pd.name_p)));
        let defaults_p4 = crate::prelude::filter(&overloads_p2, &(|f_pe: &crate::lower::model::FnDef| f_pe.public_p));
        let cp_p0x = cp_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(defaults_p4.clone(), {
            let cp_p0xx = cp_p0x.clone();
            ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let f_pf = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(FnDefinition { cp_p0: cp_p0xxy.clone(), f_p1: with_generics_f(&f_pf, &crate::prelude::Array::from(vec![(crate::prelude::Text::lit("Self"), crate::prelude::Array::new())])) }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
        }), move |each_37923: crate::prelude::Array<crate::prelude::Text>| {
            let defs_p5 = each_37923;
            crate::prelude::call_value(crate::prelude::each_job(crate::prelude::filter(&at_types_p3, &(|f_pg: &crate::lower::model::FnDef| f_pg.public_p)), {
                let cp_p0xx = cp_p0x.clone();
                ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| {
                    let cp_p0xxy = cp_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_ph = p0;
                        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), f_ph.ret_p.clone()), move |cpp_type_f_38112: crate::prelude::Text| crate::prelude::call_then(start_cpp_params_f(cp_p0xxy.clone(), f_ph.params_p.clone()), move |cpp_params_f_38162: crate::prelude::Text| crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_body_f(with_params_f(&cp_p0xxy, &f_ph.params_p), f_ph.body_p.clone()), move |cpp_body_f_38190: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&f_ph.doc_p), &crate::prelude::Text::from(format!("template <class Self>\n{} {}_at<Self>::call({})", &cpp_type_f_38112, &crate::emit::cpp::cpp_id_f(&f_ph.name_p), &cpp_params_f_38162)), &cpp_body_f_38190)))))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            }), move |each_38016: crate::prelude::Array<crate::prelude::Text>| {
                let at_defs_p6 = each_38016;
                crate::prelude::call_value(crate::prelude::each_job(overloads_p2.clone(), {
                    let cp_p0xx = cp_p0x.clone();
                    ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| {
                        let cp_p0xxy = cp_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let f_pi = p0;
                            crate::prelude::call_then(start_fn_signature_f(cp_p0xxy.clone(), with_generics_f(&f_pi, &crate::prelude::Array::from(vec![(crate::prelude::Text::lit("Self"), crate::prelude::Array::new())]))), move |fn_signature_f_38273: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{};", &fn_signature_f_38273, &(if f_pi.public_p {
                                crate::prelude::Text::lit("")
                            } else {
                                crate::prelude::Text::lit(" = delete")
                            })))))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                }), move |each_38250: crate::prelude::Array<crate::prelude::Text>| {
                    let protos_p7 = each_38250;
                    crate::prelude::call_value(crate::prelude::each_job(crate::prelude::filter(&at_types_p3, &(|f_pj: &crate::lower::model::FnDef| f_pj.public_p)), {
                        let cp_p0xx = cp_p0x.clone();
                        ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| {
                            let cp_p0xxy = cp_p0xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let f_pk = p0;
                                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), f_pk.ret_p.clone()), move |cpp_type_f_38493: crate::prelude::Text| crate::prelude::call_then(start_cpp_params_f(cp_p0xxy.clone(), f_pk.params_p.clone()), move |cpp_params_f_38518: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("template <class Self>\nstruct {}_at {{\n    static {} call({});\n}};", &crate::emit::cpp::cpp_id_f(&f_pk.name_p), &cpp_type_f_38493, &cpp_params_f_38518)))))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                    }), move |each_38385: crate::prelude::Array<crate::prelude::Text>| {
                        let at_protos_p8 = each_38385;
                        let all_defs_p9 = crate::prelude::append(&defs_p5, &at_defs_p6);
                        let generic_pa = if &crate::prelude::len(&all_defs_p9) == &crate::prelude::Nat::from(0u32) {
                            crate::prelude::Array::new()
                        } else {
                            crate::prelude::Array::from(vec![crate::emit::cpp::templates::items::trait_namespace_f(&t_p1x.name_p, &crate::syntax::lexer::chars::join_f(&all_defs_p9, &crate::prelude::Text::lit("\n")))])
                        };
                        let declared_pb = crate::prelude::append(&crate::prelude::each(&t_p1x.assocs_p, &(|n_pl: &crate::prelude::Text| crate::prelude::Text::from(format!("template <class Self>\nstruct {};", n_pl)))), &crate::prelude::each(&at_types_p3, &(|f_pm: &crate::lower::model::FnDef| crate::prelude::Text::from(format!("template <class Self>\nstruct {}_at;", &crate::emit::cpp::cpp_id_f(&f_pm.name_p))))));
                        ::prism_rtl::Turn::Finished({
                            let mut this: Parts = generic_only_f(&generic_pa);
                            this.protos_p = crate::prelude::Array::from(vec![crate::emit::cpp::templates::items::trait_namespace_f(&t_p1x.name_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::append(&protos_p7, &at_protos_p8), &crate::prelude::Text::lit("\n")))]);
                            this.forward_p = if &crate::prelude::len(&declared_pb) == &crate::prelude::Nat::from(0u32) {
                                crate::prelude::Array::new()
                            } else {
                                crate::prelude::Array::from(vec![crate::emit::cpp::templates::items::trait_namespace_f(&t_p1x.name_p, &crate::syntax::lexer::chars::join_f(&declared_pb, &crate::prelude::Text::lit("\n")))])
                            };
                            this
                        })
                    })
                })
            })
        })
    }
}

/// `Start TraitParts, x`: what the function value is when passed to `@Run`.
pub fn start_trait_parts_f(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::TraitDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<Parts>> {
    ::std::rc::Rc::new(TraitParts { cp_p0, t_p1 })
}

/// ```prism
/// ImplParts: unbounded fn Cp, ImplDef -> Parts
/// ```
pub fn impl_parts_f(cp_p0: &crate::emit::cpp::Cp, i_p1: &crate::lower::model::ImplDef) -> Parts {
    let head_p2 = crate::emit::cpp::cpp_type_f(cp_p0, &i_p1.head_p);
    let gens_p3 = cpp_template_head_f(&generic_names_of_f(&i_p1.generics_p));
    let fns_p4 = crate::prelude::run_to_end(crate::prelude::each_job(i_p1.methods_p.clone(), {
        let cp_p0x = cp_p0.clone();
        let i_p1x = i_p1.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| {
            let cp_p0xy = cp_p0x.clone();
            let i_p1xy = i_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let f_p6 = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(FnParts { cp_p0: cp_p0xy.clone(), f_p1: with_generics_f(&f_p6, &i_p1xy.generics_p) }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<Parts>>>
    }));
    let own_p5 = crate::prelude::fold(&fns_p4, &no_parts_p(), &(|acc_p7: &Parts, p_p8: &Parts| join_parts_f(acc_p7, p_p8)));
    match &i_p1.cls_p {
        m39769_0 if (m39769_0 == &crate::prelude::Text::lit("Prelude.Show")) => {
            let shown_p9 = crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&i_p1.methods_p, &(|f_pa: &crate::lower::model::FnDef| f_pa.name_p.clone())), &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("show"));
            join_parts_f(&own_p5, &protos_defs_f(&crate::prelude::Array::new(), &crate::prelude::Array::from(vec![crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("{}void {}::show(crate::prelude::Printer& p) const", &gens_p3, &head_p2)), &crate::prelude::Text::from(format!("p.raw({}(*this).to_string());", &shown_p9)))])))
        },
        m39769_1 if (m39769_1 == &crate::prelude::Text::lit("Prelude.Eq")) => {
            let eq_pb = crate::prelude::fold(&i_p1.methods_p, &crate::prelude::Text::lit(""), &(|acc_pc: &crate::prelude::Text, f_pd: &crate::lower::model::FnDef| if !crate::syntax::lexer::chars::has_prefix_f(&f_pd.name_p, &crate::prelude::Text::lit("ne")) && (acc_pc == &crate::prelude::Text::lit("")) {
                f_pd.name_p.clone()
            } else {
                acc_pc.clone()
            }));
            join_parts_f(&own_p5, &protos_defs_f(&crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("{}bool operator==(const {}& a, const {}& b);", &gens_p3, &head_p2, &head_p2))]), &crate::prelude::Array::from(vec![crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("{}bool operator==(const {}& a, const {}& b)", &gens_p3, &head_p2, &head_p2)), &crate::prelude::Text::from(format!("return {}(a, b);", &eq_pb)))])))
        },
        _ => {
            let tr_pe = crate::syntax::lexer::chars::drop_prefix_f(&crate::emit::cpp::type_path_f(&i_p1.tr_p), &crate::prelude::Text::lit("crate::"));
            let own_pf = !crate::syntax::lexer::chars::contains_f(&tr_pe, &crate::prelude::Text::lit("::"));
            let ns_pg = if own_pf {
                tr_pe.clone()
            } else {
                crate::prelude::Text::from(format!("impl_{}", &crate::syntax::lexer::chars::join_f(&crate::prelude::split_on(&tr_pe, &crate::prelude::Text::lit("::")), &crate::prelude::Text::lit("_"))))
            };
            let overloads_ph = crate::prelude::filter(&i_p1.methods_p, &(|f_pt: &crate::lower::model::FnDef| !crate::emit::cpp::in_list_f(&i_p1.result_only_p, &f_pt.name_p)));
            let at_types_pi = crate::prelude::filter(&i_p1.methods_p, &(|f_pu: &crate::lower::model::FnDef| crate::emit::cpp::in_list_f(&i_p1.result_only_p, &f_pu.name_p)));
            let in_trait_pj = crate::prelude::run_to_end(crate::prelude::each_job(overloads_ph.clone(), {
                let ns_pgx = ns_pg.clone();
                let cp_p0x = cp_p0.clone();
                let i_p1x = i_p1.clone();
                ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| {
                    let ns_pgxy = ns_pgx.clone();
                    let cp_p0xy = cp_p0x.clone();
                    let i_p1xy = i_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_pv = p0;
                        crate::prelude::call_then(start_fn_definition_f(cp_p0xy.clone(), with_generics_f(&f_pv, &i_p1xy.generics_p)), move |fn_definition_f_40814: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::trait_namespace_f(&ns_pgxy, &fn_definition_f_40814)))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            }));
            let protos_pk = crate::prelude::run_to_end(crate::prelude::each_job(overloads_ph.clone(), {
                let ns_pgx = ns_pg.clone();
                let cp_p0x = cp_p0.clone();
                let i_p1x = i_p1.clone();
                ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| {
                    let ns_pgxy = ns_pgx.clone();
                    let cp_p0xy = cp_p0x.clone();
                    let i_p1xy = i_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_p10 = p0;
                        crate::prelude::call_then(start_fn_signature_f(cp_p0xy.clone(), with_generics_f(&f_p10, &i_p1xy.generics_p)), move |fn_signature_f_40928: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::trait_namespace_f(&ns_pgxy, &crate::prelude::Text::from(format!("{};", &fn_signature_f_40928)))))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            }));
            let spec_pl = if &gens_p3 == &crate::prelude::Text::lit("") {
                crate::prelude::Text::lit("template <>\n")
            } else {
                gens_p3.clone()
            };
            let chosen_pm = crate::prelude::run_to_end(crate::prelude::each_job(i_p1.assocs_p.clone(), {
                let spec_plx = spec_pl.clone();
                let head_p2x = head_p2.clone();
                let cp_p0x = cp_p0.clone();
                ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| {
                    let spec_plxy = spec_plx.clone();
                    let head_p2xy = head_p2x.clone();
                    let cp_p0xy = cp_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (n_p11, at_p12) = p0;
                        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), at_p12.clone()), move |cpp_type_f_41457: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}struct {}<{}> {{ using type = {}; }};", &spec_plxy, &n_p11, &head_p2xy, &cpp_type_f_41457))))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            }));
            let at_specs_pn = crate::prelude::run_to_end(crate::prelude::each_job(at_types_pi.clone(), {
                let cp_p0x = cp_p0.clone();
                let own_pfx = own_pf;
                let spec_plx = spec_pl.clone();
                let head_p2x = head_p2.clone();
                ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| {
                    let cp_p0xy = cp_p0x.clone();
                    let own_pfxy = own_pfx;
                    let spec_plxy = spec_plx.clone();
                    let head_p2xy = head_p2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_p13 = p0;
                        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), f_p13.ret_p.clone()), move |cpp_type_f_41560: crate::prelude::Text| crate::prelude::call_then(start_cpp_params_f(cp_p0xy.clone(), f_p13.params_p.clone()), move |cpp_params_f_41585: crate::prelude::Text| {
                            let call_p14 = crate::prelude::Text::from(format!("static {} call({})", &cpp_type_f_41560, &cpp_params_f_41585));
                            if own_pfxy {
                                ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}struct {}_at<{}> {{\n    {};\n}};", &spec_plxy, &crate::emit::cpp::cpp_id_f(&f_p13.name_p), &head_p2xy, &call_p14)))
                            } else {
                                crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_body_f(with_params_f(&cp_p0xy, &f_p13.params_p), f_p13.body_p.clone()), move |cpp_body_f_41791: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}struct {}_at<{}> {{\n    {}\n}};", &spec_plxy, &crate::emit::cpp::cpp_id_f(&f_p13.name_p), &head_p2xy, &crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &call_p14, &cpp_body_f_41791)))))
                            }
                        }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            }));
            let at_defs_po = if own_pf {
                crate::prelude::run_to_end(crate::prelude::each_job(at_types_pi.clone(), {
                    let ns_pgx = ns_pg.clone();
                    let gens_p3x = gens_p3.clone();
                    let cp_p0x = cp_p0.clone();
                    let head_p2x = head_p2.clone();
                    ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| {
                        let ns_pgxy = ns_pgx.clone();
                        let gens_p3xy = gens_p3x.clone();
                        let cp_p0xy = cp_p0x.clone();
                        let head_p2xy = head_p2x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let f_p15 = p0;
                            crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), f_p15.ret_p.clone()), move |cpp_type_f_41949: crate::prelude::Text| crate::prelude::call_then(start_cpp_params_f(cp_p0xy.clone(), f_p15.params_p.clone()), move |cpp_params_f_42001: crate::prelude::Text| crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_body_f(with_params_f(&cp_p0xy, &f_p15.params_p), f_p15.body_p.clone()), move |cpp_body_f_42029: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::trait_namespace_f(&ns_pgxy, &crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&f_p15.doc_p), &crate::prelude::Text::from(format!("{}{} {}_at<{}>::call({})", &gens_p3xy, &cpp_type_f_41949, &crate::emit::cpp::cpp_id_f(&f_p15.name_p), &head_p2xy, &cpp_params_f_42001)), &cpp_body_f_42029))))))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                }))
            } else {
                crate::prelude::Array::new()
            };
            let spec_lines_pp = crate::prelude::append(&chosen_pm, &at_specs_pn);
            let specs_pq = if &crate::prelude::len(&spec_lines_pp) == &crate::prelude::Nat::from(0u32) {
                crate::prelude::Array::new()
            } else {
                crate::prelude::Array::from(vec![crate::emit::cpp::templates::items::trait_namespace_f(&tr_pe, &crate::syntax::lexer::chars::join_f(&spec_lines_pp, &crate::prelude::Text::lit("\n")))])
            };
            let outer_pr = if own_pf || (&crate::prelude::len(&overloads_ph) == &crate::prelude::Nat::from(0u32)) {
                crate::prelude::Array::new()
            } else {
                crate::prelude::Array::from(vec![crate::emit::cpp::templates::items::trait_namespace_f(&tr_pe, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&overloads_ph, &(|f_p16: &crate::lower::model::FnDef| crate::prelude::Text::from(format!("using ::crate::{}::{}::{};", &cp_p0.home_p, &ns_pg, &crate::emit::cpp::cpp_id_f(&f_p16.name_p))))), &crate::prelude::Text::lit("\n")))])
            };
            let parts_ps = protos_defs_f(&(if own_pf { crate::prelude::append(&specs_pq, &protos_pk) } else { protos_pk.clone() }), &(if &gens_p3 == &crate::prelude::Text::lit("") {
                crate::prelude::append(&in_trait_pj, &at_defs_po)
            } else {
                in_trait_pj.clone()
            }));
            {
                let mut this: Parts = parts_ps.clone();
                this.outer_p = if own_pf { outer_pr.clone() } else { crate::prelude::append(&specs_pq, &outer_pr) };
                this.generic_p = if &gens_p3 == &crate::prelude::Text::lit("") {
                    crate::prelude::Array::new()
                } else {
                    at_defs_po.clone()
                };
                this
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ImplParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ImplParts: unbounded fn Cp, ImplDef -> Parts
/// ```
pub struct ImplParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub i_p1: crate::lower::model::ImplDef,
}

impl ::prism_rtl::Job<Parts> for ImplParts {
    fn cycle(&self) -> ::prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let i_p1 = &self.i_p1;
        let cp_p0x = cp_p0.clone();
        let i_p1x = i_p1.clone();
        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), i_p1x.head_p.clone()), move |cpp_type_f_39551: crate::prelude::Text| {
            let head_p2 = cpp_type_f_39551;
            let gens_p3 = cpp_template_head_f(&generic_names_of_f(&i_p1x.generics_p));
            crate::prelude::call_value(crate::prelude::each_job(i_p1x.methods_p.clone(), {
                let cp_p0xx = cp_p0x.clone();
                let i_p1xx = i_p1x.clone();
                ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| {
                    let cp_p0xxy = cp_p0xx.clone();
                    let i_p1xxy = i_p1xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_p6 = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(FnParts { cp_p0: cp_p0xxy.clone(), f_p1: with_generics_f(&f_p6, &i_p1xxy.generics_p) }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<Parts>>>
            }), move |each_39643: crate::prelude::Array<Parts>| {
                let fns_p4 = each_39643;
                let own_p5 = crate::prelude::fold(&fns_p4, &no_parts_p(), &(|acc_p7: &Parts, p_p8: &Parts| join_parts_f(acc_p7, p_p8)));
                match &i_p1x.cls_p {
                    m39769_0 if (m39769_0 == &crate::prelude::Text::lit("Prelude.Show")) => {
                        let shown_p9 = crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&i_p1x.methods_p, &(|f_pa: &crate::lower::model::FnDef| f_pa.name_p.clone())), &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("show"));
                        ::prism_rtl::Turn::Finished(join_parts_f(&own_p5, &protos_defs_f(&crate::prelude::Array::new(), &crate::prelude::Array::from(vec![crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("{}void {}::show(crate::prelude::Printer& p) const", &gens_p3, &head_p2)), &crate::prelude::Text::from(format!("p.raw({}(*this).to_string());", &shown_p9)))]))))
                    },
                    m39769_1 if (m39769_1 == &crate::prelude::Text::lit("Prelude.Eq")) => {
                        let eq_pb = crate::prelude::fold(&i_p1x.methods_p, &crate::prelude::Text::lit(""), &(|acc_pc: &crate::prelude::Text, f_pd: &crate::lower::model::FnDef| if !crate::syntax::lexer::chars::has_prefix_f(&f_pd.name_p, &crate::prelude::Text::lit("ne")) && (acc_pc == &crate::prelude::Text::lit("")) {
                            f_pd.name_p.clone()
                        } else {
                            acc_pc.clone()
                        }));
                        ::prism_rtl::Turn::Finished(join_parts_f(&own_p5, &protos_defs_f(&crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("{}bool operator==(const {}& a, const {}& b);", &gens_p3, &head_p2, &head_p2))]), &crate::prelude::Array::from(vec![crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::from(format!("{}bool operator==(const {}& a, const {}& b)", &gens_p3, &head_p2, &head_p2)), &crate::prelude::Text::from(format!("return {}(a, b);", &eq_pb)))]))))
                    },
                    _ => {
                        let tr_pe = crate::syntax::lexer::chars::drop_prefix_f(&crate::emit::cpp::type_path_f(&i_p1x.tr_p), &crate::prelude::Text::lit("crate::"));
                        let own_pf = !crate::syntax::lexer::chars::contains_f(&tr_pe, &crate::prelude::Text::lit("::"));
                        let ns_pg = if own_pf {
                            tr_pe.clone()
                        } else {
                            crate::prelude::Text::from(format!("impl_{}", &crate::syntax::lexer::chars::join_f(&crate::prelude::split_on(&tr_pe, &crate::prelude::Text::lit("::")), &crate::prelude::Text::lit("_"))))
                        };
                        let overloads_ph = crate::prelude::filter(&i_p1x.methods_p, &(|f_pt: &crate::lower::model::FnDef| !crate::emit::cpp::in_list_f(&i_p1x.result_only_p, &f_pt.name_p)));
                        let at_types_pi = crate::prelude::filter(&i_p1x.methods_p, &(|f_pu: &crate::lower::model::FnDef| crate::emit::cpp::in_list_f(&i_p1x.result_only_p, &f_pu.name_p)));
                        crate::prelude::call_value(crate::prelude::each_job(overloads_ph.clone(), {
                            let ns_pgx = ns_pg.clone();
                            let cp_p0xx = cp_p0x.clone();
                            let i_p1xx = i_p1x.clone();
                            ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| {
                                let ns_pgxy = ns_pgx.clone();
                                let cp_p0xxy = cp_p0xx.clone();
                                let i_p1xxy = i_p1xx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let f_pv = p0;
                                    crate::prelude::call_then(start_fn_definition_f(cp_p0xxy.clone(), with_generics_f(&f_pv, &i_p1xxy.generics_p)), move |fn_definition_f_40814: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::trait_namespace_f(&ns_pgxy, &fn_definition_f_40814)))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                        }), move |each_40773: crate::prelude::Array<crate::prelude::Text>| {
                            let in_trait_pj = each_40773;
                            crate::prelude::call_value(crate::prelude::each_job(overloads_ph.clone(), {
                                let ns_pgx = ns_pg.clone();
                                let cp_p0xx = cp_p0x.clone();
                                let i_p1xx = i_p1x.clone();
                                ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| {
                                    let ns_pgxy = ns_pgx.clone();
                                    let cp_p0xxy = cp_p0xx.clone();
                                    let i_p1xxy = i_p1xx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let f_p10 = p0;
                                        crate::prelude::call_then(start_fn_signature_f(cp_p0xxy.clone(), with_generics_f(&f_p10, &i_p1xxy.generics_p)), move |fn_signature_f_40928: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::trait_namespace_f(&ns_pgxy, &crate::prelude::Text::from(format!("{};", &fn_signature_f_40928)))))
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                            }), move |each_40886: crate::prelude::Array<crate::prelude::Text>| {
                                let protos_pk = each_40886;
                                let spec_pl = if &gens_p3 == &crate::prelude::Text::lit("") {
                                    crate::prelude::Text::lit("template <>\n")
                                } else {
                                    gens_p3.clone()
                                };
                                crate::prelude::call_value(crate::prelude::each_job(i_p1x.assocs_p.clone(), {
                                    let spec_plx = spec_pl.clone();
                                    let head_p2x = head_p2.clone();
                                    let cp_p0xx = cp_p0x.clone();
                                    ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| {
                                        let spec_plxy = spec_plx.clone();
                                        let head_p2xy = head_p2x.clone();
                                        let cp_p0xxy = cp_p0xx.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let (n_p11, at_p12) = p0;
                                            crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), at_p12.clone()), move |cpp_type_f_41457: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}struct {}<{}> {{ using type = {}; }};", &spec_plxy, &n_p11, &head_p2xy, &cpp_type_f_41457))))
                                        }))
                                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                                }), move |each_41386: crate::prelude::Array<crate::prelude::Text>| {
                                    let chosen_pm = each_41386;
                                    crate::prelude::call_value(crate::prelude::each_job(at_types_pi.clone(), {
                                        let cp_p0xx = cp_p0x.clone();
                                        let own_pfx = own_pf;
                                        let spec_plx = spec_pl.clone();
                                        let head_p2x = head_p2.clone();
                                        ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| {
                                            let cp_p0xxy = cp_p0xx.clone();
                                            let own_pfxy = own_pfx;
                                            let spec_plxy = spec_plx.clone();
                                            let head_p2xy = head_p2x.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let f_p13 = p0;
                                                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), f_p13.ret_p.clone()), move |cpp_type_f_41560: crate::prelude::Text| crate::prelude::call_then(start_cpp_params_f(cp_p0xxy.clone(), f_p13.params_p.clone()), move |cpp_params_f_41585: crate::prelude::Text| {
                                                    let call_p14 = crate::prelude::Text::from(format!("static {} call({})", &cpp_type_f_41560, &cpp_params_f_41585));
                                                    if own_pfxy {
                                                        ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}struct {}_at<{}> {{\n    {};\n}};", &spec_plxy, &crate::emit::cpp::cpp_id_f(&f_p13.name_p), &head_p2xy, &call_p14)))
                                                    } else {
                                                        crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_body_f(with_params_f(&cp_p0xxy, &f_p13.params_p), f_p13.body_p.clone()), move |cpp_body_f_41791: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}struct {}_at<{}> {{\n    {}\n}};", &spec_plxy, &crate::emit::cpp::cpp_id_f(&f_p13.name_p), &head_p2xy, &crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &call_p14, &cpp_body_f_41791)))))
                                                    }
                                                }))
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                                    }), move |each_41505: crate::prelude::Array<crate::prelude::Text>| {
                                        let at_specs_pn = each_41505;
                                        let at_specs_pnz = at_specs_pn.clone();
                                        let chosen_pmz = chosen_pm.clone();
                                        let cp_p0xz = cp_p0x.clone();
                                        let gens_p3z = gens_p3.clone();
                                        let in_trait_pjz = in_trait_pj.clone();
                                        let ns_pgz = ns_pg.clone();
                                        let overloads_phz = overloads_ph.clone();
                                        let own_pfz = own_pf;
                                        let protos_pkz = protos_pk.clone();
                                        let tr_pez = tr_pe.clone();
                                        let k_let41853 = move |v41853: crate::prelude::Array<crate::prelude::Text>| {
                                            let at_defs_po = v41853;
                                            let spec_lines_pp = crate::prelude::append(&chosen_pmz, &at_specs_pnz);
                                            let specs_pq = if &crate::prelude::len(&spec_lines_pp) == &crate::prelude::Nat::from(0u32) {
                                                crate::prelude::Array::new()
                                            } else {
                                                crate::prelude::Array::from(vec![crate::emit::cpp::templates::items::trait_namespace_f(&tr_pez, &crate::syntax::lexer::chars::join_f(&spec_lines_pp, &crate::prelude::Text::lit("\n")))])
                                            };
                                            let outer_pr = if own_pfz || (&crate::prelude::len(&overloads_phz) == &crate::prelude::Nat::from(0u32)) {
                                                crate::prelude::Array::new()
                                            } else {
                                                crate::prelude::Array::from(vec![crate::emit::cpp::templates::items::trait_namespace_f(&tr_pez, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&overloads_phz, &(|f_p16: &crate::lower::model::FnDef| crate::prelude::Text::from(format!("using ::crate::{}::{}::{};", &cp_p0xz.home_p, &ns_pgz, &crate::emit::cpp::cpp_id_f(&f_p16.name_p))))), &crate::prelude::Text::lit("\n")))])
                                            };
                                            let parts_ps = protos_defs_f(&(if own_pfz {
                                                crate::prelude::append(&specs_pq, &protos_pkz)
                                            } else {
                                                protos_pkz.clone()
                                            }), &(if &gens_p3z == &crate::prelude::Text::lit("") {
                                                crate::prelude::append(&in_trait_pjz, &at_defs_po)
                                            } else {
                                                in_trait_pjz.clone()
                                            }));
                                            ::prism_rtl::Turn::Finished({
                                                let mut this: Parts = parts_ps.clone();
                                                this.outer_p = if own_pfz { outer_pr.clone() } else { crate::prelude::append(&specs_pq, &outer_pr) };
                                                this.generic_p = if &gens_p3z == &crate::prelude::Text::lit("") {
                                                    crate::prelude::Array::new()
                                                } else {
                                                    at_defs_po.clone()
                                                };
                                                this
                                            })
                                        };
                                        if own_pf {
                                            crate::prelude::call_value(crate::prelude::each_job(at_types_pi.clone(), {
                                                let ns_pgx = ns_pg.clone();
                                                let gens_p3x = gens_p3.clone();
                                                let cp_p0xx = cp_p0x.clone();
                                                let head_p2x = head_p2.clone();
                                                ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| {
                                                    let ns_pgxy = ns_pgx.clone();
                                                    let gens_p3xy = gens_p3x.clone();
                                                    let cp_p0xxy = cp_p0xx.clone();
                                                    let head_p2xy = head_p2x.clone();
                                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                                        let f_p15 = p0;
                                                        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), f_p15.ret_p.clone()), move |cpp_type_f_41949: crate::prelude::Text| crate::prelude::call_then(start_cpp_params_f(cp_p0xxy.clone(), f_p15.params_p.clone()), move |cpp_params_f_42001: crate::prelude::Text| crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_body_f(with_params_f(&cp_p0xxy, &f_p15.params_p), f_p15.body_p.clone()), move |cpp_body_f_42029: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::trait_namespace_f(&ns_pgxy, &crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&f_p15.doc_p), &crate::prelude::Text::from(format!("{}{} {}_at<{}>::call({})", &gens_p3xy, &cpp_type_f_41949, &crate::emit::cpp::cpp_id_f(&f_p15.name_p), &head_p2xy, &cpp_params_f_42001)), &cpp_body_f_42029))))))
                                                    }))
                                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                                            }), move |each_41874: crate::prelude::Array<crate::prelude::Text>| k_let41853(each_41874))
                                        } else {
                                            k_let41853(crate::prelude::Array::new())
                                        }
                                    })
                                })
                            })
                        })
                    },
                    _ => unreachable!("no arm matched"),
                }
            })
        })
    }
}

/// `Start ImplParts, x`: what the function value is when passed to `@Run`.
pub fn start_impl_parts_f(cp_p0: crate::emit::cpp::Cp, i_p1: crate::lower::model::ImplDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<Parts>> {
    ::std::rc::Rc::new(ImplParts { cp_p0, i_p1 })
}

/// ```prism
/// PackedParts: unbounded fn Cp, PackedDef -> Parts
/// ```
pub fn packed_parts_f(cp_p0: &crate::emit::cpp::Cp, d_p1: &crate::lower::model::PackedDef) -> Parts {
    let dictionary_p2 = crate::prelude::Text::from(format!("{}_packed", &d_p1.name_p));
    let maker_p3 = crate::prelude::Text::from(format!("{}_of_t", &dictionary_p2));
    let fields_p4 = crate::prelude::run_to_end(crate::prelude::each_job(d_p1.methods_p.clone(), {
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::PackedMethod| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_pa = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), m_pa.method_p.ret_p.clone()), move |cpp_type_f_43445: crate::prelude::Text| crate::prelude::call_value(crate::prelude::each_job(m_pa.method_p.params_p.clone(), {
                    let cp_p0xyx = cp_p0xy.clone();
                    ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| {
                        let cp_p0xyxy = cp_p0xyx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (_, t_pb) = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::cpp::expr::ParamType { cp_p0: cp_p0xyxy.clone(), t_p1: t_pb.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                }), move |each_43503: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("    {} (*{})({});", &cpp_type_f_43445, &crate::emit::cpp::cpp_id_f(&m_pa.method_p.name_p), &crate::syntax::lexer::chars::join_f(&each_43503, &crate::prelude::Text::lit(", ")))))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::PackedMethod) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    }));
    let entries_p5 = crate::prelude::run_to_end(crate::prelude::each_job(d_p1.methods_p.clone(), {
        let d_p1x = d_p1.clone();
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::PackedMethod| {
            let d_p1xy = d_p1x.clone();
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_pc = p0;
                {
                    let names_pd = crate::prelude::each(&m_pc.method_p.params_p, &(|(n_pg, _): &(crate::prelude::Text, crate::lower::model::OutTy)| crate::emit::cpp::cpp_id_f(n_pg)));
                    let args_pe = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&names_pd)), &(|i_ph: &crate::prelude::Nat| if crate::prelude::or(&crate::prelude::index(&m_pc.hidden_p, i_ph), &false) {
                        crate::prelude::Text::from(format!("{}.template held<T>()", &crate::prelude::or(&crate::prelude::index(&names_pd, i_ph), &crate::prelude::Text::lit(""))))
                    } else {
                        crate::prelude::or(&crate::prelude::index(&names_pd, i_ph), &crate::prelude::Text::lit(""))
                    }));
                    let call_pf = crate::prelude::Text::from(format!("{}::{}({})", &d_p1xy.name_p, &crate::emit::cpp::cpp_id_f(&m_pc.method_p.name_p), &crate::syntax::lexer::chars::join_f(&args_pe, &crate::prelude::Text::lit(", "))));
                    crate::prelude::call_then(start_cpp_params_f(cp_p0xy.clone(), m_pc.method_p.params_p.clone()), move |cpp_params_f_43907: crate::prelude::Text| crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), m_pc.method_p.ret_p.clone()), move |cpp_type_f_43943: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("        +[]({}) -> {} {{ return {}; }},", &cpp_params_f_43907, &cpp_type_f_43943, &(if m_pc.hidden_result_p {
                        crate::prelude::Text::from(format!("{}.repacked({})", &crate::emit::cpp::cpp_id_f(&packed_first_hidden_cpp_f(&m_pc)), &call_pf))
                    } else {
                        call_pf.clone()
                    }))))))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::PackedMethod) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    }));
    let declared_p6 = crate::prelude::Text::from(format!("/// The dictionary of `{}` an existential keeps: each method over packed values.\nstruct {} {{\n{}\n}};\n/// The dictionary of `{}` at the type of a value.\nstruct {} {{\n    template <class T>\n    {} operator()(const T&) const;\n}};\ninline constexpr {} {}_packed_of{{}};", &d_p1.name_p, &dictionary_p2, &crate::syntax::lexer::chars::join_f(&fields_p4, &crate::prelude::Text::lit("\n")), &d_p1.name_p, &maker_p3, &dictionary_p2, &maker_p3, &crate::prelude::lower(&d_p1.name_p)));
    let made_p7 = crate::prelude::Text::from(format!("template <class T>\n{} {}::operator()(const T&) const {{\n    return {}{{\n{}\n    }};\n}}", &dictionary_p2, &maker_p3, &dictionary_p2, &crate::syntax::lexer::chars::join_f(&entries_p5, &crate::prelude::Text::lit("\n"))));
    let protos_p8 = crate::prelude::run_to_end(crate::prelude::each_job(d_p1.methods_p.clone(), {
        let d_p1x = d_p1.clone();
        let cp_p0x = cp_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::PackedMethod| {
            let d_p1xy = d_p1x.clone();
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_pi = p0;
                crate::prelude::call_then(start_fn_signature_f(cp_p0xy.clone(), m_pi.method_p.clone()), move |fn_signature_f_44649: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::trait_namespace_f(&d_p1xy.name_p, &crate::prelude::Text::from(format!("{};", &fn_signature_f_44649)))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::PackedMethod) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    }));
    let defs_p9 = crate::prelude::run_to_end(crate::prelude::each_job(d_p1.methods_p.clone(), {
        let d_p1x = d_p1.clone();
        let cp_p0x = cp_p0.clone();
        let dictionary_p2x = dictionary_p2.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::PackedMethod| {
            let d_p1xy = d_p1x.clone();
            let cp_p0xy = cp_p0x.clone();
            let dictionary_p2xy = dictionary_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_pj = p0;
                crate::prelude::call_then(start_fn_signature_f(cp_p0xy.clone(), m_pj.method_p.clone()), move |fn_signature_f_44754: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::trait_namespace_f(&d_p1xy.name_p, &crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &fn_signature_f_44754, &crate::prelude::Text::from(format!("return {}.template dictionary<{}>().{}({});", &crate::emit::cpp::cpp_id_f(&packed_first_hidden_cpp_f(&m_pj)), &dictionary_p2xy, &crate::emit::cpp::cpp_id_f(&m_pj.method_p.name_p), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&m_pj.method_p.params_p, &(|(n_pk, _): &(crate::prelude::Text, crate::lower::model::OutTy)| crate::emit::cpp::cpp_id_f(n_pk))), &crate::prelude::Text::lit(", "))))))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::PackedMethod) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    }));
    let mut this: Parts = protos_defs_f(&crate::prelude::append(&crate::prelude::Array::from(vec![declared_p6.clone()]), &protos_p8), &defs_p9);
    this.generic_p = crate::prelude::Array::from(vec![made_p7.clone()]);
    this
}

/// The step machine of `PackedParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PackedParts: unbounded fn Cp, PackedDef -> Parts
/// ```
pub struct PackedParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub d_p1: crate::lower::model::PackedDef,
}

impl ::prism_rtl::Job<Parts> for PackedParts {
    fn cycle(&self) -> ::prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let d_p1 = &self.d_p1;
        let dictionary_p2 = crate::prelude::Text::from(format!("{}_packed", &d_p1.name_p));
        let maker_p3 = crate::prelude::Text::from(format!("{}_of_t", &dictionary_p2));
        let cp_p0x = cp_p0.clone();
        let d_p1x = d_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(d_p1x.methods_p.clone(), {
            let cp_p0xx = cp_p0x.clone();
            ::std::rc::Rc::new(move |p0: crate::lower::model::PackedMethod| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let m_pa = p0;
                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), m_pa.method_p.ret_p.clone()), move |cpp_type_f_43445: crate::prelude::Text| crate::prelude::call_value(crate::prelude::each_job(m_pa.method_p.params_p.clone(), {
                        let cp_p0xxyx = cp_p0xxy.clone();
                        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| {
                            let cp_p0xxyxy = cp_p0xxyx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (_, t_pb) = p0;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::cpp::expr::ParamType { cp_p0: cp_p0xxyxy.clone(), t_p1: t_pb.clone() }))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                    }), move |each_43503: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("    {} (*{})({});", &cpp_type_f_43445, &crate::emit::cpp::cpp_id_f(&m_pa.method_p.name_p), &crate::syntax::lexer::chars::join_f(&each_43503, &crate::prelude::Text::lit(", ")))))))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::PackedMethod) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
        }), move |each_43418: crate::prelude::Array<crate::prelude::Text>| {
            let fields_p4 = each_43418;
            crate::prelude::call_value(crate::prelude::each_job(d_p1x.methods_p.clone(), {
                let d_p1xx = d_p1x.clone();
                let cp_p0xx = cp_p0x.clone();
                ::std::rc::Rc::new(move |p0: crate::lower::model::PackedMethod| {
                    let d_p1xxy = d_p1xx.clone();
                    let cp_p0xxy = cp_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let m_pc = p0;
                        {
                            let names_pd = crate::prelude::each(&m_pc.method_p.params_p, &(|(n_pg, _): &(crate::prelude::Text, crate::lower::model::OutTy)| crate::emit::cpp::cpp_id_f(n_pg)));
                            let args_pe = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&names_pd)), &(|i_ph: &crate::prelude::Nat| if crate::prelude::or(&crate::prelude::index(&m_pc.hidden_p, i_ph), &false) {
                                crate::prelude::Text::from(format!("{}.template held<T>()", &crate::prelude::or(&crate::prelude::index(&names_pd, i_ph), &crate::prelude::Text::lit(""))))
                            } else {
                                crate::prelude::or(&crate::prelude::index(&names_pd, i_ph), &crate::prelude::Text::lit(""))
                            }));
                            let call_pf = crate::prelude::Text::from(format!("{}::{}({})", &d_p1xxy.name_p, &crate::emit::cpp::cpp_id_f(&m_pc.method_p.name_p), &crate::syntax::lexer::chars::join_f(&args_pe, &crate::prelude::Text::lit(", "))));
                            crate::prelude::call_then(start_cpp_params_f(cp_p0xxy.clone(), m_pc.method_p.params_p.clone()), move |cpp_params_f_43907: crate::prelude::Text| crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), m_pc.method_p.ret_p.clone()), move |cpp_type_f_43943: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("        +[]({}) -> {} {{ return {}; }},", &cpp_params_f_43907, &cpp_type_f_43943, &(if m_pc.hidden_result_p {
                                crate::prelude::Text::from(format!("{}.repacked({})", &crate::emit::cpp::cpp_id_f(&packed_first_hidden_cpp_f(&m_pc)), &call_pf))
                            } else {
                                call_pf.clone()
                            }))))))
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::PackedMethod) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            }), move |each_43587: crate::prelude::Array<crate::prelude::Text>| {
                let entries_p5 = each_43587;
                let declared_p6 = crate::prelude::Text::from(format!("/// The dictionary of `{}` an existential keeps: each method over packed values.\nstruct {} {{\n{}\n}};\n/// The dictionary of `{}` at the type of a value.\nstruct {} {{\n    template <class T>\n    {} operator()(const T&) const;\n}};\ninline constexpr {} {}_packed_of{{}};", &d_p1x.name_p, &dictionary_p2, &crate::syntax::lexer::chars::join_f(&fields_p4, &crate::prelude::Text::lit("\n")), &d_p1x.name_p, &maker_p3, &dictionary_p2, &maker_p3, &crate::prelude::lower(&d_p1x.name_p)));
                let made_p7 = crate::prelude::Text::from(format!("template <class T>\n{} {}::operator()(const T&) const {{\n    return {}{{\n{}\n    }};\n}}", &dictionary_p2, &maker_p3, &dictionary_p2, &crate::syntax::lexer::chars::join_f(&entries_p5, &crate::prelude::Text::lit("\n"))));
                crate::prelude::call_value(crate::prelude::each_job(d_p1x.methods_p.clone(), {
                    let d_p1xx = d_p1x.clone();
                    let cp_p0xx = cp_p0x.clone();
                    ::std::rc::Rc::new(move |p0: crate::lower::model::PackedMethod| {
                        let d_p1xxy = d_p1xx.clone();
                        let cp_p0xxy = cp_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let m_pi = p0;
                            crate::prelude::call_then(start_fn_signature_f(cp_p0xxy.clone(), m_pi.method_p.clone()), move |fn_signature_f_44649: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::trait_namespace_f(&d_p1xxy.name_p, &crate::prelude::Text::from(format!("{};", &fn_signature_f_44649)))))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::PackedMethod) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                }), move |each_44603: crate::prelude::Array<crate::prelude::Text>| {
                    let protos_p8 = each_44603;
                    crate::prelude::call_value(crate::prelude::each_job(d_p1x.methods_p.clone(), {
                        let d_p1xx = d_p1x.clone();
                        let cp_p0xx = cp_p0x.clone();
                        let dictionary_p2x = dictionary_p2.clone();
                        ::std::rc::Rc::new(move |p0: crate::lower::model::PackedMethod| {
                            let d_p1xxy = d_p1xx.clone();
                            let cp_p0xxy = cp_p0xx.clone();
                            let dictionary_p2xy = dictionary_p2x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let m_pj = p0;
                                crate::prelude::call_then(start_fn_signature_f(cp_p0xxy.clone(), m_pj.method_p.clone()), move |fn_signature_f_44754: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::trait_namespace_f(&d_p1xxy.name_p, &crate::emit::cpp::templates::items::cpp_function_f(&crate::prelude::Text::lit(""), &fn_signature_f_44754, &crate::prelude::Text::from(format!("return {}.template dictionary<{}>().{}({});", &crate::emit::cpp::cpp_id_f(&packed_first_hidden_cpp_f(&m_pj)), &dictionary_p2xy, &crate::emit::cpp::cpp_id_f(&m_pj.method_p.name_p), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&m_pj.method_p.params_p, &(|(n_pk, _): &(crate::prelude::Text, crate::lower::model::OutTy)| crate::emit::cpp::cpp_id_f(n_pk))), &crate::prelude::Text::lit(", "))))))))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::PackedMethod) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                    }), move |each_44692: crate::prelude::Array<crate::prelude::Text>| {
                        let defs_p9 = each_44692;
                        ::prism_rtl::Turn::Finished({
                            let mut this: Parts = protos_defs_f(&crate::prelude::append(&crate::prelude::Array::from(vec![declared_p6.clone()]), &protos_p8), &defs_p9);
                            this.generic_p = crate::prelude::Array::from(vec![made_p7.clone()]);
                            this
                        })
                    })
                })
            })
        })
    }
}

/// `Start PackedParts, x`: what the function value is when passed to `@Run`.
pub fn start_packed_parts_f(cp_p0: crate::emit::cpp::Cp, d_p1: crate::lower::model::PackedDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<Parts>> {
    ::std::rc::Rc::new(PackedParts { cp_p0, d_p1 })
}

/// ```prism
/// PackedFirstHiddenCpp: fn PackedMethod -> Text
/// ```
pub fn packed_first_hidden_cpp_f(m_p0: &crate::lower::model::PackedMethod) -> crate::prelude::Text {
    crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&m_p0.hidden_p)), &crate::prelude::Text::lit(""), &(|found_p1: &crate::prelude::Text, i_p2: &crate::prelude::Nat| if (found_p1 == &crate::prelude::Text::lit("")) && crate::prelude::or(&crate::prelude::index(&m_p0.hidden_p, i_p2), &false) {
        crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&m_p0.method_p.params_p, &(|(n_p3, _): &(crate::prelude::Text, crate::lower::model::OutTy)| n_p3.clone())), i_p2), &crate::prelude::Text::lit(""))
    } else {
        found_p1.clone()
    }))
}

/// ```prism
/// WithGenerics: fn FnDef, [((Text, [Text]))] -> FnDef
/// ```
pub fn with_generics_f(f_p0: &crate::lower::model::FnDef, gs_p1: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>) -> crate::lower::model::FnDef {
    let mut this: crate::lower::model::FnDef = f_p0.clone();
    this.generics_p = crate::prelude::append(gs_p1, &this.generics_p);
    this
}

/// ```prism
/// GenericOnly: fn [Text] -> Parts
/// ```
pub fn generic_only_f(xs_p0: &crate::prelude::Array<crate::prelude::Text>) -> Parts {
    let mut this: Parts = no_parts_p();
    this.generic_p = xs_p0.clone();
    this
}

/// ```prism
/// ProtosDefs: fn [Text], [Text] -> Parts
/// ```
pub fn protos_defs_f(ps_p0: &crate::prelude::Array<crate::prelude::Text>, ds_p1: &crate::prelude::Array<crate::prelude::Text>) -> Parts {
    let mut this: Parts = no_parts_p();
    this.protos_p = ps_p0.clone();
    this.defs_p = ds_p1.clone();
    this
}
