//! The module `Emit.Cpp.Items`, from `target/bootstrap/src/prismc/emit/cpp/items.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Parts`:
///
/// ```prism
/// type Parts = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Parts {
    pub forward: Array<Text>,
    pub values: Array<ValueDecl>,
    pub protos: Array<Text>,
    pub classes: Array<Text>,
    pub outer: Array<Text>,
    pub generic: Array<Text>,
    pub defs: Array<Text>,
}

impl Show for Parts {
    fn show(&self, p: &mut Printer) {
        p.record("Parts", &[("forward", &self.forward), ("values", &self.values), ("protos", &self.protos), ("classes", &self.classes), ("outer", &self.outer), ("generic", &self.generic), ("defs", &self.defs)]);
    }
}

impl ToPod for Parts {
    fn to_pod(&self) -> Pod {
        Pod::record("Parts", vec![("forward", self.forward.to_pod()), ("values", self.values.to_pod()), ("protos", self.protos.to_pod()), ("classes", self.classes.to_pod()), ("outer", self.outer.to_pod()), ("generic", self.generic.to_pod()), ("defs", self.defs.to_pod())])
    }
}

impl FromPod for Parts {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Parts { forward: FromPod::from_pod(field(p, "forward")?)?, values: FromPod::from_pod(field(p, "values")?)?, protos: FromPod::from_pod(field(p, "protos")?)?, classes: FromPod::from_pod(field(p, "classes")?)?, outer: FromPod::from_pod(field(p, "outer")?)?, generic: FromPod::from_pod(field(p, "generic")?)?, defs: FromPod::from_pod(field(p, "defs")?)? })
    }
}

/// `ValueDecl`:
///
/// ```prism
/// type ValueDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ValueDecl {
    pub path_: Text,
    pub deps: Array<Text>,
    pub text: Text,
}

impl Show for ValueDecl {
    fn show(&self, p: &mut Printer) {
        p.record("ValueDecl", &[("path", &self.path_), ("deps", &self.deps), ("text", &self.text)]);
    }
}

impl ToPod for ValueDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("ValueDecl", vec![("path", self.path_.to_pod()), ("deps", self.deps.to_pod()), ("text", self.text.to_pod())])
    }
}

impl FromPod for ValueDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ValueDecl { path_: FromPod::from_pod(field(p, "path")?)?, deps: FromPod::from_pod(field(p, "deps")?)?, text: FromPod::from_pod(field(p, "text")?)? })
    }
}

/// ```prism
/// CppTemplateHead: fn [Text] -> Text
/// ```
pub fn cpp_template_head(xs0: &Array<Text>) -> Text {
    match xs0 {
        c0_0 if (c0_0.len() == 0) => Text::lit(""),
        ps_p0 => Text::from(format!("template <{}>\n", &crate::syntax::lexer::chars::join(&each(ps_p0, &(|p_p1: &Text| Text::from(format!("class {}", p_p1)))), &Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// GenericNamesOf: fn [((Text, [Text]))] -> [Text]
/// ```
pub fn generic_names_of(gs_p0: &Array<(Text, Array<Text>)>) -> Array<Text> {
    each(gs_p0, &(|(g_p1, _): &(Text, Array<Text>)| g_p1.clone()))
}

/// ```prism
/// HeadOf: fn Text, [Text] -> Text
/// ```
pub fn head_of(name_p0: &Text, xs1: &Array<Text>) -> Text {
    match xs1 {
        c0_1 if (c0_1.len() == 0) => name_p0.clone(),
        ps_p2 => Text::from(format!("{}<{}>", name_p0, &crate::syntax::lexer::chars::join(ps_p2, &Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CppParams: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub fn cpp_params(cp_p0: &crate::emit::cpp::Cp, ps_p1: &Array<(Text, crate::lower::model::OutTy)>) -> Text {
    crate::syntax::lexer::chars::join(&run_to_end(each_job(ps_p1.clone(), {
        let cp_p0 = cp_p0.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
            let cp_p0 = cp_p0.clone();
            entered(once_job(move || {
                let (n_p2, t_p3) = p0;
                call_then(crate::emit::cpp::expr::start_param_type(cp_p0.clone(), t_p3.clone()), move |param_type_1510: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_1510, &crate::emit::cpp::cpp_id(&n_p2)))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "))
}

/// The step machine of `CppParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppParams: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub struct CppParams {
    pub cp_p0: crate::emit::cpp::Cp,
    pub ps_p1: Array<(Text, crate::lower::model::OutTy)>,
}

impl prism_rtl::Job<Text> for CppParams {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let ps_p1 = &self.ps_p1;
        let cp_p0 = cp_p0.clone();
        let ps_p1 = ps_p1.clone();
        call_value(each_job(ps_p1.clone(), {
            let cp_p0 = cp_p0.clone();
            Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                let cp_p0 = cp_p0.clone();
                entered(once_job(move || {
                    let (n_p2, t_p3) = p0;
                    call_then(crate::emit::cpp::expr::start_param_type(cp_p0.clone(), t_p3.clone()), move |param_type_1510: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_1510, &crate::emit::cpp::cpp_id(&n_p2)))))
                }))
            }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_1487: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&each_1487, &Text::lit(", "))))
    }
}

/// `Start CppParams, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_params(cp_p0: crate::emit::cpp::Cp, ps_p1: Array<(Text, crate::lower::model::OutTy)>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppParams { cp_p0, ps_p1 })
}

/// ```prism
/// FnSignature: unbounded fn Cp, FnDef -> Text
/// ```
pub fn fn_signature(cp_p0: &crate::emit::cpp::Cp, f_p1: &crate::lower::model::FnDef) -> Text {
    Text::from(format!("{}{} {}({})", &cpp_template_head(&generic_names_of(&f_p1.generics)), &crate::emit::cpp::cpp_type(cp_p0, &f_p1.ret), &crate::emit::cpp::cpp_id(&f_p1.name), &cpp_params(cp_p0, &f_p1.params)))
}

/// The step machine of `FnSignature`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnSignature: unbounded fn Cp, FnDef -> Text
/// ```
pub struct FnSignature {
    pub cp_p0: crate::emit::cpp::Cp,
    pub f_p1: crate::lower::model::FnDef,
}

impl prism_rtl::Job<Text> for FnSignature {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let f_p1 = &self.f_p1;
        let cp_p0 = cp_p0.clone();
        let f_p1 = f_p1.clone();
        call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), f_p1.ret.clone()), move |cpp_type_1741: Text| call_then(start_cpp_params(cp_p0.clone(), f_p1.params.clone()), move |cpp_params_1776: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{} {}({})", &cpp_template_head(&generic_names_of(&f_p1.generics)), &cpp_type_1741, &crate::emit::cpp::cpp_id(&f_p1.name), &cpp_params_1776)))))
    }
}

/// `Start FnSignature, x`: what the function value is when passed to `@Run`.
pub fn start_fn_signature(cp_p0: crate::emit::cpp::Cp, f_p1: crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FnSignature { cp_p0, f_p1 })
}

/// ```prism
/// FnDefinition: unbounded fn Cp, FnDef -> Text
/// ```
pub fn fn_definition(cp_p0: &crate::emit::cpp::Cp, f_p1: &crate::lower::model::FnDef) -> Text {
    crate::emit::cpp::templates::items::cpp_function(&cpp_doc(&f_p1.doc), &fn_signature(cp_p0, f_p1), &crate::emit::cpp::stmts::cpp_body(&with_params(cp_p0, &f_p1.params), &f_p1.body))
}

/// The step machine of `FnDefinition`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnDefinition: unbounded fn Cp, FnDef -> Text
/// ```
pub struct FnDefinition {
    pub cp_p0: crate::emit::cpp::Cp,
    pub f_p1: crate::lower::model::FnDef,
}

impl prism_rtl::Job<Text> for FnDefinition {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let f_p1 = &self.f_p1;
        let cp_p0 = cp_p0.clone();
        let f_p1 = f_p1.clone();
        call_then(start_fn_signature(cp_p0.clone(), f_p1.clone()), move |fn_signature_1901: Text| call_then(crate::emit::cpp::stmts::start_cpp_body(with_params(&cp_p0, &f_p1.params), f_p1.body.clone()), move |cpp_body_1922: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&cpp_doc(&f_p1.doc), &fn_signature_1901, &cpp_body_1922))))
    }
}

/// `Start FnDefinition, x`: what the function value is when passed to `@Run`.
pub fn start_fn_definition(cp_p0: crate::emit::cpp::Cp, f_p1: crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FnDefinition { cp_p0, f_p1 })
}

/// ```prism
/// WithParams: fn Cp, [((Text, OutTy))] -> Cp
/// ```
pub fn with_params(cp_p0: &crate::emit::cpp::Cp, ps_p1: &Array<(Text, crate::lower::model::OutTy)>) -> crate::emit::cpp::Cp {
    fold(ps_p1, cp_p0, &(|c_p2: &crate::emit::cpp::Cp, (n_p3, t_p4): &(Text, crate::lower::model::OutTy)| {
        let mut this: crate::emit::cpp::Cp = c_p2.clone();
        this.pointers = insert(&this.pointers, n_p3, &crate::emit::cpp::expr::is_pointer_ty(c_p2, &crate::emit::cpp::expr::unref(t_p4)));
        this.local_types = insert(&this.local_types, n_p3, t_p4);
        this
    }))
}

/// ```prism
/// ValueDeps: unbounded fn Cp, OutTy -> [Text]
/// ```
pub fn value_deps(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::OutTy) -> Array<Text> {
    match t_p1 {
        crate::lower::model::OutTy::OutNamed(n_p2, args_p3) => {
            let own_p4 = match crate::emit::cpp::type_of(cp_p0, n_p2) {
                Some(info_p5) => if ((((&info_p5.kind == &Text::lit("record")) || (&info_p5.kind == &Text::lit("newtype"))) || (&info_p5.kind == &Text::lit("unit"))) || (&info_p5.kind == &Text::lit("tag"))) || (&info_p5.kind == &Text::lit("choice")) {
                    Array::from(vec![dep_path(cp_p0, n_p2)])
                } else {
                    Array::new()
                },
                None => Array::new(),
            };
            append(&own_p4, &crate::emit::cpp::patterns::concat2(&run_to_end(each_job(args_p3.clone(), {
                let cp_p0 = cp_p0.clone();
                Rc::new(move |p0: crate::lower::model::OutTy| {
                    let cp_p0 = cp_p0.clone();
                    entered(once_job(move || {
                        let a_p6 = p0;
                        prism_rtl::Turn::More(Rc::new(ValueDeps { cp_p0: cp_p0.clone(), t_p1: a_p6.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }))))
        },
        crate::lower::model::OutTy::OutOpt(i_p7) => value_deps(cp_p0, &**i_p7),
        crate::lower::model::OutTy::OutRes(i_p8) => value_deps(cp_p0, &**i_p8),
        crate::lower::model::OutTy::OutCell(i_p9) => value_deps(cp_p0, &**i_p9),
        crate::lower::model::OutTy::OutTuple(ts_pa) => crate::emit::cpp::patterns::concat2(&run_to_end(each_job(ts_pa.clone(), {
            let cp_p0 = cp_p0.clone();
            Rc::new(move |p0: crate::lower::model::OutTy| {
                let cp_p0 = cp_p0.clone();
                entered(once_job(move || {
                    let a_pb = p0;
                    prism_rtl::Turn::More(Rc::new(ValueDeps { cp_p0: cp_p0.clone(), t_p1: a_pb.clone() }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }))),
        _ => Array::new(),
    }
}

/// The step machine of `ValueDeps`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ValueDeps: unbounded fn Cp, OutTy -> [Text]
/// ```
pub struct ValueDeps {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Array<Text>> for ValueDeps {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        match t_p1 {
            crate::lower::model::OutTy::OutNamed(n_p2, args_p3) => {
                let own_p4 = match crate::emit::cpp::type_of(cp_p0, n_p2) {
                    Some(info_p5) => if ((((&info_p5.kind == &Text::lit("record")) || (&info_p5.kind == &Text::lit("newtype"))) || (&info_p5.kind == &Text::lit("unit"))) || (&info_p5.kind == &Text::lit("tag"))) || (&info_p5.kind == &Text::lit("choice")) {
                        Array::from(vec![dep_path(cp_p0, n_p2)])
                    } else {
                        Array::new()
                    },
                    None => Array::new(),
                };
                let args_p3 = args_p3.clone();
                let cp_p0 = cp_p0.clone();
                call_value(each_job(args_p3.clone(), {
                    let cp_p0 = cp_p0.clone();
                    Rc::new(move |p0: crate::lower::model::OutTy| {
                        let cp_p0 = cp_p0.clone();
                        entered(once_job(move || {
                            let a_p6 = p0;
                            prism_rtl::Turn::More(Rc::new(ValueDeps { cp_p0: cp_p0.clone(), t_p1: a_p6.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_3884: Array<Array<Text>>| prism_rtl::Turn::Finished(append(&own_p4, &crate::emit::cpp::patterns::concat2(&each_3884))))
            },
            crate::lower::model::OutTy::OutOpt(i_p7) => prism_rtl::Turn::More(Rc::new(ValueDeps { cp_p0: cp_p0.clone(), t_p1: (**i_p7).clone() })),
            crate::lower::model::OutTy::OutRes(i_p8) => prism_rtl::Turn::More(Rc::new(ValueDeps { cp_p0: cp_p0.clone(), t_p1: (**i_p8).clone() })),
            crate::lower::model::OutTy::OutCell(i_p9) => prism_rtl::Turn::More(Rc::new(ValueDeps { cp_p0: cp_p0.clone(), t_p1: (**i_p9).clone() })),
            crate::lower::model::OutTy::OutTuple(ts_pa) => {
                let cp_p0 = cp_p0.clone();
                let ts_pa = ts_pa.clone();
                call_value(each_job(ts_pa.clone(), {
                    let cp_p0 = cp_p0.clone();
                    Rc::new(move |p0: crate::lower::model::OutTy| {
                        let cp_p0 = cp_p0.clone();
                        entered(once_job(move || {
                            let a_pb = p0;
                            prism_rtl::Turn::More(Rc::new(ValueDeps { cp_p0: cp_p0.clone(), t_p1: a_pb.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_4035: Array<Array<Text>>| prism_rtl::Turn::Finished(crate::emit::cpp::patterns::concat2(&each_4035)))
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start ValueDeps, x`: what the function value is when passed to `@Run`.
pub fn start_value_deps(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ValueDeps { cp_p0, t_p1 })
}

/// ```prism
/// DepPath: fn Cp, Text -> Text
/// ```
pub fn dep_path(cp_p0: &crate::emit::cpp::Cp, n_p1: &Text) -> Text {
    let abs_p2 = crate::emit::cpp::absolute(cp_p0, n_p1);
    let q_p3 = crate::syntax::lexer::chars::drop_prefix(n_p1, &Text::lit("crate::"));
    match get(&cp_p0.types, &abs_p2) {
        Some(_) => abs_p2.clone(),
        None => q_p3.clone(),
    }
}

/// ```prism
/// Behind: unbounded fn Cp, OutTy -> Bool
/// ```
pub fn behind(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::OutTy) -> bool {
    match t_p1 {
        crate::lower::model::OutTy::OutRc(_) => true,
        crate::lower::model::OutTy::OutOpt(i_p2) => behind(cp_p0, &**i_p2),
        crate::lower::model::OutTy::OutRes(i_p3) => behind(cp_p0, &**i_p3),
        crate::lower::model::OutTy::OutCell(i_p4) => behind(cp_p0, &**i_p4),
        crate::lower::model::OutTy::OutTuple(ts_p5) => run_to_end(fold_job(ts_p5.clone(), false, {
            let cp_p0 = cp_p0.clone();
            Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                let cp_p0 = cp_p0.clone();
                entered(once_job(move || {
                    let f_p6 = p0;
                    let x_p7 = p1;
                    prism_rtl::Turn::Finished(f_p6 || behind(&cp_p0, &x_p7))
                }))
            }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::lower::model::OutTy::OutArray(i_p8) => names_program_type(cp_p0, &**i_p8),
        crate::lower::model::OutTy::OutMap(k_p9, v_pa) => names_program_type(cp_p0, &**k_p9) || names_program_type(cp_p0, &**v_pa),
        crate::lower::model::OutTy::OutFn(ps_pb, r_pc) => run_to_end(fold_job(ps_pb.clone(), names_program_type(cp_p0, &**r_pc), {
            let cp_p0 = cp_p0.clone();
            Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                let cp_p0 = cp_p0.clone();
                entered(once_job(move || {
                    let f_pd = p0;
                    let x_pe = p1;
                    prism_rtl::Turn::Finished(f_pd || names_program_type(&cp_p0, &x_pe))
                }))
            }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::lower::model::OutTy::OutDyn(i_pf) => names_program_type(cp_p0, &**i_pf),
        crate::lower::model::OutTy::OutEvent(i_pg) => names_program_type(cp_p0, &**i_pg),
        crate::lower::model::OutTy::OutNamed(_, args_ph) => run_to_end(fold_job(args_ph.clone(), false, {
            let cp_p0 = cp_p0.clone();
            Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                let cp_p0 = cp_p0.clone();
                entered(once_job(move || {
                    let f_pi = p0;
                    let x_pj = p1;
                    prism_rtl::Turn::Finished(f_pi || behind(&cp_p0, &x_pj))
                }))
            }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        _ => false,
    }
}

/// The step machine of `Behind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Behind: unbounded fn Cp, OutTy -> Bool
/// ```
pub struct Behind {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::OutTy,
}

impl prism_rtl::Job<bool> for Behind {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        match t_p1 {
            crate::lower::model::OutTy::OutRc(_) => prism_rtl::Turn::Finished(true),
            crate::lower::model::OutTy::OutOpt(i_p2) => prism_rtl::Turn::More(Rc::new(Behind { cp_p0: cp_p0.clone(), t_p1: (**i_p2).clone() })),
            crate::lower::model::OutTy::OutRes(i_p3) => prism_rtl::Turn::More(Rc::new(Behind { cp_p0: cp_p0.clone(), t_p1: (**i_p3).clone() })),
            crate::lower::model::OutTy::OutCell(i_p4) => prism_rtl::Turn::More(Rc::new(Behind { cp_p0: cp_p0.clone(), t_p1: (**i_p4).clone() })),
            crate::lower::model::OutTy::OutTuple(ts_p5) => fold_job(ts_p5.clone(), false, {
                let cp_p0 = cp_p0.clone();
                Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                    let cp_p0 = cp_p0.clone();
                    entered(once_job(move || {
                        let f_p6 = p0;
                        let x_p7 = p1;
                        prism_rtl::Turn::Finished(f_p6 || behind(&cp_p0, &x_p7))
                    }))
                }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            crate::lower::model::OutTy::OutArray(i_p8) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_p8).clone() })),
            crate::lower::model::OutTy::OutMap(k_p9, v_pa) => {
                let cp_p0 = cp_p0.clone();
                let k_p9 = (**k_p9).clone();
                let v_pa = (**v_pa).clone();
                call_then(start_names_program_type(cp_p0.clone(), k_p9.clone()), move |names_program_type_5369: bool| prism_rtl::Turn::Finished(names_program_type_5369 || names_program_type(&cp_p0, &v_pa)))
            },
            crate::lower::model::OutTy::OutFn(ps_pb, r_pc) => {
                let cp_p0 = cp_p0.clone();
                let ps_pb = ps_pb.clone();
                let r_pc = (**r_pc).clone();
                call_then(start_names_program_type(cp_p0.clone(), r_pc.clone()), move |names_program_type_5446: bool| fold_job(ps_pb.clone(), names_program_type_5446, {
                    let cp_p0 = cp_p0.clone();
                    Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                        let cp_p0 = cp_p0.clone();
                        entered(once_job(move || {
                            let f_pd = p0;
                            let x_pe = p1;
                            prism_rtl::Turn::Finished(f_pd || names_program_type(&cp_p0, &x_pe))
                        }))
                    }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
                }).cycle())
            },
            crate::lower::model::OutTy::OutDyn(i_pf) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_pf).clone() })),
            crate::lower::model::OutTy::OutEvent(i_pg) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_pg).clone() })),
            crate::lower::model::OutTy::OutNamed(_, args_ph) => fold_job(args_ph.clone(), false, {
                let cp_p0 = cp_p0.clone();
                Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                    let cp_p0 = cp_p0.clone();
                    entered(once_job(move || {
                        let f_pi = p0;
                        let x_pj = p1;
                        prism_rtl::Turn::Finished(f_pi || behind(&cp_p0, &x_pj))
                    }))
                }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start Behind, x`: what the function value is when passed to `@Run`.
pub fn start_behind(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(Behind { cp_p0, t_p1 })
}

/// ```prism
/// NamesProgramType: unbounded fn Cp, OutTy -> Bool
/// ```
pub fn names_program_type(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::OutTy) -> bool {
    match t_p1 {
        crate::lower::model::OutTy::OutNamed(n_p2, args_p3) => {
            let own_p4 = match crate::emit::cpp::type_of(cp_p0, n_p2) {
                Some(info_p5) => (&info_p5.kind != &Text::lit("node")) && (&info_p5.kind != &Text::lit("job")),
                None => false,
            };
            own_p4 || run_to_end(fold_job(args_p3.clone(), false, {
                let cp_p0 = cp_p0.clone();
                Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                    let cp_p0 = cp_p0.clone();
                    entered(once_job(move || {
                        let f_p6 = p0;
                        let x_p7 = p1;
                        prism_rtl::Turn::Finished(f_p6 || names_program_type(&cp_p0, &x_p7))
                    }))
                }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
            }))
        },
        crate::lower::model::OutTy::OutOpt(i_p8) => names_program_type(cp_p0, &**i_p8),
        crate::lower::model::OutTy::OutRes(i_p9) => names_program_type(cp_p0, &**i_p9),
        crate::lower::model::OutTy::OutRc(i_pa) => names_program_type(cp_p0, &**i_pa),
        crate::lower::model::OutTy::OutCell(i_pb) => names_program_type(cp_p0, &**i_pb),
        crate::lower::model::OutTy::OutArray(i_pc) => names_program_type(cp_p0, &**i_pc),
        crate::lower::model::OutTy::OutMap(k_pd, v_pe) => names_program_type(cp_p0, &**k_pd) || names_program_type(cp_p0, &**v_pe),
        crate::lower::model::OutTy::OutTuple(ts_pf) => run_to_end(fold_job(ts_pf.clone(), false, {
            let cp_p0 = cp_p0.clone();
            Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                let cp_p0 = cp_p0.clone();
                entered(once_job(move || {
                    let f_pg = p0;
                    let x_ph = p1;
                    prism_rtl::Turn::Finished(f_pg || names_program_type(&cp_p0, &x_ph))
                }))
            }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::lower::model::OutTy::OutFn(ps_pi, r_pj) => run_to_end(fold_job(ps_pi.clone(), names_program_type(cp_p0, &**r_pj), {
            let cp_p0 = cp_p0.clone();
            Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                let cp_p0 = cp_p0.clone();
                entered(once_job(move || {
                    let f_pk = p0;
                    let x_pl = p1;
                    prism_rtl::Turn::Finished(f_pk || names_program_type(&cp_p0, &x_pl))
                }))
            }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::lower::model::OutTy::OutDyn(i_pm) => names_program_type(cp_p0, &**i_pm),
        crate::lower::model::OutTy::OutEvent(i_pn) => names_program_type(cp_p0, &**i_pn),
        _ => false,
    }
}

/// The step machine of `NamesProgramType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamesProgramType: unbounded fn Cp, OutTy -> Bool
/// ```
pub struct NamesProgramType {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::OutTy,
}

impl prism_rtl::Job<bool> for NamesProgramType {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        match t_p1 {
            crate::lower::model::OutTy::OutNamed(n_p2, args_p3) => {
                let own_p4 = match crate::emit::cpp::type_of(cp_p0, n_p2) {
                    Some(info_p5) => (&info_p5.kind != &Text::lit("node")) && (&info_p5.kind != &Text::lit("job")),
                    None => false,
                };
                prism_rtl::Turn::Finished(own_p4 || run_to_end(fold_job(args_p3.clone(), false, {
                    let cp_p0 = cp_p0.clone();
                    Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                        let cp_p0 = cp_p0.clone();
                        entered(once_job(move || {
                            let f_p6 = p0;
                            let x_p7 = p1;
                            prism_rtl::Turn::Finished(f_p6 || names_program_type(&cp_p0, &x_p7))
                        }))
                    }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
                })))
            },
            crate::lower::model::OutTy::OutOpt(i_p8) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_p8).clone() })),
            crate::lower::model::OutTy::OutRes(i_p9) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_p9).clone() })),
            crate::lower::model::OutTy::OutRc(i_pa) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_pa).clone() })),
            crate::lower::model::OutTy::OutCell(i_pb) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_pb).clone() })),
            crate::lower::model::OutTy::OutArray(i_pc) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_pc).clone() })),
            crate::lower::model::OutTy::OutMap(k_pd, v_pe) => {
                let cp_p0 = cp_p0.clone();
                let k_pd = (**k_pd).clone();
                let v_pe = (**v_pe).clone();
                call_then(start_names_program_type(cp_p0.clone(), k_pd.clone()), move |names_program_type_6249: bool| prism_rtl::Turn::Finished(names_program_type_6249 || names_program_type(&cp_p0, &v_pe)))
            },
            crate::lower::model::OutTy::OutTuple(ts_pf) => fold_job(ts_pf.clone(), false, {
                let cp_p0 = cp_p0.clone();
                Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                    let cp_p0 = cp_p0.clone();
                    entered(once_job(move || {
                        let f_pg = p0;
                        let x_ph = p1;
                        prism_rtl::Turn::Finished(f_pg || names_program_type(&cp_p0, &x_ph))
                    }))
                }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            crate::lower::model::OutTy::OutFn(ps_pi, r_pj) => {
                let cp_p0 = cp_p0.clone();
                let ps_pi = ps_pi.clone();
                let r_pj = (**r_pj).clone();
                call_then(start_names_program_type(cp_p0.clone(), r_pj.clone()), move |names_program_type_6395: bool| fold_job(ps_pi.clone(), names_program_type_6395, {
                    let cp_p0 = cp_p0.clone();
                    Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                        let cp_p0 = cp_p0.clone();
                        entered(once_job(move || {
                            let f_pk = p0;
                            let x_pl = p1;
                            prism_rtl::Turn::Finished(f_pk || names_program_type(&cp_p0, &x_pl))
                        }))
                    }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
                }).cycle())
            },
            crate::lower::model::OutTy::OutDyn(i_pm) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_pm).clone() })),
            crate::lower::model::OutTy::OutEvent(i_pn) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_pn).clone() })),
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start NamesProgramType, x`: what the function value is when passed to `@Run`.
pub fn start_names_program_type(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(NamesProgramType { cp_p0, t_p1 })
}

/// ```prism
/// let noParts
/// ```
pub fn no_parts() -> Parts {
    Parts { forward: Array::new(), values: Array::new(), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: Array::new() }
}

/// ```prism
/// JoinParts: fn Parts, Parts -> Parts
/// ```
pub fn join_parts(a_p0: &Parts, b_p1: &Parts) -> Parts {
    Parts { forward: append(&a_p0.forward, &b_p1.forward), values: append(&a_p0.values, &b_p1.values), protos: append(&a_p0.protos, &b_p1.protos), classes: append(&a_p0.classes, &b_p1.classes), outer: append(&a_p0.outer, &b_p1.outer), generic: append(&a_p0.generic, &b_p1.generic), defs: append(&a_p0.defs, &b_p1.defs) }
}

/// ```prism
/// ItemParts: unbounded fn Cp, Item -> Parts
/// ```
pub fn item_parts(cp_p0: &crate::emit::cpp::Cp, it_p1: &crate::lower::model::Item) -> Parts {
    match it_p1 {
        crate::lower::model::Item::ItType(t_p2) => type_parts(cp_p0, t_p2),
        crate::lower::model::Item::ItTag(t_p3) => tag_parts(cp_p0, t_p3),
        crate::lower::model::Item::ItRow(r_p4) => row_parts(cp_p0, &cp_p0.home, r_p4),
        crate::lower::model::Item::ItFn(f_p5) => fn_parts(cp_p0, f_p5),
        crate::lower::model::Item::ItJob(j_p6) => job_parts(cp_p0, j_p6),
        crate::lower::model::Item::ItNode(n_p7) => crate::emit::cpp::program::node_parts(cp_p0, n_p7),
        crate::lower::model::Item::ItTrait(t_p8) => trait_parts(cp_p0, t_p8),
        crate::lower::model::Item::ItImpl(i_p9) => impl_parts(cp_p0, i_p9),
        crate::lower::model::Item::ItNote(t_pa) => protos_defs(&Array::new(), &Array::from(vec![Text::from(format!("// {}", t_pa))])),
        crate::lower::model::Item::ItRefused(t_pb) => protos_defs(&Array::new(), &Array::from(vec![Text::from(format!("compile_error!(\"{}{}\");", &crate::lower::expr::lowering_refusal(), &crate::lower::expr::escape(t_pb)))])),
    }
}

/// The step machine of `ItemParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ItemParts: unbounded fn Cp, Item -> Parts
/// ```
pub struct ItemParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub it_p1: crate::lower::model::Item,
}

impl prism_rtl::Job<Parts> for ItemParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let it_p1 = &self.it_p1;
        match it_p1 {
            crate::lower::model::Item::ItType(t_p2) => prism_rtl::Turn::More(Rc::new(TypeParts { cp_p0: cp_p0.clone(), t_p1: t_p2.clone() })),
            crate::lower::model::Item::ItTag(t_p3) => prism_rtl::Turn::More(Rc::new(TagParts { cp_p0: cp_p0.clone(), t_p1: t_p3.clone() })),
            crate::lower::model::Item::ItRow(r_p4) => prism_rtl::Turn::More(Rc::new(RowParts { cp_p0: cp_p0.clone(), m_p1: cp_p0.home.clone(), r_p2: r_p4.clone() })),
            crate::lower::model::Item::ItFn(f_p5) => prism_rtl::Turn::More(Rc::new(FnParts { cp_p0: cp_p0.clone(), f_p1: f_p5.clone() })),
            crate::lower::model::Item::ItJob(j_p6) => prism_rtl::Turn::More(Rc::new(JobParts { cp_p0: cp_p0.clone(), j_p1: j_p6.clone() })),
            crate::lower::model::Item::ItNode(n_p7) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::program::NodeParts { cp_p0: cp_p0.clone(), n_p1: n_p7.clone() })),
            crate::lower::model::Item::ItTrait(t_p8) => prism_rtl::Turn::More(Rc::new(TraitParts { cp_p0: cp_p0.clone(), t_p1: t_p8.clone() })),
            crate::lower::model::Item::ItImpl(i_p9) => prism_rtl::Turn::More(Rc::new(ImplParts { cp_p0: cp_p0.clone(), i_p1: i_p9.clone() })),
            crate::lower::model::Item::ItNote(t_pa) => prism_rtl::Turn::Finished(protos_defs(&Array::new(), &Array::from(vec![Text::from(format!("// {}", t_pa))]))),
            crate::lower::model::Item::ItRefused(t_pb) => prism_rtl::Turn::Finished(protos_defs(&Array::new(), &Array::from(vec![Text::from(format!("compile_error!(\"{}{}\");", &crate::lower::expr::lowering_refusal(), &crate::lower::expr::escape(t_pb)))]))),
        }
    }
}

/// `Start ItemParts, x`: what the function value is when passed to `@Run`.
pub fn start_item_parts(cp_p0: crate::emit::cpp::Cp, it_p1: crate::lower::model::Item) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(ItemParts { cp_p0, it_p1 })
}

/// ```prism
/// FnParts: unbounded fn Cp, FnDef -> Parts
/// ```
pub fn fn_parts(cp_p0: &crate::emit::cpp::Cp, f_p1: &crate::lower::model::FnDef) -> Parts {
    if &len(&f_p1.generics) > &Nat::from(0u32) {
        {
            let mut this: Parts = generic_only(&Array::from(vec![fn_definition(cp_p0, f_p1)]));
            this.protos = Array::from(vec![Text::from(format!("{};", &fn_signature(cp_p0, f_p1)))]);
            this
        }
    } else {
        protos_defs(&Array::from(vec![Text::from(format!("{};", &fn_signature(cp_p0, f_p1)))]), &Array::from(vec![fn_definition(cp_p0, f_p1)]))
    }
}

/// The step machine of `FnParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnParts: unbounded fn Cp, FnDef -> Parts
/// ```
pub struct FnParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub f_p1: crate::lower::model::FnDef,
}

impl prism_rtl::Job<Parts> for FnParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let f_p1 = &self.f_p1;
        if &len(&f_p1.generics) > &Nat::from(0u32) {
            prism_rtl::Turn::Finished({
                let mut this: Parts = generic_only(&Array::from(vec![fn_definition(cp_p0, f_p1)]));
                this.protos = Array::from(vec![Text::from(format!("{};", &fn_signature(cp_p0, f_p1)))]);
                this
            })
        } else {
            {
                let cp_p0 = cp_p0.clone();
                let f_p1 = f_p1.clone();
                call_then(start_fn_signature(cp_p0.clone(), f_p1.clone()), move |fn_signature_7638: Text| call_then(start_fn_definition(cp_p0.clone(), f_p1.clone()), move |fn_definition_7665: Text| prism_rtl::Turn::Finished(protos_defs(&Array::from(vec![Text::from(format!("{};", &fn_signature_7638))]), &Array::from(vec![fn_definition_7665])))))
            }
        }
    }
}

/// `Start FnParts, x`: what the function value is when passed to `@Run`.
pub fn start_fn_parts(cp_p0: crate::emit::cpp::Cp, f_p1: crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(FnParts { cp_p0, f_p1 })
}

/// ```prism
/// CppDoc: fn Text -> Text
/// ```
pub fn cpp_doc(text_p0: &Text) -> Text {
    if text_p0 == &Text::lit("") {
        Text::lit("")
    } else {
        concat(&each(&split_on(text_p0, &Text::lit("\n")), &(|l_p1: &Text| if l_p1 == &Text::lit("") {
            Text::lit("///\n")
        } else {
            Text::from(format!("/// {}\n", l_p1))
        })))
    }
}

/// ```prism
/// CppSourceDoc: fn Text, Text -> Text
/// ```
pub fn cpp_source_doc(lead_p0: &Text, source_p1: &Text) -> Text {
    let quoted_p2 = concat(&each(&split_on(source_p1, &Text::lit("\n")), &(|l_p3: &Text| if l_p3 == &Text::lit("") {
        Text::lit("///\n")
    } else {
        Text::from(format!("/// {}\n", l_p3))
    })));
    if source_p1 == &Text::lit("") {
        cpp_doc(lead_p0)
    } else {
        if lead_p0 == &Text::lit("") {
            Text::from(format!("/// ```prism\n{}/// ```\n", &quoted_p2))
        } else {
            Text::from(format!("/// {}\n///\n/// ```prism\n{}/// ```\n", lead_p0, &quoted_p2))
        }
    }
}

/// ```prism
/// TypeParts: unbounded fn Cp, TyDef -> Parts
/// ```
pub fn type_parts(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::TyDef) -> Parts {
    let eq_p2 = t_p1.eq;
    let ord_p3 = t_p1.ord;
    let gens_p4 = cpp_template_head(&t_p1.params);
    let head_p5 = head_of(&t_p1.name, &t_p1.params);
    let doc_p6 = cpp_source_doc(&Text::from(format!("`{}`:", &t_p1.prism)), &t_p1.doc);
    let members_p7 = members(&(&t_p1.show != &crate::lower::model::Shown::NotShown), &t_p1.pod, &head_p5);
    let generic_p8 = &len(&t_p1.params) > &Nat::from(0u32);
    let fwd_p9 = Text::from(format!("{}{} {};", &gens_p4, &(if &t_p1.shape == &crate::lower::model::TyShape::ShapeChoice {
        Text::lit("class")
    } else {
        Text::lit("struct")
    }), &t_p1.name));
    let deps_pa = crate::emit::cpp::patterns::concat2(&run_to_end(each_job(t_p1.cases.clone(), {
        let cp_p0 = cp_p0.clone();
        Rc::new(move |p0: crate::lower::model::CaseDef| {
            let cp_p0 = cp_p0.clone();
            entered(once_job(move || {
                let c_pc = p0;
                call_value(each_job(c_pc.fields.clone(), {
                    let cp_p0 = cp_p0.clone();
                    Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                        let cp_p0 = cp_p0.clone();
                        entered(once_job(move || {
                            let (_, ft_pd) = p0;
                            prism_rtl::Turn::More(Rc::new(ValueDeps { cp_p0: cp_p0.clone(), t_p1: ft_pd.clone() }))
                        }))
                    }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_9019: Array<Array<Text>>| prism_rtl::Turn::Finished(crate::emit::cpp::patterns::concat2(&each_9019)))
            }))
        }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    })));
    let (text_p17, cmp_defs_p18) = match &t_p1.shape {
        crate::lower::model::TyShape::ShapeChoice => {
            let names_pe = each(&t_p1.cases, &(|c_pj: &crate::lower::model::CaseDef| c_pj.name.clone()));
            let cases_pf = crate::syntax::lexer::chars::join(&run_to_end(each_job(t_p1.cases.clone(), {
                let cp_p0 = cp_p0.clone();
                let eq_p2 = eq_p2;
                let ord_p3 = ord_p3;
                Rc::new(move |p0: crate::lower::model::CaseDef| {
                    let cp_p0 = cp_p0.clone();
                    let eq_p2 = eq_p2;
                    let ord_p3 = ord_p3;
                    entered(once_job(move || {
                        let c_pk = p0;
                        prism_rtl::Turn::More(Rc::new(CaseStruct { cp_p0: cp_p0.clone(), c_p1: c_pk.clone(), eq_p2, ord_p3 }))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
            })), &Text::lit("\n"));
            let cls_pg = crate::emit::cpp::templates::items::choice_class(&doc_p6, &gens_p4, &t_p1.name, &cases_pf, &crate::syntax::lexer::chars::join(&names_pe, &Text::lit(", ")), &members_p7);
            let cmp_ph = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![if eq_p2 {
                Text::from(format!("{}inline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &gens_p4, &head_p5, &head_p5))
            } else {
                Text::lit("")
            }, if ord_p3 {
                Text::from(format!("{}inline std::strong_ordering operator<=>(const {}& a, const {}& b) {{ return a.cases() <=> b.cases(); }}", &gens_p4, &head_p5, &head_p5))
            } else {
                Text::lit("")
            }]), &(|s_pl: &Text| s_pl != &Text::lit(""))), &Text::lit("\n"));
            let case_defs_pi = filter(&run_to_end(each_job(t_p1.cases.clone(), {
                let cp_p0 = cp_p0.clone();
                let gens_p4 = gens_p4.clone();
                let head_p5 = head_p5.clone();
                let eq_p2 = eq_p2;
                let ord_p3 = ord_p3;
                Rc::new(move |p0: crate::lower::model::CaseDef| {
                    let cp_p0 = cp_p0.clone();
                    let gens_p4 = gens_p4.clone();
                    let head_p5 = head_p5.clone();
                    let eq_p2 = eq_p2;
                    let ord_p3 = ord_p3;
                    entered(once_job(move || {
                        let c_pm = p0;
                        prism_rtl::Turn::More(Rc::new(CaseCmpDefs { cp_p0: cp_p0.clone(), gens_p1: gens_p4.clone(), head_p2: head_p5.clone(), c_p3: c_pm.clone(), eq_p4: eq_p2, ord_p5: ord_p3 }))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
            })), &(|s_pn: &Text| s_pn != &Text::lit("")));
            (crate::syntax::lexer::chars::join(&filter(&Array::from(vec![cls_pg.clone(), cmp_ph.clone()]), &(|s_po: &Text| s_po != &Text::lit(""))), &Text::lit("\n")), case_defs_pi.clone())
        },
        _ => {
            let first_pp = or(&index(&t_p1.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            let fields_pq = match &t_p1.shape {
                crate::lower::model::TyShape::ShapeRecord => crate::syntax::lexer::chars::join(&run_to_end(each_job(first_pp.fields.clone(), {
                    let cp_p0 = cp_p0.clone();
                    Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                        let cp_p0 = cp_p0.clone();
                        entered(once_job(move || {
                            let (f_pu, ft_pv) = p0;
                            call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), ft_pv.clone()), move |cpp_type_10229: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_10229, &crate::emit::cpp::field_id(&f_pu)))))
                        }))
                    }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
                })), &Text::lit("\n")),
                crate::lower::model::TyShape::ShapeNewtype => positional_fields(cp_p0, &first_pp.fields),
                _ => Text::lit(""),
            };
            let names_pr = match &t_p1.shape {
                crate::lower::model::TyShape::ShapeRecord => each(&first_pp.fields, &(|(f_p10, _): &(Text, crate::lower::model::OutTy)| crate::emit::cpp::field_id(f_p10))),
                crate::lower::model::TyShape::ShapeNewtype => each(&crate::check::errors::range0(&len(&first_pp.fields)), &(|i_p11: &Nat| Text::from(format!("a{}", i_p11)))),
                _ => Array::new(),
            };
            let behind_ps = run_to_end(fold_job(first_pp.fields.clone(), false, {
                let cp_p0 = cp_p0.clone();
                Rc::new(move |(p0, p1): (bool, (Text, crate::lower::model::OutTy))| {
                    let cp_p0 = cp_p0.clone();
                    entered(once_job(move || {
                        let f_p12 = p0;
                        let (_, ft_p13) = p1;
                        prism_rtl::Turn::Finished(f_p12 || behind(&cp_p0, &ft_p13))
                    }))
                }) as Rc<dyn Fn((bool, (Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>
            }));
            let (cmps_p14, cmp_defs_p15) = comparisons(&gens_p4, &head_p5, &t_p1.name, &names_pr, &eq_p2, &ord_p3, &behind_ps);
            let decl_pt = crate::emit::cpp::templates::items::value_struct(&doc_p6, &gens_p4, &t_p1.name, &fields_pq, &crate::syntax::lexer::chars::join(&filter(&Array::from(vec![cmps_p14.clone(), members_p7.clone()]), &(|s_p16: &Text| s_p16 != &Text::lit(""))), &Text::lit("\n")));
            (decl_pt.clone(), if &cmp_defs_p15 == &Text::lit("") {
                Array::new()
            } else {
                Array::from(vec![cmp_defs_p15.clone()])
            })
        },
    };
    let defs_pb = append(&cmp_defs_p18, &Array::from(vec![type_defs(cp_p0, t_p1, &head_p5)]));
    Parts { forward: Array::from(vec![fwd_p9.clone()]), values: Array::from(vec![ValueDecl { path_: decl_path(cp_p0, &t_p1.name), deps: deps_pa.clone(), text: text_p17.clone() }]), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: if generic_p8 { defs_pb.clone() } else { Array::new() }, defs: if generic_p8 { Array::new() } else { defs_pb.clone() } }
}

/// The step machine of `TypeParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeParts: unbounded fn Cp, TyDef -> Parts
/// ```
pub struct TypeParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::TyDef,
}

impl prism_rtl::Job<Parts> for TypeParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        let eq_p2 = t_p1.eq;
        let ord_p3 = t_p1.ord;
        let gens_p4 = cpp_template_head(&t_p1.params);
        let head_p5 = head_of(&t_p1.name, &t_p1.params);
        let doc_p6 = cpp_source_doc(&Text::from(format!("`{}`:", &t_p1.prism)), &t_p1.doc);
        let members_p7 = members(&(&t_p1.show != &crate::lower::model::Shown::NotShown), &t_p1.pod, &head_p5);
        let generic_p8 = &len(&t_p1.params) > &Nat::from(0u32);
        let fwd_p9 = Text::from(format!("{}{} {};", &gens_p4, &(if &t_p1.shape == &crate::lower::model::TyShape::ShapeChoice {
            Text::lit("class")
        } else {
            Text::lit("struct")
        }), &t_p1.name));
        let cp_p0 = cp_p0.clone();
        let t_p1 = t_p1.clone();
        call_value(each_job(t_p1.cases.clone(), {
            let cp_p0 = cp_p0.clone();
            Rc::new(move |p0: crate::lower::model::CaseDef| {
                let cp_p0 = cp_p0.clone();
                entered(once_job(move || {
                    let c_pc = p0;
                    call_value(each_job(c_pc.fields.clone(), {
                        let cp_p0 = cp_p0.clone();
                        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                            let cp_p0 = cp_p0.clone();
                            entered(once_job(move || {
                                let (_, ft_pd) = p0;
                                prism_rtl::Turn::More(Rc::new(ValueDeps { cp_p0: cp_p0.clone(), t_p1: ft_pd.clone() }))
                            }))
                        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }), move |each_9019: Array<Array<Text>>| prism_rtl::Turn::Finished(crate::emit::cpp::patterns::concat2(&each_9019)))
                }))
            }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }), move |each_8991: Array<Array<Text>>| {
            let deps_pa = crate::emit::cpp::patterns::concat2(&each_8991);
            let (text_p17, cmp_defs_p18) = match &t_p1.shape {
                crate::lower::model::TyShape::ShapeChoice => {
                    let names_pe = each(&t_p1.cases, &(|c_pj: &crate::lower::model::CaseDef| c_pj.name.clone()));
                    let cases_pf = crate::syntax::lexer::chars::join(&run_to_end(each_job(t_p1.cases.clone(), {
                        let cp_p0 = cp_p0.clone();
                        let eq_p2 = eq_p2;
                        let ord_p3 = ord_p3;
                        Rc::new(move |p0: crate::lower::model::CaseDef| {
                            let cp_p0 = cp_p0.clone();
                            let eq_p2 = eq_p2;
                            let ord_p3 = ord_p3;
                            entered(once_job(move || {
                                let c_pk = p0;
                                prism_rtl::Turn::More(Rc::new(CaseStruct { cp_p0: cp_p0.clone(), c_p1: c_pk.clone(), eq_p2, ord_p3 }))
                            }))
                        }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
                    })), &Text::lit("\n"));
                    let cls_pg = crate::emit::cpp::templates::items::choice_class(&doc_p6, &gens_p4, &t_p1.name, &cases_pf, &crate::syntax::lexer::chars::join(&names_pe, &Text::lit(", ")), &members_p7);
                    let cmp_ph = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![if eq_p2 {
                        Text::from(format!("{}inline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &gens_p4, &head_p5, &head_p5))
                    } else {
                        Text::lit("")
                    }, if ord_p3 {
                        Text::from(format!("{}inline std::strong_ordering operator<=>(const {}& a, const {}& b) {{ return a.cases() <=> b.cases(); }}", &gens_p4, &head_p5, &head_p5))
                    } else {
                        Text::lit("")
                    }]), &(|s_pl: &Text| s_pl != &Text::lit(""))), &Text::lit("\n"));
                    let case_defs_pi = filter(&run_to_end(each_job(t_p1.cases.clone(), {
                        let cp_p0 = cp_p0.clone();
                        let gens_p4 = gens_p4.clone();
                        let head_p5 = head_p5.clone();
                        let eq_p2 = eq_p2;
                        let ord_p3 = ord_p3;
                        Rc::new(move |p0: crate::lower::model::CaseDef| {
                            let cp_p0 = cp_p0.clone();
                            let gens_p4 = gens_p4.clone();
                            let head_p5 = head_p5.clone();
                            let eq_p2 = eq_p2;
                            let ord_p3 = ord_p3;
                            entered(once_job(move || {
                                let c_pm = p0;
                                prism_rtl::Turn::More(Rc::new(CaseCmpDefs { cp_p0: cp_p0.clone(), gens_p1: gens_p4.clone(), head_p2: head_p5.clone(), c_p3: c_pm.clone(), eq_p4: eq_p2, ord_p5: ord_p3 }))
                            }))
                        }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
                    })), &(|s_pn: &Text| s_pn != &Text::lit("")));
                    (crate::syntax::lexer::chars::join(&filter(&Array::from(vec![cls_pg.clone(), cmp_ph.clone()]), &(|s_po: &Text| s_po != &Text::lit(""))), &Text::lit("\n")), case_defs_pi.clone())
                },
                _ => {
                    let first_pp = or(&index(&t_p1.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                    let fields_pq = match &t_p1.shape {
                        crate::lower::model::TyShape::ShapeRecord => crate::syntax::lexer::chars::join(&run_to_end(each_job(first_pp.fields.clone(), {
                            let cp_p0 = cp_p0.clone();
                            Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                                let cp_p0 = cp_p0.clone();
                                entered(once_job(move || {
                                    let (f_pu, ft_pv) = p0;
                                    call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), ft_pv.clone()), move |cpp_type_10229: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_10229, &crate::emit::cpp::field_id(&f_pu)))))
                                }))
                            }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
                        })), &Text::lit("\n")),
                        crate::lower::model::TyShape::ShapeNewtype => positional_fields(&cp_p0, &first_pp.fields),
                        _ => Text::lit(""),
                    };
                    let names_pr = match &t_p1.shape {
                        crate::lower::model::TyShape::ShapeRecord => each(&first_pp.fields, &(|(f_p10, _): &(Text, crate::lower::model::OutTy)| crate::emit::cpp::field_id(f_p10))),
                        crate::lower::model::TyShape::ShapeNewtype => each(&crate::check::errors::range0(&len(&first_pp.fields)), &(|i_p11: &Nat| Text::from(format!("a{}", i_p11)))),
                        _ => Array::new(),
                    };
                    let behind_ps = run_to_end(fold_job(first_pp.fields.clone(), false, {
                        let cp_p0 = cp_p0.clone();
                        Rc::new(move |(p0, p1): (bool, (Text, crate::lower::model::OutTy))| {
                            let cp_p0 = cp_p0.clone();
                            entered(once_job(move || {
                                let f_p12 = p0;
                                let (_, ft_p13) = p1;
                                prism_rtl::Turn::Finished(f_p12 || behind(&cp_p0, &ft_p13))
                            }))
                        }) as Rc<dyn Fn((bool, (Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>
                    }));
                    let (cmps_p14, cmp_defs_p15) = comparisons(&gens_p4, &head_p5, &t_p1.name, &names_pr, &eq_p2, &ord_p3, &behind_ps);
                    let decl_pt = crate::emit::cpp::templates::items::value_struct(&doc_p6, &gens_p4, &t_p1.name, &fields_pq, &crate::syntax::lexer::chars::join(&filter(&Array::from(vec![cmps_p14.clone(), members_p7.clone()]), &(|s_p16: &Text| s_p16 != &Text::lit(""))), &Text::lit("\n")));
                    (decl_pt.clone(), if &cmp_defs_p15 == &Text::lit("") {
                        Array::new()
                    } else {
                        Array::from(vec![cmp_defs_p15.clone()])
                    })
                },
            };
            call_then(start_type_defs(cp_p0.clone(), t_p1.clone(), head_p5.clone()), move |type_defs_10979: Text| {
                let defs_pb = append(&cmp_defs_p18, &Array::from(vec![type_defs_10979]));
                prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![fwd_p9.clone()]), values: Array::from(vec![ValueDecl { path_: decl_path(&cp_p0, &t_p1.name), deps: deps_pa.clone(), text: text_p17.clone() }]), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: if generic_p8 { defs_pb.clone() } else { Array::new() }, defs: if generic_p8 { Array::new() } else { defs_pb.clone() } })
            })
        })
    }
}

/// `Start TypeParts, x`: what the function value is when passed to `@Run`.
pub fn start_type_parts(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::TyDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(TypeParts { cp_p0, t_p1 })
}

/// ```prism
/// DeclPath: fn Cp, Text -> Text
/// ```
pub fn decl_path(cp_p0: &crate::emit::cpp::Cp, name_p1: &Text) -> Text {
    if &cp_p0.home == &Text::lit("") {
        name_p1.clone()
    } else {
        Text::from(format!("{}::{}", &cp_p0.home, name_p1))
    }
}

/// ```prism
/// Comparisons: fn Text, Text, Text, [Text], Bool, Bool, Bool -> ((Text, Text))
/// ```
pub fn comparisons(gens_p0: &Text, owner_p1: &Text, self_p2: &Text, names_p3: &Array<Text>, eq_p4: &bool, ord_p5: &bool, behind_p6: &bool) -> (Text, Text) {
    if !*behind_p6 {
        (crate::syntax::lexer::chars::join(&filter(&Array::from(vec![if *eq_p4 {
            Text::from(format!("bool operator==(const {}&) const = default;", self_p2))
        } else {
            Text::lit("")
        }, if *ord_p5 {
            Text::from(format!("auto operator<=>(const {}&) const = default;", self_p2))
        } else {
            Text::lit("")
        }]), &(|s_p7: &Text| s_p7 != &Text::lit(""))), &Text::lit("\n")), Text::lit(""))
    } else {
        {
            let decls_p8 = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![if *eq_p4 {
                Text::from(format!("bool operator==(const {}&) const;", self_p2))
            } else {
                Text::lit("")
            }, if *ord_p5 {
                Text::from(format!("std::strong_ordering operator<=>(const {}&) const;", self_p2))
            } else {
                Text::lit("")
            }]), &(|s_pc: &Text| s_pc != &Text::lit(""))), &Text::lit("\n"));
            let eq_body_p9 = if &len(names_p3) == &Nat::from(0u32) {
                Text::lit("true")
            } else {
                crate::syntax::lexer::chars::join(&each(names_p3, &(|n_pd: &Text| Text::from(format!("{} == o.{}", n_pd, n_pd)))), &Text::lit(" && "))
            };
            let ord_body_pa = if &len(names_p3) == &Nat::from(0u32) {
                Text::lit("std::strong_ordering::equal")
            } else {
                Text::from(format!("std::tie({}) <=> std::tie({})", &crate::syntax::lexer::chars::join(names_p3, &Text::lit(", ")), &crate::syntax::lexer::chars::join(&each(names_p3, &(|n_pe: &Text| Text::from(format!("o.{}", n_pe)))), &Text::lit(", "))))
            };
            let defs_pb = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![if *eq_p4 {
                Text::from(format!("{}bool {}::operator==(const {}& o) const {{ return {}; }}", gens_p0, owner_p1, self_p2, &eq_body_p9))
            } else {
                Text::lit("")
            }, if *ord_p5 {
                Text::from(format!("{}std::strong_ordering {}::operator<=>(const {}& o) const {{ return {}; }}", gens_p0, owner_p1, self_p2, &ord_body_pa))
            } else {
                Text::lit("")
            }]), &(|s_pf: &Text| s_pf != &Text::lit(""))), &Text::lit("\n"));
            (decls_p8.clone(), defs_pb.clone())
        }
    }
}

/// ```prism
/// Members: fn Bool, Bool, Text -> Text
/// ```
pub fn members(shown_p0: &bool, pod_p1: &bool, head_p2: &Text) -> Text {
    let s_p3 = if *shown_p0 {
        Array::from(vec![Text::lit("void show(Printer& p) const;")])
    } else {
        Array::new()
    };
    let d_p4 = if *pod_p1 {
        Array::from(vec![Text::lit("Pod to_pod() const;"), Text::from(format!("static Result<{}> from_pod(const Pod& whole);", head_p2))])
    } else {
        Array::new()
    };
    crate::syntax::lexer::chars::join(&append(&s_p3, &d_p4), &Text::lit("\n"))
}

/// ```prism
/// CaseStruct: unbounded fn Cp, CaseDef, Bool, Bool -> Text
/// ```
pub fn case_struct(cp_p0: &crate::emit::cpp::Cp, c_p1: &crate::lower::model::CaseDef, eq_p2: &bool, ord_p3: &bool) -> Text {
    let fields_p4 = positional_fields(cp_p0, &c_p1.fields);
    let (cmps_p5, _) = comparisons(&Text::lit(""), &Text::lit(""), &c_p1.name, &case_names(c_p1), eq_p2, ord_p3, &case_behind(cp_p0, c_p1));
    crate::emit::cpp::templates::items::case_decl(&c_p1.name, &crate::syntax::lexer::chars::join(&filter(&Array::from(vec![fields_p4.clone(), cmps_p5.clone()]), &(|s_p6: &Text| s_p6 != &Text::lit(""))), &Text::lit("\n")))
}

/// The step machine of `CaseStruct`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CaseStruct: unbounded fn Cp, CaseDef, Bool, Bool -> Text
/// ```
pub struct CaseStruct {
    pub cp_p0: crate::emit::cpp::Cp,
    pub c_p1: crate::lower::model::CaseDef,
    pub eq_p2: bool,
    pub ord_p3: bool,
}

impl prism_rtl::Job<Text> for CaseStruct {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let c_p1 = &self.c_p1;
        let eq_p2 = &self.eq_p2;
        let ord_p3 = &self.ord_p3;
        let c_p1 = c_p1.clone();
        let cp_p0 = cp_p0.clone();
        let eq_p2 = *eq_p2;
        let ord_p3 = *ord_p3;
        call_then(start_positional_fields(cp_p0.clone(), c_p1.fields.clone()), move |positional_fields_13260: Text| {
            let fields_p4 = positional_fields_13260;
            call_then(start_case_behind(cp_p0.clone(), c_p1.clone()), move |case_behind_13370: bool| {
                let (cmps_p5, _) = comparisons(&Text::lit(""), &Text::lit(""), &c_p1.name, &case_names(&c_p1), &eq_p2, &ord_p3, &case_behind_13370);
                prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::case_decl(&c_p1.name, &crate::syntax::lexer::chars::join(&filter(&Array::from(vec![fields_p4.clone(), cmps_p5.clone()]), &(|s_p6: &Text| s_p6 != &Text::lit(""))), &Text::lit("\n"))))
            })
        })
    }
}

/// `Start CaseStruct, x`: what the function value is when passed to `@Run`.
pub fn start_case_struct(cp_p0: crate::emit::cpp::Cp, c_p1: crate::lower::model::CaseDef, eq_p2: bool, ord_p3: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CaseStruct { cp_p0, c_p1, eq_p2, ord_p3 })
}

/// ```prism
/// CaseCmpDefs: unbounded fn Cp, Text, Text, CaseDef, Bool, Bool -> Text
/// ```
pub fn case_cmp_defs(cp_p0: &crate::emit::cpp::Cp, gens_p1: &Text, head_p2: &Text, c_p3: &crate::lower::model::CaseDef, eq_p4: &bool, ord_p5: &bool) -> Text {
    let (_, defs_p6) = comparisons(gens_p1, &Text::from(format!("{}::{}", head_p2, &c_p3.name)), &c_p3.name, &case_names(c_p3), eq_p4, ord_p5, &case_behind(cp_p0, c_p3));
    defs_p6.clone()
}

/// The step machine of `CaseCmpDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CaseCmpDefs: unbounded fn Cp, Text, Text, CaseDef, Bool, Bool -> Text
/// ```
pub struct CaseCmpDefs {
    pub cp_p0: crate::emit::cpp::Cp,
    pub gens_p1: Text,
    pub head_p2: Text,
    pub c_p3: crate::lower::model::CaseDef,
    pub eq_p4: bool,
    pub ord_p5: bool,
}

impl prism_rtl::Job<Text> for CaseCmpDefs {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let gens_p1 = &self.gens_p1;
        let head_p2 = &self.head_p2;
        let c_p3 = &self.c_p3;
        let eq_p4 = &self.eq_p4;
        let ord_p5 = &self.ord_p5;
        let c_p3 = c_p3.clone();
        let cp_p0 = cp_p0.clone();
        let eq_p4 = *eq_p4;
        let gens_p1 = gens_p1.clone();
        let head_p2 = head_p2.clone();
        let ord_p5 = *ord_p5;
        call_then(start_case_behind(cp_p0.clone(), c_p3.clone()), move |case_behind_13763: bool| {
            let (_, defs_p6) = comparisons(&gens_p1, &Text::from(format!("{}::{}", &head_p2, &c_p3.name)), &c_p3.name, &case_names(&c_p3), &eq_p4, &ord_p5, &case_behind_13763);
            prism_rtl::Turn::Finished(defs_p6.clone())
        })
    }
}

/// `Start CaseCmpDefs, x`: what the function value is when passed to `@Run`.
pub fn start_case_cmp_defs(cp_p0: crate::emit::cpp::Cp, gens_p1: Text, head_p2: Text, c_p3: crate::lower::model::CaseDef, eq_p4: bool, ord_p5: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CaseCmpDefs { cp_p0, gens_p1, head_p2, c_p3, eq_p4, ord_p5 })
}

/// ```prism
/// CaseNames: fn CaseDef -> [Text]
/// ```
pub fn case_names(c_p0: &crate::lower::model::CaseDef) -> Array<Text> {
    each(&crate::check::errors::range0(&len(&c_p0.fields)), &(|i_p1: &Nat| Text::from(format!("a{}", i_p1))))
}

/// ```prism
/// CaseBehind: unbounded fn Cp, CaseDef -> Bool
/// ```
pub fn case_behind(cp_p0: &crate::emit::cpp::Cp, c_p1: &crate::lower::model::CaseDef) -> bool {
    run_to_end(fold_job(c_p1.fields.clone(), false, {
        let cp_p0 = cp_p0.clone();
        Rc::new(move |(p0, p1): (bool, (Text, crate::lower::model::OutTy))| {
            let cp_p0 = cp_p0.clone();
            entered(once_job(move || {
                let f_p2 = p0;
                let (_, ft_p3) = p1;
                prism_rtl::Turn::Finished(f_p2 || behind(&cp_p0, &ft_p3))
            }))
        }) as Rc<dyn Fn((bool, (Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `CaseBehind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CaseBehind: unbounded fn Cp, CaseDef -> Bool
/// ```
pub struct CaseBehind {
    pub cp_p0: crate::emit::cpp::Cp,
    pub c_p1: crate::lower::model::CaseDef,
}

impl prism_rtl::Job<bool> for CaseBehind {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let cp_p0 = &self.cp_p0;
        let c_p1 = &self.c_p1;
        fold_job(c_p1.fields.clone(), false, {
            let cp_p0 = cp_p0.clone();
            Rc::new(move |(p0, p1): (bool, (Text, crate::lower::model::OutTy))| {
                let cp_p0 = cp_p0.clone();
                entered(once_job(move || {
                    let f_p2 = p0;
                    let (_, ft_p3) = p1;
                    prism_rtl::Turn::Finished(f_p2 || behind(&cp_p0, &ft_p3))
                }))
            }) as Rc<dyn Fn((bool, (Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>
        }).cycle()
    }
}

/// `Start CaseBehind, x`: what the function value is when passed to `@Run`.
pub fn start_case_behind(cp_p0: crate::emit::cpp::Cp, c_p1: crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(CaseBehind { cp_p0, c_p1 })
}

/// ```prism
/// TypeDefs: unbounded fn Cp, TyDef, Text -> Text
/// ```
pub fn type_defs(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::TyDef, head_p2: &Text) -> Text {
    let gens_p3 = cpp_template_head(&t_p1.params);
    let show_p4 = if &t_p1.show == &crate::lower::model::Shown::ShownDerived {
        Array::from(vec![show_def(cp_p0, t_p1, head_p2, &gens_p3)])
    } else {
        Array::new()
    };
    let pod_p5 = if t_p1.pod {
        Array::from(vec![to_pod_def(cp_p0, t_p1, head_p2, &gens_p3), from_pod_def(cp_p0, t_p1, head_p2, &gens_p3)])
    } else {
        Array::new()
    };
    crate::syntax::lexer::chars::join(&append(&show_p4, &pod_p5), &Text::lit("\n"))
}

/// The step machine of `TypeDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeDefs: unbounded fn Cp, TyDef, Text -> Text
/// ```
pub struct TypeDefs {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::TyDef,
    pub head_p2: Text,
}

impl prism_rtl::Job<Text> for TypeDefs {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        let head_p2 = &self.head_p2;
        let gens_p3 = cpp_template_head(&t_p1.params);
        let show_p4 = if &t_p1.show == &crate::lower::model::Shown::ShownDerived {
            Array::from(vec![show_def(cp_p0, t_p1, head_p2, &gens_p3)])
        } else {
            Array::new()
        };
        let pod_p5 = if t_p1.pod {
            Array::from(vec![to_pod_def(cp_p0, t_p1, head_p2, &gens_p3), from_pod_def(cp_p0, t_p1, head_p2, &gens_p3)])
        } else {
            Array::new()
        };
        prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&append(&show_p4, &pod_p5), &Text::lit("\n")))
    }
}

/// `Start TypeDefs, x`: what the function value is when passed to `@Run`.
pub fn start_type_defs(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::TyDef, head_p2: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TypeDefs { cp_p0, t_p1, head_p2 })
}

/// ```prism
/// ShowDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub fn show_def(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::TyDef, head_p2: &Text, gens_p3: &Text) -> Text {
    let body_p4 = match &t_p1.shape {
        crate::lower::model::TyShape::ShapeRecord => {
            let c_p5 = or(&index(&t_p1.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            Text::from(format!("p.record(\"{}\", {{{}}});", &t_p1.prism, &crate::syntax::lexer::chars::join(&each(&c_p5.fields, &(|(f_p6, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", {}}}", &prism_field(f_p6), &crate::emit::cpp::field_id(f_p6))))), &Text::lit(", "))))
        },
        crate::lower::model::TyShape::ShapeChoice => crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&len(&t_p1.cases)), &(|i_p7: &Nat| show_case(t_p1, i_p7))), &Text::lit("\n")),
        crate::lower::model::TyShape::ShapeNewtype => Text::from(format!("p.choice(\"{}\", {{{}}});", &first_case(t_p1), &crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&first_arity(t_p1)), &(|k_p8: &Nat| Text::from(format!("a{}", k_p8)))), &Text::lit(", ")))),
        crate::lower::model::TyShape::ShapeUnit => Text::from(format!("p.choice(\"{}\", {{}});", &first_case(t_p1))),
    };
    crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}void {}::show(Printer& p) const", gens_p3, head_p2)), &body_p4)
}

/// The step machine of `ShowDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub struct ShowDef {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::TyDef,
    pub head_p2: Text,
    pub gens_p3: Text,
}

impl prism_rtl::Job<Text> for ShowDef {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        let head_p2 = &self.head_p2;
        let gens_p3 = &self.gens_p3;
        let body_p4 = match &t_p1.shape {
            crate::lower::model::TyShape::ShapeRecord => {
                let c_p5 = or(&index(&t_p1.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                Text::from(format!("p.record(\"{}\", {{{}}});", &t_p1.prism, &crate::syntax::lexer::chars::join(&each(&c_p5.fields, &(|(f_p6, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", {}}}", &prism_field(f_p6), &crate::emit::cpp::field_id(f_p6))))), &Text::lit(", "))))
            },
            crate::lower::model::TyShape::ShapeChoice => crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&len(&t_p1.cases)), &(|i_p7: &Nat| show_case(t_p1, i_p7))), &Text::lit("\n")),
            crate::lower::model::TyShape::ShapeNewtype => Text::from(format!("p.choice(\"{}\", {{{}}});", &first_case(t_p1), &crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&first_arity(t_p1)), &(|k_p8: &Nat| Text::from(format!("a{}", k_p8)))), &Text::lit(", ")))),
            crate::lower::model::TyShape::ShapeUnit => Text::from(format!("p.choice(\"{}\", {{}});", &first_case(t_p1))),
        };
        prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}void {}::show(Printer& p) const", gens_p3, head_p2)), &body_p4))
    }
}

/// `Start ShowDef, x`: what the function value is when passed to `@Run`.
pub fn start_show_def(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::TyDef, head_p2: Text, gens_p3: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ShowDef { cp_p0, t_p1, head_p2, gens_p3 })
}

/// ```prism
/// ShowCase: fn TyDef, Nat -> Text
/// ```
pub fn show_case(t_p0: &crate::lower::model::TyDef, i_p1: &Nat) -> Text {
    let c_p2 = or(&index(&t_p0.cases, i_p1), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
    let head_p3 = Text::from(format!("{} (auto c = std::get_if<{}>(&cases()))", &(if i_p1 == &Nat::from(0u32) { Text::lit("if") } else { Text::lit("else if") }), &c_p2.name));
    Text::from(format!("{} p.choice(\"{}\", {{{}}});", &head_p3, &c_p2.prism, &crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&len(&c_p2.fields)), &(|k_p4: &Nat| Text::from(format!("c->a{}", k_p4)))), &Text::lit(", "))))
}

/// ```prism
/// FirstCase: fn TyDef -> Text
/// ```
pub fn first_case(t_p0: &crate::lower::model::TyDef) -> Text {
    or(&index(&t_p0.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: t_p0.prism.clone(), fields: Array::new() }).prism.clone()
}

/// ```prism
/// FirstArity: fn TyDef -> Nat
/// ```
pub fn first_arity(t_p0: &crate::lower::model::TyDef) -> Nat {
    len(&or(&index(&t_p0.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() }).fields)
}

/// ```prism
/// FieldTypes: fn [((Text, OutTy))] -> [OutTy]
/// ```
pub fn field_types(fs_p0: &Array<(Text, crate::lower::model::OutTy)>) -> Array<crate::lower::model::OutTy> {
    each(fs_p0, &(|(_, t_p1): &(Text, crate::lower::model::OutTy)| t_p1.clone()))
}

/// ```prism
/// PositionalFields: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub fn positional_fields(cp_p0: &crate::emit::cpp::Cp, fs_p1: &Array<(Text, crate::lower::model::OutTy)>) -> Text {
    let tys_p2 = field_types(fs_p1);
    crate::syntax::lexer::chars::join(&run_to_end(each_job(crate::check::errors::range0(&len(&tys_p2)), {
        let cp_p0 = cp_p0.clone();
        let tys_p2 = tys_p2.clone();
        Rc::new(move |p0: Nat| {
            let cp_p0 = cp_p0.clone();
            let tys_p2 = tys_p2.clone();
            entered(once_job(move || {
                let i_p3 = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), or(&index(&tys_p2, &i_p3), &crate::lower::model::OutTy::OutUnit)), move |cpp_type_15954: Text| prism_rtl::Turn::Finished(Text::from(format!("{} a{};", &cpp_type_15954, &i_p3))))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"))
}

/// The step machine of `PositionalFields`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PositionalFields: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub struct PositionalFields {
    pub cp_p0: crate::emit::cpp::Cp,
    pub fs_p1: Array<(Text, crate::lower::model::OutTy)>,
}

impl prism_rtl::Job<Text> for PositionalFields {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let fs_p1 = &self.fs_p1;
        let tys_p2 = field_types(fs_p1);
        let cp_p0 = cp_p0.clone();
        call_value(each_job(crate::check::errors::range0(&len(&tys_p2)), {
            let cp_p0 = cp_p0.clone();
            let tys_p2 = tys_p2.clone();
            Rc::new(move |p0: Nat| {
                let cp_p0 = cp_p0.clone();
                let tys_p2 = tys_p2.clone();
                entered(once_job(move || {
                    let i_p3 = p0;
                    call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), or(&index(&tys_p2, &i_p3), &crate::lower::model::OutTy::OutUnit)), move |cpp_type_15954: Text| prism_rtl::Turn::Finished(Text::from(format!("{} a{};", &cpp_type_15954, &i_p3))))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_15922: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&each_15922, &Text::lit("\n"))))
    }
}

/// `Start PositionalFields, x`: what the function value is when passed to `@Run`.
pub fn start_positional_fields(cp_p0: crate::emit::cpp::Cp, fs_p1: Array<(Text, crate::lower::model::OutTy)>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(PositionalFields { cp_p0, fs_p1 })
}

/// ```prism
/// ToPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub fn to_pod_def(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::TyDef, head_p2: &Text, gens_p3: &Text) -> Text {
    let structure_p4 = match &t_p1.shape {
        crate::lower::model::TyShape::ShapeRecord => {
            let c_p6 = or(&index(&t_p1.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            Text::from(format!("Pod::record(\"{}\", {{{}}})", &t_p1.prism, &crate::syntax::lexer::chars::join(&each(&c_p6.fields, &(|(f_p7, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", prism_rtl::to_pod({})}}", &prism_field(f_p7), &crate::emit::cpp::field_id(f_p7))))), &Text::lit(", "))))
        },
        crate::lower::model::TyShape::ShapeChoice => choice_pod(t_p1),
        crate::lower::model::TyShape::ShapeNewtype => Text::from(format!("Pod::choice(\"{}\", {{{}}})", &first_case(t_p1), &crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&first_arity(t_p1)), &(|k_p8: &Nat| Text::from(format!("prism_rtl::to_pod(a{})", k_p8)))), &Text::lit(", ")))),
        crate::lower::model::TyShape::ShapeUnit => Text::from(format!("Pod::choice(\"{}\", {{}})", &first_case(t_p1))),
    };
    let body_p5 = if &t_p1.show == &crate::lower::model::Shown::ShownOwn {
        Text::from(format!("Pod structure = {};\nreturn Pod::shown(prism_rtl::show(*this), structure);", &structure_p4))
    } else {
        Text::from(format!("return {};", &structure_p4))
    };
    crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}Pod {}::to_pod() const", gens_p3, head_p2)), &body_p5)
}

/// The step machine of `ToPodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ToPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub struct ToPodDef {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::TyDef,
    pub head_p2: Text,
    pub gens_p3: Text,
}

impl prism_rtl::Job<Text> for ToPodDef {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        let head_p2 = &self.head_p2;
        let gens_p3 = &self.gens_p3;
        let structure_p4 = match &t_p1.shape {
            crate::lower::model::TyShape::ShapeRecord => {
                let c_p6 = or(&index(&t_p1.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                Text::from(format!("Pod::record(\"{}\", {{{}}})", &t_p1.prism, &crate::syntax::lexer::chars::join(&each(&c_p6.fields, &(|(f_p7, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", prism_rtl::to_pod({})}}", &prism_field(f_p7), &crate::emit::cpp::field_id(f_p7))))), &Text::lit(", "))))
            },
            crate::lower::model::TyShape::ShapeChoice => choice_pod(t_p1),
            crate::lower::model::TyShape::ShapeNewtype => Text::from(format!("Pod::choice(\"{}\", {{{}}})", &first_case(t_p1), &crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&first_arity(t_p1)), &(|k_p8: &Nat| Text::from(format!("prism_rtl::to_pod(a{})", k_p8)))), &Text::lit(", ")))),
            crate::lower::model::TyShape::ShapeUnit => Text::from(format!("Pod::choice(\"{}\", {{}})", &first_case(t_p1))),
        };
        let body_p5 = if &t_p1.show == &crate::lower::model::Shown::ShownOwn {
            Text::from(format!("Pod structure = {};\nreturn Pod::shown(prism_rtl::show(*this), structure);", &structure_p4))
        } else {
            Text::from(format!("return {};", &structure_p4))
        };
        prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}Pod {}::to_pod() const", gens_p3, head_p2)), &body_p5))
    }
}

/// `Start ToPodDef, x`: what the function value is when passed to `@Run`.
pub fn start_to_pod_def(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::TyDef, head_p2: Text, gens_p3: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ToPodDef { cp_p0, t_p1, head_p2, gens_p3 })
}

/// ```prism
/// ChoicePod: fn TyDef -> Text
/// ```
pub fn choice_pod(t_p0: &crate::lower::model::TyDef) -> Text {
    let arms_p1 = each(&crate::check::errors::range0(&len(&t_p0.cases)), &(|i_p2: &Nat| {
        let c_p3 = or(&index(&t_p0.cases, i_p2), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
        Text::from(format!("std::holds_alternative<{}>(cases()) ? Pod::choice(\"{}\", {{{}}})", &c_p3.name, &c_p3.prism, &crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&len(&c_p3.fields)), &(|k_p4: &Nat| Text::from(format!("prism_rtl::to_pod(std::get<{}>(cases()).a{})", &c_p3.name, k_p4)))), &Text::lit(", "))))
    }));
    Text::from(format!("{}\n    : Pod()", &crate::syntax::lexer::chars::join(&arms_p1, &Text::lit("\n    : "))))
}

/// ```prism
/// FromPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub fn from_pod_def(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::TyDef, head_p2: &Text, gens_p3: &Text) -> Text {
    let body_p4 = match &t_p1.shape {
        crate::lower::model::TyShape::ShapeRecord => {
            let c_p5 = or(&index(&t_p1.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            let reads_p6 = crate::syntax::lexer::chars::join(&run_to_end(each_job(c_p5.fields.clone(), {
                let cp_p0 = cp_p0.clone();
                Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                    let cp_p0 = cp_p0.clone();
                    entered(once_job(move || {
                        let (f_p7, ft_p8) = p0;
                        call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), ft_p8.clone()), move |cpp_type_17526: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = TRY(prism_rtl::from_pod<{}>(TRY(crate::prelude::field(whole, \"{}\"))))", &crate::emit::cpp::field_id(&f_p7), &cpp_type_17526, &prism_field(&f_p7)))))
                    }))
                }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
            })), &Text::lit(", "));
            Text::from(format!("return {}{{{}}};", head_p2, &reads_p6))
        },
        _ => {
            let arms_p9 = run_to_end(each_job(t_p1.cases.clone(), {
                let cp_p0 = cp_p0.clone();
                let t_p1 = t_p1.clone();
                let head_p2 = head_p2.clone();
                Rc::new(move |p0: crate::lower::model::CaseDef| {
                    let cp_p0 = cp_p0.clone();
                    let t_p1 = t_p1.clone();
                    let head_p2 = head_p2.clone();
                    entered(once_job(move || {
                        let c_pa = p0;
                        {
                            let n_pb = len(&c_pa.fields);
                            let tys_pc = field_types(&c_pa.fields);
                            call_value(each_job(crate::check::errors::range0(&n_pb), {
                                let cp_p0 = cp_p0.clone();
                                let tys_pc = tys_pc.clone();
                                Rc::new(move |p0: Nat| {
                                    let cp_p0 = cp_p0.clone();
                                    let tys_pc = tys_pc.clone();
                                    entered(once_job(move || {
                                        let i_pf = p0;
                                        call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), or(&index(&tys_pc, &i_pf), &crate::lower::model::OutTy::OutUnit)), move |cpp_type_17872: Text| prism_rtl::Turn::Finished(Text::from(format!("TRY(prism_rtl::from_pod<{}>(c->args[{}]))", &cpp_type_17872, &i_pf))))
                                    }))
                                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
                            }), move |each_17824: Array<Text>| {
                                let args_pd = crate::syntax::lexer::chars::join(&each_17824, &Text::lit(", "));
                                let made_pe = match &t_p1.shape {
                                    crate::lower::model::TyShape::ShapeChoice => Text::from(format!("{}({}{{{}}})", &head_p2, &c_pa.name, &args_pd)),
                                    _ => Text::from(format!("{}{{{}}}", &head_p2, &args_pd)),
                                };
                                prism_rtl::Turn::Finished(Text::from(format!("if (c->ctor == \"{}\" && c->args.size() == {}) return {};", &c_pa.prism, &n_pb, &made_pe)))
                            })
                        }
                    }))
                }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            Text::from(format!("const Pod& p = whole.structure();\nif (auto c = p.if_choice()) {{\n{}\n}}\nreturn mismatch<{}>(\"a {}\", p);", &indent_cpp(&crate::syntax::lexer::chars::join(&arms_p9, &Text::lit("\n"))), head_p2, &t_p1.prism))
        },
    };
    crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}Result<{}> {}::from_pod(const Pod& whole)", gens_p3, head_p2, head_p2)), &body_p4)
}

/// The step machine of `FromPodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FromPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub struct FromPodDef {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::TyDef,
    pub head_p2: Text,
    pub gens_p3: Text,
}

impl prism_rtl::Job<Text> for FromPodDef {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        let head_p2 = &self.head_p2;
        let gens_p3 = &self.gens_p3;
        let body_p4 = match &t_p1.shape {
            crate::lower::model::TyShape::ShapeRecord => {
                let c_p5 = or(&index(&t_p1.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                let reads_p6 = crate::syntax::lexer::chars::join(&run_to_end(each_job(c_p5.fields.clone(), {
                    let cp_p0 = cp_p0.clone();
                    Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                        let cp_p0 = cp_p0.clone();
                        entered(once_job(move || {
                            let (f_p7, ft_p8) = p0;
                            call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), ft_p8.clone()), move |cpp_type_17526: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = TRY(prism_rtl::from_pod<{}>(TRY(crate::prelude::field(whole, \"{}\"))))", &crate::emit::cpp::field_id(&f_p7), &cpp_type_17526, &prism_field(&f_p7)))))
                        }))
                    }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
                })), &Text::lit(", "));
                Text::from(format!("return {}{{{}}};", head_p2, &reads_p6))
            },
            _ => {
                let arms_p9 = run_to_end(each_job(t_p1.cases.clone(), {
                    let cp_p0 = cp_p0.clone();
                    let t_p1 = t_p1.clone();
                    let head_p2 = head_p2.clone();
                    Rc::new(move |p0: crate::lower::model::CaseDef| {
                        let cp_p0 = cp_p0.clone();
                        let t_p1 = t_p1.clone();
                        let head_p2 = head_p2.clone();
                        entered(once_job(move || {
                            let c_pa = p0;
                            {
                                let n_pb = len(&c_pa.fields);
                                let tys_pc = field_types(&c_pa.fields);
                                call_value(each_job(crate::check::errors::range0(&n_pb), {
                                    let cp_p0 = cp_p0.clone();
                                    let tys_pc = tys_pc.clone();
                                    Rc::new(move |p0: Nat| {
                                        let cp_p0 = cp_p0.clone();
                                        let tys_pc = tys_pc.clone();
                                        entered(once_job(move || {
                                            let i_pf = p0;
                                            call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), or(&index(&tys_pc, &i_pf), &crate::lower::model::OutTy::OutUnit)), move |cpp_type_17872: Text| prism_rtl::Turn::Finished(Text::from(format!("TRY(prism_rtl::from_pod<{}>(c->args[{}]))", &cpp_type_17872, &i_pf))))
                                        }))
                                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
                                }), move |each_17824: Array<Text>| {
                                    let args_pd = crate::syntax::lexer::chars::join(&each_17824, &Text::lit(", "));
                                    let made_pe = match &t_p1.shape {
                                        crate::lower::model::TyShape::ShapeChoice => Text::from(format!("{}({}{{{}}})", &head_p2, &c_pa.name, &args_pd)),
                                        _ => Text::from(format!("{}{{{}}}", &head_p2, &args_pd)),
                                    };
                                    prism_rtl::Turn::Finished(Text::from(format!("if (c->ctor == \"{}\" && c->args.size() == {}) return {};", &c_pa.prism, &n_pb, &made_pe)))
                                })
                            }
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
                }));
                Text::from(format!("const Pod& p = whole.structure();\nif (auto c = p.if_choice()) {{\n{}\n}}\nreturn mismatch<{}>(\"a {}\", p);", &indent_cpp(&crate::syntax::lexer::chars::join(&arms_p9, &Text::lit("\n"))), head_p2, &t_p1.prism))
            },
        };
        prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}Result<{}> {}::from_pod(const Pod& whole)", gens_p3, head_p2, head_p2)), &body_p4))
    }
}

/// `Start FromPodDef, x`: what the function value is when passed to `@Run`.
pub fn start_from_pod_def(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::TyDef, head_p2: Text, gens_p3: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FromPodDef { cp_p0, t_p1, head_p2, gens_p3 })
}

/// ```prism
/// PrismField: fn Text -> Text
/// ```
pub fn prism_field(f_p0: &Text) -> Text {
    if &crate::syntax::lexer::chars::last_char(f_p0) == &Text::lit("_") {
        crate::syntax::lexer::chars::before_last(f_p0)
    } else {
        f_p0.clone()
    }
}

/// ```prism
/// IndentCpp: fn Text -> Text
/// ```
pub fn indent_cpp(t_p0: &Text) -> Text {
    crate::syntax::lexer::chars::join(&each(&split_on(t_p0, &Text::lit("\n")), &(|l_p1: &Text| if l_p1 == &Text::lit("") {
        Text::lit("")
    } else {
        Text::from(format!("    {}", l_p1))
    })), &Text::lit("\n"))
}

/// ```prism
/// TagParts: unbounded fn Cp, TagDef -> Parts
/// ```
pub fn tag_parts(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::TagDef) -> Parts {
    let fields_p2 = crate::syntax::lexer::chars::join(&run_to_end(each_job(t_p1.fields.clone(), {
        let cp_p0 = cp_p0.clone();
        Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
            let cp_p0 = cp_p0.clone();
            entered(once_job(move || {
                let (_, f_ph, ft_pi) = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), ft_pi.clone()), move |cpp_type_18900: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_18900, &crate::emit::cpp::field_id(&f_ph)))))
            }))
        }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let pods_p3 = crate::syntax::lexer::chars::join(&each(&t_p1.fields, &(|(p_pj, f_pk, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", prism_rtl::to_pod({})}}", p_pj, &crate::emit::cpp::field_id(f_pk))))), &Text::lit(", "));
    let reads_p4 = crate::syntax::lexer::chars::join(&run_to_end(each_job(t_p1.fields.clone(), {
        let cp_p0 = cp_p0.clone();
        Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
            let cp_p0 = cp_p0.clone();
            entered(once_job(move || {
                let (p_pl, f_pm, ft_pn) = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), ft_pn.clone()), move |cpp_type_19140: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = TRY(prism_rtl::from_pod<{}>(TRY(crate::prelude::field(p, \"{}\"))))", &crate::emit::cpp::field_id(&f_pm), &cpp_type_19140, &p_pl))))
            }))
        }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "));
    let eq_p5 = if t_p1.eq {
        Text::from(format!("bool operator==(const {}&) const = default;", &t_p1.name))
    } else {
        Text::lit("")
    };
    let back_p6 = if t_p1.pod {
        Text::from(format!("static Result<{}> from_pod(const Pod& p);", &t_p1.name))
    } else {
        Text::lit("")
    };
    let deep_p7 = run_to_end(fold_job(t_p1.fields.clone(), false, Rc::new(move |(p0, p1): (bool, (Text, Text, crate::lower::model::OutTy))| entered(once_job(move || {
        let d_po = p0;
        let (_, _, ft_pp) = p1;
        prism_rtl::Turn::Finished(d_po || crate::lower::types::holds_dyn(&ft_pp))
    }))) as Rc<dyn Fn((bool, (Text, Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>));
    let level_decl_p8 = if deep_p7 {
        Text::lit("/// The level as a World reads it: each dynamic it holds sampled at the read point.\nPod level_pod(const Cx& cx) const;\n/// The update events of the dynamics it holds, and of theirs.\nvoid level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const;")
    } else {
        Text::lit("")
    };
    let decl_p9 = crate::emit::cpp::templates::items::cpp_tag_struct(&cpp_source_doc(&Text::from(format!("The `Level` of `{}`:", &t_p1.tag_name)), &t_p1.doc), &t_p1.name, &fields_p2, &t_p1.tag_name, &crate::syntax::lexer::chars::join(&filter(&Array::from(vec![eq_p5.clone(), back_p6.clone(), level_decl_p8.clone()]), &(|s_pq: &Text| s_pq != &Text::lit(""))), &Text::lit("\n")));
    let deep_pods_pa = crate::syntax::lexer::chars::join(&run_to_end(each_job(t_p1.fields.clone(), Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (p_pr, f_ps, ft_pt) = p0;
        prism_rtl::Turn::More(Rc::new(CppDeepField { p_p0: p_pr.clone(), f_p1: f_ps.clone(), ft_p2: ft_pt.clone() }))
    }))) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "));
    let deep_ports_pb = crate::syntax::lexer::chars::join(&filter(&run_to_end(each_job(t_p1.fields.clone(), Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (_, f_pu, ft_pv) = p0;
        prism_rtl::Turn::More(Rc::new(CppDeepPorts { f_p0: f_pu.clone(), ft_p1: ft_pv.clone() }))
    }))) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &(|s_p10: &Text| s_p10 != &Text::lit(""))), &Text::lit("\n"));
    let level_defs_pc = if deep_p7 {
        Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Pod {}::level_pod(const Cx& cx) const", &t_p1.name)), &Text::from(format!("static_cast<void>(cx);\nreturn Pod::element(TAG, {{{}}});", &deep_pods_pa))), crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("void {}::level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const", &t_p1.name)), &Text::from(format!("static_cast<void>(cx);\nstatic_cast<void>(out);{}", &(if &deep_ports_pb == &Text::lit("") {
            Text::lit("")
        } else {
            Text::from(format!("\n{}", &deep_ports_pb))
        }))))])
    } else {
        Array::new()
    };
    let to_pod_pd = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Pod {}::to_pod() const", &t_p1.name)), &Text::from(format!("return Pod::element(TAG, {{{}}});", &pods_p3)));
    let show_pe = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("void {}::show(Printer& p) const", &t_p1.name)), &Text::lit("prism_rtl::to_pod(*this).structure();\nShow<Pod>::show(prism_rtl::to_pod(*this), p);"));
    let from_pod_pf = if t_p1.pod {
        Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Result<{}> {}::from_pod(const Pod& p)", &t_p1.name, &t_p1.name)), &Text::from(format!("if (auto t = p.tag(); t && *t == TAG) return {}{{{}}};\nreturn mismatch<{}>(\"a {}\", p);", &t_p1.name, &reads_p4, &t_p1.name, &t_p1.tag_name)))])
    } else {
        Array::new()
    };
    let deps_pg = crate::emit::cpp::patterns::concat2(&run_to_end(each_job(t_p1.fields.clone(), {
        let cp_p0 = cp_p0.clone();
        Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
            let cp_p0 = cp_p0.clone();
            entered(once_job(move || {
                let (_, _, ft_p11) = p0;
                prism_rtl::Turn::More(Rc::new(ValueDeps { cp_p0: cp_p0.clone(), t_p1: ft_p11.clone() }))
            }))
        }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    })));
    Parts { forward: Array::from(vec![Text::from(format!("struct {};", &t_p1.name))]), values: Array::from(vec![ValueDecl { path_: decl_path(cp_p0, &t_p1.name), deps: deps_pg.clone(), text: decl_p9.clone() }]), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: append(&append(&Array::from(vec![to_pod_pd.clone(), show_pe.clone()]), &from_pod_pf), &level_defs_pc) }
}

/// The step machine of `TagParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagParts: unbounded fn Cp, TagDef -> Parts
/// ```
pub struct TagParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::TagDef,
}

impl prism_rtl::Job<Parts> for TagParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        let cp_p0 = cp_p0.clone();
        let t_p1 = t_p1.clone();
        call_value(each_job(t_p1.fields.clone(), {
            let cp_p0 = cp_p0.clone();
            Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
                let cp_p0 = cp_p0.clone();
                entered(once_job(move || {
                    let (_, f_ph, ft_pi) = p0;
                    call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), ft_pi.clone()), move |cpp_type_18900: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_18900, &crate::emit::cpp::field_id(&f_ph)))))
                }))
            }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_18862: Array<Text>| {
            let fields_p2 = crate::syntax::lexer::chars::join(&each_18862, &Text::lit("\n"));
            let pods_p3 = crate::syntax::lexer::chars::join(&each(&t_p1.fields, &(|(p_pj, f_pk, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", prism_rtl::to_pod({})}}", p_pj, &crate::emit::cpp::field_id(f_pk))))), &Text::lit(", "));
            call_value(each_job(t_p1.fields.clone(), {
                let cp_p0 = cp_p0.clone();
                Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
                    let cp_p0 = cp_p0.clone();
                    entered(once_job(move || {
                        let (p_pl, f_pm, ft_pn) = p0;
                        call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), ft_pn.clone()), move |cpp_type_19140: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = TRY(prism_rtl::from_pod<{}>(TRY(crate::prelude::field(p, \"{}\"))))", &crate::emit::cpp::field_id(&f_pm), &cpp_type_19140, &p_pl))))
                    }))
                }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_19068: Array<Text>| {
                let reads_p4 = crate::syntax::lexer::chars::join(&each_19068, &Text::lit(", "));
                let eq_p5 = if t_p1.eq {
                    Text::from(format!("bool operator==(const {}&) const = default;", &t_p1.name))
                } else {
                    Text::lit("")
                };
                let back_p6 = if t_p1.pod {
                    Text::from(format!("static Result<{}> from_pod(const Pod& p);", &t_p1.name))
                } else {
                    Text::lit("")
                };
                call_value(fold_job(t_p1.fields.clone(), false, Rc::new(move |(p0, p1): (bool, (Text, Text, crate::lower::model::OutTy))| entered(once_job(move || {
                    let d_po = p0;
                    let (_, _, ft_pp) = p1;
                    prism_rtl::Turn::Finished(d_po || crate::lower::types::holds_dyn(&ft_pp))
                }))) as Rc<dyn Fn((bool, (Text, Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>), move |fold_19459: bool| {
                    let deep_p7 = fold_19459;
                    let level_decl_p8 = if deep_p7 {
                        Text::lit("/// The level as a World reads it: each dynamic it holds sampled at the read point.\nPod level_pod(const Cx& cx) const;\n/// The update events of the dynamics it holds, and of theirs.\nvoid level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const;")
                    } else {
                        Text::lit("")
                    };
                    let decl_p9 = crate::emit::cpp::templates::items::cpp_tag_struct(&cpp_source_doc(&Text::from(format!("The `Level` of `{}`:", &t_p1.tag_name)), &t_p1.doc), &t_p1.name, &fields_p2, &t_p1.tag_name, &crate::syntax::lexer::chars::join(&filter(&Array::from(vec![eq_p5.clone(), back_p6.clone(), level_decl_p8.clone()]), &(|s_pq: &Text| s_pq != &Text::lit(""))), &Text::lit("\n")));
                    call_value(each_job(t_p1.fields.clone(), Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| entered(once_job(move || {
                        let (p_pr, f_ps, ft_pt) = p0;
                        prism_rtl::Turn::More(Rc::new(CppDeepField { p_p0: p_pr.clone(), f_p1: f_ps.clone(), ft_p2: ft_pt.clone() }))
                    }))) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_20041: Array<Text>| {
                        let deep_pods_pa = crate::syntax::lexer::chars::join(&each_20041, &Text::lit(", "));
                        call_value(each_job(t_p1.fields.clone(), Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| entered(once_job(move || {
                            let (_, f_pu, ft_pv) = p0;
                            prism_rtl::Turn::More(Rc::new(CppDeepPorts { f_p0: f_pu.clone(), ft_p1: ft_pv.clone() }))
                        }))) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_20135: Array<Text>| {
                            let deep_ports_pb = crate::syntax::lexer::chars::join(&filter(&each_20135, &(|s_p10: &Text| s_p10 != &Text::lit(""))), &Text::lit("\n"));
                            let level_defs_pc = if deep_p7 {
                                Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Pod {}::level_pod(const Cx& cx) const", &t_p1.name)), &Text::from(format!("static_cast<void>(cx);\nreturn Pod::element(TAG, {{{}}});", &deep_pods_pa))), crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("void {}::level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const", &t_p1.name)), &Text::from(format!("static_cast<void>(cx);\nstatic_cast<void>(out);{}", &(if &deep_ports_pb == &Text::lit("") {
                                    Text::lit("")
                                } else {
                                    Text::from(format!("\n{}", &deep_ports_pb))
                                }))))])
                            } else {
                                Array::new()
                            };
                            let to_pod_pd = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Pod {}::to_pod() const", &t_p1.name)), &Text::from(format!("return Pod::element(TAG, {{{}}});", &pods_p3)));
                            let show_pe = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("void {}::show(Printer& p) const", &t_p1.name)), &Text::lit("prism_rtl::to_pod(*this).structure();\nShow<Pod>::show(prism_rtl::to_pod(*this), p);"));
                            let from_pod_pf = if t_p1.pod {
                                Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Result<{}> {}::from_pod(const Pod& p)", &t_p1.name, &t_p1.name)), &Text::from(format!("if (auto t = p.tag(); t && *t == TAG) return {}{{{}}};\nreturn mismatch<{}>(\"a {}\", p);", &t_p1.name, &reads_p4, &t_p1.name, &t_p1.tag_name)))])
                            } else {
                                Array::new()
                            };
                            call_value(each_job(t_p1.fields.clone(), {
                                let cp_p0 = cp_p0.clone();
                                Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
                                    let cp_p0 = cp_p0.clone();
                                    entered(once_job(move || {
                                        let (_, _, ft_p11) = p0;
                                        prism_rtl::Turn::More(Rc::new(ValueDeps { cp_p0: cp_p0.clone(), t_p1: ft_p11.clone() }))
                                    }))
                                }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                            }), move |each_21129: Array<Array<Text>>| {
                                let deps_pg = crate::emit::cpp::patterns::concat2(&each_21129);
                                prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![Text::from(format!("struct {};", &t_p1.name))]), values: Array::from(vec![ValueDecl { path_: decl_path(&cp_p0, &t_p1.name), deps: deps_pg.clone(), text: decl_p9.clone() }]), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: append(&append(&Array::from(vec![to_pod_pd.clone(), show_pe.clone()]), &from_pod_pf), &level_defs_pc) })
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start TagParts, x`: what the function value is when passed to `@Run`.
pub fn start_tag_parts(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::TagDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(TagParts { cp_p0, t_p1 })
}

/// ```prism
/// CppDeepField: unbounded fn Text, Text, OutTy -> Text
/// ```
pub fn cpp_deep_field(p_p0: &Text, f_p1: &Text, ft_p2: &crate::lower::model::OutTy) -> Text {
    Text::from(format!("{{\"{}\", {}}}", p_p0, &cpp_deep_pod(f_p1, ft_p2)))
}

/// The step machine of `CppDeepField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppDeepField: unbounded fn Text, Text, OutTy -> Text
/// ```
pub struct CppDeepField {
    pub p_p0: Text,
    pub f_p1: Text,
    pub ft_p2: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for CppDeepField {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let p_p0 = &self.p_p0;
        let f_p1 = &self.f_p1;
        let ft_p2 = &self.ft_p2;
        let f_p1 = f_p1.clone();
        let ft_p2 = ft_p2.clone();
        let p_p0 = p_p0.clone();
        call_then(start_cpp_deep_pod(f_p1.clone(), ft_p2.clone()), move |cpp_deep_pod_21684: Text| prism_rtl::Turn::Finished(Text::from(format!("{{\"{}\", {}}}", &p_p0, &cpp_deep_pod_21684))))
    }
}

/// `Start CppDeepField, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_deep_field(p_p0: Text, f_p1: Text, ft_p2: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppDeepField { p_p0, f_p1, ft_p2 })
}

/// ```prism
/// CppDeepPod: unbounded fn Text, OutTy -> Text
/// ```
pub fn cpp_deep_pod(f_p0: &Text, ft_p1: &crate::lower::model::OutTy) -> Text {
    'm21773: {
        if let crate::lower::model::OutTy::OutMap(_, m21773_0_1) = ft_p1 && let crate::lower::model::OutTy::OutDyn(m21773_0_1_r_0) = &**m21773_0_1 && let crate::lower::model::OutTy::OutNamed(m21773_0_1_r_0_r_0, _) = &**m21773_0_1_r_0 && (m21773_0_1_r_0_r_0 == &Text::lit("crate::Elem")) {
            break 'm21773 Text::from(format!("prism_rtl::dynamics_pod({}, cx)", &crate::emit::cpp::field_id(f_p0)));
        }
        if let crate::lower::model::OutTy::OutDyn(m21773_1_0) = ft_p1 && let crate::lower::model::OutTy::OutNamed(m21773_1_0_r_0, _) = &**m21773_1_0 && (m21773_1_0_r_0 == &Text::lit("crate::Elem")) {
            break 'm21773 Text::from(format!("prism_rtl::level_pod({}.sample(cx), cx)", &crate::emit::cpp::field_id(f_p0)));
        }
        if let other_p2 = ft_p1 {
            break 'm21773 if crate::lower::types::holds_dyn(other_p2) {
                Text::lit("[] { static_assert(false, \"prismc: a tag field holding a dynamic other than `$Elem` or a map of them is not read deep (claude/incremental-host-document.md, doubt WD)\"); return Pod(); }()")
            } else {
                Text::from(format!("prism_rtl::to_pod({})", &crate::emit::cpp::field_id(f_p0)))
            };
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `CppDeepPod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppDeepPod: unbounded fn Text, OutTy -> Text
/// ```
pub struct CppDeepPod {
    pub f_p0: Text,
    pub ft_p1: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for CppDeepPod {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f_p0 = &self.f_p0;
        let ft_p1 = &self.ft_p1;
        'm21773: {
            if let crate::lower::model::OutTy::OutMap(_, m21773_0_1) = ft_p1 && let crate::lower::model::OutTy::OutDyn(m21773_0_1_r_0) = &**m21773_0_1 && let crate::lower::model::OutTy::OutNamed(m21773_0_1_r_0_r_0, _) = &**m21773_0_1_r_0 && (m21773_0_1_r_0_r_0 == &Text::lit("crate::Elem")) {
                break 'm21773 prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::dynamics_pod({}, cx)", &crate::emit::cpp::field_id(f_p0))));
            }
            if let crate::lower::model::OutTy::OutDyn(m21773_1_0) = ft_p1 && let crate::lower::model::OutTy::OutNamed(m21773_1_0_r_0, _) = &**m21773_1_0 && (m21773_1_0_r_0 == &Text::lit("crate::Elem")) {
                break 'm21773 prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::level_pod({}.sample(cx), cx)", &crate::emit::cpp::field_id(f_p0))));
            }
            if let other_p2 = ft_p1 {
                break 'm21773 {
                    let f_p0 = f_p0.clone();
                    let other_p2 = other_p2.clone();
                    call_then(crate::lower::types::start_holds_dyn(other_p2.clone()), move |holds_dyn_21998: bool| if holds_dyn_21998 {
                        prism_rtl::Turn::Finished(Text::lit("[] { static_assert(false, \"prismc: a tag field holding a dynamic other than `$Elem` or a map of them is not read deep (claude/incremental-host-document.md, doubt WD)\"); return Pod(); }()"))
                    } else {
                        prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::to_pod({})", &crate::emit::cpp::field_id(&f_p0))))
                    })
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start CppDeepPod, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_deep_pod(f_p0: Text, ft_p1: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppDeepPod { f_p0, ft_p1 })
}

/// ```prism
/// CppDeepPorts: unbounded fn Text, OutTy -> Text
/// ```
pub fn cpp_deep_ports(f_p0: &Text, ft_p1: &crate::lower::model::OutTy) -> Text {
    'm22318: {
        if let crate::lower::model::OutTy::OutMap(_, m22318_0_1) = ft_p1 && let crate::lower::model::OutTy::OutDyn(m22318_0_1_r_0) = &**m22318_0_1 && let crate::lower::model::OutTy::OutNamed(m22318_0_1_r_0_r_0, _) = &**m22318_0_1_r_0 && (m22318_0_1_r_0_r_0 == &Text::lit("crate::Elem")) {
            break 'm22318 Text::from(format!("prism_rtl::dynamics_ports({}, cx, out);", &crate::emit::cpp::field_id(f_p0)));
        }
        if let crate::lower::model::OutTy::OutDyn(m22318_1_0) = ft_p1 && let crate::lower::model::OutTy::OutNamed(m22318_1_0_r_0, _) = &**m22318_1_0 && (m22318_1_0_r_0 == &Text::lit("crate::Elem")) {
            break 'm22318 Text::from(format!("out.push_back({}.updates);\nprism_rtl::level_ports({}.sample(cx), cx, out);", &crate::emit::cpp::field_id(f_p0), &crate::emit::cpp::field_id(f_p0)));
        }
        Text::lit("")
    }
}

/// The step machine of `CppDeepPorts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppDeepPorts: unbounded fn Text, OutTy -> Text
/// ```
pub struct CppDeepPorts {
    pub f_p0: Text,
    pub ft_p1: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for CppDeepPorts {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f_p0 = &self.f_p0;
        let ft_p1 = &self.ft_p1;
        'm22318: {
            if let crate::lower::model::OutTy::OutMap(_, m22318_0_1) = ft_p1 && let crate::lower::model::OutTy::OutDyn(m22318_0_1_r_0) = &**m22318_0_1 && let crate::lower::model::OutTy::OutNamed(m22318_0_1_r_0_r_0, _) = &**m22318_0_1_r_0 && (m22318_0_1_r_0_r_0 == &Text::lit("crate::Elem")) {
                break 'm22318 prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::dynamics_ports({}, cx, out);", &crate::emit::cpp::field_id(f_p0))));
            }
            if let crate::lower::model::OutTy::OutDyn(m22318_1_0) = ft_p1 && let crate::lower::model::OutTy::OutNamed(m22318_1_0_r_0, _) = &**m22318_1_0 && (m22318_1_0_r_0 == &Text::lit("crate::Elem")) {
                break 'm22318 prism_rtl::Turn::Finished(Text::from(format!("out.push_back({}.updates);\nprism_rtl::level_ports({}.sample(cx), cx, out);", &crate::emit::cpp::field_id(f_p0), &crate::emit::cpp::field_id(f_p0))));
            }
            prism_rtl::Turn::Finished(Text::lit(""))
        }
    }
}

/// `Start CppDeepPorts, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_deep_ports(f_p0: Text, ft_p1: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppDeepPorts { f_p0, ft_p1 })
}

/// ```prism
/// RowParts: unbounded fn Cp, Text, RowDef -> Parts
/// ```
pub fn row_parts(cp_p0: &crate::emit::cpp::Cp, m_p1: &Text, r_p2: &crate::lower::model::RowDef) -> Parts {
    let names_p3 = each(&r_p2.cases, &(|(v_pf, _): &(Text, Text)| v_pf.clone()));
    let levels_p4 = if r_p2.level {
        Text::lit("\nPod level_pod(const Cx& cx) const;\nvoid level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const;")
    } else {
        Text::lit("")
    };
    let pod_p5 = Text::from(format!("Pod to_pod() const;\nvoid show(Printer& p) const;{}{}", &(if r_p2.pod {
        Text::from(format!("\nstatic Result<{}> from_pod(const Pod& p);", &r_p2.name))
    } else {
        Text::lit("")
    }), &levels_p4));
    let cases_p6 = crate::syntax::lexer::chars::join(&each(&r_p2.cases, &(|(v_pg, st_ph): &(Text, Text)| crate::emit::cpp::templates::items::case_decl(v_pg, &Text::from(format!("{} a0;{}", &row_struct(m_p1, st_ph), &(if r_p2.eq {
        Text::from(format!("\nbool operator==(const {}&) const = default;", v_pg))
    } else {
        Text::lit("")
    })))))), &Text::lit("\n"));
    let cls_p7 = crate::emit::cpp::templates::items::choice_class(&cpp_source_doc(&Text::from(format!("`{}`, a row kind\'s values:", &r_p2.prism)), &r_p2.doc), &Text::lit(""), &r_p2.name, &cases_p6, &crate::syntax::lexer::chars::join(&names_p3, &Text::lit(", ")), &pod_p5);
    let eq_p8 = if r_p2.eq {
        Text::from(format!("\ninline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &r_p2.name, &r_p2.name))
    } else {
        Text::lit("")
    };
    let level_defs_p9 = if r_p2.level {
        Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Pod {}::level_pod(const Cx& cx) const", &r_p2.name)), &Text::lit("return std::visit([&](const auto& c) { return prism_rtl::level_pod(c.a0, cx); }, cases());")), crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("void {}::level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const", &r_p2.name)), &Text::lit("std::visit([&](const auto& c) { prism_rtl::level_ports(c.a0, cx, out); }, cases());"))])
    } else {
        Array::new()
    };
    let to_pod_pa = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Pod {}::to_pod() const", &r_p2.name)), &Text::lit("return std::visit([](const auto& c) { return prism_rtl::to_pod(c.a0); }, cases());"));
    let show_pb = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("void {}::show(Printer& p) const", &r_p2.name)), &Text::lit("Show<Pod>::show(to_pod(), p);"));
    let reads_pc = crate::syntax::lexer::chars::join(&each(&r_p2.cases, &(|(v_pi, st_pj): &(Text, Text)| Text::from(format!("if (*t == {}::TAG) return {}({}{{TRY(prism_rtl::from_pod<{}>(p))}});", &row_struct(m_p1, st_pj), &r_p2.name, v_pi, &row_struct(m_p1, st_pj))))), &Text::lit("\n"));
    let from_pod_pd = if r_p2.pod {
        Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Result<{}> {}::from_pod(const Pod& p)", &r_p2.name, &r_p2.name)), &Text::from(format!("if (auto t = p.tag()) {{\n{}\n}}\nreturn mismatch<{}>(\"a {}\", p);", &indent_cpp(&reads_pc), &r_p2.name, &r_p2.name)))])
    } else {
        Array::new()
    };
    let deps_pe = crate::emit::cpp::patterns::concat2(&run_to_end(each_job(r_p2.cases.clone(), {
        let cp_p0 = cp_p0.clone();
        Rc::new(move |p0: (Text, Text)| {
            let cp_p0 = cp_p0.clone();
            entered(once_job(move || {
                let (_, st_pk) = p0;
                prism_rtl::Turn::More(Rc::new(ValueDeps { cp_p0: cp_p0.clone(), t_p1: crate::lower::model::OutTy::OutNamed(st_pk.clone(), Array::new()) }))
            }))
        }) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    })));
    Parts { forward: Array::from(vec![Text::from(format!("class {};", &r_p2.name))]), values: Array::from(vec![ValueDecl { path_: decl_path(cp_p0, &r_p2.name), deps: deps_pe.clone(), text: Text::from(format!("{}{}", &cls_p7, &eq_p8)) }]), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: append(&append(&Array::from(vec![to_pod_pa.clone(), show_pb.clone()]), &from_pod_pd), &level_defs_p9) }
}

/// The step machine of `RowParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowParts: unbounded fn Cp, Text, RowDef -> Parts
/// ```
pub struct RowParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub m_p1: Text,
    pub r_p2: crate::lower::model::RowDef,
}

impl prism_rtl::Job<Parts> for RowParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let m_p1 = &self.m_p1;
        let r_p2 = &self.r_p2;
        let names_p3 = each(&r_p2.cases, &(|(v_pf, _): &(Text, Text)| v_pf.clone()));
        let levels_p4 = if r_p2.level {
            Text::lit("\nPod level_pod(const Cx& cx) const;\nvoid level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const;")
        } else {
            Text::lit("")
        };
        let pod_p5 = Text::from(format!("Pod to_pod() const;\nvoid show(Printer& p) const;{}{}", &(if r_p2.pod {
            Text::from(format!("\nstatic Result<{}> from_pod(const Pod& p);", &r_p2.name))
        } else {
            Text::lit("")
        }), &levels_p4));
        let cases_p6 = crate::syntax::lexer::chars::join(&each(&r_p2.cases, &(|(v_pg, st_ph): &(Text, Text)| crate::emit::cpp::templates::items::case_decl(v_pg, &Text::from(format!("{} a0;{}", &row_struct(m_p1, st_ph), &(if r_p2.eq {
            Text::from(format!("\nbool operator==(const {}&) const = default;", v_pg))
        } else {
            Text::lit("")
        })))))), &Text::lit("\n"));
        let cls_p7 = crate::emit::cpp::templates::items::choice_class(&cpp_source_doc(&Text::from(format!("`{}`, a row kind\'s values:", &r_p2.prism)), &r_p2.doc), &Text::lit(""), &r_p2.name, &cases_p6, &crate::syntax::lexer::chars::join(&names_p3, &Text::lit(", ")), &pod_p5);
        let eq_p8 = if r_p2.eq {
            Text::from(format!("\ninline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &r_p2.name, &r_p2.name))
        } else {
            Text::lit("")
        };
        let level_defs_p9 = if r_p2.level {
            Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Pod {}::level_pod(const Cx& cx) const", &r_p2.name)), &Text::lit("return std::visit([&](const auto& c) { return prism_rtl::level_pod(c.a0, cx); }, cases());")), crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("void {}::level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const", &r_p2.name)), &Text::lit("std::visit([&](const auto& c) { prism_rtl::level_ports(c.a0, cx, out); }, cases());"))])
        } else {
            Array::new()
        };
        let to_pod_pa = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Pod {}::to_pod() const", &r_p2.name)), &Text::lit("return std::visit([](const auto& c) { return prism_rtl::to_pod(c.a0); }, cases());"));
        let show_pb = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("void {}::show(Printer& p) const", &r_p2.name)), &Text::lit("Show<Pod>::show(to_pod(), p);"));
        let reads_pc = crate::syntax::lexer::chars::join(&each(&r_p2.cases, &(|(v_pi, st_pj): &(Text, Text)| Text::from(format!("if (*t == {}::TAG) return {}({}{{TRY(prism_rtl::from_pod<{}>(p))}});", &row_struct(m_p1, st_pj), &r_p2.name, v_pi, &row_struct(m_p1, st_pj))))), &Text::lit("\n"));
        let from_pod_pd = if r_p2.pod {
            Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("Result<{}> {}::from_pod(const Pod& p)", &r_p2.name, &r_p2.name)), &Text::from(format!("if (auto t = p.tag()) {{\n{}\n}}\nreturn mismatch<{}>(\"a {}\", p);", &indent_cpp(&reads_pc), &r_p2.name, &r_p2.name)))])
        } else {
            Array::new()
        };
        let cp_p0 = cp_p0.clone();
        let r_p2 = r_p2.clone();
        call_value(each_job(r_p2.cases.clone(), {
            let cp_p0 = cp_p0.clone();
            Rc::new(move |p0: (Text, Text)| {
                let cp_p0 = cp_p0.clone();
                entered(once_job(move || {
                    let (_, st_pk) = p0;
                    prism_rtl::Turn::More(Rc::new(ValueDeps { cp_p0: cp_p0.clone(), t_p1: crate::lower::model::OutTy::OutNamed(st_pk.clone(), Array::new()) }))
                }))
            }) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }), move |each_24756: Array<Array<Text>>| {
            let deps_pe = crate::emit::cpp::patterns::concat2(&each_24756);
            prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![Text::from(format!("class {};", &r_p2.name))]), values: Array::from(vec![ValueDecl { path_: decl_path(&cp_p0, &r_p2.name), deps: deps_pe.clone(), text: Text::from(format!("{}{}", &cls_p7, &eq_p8)) }]), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: append(&append(&Array::from(vec![to_pod_pa.clone(), show_pb.clone()]), &from_pod_pd), &level_defs_p9) })
        })
    }
}

/// `Start RowParts, x`: what the function value is when passed to `@Run`.
pub fn start_row_parts(cp_p0: crate::emit::cpp::Cp, m_p1: Text, r_p2: crate::lower::model::RowDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(RowParts { cp_p0, m_p1, r_p2 })
}

/// ```prism
/// RowStruct: fn Text, Text -> Text
/// ```
pub fn row_struct(m_p0: &Text, st_p1: &Text) -> Text {
    if crate::syntax::lexer::chars::contains(st_p1, &Text::lit(":")) || (m_p0 == &Text::lit("")) {
        crate::emit::cpp::type_path(st_p1)
    } else {
        Text::from(format!("crate::{}::{}", m_p0, st_p1))
    }
}

/// ```prism
/// AnswerParts: unbounded fn Cp, AnswerDef -> Parts
/// ```
pub fn answer_parts(cp_p0: &crate::emit::cpp::Cp, a_p1: &crate::lower::model::AnswerDef) -> Parts {
    let names_p2 = each(&a_p1.cases, &(|c_pc: &crate::lower::model::AnswerCase| c_pc.variant.clone()));
    let accessors_p3 = crate::syntax::lexer::chars::join(&run_to_end(each_job(a_p1.cases.clone(), {
        let cp_p0 = cp_p0.clone();
        Rc::new(move |p0: crate::lower::model::AnswerCase| {
            let cp_p0 = cp_p0.clone();
            entered(once_job(move || {
                let c_pd = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), c_pd.ty.clone()), move |cpp_type_25615: Text| prism_rtl::Turn::Finished(Text::from(format!("Result<{}> {}() const;", &cpp_type_25615, &c_pd.accessor))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let members_p4 = Text::from(format!("const char* tag() const;\n{}\nstatic Result<Answer> decode(const Elem& e, const Pod& v);", &accessors_p3));
    let cases_p5 = crate::syntax::lexer::chars::join(&run_to_end(each_job(a_p1.cases.clone(), {
        let cp_p0 = cp_p0.clone();
        Rc::new(move |p0: crate::lower::model::AnswerCase| {
            let cp_p0 = cp_p0.clone();
            entered(once_job(move || {
                let c_pe = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), c_pe.ty.clone()), move |cpp_type_25845: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::case_decl(&c_pe.variant, &Text::from(format!("{} a0;", &cpp_type_25845)))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let cls_p6 = crate::emit::cpp::templates::items::choice_class(&cpp_doc(&Text::lit("`Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host\'s\nsupplier answers a child place with, and what a World\'s answer to a forwarded element\ndecodes to, carrying the tag\'s output.")), &Text::lit(""), &Text::lit("Answer"), &cases_p5, &crate::syntax::lexer::chars::join(&names_p2, &Text::lit(", ")), &members_p4);
    let tags_p7 = crate::syntax::lexer::chars::join(&each(&a_p1.cases, &(|c_pf: &crate::lower::model::AnswerCase| Text::from(format!("if (std::holds_alternative<{}>(cases())) return {}::TAG;", &c_pf.variant, &crate::emit::cpp::type_path(&c_pf.struct_path))))), &Text::lit("\n"));
    let tag_fn_p8 = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::lit("const char* Answer::tag() const"), &Text::from(format!("{}\nprism_rtl::unreachable();", &tags_p7)));
    let getters_p9 = run_to_end(each_job(a_p1.cases.clone(), {
        let cp_p0 = cp_p0.clone();
        Rc::new(move |p0: crate::lower::model::AnswerCase| {
            let cp_p0 = cp_p0.clone();
            entered(once_job(move || {
                let c_pg = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), c_pg.ty.clone()), move |cpp_type_26511: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&cpp_doc(&Text::from(format!("A `{}`\'s answer.", &c_pg.tag_name))), &Text::from(format!("Result<{}> Answer::{}() const", &cpp_type_26511, &c_pg.accessor)), &Text::from(format!("if (auto c = std::get_if<{}>(&cases())) return c->a0;\nreturn unexpected(Fault::answer(str(\"an answer for \", tag(), \", where {}\'s was expected\")));", &c_pg.variant, &c_pg.tag_name)))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let decodes_pa = crate::syntax::lexer::chars::join(&run_to_end(each_job(a_p1.cases.clone(), {
        let cp_p0 = cp_p0.clone();
        Rc::new(move |p0: crate::lower::model::AnswerCase| {
            let cp_p0 = cp_p0.clone();
            entered(once_job(move || {
                let c_ph = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), c_ph.ty.clone()), move |cpp_type_26859: Text| prism_rtl::Turn::Finished(Text::from(format!("if (is<Elem::{}>(e)) return Answer({}{{TRY(prism_rtl::from_pod<{}>(v))}});", &c_ph.variant, &c_ph.variant, &cpp_type_26859))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let decode_pb = crate::emit::cpp::templates::items::cpp_function(&cpp_doc(&Text::lit("A World\'s answer to the element `e`, decoded by its tag.")), &Text::lit("Result<Answer> Answer::decode(const Elem& e, const Pod& v)"), &Text::from(format!("{}\nprism_rtl::unreachable();", &decodes_pa)));
    Parts { forward: Array::from(vec![Text::lit("class Answer;")]), values: Array::from(vec![ValueDecl { path_: Text::lit("Answer"), deps: Array::new(), text: cls_p6.clone() }]), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: append(&Array::from(vec![tag_fn_p8.clone()]), &push(&getters_p9, &decode_pb)) }
}

/// The step machine of `AnswerParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnswerParts: unbounded fn Cp, AnswerDef -> Parts
/// ```
pub struct AnswerParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub a_p1: crate::lower::model::AnswerDef,
}

impl prism_rtl::Job<Parts> for AnswerParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let a_p1 = &self.a_p1;
        let names_p2 = each(&a_p1.cases, &(|c_pc: &crate::lower::model::AnswerCase| c_pc.variant.clone()));
        let a_p1 = a_p1.clone();
        let cp_p0 = cp_p0.clone();
        call_value(each_job(a_p1.cases.clone(), {
            let cp_p0 = cp_p0.clone();
            Rc::new(move |p0: crate::lower::model::AnswerCase| {
                let cp_p0 = cp_p0.clone();
                entered(once_job(move || {
                    let c_pd = p0;
                    call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), c_pd.ty.clone()), move |cpp_type_25615: Text| prism_rtl::Turn::Finished(Text::from(format!("Result<{}> {}() const;", &cpp_type_25615, &c_pd.accessor))))
                }))
            }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_25587: Array<Text>| {
            let accessors_p3 = crate::syntax::lexer::chars::join(&each_25587, &Text::lit("\n"));
            let members_p4 = Text::from(format!("const char* tag() const;\n{}\nstatic Result<Answer> decode(const Elem& e, const Pod& v);", &accessors_p3));
            call_value(each_job(a_p1.cases.clone(), {
                let cp_p0 = cp_p0.clone();
                Rc::new(move |p0: crate::lower::model::AnswerCase| {
                    let cp_p0 = cp_p0.clone();
                    entered(once_job(move || {
                        let c_pe = p0;
                        call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), c_pe.ty.clone()), move |cpp_type_25845: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::case_decl(&c_pe.variant, &Text::from(format!("{} a0;", &cpp_type_25845)))))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_25804: Array<Text>| {
                let cases_p5 = crate::syntax::lexer::chars::join(&each_25804, &Text::lit("\n"));
                let cls_p6 = crate::emit::cpp::templates::items::choice_class(&cpp_doc(&Text::lit("`Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host\'s\nsupplier answers a child place with, and what a World\'s answer to a forwarded element\ndecodes to, carrying the tag\'s output.")), &Text::lit(""), &Text::lit("Answer"), &cases_p5, &crate::syntax::lexer::chars::join(&names_p2, &Text::lit(", ")), &members_p4);
                let tags_p7 = crate::syntax::lexer::chars::join(&each(&a_p1.cases, &(|c_pf: &crate::lower::model::AnswerCase| Text::from(format!("if (std::holds_alternative<{}>(cases())) return {}::TAG;", &c_pf.variant, &crate::emit::cpp::type_path(&c_pf.struct_path))))), &Text::lit("\n"));
                let tag_fn_p8 = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::lit("const char* Answer::tag() const"), &Text::from(format!("{}\nprism_rtl::unreachable();", &tags_p7)));
                call_value(each_job(a_p1.cases.clone(), {
                    let cp_p0 = cp_p0.clone();
                    Rc::new(move |p0: crate::lower::model::AnswerCase| {
                        let cp_p0 = cp_p0.clone();
                        entered(once_job(move || {
                            let c_pg = p0;
                            call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), c_pg.ty.clone()), move |cpp_type_26511: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function(&cpp_doc(&Text::from(format!("A `{}`\'s answer.", &c_pg.tag_name))), &Text::from(format!("Result<{}> Answer::{}() const", &cpp_type_26511, &c_pg.accessor)), &Text::from(format!("if (auto c = std::get_if<{}>(&cases())) return c->a0;\nreturn unexpected(Fault::answer(str(\"an answer for \", tag(), \", where {}\'s was expected\")));", &c_pg.variant, &c_pg.tag_name)))))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_26433: Array<Text>| {
                    let getters_p9 = each_26433;
                    call_value(each_job(a_p1.cases.clone(), {
                        let cp_p0 = cp_p0.clone();
                        Rc::new(move |p0: crate::lower::model::AnswerCase| {
                            let cp_p0 = cp_p0.clone();
                            entered(once_job(move || {
                                let c_ph = p0;
                                call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), c_ph.ty.clone()), move |cpp_type_26859: Text| prism_rtl::Turn::Finished(Text::from(format!("if (is<Elem::{}>(e)) return Answer({}{{TRY(prism_rtl::from_pod<{}>(v))}});", &c_ph.variant, &c_ph.variant, &cpp_type_26859))))
                            }))
                        }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
                    }), move |each_26757: Array<Text>| {
                        let decodes_pa = crate::syntax::lexer::chars::join(&each_26757, &Text::lit("\n"));
                        let decode_pb = crate::emit::cpp::templates::items::cpp_function(&cpp_doc(&Text::lit("A World\'s answer to the element `e`, decoded by its tag.")), &Text::lit("Result<Answer> Answer::decode(const Elem& e, const Pod& v)"), &Text::from(format!("{}\nprism_rtl::unreachable();", &decodes_pa)));
                        prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![Text::lit("class Answer;")]), values: Array::from(vec![ValueDecl { path_: Text::lit("Answer"), deps: Array::new(), text: cls_p6.clone() }]), protos: Array::new(), classes: Array::new(), outer: Array::new(), generic: Array::new(), defs: append(&Array::from(vec![tag_fn_p8.clone()]), &push(&getters_p9, &decode_pb)) })
                    })
                })
            })
        })
    }
}

/// `Start AnswerParts, x`: what the function value is when passed to `@Run`.
pub fn start_answer_parts(cp_p0: crate::emit::cpp::Cp, a_p1: crate::lower::model::AnswerDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(AnswerParts { cp_p0, a_p1 })
}

/// ```prism
/// JobParts: unbounded fn Cp, JobDef -> Parts
/// ```
pub fn job_parts(cp_p0: &crate::emit::cpp::Cp, j_p1: &crate::lower::model::JobDef) -> Parts {
    let gens_p2 = cpp_template_head(&generic_names_of(&j_p1.generics));
    let head_p3 = head_of(&j_p1.name, &generic_names_of(&j_p1.generics));
    let jcp_p4 = crate::emit::cpp::with_fields(cp_p0, &j_p1.fields);
    let fields_p5 = crate::syntax::lexer::chars::join(&run_to_end(each_job(j_p1.fields.clone(), {
        let cp_p0 = cp_p0.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
            let cp_p0 = cp_p0.clone();
            entered(once_job(move || {
                let (n_pe, t_pf) = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), t_pf.clone()), move |cpp_type_27625: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_27625, &crate::emit::cpp::field_id(&n_pe)))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let params_p6 = crate::syntax::lexer::chars::join(&run_to_end(each_job(j_p1.fields.clone(), {
        let cp_p0 = cp_p0.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
            let cp_p0 = cp_p0.clone();
            entered(once_job(move || {
                let (n_pg, t_ph) = p0;
                call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), t_ph.clone()), move |cpp_type_27713: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_27713, &crate::emit::cpp::field_id(&n_pg)))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "));
    let inits_p7 = crate::syntax::lexer::chars::join(&each(&j_p1.fields, &(|(n_pi, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{}(std::move({}))", &crate::emit::cpp::field_id(n_pi), &crate::emit::cpp::field_id(n_pi))))), &Text::lit(", "));
    let ctor_p8 = if &len(&j_p1.fields) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!("{}({}) : {} {{}}", &j_p1.name, &params_p6, &inits_p7))
    };
    let ret_p9 = crate::emit::cpp::cpp_type(cp_p0, &j_p1.ret);
    let decl_pa = crate::emit::cpp::templates::items::job_struct(&cpp_doc(&j_p1.doc), &gens_p2, &j_p1.name, &ret_p9, &fields_p5, &ctor_p8);
    let cycle_pb = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}prism_rtl::Turn<{}> {}::cycle() const", &gens_p2, &ret_p9, &head_p3)), &crate::emit::cpp::stmts::cpp_body(&jcp_p4, &j_p1.body));
    let start_pc = crate::emit::cpp::templates::items::cpp_function(&cpp_doc(&Text::from(format!("`Start {}, x`: what the function value is when passed to `@Run`.", &j_p1.name))), &Text::from(format!("{}prism_rtl::JobRef<{}> {}({})", &gens_p2, &ret_p9, &j_p1.start, &params_p6)), &Text::from(format!("return prism_rtl::make_rc<{}>({});", &head_p3, &crate::syntax::lexer::chars::join(&each(&j_p1.fields, &(|(n_pj, _): &(Text, crate::lower::model::OutTy)| crate::emit::cpp::field_id(n_pj))), &Text::lit(", ")))));
    let generic_pd = &len(&j_p1.generics) > &Nat::from(0u32);
    Parts { forward: Array::from(vec![Text::from(format!("{}struct {};", &gens_p2, &j_p1.name))]), values: Array::new(), protos: Array::from(vec![Text::from(format!("{}prism_rtl::JobRef<{}> {}({});", &gens_p2, &ret_p9, &j_p1.start, &params_p6))]), classes: Array::from(vec![decl_pa.clone()]), outer: Array::new(), generic: if generic_pd {
        Array::from(vec![cycle_pb.clone(), start_pc.clone()])
    } else {
        Array::new()
    }, defs: if generic_pd {
        Array::new()
    } else {
        Array::from(vec![cycle_pb.clone(), start_pc.clone()])
    } }
}

/// The step machine of `JobParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobParts: unbounded fn Cp, JobDef -> Parts
/// ```
pub struct JobParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub j_p1: crate::lower::model::JobDef,
}

impl prism_rtl::Job<Parts> for JobParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let j_p1 = &self.j_p1;
        let gens_p2 = cpp_template_head(&generic_names_of(&j_p1.generics));
        let head_p3 = head_of(&j_p1.name, &generic_names_of(&j_p1.generics));
        let jcp_p4 = crate::emit::cpp::with_fields(cp_p0, &j_p1.fields);
        let cp_p0 = cp_p0.clone();
        let j_p1 = j_p1.clone();
        call_value(each_job(j_p1.fields.clone(), {
            let cp_p0 = cp_p0.clone();
            Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                let cp_p0 = cp_p0.clone();
                entered(once_job(move || {
                    let (n_pe, t_pf) = p0;
                    call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), t_pf.clone()), move |cpp_type_27625: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_27625, &crate::emit::cpp::field_id(&n_pe)))))
                }))
            }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_27596: Array<Text>| {
            let fields_p5 = crate::syntax::lexer::chars::join(&each_27596, &Text::lit("\n"));
            call_value(each_job(j_p1.fields.clone(), {
                let cp_p0 = cp_p0.clone();
                Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                    let cp_p0 = cp_p0.clone();
                    entered(once_job(move || {
                        let (n_pg, t_ph) = p0;
                        call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), t_ph.clone()), move |cpp_type_27713: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_27713, &crate::emit::cpp::field_id(&n_pg)))))
                    }))
                }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_27684: Array<Text>| {
                let params_p6 = crate::syntax::lexer::chars::join(&each_27684, &Text::lit(", "));
                let inits_p7 = crate::syntax::lexer::chars::join(&each(&j_p1.fields, &(|(n_pi, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{}(std::move({}))", &crate::emit::cpp::field_id(n_pi), &crate::emit::cpp::field_id(n_pi))))), &Text::lit(", "));
                let ctor_p8 = if &len(&j_p1.fields) == &Nat::from(0u32) {
                    Text::lit("")
                } else {
                    Text::from(format!("{}({}) : {} {{}}", &j_p1.name, &params_p6, &inits_p7))
                };
                call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), j_p1.ret.clone()), move |cpp_type_27945: Text| {
                    let ret_p9 = cpp_type_27945;
                    let decl_pa = crate::emit::cpp::templates::items::job_struct(&cpp_doc(&j_p1.doc), &gens_p2, &j_p1.name, &ret_p9, &fields_p5, &ctor_p8);
                    call_then(crate::emit::cpp::stmts::start_cpp_body(jcp_p4.clone(), j_p1.body.clone()), move |cpp_body_28123: Text| {
                        let cycle_pb = crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}prism_rtl::Turn<{}> {}::cycle() const", &gens_p2, &ret_p9, &head_p3)), &cpp_body_28123);
                        let start_pc = crate::emit::cpp::templates::items::cpp_function(&cpp_doc(&Text::from(format!("`Start {}, x`: what the function value is when passed to `@Run`.", &j_p1.name))), &Text::from(format!("{}prism_rtl::JobRef<{}> {}({})", &gens_p2, &ret_p9, &j_p1.start, &params_p6)), &Text::from(format!("return prism_rtl::make_rc<{}>({});", &head_p3, &crate::syntax::lexer::chars::join(&each(&j_p1.fields, &(|(n_pj, _): &(Text, crate::lower::model::OutTy)| crate::emit::cpp::field_id(n_pj))), &Text::lit(", ")))));
                        let generic_pd = &len(&j_p1.generics) > &Nat::from(0u32);
                        prism_rtl::Turn::Finished(Parts { forward: Array::from(vec![Text::from(format!("{}struct {};", &gens_p2, &j_p1.name))]), values: Array::new(), protos: Array::from(vec![Text::from(format!("{}prism_rtl::JobRef<{}> {}({});", &gens_p2, &ret_p9, &j_p1.start, &params_p6))]), classes: Array::from(vec![decl_pa.clone()]), outer: Array::new(), generic: if generic_pd {
                            Array::from(vec![cycle_pb.clone(), start_pc.clone()])
                        } else {
                            Array::new()
                        }, defs: if generic_pd {
                            Array::new()
                        } else {
                            Array::from(vec![cycle_pb.clone(), start_pc.clone()])
                        } })
                    })
                })
            })
        })
    }
}

/// `Start JobParts, x`: what the function value is when passed to `@Run`.
pub fn start_job_parts(cp_p0: crate::emit::cpp::Cp, j_p1: crate::lower::model::JobDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(JobParts { cp_p0, j_p1 })
}

/// ```prism
/// TraitParts: unbounded fn Cp, TraitDef -> Parts
/// ```
pub fn trait_parts(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::TraitDef) -> Parts {
    let defaults_p2 = filter(&t_p1.methods, &(|f_p6: &crate::lower::model::FnDef| f_p6.public));
    let defs_p3 = run_to_end(each_job(defaults_p2.clone(), {
        let cp_p0 = cp_p0.clone();
        Rc::new(move |p0: crate::lower::model::FnDef| {
            let cp_p0 = cp_p0.clone();
            entered(once_job(move || {
                let f_p7 = p0;
                prism_rtl::Turn::More(Rc::new(FnDefinition { cp_p0: cp_p0.clone(), f_p1: with_generics(&f_p7, &Array::from(vec![(Text::lit("Self"), Array::new())])) }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let protos_p4 = run_to_end(each_job(t_p1.methods.clone(), {
        let cp_p0 = cp_p0.clone();
        Rc::new(move |p0: crate::lower::model::FnDef| {
            let cp_p0 = cp_p0.clone();
            entered(once_job(move || {
                let f_p8 = p0;
                call_then(start_fn_signature(cp_p0.clone(), with_generics(&f_p8, &Array::from(vec![(Text::lit("Self"), Array::new())]))), move |fn_signature_29363: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{};", &fn_signature_29363, &(if f_p8.public { Text::lit("") } else { Text::lit(" = delete") })))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let generic_p5 = if &len(&defaults_p2) == &Nat::from(0u32) {
        Array::new()
    } else {
        Array::from(vec![crate::emit::cpp::templates::items::trait_namespace(&t_p1.name, &crate::syntax::lexer::chars::join(&defs_p3, &Text::lit("\n")))])
    };
    let mut this: Parts = generic_only(&generic_p5);
    this.protos = Array::from(vec![crate::emit::cpp::templates::items::trait_namespace(&t_p1.name, &crate::syntax::lexer::chars::join(&protos_p4, &Text::lit("\n")))]);
    this
}

/// The step machine of `TraitParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TraitParts: unbounded fn Cp, TraitDef -> Parts
/// ```
pub struct TraitParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::TraitDef,
}

impl prism_rtl::Job<Parts> for TraitParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        let defaults_p2 = filter(&t_p1.methods, &(|f_p6: &crate::lower::model::FnDef| f_p6.public));
        let cp_p0 = cp_p0.clone();
        let t_p1 = t_p1.clone();
        call_value(each_job(defaults_p2.clone(), {
            let cp_p0 = cp_p0.clone();
            Rc::new(move |p0: crate::lower::model::FnDef| {
                let cp_p0 = cp_p0.clone();
                entered(once_job(move || {
                    let f_p7 = p0;
                    prism_rtl::Turn::More(Rc::new(FnDefinition { cp_p0: cp_p0.clone(), f_p1: with_generics(&f_p7, &Array::from(vec![(Text::lit("Self"), Array::new())])) }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_29247: Array<Text>| {
            let defs_p3 = each_29247;
            call_value(each_job(t_p1.methods.clone(), {
                let cp_p0 = cp_p0.clone();
                Rc::new(move |p0: crate::lower::model::FnDef| {
                    let cp_p0 = cp_p0.clone();
                    entered(once_job(move || {
                        let f_p8 = p0;
                        call_then(start_fn_signature(cp_p0.clone(), with_generics(&f_p8, &Array::from(vec![(Text::lit("Self"), Array::new())]))), move |fn_signature_29363: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{};", &fn_signature_29363, &(if f_p8.public { Text::lit("") } else { Text::lit(" = delete") })))))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_29340: Array<Text>| {
                let protos_p4 = each_29340;
                let generic_p5 = if &len(&defaults_p2) == &Nat::from(0u32) {
                    Array::new()
                } else {
                    Array::from(vec![crate::emit::cpp::templates::items::trait_namespace(&t_p1.name, &crate::syntax::lexer::chars::join(&defs_p3, &Text::lit("\n")))])
                };
                prism_rtl::Turn::Finished({
                    let mut this: Parts = generic_only(&generic_p5);
                    this.protos = Array::from(vec![crate::emit::cpp::templates::items::trait_namespace(&t_p1.name, &crate::syntax::lexer::chars::join(&protos_p4, &Text::lit("\n")))]);
                    this
                })
            })
        })
    }
}

/// `Start TraitParts, x`: what the function value is when passed to `@Run`.
pub fn start_trait_parts(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::TraitDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(TraitParts { cp_p0, t_p1 })
}

/// ```prism
/// ImplParts: unbounded fn Cp, ImplDef -> Parts
/// ```
pub fn impl_parts(cp_p0: &crate::emit::cpp::Cp, i_p1: &crate::lower::model::ImplDef) -> Parts {
    let head_p2 = crate::emit::cpp::cpp_type(cp_p0, &i_p1.head);
    let gens_p3 = cpp_template_head(&generic_names_of(&i_p1.generics));
    let fns_p4 = run_to_end(each_job(i_p1.methods.clone(), {
        let cp_p0 = cp_p0.clone();
        let i_p1 = i_p1.clone();
        Rc::new(move |p0: crate::lower::model::FnDef| {
            let cp_p0 = cp_p0.clone();
            let i_p1 = i_p1.clone();
            entered(once_job(move || {
                let f_p6 = p0;
                prism_rtl::Turn::More(Rc::new(FnParts { cp_p0: cp_p0.clone(), f_p1: with_generics(&f_p6, &i_p1.generics) }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Parts>>>
    }));
    let own_p5 = fold(&fns_p4, &no_parts(), &(|acc_p7: &Parts, p_p8: &Parts| join_parts(acc_p7, p_p8)));
    match &i_p1.cls {
        m30350_0 if (m30350_0 == &Text::lit("Prelude.Show")) => {
            let shown_p9 = or(&index(&each(&i_p1.methods, &(|f_pa: &crate::lower::model::FnDef| f_pa.name.clone())), &Nat::from(0u32)), &Text::lit("show"));
            join_parts(&own_p5, &protos_defs(&Array::new(), &Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}void {}::show(Printer& p) const", &gens_p3, &head_p2)), &Text::from(format!("p.raw({}(*this).to_string());", &shown_p9)))])))
        },
        m30350_1 if (m30350_1 == &Text::lit("Prelude.Eq")) => {
            let eq_pb = fold(&i_p1.methods, &Text::lit(""), &(|acc_pc: &Text, f_pd: &crate::lower::model::FnDef| if !crate::syntax::lexer::chars::has_prefix(&f_pd.name, &Text::lit("ne")) && (acc_pc == &Text::lit("")) {
                f_pd.name.clone()
            } else {
                acc_pc.clone()
            }));
            join_parts(&own_p5, &protos_defs(&Array::from(vec![Text::from(format!("{}bool operator==(const {}& a, const {}& b);", &gens_p3, &head_p2, &head_p2))]), &Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}bool operator==(const {}& a, const {}& b)", &gens_p3, &head_p2, &head_p2)), &Text::from(format!("return {}(a, b);", &eq_pb)))])))
        },
        _ => {
            let tr_pe = crate::syntax::lexer::chars::drop_prefix(&crate::emit::cpp::type_path(&i_p1.tr), &Text::lit("crate::"));
            let own_pf = !crate::syntax::lexer::chars::contains(&tr_pe, &Text::lit("::"));
            let ns_pg = if own_pf {
                tr_pe.clone()
            } else {
                Text::from(format!("impl_{}", &crate::syntax::lexer::chars::join(&split_on(&tr_pe, &Text::lit("::")), &Text::lit("_"))))
            };
            let in_trait_ph = run_to_end(each_job(i_p1.methods.clone(), {
                let ns_pg = ns_pg.clone();
                let cp_p0 = cp_p0.clone();
                let i_p1 = i_p1.clone();
                Rc::new(move |p0: crate::lower::model::FnDef| {
                    let ns_pg = ns_pg.clone();
                    let cp_p0 = cp_p0.clone();
                    let i_p1 = i_p1.clone();
                    entered(once_job(move || {
                        let f_pk = p0;
                        call_then(start_fn_definition(cp_p0.clone(), with_generics(&f_pk, &i_p1.generics)), move |fn_definition_31217: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::trait_namespace(&ns_pg, &fn_definition_31217)))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            let protos_pi = run_to_end(each_job(i_p1.methods.clone(), {
                let ns_pg = ns_pg.clone();
                let cp_p0 = cp_p0.clone();
                let i_p1 = i_p1.clone();
                Rc::new(move |p0: crate::lower::model::FnDef| {
                    let ns_pg = ns_pg.clone();
                    let cp_p0 = cp_p0.clone();
                    let i_p1 = i_p1.clone();
                    entered(once_job(move || {
                        let f_pl = p0;
                        call_then(start_fn_signature(cp_p0.clone(), with_generics(&f_pl, &i_p1.generics)), move |fn_signature_31331: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::trait_namespace(&ns_pg, &Text::from(format!("{};", &fn_signature_31331)))))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            let outer_pj = if own_pf {
                Array::new()
            } else {
                Array::from(vec![crate::emit::cpp::templates::items::trait_namespace(&tr_pe, &crate::syntax::lexer::chars::join(&each(&i_p1.methods, &(|f_pm: &crate::lower::model::FnDef| Text::from(format!("using ::crate::{}::{}::{};", &cp_p0.home, &ns_pg, &crate::emit::cpp::cpp_id(&f_pm.name))))), &Text::lit("\n")))])
            };
            {
                let mut this: Parts = protos_defs(&protos_pi, &in_trait_ph);
                this.outer = outer_pj.clone();
                this
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ImplParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ImplParts: unbounded fn Cp, ImplDef -> Parts
/// ```
pub struct ImplParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub i_p1: crate::lower::model::ImplDef,
}

impl prism_rtl::Job<Parts> for ImplParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let i_p1 = &self.i_p1;
        let cp_p0 = cp_p0.clone();
        let i_p1 = i_p1.clone();
        call_then(crate::emit::cpp::start_cpp_type(cp_p0.clone(), i_p1.head.clone()), move |cpp_type_30132: Text| {
            let head_p2 = cpp_type_30132;
            let gens_p3 = cpp_template_head(&generic_names_of(&i_p1.generics));
            call_value(each_job(i_p1.methods.clone(), {
                let cp_p0 = cp_p0.clone();
                let i_p1 = i_p1.clone();
                Rc::new(move |p0: crate::lower::model::FnDef| {
                    let cp_p0 = cp_p0.clone();
                    let i_p1 = i_p1.clone();
                    entered(once_job(move || {
                        let f_p6 = p0;
                        prism_rtl::Turn::More(Rc::new(FnParts { cp_p0: cp_p0.clone(), f_p1: with_generics(&f_p6, &i_p1.generics) }))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Parts>>>
            }), move |each_30224: Array<Parts>| {
                let fns_p4 = each_30224;
                let own_p5 = fold(&fns_p4, &no_parts(), &(|acc_p7: &Parts, p_p8: &Parts| join_parts(acc_p7, p_p8)));
                match &i_p1.cls {
                    m30350_0 if (m30350_0 == &Text::lit("Prelude.Show")) => {
                        let shown_p9 = or(&index(&each(&i_p1.methods, &(|f_pa: &crate::lower::model::FnDef| f_pa.name.clone())), &Nat::from(0u32)), &Text::lit("show"));
                        prism_rtl::Turn::Finished(join_parts(&own_p5, &protos_defs(&Array::new(), &Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}void {}::show(Printer& p) const", &gens_p3, &head_p2)), &Text::from(format!("p.raw({}(*this).to_string());", &shown_p9)))]))))
                    },
                    m30350_1 if (m30350_1 == &Text::lit("Prelude.Eq")) => {
                        let eq_pb = fold(&i_p1.methods, &Text::lit(""), &(|acc_pc: &Text, f_pd: &crate::lower::model::FnDef| if !crate::syntax::lexer::chars::has_prefix(&f_pd.name, &Text::lit("ne")) && (acc_pc == &Text::lit("")) {
                            f_pd.name.clone()
                        } else {
                            acc_pc.clone()
                        }));
                        prism_rtl::Turn::Finished(join_parts(&own_p5, &protos_defs(&Array::from(vec![Text::from(format!("{}bool operator==(const {}& a, const {}& b);", &gens_p3, &head_p2, &head_p2))]), &Array::from(vec![crate::emit::cpp::templates::items::cpp_function(&Text::lit(""), &Text::from(format!("{}bool operator==(const {}& a, const {}& b)", &gens_p3, &head_p2, &head_p2)), &Text::from(format!("return {}(a, b);", &eq_pb)))]))))
                    },
                    _ => {
                        let tr_pe = crate::syntax::lexer::chars::drop_prefix(&crate::emit::cpp::type_path(&i_p1.tr), &Text::lit("crate::"));
                        let own_pf = !crate::syntax::lexer::chars::contains(&tr_pe, &Text::lit("::"));
                        let ns_pg = if own_pf {
                            tr_pe.clone()
                        } else {
                            Text::from(format!("impl_{}", &crate::syntax::lexer::chars::join(&split_on(&tr_pe, &Text::lit("::")), &Text::lit("_"))))
                        };
                        call_value(each_job(i_p1.methods.clone(), {
                            let ns_pg = ns_pg.clone();
                            let cp_p0 = cp_p0.clone();
                            let i_p1 = i_p1.clone();
                            Rc::new(move |p0: crate::lower::model::FnDef| {
                                let ns_pg = ns_pg.clone();
                                let cp_p0 = cp_p0.clone();
                                let i_p1 = i_p1.clone();
                                entered(once_job(move || {
                                    let f_pk = p0;
                                    call_then(start_fn_definition(cp_p0.clone(), with_generics(&f_pk, &i_p1.generics)), move |fn_definition_31217: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::trait_namespace(&ns_pg, &fn_definition_31217)))
                                }))
                            }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
                        }), move |each_31176: Array<Text>| {
                            let in_trait_ph = each_31176;
                            call_value(each_job(i_p1.methods.clone(), {
                                let ns_pg = ns_pg.clone();
                                let cp_p0 = cp_p0.clone();
                                let i_p1 = i_p1.clone();
                                Rc::new(move |p0: crate::lower::model::FnDef| {
                                    let ns_pg = ns_pg.clone();
                                    let cp_p0 = cp_p0.clone();
                                    let i_p1 = i_p1.clone();
                                    entered(once_job(move || {
                                        let f_pl = p0;
                                        call_then(start_fn_signature(cp_p0.clone(), with_generics(&f_pl, &i_p1.generics)), move |fn_signature_31331: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::trait_namespace(&ns_pg, &Text::from(format!("{};", &fn_signature_31331)))))
                                    }))
                                }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
                            }), move |each_31289: Array<Text>| {
                                let protos_pi = each_31289;
                                let outer_pj = if own_pf {
                                    Array::new()
                                } else {
                                    Array::from(vec![crate::emit::cpp::templates::items::trait_namespace(&tr_pe, &crate::syntax::lexer::chars::join(&each(&i_p1.methods, &(|f_pm: &crate::lower::model::FnDef| Text::from(format!("using ::crate::{}::{}::{};", &cp_p0.home, &ns_pg, &crate::emit::cpp::cpp_id(&f_pm.name))))), &Text::lit("\n")))])
                                };
                                prism_rtl::Turn::Finished({
                                    let mut this: Parts = protos_defs(&protos_pi, &in_trait_ph);
                                    this.outer = outer_pj.clone();
                                    this
                                })
                            })
                        })
                    },
                    _ => unreachable!("no arm matched"),
                }
            })
        })
    }
}

/// `Start ImplParts, x`: what the function value is when passed to `@Run`.
pub fn start_impl_parts(cp_p0: crate::emit::cpp::Cp, i_p1: crate::lower::model::ImplDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(ImplParts { cp_p0, i_p1 })
}

/// ```prism
/// WithGenerics: fn FnDef, [((Text, [Text]))] -> FnDef
/// ```
pub fn with_generics(f_p0: &crate::lower::model::FnDef, gs_p1: &Array<(Text, Array<Text>)>) -> crate::lower::model::FnDef {
    let mut this: crate::lower::model::FnDef = f_p0.clone();
    this.generics = append(gs_p1, &this.generics);
    this
}

/// ```prism
/// GenericOnly: fn [Text] -> Parts
/// ```
pub fn generic_only(xs_p0: &Array<Text>) -> Parts {
    let mut this: Parts = no_parts();
    this.generic = xs_p0.clone();
    this
}

/// ```prism
/// ProtosDefs: fn [Text], [Text] -> Parts
/// ```
pub fn protos_defs(ps_p0: &Array<Text>, ds_p1: &Array<Text>) -> Parts {
    let mut this: Parts = no_parts();
    this.protos = ps_p0.clone();
    this.defs = ds_p1.clone();
    this
}
