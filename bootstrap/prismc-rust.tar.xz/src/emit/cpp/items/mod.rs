//! The module `Emit.Cpp.Items`, from `target/bootstrap/src/prismc/emit/cpp/items.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Parts`:
///
/// ```prism
/// type Parts = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Parts {
    pub forward_p: Array<Text>,
    pub values_p: Array<ValueDecl>,
    pub protos_p: Array<Text>,
    pub classes_p: Array<Text>,
    pub outer_p: Array<Text>,
    pub generic_p: Array<Text>,
    pub defs_p: Array<Text>,
}

impl Show for Parts {
    fn show(&self, p: &mut Printer) {
        p.record("Parts", &[("forward", &self.forward_p), ("values", &self.values_p), ("protos", &self.protos_p), ("classes", &self.classes_p), ("outer", &self.outer_p), ("generic", &self.generic_p), ("defs", &self.defs_p)]);
    }
}

impl ToPod for Parts {
    fn to_pod(&self) -> Pod {
        Pod::record("Parts", vec![("forward", self.forward_p.to_pod()), ("values", self.values_p.to_pod()), ("protos", self.protos_p.to_pod()), ("classes", self.classes_p.to_pod()), ("outer", self.outer_p.to_pod()), ("generic", self.generic_p.to_pod()), ("defs", self.defs_p.to_pod())])
    }
}

impl FromPod for Parts {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Parts { forward_p: FromPod::from_pod(field(p, "forward")?)?, values_p: FromPod::from_pod(field(p, "values")?)?, protos_p: FromPod::from_pod(field(p, "protos")?)?, classes_p: FromPod::from_pod(field(p, "classes")?)?, outer_p: FromPod::from_pod(field(p, "outer")?)?, generic_p: FromPod::from_pod(field(p, "generic")?)?, defs_p: FromPod::from_pod(field(p, "defs")?)? })
    }
}

/// `ValueDecl`:
///
/// ```prism
/// type ValueDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ValueDecl {
    pub path_p: Text,
    pub deps_p: Array<Text>,
    pub text_p: Text,
}

impl Show for ValueDecl {
    fn show(&self, p: &mut Printer) {
        p.record("ValueDecl", &[("path", &self.path_p), ("deps", &self.deps_p), ("text", &self.text_p)]);
    }
}

impl ToPod for ValueDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("ValueDecl", vec![("path", self.path_p.to_pod()), ("deps", self.deps_p.to_pod()), ("text", self.text_p.to_pod())])
    }
}

impl FromPod for ValueDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ValueDecl { path_p: FromPod::from_pod(field(p, "path")?)?, deps_p: FromPod::from_pod(field(p, "deps")?)?, text_p: FromPod::from_pod(field(p, "text")?)? })
    }
}

/// ```prism
/// CppTemplateHead: fn [Text] -> Text
/// ```
pub fn cpp_template_head_f(xs0: &Array<Text>) -> Text {
    match xs0 {
        c0_0 if (c0_0.len() == 0) => Text::lit(""),
        ps_p0 => Text::from(format!("template <{}>\n", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(ps_p0, &(|p_p1: &Text| Text::from(format!("class {}", p_p1)))), &Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// GenericNamesOf: fn [((Text, [Text]))] -> [Text]
/// ```
pub fn generic_names_of_f(gs_p0: &Array<(Text, Array<Text>)>) -> Array<Text> {
    crate::prelude::each(gs_p0, &(|(g_p1, _): &(Text, Array<Text>)| g_p1.clone()))
}

/// ```prism
/// HeadOf: fn Text, [Text] -> Text
/// ```
pub fn head_of_f(name_p0: &Text, xs1: &Array<Text>) -> Text {
    match xs1 {
        c0_1 if (c0_1.len() == 0) => name_p0.clone(),
        ps_p2 => Text::from(format!("{}<{}>", name_p0, &crate::syntax::lexer::chars::join_f(ps_p2, &Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CppParams: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub fn cpp_params_f(cp_p0: &crate::emit::cpp::Cp, ps_p1: &Array<(Text, crate::lower::model::OutTy)>) -> Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(ps_p1.clone(), {
        let cp_p0x = cp_p0.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (n_p2, t_p3) = p0;
                crate::prelude::call_then(crate::emit::cpp::expr::start_param_type_f(cp_p0xy.clone(), t_p3.clone()), move |param_type_f_1510: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_f_1510, &crate::emit::cpp::cpp_id_f(&n_p2)))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "))
}

/// The step machine of `CppParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppParams: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub struct CppParams {
    pub cp_p0: crate::emit::cpp::Cp,
    pub ps_p1: Array<(Text, crate::lower::model::OutTy)>,
}

impl prism_rtl::Job<Text> for CppParams {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let ps_p1 = &self.ps_p1;
        let cp_p0x = cp_p0.clone();
        let ps_p1x = ps_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(ps_p1x.clone(), {
            let cp_p0xx = cp_p0x.clone();
            Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (n_p2, t_p3) = p0;
                    crate::prelude::call_then(crate::emit::cpp::expr::start_param_type_f(cp_p0xxy.clone(), t_p3.clone()), move |param_type_f_1510: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &param_type_f_1510, &crate::emit::cpp::cpp_id_f(&n_p2)))))
                }))
            }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_1487: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join_f(&each_1487, &Text::lit(", "))))
    }
}

/// `Start CppParams, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_params_f(cp_p0: crate::emit::cpp::Cp, ps_p1: Array<(Text, crate::lower::model::OutTy)>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppParams { cp_p0, ps_p1 })
}

/// ```prism
/// FnSignature: unbounded fn Cp, FnDef -> Text
/// ```
pub fn fn_signature_f(cp_p0: &crate::emit::cpp::Cp, f_p1: &crate::lower::model::FnDef) -> Text {
    Text::from(format!("{}{} {}({})", &cpp_template_head_f(&generic_names_of_f(&f_p1.generics_p)), &crate::emit::cpp::cpp_type_f(cp_p0, &f_p1.ret_p), &crate::emit::cpp::cpp_id_f(&f_p1.name_p), &cpp_params_f(cp_p0, &f_p1.params_p)))
}

/// The step machine of `FnSignature`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnSignature: unbounded fn Cp, FnDef -> Text
/// ```
pub struct FnSignature {
    pub cp_p0: crate::emit::cpp::Cp,
    pub f_p1: crate::lower::model::FnDef,
}

impl prism_rtl::Job<Text> for FnSignature {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let f_p1 = &self.f_p1;
        let cp_p0x = cp_p0.clone();
        let f_p1x = f_p1.clone();
        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), f_p1x.ret_p.clone()), move |cpp_type_f_1741: Text| crate::prelude::call_then(start_cpp_params_f(cp_p0x.clone(), f_p1x.params_p.clone()), move |cpp_params_f_1776: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{} {}({})", &cpp_template_head_f(&generic_names_of_f(&f_p1x.generics_p)), &cpp_type_f_1741, &crate::emit::cpp::cpp_id_f(&f_p1x.name_p), &cpp_params_f_1776)))))
    }
}

/// `Start FnSignature, x`: what the function value is when passed to `@Run`.
pub fn start_fn_signature_f(cp_p0: crate::emit::cpp::Cp, f_p1: crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FnSignature { cp_p0, f_p1 })
}

/// ```prism
/// FnDefinition: unbounded fn Cp, FnDef -> Text
/// ```
pub fn fn_definition_f(cp_p0: &crate::emit::cpp::Cp, f_p1: &crate::lower::model::FnDef) -> Text {
    crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&f_p1.doc_p), &fn_signature_f(cp_p0, f_p1), &crate::emit::cpp::stmts::cpp_body_f(&with_params_f(cp_p0, &f_p1.params_p), &f_p1.body_p))
}

/// The step machine of `FnDefinition`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnDefinition: unbounded fn Cp, FnDef -> Text
/// ```
pub struct FnDefinition {
    pub cp_p0: crate::emit::cpp::Cp,
    pub f_p1: crate::lower::model::FnDef,
}

impl prism_rtl::Job<Text> for FnDefinition {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let f_p1 = &self.f_p1;
        let cp_p0x = cp_p0.clone();
        let f_p1x = f_p1.clone();
        crate::prelude::call_then(start_fn_signature_f(cp_p0x.clone(), f_p1x.clone()), move |fn_signature_f_1901: Text| crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_body_f(with_params_f(&cp_p0x, &f_p1x.params_p), f_p1x.body_p.clone()), move |cpp_body_f_1922: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&f_p1x.doc_p), &fn_signature_f_1901, &cpp_body_f_1922))))
    }
}

/// `Start FnDefinition, x`: what the function value is when passed to `@Run`.
pub fn start_fn_definition_f(cp_p0: crate::emit::cpp::Cp, f_p1: crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FnDefinition { cp_p0, f_p1 })
}

/// ```prism
/// WithParams: fn Cp, [((Text, OutTy))] -> Cp
/// ```
pub fn with_params_f(cp_p0: &crate::emit::cpp::Cp, ps_p1: &Array<(Text, crate::lower::model::OutTy)>) -> crate::emit::cpp::Cp {
    crate::prelude::fold(ps_p1, cp_p0, &(|c_p2: &crate::emit::cpp::Cp, (n_p3, t_p4): &(Text, crate::lower::model::OutTy)| {
        let mut this: crate::emit::cpp::Cp = c_p2.clone();
        this.pointers_p = crate::prelude::insert(&this.pointers_p, n_p3, &crate::emit::cpp::expr::is_pointer_ty_f(c_p2, &crate::emit::cpp::expr::unref_f(t_p4)));
        this.local_types_p = crate::prelude::insert(&this.local_types_p, n_p3, t_p4);
        this
    }))
}

/// ```prism
/// ValueDeps: unbounded fn Cp, OutTy -> [Text]
/// ```
pub fn value_deps_f(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::OutTy) -> Array<Text> {
    match t_p1 {
        crate::lower::model::OutTy::OutNamed(n_p2, args_p3) => {
            let own_p4 = match crate::emit::cpp::type_of_o(cp_p0, n_p2) {
                Some(info_p5) => if ((((&info_p5.kind_p == &Text::lit("record")) || (&info_p5.kind_p == &Text::lit("newtype"))) || (&info_p5.kind_p == &Text::lit("unit"))) || (&info_p5.kind_p == &Text::lit("tag"))) || (&info_p5.kind_p == &Text::lit("choice")) {
                    Array::from(vec![dep_path_f(cp_p0, n_p2)])
                } else {
                    Array::new()
                },
                None => Array::new(),
            };
            crate::prelude::append(&own_p4, &crate::emit::cpp::patterns::concat2_f(&crate::prelude::run_to_end(crate::prelude::each_job(args_p3.clone(), {
                let cp_p0x = cp_p0.clone();
                Rc::new(move |p0: crate::lower::model::OutTy| {
                    let cp_p0xy = cp_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_p6 = p0;
                        prism_rtl::Turn::More(Rc::new(ValueDeps { cp_p0: cp_p0xy.clone(), t_p1: a_p6.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }))))
        },
        crate::lower::model::OutTy::OutOpt(i_p7) => value_deps_f(cp_p0, &**i_p7),
        crate::lower::model::OutTy::OutRes(i_p8) => value_deps_f(cp_p0, &**i_p8),
        crate::lower::model::OutTy::OutCell(i_p9) => value_deps_f(cp_p0, &**i_p9),
        crate::lower::model::OutTy::OutTuple(ts_pa) => crate::emit::cpp::patterns::concat2_f(&crate::prelude::run_to_end(crate::prelude::each_job(ts_pa.clone(), {
            let cp_p0x = cp_p0.clone();
            Rc::new(move |p0: crate::lower::model::OutTy| {
                let cp_p0xy = cp_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pb = p0;
                    prism_rtl::Turn::More(Rc::new(ValueDeps { cp_p0: cp_p0xy.clone(), t_p1: a_pb.clone() }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }))),
        _ => Array::new(),
    }
}

/// The step machine of `ValueDeps`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ValueDeps: unbounded fn Cp, OutTy -> [Text]
/// ```
pub struct ValueDeps {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Array<Text>> for ValueDeps {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        match t_p1 {
            crate::lower::model::OutTy::OutNamed(n_p2, args_p3) => {
                let own_p4 = match crate::emit::cpp::type_of_o(cp_p0, n_p2) {
                    Some(info_p5) => if ((((&info_p5.kind_p == &Text::lit("record")) || (&info_p5.kind_p == &Text::lit("newtype"))) || (&info_p5.kind_p == &Text::lit("unit"))) || (&info_p5.kind_p == &Text::lit("tag"))) || (&info_p5.kind_p == &Text::lit("choice")) {
                        Array::from(vec![dep_path_f(cp_p0, n_p2)])
                    } else {
                        Array::new()
                    },
                    None => Array::new(),
                };
                let args_p3x = args_p3.clone();
                let cp_p0x = cp_p0.clone();
                crate::prelude::call_value(crate::prelude::each_job(args_p3x.clone(), {
                    let cp_p0xx = cp_p0x.clone();
                    Rc::new(move |p0: crate::lower::model::OutTy| {
                        let cp_p0xxy = cp_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_p6 = p0;
                            prism_rtl::Turn::More(Rc::new(ValueDeps { cp_p0: cp_p0xxy.clone(), t_p1: a_p6.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_3884: Array<Array<Text>>| prism_rtl::Turn::Finished(crate::prelude::append(&own_p4, &crate::emit::cpp::patterns::concat2_f(&each_3884))))
            },
            crate::lower::model::OutTy::OutOpt(i_p7) => prism_rtl::Turn::More(Rc::new(ValueDeps { cp_p0: cp_p0.clone(), t_p1: (**i_p7).clone() })),
            crate::lower::model::OutTy::OutRes(i_p8) => prism_rtl::Turn::More(Rc::new(ValueDeps { cp_p0: cp_p0.clone(), t_p1: (**i_p8).clone() })),
            crate::lower::model::OutTy::OutCell(i_p9) => prism_rtl::Turn::More(Rc::new(ValueDeps { cp_p0: cp_p0.clone(), t_p1: (**i_p9).clone() })),
            crate::lower::model::OutTy::OutTuple(ts_pa) => {
                let cp_p0x = cp_p0.clone();
                let ts_pax = ts_pa.clone();
                crate::prelude::call_value(crate::prelude::each_job(ts_pax.clone(), {
                    let cp_p0xx = cp_p0x.clone();
                    Rc::new(move |p0: crate::lower::model::OutTy| {
                        let cp_p0xxy = cp_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_pb = p0;
                            prism_rtl::Turn::More(Rc::new(ValueDeps { cp_p0: cp_p0xxy.clone(), t_p1: a_pb.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_4035: Array<Array<Text>>| prism_rtl::Turn::Finished(crate::emit::cpp::patterns::concat2_f(&each_4035)))
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start ValueDeps, x`: what the function value is when passed to `@Run`.
pub fn start_value_deps_f(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ValueDeps { cp_p0, t_p1 })
}

/// ```prism
/// DepPath: fn Cp, Text -> Text
/// ```
pub fn dep_path_f(cp_p0: &crate::emit::cpp::Cp, n_p1: &Text) -> Text {
    let abs_p2 = crate::emit::cpp::absolute_f(cp_p0, n_p1);
    let q_p3 = crate::syntax::lexer::chars::drop_prefix_f(n_p1, &Text::lit("crate::"));
    match crate::prelude::get(&cp_p0.types_p, &abs_p2) {
        Some(_) => abs_p2.clone(),
        None => q_p3.clone(),
    }
}

/// ```prism
/// Behind: unbounded fn Cp, OutTy -> Bool
/// ```
pub fn behind_f(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::OutTy) -> bool {
    match t_p1 {
        crate::lower::model::OutTy::OutRc(_) => true,
        crate::lower::model::OutTy::OutOpt(i_p2) => behind_f(cp_p0, &**i_p2),
        crate::lower::model::OutTy::OutRes(i_p3) => behind_f(cp_p0, &**i_p3),
        crate::lower::model::OutTy::OutCell(i_p4) => behind_f(cp_p0, &**i_p4),
        crate::lower::model::OutTy::OutTuple(ts_p5) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_p5.clone(), false, {
            let cp_p0x = cp_p0.clone();
            Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                let cp_p0xy = cp_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let f_p6 = p0;
                    let x_p7 = p1;
                    prism_rtl::Turn::Finished(f_p6 || behind_f(&cp_p0xy, &x_p7))
                }))
            }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::lower::model::OutTy::OutArray(i_p8) => names_program_type_f(cp_p0, &**i_p8),
        crate::lower::model::OutTy::OutMap(k_p9, v_pa) => names_program_type_f(cp_p0, &**k_p9) || names_program_type_f(cp_p0, &**v_pa),
        crate::lower::model::OutTy::OutFn(ps_pb, r_pc) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_pb.clone(), names_program_type_f(cp_p0, &**r_pc), {
            let cp_p0x = cp_p0.clone();
            Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                let cp_p0xy = cp_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let f_pd = p0;
                    let x_pe = p1;
                    prism_rtl::Turn::Finished(f_pd || names_program_type_f(&cp_p0xy, &x_pe))
                }))
            }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::lower::model::OutTy::OutDyn(i_pf) => names_program_type_f(cp_p0, &**i_pf),
        crate::lower::model::OutTy::OutEvent(i_pg) => names_program_type_f(cp_p0, &**i_pg),
        crate::lower::model::OutTy::OutNamed(_, args_ph) => crate::prelude::run_to_end(crate::prelude::fold_job(args_ph.clone(), false, {
            let cp_p0x = cp_p0.clone();
            Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                let cp_p0xy = cp_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let f_pi = p0;
                    let x_pj = p1;
                    prism_rtl::Turn::Finished(f_pi || behind_f(&cp_p0xy, &x_pj))
                }))
            }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        _ => false,
    }
}

/// The step machine of `Behind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Behind: unbounded fn Cp, OutTy -> Bool
/// ```
pub struct Behind {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::OutTy,
}

impl prism_rtl::Job<bool> for Behind {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        match t_p1 {
            crate::lower::model::OutTy::OutRc(_) => prism_rtl::Turn::Finished(true),
            crate::lower::model::OutTy::OutOpt(i_p2) => prism_rtl::Turn::More(Rc::new(Behind { cp_p0: cp_p0.clone(), t_p1: (**i_p2).clone() })),
            crate::lower::model::OutTy::OutRes(i_p3) => prism_rtl::Turn::More(Rc::new(Behind { cp_p0: cp_p0.clone(), t_p1: (**i_p3).clone() })),
            crate::lower::model::OutTy::OutCell(i_p4) => prism_rtl::Turn::More(Rc::new(Behind { cp_p0: cp_p0.clone(), t_p1: (**i_p4).clone() })),
            crate::lower::model::OutTy::OutTuple(ts_p5) => crate::prelude::fold_job(ts_p5.clone(), false, {
                let cp_p0x = cp_p0.clone();
                Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                    let cp_p0xy = cp_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_p6 = p0;
                        let x_p7 = p1;
                        prism_rtl::Turn::Finished(f_p6 || behind_f(&cp_p0xy, &x_p7))
                    }))
                }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            crate::lower::model::OutTy::OutArray(i_p8) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_p8).clone() })),
            crate::lower::model::OutTy::OutMap(k_p9, v_pa) => {
                let cp_p0x = cp_p0.clone();
                let k_p9x = (**k_p9).clone();
                let v_pax = (**v_pa).clone();
                crate::prelude::call_then(start_names_program_type_f(cp_p0x.clone(), k_p9x.clone()), move |names_program_type_f_5369: bool| prism_rtl::Turn::Finished(names_program_type_f_5369 || names_program_type_f(&cp_p0x, &v_pax)))
            },
            crate::lower::model::OutTy::OutFn(ps_pb, r_pc) => {
                let cp_p0x = cp_p0.clone();
                let ps_pbx = ps_pb.clone();
                let r_pcx = (**r_pc).clone();
                crate::prelude::call_then(start_names_program_type_f(cp_p0x.clone(), r_pcx.clone()), move |names_program_type_f_5446: bool| crate::prelude::fold_job(ps_pbx.clone(), names_program_type_f_5446, {
                    let cp_p0xx = cp_p0x.clone();
                    Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                        let cp_p0xxy = cp_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let f_pd = p0;
                            let x_pe = p1;
                            prism_rtl::Turn::Finished(f_pd || names_program_type_f(&cp_p0xxy, &x_pe))
                        }))
                    }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
                }).cycle())
            },
            crate::lower::model::OutTy::OutDyn(i_pf) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_pf).clone() })),
            crate::lower::model::OutTy::OutEvent(i_pg) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_pg).clone() })),
            crate::lower::model::OutTy::OutNamed(_, args_ph) => crate::prelude::fold_job(args_ph.clone(), false, {
                let cp_p0x = cp_p0.clone();
                Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                    let cp_p0xy = cp_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_pi = p0;
                        let x_pj = p1;
                        prism_rtl::Turn::Finished(f_pi || behind_f(&cp_p0xy, &x_pj))
                    }))
                }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start Behind, x`: what the function value is when passed to `@Run`.
pub fn start_behind_f(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(Behind { cp_p0, t_p1 })
}

/// ```prism
/// NamesProgramType: unbounded fn Cp, OutTy -> Bool
/// ```
pub fn names_program_type_f(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::OutTy) -> bool {
    match t_p1 {
        crate::lower::model::OutTy::OutNamed(n_p2, args_p3) => {
            let own_p4 = match crate::emit::cpp::type_of_o(cp_p0, n_p2) {
                Some(info_p5) => (&info_p5.kind_p != &Text::lit("node")) && (&info_p5.kind_p != &Text::lit("job")),
                None => false,
            };
            own_p4 || crate::prelude::run_to_end(crate::prelude::fold_job(args_p3.clone(), false, {
                let cp_p0x = cp_p0.clone();
                Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                    let cp_p0xy = cp_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_p6 = p0;
                        let x_p7 = p1;
                        prism_rtl::Turn::Finished(f_p6 || names_program_type_f(&cp_p0xy, &x_p7))
                    }))
                }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
            }))
        },
        crate::lower::model::OutTy::OutOpt(i_p8) => names_program_type_f(cp_p0, &**i_p8),
        crate::lower::model::OutTy::OutRes(i_p9) => names_program_type_f(cp_p0, &**i_p9),
        crate::lower::model::OutTy::OutRc(i_pa) => names_program_type_f(cp_p0, &**i_pa),
        crate::lower::model::OutTy::OutCell(i_pb) => names_program_type_f(cp_p0, &**i_pb),
        crate::lower::model::OutTy::OutArray(i_pc) => names_program_type_f(cp_p0, &**i_pc),
        crate::lower::model::OutTy::OutMap(k_pd, v_pe) => names_program_type_f(cp_p0, &**k_pd) || names_program_type_f(cp_p0, &**v_pe),
        crate::lower::model::OutTy::OutTuple(ts_pf) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_pf.clone(), false, {
            let cp_p0x = cp_p0.clone();
            Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                let cp_p0xy = cp_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let f_pg = p0;
                    let x_ph = p1;
                    prism_rtl::Turn::Finished(f_pg || names_program_type_f(&cp_p0xy, &x_ph))
                }))
            }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::lower::model::OutTy::OutFn(ps_pi, r_pj) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_pi.clone(), names_program_type_f(cp_p0, &**r_pj), {
            let cp_p0x = cp_p0.clone();
            Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                let cp_p0xy = cp_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let f_pk = p0;
                    let x_pl = p1;
                    prism_rtl::Turn::Finished(f_pk || names_program_type_f(&cp_p0xy, &x_pl))
                }))
            }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::lower::model::OutTy::OutDyn(i_pm) => names_program_type_f(cp_p0, &**i_pm),
        crate::lower::model::OutTy::OutEvent(i_pn) => names_program_type_f(cp_p0, &**i_pn),
        _ => false,
    }
}

/// The step machine of `NamesProgramType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamesProgramType: unbounded fn Cp, OutTy -> Bool
/// ```
pub struct NamesProgramType {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::OutTy,
}

impl prism_rtl::Job<bool> for NamesProgramType {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        match t_p1 {
            crate::lower::model::OutTy::OutNamed(n_p2, args_p3) => {
                let own_p4 = match crate::emit::cpp::type_of_o(cp_p0, n_p2) {
                    Some(info_p5) => (&info_p5.kind_p != &Text::lit("node")) && (&info_p5.kind_p != &Text::lit("job")),
                    None => false,
                };
                prism_rtl::Turn::Finished(own_p4 || crate::prelude::run_to_end(crate::prelude::fold_job(args_p3.clone(), false, {
                    let cp_p0x = cp_p0.clone();
                    Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                        let cp_p0xy = cp_p0x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let f_p6 = p0;
                            let x_p7 = p1;
                            prism_rtl::Turn::Finished(f_p6 || names_program_type_f(&cp_p0xy, &x_p7))
                        }))
                    }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
                })))
            },
            crate::lower::model::OutTy::OutOpt(i_p8) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_p8).clone() })),
            crate::lower::model::OutTy::OutRes(i_p9) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_p9).clone() })),
            crate::lower::model::OutTy::OutRc(i_pa) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_pa).clone() })),
            crate::lower::model::OutTy::OutCell(i_pb) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_pb).clone() })),
            crate::lower::model::OutTy::OutArray(i_pc) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_pc).clone() })),
            crate::lower::model::OutTy::OutMap(k_pd, v_pe) => {
                let cp_p0x = cp_p0.clone();
                let k_pdx = (**k_pd).clone();
                let v_pex = (**v_pe).clone();
                crate::prelude::call_then(start_names_program_type_f(cp_p0x.clone(), k_pdx.clone()), move |names_program_type_f_6249: bool| prism_rtl::Turn::Finished(names_program_type_f_6249 || names_program_type_f(&cp_p0x, &v_pex)))
            },
            crate::lower::model::OutTy::OutTuple(ts_pf) => crate::prelude::fold_job(ts_pf.clone(), false, {
                let cp_p0x = cp_p0.clone();
                Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                    let cp_p0xy = cp_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_pg = p0;
                        let x_ph = p1;
                        prism_rtl::Turn::Finished(f_pg || names_program_type_f(&cp_p0xy, &x_ph))
                    }))
                }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            crate::lower::model::OutTy::OutFn(ps_pi, r_pj) => {
                let cp_p0x = cp_p0.clone();
                let ps_pix = ps_pi.clone();
                let r_pjx = (**r_pj).clone();
                crate::prelude::call_then(start_names_program_type_f(cp_p0x.clone(), r_pjx.clone()), move |names_program_type_f_6395: bool| crate::prelude::fold_job(ps_pix.clone(), names_program_type_f_6395, {
                    let cp_p0xx = cp_p0x.clone();
                    Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| {
                        let cp_p0xxy = cp_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let f_pk = p0;
                            let x_pl = p1;
                            prism_rtl::Turn::Finished(f_pk || names_program_type_f(&cp_p0xxy, &x_pl))
                        }))
                    }) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>
                }).cycle())
            },
            crate::lower::model::OutTy::OutDyn(i_pm) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_pm).clone() })),
            crate::lower::model::OutTy::OutEvent(i_pn) => prism_rtl::Turn::More(Rc::new(NamesProgramType { cp_p0: cp_p0.clone(), t_p1: (**i_pn).clone() })),
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start NamesProgramType, x`: what the function value is when passed to `@Run`.
pub fn start_names_program_type_f(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(NamesProgramType { cp_p0, t_p1 })
}

/// ```prism
/// let noParts
/// ```
pub fn no_parts_p() -> Parts {
    Parts { forward_p: Array::new(), values_p: Array::new(), protos_p: Array::new(), classes_p: Array::new(), outer_p: Array::new(), generic_p: Array::new(), defs_p: Array::new() }
}

/// ```prism
/// JoinParts: fn Parts, Parts -> Parts
/// ```
pub fn join_parts_f(a_p0: &Parts, b_p1: &Parts) -> Parts {
    Parts { forward_p: crate::prelude::append(&a_p0.forward_p, &b_p1.forward_p), values_p: crate::prelude::append(&a_p0.values_p, &b_p1.values_p), protos_p: crate::prelude::append(&a_p0.protos_p, &b_p1.protos_p), classes_p: crate::prelude::append(&a_p0.classes_p, &b_p1.classes_p), outer_p: crate::prelude::append(&a_p0.outer_p, &b_p1.outer_p), generic_p: crate::prelude::append(&a_p0.generic_p, &b_p1.generic_p), defs_p: crate::prelude::append(&a_p0.defs_p, &b_p1.defs_p) }
}

/// ```prism
/// ItemParts: unbounded fn Cp, Item -> Parts
/// ```
pub fn item_parts_f(cp_p0: &crate::emit::cpp::Cp, it_p1: &crate::lower::model::Item) -> Parts {
    match it_p1 {
        crate::lower::model::Item::ItType(t_p2) => type_parts_f(cp_p0, t_p2),
        crate::lower::model::Item::ItTag(t_p3) => tag_parts_f(cp_p0, t_p3),
        crate::lower::model::Item::ItRow(r_p4) => row_parts_f(cp_p0, &cp_p0.home_p, r_p4),
        crate::lower::model::Item::ItFn(f_p5) => fn_parts_f(cp_p0, f_p5),
        crate::lower::model::Item::ItJob(j_p6) => job_parts_f(cp_p0, j_p6),
        crate::lower::model::Item::ItNode(n_p7) => crate::emit::cpp::program::node_parts_f(cp_p0, n_p7),
        crate::lower::model::Item::ItTrait(t_p8) => trait_parts_f(cp_p0, t_p8),
        crate::lower::model::Item::ItImpl(i_p9) => impl_parts_f(cp_p0, i_p9),
        crate::lower::model::Item::ItNote(t_pa) => protos_defs_f(&Array::new(), &Array::from(vec![Text::from(format!("// {}", t_pa))])),
        crate::lower::model::Item::ItRefused(t_pb) => protos_defs_f(&Array::new(), &Array::from(vec![Text::from(format!("compile_error!(\"{}{}\");", &crate::lower::expr::lowering_refusal_p(), &crate::lower::expr::escape_f(t_pb)))])),
    }
}

/// The step machine of `ItemParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ItemParts: unbounded fn Cp, Item -> Parts
/// ```
pub struct ItemParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub it_p1: crate::lower::model::Item,
}

impl prism_rtl::Job<Parts> for ItemParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let it_p1 = &self.it_p1;
        match it_p1 {
            crate::lower::model::Item::ItType(t_p2) => prism_rtl::Turn::More(Rc::new(TypeParts { cp_p0: cp_p0.clone(), t_p1: t_p2.clone() })),
            crate::lower::model::Item::ItTag(t_p3) => prism_rtl::Turn::More(Rc::new(TagParts { cp_p0: cp_p0.clone(), t_p1: t_p3.clone() })),
            crate::lower::model::Item::ItRow(r_p4) => prism_rtl::Turn::More(Rc::new(RowParts { cp_p0: cp_p0.clone(), m_p1: cp_p0.home_p.clone(), r_p2: r_p4.clone() })),
            crate::lower::model::Item::ItFn(f_p5) => prism_rtl::Turn::More(Rc::new(FnParts { cp_p0: cp_p0.clone(), f_p1: f_p5.clone() })),
            crate::lower::model::Item::ItJob(j_p6) => prism_rtl::Turn::More(Rc::new(JobParts { cp_p0: cp_p0.clone(), j_p1: j_p6.clone() })),
            crate::lower::model::Item::ItNode(n_p7) => prism_rtl::Turn::More(Rc::new(crate::emit::cpp::program::NodeParts { cp_p0: cp_p0.clone(), n_p1: n_p7.clone() })),
            crate::lower::model::Item::ItTrait(t_p8) => prism_rtl::Turn::More(Rc::new(TraitParts { cp_p0: cp_p0.clone(), t_p1: t_p8.clone() })),
            crate::lower::model::Item::ItImpl(i_p9) => prism_rtl::Turn::More(Rc::new(ImplParts { cp_p0: cp_p0.clone(), i_p1: i_p9.clone() })),
            crate::lower::model::Item::ItNote(t_pa) => prism_rtl::Turn::Finished(protos_defs_f(&Array::new(), &Array::from(vec![Text::from(format!("// {}", t_pa))]))),
            crate::lower::model::Item::ItRefused(t_pb) => prism_rtl::Turn::Finished(protos_defs_f(&Array::new(), &Array::from(vec![Text::from(format!("compile_error!(\"{}{}\");", &crate::lower::expr::lowering_refusal_p(), &crate::lower::expr::escape_f(t_pb)))]))),
        }
    }
}

/// `Start ItemParts, x`: what the function value is when passed to `@Run`.
pub fn start_item_parts_f(cp_p0: crate::emit::cpp::Cp, it_p1: crate::lower::model::Item) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(ItemParts { cp_p0, it_p1 })
}

/// ```prism
/// FnParts: unbounded fn Cp, FnDef -> Parts
/// ```
pub fn fn_parts_f(cp_p0: &crate::emit::cpp::Cp, f_p1: &crate::lower::model::FnDef) -> Parts {
    if &crate::prelude::len(&f_p1.generics_p) > &Nat::from(0u32) {
        {
            let mut this: Parts = generic_only_f(&Array::from(vec![fn_definition_f(cp_p0, f_p1)]));
            this.protos_p = Array::from(vec![Text::from(format!("{};", &fn_signature_f(cp_p0, f_p1)))]);
            this
        }
    } else {
        protos_defs_f(&Array::from(vec![Text::from(format!("{};", &fn_signature_f(cp_p0, f_p1)))]), &Array::from(vec![fn_definition_f(cp_p0, f_p1)]))
    }
}

/// The step machine of `FnParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnParts: unbounded fn Cp, FnDef -> Parts
/// ```
pub struct FnParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub f_p1: crate::lower::model::FnDef,
}

impl prism_rtl::Job<Parts> for FnParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let f_p1 = &self.f_p1;
        if &crate::prelude::len(&f_p1.generics_p) > &Nat::from(0u32) {
            prism_rtl::Turn::Finished({
                let mut this: Parts = generic_only_f(&Array::from(vec![fn_definition_f(cp_p0, f_p1)]));
                this.protos_p = Array::from(vec![Text::from(format!("{};", &fn_signature_f(cp_p0, f_p1)))]);
                this
            })
        } else {
            {
                let cp_p0x = cp_p0.clone();
                let f_p1x = f_p1.clone();
                crate::prelude::call_then(start_fn_signature_f(cp_p0x.clone(), f_p1x.clone()), move |fn_signature_f_7638: Text| crate::prelude::call_then(start_fn_definition_f(cp_p0x.clone(), f_p1x.clone()), move |fn_definition_f_7665: Text| prism_rtl::Turn::Finished(protos_defs_f(&Array::from(vec![Text::from(format!("{};", &fn_signature_f_7638))]), &Array::from(vec![fn_definition_f_7665])))))
            }
        }
    }
}

/// `Start FnParts, x`: what the function value is when passed to `@Run`.
pub fn start_fn_parts_f(cp_p0: crate::emit::cpp::Cp, f_p1: crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(FnParts { cp_p0, f_p1 })
}

/// ```prism
/// CppDoc: fn Text -> Text
/// ```
pub fn cpp_doc_f(text_p0: &Text) -> Text {
    if text_p0 == &Text::lit("") {
        Text::lit("")
    } else {
        crate::prelude::concat(&crate::prelude::each(&crate::prelude::split_on(text_p0, &Text::lit("\n")), &(|l_p1: &Text| if l_p1 == &Text::lit("") {
            Text::lit("///\n")
        } else {
            Text::from(format!("/// {}\n", l_p1))
        })))
    }
}

/// ```prism
/// CppSourceDoc: fn Text, Text -> Text
/// ```
pub fn cpp_source_doc_f(lead_p0: &Text, source_p1: &Text) -> Text {
    let quoted_p2 = crate::prelude::concat(&crate::prelude::each(&crate::prelude::split_on(source_p1, &Text::lit("\n")), &(|l_p3: &Text| if l_p3 == &Text::lit("") {
        Text::lit("///\n")
    } else {
        Text::from(format!("/// {}\n", l_p3))
    })));
    if source_p1 == &Text::lit("") {
        cpp_doc_f(lead_p0)
    } else {
        if lead_p0 == &Text::lit("") {
            Text::from(format!("/// ```prism\n{}/// ```\n", &quoted_p2))
        } else {
            Text::from(format!("/// {}\n///\n/// ```prism\n{}/// ```\n", lead_p0, &quoted_p2))
        }
    }
}

/// ```prism
/// TypeParts: unbounded fn Cp, TyDef -> Parts
/// ```
pub fn type_parts_f(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::TyDef) -> Parts {
    let eq_p2 = t_p1.eq_p;
    let ord_p3 = t_p1.ord_p;
    let gens_p4 = cpp_template_head_f(&t_p1.params_p);
    let head_p5 = head_of_f(&t_p1.name_p, &t_p1.params_p);
    let doc_p6 = cpp_source_doc_f(&Text::from(format!("`{}`:", &t_p1.prism_p)), &t_p1.doc_p);
    let members_p7 = members_f(&(&t_p1.show_p != &crate::lower::model::Shown::NotShown), &t_p1.pod_p, &head_p5);
    let generic_p8 = &crate::prelude::len(&t_p1.params_p) > &Nat::from(0u32);
    let fwd_p9 = Text::from(format!("{}{} {};", &gens_p4, &(if &t_p1.shape_p == &crate::lower::model::TyShape::ShapeChoice {
        Text::lit("class")
    } else {
        Text::lit("struct")
    }), &t_p1.name_p));
    let deps_pa = crate::emit::cpp::patterns::concat2_f(&crate::prelude::run_to_end(crate::prelude::each_job(t_p1.cases_p.clone(), {
        let cp_p0x = cp_p0.clone();
        Rc::new(move |p0: crate::lower::model::CaseDef| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let c_pc = p0;
                crate::prelude::call_value(crate::prelude::each_job(c_pc.fields_p.clone(), {
                    let cp_p0xyx = cp_p0xy.clone();
                    Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                        let cp_p0xyxy = cp_p0xyx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (_, ft_pd) = p0;
                            prism_rtl::Turn::More(Rc::new(ValueDeps { cp_p0: cp_p0xyxy.clone(), t_p1: ft_pd.clone() }))
                        }))
                    }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |each_9019: Array<Array<Text>>| prism_rtl::Turn::Finished(crate::emit::cpp::patterns::concat2_f(&each_9019)))
            }))
        }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    })));
    let (text_p17, cmp_defs_p18) = match &t_p1.shape_p {
        crate::lower::model::TyShape::ShapeChoice => {
            let names_pe = crate::prelude::each(&t_p1.cases_p, &(|c_pj: &crate::lower::model::CaseDef| c_pj.name_p.clone()));
            let cases_pf = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(t_p1.cases_p.clone(), {
                let cp_p0x = cp_p0.clone();
                let eq_p2x = eq_p2;
                let ord_p3x = ord_p3;
                Rc::new(move |p0: crate::lower::model::CaseDef| {
                    let cp_p0xy = cp_p0x.clone();
                    let eq_p2xy = eq_p2x;
                    let ord_p3xy = ord_p3x;
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let c_pk = p0;
                        prism_rtl::Turn::More(Rc::new(CaseStruct { cp_p0: cp_p0xy.clone(), c_p1: c_pk.clone(), eq_p2: eq_p2xy, ord_p3: ord_p3xy }))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
            })), &Text::lit("\n"));
            let cls_pg = crate::emit::cpp::templates::items::choice_class_f(&doc_p6, &gens_p4, &t_p1.name_p, &cases_pf, &crate::syntax::lexer::chars::join_f(&names_pe, &Text::lit(", ")), &members_p7);
            let cmp_ph = crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&Array::from(vec![if eq_p2 {
                Text::from(format!("{}inline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &gens_p4, &head_p5, &head_p5))
            } else {
                Text::lit("")
            }, if ord_p3 {
                Text::from(format!("{}inline std::strong_ordering operator<=>(const {}& a, const {}& b) {{ return a.cases() <=> b.cases(); }}", &gens_p4, &head_p5, &head_p5))
            } else {
                Text::lit("")
            }]), &(|s_pl: &Text| s_pl != &Text::lit(""))), &Text::lit("\n"));
            let case_defs_pi = crate::prelude::filter(&crate::prelude::run_to_end(crate::prelude::each_job(t_p1.cases_p.clone(), {
                let cp_p0x = cp_p0.clone();
                let gens_p4x = gens_p4.clone();
                let head_p5x = head_p5.clone();
                let eq_p2x = eq_p2;
                let ord_p3x = ord_p3;
                Rc::new(move |p0: crate::lower::model::CaseDef| {
                    let cp_p0xy = cp_p0x.clone();
                    let gens_p4xy = gens_p4x.clone();
                    let head_p5xy = head_p5x.clone();
                    let eq_p2xy = eq_p2x;
                    let ord_p3xy = ord_p3x;
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let c_pm = p0;
                        prism_rtl::Turn::More(Rc::new(CaseCmpDefs { cp_p0: cp_p0xy.clone(), gens_p1: gens_p4xy.clone(), head_p2: head_p5xy.clone(), c_p3: c_pm.clone(), eq_p4: eq_p2xy, ord_p5: ord_p3xy }))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
            })), &(|s_pn: &Text| s_pn != &Text::lit("")));
            (crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&Array::from(vec![cls_pg.clone(), cmp_ph.clone()]), &(|s_po: &Text| s_po != &Text::lit(""))), &Text::lit("\n")), case_defs_pi.clone())
        },
        _ => {
            let first_pp = crate::prelude::or(&crate::prelude::index(&t_p1.cases_p, &Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: Text::lit(""), prism_p: Text::lit(""), fields_p: Array::new(), labels_p: Array::new() });
            let fields_pq = match &t_p1.shape_p {
                crate::lower::model::TyShape::ShapeRecord => crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(first_pp.fields_p.clone(), {
                    let cp_p0x = cp_p0.clone();
                    Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                        let cp_p0xy = cp_p0x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (f_pu, ft_pv) = p0;
                            crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), ft_pv.clone()), move |cpp_type_f_10242: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_f_10242, &crate::emit::cpp::field_id_f(&f_pu)))))
                        }))
                    }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
                })), &Text::lit("\n")),
                crate::lower::model::TyShape::ShapeNewtype => positional_fields_f(cp_p0, &first_pp.fields_p),
                _ => Text::lit(""),
            };
            let names_pr = match &t_p1.shape_p {
                crate::lower::model::TyShape::ShapeRecord => crate::prelude::each(&first_pp.fields_p, &(|(f_p10, _): &(Text, crate::lower::model::OutTy)| crate::emit::cpp::field_id_f(f_p10))),
                crate::lower::model::TyShape::ShapeNewtype => crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&first_pp.fields_p)), &(|i_p11: &Nat| Text::from(format!("a{}", i_p11)))),
                _ => Array::new(),
            };
            let behind_ps = crate::prelude::run_to_end(crate::prelude::fold_job(first_pp.fields_p.clone(), false, {
                let cp_p0x = cp_p0.clone();
                Rc::new(move |(p0, p1): (bool, (Text, crate::lower::model::OutTy))| {
                    let cp_p0xy = cp_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_p12 = p0;
                        let (_, ft_p13) = p1;
                        prism_rtl::Turn::Finished(f_p12 || behind_f(&cp_p0xy, &ft_p13))
                    }))
                }) as Rc<dyn Fn((bool, (Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>
            }));
            let (cmps_p14, cmp_defs_p15) = comparisons_f(&gens_p4, &head_p5, &t_p1.name_p, &names_pr, &eq_p2, &ord_p3, &behind_ps);
            let decl_pt = crate::emit::cpp::templates::items::value_struct_f(&doc_p6, &gens_p4, &t_p1.name_p, &fields_pq, &crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&Array::from(vec![cmps_p14.clone(), members_p7.clone()]), &(|s_p16: &Text| s_p16 != &Text::lit(""))), &Text::lit("\n")));
            (decl_pt.clone(), if &cmp_defs_p15 == &Text::lit("") {
                Array::new()
            } else {
                Array::from(vec![cmp_defs_p15.clone()])
            })
        },
    };
    let defs_pb = crate::prelude::append(&cmp_defs_p18, &Array::from(vec![type_defs_f(cp_p0, t_p1, &head_p5)]));
    Parts { forward_p: Array::from(vec![fwd_p9.clone()]), values_p: Array::from(vec![ValueDecl { path_p: decl_path_f(cp_p0, &t_p1.name_p), deps_p: deps_pa.clone(), text_p: text_p17.clone() }]), protos_p: Array::new(), classes_p: Array::new(), outer_p: Array::new(), generic_p: if generic_p8 { defs_pb.clone() } else { Array::new() }, defs_p: if generic_p8 { Array::new() } else { defs_pb.clone() } }
}

/// The step machine of `TypeParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeParts: unbounded fn Cp, TyDef -> Parts
/// ```
pub struct TypeParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::TyDef,
}

impl prism_rtl::Job<Parts> for TypeParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        let eq_p2 = t_p1.eq_p;
        let ord_p3 = t_p1.ord_p;
        let gens_p4 = cpp_template_head_f(&t_p1.params_p);
        let head_p5 = head_of_f(&t_p1.name_p, &t_p1.params_p);
        let doc_p6 = cpp_source_doc_f(&Text::from(format!("`{}`:", &t_p1.prism_p)), &t_p1.doc_p);
        let members_p7 = members_f(&(&t_p1.show_p != &crate::lower::model::Shown::NotShown), &t_p1.pod_p, &head_p5);
        let generic_p8 = &crate::prelude::len(&t_p1.params_p) > &Nat::from(0u32);
        let fwd_p9 = Text::from(format!("{}{} {};", &gens_p4, &(if &t_p1.shape_p == &crate::lower::model::TyShape::ShapeChoice {
            Text::lit("class")
        } else {
            Text::lit("struct")
        }), &t_p1.name_p));
        let cp_p0x = cp_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(t_p1x.cases_p.clone(), {
            let cp_p0xx = cp_p0x.clone();
            Rc::new(move |p0: crate::lower::model::CaseDef| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let c_pc = p0;
                    crate::prelude::call_value(crate::prelude::each_job(c_pc.fields_p.clone(), {
                        let cp_p0xxyx = cp_p0xxy.clone();
                        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                            let cp_p0xxyxy = cp_p0xxyx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (_, ft_pd) = p0;
                                prism_rtl::Turn::More(Rc::new(ValueDeps { cp_p0: cp_p0xxyxy.clone(), t_p1: ft_pd.clone() }))
                            }))
                        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }), move |each_9019: Array<Array<Text>>| prism_rtl::Turn::Finished(crate::emit::cpp::patterns::concat2_f(&each_9019)))
                }))
            }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }), move |each_8991: Array<Array<Text>>| {
            let deps_pa = crate::emit::cpp::patterns::concat2_f(&each_8991);
            let (text_p17, cmp_defs_p18) = match &t_p1x.shape_p {
                crate::lower::model::TyShape::ShapeChoice => {
                    let names_pe = crate::prelude::each(&t_p1x.cases_p, &(|c_pj: &crate::lower::model::CaseDef| c_pj.name_p.clone()));
                    let cases_pf = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(t_p1x.cases_p.clone(), {
                        let cp_p0xx = cp_p0x.clone();
                        let eq_p2x = eq_p2;
                        let ord_p3x = ord_p3;
                        Rc::new(move |p0: crate::lower::model::CaseDef| {
                            let cp_p0xxy = cp_p0xx.clone();
                            let eq_p2xy = eq_p2x;
                            let ord_p3xy = ord_p3x;
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let c_pk = p0;
                                prism_rtl::Turn::More(Rc::new(CaseStruct { cp_p0: cp_p0xxy.clone(), c_p1: c_pk.clone(), eq_p2: eq_p2xy, ord_p3: ord_p3xy }))
                            }))
                        }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
                    })), &Text::lit("\n"));
                    let cls_pg = crate::emit::cpp::templates::items::choice_class_f(&doc_p6, &gens_p4, &t_p1x.name_p, &cases_pf, &crate::syntax::lexer::chars::join_f(&names_pe, &Text::lit(", ")), &members_p7);
                    let cmp_ph = crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&Array::from(vec![if eq_p2 {
                        Text::from(format!("{}inline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &gens_p4, &head_p5, &head_p5))
                    } else {
                        Text::lit("")
                    }, if ord_p3 {
                        Text::from(format!("{}inline std::strong_ordering operator<=>(const {}& a, const {}& b) {{ return a.cases() <=> b.cases(); }}", &gens_p4, &head_p5, &head_p5))
                    } else {
                        Text::lit("")
                    }]), &(|s_pl: &Text| s_pl != &Text::lit(""))), &Text::lit("\n"));
                    let case_defs_pi = crate::prelude::filter(&crate::prelude::run_to_end(crate::prelude::each_job(t_p1x.cases_p.clone(), {
                        let cp_p0xx = cp_p0x.clone();
                        let gens_p4x = gens_p4.clone();
                        let head_p5x = head_p5.clone();
                        let eq_p2x = eq_p2;
                        let ord_p3x = ord_p3;
                        Rc::new(move |p0: crate::lower::model::CaseDef| {
                            let cp_p0xxy = cp_p0xx.clone();
                            let gens_p4xy = gens_p4x.clone();
                            let head_p5xy = head_p5x.clone();
                            let eq_p2xy = eq_p2x;
                            let ord_p3xy = ord_p3x;
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let c_pm = p0;
                                prism_rtl::Turn::More(Rc::new(CaseCmpDefs { cp_p0: cp_p0xxy.clone(), gens_p1: gens_p4xy.clone(), head_p2: head_p5xy.clone(), c_p3: c_pm.clone(), eq_p4: eq_p2xy, ord_p5: ord_p3xy }))
                            }))
                        }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
                    })), &(|s_pn: &Text| s_pn != &Text::lit("")));
                    (crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&Array::from(vec![cls_pg.clone(), cmp_ph.clone()]), &(|s_po: &Text| s_po != &Text::lit(""))), &Text::lit("\n")), case_defs_pi.clone())
                },
                _ => {
                    let first_pp = crate::prelude::or(&crate::prelude::index(&t_p1x.cases_p, &Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: Text::lit(""), prism_p: Text::lit(""), fields_p: Array::new(), labels_p: Array::new() });
                    let fields_pq = match &t_p1x.shape_p {
                        crate::lower::model::TyShape::ShapeRecord => crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(first_pp.fields_p.clone(), {
                            let cp_p0xx = cp_p0x.clone();
                            Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                                let cp_p0xxy = cp_p0xx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let (f_pu, ft_pv) = p0;
                                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), ft_pv.clone()), move |cpp_type_f_10242: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_f_10242, &crate::emit::cpp::field_id_f(&f_pu)))))
                                }))
                            }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
                        })), &Text::lit("\n")),
                        crate::lower::model::TyShape::ShapeNewtype => positional_fields_f(&cp_p0x, &first_pp.fields_p),
                        _ => Text::lit(""),
                    };
                    let names_pr = match &t_p1x.shape_p {
                        crate::lower::model::TyShape::ShapeRecord => crate::prelude::each(&first_pp.fields_p, &(|(f_p10, _): &(Text, crate::lower::model::OutTy)| crate::emit::cpp::field_id_f(f_p10))),
                        crate::lower::model::TyShape::ShapeNewtype => crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&first_pp.fields_p)), &(|i_p11: &Nat| Text::from(format!("a{}", i_p11)))),
                        _ => Array::new(),
                    };
                    let behind_ps = crate::prelude::run_to_end(crate::prelude::fold_job(first_pp.fields_p.clone(), false, {
                        let cp_p0xx = cp_p0x.clone();
                        Rc::new(move |(p0, p1): (bool, (Text, crate::lower::model::OutTy))| {
                            let cp_p0xxy = cp_p0xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let f_p12 = p0;
                                let (_, ft_p13) = p1;
                                prism_rtl::Turn::Finished(f_p12 || behind_f(&cp_p0xxy, &ft_p13))
                            }))
                        }) as Rc<dyn Fn((bool, (Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>
                    }));
                    let (cmps_p14, cmp_defs_p15) = comparisons_f(&gens_p4, &head_p5, &t_p1x.name_p, &names_pr, &eq_p2, &ord_p3, &behind_ps);
                    let decl_pt = crate::emit::cpp::templates::items::value_struct_f(&doc_p6, &gens_p4, &t_p1x.name_p, &fields_pq, &crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&Array::from(vec![cmps_p14.clone(), members_p7.clone()]), &(|s_p16: &Text| s_p16 != &Text::lit(""))), &Text::lit("\n")));
                    (decl_pt.clone(), if &cmp_defs_p15 == &Text::lit("") {
                        Array::new()
                    } else {
                        Array::from(vec![cmp_defs_p15.clone()])
                    })
                },
            };
            crate::prelude::call_then(start_type_defs_f(cp_p0x.clone(), t_p1x.clone(), head_p5.clone()), move |type_defs_f_10992: Text| {
                let defs_pb = crate::prelude::append(&cmp_defs_p18, &Array::from(vec![type_defs_f_10992]));
                prism_rtl::Turn::Finished(Parts { forward_p: Array::from(vec![fwd_p9.clone()]), values_p: Array::from(vec![ValueDecl { path_p: decl_path_f(&cp_p0x, &t_p1x.name_p), deps_p: deps_pa.clone(), text_p: text_p17.clone() }]), protos_p: Array::new(), classes_p: Array::new(), outer_p: Array::new(), generic_p: if generic_p8 { defs_pb.clone() } else { Array::new() }, defs_p: if generic_p8 { Array::new() } else { defs_pb.clone() } })
            })
        })
    }
}

/// `Start TypeParts, x`: what the function value is when passed to `@Run`.
pub fn start_type_parts_f(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::TyDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(TypeParts { cp_p0, t_p1 })
}

/// ```prism
/// DeclPath: fn Cp, Text -> Text
/// ```
pub fn decl_path_f(cp_p0: &crate::emit::cpp::Cp, name_p1: &Text) -> Text {
    if &cp_p0.home_p == &Text::lit("") {
        name_p1.clone()
    } else {
        Text::from(format!("{}::{}", &cp_p0.home_p, name_p1))
    }
}

/// ```prism
/// Comparisons: fn Text, Text, Text, [Text], Bool, Bool, Bool -> ((Text, Text))
/// ```
pub fn comparisons_f(gens_p0: &Text, owner_p1: &Text, self_p2: &Text, names_p3: &Array<Text>, eq_p4: &bool, ord_p5: &bool, behind_p6: &bool) -> (Text, Text) {
    if !*behind_p6 {
        (crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&Array::from(vec![if *eq_p4 {
            Text::from(format!("bool operator==(const {}&) const = default;", self_p2))
        } else {
            Text::lit("")
        }, if *ord_p5 {
            Text::from(format!("auto operator<=>(const {}&) const = default;", self_p2))
        } else {
            Text::lit("")
        }]), &(|s_p7: &Text| s_p7 != &Text::lit(""))), &Text::lit("\n")), Text::lit(""))
    } else {
        {
            let decls_p8 = crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&Array::from(vec![if *eq_p4 {
                Text::from(format!("bool operator==(const {}&) const;", self_p2))
            } else {
                Text::lit("")
            }, if *ord_p5 {
                Text::from(format!("std::strong_ordering operator<=>(const {}&) const;", self_p2))
            } else {
                Text::lit("")
            }]), &(|s_pc: &Text| s_pc != &Text::lit(""))), &Text::lit("\n"));
            let eq_body_p9 = if &crate::prelude::len(names_p3) == &Nat::from(0u32) {
                Text::lit("true")
            } else {
                crate::syntax::lexer::chars::join_f(&crate::prelude::each(names_p3, &(|n_pd: &Text| Text::from(format!("{} == o.{}", n_pd, n_pd)))), &Text::lit(" && "))
            };
            let ord_body_pa = if &crate::prelude::len(names_p3) == &Nat::from(0u32) {
                Text::lit("std::strong_ordering::equal")
            } else {
                Text::from(format!("std::tie({}) <=> std::tie({})", &crate::syntax::lexer::chars::join_f(names_p3, &Text::lit(", ")), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(names_p3, &(|n_pe: &Text| Text::from(format!("o.{}", n_pe)))), &Text::lit(", "))))
            };
            let defs_pb = crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&Array::from(vec![if *eq_p4 {
                Text::from(format!("{}bool {}::operator==(const {}& o) const {{ return {}; }}", gens_p0, owner_p1, self_p2, &eq_body_p9))
            } else {
                Text::lit("")
            }, if *ord_p5 {
                Text::from(format!("{}std::strong_ordering {}::operator<=>(const {}& o) const {{ return {}; }}", gens_p0, owner_p1, self_p2, &ord_body_pa))
            } else {
                Text::lit("")
            }]), &(|s_pf: &Text| s_pf != &Text::lit(""))), &Text::lit("\n"));
            (decls_p8.clone(), defs_pb.clone())
        }
    }
}

/// ```prism
/// Members: fn Bool, Bool, Text -> Text
/// ```
pub fn members_f(shown_p0: &bool, pod_p1: &bool, head_p2: &Text) -> Text {
    let s_p3 = if *shown_p0 {
        Array::from(vec![Text::lit("void show(Printer& p) const;")])
    } else {
        Array::new()
    };
    let d_p4 = if *pod_p1 {
        Array::from(vec![Text::lit("Pod to_pod() const;"), Text::from(format!("static Result<{}> from_pod(const Pod& whole);", head_p2))])
    } else {
        Array::new()
    };
    crate::syntax::lexer::chars::join_f(&crate::prelude::append(&s_p3, &d_p4), &Text::lit("\n"))
}

/// ```prism
/// CaseStruct: unbounded fn Cp, CaseDef, Bool, Bool -> Text
/// ```
pub fn case_struct_f(cp_p0: &crate::emit::cpp::Cp, c_p1: &crate::lower::model::CaseDef, eq_p2: &bool, ord_p3: &bool) -> Text {
    let fields_p4 = positional_fields_f(cp_p0, &c_p1.fields_p);
    let (cmps_p5, _) = comparisons_f(&Text::lit(""), &Text::lit(""), &c_p1.name_p, &case_names_f(c_p1), eq_p2, ord_p3, &case_behind_f(cp_p0, c_p1));
    crate::emit::cpp::templates::items::case_decl_f(&c_p1.name_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&Array::from(vec![fields_p4.clone(), cmps_p5.clone()]), &(|s_p6: &Text| s_p6 != &Text::lit(""))), &Text::lit("\n")))
}

/// The step machine of `CaseStruct`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CaseStruct: unbounded fn Cp, CaseDef, Bool, Bool -> Text
/// ```
pub struct CaseStruct {
    pub cp_p0: crate::emit::cpp::Cp,
    pub c_p1: crate::lower::model::CaseDef,
    pub eq_p2: bool,
    pub ord_p3: bool,
}

impl prism_rtl::Job<Text> for CaseStruct {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let c_p1 = &self.c_p1;
        let eq_p2 = &self.eq_p2;
        let ord_p3 = &self.ord_p3;
        let c_p1x = c_p1.clone();
        let cp_p0x = cp_p0.clone();
        let eq_p2x = *eq_p2;
        let ord_p3x = *ord_p3;
        crate::prelude::call_then(start_positional_fields_f(cp_p0x.clone(), c_p1x.fields_p.clone()), move |positional_fields_f_13273: Text| {
            let fields_p4 = positional_fields_f_13273;
            crate::prelude::call_then(start_case_behind_f(cp_p0x.clone(), c_p1x.clone()), move |case_behind_f_13383: bool| {
                let (cmps_p5, _) = comparisons_f(&Text::lit(""), &Text::lit(""), &c_p1x.name_p, &case_names_f(&c_p1x), &eq_p2x, &ord_p3x, &case_behind_f_13383);
                prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::case_decl_f(&c_p1x.name_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&Array::from(vec![fields_p4.clone(), cmps_p5.clone()]), &(|s_p6: &Text| s_p6 != &Text::lit(""))), &Text::lit("\n"))))
            })
        })
    }
}

/// `Start CaseStruct, x`: what the function value is when passed to `@Run`.
pub fn start_case_struct_f(cp_p0: crate::emit::cpp::Cp, c_p1: crate::lower::model::CaseDef, eq_p2: bool, ord_p3: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CaseStruct { cp_p0, c_p1, eq_p2, ord_p3 })
}

/// ```prism
/// CaseCmpDefs: unbounded fn Cp, Text, Text, CaseDef, Bool, Bool -> Text
/// ```
pub fn case_cmp_defs_f(cp_p0: &crate::emit::cpp::Cp, gens_p1: &Text, head_p2: &Text, c_p3: &crate::lower::model::CaseDef, eq_p4: &bool, ord_p5: &bool) -> Text {
    let (_, defs_p6) = comparisons_f(gens_p1, &Text::from(format!("{}::{}", head_p2, &c_p3.name_p)), &c_p3.name_p, &case_names_f(c_p3), eq_p4, ord_p5, &case_behind_f(cp_p0, c_p3));
    defs_p6.clone()
}

/// The step machine of `CaseCmpDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CaseCmpDefs: unbounded fn Cp, Text, Text, CaseDef, Bool, Bool -> Text
/// ```
pub struct CaseCmpDefs {
    pub cp_p0: crate::emit::cpp::Cp,
    pub gens_p1: Text,
    pub head_p2: Text,
    pub c_p3: crate::lower::model::CaseDef,
    pub eq_p4: bool,
    pub ord_p5: bool,
}

impl prism_rtl::Job<Text> for CaseCmpDefs {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let gens_p1 = &self.gens_p1;
        let head_p2 = &self.head_p2;
        let c_p3 = &self.c_p3;
        let eq_p4 = &self.eq_p4;
        let ord_p5 = &self.ord_p5;
        let c_p3x = c_p3.clone();
        let cp_p0x = cp_p0.clone();
        let eq_p4x = *eq_p4;
        let gens_p1x = gens_p1.clone();
        let head_p2x = head_p2.clone();
        let ord_p5x = *ord_p5;
        crate::prelude::call_then(start_case_behind_f(cp_p0x.clone(), c_p3x.clone()), move |case_behind_f_13776: bool| {
            let (_, defs_p6) = comparisons_f(&gens_p1x, &Text::from(format!("{}::{}", &head_p2x, &c_p3x.name_p)), &c_p3x.name_p, &case_names_f(&c_p3x), &eq_p4x, &ord_p5x, &case_behind_f_13776);
            prism_rtl::Turn::Finished(defs_p6.clone())
        })
    }
}

/// `Start CaseCmpDefs, x`: what the function value is when passed to `@Run`.
pub fn start_case_cmp_defs_f(cp_p0: crate::emit::cpp::Cp, gens_p1: Text, head_p2: Text, c_p3: crate::lower::model::CaseDef, eq_p4: bool, ord_p5: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CaseCmpDefs { cp_p0, gens_p1, head_p2, c_p3, eq_p4, ord_p5 })
}

/// ```prism
/// CaseNames: fn CaseDef -> [Text]
/// ```
pub fn case_names_f(c_p0: &crate::lower::model::CaseDef) -> Array<Text> {
    crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&c_p0.fields_p)), &(|i_p1: &Nat| Text::from(format!("a{}", i_p1))))
}

/// ```prism
/// CaseBehind: unbounded fn Cp, CaseDef -> Bool
/// ```
pub fn case_behind_f(cp_p0: &crate::emit::cpp::Cp, c_p1: &crate::lower::model::CaseDef) -> bool {
    crate::prelude::run_to_end(crate::prelude::fold_job(c_p1.fields_p.clone(), false, {
        let cp_p0x = cp_p0.clone();
        Rc::new(move |(p0, p1): (bool, (Text, crate::lower::model::OutTy))| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let f_p2 = p0;
                let (_, ft_p3) = p1;
                prism_rtl::Turn::Finished(f_p2 || behind_f(&cp_p0xy, &ft_p3))
            }))
        }) as Rc<dyn Fn((bool, (Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `CaseBehind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CaseBehind: unbounded fn Cp, CaseDef -> Bool
/// ```
pub struct CaseBehind {
    pub cp_p0: crate::emit::cpp::Cp,
    pub c_p1: crate::lower::model::CaseDef,
}

impl prism_rtl::Job<bool> for CaseBehind {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let cp_p0 = &self.cp_p0;
        let c_p1 = &self.c_p1;
        crate::prelude::fold_job(c_p1.fields_p.clone(), false, {
            let cp_p0x = cp_p0.clone();
            Rc::new(move |(p0, p1): (bool, (Text, crate::lower::model::OutTy))| {
                let cp_p0xy = cp_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let f_p2 = p0;
                    let (_, ft_p3) = p1;
                    prism_rtl::Turn::Finished(f_p2 || behind_f(&cp_p0xy, &ft_p3))
                }))
            }) as Rc<dyn Fn((bool, (Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>
        }).cycle()
    }
}

/// `Start CaseBehind, x`: what the function value is when passed to `@Run`.
pub fn start_case_behind_f(cp_p0: crate::emit::cpp::Cp, c_p1: crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(CaseBehind { cp_p0, c_p1 })
}

/// ```prism
/// TypeDefs: unbounded fn Cp, TyDef, Text -> Text
/// ```
pub fn type_defs_f(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::TyDef, head_p2: &Text) -> Text {
    let gens_p3 = cpp_template_head_f(&t_p1.params_p);
    let show_p4 = if &t_p1.show_p == &crate::lower::model::Shown::ShownDerived {
        Array::from(vec![show_def_f(cp_p0, t_p1, head_p2, &gens_p3)])
    } else {
        Array::new()
    };
    let pod_p5 = if t_p1.pod_p {
        Array::from(vec![to_pod_def_f(cp_p0, t_p1, head_p2, &gens_p3), from_pod_def_f(cp_p0, t_p1, head_p2, &gens_p3)])
    } else {
        Array::new()
    };
    crate::syntax::lexer::chars::join_f(&crate::prelude::append(&show_p4, &pod_p5), &Text::lit("\n"))
}

/// The step machine of `TypeDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeDefs: unbounded fn Cp, TyDef, Text -> Text
/// ```
pub struct TypeDefs {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::TyDef,
    pub head_p2: Text,
}

impl prism_rtl::Job<Text> for TypeDefs {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        let head_p2 = &self.head_p2;
        let gens_p3 = cpp_template_head_f(&t_p1.params_p);
        let show_p4 = if &t_p1.show_p == &crate::lower::model::Shown::ShownDerived {
            Array::from(vec![show_def_f(cp_p0, t_p1, head_p2, &gens_p3)])
        } else {
            Array::new()
        };
        let pod_p5 = if t_p1.pod_p {
            Array::from(vec![to_pod_def_f(cp_p0, t_p1, head_p2, &gens_p3), from_pod_def_f(cp_p0, t_p1, head_p2, &gens_p3)])
        } else {
            Array::new()
        };
        prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join_f(&crate::prelude::append(&show_p4, &pod_p5), &Text::lit("\n")))
    }
}

/// `Start TypeDefs, x`: what the function value is when passed to `@Run`.
pub fn start_type_defs_f(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::TyDef, head_p2: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TypeDefs { cp_p0, t_p1, head_p2 })
}

/// ```prism
/// ShowDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub fn show_def_f(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::TyDef, head_p2: &Text, gens_p3: &Text) -> Text {
    let body_p4 = match &t_p1.shape_p {
        crate::lower::model::TyShape::ShapeRecord => {
            let c_p5 = crate::prelude::or(&crate::prelude::index(&t_p1.cases_p, &Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: Text::lit(""), prism_p: Text::lit(""), fields_p: Array::new(), labels_p: Array::new() });
            Text::from(format!("p.record(\"{}\", {{{}}});", &t_p1.prism_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&c_p5.fields_p, &(|(f_p6, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", {}}}", &prism_field_of_f(&c_p5, f_p6), &crate::emit::cpp::field_id_f(f_p6))))), &Text::lit(", "))))
        },
        crate::lower::model::TyShape::ShapeChoice => crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&t_p1.cases_p)), &(|i_p7: &Nat| show_case_f(t_p1, i_p7))), &Text::lit("\n")),
        crate::lower::model::TyShape::ShapeNewtype => Text::from(format!("p.choice(\"{}\", {{{}}});", &first_case_f(t_p1), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::check::errors::range0_f(&first_arity_f(t_p1)), &(|k_p8: &Nat| Text::from(format!("a{}", k_p8)))), &Text::lit(", ")))),
        crate::lower::model::TyShape::ShapeUnit => Text::from(format!("p.choice(\"{}\", {{}});", &first_case_f(t_p1))),
    };
    crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("{}void {}::show(Printer& p) const", gens_p3, head_p2)), &body_p4)
}

/// The step machine of `ShowDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub struct ShowDef {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::TyDef,
    pub head_p2: Text,
    pub gens_p3: Text,
}

impl prism_rtl::Job<Text> for ShowDef {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        let head_p2 = &self.head_p2;
        let gens_p3 = &self.gens_p3;
        let body_p4 = match &t_p1.shape_p {
            crate::lower::model::TyShape::ShapeRecord => {
                let c_p5 = crate::prelude::or(&crate::prelude::index(&t_p1.cases_p, &Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: Text::lit(""), prism_p: Text::lit(""), fields_p: Array::new(), labels_p: Array::new() });
                Text::from(format!("p.record(\"{}\", {{{}}});", &t_p1.prism_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&c_p5.fields_p, &(|(f_p6, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", {}}}", &prism_field_of_f(&c_p5, f_p6), &crate::emit::cpp::field_id_f(f_p6))))), &Text::lit(", "))))
            },
            crate::lower::model::TyShape::ShapeChoice => crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&t_p1.cases_p)), &(|i_p7: &Nat| show_case_f(t_p1, i_p7))), &Text::lit("\n")),
            crate::lower::model::TyShape::ShapeNewtype => Text::from(format!("p.choice(\"{}\", {{{}}});", &first_case_f(t_p1), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::check::errors::range0_f(&first_arity_f(t_p1)), &(|k_p8: &Nat| Text::from(format!("a{}", k_p8)))), &Text::lit(", ")))),
            crate::lower::model::TyShape::ShapeUnit => Text::from(format!("p.choice(\"{}\", {{}});", &first_case_f(t_p1))),
        };
        prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("{}void {}::show(Printer& p) const", gens_p3, head_p2)), &body_p4))
    }
}

/// `Start ShowDef, x`: what the function value is when passed to `@Run`.
pub fn start_show_def_f(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::TyDef, head_p2: Text, gens_p3: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ShowDef { cp_p0, t_p1, head_p2, gens_p3 })
}

/// ```prism
/// ShowCase: fn TyDef, Nat -> Text
/// ```
pub fn show_case_f(t_p0: &crate::lower::model::TyDef, i_p1: &Nat) -> Text {
    let c_p2 = crate::prelude::or(&crate::prelude::index(&t_p0.cases_p, i_p1), &crate::lower::model::CaseDef { name_p: Text::lit(""), prism_p: Text::lit(""), fields_p: Array::new(), labels_p: Array::new() });
    let head_p3 = Text::from(format!("{} (auto c = std::get_if<{}>(&cases()))", &(if i_p1 == &Nat::from(0u32) { Text::lit("if") } else { Text::lit("else if") }), &c_p2.name_p));
    Text::from(format!("{} p.choice(\"{}\", {{{}}});", &head_p3, &c_p2.prism_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&c_p2.fields_p)), &(|k_p4: &Nat| Text::from(format!("c->a{}", k_p4)))), &Text::lit(", "))))
}

/// ```prism
/// FirstCase: fn TyDef -> Text
/// ```
pub fn first_case_f(t_p0: &crate::lower::model::TyDef) -> Text {
    crate::prelude::or(&crate::prelude::index(&t_p0.cases_p, &Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: Text::lit(""), prism_p: t_p0.prism_p.clone(), fields_p: Array::new(), labels_p: Array::new() }).prism_p.clone()
}

/// ```prism
/// FirstArity: fn TyDef -> Nat
/// ```
pub fn first_arity_f(t_p0: &crate::lower::model::TyDef) -> Nat {
    crate::prelude::len(&crate::prelude::or(&crate::prelude::index(&t_p0.cases_p, &Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: Text::lit(""), prism_p: Text::lit(""), fields_p: Array::new(), labels_p: Array::new() }).fields_p)
}

/// ```prism
/// FieldTypes: fn [((Text, OutTy))] -> [OutTy]
/// ```
pub fn field_types_f(fs_p0: &Array<(Text, crate::lower::model::OutTy)>) -> Array<crate::lower::model::OutTy> {
    crate::prelude::each(fs_p0, &(|(_, t_p1): &(Text, crate::lower::model::OutTy)| t_p1.clone()))
}

/// ```prism
/// PositionalFields: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub fn positional_fields_f(cp_p0: &crate::emit::cpp::Cp, fs_p1: &Array<(Text, crate::lower::model::OutTy)>) -> Text {
    let tys_p2 = field_types_f(fs_p1);
    crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&tys_p2)), {
        let cp_p0x = cp_p0.clone();
        let tys_p2x = tys_p2.clone();
        Rc::new(move |p0: Nat| {
            let cp_p0xy = cp_p0x.clone();
            let tys_p2xy = tys_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_p3 = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), crate::prelude::or(&crate::prelude::index(&tys_p2xy, &i_p3), &crate::lower::model::OutTy::OutUnit)), move |cpp_type_f_16024: Text| prism_rtl::Turn::Finished(Text::from(format!("{} a{};", &cpp_type_f_16024, &i_p3))))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"))
}

/// The step machine of `PositionalFields`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PositionalFields: unbounded fn Cp, [((Text, OutTy))] -> Text
/// ```
pub struct PositionalFields {
    pub cp_p0: crate::emit::cpp::Cp,
    pub fs_p1: Array<(Text, crate::lower::model::OutTy)>,
}

impl prism_rtl::Job<Text> for PositionalFields {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let fs_p1 = &self.fs_p1;
        let tys_p2 = field_types_f(fs_p1);
        let cp_p0x = cp_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&tys_p2)), {
            let cp_p0xx = cp_p0x.clone();
            let tys_p2x = tys_p2.clone();
            Rc::new(move |p0: Nat| {
                let cp_p0xxy = cp_p0xx.clone();
                let tys_p2xy = tys_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let i_p3 = p0;
                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), crate::prelude::or(&crate::prelude::index(&tys_p2xy, &i_p3), &crate::lower::model::OutTy::OutUnit)), move |cpp_type_f_16024: Text| prism_rtl::Turn::Finished(Text::from(format!("{} a{};", &cpp_type_f_16024, &i_p3))))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_15992: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join_f(&each_15992, &Text::lit("\n"))))
    }
}

/// `Start PositionalFields, x`: what the function value is when passed to `@Run`.
pub fn start_positional_fields_f(cp_p0: crate::emit::cpp::Cp, fs_p1: Array<(Text, crate::lower::model::OutTy)>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(PositionalFields { cp_p0, fs_p1 })
}

/// ```prism
/// ToPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub fn to_pod_def_f(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::TyDef, head_p2: &Text, gens_p3: &Text) -> Text {
    let structure_p4 = match &t_p1.shape_p {
        crate::lower::model::TyShape::ShapeRecord => {
            let c_p6 = crate::prelude::or(&crate::prelude::index(&t_p1.cases_p, &Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: Text::lit(""), prism_p: Text::lit(""), fields_p: Array::new(), labels_p: Array::new() });
            Text::from(format!("Pod::record(\"{}\", {{{}}})", &t_p1.prism_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&c_p6.fields_p, &(|(f_p7, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", prism_rtl::to_pod({})}}", &prism_field_of_f(&c_p6, f_p7), &crate::emit::cpp::field_id_f(f_p7))))), &Text::lit(", "))))
        },
        crate::lower::model::TyShape::ShapeChoice => choice_pod_f(t_p1),
        crate::lower::model::TyShape::ShapeNewtype => Text::from(format!("Pod::choice(\"{}\", {{{}}})", &first_case_f(t_p1), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::check::errors::range0_f(&first_arity_f(t_p1)), &(|k_p8: &Nat| Text::from(format!("prism_rtl::to_pod(a{})", k_p8)))), &Text::lit(", ")))),
        crate::lower::model::TyShape::ShapeUnit => Text::from(format!("Pod::choice(\"{}\", {{}})", &first_case_f(t_p1))),
    };
    let body_p5 = if &t_p1.show_p == &crate::lower::model::Shown::ShownOwn {
        Text::from(format!("Pod structure = {};\nreturn Pod::shown(prism_rtl::show(*this), structure);", &structure_p4))
    } else {
        Text::from(format!("return {};", &structure_p4))
    };
    crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("{}Pod {}::to_pod() const", gens_p3, head_p2)), &body_p5)
}

/// The step machine of `ToPodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ToPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub struct ToPodDef {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::TyDef,
    pub head_p2: Text,
    pub gens_p3: Text,
}

impl prism_rtl::Job<Text> for ToPodDef {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        let head_p2 = &self.head_p2;
        let gens_p3 = &self.gens_p3;
        let structure_p4 = match &t_p1.shape_p {
            crate::lower::model::TyShape::ShapeRecord => {
                let c_p6 = crate::prelude::or(&crate::prelude::index(&t_p1.cases_p, &Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: Text::lit(""), prism_p: Text::lit(""), fields_p: Array::new(), labels_p: Array::new() });
                Text::from(format!("Pod::record(\"{}\", {{{}}})", &t_p1.prism_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&c_p6.fields_p, &(|(f_p7, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", prism_rtl::to_pod({})}}", &prism_field_of_f(&c_p6, f_p7), &crate::emit::cpp::field_id_f(f_p7))))), &Text::lit(", "))))
            },
            crate::lower::model::TyShape::ShapeChoice => choice_pod_f(t_p1),
            crate::lower::model::TyShape::ShapeNewtype => Text::from(format!("Pod::choice(\"{}\", {{{}}})", &first_case_f(t_p1), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::check::errors::range0_f(&first_arity_f(t_p1)), &(|k_p8: &Nat| Text::from(format!("prism_rtl::to_pod(a{})", k_p8)))), &Text::lit(", ")))),
            crate::lower::model::TyShape::ShapeUnit => Text::from(format!("Pod::choice(\"{}\", {{}})", &first_case_f(t_p1))),
        };
        let body_p5 = if &t_p1.show_p == &crate::lower::model::Shown::ShownOwn {
            Text::from(format!("Pod structure = {};\nreturn Pod::shown(prism_rtl::show(*this), structure);", &structure_p4))
        } else {
            Text::from(format!("return {};", &structure_p4))
        };
        prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("{}Pod {}::to_pod() const", gens_p3, head_p2)), &body_p5))
    }
}

/// `Start ToPodDef, x`: what the function value is when passed to `@Run`.
pub fn start_to_pod_def_f(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::TyDef, head_p2: Text, gens_p3: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ToPodDef { cp_p0, t_p1, head_p2, gens_p3 })
}

/// ```prism
/// ChoicePod: fn TyDef -> Text
/// ```
pub fn choice_pod_f(t_p0: &crate::lower::model::TyDef) -> Text {
    let arms_p1 = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&t_p0.cases_p)), &(|i_p2: &Nat| {
        let c_p3 = crate::prelude::or(&crate::prelude::index(&t_p0.cases_p, i_p2), &crate::lower::model::CaseDef { name_p: Text::lit(""), prism_p: Text::lit(""), fields_p: Array::new(), labels_p: Array::new() });
        Text::from(format!("std::holds_alternative<{}>(cases()) ? Pod::choice(\"{}\", {{{}}})", &c_p3.name_p, &c_p3.prism_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&c_p3.fields_p)), &(|k_p4: &Nat| Text::from(format!("prism_rtl::to_pod(std::get<{}>(cases()).a{})", &c_p3.name_p, k_p4)))), &Text::lit(", "))))
    }));
    Text::from(format!("{}\n    : Pod()", &crate::syntax::lexer::chars::join_f(&arms_p1, &Text::lit("\n    : "))))
}

/// ```prism
/// FromPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub fn from_pod_def_f(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::TyDef, head_p2: &Text, gens_p3: &Text) -> Text {
    let body_p4 = match &t_p1.shape_p {
        crate::lower::model::TyShape::ShapeRecord => {
            let c_p5 = crate::prelude::or(&crate::prelude::index(&t_p1.cases_p, &Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: Text::lit(""), prism_p: Text::lit(""), fields_p: Array::new(), labels_p: Array::new() });
            let reads_p6 = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(c_p5.fields_p.clone(), {
                let cp_p0x = cp_p0.clone();
                let c_p5x = c_p5.clone();
                Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                    let cp_p0xy = cp_p0x.clone();
                    let c_p5xy = c_p5x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (f_p7, ft_p8) = p0;
                        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), ft_p8.clone()), move |cpp_type_f_17640: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = TRY(prism_rtl::from_pod<{}>(TRY(crate::prelude::field(whole, \"{}\"))))", &crate::emit::cpp::field_id_f(&f_p7), &cpp_type_f_17640, &prism_field_of_f(&c_p5xy, &f_p7)))))
                    }))
                }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
            })), &Text::lit(", "));
            Text::from(format!("return {}{{{}}};", head_p2, &reads_p6))
        },
        _ => {
            let arms_p9 = crate::prelude::run_to_end(crate::prelude::each_job(t_p1.cases_p.clone(), {
                let cp_p0x = cp_p0.clone();
                let t_p1x = t_p1.clone();
                let head_p2x = head_p2.clone();
                Rc::new(move |p0: crate::lower::model::CaseDef| {
                    let cp_p0xy = cp_p0x.clone();
                    let t_p1xy = t_p1x.clone();
                    let head_p2xy = head_p2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let c_pa = p0;
                        {
                            let n_pb = crate::prelude::len(&c_pa.fields_p);
                            let tys_pc = field_types_f(&c_pa.fields_p);
                            crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&n_pb), {
                                let cp_p0xyx = cp_p0xy.clone();
                                let tys_pcx = tys_pc.clone();
                                Rc::new(move |p0: Nat| {
                                    let cp_p0xyxy = cp_p0xyx.clone();
                                    let tys_pcxy = tys_pcx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let i_pf = p0;
                                        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xyxy.clone(), crate::prelude::or(&crate::prelude::index(&tys_pcxy, &i_pf), &crate::lower::model::OutTy::OutUnit)), move |cpp_type_f_17991: Text| prism_rtl::Turn::Finished(Text::from(format!("TRY(prism_rtl::from_pod<{}>(c->args[{}]))", &cpp_type_f_17991, &i_pf))))
                                    }))
                                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
                            }), move |each_17943: Array<Text>| {
                                let args_pd = crate::syntax::lexer::chars::join_f(&each_17943, &Text::lit(", "));
                                let made_pe = match &t_p1xy.shape_p {
                                    crate::lower::model::TyShape::ShapeChoice => Text::from(format!("{}({}{{{}}})", &head_p2xy, &c_pa.name_p, &args_pd)),
                                    _ => Text::from(format!("{}{{{}}}", &head_p2xy, &args_pd)),
                                };
                                prism_rtl::Turn::Finished(Text::from(format!("if (c->ctor == \"{}\" && c->args.size() == {}) return {};", &c_pa.prism_p, &n_pb, &made_pe)))
                            })
                        }
                    }))
                }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            Text::from(format!("const Pod& p = whole.structure();\nif (auto c = p.if_choice()) {{\n{}\n}}\nreturn mismatch<{}>(\"a {}\", p);", &indent_cpp_f(&crate::syntax::lexer::chars::join_f(&arms_p9, &Text::lit("\n"))), head_p2, &t_p1.prism_p))
        },
    };
    crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("{}Result<{}> {}::from_pod(const Pod& whole)", gens_p3, head_p2, head_p2)), &body_p4)
}

/// The step machine of `FromPodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FromPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
/// ```
pub struct FromPodDef {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::TyDef,
    pub head_p2: Text,
    pub gens_p3: Text,
}

impl prism_rtl::Job<Text> for FromPodDef {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        let head_p2 = &self.head_p2;
        let gens_p3 = &self.gens_p3;
        let body_p4 = match &t_p1.shape_p {
            crate::lower::model::TyShape::ShapeRecord => {
                let c_p5 = crate::prelude::or(&crate::prelude::index(&t_p1.cases_p, &Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: Text::lit(""), prism_p: Text::lit(""), fields_p: Array::new(), labels_p: Array::new() });
                let reads_p6 = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(c_p5.fields_p.clone(), {
                    let cp_p0x = cp_p0.clone();
                    let c_p5x = c_p5.clone();
                    Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                        let cp_p0xy = cp_p0x.clone();
                        let c_p5xy = c_p5x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (f_p7, ft_p8) = p0;
                            crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), ft_p8.clone()), move |cpp_type_f_17640: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = TRY(prism_rtl::from_pod<{}>(TRY(crate::prelude::field(whole, \"{}\"))))", &crate::emit::cpp::field_id_f(&f_p7), &cpp_type_f_17640, &prism_field_of_f(&c_p5xy, &f_p7)))))
                        }))
                    }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
                })), &Text::lit(", "));
                Text::from(format!("return {}{{{}}};", head_p2, &reads_p6))
            },
            _ => {
                let arms_p9 = crate::prelude::run_to_end(crate::prelude::each_job(t_p1.cases_p.clone(), {
                    let cp_p0x = cp_p0.clone();
                    let t_p1x = t_p1.clone();
                    let head_p2x = head_p2.clone();
                    Rc::new(move |p0: crate::lower::model::CaseDef| {
                        let cp_p0xy = cp_p0x.clone();
                        let t_p1xy = t_p1x.clone();
                        let head_p2xy = head_p2x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let c_pa = p0;
                            {
                                let n_pb = crate::prelude::len(&c_pa.fields_p);
                                let tys_pc = field_types_f(&c_pa.fields_p);
                                crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&n_pb), {
                                    let cp_p0xyx = cp_p0xy.clone();
                                    let tys_pcx = tys_pc.clone();
                                    Rc::new(move |p0: Nat| {
                                        let cp_p0xyxy = cp_p0xyx.clone();
                                        let tys_pcxy = tys_pcx.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let i_pf = p0;
                                            crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xyxy.clone(), crate::prelude::or(&crate::prelude::index(&tys_pcxy, &i_pf), &crate::lower::model::OutTy::OutUnit)), move |cpp_type_f_17991: Text| prism_rtl::Turn::Finished(Text::from(format!("TRY(prism_rtl::from_pod<{}>(c->args[{}]))", &cpp_type_f_17991, &i_pf))))
                                        }))
                                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
                                }), move |each_17943: Array<Text>| {
                                    let args_pd = crate::syntax::lexer::chars::join_f(&each_17943, &Text::lit(", "));
                                    let made_pe = match &t_p1xy.shape_p {
                                        crate::lower::model::TyShape::ShapeChoice => Text::from(format!("{}({}{{{}}})", &head_p2xy, &c_pa.name_p, &args_pd)),
                                        _ => Text::from(format!("{}{{{}}}", &head_p2xy, &args_pd)),
                                    };
                                    prism_rtl::Turn::Finished(Text::from(format!("if (c->ctor == \"{}\" && c->args.size() == {}) return {};", &c_pa.prism_p, &n_pb, &made_pe)))
                                })
                            }
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>
                }));
                Text::from(format!("const Pod& p = whole.structure();\nif (auto c = p.if_choice()) {{\n{}\n}}\nreturn mismatch<{}>(\"a {}\", p);", &indent_cpp_f(&crate::syntax::lexer::chars::join_f(&arms_p9, &Text::lit("\n"))), head_p2, &t_p1.prism_p))
            },
        };
        prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("{}Result<{}> {}::from_pod(const Pod& whole)", gens_p3, head_p2, head_p2)), &body_p4))
    }
}

/// `Start FromPodDef, x`: what the function value is when passed to `@Run`.
pub fn start_from_pod_def_f(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::TyDef, head_p2: Text, gens_p3: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FromPodDef { cp_p0, t_p1, head_p2, gens_p3 })
}

/// ```prism
/// PrismField: fn Text -> Text
/// ```
pub fn prism_field_f(f_p0: &Text) -> Text {
    if &crate::syntax::lexer::chars::last_char_f(f_p0) == &Text::lit("_") {
        crate::syntax::lexer::chars::before_last_f(f_p0)
    } else {
        f_p0.clone()
    }
}

/// ```prism
/// PrismFieldOf: fn CaseDef, Text -> Text
/// ```
pub fn prism_field_of_f(c_p0: &crate::lower::model::CaseDef, f_p1: &Text) -> Text {
    crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&c_p0.fields_p)), &prism_field_f(f_p1), &(|found_p2: &Text, i_p3: &Nat| match (crate::prelude::index(&c_p0.fields_p, i_p3), crate::prelude::index(&c_p0.labels_p, i_p3)) {
        (Some((g_p4, _)), Some(label_p5)) => if &g_p4 == f_p1 { label_p5 } else { found_p2.clone() },
        _ => found_p2.clone(),
    }))
}

/// ```prism
/// IndentCpp: fn Text -> Text
/// ```
pub fn indent_cpp_f(t_p0: &Text) -> Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::prelude::split_on(t_p0, &Text::lit("\n")), &(|l_p1: &Text| if l_p1 == &Text::lit("") {
        Text::lit("")
    } else {
        Text::from(format!("    {}", l_p1))
    })), &Text::lit("\n"))
}

/// ```prism
/// TagParts: unbounded fn Cp, TagDef -> Parts
/// ```
pub fn tag_parts_f(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::TagDef) -> Parts {
    let fields_p2 = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(t_p1.fields_p.clone(), {
        let cp_p0x = cp_p0.clone();
        Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (_, f_ph, ft_pi) = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), ft_pi.clone()), move |cpp_type_f_19342: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_f_19342, &crate::emit::cpp::field_id_f(&f_ph)))))
            }))
        }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let pods_p3 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&t_p1.fields_p, &(|(p_pj, f_pk, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", prism_rtl::to_pod({})}}", p_pj, &crate::emit::cpp::field_id_f(f_pk))))), &Text::lit(", "));
    let reads_p4 = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(t_p1.fields_p.clone(), {
        let cp_p0x = cp_p0.clone();
        Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (p_pl, f_pm, ft_pn) = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), ft_pn.clone()), move |cpp_type_f_19582: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = TRY(prism_rtl::from_pod<{}>(TRY(crate::prelude::field(p, \"{}\"))))", &crate::emit::cpp::field_id_f(&f_pm), &cpp_type_f_19582, &p_pl))))
            }))
        }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "));
    let eq_p5 = if t_p1.eq_p {
        Text::from(format!("bool operator==(const {}&) const = default;", &t_p1.name_p))
    } else {
        Text::lit("")
    };
    let back_p6 = if t_p1.pod_p {
        Text::from(format!("static Result<{}> from_pod(const Pod& p);", &t_p1.name_p))
    } else {
        Text::lit("")
    };
    let deep_p7 = crate::prelude::run_to_end(crate::prelude::fold_job(t_p1.fields_p.clone(), false, Rc::new(move |(p0, p1): (bool, (Text, Text, crate::lower::model::OutTy))| crate::prelude::entered(crate::prelude::once_job(move || {
        let d_po = p0;
        let (_, _, ft_pp) = p1;
        prism_rtl::Turn::Finished(d_po || crate::lower::types::holds_dyn_f(&ft_pp))
    }))) as Rc<dyn Fn((bool, (Text, Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>));
    let level_decl_p8 = if deep_p7 {
        Text::lit("/// The level as a World reads it: each dynamic it holds sampled at the read point.\nPod level_pod(const Cx& cx) const;\n/// The update events of the dynamics it holds, and of theirs.\nvoid level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const;")
    } else {
        Text::lit("")
    };
    let decl_p9 = crate::emit::cpp::templates::items::cpp_tag_struct_f(&cpp_source_doc_f(&Text::from(format!("The `Level` of `{}`:", &t_p1.tag_name_p)), &t_p1.doc_p), &t_p1.name_p, &fields_p2, &t_p1.tag_name_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&Array::from(vec![eq_p5.clone(), back_p6.clone(), level_decl_p8.clone()]), &(|s_pq: &Text| s_pq != &Text::lit(""))), &Text::lit("\n")));
    let deep_pods_pa = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(t_p1.fields_p.clone(), Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (p_pr, f_ps, ft_pt) = p0;
        prism_rtl::Turn::More(Rc::new(CppDeepField { p_p0: p_pr.clone(), f_p1: f_ps.clone(), ft_p2: ft_pt.clone() }))
    }))) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "));
    let deep_ports_pb = crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::run_to_end(crate::prelude::each_job(t_p1.fields_p.clone(), Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (_, f_pu, ft_pv) = p0;
        prism_rtl::Turn::More(Rc::new(CppDeepPorts { f_p0: f_pu.clone(), ft_p1: ft_pv.clone() }))
    }))) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &(|s_p10: &Text| s_p10 != &Text::lit(""))), &Text::lit("\n"));
    let level_defs_pc = if deep_p7 {
        Array::from(vec![crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("Pod {}::level_pod(const Cx& cx) const", &t_p1.name_p)), &Text::from(format!("static_cast<void>(cx);\nreturn Pod::element(TAG, {{{}}});", &deep_pods_pa))), crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("void {}::level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const", &t_p1.name_p)), &Text::from(format!("static_cast<void>(cx);\nstatic_cast<void>(out);{}", &(if &deep_ports_pb == &Text::lit("") {
            Text::lit("")
        } else {
            Text::from(format!("\n{}", &deep_ports_pb))
        }))))])
    } else {
        Array::new()
    };
    let to_pod_pd = crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("Pod {}::to_pod() const", &t_p1.name_p)), &Text::from(format!("return Pod::element(TAG, {{{}}});", &pods_p3)));
    let show_pe = crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("void {}::show(Printer& p) const", &t_p1.name_p)), &Text::lit("prism_rtl::to_pod(*this).structure();\nShow<Pod>::show(prism_rtl::to_pod(*this), p);"));
    let from_pod_pf = if t_p1.pod_p {
        Array::from(vec![crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("Result<{}> {}::from_pod(const Pod& p)", &t_p1.name_p, &t_p1.name_p)), &Text::from(format!("if (auto t = p.tag(); t && *t == TAG) return {}{{{}}};\nreturn mismatch<{}>(\"a {}\", p);", &t_p1.name_p, &reads_p4, &t_p1.name_p, &t_p1.tag_name_p)))])
    } else {
        Array::new()
    };
    let deps_pg = crate::emit::cpp::patterns::concat2_f(&crate::prelude::run_to_end(crate::prelude::each_job(t_p1.fields_p.clone(), {
        let cp_p0x = cp_p0.clone();
        Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (_, _, ft_p11) = p0;
                prism_rtl::Turn::More(Rc::new(ValueDeps { cp_p0: cp_p0xy.clone(), t_p1: ft_p11.clone() }))
            }))
        }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    })));
    Parts { forward_p: Array::from(vec![Text::from(format!("struct {};", &t_p1.name_p))]), values_p: Array::from(vec![ValueDecl { path_p: decl_path_f(cp_p0, &t_p1.name_p), deps_p: deps_pg.clone(), text_p: decl_p9.clone() }]), protos_p: Array::new(), classes_p: Array::new(), outer_p: Array::new(), generic_p: Array::new(), defs_p: crate::prelude::append(&crate::prelude::append(&Array::from(vec![to_pod_pd.clone(), show_pe.clone()]), &from_pod_pf), &level_defs_pc) }
}

/// The step machine of `TagParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagParts: unbounded fn Cp, TagDef -> Parts
/// ```
pub struct TagParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::TagDef,
}

impl prism_rtl::Job<Parts> for TagParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        let cp_p0x = cp_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(t_p1x.fields_p.clone(), {
            let cp_p0xx = cp_p0x.clone();
            Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (_, f_ph, ft_pi) = p0;
                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), ft_pi.clone()), move |cpp_type_f_19342: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_f_19342, &crate::emit::cpp::field_id_f(&f_ph)))))
                }))
            }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_19304: Array<Text>| {
            let fields_p2 = crate::syntax::lexer::chars::join_f(&each_19304, &Text::lit("\n"));
            let pods_p3 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&t_p1x.fields_p, &(|(p_pj, f_pk, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("{{\"{}\", prism_rtl::to_pod({})}}", p_pj, &crate::emit::cpp::field_id_f(f_pk))))), &Text::lit(", "));
            crate::prelude::call_value(crate::prelude::each_job(t_p1x.fields_p.clone(), {
                let cp_p0xx = cp_p0x.clone();
                Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
                    let cp_p0xxy = cp_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (p_pl, f_pm, ft_pn) = p0;
                        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), ft_pn.clone()), move |cpp_type_f_19582: Text| prism_rtl::Turn::Finished(Text::from(format!(".{} = TRY(prism_rtl::from_pod<{}>(TRY(crate::prelude::field(p, \"{}\"))))", &crate::emit::cpp::field_id_f(&f_pm), &cpp_type_f_19582, &p_pl))))
                    }))
                }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_19510: Array<Text>| {
                let reads_p4 = crate::syntax::lexer::chars::join_f(&each_19510, &Text::lit(", "));
                let eq_p5 = if t_p1x.eq_p {
                    Text::from(format!("bool operator==(const {}&) const = default;", &t_p1x.name_p))
                } else {
                    Text::lit("")
                };
                let back_p6 = if t_p1x.pod_p {
                    Text::from(format!("static Result<{}> from_pod(const Pod& p);", &t_p1x.name_p))
                } else {
                    Text::lit("")
                };
                crate::prelude::call_value(crate::prelude::fold_job(t_p1x.fields_p.clone(), false, Rc::new(move |(p0, p1): (bool, (Text, Text, crate::lower::model::OutTy))| crate::prelude::entered(crate::prelude::once_job(move || {
                    let d_po = p0;
                    let (_, _, ft_pp) = p1;
                    prism_rtl::Turn::Finished(d_po || crate::lower::types::holds_dyn_f(&ft_pp))
                }))) as Rc<dyn Fn((bool, (Text, Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>), move |fold_19901: bool| {
                    let deep_p7 = fold_19901;
                    let level_decl_p8 = if deep_p7 {
                        Text::lit("/// The level as a World reads it: each dynamic it holds sampled at the read point.\nPod level_pod(const Cx& cx) const;\n/// The update events of the dynamics it holds, and of theirs.\nvoid level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const;")
                    } else {
                        Text::lit("")
                    };
                    let decl_p9 = crate::emit::cpp::templates::items::cpp_tag_struct_f(&cpp_source_doc_f(&Text::from(format!("The `Level` of `{}`:", &t_p1x.tag_name_p)), &t_p1x.doc_p), &t_p1x.name_p, &fields_p2, &t_p1x.tag_name_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&Array::from(vec![eq_p5.clone(), back_p6.clone(), level_decl_p8.clone()]), &(|s_pq: &Text| s_pq != &Text::lit(""))), &Text::lit("\n")));
                    crate::prelude::call_value(crate::prelude::each_job(t_p1x.fields_p.clone(), Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
                        let (p_pr, f_ps, ft_pt) = p0;
                        prism_rtl::Turn::More(Rc::new(CppDeepField { p_p0: p_pr.clone(), f_p1: f_ps.clone(), ft_p2: ft_pt.clone() }))
                    }))) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_20483: Array<Text>| {
                        let deep_pods_pa = crate::syntax::lexer::chars::join_f(&each_20483, &Text::lit(", "));
                        crate::prelude::call_value(crate::prelude::each_job(t_p1x.fields_p.clone(), Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
                            let (_, f_pu, ft_pv) = p0;
                            prism_rtl::Turn::More(Rc::new(CppDeepPorts { f_p0: f_pu.clone(), ft_p1: ft_pv.clone() }))
                        }))) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_20577: Array<Text>| {
                            let deep_ports_pb = crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&each_20577, &(|s_p10: &Text| s_p10 != &Text::lit(""))), &Text::lit("\n"));
                            let level_defs_pc = if deep_p7 {
                                Array::from(vec![crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("Pod {}::level_pod(const Cx& cx) const", &t_p1x.name_p)), &Text::from(format!("static_cast<void>(cx);\nreturn Pod::element(TAG, {{{}}});", &deep_pods_pa))), crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("void {}::level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const", &t_p1x.name_p)), &Text::from(format!("static_cast<void>(cx);\nstatic_cast<void>(out);{}", &(if &deep_ports_pb == &Text::lit("") {
                                    Text::lit("")
                                } else {
                                    Text::from(format!("\n{}", &deep_ports_pb))
                                }))))])
                            } else {
                                Array::new()
                            };
                            let to_pod_pd = crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("Pod {}::to_pod() const", &t_p1x.name_p)), &Text::from(format!("return Pod::element(TAG, {{{}}});", &pods_p3)));
                            let show_pe = crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("void {}::show(Printer& p) const", &t_p1x.name_p)), &Text::lit("prism_rtl::to_pod(*this).structure();\nShow<Pod>::show(prism_rtl::to_pod(*this), p);"));
                            let from_pod_pf = if t_p1x.pod_p {
                                Array::from(vec![crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("Result<{}> {}::from_pod(const Pod& p)", &t_p1x.name_p, &t_p1x.name_p)), &Text::from(format!("if (auto t = p.tag(); t && *t == TAG) return {}{{{}}};\nreturn mismatch<{}>(\"a {}\", p);", &t_p1x.name_p, &reads_p4, &t_p1x.name_p, &t_p1x.tag_name_p)))])
                            } else {
                                Array::new()
                            };
                            crate::prelude::call_value(crate::prelude::each_job(t_p1x.fields_p.clone(), {
                                let cp_p0xx = cp_p0x.clone();
                                Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| {
                                    let cp_p0xxy = cp_p0xx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let (_, _, ft_p11) = p0;
                                        prism_rtl::Turn::More(Rc::new(ValueDeps { cp_p0: cp_p0xxy.clone(), t_p1: ft_p11.clone() }))
                                    }))
                                }) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                            }), move |each_21571: Array<Array<Text>>| {
                                let deps_pg = crate::emit::cpp::patterns::concat2_f(&each_21571);
                                prism_rtl::Turn::Finished(Parts { forward_p: Array::from(vec![Text::from(format!("struct {};", &t_p1x.name_p))]), values_p: Array::from(vec![ValueDecl { path_p: decl_path_f(&cp_p0x, &t_p1x.name_p), deps_p: deps_pg.clone(), text_p: decl_p9.clone() }]), protos_p: Array::new(), classes_p: Array::new(), outer_p: Array::new(), generic_p: Array::new(), defs_p: crate::prelude::append(&crate::prelude::append(&Array::from(vec![to_pod_pd.clone(), show_pe.clone()]), &from_pod_pf), &level_defs_pc) })
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start TagParts, x`: what the function value is when passed to `@Run`.
pub fn start_tag_parts_f(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::TagDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(TagParts { cp_p0, t_p1 })
}

/// ```prism
/// CppDeepField: unbounded fn Text, Text, OutTy -> Text
/// ```
pub fn cpp_deep_field_f(p_p0: &Text, f_p1: &Text, ft_p2: &crate::lower::model::OutTy) -> Text {
    Text::from(format!("{{\"{}\", {}}}", p_p0, &cpp_deep_pod_f(f_p1, ft_p2)))
}

/// The step machine of `CppDeepField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppDeepField: unbounded fn Text, Text, OutTy -> Text
/// ```
pub struct CppDeepField {
    pub p_p0: Text,
    pub f_p1: Text,
    pub ft_p2: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for CppDeepField {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let p_p0 = &self.p_p0;
        let f_p1 = &self.f_p1;
        let ft_p2 = &self.ft_p2;
        let f_p1x = f_p1.clone();
        let ft_p2x = ft_p2.clone();
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(start_cpp_deep_pod_f(f_p1x.clone(), ft_p2x.clone()), move |cpp_deep_pod_f_22126: Text| prism_rtl::Turn::Finished(Text::from(format!("{{\"{}\", {}}}", &p_p0x, &cpp_deep_pod_f_22126))))
    }
}

/// `Start CppDeepField, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_deep_field_f(p_p0: Text, f_p1: Text, ft_p2: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppDeepField { p_p0, f_p1, ft_p2 })
}

/// ```prism
/// CppDeepPod: unbounded fn Text, OutTy -> Text
/// ```
pub fn cpp_deep_pod_f(f_p0: &Text, ft_p1: &crate::lower::model::OutTy) -> Text {
    'm22215: {
        if let crate::lower::model::OutTy::OutMap(_, m22215_0_1) = ft_p1 && let crate::lower::model::OutTy::OutDyn(m22215_0_1_r_0) = &**m22215_0_1 && let crate::lower::model::OutTy::OutNamed(m22215_0_1_r_0_r_0, _) = &**m22215_0_1_r_0 && (m22215_0_1_r_0_r_0 == &Text::lit("crate::Elem")) {
            break 'm22215 Text::from(format!("prism_rtl::dynamics_pod({}, cx)", &crate::emit::cpp::field_id_f(f_p0)));
        }
        if let crate::lower::model::OutTy::OutDyn(m22215_1_0) = ft_p1 && let crate::lower::model::OutTy::OutNamed(m22215_1_0_r_0, _) = &**m22215_1_0 && (m22215_1_0_r_0 == &Text::lit("crate::Elem")) {
            break 'm22215 Text::from(format!("prism_rtl::level_pod({}.sample(cx), cx)", &crate::emit::cpp::field_id_f(f_p0)));
        }
        if let other_p2 = ft_p1 {
            break 'm22215 if crate::lower::types::holds_dyn_f(other_p2) {
                Text::lit("[] { static_assert(false, \"prismc: a tag field holding a dynamic other than `$Elem` or a map of them is not read deep (claude/incremental-host-document.md, doubt WD)\"); return Pod(); }()")
            } else {
                Text::from(format!("prism_rtl::to_pod({})", &crate::emit::cpp::field_id_f(f_p0)))
            };
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `CppDeepPod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppDeepPod: unbounded fn Text, OutTy -> Text
/// ```
pub struct CppDeepPod {
    pub f_p0: Text,
    pub ft_p1: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for CppDeepPod {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f_p0 = &self.f_p0;
        let ft_p1 = &self.ft_p1;
        'm22215: {
            if let crate::lower::model::OutTy::OutMap(_, m22215_0_1) = ft_p1 && let crate::lower::model::OutTy::OutDyn(m22215_0_1_r_0) = &**m22215_0_1 && let crate::lower::model::OutTy::OutNamed(m22215_0_1_r_0_r_0, _) = &**m22215_0_1_r_0 && (m22215_0_1_r_0_r_0 == &Text::lit("crate::Elem")) {
                break 'm22215 prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::dynamics_pod({}, cx)", &crate::emit::cpp::field_id_f(f_p0))));
            }
            if let crate::lower::model::OutTy::OutDyn(m22215_1_0) = ft_p1 && let crate::lower::model::OutTy::OutNamed(m22215_1_0_r_0, _) = &**m22215_1_0 && (m22215_1_0_r_0 == &Text::lit("crate::Elem")) {
                break 'm22215 prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::level_pod({}.sample(cx), cx)", &crate::emit::cpp::field_id_f(f_p0))));
            }
            if let other_p2 = ft_p1 {
                break 'm22215 {
                    let f_p0x = f_p0.clone();
                    let other_p2x = other_p2.clone();
                    crate::prelude::call_then(crate::lower::types::start_holds_dyn_f(other_p2x.clone()), move |holds_dyn_f_22440: bool| if holds_dyn_f_22440 {
                        prism_rtl::Turn::Finished(Text::lit("[] { static_assert(false, \"prismc: a tag field holding a dynamic other than `$Elem` or a map of them is not read deep (claude/incremental-host-document.md, doubt WD)\"); return Pod(); }()"))
                    } else {
                        prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::to_pod({})", &crate::emit::cpp::field_id_f(&f_p0x))))
                    })
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start CppDeepPod, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_deep_pod_f(f_p0: Text, ft_p1: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppDeepPod { f_p0, ft_p1 })
}

/// ```prism
/// CppDeepPorts: unbounded fn Text, OutTy -> Text
/// ```
pub fn cpp_deep_ports_f(f_p0: &Text, ft_p1: &crate::lower::model::OutTy) -> Text {
    'm22760: {
        if let crate::lower::model::OutTy::OutMap(_, m22760_0_1) = ft_p1 && let crate::lower::model::OutTy::OutDyn(m22760_0_1_r_0) = &**m22760_0_1 && let crate::lower::model::OutTy::OutNamed(m22760_0_1_r_0_r_0, _) = &**m22760_0_1_r_0 && (m22760_0_1_r_0_r_0 == &Text::lit("crate::Elem")) {
            break 'm22760 Text::from(format!("prism_rtl::dynamics_ports({}, cx, out);", &crate::emit::cpp::field_id_f(f_p0)));
        }
        if let crate::lower::model::OutTy::OutDyn(m22760_1_0) = ft_p1 && let crate::lower::model::OutTy::OutNamed(m22760_1_0_r_0, _) = &**m22760_1_0 && (m22760_1_0_r_0 == &Text::lit("crate::Elem")) {
            break 'm22760 Text::from(format!("out.push_back({}.updates);\nprism_rtl::level_ports({}.sample(cx), cx, out);", &crate::emit::cpp::field_id_f(f_p0), &crate::emit::cpp::field_id_f(f_p0)));
        }
        Text::lit("")
    }
}

/// The step machine of `CppDeepPorts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CppDeepPorts: unbounded fn Text, OutTy -> Text
/// ```
pub struct CppDeepPorts {
    pub f_p0: Text,
    pub ft_p1: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for CppDeepPorts {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f_p0 = &self.f_p0;
        let ft_p1 = &self.ft_p1;
        'm22760: {
            if let crate::lower::model::OutTy::OutMap(_, m22760_0_1) = ft_p1 && let crate::lower::model::OutTy::OutDyn(m22760_0_1_r_0) = &**m22760_0_1 && let crate::lower::model::OutTy::OutNamed(m22760_0_1_r_0_r_0, _) = &**m22760_0_1_r_0 && (m22760_0_1_r_0_r_0 == &Text::lit("crate::Elem")) {
                break 'm22760 prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::dynamics_ports({}, cx, out);", &crate::emit::cpp::field_id_f(f_p0))));
            }
            if let crate::lower::model::OutTy::OutDyn(m22760_1_0) = ft_p1 && let crate::lower::model::OutTy::OutNamed(m22760_1_0_r_0, _) = &**m22760_1_0 && (m22760_1_0_r_0 == &Text::lit("crate::Elem")) {
                break 'm22760 prism_rtl::Turn::Finished(Text::from(format!("out.push_back({}.updates);\nprism_rtl::level_ports({}.sample(cx), cx, out);", &crate::emit::cpp::field_id_f(f_p0), &crate::emit::cpp::field_id_f(f_p0))));
            }
            prism_rtl::Turn::Finished(Text::lit(""))
        }
    }
}

/// `Start CppDeepPorts, x`: what the function value is when passed to `@Run`.
pub fn start_cpp_deep_ports_f(f_p0: Text, ft_p1: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(CppDeepPorts { f_p0, ft_p1 })
}

/// ```prism
/// RowParts: unbounded fn Cp, Text, RowDef -> Parts
/// ```
pub fn row_parts_f(cp_p0: &crate::emit::cpp::Cp, m_p1: &Text, r_p2: &crate::lower::model::RowDef) -> Parts {
    let names_p3 = crate::prelude::each(&r_p2.cases_p, &(|(v_pf, _): &(Text, Text)| v_pf.clone()));
    let levels_p4 = if r_p2.level_p {
        Text::lit("\nPod level_pod(const Cx& cx) const;\nvoid level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const;")
    } else {
        Text::lit("")
    };
    let pod_p5 = Text::from(format!("Pod to_pod() const;\nvoid show(Printer& p) const;{}{}", &(if r_p2.pod_p {
        Text::from(format!("\nstatic Result<{}> from_pod(const Pod& p);", &r_p2.name_p))
    } else {
        Text::lit("")
    }), &levels_p4));
    let cases_p6 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&r_p2.cases_p, &(|(v_pg, st_ph): &(Text, Text)| crate::emit::cpp::templates::items::case_decl_f(v_pg, &Text::from(format!("{} a0;{}", &row_struct_f(m_p1, st_ph), &(if r_p2.eq_p {
        Text::from(format!("\nbool operator==(const {}&) const = default;", v_pg))
    } else {
        Text::lit("")
    })))))), &Text::lit("\n"));
    let cls_p7 = crate::emit::cpp::templates::items::choice_class_f(&cpp_source_doc_f(&Text::from(format!("`{}`, a row kind\'s values:", &r_p2.prism_p)), &r_p2.doc_p), &Text::lit(""), &r_p2.name_p, &cases_p6, &crate::syntax::lexer::chars::join_f(&names_p3, &Text::lit(", ")), &pod_p5);
    let eq_p8 = if r_p2.eq_p {
        Text::from(format!("\ninline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &r_p2.name_p, &r_p2.name_p))
    } else {
        Text::lit("")
    };
    let level_defs_p9 = if r_p2.level_p {
        Array::from(vec![crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("Pod {}::level_pod(const Cx& cx) const", &r_p2.name_p)), &Text::lit("return std::visit([&](const auto& c) { return prism_rtl::level_pod(c.a0, cx); }, cases());")), crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("void {}::level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const", &r_p2.name_p)), &Text::lit("std::visit([&](const auto& c) { prism_rtl::level_ports(c.a0, cx, out); }, cases());"))])
    } else {
        Array::new()
    };
    let to_pod_pa = crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("Pod {}::to_pod() const", &r_p2.name_p)), &Text::lit("return std::visit([](const auto& c) { return prism_rtl::to_pod(c.a0); }, cases());"));
    let show_pb = crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("void {}::show(Printer& p) const", &r_p2.name_p)), &Text::lit("Show<Pod>::show(to_pod(), p);"));
    let reads_pc = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&r_p2.cases_p, &(|(v_pi, st_pj): &(Text, Text)| Text::from(format!("if (*t == {}::TAG) return {}({}{{TRY(prism_rtl::from_pod<{}>(p))}});", &row_struct_f(m_p1, st_pj), &r_p2.name_p, v_pi, &row_struct_f(m_p1, st_pj))))), &Text::lit("\n"));
    let from_pod_pd = if r_p2.pod_p {
        Array::from(vec![crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("Result<{}> {}::from_pod(const Pod& p)", &r_p2.name_p, &r_p2.name_p)), &Text::from(format!("if (auto t = p.tag()) {{\n{}\n}}\nreturn mismatch<{}>(\"a {}\", p);", &indent_cpp_f(&reads_pc), &r_p2.name_p, &r_p2.name_p)))])
    } else {
        Array::new()
    };
    let deps_pe = crate::emit::cpp::patterns::concat2_f(&crate::prelude::run_to_end(crate::prelude::each_job(r_p2.cases_p.clone(), {
        let cp_p0x = cp_p0.clone();
        Rc::new(move |p0: (Text, Text)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (_, st_pk) = p0;
                prism_rtl::Turn::More(Rc::new(ValueDeps { cp_p0: cp_p0xy.clone(), t_p1: crate::lower::model::OutTy::OutNamed(st_pk.clone(), Array::new()) }))
            }))
        }) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    })));
    Parts { forward_p: Array::from(vec![Text::from(format!("class {};", &r_p2.name_p))]), values_p: Array::from(vec![ValueDecl { path_p: decl_path_f(cp_p0, &r_p2.name_p), deps_p: deps_pe.clone(), text_p: Text::from(format!("{}{}", &cls_p7, &eq_p8)) }]), protos_p: Array::new(), classes_p: Array::new(), outer_p: Array::new(), generic_p: Array::new(), defs_p: crate::prelude::append(&crate::prelude::append(&Array::from(vec![to_pod_pa.clone(), show_pb.clone()]), &from_pod_pd), &level_defs_p9) }
}

/// The step machine of `RowParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowParts: unbounded fn Cp, Text, RowDef -> Parts
/// ```
pub struct RowParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub m_p1: Text,
    pub r_p2: crate::lower::model::RowDef,
}

impl prism_rtl::Job<Parts> for RowParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let m_p1 = &self.m_p1;
        let r_p2 = &self.r_p2;
        let names_p3 = crate::prelude::each(&r_p2.cases_p, &(|(v_pf, _): &(Text, Text)| v_pf.clone()));
        let levels_p4 = if r_p2.level_p {
            Text::lit("\nPod level_pod(const Cx& cx) const;\nvoid level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const;")
        } else {
            Text::lit("")
        };
        let pod_p5 = Text::from(format!("Pod to_pod() const;\nvoid show(Printer& p) const;{}{}", &(if r_p2.pod_p {
            Text::from(format!("\nstatic Result<{}> from_pod(const Pod& p);", &r_p2.name_p))
        } else {
            Text::lit("")
        }), &levels_p4));
        let cases_p6 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&r_p2.cases_p, &(|(v_pg, st_ph): &(Text, Text)| crate::emit::cpp::templates::items::case_decl_f(v_pg, &Text::from(format!("{} a0;{}", &row_struct_f(m_p1, st_ph), &(if r_p2.eq_p {
            Text::from(format!("\nbool operator==(const {}&) const = default;", v_pg))
        } else {
            Text::lit("")
        })))))), &Text::lit("\n"));
        let cls_p7 = crate::emit::cpp::templates::items::choice_class_f(&cpp_source_doc_f(&Text::from(format!("`{}`, a row kind\'s values:", &r_p2.prism_p)), &r_p2.doc_p), &Text::lit(""), &r_p2.name_p, &cases_p6, &crate::syntax::lexer::chars::join_f(&names_p3, &Text::lit(", ")), &pod_p5);
        let eq_p8 = if r_p2.eq_p {
            Text::from(format!("\ninline bool operator==(const {}& a, const {}& b) {{ return a.cases() == b.cases(); }}", &r_p2.name_p, &r_p2.name_p))
        } else {
            Text::lit("")
        };
        let level_defs_p9 = if r_p2.level_p {
            Array::from(vec![crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("Pod {}::level_pod(const Cx& cx) const", &r_p2.name_p)), &Text::lit("return std::visit([&](const auto& c) { return prism_rtl::level_pod(c.a0, cx); }, cases());")), crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("void {}::level_ports(const Cx& cx, std::vector<prism_rtl::Rc<prism_rtl::Port<Unit>>>& out) const", &r_p2.name_p)), &Text::lit("std::visit([&](const auto& c) { prism_rtl::level_ports(c.a0, cx, out); }, cases());"))])
        } else {
            Array::new()
        };
        let to_pod_pa = crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("Pod {}::to_pod() const", &r_p2.name_p)), &Text::lit("return std::visit([](const auto& c) { return prism_rtl::to_pod(c.a0); }, cases());"));
        let show_pb = crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("void {}::show(Printer& p) const", &r_p2.name_p)), &Text::lit("Show<Pod>::show(to_pod(), p);"));
        let reads_pc = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&r_p2.cases_p, &(|(v_pi, st_pj): &(Text, Text)| Text::from(format!("if (*t == {}::TAG) return {}({}{{TRY(prism_rtl::from_pod<{}>(p))}});", &row_struct_f(m_p1, st_pj), &r_p2.name_p, v_pi, &row_struct_f(m_p1, st_pj))))), &Text::lit("\n"));
        let from_pod_pd = if r_p2.pod_p {
            Array::from(vec![crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("Result<{}> {}::from_pod(const Pod& p)", &r_p2.name_p, &r_p2.name_p)), &Text::from(format!("if (auto t = p.tag()) {{\n{}\n}}\nreturn mismatch<{}>(\"a {}\", p);", &indent_cpp_f(&reads_pc), &r_p2.name_p, &r_p2.name_p)))])
        } else {
            Array::new()
        };
        let cp_p0x = cp_p0.clone();
        let r_p2x = r_p2.clone();
        crate::prelude::call_value(crate::prelude::each_job(r_p2x.cases_p.clone(), {
            let cp_p0xx = cp_p0x.clone();
            Rc::new(move |p0: (Text, Text)| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (_, st_pk) = p0;
                    prism_rtl::Turn::More(Rc::new(ValueDeps { cp_p0: cp_p0xxy.clone(), t_p1: crate::lower::model::OutTy::OutNamed(st_pk.clone(), Array::new()) }))
                }))
            }) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }), move |each_25198: Array<Array<Text>>| {
            let deps_pe = crate::emit::cpp::patterns::concat2_f(&each_25198);
            prism_rtl::Turn::Finished(Parts { forward_p: Array::from(vec![Text::from(format!("class {};", &r_p2x.name_p))]), values_p: Array::from(vec![ValueDecl { path_p: decl_path_f(&cp_p0x, &r_p2x.name_p), deps_p: deps_pe.clone(), text_p: Text::from(format!("{}{}", &cls_p7, &eq_p8)) }]), protos_p: Array::new(), classes_p: Array::new(), outer_p: Array::new(), generic_p: Array::new(), defs_p: crate::prelude::append(&crate::prelude::append(&Array::from(vec![to_pod_pa.clone(), show_pb.clone()]), &from_pod_pd), &level_defs_p9) })
        })
    }
}

/// `Start RowParts, x`: what the function value is when passed to `@Run`.
pub fn start_row_parts_f(cp_p0: crate::emit::cpp::Cp, m_p1: Text, r_p2: crate::lower::model::RowDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(RowParts { cp_p0, m_p1, r_p2 })
}

/// ```prism
/// RowStruct: fn Text, Text -> Text
/// ```
pub fn row_struct_f(m_p0: &Text, st_p1: &Text) -> Text {
    if crate::syntax::lexer::chars::contains_f(st_p1, &Text::lit(":")) || (m_p0 == &Text::lit("")) {
        crate::emit::cpp::type_path_f(st_p1)
    } else {
        Text::from(format!("crate::{}::{}", m_p0, st_p1))
    }
}

/// ```prism
/// AnswerParts: unbounded fn Cp, AnswerDef -> Parts
/// ```
pub fn answer_parts_f(cp_p0: &crate::emit::cpp::Cp, a_p1: &crate::lower::model::AnswerDef) -> Parts {
    let names_p2 = crate::prelude::each(&a_p1.cases_p, &(|c_pc: &crate::lower::model::AnswerCase| c_pc.variant_p.clone()));
    let accessors_p3 = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(a_p1.cases_p.clone(), {
        let cp_p0x = cp_p0.clone();
        Rc::new(move |p0: crate::lower::model::AnswerCase| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let c_pd = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), c_pd.ty_p.clone()), move |cpp_type_f_26057: Text| prism_rtl::Turn::Finished(Text::from(format!("Result<{}> {}() const;", &cpp_type_f_26057, &c_pd.accessor_p))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let members_p4 = Text::from(format!("const char* tag() const;\n{}\nstatic Result<Answer> decode(const Elem& e, const Pod& v);", &accessors_p3));
    let cases_p5 = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(a_p1.cases_p.clone(), {
        let cp_p0x = cp_p0.clone();
        Rc::new(move |p0: crate::lower::model::AnswerCase| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let c_pe = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), c_pe.ty_p.clone()), move |cpp_type_f_26287: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::case_decl_f(&c_pe.variant_p, &Text::from(format!("{} a0;", &cpp_type_f_26287)))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let cls_p6 = crate::emit::cpp::templates::items::choice_class_f(&cpp_doc_f(&Text::lit("`Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host\'s\nsupplier answers a child place with, and what a World\'s answer to a forwarded element\ndecodes to, carrying the tag\'s output.")), &Text::lit(""), &Text::lit("Answer"), &cases_p5, &crate::syntax::lexer::chars::join_f(&names_p2, &Text::lit(", ")), &members_p4);
    let tags_p7 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&a_p1.cases_p, &(|c_pf: &crate::lower::model::AnswerCase| Text::from(format!("if (std::holds_alternative<{}>(cases())) return {}::TAG;", &c_pf.variant_p, &crate::emit::cpp::type_path_f(&c_pf.struct_path_p))))), &Text::lit("\n"));
    let tag_fn_p8 = crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::lit("const char* Answer::tag() const"), &Text::from(format!("{}\nprism_rtl::unreachable();", &tags_p7)));
    let getters_p9 = crate::prelude::run_to_end(crate::prelude::each_job(a_p1.cases_p.clone(), {
        let cp_p0x = cp_p0.clone();
        Rc::new(move |p0: crate::lower::model::AnswerCase| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let c_pg = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), c_pg.ty_p.clone()), move |cpp_type_f_26953: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&Text::from(format!("A `{}`\'s answer.", &c_pg.tag_name_p))), &Text::from(format!("Result<{}> Answer::{}() const", &cpp_type_f_26953, &c_pg.accessor_p)), &Text::from(format!("if (auto c = std::get_if<{}>(&cases())) return c->a0;\nreturn unexpected(Fault::answer(str(\"an answer for \", tag(), \", where {}\'s was expected\")));", &c_pg.variant_p, &c_pg.tag_name_p)))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let decodes_pa = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(a_p1.cases_p.clone(), {
        let cp_p0x = cp_p0.clone();
        Rc::new(move |p0: crate::lower::model::AnswerCase| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let c_ph = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), c_ph.ty_p.clone()), move |cpp_type_f_27301: Text| prism_rtl::Turn::Finished(Text::from(format!("if (is<Elem::{}>(e)) return Answer({}{{TRY(prism_rtl::from_pod<{}>(v))}});", &c_ph.variant_p, &c_ph.variant_p, &cpp_type_f_27301))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let decode_pb = crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&Text::lit("A World\'s answer to the element `e`, decoded by its tag.")), &Text::lit("Result<Answer> Answer::decode(const Elem& e, const Pod& v)"), &Text::from(format!("{}\nprism_rtl::unreachable();", &decodes_pa)));
    Parts { forward_p: Array::from(vec![Text::lit("class Answer;")]), values_p: Array::from(vec![ValueDecl { path_p: Text::lit("Answer"), deps_p: Array::new(), text_p: cls_p6.clone() }]), protos_p: Array::new(), classes_p: Array::new(), outer_p: Array::new(), generic_p: Array::new(), defs_p: crate::prelude::append(&Array::from(vec![tag_fn_p8.clone()]), &crate::prelude::push(&getters_p9, &decode_pb)) }
}

/// The step machine of `AnswerParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnswerParts: unbounded fn Cp, AnswerDef -> Parts
/// ```
pub struct AnswerParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub a_p1: crate::lower::model::AnswerDef,
}

impl prism_rtl::Job<Parts> for AnswerParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let a_p1 = &self.a_p1;
        let names_p2 = crate::prelude::each(&a_p1.cases_p, &(|c_pc: &crate::lower::model::AnswerCase| c_pc.variant_p.clone()));
        let a_p1x = a_p1.clone();
        let cp_p0x = cp_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(a_p1x.cases_p.clone(), {
            let cp_p0xx = cp_p0x.clone();
            Rc::new(move |p0: crate::lower::model::AnswerCase| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let c_pd = p0;
                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), c_pd.ty_p.clone()), move |cpp_type_f_26057: Text| prism_rtl::Turn::Finished(Text::from(format!("Result<{}> {}() const;", &cpp_type_f_26057, &c_pd.accessor_p))))
                }))
            }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_26029: Array<Text>| {
            let accessors_p3 = crate::syntax::lexer::chars::join_f(&each_26029, &Text::lit("\n"));
            let members_p4 = Text::from(format!("const char* tag() const;\n{}\nstatic Result<Answer> decode(const Elem& e, const Pod& v);", &accessors_p3));
            crate::prelude::call_value(crate::prelude::each_job(a_p1x.cases_p.clone(), {
                let cp_p0xx = cp_p0x.clone();
                Rc::new(move |p0: crate::lower::model::AnswerCase| {
                    let cp_p0xxy = cp_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let c_pe = p0;
                        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), c_pe.ty_p.clone()), move |cpp_type_f_26287: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::case_decl_f(&c_pe.variant_p, &Text::from(format!("{} a0;", &cpp_type_f_26287)))))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_26246: Array<Text>| {
                let cases_p5 = crate::syntax::lexer::chars::join_f(&each_26246, &Text::lit("\n"));
                let cls_p6 = crate::emit::cpp::templates::items::choice_class_f(&cpp_doc_f(&Text::lit("`Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host\'s\nsupplier answers a child place with, and what a World\'s answer to a forwarded element\ndecodes to, carrying the tag\'s output.")), &Text::lit(""), &Text::lit("Answer"), &cases_p5, &crate::syntax::lexer::chars::join_f(&names_p2, &Text::lit(", ")), &members_p4);
                let tags_p7 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&a_p1x.cases_p, &(|c_pf: &crate::lower::model::AnswerCase| Text::from(format!("if (std::holds_alternative<{}>(cases())) return {}::TAG;", &c_pf.variant_p, &crate::emit::cpp::type_path_f(&c_pf.struct_path_p))))), &Text::lit("\n"));
                let tag_fn_p8 = crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::lit("const char* Answer::tag() const"), &Text::from(format!("{}\nprism_rtl::unreachable();", &tags_p7)));
                crate::prelude::call_value(crate::prelude::each_job(a_p1x.cases_p.clone(), {
                    let cp_p0xx = cp_p0x.clone();
                    Rc::new(move |p0: crate::lower::model::AnswerCase| {
                        let cp_p0xxy = cp_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let c_pg = p0;
                            crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), c_pg.ty_p.clone()), move |cpp_type_f_26953: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&Text::from(format!("A `{}`\'s answer.", &c_pg.tag_name_p))), &Text::from(format!("Result<{}> Answer::{}() const", &cpp_type_f_26953, &c_pg.accessor_p)), &Text::from(format!("if (auto c = std::get_if<{}>(&cases())) return c->a0;\nreturn unexpected(Fault::answer(str(\"an answer for \", tag(), \", where {}\'s was expected\")));", &c_pg.variant_p, &c_pg.tag_name_p)))))
                        }))
                    }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_26875: Array<Text>| {
                    let getters_p9 = each_26875;
                    crate::prelude::call_value(crate::prelude::each_job(a_p1x.cases_p.clone(), {
                        let cp_p0xx = cp_p0x.clone();
                        Rc::new(move |p0: crate::lower::model::AnswerCase| {
                            let cp_p0xxy = cp_p0xx.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let c_ph = p0;
                                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), c_ph.ty_p.clone()), move |cpp_type_f_27301: Text| prism_rtl::Turn::Finished(Text::from(format!("if (is<Elem::{}>(e)) return Answer({}{{TRY(prism_rtl::from_pod<{}>(v))}});", &c_ph.variant_p, &c_ph.variant_p, &cpp_type_f_27301))))
                            }))
                        }) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>
                    }), move |each_27199: Array<Text>| {
                        let decodes_pa = crate::syntax::lexer::chars::join_f(&each_27199, &Text::lit("\n"));
                        let decode_pb = crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&Text::lit("A World\'s answer to the element `e`, decoded by its tag.")), &Text::lit("Result<Answer> Answer::decode(const Elem& e, const Pod& v)"), &Text::from(format!("{}\nprism_rtl::unreachable();", &decodes_pa)));
                        prism_rtl::Turn::Finished(Parts { forward_p: Array::from(vec![Text::lit("class Answer;")]), values_p: Array::from(vec![ValueDecl { path_p: Text::lit("Answer"), deps_p: Array::new(), text_p: cls_p6.clone() }]), protos_p: Array::new(), classes_p: Array::new(), outer_p: Array::new(), generic_p: Array::new(), defs_p: crate::prelude::append(&Array::from(vec![tag_fn_p8.clone()]), &crate::prelude::push(&getters_p9, &decode_pb)) })
                    })
                })
            })
        })
    }
}

/// `Start AnswerParts, x`: what the function value is when passed to `@Run`.
pub fn start_answer_parts_f(cp_p0: crate::emit::cpp::Cp, a_p1: crate::lower::model::AnswerDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(AnswerParts { cp_p0, a_p1 })
}

/// ```prism
/// JobParts: unbounded fn Cp, JobDef -> Parts
/// ```
pub fn job_parts_f(cp_p0: &crate::emit::cpp::Cp, j_p1: &crate::lower::model::JobDef) -> Parts {
    let gens_p2 = cpp_template_head_f(&generic_names_of_f(&j_p1.generics_p));
    let head_p3 = head_of_f(&j_p1.name_p, &generic_names_of_f(&j_p1.generics_p));
    let jcp_p4 = crate::emit::cpp::with_fields_f(cp_p0, &j_p1.fields_p);
    let fields_p5 = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(j_p1.fields_p.clone(), {
        let cp_p0x = cp_p0.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (n_pe, t_pf) = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), t_pf.clone()), move |cpp_type_f_28067: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_f_28067, &crate::emit::cpp::field_id_f(&n_pe)))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let params_p6 = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(j_p1.fields_p.clone(), {
        let cp_p0x = cp_p0.clone();
        Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (n_pg, t_ph) = p0;
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xy.clone(), t_ph.clone()), move |cpp_type_f_28155: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_f_28155, &crate::emit::cpp::field_id_f(&n_pg)))))
            }))
        }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit(", "));
    let inits_p7 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&j_p1.fields_p, &(|(n_pi, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{}(std::move({}))", &crate::emit::cpp::field_id_f(n_pi), &crate::emit::cpp::field_id_f(n_pi))))), &Text::lit(", "));
    let ctor_p8 = if &crate::prelude::len(&j_p1.fields_p) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!("{}({}) : {} {{}}", &j_p1.name_p, &params_p6, &inits_p7))
    };
    let ret_p9 = crate::emit::cpp::cpp_type_f(cp_p0, &j_p1.ret_p);
    let decl_pa = crate::emit::cpp::templates::items::job_struct_f(&cpp_doc_f(&j_p1.doc_p), &gens_p2, &j_p1.name_p, &ret_p9, &fields_p5, &ctor_p8);
    let cycle_pb = crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("{}prism_rtl::Turn<{}> {}::cycle() const", &gens_p2, &ret_p9, &head_p3)), &crate::emit::cpp::stmts::cpp_body_f(&jcp_p4, &j_p1.body_p));
    let start_pc = crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&Text::from(format!("`Start {}, x`: what the function value is when passed to `@Run`.", &j_p1.name_p))), &Text::from(format!("{}prism_rtl::JobRef<{}> {}({})", &gens_p2, &ret_p9, &j_p1.start_p, &params_p6)), &Text::from(format!("return prism_rtl::make_rc<{}>({});", &head_p3, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&j_p1.fields_p, &(|(n_pj, _): &(Text, crate::lower::model::OutTy)| crate::emit::cpp::field_id_f(n_pj))), &Text::lit(", ")))));
    let generic_pd = &crate::prelude::len(&j_p1.generics_p) > &Nat::from(0u32);
    Parts { forward_p: Array::from(vec![Text::from(format!("{}struct {};", &gens_p2, &j_p1.name_p))]), values_p: Array::new(), protos_p: Array::from(vec![Text::from(format!("{}prism_rtl::JobRef<{}> {}({});", &gens_p2, &ret_p9, &j_p1.start_p, &params_p6))]), classes_p: Array::from(vec![decl_pa.clone()]), outer_p: Array::new(), generic_p: if generic_pd {
        Array::from(vec![cycle_pb.clone(), start_pc.clone()])
    } else {
        Array::new()
    }, defs_p: if generic_pd {
        Array::new()
    } else {
        Array::from(vec![cycle_pb.clone(), start_pc.clone()])
    } }
}

/// The step machine of `JobParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobParts: unbounded fn Cp, JobDef -> Parts
/// ```
pub struct JobParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub j_p1: crate::lower::model::JobDef,
}

impl prism_rtl::Job<Parts> for JobParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let j_p1 = &self.j_p1;
        let gens_p2 = cpp_template_head_f(&generic_names_of_f(&j_p1.generics_p));
        let head_p3 = head_of_f(&j_p1.name_p, &generic_names_of_f(&j_p1.generics_p));
        let jcp_p4 = crate::emit::cpp::with_fields_f(cp_p0, &j_p1.fields_p);
        let cp_p0x = cp_p0.clone();
        let j_p1x = j_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(j_p1x.fields_p.clone(), {
            let cp_p0xx = cp_p0x.clone();
            Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (n_pe, t_pf) = p0;
                    crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), t_pf.clone()), move |cpp_type_f_28067: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {};", &cpp_type_f_28067, &crate::emit::cpp::field_id_f(&n_pe)))))
                }))
            }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_28038: Array<Text>| {
            let fields_p5 = crate::syntax::lexer::chars::join_f(&each_28038, &Text::lit("\n"));
            crate::prelude::call_value(crate::prelude::each_job(j_p1x.fields_p.clone(), {
                let cp_p0xx = cp_p0x.clone();
                Rc::new(move |p0: (Text, crate::lower::model::OutTy)| {
                    let cp_p0xxy = cp_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let (n_pg, t_ph) = p0;
                        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0xxy.clone(), t_ph.clone()), move |cpp_type_f_28155: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {}", &cpp_type_f_28155, &crate::emit::cpp::field_id_f(&n_pg)))))
                    }))
                }) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_28126: Array<Text>| {
                let params_p6 = crate::syntax::lexer::chars::join_f(&each_28126, &Text::lit(", "));
                let inits_p7 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&j_p1x.fields_p, &(|(n_pi, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{}(std::move({}))", &crate::emit::cpp::field_id_f(n_pi), &crate::emit::cpp::field_id_f(n_pi))))), &Text::lit(", "));
                let ctor_p8 = if &crate::prelude::len(&j_p1x.fields_p) == &Nat::from(0u32) {
                    Text::lit("")
                } else {
                    Text::from(format!("{}({}) : {} {{}}", &j_p1x.name_p, &params_p6, &inits_p7))
                };
                crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), j_p1x.ret_p.clone()), move |cpp_type_f_28387: Text| {
                    let ret_p9 = cpp_type_f_28387;
                    let decl_pa = crate::emit::cpp::templates::items::job_struct_f(&cpp_doc_f(&j_p1x.doc_p), &gens_p2, &j_p1x.name_p, &ret_p9, &fields_p5, &ctor_p8);
                    crate::prelude::call_then(crate::emit::cpp::stmts::start_cpp_body_f(jcp_p4.clone(), j_p1x.body_p.clone()), move |cpp_body_f_28565: Text| {
                        let cycle_pb = crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("{}prism_rtl::Turn<{}> {}::cycle() const", &gens_p2, &ret_p9, &head_p3)), &cpp_body_f_28565);
                        let start_pc = crate::emit::cpp::templates::items::cpp_function_f(&cpp_doc_f(&Text::from(format!("`Start {}, x`: what the function value is when passed to `@Run`.", &j_p1x.name_p))), &Text::from(format!("{}prism_rtl::JobRef<{}> {}({})", &gens_p2, &ret_p9, &j_p1x.start_p, &params_p6)), &Text::from(format!("return prism_rtl::make_rc<{}>({});", &head_p3, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&j_p1x.fields_p, &(|(n_pj, _): &(Text, crate::lower::model::OutTy)| crate::emit::cpp::field_id_f(n_pj))), &Text::lit(", ")))));
                        let generic_pd = &crate::prelude::len(&j_p1x.generics_p) > &Nat::from(0u32);
                        prism_rtl::Turn::Finished(Parts { forward_p: Array::from(vec![Text::from(format!("{}struct {};", &gens_p2, &j_p1x.name_p))]), values_p: Array::new(), protos_p: Array::from(vec![Text::from(format!("{}prism_rtl::JobRef<{}> {}({});", &gens_p2, &ret_p9, &j_p1x.start_p, &params_p6))]), classes_p: Array::from(vec![decl_pa.clone()]), outer_p: Array::new(), generic_p: if generic_pd {
                            Array::from(vec![cycle_pb.clone(), start_pc.clone()])
                        } else {
                            Array::new()
                        }, defs_p: if generic_pd {
                            Array::new()
                        } else {
                            Array::from(vec![cycle_pb.clone(), start_pc.clone()])
                        } })
                    })
                })
            })
        })
    }
}

/// `Start JobParts, x`: what the function value is when passed to `@Run`.
pub fn start_job_parts_f(cp_p0: crate::emit::cpp::Cp, j_p1: crate::lower::model::JobDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(JobParts { cp_p0, j_p1 })
}

/// ```prism
/// TraitParts: unbounded fn Cp, TraitDef -> Parts
/// ```
pub fn trait_parts_f(cp_p0: &crate::emit::cpp::Cp, t_p1: &crate::lower::model::TraitDef) -> Parts {
    let defaults_p2 = crate::prelude::filter(&t_p1.methods_p, &(|f_p6: &crate::lower::model::FnDef| f_p6.public_p));
    let defs_p3 = crate::prelude::run_to_end(crate::prelude::each_job(defaults_p2.clone(), {
        let cp_p0x = cp_p0.clone();
        Rc::new(move |p0: crate::lower::model::FnDef| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let f_p7 = p0;
                prism_rtl::Turn::More(Rc::new(FnDefinition { cp_p0: cp_p0xy.clone(), f_p1: with_generics_f(&f_p7, &Array::from(vec![(Text::lit("Self"), Array::new())])) }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let protos_p4 = crate::prelude::run_to_end(crate::prelude::each_job(t_p1.methods_p.clone(), {
        let cp_p0x = cp_p0.clone();
        Rc::new(move |p0: crate::lower::model::FnDef| {
            let cp_p0xy = cp_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let f_p8 = p0;
                crate::prelude::call_then(start_fn_signature_f(cp_p0xy.clone(), with_generics_f(&f_p8, &Array::from(vec![(Text::lit("Self"), Array::new())]))), move |fn_signature_f_29805: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{};", &fn_signature_f_29805, &(if f_p8.public_p { Text::lit("") } else { Text::lit(" = delete") })))))
            }))
        }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let generic_p5 = if &crate::prelude::len(&defaults_p2) == &Nat::from(0u32) {
        Array::new()
    } else {
        Array::from(vec![crate::emit::cpp::templates::items::trait_namespace_f(&t_p1.name_p, &crate::syntax::lexer::chars::join_f(&defs_p3, &Text::lit("\n")))])
    };
    let mut this: Parts = generic_only_f(&generic_p5);
    this.protos_p = Array::from(vec![crate::emit::cpp::templates::items::trait_namespace_f(&t_p1.name_p, &crate::syntax::lexer::chars::join_f(&protos_p4, &Text::lit("\n")))]);
    this
}

/// The step machine of `TraitParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TraitParts: unbounded fn Cp, TraitDef -> Parts
/// ```
pub struct TraitParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub t_p1: crate::lower::model::TraitDef,
}

impl prism_rtl::Job<Parts> for TraitParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let t_p1 = &self.t_p1;
        let defaults_p2 = crate::prelude::filter(&t_p1.methods_p, &(|f_p6: &crate::lower::model::FnDef| f_p6.public_p));
        let cp_p0x = cp_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(defaults_p2.clone(), {
            let cp_p0xx = cp_p0x.clone();
            Rc::new(move |p0: crate::lower::model::FnDef| {
                let cp_p0xxy = cp_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let f_p7 = p0;
                    prism_rtl::Turn::More(Rc::new(FnDefinition { cp_p0: cp_p0xxy.clone(), f_p1: with_generics_f(&f_p7, &Array::from(vec![(Text::lit("Self"), Array::new())])) }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_29689: Array<Text>| {
            let defs_p3 = each_29689;
            crate::prelude::call_value(crate::prelude::each_job(t_p1x.methods_p.clone(), {
                let cp_p0xx = cp_p0x.clone();
                Rc::new(move |p0: crate::lower::model::FnDef| {
                    let cp_p0xxy = cp_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_p8 = p0;
                        crate::prelude::call_then(start_fn_signature_f(cp_p0xxy.clone(), with_generics_f(&f_p8, &Array::from(vec![(Text::lit("Self"), Array::new())]))), move |fn_signature_f_29805: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{};", &fn_signature_f_29805, &(if f_p8.public_p { Text::lit("") } else { Text::lit(" = delete") })))))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_29782: Array<Text>| {
                let protos_p4 = each_29782;
                let generic_p5 = if &crate::prelude::len(&defaults_p2) == &Nat::from(0u32) {
                    Array::new()
                } else {
                    Array::from(vec![crate::emit::cpp::templates::items::trait_namespace_f(&t_p1x.name_p, &crate::syntax::lexer::chars::join_f(&defs_p3, &Text::lit("\n")))])
                };
                prism_rtl::Turn::Finished({
                    let mut this: Parts = generic_only_f(&generic_p5);
                    this.protos_p = Array::from(vec![crate::emit::cpp::templates::items::trait_namespace_f(&t_p1x.name_p, &crate::syntax::lexer::chars::join_f(&protos_p4, &Text::lit("\n")))]);
                    this
                })
            })
        })
    }
}

/// `Start TraitParts, x`: what the function value is when passed to `@Run`.
pub fn start_trait_parts_f(cp_p0: crate::emit::cpp::Cp, t_p1: crate::lower::model::TraitDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(TraitParts { cp_p0, t_p1 })
}

/// ```prism
/// ImplParts: unbounded fn Cp, ImplDef -> Parts
/// ```
pub fn impl_parts_f(cp_p0: &crate::emit::cpp::Cp, i_p1: &crate::lower::model::ImplDef) -> Parts {
    let head_p2 = crate::emit::cpp::cpp_type_f(cp_p0, &i_p1.head_p);
    let gens_p3 = cpp_template_head_f(&generic_names_of_f(&i_p1.generics_p));
    let fns_p4 = crate::prelude::run_to_end(crate::prelude::each_job(i_p1.methods_p.clone(), {
        let cp_p0x = cp_p0.clone();
        let i_p1x = i_p1.clone();
        Rc::new(move |p0: crate::lower::model::FnDef| {
            let cp_p0xy = cp_p0x.clone();
            let i_p1xy = i_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let f_p6 = p0;
                prism_rtl::Turn::More(Rc::new(FnParts { cp_p0: cp_p0xy.clone(), f_p1: with_generics_f(&f_p6, &i_p1xy.generics_p) }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Parts>>>
    }));
    let own_p5 = crate::prelude::fold(&fns_p4, &no_parts_p(), &(|acc_p7: &Parts, p_p8: &Parts| join_parts_f(acc_p7, p_p8)));
    match &i_p1.cls_p {
        m30792_0 if (m30792_0 == &Text::lit("Prelude.Show")) => {
            let shown_p9 = crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&i_p1.methods_p, &(|f_pa: &crate::lower::model::FnDef| f_pa.name_p.clone())), &Nat::from(0u32)), &Text::lit("show"));
            join_parts_f(&own_p5, &protos_defs_f(&Array::new(), &Array::from(vec![crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("{}void {}::show(Printer& p) const", &gens_p3, &head_p2)), &Text::from(format!("p.raw({}(*this).to_string());", &shown_p9)))])))
        },
        m30792_1 if (m30792_1 == &Text::lit("Prelude.Eq")) => {
            let eq_pb = crate::prelude::fold(&i_p1.methods_p, &Text::lit(""), &(|acc_pc: &Text, f_pd: &crate::lower::model::FnDef| if !crate::syntax::lexer::chars::has_prefix_f(&f_pd.name_p, &Text::lit("ne")) && (acc_pc == &Text::lit("")) {
                f_pd.name_p.clone()
            } else {
                acc_pc.clone()
            }));
            join_parts_f(&own_p5, &protos_defs_f(&Array::from(vec![Text::from(format!("{}bool operator==(const {}& a, const {}& b);", &gens_p3, &head_p2, &head_p2))]), &Array::from(vec![crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("{}bool operator==(const {}& a, const {}& b)", &gens_p3, &head_p2, &head_p2)), &Text::from(format!("return {}(a, b);", &eq_pb)))])))
        },
        _ => {
            let tr_pe = crate::syntax::lexer::chars::drop_prefix_f(&crate::emit::cpp::type_path_f(&i_p1.tr_p), &Text::lit("crate::"));
            let own_pf = !crate::syntax::lexer::chars::contains_f(&tr_pe, &Text::lit("::"));
            let ns_pg = if own_pf {
                tr_pe.clone()
            } else {
                Text::from(format!("impl_{}", &crate::syntax::lexer::chars::join_f(&crate::prelude::split_on(&tr_pe, &Text::lit("::")), &Text::lit("_"))))
            };
            let in_trait_ph = crate::prelude::run_to_end(crate::prelude::each_job(i_p1.methods_p.clone(), {
                let ns_pgx = ns_pg.clone();
                let cp_p0x = cp_p0.clone();
                let i_p1x = i_p1.clone();
                Rc::new(move |p0: crate::lower::model::FnDef| {
                    let ns_pgxy = ns_pgx.clone();
                    let cp_p0xy = cp_p0x.clone();
                    let i_p1xy = i_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_pk = p0;
                        crate::prelude::call_then(start_fn_definition_f(cp_p0xy.clone(), with_generics_f(&f_pk, &i_p1xy.generics_p)), move |fn_definition_f_31659: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::trait_namespace_f(&ns_pgxy, &fn_definition_f_31659)))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            let protos_pi = crate::prelude::run_to_end(crate::prelude::each_job(i_p1.methods_p.clone(), {
                let ns_pgx = ns_pg.clone();
                let cp_p0x = cp_p0.clone();
                let i_p1x = i_p1.clone();
                Rc::new(move |p0: crate::lower::model::FnDef| {
                    let ns_pgxy = ns_pgx.clone();
                    let cp_p0xy = cp_p0x.clone();
                    let i_p1xy = i_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_pl = p0;
                        crate::prelude::call_then(start_fn_signature_f(cp_p0xy.clone(), with_generics_f(&f_pl, &i_p1xy.generics_p)), move |fn_signature_f_31773: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::trait_namespace_f(&ns_pgxy, &Text::from(format!("{};", &fn_signature_f_31773)))))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
            }));
            let outer_pj = if own_pf {
                Array::new()
            } else {
                Array::from(vec![crate::emit::cpp::templates::items::trait_namespace_f(&tr_pe, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&i_p1.methods_p, &(|f_pm: &crate::lower::model::FnDef| Text::from(format!("using ::crate::{}::{}::{};", &cp_p0.home_p, &ns_pg, &crate::emit::cpp::cpp_id_f(&f_pm.name_p))))), &Text::lit("\n")))])
            };
            {
                let mut this: Parts = protos_defs_f(&protos_pi, &in_trait_ph);
                this.outer_p = outer_pj.clone();
                this
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ImplParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ImplParts: unbounded fn Cp, ImplDef -> Parts
/// ```
pub struct ImplParts {
    pub cp_p0: crate::emit::cpp::Cp,
    pub i_p1: crate::lower::model::ImplDef,
}

impl prism_rtl::Job<Parts> for ImplParts {
    fn cycle(&self) -> prism_rtl::Turn<Parts> {
        let cp_p0 = &self.cp_p0;
        let i_p1 = &self.i_p1;
        let cp_p0x = cp_p0.clone();
        let i_p1x = i_p1.clone();
        crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x.clone(), i_p1x.head_p.clone()), move |cpp_type_f_30574: Text| {
            let head_p2 = cpp_type_f_30574;
            let gens_p3 = cpp_template_head_f(&generic_names_of_f(&i_p1x.generics_p));
            crate::prelude::call_value(crate::prelude::each_job(i_p1x.methods_p.clone(), {
                let cp_p0xx = cp_p0x.clone();
                let i_p1xx = i_p1x.clone();
                Rc::new(move |p0: crate::lower::model::FnDef| {
                    let cp_p0xxy = cp_p0xx.clone();
                    let i_p1xxy = i_p1xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_p6 = p0;
                        prism_rtl::Turn::More(Rc::new(FnParts { cp_p0: cp_p0xxy.clone(), f_p1: with_generics_f(&f_p6, &i_p1xxy.generics_p) }))
                    }))
                }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Parts>>>
            }), move |each_30666: Array<Parts>| {
                let fns_p4 = each_30666;
                let own_p5 = crate::prelude::fold(&fns_p4, &no_parts_p(), &(|acc_p7: &Parts, p_p8: &Parts| join_parts_f(acc_p7, p_p8)));
                match &i_p1x.cls_p {
                    m30792_0 if (m30792_0 == &Text::lit("Prelude.Show")) => {
                        let shown_p9 = crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&i_p1x.methods_p, &(|f_pa: &crate::lower::model::FnDef| f_pa.name_p.clone())), &Nat::from(0u32)), &Text::lit("show"));
                        prism_rtl::Turn::Finished(join_parts_f(&own_p5, &protos_defs_f(&Array::new(), &Array::from(vec![crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("{}void {}::show(Printer& p) const", &gens_p3, &head_p2)), &Text::from(format!("p.raw({}(*this).to_string());", &shown_p9)))]))))
                    },
                    m30792_1 if (m30792_1 == &Text::lit("Prelude.Eq")) => {
                        let eq_pb = crate::prelude::fold(&i_p1x.methods_p, &Text::lit(""), &(|acc_pc: &Text, f_pd: &crate::lower::model::FnDef| if !crate::syntax::lexer::chars::has_prefix_f(&f_pd.name_p, &Text::lit("ne")) && (acc_pc == &Text::lit("")) {
                            f_pd.name_p.clone()
                        } else {
                            acc_pc.clone()
                        }));
                        prism_rtl::Turn::Finished(join_parts_f(&own_p5, &protos_defs_f(&Array::from(vec![Text::from(format!("{}bool operator==(const {}& a, const {}& b);", &gens_p3, &head_p2, &head_p2))]), &Array::from(vec![crate::emit::cpp::templates::items::cpp_function_f(&Text::lit(""), &Text::from(format!("{}bool operator==(const {}& a, const {}& b)", &gens_p3, &head_p2, &head_p2)), &Text::from(format!("return {}(a, b);", &eq_pb)))]))))
                    },
                    _ => {
                        let tr_pe = crate::syntax::lexer::chars::drop_prefix_f(&crate::emit::cpp::type_path_f(&i_p1x.tr_p), &Text::lit("crate::"));
                        let own_pf = !crate::syntax::lexer::chars::contains_f(&tr_pe, &Text::lit("::"));
                        let ns_pg = if own_pf {
                            tr_pe.clone()
                        } else {
                            Text::from(format!("impl_{}", &crate::syntax::lexer::chars::join_f(&crate::prelude::split_on(&tr_pe, &Text::lit("::")), &Text::lit("_"))))
                        };
                        crate::prelude::call_value(crate::prelude::each_job(i_p1x.methods_p.clone(), {
                            let ns_pgx = ns_pg.clone();
                            let cp_p0xx = cp_p0x.clone();
                            let i_p1xx = i_p1x.clone();
                            Rc::new(move |p0: crate::lower::model::FnDef| {
                                let ns_pgxy = ns_pgx.clone();
                                let cp_p0xxy = cp_p0xx.clone();
                                let i_p1xxy = i_p1xx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let f_pk = p0;
                                    crate::prelude::call_then(start_fn_definition_f(cp_p0xxy.clone(), with_generics_f(&f_pk, &i_p1xxy.generics_p)), move |fn_definition_f_31659: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::trait_namespace_f(&ns_pgxy, &fn_definition_f_31659)))
                                }))
                            }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
                        }), move |each_31618: Array<Text>| {
                            let in_trait_ph = each_31618;
                            crate::prelude::call_value(crate::prelude::each_job(i_p1x.methods_p.clone(), {
                                let ns_pgx = ns_pg.clone();
                                let cp_p0xx = cp_p0x.clone();
                                let i_p1xx = i_p1x.clone();
                                Rc::new(move |p0: crate::lower::model::FnDef| {
                                    let ns_pgxy = ns_pgx.clone();
                                    let cp_p0xxy = cp_p0xx.clone();
                                    let i_p1xxy = i_p1xx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let f_pl = p0;
                                        crate::prelude::call_then(start_fn_signature_f(cp_p0xxy.clone(), with_generics_f(&f_pl, &i_p1xxy.generics_p)), move |fn_signature_f_31773: Text| prism_rtl::Turn::Finished(crate::emit::cpp::templates::items::trait_namespace_f(&ns_pgxy, &Text::from(format!("{};", &fn_signature_f_31773)))))
                                    }))
                                }) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>
                            }), move |each_31731: Array<Text>| {
                                let protos_pi = each_31731;
                                let outer_pj = if own_pf {
                                    Array::new()
                                } else {
                                    Array::from(vec![crate::emit::cpp::templates::items::trait_namespace_f(&tr_pe, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&i_p1x.methods_p, &(|f_pm: &crate::lower::model::FnDef| Text::from(format!("using ::crate::{}::{}::{};", &cp_p0x.home_p, &ns_pg, &crate::emit::cpp::cpp_id_f(&f_pm.name_p))))), &Text::lit("\n")))])
                                };
                                prism_rtl::Turn::Finished({
                                    let mut this: Parts = protos_defs_f(&protos_pi, &in_trait_ph);
                                    this.outer_p = outer_pj.clone();
                                    this
                                })
                            })
                        })
                    },
                    _ => unreachable!("no arm matched"),
                }
            })
        })
    }
}

/// `Start ImplParts, x`: what the function value is when passed to `@Run`.
pub fn start_impl_parts_f(cp_p0: crate::emit::cpp::Cp, i_p1: crate::lower::model::ImplDef) -> Rc<dyn prism_rtl::Job<Parts>> {
    Rc::new(ImplParts { cp_p0, i_p1 })
}

/// ```prism
/// WithGenerics: fn FnDef, [((Text, [Text]))] -> FnDef
/// ```
pub fn with_generics_f(f_p0: &crate::lower::model::FnDef, gs_p1: &Array<(Text, Array<Text>)>) -> crate::lower::model::FnDef {
    let mut this: crate::lower::model::FnDef = f_p0.clone();
    this.generics_p = crate::prelude::append(gs_p1, &this.generics_p);
    this
}

/// ```prism
/// GenericOnly: fn [Text] -> Parts
/// ```
pub fn generic_only_f(xs_p0: &Array<Text>) -> Parts {
    let mut this: Parts = no_parts_p();
    this.generic_p = xs_p0.clone();
    this
}

/// ```prism
/// ProtosDefs: fn [Text], [Text] -> Parts
/// ```
pub fn protos_defs_f(ps_p0: &Array<Text>, ds_p1: &Array<Text>) -> Parts {
    let mut this: Parts = no_parts_p();
    this.protos_p = ps_p0.clone();
    this.defs_p = ds_p1.clone();
    this
}
