//! The module `Emit.Cpp.Templates`, from `target/bootstrap/src/prismc/emit/cpp/templates/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod items;

/// ```prism
/// CppMakefile: fn Text, Text, Text, Text -> Text
/// ```
pub fn cpp_makefile(name: &Text, runtime: &Text, sources: &Text, canvas: &Text) -> Text {
    let mut out = String::new();
    out.push_str("# Emitted by prismc. Edit the Prism sources, not this file.\n#   make                   the program, with $(CXX) (g++ by default)\n#   make CXX=clang++\n.DEFAULT_GOAL := ");
    place(&mut out, name, None);
    out.push_str("\n# The repository root: PRISM_ROOT from the environment (the prism script and the bootstrap\n# export their own location), else from this Makefile\'s path, which keeps a symlinked\n# build directory\'s logical path where `make -C`\'s current directory would not.\nHERE := $(patsubst %/,%,$(dir $(abspath $(lastword $(MAKEFILE_LIST)))))\nPRISM_ROOT ?= $(if $(filter /%,");
    place(&mut out, runtime, None);
    out.push_str("),");
    place(&mut out, runtime, None);
    out.push_str(",$(abspath $(HERE)/");
    place(&mut out, runtime, None);
    out.push_str("))\nRT := $(PRISM_ROOT)/runtime/cpp\nWORLD := $(PRISM_ROOT)/worlds/cli/cpp\nCXX ?= g++\nOPT ?= -O3\nCONFIG ?= prog-$(notdir $(CXX))$(subst $() ,,$(OPT))\nLIB := $(RT)/build/$(CONFIG)/libprism_rtl.a\nFLAGS := -std=gnu++20 $(OPT) -I$(RT)/include -I$(WORLD)/include -Isrc -Wall -Wno-unused -Wno-unused-parameter -Wno-unused-label\nSRCS := src/main.cpp ");
    place(&mut out, sources, None);
    out.push_str("\nOBJS := $(SRCS:src/%.cpp=build/%.o)\nWORLD_LIBS :=\nSYS_LIBS :=\n# The runtime\'s regular expressions are on RE2 (runtime/cpp/README.md), which the library\n# needs at link time whenever a program reaches them.\nRE2_LIBS := $(shell pkg-config --libs re2)\n");
    place(&mut out, canvas, Some(0));
    out.push_str("\n");
    place(&mut out, name, None);
    out.push_str(": $(OBJS) build/cli.o $(LIB) $(WORLD_LIBS)\n\t$(CXX) $(FLAGS) -o $@ $(OBJS) build/cli.o $(WORLD_LIBS) $(LIB) $(RE2_LIBS) $(SYS_LIBS)\n\nbuild/cli.o: $(WORLD)/src/cli.cpp $(WORLD)/include/prism_world_cli/cli.hpp\n\t@mkdir -p build\n\t$(CXX) $(FLAGS) -c $< -o $@\n\nbuild/%.o: src/%.cpp\n\t@mkdir -p $(dir $@)\n\t$(CXX) $(FLAGS) -MMD -MP -c $< -o $@\n\n-include $(OBJS:.o=.d)\n\n$(LIB): FORCE\n\t@$(MAKE) -s -C $(RT) lib CXX=$(CXX) CONFIG=$(CONFIG) OPT=\"$(OPT)\"\n\nFORCE:\n.PHONY: FORCE\n");
    Text::from(out)
}

/// ```prism
/// CppMakefileCanvas: fn Text -> Text
/// ```
pub fn cpp_makefile_canvas(runtime: &Text) -> Text {
    let mut out = String::new();
    out.push_str("CANVAS := $(PRISM_ROOT)/worlds/canvas/cpp\nFLAGS += -I$(CANVAS)/include $(shell pkg-config --cflags cairo freetype2)\nWORLD_LIBS := $(CANVAS)/build/$(CONFIG)/libprism_world_canvas.a\nifeq ($(shell uname -s),Darwin)\nSYS_LIBS := $(shell pkg-config --libs cairo freetype2) -framework Cocoa -framework QuartzCore\nelse\nSYS_LIBS := $(shell pkg-config --libs cairo freetype2 x11 xext)\nendif\n\n$(WORLD_LIBS): FORCE | $(LIB)\n\t@$(MAKE) -s -C $(CANVAS) lib CXX=$(CXX) CONFIG=$(CONFIG) OPT=\"$(OPT)\"\n");
    Text::from(out)
}

/// ```prism
/// CppDeclHeader: fn Text, Text, Text, Text -> Text
/// ```
pub fn cpp_decl_header(title: &Text, includes: &Text, forward: &Text, handles: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// ");
    place(&mut out, title, None);
    out.push_str(": its types, nodes and jobs declared, and its choices\' handles, emitted by\n// prismc (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n#include \"prelude.hpp\"\n");
    place(&mut out, includes, Some(0));
    out.push_str("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(&mut out, forward, Some(0));
    out.push_str("\n");
    place(&mut out, handles, Some(0));
    out.push_str("\n}  // namespace crate\n");
    Text::from(out)
}

/// ```prism
/// CppTypesHeader: fn Text, Text, Text, Text -> Text
/// ```
pub fn cpp_types_header(title: &Text, includes: &Text, values_: &Text, cases: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// ");
    place(&mut out, title, None);
    out.push_str(": its records, tags and newtypes (each after the types it holds) and its\n// choices\' cases, emitted by prismc (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n");
    place(&mut out, includes, Some(0));
    out.push_str("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(&mut out, values_, Some(0));
    out.push_str("\n");
    place(&mut out, cases, Some(0));
    out.push_str("\n}  // namespace crate\n");
    Text::from(out)
}

/// ```prism
/// CppTypesInGroup: fn Text, Text -> Text
/// ```
pub fn cpp_types_in_group(title: &Text, group: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// ");
    place(&mut out, title, None);
    out.push_str(": its records, tags and newtypes and its choices\' cases are defined with those\n// of the modules whose types it holds by value and which hold its own, in `");
    place(&mut out, group, None);
    out.push_str(".types.hpp`,\n// emitted by prismc (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n#include <");
    place(&mut out, group, None);
    out.push_str(".types.hpp>\n");
    Text::from(out)
}

/// ```prism
/// CppModHeader: fn Text, Text, Text, Text, Text -> Text
/// ```
pub fn cpp_mod_header(title: &Text, includes: &Text, protos: &Text, outer: &Text, classes: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// ");
    place(&mut out, title, None);
    out.push_str(": its functions\' prototypes and its nodes and jobs, emitted by prismc\n// (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n");
    place(&mut out, includes, Some(0));
    out.push_str("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(&mut out, protos, Some(0));
    out.push_str("\n");
    place(&mut out, outer, Some(0));
    out.push_str("\n");
    place(&mut out, classes, Some(0));
    out.push_str("\n}  // namespace crate\n");
    Text::from(out)
}

/// ```prism
/// CppGenericHeader: fn Text, Text, Text -> Text
/// ```
pub fn cpp_generic_header(title: &Text, includes: &Text, generic: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// ");
    place(&mut out, title, None);
    out.push_str(": its generic functions\' and types\' definitions, emitted by prismc\n// (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n");
    place(&mut out, includes, Some(0));
    out.push_str("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(&mut out, generic, Some(0));
    out.push_str("\n}  // namespace crate\n");
    Text::from(out)
}

/// ```prism
/// CppElemDecl: fn Text, Text, Text, Text -> Text
/// ```
pub fn cpp_elem_decl(includes: &Text, forward: &Text, handles: &Text, rows: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// The program\'s `Elem` and `Answer` declared, their handles, and the prelude\'s rows,\n// emitted by prismc (claude/backend.md). Edit the Prism sources, not this file.\n#pragma once\n\n#include \"prelude.hpp\"\n");
    place(&mut out, includes, Some(0));
    out.push_str("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(&mut out, forward, Some(0));
    out.push_str("\n");
    place(&mut out, handles, Some(0));
    out.push_str("\nnamespace prelude {\n\n");
    place(&mut out, rows, Some(0));
    out.push_str("\n}  // namespace prelude\n\n}  // namespace crate\n");
    Text::from(out)
}

/// ```prism
/// CppElemTypes: fn Text, Text -> Text
/// ```
pub fn cpp_elem_types(includes: &Text, cases: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// The cases of the program\'s `Elem` and `Answer`, emitted by prismc (claude/backend.md).\n// Edit the Prism sources, not this file.\n#pragma once\n\n#include \"elem.decl.hpp\"\n");
    place(&mut out, includes, Some(0));
    out.push_str("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(&mut out, cases, Some(0));
    out.push_str("\n}  // namespace crate\n");
    Text::from(out)
}

/// ```prism
/// CppModule: fn Text, Text, Text, Text, Text -> Text
/// ```
pub fn cpp_module(prism: &Text, path_: &Text, ns: &Text, includes: &Text, defs: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// ");
    place(&mut out, prism, None);
    out.push_str(", from `");
    place(&mut out, path_, None);
    out.push_str("`, emitted by prismc: its functions, its nodes\' methods, its\n// types\' printers (claude/backend.md). Edit the Prism source, not this file.\n");
    place(&mut out, includes, Some(0));
    out.push_str("\nnamespace crate::");
    place(&mut out, ns, None);
    out.push_str(" {\n\n");
    place(&mut out, defs, Some(0));
    out.push_str("\n}  // namespace crate::");
    place(&mut out, ns, None);
    out.push_str("\n");
    Text::from(out)
}

/// ```prism
/// CppProgramsHeader: fn Text, Text, Text -> Text
/// ```
pub fn cpp_programs_header(name: &Text, includes: &Text, programs: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// The programs of `");
    place(&mut out, name, None);
    out.push_str("`, emitted by prismc (claude/backend.md): each root\'s class, over\n// every module\'s header. Edit the Prism sources, not this file.\n#pragma once\n\n");
    place(&mut out, includes, Some(0));
    out.push_str("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(&mut out, programs, Some(0));
    out.push_str("\n}  // namespace crate\n");
    Text::from(out)
}

/// ```prism
/// CppMain: fn Text, Text, Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn cpp_main(name: &Text, includes: &Text, registrations: &Text, checks: &Text, scripts: &Text, world: &Text, run_root: &Text, crate_defs: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// The program `");
    place(&mut out, name, None);
    out.push_str("`, emitted by prismc from Prism (claude/backend.md): C++ over\n// `prism_rtl`, run under the Test World. Edit the Prism sources, not these files.\n");
    place(&mut out, includes, Some(0));
    out.push_str("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(&mut out, crate_defs, Some(0));
    out.push_str("\n/// The Test World with every root a test names, and the compiled `check` blocks.\nTestWorld test_world() {\n    TestWorld world;\n    world");
    place(&mut out, registrations, None);
    place(&mut out, checks, None);
    out.push_str(";\n    return world;\n}\n\n/// The test scripts compiled with the program: `test` runs these when given none.\nconst std::vector<std::string> SCRIPTS = {\n");
    place(&mut out, scripts, Some(4));
    out.push_str("};\n\n/// The World the root\'s row asks for: `canvas`, `cli`, or `none` (a row with `Ui` and no\n/// `Gui`, which no World answers).\nconst std::string WORLD = \"");
    place(&mut out, world, None);
    out.push_str("\";\n\n/// The root under the World `world`.\nint run_root(const std::string& world, const std::vector<std::string>& args) {\n");
    place(&mut out, run_root, Some(4));
    out.push_str("}\n\n}  // namespace crate\n\nint main(int argc, char** argv) {\n    std::vector<std::string> args(argv + 1, argv + argc);\n    // The canvas World keeps the main thread for its windows (AppKit\'s rule on macOS) and\n    // ticks on a big stack of its own.\n    if (auto [world, rest] = crate::prelude::world_option(args, crate::WORLD); world == \"canvas\" && (args.empty() || args[0] != \"test\"))\n        return crate::run_root(world, rest);\n    return crate::prelude::on_big_stack([&] {\n        auto [world, rest] = crate::prelude::world_option(args, crate::WORLD);\n        if ((!args.empty() && args[0] == \"test\") || world == \"test\") {\n            std::vector<std::string> scripts;\n            for (const auto& a : rest)\n                if (a != \"test\") scripts.push_back(a);\n            return crate::prelude::run_scripts(crate::test_world(), scripts, crate::SCRIPTS);\n        }\n        return crate::run_root(world, rest);\n    });\n}\n");
    Text::from(out)
}

/// ```prism
/// CppNoRoot: fn Text -> Text
/// ```
pub fn cpp_no_root(name: &Text) -> Text {
    let mut out = String::new();
    out.push_str("static_cast<void>(world);\nstatic_cast<void>(args);\nstd::fprintf(stderr, \"");
    place(&mut out, name, None);
    out.push_str(": the program has no `@main`; `");
    place(&mut out, name, None);
    out.push_str(" test` runs its tests\\n\");\nreturn 2;\n");
    Text::from(out)
}

/// ```prism
/// CppRunRoot: fn Text, Text -> Text
/// ```
pub fn cpp_run_root(program: &Text, canvas: &Text) -> Text {
    let mut out = String::new();
    out.push_str("if (world == \"cli\") return crate::prelude::run_cli<");
    place(&mut out, program, None);
    out.push_str(">(args);\nif (world == \"canvas\") {\n");
    place(&mut out, canvas, Some(4));
    out.push_str("}\nif (world == \"none\") {\n    std::fprintf(stderr, \"the root\'s row has Ui.* without Gui.*: no World answers Ui elements alone; emit Gui.* for the canvas World, or pass --world\\n\");\n    return 2;\n}\nstd::fprintf(stderr, \"no World %s (cli, canvas, test)\\n\", world.c_str());\nreturn 2;\n");
    Text::from(out)
}

/// ```prism
/// CppCanvasRun: fn Text -> Text
/// ```
pub fn cpp_canvas_run(program: &Text) -> Text {
    let mut out = String::new();
    out.push_str("static_cast<void>(args);\nreturn prism_world_canvas::run<");
    place(&mut out, program, None);
    out.push_str(">();\n");
    Text::from(out)
}

/// ```prism
/// CppNoCanvas: fn Text -> Text
/// ```
pub fn cpp_no_canvas(program: &Text) -> Text {
    let mut out = String::new();
    out.push_str("std::fprintf(stderr, \"the root\'s row emits no Gui.*, so this program is built without the canvas World\\n\");\nreturn 2;\n");
    Text::from(out)
}

/// ```prism
/// CppCanvasInclude: fn Text -> Text
/// ```
pub fn cpp_canvas_include(text0: &Text) -> Text {
    match text0 {
        _ => {
            let mut out = String::new();
            out.push_str("#include \"prism_world_canvas/canvas.hpp\"\n");
            Text::from(out)
        },
    }
}
