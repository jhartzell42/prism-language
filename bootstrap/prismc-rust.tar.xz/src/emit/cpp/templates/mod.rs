//! The module `Emit.Cpp.Templates`, from `target/bootstrap/src/prismc/emit/cpp/templates/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod items;

/// ```prism
/// CppMakefile: fn Text, Text, Text, Text -> Text
/// ```
pub fn cpp_makefile(name_p0: &Text, runtime_p1: &Text, sources_p2: &Text, canvas_p3: &Text) -> Text {
    let mut out = String::new();
    out.push_str("# Emitted by prismc. Edit the Prism sources, not this file.\n#   make                   the program, with $(CXX) (g++ by default)\n#   make CXX=clang++\n.DEFAULT_GOAL := ");
    place(&mut out, name_p0, None);
    out.push_str("\n# The repository root: PRISM_ROOT from the environment (the prism script and the bootstrap\n# export their own location), else from this Makefile\'s path, which keeps a symlinked\n# build directory\'s logical path where `make -C`\'s current directory would not.\nHERE := $(patsubst %/,%,$(dir $(abspath $(lastword $(MAKEFILE_LIST)))))\nPRISM_ROOT ?= $(if $(filter /%,");
    place(&mut out, runtime_p1, None);
    out.push_str("),");
    place(&mut out, runtime_p1, None);
    out.push_str(",$(abspath $(HERE)/");
    place(&mut out, runtime_p1, None);
    out.push_str("))\nRT := $(PRISM_ROOT)/runtime/cpp\nWORLD := $(PRISM_ROOT)/worlds/cli/cpp\nCXX ?= g++\nOPT ?= -O3\nCONFIG ?= prog-$(notdir $(CXX))$(subst $() ,,$(OPT))\nLIB := $(RT)/build/$(CONFIG)/libprism_rtl.a\nFLAGS := -std=gnu++20 $(OPT) -I$(RT)/include -I$(WORLD)/include -Isrc -Wall -Wno-unused -Wno-unused-parameter -Wno-unused-label\nSRCS := src/main.cpp ");
    place(&mut out, sources_p2, None);
    out.push_str("\nOBJS := $(SRCS:src/%.cpp=build/%.o)\nWORLD_LIBS :=\nSYS_LIBS :=\n# The runtime\'s regular expressions are on RE2 (runtime/cpp/README.md), which the library\n# needs at link time whenever a program reaches them.\nRE2_LIBS := $(shell pkg-config --libs re2)\n# The allocator is jemalloc, found with pkg-config (runtime/cpp/README.md, pick AL); a\n# sanitizer build (`-fsanitize` in OPT, prism\'s PRISM_SANITIZE) keeps the C library\'s,\n# which AddressSanitizer replaces with its own.\nifeq ($(findstring -fsanitize,$(OPT)),)\nifneq ($(shell pkg-config --exists jemalloc && echo found),found)\n$(error the C++ program links jemalloc, found with pkg-config, and pkg-config does not find it: apt install libjemalloc-dev pkg-config (Debian, Ubuntu), brew install jemalloc (macOS))\nendif\nALLOC_LIBS := $(shell pkg-config --libs jemalloc)\nelse\nALLOC_LIBS :=\nendif\n");
    place(&mut out, canvas_p3, Some(0));
    out.push_str("\n");
    place(&mut out, name_p0, None);
    out.push_str(": $(OBJS) build/cli.o $(LIB) $(WORLD_LIBS)\n\t$(CXX) $(FLAGS) -o $@ $(OBJS) build/cli.o $(WORLD_LIBS) $(LIB) $(RE2_LIBS) $(SYS_LIBS) $(ALLOC_LIBS)\n\nbuild/cli.o: $(WORLD)/src/cli.cpp $(WORLD)/include/prism_world_cli/cli.hpp\n\t@mkdir -p build\n\t$(CXX) $(FLAGS) -c $< -o $@\n\nbuild/%.o: src/%.cpp\n\t@mkdir -p $(dir $@)\n\t$(CXX) $(FLAGS) -MMD -MP -c $< -o $@\n\n-include $(OBJS:.o=.d)\n\n$(LIB): FORCE\n\t@$(MAKE) -s -C $(RT) lib CXX=$(CXX) CONFIG=$(CONFIG) OPT=\"$(OPT)\"\n\nFORCE:\n.PHONY: FORCE\n");
    Text::from(out)
}

/// ```prism
/// CppMakefileCanvas: fn Text -> Text
/// ```
pub fn cpp_makefile_canvas(runtime_p0: &Text) -> Text {
    let mut out = String::new();
    out.push_str("CANVAS := $(PRISM_ROOT)/worlds/canvas/cpp\nFLAGS += -I$(CANVAS)/include $(shell pkg-config --cflags cairo freetype2)\nWORLD_LIBS := $(CANVAS)/build/$(CONFIG)/libprism_world_canvas.a\nifeq ($(shell uname -s),Darwin)\nSYS_LIBS := $(shell pkg-config --libs cairo freetype2) -framework Cocoa -framework QuartzCore\nelse\nSYS_LIBS := $(shell pkg-config --libs cairo freetype2 x11 xext)\nendif\n\n$(WORLD_LIBS): FORCE | $(LIB)\n\t@$(MAKE) -s -C $(CANVAS) lib CXX=$(CXX) CONFIG=$(CONFIG) OPT=\"$(OPT)\"\n");
    Text::from(out)
}

/// ```prism
/// CppDeclHeader: fn Text, Text, Text -> Text
/// ```
pub fn cpp_decl_header(title_p0: &Text, includes_p1: &Text, forward_p2: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// ");
    place(&mut out, title_p0, None);
    out.push_str(": its types, nodes and jobs declared, emitted by prismc (claude/backend.md).\n// Edit the Prism source, not this file.\n#pragma once\n\n#include \"prelude.hpp\"\n");
    place(&mut out, includes_p1, Some(0));
    out.push_str("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(&mut out, forward_p2, Some(0));
    out.push_str("\n}  // namespace crate\n");
    Text::from(out)
}

/// ```prism
/// CppTypesHeader: fn Text, Text, Text -> Text
/// ```
pub fn cpp_types_header(title_p0: &Text, includes_p1: &Text, values_p2: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// ");
    place(&mut out, title_p0, None);
    out.push_str(": its value types (records, tags, newtypes and choices with their cases), each\n// after the types it holds by value, emitted by prismc (claude/backend.md). Edit the Prism\n// source, not this file.\n#pragma once\n\n");
    place(&mut out, includes_p1, Some(0));
    out.push_str("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(&mut out, values_p2, Some(0));
    out.push_str("\n}  // namespace crate\n");
    Text::from(out)
}

/// ```prism
/// CppTypesInGroup: fn Text, Text -> Text
/// ```
pub fn cpp_types_in_group(title_p0: &Text, group_p1: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// ");
    place(&mut out, title_p0, None);
    out.push_str(": its records, tags and newtypes and its choices\' cases are defined with those\n// of the modules whose types it holds by value and which hold its own, in `");
    place(&mut out, group_p1, None);
    out.push_str(".types.hpp`,\n// emitted by prismc (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n#include <");
    place(&mut out, group_p1, None);
    out.push_str(".types.hpp>\n");
    Text::from(out)
}

/// ```prism
/// CppModHeader: fn Text, Text, Text, Text, Text -> Text
/// ```
pub fn cpp_mod_header(title_p0: &Text, includes_p1: &Text, protos_p2: &Text, outer_p3: &Text, classes_p4: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// ");
    place(&mut out, title_p0, None);
    out.push_str(": its functions\' prototypes and its nodes and jobs, emitted by prismc\n// (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n");
    place(&mut out, includes_p1, Some(0));
    out.push_str("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(&mut out, protos_p2, Some(0));
    out.push_str("\n");
    place(&mut out, outer_p3, Some(0));
    out.push_str("\n");
    place(&mut out, classes_p4, Some(0));
    out.push_str("\n}  // namespace crate\n");
    Text::from(out)
}

/// ```prism
/// CppGenericHeader: fn Text, Text, Text -> Text
/// ```
pub fn cpp_generic_header(title_p0: &Text, includes_p1: &Text, generic_p2: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// ");
    place(&mut out, title_p0, None);
    out.push_str(": its generic functions\' and types\' definitions, emitted by prismc\n// (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n");
    place(&mut out, includes_p1, Some(0));
    out.push_str("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(&mut out, generic_p2, Some(0));
    out.push_str("\n}  // namespace crate\n");
    Text::from(out)
}

/// ```prism
/// CppElemDecl: fn Text, Text, Text -> Text
/// ```
pub fn cpp_elem_decl(includes_p0: &Text, forward_p1: &Text, rows_p2: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// The program\'s `Elem` and `Answer` declared, and the prelude\'s rows, emitted by prismc\n// (claude/backend.md). Edit the Prism sources, not this file.\n#pragma once\n\n#include \"prelude.hpp\"\n");
    place(&mut out, includes_p0, Some(0));
    out.push_str("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(&mut out, forward_p1, Some(0));
    out.push_str("\nnamespace prelude {\n\n");
    place(&mut out, rows_p2, Some(0));
    out.push_str("\n}  // namespace prelude\n\n}  // namespace crate\n");
    Text::from(out)
}

/// ```prism
/// CppElemTypes: fn Text, Text -> Text
/// ```
pub fn cpp_elem_types(includes_p0: &Text, values_p1: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// The program\'s `Elem` and `Answer` with their cases, emitted by prismc (claude/backend.md).\n// Edit the Prism sources, not this file.\n#pragma once\n\n#include \"elem.decl.hpp\"\n");
    place(&mut out, includes_p0, Some(0));
    out.push_str("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(&mut out, values_p1, Some(0));
    out.push_str("\n}  // namespace crate\n");
    Text::from(out)
}

/// ```prism
/// CppUnit: fn Text, Text, Text -> Text
/// ```
pub fn cpp_unit(title_p0: &Text, includes_p1: &Text, parts_p2: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// ");
    place(&mut out, title_p0, None);
    out.push_str(", emitted by prismc: the functions, nodes\' methods and types\' printers\n// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this\n// file.\n");
    place(&mut out, includes_p1, Some(0));
    out.push_str("\n");
    place(&mut out, parts_p2, Some(0));
    Text::from(out)
}

/// ```prism
/// CppUnitPart: fn Text, Text, Text, Text -> Text
/// ```
pub fn cpp_unit_part(prism_p0: &Text, path_p1: &Text, ns_p2: &Text, defs_p3: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// ");
    place(&mut out, prism_p0, None);
    out.push_str(", from `");
    place(&mut out, path_p1, None);
    out.push_str("`.\nnamespace crate::");
    place(&mut out, ns_p2, None);
    out.push_str(" {\n\n");
    place(&mut out, defs_p3, Some(0));
    out.push_str("\n}  // namespace crate::");
    place(&mut out, ns_p2, None);
    out.push_str("\n");
    Text::from(out)
}

/// ```prism
/// CppProgramsHeader: fn Text, Text, Text -> Text
/// ```
pub fn cpp_programs_header(name_p0: &Text, includes_p1: &Text, programs_p2: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// The programs of `");
    place(&mut out, name_p0, None);
    out.push_str("`, emitted by prismc (claude/backend.md): each root\'s class, over\n// every module\'s header. Edit the Prism sources, not this file.\n#pragma once\n\n");
    place(&mut out, includes_p1, Some(0));
    out.push_str("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(&mut out, programs_p2, Some(0));
    out.push_str("\n}  // namespace crate\n");
    Text::from(out)
}

/// ```prism
/// CppMain: fn Text, Text, Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn cpp_main(name_p0: &Text, includes_p1: &Text, registrations_p2: &Text, checks_p3: &Text, scripts_p4: &Text, world_p5: &Text, run_root_p6: &Text, crate_defs_p7: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// The program `");
    place(&mut out, name_p0, None);
    out.push_str("`, emitted by prismc from Prism (claude/backend.md): C++ over\n// `prism_rtl`, run under the Test World. Edit the Prism sources, not these files.\n");
    place(&mut out, includes_p1, Some(0));
    out.push_str("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(&mut out, crate_defs_p7, Some(0));
    out.push_str("\n/// The Test World with every root a test names, and the compiled `check` blocks.\nTestWorld test_world() {\n    TestWorld world;\n    world");
    place(&mut out, registrations_p2, None);
    place(&mut out, checks_p3, None);
    out.push_str(";\n    return world;\n}\n\n/// The test scripts compiled with the program: `test` runs these when given none.\nconst std::vector<std::string> SCRIPTS = {\n");
    place(&mut out, scripts_p4, Some(4));
    out.push_str("};\n\n/// The World the root\'s row asks for: `canvas`, `cli`, or `none` (a row with `Ui` and no\n/// `Gui`, which no World answers).\nconst std::string WORLD = \"");
    place(&mut out, world_p5, None);
    out.push_str("\";\n\n/// The root under the World `world`.\nint run_root(const std::string& world, const std::vector<std::string>& args) {\n");
    place(&mut out, run_root_p6, Some(4));
    out.push_str("}\n\n}  // namespace crate\n\nint main(int argc, char** argv) {\n    std::vector<std::string> args(argv + 1, argv + argc);\n    // The canvas World keeps the main thread for its windows (AppKit\'s rule on macOS) and\n    // ticks on a big stack of its own.\n    if (auto [world, rest] = crate::prelude::world_option(args, crate::WORLD); world == \"canvas\" && (args.empty() || args[0] != \"test\"))\n        return crate::run_root(world, rest);\n    return crate::prelude::on_big_stack([&] {\n        auto [world, rest] = crate::prelude::world_option(args, crate::WORLD);\n        if ((!args.empty() && args[0] == \"test\") || world == \"test\") {\n            std::vector<std::string> scripts;\n            for (const auto& a : rest)\n                if (a != \"test\") scripts.push_back(a);\n            return crate::prelude::run_scripts(crate::test_world(), scripts, crate::SCRIPTS);\n        }\n        return crate::run_root(world, rest);\n    });\n}\n");
    Text::from(out)
}

/// ```prism
/// CppNoRoot: fn Text -> Text
/// ```
pub fn cpp_no_root(name_p0: &Text) -> Text {
    let mut out = String::new();
    out.push_str("static_cast<void>(world);\nstatic_cast<void>(args);\nstd::fprintf(stderr, \"");
    place(&mut out, name_p0, None);
    out.push_str(": the program has no `@main`; `");
    place(&mut out, name_p0, None);
    out.push_str(" test` runs its tests\\n\");\nreturn 2;\n");
    Text::from(out)
}

/// ```prism
/// CppRunRoot: fn Text, Text -> Text
/// ```
pub fn cpp_run_root(program_p0: &Text, canvas_p1: &Text) -> Text {
    let mut out = String::new();
    out.push_str("if (world == \"cli\") return crate::prelude::run_cli<");
    place(&mut out, program_p0, None);
    out.push_str(">(args);\nif (world == \"canvas\") {\n");
    place(&mut out, canvas_p1, Some(4));
    out.push_str("}\nif (world == \"none\") {\n    std::fprintf(stderr, \"the root\'s row has Ui.* without Gui.*: no World answers Ui elements alone; emit Gui.* for the canvas World, or pass --world\\n\");\n    return 2;\n}\nstd::fprintf(stderr, \"no World %s (cli, canvas, test)\\n\", world.c_str());\nreturn 2;\n");
    Text::from(out)
}

/// ```prism
/// CppCanvasRun: fn Text -> Text
/// ```
pub fn cpp_canvas_run(program_p0: &Text) -> Text {
    let mut out = String::new();
    out.push_str("static_cast<void>(args);\nreturn prism_world_canvas::run<");
    place(&mut out, program_p0, None);
    out.push_str(">();\n");
    Text::from(out)
}

/// ```prism
/// CppNoCanvas: fn Text -> Text
/// ```
pub fn cpp_no_canvas(program_p0: &Text) -> Text {
    let mut out = String::new();
    out.push_str("std::fprintf(stderr, \"the root\'s row emits no Gui.*, so this program is built without the canvas World\\n\");\nreturn 2;\n");
    Text::from(out)
}

/// ```prism
/// CppCanvasInclude: fn Text -> Text
/// ```
pub fn cpp_canvas_include(text0: &Text) -> Text {
    match text0 {
        _ => {
            let mut out = String::new();
            out.push_str("#include \"prism_world_canvas/canvas.hpp\"\n");
            Text::from(out)
        },
    }
}
