//! The module `Emit.Cpp.Templates.Items`, from `target/bootstrap/src/prismc/emit/cpp/templates/items.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// ChoiceClass: fn Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn choice_class(doc: &Text, gens: &Text, name: &Text, cases: &Text, names: &Text, members: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, doc, Some(0));
    place(&mut out, gens, None);
    out.push_str("class ");
    place(&mut out, name, None);
    out.push_str(" {\npublic:\n    using prism_value = void;\n");
    place(&mut out, cases, Some(4));
    out.push_str("    using Cases = std::variant<");
    place(&mut out, names, None);
    out.push_str(">;\n    template <class C>\n        requires prism_rtl::one_of<C, ");
    place(&mut out, names, None);
    out.push_str(">\n    ");
    place(&mut out, name, None);
    out.push_str("(C c) : cases_(std::move(c)) {}\n    const Cases& cases() const { return cases_; }\n");
    place(&mut out, members, Some(4));
    out.push_str("\nprivate:\n    Cases cases_;\n};\n");
    Text::from(out)
}

/// ```prism
/// CaseDecl: fn Text, Text -> Text
/// ```
pub fn case_decl(name: &Text, fields: &Text) -> Text {
    let mut out = String::new();
    out.push_str("struct ");
    place(&mut out, name, None);
    out.push_str(" {\n");
    place(&mut out, fields, Some(4));
    out.push_str("};\n");
    Text::from(out)
}

/// ```prism
/// ValueStruct: fn Text, Text, Text, Text, Text -> Text
/// ```
pub fn value_struct(doc: &Text, gens: &Text, name: &Text, fields: &Text, members: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, doc, Some(0));
    place(&mut out, gens, None);
    out.push_str("struct ");
    place(&mut out, name, None);
    out.push_str(" {\n    using prism_value = void;\n");
    place(&mut out, fields, Some(4));
    out.push_str("    const ");
    place(&mut out, name, None);
    out.push_str("* operator->() const { return this; }\n    ");
    place(&mut out, name, None);
    out.push_str("* operator->() { return this; }\n");
    place(&mut out, members, Some(4));
    out.push_str("};\n");
    Text::from(out)
}

/// ```prism
/// CppTagStruct: fn Text, Text, Text, Text, Text -> Text
/// ```
pub fn cpp_tag_struct(doc: &Text, name: &Text, fields: &Text, tag_name: &Text, members: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, doc, Some(0));
    out.push_str("struct ");
    place(&mut out, name, None);
    out.push_str(" {\n    using prism_value = void;\n    /// The tag\'s qualified name, as its `Pod` carries it.\n    static constexpr const char* TAG = \"");
    place(&mut out, tag_name, None);
    out.push_str("\";\n");
    place(&mut out, fields, Some(4));
    out.push_str("    const ");
    place(&mut out, name, None);
    out.push_str("* operator->() const { return this; }\n    ");
    place(&mut out, name, None);
    out.push_str("* operator->() { return this; }\n    Pod to_pod() const;\n    void show(Printer& p) const;\n");
    place(&mut out, members, Some(4));
    out.push_str("};\n");
    Text::from(out)
}

/// ```prism
/// CppFunction: fn Text, Text, Text -> Text
/// ```
pub fn cpp_function(doc: &Text, signature: &Text, body: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, doc, Some(0));
    place(&mut out, signature, None);
    out.push_str(" {\n");
    place(&mut out, body, Some(4));
    out.push_str("}\n");
    Text::from(out)
}

/// ```prism
/// JobStruct: fn Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn job_struct(doc: &Text, gens: &Text, name: &Text, ret: &Text, fields: &Text, ctor: &Text) -> Text {
    let mut out = String::new();
    out.push_str("/// The step machine of `");
    place(&mut out, name, None);
    out.push_str("`, stopped at a cycle point: the call about to be\n/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the\n/// callee\'s job, so the job\'s stack is its frames.\n///\n");
    place(&mut out, doc, Some(0));
    place(&mut out, gens, None);
    out.push_str("struct ");
    place(&mut out, name, None);
    out.push_str(" : prism_rtl::Job<");
    place(&mut out, ret, None);
    out.push_str("> {\n");
    place(&mut out, fields, Some(4));
    place(&mut out, ctor, Some(4));
    out.push_str("    prism_rtl::Turn<");
    place(&mut out, ret, None);
    out.push_str("> cycle() const override;\n};\n");
    Text::from(out)
}

/// ```prism
/// TraitNamespace: fn Text, Text -> Text
/// ```
pub fn trait_namespace(name: &Text, body: &Text) -> Text {
    let mut out = String::new();
    out.push_str("namespace ");
    place(&mut out, name, None);
    out.push_str(" {\n");
    place(&mut out, body, Some(0));
    out.push_str("}  // namespace ");
    place(&mut out, name, None);
    Text::from(out)
}

/// ```prism
/// NodeClass: fn Text, Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn node_class(doc: &Text, name: &Text, base: &Text, fields: &Text, consts: &Text, ctor: &Text, decls: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, doc, Some(0));
    out.push_str("class ");
    place(&mut out, name, None);
    out.push_str(" : public ");
    place(&mut out, base, None);
    out.push_str(" {\npublic:\n    Path path;\n");
    place(&mut out, fields, Some(4));
    place(&mut out, consts, Some(4));
    place(&mut out, ctor, Some(4));
    out.push_str("    ");
    place(&mut out, name, None);
    out.push_str("(const ");
    place(&mut out, name, None);
    out.push_str("&) = delete;\n");
    place(&mut out, decls, Some(4));
    out.push_str("};\n");
    Text::from(out)
}

/// ```prism
/// NodeMake: fn Text, Text, Text, Text, Text -> Text
/// ```
pub fn node_make(name: &Text, signature: &Text, lets: &Text, args: &Text, rest: &Text) -> Text {
    let mut out = String::new();
    out.push_str("/// Built after propagation: holds take their initial values, places go out with\n/// `cx.added`, and nothing fires.\n");
    place(&mut out, signature, None);
    out.push_str(" {\n");
    place(&mut out, lets, Some(4));
    out.push_str("    prism_rtl::RcPlace<");
    place(&mut out, name, None);
    out.push_str("> _place;\n    auto node = _place.take(new (_place.at()) ");
    place(&mut out, name, None);
    out.push_str("(");
    place(&mut out, args, None);
    out.push_str("));\n");
    place(&mut out, rest, Some(4));
    out.push_str("}\n");
    Text::from(out)
}

/// ```prism
/// ForBuildTemplate: fn Text, Text, Text, Text, Text, Text, Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn for_build_template(owner: &Text, name: &Text, at_: &Text, key_ty: &Text, value_ty: &Text, row_make: &Text, source: &Text, parent: &Text, passed: &Text, moved: &Text, from: &Text, replaced: &Text) -> Text {
    let mut out = String::new();
    out.push_str("/// The rows of the `for` at `");
    place(&mut out, at_, None);
    out.push_str("`: rows whose key left are torn down, new keys are\n/// built under it at `[k]` from the values after the tick; kept rows keep reading their\n/// entry out of the source. Nothing to do when the source is the map last built from (one\n/// node, `same`: it has the same keys; Semantics ch. 11, sharing is invisible).\nDone ");
    place(&mut out, owner, None);
    out.push_str("::");
    place(&mut out, name, None);
    out.push_str("_build(Cx& cx) {\n    Map<");
    place(&mut out, key_ty, None);
    out.push_str(", ");
    place(&mut out, value_ty, None);
    out.push_str("> items = ");
    place(&mut out, source, None);
    out.push_str("(cx);\n    if (this->");
    place(&mut out, name, None);
    out.push_str("_from.same(items)) return {};\n");
    place(&mut out, from, Some(4));
    out.push_str("    auto old = deref(this->");
    place(&mut out, name, None);
    out.push_str(");\n    // the kept rows stay where they are: only the keys that left or came are touched\n    auto next = old;\n    for (auto&& [k, row] : old) {\n        if (!items.contains(k)) {\n            row->leave_row(cx);\n            cx.leave_later(row);\n            next.remove(k);\n        }");
    place(&mut out, replaced, None);
    out.push_str("\n    }\n    for (auto&& [k, v] : items) {\n        if (!old.contains(k)) next.insert(k, TRY(");
    place(&mut out, row_make, None);
    out.push_str("(");
    place(&mut out, at_, None);
    out.push_str(".child(Segment::key(prism_rtl::to_pod(k))), k, v, ");
    place(&mut out, parent, None);
    place(&mut out, passed, None);
    out.push_str(", cx)));\n    }\n    deref(this->");
    place(&mut out, name, None);
    out.push_str(") = next;\n    // What the block reads of its rows (a `for` that gives a dynamic) moved.\n    cx.dirty(prism_rtl::share(this));");
    place(&mut out, moved, None);
    out.push_str("\n    return {};\n}\n");
    Text::from(out)
}

/// ```prism
/// GenBuildTemplate: fn Text, Text, Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn gen_build_template(owner: &Text, name: &Text, at_: &Text, path_: &Text, source: &Text, value_ty: &Text, select: &Text, moved: &Text) -> Text {
    let mut out = String::new();
    out.push_str("/// The `rebuild` at `");
    place(&mut out, at_, None);
    out.push_str("`: the old generation torn down (it ran to the end of the\n/// tick), the next built at `");
    place(&mut out, path_, None);
    out.push_str("` from the source after the tick.\nDone ");
    place(&mut out, owner, None);
    out.push_str("::");
    place(&mut out, name, None);
    out.push_str("_build(Cx& cx) {\n    if (auto old = std::exchange(this->");
    place(&mut out, name, None);
    out.push_str(", std::nullopt)) {\n        (*old)->leave_row(cx);\n        cx.leave_later(*old);\n    }\n    std::uint32_t g = this->");
    place(&mut out, name, None);
    out.push_str("_count;\n    this->");
    place(&mut out, name, None);
    out.push_str("_count = g + 1;\n    Path path = ");
    place(&mut out, path_, None);
    out.push_str(";\n    ");
    place(&mut out, value_ty, None);
    out.push_str(" value = ");
    place(&mut out, source, None);
    out.push_str(";\n    prism_rtl::Rc<Row> row = ");
    place(&mut out, select, None);
    out.push_str(";\n    this->");
    place(&mut out, name, None);
    out.push_str(" = row;");
    place(&mut out, moved, None);
    out.push_str("\n    return {};\n}\n");
    Text::from(out)
}

/// ```prism
/// ProgramClass: fn Text, Text, Text, Text, Text -> Text
/// ```
pub fn program_class(name: &Text, prism: &Text, node_: &Text, decode: &Text, root: &Text) -> Text {
    let mut out = String::new();
    out.push_str("/// The program of `@");
    place(&mut out, prism, None);
    out.push_str("`: the root node and the runtime.\nclass ");
    place(&mut out, name, None);
    out.push_str(" : public Program {\npublic:\n    static Built<");
    place(&mut out, name, None);
    out.push_str("> build(std::span<const Pod> args, const ReadyState& ready) {\n");
    place(&mut out, decode, Some(8));
    out.push_str("        auto p = std::make_unique<");
    place(&mut out, name, None);
    out.push_str(">();\n        Cx cx = p->rt.build(ready);\n        p->root = ");
    place(&mut out, root, None);
    out.push_str(";\n        TickOut out = TRY(p->rt.close(std::move(cx)));\n        return std::pair<std::unique_ptr<");
    place(&mut out, name, None);
    out.push_str(">, TickOut>(std::move(p), std::move(out));\n    }\n    Result<TickOut> tick(const TickIn& input, const ReadyState& ready) override {\n        return rt.tick(root, input, ready);\n    }\n    void compact() override { rt.compact(); }\n\n    Runtime rt;\n    prism_rtl::Rc<");
    place(&mut out, node_, None);
    out.push_str("> root;\n};\n");
    Text::from(out)
}

/// ```prism
/// StmtExpr: fn Text, Text -> Text
/// ```
pub fn stmt_expr(stmts: &Text, tail: &Text) -> Text {
    let mut out = String::new();
    out.push_str("({\n");
    place(&mut out, stmts, Some(4));
    out.push_str("    ");
    place(&mut out, tail, None);
    out.push_str(";\n})");
    Text::from(out)
}

/// ```prism
/// MatchExpr: fn Text, Text -> Text
/// ```
pub fn match_expr(ty: &Text, arms: &Text) -> Text {
    let mut out = String::new();
    out.push_str("({\n    __label__ _done;\n    prism_rtl::Slot<");
    place(&mut out, ty, None);
    out.push_str("> _v;\n");
    place(&mut out, arms, Some(4));
    out.push_str("_done:\n    _v.take();\n})");
    Text::from(out)
}

/// ```prism
/// LabeledExpr: fn Text, Text, Text -> Text
/// ```
pub fn labeled_expr(label: &Text, ty: &Text, body: &Text) -> Text {
    let mut out = String::new();
    out.push_str("({\n    __label__ ");
    place(&mut out, label, None);
    out.push_str(";\n    prism_rtl::Slot<");
    place(&mut out, ty, None);
    out.push_str("> ");
    place(&mut out, label, None);
    out.push_str("_v;\n    {\n");
    place(&mut out, body, Some(8));
    out.push_str("    }\n");
    place(&mut out, label, None);
    out.push_str(":\n    ");
    place(&mut out, label, None);
    out.push_str("_v.take();\n})");
    Text::from(out)
}

/// ```prism
/// CondExpr: fn Text, Text, Text -> Text
/// ```
pub fn cond_expr(cond: &Text, then_x: &Text, else_x: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, cond, Some(0));
    out.push_str("    ? ");
    place(&mut out, then_x, None);
    out.push_str("\n    : ");
    place(&mut out, else_x, None);
    Text::from(out)
}

/// ```prism
/// Lambda: fn Text, Text, Text -> Text
/// ```
pub fn lambda(capture: &Text, params: &Text, body: &Text) -> Text {
    let mut out = String::new();
    out.push_str("[");
    place(&mut out, capture, None);
    out.push_str("](");
    place(&mut out, params, None);
    out.push_str(" {\n");
    place(&mut out, body, Some(4));
    out.push_str("}");
    Text::from(out)
}

/// ```prism
/// Block: fn Text, Text -> Text
/// ```
pub fn block(head: &Text, body: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, head, None);
    out.push_str(" {\n");
    place(&mut out, body, Some(4));
    out.push_str("}");
    Text::from(out)
}

/// ```prism
/// IfBlock: fn Text, Text -> Text
/// ```
pub fn if_block(cond: &Text, body: &Text) -> Text {
    let mut out = String::new();
    out.push_str("if (");
    place(&mut out, cond, None);
    out.push_str(") {\n");
    place(&mut out, body, Some(4));
    out.push_str("}");
    Text::from(out)
}

/// ```prism
/// Braced: fn Text -> Text
/// ```
pub fn braced(body: &Text) -> Text {
    let mut out = String::new();
    out.push_str("{\n");
    place(&mut out, body, Some(4));
    out.push_str("}");
    Text::from(out)
}
