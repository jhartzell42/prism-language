//! The module `Emit.Cpp.Templates.Items`, from `target/bootstrap/src/prismc/emit/cpp/templates/items.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// ChoiceClass: fn Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn choice_class_f(doc_p0: &crate::prelude::Text, gens_p1: &crate::prelude::Text, name_p2: &crate::prelude::Text, cases_p3: &crate::prelude::Text, names_p4: &crate::prelude::Text, members_p5: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    crate::prelude::place(&mut out, doc_p0, ::std::option::Option::Some(0));
    crate::prelude::place(&mut out, gens_p1, ::std::option::Option::None);
    out.push_str("class ");
    crate::prelude::place(&mut out, name_p2, ::std::option::Option::None);
    out.push_str(" {\npublic:\n    using prism_value = void;\n");
    crate::prelude::place(&mut out, cases_p3, ::std::option::Option::Some(4));
    out.push_str("    using Cases = ::std::variant<");
    crate::prelude::place(&mut out, names_p4, ::std::option::Option::None);
    out.push_str(">;\n    template <class C>\n        requires ::prism_rtl::one_of<C, ");
    crate::prelude::place(&mut out, names_p4, ::std::option::Option::None);
    out.push_str(">\n    ");
    crate::prelude::place(&mut out, name_p2, ::std::option::Option::None);
    out.push_str("(C c) : cases_(::std::move(c)) {}\n    const Cases& cases() const { return cases_; }\n");
    crate::prelude::place(&mut out, members_p5, ::std::option::Option::Some(4));
    out.push_str("\nprivate:\n    Cases cases_;\n};\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// CaseDecl: fn Text, Text -> Text
/// ```
pub fn case_decl_f(name_p0: &crate::prelude::Text, fields_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("struct ");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str(" {\n");
    crate::prelude::place(&mut out, fields_p1, ::std::option::Option::Some(4));
    out.push_str("};\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// ValueStruct: fn Text, Text, Text, Text, Text -> Text
/// ```
pub fn value_struct_f(doc_p0: &crate::prelude::Text, gens_p1: &crate::prelude::Text, name_p2: &crate::prelude::Text, fields_p3: &crate::prelude::Text, members_p4: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    crate::prelude::place(&mut out, doc_p0, ::std::option::Option::Some(0));
    crate::prelude::place(&mut out, gens_p1, ::std::option::Option::None);
    out.push_str("struct ");
    crate::prelude::place(&mut out, name_p2, ::std::option::Option::None);
    out.push_str(" {\n    using prism_value = void;\n");
    crate::prelude::place(&mut out, fields_p3, ::std::option::Option::Some(4));
    out.push_str("    const ");
    crate::prelude::place(&mut out, name_p2, ::std::option::Option::None);
    out.push_str("* operator->() const { return this; }\n    ");
    crate::prelude::place(&mut out, name_p2, ::std::option::Option::None);
    out.push_str("* operator->() { return this; }\n");
    crate::prelude::place(&mut out, members_p4, ::std::option::Option::Some(4));
    out.push_str("};\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// CppTagStruct: fn Text, Text, Text, Text, Text -> Text
/// ```
pub fn cpp_tag_struct_f(doc_p0: &crate::prelude::Text, name_p1: &crate::prelude::Text, fields_p2: &crate::prelude::Text, tag_name_p3: &crate::prelude::Text, members_p4: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    crate::prelude::place(&mut out, doc_p0, ::std::option::Option::Some(0));
    out.push_str("struct ");
    crate::prelude::place(&mut out, name_p1, ::std::option::Option::None);
    out.push_str(" {\n    using prism_value = void;\n    /// The tag\'s qualified name, as its `Pod` carries it.\n    static constexpr const char* TAG = \"");
    crate::prelude::place(&mut out, tag_name_p3, ::std::option::Option::None);
    out.push_str("\";\n");
    crate::prelude::place(&mut out, fields_p2, ::std::option::Option::Some(4));
    out.push_str("    const ");
    crate::prelude::place(&mut out, name_p1, ::std::option::Option::None);
    out.push_str("* operator->() const { return this; }\n    ");
    crate::prelude::place(&mut out, name_p1, ::std::option::Option::None);
    out.push_str("* operator->() { return this; }\n    crate::prelude::Pod to_pod() const;\n    void show(crate::prelude::Printer& p) const;\n");
    crate::prelude::place(&mut out, members_p4, ::std::option::Option::Some(4));
    out.push_str("};\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// CppFunction: fn Text, Text, Text -> Text
/// ```
pub fn cpp_function_f(doc_p0: &crate::prelude::Text, signature_p1: &crate::prelude::Text, body_p2: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    crate::prelude::place(&mut out, doc_p0, ::std::option::Option::Some(0));
    crate::prelude::place(&mut out, signature_p1, ::std::option::Option::None);
    out.push_str(" {\n");
    crate::prelude::place(&mut out, body_p2, ::std::option::Option::Some(4));
    out.push_str("}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// JobStruct: fn Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn job_struct_f(doc_p0: &crate::prelude::Text, gens_p1: &crate::prelude::Text, name_p2: &crate::prelude::Text, ret_p3: &crate::prelude::Text, fields_p4: &crate::prelude::Text, ctor_p5: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("/// The step machine of `");
    crate::prelude::place(&mut out, name_p2, ::std::option::Option::None);
    out.push_str("`, stopped at a cycle point: the call about to be\n/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the\n/// callee\'s job, so the job\'s stack is its frames.\n///\n");
    crate::prelude::place(&mut out, doc_p0, ::std::option::Option::Some(0));
    crate::prelude::place(&mut out, gens_p1, ::std::option::Option::None);
    out.push_str("struct ");
    crate::prelude::place(&mut out, name_p2, ::std::option::Option::None);
    out.push_str(" : ::prism_rtl::Job<");
    crate::prelude::place(&mut out, ret_p3, ::std::option::Option::None);
    out.push_str("> {\n");
    crate::prelude::place(&mut out, fields_p4, ::std::option::Option::Some(4));
    crate::prelude::place(&mut out, ctor_p5, ::std::option::Option::Some(4));
    out.push_str("    ::prism_rtl::Turn<");
    crate::prelude::place(&mut out, ret_p3, ::std::option::Option::None);
    out.push_str("> cycle() const override;\n};\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// TraitNamespace: fn Text, Text -> Text
/// ```
pub fn trait_namespace_f(name_p0: &crate::prelude::Text, body_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("namespace ");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str(" {\n");
    crate::prelude::place(&mut out, body_p1, ::std::option::Option::Some(0));
    out.push_str("}  // namespace ");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    crate::prelude::Text::from(out)
}

/// ```prism
/// NodeClass: fn Text, Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn node_class_f(doc_p0: &crate::prelude::Text, name_p1: &crate::prelude::Text, base_p2: &crate::prelude::Text, fields_p3: &crate::prelude::Text, consts_p4: &crate::prelude::Text, ctor_p5: &crate::prelude::Text, decls_p6: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    crate::prelude::place(&mut out, doc_p0, ::std::option::Option::Some(0));
    out.push_str("class ");
    crate::prelude::place(&mut out, name_p1, ::std::option::Option::None);
    out.push_str(" : public ");
    crate::prelude::place(&mut out, base_p2, ::std::option::Option::None);
    out.push_str(" {\npublic:\n    crate::prelude::Path path;\n");
    crate::prelude::place(&mut out, fields_p3, ::std::option::Option::Some(4));
    crate::prelude::place(&mut out, consts_p4, ::std::option::Option::Some(4));
    crate::prelude::place(&mut out, ctor_p5, ::std::option::Option::Some(4));
    out.push_str("    ");
    crate::prelude::place(&mut out, name_p1, ::std::option::Option::None);
    out.push_str("(const ");
    crate::prelude::place(&mut out, name_p1, ::std::option::Option::None);
    out.push_str("&) = delete;\n");
    crate::prelude::place(&mut out, decls_p6, ::std::option::Option::Some(4));
    out.push_str("};\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// NodeMake: fn Text, Text, Text, Text, Text -> Text
/// ```
pub fn node_make_f(name_p0: &crate::prelude::Text, signature_p1: &crate::prelude::Text, lets_p2: &crate::prelude::Text, args_p3: &crate::prelude::Text, rest_p4: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("/// Built after propagation: holds take their initial values, places go out with\n/// `cx.added`, and nothing fires.\n");
    crate::prelude::place(&mut out, signature_p1, ::std::option::Option::None);
    out.push_str(" {\n");
    crate::prelude::place(&mut out, lets_p2, ::std::option::Option::Some(4));
    out.push_str("    ::prism_rtl::RcPlace<");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str("> _place;\n    auto node = _place.take(new (_place.at()) ");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str("(");
    crate::prelude::place(&mut out, args_p3, ::std::option::Option::None);
    out.push_str("));\n");
    crate::prelude::place(&mut out, rest_p4, ::std::option::Option::Some(4));
    out.push_str("}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// ForBuildTemplate: fn Text, Text, Text, Text, Text, Text, Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn for_build_template_f(owner_p0: &crate::prelude::Text, name_p1: &crate::prelude::Text, at_p2: &crate::prelude::Text, key_ty_p3: &crate::prelude::Text, value_ty_p4: &crate::prelude::Text, row_make_p5: &crate::prelude::Text, source_p6: &crate::prelude::Text, parent_p7: &crate::prelude::Text, passed_p8: &crate::prelude::Text, moved_p9: &crate::prelude::Text, from_pa: &crate::prelude::Text, replaced_pb: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("/// The rows of the `for` at `");
    crate::prelude::place(&mut out, at_p2, ::std::option::Option::None);
    out.push_str("`: rows whose key left are torn down, new keys are\n/// built under it at `[k]` from the values after the tick; kept rows keep reading their\n/// entry out of the source. Nothing to do when the source is the map last built from (one\n/// node, `same`: it has the same keys; Semantics ch. 11, sharing is invisible).\ncrate::prelude::Done ");
    crate::prelude::place(&mut out, owner_p0, ::std::option::Option::None);
    out.push_str("::");
    crate::prelude::place(&mut out, name_p1, ::std::option::Option::None);
    out.push_str("_build(crate::prelude::Cx& cx) {\n    crate::prelude::Map<");
    crate::prelude::place(&mut out, key_ty_p3, ::std::option::Option::None);
    out.push_str(", ");
    crate::prelude::place(&mut out, value_ty_p4, ::std::option::Option::None);
    out.push_str("> items = ");
    crate::prelude::place(&mut out, source_p6, ::std::option::Option::None);
    out.push_str("(cx);\n    if (this->");
    crate::prelude::place(&mut out, name_p1, ::std::option::Option::None);
    out.push_str("_from.same(items)) return {};\n");
    crate::prelude::place(&mut out, from_pa, ::std::option::Option::Some(4));
    out.push_str("    auto old = crate::prelude::deref(this->");
    crate::prelude::place(&mut out, name_p1, ::std::option::Option::None);
    out.push_str(");\n    // the kept rows stay where they are: only the keys that left or came are touched\n    auto next = old;\n    for (auto&& [k, row] : old) {\n        if (!items.contains(k)) {\n            row->leave_row(cx);\n            cx.leave_later(row);\n            next.remove(k);\n        }");
    crate::prelude::place(&mut out, replaced_pb, ::std::option::Option::None);
    out.push_str("\n    }\n    for (auto&& [k, v] : items) {\n        if (!old.contains(k)) next.insert(k, TRY(");
    crate::prelude::place(&mut out, row_make_p5, ::std::option::Option::None);
    out.push_str("(");
    crate::prelude::place(&mut out, at_p2, ::std::option::Option::None);
    out.push_str(".child(crate::prelude::Segment::key(::prism_rtl::to_pod(k))), k, v, ");
    crate::prelude::place(&mut out, parent_p7, ::std::option::Option::None);
    crate::prelude::place(&mut out, passed_p8, ::std::option::Option::None);
    out.push_str(", cx)));\n    }\n    crate::prelude::deref(this->");
    crate::prelude::place(&mut out, name_p1, ::std::option::Option::None);
    out.push_str(") = next;\n    // What the block reads of its rows (a `for` that gives a dynamic) moved.\n    cx.dirty(::prism_rtl::share(this));");
    crate::prelude::place(&mut out, moved_p9, ::std::option::Option::None);
    out.push_str("\n    return {};\n}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// GenBuildTemplate: fn Text, Text, Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn gen_build_template_f(owner_p0: &crate::prelude::Text, name_p1: &crate::prelude::Text, at_p2: &crate::prelude::Text, path_p3: &crate::prelude::Text, source_p4: &crate::prelude::Text, value_ty_p5: &crate::prelude::Text, select_p6: &crate::prelude::Text, moved_p7: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("/// The `rebuild` at `");
    crate::prelude::place(&mut out, at_p2, ::std::option::Option::None);
    out.push_str("`: the old generation torn down (it ran to the end of the\n/// tick), the next built at `");
    crate::prelude::place(&mut out, path_p3, ::std::option::Option::None);
    out.push_str("` from the source after the tick.\ncrate::prelude::Done ");
    crate::prelude::place(&mut out, owner_p0, ::std::option::Option::None);
    out.push_str("::");
    crate::prelude::place(&mut out, name_p1, ::std::option::Option::None);
    out.push_str("_build(crate::prelude::Cx& cx) {\n    if (auto old = ::std::exchange(this->");
    crate::prelude::place(&mut out, name_p1, ::std::option::Option::None);
    out.push_str(", ::std::nullopt)) {\n        (*old)->leave_row(cx);\n        cx.leave_later(*old);\n    }\n    ::std::uint32_t g = this->");
    crate::prelude::place(&mut out, name_p1, ::std::option::Option::None);
    out.push_str("_count;\n    this->");
    crate::prelude::place(&mut out, name_p1, ::std::option::Option::None);
    out.push_str("_count = g + 1;\n    crate::prelude::Path path = ");
    crate::prelude::place(&mut out, path_p3, ::std::option::Option::None);
    out.push_str(";\n    ");
    crate::prelude::place(&mut out, value_ty_p5, ::std::option::Option::None);
    out.push_str(" value = ");
    crate::prelude::place(&mut out, source_p4, ::std::option::Option::None);
    out.push_str(";\n    ::prism_rtl::Rc<crate::prelude::Row> row = ");
    crate::prelude::place(&mut out, select_p6, ::std::option::Option::None);
    out.push_str(";\n    this->");
    crate::prelude::place(&mut out, name_p1, ::std::option::Option::None);
    out.push_str(" = row;");
    crate::prelude::place(&mut out, moved_p7, ::std::option::Option::None);
    out.push_str("\n    return {};\n}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// ProgramClass: fn Text, Text, Text, Text, Text -> Text
/// ```
pub fn program_class_f(name_p0: &crate::prelude::Text, prism_p1: &crate::prelude::Text, node_p2: &crate::prelude::Text, decode_p3: &crate::prelude::Text, root_p4: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("/// The program of `@");
    crate::prelude::place(&mut out, prism_p1, ::std::option::Option::None);
    out.push_str("`: the root node and the runtime.\nclass ");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str(" : public crate::prelude::Program {\npublic:\n    static crate::prelude::Built<");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str("> build(::std::span<const crate::prelude::Pod> args, const crate::prelude::ReadyState& ready) {\n");
    crate::prelude::place(&mut out, decode_p3, ::std::option::Option::Some(8));
    out.push_str("        auto p = ::std::make_unique<");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str(">();\n        crate::prelude::Cx cx = p->rt.build(ready);\n        p->root = ");
    crate::prelude::place(&mut out, root_p4, ::std::option::Option::None);
    out.push_str(";\n        crate::prelude::TickOut out = TRY(p->rt.close(::std::move(cx)));\n        return ::std::pair<::std::unique_ptr<");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str(">, crate::prelude::TickOut>(::std::move(p), ::std::move(out));\n    }\n    crate::prelude::Result<crate::prelude::TickOut> tick(const crate::prelude::TickIn& input, const crate::prelude::ReadyState& ready) override {\n        return rt.tick(root, input, ready);\n    }\n    void compact() override { rt.compact(); }\n\n    crate::prelude::Runtime rt;\n    ::prism_rtl::Rc<");
    crate::prelude::place(&mut out, node_p2, ::std::option::Option::None);
    out.push_str("> root;\n};\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// StmtExpr: fn Text, Text -> Text
/// ```
pub fn stmt_expr_f(stmts_p0: &crate::prelude::Text, tail_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("({\n");
    crate::prelude::place(&mut out, stmts_p0, ::std::option::Option::Some(4));
    out.push_str("    ");
    crate::prelude::place(&mut out, tail_p1, ::std::option::Option::None);
    out.push_str(";\n})");
    crate::prelude::Text::from(out)
}

/// ```prism
/// MatchExpr: fn Text, Text -> Text
/// ```
pub fn match_expr_f(ty_p0: &crate::prelude::Text, arms_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("({\n    __label__ _done;\n    ::prism_rtl::Slot<");
    crate::prelude::place(&mut out, ty_p0, ::std::option::Option::None);
    out.push_str("> _v;\n");
    crate::prelude::place(&mut out, arms_p1, ::std::option::Option::Some(4));
    out.push_str("_done:\n    _v.take();\n})");
    crate::prelude::Text::from(out)
}

/// ```prism
/// LabeledExpr: fn Text, Text, Text -> Text
/// ```
pub fn labeled_expr_f(label_p0: &crate::prelude::Text, ty_p1: &crate::prelude::Text, body_p2: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("({\n    __label__ ");
    crate::prelude::place(&mut out, label_p0, ::std::option::Option::None);
    out.push_str(";\n    ::prism_rtl::Slot<");
    crate::prelude::place(&mut out, ty_p1, ::std::option::Option::None);
    out.push_str("> ");
    crate::prelude::place(&mut out, label_p0, ::std::option::Option::None);
    out.push_str("_v;\n    {\n");
    crate::prelude::place(&mut out, body_p2, ::std::option::Option::Some(8));
    out.push_str("    }\n");
    crate::prelude::place(&mut out, label_p0, ::std::option::Option::None);
    out.push_str(":\n    ");
    crate::prelude::place(&mut out, label_p0, ::std::option::Option::None);
    out.push_str("_v.take();\n})");
    crate::prelude::Text::from(out)
}

/// ```prism
/// CondExpr: fn Text, Text, Text -> Text
/// ```
pub fn cond_expr_f(cond_p0: &crate::prelude::Text, then_x_p1: &crate::prelude::Text, else_x_p2: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    crate::prelude::place(&mut out, cond_p0, ::std::option::Option::Some(0));
    out.push_str("    ? ");
    crate::prelude::place(&mut out, then_x_p1, ::std::option::Option::None);
    out.push_str("\n    : ");
    crate::prelude::place(&mut out, else_x_p2, ::std::option::Option::None);
    crate::prelude::Text::from(out)
}

/// ```prism
/// Lambda: fn Text, Text, Text -> Text
/// ```
pub fn lambda_f(capture_p0: &crate::prelude::Text, params_p1: &crate::prelude::Text, body_p2: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("[");
    crate::prelude::place(&mut out, capture_p0, ::std::option::Option::None);
    out.push_str("](");
    crate::prelude::place(&mut out, params_p1, ::std::option::Option::None);
    out.push_str(" {\n");
    crate::prelude::place(&mut out, body_p2, ::std::option::Option::Some(4));
    out.push_str("}");
    crate::prelude::Text::from(out)
}

/// ```prism
/// Block: fn Text, Text -> Text
/// ```
pub fn block_f(head_p0: &crate::prelude::Text, body_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    crate::prelude::place(&mut out, head_p0, ::std::option::Option::None);
    out.push_str(" {\n");
    crate::prelude::place(&mut out, body_p1, ::std::option::Option::Some(4));
    out.push_str("}");
    crate::prelude::Text::from(out)
}

/// ```prism
/// IfBlock: fn Text, Text -> Text
/// ```
pub fn if_block_f(cond_p0: &crate::prelude::Text, body_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("if (");
    crate::prelude::place(&mut out, cond_p0, ::std::option::Option::None);
    out.push_str(") {\n");
    crate::prelude::place(&mut out, body_p1, ::std::option::Option::Some(4));
    out.push_str("}");
    crate::prelude::Text::from(out)
}

/// ```prism
/// Braced: fn Text -> Text
/// ```
pub fn braced_f(body_p0: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("{\n");
    crate::prelude::place(&mut out, body_p0, ::std::option::Option::Some(4));
    out.push_str("}");
    crate::prelude::Text::from(out)
}
