//! The module `Emit`, from `target/bootstrap/src/prismc/emit/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;
pub mod cpp;
pub mod rust;

