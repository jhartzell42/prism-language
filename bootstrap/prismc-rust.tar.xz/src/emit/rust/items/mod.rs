//! The module `Emit.Rust.Items`, from `target/bootstrap/src/prismc/emit/rust/items.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// Generics: fn [((Text, [Text]))] -> Text
/// ```
pub fn generics(xs0: &Array<(Text, Array<Text>)>) -> Text {
    match xs0 {
        c0_0 if (c0_0.len() == 0) => Text::lit(""),
        gs => Text::from(format!("<{}>", &crate::syntax::lexer::chars::join(&each(gs, &(|(g, bs): &(Text, Array<Text>)| if &len(bs) == &Nat::from(0u32) {
            g.clone()
        } else {
            Text::from(format!("{}: {}", g, &crate::syntax::lexer::chars::join(bs, &Text::lit(" + "))))
        })), &Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// GenericNames: fn [Text] -> Text
/// ```
pub fn generic_names(xs0: &Array<Text>) -> Text {
    match xs0 {
        c0_0 if (c0_0.len() == 0) => Text::lit(""),
        ps => Text::from(format!("<{}>", &crate::syntax::lexer::chars::join(ps, &Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Bounded: fn [Text], Text -> Text
/// ```
pub fn bounded(xs0: &Array<Text>, text1: &Text) -> Text {
    match (xs0, text1) {
        (c0_0, _) if (c0_0.len() == 0) => Text::lit(""),
        (ps, tr) => Text::from(format!("<{}>", &crate::syntax::lexer::chars::join(&each(ps, &(|p_: &Text| Text::from(format!("{}: {}", p_, tr)))), &Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// RustItem: unbounded fn Item -> Text
/// ```
pub fn rust_item(it: &crate::lower::model::Item) -> Text {
    match it {
        crate::lower::model::Item::ItTrait(t) => rust_trait(t),
        crate::lower::model::Item::ItImpl(i) => rust_impl(i),
        crate::lower::model::Item::ItType(t) => type_decl(t),
        crate::lower::model::Item::ItTag(t) => rust_tag(t),
        crate::lower::model::Item::ItRow(r) => rust_row(r),
        crate::lower::model::Item::ItFn(f) => rust_fn(f),
        crate::lower::model::Item::ItJob(j) => rust_job(j),
        crate::lower::model::Item::ItNode(n) => rust_node(n),
        crate::lower::model::Item::ItNote(t) => Text::from(format!("// {}\n", t)),
        crate::lower::model::Item::ItRefused(t) => Text::from(format!("compile_error!(\"{}{}\");\n", &crate::lower::expr::lowering_refusal(), &crate::lower::expr::escape(t))),
    }
}

/// The step machine of `RustItem`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustItem: unbounded fn Item -> Text
/// ```
pub struct RustItem {
    pub it: crate::lower::model::Item,
}

impl prism_rtl::Job<Text> for RustItem {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let it = &self.it;
        match it {
            crate::lower::model::Item::ItTrait(t) => prism_rtl::Turn::More(Rc::new(RustTrait { t: t.clone() })),
            crate::lower::model::Item::ItImpl(i) => prism_rtl::Turn::More(Rc::new(RustImpl { i: i.clone() })),
            crate::lower::model::Item::ItType(t) => prism_rtl::Turn::More(Rc::new(TypeDecl { t: t.clone() })),
            crate::lower::model::Item::ItTag(t) => prism_rtl::Turn::More(Rc::new(RustTag { t: t.clone() })),
            crate::lower::model::Item::ItRow(r) => prism_rtl::Turn::More(Rc::new(RustRow { r: r.clone() })),
            crate::lower::model::Item::ItFn(f) => prism_rtl::Turn::More(Rc::new(RustFn { f: f.clone() })),
            crate::lower::model::Item::ItJob(j) => prism_rtl::Turn::More(Rc::new(RustJob { j: j.clone() })),
            crate::lower::model::Item::ItNode(n) => prism_rtl::Turn::More(Rc::new(RustNode { n: n.clone() })),
            crate::lower::model::Item::ItNote(t) => prism_rtl::Turn::Finished(Text::from(format!("// {}\n", t))),
            crate::lower::model::Item::ItRefused(t) => prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}{}\");\n", &crate::lower::expr::lowering_refusal(), &crate::lower::expr::escape(t)))),
        }
    }
}

/// `Start RustItem, x`: what the function value is when passed to `@Run`.
pub fn start_rust_item(it: crate::lower::model::Item) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustItem { it })
}

/// ```prism
/// RustTrait: unbounded fn TraitDef -> Text
/// ```
pub fn rust_trait(t: &crate::lower::model::TraitDef) -> Text {
    let ms = crate::syntax::lexer::chars::join(&run_to_end(each_job(t.methods.clone(), Rc::new(move |p0: crate::lower::model::FnDef| entered(once_job(move || {
        let f = p0;
        prism_rtl::Turn::More(Rc::new(TraitMethod { f: f.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    Text::from(format!("{}pub trait {} {{\n{}\n}}\n", &crate::emit::rust::templates::source_doc(&Text::lit(""), &t.doc), &t.name, &crate::emit::rust::indent(&ms)))
}

/// The step machine of `RustTrait`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustTrait: unbounded fn TraitDef -> Text
/// ```
pub struct RustTrait {
    pub t: crate::lower::model::TraitDef,
}

impl prism_rtl::Job<Text> for RustTrait {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        let t = t.clone();
        call_value(each_job(t.methods.clone(), Rc::new(move |p0: crate::lower::model::FnDef| entered(once_job(move || {
            let f = p0;
            prism_rtl::Turn::More(Rc::new(TraitMethod { f: f.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_1796: Array<Text>| {
            let ms = crate::syntax::lexer::chars::join(&each_1796, &Text::lit("\n"));
            prism_rtl::Turn::Finished(Text::from(format!("{}pub trait {} {{\n{}\n}}\n", &crate::emit::rust::templates::source_doc(&Text::lit(""), &t.doc), &t.name, &crate::emit::rust::indent(&ms))))
        })
    }
}

/// `Start RustTrait, x`: what the function value is when passed to `@Run`.
pub fn start_rust_trait(t: crate::lower::model::TraitDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustTrait { t })
}

/// ```prism
/// Signature: unbounded fn FnDef, Text -> Text
/// ```
pub fn signature(f: &crate::lower::model::FnDef, vis: &Text) -> Text {
    let params = crate::syntax::lexer::chars::join(&run_to_end(each_job(f.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (n, t) = p0;
        call_then(crate::emit::rust::start_type_(t.clone()), move |type__2029: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n, &type__2029))))
    }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "));
    Text::from(format!("{}fn {}{}({}) -> {}", vis, &f.name, &generics(&f.generics), &params, &crate::emit::rust::type_(&f.ret)))
}

/// The step machine of `Signature`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Signature: unbounded fn FnDef, Text -> Text
/// ```
pub struct Signature {
    pub f: crate::lower::model::FnDef,
    pub vis: Text,
}

impl prism_rtl::Job<Text> for Signature {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f = &self.f;
        let vis = &self.vis;
        let f = f.clone();
        let vis = vis.clone();
        call_value(each_job(f.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
            let (n, t) = p0;
            call_then(crate::emit::rust::start_type_(t.clone()), move |type__2029: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n, &type__2029))))
        }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_1995: Array<Text>| {
            let params = crate::syntax::lexer::chars::join(&each_1995, &Text::lit(", "));
            call_then(crate::emit::rust::start_type_(f.ret.clone()), move |type__2102: Text| prism_rtl::Turn::Finished(Text::from(format!("{}fn {}{}({}) -> {}", &vis, &f.name, &generics(&f.generics), &params, &type__2102))))
        })
    }
}

/// `Start Signature, x`: what the function value is when passed to `@Run`.
pub fn start_signature(f: crate::lower::model::FnDef, vis: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Signature { f, vis })
}

/// ```prism
/// TraitMethod: unbounded fn FnDef -> Text
/// ```
pub fn trait_method(f: &crate::lower::model::FnDef) -> Text {
    if f.public {
        crate::emit::rust::templates::items::fn_(&Text::lit(""), &signature(f, &Text::lit("")), &crate::emit::rust::body_lines(&f.body))
    } else {
        Text::from(format!("{};", &signature(f, &Text::lit(""))))
    }
}

/// The step machine of `TraitMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TraitMethod: unbounded fn FnDef -> Text
/// ```
pub struct TraitMethod {
    pub f: crate::lower::model::FnDef,
}

impl prism_rtl::Job<Text> for TraitMethod {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f = &self.f;
        if f.public {
            {
                let f = f.clone();
                call_then(start_signature(f.clone(), Text::lit("")), move |signature_2196: Text| call_then(crate::emit::rust::start_body_lines(f.body.clone()), move |body_lines_2215: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::fn_(&Text::lit(""), &signature_2196, &body_lines_2215))))
            }
        } else {
            {
                let f = f.clone();
                call_then(start_signature(f.clone(), Text::lit("")), move |signature_2241: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &signature_2241))))
            }
        }
    }
}

/// `Start TraitMethod, x`: what the function value is when passed to `@Run`.
pub fn start_trait_method(f: crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TraitMethod { f })
}

/// ```prism
/// RustImpl: unbounded fn ImplDef -> Text
/// ```
pub fn rust_impl(i: &crate::lower::model::ImplDef) -> Text {
    let head = crate::emit::rust::type_(&i.head);
    let gens = generics(&i.generics);
    match &i.cls {
        m2516_0 if (m2516_0 == &Text::lit("Prelude.Show")) => {
            let fns = crate::syntax::lexer::chars::join(&run_to_end(each_job(i.methods.clone(), Rc::new(move |p0: crate::lower::model::FnDef| entered(once_job(move || {
                let f = p0;
                prism_rtl::Turn::More(Rc::new(RustFn { f: f.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
            let shown = or(&index(&each(&i.methods, &(|f: &crate::lower::model::FnDef| f.name.clone())), &Nat::from(0u32)), &Text::lit("show"));
            Text::from(format!("{}\n{}", &fns, &crate::emit::rust::templates::items::impl_(&gens, &Text::lit("Show"), &head, &Text::lit("fn show(&self, p: &mut Printer)"), &Text::from(format!("p.raw(&{}(self).to_string());", &shown)))))
        },
        m2516_1 if (m2516_1 == &Text::lit("Prelude.Eq")) => {
            let fns = crate::syntax::lexer::chars::join(&run_to_end(each_job(i.methods.clone(), Rc::new(move |p0: crate::lower::model::FnDef| entered(once_job(move || {
                let f = p0;
                prism_rtl::Turn::More(Rc::new(RustFn { f: f.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
            let eq = fold(&i.methods, &Text::lit(""), &(|acc: &Text, f: &crate::lower::model::FnDef| if !crate::syntax::lexer::chars::has_prefix(&f.name, &Text::lit("ne")) && (acc == &Text::lit("")) {
                f.name.clone()
            } else {
                acc.clone()
            }));
            Text::from(format!("{}\n{}", &fns, &crate::emit::rust::templates::items::impl_(&gens, &Text::lit("PartialEq"), &head, &Text::lit("fn eq(&self, other: &Self) -> bool"), &Text::from(format!("{}(self, other)", &eq)))))
        },
        _ => Text::from(format!("impl{} {} for {} {{\n{}\n}}\n", &gens, &i.tr, &head, &crate::emit::rust::indent(&crate::syntax::lexer::chars::join(&run_to_end(each_job(i.methods.clone(), Rc::new(move |p0: crate::lower::model::FnDef| entered(once_job(move || {
            let f = p0;
            call_then(start_signature(f.clone(), Text::lit("")), move |signature_3218: Text| call_then(crate::emit::rust::start_body_lines(f.body.clone()), move |body_lines_3237: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::fn_(&Text::lit(""), &signature_3218, &body_lines_3237))))
        }))) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `RustImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustImpl: unbounded fn ImplDef -> Text
/// ```
pub struct RustImpl {
    pub i: crate::lower::model::ImplDef,
}

impl prism_rtl::Job<Text> for RustImpl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let i = &self.i;
        let i = i.clone();
        call_then(crate::emit::rust::start_type_(i.head.clone()), move |type__2465: Text| {
            let head = type__2465;
            let gens = generics(&i.generics);
            match &i.cls {
                m2516_0 if (m2516_0 == &Text::lit("Prelude.Show")) => call_value(each_job(i.methods.clone(), Rc::new(move |p0: crate::lower::model::FnDef| entered(once_job(move || {
                    let f = p0;
                    prism_rtl::Turn::More(Rc::new(RustFn { f: f.clone() }))
                }))) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_2581: Array<Text>| {
                    let fns = crate::syntax::lexer::chars::join(&each_2581, &Text::lit("\n"));
                    let shown = or(&index(&each(&i.methods, &(|f: &crate::lower::model::FnDef| f.name.clone())), &Nat::from(0u32)), &Text::lit("show"));
                    prism_rtl::Turn::Finished(Text::from(format!("{}\n{}", &fns, &crate::emit::rust::templates::items::impl_(&gens, &Text::lit("Show"), &head, &Text::lit("fn show(&self, p: &mut Printer)"), &Text::from(format!("p.raw(&{}(self).to_string());", &shown))))))
                }),
                m2516_1 if (m2516_1 == &Text::lit("Prelude.Eq")) => call_value(each_job(i.methods.clone(), Rc::new(move |p0: crate::lower::model::FnDef| entered(once_job(move || {
                    let f = p0;
                    prism_rtl::Turn::More(Rc::new(RustFn { f: f.clone() }))
                }))) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_2856: Array<Text>| {
                    let fns = crate::syntax::lexer::chars::join(&each_2856, &Text::lit("\n"));
                    let eq = fold(&i.methods, &Text::lit(""), &(|acc: &Text, f: &crate::lower::model::FnDef| if !crate::syntax::lexer::chars::has_prefix(&f.name, &Text::lit("ne")) && (acc == &Text::lit("")) {
                        f.name.clone()
                    } else {
                        acc.clone()
                    }));
                    prism_rtl::Turn::Finished(Text::from(format!("{}\n{}", &fns, &crate::emit::rust::templates::items::impl_(&gens, &Text::lit("PartialEq"), &head, &Text::lit("fn eq(&self, other: &Self) -> bool"), &Text::from(format!("{}(self, other)", &eq))))))
                }),
                _ => call_value(each_job(i.methods.clone(), Rc::new(move |p0: crate::lower::model::FnDef| entered(once_job(move || {
                    let f = p0;
                    call_then(start_signature(f.clone(), Text::lit("")), move |signature_3218: Text| call_then(crate::emit::rust::start_body_lines(f.body.clone()), move |body_lines_3237: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::fn_(&Text::lit(""), &signature_3218, &body_lines_3237))))
                }))) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_3189: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("impl{} {} for {} {{\n{}\n}}\n", &gens, &i.tr, &head, &crate::emit::rust::indent(&crate::syntax::lexer::chars::join(&each_3189, &Text::lit("\n"))))))),
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start RustImpl, x`: what the function value is when passed to `@Run`.
pub fn start_rust_impl(i: crate::lower::model::ImplDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustImpl { i })
}

/// ```prism
/// RustFn: unbounded fn FnDef -> Text
/// ```
pub fn rust_fn(f: &crate::lower::model::FnDef) -> Text {
    let params = crate::syntax::lexer::chars::join(&run_to_end(each_job(f.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (n, t) = p0;
        call_then(crate::emit::rust::start_type_(t.clone()), move |type__3377: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n, &type__3377))))
    }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "));
    let sig = Text::from(format!("pub fn {}{}({}) -> {}", &f.name, &static_generics(&f.generics), &params, &crate::emit::rust::type_(&f.ret)));
    crate::emit::rust::templates::items::fn_(&crate::emit::rust::templates::source_doc(&Text::lit(""), &f.doc), &sig, &crate::emit::rust::body_lines(&f.body))
}

/// The step machine of `RustFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustFn: unbounded fn FnDef -> Text
/// ```
pub struct RustFn {
    pub f: crate::lower::model::FnDef,
}

impl prism_rtl::Job<Text> for RustFn {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f = &self.f;
        let f = f.clone();
        call_value(each_job(f.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
            let (n, t) = p0;
            call_then(crate::emit::rust::start_type_(t.clone()), move |type__3377: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n, &type__3377))))
        }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_3343: Array<Text>| {
            let params = crate::syntax::lexer::chars::join(&each_3343, &Text::lit(", "));
            call_then(crate::emit::rust::start_type_(f.ret.clone()), move |type__3607: Text| {
                let sig = Text::from(format!("pub fn {}{}({}) -> {}", &f.name, &static_generics(&f.generics), &params, &type__3607));
                call_then(crate::emit::rust::start_body_lines(f.body.clone()), move |body_lines_3656: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::fn_(&crate::emit::rust::templates::source_doc(&Text::lit(""), &f.doc), &sig, &body_lines_3656)))
            })
        })
    }
}

/// `Start RustFn, x`: what the function value is when passed to `@Run`.
pub fn start_rust_fn(f: crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustFn { f })
}

/// ```prism
/// StaticGenerics: fn [((Text, [Text]))] -> Text
/// ```
pub fn static_generics(gs: &Array<(Text, Array<Text>)>) -> Text {
    generics(&each(gs, &(|(g, bs): &(Text, Array<Text>)| (g.clone(), push(bs, &Text::lit("'static"))))))
}

/// ```prism
/// RustJob: unbounded fn JobDef -> Text
/// ```
pub fn rust_job(j: &crate::lower::model::JobDef) -> Text {
    let gnames = generic_names(&each(&j.generics, &(|(g, _): &(Text, Array<Text>)| g.clone())));
    let fields = crate::syntax::lexer::chars::join(&run_to_end(each_job(j.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (n, t) = p0;
        call_then(crate::emit::rust::start_type_(t.clone()), move |type__4062: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &n, &type__4062))))
    }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let params = crate::syntax::lexer::chars::join(&run_to_end(each_job(j.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (n, t) = p0;
        call_then(crate::emit::rust::start_type_(t.clone()), move |type__4136: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n, &type__4136))))
    }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "));
    let bounded_ = static_generics(&j.generics);
    let start = Text::from(format!("pub fn {}{}({}) -> Rc<dyn prism_rtl::Job<{}>>", &j.start, &bounded_, &params, &crate::emit::rust::type_(&j.ret)));
    let start_body = Text::from(format!("Rc::new({} {{ {} }})", &j.name, &crate::syntax::lexer::chars::join(&each(&j.fields, &(|(n, _): &(Text, crate::lower::model::OutTy)| n.clone())), &Text::lit(", "))));
    crate::emit::rust::templates::items::job(&crate::emit::rust::templates::source_doc(&Text::lit(""), &j.doc), &j.name, &gnames, &bounded_, &fields, &crate::emit::rust::type_(&j.ret), &crate::emit::rust::body_lines(&j.body), &start, &start_body)
}

/// The step machine of `RustJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustJob: unbounded fn JobDef -> Text
/// ```
pub struct RustJob {
    pub j: crate::lower::model::JobDef,
}

impl prism_rtl::Job<Text> for RustJob {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let j = &self.j;
        let gnames = generic_names(&each(&j.generics, &(|(g, _): &(Text, Array<Text>)| g.clone())));
        let j = j.clone();
        call_value(each_job(j.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
            let (n, t) = p0;
            call_then(crate::emit::rust::start_type_(t.clone()), move |type__4062: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &n, &type__4062))))
        }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_4024: Array<Text>| {
            let fields = crate::syntax::lexer::chars::join(&each_4024, &Text::lit("\n"));
            call_value(each_job(j.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
                let (n, t) = p0;
                call_then(crate::emit::rust::start_type_(t.clone()), move |type__4136: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n, &type__4136))))
            }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_4102: Array<Text>| {
                let params = crate::syntax::lexer::chars::join(&each_4102, &Text::lit(", "));
                let bounded_ = static_generics(&j.generics);
                call_then(crate::emit::rust::start_type_(j.ret.clone()), move |type__4360: Text| {
                    let start = Text::from(format!("pub fn {}{}({}) -> Rc<dyn prism_rtl::Job<{}>>", &j.start, &bounded_, &params, &type__4360));
                    let start_body = Text::from(format!("Rc::new({} {{ {} }})", &j.name, &crate::syntax::lexer::chars::join(&each(&j.fields, &(|(n, _): &(Text, crate::lower::model::OutTy)| n.clone())), &Text::lit(", "))));
                    call_then(crate::emit::rust::start_type_(j.ret.clone()), move |type__4535: Text| call_then(crate::emit::rust::start_body_lines(j.body.clone()), move |body_lines_4549: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::job(&crate::emit::rust::templates::source_doc(&Text::lit(""), &j.doc), &j.name, &gnames, &bounded_, &fields, &type__4535, &body_lines_4549, &start, &start_body))))
                })
            })
        })
    }
}

/// `Start RustJob, x`: what the function value is when passed to `@Run`.
pub fn start_rust_job(j: crate::lower::model::JobDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustJob { j })
}

/// ```prism
/// TypeDecl: unbounded fn TyDef -> Text
/// ```
pub fn type_decl(t: &crate::lower::model::TyDef) -> Text {
    let eq = t.eq && !t.floaty;
    let ord = t.ord && !t.floaty;
    let derives = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![Text::lit("Clone"), if t.eq || t.ord { Text::lit("PartialEq") } else { Text::lit("") }, if eq || ord { Text::lit("Eq") } else { Text::lit("") }, if t.ord { Text::lit("PartialOrd") } else { Text::lit("") }, if ord { Text::lit("Ord") } else { Text::lit("") }]), &(|d: &Text| d != &Text::lit(""))), &Text::lit(", "));
    let head = Text::from(format!("{}{}", &t.name, &generic_names(&t.params)));
    let doc = crate::emit::rust::templates::source_doc(&Text::from(format!("`{}`:", &t.prism)), &t.doc);
    let decl = match &t.shape {
        crate::lower::model::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            crate::emit::rust::templates::items::struct_(&doc, &derives, &head, &crate::syntax::lexer::chars::join(&run_to_end(each_job(c.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
                let (f, ft) = p0;
                call_then(crate::emit::rust::start_type_(ft.clone()), move |type__5309: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &f, &type__5309))))
            }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n")))
        },
        crate::lower::model::TyShape::ShapeUnit => crate::emit::rust::templates::items::tuple_struct(&doc, &derives, &head, &Text::lit("")),
        crate::lower::model::TyShape::ShapeNewtype => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            crate::emit::rust::templates::items::tuple_struct(&doc, &derives, &head, &Text::from(format!("({})", &crate::syntax::lexer::chars::join(&run_to_end(each_job(c.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
                let (_, ft) = p0;
                call_then(crate::emit::rust::start_type_(ft.clone()), move |type__5573: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}", &type__5573))))
            }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", ")))))
        },
        _ => crate::emit::rust::templates::items::enum_(&doc, &derives, &head, &crate::syntax::lexer::chars::join(&run_to_end(each_job(t.cases.clone(), Rc::new(move |p0: crate::lower::model::CaseDef| entered(once_job(move || {
            let c = p0;
            prism_rtl::Turn::More(Rc::new(EnumCase { c: c.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))),
    };
    let show_ = if &t.show == &crate::lower::model::Shown::ShownDerived {
        Text::from(format!("\n{}", &show_impl(t, &head)))
    } else {
        Text::lit("")
    };
    let pod = if t.pod {
        Text::from(format!("\n{}\n{}", &to_pod_impl(t, &head), &from_pod_impl(t, &head)))
    } else {
        Text::lit("")
    };
    Text::from(format!("{}{}{}", &decl, &show_, &pod))
}

/// The step machine of `TypeDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeDecl: unbounded fn TyDef -> Text
/// ```
pub struct TypeDecl {
    pub t: crate::lower::model::TyDef,
}

impl prism_rtl::Job<Text> for TypeDecl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        let eq = t.eq && !t.floaty;
        let ord = t.ord && !t.floaty;
        let derives = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![Text::lit("Clone"), if t.eq || t.ord { Text::lit("PartialEq") } else { Text::lit("") }, if eq || ord { Text::lit("Eq") } else { Text::lit("") }, if t.ord { Text::lit("PartialOrd") } else { Text::lit("") }, if ord { Text::lit("Ord") } else { Text::lit("") }]), &(|d: &Text| d != &Text::lit(""))), &Text::lit(", "));
        let head = Text::from(format!("{}{}", &t.name, &generic_names(&t.params)));
        let doc = crate::emit::rust::templates::source_doc(&Text::from(format!("`{}`:", &t.prism)), &t.doc);
        let decl = match &t.shape {
            crate::lower::model::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                crate::emit::rust::templates::items::struct_(&doc, &derives, &head, &crate::syntax::lexer::chars::join(&run_to_end(each_job(c.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
                    let (f, ft) = p0;
                    call_then(crate::emit::rust::start_type_(ft.clone()), move |type__5309: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &f, &type__5309))))
                }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n")))
            },
            crate::lower::model::TyShape::ShapeUnit => crate::emit::rust::templates::items::tuple_struct(&doc, &derives, &head, &Text::lit("")),
            crate::lower::model::TyShape::ShapeNewtype => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                crate::emit::rust::templates::items::tuple_struct(&doc, &derives, &head, &Text::from(format!("({})", &crate::syntax::lexer::chars::join(&run_to_end(each_job(c.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
                    let (_, ft) = p0;
                    call_then(crate::emit::rust::start_type_(ft.clone()), move |type__5573: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}", &type__5573))))
                }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", ")))))
            },
            _ => crate::emit::rust::templates::items::enum_(&doc, &derives, &head, &crate::syntax::lexer::chars::join(&run_to_end(each_job(t.cases.clone(), Rc::new(move |p0: crate::lower::model::CaseDef| entered(once_job(move || {
                let c = p0;
                prism_rtl::Turn::More(Rc::new(EnumCase { c: c.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))),
        };
        let show_ = if &t.show == &crate::lower::model::Shown::ShownDerived {
            Text::from(format!("\n{}", &show_impl(t, &head)))
        } else {
            Text::lit("")
        };
        let pod = if t.pod {
            Text::from(format!("\n{}\n{}", &to_pod_impl(t, &head), &from_pod_impl(t, &head)))
        } else {
            Text::lit("")
        };
        prism_rtl::Turn::Finished(Text::from(format!("{}{}{}", &decl, &show_, &pod)))
    }
}

/// `Start TypeDecl, x`: what the function value is when passed to `@Run`.
pub fn start_type_decl(t: crate::lower::model::TyDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TypeDecl { t })
}

/// ```prism
/// EnumCase: unbounded fn CaseDef -> Text
/// ```
pub fn enum_case(c: &crate::lower::model::CaseDef) -> Text {
    if &len(&c.fields) == &Nat::from(0u32) {
        Text::from(format!("{},", &c.name))
    } else {
        Text::from(format!("{}({}),", &c.name, &crate::syntax::lexer::chars::join(&run_to_end(each_job(c.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
            let (_, ft) = p0;
            prism_rtl::Turn::More(Rc::new(crate::emit::rust::Type { t: ft.clone() }))
        }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))))
    }
}

/// The step machine of `EnumCase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EnumCase: unbounded fn CaseDef -> Text
/// ```
pub struct EnumCase {
    pub c: crate::lower::model::CaseDef,
}

impl prism_rtl::Job<Text> for EnumCase {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let c = &self.c;
        if &len(&c.fields) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished(Text::from(format!("{},", &c.name)))
        } else {
            {
                let c = c.clone();
                call_value(each_job(c.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
                    let (_, ft) = p0;
                    prism_rtl::Turn::More(Rc::new(crate::emit::rust::Type { t: ft.clone() }))
                }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_5975: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{}({}),", &c.name, &crate::syntax::lexer::chars::join(&each_5975, &Text::lit(", "))))))
            }
        }
    }
}

/// `Start EnumCase, x`: what the function value is when passed to `@Run`.
pub fn start_enum_case(c: crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(EnumCase { c })
}

/// ```prism
/// Binders: fn Nat -> [Text]
/// ```
pub fn binders(n: &Nat) -> Array<Text> {
    each(&crate::check::errors::range0(n), &(|i: &Nat| Text::from(format!("a{}", i))))
}

/// ```prism
/// CasePattern: fn TyDef, CaseDef -> Text
/// ```
pub fn case_pattern(t: &crate::lower::model::TyDef, c: &crate::lower::model::CaseDef) -> Text {
    match &t.shape {
        crate::lower::model::TyShape::ShapeNewtype => Text::from(format!("{}({})", &t.name, &crate::syntax::lexer::chars::join(&binders(&len(&c.fields)), &Text::lit(", ")))),
        crate::lower::model::TyShape::ShapeUnit => t.name.clone(),
        _ => if &len(&c.fields) == &Nat::from(0u32) {
            Text::from(format!("{}::{}", &t.name, &c.name))
        } else {
            Text::from(format!("{}::{}({})", &t.name, &c.name, &crate::syntax::lexer::chars::join(&binders(&len(&c.fields)), &Text::lit(", "))))
        },
    }
}

/// ```prism
/// ShowImpl: unbounded fn TyDef, Text -> Text
/// ```
pub fn show_impl(t: &crate::lower::model::TyDef, head: &Text) -> Text {
    let body = match &t.shape {
        crate::lower::model::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            Text::from(format!("p.record(\"{}\", &[{}]);", &t.prism, &crate::syntax::lexer::chars::join(&each(&c.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("(\"{}\", &self.{})", &prism_field(f), f)))), &Text::lit(", "))))
        },
        _ => crate::emit::rust::templates::items::match_self(&crate::syntax::lexer::chars::join(&each(&t.cases, &(|c: &crate::lower::model::CaseDef| Text::from(format!("{} => p.choice(\"{}\", &[{}]),", &case_pattern(t, c), &c.prism, &crate::syntax::lexer::chars::join(&binders(&len(&c.fields)), &Text::lit(", ")))))), &Text::lit("\n"))),
    };
    crate::emit::rust::templates::items::impl_(&bounded(&t.params, &Text::lit("Show")), &Text::lit("Show"), head, &Text::lit("fn show(&self, p: &mut Printer)"), &body)
}

/// The step machine of `ShowImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowImpl: unbounded fn TyDef, Text -> Text
/// ```
pub struct ShowImpl {
    pub t: crate::lower::model::TyDef,
    pub head: Text,
}

impl prism_rtl::Job<Text> for ShowImpl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        let head = &self.head;
        let body = match &t.shape {
            crate::lower::model::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                Text::from(format!("p.record(\"{}\", &[{}]);", &t.prism, &crate::syntax::lexer::chars::join(&each(&c.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("(\"{}\", &self.{})", &prism_field(f), f)))), &Text::lit(", "))))
            },
            _ => crate::emit::rust::templates::items::match_self(&crate::syntax::lexer::chars::join(&each(&t.cases, &(|c: &crate::lower::model::CaseDef| Text::from(format!("{} => p.choice(\"{}\", &[{}]),", &case_pattern(t, c), &c.prism, &crate::syntax::lexer::chars::join(&binders(&len(&c.fields)), &Text::lit(", ")))))), &Text::lit("\n"))),
        };
        prism_rtl::Turn::Finished(crate::emit::rust::templates::items::impl_(&bounded(&t.params, &Text::lit("Show")), &Text::lit("Show"), head, &Text::lit("fn show(&self, p: &mut Printer)"), &body))
    }
}

/// `Start ShowImpl, x`: what the function value is when passed to `@Run`.
pub fn start_show_impl(t: crate::lower::model::TyDef, head: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ShowImpl { t, head })
}

/// ```prism
/// PrismField: fn Text -> Text
/// ```
pub fn prism_field(f: &Text) -> Text {
    if &crate::syntax::lexer::chars::last_char(f) == &Text::lit("_") {
        crate::syntax::lexer::chars::before_last(f)
    } else {
        f.clone()
    }
}

/// ```prism
/// ToPodImpl: unbounded fn TyDef, Text -> Text
/// ```
pub fn to_pod_impl(t: &crate::lower::model::TyDef, head: &Text) -> Text {
    let body = match &t.shape {
        crate::lower::model::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            Text::from(format!("Pod::record(\"{}\", vec![{}])", &t.prism, &crate::syntax::lexer::chars::join(&each(&c.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("(\"{}\", self.{}.to_pod())", &prism_field(f), f)))), &Text::lit(", "))))
        },
        _ => crate::emit::rust::templates::items::match_self(&crate::syntax::lexer::chars::join(&each(&t.cases, &(|c: &crate::lower::model::CaseDef| Text::from(format!("{} => Pod::Choice(\"{}\".into(), vec![{}]),", &case_pattern(t, c), &c.prism, &crate::syntax::lexer::chars::join(&each(&binders(&len(&c.fields)), &(|b: &Text| Text::from(format!("{}.to_pod()", b)))), &Text::lit(", ")))))), &Text::lit("\n"))),
    };
    let shown = if &t.show == &crate::lower::model::Shown::ShownOwn {
        crate::emit::rust::templates::items::shown_pod(&body)
    } else {
        body.clone()
    };
    crate::emit::rust::templates::items::impl_(&bounded(&t.params, &Text::lit("ToPod")), &Text::lit("ToPod"), head, &Text::lit("fn to_pod(&self) -> Pod"), &shown)
}

/// The step machine of `ToPodImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ToPodImpl: unbounded fn TyDef, Text -> Text
/// ```
pub struct ToPodImpl {
    pub t: crate::lower::model::TyDef,
    pub head: Text,
}

impl prism_rtl::Job<Text> for ToPodImpl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        let head = &self.head;
        let body = match &t.shape {
            crate::lower::model::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                Text::from(format!("Pod::record(\"{}\", vec![{}])", &t.prism, &crate::syntax::lexer::chars::join(&each(&c.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("(\"{}\", self.{}.to_pod())", &prism_field(f), f)))), &Text::lit(", "))))
            },
            _ => crate::emit::rust::templates::items::match_self(&crate::syntax::lexer::chars::join(&each(&t.cases, &(|c: &crate::lower::model::CaseDef| Text::from(format!("{} => Pod::Choice(\"{}\".into(), vec![{}]),", &case_pattern(t, c), &c.prism, &crate::syntax::lexer::chars::join(&each(&binders(&len(&c.fields)), &(|b: &Text| Text::from(format!("{}.to_pod()", b)))), &Text::lit(", ")))))), &Text::lit("\n"))),
        };
        let shown = if &t.show == &crate::lower::model::Shown::ShownOwn {
            crate::emit::rust::templates::items::shown_pod(&body)
        } else {
            body.clone()
        };
        prism_rtl::Turn::Finished(crate::emit::rust::templates::items::impl_(&bounded(&t.params, &Text::lit("ToPod")), &Text::lit("ToPod"), head, &Text::lit("fn to_pod(&self) -> Pod"), &shown))
    }
}

/// `Start ToPodImpl, x`: what the function value is when passed to `@Run`.
pub fn start_to_pod_impl(t: crate::lower::model::TyDef, head: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ToPodImpl { t, head })
}

/// ```prism
/// FromPodImpl: unbounded fn TyDef, Text -> Text
/// ```
pub fn from_pod_impl(t: &crate::lower::model::TyDef, head: &Text) -> Text {
    let body = match &t.shape {
        crate::lower::model::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            Text::from(format!("Ok({} {{ {} }})", &t.name, &crate::syntax::lexer::chars::join(&each(&c.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{}: FromPod::from_pod(field(p, \"{}\")?)?", f, &prism_field(f))))), &Text::lit(", "))))
        },
        _ => {
            let arms = each(&t.cases, &(|c: &crate::lower::model::CaseDef| {
                let n = len(&c.fields);
                let made = if &n == &Nat::from(0u32) {
                    if &t.shape == &crate::lower::model::TyShape::ShapeUnit {
                        t.name.clone()
                    } else {
                        Text::from(format!("{}::{}", &t.name, &c.name))
                    }
                } else {
                    Text::from(format!("{}({})", &(if &t.shape == &crate::lower::model::TyShape::ShapeNewtype {
                        t.name.clone()
                    } else {
                        Text::from(format!("{}::{}", &t.name, &c.name))
                    }), &crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&n), &(|i: &Nat| Text::from(format!("FromPod::from_pod(&a[{}])?", i)))), &Text::lit(", "))))
                };
                Text::from(format!("Pod::Choice(c, a) if &**c == \"{}\" && a.len() == {} => Ok({}),", &c.prism, &n, &made))
            }));
            crate::emit::rust::templates::items::from_pod_body(&crate::syntax::lexer::chars::join(&arms, &Text::lit("\n")), &Text::from(format!("a {}", &t.prism)))
        },
    };
    crate::emit::rust::templates::items::impl_(&bounded(&t.params, &Text::lit("FromPod")), &Text::lit("FromPod"), head, &Text::lit("fn from_pod(p: &Pod) -> Result<Self, Fault>"), &body)
}

/// The step machine of `FromPodImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FromPodImpl: unbounded fn TyDef, Text -> Text
/// ```
pub struct FromPodImpl {
    pub t: crate::lower::model::TyDef,
    pub head: Text,
}

impl prism_rtl::Job<Text> for FromPodImpl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        let head = &self.head;
        let body = match &t.shape {
            crate::lower::model::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                Text::from(format!("Ok({} {{ {} }})", &t.name, &crate::syntax::lexer::chars::join(&each(&c.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{}: FromPod::from_pod(field(p, \"{}\")?)?", f, &prism_field(f))))), &Text::lit(", "))))
            },
            _ => {
                let arms = each(&t.cases, &(|c: &crate::lower::model::CaseDef| {
                    let n = len(&c.fields);
                    let made = if &n == &Nat::from(0u32) {
                        if &t.shape == &crate::lower::model::TyShape::ShapeUnit {
                            t.name.clone()
                        } else {
                            Text::from(format!("{}::{}", &t.name, &c.name))
                        }
                    } else {
                        Text::from(format!("{}({})", &(if &t.shape == &crate::lower::model::TyShape::ShapeNewtype {
                            t.name.clone()
                        } else {
                            Text::from(format!("{}::{}", &t.name, &c.name))
                        }), &crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&n), &(|i: &Nat| Text::from(format!("FromPod::from_pod(&a[{}])?", i)))), &Text::lit(", "))))
                    };
                    Text::from(format!("Pod::Choice(c, a) if &**c == \"{}\" && a.len() == {} => Ok({}),", &c.prism, &n, &made))
                }));
                crate::emit::rust::templates::items::from_pod_body(&crate::syntax::lexer::chars::join(&arms, &Text::lit("\n")), &Text::from(format!("a {}", &t.prism)))
            },
        };
        prism_rtl::Turn::Finished(crate::emit::rust::templates::items::impl_(&bounded(&t.params, &Text::lit("FromPod")), &Text::lit("FromPod"), head, &Text::lit("fn from_pod(p: &Pod) -> Result<Self, Fault>"), &body))
    }
}

/// `Start FromPodImpl, x`: what the function value is when passed to `@Run`.
pub fn start_from_pod_impl(t: crate::lower::model::TyDef, head: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FromPodImpl { t, head })
}

/// ```prism
/// RustTag: unbounded fn TagDef -> Text
/// ```
pub fn rust_tag(t: &crate::lower::model::TagDef) -> Text {
    let fields = crate::syntax::lexer::chars::join(&run_to_end(each_job(t.fields.clone(), Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (_, f, ft) = p0;
        call_then(crate::emit::rust::start_type_(ft.clone()), move |type__8982: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &f, &type__8982))))
    }))) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let pods = crate::syntax::lexer::chars::join(&each(&t.fields, &(|(p_, f, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("(\"{}\", self.{}.to_pod())", p_, f)))), &Text::lit(", "));
    let derives = if t.pod { Text::lit("Clone, PartialEq") } else { Text::lit("Clone") };
    let reads = crate::syntax::lexer::chars::join(&each(&t.fields, &(|(p_, f, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("{}: FromPod::from_pod(field(p, \"{}\")?)?", f, p_)))), &Text::lit(", "));
    let back_ = if t.pod {
        Text::from(format!("\n{}", &crate::emit::rust::templates::items::tag_from_pod(&t.name, &t.tag_name, &reads)))
    } else {
        Text::lit("")
    };
    Text::from(format!("{}{}", &crate::emit::rust::templates::items::tag(&crate::emit::rust::templates::source_doc(&Text::from(format!("The `Level` of `{}`:", &t.tag_name)), &t.doc), &derives, &t.name, &fields, &t.tag_name, &pods), &back_))
}

/// The step machine of `RustTag`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustTag: unbounded fn TagDef -> Text
/// ```
pub struct RustTag {
    pub t: crate::lower::model::TagDef,
}

impl prism_rtl::Job<Text> for RustTag {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        let t = t.clone();
        call_value(each_job(t.fields.clone(), Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| entered(once_job(move || {
            let (_, f, ft) = p0;
            call_then(crate::emit::rust::start_type_(ft.clone()), move |type__8982: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &f, &type__8982))))
        }))) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_8935: Array<Text>| {
            let fields = crate::syntax::lexer::chars::join(&each_8935, &Text::lit("\n"));
            let pods = crate::syntax::lexer::chars::join(&each(&t.fields, &(|(p_, f, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("(\"{}\", self.{}.to_pod())", p_, f)))), &Text::lit(", "));
            let derives = if t.pod { Text::lit("Clone, PartialEq") } else { Text::lit("Clone") };
            let reads = crate::syntax::lexer::chars::join(&each(&t.fields, &(|(p_, f, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("{}: FromPod::from_pod(field(p, \"{}\")?)?", f, p_)))), &Text::lit(", "));
            let back_ = if t.pod {
                Text::from(format!("\n{}", &crate::emit::rust::templates::items::tag_from_pod(&t.name, &t.tag_name, &reads)))
            } else {
                Text::lit("")
            };
            prism_rtl::Turn::Finished(Text::from(format!("{}{}", &crate::emit::rust::templates::items::tag(&crate::emit::rust::templates::source_doc(&Text::from(format!("The `Level` of `{}`:", &t.tag_name)), &t.doc), &derives, &t.name, &fields, &t.tag_name, &pods), &back_)))
        })
    }
}

/// `Start RustTag, x`: what the function value is when passed to `@Run`.
pub fn start_rust_tag(t: crate::lower::model::TagDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustTag { t })
}

/// ```prism
/// RustRow: unbounded fn RowDef -> Text
/// ```
pub fn rust_row(r: &crate::lower::model::RowDef) -> Text {
    let derives = if r.pod { Text::lit("Clone, PartialEq") } else { Text::lit("Clone") };
    let cases = crate::syntax::lexer::chars::join(&each(&r.cases, &(|(v_, st): &(Text, Text)| Text::from(format!("{}({}),", v_, st)))), &Text::lit("\n"));
    let pods = crate::syntax::lexer::chars::join(&each(&r.cases, &(|(v_, _): &(Text, Text)| Text::from(format!("{}::{}(x) => x.to_pod(),", &r.name, v_)))), &Text::lit("\n"));
    let reads = crate::syntax::lexer::chars::join(&each(&r.cases, &(|(v_, st): &(Text, Text)| Text::from(format!("Some(t) if t == {}::TAG => Ok({}::{}(FromPod::from_pod(p)?)),", st, &r.name, v_)))), &Text::lit("\n"));
    let back_ = if r.pod {
        Text::from(format!("\n{}", &crate::emit::rust::templates::items::row_from_pod(&r.name, &reads)))
    } else {
        Text::lit("")
    };
    let pods2 = if &len(&r.cases) == &Nat::from(0u32) {
        Text::lit("_ => unreachable!(),")
    } else {
        pods.clone()
    };
    Text::from(format!("{}{}", &crate::emit::rust::templates::items::row(&crate::emit::rust::templates::source_doc(&Text::from(format!("`{}`, a row kind's values:", &r.prism)), &r.doc), &derives, &r.name, &cases, &pods2), &back_))
}

/// The step machine of `RustRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustRow: unbounded fn RowDef -> Text
/// ```
pub struct RustRow {
    pub r: crate::lower::model::RowDef,
}

impl prism_rtl::Job<Text> for RustRow {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let r = &self.r;
        let derives = if r.pod { Text::lit("Clone, PartialEq") } else { Text::lit("Clone") };
        let cases = crate::syntax::lexer::chars::join(&each(&r.cases, &(|(v_, st): &(Text, Text)| Text::from(format!("{}({}),", v_, st)))), &Text::lit("\n"));
        let pods = crate::syntax::lexer::chars::join(&each(&r.cases, &(|(v_, _): &(Text, Text)| Text::from(format!("{}::{}(x) => x.to_pod(),", &r.name, v_)))), &Text::lit("\n"));
        let reads = crate::syntax::lexer::chars::join(&each(&r.cases, &(|(v_, st): &(Text, Text)| Text::from(format!("Some(t) if t == {}::TAG => Ok({}::{}(FromPod::from_pod(p)?)),", st, &r.name, v_)))), &Text::lit("\n"));
        let back_ = if r.pod {
            Text::from(format!("\n{}", &crate::emit::rust::templates::items::row_from_pod(&r.name, &reads)))
        } else {
            Text::lit("")
        };
        let pods2 = if &len(&r.cases) == &Nat::from(0u32) {
            Text::lit("_ => unreachable!(),")
        } else {
            pods.clone()
        };
        prism_rtl::Turn::Finished(Text::from(format!("{}{}", &crate::emit::rust::templates::items::row(&crate::emit::rust::templates::source_doc(&Text::from(format!("`{}`, a row kind's values:", &r.prism)), &r.doc), &derives, &r.name, &cases, &pods2), &back_)))
    }
}

/// `Start RustRow, x`: what the function value is when passed to `@Run`.
pub fn start_rust_row(r: crate::lower::model::RowDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustRow { r })
}

/// ```prism
/// RustAnswer: unbounded fn AnswerDef -> Text
/// ```
pub fn rust_answer(a: &crate::lower::model::AnswerDef) -> Text {
    let cases = crate::syntax::lexer::chars::join(&run_to_end(each_job(a.cases.clone(), Rc::new(move |p0: crate::lower::model::AnswerCase| entered(once_job(move || {
        let c = p0;
        call_then(crate::emit::rust::start_type_(c.ty.clone()), move |type__10639: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({}),", &c.variant, &type__10639))))
    }))) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let tags = if &len(&a.cases) == &Nat::from(0u32) {
        Text::lit("_ => unreachable!(),")
    } else {
        crate::syntax::lexer::chars::join(&each(&a.cases, &(|c: &crate::lower::model::AnswerCase| Text::from(format!("Answer::{}(_) => {}::TAG,", &c.variant, &c.struct_path)))), &Text::lit("\n"))
    };
    let accessors = crate::syntax::lexer::chars::join(&run_to_end(each_job(a.cases.clone(), Rc::new(move |p0: crate::lower::model::AnswerCase| entered(once_job(move || {
        let c = p0;
        call_then(crate::emit::rust::start_type_(c.ty.clone()), move |type__10901: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::answer_getter(&c.accessor, &c.variant, &c.tag_name, &type__10901)))
    }))) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let decodes = if &len(&a.cases) == &Nat::from(0u32) {
        Text::lit("_ => unreachable!(),")
    } else {
        crate::syntax::lexer::chars::join(&run_to_end(each_job(a.cases.clone(), Rc::new(move |p0: crate::lower::model::AnswerCase| entered(once_job(move || {
            let c = p0;
            call_then(crate::emit::rust::start_decode_head(c.ty.clone()), move |decode_head_11064: Text| prism_rtl::Turn::Finished(Text::from(format!("Elem::{}(..) => Ok(Answer::{}({}::from_pod(v)?)),", &c.variant, &c.variant, &decode_head_11064))))
        }))) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))
    };
    crate::emit::rust::templates::items::answer_type(&cases, &tags, &accessors, &decodes)
}

/// The step machine of `RustAnswer`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustAnswer: unbounded fn AnswerDef -> Text
/// ```
pub struct RustAnswer {
    pub a: crate::lower::model::AnswerDef,
}

impl prism_rtl::Job<Text> for RustAnswer {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let a = &self.a;
        let a = a.clone();
        call_value(each_job(a.cases.clone(), Rc::new(move |p0: crate::lower::model::AnswerCase| entered(once_job(move || {
            let c = p0;
            call_then(crate::emit::rust::start_type_(c.ty.clone()), move |type__10639: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({}),", &c.variant, &type__10639))))
        }))) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_10606: Array<Text>| {
            let cases = crate::syntax::lexer::chars::join(&each_10606, &Text::lit("\n"));
            let tags = if &len(&a.cases) == &Nat::from(0u32) {
                Text::lit("_ => unreachable!(),")
            } else {
                crate::syntax::lexer::chars::join(&each(&a.cases, &(|c: &crate::lower::model::AnswerCase| Text::from(format!("Answer::{}(_) => {}::TAG,", &c.variant, &c.struct_path)))), &Text::lit("\n"))
            };
            call_value(each_job(a.cases.clone(), Rc::new(move |p0: crate::lower::model::AnswerCase| entered(once_job(move || {
                let c = p0;
                call_then(crate::emit::rust::start_type_(c.ty.clone()), move |type__10901: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::answer_getter(&c.accessor, &c.variant, &c.tag_name, &type__10901)))
            }))) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_10834: Array<Text>| {
                let accessors = crate::syntax::lexer::chars::join(&each_10834, &Text::lit("\n"));
                let decodes = if &len(&a.cases) == &Nat::from(0u32) {
                    Text::lit("_ => unreachable!(),")
                } else {
                    crate::syntax::lexer::chars::join(&run_to_end(each_job(a.cases.clone(), Rc::new(move |p0: crate::lower::model::AnswerCase| entered(once_job(move || {
                        let c = p0;
                        call_then(crate::emit::rust::start_decode_head(c.ty.clone()), move |decode_head_11064: Text| prism_rtl::Turn::Finished(Text::from(format!("Elem::{}(..) => Ok(Answer::{}({}::from_pod(v)?)),", &c.variant, &c.variant, &decode_head_11064))))
                    }))) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))
                };
                prism_rtl::Turn::Finished(crate::emit::rust::templates::items::answer_type(&cases, &tags, &accessors, &decodes))
            })
        })
    }
}

/// `Start RustAnswer, x`: what the function value is when passed to `@Run`.
pub fn start_rust_answer(a: crate::lower::model::AnswerDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustAnswer { a })
}

/// ```prism
/// RustNode: unbounded fn NodeDef -> Text
/// ```
pub fn rust_node(n: &crate::lower::model::NodeDef) -> Text {
    let fields = crate::syntax::lexer::chars::join(&run_to_end(each_job(n.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy, Text)| entered(once_job(move || {
        let (f, t, doc) = p0;
        call_then(crate::emit::rust::start_type_(t.clone()), move |type__11481: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}: {},", &crate::emit::rust::templates::doc(&doc), &f, &type__11481))))
    }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let consts = concat(&each(&n.consts, &(|(c, h, doc): &(Text, Nat, Text)| Text::from(format!("{}const {}: u32 = {};\n", &crate::emit::rust::templates::doc(&Text::from(format!("The {}.", doc))), c, h)))));
    let params = concat(&run_to_end(each_job(n.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (p_, t) = p0;
        call_then(crate::emit::rust::start_type_(t.clone()), move |type__11659: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}, ", &p_, &type__11659))))
    }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)));
    let ret = if n.fallible {
        Text::from(format!("Result<Rc<{}>, Fault>", &n.name))
    } else {
        Text::from(format!("Rc<{}>", &n.name))
    };
    let inits = crate::syntax::lexer::chars::join(&append(&Array::from(vec![Text::lit("path")]), &run_to_end(each_job(n.inits.clone(), Rc::new(move |p0: (Text, crate::lower::model::Ex)| entered(once_job(move || {
        let (f, v_) = p0;
        prism_rtl::Turn::More(Rc::new(crate::emit::rust::FieldInit { f: f.clone(), ex1: v_.clone() }))
    }))) as Rc<dyn Fn((Text, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>))), &Text::lit(", "));
    let tail = if n.fallible { Text::lit("Ok(node)") } else { Text::lit("node") };
    let rest_text = if &len(&n.build) == &Nat::from(0u32) {
        tail.clone()
    } else {
        Text::from(format!("{}\n{}", &crate::emit::rust::statements(&n.build), &tail))
    };
    let build = crate::emit::rust::templates::items::build(&n.name, &params, &ret, &crate::emit::rust::statements(&n.lets), &inits, &rest_text);
    let methods = crate::syntax::lexer::chars::join(&run_to_end(each_job(n.methods.clone(), Rc::new(move |p0: crate::lower::model::MethDef| entered(once_job(move || {
        let m = p0;
        prism_rtl::Turn::More(Rc::new(RustMethod { m: m.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let answer = if &len(&n.answers) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        crate::emit::rust::templates::items::answer(&crate::syntax::lexer::chars::join(&run_to_end(each_job(n.answers.clone(), Rc::new(move |p0: (crate::lower::model::Pa, crate::lower::model::Ex)| entered(once_job(move || {
            let (pat, call) = p0;
            call_then(crate::emit::rust::start_pattern(pat.clone()), move |pattern_12225: Text| call_then(crate::emit::rust::start_expression(call.clone()), move |expression_12242: Text| prism_rtl::Turn::Finished(Text::from(format!("{} => {},", &pattern_12225, &expression_12242)))))
        }))) as Rc<dyn Fn((crate::lower::model::Pa, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n")))
    };
    let builders = concat(&append(&run_to_end(each_job(n.builders.clone(), Rc::new(move |p0: crate::lower::model::ForDef| entered(once_job(move || {
        let b = p0;
        call_then(start_for_builder(b.clone()), move |for_builder_12330: Text| prism_rtl::Turn::Finished(Text::from(format!("\n{}", &for_builder_12330))))
    }))) as Rc<dyn Fn(crate::lower::model::ForDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &run_to_end(each_job(n.gens.clone(), Rc::new(move |p0: crate::lower::model::GenDef| entered(once_job(move || {
        let gd = p0;
        call_then(start_gen_builder(gd.clone()), move |gen_builder_12371: Text| prism_rtl::Turn::Finished(Text::from(format!("\n{}", &gen_builder_12371))))
    }))) as Rc<dyn Fn(crate::lower::model::GenDef) -> Rc<dyn prism_rtl::Job<Text>>>))));
    let row_impl = if &n.row_kind == &crate::lower::model::RowKind::NotARow {
        Text::lit("")
    } else {
        Text::from(format!("\n{}", &rust_row_impl(n)))
    };
    let hooks = crate::syntax::lexer::chars::join(&run_to_end(each_job(n.hooks.clone(), Rc::new(move |p0: (Text, Array<crate::lower::model::Do>)| entered(once_job(move || {
        let (h, body) = p0;
        if &h == &Text::lit("push") {
            call_then(crate::emit::rust::start_statements(body.clone()), move |statements_12538: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::push_hook(&statements_12538)))
        } else {
            call_then(crate::emit::rust::start_statements(body.clone()), move |statements_12570: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::hook(&h, &statements_12570)))
        }
    }))) as Rc<dyn Fn((Text, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let doc = crate::emit::rust::templates::source_doc(&Text::from(format!("`{}`: a node of its own (claude/backend.md, \"A widget block\").", &n.prism)), &n.doc);
    Text::from(format!("{}{}", &crate::emit::rust::templates::items::node_(&doc, &n.name, &fields, &consts, &build, &Text::from(format!("{}{}", &methods, &builders)), &hooks, &answer), &row_impl))
}

/// The step machine of `RustNode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustNode: unbounded fn NodeDef -> Text
/// ```
pub struct RustNode {
    pub n: crate::lower::model::NodeDef,
}

impl prism_rtl::Job<Text> for RustNode {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let n = &self.n;
        let n = n.clone();
        call_value(each_job(n.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy, Text)| entered(once_job(move || {
            let (f, t, doc) = p0;
            call_then(crate::emit::rust::start_type_(t.clone()), move |type__11481: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}: {},", &crate::emit::rust::templates::doc(&doc), &f, &type__11481))))
        }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_11433: Array<Text>| {
            let fields = crate::syntax::lexer::chars::join(&each_11433, &Text::lit("\n"));
            let consts = concat(&each(&n.consts, &(|(c, h, doc): &(Text, Nat, Text)| Text::from(format!("{}const {}: u32 = {};\n", &crate::emit::rust::templates::doc(&Text::from(format!("The {}.", doc))), c, h)))));
            call_value(each_job(n.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
                let (p_, t) = p0;
                call_then(crate::emit::rust::start_type_(t.clone()), move |type__11659: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}, ", &p_, &type__11659))))
            }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_11625: Array<Text>| {
                let params = concat(&each_11625);
                let ret = if n.fallible {
                    Text::from(format!("Result<Rc<{}>, Fault>", &n.name))
                } else {
                    Text::from(format!("Rc<{}>", &n.name))
                };
                call_value(each_job(n.inits.clone(), Rc::new(move |p0: (Text, crate::lower::model::Ex)| entered(once_job(move || {
                    let (f, v_) = p0;
                    prism_rtl::Turn::More(Rc::new(crate::emit::rust::FieldInit { f: f.clone(), ex1: v_.clone() }))
                }))) as Rc<dyn Fn((Text, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_11793: Array<Text>| {
                    let inits = crate::syntax::lexer::chars::join(&append(&Array::from(vec![Text::lit("path")]), &each_11793), &Text::lit(", "));
                    let tail = if n.fallible { Text::lit("Ok(node)") } else { Text::lit("node") };
                    let rest_text = if &len(&n.build) == &Nat::from(0u32) {
                        tail.clone()
                    } else {
                        Text::from(format!("{}\n{}", &crate::emit::rust::statements(&n.build), &tail))
                    };
                    call_then(crate::emit::rust::start_statements(n.lets.clone()), move |statements_12024: Text| {
                        let build = crate::emit::rust::templates::items::build(&n.name, &params, &ret, &statements_12024, &inits, &rest_text);
                        call_value(each_job(n.methods.clone(), Rc::new(move |p0: crate::lower::model::MethDef| entered(once_job(move || {
                            let m = p0;
                            prism_rtl::Turn::More(Rc::new(RustMethod { m: m.clone() }))
                        }))) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_12084: Array<Text>| {
                            let methods = crate::syntax::lexer::chars::join(&each_12084, &Text::lit("\n"));
                            let answer = if &len(&n.answers) == &Nat::from(0u32) {
                                Text::lit("")
                            } else {
                                crate::emit::rust::templates::items::answer(&crate::syntax::lexer::chars::join(&run_to_end(each_job(n.answers.clone(), Rc::new(move |p0: (crate::lower::model::Pa, crate::lower::model::Ex)| entered(once_job(move || {
                                    let (pat, call) = p0;
                                    call_then(crate::emit::rust::start_pattern(pat.clone()), move |pattern_12225: Text| call_then(crate::emit::rust::start_expression(call.clone()), move |expression_12242: Text| prism_rtl::Turn::Finished(Text::from(format!("{} => {},", &pattern_12225, &expression_12242)))))
                                }))) as Rc<dyn Fn((crate::lower::model::Pa, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n")))
                            };
                            call_value(each_job(n.builders.clone(), Rc::new(move |p0: crate::lower::model::ForDef| entered(once_job(move || {
                                let b = p0;
                                call_then(start_for_builder(b.clone()), move |for_builder_12330: Text| prism_rtl::Turn::Finished(Text::from(format!("\n{}", &for_builder_12330))))
                            }))) as Rc<dyn Fn(crate::lower::model::ForDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_12304: Array<Text>| call_value(each_job(n.gens.clone(), Rc::new(move |p0: crate::lower::model::GenDef| entered(once_job(move || {
                                let gd = p0;
                                call_then(start_gen_builder(gd.clone()), move |gen_builder_12371: Text| prism_rtl::Turn::Finished(Text::from(format!("\n{}", &gen_builder_12371))))
                            }))) as Rc<dyn Fn(crate::lower::model::GenDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_12348: Array<Text>| {
                                let builders = concat(&append(&each_12304, &each_12348));
                                let row_impl = if &n.row_kind == &crate::lower::model::RowKind::NotARow {
                                    Text::lit("")
                                } else {
                                    Text::from(format!("\n{}", &rust_row_impl(&n)))
                                };
                                call_value(each_job(n.hooks.clone(), Rc::new(move |p0: (Text, Array<crate::lower::model::Do>)| entered(once_job(move || {
                                    let (h, body) = p0;
                                    if &h == &Text::lit("push") {
                                        call_then(crate::emit::rust::start_statements(body.clone()), move |statements_12538: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::push_hook(&statements_12538)))
                                    } else {
                                        call_then(crate::emit::rust::start_statements(body.clone()), move |statements_12570: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::hook(&h, &statements_12570)))
                                    }
                                }))) as Rc<dyn Fn((Text, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_12483: Array<Text>| {
                                    let hooks = crate::syntax::lexer::chars::join(&each_12483, &Text::lit("\n"));
                                    let doc = crate::emit::rust::templates::source_doc(&Text::from(format!("`{}`: a node of its own (claude/backend.md, \"A widget block\").", &n.prism)), &n.doc);
                                    prism_rtl::Turn::Finished(Text::from(format!("{}{}", &crate::emit::rust::templates::items::node_(&doc, &n.name, &fields, &consts, &build, &Text::from(format!("{}{}", &methods, &builders)), &hooks, &answer), &row_impl)))
                                })
                            }))
                        })
                    })
                })
            })
        })
    }
}

/// `Start RustNode, x`: what the function value is when passed to `@Run`.
pub fn start_rust_node(n: crate::lower::model::NodeDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustNode { n })
}

/// ```prism
/// ForBuilder: unbounded fn ForDef -> Text
/// ```
pub fn for_builder(b: &crate::lower::model::ForDef) -> Text {
    crate::emit::rust::templates::items::for_build(&b.name, &crate::emit::rust::expression(&b.at), &crate::emit::rust::type_(&b.key_ty), &crate::emit::rust::type_(&b.value_ty), &b.row_node, &b.source, &crate::emit::rust::expression(&b.parent), &concat(&run_to_end(each_job(b.passed.clone(), Rc::new(move |p0: crate::lower::model::Ex| entered(once_job(move || {
        let x = p0;
        call_then(crate::emit::rust::start_expression(x.clone()), move |expression_13063: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}", &expression_13063))))
    }))) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>))))
}

/// The step machine of `ForBuilder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ForBuilder: unbounded fn ForDef -> Text
/// ```
pub struct ForBuilder {
    pub b: crate::lower::model::ForDef,
}

impl prism_rtl::Job<Text> for ForBuilder {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let b = &self.b;
        let b = b.clone();
        call_then(crate::emit::rust::start_expression(b.at.clone()), move |expression_12934: Text| call_then(crate::emit::rust::start_type_(b.key_ty.clone()), move |type__12953: Text| call_then(crate::emit::rust::start_type_(b.value_ty.clone()), move |type__12969: Text| call_then(crate::emit::rust::start_expression(b.parent.clone()), move |expression_13008: Text| call_value(each_job(b.passed.clone(), Rc::new(move |p0: crate::lower::model::Ex| entered(once_job(move || {
            let x = p0;
            call_then(crate::emit::rust::start_expression(x.clone()), move |expression_13063: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}", &expression_13063))))
        }))) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_13039: Array<Text>| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::for_build(&b.name, &expression_12934, &type__12953, &type__12969, &b.row_node, &b.source, &expression_13008, &concat(&each_13039))))))))
    }
}

/// `Start ForBuilder, x`: what the function value is when passed to `@Run`.
pub fn start_for_builder(b: crate::lower::model::ForDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ForBuilder { b })
}

/// ```prism
/// GenBuilder: unbounded fn GenDef -> Text
/// ```
pub fn gen_builder(gd: &crate::lower::model::GenDef) -> Text {
    let path_ = if gd.transparent {
        Text::lit("self.path.clone()")
    } else {
        Text::from(format!("{}.child(Segment::Gen(g))", &crate::emit::rust::expression(&gd.at)))
    };
    crate::emit::rust::templates::items::gen_build(&gd.name, &crate::emit::rust::expression(&gd.at), &path_, &crate::emit::rust::expression(&gd.source), &crate::emit::rust::type_(&gd.value_ty), &crate::emit::rust::expression(&gd.select))
}

/// The step machine of `GenBuilder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GenBuilder: unbounded fn GenDef -> Text
/// ```
pub struct GenBuilder {
    pub gd: crate::lower::model::GenDef,
}

impl prism_rtl::Job<Text> for GenBuilder {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let gd = &self.gd;
        let path_ = if gd.transparent {
            Text::lit("self.path.clone()")
        } else {
            Text::from(format!("{}.child(Segment::Gen(g))", &crate::emit::rust::expression(&gd.at)))
        };
        let gd = gd.clone();
        call_then(crate::emit::rust::start_expression(gd.at.clone()), move |expression_13457: Text| call_then(crate::emit::rust::start_expression(gd.source.clone()), move |expression_13483: Text| call_then(crate::emit::rust::start_type_(gd.value_ty.clone()), move |type__13507: Text| call_then(crate::emit::rust::start_expression(gd.select.clone()), move |expression_13526: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::gen_build(&gd.name, &expression_13457, &path_, &expression_13483, &type__13507, &expression_13526))))))
    }
}

/// `Start GenBuilder, x`: what the function value is when passed to `@Run`.
pub fn start_gen_builder(gd: crate::lower::model::GenDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(GenBuilder { gd })
}

/// ```prism
/// RustRowImpl: unbounded fn NodeDef -> Text
/// ```
pub fn rust_row_impl(n: &crate::lower::model::NodeDef) -> Text {
    let kept = if &n.row_kind == &crate::lower::model::RowKind::ForRow {
        Array::from(vec![Text::lit("*self.left_entry.borrow_mut() = Some(self.entry(cx));")])
    } else {
        Array::new()
    };
    let unsubscribe = each(&n.subs, &(|(ev, m, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("if let (Some(p), Some(h)) = (self.parent.upgrade(), self.{}_sub.take()) {{\n    p.{}_port.unsubscribe(h);\n}}", m, ev))));
    crate::emit::rust::templates::items::row_impl(&n.name, &crate::syntax::lexer::chars::join(&append(&push(&kept, &Text::lit("self.remove_places(cx);")), &unsubscribe), &Text::lit("\n")), &crate::syntax::lexer::chars::join(&run_to_end(each_job(n.hosted.clone(), Rc::new(move |p0: crate::lower::model::MethDef| entered(once_job(move || {
        let m = p0;
        prism_rtl::Turn::More(Rc::new(RustMethod { m: m.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n")))
}

/// The step machine of `RustRowImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustRowImpl: unbounded fn NodeDef -> Text
/// ```
pub struct RustRowImpl {
    pub n: crate::lower::model::NodeDef,
}

impl prism_rtl::Job<Text> for RustRowImpl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let n = &self.n;
        let kept = if &n.row_kind == &crate::lower::model::RowKind::ForRow {
            Array::from(vec![Text::lit("*self.left_entry.borrow_mut() = Some(self.entry(cx));")])
        } else {
            Array::new()
        };
        let unsubscribe = each(&n.subs, &(|(ev, m, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("if let (Some(p), Some(h)) = (self.parent.upgrade(), self.{}_sub.take()) {{\n    p.{}_port.unsubscribe(h);\n}}", m, ev))));
        let n = n.clone();
        call_value(each_job(n.hosted.clone(), Rc::new(move |p0: crate::lower::model::MethDef| entered(once_job(move || {
            let m = p0;
            prism_rtl::Turn::More(Rc::new(RustMethod { m: m.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_14224: Array<Text>| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::row_impl(&n.name, &crate::syntax::lexer::chars::join(&append(&push(&kept, &Text::lit("self.remove_places(cx);")), &unsubscribe), &Text::lit("\n")), &crate::syntax::lexer::chars::join(&each_14224, &Text::lit("\n")))))
    }
}

/// `Start RustRowImpl, x`: what the function value is when passed to `@Run`.
pub fn start_rust_row_impl(n: crate::lower::model::NodeDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustRowImpl { n })
}

/// ```prism
/// RustMethod: unbounded fn MethDef -> Text
/// ```
pub fn rust_method(m: &crate::lower::model::MethDef) -> Text {
    let recv = match &m.recv {
        crate::lower::model::Recv::RecvRc => Text::lit("self: &Rc<Self>"),
        crate::lower::model::Recv::RecvRef => Text::lit("&self"),
        crate::lower::model::Recv::RecvOwned => Text::lit("self: Rc<Self>"),
    };
    let cx_ = match &m.cx_ {
        crate::lower::model::CxArg::CxMut => Text::lit(", cx: &mut Cx"),
        crate::lower::model::CxArg::CxRef => Text::lit(", cx: &Cx"),
        crate::lower::model::CxArg::CxNone => Text::lit(""),
    };
    let params = concat(&run_to_end(each_job(m.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (p_, t) = p0;
        call_then(crate::emit::rust::start_type_(t.clone()), move |type__14611: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}: {}", &p_, &type__14611))))
    }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)));
    let ret = if &m.ret == &crate::lower::model::OutTy::OutUnit {
        Text::lit("")
    } else {
        Text::from(format!(" -> {}", &crate::emit::rust::type_(&m.ret)))
    };
    let sig = Text::from(format!("fn {}({}{}{}){}", &m.name, &recv, &params, &cx_, &ret));
    let body = if &m.ret == &crate::lower::model::OutTy::OutUnit {
        crate::emit::rust::statements(&m.body)
    } else {
        if &len(&m.body) == &Nat::from(0u32) {
            crate::emit::rust::body_lines(&m.tail)
        } else {
            Text::from(format!("{}\n{}", &crate::emit::rust::statements(&m.body), &crate::emit::rust::body_lines(&m.tail)))
        }
    };
    crate::emit::rust::templates::items::method(&crate::emit::rust::templates::doc(&m.doc), &sig, &body)
}

/// The step machine of `RustMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustMethod: unbounded fn MethDef -> Text
/// ```
pub struct RustMethod {
    pub m: crate::lower::model::MethDef,
}

impl prism_rtl::Job<Text> for RustMethod {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let m = &self.m;
        let recv = match &m.recv {
            crate::lower::model::Recv::RecvRc => Text::lit("self: &Rc<Self>"),
            crate::lower::model::Recv::RecvRef => Text::lit("&self"),
            crate::lower::model::Recv::RecvOwned => Text::lit("self: Rc<Self>"),
        };
        let cx_ = match &m.cx_ {
            crate::lower::model::CxArg::CxMut => Text::lit(", cx: &mut Cx"),
            crate::lower::model::CxArg::CxRef => Text::lit(", cx: &Cx"),
            crate::lower::model::CxArg::CxNone => Text::lit(""),
        };
        let m = m.clone();
        call_value(each_job(m.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
            let (p_, t) = p0;
            call_then(crate::emit::rust::start_type_(t.clone()), move |type__14611: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}: {}", &p_, &type__14611))))
        }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_14575: Array<Text>| {
            let params = concat(&each_14575);
            let ret = if &m.ret == &crate::lower::model::OutTy::OutUnit {
                Text::lit("")
            } else {
                Text::from(format!(" -> {}", &crate::emit::rust::type_(&m.ret)))
            };
            let sig = Text::from(format!("fn {}({}{}{}){}", &m.name, &recv, &params, &cx_, &ret));
            let body = if &m.ret == &crate::lower::model::OutTy::OutUnit {
                crate::emit::rust::statements(&m.body)
            } else {
                if &len(&m.body) == &Nat::from(0u32) {
                    crate::emit::rust::body_lines(&m.tail)
                } else {
                    Text::from(format!("{}\n{}", &crate::emit::rust::statements(&m.body), &crate::emit::rust::body_lines(&m.tail)))
                }
            };
            prism_rtl::Turn::Finished(crate::emit::rust::templates::items::method(&crate::emit::rust::templates::doc(&m.doc), &sig, &body))
        })
    }
}

/// `Start RustMethod, x`: what the function value is when passed to `@Run`.
pub fn start_rust_method(m: crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustMethod { m })
}

/// ```prism
/// RustProgram: unbounded fn ProgDef, Bool -> Text
/// ```
pub fn rust_program(p_: &crate::lower::model::ProgDef, fallible: &bool) -> Text {
    let n = len(&p_.params);
    let names = each(&p_.params, &(|(a, _): &(Text, crate::lower::model::OutTy)| a.clone()));
    let decode = if &n == &Nat::from(0u32) {
        Text::lit("let _ = args;")
    } else {
        decode_args(p_, &names)
    };
    let call = Text::from(format!("{}::build(Path::root(), {}&mut cx){}", &p_.node_, &concat(&each(&names, &(|a: &Text| Text::from(format!("{}, ", a))))), &(if *fallible { Text::lit("?") } else { Text::lit("") })));
    crate::emit::rust::templates::items::program(&p_.name, &p_.prism, &p_.node_, &decode, &call)
}

/// The step machine of `RustProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustProgram: unbounded fn ProgDef, Bool -> Text
/// ```
pub struct RustProgram {
    pub p_: crate::lower::model::ProgDef,
    pub fallible: bool,
}

impl prism_rtl::Job<Text> for RustProgram {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let p_ = &self.p_;
        let fallible = &self.fallible;
        let n = len(&p_.params);
        let names = each(&p_.params, &(|(a, _): &(Text, crate::lower::model::OutTy)| a.clone()));
        let decode = if &n == &Nat::from(0u32) {
            Text::lit("let _ = args;")
        } else {
            decode_args(p_, &names)
        };
        let call = Text::from(format!("{}::build(Path::root(), {}&mut cx){}", &p_.node_, &concat(&each(&names, &(|a: &Text| Text::from(format!("{}, ", a))))), &(if *fallible { Text::lit("?") } else { Text::lit("") })));
        prism_rtl::Turn::Finished(crate::emit::rust::templates::items::program(&p_.name, &p_.prism, &p_.node_, &decode, &call))
    }
}

/// `Start RustProgram, x`: what the function value is when passed to `@Run`.
pub fn start_rust_program(p_: crate::lower::model::ProgDef, fallible: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustProgram { p_, fallible })
}

/// ```prism
/// DecodeArgs: unbounded fn ProgDef, [Text] -> Text
/// ```
pub fn decode_args(p_: &crate::lower::model::ProgDef, names: &Array<Text>) -> Text {
    let n = len(names);
    let plural = if &n == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") };
    let head = Text::from(format!("let [{}] = args else {{ return Err(Fault::answer(\"@{} takes {} argument{}\")) }};", &crate::syntax::lexer::chars::join(names, &Text::lit(", ")), &p_.prism, &n, &plural));
    crate::syntax::lexer::chars::join(&append(&Array::from(vec![head.clone()]), &run_to_end(each_job(p_.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (a, t) = p0;
        call_then(crate::emit::rust::start_decode_head(t.clone()), move |decode_head_15642: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {}::from_pod({})?;", &a, &decode_head_15642, &a))))
    }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>))), &Text::lit("\n"))
}

/// The step machine of `DecodeArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DecodeArgs: unbounded fn ProgDef, [Text] -> Text
/// ```
pub struct DecodeArgs {
    pub p_: crate::lower::model::ProgDef,
    pub names: Array<Text>,
}

impl prism_rtl::Job<Text> for DecodeArgs {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let p_ = &self.p_;
        let names = &self.names;
        let n = len(names);
        let plural = if &n == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") };
        let head = Text::from(format!("let [{}] = args else {{ return Err(Fault::answer(\"@{} takes {} argument{}\")) }};", &crate::syntax::lexer::chars::join(names, &Text::lit(", ")), &p_.prism, &n, &plural));
        let p_ = p_.clone();
        call_value(each_job(p_.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
            let (a, t) = p0;
            call_then(crate::emit::rust::start_decode_head(t.clone()), move |decode_head_15642: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {}::from_pod({})?;", &a, &decode_head_15642, &a))))
        }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_15603: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&append(&Array::from(vec![head.clone()]), &each_15603), &Text::lit("\n"))))
    }
}

/// `Start DecodeArgs, x`: what the function value is when passed to `@Run`.
pub fn start_decode_args(p_: crate::lower::model::ProgDef, names: Array<Text>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(DecodeArgs { p_, names })
}

/// ```prism
/// RustModule: unbounded fn ModDef, Text -> Text
/// ```
pub fn rust_module(m: &crate::lower::model::ModDef, kids: &Text) -> Text {
    crate::emit::rust::templates::module(&(if &m.prism == &Text::lit("") {
        Text::lit("The root module")
    } else {
        Text::from(format!("The module `{}`", &m.prism))
    }), &m.path_, kids, &crate::syntax::lexer::chars::join(&run_to_end(each_job(m.items.clone(), Rc::new(move |p0: crate::lower::model::Item| entered(once_job(move || {
        let it = p0;
        prism_rtl::Turn::More(Rc::new(RustItem { it: it.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::Item) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n")))
}

/// The step machine of `RustModule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustModule: unbounded fn ModDef, Text -> Text
/// ```
pub struct RustModule {
    pub m: crate::lower::model::ModDef,
    pub kids: Text,
}

impl prism_rtl::Job<Text> for RustModule {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let m = &self.m;
        let kids = &self.kids;
        let kids = kids.clone();
        let m = m.clone();
        call_value(each_job(m.items.clone(), Rc::new(move |p0: crate::lower::model::Item| entered(once_job(move || {
            let it = p0;
            prism_rtl::Turn::More(Rc::new(RustItem { it: it.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Item) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_16215: Array<Text>| prism_rtl::Turn::Finished(crate::emit::rust::templates::module(&(if &m.prism == &Text::lit("") {
            Text::lit("The root module")
        } else {
            Text::from(format!("The module `{}`", &m.prism))
        }), &m.path_, &kids, &crate::syntax::lexer::chars::join(&each_16215, &Text::lit("\n")))))
    }
}

/// `Start RustModule, x`: what the function value is when passed to `@Run`.
pub fn start_rust_module(m: crate::lower::model::ModDef, kids: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustModule { m, kids })
}

/// ```prism
/// NodeFallible: fn Model, Text -> Bool
/// ```
pub fn node_fallible(model: &crate::lower::model::Model, path_: &Text) -> bool {
    fold(&model.mods, &false, &(|f: &bool, m: &crate::lower::model::ModDef| fold(&m.items, f, &(|f2: &bool, it: &crate::lower::model::Item| match it {
        crate::lower::model::Item::ItNode(n) => *f2 || ((&Text::from(format!("{}::{}", &m.name, &n.name)) == path_) && n.fallible),
        _ => *f2,
    }))))
}

/// ```prism
/// EmitCrate: unbounded fn Model, Text, [Text] -> [((Text, Text))]
/// ```
pub fn emit_crate(model: &crate::lower::model::Model, runtime: &Text, scripts: &Array<Text>) -> Array<(Text, Text)> {
    let gui = match &model.root {
        Some(r) => &r.world == &Text::lit("canvas"),
        None => false,
    };
    let cargo = crate::emit::rust::templates::cargo(&model.name, runtime, &(if gui { Text::lit("\"canvas\"") } else { Text::lit("") }));
    let paths = rust_mod_paths(&model.mods);
    let mods = concat(&each(&filter(&paths, &(|p_: &Text| !crate::syntax::lexer::chars::contains(p_, &Text::lit(":")))), &(|p_: &Text| Text::from(format!("mod {};\n", p_)))));
    let programs = crate::syntax::lexer::chars::join(&run_to_end(each_job(all_programs(model), {
        let model = model.clone();
        Rc::new(move |p0: crate::lower::model::ProgDef| {
            let model = model.clone();
            entered(once_job(move || {
                let p_ = p0;
                prism_rtl::Turn::More(Rc::new(RustProgram { p_: p_.clone(), fallible: node_fallible(&model, &p_.node_) }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::ProgDef) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let regs = concat(&each(&model.programs, &(|p_: &crate::lower::model::ProgDef| Text::from(format!(".program::<{}>(\"{}\")\n", &p_.name, &p_.prism)))));
    let checks = concat(&run_to_end(each_job(model.checks.clone(), Rc::new(move |p0: crate::lower::model::CheckDef| entered(once_job(move || {
        let c = p0;
        call_value(each_job(c.lines.clone(), Rc::new(move |p0: crate::lower::model::Ex| entered(once_job(move || {
            let l = p0;
            prism_rtl::Turn::More(Rc::new(crate::emit::rust::Expression { x: l.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_17244: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!(".check(\"{}\", || vec![{}])\n", &c.name, &crate::syntax::lexer::chars::join(&each_17244, &Text::lit(", "))))))
    }))) as Rc<dyn Fn(crate::lower::model::CheckDef) -> Rc<dyn prism_rtl::Job<Text>>>)));
    let script_list = concat(&each(scripts, &(|s: &Text| Text::from(format!("\"{}\",\n", &crate::lower::expr::escape(s))))));
    let run_root = match &model.root {
        Some(r) => crate::emit::rust::templates::run_root(&r.name),
        None => crate::emit::rust::templates::no_root(&model.name),
    };
    let world = match &model.root {
        Some(r) => r.world.clone(),
        None => Text::lit("test"),
    };
    let main = crate::emit::rust::templates::main(&model.name, &Text::from(format!("mod prelude;\n{}", &mods)), &Text::from(format!("{}\n{}\n{}", &rust_row(&model.elem), &rust_answer(&model.answer), &programs)), &Text::from(format!("{}{}", &regs, &checks)), &script_list, &run_root, &world);
    let files = run_to_end(each_job(model.mods.clone(), {
        let paths = paths.clone();
        Rc::new(move |p0: crate::lower::model::ModDef| {
            let paths = paths.clone();
            entered(once_job(move || {
                let m = p0;
                call_then(start_rust_module(m.clone(), kids_of(&paths, &m.name)), move |rust_module_17758: Text| prism_rtl::Turn::Finished((rust_mod_file(&m.name), rust_module_17758)))
            }))
        }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<(Text, Text)>>>
    }));
    let named = each(&model.mods, &(|m: &crate::lower::model::ModDef| m.name.clone()));
    let bare = each(&filter(&paths, &(|p_: &Text| !fold(&named, &false, &(|f: &bool, n: &Text| *f || (n == p_))))), &(|p_: &Text| (rust_mod_file(p_), Text::from(format!("//! Emitted by prismc: the modules under `{}`, which declares nothing of its own.\n\n{}", p_, &kids_of(&paths, p_))))));
    append(&Array::from(vec![(Text::lit("Cargo.toml"), cargo.clone()), (Text::lit("src/main.rs"), main.clone()), (Text::lit("src/prelude.rs"), crate::emit::rust::prelude::prelude_source(&Text::lit("")))]), &append(&files, &bare))
}

/// The step machine of `EmitCrate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EmitCrate: unbounded fn Model, Text, [Text] -> [((Text, Text))]
/// ```
pub struct EmitCrate {
    pub model: crate::lower::model::Model,
    pub runtime: Text,
    pub scripts: Array<Text>,
}

impl prism_rtl::Job<Array<(Text, Text)>> for EmitCrate {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Text, Text)>> {
        let model = &self.model;
        let runtime = &self.runtime;
        let scripts = &self.scripts;
        let gui = match &model.root {
            Some(r) => &r.world == &Text::lit("canvas"),
            None => false,
        };
        let cargo = crate::emit::rust::templates::cargo(&model.name, runtime, &(if gui { Text::lit("\"canvas\"") } else { Text::lit("") }));
        let paths = rust_mod_paths(&model.mods);
        let mods = concat(&each(&filter(&paths, &(|p_: &Text| !crate::syntax::lexer::chars::contains(p_, &Text::lit(":")))), &(|p_: &Text| Text::from(format!("mod {};\n", p_)))));
        let model = model.clone();
        let scripts = scripts.clone();
        call_value(each_job(all_programs(&model), {
            let model = model.clone();
            Rc::new(move |p0: crate::lower::model::ProgDef| {
                let model = model.clone();
                entered(once_job(move || {
                    let p_ = p0;
                    prism_rtl::Turn::More(Rc::new(RustProgram { p_: p_.clone(), fallible: node_fallible(&model, &p_.node_) }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::ProgDef) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_16986: Array<Text>| {
            let programs = crate::syntax::lexer::chars::join(&each_16986, &Text::lit("\n"));
            let regs = concat(&each(&model.programs, &(|p_: &crate::lower::model::ProgDef| Text::from(format!(".program::<{}>(\"{}\")\n", &p_.name, &p_.prism)))));
            call_value(each_job(model.checks.clone(), Rc::new(move |p0: crate::lower::model::CheckDef| entered(once_job(move || {
                let c = p0;
                call_value(each_job(c.lines.clone(), Rc::new(move |p0: crate::lower::model::Ex| entered(once_job(move || {
                    let l = p0;
                    prism_rtl::Turn::More(Rc::new(crate::emit::rust::Expression { x: l.clone() }))
                }))) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_17244: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!(".check(\"{}\", || vec![{}])\n", &c.name, &crate::syntax::lexer::chars::join(&each_17244, &Text::lit(", "))))))
            }))) as Rc<dyn Fn(crate::lower::model::CheckDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_17183: Array<Text>| {
                let checks = concat(&each_17183);
                let script_list = concat(&each(&scripts, &(|s: &Text| Text::from(format!("\"{}\",\n", &crate::lower::expr::escape(s))))));
                let run_root = match &model.root {
                    Some(r) => crate::emit::rust::templates::run_root(&r.name),
                    None => crate::emit::rust::templates::no_root(&model.name),
                };
                let world = match &model.root {
                    Some(r) => r.world.clone(),
                    None => Text::lit("test"),
                };
                call_then(start_rust_row(model.elem.clone()), move |rust_row_17589: Text| call_then(start_rust_answer(model.answer.clone()), move |rust_answer_17611: Text| {
                    let main = crate::emit::rust::templates::main(&model.name, &Text::from(format!("mod prelude;\n{}", &mods)), &Text::from(format!("{}\n{}\n{}", &rust_row_17589, &rust_answer_17611, &programs)), &Text::from(format!("{}{}", &regs, &checks)), &script_list, &run_root, &world);
                    call_value(each_job(model.mods.clone(), {
                        let paths = paths.clone();
                        Rc::new(move |p0: crate::lower::model::ModDef| {
                            let paths = paths.clone();
                            entered(once_job(move || {
                                let m = p0;
                                call_then(start_rust_module(m.clone(), kids_of(&paths, &m.name)), move |rust_module_17758: Text| prism_rtl::Turn::Finished((rust_mod_file(&m.name), rust_module_17758)))
                            }))
                        }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<(Text, Text)>>>
                    }), move |each_17711: Array<(Text, Text)>| {
                        let files = each_17711;
                        let named = each(&model.mods, &(|m: &crate::lower::model::ModDef| m.name.clone()));
                        let bare = each(&filter(&paths, &(|p_: &Text| !fold(&named, &false, &(|f: &bool, n: &Text| *f || (n == p_))))), &(|p_: &Text| (rust_mod_file(p_), Text::from(format!("//! Emitted by prismc: the modules under `{}`, which declares nothing of its own.\n\n{}", p_, &kids_of(&paths, p_))))));
                        prism_rtl::Turn::Finished(append(&Array::from(vec![(Text::lit("Cargo.toml"), cargo.clone()), (Text::lit("src/main.rs"), main.clone()), (Text::lit("src/prelude.rs"), crate::emit::rust::prelude::prelude_source(&Text::lit("")))]), &append(&files, &bare)))
                    })
                }))
            })
        })
    }
}

/// `Start EmitCrate, x`: what the function value is when passed to `@Run`.
pub fn start_emit_crate(model: crate::lower::model::Model, runtime: Text, scripts: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>> {
    Rc::new(EmitCrate { model, runtime, scripts })
}

/// ```prism
/// RustModPaths: fn [ModDef] -> [Text]
/// ```
pub fn rust_mod_paths(mods: &Array<crate::lower::model::ModDef>) -> Array<Text> {
    fold(mods, &Array::new(), &(|acc: &Array<Text>, m: &crate::lower::model::ModDef| {
        let segs = split(&m.name, &Text::lit("::"));
        fold(&crate::check::errors::range0(&len(&segs)), acc, &(|a: &Array<Text>, i: &Nat| add_path(a, &crate::syntax::lexer::chars::join(&take(&segs, &(i + &Nat::from(1u32))), &Text::lit("::")))))
    }))
}

/// ```prism
/// AddPath: fn [Text], Text -> [Text]
/// ```
pub fn add_path(ps: &Array<Text>, p_: &Text) -> Array<Text> {
    if fold(ps, &false, &(|f: &bool, q: &Text| *f || (q == p_))) {
        ps.clone()
    } else {
        push(ps, p_)
    }
}

/// ```prism
/// RustModFile: fn Text -> Text
/// ```
pub fn rust_mod_file(p_: &Text) -> Text {
    if p_ == &Text::lit("program") {
        Text::lit("src/program.rs")
    } else {
        Text::from(format!("src/{}/mod.rs", &crate::syntax::lexer::chars::join(&split(p_, &Text::lit("::")), &Text::lit("/"))))
    }
}

/// ```prism
/// KidsOf: fn [Text], Text -> Text
/// ```
pub fn kids_of(paths: &Array<Text>, p_: &Text) -> Text {
    concat(&each(&filter(paths, &(|q: &Text| crate::syntax::lexer::chars::has_prefix(q, &Text::from(format!("{}::", p_))) && !crate::syntax::lexer::chars::contains(&crate::syntax::lexer::chars::drop_prefix(q, &Text::from(format!("{}::", p_))), &Text::lit(":")))), &(|q: &Text| Text::from(format!("pub mod {};\n", &crate::syntax::lexer::chars::drop_prefix(q, &Text::from(format!("{}::", p_))))))))
}

/// ```prism
/// AllPrograms: fn Model -> [ProgDef]
/// ```
pub fn all_programs(model: &crate::lower::model::Model) -> Array<crate::lower::model::ProgDef> {
    match &model.root {
        Some(r) => if fold(&model.programs, &false, &(|f: &bool, p_: &crate::lower::model::ProgDef| *f || (&p_.name == &r.name))) {
            model.programs.clone()
        } else {
            push(&model.programs, r)
        },
        None => model.programs.clone(),
    }
}
