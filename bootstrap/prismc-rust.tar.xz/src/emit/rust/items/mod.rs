//! The module `Emit.Rust.Items`, from `target/bootstrap/src/prismc/emit/rust/items.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// Generics: fn [((Text, [Text]))] -> Text
/// ```
pub fn generics_f(xs0: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>) -> crate::prelude::Text {
    match xs0 {
        c0_0 if (c0_0.len() == 0) => crate::prelude::Text::lit(""),
        gs_p0 => crate::prelude::Text::from(format!("<{}>", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(gs_p0, &(|(g_p1, bs_p2): &(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)| if &crate::prelude::len(bs_p2) == &crate::prelude::Nat::from(0u32) {
            g_p1.clone()
        } else {
            crate::prelude::Text::from(format!("{}: {}", g_p1, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(bs_p2, &(|b_p3: &crate::prelude::Text| crate::emit::rust::rs_path_f(b_p3))), &crate::prelude::Text::lit(" + "))))
        })), &crate::prelude::Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// GenericNames: fn [Text] -> Text
/// ```
pub fn generic_names_f(xs0: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Text {
    match xs0 {
        c0_0 if (c0_0.len() == 0) => crate::prelude::Text::lit(""),
        ps_p0 => crate::prelude::Text::from(format!("<{}>", &crate::syntax::lexer::chars::join_f(ps_p0, &crate::prelude::Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Bounded: fn [Text], Text -> Text
/// ```
pub fn bounded_f(xs0: &crate::prelude::Array<crate::prelude::Text>, text1: &crate::prelude::Text) -> crate::prelude::Text {
    match (xs0, text1) {
        (c0_0, _) if (c0_0.len() == 0) => crate::prelude::Text::lit(""),
        (ps_p0, tr_p1) => crate::prelude::Text::from(format!("<{}>", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(ps_p0, &(|p_p2: &crate::prelude::Text| crate::prelude::Text::from(format!("{}: {}", p_p2, tr_p1)))), &crate::prelude::Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// BoundedKeyed: fn TyDef, Text -> Text
/// ```
pub fn bounded_keyed_f(t_p0: &crate::lower::model::TyDef, tr_p1: &crate::prelude::Text) -> crate::prelude::Text {
    match &t_p0.params_p {
        m1631_0 if (m1631_0.len() == 0) => crate::prelude::Text::lit(""),
        ps_p2 => crate::prelude::Text::from(format!("<{}>", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(ps_p2, &(|p_p3: &crate::prelude::Text| if crate::prelude::fold(&t_p0.keyed_p, &false, &(|found_p4: &bool, q_p5: &crate::prelude::Text| *found_p4 || (q_p5 == p_p3))) {
            crate::prelude::Text::from(format!("{}: {} + ::std::cmp::Ord", p_p3, tr_p1))
        } else {
            crate::prelude::Text::from(format!("{}: {}", p_p3, tr_p1))
        })), &crate::prelude::Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// RustItem: unbounded fn Item -> Text
/// ```
pub fn rust_item_f(it_p0: &crate::lower::model::Item) -> crate::prelude::Text {
    match it_p0 {
        crate::lower::model::Item::ItTrait(t_p1) => rust_trait_f(t_p1),
        crate::lower::model::Item::ItImpl(i_p2) => rust_impl_f(i_p2),
        crate::lower::model::Item::ItPacked(d_p3) => rust_packed_f(d_p3),
        crate::lower::model::Item::ItType(t_p4) => type_decl_f(t_p4),
        crate::lower::model::Item::ItTag(t_p5) => rust_tag_f(t_p5),
        crate::lower::model::Item::ItRow(r_p6) => rust_row_f(r_p6),
        crate::lower::model::Item::ItFn(f_p7) => rust_fn_f(f_p7),
        crate::lower::model::Item::ItJob(j_p8) => rust_job_f(j_p8),
        crate::lower::model::Item::ItNode(n_p9) => rust_node_f(n_p9),
        crate::lower::model::Item::ItNote(t_pa) => crate::prelude::Text::from(format!("// {}\n", t_pa)),
        crate::lower::model::Item::ItRefused(t_pb) => crate::prelude::Text::from(format!("compile_error!(\"{}{}\");\n", &crate::lower::expr::lowering_refusal_p(), &crate::lower::expr::escape_f(t_pb))),
    }
}

/// The step machine of `RustItem`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustItem: unbounded fn Item -> Text
/// ```
pub struct RustItem {
    pub it_p0: crate::lower::model::Item,
}

impl ::prism_rtl::Job<crate::prelude::Text> for RustItem {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let it_p0 = &self.it_p0;
        match it_p0 {
            crate::lower::model::Item::ItTrait(t_p1) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RustTrait { t_p0: t_p1.clone() })),
            crate::lower::model::Item::ItImpl(i_p2) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RustImpl { i_p0: i_p2.clone() })),
            crate::lower::model::Item::ItPacked(d_p3) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RustPacked { d_p0: d_p3.clone() })),
            crate::lower::model::Item::ItType(t_p4) => ::prism_rtl::Turn::More(::std::rc::Rc::new(TypeDecl { t_p0: t_p4.clone() })),
            crate::lower::model::Item::ItTag(t_p5) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RustTag { t_p0: t_p5.clone() })),
            crate::lower::model::Item::ItRow(r_p6) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RustRow { r_p0: r_p6.clone() })),
            crate::lower::model::Item::ItFn(f_p7) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RustFn { f_p0: f_p7.clone() })),
            crate::lower::model::Item::ItJob(j_p8) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RustJob { j_p0: j_p8.clone() })),
            crate::lower::model::Item::ItNode(n_p9) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RustNode { n_p0: n_p9.clone() })),
            crate::lower::model::Item::ItNote(t_pa) => ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("// {}\n", t_pa))),
            crate::lower::model::Item::ItRefused(t_pb) => ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("compile_error!(\"{}{}\");\n", &crate::lower::expr::lowering_refusal_p(), &crate::lower::expr::escape_f(t_pb)))),
        }
    }
}

/// `Start RustItem, x`: what the function value is when passed to `@Run`.
pub fn start_rust_item_f(it_p0: crate::lower::model::Item) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(RustItem { it_p0 })
}

/// ```prism
/// RustTrait: unbounded fn TraitDef -> Text
/// ```
pub fn rust_trait_f(t_p0: &crate::lower::model::TraitDef) -> crate::prelude::Text {
    let types_p1 = crate::prelude::each(&t_p0.assocs_p, &(|a_p3: &crate::prelude::Text| crate::prelude::Text::from(format!("type {}: ::std::clone::Clone;", a_p3))));
    let ms_p2 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&types_p1, &crate::prelude::run_to_end(crate::prelude::each_job(t_p0.methods_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| crate::prelude::entered(crate::prelude::once_job(move || {
        let f_p4 = p0;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(TraitMethod { f_p0: f_p4.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>))), &crate::prelude::Text::lit("\n"));
    crate::prelude::Text::from(format!("{}pub trait {}: ::std::clone::Clone + \'static {{\n{}\n}}\n", &crate::emit::rust::templates::source_doc_f(&crate::prelude::Text::lit(""), &t_p0.doc_p), &t_p0.name_p, &crate::emit::rust::indent_f(&ms_p2)))
}

/// The step machine of `RustTrait`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustTrait: unbounded fn TraitDef -> Text
/// ```
pub struct RustTrait {
    pub t_p0: crate::lower::model::TraitDef,
}

impl ::prism_rtl::Job<crate::prelude::Text> for RustTrait {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let t_p0 = &self.t_p0;
        let types_p1 = crate::prelude::each(&t_p0.assocs_p, &(|a_p3: &crate::prelude::Text| crate::prelude::Text::from(format!("type {}: ::std::clone::Clone;", a_p3))));
        let t_p0x = t_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(t_p0x.methods_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| crate::prelude::entered(crate::prelude::once_job(move || {
            let f_p4 = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(TraitMethod { f_p0: f_p4.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_2345: crate::prelude::Array<crate::prelude::Text>| {
            let ms_p2 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&types_p1, &each_2345), &crate::prelude::Text::lit("\n"));
            ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}pub trait {}: ::std::clone::Clone + \'static {{\n{}\n}}\n", &crate::emit::rust::templates::source_doc_f(&crate::prelude::Text::lit(""), &t_p0x.doc_p), &t_p0x.name_p, &crate::emit::rust::indent_f(&ms_p2))))
        })
    }
}

/// `Start RustTrait, x`: what the function value is when passed to `@Run`.
pub fn start_rust_trait_f(t_p0: crate::lower::model::TraitDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(RustTrait { t_p0 })
}

/// ```prism
/// Signature: unbounded fn FnDef, Text -> Text
/// ```
pub fn signature_f(f_p0: &crate::lower::model::FnDef, vis_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let params_p2 = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(f_p0.params_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (n_p3, t_p4) = p0;
        crate::prelude::call_then(crate::emit::rust::start_type_f(t_p4.clone()), move |type_f_2736: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}: {}", &n_p3, &type_f_2736))))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit(", "));
    crate::prelude::Text::from(format!("{}fn {}{}({}) -> {}", vis_p1, &f_p0.name_p, &static_generics_f(&f_p0.generics_p), &params_p2, &crate::emit::rust::type_f(&f_p0.ret_p)))
}

/// The step machine of `Signature`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Signature: unbounded fn FnDef, Text -> Text
/// ```
pub struct Signature {
    pub f_p0: crate::lower::model::FnDef,
    pub vis_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Text> for Signature {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let f_p0 = &self.f_p0;
        let vis_p1 = &self.vis_p1;
        let f_p0x = f_p0.clone();
        let vis_p1x = vis_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(f_p0x.params_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
            let (n_p3, t_p4) = p0;
            crate::prelude::call_then(crate::emit::rust::start_type_f(t_p4.clone()), move |type_f_2736: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}: {}", &n_p3, &type_f_2736))))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_2702: crate::prelude::Array<crate::prelude::Text>| {
            let params_p2 = crate::syntax::lexer::chars::join_f(&each_2702, &crate::prelude::Text::lit(", "));
            crate::prelude::call_then(crate::emit::rust::start_type_f(f_p0x.ret_p.clone()), move |type_f_2978: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}fn {}{}({}) -> {}", &vis_p1x, &f_p0x.name_p, &static_generics_f(&f_p0x.generics_p), &params_p2, &type_f_2978))))
        })
    }
}

/// `Start Signature, x`: what the function value is when passed to `@Run`.
pub fn start_signature_f(f_p0: crate::lower::model::FnDef, vis_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(Signature { f_p0, vis_p1 })
}

/// ```prism
/// TraitMethod: unbounded fn FnDef -> Text
/// ```
pub fn trait_method_f(f_p0: &crate::lower::model::FnDef) -> crate::prelude::Text {
    if f_p0.public_p {
        crate::emit::rust::templates::items::fn_f(&crate::prelude::Text::lit(""), &signature_f(f_p0, &crate::prelude::Text::lit("")), &crate::emit::rust::body_lines_f(&f_p0.body_p))
    } else {
        crate::prelude::Text::from(format!("{};", &signature_f(f_p0, &crate::prelude::Text::lit(""))))
    }
}

/// The step machine of `TraitMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TraitMethod: unbounded fn FnDef -> Text
/// ```
pub struct TraitMethod {
    pub f_p0: crate::lower::model::FnDef,
}

impl ::prism_rtl::Job<crate::prelude::Text> for TraitMethod {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let f_p0 = &self.f_p0;
        if f_p0.public_p {
            {
                let f_p0x = f_p0.clone();
                crate::prelude::call_then(start_signature_f(f_p0x.clone(), crate::prelude::Text::lit("")), move |signature_f_3072: crate::prelude::Text| crate::prelude::call_then(crate::emit::rust::start_body_lines_f(f_p0x.body_p.clone()), move |body_lines_f_3091: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::fn_f(&crate::prelude::Text::lit(""), &signature_f_3072, &body_lines_f_3091))))
            }
        } else {
            {
                let f_p0x = f_p0.clone();
                crate::prelude::call_then(start_signature_f(f_p0x.clone(), crate::prelude::Text::lit("")), move |signature_f_3117: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{};", &signature_f_3117))))
            }
        }
    }
}

/// `Start TraitMethod, x`: what the function value is when passed to `@Run`.
pub fn start_trait_method_f(f_p0: crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(TraitMethod { f_p0 })
}

/// ```prism
/// RustImpl: unbounded fn ImplDef -> Text
/// ```
pub fn rust_impl_f(i_p0: &crate::lower::model::ImplDef) -> crate::prelude::Text {
    let head_p1 = crate::emit::rust::type_f(&i_p0.head_p);
    let own_f2 = {
        let i_p0x = i_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| {
            let i_p0xy = i_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let f_p3 = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(RustFn { f_p0: {
                    let mut this: crate::lower::model::FnDef = f_p3.clone();
                    this.generics_p = crate::prelude::append(&i_p0xy.generics_p, &this.generics_p);
                    this
                } }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    };
    match &i_p0.cls_p {
        m3567_0 if (m3567_0 == &crate::prelude::Text::lit("Prelude.Show")) => {
            let fns_p4 = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(i_p0.methods_p.clone(), {
                let own_f2x = own_f2.clone();
                ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| {
                    let own_f2xy = own_f2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_p6 = p0;
                        (&own_f2xy)(f_p6.clone()).cycle()
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            })), &crate::prelude::Text::lit("\n"));
            let shown_p5 = crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&i_p0.methods_p, &(|f_p7: &crate::lower::model::FnDef| f_p7.name_p.clone())), &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("show"));
            crate::prelude::Text::from(format!("{}\n{}", &fns_p4, &crate::emit::rust::templates::items::impl_f(&static_generics_f(&i_p0.generics_p), &crate::prelude::Text::lit("crate::prelude::Show"), &head_p1, &crate::prelude::Text::lit("fn show(&self, p: &mut crate::prelude::Printer)"), &crate::prelude::Text::from(format!("p.raw(&{}(self).to_string());", &shown_p5)))))
        },
        m3567_1 if (m3567_1 == &crate::prelude::Text::lit("Prelude.Eq")) => {
            let fns_p8 = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(i_p0.methods_p.clone(), {
                let own_f2x = own_f2.clone();
                ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| {
                    let own_f2xy = own_f2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_pb = p0;
                        (&own_f2xy)(f_pb.clone()).cycle()
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            })), &crate::prelude::Text::lit("\n"));
            let eq_p9 = crate::prelude::fold(&i_p0.methods_p, &crate::prelude::Text::lit(""), &(|acc_pc: &crate::prelude::Text, f_pd: &crate::lower::model::FnDef| if !crate::syntax::lexer::chars::has_prefix_f(&f_pd.name_p, &crate::prelude::Text::lit("ne")) && (acc_pc == &crate::prelude::Text::lit("")) {
                f_pd.name_p.clone()
            } else {
                acc_pc.clone()
            }));
            let sgens_pa = static_generics_f(&i_p0.generics_p);
            crate::prelude::Text::from(format!("{}\n{}\nimpl{} ::std::cmp::Eq for {} {{}}", &fns_p8, &crate::emit::rust::templates::items::impl_f(&sgens_pa, &crate::prelude::Text::lit("::std::cmp::PartialEq"), &head_p1, &crate::prelude::Text::lit("fn eq(&self, other: &Self) -> bool"), &crate::prelude::Text::from(format!("{}(self, other)", &eq_p9))), &sgens_pa, &head_p1))
        },
        _ => {
            let types_pe = crate::prelude::run_to_end(crate::prelude::each_job(i_p0.assocs_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
                let (a_pf, t_pg) = p0;
                crate::prelude::call_then(crate::emit::rust::start_type_f(t_pg.clone()), move |type_f_4411: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("type {} = {};", &a_pf, &type_f_4411))))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>));
            crate::prelude::Text::from(format!("impl{} {} for {} {{\n{}\n}}\n", &static_generics_f(&i_p0.generics_p), &i_p0.tr_p, &head_p1, &crate::emit::rust::indent_f(&crate::syntax::lexer::chars::join_f(&crate::prelude::append(&types_pe, &crate::prelude::run_to_end(crate::prelude::each_job(i_p0.methods_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| crate::prelude::entered(crate::prelude::once_job(move || {
                let f_ph = p0;
                crate::prelude::call_then(start_signature_f(f_ph.clone(), crate::prelude::Text::lit("")), move |signature_f_4547: crate::prelude::Text| crate::prelude::call_then(crate::emit::rust::start_body_lines_f(f_ph.body_p.clone()), move |body_lines_f_4566: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::fn_f(&crate::prelude::Text::lit(""), &signature_f_4547, &body_lines_f_4566))))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>))), &crate::prelude::Text::lit("\n")))))
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `RustImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustImpl: unbounded fn ImplDef -> Text
/// ```
pub struct RustImpl {
    pub i_p0: crate::lower::model::ImplDef,
}

impl ::prism_rtl::Job<crate::prelude::Text> for RustImpl {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let i_p0 = &self.i_p0;
        let i_p0x = i_p0.clone();
        crate::prelude::call_then(crate::emit::rust::start_type_f(i_p0x.head_p.clone()), move |type_f_3459: crate::prelude::Text| {
            let head_p1 = type_f_3459;
            let own_f2 = {
                let i_p0xx = i_p0x.clone();
                ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| {
                    let i_p0xxy = i_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_p3 = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(RustFn { f_p0: {
                            let mut this: crate::lower::model::FnDef = f_p3.clone();
                            this.generics_p = crate::prelude::append(&i_p0xxy.generics_p, &this.generics_p);
                            this
                        } }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            };
            match &i_p0x.cls_p {
                m3567_0 if (m3567_0 == &crate::prelude::Text::lit("Prelude.Show")) => crate::prelude::call_value(crate::prelude::each_job(i_p0x.methods_p.clone(), {
                    let own_f2x = own_f2.clone();
                    ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| {
                        let own_f2xy = own_f2x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let f_p6 = p0;
                            (&own_f2xy)(f_p6.clone()).cycle()
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                }), move |each_3632: crate::prelude::Array<crate::prelude::Text>| {
                    let fns_p4 = crate::syntax::lexer::chars::join_f(&each_3632, &crate::prelude::Text::lit("\n"));
                    let shown_p5 = crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&i_p0x.methods_p, &(|f_p7: &crate::lower::model::FnDef| f_p7.name_p.clone())), &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("show"));
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}\n{}", &fns_p4, &crate::emit::rust::templates::items::impl_f(&static_generics_f(&i_p0x.generics_p), &crate::prelude::Text::lit("crate::prelude::Show"), &head_p1, &crate::prelude::Text::lit("fn show(&self, p: &mut crate::prelude::Printer)"), &crate::prelude::Text::from(format!("p.raw(&{}(self).to_string());", &shown_p5))))))
                }),
                m3567_1 if (m3567_1 == &crate::prelude::Text::lit("Prelude.Eq")) => crate::prelude::call_value(crate::prelude::each_job(i_p0x.methods_p.clone(), {
                    let own_f2x = own_f2.clone();
                    ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| {
                        let own_f2xy = own_f2x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let f_pb = p0;
                            (&own_f2xy)(f_pb.clone()).cycle()
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                }), move |each_3959: crate::prelude::Array<crate::prelude::Text>| {
                    let fns_p8 = crate::syntax::lexer::chars::join_f(&each_3959, &crate::prelude::Text::lit("\n"));
                    let eq_p9 = crate::prelude::fold(&i_p0x.methods_p, &crate::prelude::Text::lit(""), &(|acc_pc: &crate::prelude::Text, f_pd: &crate::lower::model::FnDef| if !crate::syntax::lexer::chars::has_prefix_f(&f_pd.name_p, &crate::prelude::Text::lit("ne")) && (acc_pc == &crate::prelude::Text::lit("")) {
                        f_pd.name_p.clone()
                    } else {
                        acc_pc.clone()
                    }));
                    let sgens_pa = static_generics_f(&i_p0x.generics_p);
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}\n{}\nimpl{} ::std::cmp::Eq for {} {{}}", &fns_p8, &crate::emit::rust::templates::items::impl_f(&sgens_pa, &crate::prelude::Text::lit("::std::cmp::PartialEq"), &head_p1, &crate::prelude::Text::lit("fn eq(&self, other: &Self) -> bool"), &crate::prelude::Text::from(format!("{}(self, other)", &eq_p9))), &sgens_pa, &head_p1)))
                }),
                _ => crate::prelude::call_value(crate::prelude::each_job(i_p0x.assocs_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let (a_pf, t_pg) = p0;
                    crate::prelude::call_then(crate::emit::rust::start_type_f(t_pg.clone()), move |type_f_4411: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("type {} = {};", &a_pf, &type_f_4411))))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_4371: crate::prelude::Array<crate::prelude::Text>| {
                    let types_pe = each_4371;
                    crate::prelude::call_value(crate::prelude::each_job(i_p0x.methods_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::FnDef| crate::prelude::entered(crate::prelude::once_job(move || {
                        let f_ph = p0;
                        crate::prelude::call_then(start_signature_f(f_ph.clone(), crate::prelude::Text::lit("")), move |signature_f_4547: crate::prelude::Text| crate::prelude::call_then(crate::emit::rust::start_body_lines_f(f_ph.body_p.clone()), move |body_lines_f_4566: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::fn_f(&crate::prelude::Text::lit(""), &signature_f_4547, &body_lines_f_4566))))
                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_4518: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("impl{} {} for {} {{\n{}\n}}\n", &static_generics_f(&i_p0x.generics_p), &i_p0x.tr_p, &head_p1, &crate::emit::rust::indent_f(&crate::syntax::lexer::chars::join_f(&crate::prelude::append(&types_pe, &each_4518), &crate::prelude::Text::lit("\n")))))))
                }),
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start RustImpl, x`: what the function value is when passed to `@Run`.
pub fn start_rust_impl_f(i_p0: crate::lower::model::ImplDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(RustImpl { i_p0 })
}

/// ```prism
/// RustPacked: unbounded fn PackedDef -> Text
/// ```
pub fn rust_packed_f(d_p0: &crate::lower::model::PackedDef) -> crate::prelude::Text {
    let dictionary_p1 = crate::prelude::Text::from(format!("{}_packed", &d_p0.name_p));
    let fields_p2 = crate::prelude::run_to_end(crate::prelude::each_job(d_p0.methods_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::PackedMethod| crate::prelude::entered(crate::prelude::once_job(move || {
        let m_p6 = p0;
        crate::prelude::call_value(crate::prelude::each_job(m_p6.method_p.params_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
            let (_, t_p7) = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::rust::Type { t_p0: t_p7.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_5181: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(crate::emit::rust::start_type_f(m_p6.method_p.ret_p.clone()), move |type_f_5240: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("pub {}: fn({}) -> {},", &m_p6.method_p.name_p, &crate::syntax::lexer::chars::join_f(&each_5181, &crate::prelude::Text::lit(", ")), &type_f_5240)))))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::PackedMethod) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>));
    let entries_p3 = crate::prelude::each(&d_p0.methods_p, &(|m_p8: &crate::lower::model::PackedMethod| {
        let names_p9 = crate::prelude::each(&m_p8.method_p.params_p, &(|(n_pc, _): &(crate::prelude::Text, crate::lower::model::OutTy)| n_pc.clone()));
        let args_pa = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&names_p9)), &(|i_pd: &crate::prelude::Nat| if crate::prelude::or(&crate::prelude::index(&m_p8.hidden_p, i_pd), &false) {
            crate::prelude::Text::from(format!("{}.held::<T>()", &crate::prelude::or(&crate::prelude::index(&names_p9, i_pd), &crate::prelude::Text::lit(""))))
        } else {
            crate::prelude::or(&crate::prelude::index(&names_p9, i_pd), &crate::prelude::Text::lit(""))
        }));
        let call_pb = crate::prelude::Text::from(format!("<T as {}>::{}({})", &d_p0.tr_p, &m_p8.method_p.name_p, &crate::syntax::lexer::chars::join_f(&args_pa, &crate::prelude::Text::lit(", "))));
        crate::prelude::Text::from(format!("{}: |{}| {},", &m_p8.method_p.name_p, &crate::syntax::lexer::chars::join_f(&names_p9, &crate::prelude::Text::lit(", ")), &(if m_p8.hidden_result_p {
            crate::prelude::Text::from(format!("{}.repacked({})", &packed_first_hidden_f(m_p8), &call_pb))
        } else {
            call_pb.clone()
        })))
    }));
    let methods_p4 = crate::prelude::run_to_end(crate::prelude::each_job(d_p0.methods_p.clone(), {
        let dictionary_p1x = dictionary_p1.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::PackedMethod| {
            let dictionary_p1xy = dictionary_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_pe = p0;
                crate::prelude::call_then(start_signature_f(m_pe.method_p.clone(), crate::prelude::Text::lit("")), move |signature_f_5732: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::fn_f(&crate::prelude::Text::lit(""), &signature_f_5732, &crate::prelude::Text::from(format!("({}.dictionary::<{}>().{})({})", &packed_first_hidden_f(&m_pe), &dictionary_p1xy, &m_pe.method_p.name_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&m_pe.method_p.params_p, &(|(n_pf, _): &(crate::prelude::Text, crate::lower::model::OutTy)| n_pf.clone())), &crate::prelude::Text::lit(", ")))))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::PackedMethod) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    }));
    let made_p5 = crate::emit::rust::templates::items::fn_f(&crate::prelude::Text::from(format!("/// The dictionary of `{}` at the type of a value.", &d_p0.name_p)), &crate::prelude::Text::from(format!("pub fn {}_packed_of<T: {}>(_: &T) -> {}", &crate::prelude::lower(&d_p0.name_p), &d_p0.tr_p, &dictionary_p1)), &crate::prelude::Text::from(format!("{} {{\n{}\n    }}", &dictionary_p1, &crate::emit::rust::indent_f(&crate::emit::rust::indent_f(&crate::syntax::lexer::chars::join_f(&entries_p3, &crate::prelude::Text::lit("\n")))))));
    crate::prelude::Text::from(format!("/// The dictionary of `{}` an existential keeps: each method over packed values.\npub struct {} {{\n{}\n}}\n{}\nimpl {} for ::prism_rtl::Packed {{\n{}\n}}\n", &d_p0.name_p, &dictionary_p1, &crate::emit::rust::indent_f(&crate::syntax::lexer::chars::join_f(&fields_p2, &crate::prelude::Text::lit("\n"))), &made_p5, &d_p0.tr_p, &crate::emit::rust::indent_f(&crate::syntax::lexer::chars::join_f(&methods_p4, &crate::prelude::Text::lit("\n")))))
}

/// The step machine of `RustPacked`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustPacked: unbounded fn PackedDef -> Text
/// ```
pub struct RustPacked {
    pub d_p0: crate::lower::model::PackedDef,
}

impl ::prism_rtl::Job<crate::prelude::Text> for RustPacked {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let d_p0 = &self.d_p0;
        let dictionary_p1 = crate::prelude::Text::from(format!("{}_packed", &d_p0.name_p));
        let d_p0x = d_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(d_p0x.methods_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::PackedMethod| crate::prelude::entered(crate::prelude::once_job(move || {
            let m_p6 = p0;
            crate::prelude::call_value(crate::prelude::each_job(m_p6.method_p.params_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
                let (_, t_p7) = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::rust::Type { t_p0: t_p7.clone() }))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_5181: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(crate::emit::rust::start_type_f(m_p6.method_p.ret_p.clone()), move |type_f_5240: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("pub {}: fn({}) -> {},", &m_p6.method_p.name_p, &crate::syntax::lexer::chars::join_f(&each_5181, &crate::prelude::Text::lit(", ")), &type_f_5240)))))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::PackedMethod) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_5128: crate::prelude::Array<crate::prelude::Text>| {
            let fields_p2 = each_5128;
            let entries_p3 = crate::prelude::each(&d_p0x.methods_p, &(|m_p8: &crate::lower::model::PackedMethod| {
                let names_p9 = crate::prelude::each(&m_p8.method_p.params_p, &(|(n_pc, _): &(crate::prelude::Text, crate::lower::model::OutTy)| n_pc.clone()));
                let args_pa = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&names_p9)), &(|i_pd: &crate::prelude::Nat| if crate::prelude::or(&crate::prelude::index(&m_p8.hidden_p, i_pd), &false) {
                    crate::prelude::Text::from(format!("{}.held::<T>()", &crate::prelude::or(&crate::prelude::index(&names_p9, i_pd), &crate::prelude::Text::lit(""))))
                } else {
                    crate::prelude::or(&crate::prelude::index(&names_p9, i_pd), &crate::prelude::Text::lit(""))
                }));
                let call_pb = crate::prelude::Text::from(format!("<T as {}>::{}({})", &d_p0x.tr_p, &m_p8.method_p.name_p, &crate::syntax::lexer::chars::join_f(&args_pa, &crate::prelude::Text::lit(", "))));
                crate::prelude::Text::from(format!("{}: |{}| {},", &m_p8.method_p.name_p, &crate::syntax::lexer::chars::join_f(&names_p9, &crate::prelude::Text::lit(", ")), &(if m_p8.hidden_result_p {
                    crate::prelude::Text::from(format!("{}.repacked({})", &packed_first_hidden_f(m_p8), &call_pb))
                } else {
                    call_pb.clone()
                })))
            }));
            crate::prelude::call_value(crate::prelude::each_job(d_p0x.methods_p.clone(), {
                let dictionary_p1x = dictionary_p1.clone();
                ::std::rc::Rc::new(move |p0: crate::lower::model::PackedMethod| {
                    let dictionary_p1xy = dictionary_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let m_pe = p0;
                        crate::prelude::call_then(start_signature_f(m_pe.method_p.clone(), crate::prelude::Text::lit("")), move |signature_f_5732: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::fn_f(&crate::prelude::Text::lit(""), &signature_f_5732, &crate::prelude::Text::from(format!("({}.dictionary::<{}>().{})({})", &packed_first_hidden_f(&m_pe), &dictionary_p1xy, &m_pe.method_p.name_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&m_pe.method_p.params_p, &(|(n_pf, _): &(crate::prelude::Text, crate::lower::model::OutTy)| n_pf.clone())), &crate::prelude::Text::lit(", ")))))))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::PackedMethod) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            }), move |each_5703: crate::prelude::Array<crate::prelude::Text>| {
                let methods_p4 = each_5703;
                let made_p5 = crate::emit::rust::templates::items::fn_f(&crate::prelude::Text::from(format!("/// The dictionary of `{}` at the type of a value.", &d_p0x.name_p)), &crate::prelude::Text::from(format!("pub fn {}_packed_of<T: {}>(_: &T) -> {}", &crate::prelude::lower(&d_p0x.name_p), &d_p0x.tr_p, &dictionary_p1)), &crate::prelude::Text::from(format!("{} {{\n{}\n    }}", &dictionary_p1, &crate::emit::rust::indent_f(&crate::emit::rust::indent_f(&crate::syntax::lexer::chars::join_f(&entries_p3, &crate::prelude::Text::lit("\n")))))));
                ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("/// The dictionary of `{}` an existential keeps: each method over packed values.\npub struct {} {{\n{}\n}}\n{}\nimpl {} for ::prism_rtl::Packed {{\n{}\n}}\n", &d_p0x.name_p, &dictionary_p1, &crate::emit::rust::indent_f(&crate::syntax::lexer::chars::join_f(&fields_p2, &crate::prelude::Text::lit("\n"))), &made_p5, &d_p0x.tr_p, &crate::emit::rust::indent_f(&crate::syntax::lexer::chars::join_f(&methods_p4, &crate::prelude::Text::lit("\n"))))))
            })
        })
    }
}

/// `Start RustPacked, x`: what the function value is when passed to `@Run`.
pub fn start_rust_packed_f(d_p0: crate::lower::model::PackedDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(RustPacked { d_p0 })
}

/// ```prism
/// PackedFirstHidden: fn PackedMethod -> Text
/// ```
pub fn packed_first_hidden_f(m_p0: &crate::lower::model::PackedMethod) -> crate::prelude::Text {
    crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&m_p0.hidden_p)), &crate::prelude::Text::lit(""), &(|found_p1: &crate::prelude::Text, i_p2: &crate::prelude::Nat| if (found_p1 == &crate::prelude::Text::lit("")) && crate::prelude::or(&crate::prelude::index(&m_p0.hidden_p, i_p2), &false) {
        crate::prelude::or(&crate::prelude::index(&crate::prelude::each(&m_p0.method_p.params_p, &(|(n_p3, _): &(crate::prelude::Text, crate::lower::model::OutTy)| n_p3.clone())), i_p2), &crate::prelude::Text::lit(""))
    } else {
        found_p1.clone()
    }))
}

/// ```prism
/// RustFn: unbounded fn FnDef -> Text
/// ```
pub fn rust_fn_f(f_p0: &crate::lower::model::FnDef) -> crate::prelude::Text {
    let params_p1 = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(f_p0.params_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (n_p3, t_p4) = p0;
        crate::prelude::call_then(crate::emit::rust::start_type_f(t_p4.clone()), move |type_f_6753: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}: {}", &n_p3, &type_f_6753))))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit(", "));
    let sig_p2 = crate::prelude::Text::from(format!("pub fn {}{}({}) -> {}", &f_p0.name_p, &static_generics_f(&f_p0.generics_p), &params_p1, &crate::emit::rust::type_f(&f_p0.ret_p)));
    crate::emit::rust::templates::items::fn_f(&crate::emit::rust::templates::source_doc_f(&crate::prelude::Text::lit(""), &f_p0.doc_p), &sig_p2, &crate::emit::rust::body_lines_f(&f_p0.body_p))
}

/// The step machine of `RustFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustFn: unbounded fn FnDef -> Text
/// ```
pub struct RustFn {
    pub f_p0: crate::lower::model::FnDef,
}

impl ::prism_rtl::Job<crate::prelude::Text> for RustFn {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let f_p0 = &self.f_p0;
        let f_p0x = f_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(f_p0x.params_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
            let (n_p3, t_p4) = p0;
            crate::prelude::call_then(crate::emit::rust::start_type_f(t_p4.clone()), move |type_f_6753: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}: {}", &n_p3, &type_f_6753))))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_6719: crate::prelude::Array<crate::prelude::Text>| {
            let params_p1 = crate::syntax::lexer::chars::join_f(&each_6719, &crate::prelude::Text::lit(", "));
            crate::prelude::call_then(crate::emit::rust::start_type_f(f_p0x.ret_p.clone()), move |type_f_6983: crate::prelude::Text| {
                let sig_p2 = crate::prelude::Text::from(format!("pub fn {}{}({}) -> {}", &f_p0x.name_p, &static_generics_f(&f_p0x.generics_p), &params_p1, &type_f_6983));
                crate::prelude::call_then(crate::emit::rust::start_body_lines_f(f_p0x.body_p.clone()), move |body_lines_f_7032: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::fn_f(&crate::emit::rust::templates::source_doc_f(&crate::prelude::Text::lit(""), &f_p0x.doc_p), &sig_p2, &body_lines_f_7032)))
            })
        })
    }
}

/// `Start RustFn, x`: what the function value is when passed to `@Run`.
pub fn start_rust_fn_f(f_p0: crate::lower::model::FnDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(RustFn { f_p0 })
}

/// ```prism
/// StaticGenerics: fn [((Text, [Text]))] -> Text
/// ```
pub fn static_generics_f(gs_p0: &crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>) -> crate::prelude::Text {
    generics_f(&crate::prelude::each(gs_p0, &(|(g_p1, bs_p2): &(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)| (g_p1.clone(), crate::prelude::push(bs_p2, &crate::prelude::Text::lit("\'static"))))))
}

/// ```prism
/// RustJob: unbounded fn JobDef -> Text
/// ```
pub fn rust_job_f(j_p0: &crate::lower::model::JobDef) -> crate::prelude::Text {
    let gnames_p1 = generic_names_f(&crate::prelude::each(&j_p0.generics_p, &(|(g_pb, _): &(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)| g_pb.clone())));
    let named_p2 = crate::prelude::fold(&j_p0.fields_p, &crate::prelude::Array::new(), &(|acc_pc: &crate::prelude::Array<crate::prelude::Text>, (_, t_pd): &(crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::append(acc_pc, &crate::lower::functions::ty_params_in_f(t_pd))));
    let unnamed_p3 = crate::prelude::filter(&crate::prelude::each(&j_p0.generics_p, &(|(g_pe, _): &(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)| g_pe.clone())), &(|g_pf: &crate::prelude::Text| !crate::prelude::fold(&named_p2, &false, &(|found_pg: &bool, other_ph: &crate::prelude::Text| *found_pg || (other_ph == g_pf)))));
    let marker_p4 = if &crate::prelude::len(&unnamed_p3) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Array::new()
    } else {
        crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("pub type_parameters: ::std::marker::PhantomData<({},)>,", &crate::syntax::lexer::chars::join_f(&unnamed_p3, &crate::prelude::Text::lit(", "))))])
    };
    let fields_p5 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::run_to_end(crate::prelude::each_job(j_p0.fields_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (n_pi, t_pj) = p0;
        crate::prelude::call_then(crate::emit::rust::start_type_f(t_pj.clone()), move |type_f_8107: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("pub {}: {},", &n_pi, &type_f_8107))))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &marker_p4), &crate::prelude::Text::lit("\n"));
    let params_p6 = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(j_p0.fields_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (n_pk, t_pl) = p0;
        crate::prelude::call_then(crate::emit::rust::start_type_f(t_pl.clone()), move |type_f_8190: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}: {}", &n_pk, &type_f_8190))))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit(", "));
    let bounded_p7 = static_generics_f(&j_p0.generics_p);
    let start_p8 = crate::prelude::Text::from(format!("pub fn {}{}({}) -> ::std::rc::Rc<dyn ::prism_rtl::Job<{}>>", &j_p0.start_p, &bounded_p7, &params_p6, &crate::emit::rust::type_f(&j_p0.ret_p)));
    let made_p9 = crate::prelude::append(&crate::prelude::each(&j_p0.fields_p, &(|(n_pm, _): &(crate::prelude::Text, crate::lower::model::OutTy)| n_pm.clone())), &(if &crate::prelude::len(&unnamed_p3) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Array::new()
    } else {
        crate::prelude::Array::from(vec![crate::prelude::Text::lit("type_parameters: ::std::marker::PhantomData")])
    }));
    let start_body_pa = crate::prelude::Text::from(format!("::std::rc::Rc::new({}{} {{ {} }})", &j_p0.name_p, &(if &gnames_p1 == &crate::prelude::Text::lit("") {
        crate::prelude::Text::lit("")
    } else {
        crate::prelude::Text::from(format!("::{}", &gnames_p1))
    }), &crate::syntax::lexer::chars::join_f(&made_p9, &crate::prelude::Text::lit(", "))));
    crate::emit::rust::templates::items::job_f(&crate::emit::rust::templates::source_doc_f(&crate::prelude::Text::lit(""), &j_p0.doc_p), &j_p0.name_p, &gnames_p1, &bounded_p7, &fields_p5, &crate::emit::rust::type_f(&j_p0.ret_p), &crate::emit::rust::body_lines_f(&j_p0.body_p), &start_p8, &start_body_pa)
}

/// The step machine of `RustJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustJob: unbounded fn JobDef -> Text
/// ```
pub struct RustJob {
    pub j_p0: crate::lower::model::JobDef,
}

impl ::prism_rtl::Job<crate::prelude::Text> for RustJob {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let j_p0 = &self.j_p0;
        let gnames_p1 = generic_names_f(&crate::prelude::each(&j_p0.generics_p, &(|(g_pb, _): &(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)| g_pb.clone())));
        let named_p2 = crate::prelude::fold(&j_p0.fields_p, &crate::prelude::Array::new(), &(|acc_pc: &crate::prelude::Array<crate::prelude::Text>, (_, t_pd): &(crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::append(acc_pc, &crate::lower::functions::ty_params_in_f(t_pd))));
        let unnamed_p3 = crate::prelude::filter(&crate::prelude::each(&j_p0.generics_p, &(|(g_pe, _): &(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)| g_pe.clone())), &(|g_pf: &crate::prelude::Text| !crate::prelude::fold(&named_p2, &false, &(|found_pg: &bool, other_ph: &crate::prelude::Text| *found_pg || (other_ph == g_pf)))));
        let marker_p4 = if &crate::prelude::len(&unnamed_p3) == &crate::prelude::Nat::from(0u32) {
            crate::prelude::Array::new()
        } else {
            crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("pub type_parameters: ::std::marker::PhantomData<({},)>,", &crate::syntax::lexer::chars::join_f(&unnamed_p3, &crate::prelude::Text::lit(", "))))])
        };
        let j_p0x = j_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(j_p0x.fields_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
            let (n_pi, t_pj) = p0;
            crate::prelude::call_then(crate::emit::rust::start_type_f(t_pj.clone()), move |type_f_8107: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("pub {}: {},", &n_pi, &type_f_8107))))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_8069: crate::prelude::Array<crate::prelude::Text>| {
            let fields_p5 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&each_8069, &marker_p4), &crate::prelude::Text::lit("\n"));
            crate::prelude::call_value(crate::prelude::each_job(j_p0x.fields_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
                let (n_pk, t_pl) = p0;
                crate::prelude::call_then(crate::emit::rust::start_type_f(t_pl.clone()), move |type_f_8190: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}: {}", &n_pk, &type_f_8190))))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_8156: crate::prelude::Array<crate::prelude::Text>| {
                let params_p6 = crate::syntax::lexer::chars::join_f(&each_8156, &crate::prelude::Text::lit(", "));
                let bounded_p7 = static_generics_f(&j_p0x.generics_p);
                crate::prelude::call_then(crate::emit::rust::start_type_f(j_p0x.ret_p.clone()), move |type_f_8427: crate::prelude::Text| {
                    let start_p8 = crate::prelude::Text::from(format!("pub fn {}{}({}) -> ::std::rc::Rc<dyn ::prism_rtl::Job<{}>>", &j_p0x.start_p, &bounded_p7, &params_p6, &type_f_8427));
                    let made_p9 = crate::prelude::append(&crate::prelude::each(&j_p0x.fields_p, &(|(n_pm, _): &(crate::prelude::Text, crate::lower::model::OutTy)| n_pm.clone())), &(if &crate::prelude::len(&unnamed_p3) == &crate::prelude::Nat::from(0u32) {
                        crate::prelude::Array::new()
                    } else {
                        crate::prelude::Array::from(vec![crate::prelude::Text::lit("type_parameters: ::std::marker::PhantomData")])
                    }));
                    let start_body_pa = crate::prelude::Text::from(format!("::std::rc::Rc::new({}{} {{ {} }})", &j_p0x.name_p, &(if &gnames_p1 == &crate::prelude::Text::lit("") {
                        crate::prelude::Text::lit("")
                    } else {
                        crate::prelude::Text::from(format!("::{}", &gnames_p1))
                    }), &crate::syntax::lexer::chars::join_f(&made_p9, &crate::prelude::Text::lit(", "))));
                    crate::prelude::call_then(crate::emit::rust::start_type_f(j_p0x.ret_p.clone()), move |type_f_8767: crate::prelude::Text| crate::prelude::call_then(crate::emit::rust::start_body_lines_f(j_p0x.body_p.clone()), move |body_lines_f_8781: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::job_f(&crate::emit::rust::templates::source_doc_f(&crate::prelude::Text::lit(""), &j_p0x.doc_p), &j_p0x.name_p, &gnames_p1, &bounded_p7, &fields_p5, &type_f_8767, &body_lines_f_8781, &start_p8, &start_body_pa))))
                })
            })
        })
    }
}

/// `Start RustJob, x`: what the function value is when passed to `@Run`.
pub fn start_rust_job_f(j_p0: crate::lower::model::JobDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(RustJob { j_p0 })
}

/// ```prism
/// TypeDecl: unbounded fn TyDef -> Text
/// ```
pub fn type_decl_f(t_p0: &crate::lower::model::TyDef) -> crate::prelude::Text {
    let generic_p1 = &crate::prelude::len(&t_p0.params_p) > &crate::prelude::Nat::from(0u32);
    let derives_p2 = if generic_p1 {
        crate::prelude::Text::lit("::std::clone::Clone")
    } else {
        crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("::std::clone::Clone"), if t_p0.eq_p || t_p0.ord_p {
            crate::prelude::Text::lit("::std::cmp::PartialEq, ::std::cmp::Eq")
        } else {
            crate::prelude::Text::lit("")
        }, if t_p0.ord_p {
            crate::prelude::Text::lit("::std::cmp::PartialOrd, ::std::cmp::Ord")
        } else {
            crate::prelude::Text::lit("")
        }]), &(|d_pa: &crate::prelude::Text| d_pa != &crate::prelude::Text::lit(""))), &crate::prelude::Text::lit(", "))
    };
    let head_p3 = crate::prelude::Text::from(format!("{}{}", &t_p0.name_p, &generic_names_f(&t_p0.params_p)));
    let doc_p4 = crate::emit::rust::templates::source_doc_f(&crate::prelude::Text::from(format!("`{}`:", &t_p0.prism_p)), &t_p0.doc_p);
    let decl_p5 = match &t_p0.shape_p {
        crate::lower::model::TyShape::ShapeRecord => {
            let c_pb = crate::prelude::or(&crate::prelude::index(&t_p0.cases_p, &crate::prelude::Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() });
            crate::emit::rust::templates::items::struct_f(&doc_p4, &derives_p2, &head_p3, &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(c_pb.fields_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
                let (f_pc, ft_pd) = p0;
                crate::prelude::call_then(crate::emit::rust::start_type_f(ft_pd.clone()), move |type_f_9830: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("pub {}: {},", &f_pc, &type_f_9830))))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit("\n")))
        },
        crate::lower::model::TyShape::ShapeUnit => crate::emit::rust::templates::items::tuple_struct_f(&doc_p4, &derives_p2, &head_p3, &crate::prelude::Text::lit("")),
        crate::lower::model::TyShape::ShapeNewtype => {
            let c_pe = crate::prelude::or(&crate::prelude::index(&t_p0.cases_p, &crate::prelude::Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() });
            crate::emit::rust::templates::items::tuple_struct_f(&doc_p4, &derives_p2, &head_p3, &crate::prelude::Text::from(format!("({})", &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(c_pe.fields_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
                let (_, ft_pf) = p0;
                crate::prelude::call_then(crate::emit::rust::start_type_f(ft_pf.clone()), move |type_f_10107: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("pub {}", &type_f_10107))))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit(", ")))))
        },
        _ => crate::emit::rust::templates::items::enum_f(&doc_p4, &derives_p2, &head_p3, &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(t_p0.cases_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::CaseDef| crate::prelude::entered(crate::prelude::once_job(move || {
            let c_pg = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(EnumCase { c_p0: c_pg.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::CaseDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit("\n"))),
    };
    let show_p6 = if &t_p0.show_p == &crate::lower::model::Shown::ShownDerived {
        crate::prelude::Text::from(format!("\n{}", &show_impl_f(t_p0, &head_p3)))
    } else {
        crate::prelude::Text::lit("")
    };
    let pod_p7 = if t_p0.pod_p {
        crate::prelude::Text::from(format!("\n{}\n{}", &to_pod_impl_f(t_p0, &head_p3), &from_pod_impl_f(t_p0, &head_p3)))
    } else {
        crate::prelude::Text::lit("")
    };
    let eq_p8 = if generic_p1 && (t_p0.eq_p || t_p0.ord_p) {
        crate::prelude::Text::from(format!("\n{}", &eq_impls_f(t_p0, &head_p3)))
    } else {
        crate::prelude::Text::lit("")
    };
    let ord_p9 = if generic_p1 && t_p0.ord_p {
        crate::prelude::Text::from(format!("\n{}", &ord_impls_f(t_p0, &head_p3)))
    } else {
        crate::prelude::Text::lit("")
    };
    crate::prelude::Text::from(format!("{}{}{}{}{}", &decl_p5, &show_p6, &pod_p7, &eq_p8, &ord_p9))
}

/// The step machine of `TypeDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeDecl: unbounded fn TyDef -> Text
/// ```
pub struct TypeDecl {
    pub t_p0: crate::lower::model::TyDef,
}

impl ::prism_rtl::Job<crate::prelude::Text> for TypeDecl {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let t_p0 = &self.t_p0;
        let generic_p1 = &crate::prelude::len(&t_p0.params_p) > &crate::prelude::Nat::from(0u32);
        let derives_p2 = if generic_p1 {
            crate::prelude::Text::lit("::std::clone::Clone")
        } else {
            crate::syntax::lexer::chars::join_f(&crate::prelude::filter(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("::std::clone::Clone"), if t_p0.eq_p || t_p0.ord_p {
                crate::prelude::Text::lit("::std::cmp::PartialEq, ::std::cmp::Eq")
            } else {
                crate::prelude::Text::lit("")
            }, if t_p0.ord_p {
                crate::prelude::Text::lit("::std::cmp::PartialOrd, ::std::cmp::Ord")
            } else {
                crate::prelude::Text::lit("")
            }]), &(|d_pa: &crate::prelude::Text| d_pa != &crate::prelude::Text::lit(""))), &crate::prelude::Text::lit(", "))
        };
        let head_p3 = crate::prelude::Text::from(format!("{}{}", &t_p0.name_p, &generic_names_f(&t_p0.params_p)));
        let doc_p4 = crate::emit::rust::templates::source_doc_f(&crate::prelude::Text::from(format!("`{}`:", &t_p0.prism_p)), &t_p0.doc_p);
        let generic_p1z = generic_p1;
        let head_p3z = head_p3.clone();
        let t_p0z = t_p0.clone();
        let k_let9608 = move |v9608: crate::prelude::Text| {
            let decl_p5 = v9608;
            let decl_p5z = decl_p5.clone();
            let generic_p1zz = generic_p1z;
            let head_p3zz = head_p3z.clone();
            let t_p0zz = t_p0z.clone();
            let k_let10220 = move |v10220: crate::prelude::Text| {
                let show_p6 = v10220;
                let decl_p5zz = decl_p5z.clone();
                let generic_p1zzz = generic_p1zz;
                let head_p3zzz = head_p3zz.clone();
                let show_p6z = show_p6.clone();
                let t_p0zzz = t_p0zz.clone();
                let k_let10294 = move |v10294: crate::prelude::Text| {
                    let pod_p7 = v10294;
                    let decl_p5zzz = decl_p5zz.clone();
                    let generic_p1zzzz = generic_p1zzz;
                    let head_p3zzzz = head_p3zzz.clone();
                    let pod_p7z = pod_p7.clone();
                    let show_p6zz = show_p6z.clone();
                    let t_p0zzzz = t_p0zzz.clone();
                    let k_let10374 = move |v10374: crate::prelude::Text| {
                        let eq_p8 = v10374;
                        let decl_p5zzzz = decl_p5zzz.clone();
                        let eq_p8z = eq_p8.clone();
                        let pod_p7zz = pod_p7z.clone();
                        let show_p6zzz = show_p6zz.clone();
                        let k_let10450 = move |v10450: crate::prelude::Text| {
                            let ord_p9 = v10450;
                            ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{}{}{}{}", &decl_p5zzzz, &show_p6zzz, &pod_p7zz, &eq_p8z, &ord_p9)))
                        };
                        if generic_p1zzzz && t_p0zzzz.ord_p {
                            crate::prelude::call_then(start_ord_impls_f(t_p0zzzz.clone(), head_p3zzzz.clone()), move |ord_impls_f_10486: crate::prelude::Text| k_let10450(crate::prelude::Text::from(format!("\n{}", &ord_impls_f_10486))))
                        } else {
                            k_let10450(crate::prelude::Text::lit(""))
                        }
                    };
                    if generic_p1zzz && (t_p0zzz.eq_p || t_p0zzz.ord_p) {
                        crate::prelude::call_then(start_eq_impls_f(t_p0zzz.clone(), head_p3zzz.clone()), move |eq_impls_f_10419: crate::prelude::Text| k_let10374(crate::prelude::Text::from(format!("\n{}", &eq_impls_f_10419))))
                    } else {
                        k_let10374(crate::prelude::Text::lit(""))
                    }
                };
                if t_p0zz.pod_p {
                    crate::prelude::call_then(start_to_pod_impl_f(t_p0zz.clone(), head_p3zz.clone()), move |to_pod_impl_f_10318: crate::prelude::Text| crate::prelude::call_then(start_from_pod_impl_f(t_p0zz.clone(), head_p3zz.clone()), move |from_pod_impl_f_10339: crate::prelude::Text| k_let10294(crate::prelude::Text::from(format!("\n{}\n{}", &to_pod_impl_f_10318, &from_pod_impl_f_10339)))))
                } else {
                    k_let10294(crate::prelude::Text::lit(""))
                }
            };
            if &t_p0z.show_p == &crate::lower::model::Shown::ShownDerived {
                crate::prelude::call_then(start_show_impl_f(t_p0z.clone(), head_p3z.clone()), move |show_impl_f_10262: crate::prelude::Text| k_let10220(crate::prelude::Text::from(format!("\n{}", &show_impl_f_10262))))
            } else {
                k_let10220(crate::prelude::Text::lit(""))
            }
        };
        match t_p0.shape_p.clone() {
            crate::lower::model::TyShape::ShapeRecord => {
                let c_pb = crate::prelude::or(&crate::prelude::index(&t_p0.cases_p, &crate::prelude::Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() });
                crate::prelude::call_value(crate::prelude::each_job(c_pb.fields_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let (f_pc, ft_pd) = p0;
                    crate::prelude::call_then(crate::emit::rust::start_type_f(ft_pd.clone()), move |type_f_9830: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("pub {}: {},", &f_pc, &type_f_9830))))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_9791: crate::prelude::Array<crate::prelude::Text>| k_let9608(crate::emit::rust::templates::items::struct_f(&doc_p4, &derives_p2, &head_p3, &crate::syntax::lexer::chars::join_f(&each_9791, &crate::prelude::Text::lit("\n")))))
            },
            crate::lower::model::TyShape::ShapeUnit => k_let9608(crate::emit::rust::templates::items::tuple_struct_f(&doc_p4, &derives_p2, &head_p3, &crate::prelude::Text::lit(""))),
            crate::lower::model::TyShape::ShapeNewtype => {
                let c_pe = crate::prelude::or(&crate::prelude::index(&t_p0.cases_p, &crate::prelude::Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() });
                crate::prelude::call_value(crate::prelude::each_job(c_pe.fields_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let (_, ft_pf) = p0;
                    crate::prelude::call_then(crate::emit::rust::start_type_f(ft_pf.clone()), move |type_f_10107: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("pub {}", &type_f_10107))))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_10068: crate::prelude::Array<crate::prelude::Text>| k_let9608(crate::emit::rust::templates::items::tuple_struct_f(&doc_p4, &derives_p2, &head_p3, &crate::prelude::Text::from(format!("({})", &crate::syntax::lexer::chars::join_f(&each_10068, &crate::prelude::Text::lit(", ")))))))
            },
            _ => {
                let t_p0x = t_p0.clone();
                crate::prelude::call_value(crate::prelude::each_job(t_p0x.cases_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::CaseDef| crate::prelude::entered(crate::prelude::once_job(move || {
                    let c_pg = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(EnumCase { c_p0: c_pg.clone() }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::CaseDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_10178: crate::prelude::Array<crate::prelude::Text>| k_let9608(crate::emit::rust::templates::items::enum_f(&doc_p4, &derives_p2, &head_p3, &crate::syntax::lexer::chars::join_f(&each_10178, &crate::prelude::Text::lit("\n")))))
            },
        }
    }
}

/// `Start TypeDecl, x`: what the function value is when passed to `@Run`.
pub fn start_type_decl_f(t_p0: crate::lower::model::TyDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(TypeDecl { t_p0 })
}

/// ```prism
/// CasePatternAs: fn TyDef, CaseDef, Text -> Text
/// ```
pub fn case_pattern_as_f(t_p0: &crate::lower::model::TyDef, c_p1: &crate::lower::model::CaseDef, prefix_p2: &crate::prelude::Text) -> crate::prelude::Text {
    let names_p3 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&c_p1.fields_p)), &(|i_p4: &crate::prelude::Nat| crate::prelude::Text::from(format!("{}{}", prefix_p2, i_p4)))), &crate::prelude::Text::lit(", "));
    match &t_p0.shape_p {
        crate::lower::model::TyShape::ShapeNewtype => crate::prelude::Text::from(format!("{}({})", &t_p0.name_p, &names_p3)),
        crate::lower::model::TyShape::ShapeUnit => t_p0.name_p.clone(),
        _ => if &crate::prelude::len(&c_p1.fields_p) == &crate::prelude::Nat::from(0u32) {
            crate::prelude::Text::from(format!("{}::{}", &t_p0.name_p, &c_p1.name_p))
        } else {
            crate::prelude::Text::from(format!("{}::{}({})", &t_p0.name_p, &c_p1.name_p, &names_p3))
        },
    }
}

/// ```prism
/// FieldPairs: fn TyDef, CaseDef -> [((Text, Text))]
/// ```
pub fn field_pairs_f(t_p0: &crate::lower::model::TyDef, c_p1: &crate::lower::model::CaseDef) -> crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)> {
    match &t_p0.shape_p {
        crate::lower::model::TyShape::ShapeRecord => crate::prelude::each(&c_p1.fields_p, &(|(f_p2, _): &(crate::prelude::Text, crate::lower::model::OutTy)| (crate::prelude::Text::from(format!("self.{}", f_p2)), crate::prelude::Text::from(format!("other.{}", f_p2))))),
        _ => crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&c_p1.fields_p)), &(|i_p3: &crate::prelude::Nat| (crate::prelude::Text::from(format!("a{}", i_p3)), crate::prelude::Text::from(format!("b{}", i_p3))))),
    }
}

/// ```prism
/// EqImpls: unbounded fn TyDef, Text -> Text
/// ```
pub fn eq_impls_f(t_p0: &crate::lower::model::TyDef, head_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let body_p2 = match &t_p0.shape_p {
        crate::lower::model::TyShape::ShapeRecord => fields_eq_f(t_p0, &crate::prelude::or(&crate::prelude::index(&t_p0.cases_p, &crate::prelude::Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() })),
        _ => crate::prelude::Text::from(format!("match (self, other) {{\n{}    #[allow(unreachable_patterns)]\n    _ => false,\n}}", &crate::prelude::concat(&crate::prelude::each(&t_p0.cases_p, &(|c_p4: &crate::lower::model::CaseDef| crate::prelude::Text::from(format!("    ({}, {}) => {},\n", &case_pattern_as_f(t_p0, c_p4, &crate::prelude::Text::lit("a")), &case_pattern_as_f(t_p0, c_p4, &crate::prelude::Text::lit("b")), &fields_eq_f(t_p0, c_p4)))))))),
    };
    let eq_impl_p3 = crate::emit::rust::templates::items::impl_f(&bounded_f(&t_p0.params_p, &crate::prelude::Text::lit("::std::cmp::Eq")), &crate::prelude::Text::lit("::std::cmp::PartialEq"), head_p1, &crate::prelude::Text::lit("fn eq(&self, other: &Self) -> bool"), &body_p2);
    crate::prelude::Text::from(format!("{}\nimpl{} ::std::cmp::Eq for {} {{}}", &eq_impl_p3, &bounded_f(&t_p0.params_p, &crate::prelude::Text::lit("::std::cmp::Eq")), head_p1))
}

/// The step machine of `EqImpls`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EqImpls: unbounded fn TyDef, Text -> Text
/// ```
pub struct EqImpls {
    pub t_p0: crate::lower::model::TyDef,
    pub head_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Text> for EqImpls {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let t_p0 = &self.t_p0;
        let head_p1 = &self.head_p1;
        let body_p2 = match &t_p0.shape_p {
            crate::lower::model::TyShape::ShapeRecord => fields_eq_f(t_p0, &crate::prelude::or(&crate::prelude::index(&t_p0.cases_p, &crate::prelude::Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() })),
            _ => crate::prelude::Text::from(format!("match (self, other) {{\n{}    #[allow(unreachable_patterns)]\n    _ => false,\n}}", &crate::prelude::concat(&crate::prelude::each(&t_p0.cases_p, &(|c_p4: &crate::lower::model::CaseDef| crate::prelude::Text::from(format!("    ({}, {}) => {},\n", &case_pattern_as_f(t_p0, c_p4, &crate::prelude::Text::lit("a")), &case_pattern_as_f(t_p0, c_p4, &crate::prelude::Text::lit("b")), &fields_eq_f(t_p0, c_p4)))))))),
        };
        let eq_impl_p3 = crate::emit::rust::templates::items::impl_f(&bounded_f(&t_p0.params_p, &crate::prelude::Text::lit("::std::cmp::Eq")), &crate::prelude::Text::lit("::std::cmp::PartialEq"), head_p1, &crate::prelude::Text::lit("fn eq(&self, other: &Self) -> bool"), &body_p2);
        ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}\nimpl{} ::std::cmp::Eq for {} {{}}", &eq_impl_p3, &bounded_f(&t_p0.params_p, &crate::prelude::Text::lit("::std::cmp::Eq")), head_p1)))
    }
}

/// `Start EqImpls, x`: what the function value is when passed to `@Run`.
pub fn start_eq_impls_f(t_p0: crate::lower::model::TyDef, head_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(EqImpls { t_p0, head_p1 })
}

/// ```prism
/// OrdImpls: unbounded fn TyDef, Text -> Text
/// ```
pub fn ord_impls_f(t_p0: &crate::lower::model::TyDef, head_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let arms_p2 = crate::prelude::concat(&crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&t_p0.cases_p)), &(|i_p7: &crate::prelude::Nat| rank_arm_f(t_p0, i_p7))));
    let rank_p3 = if &crate::prelude::len(&t_p0.cases_p) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::lit("let rank = |x: &Self| -> usize { match *x {} };")
    } else {
        crate::prelude::Text::from(format!("let rank = |x: &Self| match x {{ {}}};", &arms_p2))
    };
    let body_p4 = match &t_p0.shape_p {
        crate::lower::model::TyShape::ShapeRecord => fields_cmp_f(t_p0, &crate::prelude::or(&crate::prelude::index(&t_p0.cases_p, &crate::prelude::Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() })),
        _ => crate::prelude::Text::from(format!("{}\nmatch (self, other) {{\n{}    #[allow(unreachable_patterns)]\n    _ => rank(self).cmp(&rank(other)),\n}}", &rank_p3, &crate::prelude::concat(&crate::prelude::each(&t_p0.cases_p, &(|c_p8: &crate::lower::model::CaseDef| crate::prelude::Text::from(format!("    ({}, {}) => {},\n", &case_pattern_as_f(t_p0, c_p8, &crate::prelude::Text::lit("a")), &case_pattern_as_f(t_p0, c_p8, &crate::prelude::Text::lit("b")), &fields_cmp_f(t_p0, c_p8)))))))),
    };
    let partial_p5 = crate::emit::rust::templates::items::impl_f(&bounded_f(&t_p0.params_p, &crate::prelude::Text::lit("::std::cmp::Ord")), &crate::prelude::Text::lit("::std::cmp::PartialOrd"), head_p1, &crate::prelude::Text::lit("fn partial_cmp(&self, other: &Self) -> ::std::option::Option<::std::cmp::Ordering>"), &crate::prelude::Text::lit("::std::option::Option::Some(::std::cmp::Ord::cmp(self, other))"));
    let total_p6 = crate::emit::rust::templates::items::impl_f(&bounded_f(&t_p0.params_p, &crate::prelude::Text::lit("::std::cmp::Ord")), &crate::prelude::Text::lit("::std::cmp::Ord"), head_p1, &crate::prelude::Text::lit("fn cmp(&self, other: &Self) -> ::std::cmp::Ordering"), &body_p4);
    crate::prelude::Text::from(format!("{}\n{}", &partial_p5, &total_p6))
}

/// The step machine of `OrdImpls`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OrdImpls: unbounded fn TyDef, Text -> Text
/// ```
pub struct OrdImpls {
    pub t_p0: crate::lower::model::TyDef,
    pub head_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Text> for OrdImpls {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let t_p0 = &self.t_p0;
        let head_p1 = &self.head_p1;
        let arms_p2 = crate::prelude::concat(&crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&t_p0.cases_p)), &(|i_p7: &crate::prelude::Nat| rank_arm_f(t_p0, i_p7))));
        let rank_p3 = if &crate::prelude::len(&t_p0.cases_p) == &crate::prelude::Nat::from(0u32) {
            crate::prelude::Text::lit("let rank = |x: &Self| -> usize { match *x {} };")
        } else {
            crate::prelude::Text::from(format!("let rank = |x: &Self| match x {{ {}}};", &arms_p2))
        };
        let body_p4 = match &t_p0.shape_p {
            crate::lower::model::TyShape::ShapeRecord => fields_cmp_f(t_p0, &crate::prelude::or(&crate::prelude::index(&t_p0.cases_p, &crate::prelude::Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() })),
            _ => crate::prelude::Text::from(format!("{}\nmatch (self, other) {{\n{}    #[allow(unreachable_patterns)]\n    _ => rank(self).cmp(&rank(other)),\n}}", &rank_p3, &crate::prelude::concat(&crate::prelude::each(&t_p0.cases_p, &(|c_p8: &crate::lower::model::CaseDef| crate::prelude::Text::from(format!("    ({}, {}) => {},\n", &case_pattern_as_f(t_p0, c_p8, &crate::prelude::Text::lit("a")), &case_pattern_as_f(t_p0, c_p8, &crate::prelude::Text::lit("b")), &fields_cmp_f(t_p0, c_p8)))))))),
        };
        let partial_p5 = crate::emit::rust::templates::items::impl_f(&bounded_f(&t_p0.params_p, &crate::prelude::Text::lit("::std::cmp::Ord")), &crate::prelude::Text::lit("::std::cmp::PartialOrd"), head_p1, &crate::prelude::Text::lit("fn partial_cmp(&self, other: &Self) -> ::std::option::Option<::std::cmp::Ordering>"), &crate::prelude::Text::lit("::std::option::Option::Some(::std::cmp::Ord::cmp(self, other))"));
        let total_p6 = crate::emit::rust::templates::items::impl_f(&bounded_f(&t_p0.params_p, &crate::prelude::Text::lit("::std::cmp::Ord")), &crate::prelude::Text::lit("::std::cmp::Ord"), head_p1, &crate::prelude::Text::lit("fn cmp(&self, other: &Self) -> ::std::cmp::Ordering"), &body_p4);
        ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}\n{}", &partial_p5, &total_p6)))
    }
}

/// `Start OrdImpls, x`: what the function value is when passed to `@Run`.
pub fn start_ord_impls_f(t_p0: crate::lower::model::TyDef, head_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(OrdImpls { t_p0, head_p1 })
}

/// ```prism
/// FieldsEq: fn TyDef, CaseDef -> Text
/// ```
pub fn fields_eq_f(t_p0: &crate::lower::model::TyDef, c_p1: &crate::lower::model::CaseDef) -> crate::prelude::Text {
    crate::prelude::fold(&field_pairs_f(t_p0, c_p1), &crate::prelude::Text::lit("true"), &(|acc_p2: &crate::prelude::Text, (a_p3, b_p4): &(crate::prelude::Text, crate::prelude::Text)| crate::prelude::Text::from(format!("{} && {} == {}", acc_p2, a_p3, b_p4))))
}

/// ```prism
/// FieldsCmp: fn TyDef, CaseDef -> Text
/// ```
pub fn fields_cmp_f(t_p0: &crate::lower::model::TyDef, c_p1: &crate::lower::model::CaseDef) -> crate::prelude::Text {
    crate::prelude::fold(&field_pairs_f(t_p0, c_p1), &crate::prelude::Text::lit("::std::cmp::Ordering::Equal"), &(|acc_p2: &crate::prelude::Text, (a_p3, b_p4): &(crate::prelude::Text, crate::prelude::Text)| crate::prelude::Text::from(format!("{}.then_with(|| {}.cmp(&{}))", acc_p2, a_p3, b_p4))))
}

/// ```prism
/// RankArm: fn TyDef, Nat -> Text
/// ```
pub fn rank_arm_f(t_p0: &crate::lower::model::TyDef, i_p1: &crate::prelude::Nat) -> crate::prelude::Text {
    match crate::prelude::index(&t_p0.cases_p, i_p1) {
        ::std::option::Option::Some(c_p2) => crate::prelude::Text::from(format!("{} => {}usize, ", &case_rank_pattern_f(t_p0, &c_p2), i_p1)),
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// CaseRankPattern: fn TyDef, CaseDef -> Text
/// ```
pub fn case_rank_pattern_f(t_p0: &crate::lower::model::TyDef, c_p1: &crate::lower::model::CaseDef) -> crate::prelude::Text {
    match &t_p0.shape_p {
        crate::lower::model::TyShape::ShapeNewtype => crate::prelude::Text::from(format!("{}(..)", &t_p0.name_p)),
        crate::lower::model::TyShape::ShapeUnit => t_p0.name_p.clone(),
        _ => if &crate::prelude::len(&c_p1.fields_p) == &crate::prelude::Nat::from(0u32) {
            crate::prelude::Text::from(format!("{}::{}", &t_p0.name_p, &c_p1.name_p))
        } else {
            crate::prelude::Text::from(format!("{}::{}(..)", &t_p0.name_p, &c_p1.name_p))
        },
    }
}

/// ```prism
/// EnumCase: unbounded fn CaseDef -> Text
/// ```
pub fn enum_case_f(c_p0: &crate::lower::model::CaseDef) -> crate::prelude::Text {
    if &crate::prelude::len(&c_p0.fields_p) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::from(format!("{},", &c_p0.name_p))
    } else {
        crate::prelude::Text::from(format!("{}({}),", &c_p0.name_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(c_p0.fields_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
            let (_, ft_p1) = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::rust::Type { t_p0: ft_p1.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit(", "))))
    }
}

/// The step machine of `EnumCase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EnumCase: unbounded fn CaseDef -> Text
/// ```
pub struct EnumCase {
    pub c_p0: crate::lower::model::CaseDef,
}

impl ::prism_rtl::Job<crate::prelude::Text> for EnumCase {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let c_p0 = &self.c_p0;
        if &crate::prelude::len(&c_p0.fields_p) == &crate::prelude::Nat::from(0u32) {
            ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{},", &c_p0.name_p)))
        } else {
            {
                let c_p0x = c_p0.clone();
                crate::prelude::call_value(crate::prelude::each_job(c_p0x.fields_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let (_, ft_p1) = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::rust::Type { t_p0: ft_p1.clone() }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_14139: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}({}),", &c_p0x.name_p, &crate::syntax::lexer::chars::join_f(&each_14139, &crate::prelude::Text::lit(", "))))))
            }
        }
    }
}

/// `Start EnumCase, x`: what the function value is when passed to `@Run`.
pub fn start_enum_case_f(c_p0: crate::lower::model::CaseDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(EnumCase { c_p0 })
}

/// ```prism
/// Binders: fn Nat -> [Text]
/// ```
pub fn binders_f(n_p0: &crate::prelude::Nat) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::each(&crate::check::errors::range0_f(n_p0), &(|i_p1: &crate::prelude::Nat| crate::prelude::Text::from(format!("a{}", i_p1))))
}

/// ```prism
/// CasePattern: fn TyDef, CaseDef -> Text
/// ```
pub fn case_pattern_f(t_p0: &crate::lower::model::TyDef, c_p1: &crate::lower::model::CaseDef) -> crate::prelude::Text {
    match &t_p0.shape_p {
        crate::lower::model::TyShape::ShapeNewtype => crate::prelude::Text::from(format!("{}({})", &t_p0.name_p, &crate::syntax::lexer::chars::join_f(&binders_f(&crate::prelude::len(&c_p1.fields_p)), &crate::prelude::Text::lit(", ")))),
        crate::lower::model::TyShape::ShapeUnit => t_p0.name_p.clone(),
        _ => if &crate::prelude::len(&c_p1.fields_p) == &crate::prelude::Nat::from(0u32) {
            crate::prelude::Text::from(format!("{}::{}", &t_p0.name_p, &c_p1.name_p))
        } else {
            crate::prelude::Text::from(format!("{}::{}({})", &t_p0.name_p, &c_p1.name_p, &crate::syntax::lexer::chars::join_f(&binders_f(&crate::prelude::len(&c_p1.fields_p)), &crate::prelude::Text::lit(", "))))
        },
    }
}

/// ```prism
/// MatchSelfOf: fn TyDef, Text -> Text
/// ```
pub fn match_self_of_f(t_p0: &crate::lower::model::TyDef, arms_p1: &crate::prelude::Text) -> crate::prelude::Text {
    if &crate::prelude::len(&t_p0.cases_p) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::lit("match *self {}")
    } else {
        crate::emit::rust::templates::items::match_self_f(arms_p1)
    }
}

/// ```prism
/// ShowImpl: unbounded fn TyDef, Text -> Text
/// ```
pub fn show_impl_f(t_p0: &crate::lower::model::TyDef, head_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let body_p2 = match &t_p0.shape_p {
        crate::lower::model::TyShape::ShapeRecord => {
            let c_p3 = crate::prelude::or(&crate::prelude::index(&t_p0.cases_p, &crate::prelude::Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() });
            crate::prelude::Text::from(format!("p.record(\"{}\", &[{}]);", &t_p0.prism_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&c_p3.fields_p, &(|(f_p4, _): &(crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("(\"{}\", &self.{})", &prism_field_of_f(&c_p3, f_p4), f_p4)))), &crate::prelude::Text::lit(", "))))
        },
        _ => match_self_of_f(t_p0, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&t_p0.cases_p, &(|c_p5: &crate::lower::model::CaseDef| crate::prelude::Text::from(format!("{} => p.choice(\"{}\", &[{}]),", &case_pattern_f(t_p0, c_p5), &c_p5.prism_p, &crate::syntax::lexer::chars::join_f(&binders_f(&crate::prelude::len(&c_p5.fields_p)), &crate::prelude::Text::lit(", ")))))), &crate::prelude::Text::lit("\n"))),
    };
    crate::emit::rust::templates::items::impl_f(&bounded_keyed_f(t_p0, &crate::prelude::Text::lit("crate::prelude::Show + ::std::clone::Clone")), &crate::prelude::Text::lit("crate::prelude::Show"), head_p1, &crate::prelude::Text::lit("fn show(&self, p: &mut crate::prelude::Printer)"), &body_p2)
}

/// The step machine of `ShowImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowImpl: unbounded fn TyDef, Text -> Text
/// ```
pub struct ShowImpl {
    pub t_p0: crate::lower::model::TyDef,
    pub head_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Text> for ShowImpl {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let t_p0 = &self.t_p0;
        let head_p1 = &self.head_p1;
        let body_p2 = match &t_p0.shape_p {
            crate::lower::model::TyShape::ShapeRecord => {
                let c_p3 = crate::prelude::or(&crate::prelude::index(&t_p0.cases_p, &crate::prelude::Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() });
                crate::prelude::Text::from(format!("p.record(\"{}\", &[{}]);", &t_p0.prism_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&c_p3.fields_p, &(|(f_p4, _): &(crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("(\"{}\", &self.{})", &prism_field_of_f(&c_p3, f_p4), f_p4)))), &crate::prelude::Text::lit(", "))))
            },
            _ => match_self_of_f(t_p0, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&t_p0.cases_p, &(|c_p5: &crate::lower::model::CaseDef| crate::prelude::Text::from(format!("{} => p.choice(\"{}\", &[{}]),", &case_pattern_f(t_p0, c_p5), &c_p5.prism_p, &crate::syntax::lexer::chars::join_f(&binders_f(&crate::prelude::len(&c_p5.fields_p)), &crate::prelude::Text::lit(", ")))))), &crate::prelude::Text::lit("\n"))),
        };
        ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::impl_f(&bounded_keyed_f(t_p0, &crate::prelude::Text::lit("crate::prelude::Show + ::std::clone::Clone")), &crate::prelude::Text::lit("crate::prelude::Show"), head_p1, &crate::prelude::Text::lit("fn show(&self, p: &mut crate::prelude::Printer)"), &body_p2))
    }
}

/// `Start ShowImpl, x`: what the function value is when passed to `@Run`.
pub fn start_show_impl_f(t_p0: crate::lower::model::TyDef, head_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(ShowImpl { t_p0, head_p1 })
}

/// ```prism
/// PrismField: fn Text -> Text
/// ```
pub fn prism_field_f(f_p0: &crate::prelude::Text) -> crate::prelude::Text {
    if &crate::syntax::lexer::chars::last_char_f(f_p0) == &crate::prelude::Text::lit("_") {
        crate::syntax::lexer::chars::before_last_f(f_p0)
    } else {
        f_p0.clone()
    }
}

/// ```prism
/// PrismFieldOf: fn CaseDef, Text -> Text
/// ```
pub fn prism_field_of_f(c_p0: &crate::lower::model::CaseDef, f_p1: &crate::prelude::Text) -> crate::prelude::Text {
    crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&c_p0.fields_p)), &prism_field_f(f_p1), &(|found_p2: &crate::prelude::Text, i_p3: &crate::prelude::Nat| match (crate::prelude::index(&c_p0.fields_p, i_p3), crate::prelude::index(&c_p0.labels_p, i_p3)) {
        (::std::option::Option::Some((g_p4, _)), ::std::option::Option::Some(label_p5)) => if &g_p4 == f_p1 { label_p5 } else { found_p2.clone() },
        _ => found_p2.clone(),
    }))
}

/// ```prism
/// ChoicePodArm: unbounded fn TyDef, Nat -> Text
/// ```
pub fn choice_pod_arm_f(t_p0: &crate::lower::model::TyDef, i_p1: &crate::prelude::Nat) -> crate::prelude::Text {
    let c_p2 = crate::prelude::or(&crate::prelude::index(&t_p0.cases_p, i_p1), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() });
    crate::prelude::Text::from(format!("{} => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at(\"{}\", {}), vec![{}]),", &case_pattern_f(t_p0, &c_p2), &c_p2.prism_p, i_p1, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&binders_f(&crate::prelude::len(&c_p2.fields_p)), &(|b_p3: &crate::prelude::Text| crate::prelude::Text::from(format!("{}.to_pod()", b_p3)))), &crate::prelude::Text::lit(", "))))
}

/// The step machine of `ChoicePodArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ChoicePodArm: unbounded fn TyDef, Nat -> Text
/// ```
pub struct ChoicePodArm {
    pub t_p0: crate::lower::model::TyDef,
    pub i_p1: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::prelude::Text> for ChoicePodArm {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let t_p0 = &self.t_p0;
        let i_p1 = &self.i_p1;
        let c_p2 = crate::prelude::or(&crate::prelude::index(&t_p0.cases_p, i_p1), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() });
        ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at(\"{}\", {}), vec![{}]),", &case_pattern_f(t_p0, &c_p2), &c_p2.prism_p, i_p1, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&binders_f(&crate::prelude::len(&c_p2.fields_p)), &(|b_p3: &crate::prelude::Text| crate::prelude::Text::from(format!("{}.to_pod()", b_p3)))), &crate::prelude::Text::lit(", ")))))
    }
}

/// `Start ChoicePodArm, x`: what the function value is when passed to `@Run`.
pub fn start_choice_pod_arm_f(t_p0: crate::lower::model::TyDef, i_p1: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(ChoicePodArm { t_p0, i_p1 })
}

/// ```prism
/// ToPodImpl: unbounded fn TyDef, Text -> Text
/// ```
pub fn to_pod_impl_f(t_p0: &crate::lower::model::TyDef, head_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let body_p2 = match &t_p0.shape_p {
        crate::lower::model::TyShape::ShapeRecord => {
            let c_p5 = crate::prelude::or(&crate::prelude::index(&t_p0.cases_p, &crate::prelude::Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() });
            crate::prelude::Text::from(format!("crate::prelude::Pod::record(\"{}\", vec![{}])", &t_p0.prism_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&c_p5.fields_p, &(|(f_p6, _): &(crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("(\"{}\", self.{}.to_pod())", &prism_field_of_f(&c_p5, f_p6), f_p6)))), &crate::prelude::Text::lit(", "))))
        },
        _ => match_self_of_f(t_p0, &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&t_p0.cases_p)), {
            let t_p0x = t_p0.clone();
            ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                let t_p0xy = t_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let i_p7 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(ChoicePodArm { t_p0: t_p0xy.clone(), i_p1: i_p7.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
        })), &crate::prelude::Text::lit("\n"))),
    };
    let shown_p3 = if &t_p0.show_p == &crate::lower::model::Shown::ShownOwn {
        crate::emit::rust::templates::items::shown_pod_f(&body_p2)
    } else {
        body_p2.clone()
    };
    let bound_p4 = if (&t_p0.show_p == &crate::lower::model::Shown::ShownOwn) && (&crate::prelude::len(&t_p0.params_p) > &crate::prelude::Nat::from(0u32)) {
        crate::prelude::Text::from(format!(" where {}: crate::prelude::Show", head_p1))
    } else {
        crate::prelude::Text::lit("")
    };
    crate::emit::rust::templates::items::impl_f(&bounded_keyed_f(t_p0, &crate::prelude::Text::lit("crate::prelude::ToPod + ::std::clone::Clone")), &crate::prelude::Text::lit("crate::prelude::ToPod"), &crate::prelude::Text::from(format!("{}{}", head_p1, &bound_p4)), &crate::prelude::Text::lit("fn to_pod(&self) -> crate::prelude::Pod"), &shown_p3)
}

/// The step machine of `ToPodImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ToPodImpl: unbounded fn TyDef, Text -> Text
/// ```
pub struct ToPodImpl {
    pub t_p0: crate::lower::model::TyDef,
    pub head_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Text> for ToPodImpl {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let t_p0 = &self.t_p0;
        let head_p1 = &self.head_p1;
        let head_p1z = head_p1.clone();
        let t_p0z = t_p0.clone();
        let k_let16984 = move |v16984: crate::prelude::Text| {
            let body_p2 = v16984;
            let shown_p3 = if &t_p0z.show_p == &crate::lower::model::Shown::ShownOwn {
                crate::emit::rust::templates::items::shown_pod_f(&body_p2)
            } else {
                body_p2.clone()
            };
            let bound_p4 = if (&t_p0z.show_p == &crate::lower::model::Shown::ShownOwn) && (&crate::prelude::len(&t_p0z.params_p) > &crate::prelude::Nat::from(0u32)) {
                crate::prelude::Text::from(format!(" where {}: crate::prelude::Show", &head_p1z))
            } else {
                crate::prelude::Text::lit("")
            };
            ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::impl_f(&bounded_keyed_f(&t_p0z, &crate::prelude::Text::lit("crate::prelude::ToPod + ::std::clone::Clone")), &crate::prelude::Text::lit("crate::prelude::ToPod"), &crate::prelude::Text::from(format!("{}{}", &head_p1z, &bound_p4)), &crate::prelude::Text::lit("fn to_pod(&self) -> crate::prelude::Pod"), &shown_p3))
        };
        match t_p0.shape_p.clone() {
            crate::lower::model::TyShape::ShapeRecord => {
                let c_p5 = crate::prelude::or(&crate::prelude::index(&t_p0.cases_p, &crate::prelude::Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() });
                k_let16984(crate::prelude::Text::from(format!("crate::prelude::Pod::record(\"{}\", vec![{}])", &t_p0.prism_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&c_p5.fields_p, &(|(f_p6, _): &(crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("(\"{}\", self.{}.to_pod())", &prism_field_of_f(&c_p5, f_p6), f_p6)))), &crate::prelude::Text::lit(", ")))))
            },
            _ => {
                let t_p0x = t_p0.clone();
                crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&crate::prelude::len(&t_p0x.cases_p)), {
                    let t_p0xx = t_p0x.clone();
                    ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                        let t_p0xxy = t_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let i_p7 = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(ChoicePodArm { t_p0: t_p0xxy.clone(), i_p1: i_p7.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
                }), move |each_17320: crate::prelude::Array<crate::prelude::Text>| k_let16984(match_self_of_f(&t_p0x, &crate::syntax::lexer::chars::join_f(&each_17320, &crate::prelude::Text::lit("\n")))))
            },
        }
    }
}

/// `Start ToPodImpl, x`: what the function value is when passed to `@Run`.
pub fn start_to_pod_impl_f(t_p0: crate::lower::model::TyDef, head_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(ToPodImpl { t_p0, head_p1 })
}

/// ```prism
/// FromPodImpl: unbounded fn TyDef, Text -> Text
/// ```
pub fn from_pod_impl_f(t_p0: &crate::lower::model::TyDef, head_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let body_p2 = match &t_p0.shape_p {
        crate::lower::model::TyShape::ShapeRecord => {
            let c_p3 = crate::prelude::or(&crate::prelude::index(&t_p0.cases_p, &crate::prelude::Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() });
            crate::prelude::Text::from(format!("::std::result::Result::Ok({} {{ {} }})", &t_p0.name_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&c_p3.fields_p, &(|(f_p4, _): &(crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("{}: crate::prelude::FromPod::from_pod(crate::prelude::field(p, \"{}\")?)?", f_p4, &prism_field_of_f(&c_p3, f_p4))))), &crate::prelude::Text::lit(", "))))
        },
        _ => {
            let arms_p5 = crate::prelude::each(&t_p0.cases_p, &(|c_p6: &crate::lower::model::CaseDef| {
                let n_p7 = crate::prelude::len(&c_p6.fields_p);
                let made_p8 = if &n_p7 == &crate::prelude::Nat::from(0u32) {
                    if &t_p0.shape_p == &crate::lower::model::TyShape::ShapeUnit {
                        t_p0.name_p.clone()
                    } else {
                        crate::prelude::Text::from(format!("{}::{}", &t_p0.name_p, &c_p6.name_p))
                    }
                } else {
                    crate::prelude::Text::from(format!("{}({})", &(if &t_p0.shape_p == &crate::lower::model::TyShape::ShapeNewtype {
                        t_p0.name_p.clone()
                    } else {
                        crate::prelude::Text::from(format!("{}::{}", &t_p0.name_p, &c_p6.name_p))
                    }), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::check::errors::range0_f(&n_p7), &(|i_p9: &crate::prelude::Nat| crate::prelude::Text::from(format!("crate::prelude::FromPod::from_pod(&a[{}])?", i_p9)))), &crate::prelude::Text::lit(", "))))
                };
                crate::prelude::Text::from(format!("crate::prelude::Pod::Choice(c, a) if &**c == \"{}\" && a.len() == {} => ::std::result::Result::Ok({}),", &c_p6.prism_p, &n_p7, &made_p8))
            }));
            crate::emit::rust::templates::items::from_pod_body_f(&crate::syntax::lexer::chars::join_f(&arms_p5, &crate::prelude::Text::lit("\n")), &crate::prelude::Text::from(format!("a {}", &t_p0.prism_p)))
        },
    };
    crate::emit::rust::templates::items::impl_f(&bounded_keyed_f(t_p0, &crate::prelude::Text::lit("crate::prelude::FromPod + ::std::clone::Clone")), &crate::prelude::Text::lit("crate::prelude::FromPod"), head_p1, &crate::prelude::Text::lit("fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault>"), &body_p2)
}

/// The step machine of `FromPodImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FromPodImpl: unbounded fn TyDef, Text -> Text
/// ```
pub struct FromPodImpl {
    pub t_p0: crate::lower::model::TyDef,
    pub head_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Text> for FromPodImpl {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let t_p0 = &self.t_p0;
        let head_p1 = &self.head_p1;
        let body_p2 = match &t_p0.shape_p {
            crate::lower::model::TyShape::ShapeRecord => {
                let c_p3 = crate::prelude::or(&crate::prelude::index(&t_p0.cases_p, &crate::prelude::Nat::from(0u32)), &crate::lower::model::CaseDef { name_p: crate::prelude::Text::lit(""), prism_p: crate::prelude::Text::lit(""), fields_p: crate::prelude::Array::new(), labels_p: crate::prelude::Array::new() });
                crate::prelude::Text::from(format!("::std::result::Result::Ok({} {{ {} }})", &t_p0.name_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&c_p3.fields_p, &(|(f_p4, _): &(crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("{}: crate::prelude::FromPod::from_pod(crate::prelude::field(p, \"{}\")?)?", f_p4, &prism_field_of_f(&c_p3, f_p4))))), &crate::prelude::Text::lit(", "))))
            },
            _ => {
                let arms_p5 = crate::prelude::each(&t_p0.cases_p, &(|c_p6: &crate::lower::model::CaseDef| {
                    let n_p7 = crate::prelude::len(&c_p6.fields_p);
                    let made_p8 = if &n_p7 == &crate::prelude::Nat::from(0u32) {
                        if &t_p0.shape_p == &crate::lower::model::TyShape::ShapeUnit {
                            t_p0.name_p.clone()
                        } else {
                            crate::prelude::Text::from(format!("{}::{}", &t_p0.name_p, &c_p6.name_p))
                        }
                    } else {
                        crate::prelude::Text::from(format!("{}({})", &(if &t_p0.shape_p == &crate::lower::model::TyShape::ShapeNewtype {
                            t_p0.name_p.clone()
                        } else {
                            crate::prelude::Text::from(format!("{}::{}", &t_p0.name_p, &c_p6.name_p))
                        }), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::check::errors::range0_f(&n_p7), &(|i_p9: &crate::prelude::Nat| crate::prelude::Text::from(format!("crate::prelude::FromPod::from_pod(&a[{}])?", i_p9)))), &crate::prelude::Text::lit(", "))))
                    };
                    crate::prelude::Text::from(format!("crate::prelude::Pod::Choice(c, a) if &**c == \"{}\" && a.len() == {} => ::std::result::Result::Ok({}),", &c_p6.prism_p, &n_p7, &made_p8))
                }));
                crate::emit::rust::templates::items::from_pod_body_f(&crate::syntax::lexer::chars::join_f(&arms_p5, &crate::prelude::Text::lit("\n")), &crate::prelude::Text::from(format!("a {}", &t_p0.prism_p)))
            },
        };
        ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::impl_f(&bounded_keyed_f(t_p0, &crate::prelude::Text::lit("crate::prelude::FromPod + ::std::clone::Clone")), &crate::prelude::Text::lit("crate::prelude::FromPod"), head_p1, &crate::prelude::Text::lit("fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault>"), &body_p2))
    }
}

/// `Start FromPodImpl, x`: what the function value is when passed to `@Run`.
pub fn start_from_pod_impl_f(t_p0: crate::lower::model::TyDef, head_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(FromPodImpl { t_p0, head_p1 })
}

/// ```prism
/// RustTag: unbounded fn TagDef -> Text
/// ```
pub fn rust_tag_f(t_p0: &crate::lower::model::TagDef) -> crate::prelude::Text {
    let fields_p1 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::run_to_end(crate::prelude::each_job(t_p0.fields_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (_, f_pa, ft_pb) = p0;
        crate::prelude::call_then(crate::emit::rust::start_type_f(ft_pb.clone()), move |type_f_19096: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("pub {}: {},", &f_pa, &type_f_19096))))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::run_to_end(crate::prelude::each_job(t_p0.events_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (f_pc, et_pd) = p0;
        crate::prelude::call_then(crate::emit::rust::start_type_f(crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(et_pd.clone()))), move |type_f_19149: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("pub {}: {},", &f_pc, &type_f_19149))))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>))), &crate::prelude::Text::lit("\n"));
    let pods_p2 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&t_p0.fields_p, &(|(p_pe, f_pf, _): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("(\"{}\", self.{}.to_pod())", p_pe, f_pf)))), &crate::prelude::Text::lit(", "));
    let derives_p3 = if t_p0.eq_p {
        crate::prelude::Text::lit("::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq")
    } else {
        crate::prelude::Text::lit("::std::clone::Clone")
    };
    let reads_p4 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::each(&t_p0.fields_p, &(|(p_pg, f_ph, _): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("{}: crate::prelude::FromPod::from_pod(crate::prelude::field(p, \"{}\")?)?", f_ph, p_pg)))), &crate::prelude::each(&t_p0.events_p, &(|(f_pi, _): &(crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("{}: crate::prelude::Event::never()", f_pi))))), &crate::prelude::Text::lit(", "));
    let back_p5 = if t_p0.pod_p {
        crate::prelude::Text::from(format!("\n{}", &crate::emit::rust::templates::items::tag_from_pod_f(&t_p0.name_p, &t_p0.tag_name_p, &reads_p4)))
    } else {
        crate::prelude::Text::lit("")
    };
    let deep_p6 = crate::prelude::run_to_end(crate::prelude::fold_job(t_p0.fields_p.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy))| crate::prelude::entered(crate::prelude::once_job(move || {
        let d_pj = p0;
        let (_, _, ft_pk) = p1;
        if d_pj {
            ::prism_rtl::Turn::Finished(true)
        } else {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::HoldsDyn { t_p0: ft_pk.clone() }))
        }
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>));
    let deep_pods_p7 = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(t_p0.fields_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (p_pl, f_pm, ft_pn) = p0;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(DeepField { p_p0: p_pl.clone(), f_p1: f_pm.clone(), ft_p2: ft_pn.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit(", "));
    let deep_ports_p8 = crate::prelude::concat(&crate::prelude::run_to_end(crate::prelude::each_job(t_p0.fields_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (_, f_po, ft_pp) = p0;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(DeepPorts { f_p0: f_po.clone(), ft_p1: ft_pp.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)));
    let levels_p9 = if deep_p6 {
        crate::prelude::Text::from(format!("\n{}", &crate::emit::rust::templates::items::tag_level_f(&t_p0.name_p, &t_p0.tag_name_p, &deep_pods_p7, &deep_ports_p8)))
    } else {
        crate::prelude::Text::lit("")
    };
    crate::prelude::Text::from(format!("{}{}{}", &crate::emit::rust::templates::items::tag_f(&crate::emit::rust::templates::source_doc_f(&crate::prelude::Text::from(format!("The `Level` of `{}`:", &t_p0.tag_name_p)), &t_p0.doc_p), &derives_p3, &t_p0.name_p, &fields_p1, &t_p0.tag_name_p, &pods_p2), &back_p5, &levels_p9))
}

/// The step machine of `RustTag`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustTag: unbounded fn TagDef -> Text
/// ```
pub struct RustTag {
    pub t_p0: crate::lower::model::TagDef,
}

impl ::prism_rtl::Job<crate::prelude::Text> for RustTag {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let t_p0 = &self.t_p0;
        let t_p0x = t_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(t_p0x.fields_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
            let (_, f_pa, ft_pb) = p0;
            crate::prelude::call_then(crate::emit::rust::start_type_f(ft_pb.clone()), move |type_f_19096: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("pub {}: {},", &f_pa, &type_f_19096))))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_19049: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_value(crate::prelude::each_job(t_p0x.events_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
            let (f_pc, et_pd) = p0;
            crate::prelude::call_then(crate::emit::rust::start_type_f(crate::lower::model::OutTy::OutEvent(::std::rc::Rc::new(et_pd.clone()))), move |type_f_19149: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("pub {}: {},", &f_pc, &type_f_19149))))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_19110: crate::prelude::Array<crate::prelude::Text>| {
            let fields_p1 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&each_19049, &each_19110), &crate::prelude::Text::lit("\n"));
            let pods_p2 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&t_p0x.fields_p, &(|(p_pe, f_pf, _): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("(\"{}\", self.{}.to_pod())", p_pe, f_pf)))), &crate::prelude::Text::lit(", "));
            let derives_p3 = if t_p0x.eq_p {
                crate::prelude::Text::lit("::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq")
            } else {
                crate::prelude::Text::lit("::std::clone::Clone")
            };
            let reads_p4 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::each(&t_p0x.fields_p, &(|(p_pg, f_ph, _): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("{}: crate::prelude::FromPod::from_pod(crate::prelude::field(p, \"{}\")?)?", f_ph, p_pg)))), &crate::prelude::each(&t_p0x.events_p, &(|(f_pi, _): &(crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("{}: crate::prelude::Event::never()", f_pi))))), &crate::prelude::Text::lit(", "));
            let back_p5 = if t_p0x.pod_p {
                crate::prelude::Text::from(format!("\n{}", &crate::emit::rust::templates::items::tag_from_pod_f(&t_p0x.name_p, &t_p0x.tag_name_p, &reads_p4)))
            } else {
                crate::prelude::Text::lit("")
            };
            crate::prelude::call_value(crate::prelude::fold_job(t_p0x.fields_p.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy))| crate::prelude::entered(crate::prelude::once_job(move || {
                let d_pj = p0;
                let (_, _, ft_pk) = p1;
                if d_pj {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::lower::types::HoldsDyn { t_p0: ft_pk.clone() }))
                }
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>), move |fold_19788: bool| {
                let deep_p6 = fold_19788;
                crate::prelude::call_value(crate::prelude::each_job(t_p0x.fields_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let (p_pl, f_pm, ft_pn) = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(DeepField { p_p0: p_pl.clone(), f_p1: f_pm.clone(), ft_p2: ft_pn.clone() }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_19881: crate::prelude::Array<crate::prelude::Text>| {
                    let deep_pods_p7 = crate::syntax::lexer::chars::join_f(&each_19881, &crate::prelude::Text::lit(", "));
                    crate::prelude::call_value(crate::prelude::each_job(t_p0x.fields_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
                        let (_, f_po, ft_pp) = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(DeepPorts { f_p0: f_po.clone(), ft_p1: ft_pp.clone() }))
                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_19966: crate::prelude::Array<crate::prelude::Text>| {
                        let deep_ports_p8 = crate::prelude::concat(&each_19966);
                        let levels_p9 = if deep_p6 {
                            crate::prelude::Text::from(format!("\n{}", &crate::emit::rust::templates::items::tag_level_f(&t_p0x.name_p, &t_p0x.tag_name_p, &deep_pods_p7, &deep_ports_p8)))
                        } else {
                            crate::prelude::Text::lit("")
                        };
                        ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{}{}", &crate::emit::rust::templates::items::tag_f(&crate::emit::rust::templates::source_doc_f(&crate::prelude::Text::from(format!("The `Level` of `{}`:", &t_p0x.tag_name_p)), &t_p0x.doc_p), &derives_p3, &t_p0x.name_p, &fields_p1, &t_p0x.tag_name_p, &pods_p2), &back_p5, &levels_p9)))
                    })
                })
            })
        }))
    }
}

/// `Start RustTag, x`: what the function value is when passed to `@Run`.
pub fn start_rust_tag_f(t_p0: crate::lower::model::TagDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(RustTag { t_p0 })
}

/// ```prism
/// DeepField: unbounded fn Text, Text, OutTy -> Text
/// ```
pub fn deep_field_f(p_p0: &crate::prelude::Text, f_p1: &crate::prelude::Text, ft_p2: &crate::lower::model::OutTy) -> crate::prelude::Text {
    crate::prelude::Text::from(format!("(\"{}\", {})", p_p0, &deep_pod_f(f_p1, ft_p2)))
}

/// The step machine of `DeepField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DeepField: unbounded fn Text, Text, OutTy -> Text
/// ```
pub struct DeepField {
    pub p_p0: crate::prelude::Text,
    pub f_p1: crate::prelude::Text,
    pub ft_p2: crate::lower::model::OutTy,
}

impl ::prism_rtl::Job<crate::prelude::Text> for DeepField {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let p_p0 = &self.p_p0;
        let f_p1 = &self.f_p1;
        let ft_p2 = &self.ft_p2;
        let f_p1x = f_p1.clone();
        let ft_p2x = ft_p2.clone();
        let p_p0x = p_p0.clone();
        crate::prelude::call_then(start_deep_pod_f(f_p1x.clone(), ft_p2x.clone()), move |deep_pod_f_20314: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("(\"{}\", {})", &p_p0x, &deep_pod_f_20314))))
    }
}

/// `Start DeepField, x`: what the function value is when passed to `@Run`.
pub fn start_deep_field_f(p_p0: crate::prelude::Text, f_p1: crate::prelude::Text, ft_p2: crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(DeepField { p_p0, f_p1, ft_p2 })
}

/// ```prism
/// DeepPod: unbounded fn Text, OutTy -> Text
/// ```
pub fn deep_pod_f(f_p0: &crate::prelude::Text, ft_p1: &crate::lower::model::OutTy) -> crate::prelude::Text {
    'm20568: {
        if let crate::lower::model::OutTy::OutMap(_, m20568_0_1) = ft_p1 && let crate::lower::model::OutTy::OutDyn(m20568_0_1_r_0) = &**m20568_0_1 && let crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefItem(m20568_0_1_r_0_r_0_0, m20568_0_1_r_0_r_0_1, _), _) = &**m20568_0_1_r_0 && (m20568_0_1_r_0_r_0_0 == &crate::prelude::Text::lit("")) && (m20568_0_1_r_0_r_0_1 == &crate::prelude::Text::lit("Elem")) {
            break 'm20568 crate::prelude::Text::from(format!("::prism_rtl::dynamics_pod(&self.{}, cx)", f_p0));
        }
        if let crate::lower::model::OutTy::OutDyn(m20568_1_0) = ft_p1 && let crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefItem(m20568_1_0_r_0_0, m20568_1_0_r_0_1, _), _) = &**m20568_1_0 && (m20568_1_0_r_0_0 == &crate::prelude::Text::lit("")) && (m20568_1_0_r_0_1 == &crate::prelude::Text::lit("Elem")) {
            break 'm20568 crate::prelude::Text::from(format!("::prism_rtl::Level::level_pod(&self.{}.sample(cx), cx)", f_p0));
        }
        if let other_p2 = ft_p1 {
            break 'm20568 if crate::lower::types::holds_dyn_f(other_p2) {
                crate::prelude::Text::lit("compile_error!(\"prismc: a tag field holding a dynamic other than `$Elem` or a map of them is not read deep (claude/incremental-host-document.md, doubt WD)\")")
            } else {
                crate::prelude::Text::from(format!("self.{}.to_pod()", f_p0))
            };
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `DeepPod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DeepPod: unbounded fn Text, OutTy -> Text
/// ```
pub struct DeepPod {
    pub f_p0: crate::prelude::Text,
    pub ft_p1: crate::lower::model::OutTy,
}

impl ::prism_rtl::Job<crate::prelude::Text> for DeepPod {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let f_p0 = &self.f_p0;
        let ft_p1 = &self.ft_p1;
        'm20568: {
            if let crate::lower::model::OutTy::OutMap(_, m20568_0_1) = ft_p1 && let crate::lower::model::OutTy::OutDyn(m20568_0_1_r_0) = &**m20568_0_1 && let crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefItem(m20568_0_1_r_0_r_0_0, m20568_0_1_r_0_r_0_1, _), _) = &**m20568_0_1_r_0 && (m20568_0_1_r_0_r_0_0 == &crate::prelude::Text::lit("")) && (m20568_0_1_r_0_r_0_1 == &crate::prelude::Text::lit("Elem")) {
                break 'm20568 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::prism_rtl::dynamics_pod(&self.{}, cx)", f_p0)));
            }
            if let crate::lower::model::OutTy::OutDyn(m20568_1_0) = ft_p1 && let crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefItem(m20568_1_0_r_0_0, m20568_1_0_r_0_1, _), _) = &**m20568_1_0 && (m20568_1_0_r_0_0 == &crate::prelude::Text::lit("")) && (m20568_1_0_r_0_1 == &crate::prelude::Text::lit("Elem")) {
                break 'm20568 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::prism_rtl::Level::level_pod(&self.{}.sample(cx), cx)", f_p0)));
            }
            if let other_p2 = ft_p1 {
                break 'm20568 {
                    let f_p0x = f_p0.clone();
                    let other_p2x = other_p2.clone();
                    crate::prelude::call_then(crate::lower::types::start_holds_dyn_f(other_p2x.clone()), move |holds_dyn_f_20830: bool| if holds_dyn_f_20830 {
                        ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("compile_error!(\"prismc: a tag field holding a dynamic other than `$Elem` or a map of them is not read deep (claude/incremental-host-document.md, doubt WD)\")"))
                    } else {
                        ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("self.{}.to_pod()", &f_p0x)))
                    })
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start DeepPod, x`: what the function value is when passed to `@Run`.
pub fn start_deep_pod_f(f_p0: crate::prelude::Text, ft_p1: crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(DeepPod { f_p0, ft_p1 })
}

/// ```prism
/// DeepPorts: unbounded fn Text, OutTy -> Text
/// ```
pub fn deep_ports_f(f_p0: &crate::prelude::Text, ft_p1: &crate::lower::model::OutTy) -> crate::prelude::Text {
    'm21099: {
        if let crate::lower::model::OutTy::OutMap(_, m21099_0_1) = ft_p1 && let crate::lower::model::OutTy::OutDyn(m21099_0_1_r_0) = &**m21099_0_1 && let crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefItem(m21099_0_1_r_0_r_0_0, m21099_0_1_r_0_r_0_1, _), _) = &**m21099_0_1_r_0 && (m21099_0_1_r_0_r_0_0 == &crate::prelude::Text::lit("")) && (m21099_0_1_r_0_r_0_1 == &crate::prelude::Text::lit("Elem")) {
            break 'm21099 crate::prelude::Text::from(format!("\n        ::prism_rtl::dynamics_ports(&self.{}, cx, out);", f_p0));
        }
        if let crate::lower::model::OutTy::OutDyn(m21099_1_0) = ft_p1 && let crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefItem(m21099_1_0_r_0_0, m21099_1_0_r_0_1, _), _) = &**m21099_1_0 && (m21099_1_0_r_0_0 == &crate::prelude::Text::lit("")) && (m21099_1_0_r_0_1 == &crate::prelude::Text::lit("Elem")) {
            break 'm21099 crate::prelude::Text::from(format!("\n        out.push(self.{}.updates.clone());\n        ::prism_rtl::Level::level_ports(&self.{}.sample(cx), cx, out);", f_p0, f_p0));
        }
        crate::prelude::Text::lit("")
    }
}

/// The step machine of `DeepPorts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DeepPorts: unbounded fn Text, OutTy -> Text
/// ```
pub struct DeepPorts {
    pub f_p0: crate::prelude::Text,
    pub ft_p1: crate::lower::model::OutTy,
}

impl ::prism_rtl::Job<crate::prelude::Text> for DeepPorts {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let f_p0 = &self.f_p0;
        let ft_p1 = &self.ft_p1;
        'm21099: {
            if let crate::lower::model::OutTy::OutMap(_, m21099_0_1) = ft_p1 && let crate::lower::model::OutTy::OutDyn(m21099_0_1_r_0) = &**m21099_0_1 && let crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefItem(m21099_0_1_r_0_r_0_0, m21099_0_1_r_0_r_0_1, _), _) = &**m21099_0_1_r_0 && (m21099_0_1_r_0_r_0_0 == &crate::prelude::Text::lit("")) && (m21099_0_1_r_0_r_0_1 == &crate::prelude::Text::lit("Elem")) {
                break 'm21099 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("\n        ::prism_rtl::dynamics_ports(&self.{}, cx, out);", f_p0)));
            }
            if let crate::lower::model::OutTy::OutDyn(m21099_1_0) = ft_p1 && let crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefItem(m21099_1_0_r_0_0, m21099_1_0_r_0_1, _), _) = &**m21099_1_0 && (m21099_1_0_r_0_0 == &crate::prelude::Text::lit("")) && (m21099_1_0_r_0_1 == &crate::prelude::Text::lit("Elem")) {
                break 'm21099 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("\n        out.push(self.{}.updates.clone());\n        ::prism_rtl::Level::level_ports(&self.{}.sample(cx), cx, out);", f_p0, f_p0)));
            }
            ::prism_rtl::Turn::Finished(crate::prelude::Text::lit(""))
        }
    }
}

/// `Start DeepPorts, x`: what the function value is when passed to `@Run`.
pub fn start_deep_ports_f(f_p0: crate::prelude::Text, ft_p1: crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(DeepPorts { f_p0, ft_p1 })
}

/// ```prism
/// RustRow: unbounded fn RowDef -> Text
/// ```
pub fn rust_row_f(r_p0: &crate::lower::model::RowDef) -> crate::prelude::Text {
    let derives_p1 = if r_p0.eq_p {
        crate::prelude::Text::lit("::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq")
    } else {
        crate::prelude::Text::lit("::std::clone::Clone")
    };
    let cases_p2 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&r_p0.cases_p, &(|(v_pa, st_pb): &(crate::prelude::Text, crate::lower::model::Ref)| crate::prelude::Text::from(format!("{}({}),", v_pa, &crate::emit::rust::rs_ref_f(st_pb))))), &crate::prelude::Text::lit("\n"));
    let pods_p3 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&r_p0.cases_p, &(|(v_pc, _): &(crate::prelude::Text, crate::lower::model::Ref)| crate::prelude::Text::from(format!("{}::{}(x) => x.to_pod(),", &r_p0.name_p, v_pc)))), &crate::prelude::Text::lit("\n"));
    let reads_p4 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&r_p0.cases_p, &(|(v_pd, st_pe): &(crate::prelude::Text, crate::lower::model::Ref)| crate::prelude::Text::from(format!("::std::option::Option::Some(t) if t == {}::TAG => ::std::result::Result::Ok({}::{}(crate::prelude::FromPod::from_pod(p)?)),", &crate::emit::rust::rs_ref_f(st_pe), &r_p0.name_p, v_pd)))), &crate::prelude::Text::lit("\n"));
    let back_p5 = if r_p0.pod_p {
        crate::prelude::Text::from(format!("\n{}", &crate::emit::rust::templates::items::row_from_pod_f(&r_p0.name_p, &reads_p4)))
    } else {
        crate::prelude::Text::lit("")
    };
    let pods2_p6 = if &crate::prelude::len(&r_p0.cases_p) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::lit("_ => unreachable!(),")
    } else {
        pods_p3.clone()
    };
    let deep_pods_p7 = crate::prelude::concat(&crate::prelude::each(&r_p0.deep_p, &(|v_pf: &crate::prelude::Text| crate::prelude::Text::from(format!("{}::{}(x) => x.level_pod(cx),\n            ", &r_p0.name_p, v_pf)))));
    let deep_ports_p8 = crate::prelude::concat(&crate::prelude::each(&r_p0.deep_p, &(|v_pg: &crate::prelude::Text| crate::prelude::Text::from(format!("{}::{}(x) => x.level_ports(cx, out),\n            ", &r_p0.name_p, v_pg)))));
    let level_p9 = if r_p0.level_p {
        crate::prelude::Text::from(format!("\n{}", &crate::emit::rust::templates::items::row_level_f(&r_p0.name_p, &deep_pods_p7, &deep_ports_p8)))
    } else {
        crate::prelude::Text::lit("")
    };
    crate::prelude::Text::from(format!("{}{}{}", &crate::emit::rust::templates::items::row_f(&crate::emit::rust::templates::source_doc_f(&crate::prelude::Text::from(format!("`{}`, a row kind\'s values:", &r_p0.prism_p)), &r_p0.doc_p), &derives_p1, &r_p0.name_p, &cases_p2, &pods2_p6), &back_p5, &level_p9))
}

/// The step machine of `RustRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustRow: unbounded fn RowDef -> Text
/// ```
pub struct RustRow {
    pub r_p0: crate::lower::model::RowDef,
}

impl ::prism_rtl::Job<crate::prelude::Text> for RustRow {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let r_p0 = &self.r_p0;
        let derives_p1 = if r_p0.eq_p {
            crate::prelude::Text::lit("::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq")
        } else {
            crate::prelude::Text::lit("::std::clone::Clone")
        };
        let cases_p2 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&r_p0.cases_p, &(|(v_pa, st_pb): &(crate::prelude::Text, crate::lower::model::Ref)| crate::prelude::Text::from(format!("{}({}),", v_pa, &crate::emit::rust::rs_ref_f(st_pb))))), &crate::prelude::Text::lit("\n"));
        let pods_p3 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&r_p0.cases_p, &(|(v_pc, _): &(crate::prelude::Text, crate::lower::model::Ref)| crate::prelude::Text::from(format!("{}::{}(x) => x.to_pod(),", &r_p0.name_p, v_pc)))), &crate::prelude::Text::lit("\n"));
        let reads_p4 = crate::syntax::lexer::chars::join_f(&crate::prelude::each(&r_p0.cases_p, &(|(v_pd, st_pe): &(crate::prelude::Text, crate::lower::model::Ref)| crate::prelude::Text::from(format!("::std::option::Option::Some(t) if t == {}::TAG => ::std::result::Result::Ok({}::{}(crate::prelude::FromPod::from_pod(p)?)),", &crate::emit::rust::rs_ref_f(st_pe), &r_p0.name_p, v_pd)))), &crate::prelude::Text::lit("\n"));
        let back_p5 = if r_p0.pod_p {
            crate::prelude::Text::from(format!("\n{}", &crate::emit::rust::templates::items::row_from_pod_f(&r_p0.name_p, &reads_p4)))
        } else {
            crate::prelude::Text::lit("")
        };
        let pods2_p6 = if &crate::prelude::len(&r_p0.cases_p) == &crate::prelude::Nat::from(0u32) {
            crate::prelude::Text::lit("_ => unreachable!(),")
        } else {
            pods_p3.clone()
        };
        let deep_pods_p7 = crate::prelude::concat(&crate::prelude::each(&r_p0.deep_p, &(|v_pf: &crate::prelude::Text| crate::prelude::Text::from(format!("{}::{}(x) => x.level_pod(cx),\n            ", &r_p0.name_p, v_pf)))));
        let deep_ports_p8 = crate::prelude::concat(&crate::prelude::each(&r_p0.deep_p, &(|v_pg: &crate::prelude::Text| crate::prelude::Text::from(format!("{}::{}(x) => x.level_ports(cx, out),\n            ", &r_p0.name_p, v_pg)))));
        let level_p9 = if r_p0.level_p {
            crate::prelude::Text::from(format!("\n{}", &crate::emit::rust::templates::items::row_level_f(&r_p0.name_p, &deep_pods_p7, &deep_ports_p8)))
        } else {
            crate::prelude::Text::lit("")
        };
        ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{}{}", &crate::emit::rust::templates::items::row_f(&crate::emit::rust::templates::source_doc_f(&crate::prelude::Text::from(format!("`{}`, a row kind\'s values:", &r_p0.prism_p)), &r_p0.doc_p), &derives_p1, &r_p0.name_p, &cases_p2, &pods2_p6), &back_p5, &level_p9)))
    }
}

/// `Start RustRow, x`: what the function value is when passed to `@Run`.
pub fn start_rust_row_f(r_p0: crate::lower::model::RowDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(RustRow { r_p0 })
}

/// ```prism
/// RustAnswer: unbounded fn AnswerDef -> Text
/// ```
pub fn rust_answer_f(a_p0: &crate::lower::model::AnswerDef) -> crate::prelude::Text {
    let firsts_p1 = crate::prelude::fold(&a_p0.cases_p, &crate::prelude::Array::new(), &(|acc_pa: &crate::prelude::Array<(crate::lower::model::AnswerCase, crate::lower::model::OutTy)>, c_pb: &crate::lower::model::AnswerCase| match &c_pb.first_o {
        ::std::option::Option::Some(ft_pc) => crate::prelude::push(acc_pa, &(c_pb.clone(), ft_pc.clone())),
        ::std::option::Option::None => acc_pa.clone(),
    }));
    let cases_p2 = crate::syntax::lexer::chars::join_f(&crate::prelude::push(&crate::prelude::push(&crate::prelude::append(&crate::prelude::run_to_end(crate::prelude::each_job(a_p0.cases_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::AnswerCase| crate::prelude::entered(crate::prelude::once_job(move || {
        let c_pd = p0;
        crate::prelude::call_then(crate::emit::rust::start_type_f(c_pd.ty_p.clone()), move |type_f_23651: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}({}),", &c_pd.variant_p, &type_f_23651))))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::AnswerCase) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::run_to_end(crate::prelude::each_job(firsts_p1.clone(), ::std::rc::Rc::new(move |p0: (crate::lower::model::AnswerCase, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (c_pe, ft_pf) = p0;
        crate::prelude::call_then(crate::emit::rust::start_type_f(ft_pf.clone()), move |type_f_23713: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}First({}),", &c_pe.variant_p, &type_f_23713))))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::AnswerCase, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>))), &crate::prelude::Text::lit("Untagged_a(crate::prelude::Pod),")), &crate::prelude::Text::lit("Held_a(::std::rc::Rc<dyn ::std::any::Any>),")), &crate::prelude::Text::lit("\n"));
    let tags_p3 = crate::syntax::lexer::chars::join_f(&crate::prelude::push(&crate::prelude::push(&crate::prelude::append(&crate::prelude::each(&a_p0.cases_p, &(|c_pg: &crate::lower::model::AnswerCase| crate::prelude::Text::from(format!("Answer::{}(_) => {}::TAG,", &c_pg.variant_p, &crate::emit::rust::rs_ref_f(&c_pg.struct_path_p))))), &crate::prelude::each(&firsts_p1, &(|(c_ph, ft_pi): &(crate::lower::model::AnswerCase, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("Answer::{}First(_) => {}::TAG,", &c_ph.variant_p, &crate::emit::rust::rs_ref_f(&c_ph.struct_path_p)))))), &crate::prelude::Text::lit("Answer::Untagged_a(_) => \"no tag (an answer made outside a tag\'s arm)\",")), &crate::prelude::Text::lit("Answer::Held_a(_) => \"no tag (an answer made outside a tag\'s arm that is no plain data)\",")), &crate::prelude::Text::lit("\n"));
    let accessors_p4 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::run_to_end(crate::prelude::each_job(a_p0.cases_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::AnswerCase| crate::prelude::entered(crate::prelude::once_job(move || {
        let c_pj = p0;
        crate::prelude::call_then(crate::emit::rust::start_type_f(c_pj.ty_p.clone()), move |type_f_24305: crate::prelude::Text| crate::prelude::call_then(start_outside_arm_f(c_pj.ty_p.clone()), move |outside_arm_f_24318: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::answer_getter_f(&c_pj.accessor_p, &c_pj.variant_p, &c_pj.tag_name_p, &type_f_24305, &outside_arm_f_24318))))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::AnswerCase) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::run_to_end(crate::prelude::each_job(firsts_p1.clone(), ::std::rc::Rc::new(move |p0: (crate::lower::model::AnswerCase, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (c_pk, ft_pl) = p0;
        crate::prelude::call_then(crate::emit::rust::start_type_f(ft_pl.clone()), move |type_f_24431: crate::prelude::Text| crate::prelude::call_then(start_outside_arm_f(ft_pl.clone()), move |outside_arm_f_24442: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::answer_getter_f(&crate::prelude::Text::from(format!("{}_first", &c_pk.accessor_p)), &crate::prelude::Text::from(format!("{}First", &c_pk.variant_p)), &c_pk.tag_name_p, &type_f_24431, &outside_arm_f_24442))))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::AnswerCase, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>))), &crate::prelude::Text::lit("\n"));
    let decodes_p5 = if &crate::prelude::len(&a_p0.cases_p) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::lit("_ => unreachable!(),")
    } else {
        crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(a_p0.cases_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::AnswerCase| crate::prelude::entered(crate::prelude::once_job(move || {
            let c_pm = p0;
            crate::prelude::call_then(crate::lower::types::start_podable_f(c_pm.ty_p.clone()), move |podable_f_24703: bool| if podable_f_24703 {
                crate::prelude::call_then(crate::emit::rust::start_decode_head_f(c_pm.ty_p.clone()), move |decode_head_f_24790: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("Elem::{}(..) => ::std::result::Result::Ok(Answer::{}({}::from_pod(v)?)),", &c_pm.variant_p, &c_pm.variant_p, &decode_head_f_24790))))
            } else {
                ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("Elem::{}(..) => {},", &c_pm.variant_p, &no_world_answer_f(&c_pm.tag_name_p))))
            })
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::AnswerCase) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit("\n"))
    };
    let decode_firsts_p6 = crate::syntax::lexer::chars::join_f(&crate::prelude::push(&crate::prelude::run_to_end(crate::prelude::each_job(firsts_p1.clone(), ::std::rc::Rc::new(move |p0: (crate::lower::model::AnswerCase, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (c_pn, ft_po) = p0;
        crate::prelude::call_then(crate::lower::types::start_podable_f(ft_po.clone()), move |podable_f_24956: bool| if podable_f_24956 {
            crate::prelude::call_then(crate::emit::rust::start_decode_head_f(ft_po.clone()), move |decode_head_f_25046: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("Elem::{}(..) => ::std::result::Result::Ok(Answer::{}First({}::from_pod(v)?)),", &c_pn.variant_p, &c_pn.variant_p, &decode_head_f_25046))))
        } else {
            ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("Elem::{}(..) => {},", &c_pn.variant_p, &no_world_answer_f(&c_pn.tag_name_p))))
        })
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::AnswerCase, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit("_ => Self::decode(e, v),")), &crate::prelude::Text::lit("\n"));
    let held_arms_p7 = crate::prelude::run_to_end(crate::prelude::fold_job(a_p0.cases_p.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::lower::model::AnswerCase)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_pp = p0;
        let c_pq = p1;
        match (c_pq.held_whole_o.clone(), c_pq.held_parts_o.clone()) {
            (::std::option::Option::Some(whole_pr), ::std::option::Option::Some(parts_ps)) => crate::prelude::call_then(crate::emit::rust::start_type_f(whole_pr.clone()), move |type_f_25427: crate::prelude::Text| crate::prelude::call_then(crate::emit::rust::start_expression_f(parts_ps.clone()), move |expression_f_25456: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_pp, &crate::prelude::Text::from(format!("Elem::{}(..) => answer.held_as::<{}>().map(|whole| ({})(&whole)),", &c_pq.variant_p, &type_f_25427, &expression_f_25456)))))),
            _ => ::prism_rtl::Turn::Finished(acc_pp.clone()),
        }
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::lower::model::AnswerCase)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>));
    let helds_p8 = crate::syntax::lexer::chars::join_f(&crate::prelude::push(&held_arms_p7, &crate::prelude::Text::lit("_ => ::std::option::Option::None,")), &crate::prelude::Text::lit("\n"));
    let untagged_p9 = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::fold_job(a_p0.cases_p.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::lower::model::AnswerCase)| crate::prelude::entered(crate::prelude::once_job(move || {
        let acc_pt = p0;
        let c_pu = p1;
        crate::prelude::call_then(crate::lower::types::start_podable_f(c_pu.ty_p.clone()), move |podable_f_25730: bool| if podable_f_25730 {
            ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_pt, &crate::prelude::Text::from(format!("Answer::{}(v) => Answer::Untagged_a(crate::prelude::ToPod::to_pod(v)),", &c_pu.variant_p))))
        } else {
            ::prism_rtl::Turn::Finished(acc_pt.clone())
        })
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::lower::model::AnswerCase)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)), &crate::prelude::Text::lit("\n"));
    crate::emit::rust::templates::items::answer_type_f(&cases_p2, &tags_p3, &accessors_p4, &decodes_p5, &decode_firsts_p6, &helds_p8, &untagged_p9)
}

/// The step machine of `RustAnswer`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustAnswer: unbounded fn AnswerDef -> Text
/// ```
pub struct RustAnswer {
    pub a_p0: crate::lower::model::AnswerDef,
}

impl ::prism_rtl::Job<crate::prelude::Text> for RustAnswer {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let a_p0 = &self.a_p0;
        let firsts_p1 = crate::prelude::fold(&a_p0.cases_p, &crate::prelude::Array::new(), &(|acc_pa: &crate::prelude::Array<(crate::lower::model::AnswerCase, crate::lower::model::OutTy)>, c_pb: &crate::lower::model::AnswerCase| match &c_pb.first_o {
            ::std::option::Option::Some(ft_pc) => crate::prelude::push(acc_pa, &(c_pb.clone(), ft_pc.clone())),
            ::std::option::Option::None => acc_pa.clone(),
        }));
        let a_p0x = a_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(a_p0x.cases_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::AnswerCase| crate::prelude::entered(crate::prelude::once_job(move || {
            let c_pd = p0;
            crate::prelude::call_then(crate::emit::rust::start_type_f(c_pd.ty_p.clone()), move |type_f_23651: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}({}),", &c_pd.variant_p, &type_f_23651))))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::AnswerCase) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_23618: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_value(crate::prelude::each_job(firsts_p1.clone(), ::std::rc::Rc::new(move |p0: (crate::lower::model::AnswerCase, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
            let (c_pe, ft_pf) = p0;
            crate::prelude::call_then(crate::emit::rust::start_type_f(ft_pf.clone()), move |type_f_23713: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}First({}),", &c_pe.variant_p, &type_f_23713))))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::AnswerCase, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_23668: crate::prelude::Array<crate::prelude::Text>| {
            let cases_p2 = crate::syntax::lexer::chars::join_f(&crate::prelude::push(&crate::prelude::push(&crate::prelude::append(&each_23618, &each_23668), &crate::prelude::Text::lit("Untagged_a(crate::prelude::Pod),")), &crate::prelude::Text::lit("Held_a(::std::rc::Rc<dyn ::std::any::Any>),")), &crate::prelude::Text::lit("\n"));
            let tags_p3 = crate::syntax::lexer::chars::join_f(&crate::prelude::push(&crate::prelude::push(&crate::prelude::append(&crate::prelude::each(&a_p0x.cases_p, &(|c_pg: &crate::lower::model::AnswerCase| crate::prelude::Text::from(format!("Answer::{}(_) => {}::TAG,", &c_pg.variant_p, &crate::emit::rust::rs_ref_f(&c_pg.struct_path_p))))), &crate::prelude::each(&firsts_p1, &(|(c_ph, ft_pi): &(crate::lower::model::AnswerCase, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("Answer::{}First(_) => {}::TAG,", &c_ph.variant_p, &crate::emit::rust::rs_ref_f(&c_ph.struct_path_p)))))), &crate::prelude::Text::lit("Answer::Untagged_a(_) => \"no tag (an answer made outside a tag\'s arm)\",")), &crate::prelude::Text::lit("Answer::Held_a(_) => \"no tag (an answer made outside a tag\'s arm that is no plain data)\",")), &crate::prelude::Text::lit("\n"));
            crate::prelude::call_value(crate::prelude::each_job(a_p0x.cases_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::AnswerCase| crate::prelude::entered(crate::prelude::once_job(move || {
                let c_pj = p0;
                crate::prelude::call_then(crate::emit::rust::start_type_f(c_pj.ty_p.clone()), move |type_f_24305: crate::prelude::Text| crate::prelude::call_then(start_outside_arm_f(c_pj.ty_p.clone()), move |outside_arm_f_24318: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::answer_getter_f(&c_pj.accessor_p, &c_pj.variant_p, &c_pj.tag_name_p, &type_f_24305, &outside_arm_f_24318))))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::AnswerCase) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_24238: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_value(crate::prelude::each_job(firsts_p1.clone(), ::std::rc::Rc::new(move |p0: (crate::lower::model::AnswerCase, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
                let (c_pk, ft_pl) = p0;
                crate::prelude::call_then(crate::emit::rust::start_type_f(ft_pl.clone()), move |type_f_24431: crate::prelude::Text| crate::prelude::call_then(start_outside_arm_f(ft_pl.clone()), move |outside_arm_f_24442: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::answer_getter_f(&crate::prelude::Text::from(format!("{}_first", &c_pk.accessor_p)), &crate::prelude::Text::from(format!("{}First", &c_pk.variant_p)), &c_pk.tag_name_p, &type_f_24431, &outside_arm_f_24442))))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::AnswerCase, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_24338: crate::prelude::Array<crate::prelude::Text>| {
                let accessors_p4 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&each_24238, &each_24338), &crate::prelude::Text::lit("\n"));
                let a_p0xz = a_p0x.clone();
                let accessors_p4z = accessors_p4.clone();
                let cases_p2z = cases_p2.clone();
                let firsts_p1z = firsts_p1.clone();
                let tags_p3z = tags_p3.clone();
                let k_let24609 = move |v24609: crate::prelude::Text| {
                    let decodes_p5 = v24609;
                    crate::prelude::call_value(crate::prelude::each_job(firsts_p1z.clone(), ::std::rc::Rc::new(move |p0: (crate::lower::model::AnswerCase, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
                        let (c_pn, ft_po) = p0;
                        crate::prelude::call_then(crate::lower::types::start_podable_f(ft_po.clone()), move |podable_f_24956: bool| if podable_f_24956 {
                            crate::prelude::call_then(crate::emit::rust::start_decode_head_f(ft_po.clone()), move |decode_head_f_25046: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("Elem::{}(..) => ::std::result::Result::Ok(Answer::{}First({}::from_pod(v)?)),", &c_pn.variant_p, &c_pn.variant_p, &decode_head_f_25046))))
                        } else {
                            ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("Elem::{}(..) => {},", &c_pn.variant_p, &no_world_answer_f(&c_pn.tag_name_p))))
                        })
                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::AnswerCase, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_24927: crate::prelude::Array<crate::prelude::Text>| {
                        let decode_firsts_p6 = crate::syntax::lexer::chars::join_f(&crate::prelude::push(&each_24927, &crate::prelude::Text::lit("_ => Self::decode(e, v),")), &crate::prelude::Text::lit("\n"));
                        crate::prelude::call_value(crate::prelude::fold_job(a_p0xz.cases_p.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::lower::model::AnswerCase)| crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_pp = p0;
                            let c_pq = p1;
                            match (c_pq.held_whole_o.clone(), c_pq.held_parts_o.clone()) {
                                (::std::option::Option::Some(whole_pr), ::std::option::Option::Some(parts_ps)) => crate::prelude::call_then(crate::emit::rust::start_type_f(whole_pr.clone()), move |type_f_25427: crate::prelude::Text| crate::prelude::call_then(crate::emit::rust::start_expression_f(parts_ps.clone()), move |expression_f_25456: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_pp, &crate::prelude::Text::from(format!("Elem::{}(..) => answer.held_as::<{}>().map(|whole| ({})(&whole)),", &c_pq.variant_p, &type_f_25427, &expression_f_25456)))))),
                                _ => ::prism_rtl::Turn::Finished(acc_pp.clone()),
                            }
                        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::lower::model::AnswerCase)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>), move |fold_25275: crate::prelude::Array<crate::prelude::Text>| {
                            let held_arms_p7 = fold_25275;
                            let helds_p8 = crate::syntax::lexer::chars::join_f(&crate::prelude::push(&held_arms_p7, &crate::prelude::Text::lit("_ => ::std::option::Option::None,")), &crate::prelude::Text::lit("\n"));
                            crate::prelude::call_value(crate::prelude::fold_job(a_p0xz.cases_p.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::lower::model::AnswerCase)| crate::prelude::entered(crate::prelude::once_job(move || {
                                let acc_pt = p0;
                                let c_pu = p1;
                                crate::prelude::call_then(crate::lower::types::start_podable_f(c_pu.ty_p.clone()), move |podable_f_25730: bool| if podable_f_25730 {
                                    ::prism_rtl::Turn::Finished(crate::prelude::push(&acc_pt, &crate::prelude::Text::from(format!("Answer::{}(v) => Answer::Untagged_a(crate::prelude::ToPod::to_pod(v)),", &c_pu.variant_p))))
                                } else {
                                    ::prism_rtl::Turn::Finished(acc_pt.clone())
                                })
                            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::lower::model::AnswerCase)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>), move |fold_25697: crate::prelude::Array<crate::prelude::Text>| {
                                let untagged_p9 = crate::syntax::lexer::chars::join_f(&fold_25697, &crate::prelude::Text::lit("\n"));
                                ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::answer_type_f(&cases_p2z, &tags_p3z, &accessors_p4z, &decodes_p5, &decode_firsts_p6, &helds_p8, &untagged_p9))
                            })
                        })
                    })
                };
                if &crate::prelude::len(&a_p0x.cases_p) == &crate::prelude::Nat::from(0u32) {
                    k_let24609(crate::prelude::Text::lit("_ => unreachable!(),"))
                } else {
                    crate::prelude::call_value(crate::prelude::each_job(a_p0x.cases_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::AnswerCase| crate::prelude::entered(crate::prelude::once_job(move || {
                        let c_pm = p0;
                        crate::prelude::call_then(crate::lower::types::start_podable_f(c_pm.ty_p.clone()), move |podable_f_24703: bool| if podable_f_24703 {
                            crate::prelude::call_then(crate::emit::rust::start_decode_head_f(c_pm.ty_p.clone()), move |decode_head_f_24790: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("Elem::{}(..) => ::std::result::Result::Ok(Answer::{}({}::from_pod(v)?)),", &c_pm.variant_p, &c_pm.variant_p, &decode_head_f_24790))))
                        } else {
                            ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("Elem::{}(..) => {},", &c_pm.variant_p, &no_world_answer_f(&c_pm.tag_name_p))))
                        })
                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::AnswerCase) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_24681: crate::prelude::Array<crate::prelude::Text>| k_let24609(crate::syntax::lexer::chars::join_f(&each_24681, &crate::prelude::Text::lit("\n"))))
                }
            }))
        }))
    }
}

/// `Start RustAnswer, x`: what the function value is when passed to `@Run`.
pub fn start_rust_answer_f(a_p0: crate::lower::model::AnswerDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(RustAnswer { a_p0 })
}

/// ```prism
/// OutsideArm: unbounded fn OutTy -> Text
/// ```
pub fn outside_arm_f(t_p0: &crate::lower::model::OutTy) -> crate::prelude::Text {
    if crate::lower::types::podable_f(t_p0) {
        crate::prelude::Text::lit("Answer::Untagged_a(p) => crate::prelude::FromPod::from_pod(p),")
    } else {
        crate::prelude::Text::lit("Answer::Held_a(_) => self.held(),")
    }
}

/// The step machine of `OutsideArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OutsideArm: unbounded fn OutTy -> Text
/// ```
pub struct OutsideArm {
    pub t_p0: crate::lower::model::OutTy,
}

impl ::prism_rtl::Job<crate::prelude::Text> for OutsideArm {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let t_p0 = &self.t_p0;
        let t_p0x = t_p0.clone();
        crate::prelude::call_then(crate::lower::types::start_podable_f(t_p0x.clone()), move |podable_f_26250: bool| if podable_f_26250 {
            ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("Answer::Untagged_a(p) => crate::prelude::FromPod::from_pod(p),"))
        } else {
            ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("Answer::Held_a(_) => self.held(),"))
        })
    }
}

/// `Start OutsideArm, x`: what the function value is when passed to `@Run`.
pub fn start_outside_arm_f(t_p0: crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(OutsideArm { t_p0 })
}

/// ```prism
/// NoWorldAnswer: fn Text -> Text
/// ```
pub fn no_world_answer_f(tag_name_p0: &crate::prelude::Text) -> crate::prelude::Text {
    crate::prelude::Text::from(format!("::std::result::Result::Err(crate::prelude::Fault::answer(::std::string::String::from(\"a World\'s answer for {}, whose output is no plain data: a host answers it\")))", tag_name_p0))
}

/// ```prism
/// RustNode: unbounded fn NodeDef -> Text
/// ```
pub fn rust_node_f(n_p0: &crate::lower::model::NodeDef) -> crate::prelude::Text {
    let fields_p1 = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(n_p0.fields_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (f_pg, t_ph, doc_pi) = p0;
        crate::prelude::call_then(crate::emit::rust::start_type_f(t_ph.clone()), move |type_f_27010: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{}: {},", &crate::emit::rust::templates::doc_f(&doc_pi), &f_pg, &type_f_27010))))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit("\n"));
    let consts_p2 = crate::prelude::concat(&crate::prelude::each(&n_p0.consts_p, &(|(c_pj, h_pk, doc_pl): &(crate::prelude::Text, crate::prelude::Nat, crate::prelude::Text)| crate::prelude::Text::from(format!("{}const {}: u32 = {};\n", &crate::emit::rust::templates::doc_f(&crate::prelude::Text::from(format!("The {}.", doc_pl))), c_pj, h_pk)))));
    let params_p3 = crate::prelude::concat(&crate::prelude::run_to_end(crate::prelude::each_job(n_p0.params_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (p_pm, t_pn) = p0;
        crate::prelude::call_then(crate::emit::rust::start_type_f(t_pn.clone()), move |type_f_27188: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}: {}, ", &p_pm, &type_f_27188))))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)));
    let ret_p4 = if n_p0.fallible_p {
        crate::prelude::Text::from(format!("::std::result::Result<::std::rc::Rc<{}>, crate::prelude::Fault>", &n_p0.name_p))
    } else {
        crate::prelude::Text::from(format!("::std::rc::Rc<{}>", &n_p0.name_p))
    };
    let inits_p5 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("path")]), &crate::prelude::run_to_end(crate::prelude::each_job(n_p0.inits_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::Ex)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (f_po, v_pp) = p0;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::rust::FieldInit { f_p0: f_po.clone(), ex1: v_pp.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>))), &crate::prelude::Text::lit(", "));
    let tail_p6 = if n_p0.fallible_p {
        crate::prelude::Text::lit("::std::result::Result::Ok(node)")
    } else {
        crate::prelude::Text::lit("node")
    };
    let rest_text_p7 = if &crate::prelude::len(&n_p0.build_p) == &crate::prelude::Nat::from(0u32) {
        tail_p6.clone()
    } else {
        crate::prelude::Text::from(format!("{}\n{}", &crate::emit::rust::statements_f(&n_p0.build_p), &tail_p6))
    };
    let build_p8 = crate::emit::rust::templates::items::build_f(&n_p0.name_p, &params_p3, &ret_p4, &crate::emit::rust::statements_f(&n_p0.lets_p), &inits_p5, &rest_text_p7);
    let methods_p9 = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(n_p0.methods_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::MethDef| crate::prelude::entered(crate::prelude::once_job(move || {
        let m_pq = p0;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(RustMethod { m_p0: m_pq.clone(), visibility_p1: crate::prelude::Text::lit("pub(crate) ") }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::MethDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit("\n"));
    let seating_pa = if crate::prelude::fold(&n_p0.methods_p, &false, &(|f_pr: &bool, m_ps: &crate::lower::model::MethDef| *f_pr || (&m_ps.name_p == &crate::prelude::Text::lit("seat")))) {
        crate::prelude::Text::lit("let seated = crate::prelude::seated(at, |a| self.seat(a));\nlet at = crate::prelude::segments_of(&seated);")
    } else {
        crate::prelude::Text::lit("")
    };
    let answer_pb = if &crate::prelude::len(&n_p0.answers_p) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::lit("")
    } else {
        crate::emit::rust::templates::items::answer_f(&seating_pa, &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(n_p0.answers_p.clone(), ::std::rc::Rc::new(move |p0: (crate::lower::model::Pa, crate::lower::model::Ex)| crate::prelude::entered(crate::prelude::once_job(move || {
            let (pat_pt, call_pu) = p0;
            crate::prelude::call_then(crate::emit::rust::start_pattern_f(pat_pt.clone()), move |pattern_f_28138: crate::prelude::Text| crate::prelude::call_then(crate::emit::rust::start_expression_f(call_pu.clone()), move |expression_f_28155: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} => {},", &pattern_f_28138, &expression_f_28155)))))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Pa, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit("\n")))
    };
    let builders_pc = crate::prelude::concat(&crate::prelude::append(&crate::prelude::run_to_end(crate::prelude::each_job(n_p0.builders_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::ForDef| crate::prelude::entered(crate::prelude::once_job(move || {
        let b_pv = p0;
        crate::prelude::call_then(start_for_builder_f(b_pv.clone()), move |for_builder_f_28243: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("\n{}", &for_builder_f_28243))))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::ForDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::run_to_end(crate::prelude::each_job(n_p0.gens_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::GenDef| crate::prelude::entered(crate::prelude::once_job(move || {
        let gd_p10 = p0;
        crate::prelude::call_then(start_gen_builder_f(gd_p10.clone()), move |gen_builder_f_28284: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("\n{}", &gen_builder_f_28284))))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::GenDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>))));
    let row_impl_pd = if &n_p0.row_kind_p == &crate::lower::model::RowKind::NotARow {
        crate::prelude::Text::lit("")
    } else {
        crate::prelude::Text::from(format!("\n{}", &rust_row_impl_f(n_p0)))
    };
    let hooks_pe = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(n_p0.hooks_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::prelude::Array<crate::lower::model::Do>)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (h_p11, body_p12) = p0;
        if &h_p11 == &crate::prelude::Text::lit("push") {
            crate::prelude::call_then(crate::emit::rust::start_statements_f(body_p12.clone()), move |statements_f_28451: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::push_hook_f(&statements_f_28451)))
        } else {
            crate::prelude::call_then(crate::emit::rust::start_statements_f(body_p12.clone()), move |statements_f_28483: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::hook_f(&h_p11, &statements_f_28483)))
        }
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::prelude::Array<crate::lower::model::Do>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit("\n"));
    let doc_pf = crate::emit::rust::templates::source_doc_f(&crate::prelude::Text::from(format!("`{}`: a node of its own (claude/backend.md, \"A widget block\").", &n_p0.prism_p)), &n_p0.doc_p);
    crate::prelude::Text::from(format!("{}{}", &crate::emit::rust::templates::items::node_f(&doc_pf, &n_p0.name_p, &fields_p1, &consts_p2, &build_p8, &crate::prelude::Text::from(format!("{}{}", &methods_p9, &builders_pc)), &hooks_pe, &answer_pb), &row_impl_pd))
}

/// The step machine of `RustNode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustNode: unbounded fn NodeDef -> Text
/// ```
pub struct RustNode {
    pub n_p0: crate::lower::model::NodeDef,
}

impl ::prism_rtl::Job<crate::prelude::Text> for RustNode {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let n_p0 = &self.n_p0;
        let n_p0x = n_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(n_p0x.fields_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)| crate::prelude::entered(crate::prelude::once_job(move || {
            let (f_pg, t_ph, doc_pi) = p0;
            crate::prelude::call_then(crate::emit::rust::start_type_f(t_ph.clone()), move |type_f_27010: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{}: {},", &crate::emit::rust::templates::doc_f(&doc_pi), &f_pg, &type_f_27010))))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_26962: crate::prelude::Array<crate::prelude::Text>| {
            let fields_p1 = crate::syntax::lexer::chars::join_f(&each_26962, &crate::prelude::Text::lit("\n"));
            let consts_p2 = crate::prelude::concat(&crate::prelude::each(&n_p0x.consts_p, &(|(c_pj, h_pk, doc_pl): &(crate::prelude::Text, crate::prelude::Nat, crate::prelude::Text)| crate::prelude::Text::from(format!("{}const {}: u32 = {};\n", &crate::emit::rust::templates::doc_f(&crate::prelude::Text::from(format!("The {}.", doc_pl))), c_pj, h_pk)))));
            crate::prelude::call_value(crate::prelude::each_job(n_p0x.params_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
                let (p_pm, t_pn) = p0;
                crate::prelude::call_then(crate::emit::rust::start_type_f(t_pn.clone()), move |type_f_27188: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}: {}, ", &p_pm, &type_f_27188))))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_27154: crate::prelude::Array<crate::prelude::Text>| {
                let params_p3 = crate::prelude::concat(&each_27154);
                let ret_p4 = if n_p0x.fallible_p {
                    crate::prelude::Text::from(format!("::std::result::Result<::std::rc::Rc<{}>, crate::prelude::Fault>", &n_p0x.name_p))
                } else {
                    crate::prelude::Text::from(format!("::std::rc::Rc<{}>", &n_p0x.name_p))
                };
                crate::prelude::call_value(crate::prelude::each_job(n_p0x.inits_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::Ex)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let (f_po, v_pp) = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::rust::FieldInit { f_p0: f_po.clone(), ex1: v_pp.clone() }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_27375: crate::prelude::Array<crate::prelude::Text>| {
                    let inits_p5 = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::prelude::Text::lit("path")]), &each_27375), &crate::prelude::Text::lit(", "));
                    let tail_p6 = if n_p0x.fallible_p {
                        crate::prelude::Text::lit("::std::result::Result::Ok(node)")
                    } else {
                        crate::prelude::Text::lit("node")
                    };
                    let consts_p2z = consts_p2.clone();
                    let fields_p1z = fields_p1.clone();
                    let inits_p5z = inits_p5.clone();
                    let n_p0xz = n_p0x.clone();
                    let params_p3z = params_p3.clone();
                    let ret_p4z = ret_p4.clone();
                    let k_let27505 = move |v27505: crate::prelude::Text| {
                        let rest_text_p7 = v27505;
                        crate::prelude::call_then(crate::emit::rust::start_statements_f(n_p0xz.lets_p.clone()), move |statements_f_27629: crate::prelude::Text| {
                            let build_p8 = crate::emit::rust::templates::items::build_f(&n_p0xz.name_p, &params_p3z, &ret_p4z, &statements_f_27629, &inits_p5z, &rest_text_p7);
                            crate::prelude::call_value(crate::prelude::each_job(n_p0xz.methods_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::MethDef| crate::prelude::entered(crate::prelude::once_job(move || {
                                let m_pq = p0;
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(RustMethod { m_p0: m_pq.clone(), visibility_p1: crate::prelude::Text::lit("pub(crate) ") }))
                            }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::MethDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_27689: crate::prelude::Array<crate::prelude::Text>| {
                                let methods_p9 = crate::syntax::lexer::chars::join_f(&each_27689, &crate::prelude::Text::lit("\n"));
                                let seating_pa = if crate::prelude::fold(&n_p0xz.methods_p, &false, &(|f_pr: &bool, m_ps: &crate::lower::model::MethDef| *f_pr || (&m_ps.name_p == &crate::prelude::Text::lit("seat")))) {
                                    crate::prelude::Text::lit("let seated = crate::prelude::seated(at, |a| self.seat(a));\nlet at = crate::prelude::segments_of(&seated);")
                                } else {
                                    crate::prelude::Text::lit("")
                                };
                                let build_p8z = build_p8.clone();
                                let consts_p2zz = consts_p2z.clone();
                                let fields_p1zz = fields_p1z.clone();
                                let methods_p9z = methods_p9.clone();
                                let n_p0xzz = n_p0xz.clone();
                                let k_let28033 = move |v28033: crate::prelude::Text| {
                                    let answer_pb = v28033;
                                    crate::prelude::call_value(crate::prelude::each_job(n_p0xzz.builders_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::ForDef| crate::prelude::entered(crate::prelude::once_job(move || {
                                        let b_pv = p0;
                                        crate::prelude::call_then(start_for_builder_f(b_pv.clone()), move |for_builder_f_28243: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("\n{}", &for_builder_f_28243))))
                                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::ForDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_28217: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_value(crate::prelude::each_job(n_p0xzz.gens_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::GenDef| crate::prelude::entered(crate::prelude::once_job(move || {
                                        let gd_p10 = p0;
                                        crate::prelude::call_then(start_gen_builder_f(gd_p10.clone()), move |gen_builder_f_28284: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("\n{}", &gen_builder_f_28284))))
                                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::GenDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_28261: crate::prelude::Array<crate::prelude::Text>| {
                                        let builders_pc = crate::prelude::concat(&crate::prelude::append(&each_28217, &each_28261));
                                        let answer_pbz = answer_pb.clone();
                                        let build_p8zz = build_p8z.clone();
                                        let builders_pcz = builders_pc.clone();
                                        let consts_p2zzz = consts_p2zz.clone();
                                        let fields_p1zzz = fields_p1zz.clone();
                                        let methods_p9zz = methods_p9z.clone();
                                        let n_p0xzzz = n_p0xzz.clone();
                                        let k_let28306 = move |v28306: crate::prelude::Text| {
                                            let row_impl_pd = v28306;
                                            crate::prelude::call_value(crate::prelude::each_job(n_p0xzzz.hooks_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::prelude::Array<crate::lower::model::Do>)| crate::prelude::entered(crate::prelude::once_job(move || {
                                                let (h_p11, body_p12) = p0;
                                                if &h_p11 == &crate::prelude::Text::lit("push") {
                                                    crate::prelude::call_then(crate::emit::rust::start_statements_f(body_p12.clone()), move |statements_f_28451: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::push_hook_f(&statements_f_28451)))
                                                } else {
                                                    crate::prelude::call_then(crate::emit::rust::start_statements_f(body_p12.clone()), move |statements_f_28483: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::hook_f(&h_p11, &statements_f_28483)))
                                                }
                                            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::prelude::Array<crate::lower::model::Do>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_28396: crate::prelude::Array<crate::prelude::Text>| {
                                                let hooks_pe = crate::syntax::lexer::chars::join_f(&each_28396, &crate::prelude::Text::lit("\n"));
                                                let doc_pf = crate::emit::rust::templates::source_doc_f(&crate::prelude::Text::from(format!("`{}`: a node of its own (claude/backend.md, \"A widget block\").", &n_p0xzzz.prism_p)), &n_p0xzzz.doc_p);
                                                ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{}", &crate::emit::rust::templates::items::node_f(&doc_pf, &n_p0xzzz.name_p, &fields_p1zzz, &consts_p2zzz, &build_p8zz, &crate::prelude::Text::from(format!("{}{}", &methods_p9zz, &builders_pcz)), &hooks_pe, &answer_pbz), &row_impl_pd)))
                                            })
                                        };
                                        if &n_p0xzz.row_kind_p == &crate::lower::model::RowKind::NotARow {
                                            k_let28306(crate::prelude::Text::lit(""))
                                        } else {
                                            crate::prelude::call_then(start_rust_row_impl_f(n_p0xzz.clone()), move |rust_row_impl_f_28358: crate::prelude::Text| k_let28306(crate::prelude::Text::from(format!("\n{}", &rust_row_impl_f_28358))))
                                        }
                                    }))
                                };
                                if &crate::prelude::len(&n_p0xz.answers_p) == &crate::prelude::Nat::from(0u32) {
                                    k_let28033(crate::prelude::Text::lit(""))
                                } else {
                                    crate::prelude::call_value(crate::prelude::each_job(n_p0xz.answers_p.clone(), ::std::rc::Rc::new(move |p0: (crate::lower::model::Pa, crate::lower::model::Ex)| crate::prelude::entered(crate::prelude::once_job(move || {
                                        let (pat_pt, call_pu) = p0;
                                        crate::prelude::call_then(crate::emit::rust::start_pattern_f(pat_pt.clone()), move |pattern_f_28138: crate::prelude::Text| crate::prelude::call_then(crate::emit::rust::start_expression_f(call_pu.clone()), move |expression_f_28155: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} => {},", &pattern_f_28138, &expression_f_28155)))))
                                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Pa, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_28103: crate::prelude::Array<crate::prelude::Text>| k_let28033(crate::emit::rust::templates::items::answer_f(&seating_pa, &crate::syntax::lexer::chars::join_f(&each_28103, &crate::prelude::Text::lit("\n")))))
                                }
                            })
                        })
                    };
                    if &crate::prelude::len(&n_p0x.build_p) == &crate::prelude::Nat::from(0u32) {
                        k_let27505(tail_p6.clone())
                    } else {
                        crate::prelude::call_then(crate::emit::rust::start_statements_f(n_p0x.build_p.clone()), move |statements_f_27556: crate::prelude::Text| k_let27505(crate::prelude::Text::from(format!("{}\n{}", &statements_f_27556, &tail_p6))))
                    }
                })
            })
        })
    }
}

/// `Start RustNode, x`: what the function value is when passed to `@Run`.
pub fn start_rust_node_f(n_p0: crate::lower::model::NodeDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(RustNode { n_p0 })
}

/// ```prism
/// ForBuilder: unbounded fn ForDef -> Text
/// ```
pub fn for_builder_f(b_p0: &crate::lower::model::ForDef) -> crate::prelude::Text {
    crate::emit::rust::templates::items::for_build_f(&b_p0.name_p, &crate::emit::rust::expression_f(&b_p0.at_p), &crate::emit::rust::type_f(&b_p0.key_ty_p), &crate::emit::rust::type_f(&b_p0.value_ty_p), &crate::emit::rust::rs_path_f(&b_p0.row_node_p), &b_p0.source_p, &crate::emit::rust::expression_f(&b_p0.parent_p), &crate::prelude::concat(&crate::prelude::run_to_end(crate::prelude::each_job(b_p0.passed_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Ex| crate::prelude::entered(crate::prelude::once_job(move || {
        let x_p1 = p0;
        crate::prelude::call_then(crate::emit::rust::start_expression_f(x_p1.clone()), move |expression_f_28985: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!(", {}", &expression_f_28985))))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>))), &moved_call_f(&b_p0.name_p, &b_p0.moved_p), &from_kept_f(&b_p0.name_p, &b_p0.replaced_p), &replaced_call_f(&b_p0.replaced_p))
}

/// The step machine of `ForBuilder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ForBuilder: unbounded fn ForDef -> Text
/// ```
pub struct ForBuilder {
    pub b_p0: crate::lower::model::ForDef,
}

impl ::prism_rtl::Job<crate::prelude::Text> for ForBuilder {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let b_p0 = &self.b_p0;
        let b_p0x = b_p0.clone();
        crate::prelude::call_then(crate::emit::rust::start_expression_f(b_p0x.at_p.clone()), move |expression_f_28847: crate::prelude::Text| crate::prelude::call_then(crate::emit::rust::start_type_f(b_p0x.key_ty_p.clone()), move |type_f_28866: crate::prelude::Text| crate::prelude::call_then(crate::emit::rust::start_type_f(b_p0x.value_ty_p.clone()), move |type_f_28882: crate::prelude::Text| crate::prelude::call_then(crate::emit::rust::start_expression_f(b_p0x.parent_p.clone()), move |expression_f_28930: crate::prelude::Text| crate::prelude::call_value(crate::prelude::each_job(b_p0x.passed_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Ex| crate::prelude::entered(crate::prelude::once_job(move || {
            let x_p1 = p0;
            crate::prelude::call_then(crate::emit::rust::start_expression_f(x_p1.clone()), move |expression_f_28985: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!(", {}", &expression_f_28985))))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_28961: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::for_build_f(&b_p0x.name_p, &expression_f_28847, &type_f_28866, &type_f_28882, &crate::emit::rust::rs_path_f(&b_p0x.row_node_p), &b_p0x.source_p, &expression_f_28930, &crate::prelude::concat(&each_28961), &moved_call_f(&b_p0x.name_p, &b_p0x.moved_p), &from_kept_f(&b_p0x.name_p, &b_p0x.replaced_p), &replaced_call_f(&b_p0x.replaced_p))))))))
    }
}

/// `Start ForBuilder, x`: what the function value is when passed to `@Run`.
pub fn start_for_builder_f(b_p0: crate::lower::model::ForDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(ForBuilder { b_p0 })
}

/// ```prism
/// FromKept: fn Text, [Text] -> Text
/// ```
pub fn from_kept_f(name_p0: &crate::prelude::Text, replaced_p1: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Text {
    if &crate::prelude::len(replaced_p1) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::from(format!("*self.{}_from.borrow_mut() = items.clone();", name_p0))
    } else {
        crate::prelude::Text::from(format!("let from = ::std::mem::replace(&mut *self.{}_from.borrow_mut(), items.clone());", name_p0))
    }
}

/// ```prism
/// ReplacedCall: fn [Text] -> Text
/// ```
pub fn replaced_call_f(replaced_p0: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Text {
    if &crate::prelude::len(replaced_p0) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::lit("")
    } else {
        crate::prelude::Text::from(format!(" else if from.get(k) != items.get(k) {{\n            // the dynamic under a kept key was replaced: that row follows it from the next tick\n{}        }}", &crate::prelude::concat(&crate::prelude::each(replaced_p0, &(|m_p1: &crate::prelude::Text| crate::prelude::Text::from(format!("            row.{}(cx);\n", m_p1)))))))
    }
}

/// ```prism
/// MovedCall: fn Text, Text -> Text
/// ```
pub fn moved_call_f(name_p0: &crate::prelude::Text, m_p1: &crate::prelude::Text) -> crate::prelude::Text {
    if m_p1 == &crate::prelude::Text::lit("") {
        crate::prelude::Text::lit("")
    } else {
        crate::prelude::Text::from(format!("\n    // the places of the host\'s child came or went: its document\'s outer moves\n    if !::prism_rtl::same_keys(&self.{}.borrow(), &old) {{\n        self.{}(cx);\n    }}", name_p0, m_p1))
    }
}

/// ```prism
/// GenMovedCall: fn Text -> Text
/// ```
pub fn gen_moved_call_f(m_p0: &crate::prelude::Text) -> crate::prelude::Text {
    if m_p0 == &crate::prelude::Text::lit("") {
        crate::prelude::Text::lit("")
    } else {
        crate::prelude::Text::from(format!("\n    // the places of the host\'s child came or went: its document\'s outer moves\n    self.{}(cx);", m_p0))
    }
}

/// ```prism
/// GenBuilder: unbounded fn GenDef -> Text
/// ```
pub fn gen_builder_f(gd_p0: &crate::lower::model::GenDef) -> crate::prelude::Text {
    let path_p1 = if gd_p0.transparent_p {
        crate::prelude::Text::lit("self.path.clone()")
    } else {
        crate::prelude::Text::from(format!("{}.child(crate::prelude::Segment::Gen(g))", &crate::emit::rust::expression_f(&gd_p0.at_p)))
    };
    crate::emit::rust::templates::items::gen_build_f(&gd_p0.name_p, &crate::emit::rust::expression_f(&gd_p0.at_p), &path_p1, &crate::emit::rust::expression_f(&gd_p0.source_p), &crate::emit::rust::type_f(&gd_p0.value_ty_p), &crate::emit::rust::expression_f(&gd_p0.select_p), &gen_moved_call_f(&gd_p0.moved_p))
}

/// The step machine of `GenBuilder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GenBuilder: unbounded fn GenDef -> Text
/// ```
pub struct GenBuilder {
    pub gd_p0: crate::lower::model::GenDef,
}

impl ::prism_rtl::Job<crate::prelude::Text> for GenBuilder {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let gd_p0 = &self.gd_p0;
        let gd_p0z = gd_p0.clone();
        let k_let30853 = move |v30853: crate::prelude::Text| {
            let path_p1 = v30853;
            crate::prelude::call_then(crate::emit::rust::start_expression_f(gd_p0z.at_p.clone()), move |expression_f_30992: crate::prelude::Text| crate::prelude::call_then(crate::emit::rust::start_expression_f(gd_p0z.source_p.clone()), move |expression_f_31018: crate::prelude::Text| crate::prelude::call_then(crate::emit::rust::start_type_f(gd_p0z.value_ty_p.clone()), move |type_f_31042: crate::prelude::Text| crate::prelude::call_then(crate::emit::rust::start_expression_f(gd_p0z.select_p.clone()), move |expression_f_31061: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::gen_build_f(&gd_p0z.name_p, &expression_f_30992, &path_p1, &expression_f_31018, &type_f_31042, &expression_f_31061, &gen_moved_call_f(&gd_p0z.moved_p)))))))
        };
        if gd_p0.transparent_p {
            k_let30853(crate::prelude::Text::lit("self.path.clone()"))
        } else {
            {
                let gd_p0x = gd_p0.clone();
                crate::prelude::call_then(crate::emit::rust::start_expression_f(gd_p0x.at_p.clone()), move |expression_f_30911: crate::prelude::Text| k_let30853(crate::prelude::Text::from(format!("{}.child(crate::prelude::Segment::Gen(g))", &expression_f_30911))))
            }
        }
    }
}

/// `Start GenBuilder, x`: what the function value is when passed to `@Run`.
pub fn start_gen_builder_f(gd_p0: crate::lower::model::GenDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(GenBuilder { gd_p0 })
}

/// ```prism
/// RustRowImpl: unbounded fn NodeDef -> Text
/// ```
pub fn rust_row_impl_f(n_p0: &crate::lower::model::NodeDef) -> crate::prelude::Text {
    let kept_p1 = if &n_p0.row_kind_p == &crate::lower::model::RowKind::ForRow {
        crate::prelude::Array::from(vec![crate::prelude::Text::lit("*self.left_entry.borrow_mut() = ::std::option::Option::Some(self.entry(cx));")])
    } else {
        crate::prelude::Array::new()
    };
    let unsubscribe_p2 = crate::prelude::each(&n_p0.subs_p, &(|(ev_p3, m_p4, _): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("if let (::std::option::Option::Some(p), ::std::option::Option::Some(h)) = (self.parent.upgrade(), self.{}_sub.take()) {{\n    p.{}_port.unsubscribe(h);\n}}", m_p4, ev_p3))));
    crate::emit::rust::templates::items::row_impl_f(&n_p0.name_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::push(&kept_p1, &crate::prelude::Text::lit("self.remove_places(cx);")), &unsubscribe_p2), &crate::prelude::Text::lit("\n")), &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(n_p0.hosted_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::MethDef| crate::prelude::entered(crate::prelude::once_job(move || {
        let m_p5 = p0;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(RustMethod { m_p0: m_p5.clone(), visibility_p1: crate::prelude::Text::lit("") }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::MethDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit("\n")))
}

/// The step machine of `RustRowImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustRowImpl: unbounded fn NodeDef -> Text
/// ```
pub struct RustRowImpl {
    pub n_p0: crate::lower::model::NodeDef,
}

impl ::prism_rtl::Job<crate::prelude::Text> for RustRowImpl {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let n_p0 = &self.n_p0;
        let kept_p1 = if &n_p0.row_kind_p == &crate::lower::model::RowKind::ForRow {
            crate::prelude::Array::from(vec![crate::prelude::Text::lit("*self.left_entry.borrow_mut() = ::std::option::Option::Some(self.entry(cx));")])
        } else {
            crate::prelude::Array::new()
        };
        let unsubscribe_p2 = crate::prelude::each(&n_p0.subs_p, &(|(ev_p3, m_p4, _): &(crate::prelude::Text, crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::Text::from(format!("if let (::std::option::Option::Some(p), ::std::option::Option::Some(h)) = (self.parent.upgrade(), self.{}_sub.take()) {{\n    p.{}_port.unsubscribe(h);\n}}", m_p4, ev_p3))));
        let n_p0x = n_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(n_p0x.hosted_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::MethDef| crate::prelude::entered(crate::prelude::once_job(move || {
            let m_p5 = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(RustMethod { m_p0: m_p5.clone(), visibility_p1: crate::prelude::Text::lit("") }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::MethDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_31853: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::row_impl_f(&n_p0x.name_p, &crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::push(&kept_p1, &crate::prelude::Text::lit("self.remove_places(cx);")), &unsubscribe_p2), &crate::prelude::Text::lit("\n")), &crate::syntax::lexer::chars::join_f(&each_31853, &crate::prelude::Text::lit("\n")))))
    }
}

/// `Start RustRowImpl, x`: what the function value is when passed to `@Run`.
pub fn start_rust_row_impl_f(n_p0: crate::lower::model::NodeDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(RustRowImpl { n_p0 })
}

/// ```prism
/// RustMethod: unbounded fn MethDef, Text -> Text
/// ```
pub fn rust_method_f(m_p0: &crate::lower::model::MethDef, visibility_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let recv_p2 = match &m_p0.recv_p {
        crate::lower::model::Recv::RecvRc => crate::prelude::Text::lit("self: &::std::rc::Rc<Self>"),
        crate::lower::model::Recv::RecvRef => crate::prelude::Text::lit("&self"),
        crate::lower::model::Recv::RecvOwned => crate::prelude::Text::lit("self: ::std::rc::Rc<Self>"),
    };
    let cx_p3 = match &m_p0.cx_p {
        crate::lower::model::CxArg::CxMut => crate::prelude::Text::lit(", cx: &mut crate::prelude::Cx"),
        crate::lower::model::CxArg::CxRef => crate::prelude::Text::lit(", cx: &crate::prelude::Cx"),
        crate::lower::model::CxArg::CxNone => crate::prelude::Text::lit(""),
    };
    let params_p4 = crate::prelude::concat(&crate::prelude::run_to_end(crate::prelude::each_job(m_p0.params_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (p_p8, t_p9) = p0;
        crate::prelude::call_then(crate::emit::rust::start_type_f(t_p9.clone()), move |type_f_32580: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!(", {}: {}", &p_p8, &type_f_32580))))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)));
    let ret_p5 = if &m_p0.ret_p == &crate::lower::model::OutTy::OutUnit {
        crate::prelude::Text::lit("")
    } else {
        crate::prelude::Text::from(format!(" -> {}", &crate::emit::rust::type_f(&m_p0.ret_p)))
    };
    let sig_p6 = crate::prelude::Text::from(format!("{}fn {}({}{}{}){}", visibility_p1, &m_p0.name_p, &recv_p2, &params_p4, &cx_p3, &ret_p5));
    let body_p7 = if &m_p0.ret_p == &crate::lower::model::OutTy::OutUnit {
        crate::emit::rust::statements_f(&m_p0.body_p)
    } else {
        if &crate::prelude::len(&m_p0.body_p) == &crate::prelude::Nat::from(0u32) {
            crate::emit::rust::body_lines_f(&m_p0.tail_p)
        } else {
            crate::prelude::Text::from(format!("{}\n{}", &crate::emit::rust::statements_f(&m_p0.body_p), &crate::emit::rust::body_lines_f(&m_p0.tail_p)))
        }
    };
    crate::emit::rust::templates::items::method_f(&crate::emit::rust::templates::doc_f(&m_p0.doc_p), &sig_p6, &body_p7)
}

/// The step machine of `RustMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustMethod: unbounded fn MethDef, Text -> Text
/// ```
pub struct RustMethod {
    pub m_p0: crate::lower::model::MethDef,
    pub visibility_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Text> for RustMethod {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let m_p0 = &self.m_p0;
        let visibility_p1 = &self.visibility_p1;
        let recv_p2 = match &m_p0.recv_p {
            crate::lower::model::Recv::RecvRc => crate::prelude::Text::lit("self: &::std::rc::Rc<Self>"),
            crate::lower::model::Recv::RecvRef => crate::prelude::Text::lit("&self"),
            crate::lower::model::Recv::RecvOwned => crate::prelude::Text::lit("self: ::std::rc::Rc<Self>"),
        };
        let cx_p3 = match &m_p0.cx_p {
            crate::lower::model::CxArg::CxMut => crate::prelude::Text::lit(", cx: &mut crate::prelude::Cx"),
            crate::lower::model::CxArg::CxRef => crate::prelude::Text::lit(", cx: &crate::prelude::Cx"),
            crate::lower::model::CxArg::CxNone => crate::prelude::Text::lit(""),
        };
        let m_p0x = m_p0.clone();
        let visibility_p1x = visibility_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(m_p0x.params_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
            let (p_p8, t_p9) = p0;
            crate::prelude::call_then(crate::emit::rust::start_type_f(t_p9.clone()), move |type_f_32580: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!(", {}: {}", &p_p8, &type_f_32580))))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_32544: crate::prelude::Array<crate::prelude::Text>| {
            let params_p4 = crate::prelude::concat(&each_32544);
            let cx_p3z = cx_p3.clone();
            let m_p0xz = m_p0x.clone();
            let params_p4z = params_p4.clone();
            let recv_p2z = recv_p2.clone();
            let visibility_p1xz = visibility_p1x.clone();
            let k_let32594 = move |v32594: crate::prelude::Text| {
                let ret_p5 = v32594;
                let sig_p6 = crate::prelude::Text::from(format!("{}fn {}({}{}{}){}", &visibility_p1xz, &m_p0xz.name_p, &recv_p2z, &params_p4z, &cx_p3z, &ret_p5));
                let m_p0xzz = m_p0xz.clone();
                let sig_p6z = sig_p6.clone();
                let k_let32722 = move |v32722: crate::prelude::Text| {
                    let body_p7 = v32722;
                    ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::method_f(&crate::emit::rust::templates::doc_f(&m_p0xzz.doc_p), &sig_p6z, &body_p7))
                };
                if &m_p0xz.ret_p == &crate::lower::model::OutTy::OutUnit {
                    crate::prelude::call_then(crate::emit::rust::start_statements_f(m_p0xz.body_p.clone()), move |statements_f_32754: crate::prelude::Text| k_let32722(statements_f_32754))
                } else {
                    if &crate::prelude::len(&m_p0xz.body_p) == &crate::prelude::Nat::from(0u32) {
                        crate::prelude::call_then(crate::emit::rust::start_body_lines_f(m_p0xz.tail_p.clone()), move |body_lines_f_32800: crate::prelude::Text| k_let32722(body_lines_f_32800))
                    } else {
                        crate::prelude::call_then(crate::emit::rust::start_statements_f(m_p0xz.body_p.clone()), move |statements_f_32825: crate::prelude::Text| crate::prelude::call_then(crate::emit::rust::start_body_lines_f(m_p0xz.tail_p.clone()), move |body_lines_f_32846: crate::prelude::Text| k_let32722(crate::prelude::Text::from(format!("{}\n{}", &statements_f_32825, &body_lines_f_32846)))))
                    }
                }
            };
            if &m_p0x.ret_p == &crate::lower::model::OutTy::OutUnit {
                k_let32594(crate::prelude::Text::lit(""))
            } else {
                crate::prelude::call_then(crate::emit::rust::start_type_f(m_p0x.ret_p.clone()), move |type_f_32640: crate::prelude::Text| k_let32594(crate::prelude::Text::from(format!(" -> {}", &type_f_32640))))
            }
        })
    }
}

/// `Start RustMethod, x`: what the function value is when passed to `@Run`.
pub fn start_rust_method_f(m_p0: crate::lower::model::MethDef, visibility_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(RustMethod { m_p0, visibility_p1 })
}

/// ```prism
/// RustProgram: unbounded fn ProgDef, Bool -> Text
/// ```
pub fn rust_program_f(p_p0: &crate::lower::model::ProgDef, fallible_p1: &bool) -> crate::prelude::Text {
    let n_p2 = crate::prelude::len(&p_p0.params_p);
    let names_p3 = crate::prelude::each(&p_p0.params_p, &(|(a_p6, _): &(crate::prelude::Text, crate::lower::model::OutTy)| a_p6.clone()));
    let decode_p4 = if &n_p2 == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::lit("let _ = args;")
    } else {
        decode_args_f(p_p0, &names_p3)
    };
    let call_p5 = crate::prelude::Text::from(format!("{}::build(crate::prelude::Path::root(), {}&mut cx){}", &p_p0.node_p, &crate::prelude::concat(&crate::prelude::each(&names_p3, &(|a_p7: &crate::prelude::Text| crate::prelude::Text::from(format!("{}, ", a_p7))))), &(if *fallible_p1 {
        crate::prelude::Text::lit("?")
    } else {
        crate::prelude::Text::lit("")
    })));
    crate::emit::rust::templates::items::program_f(&p_p0.name_p, &p_p0.prism_p, &p_p0.node_p, &decode_p4, &call_p5)
}

/// The step machine of `RustProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustProgram: unbounded fn ProgDef, Bool -> Text
/// ```
pub struct RustProgram {
    pub p_p0: crate::lower::model::ProgDef,
    pub fallible_p1: bool,
}

impl ::prism_rtl::Job<crate::prelude::Text> for RustProgram {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let p_p0 = &self.p_p0;
        let fallible_p1 = &self.fallible_p1;
        let n_p2 = crate::prelude::len(&p_p0.params_p);
        let names_p3 = crate::prelude::each(&p_p0.params_p, &(|(a_p6, _): &(crate::prelude::Text, crate::lower::model::OutTy)| a_p6.clone()));
        let fallible_p1z = *fallible_p1;
        let names_p3z = names_p3.clone();
        let p_p0z = p_p0.clone();
        let k_let33055 = move |v33055: crate::prelude::Text| {
            let decode_p4 = v33055;
            let call_p5 = crate::prelude::Text::from(format!("{}::build(crate::prelude::Path::root(), {}&mut cx){}", &p_p0z.node_p, &crate::prelude::concat(&crate::prelude::each(&names_p3z, &(|a_p7: &crate::prelude::Text| crate::prelude::Text::from(format!("{}, ", a_p7))))), &(if fallible_p1z {
                crate::prelude::Text::lit("?")
            } else {
                crate::prelude::Text::lit("")
            })));
            ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::program_f(&p_p0z.name_p, &p_p0z.prism_p, &p_p0z.node_p, &decode_p4, &call_p5))
        };
        if &n_p2 == &crate::prelude::Nat::from(0u32) {
            k_let33055(crate::prelude::Text::lit("let _ = args;"))
        } else {
            {
                let p_p0x = p_p0.clone();
                crate::prelude::call_then(start_decode_args_f(p_p0x.clone(), names_p3.clone()), move |decode_args_f_33101: crate::prelude::Text| k_let33055(decode_args_f_33101))
            }
        }
    }
}

/// `Start RustProgram, x`: what the function value is when passed to `@Run`.
pub fn start_rust_program_f(p_p0: crate::lower::model::ProgDef, fallible_p1: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(RustProgram { p_p0, fallible_p1 })
}

/// ```prism
/// DecodeArgs: unbounded fn ProgDef, [Text] -> Text
/// ```
pub fn decode_args_f(p_p0: &crate::lower::model::ProgDef, names_p1: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Text {
    let n_p2 = crate::prelude::len(names_p1);
    let plural_p3 = if &n_p2 == &crate::prelude::Nat::from(1u32) {
        crate::prelude::Text::lit("")
    } else {
        crate::prelude::Text::lit("s")
    };
    let head_p4 = crate::prelude::Text::from(format!("let [{}] = args else {{ return ::std::result::Result::Err(crate::prelude::Fault::answer(\"@{} takes {} argument{}\")) }};", &crate::syntax::lexer::chars::join_f(names_p1, &crate::prelude::Text::lit(", ")), &p_p0.prism_p, &n_p2, &plural_p3));
    crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::Array::from(vec![head_p4.clone()]), &crate::prelude::run_to_end(crate::prelude::each_job(p_p0.params_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (a_p5, t_p6) = p0;
        crate::prelude::call_then(crate::emit::rust::start_decode_head_f(t_p6.clone()), move |decode_head_f_33678: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("let {} = {}::from_pod({})?;", &a_p5, &decode_head_f_33678, &a_p5))))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>))), &crate::prelude::Text::lit("\n"))
}

/// The step machine of `DecodeArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DecodeArgs: unbounded fn ProgDef, [Text] -> Text
/// ```
pub struct DecodeArgs {
    pub p_p0: crate::lower::model::ProgDef,
    pub names_p1: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for DecodeArgs {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let p_p0 = &self.p_p0;
        let names_p1 = &self.names_p1;
        let n_p2 = crate::prelude::len(names_p1);
        let plural_p3 = if &n_p2 == &crate::prelude::Nat::from(1u32) {
            crate::prelude::Text::lit("")
        } else {
            crate::prelude::Text::lit("s")
        };
        let head_p4 = crate::prelude::Text::from(format!("let [{}] = args else {{ return ::std::result::Result::Err(crate::prelude::Fault::answer(\"@{} takes {} argument{}\")) }};", &crate::syntax::lexer::chars::join_f(names_p1, &crate::prelude::Text::lit(", ")), &p_p0.prism_p, &n_p2, &plural_p3));
        let p_p0x = p_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(p_p0x.params_p.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::OutTy)| crate::prelude::entered(crate::prelude::once_job(move || {
            let (a_p5, t_p6) = p0;
            crate::prelude::call_then(crate::emit::rust::start_decode_head_f(t_p6.clone()), move |decode_head_f_33678: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("let {} = {}::from_pod({})?;", &a_p5, &decode_head_f_33678, &a_p5))))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::OutTy)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_33639: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::Array::from(vec![head_p4.clone()]), &each_33639), &crate::prelude::Text::lit("\n"))))
    }
}

/// `Start DecodeArgs, x`: what the function value is when passed to `@Run`.
pub fn start_decode_args_f(p_p0: crate::lower::model::ProgDef, names_p1: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(DecodeArgs { p_p0, names_p1 })
}

/// ```prism
/// RustModule: unbounded fn ModDef, Text -> Text
/// ```
pub fn rust_module_f(m_p0: &crate::lower::model::ModDef, kids_p1: &crate::prelude::Text) -> crate::prelude::Text {
    crate::emit::rust::templates::module_f(&(if &m_p0.prism_p == &crate::prelude::Text::lit("") {
        crate::prelude::Text::lit("The root module")
    } else {
        crate::prelude::Text::from(format!("The module `{}`", &m_p0.prism_p))
    }), &m_p0.path_p, kids_p1, &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(m_p0.items_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Item| crate::prelude::entered(crate::prelude::once_job(move || {
        let it_p2 = p0;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(RustItem { it_p0: it_p2.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Item) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit("\n")))
}

/// The step machine of `RustModule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustModule: unbounded fn ModDef, Text -> Text
/// ```
pub struct RustModule {
    pub m_p0: crate::lower::model::ModDef,
    pub kids_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Text> for RustModule {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let m_p0 = &self.m_p0;
        let kids_p1 = &self.kids_p1;
        let kids_p1x = kids_p1.clone();
        let m_p0x = m_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(m_p0x.items_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Item| crate::prelude::entered(crate::prelude::once_job(move || {
            let it_p2 = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(RustItem { it_p0: it_p2.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Item) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_34251: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::module_f(&(if &m_p0x.prism_p == &crate::prelude::Text::lit("") {
            crate::prelude::Text::lit("The root module")
        } else {
            crate::prelude::Text::from(format!("The module `{}`", &m_p0x.prism_p))
        }), &m_p0x.path_p, &kids_p1x, &crate::syntax::lexer::chars::join_f(&each_34251, &crate::prelude::Text::lit("\n")))))
    }
}

/// `Start RustModule, x`: what the function value is when passed to `@Run`.
pub fn start_rust_module_f(m_p0: crate::lower::model::ModDef, kids_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(RustModule { m_p0, kids_p1 })
}

/// ```prism
/// NodeFallible: fn Model, Text -> Bool
/// ```
pub fn node_fallible_f(model_p0: &crate::lower::model::Model, path_p1: &crate::prelude::Text) -> bool {
    crate::prelude::fold(&model_p0.mods_p, &false, &(|f_p2: &bool, m_p3: &crate::lower::model::ModDef| crate::prelude::fold(&m_p3.items_p, f_p2, &(|f2_p4: &bool, it_p5: &crate::lower::model::Item| match it_p5 {
        crate::lower::model::Item::ItNode(n_p6) => *f2_p4 || ((&crate::prelude::Text::from(format!("{}::{}", &m_p3.name_p, &n_p6.name_p)) == path_p1) && n_p6.fallible_p),
        _ => *f2_p4,
    }))))
}

/// ```prism
/// EmitCrate: unbounded fn Model, Text, [Text] -> [((Text, Text))]
/// ```
pub fn emit_crate_f(model_p0: &crate::lower::model::Model, runtime_p1: &crate::prelude::Text, scripts_p2: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)> {
    let gui_p3 = match &model_p0.root_o {
        ::std::option::Option::Some(r_ph) => &r_ph.world_p == &crate::prelude::Text::lit("canvas"),
        ::std::option::Option::None => false,
    };
    let cargo_p4 = crate::emit::rust::templates::cargo_f(&model_p0.name_p, runtime_p1, &(if gui_p3 {
        crate::prelude::Text::lit("\"canvas\"")
    } else {
        crate::prelude::Text::lit("")
    }));
    let paths_p5 = rust_mod_paths_f(&model_p0.mods_p);
    let mods_p6 = crate::prelude::concat(&crate::prelude::each(&crate::prelude::filter(&paths_p5, &(|p_pi: &crate::prelude::Text| !crate::syntax::lexer::chars::contains_f(p_pi, &crate::prelude::Text::lit(":")))), &(|p_pj: &crate::prelude::Text| crate::prelude::Text::from(format!("mod {};\n", p_pj)))));
    let programs_p7 = crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(all_programs_f(model_p0), {
        let model_p0x = model_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::ProgDef| {
            let model_p0xy = model_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let p_pk = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(RustProgram { p_p0: p_pk.clone(), fallible_p1: node_fallible_f(&model_p0xy, &p_pk.node_p) }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::ProgDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    })), &crate::prelude::Text::lit("\n"));
    let regs_p8 = crate::prelude::concat(&crate::prelude::each(&model_p0.programs_p, &(|p_pl: &crate::lower::model::ProgDef| crate::prelude::Text::from(format!(".program::<{}>(\"{}\")\n", &p_pl.name_p, &p_pl.prism_p)))));
    let checks_p9 = crate::prelude::concat(&crate::prelude::run_to_end(crate::prelude::each_job(model_p0.checks_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::CheckDef| crate::prelude::entered(crate::prelude::once_job(move || {
        let c_pm = p0;
        crate::prelude::call_value(crate::prelude::each_job(c_pm.lines_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Ex| crate::prelude::entered(crate::prelude::once_job(move || {
            let l_pn = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::rust::Expression { x_p0: l_pn.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_35280: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!(".check(\"{}\", || vec![{}])\n", &c_pm.name_p, &crate::syntax::lexer::chars::join_f(&each_35280, &crate::prelude::Text::lit(", "))))))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::CheckDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)));
    let script_list_pa = crate::prelude::concat(&crate::prelude::each(scripts_p2, &(|s_po: &crate::prelude::Text| crate::prelude::Text::from(format!("\"{}\",\n", &crate::lower::expr::escape_f(s_po))))));
    let run_root_pb = match &model_p0.root_o {
        ::std::option::Option::Some(r_pp) => crate::emit::rust::templates::run_root_f(&r_pp.name_p),
        ::std::option::Option::None => crate::emit::rust::templates::no_root_f(&model_p0.name_p),
    };
    let world_pc = match &model_p0.root_o {
        ::std::option::Option::Some(r_pq) => r_pq.world_p.clone(),
        ::std::option::Option::None => crate::prelude::Text::lit("test"),
    };
    let main_pd = crate::emit::rust::templates::main_f(&model_p0.name_p, &crate::prelude::Text::from(format!("mod prelude;\n{}", &mods_p6)), &crate::prelude::Text::from(format!("{}\n{}\n{}", &rust_row_f(&model_p0.elem_p), &rust_answer_f(&model_p0.answer_p), &programs_p7)), &crate::prelude::Text::from(format!("{}{}", &regs_p8, &checks_p9)), &script_list_pa, &run_root_pb, &world_pc);
    let files_pe = crate::prelude::run_to_end(crate::prelude::each_job(model_p0.mods_p.clone(), {
        let paths_p5x = paths_p5.clone();
        ::std::rc::Rc::new(move |p0: crate::lower::model::ModDef| {
            let paths_p5xy = paths_p5x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_pr = p0;
                crate::prelude::call_then(start_rust_module_f(m_pr.clone(), kids_of_f(&paths_p5xy, &m_pr.name_p)), move |rust_module_f_35794: crate::prelude::Text| ::prism_rtl::Turn::Finished((rust_mod_file_f(&m_pr.name_p), rust_module_f_35794)))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::ModDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::prelude::Text)>>>
    }));
    let named_pf = crate::prelude::each(&model_p0.mods_p, &(|m_ps: &crate::lower::model::ModDef| m_ps.name_p.clone()));
    let bare_pg = crate::prelude::each(&crate::prelude::filter(&paths_p5, &(|p_pt: &crate::prelude::Text| !crate::prelude::fold(&named_pf, &false, &(|f_pu: &bool, n_pv: &crate::prelude::Text| *f_pu || (n_pv == p_pt))))), &(|p_p10: &crate::prelude::Text| (rust_mod_file_f(p_p10), crate::prelude::Text::from(format!("//! Emitted by prismc: the modules under `{}`, which declares nothing of its own.\n\n{}", p_p10, &kids_of_f(&paths_p5, p_p10))))));
    crate::prelude::append(&crate::prelude::Array::from(vec![(crate::prelude::Text::lit("Cargo.toml"), cargo_p4.clone()), (crate::prelude::Text::lit("src/main.rs"), main_pd.clone()), (crate::prelude::Text::lit("src/prelude.rs"), crate::emit::rust::prelude::prelude_source_f(&crate::prelude::Text::lit("")))]), &crate::prelude::append(&files_pe, &bare_pg))
}

/// The step machine of `EmitCrate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EmitCrate: unbounded fn Model, Text, [Text] -> [((Text, Text))]
/// ```
pub struct EmitCrate {
    pub model_p0: crate::lower::model::Model,
    pub runtime_p1: crate::prelude::Text,
    pub scripts_p2: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>> for EmitCrate {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>> {
        let model_p0 = &self.model_p0;
        let runtime_p1 = &self.runtime_p1;
        let scripts_p2 = &self.scripts_p2;
        let gui_p3 = match &model_p0.root_o {
            ::std::option::Option::Some(r_ph) => &r_ph.world_p == &crate::prelude::Text::lit("canvas"),
            ::std::option::Option::None => false,
        };
        let cargo_p4 = crate::emit::rust::templates::cargo_f(&model_p0.name_p, runtime_p1, &(if gui_p3 {
            crate::prelude::Text::lit("\"canvas\"")
        } else {
            crate::prelude::Text::lit("")
        }));
        let paths_p5 = rust_mod_paths_f(&model_p0.mods_p);
        let mods_p6 = crate::prelude::concat(&crate::prelude::each(&crate::prelude::filter(&paths_p5, &(|p_pi: &crate::prelude::Text| !crate::syntax::lexer::chars::contains_f(p_pi, &crate::prelude::Text::lit(":")))), &(|p_pj: &crate::prelude::Text| crate::prelude::Text::from(format!("mod {};\n", p_pj)))));
        let model_p0x = model_p0.clone();
        let scripts_p2x = scripts_p2.clone();
        crate::prelude::call_value(crate::prelude::each_job(all_programs_f(&model_p0x), {
            let model_p0xx = model_p0x.clone();
            ::std::rc::Rc::new(move |p0: crate::lower::model::ProgDef| {
                let model_p0xxy = model_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let p_pk = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(RustProgram { p_p0: p_pk.clone(), fallible_p1: node_fallible_f(&model_p0xxy, &p_pk.node_p) }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::ProgDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
        }), move |each_35022: crate::prelude::Array<crate::prelude::Text>| {
            let programs_p7 = crate::syntax::lexer::chars::join_f(&each_35022, &crate::prelude::Text::lit("\n"));
            let regs_p8 = crate::prelude::concat(&crate::prelude::each(&model_p0x.programs_p, &(|p_pl: &crate::lower::model::ProgDef| crate::prelude::Text::from(format!(".program::<{}>(\"{}\")\n", &p_pl.name_p, &p_pl.prism_p)))));
            crate::prelude::call_value(crate::prelude::each_job(model_p0x.checks_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::CheckDef| crate::prelude::entered(crate::prelude::once_job(move || {
                let c_pm = p0;
                crate::prelude::call_value(crate::prelude::each_job(c_pm.lines_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Ex| crate::prelude::entered(crate::prelude::once_job(move || {
                    let l_pn = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::emit::rust::Expression { x_p0: l_pn.clone() }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_35280: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!(".check(\"{}\", || vec![{}])\n", &c_pm.name_p, &crate::syntax::lexer::chars::join_f(&each_35280, &crate::prelude::Text::lit(", "))))))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::CheckDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_35219: crate::prelude::Array<crate::prelude::Text>| {
                let checks_p9 = crate::prelude::concat(&each_35219);
                let script_list_pa = crate::prelude::concat(&crate::prelude::each(&scripts_p2x, &(|s_po: &crate::prelude::Text| crate::prelude::Text::from(format!("\"{}\",\n", &crate::lower::expr::escape_f(s_po))))));
                let run_root_pb = match &model_p0x.root_o {
                    ::std::option::Option::Some(r_pp) => crate::emit::rust::templates::run_root_f(&r_pp.name_p),
                    ::std::option::Option::None => crate::emit::rust::templates::no_root_f(&model_p0x.name_p),
                };
                let world_pc = match &model_p0x.root_o {
                    ::std::option::Option::Some(r_pq) => r_pq.world_p.clone(),
                    ::std::option::Option::None => crate::prelude::Text::lit("test"),
                };
                crate::prelude::call_then(start_rust_row_f(model_p0x.elem_p.clone()), move |rust_row_f_35625: crate::prelude::Text| crate::prelude::call_then(start_rust_answer_f(model_p0x.answer_p.clone()), move |rust_answer_f_35647: crate::prelude::Text| {
                    let main_pd = crate::emit::rust::templates::main_f(&model_p0x.name_p, &crate::prelude::Text::from(format!("mod prelude;\n{}", &mods_p6)), &crate::prelude::Text::from(format!("{}\n{}\n{}", &rust_row_f_35625, &rust_answer_f_35647, &programs_p7)), &crate::prelude::Text::from(format!("{}{}", &regs_p8, &checks_p9)), &script_list_pa, &run_root_pb, &world_pc);
                    crate::prelude::call_value(crate::prelude::each_job(model_p0x.mods_p.clone(), {
                        let paths_p5x = paths_p5.clone();
                        ::std::rc::Rc::new(move |p0: crate::lower::model::ModDef| {
                            let paths_p5xy = paths_p5x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let m_pr = p0;
                                crate::prelude::call_then(start_rust_module_f(m_pr.clone(), kids_of_f(&paths_p5xy, &m_pr.name_p)), move |rust_module_f_35794: crate::prelude::Text| ::prism_rtl::Turn::Finished((rust_mod_file_f(&m_pr.name_p), rust_module_f_35794)))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::ModDef) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::prelude::Text)>>>
                    }), move |each_35747: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>| {
                        let files_pe = each_35747;
                        let named_pf = crate::prelude::each(&model_p0x.mods_p, &(|m_ps: &crate::lower::model::ModDef| m_ps.name_p.clone()));
                        let bare_pg = crate::prelude::each(&crate::prelude::filter(&paths_p5, &(|p_pt: &crate::prelude::Text| !crate::prelude::fold(&named_pf, &false, &(|f_pu: &bool, n_pv: &crate::prelude::Text| *f_pu || (n_pv == p_pt))))), &(|p_p10: &crate::prelude::Text| (rust_mod_file_f(p_p10), crate::prelude::Text::from(format!("//! Emitted by prismc: the modules under `{}`, which declares nothing of its own.\n\n{}", p_p10, &kids_of_f(&paths_p5, p_p10))))));
                        ::prism_rtl::Turn::Finished(crate::prelude::append(&crate::prelude::Array::from(vec![(crate::prelude::Text::lit("Cargo.toml"), cargo_p4.clone()), (crate::prelude::Text::lit("src/main.rs"), main_pd.clone()), (crate::prelude::Text::lit("src/prelude.rs"), crate::emit::rust::prelude::prelude_source_f(&crate::prelude::Text::lit("")))]), &crate::prelude::append(&files_pe, &bare_pg)))
                    })
                }))
            })
        })
    }
}

/// `Start EmitCrate, x`: what the function value is when passed to `@Run`.
pub fn start_emit_crate_f(model_p0: crate::lower::model::Model, runtime_p1: crate::prelude::Text, scripts_p2: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>>> {
    ::std::rc::Rc::new(EmitCrate { model_p0, runtime_p1, scripts_p2 })
}

/// ```prism
/// RustModPaths: fn [ModDef] -> [Text]
/// ```
pub fn rust_mod_paths_f(mods_p0: &crate::prelude::Array<crate::lower::model::ModDef>) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::fold(mods_p0, &crate::prelude::Array::new(), &(|acc_p1: &crate::prelude::Array<crate::prelude::Text>, m_p2: &crate::lower::model::ModDef| {
        let segs_p3 = crate::prelude::split_on(&m_p2.name_p, &crate::prelude::Text::lit("::"));
        crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&segs_p3)), acc_p1, &(|a_p4: &crate::prelude::Array<crate::prelude::Text>, i_p5: &crate::prelude::Nat| add_path_f(a_p4, &crate::syntax::lexer::chars::join_f(&crate::prelude::take(&segs_p3, &(i_p5 + &crate::prelude::Nat::from(1u32))), &crate::prelude::Text::lit("::")))))
    }))
}

/// ```prism
/// AddPath: fn [Text], Text -> [Text]
/// ```
pub fn add_path_f(ps_p0: &crate::prelude::Array<crate::prelude::Text>, p_p1: &crate::prelude::Text) -> crate::prelude::Array<crate::prelude::Text> {
    if crate::prelude::fold(ps_p0, &false, &(|f_p2: &bool, q_p3: &crate::prelude::Text| *f_p2 || (q_p3 == p_p1))) {
        ps_p0.clone()
    } else {
        crate::prelude::push(ps_p0, p_p1)
    }
}

/// ```prism
/// RustModFile: fn Text -> Text
/// ```
pub fn rust_mod_file_f(p_p0: &crate::prelude::Text) -> crate::prelude::Text {
    if p_p0 == &crate::prelude::Text::lit("program") {
        crate::prelude::Text::lit("src/program.rs")
    } else {
        crate::prelude::Text::from(format!("src/{}/mod.rs", &crate::syntax::lexer::chars::join_f(&crate::prelude::split_on(p_p0, &crate::prelude::Text::lit("::")), &crate::prelude::Text::lit("/"))))
    }
}

/// ```prism
/// KidsOf: fn [Text], Text -> Text
/// ```
pub fn kids_of_f(paths_p0: &crate::prelude::Array<crate::prelude::Text>, p_p1: &crate::prelude::Text) -> crate::prelude::Text {
    crate::prelude::concat(&crate::prelude::each(&crate::prelude::filter(paths_p0, &(|q_p2: &crate::prelude::Text| crate::syntax::lexer::chars::has_prefix_f(q_p2, &crate::prelude::Text::from(format!("{}::", p_p1))) && !crate::syntax::lexer::chars::contains_f(&crate::syntax::lexer::chars::drop_prefix_f(q_p2, &crate::prelude::Text::from(format!("{}::", p_p1))), &crate::prelude::Text::lit(":")))), &(|q_p3: &crate::prelude::Text| crate::prelude::Text::from(format!("pub mod {};\n", &crate::syntax::lexer::chars::drop_prefix_f(q_p3, &crate::prelude::Text::from(format!("{}::", p_p1))))))))
}

/// ```prism
/// AllPrograms: fn Model -> [ProgDef]
/// ```
pub fn all_programs_f(model_p0: &crate::lower::model::Model) -> crate::prelude::Array<crate::lower::model::ProgDef> {
    match &model_p0.root_o {
        ::std::option::Option::Some(r_p1) => if crate::prelude::fold(&model_p0.programs_p, &false, &(|f_p2: &bool, p_p3: &crate::lower::model::ProgDef| *f_p2 || (&p_p3.name_p == &r_p1.name_p))) {
            model_p0.programs_p.clone()
        } else {
            crate::prelude::push(&model_p0.programs_p, r_p1)
        },
        ::std::option::Option::None => model_p0.programs_p.clone(),
    }
}
