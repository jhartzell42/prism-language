//! The module `Emit.Rust.Items`, from `target/bootstrap/src/prismc/emit/rust/items.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// Generics: fn [((Text, [Text]))] -> Text
/// ```
pub fn generics(xs0: &Array<(Text, Array<Text>)>) -> Text {
    match xs0 {
        c0_0 if (c0_0.len() == 0) => Text::lit(""),
        gs_p0 => Text::from(format!("<{}>", &crate::syntax::lexer::chars::join(&each(gs_p0, &(|(g_p1, bs_p2): &(Text, Array<Text>)| if &len(bs_p2) == &Nat::from(0u32) {
            g_p1.clone()
        } else {
            Text::from(format!("{}: {}", g_p1, &crate::syntax::lexer::chars::join(bs_p2, &Text::lit(" + "))))
        })), &Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// GenericNames: fn [Text] -> Text
/// ```
pub fn generic_names(xs0: &Array<Text>) -> Text {
    match xs0 {
        c0_0 if (c0_0.len() == 0) => Text::lit(""),
        ps_p0 => Text::from(format!("<{}>", &crate::syntax::lexer::chars::join(ps_p0, &Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Bounded: fn [Text], Text -> Text
/// ```
pub fn bounded(xs0: &Array<Text>, text1: &Text) -> Text {
    match (xs0, text1) {
        (c0_0, _) if (c0_0.len() == 0) => Text::lit(""),
        (ps_p0, tr_p1) => Text::from(format!("<{}>", &crate::syntax::lexer::chars::join(&each(ps_p0, &(|p_p2: &Text| Text::from(format!("{}: {}", p_p2, tr_p1)))), &Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// RustItem: unbounded fn Item -> Text
/// ```
pub fn rust_item(it_p0: &crate::lower::model::Item) -> Text {
    match it_p0 {
        crate::lower::model::Item::ItTrait(t_p1) => rust_trait(t_p1),
        crate::lower::model::Item::ItImpl(i_p2) => rust_impl(i_p2),
        crate::lower::model::Item::ItType(t_p3) => type_decl(t_p3),
        crate::lower::model::Item::ItTag(t_p4) => rust_tag(t_p4),
        crate::lower::model::Item::ItRow(r_p5) => rust_row(r_p5),
        crate::lower::model::Item::ItFn(f_p6) => rust_fn(f_p6),
        crate::lower::model::Item::ItJob(j_p7) => rust_job(j_p7),
        crate::lower::model::Item::ItNode(n_p8) => rust_node(n_p8),
        crate::lower::model::Item::ItNote(t_p9) => Text::from(format!("// {}\n", t_p9)),
        crate::lower::model::Item::ItRefused(t_pa) => Text::from(format!("compile_error!(\"{}{}\");\n", &crate::lower::expr::lowering_refusal(), &crate::lower::expr::escape(t_pa))),
    }
}

/// The step machine of `RustItem`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustItem: unbounded fn Item -> Text
/// ```
pub struct RustItem {
    pub it_p0: crate::lower::model::Item,
}

impl prism_rtl::Job<Text> for RustItem {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let it_p0 = &self.it_p0;
        match it_p0 {
            crate::lower::model::Item::ItTrait(t_p1) => prism_rtl::Turn::More(Rc::new(RustTrait { t_p0: t_p1.clone() })),
            crate::lower::model::Item::ItImpl(i_p2) => prism_rtl::Turn::More(Rc::new(RustImpl { i_p0: i_p2.clone() })),
            crate::lower::model::Item::ItType(t_p3) => prism_rtl::Turn::More(Rc::new(TypeDecl { t_p0: t_p3.clone() })),
            crate::lower::model::Item::ItTag(t_p4) => prism_rtl::Turn::More(Rc::new(RustTag { t_p0: t_p4.clone() })),
            crate::lower::model::Item::ItRow(r_p5) => prism_rtl::Turn::More(Rc::new(RustRow { r_p0: r_p5.clone() })),
            crate::lower::model::Item::ItFn(f_p6) => prism_rtl::Turn::More(Rc::new(RustFn { f_p0: f_p6.clone() })),
            crate::lower::model::Item::ItJob(j_p7) => prism_rtl::Turn::More(Rc::new(RustJob { j_p0: j_p7.clone() })),
            crate::lower::model::Item::ItNode(n_p8) => prism_rtl::Turn::More(Rc::new(RustNode { n_p0: n_p8.clone() })),
            crate::lower::model::Item::ItNote(t_p9) => prism_rtl::Turn::Finished(Text::from(format!("// {}\n", t_p9))),
            crate::lower::model::Item::ItRefused(t_pa) => prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}{}\");\n", &crate::lower::expr::lowering_refusal(), &crate::lower::expr::escape(t_pa)))),
        }
    }
}

/// `Start RustItem, x`: what the function value is when passed to `@Run`.
pub fn start_rust_item(it_p0: crate::lower::model::Item) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustItem { it_p0 })
}

/// ```prism
/// RustTrait: unbounded fn TraitDef -> Text
/// ```
pub fn rust_trait(t_p0: &crate::lower::model::TraitDef) -> Text {
    let ms_p1 = crate::syntax::lexer::chars::join(&run_to_end(each_job(t_p0.methods.clone(), Rc::new(move |p0: crate::lower::model::FnDef| entered(once_job(move || {
        let f_p2 = p0;
        prism_rtl::Turn::More(Rc::new(TraitMethod { f_p0: f_p2.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    Text::from(format!("{}pub trait {} {{\n{}\n}}\n", &crate::emit::rust::templates::source_doc(&Text::lit(""), &t_p0.doc), &t_p0.name, &crate::emit::rust::indent(&ms_p1)))
}

/// The step machine of `RustTrait`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustTrait: unbounded fn TraitDef -> Text
/// ```
pub struct RustTrait {
    pub t_p0: crate::lower::model::TraitDef,
}

impl prism_rtl::Job<Text> for RustTrait {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t_p0 = &self.t_p0;
        let t_p0 = t_p0.clone();
        call_value(each_job(t_p0.methods.clone(), Rc::new(move |p0: crate::lower::model::FnDef| entered(once_job(move || {
            let f_p2 = p0;
            prism_rtl::Turn::More(Rc::new(TraitMethod { f_p0: f_p2.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_1796: Array<Text>| {
            let ms_p1 = crate::syntax::lexer::chars::join(&each_1796, &Text::lit("\n"));
            prism_rtl::Turn::Finished(Text::from(format!("{}pub trait {} {{\n{}\n}}\n", &crate::emit::rust::templates::source_doc(&Text::lit(""), &t_p0.doc), &t_p0.name, &crate::emit::rust::indent(&ms_p1))))
        })
    }
}

/// `Start RustTrait, x`: what the function value is when passed to `@Run`.
pub fn start_rust_trait(t_p0: crate::lower::model::TraitDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustTrait { t_p0 })
}

/// ```prism
/// Signature: unbounded fn FnDef, Text -> Text
/// ```
pub fn signature(f_p0: &crate::lower::model::FnDef, vis_p1: &Text) -> Text {
    let params_p2 = crate::syntax::lexer::chars::join(&run_to_end(each_job(f_p0.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (n_p3, t_p4) = p0;
        call_then(crate::emit::rust::start_type_(t_p4.clone()), move |type__2029: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n_p3, &type__2029))))
    }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "));
    Text::from(format!("{}fn {}{}({}) -> {}", vis_p1, &f_p0.name, &generics(&f_p0.generics), &params_p2, &crate::emit::rust::type_(&f_p0.ret)))
}

/// The step machine of `Signature`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Signature: unbounded fn FnDef, Text -> Text
/// ```
pub struct Signature {
    pub f_p0: crate::lower::model::FnDef,
    pub vis_p1: Text,
}

impl prism_rtl::Job<Text> for Signature {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f_p0 = &self.f_p0;
        let vis_p1 = &self.vis_p1;
        let f_p0 = f_p0.clone();
        let vis_p1 = vis_p1.clone();
        call_value(each_job(f_p0.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
            let (n_p3, t_p4) = p0;
            call_then(crate::emit::rust::start_type_(t_p4.clone()), move |type__2029: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n_p3, &type__2029))))
        }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_1995: Array<Text>| {
            let params_p2 = crate::syntax::lexer::chars::join(&each_1995, &Text::lit(", "));
            call_then(crate::emit::rust::start_type_(f_p0.ret.clone()), move |type__2102: Text| prism_rtl::Turn::Finished(Text::from(format!("{}fn {}{}({}) -> {}", &vis_p1, &f_p0.name, &generics(&f_p0.generics), &params_p2, &type__2102))))
        })
    }
}

/// `Start Signature, x`: what the function value is when passed to `@Run`.
pub fn start_signature(f_p0: crate::lower::model::FnDef, vis_p1: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Signature { f_p0, vis_p1 })
}

/// ```prism
/// TraitMethod: unbounded fn FnDef -> Text
/// ```
pub fn trait_method(f_p0: &crate::lower::model::FnDef) -> Text {
    if f_p0.public {
        crate::emit::rust::templates::items::fn_(&Text::lit(""), &signature(f_p0, &Text::lit("")), &crate::emit::rust::body_lines(&f_p0.body))
    } else {
        Text::from(format!("{};", &signature(f_p0, &Text::lit(""))))
    }
}

/// The step machine of `TraitMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TraitMethod: unbounded fn FnDef -> Text
/// ```
pub struct TraitMethod {
    pub f_p0: crate::lower::model::FnDef,
}

impl prism_rtl::Job<Text> for TraitMethod {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f_p0 = &self.f_p0;
        if f_p0.public {
            {
                let f_p0 = f_p0.clone();
                call_then(start_signature(f_p0.clone(), Text::lit("")), move |signature_2196: Text| call_then(crate::emit::rust::start_body_lines(f_p0.body.clone()), move |body_lines_2215: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::fn_(&Text::lit(""), &signature_2196, &body_lines_2215))))
            }
        } else {
            {
                let f_p0 = f_p0.clone();
                call_then(start_signature(f_p0.clone(), Text::lit("")), move |signature_2241: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &signature_2241))))
            }
        }
    }
}

/// `Start TraitMethod, x`: what the function value is when passed to `@Run`.
pub fn start_trait_method(f_p0: crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TraitMethod { f_p0 })
}

/// ```prism
/// RustImpl: unbounded fn ImplDef -> Text
/// ```
pub fn rust_impl(i_p0: &crate::lower::model::ImplDef) -> Text {
    let head_p1 = crate::emit::rust::type_(&i_p0.head);
    let gens_p2 = generics(&i_p0.generics);
    match &i_p0.cls {
        m2516_0 if (m2516_0 == &Text::lit("Prelude.Show")) => {
            let fns_p3 = crate::syntax::lexer::chars::join(&run_to_end(each_job(i_p0.methods.clone(), Rc::new(move |p0: crate::lower::model::FnDef| entered(once_job(move || {
                let f_p5 = p0;
                prism_rtl::Turn::More(Rc::new(RustFn { f_p0: f_p5.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
            let shown_p4 = or(&index(&each(&i_p0.methods, &(|f_p6: &crate::lower::model::FnDef| f_p6.name.clone())), &Nat::from(0u32)), &Text::lit("show"));
            Text::from(format!("{}\n{}", &fns_p3, &crate::emit::rust::templates::items::impl_(&gens_p2, &Text::lit("Show"), &head_p1, &Text::lit("fn show(&self, p: &mut Printer)"), &Text::from(format!("p.raw(&{}(self).to_string());", &shown_p4)))))
        },
        m2516_1 if (m2516_1 == &Text::lit("Prelude.Eq")) => {
            let fns_p7 = crate::syntax::lexer::chars::join(&run_to_end(each_job(i_p0.methods.clone(), Rc::new(move |p0: crate::lower::model::FnDef| entered(once_job(move || {
                let f_p9 = p0;
                prism_rtl::Turn::More(Rc::new(RustFn { f_p0: f_p9.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
            let eq_p8 = fold(&i_p0.methods, &Text::lit(""), &(|acc_pa: &Text, f_pb: &crate::lower::model::FnDef| if !crate::syntax::lexer::chars::has_prefix(&f_pb.name, &Text::lit("ne")) && (acc_pa == &Text::lit("")) {
                f_pb.name.clone()
            } else {
                acc_pa.clone()
            }));
            Text::from(format!("{}\n{}\nimpl{} Eq for {} {{}}", &fns_p7, &crate::emit::rust::templates::items::impl_(&gens_p2, &Text::lit("PartialEq"), &head_p1, &Text::lit("fn eq(&self, other: &Self) -> bool"), &Text::from(format!("{}(self, other)", &eq_p8))), &gens_p2, &head_p1))
        },
        _ => Text::from(format!("impl{} {} for {} {{\n{}\n}}\n", &gens_p2, &i_p0.tr, &head_p1, &crate::emit::rust::indent(&crate::syntax::lexer::chars::join(&run_to_end(each_job(i_p0.methods.clone(), Rc::new(move |p0: crate::lower::model::FnDef| entered(once_job(move || {
            let f_pc = p0;
            call_then(start_signature(f_pc.clone(), Text::lit("")), move |signature_3249: Text| call_then(crate::emit::rust::start_body_lines(f_pc.body.clone()), move |body_lines_3268: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::fn_(&Text::lit(""), &signature_3249, &body_lines_3268))))
        }))) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `RustImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustImpl: unbounded fn ImplDef -> Text
/// ```
pub struct RustImpl {
    pub i_p0: crate::lower::model::ImplDef,
}

impl prism_rtl::Job<Text> for RustImpl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let i_p0 = &self.i_p0;
        let i_p0 = i_p0.clone();
        call_then(crate::emit::rust::start_type_(i_p0.head.clone()), move |type__2465: Text| {
            let head_p1 = type__2465;
            let gens_p2 = generics(&i_p0.generics);
            match &i_p0.cls {
                m2516_0 if (m2516_0 == &Text::lit("Prelude.Show")) => call_value(each_job(i_p0.methods.clone(), Rc::new(move |p0: crate::lower::model::FnDef| entered(once_job(move || {
                    let f_p5 = p0;
                    prism_rtl::Turn::More(Rc::new(RustFn { f_p0: f_p5.clone() }))
                }))) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_2581: Array<Text>| {
                    let fns_p3 = crate::syntax::lexer::chars::join(&each_2581, &Text::lit("\n"));
                    let shown_p4 = or(&index(&each(&i_p0.methods, &(|f_p6: &crate::lower::model::FnDef| f_p6.name.clone())), &Nat::from(0u32)), &Text::lit("show"));
                    prism_rtl::Turn::Finished(Text::from(format!("{}\n{}", &fns_p3, &crate::emit::rust::templates::items::impl_(&gens_p2, &Text::lit("Show"), &head_p1, &Text::lit("fn show(&self, p: &mut Printer)"), &Text::from(format!("p.raw(&{}(self).to_string());", &shown_p4))))))
                }),
                m2516_1 if (m2516_1 == &Text::lit("Prelude.Eq")) => call_value(each_job(i_p0.methods.clone(), Rc::new(move |p0: crate::lower::model::FnDef| entered(once_job(move || {
                    let f_p9 = p0;
                    prism_rtl::Turn::More(Rc::new(RustFn { f_p0: f_p9.clone() }))
                }))) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_2856: Array<Text>| {
                    let fns_p7 = crate::syntax::lexer::chars::join(&each_2856, &Text::lit("\n"));
                    let eq_p8 = fold(&i_p0.methods, &Text::lit(""), &(|acc_pa: &Text, f_pb: &crate::lower::model::FnDef| if !crate::syntax::lexer::chars::has_prefix(&f_pb.name, &Text::lit("ne")) && (acc_pa == &Text::lit("")) {
                        f_pb.name.clone()
                    } else {
                        acc_pa.clone()
                    }));
                    prism_rtl::Turn::Finished(Text::from(format!("{}\n{}\nimpl{} Eq for {} {{}}", &fns_p7, &crate::emit::rust::templates::items::impl_(&gens_p2, &Text::lit("PartialEq"), &head_p1, &Text::lit("fn eq(&self, other: &Self) -> bool"), &Text::from(format!("{}(self, other)", &eq_p8))), &gens_p2, &head_p1)))
                }),
                _ => call_value(each_job(i_p0.methods.clone(), Rc::new(move |p0: crate::lower::model::FnDef| entered(once_job(move || {
                    let f_pc = p0;
                    call_then(start_signature(f_pc.clone(), Text::lit("")), move |signature_3249: Text| call_then(crate::emit::rust::start_body_lines(f_pc.body.clone()), move |body_lines_3268: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::fn_(&Text::lit(""), &signature_3249, &body_lines_3268))))
                }))) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_3220: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("impl{} {} for {} {{\n{}\n}}\n", &gens_p2, &i_p0.tr, &head_p1, &crate::emit::rust::indent(&crate::syntax::lexer::chars::join(&each_3220, &Text::lit("\n"))))))),
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start RustImpl, x`: what the function value is when passed to `@Run`.
pub fn start_rust_impl(i_p0: crate::lower::model::ImplDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustImpl { i_p0 })
}

/// ```prism
/// RustFn: unbounded fn FnDef -> Text
/// ```
pub fn rust_fn(f_p0: &crate::lower::model::FnDef) -> Text {
    let params_p1 = crate::syntax::lexer::chars::join(&run_to_end(each_job(f_p0.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (n_p3, t_p4) = p0;
        call_then(crate::emit::rust::start_type_(t_p4.clone()), move |type__3408: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n_p3, &type__3408))))
    }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "));
    let sig_p2 = Text::from(format!("pub fn {}{}({}) -> {}", &f_p0.name, &static_generics(&f_p0.generics), &params_p1, &crate::emit::rust::type_(&f_p0.ret)));
    crate::emit::rust::templates::items::fn_(&crate::emit::rust::templates::source_doc(&Text::lit(""), &f_p0.doc), &sig_p2, &crate::emit::rust::body_lines(&f_p0.body))
}

/// The step machine of `RustFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustFn: unbounded fn FnDef -> Text
/// ```
pub struct RustFn {
    pub f_p0: crate::lower::model::FnDef,
}

impl prism_rtl::Job<Text> for RustFn {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f_p0 = &self.f_p0;
        let f_p0 = f_p0.clone();
        call_value(each_job(f_p0.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
            let (n_p3, t_p4) = p0;
            call_then(crate::emit::rust::start_type_(t_p4.clone()), move |type__3408: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n_p3, &type__3408))))
        }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_3374: Array<Text>| {
            let params_p1 = crate::syntax::lexer::chars::join(&each_3374, &Text::lit(", "));
            call_then(crate::emit::rust::start_type_(f_p0.ret.clone()), move |type__3638: Text| {
                let sig_p2 = Text::from(format!("pub fn {}{}({}) -> {}", &f_p0.name, &static_generics(&f_p0.generics), &params_p1, &type__3638));
                call_then(crate::emit::rust::start_body_lines(f_p0.body.clone()), move |body_lines_3687: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::fn_(&crate::emit::rust::templates::source_doc(&Text::lit(""), &f_p0.doc), &sig_p2, &body_lines_3687)))
            })
        })
    }
}

/// `Start RustFn, x`: what the function value is when passed to `@Run`.
pub fn start_rust_fn(f_p0: crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustFn { f_p0 })
}

/// ```prism
/// StaticGenerics: fn [((Text, [Text]))] -> Text
/// ```
pub fn static_generics(gs_p0: &Array<(Text, Array<Text>)>) -> Text {
    generics(&each(gs_p0, &(|(g_p1, bs_p2): &(Text, Array<Text>)| (g_p1.clone(), push(bs_p2, &Text::lit("\'static"))))))
}

/// ```prism
/// RustJob: unbounded fn JobDef -> Text
/// ```
pub fn rust_job(j_p0: &crate::lower::model::JobDef) -> Text {
    let gnames_p1 = generic_names(&each(&j_p0.generics, &(|(g_p7, _): &(Text, Array<Text>)| g_p7.clone())));
    let fields_p2 = crate::syntax::lexer::chars::join(&run_to_end(each_job(j_p0.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (n_p8, t_p9) = p0;
        call_then(crate::emit::rust::start_type_(t_p9.clone()), move |type__4093: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &n_p8, &type__4093))))
    }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let params_p3 = crate::syntax::lexer::chars::join(&run_to_end(each_job(j_p0.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (n_pa, t_pb) = p0;
        call_then(crate::emit::rust::start_type_(t_pb.clone()), move |type__4167: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n_pa, &type__4167))))
    }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "));
    let bounded_p4 = static_generics(&j_p0.generics);
    let start_p5 = Text::from(format!("pub fn {}{}({}) -> Rc<dyn prism_rtl::Job<{}>>", &j_p0.start, &bounded_p4, &params_p3, &crate::emit::rust::type_(&j_p0.ret)));
    let start_body_p6 = Text::from(format!("Rc::new({} {{ {} }})", &j_p0.name, &crate::syntax::lexer::chars::join(&each(&j_p0.fields, &(|(n_pc, _): &(Text, crate::lower::model::OutTy)| n_pc.clone())), &Text::lit(", "))));
    crate::emit::rust::templates::items::job(&crate::emit::rust::templates::source_doc(&Text::lit(""), &j_p0.doc), &j_p0.name, &gnames_p1, &bounded_p4, &fields_p2, &crate::emit::rust::type_(&j_p0.ret), &crate::emit::rust::body_lines(&j_p0.body), &start_p5, &start_body_p6)
}

/// The step machine of `RustJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustJob: unbounded fn JobDef -> Text
/// ```
pub struct RustJob {
    pub j_p0: crate::lower::model::JobDef,
}

impl prism_rtl::Job<Text> for RustJob {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let j_p0 = &self.j_p0;
        let gnames_p1 = generic_names(&each(&j_p0.generics, &(|(g_p7, _): &(Text, Array<Text>)| g_p7.clone())));
        let j_p0 = j_p0.clone();
        call_value(each_job(j_p0.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
            let (n_p8, t_p9) = p0;
            call_then(crate::emit::rust::start_type_(t_p9.clone()), move |type__4093: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &n_p8, &type__4093))))
        }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_4055: Array<Text>| {
            let fields_p2 = crate::syntax::lexer::chars::join(&each_4055, &Text::lit("\n"));
            call_value(each_job(j_p0.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
                let (n_pa, t_pb) = p0;
                call_then(crate::emit::rust::start_type_(t_pb.clone()), move |type__4167: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n_pa, &type__4167))))
            }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_4133: Array<Text>| {
                let params_p3 = crate::syntax::lexer::chars::join(&each_4133, &Text::lit(", "));
                let bounded_p4 = static_generics(&j_p0.generics);
                call_then(crate::emit::rust::start_type_(j_p0.ret.clone()), move |type__4391: Text| {
                    let start_p5 = Text::from(format!("pub fn {}{}({}) -> Rc<dyn prism_rtl::Job<{}>>", &j_p0.start, &bounded_p4, &params_p3, &type__4391));
                    let start_body_p6 = Text::from(format!("Rc::new({} {{ {} }})", &j_p0.name, &crate::syntax::lexer::chars::join(&each(&j_p0.fields, &(|(n_pc, _): &(Text, crate::lower::model::OutTy)| n_pc.clone())), &Text::lit(", "))));
                    call_then(crate::emit::rust::start_type_(j_p0.ret.clone()), move |type__4566: Text| call_then(crate::emit::rust::start_body_lines(j_p0.body.clone()), move |body_lines_4580: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::job(&crate::emit::rust::templates::source_doc(&Text::lit(""), &j_p0.doc), &j_p0.name, &gnames_p1, &bounded_p4, &fields_p2, &type__4566, &body_lines_4580, &start_p5, &start_body_p6))))
                })
            })
        })
    }
}

/// `Start RustJob, x`: what the function value is when passed to `@Run`.
pub fn start_rust_job(j_p0: crate::lower::model::JobDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustJob { j_p0 })
}

/// ```prism
/// TypeDecl: unbounded fn TyDef -> Text
/// ```
pub fn type_decl(t_p0: &crate::lower::model::TyDef) -> Text {
    let derives_p1 = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![Text::lit("Clone"), if t_p0.eq || t_p0.ord { Text::lit("PartialEq, Eq") } else { Text::lit("") }, if t_p0.ord { Text::lit("PartialOrd, Ord") } else { Text::lit("") }]), &(|d_p7: &Text| d_p7 != &Text::lit(""))), &Text::lit(", "));
    let head_p2 = Text::from(format!("{}{}", &t_p0.name, &generic_names(&t_p0.params)));
    let doc_p3 = crate::emit::rust::templates::source_doc(&Text::from(format!("`{}`:", &t_p0.prism)), &t_p0.doc);
    let decl_p4 = match &t_p0.shape {
        crate::lower::model::TyShape::ShapeRecord => {
            let c_p8 = or(&index(&t_p0.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            crate::emit::rust::templates::items::struct_(&doc_p3, &derives_p1, &head_p2, &crate::syntax::lexer::chars::join(&run_to_end(each_job(c_p8.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
                let (f_p9, ft_pa) = p0;
                call_then(crate::emit::rust::start_type_(ft_pa.clone()), move |type__5220: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &f_p9, &type__5220))))
            }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n")))
        },
        crate::lower::model::TyShape::ShapeUnit => crate::emit::rust::templates::items::tuple_struct(&doc_p3, &derives_p1, &head_p2, &Text::lit("")),
        crate::lower::model::TyShape::ShapeNewtype => {
            let c_pb = or(&index(&t_p0.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            crate::emit::rust::templates::items::tuple_struct(&doc_p3, &derives_p1, &head_p2, &Text::from(format!("({})", &crate::syntax::lexer::chars::join(&run_to_end(each_job(c_pb.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
                let (_, ft_pc) = p0;
                call_then(crate::emit::rust::start_type_(ft_pc.clone()), move |type__5484: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}", &type__5484))))
            }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", ")))))
        },
        _ => crate::emit::rust::templates::items::enum_(&doc_p3, &derives_p1, &head_p2, &crate::syntax::lexer::chars::join(&run_to_end(each_job(t_p0.cases.clone(), Rc::new(move |p0: crate::lower::model::CaseDef| entered(once_job(move || {
            let c_pd = p0;
            prism_rtl::Turn::More(Rc::new(EnumCase { c_p0: c_pd.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))),
    };
    let show_p5 = if &t_p0.show == &crate::lower::model::Shown::ShownDerived {
        Text::from(format!("\n{}", &show_impl(t_p0, &head_p2)))
    } else {
        Text::lit("")
    };
    let pod_p6 = if t_p0.pod {
        Text::from(format!("\n{}\n{}", &to_pod_impl(t_p0, &head_p2), &from_pod_impl(t_p0, &head_p2)))
    } else {
        Text::lit("")
    };
    Text::from(format!("{}{}{}", &decl_p4, &show_p5, &pod_p6))
}

/// The step machine of `TypeDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeDecl: unbounded fn TyDef -> Text
/// ```
pub struct TypeDecl {
    pub t_p0: crate::lower::model::TyDef,
}

impl prism_rtl::Job<Text> for TypeDecl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t_p0 = &self.t_p0;
        let derives_p1 = crate::syntax::lexer::chars::join(&filter(&Array::from(vec![Text::lit("Clone"), if t_p0.eq || t_p0.ord { Text::lit("PartialEq, Eq") } else { Text::lit("") }, if t_p0.ord { Text::lit("PartialOrd, Ord") } else { Text::lit("") }]), &(|d_p7: &Text| d_p7 != &Text::lit(""))), &Text::lit(", "));
        let head_p2 = Text::from(format!("{}{}", &t_p0.name, &generic_names(&t_p0.params)));
        let doc_p3 = crate::emit::rust::templates::source_doc(&Text::from(format!("`{}`:", &t_p0.prism)), &t_p0.doc);
        let decl_p4 = match &t_p0.shape {
            crate::lower::model::TyShape::ShapeRecord => {
                let c_p8 = or(&index(&t_p0.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                crate::emit::rust::templates::items::struct_(&doc_p3, &derives_p1, &head_p2, &crate::syntax::lexer::chars::join(&run_to_end(each_job(c_p8.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
                    let (f_p9, ft_pa) = p0;
                    call_then(crate::emit::rust::start_type_(ft_pa.clone()), move |type__5220: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &f_p9, &type__5220))))
                }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n")))
            },
            crate::lower::model::TyShape::ShapeUnit => crate::emit::rust::templates::items::tuple_struct(&doc_p3, &derives_p1, &head_p2, &Text::lit("")),
            crate::lower::model::TyShape::ShapeNewtype => {
                let c_pb = or(&index(&t_p0.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                crate::emit::rust::templates::items::tuple_struct(&doc_p3, &derives_p1, &head_p2, &Text::from(format!("({})", &crate::syntax::lexer::chars::join(&run_to_end(each_job(c_pb.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
                    let (_, ft_pc) = p0;
                    call_then(crate::emit::rust::start_type_(ft_pc.clone()), move |type__5484: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}", &type__5484))))
                }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", ")))))
            },
            _ => crate::emit::rust::templates::items::enum_(&doc_p3, &derives_p1, &head_p2, &crate::syntax::lexer::chars::join(&run_to_end(each_job(t_p0.cases.clone(), Rc::new(move |p0: crate::lower::model::CaseDef| entered(once_job(move || {
                let c_pd = p0;
                prism_rtl::Turn::More(Rc::new(EnumCase { c_p0: c_pd.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))),
        };
        let show_p5 = if &t_p0.show == &crate::lower::model::Shown::ShownDerived {
            Text::from(format!("\n{}", &show_impl(t_p0, &head_p2)))
        } else {
            Text::lit("")
        };
        let pod_p6 = if t_p0.pod {
            Text::from(format!("\n{}\n{}", &to_pod_impl(t_p0, &head_p2), &from_pod_impl(t_p0, &head_p2)))
        } else {
            Text::lit("")
        };
        prism_rtl::Turn::Finished(Text::from(format!("{}{}{}", &decl_p4, &show_p5, &pod_p6)))
    }
}

/// `Start TypeDecl, x`: what the function value is when passed to `@Run`.
pub fn start_type_decl(t_p0: crate::lower::model::TyDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TypeDecl { t_p0 })
}

/// ```prism
/// EnumCase: unbounded fn CaseDef -> Text
/// ```
pub fn enum_case(c_p0: &crate::lower::model::CaseDef) -> Text {
    if &len(&c_p0.fields) == &Nat::from(0u32) {
        Text::from(format!("{},", &c_p0.name))
    } else {
        Text::from(format!("{}({}),", &c_p0.name, &crate::syntax::lexer::chars::join(&run_to_end(each_job(c_p0.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
            let (_, ft_p1) = p0;
            prism_rtl::Turn::More(Rc::new(crate::emit::rust::Type { t_p0: ft_p1.clone() }))
        }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))))
    }
}

/// The step machine of `EnumCase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EnumCase: unbounded fn CaseDef -> Text
/// ```
pub struct EnumCase {
    pub c_p0: crate::lower::model::CaseDef,
}

impl prism_rtl::Job<Text> for EnumCase {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let c_p0 = &self.c_p0;
        if &len(&c_p0.fields) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished(Text::from(format!("{},", &c_p0.name)))
        } else {
            {
                let c_p0 = c_p0.clone();
                call_value(each_job(c_p0.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
                    let (_, ft_p1) = p0;
                    prism_rtl::Turn::More(Rc::new(crate::emit::rust::Type { t_p0: ft_p1.clone() }))
                }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_5886: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{}({}),", &c_p0.name, &crate::syntax::lexer::chars::join(&each_5886, &Text::lit(", "))))))
            }
        }
    }
}

/// `Start EnumCase, x`: what the function value is when passed to `@Run`.
pub fn start_enum_case(c_p0: crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(EnumCase { c_p0 })
}

/// ```prism
/// Binders: fn Nat -> [Text]
/// ```
pub fn binders(n_p0: &Nat) -> Array<Text> {
    each(&crate::check::errors::range0(n_p0), &(|i_p1: &Nat| Text::from(format!("a{}", i_p1))))
}

/// ```prism
/// CasePattern: fn TyDef, CaseDef -> Text
/// ```
pub fn case_pattern(t_p0: &crate::lower::model::TyDef, c_p1: &crate::lower::model::CaseDef) -> Text {
    match &t_p0.shape {
        crate::lower::model::TyShape::ShapeNewtype => Text::from(format!("{}({})", &t_p0.name, &crate::syntax::lexer::chars::join(&binders(&len(&c_p1.fields)), &Text::lit(", ")))),
        crate::lower::model::TyShape::ShapeUnit => t_p0.name.clone(),
        _ => if &len(&c_p1.fields) == &Nat::from(0u32) {
            Text::from(format!("{}::{}", &t_p0.name, &c_p1.name))
        } else {
            Text::from(format!("{}::{}({})", &t_p0.name, &c_p1.name, &crate::syntax::lexer::chars::join(&binders(&len(&c_p1.fields)), &Text::lit(", "))))
        },
    }
}

/// ```prism
/// ShowImpl: unbounded fn TyDef, Text -> Text
/// ```
pub fn show_impl(t_p0: &crate::lower::model::TyDef, head_p1: &Text) -> Text {
    let body_p2 = match &t_p0.shape {
        crate::lower::model::TyShape::ShapeRecord => {
            let c_p3 = or(&index(&t_p0.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            Text::from(format!("p.record(\"{}\", &[{}]);", &t_p0.prism, &crate::syntax::lexer::chars::join(&each(&c_p3.fields, &(|(f_p4, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("(\"{}\", &self.{})", &prism_field(f_p4), f_p4)))), &Text::lit(", "))))
        },
        _ => crate::emit::rust::templates::items::match_self(&crate::syntax::lexer::chars::join(&each(&t_p0.cases, &(|c_p5: &crate::lower::model::CaseDef| Text::from(format!("{} => p.choice(\"{}\", &[{}]),", &case_pattern(t_p0, c_p5), &c_p5.prism, &crate::syntax::lexer::chars::join(&binders(&len(&c_p5.fields)), &Text::lit(", ")))))), &Text::lit("\n"))),
    };
    crate::emit::rust::templates::items::impl_(&bounded(&t_p0.params, &Text::lit("Show")), &Text::lit("Show"), head_p1, &Text::lit("fn show(&self, p: &mut Printer)"), &body_p2)
}

/// The step machine of `ShowImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowImpl: unbounded fn TyDef, Text -> Text
/// ```
pub struct ShowImpl {
    pub t_p0: crate::lower::model::TyDef,
    pub head_p1: Text,
}

impl prism_rtl::Job<Text> for ShowImpl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t_p0 = &self.t_p0;
        let head_p1 = &self.head_p1;
        let body_p2 = match &t_p0.shape {
            crate::lower::model::TyShape::ShapeRecord => {
                let c_p3 = or(&index(&t_p0.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                Text::from(format!("p.record(\"{}\", &[{}]);", &t_p0.prism, &crate::syntax::lexer::chars::join(&each(&c_p3.fields, &(|(f_p4, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("(\"{}\", &self.{})", &prism_field(f_p4), f_p4)))), &Text::lit(", "))))
            },
            _ => crate::emit::rust::templates::items::match_self(&crate::syntax::lexer::chars::join(&each(&t_p0.cases, &(|c_p5: &crate::lower::model::CaseDef| Text::from(format!("{} => p.choice(\"{}\", &[{}]),", &case_pattern(t_p0, c_p5), &c_p5.prism, &crate::syntax::lexer::chars::join(&binders(&len(&c_p5.fields)), &Text::lit(", ")))))), &Text::lit("\n"))),
        };
        prism_rtl::Turn::Finished(crate::emit::rust::templates::items::impl_(&bounded(&t_p0.params, &Text::lit("Show")), &Text::lit("Show"), head_p1, &Text::lit("fn show(&self, p: &mut Printer)"), &body_p2))
    }
}

/// `Start ShowImpl, x`: what the function value is when passed to `@Run`.
pub fn start_show_impl(t_p0: crate::lower::model::TyDef, head_p1: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ShowImpl { t_p0, head_p1 })
}

/// ```prism
/// PrismField: fn Text -> Text
/// ```
pub fn prism_field(f_p0: &Text) -> Text {
    if &crate::syntax::lexer::chars::last_char(f_p0) == &Text::lit("_") {
        crate::syntax::lexer::chars::before_last(f_p0)
    } else {
        f_p0.clone()
    }
}

/// ```prism
/// ToPodImpl: unbounded fn TyDef, Text -> Text
/// ```
pub fn to_pod_impl(t_p0: &crate::lower::model::TyDef, head_p1: &Text) -> Text {
    let body_p2 = match &t_p0.shape {
        crate::lower::model::TyShape::ShapeRecord => {
            let c_p4 = or(&index(&t_p0.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            Text::from(format!("Pod::record(\"{}\", vec![{}])", &t_p0.prism, &crate::syntax::lexer::chars::join(&each(&c_p4.fields, &(|(f_p5, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("(\"{}\", self.{}.to_pod())", &prism_field(f_p5), f_p5)))), &Text::lit(", "))))
        },
        _ => crate::emit::rust::templates::items::match_self(&crate::syntax::lexer::chars::join(&each(&t_p0.cases, &(|c_p6: &crate::lower::model::CaseDef| Text::from(format!("{} => Pod::Choice(\"{}\".into(), vec![{}]),", &case_pattern(t_p0, c_p6), &c_p6.prism, &crate::syntax::lexer::chars::join(&each(&binders(&len(&c_p6.fields)), &(|b_p7: &Text| Text::from(format!("{}.to_pod()", b_p7)))), &Text::lit(", ")))))), &Text::lit("\n"))),
    };
    let shown_p3 = if &t_p0.show == &crate::lower::model::Shown::ShownOwn {
        crate::emit::rust::templates::items::shown_pod(&body_p2)
    } else {
        body_p2.clone()
    };
    crate::emit::rust::templates::items::impl_(&bounded(&t_p0.params, &Text::lit("ToPod")), &Text::lit("ToPod"), head_p1, &Text::lit("fn to_pod(&self) -> Pod"), &shown_p3)
}

/// The step machine of `ToPodImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ToPodImpl: unbounded fn TyDef, Text -> Text
/// ```
pub struct ToPodImpl {
    pub t_p0: crate::lower::model::TyDef,
    pub head_p1: Text,
}

impl prism_rtl::Job<Text> for ToPodImpl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t_p0 = &self.t_p0;
        let head_p1 = &self.head_p1;
        let body_p2 = match &t_p0.shape {
            crate::lower::model::TyShape::ShapeRecord => {
                let c_p4 = or(&index(&t_p0.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                Text::from(format!("Pod::record(\"{}\", vec![{}])", &t_p0.prism, &crate::syntax::lexer::chars::join(&each(&c_p4.fields, &(|(f_p5, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("(\"{}\", self.{}.to_pod())", &prism_field(f_p5), f_p5)))), &Text::lit(", "))))
            },
            _ => crate::emit::rust::templates::items::match_self(&crate::syntax::lexer::chars::join(&each(&t_p0.cases, &(|c_p6: &crate::lower::model::CaseDef| Text::from(format!("{} => Pod::Choice(\"{}\".into(), vec![{}]),", &case_pattern(t_p0, c_p6), &c_p6.prism, &crate::syntax::lexer::chars::join(&each(&binders(&len(&c_p6.fields)), &(|b_p7: &Text| Text::from(format!("{}.to_pod()", b_p7)))), &Text::lit(", ")))))), &Text::lit("\n"))),
        };
        let shown_p3 = if &t_p0.show == &crate::lower::model::Shown::ShownOwn {
            crate::emit::rust::templates::items::shown_pod(&body_p2)
        } else {
            body_p2.clone()
        };
        prism_rtl::Turn::Finished(crate::emit::rust::templates::items::impl_(&bounded(&t_p0.params, &Text::lit("ToPod")), &Text::lit("ToPod"), head_p1, &Text::lit("fn to_pod(&self) -> Pod"), &shown_p3))
    }
}

/// `Start ToPodImpl, x`: what the function value is when passed to `@Run`.
pub fn start_to_pod_impl(t_p0: crate::lower::model::TyDef, head_p1: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ToPodImpl { t_p0, head_p1 })
}

/// ```prism
/// FromPodImpl: unbounded fn TyDef, Text -> Text
/// ```
pub fn from_pod_impl(t_p0: &crate::lower::model::TyDef, head_p1: &Text) -> Text {
    let body_p2 = match &t_p0.shape {
        crate::lower::model::TyShape::ShapeRecord => {
            let c_p3 = or(&index(&t_p0.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            Text::from(format!("Ok({} {{ {} }})", &t_p0.name, &crate::syntax::lexer::chars::join(&each(&c_p3.fields, &(|(f_p4, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{}: FromPod::from_pod(field(p, \"{}\")?)?", f_p4, &prism_field(f_p4))))), &Text::lit(", "))))
        },
        _ => {
            let arms_p5 = each(&t_p0.cases, &(|c_p6: &crate::lower::model::CaseDef| {
                let n_p7 = len(&c_p6.fields);
                let made_p8 = if &n_p7 == &Nat::from(0u32) {
                    if &t_p0.shape == &crate::lower::model::TyShape::ShapeUnit {
                        t_p0.name.clone()
                    } else {
                        Text::from(format!("{}::{}", &t_p0.name, &c_p6.name))
                    }
                } else {
                    Text::from(format!("{}({})", &(if &t_p0.shape == &crate::lower::model::TyShape::ShapeNewtype {
                        t_p0.name.clone()
                    } else {
                        Text::from(format!("{}::{}", &t_p0.name, &c_p6.name))
                    }), &crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&n_p7), &(|i_p9: &Nat| Text::from(format!("FromPod::from_pod(&a[{}])?", i_p9)))), &Text::lit(", "))))
                };
                Text::from(format!("Pod::Choice(c, a) if &**c == \"{}\" && a.len() == {} => Ok({}),", &c_p6.prism, &n_p7, &made_p8))
            }));
            crate::emit::rust::templates::items::from_pod_body(&crate::syntax::lexer::chars::join(&arms_p5, &Text::lit("\n")), &Text::from(format!("a {}", &t_p0.prism)))
        },
    };
    crate::emit::rust::templates::items::impl_(&bounded(&t_p0.params, &Text::lit("FromPod")), &Text::lit("FromPod"), head_p1, &Text::lit("fn from_pod(p: &Pod) -> Result<Self, Fault>"), &body_p2)
}

/// The step machine of `FromPodImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FromPodImpl: unbounded fn TyDef, Text -> Text
/// ```
pub struct FromPodImpl {
    pub t_p0: crate::lower::model::TyDef,
    pub head_p1: Text,
}

impl prism_rtl::Job<Text> for FromPodImpl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t_p0 = &self.t_p0;
        let head_p1 = &self.head_p1;
        let body_p2 = match &t_p0.shape {
            crate::lower::model::TyShape::ShapeRecord => {
                let c_p3 = or(&index(&t_p0.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                Text::from(format!("Ok({} {{ {} }})", &t_p0.name, &crate::syntax::lexer::chars::join(&each(&c_p3.fields, &(|(f_p4, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{}: FromPod::from_pod(field(p, \"{}\")?)?", f_p4, &prism_field(f_p4))))), &Text::lit(", "))))
            },
            _ => {
                let arms_p5 = each(&t_p0.cases, &(|c_p6: &crate::lower::model::CaseDef| {
                    let n_p7 = len(&c_p6.fields);
                    let made_p8 = if &n_p7 == &Nat::from(0u32) {
                        if &t_p0.shape == &crate::lower::model::TyShape::ShapeUnit {
                            t_p0.name.clone()
                        } else {
                            Text::from(format!("{}::{}", &t_p0.name, &c_p6.name))
                        }
                    } else {
                        Text::from(format!("{}({})", &(if &t_p0.shape == &crate::lower::model::TyShape::ShapeNewtype {
                            t_p0.name.clone()
                        } else {
                            Text::from(format!("{}::{}", &t_p0.name, &c_p6.name))
                        }), &crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&n_p7), &(|i_p9: &Nat| Text::from(format!("FromPod::from_pod(&a[{}])?", i_p9)))), &Text::lit(", "))))
                    };
                    Text::from(format!("Pod::Choice(c, a) if &**c == \"{}\" && a.len() == {} => Ok({}),", &c_p6.prism, &n_p7, &made_p8))
                }));
                crate::emit::rust::templates::items::from_pod_body(&crate::syntax::lexer::chars::join(&arms_p5, &Text::lit("\n")), &Text::from(format!("a {}", &t_p0.prism)))
            },
        };
        prism_rtl::Turn::Finished(crate::emit::rust::templates::items::impl_(&bounded(&t_p0.params, &Text::lit("FromPod")), &Text::lit("FromPod"), head_p1, &Text::lit("fn from_pod(p: &Pod) -> Result<Self, Fault>"), &body_p2))
    }
}

/// `Start FromPodImpl, x`: what the function value is when passed to `@Run`.
pub fn start_from_pod_impl(t_p0: crate::lower::model::TyDef, head_p1: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FromPodImpl { t_p0, head_p1 })
}

/// ```prism
/// RustTag: unbounded fn TagDef -> Text
/// ```
pub fn rust_tag(t_p0: &crate::lower::model::TagDef) -> Text {
    let fields_p1 = crate::syntax::lexer::chars::join(&run_to_end(each_job(t_p0.fields.clone(), Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (_, f_pa, ft_pb) = p0;
        call_then(crate::emit::rust::start_type_(ft_pb.clone()), move |type__8893: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &f_pa, &type__8893))))
    }))) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let pods_p2 = crate::syntax::lexer::chars::join(&each(&t_p0.fields, &(|(p_pc, f_pd, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("(\"{}\", self.{}.to_pod())", p_pc, f_pd)))), &Text::lit(", "));
    let derives_p3 = if t_p0.eq { Text::lit("Clone, PartialEq, Eq") } else { Text::lit("Clone") };
    let reads_p4 = crate::syntax::lexer::chars::join(&each(&t_p0.fields, &(|(p_pe, f_pf, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("{}: FromPod::from_pod(field(p, \"{}\")?)?", f_pf, p_pe)))), &Text::lit(", "));
    let back_p5 = if t_p0.pod {
        Text::from(format!("\n{}", &crate::emit::rust::templates::items::tag_from_pod(&t_p0.name, &t_p0.tag_name, &reads_p4)))
    } else {
        Text::lit("")
    };
    let deep_p6 = run_to_end(fold_job(t_p0.fields.clone(), false, Rc::new(move |(p0, p1): (bool, (Text, Text, crate::lower::model::OutTy))| entered(once_job(move || {
        let d_pg = p0;
        let (_, _, ft_ph) = p1;
        prism_rtl::Turn::Finished(d_pg || crate::lower::types::holds_dyn(&ft_ph))
    }))) as Rc<dyn Fn((bool, (Text, Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>));
    let deep_pods_p7 = crate::syntax::lexer::chars::join(&run_to_end(each_job(t_p0.fields.clone(), Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (p_pi, f_pj, ft_pk) = p0;
        prism_rtl::Turn::More(Rc::new(DeepField { p_p0: p_pi.clone(), f_p1: f_pj.clone(), ft_p2: ft_pk.clone() }))
    }))) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "));
    let deep_ports_p8 = concat(&run_to_end(each_job(t_p0.fields.clone(), Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (_, f_pl, ft_pm) = p0;
        prism_rtl::Turn::More(Rc::new(DeepPorts { f_p0: f_pl.clone(), ft_p1: ft_pm.clone() }))
    }))) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)));
    let levels_p9 = if deep_p6 {
        Text::from(format!("\n{}", &crate::emit::rust::templates::items::tag_level(&t_p0.name, &t_p0.tag_name, &deep_pods_p7, &deep_ports_p8)))
    } else {
        Text::lit("")
    };
    Text::from(format!("{}{}{}", &crate::emit::rust::templates::items::tag(&crate::emit::rust::templates::source_doc(&Text::from(format!("The `Level` of `{}`:", &t_p0.tag_name)), &t_p0.doc), &derives_p3, &t_p0.name, &fields_p1, &t_p0.tag_name, &pods_p2), &back_p5, &levels_p9))
}

/// The step machine of `RustTag`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustTag: unbounded fn TagDef -> Text
/// ```
pub struct RustTag {
    pub t_p0: crate::lower::model::TagDef,
}

impl prism_rtl::Job<Text> for RustTag {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t_p0 = &self.t_p0;
        let t_p0 = t_p0.clone();
        call_value(each_job(t_p0.fields.clone(), Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| entered(once_job(move || {
            let (_, f_pa, ft_pb) = p0;
            call_then(crate::emit::rust::start_type_(ft_pb.clone()), move |type__8893: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &f_pa, &type__8893))))
        }))) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_8846: Array<Text>| {
            let fields_p1 = crate::syntax::lexer::chars::join(&each_8846, &Text::lit("\n"));
            let pods_p2 = crate::syntax::lexer::chars::join(&each(&t_p0.fields, &(|(p_pc, f_pd, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("(\"{}\", self.{}.to_pod())", p_pc, f_pd)))), &Text::lit(", "));
            let derives_p3 = if t_p0.eq { Text::lit("Clone, PartialEq, Eq") } else { Text::lit("Clone") };
            let reads_p4 = crate::syntax::lexer::chars::join(&each(&t_p0.fields, &(|(p_pe, f_pf, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("{}: FromPod::from_pod(field(p, \"{}\")?)?", f_pf, p_pe)))), &Text::lit(", "));
            let back_p5 = if t_p0.pod {
                Text::from(format!("\n{}", &crate::emit::rust::templates::items::tag_from_pod(&t_p0.name, &t_p0.tag_name, &reads_p4)))
            } else {
                Text::lit("")
            };
            call_value(fold_job(t_p0.fields.clone(), false, Rc::new(move |(p0, p1): (bool, (Text, Text, crate::lower::model::OutTy))| entered(once_job(move || {
                let d_pg = p0;
                let (_, _, ft_ph) = p1;
                prism_rtl::Turn::Finished(d_pg || crate::lower::types::holds_dyn(&ft_ph))
            }))) as Rc<dyn Fn((bool, (Text, Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>), move |fold_9270: bool| {
                let deep_p6 = fold_9270;
                call_value(each_job(t_p0.fields.clone(), Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| entered(once_job(move || {
                    let (p_pi, f_pj, ft_pk) = p0;
                    prism_rtl::Turn::More(Rc::new(DeepField { p_p0: p_pi.clone(), f_p1: f_pj.clone(), ft_p2: ft_pk.clone() }))
                }))) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_9363: Array<Text>| {
                    let deep_pods_p7 = crate::syntax::lexer::chars::join(&each_9363, &Text::lit(", "));
                    call_value(each_job(t_p0.fields.clone(), Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| entered(once_job(move || {
                        let (_, f_pl, ft_pm) = p0;
                        prism_rtl::Turn::More(Rc::new(DeepPorts { f_p0: f_pl.clone(), ft_p1: ft_pm.clone() }))
                    }))) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_9448: Array<Text>| {
                        let deep_ports_p8 = concat(&each_9448);
                        let levels_p9 = if deep_p6 {
                            Text::from(format!("\n{}", &crate::emit::rust::templates::items::tag_level(&t_p0.name, &t_p0.tag_name, &deep_pods_p7, &deep_ports_p8)))
                        } else {
                            Text::lit("")
                        };
                        prism_rtl::Turn::Finished(Text::from(format!("{}{}{}", &crate::emit::rust::templates::items::tag(&crate::emit::rust::templates::source_doc(&Text::from(format!("The `Level` of `{}`:", &t_p0.tag_name)), &t_p0.doc), &derives_p3, &t_p0.name, &fields_p1, &t_p0.tag_name, &pods_p2), &back_p5, &levels_p9)))
                    })
                })
            })
        })
    }
}

/// `Start RustTag, x`: what the function value is when passed to `@Run`.
pub fn start_rust_tag(t_p0: crate::lower::model::TagDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustTag { t_p0 })
}

/// ```prism
/// DeepField: unbounded fn Text, Text, OutTy -> Text
/// ```
pub fn deep_field(p_p0: &Text, f_p1: &Text, ft_p2: &crate::lower::model::OutTy) -> Text {
    Text::from(format!("(\"{}\", {})", p_p0, &deep_pod(f_p1, ft_p2)))
}

/// The step machine of `DeepField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DeepField: unbounded fn Text, Text, OutTy -> Text
/// ```
pub struct DeepField {
    pub p_p0: Text,
    pub f_p1: Text,
    pub ft_p2: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for DeepField {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let p_p0 = &self.p_p0;
        let f_p1 = &self.f_p1;
        let ft_p2 = &self.ft_p2;
        let f_p1 = f_p1.clone();
        let ft_p2 = ft_p2.clone();
        let p_p0 = p_p0.clone();
        call_then(start_deep_pod(f_p1.clone(), ft_p2.clone()), move |deep_pod_9796: Text| prism_rtl::Turn::Finished(Text::from(format!("(\"{}\", {})", &p_p0, &deep_pod_9796))))
    }
}

/// `Start DeepField, x`: what the function value is when passed to `@Run`.
pub fn start_deep_field(p_p0: Text, f_p1: Text, ft_p2: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(DeepField { p_p0, f_p1, ft_p2 })
}

/// ```prism
/// DeepPod: unbounded fn Text, OutTy -> Text
/// ```
pub fn deep_pod(f_p0: &Text, ft_p1: &crate::lower::model::OutTy) -> Text {
    'm10050: {
        if let crate::lower::model::OutTy::OutMap(_, m10050_0_1) = ft_p1 && let crate::lower::model::OutTy::OutDyn(m10050_0_1_r_0) = &**m10050_0_1 && let crate::lower::model::OutTy::OutNamed(m10050_0_1_r_0_r_0, _) = &**m10050_0_1_r_0 && (m10050_0_1_r_0_r_0 == &Text::lit("crate::Elem")) {
            break 'm10050 Text::from(format!("prism_rtl::dynamics_pod(&self.{}, cx)", f_p0));
        }
        if let crate::lower::model::OutTy::OutDyn(m10050_1_0) = ft_p1 && let crate::lower::model::OutTy::OutNamed(m10050_1_0_r_0, _) = &**m10050_1_0 && (m10050_1_0_r_0 == &Text::lit("crate::Elem")) {
            break 'm10050 Text::from(format!("prism_rtl::Level::level_pod(&self.{}.sample(cx), cx)", f_p0));
        }
        if let other_p2 = ft_p1 {
            break 'm10050 if crate::lower::types::holds_dyn(other_p2) {
                Text::lit("compile_error!(\"prismc: a tag field holding a dynamic other than `$Elem` or a map of them is not read deep (claude/incremental-host-document.md, doubt WD)\")")
            } else {
                Text::from(format!("self.{}.to_pod()", f_p0))
            };
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `DeepPod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DeepPod: unbounded fn Text, OutTy -> Text
/// ```
pub struct DeepPod {
    pub f_p0: Text,
    pub ft_p1: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for DeepPod {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f_p0 = &self.f_p0;
        let ft_p1 = &self.ft_p1;
        'm10050: {
            if let crate::lower::model::OutTy::OutMap(_, m10050_0_1) = ft_p1 && let crate::lower::model::OutTy::OutDyn(m10050_0_1_r_0) = &**m10050_0_1 && let crate::lower::model::OutTy::OutNamed(m10050_0_1_r_0_r_0, _) = &**m10050_0_1_r_0 && (m10050_0_1_r_0_r_0 == &Text::lit("crate::Elem")) {
                break 'm10050 prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::dynamics_pod(&self.{}, cx)", f_p0)));
            }
            if let crate::lower::model::OutTy::OutDyn(m10050_1_0) = ft_p1 && let crate::lower::model::OutTy::OutNamed(m10050_1_0_r_0, _) = &**m10050_1_0 && (m10050_1_0_r_0 == &Text::lit("crate::Elem")) {
                break 'm10050 prism_rtl::Turn::Finished(Text::from(format!("prism_rtl::Level::level_pod(&self.{}.sample(cx), cx)", f_p0)));
            }
            if let other_p2 = ft_p1 {
                break 'm10050 {
                    let f_p0 = f_p0.clone();
                    let other_p2 = other_p2.clone();
                    call_then(crate::lower::types::start_holds_dyn(other_p2.clone()), move |holds_dyn_10278: bool| if holds_dyn_10278 {
                        prism_rtl::Turn::Finished(Text::lit("compile_error!(\"prismc: a tag field holding a dynamic other than `$Elem` or a map of them is not read deep (claude/incremental-host-document.md, doubt WD)\")"))
                    } else {
                        prism_rtl::Turn::Finished(Text::from(format!("self.{}.to_pod()", &f_p0)))
                    })
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start DeepPod, x`: what the function value is when passed to `@Run`.
pub fn start_deep_pod(f_p0: Text, ft_p1: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(DeepPod { f_p0, ft_p1 })
}

/// ```prism
/// DeepPorts: unbounded fn Text, OutTy -> Text
/// ```
pub fn deep_ports(f_p0: &Text, ft_p1: &crate::lower::model::OutTy) -> Text {
    'm10547: {
        if let crate::lower::model::OutTy::OutMap(_, m10547_0_1) = ft_p1 && let crate::lower::model::OutTy::OutDyn(m10547_0_1_r_0) = &**m10547_0_1 && let crate::lower::model::OutTy::OutNamed(m10547_0_1_r_0_r_0, _) = &**m10547_0_1_r_0 && (m10547_0_1_r_0_r_0 == &Text::lit("crate::Elem")) {
            break 'm10547 Text::from(format!("\n        prism_rtl::dynamics_ports(&self.{}, cx, out);", f_p0));
        }
        if let crate::lower::model::OutTy::OutDyn(m10547_1_0) = ft_p1 && let crate::lower::model::OutTy::OutNamed(m10547_1_0_r_0, _) = &**m10547_1_0 && (m10547_1_0_r_0 == &Text::lit("crate::Elem")) {
            break 'm10547 Text::from(format!("\n        out.push(self.{}.updates.clone());\n        prism_rtl::Level::level_ports(&self.{}.sample(cx), cx, out);", f_p0, f_p0));
        }
        Text::lit("")
    }
}

/// The step machine of `DeepPorts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DeepPorts: unbounded fn Text, OutTy -> Text
/// ```
pub struct DeepPorts {
    pub f_p0: Text,
    pub ft_p1: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for DeepPorts {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f_p0 = &self.f_p0;
        let ft_p1 = &self.ft_p1;
        'm10547: {
            if let crate::lower::model::OutTy::OutMap(_, m10547_0_1) = ft_p1 && let crate::lower::model::OutTy::OutDyn(m10547_0_1_r_0) = &**m10547_0_1 && let crate::lower::model::OutTy::OutNamed(m10547_0_1_r_0_r_0, _) = &**m10547_0_1_r_0 && (m10547_0_1_r_0_r_0 == &Text::lit("crate::Elem")) {
                break 'm10547 prism_rtl::Turn::Finished(Text::from(format!("\n        prism_rtl::dynamics_ports(&self.{}, cx, out);", f_p0)));
            }
            if let crate::lower::model::OutTy::OutDyn(m10547_1_0) = ft_p1 && let crate::lower::model::OutTy::OutNamed(m10547_1_0_r_0, _) = &**m10547_1_0 && (m10547_1_0_r_0 == &Text::lit("crate::Elem")) {
                break 'm10547 prism_rtl::Turn::Finished(Text::from(format!("\n        out.push(self.{}.updates.clone());\n        prism_rtl::Level::level_ports(&self.{}.sample(cx), cx, out);", f_p0, f_p0)));
            }
            prism_rtl::Turn::Finished(Text::lit(""))
        }
    }
}

/// `Start DeepPorts, x`: what the function value is when passed to `@Run`.
pub fn start_deep_ports(f_p0: Text, ft_p1: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(DeepPorts { f_p0, ft_p1 })
}

/// ```prism
/// RustRow: unbounded fn RowDef -> Text
/// ```
pub fn rust_row(r_p0: &crate::lower::model::RowDef) -> Text {
    let derives_p1 = if r_p0.eq { Text::lit("Clone, PartialEq, Eq") } else { Text::lit("Clone") };
    let cases_p2 = crate::syntax::lexer::chars::join(&each(&r_p0.cases, &(|(v_pa, st_pb): &(Text, Text)| Text::from(format!("{}({}),", v_pa, st_pb)))), &Text::lit("\n"));
    let pods_p3 = crate::syntax::lexer::chars::join(&each(&r_p0.cases, &(|(v_pc, _): &(Text, Text)| Text::from(format!("{}::{}(x) => x.to_pod(),", &r_p0.name, v_pc)))), &Text::lit("\n"));
    let reads_p4 = crate::syntax::lexer::chars::join(&each(&r_p0.cases, &(|(v_pd, st_pe): &(Text, Text)| Text::from(format!("Some(t) if t == {}::TAG => Ok({}::{}(FromPod::from_pod(p)?)),", st_pe, &r_p0.name, v_pd)))), &Text::lit("\n"));
    let back_p5 = if r_p0.pod {
        Text::from(format!("\n{}", &crate::emit::rust::templates::items::row_from_pod(&r_p0.name, &reads_p4)))
    } else {
        Text::lit("")
    };
    let pods2_p6 = if &len(&r_p0.cases) == &Nat::from(0u32) {
        Text::lit("_ => unreachable!(),")
    } else {
        pods_p3.clone()
    };
    let deep_pods_p7 = concat(&each(&r_p0.deep, &(|v_pf: &Text| Text::from(format!("{}::{}(x) => x.level_pod(cx),\n            ", &r_p0.name, v_pf)))));
    let deep_ports_p8 = concat(&each(&r_p0.deep, &(|v_pg: &Text| Text::from(format!("{}::{}(x) => x.level_ports(cx, out),\n            ", &r_p0.name, v_pg)))));
    let level_p9 = if r_p0.level {
        Text::from(format!("\n{}", &crate::emit::rust::templates::items::row_level(&r_p0.name, &deep_pods_p7, &deep_ports_p8)))
    } else {
        Text::lit("")
    };
    Text::from(format!("{}{}{}", &crate::emit::rust::templates::items::row(&crate::emit::rust::templates::source_doc(&Text::from(format!("`{}`, a row kind\'s values:", &r_p0.prism)), &r_p0.doc), &derives_p1, &r_p0.name, &cases_p2, &pods2_p6), &back_p5, &level_p9))
}

/// The step machine of `RustRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustRow: unbounded fn RowDef -> Text
/// ```
pub struct RustRow {
    pub r_p0: crate::lower::model::RowDef,
}

impl prism_rtl::Job<Text> for RustRow {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let r_p0 = &self.r_p0;
        let derives_p1 = if r_p0.eq { Text::lit("Clone, PartialEq, Eq") } else { Text::lit("Clone") };
        let cases_p2 = crate::syntax::lexer::chars::join(&each(&r_p0.cases, &(|(v_pa, st_pb): &(Text, Text)| Text::from(format!("{}({}),", v_pa, st_pb)))), &Text::lit("\n"));
        let pods_p3 = crate::syntax::lexer::chars::join(&each(&r_p0.cases, &(|(v_pc, _): &(Text, Text)| Text::from(format!("{}::{}(x) => x.to_pod(),", &r_p0.name, v_pc)))), &Text::lit("\n"));
        let reads_p4 = crate::syntax::lexer::chars::join(&each(&r_p0.cases, &(|(v_pd, st_pe): &(Text, Text)| Text::from(format!("Some(t) if t == {}::TAG => Ok({}::{}(FromPod::from_pod(p)?)),", st_pe, &r_p0.name, v_pd)))), &Text::lit("\n"));
        let back_p5 = if r_p0.pod {
            Text::from(format!("\n{}", &crate::emit::rust::templates::items::row_from_pod(&r_p0.name, &reads_p4)))
        } else {
            Text::lit("")
        };
        let pods2_p6 = if &len(&r_p0.cases) == &Nat::from(0u32) {
            Text::lit("_ => unreachable!(),")
        } else {
            pods_p3.clone()
        };
        let deep_pods_p7 = concat(&each(&r_p0.deep, &(|v_pf: &Text| Text::from(format!("{}::{}(x) => x.level_pod(cx),\n            ", &r_p0.name, v_pf)))));
        let deep_ports_p8 = concat(&each(&r_p0.deep, &(|v_pg: &Text| Text::from(format!("{}::{}(x) => x.level_ports(cx, out),\n            ", &r_p0.name, v_pg)))));
        let level_p9 = if r_p0.level {
            Text::from(format!("\n{}", &crate::emit::rust::templates::items::row_level(&r_p0.name, &deep_pods_p7, &deep_ports_p8)))
        } else {
            Text::lit("")
        };
        prism_rtl::Turn::Finished(Text::from(format!("{}{}{}", &crate::emit::rust::templates::items::row(&crate::emit::rust::templates::source_doc(&Text::from(format!("`{}`, a row kind\'s values:", &r_p0.prism)), &r_p0.doc), &derives_p1, &r_p0.name, &cases_p2, &pods2_p6), &back_p5, &level_p9)))
    }
}

/// `Start RustRow, x`: what the function value is when passed to `@Run`.
pub fn start_rust_row(r_p0: crate::lower::model::RowDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustRow { r_p0 })
}

/// ```prism
/// RustAnswer: unbounded fn AnswerDef -> Text
/// ```
pub fn rust_answer(a_p0: &crate::lower::model::AnswerDef) -> Text {
    let cases_p1 = crate::syntax::lexer::chars::join(&run_to_end(each_job(a_p0.cases.clone(), Rc::new(move |p0: crate::lower::model::AnswerCase| entered(once_job(move || {
        let c_p5 = p0;
        call_then(crate::emit::rust::start_type_(c_p5.ty.clone()), move |type__12343: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({}),", &c_p5.variant, &type__12343))))
    }))) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let tags_p2 = if &len(&a_p0.cases) == &Nat::from(0u32) {
        Text::lit("_ => unreachable!(),")
    } else {
        crate::syntax::lexer::chars::join(&each(&a_p0.cases, &(|c_p6: &crate::lower::model::AnswerCase| Text::from(format!("Answer::{}(_) => {}::TAG,", &c_p6.variant, &c_p6.struct_path)))), &Text::lit("\n"))
    };
    let accessors_p3 = crate::syntax::lexer::chars::join(&run_to_end(each_job(a_p0.cases.clone(), Rc::new(move |p0: crate::lower::model::AnswerCase| entered(once_job(move || {
        let c_p7 = p0;
        call_then(crate::emit::rust::start_type_(c_p7.ty.clone()), move |type__12605: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::answer_getter(&c_p7.accessor, &c_p7.variant, &c_p7.tag_name, &type__12605)))
    }))) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let decodes_p4 = if &len(&a_p0.cases) == &Nat::from(0u32) {
        Text::lit("_ => unreachable!(),")
    } else {
        crate::syntax::lexer::chars::join(&run_to_end(each_job(a_p0.cases.clone(), Rc::new(move |p0: crate::lower::model::AnswerCase| entered(once_job(move || {
            let c_p8 = p0;
            call_then(crate::emit::rust::start_decode_head(c_p8.ty.clone()), move |decode_head_12768: Text| prism_rtl::Turn::Finished(Text::from(format!("Elem::{}(..) => Ok(Answer::{}({}::from_pod(v)?)),", &c_p8.variant, &c_p8.variant, &decode_head_12768))))
        }))) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))
    };
    crate::emit::rust::templates::items::answer_type(&cases_p1, &tags_p2, &accessors_p3, &decodes_p4)
}

/// The step machine of `RustAnswer`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustAnswer: unbounded fn AnswerDef -> Text
/// ```
pub struct RustAnswer {
    pub a_p0: crate::lower::model::AnswerDef,
}

impl prism_rtl::Job<Text> for RustAnswer {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let a_p0 = &self.a_p0;
        let a_p0 = a_p0.clone();
        call_value(each_job(a_p0.cases.clone(), Rc::new(move |p0: crate::lower::model::AnswerCase| entered(once_job(move || {
            let c_p5 = p0;
            call_then(crate::emit::rust::start_type_(c_p5.ty.clone()), move |type__12343: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({}),", &c_p5.variant, &type__12343))))
        }))) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_12310: Array<Text>| {
            let cases_p1 = crate::syntax::lexer::chars::join(&each_12310, &Text::lit("\n"));
            let tags_p2 = if &len(&a_p0.cases) == &Nat::from(0u32) {
                Text::lit("_ => unreachable!(),")
            } else {
                crate::syntax::lexer::chars::join(&each(&a_p0.cases, &(|c_p6: &crate::lower::model::AnswerCase| Text::from(format!("Answer::{}(_) => {}::TAG,", &c_p6.variant, &c_p6.struct_path)))), &Text::lit("\n"))
            };
            call_value(each_job(a_p0.cases.clone(), Rc::new(move |p0: crate::lower::model::AnswerCase| entered(once_job(move || {
                let c_p7 = p0;
                call_then(crate::emit::rust::start_type_(c_p7.ty.clone()), move |type__12605: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::answer_getter(&c_p7.accessor, &c_p7.variant, &c_p7.tag_name, &type__12605)))
            }))) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_12538: Array<Text>| {
                let accessors_p3 = crate::syntax::lexer::chars::join(&each_12538, &Text::lit("\n"));
                let decodes_p4 = if &len(&a_p0.cases) == &Nat::from(0u32) {
                    Text::lit("_ => unreachable!(),")
                } else {
                    crate::syntax::lexer::chars::join(&run_to_end(each_job(a_p0.cases.clone(), Rc::new(move |p0: crate::lower::model::AnswerCase| entered(once_job(move || {
                        let c_p8 = p0;
                        call_then(crate::emit::rust::start_decode_head(c_p8.ty.clone()), move |decode_head_12768: Text| prism_rtl::Turn::Finished(Text::from(format!("Elem::{}(..) => Ok(Answer::{}({}::from_pod(v)?)),", &c_p8.variant, &c_p8.variant, &decode_head_12768))))
                    }))) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))
                };
                prism_rtl::Turn::Finished(crate::emit::rust::templates::items::answer_type(&cases_p1, &tags_p2, &accessors_p3, &decodes_p4))
            })
        })
    }
}

/// `Start RustAnswer, x`: what the function value is when passed to `@Run`.
pub fn start_rust_answer(a_p0: crate::lower::model::AnswerDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustAnswer { a_p0 })
}

/// ```prism
/// RustNode: unbounded fn NodeDef -> Text
/// ```
pub fn rust_node(n_p0: &crate::lower::model::NodeDef) -> Text {
    let fields_p1 = crate::syntax::lexer::chars::join(&run_to_end(each_job(n_p0.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy, Text)| entered(once_job(move || {
        let (f_pf, t_pg, doc_ph) = p0;
        call_then(crate::emit::rust::start_type_(t_pg.clone()), move |type__13185: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}: {},", &crate::emit::rust::templates::doc(&doc_ph), &f_pf, &type__13185))))
    }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let consts_p2 = concat(&each(&n_p0.consts, &(|(c_pi, h_pj, doc_pk): &(Text, Nat, Text)| Text::from(format!("{}const {}: u32 = {};\n", &crate::emit::rust::templates::doc(&Text::from(format!("The {}.", doc_pk))), c_pi, h_pj)))));
    let params_p3 = concat(&run_to_end(each_job(n_p0.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (p_pl, t_pm) = p0;
        call_then(crate::emit::rust::start_type_(t_pm.clone()), move |type__13363: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}, ", &p_pl, &type__13363))))
    }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)));
    let ret_p4 = if n_p0.fallible {
        Text::from(format!("Result<Rc<{}>, Fault>", &n_p0.name))
    } else {
        Text::from(format!("Rc<{}>", &n_p0.name))
    };
    let inits_p5 = crate::syntax::lexer::chars::join(&append(&Array::from(vec![Text::lit("path")]), &run_to_end(each_job(n_p0.inits.clone(), Rc::new(move |p0: (Text, crate::lower::model::Ex)| entered(once_job(move || {
        let (f_pn, v_po) = p0;
        prism_rtl::Turn::More(Rc::new(crate::emit::rust::FieldInit { f_p0: f_pn.clone(), ex1: v_po.clone() }))
    }))) as Rc<dyn Fn((Text, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>))), &Text::lit(", "));
    let tail_p6 = if n_p0.fallible { Text::lit("Ok(node)") } else { Text::lit("node") };
    let rest_text_p7 = if &len(&n_p0.build) == &Nat::from(0u32) {
        tail_p6.clone()
    } else {
        Text::from(format!("{}\n{}", &crate::emit::rust::statements(&n_p0.build), &tail_p6))
    };
    let build_p8 = crate::emit::rust::templates::items::build(&n_p0.name, &params_p3, &ret_p4, &crate::emit::rust::statements(&n_p0.lets), &inits_p5, &rest_text_p7);
    let methods_p9 = crate::syntax::lexer::chars::join(&run_to_end(each_job(n_p0.methods.clone(), Rc::new(move |p0: crate::lower::model::MethDef| entered(once_job(move || {
        let m_pp = p0;
        prism_rtl::Turn::More(Rc::new(RustMethod { m_p0: m_pp.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let answer_pa = if &len(&n_p0.answers) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        crate::emit::rust::templates::items::answer(&crate::syntax::lexer::chars::join(&run_to_end(each_job(n_p0.answers.clone(), Rc::new(move |p0: (crate::lower::model::Pa, crate::lower::model::Ex)| entered(once_job(move || {
            let (pat_pq, call_pr) = p0;
            call_then(crate::emit::rust::start_pattern(pat_pq.clone()), move |pattern_13929: Text| call_then(crate::emit::rust::start_expression(call_pr.clone()), move |expression_13946: Text| prism_rtl::Turn::Finished(Text::from(format!("{} => {},", &pattern_13929, &expression_13946)))))
        }))) as Rc<dyn Fn((crate::lower::model::Pa, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n")))
    };
    let builders_pb = concat(&append(&run_to_end(each_job(n_p0.builders.clone(), Rc::new(move |p0: crate::lower::model::ForDef| entered(once_job(move || {
        let b_ps = p0;
        call_then(start_for_builder(b_ps.clone()), move |for_builder_14034: Text| prism_rtl::Turn::Finished(Text::from(format!("\n{}", &for_builder_14034))))
    }))) as Rc<dyn Fn(crate::lower::model::ForDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &run_to_end(each_job(n_p0.gens.clone(), Rc::new(move |p0: crate::lower::model::GenDef| entered(once_job(move || {
        let gd_pt = p0;
        call_then(start_gen_builder(gd_pt.clone()), move |gen_builder_14075: Text| prism_rtl::Turn::Finished(Text::from(format!("\n{}", &gen_builder_14075))))
    }))) as Rc<dyn Fn(crate::lower::model::GenDef) -> Rc<dyn prism_rtl::Job<Text>>>))));
    let row_impl_pc = if &n_p0.row_kind == &crate::lower::model::RowKind::NotARow {
        Text::lit("")
    } else {
        Text::from(format!("\n{}", &rust_row_impl(n_p0)))
    };
    let hooks_pd = crate::syntax::lexer::chars::join(&run_to_end(each_job(n_p0.hooks.clone(), Rc::new(move |p0: (Text, Array<crate::lower::model::Do>)| entered(once_job(move || {
        let (h_pu, body_pv) = p0;
        if &h_pu == &Text::lit("push") {
            call_then(crate::emit::rust::start_statements(body_pv.clone()), move |statements_14242: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::push_hook(&statements_14242)))
        } else {
            call_then(crate::emit::rust::start_statements(body_pv.clone()), move |statements_14274: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::hook(&h_pu, &statements_14274)))
        }
    }))) as Rc<dyn Fn((Text, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let doc_pe = crate::emit::rust::templates::source_doc(&Text::from(format!("`{}`: a node of its own (claude/backend.md, \"A widget block\").", &n_p0.prism)), &n_p0.doc);
    Text::from(format!("{}{}", &crate::emit::rust::templates::items::node_(&doc_pe, &n_p0.name, &fields_p1, &consts_p2, &build_p8, &Text::from(format!("{}{}", &methods_p9, &builders_pb)), &hooks_pd, &answer_pa), &row_impl_pc))
}

/// The step machine of `RustNode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustNode: unbounded fn NodeDef -> Text
/// ```
pub struct RustNode {
    pub n_p0: crate::lower::model::NodeDef,
}

impl prism_rtl::Job<Text> for RustNode {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let n_p0 = &self.n_p0;
        let n_p0 = n_p0.clone();
        call_value(each_job(n_p0.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy, Text)| entered(once_job(move || {
            let (f_pf, t_pg, doc_ph) = p0;
            call_then(crate::emit::rust::start_type_(t_pg.clone()), move |type__13185: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}: {},", &crate::emit::rust::templates::doc(&doc_ph), &f_pf, &type__13185))))
        }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_13137: Array<Text>| {
            let fields_p1 = crate::syntax::lexer::chars::join(&each_13137, &Text::lit("\n"));
            let consts_p2 = concat(&each(&n_p0.consts, &(|(c_pi, h_pj, doc_pk): &(Text, Nat, Text)| Text::from(format!("{}const {}: u32 = {};\n", &crate::emit::rust::templates::doc(&Text::from(format!("The {}.", doc_pk))), c_pi, h_pj)))));
            call_value(each_job(n_p0.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
                let (p_pl, t_pm) = p0;
                call_then(crate::emit::rust::start_type_(t_pm.clone()), move |type__13363: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}, ", &p_pl, &type__13363))))
            }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_13329: Array<Text>| {
                let params_p3 = concat(&each_13329);
                let ret_p4 = if n_p0.fallible {
                    Text::from(format!("Result<Rc<{}>, Fault>", &n_p0.name))
                } else {
                    Text::from(format!("Rc<{}>", &n_p0.name))
                };
                call_value(each_job(n_p0.inits.clone(), Rc::new(move |p0: (Text, crate::lower::model::Ex)| entered(once_job(move || {
                    let (f_pn, v_po) = p0;
                    prism_rtl::Turn::More(Rc::new(crate::emit::rust::FieldInit { f_p0: f_pn.clone(), ex1: v_po.clone() }))
                }))) as Rc<dyn Fn((Text, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_13497: Array<Text>| {
                    let inits_p5 = crate::syntax::lexer::chars::join(&append(&Array::from(vec![Text::lit("path")]), &each_13497), &Text::lit(", "));
                    let tail_p6 = if n_p0.fallible { Text::lit("Ok(node)") } else { Text::lit("node") };
                    let rest_text_p7 = if &len(&n_p0.build) == &Nat::from(0u32) {
                        tail_p6.clone()
                    } else {
                        Text::from(format!("{}\n{}", &crate::emit::rust::statements(&n_p0.build), &tail_p6))
                    };
                    call_then(crate::emit::rust::start_statements(n_p0.lets.clone()), move |statements_13728: Text| {
                        let build_p8 = crate::emit::rust::templates::items::build(&n_p0.name, &params_p3, &ret_p4, &statements_13728, &inits_p5, &rest_text_p7);
                        call_value(each_job(n_p0.methods.clone(), Rc::new(move |p0: crate::lower::model::MethDef| entered(once_job(move || {
                            let m_pp = p0;
                            prism_rtl::Turn::More(Rc::new(RustMethod { m_p0: m_pp.clone() }))
                        }))) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_13788: Array<Text>| {
                            let methods_p9 = crate::syntax::lexer::chars::join(&each_13788, &Text::lit("\n"));
                            let answer_pa = if &len(&n_p0.answers) == &Nat::from(0u32) {
                                Text::lit("")
                            } else {
                                crate::emit::rust::templates::items::answer(&crate::syntax::lexer::chars::join(&run_to_end(each_job(n_p0.answers.clone(), Rc::new(move |p0: (crate::lower::model::Pa, crate::lower::model::Ex)| entered(once_job(move || {
                                    let (pat_pq, call_pr) = p0;
                                    call_then(crate::emit::rust::start_pattern(pat_pq.clone()), move |pattern_13929: Text| call_then(crate::emit::rust::start_expression(call_pr.clone()), move |expression_13946: Text| prism_rtl::Turn::Finished(Text::from(format!("{} => {},", &pattern_13929, &expression_13946)))))
                                }))) as Rc<dyn Fn((crate::lower::model::Pa, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n")))
                            };
                            call_value(each_job(n_p0.builders.clone(), Rc::new(move |p0: crate::lower::model::ForDef| entered(once_job(move || {
                                let b_ps = p0;
                                call_then(start_for_builder(b_ps.clone()), move |for_builder_14034: Text| prism_rtl::Turn::Finished(Text::from(format!("\n{}", &for_builder_14034))))
                            }))) as Rc<dyn Fn(crate::lower::model::ForDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_14008: Array<Text>| call_value(each_job(n_p0.gens.clone(), Rc::new(move |p0: crate::lower::model::GenDef| entered(once_job(move || {
                                let gd_pt = p0;
                                call_then(start_gen_builder(gd_pt.clone()), move |gen_builder_14075: Text| prism_rtl::Turn::Finished(Text::from(format!("\n{}", &gen_builder_14075))))
                            }))) as Rc<dyn Fn(crate::lower::model::GenDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_14052: Array<Text>| {
                                let builders_pb = concat(&append(&each_14008, &each_14052));
                                let row_impl_pc = if &n_p0.row_kind == &crate::lower::model::RowKind::NotARow {
                                    Text::lit("")
                                } else {
                                    Text::from(format!("\n{}", &rust_row_impl(&n_p0)))
                                };
                                call_value(each_job(n_p0.hooks.clone(), Rc::new(move |p0: (Text, Array<crate::lower::model::Do>)| entered(once_job(move || {
                                    let (h_pu, body_pv) = p0;
                                    if &h_pu == &Text::lit("push") {
                                        call_then(crate::emit::rust::start_statements(body_pv.clone()), move |statements_14242: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::push_hook(&statements_14242)))
                                    } else {
                                        call_then(crate::emit::rust::start_statements(body_pv.clone()), move |statements_14274: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::hook(&h_pu, &statements_14274)))
                                    }
                                }))) as Rc<dyn Fn((Text, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_14187: Array<Text>| {
                                    let hooks_pd = crate::syntax::lexer::chars::join(&each_14187, &Text::lit("\n"));
                                    let doc_pe = crate::emit::rust::templates::source_doc(&Text::from(format!("`{}`: a node of its own (claude/backend.md, \"A widget block\").", &n_p0.prism)), &n_p0.doc);
                                    prism_rtl::Turn::Finished(Text::from(format!("{}{}", &crate::emit::rust::templates::items::node_(&doc_pe, &n_p0.name, &fields_p1, &consts_p2, &build_p8, &Text::from(format!("{}{}", &methods_p9, &builders_pb)), &hooks_pd, &answer_pa), &row_impl_pc)))
                                })
                            }))
                        })
                    })
                })
            })
        })
    }
}

/// `Start RustNode, x`: what the function value is when passed to `@Run`.
pub fn start_rust_node(n_p0: crate::lower::model::NodeDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustNode { n_p0 })
}

/// ```prism
/// ForBuilder: unbounded fn ForDef -> Text
/// ```
pub fn for_builder(b_p0: &crate::lower::model::ForDef) -> Text {
    crate::emit::rust::templates::items::for_build(&b_p0.name, &crate::emit::rust::expression(&b_p0.at), &crate::emit::rust::type_(&b_p0.key_ty), &crate::emit::rust::type_(&b_p0.value_ty), &b_p0.row_node, &b_p0.source, &crate::emit::rust::expression(&b_p0.parent), &concat(&run_to_end(each_job(b_p0.passed.clone(), Rc::new(move |p0: crate::lower::model::Ex| entered(once_job(move || {
        let x_p1 = p0;
        call_then(crate::emit::rust::start_expression(x_p1.clone()), move |expression_14767: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}", &expression_14767))))
    }))) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>))), &moved_call(&b_p0.name, &b_p0.moved), &from_kept(&b_p0.name, &b_p0.replaced), &replaced_call(&b_p0.replaced))
}

/// The step machine of `ForBuilder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ForBuilder: unbounded fn ForDef -> Text
/// ```
pub struct ForBuilder {
    pub b_p0: crate::lower::model::ForDef,
}

impl prism_rtl::Job<Text> for ForBuilder {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let b_p0 = &self.b_p0;
        let b_p0 = b_p0.clone();
        call_then(crate::emit::rust::start_expression(b_p0.at.clone()), move |expression_14638: Text| call_then(crate::emit::rust::start_type_(b_p0.key_ty.clone()), move |type__14657: Text| call_then(crate::emit::rust::start_type_(b_p0.value_ty.clone()), move |type__14673: Text| call_then(crate::emit::rust::start_expression(b_p0.parent.clone()), move |expression_14712: Text| call_value(each_job(b_p0.passed.clone(), Rc::new(move |p0: crate::lower::model::Ex| entered(once_job(move || {
            let x_p1 = p0;
            call_then(crate::emit::rust::start_expression(x_p1.clone()), move |expression_14767: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}", &expression_14767))))
        }))) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_14743: Array<Text>| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::for_build(&b_p0.name, &expression_14638, &type__14657, &type__14673, &b_p0.row_node, &b_p0.source, &expression_14712, &concat(&each_14743), &moved_call(&b_p0.name, &b_p0.moved), &from_kept(&b_p0.name, &b_p0.replaced), &replaced_call(&b_p0.replaced))))))))
    }
}

/// `Start ForBuilder, x`: what the function value is when passed to `@Run`.
pub fn start_for_builder(b_p0: crate::lower::model::ForDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ForBuilder { b_p0 })
}

/// ```prism
/// FromKept: fn Text, [Text] -> Text
/// ```
pub fn from_kept(name_p0: &Text, replaced_p1: &Array<Text>) -> Text {
    if &len(replaced_p1) == &Nat::from(0u32) {
        Text::from(format!("*self.{}_from.borrow_mut() = items.clone();", name_p0))
    } else {
        Text::from(format!("let from = std::mem::replace(&mut *self.{}_from.borrow_mut(), items.clone());", name_p0))
    }
}

/// ```prism
/// ReplacedCall: fn [Text] -> Text
/// ```
pub fn replaced_call(replaced_p0: &Array<Text>) -> Text {
    if &len(replaced_p0) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" else if from.get(k) != items.get(k) {{\n            // the dynamic under a kept key was replaced: that row follows it from the next tick\n{}        }}", &concat(&each(replaced_p0, &(|m_p1: &Text| Text::from(format!("            row.{}(cx);\n", m_p1)))))))
    }
}

/// ```prism
/// MovedCall: fn Text, Text -> Text
/// ```
pub fn moved_call(name_p0: &Text, m_p1: &Text) -> Text {
    if m_p1 == &Text::lit("") {
        Text::lit("")
    } else {
        Text::from(format!("\n    // the places of the host\'s child came or went: its document\'s outer moves\n    if !prism_rtl::same_keys(&self.{}.borrow(), &old) {{\n        self.{}(cx);\n    }}", name_p0, m_p1))
    }
}

/// ```prism
/// GenMovedCall: fn Text -> Text
/// ```
pub fn gen_moved_call(m_p0: &Text) -> Text {
    if m_p0 == &Text::lit("") {
        Text::lit("")
    } else {
        Text::from(format!("\n    // the places of the host\'s child came or went: its document\'s outer moves\n    self.{}(cx);", m_p0))
    }
}

/// ```prism
/// GenBuilder: unbounded fn GenDef -> Text
/// ```
pub fn gen_builder(gd_p0: &crate::lower::model::GenDef) -> Text {
    let path_p1 = if gd_p0.transparent {
        Text::lit("self.path.clone()")
    } else {
        Text::from(format!("{}.child(Segment::Gen(g))", &crate::emit::rust::expression(&gd_p0.at)))
    };
    crate::emit::rust::templates::items::gen_build(&gd_p0.name, &crate::emit::rust::expression(&gd_p0.at), &path_p1, &crate::emit::rust::expression(&gd_p0.source), &crate::emit::rust::type_(&gd_p0.value_ty), &crate::emit::rust::expression(&gd_p0.select), &gen_moved_call(&gd_p0.moved))
}

/// The step machine of `GenBuilder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GenBuilder: unbounded fn GenDef -> Text
/// ```
pub struct GenBuilder {
    pub gd_p0: crate::lower::model::GenDef,
}

impl prism_rtl::Job<Text> for GenBuilder {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let gd_p0 = &self.gd_p0;
        let path_p1 = if gd_p0.transparent {
            Text::lit("self.path.clone()")
        } else {
            Text::from(format!("{}.child(Segment::Gen(g))", &crate::emit::rust::expression(&gd_p0.at)))
        };
        let gd_p0 = gd_p0.clone();
        call_then(crate::emit::rust::start_expression(gd_p0.at.clone()), move |expression_16754: Text| call_then(crate::emit::rust::start_expression(gd_p0.source.clone()), move |expression_16780: Text| call_then(crate::emit::rust::start_type_(gd_p0.value_ty.clone()), move |type__16804: Text| call_then(crate::emit::rust::start_expression(gd_p0.select.clone()), move |expression_16823: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::gen_build(&gd_p0.name, &expression_16754, &path_p1, &expression_16780, &type__16804, &expression_16823, &gen_moved_call(&gd_p0.moved)))))))
    }
}

/// `Start GenBuilder, x`: what the function value is when passed to `@Run`.
pub fn start_gen_builder(gd_p0: crate::lower::model::GenDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(GenBuilder { gd_p0 })
}

/// ```prism
/// RustRowImpl: unbounded fn NodeDef -> Text
/// ```
pub fn rust_row_impl(n_p0: &crate::lower::model::NodeDef) -> Text {
    let kept_p1 = if &n_p0.row_kind == &crate::lower::model::RowKind::ForRow {
        Array::from(vec![Text::lit("*self.left_entry.borrow_mut() = Some(self.entry(cx));")])
    } else {
        Array::new()
    };
    let unsubscribe_p2 = each(&n_p0.subs, &(|(ev_p3, m_p4, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("if let (Some(p), Some(h)) = (self.parent.upgrade(), self.{}_sub.take()) {{\n    p.{}_port.unsubscribe(h);\n}}", m_p4, ev_p3))));
    crate::emit::rust::templates::items::row_impl(&n_p0.name, &crate::syntax::lexer::chars::join(&append(&push(&kept_p1, &Text::lit("self.remove_places(cx);")), &unsubscribe_p2), &Text::lit("\n")), &crate::syntax::lexer::chars::join(&run_to_end(each_job(n_p0.hosted.clone(), Rc::new(move |p0: crate::lower::model::MethDef| entered(once_job(move || {
        let m_p5 = p0;
        prism_rtl::Turn::More(Rc::new(RustMethod { m_p0: m_p5.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n")))
}

/// The step machine of `RustRowImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustRowImpl: unbounded fn NodeDef -> Text
/// ```
pub struct RustRowImpl {
    pub n_p0: crate::lower::model::NodeDef,
}

impl prism_rtl::Job<Text> for RustRowImpl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let n_p0 = &self.n_p0;
        let kept_p1 = if &n_p0.row_kind == &crate::lower::model::RowKind::ForRow {
            Array::from(vec![Text::lit("*self.left_entry.borrow_mut() = Some(self.entry(cx));")])
        } else {
            Array::new()
        };
        let unsubscribe_p2 = each(&n_p0.subs, &(|(ev_p3, m_p4, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("if let (Some(p), Some(h)) = (self.parent.upgrade(), self.{}_sub.take()) {{\n    p.{}_port.unsubscribe(h);\n}}", m_p4, ev_p3))));
        let n_p0 = n_p0.clone();
        call_value(each_job(n_p0.hosted.clone(), Rc::new(move |p0: crate::lower::model::MethDef| entered(once_job(move || {
            let m_p5 = p0;
            prism_rtl::Turn::More(Rc::new(RustMethod { m_p0: m_p5.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_17546: Array<Text>| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::row_impl(&n_p0.name, &crate::syntax::lexer::chars::join(&append(&push(&kept_p1, &Text::lit("self.remove_places(cx);")), &unsubscribe_p2), &Text::lit("\n")), &crate::syntax::lexer::chars::join(&each_17546, &Text::lit("\n")))))
    }
}

/// `Start RustRowImpl, x`: what the function value is when passed to `@Run`.
pub fn start_rust_row_impl(n_p0: crate::lower::model::NodeDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustRowImpl { n_p0 })
}

/// ```prism
/// RustMethod: unbounded fn MethDef -> Text
/// ```
pub fn rust_method(m_p0: &crate::lower::model::MethDef) -> Text {
    let recv_p1 = match &m_p0.recv {
        crate::lower::model::Recv::RecvRc => Text::lit("self: &Rc<Self>"),
        crate::lower::model::Recv::RecvRef => Text::lit("&self"),
        crate::lower::model::Recv::RecvOwned => Text::lit("self: Rc<Self>"),
    };
    let cx_p2 = match &m_p0.cx_ {
        crate::lower::model::CxArg::CxMut => Text::lit(", cx: &mut Cx"),
        crate::lower::model::CxArg::CxRef => Text::lit(", cx: &Cx"),
        crate::lower::model::CxArg::CxNone => Text::lit(""),
    };
    let params_p3 = concat(&run_to_end(each_job(m_p0.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (p_p7, t_p8) = p0;
        call_then(crate::emit::rust::start_type_(t_p8.clone()), move |type__17933: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}: {}", &p_p7, &type__17933))))
    }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)));
    let ret_p4 = if &m_p0.ret == &crate::lower::model::OutTy::OutUnit {
        Text::lit("")
    } else {
        Text::from(format!(" -> {}", &crate::emit::rust::type_(&m_p0.ret)))
    };
    let sig_p5 = Text::from(format!("fn {}({}{}{}){}", &m_p0.name, &recv_p1, &params_p3, &cx_p2, &ret_p4));
    let body_p6 = if &m_p0.ret == &crate::lower::model::OutTy::OutUnit {
        crate::emit::rust::statements(&m_p0.body)
    } else {
        if &len(&m_p0.body) == &Nat::from(0u32) {
            crate::emit::rust::body_lines(&m_p0.tail)
        } else {
            Text::from(format!("{}\n{}", &crate::emit::rust::statements(&m_p0.body), &crate::emit::rust::body_lines(&m_p0.tail)))
        }
    };
    crate::emit::rust::templates::items::method(&crate::emit::rust::templates::doc(&m_p0.doc), &sig_p5, &body_p6)
}

/// The step machine of `RustMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustMethod: unbounded fn MethDef -> Text
/// ```
pub struct RustMethod {
    pub m_p0: crate::lower::model::MethDef,
}

impl prism_rtl::Job<Text> for RustMethod {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let m_p0 = &self.m_p0;
        let recv_p1 = match &m_p0.recv {
            crate::lower::model::Recv::RecvRc => Text::lit("self: &Rc<Self>"),
            crate::lower::model::Recv::RecvRef => Text::lit("&self"),
            crate::lower::model::Recv::RecvOwned => Text::lit("self: Rc<Self>"),
        };
        let cx_p2 = match &m_p0.cx_ {
            crate::lower::model::CxArg::CxMut => Text::lit(", cx: &mut Cx"),
            crate::lower::model::CxArg::CxRef => Text::lit(", cx: &Cx"),
            crate::lower::model::CxArg::CxNone => Text::lit(""),
        };
        let m_p0 = m_p0.clone();
        call_value(each_job(m_p0.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
            let (p_p7, t_p8) = p0;
            call_then(crate::emit::rust::start_type_(t_p8.clone()), move |type__17933: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}: {}", &p_p7, &type__17933))))
        }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_17897: Array<Text>| {
            let params_p3 = concat(&each_17897);
            let ret_p4 = if &m_p0.ret == &crate::lower::model::OutTy::OutUnit {
                Text::lit("")
            } else {
                Text::from(format!(" -> {}", &crate::emit::rust::type_(&m_p0.ret)))
            };
            let sig_p5 = Text::from(format!("fn {}({}{}{}){}", &m_p0.name, &recv_p1, &params_p3, &cx_p2, &ret_p4));
            let body_p6 = if &m_p0.ret == &crate::lower::model::OutTy::OutUnit {
                crate::emit::rust::statements(&m_p0.body)
            } else {
                if &len(&m_p0.body) == &Nat::from(0u32) {
                    crate::emit::rust::body_lines(&m_p0.tail)
                } else {
                    Text::from(format!("{}\n{}", &crate::emit::rust::statements(&m_p0.body), &crate::emit::rust::body_lines(&m_p0.tail)))
                }
            };
            prism_rtl::Turn::Finished(crate::emit::rust::templates::items::method(&crate::emit::rust::templates::doc(&m_p0.doc), &sig_p5, &body_p6))
        })
    }
}

/// `Start RustMethod, x`: what the function value is when passed to `@Run`.
pub fn start_rust_method(m_p0: crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustMethod { m_p0 })
}

/// ```prism
/// RustProgram: unbounded fn ProgDef, Bool -> Text
/// ```
pub fn rust_program(p_p0: &crate::lower::model::ProgDef, fallible_p1: &bool) -> Text {
    let n_p2 = len(&p_p0.params);
    let names_p3 = each(&p_p0.params, &(|(a_p6, _): &(Text, crate::lower::model::OutTy)| a_p6.clone()));
    let decode_p4 = if &n_p2 == &Nat::from(0u32) {
        Text::lit("let _ = args;")
    } else {
        decode_args(p_p0, &names_p3)
    };
    let call_p5 = Text::from(format!("{}::build(Path::root(), {}&mut cx){}", &p_p0.node_, &concat(&each(&names_p3, &(|a_p7: &Text| Text::from(format!("{}, ", a_p7))))), &(if *fallible_p1 { Text::lit("?") } else { Text::lit("") })));
    crate::emit::rust::templates::items::program(&p_p0.name, &p_p0.prism, &p_p0.node_, &decode_p4, &call_p5)
}

/// The step machine of `RustProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustProgram: unbounded fn ProgDef, Bool -> Text
/// ```
pub struct RustProgram {
    pub p_p0: crate::lower::model::ProgDef,
    pub fallible_p1: bool,
}

impl prism_rtl::Job<Text> for RustProgram {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let p_p0 = &self.p_p0;
        let fallible_p1 = &self.fallible_p1;
        let n_p2 = len(&p_p0.params);
        let names_p3 = each(&p_p0.params, &(|(a_p6, _): &(Text, crate::lower::model::OutTy)| a_p6.clone()));
        let decode_p4 = if &n_p2 == &Nat::from(0u32) {
            Text::lit("let _ = args;")
        } else {
            decode_args(p_p0, &names_p3)
        };
        let call_p5 = Text::from(format!("{}::build(Path::root(), {}&mut cx){}", &p_p0.node_, &concat(&each(&names_p3, &(|a_p7: &Text| Text::from(format!("{}, ", a_p7))))), &(if *fallible_p1 { Text::lit("?") } else { Text::lit("") })));
        prism_rtl::Turn::Finished(crate::emit::rust::templates::items::program(&p_p0.name, &p_p0.prism, &p_p0.node_, &decode_p4, &call_p5))
    }
}

/// `Start RustProgram, x`: what the function value is when passed to `@Run`.
pub fn start_rust_program(p_p0: crate::lower::model::ProgDef, fallible_p1: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustProgram { p_p0, fallible_p1 })
}

/// ```prism
/// DecodeArgs: unbounded fn ProgDef, [Text] -> Text
/// ```
pub fn decode_args(p_p0: &crate::lower::model::ProgDef, names_p1: &Array<Text>) -> Text {
    let n_p2 = len(names_p1);
    let plural_p3 = if &n_p2 == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") };
    let head_p4 = Text::from(format!("let [{}] = args else {{ return Err(Fault::answer(\"@{} takes {} argument{}\")) }};", &crate::syntax::lexer::chars::join(names_p1, &Text::lit(", ")), &p_p0.prism, &n_p2, &plural_p3));
    crate::syntax::lexer::chars::join(&append(&Array::from(vec![head_p4.clone()]), &run_to_end(each_job(p_p0.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (a_p5, t_p6) = p0;
        call_then(crate::emit::rust::start_decode_head(t_p6.clone()), move |decode_head_18964: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {}::from_pod({})?;", &a_p5, &decode_head_18964, &a_p5))))
    }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>))), &Text::lit("\n"))
}

/// The step machine of `DecodeArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DecodeArgs: unbounded fn ProgDef, [Text] -> Text
/// ```
pub struct DecodeArgs {
    pub p_p0: crate::lower::model::ProgDef,
    pub names_p1: Array<Text>,
}

impl prism_rtl::Job<Text> for DecodeArgs {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let p_p0 = &self.p_p0;
        let names_p1 = &self.names_p1;
        let n_p2 = len(names_p1);
        let plural_p3 = if &n_p2 == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") };
        let head_p4 = Text::from(format!("let [{}] = args else {{ return Err(Fault::answer(\"@{} takes {} argument{}\")) }};", &crate::syntax::lexer::chars::join(names_p1, &Text::lit(", ")), &p_p0.prism, &n_p2, &plural_p3));
        let p_p0 = p_p0.clone();
        call_value(each_job(p_p0.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
            let (a_p5, t_p6) = p0;
            call_then(crate::emit::rust::start_decode_head(t_p6.clone()), move |decode_head_18964: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {}::from_pod({})?;", &a_p5, &decode_head_18964, &a_p5))))
        }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_18925: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&append(&Array::from(vec![head_p4.clone()]), &each_18925), &Text::lit("\n"))))
    }
}

/// `Start DecodeArgs, x`: what the function value is when passed to `@Run`.
pub fn start_decode_args(p_p0: crate::lower::model::ProgDef, names_p1: Array<Text>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(DecodeArgs { p_p0, names_p1 })
}

/// ```prism
/// RustModule: unbounded fn ModDef, Text -> Text
/// ```
pub fn rust_module(m_p0: &crate::lower::model::ModDef, kids_p1: &Text) -> Text {
    crate::emit::rust::templates::module(&(if &m_p0.prism == &Text::lit("") {
        Text::lit("The root module")
    } else {
        Text::from(format!("The module `{}`", &m_p0.prism))
    }), &m_p0.path_, kids_p1, &crate::syntax::lexer::chars::join(&run_to_end(each_job(m_p0.items.clone(), Rc::new(move |p0: crate::lower::model::Item| entered(once_job(move || {
        let it_p2 = p0;
        prism_rtl::Turn::More(Rc::new(RustItem { it_p0: it_p2.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::Item) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n")))
}

/// The step machine of `RustModule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustModule: unbounded fn ModDef, Text -> Text
/// ```
pub struct RustModule {
    pub m_p0: crate::lower::model::ModDef,
    pub kids_p1: Text,
}

impl prism_rtl::Job<Text> for RustModule {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let m_p0 = &self.m_p0;
        let kids_p1 = &self.kids_p1;
        let kids_p1 = kids_p1.clone();
        let m_p0 = m_p0.clone();
        call_value(each_job(m_p0.items.clone(), Rc::new(move |p0: crate::lower::model::Item| entered(once_job(move || {
            let it_p2 = p0;
            prism_rtl::Turn::More(Rc::new(RustItem { it_p0: it_p2.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Item) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_19537: Array<Text>| prism_rtl::Turn::Finished(crate::emit::rust::templates::module(&(if &m_p0.prism == &Text::lit("") {
            Text::lit("The root module")
        } else {
            Text::from(format!("The module `{}`", &m_p0.prism))
        }), &m_p0.path_, &kids_p1, &crate::syntax::lexer::chars::join(&each_19537, &Text::lit("\n")))))
    }
}

/// `Start RustModule, x`: what the function value is when passed to `@Run`.
pub fn start_rust_module(m_p0: crate::lower::model::ModDef, kids_p1: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustModule { m_p0, kids_p1 })
}

/// ```prism
/// NodeFallible: fn Model, Text -> Bool
/// ```
pub fn node_fallible(model_p0: &crate::lower::model::Model, path_p1: &Text) -> bool {
    fold(&model_p0.mods, &false, &(|f_p2: &bool, m_p3: &crate::lower::model::ModDef| fold(&m_p3.items, f_p2, &(|f2_p4: &bool, it_p5: &crate::lower::model::Item| match it_p5 {
        crate::lower::model::Item::ItNode(n_p6) => *f2_p4 || ((&Text::from(format!("{}::{}", &m_p3.name, &n_p6.name)) == path_p1) && n_p6.fallible),
        _ => *f2_p4,
    }))))
}

/// ```prism
/// EmitCrate: unbounded fn Model, Text, [Text] -> [((Text, Text))]
/// ```
pub fn emit_crate(model_p0: &crate::lower::model::Model, runtime_p1: &Text, scripts_p2: &Array<Text>) -> Array<(Text, Text)> {
    let gui_p3 = match &model_p0.root {
        Some(r_ph) => &r_ph.world == &Text::lit("canvas"),
        None => false,
    };
    let cargo_p4 = crate::emit::rust::templates::cargo(&model_p0.name, runtime_p1, &(if gui_p3 { Text::lit("\"canvas\"") } else { Text::lit("") }));
    let paths_p5 = rust_mod_paths(&model_p0.mods);
    let mods_p6 = concat(&each(&filter(&paths_p5, &(|p_pi: &Text| !crate::syntax::lexer::chars::contains(p_pi, &Text::lit(":")))), &(|p_pj: &Text| Text::from(format!("mod {};\n", p_pj)))));
    let programs_p7 = crate::syntax::lexer::chars::join(&run_to_end(each_job(all_programs(model_p0), {
        let model_p0 = model_p0.clone();
        Rc::new(move |p0: crate::lower::model::ProgDef| {
            let model_p0 = model_p0.clone();
            entered(once_job(move || {
                let p_pk = p0;
                prism_rtl::Turn::More(Rc::new(RustProgram { p_p0: p_pk.clone(), fallible_p1: node_fallible(&model_p0, &p_pk.node_) }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::ProgDef) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let regs_p8 = concat(&each(&model_p0.programs, &(|p_pl: &crate::lower::model::ProgDef| Text::from(format!(".program::<{}>(\"{}\")\n", &p_pl.name, &p_pl.prism)))));
    let checks_p9 = concat(&run_to_end(each_job(model_p0.checks.clone(), Rc::new(move |p0: crate::lower::model::CheckDef| entered(once_job(move || {
        let c_pm = p0;
        call_value(each_job(c_pm.lines.clone(), Rc::new(move |p0: crate::lower::model::Ex| entered(once_job(move || {
            let l_pn = p0;
            prism_rtl::Turn::More(Rc::new(crate::emit::rust::Expression { x_p0: l_pn.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_20566: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!(".check(\"{}\", || vec![{}])\n", &c_pm.name, &crate::syntax::lexer::chars::join(&each_20566, &Text::lit(", "))))))
    }))) as Rc<dyn Fn(crate::lower::model::CheckDef) -> Rc<dyn prism_rtl::Job<Text>>>)));
    let script_list_pa = concat(&each(scripts_p2, &(|s_po: &Text| Text::from(format!("\"{}\",\n", &crate::lower::expr::escape(s_po))))));
    let run_root_pb = match &model_p0.root {
        Some(r_pp) => crate::emit::rust::templates::run_root(&r_pp.name),
        None => crate::emit::rust::templates::no_root(&model_p0.name),
    };
    let world_pc = match &model_p0.root {
        Some(r_pq) => r_pq.world.clone(),
        None => Text::lit("test"),
    };
    let main_pd = crate::emit::rust::templates::main(&model_p0.name, &Text::from(format!("mod prelude;\n{}", &mods_p6)), &Text::from(format!("{}\n{}\n{}", &rust_row(&model_p0.elem), &rust_answer(&model_p0.answer), &programs_p7)), &Text::from(format!("{}{}", &regs_p8, &checks_p9)), &script_list_pa, &run_root_pb, &world_pc);
    let files_pe = run_to_end(each_job(model_p0.mods.clone(), {
        let paths_p5 = paths_p5.clone();
        Rc::new(move |p0: crate::lower::model::ModDef| {
            let paths_p5 = paths_p5.clone();
            entered(once_job(move || {
                let m_pr = p0;
                call_then(start_rust_module(m_pr.clone(), kids_of(&paths_p5, &m_pr.name)), move |rust_module_21080: Text| prism_rtl::Turn::Finished((rust_mod_file(&m_pr.name), rust_module_21080)))
            }))
        }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<(Text, Text)>>>
    }));
    let named_pf = each(&model_p0.mods, &(|m_ps: &crate::lower::model::ModDef| m_ps.name.clone()));
    let bare_pg = each(&filter(&paths_p5, &(|p_pt: &Text| !fold(&named_pf, &false, &(|f_pu: &bool, n_pv: &Text| *f_pu || (n_pv == p_pt))))), &(|p_p10: &Text| (rust_mod_file(p_p10), Text::from(format!("//! Emitted by prismc: the modules under `{}`, which declares nothing of its own.\n\n{}", p_p10, &kids_of(&paths_p5, p_p10))))));
    append(&Array::from(vec![(Text::lit("Cargo.toml"), cargo_p4.clone()), (Text::lit("src/main.rs"), main_pd.clone()), (Text::lit("src/prelude.rs"), crate::emit::rust::prelude::prelude_source(&Text::lit("")))]), &append(&files_pe, &bare_pg))
}

/// The step machine of `EmitCrate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EmitCrate: unbounded fn Model, Text, [Text] -> [((Text, Text))]
/// ```
pub struct EmitCrate {
    pub model_p0: crate::lower::model::Model,
    pub runtime_p1: Text,
    pub scripts_p2: Array<Text>,
}

impl prism_rtl::Job<Array<(Text, Text)>> for EmitCrate {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Text, Text)>> {
        let model_p0 = &self.model_p0;
        let runtime_p1 = &self.runtime_p1;
        let scripts_p2 = &self.scripts_p2;
        let gui_p3 = match &model_p0.root {
            Some(r_ph) => &r_ph.world == &Text::lit("canvas"),
            None => false,
        };
        let cargo_p4 = crate::emit::rust::templates::cargo(&model_p0.name, runtime_p1, &(if gui_p3 { Text::lit("\"canvas\"") } else { Text::lit("") }));
        let paths_p5 = rust_mod_paths(&model_p0.mods);
        let mods_p6 = concat(&each(&filter(&paths_p5, &(|p_pi: &Text| !crate::syntax::lexer::chars::contains(p_pi, &Text::lit(":")))), &(|p_pj: &Text| Text::from(format!("mod {};\n", p_pj)))));
        let model_p0 = model_p0.clone();
        let scripts_p2 = scripts_p2.clone();
        call_value(each_job(all_programs(&model_p0), {
            let model_p0 = model_p0.clone();
            Rc::new(move |p0: crate::lower::model::ProgDef| {
                let model_p0 = model_p0.clone();
                entered(once_job(move || {
                    let p_pk = p0;
                    prism_rtl::Turn::More(Rc::new(RustProgram { p_p0: p_pk.clone(), fallible_p1: node_fallible(&model_p0, &p_pk.node_) }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::ProgDef) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_20308: Array<Text>| {
            let programs_p7 = crate::syntax::lexer::chars::join(&each_20308, &Text::lit("\n"));
            let regs_p8 = concat(&each(&model_p0.programs, &(|p_pl: &crate::lower::model::ProgDef| Text::from(format!(".program::<{}>(\"{}\")\n", &p_pl.name, &p_pl.prism)))));
            call_value(each_job(model_p0.checks.clone(), Rc::new(move |p0: crate::lower::model::CheckDef| entered(once_job(move || {
                let c_pm = p0;
                call_value(each_job(c_pm.lines.clone(), Rc::new(move |p0: crate::lower::model::Ex| entered(once_job(move || {
                    let l_pn = p0;
                    prism_rtl::Turn::More(Rc::new(crate::emit::rust::Expression { x_p0: l_pn.clone() }))
                }))) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_20566: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!(".check(\"{}\", || vec![{}])\n", &c_pm.name, &crate::syntax::lexer::chars::join(&each_20566, &Text::lit(", "))))))
            }))) as Rc<dyn Fn(crate::lower::model::CheckDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_20505: Array<Text>| {
                let checks_p9 = concat(&each_20505);
                let script_list_pa = concat(&each(&scripts_p2, &(|s_po: &Text| Text::from(format!("\"{}\",\n", &crate::lower::expr::escape(s_po))))));
                let run_root_pb = match &model_p0.root {
                    Some(r_pp) => crate::emit::rust::templates::run_root(&r_pp.name),
                    None => crate::emit::rust::templates::no_root(&model_p0.name),
                };
                let world_pc = match &model_p0.root {
                    Some(r_pq) => r_pq.world.clone(),
                    None => Text::lit("test"),
                };
                call_then(start_rust_row(model_p0.elem.clone()), move |rust_row_20911: Text| call_then(start_rust_answer(model_p0.answer.clone()), move |rust_answer_20933: Text| {
                    let main_pd = crate::emit::rust::templates::main(&model_p0.name, &Text::from(format!("mod prelude;\n{}", &mods_p6)), &Text::from(format!("{}\n{}\n{}", &rust_row_20911, &rust_answer_20933, &programs_p7)), &Text::from(format!("{}{}", &regs_p8, &checks_p9)), &script_list_pa, &run_root_pb, &world_pc);
                    call_value(each_job(model_p0.mods.clone(), {
                        let paths_p5 = paths_p5.clone();
                        Rc::new(move |p0: crate::lower::model::ModDef| {
                            let paths_p5 = paths_p5.clone();
                            entered(once_job(move || {
                                let m_pr = p0;
                                call_then(start_rust_module(m_pr.clone(), kids_of(&paths_p5, &m_pr.name)), move |rust_module_21080: Text| prism_rtl::Turn::Finished((rust_mod_file(&m_pr.name), rust_module_21080)))
                            }))
                        }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<(Text, Text)>>>
                    }), move |each_21033: Array<(Text, Text)>| {
                        let files_pe = each_21033;
                        let named_pf = each(&model_p0.mods, &(|m_ps: &crate::lower::model::ModDef| m_ps.name.clone()));
                        let bare_pg = each(&filter(&paths_p5, &(|p_pt: &Text| !fold(&named_pf, &false, &(|f_pu: &bool, n_pv: &Text| *f_pu || (n_pv == p_pt))))), &(|p_p10: &Text| (rust_mod_file(p_p10), Text::from(format!("//! Emitted by prismc: the modules under `{}`, which declares nothing of its own.\n\n{}", p_p10, &kids_of(&paths_p5, p_p10))))));
                        prism_rtl::Turn::Finished(append(&Array::from(vec![(Text::lit("Cargo.toml"), cargo_p4.clone()), (Text::lit("src/main.rs"), main_pd.clone()), (Text::lit("src/prelude.rs"), crate::emit::rust::prelude::prelude_source(&Text::lit("")))]), &append(&files_pe, &bare_pg)))
                    })
                }))
            })
        })
    }
}

/// `Start EmitCrate, x`: what the function value is when passed to `@Run`.
pub fn start_emit_crate(model_p0: crate::lower::model::Model, runtime_p1: Text, scripts_p2: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>> {
    Rc::new(EmitCrate { model_p0, runtime_p1, scripts_p2 })
}

/// ```prism
/// RustModPaths: fn [ModDef] -> [Text]
/// ```
pub fn rust_mod_paths(mods_p0: &Array<crate::lower::model::ModDef>) -> Array<Text> {
    fold(mods_p0, &Array::new(), &(|acc_p1: &Array<Text>, m_p2: &crate::lower::model::ModDef| {
        let segs_p3 = split_on(&m_p2.name, &Text::lit("::"));
        fold(&crate::check::errors::range0(&len(&segs_p3)), acc_p1, &(|a_p4: &Array<Text>, i_p5: &Nat| add_path(a_p4, &crate::syntax::lexer::chars::join(&take(&segs_p3, &(i_p5 + &Nat::from(1u32))), &Text::lit("::")))))
    }))
}

/// ```prism
/// AddPath: fn [Text], Text -> [Text]
/// ```
pub fn add_path(ps_p0: &Array<Text>, p_p1: &Text) -> Array<Text> {
    if fold(ps_p0, &false, &(|f_p2: &bool, q_p3: &Text| *f_p2 || (q_p3 == p_p1))) {
        ps_p0.clone()
    } else {
        push(ps_p0, p_p1)
    }
}

/// ```prism
/// RustModFile: fn Text -> Text
/// ```
pub fn rust_mod_file(p_p0: &Text) -> Text {
    if p_p0 == &Text::lit("program") {
        Text::lit("src/program.rs")
    } else {
        Text::from(format!("src/{}/mod.rs", &crate::syntax::lexer::chars::join(&split_on(p_p0, &Text::lit("::")), &Text::lit("/"))))
    }
}

/// ```prism
/// KidsOf: fn [Text], Text -> Text
/// ```
pub fn kids_of(paths_p0: &Array<Text>, p_p1: &Text) -> Text {
    concat(&each(&filter(paths_p0, &(|q_p2: &Text| crate::syntax::lexer::chars::has_prefix(q_p2, &Text::from(format!("{}::", p_p1))) && !crate::syntax::lexer::chars::contains(&crate::syntax::lexer::chars::drop_prefix(q_p2, &Text::from(format!("{}::", p_p1))), &Text::lit(":")))), &(|q_p3: &Text| Text::from(format!("pub mod {};\n", &crate::syntax::lexer::chars::drop_prefix(q_p3, &Text::from(format!("{}::", p_p1))))))))
}

/// ```prism
/// AllPrograms: fn Model -> [ProgDef]
/// ```
pub fn all_programs(model_p0: &crate::lower::model::Model) -> Array<crate::lower::model::ProgDef> {
    match &model_p0.root {
        Some(r_p1) => if fold(&model_p0.programs, &false, &(|f_p2: &bool, p_p3: &crate::lower::model::ProgDef| *f_p2 || (&p_p3.name == &r_p1.name))) {
            model_p0.programs.clone()
        } else {
            push(&model_p0.programs, r_p1)
        },
        None => model_p0.programs.clone(),
    }
}
