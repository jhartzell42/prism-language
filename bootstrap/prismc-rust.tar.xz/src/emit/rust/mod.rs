//! The module `Emit.Rust`, from `target/bootstrap/src/prismc/emit/rust/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod items;
pub mod prelude;
pub mod templates;

/// ```prism
/// Type: unbounded fn OutTy -> Text
/// ```
pub fn type_(t_p0: &crate::lower::model::OutTy) -> Text {
    'm1596: {
        if let crate::lower::model::OutTy::OutNat = t_p0 {
            break 'm1596 Text::lit("Nat");
        }
        if let crate::lower::model::OutTy::OutInt = t_p0 {
            break 'm1596 Text::lit("Int");
        }
        if let crate::lower::model::OutTy::OutU8 = t_p0 {
            break 'm1596 Text::lit("u8");
        }
        if let crate::lower::model::OutTy::OutFloat = t_p0 {
            break 'm1596 Text::lit("Float");
        }
        if let crate::lower::model::OutTy::OutBool = t_p0 {
            break 'm1596 Text::lit("bool");
        }
        if let crate::lower::model::OutTy::OutChar = t_p0 {
            break 'm1596 Text::lit("char");
        }
        if let crate::lower::model::OutTy::OutText = t_p0 {
            break 'm1596 Text::lit("Text");
        }
        if let crate::lower::model::OutTy::OutCursor = t_p0 {
            break 'm1596 Text::lit("Cursor");
        }
        if let crate::lower::model::OutTy::OutRegex = t_p0 {
            break 'm1596 Text::lit("Regex");
        }
        if let crate::lower::model::OutTy::OutReplacement = t_p0 {
            break 'm1596 Text::lit("RegexReplacement");
        }
        if let crate::lower::model::OutTy::OutUnit = t_p0 {
            break 'm1596 Text::lit("()");
        }
        if let crate::lower::model::OutTy::OutPath = t_p0 {
            break 'm1596 Text::lit("Path");
        }
        if let crate::lower::model::OutTy::OutDuration = t_p0 {
            break 'm1596 Text::lit("Duration");
        }
        if let crate::lower::model::OutTy::OutError = t_p0 {
            break 'm1596 Text::lit("Error");
        }
        if let crate::lower::model::OutTy::OutNamed(n_p1, m1596_14_1) = t_p0 && (m1596_14_1.len() == 0) {
            break 'm1596 n_p1.clone();
        }
        if let crate::lower::model::OutTy::OutNamed(n_p2, args_p3) = t_p0 {
            break 'm1596 Text::from(format!("{}<{}>", n_p2, &types(args_p3)));
        }
        if let crate::lower::model::OutTy::OutOpt(i_p4) = t_p0 {
            break 'm1596 Text::from(format!("Option<{}>", &type_(&**i_p4)));
        }
        if let crate::lower::model::OutTy::OutRes(i_p5) = t_p0 {
            break 'm1596 Text::from(format!("Result<{}, Error>", &type_(&**i_p5)));
        }
        if let crate::lower::model::OutTy::OutTuple(m1596_18_0) = t_p0 && (m1596_18_0.len() == 1) && let Some(one_p6) = index(m1596_18_0, &Nat::from(0u32)) {
            break 'm1596 Text::from(format!("({},)", &type_(&one_p6)));
        }
        if let crate::lower::model::OutTy::OutTuple(ts_p7) = t_p0 {
            break 'm1596 Text::from(format!("({})", &types(ts_p7)));
        }
        if let crate::lower::model::OutTy::OutArray(e_p8) = t_p0 {
            break 'm1596 Text::from(format!("Array<{}>", &type_(&**e_p8)));
        }
        if let crate::lower::model::OutTy::OutMap(k_p9, v_pa) = t_p0 {
            break 'm1596 Text::from(format!("Map<{}, {}>", &type_(&**k_p9), &type_(&**v_pa)));
        }
        if let crate::lower::model::OutTy::OutFn(ps_pb, r_pc) = t_p0 {
            break 'm1596 Text::from(format!("Rc<dyn Fn({}) -> {}>", &ref_types(ps_pb), &type_(&**r_pc)));
        }
        if let crate::lower::model::OutTy::OutRef(i_pd) = t_p0 {
            break 'm1596 Text::from(format!("&{}", &type_(&**i_pd)));
        }
        if let crate::lower::model::OutTy::OutJobFn(a_pe, b_pf) = t_p0 {
            break 'm1596 Text::from(format!("Rc<dyn Fn({}) -> Rc<dyn prism_rtl::Job<{}>>>", &type_(&**a_pe), &type_(&**b_pf)));
        }
        if let crate::lower::model::OutTy::OutJob(b_pg) = t_p0 {
            break 'm1596 Text::from(format!("Rc<dyn prism_rtl::Job<{}>>", &type_(&**b_pg)));
        }
        if let crate::lower::model::OutTy::OutEvent(i_ph) = t_p0 {
            break 'm1596 Text::from(format!("Event<{}>", &type_(&**i_ph)));
        }
        if let crate::lower::model::OutTy::OutDyn(i_pi) = t_p0 {
            break 'm1596 Text::from(format!("Dynamic<{}>", &type_(&**i_pi)));
        }
        if let crate::lower::model::OutTy::OutGen(n_pj) = t_p0 {
            break 'm1596 n_pj.clone();
        }
        if let crate::lower::model::OutTy::OutRc(i_pk) = t_p0 {
            break 'm1596 Text::from(format!("Rc<{}>", &type_(&**i_pk)));
        }
        if let crate::lower::model::OutTy::OutPod = t_p0 {
            break 'm1596 Text::lit("Pod");
        }
        if let crate::lower::model::OutTy::OutShowAny = t_p0 {
            break 'm1596 Text::lit("Rc<dyn Show>");
        }
        if let crate::lower::model::OutTy::OutHold(i_pl) = t_p0 {
            break 'm1596 Text::from(format!("Hold<{}>", &type_(&**i_pl)));
        }
        if let crate::lower::model::OutTy::OutStamped(i_pm) = t_p0 {
            break 'm1596 Text::from(format!("Stamped<{}>", &type_(&**i_pm)));
        }
        if let crate::lower::model::OutTy::OutSnapshot(i_pn) = t_p0 {
            break 'm1596 Text::from(format!("Snapshot<{}>", &type_(&**i_pn)));
        }
        if let crate::lower::model::OutTy::OutDefer(i_po) = t_p0 {
            break 'm1596 Text::from(format!("Defer<{}>", &type_(&**i_po)));
        }
        if let crate::lower::model::OutTy::OutWeak(n_pp) = t_p0 {
            break 'm1596 Text::from(format!("Weak<{}>", n_pp));
        }
        if let crate::lower::model::OutTy::OutCell(i_pq) = t_p0 {
            break 'm1596 Text::from(format!("RefCell<{}>", &type_(&**i_pq)));
        }
        if let crate::lower::model::OutTy::OutWakes = t_p0 {
            break 'm1596 Text::lit("Wakes");
        }
        if let crate::lower::model::OutTy::OutCount = t_p0 {
            break 'm1596 Text::lit("u32");
        }
        if let crate::lower::model::OutTy::OutObj(i_pr) = t_p0 {
            break 'm1596 Text::from(format!("Rc<dyn {}>", &type_(&**i_pr)));
        }
        if let crate::lower::model::OutTy::OutSlice(i_ps) = t_p0 {
            break 'm1596 Text::from(format!("[{}]", &type_(&**i_ps)));
        }
        if let crate::lower::model::OutTy::OutPort(i_pt) = t_p0 {
            break 'm1596 Text::from(format!("Port<{}>", &type_(&**i_pt)));
        }
        if let crate::lower::model::OutTy::OutLive(i_pu) = t_p0 {
            break 'm1596 Text::from(format!("Live<{}>", &type_(&**i_pu)));
        }
        if let crate::lower::model::OutTy::OutUnknown(what_pv) = t_p0 {
            break 'm1596 Text::from(format!("() /* {} */", what_pv));
        }
        if let crate::lower::model::OutTy::OutQuantified(b_p10) = t_p0 {
            break 'm1596 Text::from(format!("compile_error!(\"{}a quantified type variable of `{}`: no instantiation gives it a type\")", &crate::lower::expr::lowering_refusal(), b_p10));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `Type`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Type: unbounded fn OutTy -> Text
/// ```
pub struct Type {
    pub t_p0: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for Type {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t_p0 = &self.t_p0;
        'm1596: {
            if let crate::lower::model::OutTy::OutNat = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Nat"));
            }
            if let crate::lower::model::OutTy::OutInt = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Int"));
            }
            if let crate::lower::model::OutTy::OutU8 = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("u8"));
            }
            if let crate::lower::model::OutTy::OutFloat = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Float"));
            }
            if let crate::lower::model::OutTy::OutBool = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("bool"));
            }
            if let crate::lower::model::OutTy::OutChar = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("char"));
            }
            if let crate::lower::model::OutTy::OutText = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Text"));
            }
            if let crate::lower::model::OutTy::OutCursor = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Cursor"));
            }
            if let crate::lower::model::OutTy::OutRegex = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Regex"));
            }
            if let crate::lower::model::OutTy::OutReplacement = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("RegexReplacement"));
            }
            if let crate::lower::model::OutTy::OutUnit = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("()"));
            }
            if let crate::lower::model::OutTy::OutPath = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Path"));
            }
            if let crate::lower::model::OutTy::OutDuration = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Duration"));
            }
            if let crate::lower::model::OutTy::OutError = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Error"));
            }
            if let crate::lower::model::OutTy::OutNamed(n_p1, m1596_14_1) = t_p0 && (m1596_14_1.len() == 0) {
                break 'm1596 prism_rtl::Turn::Finished(n_p1.clone());
            }
            if let crate::lower::model::OutTy::OutNamed(n_p2, args_p3) = t_p0 {
                break 'm1596 {
                    let args_p3 = args_p3.clone();
                    let n_p2 = n_p2.clone();
                    call_then(start_types(args_p3.clone()), move |types_1964: Text| prism_rtl::Turn::Finished(Text::from(format!("{}<{}>", &n_p2, &types_1964))))
                };
            }
            if let crate::lower::model::OutTy::OutOpt(i_p4) = t_p0 {
                break 'm1596 {
                    let i_p4 = (**i_p4).clone();
                    call_then(start_type_(i_p4.clone()), move |type__2001: Text| prism_rtl::Turn::Finished(Text::from(format!("Option<{}>", &type__2001))))
                };
            }
            if let crate::lower::model::OutTy::OutRes(i_p5) = t_p0 {
                break 'm1596 {
                    let i_p5 = (**i_p5).clone();
                    call_then(start_type_(i_p5.clone()), move |type__2034: Text| prism_rtl::Turn::Finished(Text::from(format!("Result<{}, Error>", &type__2034))))
                };
            }
            if let crate::lower::model::OutTy::OutTuple(m1596_18_0) = t_p0 && (m1596_18_0.len() == 1) && let Some(one_p6) = index(m1596_18_0, &Nat::from(0u32)) {
                break 'm1596 call_then(start_type_(one_p6.clone()), move |type__2076: Text| prism_rtl::Turn::Finished(Text::from(format!("({},)", &type__2076))));
            }
            if let crate::lower::model::OutTy::OutTuple(ts_p7) = t_p0 {
                break 'm1596 {
                    let ts_p7 = ts_p7.clone();
                    call_then(start_types(ts_p7.clone()), move |types_2109: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &types_2109))))
                };
            }
            if let crate::lower::model::OutTy::OutArray(e_p8) = t_p0 {
                break 'm1596 {
                    let e_p8 = (**e_p8).clone();
                    call_then(start_type_(e_p8.clone()), move |type__2145: Text| prism_rtl::Turn::Finished(Text::from(format!("Array<{}>", &type__2145))))
                };
            }
            if let crate::lower::model::OutTy::OutMap(k_p9, v_pa) = t_p0 {
                break 'm1596 {
                    let k_p9 = (**k_p9).clone();
                    let v_pa = (**v_pa).clone();
                    call_then(start_type_(k_p9.clone()), move |type__2178: Text| call_then(start_type_(v_pa.clone()), move |type__2188: Text| prism_rtl::Turn::Finished(Text::from(format!("Map<{}, {}>", &type__2178, &type__2188)))))
                };
            }
            if let crate::lower::model::OutTy::OutFn(ps_pb, r_pc) = t_p0 {
                break 'm1596 {
                    let ps_pb = ps_pb.clone();
                    let r_pc = (**r_pc).clone();
                    call_then(start_ref_types(ps_pb.clone()), move |ref_types_2227: Text| call_then(start_type_(r_pc.clone()), move |type__2245: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<dyn Fn({}) -> {}>", &ref_types_2227, &type__2245)))))
                };
            }
            if let crate::lower::model::OutTy::OutRef(i_pd) = t_p0 {
                break 'm1596 {
                    let i_pd = (**i_pd).clone();
                    call_then(start_type_(i_pd.clone()), move |type__2272: Text| prism_rtl::Turn::Finished(Text::from(format!("&{}", &type__2272))))
                };
            }
            if let crate::lower::model::OutTy::OutJobFn(a_pe, b_pf) = t_p0 {
                break 'm1596 {
                    let a_pe = (**a_pe).clone();
                    let b_pf = (**b_pf).clone();
                    call_then(start_type_(a_pe.clone()), move |type__2312: Text| call_then(start_type_(b_pf.clone()), move |type__2347: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<dyn Fn({}) -> Rc<dyn prism_rtl::Job<{}>>>", &type__2312, &type__2347)))))
                };
            }
            if let crate::lower::model::OutTy::OutJob(b_pg) = t_p0 {
                break 'm1596 {
                    let b_pg = (**b_pg).clone();
                    call_then(start_type_(b_pg.clone()), move |type__2397: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<dyn prism_rtl::Job<{}>>", &type__2397))))
                };
            }
            if let crate::lower::model::OutTy::OutEvent(i_ph) = t_p0 {
                break 'm1596 {
                    let i_ph = (**i_ph).clone();
                    call_then(start_type_(i_ph.clone()), move |type__2432: Text| prism_rtl::Turn::Finished(Text::from(format!("Event<{}>", &type__2432))))
                };
            }
            if let crate::lower::model::OutTy::OutDyn(i_pi) = t_p0 {
                break 'm1596 {
                    let i_pi = (**i_pi).clone();
                    call_then(start_type_(i_pi.clone()), move |type__2466: Text| prism_rtl::Turn::Finished(Text::from(format!("Dynamic<{}>", &type__2466))))
                };
            }
            if let crate::lower::model::OutTy::OutGen(n_pj) = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(n_pj.clone());
            }
            if let crate::lower::model::OutTy::OutRc(i_pk) = t_p0 {
                break 'm1596 {
                    let i_pk = (**i_pk).clone();
                    call_then(start_type_(i_pk.clone()), move |type__2510: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<{}>", &type__2510))))
                };
            }
            if let crate::lower::model::OutTy::OutPod = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Pod"));
            }
            if let crate::lower::model::OutTy::OutShowAny = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Rc<dyn Show>"));
            }
            if let crate::lower::model::OutTy::OutHold(i_pl) = t_p0 {
                break 'm1596 {
                    let i_pl = (**i_pl).clone();
                    call_then(start_type_(i_pl.clone()), move |type__2591: Text| prism_rtl::Turn::Finished(Text::from(format!("Hold<{}>", &type__2591))))
                };
            }
            if let crate::lower::model::OutTy::OutStamped(i_pm) = t_p0 {
                break 'm1596 {
                    let i_pm = (**i_pm).clone();
                    call_then(start_type_(i_pm.clone()), move |type__2629: Text| prism_rtl::Turn::Finished(Text::from(format!("Stamped<{}>", &type__2629))))
                };
            }
            if let crate::lower::model::OutTy::OutSnapshot(i_pn) = t_p0 {
                break 'm1596 {
                    let i_pn = (**i_pn).clone();
                    call_then(start_type_(i_pn.clone()), move |type__2669: Text| prism_rtl::Turn::Finished(Text::from(format!("Snapshot<{}>", &type__2669))))
                };
            }
            if let crate::lower::model::OutTy::OutDefer(i_po) = t_p0 {
                break 'm1596 {
                    let i_po = (**i_po).clone();
                    call_then(start_type_(i_po.clone()), move |type__2703: Text| prism_rtl::Turn::Finished(Text::from(format!("Defer<{}>", &type__2703))))
                };
            }
            if let crate::lower::model::OutTy::OutWeak(n_pp) = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::from(format!("Weak<{}>", n_pp)));
            }
            if let crate::lower::model::OutTy::OutCell(i_pq) = t_p0 {
                break 'm1596 {
                    let i_pq = (**i_pq).clone();
                    call_then(start_type_(i_pq.clone()), move |type__2765: Text| prism_rtl::Turn::Finished(Text::from(format!("RefCell<{}>", &type__2765))))
                };
            }
            if let crate::lower::model::OutTy::OutWakes = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Wakes"));
            }
            if let crate::lower::model::OutTy::OutCount = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("u32"));
            }
            if let crate::lower::model::OutTy::OutObj(i_pr) = t_p0 {
                break 'm1596 {
                    let i_pr = (**i_pr).clone();
                    call_then(start_type_(i_pr.clone()), move |type__2840: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<dyn {}>", &type__2840))))
                };
            }
            if let crate::lower::model::OutTy::OutSlice(i_ps) = t_p0 {
                break 'm1596 {
                    let i_ps = (**i_ps).clone();
                    call_then(start_type_(i_ps.clone()), move |type__2869: Text| prism_rtl::Turn::Finished(Text::from(format!("[{}]", &type__2869))))
                };
            }
            if let crate::lower::model::OutTy::OutPort(i_pt) = t_p0 {
                break 'm1596 {
                    let i_pt = (**i_pt).clone();
                    call_then(start_type_(i_pt.clone()), move |type__2901: Text| prism_rtl::Turn::Finished(Text::from(format!("Port<{}>", &type__2901))))
                };
            }
            if let crate::lower::model::OutTy::OutLive(i_pu) = t_p0 {
                break 'm1596 {
                    let i_pu = (**i_pu).clone();
                    call_then(start_type_(i_pu.clone()), move |type__2933: Text| prism_rtl::Turn::Finished(Text::from(format!("Live<{}>", &type__2933))))
                };
            }
            if let crate::lower::model::OutTy::OutUnknown(what_pv) = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::from(format!("() /* {} */", what_pv)));
            }
            if let crate::lower::model::OutTy::OutQuantified(b_p10) = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}a quantified type variable of `{}`: no instantiation gives it a type\")", &crate::lower::expr::lowering_refusal(), b_p10)));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start Type, x`: what the function value is when passed to `@Run`.
pub fn start_type_(t_p0: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Type { t_p0 })
}

/// ```prism
/// Types: unbounded fn [OutTy] -> Text
/// ```
pub fn types(ts_p0: &Array<crate::lower::model::OutTy>) -> Text {
    crate::syntax::lexer::chars::join(&run_to_end(each_job(ts_p0.clone(), Rc::new(move |p0: crate::lower::model::OutTy| entered(once_job(move || {
        let t_p1 = p0;
        prism_rtl::Turn::More(Rc::new(Type { t_p0: t_p1.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))
}

/// The step machine of `Types`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Types: unbounded fn [OutTy] -> Text
/// ```
pub struct Types {
    pub ts_p0: Array<crate::lower::model::OutTy>,
}

impl prism_rtl::Job<Text> for Types {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let ts_p0 = &self.ts_p0;
        let ts_p0 = ts_p0.clone();
        call_value(each_job(ts_p0.clone(), Rc::new(move |p0: crate::lower::model::OutTy| entered(once_job(move || {
            let t_p1 = p0;
            prism_rtl::Turn::More(Rc::new(Type { t_p0: t_p1.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_3169: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&each_3169, &Text::lit(", "))))
    }
}

/// `Start Types, x`: what the function value is when passed to `@Run`.
pub fn start_types(ts_p0: Array<crate::lower::model::OutTy>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Types { ts_p0 })
}

/// ```prism
/// RefTypes: unbounded fn [OutTy] -> Text
/// ```
pub fn ref_types(ts_p0: &Array<crate::lower::model::OutTy>) -> Text {
    crate::syntax::lexer::chars::join(&run_to_end(each_job(ts_p0.clone(), Rc::new(move |p0: crate::lower::model::OutTy| entered(once_job(move || {
        let t_p1 = p0;
        call_then(start_type_(t_p1.clone()), move |type__3277: Text| prism_rtl::Turn::Finished(Text::from(format!("&{}", &type__3277))))
    }))) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))
}

/// The step machine of `RefTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RefTypes: unbounded fn [OutTy] -> Text
/// ```
pub struct RefTypes {
    pub ts_p0: Array<crate::lower::model::OutTy>,
}

impl prism_rtl::Job<Text> for RefTypes {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let ts_p0 = &self.ts_p0;
        let ts_p0 = ts_p0.clone();
        call_value(each_job(ts_p0.clone(), Rc::new(move |p0: crate::lower::model::OutTy| entered(once_job(move || {
            let t_p1 = p0;
            call_then(start_type_(t_p1.clone()), move |type__3277: Text| prism_rtl::Turn::Finished(Text::from(format!("&{}", &type__3277))))
        }))) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_3260: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&each_3260, &Text::lit(", "))))
    }
}

/// `Start RefTypes, x`: what the function value is when passed to `@Run`.
pub fn start_ref_types(ts_p0: Array<crate::lower::model::OutTy>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RefTypes { ts_p0 })
}

/// ```prism
/// IsLoose: fn Ex -> Bool
/// ```
pub fn is_loose(x_p0: &crate::lower::model::Ex) -> bool {
    match x_p0 {
        crate::lower::model::Ex::XBlock(m3602_0_0, inner_p1) if (m3602_0_0.len() == 0) => is_loose(&**inner_p1),
        crate::lower::model::Ex::XTyped(inner_p2, _) => is_loose(&**inner_p2),
        crate::lower::model::Ex::XBin(_, _, _) => true,
        crate::lower::model::Ex::XUnary(_, _) => true,
        crate::lower::model::Ex::XClosure(_, _, _) => true,
        crate::lower::model::Ex::XIf(_, _, _) => true,
        crate::lower::model::Ex::XMatch(_, _, _, _) => true,
        crate::lower::model::Ex::XChain(_, _, _, _) => true,
        crate::lower::model::Ex::XCast(_, _) => true,
        crate::lower::model::Ex::XRef(_) => true,
        crate::lower::model::Ex::XRefMut(_) => true,
        crate::lower::model::Ex::XDeref(_) => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Tight: unbounded fn Ex -> Text
/// ```
pub fn tight(x_p0: &crate::lower::model::Ex) -> Text {
    if is_loose(x_p0) {
        Text::from(format!("({})", &expression(x_p0)))
    } else {
        expression(x_p0)
    }
}

/// The step machine of `Tight`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Tight: unbounded fn Ex -> Text
/// ```
pub struct Tight {
    pub x_p0: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for Tight {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let x_p0 = &self.x_p0;
        if is_loose(x_p0) {
            {
                let x_p0 = x_p0.clone();
                call_then(start_expression(x_p0.clone()), move |expression_4119: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_4119))))
            }
        } else {
            prism_rtl::Turn::More(Rc::new(Expression { x_p0: x_p0.clone() }))
        }
    }
}

/// `Start Tight, x`: what the function value is when passed to `@Run`.
pub fn start_tight(x_p0: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Tight { x_p0 })
}

/// ```prism
/// Operand: unbounded fn Ex -> Text
/// ```
pub fn operand(x_p0: &crate::lower::model::Ex) -> Text {
    match x_p0 {
        crate::lower::model::Ex::XBlock(m4203_0_0, inner_p1) if (m4203_0_0.len() == 0) => operand(&**inner_p1),
        crate::lower::model::Ex::XTyped(inner_p2, _) => operand(&**inner_p2),
        crate::lower::model::Ex::XBin(_, _, _) => Text::from(format!("({})", &expression(x_p0))),
        crate::lower::model::Ex::XClosure(_, _, _) => Text::from(format!("({})", &expression(x_p0))),
        crate::lower::model::Ex::XIf(_, _, _) => Text::from(format!("({})", &expression(x_p0))),
        crate::lower::model::Ex::XCast(_, _) => Text::from(format!("({})", &expression(x_p0))),
        _ => expression(x_p0),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `Operand`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Operand: unbounded fn Ex -> Text
/// ```
pub struct Operand {
    pub x_p0: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for Operand {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let x_p0 = &self.x_p0;
        match x_p0 {
            crate::lower::model::Ex::XBlock(m4203_0_0, inner_p1) if (m4203_0_0.len() == 0) => prism_rtl::Turn::More(Rc::new(Operand { x_p0: (**inner_p1).clone() })),
            crate::lower::model::Ex::XTyped(inner_p2, _) => prism_rtl::Turn::More(Rc::new(Operand { x_p0: (**inner_p2).clone() })),
            crate::lower::model::Ex::XBin(_, _, _) => {
                let x_p0 = x_p0.clone();
                call_then(start_expression(x_p0.clone()), move |expression_4326: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_4326))))
            },
            crate::lower::model::Ex::XClosure(_, _, _) => {
                let x_p0 = x_p0.clone();
                call_then(start_expression(x_p0.clone()), move |expression_4382: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_4382))))
            },
            crate::lower::model::Ex::XIf(_, _, _) => {
                let x_p0 = x_p0.clone();
                call_then(start_expression(x_p0.clone()), move |expression_4433: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_4433))))
            },
            crate::lower::model::Ex::XCast(_, _) => {
                let x_p0 = x_p0.clone();
                call_then(start_expression(x_p0.clone()), move |expression_4478: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_4478))))
            },
            _ => prism_rtl::Turn::More(Rc::new(Expression { x_p0: x_p0.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start Operand, x`: what the function value is when passed to `@Run`.
pub fn start_operand(x_p0: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Operand { x_p0 })
}

/// ```prism
/// Args: unbounded fn [Ex] -> Text
/// ```
pub fn args(xs_p0: &Array<crate::lower::model::Ex>) -> Text {
    crate::syntax::lexer::chars::join(&run_to_end(each_job(xs_p0.clone(), Rc::new(move |p0: crate::lower::model::Ex| entered(once_job(move || {
        let x_p1 = p0;
        prism_rtl::Turn::More(Rc::new(Expression { x_p0: x_p1.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))
}

/// The step machine of `Args`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Args: unbounded fn [Ex] -> Text
/// ```
pub struct Args {
    pub xs_p0: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for Args {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let xs_p0 = &self.xs_p0;
        let xs_p0 = xs_p0.clone();
        call_value(each_job(xs_p0.clone(), Rc::new(move |p0: crate::lower::model::Ex| entered(once_job(move || {
            let x_p1 = p0;
            prism_rtl::Turn::More(Rc::new(Expression { x_p0: x_p1.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_4574: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&each_4574, &Text::lit(", "))))
    }
}

/// `Start Args, x`: what the function value is when passed to `@Run`.
pub fn start_args(xs_p0: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Args { xs_p0 })
}

/// ```prism
/// Expression: unbounded fn Ex -> Text
/// ```
pub fn expression(x_p0: &crate::lower::model::Ex) -> Text {
    'm4663: {
        if let crate::lower::model::Ex::XVar(n_p1) = x_p0 {
            break 'm4663 n_p1.clone();
        }
        if let crate::lower::model::Ex::XPath(p_p2) = x_p0 {
            break 'm4663 p_p2.clone();
        }
        if let crate::lower::model::Ex::XSelf = x_p0 {
            break 'm4663 Text::lit("self");
        }
        if let crate::lower::model::Ex::XCx = x_p0 {
            break 'm4663 Text::lit("cx");
        }
        if let crate::lower::model::Ex::XConst(n_p3) = x_p0 {
            break 'm4663 Text::from(format!("Self::{}", n_p3));
        }
        if let crate::lower::model::Ex::XUnit = x_p0 {
            break 'm4663 Text::lit("()");
        }
        if let crate::lower::model::Ex::XNone = x_p0 {
            break 'm4663 Text::lit("None");
        }
        if let crate::lower::model::Ex::XBool(b_p4) = x_p0 {
            break 'm4663 if *b_p4 { Text::lit("true") } else { Text::lit("false") };
        }
        if let crate::lower::model::Ex::XNat(d_p5) = x_p0 {
            break 'm4663 if &len_text(d_p5) <= &Nat::from(9u32) {
                Text::from(format!("Nat::from({}u32)", d_p5))
            } else {
                if &len_text(d_p5) <= &Nat::from(18u32) {
                    Text::from(format!("Nat::from_int(Int::from({}i64)).unwrap()", d_p5))
                } else {
                    Text::from(format!("Nat::from_int(Int::parse(\"{}\").unwrap()).unwrap()", d_p5))
                }
            };
        }
        if let crate::lower::model::Ex::XInt(d_p6) = x_p0 {
            break 'm4663 if &len_text(&(if crate::syntax::lexer::chars::has_prefix(d_p6, &Text::lit("-")) {
                crate::syntax::lexer::chars::after_first(d_p6)
            } else {
                d_p6.clone()
            })) <= &Nat::from(18u32) {
                Text::from(format!("Int::from({})", d_p6))
            } else {
                Text::from(format!("Int::parse(\"{}\").unwrap()", d_p6))
            };
        }
        if let crate::lower::model::Ex::XByte(d_p7) = x_p0 {
            break 'm4663 Text::from(format!("{}u8", d_p7));
        }
        if let crate::lower::model::Ex::XFloat(d_p8) = x_p0 {
            break 'm4663 Text::from(format!("Float({})", d_p8));
        }
        if let crate::lower::model::Ex::XIndex(n_p9) = x_p0 {
            break 'm4663 Text::from(format!("{}", n_p9));
        }
        if let crate::lower::model::Ex::XChar(c_pa) = x_p0 {
            break 'm4663 Text::from(format!("\'{}\'", &crate::lower::expr::char_escape(c_pa)));
        }
        if let crate::lower::model::Ex::XStr(t_pb) = x_p0 {
            break 'm4663 Text::from(format!("\"{}\"", &crate::lower::expr::escape(t_pb)));
        }
        if let crate::lower::model::Ex::XRegex(p_pc, f_pd) = x_p0 {
            break 'm4663 Text::from(format!("{{ thread_local!(static R: Regex = Regex::lit(\"{}\", \"{}\")); R.with(Regex::clone) }}", &crate::lower::expr::escape(p_pc), &crate::lower::expr::escape(f_pd)));
        }
        if let crate::lower::model::Ex::XReplacement(p_pe, r_pf, f_pg) = x_p0 {
            break 'm4663 Text::from(format!("{{ thread_local!(static R: RegexReplacement = RegexReplacement::lit(\"{}\", \"{}\", \"{}\")); R.with(RegexReplacement::clone) }}", &crate::lower::expr::escape(p_pe), &crate::lower::expr::escape(f_pg), &crate::lower::expr::escape(r_pf)));
        }
        if let crate::lower::model::Ex::XRef(y_ph) = x_p0 {
            break 'm4663 Text::from(format!("&{}", &operand(&**y_ph)));
        }
        if let crate::lower::model::Ex::XRefMut(y_pi) = x_p0 {
            break 'm4663 Text::from(format!("&mut {}", &operand(&**y_pi)));
        }
        if let crate::lower::model::Ex::XDeref(y_pj) = x_p0 {
            break 'm4663 Text::from(format!("*{}", &operand(&**y_pj)));
        }
        if let crate::lower::model::Ex::XTarget(y_pk) = x_p0 {
            break 'm4663 Text::from(format!("(*{})", &expression(&**y_pk)));
        }
        if let crate::lower::model::Ex::XClone(y_pl) = x_p0 {
            break 'm4663 Text::from(format!("{}.clone()", &tight(&**y_pl)));
        }
        if let crate::lower::model::Ex::XWeak(y_pm) = x_p0 {
            break 'm4663 Text::from(format!("Rc::downgrade({})", &expression(&**y_pm)));
        }
        if let crate::lower::model::Ex::XUpgrade(y_pn) = x_p0 {
            break 'm4663 Text::from(format!("{}.upgrade()", &tight(&**y_pn)));
        }
        if let crate::lower::model::Ex::XBreak(l_po, y_pp) = x_p0 {
            break 'm4663 Text::from(format!("break {} {}", &label(l_po), &expression(&**y_pp)));
        }
        if let crate::lower::model::Ex::XBreakLoop = x_p0 {
            break 'm4663 Text::lit("break");
        }
        if let crate::lower::model::Ex::XLater(y_pq) = x_p0 {
            break 'm4663 Text::from(format!("Box::new(move |cx| {{ {}; Ok(()) }})", &expression(&**y_pq)));
        }
        if let crate::lower::model::Ex::XFormatStr(parts_pr) = x_p0 {
            break 'm4663 format_str(parts_pr);
        }
        if let crate::lower::model::Ex::XIsCase(y_ps, m4663_28_1) = x_p0 && (m4663_28_1.len() == 0) {
            break 'm4663 Text::lit("false");
        }
        if let crate::lower::model::Ex::XIsCase(y_pt, cs_pu) = x_p0 {
            break 'm4663 Text::from(format!("matches!({}, {})", &expression(&**y_pt), &crate::syntax::lexer::chars::join(&each(cs_pu, &(|c_pv: &Text| Text::from(format!("{}(..)", c_pv)))), &Text::lit(" | "))));
        }
        if let crate::lower::model::Ex::XRefusal(what_p10) = x_p0 {
            break 'm4663 Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::expr::lowering_refusal(), &crate::lower::expr::escape(what_p10)));
        }
        if let crate::lower::model::Ex::XUnreachable = x_p0 {
            break 'm4663 Text::lit("unreachable!()");
        }
        if let crate::lower::model::Ex::XCall(f_p11, args_p12) = x_p0 {
            break 'm4663 Text::from(format!("{}({})", f_p11, &args(args_p12)));
        }
        if let crate::lower::model::Ex::XApply(f_p13, args_p14) = x_p0 {
            break 'm4663 Text::from(format!("{}({})", &tight(&**f_p13), &args(args_p14)));
        }
        if let crate::lower::model::Ex::XMethod(r_p15, m_p16, args_p17) = x_p0 {
            break 'm4663 Text::from(format!("{}.{}({})", &tight(&**r_p15), m_p16, &args(args_p17)));
        }
        if let crate::lower::model::Ex::XBin(op_p18, l_p19, r_p1a) = x_p0 {
            break 'm4663 Text::from(format!("{} {} {}", &operand(&**l_p19), op_p18, &operand(&**r_p1a)));
        }
        if let crate::lower::model::Ex::XUnary(op_p1b, y_p1c) = x_p0 {
            break 'm4663 Text::from(format!("{}{}", op_p1b, &operand(&**y_p1c)));
        }
        if let crate::lower::model::Ex::XCtor(p_p1d, args_p1e) = x_p0 {
            break 'm4663 Text::from(format!("{}({})", p_p1d, &args(args_p1e)));
        }
        if let crate::lower::model::Ex::XRecord(p_p1f, fs_p1g) = x_p0 {
            break 'm4663 Text::from(format!("{} {{ {} }}", p_p1f, &crate::syntax::lexer::chars::join(&run_to_end(each_job(fs_p1g.clone(), Rc::new(move |p0: (Text, crate::lower::model::Ex)| entered(once_job(move || {
                let (f_p1h, v_p1i) = p0;
                prism_rtl::Turn::More(Rc::new(FieldInit { f_p0: f_p1h.clone(), ex1: v_p1i.clone() }))
            }))) as Rc<dyn Fn((Text, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))));
        }
        if let crate::lower::model::Ex::XTuple(m4663_39_0) = x_p0 && (m4663_39_0.len() == 1) && let Some(one_p1j) = index(m4663_39_0, &Nat::from(0u32)) {
            break 'm4663 Text::from(format!("({},)", &expression(&one_p1j)));
        }
        if let crate::lower::model::Ex::XTuple(xs_p1k) = x_p0 {
            break 'm4663 Text::from(format!("({})", &args(xs_p1k)));
        }
        if let crate::lower::model::Ex::XVec(xs_p1l) = x_p0 {
            break 'm4663 Text::from(format!("vec![{}]", &args(xs_p1l)));
        }
        if let crate::lower::model::Ex::XText(t_p1m) = x_p0 {
            break 'm4663 Text::from(format!("Text::lit(\"{}\")", &crate::lower::expr::escape(t_p1m)));
        }
        if let crate::lower::model::Ex::XFormat(parts_p1n) = x_p0 {
            break 'm4663 format(parts_p1n);
        }
        if let crate::lower::model::Ex::XMatch(s_p1o, arms_p1p, fallback_p1q, _) = x_p0 {
            break 'm4663 crate::emit::rust::templates::items::match_block(&expression(&**s_p1o), &arms(arms_p1p, fallback_p1q));
        }
        if let crate::lower::model::Ex::XChain(label_p1r, s_p1s, arms_p1t, _) = x_p0 {
            break 'm4663 chain(&label(label_p1r), &**s_p1s, arms_p1t);
        }
        if let crate::lower::model::Ex::XIf(c_p1u, t_p1v, e_p20) = x_p0 {
            break 'm4663 if_expression(&**c_p1u, &**t_p1v, &**e_p20);
        }
        if let crate::lower::model::Ex::XBlock(m4663_47_0, e_p21) = x_p0 && (m4663_47_0.len() == 0) {
            break 'm4663 expression(&**e_p21);
        }
        if let crate::lower::model::Ex::XBlock(dos_p22, e_p23) = x_p0 {
            break 'm4663 crate::emit::rust::templates::items::block(&statements(dos_p22), &expression(&**e_p23));
        }
        if let crate::lower::model::Ex::XLabeled(label_p24, dos_p25, e_p26, _) = x_p0 {
            break 'm4663 crate::emit::rust::templates::items::labeled(&label(label_p24), &statements(dos_p25), &expression(&**e_p26));
        }
        if let crate::lower::model::Ex::XClosure(mv_p27, ps_p28, body_p29) = x_p0 {
            break 'm4663 Text::from(format!("{}|{}| {}", &(if *mv_p27 { Text::lit("move ") } else { Text::lit("") }), &crate::syntax::lexer::chars::join(&run_to_end(each_job(ps_p28.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                let p_p2a = p0;
                prism_rtl::Turn::More(Rc::new(Pattern_ { p_p0: p_p2a.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", ")), &expression(&**body_p29)));
        }
        if let crate::lower::model::Ex::XTry(y_p2b) = x_p0 {
            break 'm4663 Text::from(format!("{}?", &tight(&**y_p2b)));
        }
        if let crate::lower::model::Ex::XField(r_p2c, f_p2d) = x_p0 {
            break 'm4663 Text::from(format!("{}.{}", &tight(&**r_p2c), f_p2d));
        }
        if let crate::lower::model::Ex::XPart(r_p2e, k_p2f) = x_p0 {
            break 'm4663 Text::from(format!("{}.{}", &tight(&**r_p2e), k_p2f));
        }
        if let crate::lower::model::Ex::XDecode(t_p2g, y_p2h) = x_p0 {
            break 'm4663 Text::from(format!("{}::from_pod({})?", &decode_head(t_p2g), &expression(&**y_p2h)));
        }
        if let crate::lower::model::Ex::XCast(y_p2i, t_p2j) = x_p0 {
            break 'm4663 Text::from(format!("{} as {}", &tight(&**y_p2i), &type_(t_p2j)));
        }
        if let crate::lower::model::Ex::XTyped(y_p2k, _) = x_p0 {
            break 'm4663 expression(&**y_p2k);
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `Expression`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Expression: unbounded fn Ex -> Text
/// ```
pub struct Expression {
    pub x_p0: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for Expression {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let x_p0 = &self.x_p0;
        'm4663: {
            if let crate::lower::model::Ex::XVar(n_p1) = x_p0 {
                break 'm4663 prism_rtl::Turn::Finished(n_p1.clone());
            }
            if let crate::lower::model::Ex::XPath(p_p2) = x_p0 {
                break 'm4663 prism_rtl::Turn::Finished(p_p2.clone());
            }
            if let crate::lower::model::Ex::XSelf = x_p0 {
                break 'm4663 prism_rtl::Turn::Finished(Text::lit("self"));
            }
            if let crate::lower::model::Ex::XCx = x_p0 {
                break 'm4663 prism_rtl::Turn::Finished(Text::lit("cx"));
            }
            if let crate::lower::model::Ex::XConst(n_p3) = x_p0 {
                break 'm4663 prism_rtl::Turn::Finished(Text::from(format!("Self::{}", n_p3)));
            }
            if let crate::lower::model::Ex::XUnit = x_p0 {
                break 'm4663 prism_rtl::Turn::Finished(Text::lit("()"));
            }
            if let crate::lower::model::Ex::XNone = x_p0 {
                break 'm4663 prism_rtl::Turn::Finished(Text::lit("None"));
            }
            if let crate::lower::model::Ex::XBool(b_p4) = x_p0 {
                break 'm4663 if *b_p4 {
                    prism_rtl::Turn::Finished(Text::lit("true"))
                } else {
                    prism_rtl::Turn::Finished(Text::lit("false"))
                };
            }
            if let crate::lower::model::Ex::XNat(d_p5) = x_p0 {
                break 'm4663 if &len_text(d_p5) <= &Nat::from(9u32) {
                    prism_rtl::Turn::Finished(Text::from(format!("Nat::from({}u32)", d_p5)))
                } else {
                    if &len_text(d_p5) <= &Nat::from(18u32) {
                        prism_rtl::Turn::Finished(Text::from(format!("Nat::from_int(Int::from({}i64)).unwrap()", d_p5)))
                    } else {
                        prism_rtl::Turn::Finished(Text::from(format!("Nat::from_int(Int::parse(\"{}\").unwrap()).unwrap()", d_p5)))
                    }
                };
            }
            if let crate::lower::model::Ex::XInt(d_p6) = x_p0 {
                break 'm4663 if &len_text(&(if crate::syntax::lexer::chars::has_prefix(d_p6, &Text::lit("-")) {
                    crate::syntax::lexer::chars::after_first(d_p6)
                } else {
                    d_p6.clone()
                })) <= &Nat::from(18u32) {
                    prism_rtl::Turn::Finished(Text::from(format!("Int::from({})", d_p6)))
                } else {
                    prism_rtl::Turn::Finished(Text::from(format!("Int::parse(\"{}\").unwrap()", d_p6)))
                };
            }
            if let crate::lower::model::Ex::XByte(d_p7) = x_p0 {
                break 'm4663 prism_rtl::Turn::Finished(Text::from(format!("{}u8", d_p7)));
            }
            if let crate::lower::model::Ex::XFloat(d_p8) = x_p0 {
                break 'm4663 prism_rtl::Turn::Finished(Text::from(format!("Float({})", d_p8)));
            }
            if let crate::lower::model::Ex::XIndex(n_p9) = x_p0 {
                break 'm4663 prism_rtl::Turn::Finished(Text::from(format!("{}", n_p9)));
            }
            if let crate::lower::model::Ex::XChar(c_pa) = x_p0 {
                break 'm4663 prism_rtl::Turn::Finished(Text::from(format!("\'{}\'", &crate::lower::expr::char_escape(c_pa))));
            }
            if let crate::lower::model::Ex::XStr(t_pb) = x_p0 {
                break 'm4663 prism_rtl::Turn::Finished(Text::from(format!("\"{}\"", &crate::lower::expr::escape(t_pb))));
            }
            if let crate::lower::model::Ex::XRegex(p_pc, f_pd) = x_p0 {
                break 'm4663 prism_rtl::Turn::Finished(Text::from(format!("{{ thread_local!(static R: Regex = Regex::lit(\"{}\", \"{}\")); R.with(Regex::clone) }}", &crate::lower::expr::escape(p_pc), &crate::lower::expr::escape(f_pd))));
            }
            if let crate::lower::model::Ex::XReplacement(p_pe, r_pf, f_pg) = x_p0 {
                break 'm4663 prism_rtl::Turn::Finished(Text::from(format!("{{ thread_local!(static R: RegexReplacement = RegexReplacement::lit(\"{}\", \"{}\", \"{}\")); R.with(RegexReplacement::clone) }}", &crate::lower::expr::escape(p_pe), &crate::lower::expr::escape(f_pg), &crate::lower::expr::escape(r_pf))));
            }
            if let crate::lower::model::Ex::XRef(y_ph) = x_p0 {
                break 'm4663 {
                    let y_ph = (**y_ph).clone();
                    call_then(start_operand(y_ph.clone()), move |operand_5763: Text| prism_rtl::Turn::Finished(Text::from(format!("&{}", &operand_5763))))
                };
            }
            if let crate::lower::model::Ex::XRefMut(y_pi) = x_p0 {
                break 'm4663 {
                    let y_pi = (**y_pi).clone();
                    call_then(start_operand(y_pi.clone()), move |operand_5797: Text| prism_rtl::Turn::Finished(Text::from(format!("&mut {}", &operand_5797))))
                };
            }
            if let crate::lower::model::Ex::XDeref(y_pj) = x_p0 {
                break 'm4663 {
                    let y_pj = (**y_pj).clone();
                    call_then(start_operand(y_pj.clone()), move |operand_5826: Text| prism_rtl::Turn::Finished(Text::from(format!("*{}", &operand_5826))))
                };
            }
            if let crate::lower::model::Ex::XTarget(y_pk) = x_p0 {
                break 'm4663 {
                    let y_pk = (**y_pk).clone();
                    call_then(start_expression(y_pk.clone()), move |expression_5857: Text| prism_rtl::Turn::Finished(Text::from(format!("(*{})", &expression_5857))))
                };
            }
            if let crate::lower::model::Ex::XClone(y_pl) = x_p0 {
                break 'm4663 {
                    let y_pl = (**y_pl).clone();
                    call_then(start_tight(y_pl.clone()), move |tight_5889: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.clone()", &tight_5889))))
                };
            }
            if let crate::lower::model::Ex::XWeak(y_pm) = x_p0 {
                break 'm4663 {
                    let y_pm = (**y_pm).clone();
                    call_then(start_expression(y_pm.clone()), move |expression_5936: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc::downgrade({})", &expression_5936))))
                };
            }
            if let crate::lower::model::Ex::XUpgrade(y_pn) = x_p0 {
                break 'm4663 {
                    let y_pn = (**y_pn).clone();
                    call_then(start_tight(y_pn.clone()), move |tight_5970: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.upgrade()", &tight_5970))))
                };
            }
            if let crate::lower::model::Ex::XBreak(l_po, y_pp) = x_p0 {
                break 'm4663 {
                    let l_po = l_po.clone();
                    let y_pp = (**y_pp).clone();
                    call_then(start_expression(y_pp.clone()), move |expression_6025: Text| prism_rtl::Turn::Finished(Text::from(format!("break {} {}", &label(&l_po), &expression_6025))))
                };
            }
            if let crate::lower::model::Ex::XBreakLoop = x_p0 {
                break 'm4663 prism_rtl::Turn::Finished(Text::lit("break"));
            }
            if let crate::lower::model::Ex::XLater(y_pq) = x_p0 {
                break 'm4663 {
                    let y_pq = (**y_pq).clone();
                    call_then(start_expression(y_pq.clone()), move |expression_6102: Text| prism_rtl::Turn::Finished(Text::from(format!("Box::new(move |cx| {{ {}; Ok(()) }})", &expression_6102))))
                };
            }
            if let crate::lower::model::Ex::XFormatStr(parts_pr) = x_p0 {
                break 'm4663 prism_rtl::Turn::More(Rc::new(FormatStr { parts_p0: parts_pr.clone() }));
            }
            if let crate::lower::model::Ex::XIsCase(y_ps, m4663_28_1) = x_p0 && (m4663_28_1.len() == 0) {
                break 'm4663 prism_rtl::Turn::Finished(Text::lit("false"));
            }
            if let crate::lower::model::Ex::XIsCase(y_pt, cs_pu) = x_p0 {
                break 'm4663 {
                    let cs_pu = cs_pu.clone();
                    let y_pt = (**y_pt).clone();
                    call_then(start_expression(y_pt.clone()), move |expression_6226: Text| prism_rtl::Turn::Finished(Text::from(format!("matches!({}, {})", &expression_6226, &crate::syntax::lexer::chars::join(&each(&cs_pu, &(|c_pv: &Text| Text::from(format!("{}(..)", c_pv)))), &Text::lit(" | "))))))
                };
            }
            if let crate::lower::model::Ex::XRefusal(what_p10) = x_p0 {
                break 'm4663 prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::expr::lowering_refusal(), &crate::lower::expr::escape(what_p10))));
            }
            if let crate::lower::model::Ex::XUnreachable = x_p0 {
                break 'm4663 prism_rtl::Turn::Finished(Text::lit("unreachable!()"));
            }
            if let crate::lower::model::Ex::XCall(f_p11, args_p12) = x_p0 {
                break 'm4663 {
                    let args_p12 = args_p12.clone();
                    let f_p11 = f_p11.clone();
                    call_then(start_args(args_p12.clone()), move |args_6415: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &f_p11, &args_6415))))
                };
            }
            if let crate::lower::model::Ex::XApply(f_p13, args_p14) = x_p0 {
                break 'm4663 {
                    let args_p14 = args_p14.clone();
                    let f_p13 = (**f_p13).clone();
                    call_then(start_tight(f_p13.clone()), move |tight_6450: Text| call_then(start_args(args_p14.clone()), move |args_6460: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &tight_6450, &args_6460)))))
                };
            }
            if let crate::lower::model::Ex::XMethod(r_p15, m_p16, args_p17) = x_p0 {
                break 'm4663 {
                    let args_p17 = args_p17.clone();
                    let m_p16 = m_p16.clone();
                    let r_p15 = (**r_p15).clone();
                    call_then(start_tight(r_p15.clone()), move |tight_6499: Text| call_then(start_args(args_p17.clone()), move |args_6513: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.{}({})", &tight_6499, &m_p16, &args_6513)))))
                };
            }
            if let crate::lower::model::Ex::XBin(op_p18, l_p19, r_p1a) = x_p0 {
                break 'm4663 {
                    let l_p19 = (**l_p19).clone();
                    let op_p18 = op_p18.clone();
                    let r_p1a = (**r_p1a).clone();
                    call_then(start_operand(l_p19.clone()), move |operand_6547: Text| call_then(start_operand(r_p1a.clone()), move |operand_6564: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {} {}", &operand_6547, &op_p18, &operand_6564)))))
                };
            }
            if let crate::lower::model::Ex::XUnary(op_p1b, y_p1c) = x_p0 {
                break 'm4663 {
                    let op_p1b = op_p1b.clone();
                    let y_p1c = (**y_p1c).clone();
                    call_then(start_operand(y_p1c.clone()), move |operand_6600: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &op_p1b, &operand_6600))))
                };
            }
            if let crate::lower::model::Ex::XCtor(p_p1d, args_p1e) = x_p0 {
                break 'm4663 {
                    let args_p1e = args_p1e.clone();
                    let p_p1d = p_p1d.clone();
                    call_then(start_args(args_p1e.clone()), move |args_6637: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &p_p1d, &args_6637))))
                };
            }
            if let crate::lower::model::Ex::XRecord(p_p1f, fs_p1g) = x_p0 {
                break 'm4663 {
                    let fs_p1g = fs_p1g.clone();
                    let p_p1f = p_p1f.clone();
                    call_value(each_job(fs_p1g.clone(), Rc::new(move |p0: (Text, crate::lower::model::Ex)| entered(once_job(move || {
                        let (f_p1h, v_p1i) = p0;
                        prism_rtl::Turn::More(Rc::new(FieldInit { f_p0: f_p1h.clone(), ex1: v_p1i.clone() }))
                    }))) as Rc<dyn Fn((Text, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_6684: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{} {{ {} }}", &p_p1f, &crate::syntax::lexer::chars::join(&each_6684, &Text::lit(", "))))))
                };
            }
            if let crate::lower::model::Ex::XTuple(m4663_39_0) = x_p0 && (m4663_39_0.len() == 1) && let Some(one_p1j) = index(m4663_39_0, &Nat::from(0u32)) {
                break 'm4663 call_then(start_expression(one_p1j.clone()), move |expression_6755: Text| prism_rtl::Turn::Finished(Text::from(format!("({},)", &expression_6755))));
            }
            if let crate::lower::model::Ex::XTuple(xs_p1k) = x_p0 {
                break 'm4663 {
                    let xs_p1k = xs_p1k.clone();
                    call_then(start_args(xs_p1k.clone()), move |args_6792: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &args_6792))))
                };
            }
            if let crate::lower::model::Ex::XVec(xs_p1l) = x_p0 {
                break 'm4663 {
                    let xs_p1l = xs_p1l.clone();
                    call_then(start_args(xs_p1l.clone()), move |args_6823: Text| prism_rtl::Turn::Finished(Text::from(format!("vec![{}]", &args_6823))))
                };
            }
            if let crate::lower::model::Ex::XText(t_p1m) = x_p0 {
                break 'm4663 prism_rtl::Turn::Finished(Text::from(format!("Text::lit(\"{}\")", &crate::lower::expr::escape(t_p1m))));
            }
            if let crate::lower::model::Ex::XFormat(parts_p1n) = x_p0 {
                break 'm4663 prism_rtl::Turn::More(Rc::new(Format { parts_p0: parts_p1n.clone() }));
            }
            if let crate::lower::model::Ex::XMatch(s_p1o, arms_p1p, fallback_p1q, _) = x_p0 {
                break 'm4663 {
                    let arms_p1p = arms_p1p.clone();
                    let fallback_p1q = *fallback_p1q;
                    let s_p1o = (**s_p1o).clone();
                    call_then(start_expression(s_p1o.clone()), move |expression_6957: Text| call_then(start_arms(arms_p1p.clone(), fallback_p1q), move |arms_6973: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::match_block(&expression_6957, &arms_6973))))
                };
            }
            if let crate::lower::model::Ex::XChain(label_p1r, s_p1s, arms_p1t, _) = x_p0 {
                break 'm4663 prism_rtl::Turn::More(Rc::new(Chain { label_p0: label(label_p1r), s_p1: (**s_p1s).clone(), arms_p2: arms_p1t.clone() }));
            }
            if let crate::lower::model::Ex::XIf(c_p1u, t_p1v, e_p20) = x_p0 {
                break 'm4663 prism_rtl::Turn::More(Rc::new(IfExpression { c_p0: (**c_p1u).clone(), t_p1: (**t_p1v).clone(), e_p2: (**e_p20).clone() }));
            }
            if let crate::lower::model::Ex::XBlock(m4663_47_0, e_p21) = x_p0 && (m4663_47_0.len() == 0) {
                break 'm4663 prism_rtl::Turn::More(Rc::new(Expression { x_p0: (**e_p21).clone() }));
            }
            if let crate::lower::model::Ex::XBlock(dos_p22, e_p23) = x_p0 {
                break 'm4663 {
                    let dos_p22 = dos_p22.clone();
                    let e_p23 = (**e_p23).clone();
                    call_then(start_statements(dos_p22.clone()), move |statements_7155: Text| call_then(start_expression(e_p23.clone()), move |expression_7173: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::block(&statements_7155, &expression_7173))))
                };
            }
            if let crate::lower::model::Ex::XLabeled(label_p24, dos_p25, e_p26, _) = x_p0 {
                break 'm4663 {
                    let dos_p25 = dos_p25.clone();
                    let e_p26 = (**e_p26).clone();
                    let label_p24 = label_p24.clone();
                    call_then(start_statements(dos_p25.clone()), move |statements_7247: Text| call_then(start_expression(e_p26.clone()), move |expression_7265: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::labeled(&label(&label_p24), &statements_7247, &expression_7265))))
                };
            }
            if let crate::lower::model::Ex::XClosure(mv_p27, ps_p28, body_p29) = x_p0 {
                break 'm4663 {
                    let body_p29 = (**body_p29).clone();
                    let mv_p27 = *mv_p27;
                    let ps_p28 = ps_p28.clone();
                    call_value(each_job(ps_p28.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                        let p_p2a = p0;
                        prism_rtl::Turn::More(Rc::new(Pattern_ { p_p0: p_p2a.clone() }))
                    }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_7340: Array<Text>| call_then(start_expression(body_p29.clone()), move |expression_7374: Text| prism_rtl::Turn::Finished(Text::from(format!("{}|{}| {}", &(if mv_p27 { Text::lit("move ") } else { Text::lit("") }), &crate::syntax::lexer::chars::join(&each_7340, &Text::lit(", ")), &expression_7374)))))
                };
            }
            if let crate::lower::model::Ex::XTry(y_p2b) = x_p0 {
                break 'm4663 {
                    let y_p2b = (**y_p2b).clone();
                    call_then(start_tight(y_p2b.clone()), move |tight_7406: Text| prism_rtl::Turn::Finished(Text::from(format!("{}?", &tight_7406))))
                };
            }
            if let crate::lower::model::Ex::XField(r_p2c, f_p2d) = x_p0 {
                break 'm4663 {
                    let f_p2d = f_p2d.clone();
                    let r_p2c = (**r_p2c).clone();
                    call_then(start_tight(r_p2c.clone()), move |tight_7436: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.{}", &tight_7436, &f_p2d))))
                };
            }
            if let crate::lower::model::Ex::XPart(r_p2e, k_p2f) = x_p0 {
                break 'm4663 {
                    let k_p2f = k_p2f.clone();
                    let r_p2e = (**r_p2e).clone();
                    call_then(start_tight(r_p2e.clone()), move |tight_7468: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.{}", &tight_7468, &k_p2f))))
                };
            }
            if let crate::lower::model::Ex::XDecode(t_p2g, y_p2h) = x_p0 {
                break 'm4663 {
                    let t_p2g = t_p2g.clone();
                    let y_p2h = (**y_p2h).clone();
                    call_then(start_decode_head(t_p2g.clone()), move |decode_head_7502: Text| call_then(start_expression(y_p2h.clone()), move |expression_7527: Text| prism_rtl::Turn::Finished(Text::from(format!("{}::from_pod({})?", &decode_head_7502, &expression_7527)))))
                };
            }
            if let crate::lower::model::Ex::XCast(y_p2i, t_p2j) = x_p0 {
                break 'm4663 {
                    let t_p2j = t_p2j.clone();
                    let y_p2i = (**y_p2i).clone();
                    call_then(start_tight(y_p2i.clone()), move |tight_7562: Text| call_then(start_type_(t_p2j.clone()), move |type__7575: Text| prism_rtl::Turn::Finished(Text::from(format!("{} as {}", &tight_7562, &type__7575)))))
                };
            }
            if let crate::lower::model::Ex::XTyped(y_p2k, _) = x_p0 {
                break 'm4663 prism_rtl::Turn::More(Rc::new(Expression { x_p0: (**y_p2k).clone() }));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start Expression, x`: what the function value is when passed to `@Run`.
pub fn start_expression(x_p0: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Expression { x_p0 })
}

/// ```prism
/// FieldInit: unbounded fn Text, Ex -> Text
/// ```
pub fn field_init(f_p0: &Text, ex1: &crate::lower::model::Ex) -> Text {
    match ex1 {
        crate::lower::model::Ex::XVar(v_p1) => if v_p1 == f_p0 { f_p0.clone() } else { Text::from(format!("{}: {}", f_p0, v_p1)) },
        v_p3 => Text::from(format!("{}: {}", f_p0, &expression(v_p3))),
    }
}

/// The step machine of `FieldInit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldInit: unbounded fn Text, Ex -> Text
/// ```
pub struct FieldInit {
    pub f_p0: Text,
    pub ex1: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for FieldInit {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f_p0 = &self.f_p0;
        let ex1 = &self.ex1;
        match ex1 {
            crate::lower::model::Ex::XVar(v_p1) => if v_p1 == f_p0 {
                prism_rtl::Turn::Finished(f_p0.clone())
            } else {
                prism_rtl::Turn::Finished(Text::from(format!("{}: {}", f_p0, v_p1)))
            },
            v_p3 => {
                let f_p0 = f_p0.clone();
                let v_p3 = v_p3.clone();
                call_then(start_expression(v_p3.clone()), move |expression_7745: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f_p0, &expression_7745))))
            },
        }
    }
}

/// `Start FieldInit, x`: what the function value is when passed to `@Run`.
pub fn start_field_init(f_p0: Text, ex1: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FieldInit { f_p0, ex1 })
}

/// ```prism
/// DecodeHead: unbounded fn OutTy -> Text
/// ```
pub fn decode_head(t_p0: &crate::lower::model::OutTy) -> Text {
    match t_p0 {
        crate::lower::model::OutTy::OutNamed(n_p1, m7818_0_1) if (m7818_0_1.len() == 0) => n_p1.clone(),
        crate::lower::model::OutTy::OutNat => Text::lit("Nat"),
        crate::lower::model::OutTy::OutInt => Text::lit("Int"),
        crate::lower::model::OutTy::OutText => Text::lit("Text"),
        _ => Text::from(format!("<{}>", &type_(t_p0))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `DecodeHead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DecodeHead: unbounded fn OutTy -> Text
/// ```
pub struct DecodeHead {
    pub t_p0: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for DecodeHead {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::lower::model::OutTy::OutNamed(n_p1, m7818_0_1) if (m7818_0_1.len() == 0) => prism_rtl::Turn::Finished(n_p1.clone()),
            crate::lower::model::OutTy::OutNat => prism_rtl::Turn::Finished(Text::lit("Nat")),
            crate::lower::model::OutTy::OutInt => prism_rtl::Turn::Finished(Text::lit("Int")),
            crate::lower::model::OutTy::OutText => prism_rtl::Turn::Finished(Text::lit("Text")),
            _ => {
                let t_p0 = t_p0.clone();
                call_then(start_type_(t_p0.clone()), move |type__7925: Text| prism_rtl::Turn::Finished(Text::from(format!("<{}>", &type__7925))))
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start DecodeHead, x`: what the function value is when passed to `@Run`.
pub fn start_decode_head(t_p0: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(DecodeHead { t_p0 })
}

/// ```prism
/// Label: fn Text -> Text
/// ```
pub fn label(l_p0: &Text) -> Text {
    if crate::syntax::lexer::chars::has_prefix(l_p0, &Text::lit("\'")) {
        l_p0.clone()
    } else {
        Text::from(format!("\'{}", l_p0))
    }
}

/// ```prism
/// Format: unbounded fn [Ex] -> Text
/// ```
pub fn format(parts_p0: &Array<crate::lower::model::Ex>) -> Text {
    let lit_p1 = concat(&each(parts_p0, &(|p_p3: &crate::lower::model::Ex| format_piece(p_p3))));
    let vals_p2 = filter(parts_p0, &(|p_p4: &crate::lower::model::Ex| !is_text(p_p4)));
    if &len(&vals_p2) == &Nat::from(0u32) {
        Text::from(format!("Text::lit(\"{}\")", &crate::lower::expr::escape(&concat(&each(parts_p0, &(|p_p5: &crate::lower::model::Ex| plain_piece(p_p5)))))))
    } else {
        Text::from(format!("Text::from(format!(\"{}\", {}))", &lit_p1, &args(&vals_p2)))
    }
}

/// The step machine of `Format`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Format: unbounded fn [Ex] -> Text
/// ```
pub struct Format {
    pub parts_p0: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for Format {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let parts_p0 = &self.parts_p0;
        let lit_p1 = concat(&each(parts_p0, &(|p_p3: &crate::lower::model::Ex| format_piece(p_p3))));
        let vals_p2 = filter(parts_p0, &(|p_p4: &crate::lower::model::Ex| !is_text(p_p4)));
        if &len(&vals_p2) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished(Text::from(format!("Text::lit(\"{}\")", &crate::lower::expr::escape(&concat(&each(parts_p0, &(|p_p5: &crate::lower::model::Ex| plain_piece(p_p5))))))))
        } else {
            call_then(start_args(vals_p2.clone()), move |args_8440: Text| prism_rtl::Turn::Finished(Text::from(format!("Text::from(format!(\"{}\", {}))", &lit_p1, &args_8440))))
        }
    }
}

/// `Start Format, x`: what the function value is when passed to `@Run`.
pub fn start_format(parts_p0: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Format { parts_p0 })
}

/// ```prism
/// PlainPiece: fn Ex -> Text
/// ```
pub fn plain_piece(ex0: &crate::lower::model::Ex) -> Text {
    match ex0 {
        crate::lower::model::Ex::XText(t_p0) => t_p0.clone(),
        other_p1 => Text::lit(""),
    }
}

/// ```prism
/// FormatStr: unbounded fn [Ex] -> Text
/// ```
pub fn format_str(parts_p0: &Array<crate::lower::model::Ex>) -> Text {
    let lit_p1 = concat(&each(parts_p0, &(|p_p3: &crate::lower::model::Ex| str_piece(p_p3))));
    let vals_p2 = filter(parts_p0, &(|p_p4: &crate::lower::model::Ex| !is_text(p_p4) && !is_var(p_p4)));
    if &len(&vals_p2) == &Nat::from(0u32) {
        Text::from(format!("\"{}\"", &lit_p1))
    } else {
        Text::from(format!("format!(\"{}\", {})", &lit_p1, &args(&vals_p2)))
    }
}

/// The step machine of `FormatStr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FormatStr: unbounded fn [Ex] -> Text
/// ```
pub struct FormatStr {
    pub parts_p0: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for FormatStr {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let parts_p0 = &self.parts_p0;
        let lit_p1 = concat(&each(parts_p0, &(|p_p3: &crate::lower::model::Ex| str_piece(p_p3))));
        let vals_p2 = filter(parts_p0, &(|p_p4: &crate::lower::model::Ex| !is_text(p_p4) && !is_var(p_p4)));
        if &len(&vals_p2) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished(Text::from(format!("\"{}\"", &lit_p1)))
        } else {
            call_then(start_args(vals_p2.clone()), move |args_8905: Text| prism_rtl::Turn::Finished(Text::from(format!("format!(\"{}\", {})", &lit_p1, &args_8905))))
        }
    }
}

/// `Start FormatStr, x`: what the function value is when passed to `@Run`.
pub fn start_format_str(parts_p0: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FormatStr { parts_p0 })
}

/// ```prism
/// IsVar: fn Ex -> Bool
/// ```
pub fn is_var(ex0: &crate::lower::model::Ex) -> bool {
    match ex0 {
        crate::lower::model::Ex::XVar(_) => true,
        other_p0 => false,
    }
}

/// ```prism
/// StrPiece: fn Ex -> Text
/// ```
pub fn str_piece(ex0: &crate::lower::model::Ex) -> Text {
    match ex0 {
        crate::lower::model::Ex::XVar(n_p0) => Text::from(format!("{{{}}}", n_p0)),
        other_p1 => format_piece(other_p1),
    }
}

/// ```prism
/// IsText: fn Ex -> Bool
/// ```
pub fn is_text(ex0: &crate::lower::model::Ex) -> bool {
    match ex0 {
        crate::lower::model::Ex::XText(_) => true,
        other_p0 => false,
    }
}

/// ```prism
/// FormatPiece: fn Ex -> Text
/// ```
pub fn format_piece(ex0: &crate::lower::model::Ex) -> Text {
    match ex0 {
        crate::lower::model::Ex::XText(t_p0) => format_escape(&crate::lower::expr::escape(t_p0)),
        other_p1 => Text::lit("{}"),
    }
}

/// ```prism
/// FormatEscape: fn Text -> Text
/// ```
pub fn format_escape(t_p0: &Text) -> Text {
    crate::syntax::lexer::chars::map_chars(t_p0, &(Rc::new(move |p0: Text| once_job(move || {
        let c_p1 = p0;
        prism_rtl::Turn::Finished(format_escape_char(&c_p1))
    })) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>))
}

/// ```prism
/// FormatEscapeChar: fn Text -> Text
/// ```
pub fn format_escape_char(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("{")) => Text::lit("{{"),
        c1_0 if (c1_0 == &Text::lit("}")) => Text::lit("}}"),
        c_p0 => c_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IfExpression: unbounded fn Ex, Ex, Ex -> Text
/// ```
pub fn if_expression(c_p0: &crate::lower::model::Ex, t_p1: &crate::lower::model::Ex, e_p2: &crate::lower::model::Ex) -> Text {
    let ct_p3 = expression(c_p0);
    let tt_p4 = expression(t_p1);
    let et_p5 = expression(e_p2);
    let short_p6 = !crate::syntax::lexer::chars::contains(&Text::from(format!("{}{}", &tt_p4, &et_p5)), &Text::lit("\n")) && (&len_text(&Text::from(format!("{}{}{}", &ct_p3, &tt_p4, &et_p5))) < &Nat::from(70u32));
    if short_p6 {
        Text::from(format!("if {} {{ {} }} else {{ {} }}", &ct_p3, &tt_p4, &et_p5))
    } else {
        crate::emit::rust::templates::items::if_(&ct_p3, &tt_p4, &et_p5)
    }
}

/// The step machine of `IfExpression`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IfExpression: unbounded fn Ex, Ex, Ex -> Text
/// ```
pub struct IfExpression {
    pub c_p0: crate::lower::model::Ex,
    pub t_p1: crate::lower::model::Ex,
    pub e_p2: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for IfExpression {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let c_p0 = &self.c_p0;
        let t_p1 = &self.t_p1;
        let e_p2 = &self.e_p2;
        let c_p0 = c_p0.clone();
        let e_p2 = e_p2.clone();
        let t_p1 = t_p1.clone();
        call_then(start_expression(c_p0.clone()), move |expression_9643: Text| {
            let ct_p3 = expression_9643;
            call_then(start_expression(t_p1.clone()), move |expression_9669: Text| {
                let tt_p4 = expression_9669;
                call_then(start_expression(e_p2.clone()), move |expression_9695: Text| {
                    let et_p5 = expression_9695;
                    let short_p6 = !crate::syntax::lexer::chars::contains(&Text::from(format!("{}{}", &tt_p4, &et_p5)), &Text::lit("\n")) && (&len_text(&Text::from(format!("{}{}{}", &ct_p3, &tt_p4, &et_p5))) < &Nat::from(70u32));
                    if short_p6 {
                        prism_rtl::Turn::Finished(Text::from(format!("if {} {{ {} }} else {{ {} }}", &ct_p3, &tt_p4, &et_p5)))
                    } else {
                        prism_rtl::Turn::Finished(crate::emit::rust::templates::items::if_(&ct_p3, &tt_p4, &et_p5))
                    }
                })
            })
        })
    }
}

/// `Start IfExpression, x`: what the function value is when passed to `@Run`.
pub fn start_if_expression(c_p0: crate::lower::model::Ex, t_p1: crate::lower::model::Ex, e_p2: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(IfExpression { c_p0, t_p1, e_p2 })
}

/// ```prism
/// Arms: unbounded fn [XArm], Bool -> Text
/// ```
pub fn arms(arms_p0: &Array<crate::lower::model::XArm>, fallback_p1: &bool) -> Text {
    let lines_p2 = run_to_end(each_job(arms_p0.clone(), Rc::new(move |p0: crate::lower::model::XArm| entered(once_job(move || {
        let a_p4 = p0;
        prism_rtl::Turn::More(Rc::new(Arm { a_p0: a_p4.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>>>));
    let all_p3 = if *fallback_p1 {
        push(&lines_p2, &Text::lit("_ => unreachable!(\"no arm matched\"),"))
    } else {
        lines_p2.clone()
    };
    crate::syntax::lexer::chars::join(&all_p3, &Text::lit("\n"))
}

/// The step machine of `Arms`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Arms: unbounded fn [XArm], Bool -> Text
/// ```
pub struct Arms {
    pub arms_p0: Array<crate::lower::model::XArm>,
    pub fallback_p1: bool,
}

impl prism_rtl::Job<Text> for Arms {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let arms_p0 = &self.arms_p0;
        let fallback_p1 = &self.fallback_p1;
        let arms_p0 = arms_p0.clone();
        let fallback_p1 = *fallback_p1;
        call_value(each_job(arms_p0.clone(), Rc::new(move |p0: crate::lower::model::XArm| entered(once_job(move || {
            let a_p4 = p0;
            prism_rtl::Turn::More(Rc::new(Arm { a_p0: a_p4.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_10026: Array<Text>| {
            let lines_p2 = each_10026;
            let all_p3 = if fallback_p1 {
                push(&lines_p2, &Text::lit("_ => unreachable!(\"no arm matched\"),"))
            } else {
                lines_p2.clone()
            };
            prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&all_p3, &Text::lit("\n")))
        })
    }
}

/// `Start Arms, x`: what the function value is when passed to `@Run`.
pub fn start_arms(arms_p0: Array<crate::lower::model::XArm>, fallback_p1: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Arms { arms_p0, fallback_p1 })
}

/// ```prism
/// Arm: unbounded fn XArm -> Text
/// ```
pub fn arm(a_p0: &crate::lower::model::XArm) -> Text {
    let guard_p1 = if &len(&a_p0.conds) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" if {}", &crate::syntax::lexer::chars::join(&run_to_end(each_job(a_p0.conds.clone(), Rc::new(move |p0: crate::lower::model::Cc| entered(once_job(move || {
            let c_p3 = p0;
            prism_rtl::Turn::More(Rc::new(Condition { cc0: c_p3.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(" && "))))
    };
    let body_p2 = expression(&a_p0.body);
    Text::from(format!("{}{} => {},", &pattern(&a_p0.pat), &guard_p1, &body_p2))
}

/// The step machine of `Arm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Arm: unbounded fn XArm -> Text
/// ```
pub struct Arm {
    pub a_p0: crate::lower::model::XArm,
}

impl prism_rtl::Job<Text> for Arm {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let a_p0 = &self.a_p0;
        let guard_p1 = if &len(&a_p0.conds) == &Nat::from(0u32) {
            Text::lit("")
        } else {
            Text::from(format!(" if {}", &crate::syntax::lexer::chars::join(&run_to_end(each_job(a_p0.conds.clone(), Rc::new(move |p0: crate::lower::model::Cc| entered(once_job(move || {
                let c_p3 = p0;
                prism_rtl::Turn::More(Rc::new(Condition { cc0: c_p3.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(" && "))))
        };
        let a_p0 = a_p0.clone();
        call_then(start_expression(a_p0.body.clone()), move |expression_10318: Text| {
            let body_p2 = expression_10318;
            call_then(start_pattern(a_p0.pat.clone()), move |pattern_10342: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{} => {},", &pattern_10342, &guard_p1, &body_p2))))
        })
    }
}

/// `Start Arm, x`: what the function value is when passed to `@Run`.
pub fn start_arm(a_p0: crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Arm { a_p0 })
}

/// ```prism
/// Condition: unbounded fn Cc -> Text
/// ```
pub fn condition(cc0: &crate::lower::model::Cc) -> Text {
    match cc0 {
        crate::lower::model::Cc::CcIf(x_p0) => operand(x_p0),
        crate::lower::model::Cc::CcLet(p_p1, x_p2) => Text::from(format!("let {} = {}", &pattern(p_p1), &expression(x_p2))),
    }
}

/// The step machine of `Condition`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Condition: unbounded fn Cc -> Text
/// ```
pub struct Condition {
    pub cc0: crate::lower::model::Cc,
}

impl prism_rtl::Job<Text> for Condition {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cc0 = &self.cc0;
        match cc0 {
            crate::lower::model::Cc::CcIf(x_p0) => prism_rtl::Turn::More(Rc::new(Operand { x_p0: x_p0.clone() })),
            crate::lower::model::Cc::CcLet(p_p1, x_p2) => {
                let p_p1 = p_p1.clone();
                let x_p2 = x_p2.clone();
                call_then(start_pattern(p_p1.clone()), move |pattern_10480: Text| call_then(start_expression(x_p2.clone()), move |expression_10494: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {}", &pattern_10480, &expression_10494)))))
            },
        }
    }
}

/// `Start Condition, x`: what the function value is when passed to `@Run`.
pub fn start_condition(cc0: crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Condition { cc0 })
}

/// ```prism
/// Chain: unbounded fn Text, Ex, [XArm] -> Text
/// ```
pub fn chain(label_p0: &Text, s_p1: &crate::lower::model::Ex, arms_p2: &Array<crate::lower::model::XArm>) -> Text {
    let in_place_p3 = match s_p1 {
        crate::lower::model::Ex::XRef(y_p8) => is_bound(&**y_p8),
        _ => is_bound(s_p1),
    };
    let (bind_p9, scrut_pa) = if in_place_p3 {
        (Array::new(), expression(s_p1))
    } else {
        (Array::from(vec![Text::from(format!("let scrutinee = {};", &expression(s_p1)))]), Text::lit("scrutinee"))
    };
    let n_p4 = len(arms_p2);
    let lines_p5 = run_to_end(each_job(crate::check::errors::range0(&n_p4), {
        let arms_p2 = arms_p2.clone();
        let scrut_pa = scrut_pa.clone();
        let label_p0 = label_p0.clone();
        Rc::new(move |p0: Nat| {
            let arms_p2 = arms_p2.clone();
            let scrut_pa = scrut_pa.clone();
            let label_p0 = label_p0.clone();
            entered(once_job(move || {
                let i_pb = p0;
                {
                    let a_pc = or(&index(&arms_p2, &i_pb), &crate::lower::model::XArm { pat: crate::lower::model::Pa::PaWild, conds: Array::new(), body: crate::lower::model::Ex::XUnit });
                    let catch_all_pd = (&a_pc.pat == &crate::lower::model::Pa::PaWild) && (&len(&a_pc.conds) == &Nat::from(0u32));
                    if catch_all_pd {
                        prism_rtl::Turn::More(Rc::new(Expression { x_p0: a_pc.body.clone() }))
                    } else {
                        call_then(start_pattern(a_pc.pat.clone()), move |pattern_11207: Text| call_value(each_job(a_pc.conds.clone(), Rc::new(move |p0: crate::lower::model::Cc| entered(once_job(move || {
                            let c_pf = p0;
                            prism_rtl::Turn::More(Rc::new(Condition { cc0: c_pf.clone() }))
                        }))) as Rc<dyn Fn(crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_11237: Array<Text>| {
                            let head_pe = crate::syntax::lexer::chars::join(&append(&Array::from(vec![Text::from(format!("let {} = {}", &pattern_11207, &scrut_pa))]), &each_11237), &Text::lit(" && "));
                            call_then(start_expression(a_pc.body.clone()), move |expression_11324: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::chain_arm(&head_pe, &label_p0, &continued(&expression_11324, &Text::lit("    ")))))
                        }))
                    }
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let ends_p6 = match crate::syntax::lexer::chars::last(arms_p2) {
        Some(a_pg) => (&a_pg.pat == &crate::lower::model::Pa::PaWild) && (&len(&a_pg.conds) == &Nat::from(0u32)),
        None => false,
    };
    let tail_p7 = if ends_p6 {
        Array::new()
    } else {
        Array::from(vec![Text::lit("unreachable!(\"no clause matched\")")])
    };
    Text::from(format!("{}: {{\n{}\n}}", label_p0, &indent(&crate::syntax::lexer::chars::join(&append(&append(&bind_p9, &lines_p5), &tail_p7), &Text::lit("\n")))))
}

/// The step machine of `Chain`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Chain: unbounded fn Text, Ex, [XArm] -> Text
/// ```
pub struct Chain {
    pub label_p0: Text,
    pub s_p1: crate::lower::model::Ex,
    pub arms_p2: Array<crate::lower::model::XArm>,
}

impl prism_rtl::Job<Text> for Chain {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let label_p0 = &self.label_p0;
        let s_p1 = &self.s_p1;
        let arms_p2 = &self.arms_p2;
        let in_place_p3 = match s_p1 {
            crate::lower::model::Ex::XRef(y_p8) => is_bound(&**y_p8),
            _ => is_bound(s_p1),
        };
        let (bind_p9, scrut_pa) = if in_place_p3 {
            (Array::new(), expression(s_p1))
        } else {
            (Array::from(vec![Text::from(format!("let scrutinee = {};", &expression(s_p1)))]), Text::lit("scrutinee"))
        };
        let n_p4 = len(arms_p2);
        let arms_p2 = arms_p2.clone();
        let label_p0 = label_p0.clone();
        let s_p1 = s_p1.clone();
        call_value(each_job(crate::check::errors::range0(&n_p4), {
            let arms_p2 = arms_p2.clone();
            let scrut_pa = scrut_pa.clone();
            let label_p0 = label_p0.clone();
            Rc::new(move |p0: Nat| {
                let arms_p2 = arms_p2.clone();
                let scrut_pa = scrut_pa.clone();
                let label_p0 = label_p0.clone();
                entered(once_job(move || {
                    let i_pb = p0;
                    {
                        let a_pc = or(&index(&arms_p2, &i_pb), &crate::lower::model::XArm { pat: crate::lower::model::Pa::PaWild, conds: Array::new(), body: crate::lower::model::Ex::XUnit });
                        let catch_all_pd = (&a_pc.pat == &crate::lower::model::Pa::PaWild) && (&len(&a_pc.conds) == &Nat::from(0u32));
                        if catch_all_pd {
                            prism_rtl::Turn::More(Rc::new(Expression { x_p0: a_pc.body.clone() }))
                        } else {
                            call_then(start_pattern(a_pc.pat.clone()), move |pattern_11207: Text| call_value(each_job(a_pc.conds.clone(), Rc::new(move |p0: crate::lower::model::Cc| entered(once_job(move || {
                                let c_pf = p0;
                                prism_rtl::Turn::More(Rc::new(Condition { cc0: c_pf.clone() }))
                            }))) as Rc<dyn Fn(crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_11237: Array<Text>| {
                                let head_pe = crate::syntax::lexer::chars::join(&append(&Array::from(vec![Text::from(format!("let {} = {}", &pattern_11207, &scrut_pa))]), &each_11237), &Text::lit(" && "));
                                call_then(start_expression(a_pc.body.clone()), move |expression_11324: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::chain_arm(&head_pe, &label_p0, &continued(&expression_11324, &Text::lit("    ")))))
                            }))
                        }
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_10953: Array<Text>| {
            let lines_p5 = each_10953;
            let ends_p6 = match crate::syntax::lexer::chars::last(&arms_p2) {
                Some(a_pg) => (&a_pg.pat == &crate::lower::model::Pa::PaWild) && (&len(&a_pg.conds) == &Nat::from(0u32)),
                None => false,
            };
            let tail_p7 = if ends_p6 {
                Array::new()
            } else {
                Array::from(vec![Text::lit("unreachable!(\"no clause matched\")")])
            };
            prism_rtl::Turn::Finished(Text::from(format!("{}: {{\n{}\n}}", &label_p0, &indent(&crate::syntax::lexer::chars::join(&append(&append(&bind_p9, &lines_p5), &tail_p7), &Text::lit("\n"))))))
        })
    }
}

/// `Start Chain, x`: what the function value is when passed to `@Run`.
pub fn start_chain(label_p0: Text, s_p1: crate::lower::model::Ex, arms_p2: Array<crate::lower::model::XArm>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Chain { label_p0, s_p1, arms_p2 })
}

/// ```prism
/// IsBound: fn Ex -> Bool
/// ```
pub fn is_bound(x_p0: &crate::lower::model::Ex) -> bool {
    'm11828: {
        if let crate::lower::model::Ex::XVar(_) = x_p0 {
            break 'm11828 true;
        }
        if let crate::lower::model::Ex::XField(m11828_1_0, _) = x_p0 && let crate::lower::model::Ex::XSelf = &**m11828_1_0 {
            break 'm11828 true;
        }
        if let crate::lower::model::Ex::XField(m11828_2_0, _) = x_p0 && let crate::lower::model::Ex::XMethod(m11828_2_0_r_0, _, _) = &**m11828_2_0 && let crate::lower::model::Ex::XUpgrade(_) = &**m11828_2_0_r_0 {
            break 'm11828 true;
        }
        if let crate::lower::model::Ex::XTarget(_) = x_p0 {
            break 'm11828 true;
        }
        if let crate::lower::model::Ex::XPart(m11828_4_0, _) = x_p0 && let crate::lower::model::Ex::XVar(_) = &**m11828_4_0 {
            break 'm11828 true;
        }
        false
    }
}

/// ```prism
/// Continued: fn Text, Text -> Text
/// ```
pub fn continued(t_p0: &Text, pad_p1: &Text) -> Text {
    let ls_p2 = split_on(t_p0, &Text::lit("\n"));
    crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&len(&ls_p2)), &(|i_p3: &Nat| if (i_p3 == &Nat::from(0u32)) || (&or(&index(&ls_p2, i_p3), &Text::lit("")) == &Text::lit("")) {
        or(&index(&ls_p2, i_p3), &Text::lit(""))
    } else {
        Text::from(format!("{}{}", pad_p1, &or(&index(&ls_p2, i_p3), &Text::lit(""))))
    })), &Text::lit("\n"))
}

/// ```prism
/// BodyLines: unbounded fn Ex -> Text
/// ```
pub fn body_lines(ex0: &crate::lower::model::Ex) -> Text {
    match ex0 {
        crate::lower::model::Ex::XBlock(dos_p0, e_p1) => if &len(dos_p0) == &Nat::from(0u32) {
            body_lines(&**e_p1)
        } else {
            Text::from(format!("{}\n{}", &statements(dos_p0), &body_lines(&**e_p1)))
        },
        x_p2 => expression(x_p2),
    }
}

/// The step machine of `BodyLines`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BodyLines: unbounded fn Ex -> Text
/// ```
pub struct BodyLines {
    pub ex0: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for BodyLines {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let ex0 = &self.ex0;
        match ex0 {
            crate::lower::model::Ex::XBlock(dos_p0, e_p1) => if &len(dos_p0) == &Nat::from(0u32) {
                prism_rtl::Turn::More(Rc::new(BodyLines { ex0: (**e_p1).clone() }))
            } else {
                {
                    let dos_p0 = dos_p0.clone();
                    let e_p1 = (**e_p1).clone();
                    call_then(start_statements(dos_p0.clone()), move |statements_12514: Text| call_then(start_body_lines(e_p1.clone()), move |body_lines_12532: Text| prism_rtl::Turn::Finished(Text::from(format!("{}\n{}", &statements_12514, &body_lines_12532)))))
                }
            },
            x_p2 => prism_rtl::Turn::More(Rc::new(Expression { x_p0: x_p2.clone() })),
        }
    }
}

/// `Start BodyLines, x`: what the function value is when passed to `@Run`.
pub fn start_body_lines(ex0: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(BodyLines { ex0 })
}

/// ```prism
/// Indent: fn Text -> Text
/// ```
pub fn indent(t_p0: &Text) -> Text {
    crate::syntax::lexer::chars::join(&each(&split_on(t_p0, &Text::lit("\n")), &(|l_p1: &Text| if l_p1 == &Text::lit("") {
        Text::lit("")
    } else {
        Text::from(format!("    {}", l_p1))
    })), &Text::lit("\n"))
}

/// ```prism
/// Pattern: unbounded fn Pa -> Text
/// ```
pub fn pattern(p_p0: &crate::lower::model::Pa) -> Text {
    'm12983: {
        if let crate::lower::model::Pa::PaWild = p_p0 {
            break 'm12983 Text::lit("_");
        }
        if let crate::lower::model::Pa::PaBind(n_p1) = p_p0 {
            break 'm12983 n_p1.clone();
        }
        if let crate::lower::model::Pa::PaMut(n_p2) = p_p0 {
            break 'm12983 Text::from(format!("mut {}", n_p2));
        }
        if let crate::lower::model::Pa::PaCtor(c_p3, ps_p4) = p_p0 {
            break 'm12983 Text::from(format!("{}({})", c_p3, &crate::syntax::lexer::chars::join(&run_to_end(each_job(ps_p4.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                let q_p5 = p0;
                prism_rtl::Turn::More(Rc::new(Pattern_ { p_p0: q_p5.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))));
        }
        if let crate::lower::model::Pa::PaUnit(c_p6) = p_p0 {
            break 'm12983 c_p6.clone();
        }
        if let crate::lower::model::Pa::PaRecord(c_p7, fs_p8, rest_p9) = p_p0 {
            break 'm12983 {
                let parts_pa = run_to_end(each_job(fs_p8.clone(), Rc::new(move |p0: (Text, crate::lower::model::Pa)| entered(once_job(move || {
                    let (f_pc, q_pd) = p0;
                    match &q_pd {
                        crate::lower::model::Pa::PaBind(n_pe) => if n_pe == &f_pc {
                            prism_rtl::Turn::Finished(f_pc.clone())
                        } else {
                            prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f_pc, n_pe)))
                        },
                        _ => call_then(start_pattern(q_pd.clone()), move |pattern_13285: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f_pc, &pattern_13285)))),
                    }
                }))) as Rc<dyn Fn((Text, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Text>>>));
                let all_pb = if *rest_p9 { push(&parts_pa, &Text::lit("..")) } else { parts_pa.clone() };
                Text::from(format!("{} {{ {} }}", c_p7, &crate::syntax::lexer::chars::join(&all_pb, &Text::lit(", "))))
            };
        }
        if let crate::lower::model::Pa::PaTuple(m12983_6_0) = p_p0 && (m12983_6_0.len() == 1) && let Some(one_pf) = index(m12983_6_0, &Nat::from(0u32)) {
            break 'm12983 Text::from(format!("({},)", &pattern(&one_pf)));
        }
        if let crate::lower::model::Pa::PaTuple(ps_pg) = p_p0 {
            break 'm12983 Text::from(format!("({})", &crate::syntax::lexer::chars::join(&run_to_end(each_job(ps_pg.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                let q_ph = p0;
                prism_rtl::Turn::More(Rc::new(Pattern_ { p_p0: q_ph.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))));
        }
        if let crate::lower::model::Pa::PaChar(c_pi) = p_p0 {
            break 'm12983 Text::from(format!("\'{}\'", &crate::lower::expr::char_escape(c_pi)));
        }
        if let crate::lower::model::Pa::PaBool(b_pj) = p_p0 {
            break 'm12983 if *b_pj { Text::lit("true") } else { Text::lit("false") };
        }
        if let crate::lower::model::Pa::PaIndex(n_pk) = p_p0 {
            break 'm12983 Text::from(format!("{}", n_pk));
        }
        if let crate::lower::model::Pa::PaConst(n_pl) = p_p0 {
            break 'm12983 Text::from(format!("Self::{}", n_pl));
        }
        if let crate::lower::model::Pa::PaSlice(ps_pm) = p_p0 {
            break 'm12983 Text::from(format!("[{}]", &crate::syntax::lexer::chars::join(&run_to_end(each_job(ps_pm.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                let q_pn = p0;
                prism_rtl::Turn::More(Rc::new(Pattern_ { p_p0: q_pn.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))));
        }
        if let crate::lower::model::Pa::PaRest(m12983_13_0) = p_p0 && (m12983_13_0 == &Text::lit("")) {
            break 'm12983 Text::lit("..");
        }
        if let crate::lower::model::Pa::PaRest(n_po) = p_p0 {
            break 'm12983 Text::from(format!("{} @ ..", n_po));
        }
        if let crate::lower::model::Pa::PaTyped(q_pp, t_pq) = p_p0 {
            break 'm12983 Text::from(format!("{}: {}", &pattern(&**q_pp), &type_(t_pq)));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `Pattern_`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Pattern: unbounded fn Pa -> Text
/// ```
pub struct Pattern_ {
    pub p_p0: crate::lower::model::Pa,
}

impl prism_rtl::Job<Text> for Pattern_ {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let p_p0 = &self.p_p0;
        'm12983: {
            if let crate::lower::model::Pa::PaWild = p_p0 {
                break 'm12983 prism_rtl::Turn::Finished(Text::lit("_"));
            }
            if let crate::lower::model::Pa::PaBind(n_p1) = p_p0 {
                break 'm12983 prism_rtl::Turn::Finished(n_p1.clone());
            }
            if let crate::lower::model::Pa::PaMut(n_p2) = p_p0 {
                break 'm12983 prism_rtl::Turn::Finished(Text::from(format!("mut {}", n_p2)));
            }
            if let crate::lower::model::Pa::PaCtor(c_p3, ps_p4) = p_p0 {
                break 'm12983 {
                    let c_p3 = c_p3.clone();
                    let ps_p4 = ps_p4.clone();
                    call_value(each_job(ps_p4.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                        let q_p5 = p0;
                        prism_rtl::Turn::More(Rc::new(Pattern_ { p_p0: q_p5.clone() }))
                    }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_13077: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &c_p3, &crate::syntax::lexer::chars::join(&each_13077, &Text::lit(", "))))))
                };
            }
            if let crate::lower::model::Pa::PaUnit(c_p6) = p_p0 {
                break 'm12983 prism_rtl::Turn::Finished(c_p6.clone());
            }
            if let crate::lower::model::Pa::PaRecord(c_p7, fs_p8, rest_p9) = p_p0 {
                break 'm12983 {
                    let c_p7 = c_p7.clone();
                    let fs_p8 = fs_p8.clone();
                    let rest_p9 = *rest_p9;
                    call_value(each_job(fs_p8.clone(), Rc::new(move |p0: (Text, crate::lower::model::Pa)| entered(once_job(move || {
                        let (f_pc, q_pd) = p0;
                        match &q_pd {
                            crate::lower::model::Pa::PaBind(n_pe) => if n_pe == &f_pc {
                                prism_rtl::Turn::Finished(f_pc.clone())
                            } else {
                                prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f_pc, n_pe)))
                            },
                            _ => call_then(start_pattern(q_pd.clone()), move |pattern_13285: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f_pc, &pattern_13285)))),
                        }
                    }))) as Rc<dyn Fn((Text, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_13173: Array<Text>| {
                        let parts_pa = each_13173;
                        let all_pb = if rest_p9 { push(&parts_pa, &Text::lit("..")) } else { parts_pa.clone() };
                        prism_rtl::Turn::Finished(Text::from(format!("{} {{ {} }}", &c_p7, &crate::syntax::lexer::chars::join(&all_pb, &Text::lit(", ")))))
                    })
                };
            }
            if let crate::lower::model::Pa::PaTuple(m12983_6_0) = p_p0 && (m12983_6_0.len() == 1) && let Some(one_pf) = index(m12983_6_0, &Nat::from(0u32)) {
                break 'm12983 call_then(start_pattern(one_pf.clone()), move |pattern_13414: Text| prism_rtl::Turn::Finished(Text::from(format!("({},)", &pattern_13414))));
            }
            if let crate::lower::model::Pa::PaTuple(ps_pg) = p_p0 {
                break 'm12983 {
                    let ps_pg = ps_pg.clone();
                    call_value(each_job(ps_pg.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                        let q_ph = p0;
                        prism_rtl::Turn::More(Rc::new(Pattern_ { p_p0: q_ph.clone() }))
                    }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_13455: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("({})", &crate::syntax::lexer::chars::join(&each_13455, &Text::lit(", "))))))
                };
            }
            if let crate::lower::model::Pa::PaChar(c_pi) = p_p0 {
                break 'm12983 prism_rtl::Turn::Finished(Text::from(format!("\'{}\'", &crate::lower::expr::char_escape(c_pi))));
            }
            if let crate::lower::model::Pa::PaBool(b_pj) = p_p0 {
                break 'm12983 if *b_pj {
                    prism_rtl::Turn::Finished(Text::lit("true"))
                } else {
                    prism_rtl::Turn::Finished(Text::lit("false"))
                };
            }
            if let crate::lower::model::Pa::PaIndex(n_pk) = p_p0 {
                break 'm12983 prism_rtl::Turn::Finished(Text::from(format!("{}", n_pk)));
            }
            if let crate::lower::model::Pa::PaConst(n_pl) = p_p0 {
                break 'm12983 prism_rtl::Turn::Finished(Text::from(format!("Self::{}", n_pl)));
            }
            if let crate::lower::model::Pa::PaSlice(ps_pm) = p_p0 {
                break 'm12983 {
                    let ps_pm = ps_pm.clone();
                    call_value(each_job(ps_pm.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                        let q_pn = p0;
                        prism_rtl::Turn::More(Rc::new(Pattern_ { p_p0: q_pn.clone() }))
                    }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_13636: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("[{}]", &crate::syntax::lexer::chars::join(&each_13636, &Text::lit(", "))))))
                };
            }
            if let crate::lower::model::Pa::PaRest(m12983_13_0) = p_p0 && (m12983_13_0 == &Text::lit("")) {
                break 'm12983 prism_rtl::Turn::Finished(Text::lit(".."));
            }
            if let crate::lower::model::Pa::PaRest(n_po) = p_p0 {
                break 'm12983 prism_rtl::Turn::Finished(Text::from(format!("{} @ ..", n_po)));
            }
            if let crate::lower::model::Pa::PaTyped(q_pp, t_pq) = p_p0 {
                break 'm12983 {
                    let q_pp = (**q_pp).clone();
                    let t_pq = t_pq.clone();
                    call_then(start_pattern(q_pp.clone()), move |pattern_13735: Text| call_then(start_type_(t_pq.clone()), move |type__13748: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &pattern_13735, &type__13748)))))
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start Pattern_, x`: what the function value is when passed to `@Run`.
pub fn start_pattern(p_p0: crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Pattern_ { p_p0 })
}

/// ```prism
/// Statements: unbounded fn [Do] -> Text
/// ```
pub fn statements(dos_p0: &Array<crate::lower::model::Do>) -> Text {
    crate::syntax::lexer::chars::join(&run_to_end(each_job(dos_p0.clone(), Rc::new(move |p0: crate::lower::model::Do| entered(once_job(move || {
        let d_p1 = p0;
        prism_rtl::Turn::More(Rc::new(Statement { d_p0: d_p1.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))
}

/// The step machine of `Statements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Statements: unbounded fn [Do] -> Text
/// ```
pub struct Statements {
    pub dos_p0: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for Statements {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let dos_p0 = &self.dos_p0;
        let dos_p0 = dos_p0.clone();
        call_value(each_job(dos_p0.clone(), Rc::new(move |p0: crate::lower::model::Do| entered(once_job(move || {
            let d_p1 = p0;
            prism_rtl::Turn::More(Rc::new(Statement { d_p0: d_p1.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_13822: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&each_13822, &Text::lit("\n"))))
    }
}

/// `Start Statements, x`: what the function value is when passed to `@Run`.
pub fn start_statements(dos_p0: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Statements { dos_p0 })
}

/// ```prism
/// Statement: unbounded fn Do -> Text
/// ```
pub fn statement(d_p0: &crate::lower::model::Do) -> Text {
    match d_p0 {
        crate::lower::model::Do::DoLet(p_p1, x_p2) => Text::from(format!("let {} = {};", &pattern(p_p1), &expression(x_p2))),
        crate::lower::model::Do::DoLetElse(p_p3, x_p4, e_p5) => Text::from(format!("let {} = {} else {{ {} }};", &pattern(p_p3), &expression(x_p4), &expression(e_p5))),
        crate::lower::model::Do::DoAssign(p_p6, x_p7) => Text::from(format!("{} = {};", &expression(p_p6), &expression(x_p7))),
        crate::lower::model::Do::DoWhile(c_p8, body_p9) => crate::emit::rust::templates::items::if_stmt(&Text::from(format!("while {}", &expression(c_p8))), &statements(body_p9)),
        crate::lower::model::Do::DoWhileLet(p_pa, x_pb, body_pc) => crate::emit::rust::templates::items::if_stmt(&Text::from(format!("while let {} = {}", &pattern(p_pa), &expression(x_pb))), &statements(body_pc)),
        crate::lower::model::Do::DoFor(p_pd, x_pe, body_pf) => crate::emit::rust::templates::items::if_stmt(&Text::from(format!("for {} in {}", &pattern(p_pd), &expression(x_pe))), &statements(body_pf)),
        crate::lower::model::Do::DoExpr(x_pg) => Text::from(format!("{};", &expression(x_pg))),
        crate::lower::model::Do::DoIf(c_ph, t_pi, e_pj) => Text::from(format!("{}{}", &crate::emit::rust::templates::items::if_stmt(&Text::from(format!("if {}", &expression(c_ph))), &statements(t_pi)), &else_branch(e_pj))),
        crate::lower::model::Do::DoIfLet(p_pk, x_pl, t_pm, e_pn) => Text::from(format!("{}{}", &crate::emit::rust::templates::items::if_stmt(&Text::from(format!("if let {} = {}", &pattern(p_pk), &expression(x_pl))), &statements(t_pm)), &else_branch(e_pn))),
        crate::lower::model::Do::DoMatch(x_po, cases_pp) => crate::emit::rust::templates::items::match_block(&expression(x_po), &crate::syntax::lexer::chars::join(&run_to_end(each_job(cases_pp.clone(), Rc::new(move |p0: (crate::lower::model::Pa, Array<crate::lower::model::Do>)| entered(once_job(move || {
            let (p_pq, body_pr) = p0;
            call_then(start_pattern(p_pq.clone()), move |pattern_14664: Text| call_then(start_statements(body_pr.clone()), move |statements_14677: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::arm_block(&pattern_14664, &statements_14677))))
        }))) as Rc<dyn Fn((crate::lower::model::Pa, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))),
        crate::lower::model::Do::DoReturn(x_ps) => Text::from(format!("return {};", &expression(x_ps))),
        crate::lower::model::Do::DoBlock(body_pt) => crate::emit::rust::templates::items::scope(&statements(body_pt)),
        crate::lower::model::Do::DoScope(body_pu) => Text::from(format!("{{ {} }};", &inline_statements(body_pu))),
        crate::lower::model::Do::DoLine(body_pv) => Text::from(format!("{};", &inline_statements(body_pv))),
        crate::lower::model::Do::DoNote(t_p10) => Text::from(format!("// {}", t_p10)),
    }
}

/// The step machine of `Statement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Statement: unbounded fn Do -> Text
/// ```
pub struct Statement {
    pub d_p0: crate::lower::model::Do,
}

impl prism_rtl::Job<Text> for Statement {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let d_p0 = &self.d_p0;
        match d_p0 {
            crate::lower::model::Do::DoLet(p_p1, x_p2) => {
                let p_p1 = p_p1.clone();
                let x_p2 = x_p2.clone();
                call_then(start_pattern(p_p1.clone()), move |pattern_13940: Text| call_then(start_expression(x_p2.clone()), move |expression_13954: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {};", &pattern_13940, &expression_13954)))))
            },
            crate::lower::model::Do::DoLetElse(p_p3, x_p4, e_p5) => {
                let e_p5 = e_p5.clone();
                let p_p3 = p_p3.clone();
                let x_p4 = x_p4.clone();
                call_then(start_pattern(p_p3.clone()), move |pattern_13999: Text| call_then(start_expression(x_p4.clone()), move |expression_14013: Text| call_then(start_expression(e_p5.clone()), move |expression_14036: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {} else {{ {} }};", &pattern_13999, &expression_14013, &expression_14036))))))
            },
            crate::lower::model::Do::DoAssign(p_p6, x_p7) => {
                let p_p6 = p_p6.clone();
                let x_p7 = x_p7.clone();
                call_then(start_expression(p_p6.clone()), move |expression_14076: Text| call_then(start_expression(x_p7.clone()), move |expression_14093: Text| prism_rtl::Turn::Finished(Text::from(format!("{} = {};", &expression_14076, &expression_14093)))))
            },
            crate::lower::model::Do::DoWhile(c_p8, body_p9) => {
                let body_p9 = body_p9.clone();
                let c_p8 = c_p8.clone();
                call_then(start_expression(c_p8.clone()), move |expression_14145: Text| call_then(start_statements(body_p9.clone()), move |statements_14162: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::if_stmt(&Text::from(format!("while {}", &expression_14145)), &statements_14162))))
            },
            crate::lower::model::Do::DoWhileLet(p_pa, x_pb, body_pc) => {
                let body_pc = body_pc.clone();
                let p_pa = p_pa.clone();
                let x_pb = x_pb.clone();
                call_then(start_pattern(p_pa.clone()), move |pattern_14225: Text| call_then(start_expression(x_pb.clone()), move |expression_14239: Text| call_then(start_statements(body_pc.clone()), move |statements_14256: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::if_stmt(&Text::from(format!("while let {} = {}", &pattern_14225, &expression_14239)), &statements_14256)))))
            },
            crate::lower::model::Do::DoFor(p_pd, x_pe, body_pf) => {
                let body_pf = body_pf.clone();
                let p_pd = p_pd.clone();
                let x_pe = x_pe.clone();
                call_then(start_pattern(p_pd.clone()), move |pattern_14308: Text| call_then(start_expression(x_pe.clone()), move |expression_14323: Text| call_then(start_statements(body_pf.clone()), move |statements_14340: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::if_stmt(&Text::from(format!("for {} in {}", &pattern_14308, &expression_14323)), &statements_14340)))))
            },
            crate::lower::model::Do::DoExpr(x_pg) => {
                let x_pg = x_pg.clone();
                call_then(start_expression(x_pg.clone()), move |expression_14373: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &expression_14373))))
            },
            crate::lower::model::Do::DoIf(c_ph, t_pi, e_pj) => {
                let c_ph = c_ph.clone();
                let e_pj = e_pj.clone();
                let t_pi = t_pi.clone();
                call_then(start_expression(c_ph.clone()), move |expression_14421: Text| call_then(start_statements(t_pi.clone()), move |statements_14438: Text| call_then(start_else_branch(e_pj.clone()), move |else_branch_14453: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &crate::emit::rust::templates::items::if_stmt(&Text::from(format!("if {}", &expression_14421)), &statements_14438), &else_branch_14453))))))
            },
            crate::lower::model::Do::DoIfLet(p_pk, x_pl, t_pm, e_pn) => {
                let e_pn = e_pn.clone();
                let p_pk = p_pk.clone();
                let t_pm = t_pm.clone();
                let x_pl = x_pl.clone();
                call_then(start_pattern(p_pk.clone()), move |pattern_14510: Text| call_then(start_expression(x_pl.clone()), move |expression_14524: Text| call_then(start_statements(t_pm.clone()), move |statements_14541: Text| call_then(start_else_branch(e_pn.clone()), move |else_branch_14556: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &crate::emit::rust::templates::items::if_stmt(&Text::from(format!("if let {} = {}", &pattern_14510, &expression_14524)), &statements_14541), &else_branch_14556)))))))
            },
            crate::lower::model::Do::DoMatch(x_po, cases_pp) => {
                let cases_pp = cases_pp.clone();
                let x_po = x_po.clone();
                call_then(start_expression(x_po.clone()), move |expression_14605: Text| call_value(each_job(cases_pp.clone(), Rc::new(move |p0: (crate::lower::model::Pa, Array<crate::lower::model::Do>)| entered(once_job(move || {
                    let (p_pq, body_pr) = p0;
                    call_then(start_pattern(p_pq.clone()), move |pattern_14664: Text| call_then(start_statements(body_pr.clone()), move |statements_14677: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::arm_block(&pattern_14664, &statements_14677))))
                }))) as Rc<dyn Fn((crate::lower::model::Pa, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_14627: Array<Text>| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::match_block(&expression_14605, &crate::syntax::lexer::chars::join(&each_14627, &Text::lit("\n"))))))
            },
            crate::lower::model::Do::DoReturn(x_ps) => {
                let x_ps = x_ps.clone();
                call_then(start_expression(x_ps.clone()), move |expression_14727: Text| prism_rtl::Turn::Finished(Text::from(format!("return {};", &expression_14727))))
            },
            crate::lower::model::Do::DoBlock(body_pt) => {
                let body_pt = body_pt.clone();
                call_then(start_statements(body_pt.clone()), move |statements_14768: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::scope(&statements_14768)))
            },
            crate::lower::model::Do::DoScope(body_pu) => {
                let body_pu = body_pu.clone();
                call_then(start_inline_statements(body_pu.clone()), move |inline_statements_14808: Text| prism_rtl::Turn::Finished(Text::from(format!("{{ {} }};", &inline_statements_14808))))
            },
            crate::lower::model::Do::DoLine(body_pv) => {
                let body_pv = body_pv.clone();
                call_then(start_inline_statements(body_pv.clone()), move |inline_statements_14855: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &inline_statements_14855))))
            },
            crate::lower::model::Do::DoNote(t_p10) => prism_rtl::Turn::Finished(Text::from(format!("// {}", t_p10))),
        }
    }
}

/// `Start Statement, x`: what the function value is when passed to `@Run`.
pub fn start_statement(d_p0: crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Statement { d_p0 })
}

/// ```prism
/// InlineStatements: unbounded fn [Do] -> Text
/// ```
pub fn inline_statements(dos_p0: &Array<crate::lower::model::Do>) -> Text {
    crate::syntax::lexer::chars::join(&run_to_end(each_job(dos_p0.clone(), Rc::new(move |p0: crate::lower::model::Do| entered(once_job(move || {
        let d_p1 = p0;
        prism_rtl::Turn::More(Rc::new(InlineStatement { do_0: d_p1.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(" "))
}

/// The step machine of `InlineStatements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InlineStatements: unbounded fn [Do] -> Text
/// ```
pub struct InlineStatements {
    pub dos_p0: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for InlineStatements {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let dos_p0 = &self.dos_p0;
        let dos_p0 = dos_p0.clone();
        call_value(each_job(dos_p0.clone(), Rc::new(move |p0: crate::lower::model::Do| entered(once_job(move || {
            let d_p1 = p0;
            prism_rtl::Turn::More(Rc::new(InlineStatement { do_0: d_p1.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_15028: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&each_15028, &Text::lit(" "))))
    }
}

/// `Start InlineStatements, x`: what the function value is when passed to `@Run`.
pub fn start_inline_statements(dos_p0: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(InlineStatements { dos_p0 })
}

/// ```prism
/// InlineStatement: unbounded fn Do -> Text
/// ```
pub fn inline_statement(do_0: &crate::lower::model::Do) -> Text {
    match do_0 {
        crate::lower::model::Do::DoIf(c_p0, t_p1, c0_0_2) if (c0_0_2.len() == 0) => Text::from(format!("if {} {{ {} }}", &expression(c_p0), &inline_statements(t_p1))),
        d_p2 => statement(d_p2),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `InlineStatement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InlineStatement: unbounded fn Do -> Text
/// ```
pub struct InlineStatement {
    pub do_0: crate::lower::model::Do,
}

impl prism_rtl::Job<Text> for InlineStatement {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let do_0 = &self.do_0;
        match do_0 {
            crate::lower::model::Do::DoIf(c_p0, t_p1, j0_0_2) if (j0_0_2.len() == 0) => {
                let c_p0 = c_p0.clone();
                let t_p1 = t_p1.clone();
                call_then(start_expression(c_p0.clone()), move |expression_15153: Text| call_then(start_inline_statements(t_p1.clone()), move |inline_statements_15171: Text| prism_rtl::Turn::Finished(Text::from(format!("if {} {{ {} }}", &expression_15153, &inline_statements_15171)))))
            },
            d_p2 => prism_rtl::Turn::More(Rc::new(Statement { d_p0: d_p2.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start InlineStatement, x`: what the function value is when passed to `@Run`.
pub fn start_inline_statement(do_0: crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(InlineStatement { do_0 })
}

/// ```prism
/// ElseBranch: unbounded fn [Do] -> Text
/// ```
pub fn else_branch(xs0: &Array<crate::lower::model::Do>) -> Text {
    'c: {
        if let c0_0 = xs0 && (c0_0.len() == 0) {
            break 'c Text::lit("");
        }
        if let c1_0 = xs0 && (c1_0.len() == 1) && let Some(crate::lower::model::Do::DoIf(c_p0, t_p1, e_p2)) = index(c1_0, &Nat::from(0u32)) {
            break 'c Text::from(format!(" else {}", &statement(&crate::lower::model::Do::DoIf(c_p0.clone(), t_p1.clone(), e_p2.clone()))));
        }
        if let c2_0 = xs0 && (c2_0.len() == 1) && let Some(crate::lower::model::Do::DoIfLet(p_p3, x_p4, t_p5, e_p6)) = index(c2_0, &Nat::from(0u32)) {
            break 'c Text::from(format!(" else {}", &statement(&crate::lower::model::Do::DoIfLet(p_p3.clone(), x_p4.clone(), t_p5.clone(), e_p6.clone()))));
        }
        if let body_p7 = xs0 {
            break 'c crate::emit::rust::templates::items::else_(&statements(body_p7));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `ElseBranch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ElseBranch: unbounded fn [Do] -> Text
/// ```
pub struct ElseBranch {
    pub xs0: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for ElseBranch {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let xs0 = &self.xs0;
        'j: {
            if let j0_0 = xs0 && (j0_0.len() == 0) {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let j1_0 = xs0 && (j1_0.len() == 1) && let Some(crate::lower::model::Do::DoIf(c_p0, t_p1, e_p2)) = index(j1_0, &Nat::from(0u32)) {
                break 'j call_then(start_statement(crate::lower::model::Do::DoIf(c_p0.clone(), t_p1.clone(), e_p2.clone())), move |statement_15383: Text| prism_rtl::Turn::Finished(Text::from(format!(" else {}", &statement_15383))));
            }
            if let j2_0 = xs0 && (j2_0.len() == 1) && let Some(crate::lower::model::Do::DoIfLet(p_p3, x_p4, t_p5, e_p6)) = index(j2_0, &Nat::from(0u32)) {
                break 'j call_then(start_statement(crate::lower::model::Do::DoIfLet(p_p3.clone(), x_p4.clone(), t_p5.clone(), e_p6.clone())), move |statement_15459: Text| prism_rtl::Turn::Finished(Text::from(format!(" else {}", &statement_15459))));
            }
            if let body_p7 = xs0 {
                break 'j {
                    let body_p7 = body_p7.clone();
                    call_then(start_statements(body_p7.clone()), move |statements_15519: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::else_(&statements_15519)))
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start ElseBranch, x`: what the function value is when passed to `@Run`.
pub fn start_else_branch(xs0: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ElseBranch { xs0 })
}
