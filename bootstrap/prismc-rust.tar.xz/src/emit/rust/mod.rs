//! The module `Emit.Rust`, from `target/bootstrap/src/prismc/emit/rust/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod prelude;
pub mod templates;

/// ```prism
/// Type: unbounded fn OutTy -> Text
/// ```
pub fn type_(t: &crate::lower::model::OutTy) -> Text {
    'm1081: {
        if let crate::lower::model::OutTy::OutNat = t {
            break 'm1081 Text::lit("Nat");
        }
        if let crate::lower::model::OutTy::OutInt = t {
            break 'm1081 Text::lit("Int");
        }
        if let crate::lower::model::OutTy::OutU8 = t {
            break 'm1081 Text::lit("u8");
        }
        if let crate::lower::model::OutTy::OutFloat = t {
            break 'm1081 Text::lit("f64");
        }
        if let crate::lower::model::OutTy::OutBool = t {
            break 'm1081 Text::lit("bool");
        }
        if let crate::lower::model::OutTy::OutChar = t {
            break 'm1081 Text::lit("char");
        }
        if let crate::lower::model::OutTy::OutText = t {
            break 'm1081 Text::lit("Text");
        }
        if let crate::lower::model::OutTy::OutCursor = t {
            break 'm1081 Text::lit("Cursor");
        }
        if let crate::lower::model::OutTy::OutUnit = t {
            break 'm1081 Text::lit("()");
        }
        if let crate::lower::model::OutTy::OutPath = t {
            break 'm1081 Text::lit("Path");
        }
        if let crate::lower::model::OutTy::OutDuration = t {
            break 'm1081 Text::lit("Duration");
        }
        if let crate::lower::model::OutTy::OutError = t {
            break 'm1081 Text::lit("Error");
        }
        if let crate::lower::model::OutTy::OutNamed(n, m1081_12_1) = t && (m1081_12_1.len() == 0) {
            break 'm1081 n.clone();
        }
        if let crate::lower::model::OutTy::OutNamed(n, args_) = t {
            break 'm1081 Text::from(format!("{}<{}>", n, &types(args_)));
        }
        if let crate::lower::model::OutTy::OutOpt(i) = t {
            break 'm1081 Text::from(format!("Option<{}>", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutRes(i) = t {
            break 'm1081 Text::from(format!("Result<{}, Error>", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutTuple(m1081_16_0) = t && (m1081_16_0.len() == 1) && let Some(one) = index(m1081_16_0, &Nat::from(0u32)) {
            break 'm1081 Text::from(format!("({},)", &type_(&one)));
        }
        if let crate::lower::model::OutTy::OutTuple(ts) = t {
            break 'm1081 Text::from(format!("({})", &types(ts)));
        }
        if let crate::lower::model::OutTy::OutArray(e) = t {
            break 'm1081 Text::from(format!("Array<{}>", &type_(&**e)));
        }
        if let crate::lower::model::OutTy::OutMap(k, v_) = t {
            break 'm1081 Text::from(format!("Map<{}, {}>", &type_(&**k), &type_(&**v_)));
        }
        if let crate::lower::model::OutTy::OutFn(ps, r) = t {
            break 'm1081 Text::from(format!("Rc<dyn Fn({}) -> {}>", &ref_types(ps), &type_(&**r)));
        }
        if let crate::lower::model::OutTy::OutRef(m1081_21_0) = t && let crate::lower::model::OutTy::OutFn(ps, r) = &**m1081_21_0 {
            break 'm1081 Text::from(format!("&dyn Fn({}) -> {}", &ref_types(ps), &type_(&**r)));
        }
        if let crate::lower::model::OutTy::OutRef(i) = t {
            break 'm1081 Text::from(format!("&{}", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutJobFn(a, b) = t {
            break 'm1081 Text::from(format!("Rc<dyn Fn({}) -> Rc<dyn prism_rtl::Job<{}>>>", &type_(&**a), &type_(&**b)));
        }
        if let crate::lower::model::OutTy::OutJob(b) = t {
            break 'm1081 Text::from(format!("Rc<dyn prism_rtl::Job<{}>>", &type_(&**b)));
        }
        if let crate::lower::model::OutTy::OutEvent(i) = t {
            break 'm1081 Text::from(format!("Event<{}>", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutDyn(i) = t {
            break 'm1081 Text::from(format!("Dynamic<{}>", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutGen(n) = t {
            break 'm1081 n.clone();
        }
        if let crate::lower::model::OutTy::OutRc(i) = t {
            break 'm1081 Text::from(format!("Rc<{}>", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutPod = t {
            break 'm1081 Text::lit("Pod");
        }
        if let crate::lower::model::OutTy::OutShowAny = t {
            break 'm1081 Text::lit("Rc<dyn Show>");
        }
        if let crate::lower::model::OutTy::OutHold(i) = t {
            break 'm1081 Text::from(format!("Hold<{}>", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutStamped(i) = t {
            break 'm1081 Text::from(format!("Stamped<{}>", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutSnapshot(i) = t {
            break 'm1081 Text::from(format!("Snapshot<{}>", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutDefer(i) = t {
            break 'm1081 Text::from(format!("Defer<{}>", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutWeak(n) = t {
            break 'm1081 Text::from(format!("Weak<{}>", n));
        }
        if let crate::lower::model::OutTy::OutCell(i) = t {
            break 'm1081 Text::from(format!("RefCell<{}>", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutWakes = t {
            break 'm1081 Text::lit("Wakes");
        }
        if let crate::lower::model::OutTy::OutCount = t {
            break 'm1081 Text::lit("u32");
        }
        if let crate::lower::model::OutTy::OutObj(i) = t {
            break 'm1081 Text::from(format!("Rc<dyn {}>", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutSlice(i) = t {
            break 'm1081 Text::from(format!("[{}]", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutPort(i) = t {
            break 'm1081 Text::from(format!("Port<{}>", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutLive(i) = t {
            break 'm1081 Text::from(format!("Live<{}>", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutUnknown(what) = t {
            break 'm1081 Text::from(format!("() /* {} */", what));
        }
        if let crate::lower::model::OutTy::OutQuantified(b) = t {
            break 'm1081 Text::from(format!("compile_error!(\"{}a quantified type variable of `{}`: no instantiation gives it a type\")", &crate::lower::lowering_refusal(), b));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `Type`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Type: unbounded fn OutTy -> Text
/// ```
pub struct Type {
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for Type {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        'm1081: {
            if let crate::lower::model::OutTy::OutNat = t {
                break 'm1081 prism_rtl::Turn::Finished(Text::lit("Nat"));
            }
            if let crate::lower::model::OutTy::OutInt = t {
                break 'm1081 prism_rtl::Turn::Finished(Text::lit("Int"));
            }
            if let crate::lower::model::OutTy::OutU8 = t {
                break 'm1081 prism_rtl::Turn::Finished(Text::lit("u8"));
            }
            if let crate::lower::model::OutTy::OutFloat = t {
                break 'm1081 prism_rtl::Turn::Finished(Text::lit("f64"));
            }
            if let crate::lower::model::OutTy::OutBool = t {
                break 'm1081 prism_rtl::Turn::Finished(Text::lit("bool"));
            }
            if let crate::lower::model::OutTy::OutChar = t {
                break 'm1081 prism_rtl::Turn::Finished(Text::lit("char"));
            }
            if let crate::lower::model::OutTy::OutText = t {
                break 'm1081 prism_rtl::Turn::Finished(Text::lit("Text"));
            }
            if let crate::lower::model::OutTy::OutCursor = t {
                break 'm1081 prism_rtl::Turn::Finished(Text::lit("Cursor"));
            }
            if let crate::lower::model::OutTy::OutUnit = t {
                break 'm1081 prism_rtl::Turn::Finished(Text::lit("()"));
            }
            if let crate::lower::model::OutTy::OutPath = t {
                break 'm1081 prism_rtl::Turn::Finished(Text::lit("Path"));
            }
            if let crate::lower::model::OutTy::OutDuration = t {
                break 'm1081 prism_rtl::Turn::Finished(Text::lit("Duration"));
            }
            if let crate::lower::model::OutTy::OutError = t {
                break 'm1081 prism_rtl::Turn::Finished(Text::lit("Error"));
            }
            if let crate::lower::model::OutTy::OutNamed(n, m1081_12_1) = t && (m1081_12_1.len() == 0) {
                break 'm1081 prism_rtl::Turn::Finished(n.clone());
            }
            if let crate::lower::model::OutTy::OutNamed(n, args_) = t {
                break 'm1081 {
                    let args_ = args_.clone();
                    let n = n.clone();
                    call_then(start_types(args_.clone()), move |types_1386: Text| prism_rtl::Turn::Finished(Text::from(format!("{}<{}>", &n, &types_1386))))
                };
            }
            if let crate::lower::model::OutTy::OutOpt(i) = t {
                break 'm1081 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__1423: Text| prism_rtl::Turn::Finished(Text::from(format!("Option<{}>", &type__1423))))
                };
            }
            if let crate::lower::model::OutTy::OutRes(i) = t {
                break 'm1081 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__1456: Text| prism_rtl::Turn::Finished(Text::from(format!("Result<{}, Error>", &type__1456))))
                };
            }
            if let crate::lower::model::OutTy::OutTuple(m1081_16_0) = t && (m1081_16_0.len() == 1) && let Some(one) = index(m1081_16_0, &Nat::from(0u32)) {
                break 'm1081 call_then(start_type_(one.clone()), move |type__1498: Text| prism_rtl::Turn::Finished(Text::from(format!("({},)", &type__1498))));
            }
            if let crate::lower::model::OutTy::OutTuple(ts) = t {
                break 'm1081 {
                    let ts = ts.clone();
                    call_then(start_types(ts.clone()), move |types_1531: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &types_1531))))
                };
            }
            if let crate::lower::model::OutTy::OutArray(e) = t {
                break 'm1081 {
                    let e = (**e).clone();
                    call_then(start_type_(e.clone()), move |type__1567: Text| prism_rtl::Turn::Finished(Text::from(format!("Array<{}>", &type__1567))))
                };
            }
            if let crate::lower::model::OutTy::OutMap(k, v_) = t {
                break 'm1081 {
                    let k = (**k).clone();
                    let v_ = (**v_).clone();
                    call_then(start_type_(k.clone()), move |type__1600: Text| call_then(start_type_(v_.clone()), move |type__1610: Text| prism_rtl::Turn::Finished(Text::from(format!("Map<{}, {}>", &type__1600, &type__1610)))))
                };
            }
            if let crate::lower::model::OutTy::OutFn(ps, r) = t {
                break 'm1081 {
                    let ps = ps.clone();
                    let r = (**r).clone();
                    call_then(start_ref_types(ps.clone()), move |ref_types_1649: Text| call_then(start_type_(r.clone()), move |type__1667: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<dyn Fn({}) -> {}>", &ref_types_1649, &type__1667)))))
                };
            }
            if let crate::lower::model::OutTy::OutRef(m1081_21_0) = t && let crate::lower::model::OutTy::OutFn(ps, r) = &**m1081_21_0 {
                break 'm1081 {
                    let ps = ps.clone();
                    let r = (**r).clone();
                    call_then(start_ref_types(ps.clone()), move |ref_types_1713: Text| call_then(start_type_(r.clone()), move |type__1731: Text| prism_rtl::Turn::Finished(Text::from(format!("&dyn Fn({}) -> {}", &ref_types_1713, &type__1731)))))
                };
            }
            if let crate::lower::model::OutTy::OutRef(i) = t {
                break 'm1081 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__1757: Text| prism_rtl::Turn::Finished(Text::from(format!("&{}", &type__1757))))
                };
            }
            if let crate::lower::model::OutTy::OutJobFn(a, b) = t {
                break 'm1081 {
                    let a = (**a).clone();
                    let b = (**b).clone();
                    call_then(start_type_(a.clone()), move |type__1797: Text| call_then(start_type_(b.clone()), move |type__1832: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<dyn Fn({}) -> Rc<dyn prism_rtl::Job<{}>>>", &type__1797, &type__1832)))))
                };
            }
            if let crate::lower::model::OutTy::OutJob(b) = t {
                break 'm1081 {
                    let b = (**b).clone();
                    call_then(start_type_(b.clone()), move |type__1882: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<dyn prism_rtl::Job<{}>>", &type__1882))))
                };
            }
            if let crate::lower::model::OutTy::OutEvent(i) = t {
                break 'm1081 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__1917: Text| prism_rtl::Turn::Finished(Text::from(format!("Event<{}>", &type__1917))))
                };
            }
            if let crate::lower::model::OutTy::OutDyn(i) = t {
                break 'm1081 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__1951: Text| prism_rtl::Turn::Finished(Text::from(format!("Dynamic<{}>", &type__1951))))
                };
            }
            if let crate::lower::model::OutTy::OutGen(n) = t {
                break 'm1081 prism_rtl::Turn::Finished(n.clone());
            }
            if let crate::lower::model::OutTy::OutRc(i) = t {
                break 'm1081 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__1995: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<{}>", &type__1995))))
                };
            }
            if let crate::lower::model::OutTy::OutPod = t {
                break 'm1081 prism_rtl::Turn::Finished(Text::lit("Pod"));
            }
            if let crate::lower::model::OutTy::OutShowAny = t {
                break 'm1081 prism_rtl::Turn::Finished(Text::lit("Rc<dyn Show>"));
            }
            if let crate::lower::model::OutTy::OutHold(i) = t {
                break 'm1081 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2076: Text| prism_rtl::Turn::Finished(Text::from(format!("Hold<{}>", &type__2076))))
                };
            }
            if let crate::lower::model::OutTy::OutStamped(i) = t {
                break 'm1081 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2114: Text| prism_rtl::Turn::Finished(Text::from(format!("Stamped<{}>", &type__2114))))
                };
            }
            if let crate::lower::model::OutTy::OutSnapshot(i) = t {
                break 'm1081 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2154: Text| prism_rtl::Turn::Finished(Text::from(format!("Snapshot<{}>", &type__2154))))
                };
            }
            if let crate::lower::model::OutTy::OutDefer(i) = t {
                break 'm1081 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2188: Text| prism_rtl::Turn::Finished(Text::from(format!("Defer<{}>", &type__2188))))
                };
            }
            if let crate::lower::model::OutTy::OutWeak(n) = t {
                break 'm1081 prism_rtl::Turn::Finished(Text::from(format!("Weak<{}>", n)));
            }
            if let crate::lower::model::OutTy::OutCell(i) = t {
                break 'm1081 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2250: Text| prism_rtl::Turn::Finished(Text::from(format!("RefCell<{}>", &type__2250))))
                };
            }
            if let crate::lower::model::OutTy::OutWakes = t {
                break 'm1081 prism_rtl::Turn::Finished(Text::lit("Wakes"));
            }
            if let crate::lower::model::OutTy::OutCount = t {
                break 'm1081 prism_rtl::Turn::Finished(Text::lit("u32"));
            }
            if let crate::lower::model::OutTy::OutObj(i) = t {
                break 'm1081 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2325: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<dyn {}>", &type__2325))))
                };
            }
            if let crate::lower::model::OutTy::OutSlice(i) = t {
                break 'm1081 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2354: Text| prism_rtl::Turn::Finished(Text::from(format!("[{}]", &type__2354))))
                };
            }
            if let crate::lower::model::OutTy::OutPort(i) = t {
                break 'm1081 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2386: Text| prism_rtl::Turn::Finished(Text::from(format!("Port<{}>", &type__2386))))
                };
            }
            if let crate::lower::model::OutTy::OutLive(i) = t {
                break 'm1081 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2418: Text| prism_rtl::Turn::Finished(Text::from(format!("Live<{}>", &type__2418))))
                };
            }
            if let crate::lower::model::OutTy::OutUnknown(what) = t {
                break 'm1081 prism_rtl::Turn::Finished(Text::from(format!("() /* {} */", what)));
            }
            if let crate::lower::model::OutTy::OutQuantified(b) = t {
                break 'm1081 prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}a quantified type variable of `{}`: no instantiation gives it a type\")", &crate::lower::lowering_refusal(), b)));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start Type, x`: what the function value is when passed to `@Run`.
pub fn start_type_(t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Type { t })
}

/// ```prism
/// Types: unbounded fn [OutTy] -> Text
/// ```
pub fn types(ts: &Array<crate::lower::model::OutTy>) -> Text {
    crate::syntax::lexer::join(&run_to_end(each_job(ts.clone(), Rc::new(move |p0: crate::lower::model::OutTy| entered(once_job(move || {
        let t = p0;
        prism_rtl::Turn::More(Rc::new(Type { t: t.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))
}

/// The step machine of `Types`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Types: unbounded fn [OutTy] -> Text
/// ```
pub struct Types {
    pub ts: Array<crate::lower::model::OutTy>,
}

impl prism_rtl::Job<Text> for Types {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let ts = &self.ts;
        let ts = ts.clone();
        call_value(each_job(ts.clone(), Rc::new(move |p0: crate::lower::model::OutTy| entered(once_job(move || {
            let t = p0;
            prism_rtl::Turn::More(Rc::new(Type { t: t.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_2654: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::join(&each_2654, &Text::lit(", "))))
    }
}

/// `Start Types, x`: what the function value is when passed to `@Run`.
pub fn start_types(ts: Array<crate::lower::model::OutTy>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Types { ts })
}

/// ```prism
/// RefTypes: unbounded fn [OutTy] -> Text
/// ```
pub fn ref_types(ts: &Array<crate::lower::model::OutTy>) -> Text {
    crate::syntax::lexer::join(&run_to_end(each_job(ts.clone(), Rc::new(move |p0: crate::lower::model::OutTy| entered(once_job(move || {
        let t = p0;
        call_then(start_type_(t.clone()), move |type__2762: Text| prism_rtl::Turn::Finished(Text::from(format!("&{}", &type__2762))))
    }))) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))
}

/// The step machine of `RefTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RefTypes: unbounded fn [OutTy] -> Text
/// ```
pub struct RefTypes {
    pub ts: Array<crate::lower::model::OutTy>,
}

impl prism_rtl::Job<Text> for RefTypes {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let ts = &self.ts;
        let ts = ts.clone();
        call_value(each_job(ts.clone(), Rc::new(move |p0: crate::lower::model::OutTy| entered(once_job(move || {
            let t = p0;
            call_then(start_type_(t.clone()), move |type__2762: Text| prism_rtl::Turn::Finished(Text::from(format!("&{}", &type__2762))))
        }))) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_2745: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::join(&each_2745, &Text::lit(", "))))
    }
}

/// `Start RefTypes, x`: what the function value is when passed to `@Run`.
pub fn start_ref_types(ts: Array<crate::lower::model::OutTy>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RefTypes { ts })
}

/// ```prism
/// IsLoose: fn Ex -> Bool
/// ```
pub fn is_loose(x: &crate::lower::model::Ex) -> bool {
    match x {
        crate::lower::model::Ex::XBlock(m3087_0_0, inner) if (m3087_0_0.len() == 0) => is_loose(&**inner),
        crate::lower::model::Ex::XTyped(inner, _) => is_loose(&**inner),
        crate::lower::model::Ex::XBin(_, _, _) => true,
        crate::lower::model::Ex::XUnary(_, _) => true,
        crate::lower::model::Ex::XClosure(_, _, _) => true,
        crate::lower::model::Ex::XIf(_, _, _) => true,
        crate::lower::model::Ex::XMatch(_, _, _, _) => true,
        crate::lower::model::Ex::XChain(_, _, _, _) => true,
        crate::lower::model::Ex::XCast(_, _) => true,
        crate::lower::model::Ex::XRef(_) => true,
        crate::lower::model::Ex::XRefMut(_) => true,
        crate::lower::model::Ex::XDeref(_) => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Tight: unbounded fn Ex -> Text
/// ```
pub fn tight(x: &crate::lower::model::Ex) -> Text {
    if is_loose(x) { Text::from(format!("({})", &expression(x))) } else { expression(x) }
}

/// The step machine of `Tight`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Tight: unbounded fn Ex -> Text
/// ```
pub struct Tight {
    pub x: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for Tight {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let x = &self.x;
        if is_loose(x) {
            {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_3604: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_3604))))
            }
        } else {
            prism_rtl::Turn::More(Rc::new(Expression { x: x.clone() }))
        }
    }
}

/// `Start Tight, x`: what the function value is when passed to `@Run`.
pub fn start_tight(x: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Tight { x })
}

/// ```prism
/// Operand: unbounded fn Ex -> Text
/// ```
pub fn operand(x: &crate::lower::model::Ex) -> Text {
    match x {
        crate::lower::model::Ex::XBlock(m3688_0_0, inner) if (m3688_0_0.len() == 0) => operand(&**inner),
        crate::lower::model::Ex::XTyped(inner, _) => operand(&**inner),
        crate::lower::model::Ex::XBin(_, _, _) => Text::from(format!("({})", &expression(x))),
        crate::lower::model::Ex::XClosure(_, _, _) => Text::from(format!("({})", &expression(x))),
        crate::lower::model::Ex::XIf(_, _, _) => Text::from(format!("({})", &expression(x))),
        crate::lower::model::Ex::XCast(_, _) => Text::from(format!("({})", &expression(x))),
        _ => expression(x),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `Operand`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Operand: unbounded fn Ex -> Text
/// ```
pub struct Operand {
    pub x: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for Operand {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let x = &self.x;
        match x {
            crate::lower::model::Ex::XBlock(m3688_0_0, inner) if (m3688_0_0.len() == 0) => prism_rtl::Turn::More(Rc::new(Operand { x: (**inner).clone() })),
            crate::lower::model::Ex::XTyped(inner, _) => prism_rtl::Turn::More(Rc::new(Operand { x: (**inner).clone() })),
            crate::lower::model::Ex::XBin(_, _, _) => {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_3811: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_3811))))
            },
            crate::lower::model::Ex::XClosure(_, _, _) => {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_3867: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_3867))))
            },
            crate::lower::model::Ex::XIf(_, _, _) => {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_3918: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_3918))))
            },
            crate::lower::model::Ex::XCast(_, _) => {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_3963: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_3963))))
            },
            _ => prism_rtl::Turn::More(Rc::new(Expression { x: x.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start Operand, x`: what the function value is when passed to `@Run`.
pub fn start_operand(x: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Operand { x })
}

/// ```prism
/// Args: unbounded fn [Ex] -> Text
/// ```
pub fn args(xs: &Array<crate::lower::model::Ex>) -> Text {
    crate::syntax::lexer::join(&run_to_end(each_job(xs.clone(), Rc::new(move |p0: crate::lower::model::Ex| entered(once_job(move || {
        let x = p0;
        prism_rtl::Turn::More(Rc::new(Expression { x: x.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))
}

/// The step machine of `Args`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Args: unbounded fn [Ex] -> Text
/// ```
pub struct Args {
    pub xs: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for Args {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let xs = &self.xs;
        let xs = xs.clone();
        call_value(each_job(xs.clone(), Rc::new(move |p0: crate::lower::model::Ex| entered(once_job(move || {
            let x = p0;
            prism_rtl::Turn::More(Rc::new(Expression { x: x.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_4059: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::join(&each_4059, &Text::lit(", "))))
    }
}

/// `Start Args, x`: what the function value is when passed to `@Run`.
pub fn start_args(xs: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Args { xs })
}

/// ```prism
/// Expression: unbounded fn Ex -> Text
/// ```
pub fn expression(x: &crate::lower::model::Ex) -> Text {
    'm4148: {
        if let crate::lower::model::Ex::XVar(n) = x {
            break 'm4148 n.clone();
        }
        if let crate::lower::model::Ex::XPath(p_) = x {
            break 'm4148 p_.clone();
        }
        if let crate::lower::model::Ex::XSelf = x {
            break 'm4148 Text::lit("self");
        }
        if let crate::lower::model::Ex::XCx = x {
            break 'm4148 Text::lit("cx");
        }
        if let crate::lower::model::Ex::XConst(n) = x {
            break 'm4148 Text::from(format!("Self::{}", n));
        }
        if let crate::lower::model::Ex::XUnit = x {
            break 'm4148 Text::lit("()");
        }
        if let crate::lower::model::Ex::XNone = x {
            break 'm4148 Text::lit("None");
        }
        if let crate::lower::model::Ex::XBool(b) = x {
            break 'm4148 if *b { Text::lit("true") } else { Text::lit("false") };
        }
        if let crate::lower::model::Ex::XNat(d) = x {
            break 'm4148 if &len_text(d) <= &Nat::from(9u32) {
                Text::from(format!("Nat::from({}u32)", d))
            } else {
                if &len_text(d) <= &Nat::from(18u32) {
                    Text::from(format!("Nat::from_int(Int::from({}i64)).unwrap()", d))
                } else {
                    Text::from(format!("Nat::from_int(Int::parse(\"{}\").unwrap()).unwrap()", d))
                }
            };
        }
        if let crate::lower::model::Ex::XInt(d) = x {
            break 'm4148 if &len_text(&(if crate::syntax::lexer::has_prefix(d, &Text::lit("-")) {
                crate::syntax::lexer::after_first(d)
            } else {
                d.clone()
            })) <= &Nat::from(18u32) {
                Text::from(format!("Int::from({})", d))
            } else {
                Text::from(format!("Int::parse(\"{}\").unwrap()", d))
            };
        }
        if let crate::lower::model::Ex::XByte(d) = x {
            break 'm4148 Text::from(format!("{}u8", d));
        }
        if let crate::lower::model::Ex::XFloat(d) = x {
            break 'm4148 d.clone();
        }
        if let crate::lower::model::Ex::XIndex(n) = x {
            break 'm4148 Text::from(format!("{}", n));
        }
        if let crate::lower::model::Ex::XChar(c) = x {
            break 'm4148 Text::from(format!("'{}'", &crate::lower::char_escape(c)));
        }
        if let crate::lower::model::Ex::XStr(t) = x {
            break 'm4148 Text::from(format!("\"{}\"", &crate::lower::escape(t)));
        }
        if let crate::lower::model::Ex::XRef(y) = x {
            break 'm4148 Text::from(format!("&{}", &operand(&**y)));
        }
        if let crate::lower::model::Ex::XRefMut(y) = x {
            break 'm4148 Text::from(format!("&mut {}", &operand(&**y)));
        }
        if let crate::lower::model::Ex::XDeref(y) = x {
            break 'm4148 Text::from(format!("*{}", &operand(&**y)));
        }
        if let crate::lower::model::Ex::XTarget(y) = x {
            break 'm4148 Text::from(format!("(*{})", &expression(&**y)));
        }
        if let crate::lower::model::Ex::XClone(y) = x {
            break 'm4148 Text::from(format!("{}.clone()", &tight(&**y)));
        }
        if let crate::lower::model::Ex::XWeak(y) = x {
            break 'm4148 Text::from(format!("Rc::downgrade({})", &expression(&**y)));
        }
        if let crate::lower::model::Ex::XUpgrade(y) = x {
            break 'm4148 Text::from(format!("{}.upgrade()", &tight(&**y)));
        }
        if let crate::lower::model::Ex::XBreak(l, y) = x {
            break 'm4148 Text::from(format!("break {} {}", &label(l), &expression(&**y)));
        }
        if let crate::lower::model::Ex::XBreakLoop = x {
            break 'm4148 Text::lit("break");
        }
        if let crate::lower::model::Ex::XLater(y) = x {
            break 'm4148 Text::from(format!("Box::new(move |cx| {{ {}; Ok(()) }})", &expression(&**y)));
        }
        if let crate::lower::model::Ex::XFormatStr(parts) = x {
            break 'm4148 format_str(parts);
        }
        if let crate::lower::model::Ex::XIsCase(y, m4148_26_1) = x && (m4148_26_1.len() == 0) {
            break 'm4148 Text::lit("false");
        }
        if let crate::lower::model::Ex::XIsCase(y, cs) = x {
            break 'm4148 Text::from(format!("matches!({}, {})", &expression(&**y), &crate::syntax::lexer::join(&each(cs, &(|c: &Text| Text::from(format!("{}(..)", c)))), &Text::lit(" | "))));
        }
        if let crate::lower::model::Ex::XRefusal(what) = x {
            break 'm4148 Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::lowering_refusal(), &crate::lower::escape(what)));
        }
        if let crate::lower::model::Ex::XUnreachable = x {
            break 'm4148 Text::lit("unreachable!()");
        }
        if let crate::lower::model::Ex::XCall(f, args_) = x {
            break 'm4148 Text::from(format!("{}({})", f, &args(args_)));
        }
        if let crate::lower::model::Ex::XApply(f, args_) = x {
            break 'm4148 Text::from(format!("{}({})", &tight(&**f), &args(args_)));
        }
        if let crate::lower::model::Ex::XMethod(r, m, args_) = x {
            break 'm4148 Text::from(format!("{}.{}({})", &tight(&**r), m, &args(args_)));
        }
        if let crate::lower::model::Ex::XBin(op, l, r) = x {
            break 'm4148 Text::from(format!("{} {} {}", &operand(&**l), op, &operand(&**r)));
        }
        if let crate::lower::model::Ex::XUnary(op, y) = x {
            break 'm4148 Text::from(format!("{}{}", op, &operand(&**y)));
        }
        if let crate::lower::model::Ex::XCtor(p_, args_) = x {
            break 'm4148 Text::from(format!("{}({})", p_, &args(args_)));
        }
        if let crate::lower::model::Ex::XRecord(p_, fs) = x {
            break 'm4148 Text::from(format!("{} {{ {} }}", p_, &crate::syntax::lexer::join(&run_to_end(each_job(fs.clone(), Rc::new(move |p0: (Text, crate::lower::model::Ex)| entered(once_job(move || {
                let (f, v_) = p0;
                prism_rtl::Turn::More(Rc::new(FieldInit { f: f.clone(), ex1: v_.clone() }))
            }))) as Rc<dyn Fn((Text, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))));
        }
        if let crate::lower::model::Ex::XTuple(m4148_37_0) = x && (m4148_37_0.len() == 1) && let Some(one) = index(m4148_37_0, &Nat::from(0u32)) {
            break 'm4148 Text::from(format!("({},)", &expression(&one)));
        }
        if let crate::lower::model::Ex::XTuple(xs) = x {
            break 'm4148 Text::from(format!("({})", &args(xs)));
        }
        if let crate::lower::model::Ex::XVec(xs) = x {
            break 'm4148 Text::from(format!("vec![{}]", &args(xs)));
        }
        if let crate::lower::model::Ex::XText(t) = x {
            break 'm4148 Text::from(format!("Text::lit(\"{}\")", &crate::lower::escape(t)));
        }
        if let crate::lower::model::Ex::XFormat(parts) = x {
            break 'm4148 format(parts);
        }
        if let crate::lower::model::Ex::XMatch(s, arms_, fallback, _) = x {
            break 'm4148 crate::emit::rust::templates::match_(&expression(&**s), &arms(arms_, fallback));
        }
        if let crate::lower::model::Ex::XChain(label_, s, arms_, _) = x {
            break 'm4148 chain(&label(label_), &**s, arms_);
        }
        if let crate::lower::model::Ex::XIf(c, t, e) = x {
            break 'm4148 if_expression(&**c, &**t, &**e);
        }
        if let crate::lower::model::Ex::XBlock(m4148_45_0, e) = x && (m4148_45_0.len() == 0) {
            break 'm4148 expression(&**e);
        }
        if let crate::lower::model::Ex::XBlock(dos, e) = x {
            break 'm4148 crate::emit::rust::templates::block(&statements(dos), &expression(&**e));
        }
        if let crate::lower::model::Ex::XLabeled(label_, dos, e, _) = x {
            break 'm4148 crate::emit::rust::templates::labeled(&label(label_), &statements(dos), &expression(&**e));
        }
        if let crate::lower::model::Ex::XClosure(mv, ps, body) = x {
            break 'm4148 Text::from(format!("{}|{}| {}", &(if *mv { Text::lit("move ") } else { Text::lit("") }), &crate::syntax::lexer::join(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                let p_ = p0;
                prism_rtl::Turn::More(Rc::new(Pattern_ { p_: p_.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", ")), &expression(&**body)));
        }
        if let crate::lower::model::Ex::XTry(y) = x {
            break 'm4148 Text::from(format!("{}?", &tight(&**y)));
        }
        if let crate::lower::model::Ex::XField(r, f) = x {
            break 'm4148 Text::from(format!("{}.{}", &tight(&**r), f));
        }
        if let crate::lower::model::Ex::XPart(r, k) = x {
            break 'm4148 Text::from(format!("{}.{}", &tight(&**r), k));
        }
        if let crate::lower::model::Ex::XDecode(t, y) = x {
            break 'm4148 Text::from(format!("{}::from_pod({})?", &decode_head(t), &expression(&**y)));
        }
        if let crate::lower::model::Ex::XCast(y, t) = x {
            break 'm4148 Text::from(format!("{} as {}", &tight(&**y), &type_(t)));
        }
        if let crate::lower::model::Ex::XTyped(y, _) = x {
            break 'm4148 expression(&**y);
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `Expression`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Expression: unbounded fn Ex -> Text
/// ```
pub struct Expression {
    pub x: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for Expression {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let x = &self.x;
        'm4148: {
            if let crate::lower::model::Ex::XVar(n) = x {
                break 'm4148 prism_rtl::Turn::Finished(n.clone());
            }
            if let crate::lower::model::Ex::XPath(p_) = x {
                break 'm4148 prism_rtl::Turn::Finished(p_.clone());
            }
            if let crate::lower::model::Ex::XSelf = x {
                break 'm4148 prism_rtl::Turn::Finished(Text::lit("self"));
            }
            if let crate::lower::model::Ex::XCx = x {
                break 'm4148 prism_rtl::Turn::Finished(Text::lit("cx"));
            }
            if let crate::lower::model::Ex::XConst(n) = x {
                break 'm4148 prism_rtl::Turn::Finished(Text::from(format!("Self::{}", n)));
            }
            if let crate::lower::model::Ex::XUnit = x {
                break 'm4148 prism_rtl::Turn::Finished(Text::lit("()"));
            }
            if let crate::lower::model::Ex::XNone = x {
                break 'm4148 prism_rtl::Turn::Finished(Text::lit("None"));
            }
            if let crate::lower::model::Ex::XBool(b) = x {
                break 'm4148 if *b {
                    prism_rtl::Turn::Finished(Text::lit("true"))
                } else {
                    prism_rtl::Turn::Finished(Text::lit("false"))
                };
            }
            if let crate::lower::model::Ex::XNat(d) = x {
                break 'm4148 if &len_text(d) <= &Nat::from(9u32) {
                    prism_rtl::Turn::Finished(Text::from(format!("Nat::from({}u32)", d)))
                } else {
                    if &len_text(d) <= &Nat::from(18u32) {
                        prism_rtl::Turn::Finished(Text::from(format!("Nat::from_int(Int::from({}i64)).unwrap()", d)))
                    } else {
                        prism_rtl::Turn::Finished(Text::from(format!("Nat::from_int(Int::parse(\"{}\").unwrap()).unwrap()", d)))
                    }
                };
            }
            if let crate::lower::model::Ex::XInt(d) = x {
                break 'm4148 if &len_text(&(if crate::syntax::lexer::has_prefix(d, &Text::lit("-")) {
                    crate::syntax::lexer::after_first(d)
                } else {
                    d.clone()
                })) <= &Nat::from(18u32) {
                    prism_rtl::Turn::Finished(Text::from(format!("Int::from({})", d)))
                } else {
                    prism_rtl::Turn::Finished(Text::from(format!("Int::parse(\"{}\").unwrap()", d)))
                };
            }
            if let crate::lower::model::Ex::XByte(d) = x {
                break 'm4148 prism_rtl::Turn::Finished(Text::from(format!("{}u8", d)));
            }
            if let crate::lower::model::Ex::XFloat(d) = x {
                break 'm4148 prism_rtl::Turn::Finished(d.clone());
            }
            if let crate::lower::model::Ex::XIndex(n) = x {
                break 'm4148 prism_rtl::Turn::Finished(Text::from(format!("{}", n)));
            }
            if let crate::lower::model::Ex::XChar(c) = x {
                break 'm4148 prism_rtl::Turn::Finished(Text::from(format!("'{}'", &crate::lower::char_escape(c))));
            }
            if let crate::lower::model::Ex::XStr(t) = x {
                break 'm4148 prism_rtl::Turn::Finished(Text::from(format!("\"{}\"", &crate::lower::escape(t))));
            }
            if let crate::lower::model::Ex::XRef(y) = x {
                break 'm4148 {
                    let y = (**y).clone();
                    call_then(start_operand(y.clone()), move |operand_4757: Text| prism_rtl::Turn::Finished(Text::from(format!("&{}", &operand_4757))))
                };
            }
            if let crate::lower::model::Ex::XRefMut(y) = x {
                break 'm4148 {
                    let y = (**y).clone();
                    call_then(start_operand(y.clone()), move |operand_4791: Text| prism_rtl::Turn::Finished(Text::from(format!("&mut {}", &operand_4791))))
                };
            }
            if let crate::lower::model::Ex::XDeref(y) = x {
                break 'm4148 {
                    let y = (**y).clone();
                    call_then(start_operand(y.clone()), move |operand_4820: Text| prism_rtl::Turn::Finished(Text::from(format!("*{}", &operand_4820))))
                };
            }
            if let crate::lower::model::Ex::XTarget(y) = x {
                break 'm4148 {
                    let y = (**y).clone();
                    call_then(start_expression(y.clone()), move |expression_4851: Text| prism_rtl::Turn::Finished(Text::from(format!("(*{})", &expression_4851))))
                };
            }
            if let crate::lower::model::Ex::XClone(y) = x {
                break 'm4148 {
                    let y = (**y).clone();
                    call_then(start_tight(y.clone()), move |tight_4883: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.clone()", &tight_4883))))
                };
            }
            if let crate::lower::model::Ex::XWeak(y) = x {
                break 'm4148 {
                    let y = (**y).clone();
                    call_then(start_expression(y.clone()), move |expression_4930: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc::downgrade({})", &expression_4930))))
                };
            }
            if let crate::lower::model::Ex::XUpgrade(y) = x {
                break 'm4148 {
                    let y = (**y).clone();
                    call_then(start_tight(y.clone()), move |tight_4964: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.upgrade()", &tight_4964))))
                };
            }
            if let crate::lower::model::Ex::XBreak(l, y) = x {
                break 'm4148 {
                    let l = l.clone();
                    let y = (**y).clone();
                    call_then(start_expression(y.clone()), move |expression_5019: Text| prism_rtl::Turn::Finished(Text::from(format!("break {} {}", &label(&l), &expression_5019))))
                };
            }
            if let crate::lower::model::Ex::XBreakLoop = x {
                break 'm4148 prism_rtl::Turn::Finished(Text::lit("break"));
            }
            if let crate::lower::model::Ex::XLater(y) = x {
                break 'm4148 {
                    let y = (**y).clone();
                    call_then(start_expression(y.clone()), move |expression_5096: Text| prism_rtl::Turn::Finished(Text::from(format!("Box::new(move |cx| {{ {}; Ok(()) }})", &expression_5096))))
                };
            }
            if let crate::lower::model::Ex::XFormatStr(parts) = x {
                break 'm4148 prism_rtl::Turn::More(Rc::new(FormatStr { parts: parts.clone() }));
            }
            if let crate::lower::model::Ex::XIsCase(y, m4148_26_1) = x && (m4148_26_1.len() == 0) {
                break 'm4148 prism_rtl::Turn::Finished(Text::lit("false"));
            }
            if let crate::lower::model::Ex::XIsCase(y, cs) = x {
                break 'm4148 {
                    let cs = cs.clone();
                    let y = (**y).clone();
                    call_then(start_expression(y.clone()), move |expression_5220: Text| prism_rtl::Turn::Finished(Text::from(format!("matches!({}, {})", &expression_5220, &crate::syntax::lexer::join(&each(&cs, &(|c: &Text| Text::from(format!("{}(..)", c)))), &Text::lit(" | "))))))
                };
            }
            if let crate::lower::model::Ex::XRefusal(what) = x {
                break 'm4148 prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::lowering_refusal(), &crate::lower::escape(what))));
            }
            if let crate::lower::model::Ex::XUnreachable = x {
                break 'm4148 prism_rtl::Turn::Finished(Text::lit("unreachable!()"));
            }
            if let crate::lower::model::Ex::XCall(f, args_) = x {
                break 'm4148 {
                    let args_ = args_.clone();
                    let f = f.clone();
                    call_then(start_args(args_.clone()), move |args_5409: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &f, &args_5409))))
                };
            }
            if let crate::lower::model::Ex::XApply(f, args_) = x {
                break 'm4148 {
                    let args_ = args_.clone();
                    let f = (**f).clone();
                    call_then(start_tight(f.clone()), move |tight_5444: Text| call_then(start_args(args_.clone()), move |args_5454: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &tight_5444, &args_5454)))))
                };
            }
            if let crate::lower::model::Ex::XMethod(r, m, args_) = x {
                break 'm4148 {
                    let args_ = args_.clone();
                    let m = m.clone();
                    let r = (**r).clone();
                    call_then(start_tight(r.clone()), move |tight_5493: Text| call_then(start_args(args_.clone()), move |args_5507: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.{}({})", &tight_5493, &m, &args_5507)))))
                };
            }
            if let crate::lower::model::Ex::XBin(op, l, r) = x {
                break 'm4148 {
                    let l = (**l).clone();
                    let op = op.clone();
                    let r = (**r).clone();
                    call_then(start_operand(l.clone()), move |operand_5541: Text| call_then(start_operand(r.clone()), move |operand_5558: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {} {}", &operand_5541, &op, &operand_5558)))))
                };
            }
            if let crate::lower::model::Ex::XUnary(op, y) = x {
                break 'm4148 {
                    let op = op.clone();
                    let y = (**y).clone();
                    call_then(start_operand(y.clone()), move |operand_5594: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &op, &operand_5594))))
                };
            }
            if let crate::lower::model::Ex::XCtor(p_, args_) = x {
                break 'm4148 {
                    let args_ = args_.clone();
                    let p_ = p_.clone();
                    call_then(start_args(args_.clone()), move |args_5631: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &p_, &args_5631))))
                };
            }
            if let crate::lower::model::Ex::XRecord(p_, fs) = x {
                break 'm4148 {
                    let fs = fs.clone();
                    let p_ = p_.clone();
                    call_value(each_job(fs.clone(), Rc::new(move |p0: (Text, crate::lower::model::Ex)| entered(once_job(move || {
                        let (f, v_) = p0;
                        prism_rtl::Turn::More(Rc::new(FieldInit { f: f.clone(), ex1: v_.clone() }))
                    }))) as Rc<dyn Fn((Text, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_5678: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{} {{ {} }}", &p_, &crate::syntax::lexer::join(&each_5678, &Text::lit(", "))))))
                };
            }
            if let crate::lower::model::Ex::XTuple(m4148_37_0) = x && (m4148_37_0.len() == 1) && let Some(one) = index(m4148_37_0, &Nat::from(0u32)) {
                break 'm4148 call_then(start_expression(one.clone()), move |expression_5749: Text| prism_rtl::Turn::Finished(Text::from(format!("({},)", &expression_5749))));
            }
            if let crate::lower::model::Ex::XTuple(xs) = x {
                break 'm4148 {
                    let xs = xs.clone();
                    call_then(start_args(xs.clone()), move |args_5786: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &args_5786))))
                };
            }
            if let crate::lower::model::Ex::XVec(xs) = x {
                break 'm4148 {
                    let xs = xs.clone();
                    call_then(start_args(xs.clone()), move |args_5817: Text| prism_rtl::Turn::Finished(Text::from(format!("vec![{}]", &args_5817))))
                };
            }
            if let crate::lower::model::Ex::XText(t) = x {
                break 'm4148 prism_rtl::Turn::Finished(Text::from(format!("Text::lit(\"{}\")", &crate::lower::escape(t))));
            }
            if let crate::lower::model::Ex::XFormat(parts) = x {
                break 'm4148 prism_rtl::Turn::More(Rc::new(Format { parts: parts.clone() }));
            }
            if let crate::lower::model::Ex::XMatch(s, arms_, fallback, _) = x {
                break 'm4148 {
                    let arms_ = arms_.clone();
                    let fallback = *fallback;
                    let s = (**s).clone();
                    call_then(start_expression(s.clone()), move |expression_5946: Text| call_then(start_arms(arms_.clone(), fallback), move |arms_5962: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::match_(&expression_5946, &arms_5962))))
                };
            }
            if let crate::lower::model::Ex::XChain(label_, s, arms_, _) = x {
                break 'm4148 prism_rtl::Turn::More(Rc::new(Chain { label_: label(label_), s: (**s).clone(), arms_: arms_.clone() }));
            }
            if let crate::lower::model::Ex::XIf(c, t, e) = x {
                break 'm4148 prism_rtl::Turn::More(Rc::new(IfExpression { c: (**c).clone(), t: (**t).clone(), e: (**e).clone() }));
            }
            if let crate::lower::model::Ex::XBlock(m4148_45_0, e) = x && (m4148_45_0.len() == 0) {
                break 'm4148 prism_rtl::Turn::More(Rc::new(Expression { x: (**e).clone() }));
            }
            if let crate::lower::model::Ex::XBlock(dos, e) = x {
                break 'm4148 {
                    let dos = dos.clone();
                    let e = (**e).clone();
                    call_then(start_statements(dos.clone()), move |statements_6144: Text| call_then(start_expression(e.clone()), move |expression_6162: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::block(&statements_6144, &expression_6162))))
                };
            }
            if let crate::lower::model::Ex::XLabeled(label_, dos, e, _) = x {
                break 'm4148 {
                    let dos = dos.clone();
                    let e = (**e).clone();
                    let label_ = label_.clone();
                    call_then(start_statements(dos.clone()), move |statements_6236: Text| call_then(start_expression(e.clone()), move |expression_6254: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::labeled(&label(&label_), &statements_6236, &expression_6254))))
                };
            }
            if let crate::lower::model::Ex::XClosure(mv, ps, body) = x {
                break 'm4148 {
                    let body = (**body).clone();
                    let mv = *mv;
                    let ps = ps.clone();
                    call_value(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                        let p_ = p0;
                        prism_rtl::Turn::More(Rc::new(Pattern_ { p_: p_.clone() }))
                    }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_6329: Array<Text>| call_then(start_expression(body.clone()), move |expression_6363: Text| prism_rtl::Turn::Finished(Text::from(format!("{}|{}| {}", &(if mv { Text::lit("move ") } else { Text::lit("") }), &crate::syntax::lexer::join(&each_6329, &Text::lit(", ")), &expression_6363)))))
                };
            }
            if let crate::lower::model::Ex::XTry(y) = x {
                break 'm4148 {
                    let y = (**y).clone();
                    call_then(start_tight(y.clone()), move |tight_6395: Text| prism_rtl::Turn::Finished(Text::from(format!("{}?", &tight_6395))))
                };
            }
            if let crate::lower::model::Ex::XField(r, f) = x {
                break 'm4148 {
                    let f = f.clone();
                    let r = (**r).clone();
                    call_then(start_tight(r.clone()), move |tight_6425: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.{}", &tight_6425, &f))))
                };
            }
            if let crate::lower::model::Ex::XPart(r, k) = x {
                break 'm4148 {
                    let k = k.clone();
                    let r = (**r).clone();
                    call_then(start_tight(r.clone()), move |tight_6457: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.{}", &tight_6457, &k))))
                };
            }
            if let crate::lower::model::Ex::XDecode(t, y) = x {
                break 'm4148 {
                    let t = t.clone();
                    let y = (**y).clone();
                    call_then(start_decode_head(t.clone()), move |decode_head_6491: Text| call_then(start_expression(y.clone()), move |expression_6516: Text| prism_rtl::Turn::Finished(Text::from(format!("{}::from_pod({})?", &decode_head_6491, &expression_6516)))))
                };
            }
            if let crate::lower::model::Ex::XCast(y, t) = x {
                break 'm4148 {
                    let t = t.clone();
                    let y = (**y).clone();
                    call_then(start_tight(y.clone()), move |tight_6551: Text| call_then(start_type_(t.clone()), move |type__6564: Text| prism_rtl::Turn::Finished(Text::from(format!("{} as {}", &tight_6551, &type__6564)))))
                };
            }
            if let crate::lower::model::Ex::XTyped(y, _) = x {
                break 'm4148 prism_rtl::Turn::More(Rc::new(Expression { x: (**y).clone() }));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start Expression, x`: what the function value is when passed to `@Run`.
pub fn start_expression(x: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Expression { x })
}

/// ```prism
/// FieldInit: unbounded fn Text, Ex -> Text
/// ```
pub fn field_init(f: &Text, ex1: &crate::lower::model::Ex) -> Text {
    match ex1 {
        crate::lower::model::Ex::XVar(v_) => if v_ == f { f.clone() } else { Text::from(format!("{}: {}", f, v_)) },
        v_ => Text::from(format!("{}: {}", f, &expression(v_))),
    }
}

/// The step machine of `FieldInit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldInit: unbounded fn Text, Ex -> Text
/// ```
pub struct FieldInit {
    pub f: Text,
    pub ex1: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for FieldInit {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f = &self.f;
        let ex1 = &self.ex1;
        match ex1 {
            crate::lower::model::Ex::XVar(v_) => if v_ == f {
                prism_rtl::Turn::Finished(f.clone())
            } else {
                prism_rtl::Turn::Finished(Text::from(format!("{}: {}", f, v_)))
            },
            v_ => {
                let f = f.clone();
                let v_ = v_.clone();
                call_then(start_expression(v_.clone()), move |expression_6734: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f, &expression_6734))))
            },
        }
    }
}

/// `Start FieldInit, x`: what the function value is when passed to `@Run`.
pub fn start_field_init(f: Text, ex1: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FieldInit { f, ex1 })
}

/// ```prism
/// DecodeHead: unbounded fn OutTy -> Text
/// ```
pub fn decode_head(t: &crate::lower::model::OutTy) -> Text {
    match t {
        crate::lower::model::OutTy::OutNamed(n, m6807_0_1) if (m6807_0_1.len() == 0) => n.clone(),
        crate::lower::model::OutTy::OutNat => Text::lit("Nat"),
        crate::lower::model::OutTy::OutInt => Text::lit("Int"),
        crate::lower::model::OutTy::OutText => Text::lit("Text"),
        _ => Text::from(format!("<{}>", &type_(t))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `DecodeHead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DecodeHead: unbounded fn OutTy -> Text
/// ```
pub struct DecodeHead {
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for DecodeHead {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        match t {
            crate::lower::model::OutTy::OutNamed(n, m6807_0_1) if (m6807_0_1.len() == 0) => prism_rtl::Turn::Finished(n.clone()),
            crate::lower::model::OutTy::OutNat => prism_rtl::Turn::Finished(Text::lit("Nat")),
            crate::lower::model::OutTy::OutInt => prism_rtl::Turn::Finished(Text::lit("Int")),
            crate::lower::model::OutTy::OutText => prism_rtl::Turn::Finished(Text::lit("Text")),
            _ => {
                let t = t.clone();
                call_then(start_type_(t.clone()), move |type__6914: Text| prism_rtl::Turn::Finished(Text::from(format!("<{}>", &type__6914))))
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start DecodeHead, x`: what the function value is when passed to `@Run`.
pub fn start_decode_head(t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(DecodeHead { t })
}

/// ```prism
/// Label: fn Text -> Text
/// ```
pub fn label(l: &Text) -> Text {
    if crate::syntax::lexer::has_prefix(l, &Text::lit("'")) {
        l.clone()
    } else {
        Text::from(format!("'{}", l))
    }
}

/// ```prism
/// Format: unbounded fn [Ex] -> Text
/// ```
pub fn format(parts: &Array<crate::lower::model::Ex>) -> Text {
    let lit = concat(&each(parts, &(|p_: &crate::lower::model::Ex| format_piece(p_))));
    let vals = filter(parts, &(|p_: &crate::lower::model::Ex| !is_text(p_)));
    if &len(&vals) == &Nat::from(0u32) {
        Text::from(format!("Text::lit(\"{}\")", &crate::lower::escape(&concat(&each(parts, &(|p_: &crate::lower::model::Ex| plain_piece(p_)))))))
    } else {
        Text::from(format!("Text::from(format!(\"{}\", {}))", &lit, &args(&vals)))
    }
}

/// The step machine of `Format`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Format: unbounded fn [Ex] -> Text
/// ```
pub struct Format {
    pub parts: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for Format {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let parts = &self.parts;
        let lit = concat(&each(parts, &(|p_: &crate::lower::model::Ex| format_piece(p_))));
        let vals = filter(parts, &(|p_: &crate::lower::model::Ex| !is_text(p_)));
        if &len(&vals) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished(Text::from(format!("Text::lit(\"{}\")", &crate::lower::escape(&concat(&each(parts, &(|p_: &crate::lower::model::Ex| plain_piece(p_))))))))
        } else {
            call_then(start_args(vals.clone()), move |args_7429: Text| prism_rtl::Turn::Finished(Text::from(format!("Text::from(format!(\"{}\", {}))", &lit, &args_7429))))
        }
    }
}

/// `Start Format, x`: what the function value is when passed to `@Run`.
pub fn start_format(parts: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Format { parts })
}

/// ```prism
/// PlainPiece: fn Ex -> Text
/// ```
pub fn plain_piece(ex0: &crate::lower::model::Ex) -> Text {
    match ex0 {
        crate::lower::model::Ex::XText(t) => t.clone(),
        other => Text::lit(""),
    }
}

/// ```prism
/// FormatStr: unbounded fn [Ex] -> Text
/// ```
pub fn format_str(parts: &Array<crate::lower::model::Ex>) -> Text {
    let lit = concat(&each(parts, &(|p_: &crate::lower::model::Ex| str_piece(p_))));
    let vals = filter(parts, &(|p_: &crate::lower::model::Ex| !is_text(p_) && !is_var(p_)));
    if &len(&vals) == &Nat::from(0u32) {
        Text::from(format!("\"{}\"", &lit))
    } else {
        Text::from(format!("format!(\"{}\", {})", &lit, &args(&vals)))
    }
}

/// The step machine of `FormatStr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FormatStr: unbounded fn [Ex] -> Text
/// ```
pub struct FormatStr {
    pub parts: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for FormatStr {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let parts = &self.parts;
        let lit = concat(&each(parts, &(|p_: &crate::lower::model::Ex| str_piece(p_))));
        let vals = filter(parts, &(|p_: &crate::lower::model::Ex| !is_text(p_) && !is_var(p_)));
        if &len(&vals) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished(Text::from(format!("\"{}\"", &lit)))
        } else {
            call_then(start_args(vals.clone()), move |args_7894: Text| prism_rtl::Turn::Finished(Text::from(format!("format!(\"{}\", {})", &lit, &args_7894))))
        }
    }
}

/// `Start FormatStr, x`: what the function value is when passed to `@Run`.
pub fn start_format_str(parts: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FormatStr { parts })
}

/// ```prism
/// IsVar: fn Ex -> Bool
/// ```
pub fn is_var(ex0: &crate::lower::model::Ex) -> bool {
    match ex0 {
        crate::lower::model::Ex::XVar(_) => true,
        other => false,
    }
}

/// ```prism
/// StrPiece: fn Ex -> Text
/// ```
pub fn str_piece(ex0: &crate::lower::model::Ex) -> Text {
    match ex0 {
        crate::lower::model::Ex::XVar(n) => Text::from(format!("{{{}}}", n)),
        other => format_piece(other),
    }
}

/// ```prism
/// IsText: fn Ex -> Bool
/// ```
pub fn is_text(ex0: &crate::lower::model::Ex) -> bool {
    match ex0 {
        crate::lower::model::Ex::XText(_) => true,
        other => false,
    }
}

/// ```prism
/// FormatPiece: fn Ex -> Text
/// ```
pub fn format_piece(ex0: &crate::lower::model::Ex) -> Text {
    match ex0 {
        crate::lower::model::Ex::XText(t) => format_escape(&crate::lower::escape(t)),
        other => Text::lit("{}"),
    }
}

/// ```prism
/// FormatEscape: fn Text -> Text
/// ```
pub fn format_escape(t: &Text) -> Text {
    crate::syntax::lexer::map_chars(t, &(Rc::new(move |p0: Text| once_job(move || {
        let c = p0;
        prism_rtl::Turn::Finished(format_escape_char(&c))
    })) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>))
}

/// ```prism
/// FormatEscapeChar: fn Text -> Text
/// ```
pub fn format_escape_char(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("{")) => Text::lit("{{"),
        c1_0 if (c1_0 == &Text::lit("}")) => Text::lit("}}"),
        c => c.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IfExpression: unbounded fn Ex, Ex, Ex -> Text
/// ```
pub fn if_expression(c: &crate::lower::model::Ex, t: &crate::lower::model::Ex, e: &crate::lower::model::Ex) -> Text {
    let ct = expression(c);
    let tt = expression(t);
    let et = expression(e);
    let short = !crate::syntax::lexer::contains(&Text::from(format!("{}{}", &tt, &et)), &Text::lit("\n")) && (&len_text(&Text::from(format!("{}{}{}", &ct, &tt, &et))) < &Nat::from(70u32));
    if short {
        Text::from(format!("if {} {{ {} }} else {{ {} }}", &ct, &tt, &et))
    } else {
        crate::emit::rust::templates::if_(&ct, &tt, &et)
    }
}

/// The step machine of `IfExpression`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IfExpression: unbounded fn Ex, Ex, Ex -> Text
/// ```
pub struct IfExpression {
    pub c: crate::lower::model::Ex,
    pub t: crate::lower::model::Ex,
    pub e: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for IfExpression {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let c = &self.c;
        let t = &self.t;
        let e = &self.e;
        let c = c.clone();
        let e = e.clone();
        let t = t.clone();
        call_then(start_expression(c.clone()), move |expression_8632: Text| {
            let ct = expression_8632;
            call_then(start_expression(t.clone()), move |expression_8658: Text| {
                let tt = expression_8658;
                call_then(start_expression(e.clone()), move |expression_8684: Text| {
                    let et = expression_8684;
                    let short = !crate::syntax::lexer::contains(&Text::from(format!("{}{}", &tt, &et)), &Text::lit("\n")) && (&len_text(&Text::from(format!("{}{}{}", &ct, &tt, &et))) < &Nat::from(70u32));
                    if short {
                        prism_rtl::Turn::Finished(Text::from(format!("if {} {{ {} }} else {{ {} }}", &ct, &tt, &et)))
                    } else {
                        prism_rtl::Turn::Finished(crate::emit::rust::templates::if_(&ct, &tt, &et))
                    }
                })
            })
        })
    }
}

/// `Start IfExpression, x`: what the function value is when passed to `@Run`.
pub fn start_if_expression(c: crate::lower::model::Ex, t: crate::lower::model::Ex, e: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(IfExpression { c, t, e })
}

/// ```prism
/// Arms: unbounded fn [XArm], Bool -> Text
/// ```
pub fn arms(arms_: &Array<crate::lower::model::XArm>, fallback: &bool) -> Text {
    let lines = run_to_end(each_job(arms_.clone(), Rc::new(move |p0: crate::lower::model::XArm| entered(once_job(move || {
        let a = p0;
        prism_rtl::Turn::More(Rc::new(Arm { a: a.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>>>));
    let all = if *fallback {
        push(&lines, &Text::lit("_ => unreachable!(\"no arm matched\"),"))
    } else {
        lines.clone()
    };
    crate::syntax::lexer::join(&all, &Text::lit("\n"))
}

/// The step machine of `Arms`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Arms: unbounded fn [XArm], Bool -> Text
/// ```
pub struct Arms {
    pub arms_: Array<crate::lower::model::XArm>,
    pub fallback: bool,
}

impl prism_rtl::Job<Text> for Arms {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let arms_ = &self.arms_;
        let fallback = &self.fallback;
        let arms_ = arms_.clone();
        let fallback = *fallback;
        call_value(each_job(arms_.clone(), Rc::new(move |p0: crate::lower::model::XArm| entered(once_job(move || {
            let a = p0;
            prism_rtl::Turn::More(Rc::new(Arm { a: a.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_9015: Array<Text>| {
            let lines = each_9015;
            let all = if fallback {
                push(&lines, &Text::lit("_ => unreachable!(\"no arm matched\"),"))
            } else {
                lines.clone()
            };
            prism_rtl::Turn::Finished(crate::syntax::lexer::join(&all, &Text::lit("\n")))
        })
    }
}

/// `Start Arms, x`: what the function value is when passed to `@Run`.
pub fn start_arms(arms_: Array<crate::lower::model::XArm>, fallback: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Arms { arms_, fallback })
}

/// ```prism
/// Arm: unbounded fn XArm -> Text
/// ```
pub fn arm(a: &crate::lower::model::XArm) -> Text {
    let guard = if &len(&a.conds) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" if {}", &crate::syntax::lexer::join(&run_to_end(each_job(a.conds.clone(), Rc::new(move |p0: crate::lower::model::Cc| entered(once_job(move || {
            let c = p0;
            prism_rtl::Turn::More(Rc::new(Condition { cc0: c.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(" && "))))
    };
    let body = expression(&a.body);
    Text::from(format!("{}{} => {},", &pattern(&a.pat), &guard, &body))
}

/// The step machine of `Arm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Arm: unbounded fn XArm -> Text
/// ```
pub struct Arm {
    pub a: crate::lower::model::XArm,
}

impl prism_rtl::Job<Text> for Arm {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let a = &self.a;
        let guard = if &len(&a.conds) == &Nat::from(0u32) {
            Text::lit("")
        } else {
            Text::from(format!(" if {}", &crate::syntax::lexer::join(&run_to_end(each_job(a.conds.clone(), Rc::new(move |p0: crate::lower::model::Cc| entered(once_job(move || {
                let c = p0;
                prism_rtl::Turn::More(Rc::new(Condition { cc0: c.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(" && "))))
        };
        let a = a.clone();
        call_then(start_expression(a.body.clone()), move |expression_9307: Text| {
            let body = expression_9307;
            call_then(start_pattern(a.pat.clone()), move |pattern_9331: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{} => {},", &pattern_9331, &guard, &body))))
        })
    }
}

/// `Start Arm, x`: what the function value is when passed to `@Run`.
pub fn start_arm(a: crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Arm { a })
}

/// ```prism
/// Condition: unbounded fn Cc -> Text
/// ```
pub fn condition(cc0: &crate::lower::model::Cc) -> Text {
    match cc0 {
        crate::lower::model::Cc::CcIf(x) => operand(x),
        crate::lower::model::Cc::CcLet(p_, x) => Text::from(format!("let {} = {}", &pattern(p_), &expression(x))),
    }
}

/// The step machine of `Condition`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Condition: unbounded fn Cc -> Text
/// ```
pub struct Condition {
    pub cc0: crate::lower::model::Cc,
}

impl prism_rtl::Job<Text> for Condition {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cc0 = &self.cc0;
        match cc0 {
            crate::lower::model::Cc::CcIf(x) => prism_rtl::Turn::More(Rc::new(Operand { x: x.clone() })),
            crate::lower::model::Cc::CcLet(p_, x) => {
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_pattern(p_.clone()), move |pattern_9469: Text| call_then(start_expression(x.clone()), move |expression_9483: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {}", &pattern_9469, &expression_9483)))))
            },
        }
    }
}

/// `Start Condition, x`: what the function value is when passed to `@Run`.
pub fn start_condition(cc0: crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Condition { cc0 })
}

/// ```prism
/// Chain: unbounded fn Text, Ex, [XArm] -> Text
/// ```
pub fn chain(label_: &Text, s: &crate::lower::model::Ex, arms_: &Array<crate::lower::model::XArm>) -> Text {
    let in_place = match s {
        crate::lower::model::Ex::XRef(y) => is_bound(&**y),
        _ => is_bound(s),
    };
    let (bind, scrut) = if in_place {
        (Array::new(), expression(s))
    } else {
        (Array::from(vec![Text::from(format!("let scrutinee = {};", &expression(s)))]), Text::lit("scrutinee"))
    };
    let n = len(arms_);
    let lines = run_to_end(each_job(crate::check::errors::range0(&n), {
        let arms_ = arms_.clone();
        let scrut = scrut.clone();
        let label_ = label_.clone();
        Rc::new(move |p0: Nat| {
            let arms_ = arms_.clone();
            let scrut = scrut.clone();
            let label_ = label_.clone();
            entered(once_job(move || {
                let i = p0;
                {
                    let a = or(&index(&arms_, &i), &crate::lower::model::XArm { pat: crate::lower::model::Pa::PaWild, conds: Array::new(), body: crate::lower::model::Ex::XUnit });
                    let catch_all = (&a.pat == &crate::lower::model::Pa::PaWild) && (&len(&a.conds) == &Nat::from(0u32));
                    if catch_all {
                        prism_rtl::Turn::More(Rc::new(Expression { x: a.body.clone() }))
                    } else {
                        call_then(start_pattern(a.pat.clone()), move |pattern_10196: Text| call_value(each_job(a.conds.clone(), Rc::new(move |p0: crate::lower::model::Cc| entered(once_job(move || {
                            let c = p0;
                            prism_rtl::Turn::More(Rc::new(Condition { cc0: c.clone() }))
                        }))) as Rc<dyn Fn(crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_10226: Array<Text>| {
                            let head = crate::syntax::lexer::join(&append(&Array::from(vec![Text::from(format!("let {} = {}", &pattern_10196, &scrut))]), &each_10226), &Text::lit(" && "));
                            call_then(start_expression(a.body.clone()), move |expression_10313: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::chain_arm(&head, &label_, &continued(&expression_10313, &Text::lit("    ")))))
                        }))
                    }
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let ends = match crate::syntax::lexer::last(arms_) {
        Some(a) => (&a.pat == &crate::lower::model::Pa::PaWild) && (&len(&a.conds) == &Nat::from(0u32)),
        None => false,
    };
    let tail = if ends {
        Array::new()
    } else {
        Array::from(vec![Text::lit("unreachable!(\"no clause matched\")")])
    };
    Text::from(format!("{}: {{\n{}\n}}", label_, &indent(&crate::syntax::lexer::join(&append(&append(&bind, &lines), &tail), &Text::lit("\n")))))
}

/// The step machine of `Chain`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Chain: unbounded fn Text, Ex, [XArm] -> Text
/// ```
pub struct Chain {
    pub label_: Text,
    pub s: crate::lower::model::Ex,
    pub arms_: Array<crate::lower::model::XArm>,
}

impl prism_rtl::Job<Text> for Chain {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let label_ = &self.label_;
        let s = &self.s;
        let arms_ = &self.arms_;
        let in_place = match s {
            crate::lower::model::Ex::XRef(y) => is_bound(&**y),
            _ => is_bound(s),
        };
        let (bind, scrut) = if in_place {
            (Array::new(), expression(s))
        } else {
            (Array::from(vec![Text::from(format!("let scrutinee = {};", &expression(s)))]), Text::lit("scrutinee"))
        };
        let n = len(arms_);
        let arms_ = arms_.clone();
        let label_ = label_.clone();
        let s = s.clone();
        call_value(each_job(crate::check::errors::range0(&n), {
            let arms_ = arms_.clone();
            let scrut = scrut.clone();
            let label_ = label_.clone();
            Rc::new(move |p0: Nat| {
                let arms_ = arms_.clone();
                let scrut = scrut.clone();
                let label_ = label_.clone();
                entered(once_job(move || {
                    let i = p0;
                    {
                        let a = or(&index(&arms_, &i), &crate::lower::model::XArm { pat: crate::lower::model::Pa::PaWild, conds: Array::new(), body: crate::lower::model::Ex::XUnit });
                        let catch_all = (&a.pat == &crate::lower::model::Pa::PaWild) && (&len(&a.conds) == &Nat::from(0u32));
                        if catch_all {
                            prism_rtl::Turn::More(Rc::new(Expression { x: a.body.clone() }))
                        } else {
                            call_then(start_pattern(a.pat.clone()), move |pattern_10196: Text| call_value(each_job(a.conds.clone(), Rc::new(move |p0: crate::lower::model::Cc| entered(once_job(move || {
                                let c = p0;
                                prism_rtl::Turn::More(Rc::new(Condition { cc0: c.clone() }))
                            }))) as Rc<dyn Fn(crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_10226: Array<Text>| {
                                let head = crate::syntax::lexer::join(&append(&Array::from(vec![Text::from(format!("let {} = {}", &pattern_10196, &scrut))]), &each_10226), &Text::lit(" && "));
                                call_then(start_expression(a.body.clone()), move |expression_10313: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::chain_arm(&head, &label_, &continued(&expression_10313, &Text::lit("    ")))))
                            }))
                        }
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_9942: Array<Text>| {
            let lines = each_9942;
            let ends = match crate::syntax::lexer::last(&arms_) {
                Some(a) => (&a.pat == &crate::lower::model::Pa::PaWild) && (&len(&a.conds) == &Nat::from(0u32)),
                None => false,
            };
            let tail = if ends {
                Array::new()
            } else {
                Array::from(vec![Text::lit("unreachable!(\"no clause matched\")")])
            };
            prism_rtl::Turn::Finished(Text::from(format!("{}: {{\n{}\n}}", &label_, &indent(&crate::syntax::lexer::join(&append(&append(&bind, &lines), &tail), &Text::lit("\n"))))))
        })
    }
}

/// `Start Chain, x`: what the function value is when passed to `@Run`.
pub fn start_chain(label_: Text, s: crate::lower::model::Ex, arms_: Array<crate::lower::model::XArm>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Chain { label_, s, arms_ })
}

/// ```prism
/// IsBound: fn Ex -> Bool
/// ```
pub fn is_bound(x: &crate::lower::model::Ex) -> bool {
    'm10817: {
        if let crate::lower::model::Ex::XVar(_) = x {
            break 'm10817 true;
        }
        if let crate::lower::model::Ex::XField(m10817_1_0, _) = x && let crate::lower::model::Ex::XSelf = &**m10817_1_0 {
            break 'm10817 true;
        }
        if let crate::lower::model::Ex::XField(m10817_2_0, _) = x && let crate::lower::model::Ex::XMethod(m10817_2_0_r_0, _, _) = &**m10817_2_0 && let crate::lower::model::Ex::XUpgrade(_) = &**m10817_2_0_r_0 {
            break 'm10817 true;
        }
        if let crate::lower::model::Ex::XTarget(_) = x {
            break 'm10817 true;
        }
        if let crate::lower::model::Ex::XPart(m10817_4_0, _) = x && let crate::lower::model::Ex::XVar(_) = &**m10817_4_0 {
            break 'm10817 true;
        }
        false
    }
}

/// ```prism
/// Continued: fn Text, Text -> Text
/// ```
pub fn continued(t: &Text, pad: &Text) -> Text {
    let ls = split(t, &Text::lit("\n"));
    crate::syntax::lexer::join(&each(&crate::check::errors::range0(&len(&ls)), &(|i: &Nat| if (i == &Nat::from(0u32)) || (&or(&index(&ls, i), &Text::lit("")) == &Text::lit("")) {
        or(&index(&ls, i), &Text::lit(""))
    } else {
        Text::from(format!("{}{}", pad, &or(&index(&ls, i), &Text::lit(""))))
    })), &Text::lit("\n"))
}

/// ```prism
/// BodyLines: unbounded fn Ex -> Text
/// ```
pub fn body_lines(ex0: &crate::lower::model::Ex) -> Text {
    match ex0 {
        crate::lower::model::Ex::XBlock(dos, e) => if &len(dos) == &Nat::from(0u32) {
            body_lines(&**e)
        } else {
            Text::from(format!("{}\n{}", &statements(dos), &body_lines(&**e)))
        },
        x => expression(x),
    }
}

/// The step machine of `BodyLines`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BodyLines: unbounded fn Ex -> Text
/// ```
pub struct BodyLines {
    pub ex0: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for BodyLines {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let ex0 = &self.ex0;
        match ex0 {
            crate::lower::model::Ex::XBlock(dos, e) => if &len(dos) == &Nat::from(0u32) {
                prism_rtl::Turn::More(Rc::new(BodyLines { ex0: (**e).clone() }))
            } else {
                {
                    let dos = dos.clone();
                    let e = (**e).clone();
                    call_then(start_statements(dos.clone()), move |statements_11501: Text| call_then(start_body_lines(e.clone()), move |body_lines_11519: Text| prism_rtl::Turn::Finished(Text::from(format!("{}\n{}", &statements_11501, &body_lines_11519)))))
                }
            },
            x => prism_rtl::Turn::More(Rc::new(Expression { x: x.clone() })),
        }
    }
}

/// `Start BodyLines, x`: what the function value is when passed to `@Run`.
pub fn start_body_lines(ex0: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(BodyLines { ex0 })
}

/// ```prism
/// Indent: fn Text -> Text
/// ```
pub fn indent(t: &Text) -> Text {
    crate::syntax::lexer::join(&each(&split(t, &Text::lit("\n")), &(|l: &Text| if l == &Text::lit("") { Text::lit("") } else { Text::from(format!("    {}", l)) })), &Text::lit("\n"))
}

/// ```prism
/// Pattern: unbounded fn Pa -> Text
/// ```
pub fn pattern(p_: &crate::lower::model::Pa) -> Text {
    'm11968: {
        if let crate::lower::model::Pa::PaWild = p_ {
            break 'm11968 Text::lit("_");
        }
        if let crate::lower::model::Pa::PaBind(n) = p_ {
            break 'm11968 n.clone();
        }
        if let crate::lower::model::Pa::PaMut(n) = p_ {
            break 'm11968 Text::from(format!("mut {}", n));
        }
        if let crate::lower::model::Pa::PaCtor(c, ps) = p_ {
            break 'm11968 Text::from(format!("{}({})", c, &crate::syntax::lexer::join(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                let q = p0;
                prism_rtl::Turn::More(Rc::new(Pattern_ { p_: q.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))));
        }
        if let crate::lower::model::Pa::PaUnit(c) = p_ {
            break 'm11968 c.clone();
        }
        if let crate::lower::model::Pa::PaRecord(c, fs, rest) = p_ {
            break 'm11968 {
                let parts = run_to_end(each_job(fs.clone(), Rc::new(move |p0: (Text, crate::lower::model::Pa)| entered(once_job(move || {
                    let (f, q) = p0;
                    match &q {
                        crate::lower::model::Pa::PaBind(n) => if n == &f {
                            prism_rtl::Turn::Finished(f.clone())
                        } else {
                            prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f, n)))
                        },
                        _ => call_then(start_pattern(q.clone()), move |pattern_12270: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f, &pattern_12270)))),
                    }
                }))) as Rc<dyn Fn((Text, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Text>>>));
                let all = if *rest { push(&parts, &Text::lit("..")) } else { parts.clone() };
                Text::from(format!("{} {{ {} }}", c, &crate::syntax::lexer::join(&all, &Text::lit(", "))))
            };
        }
        if let crate::lower::model::Pa::PaTuple(m11968_6_0) = p_ && (m11968_6_0.len() == 1) && let Some(one) = index(m11968_6_0, &Nat::from(0u32)) {
            break 'm11968 Text::from(format!("({},)", &pattern(&one)));
        }
        if let crate::lower::model::Pa::PaTuple(ps) = p_ {
            break 'm11968 Text::from(format!("({})", &crate::syntax::lexer::join(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                let q = p0;
                prism_rtl::Turn::More(Rc::new(Pattern_ { p_: q.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))));
        }
        if let crate::lower::model::Pa::PaChar(c) = p_ {
            break 'm11968 Text::from(format!("'{}'", &crate::lower::char_escape(c)));
        }
        if let crate::lower::model::Pa::PaBool(b) = p_ {
            break 'm11968 if *b { Text::lit("true") } else { Text::lit("false") };
        }
        if let crate::lower::model::Pa::PaIndex(n) = p_ {
            break 'm11968 Text::from(format!("{}", n));
        }
        if let crate::lower::model::Pa::PaConst(n) = p_ {
            break 'm11968 Text::from(format!("Self::{}", n));
        }
        if let crate::lower::model::Pa::PaSlice(ps) = p_ {
            break 'm11968 Text::from(format!("[{}]", &crate::syntax::lexer::join(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                let q = p0;
                prism_rtl::Turn::More(Rc::new(Pattern_ { p_: q.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))));
        }
        if let crate::lower::model::Pa::PaRest(m11968_13_0) = p_ && (m11968_13_0 == &Text::lit("")) {
            break 'm11968 Text::lit("..");
        }
        if let crate::lower::model::Pa::PaRest(n) = p_ {
            break 'm11968 Text::from(format!("{} @ ..", n));
        }
        if let crate::lower::model::Pa::PaTyped(q, t) = p_ {
            break 'm11968 Text::from(format!("{}: {}", &pattern(&**q), &type_(t)));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `Pattern_`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Pattern: unbounded fn Pa -> Text
/// ```
pub struct Pattern_ {
    pub p_: crate::lower::model::Pa,
}

impl prism_rtl::Job<Text> for Pattern_ {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let p_ = &self.p_;
        'm11968: {
            if let crate::lower::model::Pa::PaWild = p_ {
                break 'm11968 prism_rtl::Turn::Finished(Text::lit("_"));
            }
            if let crate::lower::model::Pa::PaBind(n) = p_ {
                break 'm11968 prism_rtl::Turn::Finished(n.clone());
            }
            if let crate::lower::model::Pa::PaMut(n) = p_ {
                break 'm11968 prism_rtl::Turn::Finished(Text::from(format!("mut {}", n)));
            }
            if let crate::lower::model::Pa::PaCtor(c, ps) = p_ {
                break 'm11968 {
                    let c = c.clone();
                    let ps = ps.clone();
                    call_value(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                        let q = p0;
                        prism_rtl::Turn::More(Rc::new(Pattern_ { p_: q.clone() }))
                    }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_12062: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &c, &crate::syntax::lexer::join(&each_12062, &Text::lit(", "))))))
                };
            }
            if let crate::lower::model::Pa::PaUnit(c) = p_ {
                break 'm11968 prism_rtl::Turn::Finished(c.clone());
            }
            if let crate::lower::model::Pa::PaRecord(c, fs, rest) = p_ {
                break 'm11968 {
                    let c = c.clone();
                    let fs = fs.clone();
                    let rest = *rest;
                    call_value(each_job(fs.clone(), Rc::new(move |p0: (Text, crate::lower::model::Pa)| entered(once_job(move || {
                        let (f, q) = p0;
                        match &q {
                            crate::lower::model::Pa::PaBind(n) => if n == &f {
                                prism_rtl::Turn::Finished(f.clone())
                            } else {
                                prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f, n)))
                            },
                            _ => call_then(start_pattern(q.clone()), move |pattern_12270: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f, &pattern_12270)))),
                        }
                    }))) as Rc<dyn Fn((Text, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_12158: Array<Text>| {
                        let parts = each_12158;
                        let all = if rest { push(&parts, &Text::lit("..")) } else { parts.clone() };
                        prism_rtl::Turn::Finished(Text::from(format!("{} {{ {} }}", &c, &crate::syntax::lexer::join(&all, &Text::lit(", ")))))
                    })
                };
            }
            if let crate::lower::model::Pa::PaTuple(m11968_6_0) = p_ && (m11968_6_0.len() == 1) && let Some(one) = index(m11968_6_0, &Nat::from(0u32)) {
                break 'm11968 call_then(start_pattern(one.clone()), move |pattern_12399: Text| prism_rtl::Turn::Finished(Text::from(format!("({},)", &pattern_12399))));
            }
            if let crate::lower::model::Pa::PaTuple(ps) = p_ {
                break 'm11968 {
                    let ps = ps.clone();
                    call_value(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                        let q = p0;
                        prism_rtl::Turn::More(Rc::new(Pattern_ { p_: q.clone() }))
                    }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_12440: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("({})", &crate::syntax::lexer::join(&each_12440, &Text::lit(", "))))))
                };
            }
            if let crate::lower::model::Pa::PaChar(c) = p_ {
                break 'm11968 prism_rtl::Turn::Finished(Text::from(format!("'{}'", &crate::lower::char_escape(c))));
            }
            if let crate::lower::model::Pa::PaBool(b) = p_ {
                break 'm11968 if *b {
                    prism_rtl::Turn::Finished(Text::lit("true"))
                } else {
                    prism_rtl::Turn::Finished(Text::lit("false"))
                };
            }
            if let crate::lower::model::Pa::PaIndex(n) = p_ {
                break 'm11968 prism_rtl::Turn::Finished(Text::from(format!("{}", n)));
            }
            if let crate::lower::model::Pa::PaConst(n) = p_ {
                break 'm11968 prism_rtl::Turn::Finished(Text::from(format!("Self::{}", n)));
            }
            if let crate::lower::model::Pa::PaSlice(ps) = p_ {
                break 'm11968 {
                    let ps = ps.clone();
                    call_value(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                        let q = p0;
                        prism_rtl::Turn::More(Rc::new(Pattern_ { p_: q.clone() }))
                    }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_12621: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("[{}]", &crate::syntax::lexer::join(&each_12621, &Text::lit(", "))))))
                };
            }
            if let crate::lower::model::Pa::PaRest(m11968_13_0) = p_ && (m11968_13_0 == &Text::lit("")) {
                break 'm11968 prism_rtl::Turn::Finished(Text::lit(".."));
            }
            if let crate::lower::model::Pa::PaRest(n) = p_ {
                break 'm11968 prism_rtl::Turn::Finished(Text::from(format!("{} @ ..", n)));
            }
            if let crate::lower::model::Pa::PaTyped(q, t) = p_ {
                break 'm11968 {
                    let q = (**q).clone();
                    let t = t.clone();
                    call_then(start_pattern(q.clone()), move |pattern_12720: Text| call_then(start_type_(t.clone()), move |type__12733: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &pattern_12720, &type__12733)))))
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start Pattern_, x`: what the function value is when passed to `@Run`.
pub fn start_pattern(p_: crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Pattern_ { p_ })
}

/// ```prism
/// Statements: unbounded fn [Do] -> Text
/// ```
pub fn statements(dos: &Array<crate::lower::model::Do>) -> Text {
    crate::syntax::lexer::join(&run_to_end(each_job(dos.clone(), Rc::new(move |p0: crate::lower::model::Do| entered(once_job(move || {
        let d = p0;
        prism_rtl::Turn::More(Rc::new(Statement { d: d.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))
}

/// The step machine of `Statements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Statements: unbounded fn [Do] -> Text
/// ```
pub struct Statements {
    pub dos: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for Statements {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let dos = &self.dos;
        let dos = dos.clone();
        call_value(each_job(dos.clone(), Rc::new(move |p0: crate::lower::model::Do| entered(once_job(move || {
            let d = p0;
            prism_rtl::Turn::More(Rc::new(Statement { d: d.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_12807: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::join(&each_12807, &Text::lit("\n"))))
    }
}

/// `Start Statements, x`: what the function value is when passed to `@Run`.
pub fn start_statements(dos: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Statements { dos })
}

/// ```prism
/// Statement: unbounded fn Do -> Text
/// ```
pub fn statement(d: &crate::lower::model::Do) -> Text {
    match d {
        crate::lower::model::Do::DoLet(p_, x) => Text::from(format!("let {} = {};", &pattern(p_), &expression(x))),
        crate::lower::model::Do::DoLetElse(p_, x, e) => Text::from(format!("let {} = {} else {{ {} }};", &pattern(p_), &expression(x), &expression(e))),
        crate::lower::model::Do::DoAssign(p_, x) => Text::from(format!("{} = {};", &expression(p_), &expression(x))),
        crate::lower::model::Do::DoWhile(c, body) => crate::emit::rust::templates::if_stmt(&Text::from(format!("while {}", &expression(c))), &statements(body)),
        crate::lower::model::Do::DoWhileLet(p_, x, body) => crate::emit::rust::templates::if_stmt(&Text::from(format!("while let {} = {}", &pattern(p_), &expression(x))), &statements(body)),
        crate::lower::model::Do::DoFor(p_, x, body) => crate::emit::rust::templates::if_stmt(&Text::from(format!("for {} in {}", &pattern(p_), &expression(x))), &statements(body)),
        crate::lower::model::Do::DoExpr(x) => Text::from(format!("{};", &expression(x))),
        crate::lower::model::Do::DoIf(c, t, e) => Text::from(format!("{}{}", &crate::emit::rust::templates::if_stmt(&Text::from(format!("if {}", &expression(c))), &statements(t)), &else_branch(e))),
        crate::lower::model::Do::DoIfLet(p_, x, t, e) => Text::from(format!("{}{}", &crate::emit::rust::templates::if_stmt(&Text::from(format!("if let {} = {}", &pattern(p_), &expression(x))), &statements(t)), &else_branch(e))),
        crate::lower::model::Do::DoMatch(x, cases) => crate::emit::rust::templates::match_(&expression(x), &crate::syntax::lexer::join(&run_to_end(each_job(cases.clone(), Rc::new(move |p0: (crate::lower::model::Pa, Array<crate::lower::model::Do>)| entered(once_job(move || {
            let (p_, body) = p0;
            call_then(start_pattern(p_.clone()), move |pattern_13644: Text| call_then(start_statements(body.clone()), move |statements_13657: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::arm_block(&pattern_13644, &statements_13657))))
        }))) as Rc<dyn Fn((crate::lower::model::Pa, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))),
        crate::lower::model::Do::DoReturn(x) => Text::from(format!("return {};", &expression(x))),
        crate::lower::model::Do::DoBlock(body) => crate::emit::rust::templates::scope(&statements(body)),
        crate::lower::model::Do::DoScope(body) => Text::from(format!("{{ {} }};", &inline_statements(body))),
        crate::lower::model::Do::DoLine(body) => Text::from(format!("{};", &inline_statements(body))),
        crate::lower::model::Do::DoNote(t) => Text::from(format!("// {}", t)),
    }
}

/// The step machine of `Statement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Statement: unbounded fn Do -> Text
/// ```
pub struct Statement {
    pub d: crate::lower::model::Do,
}

impl prism_rtl::Job<Text> for Statement {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let d = &self.d;
        match d {
            crate::lower::model::Do::DoLet(p_, x) => {
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_pattern(p_.clone()), move |pattern_12925: Text| call_then(start_expression(x.clone()), move |expression_12939: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {};", &pattern_12925, &expression_12939)))))
            },
            crate::lower::model::Do::DoLetElse(p_, x, e) => {
                let e = e.clone();
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_pattern(p_.clone()), move |pattern_12984: Text| call_then(start_expression(x.clone()), move |expression_12998: Text| call_then(start_expression(e.clone()), move |expression_13021: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {} else {{ {} }};", &pattern_12984, &expression_12998, &expression_13021))))))
            },
            crate::lower::model::Do::DoAssign(p_, x) => {
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_expression(p_.clone()), move |expression_13061: Text| call_then(start_expression(x.clone()), move |expression_13078: Text| prism_rtl::Turn::Finished(Text::from(format!("{} = {};", &expression_13061, &expression_13078)))))
            },
            crate::lower::model::Do::DoWhile(c, body) => {
                let body = body.clone();
                let c = c.clone();
                call_then(start_expression(c.clone()), move |expression_13130: Text| call_then(start_statements(body.clone()), move |statements_13147: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::if_stmt(&Text::from(format!("while {}", &expression_13130)), &statements_13147))))
            },
            crate::lower::model::Do::DoWhileLet(p_, x, body) => {
                let body = body.clone();
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_pattern(p_.clone()), move |pattern_13210: Text| call_then(start_expression(x.clone()), move |expression_13224: Text| call_then(start_statements(body.clone()), move |statements_13241: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::if_stmt(&Text::from(format!("while let {} = {}", &pattern_13210, &expression_13224)), &statements_13241)))))
            },
            crate::lower::model::Do::DoFor(p_, x, body) => {
                let body = body.clone();
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_pattern(p_.clone()), move |pattern_13293: Text| call_then(start_expression(x.clone()), move |expression_13308: Text| call_then(start_statements(body.clone()), move |statements_13325: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::if_stmt(&Text::from(format!("for {} in {}", &pattern_13293, &expression_13308)), &statements_13325)))))
            },
            crate::lower::model::Do::DoExpr(x) => {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_13358: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &expression_13358))))
            },
            crate::lower::model::Do::DoIf(c, t, e) => {
                let c = c.clone();
                let e = e.clone();
                let t = t.clone();
                call_then(start_expression(c.clone()), move |expression_13406: Text| call_then(start_statements(t.clone()), move |statements_13423: Text| call_then(start_else_branch(e.clone()), move |else_branch_13438: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &crate::emit::rust::templates::if_stmt(&Text::from(format!("if {}", &expression_13406)), &statements_13423), &else_branch_13438))))))
            },
            crate::lower::model::Do::DoIfLet(p_, x, t, e) => {
                let e = e.clone();
                let p_ = p_.clone();
                let t = t.clone();
                let x = x.clone();
                call_then(start_pattern(p_.clone()), move |pattern_13495: Text| call_then(start_expression(x.clone()), move |expression_13509: Text| call_then(start_statements(t.clone()), move |statements_13526: Text| call_then(start_else_branch(e.clone()), move |else_branch_13541: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &crate::emit::rust::templates::if_stmt(&Text::from(format!("if let {} = {}", &pattern_13495, &expression_13509)), &statements_13526), &else_branch_13541)))))))
            },
            crate::lower::model::Do::DoMatch(x, cases) => {
                let cases = cases.clone();
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_13585: Text| call_value(each_job(cases.clone(), Rc::new(move |p0: (crate::lower::model::Pa, Array<crate::lower::model::Do>)| entered(once_job(move || {
                    let (p_, body) = p0;
                    call_then(start_pattern(p_.clone()), move |pattern_13644: Text| call_then(start_statements(body.clone()), move |statements_13657: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::arm_block(&pattern_13644, &statements_13657))))
                }))) as Rc<dyn Fn((crate::lower::model::Pa, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_13607: Array<Text>| prism_rtl::Turn::Finished(crate::emit::rust::templates::match_(&expression_13585, &crate::syntax::lexer::join(&each_13607, &Text::lit("\n"))))))
            },
            crate::lower::model::Do::DoReturn(x) => {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_13707: Text| prism_rtl::Turn::Finished(Text::from(format!("return {};", &expression_13707))))
            },
            crate::lower::model::Do::DoBlock(body) => {
                let body = body.clone();
                call_then(start_statements(body.clone()), move |statements_13748: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::scope(&statements_13748)))
            },
            crate::lower::model::Do::DoScope(body) => {
                let body = body.clone();
                call_then(start_inline_statements(body.clone()), move |inline_statements_13788: Text| prism_rtl::Turn::Finished(Text::from(format!("{{ {} }};", &inline_statements_13788))))
            },
            crate::lower::model::Do::DoLine(body) => {
                let body = body.clone();
                call_then(start_inline_statements(body.clone()), move |inline_statements_13835: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &inline_statements_13835))))
            },
            crate::lower::model::Do::DoNote(t) => prism_rtl::Turn::Finished(Text::from(format!("// {}", t))),
        }
    }
}

/// `Start Statement, x`: what the function value is when passed to `@Run`.
pub fn start_statement(d: crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Statement { d })
}

/// ```prism
/// InlineStatements: unbounded fn [Do] -> Text
/// ```
pub fn inline_statements(dos: &Array<crate::lower::model::Do>) -> Text {
    crate::syntax::lexer::join(&run_to_end(each_job(dos.clone(), Rc::new(move |p0: crate::lower::model::Do| entered(once_job(move || {
        let d = p0;
        prism_rtl::Turn::More(Rc::new(InlineStatement { do_0: d.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(" "))
}

/// The step machine of `InlineStatements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InlineStatements: unbounded fn [Do] -> Text
/// ```
pub struct InlineStatements {
    pub dos: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for InlineStatements {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let dos = &self.dos;
        let dos = dos.clone();
        call_value(each_job(dos.clone(), Rc::new(move |p0: crate::lower::model::Do| entered(once_job(move || {
            let d = p0;
            prism_rtl::Turn::More(Rc::new(InlineStatement { do_0: d.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_14008: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::join(&each_14008, &Text::lit(" "))))
    }
}

/// `Start InlineStatements, x`: what the function value is when passed to `@Run`.
pub fn start_inline_statements(dos: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(InlineStatements { dos })
}

/// ```prism
/// InlineStatement: unbounded fn Do -> Text
/// ```
pub fn inline_statement(do_0: &crate::lower::model::Do) -> Text {
    match do_0 {
        crate::lower::model::Do::DoIf(c, t, c0_0_2) if (c0_0_2.len() == 0) => Text::from(format!("if {} {{ {} }}", &expression(c), &inline_statements(t))),
        d => statement(d),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `InlineStatement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InlineStatement: unbounded fn Do -> Text
/// ```
pub struct InlineStatement {
    pub do_0: crate::lower::model::Do,
}

impl prism_rtl::Job<Text> for InlineStatement {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let do_0 = &self.do_0;
        match do_0 {
            crate::lower::model::Do::DoIf(c, t, j0_0_2) if (j0_0_2.len() == 0) => {
                let c = c.clone();
                let t = t.clone();
                call_then(start_expression(c.clone()), move |expression_14133: Text| call_then(start_inline_statements(t.clone()), move |inline_statements_14151: Text| prism_rtl::Turn::Finished(Text::from(format!("if {} {{ {} }}", &expression_14133, &inline_statements_14151)))))
            },
            d => prism_rtl::Turn::More(Rc::new(Statement { d: d.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start InlineStatement, x`: what the function value is when passed to `@Run`.
pub fn start_inline_statement(do_0: crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(InlineStatement { do_0 })
}

/// ```prism
/// ElseBranch: unbounded fn [Do] -> Text
/// ```
pub fn else_branch(xs0: &Array<crate::lower::model::Do>) -> Text {
    'c: {
        if let c0_0 = xs0 && (c0_0.len() == 0) {
            break 'c Text::lit("");
        }
        if let c1_0 = xs0 && (c1_0.len() == 1) && let Some(crate::lower::model::Do::DoIf(c, t, e)) = index(c1_0, &Nat::from(0u32)) {
            break 'c Text::from(format!(" else {}", &statement(&crate::lower::model::Do::DoIf(c.clone(), t.clone(), e.clone()))));
        }
        if let c2_0 = xs0 && (c2_0.len() == 1) && let Some(crate::lower::model::Do::DoIfLet(p_, x, t, e)) = index(c2_0, &Nat::from(0u32)) {
            break 'c Text::from(format!(" else {}", &statement(&crate::lower::model::Do::DoIfLet(p_.clone(), x.clone(), t.clone(), e.clone()))));
        }
        if let body = xs0 {
            break 'c crate::emit::rust::templates::else_(&statements(body));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `ElseBranch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ElseBranch: unbounded fn [Do] -> Text
/// ```
pub struct ElseBranch {
    pub xs0: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for ElseBranch {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let xs0 = &self.xs0;
        'j: {
            if let j0_0 = xs0 && (j0_0.len() == 0) {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let j1_0 = xs0 && (j1_0.len() == 1) && let Some(crate::lower::model::Do::DoIf(c, t, e)) = index(j1_0, &Nat::from(0u32)) {
                break 'j call_then(start_statement(crate::lower::model::Do::DoIf(c.clone(), t.clone(), e.clone())), move |statement_14363: Text| prism_rtl::Turn::Finished(Text::from(format!(" else {}", &statement_14363))));
            }
            if let j2_0 = xs0 && (j2_0.len() == 1) && let Some(crate::lower::model::Do::DoIfLet(p_, x, t, e)) = index(j2_0, &Nat::from(0u32)) {
                break 'j call_then(start_statement(crate::lower::model::Do::DoIfLet(p_.clone(), x.clone(), t.clone(), e.clone())), move |statement_14439: Text| prism_rtl::Turn::Finished(Text::from(format!(" else {}", &statement_14439))));
            }
            if let body = xs0 {
                break 'j {
                    let body = body.clone();
                    call_then(start_statements(body.clone()), move |statements_14499: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::else_(&statements_14499)))
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start ElseBranch, x`: what the function value is when passed to `@Run`.
pub fn start_else_branch(xs0: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ElseBranch { xs0 })
}

/// ```prism
/// Generics: fn [((Text, [Text]))] -> Text
/// ```
pub fn generics(xs0: &Array<(Text, Array<Text>)>) -> Text {
    match xs0 {
        c0_0 if (c0_0.len() == 0) => Text::lit(""),
        gs => Text::from(format!("<{}>", &crate::syntax::lexer::join(&each(gs, &(|(g, bs): &(Text, Array<Text>)| if &len(bs) == &Nat::from(0u32) {
            g.clone()
        } else {
            Text::from(format!("{}: {}", g, &crate::syntax::lexer::join(bs, &Text::lit(" + "))))
        })), &Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// GenericNames: fn [Text] -> Text
/// ```
pub fn generic_names(xs0: &Array<Text>) -> Text {
    match xs0 {
        c0_0 if (c0_0.len() == 0) => Text::lit(""),
        ps => Text::from(format!("<{}>", &crate::syntax::lexer::join(ps, &Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Bounded: fn [Text], Text -> Text
/// ```
pub fn bounded(xs0: &Array<Text>, text1: &Text) -> Text {
    match (xs0, text1) {
        (c0_0, _) if (c0_0.len() == 0) => Text::lit(""),
        (ps, tr) => Text::from(format!("<{}>", &crate::syntax::lexer::join(&each(ps, &(|p_: &Text| Text::from(format!("{}: {}", p_, tr)))), &Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// RustItem: unbounded fn Item -> Text
/// ```
pub fn rust_item(it: &crate::lower::model::Item) -> Text {
    match it {
        crate::lower::model::Item::ItTrait(t) => rust_trait(t),
        crate::lower::model::Item::ItImpl(i) => rust_impl(i),
        crate::lower::model::Item::ItType(t) => type_decl(t),
        crate::lower::model::Item::ItTag(t) => rust_tag(t),
        crate::lower::model::Item::ItRow(r) => rust_row(r),
        crate::lower::model::Item::ItFn(f) => rust_fn(f),
        crate::lower::model::Item::ItJob(j) => rust_job(j),
        crate::lower::model::Item::ItNode(n) => rust_node(n),
        crate::lower::model::Item::ItNote(t) => Text::from(format!("// {}\n", t)),
        crate::lower::model::Item::ItRefused(t) => Text::from(format!("compile_error!(\"{}{}\");\n", &crate::lower::lowering_refusal(), &crate::lower::escape(t))),
    }
}

/// The step machine of `RustItem`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustItem: unbounded fn Item -> Text
/// ```
pub struct RustItem {
    pub it: crate::lower::model::Item,
}

impl prism_rtl::Job<Text> for RustItem {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let it = &self.it;
        match it {
            crate::lower::model::Item::ItTrait(t) => prism_rtl::Turn::More(Rc::new(RustTrait { t: t.clone() })),
            crate::lower::model::Item::ItImpl(i) => prism_rtl::Turn::More(Rc::new(RustImpl { i: i.clone() })),
            crate::lower::model::Item::ItType(t) => prism_rtl::Turn::More(Rc::new(TypeDecl { t: t.clone() })),
            crate::lower::model::Item::ItTag(t) => prism_rtl::Turn::More(Rc::new(RustTag { t: t.clone() })),
            crate::lower::model::Item::ItRow(r) => prism_rtl::Turn::More(Rc::new(RustRow { r: r.clone() })),
            crate::lower::model::Item::ItFn(f) => prism_rtl::Turn::More(Rc::new(RustFn { f: f.clone() })),
            crate::lower::model::Item::ItJob(j) => prism_rtl::Turn::More(Rc::new(RustJob { j: j.clone() })),
            crate::lower::model::Item::ItNode(n) => prism_rtl::Turn::More(Rc::new(RustNode { n: n.clone() })),
            crate::lower::model::Item::ItNote(t) => prism_rtl::Turn::Finished(Text::from(format!("// {}\n", t))),
            crate::lower::model::Item::ItRefused(t) => prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}{}\");\n", &crate::lower::lowering_refusal(), &crate::lower::escape(t)))),
        }
    }
}

/// `Start RustItem, x`: what the function value is when passed to `@Run`.
pub fn start_rust_item(it: crate::lower::model::Item) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustItem { it })
}

/// ```prism
/// RustTrait: unbounded fn TraitDef -> Text
/// ```
pub fn rust_trait(t: &crate::lower::model::TraitDef) -> Text {
    let ms = crate::syntax::lexer::join(&run_to_end(each_job(t.methods.clone(), Rc::new(move |p0: crate::lower::model::FnDef| entered(once_job(move || {
        let f = p0;
        prism_rtl::Turn::More(Rc::new(TraitMethod { f: f.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    Text::from(format!("{}pub trait {} {{\n{}\n}}\n", &crate::emit::rust::templates::source_doc(&Text::lit(""), &t.doc), &t.name, &indent(&ms)))
}

/// The step machine of `RustTrait`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustTrait: unbounded fn TraitDef -> Text
/// ```
pub struct RustTrait {
    pub t: crate::lower::model::TraitDef,
}

impl prism_rtl::Job<Text> for RustTrait {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        let t = t.clone();
        call_value(each_job(t.methods.clone(), Rc::new(move |p0: crate::lower::model::FnDef| entered(once_job(move || {
            let f = p0;
            prism_rtl::Turn::More(Rc::new(TraitMethod { f: f.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_15640: Array<Text>| {
            let ms = crate::syntax::lexer::join(&each_15640, &Text::lit("\n"));
            prism_rtl::Turn::Finished(Text::from(format!("{}pub trait {} {{\n{}\n}}\n", &crate::emit::rust::templates::source_doc(&Text::lit(""), &t.doc), &t.name, &indent(&ms))))
        })
    }
}

/// `Start RustTrait, x`: what the function value is when passed to `@Run`.
pub fn start_rust_trait(t: crate::lower::model::TraitDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustTrait { t })
}

/// ```prism
/// Signature: unbounded fn FnDef, Text -> Text
/// ```
pub fn signature(f: &crate::lower::model::FnDef, vis: &Text) -> Text {
    let params = crate::syntax::lexer::join(&run_to_end(each_job(f.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (n, t) = p0;
        call_then(start_type_(t.clone()), move |type__15873: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n, &type__15873))))
    }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "));
    Text::from(format!("{}fn {}{}({}) -> {}", vis, &f.name, &generics(&f.generics), &params, &type_(&f.ret)))
}

/// The step machine of `Signature`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Signature: unbounded fn FnDef, Text -> Text
/// ```
pub struct Signature {
    pub f: crate::lower::model::FnDef,
    pub vis: Text,
}

impl prism_rtl::Job<Text> for Signature {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f = &self.f;
        let vis = &self.vis;
        let f = f.clone();
        let vis = vis.clone();
        call_value(each_job(f.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
            let (n, t) = p0;
            call_then(start_type_(t.clone()), move |type__15873: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n, &type__15873))))
        }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_15839: Array<Text>| {
            let params = crate::syntax::lexer::join(&each_15839, &Text::lit(", "));
            call_then(start_type_(f.ret.clone()), move |type__15946: Text| prism_rtl::Turn::Finished(Text::from(format!("{}fn {}{}({}) -> {}", &vis, &f.name, &generics(&f.generics), &params, &type__15946))))
        })
    }
}

/// `Start Signature, x`: what the function value is when passed to `@Run`.
pub fn start_signature(f: crate::lower::model::FnDef, vis: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Signature { f, vis })
}

/// ```prism
/// TraitMethod: unbounded fn FnDef -> Text
/// ```
pub fn trait_method(f: &crate::lower::model::FnDef) -> Text {
    if f.public {
        crate::emit::rust::templates::fn_(&Text::lit(""), &signature(f, &Text::lit("")), &body_lines(&f.body))
    } else {
        Text::from(format!("{};", &signature(f, &Text::lit(""))))
    }
}

/// The step machine of `TraitMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TraitMethod: unbounded fn FnDef -> Text
/// ```
pub struct TraitMethod {
    pub f: crate::lower::model::FnDef,
}

impl prism_rtl::Job<Text> for TraitMethod {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f = &self.f;
        if f.public {
            {
                let f = f.clone();
                call_then(start_signature(f.clone(), Text::lit("")), move |signature_16040: Text| call_then(start_body_lines(f.body.clone()), move |body_lines_16059: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::fn_(&Text::lit(""), &signature_16040, &body_lines_16059))))
            }
        } else {
            {
                let f = f.clone();
                call_then(start_signature(f.clone(), Text::lit("")), move |signature_16085: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &signature_16085))))
            }
        }
    }
}

/// `Start TraitMethod, x`: what the function value is when passed to `@Run`.
pub fn start_trait_method(f: crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TraitMethod { f })
}

/// ```prism
/// RustImpl: unbounded fn ImplDef -> Text
/// ```
pub fn rust_impl(i: &crate::lower::model::ImplDef) -> Text {
    let head = type_(&i.head);
    let gens = generics(&i.generics);
    match &i.cls {
        m16360_0 if (m16360_0 == &Text::lit("Prelude.Show")) => {
            let fns = crate::syntax::lexer::join(&run_to_end(each_job(i.methods.clone(), Rc::new(move |p0: crate::lower::model::FnDef| entered(once_job(move || {
                let f = p0;
                prism_rtl::Turn::More(Rc::new(RustFn { f: f.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
            let shown = or(&index(&each(&i.methods, &(|f: &crate::lower::model::FnDef| f.name.clone())), &Nat::from(0u32)), &Text::lit("show"));
            Text::from(format!("{}\n{}", &fns, &crate::emit::rust::templates::impl_(&gens, &Text::lit("Show"), &head, &Text::lit("fn show(&self, p: &mut Printer)"), &Text::from(format!("p.raw(&{}(self).to_string());", &shown)))))
        },
        m16360_1 if (m16360_1 == &Text::lit("Prelude.Eq")) => {
            let fns = crate::syntax::lexer::join(&run_to_end(each_job(i.methods.clone(), Rc::new(move |p0: crate::lower::model::FnDef| entered(once_job(move || {
                let f = p0;
                prism_rtl::Turn::More(Rc::new(RustFn { f: f.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
            let eq = fold(&i.methods, &Text::lit(""), &(|acc: &Text, f: &crate::lower::model::FnDef| if !crate::syntax::lexer::has_prefix(&f.name, &Text::lit("ne")) && (acc == &Text::lit("")) {
                f.name.clone()
            } else {
                acc.clone()
            }));
            Text::from(format!("{}\n{}", &fns, &crate::emit::rust::templates::impl_(&gens, &Text::lit("PartialEq"), &head, &Text::lit("fn eq(&self, other: &Self) -> bool"), &Text::from(format!("{}(self, other)", &eq)))))
        },
        _ => Text::from(format!("impl{} {} for {} {{\n{}\n}}\n", &gens, &i.tr, &head, &indent(&crate::syntax::lexer::join(&run_to_end(each_job(i.methods.clone(), Rc::new(move |p0: crate::lower::model::FnDef| entered(once_job(move || {
            let f = p0;
            call_then(start_signature(f.clone(), Text::lit("")), move |signature_17062: Text| call_then(start_body_lines(f.body.clone()), move |body_lines_17081: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::fn_(&Text::lit(""), &signature_17062, &body_lines_17081))))
        }))) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `RustImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustImpl: unbounded fn ImplDef -> Text
/// ```
pub struct RustImpl {
    pub i: crate::lower::model::ImplDef,
}

impl prism_rtl::Job<Text> for RustImpl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let i = &self.i;
        let i = i.clone();
        call_then(start_type_(i.head.clone()), move |type__16309: Text| {
            let head = type__16309;
            let gens = generics(&i.generics);
            match &i.cls {
                m16360_0 if (m16360_0 == &Text::lit("Prelude.Show")) => call_value(each_job(i.methods.clone(), Rc::new(move |p0: crate::lower::model::FnDef| entered(once_job(move || {
                    let f = p0;
                    prism_rtl::Turn::More(Rc::new(RustFn { f: f.clone() }))
                }))) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_16425: Array<Text>| {
                    let fns = crate::syntax::lexer::join(&each_16425, &Text::lit("\n"));
                    let shown = or(&index(&each(&i.methods, &(|f: &crate::lower::model::FnDef| f.name.clone())), &Nat::from(0u32)), &Text::lit("show"));
                    prism_rtl::Turn::Finished(Text::from(format!("{}\n{}", &fns, &crate::emit::rust::templates::impl_(&gens, &Text::lit("Show"), &head, &Text::lit("fn show(&self, p: &mut Printer)"), &Text::from(format!("p.raw(&{}(self).to_string());", &shown))))))
                }),
                m16360_1 if (m16360_1 == &Text::lit("Prelude.Eq")) => call_value(each_job(i.methods.clone(), Rc::new(move |p0: crate::lower::model::FnDef| entered(once_job(move || {
                    let f = p0;
                    prism_rtl::Turn::More(Rc::new(RustFn { f: f.clone() }))
                }))) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_16700: Array<Text>| {
                    let fns = crate::syntax::lexer::join(&each_16700, &Text::lit("\n"));
                    let eq = fold(&i.methods, &Text::lit(""), &(|acc: &Text, f: &crate::lower::model::FnDef| if !crate::syntax::lexer::has_prefix(&f.name, &Text::lit("ne")) && (acc == &Text::lit("")) {
                        f.name.clone()
                    } else {
                        acc.clone()
                    }));
                    prism_rtl::Turn::Finished(Text::from(format!("{}\n{}", &fns, &crate::emit::rust::templates::impl_(&gens, &Text::lit("PartialEq"), &head, &Text::lit("fn eq(&self, other: &Self) -> bool"), &Text::from(format!("{}(self, other)", &eq))))))
                }),
                _ => call_value(each_job(i.methods.clone(), Rc::new(move |p0: crate::lower::model::FnDef| entered(once_job(move || {
                    let f = p0;
                    call_then(start_signature(f.clone(), Text::lit("")), move |signature_17062: Text| call_then(start_body_lines(f.body.clone()), move |body_lines_17081: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::fn_(&Text::lit(""), &signature_17062, &body_lines_17081))))
                }))) as Rc<dyn Fn(crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_17033: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("impl{} {} for {} {{\n{}\n}}\n", &gens, &i.tr, &head, &indent(&crate::syntax::lexer::join(&each_17033, &Text::lit("\n"))))))),
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start RustImpl, x`: what the function value is when passed to `@Run`.
pub fn start_rust_impl(i: crate::lower::model::ImplDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustImpl { i })
}

/// ```prism
/// RustFn: unbounded fn FnDef -> Text
/// ```
pub fn rust_fn(f: &crate::lower::model::FnDef) -> Text {
    let params = crate::syntax::lexer::join(&run_to_end(each_job(f.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (n, t) = p0;
        call_then(start_type_(t.clone()), move |type__17221: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n, &type__17221))))
    }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "));
    let sig = Text::from(format!("pub fn {}{}({}) -> {}", &f.name, &static_generics(&f.generics), &params, &type_(&f.ret)));
    crate::emit::rust::templates::fn_(&crate::emit::rust::templates::source_doc(&Text::lit(""), &f.doc), &sig, &body_lines(&f.body))
}

/// The step machine of `RustFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustFn: unbounded fn FnDef -> Text
/// ```
pub struct RustFn {
    pub f: crate::lower::model::FnDef,
}

impl prism_rtl::Job<Text> for RustFn {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f = &self.f;
        let f = f.clone();
        call_value(each_job(f.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
            let (n, t) = p0;
            call_then(start_type_(t.clone()), move |type__17221: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n, &type__17221))))
        }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_17187: Array<Text>| {
            let params = crate::syntax::lexer::join(&each_17187, &Text::lit(", "));
            call_then(start_type_(f.ret.clone()), move |type__17451: Text| {
                let sig = Text::from(format!("pub fn {}{}({}) -> {}", &f.name, &static_generics(&f.generics), &params, &type__17451));
                call_then(start_body_lines(f.body.clone()), move |body_lines_17500: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::fn_(&crate::emit::rust::templates::source_doc(&Text::lit(""), &f.doc), &sig, &body_lines_17500)))
            })
        })
    }
}

/// `Start RustFn, x`: what the function value is when passed to `@Run`.
pub fn start_rust_fn(f: crate::lower::model::FnDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustFn { f })
}

/// ```prism
/// StaticGenerics: fn [((Text, [Text]))] -> Text
/// ```
pub fn static_generics(gs: &Array<(Text, Array<Text>)>) -> Text {
    generics(&each(gs, &(|(g, bs): &(Text, Array<Text>)| (g.clone(), push(bs, &Text::lit("'static"))))))
}

/// ```prism
/// RustJob: unbounded fn JobDef -> Text
/// ```
pub fn rust_job(j: &crate::lower::model::JobDef) -> Text {
    let gnames = generic_names(&each(&j.generics, &(|(g, _): &(Text, Array<Text>)| g.clone())));
    let fields = crate::syntax::lexer::join(&run_to_end(each_job(j.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (n, t) = p0;
        call_then(start_type_(t.clone()), move |type__17906: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &n, &type__17906))))
    }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let params = crate::syntax::lexer::join(&run_to_end(each_job(j.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (n, t) = p0;
        call_then(start_type_(t.clone()), move |type__17980: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n, &type__17980))))
    }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "));
    let bounded_ = static_generics(&j.generics);
    let start = Text::from(format!("pub fn {}{}({}) -> Rc<dyn prism_rtl::Job<{}>>", &j.start, &bounded_, &params, &type_(&j.ret)));
    let start_body = Text::from(format!("Rc::new({} {{ {} }})", &j.name, &crate::syntax::lexer::join(&each(&j.fields, &(|(n, _): &(Text, crate::lower::model::OutTy)| n.clone())), &Text::lit(", "))));
    crate::emit::rust::templates::job(&crate::emit::rust::templates::source_doc(&Text::lit(""), &j.doc), &j.name, &gnames, &bounded_, &fields, &type_(&j.ret), &body_lines(&j.body), &start, &start_body)
}

/// The step machine of `RustJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustJob: unbounded fn JobDef -> Text
/// ```
pub struct RustJob {
    pub j: crate::lower::model::JobDef,
}

impl prism_rtl::Job<Text> for RustJob {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let j = &self.j;
        let gnames = generic_names(&each(&j.generics, &(|(g, _): &(Text, Array<Text>)| g.clone())));
        let j = j.clone();
        call_value(each_job(j.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
            let (n, t) = p0;
            call_then(start_type_(t.clone()), move |type__17906: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &n, &type__17906))))
        }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_17868: Array<Text>| {
            let fields = crate::syntax::lexer::join(&each_17868, &Text::lit("\n"));
            call_value(each_job(j.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
                let (n, t) = p0;
                call_then(start_type_(t.clone()), move |type__17980: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n, &type__17980))))
            }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_17946: Array<Text>| {
                let params = crate::syntax::lexer::join(&each_17946, &Text::lit(", "));
                let bounded_ = static_generics(&j.generics);
                call_then(start_type_(j.ret.clone()), move |type__18204: Text| {
                    let start = Text::from(format!("pub fn {}{}({}) -> Rc<dyn prism_rtl::Job<{}>>", &j.start, &bounded_, &params, &type__18204));
                    let start_body = Text::from(format!("Rc::new({} {{ {} }})", &j.name, &crate::syntax::lexer::join(&each(&j.fields, &(|(n, _): &(Text, crate::lower::model::OutTy)| n.clone())), &Text::lit(", "))));
                    call_then(start_type_(j.ret.clone()), move |type__18379: Text| call_then(start_body_lines(j.body.clone()), move |body_lines_18393: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::job(&crate::emit::rust::templates::source_doc(&Text::lit(""), &j.doc), &j.name, &gnames, &bounded_, &fields, &type__18379, &body_lines_18393, &start, &start_body))))
                })
            })
        })
    }
}

/// `Start RustJob, x`: what the function value is when passed to `@Run`.
pub fn start_rust_job(j: crate::lower::model::JobDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustJob { j })
}

/// ```prism
/// TypeDecl: unbounded fn TyDef -> Text
/// ```
pub fn type_decl(t: &crate::lower::model::TyDef) -> Text {
    let eq = t.eq && !t.floaty;
    let ord = t.ord && !t.floaty;
    let derives = crate::syntax::lexer::join(&filter(&Array::from(vec![Text::lit("Clone"), if t.eq || t.ord { Text::lit("PartialEq") } else { Text::lit("") }, if eq || ord { Text::lit("Eq") } else { Text::lit("") }, if t.ord { Text::lit("PartialOrd") } else { Text::lit("") }, if ord { Text::lit("Ord") } else { Text::lit("") }]), &(|d: &Text| d != &Text::lit(""))), &Text::lit(", "));
    let head = Text::from(format!("{}{}", &t.name, &generic_names(&t.params)));
    let doc = crate::emit::rust::templates::source_doc(&Text::from(format!("`{}`:", &t.prism)), &t.doc);
    let decl = match &t.shape {
        crate::lower::model::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            crate::emit::rust::templates::struct_(&doc, &derives, &head, &crate::syntax::lexer::join(&run_to_end(each_job(c.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
                let (f, ft) = p0;
                call_then(start_type_(ft.clone()), move |type__19153: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &f, &type__19153))))
            }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n")))
        },
        crate::lower::model::TyShape::ShapeUnit => crate::emit::rust::templates::tuple_struct(&doc, &derives, &head, &Text::lit("")),
        crate::lower::model::TyShape::ShapeNewtype => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            crate::emit::rust::templates::tuple_struct(&doc, &derives, &head, &Text::from(format!("({})", &crate::syntax::lexer::join(&run_to_end(each_job(c.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
                let (_, ft) = p0;
                call_then(start_type_(ft.clone()), move |type__19417: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}", &type__19417))))
            }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", ")))))
        },
        _ => crate::emit::rust::templates::enum_(&doc, &derives, &head, &crate::syntax::lexer::join(&run_to_end(each_job(t.cases.clone(), Rc::new(move |p0: crate::lower::model::CaseDef| entered(once_job(move || {
            let c = p0;
            prism_rtl::Turn::More(Rc::new(EnumCase { c: c.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))),
    };
    let show_ = if &t.show == &crate::lower::model::Shown::ShownDerived {
        Text::from(format!("\n{}", &show_impl(t, &head)))
    } else {
        Text::lit("")
    };
    let pod = if t.pod {
        Text::from(format!("\n{}\n{}", &to_pod_impl(t, &head), &from_pod_impl(t, &head)))
    } else {
        Text::lit("")
    };
    Text::from(format!("{}{}{}", &decl, &show_, &pod))
}

/// The step machine of `TypeDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeDecl: unbounded fn TyDef -> Text
/// ```
pub struct TypeDecl {
    pub t: crate::lower::model::TyDef,
}

impl prism_rtl::Job<Text> for TypeDecl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        let eq = t.eq && !t.floaty;
        let ord = t.ord && !t.floaty;
        let derives = crate::syntax::lexer::join(&filter(&Array::from(vec![Text::lit("Clone"), if t.eq || t.ord { Text::lit("PartialEq") } else { Text::lit("") }, if eq || ord { Text::lit("Eq") } else { Text::lit("") }, if t.ord { Text::lit("PartialOrd") } else { Text::lit("") }, if ord { Text::lit("Ord") } else { Text::lit("") }]), &(|d: &Text| d != &Text::lit(""))), &Text::lit(", "));
        let head = Text::from(format!("{}{}", &t.name, &generic_names(&t.params)));
        let doc = crate::emit::rust::templates::source_doc(&Text::from(format!("`{}`:", &t.prism)), &t.doc);
        let decl = match &t.shape {
            crate::lower::model::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                crate::emit::rust::templates::struct_(&doc, &derives, &head, &crate::syntax::lexer::join(&run_to_end(each_job(c.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
                    let (f, ft) = p0;
                    call_then(start_type_(ft.clone()), move |type__19153: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &f, &type__19153))))
                }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n")))
            },
            crate::lower::model::TyShape::ShapeUnit => crate::emit::rust::templates::tuple_struct(&doc, &derives, &head, &Text::lit("")),
            crate::lower::model::TyShape::ShapeNewtype => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                crate::emit::rust::templates::tuple_struct(&doc, &derives, &head, &Text::from(format!("({})", &crate::syntax::lexer::join(&run_to_end(each_job(c.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
                    let (_, ft) = p0;
                    call_then(start_type_(ft.clone()), move |type__19417: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}", &type__19417))))
                }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", ")))))
            },
            _ => crate::emit::rust::templates::enum_(&doc, &derives, &head, &crate::syntax::lexer::join(&run_to_end(each_job(t.cases.clone(), Rc::new(move |p0: crate::lower::model::CaseDef| entered(once_job(move || {
                let c = p0;
                prism_rtl::Turn::More(Rc::new(EnumCase { c: c.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))),
        };
        let show_ = if &t.show == &crate::lower::model::Shown::ShownDerived {
            Text::from(format!("\n{}", &show_impl(t, &head)))
        } else {
            Text::lit("")
        };
        let pod = if t.pod {
            Text::from(format!("\n{}\n{}", &to_pod_impl(t, &head), &from_pod_impl(t, &head)))
        } else {
            Text::lit("")
        };
        prism_rtl::Turn::Finished(Text::from(format!("{}{}{}", &decl, &show_, &pod)))
    }
}

/// `Start TypeDecl, x`: what the function value is when passed to `@Run`.
pub fn start_type_decl(t: crate::lower::model::TyDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TypeDecl { t })
}

/// ```prism
/// EnumCase: unbounded fn CaseDef -> Text
/// ```
pub fn enum_case(c: &crate::lower::model::CaseDef) -> Text {
    if &len(&c.fields) == &Nat::from(0u32) {
        Text::from(format!("{},", &c.name))
    } else {
        Text::from(format!("{}({}),", &c.name, &crate::syntax::lexer::join(&run_to_end(each_job(c.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
            let (_, ft) = p0;
            prism_rtl::Turn::More(Rc::new(Type { t: ft.clone() }))
        }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))))
    }
}

/// The step machine of `EnumCase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EnumCase: unbounded fn CaseDef -> Text
/// ```
pub struct EnumCase {
    pub c: crate::lower::model::CaseDef,
}

impl prism_rtl::Job<Text> for EnumCase {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let c = &self.c;
        if &len(&c.fields) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished(Text::from(format!("{},", &c.name)))
        } else {
            {
                let c = c.clone();
                call_value(each_job(c.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
                    let (_, ft) = p0;
                    prism_rtl::Turn::More(Rc::new(Type { t: ft.clone() }))
                }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_19819: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{}({}),", &c.name, &crate::syntax::lexer::join(&each_19819, &Text::lit(", "))))))
            }
        }
    }
}

/// `Start EnumCase, x`: what the function value is when passed to `@Run`.
pub fn start_enum_case(c: crate::lower::model::CaseDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(EnumCase { c })
}

/// ```prism
/// Binders: fn Nat -> [Text]
/// ```
pub fn binders(n: &Nat) -> Array<Text> {
    each(&crate::check::errors::range0(n), &(|i: &Nat| Text::from(format!("a{}", i))))
}

/// ```prism
/// CasePattern: fn TyDef, CaseDef -> Text
/// ```
pub fn case_pattern(t: &crate::lower::model::TyDef, c: &crate::lower::model::CaseDef) -> Text {
    match &t.shape {
        crate::lower::model::TyShape::ShapeNewtype => Text::from(format!("{}({})", &t.name, &crate::syntax::lexer::join(&binders(&len(&c.fields)), &Text::lit(", ")))),
        crate::lower::model::TyShape::ShapeUnit => t.name.clone(),
        _ => if &len(&c.fields) == &Nat::from(0u32) {
            Text::from(format!("{}::{}", &t.name, &c.name))
        } else {
            Text::from(format!("{}::{}({})", &t.name, &c.name, &crate::syntax::lexer::join(&binders(&len(&c.fields)), &Text::lit(", "))))
        },
    }
}

/// ```prism
/// ShowImpl: unbounded fn TyDef, Text -> Text
/// ```
pub fn show_impl(t: &crate::lower::model::TyDef, head: &Text) -> Text {
    let body = match &t.shape {
        crate::lower::model::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            Text::from(format!("p.record(\"{}\", &[{}]);", &t.prism, &crate::syntax::lexer::join(&each(&c.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("(\"{}\", &self.{})", &prism_field(f), f)))), &Text::lit(", "))))
        },
        _ => crate::emit::rust::templates::match_self(&crate::syntax::lexer::join(&each(&t.cases, &(|c: &crate::lower::model::CaseDef| Text::from(format!("{} => p.choice(\"{}\", &[{}]),", &case_pattern(t, c), &c.prism, &crate::syntax::lexer::join(&binders(&len(&c.fields)), &Text::lit(", ")))))), &Text::lit("\n"))),
    };
    crate::emit::rust::templates::impl_(&bounded(&t.params, &Text::lit("Show")), &Text::lit("Show"), head, &Text::lit("fn show(&self, p: &mut Printer)"), &body)
}

/// The step machine of `ShowImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowImpl: unbounded fn TyDef, Text -> Text
/// ```
pub struct ShowImpl {
    pub t: crate::lower::model::TyDef,
    pub head: Text,
}

impl prism_rtl::Job<Text> for ShowImpl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        let head = &self.head;
        let body = match &t.shape {
            crate::lower::model::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                Text::from(format!("p.record(\"{}\", &[{}]);", &t.prism, &crate::syntax::lexer::join(&each(&c.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("(\"{}\", &self.{})", &prism_field(f), f)))), &Text::lit(", "))))
            },
            _ => crate::emit::rust::templates::match_self(&crate::syntax::lexer::join(&each(&t.cases, &(|c: &crate::lower::model::CaseDef| Text::from(format!("{} => p.choice(\"{}\", &[{}]),", &case_pattern(t, c), &c.prism, &crate::syntax::lexer::join(&binders(&len(&c.fields)), &Text::lit(", ")))))), &Text::lit("\n"))),
        };
        prism_rtl::Turn::Finished(crate::emit::rust::templates::impl_(&bounded(&t.params, &Text::lit("Show")), &Text::lit("Show"), head, &Text::lit("fn show(&self, p: &mut Printer)"), &body))
    }
}

/// `Start ShowImpl, x`: what the function value is when passed to `@Run`.
pub fn start_show_impl(t: crate::lower::model::TyDef, head: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ShowImpl { t, head })
}

/// ```prism
/// PrismField: fn Text -> Text
/// ```
pub fn prism_field(f: &Text) -> Text {
    if &crate::syntax::lexer::last_char(f) == &Text::lit("_") {
        crate::syntax::lexer::before_last(f)
    } else {
        f.clone()
    }
}

/// ```prism
/// ToPodImpl: unbounded fn TyDef, Text -> Text
/// ```
pub fn to_pod_impl(t: &crate::lower::model::TyDef, head: &Text) -> Text {
    let body = match &t.shape {
        crate::lower::model::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            Text::from(format!("Pod::record(\"{}\", vec![{}])", &t.prism, &crate::syntax::lexer::join(&each(&c.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("(\"{}\", self.{}.to_pod())", &prism_field(f), f)))), &Text::lit(", "))))
        },
        _ => crate::emit::rust::templates::match_self(&crate::syntax::lexer::join(&each(&t.cases, &(|c: &crate::lower::model::CaseDef| Text::from(format!("{} => Pod::Choice(\"{}\".into(), vec![{}]),", &case_pattern(t, c), &c.prism, &crate::syntax::lexer::join(&each(&binders(&len(&c.fields)), &(|b: &Text| Text::from(format!("{}.to_pod()", b)))), &Text::lit(", ")))))), &Text::lit("\n"))),
    };
    let shown = if &t.show == &crate::lower::model::Shown::ShownOwn {
        crate::emit::rust::templates::shown_pod(&body)
    } else {
        body.clone()
    };
    crate::emit::rust::templates::impl_(&bounded(&t.params, &Text::lit("ToPod")), &Text::lit("ToPod"), head, &Text::lit("fn to_pod(&self) -> Pod"), &shown)
}

/// The step machine of `ToPodImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ToPodImpl: unbounded fn TyDef, Text -> Text
/// ```
pub struct ToPodImpl {
    pub t: crate::lower::model::TyDef,
    pub head: Text,
}

impl prism_rtl::Job<Text> for ToPodImpl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        let head = &self.head;
        let body = match &t.shape {
            crate::lower::model::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                Text::from(format!("Pod::record(\"{}\", vec![{}])", &t.prism, &crate::syntax::lexer::join(&each(&c.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("(\"{}\", self.{}.to_pod())", &prism_field(f), f)))), &Text::lit(", "))))
            },
            _ => crate::emit::rust::templates::match_self(&crate::syntax::lexer::join(&each(&t.cases, &(|c: &crate::lower::model::CaseDef| Text::from(format!("{} => Pod::Choice(\"{}\".into(), vec![{}]),", &case_pattern(t, c), &c.prism, &crate::syntax::lexer::join(&each(&binders(&len(&c.fields)), &(|b: &Text| Text::from(format!("{}.to_pod()", b)))), &Text::lit(", ")))))), &Text::lit("\n"))),
        };
        let shown = if &t.show == &crate::lower::model::Shown::ShownOwn {
            crate::emit::rust::templates::shown_pod(&body)
        } else {
            body.clone()
        };
        prism_rtl::Turn::Finished(crate::emit::rust::templates::impl_(&bounded(&t.params, &Text::lit("ToPod")), &Text::lit("ToPod"), head, &Text::lit("fn to_pod(&self) -> Pod"), &shown))
    }
}

/// `Start ToPodImpl, x`: what the function value is when passed to `@Run`.
pub fn start_to_pod_impl(t: crate::lower::model::TyDef, head: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ToPodImpl { t, head })
}

/// ```prism
/// FromPodImpl: unbounded fn TyDef, Text -> Text
/// ```
pub fn from_pod_impl(t: &crate::lower::model::TyDef, head: &Text) -> Text {
    let body = match &t.shape {
        crate::lower::model::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            Text::from(format!("Ok({} {{ {} }})", &t.name, &crate::syntax::lexer::join(&each(&c.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{}: FromPod::from_pod(field(p, \"{}\")?)?", f, &prism_field(f))))), &Text::lit(", "))))
        },
        _ => {
            let arms_ = each(&t.cases, &(|c: &crate::lower::model::CaseDef| {
                let n = len(&c.fields);
                let made = if &n == &Nat::from(0u32) {
                    if &t.shape == &crate::lower::model::TyShape::ShapeUnit {
                        t.name.clone()
                    } else {
                        Text::from(format!("{}::{}", &t.name, &c.name))
                    }
                } else {
                    Text::from(format!("{}({})", &(if &t.shape == &crate::lower::model::TyShape::ShapeNewtype {
                        t.name.clone()
                    } else {
                        Text::from(format!("{}::{}", &t.name, &c.name))
                    }), &crate::syntax::lexer::join(&each(&crate::check::errors::range0(&n), &(|i: &Nat| Text::from(format!("FromPod::from_pod(&a[{}])?", i)))), &Text::lit(", "))))
                };
                Text::from(format!("Pod::Choice(c, a) if &**c == \"{}\" && a.len() == {} => Ok({}),", &c.prism, &n, &made))
            }));
            crate::emit::rust::templates::from_pod_body(&crate::syntax::lexer::join(&arms_, &Text::lit("\n")), &Text::from(format!("a {}", &t.prism)))
        },
    };
    crate::emit::rust::templates::impl_(&bounded(&t.params, &Text::lit("FromPod")), &Text::lit("FromPod"), head, &Text::lit("fn from_pod(p: &Pod) -> Result<Self, Fault>"), &body)
}

/// The step machine of `FromPodImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FromPodImpl: unbounded fn TyDef, Text -> Text
/// ```
pub struct FromPodImpl {
    pub t: crate::lower::model::TyDef,
    pub head: Text,
}

impl prism_rtl::Job<Text> for FromPodImpl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        let head = &self.head;
        let body = match &t.shape {
            crate::lower::model::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &crate::lower::model::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                Text::from(format!("Ok({} {{ {} }})", &t.name, &crate::syntax::lexer::join(&each(&c.fields, &(|(f, _): &(Text, crate::lower::model::OutTy)| Text::from(format!("{}: FromPod::from_pod(field(p, \"{}\")?)?", f, &prism_field(f))))), &Text::lit(", "))))
            },
            _ => {
                let arms_ = each(&t.cases, &(|c: &crate::lower::model::CaseDef| {
                    let n = len(&c.fields);
                    let made = if &n == &Nat::from(0u32) {
                        if &t.shape == &crate::lower::model::TyShape::ShapeUnit {
                            t.name.clone()
                        } else {
                            Text::from(format!("{}::{}", &t.name, &c.name))
                        }
                    } else {
                        Text::from(format!("{}({})", &(if &t.shape == &crate::lower::model::TyShape::ShapeNewtype {
                            t.name.clone()
                        } else {
                            Text::from(format!("{}::{}", &t.name, &c.name))
                        }), &crate::syntax::lexer::join(&each(&crate::check::errors::range0(&n), &(|i: &Nat| Text::from(format!("FromPod::from_pod(&a[{}])?", i)))), &Text::lit(", "))))
                    };
                    Text::from(format!("Pod::Choice(c, a) if &**c == \"{}\" && a.len() == {} => Ok({}),", &c.prism, &n, &made))
                }));
                crate::emit::rust::templates::from_pod_body(&crate::syntax::lexer::join(&arms_, &Text::lit("\n")), &Text::from(format!("a {}", &t.prism)))
            },
        };
        prism_rtl::Turn::Finished(crate::emit::rust::templates::impl_(&bounded(&t.params, &Text::lit("FromPod")), &Text::lit("FromPod"), head, &Text::lit("fn from_pod(p: &Pod) -> Result<Self, Fault>"), &body))
    }
}

/// `Start FromPodImpl, x`: what the function value is when passed to `@Run`.
pub fn start_from_pod_impl(t: crate::lower::model::TyDef, head: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FromPodImpl { t, head })
}

/// ```prism
/// RustTag: unbounded fn TagDef -> Text
/// ```
pub fn rust_tag(t: &crate::lower::model::TagDef) -> Text {
    let fields = crate::syntax::lexer::join(&run_to_end(each_job(t.fields.clone(), Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (_, f, ft) = p0;
        call_then(start_type_(ft.clone()), move |type__22826: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &f, &type__22826))))
    }))) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let pods = crate::syntax::lexer::join(&each(&t.fields, &(|(p_, f, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("(\"{}\", self.{}.to_pod())", p_, f)))), &Text::lit(", "));
    let derives = if t.pod { Text::lit("Clone, PartialEq") } else { Text::lit("Clone") };
    let reads = crate::syntax::lexer::join(&each(&t.fields, &(|(p_, f, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("{}: FromPod::from_pod(field(p, \"{}\")?)?", f, p_)))), &Text::lit(", "));
    let back_ = if t.pod {
        Text::from(format!("\n{}", &crate::emit::rust::templates::tag_from_pod(&t.name, &t.tag_name, &reads)))
    } else {
        Text::lit("")
    };
    Text::from(format!("{}{}", &crate::emit::rust::templates::tag(&crate::emit::rust::templates::source_doc(&Text::from(format!("The `Level` of `{}`:", &t.tag_name)), &t.doc), &derives, &t.name, &fields, &t.tag_name, &pods), &back_))
}

/// The step machine of `RustTag`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustTag: unbounded fn TagDef -> Text
/// ```
pub struct RustTag {
    pub t: crate::lower::model::TagDef,
}

impl prism_rtl::Job<Text> for RustTag {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        let t = t.clone();
        call_value(each_job(t.fields.clone(), Rc::new(move |p0: (Text, Text, crate::lower::model::OutTy)| entered(once_job(move || {
            let (_, f, ft) = p0;
            call_then(start_type_(ft.clone()), move |type__22826: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &f, &type__22826))))
        }))) as Rc<dyn Fn((Text, Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_22779: Array<Text>| {
            let fields = crate::syntax::lexer::join(&each_22779, &Text::lit("\n"));
            let pods = crate::syntax::lexer::join(&each(&t.fields, &(|(p_, f, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("(\"{}\", self.{}.to_pod())", p_, f)))), &Text::lit(", "));
            let derives = if t.pod { Text::lit("Clone, PartialEq") } else { Text::lit("Clone") };
            let reads = crate::syntax::lexer::join(&each(&t.fields, &(|(p_, f, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("{}: FromPod::from_pod(field(p, \"{}\")?)?", f, p_)))), &Text::lit(", "));
            let back_ = if t.pod {
                Text::from(format!("\n{}", &crate::emit::rust::templates::tag_from_pod(&t.name, &t.tag_name, &reads)))
            } else {
                Text::lit("")
            };
            prism_rtl::Turn::Finished(Text::from(format!("{}{}", &crate::emit::rust::templates::tag(&crate::emit::rust::templates::source_doc(&Text::from(format!("The `Level` of `{}`:", &t.tag_name)), &t.doc), &derives, &t.name, &fields, &t.tag_name, &pods), &back_)))
        })
    }
}

/// `Start RustTag, x`: what the function value is when passed to `@Run`.
pub fn start_rust_tag(t: crate::lower::model::TagDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustTag { t })
}

/// ```prism
/// RustRow: unbounded fn RowDef -> Text
/// ```
pub fn rust_row(r: &crate::lower::model::RowDef) -> Text {
    let derives = if r.pod { Text::lit("Clone, PartialEq") } else { Text::lit("Clone") };
    let cases = crate::syntax::lexer::join(&each(&r.cases, &(|(v_, st): &(Text, Text)| Text::from(format!("{}({}),", v_, st)))), &Text::lit("\n"));
    let pods = crate::syntax::lexer::join(&each(&r.cases, &(|(v_, _): &(Text, Text)| Text::from(format!("{}::{}(x) => x.to_pod(),", &r.name, v_)))), &Text::lit("\n"));
    let reads = crate::syntax::lexer::join(&each(&r.cases, &(|(v_, st): &(Text, Text)| Text::from(format!("Some(t) if t == {}::TAG => Ok({}::{}(FromPod::from_pod(p)?)),", st, &r.name, v_)))), &Text::lit("\n"));
    let back_ = if r.pod {
        Text::from(format!("\n{}", &crate::emit::rust::templates::row_from_pod(&r.name, &reads)))
    } else {
        Text::lit("")
    };
    let pods2 = if &len(&r.cases) == &Nat::from(0u32) {
        Text::lit("_ => unreachable!(),")
    } else {
        pods.clone()
    };
    Text::from(format!("{}{}", &crate::emit::rust::templates::row(&crate::emit::rust::templates::source_doc(&Text::from(format!("`{}`, a row kind's values:", &r.prism)), &r.doc), &derives, &r.name, &cases, &pods2), &back_))
}

/// The step machine of `RustRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustRow: unbounded fn RowDef -> Text
/// ```
pub struct RustRow {
    pub r: crate::lower::model::RowDef,
}

impl prism_rtl::Job<Text> for RustRow {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let r = &self.r;
        let derives = if r.pod { Text::lit("Clone, PartialEq") } else { Text::lit("Clone") };
        let cases = crate::syntax::lexer::join(&each(&r.cases, &(|(v_, st): &(Text, Text)| Text::from(format!("{}({}),", v_, st)))), &Text::lit("\n"));
        let pods = crate::syntax::lexer::join(&each(&r.cases, &(|(v_, _): &(Text, Text)| Text::from(format!("{}::{}(x) => x.to_pod(),", &r.name, v_)))), &Text::lit("\n"));
        let reads = crate::syntax::lexer::join(&each(&r.cases, &(|(v_, st): &(Text, Text)| Text::from(format!("Some(t) if t == {}::TAG => Ok({}::{}(FromPod::from_pod(p)?)),", st, &r.name, v_)))), &Text::lit("\n"));
        let back_ = if r.pod {
            Text::from(format!("\n{}", &crate::emit::rust::templates::row_from_pod(&r.name, &reads)))
        } else {
            Text::lit("")
        };
        let pods2 = if &len(&r.cases) == &Nat::from(0u32) {
            Text::lit("_ => unreachable!(),")
        } else {
            pods.clone()
        };
        prism_rtl::Turn::Finished(Text::from(format!("{}{}", &crate::emit::rust::templates::row(&crate::emit::rust::templates::source_doc(&Text::from(format!("`{}`, a row kind's values:", &r.prism)), &r.doc), &derives, &r.name, &cases, &pods2), &back_)))
    }
}

/// `Start RustRow, x`: what the function value is when passed to `@Run`.
pub fn start_rust_row(r: crate::lower::model::RowDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustRow { r })
}

/// ```prism
/// RustAnswer: unbounded fn AnswerDef -> Text
/// ```
pub fn rust_answer(a: &crate::lower::model::AnswerDef) -> Text {
    let cases = crate::syntax::lexer::join(&run_to_end(each_job(a.cases.clone(), Rc::new(move |p0: crate::lower::model::AnswerCase| entered(once_job(move || {
        let c = p0;
        call_then(start_type_(c.ty.clone()), move |type__24483: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({}),", &c.variant, &type__24483))))
    }))) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let tags = if &len(&a.cases) == &Nat::from(0u32) {
        Text::lit("_ => unreachable!(),")
    } else {
        crate::syntax::lexer::join(&each(&a.cases, &(|c: &crate::lower::model::AnswerCase| Text::from(format!("Answer::{}(_) => {}::TAG,", &c.variant, &c.struct_path)))), &Text::lit("\n"))
    };
    let accessors = crate::syntax::lexer::join(&run_to_end(each_job(a.cases.clone(), Rc::new(move |p0: crate::lower::model::AnswerCase| entered(once_job(move || {
        let c = p0;
        call_then(start_type_(c.ty.clone()), move |type__24745: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::answer_getter(&c.accessor, &c.variant, &c.tag_name, &type__24745)))
    }))) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let decodes = if &len(&a.cases) == &Nat::from(0u32) {
        Text::lit("_ => unreachable!(),")
    } else {
        crate::syntax::lexer::join(&run_to_end(each_job(a.cases.clone(), Rc::new(move |p0: crate::lower::model::AnswerCase| entered(once_job(move || {
            let c = p0;
            call_then(start_decode_head(c.ty.clone()), move |decode_head_24908: Text| prism_rtl::Turn::Finished(Text::from(format!("Elem::{}(..) => Ok(Answer::{}({}::from_pod(v)?)),", &c.variant, &c.variant, &decode_head_24908))))
        }))) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))
    };
    crate::emit::rust::templates::answer_type(&cases, &tags, &accessors, &decodes)
}

/// The step machine of `RustAnswer`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustAnswer: unbounded fn AnswerDef -> Text
/// ```
pub struct RustAnswer {
    pub a: crate::lower::model::AnswerDef,
}

impl prism_rtl::Job<Text> for RustAnswer {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let a = &self.a;
        let a = a.clone();
        call_value(each_job(a.cases.clone(), Rc::new(move |p0: crate::lower::model::AnswerCase| entered(once_job(move || {
            let c = p0;
            call_then(start_type_(c.ty.clone()), move |type__24483: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({}),", &c.variant, &type__24483))))
        }))) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_24450: Array<Text>| {
            let cases = crate::syntax::lexer::join(&each_24450, &Text::lit("\n"));
            let tags = if &len(&a.cases) == &Nat::from(0u32) {
                Text::lit("_ => unreachable!(),")
            } else {
                crate::syntax::lexer::join(&each(&a.cases, &(|c: &crate::lower::model::AnswerCase| Text::from(format!("Answer::{}(_) => {}::TAG,", &c.variant, &c.struct_path)))), &Text::lit("\n"))
            };
            call_value(each_job(a.cases.clone(), Rc::new(move |p0: crate::lower::model::AnswerCase| entered(once_job(move || {
                let c = p0;
                call_then(start_type_(c.ty.clone()), move |type__24745: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::answer_getter(&c.accessor, &c.variant, &c.tag_name, &type__24745)))
            }))) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_24678: Array<Text>| {
                let accessors = crate::syntax::lexer::join(&each_24678, &Text::lit("\n"));
                let decodes = if &len(&a.cases) == &Nat::from(0u32) {
                    Text::lit("_ => unreachable!(),")
                } else {
                    crate::syntax::lexer::join(&run_to_end(each_job(a.cases.clone(), Rc::new(move |p0: crate::lower::model::AnswerCase| entered(once_job(move || {
                        let c = p0;
                        call_then(start_decode_head(c.ty.clone()), move |decode_head_24908: Text| prism_rtl::Turn::Finished(Text::from(format!("Elem::{}(..) => Ok(Answer::{}({}::from_pod(v)?)),", &c.variant, &c.variant, &decode_head_24908))))
                    }))) as Rc<dyn Fn(crate::lower::model::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))
                };
                prism_rtl::Turn::Finished(crate::emit::rust::templates::answer_type(&cases, &tags, &accessors, &decodes))
            })
        })
    }
}

/// `Start RustAnswer, x`: what the function value is when passed to `@Run`.
pub fn start_rust_answer(a: crate::lower::model::AnswerDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustAnswer { a })
}

/// ```prism
/// RustNode: unbounded fn NodeDef -> Text
/// ```
pub fn rust_node(n: &crate::lower::model::NodeDef) -> Text {
    let fields = crate::syntax::lexer::join(&run_to_end(each_job(n.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy, Text)| entered(once_job(move || {
        let (f, t, doc) = p0;
        call_then(start_type_(t.clone()), move |type__25325: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}: {},", &crate::emit::rust::templates::doc(&doc), &f, &type__25325))))
    }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let consts = concat(&each(&n.consts, &(|(c, h, doc): &(Text, Nat, Text)| Text::from(format!("{}const {}: u32 = {};\n", &crate::emit::rust::templates::doc(&Text::from(format!("The {}.", doc))), c, h)))));
    let params = concat(&run_to_end(each_job(n.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (p_, t) = p0;
        call_then(start_type_(t.clone()), move |type__25503: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}, ", &p_, &type__25503))))
    }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)));
    let ret = if n.fallible {
        Text::from(format!("Result<Rc<{}>, Fault>", &n.name))
    } else {
        Text::from(format!("Rc<{}>", &n.name))
    };
    let inits = crate::syntax::lexer::join(&append(&Array::from(vec![Text::lit("path")]), &run_to_end(each_job(n.inits.clone(), Rc::new(move |p0: (Text, crate::lower::model::Ex)| entered(once_job(move || {
        let (f, v_) = p0;
        prism_rtl::Turn::More(Rc::new(FieldInit { f: f.clone(), ex1: v_.clone() }))
    }))) as Rc<dyn Fn((Text, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>))), &Text::lit(", "));
    let tail = if n.fallible { Text::lit("Ok(node)") } else { Text::lit("node") };
    let rest_text = if &len(&n.build) == &Nat::from(0u32) {
        tail.clone()
    } else {
        Text::from(format!("{}\n{}", &statements(&n.build), &tail))
    };
    let build = crate::emit::rust::templates::build(&n.name, &params, &ret, &statements(&n.lets), &inits, &rest_text);
    let methods = crate::syntax::lexer::join(&run_to_end(each_job(n.methods.clone(), Rc::new(move |p0: crate::lower::model::MethDef| entered(once_job(move || {
        let m = p0;
        prism_rtl::Turn::More(Rc::new(RustMethod { m: m.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let answer = if &len(&n.answers) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        crate::emit::rust::templates::answer(&crate::syntax::lexer::join(&run_to_end(each_job(n.answers.clone(), Rc::new(move |p0: (crate::lower::model::Pa, crate::lower::model::Ex)| entered(once_job(move || {
            let (pat, call) = p0;
            call_then(start_pattern(pat.clone()), move |pattern_26069: Text| call_then(start_expression(call.clone()), move |expression_26086: Text| prism_rtl::Turn::Finished(Text::from(format!("{} => {},", &pattern_26069, &expression_26086)))))
        }))) as Rc<dyn Fn((crate::lower::model::Pa, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n")))
    };
    let builders = concat(&append(&run_to_end(each_job(n.builders.clone(), Rc::new(move |p0: crate::lower::model::ForDef| entered(once_job(move || {
        let b = p0;
        call_then(start_for_builder(b.clone()), move |for_builder_26174: Text| prism_rtl::Turn::Finished(Text::from(format!("\n{}", &for_builder_26174))))
    }))) as Rc<dyn Fn(crate::lower::model::ForDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &run_to_end(each_job(n.gens.clone(), Rc::new(move |p0: crate::lower::model::GenDef| entered(once_job(move || {
        let gd = p0;
        call_then(start_gen_builder(gd.clone()), move |gen_builder_26215: Text| prism_rtl::Turn::Finished(Text::from(format!("\n{}", &gen_builder_26215))))
    }))) as Rc<dyn Fn(crate::lower::model::GenDef) -> Rc<dyn prism_rtl::Job<Text>>>))));
    let row_impl = if &n.row_kind == &crate::lower::model::RowKind::NotARow {
        Text::lit("")
    } else {
        Text::from(format!("\n{}", &rust_row_impl(n)))
    };
    let hooks = crate::syntax::lexer::join(&run_to_end(each_job(n.hooks.clone(), Rc::new(move |p0: (Text, Array<crate::lower::model::Do>)| entered(once_job(move || {
        let (h, body) = p0;
        if &h == &Text::lit("push") {
            call_then(start_statements(body.clone()), move |statements_26382: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::push_hook(&statements_26382)))
        } else {
            call_then(start_statements(body.clone()), move |statements_26414: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::hook(&h, &statements_26414)))
        }
    }))) as Rc<dyn Fn((Text, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let doc = crate::emit::rust::templates::source_doc(&Text::from(format!("`{}`: a node of its own (claude/backend.md, \"A widget block\").", &n.prism)), &n.doc);
    Text::from(format!("{}{}", &crate::emit::rust::templates::node_(&doc, &n.name, &fields, &consts, &build, &Text::from(format!("{}{}", &methods, &builders)), &hooks, &answer), &row_impl))
}

/// The step machine of `RustNode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustNode: unbounded fn NodeDef -> Text
/// ```
pub struct RustNode {
    pub n: crate::lower::model::NodeDef,
}

impl prism_rtl::Job<Text> for RustNode {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let n = &self.n;
        let n = n.clone();
        call_value(each_job(n.fields.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy, Text)| entered(once_job(move || {
            let (f, t, doc) = p0;
            call_then(start_type_(t.clone()), move |type__25325: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}: {},", &crate::emit::rust::templates::doc(&doc), &f, &type__25325))))
        }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_25277: Array<Text>| {
            let fields = crate::syntax::lexer::join(&each_25277, &Text::lit("\n"));
            let consts = concat(&each(&n.consts, &(|(c, h, doc): &(Text, Nat, Text)| Text::from(format!("{}const {}: u32 = {};\n", &crate::emit::rust::templates::doc(&Text::from(format!("The {}.", doc))), c, h)))));
            call_value(each_job(n.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
                let (p_, t) = p0;
                call_then(start_type_(t.clone()), move |type__25503: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}, ", &p_, &type__25503))))
            }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_25469: Array<Text>| {
                let params = concat(&each_25469);
                let ret = if n.fallible {
                    Text::from(format!("Result<Rc<{}>, Fault>", &n.name))
                } else {
                    Text::from(format!("Rc<{}>", &n.name))
                };
                call_value(each_job(n.inits.clone(), Rc::new(move |p0: (Text, crate::lower::model::Ex)| entered(once_job(move || {
                    let (f, v_) = p0;
                    prism_rtl::Turn::More(Rc::new(FieldInit { f: f.clone(), ex1: v_.clone() }))
                }))) as Rc<dyn Fn((Text, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_25637: Array<Text>| {
                    let inits = crate::syntax::lexer::join(&append(&Array::from(vec![Text::lit("path")]), &each_25637), &Text::lit(", "));
                    let tail = if n.fallible { Text::lit("Ok(node)") } else { Text::lit("node") };
                    let rest_text = if &len(&n.build) == &Nat::from(0u32) {
                        tail.clone()
                    } else {
                        Text::from(format!("{}\n{}", &statements(&n.build), &tail))
                    };
                    call_then(start_statements(n.lets.clone()), move |statements_25868: Text| {
                        let build = crate::emit::rust::templates::build(&n.name, &params, &ret, &statements_25868, &inits, &rest_text);
                        call_value(each_job(n.methods.clone(), Rc::new(move |p0: crate::lower::model::MethDef| entered(once_job(move || {
                            let m = p0;
                            prism_rtl::Turn::More(Rc::new(RustMethod { m: m.clone() }))
                        }))) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_25928: Array<Text>| {
                            let methods = crate::syntax::lexer::join(&each_25928, &Text::lit("\n"));
                            let answer = if &len(&n.answers) == &Nat::from(0u32) {
                                Text::lit("")
                            } else {
                                crate::emit::rust::templates::answer(&crate::syntax::lexer::join(&run_to_end(each_job(n.answers.clone(), Rc::new(move |p0: (crate::lower::model::Pa, crate::lower::model::Ex)| entered(once_job(move || {
                                    let (pat, call) = p0;
                                    call_then(start_pattern(pat.clone()), move |pattern_26069: Text| call_then(start_expression(call.clone()), move |expression_26086: Text| prism_rtl::Turn::Finished(Text::from(format!("{} => {},", &pattern_26069, &expression_26086)))))
                                }))) as Rc<dyn Fn((crate::lower::model::Pa, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n")))
                            };
                            call_value(each_job(n.builders.clone(), Rc::new(move |p0: crate::lower::model::ForDef| entered(once_job(move || {
                                let b = p0;
                                call_then(start_for_builder(b.clone()), move |for_builder_26174: Text| prism_rtl::Turn::Finished(Text::from(format!("\n{}", &for_builder_26174))))
                            }))) as Rc<dyn Fn(crate::lower::model::ForDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_26148: Array<Text>| call_value(each_job(n.gens.clone(), Rc::new(move |p0: crate::lower::model::GenDef| entered(once_job(move || {
                                let gd = p0;
                                call_then(start_gen_builder(gd.clone()), move |gen_builder_26215: Text| prism_rtl::Turn::Finished(Text::from(format!("\n{}", &gen_builder_26215))))
                            }))) as Rc<dyn Fn(crate::lower::model::GenDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_26192: Array<Text>| {
                                let builders = concat(&append(&each_26148, &each_26192));
                                let row_impl = if &n.row_kind == &crate::lower::model::RowKind::NotARow {
                                    Text::lit("")
                                } else {
                                    Text::from(format!("\n{}", &rust_row_impl(&n)))
                                };
                                call_value(each_job(n.hooks.clone(), Rc::new(move |p0: (Text, Array<crate::lower::model::Do>)| entered(once_job(move || {
                                    let (h, body) = p0;
                                    if &h == &Text::lit("push") {
                                        call_then(start_statements(body.clone()), move |statements_26382: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::push_hook(&statements_26382)))
                                    } else {
                                        call_then(start_statements(body.clone()), move |statements_26414: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::hook(&h, &statements_26414)))
                                    }
                                }))) as Rc<dyn Fn((Text, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_26327: Array<Text>| {
                                    let hooks = crate::syntax::lexer::join(&each_26327, &Text::lit("\n"));
                                    let doc = crate::emit::rust::templates::source_doc(&Text::from(format!("`{}`: a node of its own (claude/backend.md, \"A widget block\").", &n.prism)), &n.doc);
                                    prism_rtl::Turn::Finished(Text::from(format!("{}{}", &crate::emit::rust::templates::node_(&doc, &n.name, &fields, &consts, &build, &Text::from(format!("{}{}", &methods, &builders)), &hooks, &answer), &row_impl)))
                                })
                            }))
                        })
                    })
                })
            })
        })
    }
}

/// `Start RustNode, x`: what the function value is when passed to `@Run`.
pub fn start_rust_node(n: crate::lower::model::NodeDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustNode { n })
}

/// ```prism
/// ForBuilder: unbounded fn ForDef -> Text
/// ```
pub fn for_builder(b: &crate::lower::model::ForDef) -> Text {
    crate::emit::rust::templates::for_build(&b.name, &expression(&b.at), &type_(&b.key_ty), &type_(&b.value_ty), &b.row_node, &b.source, &expression(&b.parent), &concat(&run_to_end(each_job(b.passed.clone(), Rc::new(move |p0: crate::lower::model::Ex| entered(once_job(move || {
        let x = p0;
        call_then(start_expression(x.clone()), move |expression_26907: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}", &expression_26907))))
    }))) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>))))
}

/// The step machine of `ForBuilder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ForBuilder: unbounded fn ForDef -> Text
/// ```
pub struct ForBuilder {
    pub b: crate::lower::model::ForDef,
}

impl prism_rtl::Job<Text> for ForBuilder {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let b = &self.b;
        let b = b.clone();
        call_then(start_expression(b.at.clone()), move |expression_26778: Text| call_then(start_type_(b.key_ty.clone()), move |type__26797: Text| call_then(start_type_(b.value_ty.clone()), move |type__26813: Text| call_then(start_expression(b.parent.clone()), move |expression_26852: Text| call_value(each_job(b.passed.clone(), Rc::new(move |p0: crate::lower::model::Ex| entered(once_job(move || {
            let x = p0;
            call_then(start_expression(x.clone()), move |expression_26907: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}", &expression_26907))))
        }))) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_26883: Array<Text>| prism_rtl::Turn::Finished(crate::emit::rust::templates::for_build(&b.name, &expression_26778, &type__26797, &type__26813, &b.row_node, &b.source, &expression_26852, &concat(&each_26883))))))))
    }
}

/// `Start ForBuilder, x`: what the function value is when passed to `@Run`.
pub fn start_for_builder(b: crate::lower::model::ForDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ForBuilder { b })
}

/// ```prism
/// GenBuilder: unbounded fn GenDef -> Text
/// ```
pub fn gen_builder(gd: &crate::lower::model::GenDef) -> Text {
    let path_ = if gd.transparent {
        Text::lit("self.path.clone()")
    } else {
        Text::from(format!("{}.child(Segment::Gen(g))", &expression(&gd.at)))
    };
    crate::emit::rust::templates::gen_build(&gd.name, &expression(&gd.at), &path_, &expression(&gd.source), &type_(&gd.value_ty), &expression(&gd.select))
}

/// The step machine of `GenBuilder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GenBuilder: unbounded fn GenDef -> Text
/// ```
pub struct GenBuilder {
    pub gd: crate::lower::model::GenDef,
}

impl prism_rtl::Job<Text> for GenBuilder {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let gd = &self.gd;
        let path_ = if gd.transparent {
            Text::lit("self.path.clone()")
        } else {
            Text::from(format!("{}.child(Segment::Gen(g))", &expression(&gd.at)))
        };
        let gd = gd.clone();
        call_then(start_expression(gd.at.clone()), move |expression_27301: Text| call_then(start_expression(gd.source.clone()), move |expression_27327: Text| call_then(start_type_(gd.value_ty.clone()), move |type__27351: Text| call_then(start_expression(gd.select.clone()), move |expression_27370: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::gen_build(&gd.name, &expression_27301, &path_, &expression_27327, &type__27351, &expression_27370))))))
    }
}

/// `Start GenBuilder, x`: what the function value is when passed to `@Run`.
pub fn start_gen_builder(gd: crate::lower::model::GenDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(GenBuilder { gd })
}

/// ```prism
/// RustRowImpl: unbounded fn NodeDef -> Text
/// ```
pub fn rust_row_impl(n: &crate::lower::model::NodeDef) -> Text {
    let kept = if &n.row_kind == &crate::lower::model::RowKind::ForRow {
        Array::from(vec![Text::lit("*self.left_entry.borrow_mut() = Some(self.entry(cx));")])
    } else {
        Array::new()
    };
    let unsubscribe = each(&n.subs, &(|(ev, m, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("if let (Some(p), Some(h)) = (self.parent.upgrade(), self.{}_sub.take()) {{\n    p.{}_port.unsubscribe(h);\n}}", m, ev))));
    crate::emit::rust::templates::row_impl(&n.name, &crate::syntax::lexer::join(&append(&push(&kept, &Text::lit("self.remove_places(cx);")), &unsubscribe), &Text::lit("\n")), &crate::syntax::lexer::join(&run_to_end(each_job(n.hosted.clone(), Rc::new(move |p0: crate::lower::model::MethDef| entered(once_job(move || {
        let m = p0;
        prism_rtl::Turn::More(Rc::new(RustMethod { m: m.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n")))
}

/// The step machine of `RustRowImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustRowImpl: unbounded fn NodeDef -> Text
/// ```
pub struct RustRowImpl {
    pub n: crate::lower::model::NodeDef,
}

impl prism_rtl::Job<Text> for RustRowImpl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let n = &self.n;
        let kept = if &n.row_kind == &crate::lower::model::RowKind::ForRow {
            Array::from(vec![Text::lit("*self.left_entry.borrow_mut() = Some(self.entry(cx));")])
        } else {
            Array::new()
        };
        let unsubscribe = each(&n.subs, &(|(ev, m, _): &(Text, Text, crate::lower::model::OutTy)| Text::from(format!("if let (Some(p), Some(h)) = (self.parent.upgrade(), self.{}_sub.take()) {{\n    p.{}_port.unsubscribe(h);\n}}", m, ev))));
        let n = n.clone();
        call_value(each_job(n.hosted.clone(), Rc::new(move |p0: crate::lower::model::MethDef| entered(once_job(move || {
            let m = p0;
            prism_rtl::Turn::More(Rc::new(RustMethod { m: m.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_28068: Array<Text>| prism_rtl::Turn::Finished(crate::emit::rust::templates::row_impl(&n.name, &crate::syntax::lexer::join(&append(&push(&kept, &Text::lit("self.remove_places(cx);")), &unsubscribe), &Text::lit("\n")), &crate::syntax::lexer::join(&each_28068, &Text::lit("\n")))))
    }
}

/// `Start RustRowImpl, x`: what the function value is when passed to `@Run`.
pub fn start_rust_row_impl(n: crate::lower::model::NodeDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustRowImpl { n })
}

/// ```prism
/// RustMethod: unbounded fn MethDef -> Text
/// ```
pub fn rust_method(m: &crate::lower::model::MethDef) -> Text {
    let recv = match &m.recv {
        crate::lower::model::Recv::RecvRc => Text::lit("self: &Rc<Self>"),
        crate::lower::model::Recv::RecvRef => Text::lit("&self"),
        crate::lower::model::Recv::RecvOwned => Text::lit("self: Rc<Self>"),
    };
    let cx_ = match &m.cx_ {
        crate::lower::model::CxArg::CxMut => Text::lit(", cx: &mut Cx"),
        crate::lower::model::CxArg::CxRef => Text::lit(", cx: &Cx"),
        crate::lower::model::CxArg::CxNone => Text::lit(""),
    };
    let params = concat(&run_to_end(each_job(m.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (p_, t) = p0;
        call_then(start_type_(t.clone()), move |type__28455: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}: {}", &p_, &type__28455))))
    }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)));
    let ret = if &m.ret == &crate::lower::model::OutTy::OutUnit {
        Text::lit("")
    } else {
        Text::from(format!(" -> {}", &type_(&m.ret)))
    };
    let sig = Text::from(format!("fn {}({}{}{}){}", &m.name, &recv, &params, &cx_, &ret));
    let body = if &m.ret == &crate::lower::model::OutTy::OutUnit {
        statements(&m.body)
    } else {
        if &len(&m.body) == &Nat::from(0u32) {
            body_lines(&m.tail)
        } else {
            Text::from(format!("{}\n{}", &statements(&m.body), &body_lines(&m.tail)))
        }
    };
    crate::emit::rust::templates::method(&crate::emit::rust::templates::doc(&m.doc), &sig, &body)
}

/// The step machine of `RustMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustMethod: unbounded fn MethDef -> Text
/// ```
pub struct RustMethod {
    pub m: crate::lower::model::MethDef,
}

impl prism_rtl::Job<Text> for RustMethod {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let m = &self.m;
        let recv = match &m.recv {
            crate::lower::model::Recv::RecvRc => Text::lit("self: &Rc<Self>"),
            crate::lower::model::Recv::RecvRef => Text::lit("&self"),
            crate::lower::model::Recv::RecvOwned => Text::lit("self: Rc<Self>"),
        };
        let cx_ = match &m.cx_ {
            crate::lower::model::CxArg::CxMut => Text::lit(", cx: &mut Cx"),
            crate::lower::model::CxArg::CxRef => Text::lit(", cx: &Cx"),
            crate::lower::model::CxArg::CxNone => Text::lit(""),
        };
        let m = m.clone();
        call_value(each_job(m.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
            let (p_, t) = p0;
            call_then(start_type_(t.clone()), move |type__28455: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}: {}", &p_, &type__28455))))
        }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_28419: Array<Text>| {
            let params = concat(&each_28419);
            let ret = if &m.ret == &crate::lower::model::OutTy::OutUnit {
                Text::lit("")
            } else {
                Text::from(format!(" -> {}", &type_(&m.ret)))
            };
            let sig = Text::from(format!("fn {}({}{}{}){}", &m.name, &recv, &params, &cx_, &ret));
            let body = if &m.ret == &crate::lower::model::OutTy::OutUnit {
                statements(&m.body)
            } else {
                if &len(&m.body) == &Nat::from(0u32) {
                    body_lines(&m.tail)
                } else {
                    Text::from(format!("{}\n{}", &statements(&m.body), &body_lines(&m.tail)))
                }
            };
            prism_rtl::Turn::Finished(crate::emit::rust::templates::method(&crate::emit::rust::templates::doc(&m.doc), &sig, &body))
        })
    }
}

/// `Start RustMethod, x`: what the function value is when passed to `@Run`.
pub fn start_rust_method(m: crate::lower::model::MethDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustMethod { m })
}

/// ```prism
/// RustProgram: unbounded fn ProgDef, Bool -> Text
/// ```
pub fn rust_program(p_: &crate::lower::model::ProgDef, fallible: &bool) -> Text {
    let n = len(&p_.params);
    let names = each(&p_.params, &(|(a, _): &(Text, crate::lower::model::OutTy)| a.clone()));
    let decode = if &n == &Nat::from(0u32) {
        Text::lit("let _ = args;")
    } else {
        decode_args(p_, &names)
    };
    let call = Text::from(format!("{}::build(Path::root(), {}&mut cx){}", &p_.node_, &concat(&each(&names, &(|a: &Text| Text::from(format!("{}, ", a))))), &(if *fallible { Text::lit("?") } else { Text::lit("") })));
    crate::emit::rust::templates::program(&p_.name, &p_.prism, &p_.node_, &decode, &call)
}

/// The step machine of `RustProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustProgram: unbounded fn ProgDef, Bool -> Text
/// ```
pub struct RustProgram {
    pub p_: crate::lower::model::ProgDef,
    pub fallible: bool,
}

impl prism_rtl::Job<Text> for RustProgram {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let p_ = &self.p_;
        let fallible = &self.fallible;
        let n = len(&p_.params);
        let names = each(&p_.params, &(|(a, _): &(Text, crate::lower::model::OutTy)| a.clone()));
        let decode = if &n == &Nat::from(0u32) {
            Text::lit("let _ = args;")
        } else {
            decode_args(p_, &names)
        };
        let call = Text::from(format!("{}::build(Path::root(), {}&mut cx){}", &p_.node_, &concat(&each(&names, &(|a: &Text| Text::from(format!("{}, ", a))))), &(if *fallible { Text::lit("?") } else { Text::lit("") })));
        prism_rtl::Turn::Finished(crate::emit::rust::templates::program(&p_.name, &p_.prism, &p_.node_, &decode, &call))
    }
}

/// `Start RustProgram, x`: what the function value is when passed to `@Run`.
pub fn start_rust_program(p_: crate::lower::model::ProgDef, fallible: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustProgram { p_, fallible })
}

/// ```prism
/// DecodeArgs: unbounded fn ProgDef, [Text] -> Text
/// ```
pub fn decode_args(p_: &crate::lower::model::ProgDef, names: &Array<Text>) -> Text {
    let n = len(names);
    let plural = if &n == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") };
    let head = Text::from(format!("let [{}] = args else {{ return Err(Fault::answer(\"@{} takes {} argument{}\")) }};", &crate::syntax::lexer::join(names, &Text::lit(", ")), &p_.prism, &n, &plural));
    crate::syntax::lexer::join(&append(&Array::from(vec![head.clone()]), &run_to_end(each_job(p_.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
        let (a, t) = p0;
        call_then(start_decode_head(t.clone()), move |decode_head_29486: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {}::from_pod({})?;", &a, &decode_head_29486, &a))))
    }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>))), &Text::lit("\n"))
}

/// The step machine of `DecodeArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DecodeArgs: unbounded fn ProgDef, [Text] -> Text
/// ```
pub struct DecodeArgs {
    pub p_: crate::lower::model::ProgDef,
    pub names: Array<Text>,
}

impl prism_rtl::Job<Text> for DecodeArgs {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let p_ = &self.p_;
        let names = &self.names;
        let n = len(names);
        let plural = if &n == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") };
        let head = Text::from(format!("let [{}] = args else {{ return Err(Fault::answer(\"@{} takes {} argument{}\")) }};", &crate::syntax::lexer::join(names, &Text::lit(", ")), &p_.prism, &n, &plural));
        let p_ = p_.clone();
        call_value(each_job(p_.params.clone(), Rc::new(move |p0: (Text, crate::lower::model::OutTy)| entered(once_job(move || {
            let (a, t) = p0;
            call_then(start_decode_head(t.clone()), move |decode_head_29486: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {}::from_pod({})?;", &a, &decode_head_29486, &a))))
        }))) as Rc<dyn Fn((Text, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_29447: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::join(&append(&Array::from(vec![head.clone()]), &each_29447), &Text::lit("\n"))))
    }
}

/// `Start DecodeArgs, x`: what the function value is when passed to `@Run`.
pub fn start_decode_args(p_: crate::lower::model::ProgDef, names: Array<Text>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(DecodeArgs { p_, names })
}

/// ```prism
/// RustModule: unbounded fn ModDef, Text -> Text
/// ```
pub fn rust_module(m: &crate::lower::model::ModDef, kids: &Text) -> Text {
    crate::emit::rust::templates::module(&(if &m.prism == &Text::lit("") {
        Text::lit("The root module")
    } else {
        Text::from(format!("The module `{}`", &m.prism))
    }), &m.path_, kids, &crate::syntax::lexer::join(&run_to_end(each_job(m.items.clone(), Rc::new(move |p0: crate::lower::model::Item| entered(once_job(move || {
        let it = p0;
        prism_rtl::Turn::More(Rc::new(RustItem { it: it.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::Item) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n")))
}

/// The step machine of `RustModule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustModule: unbounded fn ModDef, Text -> Text
/// ```
pub struct RustModule {
    pub m: crate::lower::model::ModDef,
    pub kids: Text,
}

impl prism_rtl::Job<Text> for RustModule {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let m = &self.m;
        let kids = &self.kids;
        let kids = kids.clone();
        let m = m.clone();
        call_value(each_job(m.items.clone(), Rc::new(move |p0: crate::lower::model::Item| entered(once_job(move || {
            let it = p0;
            prism_rtl::Turn::More(Rc::new(RustItem { it: it.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Item) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_30059: Array<Text>| prism_rtl::Turn::Finished(crate::emit::rust::templates::module(&(if &m.prism == &Text::lit("") {
            Text::lit("The root module")
        } else {
            Text::from(format!("The module `{}`", &m.prism))
        }), &m.path_, &kids, &crate::syntax::lexer::join(&each_30059, &Text::lit("\n")))))
    }
}

/// `Start RustModule, x`: what the function value is when passed to `@Run`.
pub fn start_rust_module(m: crate::lower::model::ModDef, kids: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustModule { m, kids })
}

/// ```prism
/// NodeFallible: fn Model, Text -> Bool
/// ```
pub fn node_fallible(model: &crate::lower::model::Model, path_: &Text) -> bool {
    fold(&model.mods, &false, &(|f: &bool, m: &crate::lower::model::ModDef| fold(&m.items, f, &(|f2: &bool, it: &crate::lower::model::Item| match it {
        crate::lower::model::Item::ItNode(n) => *f2 || ((&Text::from(format!("{}::{}", &m.name, &n.name)) == path_) && n.fallible),
        _ => *f2,
    }))))
}

/// ```prism
/// EmitCrate: unbounded fn Model, Text, [Text] -> [((Text, Text))]
/// ```
pub fn emit_crate(model: &crate::lower::model::Model, runtime: &Text, scripts: &Array<Text>) -> Array<(Text, Text)> {
    let gui = match &model.root {
        Some(r) => &r.world == &Text::lit("canvas"),
        None => false,
    };
    let cargo = crate::emit::rust::templates::cargo(&model.name, runtime, &(if gui { Text::lit("\"canvas\"") } else { Text::lit("") }));
    let paths = rust_mod_paths(&model.mods);
    let mods = concat(&each(&filter(&paths, &(|p_: &Text| !crate::syntax::lexer::contains(p_, &Text::lit(":")))), &(|p_: &Text| Text::from(format!("mod {};\n", p_)))));
    let programs = crate::syntax::lexer::join(&run_to_end(each_job(all_programs(model), {
        let model = model.clone();
        Rc::new(move |p0: crate::lower::model::ProgDef| {
            let model = model.clone();
            entered(once_job(move || {
                let p_ = p0;
                prism_rtl::Turn::More(Rc::new(RustProgram { p_: p_.clone(), fallible: node_fallible(&model, &p_.node_) }))
            }))
        }) as Rc<dyn Fn(crate::lower::model::ProgDef) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let regs = concat(&each(&model.programs, &(|p_: &crate::lower::model::ProgDef| Text::from(format!(".program::<{}>(\"{}\")\n", &p_.name, &p_.prism)))));
    let checks = concat(&run_to_end(each_job(model.checks.clone(), Rc::new(move |p0: crate::lower::model::CheckDef| entered(once_job(move || {
        let c = p0;
        call_value(each_job(c.lines.clone(), Rc::new(move |p0: crate::lower::model::Ex| entered(once_job(move || {
            let l = p0;
            prism_rtl::Turn::More(Rc::new(Expression { x: l.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_31088: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!(".check(\"{}\", || vec![{}])\n", &c.name, &crate::syntax::lexer::join(&each_31088, &Text::lit(", "))))))
    }))) as Rc<dyn Fn(crate::lower::model::CheckDef) -> Rc<dyn prism_rtl::Job<Text>>>)));
    let script_list = concat(&each(scripts, &(|s: &Text| Text::from(format!("\"{}\",\n", &crate::lower::escape(s))))));
    let run_root = match &model.root {
        Some(r) => crate::emit::rust::templates::run_root(&r.name),
        None => crate::emit::rust::templates::no_root(&model.name),
    };
    let world = match &model.root {
        Some(r) => r.world.clone(),
        None => Text::lit("test"),
    };
    let main = crate::emit::rust::templates::main(&model.name, &Text::from(format!("mod prelude;\n{}", &mods)), &Text::from(format!("{}\n{}\n{}", &rust_row(&model.elem), &rust_answer(&model.answer), &programs)), &Text::from(format!("{}{}", &regs, &checks)), &script_list, &run_root, &world);
    let files = run_to_end(each_job(model.mods.clone(), {
        let paths = paths.clone();
        Rc::new(move |p0: crate::lower::model::ModDef| {
            let paths = paths.clone();
            entered(once_job(move || {
                let m = p0;
                call_then(start_rust_module(m.clone(), kids_of(&paths, &m.name)), move |rust_module_31602: Text| prism_rtl::Turn::Finished((rust_mod_file(&m.name), rust_module_31602)))
            }))
        }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<(Text, Text)>>>
    }));
    let named = each(&model.mods, &(|m: &crate::lower::model::ModDef| m.name.clone()));
    let bare = each(&filter(&paths, &(|p_: &Text| !fold(&named, &false, &(|f: &bool, n: &Text| *f || (n == p_))))), &(|p_: &Text| (rust_mod_file(p_), Text::from(format!("//! Emitted by prismc: the modules under `{}`, which declares nothing of its own.\n\n{}", p_, &kids_of(&paths, p_))))));
    append(&Array::from(vec![(Text::lit("Cargo.toml"), cargo.clone()), (Text::lit("src/main.rs"), main.clone()), (Text::lit("src/prelude.rs"), crate::emit::rust::prelude::prelude_source(&Text::lit("")))]), &append(&files, &bare))
}

/// The step machine of `EmitCrate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EmitCrate: unbounded fn Model, Text, [Text] -> [((Text, Text))]
/// ```
pub struct EmitCrate {
    pub model: crate::lower::model::Model,
    pub runtime: Text,
    pub scripts: Array<Text>,
}

impl prism_rtl::Job<Array<(Text, Text)>> for EmitCrate {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Text, Text)>> {
        let model = &self.model;
        let runtime = &self.runtime;
        let scripts = &self.scripts;
        let gui = match &model.root {
            Some(r) => &r.world == &Text::lit("canvas"),
            None => false,
        };
        let cargo = crate::emit::rust::templates::cargo(&model.name, runtime, &(if gui { Text::lit("\"canvas\"") } else { Text::lit("") }));
        let paths = rust_mod_paths(&model.mods);
        let mods = concat(&each(&filter(&paths, &(|p_: &Text| !crate::syntax::lexer::contains(p_, &Text::lit(":")))), &(|p_: &Text| Text::from(format!("mod {};\n", p_)))));
        let model = model.clone();
        let scripts = scripts.clone();
        call_value(each_job(all_programs(&model), {
            let model = model.clone();
            Rc::new(move |p0: crate::lower::model::ProgDef| {
                let model = model.clone();
                entered(once_job(move || {
                    let p_ = p0;
                    prism_rtl::Turn::More(Rc::new(RustProgram { p_: p_.clone(), fallible: node_fallible(&model, &p_.node_) }))
                }))
            }) as Rc<dyn Fn(crate::lower::model::ProgDef) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_30830: Array<Text>| {
            let programs = crate::syntax::lexer::join(&each_30830, &Text::lit("\n"));
            let regs = concat(&each(&model.programs, &(|p_: &crate::lower::model::ProgDef| Text::from(format!(".program::<{}>(\"{}\")\n", &p_.name, &p_.prism)))));
            call_value(each_job(model.checks.clone(), Rc::new(move |p0: crate::lower::model::CheckDef| entered(once_job(move || {
                let c = p0;
                call_value(each_job(c.lines.clone(), Rc::new(move |p0: crate::lower::model::Ex| entered(once_job(move || {
                    let l = p0;
                    prism_rtl::Turn::More(Rc::new(Expression { x: l.clone() }))
                }))) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_31088: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!(".check(\"{}\", || vec![{}])\n", &c.name, &crate::syntax::lexer::join(&each_31088, &Text::lit(", "))))))
            }))) as Rc<dyn Fn(crate::lower::model::CheckDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_31027: Array<Text>| {
                let checks = concat(&each_31027);
                let script_list = concat(&each(&scripts, &(|s: &Text| Text::from(format!("\"{}\",\n", &crate::lower::escape(s))))));
                let run_root = match &model.root {
                    Some(r) => crate::emit::rust::templates::run_root(&r.name),
                    None => crate::emit::rust::templates::no_root(&model.name),
                };
                let world = match &model.root {
                    Some(r) => r.world.clone(),
                    None => Text::lit("test"),
                };
                call_then(start_rust_row(model.elem.clone()), move |rust_row_31433: Text| call_then(start_rust_answer(model.answer.clone()), move |rust_answer_31455: Text| {
                    let main = crate::emit::rust::templates::main(&model.name, &Text::from(format!("mod prelude;\n{}", &mods)), &Text::from(format!("{}\n{}\n{}", &rust_row_31433, &rust_answer_31455, &programs)), &Text::from(format!("{}{}", &regs, &checks)), &script_list, &run_root, &world);
                    call_value(each_job(model.mods.clone(), {
                        let paths = paths.clone();
                        Rc::new(move |p0: crate::lower::model::ModDef| {
                            let paths = paths.clone();
                            entered(once_job(move || {
                                let m = p0;
                                call_then(start_rust_module(m.clone(), kids_of(&paths, &m.name)), move |rust_module_31602: Text| prism_rtl::Turn::Finished((rust_mod_file(&m.name), rust_module_31602)))
                            }))
                        }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<(Text, Text)>>>
                    }), move |each_31555: Array<(Text, Text)>| {
                        let files = each_31555;
                        let named = each(&model.mods, &(|m: &crate::lower::model::ModDef| m.name.clone()));
                        let bare = each(&filter(&paths, &(|p_: &Text| !fold(&named, &false, &(|f: &bool, n: &Text| *f || (n == p_))))), &(|p_: &Text| (rust_mod_file(p_), Text::from(format!("//! Emitted by prismc: the modules under `{}`, which declares nothing of its own.\n\n{}", p_, &kids_of(&paths, p_))))));
                        prism_rtl::Turn::Finished(append(&Array::from(vec![(Text::lit("Cargo.toml"), cargo.clone()), (Text::lit("src/main.rs"), main.clone()), (Text::lit("src/prelude.rs"), crate::emit::rust::prelude::prelude_source(&Text::lit("")))]), &append(&files, &bare)))
                    })
                }))
            })
        })
    }
}

/// `Start EmitCrate, x`: what the function value is when passed to `@Run`.
pub fn start_emit_crate(model: crate::lower::model::Model, runtime: Text, scripts: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>> {
    Rc::new(EmitCrate { model, runtime, scripts })
}

/// ```prism
/// RustModPaths: fn [ModDef] -> [Text]
/// ```
pub fn rust_mod_paths(mods: &Array<crate::lower::model::ModDef>) -> Array<Text> {
    fold(mods, &Array::new(), &(|acc: &Array<Text>, m: &crate::lower::model::ModDef| {
        let segs = split(&m.name, &Text::lit("::"));
        fold(&crate::check::errors::range0(&len(&segs)), acc, &(|a: &Array<Text>, i: &Nat| add_path(a, &crate::syntax::lexer::join(&take(&segs, &(i + &Nat::from(1u32))), &Text::lit("::")))))
    }))
}

/// ```prism
/// AddPath: fn [Text], Text -> [Text]
/// ```
pub fn add_path(ps: &Array<Text>, p_: &Text) -> Array<Text> {
    if fold(ps, &false, &(|f: &bool, q: &Text| *f || (q == p_))) {
        ps.clone()
    } else {
        push(ps, p_)
    }
}

/// ```prism
/// RustModFile: fn Text -> Text
/// ```
pub fn rust_mod_file(p_: &Text) -> Text {
    if p_ == &Text::lit("program") {
        Text::lit("src/program.rs")
    } else {
        Text::from(format!("src/{}/mod.rs", &crate::syntax::lexer::join(&split(p_, &Text::lit("::")), &Text::lit("/"))))
    }
}

/// ```prism
/// KidsOf: fn [Text], Text -> Text
/// ```
pub fn kids_of(paths: &Array<Text>, p_: &Text) -> Text {
    concat(&each(&filter(paths, &(|q: &Text| crate::syntax::lexer::has_prefix(q, &Text::from(format!("{}::", p_))) && !crate::syntax::lexer::contains(&crate::syntax::lexer::drop_prefix(q, &Text::from(format!("{}::", p_))), &Text::lit(":")))), &(|q: &Text| Text::from(format!("pub mod {};\n", &crate::syntax::lexer::drop_prefix(q, &Text::from(format!("{}::", p_))))))))
}

/// ```prism
/// AllPrograms: fn Model -> [ProgDef]
/// ```
pub fn all_programs(model: &crate::lower::model::Model) -> Array<crate::lower::model::ProgDef> {
    match &model.root {
        Some(r) => if fold(&model.programs, &false, &(|f: &bool, p_: &crate::lower::model::ProgDef| *f || (&p_.name == &r.name))) {
            model.programs.clone()
        } else {
            push(&model.programs, r)
        },
        None => model.programs.clone(),
    }
}
