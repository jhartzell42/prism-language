//! The module `Emit.Rust`, from `target/bootstrap/src/prismc/emit/rust/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod items;
pub mod prelude;
pub mod templates;

/// ```prism
/// Type: unbounded fn OutTy -> Text
/// ```
pub fn type_(t: &crate::lower::model::OutTy) -> Text {
    'm1596: {
        if let crate::lower::model::OutTy::OutNat = t {
            break 'm1596 Text::lit("Nat");
        }
        if let crate::lower::model::OutTy::OutInt = t {
            break 'm1596 Text::lit("Int");
        }
        if let crate::lower::model::OutTy::OutU8 = t {
            break 'm1596 Text::lit("u8");
        }
        if let crate::lower::model::OutTy::OutFloat = t {
            break 'm1596 Text::lit("f64");
        }
        if let crate::lower::model::OutTy::OutBool = t {
            break 'm1596 Text::lit("bool");
        }
        if let crate::lower::model::OutTy::OutChar = t {
            break 'm1596 Text::lit("char");
        }
        if let crate::lower::model::OutTy::OutText = t {
            break 'm1596 Text::lit("Text");
        }
        if let crate::lower::model::OutTy::OutCursor = t {
            break 'm1596 Text::lit("Cursor");
        }
        if let crate::lower::model::OutTy::OutRegex = t {
            break 'm1596 Text::lit("Regex");
        }
        if let crate::lower::model::OutTy::OutReplacement = t {
            break 'm1596 Text::lit("RegexReplacement");
        }
        if let crate::lower::model::OutTy::OutUnit = t {
            break 'm1596 Text::lit("()");
        }
        if let crate::lower::model::OutTy::OutPath = t {
            break 'm1596 Text::lit("Path");
        }
        if let crate::lower::model::OutTy::OutDuration = t {
            break 'm1596 Text::lit("Duration");
        }
        if let crate::lower::model::OutTy::OutError = t {
            break 'm1596 Text::lit("Error");
        }
        if let crate::lower::model::OutTy::OutNamed(n, m1596_14_1) = t && (m1596_14_1.len() == 0) {
            break 'm1596 n.clone();
        }
        if let crate::lower::model::OutTy::OutNamed(n, args_) = t {
            break 'm1596 Text::from(format!("{}<{}>", n, &types(args_)));
        }
        if let crate::lower::model::OutTy::OutOpt(i) = t {
            break 'm1596 Text::from(format!("Option<{}>", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutRes(i) = t {
            break 'm1596 Text::from(format!("Result<{}, Error>", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutTuple(m1596_18_0) = t && (m1596_18_0.len() == 1) && let Some(one) = index(m1596_18_0, &Nat::from(0u32)) {
            break 'm1596 Text::from(format!("({},)", &type_(&one)));
        }
        if let crate::lower::model::OutTy::OutTuple(ts) = t {
            break 'm1596 Text::from(format!("({})", &types(ts)));
        }
        if let crate::lower::model::OutTy::OutArray(e) = t {
            break 'm1596 Text::from(format!("Array<{}>", &type_(&**e)));
        }
        if let crate::lower::model::OutTy::OutMap(k, v_) = t {
            break 'm1596 Text::from(format!("Map<{}, {}>", &type_(&**k), &type_(&**v_)));
        }
        if let crate::lower::model::OutTy::OutFn(ps, r) = t {
            break 'm1596 Text::from(format!("Rc<dyn Fn({}) -> {}>", &ref_types(ps), &type_(&**r)));
        }
        if let crate::lower::model::OutTy::OutRef(m1596_23_0) = t && let crate::lower::model::OutTy::OutFn(ps, r) = &**m1596_23_0 {
            break 'm1596 Text::from(format!("&dyn Fn({}) -> {}", &ref_types(ps), &type_(&**r)));
        }
        if let crate::lower::model::OutTy::OutRef(i) = t {
            break 'm1596 Text::from(format!("&{}", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutJobFn(a, b) = t {
            break 'm1596 Text::from(format!("Rc<dyn Fn({}) -> Rc<dyn prism_rtl::Job<{}>>>", &type_(&**a), &type_(&**b)));
        }
        if let crate::lower::model::OutTy::OutJob(b) = t {
            break 'm1596 Text::from(format!("Rc<dyn prism_rtl::Job<{}>>", &type_(&**b)));
        }
        if let crate::lower::model::OutTy::OutEvent(i) = t {
            break 'm1596 Text::from(format!("Event<{}>", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutDyn(i) = t {
            break 'm1596 Text::from(format!("Dynamic<{}>", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutGen(n) = t {
            break 'm1596 n.clone();
        }
        if let crate::lower::model::OutTy::OutRc(i) = t {
            break 'm1596 Text::from(format!("Rc<{}>", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutPod = t {
            break 'm1596 Text::lit("Pod");
        }
        if let crate::lower::model::OutTy::OutShowAny = t {
            break 'm1596 Text::lit("Rc<dyn Show>");
        }
        if let crate::lower::model::OutTy::OutHold(i) = t {
            break 'm1596 Text::from(format!("Hold<{}>", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutStamped(i) = t {
            break 'm1596 Text::from(format!("Stamped<{}>", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutSnapshot(i) = t {
            break 'm1596 Text::from(format!("Snapshot<{}>", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutDefer(i) = t {
            break 'm1596 Text::from(format!("Defer<{}>", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutWeak(n) = t {
            break 'm1596 Text::from(format!("Weak<{}>", n));
        }
        if let crate::lower::model::OutTy::OutCell(i) = t {
            break 'm1596 Text::from(format!("RefCell<{}>", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutWakes = t {
            break 'm1596 Text::lit("Wakes");
        }
        if let crate::lower::model::OutTy::OutCount = t {
            break 'm1596 Text::lit("u32");
        }
        if let crate::lower::model::OutTy::OutObj(i) = t {
            break 'm1596 Text::from(format!("Rc<dyn {}>", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutSlice(i) = t {
            break 'm1596 Text::from(format!("[{}]", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutPort(i) = t {
            break 'm1596 Text::from(format!("Port<{}>", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutLive(i) = t {
            break 'm1596 Text::from(format!("Live<{}>", &type_(&**i)));
        }
        if let crate::lower::model::OutTy::OutUnknown(what) = t {
            break 'm1596 Text::from(format!("() /* {} */", what));
        }
        if let crate::lower::model::OutTy::OutQuantified(b) = t {
            break 'm1596 Text::from(format!("compile_error!(\"{}a quantified type variable of `{}`: no instantiation gives it a type\")", &crate::lower::expr::lowering_refusal(), b));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `Type`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Type: unbounded fn OutTy -> Text
/// ```
pub struct Type {
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for Type {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        'm1596: {
            if let crate::lower::model::OutTy::OutNat = t {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Nat"));
            }
            if let crate::lower::model::OutTy::OutInt = t {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Int"));
            }
            if let crate::lower::model::OutTy::OutU8 = t {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("u8"));
            }
            if let crate::lower::model::OutTy::OutFloat = t {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("f64"));
            }
            if let crate::lower::model::OutTy::OutBool = t {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("bool"));
            }
            if let crate::lower::model::OutTy::OutChar = t {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("char"));
            }
            if let crate::lower::model::OutTy::OutText = t {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Text"));
            }
            if let crate::lower::model::OutTy::OutCursor = t {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Cursor"));
            }
            if let crate::lower::model::OutTy::OutRegex = t {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Regex"));
            }
            if let crate::lower::model::OutTy::OutReplacement = t {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("RegexReplacement"));
            }
            if let crate::lower::model::OutTy::OutUnit = t {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("()"));
            }
            if let crate::lower::model::OutTy::OutPath = t {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Path"));
            }
            if let crate::lower::model::OutTy::OutDuration = t {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Duration"));
            }
            if let crate::lower::model::OutTy::OutError = t {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Error"));
            }
            if let crate::lower::model::OutTy::OutNamed(n, m1596_14_1) = t && (m1596_14_1.len() == 0) {
                break 'm1596 prism_rtl::Turn::Finished(n.clone());
            }
            if let crate::lower::model::OutTy::OutNamed(n, args_) = t {
                break 'm1596 {
                    let args_ = args_.clone();
                    let n = n.clone();
                    call_then(start_types(args_.clone()), move |types_1962: Text| prism_rtl::Turn::Finished(Text::from(format!("{}<{}>", &n, &types_1962))))
                };
            }
            if let crate::lower::model::OutTy::OutOpt(i) = t {
                break 'm1596 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__1999: Text| prism_rtl::Turn::Finished(Text::from(format!("Option<{}>", &type__1999))))
                };
            }
            if let crate::lower::model::OutTy::OutRes(i) = t {
                break 'm1596 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2032: Text| prism_rtl::Turn::Finished(Text::from(format!("Result<{}, Error>", &type__2032))))
                };
            }
            if let crate::lower::model::OutTy::OutTuple(m1596_18_0) = t && (m1596_18_0.len() == 1) && let Some(one) = index(m1596_18_0, &Nat::from(0u32)) {
                break 'm1596 call_then(start_type_(one.clone()), move |type__2074: Text| prism_rtl::Turn::Finished(Text::from(format!("({},)", &type__2074))));
            }
            if let crate::lower::model::OutTy::OutTuple(ts) = t {
                break 'm1596 {
                    let ts = ts.clone();
                    call_then(start_types(ts.clone()), move |types_2107: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &types_2107))))
                };
            }
            if let crate::lower::model::OutTy::OutArray(e) = t {
                break 'm1596 {
                    let e = (**e).clone();
                    call_then(start_type_(e.clone()), move |type__2143: Text| prism_rtl::Turn::Finished(Text::from(format!("Array<{}>", &type__2143))))
                };
            }
            if let crate::lower::model::OutTy::OutMap(k, v_) = t {
                break 'm1596 {
                    let k = (**k).clone();
                    let v_ = (**v_).clone();
                    call_then(start_type_(k.clone()), move |type__2176: Text| call_then(start_type_(v_.clone()), move |type__2186: Text| prism_rtl::Turn::Finished(Text::from(format!("Map<{}, {}>", &type__2176, &type__2186)))))
                };
            }
            if let crate::lower::model::OutTy::OutFn(ps, r) = t {
                break 'm1596 {
                    let ps = ps.clone();
                    let r = (**r).clone();
                    call_then(start_ref_types(ps.clone()), move |ref_types_2225: Text| call_then(start_type_(r.clone()), move |type__2243: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<dyn Fn({}) -> {}>", &ref_types_2225, &type__2243)))))
                };
            }
            if let crate::lower::model::OutTy::OutRef(m1596_23_0) = t && let crate::lower::model::OutTy::OutFn(ps, r) = &**m1596_23_0 {
                break 'm1596 {
                    let ps = ps.clone();
                    let r = (**r).clone();
                    call_then(start_ref_types(ps.clone()), move |ref_types_2289: Text| call_then(start_type_(r.clone()), move |type__2307: Text| prism_rtl::Turn::Finished(Text::from(format!("&dyn Fn({}) -> {}", &ref_types_2289, &type__2307)))))
                };
            }
            if let crate::lower::model::OutTy::OutRef(i) = t {
                break 'm1596 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2333: Text| prism_rtl::Turn::Finished(Text::from(format!("&{}", &type__2333))))
                };
            }
            if let crate::lower::model::OutTy::OutJobFn(a, b) = t {
                break 'm1596 {
                    let a = (**a).clone();
                    let b = (**b).clone();
                    call_then(start_type_(a.clone()), move |type__2373: Text| call_then(start_type_(b.clone()), move |type__2408: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<dyn Fn({}) -> Rc<dyn prism_rtl::Job<{}>>>", &type__2373, &type__2408)))))
                };
            }
            if let crate::lower::model::OutTy::OutJob(b) = t {
                break 'm1596 {
                    let b = (**b).clone();
                    call_then(start_type_(b.clone()), move |type__2458: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<dyn prism_rtl::Job<{}>>", &type__2458))))
                };
            }
            if let crate::lower::model::OutTy::OutEvent(i) = t {
                break 'm1596 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2493: Text| prism_rtl::Turn::Finished(Text::from(format!("Event<{}>", &type__2493))))
                };
            }
            if let crate::lower::model::OutTy::OutDyn(i) = t {
                break 'm1596 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2527: Text| prism_rtl::Turn::Finished(Text::from(format!("Dynamic<{}>", &type__2527))))
                };
            }
            if let crate::lower::model::OutTy::OutGen(n) = t {
                break 'm1596 prism_rtl::Turn::Finished(n.clone());
            }
            if let crate::lower::model::OutTy::OutRc(i) = t {
                break 'm1596 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2571: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<{}>", &type__2571))))
                };
            }
            if let crate::lower::model::OutTy::OutPod = t {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Pod"));
            }
            if let crate::lower::model::OutTy::OutShowAny = t {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Rc<dyn Show>"));
            }
            if let crate::lower::model::OutTy::OutHold(i) = t {
                break 'm1596 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2652: Text| prism_rtl::Turn::Finished(Text::from(format!("Hold<{}>", &type__2652))))
                };
            }
            if let crate::lower::model::OutTy::OutStamped(i) = t {
                break 'm1596 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2690: Text| prism_rtl::Turn::Finished(Text::from(format!("Stamped<{}>", &type__2690))))
                };
            }
            if let crate::lower::model::OutTy::OutSnapshot(i) = t {
                break 'm1596 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2730: Text| prism_rtl::Turn::Finished(Text::from(format!("Snapshot<{}>", &type__2730))))
                };
            }
            if let crate::lower::model::OutTy::OutDefer(i) = t {
                break 'm1596 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2764: Text| prism_rtl::Turn::Finished(Text::from(format!("Defer<{}>", &type__2764))))
                };
            }
            if let crate::lower::model::OutTy::OutWeak(n) = t {
                break 'm1596 prism_rtl::Turn::Finished(Text::from(format!("Weak<{}>", n)));
            }
            if let crate::lower::model::OutTy::OutCell(i) = t {
                break 'm1596 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2826: Text| prism_rtl::Turn::Finished(Text::from(format!("RefCell<{}>", &type__2826))))
                };
            }
            if let crate::lower::model::OutTy::OutWakes = t {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Wakes"));
            }
            if let crate::lower::model::OutTy::OutCount = t {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("u32"));
            }
            if let crate::lower::model::OutTy::OutObj(i) = t {
                break 'm1596 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2901: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<dyn {}>", &type__2901))))
                };
            }
            if let crate::lower::model::OutTy::OutSlice(i) = t {
                break 'm1596 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2930: Text| prism_rtl::Turn::Finished(Text::from(format!("[{}]", &type__2930))))
                };
            }
            if let crate::lower::model::OutTy::OutPort(i) = t {
                break 'm1596 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2962: Text| prism_rtl::Turn::Finished(Text::from(format!("Port<{}>", &type__2962))))
                };
            }
            if let crate::lower::model::OutTy::OutLive(i) = t {
                break 'm1596 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2994: Text| prism_rtl::Turn::Finished(Text::from(format!("Live<{}>", &type__2994))))
                };
            }
            if let crate::lower::model::OutTy::OutUnknown(what) = t {
                break 'm1596 prism_rtl::Turn::Finished(Text::from(format!("() /* {} */", what)));
            }
            if let crate::lower::model::OutTy::OutQuantified(b) = t {
                break 'm1596 prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}a quantified type variable of `{}`: no instantiation gives it a type\")", &crate::lower::expr::lowering_refusal(), b)));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start Type, x`: what the function value is when passed to `@Run`.
pub fn start_type_(t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Type { t })
}

/// ```prism
/// Types: unbounded fn [OutTy] -> Text
/// ```
pub fn types(ts: &Array<crate::lower::model::OutTy>) -> Text {
    crate::syntax::lexer::chars::join(&run_to_end(each_job(ts.clone(), Rc::new(move |p0: crate::lower::model::OutTy| entered(once_job(move || {
        let t = p0;
        prism_rtl::Turn::More(Rc::new(Type { t: t.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))
}

/// The step machine of `Types`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Types: unbounded fn [OutTy] -> Text
/// ```
pub struct Types {
    pub ts: Array<crate::lower::model::OutTy>,
}

impl prism_rtl::Job<Text> for Types {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let ts = &self.ts;
        let ts = ts.clone();
        call_value(each_job(ts.clone(), Rc::new(move |p0: crate::lower::model::OutTy| entered(once_job(move || {
            let t = p0;
            prism_rtl::Turn::More(Rc::new(Type { t: t.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_3230: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&each_3230, &Text::lit(", "))))
    }
}

/// `Start Types, x`: what the function value is when passed to `@Run`.
pub fn start_types(ts: Array<crate::lower::model::OutTy>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Types { ts })
}

/// ```prism
/// RefTypes: unbounded fn [OutTy] -> Text
/// ```
pub fn ref_types(ts: &Array<crate::lower::model::OutTy>) -> Text {
    crate::syntax::lexer::chars::join(&run_to_end(each_job(ts.clone(), Rc::new(move |p0: crate::lower::model::OutTy| entered(once_job(move || {
        let t = p0;
        call_then(start_type_(t.clone()), move |type__3338: Text| prism_rtl::Turn::Finished(Text::from(format!("&{}", &type__3338))))
    }))) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))
}

/// The step machine of `RefTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RefTypes: unbounded fn [OutTy] -> Text
/// ```
pub struct RefTypes {
    pub ts: Array<crate::lower::model::OutTy>,
}

impl prism_rtl::Job<Text> for RefTypes {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let ts = &self.ts;
        let ts = ts.clone();
        call_value(each_job(ts.clone(), Rc::new(move |p0: crate::lower::model::OutTy| entered(once_job(move || {
            let t = p0;
            call_then(start_type_(t.clone()), move |type__3338: Text| prism_rtl::Turn::Finished(Text::from(format!("&{}", &type__3338))))
        }))) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_3321: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&each_3321, &Text::lit(", "))))
    }
}

/// `Start RefTypes, x`: what the function value is when passed to `@Run`.
pub fn start_ref_types(ts: Array<crate::lower::model::OutTy>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RefTypes { ts })
}

/// ```prism
/// IsLoose: fn Ex -> Bool
/// ```
pub fn is_loose(x: &crate::lower::model::Ex) -> bool {
    match x {
        crate::lower::model::Ex::XBlock(m3663_0_0, inner) if (m3663_0_0.len() == 0) => is_loose(&**inner),
        crate::lower::model::Ex::XTyped(inner, _) => is_loose(&**inner),
        crate::lower::model::Ex::XBin(_, _, _) => true,
        crate::lower::model::Ex::XUnary(_, _) => true,
        crate::lower::model::Ex::XClosure(_, _, _) => true,
        crate::lower::model::Ex::XIf(_, _, _) => true,
        crate::lower::model::Ex::XMatch(_, _, _, _) => true,
        crate::lower::model::Ex::XChain(_, _, _, _) => true,
        crate::lower::model::Ex::XCast(_, _) => true,
        crate::lower::model::Ex::XRef(_) => true,
        crate::lower::model::Ex::XRefMut(_) => true,
        crate::lower::model::Ex::XDeref(_) => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Tight: unbounded fn Ex -> Text
/// ```
pub fn tight(x: &crate::lower::model::Ex) -> Text {
    if is_loose(x) { Text::from(format!("({})", &expression(x))) } else { expression(x) }
}

/// The step machine of `Tight`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Tight: unbounded fn Ex -> Text
/// ```
pub struct Tight {
    pub x: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for Tight {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let x = &self.x;
        if is_loose(x) {
            {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_4180: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_4180))))
            }
        } else {
            prism_rtl::Turn::More(Rc::new(Expression { x: x.clone() }))
        }
    }
}

/// `Start Tight, x`: what the function value is when passed to `@Run`.
pub fn start_tight(x: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Tight { x })
}

/// ```prism
/// Operand: unbounded fn Ex -> Text
/// ```
pub fn operand(x: &crate::lower::model::Ex) -> Text {
    match x {
        crate::lower::model::Ex::XBlock(m4264_0_0, inner) if (m4264_0_0.len() == 0) => operand(&**inner),
        crate::lower::model::Ex::XTyped(inner, _) => operand(&**inner),
        crate::lower::model::Ex::XBin(_, _, _) => Text::from(format!("({})", &expression(x))),
        crate::lower::model::Ex::XClosure(_, _, _) => Text::from(format!("({})", &expression(x))),
        crate::lower::model::Ex::XIf(_, _, _) => Text::from(format!("({})", &expression(x))),
        crate::lower::model::Ex::XCast(_, _) => Text::from(format!("({})", &expression(x))),
        _ => expression(x),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `Operand`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Operand: unbounded fn Ex -> Text
/// ```
pub struct Operand {
    pub x: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for Operand {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let x = &self.x;
        match x {
            crate::lower::model::Ex::XBlock(m4264_0_0, inner) if (m4264_0_0.len() == 0) => prism_rtl::Turn::More(Rc::new(Operand { x: (**inner).clone() })),
            crate::lower::model::Ex::XTyped(inner, _) => prism_rtl::Turn::More(Rc::new(Operand { x: (**inner).clone() })),
            crate::lower::model::Ex::XBin(_, _, _) => {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_4387: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_4387))))
            },
            crate::lower::model::Ex::XClosure(_, _, _) => {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_4443: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_4443))))
            },
            crate::lower::model::Ex::XIf(_, _, _) => {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_4494: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_4494))))
            },
            crate::lower::model::Ex::XCast(_, _) => {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_4539: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_4539))))
            },
            _ => prism_rtl::Turn::More(Rc::new(Expression { x: x.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start Operand, x`: what the function value is when passed to `@Run`.
pub fn start_operand(x: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Operand { x })
}

/// ```prism
/// Args: unbounded fn [Ex] -> Text
/// ```
pub fn args(xs: &Array<crate::lower::model::Ex>) -> Text {
    crate::syntax::lexer::chars::join(&run_to_end(each_job(xs.clone(), Rc::new(move |p0: crate::lower::model::Ex| entered(once_job(move || {
        let x = p0;
        prism_rtl::Turn::More(Rc::new(Expression { x: x.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))
}

/// The step machine of `Args`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Args: unbounded fn [Ex] -> Text
/// ```
pub struct Args {
    pub xs: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for Args {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let xs = &self.xs;
        let xs = xs.clone();
        call_value(each_job(xs.clone(), Rc::new(move |p0: crate::lower::model::Ex| entered(once_job(move || {
            let x = p0;
            prism_rtl::Turn::More(Rc::new(Expression { x: x.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_4635: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&each_4635, &Text::lit(", "))))
    }
}

/// `Start Args, x`: what the function value is when passed to `@Run`.
pub fn start_args(xs: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Args { xs })
}

/// ```prism
/// Expression: unbounded fn Ex -> Text
/// ```
pub fn expression(x: &crate::lower::model::Ex) -> Text {
    'm4724: {
        if let crate::lower::model::Ex::XVar(n) = x {
            break 'm4724 n.clone();
        }
        if let crate::lower::model::Ex::XPath(p_) = x {
            break 'm4724 p_.clone();
        }
        if let crate::lower::model::Ex::XSelf = x {
            break 'm4724 Text::lit("self");
        }
        if let crate::lower::model::Ex::XCx = x {
            break 'm4724 Text::lit("cx");
        }
        if let crate::lower::model::Ex::XConst(n) = x {
            break 'm4724 Text::from(format!("Self::{}", n));
        }
        if let crate::lower::model::Ex::XUnit = x {
            break 'm4724 Text::lit("()");
        }
        if let crate::lower::model::Ex::XNone = x {
            break 'm4724 Text::lit("None");
        }
        if let crate::lower::model::Ex::XBool(b) = x {
            break 'm4724 if *b { Text::lit("true") } else { Text::lit("false") };
        }
        if let crate::lower::model::Ex::XNat(d) = x {
            break 'm4724 if &len_text(d) <= &Nat::from(9u32) {
                Text::from(format!("Nat::from({}u32)", d))
            } else {
                if &len_text(d) <= &Nat::from(18u32) {
                    Text::from(format!("Nat::from_int(Int::from({}i64)).unwrap()", d))
                } else {
                    Text::from(format!("Nat::from_int(Int::parse(\"{}\").unwrap()).unwrap()", d))
                }
            };
        }
        if let crate::lower::model::Ex::XInt(d) = x {
            break 'm4724 if &len_text(&(if crate::syntax::lexer::chars::has_prefix(d, &Text::lit("-")) {
                crate::syntax::lexer::chars::after_first(d)
            } else {
                d.clone()
            })) <= &Nat::from(18u32) {
                Text::from(format!("Int::from({})", d))
            } else {
                Text::from(format!("Int::parse(\"{}\").unwrap()", d))
            };
        }
        if let crate::lower::model::Ex::XByte(d) = x {
            break 'm4724 Text::from(format!("{}u8", d));
        }
        if let crate::lower::model::Ex::XFloat(d) = x {
            break 'm4724 d.clone();
        }
        if let crate::lower::model::Ex::XIndex(n) = x {
            break 'm4724 Text::from(format!("{}", n));
        }
        if let crate::lower::model::Ex::XChar(c) = x {
            break 'm4724 Text::from(format!("\'{}\'", &crate::lower::expr::char_escape(c)));
        }
        if let crate::lower::model::Ex::XStr(t) = x {
            break 'm4724 Text::from(format!("\"{}\"", &crate::lower::expr::escape(t)));
        }
        if let crate::lower::model::Ex::XRegex(p_, f) = x {
            break 'm4724 Text::from(format!("{{ thread_local!(static R: Regex = Regex::lit(\"{}\", \"{}\")); R.with(Regex::clone) }}", &crate::lower::expr::escape(p_), &crate::lower::expr::escape(f)));
        }
        if let crate::lower::model::Ex::XReplacement(p_, r, f) = x {
            break 'm4724 Text::from(format!("{{ thread_local!(static R: RegexReplacement = RegexReplacement::lit(\"{}\", \"{}\", \"{}\")); R.with(RegexReplacement::clone) }}", &crate::lower::expr::escape(p_), &crate::lower::expr::escape(f), &crate::lower::expr::escape(r)));
        }
        if let crate::lower::model::Ex::XRef(y) = x {
            break 'm4724 Text::from(format!("&{}", &operand(&**y)));
        }
        if let crate::lower::model::Ex::XRefMut(y) = x {
            break 'm4724 Text::from(format!("&mut {}", &operand(&**y)));
        }
        if let crate::lower::model::Ex::XDeref(y) = x {
            break 'm4724 Text::from(format!("*{}", &operand(&**y)));
        }
        if let crate::lower::model::Ex::XTarget(y) = x {
            break 'm4724 Text::from(format!("(*{})", &expression(&**y)));
        }
        if let crate::lower::model::Ex::XClone(y) = x {
            break 'm4724 Text::from(format!("{}.clone()", &tight(&**y)));
        }
        if let crate::lower::model::Ex::XWeak(y) = x {
            break 'm4724 Text::from(format!("Rc::downgrade({})", &expression(&**y)));
        }
        if let crate::lower::model::Ex::XUpgrade(y) = x {
            break 'm4724 Text::from(format!("{}.upgrade()", &tight(&**y)));
        }
        if let crate::lower::model::Ex::XBreak(l, y) = x {
            break 'm4724 Text::from(format!("break {} {}", &label(l), &expression(&**y)));
        }
        if let crate::lower::model::Ex::XBreakLoop = x {
            break 'm4724 Text::lit("break");
        }
        if let crate::lower::model::Ex::XLater(y) = x {
            break 'm4724 Text::from(format!("Box::new(move |cx| {{ {}; Ok(()) }})", &expression(&**y)));
        }
        if let crate::lower::model::Ex::XFormatStr(parts) = x {
            break 'm4724 format_str(parts);
        }
        if let crate::lower::model::Ex::XIsCase(y, m4724_28_1) = x && (m4724_28_1.len() == 0) {
            break 'm4724 Text::lit("false");
        }
        if let crate::lower::model::Ex::XIsCase(y, cs) = x {
            break 'm4724 Text::from(format!("matches!({}, {})", &expression(&**y), &crate::syntax::lexer::chars::join(&each(cs, &(|c: &Text| Text::from(format!("{}(..)", c)))), &Text::lit(" | "))));
        }
        if let crate::lower::model::Ex::XRefusal(what) = x {
            break 'm4724 Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::expr::lowering_refusal(), &crate::lower::expr::escape(what)));
        }
        if let crate::lower::model::Ex::XUnreachable = x {
            break 'm4724 Text::lit("unreachable!()");
        }
        if let crate::lower::model::Ex::XCall(f, args_) = x {
            break 'm4724 Text::from(format!("{}({})", f, &args(args_)));
        }
        if let crate::lower::model::Ex::XApply(f, args_) = x {
            break 'm4724 Text::from(format!("{}({})", &tight(&**f), &args(args_)));
        }
        if let crate::lower::model::Ex::XMethod(r, m, args_) = x {
            break 'm4724 Text::from(format!("{}.{}({})", &tight(&**r), m, &args(args_)));
        }
        if let crate::lower::model::Ex::XBin(op, l, r) = x {
            break 'm4724 Text::from(format!("{} {} {}", &operand(&**l), op, &operand(&**r)));
        }
        if let crate::lower::model::Ex::XUnary(op, y) = x {
            break 'm4724 Text::from(format!("{}{}", op, &operand(&**y)));
        }
        if let crate::lower::model::Ex::XCtor(p_, args_) = x {
            break 'm4724 Text::from(format!("{}({})", p_, &args(args_)));
        }
        if let crate::lower::model::Ex::XRecord(p_, fs) = x {
            break 'm4724 Text::from(format!("{} {{ {} }}", p_, &crate::syntax::lexer::chars::join(&run_to_end(each_job(fs.clone(), Rc::new(move |p0: (Text, crate::lower::model::Ex)| entered(once_job(move || {
                let (f, v_) = p0;
                prism_rtl::Turn::More(Rc::new(FieldInit { f: f.clone(), ex1: v_.clone() }))
            }))) as Rc<dyn Fn((Text, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))));
        }
        if let crate::lower::model::Ex::XTuple(m4724_39_0) = x && (m4724_39_0.len() == 1) && let Some(one) = index(m4724_39_0, &Nat::from(0u32)) {
            break 'm4724 Text::from(format!("({},)", &expression(&one)));
        }
        if let crate::lower::model::Ex::XTuple(xs) = x {
            break 'm4724 Text::from(format!("({})", &args(xs)));
        }
        if let crate::lower::model::Ex::XVec(xs) = x {
            break 'm4724 Text::from(format!("vec![{}]", &args(xs)));
        }
        if let crate::lower::model::Ex::XText(t) = x {
            break 'm4724 Text::from(format!("Text::lit(\"{}\")", &crate::lower::expr::escape(t)));
        }
        if let crate::lower::model::Ex::XFormat(parts) = x {
            break 'm4724 format(parts);
        }
        if let crate::lower::model::Ex::XMatch(s, arms_, fallback, _) = x {
            break 'm4724 crate::emit::rust::templates::items::match_block(&expression(&**s), &arms(arms_, fallback));
        }
        if let crate::lower::model::Ex::XChain(label_, s, arms_, _) = x {
            break 'm4724 chain(&label(label_), &**s, arms_);
        }
        if let crate::lower::model::Ex::XIf(c, t, e) = x {
            break 'm4724 if_expression(&**c, &**t, &**e);
        }
        if let crate::lower::model::Ex::XBlock(m4724_47_0, e) = x && (m4724_47_0.len() == 0) {
            break 'm4724 expression(&**e);
        }
        if let crate::lower::model::Ex::XBlock(dos, e) = x {
            break 'm4724 crate::emit::rust::templates::items::block(&statements(dos), &expression(&**e));
        }
        if let crate::lower::model::Ex::XLabeled(label_, dos, e, _) = x {
            break 'm4724 crate::emit::rust::templates::items::labeled(&label(label_), &statements(dos), &expression(&**e));
        }
        if let crate::lower::model::Ex::XClosure(mv, ps, body) = x {
            break 'm4724 Text::from(format!("{}|{}| {}", &(if *mv { Text::lit("move ") } else { Text::lit("") }), &crate::syntax::lexer::chars::join(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                let p_ = p0;
                prism_rtl::Turn::More(Rc::new(Pattern_ { p_: p_.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", ")), &expression(&**body)));
        }
        if let crate::lower::model::Ex::XTry(y) = x {
            break 'm4724 Text::from(format!("{}?", &tight(&**y)));
        }
        if let crate::lower::model::Ex::XField(r, f) = x {
            break 'm4724 Text::from(format!("{}.{}", &tight(&**r), f));
        }
        if let crate::lower::model::Ex::XPart(r, k) = x {
            break 'm4724 Text::from(format!("{}.{}", &tight(&**r), k));
        }
        if let crate::lower::model::Ex::XDecode(t, y) = x {
            break 'm4724 Text::from(format!("{}::from_pod({})?", &decode_head(t), &expression(&**y)));
        }
        if let crate::lower::model::Ex::XCast(y, t) = x {
            break 'm4724 Text::from(format!("{} as {}", &tight(&**y), &type_(t)));
        }
        if let crate::lower::model::Ex::XTyped(y, _) = x {
            break 'm4724 expression(&**y);
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `Expression`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Expression: unbounded fn Ex -> Text
/// ```
pub struct Expression {
    pub x: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for Expression {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let x = &self.x;
        'm4724: {
            if let crate::lower::model::Ex::XVar(n) = x {
                break 'm4724 prism_rtl::Turn::Finished(n.clone());
            }
            if let crate::lower::model::Ex::XPath(p_) = x {
                break 'm4724 prism_rtl::Turn::Finished(p_.clone());
            }
            if let crate::lower::model::Ex::XSelf = x {
                break 'm4724 prism_rtl::Turn::Finished(Text::lit("self"));
            }
            if let crate::lower::model::Ex::XCx = x {
                break 'm4724 prism_rtl::Turn::Finished(Text::lit("cx"));
            }
            if let crate::lower::model::Ex::XConst(n) = x {
                break 'm4724 prism_rtl::Turn::Finished(Text::from(format!("Self::{}", n)));
            }
            if let crate::lower::model::Ex::XUnit = x {
                break 'm4724 prism_rtl::Turn::Finished(Text::lit("()"));
            }
            if let crate::lower::model::Ex::XNone = x {
                break 'm4724 prism_rtl::Turn::Finished(Text::lit("None"));
            }
            if let crate::lower::model::Ex::XBool(b) = x {
                break 'm4724 if *b {
                    prism_rtl::Turn::Finished(Text::lit("true"))
                } else {
                    prism_rtl::Turn::Finished(Text::lit("false"))
                };
            }
            if let crate::lower::model::Ex::XNat(d) = x {
                break 'm4724 if &len_text(d) <= &Nat::from(9u32) {
                    prism_rtl::Turn::Finished(Text::from(format!("Nat::from({}u32)", d)))
                } else {
                    if &len_text(d) <= &Nat::from(18u32) {
                        prism_rtl::Turn::Finished(Text::from(format!("Nat::from_int(Int::from({}i64)).unwrap()", d)))
                    } else {
                        prism_rtl::Turn::Finished(Text::from(format!("Nat::from_int(Int::parse(\"{}\").unwrap()).unwrap()", d)))
                    }
                };
            }
            if let crate::lower::model::Ex::XInt(d) = x {
                break 'm4724 if &len_text(&(if crate::syntax::lexer::chars::has_prefix(d, &Text::lit("-")) {
                    crate::syntax::lexer::chars::after_first(d)
                } else {
                    d.clone()
                })) <= &Nat::from(18u32) {
                    prism_rtl::Turn::Finished(Text::from(format!("Int::from({})", d)))
                } else {
                    prism_rtl::Turn::Finished(Text::from(format!("Int::parse(\"{}\").unwrap()", d)))
                };
            }
            if let crate::lower::model::Ex::XByte(d) = x {
                break 'm4724 prism_rtl::Turn::Finished(Text::from(format!("{}u8", d)));
            }
            if let crate::lower::model::Ex::XFloat(d) = x {
                break 'm4724 prism_rtl::Turn::Finished(d.clone());
            }
            if let crate::lower::model::Ex::XIndex(n) = x {
                break 'm4724 prism_rtl::Turn::Finished(Text::from(format!("{}", n)));
            }
            if let crate::lower::model::Ex::XChar(c) = x {
                break 'm4724 prism_rtl::Turn::Finished(Text::from(format!("\'{}\'", &crate::lower::expr::char_escape(c))));
            }
            if let crate::lower::model::Ex::XStr(t) = x {
                break 'm4724 prism_rtl::Turn::Finished(Text::from(format!("\"{}\"", &crate::lower::expr::escape(t))));
            }
            if let crate::lower::model::Ex::XRegex(p_, f) = x {
                break 'm4724 prism_rtl::Turn::Finished(Text::from(format!("{{ thread_local!(static R: Regex = Regex::lit(\"{}\", \"{}\")); R.with(Regex::clone) }}", &crate::lower::expr::escape(p_), &crate::lower::expr::escape(f))));
            }
            if let crate::lower::model::Ex::XReplacement(p_, r, f) = x {
                break 'm4724 prism_rtl::Turn::Finished(Text::from(format!("{{ thread_local!(static R: RegexReplacement = RegexReplacement::lit(\"{}\", \"{}\", \"{}\")); R.with(RegexReplacement::clone) }}", &crate::lower::expr::escape(p_), &crate::lower::expr::escape(f), &crate::lower::expr::escape(r))));
            }
            if let crate::lower::model::Ex::XRef(y) = x {
                break 'm4724 {
                    let y = (**y).clone();
                    call_then(start_operand(y.clone()), move |operand_5813: Text| prism_rtl::Turn::Finished(Text::from(format!("&{}", &operand_5813))))
                };
            }
            if let crate::lower::model::Ex::XRefMut(y) = x {
                break 'm4724 {
                    let y = (**y).clone();
                    call_then(start_operand(y.clone()), move |operand_5847: Text| prism_rtl::Turn::Finished(Text::from(format!("&mut {}", &operand_5847))))
                };
            }
            if let crate::lower::model::Ex::XDeref(y) = x {
                break 'm4724 {
                    let y = (**y).clone();
                    call_then(start_operand(y.clone()), move |operand_5876: Text| prism_rtl::Turn::Finished(Text::from(format!("*{}", &operand_5876))))
                };
            }
            if let crate::lower::model::Ex::XTarget(y) = x {
                break 'm4724 {
                    let y = (**y).clone();
                    call_then(start_expression(y.clone()), move |expression_5907: Text| prism_rtl::Turn::Finished(Text::from(format!("(*{})", &expression_5907))))
                };
            }
            if let crate::lower::model::Ex::XClone(y) = x {
                break 'm4724 {
                    let y = (**y).clone();
                    call_then(start_tight(y.clone()), move |tight_5939: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.clone()", &tight_5939))))
                };
            }
            if let crate::lower::model::Ex::XWeak(y) = x {
                break 'm4724 {
                    let y = (**y).clone();
                    call_then(start_expression(y.clone()), move |expression_5986: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc::downgrade({})", &expression_5986))))
                };
            }
            if let crate::lower::model::Ex::XUpgrade(y) = x {
                break 'm4724 {
                    let y = (**y).clone();
                    call_then(start_tight(y.clone()), move |tight_6020: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.upgrade()", &tight_6020))))
                };
            }
            if let crate::lower::model::Ex::XBreak(l, y) = x {
                break 'm4724 {
                    let l = l.clone();
                    let y = (**y).clone();
                    call_then(start_expression(y.clone()), move |expression_6075: Text| prism_rtl::Turn::Finished(Text::from(format!("break {} {}", &label(&l), &expression_6075))))
                };
            }
            if let crate::lower::model::Ex::XBreakLoop = x {
                break 'm4724 prism_rtl::Turn::Finished(Text::lit("break"));
            }
            if let crate::lower::model::Ex::XLater(y) = x {
                break 'm4724 {
                    let y = (**y).clone();
                    call_then(start_expression(y.clone()), move |expression_6152: Text| prism_rtl::Turn::Finished(Text::from(format!("Box::new(move |cx| {{ {}; Ok(()) }})", &expression_6152))))
                };
            }
            if let crate::lower::model::Ex::XFormatStr(parts) = x {
                break 'm4724 prism_rtl::Turn::More(Rc::new(FormatStr { parts: parts.clone() }));
            }
            if let crate::lower::model::Ex::XIsCase(y, m4724_28_1) = x && (m4724_28_1.len() == 0) {
                break 'm4724 prism_rtl::Turn::Finished(Text::lit("false"));
            }
            if let crate::lower::model::Ex::XIsCase(y, cs) = x {
                break 'm4724 {
                    let cs = cs.clone();
                    let y = (**y).clone();
                    call_then(start_expression(y.clone()), move |expression_6276: Text| prism_rtl::Turn::Finished(Text::from(format!("matches!({}, {})", &expression_6276, &crate::syntax::lexer::chars::join(&each(&cs, &(|c: &Text| Text::from(format!("{}(..)", c)))), &Text::lit(" | "))))))
                };
            }
            if let crate::lower::model::Ex::XRefusal(what) = x {
                break 'm4724 prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::expr::lowering_refusal(), &crate::lower::expr::escape(what))));
            }
            if let crate::lower::model::Ex::XUnreachable = x {
                break 'm4724 prism_rtl::Turn::Finished(Text::lit("unreachable!()"));
            }
            if let crate::lower::model::Ex::XCall(f, args_) = x {
                break 'm4724 {
                    let args_ = args_.clone();
                    let f = f.clone();
                    call_then(start_args(args_.clone()), move |args_6465: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &f, &args_6465))))
                };
            }
            if let crate::lower::model::Ex::XApply(f, args_) = x {
                break 'm4724 {
                    let args_ = args_.clone();
                    let f = (**f).clone();
                    call_then(start_tight(f.clone()), move |tight_6500: Text| call_then(start_args(args_.clone()), move |args_6510: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &tight_6500, &args_6510)))))
                };
            }
            if let crate::lower::model::Ex::XMethod(r, m, args_) = x {
                break 'm4724 {
                    let args_ = args_.clone();
                    let m = m.clone();
                    let r = (**r).clone();
                    call_then(start_tight(r.clone()), move |tight_6549: Text| call_then(start_args(args_.clone()), move |args_6563: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.{}({})", &tight_6549, &m, &args_6563)))))
                };
            }
            if let crate::lower::model::Ex::XBin(op, l, r) = x {
                break 'm4724 {
                    let l = (**l).clone();
                    let op = op.clone();
                    let r = (**r).clone();
                    call_then(start_operand(l.clone()), move |operand_6597: Text| call_then(start_operand(r.clone()), move |operand_6614: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {} {}", &operand_6597, &op, &operand_6614)))))
                };
            }
            if let crate::lower::model::Ex::XUnary(op, y) = x {
                break 'm4724 {
                    let op = op.clone();
                    let y = (**y).clone();
                    call_then(start_operand(y.clone()), move |operand_6650: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &op, &operand_6650))))
                };
            }
            if let crate::lower::model::Ex::XCtor(p_, args_) = x {
                break 'm4724 {
                    let args_ = args_.clone();
                    let p_ = p_.clone();
                    call_then(start_args(args_.clone()), move |args_6687: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &p_, &args_6687))))
                };
            }
            if let crate::lower::model::Ex::XRecord(p_, fs) = x {
                break 'm4724 {
                    let fs = fs.clone();
                    let p_ = p_.clone();
                    call_value(each_job(fs.clone(), Rc::new(move |p0: (Text, crate::lower::model::Ex)| entered(once_job(move || {
                        let (f, v_) = p0;
                        prism_rtl::Turn::More(Rc::new(FieldInit { f: f.clone(), ex1: v_.clone() }))
                    }))) as Rc<dyn Fn((Text, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_6734: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{} {{ {} }}", &p_, &crate::syntax::lexer::chars::join(&each_6734, &Text::lit(", "))))))
                };
            }
            if let crate::lower::model::Ex::XTuple(m4724_39_0) = x && (m4724_39_0.len() == 1) && let Some(one) = index(m4724_39_0, &Nat::from(0u32)) {
                break 'm4724 call_then(start_expression(one.clone()), move |expression_6805: Text| prism_rtl::Turn::Finished(Text::from(format!("({},)", &expression_6805))));
            }
            if let crate::lower::model::Ex::XTuple(xs) = x {
                break 'm4724 {
                    let xs = xs.clone();
                    call_then(start_args(xs.clone()), move |args_6842: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &args_6842))))
                };
            }
            if let crate::lower::model::Ex::XVec(xs) = x {
                break 'm4724 {
                    let xs = xs.clone();
                    call_then(start_args(xs.clone()), move |args_6873: Text| prism_rtl::Turn::Finished(Text::from(format!("vec![{}]", &args_6873))))
                };
            }
            if let crate::lower::model::Ex::XText(t) = x {
                break 'm4724 prism_rtl::Turn::Finished(Text::from(format!("Text::lit(\"{}\")", &crate::lower::expr::escape(t))));
            }
            if let crate::lower::model::Ex::XFormat(parts) = x {
                break 'm4724 prism_rtl::Turn::More(Rc::new(Format { parts: parts.clone() }));
            }
            if let crate::lower::model::Ex::XMatch(s, arms_, fallback, _) = x {
                break 'm4724 {
                    let arms_ = arms_.clone();
                    let fallback = *fallback;
                    let s = (**s).clone();
                    call_then(start_expression(s.clone()), move |expression_7007: Text| call_then(start_arms(arms_.clone(), fallback), move |arms_7023: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::match_block(&expression_7007, &arms_7023))))
                };
            }
            if let crate::lower::model::Ex::XChain(label_, s, arms_, _) = x {
                break 'm4724 prism_rtl::Turn::More(Rc::new(Chain { label_: label(label_), s: (**s).clone(), arms_: arms_.clone() }));
            }
            if let crate::lower::model::Ex::XIf(c, t, e) = x {
                break 'm4724 prism_rtl::Turn::More(Rc::new(IfExpression { c: (**c).clone(), t: (**t).clone(), e: (**e).clone() }));
            }
            if let crate::lower::model::Ex::XBlock(m4724_47_0, e) = x && (m4724_47_0.len() == 0) {
                break 'm4724 prism_rtl::Turn::More(Rc::new(Expression { x: (**e).clone() }));
            }
            if let crate::lower::model::Ex::XBlock(dos, e) = x {
                break 'm4724 {
                    let dos = dos.clone();
                    let e = (**e).clone();
                    call_then(start_statements(dos.clone()), move |statements_7205: Text| call_then(start_expression(e.clone()), move |expression_7223: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::block(&statements_7205, &expression_7223))))
                };
            }
            if let crate::lower::model::Ex::XLabeled(label_, dos, e, _) = x {
                break 'm4724 {
                    let dos = dos.clone();
                    let e = (**e).clone();
                    let label_ = label_.clone();
                    call_then(start_statements(dos.clone()), move |statements_7297: Text| call_then(start_expression(e.clone()), move |expression_7315: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::labeled(&label(&label_), &statements_7297, &expression_7315))))
                };
            }
            if let crate::lower::model::Ex::XClosure(mv, ps, body) = x {
                break 'm4724 {
                    let body = (**body).clone();
                    let mv = *mv;
                    let ps = ps.clone();
                    call_value(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                        let p_ = p0;
                        prism_rtl::Turn::More(Rc::new(Pattern_ { p_: p_.clone() }))
                    }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_7390: Array<Text>| call_then(start_expression(body.clone()), move |expression_7424: Text| prism_rtl::Turn::Finished(Text::from(format!("{}|{}| {}", &(if mv { Text::lit("move ") } else { Text::lit("") }), &crate::syntax::lexer::chars::join(&each_7390, &Text::lit(", ")), &expression_7424)))))
                };
            }
            if let crate::lower::model::Ex::XTry(y) = x {
                break 'm4724 {
                    let y = (**y).clone();
                    call_then(start_tight(y.clone()), move |tight_7456: Text| prism_rtl::Turn::Finished(Text::from(format!("{}?", &tight_7456))))
                };
            }
            if let crate::lower::model::Ex::XField(r, f) = x {
                break 'm4724 {
                    let f = f.clone();
                    let r = (**r).clone();
                    call_then(start_tight(r.clone()), move |tight_7486: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.{}", &tight_7486, &f))))
                };
            }
            if let crate::lower::model::Ex::XPart(r, k) = x {
                break 'm4724 {
                    let k = k.clone();
                    let r = (**r).clone();
                    call_then(start_tight(r.clone()), move |tight_7518: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.{}", &tight_7518, &k))))
                };
            }
            if let crate::lower::model::Ex::XDecode(t, y) = x {
                break 'm4724 {
                    let t = t.clone();
                    let y = (**y).clone();
                    call_then(start_decode_head(t.clone()), move |decode_head_7552: Text| call_then(start_expression(y.clone()), move |expression_7577: Text| prism_rtl::Turn::Finished(Text::from(format!("{}::from_pod({})?", &decode_head_7552, &expression_7577)))))
                };
            }
            if let crate::lower::model::Ex::XCast(y, t) = x {
                break 'm4724 {
                    let t = t.clone();
                    let y = (**y).clone();
                    call_then(start_tight(y.clone()), move |tight_7612: Text| call_then(start_type_(t.clone()), move |type__7625: Text| prism_rtl::Turn::Finished(Text::from(format!("{} as {}", &tight_7612, &type__7625)))))
                };
            }
            if let crate::lower::model::Ex::XTyped(y, _) = x {
                break 'm4724 prism_rtl::Turn::More(Rc::new(Expression { x: (**y).clone() }));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start Expression, x`: what the function value is when passed to `@Run`.
pub fn start_expression(x: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Expression { x })
}

/// ```prism
/// FieldInit: unbounded fn Text, Ex -> Text
/// ```
pub fn field_init(f: &Text, ex1: &crate::lower::model::Ex) -> Text {
    match ex1 {
        crate::lower::model::Ex::XVar(v_) => if v_ == f { f.clone() } else { Text::from(format!("{}: {}", f, v_)) },
        v_ => Text::from(format!("{}: {}", f, &expression(v_))),
    }
}

/// The step machine of `FieldInit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldInit: unbounded fn Text, Ex -> Text
/// ```
pub struct FieldInit {
    pub f: Text,
    pub ex1: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for FieldInit {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f = &self.f;
        let ex1 = &self.ex1;
        match ex1 {
            crate::lower::model::Ex::XVar(v_) => if v_ == f {
                prism_rtl::Turn::Finished(f.clone())
            } else {
                prism_rtl::Turn::Finished(Text::from(format!("{}: {}", f, v_)))
            },
            v_ => {
                let f = f.clone();
                let v_ = v_.clone();
                call_then(start_expression(v_.clone()), move |expression_7795: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f, &expression_7795))))
            },
        }
    }
}

/// `Start FieldInit, x`: what the function value is when passed to `@Run`.
pub fn start_field_init(f: Text, ex1: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FieldInit { f, ex1 })
}

/// ```prism
/// DecodeHead: unbounded fn OutTy -> Text
/// ```
pub fn decode_head(t: &crate::lower::model::OutTy) -> Text {
    match t {
        crate::lower::model::OutTy::OutNamed(n, m7868_0_1) if (m7868_0_1.len() == 0) => n.clone(),
        crate::lower::model::OutTy::OutNat => Text::lit("Nat"),
        crate::lower::model::OutTy::OutInt => Text::lit("Int"),
        crate::lower::model::OutTy::OutText => Text::lit("Text"),
        _ => Text::from(format!("<{}>", &type_(t))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `DecodeHead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DecodeHead: unbounded fn OutTy -> Text
/// ```
pub struct DecodeHead {
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for DecodeHead {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        match t {
            crate::lower::model::OutTy::OutNamed(n, m7868_0_1) if (m7868_0_1.len() == 0) => prism_rtl::Turn::Finished(n.clone()),
            crate::lower::model::OutTy::OutNat => prism_rtl::Turn::Finished(Text::lit("Nat")),
            crate::lower::model::OutTy::OutInt => prism_rtl::Turn::Finished(Text::lit("Int")),
            crate::lower::model::OutTy::OutText => prism_rtl::Turn::Finished(Text::lit("Text")),
            _ => {
                let t = t.clone();
                call_then(start_type_(t.clone()), move |type__7975: Text| prism_rtl::Turn::Finished(Text::from(format!("<{}>", &type__7975))))
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start DecodeHead, x`: what the function value is when passed to `@Run`.
pub fn start_decode_head(t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(DecodeHead { t })
}

/// ```prism
/// Label: fn Text -> Text
/// ```
pub fn label(l: &Text) -> Text {
    if crate::syntax::lexer::chars::has_prefix(l, &Text::lit("\'")) {
        l.clone()
    } else {
        Text::from(format!("\'{}", l))
    }
}

/// ```prism
/// Format: unbounded fn [Ex] -> Text
/// ```
pub fn format(parts: &Array<crate::lower::model::Ex>) -> Text {
    let lit = concat(&each(parts, &(|p_: &crate::lower::model::Ex| format_piece(p_))));
    let vals = filter(parts, &(|p_: &crate::lower::model::Ex| !is_text(p_)));
    if &len(&vals) == &Nat::from(0u32) {
        Text::from(format!("Text::lit(\"{}\")", &crate::lower::expr::escape(&concat(&each(parts, &(|p_: &crate::lower::model::Ex| plain_piece(p_)))))))
    } else {
        Text::from(format!("Text::from(format!(\"{}\", {}))", &lit, &args(&vals)))
    }
}

/// The step machine of `Format`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Format: unbounded fn [Ex] -> Text
/// ```
pub struct Format {
    pub parts: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for Format {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let parts = &self.parts;
        let lit = concat(&each(parts, &(|p_: &crate::lower::model::Ex| format_piece(p_))));
        let vals = filter(parts, &(|p_: &crate::lower::model::Ex| !is_text(p_)));
        if &len(&vals) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished(Text::from(format!("Text::lit(\"{}\")", &crate::lower::expr::escape(&concat(&each(parts, &(|p_: &crate::lower::model::Ex| plain_piece(p_))))))))
        } else {
            call_then(start_args(vals.clone()), move |args_8490: Text| prism_rtl::Turn::Finished(Text::from(format!("Text::from(format!(\"{}\", {}))", &lit, &args_8490))))
        }
    }
}

/// `Start Format, x`: what the function value is when passed to `@Run`.
pub fn start_format(parts: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Format { parts })
}

/// ```prism
/// PlainPiece: fn Ex -> Text
/// ```
pub fn plain_piece(ex0: &crate::lower::model::Ex) -> Text {
    match ex0 {
        crate::lower::model::Ex::XText(t) => t.clone(),
        other => Text::lit(""),
    }
}

/// ```prism
/// FormatStr: unbounded fn [Ex] -> Text
/// ```
pub fn format_str(parts: &Array<crate::lower::model::Ex>) -> Text {
    let lit = concat(&each(parts, &(|p_: &crate::lower::model::Ex| str_piece(p_))));
    let vals = filter(parts, &(|p_: &crate::lower::model::Ex| !is_text(p_) && !is_var(p_)));
    if &len(&vals) == &Nat::from(0u32) {
        Text::from(format!("\"{}\"", &lit))
    } else {
        Text::from(format!("format!(\"{}\", {})", &lit, &args(&vals)))
    }
}

/// The step machine of `FormatStr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FormatStr: unbounded fn [Ex] -> Text
/// ```
pub struct FormatStr {
    pub parts: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for FormatStr {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let parts = &self.parts;
        let lit = concat(&each(parts, &(|p_: &crate::lower::model::Ex| str_piece(p_))));
        let vals = filter(parts, &(|p_: &crate::lower::model::Ex| !is_text(p_) && !is_var(p_)));
        if &len(&vals) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished(Text::from(format!("\"{}\"", &lit)))
        } else {
            call_then(start_args(vals.clone()), move |args_8955: Text| prism_rtl::Turn::Finished(Text::from(format!("format!(\"{}\", {})", &lit, &args_8955))))
        }
    }
}

/// `Start FormatStr, x`: what the function value is when passed to `@Run`.
pub fn start_format_str(parts: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FormatStr { parts })
}

/// ```prism
/// IsVar: fn Ex -> Bool
/// ```
pub fn is_var(ex0: &crate::lower::model::Ex) -> bool {
    match ex0 {
        crate::lower::model::Ex::XVar(_) => true,
        other => false,
    }
}

/// ```prism
/// StrPiece: fn Ex -> Text
/// ```
pub fn str_piece(ex0: &crate::lower::model::Ex) -> Text {
    match ex0 {
        crate::lower::model::Ex::XVar(n) => Text::from(format!("{{{}}}", n)),
        other => format_piece(other),
    }
}

/// ```prism
/// IsText: fn Ex -> Bool
/// ```
pub fn is_text(ex0: &crate::lower::model::Ex) -> bool {
    match ex0 {
        crate::lower::model::Ex::XText(_) => true,
        other => false,
    }
}

/// ```prism
/// FormatPiece: fn Ex -> Text
/// ```
pub fn format_piece(ex0: &crate::lower::model::Ex) -> Text {
    match ex0 {
        crate::lower::model::Ex::XText(t) => format_escape(&crate::lower::expr::escape(t)),
        other => Text::lit("{}"),
    }
}

/// ```prism
/// FormatEscape: fn Text -> Text
/// ```
pub fn format_escape(t: &Text) -> Text {
    crate::syntax::lexer::chars::map_chars(t, &(Rc::new(move |p0: Text| once_job(move || {
        let c = p0;
        prism_rtl::Turn::Finished(format_escape_char(&c))
    })) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>))
}

/// ```prism
/// FormatEscapeChar: fn Text -> Text
/// ```
pub fn format_escape_char(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("{")) => Text::lit("{{"),
        c1_0 if (c1_0 == &Text::lit("}")) => Text::lit("}}"),
        c => c.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IfExpression: unbounded fn Ex, Ex, Ex -> Text
/// ```
pub fn if_expression(c: &crate::lower::model::Ex, t: &crate::lower::model::Ex, e: &crate::lower::model::Ex) -> Text {
    let ct = expression(c);
    let tt = expression(t);
    let et = expression(e);
    let short = !crate::syntax::lexer::chars::contains(&Text::from(format!("{}{}", &tt, &et)), &Text::lit("\n")) && (&len_text(&Text::from(format!("{}{}{}", &ct, &tt, &et))) < &Nat::from(70u32));
    if short {
        Text::from(format!("if {} {{ {} }} else {{ {} }}", &ct, &tt, &et))
    } else {
        crate::emit::rust::templates::items::if_(&ct, &tt, &et)
    }
}

/// The step machine of `IfExpression`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IfExpression: unbounded fn Ex, Ex, Ex -> Text
/// ```
pub struct IfExpression {
    pub c: crate::lower::model::Ex,
    pub t: crate::lower::model::Ex,
    pub e: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for IfExpression {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let c = &self.c;
        let t = &self.t;
        let e = &self.e;
        let c = c.clone();
        let e = e.clone();
        let t = t.clone();
        call_then(start_expression(c.clone()), move |expression_9693: Text| {
            let ct = expression_9693;
            call_then(start_expression(t.clone()), move |expression_9719: Text| {
                let tt = expression_9719;
                call_then(start_expression(e.clone()), move |expression_9745: Text| {
                    let et = expression_9745;
                    let short = !crate::syntax::lexer::chars::contains(&Text::from(format!("{}{}", &tt, &et)), &Text::lit("\n")) && (&len_text(&Text::from(format!("{}{}{}", &ct, &tt, &et))) < &Nat::from(70u32));
                    if short {
                        prism_rtl::Turn::Finished(Text::from(format!("if {} {{ {} }} else {{ {} }}", &ct, &tt, &et)))
                    } else {
                        prism_rtl::Turn::Finished(crate::emit::rust::templates::items::if_(&ct, &tt, &et))
                    }
                })
            })
        })
    }
}

/// `Start IfExpression, x`: what the function value is when passed to `@Run`.
pub fn start_if_expression(c: crate::lower::model::Ex, t: crate::lower::model::Ex, e: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(IfExpression { c, t, e })
}

/// ```prism
/// Arms: unbounded fn [XArm], Bool -> Text
/// ```
pub fn arms(arms_: &Array<crate::lower::model::XArm>, fallback: &bool) -> Text {
    let lines = run_to_end(each_job(arms_.clone(), Rc::new(move |p0: crate::lower::model::XArm| entered(once_job(move || {
        let a = p0;
        prism_rtl::Turn::More(Rc::new(Arm { a: a.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>>>));
    let all = if *fallback {
        push(&lines, &Text::lit("_ => unreachable!(\"no arm matched\"),"))
    } else {
        lines.clone()
    };
    crate::syntax::lexer::chars::join(&all, &Text::lit("\n"))
}

/// The step machine of `Arms`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Arms: unbounded fn [XArm], Bool -> Text
/// ```
pub struct Arms {
    pub arms_: Array<crate::lower::model::XArm>,
    pub fallback: bool,
}

impl prism_rtl::Job<Text> for Arms {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let arms_ = &self.arms_;
        let fallback = &self.fallback;
        let arms_ = arms_.clone();
        let fallback = *fallback;
        call_value(each_job(arms_.clone(), Rc::new(move |p0: crate::lower::model::XArm| entered(once_job(move || {
            let a = p0;
            prism_rtl::Turn::More(Rc::new(Arm { a: a.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_10076: Array<Text>| {
            let lines = each_10076;
            let all = if fallback {
                push(&lines, &Text::lit("_ => unreachable!(\"no arm matched\"),"))
            } else {
                lines.clone()
            };
            prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&all, &Text::lit("\n")))
        })
    }
}

/// `Start Arms, x`: what the function value is when passed to `@Run`.
pub fn start_arms(arms_: Array<crate::lower::model::XArm>, fallback: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Arms { arms_, fallback })
}

/// ```prism
/// Arm: unbounded fn XArm -> Text
/// ```
pub fn arm(a: &crate::lower::model::XArm) -> Text {
    let guard = if &len(&a.conds) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" if {}", &crate::syntax::lexer::chars::join(&run_to_end(each_job(a.conds.clone(), Rc::new(move |p0: crate::lower::model::Cc| entered(once_job(move || {
            let c = p0;
            prism_rtl::Turn::More(Rc::new(Condition { cc0: c.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(" && "))))
    };
    let body = expression(&a.body);
    Text::from(format!("{}{} => {},", &pattern(&a.pat), &guard, &body))
}

/// The step machine of `Arm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Arm: unbounded fn XArm -> Text
/// ```
pub struct Arm {
    pub a: crate::lower::model::XArm,
}

impl prism_rtl::Job<Text> for Arm {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let a = &self.a;
        let guard = if &len(&a.conds) == &Nat::from(0u32) {
            Text::lit("")
        } else {
            Text::from(format!(" if {}", &crate::syntax::lexer::chars::join(&run_to_end(each_job(a.conds.clone(), Rc::new(move |p0: crate::lower::model::Cc| entered(once_job(move || {
                let c = p0;
                prism_rtl::Turn::More(Rc::new(Condition { cc0: c.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(" && "))))
        };
        let a = a.clone();
        call_then(start_expression(a.body.clone()), move |expression_10368: Text| {
            let body = expression_10368;
            call_then(start_pattern(a.pat.clone()), move |pattern_10392: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{} => {},", &pattern_10392, &guard, &body))))
        })
    }
}

/// `Start Arm, x`: what the function value is when passed to `@Run`.
pub fn start_arm(a: crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Arm { a })
}

/// ```prism
/// Condition: unbounded fn Cc -> Text
/// ```
pub fn condition(cc0: &crate::lower::model::Cc) -> Text {
    match cc0 {
        crate::lower::model::Cc::CcIf(x) => operand(x),
        crate::lower::model::Cc::CcLet(p_, x) => Text::from(format!("let {} = {}", &pattern(p_), &expression(x))),
    }
}

/// The step machine of `Condition`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Condition: unbounded fn Cc -> Text
/// ```
pub struct Condition {
    pub cc0: crate::lower::model::Cc,
}

impl prism_rtl::Job<Text> for Condition {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cc0 = &self.cc0;
        match cc0 {
            crate::lower::model::Cc::CcIf(x) => prism_rtl::Turn::More(Rc::new(Operand { x: x.clone() })),
            crate::lower::model::Cc::CcLet(p_, x) => {
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_pattern(p_.clone()), move |pattern_10530: Text| call_then(start_expression(x.clone()), move |expression_10544: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {}", &pattern_10530, &expression_10544)))))
            },
        }
    }
}

/// `Start Condition, x`: what the function value is when passed to `@Run`.
pub fn start_condition(cc0: crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Condition { cc0 })
}

/// ```prism
/// Chain: unbounded fn Text, Ex, [XArm] -> Text
/// ```
pub fn chain(label_: &Text, s: &crate::lower::model::Ex, arms_: &Array<crate::lower::model::XArm>) -> Text {
    let in_place = match s {
        crate::lower::model::Ex::XRef(y) => is_bound(&**y),
        _ => is_bound(s),
    };
    let (bind, scrut) = if in_place {
        (Array::new(), expression(s))
    } else {
        (Array::from(vec![Text::from(format!("let scrutinee = {};", &expression(s)))]), Text::lit("scrutinee"))
    };
    let n = len(arms_);
    let lines = run_to_end(each_job(crate::check::errors::range0(&n), {
        let arms_ = arms_.clone();
        let scrut = scrut.clone();
        let label_ = label_.clone();
        Rc::new(move |p0: Nat| {
            let arms_ = arms_.clone();
            let scrut = scrut.clone();
            let label_ = label_.clone();
            entered(once_job(move || {
                let i = p0;
                {
                    let a = or(&index(&arms_, &i), &crate::lower::model::XArm { pat: crate::lower::model::Pa::PaWild, conds: Array::new(), body: crate::lower::model::Ex::XUnit });
                    let catch_all = (&a.pat == &crate::lower::model::Pa::PaWild) && (&len(&a.conds) == &Nat::from(0u32));
                    if catch_all {
                        prism_rtl::Turn::More(Rc::new(Expression { x: a.body.clone() }))
                    } else {
                        call_then(start_pattern(a.pat.clone()), move |pattern_11257: Text| call_value(each_job(a.conds.clone(), Rc::new(move |p0: crate::lower::model::Cc| entered(once_job(move || {
                            let c = p0;
                            prism_rtl::Turn::More(Rc::new(Condition { cc0: c.clone() }))
                        }))) as Rc<dyn Fn(crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_11287: Array<Text>| {
                            let head = crate::syntax::lexer::chars::join(&append(&Array::from(vec![Text::from(format!("let {} = {}", &pattern_11257, &scrut))]), &each_11287), &Text::lit(" && "));
                            call_then(start_expression(a.body.clone()), move |expression_11374: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::chain_arm(&head, &label_, &continued(&expression_11374, &Text::lit("    ")))))
                        }))
                    }
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let ends = match crate::syntax::lexer::chars::last(arms_) {
        Some(a) => (&a.pat == &crate::lower::model::Pa::PaWild) && (&len(&a.conds) == &Nat::from(0u32)),
        None => false,
    };
    let tail = if ends {
        Array::new()
    } else {
        Array::from(vec![Text::lit("unreachable!(\"no clause matched\")")])
    };
    Text::from(format!("{}: {{\n{}\n}}", label_, &indent(&crate::syntax::lexer::chars::join(&append(&append(&bind, &lines), &tail), &Text::lit("\n")))))
}

/// The step machine of `Chain`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Chain: unbounded fn Text, Ex, [XArm] -> Text
/// ```
pub struct Chain {
    pub label_: Text,
    pub s: crate::lower::model::Ex,
    pub arms_: Array<crate::lower::model::XArm>,
}

impl prism_rtl::Job<Text> for Chain {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let label_ = &self.label_;
        let s = &self.s;
        let arms_ = &self.arms_;
        let in_place = match s {
            crate::lower::model::Ex::XRef(y) => is_bound(&**y),
            _ => is_bound(s),
        };
        let (bind, scrut) = if in_place {
            (Array::new(), expression(s))
        } else {
            (Array::from(vec![Text::from(format!("let scrutinee = {};", &expression(s)))]), Text::lit("scrutinee"))
        };
        let n = len(arms_);
        let arms_ = arms_.clone();
        let label_ = label_.clone();
        let s = s.clone();
        call_value(each_job(crate::check::errors::range0(&n), {
            let arms_ = arms_.clone();
            let scrut = scrut.clone();
            let label_ = label_.clone();
            Rc::new(move |p0: Nat| {
                let arms_ = arms_.clone();
                let scrut = scrut.clone();
                let label_ = label_.clone();
                entered(once_job(move || {
                    let i = p0;
                    {
                        let a = or(&index(&arms_, &i), &crate::lower::model::XArm { pat: crate::lower::model::Pa::PaWild, conds: Array::new(), body: crate::lower::model::Ex::XUnit });
                        let catch_all = (&a.pat == &crate::lower::model::Pa::PaWild) && (&len(&a.conds) == &Nat::from(0u32));
                        if catch_all {
                            prism_rtl::Turn::More(Rc::new(Expression { x: a.body.clone() }))
                        } else {
                            call_then(start_pattern(a.pat.clone()), move |pattern_11257: Text| call_value(each_job(a.conds.clone(), Rc::new(move |p0: crate::lower::model::Cc| entered(once_job(move || {
                                let c = p0;
                                prism_rtl::Turn::More(Rc::new(Condition { cc0: c.clone() }))
                            }))) as Rc<dyn Fn(crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_11287: Array<Text>| {
                                let head = crate::syntax::lexer::chars::join(&append(&Array::from(vec![Text::from(format!("let {} = {}", &pattern_11257, &scrut))]), &each_11287), &Text::lit(" && "));
                                call_then(start_expression(a.body.clone()), move |expression_11374: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::chain_arm(&head, &label_, &continued(&expression_11374, &Text::lit("    ")))))
                            }))
                        }
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_11003: Array<Text>| {
            let lines = each_11003;
            let ends = match crate::syntax::lexer::chars::last(&arms_) {
                Some(a) => (&a.pat == &crate::lower::model::Pa::PaWild) && (&len(&a.conds) == &Nat::from(0u32)),
                None => false,
            };
            let tail = if ends {
                Array::new()
            } else {
                Array::from(vec![Text::lit("unreachable!(\"no clause matched\")")])
            };
            prism_rtl::Turn::Finished(Text::from(format!("{}: {{\n{}\n}}", &label_, &indent(&crate::syntax::lexer::chars::join(&append(&append(&bind, &lines), &tail), &Text::lit("\n"))))))
        })
    }
}

/// `Start Chain, x`: what the function value is when passed to `@Run`.
pub fn start_chain(label_: Text, s: crate::lower::model::Ex, arms_: Array<crate::lower::model::XArm>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Chain { label_, s, arms_ })
}

/// ```prism
/// IsBound: fn Ex -> Bool
/// ```
pub fn is_bound(x: &crate::lower::model::Ex) -> bool {
    'm11878: {
        if let crate::lower::model::Ex::XVar(_) = x {
            break 'm11878 true;
        }
        if let crate::lower::model::Ex::XField(m11878_1_0, _) = x && let crate::lower::model::Ex::XSelf = &**m11878_1_0 {
            break 'm11878 true;
        }
        if let crate::lower::model::Ex::XField(m11878_2_0, _) = x && let crate::lower::model::Ex::XMethod(m11878_2_0_r_0, _, _) = &**m11878_2_0 && let crate::lower::model::Ex::XUpgrade(_) = &**m11878_2_0_r_0 {
            break 'm11878 true;
        }
        if let crate::lower::model::Ex::XTarget(_) = x {
            break 'm11878 true;
        }
        if let crate::lower::model::Ex::XPart(m11878_4_0, _) = x && let crate::lower::model::Ex::XVar(_) = &**m11878_4_0 {
            break 'm11878 true;
        }
        false
    }
}

/// ```prism
/// Continued: fn Text, Text -> Text
/// ```
pub fn continued(t: &Text, pad: &Text) -> Text {
    let ls = split_on(t, &Text::lit("\n"));
    crate::syntax::lexer::chars::join(&each(&crate::check::errors::range0(&len(&ls)), &(|i: &Nat| if (i == &Nat::from(0u32)) || (&or(&index(&ls, i), &Text::lit("")) == &Text::lit("")) {
        or(&index(&ls, i), &Text::lit(""))
    } else {
        Text::from(format!("{}{}", pad, &or(&index(&ls, i), &Text::lit(""))))
    })), &Text::lit("\n"))
}

/// ```prism
/// BodyLines: unbounded fn Ex -> Text
/// ```
pub fn body_lines(ex0: &crate::lower::model::Ex) -> Text {
    match ex0 {
        crate::lower::model::Ex::XBlock(dos, e) => if &len(dos) == &Nat::from(0u32) {
            body_lines(&**e)
        } else {
            Text::from(format!("{}\n{}", &statements(dos), &body_lines(&**e)))
        },
        x => expression(x),
    }
}

/// The step machine of `BodyLines`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BodyLines: unbounded fn Ex -> Text
/// ```
pub struct BodyLines {
    pub ex0: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for BodyLines {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let ex0 = &self.ex0;
        match ex0 {
            crate::lower::model::Ex::XBlock(dos, e) => if &len(dos) == &Nat::from(0u32) {
                prism_rtl::Turn::More(Rc::new(BodyLines { ex0: (**e).clone() }))
            } else {
                {
                    let dos = dos.clone();
                    let e = (**e).clone();
                    call_then(start_statements(dos.clone()), move |statements_12564: Text| call_then(start_body_lines(e.clone()), move |body_lines_12582: Text| prism_rtl::Turn::Finished(Text::from(format!("{}\n{}", &statements_12564, &body_lines_12582)))))
                }
            },
            x => prism_rtl::Turn::More(Rc::new(Expression { x: x.clone() })),
        }
    }
}

/// `Start BodyLines, x`: what the function value is when passed to `@Run`.
pub fn start_body_lines(ex0: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(BodyLines { ex0 })
}

/// ```prism
/// Indent: fn Text -> Text
/// ```
pub fn indent(t: &Text) -> Text {
    crate::syntax::lexer::chars::join(&each(&split_on(t, &Text::lit("\n")), &(|l: &Text| if l == &Text::lit("") { Text::lit("") } else { Text::from(format!("    {}", l)) })), &Text::lit("\n"))
}

/// ```prism
/// Pattern: unbounded fn Pa -> Text
/// ```
pub fn pattern(p_: &crate::lower::model::Pa) -> Text {
    'm13033: {
        if let crate::lower::model::Pa::PaWild = p_ {
            break 'm13033 Text::lit("_");
        }
        if let crate::lower::model::Pa::PaBind(n) = p_ {
            break 'm13033 n.clone();
        }
        if let crate::lower::model::Pa::PaMut(n) = p_ {
            break 'm13033 Text::from(format!("mut {}", n));
        }
        if let crate::lower::model::Pa::PaCtor(c, ps) = p_ {
            break 'm13033 Text::from(format!("{}({})", c, &crate::syntax::lexer::chars::join(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                let q = p0;
                prism_rtl::Turn::More(Rc::new(Pattern_ { p_: q.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))));
        }
        if let crate::lower::model::Pa::PaUnit(c) = p_ {
            break 'm13033 c.clone();
        }
        if let crate::lower::model::Pa::PaRecord(c, fs, rest) = p_ {
            break 'm13033 {
                let parts = run_to_end(each_job(fs.clone(), Rc::new(move |p0: (Text, crate::lower::model::Pa)| entered(once_job(move || {
                    let (f, q) = p0;
                    match &q {
                        crate::lower::model::Pa::PaBind(n) => if n == &f {
                            prism_rtl::Turn::Finished(f.clone())
                        } else {
                            prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f, n)))
                        },
                        _ => call_then(start_pattern(q.clone()), move |pattern_13335: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f, &pattern_13335)))),
                    }
                }))) as Rc<dyn Fn((Text, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Text>>>));
                let all = if *rest { push(&parts, &Text::lit("..")) } else { parts.clone() };
                Text::from(format!("{} {{ {} }}", c, &crate::syntax::lexer::chars::join(&all, &Text::lit(", "))))
            };
        }
        if let crate::lower::model::Pa::PaTuple(m13033_6_0) = p_ && (m13033_6_0.len() == 1) && let Some(one) = index(m13033_6_0, &Nat::from(0u32)) {
            break 'm13033 Text::from(format!("({},)", &pattern(&one)));
        }
        if let crate::lower::model::Pa::PaTuple(ps) = p_ {
            break 'm13033 Text::from(format!("({})", &crate::syntax::lexer::chars::join(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                let q = p0;
                prism_rtl::Turn::More(Rc::new(Pattern_ { p_: q.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))));
        }
        if let crate::lower::model::Pa::PaChar(c) = p_ {
            break 'm13033 Text::from(format!("\'{}\'", &crate::lower::expr::char_escape(c)));
        }
        if let crate::lower::model::Pa::PaBool(b) = p_ {
            break 'm13033 if *b { Text::lit("true") } else { Text::lit("false") };
        }
        if let crate::lower::model::Pa::PaIndex(n) = p_ {
            break 'm13033 Text::from(format!("{}", n));
        }
        if let crate::lower::model::Pa::PaConst(n) = p_ {
            break 'm13033 Text::from(format!("Self::{}", n));
        }
        if let crate::lower::model::Pa::PaSlice(ps) = p_ {
            break 'm13033 Text::from(format!("[{}]", &crate::syntax::lexer::chars::join(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                let q = p0;
                prism_rtl::Turn::More(Rc::new(Pattern_ { p_: q.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))));
        }
        if let crate::lower::model::Pa::PaRest(m13033_13_0) = p_ && (m13033_13_0 == &Text::lit("")) {
            break 'm13033 Text::lit("..");
        }
        if let crate::lower::model::Pa::PaRest(n) = p_ {
            break 'm13033 Text::from(format!("{} @ ..", n));
        }
        if let crate::lower::model::Pa::PaTyped(q, t) = p_ {
            break 'm13033 Text::from(format!("{}: {}", &pattern(&**q), &type_(t)));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `Pattern_`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Pattern: unbounded fn Pa -> Text
/// ```
pub struct Pattern_ {
    pub p_: crate::lower::model::Pa,
}

impl prism_rtl::Job<Text> for Pattern_ {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let p_ = &self.p_;
        'm13033: {
            if let crate::lower::model::Pa::PaWild = p_ {
                break 'm13033 prism_rtl::Turn::Finished(Text::lit("_"));
            }
            if let crate::lower::model::Pa::PaBind(n) = p_ {
                break 'm13033 prism_rtl::Turn::Finished(n.clone());
            }
            if let crate::lower::model::Pa::PaMut(n) = p_ {
                break 'm13033 prism_rtl::Turn::Finished(Text::from(format!("mut {}", n)));
            }
            if let crate::lower::model::Pa::PaCtor(c, ps) = p_ {
                break 'm13033 {
                    let c = c.clone();
                    let ps = ps.clone();
                    call_value(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                        let q = p0;
                        prism_rtl::Turn::More(Rc::new(Pattern_ { p_: q.clone() }))
                    }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_13127: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &c, &crate::syntax::lexer::chars::join(&each_13127, &Text::lit(", "))))))
                };
            }
            if let crate::lower::model::Pa::PaUnit(c) = p_ {
                break 'm13033 prism_rtl::Turn::Finished(c.clone());
            }
            if let crate::lower::model::Pa::PaRecord(c, fs, rest) = p_ {
                break 'm13033 {
                    let c = c.clone();
                    let fs = fs.clone();
                    let rest = *rest;
                    call_value(each_job(fs.clone(), Rc::new(move |p0: (Text, crate::lower::model::Pa)| entered(once_job(move || {
                        let (f, q) = p0;
                        match &q {
                            crate::lower::model::Pa::PaBind(n) => if n == &f {
                                prism_rtl::Turn::Finished(f.clone())
                            } else {
                                prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f, n)))
                            },
                            _ => call_then(start_pattern(q.clone()), move |pattern_13335: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f, &pattern_13335)))),
                        }
                    }))) as Rc<dyn Fn((Text, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_13223: Array<Text>| {
                        let parts = each_13223;
                        let all = if rest { push(&parts, &Text::lit("..")) } else { parts.clone() };
                        prism_rtl::Turn::Finished(Text::from(format!("{} {{ {} }}", &c, &crate::syntax::lexer::chars::join(&all, &Text::lit(", ")))))
                    })
                };
            }
            if let crate::lower::model::Pa::PaTuple(m13033_6_0) = p_ && (m13033_6_0.len() == 1) && let Some(one) = index(m13033_6_0, &Nat::from(0u32)) {
                break 'm13033 call_then(start_pattern(one.clone()), move |pattern_13464: Text| prism_rtl::Turn::Finished(Text::from(format!("({},)", &pattern_13464))));
            }
            if let crate::lower::model::Pa::PaTuple(ps) = p_ {
                break 'm13033 {
                    let ps = ps.clone();
                    call_value(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                        let q = p0;
                        prism_rtl::Turn::More(Rc::new(Pattern_ { p_: q.clone() }))
                    }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_13505: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("({})", &crate::syntax::lexer::chars::join(&each_13505, &Text::lit(", "))))))
                };
            }
            if let crate::lower::model::Pa::PaChar(c) = p_ {
                break 'm13033 prism_rtl::Turn::Finished(Text::from(format!("\'{}\'", &crate::lower::expr::char_escape(c))));
            }
            if let crate::lower::model::Pa::PaBool(b) = p_ {
                break 'm13033 if *b {
                    prism_rtl::Turn::Finished(Text::lit("true"))
                } else {
                    prism_rtl::Turn::Finished(Text::lit("false"))
                };
            }
            if let crate::lower::model::Pa::PaIndex(n) = p_ {
                break 'm13033 prism_rtl::Turn::Finished(Text::from(format!("{}", n)));
            }
            if let crate::lower::model::Pa::PaConst(n) = p_ {
                break 'm13033 prism_rtl::Turn::Finished(Text::from(format!("Self::{}", n)));
            }
            if let crate::lower::model::Pa::PaSlice(ps) = p_ {
                break 'm13033 {
                    let ps = ps.clone();
                    call_value(each_job(ps.clone(), Rc::new(move |p0: crate::lower::model::Pa| entered(once_job(move || {
                        let q = p0;
                        prism_rtl::Turn::More(Rc::new(Pattern_ { p_: q.clone() }))
                    }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_13686: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("[{}]", &crate::syntax::lexer::chars::join(&each_13686, &Text::lit(", "))))))
                };
            }
            if let crate::lower::model::Pa::PaRest(m13033_13_0) = p_ && (m13033_13_0 == &Text::lit("")) {
                break 'm13033 prism_rtl::Turn::Finished(Text::lit(".."));
            }
            if let crate::lower::model::Pa::PaRest(n) = p_ {
                break 'm13033 prism_rtl::Turn::Finished(Text::from(format!("{} @ ..", n)));
            }
            if let crate::lower::model::Pa::PaTyped(q, t) = p_ {
                break 'm13033 {
                    let q = (**q).clone();
                    let t = t.clone();
                    call_then(start_pattern(q.clone()), move |pattern_13785: Text| call_then(start_type_(t.clone()), move |type__13798: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &pattern_13785, &type__13798)))))
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start Pattern_, x`: what the function value is when passed to `@Run`.
pub fn start_pattern(p_: crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Pattern_ { p_ })
}

/// ```prism
/// Statements: unbounded fn [Do] -> Text
/// ```
pub fn statements(dos: &Array<crate::lower::model::Do>) -> Text {
    crate::syntax::lexer::chars::join(&run_to_end(each_job(dos.clone(), Rc::new(move |p0: crate::lower::model::Do| entered(once_job(move || {
        let d = p0;
        prism_rtl::Turn::More(Rc::new(Statement { d: d.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))
}

/// The step machine of `Statements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Statements: unbounded fn [Do] -> Text
/// ```
pub struct Statements {
    pub dos: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for Statements {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let dos = &self.dos;
        let dos = dos.clone();
        call_value(each_job(dos.clone(), Rc::new(move |p0: crate::lower::model::Do| entered(once_job(move || {
            let d = p0;
            prism_rtl::Turn::More(Rc::new(Statement { d: d.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_13872: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&each_13872, &Text::lit("\n"))))
    }
}

/// `Start Statements, x`: what the function value is when passed to `@Run`.
pub fn start_statements(dos: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Statements { dos })
}

/// ```prism
/// Statement: unbounded fn Do -> Text
/// ```
pub fn statement(d: &crate::lower::model::Do) -> Text {
    match d {
        crate::lower::model::Do::DoLet(p_, x) => Text::from(format!("let {} = {};", &pattern(p_), &expression(x))),
        crate::lower::model::Do::DoLetElse(p_, x, e) => Text::from(format!("let {} = {} else {{ {} }};", &pattern(p_), &expression(x), &expression(e))),
        crate::lower::model::Do::DoAssign(p_, x) => Text::from(format!("{} = {};", &expression(p_), &expression(x))),
        crate::lower::model::Do::DoWhile(c, body) => crate::emit::rust::templates::items::if_stmt(&Text::from(format!("while {}", &expression(c))), &statements(body)),
        crate::lower::model::Do::DoWhileLet(p_, x, body) => crate::emit::rust::templates::items::if_stmt(&Text::from(format!("while let {} = {}", &pattern(p_), &expression(x))), &statements(body)),
        crate::lower::model::Do::DoFor(p_, x, body) => crate::emit::rust::templates::items::if_stmt(&Text::from(format!("for {} in {}", &pattern(p_), &expression(x))), &statements(body)),
        crate::lower::model::Do::DoExpr(x) => Text::from(format!("{};", &expression(x))),
        crate::lower::model::Do::DoIf(c, t, e) => Text::from(format!("{}{}", &crate::emit::rust::templates::items::if_stmt(&Text::from(format!("if {}", &expression(c))), &statements(t)), &else_branch(e))),
        crate::lower::model::Do::DoIfLet(p_, x, t, e) => Text::from(format!("{}{}", &crate::emit::rust::templates::items::if_stmt(&Text::from(format!("if let {} = {}", &pattern(p_), &expression(x))), &statements(t)), &else_branch(e))),
        crate::lower::model::Do::DoMatch(x, cases) => crate::emit::rust::templates::items::match_block(&expression(x), &crate::syntax::lexer::chars::join(&run_to_end(each_job(cases.clone(), Rc::new(move |p0: (crate::lower::model::Pa, Array<crate::lower::model::Do>)| entered(once_job(move || {
            let (p_, body) = p0;
            call_then(start_pattern(p_.clone()), move |pattern_14714: Text| call_then(start_statements(body.clone()), move |statements_14727: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::arm_block(&pattern_14714, &statements_14727))))
        }))) as Rc<dyn Fn((crate::lower::model::Pa, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))),
        crate::lower::model::Do::DoReturn(x) => Text::from(format!("return {};", &expression(x))),
        crate::lower::model::Do::DoBlock(body) => crate::emit::rust::templates::items::scope(&statements(body)),
        crate::lower::model::Do::DoScope(body) => Text::from(format!("{{ {} }};", &inline_statements(body))),
        crate::lower::model::Do::DoLine(body) => Text::from(format!("{};", &inline_statements(body))),
        crate::lower::model::Do::DoNote(t) => Text::from(format!("// {}", t)),
    }
}

/// The step machine of `Statement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Statement: unbounded fn Do -> Text
/// ```
pub struct Statement {
    pub d: crate::lower::model::Do,
}

impl prism_rtl::Job<Text> for Statement {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let d = &self.d;
        match d {
            crate::lower::model::Do::DoLet(p_, x) => {
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_pattern(p_.clone()), move |pattern_13990: Text| call_then(start_expression(x.clone()), move |expression_14004: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {};", &pattern_13990, &expression_14004)))))
            },
            crate::lower::model::Do::DoLetElse(p_, x, e) => {
                let e = e.clone();
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_pattern(p_.clone()), move |pattern_14049: Text| call_then(start_expression(x.clone()), move |expression_14063: Text| call_then(start_expression(e.clone()), move |expression_14086: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {} else {{ {} }};", &pattern_14049, &expression_14063, &expression_14086))))))
            },
            crate::lower::model::Do::DoAssign(p_, x) => {
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_expression(p_.clone()), move |expression_14126: Text| call_then(start_expression(x.clone()), move |expression_14143: Text| prism_rtl::Turn::Finished(Text::from(format!("{} = {};", &expression_14126, &expression_14143)))))
            },
            crate::lower::model::Do::DoWhile(c, body) => {
                let body = body.clone();
                let c = c.clone();
                call_then(start_expression(c.clone()), move |expression_14195: Text| call_then(start_statements(body.clone()), move |statements_14212: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::if_stmt(&Text::from(format!("while {}", &expression_14195)), &statements_14212))))
            },
            crate::lower::model::Do::DoWhileLet(p_, x, body) => {
                let body = body.clone();
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_pattern(p_.clone()), move |pattern_14275: Text| call_then(start_expression(x.clone()), move |expression_14289: Text| call_then(start_statements(body.clone()), move |statements_14306: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::if_stmt(&Text::from(format!("while let {} = {}", &pattern_14275, &expression_14289)), &statements_14306)))))
            },
            crate::lower::model::Do::DoFor(p_, x, body) => {
                let body = body.clone();
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_pattern(p_.clone()), move |pattern_14358: Text| call_then(start_expression(x.clone()), move |expression_14373: Text| call_then(start_statements(body.clone()), move |statements_14390: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::if_stmt(&Text::from(format!("for {} in {}", &pattern_14358, &expression_14373)), &statements_14390)))))
            },
            crate::lower::model::Do::DoExpr(x) => {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_14423: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &expression_14423))))
            },
            crate::lower::model::Do::DoIf(c, t, e) => {
                let c = c.clone();
                let e = e.clone();
                let t = t.clone();
                call_then(start_expression(c.clone()), move |expression_14471: Text| call_then(start_statements(t.clone()), move |statements_14488: Text| call_then(start_else_branch(e.clone()), move |else_branch_14503: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &crate::emit::rust::templates::items::if_stmt(&Text::from(format!("if {}", &expression_14471)), &statements_14488), &else_branch_14503))))))
            },
            crate::lower::model::Do::DoIfLet(p_, x, t, e) => {
                let e = e.clone();
                let p_ = p_.clone();
                let t = t.clone();
                let x = x.clone();
                call_then(start_pattern(p_.clone()), move |pattern_14560: Text| call_then(start_expression(x.clone()), move |expression_14574: Text| call_then(start_statements(t.clone()), move |statements_14591: Text| call_then(start_else_branch(e.clone()), move |else_branch_14606: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &crate::emit::rust::templates::items::if_stmt(&Text::from(format!("if let {} = {}", &pattern_14560, &expression_14574)), &statements_14591), &else_branch_14606)))))))
            },
            crate::lower::model::Do::DoMatch(x, cases) => {
                let cases = cases.clone();
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_14655: Text| call_value(each_job(cases.clone(), Rc::new(move |p0: (crate::lower::model::Pa, Array<crate::lower::model::Do>)| entered(once_job(move || {
                    let (p_, body) = p0;
                    call_then(start_pattern(p_.clone()), move |pattern_14714: Text| call_then(start_statements(body.clone()), move |statements_14727: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::arm_block(&pattern_14714, &statements_14727))))
                }))) as Rc<dyn Fn((crate::lower::model::Pa, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_14677: Array<Text>| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::match_block(&expression_14655, &crate::syntax::lexer::chars::join(&each_14677, &Text::lit("\n"))))))
            },
            crate::lower::model::Do::DoReturn(x) => {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_14777: Text| prism_rtl::Turn::Finished(Text::from(format!("return {};", &expression_14777))))
            },
            crate::lower::model::Do::DoBlock(body) => {
                let body = body.clone();
                call_then(start_statements(body.clone()), move |statements_14818: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::scope(&statements_14818)))
            },
            crate::lower::model::Do::DoScope(body) => {
                let body = body.clone();
                call_then(start_inline_statements(body.clone()), move |inline_statements_14858: Text| prism_rtl::Turn::Finished(Text::from(format!("{{ {} }};", &inline_statements_14858))))
            },
            crate::lower::model::Do::DoLine(body) => {
                let body = body.clone();
                call_then(start_inline_statements(body.clone()), move |inline_statements_14905: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &inline_statements_14905))))
            },
            crate::lower::model::Do::DoNote(t) => prism_rtl::Turn::Finished(Text::from(format!("// {}", t))),
        }
    }
}

/// `Start Statement, x`: what the function value is when passed to `@Run`.
pub fn start_statement(d: crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Statement { d })
}

/// ```prism
/// InlineStatements: unbounded fn [Do] -> Text
/// ```
pub fn inline_statements(dos: &Array<crate::lower::model::Do>) -> Text {
    crate::syntax::lexer::chars::join(&run_to_end(each_job(dos.clone(), Rc::new(move |p0: crate::lower::model::Do| entered(once_job(move || {
        let d = p0;
        prism_rtl::Turn::More(Rc::new(InlineStatement { do_0: d.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(" "))
}

/// The step machine of `InlineStatements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InlineStatements: unbounded fn [Do] -> Text
/// ```
pub struct InlineStatements {
    pub dos: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for InlineStatements {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let dos = &self.dos;
        let dos = dos.clone();
        call_value(each_job(dos.clone(), Rc::new(move |p0: crate::lower::model::Do| entered(once_job(move || {
            let d = p0;
            prism_rtl::Turn::More(Rc::new(InlineStatement { do_0: d.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_15078: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join(&each_15078, &Text::lit(" "))))
    }
}

/// `Start InlineStatements, x`: what the function value is when passed to `@Run`.
pub fn start_inline_statements(dos: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(InlineStatements { dos })
}

/// ```prism
/// InlineStatement: unbounded fn Do -> Text
/// ```
pub fn inline_statement(do_0: &crate::lower::model::Do) -> Text {
    match do_0 {
        crate::lower::model::Do::DoIf(c, t, c0_0_2) if (c0_0_2.len() == 0) => Text::from(format!("if {} {{ {} }}", &expression(c), &inline_statements(t))),
        d => statement(d),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `InlineStatement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InlineStatement: unbounded fn Do -> Text
/// ```
pub struct InlineStatement {
    pub do_0: crate::lower::model::Do,
}

impl prism_rtl::Job<Text> for InlineStatement {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let do_0 = &self.do_0;
        match do_0 {
            crate::lower::model::Do::DoIf(c, t, j0_0_2) if (j0_0_2.len() == 0) => {
                let c = c.clone();
                let t = t.clone();
                call_then(start_expression(c.clone()), move |expression_15203: Text| call_then(start_inline_statements(t.clone()), move |inline_statements_15221: Text| prism_rtl::Turn::Finished(Text::from(format!("if {} {{ {} }}", &expression_15203, &inline_statements_15221)))))
            },
            d => prism_rtl::Turn::More(Rc::new(Statement { d: d.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start InlineStatement, x`: what the function value is when passed to `@Run`.
pub fn start_inline_statement(do_0: crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(InlineStatement { do_0 })
}

/// ```prism
/// ElseBranch: unbounded fn [Do] -> Text
/// ```
pub fn else_branch(xs0: &Array<crate::lower::model::Do>) -> Text {
    'c: {
        if let c0_0 = xs0 && (c0_0.len() == 0) {
            break 'c Text::lit("");
        }
        if let c1_0 = xs0 && (c1_0.len() == 1) && let Some(crate::lower::model::Do::DoIf(c, t, e)) = index(c1_0, &Nat::from(0u32)) {
            break 'c Text::from(format!(" else {}", &statement(&crate::lower::model::Do::DoIf(c.clone(), t.clone(), e.clone()))));
        }
        if let c2_0 = xs0 && (c2_0.len() == 1) && let Some(crate::lower::model::Do::DoIfLet(p_, x, t, e)) = index(c2_0, &Nat::from(0u32)) {
            break 'c Text::from(format!(" else {}", &statement(&crate::lower::model::Do::DoIfLet(p_.clone(), x.clone(), t.clone(), e.clone()))));
        }
        if let body = xs0 {
            break 'c crate::emit::rust::templates::items::else_(&statements(body));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `ElseBranch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ElseBranch: unbounded fn [Do] -> Text
/// ```
pub struct ElseBranch {
    pub xs0: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for ElseBranch {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let xs0 = &self.xs0;
        'j: {
            if let j0_0 = xs0 && (j0_0.len() == 0) {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let j1_0 = xs0 && (j1_0.len() == 1) && let Some(crate::lower::model::Do::DoIf(c, t, e)) = index(j1_0, &Nat::from(0u32)) {
                break 'j call_then(start_statement(crate::lower::model::Do::DoIf(c.clone(), t.clone(), e.clone())), move |statement_15433: Text| prism_rtl::Turn::Finished(Text::from(format!(" else {}", &statement_15433))));
            }
            if let j2_0 = xs0 && (j2_0.len() == 1) && let Some(crate::lower::model::Do::DoIfLet(p_, x, t, e)) = index(j2_0, &Nat::from(0u32)) {
                break 'j call_then(start_statement(crate::lower::model::Do::DoIfLet(p_.clone(), x.clone(), t.clone(), e.clone())), move |statement_15509: Text| prism_rtl::Turn::Finished(Text::from(format!(" else {}", &statement_15509))));
            }
            if let body = xs0 {
                break 'j {
                    let body = body.clone();
                    call_then(start_statements(body.clone()), move |statements_15569: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::else_(&statements_15569)))
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start ElseBranch, x`: what the function value is when passed to `@Run`.
pub fn start_else_branch(xs0: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ElseBranch { xs0 })
}
