//! The module `Emit.Rust`, from `target/bootstrap/src/prismc/emit/rust/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;
pub mod items;
pub mod prelude;
pub mod templates;

/// ```prism
/// Type: unbounded fn OutTy -> Text
/// ```
pub fn type_f(t_p0: &crate::lower::model::OutTy) -> crate::prelude::Text {
    'm1596: {
        if let crate::lower::model::OutTy::OutNat = t_p0 {
            break 'm1596 crate::prelude::Text::lit("crate::prelude::Nat");
        }
        if let crate::lower::model::OutTy::OutInt = t_p0 {
            break 'm1596 crate::prelude::Text::lit("crate::prelude::Int");
        }
        if let crate::lower::model::OutTy::OutU8 = t_p0 {
            break 'm1596 crate::prelude::Text::lit("u8");
        }
        if let crate::lower::model::OutTy::OutFloat = t_p0 {
            break 'm1596 crate::prelude::Text::lit("crate::prelude::Float");
        }
        if let crate::lower::model::OutTy::OutBool = t_p0 {
            break 'm1596 crate::prelude::Text::lit("bool");
        }
        if let crate::lower::model::OutTy::OutChar = t_p0 {
            break 'm1596 crate::prelude::Text::lit("char");
        }
        if let crate::lower::model::OutTy::OutText = t_p0 {
            break 'm1596 crate::prelude::Text::lit("crate::prelude::Text");
        }
        if let crate::lower::model::OutTy::OutCursor = t_p0 {
            break 'm1596 crate::prelude::Text::lit("crate::prelude::Cursor");
        }
        if let crate::lower::model::OutTy::OutRegex = t_p0 {
            break 'm1596 crate::prelude::Text::lit("crate::prelude::Regex");
        }
        if let crate::lower::model::OutTy::OutReplacement = t_p0 {
            break 'm1596 crate::prelude::Text::lit("crate::prelude::RegexReplacement");
        }
        if let crate::lower::model::OutTy::OutUnit = t_p0 {
            break 'm1596 crate::prelude::Text::lit("()");
        }
        if let crate::lower::model::OutTy::OutPath = t_p0 {
            break 'm1596 crate::prelude::Text::lit("crate::prelude::Path");
        }
        if let crate::lower::model::OutTy::OutDuration = t_p0 {
            break 'm1596 crate::prelude::Text::lit("crate::prelude::Duration");
        }
        if let crate::lower::model::OutTy::OutError = t_p0 {
            break 'm1596 crate::prelude::Text::lit("crate::prelude::Error");
        }
        if let crate::lower::model::OutTy::OutNamed(n_p1, m1596_14_1) = t_p0 && (m1596_14_1.len() == 0) {
            break 'm1596 rs_ref_f(n_p1);
        }
        if let crate::lower::model::OutTy::OutNamed(n_p2, args_p3) = t_p0 {
            break 'm1596 crate::prelude::Text::from(format!("{}<{}>", &rs_ref_f(n_p2), &types_f(args_p3)));
        }
        if let crate::lower::model::OutTy::OutOpt(i_p4) = t_p0 {
            break 'm1596 crate::prelude::Text::from(format!("::std::option::Option<{}>", &type_f(&**i_p4)));
        }
        if let crate::lower::model::OutTy::OutRes(i_p5) = t_p0 {
            break 'm1596 crate::prelude::Text::from(format!("::std::result::Result<{}, crate::prelude::Error>", &type_f(&**i_p5)));
        }
        if let crate::lower::model::OutTy::OutTuple(m1596_18_0) = t_p0 && (m1596_18_0.len() == 1) && let ::std::option::Option::Some(one_p6) = crate::prelude::index(m1596_18_0, &crate::prelude::Nat::from(0u32)) {
            break 'm1596 crate::prelude::Text::from(format!("({},)", &type_f(&one_p6)));
        }
        if let crate::lower::model::OutTy::OutTuple(ts_p7) = t_p0 {
            break 'm1596 crate::prelude::Text::from(format!("({})", &types_f(ts_p7)));
        }
        if let crate::lower::model::OutTy::OutArray(e_p8) = t_p0 {
            break 'm1596 crate::prelude::Text::from(format!("crate::prelude::Array<{}>", &type_f(&**e_p8)));
        }
        if let crate::lower::model::OutTy::OutMap(k_p9, v_pa) = t_p0 {
            break 'm1596 crate::prelude::Text::from(format!("crate::prelude::Map<{}, {}>", &type_f(&**k_p9), &type_f(&**v_pa)));
        }
        if let crate::lower::model::OutTy::OutFn(ps_pb, r_pc) = t_p0 {
            break 'm1596 crate::prelude::Text::from(format!("::std::rc::Rc<dyn ::std::ops::Fn({}) -> {}>", &ref_types_f(ps_pb), &type_f(&**r_pc)));
        }
        if let crate::lower::model::OutTy::OutRef(i_pd) = t_p0 {
            break 'm1596 crate::prelude::Text::from(format!("&{}", &type_f(&**i_pd)));
        }
        if let crate::lower::model::OutTy::OutRefMut(i_pe) = t_p0 {
            break 'm1596 crate::prelude::Text::from(format!("&mut {}", &type_f(&**i_pe)));
        }
        if let crate::lower::model::OutTy::OutJobFn(a_pf, b_pg) = t_p0 {
            break 'm1596 crate::prelude::Text::from(format!("::std::rc::Rc<dyn ::std::ops::Fn({}) -> ::std::rc::Rc<dyn ::prism_rtl::Job<{}>>>", &type_f(&**a_pf), &type_f(&**b_pg)));
        }
        if let crate::lower::model::OutTy::OutJob(b_ph) = t_p0 {
            break 'm1596 crate::prelude::Text::from(format!("::std::rc::Rc<dyn ::prism_rtl::Job<{}>>", &type_f(&**b_ph)));
        }
        if let crate::lower::model::OutTy::OutEvent(i_pi) = t_p0 {
            break 'm1596 crate::prelude::Text::from(format!("crate::prelude::Event<{}>", &type_f(&**i_pi)));
        }
        if let crate::lower::model::OutTy::OutDyn(i_pj) = t_p0 {
            break 'm1596 crate::prelude::Text::from(format!("crate::prelude::Dynamic<{}>", &type_f(&**i_pj)));
        }
        if let crate::lower::model::OutTy::OutGen(n_pk) = t_p0 {
            break 'm1596 n_pk.clone();
        }
        if let crate::lower::model::OutTy::OutRc(i_pl) = t_p0 {
            break 'm1596 crate::prelude::Text::from(format!("::std::rc::Rc<{}>", &type_f(&**i_pl)));
        }
        if let crate::lower::model::OutTy::OutPod = t_p0 {
            break 'm1596 crate::prelude::Text::lit("crate::prelude::Pod");
        }
        if let crate::lower::model::OutTy::OutShowAny = t_p0 {
            break 'm1596 crate::prelude::Text::lit("::std::rc::Rc<dyn crate::prelude::Show>");
        }
        if let crate::lower::model::OutTy::OutHold(i_pm) = t_p0 {
            break 'm1596 crate::prelude::Text::from(format!("crate::prelude::Hold<{}>", &type_f(&**i_pm)));
        }
        if let crate::lower::model::OutTy::OutStamped(i_pn) = t_p0 {
            break 'm1596 crate::prelude::Text::from(format!("crate::prelude::Stamped<{}>", &type_f(&**i_pn)));
        }
        if let crate::lower::model::OutTy::OutSnapshot(i_po) = t_p0 {
            break 'm1596 crate::prelude::Text::from(format!("crate::prelude::Snapshot<{}>", &type_f(&**i_po)));
        }
        if let crate::lower::model::OutTy::OutDefer(i_pp) = t_p0 {
            break 'm1596 crate::prelude::Text::from(format!("crate::prelude::Defer<{}>", &type_f(&**i_pp)));
        }
        if let crate::lower::model::OutTy::OutWeak(n_pq) = t_p0 {
            break 'm1596 crate::prelude::Text::from(format!("::std::rc::Weak<{}>", n_pq));
        }
        if let crate::lower::model::OutTy::OutCell(i_pr) = t_p0 {
            break 'm1596 crate::prelude::Text::from(format!("::std::cell::RefCell<{}>", &type_f(&**i_pr)));
        }
        if let crate::lower::model::OutTy::OutWakes = t_p0 {
            break 'm1596 crate::prelude::Text::lit("crate::prelude::Wakes");
        }
        if let crate::lower::model::OutTy::OutCount = t_p0 {
            break 'm1596 crate::prelude::Text::lit("u32");
        }
        if let crate::lower::model::OutTy::OutObj(i_ps) = t_p0 {
            break 'm1596 crate::prelude::Text::from(format!("::std::rc::Rc<dyn {}>", &type_f(&**i_ps)));
        }
        if let crate::lower::model::OutTy::OutSlice(i_pt) = t_p0 {
            break 'm1596 crate::prelude::Text::from(format!("[{}]", &type_f(&**i_pt)));
        }
        if let crate::lower::model::OutTy::OutPort(i_pu) = t_p0 {
            break 'm1596 crate::prelude::Text::from(format!("crate::prelude::Port<{}>", &type_f(&**i_pu)));
        }
        if let crate::lower::model::OutTy::OutLive(i_pv) = t_p0 {
            break 'm1596 crate::prelude::Text::from(format!("crate::prelude::Element<{}>", &type_f(&**i_pv)));
        }
        if let crate::lower::model::OutTy::OutTurn = t_p0 {
            break 'm1596 crate::prelude::Text::lit("() /* the job\'s turn */");
        }
        if let crate::lower::model::OutTy::OutAssoc(tr_p10, n_p11, m1596_46_2) = t_p0 && let crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(m1596_46_2_r_0_0), m1596_46_2_r_1) = &**m1596_46_2 && (m1596_46_2_r_0_0 == &crate::prelude::Text::lit("Self")) && (m1596_46_2_r_1.len() == 0) {
            break 'm1596 crate::prelude::Text::from(format!("Self::{}", n_p11));
        }
        if let crate::lower::model::OutTy::OutAssoc(tr_p12, n_p13, a_p14) = t_p0 {
            break 'm1596 crate::prelude::Text::from(format!("<{} as {}>::{}", &type_f(&**a_p14), tr_p12, n_p13));
        }
        if let crate::lower::model::OutTy::OutRefused(what_p15) = t_p0 {
            break 'm1596 crate::prelude::Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::expr::lowering_refusal_p(), what_p15));
        }
        if let crate::lower::model::OutTy::OutQuantified(b_p16) = t_p0 {
            break 'm1596 crate::prelude::Text::from(format!("compile_error!(\"{}a quantified type variable of `{}`: no instantiation gives it a type\")", &crate::lower::expr::lowering_refusal_p(), b_p16));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `Type`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Type: unbounded fn OutTy -> Text
/// ```
pub struct Type {
    pub t_p0: crate::lower::model::OutTy,
}

impl ::prism_rtl::Job<crate::prelude::Text> for Type {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let t_p0 = &self.t_p0;
        'm1596: {
            if let crate::lower::model::OutTy::OutNat = t_p0 {
                break 'm1596 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Nat"));
            }
            if let crate::lower::model::OutTy::OutInt = t_p0 {
                break 'm1596 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Int"));
            }
            if let crate::lower::model::OutTy::OutU8 = t_p0 {
                break 'm1596 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("u8"));
            }
            if let crate::lower::model::OutTy::OutFloat = t_p0 {
                break 'm1596 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Float"));
            }
            if let crate::lower::model::OutTy::OutBool = t_p0 {
                break 'm1596 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("bool"));
            }
            if let crate::lower::model::OutTy::OutChar = t_p0 {
                break 'm1596 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("char"));
            }
            if let crate::lower::model::OutTy::OutText = t_p0 {
                break 'm1596 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Text"));
            }
            if let crate::lower::model::OutTy::OutCursor = t_p0 {
                break 'm1596 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Cursor"));
            }
            if let crate::lower::model::OutTy::OutRegex = t_p0 {
                break 'm1596 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Regex"));
            }
            if let crate::lower::model::OutTy::OutReplacement = t_p0 {
                break 'm1596 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::RegexReplacement"));
            }
            if let crate::lower::model::OutTy::OutUnit = t_p0 {
                break 'm1596 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("()"));
            }
            if let crate::lower::model::OutTy::OutPath = t_p0 {
                break 'm1596 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Path"));
            }
            if let crate::lower::model::OutTy::OutDuration = t_p0 {
                break 'm1596 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Duration"));
            }
            if let crate::lower::model::OutTy::OutError = t_p0 {
                break 'm1596 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Error"));
            }
            if let crate::lower::model::OutTy::OutNamed(n_p1, m1596_14_1) = t_p0 && (m1596_14_1.len() == 0) {
                break 'm1596 ::prism_rtl::Turn::Finished(rs_ref_f(n_p1));
            }
            if let crate::lower::model::OutTy::OutNamed(n_p2, args_p3) = t_p0 {
                break 'm1596 {
                    let args_p3x = args_p3.clone();
                    let n_p2x = n_p2.clone();
                    crate::prelude::call_then(start_types_f(args_p3x.clone()), move |types_f_2136: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}<{}>", &rs_ref_f(&n_p2x), &types_f_2136))))
                };
            }
            if let crate::lower::model::OutTy::OutOpt(i_p4) = t_p0 {
                break 'm1596 {
                    let i_p4x = (**i_p4).clone();
                    crate::prelude::call_then(start_type_f(i_p4x.clone()), move |type_f_2188: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::std::option::Option<{}>", &type_f_2188))))
                };
            }
            if let crate::lower::model::OutTy::OutRes(i_p5) = t_p0 {
                break 'm1596 {
                    let i_p5x = (**i_p5).clone();
                    crate::prelude::call_then(start_type_f(i_p5x.clone()), move |type_f_2236: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::std::result::Result<{}, crate::prelude::Error>", &type_f_2236))))
                };
            }
            if let crate::lower::model::OutTy::OutTuple(m1596_18_0) = t_p0 && (m1596_18_0.len() == 1) && let ::std::option::Option::Some(one_p6) = crate::prelude::index(m1596_18_0, &crate::prelude::Nat::from(0u32)) {
                break 'm1596 crate::prelude::call_then(start_type_f(one_p6.clone()), move |type_f_2294: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("({},)", &type_f_2294))));
            }
            if let crate::lower::model::OutTy::OutTuple(ts_p7) = t_p0 {
                break 'm1596 {
                    let ts_p7x = ts_p7.clone();
                    crate::prelude::call_then(start_types_f(ts_p7x.clone()), move |types_f_2327: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("({})", &types_f_2327))))
                };
            }
            if let crate::lower::model::OutTy::OutArray(e_p8) = t_p0 {
                break 'm1596 {
                    let e_p8x = (**e_p8).clone();
                    crate::prelude::call_then(start_type_f(e_p8x.clone()), move |type_f_2379: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Array<{}>", &type_f_2379))))
                };
            }
            if let crate::lower::model::OutTy::OutMap(k_p9, v_pa) = t_p0 {
                break 'm1596 {
                    let k_p9x = (**k_p9).clone();
                    let v_pax = (**v_pa).clone();
                    crate::prelude::call_then(start_type_f(k_p9x.clone()), move |type_f_2428: crate::prelude::Text| crate::prelude::call_then(start_type_f(v_pax.clone()), move |type_f_2438: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Map<{}, {}>", &type_f_2428, &type_f_2438)))))
                };
            }
            if let crate::lower::model::OutTy::OutFn(ps_pb, r_pc) = t_p0 {
                break 'm1596 {
                    let ps_pbx = ps_pb.clone();
                    let r_pcx = (**r_pc).clone();
                    crate::prelude::call_then(start_ref_types_f(ps_pbx.clone()), move |ref_types_f_2500: crate::prelude::Text| crate::prelude::call_then(start_type_f(r_pcx.clone()), move |type_f_2518: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::std::rc::Rc<dyn ::std::ops::Fn({}) -> {}>", &ref_types_f_2500, &type_f_2518)))))
                };
            }
            if let crate::lower::model::OutTy::OutRef(i_pd) = t_p0 {
                break 'm1596 {
                    let i_pdx = (**i_pd).clone();
                    crate::prelude::call_then(start_type_f(i_pdx.clone()), move |type_f_2545: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("&{}", &type_f_2545))))
                };
            }
            if let crate::lower::model::OutTy::OutRefMut(i_pe) = t_p0 {
                break 'm1596 {
                    let i_pex = (**i_pe).clone();
                    crate::prelude::call_then(start_type_f(i_pex.clone()), move |type_f_2578: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("&mut {}", &type_f_2578))))
                };
            }
            if let crate::lower::model::OutTy::OutJobFn(a_pf, b_pg) = t_p0 {
                break 'm1596 {
                    let a_pfx = (**a_pf).clone();
                    let b_pgx = (**b_pg).clone();
                    crate::prelude::call_then(start_type_f(a_pfx.clone()), move |type_f_2641: crate::prelude::Text| crate::prelude::call_then(start_type_f(b_pgx.clone()), move |type_f_2689: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::std::rc::Rc<dyn ::std::ops::Fn({}) -> ::std::rc::Rc<dyn ::prism_rtl::Job<{}>>>", &type_f_2641, &type_f_2689)))))
                };
            }
            if let crate::lower::model::OutTy::OutJob(b_ph) = t_p0 {
                break 'm1596 {
                    let b_phx = (**b_ph).clone();
                    crate::prelude::call_then(start_type_f(b_phx.clone()), move |type_f_2752: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::std::rc::Rc<dyn ::prism_rtl::Job<{}>>", &type_f_2752))))
                };
            }
            if let crate::lower::model::OutTy::OutEvent(i_pi) = t_p0 {
                break 'm1596 {
                    let i_pix = (**i_pi).clone();
                    crate::prelude::call_then(start_type_f(i_pix.clone()), move |type_f_2803: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Event<{}>", &type_f_2803))))
                };
            }
            if let crate::lower::model::OutTy::OutDyn(i_pj) = t_p0 {
                break 'm1596 {
                    let i_pjx = (**i_pj).clone();
                    crate::prelude::call_then(start_type_f(i_pjx.clone()), move |type_f_2853: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Dynamic<{}>", &type_f_2853))))
                };
            }
            if let crate::lower::model::OutTy::OutGen(n_pk) = t_p0 {
                break 'm1596 ::prism_rtl::Turn::Finished(n_pk.clone());
            }
            if let crate::lower::model::OutTy::OutRc(i_pl) = t_p0 {
                break 'm1596 {
                    let i_plx = (**i_pl).clone();
                    crate::prelude::call_then(start_type_f(i_plx.clone()), move |type_f_2908: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::std::rc::Rc<{}>", &type_f_2908))))
                };
            }
            if let crate::lower::model::OutTy::OutPod = t_p0 {
                break 'm1596 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Pod"));
            }
            if let crate::lower::model::OutTy::OutShowAny = t_p0 {
                break 'm1596 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("::std::rc::Rc<dyn crate::prelude::Show>"));
            }
            if let crate::lower::model::OutTy::OutHold(i_pm) = t_p0 {
                break 'm1596 {
                    let i_pmx = (**i_pm).clone();
                    crate::prelude::call_then(start_type_f(i_pmx.clone()), move |type_f_3048: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Hold<{}>", &type_f_3048))))
                };
            }
            if let crate::lower::model::OutTy::OutStamped(i_pn) = t_p0 {
                break 'm1596 {
                    let i_pnx = (**i_pn).clone();
                    crate::prelude::call_then(start_type_f(i_pnx.clone()), move |type_f_3102: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Stamped<{}>", &type_f_3102))))
                };
            }
            if let crate::lower::model::OutTy::OutSnapshot(i_po) = t_p0 {
                break 'm1596 {
                    let i_pox = (**i_po).clone();
                    crate::prelude::call_then(start_type_f(i_pox.clone()), move |type_f_3158: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Snapshot<{}>", &type_f_3158))))
                };
            }
            if let crate::lower::model::OutTy::OutDefer(i_pp) = t_p0 {
                break 'm1596 {
                    let i_ppx = (**i_pp).clone();
                    crate::prelude::call_then(start_type_f(i_ppx.clone()), move |type_f_3208: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Defer<{}>", &type_f_3208))))
                };
            }
            if let crate::lower::model::OutTy::OutWeak(n_pq) = t_p0 {
                break 'm1596 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::std::rc::Weak<{}>", n_pq)));
            }
            if let crate::lower::model::OutTy::OutCell(i_pr) = t_p0 {
                break 'm1596 {
                    let i_prx = (**i_pr).clone();
                    crate::prelude::call_then(start_type_f(i_prx.clone()), move |type_f_3294: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::std::cell::RefCell<{}>", &type_f_3294))))
                };
            }
            if let crate::lower::model::OutTy::OutWakes = t_p0 {
                break 'm1596 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Wakes"));
            }
            if let crate::lower::model::OutTy::OutCount = t_p0 {
                break 'm1596 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("u32"));
            }
            if let crate::lower::model::OutTy::OutObj(i_ps) = t_p0 {
                break 'm1596 {
                    let i_psx = (**i_ps).clone();
                    crate::prelude::call_then(start_type_f(i_psx.clone()), move |type_f_3396: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::std::rc::Rc<dyn {}>", &type_f_3396))))
                };
            }
            if let crate::lower::model::OutTy::OutSlice(i_pt) = t_p0 {
                break 'm1596 {
                    let i_ptx = (**i_pt).clone();
                    crate::prelude::call_then(start_type_f(i_ptx.clone()), move |type_f_3425: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("[{}]", &type_f_3425))))
                };
            }
            if let crate::lower::model::OutTy::OutPort(i_pu) = t_p0 {
                break 'm1596 {
                    let i_pux = (**i_pu).clone();
                    crate::prelude::call_then(start_type_f(i_pux.clone()), move |type_f_3473: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Port<{}>", &type_f_3473))))
                };
            }
            if let crate::lower::model::OutTy::OutLive(i_pv) = t_p0 {
                break 'm1596 {
                    let i_pvx = (**i_pv).clone();
                    crate::prelude::call_then(start_type_f(i_pvx.clone()), move |type_f_3524: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Element<{}>", &type_f_3524))))
                };
            }
            if let crate::lower::model::OutTy::OutTurn = t_p0 {
                break 'm1596 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("() /* the job\'s turn */"));
            }
            if let crate::lower::model::OutTy::OutAssoc(tr_p10, n_p11, m1596_46_2) = t_p0 && let crate::lower::model::OutTy::OutNamed(crate::lower::model::Ref::RefRuntime(m1596_46_2_r_0_0), m1596_46_2_r_1) = &**m1596_46_2 && (m1596_46_2_r_0_0 == &crate::prelude::Text::lit("Self")) && (m1596_46_2_r_1.len() == 0) {
                break 'm1596 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("Self::{}", n_p11)));
            }
            if let crate::lower::model::OutTy::OutAssoc(tr_p12, n_p13, a_p14) = t_p0 {
                break 'm1596 {
                    let a_p14x = (**a_p14).clone();
                    let n_p13x = n_p13.clone();
                    let tr_p12x = tr_p12.clone();
                    crate::prelude::call_then(start_type_f(a_p14x.clone()), move |type_f_3669: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("<{} as {}>::{}", &type_f_3669, &tr_p12x, &n_p13x))))
                };
            }
            if let crate::lower::model::OutTy::OutRefused(what_p15) = t_p0 {
                break 'm1596 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::expr::lowering_refusal_p(), what_p15)));
            }
            if let crate::lower::model::OutTy::OutQuantified(b_p16) = t_p0 {
                break 'm1596 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("compile_error!(\"{}a quantified type variable of `{}`: no instantiation gives it a type\")", &crate::lower::expr::lowering_refusal_p(), b_p16)));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start Type, x`: what the function value is when passed to `@Run`.
pub fn start_type_f(t_p0: crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(Type { t_p0 })
}

/// ```prism
/// RsRef: fn Ref -> Text
/// ```
pub fn rs_ref_f(ref_0: &crate::lower::model::Ref) -> crate::prelude::Text {
    match ref_0 {
        crate::lower::model::Ref::RefItem(_, _, s_p0) => s_p0.clone(),
        crate::lower::model::Ref::RefRuntime(t_p1) => rs_path_f(t_p1),
    }
}

/// ```prism
/// RsPath: fn Text -> Text
/// ```
pub fn rs_path_f(p_p0: &crate::prelude::Text) -> crate::prelude::Text {
    if crate::syntax::lexer::chars::has_prefix_f(p_p0, &crate::prelude::Text::lit("rt::")) || crate::syntax::lexer::chars::has_prefix_f(p_p0, &crate::prelude::Text::lit("prism_rtl::")) {
        crate::lower::model::runtime_path_f(p_p0)
    } else {
        if crate::syntax::lexer::chars::has_prefix_f(p_p0, &crate::prelude::Text::lit("std::")) {
            {
                let segs_p1 = crate::prelude::split_on(&crate::syntax::lexer::chars::drop_prefix_f(p_p0, &crate::prelude::Text::lit("std::")), &crate::prelude::Text::lit("::"));
                match std_path_o(&crate::prelude::or(&crate::prelude::index(&segs_p1, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit(""))) {
                    ::std::option::Option::Some(full_p2) => crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::Array::from(vec![full_p2]), &crate::prelude::drop(&segs_p1, &crate::prelude::Nat::from(1u32))), &crate::prelude::Text::lit("::")),
                    ::std::option::Option::None => p_p0.clone(),
                }
            }
        } else {
            p_p0.clone()
        }
    }
}

/// ```prism
/// ?StdPath: fn Text -> ?Text
/// ```
pub fn std_path_o(text0: &crate::prelude::Text) -> ::std::option::Option<crate::prelude::Text> {
    match text0 {
        c0_0 if (c0_0 == &crate::prelude::Text::lit("Rc")) => ::std::option::Option::Some(crate::prelude::Text::lit("::std::rc::Rc")),
        c1_0 if (c1_0 == &crate::prelude::Text::lit("Weak")) => ::std::option::Option::Some(crate::prelude::Text::lit("::std::rc::Weak")),
        c2_0 if (c2_0 == &crate::prelude::Text::lit("Cell")) => ::std::option::Option::Some(crate::prelude::Text::lit("::std::cell::Cell")),
        c3_0 if (c3_0 == &crate::prelude::Text::lit("RefCell")) => ::std::option::Option::Some(crate::prelude::Text::lit("::std::cell::RefCell")),
        c4_0 if (c4_0 == &crate::prelude::Text::lit("Option")) => ::std::option::Option::Some(crate::prelude::Text::lit("::std::option::Option")),
        c5_0 if (c5_0 == &crate::prelude::Text::lit("Some")) => ::std::option::Option::Some(crate::prelude::Text::lit("::std::option::Option::Some")),
        c6_0 if (c6_0 == &crate::prelude::Text::lit("None")) => ::std::option::Option::Some(crate::prelude::Text::lit("::std::option::Option::None")),
        c7_0 if (c7_0 == &crate::prelude::Text::lit("Result")) => ::std::option::Option::Some(crate::prelude::Text::lit("::std::result::Result")),
        c8_0 if (c8_0 == &crate::prelude::Text::lit("Ok")) => ::std::option::Option::Some(crate::prelude::Text::lit("::std::result::Result::Ok")),
        c9_0 if (c9_0 == &crate::prelude::Text::lit("Err")) => ::std::option::Option::Some(crate::prelude::Text::lit("::std::result::Result::Err")),
        c10_0 if (c10_0 == &crate::prelude::Text::lit("Vec")) => ::std::option::Option::Some(crate::prelude::Text::lit("::std::vec::Vec")),
        c11_0 if (c11_0 == &crate::prelude::Text::lit("String")) => ::std::option::Option::Some(crate::prelude::Text::lit("::std::string::String")),
        c12_0 if (c12_0 == &crate::prelude::Text::lit("Box")) => ::std::option::Option::Some(crate::prelude::Text::lit("::std::boxed::Box")),
        c13_0 if (c13_0 == &crate::prelude::Text::lit("Default")) => ::std::option::Option::Some(crate::prelude::Text::lit("::std::default::Default")),
        c14_0 if (c14_0 == &crate::prelude::Text::lit("Clone")) => ::std::option::Option::Some(crate::prelude::Text::lit("::std::clone::Clone")),
        c15_0 if (c15_0 == &crate::prelude::Text::lit("Eq")) => ::std::option::Option::Some(crate::prelude::Text::lit("::std::cmp::Eq")),
        c16_0 if (c16_0 == &crate::prelude::Text::lit("Ord")) => ::std::option::Option::Some(crate::prelude::Text::lit("::std::cmp::Ord")),
        other_p0 => ::std::option::Option::None,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Types: unbounded fn [OutTy] -> Text
/// ```
pub fn types_f(ts_p0: &crate::prelude::Array<crate::lower::model::OutTy>) -> crate::prelude::Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(ts_p0.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::OutTy| crate::prelude::entered(crate::prelude::once_job(move || {
        let t_p1 = p0;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(Type { t_p0: t_p1.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit(", "))
}

/// The step machine of `Types`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Types: unbounded fn [OutTy] -> Text
/// ```
pub struct Types {
    pub ts_p0: crate::prelude::Array<crate::lower::model::OutTy>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for Types {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let ts_p0 = &self.ts_p0;
        let ts_p0x = ts_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(ts_p0x.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::OutTy| crate::prelude::entered(crate::prelude::once_job(move || {
            let t_p1 = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(Type { t_p0: t_p1.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_5587: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join_f(&each_5587, &crate::prelude::Text::lit(", "))))
    }
}

/// `Start Types, x`: what the function value is when passed to `@Run`.
pub fn start_types_f(ts_p0: crate::prelude::Array<crate::lower::model::OutTy>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(Types { ts_p0 })
}

/// ```prism
/// RefTypes: unbounded fn [OutTy] -> Text
/// ```
pub fn ref_types_f(ts_p0: &crate::prelude::Array<crate::lower::model::OutTy>) -> crate::prelude::Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(ts_p0.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::OutTy| crate::prelude::entered(crate::prelude::once_job(move || {
        let t_p1 = p0;
        crate::prelude::call_then(start_type_f(t_p1.clone()), move |type_f_5695: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("&{}", &type_f_5695))))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit(", "))
}

/// The step machine of `RefTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RefTypes: unbounded fn [OutTy] -> Text
/// ```
pub struct RefTypes {
    pub ts_p0: crate::prelude::Array<crate::lower::model::OutTy>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for RefTypes {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let ts_p0 = &self.ts_p0;
        let ts_p0x = ts_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(ts_p0x.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::OutTy| crate::prelude::entered(crate::prelude::once_job(move || {
            let t_p1 = p0;
            crate::prelude::call_then(start_type_f(t_p1.clone()), move |type_f_5695: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("&{}", &type_f_5695))))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_5678: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join_f(&each_5678, &crate::prelude::Text::lit(", "))))
    }
}

/// `Start RefTypes, x`: what the function value is when passed to `@Run`.
pub fn start_ref_types_f(ts_p0: crate::prelude::Array<crate::lower::model::OutTy>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(RefTypes { ts_p0 })
}

/// ```prism
/// IsLoose: fn Ex -> Bool
/// ```
pub fn is_loose_f(x_p0: &crate::lower::model::Ex) -> bool {
    match x_p0 {
        crate::lower::model::Ex::XBlock(m6020_0_0, inner_p1) if (m6020_0_0.len() == 0) => is_loose_f(&**inner_p1),
        crate::lower::model::Ex::XTyped(inner_p2, _) => is_loose_f(&**inner_p2),
        crate::lower::model::Ex::XBin(_, _, _) => true,
        crate::lower::model::Ex::XUnary(_, _) => true,
        crate::lower::model::Ex::XClosure(_, _, _) => true,
        crate::lower::model::Ex::XIf(_, _, _) => true,
        crate::lower::model::Ex::XMatch(_, _, _, _) => true,
        crate::lower::model::Ex::XChain(_, _, _, _) => true,
        crate::lower::model::Ex::XCast(_, _) => true,
        crate::lower::model::Ex::XRef(_) => true,
        crate::lower::model::Ex::XRefMut(_) => true,
        crate::lower::model::Ex::XDeref(_) => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Tight: unbounded fn Ex -> Text
/// ```
pub fn tight_f(x_p0: &crate::lower::model::Ex) -> crate::prelude::Text {
    if is_loose_f(x_p0) {
        crate::prelude::Text::from(format!("({})", &expression_f(x_p0)))
    } else {
        expression_f(x_p0)
    }
}

/// The step machine of `Tight`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Tight: unbounded fn Ex -> Text
/// ```
pub struct Tight {
    pub x_p0: crate::lower::model::Ex,
}

impl ::prism_rtl::Job<crate::prelude::Text> for Tight {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let x_p0 = &self.x_p0;
        if is_loose_f(x_p0) {
            {
                let x_p0x = x_p0.clone();
                crate::prelude::call_then(start_expression_f(x_p0x.clone()), move |expression_f_6537: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("({})", &expression_f_6537))))
            }
        } else {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(Expression { x_p0: x_p0.clone() }))
        }
    }
}

/// `Start Tight, x`: what the function value is when passed to `@Run`.
pub fn start_tight_f(x_p0: crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(Tight { x_p0 })
}

/// ```prism
/// Operand: unbounded fn Ex -> Text
/// ```
pub fn operand_f(x_p0: &crate::lower::model::Ex) -> crate::prelude::Text {
    match x_p0 {
        crate::lower::model::Ex::XBlock(m6621_0_0, inner_p1) if (m6621_0_0.len() == 0) => operand_f(&**inner_p1),
        crate::lower::model::Ex::XTyped(inner_p2, _) => operand_f(&**inner_p2),
        crate::lower::model::Ex::XBin(_, _, _) => crate::prelude::Text::from(format!("({})", &expression_f(x_p0))),
        crate::lower::model::Ex::XClosure(_, _, _) => crate::prelude::Text::from(format!("({})", &expression_f(x_p0))),
        crate::lower::model::Ex::XIf(_, _, _) => crate::prelude::Text::from(format!("({})", &expression_f(x_p0))),
        crate::lower::model::Ex::XCast(_, _) => crate::prelude::Text::from(format!("({})", &expression_f(x_p0))),
        _ => expression_f(x_p0),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `Operand`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Operand: unbounded fn Ex -> Text
/// ```
pub struct Operand {
    pub x_p0: crate::lower::model::Ex,
}

impl ::prism_rtl::Job<crate::prelude::Text> for Operand {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let x_p0 = &self.x_p0;
        match x_p0 {
            crate::lower::model::Ex::XBlock(m6621_0_0, inner_p1) if (m6621_0_0.len() == 0) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Operand { x_p0: (**inner_p1).clone() })),
            crate::lower::model::Ex::XTyped(inner_p2, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Operand { x_p0: (**inner_p2).clone() })),
            crate::lower::model::Ex::XBin(_, _, _) => {
                let x_p0x = x_p0.clone();
                crate::prelude::call_then(start_expression_f(x_p0x.clone()), move |expression_f_6744: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("({})", &expression_f_6744))))
            },
            crate::lower::model::Ex::XClosure(_, _, _) => {
                let x_p0x = x_p0.clone();
                crate::prelude::call_then(start_expression_f(x_p0x.clone()), move |expression_f_6800: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("({})", &expression_f_6800))))
            },
            crate::lower::model::Ex::XIf(_, _, _) => {
                let x_p0x = x_p0.clone();
                crate::prelude::call_then(start_expression_f(x_p0x.clone()), move |expression_f_6851: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("({})", &expression_f_6851))))
            },
            crate::lower::model::Ex::XCast(_, _) => {
                let x_p0x = x_p0.clone();
                crate::prelude::call_then(start_expression_f(x_p0x.clone()), move |expression_f_6896: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("({})", &expression_f_6896))))
            },
            _ => ::prism_rtl::Turn::More(::std::rc::Rc::new(Expression { x_p0: x_p0.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start Operand, x`: what the function value is when passed to `@Run`.
pub fn start_operand_f(x_p0: crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(Operand { x_p0 })
}

/// ```prism
/// Args: unbounded fn [Ex] -> Text
/// ```
pub fn args_f(xs_p0: &crate::prelude::Array<crate::lower::model::Ex>) -> crate::prelude::Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(xs_p0.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Ex| crate::prelude::entered(crate::prelude::once_job(move || {
        let x_p1 = p0;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(Expression { x_p0: x_p1.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit(", "))
}

/// The step machine of `Args`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Args: unbounded fn [Ex] -> Text
/// ```
pub struct Args {
    pub xs_p0: crate::prelude::Array<crate::lower::model::Ex>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for Args {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let xs_p0 = &self.xs_p0;
        let xs_p0x = xs_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(xs_p0x.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Ex| crate::prelude::entered(crate::prelude::once_job(move || {
            let x_p1 = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(Expression { x_p0: x_p1.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_6992: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join_f(&each_6992, &crate::prelude::Text::lit(", "))))
    }
}

/// `Start Args, x`: what the function value is when passed to `@Run`.
pub fn start_args_f(xs_p0: crate::prelude::Array<crate::lower::model::Ex>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(Args { xs_p0 })
}

/// ```prism
/// Expression: unbounded fn Ex -> Text
/// ```
pub fn expression_f(x_p0: &crate::lower::model::Ex) -> crate::prelude::Text {
    'm7081: {
        if let crate::lower::model::Ex::XVar(n_p1) = x_p0 {
            break 'm7081 n_p1.clone();
        }
        if let crate::lower::model::Ex::XPath(p_p2) = x_p0 {
            break 'm7081 rs_ref_f(p_p2);
        }
        if let crate::lower::model::Ex::XSelf = x_p0 {
            break 'm7081 crate::prelude::Text::lit("self");
        }
        if let crate::lower::model::Ex::XCx = x_p0 {
            break 'm7081 crate::prelude::Text::lit("cx");
        }
        if let crate::lower::model::Ex::XConst(n_p3) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("Self::{}", n_p3));
        }
        if let crate::lower::model::Ex::XUnit = x_p0 {
            break 'm7081 crate::prelude::Text::lit("()");
        }
        if let crate::lower::model::Ex::XNone = x_p0 {
            break 'm7081 crate::prelude::Text::lit("::std::option::Option::None");
        }
        if let crate::lower::model::Ex::XBool(b_p4) = x_p0 {
            break 'm7081 if *b_p4 {
                crate::prelude::Text::lit("true")
            } else {
                crate::prelude::Text::lit("false")
            };
        }
        if let crate::lower::model::Ex::XNat(d_p5) = x_p0 {
            break 'm7081 if &crate::prelude::len_text(d_p5) <= &crate::prelude::Nat::from(9u32) {
                crate::prelude::Text::from(format!("crate::prelude::Nat::from({}u32)", d_p5))
            } else {
                if &crate::prelude::len_text(d_p5) <= &crate::prelude::Nat::from(18u32) {
                    crate::prelude::Text::from(format!("crate::prelude::Nat::from_int(crate::prelude::Int::from({}i64)).unwrap()", d_p5))
                } else {
                    crate::prelude::Text::from(format!("crate::prelude::Nat::from_int(crate::prelude::Int::parse(\"{}\").unwrap()).unwrap()", d_p5))
                }
            };
        }
        if let crate::lower::model::Ex::XInt(d_p6) = x_p0 {
            break 'm7081 if &crate::prelude::len_text(&(if crate::syntax::lexer::chars::has_prefix_f(d_p6, &crate::prelude::Text::lit("-")) {
                crate::syntax::lexer::chars::after_first_f(d_p6)
            } else {
                d_p6.clone()
            })) <= &crate::prelude::Nat::from(18u32) {
                crate::prelude::Text::from(format!("crate::prelude::Int::from({})", d_p6))
            } else {
                crate::prelude::Text::from(format!("crate::prelude::Int::parse(\"{}\").unwrap()", d_p6))
            };
        }
        if let crate::lower::model::Ex::XByte(d_p7) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("{}u8", d_p7));
        }
        if let crate::lower::model::Ex::XFloat(d_p8) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("crate::prelude::Float({})", d_p8));
        }
        if let crate::lower::model::Ex::XDuration(n_p9) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("crate::prelude::Duration({})", n_p9));
        }
        if let crate::lower::model::Ex::XIndex(n_pa) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("{}", n_pa));
        }
        if let crate::lower::model::Ex::XChar(c_pb) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("\'{}\'", &crate::lower::expr::char_escape_f(c_pb)));
        }
        if let crate::lower::model::Ex::XStr(t_pc) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("\"{}\"", &crate::lower::expr::escape_f(t_pc)));
        }
        if let crate::lower::model::Ex::XRegex(p_pd, f_pe) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("{{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit(\"{}\", \"{}\")); R.with(crate::prelude::Regex::clone) }}", &crate::lower::expr::escape_f(p_pd), &crate::lower::expr::escape_f(f_pe)));
        }
        if let crate::lower::model::Ex::XReplacement(p_pf, r_pg, f_ph) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("{{ thread_local!(static R: crate::prelude::RegexReplacement = crate::prelude::RegexReplacement::lit(\"{}\", \"{}\", \"{}\")); R.with(crate::prelude::RegexReplacement::clone) }}", &crate::lower::expr::escape_f(p_pf), &crate::lower::expr::escape_f(f_ph), &crate::lower::expr::escape_f(r_pg)));
        }
        if let crate::lower::model::Ex::XRef(y_pi) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("&{}", &operand_f(&**y_pi)));
        }
        if let crate::lower::model::Ex::XRefMut(y_pj) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("&mut {}", &operand_f(&**y_pj)));
        }
        if let crate::lower::model::Ex::XDeref(y_pk) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("*{}", &operand_f(&**y_pk)));
        }
        if let crate::lower::model::Ex::XTarget(y_pl) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("(*{})", &expression_f(&**y_pl)));
        }
        if let crate::lower::model::Ex::XClone(y_pm) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("{}.clone()", &tight_f(&**y_pm)));
        }
        if let crate::lower::model::Ex::XWeak(y_pn) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("::std::rc::Rc::downgrade({})", &expression_f(&**y_pn)));
        }
        if let crate::lower::model::Ex::XUpgrade(y_po) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("{}.upgrade()", &tight_f(&**y_po)));
        }
        if let crate::lower::model::Ex::XBreak(l_pp, y_pq) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("break {} {}", &label_f(l_pp), &expression_f(&**y_pq)));
        }
        if let crate::lower::model::Ex::XBreakLoop = x_p0 {
            break 'm7081 crate::prelude::Text::lit("break");
        }
        if let crate::lower::model::Ex::XLater(y_pr) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("::std::boxed::Box::new(move |cx| {{ {}; ::std::result::Result::Ok(()) }})", &expression_f(&**y_pr)));
        }
        if let crate::lower::model::Ex::XFormatStr(parts_ps) = x_p0 {
            break 'm7081 format_str_f(parts_ps);
        }
        if let crate::lower::model::Ex::XIsCase(y_pt, m7081_29_1) = x_p0 && (m7081_29_1.len() == 0) {
            break 'm7081 crate::prelude::Text::lit("false");
        }
        if let crate::lower::model::Ex::XIsCase(y_pu, cs_pv) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("matches!({}, {})", &expression_f(&**y_pu), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(cs_pv, &(|c_p10: &crate::lower::model::Ref| crate::prelude::Text::from(format!("{}(..)", &rs_ref_f(c_p10))))), &crate::prelude::Text::lit(" | "))));
        }
        if let crate::lower::model::Ex::XRefusal(what_p11) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::expr::lowering_refusal_p(), &crate::lower::expr::escape_f(what_p11)));
        }
        if let crate::lower::model::Ex::XUnreachable = x_p0 {
            break 'm7081 crate::prelude::Text::lit("unreachable!()");
        }
        if let crate::lower::model::Ex::XCall(f_p12, args_p13) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("{}({})", &rs_ref_f(f_p12), &args_f(args_p13)));
        }
        if let crate::lower::model::Ex::XCallAt(f_p14, tys_p15, args_p16) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("{}::<{}>({})", &rs_ref_f(f_p14), &types_f(tys_p15), &args_f(args_p16)));
        }
        if let crate::lower::model::Ex::XCallSelf(tr_p17, m_p18, self_p19, args_p1a) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("<{} as {}>::{}({})", &type_f(self_p19), &rs_ref_f(tr_p17), m_p18, &args_f(args_p1a)));
        }
        if let crate::lower::model::Ex::XApply(m7081_36_0, args_p1d) = x_p0 && let crate::lower::model::Ex::XField(r_p1b, n_p1c) = &**m7081_36_0 {
            break 'm7081 crate::prelude::Text::from(format!("({})({})", &expression_f(&crate::lower::model::Ex::XField(::std::rc::Rc::new((**r_p1b).clone()), n_p1c.clone())), &args_f(args_p1d)));
        }
        if let crate::lower::model::Ex::XApply(f_p1e, args_p1f) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("{}({})", &tight_f(&**f_p1e), &args_f(args_p1f)));
        }
        if let crate::lower::model::Ex::XMethod(r_p1g, m_p1h, args_p1i) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("{}.{}({})", &tight_f(&**r_p1g), m_p1h, &args_f(args_p1i)));
        }
        if let crate::lower::model::Ex::XBin(op_p1j, l_p1k, r_p1l) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("{} {} {}", &operand_f(&**l_p1k), &crate::lower::model::bin_op_text_f(op_p1j), &operand_f(&**r_p1l)));
        }
        if let crate::lower::model::Ex::XUnary(op_p1m, y_p1n) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("{}{}", &crate::lower::model::un_op_text_f(op_p1m), &operand_f(&**y_p1n)));
        }
        if let crate::lower::model::Ex::XCtor(p_p1o, args_p1p) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("{}({})", &rs_ref_f(p_p1o), &args_f(args_p1p)));
        }
        if let crate::lower::model::Ex::XRecord(p_p1q, fs_p1r) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("{} {{ {} }}", &rs_ref_f(p_p1q), &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(fs_p1r.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::Ex)| crate::prelude::entered(crate::prelude::once_job(move || {
                let (f_p1s, v_p1t) = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(FieldInit { f_p0: f_p1s.clone(), ex1: v_p1t.clone() }))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit(", "))));
        }
        if let crate::lower::model::Ex::XTuple(m7081_43_0) = x_p0 && (m7081_43_0.len() == 1) && let ::std::option::Option::Some(one_p1u) = crate::prelude::index(m7081_43_0, &crate::prelude::Nat::from(0u32)) {
            break 'm7081 crate::prelude::Text::from(format!("({},)", &expression_f(&one_p1u)));
        }
        if let crate::lower::model::Ex::XTuple(xs_p1v) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("({})", &args_f(xs_p1v)));
        }
        if let crate::lower::model::Ex::XVec(xs_p20) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("vec![{}]", &args_f(xs_p20)));
        }
        if let crate::lower::model::Ex::XText(t_p21) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("crate::prelude::Text::lit(\"{}\")", &crate::lower::expr::escape_f(t_p21)));
        }
        if let crate::lower::model::Ex::XFormat(parts_p22) = x_p0 {
            break 'm7081 format_f(parts_p22);
        }
        if let crate::lower::model::Ex::XMatch(s_p23, arms_p24, fallback_p25, _) = x_p0 {
            break 'm7081 crate::emit::rust::templates::items::match_block_f(&expression_f(&**s_p23), &arms_f(arms_p24, fallback_p25));
        }
        if let crate::lower::model::Ex::XChain(label_p26, s_p27, arms_p28, _) = x_p0 {
            break 'm7081 chain_f(&label_f(label_p26), &**s_p27, arms_p28);
        }
        if let crate::lower::model::Ex::XIf(c_p29, t_p2a, e_p2b) = x_p0 {
            break 'm7081 if_expression_f(&**c_p29, &**t_p2a, &**e_p2b);
        }
        if let crate::lower::model::Ex::XBlock(m7081_51_0, e_p2c) = x_p0 && (m7081_51_0.len() == 0) {
            break 'm7081 expression_f(&**e_p2c);
        }
        if let crate::lower::model::Ex::XBlock(dos_p2d, e_p2e) = x_p0 {
            break 'm7081 crate::emit::rust::templates::items::block_f(&statements_f(dos_p2d), &expression_f(&**e_p2e));
        }
        if let crate::lower::model::Ex::XLabeled(label_p2f, dos_p2g, e_p2h, _) = x_p0 {
            break 'm7081 crate::emit::rust::templates::items::labeled_f(&label_f(label_p2f), &statements_f(dos_p2g), &expression_f(&**e_p2h));
        }
        if let crate::lower::model::Ex::XClosure(mv_p2i, ps_p2j, body_p2k) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("{}|{}| {}", &(if *mv_p2i {
                crate::prelude::Text::lit("move ")
            } else {
                crate::prelude::Text::lit("")
            }), &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(ps_p2j.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Pa| crate::prelude::entered(crate::prelude::once_job(move || {
                let p_p2l = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(Pattern { p_p0: p_p2l.clone() }))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Pa) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit(", ")), &expression_f(&**body_p2k)));
        }
        if let crate::lower::model::Ex::XTry(y_p2m) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("{}?", &tight_f(&**y_p2m)));
        }
        if let crate::lower::model::Ex::XField(r_p2n, f_p2o) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("{}.{}", &tight_f(&**r_p2n), f_p2o));
        }
        if let crate::lower::model::Ex::XFieldOf(r_p2p, _, f_p2q) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("{}.{}", &tight_f(&**r_p2p), f_p2q));
        }
        if let crate::lower::model::Ex::XPart(r_p2r, k_p2s) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("{}.{}", &tight_f(&**r_p2r), k_p2s));
        }
        if let crate::lower::model::Ex::XDecode(t_p2t, y_p2u) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("{}::from_pod({})?", &decode_head_f(t_p2t), &expression_f(&**y_p2u)));
        }
        if let crate::lower::model::Ex::XCast(y_p2v, t_p30) = x_p0 {
            break 'm7081 crate::prelude::Text::from(format!("{} as {}", &tight_f(&**y_p2v), &type_f(t_p30)));
        }
        if let crate::lower::model::Ex::XTyped(y_p31, _) = x_p0 {
            break 'm7081 expression_f(&**y_p31);
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `Expression`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Expression: unbounded fn Ex -> Text
/// ```
pub struct Expression {
    pub x_p0: crate::lower::model::Ex,
}

impl ::prism_rtl::Job<crate::prelude::Text> for Expression {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let x_p0 = &self.x_p0;
        'm7081: {
            if let crate::lower::model::Ex::XVar(n_p1) = x_p0 {
                break 'm7081 ::prism_rtl::Turn::Finished(n_p1.clone());
            }
            if let crate::lower::model::Ex::XPath(p_p2) = x_p0 {
                break 'm7081 ::prism_rtl::Turn::Finished(rs_ref_f(p_p2));
            }
            if let crate::lower::model::Ex::XSelf = x_p0 {
                break 'm7081 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("self"));
            }
            if let crate::lower::model::Ex::XCx = x_p0 {
                break 'm7081 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("cx"));
            }
            if let crate::lower::model::Ex::XConst(n_p3) = x_p0 {
                break 'm7081 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("Self::{}", n_p3)));
            }
            if let crate::lower::model::Ex::XUnit = x_p0 {
                break 'm7081 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("()"));
            }
            if let crate::lower::model::Ex::XNone = x_p0 {
                break 'm7081 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("::std::option::Option::None"));
            }
            if let crate::lower::model::Ex::XBool(b_p4) = x_p0 {
                break 'm7081 if *b_p4 {
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("true"))
                } else {
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("false"))
                };
            }
            if let crate::lower::model::Ex::XNat(d_p5) = x_p0 {
                break 'm7081 if &crate::prelude::len_text(d_p5) <= &crate::prelude::Nat::from(9u32) {
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Nat::from({}u32)", d_p5)))
                } else {
                    if &crate::prelude::len_text(d_p5) <= &crate::prelude::Nat::from(18u32) {
                        ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Nat::from_int(crate::prelude::Int::from({}i64)).unwrap()", d_p5)))
                    } else {
                        ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Nat::from_int(crate::prelude::Int::parse(\"{}\").unwrap()).unwrap()", d_p5)))
                    }
                };
            }
            if let crate::lower::model::Ex::XInt(d_p6) = x_p0 {
                break 'm7081 if &crate::prelude::len_text(&(if crate::syntax::lexer::chars::has_prefix_f(d_p6, &crate::prelude::Text::lit("-")) {
                    crate::syntax::lexer::chars::after_first_f(d_p6)
                } else {
                    d_p6.clone()
                })) <= &crate::prelude::Nat::from(18u32) {
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Int::from({})", d_p6)))
                } else {
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Int::parse(\"{}\").unwrap()", d_p6)))
                };
            }
            if let crate::lower::model::Ex::XByte(d_p7) = x_p0 {
                break 'm7081 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}u8", d_p7)));
            }
            if let crate::lower::model::Ex::XFloat(d_p8) = x_p0 {
                break 'm7081 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Float({})", d_p8)));
            }
            if let crate::lower::model::Ex::XDuration(n_p9) = x_p0 {
                break 'm7081 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Duration({})", n_p9)));
            }
            if let crate::lower::model::Ex::XIndex(n_pa) = x_p0 {
                break 'm7081 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}", n_pa)));
            }
            if let crate::lower::model::Ex::XChar(c_pb) = x_p0 {
                break 'm7081 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("\'{}\'", &crate::lower::expr::char_escape_f(c_pb))));
            }
            if let crate::lower::model::Ex::XStr(t_pc) = x_p0 {
                break 'm7081 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("\"{}\"", &crate::lower::expr::escape_f(t_pc))));
            }
            if let crate::lower::model::Ex::XRegex(p_pd, f_pe) = x_p0 {
                break 'm7081 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit(\"{}\", \"{}\")); R.with(crate::prelude::Regex::clone) }}", &crate::lower::expr::escape_f(p_pd), &crate::lower::expr::escape_f(f_pe))));
            }
            if let crate::lower::model::Ex::XReplacement(p_pf, r_pg, f_ph) = x_p0 {
                break 'm7081 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{{ thread_local!(static R: crate::prelude::RegexReplacement = crate::prelude::RegexReplacement::lit(\"{}\", \"{}\", \"{}\")); R.with(crate::prelude::RegexReplacement::clone) }}", &crate::lower::expr::escape_f(p_pf), &crate::lower::expr::escape_f(f_ph), &crate::lower::expr::escape_f(r_pg))));
            }
            if let crate::lower::model::Ex::XRef(y_pi) = x_p0 {
                break 'm7081 {
                    let y_pix = (**y_pi).clone();
                    crate::prelude::call_then(start_operand_f(y_pix.clone()), move |operand_f_8483: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("&{}", &operand_f_8483))))
                };
            }
            if let crate::lower::model::Ex::XRefMut(y_pj) = x_p0 {
                break 'm7081 {
                    let y_pjx = (**y_pj).clone();
                    crate::prelude::call_then(start_operand_f(y_pjx.clone()), move |operand_f_8517: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("&mut {}", &operand_f_8517))))
                };
            }
            if let crate::lower::model::Ex::XDeref(y_pk) = x_p0 {
                break 'm7081 {
                    let y_pkx = (**y_pk).clone();
                    crate::prelude::call_then(start_operand_f(y_pkx.clone()), move |operand_f_8546: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("*{}", &operand_f_8546))))
                };
            }
            if let crate::lower::model::Ex::XTarget(y_pl) = x_p0 {
                break 'm7081 {
                    let y_plx = (**y_pl).clone();
                    crate::prelude::call_then(start_expression_f(y_plx.clone()), move |expression_f_8577: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("(*{})", &expression_f_8577))))
                };
            }
            if let crate::lower::model::Ex::XClone(y_pm) = x_p0 {
                break 'm7081 {
                    let y_pmx = (**y_pm).clone();
                    crate::prelude::call_then(start_tight_f(y_pmx.clone()), move |tight_f_8609: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}.clone()", &tight_f_8609))))
                };
            }
            if let crate::lower::model::Ex::XWeak(y_pn) = x_p0 {
                break 'm7081 {
                    let y_pnx = (**y_pn).clone();
                    crate::prelude::call_then(start_expression_f(y_pnx.clone()), move |expression_f_8667: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::std::rc::Rc::downgrade({})", &expression_f_8667))))
                };
            }
            if let crate::lower::model::Ex::XUpgrade(y_po) = x_p0 {
                break 'm7081 {
                    let y_pox = (**y_po).clone();
                    crate::prelude::call_then(start_tight_f(y_pox.clone()), move |tight_f_8701: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}.upgrade()", &tight_f_8701))))
                };
            }
            if let crate::lower::model::Ex::XBreak(l_pp, y_pq) = x_p0 {
                break 'm7081 {
                    let l_ppx = l_pp.clone();
                    let y_pqx = (**y_pq).clone();
                    crate::prelude::call_then(start_expression_f(y_pqx.clone()), move |expression_f_8756: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("break {} {}", &label_f(&l_ppx), &expression_f_8756))))
                };
            }
            if let crate::lower::model::Ex::XBreakLoop = x_p0 {
                break 'm7081 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("break"));
            }
            if let crate::lower::model::Ex::XLater(y_pr) = x_p0 {
                break 'm7081 {
                    let y_prx = (**y_pr).clone();
                    crate::prelude::call_then(start_expression_f(y_prx.clone()), move |expression_f_8847: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("::std::boxed::Box::new(move |cx| {{ {}; ::std::result::Result::Ok(()) }})", &expression_f_8847))))
                };
            }
            if let crate::lower::model::Ex::XFormatStr(parts_ps) = x_p0 {
                break 'm7081 ::prism_rtl::Turn::More(::std::rc::Rc::new(FormatStr { parts_p0: parts_ps.clone() }));
            }
            if let crate::lower::model::Ex::XIsCase(y_pt, m7081_29_1) = x_p0 && (m7081_29_1.len() == 0) {
                break 'm7081 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("false"));
            }
            if let crate::lower::model::Ex::XIsCase(y_pu, cs_pv) = x_p0 {
                break 'm7081 {
                    let cs_pvx = cs_pv.clone();
                    let y_pux = (**y_pu).clone();
                    crate::prelude::call_then(start_expression_f(y_pux.clone()), move |expression_f_8994: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("matches!({}, {})", &expression_f_8994, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&cs_pvx, &(|c_p10: &crate::lower::model::Ref| crate::prelude::Text::from(format!("{}(..)", &rs_ref_f(c_p10))))), &crate::prelude::Text::lit(" | "))))))
                };
            }
            if let crate::lower::model::Ex::XRefusal(what_p11) = x_p0 {
                break 'm7081 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::expr::lowering_refusal_p(), &crate::lower::expr::escape_f(what_p11))));
            }
            if let crate::lower::model::Ex::XUnreachable = x_p0 {
                break 'm7081 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("unreachable!()"));
            }
            if let crate::lower::model::Ex::XCall(f_p12, args_p13) = x_p0 {
                break 'm7081 {
                    let args_p13x = args_p13.clone();
                    let f_p12x = f_p12.clone();
                    crate::prelude::call_then(start_args_f(args_p13x.clone()), move |args_f_9195: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}({})", &rs_ref_f(&f_p12x), &args_f_9195))))
                };
            }
            if let crate::lower::model::Ex::XCallAt(f_p14, tys_p15, args_p16) = x_p0 {
                break 'm7081 {
                    let args_p16x = args_p16.clone();
                    let f_p14x = f_p14.clone();
                    let tys_p15x = tys_p15.clone();
                    crate::prelude::call_then(start_types_f(tys_p15x.clone()), move |types_f_9248: crate::prelude::Text| crate::prelude::call_then(start_args_f(args_p16x.clone()), move |args_f_9261: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}::<{}>({})", &rs_ref_f(&f_p14x), &types_f_9248, &args_f_9261)))))
                };
            }
            if let crate::lower::model::Ex::XCallSelf(tr_p17, m_p18, self_p19, args_p1a) = x_p0 {
                break 'm7081 {
                    let args_p1ax = args_p1a.clone();
                    let m_p18x = m_p18.clone();
                    let self_p19x = self_p19.clone();
                    let tr_p17x = tr_p17.clone();
                    crate::prelude::call_then(start_type_f(self_p19x.clone()), move |type_f_9310: crate::prelude::Text| crate::prelude::call_then(start_args_f(args_p1ax.clone()), move |args_f_9342: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("<{} as {}>::{}({})", &type_f_9310, &rs_ref_f(&tr_p17x), &m_p18x, &args_f_9342)))))
                };
            }
            if let crate::lower::model::Ex::XApply(m7081_36_0, args_p1d) = x_p0 && let crate::lower::model::Ex::XField(r_p1b, n_p1c) = &**m7081_36_0 {
                break 'm7081 {
                    let args_p1dx = args_p1d.clone();
                    let n_p1cx = n_p1c.clone();
                    let r_p1bx = (**r_p1b).clone();
                    crate::prelude::call_then(start_expression_f(crate::lower::model::Ex::XField(::std::rc::Rc::new(r_p1bx.clone()), n_p1cx.clone())), move |expression_f_9480: crate::prelude::Text| crate::prelude::call_then(start_args_f(args_p1dx.clone()), move |args_f_9508: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("({})({})", &expression_f_9480, &args_f_9508)))))
                };
            }
            if let crate::lower::model::Ex::XApply(f_p1e, args_p1f) = x_p0 {
                break 'm7081 {
                    let args_p1fx = args_p1f.clone();
                    let f_p1ex = (**f_p1e).clone();
                    crate::prelude::call_then(start_tight_f(f_p1ex.clone()), move |tight_f_9543: crate::prelude::Text| crate::prelude::call_then(start_args_f(args_p1fx.clone()), move |args_f_9553: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}({})", &tight_f_9543, &args_f_9553)))))
                };
            }
            if let crate::lower::model::Ex::XMethod(r_p1g, m_p1h, args_p1i) = x_p0 {
                break 'm7081 {
                    let args_p1ix = args_p1i.clone();
                    let m_p1hx = m_p1h.clone();
                    let r_p1gx = (**r_p1g).clone();
                    crate::prelude::call_then(start_tight_f(r_p1gx.clone()), move |tight_f_9592: crate::prelude::Text| crate::prelude::call_then(start_args_f(args_p1ix.clone()), move |args_f_9606: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}.{}({})", &tight_f_9592, &m_p1hx, &args_f_9606)))))
                };
            }
            if let crate::lower::model::Ex::XBin(op_p1j, l_p1k, r_p1l) = x_p0 {
                break 'm7081 {
                    let l_p1kx = (**l_p1k).clone();
                    let op_p1jx = op_p1j.clone();
                    let r_p1lx = (**r_p1l).clone();
                    crate::prelude::call_then(start_operand_f(l_p1kx.clone()), move |operand_f_9640: crate::prelude::Text| crate::prelude::call_then(start_operand_f(r_p1lx.clone()), move |operand_f_9667: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {} {}", &operand_f_9640, &crate::lower::model::bin_op_text_f(&op_p1jx), &operand_f_9667)))))
                };
            }
            if let crate::lower::model::Ex::XUnary(op_p1m, y_p1n) = x_p0 {
                break 'm7081 {
                    let op_p1mx = op_p1m.clone();
                    let y_p1nx = (**y_p1n).clone();
                    crate::prelude::call_then(start_operand_f(y_p1nx.clone()), move |operand_f_9712: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{}", &crate::lower::model::un_op_text_f(&op_p1mx), &operand_f_9712))))
                };
            }
            if let crate::lower::model::Ex::XCtor(p_p1o, args_p1p) = x_p0 {
                break 'm7081 {
                    let args_p1px = args_p1p.clone();
                    let p_p1ox = p_p1o.clone();
                    crate::prelude::call_then(start_args_f(args_p1px.clone()), move |args_f_9755: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}({})", &rs_ref_f(&p_p1ox), &args_f_9755))))
                };
            }
            if let crate::lower::model::Ex::XRecord(p_p1q, fs_p1r) = x_p0 {
                break 'm7081 {
                    let fs_p1rx = fs_p1r.clone();
                    let p_p1qx = p_p1q.clone();
                    crate::prelude::call_value(crate::prelude::each_job(fs_p1rx.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::Ex)| crate::prelude::entered(crate::prelude::once_job(move || {
                        let (f_p1s, v_p1t) = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(FieldInit { f_p0: f_p1s.clone(), ex1: v_p1t.clone() }))
                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::Ex)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_9808: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {{ {} }}", &rs_ref_f(&p_p1qx), &crate::syntax::lexer::chars::join_f(&each_9808, &crate::prelude::Text::lit(", "))))))
                };
            }
            if let crate::lower::model::Ex::XTuple(m7081_43_0) = x_p0 && (m7081_43_0.len() == 1) && let ::std::option::Option::Some(one_p1u) = crate::prelude::index(m7081_43_0, &crate::prelude::Nat::from(0u32)) {
                break 'm7081 crate::prelude::call_then(start_expression_f(one_p1u.clone()), move |expression_f_9879: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("({},)", &expression_f_9879))));
            }
            if let crate::lower::model::Ex::XTuple(xs_p1v) = x_p0 {
                break 'm7081 {
                    let xs_p1vx = xs_p1v.clone();
                    crate::prelude::call_then(start_args_f(xs_p1vx.clone()), move |args_f_9916: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("({})", &args_f_9916))))
                };
            }
            if let crate::lower::model::Ex::XVec(xs_p20) = x_p0 {
                break 'm7081 {
                    let xs_p20x = xs_p20.clone();
                    crate::prelude::call_then(start_args_f(xs_p20x.clone()), move |args_f_9947: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("vec![{}]", &args_f_9947))))
                };
            }
            if let crate::lower::model::Ex::XText(t_p21) = x_p0 {
                break 'm7081 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Text::lit(\"{}\")", &crate::lower::expr::escape_f(t_p21))));
            }
            if let crate::lower::model::Ex::XFormat(parts_p22) = x_p0 {
                break 'm7081 ::prism_rtl::Turn::More(::std::rc::Rc::new(Format { parts_p0: parts_p22.clone() }));
            }
            if let crate::lower::model::Ex::XMatch(s_p23, arms_p24, fallback_p25, _) = x_p0 {
                break 'm7081 {
                    let arms_p24x = arms_p24.clone();
                    let fallback_p25x = *fallback_p25;
                    let s_p23x = (**s_p23).clone();
                    crate::prelude::call_then(start_expression_f(s_p23x.clone()), move |expression_f_10097: crate::prelude::Text| crate::prelude::call_then(start_arms_f(arms_p24x.clone(), fallback_p25x), move |arms_f_10113: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::match_block_f(&expression_f_10097, &arms_f_10113))))
                };
            }
            if let crate::lower::model::Ex::XChain(label_p26, s_p27, arms_p28, _) = x_p0 {
                break 'm7081 ::prism_rtl::Turn::More(::std::rc::Rc::new(Chain { label_p0: label_f(label_p26), s_p1: (**s_p27).clone(), arms_p2: arms_p28.clone() }));
            }
            if let crate::lower::model::Ex::XIf(c_p29, t_p2a, e_p2b) = x_p0 {
                break 'm7081 ::prism_rtl::Turn::More(::std::rc::Rc::new(IfExpression { c_p0: (**c_p29).clone(), t_p1: (**t_p2a).clone(), e_p2: (**e_p2b).clone() }));
            }
            if let crate::lower::model::Ex::XBlock(m7081_51_0, e_p2c) = x_p0 && (m7081_51_0.len() == 0) {
                break 'm7081 ::prism_rtl::Turn::More(::std::rc::Rc::new(Expression { x_p0: (**e_p2c).clone() }));
            }
            if let crate::lower::model::Ex::XBlock(dos_p2d, e_p2e) = x_p0 {
                break 'm7081 {
                    let dos_p2dx = dos_p2d.clone();
                    let e_p2ex = (**e_p2e).clone();
                    crate::prelude::call_then(start_statements_f(dos_p2dx.clone()), move |statements_f_10295: crate::prelude::Text| crate::prelude::call_then(start_expression_f(e_p2ex.clone()), move |expression_f_10313: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::block_f(&statements_f_10295, &expression_f_10313))))
                };
            }
            if let crate::lower::model::Ex::XLabeled(label_p2f, dos_p2g, e_p2h, _) = x_p0 {
                break 'm7081 {
                    let dos_p2gx = dos_p2g.clone();
                    let e_p2hx = (**e_p2h).clone();
                    let label_p2fx = label_p2f.clone();
                    crate::prelude::call_then(start_statements_f(dos_p2gx.clone()), move |statements_f_10387: crate::prelude::Text| crate::prelude::call_then(start_expression_f(e_p2hx.clone()), move |expression_f_10405: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::labeled_f(&label_f(&label_p2fx), &statements_f_10387, &expression_f_10405))))
                };
            }
            if let crate::lower::model::Ex::XClosure(mv_p2i, ps_p2j, body_p2k) = x_p0 {
                break 'm7081 {
                    let body_p2kx = (**body_p2k).clone();
                    let mv_p2ix = *mv_p2i;
                    let ps_p2jx = ps_p2j.clone();
                    crate::prelude::call_value(crate::prelude::each_job(ps_p2jx.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Pa| crate::prelude::entered(crate::prelude::once_job(move || {
                        let p_p2l = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(Pattern { p_p0: p_p2l.clone() }))
                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Pa) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_10480: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(start_expression_f(body_p2kx.clone()), move |expression_f_10514: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}|{}| {}", &(if mv_p2ix {
                        crate::prelude::Text::lit("move ")
                    } else {
                        crate::prelude::Text::lit("")
                    }), &crate::syntax::lexer::chars::join_f(&each_10480, &crate::prelude::Text::lit(", ")), &expression_f_10514)))))
                };
            }
            if let crate::lower::model::Ex::XTry(y_p2m) = x_p0 {
                break 'm7081 {
                    let y_p2mx = (**y_p2m).clone();
                    crate::prelude::call_then(start_tight_f(y_p2mx.clone()), move |tight_f_10546: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}?", &tight_f_10546))))
                };
            }
            if let crate::lower::model::Ex::XField(r_p2n, f_p2o) = x_p0 {
                break 'm7081 {
                    let f_p2ox = f_p2o.clone();
                    let r_p2nx = (**r_p2n).clone();
                    crate::prelude::call_then(start_tight_f(r_p2nx.clone()), move |tight_f_10576: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}.{}", &tight_f_10576, &f_p2ox))))
                };
            }
            if let crate::lower::model::Ex::XFieldOf(r_p2p, _, f_p2q) = x_p0 {
                break 'm7081 {
                    let f_p2qx = f_p2q.clone();
                    let r_p2px = (**r_p2p).clone();
                    crate::prelude::call_then(start_tight_f(r_p2px.clone()), move |tight_f_10619: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}.{}", &tight_f_10619, &f_p2qx))))
                };
            }
            if let crate::lower::model::Ex::XPart(r_p2r, k_p2s) = x_p0 {
                break 'm7081 {
                    let k_p2sx = k_p2s.clone();
                    let r_p2rx = (**r_p2r).clone();
                    crate::prelude::call_then(start_tight_f(r_p2rx.clone()), move |tight_f_10651: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}.{}", &tight_f_10651, &k_p2sx))))
                };
            }
            if let crate::lower::model::Ex::XDecode(t_p2t, y_p2u) = x_p0 {
                break 'm7081 {
                    let t_p2tx = t_p2t.clone();
                    let y_p2ux = (**y_p2u).clone();
                    crate::prelude::call_then(start_decode_head_f(t_p2tx.clone()), move |decode_head_f_10685: crate::prelude::Text| crate::prelude::call_then(start_expression_f(y_p2ux.clone()), move |expression_f_10710: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}::from_pod({})?", &decode_head_f_10685, &expression_f_10710)))))
                };
            }
            if let crate::lower::model::Ex::XCast(y_p2v, t_p30) = x_p0 {
                break 'm7081 {
                    let t_p30x = t_p30.clone();
                    let y_p2vx = (**y_p2v).clone();
                    crate::prelude::call_then(start_tight_f(y_p2vx.clone()), move |tight_f_10745: crate::prelude::Text| crate::prelude::call_then(start_type_f(t_p30x.clone()), move |type_f_10758: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} as {}", &tight_f_10745, &type_f_10758)))))
                };
            }
            if let crate::lower::model::Ex::XTyped(y_p31, _) = x_p0 {
                break 'm7081 ::prism_rtl::Turn::More(::std::rc::Rc::new(Expression { x_p0: (**y_p31).clone() }));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start Expression, x`: what the function value is when passed to `@Run`.
pub fn start_expression_f(x_p0: crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(Expression { x_p0 })
}

/// ```prism
/// FieldInit: unbounded fn Text, Ex -> Text
/// ```
pub fn field_init_f(f_p0: &crate::prelude::Text, ex1: &crate::lower::model::Ex) -> crate::prelude::Text {
    match ex1 {
        crate::lower::model::Ex::XVar(v_p1) => if v_p1 == f_p0 {
            f_p0.clone()
        } else {
            crate::prelude::Text::from(format!("{}: {}", f_p0, v_p1))
        },
        v_p3 => crate::prelude::Text::from(format!("{}: {}", f_p0, &expression_f(v_p3))),
    }
}

/// The step machine of `FieldInit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldInit: unbounded fn Text, Ex -> Text
/// ```
pub struct FieldInit {
    pub f_p0: crate::prelude::Text,
    pub ex1: crate::lower::model::Ex,
}

impl ::prism_rtl::Job<crate::prelude::Text> for FieldInit {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let f_p0 = &self.f_p0;
        let ex1 = &self.ex1;
        match ex1 {
            crate::lower::model::Ex::XVar(v_p1) => if v_p1 == f_p0 {
                ::prism_rtl::Turn::Finished(f_p0.clone())
            } else {
                ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}: {}", f_p0, v_p1)))
            },
            v_p3 => {
                let f_p0x = f_p0.clone();
                let v_p3x = v_p3.clone();
                crate::prelude::call_then(start_expression_f(v_p3x.clone()), move |expression_f_10928: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}: {}", &f_p0x, &expression_f_10928))))
            },
        }
    }
}

/// `Start FieldInit, x`: what the function value is when passed to `@Run`.
pub fn start_field_init_f(f_p0: crate::prelude::Text, ex1: crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(FieldInit { f_p0, ex1 })
}

/// ```prism
/// DecodeHead: unbounded fn OutTy -> Text
/// ```
pub fn decode_head_f(t_p0: &crate::lower::model::OutTy) -> crate::prelude::Text {
    match t_p0 {
        crate::lower::model::OutTy::OutNamed(n_p1, m11001_0_1) if (m11001_0_1.len() == 0) => rs_ref_f(n_p1),
        crate::lower::model::OutTy::OutNat => crate::prelude::Text::lit("crate::prelude::Nat"),
        crate::lower::model::OutTy::OutInt => crate::prelude::Text::lit("crate::prelude::Int"),
        crate::lower::model::OutTy::OutText => crate::prelude::Text::lit("crate::prelude::Text"),
        _ => crate::prelude::Text::from(format!("<{}>", &type_f(t_p0))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `DecodeHead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DecodeHead: unbounded fn OutTy -> Text
/// ```
pub struct DecodeHead {
    pub t_p0: crate::lower::model::OutTy,
}

impl ::prism_rtl::Job<crate::prelude::Text> for DecodeHead {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::lower::model::OutTy::OutNamed(n_p1, m11001_0_1) if (m11001_0_1.len() == 0) => ::prism_rtl::Turn::Finished(rs_ref_f(n_p1)),
            crate::lower::model::OutTy::OutNat => ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Nat")),
            crate::lower::model::OutTy::OutInt => ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Int")),
            crate::lower::model::OutTy::OutText => ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("crate::prelude::Text")),
            _ => {
                let t_p0x = t_p0.clone();
                crate::prelude::call_then(start_type_f(t_p0x.clone()), move |type_f_11162: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("<{}>", &type_f_11162))))
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start DecodeHead, x`: what the function value is when passed to `@Run`.
pub fn start_decode_head_f(t_p0: crate::lower::model::OutTy) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(DecodeHead { t_p0 })
}

/// ```prism
/// Label: fn Text -> Text
/// ```
pub fn label_f(l_p0: &crate::prelude::Text) -> crate::prelude::Text {
    if crate::syntax::lexer::chars::has_prefix_f(l_p0, &crate::prelude::Text::lit("\'")) {
        l_p0.clone()
    } else {
        crate::prelude::Text::from(format!("\'{}", l_p0))
    }
}

/// ```prism
/// Format: unbounded fn [Ex] -> Text
/// ```
pub fn format_f(parts_p0: &crate::prelude::Array<crate::lower::model::Ex>) -> crate::prelude::Text {
    let lit_p1 = crate::prelude::concat(&crate::prelude::each(parts_p0, &(|p_p3: &crate::lower::model::Ex| format_piece_f(p_p3))));
    let vals_p2 = crate::prelude::filter(parts_p0, &(|p_p4: &crate::lower::model::Ex| !is_text_f(p_p4)));
    if &crate::prelude::len(&vals_p2) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::from(format!("crate::prelude::Text::lit(\"{}\")", &crate::lower::expr::escape_f(&crate::prelude::concat(&crate::prelude::each(parts_p0, &(|p_p5: &crate::lower::model::Ex| plain_piece_f(p_p5)))))))
    } else {
        crate::prelude::Text::from(format!("crate::prelude::Text::from(format!(\"{}\", {}))", &lit_p1, &args_f(&vals_p2)))
    }
}

/// The step machine of `Format`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Format: unbounded fn [Ex] -> Text
/// ```
pub struct Format {
    pub parts_p0: crate::prelude::Array<crate::lower::model::Ex>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for Format {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let parts_p0 = &self.parts_p0;
        let lit_p1 = crate::prelude::concat(&crate::prelude::each(parts_p0, &(|p_p3: &crate::lower::model::Ex| format_piece_f(p_p3))));
        let vals_p2 = crate::prelude::filter(parts_p0, &(|p_p4: &crate::lower::model::Ex| !is_text_f(p_p4)));
        if &crate::prelude::len(&vals_p2) == &crate::prelude::Nat::from(0u32) {
            ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Text::lit(\"{}\")", &crate::lower::expr::escape_f(&crate::prelude::concat(&crate::prelude::each(parts_p0, &(|p_p5: &crate::lower::model::Ex| plain_piece_f(p_p5))))))))
        } else {
            crate::prelude::call_then(start_args_f(vals_p2.clone()), move |args_f_11709: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("crate::prelude::Text::from(format!(\"{}\", {}))", &lit_p1, &args_f_11709))))
        }
    }
}

/// `Start Format, x`: what the function value is when passed to `@Run`.
pub fn start_format_f(parts_p0: crate::prelude::Array<crate::lower::model::Ex>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(Format { parts_p0 })
}

/// ```prism
/// PlainPiece: fn Ex -> Text
/// ```
pub fn plain_piece_f(ex0: &crate::lower::model::Ex) -> crate::prelude::Text {
    match ex0 {
        crate::lower::model::Ex::XText(t_p0) => t_p0.clone(),
        other_p1 => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// FormatStr: unbounded fn [Ex] -> Text
/// ```
pub fn format_str_f(parts_p0: &crate::prelude::Array<crate::lower::model::Ex>) -> crate::prelude::Text {
    let lit_p1 = crate::prelude::concat(&crate::prelude::each(parts_p0, &(|p_p3: &crate::lower::model::Ex| str_piece_f(p_p3))));
    let vals_p2 = crate::prelude::filter(parts_p0, &(|p_p4: &crate::lower::model::Ex| !is_text_f(p_p4) && !is_var_f(p_p4)));
    if &crate::prelude::len(&vals_p2) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::from(format!("\"{}\"", &lit_p1))
    } else {
        crate::prelude::Text::from(format!("format!(\"{}\", {})", &lit_p1, &args_f(&vals_p2)))
    }
}

/// The step machine of `FormatStr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FormatStr: unbounded fn [Ex] -> Text
/// ```
pub struct FormatStr {
    pub parts_p0: crate::prelude::Array<crate::lower::model::Ex>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for FormatStr {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let parts_p0 = &self.parts_p0;
        let lit_p1 = crate::prelude::concat(&crate::prelude::each(parts_p0, &(|p_p3: &crate::lower::model::Ex| str_piece_f(p_p3))));
        let vals_p2 = crate::prelude::filter(parts_p0, &(|p_p4: &crate::lower::model::Ex| !is_text_f(p_p4) && !is_var_f(p_p4)));
        if &crate::prelude::len(&vals_p2) == &crate::prelude::Nat::from(0u32) {
            ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("\"{}\"", &lit_p1)))
        } else {
            crate::prelude::call_then(start_args_f(vals_p2.clone()), move |args_f_12174: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("format!(\"{}\", {})", &lit_p1, &args_f_12174))))
        }
    }
}

/// `Start FormatStr, x`: what the function value is when passed to `@Run`.
pub fn start_format_str_f(parts_p0: crate::prelude::Array<crate::lower::model::Ex>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(FormatStr { parts_p0 })
}

/// ```prism
/// IsVar: fn Ex -> Bool
/// ```
pub fn is_var_f(ex0: &crate::lower::model::Ex) -> bool {
    match ex0 {
        crate::lower::model::Ex::XVar(_) => true,
        other_p0 => false,
    }
}

/// ```prism
/// StrPiece: fn Ex -> Text
/// ```
pub fn str_piece_f(ex0: &crate::lower::model::Ex) -> crate::prelude::Text {
    match ex0 {
        crate::lower::model::Ex::XVar(n_p0) => crate::prelude::Text::from(format!("{{{}}}", n_p0)),
        other_p1 => format_piece_f(other_p1),
    }
}

/// ```prism
/// IsText: fn Ex -> Bool
/// ```
pub fn is_text_f(ex0: &crate::lower::model::Ex) -> bool {
    match ex0 {
        crate::lower::model::Ex::XText(_) => true,
        other_p0 => false,
    }
}

/// ```prism
/// FormatPiece: fn Ex -> Text
/// ```
pub fn format_piece_f(ex0: &crate::lower::model::Ex) -> crate::prelude::Text {
    match ex0 {
        crate::lower::model::Ex::XText(t_p0) => format_escape_f(&crate::lower::expr::escape_f(t_p0)),
        other_p1 => crate::prelude::Text::lit("{}"),
    }
}

/// ```prism
/// FormatEscape: fn Text -> Text
/// ```
pub fn format_escape_f(t_p0: &crate::prelude::Text) -> crate::prelude::Text {
    crate::syntax::lexer::chars::map_chars_f(t_p0, &(::std::rc::Rc::new(move |p0: crate::prelude::Text| crate::prelude::once_job(move || {
        let c_p1 = p0;
        ::prism_rtl::Turn::Finished(format_escape_char_f(&c_p1))
    })) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>))
}

/// ```prism
/// FormatEscapeChar: fn Text -> Text
/// ```
pub fn format_escape_char_f(text0: &crate::prelude::Text) -> crate::prelude::Text {
    match text0 {
        c0_0 if (c0_0 == &crate::prelude::Text::lit("{")) => crate::prelude::Text::lit("{{"),
        c1_0 if (c1_0 == &crate::prelude::Text::lit("}")) => crate::prelude::Text::lit("}}"),
        c_p0 => c_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IfExpression: unbounded fn Ex, Ex, Ex -> Text
/// ```
pub fn if_expression_f(c_p0: &crate::lower::model::Ex, t_p1: &crate::lower::model::Ex, e_p2: &crate::lower::model::Ex) -> crate::prelude::Text {
    let ct_p3 = expression_f(c_p0);
    let tt_p4 = expression_f(t_p1);
    let et_p5 = expression_f(e_p2);
    let short_p6 = !crate::syntax::lexer::chars::contains_f(&crate::prelude::Text::from(format!("{}{}", &tt_p4, &et_p5)), &crate::prelude::Text::lit("\n")) && (&crate::prelude::len_text(&crate::prelude::Text::from(format!("{}{}{}", &ct_p3, &tt_p4, &et_p5))) < &crate::prelude::Nat::from(70u32));
    if short_p6 {
        crate::prelude::Text::from(format!("if {} {{ {} }} else {{ {} }}", &ct_p3, &tt_p4, &et_p5))
    } else {
        crate::emit::rust::templates::items::if_f(&ct_p3, &tt_p4, &et_p5)
    }
}

/// The step machine of `IfExpression`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IfExpression: unbounded fn Ex, Ex, Ex -> Text
/// ```
pub struct IfExpression {
    pub c_p0: crate::lower::model::Ex,
    pub t_p1: crate::lower::model::Ex,
    pub e_p2: crate::lower::model::Ex,
}

impl ::prism_rtl::Job<crate::prelude::Text> for IfExpression {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let c_p0 = &self.c_p0;
        let t_p1 = &self.t_p1;
        let e_p2 = &self.e_p2;
        let c_p0x = c_p0.clone();
        let e_p2x = e_p2.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(start_expression_f(c_p0x.clone()), move |expression_f_12912: crate::prelude::Text| {
            let ct_p3 = expression_f_12912;
            crate::prelude::call_then(start_expression_f(t_p1x.clone()), move |expression_f_12938: crate::prelude::Text| {
                let tt_p4 = expression_f_12938;
                crate::prelude::call_then(start_expression_f(e_p2x.clone()), move |expression_f_12964: crate::prelude::Text| {
                    let et_p5 = expression_f_12964;
                    let short_p6 = !crate::syntax::lexer::chars::contains_f(&crate::prelude::Text::from(format!("{}{}", &tt_p4, &et_p5)), &crate::prelude::Text::lit("\n")) && (&crate::prelude::len_text(&crate::prelude::Text::from(format!("{}{}{}", &ct_p3, &tt_p4, &et_p5))) < &crate::prelude::Nat::from(70u32));
                    if short_p6 {
                        ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("if {} {{ {} }} else {{ {} }}", &ct_p3, &tt_p4, &et_p5)))
                    } else {
                        ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::if_f(&ct_p3, &tt_p4, &et_p5))
                    }
                })
            })
        })
    }
}

/// `Start IfExpression, x`: what the function value is when passed to `@Run`.
pub fn start_if_expression_f(c_p0: crate::lower::model::Ex, t_p1: crate::lower::model::Ex, e_p2: crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(IfExpression { c_p0, t_p1, e_p2 })
}

/// ```prism
/// Arms: unbounded fn [XArm], Bool -> Text
/// ```
pub fn arms_f(arms_p0: &crate::prelude::Array<crate::lower::model::XArm>, fallback_p1: &bool) -> crate::prelude::Text {
    let lines_p2 = crate::prelude::run_to_end(crate::prelude::each_job(arms_p0.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::XArm| crate::prelude::entered(crate::prelude::once_job(move || {
        let a_p4 = p0;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(Arm { a_p0: a_p4.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::XArm) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>));
    let all_p3 = if *fallback_p1 {
        crate::prelude::push(&lines_p2, &crate::prelude::Text::lit("_ => unreachable!(\"no arm matched\"),"))
    } else {
        lines_p2.clone()
    };
    crate::syntax::lexer::chars::join_f(&all_p3, &crate::prelude::Text::lit("\n"))
}

/// The step machine of `Arms`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Arms: unbounded fn [XArm], Bool -> Text
/// ```
pub struct Arms {
    pub arms_p0: crate::prelude::Array<crate::lower::model::XArm>,
    pub fallback_p1: bool,
}

impl ::prism_rtl::Job<crate::prelude::Text> for Arms {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let arms_p0 = &self.arms_p0;
        let fallback_p1 = &self.fallback_p1;
        let arms_p0x = arms_p0.clone();
        let fallback_p1x = *fallback_p1;
        crate::prelude::call_value(crate::prelude::each_job(arms_p0x.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::XArm| crate::prelude::entered(crate::prelude::once_job(move || {
            let a_p4 = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(Arm { a_p0: a_p4.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::XArm) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_13295: crate::prelude::Array<crate::prelude::Text>| {
            let lines_p2 = each_13295;
            let all_p3 = if fallback_p1x {
                crate::prelude::push(&lines_p2, &crate::prelude::Text::lit("_ => unreachable!(\"no arm matched\"),"))
            } else {
                lines_p2.clone()
            };
            ::prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join_f(&all_p3, &crate::prelude::Text::lit("\n")))
        })
    }
}

/// `Start Arms, x`: what the function value is when passed to `@Run`.
pub fn start_arms_f(arms_p0: crate::prelude::Array<crate::lower::model::XArm>, fallback_p1: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(Arms { arms_p0, fallback_p1 })
}

/// ```prism
/// Arm: unbounded fn XArm -> Text
/// ```
pub fn arm_f(a_p0: &crate::lower::model::XArm) -> crate::prelude::Text {
    let guard_p1 = if &crate::prelude::len(&a_p0.conds_p) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::lit("")
    } else {
        crate::prelude::Text::from(format!(" if {}", &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(a_p0.conds_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Cc| crate::prelude::entered(crate::prelude::once_job(move || {
            let c_p3 = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(Condition { cc0: c_p3.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Cc) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit(" && "))))
    };
    let body_p2 = expression_f(&a_p0.body_p);
    crate::prelude::Text::from(format!("{}{} => {},", &pattern_f(&a_p0.pat_p), &guard_p1, &body_p2))
}

/// The step machine of `Arm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Arm: unbounded fn XArm -> Text
/// ```
pub struct Arm {
    pub a_p0: crate::lower::model::XArm,
}

impl ::prism_rtl::Job<crate::prelude::Text> for Arm {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let a_p0 = &self.a_p0;
        let a_p0z = a_p0.clone();
        let k_let13474 = move |v13474: crate::prelude::Text| {
            let guard_p1 = v13474;
            crate::prelude::call_then(start_expression_f(a_p0z.body_p.clone()), move |expression_f_13587: crate::prelude::Text| {
                let body_p2 = expression_f_13587;
                crate::prelude::call_then(start_pattern_f(a_p0z.pat_p.clone()), move |pattern_f_13611: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{} => {},", &pattern_f_13611, &guard_p1, &body_p2))))
            })
        };
        if &crate::prelude::len(&a_p0.conds_p) == &crate::prelude::Nat::from(0u32) {
            k_let13474(crate::prelude::Text::lit(""))
        } else {
            {
                let a_p0x = a_p0.clone();
                crate::prelude::call_value(crate::prelude::each_job(a_p0x.conds_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Cc| crate::prelude::entered(crate::prelude::once_job(move || {
                    let c_p3 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(Condition { cc0: c_p3.clone() }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Cc) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_13530: crate::prelude::Array<crate::prelude::Text>| k_let13474(crate::prelude::Text::from(format!(" if {}", &crate::syntax::lexer::chars::join_f(&each_13530, &crate::prelude::Text::lit(" && "))))))
            }
        }
    }
}

/// `Start Arm, x`: what the function value is when passed to `@Run`.
pub fn start_arm_f(a_p0: crate::lower::model::XArm) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(Arm { a_p0 })
}

/// ```prism
/// Condition: unbounded fn Cc -> Text
/// ```
pub fn condition_f(cc0: &crate::lower::model::Cc) -> crate::prelude::Text {
    match cc0 {
        crate::lower::model::Cc::CcIf(x_p0) => operand_f(x_p0),
        crate::lower::model::Cc::CcLet(p_p1, x_p2) => crate::prelude::Text::from(format!("let {} = {}", &pattern_f(p_p1), &expression_f(x_p2))),
    }
}

/// The step machine of `Condition`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Condition: unbounded fn Cc -> Text
/// ```
pub struct Condition {
    pub cc0: crate::lower::model::Cc,
}

impl ::prism_rtl::Job<crate::prelude::Text> for Condition {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let cc0 = &self.cc0;
        match cc0 {
            crate::lower::model::Cc::CcIf(x_p0) => ::prism_rtl::Turn::More(::std::rc::Rc::new(Operand { x_p0: x_p0.clone() })),
            crate::lower::model::Cc::CcLet(p_p1, x_p2) => {
                let p_p1x = p_p1.clone();
                let x_p2x = x_p2.clone();
                crate::prelude::call_then(start_pattern_f(p_p1x.clone()), move |pattern_f_13749: crate::prelude::Text| crate::prelude::call_then(start_expression_f(x_p2x.clone()), move |expression_f_13763: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("let {} = {}", &pattern_f_13749, &expression_f_13763)))))
            },
        }
    }
}

/// `Start Condition, x`: what the function value is when passed to `@Run`.
pub fn start_condition_f(cc0: crate::lower::model::Cc) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(Condition { cc0 })
}

/// ```prism
/// Chain: unbounded fn Text, Ex, [XArm] -> Text
/// ```
pub fn chain_f(label_p0: &crate::prelude::Text, s_p1: &crate::lower::model::Ex, arms_p2: &crate::prelude::Array<crate::lower::model::XArm>) -> crate::prelude::Text {
    let in_place_p3 = match s_p1 {
        crate::lower::model::Ex::XRef(y_p8) => is_bound_f(&**y_p8),
        _ => is_bound_f(s_p1),
    };
    let (bind_p9, scrut_pa) = if in_place_p3 {
        (crate::prelude::Array::new(), expression_f(s_p1))
    } else {
        (crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("let scrutinee = {};", &expression_f(s_p1)))]), crate::prelude::Text::lit("scrutinee"))
    };
    let n_p4 = crate::prelude::len(arms_p2);
    let lines_p5 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&n_p4), {
        let arms_p2x = arms_p2.clone();
        let scrut_pax = scrut_pa.clone();
        let label_p0x = label_p0.clone();
        ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
            let arms_p2xy = arms_p2x.clone();
            let scrut_paxy = scrut_pax.clone();
            let label_p0xy = label_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_pb = p0;
                {
                    let a_pc = crate::prelude::or(&crate::prelude::index(&arms_p2xy, &i_pb), &crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XUnit });
                    let catch_all_pd = (&a_pc.pat_p == &crate::lower::model::Pa::PaWild) && (&crate::prelude::len(&a_pc.conds_p) == &crate::prelude::Nat::from(0u32));
                    if catch_all_pd {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(Expression { x_p0: a_pc.body_p.clone() }))
                    } else {
                        crate::prelude::call_then(start_pattern_f(a_pc.pat_p.clone()), move |pattern_f_14476: crate::prelude::Text| crate::prelude::call_value(crate::prelude::each_job(a_pc.conds_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Cc| crate::prelude::entered(crate::prelude::once_job(move || {
                            let c_pf = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(Condition { cc0: c_pf.clone() }))
                        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Cc) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_14506: crate::prelude::Array<crate::prelude::Text>| {
                            let head_pe = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("let {} = {}", &pattern_f_14476, &scrut_paxy))]), &each_14506), &crate::prelude::Text::lit(" && "));
                            crate::prelude::call_then(start_expression_f(a_pc.body_p.clone()), move |expression_f_14593: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::chain_arm_f(&head_pe, &label_p0xy, &continued_f(&expression_f_14593, &crate::prelude::Text::lit("    ")))))
                        }))
                    }
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    }));
    let ends_p6 = match crate::syntax::lexer::chars::last_o(arms_p2) {
        ::std::option::Option::Some(a_pg) => (&a_pg.pat_p == &crate::lower::model::Pa::PaWild) && (&crate::prelude::len(&a_pg.conds_p) == &crate::prelude::Nat::from(0u32)),
        ::std::option::Option::None => false,
    };
    let tail_p7 = if ends_p6 {
        crate::prelude::Array::new()
    } else {
        crate::prelude::Array::from(vec![crate::prelude::Text::lit("unreachable!(\"no clause matched\")")])
    };
    crate::prelude::Text::from(format!("{}: {{\n{}\n}}", label_p0, &indent_f(&crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::append(&bind_p9, &lines_p5), &tail_p7), &crate::prelude::Text::lit("\n")))))
}

/// The step machine of `Chain`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Chain: unbounded fn Text, Ex, [XArm] -> Text
/// ```
pub struct Chain {
    pub label_p0: crate::prelude::Text,
    pub s_p1: crate::lower::model::Ex,
    pub arms_p2: crate::prelude::Array<crate::lower::model::XArm>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for Chain {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let label_p0 = &self.label_p0;
        let s_p1 = &self.s_p1;
        let arms_p2 = &self.arms_p2;
        let in_place_p3 = match s_p1 {
            crate::lower::model::Ex::XRef(y_p8) => is_bound_f(&**y_p8),
            _ => is_bound_f(s_p1),
        };
        let arms_p2z = arms_p2.clone();
        let label_p0z = label_p0.clone();
        let k_let14067 = move |v14067: (crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text)| {
            let (bind_p9, scrut_pa) = v14067;
            let n_p4 = crate::prelude::len(&arms_p2z);
            crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&n_p4), {
                let arms_p2zx = arms_p2z.clone();
                let scrut_pax = scrut_pa.clone();
                let label_p0zx = label_p0z.clone();
                ::std::rc::Rc::new(move |p0: crate::prelude::Nat| {
                    let arms_p2zxy = arms_p2zx.clone();
                    let scrut_paxy = scrut_pax.clone();
                    let label_p0zxy = label_p0zx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let i_pb = p0;
                        {
                            let a_pc = crate::prelude::or(&crate::prelude::index(&arms_p2zxy, &i_pb), &crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaWild, conds_p: crate::prelude::Array::new(), body_p: crate::lower::model::Ex::XUnit });
                            let catch_all_pd = (&a_pc.pat_p == &crate::lower::model::Pa::PaWild) && (&crate::prelude::len(&a_pc.conds_p) == &crate::prelude::Nat::from(0u32));
                            if catch_all_pd {
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(Expression { x_p0: a_pc.body_p.clone() }))
                            } else {
                                crate::prelude::call_then(start_pattern_f(a_pc.pat_p.clone()), move |pattern_f_14476: crate::prelude::Text| crate::prelude::call_value(crate::prelude::each_job(a_pc.conds_p.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Cc| crate::prelude::entered(crate::prelude::once_job(move || {
                                    let c_pf = p0;
                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(Condition { cc0: c_pf.clone() }))
                                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Cc) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_14506: crate::prelude::Array<crate::prelude::Text>| {
                                    let head_pe = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("let {} = {}", &pattern_f_14476, &scrut_paxy))]), &each_14506), &crate::prelude::Text::lit(" && "));
                                    crate::prelude::call_then(start_expression_f(a_pc.body_p.clone()), move |expression_f_14593: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::chain_arm_f(&head_pe, &label_p0zxy, &continued_f(&expression_f_14593, &crate::prelude::Text::lit("    ")))))
                                }))
                            }
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            }), move |each_14222: crate::prelude::Array<crate::prelude::Text>| {
                let lines_p5 = each_14222;
                let ends_p6 = match crate::syntax::lexer::chars::last_o(&arms_p2z) {
                    ::std::option::Option::Some(a_pg) => (&a_pg.pat_p == &crate::lower::model::Pa::PaWild) && (&crate::prelude::len(&a_pg.conds_p) == &crate::prelude::Nat::from(0u32)),
                    ::std::option::Option::None => false,
                };
                let tail_p7 = if ends_p6 {
                    crate::prelude::Array::new()
                } else {
                    crate::prelude::Array::from(vec![crate::prelude::Text::lit("unreachable!(\"no clause matched\")")])
                };
                ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}: {{\n{}\n}}", &label_p0z, &indent_f(&crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::append(&bind_p9, &lines_p5), &tail_p7), &crate::prelude::Text::lit("\n"))))))
            })
        };
        if in_place_p3 {
            {
                let s_p1x = s_p1.clone();
                crate::prelude::call_then(start_expression_f(s_p1x.clone()), move |expression_f_14109: crate::prelude::Text| k_let14067((crate::prelude::Array::new(), expression_f_14109)))
            }
        } else {
            {
                let s_p1x = s_p1.clone();
                crate::prelude::call_then(start_expression_f(s_p1x.clone()), move |expression_f_14152: crate::prelude::Text| k_let14067((crate::prelude::Array::from(vec![crate::prelude::Text::from(format!("let scrutinee = {};", &expression_f_14152))]), crate::prelude::Text::lit("scrutinee"))))
            }
        }
    }
}

/// `Start Chain, x`: what the function value is when passed to `@Run`.
pub fn start_chain_f(label_p0: crate::prelude::Text, s_p1: crate::lower::model::Ex, arms_p2: crate::prelude::Array<crate::lower::model::XArm>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(Chain { label_p0, s_p1, arms_p2 })
}

/// ```prism
/// IsBound: fn Ex -> Bool
/// ```
pub fn is_bound_f(x_p0: &crate::lower::model::Ex) -> bool {
    'm15097: {
        if let crate::lower::model::Ex::XVar(_) = x_p0 {
            break 'm15097 true;
        }
        if let crate::lower::model::Ex::XField(m15097_1_0, _) = x_p0 && let crate::lower::model::Ex::XSelf = &**m15097_1_0 {
            break 'm15097 true;
        }
        if let crate::lower::model::Ex::XField(m15097_2_0, _) = x_p0 && let crate::lower::model::Ex::XMethod(m15097_2_0_r_0, _, _) = &**m15097_2_0 && let crate::lower::model::Ex::XUpgrade(_) = &**m15097_2_0_r_0 {
            break 'm15097 true;
        }
        if let crate::lower::model::Ex::XTarget(_) = x_p0 {
            break 'm15097 true;
        }
        if let crate::lower::model::Ex::XPart(m15097_4_0, _) = x_p0 && let crate::lower::model::Ex::XVar(_) = &**m15097_4_0 {
            break 'm15097 true;
        }
        false
    }
}

/// ```prism
/// Continued: fn Text, Text -> Text
/// ```
pub fn continued_f(t_p0: &crate::prelude::Text, pad_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let ls_p2 = crate::prelude::split_on(t_p0, &crate::prelude::Text::lit("\n"));
    crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&ls_p2)), &(|i_p3: &crate::prelude::Nat| if (i_p3 == &crate::prelude::Nat::from(0u32)) || (&crate::prelude::or(&crate::prelude::index(&ls_p2, i_p3), &crate::prelude::Text::lit("")) == &crate::prelude::Text::lit("")) {
        crate::prelude::or(&crate::prelude::index(&ls_p2, i_p3), &crate::prelude::Text::lit(""))
    } else {
        crate::prelude::Text::from(format!("{}{}", pad_p1, &crate::prelude::or(&crate::prelude::index(&ls_p2, i_p3), &crate::prelude::Text::lit(""))))
    })), &crate::prelude::Text::lit("\n"))
}

/// ```prism
/// BodyLines: unbounded fn Ex -> Text
/// ```
pub fn body_lines_f(ex0: &crate::lower::model::Ex) -> crate::prelude::Text {
    match ex0 {
        crate::lower::model::Ex::XBlock(dos_p0, e_p1) => if &crate::prelude::len(dos_p0) == &crate::prelude::Nat::from(0u32) {
            body_lines_f(&**e_p1)
        } else {
            crate::prelude::Text::from(format!("{}\n{}", &statements_f(dos_p0), &body_lines_f(&**e_p1)))
        },
        x_p2 => expression_f(x_p2),
    }
}

/// The step machine of `BodyLines`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BodyLines: unbounded fn Ex -> Text
/// ```
pub struct BodyLines {
    pub ex0: crate::lower::model::Ex,
}

impl ::prism_rtl::Job<crate::prelude::Text> for BodyLines {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let ex0 = &self.ex0;
        match ex0 {
            crate::lower::model::Ex::XBlock(dos_p0, e_p1) => if &crate::prelude::len(dos_p0) == &crate::prelude::Nat::from(0u32) {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(BodyLines { ex0: (**e_p1).clone() }))
            } else {
                {
                    let dos_p0x = dos_p0.clone();
                    let e_p1x = (**e_p1).clone();
                    crate::prelude::call_then(start_statements_f(dos_p0x.clone()), move |statements_f_15783: crate::prelude::Text| crate::prelude::call_then(start_body_lines_f(e_p1x.clone()), move |body_lines_f_15801: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}\n{}", &statements_f_15783, &body_lines_f_15801)))))
                }
            },
            x_p2 => ::prism_rtl::Turn::More(::std::rc::Rc::new(Expression { x_p0: x_p2.clone() })),
        }
    }
}

/// `Start BodyLines, x`: what the function value is when passed to `@Run`.
pub fn start_body_lines_f(ex0: crate::lower::model::Ex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(BodyLines { ex0 })
}

/// ```prism
/// Indent: fn Text -> Text
/// ```
pub fn indent_f(t_p0: &crate::prelude::Text) -> crate::prelude::Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::prelude::split_on(t_p0, &crate::prelude::Text::lit("\n")), &(|l_p1: &crate::prelude::Text| if l_p1 == &crate::prelude::Text::lit("") {
        crate::prelude::Text::lit("")
    } else {
        crate::prelude::Text::from(format!("    {}", l_p1))
    })), &crate::prelude::Text::lit("\n"))
}

/// ```prism
/// Pattern: unbounded fn Pa -> Text
/// ```
pub fn pattern_f(p_p0: &crate::lower::model::Pa) -> crate::prelude::Text {
    'm16252: {
        if let crate::lower::model::Pa::PaWild = p_p0 {
            break 'm16252 crate::prelude::Text::lit("_");
        }
        if let crate::lower::model::Pa::PaBind(n_p1) = p_p0 {
            break 'm16252 n_p1.clone();
        }
        if let crate::lower::model::Pa::PaMut(n_p2) = p_p0 {
            break 'm16252 crate::prelude::Text::from(format!("mut {}", n_p2));
        }
        if let crate::lower::model::Pa::PaCtor(c_p3, ps_p4) = p_p0 {
            break 'm16252 crate::prelude::Text::from(format!("{}({})", &rs_ref_f(c_p3), &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(ps_p4.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Pa| crate::prelude::entered(crate::prelude::once_job(move || {
                let q_p5 = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(Pattern { p_p0: q_p5.clone() }))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Pa) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit(", "))));
        }
        if let crate::lower::model::Pa::PaUnit(c_p6) = p_p0 {
            break 'm16252 rs_ref_f(c_p6);
        }
        if let crate::lower::model::Pa::PaRecord(c0_p7, fs_p8, rest_p9) = p_p0 {
            break 'm16252 {
                let c_pa = rs_ref_f(c0_p7);
                let parts_pb = crate::prelude::run_to_end(crate::prelude::each_job(fs_p8.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::Pa)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let (f_pd, q_pe) = p0;
                    match &q_pe {
                        crate::lower::model::Pa::PaBind(n_pf) => if n_pf == &f_pd {
                            ::prism_rtl::Turn::Finished(f_pd.clone())
                        } else {
                            ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}: {}", &f_pd, n_pf)))
                        },
                        _ => crate::prelude::call_then(start_pattern_f(q_pe.clone()), move |pattern_f_16592: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}: {}", &f_pd, &pattern_f_16592)))),
                    }
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::Pa)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>));
                let all_pc = if *rest_p9 {
                    crate::prelude::push(&parts_pb, &crate::prelude::Text::lit(".."))
                } else {
                    parts_pb.clone()
                };
                crate::prelude::Text::from(format!("{} {{ {} }}", &c_pa, &crate::syntax::lexer::chars::join_f(&all_pc, &crate::prelude::Text::lit(", "))))
            };
        }
        if let crate::lower::model::Pa::PaTuple(m16252_6_0) = p_p0 && (m16252_6_0.len() == 1) && let ::std::option::Option::Some(one_pg) = crate::prelude::index(m16252_6_0, &crate::prelude::Nat::from(0u32)) {
            break 'm16252 crate::prelude::Text::from(format!("({},)", &pattern_f(&one_pg)));
        }
        if let crate::lower::model::Pa::PaTuple(ps_ph) = p_p0 {
            break 'm16252 crate::prelude::Text::from(format!("({})", &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(ps_ph.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Pa| crate::prelude::entered(crate::prelude::once_job(move || {
                let q_pi = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(Pattern { p_p0: q_pi.clone() }))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Pa) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit(", "))));
        }
        if let crate::lower::model::Pa::PaChar(c_pj) = p_p0 {
            break 'm16252 crate::prelude::Text::from(format!("\'{}\'", &crate::lower::expr::char_escape_f(c_pj)));
        }
        if let crate::lower::model::Pa::PaBool(b_pk) = p_p0 {
            break 'm16252 if *b_pk {
                crate::prelude::Text::lit("true")
            } else {
                crate::prelude::Text::lit("false")
            };
        }
        if let crate::lower::model::Pa::PaIndex(n_pl) = p_p0 {
            break 'm16252 crate::prelude::Text::from(format!("{}", n_pl));
        }
        if let crate::lower::model::Pa::PaConst(n_pm) = p_p0 {
            break 'm16252 crate::prelude::Text::from(format!("Self::{}", n_pm));
        }
        if let crate::lower::model::Pa::PaSlice(ps_pn) = p_p0 {
            break 'm16252 crate::prelude::Text::from(format!("[{}]", &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(ps_pn.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Pa| crate::prelude::entered(crate::prelude::once_job(move || {
                let q_po = p0;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(Pattern { p_p0: q_po.clone() }))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Pa) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit(", "))));
        }
        if let crate::lower::model::Pa::PaRest(m16252_13_0) = p_p0 && (m16252_13_0 == &crate::prelude::Text::lit("")) {
            break 'm16252 crate::prelude::Text::lit("..");
        }
        if let crate::lower::model::Pa::PaRest(n_pp) = p_p0 {
            break 'm16252 crate::prelude::Text::from(format!("{} @ ..", n_pp));
        }
        if let crate::lower::model::Pa::PaTyped(q_pq, t_pr) = p_p0 {
            break 'm16252 crate::prelude::Text::from(format!("{}: {}", &pattern_f(&**q_pq), &type_f(t_pr)));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `Pattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Pattern: unbounded fn Pa -> Text
/// ```
pub struct Pattern {
    pub p_p0: crate::lower::model::Pa,
}

impl ::prism_rtl::Job<crate::prelude::Text> for Pattern {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let p_p0 = &self.p_p0;
        'm16252: {
            if let crate::lower::model::Pa::PaWild = p_p0 {
                break 'm16252 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("_"));
            }
            if let crate::lower::model::Pa::PaBind(n_p1) = p_p0 {
                break 'm16252 ::prism_rtl::Turn::Finished(n_p1.clone());
            }
            if let crate::lower::model::Pa::PaMut(n_p2) = p_p0 {
                break 'm16252 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("mut {}", n_p2)));
            }
            if let crate::lower::model::Pa::PaCtor(c_p3, ps_p4) = p_p0 {
                break 'm16252 {
                    let c_p3x = c_p3.clone();
                    let ps_p4x = ps_p4.clone();
                    crate::prelude::call_value(crate::prelude::each_job(ps_p4x.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Pa| crate::prelude::entered(crate::prelude::once_job(move || {
                        let q_p5 = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(Pattern { p_p0: q_p5.clone() }))
                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Pa) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_16352: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}({})", &rs_ref_f(&c_p3x), &crate::syntax::lexer::chars::join_f(&each_16352, &crate::prelude::Text::lit(", "))))))
                };
            }
            if let crate::lower::model::Pa::PaUnit(c_p6) = p_p0 {
                break 'm16252 ::prism_rtl::Turn::Finished(rs_ref_f(c_p6));
            }
            if let crate::lower::model::Pa::PaRecord(c0_p7, fs_p8, rest_p9) = p_p0 {
                break 'm16252 {
                    let c_pa = rs_ref_f(c0_p7);
                    let fs_p8x = fs_p8.clone();
                    let rest_p9x = *rest_p9;
                    crate::prelude::call_value(crate::prelude::each_job(fs_p8x.clone(), ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::lower::model::Pa)| crate::prelude::entered(crate::prelude::once_job(move || {
                        let (f_pd, q_pe) = p0;
                        match &q_pe {
                            crate::lower::model::Pa::PaBind(n_pf) => if n_pf == &f_pd {
                                ::prism_rtl::Turn::Finished(f_pd.clone())
                            } else {
                                ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}: {}", &f_pd, n_pf)))
                            },
                            _ => crate::prelude::call_then(start_pattern_f(q_pe.clone()), move |pattern_f_16592: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}: {}", &f_pd, &pattern_f_16592)))),
                        }
                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::lower::model::Pa)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_16480: crate::prelude::Array<crate::prelude::Text>| {
                        let parts_pb = each_16480;
                        let all_pc = if rest_p9x {
                            crate::prelude::push(&parts_pb, &crate::prelude::Text::lit(".."))
                        } else {
                            parts_pb.clone()
                        };
                        ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} {{ {} }}", &c_pa, &crate::syntax::lexer::chars::join_f(&all_pc, &crate::prelude::Text::lit(", ")))))
                    })
                };
            }
            if let crate::lower::model::Pa::PaTuple(m16252_6_0) = p_p0 && (m16252_6_0.len() == 1) && let ::std::option::Option::Some(one_pg) = crate::prelude::index(m16252_6_0, &crate::prelude::Nat::from(0u32)) {
                break 'm16252 crate::prelude::call_then(start_pattern_f(one_pg.clone()), move |pattern_f_16721: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("({},)", &pattern_f_16721))));
            }
            if let crate::lower::model::Pa::PaTuple(ps_ph) = p_p0 {
                break 'm16252 {
                    let ps_phx = ps_ph.clone();
                    crate::prelude::call_value(crate::prelude::each_job(ps_phx.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Pa| crate::prelude::entered(crate::prelude::once_job(move || {
                        let q_pi = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(Pattern { p_p0: q_pi.clone() }))
                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Pa) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_16762: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("({})", &crate::syntax::lexer::chars::join_f(&each_16762, &crate::prelude::Text::lit(", "))))))
                };
            }
            if let crate::lower::model::Pa::PaChar(c_pj) = p_p0 {
                break 'm16252 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("\'{}\'", &crate::lower::expr::char_escape_f(c_pj))));
            }
            if let crate::lower::model::Pa::PaBool(b_pk) = p_p0 {
                break 'm16252 if *b_pk {
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("true"))
                } else {
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("false"))
                };
            }
            if let crate::lower::model::Pa::PaIndex(n_pl) = p_p0 {
                break 'm16252 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}", n_pl)));
            }
            if let crate::lower::model::Pa::PaConst(n_pm) = p_p0 {
                break 'm16252 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("Self::{}", n_pm)));
            }
            if let crate::lower::model::Pa::PaSlice(ps_pn) = p_p0 {
                break 'm16252 {
                    let ps_pnx = ps_pn.clone();
                    crate::prelude::call_value(crate::prelude::each_job(ps_pnx.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Pa| crate::prelude::entered(crate::prelude::once_job(move || {
                        let q_po = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(Pattern { p_p0: q_po.clone() }))
                    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Pa) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_16943: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("[{}]", &crate::syntax::lexer::chars::join_f(&each_16943, &crate::prelude::Text::lit(", "))))))
                };
            }
            if let crate::lower::model::Pa::PaRest(m16252_13_0) = p_p0 && (m16252_13_0 == &crate::prelude::Text::lit("")) {
                break 'm16252 ::prism_rtl::Turn::Finished(crate::prelude::Text::lit(".."));
            }
            if let crate::lower::model::Pa::PaRest(n_pp) = p_p0 {
                break 'm16252 ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} @ ..", n_pp)));
            }
            if let crate::lower::model::Pa::PaTyped(q_pq, t_pr) = p_p0 {
                break 'm16252 {
                    let q_pqx = (**q_pq).clone();
                    let t_prx = t_pr.clone();
                    crate::prelude::call_then(start_pattern_f(q_pqx.clone()), move |pattern_f_17042: crate::prelude::Text| crate::prelude::call_then(start_type_f(t_prx.clone()), move |type_f_17055: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}: {}", &pattern_f_17042, &type_f_17055)))))
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start Pattern, x`: what the function value is when passed to `@Run`.
pub fn start_pattern_f(p_p0: crate::lower::model::Pa) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(Pattern { p_p0 })
}

/// ```prism
/// Statements: unbounded fn [Do] -> Text
/// ```
pub fn statements_f(dos_p0: &crate::prelude::Array<crate::lower::model::Do>) -> crate::prelude::Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(dos_p0.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Do| crate::prelude::entered(crate::prelude::once_job(move || {
        let d_p1 = p0;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(Statement { d_p0: d_p1.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Do) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit("\n"))
}

/// The step machine of `Statements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Statements: unbounded fn [Do] -> Text
/// ```
pub struct Statements {
    pub dos_p0: crate::prelude::Array<crate::lower::model::Do>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for Statements {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let dos_p0 = &self.dos_p0;
        let dos_p0x = dos_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(dos_p0x.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Do| crate::prelude::entered(crate::prelude::once_job(move || {
            let d_p1 = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(Statement { d_p0: d_p1.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Do) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_17129: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join_f(&each_17129, &crate::prelude::Text::lit("\n"))))
    }
}

/// `Start Statements, x`: what the function value is when passed to `@Run`.
pub fn start_statements_f(dos_p0: crate::prelude::Array<crate::lower::model::Do>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(Statements { dos_p0 })
}

/// ```prism
/// Statement: unbounded fn Do -> Text
/// ```
pub fn statement_f(d_p0: &crate::lower::model::Do) -> crate::prelude::Text {
    match d_p0 {
        crate::lower::model::Do::DoLet(p_p1, x_p2) => crate::prelude::Text::from(format!("let {} = {};", &pattern_f(p_p1), &expression_f(x_p2))),
        crate::lower::model::Do::DoLetElse(p_p3, x_p4, e_p5) => crate::prelude::Text::from(format!("let {} = {} else {{ {} }};", &pattern_f(p_p3), &expression_f(x_p4), &expression_f(e_p5))),
        crate::lower::model::Do::DoAssign(p_p6, x_p7) => crate::prelude::Text::from(format!("{} = {};", &expression_f(p_p6), &expression_f(x_p7))),
        crate::lower::model::Do::DoWhile(c_p8, body_p9) => crate::emit::rust::templates::items::if_stmt_f(&crate::prelude::Text::from(format!("while {}", &expression_f(c_p8))), &statements_f(body_p9)),
        crate::lower::model::Do::DoWhileLet(p_pa, x_pb, body_pc) => crate::emit::rust::templates::items::if_stmt_f(&crate::prelude::Text::from(format!("while let {} = {}", &pattern_f(p_pa), &expression_f(x_pb))), &statements_f(body_pc)),
        crate::lower::model::Do::DoFor(p_pd, x_pe, body_pf) => crate::emit::rust::templates::items::if_stmt_f(&crate::prelude::Text::from(format!("for {} in {}", &pattern_f(p_pd), &expression_f(x_pe))), &statements_f(body_pf)),
        crate::lower::model::Do::DoExpr(x_pg) => crate::prelude::Text::from(format!("{};", &expression_f(x_pg))),
        crate::lower::model::Do::DoIf(c_ph, t_pi, e_pj) => crate::prelude::Text::from(format!("{}{}", &crate::emit::rust::templates::items::if_stmt_f(&crate::prelude::Text::from(format!("if {}", &expression_f(c_ph))), &statements_f(t_pi)), &else_branch_f(e_pj))),
        crate::lower::model::Do::DoIfLet(p_pk, x_pl, t_pm, e_pn) => crate::prelude::Text::from(format!("{}{}", &crate::emit::rust::templates::items::if_stmt_f(&crate::prelude::Text::from(format!("if let {} = {}", &pattern_f(p_pk), &expression_f(x_pl))), &statements_f(t_pm)), &else_branch_f(e_pn))),
        crate::lower::model::Do::DoMatch(x_po, cases_pp) => crate::emit::rust::templates::items::match_block_f(&expression_f(x_po), &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(cases_pp.clone(), ::std::rc::Rc::new(move |p0: (crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)| crate::prelude::entered(crate::prelude::once_job(move || {
            let (p_pq, body_pr) = p0;
            crate::prelude::call_then(start_pattern_f(p_pq.clone()), move |pattern_f_17971: crate::prelude::Text| crate::prelude::call_then(start_statements_f(body_pr.clone()), move |statements_f_17984: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::arm_block_f(&pattern_f_17971, &statements_f_17984))))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit("\n"))),
        crate::lower::model::Do::DoReturn(x_ps) => crate::prelude::Text::from(format!("return {};", &expression_f(x_ps))),
        crate::lower::model::Do::DoBlock(body_pt) => crate::emit::rust::templates::items::scope_f(&statements_f(body_pt)),
        crate::lower::model::Do::DoScope(body_pu) => crate::prelude::Text::from(format!("{{ {} }};", &inline_statements_f(body_pu))),
        crate::lower::model::Do::DoLine(body_pv) => crate::prelude::Text::from(format!("{};", &inline_statements_f(body_pv))),
        crate::lower::model::Do::DoNote(t_p10) => crate::prelude::Text::from(format!("// {}", t_p10)),
    }
}

/// The step machine of `Statement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Statement: unbounded fn Do -> Text
/// ```
pub struct Statement {
    pub d_p0: crate::lower::model::Do,
}

impl ::prism_rtl::Job<crate::prelude::Text> for Statement {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let d_p0 = &self.d_p0;
        match d_p0 {
            crate::lower::model::Do::DoLet(p_p1, x_p2) => {
                let p_p1x = p_p1.clone();
                let x_p2x = x_p2.clone();
                crate::prelude::call_then(start_pattern_f(p_p1x.clone()), move |pattern_f_17247: crate::prelude::Text| crate::prelude::call_then(start_expression_f(x_p2x.clone()), move |expression_f_17261: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("let {} = {};", &pattern_f_17247, &expression_f_17261)))))
            },
            crate::lower::model::Do::DoLetElse(p_p3, x_p4, e_p5) => {
                let e_p5x = e_p5.clone();
                let p_p3x = p_p3.clone();
                let x_p4x = x_p4.clone();
                crate::prelude::call_then(start_pattern_f(p_p3x.clone()), move |pattern_f_17306: crate::prelude::Text| crate::prelude::call_then(start_expression_f(x_p4x.clone()), move |expression_f_17320: crate::prelude::Text| crate::prelude::call_then(start_expression_f(e_p5x.clone()), move |expression_f_17343: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("let {} = {} else {{ {} }};", &pattern_f_17306, &expression_f_17320, &expression_f_17343))))))
            },
            crate::lower::model::Do::DoAssign(p_p6, x_p7) => {
                let p_p6x = p_p6.clone();
                let x_p7x = x_p7.clone();
                crate::prelude::call_then(start_expression_f(p_p6x.clone()), move |expression_f_17383: crate::prelude::Text| crate::prelude::call_then(start_expression_f(x_p7x.clone()), move |expression_f_17400: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{} = {};", &expression_f_17383, &expression_f_17400)))))
            },
            crate::lower::model::Do::DoWhile(c_p8, body_p9) => {
                let body_p9x = body_p9.clone();
                let c_p8x = c_p8.clone();
                crate::prelude::call_then(start_expression_f(c_p8x.clone()), move |expression_f_17452: crate::prelude::Text| crate::prelude::call_then(start_statements_f(body_p9x.clone()), move |statements_f_17469: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::if_stmt_f(&crate::prelude::Text::from(format!("while {}", &expression_f_17452)), &statements_f_17469))))
            },
            crate::lower::model::Do::DoWhileLet(p_pa, x_pb, body_pc) => {
                let body_pcx = body_pc.clone();
                let p_pax = p_pa.clone();
                let x_pbx = x_pb.clone();
                crate::prelude::call_then(start_pattern_f(p_pax.clone()), move |pattern_f_17532: crate::prelude::Text| crate::prelude::call_then(start_expression_f(x_pbx.clone()), move |expression_f_17546: crate::prelude::Text| crate::prelude::call_then(start_statements_f(body_pcx.clone()), move |statements_f_17563: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::if_stmt_f(&crate::prelude::Text::from(format!("while let {} = {}", &pattern_f_17532, &expression_f_17546)), &statements_f_17563)))))
            },
            crate::lower::model::Do::DoFor(p_pd, x_pe, body_pf) => {
                let body_pfx = body_pf.clone();
                let p_pdx = p_pd.clone();
                let x_pex = x_pe.clone();
                crate::prelude::call_then(start_pattern_f(p_pdx.clone()), move |pattern_f_17615: crate::prelude::Text| crate::prelude::call_then(start_expression_f(x_pex.clone()), move |expression_f_17630: crate::prelude::Text| crate::prelude::call_then(start_statements_f(body_pfx.clone()), move |statements_f_17647: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::if_stmt_f(&crate::prelude::Text::from(format!("for {} in {}", &pattern_f_17615, &expression_f_17630)), &statements_f_17647)))))
            },
            crate::lower::model::Do::DoExpr(x_pg) => {
                let x_pgx = x_pg.clone();
                crate::prelude::call_then(start_expression_f(x_pgx.clone()), move |expression_f_17680: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{};", &expression_f_17680))))
            },
            crate::lower::model::Do::DoIf(c_ph, t_pi, e_pj) => {
                let c_phx = c_ph.clone();
                let e_pjx = e_pj.clone();
                let t_pix = t_pi.clone();
                crate::prelude::call_then(start_expression_f(c_phx.clone()), move |expression_f_17728: crate::prelude::Text| crate::prelude::call_then(start_statements_f(t_pix.clone()), move |statements_f_17745: crate::prelude::Text| crate::prelude::call_then(start_else_branch_f(e_pjx.clone()), move |else_branch_f_17760: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{}", &crate::emit::rust::templates::items::if_stmt_f(&crate::prelude::Text::from(format!("if {}", &expression_f_17728)), &statements_f_17745), &else_branch_f_17760))))))
            },
            crate::lower::model::Do::DoIfLet(p_pk, x_pl, t_pm, e_pn) => {
                let e_pnx = e_pn.clone();
                let p_pkx = p_pk.clone();
                let t_pmx = t_pm.clone();
                let x_plx = x_pl.clone();
                crate::prelude::call_then(start_pattern_f(p_pkx.clone()), move |pattern_f_17817: crate::prelude::Text| crate::prelude::call_then(start_expression_f(x_plx.clone()), move |expression_f_17831: crate::prelude::Text| crate::prelude::call_then(start_statements_f(t_pmx.clone()), move |statements_f_17848: crate::prelude::Text| crate::prelude::call_then(start_else_branch_f(e_pnx.clone()), move |else_branch_f_17863: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{}", &crate::emit::rust::templates::items::if_stmt_f(&crate::prelude::Text::from(format!("if let {} = {}", &pattern_f_17817, &expression_f_17831)), &statements_f_17848), &else_branch_f_17863)))))))
            },
            crate::lower::model::Do::DoMatch(x_po, cases_pp) => {
                let cases_ppx = cases_pp.clone();
                let x_pox = x_po.clone();
                crate::prelude::call_then(start_expression_f(x_pox.clone()), move |expression_f_17912: crate::prelude::Text| crate::prelude::call_value(crate::prelude::each_job(cases_ppx.clone(), ::std::rc::Rc::new(move |p0: (crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let (p_pq, body_pr) = p0;
                    crate::prelude::call_then(start_pattern_f(p_pq.clone()), move |pattern_f_17971: crate::prelude::Text| crate::prelude::call_then(start_statements_f(body_pr.clone()), move |statements_f_17984: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::arm_block_f(&pattern_f_17971, &statements_f_17984))))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Do>)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_17934: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::match_block_f(&expression_f_17912, &crate::syntax::lexer::chars::join_f(&each_17934, &crate::prelude::Text::lit("\n"))))))
            },
            crate::lower::model::Do::DoReturn(x_ps) => {
                let x_psx = x_ps.clone();
                crate::prelude::call_then(start_expression_f(x_psx.clone()), move |expression_f_18034: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("return {};", &expression_f_18034))))
            },
            crate::lower::model::Do::DoBlock(body_pt) => {
                let body_ptx = body_pt.clone();
                crate::prelude::call_then(start_statements_f(body_ptx.clone()), move |statements_f_18075: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::scope_f(&statements_f_18075)))
            },
            crate::lower::model::Do::DoScope(body_pu) => {
                let body_pux = body_pu.clone();
                crate::prelude::call_then(start_inline_statements_f(body_pux.clone()), move |inline_statements_f_18115: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{{ {} }};", &inline_statements_f_18115))))
            },
            crate::lower::model::Do::DoLine(body_pv) => {
                let body_pvx = body_pv.clone();
                crate::prelude::call_then(start_inline_statements_f(body_pvx.clone()), move |inline_statements_f_18162: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{};", &inline_statements_f_18162))))
            },
            crate::lower::model::Do::DoNote(t_p10) => ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("// {}", t_p10))),
        }
    }
}

/// `Start Statement, x`: what the function value is when passed to `@Run`.
pub fn start_statement_f(d_p0: crate::lower::model::Do) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(Statement { d_p0 })
}

/// ```prism
/// InlineStatements: unbounded fn [Do] -> Text
/// ```
pub fn inline_statements_f(dos_p0: &crate::prelude::Array<crate::lower::model::Do>) -> crate::prelude::Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(dos_p0.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Do| crate::prelude::entered(crate::prelude::once_job(move || {
        let d_p1 = p0;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(InlineStatement { do_0: d_p1.clone() }))
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Do) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>)), &crate::prelude::Text::lit(" "))
}

/// The step machine of `InlineStatements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InlineStatements: unbounded fn [Do] -> Text
/// ```
pub struct InlineStatements {
    pub dos_p0: crate::prelude::Array<crate::lower::model::Do>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for InlineStatements {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let dos_p0 = &self.dos_p0;
        let dos_p0x = dos_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(dos_p0x.clone(), ::std::rc::Rc::new(move |p0: crate::lower::model::Do| crate::prelude::entered(crate::prelude::once_job(move || {
            let d_p1 = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(InlineStatement { do_0: d_p1.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::lower::model::Do) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>), move |each_18335: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join_f(&each_18335, &crate::prelude::Text::lit(" "))))
    }
}

/// `Start InlineStatements, x`: what the function value is when passed to `@Run`.
pub fn start_inline_statements_f(dos_p0: crate::prelude::Array<crate::lower::model::Do>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(InlineStatements { dos_p0 })
}

/// ```prism
/// InlineStatement: unbounded fn Do -> Text
/// ```
pub fn inline_statement_f(do_0: &crate::lower::model::Do) -> crate::prelude::Text {
    match do_0 {
        crate::lower::model::Do::DoIf(c_p0, t_p1, c0_0_2) if (c0_0_2.len() == 0) => crate::prelude::Text::from(format!("if {} {{ {} }}", &expression_f(c_p0), &inline_statements_f(t_p1))),
        d_p2 => statement_f(d_p2),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `InlineStatement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InlineStatement: unbounded fn Do -> Text
/// ```
pub struct InlineStatement {
    pub do_0: crate::lower::model::Do,
}

impl ::prism_rtl::Job<crate::prelude::Text> for InlineStatement {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let do_0 = &self.do_0;
        match do_0 {
            crate::lower::model::Do::DoIf(c_p0, t_p1, j0_0_2) if (j0_0_2.len() == 0) => {
                let c_p0x = c_p0.clone();
                let t_p1x = t_p1.clone();
                crate::prelude::call_then(start_expression_f(c_p0x.clone()), move |expression_f_18460: crate::prelude::Text| crate::prelude::call_then(start_inline_statements_f(t_p1x.clone()), move |inline_statements_f_18478: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("if {} {{ {} }}", &expression_f_18460, &inline_statements_f_18478)))))
            },
            d_p2 => ::prism_rtl::Turn::More(::std::rc::Rc::new(Statement { d_p0: d_p2.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start InlineStatement, x`: what the function value is when passed to `@Run`.
pub fn start_inline_statement_f(do_0: crate::lower::model::Do) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(InlineStatement { do_0 })
}

/// ```prism
/// ElseBranch: unbounded fn [Do] -> Text
/// ```
pub fn else_branch_f(xs0: &crate::prelude::Array<crate::lower::model::Do>) -> crate::prelude::Text {
    'c: {
        if let c0_0 = xs0 && (c0_0.len() == 0) {
            break 'c crate::prelude::Text::lit("");
        }
        if let c1_0 = xs0 && (c1_0.len() == 1) && let ::std::option::Option::Some(crate::lower::model::Do::DoIf(c_p0, t_p1, e_p2)) = crate::prelude::index(c1_0, &crate::prelude::Nat::from(0u32)) {
            break 'c crate::prelude::Text::from(format!(" else {}", &statement_f(&crate::lower::model::Do::DoIf(c_p0.clone(), t_p1.clone(), e_p2.clone()))));
        }
        if let c2_0 = xs0 && (c2_0.len() == 1) && let ::std::option::Option::Some(crate::lower::model::Do::DoIfLet(p_p3, x_p4, t_p5, e_p6)) = crate::prelude::index(c2_0, &crate::prelude::Nat::from(0u32)) {
            break 'c crate::prelude::Text::from(format!(" else {}", &statement_f(&crate::lower::model::Do::DoIfLet(p_p3.clone(), x_p4.clone(), t_p5.clone(), e_p6.clone()))));
        }
        if let body_p7 = xs0 {
            break 'c crate::emit::rust::templates::items::else_f(&statements_f(body_p7));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `ElseBranch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ElseBranch: unbounded fn [Do] -> Text
/// ```
pub struct ElseBranch {
    pub xs0: crate::prelude::Array<crate::lower::model::Do>,
}

impl ::prism_rtl::Job<crate::prelude::Text> for ElseBranch {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let xs0 = &self.xs0;
        'j: {
            if let j0_0 = xs0 && (j0_0.len() == 0) {
                break 'j ::prism_rtl::Turn::Finished(crate::prelude::Text::lit(""));
            }
            if let j1_0 = xs0 && (j1_0.len() == 1) && let ::std::option::Option::Some(crate::lower::model::Do::DoIf(c_p0, t_p1, e_p2)) = crate::prelude::index(j1_0, &crate::prelude::Nat::from(0u32)) {
                break 'j crate::prelude::call_then(start_statement_f(crate::lower::model::Do::DoIf(c_p0.clone(), t_p1.clone(), e_p2.clone())), move |statement_f_18690: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!(" else {}", &statement_f_18690))));
            }
            if let j2_0 = xs0 && (j2_0.len() == 1) && let ::std::option::Option::Some(crate::lower::model::Do::DoIfLet(p_p3, x_p4, t_p5, e_p6)) = crate::prelude::index(j2_0, &crate::prelude::Nat::from(0u32)) {
                break 'j crate::prelude::call_then(start_statement_f(crate::lower::model::Do::DoIfLet(p_p3.clone(), x_p4.clone(), t_p5.clone(), e_p6.clone())), move |statement_f_18766: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!(" else {}", &statement_f_18766))));
            }
            if let body_p7 = xs0 {
                break 'j {
                    let body_p7x = body_p7.clone();
                    crate::prelude::call_then(start_statements_f(body_p7x.clone()), move |statements_f_18826: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::emit::rust::templates::items::else_f(&statements_f_18826)))
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start ElseBranch, x`: what the function value is when passed to `@Run`.
pub fn start_else_branch_f(xs0: crate::prelude::Array<crate::lower::model::Do>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(ElseBranch { xs0 })
}
