//! The module `Emit.Rust`, from `target/bootstrap/src/prismc/emit/rust/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod items;
pub mod prelude;
pub mod templates;

/// ```prism
/// Type: unbounded fn OutTy -> Text
/// ```
pub fn type_f(t_p0: &crate::lower::model::OutTy) -> Text {
    'm1596: {
        if let crate::lower::model::OutTy::OutNat = t_p0 {
            break 'm1596 Text::lit("Nat");
        }
        if let crate::lower::model::OutTy::OutInt = t_p0 {
            break 'm1596 Text::lit("Int");
        }
        if let crate::lower::model::OutTy::OutU8 = t_p0 {
            break 'm1596 Text::lit("u8");
        }
        if let crate::lower::model::OutTy::OutFloat = t_p0 {
            break 'm1596 Text::lit("Float");
        }
        if let crate::lower::model::OutTy::OutBool = t_p0 {
            break 'm1596 Text::lit("bool");
        }
        if let crate::lower::model::OutTy::OutChar = t_p0 {
            break 'm1596 Text::lit("char");
        }
        if let crate::lower::model::OutTy::OutText = t_p0 {
            break 'm1596 Text::lit("Text");
        }
        if let crate::lower::model::OutTy::OutCursor = t_p0 {
            break 'm1596 Text::lit("Cursor");
        }
        if let crate::lower::model::OutTy::OutRegex = t_p0 {
            break 'm1596 Text::lit("Regex");
        }
        if let crate::lower::model::OutTy::OutReplacement = t_p0 {
            break 'm1596 Text::lit("RegexReplacement");
        }
        if let crate::lower::model::OutTy::OutUnit = t_p0 {
            break 'm1596 Text::lit("()");
        }
        if let crate::lower::model::OutTy::OutPath = t_p0 {
            break 'm1596 Text::lit("Path");
        }
        if let crate::lower::model::OutTy::OutDuration = t_p0 {
            break 'm1596 Text::lit("Duration");
        }
        if let crate::lower::model::OutTy::OutError = t_p0 {
            break 'm1596 Text::lit("Error");
        }
        if let crate::lower::model::OutTy::OutNamed(n_p1, m1596_14_1) = t_p0 && (m1596_14_1.len() == 0) {
            break 'm1596 n_p1.clone();
        }
        if let crate::lower::model::OutTy::OutNamed(n_p2, args_p3) = t_p0 {
            break 'm1596 Text::from(format!("{}<{}>", n_p2, &types_f(args_p3)));
        }
        if let crate::lower::model::OutTy::OutOpt(i_p4) = t_p0 {
            break 'm1596 Text::from(format!("Option<{}>", &type_f(&**i_p4)));
        }
        if let crate::lower::model::OutTy::OutRes(i_p5) = t_p0 {
            break 'm1596 Text::from(format!("Result<{}, Error>", &type_f(&**i_p5)));
        }
        if let crate::lower::model::OutTy::OutTuple(m1596_18_0) = t_p0 && (m1596_18_0.len() == 1) && let Some(one_p6) = crate::prelude::index(m1596_18_0, &Nat::from(0u32)) {
            break 'm1596 Text::from(format!("({},)", &type_f(&one_p6)));
        }
        if let crate::lower::model::OutTy::OutTuple(ts_p7) = t_p0 {
            break 'm1596 Text::from(format!("({})", &types_f(ts_p7)));
        }
        if let crate::lower::model::OutTy::OutArray(e_p8) = t_p0 {
            break 'm1596 Text::from(format!("Array<{}>", &type_f(&**e_p8)));
        }
        if let crate::lower::model::OutTy::OutMap(k_p9, v_pa) = t_p0 {
            break 'm1596 Text::from(format!("Map<{}, {}>", &type_f(&**k_p9), &type_f(&**v_pa)));
        }
        if let crate::lower::model::OutTy::OutFn(ps_pb, r_pc) = t_p0 {
            break 'm1596 Text::from(format!("Rc<dyn Fn({}) -> {}>", &ref_types_f(ps_pb), &type_f(&**r_pc)));
        }
        if let crate::lower::model::OutTy::OutRef(i_pd) = t_p0 {
            break 'm1596 Text::from(format!("&{}", &type_f(&**i_pd)));
        }
        if let crate::lower::model::OutTy::OutJobFn(a_pe, b_pf) = t_p0 {
            break 'm1596 Text::from(format!("Rc<dyn Fn({}) -> Rc<dyn prism_rtl::Job<{}>>>", &type_f(&**a_pe), &type_f(&**b_pf)));
        }
        if let crate::lower::model::OutTy::OutJob(b_pg) = t_p0 {
            break 'm1596 Text::from(format!("Rc<dyn prism_rtl::Job<{}>>", &type_f(&**b_pg)));
        }
        if let crate::lower::model::OutTy::OutEvent(i_ph) = t_p0 {
            break 'm1596 Text::from(format!("Event<{}>", &type_f(&**i_ph)));
        }
        if let crate::lower::model::OutTy::OutDyn(i_pi) = t_p0 {
            break 'm1596 Text::from(format!("Dynamic<{}>", &type_f(&**i_pi)));
        }
        if let crate::lower::model::OutTy::OutGen(n_pj) = t_p0 {
            break 'm1596 n_pj.clone();
        }
        if let crate::lower::model::OutTy::OutRc(i_pk) = t_p0 {
            break 'm1596 Text::from(format!("Rc<{}>", &type_f(&**i_pk)));
        }
        if let crate::lower::model::OutTy::OutPod = t_p0 {
            break 'm1596 Text::lit("Pod");
        }
        if let crate::lower::model::OutTy::OutShowAny = t_p0 {
            break 'm1596 Text::lit("Rc<dyn Show>");
        }
        if let crate::lower::model::OutTy::OutHold(i_pl) = t_p0 {
            break 'm1596 Text::from(format!("Hold<{}>", &type_f(&**i_pl)));
        }
        if let crate::lower::model::OutTy::OutStamped(i_pm) = t_p0 {
            break 'm1596 Text::from(format!("Stamped<{}>", &type_f(&**i_pm)));
        }
        if let crate::lower::model::OutTy::OutSnapshot(i_pn) = t_p0 {
            break 'm1596 Text::from(format!("Snapshot<{}>", &type_f(&**i_pn)));
        }
        if let crate::lower::model::OutTy::OutDefer(i_po) = t_p0 {
            break 'm1596 Text::from(format!("Defer<{}>", &type_f(&**i_po)));
        }
        if let crate::lower::model::OutTy::OutWeak(n_pp) = t_p0 {
            break 'm1596 Text::from(format!("Weak<{}>", n_pp));
        }
        if let crate::lower::model::OutTy::OutCell(i_pq) = t_p0 {
            break 'm1596 Text::from(format!("RefCell<{}>", &type_f(&**i_pq)));
        }
        if let crate::lower::model::OutTy::OutWakes = t_p0 {
            break 'm1596 Text::lit("Wakes");
        }
        if let crate::lower::model::OutTy::OutCount = t_p0 {
            break 'm1596 Text::lit("u32");
        }
        if let crate::lower::model::OutTy::OutObj(i_pr) = t_p0 {
            break 'm1596 Text::from(format!("Rc<dyn {}>", &type_f(&**i_pr)));
        }
        if let crate::lower::model::OutTy::OutSlice(i_ps) = t_p0 {
            break 'm1596 Text::from(format!("[{}]", &type_f(&**i_ps)));
        }
        if let crate::lower::model::OutTy::OutPort(i_pt) = t_p0 {
            break 'm1596 Text::from(format!("Port<{}>", &type_f(&**i_pt)));
        }
        if let crate::lower::model::OutTy::OutLive(i_pu) = t_p0 {
            break 'm1596 Text::from(format!("Live<{}>", &type_f(&**i_pu)));
        }
        if let crate::lower::model::OutTy::OutTurn = t_p0 {
            break 'm1596 Text::lit("() /* the job\'s turn */");
        }
        if let crate::lower::model::OutTy::OutRefused(what_pv) = t_p0 {
            break 'm1596 Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::expr::lowering_refusal_p(), what_pv));
        }
        if let crate::lower::model::OutTy::OutQuantified(b_p10) = t_p0 {
            break 'm1596 Text::from(format!("compile_error!(\"{}a quantified type variable of `{}`: no instantiation gives it a type\")", &crate::lower::expr::lowering_refusal_p(), b_p10));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `Type`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Type: unbounded fn OutTy -> Text
/// ```
pub struct Type {
    pub t_p0: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for Type {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t_p0 = &self.t_p0;
        'm1596: {
            if let crate::lower::model::OutTy::OutNat = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Nat"));
            }
            if let crate::lower::model::OutTy::OutInt = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Int"));
            }
            if let crate::lower::model::OutTy::OutU8 = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("u8"));
            }
            if let crate::lower::model::OutTy::OutFloat = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Float"));
            }
            if let crate::lower::model::OutTy::OutBool = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("bool"));
            }
            if let crate::lower::model::OutTy::OutChar = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("char"));
            }
            if let crate::lower::model::OutTy::OutText = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Text"));
            }
            if let crate::lower::model::OutTy::OutCursor = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Cursor"));
            }
            if let crate::lower::model::OutTy::OutRegex = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Regex"));
            }
            if let crate::lower::model::OutTy::OutReplacement = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("RegexReplacement"));
            }
            if let crate::lower::model::OutTy::OutUnit = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("()"));
            }
            if let crate::lower::model::OutTy::OutPath = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Path"));
            }
            if let crate::lower::model::OutTy::OutDuration = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Duration"));
            }
            if let crate::lower::model::OutTy::OutError = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Error"));
            }
            if let crate::lower::model::OutTy::OutNamed(n_p1, m1596_14_1) = t_p0 && (m1596_14_1.len() == 0) {
                break 'm1596 prism_rtl::Turn::Finished(n_p1.clone());
            }
            if let crate::lower::model::OutTy::OutNamed(n_p2, args_p3) = t_p0 {
                break 'm1596 {
                    let args_p3x = args_p3.clone();
                    let n_p2x = n_p2.clone();
                    crate::prelude::call_then(start_types_f(args_p3x.clone()), move |types_f_1964: Text| prism_rtl::Turn::Finished(Text::from(format!("{}<{}>", &n_p2x, &types_f_1964))))
                };
            }
            if let crate::lower::model::OutTy::OutOpt(i_p4) = t_p0 {
                break 'm1596 {
                    let i_p4x = (**i_p4).clone();
                    crate::prelude::call_then(start_type_f(i_p4x.clone()), move |type_f_2001: Text| prism_rtl::Turn::Finished(Text::from(format!("Option<{}>", &type_f_2001))))
                };
            }
            if let crate::lower::model::OutTy::OutRes(i_p5) = t_p0 {
                break 'm1596 {
                    let i_p5x = (**i_p5).clone();
                    crate::prelude::call_then(start_type_f(i_p5x.clone()), move |type_f_2034: Text| prism_rtl::Turn::Finished(Text::from(format!("Result<{}, Error>", &type_f_2034))))
                };
            }
            if let crate::lower::model::OutTy::OutTuple(m1596_18_0) = t_p0 && (m1596_18_0.len() == 1) && let Some(one_p6) = crate::prelude::index(m1596_18_0, &Nat::from(0u32)) {
                break 'm1596 crate::prelude::call_then(start_type_f(one_p6.clone()), move |type_f_2076: Text| prism_rtl::Turn::Finished(Text::from(format!("({},)", &type_f_2076))));
            }
            if let crate::lower::model::OutTy::OutTuple(ts_p7) = t_p0 {
                break 'm1596 {
                    let ts_p7x = ts_p7.clone();
                    crate::prelude::call_then(start_types_f(ts_p7x.clone()), move |types_f_2109: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &types_f_2109))))
                };
            }
            if let crate::lower::model::OutTy::OutArray(e_p8) = t_p0 {
                break 'm1596 {
                    let e_p8x = (**e_p8).clone();
                    crate::prelude::call_then(start_type_f(e_p8x.clone()), move |type_f_2145: Text| prism_rtl::Turn::Finished(Text::from(format!("Array<{}>", &type_f_2145))))
                };
            }
            if let crate::lower::model::OutTy::OutMap(k_p9, v_pa) = t_p0 {
                break 'm1596 {
                    let k_p9x = (**k_p9).clone();
                    let v_pax = (**v_pa).clone();
                    crate::prelude::call_then(start_type_f(k_p9x.clone()), move |type_f_2178: Text| crate::prelude::call_then(start_type_f(v_pax.clone()), move |type_f_2188: Text| prism_rtl::Turn::Finished(Text::from(format!("Map<{}, {}>", &type_f_2178, &type_f_2188)))))
                };
            }
            if let crate::lower::model::OutTy::OutFn(ps_pb, r_pc) = t_p0 {
                break 'm1596 {
                    let ps_pbx = ps_pb.clone();
                    let r_pcx = (**r_pc).clone();
                    crate::prelude::call_then(start_ref_types_f(ps_pbx.clone()), move |ref_types_f_2227: Text| crate::prelude::call_then(start_type_f(r_pcx.clone()), move |type_f_2245: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<dyn Fn({}) -> {}>", &ref_types_f_2227, &type_f_2245)))))
                };
            }
            if let crate::lower::model::OutTy::OutRef(i_pd) = t_p0 {
                break 'm1596 {
                    let i_pdx = (**i_pd).clone();
                    crate::prelude::call_then(start_type_f(i_pdx.clone()), move |type_f_2272: Text| prism_rtl::Turn::Finished(Text::from(format!("&{}", &type_f_2272))))
                };
            }
            if let crate::lower::model::OutTy::OutJobFn(a_pe, b_pf) = t_p0 {
                break 'm1596 {
                    let a_pex = (**a_pe).clone();
                    let b_pfx = (**b_pf).clone();
                    crate::prelude::call_then(start_type_f(a_pex.clone()), move |type_f_2312: Text| crate::prelude::call_then(start_type_f(b_pfx.clone()), move |type_f_2347: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<dyn Fn({}) -> Rc<dyn prism_rtl::Job<{}>>>", &type_f_2312, &type_f_2347)))))
                };
            }
            if let crate::lower::model::OutTy::OutJob(b_pg) = t_p0 {
                break 'm1596 {
                    let b_pgx = (**b_pg).clone();
                    crate::prelude::call_then(start_type_f(b_pgx.clone()), move |type_f_2397: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<dyn prism_rtl::Job<{}>>", &type_f_2397))))
                };
            }
            if let crate::lower::model::OutTy::OutEvent(i_ph) = t_p0 {
                break 'm1596 {
                    let i_phx = (**i_ph).clone();
                    crate::prelude::call_then(start_type_f(i_phx.clone()), move |type_f_2432: Text| prism_rtl::Turn::Finished(Text::from(format!("Event<{}>", &type_f_2432))))
                };
            }
            if let crate::lower::model::OutTy::OutDyn(i_pi) = t_p0 {
                break 'm1596 {
                    let i_pix = (**i_pi).clone();
                    crate::prelude::call_then(start_type_f(i_pix.clone()), move |type_f_2466: Text| prism_rtl::Turn::Finished(Text::from(format!("Dynamic<{}>", &type_f_2466))))
                };
            }
            if let crate::lower::model::OutTy::OutGen(n_pj) = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(n_pj.clone());
            }
            if let crate::lower::model::OutTy::OutRc(i_pk) = t_p0 {
                break 'm1596 {
                    let i_pkx = (**i_pk).clone();
                    crate::prelude::call_then(start_type_f(i_pkx.clone()), move |type_f_2510: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<{}>", &type_f_2510))))
                };
            }
            if let crate::lower::model::OutTy::OutPod = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Pod"));
            }
            if let crate::lower::model::OutTy::OutShowAny = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Rc<dyn Show>"));
            }
            if let crate::lower::model::OutTy::OutHold(i_pl) = t_p0 {
                break 'm1596 {
                    let i_plx = (**i_pl).clone();
                    crate::prelude::call_then(start_type_f(i_plx.clone()), move |type_f_2591: Text| prism_rtl::Turn::Finished(Text::from(format!("Hold<{}>", &type_f_2591))))
                };
            }
            if let crate::lower::model::OutTy::OutStamped(i_pm) = t_p0 {
                break 'm1596 {
                    let i_pmx = (**i_pm).clone();
                    crate::prelude::call_then(start_type_f(i_pmx.clone()), move |type_f_2629: Text| prism_rtl::Turn::Finished(Text::from(format!("Stamped<{}>", &type_f_2629))))
                };
            }
            if let crate::lower::model::OutTy::OutSnapshot(i_pn) = t_p0 {
                break 'm1596 {
                    let i_pnx = (**i_pn).clone();
                    crate::prelude::call_then(start_type_f(i_pnx.clone()), move |type_f_2669: Text| prism_rtl::Turn::Finished(Text::from(format!("Snapshot<{}>", &type_f_2669))))
                };
            }
            if let crate::lower::model::OutTy::OutDefer(i_po) = t_p0 {
                break 'm1596 {
                    let i_pox = (**i_po).clone();
                    crate::prelude::call_then(start_type_f(i_pox.clone()), move |type_f_2703: Text| prism_rtl::Turn::Finished(Text::from(format!("Defer<{}>", &type_f_2703))))
                };
            }
            if let crate::lower::model::OutTy::OutWeak(n_pp) = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::from(format!("Weak<{}>", n_pp)));
            }
            if let crate::lower::model::OutTy::OutCell(i_pq) = t_p0 {
                break 'm1596 {
                    let i_pqx = (**i_pq).clone();
                    crate::prelude::call_then(start_type_f(i_pqx.clone()), move |type_f_2765: Text| prism_rtl::Turn::Finished(Text::from(format!("RefCell<{}>", &type_f_2765))))
                };
            }
            if let crate::lower::model::OutTy::OutWakes = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("Wakes"));
            }
            if let crate::lower::model::OutTy::OutCount = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("u32"));
            }
            if let crate::lower::model::OutTy::OutObj(i_pr) = t_p0 {
                break 'm1596 {
                    let i_prx = (**i_pr).clone();
                    crate::prelude::call_then(start_type_f(i_prx.clone()), move |type_f_2840: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<dyn {}>", &type_f_2840))))
                };
            }
            if let crate::lower::model::OutTy::OutSlice(i_ps) = t_p0 {
                break 'm1596 {
                    let i_psx = (**i_ps).clone();
                    crate::prelude::call_then(start_type_f(i_psx.clone()), move |type_f_2869: Text| prism_rtl::Turn::Finished(Text::from(format!("[{}]", &type_f_2869))))
                };
            }
            if let crate::lower::model::OutTy::OutPort(i_pt) = t_p0 {
                break 'm1596 {
                    let i_ptx = (**i_pt).clone();
                    crate::prelude::call_then(start_type_f(i_ptx.clone()), move |type_f_2901: Text| prism_rtl::Turn::Finished(Text::from(format!("Port<{}>", &type_f_2901))))
                };
            }
            if let crate::lower::model::OutTy::OutLive(i_pu) = t_p0 {
                break 'm1596 {
                    let i_pux = (**i_pu).clone();
                    crate::prelude::call_then(start_type_f(i_pux.clone()), move |type_f_2933: Text| prism_rtl::Turn::Finished(Text::from(format!("Live<{}>", &type_f_2933))))
                };
            }
            if let crate::lower::model::OutTy::OutTurn = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::lit("() /* the job\'s turn */"));
            }
            if let crate::lower::model::OutTy::OutRefused(what_pv) = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::expr::lowering_refusal_p(), what_pv)));
            }
            if let crate::lower::model::OutTy::OutQuantified(b_p10) = t_p0 {
                break 'm1596 prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}a quantified type variable of `{}`: no instantiation gives it a type\")", &crate::lower::expr::lowering_refusal_p(), b_p10)));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start Type, x`: what the function value is when passed to `@Run`.
pub fn start_type_f(t_p0: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Type { t_p0 })
}

/// ```prism
/// Types: unbounded fn [OutTy] -> Text
/// ```
pub fn types_f(ts_p0: &Array<crate::lower::model::OutTy>) -> Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(ts_p0.clone(), Rc::new(move |p0: crate::lower::model::OutTy| crate::prelude::entered(crate::prelude::once_job(move || {
        let t_p1 = p0;
        prism_rtl::Turn::More(Rc::new(Type { t_p0: t_p1.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))
}

/// The step machine of `Types`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Types: unbounded fn [OutTy] -> Text
/// ```
pub struct Types {
    pub ts_p0: Array<crate::lower::model::OutTy>,
}

impl prism_rtl::Job<Text> for Types {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let ts_p0 = &self.ts_p0;
        let ts_p0x = ts_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(ts_p0x.clone(), Rc::new(move |p0: crate::lower::model::OutTy| crate::prelude::entered(crate::prelude::once_job(move || {
            let t_p1 = p0;
            prism_rtl::Turn::More(Rc::new(Type { t_p0: t_p1.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_3236: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join_f(&each_3236, &Text::lit(", "))))
    }
}

/// `Start Types, x`: what the function value is when passed to `@Run`.
pub fn start_types_f(ts_p0: Array<crate::lower::model::OutTy>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Types { ts_p0 })
}

/// ```prism
/// RefTypes: unbounded fn [OutTy] -> Text
/// ```
pub fn ref_types_f(ts_p0: &Array<crate::lower::model::OutTy>) -> Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(ts_p0.clone(), Rc::new(move |p0: crate::lower::model::OutTy| crate::prelude::entered(crate::prelude::once_job(move || {
        let t_p1 = p0;
        crate::prelude::call_then(start_type_f(t_p1.clone()), move |type_f_3344: Text| prism_rtl::Turn::Finished(Text::from(format!("&{}", &type_f_3344))))
    }))) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))
}

/// The step machine of `RefTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RefTypes: unbounded fn [OutTy] -> Text
/// ```
pub struct RefTypes {
    pub ts_p0: Array<crate::lower::model::OutTy>,
}

impl prism_rtl::Job<Text> for RefTypes {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let ts_p0 = &self.ts_p0;
        let ts_p0x = ts_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(ts_p0x.clone(), Rc::new(move |p0: crate::lower::model::OutTy| crate::prelude::entered(crate::prelude::once_job(move || {
            let t_p1 = p0;
            crate::prelude::call_then(start_type_f(t_p1.clone()), move |type_f_3344: Text| prism_rtl::Turn::Finished(Text::from(format!("&{}", &type_f_3344))))
        }))) as Rc<dyn Fn(crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_3327: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join_f(&each_3327, &Text::lit(", "))))
    }
}

/// `Start RefTypes, x`: what the function value is when passed to `@Run`.
pub fn start_ref_types_f(ts_p0: Array<crate::lower::model::OutTy>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RefTypes { ts_p0 })
}

/// ```prism
/// IsLoose: fn Ex -> Bool
/// ```
pub fn is_loose_f(x_p0: &crate::lower::model::Ex) -> bool {
    match x_p0 {
        crate::lower::model::Ex::XBlock(m3669_0_0, inner_p1) if (m3669_0_0.len() == 0) => is_loose_f(&**inner_p1),
        crate::lower::model::Ex::XTyped(inner_p2, _) => is_loose_f(&**inner_p2),
        crate::lower::model::Ex::XBin(_, _, _) => true,
        crate::lower::model::Ex::XUnary(_, _) => true,
        crate::lower::model::Ex::XClosure(_, _, _) => true,
        crate::lower::model::Ex::XIf(_, _, _) => true,
        crate::lower::model::Ex::XMatch(_, _, _, _) => true,
        crate::lower::model::Ex::XChain(_, _, _, _) => true,
        crate::lower::model::Ex::XCast(_, _) => true,
        crate::lower::model::Ex::XRef(_) => true,
        crate::lower::model::Ex::XRefMut(_) => true,
        crate::lower::model::Ex::XDeref(_) => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Tight: unbounded fn Ex -> Text
/// ```
pub fn tight_f(x_p0: &crate::lower::model::Ex) -> Text {
    if is_loose_f(x_p0) {
        Text::from(format!("({})", &expression_f(x_p0)))
    } else {
        expression_f(x_p0)
    }
}

/// The step machine of `Tight`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Tight: unbounded fn Ex -> Text
/// ```
pub struct Tight {
    pub x_p0: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for Tight {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let x_p0 = &self.x_p0;
        if is_loose_f(x_p0) {
            {
                let x_p0x = x_p0.clone();
                crate::prelude::call_then(start_expression_f(x_p0x.clone()), move |expression_f_4186: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_f_4186))))
            }
        } else {
            prism_rtl::Turn::More(Rc::new(Expression { x_p0: x_p0.clone() }))
        }
    }
}

/// `Start Tight, x`: what the function value is when passed to `@Run`.
pub fn start_tight_f(x_p0: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Tight { x_p0 })
}

/// ```prism
/// Operand: unbounded fn Ex -> Text
/// ```
pub fn operand_f(x_p0: &crate::lower::model::Ex) -> Text {
    match x_p0 {
        crate::lower::model::Ex::XBlock(m4270_0_0, inner_p1) if (m4270_0_0.len() == 0) => operand_f(&**inner_p1),
        crate::lower::model::Ex::XTyped(inner_p2, _) => operand_f(&**inner_p2),
        crate::lower::model::Ex::XBin(_, _, _) => Text::from(format!("({})", &expression_f(x_p0))),
        crate::lower::model::Ex::XClosure(_, _, _) => Text::from(format!("({})", &expression_f(x_p0))),
        crate::lower::model::Ex::XIf(_, _, _) => Text::from(format!("({})", &expression_f(x_p0))),
        crate::lower::model::Ex::XCast(_, _) => Text::from(format!("({})", &expression_f(x_p0))),
        _ => expression_f(x_p0),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `Operand`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Operand: unbounded fn Ex -> Text
/// ```
pub struct Operand {
    pub x_p0: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for Operand {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let x_p0 = &self.x_p0;
        match x_p0 {
            crate::lower::model::Ex::XBlock(m4270_0_0, inner_p1) if (m4270_0_0.len() == 0) => prism_rtl::Turn::More(Rc::new(Operand { x_p0: (**inner_p1).clone() })),
            crate::lower::model::Ex::XTyped(inner_p2, _) => prism_rtl::Turn::More(Rc::new(Operand { x_p0: (**inner_p2).clone() })),
            crate::lower::model::Ex::XBin(_, _, _) => {
                let x_p0x = x_p0.clone();
                crate::prelude::call_then(start_expression_f(x_p0x.clone()), move |expression_f_4393: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_f_4393))))
            },
            crate::lower::model::Ex::XClosure(_, _, _) => {
                let x_p0x = x_p0.clone();
                crate::prelude::call_then(start_expression_f(x_p0x.clone()), move |expression_f_4449: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_f_4449))))
            },
            crate::lower::model::Ex::XIf(_, _, _) => {
                let x_p0x = x_p0.clone();
                crate::prelude::call_then(start_expression_f(x_p0x.clone()), move |expression_f_4500: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_f_4500))))
            },
            crate::lower::model::Ex::XCast(_, _) => {
                let x_p0x = x_p0.clone();
                crate::prelude::call_then(start_expression_f(x_p0x.clone()), move |expression_f_4545: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_f_4545))))
            },
            _ => prism_rtl::Turn::More(Rc::new(Expression { x_p0: x_p0.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start Operand, x`: what the function value is when passed to `@Run`.
pub fn start_operand_f(x_p0: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Operand { x_p0 })
}

/// ```prism
/// Args: unbounded fn [Ex] -> Text
/// ```
pub fn args_f(xs_p0: &Array<crate::lower::model::Ex>) -> Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(xs_p0.clone(), Rc::new(move |p0: crate::lower::model::Ex| crate::prelude::entered(crate::prelude::once_job(move || {
        let x_p1 = p0;
        prism_rtl::Turn::More(Rc::new(Expression { x_p0: x_p1.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))
}

/// The step machine of `Args`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Args: unbounded fn [Ex] -> Text
/// ```
pub struct Args {
    pub xs_p0: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for Args {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let xs_p0 = &self.xs_p0;
        let xs_p0x = xs_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(xs_p0x.clone(), Rc::new(move |p0: crate::lower::model::Ex| crate::prelude::entered(crate::prelude::once_job(move || {
            let x_p1 = p0;
            prism_rtl::Turn::More(Rc::new(Expression { x_p0: x_p1.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_4641: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join_f(&each_4641, &Text::lit(", "))))
    }
}

/// `Start Args, x`: what the function value is when passed to `@Run`.
pub fn start_args_f(xs_p0: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Args { xs_p0 })
}

/// ```prism
/// Expression: unbounded fn Ex -> Text
/// ```
pub fn expression_f(x_p0: &crate::lower::model::Ex) -> Text {
    'm4730: {
        if let crate::lower::model::Ex::XVar(n_p1) = x_p0 {
            break 'm4730 n_p1.clone();
        }
        if let crate::lower::model::Ex::XPath(p_p2) = x_p0 {
            break 'm4730 p_p2.clone();
        }
        if let crate::lower::model::Ex::XSelf = x_p0 {
            break 'm4730 Text::lit("self");
        }
        if let crate::lower::model::Ex::XCx = x_p0 {
            break 'm4730 Text::lit("cx");
        }
        if let crate::lower::model::Ex::XConst(n_p3) = x_p0 {
            break 'm4730 Text::from(format!("Self::{}", n_p3));
        }
        if let crate::lower::model::Ex::XUnit = x_p0 {
            break 'm4730 Text::lit("()");
        }
        if let crate::lower::model::Ex::XNone = x_p0 {
            break 'm4730 Text::lit("None");
        }
        if let crate::lower::model::Ex::XBool(b_p4) = x_p0 {
            break 'm4730 if *b_p4 { Text::lit("true") } else { Text::lit("false") };
        }
        if let crate::lower::model::Ex::XNat(d_p5) = x_p0 {
            break 'm4730 if &crate::prelude::len_text(d_p5) <= &Nat::from(9u32) {
                Text::from(format!("Nat::from({}u32)", d_p5))
            } else {
                if &crate::prelude::len_text(d_p5) <= &Nat::from(18u32) {
                    Text::from(format!("Nat::from_int(Int::from({}i64)).unwrap()", d_p5))
                } else {
                    Text::from(format!("Nat::from_int(Int::parse(\"{}\").unwrap()).unwrap()", d_p5))
                }
            };
        }
        if let crate::lower::model::Ex::XInt(d_p6) = x_p0 {
            break 'm4730 if &crate::prelude::len_text(&(if crate::syntax::lexer::chars::has_prefix_f(d_p6, &Text::lit("-")) {
                crate::syntax::lexer::chars::after_first_f(d_p6)
            } else {
                d_p6.clone()
            })) <= &Nat::from(18u32) {
                Text::from(format!("Int::from({})", d_p6))
            } else {
                Text::from(format!("Int::parse(\"{}\").unwrap()", d_p6))
            };
        }
        if let crate::lower::model::Ex::XByte(d_p7) = x_p0 {
            break 'm4730 Text::from(format!("{}u8", d_p7));
        }
        if let crate::lower::model::Ex::XFloat(d_p8) = x_p0 {
            break 'm4730 Text::from(format!("Float({})", d_p8));
        }
        if let crate::lower::model::Ex::XIndex(n_p9) = x_p0 {
            break 'm4730 Text::from(format!("{}", n_p9));
        }
        if let crate::lower::model::Ex::XChar(c_pa) = x_p0 {
            break 'm4730 Text::from(format!("\'{}\'", &crate::lower::expr::char_escape_f(c_pa)));
        }
        if let crate::lower::model::Ex::XStr(t_pb) = x_p0 {
            break 'm4730 Text::from(format!("\"{}\"", &crate::lower::expr::escape_f(t_pb)));
        }
        if let crate::lower::model::Ex::XRegex(p_pc, f_pd) = x_p0 {
            break 'm4730 Text::from(format!("{{ thread_local!(static R: Regex = Regex::lit(\"{}\", \"{}\")); R.with(Regex::clone) }}", &crate::lower::expr::escape_f(p_pc), &crate::lower::expr::escape_f(f_pd)));
        }
        if let crate::lower::model::Ex::XReplacement(p_pe, r_pf, f_pg) = x_p0 {
            break 'm4730 Text::from(format!("{{ thread_local!(static R: RegexReplacement = RegexReplacement::lit(\"{}\", \"{}\", \"{}\")); R.with(RegexReplacement::clone) }}", &crate::lower::expr::escape_f(p_pe), &crate::lower::expr::escape_f(f_pg), &crate::lower::expr::escape_f(r_pf)));
        }
        if let crate::lower::model::Ex::XRef(y_ph) = x_p0 {
            break 'm4730 Text::from(format!("&{}", &operand_f(&**y_ph)));
        }
        if let crate::lower::model::Ex::XRefMut(y_pi) = x_p0 {
            break 'm4730 Text::from(format!("&mut {}", &operand_f(&**y_pi)));
        }
        if let crate::lower::model::Ex::XDeref(y_pj) = x_p0 {
            break 'm4730 Text::from(format!("*{}", &operand_f(&**y_pj)));
        }
        if let crate::lower::model::Ex::XTarget(y_pk) = x_p0 {
            break 'm4730 Text::from(format!("(*{})", &expression_f(&**y_pk)));
        }
        if let crate::lower::model::Ex::XClone(y_pl) = x_p0 {
            break 'm4730 Text::from(format!("{}.clone()", &tight_f(&**y_pl)));
        }
        if let crate::lower::model::Ex::XWeak(y_pm) = x_p0 {
            break 'm4730 Text::from(format!("Rc::downgrade({})", &expression_f(&**y_pm)));
        }
        if let crate::lower::model::Ex::XUpgrade(y_pn) = x_p0 {
            break 'm4730 Text::from(format!("{}.upgrade()", &tight_f(&**y_pn)));
        }
        if let crate::lower::model::Ex::XBreak(l_po, y_pp) = x_p0 {
            break 'm4730 Text::from(format!("break {} {}", &label_f(l_po), &expression_f(&**y_pp)));
        }
        if let crate::lower::model::Ex::XBreakLoop = x_p0 {
            break 'm4730 Text::lit("break");
        }
        if let crate::lower::model::Ex::XLater(y_pq) = x_p0 {
            break 'm4730 Text::from(format!("Box::new(move |cx| {{ {}; Ok(()) }})", &expression_f(&**y_pq)));
        }
        if let crate::lower::model::Ex::XFormatStr(parts_pr) = x_p0 {
            break 'm4730 format_str_f(parts_pr);
        }
        if let crate::lower::model::Ex::XIsCase(y_ps, m4730_28_1) = x_p0 && (m4730_28_1.len() == 0) {
            break 'm4730 Text::lit("false");
        }
        if let crate::lower::model::Ex::XIsCase(y_pt, cs_pu) = x_p0 {
            break 'm4730 Text::from(format!("matches!({}, {})", &expression_f(&**y_pt), &crate::syntax::lexer::chars::join_f(&crate::prelude::each(cs_pu, &(|c_pv: &Text| Text::from(format!("{}(..)", c_pv)))), &Text::lit(" | "))));
        }
        if let crate::lower::model::Ex::XRefusal(what_p10) = x_p0 {
            break 'm4730 Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::expr::lowering_refusal_p(), &crate::lower::expr::escape_f(what_p10)));
        }
        if let crate::lower::model::Ex::XUnreachable = x_p0 {
            break 'm4730 Text::lit("unreachable!()");
        }
        if let crate::lower::model::Ex::XCall(f_p11, args_p12) = x_p0 {
            break 'm4730 Text::from(format!("{}({})", f_p11, &args_f(args_p12)));
        }
        if let crate::lower::model::Ex::XApply(f_p13, args_p14) = x_p0 {
            break 'm4730 Text::from(format!("{}({})", &tight_f(&**f_p13), &args_f(args_p14)));
        }
        if let crate::lower::model::Ex::XMethod(r_p15, m_p16, args_p17) = x_p0 {
            break 'm4730 Text::from(format!("{}.{}({})", &tight_f(&**r_p15), m_p16, &args_f(args_p17)));
        }
        if let crate::lower::model::Ex::XBin(op_p18, l_p19, r_p1a) = x_p0 {
            break 'm4730 Text::from(format!("{} {} {}", &operand_f(&**l_p19), &crate::lower::model::bin_op_text_f(op_p18), &operand_f(&**r_p1a)));
        }
        if let crate::lower::model::Ex::XUnary(op_p1b, y_p1c) = x_p0 {
            break 'm4730 Text::from(format!("{}{}", &crate::lower::model::un_op_text_f(op_p1b), &operand_f(&**y_p1c)));
        }
        if let crate::lower::model::Ex::XCtor(p_p1d, args_p1e) = x_p0 {
            break 'm4730 Text::from(format!("{}({})", p_p1d, &args_f(args_p1e)));
        }
        if let crate::lower::model::Ex::XRecord(p_p1f, fs_p1g) = x_p0 {
            break 'm4730 Text::from(format!("{} {{ {} }}", p_p1f, &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(fs_p1g.clone(), Rc::new(move |p0: (Text, crate::lower::model::Ex)| crate::prelude::entered(crate::prelude::once_job(move || {
                let (f_p1h, v_p1i) = p0;
                prism_rtl::Turn::More(Rc::new(FieldInit { f_p0: f_p1h.clone(), ex1: v_p1i.clone() }))
            }))) as Rc<dyn Fn((Text, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))));
        }
        if let crate::lower::model::Ex::XTuple(m4730_39_0) = x_p0 && (m4730_39_0.len() == 1) && let Some(one_p1j) = crate::prelude::index(m4730_39_0, &Nat::from(0u32)) {
            break 'm4730 Text::from(format!("({},)", &expression_f(&one_p1j)));
        }
        if let crate::lower::model::Ex::XTuple(xs_p1k) = x_p0 {
            break 'm4730 Text::from(format!("({})", &args_f(xs_p1k)));
        }
        if let crate::lower::model::Ex::XVec(xs_p1l) = x_p0 {
            break 'm4730 Text::from(format!("vec![{}]", &args_f(xs_p1l)));
        }
        if let crate::lower::model::Ex::XText(t_p1m) = x_p0 {
            break 'm4730 Text::from(format!("Text::lit(\"{}\")", &crate::lower::expr::escape_f(t_p1m)));
        }
        if let crate::lower::model::Ex::XFormat(parts_p1n) = x_p0 {
            break 'm4730 format_f(parts_p1n);
        }
        if let crate::lower::model::Ex::XMatch(s_p1o, arms_p1p, fallback_p1q, _) = x_p0 {
            break 'm4730 crate::emit::rust::templates::items::match_block_f(&expression_f(&**s_p1o), &arms_f(arms_p1p, fallback_p1q));
        }
        if let crate::lower::model::Ex::XChain(label_p1r, s_p1s, arms_p1t, _) = x_p0 {
            break 'm4730 chain_f(&label_f(label_p1r), &**s_p1s, arms_p1t);
        }
        if let crate::lower::model::Ex::XIf(c_p1u, t_p1v, e_p20) = x_p0 {
            break 'm4730 if_expression_f(&**c_p1u, &**t_p1v, &**e_p20);
        }
        if let crate::lower::model::Ex::XBlock(m4730_47_0, e_p21) = x_p0 && (m4730_47_0.len() == 0) {
            break 'm4730 expression_f(&**e_p21);
        }
        if let crate::lower::model::Ex::XBlock(dos_p22, e_p23) = x_p0 {
            break 'm4730 crate::emit::rust::templates::items::block_f(&statements_f(dos_p22), &expression_f(&**e_p23));
        }
        if let crate::lower::model::Ex::XLabeled(label_p24, dos_p25, e_p26, _) = x_p0 {
            break 'm4730 crate::emit::rust::templates::items::labeled_f(&label_f(label_p24), &statements_f(dos_p25), &expression_f(&**e_p26));
        }
        if let crate::lower::model::Ex::XClosure(mv_p27, ps_p28, body_p29) = x_p0 {
            break 'm4730 Text::from(format!("{}|{}| {}", &(if *mv_p27 { Text::lit("move ") } else { Text::lit("") }), &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(ps_p28.clone(), Rc::new(move |p0: crate::lower::model::Pa| crate::prelude::entered(crate::prelude::once_job(move || {
                let p_p2a = p0;
                prism_rtl::Turn::More(Rc::new(Pattern_ { p_p0: p_p2a.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", ")), &expression_f(&**body_p29)));
        }
        if let crate::lower::model::Ex::XTry(y_p2b) = x_p0 {
            break 'm4730 Text::from(format!("{}?", &tight_f(&**y_p2b)));
        }
        if let crate::lower::model::Ex::XField(r_p2c, f_p2d) = x_p0 {
            break 'm4730 Text::from(format!("{}.{}", &tight_f(&**r_p2c), f_p2d));
        }
        if let crate::lower::model::Ex::XPart(r_p2e, k_p2f) = x_p0 {
            break 'm4730 Text::from(format!("{}.{}", &tight_f(&**r_p2e), k_p2f));
        }
        if let crate::lower::model::Ex::XDecode(t_p2g, y_p2h) = x_p0 {
            break 'm4730 Text::from(format!("{}::from_pod({})?", &decode_head_f(t_p2g), &expression_f(&**y_p2h)));
        }
        if let crate::lower::model::Ex::XCast(y_p2i, t_p2j) = x_p0 {
            break 'm4730 Text::from(format!("{} as {}", &tight_f(&**y_p2i), &type_f(t_p2j)));
        }
        if let crate::lower::model::Ex::XTyped(y_p2k, _) = x_p0 {
            break 'm4730 expression_f(&**y_p2k);
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `Expression`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Expression: unbounded fn Ex -> Text
/// ```
pub struct Expression {
    pub x_p0: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for Expression {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let x_p0 = &self.x_p0;
        'm4730: {
            if let crate::lower::model::Ex::XVar(n_p1) = x_p0 {
                break 'm4730 prism_rtl::Turn::Finished(n_p1.clone());
            }
            if let crate::lower::model::Ex::XPath(p_p2) = x_p0 {
                break 'm4730 prism_rtl::Turn::Finished(p_p2.clone());
            }
            if let crate::lower::model::Ex::XSelf = x_p0 {
                break 'm4730 prism_rtl::Turn::Finished(Text::lit("self"));
            }
            if let crate::lower::model::Ex::XCx = x_p0 {
                break 'm4730 prism_rtl::Turn::Finished(Text::lit("cx"));
            }
            if let crate::lower::model::Ex::XConst(n_p3) = x_p0 {
                break 'm4730 prism_rtl::Turn::Finished(Text::from(format!("Self::{}", n_p3)));
            }
            if let crate::lower::model::Ex::XUnit = x_p0 {
                break 'm4730 prism_rtl::Turn::Finished(Text::lit("()"));
            }
            if let crate::lower::model::Ex::XNone = x_p0 {
                break 'm4730 prism_rtl::Turn::Finished(Text::lit("None"));
            }
            if let crate::lower::model::Ex::XBool(b_p4) = x_p0 {
                break 'm4730 if *b_p4 {
                    prism_rtl::Turn::Finished(Text::lit("true"))
                } else {
                    prism_rtl::Turn::Finished(Text::lit("false"))
                };
            }
            if let crate::lower::model::Ex::XNat(d_p5) = x_p0 {
                break 'm4730 if &crate::prelude::len_text(d_p5) <= &Nat::from(9u32) {
                    prism_rtl::Turn::Finished(Text::from(format!("Nat::from({}u32)", d_p5)))
                } else {
                    if &crate::prelude::len_text(d_p5) <= &Nat::from(18u32) {
                        prism_rtl::Turn::Finished(Text::from(format!("Nat::from_int(Int::from({}i64)).unwrap()", d_p5)))
                    } else {
                        prism_rtl::Turn::Finished(Text::from(format!("Nat::from_int(Int::parse(\"{}\").unwrap()).unwrap()", d_p5)))
                    }
                };
            }
            if let crate::lower::model::Ex::XInt(d_p6) = x_p0 {
                break 'm4730 if &crate::prelude::len_text(&(if crate::syntax::lexer::chars::has_prefix_f(d_p6, &Text::lit("-")) {
                    crate::syntax::lexer::chars::after_first_f(d_p6)
                } else {
                    d_p6.clone()
                })) <= &Nat::from(18u32) {
                    prism_rtl::Turn::Finished(Text::from(format!("Int::from({})", d_p6)))
                } else {
                    prism_rtl::Turn::Finished(Text::from(format!("Int::parse(\"{}\").unwrap()", d_p6)))
                };
            }
            if let crate::lower::model::Ex::XByte(d_p7) = x_p0 {
                break 'm4730 prism_rtl::Turn::Finished(Text::from(format!("{}u8", d_p7)));
            }
            if let crate::lower::model::Ex::XFloat(d_p8) = x_p0 {
                break 'm4730 prism_rtl::Turn::Finished(Text::from(format!("Float({})", d_p8)));
            }
            if let crate::lower::model::Ex::XIndex(n_p9) = x_p0 {
                break 'm4730 prism_rtl::Turn::Finished(Text::from(format!("{}", n_p9)));
            }
            if let crate::lower::model::Ex::XChar(c_pa) = x_p0 {
                break 'm4730 prism_rtl::Turn::Finished(Text::from(format!("\'{}\'", &crate::lower::expr::char_escape_f(c_pa))));
            }
            if let crate::lower::model::Ex::XStr(t_pb) = x_p0 {
                break 'm4730 prism_rtl::Turn::Finished(Text::from(format!("\"{}\"", &crate::lower::expr::escape_f(t_pb))));
            }
            if let crate::lower::model::Ex::XRegex(p_pc, f_pd) = x_p0 {
                break 'm4730 prism_rtl::Turn::Finished(Text::from(format!("{{ thread_local!(static R: Regex = Regex::lit(\"{}\", \"{}\")); R.with(Regex::clone) }}", &crate::lower::expr::escape_f(p_pc), &crate::lower::expr::escape_f(f_pd))));
            }
            if let crate::lower::model::Ex::XReplacement(p_pe, r_pf, f_pg) = x_p0 {
                break 'm4730 prism_rtl::Turn::Finished(Text::from(format!("{{ thread_local!(static R: RegexReplacement = RegexReplacement::lit(\"{}\", \"{}\", \"{}\")); R.with(RegexReplacement::clone) }}", &crate::lower::expr::escape_f(p_pe), &crate::lower::expr::escape_f(f_pg), &crate::lower::expr::escape_f(r_pf))));
            }
            if let crate::lower::model::Ex::XRef(y_ph) = x_p0 {
                break 'm4730 {
                    let y_phx = (**y_ph).clone();
                    crate::prelude::call_then(start_operand_f(y_phx.clone()), move |operand_f_5830: Text| prism_rtl::Turn::Finished(Text::from(format!("&{}", &operand_f_5830))))
                };
            }
            if let crate::lower::model::Ex::XRefMut(y_pi) = x_p0 {
                break 'm4730 {
                    let y_pix = (**y_pi).clone();
                    crate::prelude::call_then(start_operand_f(y_pix.clone()), move |operand_f_5864: Text| prism_rtl::Turn::Finished(Text::from(format!("&mut {}", &operand_f_5864))))
                };
            }
            if let crate::lower::model::Ex::XDeref(y_pj) = x_p0 {
                break 'm4730 {
                    let y_pjx = (**y_pj).clone();
                    crate::prelude::call_then(start_operand_f(y_pjx.clone()), move |operand_f_5893: Text| prism_rtl::Turn::Finished(Text::from(format!("*{}", &operand_f_5893))))
                };
            }
            if let crate::lower::model::Ex::XTarget(y_pk) = x_p0 {
                break 'm4730 {
                    let y_pkx = (**y_pk).clone();
                    crate::prelude::call_then(start_expression_f(y_pkx.clone()), move |expression_f_5924: Text| prism_rtl::Turn::Finished(Text::from(format!("(*{})", &expression_f_5924))))
                };
            }
            if let crate::lower::model::Ex::XClone(y_pl) = x_p0 {
                break 'm4730 {
                    let y_plx = (**y_pl).clone();
                    crate::prelude::call_then(start_tight_f(y_plx.clone()), move |tight_f_5956: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.clone()", &tight_f_5956))))
                };
            }
            if let crate::lower::model::Ex::XWeak(y_pm) = x_p0 {
                break 'm4730 {
                    let y_pmx = (**y_pm).clone();
                    crate::prelude::call_then(start_expression_f(y_pmx.clone()), move |expression_f_6003: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc::downgrade({})", &expression_f_6003))))
                };
            }
            if let crate::lower::model::Ex::XUpgrade(y_pn) = x_p0 {
                break 'm4730 {
                    let y_pnx = (**y_pn).clone();
                    crate::prelude::call_then(start_tight_f(y_pnx.clone()), move |tight_f_6037: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.upgrade()", &tight_f_6037))))
                };
            }
            if let crate::lower::model::Ex::XBreak(l_po, y_pp) = x_p0 {
                break 'm4730 {
                    let l_pox = l_po.clone();
                    let y_ppx = (**y_pp).clone();
                    crate::prelude::call_then(start_expression_f(y_ppx.clone()), move |expression_f_6092: Text| prism_rtl::Turn::Finished(Text::from(format!("break {} {}", &label_f(&l_pox), &expression_f_6092))))
                };
            }
            if let crate::lower::model::Ex::XBreakLoop = x_p0 {
                break 'm4730 prism_rtl::Turn::Finished(Text::lit("break"));
            }
            if let crate::lower::model::Ex::XLater(y_pq) = x_p0 {
                break 'm4730 {
                    let y_pqx = (**y_pq).clone();
                    crate::prelude::call_then(start_expression_f(y_pqx.clone()), move |expression_f_6169: Text| prism_rtl::Turn::Finished(Text::from(format!("Box::new(move |cx| {{ {}; Ok(()) }})", &expression_f_6169))))
                };
            }
            if let crate::lower::model::Ex::XFormatStr(parts_pr) = x_p0 {
                break 'm4730 prism_rtl::Turn::More(Rc::new(FormatStr { parts_p0: parts_pr.clone() }));
            }
            if let crate::lower::model::Ex::XIsCase(y_ps, m4730_28_1) = x_p0 && (m4730_28_1.len() == 0) {
                break 'm4730 prism_rtl::Turn::Finished(Text::lit("false"));
            }
            if let crate::lower::model::Ex::XIsCase(y_pt, cs_pu) = x_p0 {
                break 'm4730 {
                    let cs_pux = cs_pu.clone();
                    let y_ptx = (**y_pt).clone();
                    crate::prelude::call_then(start_expression_f(y_ptx.clone()), move |expression_f_6293: Text| prism_rtl::Turn::Finished(Text::from(format!("matches!({}, {})", &expression_f_6293, &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&cs_pux, &(|c_pv: &Text| Text::from(format!("{}(..)", c_pv)))), &Text::lit(" | "))))))
                };
            }
            if let crate::lower::model::Ex::XRefusal(what_p10) = x_p0 {
                break 'm4730 prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}{}\")", &crate::lower::expr::lowering_refusal_p(), &crate::lower::expr::escape_f(what_p10))));
            }
            if let crate::lower::model::Ex::XUnreachable = x_p0 {
                break 'm4730 prism_rtl::Turn::Finished(Text::lit("unreachable!()"));
            }
            if let crate::lower::model::Ex::XCall(f_p11, args_p12) = x_p0 {
                break 'm4730 {
                    let args_p12x = args_p12.clone();
                    let f_p11x = f_p11.clone();
                    crate::prelude::call_then(start_args_f(args_p12x.clone()), move |args_f_6482: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &f_p11x, &args_f_6482))))
                };
            }
            if let crate::lower::model::Ex::XApply(f_p13, args_p14) = x_p0 {
                break 'm4730 {
                    let args_p14x = args_p14.clone();
                    let f_p13x = (**f_p13).clone();
                    crate::prelude::call_then(start_tight_f(f_p13x.clone()), move |tight_f_6517: Text| crate::prelude::call_then(start_args_f(args_p14x.clone()), move |args_f_6527: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &tight_f_6517, &args_f_6527)))))
                };
            }
            if let crate::lower::model::Ex::XMethod(r_p15, m_p16, args_p17) = x_p0 {
                break 'm4730 {
                    let args_p17x = args_p17.clone();
                    let m_p16x = m_p16.clone();
                    let r_p15x = (**r_p15).clone();
                    crate::prelude::call_then(start_tight_f(r_p15x.clone()), move |tight_f_6566: Text| crate::prelude::call_then(start_args_f(args_p17x.clone()), move |args_f_6580: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.{}({})", &tight_f_6566, &m_p16x, &args_f_6580)))))
                };
            }
            if let crate::lower::model::Ex::XBin(op_p18, l_p19, r_p1a) = x_p0 {
                break 'm4730 {
                    let l_p19x = (**l_p19).clone();
                    let op_p18x = op_p18.clone();
                    let r_p1ax = (**r_p1a).clone();
                    crate::prelude::call_then(start_operand_f(l_p19x.clone()), move |operand_f_6614: Text| crate::prelude::call_then(start_operand_f(r_p1ax.clone()), move |operand_f_6641: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {} {}", &operand_f_6614, &crate::lower::model::bin_op_text_f(&op_p18x), &operand_f_6641)))))
                };
            }
            if let crate::lower::model::Ex::XUnary(op_p1b, y_p1c) = x_p0 {
                break 'm4730 {
                    let op_p1bx = op_p1b.clone();
                    let y_p1cx = (**y_p1c).clone();
                    crate::prelude::call_then(start_operand_f(y_p1cx.clone()), move |operand_f_6686: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &crate::lower::model::un_op_text_f(&op_p1bx), &operand_f_6686))))
                };
            }
            if let crate::lower::model::Ex::XCtor(p_p1d, args_p1e) = x_p0 {
                break 'm4730 {
                    let args_p1ex = args_p1e.clone();
                    let p_p1dx = p_p1d.clone();
                    crate::prelude::call_then(start_args_f(args_p1ex.clone()), move |args_f_6723: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &p_p1dx, &args_f_6723))))
                };
            }
            if let crate::lower::model::Ex::XRecord(p_p1f, fs_p1g) = x_p0 {
                break 'm4730 {
                    let fs_p1gx = fs_p1g.clone();
                    let p_p1fx = p_p1f.clone();
                    crate::prelude::call_value(crate::prelude::each_job(fs_p1gx.clone(), Rc::new(move |p0: (Text, crate::lower::model::Ex)| crate::prelude::entered(crate::prelude::once_job(move || {
                        let (f_p1h, v_p1i) = p0;
                        prism_rtl::Turn::More(Rc::new(FieldInit { f_p0: f_p1h.clone(), ex1: v_p1i.clone() }))
                    }))) as Rc<dyn Fn((Text, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_6770: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{} {{ {} }}", &p_p1fx, &crate::syntax::lexer::chars::join_f(&each_6770, &Text::lit(", "))))))
                };
            }
            if let crate::lower::model::Ex::XTuple(m4730_39_0) = x_p0 && (m4730_39_0.len() == 1) && let Some(one_p1j) = crate::prelude::index(m4730_39_0, &Nat::from(0u32)) {
                break 'm4730 crate::prelude::call_then(start_expression_f(one_p1j.clone()), move |expression_f_6841: Text| prism_rtl::Turn::Finished(Text::from(format!("({},)", &expression_f_6841))));
            }
            if let crate::lower::model::Ex::XTuple(xs_p1k) = x_p0 {
                break 'm4730 {
                    let xs_p1kx = xs_p1k.clone();
                    crate::prelude::call_then(start_args_f(xs_p1kx.clone()), move |args_f_6878: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &args_f_6878))))
                };
            }
            if let crate::lower::model::Ex::XVec(xs_p1l) = x_p0 {
                break 'm4730 {
                    let xs_p1lx = xs_p1l.clone();
                    crate::prelude::call_then(start_args_f(xs_p1lx.clone()), move |args_f_6909: Text| prism_rtl::Turn::Finished(Text::from(format!("vec![{}]", &args_f_6909))))
                };
            }
            if let crate::lower::model::Ex::XText(t_p1m) = x_p0 {
                break 'm4730 prism_rtl::Turn::Finished(Text::from(format!("Text::lit(\"{}\")", &crate::lower::expr::escape_f(t_p1m))));
            }
            if let crate::lower::model::Ex::XFormat(parts_p1n) = x_p0 {
                break 'm4730 prism_rtl::Turn::More(Rc::new(Format { parts_p0: parts_p1n.clone() }));
            }
            if let crate::lower::model::Ex::XMatch(s_p1o, arms_p1p, fallback_p1q, _) = x_p0 {
                break 'm4730 {
                    let arms_p1px = arms_p1p.clone();
                    let fallback_p1qx = *fallback_p1q;
                    let s_p1ox = (**s_p1o).clone();
                    crate::prelude::call_then(start_expression_f(s_p1ox.clone()), move |expression_f_7043: Text| crate::prelude::call_then(start_arms_f(arms_p1px.clone(), fallback_p1qx), move |arms_f_7059: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::match_block_f(&expression_f_7043, &arms_f_7059))))
                };
            }
            if let crate::lower::model::Ex::XChain(label_p1r, s_p1s, arms_p1t, _) = x_p0 {
                break 'm4730 prism_rtl::Turn::More(Rc::new(Chain { label_p0: label_f(label_p1r), s_p1: (**s_p1s).clone(), arms_p2: arms_p1t.clone() }));
            }
            if let crate::lower::model::Ex::XIf(c_p1u, t_p1v, e_p20) = x_p0 {
                break 'm4730 prism_rtl::Turn::More(Rc::new(IfExpression { c_p0: (**c_p1u).clone(), t_p1: (**t_p1v).clone(), e_p2: (**e_p20).clone() }));
            }
            if let crate::lower::model::Ex::XBlock(m4730_47_0, e_p21) = x_p0 && (m4730_47_0.len() == 0) {
                break 'm4730 prism_rtl::Turn::More(Rc::new(Expression { x_p0: (**e_p21).clone() }));
            }
            if let crate::lower::model::Ex::XBlock(dos_p22, e_p23) = x_p0 {
                break 'm4730 {
                    let dos_p22x = dos_p22.clone();
                    let e_p23x = (**e_p23).clone();
                    crate::prelude::call_then(start_statements_f(dos_p22x.clone()), move |statements_f_7241: Text| crate::prelude::call_then(start_expression_f(e_p23x.clone()), move |expression_f_7259: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::block_f(&statements_f_7241, &expression_f_7259))))
                };
            }
            if let crate::lower::model::Ex::XLabeled(label_p24, dos_p25, e_p26, _) = x_p0 {
                break 'm4730 {
                    let dos_p25x = dos_p25.clone();
                    let e_p26x = (**e_p26).clone();
                    let label_p24x = label_p24.clone();
                    crate::prelude::call_then(start_statements_f(dos_p25x.clone()), move |statements_f_7333: Text| crate::prelude::call_then(start_expression_f(e_p26x.clone()), move |expression_f_7351: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::labeled_f(&label_f(&label_p24x), &statements_f_7333, &expression_f_7351))))
                };
            }
            if let crate::lower::model::Ex::XClosure(mv_p27, ps_p28, body_p29) = x_p0 {
                break 'm4730 {
                    let body_p29x = (**body_p29).clone();
                    let mv_p27x = *mv_p27;
                    let ps_p28x = ps_p28.clone();
                    crate::prelude::call_value(crate::prelude::each_job(ps_p28x.clone(), Rc::new(move |p0: crate::lower::model::Pa| crate::prelude::entered(crate::prelude::once_job(move || {
                        let p_p2a = p0;
                        prism_rtl::Turn::More(Rc::new(Pattern_ { p_p0: p_p2a.clone() }))
                    }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_7426: Array<Text>| crate::prelude::call_then(start_expression_f(body_p29x.clone()), move |expression_f_7460: Text| prism_rtl::Turn::Finished(Text::from(format!("{}|{}| {}", &(if mv_p27x { Text::lit("move ") } else { Text::lit("") }), &crate::syntax::lexer::chars::join_f(&each_7426, &Text::lit(", ")), &expression_f_7460)))))
                };
            }
            if let crate::lower::model::Ex::XTry(y_p2b) = x_p0 {
                break 'm4730 {
                    let y_p2bx = (**y_p2b).clone();
                    crate::prelude::call_then(start_tight_f(y_p2bx.clone()), move |tight_f_7492: Text| prism_rtl::Turn::Finished(Text::from(format!("{}?", &tight_f_7492))))
                };
            }
            if let crate::lower::model::Ex::XField(r_p2c, f_p2d) = x_p0 {
                break 'm4730 {
                    let f_p2dx = f_p2d.clone();
                    let r_p2cx = (**r_p2c).clone();
                    crate::prelude::call_then(start_tight_f(r_p2cx.clone()), move |tight_f_7522: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.{}", &tight_f_7522, &f_p2dx))))
                };
            }
            if let crate::lower::model::Ex::XPart(r_p2e, k_p2f) = x_p0 {
                break 'm4730 {
                    let k_p2fx = k_p2f.clone();
                    let r_p2ex = (**r_p2e).clone();
                    crate::prelude::call_then(start_tight_f(r_p2ex.clone()), move |tight_f_7554: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.{}", &tight_f_7554, &k_p2fx))))
                };
            }
            if let crate::lower::model::Ex::XDecode(t_p2g, y_p2h) = x_p0 {
                break 'm4730 {
                    let t_p2gx = t_p2g.clone();
                    let y_p2hx = (**y_p2h).clone();
                    crate::prelude::call_then(start_decode_head_f(t_p2gx.clone()), move |decode_head_f_7588: Text| crate::prelude::call_then(start_expression_f(y_p2hx.clone()), move |expression_f_7613: Text| prism_rtl::Turn::Finished(Text::from(format!("{}::from_pod({})?", &decode_head_f_7588, &expression_f_7613)))))
                };
            }
            if let crate::lower::model::Ex::XCast(y_p2i, t_p2j) = x_p0 {
                break 'm4730 {
                    let t_p2jx = t_p2j.clone();
                    let y_p2ix = (**y_p2i).clone();
                    crate::prelude::call_then(start_tight_f(y_p2ix.clone()), move |tight_f_7648: Text| crate::prelude::call_then(start_type_f(t_p2jx.clone()), move |type_f_7661: Text| prism_rtl::Turn::Finished(Text::from(format!("{} as {}", &tight_f_7648, &type_f_7661)))))
                };
            }
            if let crate::lower::model::Ex::XTyped(y_p2k, _) = x_p0 {
                break 'm4730 prism_rtl::Turn::More(Rc::new(Expression { x_p0: (**y_p2k).clone() }));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start Expression, x`: what the function value is when passed to `@Run`.
pub fn start_expression_f(x_p0: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Expression { x_p0 })
}

/// ```prism
/// FieldInit: unbounded fn Text, Ex -> Text
/// ```
pub fn field_init_f(f_p0: &Text, ex1: &crate::lower::model::Ex) -> Text {
    match ex1 {
        crate::lower::model::Ex::XVar(v_p1) => if v_p1 == f_p0 { f_p0.clone() } else { Text::from(format!("{}: {}", f_p0, v_p1)) },
        v_p3 => Text::from(format!("{}: {}", f_p0, &expression_f(v_p3))),
    }
}

/// The step machine of `FieldInit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldInit: unbounded fn Text, Ex -> Text
/// ```
pub struct FieldInit {
    pub f_p0: Text,
    pub ex1: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for FieldInit {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f_p0 = &self.f_p0;
        let ex1 = &self.ex1;
        match ex1 {
            crate::lower::model::Ex::XVar(v_p1) => if v_p1 == f_p0 {
                prism_rtl::Turn::Finished(f_p0.clone())
            } else {
                prism_rtl::Turn::Finished(Text::from(format!("{}: {}", f_p0, v_p1)))
            },
            v_p3 => {
                let f_p0x = f_p0.clone();
                let v_p3x = v_p3.clone();
                crate::prelude::call_then(start_expression_f(v_p3x.clone()), move |expression_f_7831: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f_p0x, &expression_f_7831))))
            },
        }
    }
}

/// `Start FieldInit, x`: what the function value is when passed to `@Run`.
pub fn start_field_init_f(f_p0: Text, ex1: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FieldInit { f_p0, ex1 })
}

/// ```prism
/// DecodeHead: unbounded fn OutTy -> Text
/// ```
pub fn decode_head_f(t_p0: &crate::lower::model::OutTy) -> Text {
    match t_p0 {
        crate::lower::model::OutTy::OutNamed(n_p1, m7904_0_1) if (m7904_0_1.len() == 0) => n_p1.clone(),
        crate::lower::model::OutTy::OutNat => Text::lit("Nat"),
        crate::lower::model::OutTy::OutInt => Text::lit("Int"),
        crate::lower::model::OutTy::OutText => Text::lit("Text"),
        _ => Text::from(format!("<{}>", &type_f(t_p0))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `DecodeHead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DecodeHead: unbounded fn OutTy -> Text
/// ```
pub struct DecodeHead {
    pub t_p0: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Text> for DecodeHead {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::lower::model::OutTy::OutNamed(n_p1, m7904_0_1) if (m7904_0_1.len() == 0) => prism_rtl::Turn::Finished(n_p1.clone()),
            crate::lower::model::OutTy::OutNat => prism_rtl::Turn::Finished(Text::lit("Nat")),
            crate::lower::model::OutTy::OutInt => prism_rtl::Turn::Finished(Text::lit("Int")),
            crate::lower::model::OutTy::OutText => prism_rtl::Turn::Finished(Text::lit("Text")),
            _ => {
                let t_p0x = t_p0.clone();
                crate::prelude::call_then(start_type_f(t_p0x.clone()), move |type_f_8011: Text| prism_rtl::Turn::Finished(Text::from(format!("<{}>", &type_f_8011))))
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start DecodeHead, x`: what the function value is when passed to `@Run`.
pub fn start_decode_head_f(t_p0: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(DecodeHead { t_p0 })
}

/// ```prism
/// Label: fn Text -> Text
/// ```
pub fn label_f(l_p0: &Text) -> Text {
    if crate::syntax::lexer::chars::has_prefix_f(l_p0, &Text::lit("\'")) {
        l_p0.clone()
    } else {
        Text::from(format!("\'{}", l_p0))
    }
}

/// ```prism
/// Format: unbounded fn [Ex] -> Text
/// ```
pub fn format_f(parts_p0: &Array<crate::lower::model::Ex>) -> Text {
    let lit_p1 = crate::prelude::concat(&crate::prelude::each(parts_p0, &(|p_p3: &crate::lower::model::Ex| format_piece_f(p_p3))));
    let vals_p2 = crate::prelude::filter(parts_p0, &(|p_p4: &crate::lower::model::Ex| !is_text_f(p_p4)));
    if &crate::prelude::len(&vals_p2) == &Nat::from(0u32) {
        Text::from(format!("Text::lit(\"{}\")", &crate::lower::expr::escape_f(&crate::prelude::concat(&crate::prelude::each(parts_p0, &(|p_p5: &crate::lower::model::Ex| plain_piece_f(p_p5)))))))
    } else {
        Text::from(format!("Text::from(format!(\"{}\", {}))", &lit_p1, &args_f(&vals_p2)))
    }
}

/// The step machine of `Format`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Format: unbounded fn [Ex] -> Text
/// ```
pub struct Format {
    pub parts_p0: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for Format {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let parts_p0 = &self.parts_p0;
        let lit_p1 = crate::prelude::concat(&crate::prelude::each(parts_p0, &(|p_p3: &crate::lower::model::Ex| format_piece_f(p_p3))));
        let vals_p2 = crate::prelude::filter(parts_p0, &(|p_p4: &crate::lower::model::Ex| !is_text_f(p_p4)));
        if &crate::prelude::len(&vals_p2) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished(Text::from(format!("Text::lit(\"{}\")", &crate::lower::expr::escape_f(&crate::prelude::concat(&crate::prelude::each(parts_p0, &(|p_p5: &crate::lower::model::Ex| plain_piece_f(p_p5))))))))
        } else {
            crate::prelude::call_then(start_args_f(vals_p2.clone()), move |args_f_8526: Text| prism_rtl::Turn::Finished(Text::from(format!("Text::from(format!(\"{}\", {}))", &lit_p1, &args_f_8526))))
        }
    }
}

/// `Start Format, x`: what the function value is when passed to `@Run`.
pub fn start_format_f(parts_p0: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Format { parts_p0 })
}

/// ```prism
/// PlainPiece: fn Ex -> Text
/// ```
pub fn plain_piece_f(ex0: &crate::lower::model::Ex) -> Text {
    match ex0 {
        crate::lower::model::Ex::XText(t_p0) => t_p0.clone(),
        other_p1 => Text::lit(""),
    }
}

/// ```prism
/// FormatStr: unbounded fn [Ex] -> Text
/// ```
pub fn format_str_f(parts_p0: &Array<crate::lower::model::Ex>) -> Text {
    let lit_p1 = crate::prelude::concat(&crate::prelude::each(parts_p0, &(|p_p3: &crate::lower::model::Ex| str_piece_f(p_p3))));
    let vals_p2 = crate::prelude::filter(parts_p0, &(|p_p4: &crate::lower::model::Ex| !is_text_f(p_p4) && !is_var_f(p_p4)));
    if &crate::prelude::len(&vals_p2) == &Nat::from(0u32) {
        Text::from(format!("\"{}\"", &lit_p1))
    } else {
        Text::from(format!("format!(\"{}\", {})", &lit_p1, &args_f(&vals_p2)))
    }
}

/// The step machine of `FormatStr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FormatStr: unbounded fn [Ex] -> Text
/// ```
pub struct FormatStr {
    pub parts_p0: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Text> for FormatStr {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let parts_p0 = &self.parts_p0;
        let lit_p1 = crate::prelude::concat(&crate::prelude::each(parts_p0, &(|p_p3: &crate::lower::model::Ex| str_piece_f(p_p3))));
        let vals_p2 = crate::prelude::filter(parts_p0, &(|p_p4: &crate::lower::model::Ex| !is_text_f(p_p4) && !is_var_f(p_p4)));
        if &crate::prelude::len(&vals_p2) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished(Text::from(format!("\"{}\"", &lit_p1)))
        } else {
            crate::prelude::call_then(start_args_f(vals_p2.clone()), move |args_f_8991: Text| prism_rtl::Turn::Finished(Text::from(format!("format!(\"{}\", {})", &lit_p1, &args_f_8991))))
        }
    }
}

/// `Start FormatStr, x`: what the function value is when passed to `@Run`.
pub fn start_format_str_f(parts_p0: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FormatStr { parts_p0 })
}

/// ```prism
/// IsVar: fn Ex -> Bool
/// ```
pub fn is_var_f(ex0: &crate::lower::model::Ex) -> bool {
    match ex0 {
        crate::lower::model::Ex::XVar(_) => true,
        other_p0 => false,
    }
}

/// ```prism
/// StrPiece: fn Ex -> Text
/// ```
pub fn str_piece_f(ex0: &crate::lower::model::Ex) -> Text {
    match ex0 {
        crate::lower::model::Ex::XVar(n_p0) => Text::from(format!("{{{}}}", n_p0)),
        other_p1 => format_piece_f(other_p1),
    }
}

/// ```prism
/// IsText: fn Ex -> Bool
/// ```
pub fn is_text_f(ex0: &crate::lower::model::Ex) -> bool {
    match ex0 {
        crate::lower::model::Ex::XText(_) => true,
        other_p0 => false,
    }
}

/// ```prism
/// FormatPiece: fn Ex -> Text
/// ```
pub fn format_piece_f(ex0: &crate::lower::model::Ex) -> Text {
    match ex0 {
        crate::lower::model::Ex::XText(t_p0) => format_escape_f(&crate::lower::expr::escape_f(t_p0)),
        other_p1 => Text::lit("{}"),
    }
}

/// ```prism
/// FormatEscape: fn Text -> Text
/// ```
pub fn format_escape_f(t_p0: &Text) -> Text {
    crate::syntax::lexer::chars::map_chars_f(t_p0, &(Rc::new(move |p0: Text| crate::prelude::once_job(move || {
        let c_p1 = p0;
        prism_rtl::Turn::Finished(format_escape_char_f(&c_p1))
    })) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>))
}

/// ```prism
/// FormatEscapeChar: fn Text -> Text
/// ```
pub fn format_escape_char_f(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("{")) => Text::lit("{{"),
        c1_0 if (c1_0 == &Text::lit("}")) => Text::lit("}}"),
        c_p0 => c_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IfExpression: unbounded fn Ex, Ex, Ex -> Text
/// ```
pub fn if_expression_f(c_p0: &crate::lower::model::Ex, t_p1: &crate::lower::model::Ex, e_p2: &crate::lower::model::Ex) -> Text {
    let ct_p3 = expression_f(c_p0);
    let tt_p4 = expression_f(t_p1);
    let et_p5 = expression_f(e_p2);
    let short_p6 = !crate::syntax::lexer::chars::contains_f(&Text::from(format!("{}{}", &tt_p4, &et_p5)), &Text::lit("\n")) && (&crate::prelude::len_text(&Text::from(format!("{}{}{}", &ct_p3, &tt_p4, &et_p5))) < &Nat::from(70u32));
    if short_p6 {
        Text::from(format!("if {} {{ {} }} else {{ {} }}", &ct_p3, &tt_p4, &et_p5))
    } else {
        crate::emit::rust::templates::items::if_f(&ct_p3, &tt_p4, &et_p5)
    }
}

/// The step machine of `IfExpression`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IfExpression: unbounded fn Ex, Ex, Ex -> Text
/// ```
pub struct IfExpression {
    pub c_p0: crate::lower::model::Ex,
    pub t_p1: crate::lower::model::Ex,
    pub e_p2: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for IfExpression {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let c_p0 = &self.c_p0;
        let t_p1 = &self.t_p1;
        let e_p2 = &self.e_p2;
        let c_p0x = c_p0.clone();
        let e_p2x = e_p2.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(start_expression_f(c_p0x.clone()), move |expression_f_9729: Text| {
            let ct_p3 = expression_f_9729;
            crate::prelude::call_then(start_expression_f(t_p1x.clone()), move |expression_f_9755: Text| {
                let tt_p4 = expression_f_9755;
                crate::prelude::call_then(start_expression_f(e_p2x.clone()), move |expression_f_9781: Text| {
                    let et_p5 = expression_f_9781;
                    let short_p6 = !crate::syntax::lexer::chars::contains_f(&Text::from(format!("{}{}", &tt_p4, &et_p5)), &Text::lit("\n")) && (&crate::prelude::len_text(&Text::from(format!("{}{}{}", &ct_p3, &tt_p4, &et_p5))) < &Nat::from(70u32));
                    if short_p6 {
                        prism_rtl::Turn::Finished(Text::from(format!("if {} {{ {} }} else {{ {} }}", &ct_p3, &tt_p4, &et_p5)))
                    } else {
                        prism_rtl::Turn::Finished(crate::emit::rust::templates::items::if_f(&ct_p3, &tt_p4, &et_p5))
                    }
                })
            })
        })
    }
}

/// `Start IfExpression, x`: what the function value is when passed to `@Run`.
pub fn start_if_expression_f(c_p0: crate::lower::model::Ex, t_p1: crate::lower::model::Ex, e_p2: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(IfExpression { c_p0, t_p1, e_p2 })
}

/// ```prism
/// Arms: unbounded fn [XArm], Bool -> Text
/// ```
pub fn arms_f(arms_p0: &Array<crate::lower::model::XArm>, fallback_p1: &bool) -> Text {
    let lines_p2 = crate::prelude::run_to_end(crate::prelude::each_job(arms_p0.clone(), Rc::new(move |p0: crate::lower::model::XArm| crate::prelude::entered(crate::prelude::once_job(move || {
        let a_p4 = p0;
        prism_rtl::Turn::More(Rc::new(Arm { a_p0: a_p4.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>>>));
    let all_p3 = if *fallback_p1 {
        crate::prelude::push(&lines_p2, &Text::lit("_ => unreachable!(\"no arm matched\"),"))
    } else {
        lines_p2.clone()
    };
    crate::syntax::lexer::chars::join_f(&all_p3, &Text::lit("\n"))
}

/// The step machine of `Arms`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Arms: unbounded fn [XArm], Bool -> Text
/// ```
pub struct Arms {
    pub arms_p0: Array<crate::lower::model::XArm>,
    pub fallback_p1: bool,
}

impl prism_rtl::Job<Text> for Arms {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let arms_p0 = &self.arms_p0;
        let fallback_p1 = &self.fallback_p1;
        let arms_p0x = arms_p0.clone();
        let fallback_p1x = *fallback_p1;
        crate::prelude::call_value(crate::prelude::each_job(arms_p0x.clone(), Rc::new(move |p0: crate::lower::model::XArm| crate::prelude::entered(crate::prelude::once_job(move || {
            let a_p4 = p0;
            prism_rtl::Turn::More(Rc::new(Arm { a_p0: a_p4.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_10112: Array<Text>| {
            let lines_p2 = each_10112;
            let all_p3 = if fallback_p1x {
                crate::prelude::push(&lines_p2, &Text::lit("_ => unreachable!(\"no arm matched\"),"))
            } else {
                lines_p2.clone()
            };
            prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join_f(&all_p3, &Text::lit("\n")))
        })
    }
}

/// `Start Arms, x`: what the function value is when passed to `@Run`.
pub fn start_arms_f(arms_p0: Array<crate::lower::model::XArm>, fallback_p1: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Arms { arms_p0, fallback_p1 })
}

/// ```prism
/// Arm: unbounded fn XArm -> Text
/// ```
pub fn arm_f(a_p0: &crate::lower::model::XArm) -> Text {
    let guard_p1 = if &crate::prelude::len(&a_p0.conds_p) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" if {}", &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(a_p0.conds_p.clone(), Rc::new(move |p0: crate::lower::model::Cc| crate::prelude::entered(crate::prelude::once_job(move || {
            let c_p3 = p0;
            prism_rtl::Turn::More(Rc::new(Condition { cc0: c_p3.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(" && "))))
    };
    let body_p2 = expression_f(&a_p0.body_p);
    Text::from(format!("{}{} => {},", &pattern_f(&a_p0.pat_p), &guard_p1, &body_p2))
}

/// The step machine of `Arm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Arm: unbounded fn XArm -> Text
/// ```
pub struct Arm {
    pub a_p0: crate::lower::model::XArm,
}

impl prism_rtl::Job<Text> for Arm {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let a_p0 = &self.a_p0;
        let guard_p1 = if &crate::prelude::len(&a_p0.conds_p) == &Nat::from(0u32) {
            Text::lit("")
        } else {
            Text::from(format!(" if {}", &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(a_p0.conds_p.clone(), Rc::new(move |p0: crate::lower::model::Cc| crate::prelude::entered(crate::prelude::once_job(move || {
                let c_p3 = p0;
                prism_rtl::Turn::More(Rc::new(Condition { cc0: c_p3.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(" && "))))
        };
        let a_p0x = a_p0.clone();
        crate::prelude::call_then(start_expression_f(a_p0x.body_p.clone()), move |expression_f_10404: Text| {
            let body_p2 = expression_f_10404;
            crate::prelude::call_then(start_pattern_f(a_p0x.pat_p.clone()), move |pattern_f_10428: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{} => {},", &pattern_f_10428, &guard_p1, &body_p2))))
        })
    }
}

/// `Start Arm, x`: what the function value is when passed to `@Run`.
pub fn start_arm_f(a_p0: crate::lower::model::XArm) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Arm { a_p0 })
}

/// ```prism
/// Condition: unbounded fn Cc -> Text
/// ```
pub fn condition_f(cc0: &crate::lower::model::Cc) -> Text {
    match cc0 {
        crate::lower::model::Cc::CcIf(x_p0) => operand_f(x_p0),
        crate::lower::model::Cc::CcLet(p_p1, x_p2) => Text::from(format!("let {} = {}", &pattern_f(p_p1), &expression_f(x_p2))),
    }
}

/// The step machine of `Condition`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Condition: unbounded fn Cc -> Text
/// ```
pub struct Condition {
    pub cc0: crate::lower::model::Cc,
}

impl prism_rtl::Job<Text> for Condition {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cc0 = &self.cc0;
        match cc0 {
            crate::lower::model::Cc::CcIf(x_p0) => prism_rtl::Turn::More(Rc::new(Operand { x_p0: x_p0.clone() })),
            crate::lower::model::Cc::CcLet(p_p1, x_p2) => {
                let p_p1x = p_p1.clone();
                let x_p2x = x_p2.clone();
                crate::prelude::call_then(start_pattern_f(p_p1x.clone()), move |pattern_f_10566: Text| crate::prelude::call_then(start_expression_f(x_p2x.clone()), move |expression_f_10580: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {}", &pattern_f_10566, &expression_f_10580)))))
            },
        }
    }
}

/// `Start Condition, x`: what the function value is when passed to `@Run`.
pub fn start_condition_f(cc0: crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Condition { cc0 })
}

/// ```prism
/// Chain: unbounded fn Text, Ex, [XArm] -> Text
/// ```
pub fn chain_f(label_p0: &Text, s_p1: &crate::lower::model::Ex, arms_p2: &Array<crate::lower::model::XArm>) -> Text {
    let in_place_p3 = match s_p1 {
        crate::lower::model::Ex::XRef(y_p8) => is_bound_f(&**y_p8),
        _ => is_bound_f(s_p1),
    };
    let (bind_p9, scrut_pa) = if in_place_p3 {
        (Array::new(), expression_f(s_p1))
    } else {
        (Array::from(vec![Text::from(format!("let scrutinee = {};", &expression_f(s_p1)))]), Text::lit("scrutinee"))
    };
    let n_p4 = crate::prelude::len(arms_p2);
    let lines_p5 = crate::prelude::run_to_end(crate::prelude::each_job(crate::check::errors::range0_f(&n_p4), {
        let arms_p2x = arms_p2.clone();
        let scrut_pax = scrut_pa.clone();
        let label_p0x = label_p0.clone();
        Rc::new(move |p0: Nat| {
            let arms_p2xy = arms_p2x.clone();
            let scrut_paxy = scrut_pax.clone();
            let label_p0xy = label_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let i_pb = p0;
                {
                    let a_pc = crate::prelude::or(&crate::prelude::index(&arms_p2xy, &i_pb), &crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaWild, conds_p: Array::new(), body_p: crate::lower::model::Ex::XUnit });
                    let catch_all_pd = (&a_pc.pat_p == &crate::lower::model::Pa::PaWild) && (&crate::prelude::len(&a_pc.conds_p) == &Nat::from(0u32));
                    if catch_all_pd {
                        prism_rtl::Turn::More(Rc::new(Expression { x_p0: a_pc.body_p.clone() }))
                    } else {
                        crate::prelude::call_then(start_pattern_f(a_pc.pat_p.clone()), move |pattern_f_11293: Text| crate::prelude::call_value(crate::prelude::each_job(a_pc.conds_p.clone(), Rc::new(move |p0: crate::lower::model::Cc| crate::prelude::entered(crate::prelude::once_job(move || {
                            let c_pf = p0;
                            prism_rtl::Turn::More(Rc::new(Condition { cc0: c_pf.clone() }))
                        }))) as Rc<dyn Fn(crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_11323: Array<Text>| {
                            let head_pe = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&Array::from(vec![Text::from(format!("let {} = {}", &pattern_f_11293, &scrut_paxy))]), &each_11323), &Text::lit(" && "));
                            crate::prelude::call_then(start_expression_f(a_pc.body_p.clone()), move |expression_f_11410: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::chain_arm_f(&head_pe, &label_p0xy, &continued_f(&expression_f_11410, &Text::lit("    ")))))
                        }))
                    }
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let ends_p6 = match crate::syntax::lexer::chars::last_o(arms_p2) {
        Some(a_pg) => (&a_pg.pat_p == &crate::lower::model::Pa::PaWild) && (&crate::prelude::len(&a_pg.conds_p) == &Nat::from(0u32)),
        None => false,
    };
    let tail_p7 = if ends_p6 {
        Array::new()
    } else {
        Array::from(vec![Text::lit("unreachable!(\"no clause matched\")")])
    };
    Text::from(format!("{}: {{\n{}\n}}", label_p0, &indent_f(&crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::append(&bind_p9, &lines_p5), &tail_p7), &Text::lit("\n")))))
}

/// The step machine of `Chain`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Chain: unbounded fn Text, Ex, [XArm] -> Text
/// ```
pub struct Chain {
    pub label_p0: Text,
    pub s_p1: crate::lower::model::Ex,
    pub arms_p2: Array<crate::lower::model::XArm>,
}

impl prism_rtl::Job<Text> for Chain {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let label_p0 = &self.label_p0;
        let s_p1 = &self.s_p1;
        let arms_p2 = &self.arms_p2;
        let in_place_p3 = match s_p1 {
            crate::lower::model::Ex::XRef(y_p8) => is_bound_f(&**y_p8),
            _ => is_bound_f(s_p1),
        };
        let (bind_p9, scrut_pa) = if in_place_p3 {
            (Array::new(), expression_f(s_p1))
        } else {
            (Array::from(vec![Text::from(format!("let scrutinee = {};", &expression_f(s_p1)))]), Text::lit("scrutinee"))
        };
        let n_p4 = crate::prelude::len(arms_p2);
        let arms_p2x = arms_p2.clone();
        let label_p0x = label_p0.clone();
        let s_p1x = s_p1.clone();
        crate::prelude::call_value(crate::prelude::each_job(crate::check::errors::range0_f(&n_p4), {
            let arms_p2xx = arms_p2x.clone();
            let scrut_pax = scrut_pa.clone();
            let label_p0xx = label_p0x.clone();
            Rc::new(move |p0: Nat| {
                let arms_p2xxy = arms_p2xx.clone();
                let scrut_paxy = scrut_pax.clone();
                let label_p0xxy = label_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let i_pb = p0;
                    {
                        let a_pc = crate::prelude::or(&crate::prelude::index(&arms_p2xxy, &i_pb), &crate::lower::model::XArm { pat_p: crate::lower::model::Pa::PaWild, conds_p: Array::new(), body_p: crate::lower::model::Ex::XUnit });
                        let catch_all_pd = (&a_pc.pat_p == &crate::lower::model::Pa::PaWild) && (&crate::prelude::len(&a_pc.conds_p) == &Nat::from(0u32));
                        if catch_all_pd {
                            prism_rtl::Turn::More(Rc::new(Expression { x_p0: a_pc.body_p.clone() }))
                        } else {
                            crate::prelude::call_then(start_pattern_f(a_pc.pat_p.clone()), move |pattern_f_11293: Text| crate::prelude::call_value(crate::prelude::each_job(a_pc.conds_p.clone(), Rc::new(move |p0: crate::lower::model::Cc| crate::prelude::entered(crate::prelude::once_job(move || {
                                let c_pf = p0;
                                prism_rtl::Turn::More(Rc::new(Condition { cc0: c_pf.clone() }))
                            }))) as Rc<dyn Fn(crate::lower::model::Cc) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_11323: Array<Text>| {
                                let head_pe = crate::syntax::lexer::chars::join_f(&crate::prelude::append(&Array::from(vec![Text::from(format!("let {} = {}", &pattern_f_11293, &scrut_paxy))]), &each_11323), &Text::lit(" && "));
                                crate::prelude::call_then(start_expression_f(a_pc.body_p.clone()), move |expression_f_11410: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::chain_arm_f(&head_pe, &label_p0xxy, &continued_f(&expression_f_11410, &Text::lit("    ")))))
                            }))
                        }
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_11039: Array<Text>| {
            let lines_p5 = each_11039;
            let ends_p6 = match crate::syntax::lexer::chars::last_o(&arms_p2x) {
                Some(a_pg) => (&a_pg.pat_p == &crate::lower::model::Pa::PaWild) && (&crate::prelude::len(&a_pg.conds_p) == &Nat::from(0u32)),
                None => false,
            };
            let tail_p7 = if ends_p6 {
                Array::new()
            } else {
                Array::from(vec![Text::lit("unreachable!(\"no clause matched\")")])
            };
            prism_rtl::Turn::Finished(Text::from(format!("{}: {{\n{}\n}}", &label_p0x, &indent_f(&crate::syntax::lexer::chars::join_f(&crate::prelude::append(&crate::prelude::append(&bind_p9, &lines_p5), &tail_p7), &Text::lit("\n"))))))
        })
    }
}

/// `Start Chain, x`: what the function value is when passed to `@Run`.
pub fn start_chain_f(label_p0: Text, s_p1: crate::lower::model::Ex, arms_p2: Array<crate::lower::model::XArm>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Chain { label_p0, s_p1, arms_p2 })
}

/// ```prism
/// IsBound: fn Ex -> Bool
/// ```
pub fn is_bound_f(x_p0: &crate::lower::model::Ex) -> bool {
    'm11914: {
        if let crate::lower::model::Ex::XVar(_) = x_p0 {
            break 'm11914 true;
        }
        if let crate::lower::model::Ex::XField(m11914_1_0, _) = x_p0 && let crate::lower::model::Ex::XSelf = &**m11914_1_0 {
            break 'm11914 true;
        }
        if let crate::lower::model::Ex::XField(m11914_2_0, _) = x_p0 && let crate::lower::model::Ex::XMethod(m11914_2_0_r_0, _, _) = &**m11914_2_0 && let crate::lower::model::Ex::XUpgrade(_) = &**m11914_2_0_r_0 {
            break 'm11914 true;
        }
        if let crate::lower::model::Ex::XTarget(_) = x_p0 {
            break 'm11914 true;
        }
        if let crate::lower::model::Ex::XPart(m11914_4_0, _) = x_p0 && let crate::lower::model::Ex::XVar(_) = &**m11914_4_0 {
            break 'm11914 true;
        }
        false
    }
}

/// ```prism
/// Continued: fn Text, Text -> Text
/// ```
pub fn continued_f(t_p0: &Text, pad_p1: &Text) -> Text {
    let ls_p2 = crate::prelude::split_on(t_p0, &Text::lit("\n"));
    crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&ls_p2)), &(|i_p3: &Nat| if (i_p3 == &Nat::from(0u32)) || (&crate::prelude::or(&crate::prelude::index(&ls_p2, i_p3), &Text::lit("")) == &Text::lit("")) {
        crate::prelude::or(&crate::prelude::index(&ls_p2, i_p3), &Text::lit(""))
    } else {
        Text::from(format!("{}{}", pad_p1, &crate::prelude::or(&crate::prelude::index(&ls_p2, i_p3), &Text::lit(""))))
    })), &Text::lit("\n"))
}

/// ```prism
/// BodyLines: unbounded fn Ex -> Text
/// ```
pub fn body_lines_f(ex0: &crate::lower::model::Ex) -> Text {
    match ex0 {
        crate::lower::model::Ex::XBlock(dos_p0, e_p1) => if &crate::prelude::len(dos_p0) == &Nat::from(0u32) {
            body_lines_f(&**e_p1)
        } else {
            Text::from(format!("{}\n{}", &statements_f(dos_p0), &body_lines_f(&**e_p1)))
        },
        x_p2 => expression_f(x_p2),
    }
}

/// The step machine of `BodyLines`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BodyLines: unbounded fn Ex -> Text
/// ```
pub struct BodyLines {
    pub ex0: crate::lower::model::Ex,
}

impl prism_rtl::Job<Text> for BodyLines {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let ex0 = &self.ex0;
        match ex0 {
            crate::lower::model::Ex::XBlock(dos_p0, e_p1) => if &crate::prelude::len(dos_p0) == &Nat::from(0u32) {
                prism_rtl::Turn::More(Rc::new(BodyLines { ex0: (**e_p1).clone() }))
            } else {
                {
                    let dos_p0x = dos_p0.clone();
                    let e_p1x = (**e_p1).clone();
                    crate::prelude::call_then(start_statements_f(dos_p0x.clone()), move |statements_f_12600: Text| crate::prelude::call_then(start_body_lines_f(e_p1x.clone()), move |body_lines_f_12618: Text| prism_rtl::Turn::Finished(Text::from(format!("{}\n{}", &statements_f_12600, &body_lines_f_12618)))))
                }
            },
            x_p2 => prism_rtl::Turn::More(Rc::new(Expression { x_p0: x_p2.clone() })),
        }
    }
}

/// `Start BodyLines, x`: what the function value is when passed to `@Run`.
pub fn start_body_lines_f(ex0: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(BodyLines { ex0 })
}

/// ```prism
/// Indent: fn Text -> Text
/// ```
pub fn indent_f(t_p0: &Text) -> Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::prelude::split_on(t_p0, &Text::lit("\n")), &(|l_p1: &Text| if l_p1 == &Text::lit("") {
        Text::lit("")
    } else {
        Text::from(format!("    {}", l_p1))
    })), &Text::lit("\n"))
}

/// ```prism
/// Pattern: unbounded fn Pa -> Text
/// ```
pub fn pattern_f(p_p0: &crate::lower::model::Pa) -> Text {
    'm13069: {
        if let crate::lower::model::Pa::PaWild = p_p0 {
            break 'm13069 Text::lit("_");
        }
        if let crate::lower::model::Pa::PaBind(n_p1) = p_p0 {
            break 'm13069 n_p1.clone();
        }
        if let crate::lower::model::Pa::PaMut(n_p2) = p_p0 {
            break 'm13069 Text::from(format!("mut {}", n_p2));
        }
        if let crate::lower::model::Pa::PaCtor(c_p3, ps_p4) = p_p0 {
            break 'm13069 Text::from(format!("{}({})", c_p3, &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(ps_p4.clone(), Rc::new(move |p0: crate::lower::model::Pa| crate::prelude::entered(crate::prelude::once_job(move || {
                let q_p5 = p0;
                prism_rtl::Turn::More(Rc::new(Pattern_ { p_p0: q_p5.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))));
        }
        if let crate::lower::model::Pa::PaUnit(c_p6) = p_p0 {
            break 'm13069 c_p6.clone();
        }
        if let crate::lower::model::Pa::PaRecord(c_p7, fs_p8, rest_p9) = p_p0 {
            break 'm13069 {
                let parts_pa = crate::prelude::run_to_end(crate::prelude::each_job(fs_p8.clone(), Rc::new(move |p0: (Text, crate::lower::model::Pa)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let (f_pc, q_pd) = p0;
                    match &q_pd {
                        crate::lower::model::Pa::PaBind(n_pe) => if n_pe == &f_pc {
                            prism_rtl::Turn::Finished(f_pc.clone())
                        } else {
                            prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f_pc, n_pe)))
                        },
                        _ => crate::prelude::call_then(start_pattern_f(q_pd.clone()), move |pattern_f_13371: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f_pc, &pattern_f_13371)))),
                    }
                }))) as Rc<dyn Fn((Text, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Text>>>));
                let all_pb = if *rest_p9 {
                    crate::prelude::push(&parts_pa, &Text::lit(".."))
                } else {
                    parts_pa.clone()
                };
                Text::from(format!("{} {{ {} }}", c_p7, &crate::syntax::lexer::chars::join_f(&all_pb, &Text::lit(", "))))
            };
        }
        if let crate::lower::model::Pa::PaTuple(m13069_6_0) = p_p0 && (m13069_6_0.len() == 1) && let Some(one_pf) = crate::prelude::index(m13069_6_0, &Nat::from(0u32)) {
            break 'm13069 Text::from(format!("({},)", &pattern_f(&one_pf)));
        }
        if let crate::lower::model::Pa::PaTuple(ps_pg) = p_p0 {
            break 'm13069 Text::from(format!("({})", &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(ps_pg.clone(), Rc::new(move |p0: crate::lower::model::Pa| crate::prelude::entered(crate::prelude::once_job(move || {
                let q_ph = p0;
                prism_rtl::Turn::More(Rc::new(Pattern_ { p_p0: q_ph.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))));
        }
        if let crate::lower::model::Pa::PaChar(c_pi) = p_p0 {
            break 'm13069 Text::from(format!("\'{}\'", &crate::lower::expr::char_escape_f(c_pi)));
        }
        if let crate::lower::model::Pa::PaBool(b_pj) = p_p0 {
            break 'm13069 if *b_pj { Text::lit("true") } else { Text::lit("false") };
        }
        if let crate::lower::model::Pa::PaIndex(n_pk) = p_p0 {
            break 'm13069 Text::from(format!("{}", n_pk));
        }
        if let crate::lower::model::Pa::PaConst(n_pl) = p_p0 {
            break 'm13069 Text::from(format!("Self::{}", n_pl));
        }
        if let crate::lower::model::Pa::PaSlice(ps_pm) = p_p0 {
            break 'm13069 Text::from(format!("[{}]", &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(ps_pm.clone(), Rc::new(move |p0: crate::lower::model::Pa| crate::prelude::entered(crate::prelude::once_job(move || {
                let q_pn = p0;
                prism_rtl::Turn::More(Rc::new(Pattern_ { p_p0: q_pn.clone() }))
            }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))));
        }
        if let crate::lower::model::Pa::PaRest(m13069_13_0) = p_p0 && (m13069_13_0 == &Text::lit("")) {
            break 'm13069 Text::lit("..");
        }
        if let crate::lower::model::Pa::PaRest(n_po) = p_p0 {
            break 'm13069 Text::from(format!("{} @ ..", n_po));
        }
        if let crate::lower::model::Pa::PaTyped(q_pp, t_pq) = p_p0 {
            break 'm13069 Text::from(format!("{}: {}", &pattern_f(&**q_pp), &type_f(t_pq)));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `Pattern_`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Pattern: unbounded fn Pa -> Text
/// ```
pub struct Pattern_ {
    pub p_p0: crate::lower::model::Pa,
}

impl prism_rtl::Job<Text> for Pattern_ {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let p_p0 = &self.p_p0;
        'm13069: {
            if let crate::lower::model::Pa::PaWild = p_p0 {
                break 'm13069 prism_rtl::Turn::Finished(Text::lit("_"));
            }
            if let crate::lower::model::Pa::PaBind(n_p1) = p_p0 {
                break 'm13069 prism_rtl::Turn::Finished(n_p1.clone());
            }
            if let crate::lower::model::Pa::PaMut(n_p2) = p_p0 {
                break 'm13069 prism_rtl::Turn::Finished(Text::from(format!("mut {}", n_p2)));
            }
            if let crate::lower::model::Pa::PaCtor(c_p3, ps_p4) = p_p0 {
                break 'm13069 {
                    let c_p3x = c_p3.clone();
                    let ps_p4x = ps_p4.clone();
                    crate::prelude::call_value(crate::prelude::each_job(ps_p4x.clone(), Rc::new(move |p0: crate::lower::model::Pa| crate::prelude::entered(crate::prelude::once_job(move || {
                        let q_p5 = p0;
                        prism_rtl::Turn::More(Rc::new(Pattern_ { p_p0: q_p5.clone() }))
                    }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_13163: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &c_p3x, &crate::syntax::lexer::chars::join_f(&each_13163, &Text::lit(", "))))))
                };
            }
            if let crate::lower::model::Pa::PaUnit(c_p6) = p_p0 {
                break 'm13069 prism_rtl::Turn::Finished(c_p6.clone());
            }
            if let crate::lower::model::Pa::PaRecord(c_p7, fs_p8, rest_p9) = p_p0 {
                break 'm13069 {
                    let c_p7x = c_p7.clone();
                    let fs_p8x = fs_p8.clone();
                    let rest_p9x = *rest_p9;
                    crate::prelude::call_value(crate::prelude::each_job(fs_p8x.clone(), Rc::new(move |p0: (Text, crate::lower::model::Pa)| crate::prelude::entered(crate::prelude::once_job(move || {
                        let (f_pc, q_pd) = p0;
                        match &q_pd {
                            crate::lower::model::Pa::PaBind(n_pe) => if n_pe == &f_pc {
                                prism_rtl::Turn::Finished(f_pc.clone())
                            } else {
                                prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f_pc, n_pe)))
                            },
                            _ => crate::prelude::call_then(start_pattern_f(q_pd.clone()), move |pattern_f_13371: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f_pc, &pattern_f_13371)))),
                        }
                    }))) as Rc<dyn Fn((Text, crate::lower::model::Pa)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_13259: Array<Text>| {
                        let parts_pa = each_13259;
                        let all_pb = if rest_p9x {
                            crate::prelude::push(&parts_pa, &Text::lit(".."))
                        } else {
                            parts_pa.clone()
                        };
                        prism_rtl::Turn::Finished(Text::from(format!("{} {{ {} }}", &c_p7x, &crate::syntax::lexer::chars::join_f(&all_pb, &Text::lit(", ")))))
                    })
                };
            }
            if let crate::lower::model::Pa::PaTuple(m13069_6_0) = p_p0 && (m13069_6_0.len() == 1) && let Some(one_pf) = crate::prelude::index(m13069_6_0, &Nat::from(0u32)) {
                break 'm13069 crate::prelude::call_then(start_pattern_f(one_pf.clone()), move |pattern_f_13500: Text| prism_rtl::Turn::Finished(Text::from(format!("({},)", &pattern_f_13500))));
            }
            if let crate::lower::model::Pa::PaTuple(ps_pg) = p_p0 {
                break 'm13069 {
                    let ps_pgx = ps_pg.clone();
                    crate::prelude::call_value(crate::prelude::each_job(ps_pgx.clone(), Rc::new(move |p0: crate::lower::model::Pa| crate::prelude::entered(crate::prelude::once_job(move || {
                        let q_ph = p0;
                        prism_rtl::Turn::More(Rc::new(Pattern_ { p_p0: q_ph.clone() }))
                    }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_13541: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("({})", &crate::syntax::lexer::chars::join_f(&each_13541, &Text::lit(", "))))))
                };
            }
            if let crate::lower::model::Pa::PaChar(c_pi) = p_p0 {
                break 'm13069 prism_rtl::Turn::Finished(Text::from(format!("\'{}\'", &crate::lower::expr::char_escape_f(c_pi))));
            }
            if let crate::lower::model::Pa::PaBool(b_pj) = p_p0 {
                break 'm13069 if *b_pj {
                    prism_rtl::Turn::Finished(Text::lit("true"))
                } else {
                    prism_rtl::Turn::Finished(Text::lit("false"))
                };
            }
            if let crate::lower::model::Pa::PaIndex(n_pk) = p_p0 {
                break 'm13069 prism_rtl::Turn::Finished(Text::from(format!("{}", n_pk)));
            }
            if let crate::lower::model::Pa::PaConst(n_pl) = p_p0 {
                break 'm13069 prism_rtl::Turn::Finished(Text::from(format!("Self::{}", n_pl)));
            }
            if let crate::lower::model::Pa::PaSlice(ps_pm) = p_p0 {
                break 'm13069 {
                    let ps_pmx = ps_pm.clone();
                    crate::prelude::call_value(crate::prelude::each_job(ps_pmx.clone(), Rc::new(move |p0: crate::lower::model::Pa| crate::prelude::entered(crate::prelude::once_job(move || {
                        let q_pn = p0;
                        prism_rtl::Turn::More(Rc::new(Pattern_ { p_p0: q_pn.clone() }))
                    }))) as Rc<dyn Fn(crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_13722: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("[{}]", &crate::syntax::lexer::chars::join_f(&each_13722, &Text::lit(", "))))))
                };
            }
            if let crate::lower::model::Pa::PaRest(m13069_13_0) = p_p0 && (m13069_13_0 == &Text::lit("")) {
                break 'm13069 prism_rtl::Turn::Finished(Text::lit(".."));
            }
            if let crate::lower::model::Pa::PaRest(n_po) = p_p0 {
                break 'm13069 prism_rtl::Turn::Finished(Text::from(format!("{} @ ..", n_po)));
            }
            if let crate::lower::model::Pa::PaTyped(q_pp, t_pq) = p_p0 {
                break 'm13069 {
                    let q_ppx = (**q_pp).clone();
                    let t_pqx = t_pq.clone();
                    crate::prelude::call_then(start_pattern_f(q_ppx.clone()), move |pattern_f_13821: Text| crate::prelude::call_then(start_type_f(t_pqx.clone()), move |type_f_13834: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &pattern_f_13821, &type_f_13834)))))
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start Pattern_, x`: what the function value is when passed to `@Run`.
pub fn start_pattern_f(p_p0: crate::lower::model::Pa) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Pattern_ { p_p0 })
}

/// ```prism
/// Statements: unbounded fn [Do] -> Text
/// ```
pub fn statements_f(dos_p0: &Array<crate::lower::model::Do>) -> Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(dos_p0.clone(), Rc::new(move |p0: crate::lower::model::Do| crate::prelude::entered(crate::prelude::once_job(move || {
        let d_p1 = p0;
        prism_rtl::Turn::More(Rc::new(Statement { d_p0: d_p1.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))
}

/// The step machine of `Statements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Statements: unbounded fn [Do] -> Text
/// ```
pub struct Statements {
    pub dos_p0: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for Statements {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let dos_p0 = &self.dos_p0;
        let dos_p0x = dos_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(dos_p0x.clone(), Rc::new(move |p0: crate::lower::model::Do| crate::prelude::entered(crate::prelude::once_job(move || {
            let d_p1 = p0;
            prism_rtl::Turn::More(Rc::new(Statement { d_p0: d_p1.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_13908: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join_f(&each_13908, &Text::lit("\n"))))
    }
}

/// `Start Statements, x`: what the function value is when passed to `@Run`.
pub fn start_statements_f(dos_p0: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Statements { dos_p0 })
}

/// ```prism
/// Statement: unbounded fn Do -> Text
/// ```
pub fn statement_f(d_p0: &crate::lower::model::Do) -> Text {
    match d_p0 {
        crate::lower::model::Do::DoLet(p_p1, x_p2) => Text::from(format!("let {} = {};", &pattern_f(p_p1), &expression_f(x_p2))),
        crate::lower::model::Do::DoLetElse(p_p3, x_p4, e_p5) => Text::from(format!("let {} = {} else {{ {} }};", &pattern_f(p_p3), &expression_f(x_p4), &expression_f(e_p5))),
        crate::lower::model::Do::DoAssign(p_p6, x_p7) => Text::from(format!("{} = {};", &expression_f(p_p6), &expression_f(x_p7))),
        crate::lower::model::Do::DoWhile(c_p8, body_p9) => crate::emit::rust::templates::items::if_stmt_f(&Text::from(format!("while {}", &expression_f(c_p8))), &statements_f(body_p9)),
        crate::lower::model::Do::DoWhileLet(p_pa, x_pb, body_pc) => crate::emit::rust::templates::items::if_stmt_f(&Text::from(format!("while let {} = {}", &pattern_f(p_pa), &expression_f(x_pb))), &statements_f(body_pc)),
        crate::lower::model::Do::DoFor(p_pd, x_pe, body_pf) => crate::emit::rust::templates::items::if_stmt_f(&Text::from(format!("for {} in {}", &pattern_f(p_pd), &expression_f(x_pe))), &statements_f(body_pf)),
        crate::lower::model::Do::DoExpr(x_pg) => Text::from(format!("{};", &expression_f(x_pg))),
        crate::lower::model::Do::DoIf(c_ph, t_pi, e_pj) => Text::from(format!("{}{}", &crate::emit::rust::templates::items::if_stmt_f(&Text::from(format!("if {}", &expression_f(c_ph))), &statements_f(t_pi)), &else_branch_f(e_pj))),
        crate::lower::model::Do::DoIfLet(p_pk, x_pl, t_pm, e_pn) => Text::from(format!("{}{}", &crate::emit::rust::templates::items::if_stmt_f(&Text::from(format!("if let {} = {}", &pattern_f(p_pk), &expression_f(x_pl))), &statements_f(t_pm)), &else_branch_f(e_pn))),
        crate::lower::model::Do::DoMatch(x_po, cases_pp) => crate::emit::rust::templates::items::match_block_f(&expression_f(x_po), &crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(cases_pp.clone(), Rc::new(move |p0: (crate::lower::model::Pa, Array<crate::lower::model::Do>)| crate::prelude::entered(crate::prelude::once_job(move || {
            let (p_pq, body_pr) = p0;
            crate::prelude::call_then(start_pattern_f(p_pq.clone()), move |pattern_f_14750: Text| crate::prelude::call_then(start_statements_f(body_pr.clone()), move |statements_f_14763: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::arm_block_f(&pattern_f_14750, &statements_f_14763))))
        }))) as Rc<dyn Fn((crate::lower::model::Pa, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))),
        crate::lower::model::Do::DoReturn(x_ps) => Text::from(format!("return {};", &expression_f(x_ps))),
        crate::lower::model::Do::DoBlock(body_pt) => crate::emit::rust::templates::items::scope_f(&statements_f(body_pt)),
        crate::lower::model::Do::DoScope(body_pu) => Text::from(format!("{{ {} }};", &inline_statements_f(body_pu))),
        crate::lower::model::Do::DoLine(body_pv) => Text::from(format!("{};", &inline_statements_f(body_pv))),
        crate::lower::model::Do::DoNote(t_p10) => Text::from(format!("// {}", t_p10)),
    }
}

/// The step machine of `Statement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Statement: unbounded fn Do -> Text
/// ```
pub struct Statement {
    pub d_p0: crate::lower::model::Do,
}

impl prism_rtl::Job<Text> for Statement {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let d_p0 = &self.d_p0;
        match d_p0 {
            crate::lower::model::Do::DoLet(p_p1, x_p2) => {
                let p_p1x = p_p1.clone();
                let x_p2x = x_p2.clone();
                crate::prelude::call_then(start_pattern_f(p_p1x.clone()), move |pattern_f_14026: Text| crate::prelude::call_then(start_expression_f(x_p2x.clone()), move |expression_f_14040: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {};", &pattern_f_14026, &expression_f_14040)))))
            },
            crate::lower::model::Do::DoLetElse(p_p3, x_p4, e_p5) => {
                let e_p5x = e_p5.clone();
                let p_p3x = p_p3.clone();
                let x_p4x = x_p4.clone();
                crate::prelude::call_then(start_pattern_f(p_p3x.clone()), move |pattern_f_14085: Text| crate::prelude::call_then(start_expression_f(x_p4x.clone()), move |expression_f_14099: Text| crate::prelude::call_then(start_expression_f(e_p5x.clone()), move |expression_f_14122: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {} else {{ {} }};", &pattern_f_14085, &expression_f_14099, &expression_f_14122))))))
            },
            crate::lower::model::Do::DoAssign(p_p6, x_p7) => {
                let p_p6x = p_p6.clone();
                let x_p7x = x_p7.clone();
                crate::prelude::call_then(start_expression_f(p_p6x.clone()), move |expression_f_14162: Text| crate::prelude::call_then(start_expression_f(x_p7x.clone()), move |expression_f_14179: Text| prism_rtl::Turn::Finished(Text::from(format!("{} = {};", &expression_f_14162, &expression_f_14179)))))
            },
            crate::lower::model::Do::DoWhile(c_p8, body_p9) => {
                let body_p9x = body_p9.clone();
                let c_p8x = c_p8.clone();
                crate::prelude::call_then(start_expression_f(c_p8x.clone()), move |expression_f_14231: Text| crate::prelude::call_then(start_statements_f(body_p9x.clone()), move |statements_f_14248: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::if_stmt_f(&Text::from(format!("while {}", &expression_f_14231)), &statements_f_14248))))
            },
            crate::lower::model::Do::DoWhileLet(p_pa, x_pb, body_pc) => {
                let body_pcx = body_pc.clone();
                let p_pax = p_pa.clone();
                let x_pbx = x_pb.clone();
                crate::prelude::call_then(start_pattern_f(p_pax.clone()), move |pattern_f_14311: Text| crate::prelude::call_then(start_expression_f(x_pbx.clone()), move |expression_f_14325: Text| crate::prelude::call_then(start_statements_f(body_pcx.clone()), move |statements_f_14342: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::if_stmt_f(&Text::from(format!("while let {} = {}", &pattern_f_14311, &expression_f_14325)), &statements_f_14342)))))
            },
            crate::lower::model::Do::DoFor(p_pd, x_pe, body_pf) => {
                let body_pfx = body_pf.clone();
                let p_pdx = p_pd.clone();
                let x_pex = x_pe.clone();
                crate::prelude::call_then(start_pattern_f(p_pdx.clone()), move |pattern_f_14394: Text| crate::prelude::call_then(start_expression_f(x_pex.clone()), move |expression_f_14409: Text| crate::prelude::call_then(start_statements_f(body_pfx.clone()), move |statements_f_14426: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::if_stmt_f(&Text::from(format!("for {} in {}", &pattern_f_14394, &expression_f_14409)), &statements_f_14426)))))
            },
            crate::lower::model::Do::DoExpr(x_pg) => {
                let x_pgx = x_pg.clone();
                crate::prelude::call_then(start_expression_f(x_pgx.clone()), move |expression_f_14459: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &expression_f_14459))))
            },
            crate::lower::model::Do::DoIf(c_ph, t_pi, e_pj) => {
                let c_phx = c_ph.clone();
                let e_pjx = e_pj.clone();
                let t_pix = t_pi.clone();
                crate::prelude::call_then(start_expression_f(c_phx.clone()), move |expression_f_14507: Text| crate::prelude::call_then(start_statements_f(t_pix.clone()), move |statements_f_14524: Text| crate::prelude::call_then(start_else_branch_f(e_pjx.clone()), move |else_branch_f_14539: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &crate::emit::rust::templates::items::if_stmt_f(&Text::from(format!("if {}", &expression_f_14507)), &statements_f_14524), &else_branch_f_14539))))))
            },
            crate::lower::model::Do::DoIfLet(p_pk, x_pl, t_pm, e_pn) => {
                let e_pnx = e_pn.clone();
                let p_pkx = p_pk.clone();
                let t_pmx = t_pm.clone();
                let x_plx = x_pl.clone();
                crate::prelude::call_then(start_pattern_f(p_pkx.clone()), move |pattern_f_14596: Text| crate::prelude::call_then(start_expression_f(x_plx.clone()), move |expression_f_14610: Text| crate::prelude::call_then(start_statements_f(t_pmx.clone()), move |statements_f_14627: Text| crate::prelude::call_then(start_else_branch_f(e_pnx.clone()), move |else_branch_f_14642: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &crate::emit::rust::templates::items::if_stmt_f(&Text::from(format!("if let {} = {}", &pattern_f_14596, &expression_f_14610)), &statements_f_14627), &else_branch_f_14642)))))))
            },
            crate::lower::model::Do::DoMatch(x_po, cases_pp) => {
                let cases_ppx = cases_pp.clone();
                let x_pox = x_po.clone();
                crate::prelude::call_then(start_expression_f(x_pox.clone()), move |expression_f_14691: Text| crate::prelude::call_value(crate::prelude::each_job(cases_ppx.clone(), Rc::new(move |p0: (crate::lower::model::Pa, Array<crate::lower::model::Do>)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let (p_pq, body_pr) = p0;
                    crate::prelude::call_then(start_pattern_f(p_pq.clone()), move |pattern_f_14750: Text| crate::prelude::call_then(start_statements_f(body_pr.clone()), move |statements_f_14763: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::arm_block_f(&pattern_f_14750, &statements_f_14763))))
                }))) as Rc<dyn Fn((crate::lower::model::Pa, Array<crate::lower::model::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_14713: Array<Text>| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::match_block_f(&expression_f_14691, &crate::syntax::lexer::chars::join_f(&each_14713, &Text::lit("\n"))))))
            },
            crate::lower::model::Do::DoReturn(x_ps) => {
                let x_psx = x_ps.clone();
                crate::prelude::call_then(start_expression_f(x_psx.clone()), move |expression_f_14813: Text| prism_rtl::Turn::Finished(Text::from(format!("return {};", &expression_f_14813))))
            },
            crate::lower::model::Do::DoBlock(body_pt) => {
                let body_ptx = body_pt.clone();
                crate::prelude::call_then(start_statements_f(body_ptx.clone()), move |statements_f_14854: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::scope_f(&statements_f_14854)))
            },
            crate::lower::model::Do::DoScope(body_pu) => {
                let body_pux = body_pu.clone();
                crate::prelude::call_then(start_inline_statements_f(body_pux.clone()), move |inline_statements_f_14894: Text| prism_rtl::Turn::Finished(Text::from(format!("{{ {} }};", &inline_statements_f_14894))))
            },
            crate::lower::model::Do::DoLine(body_pv) => {
                let body_pvx = body_pv.clone();
                crate::prelude::call_then(start_inline_statements_f(body_pvx.clone()), move |inline_statements_f_14941: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &inline_statements_f_14941))))
            },
            crate::lower::model::Do::DoNote(t_p10) => prism_rtl::Turn::Finished(Text::from(format!("// {}", t_p10))),
        }
    }
}

/// `Start Statement, x`: what the function value is when passed to `@Run`.
pub fn start_statement_f(d_p0: crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Statement { d_p0 })
}

/// ```prism
/// InlineStatements: unbounded fn [Do] -> Text
/// ```
pub fn inline_statements_f(dos_p0: &Array<crate::lower::model::Do>) -> Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::run_to_end(crate::prelude::each_job(dos_p0.clone(), Rc::new(move |p0: crate::lower::model::Do| crate::prelude::entered(crate::prelude::once_job(move || {
        let d_p1 = p0;
        prism_rtl::Turn::More(Rc::new(InlineStatement { do_0: d_p1.clone() }))
    }))) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(" "))
}

/// The step machine of `InlineStatements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InlineStatements: unbounded fn [Do] -> Text
/// ```
pub struct InlineStatements {
    pub dos_p0: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for InlineStatements {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let dos_p0 = &self.dos_p0;
        let dos_p0x = dos_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(dos_p0x.clone(), Rc::new(move |p0: crate::lower::model::Do| crate::prelude::entered(crate::prelude::once_job(move || {
            let d_p1 = p0;
            prism_rtl::Turn::More(Rc::new(InlineStatement { do_0: d_p1.clone() }))
        }))) as Rc<dyn Fn(crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_15114: Array<Text>| prism_rtl::Turn::Finished(crate::syntax::lexer::chars::join_f(&each_15114, &Text::lit(" "))))
    }
}

/// `Start InlineStatements, x`: what the function value is when passed to `@Run`.
pub fn start_inline_statements_f(dos_p0: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(InlineStatements { dos_p0 })
}

/// ```prism
/// InlineStatement: unbounded fn Do -> Text
/// ```
pub fn inline_statement_f(do_0: &crate::lower::model::Do) -> Text {
    match do_0 {
        crate::lower::model::Do::DoIf(c_p0, t_p1, c0_0_2) if (c0_0_2.len() == 0) => Text::from(format!("if {} {{ {} }}", &expression_f(c_p0), &inline_statements_f(t_p1))),
        d_p2 => statement_f(d_p2),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `InlineStatement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InlineStatement: unbounded fn Do -> Text
/// ```
pub struct InlineStatement {
    pub do_0: crate::lower::model::Do,
}

impl prism_rtl::Job<Text> for InlineStatement {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let do_0 = &self.do_0;
        match do_0 {
            crate::lower::model::Do::DoIf(c_p0, t_p1, j0_0_2) if (j0_0_2.len() == 0) => {
                let c_p0x = c_p0.clone();
                let t_p1x = t_p1.clone();
                crate::prelude::call_then(start_expression_f(c_p0x.clone()), move |expression_f_15239: Text| crate::prelude::call_then(start_inline_statements_f(t_p1x.clone()), move |inline_statements_f_15257: Text| prism_rtl::Turn::Finished(Text::from(format!("if {} {{ {} }}", &expression_f_15239, &inline_statements_f_15257)))))
            },
            d_p2 => prism_rtl::Turn::More(Rc::new(Statement { d_p0: d_p2.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start InlineStatement, x`: what the function value is when passed to `@Run`.
pub fn start_inline_statement_f(do_0: crate::lower::model::Do) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(InlineStatement { do_0 })
}

/// ```prism
/// ElseBranch: unbounded fn [Do] -> Text
/// ```
pub fn else_branch_f(xs0: &Array<crate::lower::model::Do>) -> Text {
    'c: {
        if let c0_0 = xs0 && (c0_0.len() == 0) {
            break 'c Text::lit("");
        }
        if let c1_0 = xs0 && (c1_0.len() == 1) && let Some(crate::lower::model::Do::DoIf(c_p0, t_p1, e_p2)) = crate::prelude::index(c1_0, &Nat::from(0u32)) {
            break 'c Text::from(format!(" else {}", &statement_f(&crate::lower::model::Do::DoIf(c_p0.clone(), t_p1.clone(), e_p2.clone()))));
        }
        if let c2_0 = xs0 && (c2_0.len() == 1) && let Some(crate::lower::model::Do::DoIfLet(p_p3, x_p4, t_p5, e_p6)) = crate::prelude::index(c2_0, &Nat::from(0u32)) {
            break 'c Text::from(format!(" else {}", &statement_f(&crate::lower::model::Do::DoIfLet(p_p3.clone(), x_p4.clone(), t_p5.clone(), e_p6.clone()))));
        }
        if let body_p7 = xs0 {
            break 'c crate::emit::rust::templates::items::else_f(&statements_f(body_p7));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `ElseBranch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ElseBranch: unbounded fn [Do] -> Text
/// ```
pub struct ElseBranch {
    pub xs0: Array<crate::lower::model::Do>,
}

impl prism_rtl::Job<Text> for ElseBranch {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let xs0 = &self.xs0;
        'j: {
            if let j0_0 = xs0 && (j0_0.len() == 0) {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let j1_0 = xs0 && (j1_0.len() == 1) && let Some(crate::lower::model::Do::DoIf(c_p0, t_p1, e_p2)) = crate::prelude::index(j1_0, &Nat::from(0u32)) {
                break 'j crate::prelude::call_then(start_statement_f(crate::lower::model::Do::DoIf(c_p0.clone(), t_p1.clone(), e_p2.clone())), move |statement_f_15469: Text| prism_rtl::Turn::Finished(Text::from(format!(" else {}", &statement_f_15469))));
            }
            if let j2_0 = xs0 && (j2_0.len() == 1) && let Some(crate::lower::model::Do::DoIfLet(p_p3, x_p4, t_p5, e_p6)) = crate::prelude::index(j2_0, &Nat::from(0u32)) {
                break 'j crate::prelude::call_then(start_statement_f(crate::lower::model::Do::DoIfLet(p_p3.clone(), x_p4.clone(), t_p5.clone(), e_p6.clone())), move |statement_f_15545: Text| prism_rtl::Turn::Finished(Text::from(format!(" else {}", &statement_f_15545))));
            }
            if let body_p7 = xs0 {
                break 'j {
                    let body_p7x = body_p7.clone();
                    crate::prelude::call_then(start_statements_f(body_p7x.clone()), move |statements_f_15605: Text| prism_rtl::Turn::Finished(crate::emit::rust::templates::items::else_f(&statements_f_15605)))
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start ElseBranch, x`: what the function value is when passed to `@Run`.
pub fn start_else_branch_f(xs0: Array<crate::lower::model::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ElseBranch { xs0 })
}
