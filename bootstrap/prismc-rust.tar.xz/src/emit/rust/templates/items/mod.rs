//! The module `Emit.Rust.Templates.Items`, from `target/bootstrap/src/prismc/emit/rust/templates/items.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// Struct: fn Text, Text, Text, Text -> Text
/// ```
pub fn struct_(doc: &Text, derives: &Text, head: &Text, fields: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, doc, Some(0));
    out.push_str("#[derive(");
    place(&mut out, derives, None);
    out.push_str(")]\npub struct ");
    place(&mut out, head, None);
    out.push_str(" {\n");
    place(&mut out, fields, Some(4));
    out.push_str("}\n");
    Text::from(out)
}

/// ```prism
/// Enum: fn Text, Text, Text, Text -> Text
/// ```
pub fn enum_(doc: &Text, derives: &Text, head: &Text, cases: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, doc, Some(0));
    out.push_str("#[derive(");
    place(&mut out, derives, None);
    out.push_str(")]\npub enum ");
    place(&mut out, head, None);
    out.push_str(" {\n");
    place(&mut out, cases, Some(4));
    out.push_str("}\n");
    Text::from(out)
}

/// ```prism
/// TupleStruct: fn Text, Text, Text, Text -> Text
/// ```
pub fn tuple_struct(doc: &Text, derives: &Text, head: &Text, fields: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, doc, Some(0));
    out.push_str("#[derive(");
    place(&mut out, derives, None);
    out.push_str(")]\npub struct ");
    place(&mut out, head, None);
    place(&mut out, fields, None);
    out.push_str(";\n");
    Text::from(out)
}

/// ```prism
/// Impl: fn Text, Text, Text, Text, Text -> Text
/// ```
pub fn impl_(generics: &Text, tr: &Text, ty: &Text, signature: &Text, body: &Text) -> Text {
    let mut out = String::new();
    out.push_str("impl");
    place(&mut out, generics, None);
    out.push_str(" ");
    place(&mut out, tr, None);
    out.push_str(" for ");
    place(&mut out, ty, None);
    out.push_str(" {\n    ");
    place(&mut out, signature, None);
    out.push_str(" {\n");
    place(&mut out, body, Some(8));
    out.push_str("    }\n}\n");
    Text::from(out)
}

/// ```prism
/// MatchSelf: fn Text -> Text
/// ```
pub fn match_self(arms: &Text) -> Text {
    let mut out = String::new();
    out.push_str("match self {\n");
    place(&mut out, arms, Some(4));
    out.push_str("}\n");
    Text::from(out)
}

/// ```prism
/// ShownPod: fn Text -> Text
/// ```
pub fn shown_pod(structure: &Text) -> Text {
    let mut out = String::new();
    out.push_str("let structure = {\n");
    place(&mut out, structure, Some(4));
    out.push_str("};\nPod::Shown(show(self).as_str().into(), Box::new(structure))\n");
    Text::from(out)
}

/// ```prism
/// FromPodBody: fn Text, Text -> Text
/// ```
pub fn from_pod_body(arms: &Text, want: &Text) -> Text {
    let mut out = String::new();
    out.push_str("match p.structure() {\n");
    place(&mut out, arms, Some(4));
    out.push_str("    other => mismatch(\"");
    place(&mut out, want, None);
    out.push_str("\", other),\n}\n");
    Text::from(out)
}

/// ```prism
/// Tag: fn Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn tag(doc: &Text, derives: &Text, name: &Text, fields: &Text, tag_name: &Text, pods: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, doc, Some(0));
    out.push_str("#[derive(");
    place(&mut out, derives, None);
    out.push_str(")]\npub struct ");
    place(&mut out, name, None);
    out.push_str(" {\n");
    place(&mut out, fields, Some(4));
    out.push_str("}\n\nimpl ");
    place(&mut out, name, None);
    out.push_str(" {\n    /// The tag\'s qualified name, as its `Pod` carries it.\n    pub const TAG: &\'static str = \"");
    place(&mut out, tag_name, None);
    out.push_str("\";\n}\n\nimpl ToPod for ");
    place(&mut out, name, None);
    out.push_str(" {\n    fn to_pod(&self) -> Pod {\n        Pod::element(\"");
    place(&mut out, tag_name, None);
    out.push_str("\", vec![");
    place(&mut out, pods, None);
    out.push_str("])\n    }\n}\n\nimpl Show for ");
    place(&mut out, name, None);
    out.push_str(" {\n    fn show(&self, p: &mut Printer) {\n        self.to_pod().show(p);\n    }\n}\n");
    Text::from(out)
}

/// ```prism
/// TagFromPod: fn Text, Text, Text -> Text
/// ```
pub fn tag_from_pod(name: &Text, tag_name: &Text, reads: &Text) -> Text {
    let mut out = String::new();
    out.push_str("impl FromPod for ");
    place(&mut out, name, None);
    out.push_str(" {\n    fn from_pod(p: &Pod) -> Result<Self, Fault> {\n        match p.tag() {\n            Some(\"");
    place(&mut out, tag_name, None);
    out.push_str("\") => Ok(");
    place(&mut out, name, None);
    out.push_str(" { ");
    place(&mut out, reads, None);
    out.push_str(" }),\n            _ => prism_rtl::pod::mismatch(\"a ");
    place(&mut out, tag_name, None);
    out.push_str("\", p),\n        }\n    }\n}\n");
    Text::from(out)
}

/// ```prism
/// Row: fn Text, Text, Text, Text, Text -> Text
/// ```
pub fn row(doc: &Text, derives: &Text, name: &Text, cases: &Text, pods: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, doc, Some(0));
    out.push_str("#[derive(");
    place(&mut out, derives, None);
    out.push_str(")]\npub enum ");
    place(&mut out, name, None);
    out.push_str(" {\n");
    place(&mut out, cases, Some(4));
    out.push_str("}\n\nimpl ToPod for ");
    place(&mut out, name, None);
    out.push_str(" {\n    fn to_pod(&self) -> Pod {\n        match self {\n");
    place(&mut out, pods, Some(12));
    out.push_str("        }\n    }\n}\n\nimpl Show for ");
    place(&mut out, name, None);
    out.push_str(" {\n    fn show(&self, p: &mut Printer) {\n        self.to_pod().show(p);\n    }\n}\n");
    Text::from(out)
}

/// ```prism
/// RowFromPod: fn Text, Text -> Text
/// ```
pub fn row_from_pod(name: &Text, reads: &Text) -> Text {
    let mut out = String::new();
    out.push_str("impl FromPod for ");
    place(&mut out, name, None);
    out.push_str(" {\n    fn from_pod(p: &Pod) -> Result<Self, Fault> {\n        match p.tag() {\n");
    place(&mut out, reads, Some(12));
    out.push_str("            _ => prism_rtl::pod::mismatch(\"a ");
    place(&mut out, name, None);
    out.push_str("\", p),\n        }\n    }\n}\n");
    Text::from(out)
}

/// ```prism
/// Fn: fn Text, Text, Text -> Text
/// ```
pub fn fn_(doc: &Text, signature: &Text, body: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, doc, Some(0));
    place(&mut out, signature, None);
    out.push_str(" {\n");
    place(&mut out, body, Some(4));
    out.push_str("}\n");
    Text::from(out)
}

/// ```prism
/// Job: fn Text, Text, Text, Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn job(doc: &Text, head: &Text, generics: &Text, bounded: &Text, fields: &Text, ret: &Text, body: &Text, start: &Text, start_body: &Text) -> Text {
    let mut out = String::new();
    out.push_str("/// The step machine of `");
    place(&mut out, head, None);
    out.push_str("`, stopped at a cycle point: the call about to be\n/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the\n/// callee\'s job, so the job\'s stack is its frames.\n///\n");
    place(&mut out, doc, Some(0));
    out.push_str("pub struct ");
    place(&mut out, head, None);
    place(&mut out, generics, None);
    out.push_str(" {\n");
    place(&mut out, fields, Some(4));
    out.push_str("}\n\nimpl");
    place(&mut out, bounded, None);
    out.push_str(" prism_rtl::Job<");
    place(&mut out, ret, None);
    out.push_str("> for ");
    place(&mut out, head, None);
    place(&mut out, generics, None);
    out.push_str(" {\n    fn cycle(&self) -> prism_rtl::Turn<");
    place(&mut out, ret, None);
    out.push_str("> {\n");
    place(&mut out, body, Some(8));
    out.push_str("    }\n}\n\n/// `Start ");
    place(&mut out, head, None);
    out.push_str(", x`: what the function value is when passed to `@Run`.\n");
    place(&mut out, start, None);
    out.push_str(" {\n");
    place(&mut out, start_body, Some(4));
    out.push_str("}\n");
    Text::from(out)
}

/// ```prism
/// Node: fn Text, Text, Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn node_(doc: &Text, name: &Text, fields: &Text, consts: &Text, build_: &Text, methods: &Text, hooks: &Text, answer_: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, doc, Some(0));
    out.push_str("pub struct ");
    place(&mut out, name, None);
    out.push_str(" {\n    path: Path,\n");
    place(&mut out, fields, Some(4));
    out.push_str("}\n\nimpl ");
    place(&mut out, name, None);
    out.push_str(" {\n");
    place(&mut out, consts, Some(4));
    place(&mut out, build_, Some(4));
    place(&mut out, methods, Some(4));
    out.push_str("}\n\nimpl Node for ");
    place(&mut out, name, None);
    out.push_str(" {\n");
    place(&mut out, answer_, Some(4));
    place(&mut out, hooks, Some(4));
    out.push_str("}\n");
    Text::from(out)
}

/// ```prism
/// Build: fn Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn build(name: &Text, params: &Text, ret: &Text, lets: &Text, inits: &Text, rest: &Text) -> Text {
    let mut out = String::new();
    out.push_str("/// Built after propagation: holds take their initial values, places go out with\n/// `cx.added`, and nothing fires.\npub fn build(path: Path, ");
    place(&mut out, params, None);
    out.push_str("cx: &mut Cx) -> ");
    place(&mut out, ret, None);
    out.push_str(" {\n");
    place(&mut out, lets, Some(4));
    out.push_str("    let node = Rc::new(");
    place(&mut out, name, None);
    out.push_str(" { ");
    place(&mut out, inits, None);
    out.push_str(" });\n");
    place(&mut out, rest, Some(4));
    out.push_str("}\n");
    Text::from(out)
}

/// ```prism
/// Method: fn Text, Text, Text -> Text
/// ```
pub fn method(doc: &Text, signature: &Text, body: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, doc, Some(0));
    place(&mut out, signature, None);
    out.push_str(" {\n");
    place(&mut out, body, Some(4));
    out.push_str("}\n");
    Text::from(out)
}

/// ```prism
/// ForBuild: fn Text, Text, Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn for_build(name: &Text, at_: &Text, key_ty: &Text, value_ty: &Text, row_node: &Text, source: &Text, parent: &Text, passed: &Text) -> Text {
    let mut out = String::new();
    out.push_str("/// The rows of the `for` at `");
    place(&mut out, at_, None);
    out.push_str("`: rows whose key left are torn down, new keys are\n/// built under it at `[k]` from the values after the tick; kept rows keep reading their\n/// entry out of the source.\nfn ");
    place(&mut out, name, None);
    out.push_str("_build(self: &Rc<Self>, cx: &mut Cx) -> Done {\n    let items: Map<");
    place(&mut out, key_ty, None);
    out.push_str(", ");
    place(&mut out, value_ty, None);
    out.push_str("> = self.");
    place(&mut out, source, None);
    out.push_str("(cx);\n    let old = self.");
    place(&mut out, name, None);
    out.push_str(".borrow().clone();\n    // the kept rows stay where they are: only the keys that left or came are touched\n    let mut next = old.clone();\n    for (k, row) in old.iter() {\n        if !items.contains_key(k) {\n            row.leave_row(cx);\n            cx.leave_later(row.clone());\n            next.remove(k);\n        }\n    }\n    for (k, v) in items.iter() {\n        if !old.contains_key(k) {\n            let row = ");
    place(&mut out, row_node, None);
    out.push_str("::build(");
    place(&mut out, at_, None);
    out.push_str(".child(Segment::Key(k.to_pod())), k.clone(), v.clone(), ");
    place(&mut out, parent, None);
    place(&mut out, passed, None);
    out.push_str(", cx)?;\n            next.insert(k.clone(), row);\n        }\n    }\n    *self.");
    place(&mut out, name, None);
    out.push_str(".borrow_mut() = next;\n    // What the block reads of its rows (a `for` that gives a dynamic) moved.\n    cx.dirty(self.clone());\n    Ok(())\n}\n");
    Text::from(out)
}

/// ```prism
/// GenBuild: fn Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn gen_build(name: &Text, at_: &Text, path_: &Text, source: &Text, value_ty: &Text, select: &Text) -> Text {
    let mut out = String::new();
    out.push_str("/// The `rebuild` at `");
    place(&mut out, at_, None);
    out.push_str("`: the old generation torn down (it ran to the end of the\n/// tick), the next built at `");
    place(&mut out, path_, None);
    out.push_str("` from the source after the tick.\nfn ");
    place(&mut out, name, None);
    out.push_str("_build(self: &Rc<Self>, cx: &mut Cx) -> Done {\n    if let Some(old) = self.");
    place(&mut out, name, None);
    out.push_str(".borrow_mut().take() {\n        old.leave_row(cx);\n        cx.leave_later(old);\n    }\n    let g = self.");
    place(&mut out, name, None);
    out.push_str("_count.get();\n    self.");
    place(&mut out, name, None);
    out.push_str("_count.set(g + 1);\n    let path = ");
    place(&mut out, path_, None);
    out.push_str(";\n    let value: ");
    place(&mut out, value_ty, None);
    out.push_str(" = ");
    place(&mut out, source, None);
    out.push_str(";\n    let row: Rc<dyn Row> = ");
    place(&mut out, select, None);
    out.push_str(";\n    *self.");
    place(&mut out, name, None);
    out.push_str(".borrow_mut() = Some(row);\n    Ok(())\n}\n");
    Text::from(out)
}

/// ```prism
/// RowImpl: fn Text, Text, Text -> Text
/// ```
pub fn row_impl(name: &Text, leaving: &Text, hosted: &Text) -> Text {
    let mut out = String::new();
    out.push_str("impl Row for ");
    place(&mut out, name, None);
    out.push_str(" {\n    fn leave_row(&self, cx: &mut Cx) {\n");
    place(&mut out, leaving, Some(8));
    out.push_str("    }\n");
    place(&mut out, hosted, Some(4));
    out.push_str("}\n");
    Text::from(out)
}

/// ```prism
/// AnswerType: fn Text, Text, Text, Text -> Text
/// ```
pub fn answer_type(cases: &Text, tags: &Text, accessors: &Text, decodes: &Text) -> Text {
    let mut out = String::new();
    out.push_str("/// `Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host\'s\n/// supplier answers a child place with, and what a World\'s answer to a forwarded element\n/// decodes to, carrying the tag\'s output.\n#[derive(Clone)]\npub enum Answer {\n");
    place(&mut out, cases, Some(4));
    out.push_str("}\n\nimpl Answer {\n    /// The tag the answer is for.\n    pub fn tag(&self) -> &\'static str {\n        match self {\n");
    place(&mut out, tags, Some(12));
    out.push_str("        }\n    }\n");
    place(&mut out, accessors, Some(4));
    out.push_str("}\n\nimpl prism_rtl::AnswerOf<Elem> for Answer {\n    /// A World\'s answer to the element `e`, decoded by its tag.\n    fn decode(e: &Elem, v: &Pod) -> Result<Answer, Fault> {\n        match e {\n");
    place(&mut out, decodes, Some(12));
    out.push_str("        }\n    }\n}\n");
    Text::from(out)
}

/// ```prism
/// AnswerGetter: fn Text, Text, Text, Text -> Text
/// ```
pub fn answer_getter(accessor: &Text, variant: &Text, tag_name: &Text, ty: &Text) -> Text {
    let mut out = String::new();
    out.push_str("/// A `");
    place(&mut out, tag_name, None);
    out.push_str("`\'s answer.\npub fn ");
    place(&mut out, accessor, None);
    out.push_str("(&self) -> Result<");
    place(&mut out, ty, None);
    out.push_str(", Fault> {\n    match self {\n        Answer::");
    place(&mut out, variant, None);
    out.push_str("(v) => Ok(v.clone()),\n        other => Err(Fault::answer(format!(\"an answer for {}, where ");
    place(&mut out, tag_name, None);
    out.push_str("\'s was expected\", other.tag()))),\n    }\n}\n");
    Text::from(out)
}

/// ```prism
/// Answer: fn Text -> Text
/// ```
pub fn answer(arms: &Text) -> Text {
    let mut out = String::new();
    out.push_str("fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {\n    match at {\n");
    place(&mut out, arms, Some(8));
    out.push_str("        _ => return Err(Fault::answer(format!(\"no answering place at {}\", Path(at.to_vec())))),\n    }\n    Ok(())\n}\n");
    Text::from(out)
}

/// ```prism
/// Hook: fn Text, Text -> Text
/// ```
pub fn hook(name: &Text, body: &Text) -> Text {
    let mut out = String::new();
    out.push_str("fn ");
    place(&mut out, name, None);
    out.push_str("(self: Rc<Self>, cx: &mut Cx) -> Done {\n");
    place(&mut out, body, Some(4));
    out.push_str("    Ok(())\n}\n");
    Text::from(out)
}

/// ```prism
/// PushHook: fn Text -> Text
/// ```
pub fn push_hook(body: &Text) -> Text {
    let mut out = String::new();
    out.push_str("fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {\n");
    place(&mut out, body, Some(4));
    out.push_str("    Ok(())\n}\n");
    Text::from(out)
}

/// ```prism
/// Program: fn Text, Text, Text, Text, Text -> Text
/// ```
pub fn program(name: &Text, prism: &Text, node__: &Text, decode: &Text, call: &Text) -> Text {
    let mut out = String::new();
    out.push_str("/// The program of `@");
    place(&mut out, prism, None);
    out.push_str("`: the root node and the runtime.\npub struct ");
    place(&mut out, name, None);
    out.push_str(" {\n    rt: Runtime,\n    root: Rc<");
    place(&mut out, node__, None);
    out.push_str(">,\n}\n\nimpl Program for ");
    place(&mut out, name, None);
    out.push_str(" {\n    fn build(args: &[Pod], ready: &dyn ReadyState) -> Result<(Self, TickOut), Fault> {\n");
    place(&mut out, decode, Some(8));
    out.push_str("        let mut rt = Runtime::new();\n        let mut cx = rt.build(ready);\n        let root = ");
    place(&mut out, call, None);
    out.push_str(";\n        let out = rt.close(cx)?;\n        Ok((");
    place(&mut out, name, None);
    out.push_str(" { rt, root }, out))\n    }\n    fn tick(&mut self, input: &TickIn, ready: &dyn ReadyState) -> Result<TickOut, Fault> {\n        let root: Rc<dyn Node> = self.root.clone();\n        self.rt.tick(&root, input, ready)\n    }\n    fn compact(&mut self) {\n        self.rt.compact();\n    }\n}\n");
    Text::from(out)
}

/// ```prism
/// MatchBlock: fn Text, Text -> Text
/// ```
pub fn match_block(scrut: &Text, arms: &Text) -> Text {
    let mut out = String::new();
    out.push_str("match ");
    place(&mut out, scrut, None);
    out.push_str(" {\n");
    place(&mut out, arms, Some(4));
    out.push_str("}");
    Text::from(out)
}

/// ```prism
/// Block: fn Text, Text -> Text
/// ```
pub fn block(stmts: &Text, tail: &Text) -> Text {
    let mut out = String::new();
    out.push_str("{\n");
    place(&mut out, stmts, Some(4));
    place(&mut out, tail, Some(4));
    out.push_str("}");
    Text::from(out)
}

/// ```prism
/// Labeled: fn Text, Text, Text -> Text
/// ```
pub fn labeled(label: &Text, stmts: &Text, tail: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, label, None);
    out.push_str(": {\n");
    place(&mut out, stmts, Some(4));
    place(&mut out, tail, Some(4));
    out.push_str("}");
    Text::from(out)
}

/// ```prism
/// If: fn Text, Text, Text -> Text
/// ```
pub fn if_(cond: &Text, then_x: &Text, else_x: &Text) -> Text {
    let mut out = String::new();
    out.push_str("if ");
    place(&mut out, cond, None);
    out.push_str(" {\n");
    place(&mut out, then_x, Some(4));
    out.push_str("} else {\n");
    place(&mut out, else_x, Some(4));
    out.push_str("}");
    Text::from(out)
}

/// ```prism
/// IfStmt: fn Text, Text -> Text
/// ```
pub fn if_stmt(head: &Text, body: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, head, None);
    out.push_str(" {\n");
    place(&mut out, body, Some(4));
    out.push_str("}");
    Text::from(out)
}

/// ```prism
/// Scope: fn Text -> Text
/// ```
pub fn scope(body: &Text) -> Text {
    let mut out = String::new();
    out.push_str("{\n");
    place(&mut out, body, Some(4));
    out.push_str("}");
    Text::from(out)
}

/// ```prism
/// Else: fn Text -> Text
/// ```
pub fn else_(body: &Text) -> Text {
    let mut out = String::new();
    out.push_str(" else {\n");
    place(&mut out, body, Some(4));
    out.push_str("}");
    Text::from(out)
}

/// ```prism
/// ArmBlock: fn Text, Text -> Text
/// ```
pub fn arm_block(pat: &Text, body: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, pat, None);
    out.push_str(" => {\n");
    place(&mut out, body, Some(4));
    out.push_str("}");
    Text::from(out)
}

/// ```prism
/// ChainArm: fn Text, Text, Text -> Text
/// ```
pub fn chain_arm(head: &Text, label: &Text, body: &Text) -> Text {
    let mut out = String::new();
    out.push_str("if ");
    place(&mut out, head, None);
    out.push_str(" {\n    break ");
    place(&mut out, label, None);
    out.push_str(" ");
    place(&mut out, body, None);
    out.push_str(";\n}");
    Text::from(out)
}
