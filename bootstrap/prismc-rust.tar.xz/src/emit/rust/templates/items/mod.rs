//! The module `Emit.Rust.Templates.Items`, from `target/bootstrap/src/prismc/emit/rust/templates/items.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// Struct: fn Text, Text, Text, Text -> Text
/// ```
pub fn struct_(doc_p0: &Text, derives_p1: &Text, head_p2: &Text, fields_p3: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, doc_p0, Some(0));
    out.push_str("#[derive(");
    place(&mut out, derives_p1, None);
    out.push_str(")]\npub struct ");
    place(&mut out, head_p2, None);
    out.push_str(" {\n");
    place(&mut out, fields_p3, Some(4));
    out.push_str("}\n");
    Text::from(out)
}

/// ```prism
/// Enum: fn Text, Text, Text, Text -> Text
/// ```
pub fn enum_(doc_p0: &Text, derives_p1: &Text, head_p2: &Text, cases_p3: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, doc_p0, Some(0));
    out.push_str("#[derive(");
    place(&mut out, derives_p1, None);
    out.push_str(")]\npub enum ");
    place(&mut out, head_p2, None);
    out.push_str(" {\n");
    place(&mut out, cases_p3, Some(4));
    out.push_str("}\n");
    Text::from(out)
}

/// ```prism
/// TupleStruct: fn Text, Text, Text, Text -> Text
/// ```
pub fn tuple_struct(doc_p0: &Text, derives_p1: &Text, head_p2: &Text, fields_p3: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, doc_p0, Some(0));
    out.push_str("#[derive(");
    place(&mut out, derives_p1, None);
    out.push_str(")]\npub struct ");
    place(&mut out, head_p2, None);
    place(&mut out, fields_p3, None);
    out.push_str(";\n");
    Text::from(out)
}

/// ```prism
/// Impl: fn Text, Text, Text, Text, Text -> Text
/// ```
pub fn impl_(generics_p0: &Text, tr_p1: &Text, ty_p2: &Text, signature_p3: &Text, body_p4: &Text) -> Text {
    let mut out = String::new();
    out.push_str("impl");
    place(&mut out, generics_p0, None);
    out.push_str(" ");
    place(&mut out, tr_p1, None);
    out.push_str(" for ");
    place(&mut out, ty_p2, None);
    out.push_str(" {\n    ");
    place(&mut out, signature_p3, None);
    out.push_str(" {\n");
    place(&mut out, body_p4, Some(8));
    out.push_str("    }\n}\n");
    Text::from(out)
}

/// ```prism
/// MatchSelf: fn Text -> Text
/// ```
pub fn match_self(arms_p0: &Text) -> Text {
    let mut out = String::new();
    out.push_str("match self {\n");
    place(&mut out, arms_p0, Some(4));
    out.push_str("}\n");
    Text::from(out)
}

/// ```prism
/// ShownPod: fn Text -> Text
/// ```
pub fn shown_pod(structure_p0: &Text) -> Text {
    let mut out = String::new();
    out.push_str("let structure = {\n");
    place(&mut out, structure_p0, Some(4));
    out.push_str("};\nPod::Shown(show(self).as_str().into(), Box::new(structure))\n");
    Text::from(out)
}

/// ```prism
/// FromPodBody: fn Text, Text -> Text
/// ```
pub fn from_pod_body(arms_p0: &Text, want_p1: &Text) -> Text {
    let mut out = String::new();
    out.push_str("match p.structure() {\n");
    place(&mut out, arms_p0, Some(4));
    out.push_str("    other => mismatch(\"");
    place(&mut out, want_p1, None);
    out.push_str("\", other),\n}\n");
    Text::from(out)
}

/// ```prism
/// Tag: fn Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn tag(doc_p0: &Text, derives_p1: &Text, name_p2: &Text, fields_p3: &Text, tag_name_p4: &Text, pods_p5: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, doc_p0, Some(0));
    out.push_str("#[derive(");
    place(&mut out, derives_p1, None);
    out.push_str(")]\npub struct ");
    place(&mut out, name_p2, None);
    out.push_str(" {\n");
    place(&mut out, fields_p3, Some(4));
    out.push_str("}\n\nimpl ");
    place(&mut out, name_p2, None);
    out.push_str(" {\n    /// The tag\'s qualified name, as its `Pod` carries it.\n    pub const TAG: &\'static str = \"");
    place(&mut out, tag_name_p4, None);
    out.push_str("\";\n}\n\nimpl ToPod for ");
    place(&mut out, name_p2, None);
    out.push_str(" {\n    fn to_pod(&self) -> Pod {\n        Pod::element(\"");
    place(&mut out, tag_name_p4, None);
    out.push_str("\", vec![");
    place(&mut out, pods_p5, None);
    out.push_str("])\n    }\n}\n\nimpl Show for ");
    place(&mut out, name_p2, None);
    out.push_str(" {\n    fn show(&self, p: &mut Printer) {\n        self.to_pod().show(p);\n    }\n}\n");
    Text::from(out)
}

/// ```prism
/// TagLevel: fn Text, Text, Text, Text -> Text
/// ```
pub fn tag_level(name_p0: &Text, tag_name_p1: &Text, pods_p2: &Text, ports_p3: &Text) -> Text {
    let mut out = String::new();
    out.push_str("impl ");
    place(&mut out, name_p0, None);
    out.push_str(" {\n    /// The level as a World reads it: each dynamic it holds sampled at the read point.\n    pub fn level_pod(&self, cx: &Cx) -> Pod {\n        Pod::element(\"");
    place(&mut out, tag_name_p1, None);
    out.push_str("\", vec![");
    place(&mut out, pods_p2, None);
    out.push_str("])\n    }\n    /// The update events of the dynamics it holds, and of theirs.\n    pub fn level_ports(&self, cx: &Cx, out: &mut Vec<Rc<Port<()>>>) {\n        let _ = (cx, &out);");
    place(&mut out, ports_p3, None);
    out.push_str("\n    }\n}\n");
    Text::from(out)
}

/// ```prism
/// RowLevel: fn Text, Text, Text -> Text
/// ```
pub fn row_level(name_p0: &Text, pods_p1: &Text, ports_p2: &Text) -> Text {
    let mut out = String::new();
    out.push_str("impl prism_rtl::Level for ");
    place(&mut out, name_p0, None);
    out.push_str(" {\n    fn level_pod(&self, cx: &Cx) -> Pod {\n        let _ = cx;\n        match self {\n            ");
    place(&mut out, pods_p1, None);
    out.push_str("_ => self.to_pod(),\n        }\n    }\n    fn level_ports(&self, cx: &Cx, out: &mut Vec<Rc<Port<()>>>) {\n        let _ = (cx, &out);\n        match self {\n            ");
    place(&mut out, ports_p2, None);
    out.push_str("_ => {}\n        }\n    }\n}\n");
    Text::from(out)
}

/// ```prism
/// TagFromPod: fn Text, Text, Text -> Text
/// ```
pub fn tag_from_pod(name_p0: &Text, tag_name_p1: &Text, reads_p2: &Text) -> Text {
    let mut out = String::new();
    out.push_str("impl FromPod for ");
    place(&mut out, name_p0, None);
    out.push_str(" {\n    fn from_pod(p: &Pod) -> Result<Self, Fault> {\n        match p.tag() {\n            Some(\"");
    place(&mut out, tag_name_p1, None);
    out.push_str("\") => Ok(");
    place(&mut out, name_p0, None);
    out.push_str(" { ");
    place(&mut out, reads_p2, None);
    out.push_str(" }),\n            _ => prism_rtl::pod::mismatch(\"a ");
    place(&mut out, tag_name_p1, None);
    out.push_str("\", p),\n        }\n    }\n}\n");
    Text::from(out)
}

/// ```prism
/// Row: fn Text, Text, Text, Text, Text -> Text
/// ```
pub fn row(doc_p0: &Text, derives_p1: &Text, name_p2: &Text, cases_p3: &Text, pods_p4: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, doc_p0, Some(0));
    out.push_str("#[derive(");
    place(&mut out, derives_p1, None);
    out.push_str(")]\npub enum ");
    place(&mut out, name_p2, None);
    out.push_str(" {\n");
    place(&mut out, cases_p3, Some(4));
    out.push_str("}\n\nimpl ToPod for ");
    place(&mut out, name_p2, None);
    out.push_str(" {\n    fn to_pod(&self) -> Pod {\n        match self {\n");
    place(&mut out, pods_p4, Some(12));
    out.push_str("        }\n    }\n}\n\nimpl Show for ");
    place(&mut out, name_p2, None);
    out.push_str(" {\n    fn show(&self, p: &mut Printer) {\n        self.to_pod().show(p);\n    }\n}\n");
    Text::from(out)
}

/// ```prism
/// RowFromPod: fn Text, Text -> Text
/// ```
pub fn row_from_pod(name_p0: &Text, reads_p1: &Text) -> Text {
    let mut out = String::new();
    out.push_str("impl FromPod for ");
    place(&mut out, name_p0, None);
    out.push_str(" {\n    fn from_pod(p: &Pod) -> Result<Self, Fault> {\n        match p.tag() {\n");
    place(&mut out, reads_p1, Some(12));
    out.push_str("            _ => prism_rtl::pod::mismatch(\"a ");
    place(&mut out, name_p0, None);
    out.push_str("\", p),\n        }\n    }\n}\n");
    Text::from(out)
}

/// ```prism
/// Fn: fn Text, Text, Text -> Text
/// ```
pub fn fn_(doc_p0: &Text, signature_p1: &Text, body_p2: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, doc_p0, Some(0));
    place(&mut out, signature_p1, None);
    out.push_str(" {\n");
    place(&mut out, body_p2, Some(4));
    out.push_str("}\n");
    Text::from(out)
}

/// ```prism
/// Job: fn Text, Text, Text, Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn job(doc_p0: &Text, head_p1: &Text, generics_p2: &Text, bounded_p3: &Text, fields_p4: &Text, ret_p5: &Text, body_p6: &Text, start_p7: &Text, start_body_p8: &Text) -> Text {
    let mut out = String::new();
    out.push_str("/// The step machine of `");
    place(&mut out, head_p1, None);
    out.push_str("`, stopped at a cycle point: the call about to be\n/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the\n/// callee\'s job, so the job\'s stack is its frames.\n///\n");
    place(&mut out, doc_p0, Some(0));
    out.push_str("pub struct ");
    place(&mut out, head_p1, None);
    place(&mut out, generics_p2, None);
    out.push_str(" {\n");
    place(&mut out, fields_p4, Some(4));
    out.push_str("}\n\nimpl");
    place(&mut out, bounded_p3, None);
    out.push_str(" prism_rtl::Job<");
    place(&mut out, ret_p5, None);
    out.push_str("> for ");
    place(&mut out, head_p1, None);
    place(&mut out, generics_p2, None);
    out.push_str(" {\n    fn cycle(&self) -> prism_rtl::Turn<");
    place(&mut out, ret_p5, None);
    out.push_str("> {\n");
    place(&mut out, body_p6, Some(8));
    out.push_str("    }\n}\n\n/// `Start ");
    place(&mut out, head_p1, None);
    out.push_str(", x`: what the function value is when passed to `@Run`.\n");
    place(&mut out, start_p7, None);
    out.push_str(" {\n");
    place(&mut out, start_body_p8, Some(4));
    out.push_str("}\n");
    Text::from(out)
}

/// ```prism
/// Node: fn Text, Text, Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn node_(doc_p0: &Text, name_p1: &Text, fields_p2: &Text, consts_p3: &Text, build_p4: &Text, methods_p5: &Text, hooks_p6: &Text, answer_p7: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, doc_p0, Some(0));
    out.push_str("pub struct ");
    place(&mut out, name_p1, None);
    out.push_str(" {\n    path: Path,\n");
    place(&mut out, fields_p2, Some(4));
    out.push_str("}\n\nimpl ");
    place(&mut out, name_p1, None);
    out.push_str(" {\n");
    place(&mut out, consts_p3, Some(4));
    place(&mut out, build_p4, Some(4));
    place(&mut out, methods_p5, Some(4));
    out.push_str("}\n\nimpl Node for ");
    place(&mut out, name_p1, None);
    out.push_str(" {\n");
    place(&mut out, answer_p7, Some(4));
    place(&mut out, hooks_p6, Some(4));
    out.push_str("}\n");
    Text::from(out)
}

/// ```prism
/// Build: fn Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn build(name_p0: &Text, params_p1: &Text, ret_p2: &Text, lets_p3: &Text, inits_p4: &Text, rest_p5: &Text) -> Text {
    let mut out = String::new();
    out.push_str("/// Built after propagation: holds take their initial values, places go out with\n/// `cx.added`, and nothing fires.\npub fn build(path: Path, ");
    place(&mut out, params_p1, None);
    out.push_str("cx: &mut Cx) -> ");
    place(&mut out, ret_p2, None);
    out.push_str(" {\n");
    place(&mut out, lets_p3, Some(4));
    out.push_str("    let node = Rc::new(");
    place(&mut out, name_p0, None);
    out.push_str(" { ");
    place(&mut out, inits_p4, None);
    out.push_str(" });\n");
    place(&mut out, rest_p5, Some(4));
    out.push_str("}\n");
    Text::from(out)
}

/// ```prism
/// Method: fn Text, Text, Text -> Text
/// ```
pub fn method(doc_p0: &Text, signature_p1: &Text, body_p2: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, doc_p0, Some(0));
    place(&mut out, signature_p1, None);
    out.push_str(" {\n");
    place(&mut out, body_p2, Some(4));
    out.push_str("}\n");
    Text::from(out)
}

/// ```prism
/// ForBuild: fn Text, Text, Text, Text, Text, Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn for_build(name_p0: &Text, at_p1: &Text, key_ty_p2: &Text, value_ty_p3: &Text, row_node_p4: &Text, source_p5: &Text, parent_p6: &Text, passed_p7: &Text, moved_p8: &Text, from_p9: &Text, replaced_pa: &Text) -> Text {
    let mut out = String::new();
    out.push_str("/// The rows of the `for` at `");
    place(&mut out, at_p1, None);
    out.push_str("`: rows whose key left are torn down, new keys are\n/// built under it at `[k]` from the values after the tick; kept rows keep reading their\n/// entry out of the source. Nothing to do when the source is the map last built from.\nfn ");
    place(&mut out, name_p0, None);
    out.push_str("_build(self: &Rc<Self>, cx: &mut Cx) -> Done {\n    let items: Map<");
    place(&mut out, key_ty_p2, None);
    out.push_str(", ");
    place(&mut out, value_ty_p3, None);
    out.push_str("> = self.");
    place(&mut out, source_p5, None);
    out.push_str("(cx);\n    if self.");
    place(&mut out, name_p0, None);
    out.push_str("_from.borrow().same(&items) {\n        return Ok(());\n    }\n");
    place(&mut out, from_p9, Some(4));
    out.push_str("    let old = self.");
    place(&mut out, name_p0, None);
    out.push_str(".borrow().clone();\n    // the kept rows stay where they are: only the keys that left or came are touched\n    let mut next = old.clone();\n    for (k, row) in old.iter() {\n        if !items.contains_key(k) {\n            row.leave_row(cx);\n            cx.leave_later(row.clone());\n            next.remove(k);\n        }");
    place(&mut out, replaced_pa, None);
    out.push_str("\n    }\n    for (k, v) in items.iter() {\n        if !old.contains_key(k) {\n            let row = ");
    place(&mut out, row_node_p4, None);
    out.push_str("::build(");
    place(&mut out, at_p1, None);
    out.push_str(".child(Segment::Key(k.to_pod())), k.clone(), v.clone(), ");
    place(&mut out, parent_p6, None);
    place(&mut out, passed_p7, None);
    out.push_str(", cx)?;\n            next.insert(k.clone(), row);\n        }\n    }\n    *self.");
    place(&mut out, name_p0, None);
    out.push_str(".borrow_mut() = next;\n    // What the block reads of its rows (a `for` that gives a dynamic) moved.\n    cx.dirty(self.clone());");
    place(&mut out, moved_p8, None);
    out.push_str("\n    Ok(())\n}\n");
    Text::from(out)
}

/// ```prism
/// GenBuild: fn Text, Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn gen_build(name_p0: &Text, at_p1: &Text, path_p2: &Text, source_p3: &Text, value_ty_p4: &Text, select_p5: &Text, moved_p6: &Text) -> Text {
    let mut out = String::new();
    out.push_str("/// The `rebuild` at `");
    place(&mut out, at_p1, None);
    out.push_str("`: the old generation torn down (it ran to the end of the\n/// tick), the next built at `");
    place(&mut out, path_p2, None);
    out.push_str("` from the source after the tick.\nfn ");
    place(&mut out, name_p0, None);
    out.push_str("_build(self: &Rc<Self>, cx: &mut Cx) -> Done {\n    if let Some(old) = self.");
    place(&mut out, name_p0, None);
    out.push_str(".borrow_mut().take() {\n        old.leave_row(cx);\n        cx.leave_later(old);\n    }\n    let g = self.");
    place(&mut out, name_p0, None);
    out.push_str("_count.get();\n    self.");
    place(&mut out, name_p0, None);
    out.push_str("_count.set(g + 1);\n    let path = ");
    place(&mut out, path_p2, None);
    out.push_str(";\n    let value: ");
    place(&mut out, value_ty_p4, None);
    out.push_str(" = ");
    place(&mut out, source_p3, None);
    out.push_str(";\n    let row: Rc<dyn Row> = ");
    place(&mut out, select_p5, None);
    out.push_str(";\n    *self.");
    place(&mut out, name_p0, None);
    out.push_str(".borrow_mut() = Some(row);");
    place(&mut out, moved_p6, None);
    out.push_str("\n    Ok(())\n}\n");
    Text::from(out)
}

/// ```prism
/// RowImpl: fn Text, Text, Text -> Text
/// ```
pub fn row_impl(name_p0: &Text, leaving_p1: &Text, hosted_p2: &Text) -> Text {
    let mut out = String::new();
    out.push_str("impl Row for ");
    place(&mut out, name_p0, None);
    out.push_str(" {\n    fn leave_row(&self, cx: &mut Cx) {\n");
    place(&mut out, leaving_p1, Some(8));
    out.push_str("    }\n");
    place(&mut out, hosted_p2, Some(4));
    out.push_str("}\n");
    Text::from(out)
}

/// ```prism
/// AnswerType: fn Text, Text, Text, Text -> Text
/// ```
pub fn answer_type(cases_p0: &Text, tags_p1: &Text, accessors_p2: &Text, decodes_p3: &Text) -> Text {
    let mut out = String::new();
    out.push_str("/// `Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host\'s\n/// supplier answers a child place with, and what a World\'s answer to a forwarded element\n/// decodes to, carrying the tag\'s output.\n#[derive(Clone)]\npub enum Answer {\n");
    place(&mut out, cases_p0, Some(4));
    out.push_str("}\n\nimpl Answer {\n    /// The tag the answer is for.\n    pub fn tag(&self) -> &\'static str {\n        match self {\n");
    place(&mut out, tags_p1, Some(12));
    out.push_str("        }\n    }\n");
    place(&mut out, accessors_p2, Some(4));
    out.push_str("}\n\nimpl prism_rtl::AnswerOf<Elem> for Answer {\n    /// A World\'s answer to the element `e`, decoded by its tag.\n    fn decode(e: &Elem, v: &Pod) -> Result<Answer, Fault> {\n        match e {\n");
    place(&mut out, decodes_p3, Some(12));
    out.push_str("        }\n    }\n}\n");
    Text::from(out)
}

/// ```prism
/// AnswerGetter: fn Text, Text, Text, Text -> Text
/// ```
pub fn answer_getter(accessor_p0: &Text, variant_p1: &Text, tag_name_p2: &Text, ty_p3: &Text) -> Text {
    let mut out = String::new();
    out.push_str("/// A `");
    place(&mut out, tag_name_p2, None);
    out.push_str("`\'s answer.\npub fn ");
    place(&mut out, accessor_p0, None);
    out.push_str("(&self) -> Result<");
    place(&mut out, ty_p3, None);
    out.push_str(", Fault> {\n    match self {\n        Answer::");
    place(&mut out, variant_p1, None);
    out.push_str("(v) => Ok(v.clone()),\n        other => Err(Fault::answer(format!(\"an answer for {}, where ");
    place(&mut out, tag_name_p2, None);
    out.push_str("\'s was expected\", other.tag()))),\n    }\n}\n");
    Text::from(out)
}

/// ```prism
/// Answer: fn Text -> Text
/// ```
pub fn answer(arms_p0: &Text) -> Text {
    let mut out = String::new();
    out.push_str("fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {\n    match at {\n");
    place(&mut out, arms_p0, Some(8));
    out.push_str("        _ => return Err(Fault::answer(format!(\"no answering place at {}\", Path(at.to_vec())))),\n    }\n    Ok(())\n}\n");
    Text::from(out)
}

/// ```prism
/// Hook: fn Text, Text -> Text
/// ```
pub fn hook(name_p0: &Text, body_p1: &Text) -> Text {
    let mut out = String::new();
    out.push_str("fn ");
    place(&mut out, name_p0, None);
    out.push_str("(self: Rc<Self>, cx: &mut Cx) -> Done {\n");
    place(&mut out, body_p1, Some(4));
    out.push_str("    Ok(())\n}\n");
    Text::from(out)
}

/// ```prism
/// PushHook: fn Text -> Text
/// ```
pub fn push_hook(body_p0: &Text) -> Text {
    let mut out = String::new();
    out.push_str("fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {\n");
    place(&mut out, body_p0, Some(4));
    out.push_str("    Ok(())\n}\n");
    Text::from(out)
}

/// ```prism
/// Program: fn Text, Text, Text, Text, Text -> Text
/// ```
pub fn program(name_p0: &Text, prism_p1: &Text, node_p2: &Text, decode_p3: &Text, call_p4: &Text) -> Text {
    let mut out = String::new();
    out.push_str("/// The program of `@");
    place(&mut out, prism_p1, None);
    out.push_str("`: the root node and the runtime.\npub struct ");
    place(&mut out, name_p0, None);
    out.push_str(" {\n    rt: Runtime,\n    root: Rc<");
    place(&mut out, node_p2, None);
    out.push_str(">,\n}\n\nimpl Program for ");
    place(&mut out, name_p0, None);
    out.push_str(" {\n    fn build(args: &[Pod], ready: &dyn ReadyState) -> Result<(Self, TickOut), Fault> {\n");
    place(&mut out, decode_p3, Some(8));
    out.push_str("        let mut rt = Runtime::new();\n        let mut cx = rt.build(ready);\n        let root = ");
    place(&mut out, call_p4, None);
    out.push_str(";\n        let out = rt.close(cx)?;\n        Ok((");
    place(&mut out, name_p0, None);
    out.push_str(" { rt, root }, out))\n    }\n    fn tick(&mut self, input: &TickIn, ready: &dyn ReadyState) -> Result<TickOut, Fault> {\n        let root: Rc<dyn Node> = self.root.clone();\n        self.rt.tick(&root, input, ready)\n    }\n    fn compact(&mut self) {\n        self.rt.compact();\n    }\n}\n");
    Text::from(out)
}

/// ```prism
/// MatchBlock: fn Text, Text -> Text
/// ```
pub fn match_block(scrut_p0: &Text, arms_p1: &Text) -> Text {
    let mut out = String::new();
    out.push_str("match ");
    place(&mut out, scrut_p0, None);
    out.push_str(" {\n");
    place(&mut out, arms_p1, Some(4));
    out.push_str("}");
    Text::from(out)
}

/// ```prism
/// Block: fn Text, Text -> Text
/// ```
pub fn block(stmts_p0: &Text, tail_p1: &Text) -> Text {
    let mut out = String::new();
    out.push_str("{\n");
    place(&mut out, stmts_p0, Some(4));
    place(&mut out, tail_p1, Some(4));
    out.push_str("}");
    Text::from(out)
}

/// ```prism
/// Labeled: fn Text, Text, Text -> Text
/// ```
pub fn labeled(label_p0: &Text, stmts_p1: &Text, tail_p2: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, label_p0, None);
    out.push_str(": {\n");
    place(&mut out, stmts_p1, Some(4));
    place(&mut out, tail_p2, Some(4));
    out.push_str("}");
    Text::from(out)
}

/// ```prism
/// If: fn Text, Text, Text -> Text
/// ```
pub fn if_(cond_p0: &Text, then_x_p1: &Text, else_x_p2: &Text) -> Text {
    let mut out = String::new();
    out.push_str("if ");
    place(&mut out, cond_p0, None);
    out.push_str(" {\n");
    place(&mut out, then_x_p1, Some(4));
    out.push_str("} else {\n");
    place(&mut out, else_x_p2, Some(4));
    out.push_str("}");
    Text::from(out)
}

/// ```prism
/// IfStmt: fn Text, Text -> Text
/// ```
pub fn if_stmt(head_p0: &Text, body_p1: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, head_p0, None);
    out.push_str(" {\n");
    place(&mut out, body_p1, Some(4));
    out.push_str("}");
    Text::from(out)
}

/// ```prism
/// Scope: fn Text -> Text
/// ```
pub fn scope(body_p0: &Text) -> Text {
    let mut out = String::new();
    out.push_str("{\n");
    place(&mut out, body_p0, Some(4));
    out.push_str("}");
    Text::from(out)
}

/// ```prism
/// Else: fn Text -> Text
/// ```
pub fn else_(body_p0: &Text) -> Text {
    let mut out = String::new();
    out.push_str(" else {\n");
    place(&mut out, body_p0, Some(4));
    out.push_str("}");
    Text::from(out)
}

/// ```prism
/// ArmBlock: fn Text, Text -> Text
/// ```
pub fn arm_block(pat_p0: &Text, body_p1: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, pat_p0, None);
    out.push_str(" => {\n");
    place(&mut out, body_p1, Some(4));
    out.push_str("}");
    Text::from(out)
}

/// ```prism
/// ChainArm: fn Text, Text, Text -> Text
/// ```
pub fn chain_arm(head_p0: &Text, label_p1: &Text, body_p2: &Text) -> Text {
    let mut out = String::new();
    out.push_str("if ");
    place(&mut out, head_p0, None);
    out.push_str(" {\n    break ");
    place(&mut out, label_p1, None);
    out.push_str(" ");
    place(&mut out, body_p2, None);
    out.push_str(";\n}");
    Text::from(out)
}
