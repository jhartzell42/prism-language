//! The module `Emit.Rust.Templates.Items`, from `target/bootstrap/src/prismc/emit/rust/templates/items.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// Struct: fn Text, Text, Text, Text -> Text
/// ```
pub fn struct_f(doc_p0: &crate::prelude::Text, derives_p1: &crate::prelude::Text, head_p2: &crate::prelude::Text, fields_p3: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    crate::prelude::place(&mut out, doc_p0, ::std::option::Option::Some(0));
    out.push_str("#[derive(");
    crate::prelude::place(&mut out, derives_p1, ::std::option::Option::None);
    out.push_str(")]\npub struct ");
    crate::prelude::place(&mut out, head_p2, ::std::option::Option::None);
    out.push_str(" {\n");
    crate::prelude::place(&mut out, fields_p3, ::std::option::Option::Some(4));
    out.push_str("}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// Enum: fn Text, Text, Text, Text -> Text
/// ```
pub fn enum_f(doc_p0: &crate::prelude::Text, derives_p1: &crate::prelude::Text, head_p2: &crate::prelude::Text, cases_p3: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    crate::prelude::place(&mut out, doc_p0, ::std::option::Option::Some(0));
    out.push_str("#[derive(");
    crate::prelude::place(&mut out, derives_p1, ::std::option::Option::None);
    out.push_str(")]\npub enum ");
    crate::prelude::place(&mut out, head_p2, ::std::option::Option::None);
    out.push_str(" {\n");
    crate::prelude::place(&mut out, cases_p3, ::std::option::Option::Some(4));
    out.push_str("}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// TupleStruct: fn Text, Text, Text, Text -> Text
/// ```
pub fn tuple_struct_f(doc_p0: &crate::prelude::Text, derives_p1: &crate::prelude::Text, head_p2: &crate::prelude::Text, fields_p3: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    crate::prelude::place(&mut out, doc_p0, ::std::option::Option::Some(0));
    out.push_str("#[derive(");
    crate::prelude::place(&mut out, derives_p1, ::std::option::Option::None);
    out.push_str(")]\npub struct ");
    crate::prelude::place(&mut out, head_p2, ::std::option::Option::None);
    crate::prelude::place(&mut out, fields_p3, ::std::option::Option::None);
    out.push_str(";\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// Impl: fn Text, Text, Text, Text, Text -> Text
/// ```
pub fn impl_f(generics_p0: &crate::prelude::Text, tr_p1: &crate::prelude::Text, ty_p2: &crate::prelude::Text, signature_p3: &crate::prelude::Text, body_p4: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("impl");
    crate::prelude::place(&mut out, generics_p0, ::std::option::Option::None);
    out.push_str(" ");
    crate::prelude::place(&mut out, tr_p1, ::std::option::Option::None);
    out.push_str(" for ");
    crate::prelude::place(&mut out, ty_p2, ::std::option::Option::None);
    out.push_str(" {\n    ");
    crate::prelude::place(&mut out, signature_p3, ::std::option::Option::None);
    out.push_str(" {\n");
    crate::prelude::place(&mut out, body_p4, ::std::option::Option::Some(8));
    out.push_str("    }\n}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// MatchSelf: fn Text -> Text
/// ```
pub fn match_self_f(arms_p0: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("match self {\n");
    crate::prelude::place(&mut out, arms_p0, ::std::option::Option::Some(4));
    out.push_str("}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// ShownPod: fn Text -> Text
/// ```
pub fn shown_pod_f(structure_p0: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("let structure = {\n");
    crate::prelude::place(&mut out, structure_p0, ::std::option::Option::Some(4));
    out.push_str("};\ncrate::prelude::Pod::Shown(crate::prelude::show(self).as_str().into(), ::std::boxed::Box::new(structure))\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// FromPodBody: fn Text, Text -> Text
/// ```
pub fn from_pod_body_f(arms_p0: &crate::prelude::Text, want_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("match p.structure() {\n");
    crate::prelude::place(&mut out, arms_p0, ::std::option::Option::Some(4));
    out.push_str("    other => ::prism_rtl::pod::mismatch(\"");
    crate::prelude::place(&mut out, want_p1, ::std::option::Option::None);
    out.push_str("\", other),\n}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// Tag: fn Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn tag_f(doc_p0: &crate::prelude::Text, derives_p1: &crate::prelude::Text, name_p2: &crate::prelude::Text, fields_p3: &crate::prelude::Text, tag_name_p4: &crate::prelude::Text, pods_p5: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    crate::prelude::place(&mut out, doc_p0, ::std::option::Option::Some(0));
    out.push_str("#[derive(");
    crate::prelude::place(&mut out, derives_p1, ::std::option::Option::None);
    out.push_str(")]\npub struct ");
    crate::prelude::place(&mut out, name_p2, ::std::option::Option::None);
    out.push_str(" {\n");
    crate::prelude::place(&mut out, fields_p3, ::std::option::Option::Some(4));
    out.push_str("}\n\nimpl ");
    crate::prelude::place(&mut out, name_p2, ::std::option::Option::None);
    out.push_str(" {\n    /// The tag\'s qualified name, as its `Pod` carries it.\n    pub const TAG: &\'static str = \"");
    crate::prelude::place(&mut out, tag_name_p4, ::std::option::Option::None);
    out.push_str("\";\n}\n\nimpl crate::prelude::ToPod for ");
    crate::prelude::place(&mut out, name_p2, ::std::option::Option::None);
    out.push_str(" {\n    fn to_pod(&self) -> crate::prelude::Pod {\n        crate::prelude::Pod::element(\"");
    crate::prelude::place(&mut out, tag_name_p4, ::std::option::Option::None);
    out.push_str("\", vec![");
    crate::prelude::place(&mut out, pods_p5, ::std::option::Option::None);
    out.push_str("])\n    }\n}\n\nimpl crate::prelude::Show for ");
    crate::prelude::place(&mut out, name_p2, ::std::option::Option::None);
    out.push_str(" {\n    fn show(&self, p: &mut crate::prelude::Printer) {\n        self.to_pod().show(p);\n    }\n}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// TagLevel: fn Text, Text, Text, Text -> Text
/// ```
pub fn tag_level_f(name_p0: &crate::prelude::Text, tag_name_p1: &crate::prelude::Text, pods_p2: &crate::prelude::Text, ports_p3: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("impl ");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str(" {\n    /// The level as a World reads it: each dynamic it holds sampled at the read point.\n    pub fn level_pod(&self, cx: &crate::prelude::Cx) -> crate::prelude::Pod {\n        crate::prelude::Pod::element(\"");
    crate::prelude::place(&mut out, tag_name_p1, ::std::option::Option::None);
    out.push_str("\", vec![");
    crate::prelude::place(&mut out, pods_p2, ::std::option::Option::None);
    out.push_str("])\n    }\n    /// The update events of the dynamics it holds, and of theirs.\n    pub fn level_ports(&self, cx: &crate::prelude::Cx, out: &mut ::std::vec::Vec<::std::rc::Rc<crate::prelude::Port<()>>>) {\n        let _ = (cx, &out);");
    crate::prelude::place(&mut out, ports_p3, ::std::option::Option::None);
    out.push_str("\n    }\n}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// RowLevel: fn Text, Text, Text -> Text
/// ```
pub fn row_level_f(name_p0: &crate::prelude::Text, pods_p1: &crate::prelude::Text, ports_p2: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("impl ::prism_rtl::Level for ");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str(" {\n    fn level_pod(&self, cx: &crate::prelude::Cx) -> crate::prelude::Pod {\n        let _ = cx;\n        match self {\n            ");
    crate::prelude::place(&mut out, pods_p1, ::std::option::Option::None);
    out.push_str("_ => self.to_pod(),\n        }\n    }\n    fn level_ports(&self, cx: &crate::prelude::Cx, out: &mut ::std::vec::Vec<::std::rc::Rc<crate::prelude::Port<()>>>) {\n        let _ = (cx, &out);\n        match self {\n            ");
    crate::prelude::place(&mut out, ports_p2, ::std::option::Option::None);
    out.push_str("_ => {}\n        }\n    }\n}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// TagFromPod: fn Text, Text, Text -> Text
/// ```
pub fn tag_from_pod_f(name_p0: &crate::prelude::Text, tag_name_p1: &crate::prelude::Text, reads_p2: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("impl crate::prelude::FromPod for ");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str(" {\n    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {\n        match p.tag() {\n            ::std::option::Option::Some(\"");
    crate::prelude::place(&mut out, tag_name_p1, ::std::option::Option::None);
    out.push_str("\") => ::std::result::Result::Ok(");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str(" { ");
    crate::prelude::place(&mut out, reads_p2, ::std::option::Option::None);
    out.push_str(" }),\n            _ => ::prism_rtl::pod::mismatch(\"a ");
    crate::prelude::place(&mut out, tag_name_p1, ::std::option::Option::None);
    out.push_str("\", p),\n        }\n    }\n}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// Row: fn Text, Text, Text, Text, Text -> Text
/// ```
pub fn row_f(doc_p0: &crate::prelude::Text, derives_p1: &crate::prelude::Text, name_p2: &crate::prelude::Text, cases_p3: &crate::prelude::Text, pods_p4: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    crate::prelude::place(&mut out, doc_p0, ::std::option::Option::Some(0));
    out.push_str("#[derive(");
    crate::prelude::place(&mut out, derives_p1, ::std::option::Option::None);
    out.push_str(")]\npub enum ");
    crate::prelude::place(&mut out, name_p2, ::std::option::Option::None);
    out.push_str(" {\n");
    crate::prelude::place(&mut out, cases_p3, ::std::option::Option::Some(4));
    out.push_str("}\n\nimpl crate::prelude::ToPod for ");
    crate::prelude::place(&mut out, name_p2, ::std::option::Option::None);
    out.push_str(" {\n    fn to_pod(&self) -> crate::prelude::Pod {\n        match self {\n");
    crate::prelude::place(&mut out, pods_p4, ::std::option::Option::Some(12));
    out.push_str("        }\n    }\n}\n\nimpl crate::prelude::Show for ");
    crate::prelude::place(&mut out, name_p2, ::std::option::Option::None);
    out.push_str(" {\n    fn show(&self, p: &mut crate::prelude::Printer) {\n        self.to_pod().show(p);\n    }\n}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// RowFromPod: fn Text, Text -> Text
/// ```
pub fn row_from_pod_f(name_p0: &crate::prelude::Text, reads_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("impl crate::prelude::FromPod for ");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str(" {\n    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {\n        match p.tag() {\n");
    crate::prelude::place(&mut out, reads_p1, ::std::option::Option::Some(12));
    out.push_str("            _ => ::prism_rtl::pod::mismatch(\"a ");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str("\", p),\n        }\n    }\n}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// Fn: fn Text, Text, Text -> Text
/// ```
pub fn fn_f(doc_p0: &crate::prelude::Text, signature_p1: &crate::prelude::Text, body_p2: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    crate::prelude::place(&mut out, doc_p0, ::std::option::Option::Some(0));
    crate::prelude::place(&mut out, signature_p1, ::std::option::Option::None);
    out.push_str(" {\n");
    crate::prelude::place(&mut out, body_p2, ::std::option::Option::Some(4));
    out.push_str("}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// Job: fn Text, Text, Text, Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn job_f(doc_p0: &crate::prelude::Text, head_p1: &crate::prelude::Text, generics_p2: &crate::prelude::Text, bounded_p3: &crate::prelude::Text, fields_p4: &crate::prelude::Text, ret_p5: &crate::prelude::Text, body_p6: &crate::prelude::Text, start_p7: &crate::prelude::Text, start_body_p8: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("/// The step machine of `");
    crate::prelude::place(&mut out, head_p1, ::std::option::Option::None);
    out.push_str("`, stopped at a cycle point: the call about to be\n/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the\n/// callee\'s job, so the job\'s stack is its frames.\n///\n");
    crate::prelude::place(&mut out, doc_p0, ::std::option::Option::Some(0));
    out.push_str("pub struct ");
    crate::prelude::place(&mut out, head_p1, ::std::option::Option::None);
    crate::prelude::place(&mut out, generics_p2, ::std::option::Option::None);
    out.push_str(" {\n");
    crate::prelude::place(&mut out, fields_p4, ::std::option::Option::Some(4));
    out.push_str("}\n\nimpl");
    crate::prelude::place(&mut out, bounded_p3, ::std::option::Option::None);
    out.push_str(" ::prism_rtl::Job<");
    crate::prelude::place(&mut out, ret_p5, ::std::option::Option::None);
    out.push_str("> for ");
    crate::prelude::place(&mut out, head_p1, ::std::option::Option::None);
    crate::prelude::place(&mut out, generics_p2, ::std::option::Option::None);
    out.push_str(" {\n    fn cycle(&self) -> ::prism_rtl::Turn<");
    crate::prelude::place(&mut out, ret_p5, ::std::option::Option::None);
    out.push_str("> {\n");
    crate::prelude::place(&mut out, body_p6, ::std::option::Option::Some(8));
    out.push_str("    }\n}\n\n/// `Start ");
    crate::prelude::place(&mut out, head_p1, ::std::option::Option::None);
    out.push_str(", x`: what the function value is when passed to `@Run`.\n");
    crate::prelude::place(&mut out, start_p7, ::std::option::Option::None);
    out.push_str(" {\n");
    crate::prelude::place(&mut out, start_body_p8, ::std::option::Option::Some(4));
    out.push_str("}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// Node: fn Text, Text, Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn node_f(doc_p0: &crate::prelude::Text, name_p1: &crate::prelude::Text, fields_p2: &crate::prelude::Text, consts_p3: &crate::prelude::Text, build_p4: &crate::prelude::Text, methods_p5: &crate::prelude::Text, hooks_p6: &crate::prelude::Text, answer_p7: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    crate::prelude::place(&mut out, doc_p0, ::std::option::Option::Some(0));
    out.push_str("pub struct ");
    crate::prelude::place(&mut out, name_p1, ::std::option::Option::None);
    out.push_str(" {\n    path: crate::prelude::Path,\n");
    crate::prelude::place(&mut out, fields_p2, ::std::option::Option::Some(4));
    out.push_str("}\n\nimpl ");
    crate::prelude::place(&mut out, name_p1, ::std::option::Option::None);
    out.push_str(" {\n");
    crate::prelude::place(&mut out, consts_p3, ::std::option::Option::Some(4));
    crate::prelude::place(&mut out, build_p4, ::std::option::Option::Some(4));
    crate::prelude::place(&mut out, methods_p5, ::std::option::Option::Some(4));
    out.push_str("}\n\nimpl crate::prelude::Node for ");
    crate::prelude::place(&mut out, name_p1, ::std::option::Option::None);
    out.push_str(" {\n");
    crate::prelude::place(&mut out, answer_p7, ::std::option::Option::Some(4));
    crate::prelude::place(&mut out, hooks_p6, ::std::option::Option::Some(4));
    out.push_str("}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// Build: fn Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn build_f(name_p0: &crate::prelude::Text, params_p1: &crate::prelude::Text, ret_p2: &crate::prelude::Text, lets_p3: &crate::prelude::Text, inits_p4: &crate::prelude::Text, rest_p5: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("/// Built after propagation: holds take their initial values, places go out with\n/// `cx.added`, and nothing fires.\npub fn build(path: crate::prelude::Path, ");
    crate::prelude::place(&mut out, params_p1, ::std::option::Option::None);
    out.push_str("cx: &mut crate::prelude::Cx) -> ");
    crate::prelude::place(&mut out, ret_p2, ::std::option::Option::None);
    out.push_str(" {\n");
    crate::prelude::place(&mut out, lets_p3, ::std::option::Option::Some(4));
    out.push_str("    let node = ::std::rc::Rc::new(");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str(" { ");
    crate::prelude::place(&mut out, inits_p4, ::std::option::Option::None);
    out.push_str(" });\n");
    crate::prelude::place(&mut out, rest_p5, ::std::option::Option::Some(4));
    out.push_str("}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// Method: fn Text, Text, Text -> Text
/// ```
pub fn method_f(doc_p0: &crate::prelude::Text, signature_p1: &crate::prelude::Text, body_p2: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    crate::prelude::place(&mut out, doc_p0, ::std::option::Option::Some(0));
    crate::prelude::place(&mut out, signature_p1, ::std::option::Option::None);
    out.push_str(" {\n");
    crate::prelude::place(&mut out, body_p2, ::std::option::Option::Some(4));
    out.push_str("}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// ForBuild: fn Text, Text, Text, Text, Text, Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn for_build_f(name_p0: &crate::prelude::Text, at_p1: &crate::prelude::Text, key_ty_p2: &crate::prelude::Text, value_ty_p3: &crate::prelude::Text, row_node_p4: &crate::prelude::Text, source_p5: &crate::prelude::Text, parent_p6: &crate::prelude::Text, passed_p7: &crate::prelude::Text, moved_p8: &crate::prelude::Text, from_p9: &crate::prelude::Text, replaced_pa: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("/// The rows of the `for` at `");
    crate::prelude::place(&mut out, at_p1, ::std::option::Option::None);
    out.push_str("`: rows whose key left are torn down, new keys are\n/// built under it at `[k]` from the values after the tick; kept rows keep reading their\n/// entry out of the source. Nothing to do when the source is the map last built from.\nfn ");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str("_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {\n    let items: crate::prelude::Map<");
    crate::prelude::place(&mut out, key_ty_p2, ::std::option::Option::None);
    out.push_str(", ");
    crate::prelude::place(&mut out, value_ty_p3, ::std::option::Option::None);
    out.push_str("> = self.");
    crate::prelude::place(&mut out, source_p5, ::std::option::Option::None);
    out.push_str("(cx);\n    if self.");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str("_from.borrow().same(&items) {\n        return ::std::result::Result::Ok(());\n    }\n");
    crate::prelude::place(&mut out, from_p9, ::std::option::Option::Some(4));
    out.push_str("    let old = self.");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str(".borrow().clone();\n    // the kept rows stay where they are: only the keys that left or came are touched\n    let mut next = old.clone();\n    for (k, row) in old.iter() {\n        if !items.contains_key(k) {\n            row.leave_row(cx);\n            cx.leave_later(row.clone());\n            next.remove(k);\n        }");
    crate::prelude::place(&mut out, replaced_pa, ::std::option::Option::None);
    out.push_str("\n    }\n    for (k, v) in items.iter() {\n        if !old.contains_key(k) {\n            let row = ");
    crate::prelude::place(&mut out, row_node_p4, ::std::option::Option::None);
    out.push_str("::build(");
    crate::prelude::place(&mut out, at_p1, ::std::option::Option::None);
    out.push_str(".child(crate::prelude::Segment::Key(k.to_pod())), k.clone(), v.clone(), ");
    crate::prelude::place(&mut out, parent_p6, ::std::option::Option::None);
    crate::prelude::place(&mut out, passed_p7, ::std::option::Option::None);
    out.push_str(", cx)?;\n            next.insert(k.clone(), row);\n        }\n    }\n    *self.");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str(".borrow_mut() = next;\n    // What the block reads of its rows (a `for` that gives a dynamic) moved.\n    cx.dirty(self.clone());");
    crate::prelude::place(&mut out, moved_p8, ::std::option::Option::None);
    out.push_str("\n    ::std::result::Result::Ok(())\n}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// GenBuild: fn Text, Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn gen_build_f(name_p0: &crate::prelude::Text, at_p1: &crate::prelude::Text, path_p2: &crate::prelude::Text, source_p3: &crate::prelude::Text, value_ty_p4: &crate::prelude::Text, select_p5: &crate::prelude::Text, moved_p6: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("/// The `rebuild` at `");
    crate::prelude::place(&mut out, at_p1, ::std::option::Option::None);
    out.push_str("`: the old generation torn down (it ran to the end of the\n/// tick), the next built at `");
    crate::prelude::place(&mut out, path_p2, ::std::option::Option::None);
    out.push_str("` from the source after the tick.\nfn ");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str("_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {\n    if let ::std::option::Option::Some(old) = self.");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str(".borrow_mut().take() {\n        old.leave_row(cx);\n        cx.leave_later(old);\n    }\n    let g = self.");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str("_count.get();\n    self.");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str("_count.set(g + 1);\n    let path = ");
    crate::prelude::place(&mut out, path_p2, ::std::option::Option::None);
    out.push_str(";\n    let value: ");
    crate::prelude::place(&mut out, value_ty_p4, ::std::option::Option::None);
    out.push_str(" = ");
    crate::prelude::place(&mut out, source_p3, ::std::option::Option::None);
    out.push_str(";\n    let row: ::std::rc::Rc<dyn crate::prelude::Row> = ");
    crate::prelude::place(&mut out, select_p5, ::std::option::Option::None);
    out.push_str(";\n    *self.");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str(".borrow_mut() = ::std::option::Option::Some(row);");
    crate::prelude::place(&mut out, moved_p6, ::std::option::Option::None);
    out.push_str("\n    ::std::result::Result::Ok(())\n}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// RowImpl: fn Text, Text, Text -> Text
/// ```
pub fn row_impl_f(name_p0: &crate::prelude::Text, leaving_p1: &crate::prelude::Text, hosted_p2: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("impl crate::prelude::Row for ");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str(" {\n    fn leave_row(&self, cx: &mut crate::prelude::Cx) {\n");
    crate::prelude::place(&mut out, leaving_p1, ::std::option::Option::Some(8));
    out.push_str("    }\n");
    crate::prelude::place(&mut out, hosted_p2, ::std::option::Option::Some(4));
    out.push_str("}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// AnswerType: fn Text, Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn answer_type_f(cases_p0: &crate::prelude::Text, tags_p1: &crate::prelude::Text, accessors_p2: &crate::prelude::Text, decodes_p3: &crate::prelude::Text, firsts_p4: &crate::prelude::Text, helds_p5: &crate::prelude::Text, untagged_p6: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("/// `Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host\'s\n/// supplier answers a child place with, and what a World\'s answer to a forwarded element\n/// decodes to, carrying the tag\'s output.\n#[derive(Clone)]\npub enum Answer {\n");
    crate::prelude::place(&mut out, cases_p0, ::std::option::Option::Some(4));
    out.push_str("}\n\nimpl Answer {\n    /// The tag the answer is for.\n    pub fn tag(&self) -> &\'static str {\n        match self {\n");
    crate::prelude::place(&mut out, tags_p1, ::std::option::Option::Some(12));
    out.push_str("        }\n    }\n");
    crate::prelude::place(&mut out, accessors_p2, ::std::option::Option::Some(4));
    out.push_str("    /// The answer as one made outside a tag\'s arm, where it is plain data: what a place\n    /// of another tag reads at its own type (an element of the host\'s own making given\n    /// under a tag\'s arm, `@Element (Prelude.Unwrap(..))`). Any other answer is itself.\n    pub fn untagged(&self) -> Answer {\n        match self {\n");
    crate::prelude::place(&mut out, untagged_p6, ::std::option::Option::Some(12));
    out.push_str("            other => other.clone(),\n        }\n    }\n    /// An answer made outside a tag\'s arm, read at the type of the line that binds it (a\n    /// blueprint value\'s plain result).\n    pub fn plain<T: crate::prelude::FromPod>(&self) -> ::std::result::Result<T, crate::prelude::Fault> {\n        match self {\n            Answer::Untagged_a(p) => crate::prelude::FromPod::from_pod(p),\n            other => ::std::result::Result::Err(crate::prelude::Fault::answer(format!(\"an answer for {}, where a blueprint value\'s plain result was expected\", other.tag()))),\n        }\n    }\n    /// An answer made outside a tag\'s arm that is no plain data (a function, a dynamic, a\n    /// bundle with its events and dynamics whole), when it is one and holds a `T`.\n    pub fn held_as<T: Clone + \'static>(&self) -> ::std::option::Option<T> {\n        match self {\n            Answer::Held_a(v) => v.downcast_ref::<T>().cloned(),\n            _ => ::std::option::Option::None,\n        }\n    }\n    /// The same, read at the type of the line that binds it: any other answer is a fault.\n    pub fn held<T: Clone + \'static>(&self) -> ::std::result::Result<T, crate::prelude::Fault> {\n        self.held_as::<T>().ok_or_else(|| crate::prelude::Fault::answer(format!(\"an answer for {}, where a blueprint value\'s result that is no plain data was expected\", self.tag())))\n    }\n}\n\nimpl ::prism_rtl::AnswerOf<Elem> for Answer {\n    /// A World\'s answer to the element `e`, decoded by its tag.\n    fn decode(e: &Elem, v: &crate::prelude::Pod) -> ::std::result::Result<Answer, crate::prelude::Fault> {\n        match e {\n");
    crate::prelude::place(&mut out, decodes_p3, ::std::option::Option::Some(12));
    out.push_str("        }\n    }\n    /// A World\'s first value for the element `e`: a bundle\'s plain parts, any other tag\'s\n    /// answer.\n    fn decode_first(e: &Elem, v: &crate::prelude::Pod) -> ::std::result::Result<Answer, crate::prelude::Fault> {\n        match e {\n");
    crate::prelude::place(&mut out, firsts_p4, ::std::option::Option::Some(12));
    out.push_str("        }\n    }\n    /// An answer held whole (a bundle with a part that is no plain data, made outside a\n    /// tag\'s arm) as the parts the tag of `e` takes.\n    fn held_parts(e: &Elem, answer: &Answer) -> ::std::option::Option<::prism_rtl::PartsAnswer<Answer>> {\n        match e {\n");
    crate::prelude::place(&mut out, helds_p5, ::std::option::Option::Some(12));
    out.push_str("        }\n    }\n}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// AnswerGetter: fn Text, Text, Text, Text, Text -> Text
/// ```
pub fn answer_getter_f(accessor_p0: &crate::prelude::Text, variant_p1: &crate::prelude::Text, tag_name_p2: &crate::prelude::Text, ty_p3: &crate::prelude::Text, outside_p4: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("/// A `");
    crate::prelude::place(&mut out, tag_name_p2, ::std::option::Option::None);
    out.push_str("`\'s answer.\npub fn ");
    crate::prelude::place(&mut out, accessor_p0, ::std::option::Option::None);
    out.push_str("(&self) -> ::std::result::Result<");
    crate::prelude::place(&mut out, ty_p3, ::std::option::Option::None);
    out.push_str(", crate::prelude::Fault> {\n    match self {\n        Answer::");
    crate::prelude::place(&mut out, variant_p1, ::std::option::Option::None);
    out.push_str("(v) => ::std::result::Result::Ok(v.clone()),\n");
    crate::prelude::place(&mut out, outside_p4, ::std::option::Option::Some(8));
    out.push_str("        other => ::std::result::Result::Err(crate::prelude::Fault::answer(format!(\"an answer for {}, where ");
    crate::prelude::place(&mut out, tag_name_p2, ::std::option::Option::None);
    out.push_str("\'s was expected\", other.tag()))),\n    }\n}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// Answer: fn Text, Text -> Text
/// ```
pub fn answer_f(seating_p0: &crate::prelude::Text, arms_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {\n");
    crate::prelude::place(&mut out, seating_p0, ::std::option::Option::Some(4));
    out.push_str("    match at {\n");
    crate::prelude::place(&mut out, arms_p1, ::std::option::Option::Some(8));
    out.push_str("        _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!(\"no answering place at {}\", crate::prelude::Path(at.to_vec())))),\n    }\n    ::std::result::Result::Ok(())\n}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// Hook: fn Text, Text -> Text
/// ```
pub fn hook_f(name_p0: &crate::prelude::Text, body_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("fn ");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str("(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {\n");
    crate::prelude::place(&mut out, body_p1, ::std::option::Option::Some(4));
    out.push_str("    ::std::result::Result::Ok(())\n}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// PushHook: fn Text -> Text
/// ```
pub fn push_hook_f(body_p0: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("fn push(self: ::std::rc::Rc<Self>, element: &crate::prelude::Pod, v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {\n");
    crate::prelude::place(&mut out, body_p0, ::std::option::Option::Some(4));
    out.push_str("    ::std::result::Result::Ok(())\n}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// Program: fn Text, Text, Text, Text, Text -> Text
/// ```
pub fn program_f(name_p0: &crate::prelude::Text, prism_p1: &crate::prelude::Text, node_p2: &crate::prelude::Text, decode_p3: &crate::prelude::Text, call_p4: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("/// The program of `@");
    crate::prelude::place(&mut out, prism_p1, ::std::option::Option::None);
    out.push_str("`: the root node and the runtime.\npub struct ");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str(" {\n    rt: crate::prelude::Runtime,\n    root: ::std::rc::Rc<");
    crate::prelude::place(&mut out, node_p2, ::std::option::Option::None);
    out.push_str(">,\n}\n\nimpl crate::prelude::Program for ");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str(" {\n    fn build(args: &[crate::prelude::Pod], ready: &dyn crate::prelude::ReadyState) -> ::std::result::Result<(Self, crate::prelude::TickOut), crate::prelude::Fault> {\n");
    crate::prelude::place(&mut out, decode_p3, ::std::option::Option::Some(8));
    out.push_str("        let mut rt = crate::prelude::Runtime::new();\n        let mut cx = rt.build(ready);\n        let root = ");
    crate::prelude::place(&mut out, call_p4, ::std::option::Option::None);
    out.push_str(";\n        let out = rt.close(cx)?;\n        ::std::result::Result::Ok((");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str(" { rt, root }, out))\n    }\n    fn tick(&mut self, input: &crate::prelude::TickIn, ready: &dyn crate::prelude::ReadyState) -> ::std::result::Result<crate::prelude::TickOut, crate::prelude::Fault> {\n        let root: ::std::rc::Rc<dyn crate::prelude::Node> = self.root.clone();\n        self.rt.tick(&root, input, ready)\n    }\n    fn compact(&mut self) {\n        self.rt.compact();\n    }\n}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// MatchBlock: fn Text, Text -> Text
/// ```
pub fn match_block_f(scrut_p0: &crate::prelude::Text, arms_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("match ");
    crate::prelude::place(&mut out, scrut_p0, ::std::option::Option::None);
    out.push_str(" {\n");
    crate::prelude::place(&mut out, arms_p1, ::std::option::Option::Some(4));
    out.push_str("}");
    crate::prelude::Text::from(out)
}

/// ```prism
/// Block: fn Text, Text -> Text
/// ```
pub fn block_f(stmts_p0: &crate::prelude::Text, tail_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("{\n");
    crate::prelude::place(&mut out, stmts_p0, ::std::option::Option::Some(4));
    crate::prelude::place(&mut out, tail_p1, ::std::option::Option::Some(4));
    out.push_str("}");
    crate::prelude::Text::from(out)
}

/// ```prism
/// Labeled: fn Text, Text, Text -> Text
/// ```
pub fn labeled_f(label_p0: &crate::prelude::Text, stmts_p1: &crate::prelude::Text, tail_p2: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    crate::prelude::place(&mut out, label_p0, ::std::option::Option::None);
    out.push_str(": {\n");
    crate::prelude::place(&mut out, stmts_p1, ::std::option::Option::Some(4));
    crate::prelude::place(&mut out, tail_p2, ::std::option::Option::Some(4));
    out.push_str("}");
    crate::prelude::Text::from(out)
}

/// ```prism
/// If: fn Text, Text, Text -> Text
/// ```
pub fn if_f(cond_p0: &crate::prelude::Text, then_x_p1: &crate::prelude::Text, else_x_p2: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("if ");
    crate::prelude::place(&mut out, cond_p0, ::std::option::Option::None);
    out.push_str(" {\n");
    crate::prelude::place(&mut out, then_x_p1, ::std::option::Option::Some(4));
    out.push_str("} else {\n");
    crate::prelude::place(&mut out, else_x_p2, ::std::option::Option::Some(4));
    out.push_str("}");
    crate::prelude::Text::from(out)
}

/// ```prism
/// IfStmt: fn Text, Text -> Text
/// ```
pub fn if_stmt_f(head_p0: &crate::prelude::Text, body_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    crate::prelude::place(&mut out, head_p0, ::std::option::Option::None);
    out.push_str(" {\n");
    crate::prelude::place(&mut out, body_p1, ::std::option::Option::Some(4));
    out.push_str("}");
    crate::prelude::Text::from(out)
}

/// ```prism
/// Scope: fn Text -> Text
/// ```
pub fn scope_f(body_p0: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("{\n");
    crate::prelude::place(&mut out, body_p0, ::std::option::Option::Some(4));
    out.push_str("}");
    crate::prelude::Text::from(out)
}

/// ```prism
/// Else: fn Text -> Text
/// ```
pub fn else_f(body_p0: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str(" else {\n");
    crate::prelude::place(&mut out, body_p0, ::std::option::Option::Some(4));
    out.push_str("}");
    crate::prelude::Text::from(out)
}

/// ```prism
/// ArmBlock: fn Text, Text -> Text
/// ```
pub fn arm_block_f(pat_p0: &crate::prelude::Text, body_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    crate::prelude::place(&mut out, pat_p0, ::std::option::Option::None);
    out.push_str(" => {\n");
    crate::prelude::place(&mut out, body_p1, ::std::option::Option::Some(4));
    out.push_str("}");
    crate::prelude::Text::from(out)
}

/// ```prism
/// ChainArm: fn Text, Text, Text -> Text
/// ```
pub fn chain_arm_f(head_p0: &crate::prelude::Text, label_p1: &crate::prelude::Text, body_p2: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("if ");
    crate::prelude::place(&mut out, head_p0, ::std::option::Option::None);
    out.push_str(" {\n    break ");
    crate::prelude::place(&mut out, label_p1, ::std::option::Option::None);
    out.push_str(" ");
    crate::prelude::place(&mut out, body_p2, ::std::option::Option::None);
    out.push_str(";\n}");
    crate::prelude::Text::from(out)
}
