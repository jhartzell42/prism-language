//! The module `Emit.Rust.Templates`, from `target/bootstrap/src/prismc/emit/rust/templates/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod items;

/// ```prism
/// Doc: fn Text -> Text
/// ```
pub fn doc(text_: &Text) -> Text {
    if text_ == &Text::lit("") {
        Text::lit("")
    } else {
        concat(&each(&split(text_, &Text::lit("\n")), &(|l: &Text| if l == &Text::lit("") {
            Text::lit("///\n")
        } else {
            Text::from(format!("/// {}\n", l))
        })))
    }
}

/// ```prism
/// SourceDoc: fn Text, Text -> Text
/// ```
pub fn source_doc(lead: &Text, source: &Text) -> Text {
    if lead == &Text::lit("") { source_only(source) } else { source_led(lead, source) }
}

/// ```prism
/// SourceOnly: fn Text -> Text
/// ```
pub fn source_only(source: &Text) -> Text {
    let mut out = String::new();
    out.push_str("/// ```prism\n");
    place(&mut out, &quoted(source), None);
    out.push_str("\n/// ```\n");
    Text::from(out)
}

/// ```prism
/// SourceLed: fn Text, Text -> Text
/// ```
pub fn source_led(lead: &Text, source: &Text) -> Text {
    let mut out = String::new();
    out.push_str("/// ");
    place(&mut out, lead, None);
    out.push_str("\n///\n/// ```prism\n");
    place(&mut out, &quoted(source), None);
    out.push_str("\n/// ```\n");
    Text::from(out)
}

/// ```prism
/// Quoted: fn Text -> Text
/// ```
pub fn quoted(text_: &Text) -> Text {
    joined(&each(&split(text_, &Text::lit("\n")), &(|l: &Text| if l == &Text::lit("") { Text::lit("///") } else { Text::from(format!("/// {}", l)) })), &Text::lit("\n"))
}

/// ```prism
/// Joined: fn [Text], Text -> Text
/// ```
pub fn joined(xs: &Array<Text>, sep: &Text) -> Text {
    match index(xs, &Nat::from(0u32)) {
        Some(first_) => concat(&fold(&drop(xs, &Nat::from(1u32)), &Array::from(vec![first_.clone()]), &(|acc: &Array<Text>, x: &Text| push(&push(acc, sep), x)))),
        None => Text::lit(""),
    }
}

/// ```prism
/// Module: fn Text, Text, Text, Text -> Text
/// ```
pub fn module(prism: &Text, path_: &Text, uses: &Text, items: &Text) -> Text {
    let mut out = String::new();
    out.push_str("//! ");
    place(&mut out, prism, None);
    out.push_str(", from `");
    place(&mut out, path_, None);
    out.push_str("`, emitted by prismc: one Rust type per Prism type, a node\n//! per root widget (claude/backend.md). Edit the Prism source, not this file.\n\nuse std::cell::{Cell, RefCell};\nuse std::rc::{Rc, Weak};\n\nuse prism_rtl::*;\nuse prism_rtl::pod::mismatch;\n\nuse crate::prelude::*;\n");
    place(&mut out, uses, Some(0));
    out.push_str("\n");
    place(&mut out, items, Some(0));
    Text::from(out)
}

/// ```prism
/// Cargo: fn Text, Text, Text -> Text
/// ```
pub fn cargo(name: &Text, runtime: &Text, defaults: &Text) -> Text {
    let mut out = String::new();
    out.push_str("# Emitted by prismc. Edit the Prism sources, not this file.\n[package]\nname = \"");
    place(&mut out, name, None);
    out.push_str("\"\nversion = \"0.1.0\"\nedition = \"2024\"\n\n[workspace]\n\n[[bin]]\nname = \"");
    place(&mut out, name, None);
    out.push_str("\"\npath = \"src/main.rs\"\n\n[dependencies]\nprism_rtl = { path = \"");
    place(&mut out, runtime, None);
    out.push_str("/runtime/rust\" }\nprism_world_cli = { path = \"");
    place(&mut out, runtime, None);
    out.push_str("/worlds/cli/rust\" }\nprism_world_canvas_rtl = { path = \"");
    place(&mut out, runtime, None);
    out.push_str("/worlds/canvas/rust\", optional = true }\n\n[features]\ndefault = [");
    place(&mut out, defaults, None);
    out.push_str("]\ncanvas = [\"prism_world_canvas_rtl\"]\n");
    Text::from(out)
}

/// ```prism
/// Main: fn Text, Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn main(name: &Text, mods: &Text, programs: &Text, registrations: &Text, scripts: &Text, run_root_: &Text, world: &Text) -> Text {
    let mut out = String::new();
    out.push_str("//! The program `");
    place(&mut out, name, None);
    out.push_str("`, emitted by prismc from Prism (claude/backend.md): a crate over\n//! `prism_rtl`, run under the CLI World, the canvas World or the Test World. Edit the\n//! Prism sources, not these files.\n#![allow(dead_code, unused_variables, unused_imports, unused_mut, unused_parens, unused_braces)]\n#![allow(unreachable_patterns, unreachable_code, unused_labels, non_snake_case, non_camel_case_types)]\n#![allow(clippy::all)]\n\n");
    place(&mut out, mods, Some(0));
    out.push_str("\nuse std::rc::Rc;\n\nuse prism_rtl::*;\n\nuse crate::prelude::*;\n\n");
    place(&mut out, programs, Some(0));
    out.push_str("\n/// The Test World with every root a test names, and the compiled `check` blocks.\nfn test_world() -> TestWorld {\n    TestWorld::new()\n");
    place(&mut out, registrations, Some(8));
    out.push_str("}\n\n/// The test scripts compiled with the program: `test` runs these when given none.\nconst SCRIPTS: &[&str] = &[\n");
    place(&mut out, scripts, Some(4));
    out.push_str("];\n\n/// The World the root\'s row asks for: `canvas`, `cli`, or `none` (a row with `Ui` and no\n/// `Gui`, which no World answers).\nconst WORLD: &str = \"");
    place(&mut out, world, None);
    out.push_str("\";\n\nfn main() {\n    let args: Vec<String> = std::env::args().skip(1).collect();\n    let (world, rest) = prelude::world_option(&args, WORLD);\n    let code = if args.first().map(String::as_str) == Some(\"test\") || world == \"test\" {\n        let scripts: Vec<String> = rest.into_iter().filter(|a| a != \"test\").collect();\n        prelude::on_big_stack(move || prelude::run_scripts(&test_world(), &scripts, SCRIPTS))\n    } else {\n        run_root(&world, rest)\n    };\n    std::process::exit(code as i32);\n}\n\n/// The root under the World `world`.\nfn run_root(world: &str, args: Vec<String>) -> u8 {\n");
    place(&mut out, run_root_, Some(4));
    out.push_str("}\n");
    Text::from(out)
}

/// ```prism
/// NoRoot: fn Text -> Text
/// ```
pub fn no_root(name: &Text) -> Text {
    let mut out = String::new();
    out.push_str("let _ = (world, args);\neprintln!(\"");
    place(&mut out, name, None);
    out.push_str(": the program has no `@main`; `");
    place(&mut out, name, None);
    out.push_str(" test` runs its tests\");\n2\n");
    Text::from(out)
}

/// ```prism
/// RunRoot: fn Text -> Text
/// ```
pub fn run_root(program: &Text) -> Text {
    let mut out = String::new();
    out.push_str("match world {\n    \"canvas\" => prelude::run_canvas::<");
    place(&mut out, program, None);
    out.push_str(">(),\n    \"cli\" => prelude::on_big_stack(move || prism_world_cli::run::<");
    place(&mut out, program, None);
    out.push_str(">(args)),\n    \"none\" => {\n        eprintln!(\"the root\'s row has Ui.* without Gui.*: no World answers Ui elements alone; emit Gui.* for the canvas World, or pass --world\");\n        2\n    }\n    other => {\n        eprintln!(\"no World {other} (cli, canvas, test)\");\n        2\n    }\n}\n");
    Text::from(out)
}
