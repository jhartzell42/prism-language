//! The module `Emit.Rust.Templates`, from `target/bootstrap/src/prismc/emit/rust/templates/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;
pub mod items;

/// ```prism
/// Doc: fn Text -> Text
/// ```
pub fn doc_f(text_p0: &crate::prelude::Text) -> crate::prelude::Text {
    if text_p0 == &crate::prelude::Text::lit("") {
        crate::prelude::Text::lit("")
    } else {
        crate::prelude::concat(&crate::prelude::each(&crate::prelude::split_on(text_p0, &crate::prelude::Text::lit("\n")), &(|l_p1: &crate::prelude::Text| if l_p1 == &crate::prelude::Text::lit("") {
            crate::prelude::Text::lit("///\n")
        } else {
            crate::prelude::Text::from(format!("/// {}\n", l_p1))
        })))
    }
}

/// ```prism
/// SourceDoc: fn Text, Text -> Text
/// ```
pub fn source_doc_f(lead_p0: &crate::prelude::Text, source_p1: &crate::prelude::Text) -> crate::prelude::Text {
    if lead_p0 == &crate::prelude::Text::lit("") {
        source_only_f(source_p1)
    } else {
        source_led_f(lead_p0, source_p1)
    }
}

/// ```prism
/// SourceOnly: fn Text -> Text
/// ```
pub fn source_only_f(source_p0: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("/// ```prism\n");
    crate::prelude::place(&mut out, &quoted_f(source_p0), ::std::option::Option::None);
    out.push_str("\n/// ```\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// SourceLed: fn Text, Text -> Text
/// ```
pub fn source_led_f(lead_p0: &crate::prelude::Text, source_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("/// ");
    crate::prelude::place(&mut out, lead_p0, ::std::option::Option::None);
    out.push_str("\n///\n/// ```prism\n");
    crate::prelude::place(&mut out, &quoted_f(source_p1), ::std::option::Option::None);
    out.push_str("\n/// ```\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// Quoted: fn Text -> Text
/// ```
pub fn quoted_f(text_p0: &crate::prelude::Text) -> crate::prelude::Text {
    joined_f(&crate::prelude::each(&crate::prelude::split_on(text_p0, &crate::prelude::Text::lit("\n")), &(|l_p1: &crate::prelude::Text| if l_p1 == &crate::prelude::Text::lit("") {
        crate::prelude::Text::lit("///")
    } else {
        crate::prelude::Text::from(format!("/// {}", l_p1))
    })), &crate::prelude::Text::lit("\n"))
}

/// ```prism
/// Joined: fn [Text], Text -> Text
/// ```
pub fn joined_f(xs_p0: &crate::prelude::Array<crate::prelude::Text>, sep_p1: &crate::prelude::Text) -> crate::prelude::Text {
    match crate::prelude::index(xs_p0, &crate::prelude::Nat::from(0u32)) {
        ::std::option::Option::Some(first_p2) => crate::prelude::concat(&crate::prelude::fold(&crate::prelude::drop(xs_p0, &crate::prelude::Nat::from(1u32)), &crate::prelude::Array::from(vec![first_p2.clone()]), &(|acc_p3: &crate::prelude::Array<crate::prelude::Text>, x_p4: &crate::prelude::Text| crate::prelude::push(&crate::prelude::push(acc_p3, sep_p1), x_p4)))),
        ::std::option::Option::None => crate::prelude::Text::lit(""),
    }
}

/// ```prism
/// Module: fn Text, Text, Text, Text -> Text
/// ```
pub fn module_f(prism_p0: &crate::prelude::Text, path_p1: &crate::prelude::Text, uses_p2: &crate::prelude::Text, items_p3: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("//! ");
    crate::prelude::place(&mut out, prism_p0, ::std::option::Option::None);
    out.push_str(", from `");
    crate::prelude::place(&mut out, path_p1, ::std::option::Option::None);
    out.push_str("`, emitted by prismc: one Rust type per Prism type, a node\n//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime\n//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the\n//! standard library from `::std`, and nothing is imported by name: a program\'s own type\n//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.\n\nuse crate::prelude::traits::*;\n");
    crate::prelude::place(&mut out, uses_p2, ::std::option::Option::Some(0));
    out.push_str("\n");
    crate::prelude::place(&mut out, items_p3, ::std::option::Option::Some(0));
    crate::prelude::Text::from(out)
}

/// ```prism
/// Cargo: fn Text, Text, Text -> Text
/// ```
pub fn cargo_f(name_p0: &crate::prelude::Text, runtime_p1: &crate::prelude::Text, defaults_p2: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("# Emitted by prismc. Edit the Prism sources, not this file.\n[package]\nname = \"");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str("\"\nversion = \"0.1.0\"\nedition = \"2024\"\n\n[workspace]\n\n[[bin]]\nname = \"");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str("\"\npath = \"src/main.rs\"\n\n[dependencies]\nprism_rtl = { path = \"");
    crate::prelude::place(&mut out, runtime_p1, ::std::option::Option::None);
    out.push_str("/runtime/rust\" }\nprism_world_cli = { path = \"");
    crate::prelude::place(&mut out, runtime_p1, ::std::option::Option::None);
    out.push_str("/worlds/cli/rust\" }\nprism_world_canvas_rtl = { path = \"");
    crate::prelude::place(&mut out, runtime_p1, ::std::option::Option::None);
    out.push_str("/worlds/canvas/rust\", optional = true }\n\n[features]\ndefault = [");
    crate::prelude::place(&mut out, defaults_p2, ::std::option::Option::None);
    out.push_str("]\ncanvas = [\"prism_world_canvas_rtl\"]\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// Main: fn Text, Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn main_f(name_p0: &crate::prelude::Text, mods_p1: &crate::prelude::Text, programs_p2: &crate::prelude::Text, registrations_p3: &crate::prelude::Text, scripts_p4: &crate::prelude::Text, run_root_p5: &crate::prelude::Text, world_p6: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("//! The program `");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str("`, emitted by prismc from Prism (claude/backend.md): a crate over\n//! `prism_rtl`, run under the CLI World, the canvas World or the Test World. Edit the\n//! Prism sources, not these files.\n#![allow(dead_code, unused_variables, unused_imports, unused_mut, unused_parens, unused_braces)]\n#![allow(unreachable_patterns, unreachable_code, unused_labels, non_snake_case, non_camel_case_types)]\n#![allow(clippy::all)]\n// A recursive widget\'s rows nest a node type per level, sixteen levels (gap ID): deeper than\n// rustc\'s default limit of 128 for checking what a type\'s drop reaches.\n#![recursion_limit = \"512\"]\n\n");
    crate::prelude::place(&mut out, mods_p1, ::std::option::Option::Some(0));
    out.push_str("\nuse ::std::rc::Rc;\n\nuse ::prism_rtl::*;\n\nuse crate::prelude::*;\n\n");
    crate::prelude::place(&mut out, programs_p2, ::std::option::Option::Some(0));
    out.push_str("\n/// The Test World with every root a test names, and the compiled `check` blocks.\nfn test_world() -> crate::prelude::TestWorld {\n    crate::prelude::TestWorld::new()\n");
    crate::prelude::place(&mut out, registrations_p3, ::std::option::Option::Some(8));
    out.push_str("}\n\n/// The test scripts compiled with the program: `test` runs these when given none.\nconst SCRIPTS: &[&str] = &[\n");
    crate::prelude::place(&mut out, scripts_p4, ::std::option::Option::Some(4));
    out.push_str("];\n\n/// The World the root\'s row asks for: `canvas`, `cli`, or `none` (a row with `Ui` and no\n/// `Gui`, which no World answers).\nconst WORLD: &str = \"");
    crate::prelude::place(&mut out, world_p6, ::std::option::Option::None);
    out.push_str("\";\n\nfn main() {\n    let args: ::std::vec::Vec<::std::string::String> = ::std::env::args().skip(1).collect();\n    let (world, rest) = prelude::world_option(&args, WORLD);\n    let code = if args.first().map(::std::string::String::as_str) == ::std::option::Option::Some(\"test\") || world == \"test\" {\n        let scripts: ::std::vec::Vec<::std::string::String> = rest.into_iter().filter(|a| a != \"test\").collect();\n        prelude::on_big_stack(move || prelude::run_scripts(&test_world(), &scripts, SCRIPTS))\n    } else {\n        run_root(&world, rest)\n    };\n    ::std::process::exit(code as i32);\n}\n\n/// The root under the World `world`.\nfn run_root(world: &str, args: ::std::vec::Vec<::std::string::String>) -> u8 {\n");
    crate::prelude::place(&mut out, run_root_p5, ::std::option::Option::Some(4));
    out.push_str("}\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// NoRoot: fn Text -> Text
/// ```
pub fn no_root_f(name_p0: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("let _ = (world, args);\neprintln!(\"");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str(": the program has no `@main`; `");
    crate::prelude::place(&mut out, name_p0, ::std::option::Option::None);
    out.push_str(" test` runs its tests\");\n2\n");
    crate::prelude::Text::from(out)
}

/// ```prism
/// RunRoot: fn Text -> Text
/// ```
pub fn run_root_f(program_p0: &crate::prelude::Text) -> crate::prelude::Text {
    let mut out = ::std::string::String::new();
    out.push_str("match world {\n    \"canvas\" => prelude::run_canvas::<");
    crate::prelude::place(&mut out, program_p0, ::std::option::Option::None);
    out.push_str(">(),\n    \"cli\" => prelude::on_big_stack(move || ::prism_world_cli::run::<");
    crate::prelude::place(&mut out, program_p0, ::std::option::Option::None);
    out.push_str(">(args)),\n    \"none\" => {\n        eprintln!(\"the root\'s row has Ui.* without Gui.*: no World answers Ui elements alone; emit Gui.* for the canvas World, or pass --world\");\n        2\n    }\n    other => {\n        eprintln!(\"no World {other} (cli, canvas, test)\");\n        2\n    }\n}\n");
    crate::prelude::Text::from(out)
}
