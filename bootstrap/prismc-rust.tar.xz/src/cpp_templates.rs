//! The module `CppTemplates`, from `target/bootstrap/src/prismc/templates/cpp.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
#[allow(unused_imports)]
use crate::{program, ast, check_blocks, check_env, check_errors, check_expr, check_passes, check_types, cpp_prelude_template, emit, emit_cpp, fs, lexer, lower, parser, prelude_template, process, rust_templates, sexp, typed};

/// ```prism
/// CppMakefile: fn Text, Text, Text, Text -> Text
/// ```
pub fn cpp_makefile(name: &Text, runtime: &Text, sources: &Text, canvas: &Text) -> Text {
    let mut out = String::new();
    out.push_str("# Emitted by prismc. Edit the Prism sources, not this file.\n#   make                   the program, with $(CXX) (g++ by default)\n#   make CXX=clang++\n.DEFAULT_GOAL := ");
    place(&mut out, name, None);
    out.push_str("\n# The repository root: PRISM_ROOT from the environment (the prism script and the bootstrap\n# export their own location), else from this Makefile's path, which keeps a symlinked\n# build directory's logical path where `make -C`'s current directory would not.\nHERE := $(patsubst %/,%,$(dir $(abspath $(lastword $(MAKEFILE_LIST)))))\nPRISM_ROOT ?= $(if $(filter /%,");
    place(&mut out, runtime, None);
    out.push_str("),");
    place(&mut out, runtime, None);
    out.push_str(",$(abspath $(HERE)/");
    place(&mut out, runtime, None);
    out.push_str("))\nRT := $(PRISM_ROOT)/runtime/cpp\nWORLD := $(PRISM_ROOT)/worlds/cli/cpp\nCXX ?= g++\nOPT ?= -O3\nCONFIG ?= prog-$(notdir $(CXX))$(subst $() ,,$(OPT))\nLIB := $(RT)/build/$(CONFIG)/libprism_rtl.a\nFLAGS := -std=gnu++20 $(OPT) -I$(RT)/include -I$(WORLD)/include -Isrc -Wall -Wno-unused -Wno-unused-parameter -Wno-unused-label\nSRCS := src/main.cpp ");
    place(&mut out, sources, None);
    out.push_str("\nOBJS := $(SRCS:src/%.cpp=build/%.o)\nWORLD_LIBS :=\nSYS_LIBS :=\n");
    place(&mut out, canvas, Some(0));
    out.push_str("\n");
    place(&mut out, name, None);
    out.push_str(": $(OBJS) build/cli.o $(LIB) $(WORLD_LIBS)\n\t$(CXX) $(FLAGS) -o $@ $(OBJS) build/cli.o $(WORLD_LIBS) $(LIB) $(SYS_LIBS)\n\nbuild/cli.o: $(WORLD)/src/cli.cpp $(WORLD)/include/prism_world_cli/cli.hpp\n\t@mkdir -p build\n\t$(CXX) $(FLAGS) -c $< -o $@\n\nbuild/%.o: src/%.cpp\n\t@mkdir -p build\n\t$(CXX) $(FLAGS) -MMD -MP -c $< -o $@\n\n-include $(OBJS:.o=.d)\n\n$(LIB): FORCE\n\t@$(MAKE) -s -C $(RT) lib CXX=$(CXX) CONFIG=$(CONFIG) OPT=\"$(OPT)\"\n\nFORCE:\n.PHONY: FORCE\n");
    Text::from(out)
}

/// ```prism
/// CppMakefileCanvas: fn Text -> Text
/// ```
pub fn cpp_makefile_canvas(runtime: &Text) -> Text {
    let mut out = String::new();
    out.push_str("CANVAS := $(PRISM_ROOT)/worlds/canvas/cpp\nFLAGS += -I$(CANVAS)/include $(shell pkg-config --cflags cairo freetype2)\nWORLD_LIBS := $(CANVAS)/build/$(CONFIG)/libprism_world_canvas.a\nifeq ($(shell uname -s),Darwin)\nSYS_LIBS := $(shell pkg-config --libs cairo freetype2) -framework Cocoa -framework QuartzCore\nelse\nSYS_LIBS := $(shell pkg-config --libs cairo freetype2 x11 xext)\nendif\n\n$(WORLD_LIBS): FORCE | $(LIB)\n\t@$(MAKE) -s -C $(CANVAS) lib CXX=$(CXX) CONFIG=$(CONFIG) OPT=\"$(OPT)\"\n");
    Text::from(out)
}

/// ```prism
/// CppDeclHeader: fn Text, Text, Text, Text -> Text
/// ```
pub fn cpp_decl_header(title: &Text, includes: &Text, forward: &Text, handles: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// ");
    place(&mut out, title, None);
    out.push_str(": its types, nodes and jobs declared, and its choices' handles, emitted by\n// prismc (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n#include \"prelude.hpp\"\n");
    place(&mut out, includes, Some(0));
    out.push_str("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(&mut out, forward, Some(0));
    out.push_str("\n");
    place(&mut out, handles, Some(0));
    out.push_str("\n}  // namespace crate\n");
    Text::from(out)
}

/// ```prism
/// CppTypesHeader: fn Text, Text, Text, Text -> Text
/// ```
pub fn cpp_types_header(title: &Text, includes: &Text, values_: &Text, cases: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// ");
    place(&mut out, title, None);
    out.push_str(": its records, tags and newtypes (each after the types it holds) and its\n// choices' cases, emitted by prismc (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n");
    place(&mut out, includes, Some(0));
    out.push_str("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(&mut out, values_, Some(0));
    out.push_str("\n");
    place(&mut out, cases, Some(0));
    out.push_str("\n}  // namespace crate\n");
    Text::from(out)
}

/// ```prism
/// CppTypesInGroup: fn Text, Text -> Text
/// ```
pub fn cpp_types_in_group(title: &Text, group: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// ");
    place(&mut out, title, None);
    out.push_str(": its records, tags and newtypes and its choices' cases are defined with those\n// of the modules whose types it holds by value and which hold its own, in `");
    place(&mut out, group, None);
    out.push_str(".types.hpp`,\n// emitted by prismc (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n#include \"");
    place(&mut out, group, None);
    out.push_str(".types.hpp\"\n");
    Text::from(out)
}

/// ```prism
/// CppModHeader: fn Text, Text, Text, Text, Text -> Text
/// ```
pub fn cpp_mod_header(title: &Text, includes: &Text, protos: &Text, outer: &Text, classes: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// ");
    place(&mut out, title, None);
    out.push_str(": its functions' prototypes and its nodes and jobs, emitted by prismc\n// (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n");
    place(&mut out, includes, Some(0));
    out.push_str("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(&mut out, protos, Some(0));
    out.push_str("\n");
    place(&mut out, outer, Some(0));
    out.push_str("\n");
    place(&mut out, classes, Some(0));
    out.push_str("\n}  // namespace crate\n");
    Text::from(out)
}

/// ```prism
/// CppGenericHeader: fn Text, Text, Text -> Text
/// ```
pub fn cpp_generic_header(title: &Text, includes: &Text, generic: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// ");
    place(&mut out, title, None);
    out.push_str(": its generic functions' and types' definitions, emitted by prismc\n// (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n");
    place(&mut out, includes, Some(0));
    out.push_str("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(&mut out, generic, Some(0));
    out.push_str("\n}  // namespace crate\n");
    Text::from(out)
}

/// ```prism
/// CppElemDecl: fn Text, Text, Text, Text -> Text
/// ```
pub fn cpp_elem_decl(includes: &Text, forward: &Text, handles: &Text, rows: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// The program's `Elem` and `Answer` declared, their handles, and the prelude's rows,\n// emitted by prismc (claude/backend.md). Edit the Prism sources, not this file.\n#pragma once\n\n#include \"prelude.hpp\"\n");
    place(&mut out, includes, Some(0));
    out.push_str("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(&mut out, forward, Some(0));
    out.push_str("\n");
    place(&mut out, handles, Some(0));
    out.push_str("\nnamespace prelude {\n\n");
    place(&mut out, rows, Some(0));
    out.push_str("\n}  // namespace prelude\n\n}  // namespace crate\n");
    Text::from(out)
}

/// ```prism
/// CppElemTypes: fn Text, Text -> Text
/// ```
pub fn cpp_elem_types(includes: &Text, cases: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// The cases of the program's `Elem` and `Answer`, emitted by prismc (claude/backend.md).\n// Edit the Prism sources, not this file.\n#pragma once\n\n#include \"elem.decl.hpp\"\n");
    place(&mut out, includes, Some(0));
    out.push_str("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(&mut out, cases, Some(0));
    out.push_str("\n}  // namespace crate\n");
    Text::from(out)
}

/// ```prism
/// CppModule: fn Text, Text, Text, Text, Text -> Text
/// ```
pub fn cpp_module(prism: &Text, path_: &Text, ns: &Text, includes: &Text, defs: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// ");
    place(&mut out, prism, None);
    out.push_str(", from `");
    place(&mut out, path_, None);
    out.push_str("`, emitted by prismc: its functions, its nodes' methods, its\n// types' printers (claude/backend.md). Edit the Prism source, not this file.\n");
    place(&mut out, includes, Some(0));
    out.push_str("\nnamespace crate::");
    place(&mut out, ns, None);
    out.push_str(" {\n\n");
    place(&mut out, defs, Some(0));
    out.push_str("\n}  // namespace crate::");
    place(&mut out, ns, None);
    out.push_str("\n");
    Text::from(out)
}

/// ```prism
/// CppProgramsHeader: fn Text, Text, Text -> Text
/// ```
pub fn cpp_programs_header(name: &Text, includes: &Text, programs: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// The programs of `");
    place(&mut out, name, None);
    out.push_str("`, emitted by prismc (claude/backend.md): each root's class, over\n// every module's header. Edit the Prism sources, not this file.\n#pragma once\n\n");
    place(&mut out, includes, Some(0));
    out.push_str("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(&mut out, programs, Some(0));
    out.push_str("\n}  // namespace crate\n");
    Text::from(out)
}

/// ```prism
/// CppMain: fn Text, Text, Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn cpp_main(name: &Text, includes: &Text, registrations: &Text, checks: &Text, scripts: &Text, world: &Text, run_root: &Text, crate_defs: &Text) -> Text {
    let mut out = String::new();
    out.push_str("// The program `");
    place(&mut out, name, None);
    out.push_str("`, emitted by prismc from Prism (claude/backend.md): C++ over\n// `prism_rtl`, run under the Test World. Edit the Prism sources, not these files.\n");
    place(&mut out, includes, Some(0));
    out.push_str("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(&mut out, crate_defs, Some(0));
    out.push_str("\n/// The Test World with every root a test names, and the compiled `check` blocks.\nTestWorld test_world() {\n    TestWorld world;\n    world");
    place(&mut out, registrations, None);
    place(&mut out, checks, None);
    out.push_str(";\n    return world;\n}\n\n/// The test scripts compiled with the program: `test` runs these when given none.\nconst std::vector<std::string> SCRIPTS = {\n");
    place(&mut out, scripts, Some(4));
    out.push_str("};\n\n/// The World the root's row asks for: `canvas`, `cli`, or `none` (a row with `Ui` and no\n/// `Gui`, which no World answers).\nconst std::string WORLD = \"");
    place(&mut out, world, None);
    out.push_str("\";\n\n/// The root under the World `world`.\nint run_root(const std::string& world, const std::vector<std::string>& args) {\n");
    place(&mut out, run_root, Some(4));
    out.push_str("}\n\n}  // namespace crate\n\nint main(int argc, char** argv) {\n    std::vector<std::string> args(argv + 1, argv + argc);\n    // The canvas World keeps the main thread for its windows (AppKit's rule on macOS) and\n    // ticks on a big stack of its own.\n    if (auto [world, rest] = crate::prelude::world_option(args, crate::WORLD); world == \"canvas\" && (args.empty() || args[0] != \"test\"))\n        return crate::run_root(world, rest);\n    return crate::prelude::on_big_stack([&] {\n        auto [world, rest] = crate::prelude::world_option(args, crate::WORLD);\n        if ((!args.empty() && args[0] == \"test\") || world == \"test\") {\n            std::vector<std::string> scripts;\n            for (const auto& a : rest)\n                if (a != \"test\") scripts.push_back(a);\n            return crate::prelude::run_scripts(crate::test_world(), scripts, crate::SCRIPTS);\n        }\n        return crate::run_root(world, rest);\n    });\n}\n");
    Text::from(out)
}

/// ```prism
/// CppNoRoot: fn Text -> Text
/// ```
pub fn cpp_no_root(name: &Text) -> Text {
    let mut out = String::new();
    out.push_str("static_cast<void>(world);\nstatic_cast<void>(args);\nstd::fprintf(stderr, \"");
    place(&mut out, name, None);
    out.push_str(": the program has no `@main`; `");
    place(&mut out, name, None);
    out.push_str(" test` runs its tests\\n\");\nreturn 2;\n");
    Text::from(out)
}

/// ```prism
/// CppRunRoot: fn Text, Text -> Text
/// ```
pub fn cpp_run_root(program: &Text, canvas: &Text) -> Text {
    let mut out = String::new();
    out.push_str("if (world == \"cli\") return prelude::run_cli<");
    place(&mut out, program, None);
    out.push_str(">(args);\nif (world == \"canvas\") {\n");
    place(&mut out, canvas, Some(4));
    out.push_str("}\nif (world == \"none\") {\n    std::fprintf(stderr, \"the root's row has Ui.* without Gui.*: no World answers Ui elements alone; emit Gui.* for the canvas World, or pass --world\\n\");\n    return 2;\n}\nstd::fprintf(stderr, \"no World %s (cli, canvas, test)\\n\", world.c_str());\nreturn 2;\n");
    Text::from(out)
}

/// ```prism
/// CppCanvasRun: fn Text -> Text
/// ```
pub fn cpp_canvas_run(program: &Text) -> Text {
    let mut out = String::new();
    out.push_str("static_cast<void>(args);\nreturn prism_world_canvas::run<");
    place(&mut out, program, None);
    out.push_str(">();\n");
    Text::from(out)
}

/// ```prism
/// CppNoCanvas: fn Text -> Text
/// ```
pub fn cpp_no_canvas(program: &Text) -> Text {
    let mut out = String::new();
    out.push_str("std::fprintf(stderr, \"the root's row emits no Gui.*, so this program is built without the canvas World\\n\");\nreturn 2;\n");
    Text::from(out)
}

/// ```prism
/// CppCanvasInclude: fn Text -> Text
/// ```
pub fn cpp_canvas_include(text0: &Text) -> Text {
    match text0 {
        _ => {
            let mut out = String::new();
            out.push_str("#include \"prism_world_canvas/canvas.hpp\"\n");
            Text::from(out)
        },
    }
}

/// ```prism
/// ChoiceHandle: fn Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn choice_handle(doc: &Text, gens: &Text, name: &Text, decls: &Text, names: &Text, members: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, doc, Some(0));
    place(&mut out, gens, None);
    out.push_str("class ");
    place(&mut out, name, None);
    out.push_str(" {\npublic:\n    using prism_value = void;\n");
    place(&mut out, decls, Some(4));
    out.push_str("    using Cases = std::variant<");
    place(&mut out, names, None);
    out.push_str(">;\n    template <class C>\n        requires prism_rtl::one_of<C, ");
    place(&mut out, names, None);
    out.push_str(">\n    ");
    place(&mut out, name, None);
    out.push_str("(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}\n    const Cases& cases() const;\n");
    place(&mut out, members, Some(4));
    out.push_str("\nprivate:\n    prism_rtl::Rc<const Cases> cases_;\n};\n");
    Text::from(out)
}

/// ```prism
/// CaseDecl: fn Text, Text, Text -> Text
/// ```
pub fn case_decl(gens: &Text, path_: &Text, fields: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, gens, None);
    out.push_str("struct ");
    place(&mut out, path_, None);
    out.push_str(" {\n");
    place(&mut out, fields, Some(4));
    out.push_str("};\n");
    Text::from(out)
}

/// ```prism
/// ValueStruct: fn Text, Text, Text, Text, Text -> Text
/// ```
pub fn value_struct(doc: &Text, gens: &Text, name: &Text, fields: &Text, members: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, doc, Some(0));
    place(&mut out, gens, None);
    out.push_str("struct ");
    place(&mut out, name, None);
    out.push_str(" {\n    using prism_value = void;\n");
    place(&mut out, fields, Some(4));
    out.push_str("    const ");
    place(&mut out, name, None);
    out.push_str("* operator->() const { return this; }\n    ");
    place(&mut out, name, None);
    out.push_str("* operator->() { return this; }\n");
    place(&mut out, members, Some(4));
    out.push_str("};\n");
    Text::from(out)
}

/// ```prism
/// CppTagStruct: fn Text, Text, Text, Text, Text -> Text
/// ```
pub fn cpp_tag_struct(doc: &Text, name: &Text, fields: &Text, tag_name: &Text, members: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, doc, Some(0));
    out.push_str("struct ");
    place(&mut out, name, None);
    out.push_str(" {\n    using prism_value = void;\n    /// The tag's qualified name, as its `Pod` carries it.\n    static constexpr const char* TAG = \"");
    place(&mut out, tag_name, None);
    out.push_str("\";\n");
    place(&mut out, fields, Some(4));
    out.push_str("    const ");
    place(&mut out, name, None);
    out.push_str("* operator->() const { return this; }\n    ");
    place(&mut out, name, None);
    out.push_str("* operator->() { return this; }\n    Pod to_pod() const;\n    void show(Printer& p) const;\n");
    place(&mut out, members, Some(4));
    out.push_str("};\n");
    Text::from(out)
}

/// ```prism
/// CppFunction: fn Text, Text, Text -> Text
/// ```
pub fn cpp_function(doc: &Text, signature: &Text, body: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, doc, Some(0));
    place(&mut out, signature, None);
    out.push_str(" {\n");
    place(&mut out, body, Some(4));
    out.push_str("}\n");
    Text::from(out)
}

/// ```prism
/// JobStruct: fn Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn job_struct(doc: &Text, gens: &Text, name: &Text, ret: &Text, fields: &Text, ctor: &Text) -> Text {
    let mut out = String::new();
    out.push_str("/// The step machine of `");
    place(&mut out, name, None);
    out.push_str("`, stopped at a cycle point: the call about to be\n/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the\n/// callee's job, so the job's stack is its frames.\n///\n");
    place(&mut out, doc, Some(0));
    place(&mut out, gens, None);
    out.push_str("struct ");
    place(&mut out, name, None);
    out.push_str(" : prism_rtl::Job<");
    place(&mut out, ret, None);
    out.push_str("> {\n");
    place(&mut out, fields, Some(4));
    place(&mut out, ctor, Some(4));
    out.push_str("    prism_rtl::Turn<");
    place(&mut out, ret, None);
    out.push_str("> cycle() const override;\n};\n");
    Text::from(out)
}

/// ```prism
/// TraitNamespace: fn Text, Text -> Text
/// ```
pub fn trait_namespace(name: &Text, body: &Text) -> Text {
    let mut out = String::new();
    out.push_str("namespace ");
    place(&mut out, name, None);
    out.push_str(" {\n");
    place(&mut out, body, Some(0));
    out.push_str("}  // namespace ");
    place(&mut out, name, None);
    Text::from(out)
}

/// ```prism
/// NodeClass: fn Text, Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn node_class(doc: &Text, name: &Text, base: &Text, fields: &Text, consts: &Text, ctor: &Text, decls: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, doc, Some(0));
    out.push_str("class ");
    place(&mut out, name, None);
    out.push_str(" : public ");
    place(&mut out, base, None);
    out.push_str(" {\npublic:\n    Path path;\n");
    place(&mut out, fields, Some(4));
    place(&mut out, consts, Some(4));
    place(&mut out, ctor, Some(4));
    out.push_str("    ");
    place(&mut out, name, None);
    out.push_str("(const ");
    place(&mut out, name, None);
    out.push_str("&) = delete;\n");
    place(&mut out, decls, Some(4));
    out.push_str("};\n");
    Text::from(out)
}

/// ```prism
/// NodeMake: fn Text, Text, Text, Text, Text -> Text
/// ```
pub fn node_make(name: &Text, signature: &Text, lets: &Text, args: &Text, rest: &Text) -> Text {
    let mut out = String::new();
    out.push_str("/// Built after propagation: holds take their initial values, places go out with\n/// `cx.added`, and nothing fires.\n");
    place(&mut out, signature, None);
    out.push_str(" {\n");
    place(&mut out, lets, Some(4));
    out.push_str("    prism_rtl::RcPlace<");
    place(&mut out, name, None);
    out.push_str("> _place;\n    auto node = _place.take(new (_place.at()) ");
    place(&mut out, name, None);
    out.push_str("(");
    place(&mut out, args, None);
    out.push_str("));\n");
    place(&mut out, rest, Some(4));
    out.push_str("}\n");
    Text::from(out)
}

/// ```prism
/// ForBuildTemplate: fn Text, Text, Text, Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn for_build_template(owner: &Text, name: &Text, at_: &Text, key_ty: &Text, value_ty: &Text, row_make: &Text, source: &Text, parent: &Text, passed: &Text) -> Text {
    let mut out = String::new();
    out.push_str("/// The rows of the `for` at `");
    place(&mut out, at_, None);
    out.push_str("`: rows whose key left are torn down, new keys are\n/// built under it at `[k]` from the values after the tick; kept rows keep reading their\n/// entry out of the source.\nDone ");
    place(&mut out, owner, None);
    out.push_str("::");
    place(&mut out, name, None);
    out.push_str("_build(Cx& cx) {\n    Map<");
    place(&mut out, key_ty, None);
    out.push_str(", ");
    place(&mut out, value_ty, None);
    out.push_str("> items = ");
    place(&mut out, source, None);
    out.push_str("(cx);\n    auto old = deref(this->");
    place(&mut out, name, None);
    out.push_str(");\n    for (auto&& [k, row] : old) {\n        if (!items.contains(k)) {\n            row->leave_row(cx);\n            cx.leave_later(row);\n        }\n    }\n    decltype(old) next;\n    for (auto&& [k, v] : items) {\n        if (auto row = old.get(k)) next.insert(k, *row);\n        else next.insert(k, TRY(");
    place(&mut out, row_make, None);
    out.push_str("(");
    place(&mut out, at_, None);
    out.push_str(".child(Segment::key(prism_rtl::to_pod(k))), k, v, ");
    place(&mut out, parent, None);
    place(&mut out, passed, None);
    out.push_str(", cx)));\n    }\n    deref(this->");
    place(&mut out, name, None);
    out.push_str(") = next;\n    // What the block reads of its rows (a `for` that gives a dynamic) moved.\n    cx.dirty(prism_rtl::share(this));\n    return {};\n}\n");
    Text::from(out)
}

/// ```prism
/// GenBuildTemplate: fn Text, Text, Text, Text, Text, Text, Text -> Text
/// ```
pub fn gen_build_template(owner: &Text, name: &Text, at_: &Text, path_: &Text, source: &Text, value_ty: &Text, select: &Text) -> Text {
    let mut out = String::new();
    out.push_str("/// The `rebuild` at `");
    place(&mut out, at_, None);
    out.push_str("`: the old generation torn down (it ran to the end of the\n/// tick), the next built at `");
    place(&mut out, path_, None);
    out.push_str("` from the source after the tick.\nDone ");
    place(&mut out, owner, None);
    out.push_str("::");
    place(&mut out, name, None);
    out.push_str("_build(Cx& cx) {\n    if (auto old = std::exchange(this->");
    place(&mut out, name, None);
    out.push_str(", std::nullopt)) {\n        (*old)->leave_row(cx);\n        cx.leave_later(*old);\n    }\n    std::uint32_t g = this->");
    place(&mut out, name, None);
    out.push_str("_count;\n    this->");
    place(&mut out, name, None);
    out.push_str("_count = g + 1;\n    Path path = ");
    place(&mut out, path_, None);
    out.push_str(";\n    ");
    place(&mut out, value_ty, None);
    out.push_str(" value = ");
    place(&mut out, source, None);
    out.push_str(";\n    prism_rtl::Rc<Row> row = ");
    place(&mut out, select, None);
    out.push_str(";\n    this->");
    place(&mut out, name, None);
    out.push_str(" = row;\n    return {};\n}\n");
    Text::from(out)
}

/// ```prism
/// ProgramClass: fn Text, Text, Text, Text, Text -> Text
/// ```
pub fn program_class(name: &Text, prism: &Text, node_: &Text, decode: &Text, root: &Text) -> Text {
    let mut out = String::new();
    out.push_str("/// The program of `@");
    place(&mut out, prism, None);
    out.push_str("`: the root node and the runtime.\nclass ");
    place(&mut out, name, None);
    out.push_str(" : public Program {\npublic:\n    static Built<");
    place(&mut out, name, None);
    out.push_str("> build(std::span<const Pod> args, const ReadyState& ready) {\n");
    place(&mut out, decode, Some(8));
    out.push_str("        auto p = std::make_unique<");
    place(&mut out, name, None);
    out.push_str(">();\n        Cx cx = p->rt.build(ready);\n        p->root = ");
    place(&mut out, root, None);
    out.push_str(";\n        TickOut out = TRY(p->rt.close(std::move(cx)));\n        return std::pair<std::unique_ptr<");
    place(&mut out, name, None);
    out.push_str(">, TickOut>(std::move(p), std::move(out));\n    }\n    Result<TickOut> tick(const TickIn& input, const ReadyState& ready) override {\n        return rt.tick(root, input, ready);\n    }\n    void compact() override { rt.compact(); }\n\n    Runtime rt;\n    prism_rtl::Rc<");
    place(&mut out, node_, None);
    out.push_str("> root;\n};\n");
    Text::from(out)
}

/// ```prism
/// StmtExpr: fn Text, Text -> Text
/// ```
pub fn stmt_expr(stmts: &Text, tail: &Text) -> Text {
    let mut out = String::new();
    out.push_str("({\n");
    place(&mut out, stmts, Some(4));
    out.push_str("    ");
    place(&mut out, tail, None);
    out.push_str(";\n})");
    Text::from(out)
}

/// ```prism
/// MatchExpr: fn Text, Text -> Text
/// ```
pub fn match_expr(ty: &Text, arms: &Text) -> Text {
    let mut out = String::new();
    out.push_str("({\n    __label__ _done;\n    prism_rtl::Slot<");
    place(&mut out, ty, None);
    out.push_str("> _v;\n");
    place(&mut out, arms, Some(4));
    out.push_str("_done:\n    _v.take();\n})");
    Text::from(out)
}

/// ```prism
/// LabeledExpr: fn Text, Text, Text -> Text
/// ```
pub fn labeled_expr(label: &Text, ty: &Text, body: &Text) -> Text {
    let mut out = String::new();
    out.push_str("({\n    __label__ ");
    place(&mut out, label, None);
    out.push_str(";\n    prism_rtl::Slot<");
    place(&mut out, ty, None);
    out.push_str("> ");
    place(&mut out, label, None);
    out.push_str("_v;\n    {\n");
    place(&mut out, body, Some(8));
    out.push_str("    }\n");
    place(&mut out, label, None);
    out.push_str(":\n    ");
    place(&mut out, label, None);
    out.push_str("_v.take();\n})");
    Text::from(out)
}

/// ```prism
/// CondExpr: fn Text, Text, Text -> Text
/// ```
pub fn cond_expr(cond: &Text, then_x: &Text, else_x: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, cond, Some(0));
    out.push_str("    ? ");
    place(&mut out, then_x, None);
    out.push_str("\n    : ");
    place(&mut out, else_x, None);
    Text::from(out)
}

/// ```prism
/// Lambda: fn Text, Text, Text -> Text
/// ```
pub fn lambda(capture: &Text, params: &Text, body: &Text) -> Text {
    let mut out = String::new();
    out.push_str("[");
    place(&mut out, capture, None);
    out.push_str("](");
    place(&mut out, params, None);
    out.push_str(" {\n");
    place(&mut out, body, Some(4));
    out.push_str("}");
    Text::from(out)
}

/// ```prism
/// Block: fn Text, Text -> Text
/// ```
pub fn block(head: &Text, body: &Text) -> Text {
    let mut out = String::new();
    place(&mut out, head, None);
    out.push_str(" {\n");
    place(&mut out, body, Some(4));
    out.push_str("}");
    Text::from(out)
}

/// ```prism
/// IfBlock: fn Text, Text -> Text
/// ```
pub fn if_block(cond: &Text, body: &Text) -> Text {
    let mut out = String::new();
    out.push_str("if (");
    place(&mut out, cond, None);
    out.push_str(") {\n");
    place(&mut out, body, Some(4));
    out.push_str("}");
    Text::from(out)
}

/// ```prism
/// Braced: fn Text -> Text
/// ```
pub fn braced(body: &Text) -> Text {
    let mut out = String::new();
    out.push_str("{\n");
    place(&mut out, body, Some(4));
    out.push_str("}");
    Text::from(out)
}
