//! The module `Reading`, from `target/bootstrap/src/prismc/reading.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Assembled`:
///
/// ```prism
/// type Assembled = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Assembled {
    pub units_p: Array<ModFiles>,
    pub prelude_p: Array<ModFiles>,
    pub scripts_p: Array<Text>,
    pub errors_p: Array<TreeDiag>,
}

impl Show for Assembled {
    fn show(&self, p: &mut Printer) {
        p.record("Assembled", &[("units", &self.units_p), ("prelude", &self.prelude_p), ("scripts", &self.scripts_p), ("errors", &self.errors_p)]);
    }
}

impl ToPod for Assembled {
    fn to_pod(&self) -> Pod {
        Pod::record("Assembled", vec![("units", self.units_p.to_pod()), ("prelude", self.prelude_p.to_pod()), ("scripts", self.scripts_p.to_pod()), ("errors", self.errors_p.to_pod())])
    }
}

impl FromPod for Assembled {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Assembled { units_p: FromPod::from_pod(field(p, "units")?)?, prelude_p: FromPod::from_pod(field(p, "prelude")?)?, scripts_p: FromPod::from_pod(field(p, "scripts")?)?, errors_p: FromPod::from_pod(field(p, "errors")?)? })
    }
}

/// `CheckOpts`:
///
/// ```prism
/// type CheckOpts = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CheckOpts {
    pub world_p: Array<Text>,
    pub out_o: Option<Text>,
    pub typed_p: bool,
    pub unused_p: bool,
}

impl Show for CheckOpts {
    fn show(&self, p: &mut Printer) {
        p.record("CheckOpts", &[("world", &self.world_p), ("out", &self.out_o), ("typed", &self.typed_p), ("unused", &self.unused_p)]);
    }
}

impl ToPod for CheckOpts {
    fn to_pod(&self) -> Pod {
        Pod::record("CheckOpts", vec![("world", self.world_p.to_pod()), ("out", self.out_o.to_pod()), ("typed", self.typed_p.to_pod()), ("unused", self.unused_p.to_pod())])
    }
}

impl FromPod for CheckOpts {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CheckOpts { world_p: FromPod::from_pod(field(p, "world")?)?, out_o: FromPod::from_pod(field(p, "out")?)?, typed_p: FromPod::from_pod(field(p, "typed")?)?, unused_p: FromPod::from_pod(field(p, "unused")?)? })
    }
}

/// `CompileSettings`:
///
/// ```prism
/// type CompileSettings = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CompileSettings {
    pub out_p: Text,
    pub prelude_p: Text,
    pub name_p: Text,
    pub runtime_p: Text,
    pub target_p: Text,
}

impl Show for CompileSettings {
    fn show(&self, p: &mut Printer) {
        p.record("CompileSettings", &[("out", &self.out_p), ("prelude", &self.prelude_p), ("name", &self.name_p), ("runtime", &self.runtime_p), ("target", &self.target_p)]);
    }
}

impl ToPod for CompileSettings {
    fn to_pod(&self) -> Pod {
        Pod::record("CompileSettings", vec![("out", self.out_p.to_pod()), ("prelude", self.prelude_p.to_pod()), ("name", self.name_p.to_pod()), ("runtime", self.runtime_p.to_pod()), ("target", self.target_p.to_pod())])
    }
}

impl FromPod for CompileSettings {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CompileSettings { out_p: FromPod::from_pod(field(p, "out")?)?, prelude_p: FromPod::from_pod(field(p, "prelude")?)?, name_p: FromPod::from_pod(field(p, "name")?)?, runtime_p: FromPod::from_pod(field(p, "runtime")?)?, target_p: FromPod::from_pod(field(p, "target")?)? })
    }
}

/// `HeadLine`:
///
/// ```prism
/// type HeadLine = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct HeadLine {
    pub word_p: Text,
    pub arg_p: Text,
    pub span_p: crate::syntax::Range,
}

impl Show for HeadLine {
    fn show(&self, p: &mut Printer) {
        p.record("HeadLine", &[("word", &self.word_p), ("arg", &self.arg_p), ("span", &self.span_p)]);
    }
}

impl ToPod for HeadLine {
    fn to_pod(&self) -> Pod {
        Pod::record("HeadLine", vec![("word", self.word_p.to_pod()), ("arg", self.arg_p.to_pod()), ("span", self.span_p.to_pod())])
    }
}

impl FromPod for HeadLine {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(HeadLine { word_p: FromPod::from_pod(field(p, "word")?)?, arg_p: FromPod::from_pod(field(p, "arg")?)?, span_p: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `ModFiles`:
///
/// ```prism
/// type ModFiles = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ModFiles {
    pub name_p: Text,
    pub named_p: bool,
    pub segs_p: Array<Seg>,
    pub parent_p: Text,
}

impl Show for ModFiles {
    fn show(&self, p: &mut Printer) {
        p.record("ModFiles", &[("name", &self.name_p), ("named", &self.named_p), ("segs", &self.segs_p), ("parent", &self.parent_p)]);
    }
}

impl ToPod for ModFiles {
    fn to_pod(&self) -> Pod {
        Pod::record("ModFiles", vec![("name", self.name_p.to_pod()), ("named", self.named_p.to_pod()), ("segs", self.segs_p.to_pod()), ("parent", self.parent_p.to_pod())])
    }
}

impl FromPod for ModFiles {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ModFiles { name_p: FromPod::from_pod(field(p, "name")?)?, named_p: FromPod::from_pod(field(p, "named")?)?, segs_p: FromPod::from_pod(field(p, "segs")?)?, parent_p: FromPod::from_pod(field(p, "parent")?)? })
    }
}

/// `ParsedProgram`:
///
/// ```prism
/// type ParsedProgram = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ParsedProgram {
    pub srcs_p: Array<crate::check::errors::Src>,
    pub trees_p: Array<crate::syntax::Module>,
    pub shown_p: Nat,
    pub parents_p: Array<Text>,
    pub errors_p: Text,
}

impl Show for ParsedProgram {
    fn show(&self, p: &mut Printer) {
        p.record("ParsedProgram", &[("srcs", &self.srcs_p), ("trees", &self.trees_p), ("shown", &self.shown_p), ("parents", &self.parents_p), ("errors", &self.errors_p)]);
    }
}

impl ToPod for ParsedProgram {
    fn to_pod(&self) -> Pod {
        Pod::record("ParsedProgram", vec![("srcs", self.srcs_p.to_pod()), ("trees", self.trees_p.to_pod()), ("shown", self.shown_p.to_pod()), ("parents", self.parents_p.to_pod()), ("errors", self.errors_p.to_pod())])
    }
}

impl FromPod for ParsedProgram {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ParsedProgram { srcs_p: FromPod::from_pod(field(p, "srcs")?)?, trees_p: FromPod::from_pod(field(p, "trees")?)?, shown_p: FromPod::from_pod(field(p, "shown")?)?, parents_p: FromPod::from_pod(field(p, "parents")?)?, errors_p: FromPod::from_pod(field(p, "errors")?)? })
    }
}

/// `ReadInput`:
///
/// ```prism
/// type ReadInput = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ReadInput {
    pub args_p: Array<Text>,
    pub prelude_p: Text,
    pub listings_p: Array<(Text, Array<Text>)>,
    pub paths_p: Array<Text>,
    pub texts_p: Array<(Text, Text)>,
    pub tests_p: bool,
    pub compiling_p: bool,
}

impl Show for ReadInput {
    fn show(&self, p: &mut Printer) {
        p.record("ReadInput", &[("args", &self.args_p), ("prelude", &self.prelude_p), ("listings", &self.listings_p), ("paths", &self.paths_p), ("texts", &self.texts_p), ("tests", &self.tests_p), ("compiling", &self.compiling_p)]);
    }
}

impl ToPod for ReadInput {
    fn to_pod(&self) -> Pod {
        Pod::record("ReadInput", vec![("args", self.args_p.to_pod()), ("prelude", self.prelude_p.to_pod()), ("listings", self.listings_p.to_pod()), ("paths", self.paths_p.to_pod()), ("texts", self.texts_p.to_pod()), ("tests", self.tests_p.to_pod()), ("compiling", self.compiling_p.to_pod())])
    }
}

impl FromPod for ReadInput {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ReadInput { args_p: FromPod::from_pod(field(p, "args")?)?, prelude_p: FromPod::from_pod(field(p, "prelude")?)?, listings_p: FromPod::from_pod(field(p, "listings")?)?, paths_p: FromPod::from_pod(field(p, "paths")?)?, texts_p: FromPod::from_pod(field(p, "texts")?)?, tests_p: FromPod::from_pod(field(p, "tests")?)?, compiling_p: FromPod::from_pod(field(p, "compiling")?)? })
    }
}

/// `ReadMode`:
///
/// ```prism
/// type ReadMode = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum ReadMode {
    Checking(CheckOpts),
    Compiling(CompileSettings),
}

impl Show for ReadMode {
    fn show(&self, p: &mut Printer) {
        match self {
            ReadMode::Checking(a0) => p.choice("Checking", &[a0]),
            ReadMode::Compiling(a0) => p.choice("Compiling", &[a0]),
        }
    }
}

impl ToPod for ReadMode {
    fn to_pod(&self) -> Pod {
        match self {
            ReadMode::Checking(a0) => Pod::Choice("Checking".into(), vec![a0.to_pod()]),
            ReadMode::Compiling(a0) => Pod::Choice("Compiling".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for ReadMode {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "Checking" && a.len() == 1 => Ok(ReadMode::Checking(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "Compiling" && a.len() == 1 => Ok(ReadMode::Compiling(FromPod::from_pod(&a[0])?)),
            other => mismatch("a ReadMode", other),
        }
    }
}

/// `Seg`:
///
/// ```prism
/// type Seg = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Seg {
    pub path_p: Text,
    pub text_p: Text,
    pub role_p: Text,
}

impl Show for Seg {
    fn show(&self, p: &mut Printer) {
        p.record("Seg", &[("path", &self.path_p), ("text", &self.text_p), ("role", &self.role_p)]);
    }
}

impl ToPod for Seg {
    fn to_pod(&self) -> Pod {
        Pod::record("Seg", vec![("path", self.path_p.to_pod()), ("text", self.text_p.to_pod()), ("role", self.role_p.to_pod())])
    }
}

impl FromPod for Seg {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Seg { path_p: FromPod::from_pod(field(p, "path")?)?, text_p: FromPod::from_pod(field(p, "text")?)?, role_p: FromPod::from_pod(field(p, "role")?)? })
    }
}

/// `TreeAcc`:
///
/// ```prism
/// type TreeAcc = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TreeAcc {
    pub units_p: Array<ModFiles>,
    pub declared_p: Map<Text, bool>,
    pub diags_p: Array<TreeDiag>,
}

impl Show for TreeAcc {
    fn show(&self, p: &mut Printer) {
        p.record("TreeAcc", &[("units", &self.units_p), ("declared", &self.declared_p), ("diags", &self.diags_p)]);
    }
}

impl ToPod for TreeAcc {
    fn to_pod(&self) -> Pod {
        Pod::record("TreeAcc", vec![("units", self.units_p.to_pod()), ("declared", self.declared_p.to_pod()), ("diags", self.diags_p.to_pod())])
    }
}

impl FromPod for TreeAcc {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TreeAcc { units_p: FromPod::from_pod(field(p, "units")?)?, declared_p: FromPod::from_pod(field(p, "declared")?)?, diags_p: FromPod::from_pod(field(p, "diags")?)? })
    }
}

/// `TreeDiag`:
///
/// ```prism
/// type TreeDiag = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TreeDiag {
    pub path_p: Text,
    pub span_p: crate::syntax::Range,
    pub code_p: Text,
    pub message_p: Text,
    pub fix_p: Text,
}

impl Show for TreeDiag {
    fn show(&self, p: &mut Printer) {
        p.record("TreeDiag", &[("path", &self.path_p), ("span", &self.span_p), ("code", &self.code_p), ("message", &self.message_p), ("fix", &self.fix_p)]);
    }
}

impl ToPod for TreeDiag {
    fn to_pod(&self) -> Pod {
        Pod::record("TreeDiag", vec![("path", self.path_p.to_pod()), ("span", self.span_p.to_pod()), ("code", self.code_p.to_pod()), ("message", self.message_p.to_pod()), ("fix", self.fix_p.to_pod())])
    }
}

impl FromPod for TreeDiag {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TreeDiag { path_p: FromPod::from_pod(field(p, "path")?)?, span_p: FromPod::from_pod(field(p, "span")?)?, code_p: FromPod::from_pod(field(p, "code")?)?, message_p: FromPod::from_pod(field(p, "message")?)?, fix_p: FromPod::from_pod(field(p, "fix")?)? })
    }
}

/// ```prism
/// IsCompiling: fn ReadMode -> Bool
/// ```
pub fn is_compiling_f(read_mode0: &ReadMode) -> bool {
    match read_mode0 {
        ReadMode::Compiling(_) => true,
        ReadMode::Checking(_) => false,
    }
}

// `@ReadSources` is inlined where it is applied.

// `@ReadUp` is inlined where it is applied.

// `@ReadTexts` is inlined where it is applied.

// `@ReadRun` is inlined where it is applied.

// `@RunRead` is inlined where it is applied.

// `@CheckRun` is inlined where it is applied.

// `@CompileRun` is inlined where it is applied.

/// ```prism
/// Pairs: fn [Text], (Nat ==> [Text]) -> [((Text, [Text]))]
/// ```
pub fn pairs_f(ds_p0: &Array<Text>, m_p1: &Map<Nat, Array<Text>>) -> Array<(Text, Array<Text>)> {
    crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(ds_p0)), &(|i_p2: &Nat| (crate::prelude::or(&crate::prelude::index(ds_p0, i_p2), &Text::lit("")), crate::prelude::or(&crate::prelude::get(m_p1, i_p2), &Array::new()))))
}

/// ```prism
/// ReadFailure: fn ?~Contents -> Text
/// ```
pub fn read_failure_f(opt0: &Option<Result<crate::fs::Contents, Error>>) -> Text {
    match opt0 {
        Some(c_r0) => contents_failure_f(c_r0),
        None => Text::lit("nothing was read"),
    }
}

/// ```prism
/// ContentsFailure: fn ~Contents -> Text
/// ```
pub fn contents_failure_f(arg0: &Result<crate::fs::Contents, Error>) -> Text {
    match arg0 {
        Ok(c_p0) => Text::lit(""),
        Err(c1_0) => c1_0.message_p.clone(),
    }
}

/// ```prism
/// ContentsText: fn ~Contents -> Text
/// ```
pub fn contents_text_f(arg0: &Result<crate::fs::Contents, Error>) -> Text {
    match arg0 {
        Ok(c_p0) => c_p0.text_p.clone(),
        Err(c1_0) => Text::lit(""),
    }
}

/// ```prism
/// IsSourcePath: fn Text -> Bool
/// ```
pub fn is_source_path_f(f_p0: &Text) -> bool {
    crate::syntax::lexer::chars::has_suffix_f(f_p0, &Text::lit(".prism")) || crate::syntax::lexer::chars::has_suffix_f(f_p0, &Text::lit(".prismtest"))
}

/// ```prism
/// DirOf: fn Text -> Text
/// ```
pub fn dir_of_f(p_p0: &Text) -> Text {
    crate::syntax::lexer::chars::join_f(&crate::syntax::lexer::chars::pop_f(&crate::prelude::split_on(p_p0, &Text::lit("/"))), &Text::lit("/"))
}

/// ```prism
/// BaseOf: fn Text -> Text
/// ```
pub fn base_of_f(p_p0: &Text) -> Text {
    crate::prelude::or(&crate::syntax::lexer::chars::last_o(&crate::prelude::split_on(p_p0, &Text::lit("/"))), p_p0)
}

/// ```prism
/// Under: fn Text, Text -> Text
/// ```
pub fn under_f(d_p0: &Text, n_p1: &Text) -> Text {
    if (d_p0 == &Text::lit("")) || (d_p0 == &Text::lit(".")) {
        n_p1.clone()
    } else {
        Text::from(format!("{}/{}", d_p0, n_p1))
    }
}

/// ```prism
/// Ancestors: fn Text -> [Text]
/// ```
pub fn ancestors_f(d_p0: &Text) -> Array<Text> {
    let parts_p1 = crate::prelude::split_on(d_p0, &Text::lit("/"));
    let n_p2 = crate::prelude::len(&parts_p1);
    crate::prelude::filter(&crate::prelude::each(&crate::check::errors::range0_f(&crate::syntax::lexer::chars::dec_f(&n_p2)), &(|i_p3: &Nat| crate::syntax::lexer::chars::join_f(&crate::prelude::take(&parts_p1, &crate::prelude::or(&(&crate::syntax::lexer::chars::dec_f(&n_p2)).checked_sub(i_p3), &Nat::from(0u32))), &Text::lit("/")))), &(|a_p4: &Text| (a_p4 != &Text::lit("")) && (a_p4 != &Text::lit("."))))
}

/// ```prism
/// DirName: fn Text -> Text
/// ```
pub fn dir_name_f(name_p0: &Text) -> Text {
    let (out_p5, _) = crate::syntax::lexer::chars::fold_chars_f(name_p0, &(Text::lit(""), Text::lit("")), &(Rc::new(move |(p0, p1): ((Text, Text), Text)| crate::prelude::once_job(move || {
        let (acc_p1, prev_p2) = p0;
        let c_p3 = p1;
        {
            let sep_p4 = if crate::syntax::lexer::chars::is_upper_f(&c_p3) && (crate::syntax::lexer::chars::is_lower_f(&prev_p2) || crate::syntax::lexer::chars::is_digit_f(&prev_p2)) {
                Text::lit("_")
            } else {
                Text::lit("")
            };
            prism_rtl::Turn::Finished((Text::from(format!("{}{}{}", &acc_p1, &sep_p4, &(if crate::syntax::lexer::chars::is_upper_f(&c_p3) {
                crate::prelude::lower(&c_p3)
            } else {
                c_p3.clone()
            }))), c_p3.clone()))
        }
    })) as Rc<dyn Fn(((Text, Text), Text)) -> Rc<dyn prism_rtl::Job<(Text, Text)>>>));
    out_p5.clone()
}

/// ```prism
/// ModOfDir: fn Text -> Text
/// ```
pub fn mod_of_dir_f(d_p0: &Text) -> Text {
    crate::prelude::concat(&crate::prelude::each(&crate::prelude::split_on(d_p0, &Text::lit("_")), &(|w_p1: &Text| Text::from(format!("{}{}", &crate::prelude::upper(&crate::syntax::lexer::chars::head_f(w_p1)), &crate::syntax::lexer::chars::after_first_f(w_p1))))))
}

/// ```prism
/// HeaderLines: fn Text -> [HeadLine]
/// ```
pub fn header_lines_f(text_p0: &Text) -> Array<HeadLine> {
    let (lines_p7, _, _) = crate::prelude::fold(&crate::prelude::split_on(text_p0, &Text::lit("\n")), &(Array::new(), Nat::from(0u32), true), &(|(acc_p1, at_p2, open_p3): &(Array<HeadLine>, Nat, bool), line_p4: &Text| {
        let next_p5 = &(at_p2 + &crate::prelude::len_text(line_p4)) + &Nat::from(1u32);
        if !*open_p3 {
            (acc_p1.clone(), next_p5.clone(), false)
        } else {
            if ((&crate::syntax::lexer::chars::trim_f(line_p4) == &Text::lit("")) || crate::syntax::lexer::chars::has_prefix_f(line_p4, &Text::lit("#"))) || crate::syntax::lexer::chars::has_prefix_f(line_p4, &Text::lit(" ")) {
                (acc_p1.clone(), next_p5.clone(), true)
            } else {
                match head_line_of_o(line_p4, at_p2) {
                    Some(h_p6) => (crate::prelude::push(acc_p1, &h_p6), next_p5.clone(), true),
                    None => (acc_p1.clone(), next_p5.clone(), false),
                }
            }
        }
    }));
    lines_p7.clone()
}

/// ```prism
/// ?HeadLineOf: fn Text, Nat -> ?HeadLine
/// ```
pub fn head_line_of_o(line_p0: &Text, at_p1: &Nat) -> Option<HeadLine> {
    let code_p2 = crate::syntax::lexer::chars::trim_end_f(&crate::prelude::or(&crate::prelude::index(&crate::prelude::split_on(line_p0, &Text::lit(" #")), &Nat::from(0u32)), line_p0));
    let words_p4 = crate::prelude::filter(&crate::prelude::split_on(&code_p2, &Text::lit(" ")), &(|w_p3: &Text| w_p3 != &Text::lit("")));
    let first_p5 = crate::prelude::or(&crate::prelude::index(&words_p4, &Nat::from(0u32)), &Text::lit(""));
    let second_p6 = crate::prelude::or(&crate::prelude::index(&words_p4, &Nat::from(1u32)), &Text::lit(""));
    let span_p7 = crate::syntax::Range { start_p: at_p1.clone(), end_p: at_p1 + &crate::prelude::len_text(&code_p2) };
    if (&first_p5 == &Text::lit("test")) && (&second_p6 == &Text::lit("mod")) {
        Some(HeadLine { word_p: Text::lit("test mod"), arg_p: crate::prelude::or(&crate::prelude::index(&words_p4, &Nat::from(2u32)), &Text::lit("")), span_p: span_p7.clone() })
    } else {
        if crate::check::types::has_text_f(&Array::from(vec![Text::lit("module"), Text::lit("emit"), Text::lit("mod"), Text::lit("use")]), &first_p5) {
            Some(HeadLine { word_p: first_p5.clone(), arg_p: crate::prelude::or(&crate::syntax::lexer::chars::before_suffix_o(&second_p6, &Text::lit(".*")), &second_p6), span_p: span_p7.clone() })
        } else {
            None
        }
    }
}

/// ```prism
/// ?FirstDeclLine: fn Text -> ?Range
/// ```
pub fn first_decl_line_o(text_p0: &Text) -> Option<crate::syntax::Range> {
    let (found_o5, _) = crate::prelude::fold(&crate::prelude::split_on(text_p0, &Text::lit("\n")), &(None, Nat::from(0u32)), &(|(f_o1, at_p2): &(Option<crate::syntax::Range>, Nat), line_p3: &Text| {
        let next_p4 = &(at_p2 + &crate::prelude::len_text(line_p3)) + &Nat::from(1u32);
        if ((((f_o1 != &None) || (&crate::syntax::lexer::chars::trim_f(line_p3) == &Text::lit(""))) || crate::syntax::lexer::chars::has_prefix_f(line_p3, &Text::lit("#"))) || crate::syntax::lexer::chars::has_prefix_f(line_p3, &Text::lit(" "))) || (&head_line_of_o(line_p3, at_p2) != &None) {
            (f_o1.clone(), next_p4.clone())
        } else {
            (Some(crate::syntax::Range { start_p: at_p2.clone(), end_p: at_p2 + &crate::prelude::len_text(&crate::syntax::lexer::chars::trim_end_f(line_p3)) }), next_p4.clone())
        }
    }));
    found_o5.clone()
}

/// ```prism
/// let noAssembly
/// ```
pub fn no_assembly_p() -> Assembled {
    Assembled { units_p: Array::new(), prelude_p: Array::new(), scripts_p: Array::new(), errors_p: Array::new() }
}

/// ```prism
/// let noSpan
/// ```
pub fn no_span_p() -> crate::syntax::Range {
    crate::syntax::Range { start_p: Nat::from(0u32), end_p: Nat::from(0u32) }
}

/// ```prism
/// AddTreeDiag: fn TreeAcc, Text, Range, Text, Text, Text -> TreeAcc
/// ```
pub fn add_tree_diag_f(acc_p0: &TreeAcc, path_p1: &Text, span_p2: &crate::syntax::Range, code_p3: &Text, message_p4: &Text, fix_p5: &Text) -> TreeAcc {
    let mut this: TreeAcc = acc_p0.clone();
    this.diags_p = crate::prelude::push(&this.diags_p, &TreeDiag { path_p: path_p1.clone(), span_p: span_p2.clone(), code_p: code_p3.clone(), message_p: message_p4.clone(), fix_p: fix_p5.clone() });
    this
}

/// ```prism
/// IsModuleDir: fn Text, [Text] -> Bool
/// ```
pub fn is_module_dir_f(d_p0: &Text, files_p1: &Array<Text>) -> bool {
    (crate::check::types::has_text_f(files_p1, &under_f(d_p0, &Text::lit("mod.prism"))) && !crate::check::types::has_text_f(files_p1, &under_f(d_p0, &Text::lit("app.prism")))) && !crate::check::types::has_text_f(files_p1, &under_f(d_p0, &Text::lit("lib.prism")))
}

/// ```prism
/// IsRootDir: fn Text, [Text] -> Bool
/// ```
pub fn is_root_dir_f(d_p0: &Text, files_p1: &Array<Text>) -> bool {
    crate::check::types::has_text_f(files_p1, &under_f(d_p0, &Text::lit("app.prism"))) || crate::check::types::has_text_f(files_p1, &under_f(d_p0, &Text::lit("lib.prism")))
}

/// ```prism
/// ?TreeRootOf: fn Text, (Text ==> [Text]) -> ?Text
/// ```
pub fn tree_root_of_o(d_p0: &Text, listings_p1: &Map<Text, Array<Text>>) -> Option<Text> {
    let files_p2 = crate::prelude::or(&crate::prelude::get(listings_p1, d_p0), &Array::new());
    if is_root_dir_f(d_p0, &files_p2) {
        Some(d_p0.clone())
    } else {
        if is_module_dir_f(d_p0, &files_p2) {
            crate::prelude::fold(&ancestors_f(d_p0), &None, &(|found_o3: &Option<Text>, a_p4: &Text| if (found_o3 == &None) && is_root_dir_f(a_p4, &crate::prelude::or(&crate::prelude::get(listings_p1, a_p4), &Array::new())) {
                Some(a_p4.clone())
            } else {
                found_o3.clone()
            }))
        } else {
            None
        }
    }
}

/// ```prism
/// ToRead: fn [Text], (Text ==> [Text]) -> [Text]
/// ```
pub fn to_read_f(args_p0: &Array<Text>, listings_p1: &Map<Text, Array<Text>>) -> Array<Text> {
    crate::prelude::fold(args_p0, &Array::new(), &(|acc_p2: &Array<Text>, a_p3: &Text| if is_source_path_f(a_p3) {
        crate::check::types::add_text_f(acc_p2, a_p3)
    } else {
        match tree_root_of_o(a_p3, listings_p1) {
            Some(root_p4) => crate::check::types::union_texts_f(acc_p2, &crate::prelude::or(&crate::prelude::get(listings_p1, &root_p4), &Array::new())),
            None => acc_p2.clone(),
        }
    }))
}

/// ```prism
/// Assemble: unbounded fn ReadInput -> Assembled
/// ```
pub fn assemble_f(input_p0: &ReadInput) -> Assembled {
    let listings_p1 = crate::prelude::map(&input_p0.listings_p);
    let texts_p2 = crate::prelude::map(&input_p0.texts_p);
    let progs_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(input_p0.args_p.clone(), no_assembly_p(), {
        let listings_p1x = listings_p1.clone();
        let texts_p2x = texts_p2.clone();
        Rc::new(move |(p0, p1): (Assembled, Text)| {
            let listings_p1xy = listings_p1x.clone();
            let texts_p2xy = texts_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p7 = p0;
                let a_p8 = p1;
                prism_rtl::Turn::More(Rc::new(AddArg { acc_p0: acc_p7.clone(), listings_p1: listings_p1xy.clone(), texts_p2: texts_p2xy.clone(), a_p3: a_p8.clone() }))
            }))
        }) as Rc<dyn Fn((Assembled, Text)) -> Rc<dyn prism_rtl::Job<Assembled>>>
    }));
    let pre_p4 = add_arg_f(&no_assembly_p(), &listings_p1, &texts_p2, &input_p0.prelude_p);
    let units_p5 = crate::prelude::filter(&crate::prelude::each(&progs_p3.units_p, &(|u_p9: &ModFiles| kept_segs_f(u_p9, &input_p0.tests_p))), &(|u_pa: &ModFiles| &crate::prelude::len(&u_pa.segs_p) > &Nat::from(0u32)));
    let kept_p6 = crate::prelude::fold(&units_p5, &Array::new(), &(|acc_pb: &Array<Text>, u_pc: &ModFiles| crate::prelude::append(acc_pb, &crate::prelude::each(&u_pc.segs_p, &(|s_pd: &Seg| s_pd.path_p.clone())))));
    let mut this: Assembled = progs_p3.clone();
    this.units_p = units_p5.clone();
    this.prelude_p = crate::prelude::filter(&crate::prelude::each(&pre_p4.units_p, &(|u_pe: &ModFiles| kept_segs_f(u_pe, &false))), &(|u_pf: &ModFiles| &crate::prelude::len(&u_pf.segs_p) > &Nat::from(0u32)));
    this.scripts_p = crate::prelude::filter(&this.scripts_p, &(|p_pg: &Text| crate::check::types::has_text_f(&kept_p6, p_pg)));
    this.errors_p = crate::prelude::append(&this.errors_p, &pre_p4.errors_p);
    this
}

/// The step machine of `Assemble`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Assemble: unbounded fn ReadInput -> Assembled
/// ```
pub struct Assemble {
    pub input_p0: ReadInput,
}

impl prism_rtl::Job<Assembled> for Assemble {
    fn cycle(&self) -> prism_rtl::Turn<Assembled> {
        let input_p0 = &self.input_p0;
        let listings_p1 = crate::prelude::map(&input_p0.listings_p);
        let texts_p2 = crate::prelude::map(&input_p0.texts_p);
        let input_p0x = input_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(input_p0x.args_p.clone(), no_assembly_p(), {
            let listings_p1x = listings_p1.clone();
            let texts_p2x = texts_p2.clone();
            Rc::new(move |(p0, p1): (Assembled, Text)| {
                let listings_p1xy = listings_p1x.clone();
                let texts_p2xy = texts_p2x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p7 = p0;
                    let a_p8 = p1;
                    prism_rtl::Turn::More(Rc::new(AddArg { acc_p0: acc_p7.clone(), listings_p1: listings_p1xy.clone(), texts_p2: texts_p2xy.clone(), a_p3: a_p8.clone() }))
                }))
            }) as Rc<dyn Fn((Assembled, Text)) -> Rc<dyn prism_rtl::Job<Assembled>>>
        }), move |fold_12106: Assembled| {
            let progs_p3 = fold_12106;
            crate::prelude::call_then(start_add_arg_f(no_assembly_p(), listings_p1.clone(), texts_p2.clone(), input_p0x.prelude_p.clone()), move |add_arg_f_12190: Assembled| {
                let pre_p4 = add_arg_f_12190;
                let units_p5 = crate::prelude::filter(&crate::prelude::each(&progs_p3.units_p, &(|u_p9: &ModFiles| kept_segs_f(u_p9, &input_p0x.tests_p))), &(|u_pa: &ModFiles| &crate::prelude::len(&u_pa.segs_p) > &Nat::from(0u32)));
                let kept_p6 = crate::prelude::fold(&units_p5, &Array::new(), &(|acc_pb: &Array<Text>, u_pc: &ModFiles| crate::prelude::append(acc_pb, &crate::prelude::each(&u_pc.segs_p, &(|s_pd: &Seg| s_pd.path_p.clone())))));
                prism_rtl::Turn::Finished({
                    let mut this: Assembled = progs_p3.clone();
                    this.units_p = units_p5.clone();
                    this.prelude_p = crate::prelude::filter(&crate::prelude::each(&pre_p4.units_p, &(|u_pe: &ModFiles| kept_segs_f(u_pe, &false))), &(|u_pf: &ModFiles| &crate::prelude::len(&u_pf.segs_p) > &Nat::from(0u32)));
                    this.scripts_p = crate::prelude::filter(&this.scripts_p, &(|p_pg: &Text| crate::check::types::has_text_f(&kept_p6, p_pg)));
                    this.errors_p = crate::prelude::append(&this.errors_p, &pre_p4.errors_p);
                    this
                })
            })
        })
    }
}

/// `Start Assemble, x`: what the function value is when passed to `@Run`.
pub fn start_assemble_f(input_p0: ReadInput) -> Rc<dyn prism_rtl::Job<Assembled>> {
    Rc::new(Assemble { input_p0 })
}

/// ```prism
/// KeptSegs: fn ModFiles, Bool -> ModFiles
/// ```
pub fn kept_segs_f(u_p0: &ModFiles, tests_p1: &bool) -> ModFiles {
    let mut this: ModFiles = u_p0.clone();
    this.segs_p = crate::prelude::filter(&this.segs_p, &(|s_p2: &Seg| (&s_p2.role_p != &Text::lit("test")) || *tests_p1));
    this
}

/// ```prism
/// AddArg: unbounded fn Assembled, (Text ==> [Text]), (Text ==> Text), Text -> Assembled
/// ```
pub fn add_arg_f(acc_p0: &Assembled, listings_p1: &Map<Text, Array<Text>>, texts_p2: &Map<Text, Text>, a_p3: &Text) -> Assembled {
    if crate::syntax::lexer::chars::has_suffix_f(a_p3, &Text::lit(".prismtest")) {
        {
            let mut this: Assembled = acc_p0.clone();
            this.errors_p = crate::prelude::push(&this.errors_p, &TreeDiag { path_p: a_p3.clone(), span_p: no_span_p(), code_p: Text::lit("prismtest"), message_p: Text::from(format!("`{}`: a `.prismtest` is not read: a module\'s tests are in its test modules, a loose file\'s inline", a_p3)), fix_p: Text::lit("move its declarations into a test module (`test mod tests`), or into the file it tests") });
            this
        }
    } else {
        if crate::syntax::lexer::chars::has_suffix_f(a_p3, &Text::lit(".prism")) {
            {
                let mut this: Assembled = acc_p0.clone();
                this.units_p = crate::prelude::push(&this.units_p, &ModFiles { name_p: Text::lit(""), named_p: false, segs_p: Array::from(vec![Seg { path_p: a_p3.clone(), text_p: crate::prelude::or(&crate::prelude::get(texts_p2, a_p3), &Text::lit("")), role_p: Text::lit("loose") }]), parent_p: Text::lit("") });
                this
            }
        } else {
            match tree_root_of_o(a_p3, listings_p1) {
                Some(root_p4) => {
                    let tree_p5 = walk_tree_f(&root_p4, &crate::prelude::or(&crate::prelude::get(listings_p1, &root_p4), &Array::new()), texts_p2);
                    let start_p6 = under_f(a_p3, &Text::lit("mod.prism"));
                    let units_p7 = if &root_p4 == a_p3 {
                        tree_p5.units_p.clone()
                    } else {
                        reach_tree_f(&tree_p5.units_p, &start_p6)
                    };
                    let scripts_p8 = if &root_p4 == a_p3 {
                        crate::prelude::fold(&units_p7, &Array::new(), &(|s_p9: &Array<Text>, u_pa: &ModFiles| crate::prelude::append(s_p9, &test_paths_f(u_pa))))
                    } else {
                        crate::prelude::fold(&crate::prelude::filter(&units_p7, &(|u_pb: &ModFiles| (&main_path_f(u_pb) == &start_p6) || (&u_pb.parent_p == &start_p6))), &Array::new(), &(|s_pc: &Array<Text>, u_pd: &ModFiles| crate::prelude::append(s_pc, &test_paths_f(u_pd))))
                    };
                    {
                        let mut this: Assembled = acc_p0.clone();
                        this.units_p = crate::prelude::append(&this.units_p, &units_p7);
                        this.scripts_p = crate::prelude::append(&this.scripts_p, &scripts_p8);
                        this.errors_p = crate::prelude::append(&this.errors_p, &tree_p5.diags_p);
                        this
                    }
                },
                None => {
                    let mut this: Assembled = acc_p0.clone();
                    this.errors_p = crate::prelude::push(&this.errors_p, &TreeDiag { path_p: a_p3.clone(), span_p: no_span_p(), code_p: Text::lit("no-root"), message_p: Text::from(format!("`{}` holds no app.prism, lib.prism or mod.prism, and a directory argument is a tree", a_p3)), fix_p: Text::lit("give it a root, or name its files") });
                    this
                },
            }
        }
    }
}

/// The step machine of `AddArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AddArg: unbounded fn Assembled, (Text ==> [Text]), (Text ==> Text), Text -> Assembled
/// ```
pub struct AddArg {
    pub acc_p0: Assembled,
    pub listings_p1: Map<Text, Array<Text>>,
    pub texts_p2: Map<Text, Text>,
    pub a_p3: Text,
}

impl prism_rtl::Job<Assembled> for AddArg {
    fn cycle(&self) -> prism_rtl::Turn<Assembled> {
        let acc_p0 = &self.acc_p0;
        let listings_p1 = &self.listings_p1;
        let texts_p2 = &self.texts_p2;
        let a_p3 = &self.a_p3;
        if crate::syntax::lexer::chars::has_suffix_f(a_p3, &Text::lit(".prismtest")) {
            prism_rtl::Turn::Finished({
                let mut this: Assembled = acc_p0.clone();
                this.errors_p = crate::prelude::push(&this.errors_p, &TreeDiag { path_p: a_p3.clone(), span_p: no_span_p(), code_p: Text::lit("prismtest"), message_p: Text::from(format!("`{}`: a `.prismtest` is not read: a module\'s tests are in its test modules, a loose file\'s inline", a_p3)), fix_p: Text::lit("move its declarations into a test module (`test mod tests`), or into the file it tests") });
                this
            })
        } else {
            if crate::syntax::lexer::chars::has_suffix_f(a_p3, &Text::lit(".prism")) {
                prism_rtl::Turn::Finished({
                    let mut this: Assembled = acc_p0.clone();
                    this.units_p = crate::prelude::push(&this.units_p, &ModFiles { name_p: Text::lit(""), named_p: false, segs_p: Array::from(vec![Seg { path_p: a_p3.clone(), text_p: crate::prelude::or(&crate::prelude::get(texts_p2, a_p3), &Text::lit("")), role_p: Text::lit("loose") }]), parent_p: Text::lit("") });
                    this
                })
            } else {
                match tree_root_of_o(a_p3, listings_p1) {
                    Some(root_p4) => {
                        let a_p3x = a_p3.clone();
                        let acc_p0x = acc_p0.clone();
                        let listings_p1x = listings_p1.clone();
                        let texts_p2x = texts_p2.clone();
                        crate::prelude::call_then(start_walk_tree_f(root_p4.clone(), crate::prelude::or(&crate::prelude::get(&listings_p1x, &root_p4), &Array::new()), texts_p2x.clone()), move |walk_tree_f_13644: TreeAcc| {
                            let tree_p5 = walk_tree_f_13644;
                            let start_p6 = under_f(&a_p3x, &Text::lit("mod.prism"));
                            let units_p7 = if &root_p4 == &a_p3x {
                                tree_p5.units_p.clone()
                            } else {
                                reach_tree_f(&tree_p5.units_p, &start_p6)
                            };
                            let scripts_p8 = if &root_p4 == &a_p3x {
                                crate::prelude::fold(&units_p7, &Array::new(), &(|s_p9: &Array<Text>, u_pa: &ModFiles| crate::prelude::append(s_p9, &test_paths_f(u_pa))))
                            } else {
                                crate::prelude::fold(&crate::prelude::filter(&units_p7, &(|u_pb: &ModFiles| (&main_path_f(u_pb) == &start_p6) || (&u_pb.parent_p == &start_p6))), &Array::new(), &(|s_pc: &Array<Text>, u_pd: &ModFiles| crate::prelude::append(s_pc, &test_paths_f(u_pd))))
                            };
                            prism_rtl::Turn::Finished({
                                let mut this: Assembled = acc_p0x.clone();
                                this.units_p = crate::prelude::append(&this.units_p, &units_p7);
                                this.scripts_p = crate::prelude::append(&this.scripts_p, &scripts_p8);
                                this.errors_p = crate::prelude::append(&this.errors_p, &tree_p5.diags_p);
                                this
                            })
                        })
                    },
                    None => prism_rtl::Turn::Finished({
                        let mut this: Assembled = acc_p0.clone();
                        this.errors_p = crate::prelude::push(&this.errors_p, &TreeDiag { path_p: a_p3.clone(), span_p: no_span_p(), code_p: Text::lit("no-root"), message_p: Text::from(format!("`{}` holds no app.prism, lib.prism or mod.prism, and a directory argument is a tree", a_p3)), fix_p: Text::lit("give it a root, or name its files") });
                        this
                    }),
                }
            }
        }
    }
}

/// `Start AddArg, x`: what the function value is when passed to `@Run`.
pub fn start_add_arg_f(acc_p0: Assembled, listings_p1: Map<Text, Array<Text>>, texts_p2: Map<Text, Text>, a_p3: Text) -> Rc<dyn prism_rtl::Job<Assembled>> {
    Rc::new(AddArg { acc_p0, listings_p1, texts_p2, a_p3 })
}

/// ```prism
/// MainPath: fn ModFiles -> Text
/// ```
pub fn main_path_f(u_p0: &ModFiles) -> Text {
    match crate::prelude::index(&u_p0.segs_p, &Nat::from(0u32)) {
        Some(s_p1) => s_p1.path_p.clone(),
        None => Text::lit(""),
    }
}

/// ```prism
/// MainText: fn ModFiles -> Text
/// ```
pub fn main_text_f(u_p0: &ModFiles) -> Text {
    match crate::prelude::index(&u_p0.segs_p, &Nat::from(0u32)) {
        Some(s_p1) => s_p1.text_p.clone(),
        None => Text::lit(""),
    }
}

/// ```prism
/// TestPaths: fn ModFiles -> [Text]
/// ```
pub fn test_paths_f(u_p0: &ModFiles) -> Array<Text> {
    crate::prelude::each(&crate::prelude::filter(&u_p0.segs_p, &(|s_p1: &Seg| &s_p1.role_p == &Text::lit("test"))), &(|s_p2: &Seg| s_p2.path_p.clone()))
}

/// ```prism
/// WalkTree: unbounded fn Text, [Text], (Text ==> Text) -> TreeAcc
/// ```
pub fn walk_tree_f(root_p0: &Text, files_p1: &Array<Text>, texts_p2: &Map<Text, Text>) -> TreeAcc {
    let has_p3 = crate::prelude::fold(files_p1, &Map::new(), &(|m_pa: &Map<Text, bool>, f_pb: &Text| crate::prelude::insert(m_pa, f_pb, &true)));
    let app_p4 = under_f(root_p0, &Text::lit("app.prism"));
    let lib_p5 = under_f(root_p0, &Text::lit("lib.prism"));
    let acc0_p6 = TreeAcc { units_p: Array::new(), declared_p: Map::new(), diags_p: Array::new() };
    let acc1_p7 = if crate::check::env::has_key_f(&has_p3, &app_p4) && crate::check::env::has_key_f(&has_p3, &lib_p5) {
        add_tree_diag_f(&acc0_p6, &lib_p5, &no_span_p(), &Text::lit("two-roots"), &Text::lit("`app.prism` and `lib.prism` in one directory: a tree has one root"), &Text::lit("keep app.prism for a program or lib.prism for a library"))
    } else {
        acc0_p6.clone()
    };
    let acc2_p8 = if crate::check::env::has_key_f(&has_p3, &app_p4) {
        walk_module_f(&has_p3, texts_p2, &acc1_p7, &app_p4, &Text::lit(""), &Text::lit(""), &false)
    } else {
        walk_lib_f(&has_p3, texts_p2, &acc1_p7, &lib_p5)
    };
    let acc3_p9 = {
        let mut this: TreeAcc = acc2_p8.clone();
        this.declared_p = crate::prelude::insert(&this.declared_p, &lib_p5, &true);
        this
    };
    crate::prelude::fold(files_p1, &acc3_p9, &(|a_pc: &TreeAcc, f_pd: &Text| if crate::check::env::has_key_f(&a_pc.declared_p, f_pd) {
        a_pc.clone()
    } else {
        stray_f(&has_p3, texts_p2, a_pc, f_pd)
    }))
}

/// The step machine of `WalkTree`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WalkTree: unbounded fn Text, [Text], (Text ==> Text) -> TreeAcc
/// ```
pub struct WalkTree {
    pub root_p0: Text,
    pub files_p1: Array<Text>,
    pub texts_p2: Map<Text, Text>,
}

impl prism_rtl::Job<TreeAcc> for WalkTree {
    fn cycle(&self) -> prism_rtl::Turn<TreeAcc> {
        let root_p0 = &self.root_p0;
        let files_p1 = &self.files_p1;
        let texts_p2 = &self.texts_p2;
        let has_p3 = crate::prelude::fold(files_p1, &Map::new(), &(|m_pa: &Map<Text, bool>, f_pb: &Text| crate::prelude::insert(m_pa, f_pb, &true)));
        let app_p4 = under_f(root_p0, &Text::lit("app.prism"));
        let lib_p5 = under_f(root_p0, &Text::lit("lib.prism"));
        let acc0_p6 = TreeAcc { units_p: Array::new(), declared_p: Map::new(), diags_p: Array::new() };
        let acc1_p7 = if crate::check::env::has_key_f(&has_p3, &app_p4) && crate::check::env::has_key_f(&has_p3, &lib_p5) {
            add_tree_diag_f(&acc0_p6, &lib_p5, &no_span_p(), &Text::lit("two-roots"), &Text::lit("`app.prism` and `lib.prism` in one directory: a tree has one root"), &Text::lit("keep app.prism for a program or lib.prism for a library"))
        } else {
            acc0_p6.clone()
        };
        let acc2_p8 = if crate::check::env::has_key_f(&has_p3, &app_p4) {
            walk_module_f(&has_p3, texts_p2, &acc1_p7, &app_p4, &Text::lit(""), &Text::lit(""), &false)
        } else {
            walk_lib_f(&has_p3, texts_p2, &acc1_p7, &lib_p5)
        };
        let acc3_p9 = {
            let mut this: TreeAcc = acc2_p8.clone();
            this.declared_p = crate::prelude::insert(&this.declared_p, &lib_p5, &true);
            this
        };
        prism_rtl::Turn::Finished(crate::prelude::fold(files_p1, &acc3_p9, &(|a_pc: &TreeAcc, f_pd: &Text| if crate::check::env::has_key_f(&a_pc.declared_p, f_pd) {
            a_pc.clone()
        } else {
            stray_f(&has_p3, texts_p2, a_pc, f_pd)
        })))
    }
}

/// `Start WalkTree, x`: what the function value is when passed to `@Run`.
pub fn start_walk_tree_f(root_p0: Text, files_p1: Array<Text>, texts_p2: Map<Text, Text>) -> Rc<dyn prism_rtl::Job<TreeAcc>> {
    Rc::new(WalkTree { root_p0, files_p1, texts_p2 })
}

/// ```prism
/// WalkLib: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text -> TreeAcc
/// ```
pub fn walk_lib_f(has_p0: &Map<Text, bool>, texts_p1: &Map<Text, Text>, acc_p2: &TreeAcc, lib_p3: &Text) -> TreeAcc {
    let text_p4 = crate::prelude::or(&crate::prelude::get(texts_p1, lib_p3), &Text::lit(""));
    let heads_p5 = header_lines_f(&text_p4);
    let bad_p6 = crate::prelude::filter(&heads_p5, &(|h_pa: &HeadLine| !((&h_pa.word_p == &Text::lit("mod")) && crate::check::env::is_upper_text_f(&h_pa.arg_p))));
    let acc1_p7 = crate::prelude::fold(&bad_p6, acc_p2, &(|a_pb: &TreeAcc, h_pc: &HeadLine| add_tree_diag_f(a_pb, lib_p3, &h_pc.span_p, &Text::lit("lib-header"), &Text::from(format!("lib.prism holds only `mod Name` lines, the library\'s modules: `{}` belongs in a module", &h_pc.word_p)), &Text::lit("move the line to a module\'s mod.prism"))));
    let acc2_p8 = match first_decl_line_o(&text_p4) {
        Some(r_pd) => add_tree_diag_f(&acc1_p7, lib_p3, &r_pd, &Text::lit("lib-header"), &Text::lit("lib.prism holds only `mod Name` lines, the library\'s modules"), &Text::lit("move the declaration to a module")),
        None => acc1_p7.clone(),
    };
    let dir_p9 = dir_of_f(lib_p3);
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::filter(&heads_p5, &(|h_pe: &HeadLine| (&h_pe.word_p == &Text::lit("mod")) && crate::check::env::is_upper_text_f(&h_pe.arg_p))), acc2_p8.clone(), {
        let has_p0x = has_p0.clone();
        let texts_p1x = texts_p1.clone();
        let lib_p3x = lib_p3.clone();
        let dir_p9x = dir_p9.clone();
        Rc::new(move |(p0, p1): (TreeAcc, HeadLine)| {
            let has_p0xy = has_p0x.clone();
            let texts_p1xy = texts_p1x.clone();
            let lib_p3xy = lib_p3x.clone();
            let dir_p9xy = dir_p9x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let a_pf = p0;
                let h_pg = p1;
                prism_rtl::Turn::More(Rc::new(Child { has_p0: has_p0xy.clone(), texts_p1: texts_p1xy.clone(), acc_p2: a_pf.clone(), main_p3: lib_p3xy.clone(), dir_p4: dir_p9xy.clone(), h_p5: h_pg.clone(), parent_p6: Text::lit(""), in_test_p7: false }))
            }))
        }) as Rc<dyn Fn((TreeAcc, HeadLine)) -> Rc<dyn prism_rtl::Job<TreeAcc>>>
    }))
}

/// The step machine of `WalkLib`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WalkLib: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text -> TreeAcc
/// ```
pub struct WalkLib {
    pub has_p0: Map<Text, bool>,
    pub texts_p1: Map<Text, Text>,
    pub acc_p2: TreeAcc,
    pub lib_p3: Text,
}

impl prism_rtl::Job<TreeAcc> for WalkLib {
    fn cycle(&self) -> prism_rtl::Turn<TreeAcc> {
        let has_p0 = &self.has_p0;
        let texts_p1 = &self.texts_p1;
        let acc_p2 = &self.acc_p2;
        let lib_p3 = &self.lib_p3;
        let text_p4 = crate::prelude::or(&crate::prelude::get(texts_p1, lib_p3), &Text::lit(""));
        let heads_p5 = header_lines_f(&text_p4);
        let bad_p6 = crate::prelude::filter(&heads_p5, &(|h_pa: &HeadLine| !((&h_pa.word_p == &Text::lit("mod")) && crate::check::env::is_upper_text_f(&h_pa.arg_p))));
        let acc1_p7 = crate::prelude::fold(&bad_p6, acc_p2, &(|a_pb: &TreeAcc, h_pc: &HeadLine| add_tree_diag_f(a_pb, lib_p3, &h_pc.span_p, &Text::lit("lib-header"), &Text::from(format!("lib.prism holds only `mod Name` lines, the library\'s modules: `{}` belongs in a module", &h_pc.word_p)), &Text::lit("move the line to a module\'s mod.prism"))));
        let acc2_p8 = match first_decl_line_o(&text_p4) {
            Some(r_pd) => add_tree_diag_f(&acc1_p7, lib_p3, &r_pd, &Text::lit("lib-header"), &Text::lit("lib.prism holds only `mod Name` lines, the library\'s modules"), &Text::lit("move the declaration to a module")),
            None => acc1_p7.clone(),
        };
        let dir_p9 = dir_of_f(lib_p3);
        crate::prelude::fold_job(crate::prelude::filter(&heads_p5, &(|h_pe: &HeadLine| (&h_pe.word_p == &Text::lit("mod")) && crate::check::env::is_upper_text_f(&h_pe.arg_p))), acc2_p8.clone(), {
            let has_p0x = has_p0.clone();
            let texts_p1x = texts_p1.clone();
            let lib_p3x = lib_p3.clone();
            let dir_p9x = dir_p9.clone();
            Rc::new(move |(p0, p1): (TreeAcc, HeadLine)| {
                let has_p0xy = has_p0x.clone();
                let texts_p1xy = texts_p1x.clone();
                let lib_p3xy = lib_p3x.clone();
                let dir_p9xy = dir_p9x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pf = p0;
                    let h_pg = p1;
                    prism_rtl::Turn::More(Rc::new(Child { has_p0: has_p0xy.clone(), texts_p1: texts_p1xy.clone(), acc_p2: a_pf.clone(), main_p3: lib_p3xy.clone(), dir_p4: dir_p9xy.clone(), h_p5: h_pg.clone(), parent_p6: Text::lit(""), in_test_p7: false }))
                }))
            }) as Rc<dyn Fn((TreeAcc, HeadLine)) -> Rc<dyn prism_rtl::Job<TreeAcc>>>
        }).cycle()
    }
}

/// `Start WalkLib, x`: what the function value is when passed to `@Run`.
pub fn start_walk_lib_f(has_p0: Map<Text, bool>, texts_p1: Map<Text, Text>, acc_p2: TreeAcc, lib_p3: Text) -> Rc<dyn prism_rtl::Job<TreeAcc>> {
    Rc::new(WalkLib { has_p0, texts_p1, acc_p2, lib_p3 })
}

/// ```prism
/// WalkModule: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text, Text, Bool -> TreeAcc
/// ```
pub fn walk_module_f(has_p0: &Map<Text, bool>, texts_p1: &Map<Text, Text>, acc_p2: &TreeAcc, main_p3: &Text, name_p4: &Text, parent_p5: &Text, in_test_p6: &bool) -> TreeAcc {
    let dir_p7 = dir_of_f(main_p3);
    let text_p8 = crate::prelude::or(&crate::prelude::get(texts_p1, main_p3), &Text::lit(""));
    let heads_p9 = header_lines_f(&text_p8);
    let mods_pa = crate::prelude::filter(&heads_p9, &(|h_pk: &HeadLine| (&h_pk.word_p == &Text::lit("mod")) || (&h_pk.word_p == &Text::lit("test mod"))));
    let subs_pb = crate::prelude::filter(&mods_pa, &(|h_pl: &HeadLine| crate::check::env::is_upper_text_f(&h_pl.arg_p)));
    let lower_pc = crate::prelude::filter(&mods_pa, &(|h_pm: &HeadLine| !crate::check::env::is_upper_text_f(&h_pm.arg_p)));
    let named_pd = if name_p4 == &Text::lit("") {
        Text::lit("its path makes it the root")
    } else {
        Text::from(format!("its path names the module `{}`", name_p4))
    };
    let acc1_pe = crate::prelude::fold(&crate::prelude::filter(&heads_p9, &(|h_pn: &HeadLine| &h_pn.word_p == &Text::lit("module"))), acc_p2, &(|a_po: &TreeAcc, h_pp: &HeadLine| add_tree_diag_f(a_po, main_p3, &h_pp.span_p, &Text::lit("module-line"), &Text::from(format!("a module\'s file has no `module` line: {}", &named_pd)), &Text::lit("delete the line"))));
    let leaf_pf = !crate::check::types::has_text_f(&Array::from(vec![Text::lit("mod.prism"), Text::lit("app.prism"), Text::lit("lib.prism")]), &base_of_f(main_p3));
    let stem_pg = crate::prelude::or(&crate::syntax::lexer::chars::before_suffix_o(&base_of_f(main_p3), &Text::lit(".prism")), main_p3);
    let acc2_ph = if leaf_pf {
        crate::prelude::fold(&mods_pa, &acc1_pe, &(|a_pq: &TreeAcc, h_pr: &HeadLine| add_tree_diag_f(a_pq, main_p3, &h_pr.span_p, &Text::lit("mod-leaf"), &Text::from(format!("`{}` declares `{} {}`, and a module with children is a directory", &base_of_f(main_p3), &h_pr.word_p, &h_pr.arg_p)), &Text::from(format!("move {} to {}/mod.prism", &base_of_f(main_p3), &stem_pg)))))
    } else {
        acc1_pe.clone()
    };
    let acc3_pi = crate::prelude::fold(&lower_pc, &acc2_ph, &(|a_ps: &TreeAcc, h_pt: &HeadLine| lowercase_f(a_ps, main_p3, &dir_p7, h_pt)));
    let acc4_pj = {
        let mut this: TreeAcc = acc3_pi.clone();
        this.declared_p = crate::prelude::insert(&this.declared_p, main_p3, &true);
        this.units_p = crate::prelude::push(&this.units_p, &ModFiles { name_p: name_p4.clone(), named_p: true, segs_p: Array::from(vec![Seg { path_p: main_p3.clone(), text_p: text_p8.clone(), role_p: if *in_test_p6 { Text::lit("test") } else { Text::lit("main") } }]), parent_p: parent_p5.clone() });
        this
    };
    if leaf_pf {
        acc4_pj.clone()
    } else {
        crate::prelude::run_to_end(crate::prelude::fold_job(subs_pb.clone(), acc4_pj.clone(), {
            let has_p0x = has_p0.clone();
            let texts_p1x = texts_p1.clone();
            let main_p3x = main_p3.clone();
            let dir_p7x = dir_p7.clone();
            let name_p4x = name_p4.clone();
            let in_test_p6x = *in_test_p6;
            Rc::new(move |(p0, p1): (TreeAcc, HeadLine)| {
                let has_p0xy = has_p0x.clone();
                let texts_p1xy = texts_p1x.clone();
                let main_p3xy = main_p3x.clone();
                let dir_p7xy = dir_p7x.clone();
                let name_p4xy = name_p4x.clone();
                let in_test_p6xy = in_test_p6x;
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pu = p0;
                    let h_pv = p1;
                    prism_rtl::Turn::More(Rc::new(Child { has_p0: has_p0xy.clone(), texts_p1: texts_p1xy.clone(), acc_p2: a_pu.clone(), main_p3: main_p3xy.clone(), dir_p4: dir_p7xy.clone(), h_p5: h_pv.clone(), parent_p6: name_p4xy.clone(), in_test_p7: in_test_p6xy }))
                }))
            }) as Rc<dyn Fn((TreeAcc, HeadLine)) -> Rc<dyn prism_rtl::Job<TreeAcc>>>
        }))
    }
}

/// The step machine of `WalkModule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WalkModule: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text, Text, Bool -> TreeAcc
/// ```
pub struct WalkModule {
    pub has_p0: Map<Text, bool>,
    pub texts_p1: Map<Text, Text>,
    pub acc_p2: TreeAcc,
    pub main_p3: Text,
    pub name_p4: Text,
    pub parent_p5: Text,
    pub in_test_p6: bool,
}

impl prism_rtl::Job<TreeAcc> for WalkModule {
    fn cycle(&self) -> prism_rtl::Turn<TreeAcc> {
        let has_p0 = &self.has_p0;
        let texts_p1 = &self.texts_p1;
        let acc_p2 = &self.acc_p2;
        let main_p3 = &self.main_p3;
        let name_p4 = &self.name_p4;
        let parent_p5 = &self.parent_p5;
        let in_test_p6 = &self.in_test_p6;
        let dir_p7 = dir_of_f(main_p3);
        let text_p8 = crate::prelude::or(&crate::prelude::get(texts_p1, main_p3), &Text::lit(""));
        let heads_p9 = header_lines_f(&text_p8);
        let mods_pa = crate::prelude::filter(&heads_p9, &(|h_pk: &HeadLine| (&h_pk.word_p == &Text::lit("mod")) || (&h_pk.word_p == &Text::lit("test mod"))));
        let subs_pb = crate::prelude::filter(&mods_pa, &(|h_pl: &HeadLine| crate::check::env::is_upper_text_f(&h_pl.arg_p)));
        let lower_pc = crate::prelude::filter(&mods_pa, &(|h_pm: &HeadLine| !crate::check::env::is_upper_text_f(&h_pm.arg_p)));
        let named_pd = if name_p4 == &Text::lit("") {
            Text::lit("its path makes it the root")
        } else {
            Text::from(format!("its path names the module `{}`", name_p4))
        };
        let acc1_pe = crate::prelude::fold(&crate::prelude::filter(&heads_p9, &(|h_pn: &HeadLine| &h_pn.word_p == &Text::lit("module"))), acc_p2, &(|a_po: &TreeAcc, h_pp: &HeadLine| add_tree_diag_f(a_po, main_p3, &h_pp.span_p, &Text::lit("module-line"), &Text::from(format!("a module\'s file has no `module` line: {}", &named_pd)), &Text::lit("delete the line"))));
        let leaf_pf = !crate::check::types::has_text_f(&Array::from(vec![Text::lit("mod.prism"), Text::lit("app.prism"), Text::lit("lib.prism")]), &base_of_f(main_p3));
        let stem_pg = crate::prelude::or(&crate::syntax::lexer::chars::before_suffix_o(&base_of_f(main_p3), &Text::lit(".prism")), main_p3);
        let acc2_ph = if leaf_pf {
            crate::prelude::fold(&mods_pa, &acc1_pe, &(|a_pq: &TreeAcc, h_pr: &HeadLine| add_tree_diag_f(a_pq, main_p3, &h_pr.span_p, &Text::lit("mod-leaf"), &Text::from(format!("`{}` declares `{} {}`, and a module with children is a directory", &base_of_f(main_p3), &h_pr.word_p, &h_pr.arg_p)), &Text::from(format!("move {} to {}/mod.prism", &base_of_f(main_p3), &stem_pg)))))
        } else {
            acc1_pe.clone()
        };
        let acc3_pi = crate::prelude::fold(&lower_pc, &acc2_ph, &(|a_ps: &TreeAcc, h_pt: &HeadLine| lowercase_f(a_ps, main_p3, &dir_p7, h_pt)));
        let acc4_pj = {
            let mut this: TreeAcc = acc3_pi.clone();
            this.declared_p = crate::prelude::insert(&this.declared_p, main_p3, &true);
            this.units_p = crate::prelude::push(&this.units_p, &ModFiles { name_p: name_p4.clone(), named_p: true, segs_p: Array::from(vec![Seg { path_p: main_p3.clone(), text_p: text_p8.clone(), role_p: if *in_test_p6 { Text::lit("test") } else { Text::lit("main") } }]), parent_p: parent_p5.clone() });
            this
        };
        if leaf_pf {
            prism_rtl::Turn::Finished(acc4_pj.clone())
        } else {
            crate::prelude::fold_job(subs_pb.clone(), acc4_pj.clone(), {
                let has_p0x = has_p0.clone();
                let texts_p1x = texts_p1.clone();
                let main_p3x = main_p3.clone();
                let dir_p7x = dir_p7.clone();
                let name_p4x = name_p4.clone();
                let in_test_p6x = *in_test_p6;
                Rc::new(move |(p0, p1): (TreeAcc, HeadLine)| {
                    let has_p0xy = has_p0x.clone();
                    let texts_p1xy = texts_p1x.clone();
                    let main_p3xy = main_p3x.clone();
                    let dir_p7xy = dir_p7x.clone();
                    let name_p4xy = name_p4x.clone();
                    let in_test_p6xy = in_test_p6x;
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_pu = p0;
                        let h_pv = p1;
                        prism_rtl::Turn::More(Rc::new(Child { has_p0: has_p0xy.clone(), texts_p1: texts_p1xy.clone(), acc_p2: a_pu.clone(), main_p3: main_p3xy.clone(), dir_p4: dir_p7xy.clone(), h_p5: h_pv.clone(), parent_p6: name_p4xy.clone(), in_test_p7: in_test_p6xy }))
                    }))
                }) as Rc<dyn Fn((TreeAcc, HeadLine)) -> Rc<dyn prism_rtl::Job<TreeAcc>>>
            }).cycle()
        }
    }
}

/// `Start WalkModule, x`: what the function value is when passed to `@Run`.
pub fn start_walk_module_f(has_p0: Map<Text, bool>, texts_p1: Map<Text, Text>, acc_p2: TreeAcc, main_p3: Text, name_p4: Text, parent_p5: Text, in_test_p6: bool) -> Rc<dyn prism_rtl::Job<TreeAcc>> {
    Rc::new(WalkModule { has_p0, texts_p1, acc_p2, main_p3, name_p4, parent_p5, in_test_p6 })
}

/// ```prism
/// Lowercase: fn TreeAcc, Text, Text, HeadLine -> TreeAcc
/// ```
pub fn lowercase_f(a_p0: &TreeAcc, main_p1: &Text, dir_p2: &Text, h_p3: &HeadLine) -> TreeAcc {
    let up_p4 = Text::from(format!("{}{}", &crate::prelude::upper(&crate::syntax::lexer::chars::head_f(&h_p3.arg_p)), &crate::syntax::lexer::chars::after_first_f(&h_p3.arg_p)));
    let marked_p5 = {
        let mut this: TreeAcc = a_p0.clone();
        this.declared_p = crate::prelude::insert(&this.declared_p, &under_f(dir_p2, &Text::from(format!("{}.prism", &h_p3.arg_p))), &true);
        this
    };
    add_tree_diag_f(&marked_p5, main_p1, &h_p3.span_p, &Text::lit("mod-lowercase"), &Text::from(format!("`{} {}`: a module\'s name is capitalised, and every `mod` line declares a module with a namespace of its own", &h_p3.word_p, &h_p3.arg_p)), &Text::from(format!("write `{} {}` (its file {}.prism, with a header of its own)", &h_p3.word_p, &up_p4, &h_p3.arg_p)))
}

/// ```prism
/// Child: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text, HeadLine, Text, Bool -> TreeAcc
/// ```
pub fn child_f(has_p0: &Map<Text, bool>, texts_p1: &Map<Text, Text>, acc_p2: &TreeAcc, main_p3: &Text, dir_p4: &Text, h_p5: &HeadLine, parent_p6: &Text, in_test_p7: &bool) -> TreeAcc {
    let snake_p8 = dir_name_f(&h_p5.arg_p);
    let file_p9 = under_f(dir_p4, &Text::from(format!("{}.prism", &snake_p8)));
    let nested_pa = under_f(dir_p4, &Text::from(format!("{}/mod.prism", &snake_p8)));
    let name_pb = if parent_p6 == &Text::lit("") {
        h_p5.arg_p.clone()
    } else {
        Text::from(format!("{}.{}", parent_p6, &h_p5.arg_p))
    };
    let is_test_pc = *in_test_p7 || (&h_p5.word_p == &Text::lit("test mod"));
    let line_pd = Text::from(format!("{} {}", &h_p5.word_p, &h_p5.arg_p));
    if (&file_p9 == main_p3) || (&nested_pa == main_p3) {
        add_tree_diag_f(acc_p2, main_p3, &h_p5.span_p, &Text::lit("mod-self"), &Text::from(format!("`{}` names `{}`, the file that declares it", &line_pd, &base_of_f(main_p3))), &Text::lit("rename the module"))
    } else {
        if crate::check::env::has_key_f(has_p0, &file_p9) && crate::check::env::has_key_f(has_p0, &nested_pa) {
            {
                let both_pe = {
                    let mut this: TreeAcc = acc_p2.clone();
                    this.declared_p = crate::prelude::insert(&crate::prelude::insert(&this.declared_p, &file_p9, &true), &nested_pa, &true);
                    this
                };
                add_tree_diag_f(&both_pe, main_p3, &h_p5.span_p, &Text::lit("mod-both"), &Text::from(format!("`{}` declares `{}.prism` or `{}/mod.prism`, and both are there", &line_pd, &snake_p8, &snake_p8)), &Text::from(format!("keep one: {}/mod.prism when the module has children, else {}.prism", &snake_p8, &snake_p8)))
            }
        } else {
            if crate::check::env::has_key_f(has_p0, &file_p9) {
                walk_module_f(has_p0, texts_p1, acc_p2, &file_p9, &name_pb, main_p3, &is_test_pc)
            } else {
                if crate::check::env::has_key_f(has_p0, &nested_pa) {
                    walk_module_f(has_p0, texts_p1, acc_p2, &nested_pa, &name_pb, main_p3, &is_test_pc)
                } else {
                    add_tree_diag_f(acc_p2, main_p3, &h_p5.span_p, &Text::lit("mod-missing"), &Text::from(format!("`{}` declares `{}.prism` or `{}/mod.prism`, and neither is there", &line_pd, &snake_p8, &snake_p8)), &Text::from(format!("create {}.prism, or delete the line", &snake_p8)))
                }
            }
        }
    }
}

/// The step machine of `Child`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Child: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text, HeadLine, Text, Bool -> TreeAcc
/// ```
pub struct Child {
    pub has_p0: Map<Text, bool>,
    pub texts_p1: Map<Text, Text>,
    pub acc_p2: TreeAcc,
    pub main_p3: Text,
    pub dir_p4: Text,
    pub h_p5: HeadLine,
    pub parent_p6: Text,
    pub in_test_p7: bool,
}

impl prism_rtl::Job<TreeAcc> for Child {
    fn cycle(&self) -> prism_rtl::Turn<TreeAcc> {
        let has_p0 = &self.has_p0;
        let texts_p1 = &self.texts_p1;
        let acc_p2 = &self.acc_p2;
        let main_p3 = &self.main_p3;
        let dir_p4 = &self.dir_p4;
        let h_p5 = &self.h_p5;
        let parent_p6 = &self.parent_p6;
        let in_test_p7 = &self.in_test_p7;
        let snake_p8 = dir_name_f(&h_p5.arg_p);
        let file_p9 = under_f(dir_p4, &Text::from(format!("{}.prism", &snake_p8)));
        let nested_pa = under_f(dir_p4, &Text::from(format!("{}/mod.prism", &snake_p8)));
        let name_pb = if parent_p6 == &Text::lit("") {
            h_p5.arg_p.clone()
        } else {
            Text::from(format!("{}.{}", parent_p6, &h_p5.arg_p))
        };
        let is_test_pc = *in_test_p7 || (&h_p5.word_p == &Text::lit("test mod"));
        let line_pd = Text::from(format!("{} {}", &h_p5.word_p, &h_p5.arg_p));
        if (&file_p9 == main_p3) || (&nested_pa == main_p3) {
            prism_rtl::Turn::Finished(add_tree_diag_f(acc_p2, main_p3, &h_p5.span_p, &Text::lit("mod-self"), &Text::from(format!("`{}` names `{}`, the file that declares it", &line_pd, &base_of_f(main_p3))), &Text::lit("rename the module")))
        } else {
            if crate::check::env::has_key_f(has_p0, &file_p9) && crate::check::env::has_key_f(has_p0, &nested_pa) {
                {
                    let both_pe = {
                        let mut this: TreeAcc = acc_p2.clone();
                        this.declared_p = crate::prelude::insert(&crate::prelude::insert(&this.declared_p, &file_p9, &true), &nested_pa, &true);
                        this
                    };
                    prism_rtl::Turn::Finished(add_tree_diag_f(&both_pe, main_p3, &h_p5.span_p, &Text::lit("mod-both"), &Text::from(format!("`{}` declares `{}.prism` or `{}/mod.prism`, and both are there", &line_pd, &snake_p8, &snake_p8)), &Text::from(format!("keep one: {}/mod.prism when the module has children, else {}.prism", &snake_p8, &snake_p8))))
                }
            } else {
                if crate::check::env::has_key_f(has_p0, &file_p9) {
                    prism_rtl::Turn::More(Rc::new(WalkModule { has_p0: has_p0.clone(), texts_p1: texts_p1.clone(), acc_p2: acc_p2.clone(), main_p3: file_p9.clone(), name_p4: name_pb.clone(), parent_p5: main_p3.clone(), in_test_p6: is_test_pc }))
                } else {
                    if crate::check::env::has_key_f(has_p0, &nested_pa) {
                        prism_rtl::Turn::More(Rc::new(WalkModule { has_p0: has_p0.clone(), texts_p1: texts_p1.clone(), acc_p2: acc_p2.clone(), main_p3: nested_pa.clone(), name_p4: name_pb.clone(), parent_p5: main_p3.clone(), in_test_p6: is_test_pc }))
                    } else {
                        prism_rtl::Turn::Finished(add_tree_diag_f(acc_p2, main_p3, &h_p5.span_p, &Text::lit("mod-missing"), &Text::from(format!("`{}` declares `{}.prism` or `{}/mod.prism`, and neither is there", &line_pd, &snake_p8, &snake_p8)), &Text::from(format!("create {}.prism, or delete the line", &snake_p8))))
                    }
                }
            }
        }
    }
}

/// `Start Child, x`: what the function value is when passed to `@Run`.
pub fn start_child_f(has_p0: Map<Text, bool>, texts_p1: Map<Text, Text>, acc_p2: TreeAcc, main_p3: Text, dir_p4: Text, h_p5: HeadLine, parent_p6: Text, in_test_p7: bool) -> Rc<dyn prism_rtl::Job<TreeAcc>> {
    Rc::new(Child { has_p0, texts_p1, acc_p2, main_p3, dir_p4, h_p5, parent_p6, in_test_p7 })
}

/// ```prism
/// Stray: fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text -> TreeAcc
/// ```
pub fn stray_f(has_p0: &Map<Text, bool>, texts_p1: &Map<Text, Text>, acc_p2: &TreeAcc, f_p3: &Text) -> TreeAcc {
    let text_p4 = crate::prelude::or(&crate::prelude::get(texts_p1, f_p3), &Text::lit(""));
    if crate::syntax::lexer::chars::has_suffix_f(f_p3, &Text::lit(".prismtest")) {
        add_tree_diag_f(acc_p2, f_p3, &no_span_p(), &Text::lit("mod-stray"), &Text::from(format!("`{}` is a test script in a tree, where tests are in test modules", &base_of_f(f_p3))), &Text::lit("put its declarations in a test module, declared by `test mod Tests`"))
    } else {
        {
            let dir_p5 = dir_of_f(f_p3);
            let is_main_p6 = &base_of_f(f_p3) == &Text::lit("mod.prism");
            let home_p7 = if is_main_p6 { dir_of_f(&dir_p5) } else { dir_p5.clone() };
            let main_p8 = crate::prelude::fold(&Array::from(vec![Text::lit("mod.prism"), Text::lit("app.prism"), Text::lit("lib.prism")]), &Text::lit(""), &(|m_pb: &Text, n_pc: &Text| if (m_pb == &Text::lit("")) && crate::check::env::has_key_f(has_p0, &under_f(&home_p7, n_pc)) {
                n_pc.clone()
            } else {
                m_pb.clone()
            }));
            let line_p9 = if is_main_p6 {
                Text::from(format!("mod {}", &mod_of_dir_f(&base_of_f(&dir_p5))))
            } else {
                Text::from(format!("mod {}", &mod_of_dir_f(&crate::prelude::or(&crate::syntax::lexer::chars::before_suffix_o(&base_of_f(f_p3), &Text::lit(".prism")), f_p3))))
            };
            let shown_pa = if is_main_p6 {
                Text::from(format!("{}/mod.prism", &base_of_f(&dir_p5)))
            } else {
                base_of_f(f_p3)
            };
            if &main_p8 == &Text::lit("") {
                add_tree_diag_f(acc_p2, f_p3, &no_span_p(), &Text::lit("mod-stray"), &Text::from(format!("`{}` is in a tree, in no module\'s directory", f_p3)), &Text::lit("move it into a module\'s directory and declare it with a `mod` line"))
            } else {
                add_tree_diag_f(acc_p2, f_p3, &no_span_p(), &Text::lit("mod-stray"), &Text::from(format!("`{}` is in the directory of `{}`, which declares no `{}`", &shown_pa, &main_p8, &line_p9)), &Text::from(format!("declare it with `{}` in {}, or move it out of the directory", &line_p9, &main_p8)))
            }
        }
    }
}

/// ```prism
/// ReachTree: unbounded fn [ModFiles], Text -> [ModFiles]
/// ```
pub fn reach_tree_f(units_p0: &Array<ModFiles>, main_p1: &Text) -> Array<ModFiles> {
    let by_name_p2 = crate::prelude::fold(units_p0, &Map::new(), &(|m_p5: &Map<Text, ModFiles>, u_p6: &ModFiles| crate::prelude::insert(m_p5, &unit_name_f(u_p6), u_p6)));
    let start_p3 = crate::prelude::fold(units_p0, &Array::new(), &(|s_p7: &Array<Text>, u_p8: &ModFiles| if (&main_path_f(u_p8) == main_p1) || ((&u_p8.parent_p == main_p1) && is_test_unit_f(u_p8)) {
        crate::prelude::push(s_p7, &unit_name_f(u_p8))
    } else {
        s_p7.clone()
    }));
    let reached_p4 = reach_names_f(&by_name_p2, &start_p3, &start_p3);
    crate::prelude::filter(units_p0, &(|u_p9: &ModFiles| crate::check::types::has_text_f(&reached_p4, &unit_name_f(u_p9))))
}

/// The step machine of `ReachTree`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReachTree: unbounded fn [ModFiles], Text -> [ModFiles]
/// ```
pub struct ReachTree {
    pub units_p0: Array<ModFiles>,
    pub main_p1: Text,
}

impl prism_rtl::Job<Array<ModFiles>> for ReachTree {
    fn cycle(&self) -> prism_rtl::Turn<Array<ModFiles>> {
        let units_p0 = &self.units_p0;
        let main_p1 = &self.main_p1;
        let by_name_p2 = crate::prelude::fold(units_p0, &Map::new(), &(|m_p5: &Map<Text, ModFiles>, u_p6: &ModFiles| crate::prelude::insert(m_p5, &unit_name_f(u_p6), u_p6)));
        let start_p3 = crate::prelude::fold(units_p0, &Array::new(), &(|s_p7: &Array<Text>, u_p8: &ModFiles| if (&main_path_f(u_p8) == main_p1) || ((&u_p8.parent_p == main_p1) && is_test_unit_f(u_p8)) {
            crate::prelude::push(s_p7, &unit_name_f(u_p8))
        } else {
            s_p7.clone()
        }));
        let units_p0x = units_p0.clone();
        crate::prelude::call_then(start_reach_names_f(by_name_p2.clone(), start_p3.clone(), start_p3.clone()), move |reach_names_f_22458: Array<Text>| {
            let reached_p4 = reach_names_f_22458;
            prism_rtl::Turn::Finished(crate::prelude::filter(&units_p0x, &(|u_p9: &ModFiles| crate::check::types::has_text_f(&reached_p4, &unit_name_f(u_p9)))))
        })
    }
}

/// `Start ReachTree, x`: what the function value is when passed to `@Run`.
pub fn start_reach_tree_f(units_p0: Array<ModFiles>, main_p1: Text) -> Rc<dyn prism_rtl::Job<Array<ModFiles>>> {
    Rc::new(ReachTree { units_p0, main_p1 })
}

/// ```prism
/// ReachNames: unbounded fn (Text ==> ModFiles), [Text], [Text] -> [Text]
/// ```
pub fn reach_names_f(by_name_p0: &Map<Text, ModFiles>, seen_p1: &Array<Text>, todo_p2: &Array<Text>) -> Array<Text> {
    match crate::prelude::index(todo_p2, &Nat::from(0u32)) {
        None => seen_p1.clone(),
        Some(n_p3) => {
            let uses_p4 = match crate::prelude::get(by_name_p0, &n_p3) {
                Some(u_p6) => crate::prelude::each(&crate::prelude::filter(&header_lines_f(&main_text_f(&u_p6)), &(|h_p7: &HeadLine| &h_p7.word_p == &Text::lit("use"))), &(|h_p8: &HeadLine| use_target_f(by_name_p0, &h_p8.arg_p))),
                None => Array::new(),
            };
            let fresh_p5 = crate::prelude::filter(&uses_p4, &(|x_p9: &Text| !crate::check::types::has_text_f(seen_p1, x_p9) && crate::check::env::has_key_f(by_name_p0, x_p9)));
            reach_names_f(by_name_p0, &crate::check::types::union_texts_f(seen_p1, &fresh_p5), &crate::prelude::append(&crate::prelude::drop(todo_p2, &Nat::from(1u32)), &fresh_p5))
        },
    }
}

/// The step machine of `ReachNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReachNames: unbounded fn (Text ==> ModFiles), [Text], [Text] -> [Text]
/// ```
pub struct ReachNames {
    pub by_name_p0: Map<Text, ModFiles>,
    pub seen_p1: Array<Text>,
    pub todo_p2: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for ReachNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let by_name_p0 = &self.by_name_p0;
        let seen_p1 = &self.seen_p1;
        let todo_p2 = &self.todo_p2;
        match crate::prelude::index(todo_p2, &Nat::from(0u32)) {
            None => prism_rtl::Turn::Finished(seen_p1.clone()),
            Some(n_p3) => {
                let uses_p4 = match crate::prelude::get(by_name_p0, &n_p3) {
                    Some(u_p6) => crate::prelude::each(&crate::prelude::filter(&header_lines_f(&main_text_f(&u_p6)), &(|h_p7: &HeadLine| &h_p7.word_p == &Text::lit("use"))), &(|h_p8: &HeadLine| use_target_f(by_name_p0, &h_p8.arg_p))),
                    None => Array::new(),
                };
                let fresh_p5 = crate::prelude::filter(&uses_p4, &(|x_p9: &Text| !crate::check::types::has_text_f(seen_p1, x_p9) && crate::check::env::has_key_f(by_name_p0, x_p9)));
                prism_rtl::Turn::More(Rc::new(ReachNames { by_name_p0: by_name_p0.clone(), seen_p1: crate::check::types::union_texts_f(seen_p1, &fresh_p5), todo_p2: crate::prelude::append(&crate::prelude::drop(todo_p2, &Nat::from(1u32)), &fresh_p5) }))
            },
        }
    }
}

/// `Start ReachNames, x`: what the function value is when passed to `@Run`.
pub fn start_reach_names_f(by_name_p0: Map<Text, ModFiles>, seen_p1: Array<Text>, todo_p2: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ReachNames { by_name_p0, seen_p1, todo_p2 })
}

/// ```prism
/// UseTarget: fn (Text ==> ModFiles), Text -> Text
/// ```
pub fn use_target_f(by_name_p0: &Map<Text, ModFiles>, u_p1: &Text) -> Text {
    if (u_p1 == &Text::lit("App")) && !crate::check::env::has_key_f(by_name_p0, &Text::lit("App")) {
        Text::lit("")
    } else {
        u_p1.clone()
    }
}

/// ```prism
/// IsTestUnit: fn ModFiles -> Bool
/// ```
pub fn is_test_unit_f(u_p0: &ModFiles) -> bool {
    match crate::prelude::index(&u_p0.segs_p, &Nat::from(0u32)) {
        Some(s_p1) => &s_p1.role_p == &Text::lit("test"),
        None => false,
    }
}

/// ```prism
/// UnitName: fn ModFiles -> Text
/// ```
pub fn unit_name_f(u_p0: &ModFiles) -> Text {
    if u_p0.named_p {
        u_p0.name_p.clone()
    } else {
        crate::prelude::fold(&header_lines_f(&main_text_f(u_p0)), &Text::lit(""), &(|n_p1: &Text, h_p2: &HeadLine| if &h_p2.word_p == &Text::lit("module") { h_p2.arg_p.clone() } else { n_p1.clone() }))
    }
}

/// ```prism
/// RenderTreeDiag: fn (Text ==> Text), TreeDiag -> Text
/// ```
pub fn render_tree_diag_f(texts_p0: &Map<Text, Text>, d_p1: &TreeDiag) -> Text {
    crate::check::errors::render_cdiag_f(&Array::from(vec![crate::check::errors::mk_src_f(&d_p1.path_p, &crate::prelude::or(&crate::prelude::get(texts_p0, &d_p1.path_p), &Text::lit("")))]), &crate::check::errors::CDiag { code_p: d_p1.code_p.clone(), file_p: Nat::from(0u32), span_p: d_p1.span_p.clone(), message_p: d_p1.message_p.clone(), fix_p: d_p1.fix_p.clone() })
}

/// ```prism
/// TreeReport: fn ReadInput, [TreeDiag] -> Text
/// ```
pub fn tree_report_f(input_p0: &ReadInput, ds_p1: &Array<TreeDiag>) -> Text {
    let texts_p2 = crate::prelude::map(&input_p0.texts_p);
    let n_p3 = crate::prelude::len(ds_p1);
    Text::from(format!("{}{} error{}", &crate::prelude::concat(&crate::prelude::each(ds_p1, &(|d_p4: &TreeDiag| render_tree_diag_f(&texts_p2, d_p4)))), &n_p3, &(if &n_p3 == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") })))
}

/// ```prism
/// ParseUnit: unbounded fn ModFiles -> ((Src, Parsed))
/// ```
pub fn parse_unit_f(u_p0: &ModFiles) -> (crate::check::errors::Src, crate::syntax::parser::Parsed) {
    let src_p1 = crate::check::errors::mk_joined_src_f(&crate::prelude::each(&u_p0.segs_p, &(|s_p5: &Seg| (s_p5.path_p.clone(), s_p5.text_p.clone(), s_p5.role_p.clone()))));
    let parsed_p2 = crate::syntax::parser::parse_file_f(&src_p1.text_p);
    let t0_p3 = parsed_p2.tree_p.clone();
    let tree_p4 = if !u_p0.named_p {
        t0_p3.clone()
    } else {
        {
            let mut this: crate::syntax::Module = t0_p3.clone();
            this.name_o = if &u_p0.name_p == &Text::lit("") {
                None
            } else {
                Some(crate::syntax::QualName { path_p: crate::prelude::split_on(&u_p0.name_p, &Text::lit(".")), span_p: no_span_p() })
            };
            this
        }
    };
    (src_p1.clone(), crate::syntax::parser::Parsed { tree_p: tree_p4.clone(), diags_p: parsed_p2.diags_p.clone() })
}

/// The step machine of `ParseUnit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseUnit: unbounded fn ModFiles -> ((Src, Parsed))
/// ```
pub struct ParseUnit {
    pub u_p0: ModFiles,
}

impl prism_rtl::Job<(crate::check::errors::Src, crate::syntax::parser::Parsed)> for ParseUnit {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::errors::Src, crate::syntax::parser::Parsed)> {
        let u_p0 = &self.u_p0;
        let src_p1 = crate::check::errors::mk_joined_src_f(&crate::prelude::each(&u_p0.segs_p, &(|s_p5: &Seg| (s_p5.path_p.clone(), s_p5.text_p.clone(), s_p5.role_p.clone()))));
        let u_p0x = u_p0.clone();
        crate::prelude::call_then(crate::syntax::parser::start_parse_file_f(src_p1.text_p.clone()), move |parse_file_f_24471: crate::syntax::parser::Parsed| {
            let parsed_p2 = parse_file_f_24471;
            let t0_p3 = parsed_p2.tree_p.clone();
            let tree_p4 = if !u_p0x.named_p {
                t0_p3.clone()
            } else {
                {
                    let mut this: crate::syntax::Module = t0_p3.clone();
                    this.name_o = if &u_p0x.name_p == &Text::lit("") {
                        None
                    } else {
                        Some(crate::syntax::QualName { path_p: crate::prelude::split_on(&u_p0x.name_p, &Text::lit(".")), span_p: no_span_p() })
                    };
                    this
                }
            };
            prism_rtl::Turn::Finished((src_p1.clone(), crate::syntax::parser::Parsed { tree_p: tree_p4.clone(), diags_p: parsed_p2.diags_p.clone() }))
        })
    }
}

/// `Start ParseUnit, x`: what the function value is when passed to `@Run`.
pub fn start_parse_unit_f(u_p0: ModFiles) -> Rc<dyn prism_rtl::Job<(crate::check::errors::Src, crate::syntax::parser::Parsed)>> {
    Rc::new(ParseUnit { u_p0 })
}

/// ```prism
/// ParseProgram: unbounded fn Assembled -> ParsedProgram
/// ```
pub fn parse_program_f(read_p0: &Assembled) -> ParsedProgram {
    let parsed_p1 = crate::prelude::run_to_end(crate::prelude::each_job(read_p0.units_p.clone(), Rc::new(move |p0: ModFiles| crate::prelude::entered(crate::prelude::once_job(move || {
        let u_p8 = p0;
        prism_rtl::Turn::More(Rc::new(ParseUnit { u_p0: u_p8.clone() }))
    }))) as Rc<dyn Fn(ModFiles) -> Rc<dyn prism_rtl::Job<(crate::check::errors::Src, crate::syntax::parser::Parsed)>>>));
    let user_mods_p2 = crate::prelude::fold(&parsed_p1, &Array::new(), &(|acc_p9: &Array<Text>, (_, p_pa): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| crate::prelude::push(acc_p9, &crate::check::env::mod_name_f(&p_pa.tree_p))));
    let user_fams_p3 = crate::prelude::fold(&parsed_p1, &Array::new(), &(|acc_pb: &Array<Text>, (_, p_pc): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| crate::prelude::append(acc_pb, &tag_families_f(&p_pc.tree_p))));
    let pre_parsed_p4 = crate::prelude::run_to_end(crate::prelude::each_job(read_p0.prelude_p.clone(), Rc::new(move |p0: ModFiles| crate::prelude::entered(crate::prelude::once_job(move || {
        let u_pd = p0;
        prism_rtl::Turn::More(Rc::new(ParseUnit { u_p0: u_pd.clone() }))
    }))) as Rc<dyn Fn(ModFiles) -> Rc<dyn prism_rtl::Job<(crate::check::errors::Src, crate::syntax::parser::Parsed)>>>));
    let kept_p5 = crate::prelude::filter(&pre_parsed_p4, &(|(_, p_pe): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| !crate::check::types::has_text_f(&user_mods_p2, &crate::check::env::mod_name_f(&p_pe.tree_p)) && !any_in_f(&tag_families_f(&p_pe.tree_p), &user_fams_p3)));
    let all_p6 = crate::prelude::append(&parsed_p1, &kept_p5);
    let errors_p7 = crate::prelude::fold(&all_p6, &Text::lit(""), &(|acc_pf: &Text, (src_pg, p_ph): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| if crate::program::any_errors_f(&p_ph.diags_p) {
        Text::from(format!("{}{}", acc_pf, &render_parse_f(src_pg, &p_ph.diags_p)))
    } else {
        acc_pf.clone()
    }));
    ParsedProgram { srcs_p: crate::prelude::each(&all_p6, &(|(s_pi, _): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| s_pi.clone())), trees_p: crate::prelude::each(&all_p6, &(|(_, p_pj): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| p_pj.tree_p.clone())), shown_p: crate::prelude::len(&parsed_p1), parents_p: crate::prelude::each(&read_p0.units_p, &(|u_pk: &ModFiles| u_pk.parent_p.clone())), errors_p: errors_p7.clone() }
}

/// The step machine of `ParseProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseProgram: unbounded fn Assembled -> ParsedProgram
/// ```
pub struct ParseProgram {
    pub read_p0: Assembled,
}

impl prism_rtl::Job<ParsedProgram> for ParseProgram {
    fn cycle(&self) -> prism_rtl::Turn<ParsedProgram> {
        let read_p0 = &self.read_p0;
        let read_p0x = read_p0.clone();
        crate::prelude::call_value(crate::prelude::each_job(read_p0x.units_p.clone(), Rc::new(move |p0: ModFiles| crate::prelude::entered(crate::prelude::once_job(move || {
            let u_p8 = p0;
            prism_rtl::Turn::More(Rc::new(ParseUnit { u_p0: u_p8.clone() }))
        }))) as Rc<dyn Fn(ModFiles) -> Rc<dyn prism_rtl::Job<(crate::check::errors::Src, crate::syntax::parser::Parsed)>>>), move |each_25155: Array<(crate::check::errors::Src, crate::syntax::parser::Parsed)>| {
            let parsed_p1 = each_25155;
            let user_mods_p2 = crate::prelude::fold(&parsed_p1, &Array::new(), &(|acc_p9: &Array<Text>, (_, p_pa): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| crate::prelude::push(acc_p9, &crate::check::env::mod_name_f(&p_pa.tree_p))));
            let user_fams_p3 = crate::prelude::fold(&parsed_p1, &Array::new(), &(|acc_pb: &Array<Text>, (_, p_pc): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| crate::prelude::append(acc_pb, &tag_families_f(&p_pc.tree_p))));
            crate::prelude::call_value(crate::prelude::each_job(read_p0x.prelude_p.clone(), Rc::new(move |p0: ModFiles| crate::prelude::entered(crate::prelude::once_job(move || {
                let u_pd = p0;
                prism_rtl::Turn::More(Rc::new(ParseUnit { u_p0: u_pd.clone() }))
            }))) as Rc<dyn Fn(ModFiles) -> Rc<dyn prism_rtl::Job<(crate::check::errors::Src, crate::syntax::parser::Parsed)>>>), move |each_25389: Array<(crate::check::errors::Src, crate::syntax::parser::Parsed)>| {
                let pre_parsed_p4 = each_25389;
                let kept_p5 = crate::prelude::filter(&pre_parsed_p4, &(|(_, p_pe): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| !crate::check::types::has_text_f(&user_mods_p2, &crate::check::env::mod_name_f(&p_pe.tree_p)) && !any_in_f(&tag_families_f(&p_pe.tree_p), &user_fams_p3)));
                let all_p6 = crate::prelude::append(&parsed_p1, &kept_p5);
                let errors_p7 = crate::prelude::fold(&all_p6, &Text::lit(""), &(|acc_pf: &Text, (src_pg, p_ph): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| if crate::program::any_errors_f(&p_ph.diags_p) {
                    Text::from(format!("{}{}", acc_pf, &render_parse_f(src_pg, &p_ph.diags_p)))
                } else {
                    acc_pf.clone()
                }));
                prism_rtl::Turn::Finished(ParsedProgram { srcs_p: crate::prelude::each(&all_p6, &(|(s_pi, _): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| s_pi.clone())), trees_p: crate::prelude::each(&all_p6, &(|(_, p_pj): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| p_pj.tree_p.clone())), shown_p: crate::prelude::len(&parsed_p1), parents_p: crate::prelude::each(&read_p0x.units_p, &(|u_pk: &ModFiles| u_pk.parent_p.clone())), errors_p: errors_p7.clone() })
            })
        })
    }
}

/// `Start ParseProgram, x`: what the function value is when passed to `@Run`.
pub fn start_parse_program_f(read_p0: Assembled) -> Rc<dyn prism_rtl::Job<ParsedProgram>> {
    Rc::new(ParseProgram { read_p0 })
}

/// ```prism
/// TreeDeclDiags: fn ParsedProgram -> [CDiag]
/// ```
pub fn tree_decl_diags_f(pp_p0: &ParsedProgram) -> Array<crate::check::errors::CDiag> {
    crate::prelude::fold(&crate::check::errors::range0_f(&pp_p0.shown_p), &Array::new(), &(|acc_p1: &Array<crate::check::errors::CDiag>, i_p2: &Nat| match crate::prelude::index(&pp_p0.srcs_p, i_p2) {
        Some(src_p3) => crate::prelude::fold(&crate::prelude::or(&crate::prelude::index(&pp_p0.trees_p, i_p2), &crate::check::env::empty_module_p()).decls_p, acc_p1, &(|a_p4: &Array<crate::check::errors::CDiag>, d_p5: &crate::syntax::decls::Decl| crate::prelude::append(a_p4, &decl_role_diags_f(&src_p3, &crate::prelude::or(&crate::prelude::index(&pp_p0.parents_p, i_p2), &Text::lit("")), i_p2, d_p5)))),
        None => acc_p1.clone(),
    }))
}

/// ```prism
/// DeclRoleDiags: fn Src, Text, Nat, Decl -> [CDiag]
/// ```
pub fn decl_role_diags_f(src_p0: &crate::check::errors::Src, parent_p1: &Text, i_p2: &Nat, d_p3: &crate::syntax::decls::Decl) -> Array<crate::check::errors::CDiag> {
    let seg_p4 = crate::check::errors::seg_at_f(src_p0, &d_p3.span_p.start_p);
    let role_p5 = seg_p4.role_p.clone();
    let main_p6 = base_of_f(&src_p0.path_p);
    let tested_p7 = if (&seg_p4.path_p == &src_p0.path_p) && (parent_p1 != &Text::lit("")) {
        base_of_f(parent_p1)
    } else {
        main_p6.clone()
    };
    let what_p8 = match &d_p3.kind_p {
        crate::syntax::decls::DeclKind::DTest(_) => Text::lit("test"),
        crate::syntax::decls::DeclKind::DCheck(_) => Text::lit("check"),
        crate::syntax::decls::DeclKind::DTag(_) => Text::lit("tag"),
        crate::syntax::decls::DeclKind::DTrait(_) => Text::lit("trait"),
        crate::syntax::decls::DeclKind::DImpl(_) => Text::lit("impl"),
        _ => Text::lit(""),
    };
    if (&role_p5 == &Text::lit("main")) && ((&what_p8 == &Text::lit("test")) || (&what_p8 == &Text::lit("check"))) {
        Array::from(vec![crate::check::errors::CDiag { code_p: Text::lit("test-outside"), file_p: i_p2.clone(), span_p: d_p3.span_p.clone(), message_p: Text::from(format!("a `{}` in a tree stands only in a test module", &what_p8)), fix_p: Text::from(format!("move it to a test module: `test mod Tests` in {}, and tests.prism", &main_p6)) }])
    } else {
        if (&role_p5 == &Text::lit("test")) && (((&what_p8 == &Text::lit("tag")) || (&what_p8 == &Text::lit("trait"))) || (&what_p8 == &Text::lit("impl"))) {
            Array::from(vec![crate::check::errors::CDiag { code_p: Text::lit("test-declares"), file_p: i_p2.clone(), span_p: d_p3.span_p.clone(), message_p: Text::lit("a test module declares no tag, trait or impl"), fix_p: Text::from(format!("declare it in {}, the module the test module tests", &tested_p7)) }])
        } else {
            Array::new()
        }
    }
}

/// ```prism
/// TagFamilies: fn Module -> [Text]
/// ```
pub fn tag_families_f(m_p0: &crate::syntax::Module) -> Array<Text> {
    crate::prelude::fold(&m_p0.decls_p, &Array::new(), &(|acc_p1: &Array<Text>, d_p2: &crate::syntax::decls::Decl| match &d_p2.kind_p {
        crate::syntax::decls::DeclKind::DTag(t_p3) => crate::prelude::push(acc_p1, &crate::syntax::lexer::chars::join_f(&crate::prelude::take(&t_p3.name_p.path_p, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&t_p3.name_p.path_p))), &Text::lit("."))),
        _ => acc_p1.clone(),
    }))
}

/// ```prism
/// AnyIn: fn [Text], [Text] -> Bool
/// ```
pub fn any_in_f(xs_p0: &Array<Text>, ys_p1: &Array<Text>) -> bool {
    crate::prelude::fold(xs_p0, &false, &(|seen_p2: &bool, x_p3: &Text| *seen_p2 || crate::check::types::has_text_f(ys_p1, x_p3)))
}

/// ```prism
/// RenderParse: fn Src, [Diag] -> Text
/// ```
pub fn render_parse_f(src_p0: &crate::check::errors::Src, ds_p1: &Array<crate::syntax::Diag>) -> Text {
    crate::prelude::concat(&crate::prelude::each(&crate::prelude::filter(ds_p1, &(|d_p2: &crate::syntax::Diag| &d_p2.stage_p != &Text::lit("out"))), &(|d_p3: &crate::syntax::Diag| Text::from(format!("{}:{}: {}\n", &crate::check::errors::src_place_f(src_p0, &d_p3.span_p.start_p), &(&crate::syntax::lexer::chars::column_of_f(&src_p0.text_p, &crate::prelude::or(&crate::prelude::index(&src_p0.starts_p, &crate::check::errors::cline_of_f(&src_p0.starts_p, &d_p3.span_p.start_p)), &Nat::from(0u32)), &d_p3.span_p.start_p) + &Nat::from(1u32)), &d_p3.message_p)))))
}
