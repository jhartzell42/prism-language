//! The module `Reading`, from `target/bootstrap/src/prismc/reading.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Assembled`:
///
/// ```prism
/// type Assembled = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Assembled {
    pub units: Array<ModFiles>,
    pub prelude: Array<ModFiles>,
    pub scripts: Array<Text>,
    pub errors: Array<TreeDiag>,
}

impl Show for Assembled {
    fn show(&self, p: &mut Printer) {
        p.record("Assembled", &[("units", &self.units), ("prelude", &self.prelude), ("scripts", &self.scripts), ("errors", &self.errors)]);
    }
}

impl ToPod for Assembled {
    fn to_pod(&self) -> Pod {
        Pod::record("Assembled", vec![("units", self.units.to_pod()), ("prelude", self.prelude.to_pod()), ("scripts", self.scripts.to_pod()), ("errors", self.errors.to_pod())])
    }
}

impl FromPod for Assembled {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Assembled { units: FromPod::from_pod(field(p, "units")?)?, prelude: FromPod::from_pod(field(p, "prelude")?)?, scripts: FromPod::from_pod(field(p, "scripts")?)?, errors: FromPod::from_pod(field(p, "errors")?)? })
    }
}

/// `CheckOpts`:
///
/// ```prism
/// type CheckOpts = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CheckOpts {
    pub world: Array<Text>,
    pub out: Option<Text>,
    pub typed: bool,
    pub unused: bool,
}

impl Show for CheckOpts {
    fn show(&self, p: &mut Printer) {
        p.record("CheckOpts", &[("world", &self.world), ("out", &self.out), ("typed", &self.typed), ("unused", &self.unused)]);
    }
}

impl ToPod for CheckOpts {
    fn to_pod(&self) -> Pod {
        Pod::record("CheckOpts", vec![("world", self.world.to_pod()), ("out", self.out.to_pod()), ("typed", self.typed.to_pod()), ("unused", self.unused.to_pod())])
    }
}

impl FromPod for CheckOpts {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CheckOpts { world: FromPod::from_pod(field(p, "world")?)?, out: FromPod::from_pod(field(p, "out")?)?, typed: FromPod::from_pod(field(p, "typed")?)?, unused: FromPod::from_pod(field(p, "unused")?)? })
    }
}

/// `CompileSettings`:
///
/// ```prism
/// type CompileSettings = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CompileSettings {
    pub out: Text,
    pub prelude: Text,
    pub name: Text,
    pub runtime: Text,
    pub target: Text,
}

impl Show for CompileSettings {
    fn show(&self, p: &mut Printer) {
        p.record("CompileSettings", &[("out", &self.out), ("prelude", &self.prelude), ("name", &self.name), ("runtime", &self.runtime), ("target", &self.target)]);
    }
}

impl ToPod for CompileSettings {
    fn to_pod(&self) -> Pod {
        Pod::record("CompileSettings", vec![("out", self.out.to_pod()), ("prelude", self.prelude.to_pod()), ("name", self.name.to_pod()), ("runtime", self.runtime.to_pod()), ("target", self.target.to_pod())])
    }
}

impl FromPod for CompileSettings {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CompileSettings { out: FromPod::from_pod(field(p, "out")?)?, prelude: FromPod::from_pod(field(p, "prelude")?)?, name: FromPod::from_pod(field(p, "name")?)?, runtime: FromPod::from_pod(field(p, "runtime")?)?, target: FromPod::from_pod(field(p, "target")?)? })
    }
}

/// `HeadLine`:
///
/// ```prism
/// type HeadLine = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct HeadLine {
    pub word: Text,
    pub arg: Text,
    pub span: crate::syntax::Range,
}

impl Show for HeadLine {
    fn show(&self, p: &mut Printer) {
        p.record("HeadLine", &[("word", &self.word), ("arg", &self.arg), ("span", &self.span)]);
    }
}

impl ToPod for HeadLine {
    fn to_pod(&self) -> Pod {
        Pod::record("HeadLine", vec![("word", self.word.to_pod()), ("arg", self.arg.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for HeadLine {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(HeadLine { word: FromPod::from_pod(field(p, "word")?)?, arg: FromPod::from_pod(field(p, "arg")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `ModFiles`:
///
/// ```prism
/// type ModFiles = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ModFiles {
    pub name: Text,
    pub named: bool,
    pub segs: Array<Seg>,
    pub parent: Text,
}

impl Show for ModFiles {
    fn show(&self, p: &mut Printer) {
        p.record("ModFiles", &[("name", &self.name), ("named", &self.named), ("segs", &self.segs), ("parent", &self.parent)]);
    }
}

impl ToPod for ModFiles {
    fn to_pod(&self) -> Pod {
        Pod::record("ModFiles", vec![("name", self.name.to_pod()), ("named", self.named.to_pod()), ("segs", self.segs.to_pod()), ("parent", self.parent.to_pod())])
    }
}

impl FromPod for ModFiles {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ModFiles { name: FromPod::from_pod(field(p, "name")?)?, named: FromPod::from_pod(field(p, "named")?)?, segs: FromPod::from_pod(field(p, "segs")?)?, parent: FromPod::from_pod(field(p, "parent")?)? })
    }
}

/// `ParsedProgram`:
///
/// ```prism
/// type ParsedProgram = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ParsedProgram {
    pub srcs: Array<crate::check::errors::Src>,
    pub trees: Array<crate::syntax::Module>,
    pub shown: Nat,
    pub parents: Array<Text>,
    pub errors: Text,
}

impl Show for ParsedProgram {
    fn show(&self, p: &mut Printer) {
        p.record("ParsedProgram", &[("srcs", &self.srcs), ("trees", &self.trees), ("shown", &self.shown), ("parents", &self.parents), ("errors", &self.errors)]);
    }
}

impl ToPod for ParsedProgram {
    fn to_pod(&self) -> Pod {
        Pod::record("ParsedProgram", vec![("srcs", self.srcs.to_pod()), ("trees", self.trees.to_pod()), ("shown", self.shown.to_pod()), ("parents", self.parents.to_pod()), ("errors", self.errors.to_pod())])
    }
}

impl FromPod for ParsedProgram {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ParsedProgram { srcs: FromPod::from_pod(field(p, "srcs")?)?, trees: FromPod::from_pod(field(p, "trees")?)?, shown: FromPod::from_pod(field(p, "shown")?)?, parents: FromPod::from_pod(field(p, "parents")?)?, errors: FromPod::from_pod(field(p, "errors")?)? })
    }
}

/// `ReadInput`:
///
/// ```prism
/// type ReadInput = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ReadInput {
    pub args: Array<Text>,
    pub prelude: Text,
    pub listings: Array<(Text, Array<Text>)>,
    pub paths: Array<Text>,
    pub texts: Array<(Text, Text)>,
    pub tests: bool,
    pub compiling: bool,
}

impl Show for ReadInput {
    fn show(&self, p: &mut Printer) {
        p.record("ReadInput", &[("args", &self.args), ("prelude", &self.prelude), ("listings", &self.listings), ("paths", &self.paths), ("texts", &self.texts), ("tests", &self.tests), ("compiling", &self.compiling)]);
    }
}

impl ToPod for ReadInput {
    fn to_pod(&self) -> Pod {
        Pod::record("ReadInput", vec![("args", self.args.to_pod()), ("prelude", self.prelude.to_pod()), ("listings", self.listings.to_pod()), ("paths", self.paths.to_pod()), ("texts", self.texts.to_pod()), ("tests", self.tests.to_pod()), ("compiling", self.compiling.to_pod())])
    }
}

impl FromPod for ReadInput {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ReadInput { args: FromPod::from_pod(field(p, "args")?)?, prelude: FromPod::from_pod(field(p, "prelude")?)?, listings: FromPod::from_pod(field(p, "listings")?)?, paths: FromPod::from_pod(field(p, "paths")?)?, texts: FromPod::from_pod(field(p, "texts")?)?, tests: FromPod::from_pod(field(p, "tests")?)?, compiling: FromPod::from_pod(field(p, "compiling")?)? })
    }
}

/// `ReadMode`:
///
/// ```prism
/// type ReadMode = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum ReadMode {
    Checking(CheckOpts),
    Compiling(CompileSettings),
}

impl Show for ReadMode {
    fn show(&self, p: &mut Printer) {
        match self {
            ReadMode::Checking(a0) => p.choice("Checking", &[a0]),
            ReadMode::Compiling(a0) => p.choice("Compiling", &[a0]),
        }
    }
}

impl ToPod for ReadMode {
    fn to_pod(&self) -> Pod {
        match self {
            ReadMode::Checking(a0) => Pod::Choice("Checking".into(), vec![a0.to_pod()]),
            ReadMode::Compiling(a0) => Pod::Choice("Compiling".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for ReadMode {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "Checking" && a.len() == 1 => Ok(ReadMode::Checking(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "Compiling" && a.len() == 1 => Ok(ReadMode::Compiling(FromPod::from_pod(&a[0])?)),
            other => mismatch("a ReadMode", other),
        }
    }
}

/// `Seg`:
///
/// ```prism
/// type Seg = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Seg {
    pub path_: Text,
    pub text: Text,
    pub role: Text,
}

impl Show for Seg {
    fn show(&self, p: &mut Printer) {
        p.record("Seg", &[("path", &self.path_), ("text", &self.text), ("role", &self.role)]);
    }
}

impl ToPod for Seg {
    fn to_pod(&self) -> Pod {
        Pod::record("Seg", vec![("path", self.path_.to_pod()), ("text", self.text.to_pod()), ("role", self.role.to_pod())])
    }
}

impl FromPod for Seg {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Seg { path_: FromPod::from_pod(field(p, "path")?)?, text: FromPod::from_pod(field(p, "text")?)?, role: FromPod::from_pod(field(p, "role")?)? })
    }
}

/// `TreeAcc`:
///
/// ```prism
/// type TreeAcc = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TreeAcc {
    pub units: Array<ModFiles>,
    pub declared: Map<Text, bool>,
    pub diags: Array<TreeDiag>,
}

impl Show for TreeAcc {
    fn show(&self, p: &mut Printer) {
        p.record("TreeAcc", &[("units", &self.units), ("declared", &self.declared), ("diags", &self.diags)]);
    }
}

impl ToPod for TreeAcc {
    fn to_pod(&self) -> Pod {
        Pod::record("TreeAcc", vec![("units", self.units.to_pod()), ("declared", self.declared.to_pod()), ("diags", self.diags.to_pod())])
    }
}

impl FromPod for TreeAcc {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TreeAcc { units: FromPod::from_pod(field(p, "units")?)?, declared: FromPod::from_pod(field(p, "declared")?)?, diags: FromPod::from_pod(field(p, "diags")?)? })
    }
}

/// `TreeDiag`:
///
/// ```prism
/// type TreeDiag = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TreeDiag {
    pub path_: Text,
    pub span: crate::syntax::Range,
    pub code: Text,
    pub message: Text,
    pub fix: Text,
}

impl Show for TreeDiag {
    fn show(&self, p: &mut Printer) {
        p.record("TreeDiag", &[("path", &self.path_), ("span", &self.span), ("code", &self.code), ("message", &self.message), ("fix", &self.fix)]);
    }
}

impl ToPod for TreeDiag {
    fn to_pod(&self) -> Pod {
        Pod::record("TreeDiag", vec![("path", self.path_.to_pod()), ("span", self.span.to_pod()), ("code", self.code.to_pod()), ("message", self.message.to_pod()), ("fix", self.fix.to_pod())])
    }
}

impl FromPod for TreeDiag {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TreeDiag { path_: FromPod::from_pod(field(p, "path")?)?, span: FromPod::from_pod(field(p, "span")?)?, code: FromPod::from_pod(field(p, "code")?)?, message: FromPod::from_pod(field(p, "message")?)?, fix: FromPod::from_pod(field(p, "fix")?)? })
    }
}

/// ```prism
/// IsCompiling: fn ReadMode -> Bool
/// ```
pub fn is_compiling(read_mode0: &ReadMode) -> bool {
    match read_mode0 {
        ReadMode::Compiling(_) => true,
        ReadMode::Checking(_) => false,
    }
}

// `@ReadSources` is inlined where it is applied.

// `@ReadUp` is inlined where it is applied.

// `@ReadTexts` is inlined where it is applied.

// `@ReadRun` is inlined where it is applied.

// `@RunRead` is inlined where it is applied.

// `@CheckRun` is inlined where it is applied.

// `@CompileRun` is inlined where it is applied.

/// ```prism
/// Pairs: fn [Text], (Nat ==> [Text]) -> [((Text, [Text]))]
/// ```
pub fn pairs(ds: &Array<Text>, m: &Map<Nat, Array<Text>>) -> Array<(Text, Array<Text>)> {
    each(&crate::check::errors::range0(&len(ds)), &(|i: &Nat| (or(&index(ds, i), &Text::lit("")), or(&get(m, i), &Array::new()))))
}

/// ```prism
/// ReadFailure: fn ?~Contents -> Text
/// ```
pub fn read_failure(opt0: &Option<Result<crate::fs::Contents, Error>>) -> Text {
    match opt0 {
        Some(c_try) => contents_failure(c_try),
        None => Text::lit("nothing was read"),
    }
}

/// ```prism
/// ContentsFailure: fn ~Contents -> Text
/// ```
pub fn contents_failure(arg0: &Result<crate::fs::Contents, Error>) -> Text {
    match arg0 {
        Ok(c) => Text::lit(""),
        Err(c1_0) => c1_0.message.clone(),
    }
}

/// ```prism
/// ContentsText: fn ~Contents -> Text
/// ```
pub fn contents_text(arg0: &Result<crate::fs::Contents, Error>) -> Text {
    match arg0 {
        Ok(c) => c.text.clone(),
        Err(c1_0) => Text::lit(""),
    }
}

/// ```prism
/// IsSourcePath: fn Text -> Bool
/// ```
pub fn is_source_path(f: &Text) -> bool {
    crate::syntax::lexer::chars::has_suffix(f, &Text::lit(".prism")) || crate::syntax::lexer::chars::has_suffix(f, &Text::lit(".prismtest"))
}

/// ```prism
/// DirOf: fn Text -> Text
/// ```
pub fn dir_of(p_: &Text) -> Text {
    crate::syntax::lexer::chars::join(&crate::syntax::lexer::chars::pop(&split_on(p_, &Text::lit("/"))), &Text::lit("/"))
}

/// ```prism
/// BaseOf: fn Text -> Text
/// ```
pub fn base_of(p_: &Text) -> Text {
    or(&crate::syntax::lexer::chars::last(&split_on(p_, &Text::lit("/"))), p_)
}

/// ```prism
/// Under: fn Text, Text -> Text
/// ```
pub fn under(d: &Text, n: &Text) -> Text {
    if (d == &Text::lit("")) || (d == &Text::lit(".")) {
        n.clone()
    } else {
        Text::from(format!("{}/{}", d, n))
    }
}

/// ```prism
/// Ancestors: fn Text -> [Text]
/// ```
pub fn ancestors(d: &Text) -> Array<Text> {
    let parts = split_on(d, &Text::lit("/"));
    let n = len(&parts);
    filter(&each(&crate::check::errors::range0(&crate::syntax::lexer::chars::dec(&n)), &(|i: &Nat| crate::syntax::lexer::chars::join(&take(&parts, &or(&(&crate::syntax::lexer::chars::dec(&n)).checked_sub(i), &Nat::from(0u32))), &Text::lit("/")))), &(|a: &Text| (a != &Text::lit("")) && (a != &Text::lit("."))))
}

/// ```prism
/// DirName: fn Text -> Text
/// ```
pub fn dir_name(name: &Text) -> Text {
    let (out, _) = crate::syntax::lexer::chars::fold_chars(name, &(Text::lit(""), Text::lit("")), &(Rc::new(move |(p0, p1): ((Text, Text), Text)| once_job(move || {
        let (acc, prev) = p0;
        let c = p1;
        {
            let sep = if crate::syntax::lexer::chars::is_upper(&c) && (crate::syntax::lexer::chars::is_lower(&prev) || crate::syntax::lexer::chars::is_digit(&prev)) {
                Text::lit("_")
            } else {
                Text::lit("")
            };
            prism_rtl::Turn::Finished((Text::from(format!("{}{}{}", &acc, &sep, &(if crate::syntax::lexer::chars::is_upper(&c) {
                crate::prelude::lower(&c)
            } else {
                c.clone()
            }))), c.clone()))
        }
    })) as Rc<dyn Fn(((Text, Text), Text)) -> Rc<dyn prism_rtl::Job<(Text, Text)>>>));
    out.clone()
}

/// ```prism
/// ModOfDir: fn Text -> Text
/// ```
pub fn mod_of_dir(d: &Text) -> Text {
    concat(&each(&split_on(d, &Text::lit("_")), &(|w: &Text| Text::from(format!("{}{}", &upper(&crate::syntax::lexer::chars::head(w)), &crate::syntax::lexer::chars::after_first(w))))))
}

/// ```prism
/// HeaderLines: fn Text -> [HeadLine]
/// ```
pub fn header_lines(text_: &Text) -> Array<HeadLine> {
    let (lines, _, _) = fold(&split_on(text_, &Text::lit("\n")), &(Array::new(), Nat::from(0u32), true), &(|(acc, at_, open): &(Array<HeadLine>, Nat, bool), line: &Text| {
        let next_ = &(at_ + &len_text(line)) + &Nat::from(1u32);
        if !*open {
            (acc.clone(), next_.clone(), false)
        } else {
            if ((&crate::syntax::lexer::chars::trim(line) == &Text::lit("")) || crate::syntax::lexer::chars::has_prefix(line, &Text::lit("#"))) || crate::syntax::lexer::chars::has_prefix(line, &Text::lit(" ")) {
                (acc.clone(), next_.clone(), true)
            } else {
                match head_line_of(line, at_) {
                    Some(h) => (push(acc, &h), next_.clone(), true),
                    None => (acc.clone(), next_.clone(), false),
                }
            }
        }
    }));
    lines.clone()
}

/// ```prism
/// ?HeadLineOf: fn Text, Nat -> ?HeadLine
/// ```
pub fn head_line_of(line: &Text, at_: &Nat) -> Option<HeadLine> {
    let code = crate::syntax::lexer::chars::trim_end(&or(&index(&split_on(line, &Text::lit(" #")), &Nat::from(0u32)), line));
    let words = filter(&split_on(&code, &Text::lit(" ")), &(|w: &Text| w != &Text::lit("")));
    let first_ = or(&index(&words, &Nat::from(0u32)), &Text::lit(""));
    let second = or(&index(&words, &Nat::from(1u32)), &Text::lit(""));
    let span = crate::syntax::Range { start: at_.clone(), end: at_ + &len_text(&code) };
    if (&first_ == &Text::lit("test")) && (&second == &Text::lit("mod")) {
        Some(HeadLine { word: Text::lit("test mod"), arg: or(&index(&words, &Nat::from(2u32)), &Text::lit("")), span: span.clone() })
    } else {
        if crate::check::types::has_text(&Array::from(vec![Text::lit("module"), Text::lit("emit"), Text::lit("mod"), Text::lit("use")]), &first_) {
            Some(HeadLine { word: first_.clone(), arg: or(&crate::syntax::lexer::chars::before_suffix(&second, &Text::lit(".*")), &second), span: span.clone() })
        } else {
            None
        }
    }
}

/// ```prism
/// ?FirstDeclLine: fn Text -> ?Range
/// ```
pub fn first_decl_line(text_: &Text) -> Option<crate::syntax::Range> {
    let (found_opt, _) = fold(&split_on(text_, &Text::lit("\n")), &(None, Nat::from(0u32)), &(|(f_opt, at_): &(Option<crate::syntax::Range>, Nat), line: &Text| {
        let next_ = &(at_ + &len_text(line)) + &Nat::from(1u32);
        if ((((f_opt != &None) || (&crate::syntax::lexer::chars::trim(line) == &Text::lit(""))) || crate::syntax::lexer::chars::has_prefix(line, &Text::lit("#"))) || crate::syntax::lexer::chars::has_prefix(line, &Text::lit(" "))) || (&head_line_of(line, at_) != &None) {
            (f_opt.clone(), next_.clone())
        } else {
            (Some(crate::syntax::Range { start: at_.clone(), end: at_ + &len_text(&crate::syntax::lexer::chars::trim_end(line)) }), next_.clone())
        }
    }));
    found_opt.clone()
}

/// ```prism
/// let noAssembly
/// ```
pub fn no_assembly() -> Assembled {
    Assembled { units: Array::new(), prelude: Array::new(), scripts: Array::new(), errors: Array::new() }
}

/// ```prism
/// let noSpan
/// ```
pub fn no_span() -> crate::syntax::Range {
    crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) }
}

/// ```prism
/// AddTreeDiag: fn TreeAcc, Text, Range, Text, Text, Text -> TreeAcc
/// ```
pub fn add_tree_diag(acc: &TreeAcc, path_: &Text, span: &crate::syntax::Range, code: &Text, message: &Text, fix: &Text) -> TreeAcc {
    let mut this: TreeAcc = acc.clone();
    this.diags = push(&this.diags, &TreeDiag { path_: path_.clone(), span: span.clone(), code: code.clone(), message: message.clone(), fix: fix.clone() });
    this
}

/// ```prism
/// IsModuleDir: fn Text, [Text] -> Bool
/// ```
pub fn is_module_dir(d: &Text, files: &Array<Text>) -> bool {
    (crate::check::types::has_text(files, &under(d, &Text::lit("mod.prism"))) && !crate::check::types::has_text(files, &under(d, &Text::lit("app.prism")))) && !crate::check::types::has_text(files, &under(d, &Text::lit("lib.prism")))
}

/// ```prism
/// IsRootDir: fn Text, [Text] -> Bool
/// ```
pub fn is_root_dir(d: &Text, files: &Array<Text>) -> bool {
    crate::check::types::has_text(files, &under(d, &Text::lit("app.prism"))) || crate::check::types::has_text(files, &under(d, &Text::lit("lib.prism")))
}

/// ```prism
/// ?TreeRootOf: fn Text, (Text ==> [Text]) -> ?Text
/// ```
pub fn tree_root_of(d: &Text, listings: &Map<Text, Array<Text>>) -> Option<Text> {
    let files = or(&get(listings, d), &Array::new());
    if is_root_dir(d, &files) {
        Some(d.clone())
    } else {
        if is_module_dir(d, &files) {
            fold(&ancestors(d), &None, &(|found_opt: &Option<Text>, a: &Text| if (found_opt == &None) && is_root_dir(a, &or(&get(listings, a), &Array::new())) {
                Some(a.clone())
            } else {
                found_opt.clone()
            }))
        } else {
            None
        }
    }
}

/// ```prism
/// ToRead: fn [Text], (Text ==> [Text]) -> [Text]
/// ```
pub fn to_read(args: &Array<Text>, listings: &Map<Text, Array<Text>>) -> Array<Text> {
    fold(args, &Array::new(), &(|acc: &Array<Text>, a: &Text| if is_source_path(a) {
        crate::check::types::add_text(acc, a)
    } else {
        match tree_root_of(a, listings) {
            Some(root) => crate::check::types::union_texts(acc, &or(&get(listings, &root), &Array::new())),
            None => acc.clone(),
        }
    }))
}

/// ```prism
/// Assemble: unbounded fn ReadInput -> Assembled
/// ```
pub fn assemble(input: &ReadInput) -> Assembled {
    let listings = map(&input.listings);
    let texts = map(&input.texts);
    let progs = run_to_end(fold_job(input.args.clone(), no_assembly(), {
        let listings = listings.clone();
        let texts = texts.clone();
        Rc::new(move |(p0, p1): (Assembled, Text)| {
            let listings = listings.clone();
            let texts = texts.clone();
            entered(once_job(move || {
                let acc = p0;
                let a = p1;
                prism_rtl::Turn::More(Rc::new(AddArg { acc: acc.clone(), listings: listings.clone(), texts: texts.clone(), a: a.clone() }))
            }))
        }) as Rc<dyn Fn((Assembled, Text)) -> Rc<dyn prism_rtl::Job<Assembled>>>
    }));
    let pre = add_arg(&no_assembly(), &listings, &texts, &input.prelude);
    let units = filter(&each(&progs.units, &(|u: &ModFiles| kept_segs(u, &input.tests))), &(|u: &ModFiles| &len(&u.segs) > &Nat::from(0u32)));
    let kept = fold(&units, &Array::new(), &(|acc: &Array<Text>, u: &ModFiles| append(acc, &each(&u.segs, &(|s: &Seg| s.path_.clone())))));
    let mut this: Assembled = progs.clone();
    this.units = units.clone();
    this.prelude = filter(&each(&pre.units, &(|u: &ModFiles| kept_segs(u, &false))), &(|u: &ModFiles| &len(&u.segs) > &Nat::from(0u32)));
    this.scripts = filter(&this.scripts, &(|p_: &Text| crate::check::types::has_text(&kept, p_)));
    this.errors = append(&this.errors, &pre.errors);
    this
}

/// The step machine of `Assemble`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Assemble: unbounded fn ReadInput -> Assembled
/// ```
pub struct Assemble {
    pub input: ReadInput,
}

impl prism_rtl::Job<Assembled> for Assemble {
    fn cycle(&self) -> prism_rtl::Turn<Assembled> {
        let input = &self.input;
        let listings = map(&input.listings);
        let texts = map(&input.texts);
        let input = input.clone();
        call_value(fold_job(input.args.clone(), no_assembly(), {
            let listings = listings.clone();
            let texts = texts.clone();
            Rc::new(move |(p0, p1): (Assembled, Text)| {
                let listings = listings.clone();
                let texts = texts.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let a = p1;
                    prism_rtl::Turn::More(Rc::new(AddArg { acc: acc.clone(), listings: listings.clone(), texts: texts.clone(), a: a.clone() }))
                }))
            }) as Rc<dyn Fn((Assembled, Text)) -> Rc<dyn prism_rtl::Job<Assembled>>>
        }), move |fold_12106: Assembled| {
            let progs = fold_12106;
            call_then(start_add_arg(no_assembly(), listings.clone(), texts.clone(), input.prelude.clone()), move |add_arg_12190: Assembled| {
                let pre = add_arg_12190;
                let units = filter(&each(&progs.units, &(|u: &ModFiles| kept_segs(u, &input.tests))), &(|u: &ModFiles| &len(&u.segs) > &Nat::from(0u32)));
                let kept = fold(&units, &Array::new(), &(|acc: &Array<Text>, u: &ModFiles| append(acc, &each(&u.segs, &(|s: &Seg| s.path_.clone())))));
                prism_rtl::Turn::Finished({
                    let mut this: Assembled = progs.clone();
                    this.units = units.clone();
                    this.prelude = filter(&each(&pre.units, &(|u: &ModFiles| kept_segs(u, &false))), &(|u: &ModFiles| &len(&u.segs) > &Nat::from(0u32)));
                    this.scripts = filter(&this.scripts, &(|p_: &Text| crate::check::types::has_text(&kept, p_)));
                    this.errors = append(&this.errors, &pre.errors);
                    this
                })
            })
        })
    }
}

/// `Start Assemble, x`: what the function value is when passed to `@Run`.
pub fn start_assemble(input: ReadInput) -> Rc<dyn prism_rtl::Job<Assembled>> {
    Rc::new(Assemble { input })
}

/// ```prism
/// KeptSegs: fn ModFiles, Bool -> ModFiles
/// ```
pub fn kept_segs(u: &ModFiles, tests: &bool) -> ModFiles {
    let mut this: ModFiles = u.clone();
    this.segs = filter(&this.segs, &(|s: &Seg| (&s.role != &Text::lit("test")) || *tests));
    this
}

/// ```prism
/// AddArg: unbounded fn Assembled, (Text ==> [Text]), (Text ==> Text), Text -> Assembled
/// ```
pub fn add_arg(acc: &Assembled, listings: &Map<Text, Array<Text>>, texts: &Map<Text, Text>, a: &Text) -> Assembled {
    if crate::syntax::lexer::chars::has_suffix(a, &Text::lit(".prismtest")) {
        {
            let mut this: Assembled = acc.clone();
            this.errors = push(&this.errors, &TreeDiag { path_: a.clone(), span: no_span(), code: Text::lit("prismtest"), message: Text::from(format!("`{}`: a `.prismtest` is not read: a module\'s tests are in its test modules, a loose file\'s inline", a)), fix: Text::lit("move its declarations into a test module (`test mod tests`), or into the file it tests") });
            this
        }
    } else {
        if crate::syntax::lexer::chars::has_suffix(a, &Text::lit(".prism")) {
            {
                let mut this: Assembled = acc.clone();
                this.units = push(&this.units, &ModFiles { name: Text::lit(""), named: false, segs: Array::from(vec![Seg { path_: a.clone(), text: or(&get(texts, a), &Text::lit("")), role: Text::lit("loose") }]), parent: Text::lit("") });
                this
            }
        } else {
            match tree_root_of(a, listings) {
                Some(root) => {
                    let tree = walk_tree(&root, &or(&get(listings, &root), &Array::new()), texts);
                    let start = under(a, &Text::lit("mod.prism"));
                    let units = if &root == a { tree.units.clone() } else { reach_tree(&tree.units, &start) };
                    let scripts = if &root == a {
                        fold(&units, &Array::new(), &(|s: &Array<Text>, u: &ModFiles| append(s, &test_paths(u))))
                    } else {
                        fold(&filter(&units, &(|u: &ModFiles| (&main_path(u) == &start) || (&u.parent == &start))), &Array::new(), &(|s: &Array<Text>, u: &ModFiles| append(s, &test_paths(u))))
                    };
                    {
                        let mut this: Assembled = acc.clone();
                        this.units = append(&this.units, &units);
                        this.scripts = append(&this.scripts, &scripts);
                        this.errors = append(&this.errors, &tree.diags);
                        this
                    }
                },
                None => {
                    let mut this: Assembled = acc.clone();
                    this.errors = push(&this.errors, &TreeDiag { path_: a.clone(), span: no_span(), code: Text::lit("no-root"), message: Text::from(format!("`{}` holds no app.prism, lib.prism or mod.prism, and a directory argument is a tree", a)), fix: Text::lit("give it a root, or name its files") });
                    this
                },
            }
        }
    }
}

/// The step machine of `AddArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AddArg: unbounded fn Assembled, (Text ==> [Text]), (Text ==> Text), Text -> Assembled
/// ```
pub struct AddArg {
    pub acc: Assembled,
    pub listings: Map<Text, Array<Text>>,
    pub texts: Map<Text, Text>,
    pub a: Text,
}

impl prism_rtl::Job<Assembled> for AddArg {
    fn cycle(&self) -> prism_rtl::Turn<Assembled> {
        let acc = &self.acc;
        let listings = &self.listings;
        let texts = &self.texts;
        let a = &self.a;
        if crate::syntax::lexer::chars::has_suffix(a, &Text::lit(".prismtest")) {
            prism_rtl::Turn::Finished({
                let mut this: Assembled = acc.clone();
                this.errors = push(&this.errors, &TreeDiag { path_: a.clone(), span: no_span(), code: Text::lit("prismtest"), message: Text::from(format!("`{}`: a `.prismtest` is not read: a module\'s tests are in its test modules, a loose file\'s inline", a)), fix: Text::lit("move its declarations into a test module (`test mod tests`), or into the file it tests") });
                this
            })
        } else {
            if crate::syntax::lexer::chars::has_suffix(a, &Text::lit(".prism")) {
                prism_rtl::Turn::Finished({
                    let mut this: Assembled = acc.clone();
                    this.units = push(&this.units, &ModFiles { name: Text::lit(""), named: false, segs: Array::from(vec![Seg { path_: a.clone(), text: or(&get(texts, a), &Text::lit("")), role: Text::lit("loose") }]), parent: Text::lit("") });
                    this
                })
            } else {
                match tree_root_of(a, listings) {
                    Some(root) => {
                        let a = a.clone();
                        let acc = acc.clone();
                        let listings = listings.clone();
                        let texts = texts.clone();
                        call_then(start_walk_tree(root.clone(), or(&get(&listings, &root), &Array::new()), texts.clone()), move |walk_tree_13644: TreeAcc| {
                            let tree = walk_tree_13644;
                            let start = under(&a, &Text::lit("mod.prism"));
                            let units = if &root == &a { tree.units.clone() } else { reach_tree(&tree.units, &start) };
                            let scripts = if &root == &a {
                                fold(&units, &Array::new(), &(|s: &Array<Text>, u: &ModFiles| append(s, &test_paths(u))))
                            } else {
                                fold(&filter(&units, &(|u: &ModFiles| (&main_path(u) == &start) || (&u.parent == &start))), &Array::new(), &(|s: &Array<Text>, u: &ModFiles| append(s, &test_paths(u))))
                            };
                            prism_rtl::Turn::Finished({
                                let mut this: Assembled = acc.clone();
                                this.units = append(&this.units, &units);
                                this.scripts = append(&this.scripts, &scripts);
                                this.errors = append(&this.errors, &tree.diags);
                                this
                            })
                        })
                    },
                    None => prism_rtl::Turn::Finished({
                        let mut this: Assembled = acc.clone();
                        this.errors = push(&this.errors, &TreeDiag { path_: a.clone(), span: no_span(), code: Text::lit("no-root"), message: Text::from(format!("`{}` holds no app.prism, lib.prism or mod.prism, and a directory argument is a tree", a)), fix: Text::lit("give it a root, or name its files") });
                        this
                    }),
                }
            }
        }
    }
}

/// `Start AddArg, x`: what the function value is when passed to `@Run`.
pub fn start_add_arg(acc: Assembled, listings: Map<Text, Array<Text>>, texts: Map<Text, Text>, a: Text) -> Rc<dyn prism_rtl::Job<Assembled>> {
    Rc::new(AddArg { acc, listings, texts, a })
}

/// ```prism
/// MainPath: fn ModFiles -> Text
/// ```
pub fn main_path(u: &ModFiles) -> Text {
    match index(&u.segs, &Nat::from(0u32)) {
        Some(s) => s.path_.clone(),
        None => Text::lit(""),
    }
}

/// ```prism
/// MainText: fn ModFiles -> Text
/// ```
pub fn main_text(u: &ModFiles) -> Text {
    match index(&u.segs, &Nat::from(0u32)) {
        Some(s) => s.text.clone(),
        None => Text::lit(""),
    }
}

/// ```prism
/// TestPaths: fn ModFiles -> [Text]
/// ```
pub fn test_paths(u: &ModFiles) -> Array<Text> {
    each(&filter(&u.segs, &(|s: &Seg| &s.role == &Text::lit("test"))), &(|s: &Seg| s.path_.clone()))
}

/// ```prism
/// WalkTree: unbounded fn Text, [Text], (Text ==> Text) -> TreeAcc
/// ```
pub fn walk_tree(root: &Text, files: &Array<Text>, texts: &Map<Text, Text>) -> TreeAcc {
    let has = fold(files, &Map::new(), &(|m: &Map<Text, bool>, f: &Text| insert(m, f, &true)));
    let app = under(root, &Text::lit("app.prism"));
    let lib = under(root, &Text::lit("lib.prism"));
    let acc0 = TreeAcc { units: Array::new(), declared: Map::new(), diags: Array::new() };
    let acc1 = if crate::check::env::has_key(&has, &app) && crate::check::env::has_key(&has, &lib) {
        add_tree_diag(&acc0, &lib, &no_span(), &Text::lit("two-roots"), &Text::lit("`app.prism` and `lib.prism` in one directory: a tree has one root"), &Text::lit("keep app.prism for a program or lib.prism for a library"))
    } else {
        acc0.clone()
    };
    let acc2 = if crate::check::env::has_key(&has, &app) {
        walk_module(&has, texts, &acc1, &app, &Text::lit(""), &Text::lit(""), &false)
    } else {
        walk_lib(&has, texts, &acc1, &lib)
    };
    let acc3 = {
        let mut this: TreeAcc = acc2.clone();
        this.declared = insert(&this.declared, &lib, &true);
        this
    };
    fold(files, &acc3, &(|a: &TreeAcc, f: &Text| if crate::check::env::has_key(&a.declared, f) {
        a.clone()
    } else {
        stray(&has, texts, a, f)
    }))
}

/// The step machine of `WalkTree`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WalkTree: unbounded fn Text, [Text], (Text ==> Text) -> TreeAcc
/// ```
pub struct WalkTree {
    pub root: Text,
    pub files: Array<Text>,
    pub texts: Map<Text, Text>,
}

impl prism_rtl::Job<TreeAcc> for WalkTree {
    fn cycle(&self) -> prism_rtl::Turn<TreeAcc> {
        let root = &self.root;
        let files = &self.files;
        let texts = &self.texts;
        let has = fold(files, &Map::new(), &(|m: &Map<Text, bool>, f: &Text| insert(m, f, &true)));
        let app = under(root, &Text::lit("app.prism"));
        let lib = under(root, &Text::lit("lib.prism"));
        let acc0 = TreeAcc { units: Array::new(), declared: Map::new(), diags: Array::new() };
        let acc1 = if crate::check::env::has_key(&has, &app) && crate::check::env::has_key(&has, &lib) {
            add_tree_diag(&acc0, &lib, &no_span(), &Text::lit("two-roots"), &Text::lit("`app.prism` and `lib.prism` in one directory: a tree has one root"), &Text::lit("keep app.prism for a program or lib.prism for a library"))
        } else {
            acc0.clone()
        };
        let acc2 = if crate::check::env::has_key(&has, &app) {
            walk_module(&has, texts, &acc1, &app, &Text::lit(""), &Text::lit(""), &false)
        } else {
            walk_lib(&has, texts, &acc1, &lib)
        };
        let acc3 = {
            let mut this: TreeAcc = acc2.clone();
            this.declared = insert(&this.declared, &lib, &true);
            this
        };
        prism_rtl::Turn::Finished(fold(files, &acc3, &(|a: &TreeAcc, f: &Text| if crate::check::env::has_key(&a.declared, f) {
            a.clone()
        } else {
            stray(&has, texts, a, f)
        })))
    }
}

/// `Start WalkTree, x`: what the function value is when passed to `@Run`.
pub fn start_walk_tree(root: Text, files: Array<Text>, texts: Map<Text, Text>) -> Rc<dyn prism_rtl::Job<TreeAcc>> {
    Rc::new(WalkTree { root, files, texts })
}

/// ```prism
/// WalkLib: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text -> TreeAcc
/// ```
pub fn walk_lib(has: &Map<Text, bool>, texts: &Map<Text, Text>, acc: &TreeAcc, lib: &Text) -> TreeAcc {
    let text_ = or(&get(texts, lib), &Text::lit(""));
    let heads = header_lines(&text_);
    let bad = filter(&heads, &(|h: &HeadLine| !((&h.word == &Text::lit("mod")) && crate::check::env::is_upper_text(&h.arg))));
    let acc1 = fold(&bad, acc, &(|a: &TreeAcc, h: &HeadLine| add_tree_diag(a, lib, &h.span, &Text::lit("lib-header"), &Text::from(format!("lib.prism holds only `mod Name` lines, the library\'s modules: `{}` belongs in a module", &h.word)), &Text::lit("move the line to a module\'s mod.prism"))));
    let acc2 = match first_decl_line(&text_) {
        Some(r) => add_tree_diag(&acc1, lib, &r, &Text::lit("lib-header"), &Text::lit("lib.prism holds only `mod Name` lines, the library\'s modules"), &Text::lit("move the declaration to a module")),
        None => acc1.clone(),
    };
    let dir = dir_of(lib);
    run_to_end(fold_job(filter(&heads, &(|h: &HeadLine| (&h.word == &Text::lit("mod")) && crate::check::env::is_upper_text(&h.arg))), acc2.clone(), {
        let has = has.clone();
        let texts = texts.clone();
        let lib = lib.clone();
        let dir = dir.clone();
        Rc::new(move |(p0, p1): (TreeAcc, HeadLine)| {
            let has = has.clone();
            let texts = texts.clone();
            let lib = lib.clone();
            let dir = dir.clone();
            entered(once_job(move || {
                let a = p0;
                let h = p1;
                prism_rtl::Turn::More(Rc::new(Child { has: has.clone(), texts: texts.clone(), acc: a.clone(), main: lib.clone(), dir: dir.clone(), h: h.clone(), parent: Text::lit(""), in_test: false }))
            }))
        }) as Rc<dyn Fn((TreeAcc, HeadLine)) -> Rc<dyn prism_rtl::Job<TreeAcc>>>
    }))
}

/// The step machine of `WalkLib`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WalkLib: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text -> TreeAcc
/// ```
pub struct WalkLib {
    pub has: Map<Text, bool>,
    pub texts: Map<Text, Text>,
    pub acc: TreeAcc,
    pub lib: Text,
}

impl prism_rtl::Job<TreeAcc> for WalkLib {
    fn cycle(&self) -> prism_rtl::Turn<TreeAcc> {
        let has = &self.has;
        let texts = &self.texts;
        let acc = &self.acc;
        let lib = &self.lib;
        let text_ = or(&get(texts, lib), &Text::lit(""));
        let heads = header_lines(&text_);
        let bad = filter(&heads, &(|h: &HeadLine| !((&h.word == &Text::lit("mod")) && crate::check::env::is_upper_text(&h.arg))));
        let acc1 = fold(&bad, acc, &(|a: &TreeAcc, h: &HeadLine| add_tree_diag(a, lib, &h.span, &Text::lit("lib-header"), &Text::from(format!("lib.prism holds only `mod Name` lines, the library\'s modules: `{}` belongs in a module", &h.word)), &Text::lit("move the line to a module\'s mod.prism"))));
        let acc2 = match first_decl_line(&text_) {
            Some(r) => add_tree_diag(&acc1, lib, &r, &Text::lit("lib-header"), &Text::lit("lib.prism holds only `mod Name` lines, the library\'s modules"), &Text::lit("move the declaration to a module")),
            None => acc1.clone(),
        };
        let dir = dir_of(lib);
        fold_job(filter(&heads, &(|h: &HeadLine| (&h.word == &Text::lit("mod")) && crate::check::env::is_upper_text(&h.arg))), acc2.clone(), {
            let has = has.clone();
            let texts = texts.clone();
            let lib = lib.clone();
            let dir = dir.clone();
            Rc::new(move |(p0, p1): (TreeAcc, HeadLine)| {
                let has = has.clone();
                let texts = texts.clone();
                let lib = lib.clone();
                let dir = dir.clone();
                entered(once_job(move || {
                    let a = p0;
                    let h = p1;
                    prism_rtl::Turn::More(Rc::new(Child { has: has.clone(), texts: texts.clone(), acc: a.clone(), main: lib.clone(), dir: dir.clone(), h: h.clone(), parent: Text::lit(""), in_test: false }))
                }))
            }) as Rc<dyn Fn((TreeAcc, HeadLine)) -> Rc<dyn prism_rtl::Job<TreeAcc>>>
        }).cycle()
    }
}

/// `Start WalkLib, x`: what the function value is when passed to `@Run`.
pub fn start_walk_lib(has: Map<Text, bool>, texts: Map<Text, Text>, acc: TreeAcc, lib: Text) -> Rc<dyn prism_rtl::Job<TreeAcc>> {
    Rc::new(WalkLib { has, texts, acc, lib })
}

/// ```prism
/// WalkModule: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text, Text, Bool -> TreeAcc
/// ```
pub fn walk_module(has: &Map<Text, bool>, texts: &Map<Text, Text>, acc: &TreeAcc, main: &Text, name: &Text, parent: &Text, in_test: &bool) -> TreeAcc {
    let dir = dir_of(main);
    let text_ = or(&get(texts, main), &Text::lit(""));
    let heads = header_lines(&text_);
    let mods = filter(&heads, &(|h: &HeadLine| (&h.word == &Text::lit("mod")) || (&h.word == &Text::lit("test mod"))));
    let subs = filter(&mods, &(|h: &HeadLine| crate::check::env::is_upper_text(&h.arg)));
    let lower_ = filter(&mods, &(|h: &HeadLine| !crate::check::env::is_upper_text(&h.arg)));
    let named_ = if name == &Text::lit("") {
        Text::lit("its path makes it the root")
    } else {
        Text::from(format!("its path names the module `{}`", name))
    };
    let acc1 = fold(&filter(&heads, &(|h: &HeadLine| &h.word == &Text::lit("module"))), acc, &(|a: &TreeAcc, h: &HeadLine| add_tree_diag(a, main, &h.span, &Text::lit("module-line"), &Text::from(format!("a module\'s file has no `module` line: {}", &named_)), &Text::lit("delete the line"))));
    let leaf = !crate::check::types::has_text(&Array::from(vec![Text::lit("mod.prism"), Text::lit("app.prism"), Text::lit("lib.prism")]), &base_of(main));
    let stem = or(&crate::syntax::lexer::chars::before_suffix(&base_of(main), &Text::lit(".prism")), main);
    let acc2 = if leaf {
        fold(&mods, &acc1, &(|a: &TreeAcc, h: &HeadLine| add_tree_diag(a, main, &h.span, &Text::lit("mod-leaf"), &Text::from(format!("`{}` declares `{} {}`, and a module with children is a directory", &base_of(main), &h.word, &h.arg)), &Text::from(format!("move {} to {}/mod.prism", &base_of(main), &stem)))))
    } else {
        acc1.clone()
    };
    let acc3 = fold(&lower_, &acc2, &(|a: &TreeAcc, h: &HeadLine| lowercase(a, main, &dir, h)));
    let acc4 = {
        let mut this: TreeAcc = acc3.clone();
        this.declared = insert(&this.declared, main, &true);
        this.units = push(&this.units, &ModFiles { name: name.clone(), named: true, segs: Array::from(vec![Seg { path_: main.clone(), text: text_.clone(), role: if *in_test { Text::lit("test") } else { Text::lit("main") } }]), parent: parent.clone() });
        this
    };
    if leaf {
        acc4.clone()
    } else {
        run_to_end(fold_job(subs.clone(), acc4.clone(), {
            let has = has.clone();
            let texts = texts.clone();
            let main = main.clone();
            let dir = dir.clone();
            let name = name.clone();
            let in_test = *in_test;
            Rc::new(move |(p0, p1): (TreeAcc, HeadLine)| {
                let has = has.clone();
                let texts = texts.clone();
                let main = main.clone();
                let dir = dir.clone();
                let name = name.clone();
                let in_test = in_test;
                entered(once_job(move || {
                    let a = p0;
                    let h = p1;
                    prism_rtl::Turn::More(Rc::new(Child { has: has.clone(), texts: texts.clone(), acc: a.clone(), main: main.clone(), dir: dir.clone(), h: h.clone(), parent: name.clone(), in_test }))
                }))
            }) as Rc<dyn Fn((TreeAcc, HeadLine)) -> Rc<dyn prism_rtl::Job<TreeAcc>>>
        }))
    }
}

/// The step machine of `WalkModule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WalkModule: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text, Text, Bool -> TreeAcc
/// ```
pub struct WalkModule {
    pub has: Map<Text, bool>,
    pub texts: Map<Text, Text>,
    pub acc: TreeAcc,
    pub main: Text,
    pub name: Text,
    pub parent: Text,
    pub in_test: bool,
}

impl prism_rtl::Job<TreeAcc> for WalkModule {
    fn cycle(&self) -> prism_rtl::Turn<TreeAcc> {
        let has = &self.has;
        let texts = &self.texts;
        let acc = &self.acc;
        let main = &self.main;
        let name = &self.name;
        let parent = &self.parent;
        let in_test = &self.in_test;
        let dir = dir_of(main);
        let text_ = or(&get(texts, main), &Text::lit(""));
        let heads = header_lines(&text_);
        let mods = filter(&heads, &(|h: &HeadLine| (&h.word == &Text::lit("mod")) || (&h.word == &Text::lit("test mod"))));
        let subs = filter(&mods, &(|h: &HeadLine| crate::check::env::is_upper_text(&h.arg)));
        let lower_ = filter(&mods, &(|h: &HeadLine| !crate::check::env::is_upper_text(&h.arg)));
        let named_ = if name == &Text::lit("") {
            Text::lit("its path makes it the root")
        } else {
            Text::from(format!("its path names the module `{}`", name))
        };
        let acc1 = fold(&filter(&heads, &(|h: &HeadLine| &h.word == &Text::lit("module"))), acc, &(|a: &TreeAcc, h: &HeadLine| add_tree_diag(a, main, &h.span, &Text::lit("module-line"), &Text::from(format!("a module\'s file has no `module` line: {}", &named_)), &Text::lit("delete the line"))));
        let leaf = !crate::check::types::has_text(&Array::from(vec![Text::lit("mod.prism"), Text::lit("app.prism"), Text::lit("lib.prism")]), &base_of(main));
        let stem = or(&crate::syntax::lexer::chars::before_suffix(&base_of(main), &Text::lit(".prism")), main);
        let acc2 = if leaf {
            fold(&mods, &acc1, &(|a: &TreeAcc, h: &HeadLine| add_tree_diag(a, main, &h.span, &Text::lit("mod-leaf"), &Text::from(format!("`{}` declares `{} {}`, and a module with children is a directory", &base_of(main), &h.word, &h.arg)), &Text::from(format!("move {} to {}/mod.prism", &base_of(main), &stem)))))
        } else {
            acc1.clone()
        };
        let acc3 = fold(&lower_, &acc2, &(|a: &TreeAcc, h: &HeadLine| lowercase(a, main, &dir, h)));
        let acc4 = {
            let mut this: TreeAcc = acc3.clone();
            this.declared = insert(&this.declared, main, &true);
            this.units = push(&this.units, &ModFiles { name: name.clone(), named: true, segs: Array::from(vec![Seg { path_: main.clone(), text: text_.clone(), role: if *in_test { Text::lit("test") } else { Text::lit("main") } }]), parent: parent.clone() });
            this
        };
        if leaf {
            prism_rtl::Turn::Finished(acc4.clone())
        } else {
            fold_job(subs.clone(), acc4.clone(), {
                let has = has.clone();
                let texts = texts.clone();
                let main = main.clone();
                let dir = dir.clone();
                let name = name.clone();
                let in_test = *in_test;
                Rc::new(move |(p0, p1): (TreeAcc, HeadLine)| {
                    let has = has.clone();
                    let texts = texts.clone();
                    let main = main.clone();
                    let dir = dir.clone();
                    let name = name.clone();
                    let in_test = in_test;
                    entered(once_job(move || {
                        let a = p0;
                        let h = p1;
                        prism_rtl::Turn::More(Rc::new(Child { has: has.clone(), texts: texts.clone(), acc: a.clone(), main: main.clone(), dir: dir.clone(), h: h.clone(), parent: name.clone(), in_test }))
                    }))
                }) as Rc<dyn Fn((TreeAcc, HeadLine)) -> Rc<dyn prism_rtl::Job<TreeAcc>>>
            }).cycle()
        }
    }
}

/// `Start WalkModule, x`: what the function value is when passed to `@Run`.
pub fn start_walk_module(has: Map<Text, bool>, texts: Map<Text, Text>, acc: TreeAcc, main: Text, name: Text, parent: Text, in_test: bool) -> Rc<dyn prism_rtl::Job<TreeAcc>> {
    Rc::new(WalkModule { has, texts, acc, main, name, parent, in_test })
}

/// ```prism
/// Lowercase: fn TreeAcc, Text, Text, HeadLine -> TreeAcc
/// ```
pub fn lowercase(a: &TreeAcc, main: &Text, dir: &Text, h: &HeadLine) -> TreeAcc {
    let up = Text::from(format!("{}{}", &upper(&crate::syntax::lexer::chars::head(&h.arg)), &crate::syntax::lexer::chars::after_first(&h.arg)));
    let marked = {
        let mut this: TreeAcc = a.clone();
        this.declared = insert(&this.declared, &under(dir, &Text::from(format!("{}.prism", &h.arg))), &true);
        this
    };
    add_tree_diag(&marked, main, &h.span, &Text::lit("mod-lowercase"), &Text::from(format!("`{} {}`: a module\'s name is capitalised, and every `mod` line declares a module with a namespace of its own", &h.word, &h.arg)), &Text::from(format!("write `{} {}` (its file {}.prism, with a header of its own)", &h.word, &up, &h.arg)))
}

/// ```prism
/// Child: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text, HeadLine, Text, Bool -> TreeAcc
/// ```
pub fn child(has: &Map<Text, bool>, texts: &Map<Text, Text>, acc: &TreeAcc, main: &Text, dir: &Text, h: &HeadLine, parent: &Text, in_test: &bool) -> TreeAcc {
    let snake = dir_name(&h.arg);
    let file = under(dir, &Text::from(format!("{}.prism", &snake)));
    let nested = under(dir, &Text::from(format!("{}/mod.prism", &snake)));
    let name = if parent == &Text::lit("") {
        h.arg.clone()
    } else {
        Text::from(format!("{}.{}", parent, &h.arg))
    };
    let is_test = *in_test || (&h.word == &Text::lit("test mod"));
    let line = Text::from(format!("{} {}", &h.word, &h.arg));
    if (&file == main) || (&nested == main) {
        add_tree_diag(acc, main, &h.span, &Text::lit("mod-self"), &Text::from(format!("`{}` names `{}`, the file that declares it", &line, &base_of(main))), &Text::lit("rename the module"))
    } else {
        if crate::check::env::has_key(has, &file) && crate::check::env::has_key(has, &nested) {
            {
                let both_ = {
                    let mut this: TreeAcc = acc.clone();
                    this.declared = insert(&insert(&this.declared, &file, &true), &nested, &true);
                    this
                };
                add_tree_diag(&both_, main, &h.span, &Text::lit("mod-both"), &Text::from(format!("`{}` declares `{}.prism` or `{}/mod.prism`, and both are there", &line, &snake, &snake)), &Text::from(format!("keep one: {}/mod.prism when the module has children, else {}.prism", &snake, &snake)))
            }
        } else {
            if crate::check::env::has_key(has, &file) {
                walk_module(has, texts, acc, &file, &name, main, &is_test)
            } else {
                if crate::check::env::has_key(has, &nested) {
                    walk_module(has, texts, acc, &nested, &name, main, &is_test)
                } else {
                    add_tree_diag(acc, main, &h.span, &Text::lit("mod-missing"), &Text::from(format!("`{}` declares `{}.prism` or `{}/mod.prism`, and neither is there", &line, &snake, &snake)), &Text::from(format!("create {}.prism, or delete the line", &snake)))
                }
            }
        }
    }
}

/// The step machine of `Child`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Child: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text, HeadLine, Text, Bool -> TreeAcc
/// ```
pub struct Child {
    pub has: Map<Text, bool>,
    pub texts: Map<Text, Text>,
    pub acc: TreeAcc,
    pub main: Text,
    pub dir: Text,
    pub h: HeadLine,
    pub parent: Text,
    pub in_test: bool,
}

impl prism_rtl::Job<TreeAcc> for Child {
    fn cycle(&self) -> prism_rtl::Turn<TreeAcc> {
        let has = &self.has;
        let texts = &self.texts;
        let acc = &self.acc;
        let main = &self.main;
        let dir = &self.dir;
        let h = &self.h;
        let parent = &self.parent;
        let in_test = &self.in_test;
        let snake = dir_name(&h.arg);
        let file = under(dir, &Text::from(format!("{}.prism", &snake)));
        let nested = under(dir, &Text::from(format!("{}/mod.prism", &snake)));
        let name = if parent == &Text::lit("") {
            h.arg.clone()
        } else {
            Text::from(format!("{}.{}", parent, &h.arg))
        };
        let is_test = *in_test || (&h.word == &Text::lit("test mod"));
        let line = Text::from(format!("{} {}", &h.word, &h.arg));
        if (&file == main) || (&nested == main) {
            prism_rtl::Turn::Finished(add_tree_diag(acc, main, &h.span, &Text::lit("mod-self"), &Text::from(format!("`{}` names `{}`, the file that declares it", &line, &base_of(main))), &Text::lit("rename the module")))
        } else {
            if crate::check::env::has_key(has, &file) && crate::check::env::has_key(has, &nested) {
                {
                    let both_ = {
                        let mut this: TreeAcc = acc.clone();
                        this.declared = insert(&insert(&this.declared, &file, &true), &nested, &true);
                        this
                    };
                    prism_rtl::Turn::Finished(add_tree_diag(&both_, main, &h.span, &Text::lit("mod-both"), &Text::from(format!("`{}` declares `{}.prism` or `{}/mod.prism`, and both are there", &line, &snake, &snake)), &Text::from(format!("keep one: {}/mod.prism when the module has children, else {}.prism", &snake, &snake))))
                }
            } else {
                if crate::check::env::has_key(has, &file) {
                    prism_rtl::Turn::More(Rc::new(WalkModule { has: has.clone(), texts: texts.clone(), acc: acc.clone(), main: file.clone(), name: name.clone(), parent: main.clone(), in_test: is_test }))
                } else {
                    if crate::check::env::has_key(has, &nested) {
                        prism_rtl::Turn::More(Rc::new(WalkModule { has: has.clone(), texts: texts.clone(), acc: acc.clone(), main: nested.clone(), name: name.clone(), parent: main.clone(), in_test: is_test }))
                    } else {
                        prism_rtl::Turn::Finished(add_tree_diag(acc, main, &h.span, &Text::lit("mod-missing"), &Text::from(format!("`{}` declares `{}.prism` or `{}/mod.prism`, and neither is there", &line, &snake, &snake)), &Text::from(format!("create {}.prism, or delete the line", &snake))))
                    }
                }
            }
        }
    }
}

/// `Start Child, x`: what the function value is when passed to `@Run`.
pub fn start_child(has: Map<Text, bool>, texts: Map<Text, Text>, acc: TreeAcc, main: Text, dir: Text, h: HeadLine, parent: Text, in_test: bool) -> Rc<dyn prism_rtl::Job<TreeAcc>> {
    Rc::new(Child { has, texts, acc, main, dir, h, parent, in_test })
}

/// ```prism
/// Stray: fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text -> TreeAcc
/// ```
pub fn stray(has: &Map<Text, bool>, texts: &Map<Text, Text>, acc: &TreeAcc, f: &Text) -> TreeAcc {
    let text_ = or(&get(texts, f), &Text::lit(""));
    if crate::syntax::lexer::chars::has_suffix(f, &Text::lit(".prismtest")) {
        add_tree_diag(acc, f, &no_span(), &Text::lit("mod-stray"), &Text::from(format!("`{}` is a test script in a tree, where tests are in test modules", &base_of(f))), &Text::lit("put its declarations in a test module, declared by `test mod Tests`"))
    } else {
        {
            let dir = dir_of(f);
            let is_main = &base_of(f) == &Text::lit("mod.prism");
            let home = if is_main { dir_of(&dir) } else { dir.clone() };
            let main = fold(&Array::from(vec![Text::lit("mod.prism"), Text::lit("app.prism"), Text::lit("lib.prism")]), &Text::lit(""), &(|m: &Text, n: &Text| if (m == &Text::lit("")) && crate::check::env::has_key(has, &under(&home, n)) {
                n.clone()
            } else {
                m.clone()
            }));
            let line = if is_main {
                Text::from(format!("mod {}", &mod_of_dir(&base_of(&dir))))
            } else {
                Text::from(format!("mod {}", &mod_of_dir(&or(&crate::syntax::lexer::chars::before_suffix(&base_of(f), &Text::lit(".prism")), f))))
            };
            let shown = if is_main { Text::from(format!("{}/mod.prism", &base_of(&dir))) } else { base_of(f) };
            if &main == &Text::lit("") {
                add_tree_diag(acc, f, &no_span(), &Text::lit("mod-stray"), &Text::from(format!("`{}` is in a tree, in no module\'s directory", f)), &Text::lit("move it into a module\'s directory and declare it with a `mod` line"))
            } else {
                add_tree_diag(acc, f, &no_span(), &Text::lit("mod-stray"), &Text::from(format!("`{}` is in the directory of `{}`, which declares no `{}`", &shown, &main, &line)), &Text::from(format!("declare it with `{}` in {}, or move it out of the directory", &line, &main)))
            }
        }
    }
}

/// ```prism
/// ReachTree: unbounded fn [ModFiles], Text -> [ModFiles]
/// ```
pub fn reach_tree(units: &Array<ModFiles>, main: &Text) -> Array<ModFiles> {
    let by_name = fold(units, &Map::new(), &(|m: &Map<Text, ModFiles>, u: &ModFiles| insert(m, &unit_name(u), u)));
    let start = fold(units, &Array::new(), &(|s: &Array<Text>, u: &ModFiles| if (&main_path(u) == main) || ((&u.parent == main) && is_test_unit(u)) {
        push(s, &unit_name(u))
    } else {
        s.clone()
    }));
    let reached = reach_names(&by_name, &start, &start);
    filter(units, &(|u: &ModFiles| crate::check::types::has_text(&reached, &unit_name(u))))
}

/// The step machine of `ReachTree`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReachTree: unbounded fn [ModFiles], Text -> [ModFiles]
/// ```
pub struct ReachTree {
    pub units: Array<ModFiles>,
    pub main: Text,
}

impl prism_rtl::Job<Array<ModFiles>> for ReachTree {
    fn cycle(&self) -> prism_rtl::Turn<Array<ModFiles>> {
        let units = &self.units;
        let main = &self.main;
        let by_name = fold(units, &Map::new(), &(|m: &Map<Text, ModFiles>, u: &ModFiles| insert(m, &unit_name(u), u)));
        let start = fold(units, &Array::new(), &(|s: &Array<Text>, u: &ModFiles| if (&main_path(u) == main) || ((&u.parent == main) && is_test_unit(u)) {
            push(s, &unit_name(u))
        } else {
            s.clone()
        }));
        let units = units.clone();
        call_then(start_reach_names(by_name.clone(), start.clone(), start.clone()), move |reach_names_22458: Array<Text>| {
            let reached = reach_names_22458;
            prism_rtl::Turn::Finished(filter(&units, &(|u: &ModFiles| crate::check::types::has_text(&reached, &unit_name(u)))))
        })
    }
}

/// `Start ReachTree, x`: what the function value is when passed to `@Run`.
pub fn start_reach_tree(units: Array<ModFiles>, main: Text) -> Rc<dyn prism_rtl::Job<Array<ModFiles>>> {
    Rc::new(ReachTree { units, main })
}

/// ```prism
/// ReachNames: unbounded fn (Text ==> ModFiles), [Text], [Text] -> [Text]
/// ```
pub fn reach_names(by_name: &Map<Text, ModFiles>, seen: &Array<Text>, todo: &Array<Text>) -> Array<Text> {
    match index(todo, &Nat::from(0u32)) {
        None => seen.clone(),
        Some(n) => {
            let uses = match get(by_name, &n) {
                Some(u) => each(&filter(&header_lines(&main_text(&u)), &(|h: &HeadLine| &h.word == &Text::lit("use"))), &(|h: &HeadLine| use_target(by_name, &h.arg))),
                None => Array::new(),
            };
            let fresh = filter(&uses, &(|x: &Text| !crate::check::types::has_text(seen, x) && crate::check::env::has_key(by_name, x)));
            reach_names(by_name, &crate::check::types::union_texts(seen, &fresh), &append(&drop(todo, &Nat::from(1u32)), &fresh))
        },
    }
}

/// The step machine of `ReachNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReachNames: unbounded fn (Text ==> ModFiles), [Text], [Text] -> [Text]
/// ```
pub struct ReachNames {
    pub by_name: Map<Text, ModFiles>,
    pub seen: Array<Text>,
    pub todo: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for ReachNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let by_name = &self.by_name;
        let seen = &self.seen;
        let todo = &self.todo;
        match index(todo, &Nat::from(0u32)) {
            None => prism_rtl::Turn::Finished(seen.clone()),
            Some(n) => {
                let uses = match get(by_name, &n) {
                    Some(u) => each(&filter(&header_lines(&main_text(&u)), &(|h: &HeadLine| &h.word == &Text::lit("use"))), &(|h: &HeadLine| use_target(by_name, &h.arg))),
                    None => Array::new(),
                };
                let fresh = filter(&uses, &(|x: &Text| !crate::check::types::has_text(seen, x) && crate::check::env::has_key(by_name, x)));
                prism_rtl::Turn::More(Rc::new(ReachNames { by_name: by_name.clone(), seen: crate::check::types::union_texts(seen, &fresh), todo: append(&drop(todo, &Nat::from(1u32)), &fresh) }))
            },
        }
    }
}

/// `Start ReachNames, x`: what the function value is when passed to `@Run`.
pub fn start_reach_names(by_name: Map<Text, ModFiles>, seen: Array<Text>, todo: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ReachNames { by_name, seen, todo })
}

/// ```prism
/// UseTarget: fn (Text ==> ModFiles), Text -> Text
/// ```
pub fn use_target(by_name: &Map<Text, ModFiles>, u: &Text) -> Text {
    if (u == &Text::lit("App")) && !crate::check::env::has_key(by_name, &Text::lit("App")) {
        Text::lit("")
    } else {
        u.clone()
    }
}

/// ```prism
/// IsTestUnit: fn ModFiles -> Bool
/// ```
pub fn is_test_unit(u: &ModFiles) -> bool {
    match index(&u.segs, &Nat::from(0u32)) {
        Some(s) => &s.role == &Text::lit("test"),
        None => false,
    }
}

/// ```prism
/// UnitName: fn ModFiles -> Text
/// ```
pub fn unit_name(u: &ModFiles) -> Text {
    if u.named {
        u.name.clone()
    } else {
        fold(&header_lines(&main_text(u)), &Text::lit(""), &(|n: &Text, h: &HeadLine| if &h.word == &Text::lit("module") { h.arg.clone() } else { n.clone() }))
    }
}

/// ```prism
/// RenderTreeDiag: fn (Text ==> Text), TreeDiag -> Text
/// ```
pub fn render_tree_diag(texts: &Map<Text, Text>, d: &TreeDiag) -> Text {
    crate::check::errors::render_cdiag(&Array::from(vec![crate::check::errors::mk_src(&d.path_, &or(&get(texts, &d.path_), &Text::lit("")))]), &crate::check::errors::CDiag { code: d.code.clone(), file: Nat::from(0u32), span: d.span.clone(), message: d.message.clone(), fix: d.fix.clone() })
}

/// ```prism
/// TreeReport: fn ReadInput, [TreeDiag] -> Text
/// ```
pub fn tree_report(input: &ReadInput, ds: &Array<TreeDiag>) -> Text {
    let texts = map(&input.texts);
    let n = len(ds);
    Text::from(format!("{}{} error{}", &concat(&each(ds, &(|d: &TreeDiag| render_tree_diag(&texts, d)))), &n, &(if &n == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") })))
}

/// ```prism
/// ParseUnit: unbounded fn ModFiles -> ((Src, Parsed))
/// ```
pub fn parse_unit(u: &ModFiles) -> (crate::check::errors::Src, crate::syntax::parser::Parsed) {
    let src = crate::check::errors::mk_joined_src(&each(&u.segs, &(|s: &Seg| (s.path_.clone(), s.text.clone(), s.role.clone()))));
    let parsed = crate::syntax::parser::parse_file(&src.text);
    let t0 = parsed.tree.clone();
    let tree = if !u.named {
        t0.clone()
    } else {
        {
            let mut this: crate::syntax::Module = t0.clone();
            this.name = if &u.name == &Text::lit("") {
                None
            } else {
                Some(crate::syntax::QualName { path_: split_on(&u.name, &Text::lit(".")), span: no_span() })
            };
            this
        }
    };
    (src.clone(), crate::syntax::parser::Parsed { tree: tree.clone(), diags: parsed.diags.clone() })
}

/// The step machine of `ParseUnit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseUnit: unbounded fn ModFiles -> ((Src, Parsed))
/// ```
pub struct ParseUnit {
    pub u: ModFiles,
}

impl prism_rtl::Job<(crate::check::errors::Src, crate::syntax::parser::Parsed)> for ParseUnit {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::errors::Src, crate::syntax::parser::Parsed)> {
        let u = &self.u;
        let src = crate::check::errors::mk_joined_src(&each(&u.segs, &(|s: &Seg| (s.path_.clone(), s.text.clone(), s.role.clone()))));
        let u = u.clone();
        call_then(crate::syntax::parser::start_parse_file(src.text.clone()), move |parse_file_24471: crate::syntax::parser::Parsed| {
            let parsed = parse_file_24471;
            let t0 = parsed.tree.clone();
            let tree = if !u.named {
                t0.clone()
            } else {
                {
                    let mut this: crate::syntax::Module = t0.clone();
                    this.name = if &u.name == &Text::lit("") {
                        None
                    } else {
                        Some(crate::syntax::QualName { path_: split_on(&u.name, &Text::lit(".")), span: no_span() })
                    };
                    this
                }
            };
            prism_rtl::Turn::Finished((src.clone(), crate::syntax::parser::Parsed { tree: tree.clone(), diags: parsed.diags.clone() }))
        })
    }
}

/// `Start ParseUnit, x`: what the function value is when passed to `@Run`.
pub fn start_parse_unit(u: ModFiles) -> Rc<dyn prism_rtl::Job<(crate::check::errors::Src, crate::syntax::parser::Parsed)>> {
    Rc::new(ParseUnit { u })
}

/// ```prism
/// ParseProgram: unbounded fn Assembled -> ParsedProgram
/// ```
pub fn parse_program(read: &Assembled) -> ParsedProgram {
    let parsed = run_to_end(each_job(read.units.clone(), Rc::new(move |p0: ModFiles| entered(once_job(move || {
        let u = p0;
        prism_rtl::Turn::More(Rc::new(ParseUnit { u: u.clone() }))
    }))) as Rc<dyn Fn(ModFiles) -> Rc<dyn prism_rtl::Job<(crate::check::errors::Src, crate::syntax::parser::Parsed)>>>));
    let user_mods = fold(&parsed, &Array::new(), &(|acc: &Array<Text>, (_, p_): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| push(acc, &crate::check::env::mod_name(&p_.tree))));
    let user_fams = fold(&parsed, &Array::new(), &(|acc: &Array<Text>, (_, p_): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| append(acc, &tag_families(&p_.tree))));
    let pre_parsed = run_to_end(each_job(read.prelude.clone(), Rc::new(move |p0: ModFiles| entered(once_job(move || {
        let u = p0;
        prism_rtl::Turn::More(Rc::new(ParseUnit { u: u.clone() }))
    }))) as Rc<dyn Fn(ModFiles) -> Rc<dyn prism_rtl::Job<(crate::check::errors::Src, crate::syntax::parser::Parsed)>>>));
    let kept = filter(&pre_parsed, &(|(_, p_): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| !crate::check::types::has_text(&user_mods, &crate::check::env::mod_name(&p_.tree)) && !any_in(&tag_families(&p_.tree), &user_fams)));
    let all = append(&parsed, &kept);
    let errors = fold(&all, &Text::lit(""), &(|acc: &Text, (src, p_): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| if crate::program::any_errors(&p_.diags) {
        Text::from(format!("{}{}", acc, &render_parse(src, &p_.diags)))
    } else {
        acc.clone()
    }));
    ParsedProgram { srcs: each(&all, &(|(s, _): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| s.clone())), trees: each(&all, &(|(_, p_): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| p_.tree.clone())), shown: len(&parsed), parents: each(&read.units, &(|u: &ModFiles| u.parent.clone())), errors: errors.clone() }
}

/// The step machine of `ParseProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseProgram: unbounded fn Assembled -> ParsedProgram
/// ```
pub struct ParseProgram {
    pub read: Assembled,
}

impl prism_rtl::Job<ParsedProgram> for ParseProgram {
    fn cycle(&self) -> prism_rtl::Turn<ParsedProgram> {
        let read = &self.read;
        let read = read.clone();
        call_value(each_job(read.units.clone(), Rc::new(move |p0: ModFiles| entered(once_job(move || {
            let u = p0;
            prism_rtl::Turn::More(Rc::new(ParseUnit { u: u.clone() }))
        }))) as Rc<dyn Fn(ModFiles) -> Rc<dyn prism_rtl::Job<(crate::check::errors::Src, crate::syntax::parser::Parsed)>>>), move |each_25155: Array<(crate::check::errors::Src, crate::syntax::parser::Parsed)>| {
            let parsed = each_25155;
            let user_mods = fold(&parsed, &Array::new(), &(|acc: &Array<Text>, (_, p_): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| push(acc, &crate::check::env::mod_name(&p_.tree))));
            let user_fams = fold(&parsed, &Array::new(), &(|acc: &Array<Text>, (_, p_): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| append(acc, &tag_families(&p_.tree))));
            call_value(each_job(read.prelude.clone(), Rc::new(move |p0: ModFiles| entered(once_job(move || {
                let u = p0;
                prism_rtl::Turn::More(Rc::new(ParseUnit { u: u.clone() }))
            }))) as Rc<dyn Fn(ModFiles) -> Rc<dyn prism_rtl::Job<(crate::check::errors::Src, crate::syntax::parser::Parsed)>>>), move |each_25389: Array<(crate::check::errors::Src, crate::syntax::parser::Parsed)>| {
                let pre_parsed = each_25389;
                let kept = filter(&pre_parsed, &(|(_, p_): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| !crate::check::types::has_text(&user_mods, &crate::check::env::mod_name(&p_.tree)) && !any_in(&tag_families(&p_.tree), &user_fams)));
                let all = append(&parsed, &kept);
                let errors = fold(&all, &Text::lit(""), &(|acc: &Text, (src, p_): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| if crate::program::any_errors(&p_.diags) {
                    Text::from(format!("{}{}", acc, &render_parse(src, &p_.diags)))
                } else {
                    acc.clone()
                }));
                prism_rtl::Turn::Finished(ParsedProgram { srcs: each(&all, &(|(s, _): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| s.clone())), trees: each(&all, &(|(_, p_): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| p_.tree.clone())), shown: len(&parsed), parents: each(&read.units, &(|u: &ModFiles| u.parent.clone())), errors: errors.clone() })
            })
        })
    }
}

/// `Start ParseProgram, x`: what the function value is when passed to `@Run`.
pub fn start_parse_program(read: Assembled) -> Rc<dyn prism_rtl::Job<ParsedProgram>> {
    Rc::new(ParseProgram { read })
}

/// ```prism
/// TreeDeclDiags: fn ParsedProgram -> [CDiag]
/// ```
pub fn tree_decl_diags(pp: &ParsedProgram) -> Array<crate::check::errors::CDiag> {
    fold(&crate::check::errors::range0(&pp.shown), &Array::new(), &(|acc: &Array<crate::check::errors::CDiag>, i: &Nat| match index(&pp.srcs, i) {
        Some(src) => fold(&or(&index(&pp.trees, i), &crate::check::env::empty_module()).decls, acc, &(|a: &Array<crate::check::errors::CDiag>, d: &crate::syntax::decls::Decl| append(a, &decl_role_diags(&src, &or(&index(&pp.parents, i), &Text::lit("")), i, d)))),
        None => acc.clone(),
    }))
}

/// ```prism
/// DeclRoleDiags: fn Src, Text, Nat, Decl -> [CDiag]
/// ```
pub fn decl_role_diags(src: &crate::check::errors::Src, parent: &Text, i: &Nat, d: &crate::syntax::decls::Decl) -> Array<crate::check::errors::CDiag> {
    let seg = crate::check::errors::seg_at(src, &d.span.start);
    let role = seg.role.clone();
    let main = base_of(&src.path_);
    let tested = if (&seg.path_ == &src.path_) && (parent != &Text::lit("")) {
        base_of(parent)
    } else {
        main.clone()
    };
    let what = match &d.kind {
        crate::syntax::decls::DeclKind::DTest(_) => Text::lit("test"),
        crate::syntax::decls::DeclKind::DCheck(_) => Text::lit("check"),
        crate::syntax::decls::DeclKind::DTag(_) => Text::lit("tag"),
        crate::syntax::decls::DeclKind::DTrait(_) => Text::lit("trait"),
        crate::syntax::decls::DeclKind::DImpl(_) => Text::lit("impl"),
        _ => Text::lit(""),
    };
    if (&role == &Text::lit("main")) && ((&what == &Text::lit("test")) || (&what == &Text::lit("check"))) {
        Array::from(vec![crate::check::errors::CDiag { code: Text::lit("test-outside"), file: i.clone(), span: d.span.clone(), message: Text::from(format!("a `{}` in a tree stands only in a test module", &what)), fix: Text::from(format!("move it to a test module: `test mod Tests` in {}, and tests.prism", &main)) }])
    } else {
        if (&role == &Text::lit("test")) && (((&what == &Text::lit("tag")) || (&what == &Text::lit("trait"))) || (&what == &Text::lit("impl"))) {
            Array::from(vec![crate::check::errors::CDiag { code: Text::lit("test-declares"), file: i.clone(), span: d.span.clone(), message: Text::lit("a test module declares no tag, trait or impl"), fix: Text::from(format!("declare it in {}, the module the test module tests", &tested)) }])
        } else {
            Array::new()
        }
    }
}

/// ```prism
/// TagFamilies: fn Module -> [Text]
/// ```
pub fn tag_families(m: &crate::syntax::Module) -> Array<Text> {
    fold(&m.decls, &Array::new(), &(|acc: &Array<Text>, d: &crate::syntax::decls::Decl| match &d.kind {
        crate::syntax::decls::DeclKind::DTag(t) => push(acc, &crate::syntax::lexer::chars::join(&take(&t.name.path_, &crate::syntax::lexer::chars::dec(&len(&t.name.path_))), &Text::lit("."))),
        _ => acc.clone(),
    }))
}

/// ```prism
/// AnyIn: fn [Text], [Text] -> Bool
/// ```
pub fn any_in(xs: &Array<Text>, ys: &Array<Text>) -> bool {
    fold(xs, &false, &(|seen: &bool, x: &Text| *seen || crate::check::types::has_text(ys, x)))
}

/// ```prism
/// RenderParse: fn Src, [Diag] -> Text
/// ```
pub fn render_parse(src: &crate::check::errors::Src, ds: &Array<crate::syntax::Diag>) -> Text {
    concat(&each(&filter(ds, &(|d: &crate::syntax::Diag| &d.stage != &Text::lit("out"))), &(|d: &crate::syntax::Diag| Text::from(format!("{}:{}: {}\n", &crate::check::errors::src_place(src, &d.span.start), &(&crate::syntax::lexer::chars::column_of(&src.text, &or(&index(&src.starts, &crate::check::errors::cline_of(&src.starts, &d.span.start)), &Nat::from(0u32)), &d.span.start) + &Nat::from(1u32)), &d.message)))))
}
