//! The module `Reading`, from `target/bootstrap/src/prismc/reading.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Assembled`:
///
/// ```prism
/// type Assembled = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Assembled {
    pub units: Array<ModFiles>,
    pub prelude: Array<ModFiles>,
    pub scripts: Array<Text>,
    pub errors: Array<TreeDiag>,
}

impl Show for Assembled {
    fn show(&self, p: &mut Printer) {
        p.record("Assembled", &[("units", &self.units), ("prelude", &self.prelude), ("scripts", &self.scripts), ("errors", &self.errors)]);
    }
}

impl ToPod for Assembled {
    fn to_pod(&self) -> Pod {
        Pod::record("Assembled", vec![("units", self.units.to_pod()), ("prelude", self.prelude.to_pod()), ("scripts", self.scripts.to_pod()), ("errors", self.errors.to_pod())])
    }
}

impl FromPod for Assembled {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Assembled { units: FromPod::from_pod(field(p, "units")?)?, prelude: FromPod::from_pod(field(p, "prelude")?)?, scripts: FromPod::from_pod(field(p, "scripts")?)?, errors: FromPod::from_pod(field(p, "errors")?)? })
    }
}

/// `CheckOpts`:
///
/// ```prism
/// type CheckOpts = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CheckOpts {
    pub world: Array<Text>,
    pub out: Option<Text>,
    pub typed: bool,
    pub unused: bool,
}

impl Show for CheckOpts {
    fn show(&self, p: &mut Printer) {
        p.record("CheckOpts", &[("world", &self.world), ("out", &self.out), ("typed", &self.typed), ("unused", &self.unused)]);
    }
}

impl ToPod for CheckOpts {
    fn to_pod(&self) -> Pod {
        Pod::record("CheckOpts", vec![("world", self.world.to_pod()), ("out", self.out.to_pod()), ("typed", self.typed.to_pod()), ("unused", self.unused.to_pod())])
    }
}

impl FromPod for CheckOpts {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CheckOpts { world: FromPod::from_pod(field(p, "world")?)?, out: FromPod::from_pod(field(p, "out")?)?, typed: FromPod::from_pod(field(p, "typed")?)?, unused: FromPod::from_pod(field(p, "unused")?)? })
    }
}

/// `CompileSettings`:
///
/// ```prism
/// type CompileSettings = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CompileSettings {
    pub out: Text,
    pub prelude: Text,
    pub name: Text,
    pub runtime: Text,
    pub target: Text,
}

impl Show for CompileSettings {
    fn show(&self, p: &mut Printer) {
        p.record("CompileSettings", &[("out", &self.out), ("prelude", &self.prelude), ("name", &self.name), ("runtime", &self.runtime), ("target", &self.target)]);
    }
}

impl ToPod for CompileSettings {
    fn to_pod(&self) -> Pod {
        Pod::record("CompileSettings", vec![("out", self.out.to_pod()), ("prelude", self.prelude.to_pod()), ("name", self.name.to_pod()), ("runtime", self.runtime.to_pod()), ("target", self.target.to_pod())])
    }
}

impl FromPod for CompileSettings {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CompileSettings { out: FromPod::from_pod(field(p, "out")?)?, prelude: FromPod::from_pod(field(p, "prelude")?)?, name: FromPod::from_pod(field(p, "name")?)?, runtime: FromPod::from_pod(field(p, "runtime")?)?, target: FromPod::from_pod(field(p, "target")?)? })
    }
}

/// `HeadLine`:
///
/// ```prism
/// type HeadLine = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct HeadLine {
    pub word: Text,
    pub arg: Text,
    pub span: crate::syntax::Range,
}

impl Show for HeadLine {
    fn show(&self, p: &mut Printer) {
        p.record("HeadLine", &[("word", &self.word), ("arg", &self.arg), ("span", &self.span)]);
    }
}

impl ToPod for HeadLine {
    fn to_pod(&self) -> Pod {
        Pod::record("HeadLine", vec![("word", self.word.to_pod()), ("arg", self.arg.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for HeadLine {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(HeadLine { word: FromPod::from_pod(field(p, "word")?)?, arg: FromPod::from_pod(field(p, "arg")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `ModFiles`:
///
/// ```prism
/// type ModFiles = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ModFiles {
    pub name: Text,
    pub named: bool,
    pub segs: Array<Seg>,
    pub parent: Text,
}

impl Show for ModFiles {
    fn show(&self, p: &mut Printer) {
        p.record("ModFiles", &[("name", &self.name), ("named", &self.named), ("segs", &self.segs), ("parent", &self.parent)]);
    }
}

impl ToPod for ModFiles {
    fn to_pod(&self) -> Pod {
        Pod::record("ModFiles", vec![("name", self.name.to_pod()), ("named", self.named.to_pod()), ("segs", self.segs.to_pod()), ("parent", self.parent.to_pod())])
    }
}

impl FromPod for ModFiles {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ModFiles { name: FromPod::from_pod(field(p, "name")?)?, named: FromPod::from_pod(field(p, "named")?)?, segs: FromPod::from_pod(field(p, "segs")?)?, parent: FromPod::from_pod(field(p, "parent")?)? })
    }
}

/// `ParsedProgram`:
///
/// ```prism
/// type ParsedProgram = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ParsedProgram {
    pub srcs: Array<crate::check::errors::Src>,
    pub trees: Array<crate::syntax::Module>,
    pub shown: Nat,
    pub parents: Array<Text>,
    pub errors: Text,
}

impl Show for ParsedProgram {
    fn show(&self, p: &mut Printer) {
        p.record("ParsedProgram", &[("srcs", &self.srcs), ("trees", &self.trees), ("shown", &self.shown), ("parents", &self.parents), ("errors", &self.errors)]);
    }
}

impl ToPod for ParsedProgram {
    fn to_pod(&self) -> Pod {
        Pod::record("ParsedProgram", vec![("srcs", self.srcs.to_pod()), ("trees", self.trees.to_pod()), ("shown", self.shown.to_pod()), ("parents", self.parents.to_pod()), ("errors", self.errors.to_pod())])
    }
}

impl FromPod for ParsedProgram {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ParsedProgram { srcs: FromPod::from_pod(field(p, "srcs")?)?, trees: FromPod::from_pod(field(p, "trees")?)?, shown: FromPod::from_pod(field(p, "shown")?)?, parents: FromPod::from_pod(field(p, "parents")?)?, errors: FromPod::from_pod(field(p, "errors")?)? })
    }
}

/// `ReadInput`:
///
/// ```prism
/// type ReadInput = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ReadInput {
    pub args: Array<Text>,
    pub prelude: Text,
    pub listings: Array<(Text, Array<Text>)>,
    pub paths: Array<Text>,
    pub texts: Array<(Text, Text)>,
    pub tests: bool,
    pub compiling: bool,
}

impl Show for ReadInput {
    fn show(&self, p: &mut Printer) {
        p.record("ReadInput", &[("args", &self.args), ("prelude", &self.prelude), ("listings", &self.listings), ("paths", &self.paths), ("texts", &self.texts), ("tests", &self.tests), ("compiling", &self.compiling)]);
    }
}

impl ToPod for ReadInput {
    fn to_pod(&self) -> Pod {
        Pod::record("ReadInput", vec![("args", self.args.to_pod()), ("prelude", self.prelude.to_pod()), ("listings", self.listings.to_pod()), ("paths", self.paths.to_pod()), ("texts", self.texts.to_pod()), ("tests", self.tests.to_pod()), ("compiling", self.compiling.to_pod())])
    }
}

impl FromPod for ReadInput {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ReadInput { args: FromPod::from_pod(field(p, "args")?)?, prelude: FromPod::from_pod(field(p, "prelude")?)?, listings: FromPod::from_pod(field(p, "listings")?)?, paths: FromPod::from_pod(field(p, "paths")?)?, texts: FromPod::from_pod(field(p, "texts")?)?, tests: FromPod::from_pod(field(p, "tests")?)?, compiling: FromPod::from_pod(field(p, "compiling")?)? })
    }
}

/// `ReadMode`:
///
/// ```prism
/// type ReadMode = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum ReadMode {
    Checking(CheckOpts),
    Compiling(CompileSettings),
}

impl Show for ReadMode {
    fn show(&self, p: &mut Printer) {
        match self {
            ReadMode::Checking(a0) => p.choice("Checking", &[a0]),
            ReadMode::Compiling(a0) => p.choice("Compiling", &[a0]),
        }
    }
}

impl ToPod for ReadMode {
    fn to_pod(&self) -> Pod {
        match self {
            ReadMode::Checking(a0) => Pod::Choice("Checking".into(), vec![a0.to_pod()]),
            ReadMode::Compiling(a0) => Pod::Choice("Compiling".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for ReadMode {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "Checking" && a.len() == 1 => Ok(ReadMode::Checking(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "Compiling" && a.len() == 1 => Ok(ReadMode::Compiling(FromPod::from_pod(&a[0])?)),
            other => mismatch("a ReadMode", other),
        }
    }
}

/// `Seg`:
///
/// ```prism
/// type Seg = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Seg {
    pub path_: Text,
    pub text: Text,
    pub role: Text,
}

impl Show for Seg {
    fn show(&self, p: &mut Printer) {
        p.record("Seg", &[("path", &self.path_), ("text", &self.text), ("role", &self.role)]);
    }
}

impl ToPod for Seg {
    fn to_pod(&self) -> Pod {
        Pod::record("Seg", vec![("path", self.path_.to_pod()), ("text", self.text.to_pod()), ("role", self.role.to_pod())])
    }
}

impl FromPod for Seg {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Seg { path_: FromPod::from_pod(field(p, "path")?)?, text: FromPod::from_pod(field(p, "text")?)?, role: FromPod::from_pod(field(p, "role")?)? })
    }
}

/// `TreeAcc`:
///
/// ```prism
/// type TreeAcc = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TreeAcc {
    pub units: Array<ModFiles>,
    pub declared: Map<Text, bool>,
    pub diags: Array<TreeDiag>,
}

impl Show for TreeAcc {
    fn show(&self, p: &mut Printer) {
        p.record("TreeAcc", &[("units", &self.units), ("declared", &self.declared), ("diags", &self.diags)]);
    }
}

impl ToPod for TreeAcc {
    fn to_pod(&self) -> Pod {
        Pod::record("TreeAcc", vec![("units", self.units.to_pod()), ("declared", self.declared.to_pod()), ("diags", self.diags.to_pod())])
    }
}

impl FromPod for TreeAcc {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TreeAcc { units: FromPod::from_pod(field(p, "units")?)?, declared: FromPod::from_pod(field(p, "declared")?)?, diags: FromPod::from_pod(field(p, "diags")?)? })
    }
}

/// `TreeDiag`:
///
/// ```prism
/// type TreeDiag = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TreeDiag {
    pub path_: Text,
    pub span: crate::syntax::Range,
    pub code: Text,
    pub message: Text,
    pub fix: Text,
}

impl Show for TreeDiag {
    fn show(&self, p: &mut Printer) {
        p.record("TreeDiag", &[("path", &self.path_), ("span", &self.span), ("code", &self.code), ("message", &self.message), ("fix", &self.fix)]);
    }
}

impl ToPod for TreeDiag {
    fn to_pod(&self) -> Pod {
        Pod::record("TreeDiag", vec![("path", self.path_.to_pod()), ("span", self.span.to_pod()), ("code", self.code.to_pod()), ("message", self.message.to_pod()), ("fix", self.fix.to_pod())])
    }
}

impl FromPod for TreeDiag {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TreeDiag { path_: FromPod::from_pod(field(p, "path")?)?, span: FromPod::from_pod(field(p, "span")?)?, code: FromPod::from_pod(field(p, "code")?)?, message: FromPod::from_pod(field(p, "message")?)?, fix: FromPod::from_pod(field(p, "fix")?)? })
    }
}

/// ```prism
/// IsCompiling: fn ReadMode -> Bool
/// ```
pub fn is_compiling(read_mode0: &ReadMode) -> bool {
    match read_mode0 {
        ReadMode::Compiling(_) => true,
        ReadMode::Checking(_) => false,
    }
}

// `@ReadSources` is inlined where it is applied.

// `@ReadUp` is inlined where it is applied.

// `@ReadTexts` is inlined where it is applied.

// `@ReadRun` is inlined where it is applied.

// `@RunRead` is inlined where it is applied.

// `@CheckRun` is inlined where it is applied.

// `@CompileRun` is inlined where it is applied.

/// ```prism
/// Pairs: fn [Text], (Nat ==> [Text]) -> [((Text, [Text]))]
/// ```
pub fn pairs(ds_p0: &Array<Text>, m_p1: &Map<Nat, Array<Text>>) -> Array<(Text, Array<Text>)> {
    each(&crate::check::errors::range0(&len(ds_p0)), &(|i_p2: &Nat| (or(&index(ds_p0, i_p2), &Text::lit("")), or(&get(m_p1, i_p2), &Array::new()))))
}

/// ```prism
/// ReadFailure: fn ?~Contents -> Text
/// ```
pub fn read_failure(opt0: &Option<Result<crate::fs::Contents, Error>>) -> Text {
    match opt0 {
        Some(c_r0) => contents_failure(c_r0),
        None => Text::lit("nothing was read"),
    }
}

/// ```prism
/// ContentsFailure: fn ~Contents -> Text
/// ```
pub fn contents_failure(arg0: &Result<crate::fs::Contents, Error>) -> Text {
    match arg0 {
        Ok(c_p0) => Text::lit(""),
        Err(c1_0) => c1_0.message.clone(),
    }
}

/// ```prism
/// ContentsText: fn ~Contents -> Text
/// ```
pub fn contents_text(arg0: &Result<crate::fs::Contents, Error>) -> Text {
    match arg0 {
        Ok(c_p0) => c_p0.text.clone(),
        Err(c1_0) => Text::lit(""),
    }
}

/// ```prism
/// IsSourcePath: fn Text -> Bool
/// ```
pub fn is_source_path(f_p0: &Text) -> bool {
    crate::syntax::lexer::chars::has_suffix(f_p0, &Text::lit(".prism")) || crate::syntax::lexer::chars::has_suffix(f_p0, &Text::lit(".prismtest"))
}

/// ```prism
/// DirOf: fn Text -> Text
/// ```
pub fn dir_of(p_p0: &Text) -> Text {
    crate::syntax::lexer::chars::join(&crate::syntax::lexer::chars::pop(&split_on(p_p0, &Text::lit("/"))), &Text::lit("/"))
}

/// ```prism
/// BaseOf: fn Text -> Text
/// ```
pub fn base_of(p_p0: &Text) -> Text {
    or(&crate::syntax::lexer::chars::last(&split_on(p_p0, &Text::lit("/"))), p_p0)
}

/// ```prism
/// Under: fn Text, Text -> Text
/// ```
pub fn under(d_p0: &Text, n_p1: &Text) -> Text {
    if (d_p0 == &Text::lit("")) || (d_p0 == &Text::lit(".")) {
        n_p1.clone()
    } else {
        Text::from(format!("{}/{}", d_p0, n_p1))
    }
}

/// ```prism
/// Ancestors: fn Text -> [Text]
/// ```
pub fn ancestors(d_p0: &Text) -> Array<Text> {
    let parts_p1 = split_on(d_p0, &Text::lit("/"));
    let n_p2 = len(&parts_p1);
    filter(&each(&crate::check::errors::range0(&crate::syntax::lexer::chars::dec(&n_p2)), &(|i_p3: &Nat| crate::syntax::lexer::chars::join(&take(&parts_p1, &or(&(&crate::syntax::lexer::chars::dec(&n_p2)).checked_sub(i_p3), &Nat::from(0u32))), &Text::lit("/")))), &(|a_p4: &Text| (a_p4 != &Text::lit("")) && (a_p4 != &Text::lit("."))))
}

/// ```prism
/// DirName: fn Text -> Text
/// ```
pub fn dir_name(name_p0: &Text) -> Text {
    let (out_p5, _) = crate::syntax::lexer::chars::fold_chars(name_p0, &(Text::lit(""), Text::lit("")), &(Rc::new(move |(p0, p1): ((Text, Text), Text)| once_job(move || {
        let (acc_p1, prev_p2) = p0;
        let c_p3 = p1;
        {
            let sep_p4 = if crate::syntax::lexer::chars::is_upper(&c_p3) && (crate::syntax::lexer::chars::is_lower(&prev_p2) || crate::syntax::lexer::chars::is_digit(&prev_p2)) {
                Text::lit("_")
            } else {
                Text::lit("")
            };
            prism_rtl::Turn::Finished((Text::from(format!("{}{}{}", &acc_p1, &sep_p4, &(if crate::syntax::lexer::chars::is_upper(&c_p3) {
                crate::prelude::lower(&c_p3)
            } else {
                c_p3.clone()
            }))), c_p3.clone()))
        }
    })) as Rc<dyn Fn(((Text, Text), Text)) -> Rc<dyn prism_rtl::Job<(Text, Text)>>>));
    out_p5.clone()
}

/// ```prism
/// ModOfDir: fn Text -> Text
/// ```
pub fn mod_of_dir(d_p0: &Text) -> Text {
    concat(&each(&split_on(d_p0, &Text::lit("_")), &(|w_p1: &Text| Text::from(format!("{}{}", &upper(&crate::syntax::lexer::chars::head(w_p1)), &crate::syntax::lexer::chars::after_first(w_p1))))))
}

/// ```prism
/// HeaderLines: fn Text -> [HeadLine]
/// ```
pub fn header_lines(text_p0: &Text) -> Array<HeadLine> {
    let (lines_p7, _, _) = fold(&split_on(text_p0, &Text::lit("\n")), &(Array::new(), Nat::from(0u32), true), &(|(acc_p1, at_p2, open_p3): &(Array<HeadLine>, Nat, bool), line_p4: &Text| {
        let next_p5 = &(at_p2 + &len_text(line_p4)) + &Nat::from(1u32);
        if !*open_p3 {
            (acc_p1.clone(), next_p5.clone(), false)
        } else {
            if ((&crate::syntax::lexer::chars::trim(line_p4) == &Text::lit("")) || crate::syntax::lexer::chars::has_prefix(line_p4, &Text::lit("#"))) || crate::syntax::lexer::chars::has_prefix(line_p4, &Text::lit(" ")) {
                (acc_p1.clone(), next_p5.clone(), true)
            } else {
                match head_line_of(line_p4, at_p2) {
                    Some(h_p6) => (push(acc_p1, &h_p6), next_p5.clone(), true),
                    None => (acc_p1.clone(), next_p5.clone(), false),
                }
            }
        }
    }));
    lines_p7.clone()
}

/// ```prism
/// ?HeadLineOf: fn Text, Nat -> ?HeadLine
/// ```
pub fn head_line_of(line_p0: &Text, at_p1: &Nat) -> Option<HeadLine> {
    let code_p2 = crate::syntax::lexer::chars::trim_end(&or(&index(&split_on(line_p0, &Text::lit(" #")), &Nat::from(0u32)), line_p0));
    let words_p4 = filter(&split_on(&code_p2, &Text::lit(" ")), &(|w_p3: &Text| w_p3 != &Text::lit("")));
    let first_p5 = or(&index(&words_p4, &Nat::from(0u32)), &Text::lit(""));
    let second_p6 = or(&index(&words_p4, &Nat::from(1u32)), &Text::lit(""));
    let span_p7 = crate::syntax::Range { start: at_p1.clone(), end: at_p1 + &len_text(&code_p2) };
    if (&first_p5 == &Text::lit("test")) && (&second_p6 == &Text::lit("mod")) {
        Some(HeadLine { word: Text::lit("test mod"), arg: or(&index(&words_p4, &Nat::from(2u32)), &Text::lit("")), span: span_p7.clone() })
    } else {
        if crate::check::types::has_text(&Array::from(vec![Text::lit("module"), Text::lit("emit"), Text::lit("mod"), Text::lit("use")]), &first_p5) {
            Some(HeadLine { word: first_p5.clone(), arg: or(&crate::syntax::lexer::chars::before_suffix(&second_p6, &Text::lit(".*")), &second_p6), span: span_p7.clone() })
        } else {
            None
        }
    }
}

/// ```prism
/// ?FirstDeclLine: fn Text -> ?Range
/// ```
pub fn first_decl_line(text_p0: &Text) -> Option<crate::syntax::Range> {
    let (found_o5, _) = fold(&split_on(text_p0, &Text::lit("\n")), &(None, Nat::from(0u32)), &(|(f_o1, at_p2): &(Option<crate::syntax::Range>, Nat), line_p3: &Text| {
        let next_p4 = &(at_p2 + &len_text(line_p3)) + &Nat::from(1u32);
        if ((((f_o1 != &None) || (&crate::syntax::lexer::chars::trim(line_p3) == &Text::lit(""))) || crate::syntax::lexer::chars::has_prefix(line_p3, &Text::lit("#"))) || crate::syntax::lexer::chars::has_prefix(line_p3, &Text::lit(" "))) || (&head_line_of(line_p3, at_p2) != &None) {
            (f_o1.clone(), next_p4.clone())
        } else {
            (Some(crate::syntax::Range { start: at_p2.clone(), end: at_p2 + &len_text(&crate::syntax::lexer::chars::trim_end(line_p3)) }), next_p4.clone())
        }
    }));
    found_o5.clone()
}

/// ```prism
/// let noAssembly
/// ```
pub fn no_assembly() -> Assembled {
    Assembled { units: Array::new(), prelude: Array::new(), scripts: Array::new(), errors: Array::new() }
}

/// ```prism
/// let noSpan
/// ```
pub fn no_span() -> crate::syntax::Range {
    crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) }
}

/// ```prism
/// AddTreeDiag: fn TreeAcc, Text, Range, Text, Text, Text -> TreeAcc
/// ```
pub fn add_tree_diag(acc_p0: &TreeAcc, path_p1: &Text, span_p2: &crate::syntax::Range, code_p3: &Text, message_p4: &Text, fix_p5: &Text) -> TreeAcc {
    let mut this: TreeAcc = acc_p0.clone();
    this.diags = push(&this.diags, &TreeDiag { path_: path_p1.clone(), span: span_p2.clone(), code: code_p3.clone(), message: message_p4.clone(), fix: fix_p5.clone() });
    this
}

/// ```prism
/// IsModuleDir: fn Text, [Text] -> Bool
/// ```
pub fn is_module_dir(d_p0: &Text, files_p1: &Array<Text>) -> bool {
    (crate::check::types::has_text(files_p1, &under(d_p0, &Text::lit("mod.prism"))) && !crate::check::types::has_text(files_p1, &under(d_p0, &Text::lit("app.prism")))) && !crate::check::types::has_text(files_p1, &under(d_p0, &Text::lit("lib.prism")))
}

/// ```prism
/// IsRootDir: fn Text, [Text] -> Bool
/// ```
pub fn is_root_dir(d_p0: &Text, files_p1: &Array<Text>) -> bool {
    crate::check::types::has_text(files_p1, &under(d_p0, &Text::lit("app.prism"))) || crate::check::types::has_text(files_p1, &under(d_p0, &Text::lit("lib.prism")))
}

/// ```prism
/// ?TreeRootOf: fn Text, (Text ==> [Text]) -> ?Text
/// ```
pub fn tree_root_of(d_p0: &Text, listings_p1: &Map<Text, Array<Text>>) -> Option<Text> {
    let files_p2 = or(&get(listings_p1, d_p0), &Array::new());
    if is_root_dir(d_p0, &files_p2) {
        Some(d_p0.clone())
    } else {
        if is_module_dir(d_p0, &files_p2) {
            fold(&ancestors(d_p0), &None, &(|found_o3: &Option<Text>, a_p4: &Text| if (found_o3 == &None) && is_root_dir(a_p4, &or(&get(listings_p1, a_p4), &Array::new())) {
                Some(a_p4.clone())
            } else {
                found_o3.clone()
            }))
        } else {
            None
        }
    }
}

/// ```prism
/// ToRead: fn [Text], (Text ==> [Text]) -> [Text]
/// ```
pub fn to_read(args_p0: &Array<Text>, listings_p1: &Map<Text, Array<Text>>) -> Array<Text> {
    fold(args_p0, &Array::new(), &(|acc_p2: &Array<Text>, a_p3: &Text| if is_source_path(a_p3) {
        crate::check::types::add_text(acc_p2, a_p3)
    } else {
        match tree_root_of(a_p3, listings_p1) {
            Some(root_p4) => crate::check::types::union_texts(acc_p2, &or(&get(listings_p1, &root_p4), &Array::new())),
            None => acc_p2.clone(),
        }
    }))
}

/// ```prism
/// Assemble: unbounded fn ReadInput -> Assembled
/// ```
pub fn assemble(input_p0: &ReadInput) -> Assembled {
    let listings_p1 = map(&input_p0.listings);
    let texts_p2 = map(&input_p0.texts);
    let progs_p3 = run_to_end(fold_job(input_p0.args.clone(), no_assembly(), {
        let listings_p1 = listings_p1.clone();
        let texts_p2 = texts_p2.clone();
        Rc::new(move |(p0, p1): (Assembled, Text)| {
            let listings_p1 = listings_p1.clone();
            let texts_p2 = texts_p2.clone();
            entered(once_job(move || {
                let acc_p7 = p0;
                let a_p8 = p1;
                prism_rtl::Turn::More(Rc::new(AddArg { acc_p0: acc_p7.clone(), listings_p1: listings_p1.clone(), texts_p2: texts_p2.clone(), a_p3: a_p8.clone() }))
            }))
        }) as Rc<dyn Fn((Assembled, Text)) -> Rc<dyn prism_rtl::Job<Assembled>>>
    }));
    let pre_p4 = add_arg(&no_assembly(), &listings_p1, &texts_p2, &input_p0.prelude);
    let units_p5 = filter(&each(&progs_p3.units, &(|u_p9: &ModFiles| kept_segs(u_p9, &input_p0.tests))), &(|u_pa: &ModFiles| &len(&u_pa.segs) > &Nat::from(0u32)));
    let kept_p6 = fold(&units_p5, &Array::new(), &(|acc_pb: &Array<Text>, u_pc: &ModFiles| append(acc_pb, &each(&u_pc.segs, &(|s_pd: &Seg| s_pd.path_.clone())))));
    let mut this: Assembled = progs_p3.clone();
    this.units = units_p5.clone();
    this.prelude = filter(&each(&pre_p4.units, &(|u_pe: &ModFiles| kept_segs(u_pe, &false))), &(|u_pf: &ModFiles| &len(&u_pf.segs) > &Nat::from(0u32)));
    this.scripts = filter(&this.scripts, &(|p_pg: &Text| crate::check::types::has_text(&kept_p6, p_pg)));
    this.errors = append(&this.errors, &pre_p4.errors);
    this
}

/// The step machine of `Assemble`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Assemble: unbounded fn ReadInput -> Assembled
/// ```
pub struct Assemble {
    pub input_p0: ReadInput,
}

impl prism_rtl::Job<Assembled> for Assemble {
    fn cycle(&self) -> prism_rtl::Turn<Assembled> {
        let input_p0 = &self.input_p0;
        let listings_p1 = map(&input_p0.listings);
        let texts_p2 = map(&input_p0.texts);
        let input_p0 = input_p0.clone();
        call_value(fold_job(input_p0.args.clone(), no_assembly(), {
            let listings_p1 = listings_p1.clone();
            let texts_p2 = texts_p2.clone();
            Rc::new(move |(p0, p1): (Assembled, Text)| {
                let listings_p1 = listings_p1.clone();
                let texts_p2 = texts_p2.clone();
                entered(once_job(move || {
                    let acc_p7 = p0;
                    let a_p8 = p1;
                    prism_rtl::Turn::More(Rc::new(AddArg { acc_p0: acc_p7.clone(), listings_p1: listings_p1.clone(), texts_p2: texts_p2.clone(), a_p3: a_p8.clone() }))
                }))
            }) as Rc<dyn Fn((Assembled, Text)) -> Rc<dyn prism_rtl::Job<Assembled>>>
        }), move |fold_12106: Assembled| {
            let progs_p3 = fold_12106;
            call_then(start_add_arg(no_assembly(), listings_p1.clone(), texts_p2.clone(), input_p0.prelude.clone()), move |add_arg_12190: Assembled| {
                let pre_p4 = add_arg_12190;
                let units_p5 = filter(&each(&progs_p3.units, &(|u_p9: &ModFiles| kept_segs(u_p9, &input_p0.tests))), &(|u_pa: &ModFiles| &len(&u_pa.segs) > &Nat::from(0u32)));
                let kept_p6 = fold(&units_p5, &Array::new(), &(|acc_pb: &Array<Text>, u_pc: &ModFiles| append(acc_pb, &each(&u_pc.segs, &(|s_pd: &Seg| s_pd.path_.clone())))));
                prism_rtl::Turn::Finished({
                    let mut this: Assembled = progs_p3.clone();
                    this.units = units_p5.clone();
                    this.prelude = filter(&each(&pre_p4.units, &(|u_pe: &ModFiles| kept_segs(u_pe, &false))), &(|u_pf: &ModFiles| &len(&u_pf.segs) > &Nat::from(0u32)));
                    this.scripts = filter(&this.scripts, &(|p_pg: &Text| crate::check::types::has_text(&kept_p6, p_pg)));
                    this.errors = append(&this.errors, &pre_p4.errors);
                    this
                })
            })
        })
    }
}

/// `Start Assemble, x`: what the function value is when passed to `@Run`.
pub fn start_assemble(input_p0: ReadInput) -> Rc<dyn prism_rtl::Job<Assembled>> {
    Rc::new(Assemble { input_p0 })
}

/// ```prism
/// KeptSegs: fn ModFiles, Bool -> ModFiles
/// ```
pub fn kept_segs(u_p0: &ModFiles, tests_p1: &bool) -> ModFiles {
    let mut this: ModFiles = u_p0.clone();
    this.segs = filter(&this.segs, &(|s_p2: &Seg| (&s_p2.role != &Text::lit("test")) || *tests_p1));
    this
}

/// ```prism
/// AddArg: unbounded fn Assembled, (Text ==> [Text]), (Text ==> Text), Text -> Assembled
/// ```
pub fn add_arg(acc_p0: &Assembled, listings_p1: &Map<Text, Array<Text>>, texts_p2: &Map<Text, Text>, a_p3: &Text) -> Assembled {
    if crate::syntax::lexer::chars::has_suffix(a_p3, &Text::lit(".prismtest")) {
        {
            let mut this: Assembled = acc_p0.clone();
            this.errors = push(&this.errors, &TreeDiag { path_: a_p3.clone(), span: no_span(), code: Text::lit("prismtest"), message: Text::from(format!("`{}`: a `.prismtest` is not read: a module\'s tests are in its test modules, a loose file\'s inline", a_p3)), fix: Text::lit("move its declarations into a test module (`test mod tests`), or into the file it tests") });
            this
        }
    } else {
        if crate::syntax::lexer::chars::has_suffix(a_p3, &Text::lit(".prism")) {
            {
                let mut this: Assembled = acc_p0.clone();
                this.units = push(&this.units, &ModFiles { name: Text::lit(""), named: false, segs: Array::from(vec![Seg { path_: a_p3.clone(), text: or(&get(texts_p2, a_p3), &Text::lit("")), role: Text::lit("loose") }]), parent: Text::lit("") });
                this
            }
        } else {
            match tree_root_of(a_p3, listings_p1) {
                Some(root_p4) => {
                    let tree_p5 = walk_tree(&root_p4, &or(&get(listings_p1, &root_p4), &Array::new()), texts_p2);
                    let start_p6 = under(a_p3, &Text::lit("mod.prism"));
                    let units_p7 = if &root_p4 == a_p3 {
                        tree_p5.units.clone()
                    } else {
                        reach_tree(&tree_p5.units, &start_p6)
                    };
                    let scripts_p8 = if &root_p4 == a_p3 {
                        fold(&units_p7, &Array::new(), &(|s_p9: &Array<Text>, u_pa: &ModFiles| append(s_p9, &test_paths(u_pa))))
                    } else {
                        fold(&filter(&units_p7, &(|u_pb: &ModFiles| (&main_path(u_pb) == &start_p6) || (&u_pb.parent == &start_p6))), &Array::new(), &(|s_pc: &Array<Text>, u_pd: &ModFiles| append(s_pc, &test_paths(u_pd))))
                    };
                    {
                        let mut this: Assembled = acc_p0.clone();
                        this.units = append(&this.units, &units_p7);
                        this.scripts = append(&this.scripts, &scripts_p8);
                        this.errors = append(&this.errors, &tree_p5.diags);
                        this
                    }
                },
                None => {
                    let mut this: Assembled = acc_p0.clone();
                    this.errors = push(&this.errors, &TreeDiag { path_: a_p3.clone(), span: no_span(), code: Text::lit("no-root"), message: Text::from(format!("`{}` holds no app.prism, lib.prism or mod.prism, and a directory argument is a tree", a_p3)), fix: Text::lit("give it a root, or name its files") });
                    this
                },
            }
        }
    }
}

/// The step machine of `AddArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AddArg: unbounded fn Assembled, (Text ==> [Text]), (Text ==> Text), Text -> Assembled
/// ```
pub struct AddArg {
    pub acc_p0: Assembled,
    pub listings_p1: Map<Text, Array<Text>>,
    pub texts_p2: Map<Text, Text>,
    pub a_p3: Text,
}

impl prism_rtl::Job<Assembled> for AddArg {
    fn cycle(&self) -> prism_rtl::Turn<Assembled> {
        let acc_p0 = &self.acc_p0;
        let listings_p1 = &self.listings_p1;
        let texts_p2 = &self.texts_p2;
        let a_p3 = &self.a_p3;
        if crate::syntax::lexer::chars::has_suffix(a_p3, &Text::lit(".prismtest")) {
            prism_rtl::Turn::Finished({
                let mut this: Assembled = acc_p0.clone();
                this.errors = push(&this.errors, &TreeDiag { path_: a_p3.clone(), span: no_span(), code: Text::lit("prismtest"), message: Text::from(format!("`{}`: a `.prismtest` is not read: a module\'s tests are in its test modules, a loose file\'s inline", a_p3)), fix: Text::lit("move its declarations into a test module (`test mod tests`), or into the file it tests") });
                this
            })
        } else {
            if crate::syntax::lexer::chars::has_suffix(a_p3, &Text::lit(".prism")) {
                prism_rtl::Turn::Finished({
                    let mut this: Assembled = acc_p0.clone();
                    this.units = push(&this.units, &ModFiles { name: Text::lit(""), named: false, segs: Array::from(vec![Seg { path_: a_p3.clone(), text: or(&get(texts_p2, a_p3), &Text::lit("")), role: Text::lit("loose") }]), parent: Text::lit("") });
                    this
                })
            } else {
                match tree_root_of(a_p3, listings_p1) {
                    Some(root_p4) => {
                        let a_p3 = a_p3.clone();
                        let acc_p0 = acc_p0.clone();
                        let listings_p1 = listings_p1.clone();
                        let texts_p2 = texts_p2.clone();
                        call_then(start_walk_tree(root_p4.clone(), or(&get(&listings_p1, &root_p4), &Array::new()), texts_p2.clone()), move |walk_tree_13644: TreeAcc| {
                            let tree_p5 = walk_tree_13644;
                            let start_p6 = under(&a_p3, &Text::lit("mod.prism"));
                            let units_p7 = if &root_p4 == &a_p3 {
                                tree_p5.units.clone()
                            } else {
                                reach_tree(&tree_p5.units, &start_p6)
                            };
                            let scripts_p8 = if &root_p4 == &a_p3 {
                                fold(&units_p7, &Array::new(), &(|s_p9: &Array<Text>, u_pa: &ModFiles| append(s_p9, &test_paths(u_pa))))
                            } else {
                                fold(&filter(&units_p7, &(|u_pb: &ModFiles| (&main_path(u_pb) == &start_p6) || (&u_pb.parent == &start_p6))), &Array::new(), &(|s_pc: &Array<Text>, u_pd: &ModFiles| append(s_pc, &test_paths(u_pd))))
                            };
                            prism_rtl::Turn::Finished({
                                let mut this: Assembled = acc_p0.clone();
                                this.units = append(&this.units, &units_p7);
                                this.scripts = append(&this.scripts, &scripts_p8);
                                this.errors = append(&this.errors, &tree_p5.diags);
                                this
                            })
                        })
                    },
                    None => prism_rtl::Turn::Finished({
                        let mut this: Assembled = acc_p0.clone();
                        this.errors = push(&this.errors, &TreeDiag { path_: a_p3.clone(), span: no_span(), code: Text::lit("no-root"), message: Text::from(format!("`{}` holds no app.prism, lib.prism or mod.prism, and a directory argument is a tree", a_p3)), fix: Text::lit("give it a root, or name its files") });
                        this
                    }),
                }
            }
        }
    }
}

/// `Start AddArg, x`: what the function value is when passed to `@Run`.
pub fn start_add_arg(acc_p0: Assembled, listings_p1: Map<Text, Array<Text>>, texts_p2: Map<Text, Text>, a_p3: Text) -> Rc<dyn prism_rtl::Job<Assembled>> {
    Rc::new(AddArg { acc_p0, listings_p1, texts_p2, a_p3 })
}

/// ```prism
/// MainPath: fn ModFiles -> Text
/// ```
pub fn main_path(u_p0: &ModFiles) -> Text {
    match index(&u_p0.segs, &Nat::from(0u32)) {
        Some(s_p1) => s_p1.path_.clone(),
        None => Text::lit(""),
    }
}

/// ```prism
/// MainText: fn ModFiles -> Text
/// ```
pub fn main_text(u_p0: &ModFiles) -> Text {
    match index(&u_p0.segs, &Nat::from(0u32)) {
        Some(s_p1) => s_p1.text.clone(),
        None => Text::lit(""),
    }
}

/// ```prism
/// TestPaths: fn ModFiles -> [Text]
/// ```
pub fn test_paths(u_p0: &ModFiles) -> Array<Text> {
    each(&filter(&u_p0.segs, &(|s_p1: &Seg| &s_p1.role == &Text::lit("test"))), &(|s_p2: &Seg| s_p2.path_.clone()))
}

/// ```prism
/// WalkTree: unbounded fn Text, [Text], (Text ==> Text) -> TreeAcc
/// ```
pub fn walk_tree(root_p0: &Text, files_p1: &Array<Text>, texts_p2: &Map<Text, Text>) -> TreeAcc {
    let has_p3 = fold(files_p1, &Map::new(), &(|m_pa: &Map<Text, bool>, f_pb: &Text| insert(m_pa, f_pb, &true)));
    let app_p4 = under(root_p0, &Text::lit("app.prism"));
    let lib_p5 = under(root_p0, &Text::lit("lib.prism"));
    let acc0_p6 = TreeAcc { units: Array::new(), declared: Map::new(), diags: Array::new() };
    let acc1_p7 = if crate::check::env::has_key(&has_p3, &app_p4) && crate::check::env::has_key(&has_p3, &lib_p5) {
        add_tree_diag(&acc0_p6, &lib_p5, &no_span(), &Text::lit("two-roots"), &Text::lit("`app.prism` and `lib.prism` in one directory: a tree has one root"), &Text::lit("keep app.prism for a program or lib.prism for a library"))
    } else {
        acc0_p6.clone()
    };
    let acc2_p8 = if crate::check::env::has_key(&has_p3, &app_p4) {
        walk_module(&has_p3, texts_p2, &acc1_p7, &app_p4, &Text::lit(""), &Text::lit(""), &false)
    } else {
        walk_lib(&has_p3, texts_p2, &acc1_p7, &lib_p5)
    };
    let acc3_p9 = {
        let mut this: TreeAcc = acc2_p8.clone();
        this.declared = insert(&this.declared, &lib_p5, &true);
        this
    };
    fold(files_p1, &acc3_p9, &(|a_pc: &TreeAcc, f_pd: &Text| if crate::check::env::has_key(&a_pc.declared, f_pd) {
        a_pc.clone()
    } else {
        stray(&has_p3, texts_p2, a_pc, f_pd)
    }))
}

/// The step machine of `WalkTree`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WalkTree: unbounded fn Text, [Text], (Text ==> Text) -> TreeAcc
/// ```
pub struct WalkTree {
    pub root_p0: Text,
    pub files_p1: Array<Text>,
    pub texts_p2: Map<Text, Text>,
}

impl prism_rtl::Job<TreeAcc> for WalkTree {
    fn cycle(&self) -> prism_rtl::Turn<TreeAcc> {
        let root_p0 = &self.root_p0;
        let files_p1 = &self.files_p1;
        let texts_p2 = &self.texts_p2;
        let has_p3 = fold(files_p1, &Map::new(), &(|m_pa: &Map<Text, bool>, f_pb: &Text| insert(m_pa, f_pb, &true)));
        let app_p4 = under(root_p0, &Text::lit("app.prism"));
        let lib_p5 = under(root_p0, &Text::lit("lib.prism"));
        let acc0_p6 = TreeAcc { units: Array::new(), declared: Map::new(), diags: Array::new() };
        let acc1_p7 = if crate::check::env::has_key(&has_p3, &app_p4) && crate::check::env::has_key(&has_p3, &lib_p5) {
            add_tree_diag(&acc0_p6, &lib_p5, &no_span(), &Text::lit("two-roots"), &Text::lit("`app.prism` and `lib.prism` in one directory: a tree has one root"), &Text::lit("keep app.prism for a program or lib.prism for a library"))
        } else {
            acc0_p6.clone()
        };
        let acc2_p8 = if crate::check::env::has_key(&has_p3, &app_p4) {
            walk_module(&has_p3, texts_p2, &acc1_p7, &app_p4, &Text::lit(""), &Text::lit(""), &false)
        } else {
            walk_lib(&has_p3, texts_p2, &acc1_p7, &lib_p5)
        };
        let acc3_p9 = {
            let mut this: TreeAcc = acc2_p8.clone();
            this.declared = insert(&this.declared, &lib_p5, &true);
            this
        };
        prism_rtl::Turn::Finished(fold(files_p1, &acc3_p9, &(|a_pc: &TreeAcc, f_pd: &Text| if crate::check::env::has_key(&a_pc.declared, f_pd) {
            a_pc.clone()
        } else {
            stray(&has_p3, texts_p2, a_pc, f_pd)
        })))
    }
}

/// `Start WalkTree, x`: what the function value is when passed to `@Run`.
pub fn start_walk_tree(root_p0: Text, files_p1: Array<Text>, texts_p2: Map<Text, Text>) -> Rc<dyn prism_rtl::Job<TreeAcc>> {
    Rc::new(WalkTree { root_p0, files_p1, texts_p2 })
}

/// ```prism
/// WalkLib: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text -> TreeAcc
/// ```
pub fn walk_lib(has_p0: &Map<Text, bool>, texts_p1: &Map<Text, Text>, acc_p2: &TreeAcc, lib_p3: &Text) -> TreeAcc {
    let text_p4 = or(&get(texts_p1, lib_p3), &Text::lit(""));
    let heads_p5 = header_lines(&text_p4);
    let bad_p6 = filter(&heads_p5, &(|h_pa: &HeadLine| !((&h_pa.word == &Text::lit("mod")) && crate::check::env::is_upper_text(&h_pa.arg))));
    let acc1_p7 = fold(&bad_p6, acc_p2, &(|a_pb: &TreeAcc, h_pc: &HeadLine| add_tree_diag(a_pb, lib_p3, &h_pc.span, &Text::lit("lib-header"), &Text::from(format!("lib.prism holds only `mod Name` lines, the library\'s modules: `{}` belongs in a module", &h_pc.word)), &Text::lit("move the line to a module\'s mod.prism"))));
    let acc2_p8 = match first_decl_line(&text_p4) {
        Some(r_pd) => add_tree_diag(&acc1_p7, lib_p3, &r_pd, &Text::lit("lib-header"), &Text::lit("lib.prism holds only `mod Name` lines, the library\'s modules"), &Text::lit("move the declaration to a module")),
        None => acc1_p7.clone(),
    };
    let dir_p9 = dir_of(lib_p3);
    run_to_end(fold_job(filter(&heads_p5, &(|h_pe: &HeadLine| (&h_pe.word == &Text::lit("mod")) && crate::check::env::is_upper_text(&h_pe.arg))), acc2_p8.clone(), {
        let has_p0 = has_p0.clone();
        let texts_p1 = texts_p1.clone();
        let lib_p3 = lib_p3.clone();
        let dir_p9 = dir_p9.clone();
        Rc::new(move |(p0, p1): (TreeAcc, HeadLine)| {
            let has_p0 = has_p0.clone();
            let texts_p1 = texts_p1.clone();
            let lib_p3 = lib_p3.clone();
            let dir_p9 = dir_p9.clone();
            entered(once_job(move || {
                let a_pf = p0;
                let h_pg = p1;
                prism_rtl::Turn::More(Rc::new(Child { has_p0: has_p0.clone(), texts_p1: texts_p1.clone(), acc_p2: a_pf.clone(), main_p3: lib_p3.clone(), dir_p4: dir_p9.clone(), h_p5: h_pg.clone(), parent_p6: Text::lit(""), in_test_p7: false }))
            }))
        }) as Rc<dyn Fn((TreeAcc, HeadLine)) -> Rc<dyn prism_rtl::Job<TreeAcc>>>
    }))
}

/// The step machine of `WalkLib`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WalkLib: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text -> TreeAcc
/// ```
pub struct WalkLib {
    pub has_p0: Map<Text, bool>,
    pub texts_p1: Map<Text, Text>,
    pub acc_p2: TreeAcc,
    pub lib_p3: Text,
}

impl prism_rtl::Job<TreeAcc> for WalkLib {
    fn cycle(&self) -> prism_rtl::Turn<TreeAcc> {
        let has_p0 = &self.has_p0;
        let texts_p1 = &self.texts_p1;
        let acc_p2 = &self.acc_p2;
        let lib_p3 = &self.lib_p3;
        let text_p4 = or(&get(texts_p1, lib_p3), &Text::lit(""));
        let heads_p5 = header_lines(&text_p4);
        let bad_p6 = filter(&heads_p5, &(|h_pa: &HeadLine| !((&h_pa.word == &Text::lit("mod")) && crate::check::env::is_upper_text(&h_pa.arg))));
        let acc1_p7 = fold(&bad_p6, acc_p2, &(|a_pb: &TreeAcc, h_pc: &HeadLine| add_tree_diag(a_pb, lib_p3, &h_pc.span, &Text::lit("lib-header"), &Text::from(format!("lib.prism holds only `mod Name` lines, the library\'s modules: `{}` belongs in a module", &h_pc.word)), &Text::lit("move the line to a module\'s mod.prism"))));
        let acc2_p8 = match first_decl_line(&text_p4) {
            Some(r_pd) => add_tree_diag(&acc1_p7, lib_p3, &r_pd, &Text::lit("lib-header"), &Text::lit("lib.prism holds only `mod Name` lines, the library\'s modules"), &Text::lit("move the declaration to a module")),
            None => acc1_p7.clone(),
        };
        let dir_p9 = dir_of(lib_p3);
        fold_job(filter(&heads_p5, &(|h_pe: &HeadLine| (&h_pe.word == &Text::lit("mod")) && crate::check::env::is_upper_text(&h_pe.arg))), acc2_p8.clone(), {
            let has_p0 = has_p0.clone();
            let texts_p1 = texts_p1.clone();
            let lib_p3 = lib_p3.clone();
            let dir_p9 = dir_p9.clone();
            Rc::new(move |(p0, p1): (TreeAcc, HeadLine)| {
                let has_p0 = has_p0.clone();
                let texts_p1 = texts_p1.clone();
                let lib_p3 = lib_p3.clone();
                let dir_p9 = dir_p9.clone();
                entered(once_job(move || {
                    let a_pf = p0;
                    let h_pg = p1;
                    prism_rtl::Turn::More(Rc::new(Child { has_p0: has_p0.clone(), texts_p1: texts_p1.clone(), acc_p2: a_pf.clone(), main_p3: lib_p3.clone(), dir_p4: dir_p9.clone(), h_p5: h_pg.clone(), parent_p6: Text::lit(""), in_test_p7: false }))
                }))
            }) as Rc<dyn Fn((TreeAcc, HeadLine)) -> Rc<dyn prism_rtl::Job<TreeAcc>>>
        }).cycle()
    }
}

/// `Start WalkLib, x`: what the function value is when passed to `@Run`.
pub fn start_walk_lib(has_p0: Map<Text, bool>, texts_p1: Map<Text, Text>, acc_p2: TreeAcc, lib_p3: Text) -> Rc<dyn prism_rtl::Job<TreeAcc>> {
    Rc::new(WalkLib { has_p0, texts_p1, acc_p2, lib_p3 })
}

/// ```prism
/// WalkModule: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text, Text, Bool -> TreeAcc
/// ```
pub fn walk_module(has_p0: &Map<Text, bool>, texts_p1: &Map<Text, Text>, acc_p2: &TreeAcc, main_p3: &Text, name_p4: &Text, parent_p5: &Text, in_test_p6: &bool) -> TreeAcc {
    let dir_p7 = dir_of(main_p3);
    let text_p8 = or(&get(texts_p1, main_p3), &Text::lit(""));
    let heads_p9 = header_lines(&text_p8);
    let mods_pa = filter(&heads_p9, &(|h_pk: &HeadLine| (&h_pk.word == &Text::lit("mod")) || (&h_pk.word == &Text::lit("test mod"))));
    let subs_pb = filter(&mods_pa, &(|h_pl: &HeadLine| crate::check::env::is_upper_text(&h_pl.arg)));
    let lower_pc = filter(&mods_pa, &(|h_pm: &HeadLine| !crate::check::env::is_upper_text(&h_pm.arg)));
    let named_pd = if name_p4 == &Text::lit("") {
        Text::lit("its path makes it the root")
    } else {
        Text::from(format!("its path names the module `{}`", name_p4))
    };
    let acc1_pe = fold(&filter(&heads_p9, &(|h_pn: &HeadLine| &h_pn.word == &Text::lit("module"))), acc_p2, &(|a_po: &TreeAcc, h_pp: &HeadLine| add_tree_diag(a_po, main_p3, &h_pp.span, &Text::lit("module-line"), &Text::from(format!("a module\'s file has no `module` line: {}", &named_pd)), &Text::lit("delete the line"))));
    let leaf_pf = !crate::check::types::has_text(&Array::from(vec![Text::lit("mod.prism"), Text::lit("app.prism"), Text::lit("lib.prism")]), &base_of(main_p3));
    let stem_pg = or(&crate::syntax::lexer::chars::before_suffix(&base_of(main_p3), &Text::lit(".prism")), main_p3);
    let acc2_ph = if leaf_pf {
        fold(&mods_pa, &acc1_pe, &(|a_pq: &TreeAcc, h_pr: &HeadLine| add_tree_diag(a_pq, main_p3, &h_pr.span, &Text::lit("mod-leaf"), &Text::from(format!("`{}` declares `{} {}`, and a module with children is a directory", &base_of(main_p3), &h_pr.word, &h_pr.arg)), &Text::from(format!("move {} to {}/mod.prism", &base_of(main_p3), &stem_pg)))))
    } else {
        acc1_pe.clone()
    };
    let acc3_pi = fold(&lower_pc, &acc2_ph, &(|a_ps: &TreeAcc, h_pt: &HeadLine| lowercase(a_ps, main_p3, &dir_p7, h_pt)));
    let acc4_pj = {
        let mut this: TreeAcc = acc3_pi.clone();
        this.declared = insert(&this.declared, main_p3, &true);
        this.units = push(&this.units, &ModFiles { name: name_p4.clone(), named: true, segs: Array::from(vec![Seg { path_: main_p3.clone(), text: text_p8.clone(), role: if *in_test_p6 { Text::lit("test") } else { Text::lit("main") } }]), parent: parent_p5.clone() });
        this
    };
    if leaf_pf {
        acc4_pj.clone()
    } else {
        run_to_end(fold_job(subs_pb.clone(), acc4_pj.clone(), {
            let has_p0 = has_p0.clone();
            let texts_p1 = texts_p1.clone();
            let main_p3 = main_p3.clone();
            let dir_p7 = dir_p7.clone();
            let name_p4 = name_p4.clone();
            let in_test_p6 = *in_test_p6;
            Rc::new(move |(p0, p1): (TreeAcc, HeadLine)| {
                let has_p0 = has_p0.clone();
                let texts_p1 = texts_p1.clone();
                let main_p3 = main_p3.clone();
                let dir_p7 = dir_p7.clone();
                let name_p4 = name_p4.clone();
                let in_test_p6 = in_test_p6;
                entered(once_job(move || {
                    let a_pu = p0;
                    let h_pv = p1;
                    prism_rtl::Turn::More(Rc::new(Child { has_p0: has_p0.clone(), texts_p1: texts_p1.clone(), acc_p2: a_pu.clone(), main_p3: main_p3.clone(), dir_p4: dir_p7.clone(), h_p5: h_pv.clone(), parent_p6: name_p4.clone(), in_test_p7: in_test_p6 }))
                }))
            }) as Rc<dyn Fn((TreeAcc, HeadLine)) -> Rc<dyn prism_rtl::Job<TreeAcc>>>
        }))
    }
}

/// The step machine of `WalkModule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WalkModule: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text, Text, Bool -> TreeAcc
/// ```
pub struct WalkModule {
    pub has_p0: Map<Text, bool>,
    pub texts_p1: Map<Text, Text>,
    pub acc_p2: TreeAcc,
    pub main_p3: Text,
    pub name_p4: Text,
    pub parent_p5: Text,
    pub in_test_p6: bool,
}

impl prism_rtl::Job<TreeAcc> for WalkModule {
    fn cycle(&self) -> prism_rtl::Turn<TreeAcc> {
        let has_p0 = &self.has_p0;
        let texts_p1 = &self.texts_p1;
        let acc_p2 = &self.acc_p2;
        let main_p3 = &self.main_p3;
        let name_p4 = &self.name_p4;
        let parent_p5 = &self.parent_p5;
        let in_test_p6 = &self.in_test_p6;
        let dir_p7 = dir_of(main_p3);
        let text_p8 = or(&get(texts_p1, main_p3), &Text::lit(""));
        let heads_p9 = header_lines(&text_p8);
        let mods_pa = filter(&heads_p9, &(|h_pk: &HeadLine| (&h_pk.word == &Text::lit("mod")) || (&h_pk.word == &Text::lit("test mod"))));
        let subs_pb = filter(&mods_pa, &(|h_pl: &HeadLine| crate::check::env::is_upper_text(&h_pl.arg)));
        let lower_pc = filter(&mods_pa, &(|h_pm: &HeadLine| !crate::check::env::is_upper_text(&h_pm.arg)));
        let named_pd = if name_p4 == &Text::lit("") {
            Text::lit("its path makes it the root")
        } else {
            Text::from(format!("its path names the module `{}`", name_p4))
        };
        let acc1_pe = fold(&filter(&heads_p9, &(|h_pn: &HeadLine| &h_pn.word == &Text::lit("module"))), acc_p2, &(|a_po: &TreeAcc, h_pp: &HeadLine| add_tree_diag(a_po, main_p3, &h_pp.span, &Text::lit("module-line"), &Text::from(format!("a module\'s file has no `module` line: {}", &named_pd)), &Text::lit("delete the line"))));
        let leaf_pf = !crate::check::types::has_text(&Array::from(vec![Text::lit("mod.prism"), Text::lit("app.prism"), Text::lit("lib.prism")]), &base_of(main_p3));
        let stem_pg = or(&crate::syntax::lexer::chars::before_suffix(&base_of(main_p3), &Text::lit(".prism")), main_p3);
        let acc2_ph = if leaf_pf {
            fold(&mods_pa, &acc1_pe, &(|a_pq: &TreeAcc, h_pr: &HeadLine| add_tree_diag(a_pq, main_p3, &h_pr.span, &Text::lit("mod-leaf"), &Text::from(format!("`{}` declares `{} {}`, and a module with children is a directory", &base_of(main_p3), &h_pr.word, &h_pr.arg)), &Text::from(format!("move {} to {}/mod.prism", &base_of(main_p3), &stem_pg)))))
        } else {
            acc1_pe.clone()
        };
        let acc3_pi = fold(&lower_pc, &acc2_ph, &(|a_ps: &TreeAcc, h_pt: &HeadLine| lowercase(a_ps, main_p3, &dir_p7, h_pt)));
        let acc4_pj = {
            let mut this: TreeAcc = acc3_pi.clone();
            this.declared = insert(&this.declared, main_p3, &true);
            this.units = push(&this.units, &ModFiles { name: name_p4.clone(), named: true, segs: Array::from(vec![Seg { path_: main_p3.clone(), text: text_p8.clone(), role: if *in_test_p6 { Text::lit("test") } else { Text::lit("main") } }]), parent: parent_p5.clone() });
            this
        };
        if leaf_pf {
            prism_rtl::Turn::Finished(acc4_pj.clone())
        } else {
            fold_job(subs_pb.clone(), acc4_pj.clone(), {
                let has_p0 = has_p0.clone();
                let texts_p1 = texts_p1.clone();
                let main_p3 = main_p3.clone();
                let dir_p7 = dir_p7.clone();
                let name_p4 = name_p4.clone();
                let in_test_p6 = *in_test_p6;
                Rc::new(move |(p0, p1): (TreeAcc, HeadLine)| {
                    let has_p0 = has_p0.clone();
                    let texts_p1 = texts_p1.clone();
                    let main_p3 = main_p3.clone();
                    let dir_p7 = dir_p7.clone();
                    let name_p4 = name_p4.clone();
                    let in_test_p6 = in_test_p6;
                    entered(once_job(move || {
                        let a_pu = p0;
                        let h_pv = p1;
                        prism_rtl::Turn::More(Rc::new(Child { has_p0: has_p0.clone(), texts_p1: texts_p1.clone(), acc_p2: a_pu.clone(), main_p3: main_p3.clone(), dir_p4: dir_p7.clone(), h_p5: h_pv.clone(), parent_p6: name_p4.clone(), in_test_p7: in_test_p6 }))
                    }))
                }) as Rc<dyn Fn((TreeAcc, HeadLine)) -> Rc<dyn prism_rtl::Job<TreeAcc>>>
            }).cycle()
        }
    }
}

/// `Start WalkModule, x`: what the function value is when passed to `@Run`.
pub fn start_walk_module(has_p0: Map<Text, bool>, texts_p1: Map<Text, Text>, acc_p2: TreeAcc, main_p3: Text, name_p4: Text, parent_p5: Text, in_test_p6: bool) -> Rc<dyn prism_rtl::Job<TreeAcc>> {
    Rc::new(WalkModule { has_p0, texts_p1, acc_p2, main_p3, name_p4, parent_p5, in_test_p6 })
}

/// ```prism
/// Lowercase: fn TreeAcc, Text, Text, HeadLine -> TreeAcc
/// ```
pub fn lowercase(a_p0: &TreeAcc, main_p1: &Text, dir_p2: &Text, h_p3: &HeadLine) -> TreeAcc {
    let up_p4 = Text::from(format!("{}{}", &upper(&crate::syntax::lexer::chars::head(&h_p3.arg)), &crate::syntax::lexer::chars::after_first(&h_p3.arg)));
    let marked_p5 = {
        let mut this: TreeAcc = a_p0.clone();
        this.declared = insert(&this.declared, &under(dir_p2, &Text::from(format!("{}.prism", &h_p3.arg))), &true);
        this
    };
    add_tree_diag(&marked_p5, main_p1, &h_p3.span, &Text::lit("mod-lowercase"), &Text::from(format!("`{} {}`: a module\'s name is capitalised, and every `mod` line declares a module with a namespace of its own", &h_p3.word, &h_p3.arg)), &Text::from(format!("write `{} {}` (its file {}.prism, with a header of its own)", &h_p3.word, &up_p4, &h_p3.arg)))
}

/// ```prism
/// Child: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text, HeadLine, Text, Bool -> TreeAcc
/// ```
pub fn child(has_p0: &Map<Text, bool>, texts_p1: &Map<Text, Text>, acc_p2: &TreeAcc, main_p3: &Text, dir_p4: &Text, h_p5: &HeadLine, parent_p6: &Text, in_test_p7: &bool) -> TreeAcc {
    let snake_p8 = dir_name(&h_p5.arg);
    let file_p9 = under(dir_p4, &Text::from(format!("{}.prism", &snake_p8)));
    let nested_pa = under(dir_p4, &Text::from(format!("{}/mod.prism", &snake_p8)));
    let name_pb = if parent_p6 == &Text::lit("") {
        h_p5.arg.clone()
    } else {
        Text::from(format!("{}.{}", parent_p6, &h_p5.arg))
    };
    let is_test_pc = *in_test_p7 || (&h_p5.word == &Text::lit("test mod"));
    let line_pd = Text::from(format!("{} {}", &h_p5.word, &h_p5.arg));
    if (&file_p9 == main_p3) || (&nested_pa == main_p3) {
        add_tree_diag(acc_p2, main_p3, &h_p5.span, &Text::lit("mod-self"), &Text::from(format!("`{}` names `{}`, the file that declares it", &line_pd, &base_of(main_p3))), &Text::lit("rename the module"))
    } else {
        if crate::check::env::has_key(has_p0, &file_p9) && crate::check::env::has_key(has_p0, &nested_pa) {
            {
                let both_pe = {
                    let mut this: TreeAcc = acc_p2.clone();
                    this.declared = insert(&insert(&this.declared, &file_p9, &true), &nested_pa, &true);
                    this
                };
                add_tree_diag(&both_pe, main_p3, &h_p5.span, &Text::lit("mod-both"), &Text::from(format!("`{}` declares `{}.prism` or `{}/mod.prism`, and both are there", &line_pd, &snake_p8, &snake_p8)), &Text::from(format!("keep one: {}/mod.prism when the module has children, else {}.prism", &snake_p8, &snake_p8)))
            }
        } else {
            if crate::check::env::has_key(has_p0, &file_p9) {
                walk_module(has_p0, texts_p1, acc_p2, &file_p9, &name_pb, main_p3, &is_test_pc)
            } else {
                if crate::check::env::has_key(has_p0, &nested_pa) {
                    walk_module(has_p0, texts_p1, acc_p2, &nested_pa, &name_pb, main_p3, &is_test_pc)
                } else {
                    add_tree_diag(acc_p2, main_p3, &h_p5.span, &Text::lit("mod-missing"), &Text::from(format!("`{}` declares `{}.prism` or `{}/mod.prism`, and neither is there", &line_pd, &snake_p8, &snake_p8)), &Text::from(format!("create {}.prism, or delete the line", &snake_p8)))
                }
            }
        }
    }
}

/// The step machine of `Child`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Child: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text, HeadLine, Text, Bool -> TreeAcc
/// ```
pub struct Child {
    pub has_p0: Map<Text, bool>,
    pub texts_p1: Map<Text, Text>,
    pub acc_p2: TreeAcc,
    pub main_p3: Text,
    pub dir_p4: Text,
    pub h_p5: HeadLine,
    pub parent_p6: Text,
    pub in_test_p7: bool,
}

impl prism_rtl::Job<TreeAcc> for Child {
    fn cycle(&self) -> prism_rtl::Turn<TreeAcc> {
        let has_p0 = &self.has_p0;
        let texts_p1 = &self.texts_p1;
        let acc_p2 = &self.acc_p2;
        let main_p3 = &self.main_p3;
        let dir_p4 = &self.dir_p4;
        let h_p5 = &self.h_p5;
        let parent_p6 = &self.parent_p6;
        let in_test_p7 = &self.in_test_p7;
        let snake_p8 = dir_name(&h_p5.arg);
        let file_p9 = under(dir_p4, &Text::from(format!("{}.prism", &snake_p8)));
        let nested_pa = under(dir_p4, &Text::from(format!("{}/mod.prism", &snake_p8)));
        let name_pb = if parent_p6 == &Text::lit("") {
            h_p5.arg.clone()
        } else {
            Text::from(format!("{}.{}", parent_p6, &h_p5.arg))
        };
        let is_test_pc = *in_test_p7 || (&h_p5.word == &Text::lit("test mod"));
        let line_pd = Text::from(format!("{} {}", &h_p5.word, &h_p5.arg));
        if (&file_p9 == main_p3) || (&nested_pa == main_p3) {
            prism_rtl::Turn::Finished(add_tree_diag(acc_p2, main_p3, &h_p5.span, &Text::lit("mod-self"), &Text::from(format!("`{}` names `{}`, the file that declares it", &line_pd, &base_of(main_p3))), &Text::lit("rename the module")))
        } else {
            if crate::check::env::has_key(has_p0, &file_p9) && crate::check::env::has_key(has_p0, &nested_pa) {
                {
                    let both_pe = {
                        let mut this: TreeAcc = acc_p2.clone();
                        this.declared = insert(&insert(&this.declared, &file_p9, &true), &nested_pa, &true);
                        this
                    };
                    prism_rtl::Turn::Finished(add_tree_diag(&both_pe, main_p3, &h_p5.span, &Text::lit("mod-both"), &Text::from(format!("`{}` declares `{}.prism` or `{}/mod.prism`, and both are there", &line_pd, &snake_p8, &snake_p8)), &Text::from(format!("keep one: {}/mod.prism when the module has children, else {}.prism", &snake_p8, &snake_p8))))
                }
            } else {
                if crate::check::env::has_key(has_p0, &file_p9) {
                    prism_rtl::Turn::More(Rc::new(WalkModule { has_p0: has_p0.clone(), texts_p1: texts_p1.clone(), acc_p2: acc_p2.clone(), main_p3: file_p9.clone(), name_p4: name_pb.clone(), parent_p5: main_p3.clone(), in_test_p6: is_test_pc }))
                } else {
                    if crate::check::env::has_key(has_p0, &nested_pa) {
                        prism_rtl::Turn::More(Rc::new(WalkModule { has_p0: has_p0.clone(), texts_p1: texts_p1.clone(), acc_p2: acc_p2.clone(), main_p3: nested_pa.clone(), name_p4: name_pb.clone(), parent_p5: main_p3.clone(), in_test_p6: is_test_pc }))
                    } else {
                        prism_rtl::Turn::Finished(add_tree_diag(acc_p2, main_p3, &h_p5.span, &Text::lit("mod-missing"), &Text::from(format!("`{}` declares `{}.prism` or `{}/mod.prism`, and neither is there", &line_pd, &snake_p8, &snake_p8)), &Text::from(format!("create {}.prism, or delete the line", &snake_p8))))
                    }
                }
            }
        }
    }
}

/// `Start Child, x`: what the function value is when passed to `@Run`.
pub fn start_child(has_p0: Map<Text, bool>, texts_p1: Map<Text, Text>, acc_p2: TreeAcc, main_p3: Text, dir_p4: Text, h_p5: HeadLine, parent_p6: Text, in_test_p7: bool) -> Rc<dyn prism_rtl::Job<TreeAcc>> {
    Rc::new(Child { has_p0, texts_p1, acc_p2, main_p3, dir_p4, h_p5, parent_p6, in_test_p7 })
}

/// ```prism
/// Stray: fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text -> TreeAcc
/// ```
pub fn stray(has_p0: &Map<Text, bool>, texts_p1: &Map<Text, Text>, acc_p2: &TreeAcc, f_p3: &Text) -> TreeAcc {
    let text_p4 = or(&get(texts_p1, f_p3), &Text::lit(""));
    if crate::syntax::lexer::chars::has_suffix(f_p3, &Text::lit(".prismtest")) {
        add_tree_diag(acc_p2, f_p3, &no_span(), &Text::lit("mod-stray"), &Text::from(format!("`{}` is a test script in a tree, where tests are in test modules", &base_of(f_p3))), &Text::lit("put its declarations in a test module, declared by `test mod Tests`"))
    } else {
        {
            let dir_p5 = dir_of(f_p3);
            let is_main_p6 = &base_of(f_p3) == &Text::lit("mod.prism");
            let home_p7 = if is_main_p6 { dir_of(&dir_p5) } else { dir_p5.clone() };
            let main_p8 = fold(&Array::from(vec![Text::lit("mod.prism"), Text::lit("app.prism"), Text::lit("lib.prism")]), &Text::lit(""), &(|m_pb: &Text, n_pc: &Text| if (m_pb == &Text::lit("")) && crate::check::env::has_key(has_p0, &under(&home_p7, n_pc)) {
                n_pc.clone()
            } else {
                m_pb.clone()
            }));
            let line_p9 = if is_main_p6 {
                Text::from(format!("mod {}", &mod_of_dir(&base_of(&dir_p5))))
            } else {
                Text::from(format!("mod {}", &mod_of_dir(&or(&crate::syntax::lexer::chars::before_suffix(&base_of(f_p3), &Text::lit(".prism")), f_p3))))
            };
            let shown_pa = if is_main_p6 {
                Text::from(format!("{}/mod.prism", &base_of(&dir_p5)))
            } else {
                base_of(f_p3)
            };
            if &main_p8 == &Text::lit("") {
                add_tree_diag(acc_p2, f_p3, &no_span(), &Text::lit("mod-stray"), &Text::from(format!("`{}` is in a tree, in no module\'s directory", f_p3)), &Text::lit("move it into a module\'s directory and declare it with a `mod` line"))
            } else {
                add_tree_diag(acc_p2, f_p3, &no_span(), &Text::lit("mod-stray"), &Text::from(format!("`{}` is in the directory of `{}`, which declares no `{}`", &shown_pa, &main_p8, &line_p9)), &Text::from(format!("declare it with `{}` in {}, or move it out of the directory", &line_p9, &main_p8)))
            }
        }
    }
}

/// ```prism
/// ReachTree: unbounded fn [ModFiles], Text -> [ModFiles]
/// ```
pub fn reach_tree(units_p0: &Array<ModFiles>, main_p1: &Text) -> Array<ModFiles> {
    let by_name_p2 = fold(units_p0, &Map::new(), &(|m_p5: &Map<Text, ModFiles>, u_p6: &ModFiles| insert(m_p5, &unit_name(u_p6), u_p6)));
    let start_p3 = fold(units_p0, &Array::new(), &(|s_p7: &Array<Text>, u_p8: &ModFiles| if (&main_path(u_p8) == main_p1) || ((&u_p8.parent == main_p1) && is_test_unit(u_p8)) {
        push(s_p7, &unit_name(u_p8))
    } else {
        s_p7.clone()
    }));
    let reached_p4 = reach_names(&by_name_p2, &start_p3, &start_p3);
    filter(units_p0, &(|u_p9: &ModFiles| crate::check::types::has_text(&reached_p4, &unit_name(u_p9))))
}

/// The step machine of `ReachTree`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReachTree: unbounded fn [ModFiles], Text -> [ModFiles]
/// ```
pub struct ReachTree {
    pub units_p0: Array<ModFiles>,
    pub main_p1: Text,
}

impl prism_rtl::Job<Array<ModFiles>> for ReachTree {
    fn cycle(&self) -> prism_rtl::Turn<Array<ModFiles>> {
        let units_p0 = &self.units_p0;
        let main_p1 = &self.main_p1;
        let by_name_p2 = fold(units_p0, &Map::new(), &(|m_p5: &Map<Text, ModFiles>, u_p6: &ModFiles| insert(m_p5, &unit_name(u_p6), u_p6)));
        let start_p3 = fold(units_p0, &Array::new(), &(|s_p7: &Array<Text>, u_p8: &ModFiles| if (&main_path(u_p8) == main_p1) || ((&u_p8.parent == main_p1) && is_test_unit(u_p8)) {
            push(s_p7, &unit_name(u_p8))
        } else {
            s_p7.clone()
        }));
        let units_p0 = units_p0.clone();
        call_then(start_reach_names(by_name_p2.clone(), start_p3.clone(), start_p3.clone()), move |reach_names_22458: Array<Text>| {
            let reached_p4 = reach_names_22458;
            prism_rtl::Turn::Finished(filter(&units_p0, &(|u_p9: &ModFiles| crate::check::types::has_text(&reached_p4, &unit_name(u_p9)))))
        })
    }
}

/// `Start ReachTree, x`: what the function value is when passed to `@Run`.
pub fn start_reach_tree(units_p0: Array<ModFiles>, main_p1: Text) -> Rc<dyn prism_rtl::Job<Array<ModFiles>>> {
    Rc::new(ReachTree { units_p0, main_p1 })
}

/// ```prism
/// ReachNames: unbounded fn (Text ==> ModFiles), [Text], [Text] -> [Text]
/// ```
pub fn reach_names(by_name_p0: &Map<Text, ModFiles>, seen_p1: &Array<Text>, todo_p2: &Array<Text>) -> Array<Text> {
    match index(todo_p2, &Nat::from(0u32)) {
        None => seen_p1.clone(),
        Some(n_p3) => {
            let uses_p4 = match get(by_name_p0, &n_p3) {
                Some(u_p6) => each(&filter(&header_lines(&main_text(&u_p6)), &(|h_p7: &HeadLine| &h_p7.word == &Text::lit("use"))), &(|h_p8: &HeadLine| use_target(by_name_p0, &h_p8.arg))),
                None => Array::new(),
            };
            let fresh_p5 = filter(&uses_p4, &(|x_p9: &Text| !crate::check::types::has_text(seen_p1, x_p9) && crate::check::env::has_key(by_name_p0, x_p9)));
            reach_names(by_name_p0, &crate::check::types::union_texts(seen_p1, &fresh_p5), &append(&drop(todo_p2, &Nat::from(1u32)), &fresh_p5))
        },
    }
}

/// The step machine of `ReachNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReachNames: unbounded fn (Text ==> ModFiles), [Text], [Text] -> [Text]
/// ```
pub struct ReachNames {
    pub by_name_p0: Map<Text, ModFiles>,
    pub seen_p1: Array<Text>,
    pub todo_p2: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for ReachNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let by_name_p0 = &self.by_name_p0;
        let seen_p1 = &self.seen_p1;
        let todo_p2 = &self.todo_p2;
        match index(todo_p2, &Nat::from(0u32)) {
            None => prism_rtl::Turn::Finished(seen_p1.clone()),
            Some(n_p3) => {
                let uses_p4 = match get(by_name_p0, &n_p3) {
                    Some(u_p6) => each(&filter(&header_lines(&main_text(&u_p6)), &(|h_p7: &HeadLine| &h_p7.word == &Text::lit("use"))), &(|h_p8: &HeadLine| use_target(by_name_p0, &h_p8.arg))),
                    None => Array::new(),
                };
                let fresh_p5 = filter(&uses_p4, &(|x_p9: &Text| !crate::check::types::has_text(seen_p1, x_p9) && crate::check::env::has_key(by_name_p0, x_p9)));
                prism_rtl::Turn::More(Rc::new(ReachNames { by_name_p0: by_name_p0.clone(), seen_p1: crate::check::types::union_texts(seen_p1, &fresh_p5), todo_p2: append(&drop(todo_p2, &Nat::from(1u32)), &fresh_p5) }))
            },
        }
    }
}

/// `Start ReachNames, x`: what the function value is when passed to `@Run`.
pub fn start_reach_names(by_name_p0: Map<Text, ModFiles>, seen_p1: Array<Text>, todo_p2: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ReachNames { by_name_p0, seen_p1, todo_p2 })
}

/// ```prism
/// UseTarget: fn (Text ==> ModFiles), Text -> Text
/// ```
pub fn use_target(by_name_p0: &Map<Text, ModFiles>, u_p1: &Text) -> Text {
    if (u_p1 == &Text::lit("App")) && !crate::check::env::has_key(by_name_p0, &Text::lit("App")) {
        Text::lit("")
    } else {
        u_p1.clone()
    }
}

/// ```prism
/// IsTestUnit: fn ModFiles -> Bool
/// ```
pub fn is_test_unit(u_p0: &ModFiles) -> bool {
    match index(&u_p0.segs, &Nat::from(0u32)) {
        Some(s_p1) => &s_p1.role == &Text::lit("test"),
        None => false,
    }
}

/// ```prism
/// UnitName: fn ModFiles -> Text
/// ```
pub fn unit_name(u_p0: &ModFiles) -> Text {
    if u_p0.named {
        u_p0.name.clone()
    } else {
        fold(&header_lines(&main_text(u_p0)), &Text::lit(""), &(|n_p1: &Text, h_p2: &HeadLine| if &h_p2.word == &Text::lit("module") { h_p2.arg.clone() } else { n_p1.clone() }))
    }
}

/// ```prism
/// RenderTreeDiag: fn (Text ==> Text), TreeDiag -> Text
/// ```
pub fn render_tree_diag(texts_p0: &Map<Text, Text>, d_p1: &TreeDiag) -> Text {
    crate::check::errors::render_cdiag(&Array::from(vec![crate::check::errors::mk_src(&d_p1.path_, &or(&get(texts_p0, &d_p1.path_), &Text::lit("")))]), &crate::check::errors::CDiag { code: d_p1.code.clone(), file: Nat::from(0u32), span: d_p1.span.clone(), message: d_p1.message.clone(), fix: d_p1.fix.clone() })
}

/// ```prism
/// TreeReport: fn ReadInput, [TreeDiag] -> Text
/// ```
pub fn tree_report(input_p0: &ReadInput, ds_p1: &Array<TreeDiag>) -> Text {
    let texts_p2 = map(&input_p0.texts);
    let n_p3 = len(ds_p1);
    Text::from(format!("{}{} error{}", &concat(&each(ds_p1, &(|d_p4: &TreeDiag| render_tree_diag(&texts_p2, d_p4)))), &n_p3, &(if &n_p3 == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") })))
}

/// ```prism
/// ParseUnit: unbounded fn ModFiles -> ((Src, Parsed))
/// ```
pub fn parse_unit(u_p0: &ModFiles) -> (crate::check::errors::Src, crate::syntax::parser::Parsed) {
    let src_p1 = crate::check::errors::mk_joined_src(&each(&u_p0.segs, &(|s_p5: &Seg| (s_p5.path_.clone(), s_p5.text.clone(), s_p5.role.clone()))));
    let parsed_p2 = crate::syntax::parser::parse_file(&src_p1.text);
    let t0_p3 = parsed_p2.tree.clone();
    let tree_p4 = if !u_p0.named {
        t0_p3.clone()
    } else {
        {
            let mut this: crate::syntax::Module = t0_p3.clone();
            this.name = if &u_p0.name == &Text::lit("") {
                None
            } else {
                Some(crate::syntax::QualName { path_: split_on(&u_p0.name, &Text::lit(".")), span: no_span() })
            };
            this
        }
    };
    (src_p1.clone(), crate::syntax::parser::Parsed { tree: tree_p4.clone(), diags: parsed_p2.diags.clone() })
}

/// The step machine of `ParseUnit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseUnit: unbounded fn ModFiles -> ((Src, Parsed))
/// ```
pub struct ParseUnit {
    pub u_p0: ModFiles,
}

impl prism_rtl::Job<(crate::check::errors::Src, crate::syntax::parser::Parsed)> for ParseUnit {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::errors::Src, crate::syntax::parser::Parsed)> {
        let u_p0 = &self.u_p0;
        let src_p1 = crate::check::errors::mk_joined_src(&each(&u_p0.segs, &(|s_p5: &Seg| (s_p5.path_.clone(), s_p5.text.clone(), s_p5.role.clone()))));
        let u_p0 = u_p0.clone();
        call_then(crate::syntax::parser::start_parse_file(src_p1.text.clone()), move |parse_file_24471: crate::syntax::parser::Parsed| {
            let parsed_p2 = parse_file_24471;
            let t0_p3 = parsed_p2.tree.clone();
            let tree_p4 = if !u_p0.named {
                t0_p3.clone()
            } else {
                {
                    let mut this: crate::syntax::Module = t0_p3.clone();
                    this.name = if &u_p0.name == &Text::lit("") {
                        None
                    } else {
                        Some(crate::syntax::QualName { path_: split_on(&u_p0.name, &Text::lit(".")), span: no_span() })
                    };
                    this
                }
            };
            prism_rtl::Turn::Finished((src_p1.clone(), crate::syntax::parser::Parsed { tree: tree_p4.clone(), diags: parsed_p2.diags.clone() }))
        })
    }
}

/// `Start ParseUnit, x`: what the function value is when passed to `@Run`.
pub fn start_parse_unit(u_p0: ModFiles) -> Rc<dyn prism_rtl::Job<(crate::check::errors::Src, crate::syntax::parser::Parsed)>> {
    Rc::new(ParseUnit { u_p0 })
}

/// ```prism
/// ParseProgram: unbounded fn Assembled -> ParsedProgram
/// ```
pub fn parse_program(read_p0: &Assembled) -> ParsedProgram {
    let parsed_p1 = run_to_end(each_job(read_p0.units.clone(), Rc::new(move |p0: ModFiles| entered(once_job(move || {
        let u_p8 = p0;
        prism_rtl::Turn::More(Rc::new(ParseUnit { u_p0: u_p8.clone() }))
    }))) as Rc<dyn Fn(ModFiles) -> Rc<dyn prism_rtl::Job<(crate::check::errors::Src, crate::syntax::parser::Parsed)>>>));
    let user_mods_p2 = fold(&parsed_p1, &Array::new(), &(|acc_p9: &Array<Text>, (_, p_pa): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| push(acc_p9, &crate::check::env::mod_name(&p_pa.tree))));
    let user_fams_p3 = fold(&parsed_p1, &Array::new(), &(|acc_pb: &Array<Text>, (_, p_pc): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| append(acc_pb, &tag_families(&p_pc.tree))));
    let pre_parsed_p4 = run_to_end(each_job(read_p0.prelude.clone(), Rc::new(move |p0: ModFiles| entered(once_job(move || {
        let u_pd = p0;
        prism_rtl::Turn::More(Rc::new(ParseUnit { u_p0: u_pd.clone() }))
    }))) as Rc<dyn Fn(ModFiles) -> Rc<dyn prism_rtl::Job<(crate::check::errors::Src, crate::syntax::parser::Parsed)>>>));
    let kept_p5 = filter(&pre_parsed_p4, &(|(_, p_pe): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| !crate::check::types::has_text(&user_mods_p2, &crate::check::env::mod_name(&p_pe.tree)) && !any_in(&tag_families(&p_pe.tree), &user_fams_p3)));
    let all_p6 = append(&parsed_p1, &kept_p5);
    let errors_p7 = fold(&all_p6, &Text::lit(""), &(|acc_pf: &Text, (src_pg, p_ph): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| if crate::program::any_errors(&p_ph.diags) {
        Text::from(format!("{}{}", acc_pf, &render_parse(src_pg, &p_ph.diags)))
    } else {
        acc_pf.clone()
    }));
    ParsedProgram { srcs: each(&all_p6, &(|(s_pi, _): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| s_pi.clone())), trees: each(&all_p6, &(|(_, p_pj): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| p_pj.tree.clone())), shown: len(&parsed_p1), parents: each(&read_p0.units, &(|u_pk: &ModFiles| u_pk.parent.clone())), errors: errors_p7.clone() }
}

/// The step machine of `ParseProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseProgram: unbounded fn Assembled -> ParsedProgram
/// ```
pub struct ParseProgram {
    pub read_p0: Assembled,
}

impl prism_rtl::Job<ParsedProgram> for ParseProgram {
    fn cycle(&self) -> prism_rtl::Turn<ParsedProgram> {
        let read_p0 = &self.read_p0;
        let read_p0 = read_p0.clone();
        call_value(each_job(read_p0.units.clone(), Rc::new(move |p0: ModFiles| entered(once_job(move || {
            let u_p8 = p0;
            prism_rtl::Turn::More(Rc::new(ParseUnit { u_p0: u_p8.clone() }))
        }))) as Rc<dyn Fn(ModFiles) -> Rc<dyn prism_rtl::Job<(crate::check::errors::Src, crate::syntax::parser::Parsed)>>>), move |each_25155: Array<(crate::check::errors::Src, crate::syntax::parser::Parsed)>| {
            let parsed_p1 = each_25155;
            let user_mods_p2 = fold(&parsed_p1, &Array::new(), &(|acc_p9: &Array<Text>, (_, p_pa): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| push(acc_p9, &crate::check::env::mod_name(&p_pa.tree))));
            let user_fams_p3 = fold(&parsed_p1, &Array::new(), &(|acc_pb: &Array<Text>, (_, p_pc): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| append(acc_pb, &tag_families(&p_pc.tree))));
            call_value(each_job(read_p0.prelude.clone(), Rc::new(move |p0: ModFiles| entered(once_job(move || {
                let u_pd = p0;
                prism_rtl::Turn::More(Rc::new(ParseUnit { u_p0: u_pd.clone() }))
            }))) as Rc<dyn Fn(ModFiles) -> Rc<dyn prism_rtl::Job<(crate::check::errors::Src, crate::syntax::parser::Parsed)>>>), move |each_25389: Array<(crate::check::errors::Src, crate::syntax::parser::Parsed)>| {
                let pre_parsed_p4 = each_25389;
                let kept_p5 = filter(&pre_parsed_p4, &(|(_, p_pe): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| !crate::check::types::has_text(&user_mods_p2, &crate::check::env::mod_name(&p_pe.tree)) && !any_in(&tag_families(&p_pe.tree), &user_fams_p3)));
                let all_p6 = append(&parsed_p1, &kept_p5);
                let errors_p7 = fold(&all_p6, &Text::lit(""), &(|acc_pf: &Text, (src_pg, p_ph): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| if crate::program::any_errors(&p_ph.diags) {
                    Text::from(format!("{}{}", acc_pf, &render_parse(src_pg, &p_ph.diags)))
                } else {
                    acc_pf.clone()
                }));
                prism_rtl::Turn::Finished(ParsedProgram { srcs: each(&all_p6, &(|(s_pi, _): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| s_pi.clone())), trees: each(&all_p6, &(|(_, p_pj): &(crate::check::errors::Src, crate::syntax::parser::Parsed)| p_pj.tree.clone())), shown: len(&parsed_p1), parents: each(&read_p0.units, &(|u_pk: &ModFiles| u_pk.parent.clone())), errors: errors_p7.clone() })
            })
        })
    }
}

/// `Start ParseProgram, x`: what the function value is when passed to `@Run`.
pub fn start_parse_program(read_p0: Assembled) -> Rc<dyn prism_rtl::Job<ParsedProgram>> {
    Rc::new(ParseProgram { read_p0 })
}

/// ```prism
/// TreeDeclDiags: fn ParsedProgram -> [CDiag]
/// ```
pub fn tree_decl_diags(pp_p0: &ParsedProgram) -> Array<crate::check::errors::CDiag> {
    fold(&crate::check::errors::range0(&pp_p0.shown), &Array::new(), &(|acc_p1: &Array<crate::check::errors::CDiag>, i_p2: &Nat| match index(&pp_p0.srcs, i_p2) {
        Some(src_p3) => fold(&or(&index(&pp_p0.trees, i_p2), &crate::check::env::empty_module()).decls, acc_p1, &(|a_p4: &Array<crate::check::errors::CDiag>, d_p5: &crate::syntax::decls::Decl| append(a_p4, &decl_role_diags(&src_p3, &or(&index(&pp_p0.parents, i_p2), &Text::lit("")), i_p2, d_p5)))),
        None => acc_p1.clone(),
    }))
}

/// ```prism
/// DeclRoleDiags: fn Src, Text, Nat, Decl -> [CDiag]
/// ```
pub fn decl_role_diags(src_p0: &crate::check::errors::Src, parent_p1: &Text, i_p2: &Nat, d_p3: &crate::syntax::decls::Decl) -> Array<crate::check::errors::CDiag> {
    let seg_p4 = crate::check::errors::seg_at(src_p0, &d_p3.span.start);
    let role_p5 = seg_p4.role.clone();
    let main_p6 = base_of(&src_p0.path_);
    let tested_p7 = if (&seg_p4.path_ == &src_p0.path_) && (parent_p1 != &Text::lit("")) {
        base_of(parent_p1)
    } else {
        main_p6.clone()
    };
    let what_p8 = match &d_p3.kind {
        crate::syntax::decls::DeclKind::DTest(_) => Text::lit("test"),
        crate::syntax::decls::DeclKind::DCheck(_) => Text::lit("check"),
        crate::syntax::decls::DeclKind::DTag(_) => Text::lit("tag"),
        crate::syntax::decls::DeclKind::DTrait(_) => Text::lit("trait"),
        crate::syntax::decls::DeclKind::DImpl(_) => Text::lit("impl"),
        _ => Text::lit(""),
    };
    if (&role_p5 == &Text::lit("main")) && ((&what_p8 == &Text::lit("test")) || (&what_p8 == &Text::lit("check"))) {
        Array::from(vec![crate::check::errors::CDiag { code: Text::lit("test-outside"), file: i_p2.clone(), span: d_p3.span.clone(), message: Text::from(format!("a `{}` in a tree stands only in a test module", &what_p8)), fix: Text::from(format!("move it to a test module: `test mod Tests` in {}, and tests.prism", &main_p6)) }])
    } else {
        if (&role_p5 == &Text::lit("test")) && (((&what_p8 == &Text::lit("tag")) || (&what_p8 == &Text::lit("trait"))) || (&what_p8 == &Text::lit("impl"))) {
            Array::from(vec![crate::check::errors::CDiag { code: Text::lit("test-declares"), file: i_p2.clone(), span: d_p3.span.clone(), message: Text::lit("a test module declares no tag, trait or impl"), fix: Text::from(format!("declare it in {}, the module the test module tests", &tested_p7)) }])
        } else {
            Array::new()
        }
    }
}

/// ```prism
/// TagFamilies: fn Module -> [Text]
/// ```
pub fn tag_families(m_p0: &crate::syntax::Module) -> Array<Text> {
    fold(&m_p0.decls, &Array::new(), &(|acc_p1: &Array<Text>, d_p2: &crate::syntax::decls::Decl| match &d_p2.kind {
        crate::syntax::decls::DeclKind::DTag(t_p3) => push(acc_p1, &crate::syntax::lexer::chars::join(&take(&t_p3.name.path_, &crate::syntax::lexer::chars::dec(&len(&t_p3.name.path_))), &Text::lit("."))),
        _ => acc_p1.clone(),
    }))
}

/// ```prism
/// AnyIn: fn [Text], [Text] -> Bool
/// ```
pub fn any_in(xs_p0: &Array<Text>, ys_p1: &Array<Text>) -> bool {
    fold(xs_p0, &false, &(|seen_p2: &bool, x_p3: &Text| *seen_p2 || crate::check::types::has_text(ys_p1, x_p3)))
}

/// ```prism
/// RenderParse: fn Src, [Diag] -> Text
/// ```
pub fn render_parse(src_p0: &crate::check::errors::Src, ds_p1: &Array<crate::syntax::Diag>) -> Text {
    concat(&each(&filter(ds_p1, &(|d_p2: &crate::syntax::Diag| &d_p2.stage != &Text::lit("out"))), &(|d_p3: &crate::syntax::Diag| Text::from(format!("{}:{}: {}\n", &crate::check::errors::src_place(src_p0, &d_p3.span.start), &(&crate::syntax::lexer::chars::column_of(&src_p0.text, &or(&index(&src_p0.starts, &crate::check::errors::cline_of(&src_p0.starts, &d_p3.span.start)), &Nat::from(0u32)), &d_p3.span.start) + &Nat::from(1u32)), &d_p3.message)))))
}
