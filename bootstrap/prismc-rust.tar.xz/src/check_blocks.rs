//! The module `CheckBlocks`, from `target/bootstrap/src/prismc/check-blocks.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (docs/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
#[allow(unused_imports)]
use crate::{program, ast, check_env, check_errors, check_expr, check_passes, check_types, cpp_prelude_template, cpp_templates, emit, emit_cpp, fs, lexer, lower, parser, prelude_template, process, rust_templates, sexp, typed};

/// ```prism
/// GroupOrder: fn [Stmt] -> [Nat]
/// ```
pub fn group_order(stmts: &Array<ast::Stmt>) -> Array<Nat> {
    let all = check_errors::range0(&len(stmts));
    let holds = filter(&all, &(|i: &Nat| is_hold(&or(&index(stmts, i), &dummy_stmt2()))));
    let lets = filter(&all, &(|i: &Nat| is_let_like(&or(&index(stmts, i), &dummy_stmt2()))));
    let rest = filter(&all, &(|i: &Nat| !is_hold(&or(&index(stmts, i), &dummy_stmt2())) && !is_let_like(&or(&index(stmts, i), &dummy_stmt2()))));
    append(&append(&holds, &lets), &rest)
}

/// ```prism
/// DepOrder: unbounded fn [Stmt] -> [ [Nat] ]
/// ```
pub fn dep_order(stmts: &Array<ast::Stmt>) -> Array<Array<Nat>> {
    let n = len(stmts);
    let defs = run_to_end(each_job(stmts.clone(), Rc::new(move |p0: ast::Stmt| entered(once_job(move || {
        let s = p0;
        prism_rtl::Turn::More(Rc::new(GroupDefs { s: s.clone() }))
    }))) as Rc<dyn Fn(ast::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    let uses = run_to_end(each_job(stmts.clone(), Rc::new(move |p0: ast::Stmt| entered(once_job(move || {
        let s = p0;
        prism_rtl::Turn::More(Rc::new(check_passes::NamesInStmt { s: s.clone() }))
    }))) as Rc<dyn Fn(ast::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>>>));
    let deps = each(&check_errors::range0(&n), &(|i: &Nat| filter(&check_errors::range0(&n), &(|j: &Nat| fold(&or(&index(&defs, j), &Array::new()), &false, &(|seen: &bool, d: &Text| *seen || check_types::has_text(&or(&index(&uses, i), &Array::new()), d)))))));
    let reach = run_to_end(each_job(check_errors::range0(&n), {
        let deps = deps.clone();
        Rc::new(move |p0: Nat| {
            let deps = deps.clone();
            entered(once_job(move || {
                let i = p0;
                prism_rtl::Turn::More(Rc::new(ReachIdx { deps: deps.clone(), frontier: or(&index(&deps, &i), &Array::new()), seen: Array::new() }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
    }));
    let comps = each(&check_errors::range0(&n), &(|i: &Nat| filter(&check_errors::range0(&n), &(|j: &Nat| (j == i) || (check_types::has_nat(&or(&index(&reach, i), &Array::new()), j) && check_types::has_nat(&or(&index(&reach, j), &Array::new()), i))))));
    emit_groups(&comps, &deps, &Array::new(), &Array::new())
}

/// The step machine of `DepOrder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DepOrder: unbounded fn [Stmt] -> [ [Nat] ]
/// ```
pub struct DepOrder {
    pub stmts: Array<ast::Stmt>,
}

impl prism_rtl::Job<Array<Array<Nat>>> for DepOrder {
    fn cycle(&self) -> prism_rtl::Turn<Array<Array<Nat>>> {
        let stmts = &self.stmts;
        let n = len(stmts);
        let stmts = stmts.clone();
        call_value(each_job(stmts.clone(), Rc::new(move |p0: ast::Stmt| entered(once_job(move || {
            let s = p0;
            prism_rtl::Turn::More(Rc::new(GroupDefs { s: s.clone() }))
        }))) as Rc<dyn Fn(ast::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_1872: Array<Array<Text>>| {
            let defs = each_1872;
            call_value(each_job(stmts.clone(), Rc::new(move |p0: ast::Stmt| entered(once_job(move || {
                let s = p0;
                prism_rtl::Turn::More(Rc::new(check_passes::NamesInStmt { s: s.clone() }))
            }))) as Rc<dyn Fn(ast::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>>>), move |each_1916: Array<Array<Text>>| {
                let uses = each_1916;
                let deps = each(&check_errors::range0(&n), &(|i: &Nat| filter(&check_errors::range0(&n), &(|j: &Nat| fold(&or(&index(&defs, j), &Array::new()), &false, &(|seen: &bool, d: &Text| *seen || check_types::has_text(&or(&index(&uses, i), &Array::new()), d)))))));
                call_value(each_job(check_errors::range0(&n), {
                    let deps = deps.clone();
                    Rc::new(move |p0: Nat| {
                        let deps = deps.clone();
                        entered(once_job(move || {
                            let i = p0;
                            prism_rtl::Turn::More(Rc::new(ReachIdx { deps: deps.clone(), frontier: or(&index(&deps, &i), &Array::new()), seen: Array::new() }))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
                }), move |each_2105: Array<Array<Nat>>| {
                    let reach = each_2105;
                    let comps = each(&check_errors::range0(&n), &(|i: &Nat| filter(&check_errors::range0(&n), &(|j: &Nat| (j == i) || (check_types::has_nat(&or(&index(&reach, i), &Array::new()), j) && check_types::has_nat(&or(&index(&reach, j), &Array::new()), i))))));
                    prism_rtl::Turn::More(Rc::new(EmitGroups { comps: comps.clone(), deps: deps.clone(), done: Array::new(), acc: Array::new() }))
                })
            })
        })
    }
}

/// `Start DepOrder, x`: what the function value is when passed to `@Run`.
pub fn start_dep_order(stmts: Array<ast::Stmt>) -> Rc<dyn prism_rtl::Job<Array<Array<Nat>>>> {
    Rc::new(DepOrder { stmts })
}

/// ```prism
/// GroupDefs: unbounded fn Stmt -> [Text]
/// ```
pub fn group_defs(s: &ast::Stmt) -> Array<Text> {
    match &s.kind {
        ast::StmtKind::SBind(p_, _, _) => check_env::pattern_names(p_),
        ast::StmtKind::SLet(p_, _, _) => check_env::pattern_names(p_),
        ast::StmtKind::SFn(f) => Array::from(vec![check_env::def_name_text(&f.name)]),
        ast::StmtKind::SWidget(w) => Array::from(vec![check_env::sname_key(&w.name)]),
        _ => Array::new(),
    }
}

/// The step machine of `GroupDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GroupDefs: unbounded fn Stmt -> [Text]
/// ```
pub struct GroupDefs {
    pub s: ast::Stmt,
}

impl prism_rtl::Job<Array<Text>> for GroupDefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let s = &self.s;
        match &s.kind {
            ast::StmtKind::SBind(p_, _, _) => prism_rtl::Turn::More(Rc::new(check_env::PatternNames { p_: p_.clone() })),
            ast::StmtKind::SLet(p_, _, _) => prism_rtl::Turn::More(Rc::new(check_env::PatternNames { p_: p_.clone() })),
            ast::StmtKind::SFn(f) => prism_rtl::Turn::Finished(Array::from(vec![check_env::def_name_text(&f.name)])),
            ast::StmtKind::SWidget(w) => prism_rtl::Turn::Finished(Array::from(vec![check_env::sname_key(&w.name)])),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start GroupDefs, x`: what the function value is when passed to `@Run`.
pub fn start_group_defs(s: ast::Stmt) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(GroupDefs { s })
}

/// ```prism
/// ReachIdx: unbounded fn [ [Nat] ], [Nat], [Nat] -> [Nat]
/// ```
pub fn reach_idx(deps: &Array<Array<Nat>>, frontier: &Array<Nat>, seen: &Array<Nat>) -> Array<Nat> {
    match index(frontier, &Nat::from(0u32)) {
        None => seen.clone(),
        Some(x) => if check_types::has_nat(seen, &x) {
            reach_idx(deps, &drop(frontier, &Nat::from(1u32)), seen)
        } else {
            reach_idx(deps, &append(&drop(frontier, &Nat::from(1u32)), &or(&index(deps, &x), &Array::new())), &push(seen, &x))
        },
    }
}

/// The step machine of `ReachIdx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReachIdx: unbounded fn [ [Nat] ], [Nat], [Nat] -> [Nat]
/// ```
pub struct ReachIdx {
    pub deps: Array<Array<Nat>>,
    pub frontier: Array<Nat>,
    pub seen: Array<Nat>,
}

impl prism_rtl::Job<Array<Nat>> for ReachIdx {
    fn cycle(&self) -> prism_rtl::Turn<Array<Nat>> {
        let deps = &self.deps;
        let frontier = &self.frontier;
        let seen = &self.seen;
        match index(frontier, &Nat::from(0u32)) {
            None => prism_rtl::Turn::Finished(seen.clone()),
            Some(x) => if check_types::has_nat(seen, &x) {
                prism_rtl::Turn::More(Rc::new(ReachIdx { deps: deps.clone(), frontier: drop(frontier, &Nat::from(1u32)), seen: seen.clone() }))
            } else {
                prism_rtl::Turn::More(Rc::new(ReachIdx { deps: deps.clone(), frontier: append(&drop(frontier, &Nat::from(1u32)), &or(&index(deps, &x), &Array::new())), seen: push(seen, &x) }))
            },
        }
    }
}

/// `Start ReachIdx, x`: what the function value is when passed to `@Run`.
pub fn start_reach_idx(deps: Array<Array<Nat>>, frontier: Array<Nat>, seen: Array<Nat>) -> Rc<dyn prism_rtl::Job<Array<Nat>>> {
    Rc::new(ReachIdx { deps, frontier, seen })
}

/// ```prism
/// EmitGroups: unbounded fn [ [Nat] ], [ [Nat] ], [Nat], [ [Nat] ] -> [ [Nat] ]
/// ```
pub fn emit_groups(comps: &Array<Array<Nat>>, deps: &Array<Array<Nat>>, done: &Array<Nat>, acc: &Array<Array<Nat>>) -> Array<Array<Nat>> {
    let ready = filter(&check_errors::range0(&len(comps)), &(|i: &Nat| !check_types::has_nat(done, i) && fold(&or(&index(deps, i), &Array::new()), &true, &(|ok: &bool, d: &Nat| *ok && (check_types::has_nat(done, d) || check_types::has_nat(&or(&index(comps, i), &Array::new()), d))))));
    match index(&ready, &Nat::from(0u32)) {
        None => acc.clone(),
        Some(i) => {
            let c = or(&index(comps, &i), &Array::from(vec![i.clone()]));
            emit_groups(comps, deps, &append(done, &c), &push(acc, &c))
        },
    }
}

/// The step machine of `EmitGroups`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EmitGroups: unbounded fn [ [Nat] ], [ [Nat] ], [Nat], [ [Nat] ] -> [ [Nat] ]
/// ```
pub struct EmitGroups {
    pub comps: Array<Array<Nat>>,
    pub deps: Array<Array<Nat>>,
    pub done: Array<Nat>,
    pub acc: Array<Array<Nat>>,
}

impl prism_rtl::Job<Array<Array<Nat>>> for EmitGroups {
    fn cycle(&self) -> prism_rtl::Turn<Array<Array<Nat>>> {
        let comps = &self.comps;
        let deps = &self.deps;
        let done = &self.done;
        let acc = &self.acc;
        let ready = filter(&check_errors::range0(&len(comps)), &(|i: &Nat| !check_types::has_nat(done, i) && fold(&or(&index(deps, i), &Array::new()), &true, &(|ok: &bool, d: &Nat| *ok && (check_types::has_nat(done, d) || check_types::has_nat(&or(&index(comps, i), &Array::new()), d))))));
        match index(&ready, &Nat::from(0u32)) {
            None => prism_rtl::Turn::Finished(acc.clone()),
            Some(i) => {
                let c = or(&index(comps, &i), &Array::from(vec![i.clone()]));
                prism_rtl::Turn::More(Rc::new(EmitGroups { comps: comps.clone(), deps: deps.clone(), done: append(done, &c), acc: push(acc, &c) }))
            },
        }
    }
}

/// `Start EmitGroups, x`: what the function value is when passed to `@Run`.
pub fn start_emit_groups(comps: Array<Array<Nat>>, deps: Array<Array<Nat>>, done: Array<Nat>, acc: Array<Array<Nat>>) -> Rc<dyn prism_rtl::Job<Array<Array<Nat>>>> {
    Rc::new(EmitGroups { comps, deps, done, acc })
}

/// ```prism
/// IsHold: fn Stmt -> Bool
/// ```
pub fn is_hold(s: &ast::Stmt) -> bool {
    match &s.kind {
        ast::StmtKind::SBind(_, _, Some(_)) => true,
        _ => false,
    }
}

/// ```prism
/// IsLetLike: fn Stmt -> Bool
/// ```
pub fn is_let_like(s: &ast::Stmt) -> bool {
    match &s.kind {
        ast::StmtKind::SLet(_, _, _) => true,
        ast::StmtKind::SFn(_) => true,
        ast::StmtKind::SSignature(_) => true,
        _ => false,
    }
}

/// ```prism
/// InferWidgetBlock: unbounded fn Env, St, Block -> ((Ty, St))
/// ```
pub fn infer_widget_block(env: &check_expr::Env, st: &check_types::St, b: &ast::Block) -> (check_types::Ty, check_types::St) {
    let (env1, st1) = block_row(env, st, &b.stmts);
    let (env2, st2) = run_to_end(fold_job(b.stmts.clone(), (env1.clone(), st1.clone()), Rc::new(move |(p0, p1): ((check_expr::Env, check_types::St), ast::Stmt)| entered(once_job(move || {
        let (en, s) = p0;
        let stmt = p1;
        prism_rtl::Turn::More(Rc::new(PreBindStmt { env: en.clone(), st: s.clone(), s: stmt.clone() }))
    }))) as Rc<dyn Fn(((check_expr::Env, check_types::St), ast::Stmt)) -> Rc<dyn prism_rtl::Job<(check_expr::Env, check_types::St)>>>));
    let n = len(&b.stmts);
    let (env3, st3, res_opt) = run_to_end(fold_job(group_order(&b.stmts), (env2.clone(), st2.clone(), None), {
        let b = b.clone();
        let n = n.clone();
        Rc::new(move |(p0, p1): ((check_expr::Env, check_types::St, Option<check_types::Ty>), Nat)| {
            let b = b.clone();
            let n = n.clone();
            entered(once_job(move || {
                let (en, s, r_opt) = p0;
                let i = p1;
                {
                    let stmt = or(&index(&b.stmts, &i), &dummy_stmt2());
                    call_then(start_widget_stmt(en.clone(), s.clone(), stmt.clone(), &(&i + &Nat::from(1u32)) == &n), move |widget_stmt_4497: (check_expr::Env, check_types::St, Option<check_types::Ty>)| {
                        let (en2, s2, r2_opt) = widget_stmt_4497;
                        match &r2_opt {
                            Some(t) => prism_rtl::Turn::Finished((en2.clone(), s2.clone(), Some(t.clone()))),
                            None => prism_rtl::Turn::Finished((en2.clone(), s2.clone(), r_opt.clone())),
                        }
                    })
                }
            }))
        }) as Rc<dyn Fn(((check_expr::Env, check_types::St, Option<check_types::Ty>), Nat)) -> Rc<dyn prism_rtl::Job<(check_expr::Env, check_types::St, Option<check_types::Ty>)>>>
    }));
    let st4 = check_passes::block_prompt_cycles(&env3, &st3, b);
    let st5 = if st4.recording {
        check_types::note_group(&st4, &b.span, &Text::from("widget"), &dep_order(&b.stmts))
    } else {
        st4.clone()
    };
    (or(&res_opt, &check_types::t_unit()), st5.clone())
}

/// The step machine of `InferWidgetBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferWidgetBlock: unbounded fn Env, St, Block -> ((Ty, St))
/// ```
pub struct InferWidgetBlock {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub b: ast::Block,
}

impl prism_rtl::Job<(check_types::Ty, check_types::St)> for InferWidgetBlock {
    fn cycle(&self) -> prism_rtl::Turn<(check_types::Ty, check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let b = &self.b;
        let b = b.clone();
        let env = env.clone();
        let st = st.clone();
        call_then(start_block_row(env.clone(), st.clone(), b.stmts.clone()), move |block_row_4178: (check_expr::Env, check_types::St)| {
            let (env1, st1) = block_row_4178;
            call_value(fold_job(b.stmts.clone(), (env1.clone(), st1.clone()), Rc::new(move |(p0, p1): ((check_expr::Env, check_types::St), ast::Stmt)| entered(once_job(move || {
                let (en, s) = p0;
                let stmt = p1;
                prism_rtl::Turn::More(Rc::new(PreBindStmt { env: en.clone(), st: s.clone(), s: stmt.clone() }))
            }))) as Rc<dyn Fn(((check_expr::Env, check_types::St), ast::Stmt)) -> Rc<dyn prism_rtl::Job<(check_expr::Env, check_types::St)>>>), move |fold_4228: (check_expr::Env, check_types::St)| {
                let (env2, st2) = fold_4228;
                let n = len(&b.stmts);
                call_value(fold_job(group_order(&b.stmts), (env2.clone(), st2.clone(), None), {
                    let b = b.clone();
                    let n = n.clone();
                    Rc::new(move |(p0, p1): ((check_expr::Env, check_types::St, Option<check_types::Ty>), Nat)| {
                        let b = b.clone();
                        let n = n.clone();
                        entered(once_job(move || {
                            let (en, s, r_opt) = p0;
                            let i = p1;
                            {
                                let stmt = or(&index(&b.stmts, &i), &dummy_stmt2());
                                call_then(start_widget_stmt(en.clone(), s.clone(), stmt.clone(), &(&i + &Nat::from(1u32)) == &n), move |widget_stmt_4497: (check_expr::Env, check_types::St, Option<check_types::Ty>)| {
                                    let (en2, s2, r2_opt) = widget_stmt_4497;
                                    match &r2_opt {
                                        Some(t) => prism_rtl::Turn::Finished((en2.clone(), s2.clone(), Some(t.clone()))),
                                        None => prism_rtl::Turn::Finished((en2.clone(), s2.clone(), r_opt.clone())),
                                    }
                                })
                            }
                        }))
                    }) as Rc<dyn Fn(((check_expr::Env, check_types::St, Option<check_types::Ty>), Nat)) -> Rc<dyn prism_rtl::Job<(check_expr::Env, check_types::St, Option<check_types::Ty>)>>>
                }), move |fold_4354: (check_expr::Env, check_types::St, Option<check_types::Ty>)| {
                    let (env3, st3, res_opt) = fold_4354;
                    call_then(check_passes::start_block_prompt_cycles(env3.clone(), st3.clone(), b.clone()), move |block_prompt_cycles_4632: check_types::St| {
                        let st4 = block_prompt_cycles_4632;
                        let st5 = if st4.recording {
                            check_types::note_group(&st4, &b.span, &Text::from("widget"), &dep_order(&b.stmts))
                        } else {
                            st4.clone()
                        };
                        prism_rtl::Turn::Finished((or(&res_opt, &check_types::t_unit()), st5.clone()))
                    })
                })
            })
        })
    }
}

/// `Start InferWidgetBlock, x`: what the function value is when passed to `@Run`.
pub fn start_infer_widget_block(env: check_expr::Env, st: check_types::St, b: ast::Block) -> Rc<dyn prism_rtl::Job<(check_types::Ty, check_types::St)>> {
    Rc::new(InferWidgetBlock { env, st, b })
}

/// ```prism
/// let dummyStmt2
/// ```
pub fn dummy_stmt2() -> ast::Stmt {
    ast::Stmt { kind: ast::StmtKind::SExpr(ast::Expr { kind: Rc::new(ast::ExprKind::EError), span: ast::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }), span: ast::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// BlockRow: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub fn block_row(env: &check_expr::Env, st: &check_types::St, stmts: &Array<ast::Stmt>) -> (check_expr::Env, check_types::St) {
    run_to_end(fold_job(check_errors::range0(&len(stmts)), (env.clone(), st.clone()), {
        let stmts = stmts.clone();
        Rc::new(move |(p0, p1): ((check_expr::Env, check_types::St), Nat)| {
            let stmts = stmts.clone();
            entered(once_job(move || {
                let (en, s) = p0;
                let i = p1;
                match index(&stmts, &i) {
                    Some(stmt) => match &stmt.kind {
                        ast::StmtKind::SEmit(row_decl) => if &i > &Nat::from(0u32) {
                            prism_rtl::Turn::Finished((en.clone(), check_types::err_fix(&s, &Text::from("emit-element"), &stmt.span, &Text::from("`emit` comes first in its block"), &Text::from("move this line to the top of the block"))))
                        } else {
                            {
                                let row_decl = row_decl.clone();
                                call_then(check_env::start_conv_row(check_expr::env_cx(&en), s.clone(), row_as_type(&row_decl)), move |conv_row_5394: (check_types::Rw, check_types::St)| {
                                    let (rw, s2) = conv_row_5394;
                                    let en2 = {
                                        let mut this: check_expr::Env = en.clone();
                                        this.scope = resolve_scope_row(&en, &rw);
                                        this
                                    };
                                    prism_rtl::Turn::Finished((en2.clone(), s2.clone()))
                                })
                            }
                        },
                        _ => prism_rtl::Turn::Finished((en.clone(), s.clone())),
                    },
                    None => prism_rtl::Turn::Finished((en.clone(), s.clone())),
                }
            }))
        }) as Rc<dyn Fn(((check_expr::Env, check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(check_expr::Env, check_types::St)>>>
    }))
}

/// The step machine of `BlockRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockRow: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub struct BlockRow {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub stmts: Array<ast::Stmt>,
}

impl prism_rtl::Job<(check_expr::Env, check_types::St)> for BlockRow {
    fn cycle(&self) -> prism_rtl::Turn<(check_expr::Env, check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let stmts = &self.stmts;
        fold_job(check_errors::range0(&len(stmts)), (env.clone(), st.clone()), {
            let stmts = stmts.clone();
            Rc::new(move |(p0, p1): ((check_expr::Env, check_types::St), Nat)| {
                let stmts = stmts.clone();
                entered(once_job(move || {
                    let (en, s) = p0;
                    let i = p1;
                    match index(&stmts, &i) {
                        Some(stmt) => match &stmt.kind {
                            ast::StmtKind::SEmit(row_decl) => if &i > &Nat::from(0u32) {
                                prism_rtl::Turn::Finished((en.clone(), check_types::err_fix(&s, &Text::from("emit-element"), &stmt.span, &Text::from("`emit` comes first in its block"), &Text::from("move this line to the top of the block"))))
                            } else {
                                {
                                    let row_decl = row_decl.clone();
                                    call_then(check_env::start_conv_row(check_expr::env_cx(&en), s.clone(), row_as_type(&row_decl)), move |conv_row_5394: (check_types::Rw, check_types::St)| {
                                        let (rw, s2) = conv_row_5394;
                                        let en2 = {
                                            let mut this: check_expr::Env = en.clone();
                                            this.scope = resolve_scope_row(&en, &rw);
                                            this
                                        };
                                        prism_rtl::Turn::Finished((en2.clone(), s2.clone()))
                                    })
                                }
                            },
                            _ => prism_rtl::Turn::Finished((en.clone(), s.clone())),
                        },
                        None => prism_rtl::Turn::Finished((en.clone(), s.clone())),
                    }
                }))
            }) as Rc<dyn Fn(((check_expr::Env, check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(check_expr::Env, check_types::St)>>>
        }).cycle()
    }
}

/// `Start BlockRow, x`: what the function value is when passed to `@Run`.
pub fn start_block_row(env: check_expr::Env, st: check_types::St, stmts: Array<ast::Stmt>) -> Rc<dyn prism_rtl::Job<(check_expr::Env, check_types::St)>> {
    Rc::new(BlockRow { env, st, stmts })
}

/// ```prism
/// RowAsType: fn Row -> Type
/// ```
pub fn row_as_type(row_decl: &ast::Row_) -> ast::Type {
    ast::Type { kind: Rc::new(ast::TypeKind::TRowUnion(each(&row_decl.terms, &row_term_type))), span: row_decl.span.clone() }
}

/// ```prism
/// RowTermType: fn RowTerm -> Type
/// ```
pub fn row_term_type(row_term0: &ast::RowTerm) -> ast::Type {
    match row_term0 {
        ast::RowTerm::RFamily(q) => ast::Type { kind: Rc::new(ast::TypeKind::TFamily(q.clone())), span: q.span.clone() },
        ast::RowTerm::RVar(v_) => ast::Type { kind: Rc::new(ast::TypeKind::TName(ast::SName { sigils: Text::from(""), path_: Array::from(vec![v_.name.clone()]), span: v_.span.clone() }, Array::new())), span: v_.span.clone() },
        ast::RowTerm::RType(t) => t.clone(),
    }
}

/// ```prism
/// ResolveScopeRow: fn Env, Rw -> Rw
/// ```
pub fn resolve_scope_row(env: &check_expr::Env, rw: &check_types::Rw) -> check_types::Rw {
    match &rw.tail {
        check_types::Tail::TlQ(v_) => check_types::Rw { fams: rw.fams.clone(), minus: rw.minus.clone(), tail: env.scope.tail.clone() },
        _ => rw.clone(),
    }
}

/// ```prism
/// PreBindStmt: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub fn pre_bind_stmt(env: &check_expr::Env, st: &check_types::St, s: &ast::Stmt) -> (check_expr::Env, check_types::St) {
    match &s.kind {
        ast::StmtKind::SBind(p_, _, _) => pre_bind_pattern(env, st, p_),
        ast::StmtKind::SLet(_, _, _) => check_expr::pre_bind(env, st, s),
        ast::StmtKind::SFn(_) => check_expr::pre_bind(env, st, s),
        ast::StmtKind::SSignature(_) => check_expr::pre_bind(env, st, s),
        ast::StmtKind::SWidget(w) => {
            let (v_, st2) = check_types::fresh_var(st, &false, &Text::from(""));
            (check_expr::with_local(env, &check_env::sname_key(&w.name), &check_types::mono(&check_types::Ty::TyAt(Rc::new(v_.clone()), env.scope.clone()))), st2.clone())
        },
        _ => (env.clone(), st.clone()),
    }
}

/// The step machine of `PreBindStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBindStmt: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub struct PreBindStmt {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub s: ast::Stmt,
}

impl prism_rtl::Job<(check_expr::Env, check_types::St)> for PreBindStmt {
    fn cycle(&self) -> prism_rtl::Turn<(check_expr::Env, check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let s = &self.s;
        match &s.kind {
            ast::StmtKind::SBind(p_, _, _) => prism_rtl::Turn::More(Rc::new(PreBindPattern { env: env.clone(), st: st.clone(), p_: p_.clone() })),
            ast::StmtKind::SLet(_, _, _) => prism_rtl::Turn::More(Rc::new(check_expr::PreBind { env: env.clone(), st: st.clone(), s: s.clone() })),
            ast::StmtKind::SFn(_) => prism_rtl::Turn::More(Rc::new(check_expr::PreBind { env: env.clone(), st: st.clone(), s: s.clone() })),
            ast::StmtKind::SSignature(_) => prism_rtl::Turn::More(Rc::new(check_expr::PreBind { env: env.clone(), st: st.clone(), s: s.clone() })),
            ast::StmtKind::SWidget(w) => {
                let (v_, st2) = check_types::fresh_var(st, &false, &Text::from(""));
                prism_rtl::Turn::Finished((check_expr::with_local(env, &check_env::sname_key(&w.name), &check_types::mono(&check_types::Ty::TyAt(Rc::new(v_.clone()), env.scope.clone()))), st2.clone()))
            },
            _ => prism_rtl::Turn::Finished((env.clone(), st.clone())),
        }
    }
}

/// `Start PreBindStmt, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind_stmt(env: check_expr::Env, st: check_types::St, s: ast::Stmt) -> Rc<dyn prism_rtl::Job<(check_expr::Env, check_types::St)>> {
    Rc::new(PreBindStmt { env, st, s })
}

/// ```prism
/// PreBindPattern: unbounded fn Env, St, Pattern -> ((Env, St))
/// ```
pub fn pre_bind_pattern(env: &check_expr::Env, st: &check_types::St, p_: &ast::Pattern_) -> (check_expr::Env, check_types::St) {
    fold(&check_env::pattern_binders(p_), &(env.clone(), st.clone()), &(|(en, s): &(check_expr::Env, check_types::St), (name, at): &(Text, ast::Range)| {
        let (v_, s1) = check_types::fresh_var(s, &true, name);
        let s2 = check_types::at_binder(&s1, &v_, at);
        let (rw, s3) = check_types::fresh_row(&s2, &Array::new());
        let t = check_types::with_marks(&check_expr::type_marks(&check_types::marks_of(name)), &v_, &rw);
        let en2 = {
            let mut this: check_expr::Env = check_expr::with_local(en, name, &check_types::mono(&t));
            this.pending = check_types::add_text(&this.pending, name);
            this
        };
        (en2.clone(), s3.clone())
    }))
}

/// The step machine of `PreBindPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBindPattern: unbounded fn Env, St, Pattern -> ((Env, St))
/// ```
pub struct PreBindPattern {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub p_: ast::Pattern_,
}

impl prism_rtl::Job<(check_expr::Env, check_types::St)> for PreBindPattern {
    fn cycle(&self) -> prism_rtl::Turn<(check_expr::Env, check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let p_ = &self.p_;
        let env = env.clone();
        let p_ = p_.clone();
        let st = st.clone();
        call_then(check_env::start_pattern_binders(p_.clone()), move |pattern_binders_6915: Array<(Text, ast::Range)>| prism_rtl::Turn::Finished(fold(&pattern_binders_6915, &(env.clone(), st.clone()), &(|(en, s): &(check_expr::Env, check_types::St), (name, at): &(Text, ast::Range)| {
            let (v_, s1) = check_types::fresh_var(s, &true, name);
            let s2 = check_types::at_binder(&s1, &v_, at);
            let (rw, s3) = check_types::fresh_row(&s2, &Array::new());
            let t = check_types::with_marks(&check_expr::type_marks(&check_types::marks_of(name)), &v_, &rw);
            let en2 = {
                let mut this: check_expr::Env = check_expr::with_local(en, name, &check_types::mono(&t));
                this.pending = check_types::add_text(&this.pending, name);
                this
            };
            (en2.clone(), s3.clone())
        }))))
    }
}

/// `Start PreBindPattern, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind_pattern(env: check_expr::Env, st: check_types::St, p_: ast::Pattern_) -> Rc<dyn prism_rtl::Job<(check_expr::Env, check_types::St)>> {
    Rc::new(PreBindPattern { env, st, p_ })
}

/// ```prism
/// WidgetStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St, ?Ty))
/// ```
pub fn widget_stmt(env: &check_expr::Env, st: &check_types::St, s: &ast::Stmt, last: &bool) -> (check_expr::Env, check_types::St, Option<check_types::Ty>) {
    match &s.kind {
        ast::StmtKind::SEmit(_) => (env.clone(), st.clone(), if *last { Some(check_types::t_unit()) } else { None }),
        ast::StmtKind::SBind(p_, e, None) => {
            let st2 = bind_stmt(env, st, p_, e, &s.span);
            (env.clone(), st2.clone(), if *last { Some(check_types::t_unit()) } else { None })
        },
        ast::StmtKind::SBind(p_, init, Some(step_)) => {
            let st2 = hold_stmt(env, st, p_, init, step_, &s.span);
            (env.clone(), st2.clone(), if *last { Some(check_types::t_unit()) } else { None })
        },
        ast::StmtKind::SIgnore(e) => {
            let st2 = ignore_stmt(env, st, e, &s.span);
            (env.clone(), st2.clone(), if *last { Some(check_types::t_unit()) } else { None })
        },
        ast::StmtKind::SLet(p_, ty_opt, e) => {
            let (env2, st2) = check_expr::check_let(env, st, p_, ty_opt, e, &s.span);
            (env2.clone(), st2.clone(), if *last { Some(check_types::t_unit()) } else { None })
        },
        ast::StmtKind::SFn(f) => {
            let (env2, st2) = check_expr::check_local_fn(env, st, f, &s.span);
            (env2.clone(), st2.clone(), if *last { Some(check_types::t_unit()) } else { None })
        },
        ast::StmtKind::SSignature(_) => (env.clone(), st.clone(), if *last { Some(check_types::t_unit()) } else { None }),
        ast::StmtKind::SWidget(w) => {
            let (t, st2) = infer_widget_block(env, st, &w.body);
            let st3 = match get(&env.locals, &check_env::sname_key(&w.name)) {
                Some(sc) => check_types::unify(&st2, &sc.ty, &check_types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()), &w.span),
                None => st2.clone(),
            };
            (env.clone(), st3.clone(), if *last { Some(check_types::t_unit()) } else { None })
        },
        ast::StmtKind::SExpr(e) => {
            let (t, st2) = bare_line(env, st, e, last);
            if *last {
                (env.clone(), st2.clone(), Some(t.clone()))
            } else {
                (env.clone(), st2.clone(), None)
            }
        },
        _ => (env.clone(), check_types::err(st, &Text::from("mismatch"), &s.span, &Text::from("this statement belongs in a `given:` or `update` block")), if *last { Some(check_types::t_unit()) } else { None }),
    }
}

/// The step machine of `WidgetStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WidgetStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St, ?Ty))
/// ```
pub struct WidgetStmt {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub s: ast::Stmt,
    pub last: bool,
}

impl prism_rtl::Job<(check_expr::Env, check_types::St, Option<check_types::Ty>)> for WidgetStmt {
    fn cycle(&self) -> prism_rtl::Turn<(check_expr::Env, check_types::St, Option<check_types::Ty>)> {
        let env = &self.env;
        let st = &self.st;
        let s = &self.s;
        let last = &self.last;
        match &s.kind {
            ast::StmtKind::SEmit(_) => prism_rtl::Turn::Finished((env.clone(), st.clone(), if *last { Some(check_types::t_unit()) } else { None })),
            ast::StmtKind::SBind(p_, e, None) => {
                let e = e.clone();
                let env = env.clone();
                let last = *last;
                let p_ = p_.clone();
                let s = s.clone();
                let st = st.clone();
                call_then(start_bind_stmt(env.clone(), st.clone(), p_.clone(), e.clone(), s.span.clone()), move |bind_stmt_7540: check_types::St| {
                    let st2 = bind_stmt_7540;
                    prism_rtl::Turn::Finished((env.clone(), st2.clone(), if last { Some(check_types::t_unit()) } else { None }))
                })
            },
            ast::StmtKind::SBind(p_, init, Some(step_)) => {
                let env = env.clone();
                let init = init.clone();
                let last = *last;
                let p_ = p_.clone();
                let s = s.clone();
                let st = st.clone();
                let step_ = step_.clone();
                call_then(start_hold_stmt(env.clone(), st.clone(), p_.clone(), init.clone(), step_.clone(), s.span.clone()), move |hold_stmt_7667: check_types::St| {
                    let st2 = hold_stmt_7667;
                    prism_rtl::Turn::Finished((env.clone(), st2.clone(), if last { Some(check_types::t_unit()) } else { None }))
                })
            },
            ast::StmtKind::SIgnore(e) => {
                let e = e.clone();
                let env = env.clone();
                let last = *last;
                let s = s.clone();
                let st = st.clone();
                call_then(start_ignore_stmt(env.clone(), st.clone(), e.clone(), s.span.clone()), move |ignore_stmt_7789: check_types::St| {
                    let st2 = ignore_stmt_7789;
                    prism_rtl::Turn::Finished((env.clone(), st2.clone(), if last { Some(check_types::t_unit()) } else { None }))
                })
            },
            ast::StmtKind::SLet(p_, ty_opt, e) => {
                let ty_opt = ty_opt.clone();
                let e = e.clone();
                let env = env.clone();
                let last = *last;
                let p_ = p_.clone();
                let s = s.clone();
                let st = st.clone();
                call_then(check_expr::start_check_let(env.clone(), st.clone(), p_.clone(), ty_opt.clone(), e.clone(), s.span.clone()), move |check_let_7916: (check_expr::Env, check_types::St)| {
                    let (env2, st2) = check_let_7916;
                    prism_rtl::Turn::Finished((env2.clone(), st2.clone(), if last { Some(check_types::t_unit()) } else { None }))
                })
            },
            ast::StmtKind::SFn(f) => {
                let env = env.clone();
                let f = f.clone();
                let last = *last;
                let s = s.clone();
                let st = st.clone();
                call_then(check_expr::start_check_local_fn(env.clone(), st.clone(), f.clone(), s.span.clone()), move |check_local_fn_8041: (check_expr::Env, check_types::St)| {
                    let (env2, st2) = check_local_fn_8041;
                    prism_rtl::Turn::Finished((env2.clone(), st2.clone(), if last { Some(check_types::t_unit()) } else { None }))
                })
            },
            ast::StmtKind::SSignature(_) => prism_rtl::Turn::Finished((env.clone(), st.clone(), if *last { Some(check_types::t_unit()) } else { None })),
            ast::StmtKind::SWidget(w) => {
                let env = env.clone();
                let last = *last;
                let st = st.clone();
                let w = w.clone();
                call_then(start_infer_widget_block(env.clone(), st.clone(), w.body.clone()), move |infer_widget_block_8226: (check_types::Ty, check_types::St)| {
                    let (t, st2) = infer_widget_block_8226;
                    let st3 = match get(&env.locals, &check_env::sname_key(&w.name)) {
                        Some(sc) => check_types::unify(&st2, &sc.ty, &check_types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()), &w.span),
                        None => st2.clone(),
                    };
                    prism_rtl::Turn::Finished((env.clone(), st3.clone(), if last { Some(check_types::t_unit()) } else { None }))
                })
            },
            ast::StmtKind::SExpr(e) => {
                let e = e.clone();
                let env = env.clone();
                let last = *last;
                let st = st.clone();
                call_then(start_bare_line(env.clone(), st.clone(), e.clone(), last), move |bare_line_8484: (check_types::Ty, check_types::St)| {
                    let (t, st2) = bare_line_8484;
                    if last {
                        prism_rtl::Turn::Finished((env.clone(), st2.clone(), Some(t.clone())))
                    } else {
                        prism_rtl::Turn::Finished((env.clone(), st2.clone(), None))
                    }
                })
            },
            _ => prism_rtl::Turn::Finished((env.clone(), check_types::err(st, &Text::from("mismatch"), &s.span, &Text::from("this statement belongs in a `given:` or `update` block")), if *last { Some(check_types::t_unit()) } else { None })),
        }
    }
}

/// `Start WidgetStmt, x`: what the function value is when passed to `@Run`.
pub fn start_widget_stmt(env: check_expr::Env, st: check_types::St, s: ast::Stmt, last: bool) -> Rc<dyn prism_rtl::Job<(check_expr::Env, check_types::St, Option<check_types::Ty>)>> {
    Rc::new(WidgetStmt { env, st, s, last })
}

/// ```prism
/// BindStmt: unbounded fn Env, St, Pattern, Expr, Range -> St
/// ```
pub fn bind_stmt(env: &check_expr::Env, st: &check_types::St, p_: &ast::Pattern_, e: &ast::Expr, span: &ast::Range) -> check_types::St {
    let (t, st1) = check_expr::infer(env, st, e);
    let (out, st2) = if is_builder(e) {
        (t.clone(), st1.clone())
    } else {
        bind_output(env, &st1, &t, &e.span)
    };
    let (_, st3) = check_expr::bind_pattern(env, &st2, p_, &out, &false);
    st3.clone()
}

/// The step machine of `BindStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindStmt: unbounded fn Env, St, Pattern, Expr, Range -> St
/// ```
pub struct BindStmt {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub p_: ast::Pattern_,
    pub e: ast::Expr,
    pub span: ast::Range,
}

impl prism_rtl::Job<check_types::St> for BindStmt {
    fn cycle(&self) -> prism_rtl::Turn<check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let p_ = &self.p_;
        let e = &self.e;
        let span = &self.span;
        let e = e.clone();
        let env = env.clone();
        let p_ = p_.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(check_expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_9099: (check_types::Ty, check_types::St)| {
            let (t, st1) = infer_9099;
            let (out, st2) = if is_builder(&e) {
                (t.clone(), st1.clone())
            } else {
                bind_output(&env, &st1, &t, &e.span)
            };
            call_then(check_expr::start_bind_pattern(env.clone(), st2.clone(), p_.clone(), out.clone(), false), move |bind_pattern_9229: (check_expr::Env, check_types::St)| {
                let (_, st3) = bind_pattern_9229;
                prism_rtl::Turn::Finished(st3.clone())
            })
        })
    }
}

/// `Start BindStmt, x`: what the function value is when passed to `@Run`.
pub fn start_bind_stmt(env: check_expr::Env, st: check_types::St, p_: ast::Pattern_, e: ast::Expr, span: ast::Range) -> Rc<dyn prism_rtl::Job<check_types::St>> {
    Rc::new(BindStmt { env, st, p_, e, span })
}

/// ```prism
/// IsBuilder: fn Expr -> Bool
/// ```
pub fn is_builder(e: &ast::Expr) -> bool {
    match &*e.kind {
        ast::ExprKind::ERebuild(_, _) => true,
        ast::ExprKind::EFor(_, _, _) => true,
        ast::ExprKind::EGroup(x) => is_builder(&**x),
        _ => false,
    }
}

/// ```prism
/// BindOutput: unbounded fn Env, St, Ty, Range -> ((Ty, St))
/// ```
pub fn bind_output(env: &check_expr::Env, st: &check_types::St, t: &check_types::Ty, span: &ast::Range) -> (check_types::Ty, check_types::St) {
    match check_types::walk(st, t) {
        check_types::Ty::TyAt(inner, rw) => ((*inner).clone(), add_incl(st, &rw, &env.scope, span, &Text::from("child"))),
        check_types::Ty::TyElem(rw, o) => ((*o).clone(), add_incl(st, &rw, &env.scope, span, &Text::from("element"))),
        check_types::Ty::TySig(s, inner) => match check_types::walk(st, &*inner) {
            check_types::Ty::TyAt(_, _) => (check_types::Ty::TyErr, check_types::err_fix(st, &Text::from("bind-dynamic"), span, &Text::from(format!("binding a `{}`; say what happens to the old widgets with `rebuild`", &check_types::show_ty(st, t))), &Text::from("write `rebuild` over the dynamic, with the blueprint inside"))),
            check_types::Ty::TyElem(_, _) => (check_types::Ty::TyErr, check_types::err_fix(st, &Text::from("bind-dynamic"), span, &Text::from(format!("binding a `{}`, a {} of elements; say what happens to the old element with `rebuild`", &check_types::show_ty(st, t), &(if &s == &Text::from("$") { Text::from("dynamic") } else { Text::from("event") }))), &Text::from("write `rebuild` over the dynamic field's value, with the element inside"))),
            _ => (check_types::Ty::TyErr, check_types::err(st, &Text::from("mismatch"), span, &Text::from(format!("`<-` binds a blueprint or an element; this is `{}`", &check_types::show_ty(st, t))))),
        },
        check_types::Ty::TyFlex(_) => {
            let (v_, st2) = check_types::fresh_var(st, &false, &Text::from(""));
            (v_.clone(), check_types::unify(&st2, t, &check_types::Ty::TyAt(Rc::new(v_.clone()), env.scope.clone()), span))
        },
        check_types::Ty::TyErr => (check_types::Ty::TyErr, st.clone()),
        other => (check_types::Ty::TyErr, check_types::err(st, &Text::from("mismatch"), span, &Text::from(format!("`<-` binds a blueprint or an element; this is `{}`", &check_types::show_ty(st, &other))))),
    }
}

/// The step machine of `BindOutput`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindOutput: unbounded fn Env, St, Ty, Range -> ((Ty, St))
/// ```
pub struct BindOutput {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub t: check_types::Ty,
    pub span: ast::Range,
}

impl prism_rtl::Job<(check_types::Ty, check_types::St)> for BindOutput {
    fn cycle(&self) -> prism_rtl::Turn<(check_types::Ty, check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let t = &self.t;
        let span = &self.span;
        let env = env.clone();
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(check_types::start_walk(st.clone(), t.clone()), move |walk_9624: check_types::Ty| match walk_9624 {
            check_types::Ty::TyAt(inner, rw) => prism_rtl::Turn::Finished(((*inner).clone(), add_incl(&st, &rw, &env.scope, &span, &Text::from("child")))),
            check_types::Ty::TyElem(rw, o) => prism_rtl::Turn::Finished(((*o).clone(), add_incl(&st, &rw, &env.scope, &span, &Text::from("element")))),
            check_types::Ty::TySig(s, inner) => call_then(check_types::start_walk(st.clone(), (*inner).clone()), move |walk_9814: check_types::Ty| match walk_9814 {
                check_types::Ty::TyAt(_, _) => call_then(check_types::start_show_ty(st.clone(), t.clone()), move |show_ty_9919: Text| prism_rtl::Turn::Finished((check_types::Ty::TyErr, check_types::err_fix(&st, &Text::from("bind-dynamic"), &span, &Text::from(format!("binding a `{}`; say what happens to the old widgets with `rebuild`", &show_ty_9919)), &Text::from("write `rebuild` over the dynamic, with the blueprint inside"))))),
                check_types::Ty::TyElem(_, _) => call_then(check_types::start_show_ty(st.clone(), t.clone()), move |show_ty_10144: Text| prism_rtl::Turn::Finished((check_types::Ty::TyErr, check_types::err_fix(&st, &Text::from("bind-dynamic"), &span, &Text::from(format!("binding a `{}`, a {} of elements; say what happens to the old element with `rebuild`", &show_ty_10144, &(if &s == &Text::from("$") { Text::from("dynamic") } else { Text::from("event") }))), &Text::from("write `rebuild` over the dynamic field's value, with the element inside"))))),
                _ => call_then(check_types::start_show_ty(st.clone(), t.clone()), move |show_ty_10452: Text| prism_rtl::Turn::Finished((check_types::Ty::TyErr, check_types::err(&st, &Text::from("mismatch"), &span, &Text::from(format!("`<-` binds a blueprint or an element; this is `{}`", &show_ty_10452)))))),
            }),
            check_types::Ty::TyFlex(_) => {
                let (v_, st2) = check_types::fresh_var(&st, &false, &Text::from(""));
                call_then(check_types::start_unify(st2.clone(), t.clone(), check_types::Ty::TyAt(Rc::new(v_.clone()), env.scope.clone()), span.clone()), move |unify_10552: check_types::St| prism_rtl::Turn::Finished((v_.clone(), unify_10552)))
            },
            check_types::Ty::TyErr => prism_rtl::Turn::Finished((check_types::Ty::TyErr, st.clone())),
            other => call_then(check_types::start_show_ty(st.clone(), other.clone()), move |show_ty_10716: Text| prism_rtl::Turn::Finished((check_types::Ty::TyErr, check_types::err(&st, &Text::from("mismatch"), &span, &Text::from(format!("`<-` binds a blueprint or an element; this is `{}`", &show_ty_10716)))))),
        })
    }
}

/// `Start BindOutput, x`: what the function value is when passed to `@Run`.
pub fn start_bind_output(env: check_expr::Env, st: check_types::St, t: check_types::Ty, span: ast::Range) -> Rc<dyn prism_rtl::Job<(check_types::Ty, check_types::St)>> {
    Rc::new(BindOutput { env, st, t, span })
}

/// ```prism
/// AddIncl: fn St, Rw, Rw, Range, Text -> St
/// ```
pub fn add_incl(st: &check_types::St, sub: &check_types::Rw, sup: &check_types::Rw, span: &ast::Range, what: &Text) -> check_types::St {
    let mut this: check_types::St = st.clone();
    this.incls = push(&this.incls, &check_types::Incl { sub: sub.clone(), sup: sup.clone(), file: this.file.clone(), span: span.clone(), what: what.clone(), forward: false });
    this
}

/// ```prism
/// HoldStmt: unbounded fn Env, St, Pattern, Expr, Expr, Range -> St
/// ```
pub fn hold_stmt(env: &check_expr::Env, st: &check_types::St, p_: &ast::Pattern_, init: &ast::Expr, step_: &ast::Expr, span: &ast::Range) -> check_types::St {
    let (v_, st1) = check_types::fresh_var(st, &false, &Text::from(""));
    let held = check_types::Ty::TySig(Text::from("$"), Rc::new(v_.clone()));
    let (_, st2) = check_expr::bind_pattern(env, &st1, p_, &held, &false);
    let st3 = check_expr::check(env, &st2, init, &v_);
    let (step_ty, st4) = check_expr::infer(env, &st3, step_);
    if (&check_types::head_sigil(&st4, &step_ty) == &Text::from("!")) || (&step_ty == &check_types::Ty::TyErr) {
        check_types::unify(&st4, &check_types::Ty::TySig(Text::from("!"), Rc::new(v_.clone())), &step_ty, &step_.span)
    } else {
        check_types::err_fix(&st4, &Text::from("mismatch"), &step_.span, &Text::from(format!("a hold's step is an event; this is `{}`", &check_types::show_ty(&st4, &step_ty))), &Text::from("fire it with an event: `... on !e`"))
    }
}

/// The step machine of `HoldStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HoldStmt: unbounded fn Env, St, Pattern, Expr, Expr, Range -> St
/// ```
pub struct HoldStmt {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub p_: ast::Pattern_,
    pub init: ast::Expr,
    pub step_: ast::Expr,
    pub span: ast::Range,
}

impl prism_rtl::Job<check_types::St> for HoldStmt {
    fn cycle(&self) -> prism_rtl::Turn<check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let p_ = &self.p_;
        let init = &self.init;
        let step_ = &self.step_;
        let span = &self.span;
        let (v_, st1) = check_types::fresh_var(st, &false, &Text::from(""));
        let held = check_types::Ty::TySig(Text::from("$"), Rc::new(v_.clone()));
        let env = env.clone();
        let init = init.clone();
        let p_ = p_.clone();
        let span = span.clone();
        let step_ = step_.clone();
        call_then(check_expr::start_bind_pattern(env.clone(), st1.clone(), p_.clone(), held.clone(), false), move |bind_pattern_11259: (check_expr::Env, check_types::St)| {
            let (_, st2) = bind_pattern_11259;
            call_then(check_expr::start_check(env.clone(), st2.clone(), init.clone(), v_.clone()), move |check_11310: check_types::St| {
                let st3 = check_11310;
                call_then(check_expr::start_infer(env.clone(), st3.clone(), step_.clone()), move |infer_11360: (check_types::Ty, check_types::St)| {
                    let (step_ty, st4) = infer_11360;
                    call_then(check_types::start_head_sigil(st4.clone(), step_ty.clone()), move |head_sigil_11389: Text| if (&head_sigil_11389 == &Text::from("!")) || (&step_ty == &check_types::Ty::TyErr) {
                        prism_rtl::Turn::More(Rc::new(check_types::Unify { st: st4.clone(), expected: check_types::Ty::TySig(Text::from("!"), Rc::new(v_.clone())), found: step_ty.clone(), span: step_.span.clone() }))
                    } else {
                        call_then(check_types::start_show_ty(st4.clone(), step_ty.clone()), move |show_ty_11567: Text| prism_rtl::Turn::Finished(check_types::err_fix(&st4, &Text::from("mismatch"), &step_.span, &Text::from(format!("a hold's step is an event; this is `{}`", &show_ty_11567)), &Text::from("fire it with an event: `... on !e`"))))
                    })
                })
            })
        })
    }
}

/// `Start HoldStmt, x`: what the function value is when passed to `@Run`.
pub fn start_hold_stmt(env: check_expr::Env, st: check_types::St, p_: ast::Pattern_, init: ast::Expr, step_: ast::Expr, span: ast::Range) -> Rc<dyn prism_rtl::Job<check_types::St>> {
    Rc::new(HoldStmt { env, st, p_, init, step_, span })
}

/// ```prism
/// IgnoreStmt: unbounded fn Env, St, Expr, Range -> St
/// ```
pub fn ignore_stmt(env: &check_expr::Env, st: &check_types::St, e: &ast::Expr, span: &ast::Range) -> check_types::St {
    let (t, st1) = check_expr::infer(env, st, e);
    match check_types::walk(&st1, &t) {
        check_types::Ty::TyAt(_, _) => {
            let (_, st2) = bind_output(env, &st1, &t, &e.span);
            st2.clone()
        },
        check_types::Ty::TyElem(_, _) => {
            let (_, st2) = bind_output(env, &st1, &t, &e.span);
            st2.clone()
        },
        check_types::Ty::TySig(_, inner) => match check_types::walk(&st1, &*inner) {
            check_types::Ty::TyAt(_, _) => {
                let (_, st2) = bind_output(env, &st1, &t, &e.span);
                st2.clone()
            },
            check_types::Ty::TyElem(_, _) => {
                let (_, st2) = bind_output(env, &st1, &t, &e.span);
                st2.clone()
            },
            _ => st1.clone(),
        },
        _ => st1.clone(),
    }
}

/// The step machine of `IgnoreStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IgnoreStmt: unbounded fn Env, St, Expr, Range -> St
/// ```
pub struct IgnoreStmt {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub e: ast::Expr,
    pub span: ast::Range,
}

impl prism_rtl::Job<check_types::St> for IgnoreStmt {
    fn cycle(&self) -> prism_rtl::Turn<check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let e = &self.e;
        let span = &self.span;
        let e = e.clone();
        let env = env.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(check_expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_11800: (check_types::Ty, check_types::St)| {
            let (t, st1) = infer_11800;
            call_then(check_types::start_walk(st1.clone(), t.clone()), move |walk_11827: check_types::Ty| match walk_11827 {
                check_types::Ty::TyAt(_, _) => call_then(start_bind_output(env.clone(), st1.clone(), t.clone(), e.span.clone()), move |bind_output_11903: (check_types::Ty, check_types::St)| {
                    let (_, st2) = bind_output_11903;
                    prism_rtl::Turn::Finished(st2.clone())
                }),
                check_types::Ty::TyElem(_, _) => call_then(start_bind_output(env.clone(), st1.clone(), t.clone(), e.span.clone()), move |bind_output_12015: (check_types::Ty, check_types::St)| {
                    let (_, st2) = bind_output_12015;
                    prism_rtl::Turn::Finished(st2.clone())
                }),
                check_types::Ty::TySig(_, inner) => call_then(check_types::start_walk(st1.clone(), (*inner).clone()), move |walk_12097: check_types::Ty| match walk_12097 {
                    check_types::Ty::TyAt(_, _) => call_then(start_bind_output(env.clone(), st1.clone(), t.clone(), e.span.clone()), move |bind_output_12185: (check_types::Ty, check_types::St)| {
                        let (_, st2) = bind_output_12185;
                        prism_rtl::Turn::Finished(st2.clone())
                    }),
                    check_types::Ty::TyElem(_, _) => call_then(start_bind_output(env.clone(), st1.clone(), t.clone(), e.span.clone()), move |bind_output_12309: (check_types::Ty, check_types::St)| {
                        let (_, st2) = bind_output_12309;
                        prism_rtl::Turn::Finished(st2.clone())
                    }),
                    _ => prism_rtl::Turn::Finished(st1.clone()),
                }),
                _ => prism_rtl::Turn::Finished(st1.clone()),
            })
        })
    }
}

/// `Start IgnoreStmt, x`: what the function value is when passed to `@Run`.
pub fn start_ignore_stmt(env: check_expr::Env, st: check_types::St, e: ast::Expr, span: ast::Range) -> Rc<dyn prism_rtl::Job<check_types::St>> {
    Rc::new(IgnoreStmt { env, st, e, span })
}

/// ```prism
/// BareLine: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
/// ```
pub fn bare_line(env: &check_expr::Env, st: &check_types::St, e: &ast::Expr, last: &bool) -> (check_types::Ty, check_types::St) {
    let (t, st2) = bare_line_kind(env, st, e, last);
    let shown = match &*e.kind {
        ast::ExprKind::EFreeSigil(m12768_0_0, _) if (m12768_0_0 == &Text::from("@")) => check_types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()),
        ast::ExprKind::EMatch(_, _) => check_types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()),
        ast::ExprKind::EIf(_, _, _) => check_types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()),
        _ => t.clone(),
        _ => unreachable!("no arm matched"),
    };
    match &*e.kind {
        ast::ExprKind::EFreeSigil(m12960_0_0, _) if (m12960_0_0 == &Text::from("@")) => (t.clone(), check_types::note_ty(&st2, &e.span, &shown)),
        ast::ExprKind::EMatch(_, _) => (t.clone(), check_types::note_ty(&st2, &e.span, &shown)),
        ast::ExprKind::EIf(_, _, _) => (t.clone(), check_types::note_ty(&st2, &e.span, &shown)),
        ast::ExprKind::EGroup(_) => (t.clone(), note_as_last(&st2, &e.span)),
        _ => (t.clone(), st2.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `BareLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BareLine: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
/// ```
pub struct BareLine {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub e: ast::Expr,
    pub last: bool,
}

impl prism_rtl::Job<(check_types::Ty, check_types::St)> for BareLine {
    fn cycle(&self) -> prism_rtl::Turn<(check_types::Ty, check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let e = &self.e;
        let last = &self.last;
        let e = e.clone();
        let env = env.clone();
        let last = *last;
        let st = st.clone();
        call_then(start_bare_line_kind(env.clone(), st.clone(), e.clone(), last), move |bare_line_kind_12722: (check_types::Ty, check_types::St)| {
            let (t, st2) = bare_line_kind_12722;
            let shown = match &*e.kind {
                ast::ExprKind::EFreeSigil(m12768_0_0, _) if (m12768_0_0 == &Text::from("@")) => check_types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()),
                ast::ExprKind::EMatch(_, _) => check_types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()),
                ast::ExprKind::EIf(_, _, _) => check_types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()),
                _ => t.clone(),
                _ => unreachable!("no arm matched"),
            };
            match &*e.kind {
                ast::ExprKind::EFreeSigil(m12960_0_0, _) if (m12960_0_0 == &Text::from("@")) => prism_rtl::Turn::Finished((t.clone(), check_types::note_ty(&st2, &e.span, &shown))),
                ast::ExprKind::EMatch(_, _) => prism_rtl::Turn::Finished((t.clone(), check_types::note_ty(&st2, &e.span, &shown))),
                ast::ExprKind::EIf(_, _, _) => prism_rtl::Turn::Finished((t.clone(), check_types::note_ty(&st2, &e.span, &shown))),
                ast::ExprKind::EGroup(_) => prism_rtl::Turn::Finished((t.clone(), note_as_last(&st2, &e.span))),
                _ => prism_rtl::Turn::Finished((t.clone(), st2.clone())),
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start BareLine, x`: what the function value is when passed to `@Run`.
pub fn start_bare_line(env: check_expr::Env, st: check_types::St, e: ast::Expr, last: bool) -> Rc<dyn prism_rtl::Job<(check_types::Ty, check_types::St)>> {
    Rc::new(BareLine { env, st, e, last })
}

/// ```prism
/// NoteAsLast: fn St, Range -> St
/// ```
pub fn note_as_last(st: &check_types::St, span: &ast::Range) -> check_types::St {
    match lexer::last(&st.typed.exprs) {
        Some(n) => check_types::note_ty(st, span, &n.ty),
        None => st.clone(),
    }
}

/// ```prism
/// BareLineKind: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
/// ```
pub fn bare_line_kind(env: &check_expr::Env, st: &check_types::St, e: &ast::Expr, last: &bool) -> (check_types::Ty, check_types::St) {
    match &*e.kind {
        ast::ExprKind::EMatch(scrut, arms) => building_match(env, st, &**scrut, arms, &e.span, last),
        ast::ExprKind::EIf(c, then_b, else_b_opt) => building_if(env, st, &**c, then_b, else_b_opt, &e.span, last),
        ast::ExprKind::EFreeSigil(m13542_2_0, x) if (m13542_2_0 == &Text::from("@")) => {
            let (t, st2) = check_expr::infer(env, st, &**x);
            if *last {
                (t.clone(), st2.clone())
            } else {
                (t.clone(), discarded(&st2, &t, &e.span))
            }
        },
        ast::ExprKind::EGroup(x) => bare_line(env, st, &**x, last),
        _ => {
            let (t, st1) = check_expr::infer(env, st, e);
            let (res, st2) = match check_types::walk(&st1, &t) {
                check_types::Ty::TyAt(_, _) => bind_output(env, &st1, &t, &e.span),
                check_types::Ty::TyElem(_, _) => bind_output(env, &st1, &t, &e.span),
                check_types::Ty::TyErr => (check_types::t_unit(), st1.clone()),
                other => if is_builder(e) {
                    (other.clone(), st1.clone())
                } else {
                    if &check_types::walk(&st1, &other) == &check_types::t_unit() {
                        (check_types::t_unit(), st1.clone())
                    } else {
                        (other.clone(), check_types::err_fix(&st1, &Text::from("mismatch"), &e.span, &Text::from(format!("a bare line emits an element or builds a blueprint; this is `{}`", &check_types::show_ty(&st1, &other))), &Text::from(format!("end the block on a value with `@ {}`", &check_expr::src_text(env, &e.span)))))
                    }
                },
            };
            if *last {
                (res.clone(), st2.clone())
            } else {
                (res.clone(), discarded(&st2, &res, &e.span))
            }
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `BareLineKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BareLineKind: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
/// ```
pub struct BareLineKind {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub e: ast::Expr,
    pub last: bool,
}

impl prism_rtl::Job<(check_types::Ty, check_types::St)> for BareLineKind {
    fn cycle(&self) -> prism_rtl::Turn<(check_types::Ty, check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let e = &self.e;
        let last = &self.last;
        match &*e.kind {
            ast::ExprKind::EMatch(scrut, arms) => prism_rtl::Turn::More(Rc::new(BuildingMatch { env: env.clone(), st: st.clone(), scrut: (**scrut).clone(), arms: arms.clone(), span: e.span.clone(), last: *last })),
            ast::ExprKind::EIf(c, then_b, else_b_opt) => prism_rtl::Turn::More(Rc::new(BuildingIf { env: env.clone(), st: st.clone(), c: (**c).clone(), then_b: then_b.clone(), else_b_opt: else_b_opt.clone(), span: e.span.clone(), last: *last })),
            ast::ExprKind::EFreeSigil(m13542_2_0, x) if (m13542_2_0 == &Text::from("@")) => {
                let e = e.clone();
                let env = env.clone();
                let last = *last;
                let st = st.clone();
                let x = (**x).clone();
                call_then(check_expr::start_infer(env.clone(), st.clone(), x.clone()), move |infer_13754: (check_types::Ty, check_types::St)| {
                    let (t, st2) = infer_13754;
                    if last {
                        prism_rtl::Turn::Finished((t.clone(), st2.clone()))
                    } else {
                        call_then(start_discarded(st2.clone(), t.clone(), e.span.clone()), move |discarded_13811: check_types::St| prism_rtl::Turn::Finished((t.clone(), discarded_13811)))
                    }
                })
            },
            ast::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(BareLine { env: env.clone(), st: st.clone(), e: (**x).clone(), last: *last })),
            _ => {
                let e = e.clone();
                let env = env.clone();
                let last = *last;
                let st = st.clone();
                call_then(check_expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_13919: (check_types::Ty, check_types::St)| {
                    let (t, st1) = infer_13919;
                    call_then(check_types::start_walk(st1.clone(), t.clone()), move |walk_13969: check_types::Ty| {
                        let (res, st2) = match walk_13969 {
                            check_types::Ty::TyAt(_, _) => bind_output(&env, &st1, &t, &e.span),
                            check_types::Ty::TyElem(_, _) => bind_output(&env, &st1, &t, &e.span),
                            check_types::Ty::TyErr => (check_types::t_unit(), st1.clone()),
                            other => if is_builder(&e) {
                                (other.clone(), st1.clone())
                            } else {
                                if &check_types::walk(&st1, &other) == &check_types::t_unit() {
                                    (check_types::t_unit(), st1.clone())
                                } else {
                                    (other.clone(), check_types::err_fix(&st1, &Text::from("mismatch"), &e.span, &Text::from(format!("a bare line emits an element or builds a blueprint; this is `{}`", &check_types::show_ty(&st1, &other))), &Text::from(format!("end the block on a value with `@ {}`", &check_expr::src_text(&env, &e.span)))))
                                }
                            },
                        };
                        if last {
                            prism_rtl::Turn::Finished((res.clone(), st2.clone()))
                        } else {
                            call_then(start_discarded(st2.clone(), res.clone(), e.span.clone()), move |discarded_14534: check_types::St| prism_rtl::Turn::Finished((res.clone(), discarded_14534)))
                        }
                    })
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start BareLineKind, x`: what the function value is when passed to `@Run`.
pub fn start_bare_line_kind(env: check_expr::Env, st: check_types::St, e: ast::Expr, last: bool) -> Rc<dyn prism_rtl::Job<(check_types::Ty, check_types::St)>> {
    Rc::new(BareLineKind { env, st, e, last })
}

/// ```prism
/// Discarded: unbounded fn St, Ty, Range -> St
/// ```
pub fn discarded(st: &check_types::St, t: &check_types::Ty, span: &ast::Range) -> check_types::St {
    match check_types::walk(st, t) {
        check_types::Ty::TyCon(m14698_0_0, m14698_0_1) if (&m14698_0_0 == &Text::from("unit")) && ((&m14698_0_1).len() == 0) => st.clone(),
        check_types::Ty::TyErr => st.clone(),
        check_types::Ty::TyFlex(_) => check_types::unify(st, &check_types::t_unit(), t, span),
        other => check_types::err_fix(st, &Text::from("discarded"), span, &Text::from(format!("this line's result is `{}`; drop it with `ignore <-`", &check_types::show_ty(st, &other))), &Text::from("write `ignore <-` in front of it, or bind it")),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `Discarded`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Discarded: unbounded fn St, Ty, Range -> St
/// ```
pub struct Discarded {
    pub st: check_types::St,
    pub t: check_types::Ty,
    pub span: ast::Range,
}

impl prism_rtl::Job<check_types::St> for Discarded {
    fn cycle(&self) -> prism_rtl::Turn<check_types::St> {
        let st = &self.st;
        let t = &self.t;
        let span = &self.span;
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(check_types::start_walk(st.clone(), t.clone()), move |walk_14704: check_types::Ty| match walk_14704 {
            check_types::Ty::TyCon(m14698_0_0, m14698_0_1) if (&m14698_0_0 == &Text::from("unit")) && ((&m14698_0_1).len() == 0) => prism_rtl::Turn::Finished(st.clone()),
            check_types::Ty::TyErr => prism_rtl::Turn::Finished(st.clone()),
            check_types::Ty::TyFlex(_) => prism_rtl::Turn::More(Rc::new(check_types::Unify { st: st.clone(), expected: check_types::t_unit(), found: t.clone(), span: span.clone() })),
            other => call_then(check_types::start_show_ty(st.clone(), other.clone()), move |show_ty_14867: Text| prism_rtl::Turn::Finished(check_types::err_fix(&st, &Text::from("discarded"), &span, &Text::from(format!("this line's result is `{}`; drop it with `ignore <-`", &show_ty_14867)), &Text::from("write `ignore <-` in front of it, or bind it")))),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start Discarded, x`: what the function value is when passed to `@Run`.
pub fn start_discarded(st: check_types::St, t: check_types::Ty, span: ast::Range) -> Rc<dyn prism_rtl::Job<check_types::St>> {
    Rc::new(Discarded { st, t, span })
}

/// ```prism
/// BuildingMatch: unbounded fn Env, St, Expr, [Arm], Range, Bool -> ((Ty, St))
/// ```
pub fn building_match(env: &check_expr::Env, st: &check_types::St, scrut: &ast::Expr, arms: &Array<ast::Arm>, span: &ast::Range, last: &bool) -> (check_types::Ty, check_types::St) {
    let (st_ty, st1) = check_expr::infer(env, st, scrut);
    let sh = check_types::head_sigil(&st1, &st_ty);
    let st2 = if check_expr::is_time_sigil(&sh) {
        check_types::err_fix(&st1, &Text::from("building-match"), &scrut.span, &Text::from(format!("a blueprint in a match over a {}; use `rebuild`", &(if &sh == &Text::from("$") { Text::from("dynamic") } else { Text::from("event") }))), &Text::from(format!("write `rebuild {}:` with `match _:` inside", &check_expr::src_text(env, &scrut.span))))
    } else {
        st1.clone()
    };
    let plain_scrut = if check_expr::is_time_sigil(&sh) {
        check_expr::inner_of(&st2, &st_ty)
    } else {
        st_ty.clone()
    };
    let (res, st3) = check_types::fresh_var(&st2, &false, &Text::from(""));
    let st4 = run_to_end(fold_job(arms.clone(), st3.clone(), {
        let env = env.clone();
        let plain_scrut = plain_scrut.clone();
        let res = res.clone();
        Rc::new(move |(p0, p1): (check_types::St, ast::Arm)| {
            let env = env.clone();
            let plain_scrut = plain_scrut.clone();
            let res = res.clone();
            entered(once_job(move || {
                let s = p0;
                let arm = p1;
                {
                    let (env2, s1) = match &arm.pattern {
                        Some(p_) => check_expr::bind_pattern(&env, &s, p_, &plain_scrut, &true),
                        None => (env.clone(), s.clone()),
                    };
                    let s2 = match &arm.guard {
                        Some(gd) => check_expr::check_cond(&env2, &s1, gd),
                        None => s1.clone(),
                    };
                    let (bt, s3) = arm_widget_block(&env2, &s2, &arm.body);
                    prism_rtl::Turn::More(Rc::new(check_types::Unify { st: s3.clone(), expected: res.clone(), found: bt.clone(), span: arm.body.span.clone() }))
                }
            }))
        }) as Rc<dyn Fn((check_types::St, ast::Arm)) -> Rc<dyn prism_rtl::Job<check_types::St>>>
    }));
    let st5 = check_passes::match_coverage(env, &st4, &plain_scrut, arms, span);
    if *last {
        (res.clone(), st5.clone())
    } else {
        (res.clone(), discarded(&st5, &res, span))
    }
}

/// The step machine of `BuildingMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildingMatch: unbounded fn Env, St, Expr, [Arm], Range, Bool -> ((Ty, St))
/// ```
pub struct BuildingMatch {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub scrut: ast::Expr,
    pub arms: Array<ast::Arm>,
    pub span: ast::Range,
    pub last: bool,
}

impl prism_rtl::Job<(check_types::Ty, check_types::St)> for BuildingMatch {
    fn cycle(&self) -> prism_rtl::Turn<(check_types::Ty, check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let scrut = &self.scrut;
        let arms = &self.arms;
        let span = &self.span;
        let last = &self.last;
        let arms = arms.clone();
        let env = env.clone();
        let last = *last;
        let scrut = scrut.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(check_expr::start_infer(env.clone(), st.clone(), scrut.clone()), move |infer_15271: (check_types::Ty, check_types::St)| {
            let (st_ty, st1) = infer_15271;
            call_then(check_types::start_head_sigil(st1.clone(), st_ty.clone()), move |head_sigil_15305: Text| {
                let sh = head_sigil_15305;
                let st2 = if check_expr::is_time_sigil(&sh) {
                    check_types::err_fix(&st1, &Text::from("building-match"), &scrut.span, &Text::from(format!("a blueprint in a match over a {}; use `rebuild`", &(if &sh == &Text::from("$") { Text::from("dynamic") } else { Text::from("event") }))), &Text::from(format!("write `rebuild {}:` with `match _:` inside", &check_expr::src_text(&env, &scrut.span))))
                } else {
                    st1.clone()
                };
                let plain_scrut = if check_expr::is_time_sigil(&sh) {
                    check_expr::inner_of(&st2, &st_ty)
                } else {
                    st_ty.clone()
                };
                let (res, st3) = check_types::fresh_var(&st2, &false, &Text::from(""));
                call_value(fold_job(arms.clone(), st3.clone(), {
                    let env = env.clone();
                    let plain_scrut = plain_scrut.clone();
                    let res = res.clone();
                    Rc::new(move |(p0, p1): (check_types::St, ast::Arm)| {
                        let env = env.clone();
                        let plain_scrut = plain_scrut.clone();
                        let res = res.clone();
                        entered(once_job(move || {
                            let s = p0;
                            let arm = p1;
                            {
                                let (env2, s1) = match &arm.pattern {
                                    Some(p_) => check_expr::bind_pattern(&env, &s, p_, &plain_scrut, &true),
                                    None => (env.clone(), s.clone()),
                                };
                                let s2 = match &arm.guard {
                                    Some(gd) => check_expr::check_cond(&env2, &s1, gd),
                                    None => s1.clone(),
                                };
                                let (bt, s3) = arm_widget_block(&env2, &s2, &arm.body);
                                prism_rtl::Turn::More(Rc::new(check_types::Unify { st: s3.clone(), expected: res.clone(), found: bt.clone(), span: arm.body.span.clone() }))
                            }
                        }))
                    }) as Rc<dyn Fn((check_types::St, ast::Arm)) -> Rc<dyn prism_rtl::Job<check_types::St>>>
                }), move |fold_15696: check_types::St| {
                    let st4 = fold_15696;
                    call_then(check_passes::start_match_coverage(env.clone(), st4.clone(), plain_scrut.clone(), arms.clone(), span.clone()), move |match_coverage_16064: check_types::St| {
                        let st5 = match_coverage_16064;
                        if last {
                            prism_rtl::Turn::Finished((res.clone(), st5.clone()))
                        } else {
                            call_then(start_discarded(st5.clone(), res.clone(), span.clone()), move |discarded_16151: check_types::St| prism_rtl::Turn::Finished((res.clone(), discarded_16151)))
                        }
                    })
                })
            })
        })
    }
}

/// `Start BuildingMatch, x`: what the function value is when passed to `@Run`.
pub fn start_building_match(env: check_expr::Env, st: check_types::St, scrut: ast::Expr, arms: Array<ast::Arm>, span: ast::Range, last: bool) -> Rc<dyn prism_rtl::Job<(check_types::Ty, check_types::St)>> {
    Rc::new(BuildingMatch { env, st, scrut, arms, span, last })
}

/// ```prism
/// BuildingIf: unbounded fn Env, St, Cond, Block, ?Block, Range, Bool -> ((Ty, St))
/// ```
pub fn building_if(env: &check_expr::Env, st: &check_types::St, c: &ast::Cond, then_b: &ast::Block, else_b_opt: &Option<ast::Block>, span: &ast::Range, last: &bool) -> (check_types::Ty, check_types::St) {
    let (env2, st1) = match c {
        ast::Cond::CondExpr(e) => {
            let (ct, s1) = check_expr::infer(env, st, &**e);
            let sh = check_types::head_sigil(&s1, &ct);
            let s2 = if check_expr::is_time_sigil(&sh) {
                check_types::err_fix(&s1, &Text::from("building-match"), &e.span, &Text::from("a blueprint in a match over a dynamic; use `rebuild`"), &Text::from("write `rebuild` over the condition, with `if _:` inside"))
            } else {
                s1.clone()
            };
            (env.clone(), check_types::unify(&s2, &check_types::t_bool(), &(if check_expr::is_time_sigil(&sh) {
                check_expr::inner_of(&s2, &ct)
            } else {
                ct.clone()
            }), &e.span))
        },
        ast::Cond::CondBind(p_, e, gd_opt) => {
            let (et, s1) = check_expr::infer(env, st, &**e);
            let (en, s2) = check_expr::bind_pattern(env, &s1, p_, &et, &true);
            match &**gd_opt {
                Some(g) => (en.clone(), check_expr::check_cond(&en, &s2, g)),
                None => (en.clone(), s2.clone()),
            }
        },
    };
    let (t1, st2) = arm_widget_block(&env2, &st1, then_b);
    match else_b_opt {
        Some(b) => {
            let (t2, st3) = arm_widget_block(env, &st2, b);
            let st4 = check_types::unify(&st3, &t1, &t2, &b.span);
            if *last {
                (t1.clone(), st4.clone())
            } else {
                (t1.clone(), discarded(&st4, &t1, span))
            }
        },
        None => {
            let st3 = check_types::unify(&st2, &check_types::t_unit(), &t1, &then_b.span);
            (check_types::t_unit(), st3.clone())
        },
    }
}

/// The step machine of `BuildingIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BuildingIf: unbounded fn Env, St, Cond, Block, ?Block, Range, Bool -> ((Ty, St))
/// ```
pub struct BuildingIf {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub c: ast::Cond,
    pub then_b: ast::Block,
    pub else_b_opt: Option<ast::Block>,
    pub span: ast::Range,
    pub last: bool,
}

impl prism_rtl::Job<(check_types::Ty, check_types::St)> for BuildingIf {
    fn cycle(&self) -> prism_rtl::Turn<(check_types::Ty, check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let c = &self.c;
        let then_b = &self.then_b;
        let else_b_opt = &self.else_b_opt;
        let span = &self.span;
        let last = &self.last;
        let (env2, st1) = match c {
            ast::Cond::CondExpr(e) => {
                let (ct, s1) = check_expr::infer(env, st, &**e);
                let sh = check_types::head_sigil(&s1, &ct);
                let s2 = if check_expr::is_time_sigil(&sh) {
                    check_types::err_fix(&s1, &Text::from("building-match"), &e.span, &Text::from("a blueprint in a match over a dynamic; use `rebuild`"), &Text::from("write `rebuild` over the condition, with `if _:` inside"))
                } else {
                    s1.clone()
                };
                (env.clone(), check_types::unify(&s2, &check_types::t_bool(), &(if check_expr::is_time_sigil(&sh) {
                    check_expr::inner_of(&s2, &ct)
                } else {
                    ct.clone()
                }), &e.span))
            },
            ast::Cond::CondBind(p_, e, gd_opt) => {
                let (et, s1) = check_expr::infer(env, st, &**e);
                let (en, s2) = check_expr::bind_pattern(env, &s1, p_, &et, &true);
                match &**gd_opt {
                    Some(g) => (en.clone(), check_expr::check_cond(&en, &s2, g)),
                    None => (en.clone(), s2.clone()),
                }
            },
        };
        let (t1, st2) = arm_widget_block(&env2, &st1, then_b);
        match else_b_opt {
            Some(b) => {
                let (t2, st3) = arm_widget_block(env, &st2, b);
                let b = b.clone();
                let last = *last;
                let span = span.clone();
                call_then(check_types::start_unify(st3.clone(), t1.clone(), t2.clone(), b.span.clone()), move |unify_17150: check_types::St| {
                    let st4 = unify_17150;
                    if last {
                        prism_rtl::Turn::Finished((t1.clone(), st4.clone()))
                    } else {
                        call_then(start_discarded(st4.clone(), t1.clone(), span.clone()), move |discarded_17222: check_types::St| prism_rtl::Turn::Finished((t1.clone(), discarded_17222)))
                    }
                })
            },
            None => {
                let span = span.clone();
                let then_b = then_b.clone();
                call_then(check_types::start_unify(st2.clone(), check_types::t_unit(), t1.clone(), then_b.span.clone()), move |unify_17284: check_types::St| {
                    let st3 = unify_17284;
                    prism_rtl::Turn::Finished((check_types::t_unit(), st3.clone()))
                })
            },
        }
    }
}

/// `Start BuildingIf, x`: what the function value is when passed to `@Run`.
pub fn start_building_if(env: check_expr::Env, st: check_types::St, c: ast::Cond, then_b: ast::Block, else_b_opt: Option<ast::Block>, span: ast::Range, last: bool) -> Rc<dyn prism_rtl::Job<(check_types::Ty, check_types::St)>> {
    Rc::new(BuildingIf { env, st, c, then_b, else_b_opt, span, last })
}

/// ```prism
/// ArmWidgetBlock: unbounded fn Env, St, Block -> ((Ty, St))
/// ```
pub fn arm_widget_block(env: &check_expr::Env, st: &check_types::St, b: &ast::Block) -> (check_types::Ty, check_types::St) {
    infer_widget_block(env, st, b)
}

/// ```prism
/// InferRebuild: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
/// ```
pub fn infer_rebuild(env: &check_expr::Env, st: &check_types::St, scrut: &ast::Expr, body: &ast::Block, span: &ast::Range) -> (check_types::Ty, check_types::St) {
    let (t, st1) = check_expr::infer(env, st, scrut);
    let (inner, st2) = match check_types::walk(&st1, &t) {
        check_types::Ty::TySig(m18151_0_0, i) if (&m18151_0_0 == &Text::from("$")) => ((*i).clone(), st1.clone()),
        check_types::Ty::TyErr => (check_types::Ty::TyErr, st1.clone()),
        check_types::Ty::TyFlex(_) => {
            let (v_, s2) = check_types::fresh_var(&st1, &false, &Text::from(""));
            (v_.clone(), check_types::unify(&s2, &check_types::Ty::TySig(Text::from("$"), Rc::new(v_.clone())), &t, &scrut.span))
        },
        other => (check_types::Ty::TyErr, check_types::err_fix(&st1, &Text::from("mismatch"), &scrut.span, &Text::from(format!("`rebuild` builds over a dynamic; this is `{}`", &check_types::show_ty(&st1, &other))), &Text::from("a plain value is built once: write the block's lines in place"))),
        _ => unreachable!("no arm matched"),
    };
    let env2 = with_topic(env, &Text::from("_"), &inner);
    let (res, st3) = infer_widget_block(&env2, &st2, body);
    match check_types::walk(&st3, &res) {
        check_types::Ty::TyCon(m18664_0_0, m18664_0_1) if (&m18664_0_0 == &Text::from("unit")) && ((&m18664_0_1).len() == 0) => (check_types::t_unit(), st3.clone()),
        other => (check_types::Ty::TySig(Text::from("$"), Rc::new(other.clone())), st3.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `InferRebuild`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferRebuild: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
/// ```
pub struct InferRebuild {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub scrut: ast::Expr,
    pub body: ast::Block,
    pub span: ast::Range,
}

impl prism_rtl::Job<(check_types::Ty, check_types::St)> for InferRebuild {
    fn cycle(&self) -> prism_rtl::Turn<(check_types::Ty, check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let scrut = &self.scrut;
        let body = &self.body;
        let span = &self.span;
        let body = body.clone();
        let env = env.clone();
        let scrut = scrut.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(check_expr::start_infer(env.clone(), st.clone(), scrut.clone()), move |infer_18105: (check_types::Ty, check_types::St)| {
            let (t, st1) = infer_18105;
            call_then(check_types::start_walk(st1.clone(), t.clone()), move |walk_18157: check_types::Ty| {
                let (inner, st2) = match walk_18157 {
                    check_types::Ty::TySig(m18151_0_0, i) if (&m18151_0_0 == &Text::from("$")) => ((*i).clone(), st1.clone()),
                    check_types::Ty::TyErr => (check_types::Ty::TyErr, st1.clone()),
                    check_types::Ty::TyFlex(_) => {
                        let (v_, s2) = check_types::fresh_var(&st1, &false, &Text::from(""));
                        (v_.clone(), check_types::unify(&s2, &check_types::Ty::TySig(Text::from("$"), Rc::new(v_.clone())), &t, &scrut.span))
                    },
                    other => (check_types::Ty::TyErr, check_types::err_fix(&st1, &Text::from("mismatch"), &scrut.span, &Text::from(format!("`rebuild` builds over a dynamic; this is `{}`", &check_types::show_ty(&st1, &other))), &Text::from("a plain value is built once: write the block's lines in place"))),
                    _ => unreachable!("no arm matched"),
                };
                let env2 = with_topic(&env, &Text::from("_"), &inner);
                call_then(start_infer_widget_block(env2.clone(), st2.clone(), body.clone()), move |infer_widget_block_18627: (check_types::Ty, check_types::St)| {
                    let (res, st3) = infer_widget_block_18627;
                    call_then(check_types::start_walk(st3.clone(), res.clone()), move |walk_18670: check_types::Ty| match walk_18670 {
                        check_types::Ty::TyCon(m18664_0_0, m18664_0_1) if (&m18664_0_0 == &Text::from("unit")) && ((&m18664_0_1).len() == 0) => prism_rtl::Turn::Finished((check_types::t_unit(), st3.clone())),
                        other => prism_rtl::Turn::Finished((check_types::Ty::TySig(Text::from("$"), Rc::new(other.clone())), st3.clone())),
                        _ => unreachable!("no arm matched"),
                    })
                })
            })
        })
    }
}

/// `Start InferRebuild, x`: what the function value is when passed to `@Run`.
pub fn start_infer_rebuild(env: check_expr::Env, st: check_types::St, scrut: ast::Expr, body: ast::Block, span: ast::Range) -> Rc<dyn prism_rtl::Job<(check_types::Ty, check_types::St)>> {
    Rc::new(InferRebuild { env, st, scrut, body, span })
}

/// ```prism
/// WithTopic: fn Env, Text, Ty -> Env
/// ```
pub fn with_topic(env: &check_expr::Env, name: &Text, t: &check_types::Ty) -> check_expr::Env {
    let mut this: check_expr::Env = check_expr::with_local(env, name, &check_types::mono(t));
    this.pending = filter(&this.pending, &(|x: &Text| x != name));
    this
}

/// ```prism
/// InferFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> ((Ty, St))
/// ```
pub fn infer_for(env: &check_expr::Env, st: &check_types::St, binders_opt: &Option<ast::ForBinders>, source: &ast::Expr, body: &ast::Block, span: &ast::Range) -> (check_types::Ty, check_types::St) {
    if env.in_update {
        (check_types::t_unit(), update_for(env, st, binders_opt, source, body, span))
    } else {
        {
            let (t, st1) = check_expr::infer(env, st, source);
            let sh = check_types::head_sigil(&st1, &t);
            let coll = if &sh == &Text::from("$") { check_expr::inner_of(&st1, &t) } else { t.clone() };
            let st2 = if (&sh == &Text::from("!")) || (&sh == &Text::from("@")) {
                check_types::err(&st1, &Text::from("mismatch"), &source.span, &Text::from(format!("`for` runs over a map or an array, plain or dynamic; this is `{}`", &check_types::show_ty(&st1, &t))))
            } else {
                st1.clone()
            };
            let (k, v_, st3) = coll_parts(&st2, &coll, &source.span);
            let live = &sh == &Text::from("$");
            let env1 = loop_indices(env);
            let (env2, st4) = bind_for_binders(&env1, &st3, binders_opt, &k, &v_, &live);
            let (res, st5) = infer_widget_block(&env2, &st4, body);
            gather(&st5, &res, &k, &live)
        }
    }
}

/// The step machine of `InferFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> ((Ty, St))
/// ```
pub struct InferFor {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub binders_opt: Option<ast::ForBinders>,
    pub source: ast::Expr,
    pub body: ast::Block,
    pub span: ast::Range,
}

impl prism_rtl::Job<(check_types::Ty, check_types::St)> for InferFor {
    fn cycle(&self) -> prism_rtl::Turn<(check_types::Ty, check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let binders_opt = &self.binders_opt;
        let source = &self.source;
        let body = &self.body;
        let span = &self.span;
        if env.in_update {
            {
                let binders_opt = binders_opt.clone();
                let body = body.clone();
                let env = env.clone();
                let source = source.clone();
                let span = span.clone();
                let st = st.clone();
                call_then(start_update_for(env.clone(), st.clone(), binders_opt.clone(), source.clone(), body.clone(), span.clone()), move |update_for_19255: check_types::St| prism_rtl::Turn::Finished((check_types::t_unit(), update_for_19255)))
            }
        } else {
            {
                let binders_opt = binders_opt.clone();
                let body = body.clone();
                let env = env.clone();
                let source = source.clone();
                let span = span.clone();
                let st = st.clone();
                call_then(check_expr::start_infer(env.clone(), st.clone(), source.clone()), move |infer_19341: (check_types::Ty, check_types::St)| {
                    let (t, st1) = infer_19341;
                    call_then(check_types::start_head_sigil(st1.clone(), t.clone()), move |head_sigil_19380: Text| {
                        let sh = head_sigil_19380;
                        let coll = if &sh == &Text::from("$") { check_expr::inner_of(&st1, &t) } else { t.clone() };
                        let st2 = if (&sh == &Text::from("!")) || (&sh == &Text::from("@")) {
                            check_types::err(&st1, &Text::from("mismatch"), &source.span, &Text::from(format!("`for` runs over a map or an array, plain or dynamic; this is `{}`", &check_types::show_ty(&st1, &t))))
                        } else {
                            st1.clone()
                        };
                        call_then(start_coll_parts(st2.clone(), coll.clone(), source.span.clone()), move |coll_parts_19651: (check_types::Ty, check_types::Ty, check_types::St)| {
                            let (k, v_, st3) = coll_parts_19651;
                            let live = &sh == &Text::from("$");
                            let env1 = loop_indices(&env);
                            call_then(start_bind_for_binders(env1.clone(), st3.clone(), binders_opt.clone(), k.clone(), v_.clone(), live), move |bind_for_binders_19776: (check_expr::Env, check_types::St)| {
                                let (env2, st4) = bind_for_binders_19776;
                                call_then(start_infer_widget_block(env2.clone(), st4.clone(), body.clone()), move |infer_widget_block_19850: (check_types::Ty, check_types::St)| {
                                    let (res, st5) = infer_widget_block_19850;
                                    prism_rtl::Turn::More(Rc::new(Gather { st: st5.clone(), res: res.clone(), k: k.clone(), live }))
                                })
                            })
                        })
                    })
                })
            }
        }
    }
}

/// `Start InferFor, x`: what the function value is when passed to `@Run`.
pub fn start_infer_for(env: check_expr::Env, st: check_types::St, binders_opt: Option<ast::ForBinders>, source: ast::Expr, body: ast::Block, span: ast::Range) -> Rc<dyn prism_rtl::Job<(check_types::Ty, check_types::St)>> {
    Rc::new(InferFor { env, st, binders_opt, source, body, span })
}

/// ```prism
/// CollParts: unbounded fn St, Ty, Range -> ((Ty, Ty, St))
/// ```
pub fn coll_parts(st: &check_types::St, t: &check_types::Ty, span: &ast::Range) -> (check_types::Ty, check_types::Ty, check_types::St) {
    'm20043: {
        let scrutinee = &check_types::walk(st, t);
        if let check_types::Ty::TyMap(k, v_) = scrutinee {
            break 'm20043 ((**k).clone(), (**v_).clone(), st.clone());
        }
        if let check_types::Ty::TyArray(v_) = scrutinee {
            break 'm20043 (check_types::t_nat(), (**v_).clone(), st.clone());
        }
        if let check_types::Ty::TyCon(m20043_2_0, m20043_2_1) = scrutinee && (m20043_2_0 == &Text::from("Buffer")) && (m20043_2_1.len() == 1) && let Some(v_) = index(m20043_2_1, &Nat::from(0u32)) {
            break 'm20043 (check_types::t_nat(), v_.clone(), st.clone());
        }
        if let check_types::Ty::TyErr = scrutinee {
            break 'm20043 (check_types::Ty::TyErr, check_types::Ty::TyErr, st.clone());
        }
        if let check_types::Ty::TyFlex(_) = scrutinee {
            break 'm20043 {
                let (v_, st2) = check_types::fresh_var(st, &false, &Text::from(""));
                (check_types::t_nat(), v_.clone(), check_types::unify(&st2, &check_types::Ty::TyArray(Rc::new(v_.clone())), t, span))
            };
        }
        if let other = scrutinee {
            break 'm20043 (check_types::Ty::TyErr, check_types::Ty::TyErr, check_types::err(st, &Text::from("mismatch"), span, &Text::from(format!("`for` runs over a map or an array; this is `{}`", &check_types::show_ty(st, other)))));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `CollParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CollParts: unbounded fn St, Ty, Range -> ((Ty, Ty, St))
/// ```
pub struct CollParts {
    pub st: check_types::St,
    pub t: check_types::Ty,
    pub span: ast::Range,
}

impl prism_rtl::Job<(check_types::Ty, check_types::Ty, check_types::St)> for CollParts {
    fn cycle(&self) -> prism_rtl::Turn<(check_types::Ty, check_types::Ty, check_types::St)> {
        let st = &self.st;
        let t = &self.t;
        let span = &self.span;
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(check_types::start_walk(st.clone(), t.clone()), move |walk_20049: check_types::Ty| 'm20043: {
            if let check_types::Ty::TyMap(k, v_) = &walk_20049 {
                break 'm20043 prism_rtl::Turn::Finished(((**k).clone(), (**v_).clone(), st.clone()));
            }
            if let check_types::Ty::TyArray(v_) = &walk_20049 {
                break 'm20043 prism_rtl::Turn::Finished((check_types::t_nat(), (**v_).clone(), st.clone()));
            }
            if let check_types::Ty::TyCon(m20043_2_0, m20043_2_1) = &walk_20049 && (m20043_2_0 == &Text::from("Buffer")) && (m20043_2_1.len() == 1) && let Some(v_) = index(m20043_2_1, &Nat::from(0u32)) {
                break 'm20043 prism_rtl::Turn::Finished((check_types::t_nat(), v_.clone(), st.clone()));
            }
            if let check_types::Ty::TyErr = &walk_20049 {
                break 'm20043 prism_rtl::Turn::Finished((check_types::Ty::TyErr, check_types::Ty::TyErr, st.clone()));
            }
            if let check_types::Ty::TyFlex(_) = &walk_20049 {
                break 'm20043 {
                    let (v_, st2) = check_types::fresh_var(&st, &false, &Text::from(""));
                    call_then(check_types::start_unify(st2.clone(), check_types::Ty::TyArray(Rc::new(v_.clone())), t.clone(), span.clone()), move |unify_20283: check_types::St| prism_rtl::Turn::Finished((check_types::t_nat(), v_.clone(), unify_20283)))
                };
            }
            if let other = &walk_20049 {
                break 'm20043 {
                    let other = other.clone();
                    call_then(check_types::start_show_ty(st.clone(), other.clone()), move |show_ty_20418: Text| prism_rtl::Turn::Finished((check_types::Ty::TyErr, check_types::Ty::TyErr, check_types::err(&st, &Text::from("mismatch"), &span, &Text::from(format!("`for` runs over a map or an array; this is `{}`", &show_ty_20418))))))
                };
            }
            unreachable!("no clause matched")
        })
    }
}

/// `Start CollParts, x`: what the function value is when passed to `@Run`.
pub fn start_coll_parts(st: check_types::St, t: check_types::Ty, span: ast::Range) -> Rc<dyn prism_rtl::Job<(check_types::Ty, check_types::Ty, check_types::St)>> {
    Rc::new(CollParts { st, t, span })
}

/// ```prism
/// LoopIndices: fn Env -> Env
/// ```
pub fn loop_indices(env: &check_expr::Env) -> check_expr::Env {
    let outer1_opt = get(&env.locals, &Text::from("ix"));
    let outer2_opt = get(&env.locals, &Text::from("jx"));
    let e1 = check_expr::with_local(env, &Text::from("ix"), &check_types::mono(&check_types::t_nat()));
    let e2 = match &outer1_opt {
        Some(sc) => check_expr::with_local(&e1, &Text::from("jx"), sc),
        None => e1.clone(),
    };
    match &outer2_opt {
        Some(sc) => check_expr::with_local(&e2, &Text::from("kx"), sc),
        None => e2.clone(),
    }
}

/// ```prism
/// BindForBinders: unbounded fn Env, St, ?ForBinders, Ty, Ty, Bool -> ((Env, St))
/// ```
pub fn bind_for_binders(env: &check_expr::Env, st: &check_types::St, binders_opt: &Option<ast::ForBinders>, k: &check_types::Ty, v_: &check_types::Ty, live: &bool) -> (check_expr::Env, check_types::St) {
    let vt = if *live {
        check_types::Ty::TySig(Text::from("$"), Rc::new(v_.clone()))
    } else {
        v_.clone()
    };
    match binders_opt {
        None => {
            let e1 = with_topic(env, &(if *live { Text::from("$_") } else { Text::from("_") }), &vt);
            (with_topic(&e1, &Text::from("key"), k), st.clone())
        },
        Some(bs) => match &bs.second {
            Some(second) => {
                let (e1, st1) = check_expr::bind_pattern(&unpending(env), st, &bs.first, k, &false);
                check_expr::bind_pattern(&e1, &st1, second, &vt, &false)
            },
            None => {
                let e1 = with_topic(env, &Text::from("key"), k);
                check_expr::bind_pattern(&unpending(&e1), st, &bs.first, &vt, &false)
            },
        },
    }
}

/// The step machine of `BindForBinders`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindForBinders: unbounded fn Env, St, ?ForBinders, Ty, Ty, Bool -> ((Env, St))
/// ```
pub struct BindForBinders {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub binders_opt: Option<ast::ForBinders>,
    pub k: check_types::Ty,
    pub v_: check_types::Ty,
    pub live: bool,
}

impl prism_rtl::Job<(check_expr::Env, check_types::St)> for BindForBinders {
    fn cycle(&self) -> prism_rtl::Turn<(check_expr::Env, check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let binders_opt = &self.binders_opt;
        let k = &self.k;
        let v_ = &self.v_;
        let live = &self.live;
        let vt = if *live {
            check_types::Ty::TySig(Text::from("$"), Rc::new(v_.clone()))
        } else {
            v_.clone()
        };
        match binders_opt {
            None => {
                let e1 = with_topic(env, &(if *live { Text::from("$_") } else { Text::from("_") }), &vt);
                prism_rtl::Turn::Finished((with_topic(&e1, &Text::from("key"), k), st.clone()))
            },
            Some(bs) => match &bs.second {
                Some(second) => {
                    let bs = bs.clone();
                    let env = env.clone();
                    let k = k.clone();
                    let second = second.clone();
                    let st = st.clone();
                    call_then(check_expr::start_bind_pattern(unpending(&env), st.clone(), bs.first.clone(), k.clone(), false), move |bind_pattern_21414: (check_expr::Env, check_types::St)| {
                        let (e1, st1) = bind_pattern_21414;
                        prism_rtl::Turn::More(Rc::new(check_expr::BindPattern { env: e1.clone(), st: st1.clone(), p_: second.clone(), t: vt.clone(), refutable: false }))
                    })
                },
                None => {
                    let e1 = with_topic(env, &Text::from("key"), k);
                    prism_rtl::Turn::More(Rc::new(check_expr::BindPattern { env: unpending(&e1), st: st.clone(), p_: bs.first.clone(), t: vt.clone(), refutable: false }))
                },
            },
        }
    }
}

/// `Start BindForBinders, x`: what the function value is when passed to `@Run`.
pub fn start_bind_for_binders(env: check_expr::Env, st: check_types::St, binders_opt: Option<ast::ForBinders>, k: check_types::Ty, v_: check_types::Ty, live: bool) -> Rc<dyn prism_rtl::Job<(check_expr::Env, check_types::St)>> {
    Rc::new(BindForBinders { env, st, binders_opt, k, v_, live })
}

/// ```prism
/// Unpending: fn Env -> Env
/// ```
pub fn unpending(env: &check_expr::Env) -> check_expr::Env {
    let mut this: check_expr::Env = env.clone();
    this.pending = Array::new();
    this
}

/// ```prism
/// Gather: unbounded fn St, Ty, Ty, Bool -> ((Ty, St))
/// ```
pub fn gather(st: &check_types::St, res: &check_types::Ty, k: &check_types::Ty, live: &bool) -> (check_types::Ty, check_types::St) {
    match check_types::walk(st, res) {
        check_types::Ty::TyCon(m22080_0_0, m22080_0_1) if (&m22080_0_0 == &Text::from("unit")) && ((&m22080_0_1).len() == 0) => (check_types::t_unit(), st.clone()),
        check_types::Ty::TySig(m22080_1_0, t) if (&m22080_1_0 == &Text::from("!")) => (check_types::Ty::TySig(Text::from("!"), Rc::new(check_types::Ty::TyMap(Rc::new(k.clone()), Rc::new((*t).clone())))), st.clone()),
        check_types::Ty::TySig(m22080_2_0, t) if (&m22080_2_0 == &Text::from("$")) => (check_types::Ty::TySig(Text::from("$"), Rc::new(check_types::Ty::TyMap(Rc::new(k.clone()), Rc::new((*t).clone())))), st.clone()),
        check_types::Ty::TyTuple(ts) => if run_to_end(fold_job(ts.clone(), false, {
            let st = st.clone();
            Rc::new(move |(p0, p1): (bool, check_types::Ty)| {
                let st = st.clone();
                entered(once_job(move || {
                    let seen = p0;
                    let x = p1;
                    prism_rtl::Turn::Finished(seen || check_expr::is_time_sigil(&check_types::head_sigil(&st, &x)))
                }))
            }) as Rc<dyn Fn((bool, check_types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })) {
            {
                let (parts, st2) = run_to_end(fold_job(ts.clone(), (Array::new(), st.clone()), {
                    let k = k.clone();
                    let live = *live;
                    Rc::new(move |(p0, p1): ((Array<check_types::Ty>, check_types::St), check_types::Ty)| {
                        let k = k.clone();
                        let live = live;
                        entered(once_job(move || {
                            let (acc, s) = p0;
                            let x = p1;
                            call_then(start_gather(s.clone(), x.clone(), k.clone(), live), move |gather_22440: (check_types::Ty, check_types::St)| {
                                let (g, s2) = gather_22440;
                                prism_rtl::Turn::Finished((push(&acc, &g), s2.clone()))
                            })
                        }))
                    }) as Rc<dyn Fn(((Array<check_types::Ty>, check_types::St), check_types::Ty)) -> Rc<dyn prism_rtl::Job<(Array<check_types::Ty>, check_types::St)>>>
                }));
                (check_types::Ty::TyTuple(parts.clone()), st2.clone())
            }
        } else {
            (live_map(live, k, &check_types::Ty::TyTuple(ts.clone())), st.clone())
        },
        other => (live_map(live, k, &other), st.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `Gather`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Gather: unbounded fn St, Ty, Ty, Bool -> ((Ty, St))
/// ```
pub struct Gather {
    pub st: check_types::St,
    pub res: check_types::Ty,
    pub k: check_types::Ty,
    pub live: bool,
}

impl prism_rtl::Job<(check_types::Ty, check_types::St)> for Gather {
    fn cycle(&self) -> prism_rtl::Turn<(check_types::Ty, check_types::St)> {
        let st = &self.st;
        let res = &self.res;
        let k = &self.k;
        let live = &self.live;
        let k = k.clone();
        let live = *live;
        let res = res.clone();
        let st = st.clone();
        call_then(check_types::start_walk(st.clone(), res.clone()), move |walk_22086: check_types::Ty| match walk_22086 {
            check_types::Ty::TyCon(m22080_0_0, m22080_0_1) if (&m22080_0_0 == &Text::from("unit")) && ((&m22080_0_1).len() == 0) => prism_rtl::Turn::Finished((check_types::t_unit(), st.clone())),
            check_types::Ty::TySig(m22080_1_0, t) if (&m22080_1_0 == &Text::from("!")) => prism_rtl::Turn::Finished((check_types::Ty::TySig(Text::from("!"), Rc::new(check_types::Ty::TyMap(Rc::new(k.clone()), Rc::new((*t).clone())))), st.clone())),
            check_types::Ty::TySig(m22080_2_0, t) if (&m22080_2_0 == &Text::from("$")) => prism_rtl::Turn::Finished((check_types::Ty::TySig(Text::from("$"), Rc::new(check_types::Ty::TyMap(Rc::new(k.clone()), Rc::new((*t).clone())))), st.clone())),
            check_types::Ty::TyTuple(ts) => call_value(fold_job(ts.clone(), false, {
                let st = st.clone();
                Rc::new(move |(p0, p1): (bool, check_types::Ty)| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let seen = p0;
                        let x = p1;
                        prism_rtl::Turn::Finished(seen || check_expr::is_time_sigil(&check_types::head_sigil(&st, &x)))
                    }))
                }) as Rc<dyn Fn((bool, check_types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
            }), move |fold_22269: bool| if fold_22269 {
                call_value(fold_job(ts.clone(), (Array::new(), st.clone()), {
                    let k = k.clone();
                    let live = live;
                    Rc::new(move |(p0, p1): ((Array<check_types::Ty>, check_types::St), check_types::Ty)| {
                        let k = k.clone();
                        let live = live;
                        entered(once_job(move || {
                            let (acc, s) = p0;
                            let x = p1;
                            call_then(start_gather(s.clone(), x.clone(), k.clone(), live), move |gather_22440: (check_types::Ty, check_types::St)| {
                                let (g, s2) = gather_22440;
                                prism_rtl::Turn::Finished((push(&acc, &g), s2.clone()))
                            })
                        }))
                    }) as Rc<dyn Fn(((Array<check_types::Ty>, check_types::St), check_types::Ty)) -> Rc<dyn prism_rtl::Job<(Array<check_types::Ty>, check_types::St)>>>
                }), move |fold_22368: (Array<check_types::Ty>, check_types::St)| {
                    let (parts, st2) = fold_22368;
                    prism_rtl::Turn::Finished((check_types::Ty::TyTuple(parts.clone()), st2.clone()))
                })
            } else {
                prism_rtl::Turn::Finished((live_map(&live, &k, &check_types::Ty::TyTuple(ts.clone())), st.clone()))
            }),
            other => prism_rtl::Turn::Finished((live_map(&live, &k, &other), st.clone())),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start Gather, x`: what the function value is when passed to `@Run`.
pub fn start_gather(st: check_types::St, res: check_types::Ty, k: check_types::Ty, live: bool) -> Rc<dyn prism_rtl::Job<(check_types::Ty, check_types::St)>> {
    Rc::new(Gather { st, res, k, live })
}

/// ```prism
/// LiveMap: fn Bool, Ty, Ty -> Ty
/// ```
pub fn live_map(live: &bool, k: &check_types::Ty, v_: &check_types::Ty) -> check_types::Ty {
    if *live {
        check_types::Ty::TySig(Text::from("$"), Rc::new(check_types::Ty::TyMap(Rc::new(k.clone()), Rc::new(v_.clone()))))
    } else {
        check_types::Ty::TyMap(Rc::new(k.clone()), Rc::new(v_.clone()))
    }
}

/// ```prism
/// InferGiven: unbounded fn Env, St, Block, Range -> ((Ty, St))
/// ```
pub fn infer_given(env: &check_expr::Env, st: &check_types::St, b: &ast::Block, span: &ast::Range) -> (check_types::Ty, check_types::St) {
    let mark = if (&env.mark == &Text::from("?")) || (&env.mark == &Text::from("~")) {
        env.mark.clone()
    } else {
        given_mark_of(&b.stmts)
    };
    infer_given_block(env, st, b, &mark)
}

/// The step machine of `InferGiven`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferGiven: unbounded fn Env, St, Block, Range -> ((Ty, St))
/// ```
pub struct InferGiven {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub b: ast::Block,
    pub span: ast::Range,
}

impl prism_rtl::Job<(check_types::Ty, check_types::St)> for InferGiven {
    fn cycle(&self) -> prism_rtl::Turn<(check_types::Ty, check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let b = &self.b;
        let span = &self.span;
        let mark = if (&env.mark == &Text::from("?")) || (&env.mark == &Text::from("~")) {
            env.mark.clone()
        } else {
            given_mark_of(&b.stmts)
        };
        prism_rtl::Turn::More(Rc::new(InferGivenBlock { env: env.clone(), st: st.clone(), b: b.clone(), mark: mark.clone() }))
    }
}

/// `Start InferGiven, x`: what the function value is when passed to `@Run`.
pub fn start_infer_given(env: check_expr::Env, st: check_types::St, b: ast::Block, span: ast::Range) -> Rc<dyn prism_rtl::Job<(check_types::Ty, check_types::St)>> {
    Rc::new(InferGiven { env, st, b, span })
}

/// ```prism
/// GivenMarkOf: fn [Stmt] -> Text
/// ```
pub fn given_mark_of(stmts: &Array<ast::Stmt>) -> Text {
    fold(stmts, &Text::from("?"), &(|m: &Text, s: &ast::Stmt| m.clone()))
}

/// ```prism
/// InferGivenBlock: unbounded fn Env, St, Block, Text -> ((Ty, St))
/// ```
pub fn infer_given_block(env: &check_expr::Env, st: &check_types::St, b: &ast::Block, mark: &Text) -> (check_types::Ty, check_types::St) {
    let n = len(&b.stmts);
    let (env2, st2, res_opt) = run_to_end(fold_job(check_errors::range0(&n), (env.clone(), st.clone(), None), {
        let b = b.clone();
        let mark = mark.clone();
        let n = n.clone();
        Rc::new(move |(p0, p1): ((check_expr::Env, check_types::St, Option<check_types::Ty>), Nat)| {
            let b = b.clone();
            let mark = mark.clone();
            let n = n.clone();
            entered(once_job(move || {
                let (en, s, r_opt) = p0;
                let i = p1;
                {
                    let stmt = or(&index(&b.stmts, &i), &dummy_stmt2());
                    prism_rtl::Turn::More(Rc::new(GivenStmt { env: en.clone(), st: s.clone(), s: stmt.clone(), mark: mark.clone(), last: &(&i + &Nat::from(1u32)) == &n, res_opt: r_opt.clone() }))
                }
            }))
        }) as Rc<dyn Fn(((check_expr::Env, check_types::St, Option<check_types::Ty>), Nat)) -> Rc<dyn prism_rtl::Job<(check_expr::Env, check_types::St, Option<check_types::Ty>)>>>
    }));
    match &res_opt {
        Some(t) => (t.clone(), st2.clone()),
        None => {
            let (v_, st3) = check_types::fresh_var(&st2, &false, &Text::from(""));
            (check_types::Ty::TySig(mark.clone(), Rc::new(v_.clone())), st3.clone())
        },
    }
}

/// The step machine of `InferGivenBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferGivenBlock: unbounded fn Env, St, Block, Text -> ((Ty, St))
/// ```
pub struct InferGivenBlock {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub b: ast::Block,
    pub mark: Text,
}

impl prism_rtl::Job<(check_types::Ty, check_types::St)> for InferGivenBlock {
    fn cycle(&self) -> prism_rtl::Turn<(check_types::Ty, check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let b = &self.b;
        let mark = &self.mark;
        let n = len(&b.stmts);
        let b = b.clone();
        let env = env.clone();
        let mark = mark.clone();
        let st = st.clone();
        call_value(fold_job(check_errors::range0(&n), (env.clone(), st.clone(), None), {
            let b = b.clone();
            let mark = mark.clone();
            let n = n.clone();
            Rc::new(move |(p0, p1): ((check_expr::Env, check_types::St, Option<check_types::Ty>), Nat)| {
                let b = b.clone();
                let mark = mark.clone();
                let n = n.clone();
                entered(once_job(move || {
                    let (en, s, r_opt) = p0;
                    let i = p1;
                    {
                        let stmt = or(&index(&b.stmts, &i), &dummy_stmt2());
                        prism_rtl::Turn::More(Rc::new(GivenStmt { env: en.clone(), st: s.clone(), s: stmt.clone(), mark: mark.clone(), last: &(&i + &Nat::from(1u32)) == &n, res_opt: r_opt.clone() }))
                    }
                }))
            }) as Rc<dyn Fn(((check_expr::Env, check_types::St, Option<check_types::Ty>), Nat)) -> Rc<dyn prism_rtl::Job<(check_expr::Env, check_types::St, Option<check_types::Ty>)>>>
        }), move |fold_23637: (check_expr::Env, check_types::St, Option<check_types::Ty>)| {
            let (env2, st2, res_opt) = fold_23637;
            match &res_opt {
                Some(t) => prism_rtl::Turn::Finished((t.clone(), st2.clone())),
                None => {
                    let (v_, st3) = check_types::fresh_var(&st2, &false, &Text::from(""));
                    prism_rtl::Turn::Finished((check_types::Ty::TySig(mark.clone(), Rc::new(v_.clone())), st3.clone()))
                },
            }
        })
    }
}

/// `Start InferGivenBlock, x`: what the function value is when passed to `@Run`.
pub fn start_infer_given_block(env: check_expr::Env, st: check_types::St, b: ast::Block, mark: Text) -> Rc<dyn prism_rtl::Job<(check_types::Ty, check_types::St)>> {
    Rc::new(InferGivenBlock { env, st, b, mark })
}

/// ```prism
/// GivenStmt: unbounded fn Env, St, Stmt, Text, Bool, ?Ty -> ((Env, St, ?Ty))
/// ```
pub fn given_stmt(env: &check_expr::Env, st: &check_types::St, s: &ast::Stmt, mark: &Text, last: &bool, res_opt: &Option<check_types::Ty>) -> (check_expr::Env, check_types::St, Option<check_types::Ty>) {
    match &s.kind {
        ast::StmtKind::SBind(p_, e, None) => {
            let (t, st1) = check_expr::infer(env, st, e);
            let (v_, st2) = check_types::fresh_var(&st1, &false, &Text::from(""));
            let st3 = check_types::unify(&st2, &check_types::Ty::TySig(mark.clone(), Rc::new(v_.clone())), &t, &e.span);
            let (env2, st4) = check_expr::bind_pattern(&unpending(env), &st3, p_, &v_, &true);
            (env2.clone(), st4.clone(), res_opt.clone())
        },
        ast::StmtKind::SRequire(c) => (env.clone(), check_expr::check_cond(env, st, c), res_opt.clone()),
        ast::StmtKind::SForbid(c) => (env.clone(), check_expr::check_cond(env, st, c), res_opt.clone()),
        ast::StmtKind::SLet(p_, ty_opt, e) => {
            let (env2, st2) = check_expr::check_let(env, st, p_, ty_opt, e, &s.span);
            (env2.clone(), st2.clone(), res_opt.clone())
        },
        ast::StmtKind::SFn(f) => {
            let (env1, st1) = check_expr::pre_bind(env, st, s);
            let (env2, st2) = check_expr::check_local_fn(&env1, &st1, f, &s.span);
            (env2.clone(), st2.clone(), res_opt.clone())
        },
        ast::StmtKind::SSignature(_) => {
            let (env2, st2) = check_expr::pre_bind(env, st, s);
            (env2.clone(), st2.clone(), res_opt.clone())
        },
        ast::StmtKind::SExpr(e) => if *last {
            {
                let (t, st1) = check_expr::infer(env, st, e);
                let (v_, st2) = check_types::fresh_var(&st1, &false, &Text::from(""));
                let st3 = check_types::unify(&st2, &check_types::Ty::TySig(mark.clone(), Rc::new(v_.clone())), &t, &e.span);
                (env.clone(), st3.clone(), Some(check_types::Ty::TySig(mark.clone(), Rc::new(v_.clone()))))
            }
        } else {
            {
                let (t, st1) = check_expr::infer(env, st, e);
                (env.clone(), discarded(&st1, &t, &e.span), res_opt.clone())
            }
        },
        _ => (env.clone(), check_types::err(st, &Text::from("mismatch"), &s.span, &Text::from("this statement belongs in a widget or `update` block")), res_opt.clone()),
    }
}

/// The step machine of `GivenStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GivenStmt: unbounded fn Env, St, Stmt, Text, Bool, ?Ty -> ((Env, St, ?Ty))
/// ```
pub struct GivenStmt {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub s: ast::Stmt,
    pub mark: Text,
    pub last: bool,
    pub res_opt: Option<check_types::Ty>,
}

impl prism_rtl::Job<(check_expr::Env, check_types::St, Option<check_types::Ty>)> for GivenStmt {
    fn cycle(&self) -> prism_rtl::Turn<(check_expr::Env, check_types::St, Option<check_types::Ty>)> {
        let env = &self.env;
        let st = &self.st;
        let s = &self.s;
        let mark = &self.mark;
        let last = &self.last;
        let res_opt = &self.res_opt;
        match &s.kind {
            ast::StmtKind::SBind(p_, e, None) => {
                let res_opt = res_opt.clone();
                let e = e.clone();
                let env = env.clone();
                let mark = mark.clone();
                let p_ = p_.clone();
                let st = st.clone();
                call_then(check_expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_24112: (check_types::Ty, check_types::St)| {
                    let (t, st1) = infer_24112;
                    let (v_, st2) = check_types::fresh_var(&st1, &false, &Text::from(""));
                    call_then(check_types::start_unify(st2.clone(), check_types::Ty::TySig(mark.clone(), Rc::new(v_.clone())), t.clone(), e.span.clone()), move |unify_24196: check_types::St| {
                        let st3 = unify_24196;
                        call_then(check_expr::start_bind_pattern(unpending(&env), st3.clone(), p_.clone(), v_.clone(), true), move |bind_pattern_24262: (check_expr::Env, check_types::St)| {
                            let (env2, st4) = bind_pattern_24262;
                            prism_rtl::Turn::Finished((env2.clone(), st4.clone(), res_opt.clone()))
                        })
                    })
                })
            },
            ast::StmtKind::SRequire(c) => {
                let res_opt = res_opt.clone();
                let c = c.clone();
                let env = env.clone();
                let st = st.clone();
                call_then(check_expr::start_check_cond(env.clone(), st.clone(), c.clone()), move |check_cond_24359: check_types::St| prism_rtl::Turn::Finished((env.clone(), check_cond_24359, res_opt.clone())))
            },
            ast::StmtKind::SForbid(c) => {
                let res_opt = res_opt.clone();
                let c = c.clone();
                let env = env.clone();
                let st = st.clone();
                call_then(check_expr::start_check_cond(env.clone(), st.clone(), c.clone()), move |check_cond_24412: check_types::St| prism_rtl::Turn::Finished((env.clone(), check_cond_24412, res_opt.clone())))
            },
            ast::StmtKind::SLet(p_, ty_opt, e) => {
                let res_opt = res_opt.clone();
                let ty_opt = ty_opt.clone();
                let e = e.clone();
                let env = env.clone();
                let p_ = p_.clone();
                let s = s.clone();
                let st = st.clone();
                call_then(check_expr::start_check_let(env.clone(), st.clone(), p_.clone(), ty_opt.clone(), e.clone(), s.span.clone()), move |check_let_24490: (check_expr::Env, check_types::St)| {
                    let (env2, st2) = check_let_24490;
                    prism_rtl::Turn::Finished((env2.clone(), st2.clone(), res_opt.clone()))
                })
            },
            ast::StmtKind::SFn(f) => {
                let res_opt = res_opt.clone();
                let env = env.clone();
                let f = f.clone();
                let s = s.clone();
                let st = st.clone();
                call_then(check_expr::start_pre_bind(env.clone(), st.clone(), s.clone()), move |pre_bind_24593: (check_expr::Env, check_types::St)| {
                    let (env1, st1) = pre_bind_24593;
                    call_then(check_expr::start_check_local_fn(env1.clone(), st1.clone(), f.clone(), s.span.clone()), move |check_local_fn_24640: (check_expr::Env, check_types::St)| {
                        let (env2, st2) = check_local_fn_24640;
                        prism_rtl::Turn::Finished((env2.clone(), st2.clone(), res_opt.clone()))
                    })
                })
            },
            ast::StmtKind::SSignature(_) => {
                let res_opt = res_opt.clone();
                let env = env.clone();
                let s = s.clone();
                let st = st.clone();
                call_then(check_expr::start_pre_bind(env.clone(), st.clone(), s.clone()), move |pre_bind_24753: (check_expr::Env, check_types::St)| {
                    let (env2, st2) = pre_bind_24753;
                    prism_rtl::Turn::Finished((env2.clone(), st2.clone(), res_opt.clone()))
                })
            },
            ast::StmtKind::SExpr(e) => if *last {
                {
                    let e = e.clone();
                    let env = env.clone();
                    let last = *last;
                    let mark = mark.clone();
                    let st = st.clone();
                    call_then(check_expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_24859: (check_types::Ty, check_types::St)| {
                        let (t, st1) = infer_24859;
                        let (v_, st2) = check_types::fresh_var(&st1, &false, &Text::from(""));
                        call_then(check_types::start_unify(st2.clone(), check_types::Ty::TySig(mark.clone(), Rc::new(v_.clone())), t.clone(), e.span.clone()), move |unify_24951: check_types::St| {
                            let st3 = unify_24951;
                            prism_rtl::Turn::Finished((env.clone(), st3.clone(), Some(check_types::Ty::TySig(mark.clone(), Rc::new(v_.clone())))))
                        })
                    })
                }
            } else {
                {
                    let res_opt = res_opt.clone();
                    let e = e.clone();
                    let env = env.clone();
                    let st = st.clone();
                    call_then(check_expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_25218: (check_types::Ty, check_types::St)| {
                        let (t, st1) = infer_25218;
                        call_then(start_discarded(st1.clone(), t.clone(), e.span.clone()), move |discarded_25255: check_types::St| prism_rtl::Turn::Finished((env.clone(), discarded_25255, res_opt.clone())))
                    })
                }
            },
            _ => prism_rtl::Turn::Finished((env.clone(), check_types::err(st, &Text::from("mismatch"), &s.span, &Text::from("this statement belongs in a widget or `update` block")), res_opt.clone())),
        }
    }
}

/// `Start GivenStmt, x`: what the function value is when passed to `@Run`.
pub fn start_given_stmt(env: check_expr::Env, st: check_types::St, s: ast::Stmt, mark: Text, last: bool, res_opt: Option<check_types::Ty>) -> Rc<dyn prism_rtl::Job<(check_expr::Env, check_types::St, Option<check_types::Ty>)>> {
    Rc::new(GivenStmt { env, st, s, mark, last, res_opt })
}

/// ```prism
/// InferUpdate: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
/// ```
pub fn infer_update(env: &check_expr::Env, st: &check_types::St, target: &ast::Expr, body: &ast::Block, span: &ast::Range) -> (check_types::Ty, check_types::St) {
    let (t, st1) = check_expr::infer(env, st, target);
    let sh = check_types::head_sigil(&st1, &t);
    let st2 = if check_expr::is_time_sigil(&sh) || (&sh == &Text::from("@")) {
        check_types::err_fix(&st1, &Text::from("time-in-update"), &target.span, &Text::from(format!("`update` over a `{}`", &check_types::show_ty(&st1, &t))), &Text::from("update the plain value, and lift the function that does it"))
    } else {
        st1.clone()
    };
    let env2 = {
        let mut this: check_expr::Env = with_topic(env, &Text::from("&_"), &t);
        this.in_update = true;
        this
    };
    let (_, st3) = update_stmts(&env2, &st2, &body.stmts);
    let st4 = check_passes::and_block_checks(&env2, &st3, body, &t);
    (t.clone(), st4.clone())
}

/// The step machine of `InferUpdate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferUpdate: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
/// ```
pub struct InferUpdate {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub target: ast::Expr,
    pub body: ast::Block,
    pub span: ast::Range,
}

impl prism_rtl::Job<(check_types::Ty, check_types::St)> for InferUpdate {
    fn cycle(&self) -> prism_rtl::Turn<(check_types::Ty, check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let target = &self.target;
        let body = &self.body;
        let span = &self.span;
        let body = body.clone();
        let env = env.clone();
        let span = span.clone();
        let st = st.clone();
        let target = target.clone();
        call_then(check_expr::start_infer(env.clone(), st.clone(), target.clone()), move |infer_25934: (check_types::Ty, check_types::St)| {
            let (t, st1) = infer_25934;
            call_then(check_types::start_head_sigil(st1.clone(), t.clone()), move |head_sigil_25969: Text| {
                let sh = head_sigil_25969;
                let st2 = if check_expr::is_time_sigil(&sh) || (&sh == &Text::from("@")) {
                    check_types::err_fix(&st1, &Text::from("time-in-update"), &target.span, &Text::from(format!("`update` over a `{}`", &check_types::show_ty(&st1, &t))), &Text::from("update the plain value, and lift the function that does it"))
                } else {
                    st1.clone()
                };
                let env2 = {
                    let mut this: check_expr::Env = with_topic(&env, &Text::from("&_"), &t);
                    this.in_update = true;
                    this
                };
                call_then(start_update_stmts(env2.clone(), st2.clone(), body.stmts.clone()), move |update_stmts_26287: (check_expr::Env, check_types::St)| {
                    let (_, st3) = update_stmts_26287;
                    call_then(check_passes::start_and_block_checks(env2.clone(), st3.clone(), body.clone(), t.clone()), move |and_block_checks_26335: check_types::St| {
                        let st4 = and_block_checks_26335;
                        prism_rtl::Turn::Finished((t.clone(), st4.clone()))
                    })
                })
            })
        })
    }
}

/// `Start InferUpdate, x`: what the function value is when passed to `@Run`.
pub fn start_infer_update(env: check_expr::Env, st: check_types::St, target: ast::Expr, body: ast::Block, span: ast::Range) -> Rc<dyn prism_rtl::Job<(check_types::Ty, check_types::St)>> {
    Rc::new(InferUpdate { env, st, target, body, span })
}

/// ```prism
/// UpdateStmts: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub fn update_stmts(env: &check_expr::Env, st: &check_types::St, stmts: &Array<ast::Stmt>) -> (check_expr::Env, check_types::St) {
    run_to_end(fold_job(stmts.clone(), (env.clone(), st.clone()), Rc::new(move |(p0, p1): ((check_expr::Env, check_types::St), ast::Stmt)| entered(once_job(move || {
        let (en, s) = p0;
        let stmt = p1;
        prism_rtl::Turn::More(Rc::new(UpdateStmt { env: en.clone(), st: s.clone(), s: stmt.clone() }))
    }))) as Rc<dyn Fn(((check_expr::Env, check_types::St), ast::Stmt)) -> Rc<dyn prism_rtl::Job<(check_expr::Env, check_types::St)>>>))
}

/// The step machine of `UpdateStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateStmts: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub struct UpdateStmts {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub stmts: Array<ast::Stmt>,
}

impl prism_rtl::Job<(check_expr::Env, check_types::St)> for UpdateStmts {
    fn cycle(&self) -> prism_rtl::Turn<(check_expr::Env, check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let stmts = &self.stmts;
        fold_job(stmts.clone(), (env.clone(), st.clone()), Rc::new(move |(p0, p1): ((check_expr::Env, check_types::St), ast::Stmt)| entered(once_job(move || {
            let (en, s) = p0;
            let stmt = p1;
            prism_rtl::Turn::More(Rc::new(UpdateStmt { env: en.clone(), st: s.clone(), s: stmt.clone() }))
        }))) as Rc<dyn Fn(((check_expr::Env, check_types::St), ast::Stmt)) -> Rc<dyn prism_rtl::Job<(check_expr::Env, check_types::St)>>>).cycle()
    }
}

/// `Start UpdateStmts, x`: what the function value is when passed to `@Run`.
pub fn start_update_stmts(env: check_expr::Env, st: check_types::St, stmts: Array<ast::Stmt>) -> Rc<dyn prism_rtl::Job<(check_expr::Env, check_types::St)>> {
    Rc::new(UpdateStmts { env, st, stmts })
}

/// ```prism
/// UpdateStmt: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub fn update_stmt(env: &check_expr::Env, st: &check_types::St, s: &ast::Stmt) -> (check_expr::Env, check_types::St) {
    match &s.kind {
        ast::StmtKind::SSet(target, value) => {
            let (tt, st1) = check_expr::infer(env, st, target);
            let st2 = ref_target(env, &st1, target);
            (env.clone(), check_expr::check(env, &st2, value, &tt))
        },
        ast::StmtKind::SAccum(target, op, value) => {
            let (tt, st1) = check_expr::infer(env, st, target);
            let st2 = ref_target(env, &st1, target);
            let st3 = check_expr::check(env, &st2, value, &tt);
            let st4 = check_expr::add_want(&st3, &Text::from("Prelude.Num"), &tt, &s.span);
            let st5 = if op == &Text::from("-=") {
                check_expr::add_want(&st4, &Text::from("Prelude.Sub"), &tt, &s.span)
            } else {
                st4.clone()
            };
            (env.clone(), st5.clone())
        },
        ast::StmtKind::SLet(p_, ty_opt, e) => {
            let (t, st1) = check_expr::infer(env, st, e);
            let st2 = match ty_opt {
                Some(ty) => {
                    let (at, s2) = check_env::conv_type(&check_expr::env_cx(env), &st1, ty);
                    check_types::unify(&s2, &at, &t, &e.span)
                },
                None => st1.clone(),
            };
            let (env2, st3) = check_expr::bind_pattern(&unpending(env), &st2, p_, &t, &false);
            (env2.clone(), st3.clone())
        },
        ast::StmtKind::SWhile(c, body) => (env.clone(), update_while(env, st, c, body)),
        ast::StmtKind::SExpr(e) => match &*e.kind {
            ast::ExprKind::EIf(c, then_b, else_b_opt) => (env.clone(), update_if(env, st, &**c, then_b, else_b_opt)),
            ast::ExprKind::EMatch(scrut, arms) => (env.clone(), update_match(env, st, &**scrut, arms, &e.span)),
            ast::ExprKind::EFor(binders_opt, source, body) => (env.clone(), update_for(env, st, binders_opt, &**source, body, &e.span)),
            _ => {
                let (t, st1) = check_expr::infer(env, st, e);
                (env.clone(), discarded(&st1, &t, &e.span))
            },
        },
        ast::StmtKind::SFn(f) => {
            let (env1, st1) = check_expr::pre_bind(env, st, s);
            check_expr::check_local_fn(&env1, &st1, f, &s.span)
        },
        ast::StmtKind::SSignature(_) => check_expr::pre_bind(env, st, s),
        _ => (env.clone(), check_types::err(st, &Text::from("mismatch"), &s.span, &Text::from("this statement belongs in a widget or `given:` block"))),
    }
}

/// The step machine of `UpdateStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateStmt: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub struct UpdateStmt {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub s: ast::Stmt,
}

impl prism_rtl::Job<(check_expr::Env, check_types::St)> for UpdateStmt {
    fn cycle(&self) -> prism_rtl::Turn<(check_expr::Env, check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let s = &self.s;
        match &s.kind {
            ast::StmtKind::SSet(target, value) => {
                let env = env.clone();
                let st = st.clone();
                let target = target.clone();
                let value = value.clone();
                call_then(check_expr::start_infer(env.clone(), st.clone(), target.clone()), move |infer_26687: (check_types::Ty, check_types::St)| {
                    let (tt, st1) = infer_26687;
                    let st2 = ref_target(&env, &st1, &target);
                    call_then(check_expr::start_check(env.clone(), st2.clone(), value.clone(), tt.clone()), move |check_26770: check_types::St| prism_rtl::Turn::Finished((env.clone(), check_26770)))
                })
            },
            ast::StmtKind::SAccum(target, op, value) => {
                let env = env.clone();
                let op = op.clone();
                let s = s.clone();
                let st = st.clone();
                let target = target.clone();
                let value = value.clone();
                call_then(check_expr::start_infer(env.clone(), st.clone(), target.clone()), move |infer_26855: (check_types::Ty, check_types::St)| {
                    let (tt, st1) = infer_26855;
                    let st2 = ref_target(&env, &st1, &target);
                    call_then(check_expr::start_check(env.clone(), st2.clone(), value.clone(), tt.clone()), move |check_26940: check_types::St| {
                        let st3 = check_26940;
                        let st4 = check_expr::add_want(&st3, &Text::from("Prelude.Num"), &tt, &s.span);
                        let st5 = if &op == &Text::from("-=") {
                            check_expr::add_want(&st4, &Text::from("Prelude.Sub"), &tt, &s.span)
                        } else {
                            st4.clone()
                        };
                        prism_rtl::Turn::Finished((env.clone(), st5.clone()))
                    })
                })
            },
            ast::StmtKind::SLet(p_, ty_opt, e) => {
                let ty_opt = ty_opt.clone();
                let e = e.clone();
                let env = env.clone();
                let p_ = p_.clone();
                let st = st.clone();
                call_then(check_expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_27171: (check_types::Ty, check_types::St)| {
                    let (t, st1) = infer_27171;
                    let st2 = match &ty_opt {
                        Some(ty) => {
                            let (at, s2) = check_env::conv_type(&check_expr::env_cx(&env), &st1, ty);
                            check_types::unify(&s2, &at, &t, &e.span)
                        },
                        None => st1.clone(),
                    };
                    call_then(check_expr::start_bind_pattern(unpending(&env), st2.clone(), p_.clone(), t.clone(), false), move |bind_pattern_27387: (check_expr::Env, check_types::St)| {
                        let (env2, st3) = bind_pattern_27387;
                        prism_rtl::Turn::Finished((env2.clone(), st3.clone()))
                    })
                })
            },
            ast::StmtKind::SWhile(c, body) => {
                let body = body.clone();
                let c = c.clone();
                let env = env.clone();
                let st = st.clone();
                call_then(start_update_while(env.clone(), st.clone(), c.clone(), body.clone()), move |update_while_27483: check_types::St| prism_rtl::Turn::Finished((env.clone(), update_while_27483)))
            },
            ast::StmtKind::SExpr(e) => match &*e.kind {
                ast::ExprKind::EIf(c, then_b, else_b_opt) => {
                    let else_b_opt = else_b_opt.clone();
                    let c = (**c).clone();
                    let env = env.clone();
                    let st = st.clone();
                    let then_b = then_b.clone();
                    call_then(start_update_if(env.clone(), st.clone(), c.clone(), then_b.clone(), else_b_opt.clone()), move |update_if_27580: check_types::St| prism_rtl::Turn::Finished((env.clone(), update_if_27580)))
                },
                ast::ExprKind::EMatch(scrut, arms) => {
                    let arms = arms.clone();
                    let e = e.clone();
                    let env = env.clone();
                    let scrut = (**scrut).clone();
                    let st = st.clone();
                    call_then(start_update_match(env.clone(), st.clone(), scrut.clone(), arms.clone(), e.span.clone()), move |update_match_27654: check_types::St| prism_rtl::Turn::Finished((env.clone(), update_match_27654)))
                },
                ast::ExprKind::EFor(binders_opt, source, body) => {
                    let binders_opt = binders_opt.clone();
                    let body = body.clone();
                    let e = e.clone();
                    let env = env.clone();
                    let source = (**source).clone();
                    let st = st.clone();
                    call_then(start_update_for(env.clone(), st.clone(), binders_opt.clone(), source.clone(), body.clone(), e.span.clone()), move |update_for_27743: check_types::St| prism_rtl::Turn::Finished((env.clone(), update_for_27743)))
                },
                _ => {
                    let e = e.clone();
                    let env = env.clone();
                    let st = st.clone();
                    call_then(check_expr::start_infer(env.clone(), st.clone(), e.clone()), move |infer_27844: (check_types::Ty, check_types::St)| {
                        let (t, st1) = infer_27844;
                        call_then(start_discarded(st1.clone(), t.clone(), e.span.clone()), move |discarded_27881: check_types::St| prism_rtl::Turn::Finished((env.clone(), discarded_27881)))
                    })
                },
            },
            ast::StmtKind::SFn(f) => {
                let env = env.clone();
                let f = f.clone();
                let s = s.clone();
                let st = st.clone();
                call_then(check_expr::start_pre_bind(env.clone(), st.clone(), s.clone()), move |pre_bind_27948: (check_expr::Env, check_types::St)| {
                    let (env1, st1) = pre_bind_27948;
                    prism_rtl::Turn::More(Rc::new(check_expr::CheckLocalFn { env: env1.clone(), st: st1.clone(), f: f.clone(), span: s.span.clone() }))
                })
            },
            ast::StmtKind::SSignature(_) => prism_rtl::Turn::More(Rc::new(check_expr::PreBind { env: env.clone(), st: st.clone(), s: s.clone() })),
            _ => prism_rtl::Turn::Finished((env.clone(), check_types::err(st, &Text::from("mismatch"), &s.span, &Text::from("this statement belongs in a widget or `given:` block")))),
        }
    }
}

/// `Start UpdateStmt, x`: what the function value is when passed to `@Run`.
pub fn start_update_stmt(env: check_expr::Env, st: check_types::St, s: ast::Stmt) -> Rc<dyn prism_rtl::Job<(check_expr::Env, check_types::St)>> {
    Rc::new(UpdateStmt { env, st, s })
}

/// ```prism
/// RefTarget: fn Env, St, Expr -> St
/// ```
pub fn ref_target(env: &check_expr::Env, st: &check_types::St, e: &ast::Expr) -> check_types::St {
    if is_ref(e) {
        st.clone()
    } else {
        check_types::err_fix(st, &Text::from("mismatch"), &e.span, &Text::from("the left of `<=` is a reference: `&_`, a local `&x`, or a path from one"), &Text::from(format!("write `&_.{}`, or make a local with `let &x = ...`", &check_expr::src_text(env, &e.span))))
    }
}

/// ```prism
/// IsRef: fn Expr -> Bool
/// ```
pub fn is_ref(e: &ast::Expr) -> bool {
    match &*e.kind {
        ast::ExprKind::EName(n) => &take_text(&n.sigils, &Nat::from(1u32)) == &Text::from("&"),
        ast::ExprKind::EField(r, _, _) => is_ref(&**r),
        ast::ExprKind::EIndex(r, _) => is_ref(&**r),
        ast::ExprKind::EGroup(x) => is_ref(&**x),
        _ => false,
    }
}

/// ```prism
/// UpdateIf: unbounded fn Env, St, Cond, Block, ?Block -> St
/// ```
pub fn update_if(env: &check_expr::Env, st: &check_types::St, c: &ast::Cond, then_b: &ast::Block, else_b_opt: &Option<ast::Block>) -> check_types::St {
    let (env2, st1) = match c {
        ast::Cond::CondExpr(e) => (env.clone(), check_expr::check_cond(env, st, &**e)),
        ast::Cond::CondBind(p_, e, gd_opt) => {
            let (et, s1) = check_expr::infer(env, st, &**e);
            let (en, s2) = check_expr::bind_pattern(&unpending(env), &s1, p_, &et, &true);
            match &**gd_opt {
                Some(g) => (en.clone(), check_expr::check_cond(&en, &s2, g)),
                None => (en.clone(), s2.clone()),
            }
        },
    };
    let (_, st2) = update_stmts(&env2, &st1, &then_b.stmts);
    match else_b_opt {
        Some(b) => {
            let (_, st3) = update_stmts(env, &st2, &b.stmts);
            st3.clone()
        },
        None => st2.clone(),
    }
}

/// The step machine of `UpdateIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateIf: unbounded fn Env, St, Cond, Block, ?Block -> St
/// ```
pub struct UpdateIf {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub c: ast::Cond,
    pub then_b: ast::Block,
    pub else_b_opt: Option<ast::Block>,
}

impl prism_rtl::Job<check_types::St> for UpdateIf {
    fn cycle(&self) -> prism_rtl::Turn<check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let c = &self.c;
        let then_b = &self.then_b;
        let else_b_opt = &self.else_b_opt;
        let (env2, st1) = match c {
            ast::Cond::CondExpr(e) => (env.clone(), check_expr::check_cond(env, st, &**e)),
            ast::Cond::CondBind(p_, e, gd_opt) => {
                let (et, s1) = check_expr::infer(env, st, &**e);
                let (en, s2) = check_expr::bind_pattern(&unpending(env), &s1, p_, &et, &true);
                match &**gd_opt {
                    Some(g) => (en.clone(), check_expr::check_cond(&en, &s2, g)),
                    None => (en.clone(), s2.clone()),
                }
            },
        };
        let else_b_opt = else_b_opt.clone();
        let env = env.clone();
        let then_b = then_b.clone();
        call_then(start_update_stmts(env2.clone(), st1.clone(), then_b.stmts.clone()), move |update_stmts_29165: (check_expr::Env, check_types::St)| {
            let (_, st2) = update_stmts_29165;
            match &else_b_opt {
                Some(b) => {
                    let b = b.clone();
                    call_then(start_update_stmts(env.clone(), st2.clone(), b.stmts.clone()), move |update_stmts_29265: (check_expr::Env, check_types::St)| {
                        let (_, st3) = update_stmts_29265;
                        prism_rtl::Turn::Finished(st3.clone())
                    })
                },
                None => prism_rtl::Turn::Finished(st2.clone()),
            }
        })
    }
}

/// `Start UpdateIf, x`: what the function value is when passed to `@Run`.
pub fn start_update_if(env: check_expr::Env, st: check_types::St, c: ast::Cond, then_b: ast::Block, else_b_opt: Option<ast::Block>) -> Rc<dyn prism_rtl::Job<check_types::St>> {
    Rc::new(UpdateIf { env, st, c, then_b, else_b_opt })
}

/// ```prism
/// UpdateMatch: unbounded fn Env, St, Expr, [Arm], Range -> St
/// ```
pub fn update_match(env: &check_expr::Env, st: &check_types::St, scrut: &ast::Expr, arms: &Array<ast::Arm>, span: &ast::Range) -> check_types::St {
    let (t, st1) = check_expr::infer(env, st, scrut);
    let st2 = run_to_end(fold_job(arms.clone(), st1.clone(), {
        let env = env.clone();
        let t = t.clone();
        Rc::new(move |(p0, p1): (check_types::St, ast::Arm)| {
            let env = env.clone();
            let t = t.clone();
            entered(once_job(move || {
                let s = p0;
                let arm = p1;
                {
                    let (env2, s1) = match &arm.pattern {
                        Some(p_) => check_expr::bind_pattern(&unpending(&env), &s, p_, &t, &true),
                        None => (env.clone(), s.clone()),
                    };
                    let s2 = match &arm.guard {
                        Some(gd) => check_expr::check_cond(&env2, &s1, gd),
                        None => s1.clone(),
                    };
                    call_then(start_update_stmts(env2.clone(), s2.clone(), arm.body.stmts.clone()), move |update_stmts_29774: (check_expr::Env, check_types::St)| {
                        let (_, s3) = update_stmts_29774;
                        prism_rtl::Turn::Finished(s3.clone())
                    })
                }
            }))
        }) as Rc<dyn Fn((check_types::St, ast::Arm)) -> Rc<dyn prism_rtl::Job<check_types::St>>>
    }));
    check_passes::match_coverage(env, &st2, &t, arms, span)
}

/// The step machine of `UpdateMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateMatch: unbounded fn Env, St, Expr, [Arm], Range -> St
/// ```
pub struct UpdateMatch {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub scrut: ast::Expr,
    pub arms: Array<ast::Arm>,
    pub span: ast::Range,
}

impl prism_rtl::Job<check_types::St> for UpdateMatch {
    fn cycle(&self) -> prism_rtl::Turn<check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let scrut = &self.scrut;
        let arms = &self.arms;
        let span = &self.span;
        let arms = arms.clone();
        let env = env.clone();
        let scrut = scrut.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(check_expr::start_infer(env.clone(), st.clone(), scrut.clone()), move |infer_29453: (check_types::Ty, check_types::St)| {
            let (t, st1) = infer_29453;
            call_value(fold_job(arms.clone(), st1.clone(), {
                let env = env.clone();
                let t = t.clone();
                Rc::new(move |(p0, p1): (check_types::St, ast::Arm)| {
                    let env = env.clone();
                    let t = t.clone();
                    entered(once_job(move || {
                        let s = p0;
                        let arm = p1;
                        {
                            let (env2, s1) = match &arm.pattern {
                                Some(p_) => check_expr::bind_pattern(&unpending(&env), &s, p_, &t, &true),
                                None => (env.clone(), s.clone()),
                            };
                            let s2 = match &arm.guard {
                                Some(gd) => check_expr::check_cond(&env2, &s1, gd),
                                None => s1.clone(),
                            };
                            call_then(start_update_stmts(env2.clone(), s2.clone(), arm.body.stmts.clone()), move |update_stmts_29774: (check_expr::Env, check_types::St)| {
                                let (_, s3) = update_stmts_29774;
                                prism_rtl::Turn::Finished(s3.clone())
                            })
                        }
                    }))
                }) as Rc<dyn Fn((check_types::St, ast::Arm)) -> Rc<dyn prism_rtl::Job<check_types::St>>>
            }), move |fold_29488: check_types::St| {
                let st2 = fold_29488;
                prism_rtl::Turn::More(Rc::new(check_passes::MatchCoverage { env: env.clone(), st: st2.clone(), t: t.clone(), arms: arms.clone(), span: span.clone() }))
            })
        })
    }
}

/// `Start UpdateMatch, x`: what the function value is when passed to `@Run`.
pub fn start_update_match(env: check_expr::Env, st: check_types::St, scrut: ast::Expr, arms: Array<ast::Arm>, span: ast::Range) -> Rc<dyn prism_rtl::Job<check_types::St>> {
    Rc::new(UpdateMatch { env, st, scrut, arms, span })
}

/// ```prism
/// UpdateWhile: unbounded fn Env, St, Cond, Block -> St
/// ```
pub fn update_while(env: &check_expr::Env, st: &check_types::St, c: &ast::Cond, body: &ast::Block) -> check_types::St {
    let (env2, st1) = match c {
        ast::Cond::CondExpr(e) => (env.clone(), check_expr::check_cond(env, st, &**e)),
        ast::Cond::CondBind(p_, e, gd_opt) => {
            let (et, s1) = check_expr::infer(env, st, &**e);
            let (en, s2) = check_expr::bind_pattern(&unpending(env), &s1, p_, &et, &true);
            match &**gd_opt {
                Some(g) => (en.clone(), check_expr::check_cond(&en, &s2, g)),
                None => (en.clone(), s2.clone()),
            }
        },
    };
    let (_, st2) = update_stmts(&env2, &st1, &body.stmts);
    st2.clone()
}

/// The step machine of `UpdateWhile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateWhile: unbounded fn Env, St, Cond, Block -> St
/// ```
pub struct UpdateWhile {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub c: ast::Cond,
    pub body: ast::Block,
}

impl prism_rtl::Job<check_types::St> for UpdateWhile {
    fn cycle(&self) -> prism_rtl::Turn<check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let c = &self.c;
        let body = &self.body;
        let (env2, st1) = match c {
            ast::Cond::CondExpr(e) => (env.clone(), check_expr::check_cond(env, st, &**e)),
            ast::Cond::CondBind(p_, e, gd_opt) => {
                let (et, s1) = check_expr::infer(env, st, &**e);
                let (en, s2) = check_expr::bind_pattern(&unpending(env), &s1, p_, &et, &true);
                match &**gd_opt {
                    Some(g) => (en.clone(), check_expr::check_cond(&en, &s2, g)),
                    None => (en.clone(), s2.clone()),
                }
            },
        };
        let body = body.clone();
        call_then(start_update_stmts(env2.clone(), st1.clone(), body.stmts.clone()), move |update_stmts_30409: (check_expr::Env, check_types::St)| {
            let (_, st2) = update_stmts_30409;
            prism_rtl::Turn::Finished(st2.clone())
        })
    }
}

/// `Start UpdateWhile, x`: what the function value is when passed to `@Run`.
pub fn start_update_while(env: check_expr::Env, st: check_types::St, c: ast::Cond, body: ast::Block) -> Rc<dyn prism_rtl::Job<check_types::St>> {
    Rc::new(UpdateWhile { env, st, c, body })
}

/// ```prism
/// UpdateFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> St
/// ```
pub fn update_for(env: &check_expr::Env, st: &check_types::St, binders_opt: &Option<ast::ForBinders>, source: &ast::Expr, body: &ast::Block, span: &ast::Range) -> check_types::St {
    let (t, st1) = check_expr::infer(env, st, source);
    let (k, v_, st2) = coll_parts(&st1, &t, &source.span);
    let env1 = loop_indices(env);
    let (env2, st3) = match binders_opt {
        None => (with_topic(&env1, &Text::from("&_"), &v_), st2.clone()),
        Some(bs) => match &bs.second {
            Some(second) => {
                let (e1, s1) = check_expr::bind_pattern(&unpending(&env1), &st2, &bs.first, &k, &false);
                check_expr::bind_pattern(&e1, &s1, second, &v_, &false)
            },
            None => check_expr::bind_pattern(&unpending(&env1), &st2, &bs.first, &v_, &false),
        },
    };
    let (_, st4) = update_stmts(&env2, &st3, &body.stmts);
    st4.clone()
}

/// The step machine of `UpdateFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> St
/// ```
pub struct UpdateFor {
    pub env: check_expr::Env,
    pub st: check_types::St,
    pub binders_opt: Option<ast::ForBinders>,
    pub source: ast::Expr,
    pub body: ast::Block,
    pub span: ast::Range,
}

impl prism_rtl::Job<check_types::St> for UpdateFor {
    fn cycle(&self) -> prism_rtl::Turn<check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let binders_opt = &self.binders_opt;
        let source = &self.source;
        let body = &self.body;
        let span = &self.span;
        let binders_opt = binders_opt.clone();
        let body = body.clone();
        let env = env.clone();
        let source = source.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(check_expr::start_infer(env.clone(), st.clone(), source.clone()), move |infer_30717: (check_types::Ty, check_types::St)| {
            let (t, st1) = infer_30717;
            call_then(start_coll_parts(st1.clone(), t.clone(), source.span.clone()), move |coll_parts_30763: (check_types::Ty, check_types::Ty, check_types::St)| {
                let (k, v_, st2) = coll_parts_30763;
                let env1 = loop_indices(&env);
                let (env2, st3) = match &binders_opt {
                    None => (with_topic(&env1, &Text::from("&_"), &v_), st2.clone()),
                    Some(bs) => match &bs.second {
                        Some(second) => {
                            let (e1, s1) = check_expr::bind_pattern(&unpending(&env1), &st2, &bs.first, &k, &false);
                            check_expr::bind_pattern(&e1, &s1, second, &v_, &false)
                        },
                        None => check_expr::bind_pattern(&unpending(&env1), &st2, &bs.first, &v_, &false),
                    },
                };
                call_then(start_update_stmts(env2.clone(), st3.clone(), body.stmts.clone()), move |update_stmts_31203: (check_expr::Env, check_types::St)| {
                    let (_, st4) = update_stmts_31203;
                    prism_rtl::Turn::Finished(st4.clone())
                })
            })
        })
    }
}

/// `Start UpdateFor, x`: what the function value is when passed to `@Run`.
pub fn start_update_for(env: check_expr::Env, st: check_types::St, binders_opt: Option<ast::ForBinders>, source: ast::Expr, body: ast::Block, span: ast::Range) -> Rc<dyn prism_rtl::Job<check_types::St>> {
    Rc::new(UpdateFor { env, st, binders_opt, source, body, span })
}
