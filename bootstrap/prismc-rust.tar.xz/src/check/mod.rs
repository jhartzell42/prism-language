//! The module `Check`, from `target/bootstrap/src/prismc/check/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;
pub mod blocks;
pub mod env;
pub mod errors;
pub mod expr;
pub mod passes;
pub mod regex;
pub mod shrink;
pub mod typed;
pub mod types;

/// `GrowthFound`:
///
/// ```prism
/// type GrowthFound = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct GrowthFound {
    pub st_p: crate::check::types::St,
    pub reported_p: crate::prelude::Array<crate::prelude::Text>,
    pub seen_p: crate::prelude::Map<crate::prelude::Text, bool>,
}

impl crate::prelude::Show for GrowthFound {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("GrowthFound", &[("st", &self.st_p), ("reported", &self.reported_p), ("seen", &self.seen_p)]);
    }
}

impl crate::prelude::ToPod for GrowthFound {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("GrowthFound", vec![("st", self.st_p.to_pod()), ("reported", self.reported_p.to_pod()), ("seen", self.seen_p.to_pod())])
    }
}

impl crate::prelude::FromPod for GrowthFound {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(GrowthFound { st_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "st")?)?, reported_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "reported")?)?, seen_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "seen")?)? })
    }
}

/// `GrowthStep`:
///
/// ```prism
/// type GrowthStep = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct GrowthStep {
    pub definition_p: crate::prelude::Text,
    pub types_p: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>,
    pub place_p: crate::prelude::Text,
}

impl crate::prelude::Show for GrowthStep {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("GrowthStep", &[("definition", &self.definition_p), ("types", &self.types_p), ("place", &self.place_p)]);
    }
}

impl crate::prelude::ToPod for GrowthStep {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("GrowthStep", vec![("definition", self.definition_p.to_pod()), ("types", self.types_p.to_pod()), ("place", self.place_p.to_pod())])
    }
}

impl crate::prelude::FromPod for GrowthStep {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(GrowthStep { definition_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "definition")?)?, types_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "types")?)?, place_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "place")?)? })
    }
}

/// `Report`:
///
/// ```prism
/// type Report = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Report {
    pub text_p: crate::prelude::Text,
    pub errors_p: crate::prelude::Nat,
    pub root_row_p: crate::prelude::Text,
    pub typed_p: crate::check::typed::TProgram,
}

impl crate::prelude::Show for Report {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Report", &[("text", &self.text_p), ("errors", &self.errors_p), ("rootRow", &self.root_row_p), ("typed", &self.typed_p)]);
    }
}

impl crate::prelude::ToPod for Report {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Report", vec![("text", self.text_p.to_pod()), ("errors", self.errors_p.to_pod()), ("rootRow", self.root_row_p.to_pod()), ("typed", self.typed_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Report {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Report { text_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "text")?)?, errors_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "errors")?)?, root_row_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "rootRow")?)?, typed_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "typed")?)? })
    }
}

/// ```prism
/// CheckProgram: unbounded fn [Src], [Module], [Text], Nat, Bool, Bool, [CDiag] -> Report
/// ```
pub fn check_program_f(srcs_p0: &crate::prelude::Array<crate::check::errors::Src>, trees_p1: &crate::prelude::Array<crate::syntax::Module>, world_p2: &crate::prelude::Array<crate::prelude::Text>, shown_p3: &crate::prelude::Nat, recording_p4: &bool, unused_p5: &bool, pre_p6: &crate::prelude::Array<crate::check::errors::CDiag>) -> Report {
    let (g0a_ph, stb_pi) = crate::check::env::build_g_f(srcs_p0, trees_p1);
    let g0_p7 = {
        let mut this: crate::check::env::G = g0a_ph.clone();
        this.prelude_from_p = shown_p3.clone();
        this
    };
    let st0_p8 = {
        let mut this: crate::check::types::St = stb_pi.clone();
        this.recording_p = *recording_p4;
        this
    };
    let (g1_pj, st1_pk) = top_lets_f(&g0_p7, &crate::check::env::decls::impls_complete_f(&g0_p7, &crate::check::env::decls::missing_definitions_f(&g0_p7, &st0_p8)));
    let (failed_pr, st2_ps) = crate::prelude::run_to_end(crate::prelude::fold_job(g1_pj.defs_p.clone(), (crate::prelude::Array::new(), st1_pk.clone()), {
        let g1_pjx = g1_pj.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::prelude::Text>, crate::check::types::St), crate::check::env::Def)| {
            let g1_pjxy = g1_pjx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (bad_pl, s_pm) = p0;
                let d_pn = p1;
                {
                    let before_po = crate::prelude::len(&s_pm.diags_p);
                    crate::prelude::call_then(start_check_def_f(g1_pjxy.clone(), s_pm.clone(), d_pn.clone()), move |check_def_f_2674: crate::check::types::St| {
                        let s2_pp = check_def_f_2674;
                        let bad2_pq = if &crate::prelude::len(&s2_pp.diags_p) > &before_po {
                            crate::prelude::push(&bad_pl, &crate::check::shrink::types::own_key_f(&d_pn).qk_p)
                        } else {
                            bad_pl.clone()
                        };
                        ::prism_rtl::Turn::Finished((bad2_pq.clone(), s2_pp.clone()))
                    })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::prelude::Text>, crate::check::types::St), crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, crate::check::types::St)>>>
    }));
    let st2b_p9 = {
        let mut this: crate::check::types::St = st2_ps.clone();
        this.level_p = crate::prelude::Nat::from(0u32);
        this
    };
    let st3_pa = crate::check::types::unify::undecided_f(&crate::check::env::traits::default_wants_f(&g1_pj, &crate::check::types::recording::faults_settled_f(&st2b_p9), &crate::prelude::Array::new()));
    let good_pb = crate::prelude::filter(&g1_pj.defs_p, &(|d_pt: &crate::check::env::Def| !crate::check::types::has_text_f(&failed_pr, &crate::check::shrink::types::own_key_f(d_pt).qk_p)));
    let (st4_pu, refs_pv) = crate::check::shrink::shrink_check_f(&g1_pj, &st3_pa, &good_pb);
    let (root_row_p10, st5_p11) = root_row_f(&g1_pj, &growth_check_f(&g1_pj, &st4_pu, &good_pb), world_p2);
    let warnings_pc = if *unused_p5 {
        crate::check::shrink::unused_defs_f(&good_pb, &refs_pv, shown_p3)
    } else {
        crate::prelude::Array::new()
    };
    let reached_pd = crate::check::shrink::test_only_reached_f(srcs_p0, &g1_pj.defs_p, &refs_pv);
    let diags_pe = crate::check::errors::sort_diags_f(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::filter(&st5_p11.diags_p, &(|d_p12: &crate::check::errors::CDiag| &d_p12.file_p < shown_p3)), &warnings_pc), pre_p6), &reached_pd));
    let text_pf = crate::prelude::concat(&crate::prelude::each(&diags_pe, &(|d_p13: &crate::check::errors::CDiag| crate::check::errors::render_cdiag_f(srcs_p0, d_p13))));
    let typed_pg = if *recording_p4 {
        typed_of_f(&g1_pj, &st5_p11, shown_p3)
    } else {
        crate::check::typed::empty_typed_p()
    };
    Report { text_p: text_pf.clone(), errors_p: crate::prelude::len(&crate::prelude::filter(&diags_pe, &(|d_p14: &crate::check::errors::CDiag| !crate::check::errors::is_warning_f(d_p14)))), root_row_p: root_row_p10.clone(), typed_p: typed_pg.clone() }
}

/// The step machine of `CheckProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckProgram: unbounded fn [Src], [Module], [Text], Nat, Bool, Bool, [CDiag] -> Report
/// ```
pub struct CheckProgram {
    pub srcs_p0: crate::prelude::Array<crate::check::errors::Src>,
    pub trees_p1: crate::prelude::Array<crate::syntax::Module>,
    pub world_p2: crate::prelude::Array<crate::prelude::Text>,
    pub shown_p3: crate::prelude::Nat,
    pub recording_p4: bool,
    pub unused_p5: bool,
    pub pre_p6: crate::prelude::Array<crate::check::errors::CDiag>,
}

impl ::prism_rtl::Job<Report> for CheckProgram {
    fn cycle(&self) -> ::prism_rtl::Turn<Report> {
        let srcs_p0 = &self.srcs_p0;
        let trees_p1 = &self.trees_p1;
        let world_p2 = &self.world_p2;
        let shown_p3 = &self.shown_p3;
        let recording_p4 = &self.recording_p4;
        let unused_p5 = &self.unused_p5;
        let pre_p6 = &self.pre_p6;
        let pre_p6x = pre_p6.clone();
        let recording_p4x = *recording_p4;
        let shown_p3x = shown_p3.clone();
        let srcs_p0x = srcs_p0.clone();
        let trees_p1x = trees_p1.clone();
        let unused_p5x = *unused_p5;
        let world_p2x = world_p2.clone();
        crate::prelude::call_then(crate::check::env::start_build_g_f(srcs_p0x.clone(), trees_p1x.clone()), move |build_g_f_2188: (crate::check::env::G, crate::check::types::St)| {
            let (g0a_ph, stb_pi) = build_g_f_2188;
            let g0_p7 = {
                let mut this: crate::check::env::G = g0a_ph.clone();
                this.prelude_from_p = shown_p3x.clone();
                this
            };
            let st0_p8 = {
                let mut this: crate::check::types::St = stb_pi.clone();
                this.recording_p = recording_p4x;
                this
            };
            crate::prelude::call_then(crate::check::env::decls::start_missing_definitions_f(g0_p7.clone(), st0_p8.clone()), move |missing_definitions_f_2523: crate::check::types::St| crate::prelude::call_then(crate::check::env::decls::start_impls_complete_f(g0_p7.clone(), missing_definitions_f_2523), move |impls_complete_f_2504: crate::check::types::St| crate::prelude::call_then(start_top_lets_f(g0_p7.clone(), impls_complete_f_2504), move |top_lets_f_2491: (crate::check::env::G, crate::check::types::St)| {
                let (g1_pj, st1_pk) = top_lets_f_2491;
                crate::prelude::call_value(crate::prelude::fold_job(g1_pj.defs_p.clone(), (crate::prelude::Array::new(), st1_pk.clone()), {
                    let g1_pjx = g1_pj.clone();
                    ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Array<crate::prelude::Text>, crate::check::types::St), crate::check::env::Def)| {
                        let g1_pjxy = g1_pjx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (bad_pl, s_pm) = p0;
                            let d_pn = p1;
                            {
                                let before_po = crate::prelude::len(&s_pm.diags_p);
                                crate::prelude::call_then(start_check_def_f(g1_pjxy.clone(), s_pm.clone(), d_pn.clone()), move |check_def_f_2674: crate::check::types::St| {
                                    let s2_pp = check_def_f_2674;
                                    let bad2_pq = if &crate::prelude::len(&s2_pp.diags_p) > &before_po {
                                        crate::prelude::push(&bad_pl, &crate::check::shrink::types::own_key_f(&d_pn).qk_p)
                                    } else {
                                        bad_pl.clone()
                                    };
                                    ::prism_rtl::Turn::Finished((bad2_pq.clone(), s2_pp.clone()))
                                })
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Array<crate::prelude::Text>, crate::check::types::St), crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::prelude::Text>, crate::check::types::St)>>>
                }), move |fold_2578: (crate::prelude::Array<crate::prelude::Text>, crate::check::types::St)| {
                    let (failed_pr, st2_ps) = fold_2578;
                    let st2b_p9 = {
                        let mut this: crate::check::types::St = st2_ps.clone();
                        this.level_p = crate::prelude::Nat::from(0u32);
                        this
                    };
                    crate::prelude::call_then(crate::check::types::recording::start_faults_settled_f(st2b_p9.clone()), move |faults_settled_f_2886: crate::check::types::St| crate::prelude::call_then(crate::check::env::traits::start_default_wants_f(g1_pj.clone(), faults_settled_f_2886, crate::prelude::Array::new()), move |default_wants_f_2868: crate::check::types::St| crate::prelude::call_then(crate::check::types::unify::start_undecided_f(default_wants_f_2868), move |undecided_f_2857: crate::check::types::St| {
                        let st3_pa = undecided_f_2857;
                        let good_pb = crate::prelude::filter(&g1_pj.defs_p, &(|d_pt: &crate::check::env::Def| !crate::check::types::has_text_f(&failed_pr, &crate::check::shrink::types::own_key_f(d_pt).qk_p)));
                        crate::prelude::call_then(crate::check::shrink::start_shrink_check_f(g1_pj.clone(), st3_pa.clone(), good_pb.clone()), move |shrink_check_f_3156: (crate::check::types::St, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>)| {
                            let (st4_pu, refs_pv) = shrink_check_f_3156;
                            crate::prelude::call_then(start_growth_check_f(g1_pj.clone(), st4_pu.clone(), good_pb.clone()), move |growth_check_f_3222: crate::check::types::St| crate::prelude::call_then(start_root_row_f(g1_pj.clone(), growth_check_f_3222, world_p2x.clone()), move |root_row_f_3209: (crate::prelude::Text, crate::check::types::St)| {
                                let (root_row_p10, st5_p11) = root_row_f_3209;
                                let g1_pjz = g1_pj.clone();
                                let pre_p6xz = pre_p6x.clone();
                                let recording_p4xz = recording_p4x;
                                let refs_pvz = refs_pv.clone();
                                let root_row_p10z = root_row_p10.clone();
                                let shown_p3xz = shown_p3x.clone();
                                let srcs_p0xz = srcs_p0x.clone();
                                let st5_p11z = st5_p11.clone();
                                let k_let3260 = move |v3260: crate::prelude::Array<crate::check::errors::CDiag>| {
                                    let warnings_pc = v3260;
                                    let reached_pd = crate::check::shrink::test_only_reached_f(&srcs_p0xz, &g1_pjz.defs_p, &refs_pvz);
                                    let diags_pe = crate::check::errors::sort_diags_f(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::filter(&st5_p11z.diags_p, &(|d_p12: &crate::check::errors::CDiag| &d_p12.file_p < &shown_p3xz)), &warnings_pc), &pre_p6xz), &reached_pd));
                                    let text_pf = crate::prelude::concat(&crate::prelude::each(&diags_pe, &(|d_p13: &crate::check::errors::CDiag| crate::check::errors::render_cdiag_f(&srcs_p0xz, d_p13))));
                                    let diags_pez = diags_pe.clone();
                                    let root_row_p10zz = root_row_p10z.clone();
                                    let text_pfz = text_pf.clone();
                                    let k_let3562 = move |v3562: crate::check::typed::TProgram| {
                                        let typed_pg = v3562;
                                        ::prism_rtl::Turn::Finished(Report { text_p: text_pfz.clone(), errors_p: crate::prelude::len(&crate::prelude::filter(&diags_pez, &(|d_p14: &crate::check::errors::CDiag| !crate::check::errors::is_warning_f(d_p14)))), root_row_p: root_row_p10zz.clone(), typed_p: typed_pg.clone() })
                                    };
                                    if recording_p4xz {
                                        crate::prelude::call_then(start_typed_of_f(g1_pjz.clone(), st5_p11z.clone(), shown_p3xz.clone()), move |typed_of_f_3588: crate::check::typed::TProgram| k_let3562(typed_of_f_3588))
                                    } else {
                                        k_let3562(crate::check::typed::empty_typed_p())
                                    }
                                };
                                if unused_p5x {
                                    crate::prelude::call_then(crate::check::shrink::start_unused_defs_f(good_pb.clone(), refs_pv.clone(), shown_p3x.clone()), move |unused_defs_f_3286: crate::prelude::Array<crate::check::errors::CDiag>| k_let3260(unused_defs_f_3286))
                                } else {
                                    k_let3260(crate::prelude::Array::new())
                                }
                            }))
                        })
                    })))
                })
            })))
        })
    }
}

/// `Start CheckProgram, x`: what the function value is when passed to `@Run`.
pub fn start_check_program_f(srcs_p0: crate::prelude::Array<crate::check::errors::Src>, trees_p1: crate::prelude::Array<crate::syntax::Module>, world_p2: crate::prelude::Array<crate::prelude::Text>, shown_p3: crate::prelude::Nat, recording_p4: bool, unused_p5: bool, pre_p6: crate::prelude::Array<crate::check::errors::CDiag>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<Report>> {
    ::std::rc::Rc::new(CheckProgram { srcs_p0, trees_p1, world_p2, shown_p3, recording_p4, unused_p5, pre_p6 })
}

/// ```prism
/// GrowthCheck: unbounded fn G, St, [Def] -> St
/// ```
pub fn growth_check_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, defs_p2: &crate::prelude::Array<crate::check::env::Def>) -> crate::check::types::St {
    let named_p3 = crate::prelude::fold(defs_p2, &crate::prelude::Map::new(), &(|m_pa: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, d_pb: &crate::check::env::Def| match crate::prelude::get(&g_p0.vals_p, &d_pb.qk_p) {
        ::std::option::Option::Some(v_pc) => if crate::check::expr::is_generic_use_f(&v_pc) && is_named_def_f(d_pb) {
            crate::prelude::insert(m_pa, &d_pb.qk_p, &v_pc.scheme_p.qs_p)
        } else {
            m_pa.clone()
        },
        ::std::option::Option::None => m_pa.clone(),
    }));
    let impls_p4 = crate::prelude::fold(&crate::prelude::keys(&g_p0.impls_p), &crate::prelude::Map::new(), &(|m_pd: &crate::prelude::Map<crate::prelude::Text, crate::check::env::ImplInfo>, cls_pe: &crate::prelude::Text| crate::prelude::fold(&crate::prelude::or(&crate::prelude::get(&g_p0.impls_p, cls_pe), &crate::prelude::Array::new()), m_pd, &(|m2_pf: &crate::prelude::Map<crate::prelude::Text, crate::check::env::ImplInfo>, im_pg: &crate::check::env::ImplInfo| if im_pg.derived_p || (&crate::prelude::len(&im_pg.qs_p) == &crate::prelude::Nat::from(0u32)) {
        m2_pf.clone()
    } else {
        crate::prelude::insert(m2_pf, &crate::check::env::traits::impl_choice_f(im_pg), im_pg)
    }))));
    let generic_p5 = crate::prelude::fold(&crate::prelude::keys(&impls_p4), &named_p3, &(|m_ph: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, impl_key_pi: &crate::prelude::Text| match crate::prelude::get(&impls_p4, impl_key_pi) {
        ::std::option::Option::Some(im_pj) => crate::prelude::insert(m_ph, impl_key_pi, &im_pj.qs_p),
        ::std::option::Option::None => m_ph.clone(),
    }));
    let impl_of_p6 = crate::prelude::fold(defs_p2, &crate::prelude::Map::new(), &(|m_pk: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>, d_pl: &crate::check::env::Def| match &d_pl.body_p {
        crate::check::env::DefBody::DbMethod(_, _, im_pm) => crate::prelude::insert(m_pk, &crate::check::shrink::types::own_key_f(d_pl).qk_p, &crate::prelude::Text::from(format!("impl:{}.{}", &im_pm.file_p, &im_pm.span_p.start_p))),
        _ => m_pk.clone(),
    }));
    let shown_p7 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(&impls_p4), crate::prelude::Map::new(), {
        let impls_p4x = impls_p4.clone();
        let st_p1x = st_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>, crate::prelude::Text)| {
            let impls_p4xy = impls_p4x.clone();
            let st_p1xy = st_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_pn = p0;
                let impl_key_po = p1;
                match crate::prelude::get(&impls_p4xy, &impl_key_po) {
                    ::std::option::Option::Some(im_pp) => crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1xy.clone(), im_pp.head_p.clone()), move |show_ty_f_7722: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::insert(&m_pn, &impl_key_po, &crate::prelude::Text::from(format!("impl ^{} {}", &crate::check::types::bare_name_f(&im_pp.cls_p), &show_ty_f_7722))))),
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(m_pn.clone()),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>>>>
    }));
    let uses_by_p8 = crate::prelude::run_to_end(crate::prelude::fold_job(st_p1.generic_uses_p.clone(), crate::prelude::Map::new(), {
        let impl_of_p6x = impl_of_p6.clone();
        let generic_p5x = generic_p5.clone();
        let impls_p4x = impls_p4.clone();
        let st_p1x = st_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::check::types::GenericUse>>, crate::check::types::GenericUse)| {
            let impl_of_p6xy = impl_of_p6x.clone();
            let generic_p5xy = generic_p5x.clone();
            let impls_p4xy = impls_p4x.clone();
            let st_p1xy = st_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_pq = p0;
                let noted_pr = p1;
                {
                    let user_ps = crate::prelude::or(&crate::prelude::get(&impl_of_p6xy, &noted_pr.user_p), &noted_pr.user_p);
                    let own_pt = crate::prelude::or(&crate::prelude::get(&generic_p5xy, &user_ps), &crate::prelude::Array::new());
                    let generic_p5xyz = generic_p5xy.clone();
                    let m_pqz = m_pq.clone();
                    let noted_prz = noted_pr.clone();
                    let st_p1xyz = st_p1xy.clone();
                    let user_psz = user_ps.clone();
                    let k_let8077 = move |v8077: bool| {
                        let foreign_pu = v8077;
                        if ((crate::check::env::has_key_f(&generic_p5xyz, &user_psz) && crate::check::env::has_key_f(&generic_p5xyz, &noted_prz.target_p)) && !foreign_pu) && !crate::prelude::run_to_end(crate::prelude::fold_job(noted_prz.types_p.clone(), false, {
                            let st_p1xyzx = st_p1xyz.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::check::types::Ty))| {
                                let st_p1xyzxy = st_p1xyzx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let found_p13 = p0;
                                    let (_, t_p14) = p1;
                                    if found_p13 {
                                        ::prism_rtl::Turn::Finished(true)
                                    } else {
                                        crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p1xyzxy.clone(), t_p14.clone()), move |zonk_f_8517: crate::check::types::Ty| ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsAssociatedType { t_p0: zonk_f_8517 })))
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::check::types::Ty))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                        })) {
                            {
                                let read_p15 = {
                                    let mut this: crate::check::types::GenericUse = noted_prz.clone();
                                    this.user_p = user_psz.clone();
                                    this.types_p = crate::prelude::run_to_end(crate::prelude::each_job(this.types_p.clone(), {
                                        let st_p1xyzx = st_p1xyz.clone();
                                        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::check::types::Ty)| {
                                            let st_p1xyzxy = st_p1xyzx.clone();
                                            crate::prelude::entered(crate::prelude::once_job(move || {
                                                let (q_p16, t_p17) = p0;
                                                crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p1xyzxy.clone(), t_p17.clone()), move |zonk_f_8672: crate::check::types::Ty| crate::prelude::call_then(start_flex_named_f(zonk_f_8672), move |flex_named_f_8661: crate::check::types::Ty| ::prism_rtl::Turn::Finished((q_p16.clone(), flex_named_f_8661))))
                                            }))
                                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::Ty)>>>
                                    }));
                                    this
                                };
                                ::prism_rtl::Turn::Finished(crate::prelude::insert(&m_pqz, &user_psz, &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(&m_pqz, &user_psz), &crate::prelude::Array::new()), &read_p15)))
                            }
                        } else {
                            ::prism_rtl::Turn::Finished(m_pqz.clone())
                        }
                    };
                    if crate::check::env::has_key_f(&impls_p4xy, &user_ps) {
                        crate::prelude::call_value(crate::prelude::fold_job(noted_pr.types_p.clone(), false, {
                            let st_p1xyx = st_p1xy.clone();
                            let own_ptx = own_pt.clone();
                            ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::check::types::Ty))| {
                                let st_p1xyxy = st_p1xyx.clone();
                                let own_ptxy = own_ptx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let found_pv = p0;
                                    let (_, t_p10) = p1;
                                    if found_pv {
                                        ::prism_rtl::Turn::Finished(true)
                                    } else {
                                        crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p1xyxy.clone(), t_p10.clone()), move |zonk_f_8205: crate::check::types::Ty| crate::prelude::call_then(start_flex_named_f(zonk_f_8205), move |flex_named_f_8194: crate::check::types::Ty| crate::prelude::call_then(start_rigid_names_in_f(flex_named_f_8194), move |rigid_names_in_f_8180: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&rigid_names_in_f_8180, &false, &(|other_p11: &bool, q_p12: &crate::prelude::Text| *other_p11 || !crate::check::types::has_text_f(&own_ptxy, q_p12)))))))
                                    }
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::check::types::Ty))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                        }), move |fold_8116: bool| k_let8077(fold_8116))
                    } else {
                        k_let8077(false)
                    }
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::check::types::GenericUse>>, crate::check::types::GenericUse)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::check::types::GenericUse>>>>>
    }));
    let found_p9 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(&generic_p5), GrowthFound { st_p: st_p1.clone(), reported_p: crate::prelude::Array::new(), seen_p: crate::prelude::Map::new() }, {
        let generic_p5x = generic_p5.clone();
        let uses_by_p8x = uses_by_p8.clone();
        let shown_p7x = shown_p7.clone();
        ::std::rc::Rc::new(move |(p0, p1): (GrowthFound, crate::prelude::Text)| {
            let generic_p5xy = generic_p5x.clone();
            let uses_by_p8xy = uses_by_p8x.clone();
            let shown_p7xy = shown_p7x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let sofar_p18 = p0;
                let start_p19 = p1;
                {
                    let own_p1a = crate::prelude::each(&crate::prelude::or(&crate::prelude::get(&generic_p5xy, &start_p19), &crate::prelude::Array::new()), &(|q_p1c: &crate::prelude::Text| (q_p1c.clone(), crate::check::types::Ty::TyRigid(q_p1c.clone()))));
                    let fresh_p1b = {
                        let mut this: GrowthFound = sofar_p18.clone();
                        this.seen_p = crate::prelude::insert(&crate::prelude::Map::new(), &crate::prelude::Text::from(format!("{} {}", &start_p19, &crate::prelude::show_text(&own_p1a))), &true);
                        this
                    };
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(GrowthWalk { uses_by_p0: uses_by_p8xy.clone(), shown_p1: shown_p7xy.clone(), path_p2: crate::prelude::Array::from(vec![GrowthStep { definition_p: start_p19.clone(), types_p: own_p1a.clone(), place_p: crate::prelude::Text::lit("") }]), at_p3: start_p19.clone(), reached_p4: own_p1a.clone(), found_p5: fresh_p1b.clone() }))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((GrowthFound, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<GrowthFound>>>
    }));
    found_p9.st_p.clone()
}

/// The step machine of `GrowthCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GrowthCheck: unbounded fn G, St, [Def] -> St
/// ```
pub struct GrowthCheck {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub defs_p2: crate::prelude::Array<crate::check::env::Def>,
}

impl ::prism_rtl::Job<crate::check::types::St> for GrowthCheck {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let defs_p2 = &self.defs_p2;
        let named_p3 = crate::prelude::fold(defs_p2, &crate::prelude::Map::new(), &(|m_pa: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, d_pb: &crate::check::env::Def| match crate::prelude::get(&g_p0.vals_p, &d_pb.qk_p) {
            ::std::option::Option::Some(v_pc) => if crate::check::expr::is_generic_use_f(&v_pc) && is_named_def_f(d_pb) {
                crate::prelude::insert(m_pa, &d_pb.qk_p, &v_pc.scheme_p.qs_p)
            } else {
                m_pa.clone()
            },
            ::std::option::Option::None => m_pa.clone(),
        }));
        let impls_p4 = crate::prelude::fold(&crate::prelude::keys(&g_p0.impls_p), &crate::prelude::Map::new(), &(|m_pd: &crate::prelude::Map<crate::prelude::Text, crate::check::env::ImplInfo>, cls_pe: &crate::prelude::Text| crate::prelude::fold(&crate::prelude::or(&crate::prelude::get(&g_p0.impls_p, cls_pe), &crate::prelude::Array::new()), m_pd, &(|m2_pf: &crate::prelude::Map<crate::prelude::Text, crate::check::env::ImplInfo>, im_pg: &crate::check::env::ImplInfo| if im_pg.derived_p || (&crate::prelude::len(&im_pg.qs_p) == &crate::prelude::Nat::from(0u32)) {
            m2_pf.clone()
        } else {
            crate::prelude::insert(m2_pf, &crate::check::env::traits::impl_choice_f(im_pg), im_pg)
        }))));
        let generic_p5 = crate::prelude::fold(&crate::prelude::keys(&impls_p4), &named_p3, &(|m_ph: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, impl_key_pi: &crate::prelude::Text| match crate::prelude::get(&impls_p4, impl_key_pi) {
            ::std::option::Option::Some(im_pj) => crate::prelude::insert(m_ph, impl_key_pi, &im_pj.qs_p),
            ::std::option::Option::None => m_ph.clone(),
        }));
        let impl_of_p6 = crate::prelude::fold(defs_p2, &crate::prelude::Map::new(), &(|m_pk: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>, d_pl: &crate::check::env::Def| match &d_pl.body_p {
            crate::check::env::DefBody::DbMethod(_, _, im_pm) => crate::prelude::insert(m_pk, &crate::check::shrink::types::own_key_f(d_pl).qk_p, &crate::prelude::Text::from(format!("impl:{}.{}", &im_pm.file_p, &im_pm.span_p.start_p))),
            _ => m_pk.clone(),
        }));
        let st_p1x = st_p1.clone();
        crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::keys(&impls_p4), crate::prelude::Map::new(), {
            let impls_p4x = impls_p4.clone();
            let st_p1xx = st_p1x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>, crate::prelude::Text)| {
                let impls_p4xy = impls_p4x.clone();
                let st_p1xxy = st_p1xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let m_pn = p0;
                    let impl_key_po = p1;
                    match crate::prelude::get(&impls_p4xy, &impl_key_po) {
                        ::std::option::Option::Some(im_pp) => crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1xxy.clone(), im_pp.head_p.clone()), move |show_ty_f_7722: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::insert(&m_pn, &impl_key_po, &crate::prelude::Text::from(format!("impl ^{} {}", &crate::check::types::bare_name_f(&im_pp.cls_p), &show_ty_f_7722))))),
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(m_pn.clone()),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>>>>
        }), move |fold_7604: crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>| {
            let shown_p7 = fold_7604;
            crate::prelude::call_value(crate::prelude::fold_job(st_p1x.generic_uses_p.clone(), crate::prelude::Map::new(), {
                let impl_of_p6x = impl_of_p6.clone();
                let generic_p5x = generic_p5.clone();
                let impls_p4x = impls_p4.clone();
                let st_p1xx = st_p1x.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::check::types::GenericUse>>, crate::check::types::GenericUse)| {
                    let impl_of_p6xy = impl_of_p6x.clone();
                    let generic_p5xy = generic_p5x.clone();
                    let impls_p4xy = impls_p4x.clone();
                    let st_p1xxy = st_p1xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let m_pq = p0;
                        let noted_pr = p1;
                        {
                            let user_ps = crate::prelude::or(&crate::prelude::get(&impl_of_p6xy, &noted_pr.user_p), &noted_pr.user_p);
                            let own_pt = crate::prelude::or(&crate::prelude::get(&generic_p5xy, &user_ps), &crate::prelude::Array::new());
                            let generic_p5xyz = generic_p5xy.clone();
                            let m_pqz = m_pq.clone();
                            let noted_prz = noted_pr.clone();
                            let st_p1xxyz = st_p1xxy.clone();
                            let user_psz = user_ps.clone();
                            let k_let8077 = move |v8077: bool| {
                                let foreign_pu = v8077;
                                if ((crate::check::env::has_key_f(&generic_p5xyz, &user_psz) && crate::check::env::has_key_f(&generic_p5xyz, &noted_prz.target_p)) && !foreign_pu) && !crate::prelude::run_to_end(crate::prelude::fold_job(noted_prz.types_p.clone(), false, {
                                    let st_p1xxyzx = st_p1xxyz.clone();
                                    ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::check::types::Ty))| {
                                        let st_p1xxyzxy = st_p1xxyzx.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let found_p13 = p0;
                                            let (_, t_p14) = p1;
                                            if found_p13 {
                                                ::prism_rtl::Turn::Finished(true)
                                            } else {
                                                crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p1xxyzxy.clone(), t_p14.clone()), move |zonk_f_8517: crate::check::types::Ty| ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsAssociatedType { t_p0: zonk_f_8517 })))
                                            }
                                        }))
                                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::check::types::Ty))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                                })) {
                                    {
                                        let read_p15 = {
                                            let mut this: crate::check::types::GenericUse = noted_prz.clone();
                                            this.user_p = user_psz.clone();
                                            this.types_p = crate::prelude::run_to_end(crate::prelude::each_job(this.types_p.clone(), {
                                                let st_p1xxyzx = st_p1xxyz.clone();
                                                ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::check::types::Ty)| {
                                                    let st_p1xxyzxy = st_p1xxyzx.clone();
                                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                                        let (q_p16, t_p17) = p0;
                                                        crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p1xxyzxy.clone(), t_p17.clone()), move |zonk_f_8672: crate::check::types::Ty| crate::prelude::call_then(start_flex_named_f(zonk_f_8672), move |flex_named_f_8661: crate::check::types::Ty| ::prism_rtl::Turn::Finished((q_p16.clone(), flex_named_f_8661))))
                                                    }))
                                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::Ty)>>>
                                            }));
                                            this
                                        };
                                        ::prism_rtl::Turn::Finished(crate::prelude::insert(&m_pqz, &user_psz, &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(&m_pqz, &user_psz), &crate::prelude::Array::new()), &read_p15)))
                                    }
                                } else {
                                    ::prism_rtl::Turn::Finished(m_pqz.clone())
                                }
                            };
                            if crate::check::env::has_key_f(&impls_p4xy, &user_ps) {
                                crate::prelude::call_value(crate::prelude::fold_job(noted_pr.types_p.clone(), false, {
                                    let st_p1xxyx = st_p1xxy.clone();
                                    let own_ptx = own_pt.clone();
                                    ::std::rc::Rc::new(move |(p0, p1): (bool, (crate::prelude::Text, crate::check::types::Ty))| {
                                        let st_p1xxyxy = st_p1xxyx.clone();
                                        let own_ptxy = own_ptx.clone();
                                        crate::prelude::entered(crate::prelude::once_job(move || {
                                            let found_pv = p0;
                                            let (_, t_p10) = p1;
                                            if found_pv {
                                                ::prism_rtl::Turn::Finished(true)
                                            } else {
                                                crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p1xxyxy.clone(), t_p10.clone()), move |zonk_f_8205: crate::check::types::Ty| crate::prelude::call_then(start_flex_named_f(zonk_f_8205), move |flex_named_f_8194: crate::check::types::Ty| crate::prelude::call_then(start_rigid_names_in_f(flex_named_f_8194), move |rigid_names_in_f_8180: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::fold(&rigid_names_in_f_8180, &false, &(|other_p11: &bool, q_p12: &crate::prelude::Text| *other_p11 || !crate::check::types::has_text_f(&own_ptxy, q_p12)))))))
                                            }
                                        }))
                                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, (crate::prelude::Text, crate::check::types::Ty))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                                }), move |fold_8116: bool| k_let8077(fold_8116))
                            } else {
                                k_let8077(false)
                            }
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::check::types::GenericUse>>, crate::check::types::GenericUse)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::check::types::GenericUse>>>>>
            }), move |fold_7775: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::check::types::GenericUse>>| {
                let uses_by_p8 = fold_7775;
                crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::keys(&generic_p5), GrowthFound { st_p: st_p1x.clone(), reported_p: crate::prelude::Array::new(), seen_p: crate::prelude::Map::new() }, {
                    let generic_p5x = generic_p5.clone();
                    let uses_by_p8x = uses_by_p8.clone();
                    let shown_p7x = shown_p7.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (GrowthFound, crate::prelude::Text)| {
                        let generic_p5xy = generic_p5x.clone();
                        let uses_by_p8xy = uses_by_p8x.clone();
                        let shown_p7xy = shown_p7x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let sofar_p18 = p0;
                            let start_p19 = p1;
                            {
                                let own_p1a = crate::prelude::each(&crate::prelude::or(&crate::prelude::get(&generic_p5xy, &start_p19), &crate::prelude::Array::new()), &(|q_p1c: &crate::prelude::Text| (q_p1c.clone(), crate::check::types::Ty::TyRigid(q_p1c.clone()))));
                                let fresh_p1b = {
                                    let mut this: GrowthFound = sofar_p18.clone();
                                    this.seen_p = crate::prelude::insert(&crate::prelude::Map::new(), &crate::prelude::Text::from(format!("{} {}", &start_p19, &crate::prelude::show_text(&own_p1a))), &true);
                                    this
                                };
                                ::prism_rtl::Turn::More(::std::rc::Rc::new(GrowthWalk { uses_by_p0: uses_by_p8xy.clone(), shown_p1: shown_p7xy.clone(), path_p2: crate::prelude::Array::from(vec![GrowthStep { definition_p: start_p19.clone(), types_p: own_p1a.clone(), place_p: crate::prelude::Text::lit("") }]), at_p3: start_p19.clone(), reached_p4: own_p1a.clone(), found_p5: fresh_p1b.clone() }))
                            }
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((GrowthFound, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<GrowthFound>>>
                }), move |fold_8779: GrowthFound| {
                    let found_p9 = fold_8779;
                    ::prism_rtl::Turn::Finished(found_p9.st_p.clone())
                })
            })
        })
    }
}

/// `Start GrowthCheck, x`: what the function value is when passed to `@Run`.
pub fn start_growth_check_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, defs_p2: crate::prelude::Array<crate::check::env::Def>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(GrowthCheck { g_p0, st_p1, defs_p2 })
}

/// ```prism
/// RigidNamesIn: unbounded fn Ty -> [Text]
/// ```
pub fn rigid_names_in_f(t_p0: &crate::check::types::Ty) -> crate::prelude::Array<crate::prelude::Text> {
    match t_p0 {
        crate::check::types::Ty::TyRigid(n_p1) => crate::prelude::Array::from(vec![n_p1.clone()]),
        crate::check::types::Ty::TyCon(_, args_p2) => crate::prelude::run_to_end(crate::prelude::fold_job(args_p2.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p3 = p0;
            let a_p4 = p1;
            crate::prelude::call_then(start_rigid_names_in_f(a_p4.clone()), move |rigid_names_in_f_9344: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p3, &rigid_names_in_f_9344)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)),
        crate::check::types::Ty::TyFn(_, ps_p5, r_p6) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_p5.clone(), rigid_names_in_f(&**r_p6), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_p7 = p0;
            let a_p8 = p1;
            crate::prelude::call_then(start_rigid_names_in_f(a_p8.clone()), move |rigid_names_in_f_9438: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p7, &rigid_names_in_f_9438)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)),
        crate::check::types::Ty::TyTuple(ts_p9) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_p9.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
            let acc_pa = p0;
            let a_pb = p1;
            crate::prelude::call_then(start_rigid_names_in_f(a_pb.clone()), move |rigid_names_in_f_9512: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pa, &rigid_names_in_f_9512)))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>)),
        crate::check::types::Ty::TyArray(e_pc) => rigid_names_in_f(&**e_pc),
        crate::check::types::Ty::TyMap(k_pd, v_pe) => crate::check::types::union_texts_f(&rigid_names_in_f(&**k_pd), &rigid_names_in_f(&**v_pe)),
        crate::check::types::Ty::TySig(_, i_pf) => rigid_names_in_f(&**i_pf),
        crate::check::types::Ty::TyAt(i_pg, _) => rigid_names_in_f(&**i_pg),
        crate::check::types::Ty::TyElem(_, o_ph) => rigid_names_in_f(&**o_ph),
        crate::check::types::Ty::TyAssoc(_, ignore2_pi, a_pj) => rigid_names_in_f(&**a_pj),
        _ => crate::prelude::Array::new(),
    }
}

/// The step machine of `RigidNamesIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RigidNamesIn: unbounded fn Ty -> [Text]
/// ```
pub struct RigidNamesIn {
    pub t_p0: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for RigidNamesIn {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::check::types::Ty::TyRigid(n_p1) => ::prism_rtl::Turn::Finished(crate::prelude::Array::from(vec![n_p1.clone()])),
            crate::check::types::Ty::TyCon(_, args_p2) => crate::prelude::fold_job(args_p2.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p3 = p0;
                let a_p4 = p1;
                crate::prelude::call_then(start_rigid_names_in_f(a_p4.clone()), move |rigid_names_in_f_9344: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p3, &rigid_names_in_f_9344)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle(),
            crate::check::types::Ty::TyFn(_, ps_p5, r_p6) => {
                let ps_p5x = ps_p5.clone();
                let r_p6x = (**r_p6).clone();
                crate::prelude::call_then(start_rigid_names_in_f(r_p6x.clone()), move |rigid_names_in_f_9394: crate::prelude::Array<crate::prelude::Text>| crate::prelude::fold_job(ps_p5x.clone(), rigid_names_in_f_9394, ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p7 = p0;
                    let a_p8 = p1;
                    crate::prelude::call_then(start_rigid_names_in_f(a_p8.clone()), move |rigid_names_in_f_9438: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p7, &rigid_names_in_f_9438)))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle())
            },
            crate::check::types::Ty::TyTuple(ts_p9) => crate::prelude::fold_job(ts_p9.clone(), crate::prelude::Array::new(), ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pa = p0;
                let a_pb = p1;
                crate::prelude::call_then(start_rigid_names_in_f(a_pb.clone()), move |rigid_names_in_f_9512: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pa, &rigid_names_in_f_9512)))
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>).cycle(),
            crate::check::types::Ty::TyArray(e_pc) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RigidNamesIn { t_p0: (**e_pc).clone() })),
            crate::check::types::Ty::TyMap(k_pd, v_pe) => {
                let k_pdx = (**k_pd).clone();
                let v_pex = (**v_pe).clone();
                crate::prelude::call_then(start_rigid_names_in_f(k_pdx.clone()), move |rigid_names_in_f_9586: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(start_rigid_names_in_f(v_pex.clone()), move |rigid_names_in_f_9604: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&rigid_names_in_f_9586, &rigid_names_in_f_9604))))
            },
            crate::check::types::Ty::TySig(_, i_pf) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RigidNamesIn { t_p0: (**i_pf).clone() })),
            crate::check::types::Ty::TyAt(i_pg, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RigidNamesIn { t_p0: (**i_pg).clone() })),
            crate::check::types::Ty::TyElem(_, o_ph) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RigidNamesIn { t_p0: (**o_ph).clone() })),
            crate::check::types::Ty::TyAssoc(_, ignore2_pi, a_pj) => ::prism_rtl::Turn::More(::std::rc::Rc::new(RigidNamesIn { t_p0: (**a_pj).clone() })),
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start RigidNamesIn, x`: what the function value is when passed to `@Run`.
pub fn start_rigid_names_in_f(t_p0: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(RigidNamesIn { t_p0 })
}

/// ```prism
/// GrowthName: fn (Text ==> Text), Text -> Text
/// ```
pub fn growth_name_f(shown_p0: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>, definition_p1: &crate::prelude::Text) -> crate::prelude::Text {
    crate::prelude::or(&crate::prelude::get(shown_p0, definition_p1), &crate::check::types::bare_name_f(definition_p1))
}

/// ```prism
/// IsNamedDef: fn Def -> Bool
/// ```
pub fn is_named_def_f(d_p0: &crate::check::env::Def) -> bool {
    match &d_p0.body_p {
        crate::check::env::DefBody::DbFn(_) => true,
        crate::check::env::DefBody::DbWidget(_) => true,
        crate::check::env::DefBody::DbLet(_) => true,
        _ => false,
    }
}

/// ```prism
/// FlexNamed: unbounded fn Ty -> Ty
/// ```
pub fn flex_named_f(t_p0: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p0 {
        crate::check::types::Ty::TyFlex(n_p1) => crate::check::types::Ty::TyRigid(crate::prelude::Text::from(format!("\'{}", n_p1))),
        crate::check::types::Ty::TyCon(n_p2, args_p3) => crate::check::types::Ty::TyCon(n_p2.clone(), crate::prelude::run_to_end(crate::prelude::each_job(args_p3.clone(), ::std::rc::Rc::new(move |p0: crate::check::types::Ty| crate::prelude::entered(crate::prelude::once_job(move || {
            let a_p4 = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(FlexNamed { t_p0: a_p4.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>))),
        crate::check::types::Ty::TyFn(c_p5, ps_p6, r_p7) => crate::check::types::Ty::TyFn(c_p5.clone(), crate::prelude::run_to_end(crate::prelude::each_job(ps_p6.clone(), ::std::rc::Rc::new(move |p0: crate::check::types::Ty| crate::prelude::entered(crate::prelude::once_job(move || {
            let a_p8 = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(FlexNamed { t_p0: a_p8.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>)), ::std::rc::Rc::new(flex_named_f(&**r_p7))),
        crate::check::types::Ty::TyTuple(ts_p9) => crate::check::types::Ty::TyTuple(crate::prelude::run_to_end(crate::prelude::each_job(ts_p9.clone(), ::std::rc::Rc::new(move |p0: crate::check::types::Ty| crate::prelude::entered(crate::prelude::once_job(move || {
            let a_pa = p0;
            ::prism_rtl::Turn::More(::std::rc::Rc::new(FlexNamed { t_p0: a_pa.clone() }))
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>))),
        crate::check::types::Ty::TyArray(e_pb) => crate::check::types::Ty::TyArray(::std::rc::Rc::new(flex_named_f(&**e_pb))),
        crate::check::types::Ty::TyMap(k_pc, v_pd) => crate::check::types::Ty::TyMap(::std::rc::Rc::new(flex_named_f(&**k_pc)), ::std::rc::Rc::new(flex_named_f(&**v_pd))),
        crate::check::types::Ty::TySig(s_pe, i_pf) => crate::check::types::Ty::TySig(s_pe.clone(), ::std::rc::Rc::new(flex_named_f(&**i_pf))),
        crate::check::types::Ty::TyAt(i_pg, rw_ph) => crate::check::types::Ty::TyAt(::std::rc::Rc::new(flex_named_f(&**i_pg)), rw_ph.clone()),
        crate::check::types::Ty::TyElem(rw_pi, o_pj) => crate::check::types::Ty::TyElem(rw_pi.clone(), ::std::rc::Rc::new(flex_named_f(&**o_pj))),
        crate::check::types::Ty::TyAssoc(tr_pk, n_pl, a_pm) => crate::check::types::Ty::TyAssoc(tr_pk.clone(), n_pl.clone(), ::std::rc::Rc::new(flex_named_f(&**a_pm))),
        other_pn => other_pn.clone(),
    }
}

/// The step machine of `FlexNamed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FlexNamed: unbounded fn Ty -> Ty
/// ```
pub struct FlexNamed {
    pub t_p0: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::Ty> for FlexNamed {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::Ty> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::check::types::Ty::TyFlex(n_p1) => ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyRigid(crate::prelude::Text::from(format!("\'{}", n_p1)))),
            crate::check::types::Ty::TyCon(n_p2, args_p3) => {
                let args_p3x = args_p3.clone();
                let n_p2x = n_p2.clone();
                crate::prelude::call_value(crate::prelude::each_job(args_p3x.clone(), ::std::rc::Rc::new(move |p0: crate::check::types::Ty| crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p4 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(FlexNamed { t_p0: a_p4.clone() }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>), move |each_10633: crate::prelude::Array<crate::check::types::Ty>| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyCon(n_p2x.clone(), each_10633)))
            },
            crate::check::types::Ty::TyFn(c_p5, ps_p6, r_p7) => {
                let c_p5x = c_p5.clone();
                let ps_p6x = ps_p6.clone();
                let r_p7x = (**r_p7).clone();
                crate::prelude::call_value(crate::prelude::each_job(ps_p6x.clone(), ::std::rc::Rc::new(move |p0: crate::check::types::Ty| crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p8 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(FlexNamed { t_p0: a_p8.clone() }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>), move |each_10690: crate::prelude::Array<crate::check::types::Ty>| crate::prelude::call_then(start_flex_named_f(r_p7x.clone()), move |flex_named_f_10719: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyFn(c_p5x.clone(), each_10690, ::std::rc::Rc::new(flex_named_f_10719)))))
            },
            crate::check::types::Ty::TyTuple(ts_p9) => {
                let ts_p9x = ts_p9.clone();
                crate::prelude::call_value(crate::prelude::each_job(ts_p9x.clone(), ::std::rc::Rc::new(move |p0: crate::check::types::Ty| crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pa = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(FlexNamed { t_p0: a_pa.clone() }))
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>), move |each_10757: crate::prelude::Array<crate::check::types::Ty>| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyTuple(each_10757)))
            },
            crate::check::types::Ty::TyArray(e_pb) => {
                let e_pbx = (**e_pb).clone();
                crate::prelude::call_then(start_flex_named_f(e_pbx.clone()), move |flex_named_f_10808: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyArray(::std::rc::Rc::new(flex_named_f_10808))))
            },
            crate::check::types::Ty::TyMap(k_pc, v_pd) => {
                let k_pcx = (**k_pc).clone();
                let v_pdx = (**v_pd).clone();
                crate::prelude::call_then(start_flex_named_f(k_pcx.clone()), move |flex_named_f_10844: crate::check::types::Ty| crate::prelude::call_then(start_flex_named_f(v_pdx.clone()), move |flex_named_f_10859: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyMap(::std::rc::Rc::new(flex_named_f_10844), ::std::rc::Rc::new(flex_named_f_10859)))))
            },
            crate::check::types::Ty::TySig(s_pe, i_pf) => {
                let i_pfx = (**i_pf).clone();
                let s_pex = s_pe.clone();
                crate::prelude::call_then(start_flex_named_f(i_pfx.clone()), move |flex_named_f_10898: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TySig(s_pex.clone(), ::std::rc::Rc::new(flex_named_f_10898))))
            },
            crate::check::types::Ty::TyAt(i_pg, rw_ph) => {
                let i_pgx = (**i_pg).clone();
                let rw_phx = rw_ph.clone();
                crate::prelude::call_then(start_flex_named_f(i_pgx.clone()), move |flex_named_f_10933: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyAt(::std::rc::Rc::new(flex_named_f_10933), rw_phx.clone())))
            },
            crate::check::types::Ty::TyElem(rw_pi, o_pj) => {
                let o_pjx = (**o_pj).clone();
                let rw_pix = rw_pi.clone();
                crate::prelude::call_then(start_flex_named_f(o_pjx.clone()), move |flex_named_f_10980: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyElem(rw_pix.clone(), ::std::rc::Rc::new(flex_named_f_10980))))
            },
            crate::check::types::Ty::TyAssoc(tr_pk, n_pl, a_pm) => {
                let a_pmx = (**a_pm).clone();
                let n_plx = n_pl.clone();
                let tr_pkx = tr_pk.clone();
                crate::prelude::call_then(start_flex_named_f(a_pmx.clone()), move |flex_named_f_11031: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyAssoc(tr_pkx.clone(), n_plx.clone(), ::std::rc::Rc::new(flex_named_f_11031))))
            },
            other_pn => ::prism_rtl::Turn::Finished(other_pn.clone()),
        }
    }
}

/// `Start FlexNamed, x`: what the function value is when passed to `@Run`.
pub fn start_flex_named_f(t_p0: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>> {
    ::std::rc::Rc::new(FlexNamed { t_p0 })
}

/// ```prism
/// HoldsAssociatedType: unbounded fn Ty -> Bool
/// ```
pub fn holds_associated_type_f(t_p0: &crate::check::types::Ty) -> bool {
    match t_p0 {
        crate::check::types::Ty::TyAssoc(_, _, ignore2_p1) => true,
        crate::check::types::Ty::TyCon(_, args_p2) => crate::prelude::run_to_end(crate::prelude::fold_job(args_p2.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
            let found_p3 = p0;
            let a_p4 = p1;
            if found_p3 {
                ::prism_rtl::Turn::Finished(true)
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsAssociatedType { t_p0: a_p4.clone() }))
            }
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>)),
        crate::check::types::Ty::TyFn(_, ps_p5, r_p6) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_p5.clone(), holds_associated_type_f(&**r_p6), ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
            let found_p7 = p0;
            let a_p8 = p1;
            if found_p7 {
                ::prism_rtl::Turn::Finished(true)
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsAssociatedType { t_p0: a_p8.clone() }))
            }
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>)),
        crate::check::types::Ty::TyTuple(ts_p9) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_p9.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
            let found_pa = p0;
            let a_pb = p1;
            if found_pa {
                ::prism_rtl::Turn::Finished(true)
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsAssociatedType { t_p0: a_pb.clone() }))
            }
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>)),
        crate::check::types::Ty::TyArray(e_pc) => holds_associated_type_f(&**e_pc),
        crate::check::types::Ty::TyMap(k_pd, v_pe) => holds_associated_type_f(&**k_pd) || holds_associated_type_f(&**v_pe),
        crate::check::types::Ty::TySig(_, i_pf) => holds_associated_type_f(&**i_pf),
        crate::check::types::Ty::TyAt(i_pg, _) => holds_associated_type_f(&**i_pg),
        crate::check::types::Ty::TyElem(_, o_ph) => holds_associated_type_f(&**o_ph),
        _ => false,
    }
}

/// The step machine of `HoldsAssociatedType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HoldsAssociatedType: unbounded fn Ty -> Bool
/// ```
pub struct HoldsAssociatedType {
    pub t_p0: crate::check::types::Ty,
}

impl ::prism_rtl::Job<bool> for HoldsAssociatedType {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let t_p0 = &self.t_p0;
        match t_p0 {
            crate::check::types::Ty::TyAssoc(_, _, ignore2_p1) => ::prism_rtl::Turn::Finished(true),
            crate::check::types::Ty::TyCon(_, args_p2) => crate::prelude::fold_job(args_p2.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                let found_p3 = p0;
                let a_p4 = p1;
                if found_p3 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsAssociatedType { t_p0: a_p4.clone() }))
                }
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>).cycle(),
            crate::check::types::Ty::TyFn(_, ps_p5, r_p6) => {
                let ps_p5x = ps_p5.clone();
                let r_p6x = (**r_p6).clone();
                crate::prelude::call_then(start_holds_associated_type_f(r_p6x.clone()), move |holds_associated_type_f_11508: bool| crate::prelude::fold_job(ps_p5x.clone(), holds_associated_type_f_11508, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let found_p7 = p0;
                    let a_p8 = p1;
                    if found_p7 {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsAssociatedType { t_p0: a_p8.clone() }))
                    }
                }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>).cycle())
            },
            crate::check::types::Ty::TyTuple(ts_p9) => crate::prelude::fold_job(ts_p9.clone(), false, ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| crate::prelude::entered(crate::prelude::once_job(move || {
                let found_pa = p0;
                let a_pb = p1;
                if found_pa {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsAssociatedType { t_p0: a_pb.clone() }))
                }
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>).cycle(),
            crate::check::types::Ty::TyArray(e_pc) => ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsAssociatedType { t_p0: (**e_pc).clone() })),
            crate::check::types::Ty::TyMap(k_pd, v_pe) => {
                let k_pdx = (**k_pd).clone();
                let v_pex = (**v_pe).clone();
                crate::prelude::call_then(start_holds_associated_type_f(k_pdx.clone()), move |holds_associated_type_f_11704: bool| if holds_associated_type_f_11704 {
                    ::prism_rtl::Turn::Finished(true)
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsAssociatedType { t_p0: v_pex.clone() }))
                })
            },
            crate::check::types::Ty::TySig(_, i_pf) => ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsAssociatedType { t_p0: (**i_pf).clone() })),
            crate::check::types::Ty::TyAt(i_pg, _) => ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsAssociatedType { t_p0: (**i_pg).clone() })),
            crate::check::types::Ty::TyElem(_, o_ph) => ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsAssociatedType { t_p0: (**o_ph).clone() })),
            _ => ::prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start HoldsAssociatedType, x`: what the function value is when passed to `@Run`.
pub fn start_holds_associated_type_f(t_p0: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(HoldsAssociatedType { t_p0 })
}

/// ```prism
/// GrowthWalk: unbounded fn (Text ==> [GenericUse]), (Text ==> Text), [GrowthStep], Text, [((Text, Ty))], GrowthFound -> GrowthFound
/// ```
pub fn growth_walk_f(uses_by_p0: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::check::types::GenericUse>>, shown_p1: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>, path_p2: &crate::prelude::Array<GrowthStep>, at_p3: &crate::prelude::Text, reached_p4: &crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, found_p5: &GrowthFound) -> GrowthFound {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::or(&crate::prelude::get(uses_by_p0, at_p3), &crate::prelude::Array::new()), found_p5.clone(), {
        let path_p2x = path_p2.clone();
        let shown_p1x = shown_p1.clone();
        let reached_p4x = reached_p4.clone();
        let uses_by_p0x = uses_by_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (GrowthFound, crate::check::types::GenericUse)| {
            let path_p2xy = path_p2x.clone();
            let shown_p1xy = shown_p1x.clone();
            let reached_p4xy = reached_p4x.clone();
            let uses_by_p0xy = uses_by_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let sofar_p6 = p0;
                let noted_p7 = p1;
                {
                    let step_p8 = GrowthStep { definition_p: noted_p7.target_p.clone(), types_p: noted_p7.types_p.clone(), place_p: crate::prelude::Text::from(format!("{}:{}", &noted_p7.file_p, &noted_p7.span_p.start_p)) };
                    crate::prelude::call_then(start_grows_back_o(path_p2xy.clone(), noted_p7.types_p.clone(), noted_p7.target_p.clone(), crate::prelude::len(&path_p2xy)), move |grows_back_o_12506: ::std::option::Option<(crate::prelude::Nat, crate::prelude::Text, crate::check::types::Ty)>| match grows_back_o_12506 {
                        ::std::option::Option::Some((above_p9, q_pa, t_pb)) => {
                            let round_pc = crate::prelude::push(&crate::prelude::drop(&path_p2xy, &(&above_p9 + &crate::prelude::Nat::from(1u32))), &step_p8);
                            let line_pd = crate::syntax::lexer::chars::join_f(&crate::check::types::sort_texts_f(&crate::prelude::each(&round_pc, &(|s_pe: &GrowthStep| s_pe.place_p.clone()))), &crate::prelude::Text::lit(" "));
                            if crate::check::types::has_text_f(&sofar_p6.reported_p, &line_pd) {
                                ::prism_rtl::Turn::Finished(sofar_p6.clone())
                            } else {
                                {
                                    let through_pf = crate::prelude::fold(&round_pc, &crate::prelude::Array::new(), &(|acc_pi: &crate::prelude::Array<crate::prelude::Text>, s_pj: &GrowthStep| if (&s_pj.definition_p == &noted_p7.target_p) || crate::check::types::has_text_f(acc_pi, &crate::prelude::Text::from(format!("`{}`", &growth_name_f(&shown_p1xy, &s_pj.definition_p)))) {
                                        acc_pi.clone()
                                    } else {
                                        crate::prelude::push(acc_pi, &crate::prelude::Text::from(format!("`{}`", &growth_name_f(&shown_p1xy, &s_pj.definition_p))))
                                    }));
                                    let way_pg = if &crate::prelude::len(&through_pf) == &crate::prelude::Nat::from(0u32) {
                                        crate::prelude::Text::lit("")
                                    } else {
                                        crate::prelude::Text::from(format!(" through {}", &crate::syntax::lexer::chars::join_f(&through_pf, &crate::prelude::Text::lit(", "))))
                                    };
                                    let reaches_ph = if crate::check::env::has_key_f(&shown_p1xy, &noted_p7.target_p) {
                                        crate::prelude::Text::lit("needs itself")
                                    } else {
                                        crate::prelude::Text::lit("calls itself")
                                    };
                                    ::prism_rtl::Turn::Finished({
                                        let mut this: GrowthFound = sofar_p6.clone();
                                        this.reported_p = crate::prelude::push(&this.reported_p, &line_pd);
                                        this.st_p = crate::check::types::recording::add_diag_f(&this.st_p, &crate::check::errors::diag0_f(&crate::prelude::Text::lit("grows-without-end"), &noted_p7.file_p, &noted_p7.span_p, &crate::prelude::Text::from(format!("`{}` {}{} at `{}` for `{}`: a type that grows without end", &growth_name_f(&shown_p1xy, &noted_p7.target_p), &reaches_ph, &way_pg, &crate::check::types::show_ty_f(&sofar_p6.st_p, &t_pb), &q_pa))));
                                        this
                                    })
                                }
                            }
                        },
                        ::std::option::Option::None => crate::prelude::call_value(crate::prelude::each_job(noted_p7.types_p.clone(), {
                            let reached_p4xyx = reached_p4xy.clone();
                            ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::check::types::Ty)| {
                                let reached_p4xyxy = reached_p4xyx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let (q_pm, t_pn) = p0;
                                    crate::prelude::call_then(start_subst_rigids_f(reached_p4xyxy.clone(), t_pn.clone()), move |subst_rigids_f_13619: crate::check::types::Ty| ::prism_rtl::Turn::Finished((q_pm.clone(), subst_rigids_f_13619)))
                                }))
                            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::Ty)>>>
                        }), move |each_13583: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>| {
                            let now_pk = each_13583;
                            let reached_at_pl = crate::prelude::Text::from(format!("{} {}", &noted_p7.target_p, &crate::prelude::show_text(&now_pk)));
                            if crate::check::env::has_key_f(&sofar_p6.seen_p, &reached_at_pl) {
                                ::prism_rtl::Turn::Finished(sofar_p6.clone())
                            } else {
                                {
                                    let marked_po = {
                                        let mut this: GrowthFound = sofar_p6.clone();
                                        this.seen_p = crate::prelude::insert(&this.seen_p, &reached_at_pl, &true);
                                        this
                                    };
                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(GrowthWalk { uses_by_p0: uses_by_p0xy.clone(), shown_p1: shown_p1xy.clone(), path_p2: crate::prelude::push(&path_p2xy, &step_p8), at_p3: noted_p7.target_p.clone(), reached_p4: now_pk.clone(), found_p5: marked_po.clone() }))
                                }
                            }
                        }),
                    })
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((GrowthFound, crate::check::types::GenericUse)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<GrowthFound>>>
    }))
}

/// The step machine of `GrowthWalk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GrowthWalk: unbounded fn (Text ==> [GenericUse]), (Text ==> Text), [GrowthStep], Text, [((Text, Ty))], GrowthFound -> GrowthFound
/// ```
pub struct GrowthWalk {
    pub uses_by_p0: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::check::types::GenericUse>>,
    pub shown_p1: crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>,
    pub path_p2: crate::prelude::Array<GrowthStep>,
    pub at_p3: crate::prelude::Text,
    pub reached_p4: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>,
    pub found_p5: GrowthFound,
}

impl ::prism_rtl::Job<GrowthFound> for GrowthWalk {
    fn cycle(&self) -> ::prism_rtl::Turn<GrowthFound> {
        let uses_by_p0 = &self.uses_by_p0;
        let shown_p1 = &self.shown_p1;
        let path_p2 = &self.path_p2;
        let at_p3 = &self.at_p3;
        let reached_p4 = &self.reached_p4;
        let found_p5 = &self.found_p5;
        crate::prelude::fold_job(crate::prelude::or(&crate::prelude::get(uses_by_p0, at_p3), &crate::prelude::Array::new()), found_p5.clone(), {
            let path_p2x = path_p2.clone();
            let shown_p1x = shown_p1.clone();
            let reached_p4x = reached_p4.clone();
            let uses_by_p0x = uses_by_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (GrowthFound, crate::check::types::GenericUse)| {
                let path_p2xy = path_p2x.clone();
                let shown_p1xy = shown_p1x.clone();
                let reached_p4xy = reached_p4x.clone();
                let uses_by_p0xy = uses_by_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let sofar_p6 = p0;
                    let noted_p7 = p1;
                    {
                        let step_p8 = GrowthStep { definition_p: noted_p7.target_p.clone(), types_p: noted_p7.types_p.clone(), place_p: crate::prelude::Text::from(format!("{}:{}", &noted_p7.file_p, &noted_p7.span_p.start_p)) };
                        crate::prelude::call_then(start_grows_back_o(path_p2xy.clone(), noted_p7.types_p.clone(), noted_p7.target_p.clone(), crate::prelude::len(&path_p2xy)), move |grows_back_o_12506: ::std::option::Option<(crate::prelude::Nat, crate::prelude::Text, crate::check::types::Ty)>| match grows_back_o_12506 {
                            ::std::option::Option::Some((above_p9, q_pa, t_pb)) => {
                                let round_pc = crate::prelude::push(&crate::prelude::drop(&path_p2xy, &(&above_p9 + &crate::prelude::Nat::from(1u32))), &step_p8);
                                let line_pd = crate::syntax::lexer::chars::join_f(&crate::check::types::sort_texts_f(&crate::prelude::each(&round_pc, &(|s_pe: &GrowthStep| s_pe.place_p.clone()))), &crate::prelude::Text::lit(" "));
                                if crate::check::types::has_text_f(&sofar_p6.reported_p, &line_pd) {
                                    ::prism_rtl::Turn::Finished(sofar_p6.clone())
                                } else {
                                    {
                                        let through_pf = crate::prelude::fold(&round_pc, &crate::prelude::Array::new(), &(|acc_pi: &crate::prelude::Array<crate::prelude::Text>, s_pj: &GrowthStep| if (&s_pj.definition_p == &noted_p7.target_p) || crate::check::types::has_text_f(acc_pi, &crate::prelude::Text::from(format!("`{}`", &growth_name_f(&shown_p1xy, &s_pj.definition_p)))) {
                                            acc_pi.clone()
                                        } else {
                                            crate::prelude::push(acc_pi, &crate::prelude::Text::from(format!("`{}`", &growth_name_f(&shown_p1xy, &s_pj.definition_p))))
                                        }));
                                        let way_pg = if &crate::prelude::len(&through_pf) == &crate::prelude::Nat::from(0u32) {
                                            crate::prelude::Text::lit("")
                                        } else {
                                            crate::prelude::Text::from(format!(" through {}", &crate::syntax::lexer::chars::join_f(&through_pf, &crate::prelude::Text::lit(", "))))
                                        };
                                        let reaches_ph = if crate::check::env::has_key_f(&shown_p1xy, &noted_p7.target_p) {
                                            crate::prelude::Text::lit("needs itself")
                                        } else {
                                            crate::prelude::Text::lit("calls itself")
                                        };
                                        ::prism_rtl::Turn::Finished({
                                            let mut this: GrowthFound = sofar_p6.clone();
                                            this.reported_p = crate::prelude::push(&this.reported_p, &line_pd);
                                            this.st_p = crate::check::types::recording::add_diag_f(&this.st_p, &crate::check::errors::diag0_f(&crate::prelude::Text::lit("grows-without-end"), &noted_p7.file_p, &noted_p7.span_p, &crate::prelude::Text::from(format!("`{}` {}{} at `{}` for `{}`: a type that grows without end", &growth_name_f(&shown_p1xy, &noted_p7.target_p), &reaches_ph, &way_pg, &crate::check::types::show_ty_f(&sofar_p6.st_p, &t_pb), &q_pa))));
                                            this
                                        })
                                    }
                                }
                            },
                            ::std::option::Option::None => crate::prelude::call_value(crate::prelude::each_job(noted_p7.types_p.clone(), {
                                let reached_p4xyx = reached_p4xy.clone();
                                ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::check::types::Ty)| {
                                    let reached_p4xyxy = reached_p4xyx.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let (q_pm, t_pn) = p0;
                                        crate::prelude::call_then(start_subst_rigids_f(reached_p4xyxy.clone(), t_pn.clone()), move |subst_rigids_f_13619: crate::check::types::Ty| ::prism_rtl::Turn::Finished((q_pm.clone(), subst_rigids_f_13619)))
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::Ty)>>>
                            }), move |each_13583: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>| {
                                let now_pk = each_13583;
                                let reached_at_pl = crate::prelude::Text::from(format!("{} {}", &noted_p7.target_p, &crate::prelude::show_text(&now_pk)));
                                if crate::check::env::has_key_f(&sofar_p6.seen_p, &reached_at_pl) {
                                    ::prism_rtl::Turn::Finished(sofar_p6.clone())
                                } else {
                                    {
                                        let marked_po = {
                                            let mut this: GrowthFound = sofar_p6.clone();
                                            this.seen_p = crate::prelude::insert(&this.seen_p, &reached_at_pl, &true);
                                            this
                                        };
                                        ::prism_rtl::Turn::More(::std::rc::Rc::new(GrowthWalk { uses_by_p0: uses_by_p0xy.clone(), shown_p1: shown_p1xy.clone(), path_p2: crate::prelude::push(&path_p2xy, &step_p8), at_p3: noted_p7.target_p.clone(), reached_p4: now_pk.clone(), found_p5: marked_po.clone() }))
                                    }
                                }
                            }),
                        })
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((GrowthFound, crate::check::types::GenericUse)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<GrowthFound>>>
        }).cycle()
    }
}

/// `Start GrowthWalk, x`: what the function value is when passed to `@Run`.
pub fn start_growth_walk_f(uses_by_p0: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::check::types::GenericUse>>, shown_p1: crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>, path_p2: crate::prelude::Array<GrowthStep>, at_p3: crate::prelude::Text, reached_p4: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, found_p5: GrowthFound) -> ::std::rc::Rc<dyn ::prism_rtl::Job<GrowthFound>> {
    ::std::rc::Rc::new(GrowthWalk { uses_by_p0, shown_p1, path_p2, at_p3, reached_p4, found_p5 })
}

/// ```prism
/// ?GrowsBack: unbounded fn [GrowthStep], [((Text, Ty))], Text, Nat -> ?((Nat, Text, Ty))
/// ```
pub fn grows_back_o(path_p0: &crate::prelude::Array<GrowthStep>, composed_p1: &crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, target_p2: &crate::prelude::Text, below_p3: &crate::prelude::Nat) -> ::std::option::Option<(crate::prelude::Nat, crate::prelude::Text, crate::check::types::Ty)> {
    match below_p3.checked_sub(&crate::prelude::Nat::from(1u32)) {
        ::std::option::Option::None => ::std::option::Option::None,
        ::std::option::Option::Some(at_p4) => match crate::prelude::index(path_p0, &at_p4) {
            ::std::option::Option::None => ::std::option::Option::None,
            ::std::option::Option::Some(above_p5) => {
                let grown_p6 = if &above_p5.definition_p == target_p2 {
                    crate::prelude::filter(composed_p1, &(|(q_p7, t_p8): &(crate::prelude::Text, crate::check::types::Ty)| (t_p8 != &crate::check::types::Ty::TyRigid(q_p7.clone())) && crate::check::expr::calls::rigid_in_f(q_p7, t_p8)))
                } else {
                    crate::prelude::Array::new()
                };
                match crate::prelude::index(&grown_p6, &crate::prelude::Nat::from(0u32)) {
                    ::std::option::Option::Some((q_p9, t_pa)) => ::std::option::Option::Some((at_p4.clone(), q_p9, t_pa)),
                    ::std::option::Option::None => grows_back_o(path_p0, &crate::prelude::run_to_end(crate::prelude::each_job(composed_p1.clone(), {
                        let above_p5x = above_p5.clone();
                        ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::check::types::Ty)| {
                            let above_p5xy = above_p5x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let (q_pb, t_pc) = p0;
                                crate::prelude::call_then(start_subst_rigids_f(above_p5xy.types_p.clone(), t_pc.clone()), move |subst_rigids_f_14758: crate::check::types::Ty| ::prism_rtl::Turn::Finished((q_pb.clone(), subst_rigids_f_14758)))
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::Ty)>>>
                    })), target_p2, &at_p4),
                }
            },
        },
    }
}

/// The step machine of `GrowsBack`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?GrowsBack: unbounded fn [GrowthStep], [((Text, Ty))], Text, Nat -> ?((Nat, Text, Ty))
/// ```
pub struct GrowsBack {
    pub path_p0: crate::prelude::Array<GrowthStep>,
    pub composed_p1: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>,
    pub target_p2: crate::prelude::Text,
    pub below_p3: crate::prelude::Nat,
}

impl ::prism_rtl::Job<::std::option::Option<(crate::prelude::Nat, crate::prelude::Text, crate::check::types::Ty)>> for GrowsBack {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<(crate::prelude::Nat, crate::prelude::Text, crate::check::types::Ty)>> {
        let path_p0 = &self.path_p0;
        let composed_p1 = &self.composed_p1;
        let target_p2 = &self.target_p2;
        let below_p3 = &self.below_p3;
        match below_p3.checked_sub(&crate::prelude::Nat::from(1u32)) {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
            ::std::option::Option::Some(at_p4) => match crate::prelude::index(path_p0, &at_p4) {
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                ::std::option::Option::Some(above_p5) => {
                    let grown_p6 = if &above_p5.definition_p == target_p2 {
                        crate::prelude::filter(composed_p1, &(|(q_p7, t_p8): &(crate::prelude::Text, crate::check::types::Ty)| (t_p8 != &crate::check::types::Ty::TyRigid(q_p7.clone())) && crate::check::expr::calls::rigid_in_f(q_p7, t_p8)))
                    } else {
                        crate::prelude::Array::new()
                    };
                    match crate::prelude::index(&grown_p6, &crate::prelude::Nat::from(0u32)) {
                        ::std::option::Option::Some((q_p9, t_pa)) => ::prism_rtl::Turn::Finished(::std::option::Option::Some((at_p4.clone(), q_p9.clone(), t_pa.clone()))),
                        ::std::option::Option::None => {
                            let composed_p1x = composed_p1.clone();
                            let path_p0x = path_p0.clone();
                            let target_p2x = target_p2.clone();
                            crate::prelude::call_value(crate::prelude::each_job(composed_p1x.clone(), {
                                let above_p5x = above_p5.clone();
                                ::std::rc::Rc::new(move |p0: (crate::prelude::Text, crate::check::types::Ty)| {
                                    let above_p5xy = above_p5x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let (q_pb, t_pc) = p0;
                                        crate::prelude::call_then(start_subst_rigids_f(above_p5xy.types_p.clone(), t_pc.clone()), move |subst_rigids_f_14758: crate::check::types::Ty| ::prism_rtl::Turn::Finished((q_pb.clone(), subst_rigids_f_14758)))
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Text, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::Ty)>>>
                            }), move |each_14725: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>| ::prism_rtl::Turn::More(::std::rc::Rc::new(GrowsBack { path_p0: path_p0x.clone(), composed_p1: each_14725, target_p2: target_p2x.clone(), below_p3: at_p4.clone() })))
                        },
                    }
                },
            },
        }
    }
}

/// `Start GrowsBack, x`: what the function value is when passed to `@Run`.
pub fn start_grows_back_o(path_p0: crate::prelude::Array<GrowthStep>, composed_p1: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, target_p2: crate::prelude::Text, below_p3: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<(crate::prelude::Nat, crate::prelude::Text, crate::check::types::Ty)>>> {
    ::std::rc::Rc::new(GrowsBack { path_p0, composed_p1, target_p2, below_p3 })
}

/// ```prism
/// SubstRigids: unbounded fn [((Text, Ty))], Ty -> Ty
/// ```
pub fn subst_rigids_f(by_p0: &crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p1 {
        crate::check::types::Ty::TyRigid(n_p2) => match crate::prelude::index(&crate::prelude::filter(by_p0, &(|(q_p3, _): &(crate::prelude::Text, crate::check::types::Ty)| q_p3 == n_p2)), &crate::prelude::Nat::from(0u32)) {
            ::std::option::Option::Some((_, to_p4)) => to_p4,
            ::std::option::Option::None => t_p1.clone(),
        },
        crate::check::types::Ty::TyCon(n_p5, args_p6) => crate::check::types::Ty::TyCon(n_p5.clone(), crate::prelude::run_to_end(crate::prelude::each_job(args_p6.clone(), {
            let by_p0x = by_p0.clone();
            ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                let by_p0xy = by_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p7 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(SubstRigids { by_p0: by_p0xy.clone(), t_p1: a_p7.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyFn(c_p8, ps_p9, r_pa) => crate::check::types::Ty::TyFn(c_p8.clone(), crate::prelude::run_to_end(crate::prelude::each_job(ps_p9.clone(), {
            let by_p0x = by_p0.clone();
            ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                let by_p0xy = by_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pb = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(SubstRigids { by_p0: by_p0xy.clone(), t_p1: a_pb.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
        })), ::std::rc::Rc::new(subst_rigids_f(by_p0, &**r_pa))),
        crate::check::types::Ty::TyTuple(ts_pc) => crate::check::types::Ty::TyTuple(crate::prelude::run_to_end(crate::prelude::each_job(ts_pc.clone(), {
            let by_p0x = by_p0.clone();
            ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                let by_p0xy = by_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pd = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(SubstRigids { by_p0: by_p0xy.clone(), t_p1: a_pd.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyArray(e_pe) => crate::check::types::Ty::TyArray(::std::rc::Rc::new(subst_rigids_f(by_p0, &**e_pe))),
        crate::check::types::Ty::TyMap(k_pf, v_pg) => crate::check::types::Ty::TyMap(::std::rc::Rc::new(subst_rigids_f(by_p0, &**k_pf)), ::std::rc::Rc::new(subst_rigids_f(by_p0, &**v_pg))),
        crate::check::types::Ty::TySig(s_ph, i_pi) => crate::check::types::Ty::TySig(s_ph.clone(), ::std::rc::Rc::new(subst_rigids_f(by_p0, &**i_pi))),
        crate::check::types::Ty::TyAt(i_pj, rw_pk) => crate::check::types::Ty::TyAt(::std::rc::Rc::new(subst_rigids_f(by_p0, &**i_pj)), rw_pk.clone()),
        crate::check::types::Ty::TyElem(rw_pl, o_pm) => crate::check::types::Ty::TyElem(rw_pl.clone(), ::std::rc::Rc::new(subst_rigids_f(by_p0, &**o_pm))),
        crate::check::types::Ty::TyAssoc(tr_pn, n_po, a_pp) => crate::check::types::Ty::TyAssoc(tr_pn.clone(), n_po.clone(), ::std::rc::Rc::new(subst_rigids_f(by_p0, &**a_pp))),
        other_pq => other_pq.clone(),
    }
}

/// The step machine of `SubstRigids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SubstRigids: unbounded fn [((Text, Ty))], Ty -> Ty
/// ```
pub struct SubstRigids {
    pub by_p0: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>,
    pub t_p1: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::Ty> for SubstRigids {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::Ty> {
        let by_p0 = &self.by_p0;
        let t_p1 = &self.t_p1;
        match t_p1 {
            crate::check::types::Ty::TyRigid(n_p2) => match crate::prelude::index(&crate::prelude::filter(by_p0, &(|(q_p3, _): &(crate::prelude::Text, crate::check::types::Ty)| q_p3 == n_p2)), &crate::prelude::Nat::from(0u32)) {
                ::std::option::Option::Some((_, to_p4)) => ::prism_rtl::Turn::Finished(to_p4.clone()),
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(t_p1.clone()),
            },
            crate::check::types::Ty::TyCon(n_p5, args_p6) => {
                let args_p6x = args_p6.clone();
                let by_p0x = by_p0.clone();
                let n_p5x = n_p5.clone();
                crate::prelude::call_value(crate::prelude::each_job(args_p6x.clone(), {
                    let by_p0xx = by_p0x.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                        let by_p0xxy = by_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_p7 = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(SubstRigids { by_p0: by_p0xxy.clone(), t_p1: a_p7.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_15109: crate::prelude::Array<crate::check::types::Ty>| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyCon(n_p5x.clone(), each_15109)))
            },
            crate::check::types::Ty::TyFn(c_p8, ps_p9, r_pa) => {
                let by_p0x = by_p0.clone();
                let c_p8x = c_p8.clone();
                let ps_p9x = ps_p9.clone();
                let r_pax = (**r_pa).clone();
                crate::prelude::call_value(crate::prelude::each_job(ps_p9x.clone(), {
                    let by_p0xx = by_p0x.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                        let by_p0xxy = by_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_pb = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(SubstRigids { by_p0: by_p0xxy.clone(), t_p1: a_pb.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_15172: crate::prelude::Array<crate::check::types::Ty>| crate::prelude::call_then(start_subst_rigids_f(by_p0x.clone(), r_pax.clone()), move |subst_rigids_f_15207: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyFn(c_p8x.clone(), each_15172, ::std::rc::Rc::new(subst_rigids_f_15207)))))
            },
            crate::check::types::Ty::TyTuple(ts_pc) => {
                let by_p0x = by_p0.clone();
                let ts_pcx = ts_pc.clone();
                crate::prelude::call_value(crate::prelude::each_job(ts_pcx.clone(), {
                    let by_p0xx = by_p0x.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                        let by_p0xxy = by_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_pd = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(SubstRigids { by_p0: by_p0xxy.clone(), t_p1: a_pd.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_15251: crate::prelude::Array<crate::check::types::Ty>| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyTuple(each_15251)))
            },
            crate::check::types::Ty::TyArray(e_pe) => {
                let by_p0x = by_p0.clone();
                let e_pex = (**e_pe).clone();
                crate::prelude::call_then(start_subst_rigids_f(by_p0x.clone(), e_pex.clone()), move |subst_rigids_f_15308: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyArray(::std::rc::Rc::new(subst_rigids_f_15308))))
            },
            crate::check::types::Ty::TyMap(k_pf, v_pg) => {
                let by_p0x = by_p0.clone();
                let k_pfx = (**k_pf).clone();
                let v_pgx = (**v_pg).clone();
                crate::prelude::call_then(start_subst_rigids_f(by_p0x.clone(), k_pfx.clone()), move |subst_rigids_f_15350: crate::check::types::Ty| crate::prelude::call_then(start_subst_rigids_f(by_p0x.clone(), v_pgx.clone()), move |subst_rigids_f_15371: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyMap(::std::rc::Rc::new(subst_rigids_f_15350), ::std::rc::Rc::new(subst_rigids_f_15371)))))
            },
            crate::check::types::Ty::TySig(s_ph, i_pi) => {
                let by_p0x = by_p0.clone();
                let i_pix = (**i_pi).clone();
                let s_phx = s_ph.clone();
                crate::prelude::call_then(start_subst_rigids_f(by_p0x.clone(), i_pix.clone()), move |subst_rigids_f_15416: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TySig(s_phx.clone(), ::std::rc::Rc::new(subst_rigids_f_15416))))
            },
            crate::check::types::Ty::TyAt(i_pj, rw_pk) => {
                let by_p0x = by_p0.clone();
                let i_pjx = (**i_pj).clone();
                let rw_pkx = rw_pk.clone();
                crate::prelude::call_then(start_subst_rigids_f(by_p0x.clone(), i_pjx.clone()), move |subst_rigids_f_15457: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyAt(::std::rc::Rc::new(subst_rigids_f_15457), rw_pkx.clone())))
            },
            crate::check::types::Ty::TyElem(rw_pl, o_pm) => {
                let by_p0x = by_p0.clone();
                let o_pmx = (**o_pm).clone();
                let rw_plx = rw_pl.clone();
                crate::prelude::call_then(start_subst_rigids_f(by_p0x.clone(), o_pmx.clone()), move |subst_rigids_f_15510: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyElem(rw_plx.clone(), ::std::rc::Rc::new(subst_rigids_f_15510))))
            },
            crate::check::types::Ty::TyAssoc(tr_pn, n_po, a_pp) => {
                let a_ppx = (**a_pp).clone();
                let by_p0x = by_p0.clone();
                let n_pox = n_po.clone();
                let tr_pnx = tr_pn.clone();
                crate::prelude::call_then(start_subst_rigids_f(by_p0x.clone(), a_ppx.clone()), move |subst_rigids_f_15567: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyAssoc(tr_pnx.clone(), n_pox.clone(), ::std::rc::Rc::new(subst_rigids_f_15567))))
            },
            other_pq => ::prism_rtl::Turn::Finished(other_pq.clone()),
        }
    }
}

/// `Start SubstRigids, x`: what the function value is when passed to `@Run`.
pub fn start_subst_rigids_f(by_p0: crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>, t_p1: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>> {
    ::std::rc::Rc::new(SubstRigids { by_p0, t_p1 })
}

/// ```prism
/// TypedOf: unbounded fn G, St, Nat -> TProgram
/// ```
pub fn typed_of_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, shown_p2: &crate::prelude::Nat) -> crate::check::typed::TProgram {
    let z_p3 = crate::check::types::recording::zonk_typed_f(st_p1);
    let vals_p4 = crate::prelude::filter(&crate::prelude::values(&g_p0.vals_p), &(|v_p5: &crate::check::env::ValInfo| ((&v_p5.file_p < shown_p2) && (&v_p5.sort_p != &crate::prelude::Text::lit("builtin"))) && (&crate::prelude::or(&crate::prelude::get(&g_p0.mods_p, &v_p5.home_p), &crate::check::env::reading::dummy_mod_p()).file_p == &v_p5.file_p)));
    let mut this: crate::check::typed::TProgram = z_p3.clone();
    this.defs_p = crate::prelude::run_to_end(crate::prelude::each_job(vals_p4.clone(), {
        let st_p1x = st_p1.clone();
        ::std::rc::Rc::new(move |p0: crate::check::env::ValInfo| {
            let st_p1xy = st_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let v_p6 = p0;
                crate::prelude::call_then(start_zonk_scheme_f(st_p1xy.clone(), v_p6.scheme_p.clone()), move |zonk_scheme_f_16079: crate::check::types::Scheme| ::prism_rtl::Turn::Finished(crate::check::typed::DefNote { at_p: crate::check::typed::SrcAt { file_p: v_p6.file_p.clone(), span_p: v_p6.span_p.clone() }, name_p: v_p6.qk_p.clone(), scheme_p: zonk_scheme_f_16079 }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::env::ValInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::typed::DefNote>>>
    }));
    this
}

/// The step machine of `TypedOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypedOf: unbounded fn G, St, Nat -> TProgram
/// ```
pub struct TypedOf {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub shown_p2: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::check::typed::TProgram> for TypedOf {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::typed::TProgram> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let shown_p2 = &self.shown_p2;
        let g_p0x = g_p0.clone();
        let shown_p2x = shown_p2.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_zonk_typed_f(st_p1x.clone()), move |zonk_typed_f_15822: crate::check::typed::TProgram| {
            let z_p3 = zonk_typed_f_15822;
            let vals_p4 = crate::prelude::filter(&crate::prelude::values(&g_p0x.vals_p), &(|v_p5: &crate::check::env::ValInfo| ((&v_p5.file_p < &shown_p2x) && (&v_p5.sort_p != &crate::prelude::Text::lit("builtin"))) && (&crate::prelude::or(&crate::prelude::get(&g_p0x.mods_p, &v_p5.home_p), &crate::check::env::reading::dummy_mod_p()).file_p == &v_p5.file_p)));
            ::prism_rtl::Turn::Finished({
                let mut this: crate::check::typed::TProgram = z_p3.clone();
                this.defs_p = crate::prelude::run_to_end(crate::prelude::each_job(vals_p4.clone(), {
                    let st_p1xx = st_p1x.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::env::ValInfo| {
                        let st_p1xxy = st_p1xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let v_p6 = p0;
                            crate::prelude::call_then(start_zonk_scheme_f(st_p1xxy.clone(), v_p6.scheme_p.clone()), move |zonk_scheme_f_16079: crate::check::types::Scheme| ::prism_rtl::Turn::Finished(crate::check::typed::DefNote { at_p: crate::check::typed::SrcAt { file_p: v_p6.file_p.clone(), span_p: v_p6.span_p.clone() }, name_p: v_p6.qk_p.clone(), scheme_p: zonk_scheme_f_16079 }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::env::ValInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::typed::DefNote>>>
                }));
                this
            })
        })
    }
}

/// `Start TypedOf, x`: what the function value is when passed to `@Run`.
pub fn start_typed_of_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, shown_p2: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::typed::TProgram>> {
    ::std::rc::Rc::new(TypedOf { g_p0, st_p1, shown_p2 })
}

/// ```prism
/// ZonkScheme: unbounded fn St, Scheme -> Scheme
/// ```
pub fn zonk_scheme_f(st_p0: &crate::check::types::St, sc_p1: &crate::check::types::Scheme) -> crate::check::types::Scheme {
    let mut this: crate::check::types::Scheme = sc_p1.clone();
    this.ty_p = crate::check::types::recording::zonk_f(st_p0, &this.ty_p);
    this
}

/// The step machine of `ZonkScheme`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ZonkScheme: unbounded fn St, Scheme -> Scheme
/// ```
pub struct ZonkScheme {
    pub st_p0: crate::check::types::St,
    pub sc_p1: crate::check::types::Scheme,
}

impl ::prism_rtl::Job<crate::check::types::Scheme> for ZonkScheme {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::Scheme> {
        let st_p0 = &self.st_p0;
        let sc_p1 = &self.sc_p1;
        ::prism_rtl::Turn::Finished({
            let mut this: crate::check::types::Scheme = sc_p1.clone();
            this.ty_p = crate::check::types::recording::zonk_f(st_p0, &this.ty_p);
            this
        })
    }
}

/// `Start ZonkScheme, x`: what the function value is when passed to `@Run`.
pub fn start_zonk_scheme_f(st_p0: crate::check::types::St, sc_p1: crate::check::types::Scheme) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Scheme>> {
    ::std::rc::Rc::new(ZonkScheme { st_p0, sc_p1 })
}

/// ```prism
/// TopLets: unbounded fn G, St -> ((G, St))
/// ```
pub fn top_lets_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St) -> (crate::check::env::G, crate::check::types::St) {
    let unsigned_p2 = crate::prelude::filter(&g_p0.defs_p, &(|d_p3: &crate::check::env::Def| is_let_def_f(d_p3) && !crate::check::env::has_key_f(&g_p0.vals_p, &d_p3.qk_p)));
    let (g1_pa, st1_pb) = crate::prelude::fold(&unsigned_p2, &(g_p0.clone(), st_p1.clone()), &(|(gg_p4, s_p5): &(crate::check::env::G, crate::check::types::St), d_p6: &crate::check::env::Def| {
        let (v_p8, s2_p9) = crate::check::types::fresh_var_f(s_p5, &false, &d_p6.name_p);
        let gg2_p7 = {
            let mut this: crate::check::env::G = gg_p4.clone();
            this.vals_p = crate::prelude::insert(&this.vals_p, &d_p6.qk_p, &crate::check::env::ValInfo { qk_p: d_p6.qk_p.clone(), scheme_p: crate::check::types::schemes::mono_f(&v_p8), sort_p: crate::prelude::Text::lit("let"), has_sig_p: false, home_p: d_p6.home_p.clone(), file_p: d_p6.file_p.clone(), span_p: d_p6.span_p.clone() });
            this
        };
        (gg2_p7.clone(), s2_p9.clone())
    }));
    crate::prelude::run_to_end(crate::prelude::fold_job(unsigned_p2.clone(), (g1_pa.clone(), st1_pb.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St), crate::check::env::Def)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (gg_pc, s_pd) = p0;
        let d_pe = p1;
        match &d_pe.body_p {
            crate::check::env::DefBody::DbLet(l_pf) => {
                let env_pg = def_env_f(&gg_pc, &d_pe);
                let s0_ph = {
                    let mut this: crate::check::types::St = s_pd.clone();
                    this.file_p = d_pe.file_p.clone();
                    this.definition_p = d_pe.qk_p.clone();
                    this.level_p = crate::prelude::Nat::from(1u32);
                    this.local_next_p = crate::prelude::Nat::from(0u32);
                    this
                };
                let ahead_pi = crate::prelude::or(&crate::prelude::get(&gg_pc.vals_p, &d_pe.qk_p), &dummy_val_p()).scheme_p.ty_p.clone();
                let (pre_ps, s0v_pt) = crate::check::types::fresh_var_f(&s0_ph, &false, &d_pe.name_p);
                let l_pfx = l_pf.clone();
                crate::prelude::call_then(crate::check::expr::start_check_f(env_pg.clone(), s0v_pt.clone(), l_pfx.value_p.clone(), pre_ps.clone()), move |check_f_17739: crate::check::types::St| {
                    let s1_pj = check_f_17739;
                    crate::prelude::call_then(crate::check::env::traits::start_solve_wants_f(gg_pc.clone(), s1_pj.clone(), crate::prelude::Array::new(), false), move |solve_wants_f_17790: crate::check::types::St| {
                        let s2a_pk = solve_wants_f_17790;
                        crate::prelude::call_then(crate::check::types::start_is_flex_var_f(s2a_pk.clone(), ahead_pi.clone()), move |is_flex_var_f_18226: bool| {
                            let used_pl = !is_flex_var_f_18226;
                            let ahead_piz = ahead_pi.clone();
                            let d_pez = d_pe.clone();
                            let gg_pcz = gg_pc.clone();
                            let l_pfxz = l_pfx.clone();
                            let pre_psz = pre_ps.clone();
                            let used_plz = used_pl;
                            let k_let18260 = move |v18260: crate::check::types::St| {
                                let s2_pm = v18260;
                                let s3_pn = {
                                    let mut this: crate::check::types::St = s2_pm.clone();
                                    this.level_p = crate::prelude::Nat::from(0u32);
                                    this
                                };
                                crate::prelude::call_then(crate::check::types::recording::start_zonk_f(s3_pn.clone(), pre_psz.clone()), move |zonk_f_18400: crate::check::types::Ty| {
                                    let t_po = zonk_f_18400;
                                    crate::prelude::call_then(crate::check::types::colors::start_free_col_vars_f(s3_pn.clone(), t_po.clone()), move |free_col_vars_f_18706: crate::prelude::Array<crate::prelude::Nat>| {
                                        let s3c_pp = crate::check::types::unify::lower_levels_f(&s3_pn, &free_col_vars_f_18706, &crate::prelude::Nat::from(0u32));
                                        crate::prelude::call_then(crate::check::expr::lets::start_wants_above_f(s3c_pp.clone(), t_po.clone(), crate::check::expr::is_lambda_f(&l_pfxz.value_p)), move |wants_above_f_18767: (crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text)>, crate::check::types::St)| {
                                            let (keep_pu, bounds_pv, s4_p10) = wants_above_f_18767;
                                            crate::prelude::call_then(crate::check::types::schemes::start_holds_node_f(s4_p10.clone(), t_po.clone()), move |holds_node_f_18838: bool| {
                                                let ahead_pizz = ahead_piz.clone();
                                                let d_pezz = d_pez.clone();
                                                let gg_pczz = gg_pcz.clone();
                                                let t_poz = t_po.clone();
                                                let used_plzz = used_plz;
                                                let k_let18817 = move |v18817: (crate::check::types::Scheme, crate::check::types::St)| {
                                                    let (sc_p11, s5a_p12) = v18817;
                                                    let d_pezzz = d_pezz.clone();
                                                    let gg_pczzz = gg_pczz.clone();
                                                    let sc_p11z = sc_p11.clone();
                                                    let k_let18919 = move |v18919: crate::check::types::St| {
                                                        let s5_pq = v18919;
                                                        let gg2_pr = {
                                                            let mut this: crate::check::env::G = gg_pczzz.clone();
                                                            this.vals_p = crate::prelude::insert(&this.vals_p, &d_pezzz.qk_p, &crate::check::env::ValInfo { qk_p: d_pezzz.qk_p.clone(), scheme_p: sc_p11z.clone(), sort_p: crate::prelude::Text::lit("let"), has_sig_p: false, home_p: d_pezzz.home_p.clone(), file_p: d_pezzz.file_p.clone(), span_p: d_pezzz.span_p.clone() });
                                                            this
                                                        };
                                                        crate::prelude::call_then(crate::check::types::colors::start_check_colors_f(s5_pq.clone()), move |check_colors_f_19225: crate::check::types::St| crate::prelude::call_then(crate::check::env::traits::start_resolve_fields_f(gg_pczzz.clone(), check_colors_f_19225, true), move |resolve_fields_f_19206: crate::check::types::St| crate::prelude::call_then(crate::check::types::unify::start_layer_questions_f(resolve_fields_f_19206), move |layer_questions_f_19190: crate::check::types::St| crate::prelude::call_then(crate::check::passes::start_discharge_incls_f(gg_pczzz.clone(), layer_questions_f_19190, crate::prelude::Nat::from(0u32)), move |discharge_incls_f_19170: crate::check::types::St| ::prism_rtl::Turn::Finished((gg2_pr.clone(), discharge_incls_f_19170))))))
                                                    };
                                                    if used_plzz {
                                                        k_let18919(s5a_p12.clone())
                                                    } else {
                                                        crate::prelude::call_then(crate::check::types::unify::start_unify_f(s5a_p12.clone(), ahead_pizz.clone(), t_poz.clone(), d_pezz.span_p.clone()), move |unify_f_18947: crate::check::types::St| k_let18919(unify_f_18947))
                                                    }
                                                };
                                                if holds_node_f_18838 {
                                                    k_let18817((crate::check::types::schemes::mono_f(&t_po), s4_p10.clone()))
                                                } else {
                                                    crate::prelude::call_then(crate::check::types::schemes::start_generalize_f(s4_p10.clone(), t_po.clone(), keep_pu.clone(), bounds_pv.clone()), move |generalize_f_18876: (crate::check::types::Scheme, crate::check::types::St)| k_let18817(generalize_f_18876))
                                                }
                                            })
                                        })
                                    })
                                })
                            };
                            if used_pl {
                                crate::prelude::call_then(crate::check::types::unify::start_unify_f(s2a_pk.clone(), ahead_pi.clone(), pre_ps.clone(), d_pe.span_p.clone()), move |unify_f_18278: crate::check::types::St| k_let18260(unify_f_18278))
                            } else {
                                k_let18260(s2a_pk.clone())
                            }
                        })
                    })
                })
            },
            _ => ::prism_rtl::Turn::Finished((gg_pc.clone(), s_pd.clone())),
        }
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::env::G, crate::check::types::St), crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>>>))
}

/// The step machine of `TopLets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TopLets: unbounded fn G, St -> ((G, St))
/// ```
pub struct TopLets {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
}

impl ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for TopLets {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let unsigned_p2 = crate::prelude::filter(&g_p0.defs_p, &(|d_p3: &crate::check::env::Def| is_let_def_f(d_p3) && !crate::check::env::has_key_f(&g_p0.vals_p, &d_p3.qk_p)));
        let (g1_pa, st1_pb) = crate::prelude::fold(&unsigned_p2, &(g_p0.clone(), st_p1.clone()), &(|(gg_p4, s_p5): &(crate::check::env::G, crate::check::types::St), d_p6: &crate::check::env::Def| {
            let (v_p8, s2_p9) = crate::check::types::fresh_var_f(s_p5, &false, &d_p6.name_p);
            let gg2_p7 = {
                let mut this: crate::check::env::G = gg_p4.clone();
                this.vals_p = crate::prelude::insert(&this.vals_p, &d_p6.qk_p, &crate::check::env::ValInfo { qk_p: d_p6.qk_p.clone(), scheme_p: crate::check::types::schemes::mono_f(&v_p8), sort_p: crate::prelude::Text::lit("let"), has_sig_p: false, home_p: d_p6.home_p.clone(), file_p: d_p6.file_p.clone(), span_p: d_p6.span_p.clone() });
                this
            };
            (gg2_p7.clone(), s2_p9.clone())
        }));
        crate::prelude::fold_job(unsigned_p2.clone(), (g1_pa.clone(), st1_pb.clone()), ::std::rc::Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St), crate::check::env::Def)| crate::prelude::entered(crate::prelude::once_job(move || {
            let (gg_pc, s_pd) = p0;
            let d_pe = p1;
            match &d_pe.body_p {
                crate::check::env::DefBody::DbLet(l_pf) => {
                    let env_pg = def_env_f(&gg_pc, &d_pe);
                    let s0_ph = {
                        let mut this: crate::check::types::St = s_pd.clone();
                        this.file_p = d_pe.file_p.clone();
                        this.definition_p = d_pe.qk_p.clone();
                        this.level_p = crate::prelude::Nat::from(1u32);
                        this.local_next_p = crate::prelude::Nat::from(0u32);
                        this
                    };
                    let ahead_pi = crate::prelude::or(&crate::prelude::get(&gg_pc.vals_p, &d_pe.qk_p), &dummy_val_p()).scheme_p.ty_p.clone();
                    let (pre_ps, s0v_pt) = crate::check::types::fresh_var_f(&s0_ph, &false, &d_pe.name_p);
                    let l_pfx = l_pf.clone();
                    crate::prelude::call_then(crate::check::expr::start_check_f(env_pg.clone(), s0v_pt.clone(), l_pfx.value_p.clone(), pre_ps.clone()), move |check_f_17739: crate::check::types::St| {
                        let s1_pj = check_f_17739;
                        crate::prelude::call_then(crate::check::env::traits::start_solve_wants_f(gg_pc.clone(), s1_pj.clone(), crate::prelude::Array::new(), false), move |solve_wants_f_17790: crate::check::types::St| {
                            let s2a_pk = solve_wants_f_17790;
                            crate::prelude::call_then(crate::check::types::start_is_flex_var_f(s2a_pk.clone(), ahead_pi.clone()), move |is_flex_var_f_18226: bool| {
                                let used_pl = !is_flex_var_f_18226;
                                let ahead_piz = ahead_pi.clone();
                                let d_pez = d_pe.clone();
                                let gg_pcz = gg_pc.clone();
                                let l_pfxz = l_pfx.clone();
                                let pre_psz = pre_ps.clone();
                                let used_plz = used_pl;
                                let k_let18260 = move |v18260: crate::check::types::St| {
                                    let s2_pm = v18260;
                                    let s3_pn = {
                                        let mut this: crate::check::types::St = s2_pm.clone();
                                        this.level_p = crate::prelude::Nat::from(0u32);
                                        this
                                    };
                                    crate::prelude::call_then(crate::check::types::recording::start_zonk_f(s3_pn.clone(), pre_psz.clone()), move |zonk_f_18400: crate::check::types::Ty| {
                                        let t_po = zonk_f_18400;
                                        crate::prelude::call_then(crate::check::types::colors::start_free_col_vars_f(s3_pn.clone(), t_po.clone()), move |free_col_vars_f_18706: crate::prelude::Array<crate::prelude::Nat>| {
                                            let s3c_pp = crate::check::types::unify::lower_levels_f(&s3_pn, &free_col_vars_f_18706, &crate::prelude::Nat::from(0u32));
                                            crate::prelude::call_then(crate::check::expr::lets::start_wants_above_f(s3c_pp.clone(), t_po.clone(), crate::check::expr::is_lambda_f(&l_pfxz.value_p)), move |wants_above_f_18767: (crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text)>, crate::check::types::St)| {
                                                let (keep_pu, bounds_pv, s4_p10) = wants_above_f_18767;
                                                crate::prelude::call_then(crate::check::types::schemes::start_holds_node_f(s4_p10.clone(), t_po.clone()), move |holds_node_f_18838: bool| {
                                                    let ahead_pizz = ahead_piz.clone();
                                                    let d_pezz = d_pez.clone();
                                                    let gg_pczz = gg_pcz.clone();
                                                    let t_poz = t_po.clone();
                                                    let used_plzz = used_plz;
                                                    let k_let18817 = move |v18817: (crate::check::types::Scheme, crate::check::types::St)| {
                                                        let (sc_p11, s5a_p12) = v18817;
                                                        let d_pezzz = d_pezz.clone();
                                                        let gg_pczzz = gg_pczz.clone();
                                                        let sc_p11z = sc_p11.clone();
                                                        let k_let18919 = move |v18919: crate::check::types::St| {
                                                            let s5_pq = v18919;
                                                            let gg2_pr = {
                                                                let mut this: crate::check::env::G = gg_pczzz.clone();
                                                                this.vals_p = crate::prelude::insert(&this.vals_p, &d_pezzz.qk_p, &crate::check::env::ValInfo { qk_p: d_pezzz.qk_p.clone(), scheme_p: sc_p11z.clone(), sort_p: crate::prelude::Text::lit("let"), has_sig_p: false, home_p: d_pezzz.home_p.clone(), file_p: d_pezzz.file_p.clone(), span_p: d_pezzz.span_p.clone() });
                                                                this
                                                            };
                                                            crate::prelude::call_then(crate::check::types::colors::start_check_colors_f(s5_pq.clone()), move |check_colors_f_19225: crate::check::types::St| crate::prelude::call_then(crate::check::env::traits::start_resolve_fields_f(gg_pczzz.clone(), check_colors_f_19225, true), move |resolve_fields_f_19206: crate::check::types::St| crate::prelude::call_then(crate::check::types::unify::start_layer_questions_f(resolve_fields_f_19206), move |layer_questions_f_19190: crate::check::types::St| crate::prelude::call_then(crate::check::passes::start_discharge_incls_f(gg_pczzz.clone(), layer_questions_f_19190, crate::prelude::Nat::from(0u32)), move |discharge_incls_f_19170: crate::check::types::St| ::prism_rtl::Turn::Finished((gg2_pr.clone(), discharge_incls_f_19170))))))
                                                        };
                                                        if used_plzz {
                                                            k_let18919(s5a_p12.clone())
                                                        } else {
                                                            crate::prelude::call_then(crate::check::types::unify::start_unify_f(s5a_p12.clone(), ahead_pizz.clone(), t_poz.clone(), d_pezz.span_p.clone()), move |unify_f_18947: crate::check::types::St| k_let18919(unify_f_18947))
                                                        }
                                                    };
                                                    if holds_node_f_18838 {
                                                        k_let18817((crate::check::types::schemes::mono_f(&t_po), s4_p10.clone()))
                                                    } else {
                                                        crate::prelude::call_then(crate::check::types::schemes::start_generalize_f(s4_p10.clone(), t_po.clone(), keep_pu.clone(), bounds_pv.clone()), move |generalize_f_18876: (crate::check::types::Scheme, crate::check::types::St)| k_let18817(generalize_f_18876))
                                                    }
                                                })
                                            })
                                        })
                                    })
                                };
                                if used_pl {
                                    crate::prelude::call_then(crate::check::types::unify::start_unify_f(s2a_pk.clone(), ahead_pi.clone(), pre_ps.clone(), d_pe.span_p.clone()), move |unify_f_18278: crate::check::types::St| k_let18260(unify_f_18278))
                                } else {
                                    k_let18260(s2a_pk.clone())
                                }
                            })
                        })
                    })
                },
                _ => ::prism_rtl::Turn::Finished((gg_pc.clone(), s_pd.clone())),
            }
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::check::env::G, crate::check::types::St), crate::check::env::Def)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>>>).cycle()
    }
}

/// `Start TopLets, x`: what the function value is when passed to `@Run`.
pub fn start_top_lets_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    ::std::rc::Rc::new(TopLets { g_p0, st_p1 })
}

/// ```prism
/// let dummyVal
/// ```
pub fn dummy_val_p() -> crate::check::env::ValInfo {
    crate::check::env::ValInfo { qk_p: crate::prelude::Text::lit(""), scheme_p: crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyErr), sort_p: crate::prelude::Text::lit(""), has_sig_p: false, home_p: crate::prelude::Text::lit(""), file_p: crate::prelude::Nat::from(0u32), span_p: crate::syntax::Range { start_p: crate::prelude::Nat::from(0u32), end_p: crate::prelude::Nat::from(0u32) } }
}

/// ```prism
/// IsLetDef: fn Def -> Bool
/// ```
pub fn is_let_def_f(d_p0: &crate::check::env::Def) -> bool {
    match &d_p0.body_p {
        crate::check::env::DefBody::DbLet(_) => true,
        _ => false,
    }
}

/// ```prism
/// DefEnv: fn G, Def -> Env
/// ```
pub fn def_env_f(g_p0: &crate::check::env::G, d_p1: &crate::check::env::Def) -> crate::check::expr::Env {
    let info_p2 = crate::prelude::or(&crate::prelude::get(&g_p0.mods_p, &d_p1.home_p), &crate::check::env::reading::dummy_mod_p());
    let scope_p3 = match &info_p2.emit_rw_p.tail_p {
        crate::check::types::Tail::TlQ(v_p4) => crate::check::types::Rw { fams_p: info_p2.emit_rw_p.fams_p.clone(), minus_p: crate::prelude::Array::new(), tail_p: crate::check::types::Tail::TlRigid(v_p4.clone()) },
        _ => info_p2.emit_rw_p.clone(),
    };
    crate::check::expr::Env { g_p: g_p0.clone(), home_p: d_p1.home_p.clone(), file_p: d_p1.file_p.clone(), src_p: crate::prelude::or(&crate::prelude::index(&g_p0.srcs_p, &d_p1.file_p), &crate::check::errors::mk_src_f(&crate::prelude::Text::lit(""), &crate::prelude::Text::lit(""))), locals_p: crate::prelude::Map::new(), scope_p: scope_p3.clone(), givens_p: crate::prelude::Array::new(), mark_p: crate::prelude::Text::lit(""), in_update_p: false, def_name_p: d_p1.name_p.clone(), refine_p: crate::prelude::Map::new(), pending_p: crate::prelude::Array::new(), ids_p: crate::prelude::Map::new() }
}

/// ```prism
/// CheckDef: unbounded fn G, St, Def -> St
/// ```
pub fn check_def_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, d_p2: &crate::check::env::Def) -> crate::check::types::St {
    let env_p3 = def_env_f(g_p0, d_p2);
    let incls_before_p4 = crate::prelude::len(&st_p1.incls_p);
    let own_p5 = crate::check::shrink::types::own_key_f(d_p2).qk_p.clone();
    let s0_p6 = {
        let mut this: crate::check::types::St = st_p1.clone();
        this.file_p = d_p2.file_p.clone();
        this.definition_p = own_p5.clone();
        this.level_p = crate::prelude::Nat::from(1u32);
        this.local_next_p = crate::prelude::Nat::from(0u32);
        this.color_p = crate::check::types::Col::CBound;
        this.color_why_p = crate::prelude::Text::lit("");
        this.color_flex_p = crate::prelude::Array::new();
        this.cleqs_p = crate::prelude::Array::new();
        this
    };
    let s1_p7 = match &d_p2.body_p {
        crate::check::env::DefBody::DbFn(clauses_pc) => match crate::prelude::get(&g_p0.vals_p, &d_p2.qk_p) {
            ::std::option::Option::Some(v_pd) => if crate::check::env::decls::is_lens_text_f(&d_p2.name_p) {
                crate::check::blocks::borrows::check_lens_f(&env_p3, &s0_p6, &d_p2.name_p, clauses_pc, &v_pd.scheme_p, &d_p2.span_p)
            } else {
                crate::check::expr::lets::check_clauses_f(&env_p3, &s0_p6, &d_p2.name_p, clauses_pc, &v_pd.scheme_p, &d_p2.span_p)
            },
            ::std::option::Option::None => s0_p6.clone(),
        },
        crate::check::env::DefBody::DbWidget(w_pe) => check_widget_def_f(&env_p3, &s0_p6, d_p2, w_pe),
        crate::check::env::DefBody::DbLet(l_pf) => match crate::prelude::get(&g_p0.vals_p, &d_p2.qk_p) {
            ::std::option::Option::Some(v_pg) => if v_pg.has_sig_p {
                crate::check::expr::check_f(&env_p3, &s0_p6, &l_pf.value_p, &crate::check::types::schemes::skolemize_f(&v_pg.scheme_p))
            } else {
                s0_p6.clone()
            },
            ::std::option::Option::None => s0_p6.clone(),
        },
        crate::check::env::DefBody::DbMethod(clauses_ph, cls_pi, im_pj) => check_method_f(&env_p3, &s0_p6, d_p2, clauses_ph, cls_pi, im_pj),
        crate::check::env::DefBody::DbDefault(clauses_pk, cls_pl) => match method_key_o(g_p0, cls_pl, &d_p2.name_p) {
            ::std::option::Option::Some(mk_pm) => match crate::prelude::get(&g_p0.vals_p, &mk_pm) {
                ::std::option::Option::Some(v_pn) => crate::check::expr::lets::check_clauses_f(&env_p3, &s0_p6, &d_p2.name_p, clauses_pk, &v_pn.scheme_p, &d_p2.span_p),
                ::std::option::Option::None => s0_p6.clone(),
            },
            ::std::option::Option::None => s0_p6.clone(),
        },
        crate::check::env::DefBody::DbCheck(c_po) => crate::prelude::run_to_end(crate::prelude::fold_job(c_po.lines_p.clone(), s0_p6.clone(), {
            let env_p3x = env_p3.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::CheckLine)| {
                let env_p3xy = env_p3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let s_pp = p0;
                    let line_pq = p1;
                    crate::prelude::call_then(crate::check::expr::start_infer_f(env_p3xy.clone(), s_pp.clone(), line_pq.expr_p.clone()), move |infer_f_21411: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t_pr, s2_ps) = infer_f_21411;
                        match &line_pq.pattern_o {
                            ::std::option::Option::Some(p_pt) => {
                                let p_ptx = p_pt.clone();
                                crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(env_p3xy.clone(), s2_ps.clone(), p_ptx.clone(), t_pr.clone(), true), move |bind_pattern_f_21530: (crate::check::expr::Env, crate::check::types::St)| {
                                    let (_, s3_pu) = bind_pattern_f_21530;
                                    ::prism_rtl::Turn::Finished(s3_pu.clone())
                                })
                            },
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished(s2_ps.clone()),
                        }
                    })
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::syntax::decls::CheckLine)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
        })),
        crate::check::env::DefBody::DbTest(t_pv) => {
            let (bt_p10, s2_p11) = crate::check::expr::infer_f(&env_p3, &s0_p6, &t_pv.blueprint_p);
            match crate::check::types::recording::walk_f(&s2_p11, &bt_p10) {
                crate::check::types::Ty::TyAt(_, _) => s2_p11.clone(),
                crate::check::types::Ty::TyErr => s2_p11.clone(),
                other_p12 => crate::check::types::recording::err_f(&s2_p11, &crate::prelude::Text::lit("mismatch"), &t_pv.blueprint_p.span_p, &crate::prelude::Text::from(format!("a test builds a blueprint; this is `{}`", &crate::check::types::show_ty_f(&s2_p11, &other_p12)))),
            }
        },
    };
    let first_p8 = crate::check::env::traits::solve_wants_f(g_p0, &s1_p7, &env_p3.givens_p, &false);
    let solved_p9 = crate::check::types::colors::check_colors_f(&(if &crate::prelude::len(&first_p8.packs_p) == &crate::prelude::Nat::from(0u32) {
        first_p8.clone()
    } else {
        crate::check::env::traits::solve_wants_f(g_p0, &crate::check::env::traits::resolve_packs_f(&first_p8, &true), &env_p3.givens_p, &false)
    }));
    let defaulted_pa = crate::check::types::unify::layer_questions_f(&crate::check::env::traits::resolve_fields_f(g_p0, &default_def_f(g_p0, &solved_p9), &true));
    let discharged_pb = crate::check::passes::discharge_incls_f(g_p0, &defaulted_pa, &incls_before_p4);
    let mut this: crate::check::types::St = discharged_pb.clone();
    this.level_p = crate::prelude::Nat::from(0u32);
    this
}

/// The step machine of `CheckDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckDef: unbounded fn G, St, Def -> St
/// ```
pub struct CheckDef {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub d_p2: crate::check::env::Def,
}

impl ::prism_rtl::Job<crate::check::types::St> for CheckDef {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let d_p2 = &self.d_p2;
        let env_p3 = def_env_f(g_p0, d_p2);
        let incls_before_p4 = crate::prelude::len(&st_p1.incls_p);
        let own_p5 = crate::check::shrink::types::own_key_f(d_p2).qk_p.clone();
        let s0_p6 = {
            let mut this: crate::check::types::St = st_p1.clone();
            this.file_p = d_p2.file_p.clone();
            this.definition_p = own_p5.clone();
            this.level_p = crate::prelude::Nat::from(1u32);
            this.local_next_p = crate::prelude::Nat::from(0u32);
            this.color_p = crate::check::types::Col::CBound;
            this.color_why_p = crate::prelude::Text::lit("");
            this.color_flex_p = crate::prelude::Array::new();
            this.cleqs_p = crate::prelude::Array::new();
            this
        };
        let env_p3z = env_p3.clone();
        let g_p0z = g_p0.clone();
        let incls_before_p4z = incls_before_p4.clone();
        let k_let20576 = move |v20576: crate::check::types::St| {
            let s1_p7 = v20576;
            crate::prelude::call_then(crate::check::env::traits::start_solve_wants_f(g_p0z.clone(), s1_p7.clone(), env_p3z.givens_p.clone(), false), move |solve_wants_f_21915: crate::check::types::St| {
                let first_p8 = solve_wants_f_21915;
                crate::prelude::call_then(crate::check::types::colors::start_check_colors_f(if &crate::prelude::len(&first_p8.packs_p) == &crate::prelude::Nat::from(0u32) {
                    first_p8.clone()
                } else {
                    crate::check::env::traits::solve_wants_f(&g_p0z, &crate::check::env::traits::resolve_packs_f(&first_p8, &true), &env_p3z.givens_p, &false)
                }), move |check_colors_f_22059: crate::check::types::St| {
                    let solved_p9 = check_colors_f_22059;
                    crate::prelude::call_then(start_default_def_f(g_p0z.clone(), solved_p9.clone()), move |default_def_f_22226: crate::check::types::St| crate::prelude::call_then(crate::check::env::traits::start_resolve_fields_f(g_p0z.clone(), default_def_f_22226, true), move |resolve_fields_f_22208: crate::check::types::St| crate::prelude::call_then(crate::check::types::unify::start_layer_questions_f(resolve_fields_f_22208), move |layer_questions_f_22192: crate::check::types::St| {
                        let defaulted_pa = layer_questions_f_22192;
                        crate::prelude::call_then(crate::check::passes::start_discharge_incls_f(g_p0z.clone(), defaulted_pa.clone(), incls_before_p4z.clone()), move |discharge_incls_f_22276: crate::check::types::St| {
                            let discharged_pb = discharge_incls_f_22276;
                            ::prism_rtl::Turn::Finished({
                                let mut this: crate::check::types::St = discharged_pb.clone();
                                this.level_p = crate::prelude::Nat::from(0u32);
                                this
                            })
                        })
                    })))
                })
            })
        };
        match d_p2.body_p.clone() {
            crate::check::env::DefBody::DbFn(clauses_pc) => match crate::prelude::get(&g_p0.vals_p, &d_p2.qk_p) {
                ::std::option::Option::Some(v_pd) => if crate::check::env::decls::is_lens_text_f(&d_p2.name_p) {
                    {
                        let d_p2x = d_p2.clone();
                        crate::prelude::call_then(crate::check::blocks::borrows::start_check_lens_f(env_p3.clone(), s0_p6.clone(), d_p2x.name_p.clone(), clauses_pc.clone(), v_pd.scheme_p.clone(), d_p2x.span_p.clone()), move |check_lens_f_20680: crate::check::types::St| k_let20576(check_lens_f_20680))
                    }
                } else {
                    {
                        let d_p2x = d_p2.clone();
                        crate::prelude::call_then(crate::check::expr::lets::start_check_clauses_f(env_p3.clone(), s0_p6.clone(), d_p2x.name_p.clone(), clauses_pc.clone(), v_pd.scheme_p.clone(), d_p2x.span_p.clone()), move |check_clauses_f_20739: crate::check::types::St| k_let20576(check_clauses_f_20739))
                    }
                },
                ::std::option::Option::None => k_let20576(s0_p6.clone()),
            },
            crate::check::env::DefBody::DbWidget(w_pe) => {
                let d_p2x = d_p2.clone();
                crate::prelude::call_then(start_check_widget_def_f(env_p3.clone(), s0_p6.clone(), d_p2x.clone(), w_pe.clone()), move |check_widget_def_f_20835: crate::check::types::St| k_let20576(check_widget_def_f_20835))
            },
            crate::check::env::DefBody::DbLet(l_pf) => match crate::prelude::get(&g_p0.vals_p, &d_p2.qk_p) {
                ::std::option::Option::Some(v_pg) => if v_pg.has_sig_p {
                    crate::prelude::call_then(crate::check::types::schemes::start_skolemize_f(v_pg.scheme_p.clone()), move |skolemize_f_20972: crate::check::types::Ty| crate::prelude::call_then(crate::check::expr::start_check_f(env_p3.clone(), s0_p6.clone(), l_pf.value_p.clone(), skolemize_f_20972), move |check_f_20947: crate::check::types::St| k_let20576(check_f_20947)))
                } else {
                    k_let20576(s0_p6.clone())
                },
                ::std::option::Option::None => k_let20576(s0_p6.clone()),
            },
            crate::check::env::DefBody::DbMethod(clauses_ph, cls_pi, im_pj) => {
                let d_p2x = d_p2.clone();
                crate::prelude::call_then(start_check_method_f(env_p3.clone(), s0_p6.clone(), d_p2x.clone(), clauses_ph.clone(), cls_pi.clone(), im_pj.clone()), move |check_method_f_21072: crate::check::types::St| k_let20576(check_method_f_21072))
            },
            crate::check::env::DefBody::DbDefault(clauses_pk, cls_pl) => match method_key_o(g_p0, &cls_pl, &d_p2.name_p) {
                ::std::option::Option::Some(mk_pm) => match crate::prelude::get(&g_p0.vals_p, &mk_pm) {
                    ::std::option::Option::Some(v_pn) => {
                        let d_p2x = d_p2.clone();
                        crate::prelude::call_then(crate::check::expr::lets::start_check_clauses_f(env_p3.clone(), s0_p6.clone(), d_p2x.name_p.clone(), clauses_pk.clone(), v_pn.scheme_p.clone(), d_p2x.span_p.clone()), move |check_clauses_f_21235: crate::check::types::St| k_let20576(check_clauses_f_21235))
                    },
                    ::std::option::Option::None => k_let20576(s0_p6.clone()),
                },
                ::std::option::Option::None => k_let20576(s0_p6.clone()),
            },
            crate::check::env::DefBody::DbCheck(c_po) => crate::prelude::call_value(crate::prelude::fold_job(c_po.lines_p.clone(), s0_p6.clone(), {
                let env_p3x = env_p3.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::CheckLine)| {
                    let env_p3xy = env_p3x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let s_pp = p0;
                        let line_pq = p1;
                        crate::prelude::call_then(crate::check::expr::start_infer_f(env_p3xy.clone(), s_pp.clone(), line_pq.expr_p.clone()), move |infer_f_21411: (crate::check::types::Ty, crate::check::types::St)| {
                            let (t_pr, s2_ps) = infer_f_21411;
                            match &line_pq.pattern_o {
                                ::std::option::Option::Some(p_pt) => {
                                    let p_ptx = p_pt.clone();
                                    crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(env_p3xy.clone(), s2_ps.clone(), p_ptx.clone(), t_pr.clone(), true), move |bind_pattern_f_21530: (crate::check::expr::Env, crate::check::types::St)| {
                                        let (_, s3_pu) = bind_pattern_f_21530;
                                        ::prism_rtl::Turn::Finished(s3_pu.clone())
                                    })
                                },
                                ::std::option::Option::None => ::prism_rtl::Turn::Finished(s2_ps.clone()),
                            }
                        })
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::syntax::decls::CheckLine)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
            }), move |fold_21354: crate::check::types::St| k_let20576(fold_21354)),
            crate::check::env::DefBody::DbTest(t_pv) => crate::prelude::call_then(crate::check::expr::start_infer_f(env_p3.clone(), s0_p6.clone(), t_pv.blueprint_p.clone()), move |infer_f_21656: (crate::check::types::Ty, crate::check::types::St)| {
                let (bt_p10, s2_p11) = infer_f_21656;
                crate::prelude::call_then(crate::check::types::recording::start_walk_f(s2_p11.clone(), bt_p10.clone()), move |walk_f_21701: crate::check::types::Ty| match walk_f_21701 {
                    crate::check::types::Ty::TyAt(_, _) => k_let20576(s2_p11.clone()),
                    crate::check::types::Ty::TyErr => k_let20576(s2_p11.clone()),
                    other_p12 => crate::prelude::call_then(crate::check::types::start_show_ty_f(s2_p11.clone(), other_p12.clone()), move |show_ty_f_21879: crate::prelude::Text| k_let20576(crate::check::types::recording::err_f(&s2_p11, &crate::prelude::Text::lit("mismatch"), &t_pv.blueprint_p.span_p, &crate::prelude::Text::from(format!("a test builds a blueprint; this is `{}`", &show_ty_f_21879))))),
                })
            }),
        }
    }
}

/// `Start CheckDef, x`: what the function value is when passed to `@Run`.
pub fn start_check_def_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, d_p2: crate::check::env::Def) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(CheckDef { g_p0, st_p1, d_p2 })
}

/// ```prism
/// DefaultDef: unbounded fn G, St -> St
/// ```
pub fn default_def_f(g_p0: &crate::check::env::G, st0_p1: &crate::check::types::St) -> crate::check::types::St {
    let st_p2 = crate::check::types::recording::faults_defaulted_f(st0_p1, &false);
    let mine_p3 = crate::prelude::run_to_end(crate::prelude::filter_job(st_p2.wants_p.clone(), {
        let st_p2x = st_p2.clone();
        ::std::rc::Rc::new(move |p0: crate::check::types::Want| {
            let st_p2xy = st_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let w_p7 = p0;
                crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p2xy.clone(), w_p7.ty_p.clone()), move |walk_f_22703: crate::check::types::Ty| match walk_f_22703 {
                    crate::check::types::Ty::TyFlex(n_p8) => ::prism_rtl::Turn::Finished(&crate::check::types::recording::info_of_f(&st_p2xy, &n_p8).level_p >= &crate::prelude::Nat::from(1u32)),
                    _ => ::prism_rtl::Turn::Finished(true),
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Want) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }));
    let theirs_p4 = crate::prelude::run_to_end(crate::prelude::filter_job(st_p2.wants_p.clone(), {
        let st_p2x = st_p2.clone();
        ::std::rc::Rc::new(move |p0: crate::check::types::Want| {
            let st_p2xy = st_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let w_p9 = p0;
                crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p2xy.clone(), w_p9.ty_p.clone()), move |walk_f_22831: crate::check::types::Ty| match walk_f_22831 {
                    crate::check::types::Ty::TyFlex(n_pa) => ::prism_rtl::Turn::Finished(&crate::check::types::recording::info_of_f(&st_p2xy, &n_pa).level_p < &crate::prelude::Nat::from(1u32)),
                    _ => ::prism_rtl::Turn::Finished(false),
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Want) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }));
    let st1_p5 = {
        let mut this: crate::check::types::St = st_p2.clone();
        this.wants_p = mine_p3.clone();
        this
    };
    let s2_p6 = crate::check::env::traits::default_wants_f(g_p0, &st1_p5, &crate::prelude::Array::new());
    let mut this: crate::check::types::St = s2_p6.clone();
    this.wants_p = crate::prelude::append(&theirs_p4, &this.wants_p);
    this
}

/// The step machine of `DefaultDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefaultDef: unbounded fn G, St -> St
/// ```
pub struct DefaultDef {
    pub g_p0: crate::check::env::G,
    pub st0_p1: crate::check::types::St,
}

impl ::prism_rtl::Job<crate::check::types::St> for DefaultDef {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st0_p1 = &self.st0_p1;
        let g_p0x = g_p0.clone();
        let st0_p1x = st0_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_faults_defaulted_f(st0_p1x.clone(), false), move |faults_defaulted_f_22633: crate::check::types::St| {
            let st_p2 = faults_defaulted_f_22633;
            crate::prelude::call_value(crate::prelude::filter_job(st_p2.wants_p.clone(), {
                let st_p2x = st_p2.clone();
                ::std::rc::Rc::new(move |p0: crate::check::types::Want| {
                    let st_p2xy = st_p2x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let w_p7 = p0;
                        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p2xy.clone(), w_p7.ty_p.clone()), move |walk_f_22703: crate::check::types::Ty| match walk_f_22703 {
                            crate::check::types::Ty::TyFlex(n_p8) => ::prism_rtl::Turn::Finished(&crate::check::types::recording::info_of_f(&st_p2xy, &n_p8).level_p >= &crate::prelude::Nat::from(1u32)),
                            _ => ::prism_rtl::Turn::Finished(true),
                        })
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Want) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }), move |filter_22675: crate::prelude::Array<crate::check::types::Want>| {
                let mine_p3 = filter_22675;
                crate::prelude::call_value(crate::prelude::filter_job(st_p2.wants_p.clone(), {
                    let st_p2x = st_p2.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::types::Want| {
                        let st_p2xy = st_p2x.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let w_p9 = p0;
                            crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p2xy.clone(), w_p9.ty_p.clone()), move |walk_f_22831: crate::check::types::Ty| match walk_f_22831 {
                                crate::check::types::Ty::TyFlex(n_pa) => ::prism_rtl::Turn::Finished(&crate::check::types::recording::info_of_f(&st_p2xy, &n_pa).level_p < &crate::prelude::Nat::from(1u32)),
                                _ => ::prism_rtl::Turn::Finished(false),
                            })
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Want) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
                }), move |filter_22803: crate::prelude::Array<crate::check::types::Want>| {
                    let theirs_p4 = filter_22803;
                    let st1_p5 = {
                        let mut this: crate::check::types::St = st_p2.clone();
                        this.wants_p = mine_p3.clone();
                        this
                    };
                    crate::prelude::call_then(crate::check::env::traits::start_default_wants_f(g_p0x.clone(), st1_p5.clone(), crate::prelude::Array::new()), move |default_wants_f_22977: crate::check::types::St| {
                        let s2_p6 = default_wants_f_22977;
                        ::prism_rtl::Turn::Finished({
                            let mut this: crate::check::types::St = s2_p6.clone();
                            this.wants_p = crate::prelude::append(&theirs_p4, &this.wants_p);
                            this
                        })
                    })
                })
            })
        })
    }
}

/// `Start DefaultDef, x`: what the function value is when passed to `@Run`.
pub fn start_default_def_f(g_p0: crate::check::env::G, st0_p1: crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(DefaultDef { g_p0, st0_p1 })
}

/// ```prism
/// CheckWidgetDef: unbounded fn Env, St, Def, WidgetDecl -> St
/// ```
pub fn check_widget_def_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, d_p2: &crate::check::env::Def, w_p3: &crate::syntax::decls::WidgetDecl) -> crate::check::types::St {
    match crate::prelude::get(&env_p0.g_p.vals_p, &d_p2.qk_p) {
        ::std::option::Option::Some(v_p4) => match crate::check::types::schemes::skolemize_f(&v_p4.scheme_p) {
            crate::check::types::Ty::TyAt(inner_p5, rw_p6) => {
                let env2_p7 = {
                    let mut this: crate::check::expr::Env = env_p0.clone();
                    this.scope_p = rw_p6;
                    this.mark_p = crate::prelude::Text::lit("@");
                    this
                };
                let (t_p8, st2_p9) = crate::check::blocks::infer_widget_block_f(&env2_p7, st_p1, &w_p3.body_p);
                crate::check::types::recording::note_fn_f(&crate::check::types::unify::unify_f(&st2_p9, &*inner_p5, &t_p8, &crate::check::types::recording::result_span_f(&w_p3.body_p)), &w_p3.span_p, &d_p2.name_p, &crate::check::types::Col::CBound, &st2_p9.color_p)
            },
            other_pa => crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), &w_p3.span_p, &crate::prelude::Text::from(format!("`{}` is declared `{}`; a widget block builds a blueprint", &d_p2.name_p, &crate::check::types::show_ty_f(st_p1, &other_pa)))),
        },
        ::std::option::Option::None => {
            let (t_pb, st2_pc) = crate::check::blocks::infer_widget_block_f(env_p0, st_p1, &w_p3.body_p);
            crate::check::types::recording::note_fn_f(&st2_pc, &w_p3.span_p, &d_p2.name_p, &crate::check::types::Col::CBound, &st2_pc.color_p)
        },
    }
}

/// The step machine of `CheckWidgetDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckWidgetDef: unbounded fn Env, St, Def, WidgetDecl -> St
/// ```
pub struct CheckWidgetDef {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub d_p2: crate::check::env::Def,
    pub w_p3: crate::syntax::decls::WidgetDecl,
}

impl ::prism_rtl::Job<crate::check::types::St> for CheckWidgetDef {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let d_p2 = &self.d_p2;
        let w_p3 = &self.w_p3;
        match crate::prelude::get(&env_p0.g_p.vals_p, &d_p2.qk_p) {
            ::std::option::Option::Some(v_p4) => {
                let d_p2x = d_p2.clone();
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                let w_p3x = w_p3.clone();
                crate::prelude::call_then(crate::check::types::schemes::start_skolemize_f(v_p4.scheme_p.clone()), move |skolemize_f_23283: crate::check::types::Ty| match skolemize_f_23283 {
                    crate::check::types::Ty::TyAt(inner_p5, rw_p6) => {
                        let env2_p7 = {
                            let mut this: crate::check::expr::Env = env_p0x.clone();
                            this.scope_p = rw_p6.clone();
                            this.mark_p = crate::prelude::Text::lit("@");
                            this
                        };
                        crate::prelude::call_then(crate::check::blocks::start_infer_widget_block_f(env2_p7.clone(), st_p1x.clone(), w_p3x.body_p.clone()), move |infer_widget_block_f_23453: (crate::check::types::Ty, crate::check::types::St)| {
                            let (t_p8, st2_p9) = infer_widget_block_f_23453;
                            crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_p9.clone(), (*inner_p5).clone(), t_p8.clone(), crate::check::types::recording::result_span_f(&w_p3x.body_p)), move |unify_f_23507: crate::check::types::St| ::prism_rtl::Turn::Finished(crate::check::types::recording::note_fn_f(&unify_f_23507, &w_p3x.span_p, &d_p2x.name_p, &crate::check::types::Col::CBound, &st2_p9.color_p)))
                        })
                    },
                    other_pa => crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), other_pa.clone()), move |show_ty_f_23653: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&st_p1x, &crate::prelude::Text::lit("mismatch"), &w_p3x.span_p, &crate::prelude::Text::from(format!("`{}` is declared `{}`; a widget block builds a blueprint", &d_p2x.name_p, &show_ty_f_23653))))),
                })
            },
            ::std::option::Option::None => {
                let d_p2x = d_p2.clone();
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                let w_p3x = w_p3.clone();
                crate::prelude::call_then(crate::check::blocks::start_infer_widget_block_f(env_p0x.clone(), st_p1x.clone(), w_p3x.body_p.clone()), move |infer_widget_block_f_23742: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_pb, st2_pc) = infer_widget_block_f_23742;
                    ::prism_rtl::Turn::Finished(crate::check::types::recording::note_fn_f(&st2_pc, &w_p3x.span_p, &d_p2x.name_p, &crate::check::types::Col::CBound, &st2_pc.color_p))
                })
            },
        }
    }
}

/// `Start CheckWidgetDef, x`: what the function value is when passed to `@Run`.
pub fn start_check_widget_def_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, d_p2: crate::check::env::Def, w_p3: crate::syntax::decls::WidgetDecl) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(CheckWidgetDef { env_p0, st_p1, d_p2, w_p3 })
}

/// ```prism
/// ?MethodKey: fn G, Text, Text -> ?Text
/// ```
pub fn method_key_o(g_p0: &crate::check::env::G, cls_p1: &crate::prelude::Text, name_p2: &crate::prelude::Text) -> ::std::option::Option<crate::prelude::Text> {
    crate::prelude::fold(&crate::prelude::or(&crate::prelude::get(&g_p0.traits_p, cls_p1), &crate::check::env::traits::dummy_trait_p()).methods_p, &::std::option::Option::None, &(|found_o3: &::std::option::Option<crate::prelude::Text>, k_p4: &crate::prelude::Text| match found_o3 {
        ::std::option::Option::Some(f_p5) => ::std::option::Option::Some(f_p5.clone()),
        ::std::option::Option::None => if (&crate::check::types::bare_name_f(k_p4) == name_p2) || (&crate::syntax::lexer::chars::drop_prefix_f(k_p4, &crate::prelude::Text::from(format!("{}.", &crate::prelude::or(&crate::prelude::get(&g_p0.traits_p, cls_p1), &crate::check::env::traits::dummy_trait_p()).home_p))) == name_p2) {
            ::std::option::Option::Some(k_p4.clone())
        } else {
            ::std::option::Option::None
        },
    }))
}

/// ```prism
/// CheckMethod: unbounded fn Env, St, Def, [FnClause], Text, ImplInfo -> St
/// ```
pub fn check_method_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, d_p2: &crate::check::env::Def, clauses_p3: &crate::prelude::Array<crate::syntax::decls::FnClause>, cls_p4: &crate::prelude::Text, im_p5: &crate::check::env::ImplInfo) -> crate::check::types::St {
    match method_key_o(&env_p0.g_p, cls_p4, &d_p2.name_p) {
        ::std::option::Option::None => crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), &d_p2.span_p, &crate::prelude::Text::from(format!("`^{}` has no method `{}`", &crate::check::types::bare_name_f(cls_p4), &d_p2.name_p))),
        ::std::option::Option::Some(mk_p6) => match crate::prelude::get(&env_p0.g_p.vals_p, &mk_p6) {
            ::std::option::Option::None => st_p1.clone(),
            ::std::option::Option::Some(v_p7) => {
                let ti_p8 = crate::prelude::or(&crate::prelude::get(&env_p0.g_p.traits_p, cls_p4), &crate::check::env::traits::dummy_trait_p());
                let head_p9 = crate::check::types::schemes::subst_q_f(&crate::check::types::schemes::Inst { tys_p: crate::prelude::fold(&im_p5.qs_p, &crate::prelude::Map::new(), &(|m_pd: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, q_pe: &crate::prelude::Text| crate::prelude::insert(m_pd, q_pe, &crate::check::types::Ty::TyRigid(q_pe.clone())))), rows_p: crate::prelude::Map::new(), cols_p: crate::prelude::Map::new() }, &im_p5.head_p);
                let own_pa = crate::check::types::schemes::scheme_apart_f(&crate::check::types::Scheme { qs_p: crate::prelude::filter(&v_p7.scheme_p.qs_p, &(|q_pf: &crate::prelude::Text| q_pf != &ti_p8.param_p)), plain_qs_p: crate::prelude::Array::new(), rqs_p: v_p7.scheme_p.rqs_p.clone(), cqs_p: v_p7.scheme_p.cqs_p.clone(), cjoins_p: v_p7.scheme_p.cjoins_p.clone(), bounds_p: crate::prelude::filter(&v_p7.scheme_p.bounds_p, &(|(q_pg, _): &(crate::prelude::Text, crate::prelude::Text)| q_pg != &ti_p8.param_p)), eqs_p: crate::prelude::Array::new(), ty_p: v_p7.scheme_p.ty_p.clone() }, &im_p5.qs_p);
                let sc_pb = {
                    let mut this: crate::check::types::Scheme = own_pa.clone();
                    this.ty_p = crate::check::types::schemes::subst_q_f(&crate::check::types::schemes::Inst { tys_p: crate::prelude::map_of(vec![(ti_p8.param_p.clone(), head_p9.clone())]), rows_p: crate::prelude::Map::new(), cols_p: crate::prelude::Map::new() }, &this.ty_p);
                    this
                };
                let env2_pc = {
                    let mut this: crate::check::expr::Env = env_p0.clone();
                    this.givens_p = im_p5.bounds_p.clone();
                    this
                };
                crate::check::expr::lets::check_clauses_f(&env2_pc, st_p1, &d_p2.name_p, clauses_p3, &sc_pb, &d_p2.span_p)
            },
        },
    }
}

/// The step machine of `CheckMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckMethod: unbounded fn Env, St, Def, [FnClause], Text, ImplInfo -> St
/// ```
pub struct CheckMethod {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub d_p2: crate::check::env::Def,
    pub clauses_p3: crate::prelude::Array<crate::syntax::decls::FnClause>,
    pub cls_p4: crate::prelude::Text,
    pub im_p5: crate::check::env::ImplInfo,
}

impl ::prism_rtl::Job<crate::check::types::St> for CheckMethod {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let d_p2 = &self.d_p2;
        let clauses_p3 = &self.clauses_p3;
        let cls_p4 = &self.cls_p4;
        let im_p5 = &self.im_p5;
        match method_key_o(&env_p0.g_p, cls_p4, &d_p2.name_p) {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(crate::check::types::recording::err_f(st_p1, &crate::prelude::Text::lit("mismatch"), &d_p2.span_p, &crate::prelude::Text::from(format!("`^{}` has no method `{}`", &crate::check::types::bare_name_f(cls_p4), &d_p2.name_p)))),
            ::std::option::Option::Some(mk_p6) => match crate::prelude::get(&env_p0.g_p.vals_p, &mk_p6) {
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(st_p1.clone()),
                ::std::option::Option::Some(v_p7) => {
                    let ti_p8 = crate::prelude::or(&crate::prelude::get(&env_p0.g_p.traits_p, cls_p4), &crate::check::env::traits::dummy_trait_p());
                    let clauses_p3x = clauses_p3.clone();
                    let d_p2x = d_p2.clone();
                    let env_p0x = env_p0.clone();
                    let im_p5x = im_p5.clone();
                    let st_p1x = st_p1.clone();
                    crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(crate::check::types::schemes::Inst { tys_p: crate::prelude::fold(&im_p5x.qs_p, &crate::prelude::Map::new(), &(|m_pd: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, q_pe: &crate::prelude::Text| crate::prelude::insert(m_pd, q_pe, &crate::check::types::Ty::TyRigid(q_pe.clone())))), rows_p: crate::prelude::Map::new(), cols_p: crate::prelude::Map::new() }, im_p5x.head_p.clone()), move |subst_q_f_24613: crate::check::types::Ty| {
                        let head_p9 = subst_q_f_24613;
                        crate::prelude::call_then(crate::check::types::schemes::start_scheme_apart_f(crate::check::types::Scheme { qs_p: crate::prelude::filter(&v_p7.scheme_p.qs_p, &(|q_pf: &crate::prelude::Text| q_pf != &ti_p8.param_p)), plain_qs_p: crate::prelude::Array::new(), rqs_p: v_p7.scheme_p.rqs_p.clone(), cqs_p: v_p7.scheme_p.cqs_p.clone(), cjoins_p: v_p7.scheme_p.cjoins_p.clone(), bounds_p: crate::prelude::filter(&v_p7.scheme_p.bounds_p, &(|(q_pg, _): &(crate::prelude::Text, crate::prelude::Text)| q_pg != &ti_p8.param_p)), eqs_p: crate::prelude::Array::new(), ty_p: v_p7.scheme_p.ty_p.clone() }, im_p5x.qs_p.clone()), move |scheme_apart_f_24827: crate::check::types::Scheme| {
                            let own_pa = scheme_apart_f_24827;
                            let sc_pb = {
                                let mut this: crate::check::types::Scheme = own_pa.clone();
                                this.ty_p = crate::check::types::schemes::subst_q_f(&crate::check::types::schemes::Inst { tys_p: crate::prelude::map_of(vec![(ti_p8.param_p.clone(), head_p9.clone())]), rows_p: crate::prelude::Map::new(), cols_p: crate::prelude::Map::new() }, &this.ty_p);
                                this
                            };
                            let env2_pc = {
                                let mut this: crate::check::expr::Env = env_p0x.clone();
                                this.givens_p = im_p5x.bounds_p.clone();
                                this
                            };
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::expr::lets::CheckClauses { env_p0: env2_pc.clone(), st_p1: st_p1x.clone(), name_p2: d_p2x.name_p.clone(), clauses_p3: clauses_p3x.clone(), sc_p4: sc_pb.clone(), span_p5: d_p2x.span_p.clone() }))
                        })
                    })
                },
            },
        }
    }
}

/// `Start CheckMethod, x`: what the function value is when passed to `@Run`.
pub fn start_check_method_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, d_p2: crate::check::env::Def, clauses_p3: crate::prelude::Array<crate::syntax::decls::FnClause>, cls_p4: crate::prelude::Text, im_p5: crate::check::env::ImplInfo) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(CheckMethod { env_p0, st_p1, d_p2, clauses_p3, cls_p4, im_p5 })
}

/// ```prism
/// RootRow: unbounded fn G, St, [Text] -> ((Text, St))
/// ```
pub fn root_row_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, world_p2: &crate::prelude::Array<crate::prelude::Text>) -> (crate::prelude::Text, crate::check::types::St) {
    match crate::prelude::get(&g_p0.mods_p, &crate::prelude::Text::lit("")) {
        ::std::option::Option::None => (crate::prelude::Text::lit(""), st_p1.clone()),
        ::std::option::Option::Some(info_p3) => {
            let shown_p4 = crate::check::types::show_row_f(&info_p3.emit_rw_p);
            if &crate::prelude::len(world_p2) == &crate::prelude::Nat::from(0u32) {
                (shown_p4.clone(), st_p1.clone())
            } else {
                {
                    let missing_p5 = crate::prelude::filter(&info_p3.emit_rw_p.fams_p, &(|f_p6: &crate::prelude::Text| !crate::check::types::has_text_f(world_p2, f_p6)));
                    if &crate::prelude::len(&missing_p5) == &crate::prelude::Nat::from(0u32) {
                        (shown_p4.clone(), st_p1.clone())
                    } else {
                        {
                            let s0_p7 = {
                                let mut this: crate::check::types::St = st_p1.clone();
                                this.file_p = info_p3.file_p.clone();
                                this
                            };
                            (shown_p4.clone(), crate::check::types::recording::err_fix_f(&s0_p7, &crate::prelude::Text::lit("world-row"), &info_p3.tree_p.span_p, &crate::prelude::Text::from(format!("the program emits {}, which this World does not answer", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&missing_p5, &(|f_p8: &crate::prelude::Text| crate::prelude::Text::from(format!("`{}.*`", f_p8)))), &crate::prelude::Text::lit(", ")))), &crate::prelude::Text::lit("host the tags it cannot answer, or run under a World that answers them")))
                        }
                    }
                }
            }
        },
    }
}

/// The step machine of `RootRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RootRow: unbounded fn G, St, [Text] -> ((Text, St))
/// ```
pub struct RootRow {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub world_p2: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::St)> for RootRow {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Text, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let world_p2 = &self.world_p2;
        match crate::prelude::get(&g_p0.mods_p, &crate::prelude::Text::lit("")) {
            ::std::option::Option::None => ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), st_p1.clone())),
            ::std::option::Option::Some(info_p3) => {
                let shown_p4 = crate::check::types::show_row_f(&info_p3.emit_rw_p);
                if &crate::prelude::len(world_p2) == &crate::prelude::Nat::from(0u32) {
                    ::prism_rtl::Turn::Finished((shown_p4.clone(), st_p1.clone()))
                } else {
                    {
                        let missing_p5 = crate::prelude::filter(&info_p3.emit_rw_p.fams_p, &(|f_p6: &crate::prelude::Text| !crate::check::types::has_text_f(world_p2, f_p6)));
                        if &crate::prelude::len(&missing_p5) == &crate::prelude::Nat::from(0u32) {
                            ::prism_rtl::Turn::Finished((shown_p4.clone(), st_p1.clone()))
                        } else {
                            {
                                let s0_p7 = {
                                    let mut this: crate::check::types::St = st_p1.clone();
                                    this.file_p = info_p3.file_p.clone();
                                    this
                                };
                                ::prism_rtl::Turn::Finished((shown_p4.clone(), crate::check::types::recording::err_fix_f(&s0_p7, &crate::prelude::Text::lit("world-row"), &info_p3.tree_p.span_p, &crate::prelude::Text::from(format!("the program emits {}, which this World does not answer", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&missing_p5, &(|f_p8: &crate::prelude::Text| crate::prelude::Text::from(format!("`{}.*`", f_p8)))), &crate::prelude::Text::lit(", ")))), &crate::prelude::Text::lit("host the tags it cannot answer, or run under a World that answers them"))))
                            }
                        }
                    }
                }
            },
        }
    }
}

/// `Start RootRow, x`: what the function value is when passed to `@Run`.
pub fn start_root_row_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, world_p2: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::St)>> {
    ::std::rc::Rc::new(RootRow { g_p0, st_p1, world_p2 })
}
