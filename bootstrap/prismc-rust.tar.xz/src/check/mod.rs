//! The module `Check`, from `target/bootstrap/src/prismc/check/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod blocks;
pub mod env;
pub mod errors;
pub mod expr;
pub mod passes;
pub mod shrink;
pub mod typed;
pub mod types;

/// `Report`:
///
/// ```prism
/// type Report = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Report_ {
    pub text: Text,
    pub errors: Nat,
    pub root_row: Text,
    pub typed: crate::check::typed::TProgram,
}

impl Show for Report_ {
    fn show(&self, p: &mut Printer) {
        p.record("Report", &[("text", &self.text), ("errors", &self.errors), ("root_row", &self.root_row), ("typed", &self.typed)]);
    }
}

impl ToPod for Report_ {
    fn to_pod(&self) -> Pod {
        Pod::record("Report", vec![("text", self.text.to_pod()), ("errors", self.errors.to_pod()), ("root_row", self.root_row.to_pod()), ("typed", self.typed.to_pod())])
    }
}

impl FromPod for Report_ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Report_ { text: FromPod::from_pod(field(p, "text")?)?, errors: FromPod::from_pod(field(p, "errors")?)?, root_row: FromPod::from_pod(field(p, "root_row")?)?, typed: FromPod::from_pod(field(p, "typed")?)? })
    }
}

/// ```prism
/// CheckProgram: unbounded fn [Src], [Module], [Text], Nat, Bool, Bool, [CDiag] -> Report
/// ```
pub fn check_program(srcs: &Array<crate::check::errors::Src>, trees: &Array<crate::syntax::Module>, world: &Array<Text>, shown: &Nat, recording: &bool, unused: &bool, pre: &Array<crate::check::errors::CDiag>) -> Report_ {
    let (g0a, stb) = crate::check::env::build_g(srcs, trees);
    let g0 = {
        let mut this: crate::check::env::G = g0a.clone();
        this.prelude_from = shown.clone();
        this
    };
    let st0 = {
        let mut this: crate::check::types::St = stb.clone();
        this.recording = *recording;
        this
    };
    let (g1, st1) = top_lets(&g0, &st0);
    let (failed, st2) = run_to_end(fold_job(g1.defs.clone(), (Array::new(), st1.clone()), {
        let g1 = g1.clone();
        Rc::new(move |(p0, p1): ((Array<Text>, crate::check::types::St), crate::check::env::Def)| {
            let g1 = g1.clone();
            entered(once_job(move || {
                let (bad, s) = p0;
                let d = p1;
                {
                    let before_ = len(&s.diags);
                    call_then(start_check_def(g1.clone(), s.clone(), d.clone()), move |check_def_2619: crate::check::types::St| {
                        let s2 = check_def_2619;
                        let bad2 = if &len(&s2.diags) > &before_ {
                            push(&bad, &crate::check::shrink::types::own_key(&d).qk)
                        } else {
                            bad.clone()
                        };
                        prism_rtl::Turn::Finished((bad2.clone(), s2.clone()))
                    })
                }
            }))
        }) as Rc<dyn Fn(((Array<Text>, crate::check::types::St), crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<(Array<Text>, crate::check::types::St)>>>
    }));
    let st2b = {
        let mut this: crate::check::types::St = st2.clone();
        this.level = Nat::from(0u32);
        this
    };
    let st3 = crate::check::env::traits::default_wants(&g1, &st2b, &Array::new());
    let good = filter(&g1.defs, &(|d: &crate::check::env::Def| !crate::check::types::has_text(&failed, &crate::check::shrink::types::own_key(d).qk)));
    let (st4, refs) = crate::check::shrink::shrink_check(&g1, &st3, &good);
    let (root_row_, st5) = root_row(&g1, &st4, world);
    let warnings = if *unused {
        crate::check::shrink::unused_defs(&good, &refs, shown)
    } else {
        Array::new()
    };
    let reached = crate::check::shrink::test_only_reached(srcs, &g1.defs, &refs);
    let diags = crate::check::errors::sort_diags(&append(&append(&append(&filter(&st5.diags, &(|d: &crate::check::errors::CDiag| &d.file < shown)), &warnings), pre), &reached));
    let text_ = concat(&each(&diags, &(|d: &crate::check::errors::CDiag| crate::check::errors::render_cdiag(srcs, d))));
    let typed = if *recording {
        typed_of(&g1, &st5, shown)
    } else {
        crate::check::typed::empty_typed()
    };
    Report_ { text: text_.clone(), errors: len(&filter(&diags, &(|d: &crate::check::errors::CDiag| !crate::check::errors::is_warning(d)))), root_row: root_row_.clone(), typed: typed.clone() }
}

/// The step machine of `CheckProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckProgram: unbounded fn [Src], [Module], [Text], Nat, Bool, Bool, [CDiag] -> Report
/// ```
pub struct CheckProgram {
    pub srcs: Array<crate::check::errors::Src>,
    pub trees: Array<crate::syntax::Module>,
    pub world: Array<Text>,
    pub shown: Nat,
    pub recording: bool,
    pub unused: bool,
    pub pre: Array<crate::check::errors::CDiag>,
}

impl prism_rtl::Job<Report_> for CheckProgram {
    fn cycle(&self) -> prism_rtl::Turn<Report_> {
        let srcs = &self.srcs;
        let trees = &self.trees;
        let world = &self.world;
        let shown = &self.shown;
        let recording = &self.recording;
        let unused = &self.unused;
        let pre = &self.pre;
        let pre = pre.clone();
        let recording = *recording;
        let shown = shown.clone();
        let srcs = srcs.clone();
        let trees = trees.clone();
        let unused = *unused;
        let world = world.clone();
        call_then(crate::check::env::start_build_g(srcs.clone(), trees.clone()), move |build_g_2178: (crate::check::env::G, crate::check::types::St)| {
            let (g0a, stb) = build_g_2178;
            let g0 = {
                let mut this: crate::check::env::G = g0a.clone();
                this.prelude_from = shown.clone();
                this
            };
            let st0 = {
                let mut this: crate::check::types::St = stb.clone();
                this.recording = recording;
                this
            };
            call_then(start_top_lets(g0.clone(), st0.clone()), move |top_lets_2481: (crate::check::env::G, crate::check::types::St)| {
                let (g1, st1) = top_lets_2481;
                call_value(fold_job(g1.defs.clone(), (Array::new(), st1.clone()), {
                    let g1 = g1.clone();
                    Rc::new(move |(p0, p1): ((Array<Text>, crate::check::types::St), crate::check::env::Def)| {
                        let g1 = g1.clone();
                        entered(once_job(move || {
                            let (bad, s) = p0;
                            let d = p1;
                            {
                                let before_ = len(&s.diags);
                                call_then(start_check_def(g1.clone(), s.clone(), d.clone()), move |check_def_2619: crate::check::types::St| {
                                    let s2 = check_def_2619;
                                    let bad2 = if &len(&s2.diags) > &before_ {
                                        push(&bad, &crate::check::shrink::types::own_key(&d).qk)
                                    } else {
                                        bad.clone()
                                    };
                                    prism_rtl::Turn::Finished((bad2.clone(), s2.clone()))
                                })
                            }
                        }))
                    }) as Rc<dyn Fn(((Array<Text>, crate::check::types::St), crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<(Array<Text>, crate::check::types::St)>>>
                }), move |fold_2523: (Array<Text>, crate::check::types::St)| {
                    let (failed, st2) = fold_2523;
                    let st2b = {
                        let mut this: crate::check::types::St = st2.clone();
                        this.level = Nat::from(0u32);
                        this
                    };
                    call_then(crate::check::env::traits::start_default_wants(g1.clone(), st2b.clone(), Array::new()), move |default_wants_2802: crate::check::types::St| {
                        let st3 = default_wants_2802;
                        let good = filter(&g1.defs, &(|d: &crate::check::env::Def| !crate::check::types::has_text(&failed, &crate::check::shrink::types::own_key(d).qk)));
                        call_then(crate::check::shrink::start_shrink_check(g1.clone(), st3.clone(), good.clone()), move |shrink_check_3073: (crate::check::types::St, Array<(Text, Array<Text>)>)| {
                            let (st4, refs) = shrink_check_3073;
                            call_then(start_root_row(g1.clone(), st4.clone(), world.clone()), move |root_row_3126: (Text, crate::check::types::St)| {
                                let (root_row_, st5) = root_row_3126;
                                let warnings = if unused {
                                    crate::check::shrink::unused_defs(&good, &refs, &shown)
                                } else {
                                    Array::new()
                                };
                                let reached = crate::check::shrink::test_only_reached(&srcs, &g1.defs, &refs);
                                let diags = crate::check::errors::sort_diags(&append(&append(&append(&filter(&st5.diags, &(|d: &crate::check::errors::CDiag| &d.file < &shown)), &warnings), &pre), &reached));
                                let text_ = concat(&each(&diags, &(|d: &crate::check::errors::CDiag| crate::check::errors::render_cdiag(&srcs, d))));
                                let typed = if recording {
                                    typed_of(&g1, &st5, &shown)
                                } else {
                                    crate::check::typed::empty_typed()
                                };
                                prism_rtl::Turn::Finished(Report_ { text: text_.clone(), errors: len(&filter(&diags, &(|d: &crate::check::errors::CDiag| !crate::check::errors::is_warning(d)))), root_row: root_row_.clone(), typed: typed.clone() })
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start CheckProgram, x`: what the function value is when passed to `@Run`.
pub fn start_check_program(srcs: Array<crate::check::errors::Src>, trees: Array<crate::syntax::Module>, world: Array<Text>, shown: Nat, recording: bool, unused: bool, pre: Array<crate::check::errors::CDiag>) -> Rc<dyn prism_rtl::Job<Report_>> {
    Rc::new(CheckProgram { srcs, trees, world, shown, recording, unused, pre })
}

/// ```prism
/// TypedOf: unbounded fn G, St, Nat -> TProgram
/// ```
pub fn typed_of(g: &crate::check::env::G, st: &crate::check::types::St, shown: &Nat) -> crate::check::typed::TProgram {
    let z = crate::check::types::recording::zonk_typed(st);
    let vals = filter(&values(&g.vals), &(|v_: &crate::check::env::ValInfo| ((&v_.file < shown) && (&v_.sort != &Text::lit("builtin"))) && (&or(&get(&g.mods, &v_.home), &crate::check::env::reading::dummy_mod()).file == &v_.file)));
    let mut this: crate::check::typed::TProgram = z.clone();
    this.defs = run_to_end(each_job(vals.clone(), {
        let st = st.clone();
        Rc::new(move |p0: crate::check::env::ValInfo| {
            let st = st.clone();
            entered(once_job(move || {
                let v_ = p0;
                call_then(start_zonk_scheme(st.clone(), v_.scheme.clone()), move |zonk_scheme_4102: crate::check::types::Scheme| prism_rtl::Turn::Finished(crate::check::typed::DefNote { at: crate::check::typed::SrcAt { file: v_.file.clone(), span: v_.span.clone() }, name: v_.qk.clone(), scheme: zonk_scheme_4102 }))
            }))
        }) as Rc<dyn Fn(crate::check::env::ValInfo) -> Rc<dyn prism_rtl::Job<crate::check::typed::DefNote>>>
    }));
    this
}

/// The step machine of `TypedOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypedOf: unbounded fn G, St, Nat -> TProgram
/// ```
pub struct TypedOf {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub shown: Nat,
}

impl prism_rtl::Job<crate::check::typed::TProgram> for TypedOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::typed::TProgram> {
        let g = &self.g;
        let st = &self.st;
        let shown = &self.shown;
        let g = g.clone();
        let shown = shown.clone();
        let st = st.clone();
        call_then(crate::check::types::recording::start_zonk_typed(st.clone()), move |zonk_typed_3845: crate::check::typed::TProgram| {
            let z = zonk_typed_3845;
            let vals = filter(&values(&g.vals), &(|v_: &crate::check::env::ValInfo| ((&v_.file < &shown) && (&v_.sort != &Text::lit("builtin"))) && (&or(&get(&g.mods, &v_.home), &crate::check::env::reading::dummy_mod()).file == &v_.file)));
            prism_rtl::Turn::Finished({
                let mut this: crate::check::typed::TProgram = z.clone();
                this.defs = run_to_end(each_job(vals.clone(), {
                    let st = st.clone();
                    Rc::new(move |p0: crate::check::env::ValInfo| {
                        let st = st.clone();
                        entered(once_job(move || {
                            let v_ = p0;
                            call_then(start_zonk_scheme(st.clone(), v_.scheme.clone()), move |zonk_scheme_4102: crate::check::types::Scheme| prism_rtl::Turn::Finished(crate::check::typed::DefNote { at: crate::check::typed::SrcAt { file: v_.file.clone(), span: v_.span.clone() }, name: v_.qk.clone(), scheme: zonk_scheme_4102 }))
                        }))
                    }) as Rc<dyn Fn(crate::check::env::ValInfo) -> Rc<dyn prism_rtl::Job<crate::check::typed::DefNote>>>
                }));
                this
            })
        })
    }
}

/// `Start TypedOf, x`: what the function value is when passed to `@Run`.
pub fn start_typed_of(g: crate::check::env::G, st: crate::check::types::St, shown: Nat) -> Rc<dyn prism_rtl::Job<crate::check::typed::TProgram>> {
    Rc::new(TypedOf { g, st, shown })
}

/// ```prism
/// ZonkScheme: unbounded fn St, Scheme -> Scheme
/// ```
pub fn zonk_scheme(st: &crate::check::types::St, sc: &crate::check::types::Scheme) -> crate::check::types::Scheme {
    let mut this: crate::check::types::Scheme = sc.clone();
    this.ty = crate::check::types::recording::zonk(st, &this.ty);
    this
}

/// The step machine of `ZonkScheme`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ZonkScheme: unbounded fn St, Scheme -> Scheme
/// ```
pub struct ZonkScheme {
    pub st: crate::check::types::St,
    pub sc: crate::check::types::Scheme,
}

impl prism_rtl::Job<crate::check::types::Scheme> for ZonkScheme {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Scheme> {
        let st = &self.st;
        let sc = &self.sc;
        prism_rtl::Turn::Finished({
            let mut this: crate::check::types::Scheme = sc.clone();
            this.ty = crate::check::types::recording::zonk(st, &this.ty);
            this
        })
    }
}

/// `Start ZonkScheme, x`: what the function value is when passed to `@Run`.
pub fn start_zonk_scheme(st: crate::check::types::St, sc: crate::check::types::Scheme) -> Rc<dyn prism_rtl::Job<crate::check::types::Scheme>> {
    Rc::new(ZonkScheme { st, sc })
}

/// ```prism
/// TopLets: unbounded fn G, St -> ((G, St))
/// ```
pub fn top_lets(g: &crate::check::env::G, st: &crate::check::types::St) -> (crate::check::env::G, crate::check::types::St) {
    let unsigned = filter(&g.defs, &(|d: &crate::check::env::Def| is_let_def(d) && !crate::check::env::has_key(&g.vals, &d.qk)));
    let (g1, st1) = fold(&unsigned, &(g.clone(), st.clone()), &(|(gg, s): &(crate::check::env::G, crate::check::types::St), d: &crate::check::env::Def| {
        let (v_, s2) = crate::check::types::fresh_var(s, &false, &d.name);
        let gg2 = {
            let mut this: crate::check::env::G = gg.clone();
            this.vals = insert(&this.vals, &d.qk, &crate::check::env::ValInfo { qk: d.qk.clone(), scheme: crate::check::types::schemes::mono(&v_), sort: Text::lit("let"), has_sig: false, home: d.home.clone(), file: d.file.clone(), span: d.span.clone() });
            this
        };
        (gg2.clone(), s2.clone())
    }));
    run_to_end(fold_job(unsigned.clone(), (g1.clone(), st1.clone()), Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St), crate::check::env::Def)| entered(once_job(move || {
        let (gg, s) = p0;
        let d = p1;
        match &d.body {
            crate::check::env::DefBody::DbLet(l) => {
                let env = def_env(&gg, &d);
                let s0 = {
                    let mut this: crate::check::types::St = s.clone();
                    this.file = d.file.clone();
                    this.level = Nat::from(1u32);
                    this
                };
                let pre = or(&get(&gg.vals, &d.qk), &dummy_val()).scheme.ty.clone();
                let l = l.clone();
                call_then(crate::check::expr::start_check(env.clone(), s0.clone(), l.value.clone(), pre.clone()), move |check_5197: crate::check::types::St| {
                    let s1 = check_5197;
                    call_then(crate::check::env::traits::start_solve_wants(gg.clone(), s1.clone(), Array::new(), false), move |solve_wants_5246: crate::check::types::St| {
                        let s2 = solve_wants_5246;
                        let s3 = {
                            let mut this: crate::check::types::St = s2.clone();
                            this.level = Nat::from(0u32);
                            this
                        };
                        call_then(crate::check::types::recording::start_zonk(s3.clone(), pre.clone()), move |zonk_5359: crate::check::types::Ty| {
                            let t = zonk_5359;
                            call_then(crate::check::expr::lets::start_wants_above(s3.clone(), t.clone(), crate::check::expr::is_lambda(&l.value)), move |wants_above_5411: (Array<Nat>, Array<(Nat, Text)>, crate::check::types::St)| {
                                let (keep, bounds, s4) = wants_above_5411;
                                call_then(crate::check::types::schemes::start_holds_node(s4.clone(), t.clone()), move |holds_node_5480: bool| {
                                    let (sc, s5) = if holds_node_5480 {
                                        (crate::check::types::schemes::mono(&t), s4.clone())
                                    } else {
                                        crate::check::types::schemes::generalize(&s4, &t, &keep, &bounds)
                                    };
                                    let gg2 = {
                                        let mut this: crate::check::env::G = gg.clone();
                                        this.vals = insert(&this.vals, &d.qk, &crate::check::env::ValInfo { qk: d.qk.clone(), scheme: sc.clone(), sort: Text::lit("let"), has_sig: false, home: d.home.clone(), file: d.file.clone(), span: d.span.clone() });
                                        this
                                    };
                                    call_then(crate::check::types::colors::start_check_colors(s5.clone()), move |check_colors_5799: crate::check::types::St| call_then(crate::check::env::traits::start_resolve_fields(gg.clone(), check_colors_5799, true), move |resolve_fields_5780: crate::check::types::St| call_then(crate::check::types::unify::start_layer_questions(resolve_fields_5780), move |layer_questions_5764: crate::check::types::St| call_then(crate::check::passes::start_discharge_incls(gg.clone(), layer_questions_5764, Nat::from(0u32)), move |discharge_incls_5744: crate::check::types::St| prism_rtl::Turn::Finished((gg2.clone(), discharge_incls_5744))))))
                                })
                            })
                        })
                    })
                })
            },
            _ => prism_rtl::Turn::Finished((gg.clone(), s.clone())),
        }
    }))) as Rc<dyn Fn(((crate::check::env::G, crate::check::types::St), crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>>>))
}

/// The step machine of `TopLets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TopLets: unbounded fn G, St -> ((G, St))
/// ```
pub struct TopLets {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for TopLets {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let unsigned = filter(&g.defs, &(|d: &crate::check::env::Def| is_let_def(d) && !crate::check::env::has_key(&g.vals, &d.qk)));
        let (g1, st1) = fold(&unsigned, &(g.clone(), st.clone()), &(|(gg, s): &(crate::check::env::G, crate::check::types::St), d: &crate::check::env::Def| {
            let (v_, s2) = crate::check::types::fresh_var(s, &false, &d.name);
            let gg2 = {
                let mut this: crate::check::env::G = gg.clone();
                this.vals = insert(&this.vals, &d.qk, &crate::check::env::ValInfo { qk: d.qk.clone(), scheme: crate::check::types::schemes::mono(&v_), sort: Text::lit("let"), has_sig: false, home: d.home.clone(), file: d.file.clone(), span: d.span.clone() });
                this
            };
            (gg2.clone(), s2.clone())
        }));
        fold_job(unsigned.clone(), (g1.clone(), st1.clone()), Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St), crate::check::env::Def)| entered(once_job(move || {
            let (gg, s) = p0;
            let d = p1;
            match &d.body {
                crate::check::env::DefBody::DbLet(l) => {
                    let env = def_env(&gg, &d);
                    let s0 = {
                        let mut this: crate::check::types::St = s.clone();
                        this.file = d.file.clone();
                        this.level = Nat::from(1u32);
                        this
                    };
                    let pre = or(&get(&gg.vals, &d.qk), &dummy_val()).scheme.ty.clone();
                    let l = l.clone();
                    call_then(crate::check::expr::start_check(env.clone(), s0.clone(), l.value.clone(), pre.clone()), move |check_5197: crate::check::types::St| {
                        let s1 = check_5197;
                        call_then(crate::check::env::traits::start_solve_wants(gg.clone(), s1.clone(), Array::new(), false), move |solve_wants_5246: crate::check::types::St| {
                            let s2 = solve_wants_5246;
                            let s3 = {
                                let mut this: crate::check::types::St = s2.clone();
                                this.level = Nat::from(0u32);
                                this
                            };
                            call_then(crate::check::types::recording::start_zonk(s3.clone(), pre.clone()), move |zonk_5359: crate::check::types::Ty| {
                                let t = zonk_5359;
                                call_then(crate::check::expr::lets::start_wants_above(s3.clone(), t.clone(), crate::check::expr::is_lambda(&l.value)), move |wants_above_5411: (Array<Nat>, Array<(Nat, Text)>, crate::check::types::St)| {
                                    let (keep, bounds, s4) = wants_above_5411;
                                    call_then(crate::check::types::schemes::start_holds_node(s4.clone(), t.clone()), move |holds_node_5480: bool| {
                                        let (sc, s5) = if holds_node_5480 {
                                            (crate::check::types::schemes::mono(&t), s4.clone())
                                        } else {
                                            crate::check::types::schemes::generalize(&s4, &t, &keep, &bounds)
                                        };
                                        let gg2 = {
                                            let mut this: crate::check::env::G = gg.clone();
                                            this.vals = insert(&this.vals, &d.qk, &crate::check::env::ValInfo { qk: d.qk.clone(), scheme: sc.clone(), sort: Text::lit("let"), has_sig: false, home: d.home.clone(), file: d.file.clone(), span: d.span.clone() });
                                            this
                                        };
                                        call_then(crate::check::types::colors::start_check_colors(s5.clone()), move |check_colors_5799: crate::check::types::St| call_then(crate::check::env::traits::start_resolve_fields(gg.clone(), check_colors_5799, true), move |resolve_fields_5780: crate::check::types::St| call_then(crate::check::types::unify::start_layer_questions(resolve_fields_5780), move |layer_questions_5764: crate::check::types::St| call_then(crate::check::passes::start_discharge_incls(gg.clone(), layer_questions_5764, Nat::from(0u32)), move |discharge_incls_5744: crate::check::types::St| prism_rtl::Turn::Finished((gg2.clone(), discharge_incls_5744))))))
                                    })
                                })
                            })
                        })
                    })
                },
                _ => prism_rtl::Turn::Finished((gg.clone(), s.clone())),
            }
        }))) as Rc<dyn Fn(((crate::check::env::G, crate::check::types::St), crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>>>).cycle()
    }
}

/// `Start TopLets, x`: what the function value is when passed to `@Run`.
pub fn start_top_lets(g: crate::check::env::G, st: crate::check::types::St) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    Rc::new(TopLets { g, st })
}

/// ```prism
/// let dummyVal
/// ```
pub fn dummy_val() -> crate::check::env::ValInfo {
    crate::check::env::ValInfo { qk: Text::lit(""), scheme: crate::check::types::schemes::mono(&crate::check::types::Ty::TyErr), sort: Text::lit(""), has_sig: false, home: Text::lit(""), file: Nat::from(0u32), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// IsLetDef: fn Def -> Bool
/// ```
pub fn is_let_def(d: &crate::check::env::Def) -> bool {
    match &d.body {
        crate::check::env::DefBody::DbLet(_) => true,
        _ => false,
    }
}

/// ```prism
/// DefEnv: fn G, Def -> Env
/// ```
pub fn def_env(g: &crate::check::env::G, d: &crate::check::env::Def) -> crate::check::expr::Env {
    let info = or(&get(&g.mods, &d.home), &crate::check::env::reading::dummy_mod());
    let scope = match &info.emit_rw.tail {
        crate::check::types::Tail::TlQ(v_) => crate::check::types::Rw { fams: info.emit_rw.fams.clone(), minus: Array::new(), tail: crate::check::types::Tail::TlRigid(v_.clone()) },
        _ => info.emit_rw.clone(),
    };
    crate::check::expr::Env { g: g.clone(), home: d.home.clone(), file: d.file.clone(), src: or(&index(&g.srcs, &d.file), &crate::check::errors::mk_src(&Text::lit(""), &Text::lit(""))), locals: Map::new(), scope: scope.clone(), givens: Array::new(), mark: Text::lit(""), in_update: false, def_name: d.name.clone(), refine: Map::new(), pending: Array::new() }
}

/// ```prism
/// CheckDef: unbounded fn G, St, Def -> St
/// ```
pub fn check_def(g: &crate::check::env::G, st: &crate::check::types::St, d: &crate::check::env::Def) -> crate::check::types::St {
    let env = def_env(g, d);
    let incls_before = len(&st.incls);
    let s0 = {
        let mut this: crate::check::types::St = st.clone();
        this.file = d.file.clone();
        this.level = Nat::from(1u32);
        this.color = crate::check::types::Col::CBound;
        this.color_why = Text::lit("");
        this.color_flex = Array::new();
        this.cleqs = Array::new();
        this
    };
    let s1 = match &d.body {
        crate::check::env::DefBody::DbFn(clauses) => match get(&g.vals, &d.qk) {
            Some(v_) => crate::check::expr::lets::check_clauses(&env, &s0, &d.name, clauses, &v_.scheme, &d.span),
            None => s0.clone(),
        },
        crate::check::env::DefBody::DbWidget(w) => check_widget_def(&env, &s0, d, w),
        crate::check::env::DefBody::DbLet(l) => match get(&g.vals, &d.qk) {
            Some(v_) => if v_.has_sig {
                crate::check::expr::check(&env, &s0, &l.value, &crate::check::types::schemes::skolemize(&v_.scheme))
            } else {
                s0.clone()
            },
            None => s0.clone(),
        },
        crate::check::env::DefBody::DbMethod(clauses, cls, im) => check_method(&env, &s0, d, clauses, cls, im),
        crate::check::env::DefBody::DbDefault(clauses, cls) => match method_key(g, cls, &d.name) {
            Some(mk) => match get(&g.vals, &mk) {
                Some(v_) => crate::check::expr::lets::check_clauses(&env, &s0, &d.name, clauses, &v_.scheme, &d.span),
                None => s0.clone(),
            },
            None => s0.clone(),
        },
        crate::check::env::DefBody::DbCheck(c) => run_to_end(fold_job(c.lines.clone(), s0.clone(), {
            let env = env.clone();
            Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::CheckLine)| {
                let env = env.clone();
                entered(once_job(move || {
                    let s = p0;
                    let line = p1;
                    call_then(crate::check::expr::start_infer(env.clone(), s.clone(), line.expr.clone()), move |infer_7813: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t, s2) = infer_7813;
                        match &line.pattern {
                            Some(p_) => {
                                let p_ = p_.clone();
                                call_then(crate::check::expr::patterns::start_bind_pattern(env.clone(), s2.clone(), p_.clone(), t.clone(), true), move |bind_pattern_7932: (crate::check::expr::Env, crate::check::types::St)| {
                                    let (_, s3) = bind_pattern_7932;
                                    prism_rtl::Turn::Finished(s3.clone())
                                })
                            },
                            None => prism_rtl::Turn::Finished(s2.clone()),
                        }
                    })
                }))
            }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::decls::CheckLine)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        })),
        crate::check::env::DefBody::DbTest(t) => {
            let (bt, s2) = crate::check::expr::infer(&env, &s0, &t.blueprint);
            match crate::check::types::recording::walk(&s2, &bt) {
                crate::check::types::Ty::TyAt(_, _) => s2.clone(),
                crate::check::types::Ty::TyErr => s2.clone(),
                other => crate::check::types::recording::err(&s2, &Text::lit("mismatch"), &t.blueprint.span, &Text::from(format!("a test builds a blueprint; this is `{}`", &crate::check::types::show_ty(&s2, &other)))),
            }
        },
    };
    let solved = crate::check::types::colors::check_colors(&crate::check::env::traits::solve_wants(g, &s1, &env.givens, &false));
    let defaulted = crate::check::types::unify::layer_questions(&crate::check::env::traits::resolve_fields(g, &default_def(g, &solved), &true));
    let discharged = crate::check::passes::discharge_incls(g, &defaulted, &incls_before);
    let mut this: crate::check::types::St = discharged.clone();
    this.level = Nat::from(0u32);
    this
}

/// The step machine of `CheckDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckDef: unbounded fn G, St, Def -> St
/// ```
pub struct CheckDef {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub d: crate::check::env::Def,
}

impl prism_rtl::Job<crate::check::types::St> for CheckDef {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let st = &self.st;
        let d = &self.d;
        let env = def_env(g, d);
        let incls_before = len(&st.incls);
        let s0 = {
            let mut this: crate::check::types::St = st.clone();
            this.file = d.file.clone();
            this.level = Nat::from(1u32);
            this.color = crate::check::types::Col::CBound;
            this.color_why = Text::lit("");
            this.color_flex = Array::new();
            this.cleqs = Array::new();
            this
        };
        let s1 = match &d.body {
            crate::check::env::DefBody::DbFn(clauses) => match get(&g.vals, &d.qk) {
                Some(v_) => crate::check::expr::lets::check_clauses(&env, &s0, &d.name, clauses, &v_.scheme, &d.span),
                None => s0.clone(),
            },
            crate::check::env::DefBody::DbWidget(w) => check_widget_def(&env, &s0, d, w),
            crate::check::env::DefBody::DbLet(l) => match get(&g.vals, &d.qk) {
                Some(v_) => if v_.has_sig {
                    crate::check::expr::check(&env, &s0, &l.value, &crate::check::types::schemes::skolemize(&v_.scheme))
                } else {
                    s0.clone()
                },
                None => s0.clone(),
            },
            crate::check::env::DefBody::DbMethod(clauses, cls, im) => check_method(&env, &s0, d, clauses, cls, im),
            crate::check::env::DefBody::DbDefault(clauses, cls) => match method_key(g, cls, &d.name) {
                Some(mk) => match get(&g.vals, &mk) {
                    Some(v_) => crate::check::expr::lets::check_clauses(&env, &s0, &d.name, clauses, &v_.scheme, &d.span),
                    None => s0.clone(),
                },
                None => s0.clone(),
            },
            crate::check::env::DefBody::DbCheck(c) => run_to_end(fold_job(c.lines.clone(), s0.clone(), {
                let env = env.clone();
                Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::CheckLine)| {
                    let env = env.clone();
                    entered(once_job(move || {
                        let s = p0;
                        let line = p1;
                        call_then(crate::check::expr::start_infer(env.clone(), s.clone(), line.expr.clone()), move |infer_7813: (crate::check::types::Ty, crate::check::types::St)| {
                            let (t, s2) = infer_7813;
                            match &line.pattern {
                                Some(p_) => {
                                    let p_ = p_.clone();
                                    call_then(crate::check::expr::patterns::start_bind_pattern(env.clone(), s2.clone(), p_.clone(), t.clone(), true), move |bind_pattern_7932: (crate::check::expr::Env, crate::check::types::St)| {
                                        let (_, s3) = bind_pattern_7932;
                                        prism_rtl::Turn::Finished(s3.clone())
                                    })
                                },
                                None => prism_rtl::Turn::Finished(s2.clone()),
                            }
                        })
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::decls::CheckLine)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            })),
            crate::check::env::DefBody::DbTest(t) => {
                let (bt, s2) = crate::check::expr::infer(&env, &s0, &t.blueprint);
                match crate::check::types::recording::walk(&s2, &bt) {
                    crate::check::types::Ty::TyAt(_, _) => s2.clone(),
                    crate::check::types::Ty::TyErr => s2.clone(),
                    other => crate::check::types::recording::err(&s2, &Text::lit("mismatch"), &t.blueprint.span, &Text::from(format!("a test builds a blueprint; this is `{}`", &crate::check::types::show_ty(&s2, &other)))),
                }
            },
        };
        let g = g.clone();
        call_then(crate::check::env::traits::start_solve_wants(g.clone(), s1.clone(), env.givens.clone(), false), move |solve_wants_8331: crate::check::types::St| call_then(crate::check::types::colors::start_check_colors(solve_wants_8331), move |check_colors_8318: crate::check::types::St| {
            let solved = check_colors_8318;
            call_then(start_default_def(g.clone(), solved.clone()), move |default_def_8422: crate::check::types::St| call_then(crate::check::env::traits::start_resolve_fields(g.clone(), default_def_8422, true), move |resolve_fields_8404: crate::check::types::St| call_then(crate::check::types::unify::start_layer_questions(resolve_fields_8404), move |layer_questions_8388: crate::check::types::St| {
                let defaulted = layer_questions_8388;
                call_then(crate::check::passes::start_discharge_incls(g.clone(), defaulted.clone(), incls_before.clone()), move |discharge_incls_8472: crate::check::types::St| {
                    let discharged = discharge_incls_8472;
                    prism_rtl::Turn::Finished({
                        let mut this: crate::check::types::St = discharged.clone();
                        this.level = Nat::from(0u32);
                        this
                    })
                })
            })))
        }))
    }
}

/// `Start CheckDef, x`: what the function value is when passed to `@Run`.
pub fn start_check_def(g: crate::check::env::G, st: crate::check::types::St, d: crate::check::env::Def) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckDef { g, st, d })
}

/// ```prism
/// DefaultDef: unbounded fn G, St -> St
/// ```
pub fn default_def(g: &crate::check::env::G, st: &crate::check::types::St) -> crate::check::types::St {
    let mine = run_to_end(filter_job(st.wants.clone(), {
        let st = st.clone();
        Rc::new(move |p0: crate::check::types::Want| {
            let st = st.clone();
            entered(once_job(move || {
                let w = p0;
                call_then(crate::check::types::recording::start_walk(st.clone(), w.ty.clone()), move |walk_8794: crate::check::types::Ty| match walk_8794 {
                    crate::check::types::Ty::TyFlex(n) => prism_rtl::Turn::Finished(&crate::check::types::recording::info_of(&st, &n).level >= &Nat::from(1u32)),
                    _ => prism_rtl::Turn::Finished(true),
                })
            }))
        }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    let theirs = run_to_end(filter_job(st.wants.clone(), {
        let st = st.clone();
        Rc::new(move |p0: crate::check::types::Want| {
            let st = st.clone();
            entered(once_job(move || {
                let w = p0;
                call_then(crate::check::types::recording::start_walk(st.clone(), w.ty.clone()), move |walk_8922: crate::check::types::Ty| match walk_8922 {
                    crate::check::types::Ty::TyFlex(n) => prism_rtl::Turn::Finished(&crate::check::types::recording::info_of(&st, &n).level < &Nat::from(1u32)),
                    _ => prism_rtl::Turn::Finished(false),
                })
            }))
        }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    let st1 = {
        let mut this: crate::check::types::St = st.clone();
        this.wants = mine.clone();
        this
    };
    let s2 = crate::check::env::traits::default_wants(g, &st1, &Array::new());
    let mut this: crate::check::types::St = s2.clone();
    this.wants = append(&theirs, &this.wants);
    this
}

/// The step machine of `DefaultDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefaultDef: unbounded fn G, St -> St
/// ```
pub struct DefaultDef {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
}

impl prism_rtl::Job<crate::check::types::St> for DefaultDef {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g = &self.g;
        let st = &self.st;
        let g = g.clone();
        let st = st.clone();
        call_value(filter_job(st.wants.clone(), {
            let st = st.clone();
            Rc::new(move |p0: crate::check::types::Want| {
                let st = st.clone();
                entered(once_job(move || {
                    let w = p0;
                    call_then(crate::check::types::recording::start_walk(st.clone(), w.ty.clone()), move |walk_8794: crate::check::types::Ty| match walk_8794 {
                        crate::check::types::Ty::TyFlex(n) => prism_rtl::Turn::Finished(&crate::check::types::recording::info_of(&st, &n).level >= &Nat::from(1u32)),
                        _ => prism_rtl::Turn::Finished(true),
                    })
                }))
            }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
        }), move |filter_8766: Array<crate::check::types::Want>| {
            let mine = filter_8766;
            call_value(filter_job(st.wants.clone(), {
                let st = st.clone();
                Rc::new(move |p0: crate::check::types::Want| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let w = p0;
                        call_then(crate::check::types::recording::start_walk(st.clone(), w.ty.clone()), move |walk_8922: crate::check::types::Ty| match walk_8922 {
                            crate::check::types::Ty::TyFlex(n) => prism_rtl::Turn::Finished(&crate::check::types::recording::info_of(&st, &n).level < &Nat::from(1u32)),
                            _ => prism_rtl::Turn::Finished(false),
                        })
                    }))
                }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
            }), move |filter_8894: Array<crate::check::types::Want>| {
                let theirs = filter_8894;
                let st1 = {
                    let mut this: crate::check::types::St = st.clone();
                    this.wants = mine.clone();
                    this
                };
                call_then(crate::check::env::traits::start_default_wants(g.clone(), st1.clone(), Array::new()), move |default_wants_9068: crate::check::types::St| {
                    let s2 = default_wants_9068;
                    prism_rtl::Turn::Finished({
                        let mut this: crate::check::types::St = s2.clone();
                        this.wants = append(&theirs, &this.wants);
                        this
                    })
                })
            })
        })
    }
}

/// `Start DefaultDef, x`: what the function value is when passed to `@Run`.
pub fn start_default_def(g: crate::check::env::G, st: crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(DefaultDef { g, st })
}

/// ```prism
/// CheckWidgetDef: unbounded fn Env, St, Def, WidgetDecl -> St
/// ```
pub fn check_widget_def(env: &crate::check::expr::Env, st: &crate::check::types::St, d: &crate::check::env::Def, w: &crate::syntax::decls::WidgetDecl) -> crate::check::types::St {
    match get(&env.g.vals, &d.qk) {
        Some(v_) => match crate::check::types::schemes::skolemize(&v_.scheme) {
            crate::check::types::Ty::TyAt(inner, rw) => {
                let env2 = {
                    let mut this: crate::check::expr::Env = env.clone();
                    this.scope = rw.clone();
                    this.mark = Text::lit("@");
                    this
                };
                let (t, st2) = crate::check::blocks::infer_widget_block(&env2, st, &w.body);
                crate::check::types::recording::note_fn(&crate::check::types::unify::unify(&st2, &*inner, &t, &w.span), &w.span, &d.name, &crate::check::types::Col::CBound, &st2.color)
            },
            other => crate::check::types::recording::err(st, &Text::lit("mismatch"), &w.span, &Text::from(format!("`{}` is declared `{}`; a widget block builds a blueprint", &d.name, &crate::check::types::show_ty(st, &other)))),
        },
        None => {
            let (t, st2) = crate::check::blocks::infer_widget_block(env, st, &w.body);
            crate::check::types::recording::note_fn(&st2, &w.span, &d.name, &crate::check::types::Col::CBound, &st2.color)
        },
    }
}

/// The step machine of `CheckWidgetDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckWidgetDef: unbounded fn Env, St, Def, WidgetDecl -> St
/// ```
pub struct CheckWidgetDef {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub d: crate::check::env::Def,
    pub w: crate::syntax::decls::WidgetDecl,
}

impl prism_rtl::Job<crate::check::types::St> for CheckWidgetDef {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let d = &self.d;
        let w = &self.w;
        match get(&env.g.vals, &d.qk) {
            Some(v_) => {
                let d = d.clone();
                let env = env.clone();
                let st = st.clone();
                let w = w.clone();
                call_then(crate::check::types::schemes::start_skolemize(v_.scheme.clone()), move |skolemize_9374: crate::check::types::Ty| match skolemize_9374 {
                    crate::check::types::Ty::TyAt(inner, rw) => {
                        let env2 = {
                            let mut this: crate::check::expr::Env = env.clone();
                            this.scope = rw.clone();
                            this.mark = Text::lit("@");
                            this
                        };
                        call_then(crate::check::blocks::start_infer_widget_block(env2.clone(), st.clone(), w.body.clone()), move |infer_widget_block_9544: (crate::check::types::Ty, crate::check::types::St)| {
                            let (t, st2) = infer_widget_block_9544;
                            call_then(crate::check::types::unify::start_unify(st2.clone(), (*inner).clone(), t.clone(), w.span.clone()), move |unify_9598: crate::check::types::St| prism_rtl::Turn::Finished(crate::check::types::recording::note_fn(&unify_9598, &w.span, &d.name, &crate::check::types::Col::CBound, &st2.color)))
                        })
                    },
                    other => call_then(crate::check::types::start_show_ty(st.clone(), other.clone()), move |show_ty_9731: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err(&st, &Text::lit("mismatch"), &w.span, &Text::from(format!("`{}` is declared `{}`; a widget block builds a blueprint", &d.name, &show_ty_9731))))),
                })
            },
            None => {
                let d = d.clone();
                let env = env.clone();
                let st = st.clone();
                let w = w.clone();
                call_then(crate::check::blocks::start_infer_widget_block(env.clone(), st.clone(), w.body.clone()), move |infer_widget_block_9820: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t, st2) = infer_widget_block_9820;
                    prism_rtl::Turn::Finished(crate::check::types::recording::note_fn(&st2, &w.span, &d.name, &crate::check::types::Col::CBound, &st2.color))
                })
            },
        }
    }
}

/// `Start CheckWidgetDef, x`: what the function value is when passed to `@Run`.
pub fn start_check_widget_def(env: crate::check::expr::Env, st: crate::check::types::St, d: crate::check::env::Def, w: crate::syntax::decls::WidgetDecl) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckWidgetDef { env, st, d, w })
}

/// ```prism
/// ?MethodKey: fn G, Text, Text -> ?Text
/// ```
pub fn method_key(g: &crate::check::env::G, cls: &Text, name: &Text) -> Option<Text> {
    fold(&or(&get(&g.traits, cls), &crate::check::env::traits::dummy_trait()).methods, &None, &(|found_opt: &Option<Text>, k: &Text| match found_opt {
        Some(f) => Some(f.clone()),
        None => if (&crate::check::types::bare_name(k) == name) || (&crate::syntax::lexer::chars::drop_prefix(k, &Text::from(format!("{}.", &or(&get(&g.traits, cls), &crate::check::env::traits::dummy_trait()).home))) == name) {
            Some(k.clone())
        } else {
            None
        },
    }))
}

/// ```prism
/// CheckMethod: unbounded fn Env, St, Def, [FnClause], Text, ImplInfo -> St
/// ```
pub fn check_method(env: &crate::check::expr::Env, st: &crate::check::types::St, d: &crate::check::env::Def, clauses: &Array<crate::syntax::decls::FnClause>, cls: &Text, im: &crate::check::env::ImplInfo) -> crate::check::types::St {
    match method_key(&env.g, cls, &d.name) {
        None => crate::check::types::recording::err(st, &Text::lit("mismatch"), &d.span, &Text::from(format!("`^{}` has no method `{}`", &crate::check::types::bare_name(cls), &d.name))),
        Some(mk) => match get(&env.g.vals, &mk) {
            None => st.clone(),
            Some(v_) => {
                let ti = or(&get(&env.g.traits, cls), &crate::check::env::traits::dummy_trait());
                let head = crate::check::types::schemes::subst_q(&crate::check::types::schemes::Inst { tys: fold(&im.qs, &Map::new(), &(|m: &Map<Text, crate::check::types::Ty>, q: &Text| insert(m, q, &crate::check::types::Ty::TyRigid(q.clone())))), rows: Map::new(), cols: Map::new() }, &im.head);
                let ty = crate::check::types::schemes::subst_q(&crate::check::types::schemes::Inst { tys: map_of(vec![(ti.param.clone(), head.clone())]), rows: Map::new(), cols: Map::new() }, &v_.scheme.ty);
                let sc = crate::check::types::Scheme { qs: filter(&v_.scheme.qs, &(|q: &Text| q != &ti.param)), plain_qs: Array::new(), rqs: v_.scheme.rqs.clone(), cqs: v_.scheme.cqs.clone(), cjoins: v_.scheme.cjoins.clone(), bounds: filter(&v_.scheme.bounds, &(|(q, _): &(Text, Text)| q != &ti.param)), ty: ty.clone() };
                let env2 = {
                    let mut this: crate::check::expr::Env = env.clone();
                    this.givens = im.bounds.clone();
                    this
                };
                crate::check::expr::lets::check_clauses(&env2, st, &d.name, clauses, &sc, &d.span)
            },
        },
    }
}

/// The step machine of `CheckMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckMethod: unbounded fn Env, St, Def, [FnClause], Text, ImplInfo -> St
/// ```
pub struct CheckMethod {
    pub env: crate::check::expr::Env,
    pub st: crate::check::types::St,
    pub d: crate::check::env::Def,
    pub clauses: Array<crate::syntax::decls::FnClause>,
    pub cls: Text,
    pub im: crate::check::env::ImplInfo,
}

impl prism_rtl::Job<crate::check::types::St> for CheckMethod {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env = &self.env;
        let st = &self.st;
        let d = &self.d;
        let clauses = &self.clauses;
        let cls = &self.cls;
        let im = &self.im;
        match method_key(&env.g, cls, &d.name) {
            None => prism_rtl::Turn::Finished(crate::check::types::recording::err(st, &Text::lit("mismatch"), &d.span, &Text::from(format!("`^{}` has no method `{}`", &crate::check::types::bare_name(cls), &d.name)))),
            Some(mk) => match get(&env.g.vals, &mk) {
                None => prism_rtl::Turn::Finished(st.clone()),
                Some(v_) => {
                    let ti = or(&get(&env.g.traits, cls), &crate::check::env::traits::dummy_trait());
                    let clauses = clauses.clone();
                    let d = d.clone();
                    let env = env.clone();
                    let im = im.clone();
                    let st = st.clone();
                    call_then(crate::check::types::schemes::start_subst_q(crate::check::types::schemes::Inst { tys: fold(&im.qs, &Map::new(), &(|m: &Map<Text, crate::check::types::Ty>, q: &Text| insert(m, q, &crate::check::types::Ty::TyRigid(q.clone())))), rows: Map::new(), cols: Map::new() }, im.head.clone()), move |subst_q_10691: crate::check::types::Ty| {
                        let head = subst_q_10691;
                        call_then(crate::check::types::schemes::start_subst_q(crate::check::types::schemes::Inst { tys: map_of(vec![(ti.param.clone(), head.clone())]), rows: Map::new(), cols: Map::new() }, v_.scheme.ty.clone()), move |subst_q_10809: crate::check::types::Ty| {
                            let ty = subst_q_10809;
                            let sc = crate::check::types::Scheme { qs: filter(&v_.scheme.qs, &(|q: &Text| q != &ti.param)), plain_qs: Array::new(), rqs: v_.scheme.rqs.clone(), cqs: v_.scheme.cqs.clone(), cjoins: v_.scheme.cjoins.clone(), bounds: filter(&v_.scheme.bounds, &(|(q, _): &(Text, Text)| q != &ti.param)), ty: ty.clone() };
                            let env2 = {
                                let mut this: crate::check::expr::Env = env.clone();
                                this.givens = im.bounds.clone();
                                this
                            };
                            prism_rtl::Turn::More(Rc::new(crate::check::expr::lets::CheckClauses { env: env2.clone(), st: st.clone(), name: d.name.clone(), clauses: clauses.clone(), sc: sc.clone(), span: d.span.clone() }))
                        })
                    })
                },
            },
        }
    }
}

/// `Start CheckMethod, x`: what the function value is when passed to `@Run`.
pub fn start_check_method(env: crate::check::expr::Env, st: crate::check::types::St, d: crate::check::env::Def, clauses: Array<crate::syntax::decls::FnClause>, cls: Text, im: crate::check::env::ImplInfo) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckMethod { env, st, d, clauses, cls, im })
}

/// ```prism
/// RootRow: unbounded fn G, St, [Text] -> ((Text, St))
/// ```
pub fn root_row(g: &crate::check::env::G, st: &crate::check::types::St, world: &Array<Text>) -> (Text, crate::check::types::St) {
    match get(&g.mods, &Text::lit("")) {
        None => (Text::lit(""), st.clone()),
        Some(info) => {
            let shown = crate::check::types::show_row(&info.emit_rw);
            if &len(world) == &Nat::from(0u32) {
                (shown.clone(), st.clone())
            } else {
                {
                    let missing = filter(&info.emit_rw.fams, &(|f: &Text| !crate::check::types::has_text(world, f)));
                    if &len(&missing) == &Nat::from(0u32) {
                        (shown.clone(), st.clone())
                    } else {
                        {
                            let s0 = {
                                let mut this: crate::check::types::St = st.clone();
                                this.file = info.file.clone();
                                this
                            };
                            (shown.clone(), crate::check::types::recording::err_fix(&s0, &Text::lit("world-row"), &info.tree.span, &Text::from(format!("the program emits {}, which this World does not answer", &crate::syntax::lexer::chars::join(&each(&missing, &(|f: &Text| Text::from(format!("`{}.*`", f)))), &Text::lit(", ")))), &Text::lit("host the tags it cannot answer, or run under a World that answers them")))
                        }
                    }
                }
            }
        },
    }
}

/// The step machine of `RootRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RootRow: unbounded fn G, St, [Text] -> ((Text, St))
/// ```
pub struct RootRow {
    pub g: crate::check::env::G,
    pub st: crate::check::types::St,
    pub world: Array<Text>,
}

impl prism_rtl::Job<(Text, crate::check::types::St)> for RootRow {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::check::types::St)> {
        let g = &self.g;
        let st = &self.st;
        let world = &self.world;
        match get(&g.mods, &Text::lit("")) {
            None => prism_rtl::Turn::Finished((Text::lit(""), st.clone())),
            Some(info) => {
                let shown = crate::check::types::show_row(&info.emit_rw);
                if &len(world) == &Nat::from(0u32) {
                    prism_rtl::Turn::Finished((shown.clone(), st.clone()))
                } else {
                    {
                        let missing = filter(&info.emit_rw.fams, &(|f: &Text| !crate::check::types::has_text(world, f)));
                        if &len(&missing) == &Nat::from(0u32) {
                            prism_rtl::Turn::Finished((shown.clone(), st.clone()))
                        } else {
                            {
                                let s0 = {
                                    let mut this: crate::check::types::St = st.clone();
                                    this.file = info.file.clone();
                                    this
                                };
                                prism_rtl::Turn::Finished((shown.clone(), crate::check::types::recording::err_fix(&s0, &Text::lit("world-row"), &info.tree.span, &Text::from(format!("the program emits {}, which this World does not answer", &crate::syntax::lexer::chars::join(&each(&missing, &(|f: &Text| Text::from(format!("`{}.*`", f)))), &Text::lit(", ")))), &Text::lit("host the tags it cannot answer, or run under a World that answers them"))))
                            }
                        }
                    }
                }
            },
        }
    }
}

/// `Start RootRow, x`: what the function value is when passed to `@Run`.
pub fn start_root_row(g: crate::check::env::G, st: crate::check::types::St, world: Array<Text>) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>> {
    Rc::new(RootRow { g, st, world })
}
