//! The module `Check`, from `target/bootstrap/src/prismc/check/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod blocks;
pub mod env;
pub mod errors;
pub mod expr;
pub mod passes;
pub mod regex;
pub mod shrink;
pub mod typed;
pub mod types;

/// `Report`:
///
/// ```prism
/// type Report = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Report_ {
    pub text: Text,
    pub errors: Nat,
    pub root_row: Text,
    pub typed: crate::check::typed::TProgram,
}

impl Show for Report_ {
    fn show(&self, p: &mut Printer) {
        p.record("Report", &[("text", &self.text), ("errors", &self.errors), ("root_row", &self.root_row), ("typed", &self.typed)]);
    }
}

impl ToPod for Report_ {
    fn to_pod(&self) -> Pod {
        Pod::record("Report", vec![("text", self.text.to_pod()), ("errors", self.errors.to_pod()), ("root_row", self.root_row.to_pod()), ("typed", self.typed.to_pod())])
    }
}

impl FromPod for Report_ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Report_ { text: FromPod::from_pod(field(p, "text")?)?, errors: FromPod::from_pod(field(p, "errors")?)?, root_row: FromPod::from_pod(field(p, "root_row")?)?, typed: FromPod::from_pod(field(p, "typed")?)? })
    }
}

/// ```prism
/// CheckProgram: unbounded fn [Src], [Module], [Text], Nat, Bool, Bool, [CDiag] -> Report
/// ```
pub fn check_program(srcs_p0: &Array<crate::check::errors::Src>, trees_p1: &Array<crate::syntax::Module>, world_p2: &Array<Text>, shown_p3: &Nat, recording_p4: &bool, unused_p5: &bool, pre_p6: &Array<crate::check::errors::CDiag>) -> Report_ {
    let (g0a_ph, stb_pi) = crate::check::env::build_g(srcs_p0, trees_p1);
    let g0_p7 = {
        let mut this: crate::check::env::G = g0a_ph.clone();
        this.prelude_from = shown_p3.clone();
        this
    };
    let st0_p8 = {
        let mut this: crate::check::types::St = stb_pi.clone();
        this.recording = *recording_p4;
        this
    };
    let (g1_pj, st1_pk) = top_lets(&g0_p7, &st0_p8);
    let (failed_pr, st2_ps) = run_to_end(fold_job(g1_pj.defs.clone(), (Array::new(), st1_pk.clone()), {
        let g1_pj = g1_pj.clone();
        Rc::new(move |(p0, p1): ((Array<Text>, crate::check::types::St), crate::check::env::Def)| {
            let g1_pj = g1_pj.clone();
            entered(once_job(move || {
                let (bad_pl, s_pm) = p0;
                let d_pn = p1;
                {
                    let before_po = len(&s_pm.diags);
                    call_then(start_check_def(g1_pj.clone(), s_pm.clone(), d_pn.clone()), move |check_def_2629: crate::check::types::St| {
                        let s2_pp = check_def_2629;
                        let bad2_pq = if &len(&s2_pp.diags) > &before_po {
                            push(&bad_pl, &crate::check::shrink::types::own_key(&d_pn).qk)
                        } else {
                            bad_pl.clone()
                        };
                        prism_rtl::Turn::Finished((bad2_pq.clone(), s2_pp.clone()))
                    })
                }
            }))
        }) as Rc<dyn Fn(((Array<Text>, crate::check::types::St), crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<(Array<Text>, crate::check::types::St)>>>
    }));
    let st2b_p9 = {
        let mut this: crate::check::types::St = st2_ps.clone();
        this.level = Nat::from(0u32);
        this
    };
    let st3_pa = crate::check::env::traits::default_wants(&g1_pj, &st2b_p9, &Array::new());
    let good_pb = filter(&g1_pj.defs, &(|d_pt: &crate::check::env::Def| !crate::check::types::has_text(&failed_pr, &crate::check::shrink::types::own_key(d_pt).qk)));
    let (st4_pu, refs_pv) = crate::check::shrink::shrink_check(&g1_pj, &st3_pa, &good_pb);
    let (root_row_p10, st5_p11) = root_row(&g1_pj, &st4_pu, world_p2);
    let warnings_pc = if *unused_p5 {
        crate::check::shrink::unused_defs(&good_pb, &refs_pv, shown_p3)
    } else {
        Array::new()
    };
    let reached_pd = crate::check::shrink::test_only_reached(srcs_p0, &g1_pj.defs, &refs_pv);
    let diags_pe = crate::check::errors::sort_diags(&append(&append(&append(&filter(&st5_p11.diags, &(|d_p12: &crate::check::errors::CDiag| &d_p12.file < shown_p3)), &warnings_pc), pre_p6), &reached_pd));
    let text_pf = concat(&each(&diags_pe, &(|d_p13: &crate::check::errors::CDiag| crate::check::errors::render_cdiag(srcs_p0, d_p13))));
    let typed_pg = if *recording_p4 {
        typed_of(&g1_pj, &st5_p11, shown_p3)
    } else {
        crate::check::typed::empty_typed()
    };
    Report_ { text: text_pf.clone(), errors: len(&filter(&diags_pe, &(|d_p14: &crate::check::errors::CDiag| !crate::check::errors::is_warning(d_p14)))), root_row: root_row_p10.clone(), typed: typed_pg.clone() }
}

/// The step machine of `CheckProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckProgram: unbounded fn [Src], [Module], [Text], Nat, Bool, Bool, [CDiag] -> Report
/// ```
pub struct CheckProgram {
    pub srcs_p0: Array<crate::check::errors::Src>,
    pub trees_p1: Array<crate::syntax::Module>,
    pub world_p2: Array<Text>,
    pub shown_p3: Nat,
    pub recording_p4: bool,
    pub unused_p5: bool,
    pub pre_p6: Array<crate::check::errors::CDiag>,
}

impl prism_rtl::Job<Report_> for CheckProgram {
    fn cycle(&self) -> prism_rtl::Turn<Report_> {
        let srcs_p0 = &self.srcs_p0;
        let trees_p1 = &self.trees_p1;
        let world_p2 = &self.world_p2;
        let shown_p3 = &self.shown_p3;
        let recording_p4 = &self.recording_p4;
        let unused_p5 = &self.unused_p5;
        let pre_p6 = &self.pre_p6;
        let pre_p6 = pre_p6.clone();
        let recording_p4 = *recording_p4;
        let shown_p3 = shown_p3.clone();
        let srcs_p0 = srcs_p0.clone();
        let trees_p1 = trees_p1.clone();
        let unused_p5 = *unused_p5;
        let world_p2 = world_p2.clone();
        call_then(crate::check::env::start_build_g(srcs_p0.clone(), trees_p1.clone()), move |build_g_2188: (crate::check::env::G, crate::check::types::St)| {
            let (g0a_ph, stb_pi) = build_g_2188;
            let g0_p7 = {
                let mut this: crate::check::env::G = g0a_ph.clone();
                this.prelude_from = shown_p3.clone();
                this
            };
            let st0_p8 = {
                let mut this: crate::check::types::St = stb_pi.clone();
                this.recording = recording_p4;
                this
            };
            call_then(start_top_lets(g0_p7.clone(), st0_p8.clone()), move |top_lets_2491: (crate::check::env::G, crate::check::types::St)| {
                let (g1_pj, st1_pk) = top_lets_2491;
                call_value(fold_job(g1_pj.defs.clone(), (Array::new(), st1_pk.clone()), {
                    let g1_pj = g1_pj.clone();
                    Rc::new(move |(p0, p1): ((Array<Text>, crate::check::types::St), crate::check::env::Def)| {
                        let g1_pj = g1_pj.clone();
                        entered(once_job(move || {
                            let (bad_pl, s_pm) = p0;
                            let d_pn = p1;
                            {
                                let before_po = len(&s_pm.diags);
                                call_then(start_check_def(g1_pj.clone(), s_pm.clone(), d_pn.clone()), move |check_def_2629: crate::check::types::St| {
                                    let s2_pp = check_def_2629;
                                    let bad2_pq = if &len(&s2_pp.diags) > &before_po {
                                        push(&bad_pl, &crate::check::shrink::types::own_key(&d_pn).qk)
                                    } else {
                                        bad_pl.clone()
                                    };
                                    prism_rtl::Turn::Finished((bad2_pq.clone(), s2_pp.clone()))
                                })
                            }
                        }))
                    }) as Rc<dyn Fn(((Array<Text>, crate::check::types::St), crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<(Array<Text>, crate::check::types::St)>>>
                }), move |fold_2533: (Array<Text>, crate::check::types::St)| {
                    let (failed_pr, st2_ps) = fold_2533;
                    let st2b_p9 = {
                        let mut this: crate::check::types::St = st2_ps.clone();
                        this.level = Nat::from(0u32);
                        this
                    };
                    call_then(crate::check::env::traits::start_default_wants(g1_pj.clone(), st2b_p9.clone(), Array::new()), move |default_wants_2812: crate::check::types::St| {
                        let st3_pa = default_wants_2812;
                        let good_pb = filter(&g1_pj.defs, &(|d_pt: &crate::check::env::Def| !crate::check::types::has_text(&failed_pr, &crate::check::shrink::types::own_key(d_pt).qk)));
                        call_then(crate::check::shrink::start_shrink_check(g1_pj.clone(), st3_pa.clone(), good_pb.clone()), move |shrink_check_3083: (crate::check::types::St, Array<(Text, Array<Text>)>)| {
                            let (st4_pu, refs_pv) = shrink_check_3083;
                            call_then(start_root_row(g1_pj.clone(), st4_pu.clone(), world_p2.clone()), move |root_row_3136: (Text, crate::check::types::St)| {
                                let (root_row_p10, st5_p11) = root_row_3136;
                                let warnings_pc = if unused_p5 {
                                    crate::check::shrink::unused_defs(&good_pb, &refs_pv, &shown_p3)
                                } else {
                                    Array::new()
                                };
                                let reached_pd = crate::check::shrink::test_only_reached(&srcs_p0, &g1_pj.defs, &refs_pv);
                                let diags_pe = crate::check::errors::sort_diags(&append(&append(&append(&filter(&st5_p11.diags, &(|d_p12: &crate::check::errors::CDiag| &d_p12.file < &shown_p3)), &warnings_pc), &pre_p6), &reached_pd));
                                let text_pf = concat(&each(&diags_pe, &(|d_p13: &crate::check::errors::CDiag| crate::check::errors::render_cdiag(&srcs_p0, d_p13))));
                                let typed_pg = if recording_p4 {
                                    typed_of(&g1_pj, &st5_p11, &shown_p3)
                                } else {
                                    crate::check::typed::empty_typed()
                                };
                                prism_rtl::Turn::Finished(Report_ { text: text_pf.clone(), errors: len(&filter(&diags_pe, &(|d_p14: &crate::check::errors::CDiag| !crate::check::errors::is_warning(d_p14)))), root_row: root_row_p10.clone(), typed: typed_pg.clone() })
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start CheckProgram, x`: what the function value is when passed to `@Run`.
pub fn start_check_program(srcs_p0: Array<crate::check::errors::Src>, trees_p1: Array<crate::syntax::Module>, world_p2: Array<Text>, shown_p3: Nat, recording_p4: bool, unused_p5: bool, pre_p6: Array<crate::check::errors::CDiag>) -> Rc<dyn prism_rtl::Job<Report_>> {
    Rc::new(CheckProgram { srcs_p0, trees_p1, world_p2, shown_p3, recording_p4, unused_p5, pre_p6 })
}

/// ```prism
/// TypedOf: unbounded fn G, St, Nat -> TProgram
/// ```
pub fn typed_of(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, shown_p2: &Nat) -> crate::check::typed::TProgram {
    let z_p3 = crate::check::types::recording::zonk_typed(st_p1);
    let vals_p4 = filter(&values(&g_p0.vals), &(|v_p5: &crate::check::env::ValInfo| ((&v_p5.file < shown_p2) && (&v_p5.sort != &Text::lit("builtin"))) && (&or(&get(&g_p0.mods, &v_p5.home), &crate::check::env::reading::dummy_mod()).file == &v_p5.file)));
    let mut this: crate::check::typed::TProgram = z_p3.clone();
    this.defs = run_to_end(each_job(vals_p4.clone(), {
        let st_p1 = st_p1.clone();
        Rc::new(move |p0: crate::check::env::ValInfo| {
            let st_p1 = st_p1.clone();
            entered(once_job(move || {
                let v_p6 = p0;
                call_then(start_zonk_scheme(st_p1.clone(), v_p6.scheme.clone()), move |zonk_scheme_4112: crate::check::types::Scheme| prism_rtl::Turn::Finished(crate::check::typed::DefNote { at: crate::check::typed::SrcAt { file: v_p6.file.clone(), span: v_p6.span.clone() }, name: v_p6.qk.clone(), scheme: zonk_scheme_4112 }))
            }))
        }) as Rc<dyn Fn(crate::check::env::ValInfo) -> Rc<dyn prism_rtl::Job<crate::check::typed::DefNote>>>
    }));
    this
}

/// The step machine of `TypedOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypedOf: unbounded fn G, St, Nat -> TProgram
/// ```
pub struct TypedOf {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub shown_p2: Nat,
}

impl prism_rtl::Job<crate::check::typed::TProgram> for TypedOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::typed::TProgram> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let shown_p2 = &self.shown_p2;
        let g_p0 = g_p0.clone();
        let shown_p2 = shown_p2.clone();
        let st_p1 = st_p1.clone();
        call_then(crate::check::types::recording::start_zonk_typed(st_p1.clone()), move |zonk_typed_3855: crate::check::typed::TProgram| {
            let z_p3 = zonk_typed_3855;
            let vals_p4 = filter(&values(&g_p0.vals), &(|v_p5: &crate::check::env::ValInfo| ((&v_p5.file < &shown_p2) && (&v_p5.sort != &Text::lit("builtin"))) && (&or(&get(&g_p0.mods, &v_p5.home), &crate::check::env::reading::dummy_mod()).file == &v_p5.file)));
            prism_rtl::Turn::Finished({
                let mut this: crate::check::typed::TProgram = z_p3.clone();
                this.defs = run_to_end(each_job(vals_p4.clone(), {
                    let st_p1 = st_p1.clone();
                    Rc::new(move |p0: crate::check::env::ValInfo| {
                        let st_p1 = st_p1.clone();
                        entered(once_job(move || {
                            let v_p6 = p0;
                            call_then(start_zonk_scheme(st_p1.clone(), v_p6.scheme.clone()), move |zonk_scheme_4112: crate::check::types::Scheme| prism_rtl::Turn::Finished(crate::check::typed::DefNote { at: crate::check::typed::SrcAt { file: v_p6.file.clone(), span: v_p6.span.clone() }, name: v_p6.qk.clone(), scheme: zonk_scheme_4112 }))
                        }))
                    }) as Rc<dyn Fn(crate::check::env::ValInfo) -> Rc<dyn prism_rtl::Job<crate::check::typed::DefNote>>>
                }));
                this
            })
        })
    }
}

/// `Start TypedOf, x`: what the function value is when passed to `@Run`.
pub fn start_typed_of(g_p0: crate::check::env::G, st_p1: crate::check::types::St, shown_p2: Nat) -> Rc<dyn prism_rtl::Job<crate::check::typed::TProgram>> {
    Rc::new(TypedOf { g_p0, st_p1, shown_p2 })
}

/// ```prism
/// ZonkScheme: unbounded fn St, Scheme -> Scheme
/// ```
pub fn zonk_scheme(st_p0: &crate::check::types::St, sc_p1: &crate::check::types::Scheme) -> crate::check::types::Scheme {
    let mut this: crate::check::types::Scheme = sc_p1.clone();
    this.ty = crate::check::types::recording::zonk(st_p0, &this.ty);
    this
}

/// The step machine of `ZonkScheme`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ZonkScheme: unbounded fn St, Scheme -> Scheme
/// ```
pub struct ZonkScheme {
    pub st_p0: crate::check::types::St,
    pub sc_p1: crate::check::types::Scheme,
}

impl prism_rtl::Job<crate::check::types::Scheme> for ZonkScheme {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Scheme> {
        let st_p0 = &self.st_p0;
        let sc_p1 = &self.sc_p1;
        prism_rtl::Turn::Finished({
            let mut this: crate::check::types::Scheme = sc_p1.clone();
            this.ty = crate::check::types::recording::zonk(st_p0, &this.ty);
            this
        })
    }
}

/// `Start ZonkScheme, x`: what the function value is when passed to `@Run`.
pub fn start_zonk_scheme(st_p0: crate::check::types::St, sc_p1: crate::check::types::Scheme) -> Rc<dyn prism_rtl::Job<crate::check::types::Scheme>> {
    Rc::new(ZonkScheme { st_p0, sc_p1 })
}

/// ```prism
/// TopLets: unbounded fn G, St -> ((G, St))
/// ```
pub fn top_lets(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St) -> (crate::check::env::G, crate::check::types::St) {
    let unsigned_p2 = filter(&g_p0.defs, &(|d_p3: &crate::check::env::Def| is_let_def(d_p3) && !crate::check::env::has_key(&g_p0.vals, &d_p3.qk)));
    let (g1_pa, st1_pb) = fold(&unsigned_p2, &(g_p0.clone(), st_p1.clone()), &(|(gg_p4, s_p5): &(crate::check::env::G, crate::check::types::St), d_p6: &crate::check::env::Def| {
        let (v_p8, s2_p9) = crate::check::types::fresh_var(s_p5, &false, &d_p6.name);
        let gg2_p7 = {
            let mut this: crate::check::env::G = gg_p4.clone();
            this.vals = insert(&this.vals, &d_p6.qk, &crate::check::env::ValInfo { qk: d_p6.qk.clone(), scheme: crate::check::types::schemes::mono(&v_p8), sort: Text::lit("let"), has_sig: false, home: d_p6.home.clone(), file: d_p6.file.clone(), span: d_p6.span.clone() });
            this
        };
        (gg2_p7.clone(), s2_p9.clone())
    }));
    run_to_end(fold_job(unsigned_p2.clone(), (g1_pa.clone(), st1_pb.clone()), Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St), crate::check::env::Def)| entered(once_job(move || {
        let (gg_pc, s_pd) = p0;
        let d_pe = p1;
        match &d_pe.body {
            crate::check::env::DefBody::DbLet(l_pf) => {
                let env_pg = def_env(&gg_pc, &d_pe);
                let s0_ph = {
                    let mut this: crate::check::types::St = s_pd.clone();
                    this.file = d_pe.file.clone();
                    this.level = Nat::from(1u32);
                    this.local_next = Nat::from(0u32);
                    this
                };
                let pre_pi = or(&get(&gg_pc.vals, &d_pe.qk), &dummy_val()).scheme.ty.clone();
                let l_pf = l_pf.clone();
                call_then(crate::check::expr::start_check(env_pg.clone(), s0_ph.clone(), l_pf.value.clone(), pre_pi.clone()), move |check_5241: crate::check::types::St| {
                    let s1_pj = check_5241;
                    call_then(crate::check::env::traits::start_solve_wants(gg_pc.clone(), s1_pj.clone(), Array::new(), false), move |solve_wants_5290: crate::check::types::St| {
                        let s2_pk = solve_wants_5290;
                        let s3_pl = {
                            let mut this: crate::check::types::St = s2_pk.clone();
                            this.level = Nat::from(0u32);
                            this
                        };
                        call_then(crate::check::types::recording::start_zonk(s3_pl.clone(), pre_pi.clone()), move |zonk_5403: crate::check::types::Ty| {
                            let t_pm = zonk_5403;
                            call_then(crate::check::expr::lets::start_wants_above(s3_pl.clone(), t_pm.clone(), crate::check::expr::is_lambda(&l_pf.value)), move |wants_above_5455: (Array<Nat>, Array<(Nat, Text)>, crate::check::types::St)| {
                                let (keep_po, bounds_pp, s4_pq) = wants_above_5455;
                                call_then(crate::check::types::schemes::start_holds_node(s4_pq.clone(), t_pm.clone()), move |holds_node_5524: bool| {
                                    let (sc_pr, s5_ps) = if holds_node_5524 {
                                        (crate::check::types::schemes::mono(&t_pm), s4_pq.clone())
                                    } else {
                                        crate::check::types::schemes::generalize(&s4_pq, &t_pm, &keep_po, &bounds_pp)
                                    };
                                    let gg2_pn = {
                                        let mut this: crate::check::env::G = gg_pc.clone();
                                        this.vals = insert(&this.vals, &d_pe.qk, &crate::check::env::ValInfo { qk: d_pe.qk.clone(), scheme: sc_pr.clone(), sort: Text::lit("let"), has_sig: false, home: d_pe.home.clone(), file: d_pe.file.clone(), span: d_pe.span.clone() });
                                        this
                                    };
                                    call_then(crate::check::types::colors::start_check_colors(s5_ps.clone()), move |check_colors_5843: crate::check::types::St| call_then(crate::check::env::traits::start_resolve_fields(gg_pc.clone(), check_colors_5843, true), move |resolve_fields_5824: crate::check::types::St| call_then(crate::check::types::unify::start_layer_questions(resolve_fields_5824), move |layer_questions_5808: crate::check::types::St| call_then(crate::check::passes::start_discharge_incls(gg_pc.clone(), layer_questions_5808, Nat::from(0u32)), move |discharge_incls_5788: crate::check::types::St| prism_rtl::Turn::Finished((gg2_pn.clone(), discharge_incls_5788))))))
                                })
                            })
                        })
                    })
                })
            },
            _ => prism_rtl::Turn::Finished((gg_pc.clone(), s_pd.clone())),
        }
    }))) as Rc<dyn Fn(((crate::check::env::G, crate::check::types::St), crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>>>))
}

/// The step machine of `TopLets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TopLets: unbounded fn G, St -> ((G, St))
/// ```
pub struct TopLets {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for TopLets {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let unsigned_p2 = filter(&g_p0.defs, &(|d_p3: &crate::check::env::Def| is_let_def(d_p3) && !crate::check::env::has_key(&g_p0.vals, &d_p3.qk)));
        let (g1_pa, st1_pb) = fold(&unsigned_p2, &(g_p0.clone(), st_p1.clone()), &(|(gg_p4, s_p5): &(crate::check::env::G, crate::check::types::St), d_p6: &crate::check::env::Def| {
            let (v_p8, s2_p9) = crate::check::types::fresh_var(s_p5, &false, &d_p6.name);
            let gg2_p7 = {
                let mut this: crate::check::env::G = gg_p4.clone();
                this.vals = insert(&this.vals, &d_p6.qk, &crate::check::env::ValInfo { qk: d_p6.qk.clone(), scheme: crate::check::types::schemes::mono(&v_p8), sort: Text::lit("let"), has_sig: false, home: d_p6.home.clone(), file: d_p6.file.clone(), span: d_p6.span.clone() });
                this
            };
            (gg2_p7.clone(), s2_p9.clone())
        }));
        fold_job(unsigned_p2.clone(), (g1_pa.clone(), st1_pb.clone()), Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St), crate::check::env::Def)| entered(once_job(move || {
            let (gg_pc, s_pd) = p0;
            let d_pe = p1;
            match &d_pe.body {
                crate::check::env::DefBody::DbLet(l_pf) => {
                    let env_pg = def_env(&gg_pc, &d_pe);
                    let s0_ph = {
                        let mut this: crate::check::types::St = s_pd.clone();
                        this.file = d_pe.file.clone();
                        this.level = Nat::from(1u32);
                        this.local_next = Nat::from(0u32);
                        this
                    };
                    let pre_pi = or(&get(&gg_pc.vals, &d_pe.qk), &dummy_val()).scheme.ty.clone();
                    let l_pf = l_pf.clone();
                    call_then(crate::check::expr::start_check(env_pg.clone(), s0_ph.clone(), l_pf.value.clone(), pre_pi.clone()), move |check_5241: crate::check::types::St| {
                        let s1_pj = check_5241;
                        call_then(crate::check::env::traits::start_solve_wants(gg_pc.clone(), s1_pj.clone(), Array::new(), false), move |solve_wants_5290: crate::check::types::St| {
                            let s2_pk = solve_wants_5290;
                            let s3_pl = {
                                let mut this: crate::check::types::St = s2_pk.clone();
                                this.level = Nat::from(0u32);
                                this
                            };
                            call_then(crate::check::types::recording::start_zonk(s3_pl.clone(), pre_pi.clone()), move |zonk_5403: crate::check::types::Ty| {
                                let t_pm = zonk_5403;
                                call_then(crate::check::expr::lets::start_wants_above(s3_pl.clone(), t_pm.clone(), crate::check::expr::is_lambda(&l_pf.value)), move |wants_above_5455: (Array<Nat>, Array<(Nat, Text)>, crate::check::types::St)| {
                                    let (keep_po, bounds_pp, s4_pq) = wants_above_5455;
                                    call_then(crate::check::types::schemes::start_holds_node(s4_pq.clone(), t_pm.clone()), move |holds_node_5524: bool| {
                                        let (sc_pr, s5_ps) = if holds_node_5524 {
                                            (crate::check::types::schemes::mono(&t_pm), s4_pq.clone())
                                        } else {
                                            crate::check::types::schemes::generalize(&s4_pq, &t_pm, &keep_po, &bounds_pp)
                                        };
                                        let gg2_pn = {
                                            let mut this: crate::check::env::G = gg_pc.clone();
                                            this.vals = insert(&this.vals, &d_pe.qk, &crate::check::env::ValInfo { qk: d_pe.qk.clone(), scheme: sc_pr.clone(), sort: Text::lit("let"), has_sig: false, home: d_pe.home.clone(), file: d_pe.file.clone(), span: d_pe.span.clone() });
                                            this
                                        };
                                        call_then(crate::check::types::colors::start_check_colors(s5_ps.clone()), move |check_colors_5843: crate::check::types::St| call_then(crate::check::env::traits::start_resolve_fields(gg_pc.clone(), check_colors_5843, true), move |resolve_fields_5824: crate::check::types::St| call_then(crate::check::types::unify::start_layer_questions(resolve_fields_5824), move |layer_questions_5808: crate::check::types::St| call_then(crate::check::passes::start_discharge_incls(gg_pc.clone(), layer_questions_5808, Nat::from(0u32)), move |discharge_incls_5788: crate::check::types::St| prism_rtl::Turn::Finished((gg2_pn.clone(), discharge_incls_5788))))))
                                    })
                                })
                            })
                        })
                    })
                },
                _ => prism_rtl::Turn::Finished((gg_pc.clone(), s_pd.clone())),
            }
        }))) as Rc<dyn Fn(((crate::check::env::G, crate::check::types::St), crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>>>).cycle()
    }
}

/// `Start TopLets, x`: what the function value is when passed to `@Run`.
pub fn start_top_lets(g_p0: crate::check::env::G, st_p1: crate::check::types::St) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    Rc::new(TopLets { g_p0, st_p1 })
}

/// ```prism
/// let dummyVal
/// ```
pub fn dummy_val() -> crate::check::env::ValInfo {
    crate::check::env::ValInfo { qk: Text::lit(""), scheme: crate::check::types::schemes::mono(&crate::check::types::Ty::TyErr), sort: Text::lit(""), has_sig: false, home: Text::lit(""), file: Nat::from(0u32), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// IsLetDef: fn Def -> Bool
/// ```
pub fn is_let_def(d_p0: &crate::check::env::Def) -> bool {
    match &d_p0.body {
        crate::check::env::DefBody::DbLet(_) => true,
        _ => false,
    }
}

/// ```prism
/// DefEnv: fn G, Def -> Env
/// ```
pub fn def_env(g_p0: &crate::check::env::G, d_p1: &crate::check::env::Def) -> crate::check::expr::Env {
    let info_p2 = or(&get(&g_p0.mods, &d_p1.home), &crate::check::env::reading::dummy_mod());
    let scope_p3 = match &info_p2.emit_rw.tail {
        crate::check::types::Tail::TlQ(v_p4) => crate::check::types::Rw { fams: info_p2.emit_rw.fams.clone(), minus: Array::new(), tail: crate::check::types::Tail::TlRigid(v_p4.clone()) },
        _ => info_p2.emit_rw.clone(),
    };
    crate::check::expr::Env { g: g_p0.clone(), home: d_p1.home.clone(), file: d_p1.file.clone(), src: or(&index(&g_p0.srcs, &d_p1.file), &crate::check::errors::mk_src(&Text::lit(""), &Text::lit(""))), locals: Map::new(), scope: scope_p3.clone(), givens: Array::new(), mark: Text::lit(""), in_update: false, def_name: d_p1.name.clone(), refine: Map::new(), pending: Array::new(), ids: Map::new() }
}

/// ```prism
/// CheckDef: unbounded fn G, St, Def -> St
/// ```
pub fn check_def(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, d_p2: &crate::check::env::Def) -> crate::check::types::St {
    let env_p3 = def_env(g_p0, d_p2);
    let incls_before_p4 = len(&st_p1.incls);
    let s0_p5 = {
        let mut this: crate::check::types::St = st_p1.clone();
        this.file = d_p2.file.clone();
        this.level = Nat::from(1u32);
        this.local_next = Nat::from(0u32);
        this.color = crate::check::types::Col::CBound;
        this.color_why = Text::lit("");
        this.color_flex = Array::new();
        this.cleqs = Array::new();
        this
    };
    let s1_p6 = match &d_p2.body {
        crate::check::env::DefBody::DbFn(clauses_pa) => match get(&g_p0.vals, &d_p2.qk) {
            Some(v_pb) => crate::check::expr::lets::check_clauses(&env_p3, &s0_p5, &d_p2.name, clauses_pa, &v_pb.scheme, &d_p2.span),
            None => s0_p5.clone(),
        },
        crate::check::env::DefBody::DbWidget(w_pc) => check_widget_def(&env_p3, &s0_p5, d_p2, w_pc),
        crate::check::env::DefBody::DbLet(l_pd) => match get(&g_p0.vals, &d_p2.qk) {
            Some(v_pe) => if v_pe.has_sig {
                crate::check::expr::check(&env_p3, &s0_p5, &l_pd.value, &crate::check::types::schemes::skolemize(&v_pe.scheme))
            } else {
                s0_p5.clone()
            },
            None => s0_p5.clone(),
        },
        crate::check::env::DefBody::DbMethod(clauses_pf, cls_pg, im_ph) => check_method(&env_p3, &s0_p5, d_p2, clauses_pf, cls_pg, im_ph),
        crate::check::env::DefBody::DbDefault(clauses_pi, cls_pj) => match method_key(g_p0, cls_pj, &d_p2.name) {
            Some(mk_pk) => match get(&g_p0.vals, &mk_pk) {
                Some(v_pl) => crate::check::expr::lets::check_clauses(&env_p3, &s0_p5, &d_p2.name, clauses_pi, &v_pl.scheme, &d_p2.span),
                None => s0_p5.clone(),
            },
            None => s0_p5.clone(),
        },
        crate::check::env::DefBody::DbCheck(c_pm) => run_to_end(fold_job(c_pm.lines.clone(), s0_p5.clone(), {
            let env_p3 = env_p3.clone();
            Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::CheckLine)| {
                let env_p3 = env_p3.clone();
                entered(once_job(move || {
                    let s_pn = p0;
                    let line_po = p1;
                    call_then(crate::check::expr::start_infer(env_p3.clone(), s_pn.clone(), line_po.expr.clone()), move |infer_7891: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t_pp, s2_pq) = infer_7891;
                        match &line_po.pattern {
                            Some(p_pr) => {
                                let p_pr = p_pr.clone();
                                call_then(crate::check::expr::patterns::start_bind_pattern(env_p3.clone(), s2_pq.clone(), p_pr.clone(), t_pp.clone(), true), move |bind_pattern_8010: (crate::check::expr::Env, crate::check::types::St)| {
                                    let (_, s3_ps) = bind_pattern_8010;
                                    prism_rtl::Turn::Finished(s3_ps.clone())
                                })
                            },
                            None => prism_rtl::Turn::Finished(s2_pq.clone()),
                        }
                    })
                }))
            }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::decls::CheckLine)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        })),
        crate::check::env::DefBody::DbTest(t_pt) => {
            let (bt_pu, s2_pv) = crate::check::expr::infer(&env_p3, &s0_p5, &t_pt.blueprint);
            match crate::check::types::recording::walk(&s2_pv, &bt_pu) {
                crate::check::types::Ty::TyAt(_, _) => s2_pv.clone(),
                crate::check::types::Ty::TyErr => s2_pv.clone(),
                other_p10 => crate::check::types::recording::err(&s2_pv, &Text::lit("mismatch"), &t_pt.blueprint.span, &Text::from(format!("a test builds a blueprint; this is `{}`", &crate::check::types::show_ty(&s2_pv, &other_p10)))),
            }
        },
    };
    let solved_p7 = crate::check::types::colors::check_colors(&crate::check::env::traits::solve_wants(g_p0, &s1_p6, &env_p3.givens, &false));
    let defaulted_p8 = crate::check::types::unify::layer_questions(&crate::check::env::traits::resolve_fields(g_p0, &default_def(g_p0, &solved_p7), &true));
    let discharged_p9 = crate::check::passes::discharge_incls(g_p0, &defaulted_p8, &incls_before_p4);
    let mut this: crate::check::types::St = discharged_p9.clone();
    this.level = Nat::from(0u32);
    this
}

/// The step machine of `CheckDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckDef: unbounded fn G, St, Def -> St
/// ```
pub struct CheckDef {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub d_p2: crate::check::env::Def,
}

impl prism_rtl::Job<crate::check::types::St> for CheckDef {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let d_p2 = &self.d_p2;
        let env_p3 = def_env(g_p0, d_p2);
        let incls_before_p4 = len(&st_p1.incls);
        let s0_p5 = {
            let mut this: crate::check::types::St = st_p1.clone();
            this.file = d_p2.file.clone();
            this.level = Nat::from(1u32);
            this.local_next = Nat::from(0u32);
            this.color = crate::check::types::Col::CBound;
            this.color_why = Text::lit("");
            this.color_flex = Array::new();
            this.cleqs = Array::new();
            this
        };
        let s1_p6 = match &d_p2.body {
            crate::check::env::DefBody::DbFn(clauses_pa) => match get(&g_p0.vals, &d_p2.qk) {
                Some(v_pb) => crate::check::expr::lets::check_clauses(&env_p3, &s0_p5, &d_p2.name, clauses_pa, &v_pb.scheme, &d_p2.span),
                None => s0_p5.clone(),
            },
            crate::check::env::DefBody::DbWidget(w_pc) => check_widget_def(&env_p3, &s0_p5, d_p2, w_pc),
            crate::check::env::DefBody::DbLet(l_pd) => match get(&g_p0.vals, &d_p2.qk) {
                Some(v_pe) => if v_pe.has_sig {
                    crate::check::expr::check(&env_p3, &s0_p5, &l_pd.value, &crate::check::types::schemes::skolemize(&v_pe.scheme))
                } else {
                    s0_p5.clone()
                },
                None => s0_p5.clone(),
            },
            crate::check::env::DefBody::DbMethod(clauses_pf, cls_pg, im_ph) => check_method(&env_p3, &s0_p5, d_p2, clauses_pf, cls_pg, im_ph),
            crate::check::env::DefBody::DbDefault(clauses_pi, cls_pj) => match method_key(g_p0, cls_pj, &d_p2.name) {
                Some(mk_pk) => match get(&g_p0.vals, &mk_pk) {
                    Some(v_pl) => crate::check::expr::lets::check_clauses(&env_p3, &s0_p5, &d_p2.name, clauses_pi, &v_pl.scheme, &d_p2.span),
                    None => s0_p5.clone(),
                },
                None => s0_p5.clone(),
            },
            crate::check::env::DefBody::DbCheck(c_pm) => run_to_end(fold_job(c_pm.lines.clone(), s0_p5.clone(), {
                let env_p3 = env_p3.clone();
                Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::CheckLine)| {
                    let env_p3 = env_p3.clone();
                    entered(once_job(move || {
                        let s_pn = p0;
                        let line_po = p1;
                        call_then(crate::check::expr::start_infer(env_p3.clone(), s_pn.clone(), line_po.expr.clone()), move |infer_7891: (crate::check::types::Ty, crate::check::types::St)| {
                            let (t_pp, s2_pq) = infer_7891;
                            match &line_po.pattern {
                                Some(p_pr) => {
                                    let p_pr = p_pr.clone();
                                    call_then(crate::check::expr::patterns::start_bind_pattern(env_p3.clone(), s2_pq.clone(), p_pr.clone(), t_pp.clone(), true), move |bind_pattern_8010: (crate::check::expr::Env, crate::check::types::St)| {
                                        let (_, s3_ps) = bind_pattern_8010;
                                        prism_rtl::Turn::Finished(s3_ps.clone())
                                    })
                                },
                                None => prism_rtl::Turn::Finished(s2_pq.clone()),
                            }
                        })
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::decls::CheckLine)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            })),
            crate::check::env::DefBody::DbTest(t_pt) => {
                let (bt_pu, s2_pv) = crate::check::expr::infer(&env_p3, &s0_p5, &t_pt.blueprint);
                match crate::check::types::recording::walk(&s2_pv, &bt_pu) {
                    crate::check::types::Ty::TyAt(_, _) => s2_pv.clone(),
                    crate::check::types::Ty::TyErr => s2_pv.clone(),
                    other_p10 => crate::check::types::recording::err(&s2_pv, &Text::lit("mismatch"), &t_pt.blueprint.span, &Text::from(format!("a test builds a blueprint; this is `{}`", &crate::check::types::show_ty(&s2_pv, &other_p10)))),
                }
            },
        };
        let g_p0 = g_p0.clone();
        call_then(crate::check::env::traits::start_solve_wants(g_p0.clone(), s1_p6.clone(), env_p3.givens.clone(), false), move |solve_wants_8409: crate::check::types::St| call_then(crate::check::types::colors::start_check_colors(solve_wants_8409), move |check_colors_8396: crate::check::types::St| {
            let solved_p7 = check_colors_8396;
            call_then(start_default_def(g_p0.clone(), solved_p7.clone()), move |default_def_8500: crate::check::types::St| call_then(crate::check::env::traits::start_resolve_fields(g_p0.clone(), default_def_8500, true), move |resolve_fields_8482: crate::check::types::St| call_then(crate::check::types::unify::start_layer_questions(resolve_fields_8482), move |layer_questions_8466: crate::check::types::St| {
                let defaulted_p8 = layer_questions_8466;
                call_then(crate::check::passes::start_discharge_incls(g_p0.clone(), defaulted_p8.clone(), incls_before_p4.clone()), move |discharge_incls_8550: crate::check::types::St| {
                    let discharged_p9 = discharge_incls_8550;
                    prism_rtl::Turn::Finished({
                        let mut this: crate::check::types::St = discharged_p9.clone();
                        this.level = Nat::from(0u32);
                        this
                    })
                })
            })))
        }))
    }
}

/// `Start CheckDef, x`: what the function value is when passed to `@Run`.
pub fn start_check_def(g_p0: crate::check::env::G, st_p1: crate::check::types::St, d_p2: crate::check::env::Def) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckDef { g_p0, st_p1, d_p2 })
}

/// ```prism
/// DefaultDef: unbounded fn G, St -> St
/// ```
pub fn default_def(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St) -> crate::check::types::St {
    let mine_p2 = run_to_end(filter_job(st_p1.wants.clone(), {
        let st_p1 = st_p1.clone();
        Rc::new(move |p0: crate::check::types::Want| {
            let st_p1 = st_p1.clone();
            entered(once_job(move || {
                let w_p6 = p0;
                call_then(crate::check::types::recording::start_walk(st_p1.clone(), w_p6.ty.clone()), move |walk_8872: crate::check::types::Ty| match walk_8872 {
                    crate::check::types::Ty::TyFlex(n_p7) => prism_rtl::Turn::Finished(&crate::check::types::recording::info_of(&st_p1, &n_p7).level >= &Nat::from(1u32)),
                    _ => prism_rtl::Turn::Finished(true),
                })
            }))
        }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    let theirs_p3 = run_to_end(filter_job(st_p1.wants.clone(), {
        let st_p1 = st_p1.clone();
        Rc::new(move |p0: crate::check::types::Want| {
            let st_p1 = st_p1.clone();
            entered(once_job(move || {
                let w_p8 = p0;
                call_then(crate::check::types::recording::start_walk(st_p1.clone(), w_p8.ty.clone()), move |walk_9000: crate::check::types::Ty| match walk_9000 {
                    crate::check::types::Ty::TyFlex(n_p9) => prism_rtl::Turn::Finished(&crate::check::types::recording::info_of(&st_p1, &n_p9).level < &Nat::from(1u32)),
                    _ => prism_rtl::Turn::Finished(false),
                })
            }))
        }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    let st1_p4 = {
        let mut this: crate::check::types::St = st_p1.clone();
        this.wants = mine_p2.clone();
        this
    };
    let s2_p5 = crate::check::env::traits::default_wants(g_p0, &st1_p4, &Array::new());
    let mut this: crate::check::types::St = s2_p5.clone();
    this.wants = append(&theirs_p3, &this.wants);
    this
}

/// The step machine of `DefaultDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefaultDef: unbounded fn G, St -> St
/// ```
pub struct DefaultDef {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
}

impl prism_rtl::Job<crate::check::types::St> for DefaultDef {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let g_p0 = g_p0.clone();
        let st_p1 = st_p1.clone();
        call_value(filter_job(st_p1.wants.clone(), {
            let st_p1 = st_p1.clone();
            Rc::new(move |p0: crate::check::types::Want| {
                let st_p1 = st_p1.clone();
                entered(once_job(move || {
                    let w_p6 = p0;
                    call_then(crate::check::types::recording::start_walk(st_p1.clone(), w_p6.ty.clone()), move |walk_8872: crate::check::types::Ty| match walk_8872 {
                        crate::check::types::Ty::TyFlex(n_p7) => prism_rtl::Turn::Finished(&crate::check::types::recording::info_of(&st_p1, &n_p7).level >= &Nat::from(1u32)),
                        _ => prism_rtl::Turn::Finished(true),
                    })
                }))
            }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
        }), move |filter_8844: Array<crate::check::types::Want>| {
            let mine_p2 = filter_8844;
            call_value(filter_job(st_p1.wants.clone(), {
                let st_p1 = st_p1.clone();
                Rc::new(move |p0: crate::check::types::Want| {
                    let st_p1 = st_p1.clone();
                    entered(once_job(move || {
                        let w_p8 = p0;
                        call_then(crate::check::types::recording::start_walk(st_p1.clone(), w_p8.ty.clone()), move |walk_9000: crate::check::types::Ty| match walk_9000 {
                            crate::check::types::Ty::TyFlex(n_p9) => prism_rtl::Turn::Finished(&crate::check::types::recording::info_of(&st_p1, &n_p9).level < &Nat::from(1u32)),
                            _ => prism_rtl::Turn::Finished(false),
                        })
                    }))
                }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
            }), move |filter_8972: Array<crate::check::types::Want>| {
                let theirs_p3 = filter_8972;
                let st1_p4 = {
                    let mut this: crate::check::types::St = st_p1.clone();
                    this.wants = mine_p2.clone();
                    this
                };
                call_then(crate::check::env::traits::start_default_wants(g_p0.clone(), st1_p4.clone(), Array::new()), move |default_wants_9146: crate::check::types::St| {
                    let s2_p5 = default_wants_9146;
                    prism_rtl::Turn::Finished({
                        let mut this: crate::check::types::St = s2_p5.clone();
                        this.wants = append(&theirs_p3, &this.wants);
                        this
                    })
                })
            })
        })
    }
}

/// `Start DefaultDef, x`: what the function value is when passed to `@Run`.
pub fn start_default_def(g_p0: crate::check::env::G, st_p1: crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(DefaultDef { g_p0, st_p1 })
}

/// ```prism
/// CheckWidgetDef: unbounded fn Env, St, Def, WidgetDecl -> St
/// ```
pub fn check_widget_def(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, d_p2: &crate::check::env::Def, w_p3: &crate::syntax::decls::WidgetDecl) -> crate::check::types::St {
    match get(&env_p0.g.vals, &d_p2.qk) {
        Some(v_p4) => match crate::check::types::schemes::skolemize(&v_p4.scheme) {
            crate::check::types::Ty::TyAt(inner_p5, rw_p6) => {
                let env2_p7 = {
                    let mut this: crate::check::expr::Env = env_p0.clone();
                    this.scope = rw_p6;
                    this.mark = Text::lit("@");
                    this
                };
                let (t_p8, st2_p9) = crate::check::blocks::infer_widget_block(&env2_p7, st_p1, &w_p3.body);
                crate::check::types::recording::note_fn(&crate::check::types::unify::unify(&st2_p9, &*inner_p5, &t_p8, &w_p3.span), &w_p3.span, &d_p2.name, &crate::check::types::Col::CBound, &st2_p9.color)
            },
            other_pa => crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), &w_p3.span, &Text::from(format!("`{}` is declared `{}`; a widget block builds a blueprint", &d_p2.name, &crate::check::types::show_ty(st_p1, &other_pa)))),
        },
        None => {
            let (t_pb, st2_pc) = crate::check::blocks::infer_widget_block(env_p0, st_p1, &w_p3.body);
            crate::check::types::recording::note_fn(&st2_pc, &w_p3.span, &d_p2.name, &crate::check::types::Col::CBound, &st2_pc.color)
        },
    }
}

/// The step machine of `CheckWidgetDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckWidgetDef: unbounded fn Env, St, Def, WidgetDecl -> St
/// ```
pub struct CheckWidgetDef {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub d_p2: crate::check::env::Def,
    pub w_p3: crate::syntax::decls::WidgetDecl,
}

impl prism_rtl::Job<crate::check::types::St> for CheckWidgetDef {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let d_p2 = &self.d_p2;
        let w_p3 = &self.w_p3;
        match get(&env_p0.g.vals, &d_p2.qk) {
            Some(v_p4) => {
                let d_p2 = d_p2.clone();
                let env_p0 = env_p0.clone();
                let st_p1 = st_p1.clone();
                let w_p3 = w_p3.clone();
                call_then(crate::check::types::schemes::start_skolemize(v_p4.scheme.clone()), move |skolemize_9452: crate::check::types::Ty| match skolemize_9452 {
                    crate::check::types::Ty::TyAt(inner_p5, rw_p6) => {
                        let env2_p7 = {
                            let mut this: crate::check::expr::Env = env_p0.clone();
                            this.scope = rw_p6.clone();
                            this.mark = Text::lit("@");
                            this
                        };
                        call_then(crate::check::blocks::start_infer_widget_block(env2_p7.clone(), st_p1.clone(), w_p3.body.clone()), move |infer_widget_block_9622: (crate::check::types::Ty, crate::check::types::St)| {
                            let (t_p8, st2_p9) = infer_widget_block_9622;
                            call_then(crate::check::types::unify::start_unify(st2_p9.clone(), (*inner_p5).clone(), t_p8.clone(), w_p3.span.clone()), move |unify_9676: crate::check::types::St| prism_rtl::Turn::Finished(crate::check::types::recording::note_fn(&unify_9676, &w_p3.span, &d_p2.name, &crate::check::types::Col::CBound, &st2_p9.color)))
                        })
                    },
                    other_pa => call_then(crate::check::types::start_show_ty(st_p1.clone(), other_pa.clone()), move |show_ty_9809: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err(&st_p1, &Text::lit("mismatch"), &w_p3.span, &Text::from(format!("`{}` is declared `{}`; a widget block builds a blueprint", &d_p2.name, &show_ty_9809))))),
                })
            },
            None => {
                let d_p2 = d_p2.clone();
                let env_p0 = env_p0.clone();
                let st_p1 = st_p1.clone();
                let w_p3 = w_p3.clone();
                call_then(crate::check::blocks::start_infer_widget_block(env_p0.clone(), st_p1.clone(), w_p3.body.clone()), move |infer_widget_block_9898: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_pb, st2_pc) = infer_widget_block_9898;
                    prism_rtl::Turn::Finished(crate::check::types::recording::note_fn(&st2_pc, &w_p3.span, &d_p2.name, &crate::check::types::Col::CBound, &st2_pc.color))
                })
            },
        }
    }
}

/// `Start CheckWidgetDef, x`: what the function value is when passed to `@Run`.
pub fn start_check_widget_def(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, d_p2: crate::check::env::Def, w_p3: crate::syntax::decls::WidgetDecl) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckWidgetDef { env_p0, st_p1, d_p2, w_p3 })
}

/// ```prism
/// ?MethodKey: fn G, Text, Text -> ?Text
/// ```
pub fn method_key(g_p0: &crate::check::env::G, cls_p1: &Text, name_p2: &Text) -> Option<Text> {
    fold(&or(&get(&g_p0.traits, cls_p1), &crate::check::env::traits::dummy_trait()).methods, &None, &(|found_o3: &Option<Text>, k_p4: &Text| match found_o3 {
        Some(f_p5) => Some(f_p5.clone()),
        None => if (&crate::check::types::bare_name(k_p4) == name_p2) || (&crate::syntax::lexer::chars::drop_prefix(k_p4, &Text::from(format!("{}.", &or(&get(&g_p0.traits, cls_p1), &crate::check::env::traits::dummy_trait()).home))) == name_p2) {
            Some(k_p4.clone())
        } else {
            None
        },
    }))
}

/// ```prism
/// CheckMethod: unbounded fn Env, St, Def, [FnClause], Text, ImplInfo -> St
/// ```
pub fn check_method(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, d_p2: &crate::check::env::Def, clauses_p3: &Array<crate::syntax::decls::FnClause>, cls_p4: &Text, im_p5: &crate::check::env::ImplInfo) -> crate::check::types::St {
    match method_key(&env_p0.g, cls_p4, &d_p2.name) {
        None => crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), &d_p2.span, &Text::from(format!("`^{}` has no method `{}`", &crate::check::types::bare_name(cls_p4), &d_p2.name))),
        Some(mk_p6) => match get(&env_p0.g.vals, &mk_p6) {
            None => st_p1.clone(),
            Some(v_p7) => {
                let ti_p8 = or(&get(&env_p0.g.traits, cls_p4), &crate::check::env::traits::dummy_trait());
                let head_p9 = crate::check::types::schemes::subst_q(&crate::check::types::schemes::Inst { tys: fold(&im_p5.qs, &Map::new(), &(|m_pd: &Map<Text, crate::check::types::Ty>, q_pe: &Text| insert(m_pd, q_pe, &crate::check::types::Ty::TyRigid(q_pe.clone())))), rows: Map::new(), cols: Map::new() }, &im_p5.head);
                let ty_pa = crate::check::types::schemes::subst_q(&crate::check::types::schemes::Inst { tys: map_of(vec![(ti_p8.param.clone(), head_p9.clone())]), rows: Map::new(), cols: Map::new() }, &v_p7.scheme.ty);
                let sc_pb = crate::check::types::Scheme { qs: filter(&v_p7.scheme.qs, &(|q_pf: &Text| q_pf != &ti_p8.param)), plain_qs: Array::new(), rqs: v_p7.scheme.rqs.clone(), cqs: v_p7.scheme.cqs.clone(), cjoins: v_p7.scheme.cjoins.clone(), bounds: filter(&v_p7.scheme.bounds, &(|(q_pg, _): &(Text, Text)| q_pg != &ti_p8.param)), ty: ty_pa.clone() };
                let env2_pc = {
                    let mut this: crate::check::expr::Env = env_p0.clone();
                    this.givens = im_p5.bounds.clone();
                    this
                };
                crate::check::expr::lets::check_clauses(&env2_pc, st_p1, &d_p2.name, clauses_p3, &sc_pb, &d_p2.span)
            },
        },
    }
}

/// The step machine of `CheckMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckMethod: unbounded fn Env, St, Def, [FnClause], Text, ImplInfo -> St
/// ```
pub struct CheckMethod {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub d_p2: crate::check::env::Def,
    pub clauses_p3: Array<crate::syntax::decls::FnClause>,
    pub cls_p4: Text,
    pub im_p5: crate::check::env::ImplInfo,
}

impl prism_rtl::Job<crate::check::types::St> for CheckMethod {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let d_p2 = &self.d_p2;
        let clauses_p3 = &self.clauses_p3;
        let cls_p4 = &self.cls_p4;
        let im_p5 = &self.im_p5;
        match method_key(&env_p0.g, cls_p4, &d_p2.name) {
            None => prism_rtl::Turn::Finished(crate::check::types::recording::err(st_p1, &Text::lit("mismatch"), &d_p2.span, &Text::from(format!("`^{}` has no method `{}`", &crate::check::types::bare_name(cls_p4), &d_p2.name)))),
            Some(mk_p6) => match get(&env_p0.g.vals, &mk_p6) {
                None => prism_rtl::Turn::Finished(st_p1.clone()),
                Some(v_p7) => {
                    let ti_p8 = or(&get(&env_p0.g.traits, cls_p4), &crate::check::env::traits::dummy_trait());
                    let clauses_p3 = clauses_p3.clone();
                    let d_p2 = d_p2.clone();
                    let env_p0 = env_p0.clone();
                    let im_p5 = im_p5.clone();
                    let st_p1 = st_p1.clone();
                    call_then(crate::check::types::schemes::start_subst_q(crate::check::types::schemes::Inst { tys: fold(&im_p5.qs, &Map::new(), &(|m_pd: &Map<Text, crate::check::types::Ty>, q_pe: &Text| insert(m_pd, q_pe, &crate::check::types::Ty::TyRigid(q_pe.clone())))), rows: Map::new(), cols: Map::new() }, im_p5.head.clone()), move |subst_q_10769: crate::check::types::Ty| {
                        let head_p9 = subst_q_10769;
                        call_then(crate::check::types::schemes::start_subst_q(crate::check::types::schemes::Inst { tys: map_of(vec![(ti_p8.param.clone(), head_p9.clone())]), rows: Map::new(), cols: Map::new() }, v_p7.scheme.ty.clone()), move |subst_q_10887: crate::check::types::Ty| {
                            let ty_pa = subst_q_10887;
                            let sc_pb = crate::check::types::Scheme { qs: filter(&v_p7.scheme.qs, &(|q_pf: &Text| q_pf != &ti_p8.param)), plain_qs: Array::new(), rqs: v_p7.scheme.rqs.clone(), cqs: v_p7.scheme.cqs.clone(), cjoins: v_p7.scheme.cjoins.clone(), bounds: filter(&v_p7.scheme.bounds, &(|(q_pg, _): &(Text, Text)| q_pg != &ti_p8.param)), ty: ty_pa.clone() };
                            let env2_pc = {
                                let mut this: crate::check::expr::Env = env_p0.clone();
                                this.givens = im_p5.bounds.clone();
                                this
                            };
                            prism_rtl::Turn::More(Rc::new(crate::check::expr::lets::CheckClauses { env_p0: env2_pc.clone(), st_p1: st_p1.clone(), name_p2: d_p2.name.clone(), clauses_p3: clauses_p3.clone(), sc_p4: sc_pb.clone(), span_p5: d_p2.span.clone() }))
                        })
                    })
                },
            },
        }
    }
}

/// `Start CheckMethod, x`: what the function value is when passed to `@Run`.
pub fn start_check_method(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, d_p2: crate::check::env::Def, clauses_p3: Array<crate::syntax::decls::FnClause>, cls_p4: Text, im_p5: crate::check::env::ImplInfo) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckMethod { env_p0, st_p1, d_p2, clauses_p3, cls_p4, im_p5 })
}

/// ```prism
/// RootRow: unbounded fn G, St, [Text] -> ((Text, St))
/// ```
pub fn root_row(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, world_p2: &Array<Text>) -> (Text, crate::check::types::St) {
    match get(&g_p0.mods, &Text::lit("")) {
        None => (Text::lit(""), st_p1.clone()),
        Some(info_p3) => {
            let shown_p4 = crate::check::types::show_row(&info_p3.emit_rw);
            if &len(world_p2) == &Nat::from(0u32) {
                (shown_p4.clone(), st_p1.clone())
            } else {
                {
                    let missing_p5 = filter(&info_p3.emit_rw.fams, &(|f_p6: &Text| !crate::check::types::has_text(world_p2, f_p6)));
                    if &len(&missing_p5) == &Nat::from(0u32) {
                        (shown_p4.clone(), st_p1.clone())
                    } else {
                        {
                            let s0_p7 = {
                                let mut this: crate::check::types::St = st_p1.clone();
                                this.file = info_p3.file.clone();
                                this
                            };
                            (shown_p4.clone(), crate::check::types::recording::err_fix(&s0_p7, &Text::lit("world-row"), &info_p3.tree.span, &Text::from(format!("the program emits {}, which this World does not answer", &crate::syntax::lexer::chars::join(&each(&missing_p5, &(|f_p8: &Text| Text::from(format!("`{}.*`", f_p8)))), &Text::lit(", ")))), &Text::lit("host the tags it cannot answer, or run under a World that answers them")))
                        }
                    }
                }
            }
        },
    }
}

/// The step machine of `RootRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RootRow: unbounded fn G, St, [Text] -> ((Text, St))
/// ```
pub struct RootRow {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub world_p2: Array<Text>,
}

impl prism_rtl::Job<(Text, crate::check::types::St)> for RootRow {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let world_p2 = &self.world_p2;
        match get(&g_p0.mods, &Text::lit("")) {
            None => prism_rtl::Turn::Finished((Text::lit(""), st_p1.clone())),
            Some(info_p3) => {
                let shown_p4 = crate::check::types::show_row(&info_p3.emit_rw);
                if &len(world_p2) == &Nat::from(0u32) {
                    prism_rtl::Turn::Finished((shown_p4.clone(), st_p1.clone()))
                } else {
                    {
                        let missing_p5 = filter(&info_p3.emit_rw.fams, &(|f_p6: &Text| !crate::check::types::has_text(world_p2, f_p6)));
                        if &len(&missing_p5) == &Nat::from(0u32) {
                            prism_rtl::Turn::Finished((shown_p4.clone(), st_p1.clone()))
                        } else {
                            {
                                let s0_p7 = {
                                    let mut this: crate::check::types::St = st_p1.clone();
                                    this.file = info_p3.file.clone();
                                    this
                                };
                                prism_rtl::Turn::Finished((shown_p4.clone(), crate::check::types::recording::err_fix(&s0_p7, &Text::lit("world-row"), &info_p3.tree.span, &Text::from(format!("the program emits {}, which this World does not answer", &crate::syntax::lexer::chars::join(&each(&missing_p5, &(|f_p8: &Text| Text::from(format!("`{}.*`", f_p8)))), &Text::lit(", ")))), &Text::lit("host the tags it cannot answer, or run under a World that answers them"))))
                            }
                        }
                    }
                }
            },
        }
    }
}

/// `Start RootRow, x`: what the function value is when passed to `@Run`.
pub fn start_root_row(g_p0: crate::check::env::G, st_p1: crate::check::types::St, world_p2: Array<Text>) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>> {
    Rc::new(RootRow { g_p0, st_p1, world_p2 })
}
