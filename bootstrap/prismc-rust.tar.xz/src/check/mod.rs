//! The module `Check`, from `target/bootstrap/src/prismc/check/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod blocks;
pub mod env;
pub mod errors;
pub mod expr;
pub mod passes;
pub mod regex;
pub mod shrink;
pub mod typed;
pub mod types;

/// `Report`:
///
/// ```prism
/// type Report = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Report_ {
    pub text_p: Text,
    pub errors_p: Nat,
    pub root_row_p: Text,
    pub typed_p: crate::check::typed::TProgram,
}

impl Show for Report_ {
    fn show(&self, p: &mut Printer) {
        p.record("Report", &[("text", &self.text_p), ("errors", &self.errors_p), ("rootRow", &self.root_row_p), ("typed", &self.typed_p)]);
    }
}

impl ToPod for Report_ {
    fn to_pod(&self) -> Pod {
        Pod::record("Report", vec![("text", self.text_p.to_pod()), ("errors", self.errors_p.to_pod()), ("rootRow", self.root_row_p.to_pod()), ("typed", self.typed_p.to_pod())])
    }
}

impl FromPod for Report_ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Report_ { text_p: FromPod::from_pod(field(p, "text")?)?, errors_p: FromPod::from_pod(field(p, "errors")?)?, root_row_p: FromPod::from_pod(field(p, "rootRow")?)?, typed_p: FromPod::from_pod(field(p, "typed")?)? })
    }
}

/// ```prism
/// CheckProgram: unbounded fn [Src], [Module], [Text], Nat, Bool, Bool, [CDiag] -> Report
/// ```
pub fn check_program_f(srcs_p0: &Array<crate::check::errors::Src>, trees_p1: &Array<crate::syntax::Module>, world_p2: &Array<Text>, shown_p3: &Nat, recording_p4: &bool, unused_p5: &bool, pre_p6: &Array<crate::check::errors::CDiag>) -> Report_ {
    let (g0a_ph, stb_pi) = crate::check::env::build_g_f(srcs_p0, trees_p1);
    let g0_p7 = {
        let mut this: crate::check::env::G = g0a_ph.clone();
        this.prelude_from_p = shown_p3.clone();
        this
    };
    let st0_p8 = {
        let mut this: crate::check::types::St = stb_pi.clone();
        this.recording_p = *recording_p4;
        this
    };
    let (g1_pj, st1_pk) = top_lets_f(&g0_p7, &st0_p8);
    let (failed_pr, st2_ps) = crate::prelude::run_to_end(crate::prelude::fold_job(g1_pj.defs_p.clone(), (Array::new(), st1_pk.clone()), {
        let g1_pjx = g1_pj.clone();
        Rc::new(move |(p0, p1): ((Array<Text>, crate::check::types::St), crate::check::env::Def)| {
            let g1_pjxy = g1_pjx.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (bad_pl, s_pm) = p0;
                let d_pn = p1;
                {
                    let before_po = crate::prelude::len(&s_pm.diags_p);
                    crate::prelude::call_then(start_check_def_f(g1_pjxy.clone(), s_pm.clone(), d_pn.clone()), move |check_def_f_2629: crate::check::types::St| {
                        let s2_pp = check_def_f_2629;
                        let bad2_pq = if &crate::prelude::len(&s2_pp.diags_p) > &before_po {
                            crate::prelude::push(&bad_pl, &crate::check::shrink::types::own_key_f(&d_pn).qk_p)
                        } else {
                            bad_pl.clone()
                        };
                        prism_rtl::Turn::Finished((bad2_pq.clone(), s2_pp.clone()))
                    })
                }
            }))
        }) as Rc<dyn Fn(((Array<Text>, crate::check::types::St), crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<(Array<Text>, crate::check::types::St)>>>
    }));
    let st2b_p9 = {
        let mut this: crate::check::types::St = st2_ps.clone();
        this.level_p = Nat::from(0u32);
        this
    };
    let st3_pa = crate::check::env::traits::default_wants_f(&g1_pj, &st2b_p9, &Array::new());
    let good_pb = crate::prelude::filter(&g1_pj.defs_p, &(|d_pt: &crate::check::env::Def| !crate::check::types::has_text_f(&failed_pr, &crate::check::shrink::types::own_key_f(d_pt).qk_p)));
    let (st4_pu, refs_pv) = crate::check::shrink::shrink_check_f(&g1_pj, &st3_pa, &good_pb);
    let (root_row_p10, st5_p11) = root_row_f(&g1_pj, &st4_pu, world_p2);
    let warnings_pc = if *unused_p5 {
        crate::check::shrink::unused_defs_f(&good_pb, &refs_pv, shown_p3)
    } else {
        Array::new()
    };
    let reached_pd = crate::check::shrink::test_only_reached_f(srcs_p0, &g1_pj.defs_p, &refs_pv);
    let diags_pe = crate::check::errors::sort_diags_f(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::filter(&st5_p11.diags_p, &(|d_p12: &crate::check::errors::CDiag| &d_p12.file_p < shown_p3)), &warnings_pc), pre_p6), &reached_pd));
    let text_pf = crate::prelude::concat(&crate::prelude::each(&diags_pe, &(|d_p13: &crate::check::errors::CDiag| crate::check::errors::render_cdiag_f(srcs_p0, d_p13))));
    let typed_pg = if *recording_p4 {
        typed_of_f(&g1_pj, &st5_p11, shown_p3)
    } else {
        crate::check::typed::empty_typed_p()
    };
    Report_ { text_p: text_pf.clone(), errors_p: crate::prelude::len(&crate::prelude::filter(&diags_pe, &(|d_p14: &crate::check::errors::CDiag| !crate::check::errors::is_warning_f(d_p14)))), root_row_p: root_row_p10.clone(), typed_p: typed_pg.clone() }
}

/// The step machine of `CheckProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckProgram: unbounded fn [Src], [Module], [Text], Nat, Bool, Bool, [CDiag] -> Report
/// ```
pub struct CheckProgram {
    pub srcs_p0: Array<crate::check::errors::Src>,
    pub trees_p1: Array<crate::syntax::Module>,
    pub world_p2: Array<Text>,
    pub shown_p3: Nat,
    pub recording_p4: bool,
    pub unused_p5: bool,
    pub pre_p6: Array<crate::check::errors::CDiag>,
}

impl prism_rtl::Job<Report_> for CheckProgram {
    fn cycle(&self) -> prism_rtl::Turn<Report_> {
        let srcs_p0 = &self.srcs_p0;
        let trees_p1 = &self.trees_p1;
        let world_p2 = &self.world_p2;
        let shown_p3 = &self.shown_p3;
        let recording_p4 = &self.recording_p4;
        let unused_p5 = &self.unused_p5;
        let pre_p6 = &self.pre_p6;
        let pre_p6x = pre_p6.clone();
        let recording_p4x = *recording_p4;
        let shown_p3x = shown_p3.clone();
        let srcs_p0x = srcs_p0.clone();
        let trees_p1x = trees_p1.clone();
        let unused_p5x = *unused_p5;
        let world_p2x = world_p2.clone();
        crate::prelude::call_then(crate::check::env::start_build_g_f(srcs_p0x.clone(), trees_p1x.clone()), move |build_g_f_2188: (crate::check::env::G, crate::check::types::St)| {
            let (g0a_ph, stb_pi) = build_g_f_2188;
            let g0_p7 = {
                let mut this: crate::check::env::G = g0a_ph.clone();
                this.prelude_from_p = shown_p3x.clone();
                this
            };
            let st0_p8 = {
                let mut this: crate::check::types::St = stb_pi.clone();
                this.recording_p = recording_p4x;
                this
            };
            crate::prelude::call_then(start_top_lets_f(g0_p7.clone(), st0_p8.clone()), move |top_lets_f_2491: (crate::check::env::G, crate::check::types::St)| {
                let (g1_pj, st1_pk) = top_lets_f_2491;
                crate::prelude::call_value(crate::prelude::fold_job(g1_pj.defs_p.clone(), (Array::new(), st1_pk.clone()), {
                    let g1_pjx = g1_pj.clone();
                    Rc::new(move |(p0, p1): ((Array<Text>, crate::check::types::St), crate::check::env::Def)| {
                        let g1_pjxy = g1_pjx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (bad_pl, s_pm) = p0;
                            let d_pn = p1;
                            {
                                let before_po = crate::prelude::len(&s_pm.diags_p);
                                crate::prelude::call_then(start_check_def_f(g1_pjxy.clone(), s_pm.clone(), d_pn.clone()), move |check_def_f_2629: crate::check::types::St| {
                                    let s2_pp = check_def_f_2629;
                                    let bad2_pq = if &crate::prelude::len(&s2_pp.diags_p) > &before_po {
                                        crate::prelude::push(&bad_pl, &crate::check::shrink::types::own_key_f(&d_pn).qk_p)
                                    } else {
                                        bad_pl.clone()
                                    };
                                    prism_rtl::Turn::Finished((bad2_pq.clone(), s2_pp.clone()))
                                })
                            }
                        }))
                    }) as Rc<dyn Fn(((Array<Text>, crate::check::types::St), crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<(Array<Text>, crate::check::types::St)>>>
                }), move |fold_2533: (Array<Text>, crate::check::types::St)| {
                    let (failed_pr, st2_ps) = fold_2533;
                    let st2b_p9 = {
                        let mut this: crate::check::types::St = st2_ps.clone();
                        this.level_p = Nat::from(0u32);
                        this
                    };
                    crate::prelude::call_then(crate::check::env::traits::start_default_wants_f(g1_pj.clone(), st2b_p9.clone(), Array::new()), move |default_wants_f_2812: crate::check::types::St| {
                        let st3_pa = default_wants_f_2812;
                        let good_pb = crate::prelude::filter(&g1_pj.defs_p, &(|d_pt: &crate::check::env::Def| !crate::check::types::has_text_f(&failed_pr, &crate::check::shrink::types::own_key_f(d_pt).qk_p)));
                        crate::prelude::call_then(crate::check::shrink::start_shrink_check_f(g1_pj.clone(), st3_pa.clone(), good_pb.clone()), move |shrink_check_f_3083: (crate::check::types::St, Array<(Text, Array<Text>)>)| {
                            let (st4_pu, refs_pv) = shrink_check_f_3083;
                            crate::prelude::call_then(start_root_row_f(g1_pj.clone(), st4_pu.clone(), world_p2x.clone()), move |root_row_f_3136: (Text, crate::check::types::St)| {
                                let (root_row_p10, st5_p11) = root_row_f_3136;
                                let warnings_pc = if unused_p5x {
                                    crate::check::shrink::unused_defs_f(&good_pb, &refs_pv, &shown_p3x)
                                } else {
                                    Array::new()
                                };
                                let reached_pd = crate::check::shrink::test_only_reached_f(&srcs_p0x, &g1_pj.defs_p, &refs_pv);
                                let diags_pe = crate::check::errors::sort_diags_f(&crate::prelude::append(&crate::prelude::append(&crate::prelude::append(&crate::prelude::filter(&st5_p11.diags_p, &(|d_p12: &crate::check::errors::CDiag| &d_p12.file_p < &shown_p3x)), &warnings_pc), &pre_p6x), &reached_pd));
                                let text_pf = crate::prelude::concat(&crate::prelude::each(&diags_pe, &(|d_p13: &crate::check::errors::CDiag| crate::check::errors::render_cdiag_f(&srcs_p0x, d_p13))));
                                let typed_pg = if recording_p4x {
                                    typed_of_f(&g1_pj, &st5_p11, &shown_p3x)
                                } else {
                                    crate::check::typed::empty_typed_p()
                                };
                                prism_rtl::Turn::Finished(Report_ { text_p: text_pf.clone(), errors_p: crate::prelude::len(&crate::prelude::filter(&diags_pe, &(|d_p14: &crate::check::errors::CDiag| !crate::check::errors::is_warning_f(d_p14)))), root_row_p: root_row_p10.clone(), typed_p: typed_pg.clone() })
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start CheckProgram, x`: what the function value is when passed to `@Run`.
pub fn start_check_program_f(srcs_p0: Array<crate::check::errors::Src>, trees_p1: Array<crate::syntax::Module>, world_p2: Array<Text>, shown_p3: Nat, recording_p4: bool, unused_p5: bool, pre_p6: Array<crate::check::errors::CDiag>) -> Rc<dyn prism_rtl::Job<Report_>> {
    Rc::new(CheckProgram { srcs_p0, trees_p1, world_p2, shown_p3, recording_p4, unused_p5, pre_p6 })
}

/// ```prism
/// TypedOf: unbounded fn G, St, Nat -> TProgram
/// ```
pub fn typed_of_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, shown_p2: &Nat) -> crate::check::typed::TProgram {
    let z_p3 = crate::check::types::recording::zonk_typed_f(st_p1);
    let vals_p4 = crate::prelude::filter(&crate::prelude::values(&g_p0.vals_p), &(|v_p5: &crate::check::env::ValInfo| ((&v_p5.file_p < shown_p2) && (&v_p5.sort_p != &Text::lit("builtin"))) && (&crate::prelude::or(&crate::prelude::get(&g_p0.mods_p, &v_p5.home_p), &crate::check::env::reading::dummy_mod_p()).file_p == &v_p5.file_p)));
    let mut this: crate::check::typed::TProgram = z_p3.clone();
    this.defs_p = crate::prelude::run_to_end(crate::prelude::each_job(vals_p4.clone(), {
        let st_p1x = st_p1.clone();
        Rc::new(move |p0: crate::check::env::ValInfo| {
            let st_p1xy = st_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let v_p6 = p0;
                crate::prelude::call_then(start_zonk_scheme_f(st_p1xy.clone(), v_p6.scheme_p.clone()), move |zonk_scheme_f_4112: crate::check::types::Scheme| prism_rtl::Turn::Finished(crate::check::typed::DefNote { at_p: crate::check::typed::SrcAt { file_p: v_p6.file_p.clone(), span_p: v_p6.span_p.clone() }, name_p: v_p6.qk_p.clone(), scheme_p: zonk_scheme_f_4112 }))
            }))
        }) as Rc<dyn Fn(crate::check::env::ValInfo) -> Rc<dyn prism_rtl::Job<crate::check::typed::DefNote>>>
    }));
    this
}

/// The step machine of `TypedOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypedOf: unbounded fn G, St, Nat -> TProgram
/// ```
pub struct TypedOf {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub shown_p2: Nat,
}

impl prism_rtl::Job<crate::check::typed::TProgram> for TypedOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::typed::TProgram> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let shown_p2 = &self.shown_p2;
        let g_p0x = g_p0.clone();
        let shown_p2x = shown_p2.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_zonk_typed_f(st_p1x.clone()), move |zonk_typed_f_3855: crate::check::typed::TProgram| {
            let z_p3 = zonk_typed_f_3855;
            let vals_p4 = crate::prelude::filter(&crate::prelude::values(&g_p0x.vals_p), &(|v_p5: &crate::check::env::ValInfo| ((&v_p5.file_p < &shown_p2x) && (&v_p5.sort_p != &Text::lit("builtin"))) && (&crate::prelude::or(&crate::prelude::get(&g_p0x.mods_p, &v_p5.home_p), &crate::check::env::reading::dummy_mod_p()).file_p == &v_p5.file_p)));
            prism_rtl::Turn::Finished({
                let mut this: crate::check::typed::TProgram = z_p3.clone();
                this.defs_p = crate::prelude::run_to_end(crate::prelude::each_job(vals_p4.clone(), {
                    let st_p1xx = st_p1x.clone();
                    Rc::new(move |p0: crate::check::env::ValInfo| {
                        let st_p1xxy = st_p1xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let v_p6 = p0;
                            crate::prelude::call_then(start_zonk_scheme_f(st_p1xxy.clone(), v_p6.scheme_p.clone()), move |zonk_scheme_f_4112: crate::check::types::Scheme| prism_rtl::Turn::Finished(crate::check::typed::DefNote { at_p: crate::check::typed::SrcAt { file_p: v_p6.file_p.clone(), span_p: v_p6.span_p.clone() }, name_p: v_p6.qk_p.clone(), scheme_p: zonk_scheme_f_4112 }))
                        }))
                    }) as Rc<dyn Fn(crate::check::env::ValInfo) -> Rc<dyn prism_rtl::Job<crate::check::typed::DefNote>>>
                }));
                this
            })
        })
    }
}

/// `Start TypedOf, x`: what the function value is when passed to `@Run`.
pub fn start_typed_of_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, shown_p2: Nat) -> Rc<dyn prism_rtl::Job<crate::check::typed::TProgram>> {
    Rc::new(TypedOf { g_p0, st_p1, shown_p2 })
}

/// ```prism
/// ZonkScheme: unbounded fn St, Scheme -> Scheme
/// ```
pub fn zonk_scheme_f(st_p0: &crate::check::types::St, sc_p1: &crate::check::types::Scheme) -> crate::check::types::Scheme {
    let mut this: crate::check::types::Scheme = sc_p1.clone();
    this.ty_p = crate::check::types::recording::zonk_f(st_p0, &this.ty_p);
    this
}

/// The step machine of `ZonkScheme`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ZonkScheme: unbounded fn St, Scheme -> Scheme
/// ```
pub struct ZonkScheme {
    pub st_p0: crate::check::types::St,
    pub sc_p1: crate::check::types::Scheme,
}

impl prism_rtl::Job<crate::check::types::Scheme> for ZonkScheme {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Scheme> {
        let st_p0 = &self.st_p0;
        let sc_p1 = &self.sc_p1;
        prism_rtl::Turn::Finished({
            let mut this: crate::check::types::Scheme = sc_p1.clone();
            this.ty_p = crate::check::types::recording::zonk_f(st_p0, &this.ty_p);
            this
        })
    }
}

/// `Start ZonkScheme, x`: what the function value is when passed to `@Run`.
pub fn start_zonk_scheme_f(st_p0: crate::check::types::St, sc_p1: crate::check::types::Scheme) -> Rc<dyn prism_rtl::Job<crate::check::types::Scheme>> {
    Rc::new(ZonkScheme { st_p0, sc_p1 })
}

/// ```prism
/// TopLets: unbounded fn G, St -> ((G, St))
/// ```
pub fn top_lets_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St) -> (crate::check::env::G, crate::check::types::St) {
    let unsigned_p2 = crate::prelude::filter(&g_p0.defs_p, &(|d_p3: &crate::check::env::Def| is_let_def_f(d_p3) && !crate::check::env::has_key_f(&g_p0.vals_p, &d_p3.qk_p)));
    let (g1_pa, st1_pb) = crate::prelude::fold(&unsigned_p2, &(g_p0.clone(), st_p1.clone()), &(|(gg_p4, s_p5): &(crate::check::env::G, crate::check::types::St), d_p6: &crate::check::env::Def| {
        let (v_p8, s2_p9) = crate::check::types::fresh_var_f(s_p5, &false, &d_p6.name_p);
        let gg2_p7 = {
            let mut this: crate::check::env::G = gg_p4.clone();
            this.vals_p = crate::prelude::insert(&this.vals_p, &d_p6.qk_p, &crate::check::env::ValInfo { qk_p: d_p6.qk_p.clone(), scheme_p: crate::check::types::schemes::mono_f(&v_p8), sort_p: Text::lit("let"), has_sig_p: false, home_p: d_p6.home_p.clone(), file_p: d_p6.file_p.clone(), span_p: d_p6.span_p.clone() });
            this
        };
        (gg2_p7.clone(), s2_p9.clone())
    }));
    crate::prelude::run_to_end(crate::prelude::fold_job(unsigned_p2.clone(), (g1_pa.clone(), st1_pb.clone()), Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St), crate::check::env::Def)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (gg_pc, s_pd) = p0;
        let d_pe = p1;
        match &d_pe.body_p {
            crate::check::env::DefBody::DbLet(l_pf) => {
                let env_pg = def_env_f(&gg_pc, &d_pe);
                let s0_ph = {
                    let mut this: crate::check::types::St = s_pd.clone();
                    this.file_p = d_pe.file_p.clone();
                    this.level_p = Nat::from(1u32);
                    this.local_next_p = Nat::from(0u32);
                    this
                };
                let pre_pi = crate::prelude::or(&crate::prelude::get(&gg_pc.vals_p, &d_pe.qk_p), &dummy_val_p()).scheme_p.ty_p.clone();
                let l_pfx = l_pf.clone();
                crate::prelude::call_then(crate::check::expr::start_check_f(env_pg.clone(), s0_ph.clone(), l_pfx.value_p.clone(), pre_pi.clone()), move |check_f_5241: crate::check::types::St| {
                    let s1_pj = check_f_5241;
                    crate::prelude::call_then(crate::check::env::traits::start_solve_wants_f(gg_pc.clone(), s1_pj.clone(), Array::new(), false), move |solve_wants_f_5290: crate::check::types::St| {
                        let s2_pk = solve_wants_f_5290;
                        let s3_pl = {
                            let mut this: crate::check::types::St = s2_pk.clone();
                            this.level_p = Nat::from(0u32);
                            this
                        };
                        crate::prelude::call_then(crate::check::types::recording::start_zonk_f(s3_pl.clone(), pre_pi.clone()), move |zonk_f_5403: crate::check::types::Ty| {
                            let t_pm = zonk_f_5403;
                            crate::prelude::call_then(crate::check::expr::lets::start_wants_above_f(s3_pl.clone(), t_pm.clone(), crate::check::expr::is_lambda_f(&l_pfx.value_p)), move |wants_above_f_5455: (Array<Nat>, Array<(Nat, Text)>, crate::check::types::St)| {
                                let (keep_po, bounds_pp, s4_pq) = wants_above_f_5455;
                                crate::prelude::call_then(crate::check::types::schemes::start_holds_node_f(s4_pq.clone(), t_pm.clone()), move |holds_node_f_5524: bool| {
                                    let (sc_pr, s5_ps) = if holds_node_f_5524 {
                                        (crate::check::types::schemes::mono_f(&t_pm), s4_pq.clone())
                                    } else {
                                        crate::check::types::schemes::generalize_f(&s4_pq, &t_pm, &keep_po, &bounds_pp)
                                    };
                                    let gg2_pn = {
                                        let mut this: crate::check::env::G = gg_pc.clone();
                                        this.vals_p = crate::prelude::insert(&this.vals_p, &d_pe.qk_p, &crate::check::env::ValInfo { qk_p: d_pe.qk_p.clone(), scheme_p: sc_pr.clone(), sort_p: Text::lit("let"), has_sig_p: false, home_p: d_pe.home_p.clone(), file_p: d_pe.file_p.clone(), span_p: d_pe.span_p.clone() });
                                        this
                                    };
                                    crate::prelude::call_then(crate::check::types::colors::start_check_colors_f(s5_ps.clone()), move |check_colors_f_5843: crate::check::types::St| crate::prelude::call_then(crate::check::env::traits::start_resolve_fields_f(gg_pc.clone(), check_colors_f_5843, true), move |resolve_fields_f_5824: crate::check::types::St| crate::prelude::call_then(crate::check::types::unify::start_layer_questions_f(resolve_fields_f_5824), move |layer_questions_f_5808: crate::check::types::St| crate::prelude::call_then(crate::check::passes::start_discharge_incls_f(gg_pc.clone(), layer_questions_f_5808, Nat::from(0u32)), move |discharge_incls_f_5788: crate::check::types::St| prism_rtl::Turn::Finished((gg2_pn.clone(), discharge_incls_f_5788))))))
                                })
                            })
                        })
                    })
                })
            },
            _ => prism_rtl::Turn::Finished((gg_pc.clone(), s_pd.clone())),
        }
    }))) as Rc<dyn Fn(((crate::check::env::G, crate::check::types::St), crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>>>))
}

/// The step machine of `TopLets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TopLets: unbounded fn G, St -> ((G, St))
/// ```
pub struct TopLets {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
}

impl prism_rtl::Job<(crate::check::env::G, crate::check::types::St)> for TopLets {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::env::G, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let unsigned_p2 = crate::prelude::filter(&g_p0.defs_p, &(|d_p3: &crate::check::env::Def| is_let_def_f(d_p3) && !crate::check::env::has_key_f(&g_p0.vals_p, &d_p3.qk_p)));
        let (g1_pa, st1_pb) = crate::prelude::fold(&unsigned_p2, &(g_p0.clone(), st_p1.clone()), &(|(gg_p4, s_p5): &(crate::check::env::G, crate::check::types::St), d_p6: &crate::check::env::Def| {
            let (v_p8, s2_p9) = crate::check::types::fresh_var_f(s_p5, &false, &d_p6.name_p);
            let gg2_p7 = {
                let mut this: crate::check::env::G = gg_p4.clone();
                this.vals_p = crate::prelude::insert(&this.vals_p, &d_p6.qk_p, &crate::check::env::ValInfo { qk_p: d_p6.qk_p.clone(), scheme_p: crate::check::types::schemes::mono_f(&v_p8), sort_p: Text::lit("let"), has_sig_p: false, home_p: d_p6.home_p.clone(), file_p: d_p6.file_p.clone(), span_p: d_p6.span_p.clone() });
                this
            };
            (gg2_p7.clone(), s2_p9.clone())
        }));
        crate::prelude::fold_job(unsigned_p2.clone(), (g1_pa.clone(), st1_pb.clone()), Rc::new(move |(p0, p1): ((crate::check::env::G, crate::check::types::St), crate::check::env::Def)| crate::prelude::entered(crate::prelude::once_job(move || {
            let (gg_pc, s_pd) = p0;
            let d_pe = p1;
            match &d_pe.body_p {
                crate::check::env::DefBody::DbLet(l_pf) => {
                    let env_pg = def_env_f(&gg_pc, &d_pe);
                    let s0_ph = {
                        let mut this: crate::check::types::St = s_pd.clone();
                        this.file_p = d_pe.file_p.clone();
                        this.level_p = Nat::from(1u32);
                        this.local_next_p = Nat::from(0u32);
                        this
                    };
                    let pre_pi = crate::prelude::or(&crate::prelude::get(&gg_pc.vals_p, &d_pe.qk_p), &dummy_val_p()).scheme_p.ty_p.clone();
                    let l_pfx = l_pf.clone();
                    crate::prelude::call_then(crate::check::expr::start_check_f(env_pg.clone(), s0_ph.clone(), l_pfx.value_p.clone(), pre_pi.clone()), move |check_f_5241: crate::check::types::St| {
                        let s1_pj = check_f_5241;
                        crate::prelude::call_then(crate::check::env::traits::start_solve_wants_f(gg_pc.clone(), s1_pj.clone(), Array::new(), false), move |solve_wants_f_5290: crate::check::types::St| {
                            let s2_pk = solve_wants_f_5290;
                            let s3_pl = {
                                let mut this: crate::check::types::St = s2_pk.clone();
                                this.level_p = Nat::from(0u32);
                                this
                            };
                            crate::prelude::call_then(crate::check::types::recording::start_zonk_f(s3_pl.clone(), pre_pi.clone()), move |zonk_f_5403: crate::check::types::Ty| {
                                let t_pm = zonk_f_5403;
                                crate::prelude::call_then(crate::check::expr::lets::start_wants_above_f(s3_pl.clone(), t_pm.clone(), crate::check::expr::is_lambda_f(&l_pfx.value_p)), move |wants_above_f_5455: (Array<Nat>, Array<(Nat, Text)>, crate::check::types::St)| {
                                    let (keep_po, bounds_pp, s4_pq) = wants_above_f_5455;
                                    crate::prelude::call_then(crate::check::types::schemes::start_holds_node_f(s4_pq.clone(), t_pm.clone()), move |holds_node_f_5524: bool| {
                                        let (sc_pr, s5_ps) = if holds_node_f_5524 {
                                            (crate::check::types::schemes::mono_f(&t_pm), s4_pq.clone())
                                        } else {
                                            crate::check::types::schemes::generalize_f(&s4_pq, &t_pm, &keep_po, &bounds_pp)
                                        };
                                        let gg2_pn = {
                                            let mut this: crate::check::env::G = gg_pc.clone();
                                            this.vals_p = crate::prelude::insert(&this.vals_p, &d_pe.qk_p, &crate::check::env::ValInfo { qk_p: d_pe.qk_p.clone(), scheme_p: sc_pr.clone(), sort_p: Text::lit("let"), has_sig_p: false, home_p: d_pe.home_p.clone(), file_p: d_pe.file_p.clone(), span_p: d_pe.span_p.clone() });
                                            this
                                        };
                                        crate::prelude::call_then(crate::check::types::colors::start_check_colors_f(s5_ps.clone()), move |check_colors_f_5843: crate::check::types::St| crate::prelude::call_then(crate::check::env::traits::start_resolve_fields_f(gg_pc.clone(), check_colors_f_5843, true), move |resolve_fields_f_5824: crate::check::types::St| crate::prelude::call_then(crate::check::types::unify::start_layer_questions_f(resolve_fields_f_5824), move |layer_questions_f_5808: crate::check::types::St| crate::prelude::call_then(crate::check::passes::start_discharge_incls_f(gg_pc.clone(), layer_questions_f_5808, Nat::from(0u32)), move |discharge_incls_f_5788: crate::check::types::St| prism_rtl::Turn::Finished((gg2_pn.clone(), discharge_incls_f_5788))))))
                                    })
                                })
                            })
                        })
                    })
                },
                _ => prism_rtl::Turn::Finished((gg_pc.clone(), s_pd.clone())),
            }
        }))) as Rc<dyn Fn(((crate::check::env::G, crate::check::types::St), crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>>>).cycle()
    }
}

/// `Start TopLets, x`: what the function value is when passed to `@Run`.
pub fn start_top_lets_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St) -> Rc<dyn prism_rtl::Job<(crate::check::env::G, crate::check::types::St)>> {
    Rc::new(TopLets { g_p0, st_p1 })
}

/// ```prism
/// let dummyVal
/// ```
pub fn dummy_val_p() -> crate::check::env::ValInfo {
    crate::check::env::ValInfo { qk_p: Text::lit(""), scheme_p: crate::check::types::schemes::mono_f(&crate::check::types::Ty::TyErr), sort_p: Text::lit(""), has_sig_p: false, home_p: Text::lit(""), file_p: Nat::from(0u32), span_p: crate::syntax::Range { start_p: Nat::from(0u32), end_p: Nat::from(0u32) } }
}

/// ```prism
/// IsLetDef: fn Def -> Bool
/// ```
pub fn is_let_def_f(d_p0: &crate::check::env::Def) -> bool {
    match &d_p0.body_p {
        crate::check::env::DefBody::DbLet(_) => true,
        _ => false,
    }
}

/// ```prism
/// DefEnv: fn G, Def -> Env
/// ```
pub fn def_env_f(g_p0: &crate::check::env::G, d_p1: &crate::check::env::Def) -> crate::check::expr::Env {
    let info_p2 = crate::prelude::or(&crate::prelude::get(&g_p0.mods_p, &d_p1.home_p), &crate::check::env::reading::dummy_mod_p());
    let scope_p3 = match &info_p2.emit_rw_p.tail_p {
        crate::check::types::Tail::TlQ(v_p4) => crate::check::types::Rw { fams_p: info_p2.emit_rw_p.fams_p.clone(), minus_p: Array::new(), tail_p: crate::check::types::Tail::TlRigid(v_p4.clone()) },
        _ => info_p2.emit_rw_p.clone(),
    };
    crate::check::expr::Env { g_p: g_p0.clone(), home_p: d_p1.home_p.clone(), file_p: d_p1.file_p.clone(), src_p: crate::prelude::or(&crate::prelude::index(&g_p0.srcs_p, &d_p1.file_p), &crate::check::errors::mk_src_f(&Text::lit(""), &Text::lit(""))), locals_p: Map::new(), scope_p: scope_p3.clone(), givens_p: Array::new(), mark_p: Text::lit(""), in_update_p: false, def_name_p: d_p1.name_p.clone(), refine_p: Map::new(), pending_p: Array::new(), ids_p: Map::new() }
}

/// ```prism
/// CheckDef: unbounded fn G, St, Def -> St
/// ```
pub fn check_def_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, d_p2: &crate::check::env::Def) -> crate::check::types::St {
    let env_p3 = def_env_f(g_p0, d_p2);
    let incls_before_p4 = crate::prelude::len(&st_p1.incls_p);
    let s0_p5 = {
        let mut this: crate::check::types::St = st_p1.clone();
        this.file_p = d_p2.file_p.clone();
        this.level_p = Nat::from(1u32);
        this.local_next_p = Nat::from(0u32);
        this.color_p = crate::check::types::Col::CBound;
        this.color_why_p = Text::lit("");
        this.color_flex_p = Array::new();
        this.cleqs_p = Array::new();
        this
    };
    let s1_p6 = match &d_p2.body_p {
        crate::check::env::DefBody::DbFn(clauses_pa) => match crate::prelude::get(&g_p0.vals_p, &d_p2.qk_p) {
            Some(v_pb) => crate::check::expr::lets::check_clauses_f(&env_p3, &s0_p5, &d_p2.name_p, clauses_pa, &v_pb.scheme_p, &d_p2.span_p),
            None => s0_p5.clone(),
        },
        crate::check::env::DefBody::DbWidget(w_pc) => check_widget_def_f(&env_p3, &s0_p5, d_p2, w_pc),
        crate::check::env::DefBody::DbLet(l_pd) => match crate::prelude::get(&g_p0.vals_p, &d_p2.qk_p) {
            Some(v_pe) => if v_pe.has_sig_p {
                crate::check::expr::check_f(&env_p3, &s0_p5, &l_pd.value_p, &crate::check::types::schemes::skolemize_f(&v_pe.scheme_p))
            } else {
                s0_p5.clone()
            },
            None => s0_p5.clone(),
        },
        crate::check::env::DefBody::DbMethod(clauses_pf, cls_pg, im_ph) => check_method_f(&env_p3, &s0_p5, d_p2, clauses_pf, cls_pg, im_ph),
        crate::check::env::DefBody::DbDefault(clauses_pi, cls_pj) => match method_key_o(g_p0, cls_pj, &d_p2.name_p) {
            Some(mk_pk) => match crate::prelude::get(&g_p0.vals_p, &mk_pk) {
                Some(v_pl) => crate::check::expr::lets::check_clauses_f(&env_p3, &s0_p5, &d_p2.name_p, clauses_pi, &v_pl.scheme_p, &d_p2.span_p),
                None => s0_p5.clone(),
            },
            None => s0_p5.clone(),
        },
        crate::check::env::DefBody::DbCheck(c_pm) => crate::prelude::run_to_end(crate::prelude::fold_job(c_pm.lines_p.clone(), s0_p5.clone(), {
            let env_p3x = env_p3.clone();
            Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::CheckLine)| {
                let env_p3xy = env_p3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let s_pn = p0;
                    let line_po = p1;
                    crate::prelude::call_then(crate::check::expr::start_infer_f(env_p3xy.clone(), s_pn.clone(), line_po.expr_p.clone()), move |infer_f_7891: (crate::check::types::Ty, crate::check::types::St)| {
                        let (t_pp, s2_pq) = infer_f_7891;
                        match &line_po.pattern_o {
                            Some(p_pr) => {
                                let p_prx = p_pr.clone();
                                crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(env_p3xy.clone(), s2_pq.clone(), p_prx.clone(), t_pp.clone(), true), move |bind_pattern_f_8010: (crate::check::expr::Env, crate::check::types::St)| {
                                    let (_, s3_ps) = bind_pattern_f_8010;
                                    prism_rtl::Turn::Finished(s3_ps.clone())
                                })
                            },
                            None => prism_rtl::Turn::Finished(s2_pq.clone()),
                        }
                    })
                }))
            }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::decls::CheckLine)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
        })),
        crate::check::env::DefBody::DbTest(t_pt) => {
            let (bt_pu, s2_pv) = crate::check::expr::infer_f(&env_p3, &s0_p5, &t_pt.blueprint_p);
            match crate::check::types::recording::walk_f(&s2_pv, &bt_pu) {
                crate::check::types::Ty::TyAt(_, _) => s2_pv.clone(),
                crate::check::types::Ty::TyErr => s2_pv.clone(),
                other_p10 => crate::check::types::recording::err_f(&s2_pv, &Text::lit("mismatch"), &t_pt.blueprint_p.span_p, &Text::from(format!("a test builds a blueprint; this is `{}`", &crate::check::types::show_ty_f(&s2_pv, &other_p10)))),
            }
        },
    };
    let solved_p7 = crate::check::types::colors::check_colors_f(&crate::check::env::traits::solve_wants_f(g_p0, &s1_p6, &env_p3.givens_p, &false));
    let defaulted_p8 = crate::check::types::unify::layer_questions_f(&crate::check::env::traits::resolve_fields_f(g_p0, &default_def_f(g_p0, &solved_p7), &true));
    let discharged_p9 = crate::check::passes::discharge_incls_f(g_p0, &defaulted_p8, &incls_before_p4);
    let mut this: crate::check::types::St = discharged_p9.clone();
    this.level_p = Nat::from(0u32);
    this
}

/// The step machine of `CheckDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckDef: unbounded fn G, St, Def -> St
/// ```
pub struct CheckDef {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub d_p2: crate::check::env::Def,
}

impl prism_rtl::Job<crate::check::types::St> for CheckDef {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let d_p2 = &self.d_p2;
        let env_p3 = def_env_f(g_p0, d_p2);
        let incls_before_p4 = crate::prelude::len(&st_p1.incls_p);
        let s0_p5 = {
            let mut this: crate::check::types::St = st_p1.clone();
            this.file_p = d_p2.file_p.clone();
            this.level_p = Nat::from(1u32);
            this.local_next_p = Nat::from(0u32);
            this.color_p = crate::check::types::Col::CBound;
            this.color_why_p = Text::lit("");
            this.color_flex_p = Array::new();
            this.cleqs_p = Array::new();
            this
        };
        let s1_p6 = match &d_p2.body_p {
            crate::check::env::DefBody::DbFn(clauses_pa) => match crate::prelude::get(&g_p0.vals_p, &d_p2.qk_p) {
                Some(v_pb) => crate::check::expr::lets::check_clauses_f(&env_p3, &s0_p5, &d_p2.name_p, clauses_pa, &v_pb.scheme_p, &d_p2.span_p),
                None => s0_p5.clone(),
            },
            crate::check::env::DefBody::DbWidget(w_pc) => check_widget_def_f(&env_p3, &s0_p5, d_p2, w_pc),
            crate::check::env::DefBody::DbLet(l_pd) => match crate::prelude::get(&g_p0.vals_p, &d_p2.qk_p) {
                Some(v_pe) => if v_pe.has_sig_p {
                    crate::check::expr::check_f(&env_p3, &s0_p5, &l_pd.value_p, &crate::check::types::schemes::skolemize_f(&v_pe.scheme_p))
                } else {
                    s0_p5.clone()
                },
                None => s0_p5.clone(),
            },
            crate::check::env::DefBody::DbMethod(clauses_pf, cls_pg, im_ph) => check_method_f(&env_p3, &s0_p5, d_p2, clauses_pf, cls_pg, im_ph),
            crate::check::env::DefBody::DbDefault(clauses_pi, cls_pj) => match method_key_o(g_p0, cls_pj, &d_p2.name_p) {
                Some(mk_pk) => match crate::prelude::get(&g_p0.vals_p, &mk_pk) {
                    Some(v_pl) => crate::check::expr::lets::check_clauses_f(&env_p3, &s0_p5, &d_p2.name_p, clauses_pi, &v_pl.scheme_p, &d_p2.span_p),
                    None => s0_p5.clone(),
                },
                None => s0_p5.clone(),
            },
            crate::check::env::DefBody::DbCheck(c_pm) => crate::prelude::run_to_end(crate::prelude::fold_job(c_pm.lines_p.clone(), s0_p5.clone(), {
                let env_p3x = env_p3.clone();
                Rc::new(move |(p0, p1): (crate::check::types::St, crate::syntax::decls::CheckLine)| {
                    let env_p3xy = env_p3x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let s_pn = p0;
                        let line_po = p1;
                        crate::prelude::call_then(crate::check::expr::start_infer_f(env_p3xy.clone(), s_pn.clone(), line_po.expr_p.clone()), move |infer_f_7891: (crate::check::types::Ty, crate::check::types::St)| {
                            let (t_pp, s2_pq) = infer_f_7891;
                            match &line_po.pattern_o {
                                Some(p_pr) => {
                                    let p_prx = p_pr.clone();
                                    crate::prelude::call_then(crate::check::expr::patterns::start_bind_pattern_f(env_p3xy.clone(), s2_pq.clone(), p_prx.clone(), t_pp.clone(), true), move |bind_pattern_f_8010: (crate::check::expr::Env, crate::check::types::St)| {
                                        let (_, s3_ps) = bind_pattern_f_8010;
                                        prism_rtl::Turn::Finished(s3_ps.clone())
                                    })
                                },
                                None => prism_rtl::Turn::Finished(s2_pq.clone()),
                            }
                        })
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, crate::syntax::decls::CheckLine)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            })),
            crate::check::env::DefBody::DbTest(t_pt) => {
                let (bt_pu, s2_pv) = crate::check::expr::infer_f(&env_p3, &s0_p5, &t_pt.blueprint_p);
                match crate::check::types::recording::walk_f(&s2_pv, &bt_pu) {
                    crate::check::types::Ty::TyAt(_, _) => s2_pv.clone(),
                    crate::check::types::Ty::TyErr => s2_pv.clone(),
                    other_p10 => crate::check::types::recording::err_f(&s2_pv, &Text::lit("mismatch"), &t_pt.blueprint_p.span_p, &Text::from(format!("a test builds a blueprint; this is `{}`", &crate::check::types::show_ty_f(&s2_pv, &other_p10)))),
                }
            },
        };
        let g_p0x = g_p0.clone();
        crate::prelude::call_then(crate::check::env::traits::start_solve_wants_f(g_p0x.clone(), s1_p6.clone(), env_p3.givens_p.clone(), false), move |solve_wants_f_8409: crate::check::types::St| crate::prelude::call_then(crate::check::types::colors::start_check_colors_f(solve_wants_f_8409), move |check_colors_f_8396: crate::check::types::St| {
            let solved_p7 = check_colors_f_8396;
            crate::prelude::call_then(start_default_def_f(g_p0x.clone(), solved_p7.clone()), move |default_def_f_8500: crate::check::types::St| crate::prelude::call_then(crate::check::env::traits::start_resolve_fields_f(g_p0x.clone(), default_def_f_8500, true), move |resolve_fields_f_8482: crate::check::types::St| crate::prelude::call_then(crate::check::types::unify::start_layer_questions_f(resolve_fields_f_8482), move |layer_questions_f_8466: crate::check::types::St| {
                let defaulted_p8 = layer_questions_f_8466;
                crate::prelude::call_then(crate::check::passes::start_discharge_incls_f(g_p0x.clone(), defaulted_p8.clone(), incls_before_p4.clone()), move |discharge_incls_f_8550: crate::check::types::St| {
                    let discharged_p9 = discharge_incls_f_8550;
                    prism_rtl::Turn::Finished({
                        let mut this: crate::check::types::St = discharged_p9.clone();
                        this.level_p = Nat::from(0u32);
                        this
                    })
                })
            })))
        }))
    }
}

/// `Start CheckDef, x`: what the function value is when passed to `@Run`.
pub fn start_check_def_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, d_p2: crate::check::env::Def) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckDef { g_p0, st_p1, d_p2 })
}

/// ```prism
/// DefaultDef: unbounded fn G, St -> St
/// ```
pub fn default_def_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St) -> crate::check::types::St {
    let mine_p2 = crate::prelude::run_to_end(crate::prelude::filter_job(st_p1.wants_p.clone(), {
        let st_p1x = st_p1.clone();
        Rc::new(move |p0: crate::check::types::Want| {
            let st_p1xy = st_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let w_p6 = p0;
                crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1xy.clone(), w_p6.ty_p.clone()), move |walk_f_8872: crate::check::types::Ty| match walk_f_8872 {
                    crate::check::types::Ty::TyFlex(n_p7) => prism_rtl::Turn::Finished(&crate::check::types::recording::info_of_f(&st_p1xy, &n_p7).level_p >= &Nat::from(1u32)),
                    _ => prism_rtl::Turn::Finished(true),
                })
            }))
        }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    let theirs_p3 = crate::prelude::run_to_end(crate::prelude::filter_job(st_p1.wants_p.clone(), {
        let st_p1x = st_p1.clone();
        Rc::new(move |p0: crate::check::types::Want| {
            let st_p1xy = st_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let w_p8 = p0;
                crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1xy.clone(), w_p8.ty_p.clone()), move |walk_f_9000: crate::check::types::Ty| match walk_f_9000 {
                    crate::check::types::Ty::TyFlex(n_p9) => prism_rtl::Turn::Finished(&crate::check::types::recording::info_of_f(&st_p1xy, &n_p9).level_p < &Nat::from(1u32)),
                    _ => prism_rtl::Turn::Finished(false),
                })
            }))
        }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    let st1_p4 = {
        let mut this: crate::check::types::St = st_p1.clone();
        this.wants_p = mine_p2.clone();
        this
    };
    let s2_p5 = crate::check::env::traits::default_wants_f(g_p0, &st1_p4, &Array::new());
    let mut this: crate::check::types::St = s2_p5.clone();
    this.wants_p = crate::prelude::append(&theirs_p3, &this.wants_p);
    this
}

/// The step machine of `DefaultDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefaultDef: unbounded fn G, St -> St
/// ```
pub struct DefaultDef {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
}

impl prism_rtl::Job<crate::check::types::St> for DefaultDef {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let g_p0x = g_p0.clone();
        let st_p1x = st_p1.clone();
        crate::prelude::call_value(crate::prelude::filter_job(st_p1x.wants_p.clone(), {
            let st_p1xx = st_p1x.clone();
            Rc::new(move |p0: crate::check::types::Want| {
                let st_p1xxy = st_p1xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let w_p6 = p0;
                    crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1xxy.clone(), w_p6.ty_p.clone()), move |walk_f_8872: crate::check::types::Ty| match walk_f_8872 {
                        crate::check::types::Ty::TyFlex(n_p7) => prism_rtl::Turn::Finished(&crate::check::types::recording::info_of_f(&st_p1xxy, &n_p7).level_p >= &Nat::from(1u32)),
                        _ => prism_rtl::Turn::Finished(true),
                    })
                }))
            }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
        }), move |filter_8844: Array<crate::check::types::Want>| {
            let mine_p2 = filter_8844;
            crate::prelude::call_value(crate::prelude::filter_job(st_p1x.wants_p.clone(), {
                let st_p1xx = st_p1x.clone();
                Rc::new(move |p0: crate::check::types::Want| {
                    let st_p1xxy = st_p1xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let w_p8 = p0;
                        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1xxy.clone(), w_p8.ty_p.clone()), move |walk_f_9000: crate::check::types::Ty| match walk_f_9000 {
                            crate::check::types::Ty::TyFlex(n_p9) => prism_rtl::Turn::Finished(&crate::check::types::recording::info_of_f(&st_p1xxy, &n_p9).level_p < &Nat::from(1u32)),
                            _ => prism_rtl::Turn::Finished(false),
                        })
                    }))
                }) as Rc<dyn Fn(crate::check::types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
            }), move |filter_8972: Array<crate::check::types::Want>| {
                let theirs_p3 = filter_8972;
                let st1_p4 = {
                    let mut this: crate::check::types::St = st_p1x.clone();
                    this.wants_p = mine_p2.clone();
                    this
                };
                crate::prelude::call_then(crate::check::env::traits::start_default_wants_f(g_p0x.clone(), st1_p4.clone(), Array::new()), move |default_wants_f_9146: crate::check::types::St| {
                    let s2_p5 = default_wants_f_9146;
                    prism_rtl::Turn::Finished({
                        let mut this: crate::check::types::St = s2_p5.clone();
                        this.wants_p = crate::prelude::append(&theirs_p3, &this.wants_p);
                        this
                    })
                })
            })
        })
    }
}

/// `Start DefaultDef, x`: what the function value is when passed to `@Run`.
pub fn start_default_def_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(DefaultDef { g_p0, st_p1 })
}

/// ```prism
/// CheckWidgetDef: unbounded fn Env, St, Def, WidgetDecl -> St
/// ```
pub fn check_widget_def_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, d_p2: &crate::check::env::Def, w_p3: &crate::syntax::decls::WidgetDecl) -> crate::check::types::St {
    match crate::prelude::get(&env_p0.g_p.vals_p, &d_p2.qk_p) {
        Some(v_p4) => match crate::check::types::schemes::skolemize_f(&v_p4.scheme_p) {
            crate::check::types::Ty::TyAt(inner_p5, rw_p6) => {
                let env2_p7 = {
                    let mut this: crate::check::expr::Env = env_p0.clone();
                    this.scope_p = rw_p6;
                    this.mark_p = Text::lit("@");
                    this
                };
                let (t_p8, st2_p9) = crate::check::blocks::infer_widget_block_f(&env2_p7, st_p1, &w_p3.body_p);
                crate::check::types::recording::note_fn_f(&crate::check::types::unify::unify_f(&st2_p9, &*inner_p5, &t_p8, &w_p3.span_p), &w_p3.span_p, &d_p2.name_p, &crate::check::types::Col::CBound, &st2_p9.color_p)
            },
            other_pa => crate::check::types::recording::err_f(st_p1, &Text::lit("mismatch"), &w_p3.span_p, &Text::from(format!("`{}` is declared `{}`; a widget block builds a blueprint", &d_p2.name_p, &crate::check::types::show_ty_f(st_p1, &other_pa)))),
        },
        None => {
            let (t_pb, st2_pc) = crate::check::blocks::infer_widget_block_f(env_p0, st_p1, &w_p3.body_p);
            crate::check::types::recording::note_fn_f(&st2_pc, &w_p3.span_p, &d_p2.name_p, &crate::check::types::Col::CBound, &st2_pc.color_p)
        },
    }
}

/// The step machine of `CheckWidgetDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckWidgetDef: unbounded fn Env, St, Def, WidgetDecl -> St
/// ```
pub struct CheckWidgetDef {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub d_p2: crate::check::env::Def,
    pub w_p3: crate::syntax::decls::WidgetDecl,
}

impl prism_rtl::Job<crate::check::types::St> for CheckWidgetDef {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let d_p2 = &self.d_p2;
        let w_p3 = &self.w_p3;
        match crate::prelude::get(&env_p0.g_p.vals_p, &d_p2.qk_p) {
            Some(v_p4) => {
                let d_p2x = d_p2.clone();
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                let w_p3x = w_p3.clone();
                crate::prelude::call_then(crate::check::types::schemes::start_skolemize_f(v_p4.scheme_p.clone()), move |skolemize_f_9452: crate::check::types::Ty| match skolemize_f_9452 {
                    crate::check::types::Ty::TyAt(inner_p5, rw_p6) => {
                        let env2_p7 = {
                            let mut this: crate::check::expr::Env = env_p0x.clone();
                            this.scope_p = rw_p6.clone();
                            this.mark_p = Text::lit("@");
                            this
                        };
                        crate::prelude::call_then(crate::check::blocks::start_infer_widget_block_f(env2_p7.clone(), st_p1x.clone(), w_p3x.body_p.clone()), move |infer_widget_block_f_9622: (crate::check::types::Ty, crate::check::types::St)| {
                            let (t_p8, st2_p9) = infer_widget_block_f_9622;
                            crate::prelude::call_then(crate::check::types::unify::start_unify_f(st2_p9.clone(), (*inner_p5).clone(), t_p8.clone(), w_p3x.span_p.clone()), move |unify_f_9676: crate::check::types::St| prism_rtl::Turn::Finished(crate::check::types::recording::note_fn_f(&unify_f_9676, &w_p3x.span_p, &d_p2x.name_p, &crate::check::types::Col::CBound, &st2_p9.color_p)))
                        })
                    },
                    other_pa => crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x.clone(), other_pa.clone()), move |show_ty_f_9809: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&st_p1x, &Text::lit("mismatch"), &w_p3x.span_p, &Text::from(format!("`{}` is declared `{}`; a widget block builds a blueprint", &d_p2x.name_p, &show_ty_f_9809))))),
                })
            },
            None => {
                let d_p2x = d_p2.clone();
                let env_p0x = env_p0.clone();
                let st_p1x = st_p1.clone();
                let w_p3x = w_p3.clone();
                crate::prelude::call_then(crate::check::blocks::start_infer_widget_block_f(env_p0x.clone(), st_p1x.clone(), w_p3x.body_p.clone()), move |infer_widget_block_f_9898: (crate::check::types::Ty, crate::check::types::St)| {
                    let (t_pb, st2_pc) = infer_widget_block_f_9898;
                    prism_rtl::Turn::Finished(crate::check::types::recording::note_fn_f(&st2_pc, &w_p3x.span_p, &d_p2x.name_p, &crate::check::types::Col::CBound, &st2_pc.color_p))
                })
            },
        }
    }
}

/// `Start CheckWidgetDef, x`: what the function value is when passed to `@Run`.
pub fn start_check_widget_def_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, d_p2: crate::check::env::Def, w_p3: crate::syntax::decls::WidgetDecl) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckWidgetDef { env_p0, st_p1, d_p2, w_p3 })
}

/// ```prism
/// ?MethodKey: fn G, Text, Text -> ?Text
/// ```
pub fn method_key_o(g_p0: &crate::check::env::G, cls_p1: &Text, name_p2: &Text) -> Option<Text> {
    crate::prelude::fold(&crate::prelude::or(&crate::prelude::get(&g_p0.traits_p, cls_p1), &crate::check::env::traits::dummy_trait_p()).methods_p, &None, &(|found_o3: &Option<Text>, k_p4: &Text| match found_o3 {
        Some(f_p5) => Some(f_p5.clone()),
        None => if (&crate::check::types::bare_name_f(k_p4) == name_p2) || (&crate::syntax::lexer::chars::drop_prefix_f(k_p4, &Text::from(format!("{}.", &crate::prelude::or(&crate::prelude::get(&g_p0.traits_p, cls_p1), &crate::check::env::traits::dummy_trait_p()).home_p))) == name_p2) {
            Some(k_p4.clone())
        } else {
            None
        },
    }))
}

/// ```prism
/// CheckMethod: unbounded fn Env, St, Def, [FnClause], Text, ImplInfo -> St
/// ```
pub fn check_method_f(env_p0: &crate::check::expr::Env, st_p1: &crate::check::types::St, d_p2: &crate::check::env::Def, clauses_p3: &Array<crate::syntax::decls::FnClause>, cls_p4: &Text, im_p5: &crate::check::env::ImplInfo) -> crate::check::types::St {
    match method_key_o(&env_p0.g_p, cls_p4, &d_p2.name_p) {
        None => crate::check::types::recording::err_f(st_p1, &Text::lit("mismatch"), &d_p2.span_p, &Text::from(format!("`^{}` has no method `{}`", &crate::check::types::bare_name_f(cls_p4), &d_p2.name_p))),
        Some(mk_p6) => match crate::prelude::get(&env_p0.g_p.vals_p, &mk_p6) {
            None => st_p1.clone(),
            Some(v_p7) => {
                let ti_p8 = crate::prelude::or(&crate::prelude::get(&env_p0.g_p.traits_p, cls_p4), &crate::check::env::traits::dummy_trait_p());
                let head_p9 = crate::check::types::schemes::subst_q_f(&crate::check::types::schemes::Inst { tys_p: crate::prelude::fold(&im_p5.qs_p, &Map::new(), &(|m_pd: &Map<Text, crate::check::types::Ty>, q_pe: &Text| crate::prelude::insert(m_pd, q_pe, &crate::check::types::Ty::TyRigid(q_pe.clone())))), rows_p: Map::new(), cols_p: Map::new() }, &im_p5.head_p);
                let ty_pa = crate::check::types::schemes::subst_q_f(&crate::check::types::schemes::Inst { tys_p: crate::prelude::map_of(vec![(ti_p8.param_p.clone(), head_p9.clone())]), rows_p: Map::new(), cols_p: Map::new() }, &v_p7.scheme_p.ty_p);
                let sc_pb = crate::check::types::Scheme { qs_p: crate::prelude::filter(&v_p7.scheme_p.qs_p, &(|q_pf: &Text| q_pf != &ti_p8.param_p)), plain_qs_p: Array::new(), rqs_p: v_p7.scheme_p.rqs_p.clone(), cqs_p: v_p7.scheme_p.cqs_p.clone(), cjoins_p: v_p7.scheme_p.cjoins_p.clone(), bounds_p: crate::prelude::filter(&v_p7.scheme_p.bounds_p, &(|(q_pg, _): &(Text, Text)| q_pg != &ti_p8.param_p)), ty_p: ty_pa.clone() };
                let env2_pc = {
                    let mut this: crate::check::expr::Env = env_p0.clone();
                    this.givens_p = im_p5.bounds_p.clone();
                    this
                };
                crate::check::expr::lets::check_clauses_f(&env2_pc, st_p1, &d_p2.name_p, clauses_p3, &sc_pb, &d_p2.span_p)
            },
        },
    }
}

/// The step machine of `CheckMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckMethod: unbounded fn Env, St, Def, [FnClause], Text, ImplInfo -> St
/// ```
pub struct CheckMethod {
    pub env_p0: crate::check::expr::Env,
    pub st_p1: crate::check::types::St,
    pub d_p2: crate::check::env::Def,
    pub clauses_p3: Array<crate::syntax::decls::FnClause>,
    pub cls_p4: Text,
    pub im_p5: crate::check::env::ImplInfo,
}

impl prism_rtl::Job<crate::check::types::St> for CheckMethod {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let env_p0 = &self.env_p0;
        let st_p1 = &self.st_p1;
        let d_p2 = &self.d_p2;
        let clauses_p3 = &self.clauses_p3;
        let cls_p4 = &self.cls_p4;
        let im_p5 = &self.im_p5;
        match method_key_o(&env_p0.g_p, cls_p4, &d_p2.name_p) {
            None => prism_rtl::Turn::Finished(crate::check::types::recording::err_f(st_p1, &Text::lit("mismatch"), &d_p2.span_p, &Text::from(format!("`^{}` has no method `{}`", &crate::check::types::bare_name_f(cls_p4), &d_p2.name_p)))),
            Some(mk_p6) => match crate::prelude::get(&env_p0.g_p.vals_p, &mk_p6) {
                None => prism_rtl::Turn::Finished(st_p1.clone()),
                Some(v_p7) => {
                    let ti_p8 = crate::prelude::or(&crate::prelude::get(&env_p0.g_p.traits_p, cls_p4), &crate::check::env::traits::dummy_trait_p());
                    let clauses_p3x = clauses_p3.clone();
                    let d_p2x = d_p2.clone();
                    let env_p0x = env_p0.clone();
                    let im_p5x = im_p5.clone();
                    let st_p1x = st_p1.clone();
                    crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(crate::check::types::schemes::Inst { tys_p: crate::prelude::fold(&im_p5x.qs_p, &Map::new(), &(|m_pd: &Map<Text, crate::check::types::Ty>, q_pe: &Text| crate::prelude::insert(m_pd, q_pe, &crate::check::types::Ty::TyRigid(q_pe.clone())))), rows_p: Map::new(), cols_p: Map::new() }, im_p5x.head_p.clone()), move |subst_q_f_10769: crate::check::types::Ty| {
                        let head_p9 = subst_q_f_10769;
                        crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(crate::check::types::schemes::Inst { tys_p: crate::prelude::map_of(vec![(ti_p8.param_p.clone(), head_p9.clone())]), rows_p: Map::new(), cols_p: Map::new() }, v_p7.scheme_p.ty_p.clone()), move |subst_q_f_10887: crate::check::types::Ty| {
                            let ty_pa = subst_q_f_10887;
                            let sc_pb = crate::check::types::Scheme { qs_p: crate::prelude::filter(&v_p7.scheme_p.qs_p, &(|q_pf: &Text| q_pf != &ti_p8.param_p)), plain_qs_p: Array::new(), rqs_p: v_p7.scheme_p.rqs_p.clone(), cqs_p: v_p7.scheme_p.cqs_p.clone(), cjoins_p: v_p7.scheme_p.cjoins_p.clone(), bounds_p: crate::prelude::filter(&v_p7.scheme_p.bounds_p, &(|(q_pg, _): &(Text, Text)| q_pg != &ti_p8.param_p)), ty_p: ty_pa.clone() };
                            let env2_pc = {
                                let mut this: crate::check::expr::Env = env_p0x.clone();
                                this.givens_p = im_p5x.bounds_p.clone();
                                this
                            };
                            prism_rtl::Turn::More(Rc::new(crate::check::expr::lets::CheckClauses { env_p0: env2_pc.clone(), st_p1: st_p1x.clone(), name_p2: d_p2x.name_p.clone(), clauses_p3: clauses_p3x.clone(), sc_p4: sc_pb.clone(), span_p5: d_p2x.span_p.clone() }))
                        })
                    })
                },
            },
        }
    }
}

/// `Start CheckMethod, x`: what the function value is when passed to `@Run`.
pub fn start_check_method_f(env_p0: crate::check::expr::Env, st_p1: crate::check::types::St, d_p2: crate::check::env::Def, clauses_p3: Array<crate::syntax::decls::FnClause>, cls_p4: Text, im_p5: crate::check::env::ImplInfo) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckMethod { env_p0, st_p1, d_p2, clauses_p3, cls_p4, im_p5 })
}

/// ```prism
/// RootRow: unbounded fn G, St, [Text] -> ((Text, St))
/// ```
pub fn root_row_f(g_p0: &crate::check::env::G, st_p1: &crate::check::types::St, world_p2: &Array<Text>) -> (Text, crate::check::types::St) {
    match crate::prelude::get(&g_p0.mods_p, &Text::lit("")) {
        None => (Text::lit(""), st_p1.clone()),
        Some(info_p3) => {
            let shown_p4 = crate::check::types::show_row_f(&info_p3.emit_rw_p);
            if &crate::prelude::len(world_p2) == &Nat::from(0u32) {
                (shown_p4.clone(), st_p1.clone())
            } else {
                {
                    let missing_p5 = crate::prelude::filter(&info_p3.emit_rw_p.fams_p, &(|f_p6: &Text| !crate::check::types::has_text_f(world_p2, f_p6)));
                    if &crate::prelude::len(&missing_p5) == &Nat::from(0u32) {
                        (shown_p4.clone(), st_p1.clone())
                    } else {
                        {
                            let s0_p7 = {
                                let mut this: crate::check::types::St = st_p1.clone();
                                this.file_p = info_p3.file_p.clone();
                                this
                            };
                            (shown_p4.clone(), crate::check::types::recording::err_fix_f(&s0_p7, &Text::lit("world-row"), &info_p3.tree_p.span_p, &Text::from(format!("the program emits {}, which this World does not answer", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&missing_p5, &(|f_p8: &Text| Text::from(format!("`{}.*`", f_p8)))), &Text::lit(", ")))), &Text::lit("host the tags it cannot answer, or run under a World that answers them")))
                        }
                    }
                }
            }
        },
    }
}

/// The step machine of `RootRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RootRow: unbounded fn G, St, [Text] -> ((Text, St))
/// ```
pub struct RootRow {
    pub g_p0: crate::check::env::G,
    pub st_p1: crate::check::types::St,
    pub world_p2: Array<Text>,
}

impl prism_rtl::Job<(Text, crate::check::types::St)> for RootRow {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::check::types::St)> {
        let g_p0 = &self.g_p0;
        let st_p1 = &self.st_p1;
        let world_p2 = &self.world_p2;
        match crate::prelude::get(&g_p0.mods_p, &Text::lit("")) {
            None => prism_rtl::Turn::Finished((Text::lit(""), st_p1.clone())),
            Some(info_p3) => {
                let shown_p4 = crate::check::types::show_row_f(&info_p3.emit_rw_p);
                if &crate::prelude::len(world_p2) == &Nat::from(0u32) {
                    prism_rtl::Turn::Finished((shown_p4.clone(), st_p1.clone()))
                } else {
                    {
                        let missing_p5 = crate::prelude::filter(&info_p3.emit_rw_p.fams_p, &(|f_p6: &Text| !crate::check::types::has_text_f(world_p2, f_p6)));
                        if &crate::prelude::len(&missing_p5) == &Nat::from(0u32) {
                            prism_rtl::Turn::Finished((shown_p4.clone(), st_p1.clone()))
                        } else {
                            {
                                let s0_p7 = {
                                    let mut this: crate::check::types::St = st_p1.clone();
                                    this.file_p = info_p3.file_p.clone();
                                    this
                                };
                                prism_rtl::Turn::Finished((shown_p4.clone(), crate::check::types::recording::err_fix_f(&s0_p7, &Text::lit("world-row"), &info_p3.tree_p.span_p, &Text::from(format!("the program emits {}, which this World does not answer", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(&missing_p5, &(|f_p8: &Text| Text::from(format!("`{}.*`", f_p8)))), &Text::lit(", ")))), &Text::lit("host the tags it cannot answer, or run under a World that answers them"))))
                            }
                        }
                    }
                }
            },
        }
    }
}

/// `Start RootRow, x`: what the function value is when passed to `@Run`.
pub fn start_root_row_f(g_p0: crate::check::env::G, st_p1: crate::check::types::St, world_p2: Array<Text>) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>> {
    Rc::new(RootRow { g_p0, st_p1, world_p2 })
}
