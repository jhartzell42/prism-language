//! The module `Check.Types.Schemes`, from `target/bootstrap/src/prismc/check/types/schemes.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Inst`:
///
/// ```prism
/// type Inst = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Inst {
    pub tys: Map<Text, crate::check::types::Ty>,
    pub rows: Map<Text, crate::check::types::Tail>,
    pub cols: Map<Text, crate::check::types::Col>,
}

impl Show for Inst {
    fn show(&self, p: &mut Printer) {
        p.record("Inst", &[("tys", &self.tys), ("rows", &self.rows), ("cols", &self.cols)]);
    }
}

impl ToPod for Inst {
    fn to_pod(&self) -> Pod {
        Pod::record("Inst", vec![("tys", self.tys.to_pod()), ("rows", self.rows.to_pod()), ("cols", self.cols.to_pod())])
    }
}

impl FromPod for Inst {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Inst { tys: FromPod::from_pod(field(p, "tys")?)?, rows: FromPod::from_pod(field(p, "rows")?)?, cols: FromPod::from_pod(field(p, "cols")?)? })
    }
}

/// ```prism
/// Mono: fn Ty -> Scheme
/// ```
pub fn mono(t: &crate::check::types::Ty) -> crate::check::types::Scheme {
    crate::check::types::Scheme { qs: Array::new(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: t.clone() }
}

/// ```prism
/// SubstQ: unbounded fn Inst, Ty -> Ty
/// ```
pub fn subst_q(m: &Inst, t: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t {
        crate::check::types::Ty::TyQ(n) => or(&get(&m.tys, n), &crate::check::types::Ty::TyQ(n.clone())),
        crate::check::types::Ty::TyCon(n, args) => crate::check::types::Ty::TyCon(n.clone(), run_to_end(each_job(args.clone(), {
            let m = m.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let m = m.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(SubstQ { m: m.clone(), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyFn(c, ps, res) => crate::check::types::Ty::TyFn(subst_col(m, c), run_to_end(each_job(ps.clone(), {
            let m = m.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let m = m.clone();
                entered(once_job(move || {
                    let p_ = p0;
                    prism_rtl::Turn::More(Rc::new(SubstQ { m: m.clone(), t: p_.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        })), Rc::new(subst_q(m, &**res))),
        crate::check::types::Ty::TyTuple(ts) => crate::check::types::Ty::TyTuple(run_to_end(each_job(ts.clone(), {
            let m = m.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let m = m.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(SubstQ { m: m.clone(), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyArray(e) => crate::check::types::Ty::TyArray(Rc::new(subst_q(m, &**e))),
        crate::check::types::Ty::TyMap(k, v_) => crate::check::types::Ty::TyMap(Rc::new(subst_q(m, &**k)), Rc::new(subst_q(m, &**v_))),
        crate::check::types::Ty::TySig(s, i) => crate::check::types::Ty::TySig(s.clone(), Rc::new(subst_q(m, &**i))),
        crate::check::types::Ty::TyAt(i, rw) => crate::check::types::Ty::TyAt(Rc::new(subst_q(m, &**i)), subst_row_q(m, rw)),
        crate::check::types::Ty::TyElem(rw, o) => crate::check::types::Ty::TyElem(subst_row_q(m, rw), Rc::new(subst_q(m, &**o))),
        crate::check::types::Ty::TyElemAny(rw) => crate::check::types::Ty::TyElemAny(subst_row_q(m, rw)),
        crate::check::types::Ty::TyAssoc(n, a) => crate::check::types::Ty::TyAssoc(n.clone(), Rc::new(subst_q(m, &**a))),
        other => other.clone(),
    }
}

/// The step machine of `SubstQ`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SubstQ: unbounded fn Inst, Ty -> Ty
/// ```
pub struct SubstQ {
    pub m: Inst,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::Ty> for SubstQ {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let m = &self.m;
        let t = &self.t;
        match t {
            crate::check::types::Ty::TyQ(n) => prism_rtl::Turn::Finished(or(&get(&m.tys, n), &crate::check::types::Ty::TyQ(n.clone()))),
            crate::check::types::Ty::TyCon(n, args) => {
                let args = args.clone();
                let m = m.clone();
                let n = n.clone();
                call_value(each_job(args.clone(), {
                    let m = m.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let m = m.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(SubstQ { m: m.clone(), t: a.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_1157: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyCon(n.clone(), each_1157)))
            },
            crate::check::types::Ty::TyFn(c, ps, res) => {
                let c = c.clone();
                let m = m.clone();
                let ps = ps.clone();
                let res = (**res).clone();
                call_value(each_job(ps.clone(), {
                    let m = m.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let m = m.clone();
                        entered(once_job(move || {
                            let p_ = p0;
                            prism_rtl::Turn::More(Rc::new(SubstQ { m: m.clone(), t: p_.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_1230: Array<crate::check::types::Ty>| call_then(start_subst_q(m.clone(), res.clone()), move |subst_q_1259: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyFn(subst_col(&m, &c), each_1230, Rc::new(subst_q_1259)))))
            },
            crate::check::types::Ty::TyTuple(ts) => {
                let m = m.clone();
                let ts = ts.clone();
                call_value(each_job(ts.clone(), {
                    let m = m.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let m = m.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(SubstQ { m: m.clone(), t: a.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_1299: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyTuple(each_1299)))
            },
            crate::check::types::Ty::TyArray(e) => {
                let e = (**e).clone();
                let m = m.clone();
                call_then(start_subst_q(m.clone(), e.clone()), move |subst_q_1350: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyArray(Rc::new(subst_q_1350))))
            },
            crate::check::types::Ty::TyMap(k, v_) => {
                let k = (**k).clone();
                let m = m.clone();
                let v_ = (**v_).clone();
                call_then(start_subst_q(m.clone(), k.clone()), move |subst_q_1386: crate::check::types::Ty| call_then(start_subst_q(m.clone(), v_.clone()), move |subst_q_1401: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyMap(Rc::new(subst_q_1386), Rc::new(subst_q_1401)))))
            },
            crate::check::types::Ty::TySig(s, i) => {
                let i = (**i).clone();
                let m = m.clone();
                let s = s.clone();
                call_then(start_subst_q(m.clone(), i.clone()), move |subst_q_1440: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TySig(s.clone(), Rc::new(subst_q_1440))))
            },
            crate::check::types::Ty::TyAt(i, rw) => {
                let i = (**i).clone();
                let m = m.clone();
                let rw = rw.clone();
                call_then(start_subst_q(m.clone(), i.clone()), move |subst_q_1475: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyAt(Rc::new(subst_q_1475), subst_row_q(&m, &rw))))
            },
            crate::check::types::Ty::TyElem(rw, o) => {
                let m = m.clone();
                let o = (**o).clone();
                let rw = rw.clone();
                call_then(start_subst_q(m.clone(), o.clone()), move |subst_q_1552: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyElem(subst_row_q(&m, &rw), Rc::new(subst_q_1552))))
            },
            crate::check::types::Ty::TyElemAny(rw) => prism_rtl::Turn::Finished(crate::check::types::Ty::TyElemAny(subst_row_q(m, rw))),
            crate::check::types::Ty::TyAssoc(n, a) => {
                let a = (**a).clone();
                let m = m.clone();
                let n = n.clone();
                call_then(start_subst_q(m.clone(), a.clone()), move |subst_q_1641: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyAssoc(n.clone(), Rc::new(subst_q_1641))))
            },
            other => prism_rtl::Turn::Finished(other.clone()),
        }
    }
}

/// `Start SubstQ, x`: what the function value is when passed to `@Run`.
pub fn start_subst_q(m: Inst, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(SubstQ { m, t })
}

/// ```prism
/// SubstRowQ: fn Inst, Rw -> Rw
/// ```
pub fn subst_row_q(m: &Inst, rw: &crate::check::types::Rw) -> crate::check::types::Rw {
    match &rw.tail {
        crate::check::types::Tail::TlQ(n) => match get(&m.rows, n) {
            Some(t) => crate::check::types::Rw { fams: rw.fams.clone(), minus: rw.minus.clone(), tail: t.clone() },
            None => rw.clone(),
        },
        _ => rw.clone(),
    }
}

/// ```prism
/// SubstCol: fn Inst, Col -> Col
/// ```
pub fn subst_col(m: &Inst, col1: &crate::check::types::Col) -> crate::check::types::Col {
    match col1 {
        crate::check::types::Col::CQ(n) => or(&get(&m.cols, n), &crate::check::types::Col::CQ(n.clone())),
        c => c.clone(),
    }
}

/// ```prism
/// Instantiate: unbounded fn St, Scheme, Range -> ((Ty, St))
/// ```
pub fn instantiate(st: &crate::check::types::St, sc: &crate::check::types::Scheme, span: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (t, st2, _) = instantiate_with(st, sc, span, &Array::new());
    (t.clone(), st2.clone())
}

/// The step machine of `Instantiate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Instantiate: unbounded fn St, Scheme, Range -> ((Ty, St))
/// ```
pub struct Instantiate {
    pub st: crate::check::types::St,
    pub sc: crate::check::types::Scheme,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for Instantiate {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let st = &self.st;
        let sc = &self.sc;
        let span = &self.span;
        let sc = sc.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(start_instantiate_with(st.clone(), sc.clone(), span.clone(), Array::new()), move |instantiate_with_2231: (crate::check::types::Ty, crate::check::types::St, Inst)| {
            let (t, st2, _) = instantiate_with_2231;
            prism_rtl::Turn::Finished((t.clone(), st2.clone()))
        })
    }
}

/// `Start Instantiate, x`: what the function value is when passed to `@Run`.
pub fn start_instantiate(st: crate::check::types::St, sc: crate::check::types::Scheme, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(Instantiate { st, sc, span })
}

/// ```prism
/// InstantiateWith: unbounded fn St, Scheme, Range, [Ty] -> ((Ty, St, Inst))
/// ```
pub fn instantiate_with(st: &crate::check::types::St, sc: &crate::check::types::Scheme, span: &crate::syntax::Range, explicit: &Array<crate::check::types::Ty>) -> (crate::check::types::Ty, crate::check::types::St, Inst) {
    let (tys, st1) = fold(&crate::check::errors::range0(&len(&sc.qs)), &(Map::new(), st.clone()), &(|(m, s): &(Map<Text, crate::check::types::Ty>, crate::check::types::St), i: &Nat| {
        let q = or(&index(&sc.qs, i), &Text::lit(""));
        match index(explicit, i) {
            Some(g) => (insert(m, &q, &g), s.clone()),
            None => {
                let (v_, s2) = crate::check::types::fresh_var(s, &crate::check::types::has_text(&sc.plain_qs, &q), &Text::lit(""));
                (insert(m, &q, &v_), s2.clone())
            },
        }
    }));
    let nq = len(&sc.qs);
    let (rows, st2) = run_to_end(fold_job(sc.rqs.clone(), (Map::new(), st1.clone()), {
        let sc = sc.clone();
        Rc::new(move |(p0, p1): ((Map<Text, crate::check::types::Tail>, crate::check::types::St), Text)| {
            let sc = sc.clone();
            entered(once_job(move || {
                let (m, s) = p0;
                let q = p1;
                call_then(start_lacks_in(sc.ty.clone(), q.clone()), move |lacks_in_2973: Array<Text>| {
                    let (rw, s2) = crate::check::types::recording::fresh_row(&s, &lacks_in_2973);
                    prism_rtl::Turn::Finished((insert(&m, &q, &rw.tail), crate::check::types::unify::name_row(&s2, &rw.tail, &q)))
                })
            }))
        }) as Rc<dyn Fn(((Map<Text, crate::check::types::Tail>, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, crate::check::types::Tail>, crate::check::types::St)>>>
    }));
    let (cols, st2b) = fold(&sc.cqs, &(Map::new(), st2.clone()), &(|(m, s): &(Map<Text, crate::check::types::Col>, crate::check::types::St), q: &Text| {
        let (c, s2) = crate::check::types::fresh_col(s);
        (insert(m, q, &c), s2.clone())
    }));
    let inst = Inst { tys: tys.clone(), rows: rows.clone(), cols: cols.clone() };
    let st2c = run_to_end(fold_job(sc.cjoins.clone(), st2b.clone(), {
        let cols = cols.clone();
        let span = span.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, (Text, Text))| {
            let cols = cols.clone();
            let span = span.clone();
            entered(once_job(move || {
                let s = p0;
                let (lo, hi) = p1;
                prism_rtl::Turn::More(Rc::new(crate::check::types::colors::AddLeq { st: s.clone(), lo0: or(&get(&cols, &lo), &crate::check::types::Col::CBound), hi0: or(&get(&cols, &hi), &crate::check::types::Col::CBound), span: span.clone(), kind: Text::lit("arg"), name: Text::lit(""), why: Text::lit("") }))
            }))
        }) as Rc<dyn Fn((crate::check::types::St, (Text, Text))) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }));
    let st3 = fold(&sc.bounds, &st2c, &(|s: &crate::check::types::St, (v_, tr): &(Text, Text)| {
        let mut this: crate::check::types::St = s.clone();
        this.wants = push(&this.wants, &crate::check::types::Want { cls: tr.clone(), ty: or(&get(&tys, v_), &crate::check::types::Ty::TyErr), file: s.file.clone(), span: span.clone(), level: s.level.clone() });
        this
    }));
    (subst_q(&inst, &sc.ty), st3.clone(), inst.clone())
}

/// The step machine of `InstantiateWith`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InstantiateWith: unbounded fn St, Scheme, Range, [Ty] -> ((Ty, St, Inst))
/// ```
pub struct InstantiateWith {
    pub st: crate::check::types::St,
    pub sc: crate::check::types::Scheme,
    pub span: crate::syntax::Range,
    pub explicit: Array<crate::check::types::Ty>,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St, Inst)> for InstantiateWith {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St, Inst)> {
        let st = &self.st;
        let sc = &self.sc;
        let span = &self.span;
        let explicit = &self.explicit;
        let (tys, st1) = fold(&crate::check::errors::range0(&len(&sc.qs)), &(Map::new(), st.clone()), &(|(m, s): &(Map<Text, crate::check::types::Ty>, crate::check::types::St), i: &Nat| {
            let q = or(&index(&sc.qs, i), &Text::lit(""));
            match index(explicit, i) {
                Some(g) => (insert(m, &q, &g), s.clone()),
                None => {
                    let (v_, s2) = crate::check::types::fresh_var(s, &crate::check::types::has_text(&sc.plain_qs, &q), &Text::lit(""));
                    (insert(m, &q, &v_), s2.clone())
                },
            }
        }));
        let nq = len(&sc.qs);
        let sc = sc.clone();
        let span = span.clone();
        call_value(fold_job(sc.rqs.clone(), (Map::new(), st1.clone()), {
            let sc = sc.clone();
            Rc::new(move |(p0, p1): ((Map<Text, crate::check::types::Tail>, crate::check::types::St), Text)| {
                let sc = sc.clone();
                entered(once_job(move || {
                    let (m, s) = p0;
                    let q = p1;
                    call_then(start_lacks_in(sc.ty.clone(), q.clone()), move |lacks_in_2973: Array<Text>| {
                        let (rw, s2) = crate::check::types::recording::fresh_row(&s, &lacks_in_2973);
                        prism_rtl::Turn::Finished((insert(&m, &q, &rw.tail), crate::check::types::unify::name_row(&s2, &rw.tail, &q)))
                    })
                }))
            }) as Rc<dyn Fn(((Map<Text, crate::check::types::Tail>, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, crate::check::types::Tail>, crate::check::types::St)>>>
        }), move |fold_2894: (Map<Text, crate::check::types::Tail>, crate::check::types::St)| {
            let (rows, st2) = fold_2894;
            let (cols, st2b) = fold(&sc.cqs, &(Map::new(), st2.clone()), &(|(m, s): &(Map<Text, crate::check::types::Col>, crate::check::types::St), q: &Text| {
                let (c, s2) = crate::check::types::fresh_col(s);
                (insert(m, q, &c), s2.clone())
            }));
            let inst = Inst { tys: tys.clone(), rows: rows.clone(), cols: cols.clone() };
            call_value(fold_job(sc.cjoins.clone(), st2b.clone(), {
                let cols = cols.clone();
                let span = span.clone();
                Rc::new(move |(p0, p1): (crate::check::types::St, (Text, Text))| {
                    let cols = cols.clone();
                    let span = span.clone();
                    entered(once_job(move || {
                        let s = p0;
                        let (lo, hi) = p1;
                        prism_rtl::Turn::More(Rc::new(crate::check::types::colors::AddLeq { st: s.clone(), lo0: or(&get(&cols, &lo), &crate::check::types::Col::CBound), hi0: or(&get(&cols, &hi), &crate::check::types::Col::CBound), span: span.clone(), kind: Text::lit("arg"), name: Text::lit(""), why: Text::lit("") }))
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, (Text, Text))) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            }), move |fold_3252: crate::check::types::St| {
                let st2c = fold_3252;
                let st3 = fold(&sc.bounds, &st2c, &(|s: &crate::check::types::St, (v_, tr): &(Text, Text)| {
                    let mut this: crate::check::types::St = s.clone();
                    this.wants = push(&this.wants, &crate::check::types::Want { cls: tr.clone(), ty: or(&get(&tys, v_), &crate::check::types::Ty::TyErr), file: s.file.clone(), span: span.clone(), level: s.level.clone() });
                    this
                }));
                call_then(start_subst_q(inst.clone(), sc.ty.clone()), move |subst_q_3546: crate::check::types::Ty| prism_rtl::Turn::Finished((subst_q_3546, st3.clone(), inst.clone())))
            })
        })
    }
}

/// `Start InstantiateWith, x`: what the function value is when passed to `@Run`.
pub fn start_instantiate_with(st: crate::check::types::St, sc: crate::check::types::Scheme, span: crate::syntax::Range, explicit: Array<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St, Inst)>> {
    Rc::new(InstantiateWith { st, sc, span, explicit })
}

/// ```prism
/// LacksIn: unbounded fn Ty, Text -> [Text]
/// ```
pub fn lacks_in(t: &crate::check::types::Ty, q: &Text) -> Array<Text> {
    match t {
        crate::check::types::Ty::TyCon(_, args) => run_to_end(fold_job(args.clone(), Array::new(), {
            let q = q.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                let q = q.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let a = p1;
                    call_then(start_lacks_in(a.clone(), q.clone()), move |lacks_in_3833: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &lacks_in_3833)))
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        })),
        crate::check::types::Ty::TyFn(_, ps, r) => run_to_end(fold_job(ps.clone(), lacks_in(&**r, q), {
            let q = q.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                let q = q.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let a = p1;
                    call_then(start_lacks_in(a.clone(), q.clone()), move |lacks_in_3923: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &lacks_in_3923)))
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        })),
        crate::check::types::Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), Array::new(), {
            let q = q.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                let q = q.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let a = p1;
                    call_then(start_lacks_in(a.clone(), q.clone()), move |lacks_in_3995: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &lacks_in_3995)))
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        })),
        crate::check::types::Ty::TyArray(e) => lacks_in(&**e, q),
        crate::check::types::Ty::TyMap(k, v_) => crate::check::types::union_texts(&lacks_in(&**k, q), &lacks_in(&**v_, q)),
        crate::check::types::Ty::TySig(_, i) => lacks_in(&**i, q),
        crate::check::types::Ty::TyAt(i, rw) => crate::check::types::union_texts(&lacks_in(&**i, q), &row_lacks(rw, q)),
        crate::check::types::Ty::TyElem(rw, o) => crate::check::types::union_texts(&lacks_in(&**o, q), &row_lacks(rw, q)),
        crate::check::types::Ty::TyElemAny(rw) => row_lacks(rw, q),
        _ => Array::new(),
    }
}

/// The step machine of `LacksIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LacksIn: unbounded fn Ty, Text -> [Text]
/// ```
pub struct LacksIn {
    pub t: crate::check::types::Ty,
    pub q: Text,
}

impl prism_rtl::Job<Array<Text>> for LacksIn {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let t = &self.t;
        let q = &self.q;
        match t {
            crate::check::types::Ty::TyCon(_, args) => fold_job(args.clone(), Array::new(), {
                let q = q.clone();
                Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                    let q = q.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let a = p1;
                        call_then(start_lacks_in(a.clone(), q.clone()), move |lacks_in_3833: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &lacks_in_3833)))
                    }))
                }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }).cycle(),
            crate::check::types::Ty::TyFn(_, ps, r) => {
                let ps = ps.clone();
                let q = q.clone();
                let r = (**r).clone();
                call_then(start_lacks_in(r.clone(), q.clone()), move |lacks_in_3881: Array<Text>| fold_job(ps.clone(), lacks_in_3881, {
                    let q = q.clone();
                    Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                        let q = q.clone();
                        entered(once_job(move || {
                            let acc = p0;
                            let a = p1;
                            call_then(start_lacks_in(a.clone(), q.clone()), move |lacks_in_3923: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &lacks_in_3923)))
                        }))
                    }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }).cycle())
            },
            crate::check::types::Ty::TyTuple(ts) => fold_job(ts.clone(), Array::new(), {
                let q = q.clone();
                Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                    let q = q.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let a = p1;
                        call_then(start_lacks_in(a.clone(), q.clone()), move |lacks_in_3995: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &lacks_in_3995)))
                    }))
                }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }).cycle(),
            crate::check::types::Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(LacksIn { t: (**e).clone(), q: q.clone() })),
            crate::check::types::Ty::TyMap(k, v_) => {
                let k = (**k).clone();
                let q = q.clone();
                let v_ = (**v_).clone();
                call_then(start_lacks_in(k.clone(), q.clone()), move |lacks_in_4065: Array<Text>| call_then(start_lacks_in(v_.clone(), q.clone()), move |lacks_in_4081: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&lacks_in_4065, &lacks_in_4081))))
            },
            crate::check::types::Ty::TySig(_, i) => prism_rtl::Turn::More(Rc::new(LacksIn { t: (**i).clone(), q: q.clone() })),
            crate::check::types::Ty::TyAt(i, rw) => {
                let i = (**i).clone();
                let q = q.clone();
                let rw = rw.clone();
                call_then(start_lacks_in(i.clone(), q.clone()), move |lacks_in_4157: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&lacks_in_4157, &row_lacks(&rw, &q))))
            },
            crate::check::types::Ty::TyElem(rw, o) => {
                let o = (**o).clone();
                let q = q.clone();
                let rw = rw.clone();
                call_then(start_lacks_in(o.clone(), q.clone()), move |lacks_in_4219: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&lacks_in_4219, &row_lacks(&rw, &q))))
            },
            crate::check::types::Ty::TyElemAny(rw) => prism_rtl::Turn::Finished(row_lacks(rw, q)),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start LacksIn, x`: what the function value is when passed to `@Run`.
pub fn start_lacks_in(t: crate::check::types::Ty, q: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(LacksIn { t, q })
}

/// ```prism
/// RowLacks: fn Rw, Text -> [Text]
/// ```
pub fn row_lacks(rw: &crate::check::types::Rw, q: &Text) -> Array<Text> {
    if &rw.tail == &crate::check::types::Tail::TlQ(q.clone()) {
        rw.fams.clone()
    } else {
        Array::new()
    }
}

/// ```prism
/// Skolemize: unbounded fn Scheme -> Ty
/// ```
pub fn skolemize(sc: &crate::check::types::Scheme) -> crate::check::types::Ty {
    let tys = fold(&sc.qs, &Map::new(), &(|m: &Map<Text, crate::check::types::Ty>, q: &Text| insert(m, q, &crate::check::types::Ty::TyRigid(q.clone()))));
    let rows = fold(&sc.rqs, &Map::new(), &(|m: &Map<Text, crate::check::types::Tail>, q: &Text| insert(m, q, &crate::check::types::Tail::TlRigid(q.clone()))));
    let cols = fold(&sc.cqs, &Map::new(), &(|m: &Map<Text, crate::check::types::Col>, q: &Text| insert(m, q, &crate::check::types::Col::CRigid(q.clone()))));
    subst_q(&Inst { tys: tys.clone(), rows: rows.clone(), cols: cols.clone() }, &sc.ty)
}

/// The step machine of `Skolemize`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Skolemize: unbounded fn Scheme -> Ty
/// ```
pub struct Skolemize {
    pub sc: crate::check::types::Scheme,
}

impl prism_rtl::Job<crate::check::types::Ty> for Skolemize {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let sc = &self.sc;
        let tys = fold(&sc.qs, &Map::new(), &(|m: &Map<Text, crate::check::types::Ty>, q: &Text| insert(m, q, &crate::check::types::Ty::TyRigid(q.clone()))));
        let rows = fold(&sc.rqs, &Map::new(), &(|m: &Map<Text, crate::check::types::Tail>, q: &Text| insert(m, q, &crate::check::types::Tail::TlRigid(q.clone()))));
        let cols = fold(&sc.cqs, &Map::new(), &(|m: &Map<Text, crate::check::types::Col>, q: &Text| insert(m, q, &crate::check::types::Col::CRigid(q.clone()))));
        prism_rtl::Turn::More(Rc::new(SubstQ { m: Inst { tys: tys.clone(), rows: rows.clone(), cols: cols.clone() }, t: sc.ty.clone() }))
    }
}

/// `Start Skolemize, x`: what the function value is when passed to `@Run`.
pub fn start_skolemize(sc: crate::check::types::Scheme) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(Skolemize { sc })
}

/// ```prism
/// Generalize: unbounded fn St, Ty, [Nat], [((Nat, Text))] -> ((Scheme, St))
/// ```
pub fn generalize(st0: &crate::check::types::St, t: &crate::check::types::Ty, keep: &Array<Nat>, bounds: &Array<(Nat, Text)>) -> (crate::check::types::Scheme, crate::check::types::St) {
    let waiting = run_to_end(fold_job(st0.field_qs.clone(), Array::new(), {
        let st0 = st0.clone();
        Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::unify::FieldQ)| {
            let st0 = st0.clone();
            entered(once_job(move || {
                let acc = p0;
                let q = p1;
                call_then(crate::check::types::recording::start_free_vars_into(st0.clone(), acc.clone(), q.recv.clone()), move |free_vars_into_5383: Array<Nat>| prism_rtl::Turn::More(Rc::new(crate::check::types::recording::FreeVarsInto { st: st0.clone(), acc: free_vars_into_5383, t: q.result.clone() })))
            }))
        }) as Rc<dyn Fn((Array<Nat>, crate::check::types::unify::FieldQ)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
    }));
    let st = crate::check::types::colors::generalize_cols(&crate::check::types::unify::lower_levels(st0, &waiting, &st0.level));
    let z = crate::check::types::recording::zonk(&st, t);
    let vs = filter(&crate::check::types::recording::free_vars(&st, &z), &(|v_: &Nat| (&crate::check::types::recording::info_of(&st, v_).level > &st.level) && !crate::check::types::has_nat(keep, v_)));
    let cvs = filter(&crate::check::types::colors::free_col_vars(&st, &z), &(|v_: &Nat| &crate::check::types::recording::info_of(&st, v_).level > &st.level));
    let tys = fold(&vs, &Map::new(), &(|m: &Map<Nat, crate::check::types::Ty>, v_: &Nat| insert(m, v_, &crate::check::types::Ty::TyQ(Text::from(format!("'{}", v_))))));
    let cols = fold(&cvs, &Map::new(), &(|m: &Map<Nat, crate::check::types::Col>, v_: &Nat| insert(m, v_, &crate::check::types::Col::CQ(Text::from(format!("'c{}", v_))))));
    let named = subst_flex(&tys, &cols, &z);
    let plains = each(&filter(&vs, &(|v_: &Nat| crate::check::types::recording::info_of(&st, v_).plain)), &(|v_: &Nat| Text::from(format!("'{}", v_))));
    let bs = each(&filter(bounds, &(|(v_, _): &(Nat, Text)| crate::check::types::has_nat(&vs, v_))), &(|(v_, tr): &(Nat, Text)| (Text::from(format!("'{}", v_)), tr.clone())));
    let st2 = {
        let mut this: crate::check::types::St = st.clone();
        this.col_q = fold(&cvs, &this.col_q, &(|m: &Map<Nat, Text>, v_: &Nat| insert(m, v_, &Text::from(format!("'c{}", v_)))));
        this
    };
    (crate::check::types::Scheme { qs: each(&vs, &(|v_: &Nat| Text::from(format!("'{}", v_)))), plain_qs: plains.clone(), rqs: Array::new(), cqs: each(&cvs, &(|v_: &Nat| Text::from(format!("'c{}", v_)))), cjoins: Array::new(), bounds: bs.clone(), ty: named.clone() }, st2.clone())
}

/// The step machine of `Generalize`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Generalize: unbounded fn St, Ty, [Nat], [((Nat, Text))] -> ((Scheme, St))
/// ```
pub struct Generalize {
    pub st0: crate::check::types::St,
    pub t: crate::check::types::Ty,
    pub keep: Array<Nat>,
    pub bounds: Array<(Nat, Text)>,
}

impl prism_rtl::Job<(crate::check::types::Scheme, crate::check::types::St)> for Generalize {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Scheme, crate::check::types::St)> {
        let st0 = &self.st0;
        let t = &self.t;
        let keep = &self.keep;
        let bounds = &self.bounds;
        let bounds = bounds.clone();
        let keep = keep.clone();
        let st0 = st0.clone();
        let t = t.clone();
        call_value(fold_job(st0.field_qs.clone(), Array::new(), {
            let st0 = st0.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::unify::FieldQ)| {
                let st0 = st0.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let q = p1;
                    call_then(crate::check::types::recording::start_free_vars_into(st0.clone(), acc.clone(), q.recv.clone()), move |free_vars_into_5383: Array<Nat>| prism_rtl::Turn::More(Rc::new(crate::check::types::recording::FreeVarsInto { st: st0.clone(), acc: free_vars_into_5383, t: q.result.clone() })))
                }))
            }) as Rc<dyn Fn((Array<Nat>, crate::check::types::unify::FieldQ)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        }), move |fold_5330: Array<Nat>| {
            let waiting = fold_5330;
            call_then(crate::check::types::colors::start_generalize_cols(crate::check::types::unify::lower_levels(&st0, &waiting, &st0.level)), move |generalize_cols_5437: crate::check::types::St| {
                let st = generalize_cols_5437;
                call_then(crate::check::types::recording::start_zonk(st.clone(), t.clone()), move |zonk_5502: crate::check::types::Ty| {
                    let z = zonk_5502;
                    call_then(crate::check::types::recording::start_free_vars(st.clone(), z.clone()), move |free_vars_5534: Array<Nat>| {
                        let vs = filter(&free_vars_5534, &(|v_: &Nat| (&crate::check::types::recording::info_of(&st, v_).level > &st.level) && !crate::check::types::has_nat(&keep, v_)));
                        call_then(crate::check::types::colors::start_free_col_vars(st.clone(), z.clone()), move |free_col_vars_5635: Array<Nat>| {
                            let cvs = filter(&free_col_vars_5635, &(|v_: &Nat| &crate::check::types::recording::info_of(&st, v_).level > &st.level));
                            let tys = fold(&vs, &Map::new(), &(|m: &Map<Nat, crate::check::types::Ty>, v_: &Nat| insert(m, v_, &crate::check::types::Ty::TyQ(Text::from(format!("'{}", v_))))));
                            let cols = fold(&cvs, &Map::new(), &(|m: &Map<Nat, crate::check::types::Col>, v_: &Nat| insert(m, v_, &crate::check::types::Col::CQ(Text::from(format!("'c{}", v_))))));
                            call_then(start_subst_flex(tys.clone(), cols.clone(), z.clone()), move |subst_flex_5832: crate::check::types::Ty| {
                                let named = subst_flex_5832;
                                let plains = each(&filter(&vs, &(|v_: &Nat| crate::check::types::recording::info_of(&st, v_).plain)), &(|v_: &Nat| Text::from(format!("'{}", v_))));
                                let bs = each(&filter(&bounds, &(|(v_, _): &(Nat, Text)| crate::check::types::has_nat(&vs, v_))), &(|(v_, tr): &(Nat, Text)| (Text::from(format!("'{}", v_)), tr.clone())));
                                let st2 = {
                                    let mut this: crate::check::types::St = st.clone();
                                    this.col_q = fold(&cvs, &this.col_q, &(|m: &Map<Nat, Text>, v_: &Nat| insert(m, v_, &Text::from(format!("'c{}", v_)))));
                                    this
                                };
                                prism_rtl::Turn::Finished((crate::check::types::Scheme { qs: each(&vs, &(|v_: &Nat| Text::from(format!("'{}", v_)))), plain_qs: plains.clone(), rqs: Array::new(), cqs: each(&cvs, &(|v_: &Nat| Text::from(format!("'c{}", v_)))), cjoins: Array::new(), bounds: bs.clone(), ty: named.clone() }, st2.clone()))
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start Generalize, x`: what the function value is when passed to `@Run`.
pub fn start_generalize(st0: crate::check::types::St, t: crate::check::types::Ty, keep: Array<Nat>, bounds: Array<(Nat, Text)>) -> Rc<dyn prism_rtl::Job<(crate::check::types::Scheme, crate::check::types::St)>> {
    Rc::new(Generalize { st0, t, keep, bounds })
}

/// ```prism
/// SubstFlex: unbounded fn (Nat ==> Ty), (Nat ==> Col), Ty -> Ty
/// ```
pub fn subst_flex(m: &Map<Nat, crate::check::types::Ty>, cm: &Map<Nat, crate::check::types::Col>, t: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t {
        crate::check::types::Ty::TyFlex(n) => or(&get(m, n), &crate::check::types::Ty::TyFlex(n.clone())),
        crate::check::types::Ty::TyCon(n, args) => crate::check::types::Ty::TyCon(n.clone(), run_to_end(each_job(args.clone(), {
            let m = m.clone();
            let cm = cm.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let m = m.clone();
                let cm = cm.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(SubstFlex { m: m.clone(), cm: cm.clone(), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyFn(c, ps, res) => {
            let c2 = match c {
                crate::check::types::Col::CFlex(n) => or(&get(cm, n), c),
                other => other.clone(),
            };
            crate::check::types::Ty::TyFn(c2.clone(), run_to_end(each_job(ps.clone(), {
                let m = m.clone();
                let cm = cm.clone();
                Rc::new(move |p0: crate::check::types::Ty| {
                    let m = m.clone();
                    let cm = cm.clone();
                    entered(once_job(move || {
                        let p_ = p0;
                        prism_rtl::Turn::More(Rc::new(SubstFlex { m: m.clone(), cm: cm.clone(), t: p_.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
            })), Rc::new(subst_flex(m, cm, &**res)))
        },
        crate::check::types::Ty::TyTuple(ts) => crate::check::types::Ty::TyTuple(run_to_end(each_job(ts.clone(), {
            let m = m.clone();
            let cm = cm.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let m = m.clone();
                let cm = cm.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(SubstFlex { m: m.clone(), cm: cm.clone(), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyArray(e) => crate::check::types::Ty::TyArray(Rc::new(subst_flex(m, cm, &**e))),
        crate::check::types::Ty::TyMap(k, v_) => crate::check::types::Ty::TyMap(Rc::new(subst_flex(m, cm, &**k)), Rc::new(subst_flex(m, cm, &**v_))),
        crate::check::types::Ty::TySig(s, i) => crate::check::types::Ty::TySig(s.clone(), Rc::new(subst_flex(m, cm, &**i))),
        crate::check::types::Ty::TyAt(i, rw) => crate::check::types::Ty::TyAt(Rc::new(subst_flex(m, cm, &**i)), rw.clone()),
        crate::check::types::Ty::TyElem(rw, o) => crate::check::types::Ty::TyElem(rw.clone(), Rc::new(subst_flex(m, cm, &**o))),
        crate::check::types::Ty::TyAssoc(n, a) => crate::check::types::Ty::TyAssoc(n.clone(), Rc::new(subst_flex(m, cm, &**a))),
        other => other.clone(),
    }
}

/// The step machine of `SubstFlex`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SubstFlex: unbounded fn (Nat ==> Ty), (Nat ==> Col), Ty -> Ty
/// ```
pub struct SubstFlex {
    pub m: Map<Nat, crate::check::types::Ty>,
    pub cm: Map<Nat, crate::check::types::Col>,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::Ty> for SubstFlex {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let m = &self.m;
        let cm = &self.cm;
        let t = &self.t;
        match t {
            crate::check::types::Ty::TyFlex(n) => prism_rtl::Turn::Finished(or(&get(m, n), &crate::check::types::Ty::TyFlex(n.clone()))),
            crate::check::types::Ty::TyCon(n, args) => {
                let args = args.clone();
                let cm = cm.clone();
                let m = m.clone();
                let n = n.clone();
                call_value(each_job(args.clone(), {
                    let m = m.clone();
                    let cm = cm.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let m = m.clone();
                        let cm = cm.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(SubstFlex { m: m.clone(), cm: cm.clone(), t: a.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_6411: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyCon(n.clone(), each_6411)))
            },
            crate::check::types::Ty::TyFn(c, ps, res) => {
                let c2 = match c {
                    crate::check::types::Col::CFlex(n) => or(&get(cm, n), c),
                    other => other.clone(),
                };
                let cm = cm.clone();
                let m = m.clone();
                let ps = ps.clone();
                let res = (**res).clone();
                call_value(each_job(ps.clone(), {
                    let m = m.clone();
                    let cm = cm.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let m = m.clone();
                        let cm = cm.clone();
                        entered(once_job(move || {
                            let p_ = p0;
                            prism_rtl::Turn::More(Rc::new(SubstFlex { m: m.clone(), cm: cm.clone(), t: p_.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_6570: Array<crate::check::types::Ty>| call_then(start_subst_flex(m.clone(), cm.clone(), res.clone()), move |subst_flex_6606: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyFn(c2.clone(), each_6570, Rc::new(subst_flex_6606)))))
            },
            crate::check::types::Ty::TyTuple(ts) => {
                let cm = cm.clone();
                let m = m.clone();
                let ts = ts.clone();
                call_value(each_job(ts.clone(), {
                    let m = m.clone();
                    let cm = cm.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let m = m.clone();
                        let cm = cm.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(SubstFlex { m: m.clone(), cm: cm.clone(), t: a.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_6653: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyTuple(each_6653)))
            },
            crate::check::types::Ty::TyArray(e) => {
                let cm = cm.clone();
                let e = (**e).clone();
                let m = m.clone();
                call_then(start_subst_flex(m.clone(), cm.clone(), e.clone()), move |subst_flex_6711: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyArray(Rc::new(subst_flex_6711))))
            },
            crate::check::types::Ty::TyMap(k, v_) => {
                let cm = cm.clone();
                let k = (**k).clone();
                let m = m.clone();
                let v_ = (**v_).clone();
                call_then(start_subst_flex(m.clone(), cm.clone(), k.clone()), move |subst_flex_6754: crate::check::types::Ty| call_then(start_subst_flex(m.clone(), cm.clone(), v_.clone()), move |subst_flex_6776: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyMap(Rc::new(subst_flex_6754), Rc::new(subst_flex_6776)))))
            },
            crate::check::types::Ty::TySig(s, i) => {
                let cm = cm.clone();
                let i = (**i).clone();
                let m = m.clone();
                let s = s.clone();
                call_then(start_subst_flex(m.clone(), cm.clone(), i.clone()), move |subst_flex_6822: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TySig(s.clone(), Rc::new(subst_flex_6822))))
            },
            crate::check::types::Ty::TyAt(i, rw) => {
                let cm = cm.clone();
                let i = (**i).clone();
                let m = m.clone();
                let rw = rw.clone();
                call_then(start_subst_flex(m.clone(), cm.clone(), i.clone()), move |subst_flex_6864: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyAt(Rc::new(subst_flex_6864), rw.clone())))
            },
            crate::check::types::Ty::TyElem(rw, o) => {
                let cm = cm.clone();
                let m = m.clone();
                let o = (**o).clone();
                let rw = rw.clone();
                call_then(start_subst_flex(m.clone(), cm.clone(), o.clone()), move |subst_flex_6918: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyElem(rw.clone(), Rc::new(subst_flex_6918))))
            },
            crate::check::types::Ty::TyAssoc(n, a) => {
                let a = (**a).clone();
                let cm = cm.clone();
                let m = m.clone();
                let n = n.clone();
                call_then(start_subst_flex(m.clone(), cm.clone(), a.clone()), move |subst_flex_6968: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyAssoc(n.clone(), Rc::new(subst_flex_6968))))
            },
            other => prism_rtl::Turn::Finished(other.clone()),
        }
    }
}

/// `Start SubstFlex, x`: what the function value is when passed to `@Run`.
pub fn start_subst_flex(m: Map<Nat, crate::check::types::Ty>, cm: Map<Nat, crate::check::types::Col>, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(SubstFlex { m, cm, t })
}

/// ```prism
/// HoldsNode: unbounded fn St, Ty -> Bool
/// ```
pub fn holds_node(st: &crate::check::types::St, t: &crate::check::types::Ty) -> bool {
    match crate::check::types::recording::walk(st, t) {
        crate::check::types::Ty::TySig(s, i) => ((&s == &Text::lit("$")) || (&s == &Text::lit("!"))) || holds_node(st, &*i),
        crate::check::types::Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), false, {
            let st = st.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let st = st.clone();
                entered(once_job(move || {
                    let seen = p0;
                    let x = p1;
                    prism_rtl::Turn::Finished(seen || holds_node(&st, &x))
                }))
            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::check::types::Ty::TyArray(e) => holds_node(st, &*e),
        crate::check::types::Ty::TyMap(k, v_) => holds_node(st, &*k) || holds_node(st, &*v_),
        crate::check::types::Ty::TyCon(_, args) => run_to_end(fold_job(args.clone(), false, {
            let st = st.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let st = st.clone();
                entered(once_job(move || {
                    let seen = p0;
                    let x = p1;
                    prism_rtl::Turn::Finished(seen || holds_node(&st, &x))
                }))
            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        _ => false,
    }
}

/// The step machine of `HoldsNode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HoldsNode: unbounded fn St, Ty -> Bool
/// ```
pub struct HoldsNode {
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<bool> for HoldsNode {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let st = &self.st;
        let t = &self.t;
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::recording::start_walk(st.clone(), t.clone()), move |walk_7202: crate::check::types::Ty| match walk_7202 {
            crate::check::types::Ty::TySig(s, i) => prism_rtl::Turn::Finished(((&s == &Text::lit("$")) || (&s == &Text::lit("!"))) || holds_node(&st, &*i)),
            crate::check::types::Ty::TyTuple(ts) => fold_job(ts.clone(), false, {
                let st = st.clone();
                Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let seen = p0;
                        let x = p1;
                        prism_rtl::Turn::Finished(seen || holds_node(&st, &x))
                    }))
                }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            crate::check::types::Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(HoldsNode { st: st.clone(), t: (*e).clone() })),
            crate::check::types::Ty::TyMap(k, v_) => call_then(start_holds_node(st.clone(), (*k).clone()), move |holds_node_7385: bool| prism_rtl::Turn::Finished(holds_node_7385 || holds_node(&st, &*v_))),
            crate::check::types::Ty::TyCon(_, args) => fold_job(args.clone(), false, {
                let st = st.clone();
                Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let seen = p0;
                        let x = p1;
                        prism_rtl::Turn::Finished(seen || holds_node(&st, &x))
                    }))
                }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            _ => prism_rtl::Turn::Finished(false),
        })
    }
}

/// `Start HoldsNode, x`: what the function value is when passed to `@Run`.
pub fn start_holds_node(st: crate::check::types::St, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(HoldsNode { st, t })
}

/// ```prism
/// EnterLevel: fn St -> St
/// ```
pub fn enter_level(st: &crate::check::types::St) -> crate::check::types::St {
    let mut this: crate::check::types::St = st.clone();
    this.level = &this.level + &Nat::from(1u32);
    this
}

/// ```prism
/// LeaveLevel: fn St -> St
/// ```
pub fn leave_level(st: &crate::check::types::St) -> crate::check::types::St {
    let mut this: crate::check::types::St = st.clone();
    this.level = or(&(&this.level).checked_sub(&Nat::from(1u32)), &Nat::from(0u32));
    this
}
