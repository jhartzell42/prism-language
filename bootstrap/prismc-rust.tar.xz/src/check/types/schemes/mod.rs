//! The module `Check.Types.Schemes`, from `target/bootstrap/src/prismc/check/types/schemes.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `Inst`:
///
/// ```prism
/// type Inst = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Inst {
    pub tys_p: crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>,
    pub rows_p: crate::prelude::Map<crate::prelude::Text, crate::check::types::Tail>,
    pub cols_p: crate::prelude::Map<crate::prelude::Text, crate::check::types::Col>,
}

impl crate::prelude::Show for Inst {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Inst", &[("tys", &self.tys_p), ("rows", &self.rows_p), ("cols", &self.cols_p)]);
    }
}

impl crate::prelude::ToPod for Inst {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Inst", vec![("tys", self.tys_p.to_pod()), ("rows", self.rows_p.to_pod()), ("cols", self.cols_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Inst {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Inst { tys_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "tys")?)?, rows_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "rows")?)?, cols_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "cols")?)? })
    }
}

/// ```prism
/// Mono: fn Ty -> Scheme
/// ```
pub fn mono_f(t_p0: &crate::check::types::Ty) -> crate::check::types::Scheme {
    crate::check::types::Scheme { qs_p: crate::prelude::Array::new(), plain_qs_p: crate::prelude::Array::new(), rqs_p: crate::prelude::Array::new(), cqs_p: crate::prelude::Array::new(), cjoins_p: crate::prelude::Array::new(), bounds_p: crate::prelude::Array::new(), eqs_p: crate::prelude::Array::new(), ty_p: t_p0.clone() }
}

/// ```prism
/// SubstQ: unbounded fn Inst, Ty -> Ty
/// ```
pub fn subst_q_f(m_p0: &Inst, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p1 {
        crate::check::types::Ty::TyQ(n_p2) => crate::prelude::or(&crate::prelude::get(&m_p0.tys_p, n_p2), &crate::check::types::Ty::TyQ(n_p2.clone())),
        crate::check::types::Ty::TyCon(n_p3, args_p4) => crate::check::types::Ty::TyCon(n_p3.clone(), crate::prelude::run_to_end(crate::prelude::each_job(args_p4.clone(), {
            let m_p0x = m_p0.clone();
            ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                let m_p0xy = m_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p5 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(SubstQ { m_p0: m_p0xy.clone(), t_p1: a_p5.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyFn(c_p6, ps_p7, res_p8) => crate::check::types::Ty::TyFn(subst_col_f(m_p0, c_p6), crate::prelude::run_to_end(crate::prelude::each_job(ps_p7.clone(), {
            let m_p0x = m_p0.clone();
            ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                let m_p0xy = m_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let p_p9 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(SubstQ { m_p0: m_p0xy.clone(), t_p1: p_p9.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
        })), ::std::rc::Rc::new(subst_q_f(m_p0, &**res_p8))),
        crate::check::types::Ty::TyTuple(ts_pa) => crate::check::types::Ty::TyTuple(crate::prelude::run_to_end(crate::prelude::each_job(ts_pa.clone(), {
            let m_p0x = m_p0.clone();
            ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                let m_p0xy = m_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pb = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(SubstQ { m_p0: m_p0xy.clone(), t_p1: a_pb.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyArray(e_pc) => crate::check::types::Ty::TyArray(::std::rc::Rc::new(subst_q_f(m_p0, &**e_pc))),
        crate::check::types::Ty::TyMap(k_pd, v_pe) => crate::check::types::Ty::TyMap(::std::rc::Rc::new(subst_q_f(m_p0, &**k_pd)), ::std::rc::Rc::new(subst_q_f(m_p0, &**v_pe))),
        crate::check::types::Ty::TySig(s_pf, i_pg) => crate::check::types::Ty::TySig(s_pf.clone(), ::std::rc::Rc::new(subst_q_f(m_p0, &**i_pg))),
        crate::check::types::Ty::TyAt(i_ph, rw_pi) => crate::check::types::Ty::TyAt(::std::rc::Rc::new(subst_q_f(m_p0, &**i_ph)), subst_row_q_f(m_p0, rw_pi)),
        crate::check::types::Ty::TyElem(rw_pj, o_pk) => crate::check::types::Ty::TyElem(subst_row_q_f(m_p0, rw_pj), ::std::rc::Rc::new(subst_q_f(m_p0, &**o_pk))),
        crate::check::types::Ty::TyElemAny(rw_pl) => crate::check::types::Ty::TyElemAny(subst_row_q_f(m_p0, rw_pl)),
        crate::check::types::Ty::TyAssoc(tr_pm, n_pn, a_po) => crate::check::types::Ty::TyAssoc(tr_pm.clone(), n_pn.clone(), ::std::rc::Rc::new(subst_q_f(m_p0, &**a_po))),
        other_pp => other_pp.clone(),
    }
}

/// The step machine of `SubstQ`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SubstQ: unbounded fn Inst, Ty -> Ty
/// ```
pub struct SubstQ {
    pub m_p0: Inst,
    pub t_p1: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::Ty> for SubstQ {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::Ty> {
        let m_p0 = &self.m_p0;
        let t_p1 = &self.t_p1;
        match t_p1 {
            crate::check::types::Ty::TyQ(n_p2) => ::prism_rtl::Turn::Finished(crate::prelude::or(&crate::prelude::get(&m_p0.tys_p, n_p2), &crate::check::types::Ty::TyQ(n_p2.clone()))),
            crate::check::types::Ty::TyCon(n_p3, args_p4) => {
                let args_p4x = args_p4.clone();
                let m_p0x = m_p0.clone();
                let n_p3x = n_p3.clone();
                crate::prelude::call_value(crate::prelude::each_job(args_p4x.clone(), {
                    let m_p0xx = m_p0x.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                        let m_p0xxy = m_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_p5 = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(SubstQ { m_p0: m_p0xxy.clone(), t_p1: a_p5.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_1167: crate::prelude::Array<crate::check::types::Ty>| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyCon(n_p3x.clone(), each_1167)))
            },
            crate::check::types::Ty::TyFn(c_p6, ps_p7, res_p8) => {
                let c_p6x = c_p6.clone();
                let m_p0x = m_p0.clone();
                let ps_p7x = ps_p7.clone();
                let res_p8x = (**res_p8).clone();
                crate::prelude::call_value(crate::prelude::each_job(ps_p7x.clone(), {
                    let m_p0xx = m_p0x.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                        let m_p0xxy = m_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let p_p9 = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(SubstQ { m_p0: m_p0xxy.clone(), t_p1: p_p9.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_1240: crate::prelude::Array<crate::check::types::Ty>| crate::prelude::call_then(start_subst_q_f(m_p0x.clone(), res_p8x.clone()), move |subst_q_f_1269: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyFn(subst_col_f(&m_p0x, &c_p6x), each_1240, ::std::rc::Rc::new(subst_q_f_1269)))))
            },
            crate::check::types::Ty::TyTuple(ts_pa) => {
                let m_p0x = m_p0.clone();
                let ts_pax = ts_pa.clone();
                crate::prelude::call_value(crate::prelude::each_job(ts_pax.clone(), {
                    let m_p0xx = m_p0x.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                        let m_p0xxy = m_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_pb = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(SubstQ { m_p0: m_p0xxy.clone(), t_p1: a_pb.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_1309: crate::prelude::Array<crate::check::types::Ty>| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyTuple(each_1309)))
            },
            crate::check::types::Ty::TyArray(e_pc) => {
                let e_pcx = (**e_pc).clone();
                let m_p0x = m_p0.clone();
                crate::prelude::call_then(start_subst_q_f(m_p0x.clone(), e_pcx.clone()), move |subst_q_f_1360: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyArray(::std::rc::Rc::new(subst_q_f_1360))))
            },
            crate::check::types::Ty::TyMap(k_pd, v_pe) => {
                let k_pdx = (**k_pd).clone();
                let m_p0x = m_p0.clone();
                let v_pex = (**v_pe).clone();
                crate::prelude::call_then(start_subst_q_f(m_p0x.clone(), k_pdx.clone()), move |subst_q_f_1396: crate::check::types::Ty| crate::prelude::call_then(start_subst_q_f(m_p0x.clone(), v_pex.clone()), move |subst_q_f_1411: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyMap(::std::rc::Rc::new(subst_q_f_1396), ::std::rc::Rc::new(subst_q_f_1411)))))
            },
            crate::check::types::Ty::TySig(s_pf, i_pg) => {
                let i_pgx = (**i_pg).clone();
                let m_p0x = m_p0.clone();
                let s_pfx = s_pf.clone();
                crate::prelude::call_then(start_subst_q_f(m_p0x.clone(), i_pgx.clone()), move |subst_q_f_1450: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TySig(s_pfx.clone(), ::std::rc::Rc::new(subst_q_f_1450))))
            },
            crate::check::types::Ty::TyAt(i_ph, rw_pi) => {
                let i_phx = (**i_ph).clone();
                let m_p0x = m_p0.clone();
                let rw_pix = rw_pi.clone();
                crate::prelude::call_then(start_subst_q_f(m_p0x.clone(), i_phx.clone()), move |subst_q_f_1485: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyAt(::std::rc::Rc::new(subst_q_f_1485), subst_row_q_f(&m_p0x, &rw_pix))))
            },
            crate::check::types::Ty::TyElem(rw_pj, o_pk) => {
                let m_p0x = m_p0.clone();
                let o_pkx = (**o_pk).clone();
                let rw_pjx = rw_pj.clone();
                crate::prelude::call_then(start_subst_q_f(m_p0x.clone(), o_pkx.clone()), move |subst_q_f_1562: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyElem(subst_row_q_f(&m_p0x, &rw_pjx), ::std::rc::Rc::new(subst_q_f_1562))))
            },
            crate::check::types::Ty::TyElemAny(rw_pl) => ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyElemAny(subst_row_q_f(m_p0, rw_pl))),
            crate::check::types::Ty::TyAssoc(tr_pm, n_pn, a_po) => {
                let a_pox = (**a_po).clone();
                let m_p0x = m_p0.clone();
                let n_pnx = n_pn.clone();
                let tr_pmx = tr_pm.clone();
                crate::prelude::call_then(start_subst_q_f(m_p0x.clone(), a_pox.clone()), move |subst_q_f_1659: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyAssoc(tr_pmx.clone(), n_pnx.clone(), ::std::rc::Rc::new(subst_q_f_1659))))
            },
            other_pp => ::prism_rtl::Turn::Finished(other_pp.clone()),
        }
    }
}

/// `Start SubstQ, x`: what the function value is when passed to `@Run`.
pub fn start_subst_q_f(m_p0: Inst, t_p1: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>> {
    ::std::rc::Rc::new(SubstQ { m_p0, t_p1 })
}

/// ```prism
/// SubstRowQ: fn Inst, Rw -> Rw
/// ```
pub fn subst_row_q_f(m_p0: &Inst, rw_p1: &crate::check::types::Rw) -> crate::check::types::Rw {
    match &rw_p1.tail_p {
        crate::check::types::Tail::TlQ(n_p2) => match crate::prelude::get(&m_p0.rows_p, n_p2) {
            ::std::option::Option::Some(t_p3) => crate::check::types::Rw { fams_p: rw_p1.fams_p.clone(), minus_p: rw_p1.minus_p.clone(), tail_p: t_p3 },
            ::std::option::Option::None => rw_p1.clone(),
        },
        _ => rw_p1.clone(),
    }
}

/// ```prism
/// SubstCol: fn Inst, Col -> Col
/// ```
pub fn subst_col_f(m_p0: &Inst, col1: &crate::check::types::Col) -> crate::check::types::Col {
    match col1 {
        crate::check::types::Col::CQ(n_p1) => crate::prelude::or(&crate::prelude::get(&m_p0.cols_p, n_p1), &crate::check::types::Col::CQ(n_p1.clone())),
        c_p3 => c_p3.clone(),
    }
}

/// ```prism
/// Instantiate: unbounded fn St, Scheme, Range -> ((Ty, St))
/// ```
pub fn instantiate_f(st_p0: &crate::check::types::St, sc_p1: &crate::check::types::Scheme, span_p2: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (t_p3, st2_p4, _) = instantiate_with_f(st_p0, sc_p1, span_p2, &crate::prelude::Array::new());
    (t_p3.clone(), st2_p4.clone())
}

/// The step machine of `Instantiate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Instantiate: unbounded fn St, Scheme, Range -> ((Ty, St))
/// ```
pub struct Instantiate {
    pub st_p0: crate::check::types::St,
    pub sc_p1: crate::check::types::Scheme,
    pub span_p2: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for Instantiate {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let sc_p1 = &self.sc_p1;
        let span_p2 = &self.span_p2;
        let sc_p1x = sc_p1.clone();
        let span_p2x = span_p2.clone();
        let st_p0x = st_p0.clone();
        crate::prelude::call_then(start_instantiate_with_f(st_p0x.clone(), sc_p1x.clone(), span_p2x.clone(), crate::prelude::Array::new()), move |instantiate_with_f_2249: (crate::check::types::Ty, crate::check::types::St, Inst)| {
            let (t_p3, st2_p4, _) = instantiate_with_f_2249;
            ::prism_rtl::Turn::Finished((t_p3.clone(), st2_p4.clone()))
        })
    }
}

/// `Start Instantiate, x`: what the function value is when passed to `@Run`.
pub fn start_instantiate_f(st_p0: crate::check::types::St, sc_p1: crate::check::types::Scheme, span_p2: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    ::std::rc::Rc::new(Instantiate { st_p0, sc_p1, span_p2 })
}

/// ```prism
/// InstantiateWith: unbounded fn St, Scheme, Range, [Ty] -> ((Ty, St, Inst))
/// ```
pub fn instantiate_with_f(st_p0: &crate::check::types::St, sc_p1: &crate::check::types::Scheme, span_p2: &crate::syntax::Range, explicit_p3: &crate::prelude::Array<crate::check::types::Ty>) -> (crate::check::types::Ty, crate::check::types::St, Inst) {
    let (tys_pg, st1_ph) = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&sc_p1.qs_p)), &(crate::prelude::Map::new(), st_p0.clone()), &(|(m_p9, s_pa): &(crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, crate::check::types::St), i_pb: &crate::prelude::Nat| {
        let q_pc = crate::prelude::or(&crate::prelude::index(&sc_p1.qs_p, i_pb), &crate::prelude::Text::lit(""));
        match crate::prelude::index(explicit_p3, i_pb) {
            ::std::option::Option::Some(g_pd) => (crate::prelude::insert(m_p9, &q_pc, &g_pd), s_pa.clone()),
            ::std::option::Option::None => {
                let (v_pe, s2_pf) = crate::check::types::fresh_var_f(s_pa, &crate::check::types::has_text_f(&sc_p1.plain_qs_p, &q_pc), &crate::prelude::Text::lit(""));
                (crate::prelude::insert(m_p9, &q_pc, &v_pe), s2_pf.clone())
            },
        }
    }));
    let nq_p4 = crate::prelude::len(&sc_p1.qs_p);
    let (rows_pn, st2_po) = crate::prelude::run_to_end(crate::prelude::fold_job(sc_p1.rqs_p.clone(), (crate::prelude::Map::new(), st1_ph.clone()), {
        let sc_p1x = sc_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Map<crate::prelude::Text, crate::check::types::Tail>, crate::check::types::St), crate::prelude::Text)| {
            let sc_p1xy = sc_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (m_pi, s_pj) = p0;
                let q_pk = p1;
                crate::prelude::call_then(start_lacks_in_f(sc_p1xy.ty_p.clone(), q_pk.clone()), move |lacks_in_f_2991: crate::prelude::Array<crate::prelude::Text>| {
                    let (rw_pl, s2_pm) = crate::check::types::recording::fresh_row_f(&s_pj, &lacks_in_f_2991);
                    ::prism_rtl::Turn::Finished((crate::prelude::insert(&m_pi, &q_pk, &rw_pl.tail_p), crate::check::types::unify::name_row_f(&s2_pm, &rw_pl.tail_p, &q_pk)))
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Map<crate::prelude::Text, crate::check::types::Tail>, crate::check::types::St), crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Map<crate::prelude::Text, crate::check::types::Tail>, crate::check::types::St)>>>
    }));
    let (cols_pu, st2b_pv) = crate::prelude::fold(&sc_p1.cqs_p, &(crate::prelude::Map::new(), st2_po.clone()), &(|(m_pp, s_pq): &(crate::prelude::Map<crate::prelude::Text, crate::check::types::Col>, crate::check::types::St), q_pr: &crate::prelude::Text| {
        let (c_ps, s2_pt) = crate::check::types::fresh_col_f(s_pq);
        (crate::prelude::insert(m_pp, q_pr, &c_ps), s2_pt.clone())
    }));
    let inst_p5 = Inst { tys_p: tys_pg.clone(), rows_p: rows_pn.clone(), cols_p: cols_pu.clone() };
    let st2c_p6 = crate::prelude::run_to_end(crate::prelude::fold_job(sc_p1.cjoins_p.clone(), st2b_pv.clone(), {
        let cols_pux = cols_pu.clone();
        let span_p2x = span_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, (crate::prelude::Text, crate::prelude::Text))| {
            let cols_puxy = cols_pux.clone();
            let span_p2xy = span_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p10 = p0;
                let (lo_p11, hi_p12) = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::colors::AddLeq { st_p0: s_p10.clone(), lo0_p1: crate::prelude::or(&crate::prelude::get(&cols_puxy, &lo_p11), &crate::check::types::Col::CBound), hi0_p2: crate::prelude::or(&crate::prelude::get(&cols_puxy, &hi_p12), &crate::check::types::Col::CBound), span_p3: span_p2xy.clone(), kind_p4: crate::prelude::Text::lit("arg"), name_p5: crate::prelude::Text::lit(""), why_p6: crate::prelude::Text::lit("") }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, (crate::prelude::Text, crate::prelude::Text))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
    }));
    let st3_p7 = crate::prelude::fold(&sc_p1.bounds_p, &st2c_p6, &(|s_p13: &crate::check::types::St, (v_p14, tr_p15): &(crate::prelude::Text, crate::prelude::Text)| {
        let mut this: crate::check::types::St = s_p13.clone();
        this.wants_p = crate::prelude::push(&this.wants_p, &crate::check::types::Want { cls_p: tr_p15.clone(), ty_p: crate::prelude::or(&crate::prelude::get(&tys_pg, v_p14), &crate::check::types::Ty::TyErr), file_p: s_p13.file_p.clone(), span_p: span_p2.clone(), level_p: s_p13.level_p.clone() });
        this
    }));
    let st4_p8 = crate::prelude::run_to_end(crate::prelude::fold_job(sc_p1.eqs_p.clone(), st3_p7.clone(), {
        let inst_p5x = inst_p5.clone();
        let span_p2x = span_p2.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Waiting)| {
            let inst_p5xy = inst_p5x.clone();
            let span_p2xy = span_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p16 = p0;
                let w_p17 = p1;
                crate::prelude::call_then(start_subst_q_f(inst_p5xy.clone(), w_p17.expected_p.clone()), move |subst_q_f_3693: crate::check::types::Ty| crate::prelude::call_then(start_subst_q_f(inst_p5xy.clone(), w_p17.found_p.clone()), move |subst_q_f_3720: crate::check::types::Ty| ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::unify::Unify { st_p0: s_p16.clone(), expected_p1: subst_q_f_3693, found_p2: subst_q_f_3720, span_p3: span_p2xy.clone() }))))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::types::Waiting)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
    }));
    (subst_q_f(&inst_p5, &sc_p1.ty_p), st4_p8.clone(), inst_p5.clone())
}

/// The step machine of `InstantiateWith`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InstantiateWith: unbounded fn St, Scheme, Range, [Ty] -> ((Ty, St, Inst))
/// ```
pub struct InstantiateWith {
    pub st_p0: crate::check::types::St,
    pub sc_p1: crate::check::types::Scheme,
    pub span_p2: crate::syntax::Range,
    pub explicit_p3: crate::prelude::Array<crate::check::types::Ty>,
}

impl ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St, Inst)> for InstantiateWith {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St, Inst)> {
        let st_p0 = &self.st_p0;
        let sc_p1 = &self.sc_p1;
        let span_p2 = &self.span_p2;
        let explicit_p3 = &self.explicit_p3;
        let (tys_pg, st1_ph) = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&sc_p1.qs_p)), &(crate::prelude::Map::new(), st_p0.clone()), &(|(m_p9, s_pa): &(crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, crate::check::types::St), i_pb: &crate::prelude::Nat| {
            let q_pc = crate::prelude::or(&crate::prelude::index(&sc_p1.qs_p, i_pb), &crate::prelude::Text::lit(""));
            match crate::prelude::index(explicit_p3, i_pb) {
                ::std::option::Option::Some(g_pd) => (crate::prelude::insert(m_p9, &q_pc, &g_pd), s_pa.clone()),
                ::std::option::Option::None => {
                    let (v_pe, s2_pf) = crate::check::types::fresh_var_f(s_pa, &crate::check::types::has_text_f(&sc_p1.plain_qs_p, &q_pc), &crate::prelude::Text::lit(""));
                    (crate::prelude::insert(m_p9, &q_pc, &v_pe), s2_pf.clone())
                },
            }
        }));
        let nq_p4 = crate::prelude::len(&sc_p1.qs_p);
        let sc_p1x = sc_p1.clone();
        let span_p2x = span_p2.clone();
        crate::prelude::call_value(crate::prelude::fold_job(sc_p1x.rqs_p.clone(), (crate::prelude::Map::new(), st1_ph.clone()), {
            let sc_p1xx = sc_p1x.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Map<crate::prelude::Text, crate::check::types::Tail>, crate::check::types::St), crate::prelude::Text)| {
                let sc_p1xxy = sc_p1xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (m_pi, s_pj) = p0;
                    let q_pk = p1;
                    crate::prelude::call_then(start_lacks_in_f(sc_p1xxy.ty_p.clone(), q_pk.clone()), move |lacks_in_f_2991: crate::prelude::Array<crate::prelude::Text>| {
                        let (rw_pl, s2_pm) = crate::check::types::recording::fresh_row_f(&s_pj, &lacks_in_f_2991);
                        ::prism_rtl::Turn::Finished((crate::prelude::insert(&m_pi, &q_pk, &rw_pl.tail_p), crate::check::types::unify::name_row_f(&s2_pm, &rw_pl.tail_p, &q_pk)))
                    })
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Map<crate::prelude::Text, crate::check::types::Tail>, crate::check::types::St), crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Map<crate::prelude::Text, crate::check::types::Tail>, crate::check::types::St)>>>
        }), move |fold_2912: (crate::prelude::Map<crate::prelude::Text, crate::check::types::Tail>, crate::check::types::St)| {
            let (rows_pn, st2_po) = fold_2912;
            let (cols_pu, st2b_pv) = crate::prelude::fold(&sc_p1x.cqs_p, &(crate::prelude::Map::new(), st2_po.clone()), &(|(m_pp, s_pq): &(crate::prelude::Map<crate::prelude::Text, crate::check::types::Col>, crate::check::types::St), q_pr: &crate::prelude::Text| {
                let (c_ps, s2_pt) = crate::check::types::fresh_col_f(s_pq);
                (crate::prelude::insert(m_pp, q_pr, &c_ps), s2_pt.clone())
            }));
            let inst_p5 = Inst { tys_p: tys_pg.clone(), rows_p: rows_pn.clone(), cols_p: cols_pu.clone() };
            crate::prelude::call_value(crate::prelude::fold_job(sc_p1x.cjoins_p.clone(), st2b_pv.clone(), {
                let cols_pux = cols_pu.clone();
                let span_p2xx = span_p2x.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, (crate::prelude::Text, crate::prelude::Text))| {
                    let cols_puxy = cols_pux.clone();
                    let span_p2xxy = span_p2xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let s_p10 = p0;
                        let (lo_p11, hi_p12) = p1;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::colors::AddLeq { st_p0: s_p10.clone(), lo0_p1: crate::prelude::or(&crate::prelude::get(&cols_puxy, &lo_p11), &crate::check::types::Col::CBound), hi0_p2: crate::prelude::or(&crate::prelude::get(&cols_puxy, &hi_p12), &crate::check::types::Col::CBound), span_p3: span_p2xxy.clone(), kind_p4: crate::prelude::Text::lit("arg"), name_p5: crate::prelude::Text::lit(""), why_p6: crate::prelude::Text::lit("") }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, (crate::prelude::Text, crate::prelude::Text))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
            }), move |fold_3270: crate::check::types::St| {
                let st2c_p6 = fold_3270;
                let st3_p7 = crate::prelude::fold(&sc_p1x.bounds_p, &st2c_p6, &(|s_p13: &crate::check::types::St, (v_p14, tr_p15): &(crate::prelude::Text, crate::prelude::Text)| {
                    let mut this: crate::check::types::St = s_p13.clone();
                    this.wants_p = crate::prelude::push(&this.wants_p, &crate::check::types::Want { cls_p: tr_p15.clone(), ty_p: crate::prelude::or(&crate::prelude::get(&tys_pg, v_p14), &crate::check::types::Ty::TyErr), file_p: s_p13.file_p.clone(), span_p: span_p2x.clone(), level_p: s_p13.level_p.clone() });
                    this
                }));
                crate::prelude::call_value(crate::prelude::fold_job(sc_p1x.eqs_p.clone(), st3_p7.clone(), {
                    let inst_p5x = inst_p5.clone();
                    let span_p2xx = span_p2x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Waiting)| {
                        let inst_p5xy = inst_p5x.clone();
                        let span_p2xxy = span_p2xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let s_p16 = p0;
                            let w_p17 = p1;
                            crate::prelude::call_then(start_subst_q_f(inst_p5xy.clone(), w_p17.expected_p.clone()), move |subst_q_f_3693: crate::check::types::Ty| crate::prelude::call_then(start_subst_q_f(inst_p5xy.clone(), w_p17.found_p.clone()), move |subst_q_f_3720: crate::check::types::Ty| ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::unify::Unify { st_p0: s_p16.clone(), expected_p1: subst_q_f_3693, found_p2: subst_q_f_3720, span_p3: span_p2xxy.clone() }))))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::types::Waiting)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>
                }), move |fold_3657: crate::check::types::St| {
                    let st4_p8 = fold_3657;
                    crate::prelude::call_then(start_subst_q_f(inst_p5.clone(), sc_p1x.ty_p.clone()), move |subst_q_f_3755: crate::check::types::Ty| ::prism_rtl::Turn::Finished((subst_q_f_3755, st4_p8.clone(), inst_p5.clone())))
                })
            })
        })
    }
}

/// `Start InstantiateWith, x`: what the function value is when passed to `@Run`.
pub fn start_instantiate_with_f(st_p0: crate::check::types::St, sc_p1: crate::check::types::Scheme, span_p2: crate::syntax::Range, explicit_p3: crate::prelude::Array<crate::check::types::Ty>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St, Inst)>> {
    ::std::rc::Rc::new(InstantiateWith { st_p0, sc_p1, span_p2, explicit_p3 })
}

/// ```prism
/// LacksIn: unbounded fn Ty, Text -> [Text]
/// ```
pub fn lacks_in_f(t_p0: &crate::check::types::Ty, q_p1: &crate::prelude::Text) -> crate::prelude::Array<crate::prelude::Text> {
    match t_p0 {
        crate::check::types::Ty::TyCon(_, args_p2) => crate::prelude::run_to_end(crate::prelude::fold_job(args_p2.clone(), crate::prelude::Array::new(), {
            let q_p1x = q_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| {
                let q_p1xy = q_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p3 = p0;
                    let a_p4 = p1;
                    crate::prelude::call_then(start_lacks_in_f(a_p4.clone(), q_p1xy.clone()), move |lacks_in_f_4042: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p3, &lacks_in_f_4042)))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
        })),
        crate::check::types::Ty::TyFn(_, ps_p5, r_p6) => crate::prelude::run_to_end(crate::prelude::fold_job(ps_p5.clone(), lacks_in_f(&**r_p6, q_p1), {
            let q_p1x = q_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| {
                let q_p1xy = q_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p7 = p0;
                    let a_p8 = p1;
                    crate::prelude::call_then(start_lacks_in_f(a_p8.clone(), q_p1xy.clone()), move |lacks_in_f_4132: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p7, &lacks_in_f_4132)))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
        })),
        crate::check::types::Ty::TyTuple(ts_p9) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_p9.clone(), crate::prelude::Array::new(), {
            let q_p1x = q_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| {
                let q_p1xy = q_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_pa = p0;
                    let a_pb = p1;
                    crate::prelude::call_then(start_lacks_in_f(a_pb.clone(), q_p1xy.clone()), move |lacks_in_f_4204: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pa, &lacks_in_f_4204)))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
        })),
        crate::check::types::Ty::TyArray(e_pc) => lacks_in_f(&**e_pc, q_p1),
        crate::check::types::Ty::TyMap(k_pd, v_pe) => crate::check::types::union_texts_f(&lacks_in_f(&**k_pd, q_p1), &lacks_in_f(&**v_pe, q_p1)),
        crate::check::types::Ty::TySig(_, i_pf) => lacks_in_f(&**i_pf, q_p1),
        crate::check::types::Ty::TyAt(i_pg, rw_ph) => crate::check::types::union_texts_f(&lacks_in_f(&**i_pg, q_p1), &row_lacks_f(rw_ph, q_p1)),
        crate::check::types::Ty::TyElem(rw_pi, o_pj) => crate::check::types::union_texts_f(&lacks_in_f(&**o_pj, q_p1), &row_lacks_f(rw_pi, q_p1)),
        crate::check::types::Ty::TyElemAny(rw_pk) => row_lacks_f(rw_pk, q_p1),
        _ => crate::prelude::Array::new(),
    }
}

/// The step machine of `LacksIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LacksIn: unbounded fn Ty, Text -> [Text]
/// ```
pub struct LacksIn {
    pub t_p0: crate::check::types::Ty,
    pub q_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>> for LacksIn {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Array<crate::prelude::Text>> {
        let t_p0 = &self.t_p0;
        let q_p1 = &self.q_p1;
        match t_p0 {
            crate::check::types::Ty::TyCon(_, args_p2) => crate::prelude::fold_job(args_p2.clone(), crate::prelude::Array::new(), {
                let q_p1x = q_p1.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| {
                    let q_p1xy = q_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_p3 = p0;
                        let a_p4 = p1;
                        crate::prelude::call_then(start_lacks_in_f(a_p4.clone(), q_p1xy.clone()), move |lacks_in_f_4042: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p3, &lacks_in_f_4042)))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
            }).cycle(),
            crate::check::types::Ty::TyFn(_, ps_p5, r_p6) => {
                let ps_p5x = ps_p5.clone();
                let q_p1x = q_p1.clone();
                let r_p6x = (**r_p6).clone();
                crate::prelude::call_then(start_lacks_in_f(r_p6x.clone(), q_p1x.clone()), move |lacks_in_f_4090: crate::prelude::Array<crate::prelude::Text>| crate::prelude::fold_job(ps_p5x.clone(), lacks_in_f_4090, {
                    let q_p1xx = q_p1x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| {
                        let q_p1xxy = q_p1xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_p7 = p0;
                            let a_p8 = p1;
                            crate::prelude::call_then(start_lacks_in_f(a_p8.clone(), q_p1xxy.clone()), move |lacks_in_f_4132: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_p7, &lacks_in_f_4132)))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
                }).cycle())
            },
            crate::check::types::Ty::TyTuple(ts_p9) => crate::prelude::fold_job(ts_p9.clone(), crate::prelude::Array::new(), {
                let q_p1x = q_p1.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)| {
                    let q_p1xy = q_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_pa = p0;
                        let a_pb = p1;
                        crate::prelude::call_then(start_lacks_in_f(a_pb.clone(), q_p1xy.clone()), move |lacks_in_f_4204: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&acc_pa, &lacks_in_f_4204)))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Text>, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>>>
            }).cycle(),
            crate::check::types::Ty::TyArray(e_pc) => ::prism_rtl::Turn::More(::std::rc::Rc::new(LacksIn { t_p0: (**e_pc).clone(), q_p1: q_p1.clone() })),
            crate::check::types::Ty::TyMap(k_pd, v_pe) => {
                let k_pdx = (**k_pd).clone();
                let q_p1x = q_p1.clone();
                let v_pex = (**v_pe).clone();
                crate::prelude::call_then(start_lacks_in_f(k_pdx.clone(), q_p1x.clone()), move |lacks_in_f_4274: crate::prelude::Array<crate::prelude::Text>| crate::prelude::call_then(start_lacks_in_f(v_pex.clone(), q_p1x.clone()), move |lacks_in_f_4290: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&lacks_in_f_4274, &lacks_in_f_4290))))
            },
            crate::check::types::Ty::TySig(_, i_pf) => ::prism_rtl::Turn::More(::std::rc::Rc::new(LacksIn { t_p0: (**i_pf).clone(), q_p1: q_p1.clone() })),
            crate::check::types::Ty::TyAt(i_pg, rw_ph) => {
                let i_pgx = (**i_pg).clone();
                let q_p1x = q_p1.clone();
                let rw_phx = rw_ph.clone();
                crate::prelude::call_then(start_lacks_in_f(i_pgx.clone(), q_p1x.clone()), move |lacks_in_f_4366: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&lacks_in_f_4366, &row_lacks_f(&rw_phx, &q_p1x))))
            },
            crate::check::types::Ty::TyElem(rw_pi, o_pj) => {
                let o_pjx = (**o_pj).clone();
                let q_p1x = q_p1.clone();
                let rw_pix = rw_pi.clone();
                crate::prelude::call_then(start_lacks_in_f(o_pjx.clone(), q_p1x.clone()), move |lacks_in_f_4428: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::check::types::union_texts_f(&lacks_in_f_4428, &row_lacks_f(&rw_pix, &q_p1x))))
            },
            crate::check::types::Ty::TyElemAny(rw_pk) => ::prism_rtl::Turn::Finished(row_lacks_f(rw_pk, q_p1)),
            _ => ::prism_rtl::Turn::Finished(crate::prelude::Array::new()),
        }
    }
}

/// `Start LacksIn, x`: what the function value is when passed to `@Run`.
pub fn start_lacks_in_f(t_p0: crate::check::types::Ty, q_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Text>>> {
    ::std::rc::Rc::new(LacksIn { t_p0, q_p1 })
}

/// ```prism
/// RowLacks: fn Rw, Text -> [Text]
/// ```
pub fn row_lacks_f(rw_p0: &crate::check::types::Rw, q_p1: &crate::prelude::Text) -> crate::prelude::Array<crate::prelude::Text> {
    if &rw_p0.tail_p == &crate::check::types::Tail::TlQ(q_p1.clone()) {
        rw_p0.fams_p.clone()
    } else {
        crate::prelude::Array::new()
    }
}

/// ```prism
/// ApartName: fn Text, [Text], [Text] -> Text
/// ```
pub fn apart_name_f(q_p0: &crate::prelude::Text, impl_qs_p1: &crate::prelude::Array<crate::prelude::Text>, own_qs_p2: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Text {
    if crate::check::types::has_text_f(impl_qs_p1, q_p0) {
        crate::prelude::Text::from(format!("{}{}", q_p0, &crate::syntax::lexer::chars::join_f(&crate::prelude::append(impl_qs_p1, own_qs_p2), &crate::prelude::Text::lit(""))))
    } else {
        q_p0.clone()
    }
}

/// ```prism
/// SchemeApart: unbounded fn Scheme, [Text] -> Scheme
/// ```
pub fn scheme_apart_f(sc_p0: &crate::check::types::Scheme, impl_qs_p1: &crate::prelude::Array<crate::prelude::Text>) -> crate::check::types::Scheme {
    let own_p2 = sc_p0.qs_p.clone();
    let tys_p3 = crate::prelude::fold(&own_p2, &crate::prelude::Map::new(), &(|m_p4: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, q_p5: &crate::prelude::Text| crate::prelude::insert(m_p4, q_p5, &crate::check::types::Ty::TyQ(apart_name_f(q_p5, impl_qs_p1, &own_p2)))));
    let mut this: crate::check::types::Scheme = sc_p0.clone();
    this.qs_p = crate::prelude::each(&own_p2, &(|q_p6: &crate::prelude::Text| apart_name_f(q_p6, impl_qs_p1, &own_p2)));
    this.plain_qs_p = crate::prelude::each(&this.plain_qs_p, &(|q_p7: &crate::prelude::Text| apart_name_f(q_p7, impl_qs_p1, &own_p2)));
    this.bounds_p = crate::prelude::each(&this.bounds_p, &(|(q_p8, cls_p9): &(crate::prelude::Text, crate::prelude::Text)| (apart_name_f(q_p8, impl_qs_p1, &own_p2), cls_p9.clone())));
    this.ty_p = subst_q_f(&Inst { tys_p: tys_p3.clone(), rows_p: crate::prelude::Map::new(), cols_p: crate::prelude::Map::new() }, &this.ty_p);
    this
}

/// The step machine of `SchemeApart`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SchemeApart: unbounded fn Scheme, [Text] -> Scheme
/// ```
pub struct SchemeApart {
    pub sc_p0: crate::check::types::Scheme,
    pub impl_qs_p1: crate::prelude::Array<crate::prelude::Text>,
}

impl ::prism_rtl::Job<crate::check::types::Scheme> for SchemeApart {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::Scheme> {
        let sc_p0 = &self.sc_p0;
        let impl_qs_p1 = &self.impl_qs_p1;
        let own_p2 = sc_p0.qs_p.clone();
        let tys_p3 = crate::prelude::fold(&own_p2, &crate::prelude::Map::new(), &(|m_p4: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, q_p5: &crate::prelude::Text| crate::prelude::insert(m_p4, q_p5, &crate::check::types::Ty::TyQ(apart_name_f(q_p5, impl_qs_p1, &own_p2)))));
        ::prism_rtl::Turn::Finished({
            let mut this: crate::check::types::Scheme = sc_p0.clone();
            this.qs_p = crate::prelude::each(&own_p2, &(|q_p6: &crate::prelude::Text| apart_name_f(q_p6, impl_qs_p1, &own_p2)));
            this.plain_qs_p = crate::prelude::each(&this.plain_qs_p, &(|q_p7: &crate::prelude::Text| apart_name_f(q_p7, impl_qs_p1, &own_p2)));
            this.bounds_p = crate::prelude::each(&this.bounds_p, &(|(q_p8, cls_p9): &(crate::prelude::Text, crate::prelude::Text)| (apart_name_f(q_p8, impl_qs_p1, &own_p2), cls_p9.clone())));
            this.ty_p = subst_q_f(&Inst { tys_p: tys_p3.clone(), rows_p: crate::prelude::Map::new(), cols_p: crate::prelude::Map::new() }, &this.ty_p);
            this
        })
    }
}

/// `Start SchemeApart, x`: what the function value is when passed to `@Run`.
pub fn start_scheme_apart_f(sc_p0: crate::check::types::Scheme, impl_qs_p1: crate::prelude::Array<crate::prelude::Text>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Scheme>> {
    ::std::rc::Rc::new(SchemeApart { sc_p0, impl_qs_p1 })
}

/// ```prism
/// Skolemize: unbounded fn Scheme -> Ty
/// ```
pub fn skolemize_f(sc_p0: &crate::check::types::Scheme) -> crate::check::types::Ty {
    let tys_p1 = crate::prelude::fold(&sc_p0.qs_p, &crate::prelude::Map::new(), &(|m_p4: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, q_p5: &crate::prelude::Text| crate::prelude::insert(m_p4, q_p5, &crate::check::types::Ty::TyRigid(q_p5.clone()))));
    let rows_p2 = crate::prelude::fold(&sc_p0.rqs_p, &crate::prelude::Map::new(), &(|m_p6: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Tail>, q_p7: &crate::prelude::Text| crate::prelude::insert(m_p6, q_p7, &crate::check::types::Tail::TlRigid(q_p7.clone()))));
    let cols_p3 = crate::prelude::fold(&sc_p0.cqs_p, &crate::prelude::Map::new(), &(|m_p8: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Col>, q_p9: &crate::prelude::Text| crate::prelude::insert(m_p8, q_p9, &crate::check::types::Col::CRigid(q_p9.clone()))));
    subst_q_f(&Inst { tys_p: tys_p1.clone(), rows_p: rows_p2.clone(), cols_p: cols_p3.clone() }, &sc_p0.ty_p)
}

/// The step machine of `Skolemize`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Skolemize: unbounded fn Scheme -> Ty
/// ```
pub struct Skolemize {
    pub sc_p0: crate::check::types::Scheme,
}

impl ::prism_rtl::Job<crate::check::types::Ty> for Skolemize {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::Ty> {
        let sc_p0 = &self.sc_p0;
        let tys_p1 = crate::prelude::fold(&sc_p0.qs_p, &crate::prelude::Map::new(), &(|m_p4: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, q_p5: &crate::prelude::Text| crate::prelude::insert(m_p4, q_p5, &crate::check::types::Ty::TyRigid(q_p5.clone()))));
        let rows_p2 = crate::prelude::fold(&sc_p0.rqs_p, &crate::prelude::Map::new(), &(|m_p6: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Tail>, q_p7: &crate::prelude::Text| crate::prelude::insert(m_p6, q_p7, &crate::check::types::Tail::TlRigid(q_p7.clone()))));
        let cols_p3 = crate::prelude::fold(&sc_p0.cqs_p, &crate::prelude::Map::new(), &(|m_p8: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Col>, q_p9: &crate::prelude::Text| crate::prelude::insert(m_p8, q_p9, &crate::check::types::Col::CRigid(q_p9.clone()))));
        ::prism_rtl::Turn::More(::std::rc::Rc::new(SubstQ { m_p0: Inst { tys_p: tys_p1.clone(), rows_p: rows_p2.clone(), cols_p: cols_p3.clone() }, t_p1: sc_p0.ty_p.clone() }))
    }
}

/// `Start Skolemize, x`: what the function value is when passed to `@Run`.
pub fn start_skolemize_f(sc_p0: crate::check::types::Scheme) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>> {
    ::std::rc::Rc::new(Skolemize { sc_p0 })
}

/// ```prism
/// KeepWaitingBut: unbounded fn St, [Waiting] -> St
/// ```
pub fn keep_waiting_but_f(st_p0: &crate::check::types::St, own_p1: &crate::prelude::Array<crate::check::types::Waiting>) -> crate::check::types::St {
    let fields_p2 = crate::prelude::run_to_end(crate::prelude::fold_job(st_p0.field_qs_p.clone(), crate::prelude::Array::new(), {
        let st_p0x = st_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::check::types::unify::FieldQ)| {
            let st_p0xy = st_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p5 = p0;
                let q_p6 = p1;
                crate::prelude::call_then(crate::check::types::recording::start_free_vars_into_f(st_p0xy.clone(), acc_p5.clone(), q_p6.recv_p.clone()), move |free_vars_into_f_7141: crate::prelude::Array<crate::prelude::Nat>| ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::recording::FreeVarsInto { st_p0: st_p0xy.clone(), acc_p1: free_vars_into_f_7141, t_p2: q_p6.result_p.clone() })))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::check::types::unify::FieldQ)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
    }));
    let deferred_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::filter(&st_p0.deferred_p, &(|w_p7: &crate::check::types::Waiting| !has_waiting_f(own_p1, w_p7))), fields_p2.clone(), {
        let st_p0x = st_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Waiting)| {
            let st_p0xy = st_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_p8 = p0;
                let w_p9 = p1;
                crate::prelude::call_then(crate::check::types::recording::start_free_vars_into_f(st_p0xy.clone(), acc_p8.clone(), w_p9.expected_p.clone()), move |free_vars_into_f_7293: crate::prelude::Array<crate::prelude::Nat>| ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::recording::FreeVarsInto { st_p0: st_p0xy.clone(), acc_p1: free_vars_into_f_7293, t_p2: w_p9.found_p.clone() })))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Waiting)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
    }));
    let waiting_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(st_p0.fault_vars_p.clone(), deferred_p3.clone(), {
        let st_p0x = st_p0.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Waiting)| {
            let st_p0xy = st_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_pa = p0;
                let w_pb = p1;
                ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::recording::FreeVarsInto { st_p0: st_p0xy.clone(), acc_p1: acc_pa.clone(), t_p2: w_pb.expected_p.clone() }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Waiting)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
    }));
    crate::check::types::unify::lower_levels_f(st_p0, &waiting_p4, &st_p0.level_p)
}

/// The step machine of `KeepWaitingBut`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// KeepWaitingBut: unbounded fn St, [Waiting] -> St
/// ```
pub struct KeepWaitingBut {
    pub st_p0: crate::check::types::St,
    pub own_p1: crate::prelude::Array<crate::check::types::Waiting>,
}

impl ::prism_rtl::Job<crate::check::types::St> for KeepWaitingBut {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let own_p1 = &self.own_p1;
        let own_p1x = own_p1.clone();
        let st_p0x = st_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(st_p0x.field_qs_p.clone(), crate::prelude::Array::new(), {
            let st_p0xx = st_p0x.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::check::types::unify::FieldQ)| {
                let st_p0xxy = st_p0xx.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_p5 = p0;
                    let q_p6 = p1;
                    crate::prelude::call_then(crate::check::types::recording::start_free_vars_into_f(st_p0xxy.clone(), acc_p5.clone(), q_p6.recv_p.clone()), move |free_vars_into_f_7141: crate::prelude::Array<crate::prelude::Nat>| ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::recording::FreeVarsInto { st_p0: st_p0xxy.clone(), acc_p1: free_vars_into_f_7141, t_p2: q_p6.result_p.clone() })))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::check::types::unify::FieldQ)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
        }), move |fold_7090: crate::prelude::Array<crate::prelude::Nat>| {
            let fields_p2 = fold_7090;
            crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::filter(&st_p0x.deferred_p, &(|w_p7: &crate::check::types::Waiting| !has_waiting_f(&own_p1x, w_p7))), fields_p2.clone(), {
                let st_p0xx = st_p0x.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Waiting)| {
                    let st_p0xxy = st_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let acc_p8 = p0;
                        let w_p9 = p1;
                        crate::prelude::call_then(crate::check::types::recording::start_free_vars_into_f(st_p0xxy.clone(), acc_p8.clone(), w_p9.expected_p.clone()), move |free_vars_into_f_7293: crate::prelude::Array<crate::prelude::Nat>| ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::recording::FreeVarsInto { st_p0: st_p0xxy.clone(), acc_p1: free_vars_into_f_7293, t_p2: w_p9.found_p.clone() })))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Waiting)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
            }), move |fold_7200: crate::prelude::Array<crate::prelude::Nat>| {
                let deferred_p3 = fold_7200;
                crate::prelude::call_value(crate::prelude::fold_job(st_p0x.fault_vars_p.clone(), deferred_p3.clone(), {
                    let st_p0xx = st_p0x.clone();
                    ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Waiting)| {
                        let st_p0xxy = st_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let acc_pa = p0;
                            let w_pb = p1;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::recording::FreeVarsInto { st_p0: st_p0xxy.clone(), acc_p1: acc_pa.clone(), t_p2: w_pb.expected_p.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Array<crate::prelude::Nat>, crate::check::types::Waiting)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Array<crate::prelude::Nat>>>>
                }), move |fold_7354: crate::prelude::Array<crate::prelude::Nat>| {
                    let waiting_p4 = fold_7354;
                    ::prism_rtl::Turn::Finished(crate::check::types::unify::lower_levels_f(&st_p0x, &waiting_p4, &st_p0x.level_p))
                })
            })
        })
    }
}

/// `Start KeepWaitingBut, x`: what the function value is when passed to `@Run`.
pub fn start_keep_waiting_but_f(st_p0: crate::check::types::St, own_p1: crate::prelude::Array<crate::check::types::Waiting>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(KeepWaitingBut { st_p0, own_p1 })
}

/// ```prism
/// Generalize: unbounded fn St, Ty, [Nat], [((Nat, Text))] -> ((Scheme, St))
/// ```
pub fn generalize_f(st0_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty, keep_p2: &crate::prelude::Array<crate::prelude::Nat>, bounds_p3: &crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text)>) -> (crate::check::types::Scheme, crate::check::types::St) {
    generalize_in_f(st0_p0, t_p1, keep_p2, bounds_p3, &crate::prelude::Array::new())
}

/// The step machine of `Generalize`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Generalize: unbounded fn St, Ty, [Nat], [((Nat, Text))] -> ((Scheme, St))
/// ```
pub struct Generalize {
    pub st0_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
    pub keep_p2: crate::prelude::Array<crate::prelude::Nat>,
    pub bounds_p3: crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text)>,
}

impl ::prism_rtl::Job<(crate::check::types::Scheme, crate::check::types::St)> for Generalize {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Scheme, crate::check::types::St)> {
        let st0_p0 = &self.st0_p0;
        let t_p1 = &self.t_p1;
        let keep_p2 = &self.keep_p2;
        let bounds_p3 = &self.bounds_p3;
        ::prism_rtl::Turn::More(::std::rc::Rc::new(GeneralizeIn { st0_p0: st0_p0.clone(), t_p1: t_p1.clone(), keep_p2: keep_p2.clone(), bounds_p3: bounds_p3.clone(), own_p4: crate::prelude::Array::new() }))
    }
}

/// `Start Generalize, x`: what the function value is when passed to `@Run`.
pub fn start_generalize_f(st0_p0: crate::check::types::St, t_p1: crate::check::types::Ty, keep_p2: crate::prelude::Array<crate::prelude::Nat>, bounds_p3: crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text)>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Scheme, crate::check::types::St)>> {
    ::std::rc::Rc::new(Generalize { st0_p0, t_p1, keep_p2, bounds_p3 })
}

/// ```prism
/// GeneralizeIn: unbounded fn St, Ty, [Nat], [((Nat, Text))], [Waiting] -> ((Scheme, St))
/// ```
pub fn generalize_in_f(st0_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty, keep_p2: &crate::prelude::Array<crate::prelude::Nat>, bounds_p3: &crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text)>, own_p4: &crate::prelude::Array<crate::check::types::Waiting>) -> (crate::check::types::Scheme, crate::check::types::St) {
    let st_p5 = crate::check::types::colors::generalize_cols_f(&keep_waiting_but_f(st0_p0, own_p4));
    let z_p6 = crate::check::types::recording::zonk_f(&st_p5, t_p1);
    let vs_p7 = crate::prelude::filter(&crate::check::types::recording::free_vars_f(&st_p5, &z_p6), &(|v_pg: &crate::prelude::Nat| (&crate::check::types::recording::info_of_f(&st_p5, v_pg).level_p > &st_p5.level_p) && !crate::check::types::has_nat_f(keep_p2, v_pg)));
    let cvs_p8 = crate::prelude::filter(&crate::check::types::colors::free_col_vars_f(&st_p5, &z_p6), &(|v_ph: &crate::prelude::Nat| &crate::check::types::recording::info_of_f(&st_p5, v_ph).level_p > &st_p5.level_p));
    let tys_p9 = crate::prelude::fold(&vs_p7, &crate::prelude::Map::new(), &(|m_pi: &crate::prelude::Map<crate::prelude::Nat, crate::check::types::Ty>, v_pj: &crate::prelude::Nat| crate::prelude::insert(m_pi, v_pj, &crate::check::types::Ty::TyQ(crate::prelude::Text::from(format!("\'{}", v_pj))))));
    let cols_pa = crate::prelude::fold(&cvs_p8, &crate::prelude::Map::new(), &(|m_pk: &crate::prelude::Map<crate::prelude::Nat, crate::check::types::Col>, v_pl: &crate::prelude::Nat| crate::prelude::insert(m_pk, v_pl, &crate::check::types::Col::CQ(crate::prelude::Text::from(format!("\'c{}", v_pl))))));
    let named_pb = subst_flex_f(&tys_p9, &cols_pa, &z_p6);
    let plains_pc = crate::prelude::each(&crate::prelude::filter(&vs_p7, &(|v_pm: &crate::prelude::Nat| crate::check::types::recording::info_of_f(&st_p5, v_pm).plain_p)), &(|v_pn: &crate::prelude::Nat| crate::prelude::Text::from(format!("\'{}", v_pn))));
    let bs_pd = crate::prelude::each(&crate::prelude::filter(bounds_p3, &(|(v_po, _): &(crate::prelude::Nat, crate::prelude::Text)| crate::check::types::has_nat_f(&vs_p7, v_po))), &(|(v_pp, tr_pq): &(crate::prelude::Nat, crate::prelude::Text)| (crate::prelude::Text::from(format!("\'{}", v_pp)), tr_pq.clone())));
    let eqs_pe = crate::prelude::run_to_end(crate::prelude::each_job(own_p4.clone(), {
        let tys_p9x = tys_p9.clone();
        let cols_pax = cols_pa.clone();
        let st_p5x = st_p5.clone();
        ::std::rc::Rc::new(move |p0: crate::check::types::Waiting| {
            let tys_p9xy = tys_p9x.clone();
            let cols_paxy = cols_pax.clone();
            let st_p5xy = st_p5x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let w_pr = p0;
                ::prism_rtl::Turn::Finished({
                    let mut this: crate::check::types::Waiting = w_pr.clone();
                    this.expected_p = subst_flex_f(&tys_p9xy, &cols_paxy, &crate::check::types::recording::zonk_f(&st_p5xy, &w_pr.expected_p));
                    this.found_p = subst_flex_f(&tys_p9xy, &cols_paxy, &crate::check::types::recording::zonk_f(&st_p5xy, &w_pr.found_p));
                    this
                })
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Waiting) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Waiting>>>
    }));
    let st2_pf = {
        let mut this: crate::check::types::St = st_p5.clone();
        this.col_q_p = crate::prelude::fold(&cvs_p8, &this.col_q_p, &(|m_ps: &crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text>, v_pt: &crate::prelude::Nat| crate::prelude::insert(m_ps, v_pt, &crate::prelude::Text::from(format!("\'c{}", v_pt)))));
        this.deferred_p = crate::prelude::filter(&this.deferred_p, &(|w_pu: &crate::check::types::Waiting| !has_waiting_f(own_p4, w_pu)));
        this
    };
    (crate::check::types::Scheme { qs_p: crate::prelude::each(&vs_p7, &(|v_pv: &crate::prelude::Nat| crate::prelude::Text::from(format!("\'{}", v_pv)))), plain_qs_p: plains_pc.clone(), rqs_p: crate::prelude::Array::new(), cqs_p: crate::prelude::each(&cvs_p8, &(|v_p10: &crate::prelude::Nat| crate::prelude::Text::from(format!("\'c{}", v_p10)))), cjoins_p: crate::prelude::Array::new(), bounds_p: bs_pd.clone(), eqs_p: eqs_pe.clone(), ty_p: named_pb.clone() }, st2_pf.clone())
}

/// The step machine of `GeneralizeIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GeneralizeIn: unbounded fn St, Ty, [Nat], [((Nat, Text))], [Waiting] -> ((Scheme, St))
/// ```
pub struct GeneralizeIn {
    pub st0_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
    pub keep_p2: crate::prelude::Array<crate::prelude::Nat>,
    pub bounds_p3: crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text)>,
    pub own_p4: crate::prelude::Array<crate::check::types::Waiting>,
}

impl ::prism_rtl::Job<(crate::check::types::Scheme, crate::check::types::St)> for GeneralizeIn {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::check::types::Scheme, crate::check::types::St)> {
        let st0_p0 = &self.st0_p0;
        let t_p1 = &self.t_p1;
        let keep_p2 = &self.keep_p2;
        let bounds_p3 = &self.bounds_p3;
        let own_p4 = &self.own_p4;
        let bounds_p3x = bounds_p3.clone();
        let keep_p2x = keep_p2.clone();
        let own_p4x = own_p4.clone();
        let st0_p0x = st0_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(start_keep_waiting_but_f(st0_p0x.clone(), own_p4x.clone()), move |keep_waiting_but_f_8189: crate::check::types::St| crate::prelude::call_then(crate::check::types::colors::start_generalize_cols_f(keep_waiting_but_f_8189), move |generalize_cols_f_8173: crate::check::types::St| {
            let st_p5 = generalize_cols_f_8173;
            crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p5.clone(), t_p1x.clone()), move |zonk_f_8226: crate::check::types::Ty| {
                let z_p6 = zonk_f_8226;
                crate::prelude::call_then(crate::check::types::recording::start_free_vars_f(st_p5.clone(), z_p6.clone()), move |free_vars_f_8258: crate::prelude::Array<crate::prelude::Nat>| {
                    let vs_p7 = crate::prelude::filter(&free_vars_f_8258, &(|v_pg: &crate::prelude::Nat| (&crate::check::types::recording::info_of_f(&st_p5, v_pg).level_p > &st_p5.level_p) && !crate::check::types::has_nat_f(&keep_p2x, v_pg)));
                    crate::prelude::call_then(crate::check::types::colors::start_free_col_vars_f(st_p5.clone(), z_p6.clone()), move |free_col_vars_f_8359: crate::prelude::Array<crate::prelude::Nat>| {
                        let cvs_p8 = crate::prelude::filter(&free_col_vars_f_8359, &(|v_ph: &crate::prelude::Nat| &crate::check::types::recording::info_of_f(&st_p5, v_ph).level_p > &st_p5.level_p));
                        let tys_p9 = crate::prelude::fold(&vs_p7, &crate::prelude::Map::new(), &(|m_pi: &crate::prelude::Map<crate::prelude::Nat, crate::check::types::Ty>, v_pj: &crate::prelude::Nat| crate::prelude::insert(m_pi, v_pj, &crate::check::types::Ty::TyQ(crate::prelude::Text::from(format!("\'{}", v_pj))))));
                        let cols_pa = crate::prelude::fold(&cvs_p8, &crate::prelude::Map::new(), &(|m_pk: &crate::prelude::Map<crate::prelude::Nat, crate::check::types::Col>, v_pl: &crate::prelude::Nat| crate::prelude::insert(m_pk, v_pl, &crate::check::types::Col::CQ(crate::prelude::Text::from(format!("\'c{}", v_pl))))));
                        crate::prelude::call_then(start_subst_flex_f(tys_p9.clone(), cols_pa.clone(), z_p6.clone()), move |subst_flex_f_8556: crate::check::types::Ty| {
                            let named_pb = subst_flex_f_8556;
                            let plains_pc = crate::prelude::each(&crate::prelude::filter(&vs_p7, &(|v_pm: &crate::prelude::Nat| crate::check::types::recording::info_of_f(&st_p5, v_pm).plain_p)), &(|v_pn: &crate::prelude::Nat| crate::prelude::Text::from(format!("\'{}", v_pn))));
                            let bs_pd = crate::prelude::each(&crate::prelude::filter(&bounds_p3x, &(|(v_po, _): &(crate::prelude::Nat, crate::prelude::Text)| crate::check::types::has_nat_f(&vs_p7, v_po))), &(|(v_pp, tr_pq): &(crate::prelude::Nat, crate::prelude::Text)| (crate::prelude::Text::from(format!("\'{}", v_pp)), tr_pq.clone())));
                            crate::prelude::call_value(crate::prelude::each_job(own_p4x.clone(), {
                                let tys_p9x = tys_p9.clone();
                                let cols_pax = cols_pa.clone();
                                let st_p5x = st_p5.clone();
                                ::std::rc::Rc::new(move |p0: crate::check::types::Waiting| {
                                    let tys_p9xy = tys_p9x.clone();
                                    let cols_paxy = cols_pax.clone();
                                    let st_p5xy = st_p5x.clone();
                                    crate::prelude::entered(crate::prelude::once_job(move || {
                                        let w_pr = p0;
                                        ::prism_rtl::Turn::Finished({
                                            let mut this: crate::check::types::Waiting = w_pr.clone();
                                            this.expected_p = subst_flex_f(&tys_p9xy, &cols_paxy, &crate::check::types::recording::zonk_f(&st_p5xy, &w_pr.expected_p));
                                            this.found_p = subst_flex_f(&tys_p9xy, &cols_paxy, &crate::check::types::recording::zonk_f(&st_p5xy, &w_pr.found_p));
                                            this
                                        })
                                    }))
                                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Waiting) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Waiting>>>
                            }), move |each_8761: crate::prelude::Array<crate::check::types::Waiting>| {
                                let eqs_pe = each_8761;
                                let st2_pf = {
                                    let mut this: crate::check::types::St = st_p5.clone();
                                    this.col_q_p = crate::prelude::fold(&cvs_p8, &this.col_q_p, &(|m_ps: &crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text>, v_pt: &crate::prelude::Nat| crate::prelude::insert(m_ps, v_pt, &crate::prelude::Text::from(format!("\'c{}", v_pt)))));
                                    this.deferred_p = crate::prelude::filter(&this.deferred_p, &(|w_pu: &crate::check::types::Waiting| !has_waiting_f(&own_p4x, w_pu)));
                                    this
                                };
                                ::prism_rtl::Turn::Finished((crate::check::types::Scheme { qs_p: crate::prelude::each(&vs_p7, &(|v_pv: &crate::prelude::Nat| crate::prelude::Text::from(format!("\'{}", v_pv)))), plain_qs_p: plains_pc.clone(), rqs_p: crate::prelude::Array::new(), cqs_p: crate::prelude::each(&cvs_p8, &(|v_p10: &crate::prelude::Nat| crate::prelude::Text::from(format!("\'c{}", v_p10)))), cjoins_p: crate::prelude::Array::new(), bounds_p: bs_pd.clone(), eqs_p: eqs_pe.clone(), ty_p: named_pb.clone() }, st2_pf.clone()))
                            })
                        })
                    })
                })
            })
        }))
    }
}

/// `Start GeneralizeIn, x`: what the function value is when passed to `@Run`.
pub fn start_generalize_in_f(st0_p0: crate::check::types::St, t_p1: crate::check::types::Ty, keep_p2: crate::prelude::Array<crate::prelude::Nat>, bounds_p3: crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text)>, own_p4: crate::prelude::Array<crate::check::types::Waiting>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::check::types::Scheme, crate::check::types::St)>> {
    ::std::rc::Rc::new(GeneralizeIn { st0_p0, t_p1, keep_p2, bounds_p3, own_p4 })
}

/// ```prism
/// OwnEquations: unbounded fn St, Ty, [Nat] -> [Waiting]
/// ```
pub fn own_equations_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty, keep_p2: &crate::prelude::Array<crate::prelude::Nat>) -> crate::prelude::Array<crate::check::types::Waiting> {
    let in_type_p3 = crate::check::types::recording::free_vars_f(st_p0, &crate::check::types::recording::zonk_f(st_p0, t_p1));
    crate::prelude::run_to_end(crate::prelude::filter_job(st_p0.deferred_p.clone(), {
        let st_p0x = st_p0.clone();
        let in_type_p3x = in_type_p3.clone();
        let keep_p2x = keep_p2.clone();
        ::std::rc::Rc::new(move |p0: crate::check::types::Waiting| {
            let st_p0xy = st_p0x.clone();
            let in_type_p3xy = in_type_p3x.clone();
            let keep_p2xy = keep_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let w_p4 = p0;
                crate::prelude::call_then(crate::check::types::recording::start_free_vars_f(st_p0xy.clone(), w_p4.expected_p.clone()), move |free_vars_f_9627: crate::prelude::Array<crate::prelude::Nat>| crate::prelude::call_then(crate::check::types::recording::start_free_vars_into_f(st_p0xy.clone(), free_vars_f_9627, w_p4.found_p.clone()), move |free_vars_into_f_9609: crate::prelude::Array<crate::prelude::Nat>| {
                    let vs_p5 = free_vars_into_f_9609;
                    ::prism_rtl::Turn::Finished((&crate::prelude::len(&vs_p5) > &crate::prelude::Nat::from(0u32)) && crate::prelude::fold(&vs_p5, &true, &(|ok_p6: &bool, v_p7: &crate::prelude::Nat| ((*ok_p6 && crate::check::types::has_nat_f(&in_type_p3xy, v_p7)) && (&crate::check::types::recording::info_of_f(&st_p0xy, v_p7).level_p > &st_p0xy.level_p)) && !crate::check::types::has_nat_f(&keep_p2xy, v_p7))))
                }))
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Waiting) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
    }))
}

/// ```prism
/// HasWaiting: fn [Waiting], Waiting -> Bool
/// ```
pub fn has_waiting_f(ws_p0: &crate::prelude::Array<crate::check::types::Waiting>, w_p1: &crate::check::types::Waiting) -> bool {
    crate::prelude::fold(ws_p0, &false, &(|seen_p2: &bool, x_p3: &crate::check::types::Waiting| *seen_p2 || (x_p3 == w_p1)))
}

/// ```prism
/// SubstFlex: unbounded fn (Nat ==> Ty), (Nat ==> Col), Ty -> Ty
/// ```
pub fn subst_flex_f(m_p0: &crate::prelude::Map<crate::prelude::Nat, crate::check::types::Ty>, cm_p1: &crate::prelude::Map<crate::prelude::Nat, crate::check::types::Col>, t_p2: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p2 {
        crate::check::types::Ty::TyFlex(n_p3) => crate::prelude::or(&crate::prelude::get(m_p0, n_p3), &crate::check::types::Ty::TyFlex(n_p3.clone())),
        crate::check::types::Ty::TyCon(n_p4, args_p5) => crate::check::types::Ty::TyCon(n_p4.clone(), crate::prelude::run_to_end(crate::prelude::each_job(args_p5.clone(), {
            let m_p0x = m_p0.clone();
            let cm_p1x = cm_p1.clone();
            ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                let m_p0xy = m_p0x.clone();
                let cm_p1xy = cm_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p6 = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(SubstFlex { m_p0: m_p0xy.clone(), cm_p1: cm_p1xy.clone(), t_p2: a_p6.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyFn(c_p7, ps_p8, res_p9) => {
            let c2_pa = match c_p7 {
                crate::check::types::Col::CFlex(n_pb) => crate::prelude::or(&crate::prelude::get(cm_p1, n_pb), c_p7),
                other_pc => other_pc.clone(),
            };
            crate::check::types::Ty::TyFn(c2_pa.clone(), crate::prelude::run_to_end(crate::prelude::each_job(ps_p8.clone(), {
                let m_p0x = m_p0.clone();
                let cm_p1x = cm_p1.clone();
                ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                    let m_p0xy = m_p0x.clone();
                    let cm_p1xy = cm_p1x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let p_pd = p0;
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(SubstFlex { m_p0: m_p0xy.clone(), cm_p1: cm_p1xy.clone(), t_p2: p_pd.clone() }))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
            })), ::std::rc::Rc::new(subst_flex_f(m_p0, cm_p1, &**res_p9)))
        },
        crate::check::types::Ty::TyTuple(ts_pe) => crate::check::types::Ty::TyTuple(crate::prelude::run_to_end(crate::prelude::each_job(ts_pe.clone(), {
            let m_p0x = m_p0.clone();
            let cm_p1x = cm_p1.clone();
            ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                let m_p0xy = m_p0x.clone();
                let cm_p1xy = cm_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pf = p0;
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(SubstFlex { m_p0: m_p0xy.clone(), cm_p1: cm_p1xy.clone(), t_p2: a_pf.clone() }))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyArray(e_pg) => crate::check::types::Ty::TyArray(::std::rc::Rc::new(subst_flex_f(m_p0, cm_p1, &**e_pg))),
        crate::check::types::Ty::TyMap(k_ph, v_pi) => crate::check::types::Ty::TyMap(::std::rc::Rc::new(subst_flex_f(m_p0, cm_p1, &**k_ph)), ::std::rc::Rc::new(subst_flex_f(m_p0, cm_p1, &**v_pi))),
        crate::check::types::Ty::TySig(s_pj, i_pk) => crate::check::types::Ty::TySig(s_pj.clone(), ::std::rc::Rc::new(subst_flex_f(m_p0, cm_p1, &**i_pk))),
        crate::check::types::Ty::TyAt(i_pl, rw_pm) => crate::check::types::Ty::TyAt(::std::rc::Rc::new(subst_flex_f(m_p0, cm_p1, &**i_pl)), rw_pm.clone()),
        crate::check::types::Ty::TyElem(rw_pn, o_po) => crate::check::types::Ty::TyElem(rw_pn.clone(), ::std::rc::Rc::new(subst_flex_f(m_p0, cm_p1, &**o_po))),
        crate::check::types::Ty::TyAssoc(tr_pp, n_pq, a_pr) => crate::check::types::Ty::TyAssoc(tr_pp.clone(), n_pq.clone(), ::std::rc::Rc::new(subst_flex_f(m_p0, cm_p1, &**a_pr))),
        other_ps => other_ps.clone(),
    }
}

/// The step machine of `SubstFlex`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SubstFlex: unbounded fn (Nat ==> Ty), (Nat ==> Col), Ty -> Ty
/// ```
pub struct SubstFlex {
    pub m_p0: crate::prelude::Map<crate::prelude::Nat, crate::check::types::Ty>,
    pub cm_p1: crate::prelude::Map<crate::prelude::Nat, crate::check::types::Col>,
    pub t_p2: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::Ty> for SubstFlex {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::Ty> {
        let m_p0 = &self.m_p0;
        let cm_p1 = &self.cm_p1;
        let t_p2 = &self.t_p2;
        match t_p2 {
            crate::check::types::Ty::TyFlex(n_p3) => ::prism_rtl::Turn::Finished(crate::prelude::or(&crate::prelude::get(m_p0, n_p3), &crate::check::types::Ty::TyFlex(n_p3.clone()))),
            crate::check::types::Ty::TyCon(n_p4, args_p5) => {
                let args_p5x = args_p5.clone();
                let cm_p1x = cm_p1.clone();
                let m_p0x = m_p0.clone();
                let n_p4x = n_p4.clone();
                crate::prelude::call_value(crate::prelude::each_job(args_p5x.clone(), {
                    let m_p0xx = m_p0x.clone();
                    let cm_p1xx = cm_p1x.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                        let m_p0xxy = m_p0xx.clone();
                        let cm_p1xxy = cm_p1xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_p6 = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(SubstFlex { m_p0: m_p0xxy.clone(), cm_p1: cm_p1xxy.clone(), t_p2: a_p6.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_10065: crate::prelude::Array<crate::check::types::Ty>| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyCon(n_p4x.clone(), each_10065)))
            },
            crate::check::types::Ty::TyFn(c_p7, ps_p8, res_p9) => {
                let c2_pa = match c_p7 {
                    crate::check::types::Col::CFlex(n_pb) => crate::prelude::or(&crate::prelude::get(cm_p1, n_pb), c_p7),
                    other_pc => other_pc.clone(),
                };
                let cm_p1x = cm_p1.clone();
                let m_p0x = m_p0.clone();
                let ps_p8x = ps_p8.clone();
                let res_p9x = (**res_p9).clone();
                crate::prelude::call_value(crate::prelude::each_job(ps_p8x.clone(), {
                    let m_p0xx = m_p0x.clone();
                    let cm_p1xx = cm_p1x.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                        let m_p0xxy = m_p0xx.clone();
                        let cm_p1xxy = cm_p1xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let p_pd = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(SubstFlex { m_p0: m_p0xxy.clone(), cm_p1: cm_p1xxy.clone(), t_p2: p_pd.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_10224: crate::prelude::Array<crate::check::types::Ty>| crate::prelude::call_then(start_subst_flex_f(m_p0x.clone(), cm_p1x.clone(), res_p9x.clone()), move |subst_flex_f_10260: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyFn(c2_pa.clone(), each_10224, ::std::rc::Rc::new(subst_flex_f_10260)))))
            },
            crate::check::types::Ty::TyTuple(ts_pe) => {
                let cm_p1x = cm_p1.clone();
                let m_p0x = m_p0.clone();
                let ts_pex = ts_pe.clone();
                crate::prelude::call_value(crate::prelude::each_job(ts_pex.clone(), {
                    let m_p0xx = m_p0x.clone();
                    let cm_p1xx = cm_p1x.clone();
                    ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                        let m_p0xxy = m_p0xx.clone();
                        let cm_p1xxy = cm_p1xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_pf = p0;
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(SubstFlex { m_p0: m_p0xxy.clone(), cm_p1: cm_p1xxy.clone(), t_p2: a_pf.clone() }))
                        }))
                    }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_10307: crate::prelude::Array<crate::check::types::Ty>| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyTuple(each_10307)))
            },
            crate::check::types::Ty::TyArray(e_pg) => {
                let cm_p1x = cm_p1.clone();
                let e_pgx = (**e_pg).clone();
                let m_p0x = m_p0.clone();
                crate::prelude::call_then(start_subst_flex_f(m_p0x.clone(), cm_p1x.clone(), e_pgx.clone()), move |subst_flex_f_10365: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyArray(::std::rc::Rc::new(subst_flex_f_10365))))
            },
            crate::check::types::Ty::TyMap(k_ph, v_pi) => {
                let cm_p1x = cm_p1.clone();
                let k_phx = (**k_ph).clone();
                let m_p0x = m_p0.clone();
                let v_pix = (**v_pi).clone();
                crate::prelude::call_then(start_subst_flex_f(m_p0x.clone(), cm_p1x.clone(), k_phx.clone()), move |subst_flex_f_10408: crate::check::types::Ty| crate::prelude::call_then(start_subst_flex_f(m_p0x.clone(), cm_p1x.clone(), v_pix.clone()), move |subst_flex_f_10430: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyMap(::std::rc::Rc::new(subst_flex_f_10408), ::std::rc::Rc::new(subst_flex_f_10430)))))
            },
            crate::check::types::Ty::TySig(s_pj, i_pk) => {
                let cm_p1x = cm_p1.clone();
                let i_pkx = (**i_pk).clone();
                let m_p0x = m_p0.clone();
                let s_pjx = s_pj.clone();
                crate::prelude::call_then(start_subst_flex_f(m_p0x.clone(), cm_p1x.clone(), i_pkx.clone()), move |subst_flex_f_10476: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TySig(s_pjx.clone(), ::std::rc::Rc::new(subst_flex_f_10476))))
            },
            crate::check::types::Ty::TyAt(i_pl, rw_pm) => {
                let cm_p1x = cm_p1.clone();
                let i_plx = (**i_pl).clone();
                let m_p0x = m_p0.clone();
                let rw_pmx = rw_pm.clone();
                crate::prelude::call_then(start_subst_flex_f(m_p0x.clone(), cm_p1x.clone(), i_plx.clone()), move |subst_flex_f_10518: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyAt(::std::rc::Rc::new(subst_flex_f_10518), rw_pmx.clone())))
            },
            crate::check::types::Ty::TyElem(rw_pn, o_po) => {
                let cm_p1x = cm_p1.clone();
                let m_p0x = m_p0.clone();
                let o_pox = (**o_po).clone();
                let rw_pnx = rw_pn.clone();
                crate::prelude::call_then(start_subst_flex_f(m_p0x.clone(), cm_p1x.clone(), o_pox.clone()), move |subst_flex_f_10572: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyElem(rw_pnx.clone(), ::std::rc::Rc::new(subst_flex_f_10572))))
            },
            crate::check::types::Ty::TyAssoc(tr_pp, n_pq, a_pr) => {
                let a_prx = (**a_pr).clone();
                let cm_p1x = cm_p1.clone();
                let m_p0x = m_p0.clone();
                let n_pqx = n_pq.clone();
                let tr_ppx = tr_pp.clone();
                crate::prelude::call_then(start_subst_flex_f(m_p0x.clone(), cm_p1x.clone(), a_prx.clone()), move |subst_flex_f_10630: crate::check::types::Ty| ::prism_rtl::Turn::Finished(crate::check::types::Ty::TyAssoc(tr_ppx.clone(), n_pqx.clone(), ::std::rc::Rc::new(subst_flex_f_10630))))
            },
            other_ps => ::prism_rtl::Turn::Finished(other_ps.clone()),
        }
    }
}

/// `Start SubstFlex, x`: what the function value is when passed to `@Run`.
pub fn start_subst_flex_f(m_p0: crate::prelude::Map<crate::prelude::Nat, crate::check::types::Ty>, cm_p1: crate::prelude::Map<crate::prelude::Nat, crate::check::types::Col>, t_p2: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>> {
    ::std::rc::Rc::new(SubstFlex { m_p0, cm_p1, t_p2 })
}

/// ```prism
/// HoldsNode: unbounded fn St, Ty -> Bool
/// ```
pub fn holds_node_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> bool {
    match crate::check::types::recording::walk_f(st_p0, t_p1) {
        crate::check::types::Ty::TySig(s_p2, i_p3) => ((&s_p2 == &crate::prelude::Text::lit("$")) || (&s_p2 == &crate::prelude::Text::lit("!"))) || holds_node_f(st_p0, &*i_p3),
        crate::check::types::Ty::TyTuple(ts_p4) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_p4.clone(), false, {
            let st_p0x = st_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let seen_p5 = p0;
                    let x_p6 = p1;
                    if seen_p5 {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsNode { st_p0: st_p0xy.clone(), t_p1: x_p6.clone() }))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        })),
        crate::check::types::Ty::TyArray(e_p7) => holds_node_f(st_p0, &*e_p7),
        crate::check::types::Ty::TyMap(k_p8, v_p9) => holds_node_f(st_p0, &*k_p8) || holds_node_f(st_p0, &*v_p9),
        crate::check::types::Ty::TyCon(_, args_pa) => crate::prelude::run_to_end(crate::prelude::fold_job(args_pa.clone(), false, {
            let st_p0x = st_p0.clone();
            ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let seen_pb = p0;
                    let x_pc = p1;
                    if seen_pb {
                        ::prism_rtl::Turn::Finished(true)
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsNode { st_p0: st_p0xy.clone(), t_p1: x_pc.clone() }))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
        })),
        _ => false,
    }
}

/// The step machine of `HoldsNode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HoldsNode: unbounded fn St, Ty -> Bool
/// ```
pub struct HoldsNode {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl ::prism_rtl::Job<bool> for HoldsNode {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), t_p1x.clone()), move |walk_f_10864: crate::check::types::Ty| match walk_f_10864 {
            crate::check::types::Ty::TySig(s_p2, i_p3) => if (&s_p2 == &crate::prelude::Text::lit("$")) || (&s_p2 == &crate::prelude::Text::lit("!")) {
                ::prism_rtl::Turn::Finished(true)
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsNode { st_p0: st_p0x.clone(), t_p1: (*i_p3).clone() }))
            },
            crate::check::types::Ty::TyTuple(ts_p4) => crate::prelude::fold_job(ts_p4.clone(), false, {
                let st_p0xx = st_p0x.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                    let st_p0xxy = st_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let seen_p5 = p0;
                        let x_p6 = p1;
                        if seen_p5 {
                            ::prism_rtl::Turn::Finished(true)
                        } else {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsNode { st_p0: st_p0xxy.clone(), t_p1: x_p6.clone() }))
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }).cycle(),
            crate::check::types::Ty::TyArray(e_p7) => ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsNode { st_p0: st_p0x.clone(), t_p1: (*e_p7).clone() })),
            crate::check::types::Ty::TyMap(k_p8, v_p9) => crate::prelude::call_then(start_holds_node_f(st_p0x.clone(), (*k_p8).clone()), move |holds_node_f_11047: bool| if holds_node_f_11047 {
                ::prism_rtl::Turn::Finished(true)
            } else {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsNode { st_p0: st_p0x.clone(), t_p1: (*v_p9).clone() }))
            }),
            crate::check::types::Ty::TyCon(_, args_pa) => crate::prelude::fold_job(args_pa.clone(), false, {
                let st_p0xx = st_p0x.clone();
                ::std::rc::Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                    let st_p0xxy = st_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let seen_pb = p0;
                        let x_pc = p1;
                        if seen_pb {
                            ::prism_rtl::Turn::Finished(true)
                        } else {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(HoldsNode { st_p0: st_p0xxy.clone(), t_p1: x_pc.clone() }))
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((bool, crate::check::types::Ty)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>>>
            }).cycle(),
            _ => ::prism_rtl::Turn::Finished(false),
        })
    }
}

/// `Start HoldsNode, x`: what the function value is when passed to `@Run`.
pub fn start_holds_node_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(HoldsNode { st_p0, t_p1 })
}

/// ```prism
/// EnterLevel: fn St -> St
/// ```
pub fn enter_level_f(st_p0: &crate::check::types::St) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.level_p = &this.level_p + &crate::prelude::Nat::from(1u32);
    this
}

/// ```prism
/// LeaveLevel: fn St -> St
/// ```
pub fn leave_level_f(st_p0: &crate::check::types::St) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.level_p = crate::prelude::or(&(&this.level_p).checked_sub(&crate::prelude::Nat::from(1u32)), &crate::prelude::Nat::from(0u32));
    this
}
