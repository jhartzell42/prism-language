//! The module `Check.Types.Schemes`, from `target/bootstrap/src/prismc/check/types/schemes.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Inst`:
///
/// ```prism
/// type Inst = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Inst {
    pub tys: Map<Text, crate::check::types::Ty>,
    pub rows: Map<Text, crate::check::types::Tail>,
    pub cols: Map<Text, crate::check::types::Col>,
}

impl Show for Inst {
    fn show(&self, p: &mut Printer) {
        p.record("Inst", &[("tys", &self.tys), ("rows", &self.rows), ("cols", &self.cols)]);
    }
}

impl ToPod for Inst {
    fn to_pod(&self) -> Pod {
        Pod::record("Inst", vec![("tys", self.tys.to_pod()), ("rows", self.rows.to_pod()), ("cols", self.cols.to_pod())])
    }
}

impl FromPod for Inst {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Inst { tys: FromPod::from_pod(field(p, "tys")?)?, rows: FromPod::from_pod(field(p, "rows")?)?, cols: FromPod::from_pod(field(p, "cols")?)? })
    }
}

/// ```prism
/// Mono: fn Ty -> Scheme
/// ```
pub fn mono(t_p0: &crate::check::types::Ty) -> crate::check::types::Scheme {
    crate::check::types::Scheme { qs: Array::new(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: t_p0.clone() }
}

/// ```prism
/// SubstQ: unbounded fn Inst, Ty -> Ty
/// ```
pub fn subst_q(m_p0: &Inst, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p1 {
        crate::check::types::Ty::TyQ(n_p2) => or(&get(&m_p0.tys, n_p2), &crate::check::types::Ty::TyQ(n_p2.clone())),
        crate::check::types::Ty::TyCon(n_p3, args_p4) => crate::check::types::Ty::TyCon(n_p3.clone(), run_to_end(each_job(args_p4.clone(), {
            let m_p0 = m_p0.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let m_p0 = m_p0.clone();
                entered(once_job(move || {
                    let a_p5 = p0;
                    prism_rtl::Turn::More(Rc::new(SubstQ { m_p0: m_p0.clone(), t_p1: a_p5.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyFn(c_p6, ps_p7, res_p8) => crate::check::types::Ty::TyFn(subst_col(m_p0, c_p6), run_to_end(each_job(ps_p7.clone(), {
            let m_p0 = m_p0.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let m_p0 = m_p0.clone();
                entered(once_job(move || {
                    let p_p9 = p0;
                    prism_rtl::Turn::More(Rc::new(SubstQ { m_p0: m_p0.clone(), t_p1: p_p9.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        })), Rc::new(subst_q(m_p0, &**res_p8))),
        crate::check::types::Ty::TyTuple(ts_pa) => crate::check::types::Ty::TyTuple(run_to_end(each_job(ts_pa.clone(), {
            let m_p0 = m_p0.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let m_p0 = m_p0.clone();
                entered(once_job(move || {
                    let a_pb = p0;
                    prism_rtl::Turn::More(Rc::new(SubstQ { m_p0: m_p0.clone(), t_p1: a_pb.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyArray(e_pc) => crate::check::types::Ty::TyArray(Rc::new(subst_q(m_p0, &**e_pc))),
        crate::check::types::Ty::TyMap(k_pd, v_pe) => crate::check::types::Ty::TyMap(Rc::new(subst_q(m_p0, &**k_pd)), Rc::new(subst_q(m_p0, &**v_pe))),
        crate::check::types::Ty::TySig(s_pf, i_pg) => crate::check::types::Ty::TySig(s_pf.clone(), Rc::new(subst_q(m_p0, &**i_pg))),
        crate::check::types::Ty::TyAt(i_ph, rw_pi) => crate::check::types::Ty::TyAt(Rc::new(subst_q(m_p0, &**i_ph)), subst_row_q(m_p0, rw_pi)),
        crate::check::types::Ty::TyElem(rw_pj, o_pk) => crate::check::types::Ty::TyElem(subst_row_q(m_p0, rw_pj), Rc::new(subst_q(m_p0, &**o_pk))),
        crate::check::types::Ty::TyElemAny(rw_pl) => crate::check::types::Ty::TyElemAny(subst_row_q(m_p0, rw_pl)),
        crate::check::types::Ty::TyAssoc(n_pm, a_pn) => crate::check::types::Ty::TyAssoc(n_pm.clone(), Rc::new(subst_q(m_p0, &**a_pn))),
        other_po => other_po.clone(),
    }
}

/// The step machine of `SubstQ`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SubstQ: unbounded fn Inst, Ty -> Ty
/// ```
pub struct SubstQ {
    pub m_p0: Inst,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::Ty> for SubstQ {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let m_p0 = &self.m_p0;
        let t_p1 = &self.t_p1;
        match t_p1 {
            crate::check::types::Ty::TyQ(n_p2) => prism_rtl::Turn::Finished(or(&get(&m_p0.tys, n_p2), &crate::check::types::Ty::TyQ(n_p2.clone()))),
            crate::check::types::Ty::TyCon(n_p3, args_p4) => {
                let args_p4 = args_p4.clone();
                let m_p0 = m_p0.clone();
                let n_p3 = n_p3.clone();
                call_value(each_job(args_p4.clone(), {
                    let m_p0 = m_p0.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let m_p0 = m_p0.clone();
                        entered(once_job(move || {
                            let a_p5 = p0;
                            prism_rtl::Turn::More(Rc::new(SubstQ { m_p0: m_p0.clone(), t_p1: a_p5.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_1157: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyCon(n_p3.clone(), each_1157)))
            },
            crate::check::types::Ty::TyFn(c_p6, ps_p7, res_p8) => {
                let c_p6 = c_p6.clone();
                let m_p0 = m_p0.clone();
                let ps_p7 = ps_p7.clone();
                let res_p8 = (**res_p8).clone();
                call_value(each_job(ps_p7.clone(), {
                    let m_p0 = m_p0.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let m_p0 = m_p0.clone();
                        entered(once_job(move || {
                            let p_p9 = p0;
                            prism_rtl::Turn::More(Rc::new(SubstQ { m_p0: m_p0.clone(), t_p1: p_p9.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_1230: Array<crate::check::types::Ty>| call_then(start_subst_q(m_p0.clone(), res_p8.clone()), move |subst_q_1259: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyFn(subst_col(&m_p0, &c_p6), each_1230, Rc::new(subst_q_1259)))))
            },
            crate::check::types::Ty::TyTuple(ts_pa) => {
                let m_p0 = m_p0.clone();
                let ts_pa = ts_pa.clone();
                call_value(each_job(ts_pa.clone(), {
                    let m_p0 = m_p0.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let m_p0 = m_p0.clone();
                        entered(once_job(move || {
                            let a_pb = p0;
                            prism_rtl::Turn::More(Rc::new(SubstQ { m_p0: m_p0.clone(), t_p1: a_pb.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_1299: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyTuple(each_1299)))
            },
            crate::check::types::Ty::TyArray(e_pc) => {
                let e_pc = (**e_pc).clone();
                let m_p0 = m_p0.clone();
                call_then(start_subst_q(m_p0.clone(), e_pc.clone()), move |subst_q_1350: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyArray(Rc::new(subst_q_1350))))
            },
            crate::check::types::Ty::TyMap(k_pd, v_pe) => {
                let k_pd = (**k_pd).clone();
                let m_p0 = m_p0.clone();
                let v_pe = (**v_pe).clone();
                call_then(start_subst_q(m_p0.clone(), k_pd.clone()), move |subst_q_1386: crate::check::types::Ty| call_then(start_subst_q(m_p0.clone(), v_pe.clone()), move |subst_q_1401: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyMap(Rc::new(subst_q_1386), Rc::new(subst_q_1401)))))
            },
            crate::check::types::Ty::TySig(s_pf, i_pg) => {
                let i_pg = (**i_pg).clone();
                let m_p0 = m_p0.clone();
                let s_pf = s_pf.clone();
                call_then(start_subst_q(m_p0.clone(), i_pg.clone()), move |subst_q_1440: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TySig(s_pf.clone(), Rc::new(subst_q_1440))))
            },
            crate::check::types::Ty::TyAt(i_ph, rw_pi) => {
                let i_ph = (**i_ph).clone();
                let m_p0 = m_p0.clone();
                let rw_pi = rw_pi.clone();
                call_then(start_subst_q(m_p0.clone(), i_ph.clone()), move |subst_q_1475: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyAt(Rc::new(subst_q_1475), subst_row_q(&m_p0, &rw_pi))))
            },
            crate::check::types::Ty::TyElem(rw_pj, o_pk) => {
                let m_p0 = m_p0.clone();
                let o_pk = (**o_pk).clone();
                let rw_pj = rw_pj.clone();
                call_then(start_subst_q(m_p0.clone(), o_pk.clone()), move |subst_q_1552: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyElem(subst_row_q(&m_p0, &rw_pj), Rc::new(subst_q_1552))))
            },
            crate::check::types::Ty::TyElemAny(rw_pl) => prism_rtl::Turn::Finished(crate::check::types::Ty::TyElemAny(subst_row_q(m_p0, rw_pl))),
            crate::check::types::Ty::TyAssoc(n_pm, a_pn) => {
                let a_pn = (**a_pn).clone();
                let m_p0 = m_p0.clone();
                let n_pm = n_pm.clone();
                call_then(start_subst_q(m_p0.clone(), a_pn.clone()), move |subst_q_1641: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyAssoc(n_pm.clone(), Rc::new(subst_q_1641))))
            },
            other_po => prism_rtl::Turn::Finished(other_po.clone()),
        }
    }
}

/// `Start SubstQ, x`: what the function value is when passed to `@Run`.
pub fn start_subst_q(m_p0: Inst, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(SubstQ { m_p0, t_p1 })
}

/// ```prism
/// SubstRowQ: fn Inst, Rw -> Rw
/// ```
pub fn subst_row_q(m_p0: &Inst, rw_p1: &crate::check::types::Rw) -> crate::check::types::Rw {
    match &rw_p1.tail {
        crate::check::types::Tail::TlQ(n_p2) => match get(&m_p0.rows, n_p2) {
            Some(t_p3) => crate::check::types::Rw { fams: rw_p1.fams.clone(), minus: rw_p1.minus.clone(), tail: t_p3 },
            None => rw_p1.clone(),
        },
        _ => rw_p1.clone(),
    }
}

/// ```prism
/// SubstCol: fn Inst, Col -> Col
/// ```
pub fn subst_col(m_p0: &Inst, col1: &crate::check::types::Col) -> crate::check::types::Col {
    match col1 {
        crate::check::types::Col::CQ(n_p1) => or(&get(&m_p0.cols, n_p1), &crate::check::types::Col::CQ(n_p1.clone())),
        c_p3 => c_p3.clone(),
    }
}

/// ```prism
/// Instantiate: unbounded fn St, Scheme, Range -> ((Ty, St))
/// ```
pub fn instantiate(st_p0: &crate::check::types::St, sc_p1: &crate::check::types::Scheme, span_p2: &crate::syntax::Range) -> (crate::check::types::Ty, crate::check::types::St) {
    let (t_p3, st2_p4, _) = instantiate_with(st_p0, sc_p1, span_p2, &Array::new());
    (t_p3.clone(), st2_p4.clone())
}

/// The step machine of `Instantiate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Instantiate: unbounded fn St, Scheme, Range -> ((Ty, St))
/// ```
pub struct Instantiate {
    pub st_p0: crate::check::types::St,
    pub sc_p1: crate::check::types::Scheme,
    pub span_p2: crate::syntax::Range,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)> for Instantiate {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let sc_p1 = &self.sc_p1;
        let span_p2 = &self.span_p2;
        let sc_p1 = sc_p1.clone();
        let span_p2 = span_p2.clone();
        let st_p0 = st_p0.clone();
        call_then(start_instantiate_with(st_p0.clone(), sc_p1.clone(), span_p2.clone(), Array::new()), move |instantiate_with_2231: (crate::check::types::Ty, crate::check::types::St, Inst)| {
            let (t_p3, st2_p4, _) = instantiate_with_2231;
            prism_rtl::Turn::Finished((t_p3.clone(), st2_p4.clone()))
        })
    }
}

/// `Start Instantiate, x`: what the function value is when passed to `@Run`.
pub fn start_instantiate(st_p0: crate::check::types::St, sc_p1: crate::check::types::Scheme, span_p2: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St)>> {
    Rc::new(Instantiate { st_p0, sc_p1, span_p2 })
}

/// ```prism
/// InstantiateWith: unbounded fn St, Scheme, Range, [Ty] -> ((Ty, St, Inst))
/// ```
pub fn instantiate_with(st_p0: &crate::check::types::St, sc_p1: &crate::check::types::Scheme, span_p2: &crate::syntax::Range, explicit_p3: &Array<crate::check::types::Ty>) -> (crate::check::types::Ty, crate::check::types::St, Inst) {
    let (tys_pf, st1_pg) = fold(&crate::check::errors::range0(&len(&sc_p1.qs)), &(Map::new(), st_p0.clone()), &(|(m_p8, s_p9): &(Map<Text, crate::check::types::Ty>, crate::check::types::St), i_pa: &Nat| {
        let q_pb = or(&index(&sc_p1.qs, i_pa), &Text::lit(""));
        match index(explicit_p3, i_pa) {
            Some(g_pc) => (insert(m_p8, &q_pb, &g_pc), s_p9.clone()),
            None => {
                let (v_pd, s2_pe) = crate::check::types::fresh_var(s_p9, &crate::check::types::has_text(&sc_p1.plain_qs, &q_pb), &Text::lit(""));
                (insert(m_p8, &q_pb, &v_pd), s2_pe.clone())
            },
        }
    }));
    let nq_p4 = len(&sc_p1.qs);
    let (rows_pm, st2_pn) = run_to_end(fold_job(sc_p1.rqs.clone(), (Map::new(), st1_pg.clone()), {
        let sc_p1 = sc_p1.clone();
        Rc::new(move |(p0, p1): ((Map<Text, crate::check::types::Tail>, crate::check::types::St), Text)| {
            let sc_p1 = sc_p1.clone();
            entered(once_job(move || {
                let (m_ph, s_pi) = p0;
                let q_pj = p1;
                call_then(start_lacks_in(sc_p1.ty.clone(), q_pj.clone()), move |lacks_in_2973: Array<Text>| {
                    let (rw_pk, s2_pl) = crate::check::types::recording::fresh_row(&s_pi, &lacks_in_2973);
                    prism_rtl::Turn::Finished((insert(&m_ph, &q_pj, &rw_pk.tail), crate::check::types::unify::name_row(&s2_pl, &rw_pk.tail, &q_pj)))
                })
            }))
        }) as Rc<dyn Fn(((Map<Text, crate::check::types::Tail>, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, crate::check::types::Tail>, crate::check::types::St)>>>
    }));
    let (cols_pt, st2b_pu) = fold(&sc_p1.cqs, &(Map::new(), st2_pn.clone()), &(|(m_po, s_pp): &(Map<Text, crate::check::types::Col>, crate::check::types::St), q_pq: &Text| {
        let (c_pr, s2_ps) = crate::check::types::fresh_col(s_pp);
        (insert(m_po, q_pq, &c_pr), s2_ps.clone())
    }));
    let inst_p5 = Inst { tys: tys_pf.clone(), rows: rows_pm.clone(), cols: cols_pt.clone() };
    let st2c_p6 = run_to_end(fold_job(sc_p1.cjoins.clone(), st2b_pu.clone(), {
        let cols_pt = cols_pt.clone();
        let span_p2 = span_p2.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, (Text, Text))| {
            let cols_pt = cols_pt.clone();
            let span_p2 = span_p2.clone();
            entered(once_job(move || {
                let s_pv = p0;
                let (lo_p10, hi_p11) = p1;
                prism_rtl::Turn::More(Rc::new(crate::check::types::colors::AddLeq { st_p0: s_pv.clone(), lo0_p1: or(&get(&cols_pt, &lo_p10), &crate::check::types::Col::CBound), hi0_p2: or(&get(&cols_pt, &hi_p11), &crate::check::types::Col::CBound), span_p3: span_p2.clone(), kind_p4: Text::lit("arg"), name_p5: Text::lit(""), why_p6: Text::lit("") }))
            }))
        }) as Rc<dyn Fn((crate::check::types::St, (Text, Text))) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }));
    let st3_p7 = fold(&sc_p1.bounds, &st2c_p6, &(|s_p12: &crate::check::types::St, (v_p13, tr_p14): &(Text, Text)| {
        let mut this: crate::check::types::St = s_p12.clone();
        this.wants = push(&this.wants, &crate::check::types::Want { cls: tr_p14.clone(), ty: or(&get(&tys_pf, v_p13), &crate::check::types::Ty::TyErr), file: s_p12.file.clone(), span: span_p2.clone(), level: s_p12.level.clone() });
        this
    }));
    (subst_q(&inst_p5, &sc_p1.ty), st3_p7.clone(), inst_p5.clone())
}

/// The step machine of `InstantiateWith`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InstantiateWith: unbounded fn St, Scheme, Range, [Ty] -> ((Ty, St, Inst))
/// ```
pub struct InstantiateWith {
    pub st_p0: crate::check::types::St,
    pub sc_p1: crate::check::types::Scheme,
    pub span_p2: crate::syntax::Range,
    pub explicit_p3: Array<crate::check::types::Ty>,
}

impl prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St, Inst)> for InstantiateWith {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Ty, crate::check::types::St, Inst)> {
        let st_p0 = &self.st_p0;
        let sc_p1 = &self.sc_p1;
        let span_p2 = &self.span_p2;
        let explicit_p3 = &self.explicit_p3;
        let (tys_pf, st1_pg) = fold(&crate::check::errors::range0(&len(&sc_p1.qs)), &(Map::new(), st_p0.clone()), &(|(m_p8, s_p9): &(Map<Text, crate::check::types::Ty>, crate::check::types::St), i_pa: &Nat| {
            let q_pb = or(&index(&sc_p1.qs, i_pa), &Text::lit(""));
            match index(explicit_p3, i_pa) {
                Some(g_pc) => (insert(m_p8, &q_pb, &g_pc), s_p9.clone()),
                None => {
                    let (v_pd, s2_pe) = crate::check::types::fresh_var(s_p9, &crate::check::types::has_text(&sc_p1.plain_qs, &q_pb), &Text::lit(""));
                    (insert(m_p8, &q_pb, &v_pd), s2_pe.clone())
                },
            }
        }));
        let nq_p4 = len(&sc_p1.qs);
        let sc_p1 = sc_p1.clone();
        let span_p2 = span_p2.clone();
        call_value(fold_job(sc_p1.rqs.clone(), (Map::new(), st1_pg.clone()), {
            let sc_p1 = sc_p1.clone();
            Rc::new(move |(p0, p1): ((Map<Text, crate::check::types::Tail>, crate::check::types::St), Text)| {
                let sc_p1 = sc_p1.clone();
                entered(once_job(move || {
                    let (m_ph, s_pi) = p0;
                    let q_pj = p1;
                    call_then(start_lacks_in(sc_p1.ty.clone(), q_pj.clone()), move |lacks_in_2973: Array<Text>| {
                        let (rw_pk, s2_pl) = crate::check::types::recording::fresh_row(&s_pi, &lacks_in_2973);
                        prism_rtl::Turn::Finished((insert(&m_ph, &q_pj, &rw_pk.tail), crate::check::types::unify::name_row(&s2_pl, &rw_pk.tail, &q_pj)))
                    })
                }))
            }) as Rc<dyn Fn(((Map<Text, crate::check::types::Tail>, crate::check::types::St), Text)) -> Rc<dyn prism_rtl::Job<(Map<Text, crate::check::types::Tail>, crate::check::types::St)>>>
        }), move |fold_2894: (Map<Text, crate::check::types::Tail>, crate::check::types::St)| {
            let (rows_pm, st2_pn) = fold_2894;
            let (cols_pt, st2b_pu) = fold(&sc_p1.cqs, &(Map::new(), st2_pn.clone()), &(|(m_po, s_pp): &(Map<Text, crate::check::types::Col>, crate::check::types::St), q_pq: &Text| {
                let (c_pr, s2_ps) = crate::check::types::fresh_col(s_pp);
                (insert(m_po, q_pq, &c_pr), s2_ps.clone())
            }));
            let inst_p5 = Inst { tys: tys_pf.clone(), rows: rows_pm.clone(), cols: cols_pt.clone() };
            call_value(fold_job(sc_p1.cjoins.clone(), st2b_pu.clone(), {
                let cols_pt = cols_pt.clone();
                let span_p2 = span_p2.clone();
                Rc::new(move |(p0, p1): (crate::check::types::St, (Text, Text))| {
                    let cols_pt = cols_pt.clone();
                    let span_p2 = span_p2.clone();
                    entered(once_job(move || {
                        let s_pv = p0;
                        let (lo_p10, hi_p11) = p1;
                        prism_rtl::Turn::More(Rc::new(crate::check::types::colors::AddLeq { st_p0: s_pv.clone(), lo0_p1: or(&get(&cols_pt, &lo_p10), &crate::check::types::Col::CBound), hi0_p2: or(&get(&cols_pt, &hi_p11), &crate::check::types::Col::CBound), span_p3: span_p2.clone(), kind_p4: Text::lit("arg"), name_p5: Text::lit(""), why_p6: Text::lit("") }))
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, (Text, Text))) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            }), move |fold_3252: crate::check::types::St| {
                let st2c_p6 = fold_3252;
                let st3_p7 = fold(&sc_p1.bounds, &st2c_p6, &(|s_p12: &crate::check::types::St, (v_p13, tr_p14): &(Text, Text)| {
                    let mut this: crate::check::types::St = s_p12.clone();
                    this.wants = push(&this.wants, &crate::check::types::Want { cls: tr_p14.clone(), ty: or(&get(&tys_pf, v_p13), &crate::check::types::Ty::TyErr), file: s_p12.file.clone(), span: span_p2.clone(), level: s_p12.level.clone() });
                    this
                }));
                call_then(start_subst_q(inst_p5.clone(), sc_p1.ty.clone()), move |subst_q_3546: crate::check::types::Ty| prism_rtl::Turn::Finished((subst_q_3546, st3_p7.clone(), inst_p5.clone())))
            })
        })
    }
}

/// `Start InstantiateWith, x`: what the function value is when passed to `@Run`.
pub fn start_instantiate_with(st_p0: crate::check::types::St, sc_p1: crate::check::types::Scheme, span_p2: crate::syntax::Range, explicit_p3: Array<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<(crate::check::types::Ty, crate::check::types::St, Inst)>> {
    Rc::new(InstantiateWith { st_p0, sc_p1, span_p2, explicit_p3 })
}

/// ```prism
/// LacksIn: unbounded fn Ty, Text -> [Text]
/// ```
pub fn lacks_in(t_p0: &crate::check::types::Ty, q_p1: &Text) -> Array<Text> {
    match t_p0 {
        crate::check::types::Ty::TyCon(_, args_p2) => run_to_end(fold_job(args_p2.clone(), Array::new(), {
            let q_p1 = q_p1.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                let q_p1 = q_p1.clone();
                entered(once_job(move || {
                    let acc_p3 = p0;
                    let a_p4 = p1;
                    call_then(start_lacks_in(a_p4.clone(), q_p1.clone()), move |lacks_in_3833: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc_p3, &lacks_in_3833)))
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        })),
        crate::check::types::Ty::TyFn(_, ps_p5, r_p6) => run_to_end(fold_job(ps_p5.clone(), lacks_in(&**r_p6, q_p1), {
            let q_p1 = q_p1.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                let q_p1 = q_p1.clone();
                entered(once_job(move || {
                    let acc_p7 = p0;
                    let a_p8 = p1;
                    call_then(start_lacks_in(a_p8.clone(), q_p1.clone()), move |lacks_in_3923: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc_p7, &lacks_in_3923)))
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        })),
        crate::check::types::Ty::TyTuple(ts_p9) => run_to_end(fold_job(ts_p9.clone(), Array::new(), {
            let q_p1 = q_p1.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                let q_p1 = q_p1.clone();
                entered(once_job(move || {
                    let acc_pa = p0;
                    let a_pb = p1;
                    call_then(start_lacks_in(a_pb.clone(), q_p1.clone()), move |lacks_in_3995: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc_pa, &lacks_in_3995)))
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        })),
        crate::check::types::Ty::TyArray(e_pc) => lacks_in(&**e_pc, q_p1),
        crate::check::types::Ty::TyMap(k_pd, v_pe) => crate::check::types::union_texts(&lacks_in(&**k_pd, q_p1), &lacks_in(&**v_pe, q_p1)),
        crate::check::types::Ty::TySig(_, i_pf) => lacks_in(&**i_pf, q_p1),
        crate::check::types::Ty::TyAt(i_pg, rw_ph) => crate::check::types::union_texts(&lacks_in(&**i_pg, q_p1), &row_lacks(rw_ph, q_p1)),
        crate::check::types::Ty::TyElem(rw_pi, o_pj) => crate::check::types::union_texts(&lacks_in(&**o_pj, q_p1), &row_lacks(rw_pi, q_p1)),
        crate::check::types::Ty::TyElemAny(rw_pk) => row_lacks(rw_pk, q_p1),
        _ => Array::new(),
    }
}

/// The step machine of `LacksIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LacksIn: unbounded fn Ty, Text -> [Text]
/// ```
pub struct LacksIn {
    pub t_p0: crate::check::types::Ty,
    pub q_p1: Text,
}

impl prism_rtl::Job<Array<Text>> for LacksIn {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let t_p0 = &self.t_p0;
        let q_p1 = &self.q_p1;
        match t_p0 {
            crate::check::types::Ty::TyCon(_, args_p2) => fold_job(args_p2.clone(), Array::new(), {
                let q_p1 = q_p1.clone();
                Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                    let q_p1 = q_p1.clone();
                    entered(once_job(move || {
                        let acc_p3 = p0;
                        let a_p4 = p1;
                        call_then(start_lacks_in(a_p4.clone(), q_p1.clone()), move |lacks_in_3833: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc_p3, &lacks_in_3833)))
                    }))
                }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }).cycle(),
            crate::check::types::Ty::TyFn(_, ps_p5, r_p6) => {
                let ps_p5 = ps_p5.clone();
                let q_p1 = q_p1.clone();
                let r_p6 = (**r_p6).clone();
                call_then(start_lacks_in(r_p6.clone(), q_p1.clone()), move |lacks_in_3881: Array<Text>| fold_job(ps_p5.clone(), lacks_in_3881, {
                    let q_p1 = q_p1.clone();
                    Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                        let q_p1 = q_p1.clone();
                        entered(once_job(move || {
                            let acc_p7 = p0;
                            let a_p8 = p1;
                            call_then(start_lacks_in(a_p8.clone(), q_p1.clone()), move |lacks_in_3923: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc_p7, &lacks_in_3923)))
                        }))
                    }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }).cycle())
            },
            crate::check::types::Ty::TyTuple(ts_p9) => fold_job(ts_p9.clone(), Array::new(), {
                let q_p1 = q_p1.clone();
                Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                    let q_p1 = q_p1.clone();
                    entered(once_job(move || {
                        let acc_pa = p0;
                        let a_pb = p1;
                        call_then(start_lacks_in(a_pb.clone(), q_p1.clone()), move |lacks_in_3995: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc_pa, &lacks_in_3995)))
                    }))
                }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }).cycle(),
            crate::check::types::Ty::TyArray(e_pc) => prism_rtl::Turn::More(Rc::new(LacksIn { t_p0: (**e_pc).clone(), q_p1: q_p1.clone() })),
            crate::check::types::Ty::TyMap(k_pd, v_pe) => {
                let k_pd = (**k_pd).clone();
                let q_p1 = q_p1.clone();
                let v_pe = (**v_pe).clone();
                call_then(start_lacks_in(k_pd.clone(), q_p1.clone()), move |lacks_in_4065: Array<Text>| call_then(start_lacks_in(v_pe.clone(), q_p1.clone()), move |lacks_in_4081: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&lacks_in_4065, &lacks_in_4081))))
            },
            crate::check::types::Ty::TySig(_, i_pf) => prism_rtl::Turn::More(Rc::new(LacksIn { t_p0: (**i_pf).clone(), q_p1: q_p1.clone() })),
            crate::check::types::Ty::TyAt(i_pg, rw_ph) => {
                let i_pg = (**i_pg).clone();
                let q_p1 = q_p1.clone();
                let rw_ph = rw_ph.clone();
                call_then(start_lacks_in(i_pg.clone(), q_p1.clone()), move |lacks_in_4157: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&lacks_in_4157, &row_lacks(&rw_ph, &q_p1))))
            },
            crate::check::types::Ty::TyElem(rw_pi, o_pj) => {
                let o_pj = (**o_pj).clone();
                let q_p1 = q_p1.clone();
                let rw_pi = rw_pi.clone();
                call_then(start_lacks_in(o_pj.clone(), q_p1.clone()), move |lacks_in_4219: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&lacks_in_4219, &row_lacks(&rw_pi, &q_p1))))
            },
            crate::check::types::Ty::TyElemAny(rw_pk) => prism_rtl::Turn::Finished(row_lacks(rw_pk, q_p1)),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start LacksIn, x`: what the function value is when passed to `@Run`.
pub fn start_lacks_in(t_p0: crate::check::types::Ty, q_p1: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(LacksIn { t_p0, q_p1 })
}

/// ```prism
/// RowLacks: fn Rw, Text -> [Text]
/// ```
pub fn row_lacks(rw_p0: &crate::check::types::Rw, q_p1: &Text) -> Array<Text> {
    if &rw_p0.tail == &crate::check::types::Tail::TlQ(q_p1.clone()) {
        rw_p0.fams.clone()
    } else {
        Array::new()
    }
}

/// ```prism
/// Skolemize: unbounded fn Scheme -> Ty
/// ```
pub fn skolemize(sc_p0: &crate::check::types::Scheme) -> crate::check::types::Ty {
    let tys_p1 = fold(&sc_p0.qs, &Map::new(), &(|m_p4: &Map<Text, crate::check::types::Ty>, q_p5: &Text| insert(m_p4, q_p5, &crate::check::types::Ty::TyRigid(q_p5.clone()))));
    let rows_p2 = fold(&sc_p0.rqs, &Map::new(), &(|m_p6: &Map<Text, crate::check::types::Tail>, q_p7: &Text| insert(m_p6, q_p7, &crate::check::types::Tail::TlRigid(q_p7.clone()))));
    let cols_p3 = fold(&sc_p0.cqs, &Map::new(), &(|m_p8: &Map<Text, crate::check::types::Col>, q_p9: &Text| insert(m_p8, q_p9, &crate::check::types::Col::CRigid(q_p9.clone()))));
    subst_q(&Inst { tys: tys_p1.clone(), rows: rows_p2.clone(), cols: cols_p3.clone() }, &sc_p0.ty)
}

/// The step machine of `Skolemize`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Skolemize: unbounded fn Scheme -> Ty
/// ```
pub struct Skolemize {
    pub sc_p0: crate::check::types::Scheme,
}

impl prism_rtl::Job<crate::check::types::Ty> for Skolemize {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let sc_p0 = &self.sc_p0;
        let tys_p1 = fold(&sc_p0.qs, &Map::new(), &(|m_p4: &Map<Text, crate::check::types::Ty>, q_p5: &Text| insert(m_p4, q_p5, &crate::check::types::Ty::TyRigid(q_p5.clone()))));
        let rows_p2 = fold(&sc_p0.rqs, &Map::new(), &(|m_p6: &Map<Text, crate::check::types::Tail>, q_p7: &Text| insert(m_p6, q_p7, &crate::check::types::Tail::TlRigid(q_p7.clone()))));
        let cols_p3 = fold(&sc_p0.cqs, &Map::new(), &(|m_p8: &Map<Text, crate::check::types::Col>, q_p9: &Text| insert(m_p8, q_p9, &crate::check::types::Col::CRigid(q_p9.clone()))));
        prism_rtl::Turn::More(Rc::new(SubstQ { m_p0: Inst { tys: tys_p1.clone(), rows: rows_p2.clone(), cols: cols_p3.clone() }, t_p1: sc_p0.ty.clone() }))
    }
}

/// `Start Skolemize, x`: what the function value is when passed to `@Run`.
pub fn start_skolemize(sc_p0: crate::check::types::Scheme) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(Skolemize { sc_p0 })
}

/// ```prism
/// Generalize: unbounded fn St, Ty, [Nat], [((Nat, Text))] -> ((Scheme, St))
/// ```
pub fn generalize(st0_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty, keep_p2: &Array<Nat>, bounds_p3: &Array<(Nat, Text)>) -> (crate::check::types::Scheme, crate::check::types::St) {
    let waiting_p4 = run_to_end(fold_job(st0_p0.field_qs.clone(), Array::new(), {
        let st0_p0 = st0_p0.clone();
        Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::unify::FieldQ)| {
            let st0_p0 = st0_p0.clone();
            entered(once_job(move || {
                let acc_pf = p0;
                let q_pg = p1;
                call_then(crate::check::types::recording::start_free_vars_into(st0_p0.clone(), acc_pf.clone(), q_pg.recv.clone()), move |free_vars_into_5383: Array<Nat>| prism_rtl::Turn::More(Rc::new(crate::check::types::recording::FreeVarsInto { st_p0: st0_p0.clone(), acc_p1: free_vars_into_5383, t_p2: q_pg.result.clone() })))
            }))
        }) as Rc<dyn Fn((Array<Nat>, crate::check::types::unify::FieldQ)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
    }));
    let st_p5 = crate::check::types::colors::generalize_cols(&crate::check::types::unify::lower_levels(st0_p0, &waiting_p4, &st0_p0.level));
    let z_p6 = crate::check::types::recording::zonk(&st_p5, t_p1);
    let vs_p7 = filter(&crate::check::types::recording::free_vars(&st_p5, &z_p6), &(|v_ph: &Nat| (&crate::check::types::recording::info_of(&st_p5, v_ph).level > &st_p5.level) && !crate::check::types::has_nat(keep_p2, v_ph)));
    let cvs_p8 = filter(&crate::check::types::colors::free_col_vars(&st_p5, &z_p6), &(|v_pi: &Nat| &crate::check::types::recording::info_of(&st_p5, v_pi).level > &st_p5.level));
    let tys_p9 = fold(&vs_p7, &Map::new(), &(|m_pj: &Map<Nat, crate::check::types::Ty>, v_pk: &Nat| insert(m_pj, v_pk, &crate::check::types::Ty::TyQ(Text::from(format!("\'{}", v_pk))))));
    let cols_pa = fold(&cvs_p8, &Map::new(), &(|m_pl: &Map<Nat, crate::check::types::Col>, v_pm: &Nat| insert(m_pl, v_pm, &crate::check::types::Col::CQ(Text::from(format!("\'c{}", v_pm))))));
    let named_pb = subst_flex(&tys_p9, &cols_pa, &z_p6);
    let plains_pc = each(&filter(&vs_p7, &(|v_pn: &Nat| crate::check::types::recording::info_of(&st_p5, v_pn).plain)), &(|v_po: &Nat| Text::from(format!("\'{}", v_po))));
    let bs_pd = each(&filter(bounds_p3, &(|(v_pp, _): &(Nat, Text)| crate::check::types::has_nat(&vs_p7, v_pp))), &(|(v_pq, tr_pr): &(Nat, Text)| (Text::from(format!("\'{}", v_pq)), tr_pr.clone())));
    let st2_pe = {
        let mut this: crate::check::types::St = st_p5.clone();
        this.col_q = fold(&cvs_p8, &this.col_q, &(|m_ps: &Map<Nat, Text>, v_pt: &Nat| insert(m_ps, v_pt, &Text::from(format!("\'c{}", v_pt)))));
        this
    };
    (crate::check::types::Scheme { qs: each(&vs_p7, &(|v_pu: &Nat| Text::from(format!("\'{}", v_pu)))), plain_qs: plains_pc.clone(), rqs: Array::new(), cqs: each(&cvs_p8, &(|v_pv: &Nat| Text::from(format!("\'c{}", v_pv)))), cjoins: Array::new(), bounds: bs_pd.clone(), ty: named_pb.clone() }, st2_pe.clone())
}

/// The step machine of `Generalize`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Generalize: unbounded fn St, Ty, [Nat], [((Nat, Text))] -> ((Scheme, St))
/// ```
pub struct Generalize {
    pub st0_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
    pub keep_p2: Array<Nat>,
    pub bounds_p3: Array<(Nat, Text)>,
}

impl prism_rtl::Job<(crate::check::types::Scheme, crate::check::types::St)> for Generalize {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check::types::Scheme, crate::check::types::St)> {
        let st0_p0 = &self.st0_p0;
        let t_p1 = &self.t_p1;
        let keep_p2 = &self.keep_p2;
        let bounds_p3 = &self.bounds_p3;
        let bounds_p3 = bounds_p3.clone();
        let keep_p2 = keep_p2.clone();
        let st0_p0 = st0_p0.clone();
        let t_p1 = t_p1.clone();
        call_value(fold_job(st0_p0.field_qs.clone(), Array::new(), {
            let st0_p0 = st0_p0.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::unify::FieldQ)| {
                let st0_p0 = st0_p0.clone();
                entered(once_job(move || {
                    let acc_pf = p0;
                    let q_pg = p1;
                    call_then(crate::check::types::recording::start_free_vars_into(st0_p0.clone(), acc_pf.clone(), q_pg.recv.clone()), move |free_vars_into_5383: Array<Nat>| prism_rtl::Turn::More(Rc::new(crate::check::types::recording::FreeVarsInto { st_p0: st0_p0.clone(), acc_p1: free_vars_into_5383, t_p2: q_pg.result.clone() })))
                }))
            }) as Rc<dyn Fn((Array<Nat>, crate::check::types::unify::FieldQ)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        }), move |fold_5330: Array<Nat>| {
            let waiting_p4 = fold_5330;
            call_then(crate::check::types::colors::start_generalize_cols(crate::check::types::unify::lower_levels(&st0_p0, &waiting_p4, &st0_p0.level)), move |generalize_cols_5437: crate::check::types::St| {
                let st_p5 = generalize_cols_5437;
                call_then(crate::check::types::recording::start_zonk(st_p5.clone(), t_p1.clone()), move |zonk_5502: crate::check::types::Ty| {
                    let z_p6 = zonk_5502;
                    call_then(crate::check::types::recording::start_free_vars(st_p5.clone(), z_p6.clone()), move |free_vars_5534: Array<Nat>| {
                        let vs_p7 = filter(&free_vars_5534, &(|v_ph: &Nat| (&crate::check::types::recording::info_of(&st_p5, v_ph).level > &st_p5.level) && !crate::check::types::has_nat(&keep_p2, v_ph)));
                        call_then(crate::check::types::colors::start_free_col_vars(st_p5.clone(), z_p6.clone()), move |free_col_vars_5635: Array<Nat>| {
                            let cvs_p8 = filter(&free_col_vars_5635, &(|v_pi: &Nat| &crate::check::types::recording::info_of(&st_p5, v_pi).level > &st_p5.level));
                            let tys_p9 = fold(&vs_p7, &Map::new(), &(|m_pj: &Map<Nat, crate::check::types::Ty>, v_pk: &Nat| insert(m_pj, v_pk, &crate::check::types::Ty::TyQ(Text::from(format!("\'{}", v_pk))))));
                            let cols_pa = fold(&cvs_p8, &Map::new(), &(|m_pl: &Map<Nat, crate::check::types::Col>, v_pm: &Nat| insert(m_pl, v_pm, &crate::check::types::Col::CQ(Text::from(format!("\'c{}", v_pm))))));
                            call_then(start_subst_flex(tys_p9.clone(), cols_pa.clone(), z_p6.clone()), move |subst_flex_5832: crate::check::types::Ty| {
                                let named_pb = subst_flex_5832;
                                let plains_pc = each(&filter(&vs_p7, &(|v_pn: &Nat| crate::check::types::recording::info_of(&st_p5, v_pn).plain)), &(|v_po: &Nat| Text::from(format!("\'{}", v_po))));
                                let bs_pd = each(&filter(&bounds_p3, &(|(v_pp, _): &(Nat, Text)| crate::check::types::has_nat(&vs_p7, v_pp))), &(|(v_pq, tr_pr): &(Nat, Text)| (Text::from(format!("\'{}", v_pq)), tr_pr.clone())));
                                let st2_pe = {
                                    let mut this: crate::check::types::St = st_p5.clone();
                                    this.col_q = fold(&cvs_p8, &this.col_q, &(|m_ps: &Map<Nat, Text>, v_pt: &Nat| insert(m_ps, v_pt, &Text::from(format!("\'c{}", v_pt)))));
                                    this
                                };
                                prism_rtl::Turn::Finished((crate::check::types::Scheme { qs: each(&vs_p7, &(|v_pu: &Nat| Text::from(format!("\'{}", v_pu)))), plain_qs: plains_pc.clone(), rqs: Array::new(), cqs: each(&cvs_p8, &(|v_pv: &Nat| Text::from(format!("\'c{}", v_pv)))), cjoins: Array::new(), bounds: bs_pd.clone(), ty: named_pb.clone() }, st2_pe.clone()))
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start Generalize, x`: what the function value is when passed to `@Run`.
pub fn start_generalize(st0_p0: crate::check::types::St, t_p1: crate::check::types::Ty, keep_p2: Array<Nat>, bounds_p3: Array<(Nat, Text)>) -> Rc<dyn prism_rtl::Job<(crate::check::types::Scheme, crate::check::types::St)>> {
    Rc::new(Generalize { st0_p0, t_p1, keep_p2, bounds_p3 })
}

/// ```prism
/// SubstFlex: unbounded fn (Nat ==> Ty), (Nat ==> Col), Ty -> Ty
/// ```
pub fn subst_flex(m_p0: &Map<Nat, crate::check::types::Ty>, cm_p1: &Map<Nat, crate::check::types::Col>, t_p2: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p2 {
        crate::check::types::Ty::TyFlex(n_p3) => or(&get(m_p0, n_p3), &crate::check::types::Ty::TyFlex(n_p3.clone())),
        crate::check::types::Ty::TyCon(n_p4, args_p5) => crate::check::types::Ty::TyCon(n_p4.clone(), run_to_end(each_job(args_p5.clone(), {
            let m_p0 = m_p0.clone();
            let cm_p1 = cm_p1.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let m_p0 = m_p0.clone();
                let cm_p1 = cm_p1.clone();
                entered(once_job(move || {
                    let a_p6 = p0;
                    prism_rtl::Turn::More(Rc::new(SubstFlex { m_p0: m_p0.clone(), cm_p1: cm_p1.clone(), t_p2: a_p6.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyFn(c_p7, ps_p8, res_p9) => {
            let c2_pa = match c_p7 {
                crate::check::types::Col::CFlex(n_pb) => or(&get(cm_p1, n_pb), c_p7),
                other_pc => other_pc.clone(),
            };
            crate::check::types::Ty::TyFn(c2_pa.clone(), run_to_end(each_job(ps_p8.clone(), {
                let m_p0 = m_p0.clone();
                let cm_p1 = cm_p1.clone();
                Rc::new(move |p0: crate::check::types::Ty| {
                    let m_p0 = m_p0.clone();
                    let cm_p1 = cm_p1.clone();
                    entered(once_job(move || {
                        let p_pd = p0;
                        prism_rtl::Turn::More(Rc::new(SubstFlex { m_p0: m_p0.clone(), cm_p1: cm_p1.clone(), t_p2: p_pd.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
            })), Rc::new(subst_flex(m_p0, cm_p1, &**res_p9)))
        },
        crate::check::types::Ty::TyTuple(ts_pe) => crate::check::types::Ty::TyTuple(run_to_end(each_job(ts_pe.clone(), {
            let m_p0 = m_p0.clone();
            let cm_p1 = cm_p1.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let m_p0 = m_p0.clone();
                let cm_p1 = cm_p1.clone();
                entered(once_job(move || {
                    let a_pf = p0;
                    prism_rtl::Turn::More(Rc::new(SubstFlex { m_p0: m_p0.clone(), cm_p1: cm_p1.clone(), t_p2: a_pf.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyArray(e_pg) => crate::check::types::Ty::TyArray(Rc::new(subst_flex(m_p0, cm_p1, &**e_pg))),
        crate::check::types::Ty::TyMap(k_ph, v_pi) => crate::check::types::Ty::TyMap(Rc::new(subst_flex(m_p0, cm_p1, &**k_ph)), Rc::new(subst_flex(m_p0, cm_p1, &**v_pi))),
        crate::check::types::Ty::TySig(s_pj, i_pk) => crate::check::types::Ty::TySig(s_pj.clone(), Rc::new(subst_flex(m_p0, cm_p1, &**i_pk))),
        crate::check::types::Ty::TyAt(i_pl, rw_pm) => crate::check::types::Ty::TyAt(Rc::new(subst_flex(m_p0, cm_p1, &**i_pl)), rw_pm.clone()),
        crate::check::types::Ty::TyElem(rw_pn, o_po) => crate::check::types::Ty::TyElem(rw_pn.clone(), Rc::new(subst_flex(m_p0, cm_p1, &**o_po))),
        crate::check::types::Ty::TyAssoc(n_pp, a_pq) => crate::check::types::Ty::TyAssoc(n_pp.clone(), Rc::new(subst_flex(m_p0, cm_p1, &**a_pq))),
        other_pr => other_pr.clone(),
    }
}

/// The step machine of `SubstFlex`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SubstFlex: unbounded fn (Nat ==> Ty), (Nat ==> Col), Ty -> Ty
/// ```
pub struct SubstFlex {
    pub m_p0: Map<Nat, crate::check::types::Ty>,
    pub cm_p1: Map<Nat, crate::check::types::Col>,
    pub t_p2: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::Ty> for SubstFlex {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let m_p0 = &self.m_p0;
        let cm_p1 = &self.cm_p1;
        let t_p2 = &self.t_p2;
        match t_p2 {
            crate::check::types::Ty::TyFlex(n_p3) => prism_rtl::Turn::Finished(or(&get(m_p0, n_p3), &crate::check::types::Ty::TyFlex(n_p3.clone()))),
            crate::check::types::Ty::TyCon(n_p4, args_p5) => {
                let args_p5 = args_p5.clone();
                let cm_p1 = cm_p1.clone();
                let m_p0 = m_p0.clone();
                let n_p4 = n_p4.clone();
                call_value(each_job(args_p5.clone(), {
                    let m_p0 = m_p0.clone();
                    let cm_p1 = cm_p1.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let m_p0 = m_p0.clone();
                        let cm_p1 = cm_p1.clone();
                        entered(once_job(move || {
                            let a_p6 = p0;
                            prism_rtl::Turn::More(Rc::new(SubstFlex { m_p0: m_p0.clone(), cm_p1: cm_p1.clone(), t_p2: a_p6.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_6411: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyCon(n_p4.clone(), each_6411)))
            },
            crate::check::types::Ty::TyFn(c_p7, ps_p8, res_p9) => {
                let c2_pa = match c_p7 {
                    crate::check::types::Col::CFlex(n_pb) => or(&get(cm_p1, n_pb), c_p7),
                    other_pc => other_pc.clone(),
                };
                let cm_p1 = cm_p1.clone();
                let m_p0 = m_p0.clone();
                let ps_p8 = ps_p8.clone();
                let res_p9 = (**res_p9).clone();
                call_value(each_job(ps_p8.clone(), {
                    let m_p0 = m_p0.clone();
                    let cm_p1 = cm_p1.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let m_p0 = m_p0.clone();
                        let cm_p1 = cm_p1.clone();
                        entered(once_job(move || {
                            let p_pd = p0;
                            prism_rtl::Turn::More(Rc::new(SubstFlex { m_p0: m_p0.clone(), cm_p1: cm_p1.clone(), t_p2: p_pd.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_6570: Array<crate::check::types::Ty>| call_then(start_subst_flex(m_p0.clone(), cm_p1.clone(), res_p9.clone()), move |subst_flex_6606: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyFn(c2_pa.clone(), each_6570, Rc::new(subst_flex_6606)))))
            },
            crate::check::types::Ty::TyTuple(ts_pe) => {
                let cm_p1 = cm_p1.clone();
                let m_p0 = m_p0.clone();
                let ts_pe = ts_pe.clone();
                call_value(each_job(ts_pe.clone(), {
                    let m_p0 = m_p0.clone();
                    let cm_p1 = cm_p1.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let m_p0 = m_p0.clone();
                        let cm_p1 = cm_p1.clone();
                        entered(once_job(move || {
                            let a_pf = p0;
                            prism_rtl::Turn::More(Rc::new(SubstFlex { m_p0: m_p0.clone(), cm_p1: cm_p1.clone(), t_p2: a_pf.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_6653: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyTuple(each_6653)))
            },
            crate::check::types::Ty::TyArray(e_pg) => {
                let cm_p1 = cm_p1.clone();
                let e_pg = (**e_pg).clone();
                let m_p0 = m_p0.clone();
                call_then(start_subst_flex(m_p0.clone(), cm_p1.clone(), e_pg.clone()), move |subst_flex_6711: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyArray(Rc::new(subst_flex_6711))))
            },
            crate::check::types::Ty::TyMap(k_ph, v_pi) => {
                let cm_p1 = cm_p1.clone();
                let k_ph = (**k_ph).clone();
                let m_p0 = m_p0.clone();
                let v_pi = (**v_pi).clone();
                call_then(start_subst_flex(m_p0.clone(), cm_p1.clone(), k_ph.clone()), move |subst_flex_6754: crate::check::types::Ty| call_then(start_subst_flex(m_p0.clone(), cm_p1.clone(), v_pi.clone()), move |subst_flex_6776: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyMap(Rc::new(subst_flex_6754), Rc::new(subst_flex_6776)))))
            },
            crate::check::types::Ty::TySig(s_pj, i_pk) => {
                let cm_p1 = cm_p1.clone();
                let i_pk = (**i_pk).clone();
                let m_p0 = m_p0.clone();
                let s_pj = s_pj.clone();
                call_then(start_subst_flex(m_p0.clone(), cm_p1.clone(), i_pk.clone()), move |subst_flex_6822: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TySig(s_pj.clone(), Rc::new(subst_flex_6822))))
            },
            crate::check::types::Ty::TyAt(i_pl, rw_pm) => {
                let cm_p1 = cm_p1.clone();
                let i_pl = (**i_pl).clone();
                let m_p0 = m_p0.clone();
                let rw_pm = rw_pm.clone();
                call_then(start_subst_flex(m_p0.clone(), cm_p1.clone(), i_pl.clone()), move |subst_flex_6864: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyAt(Rc::new(subst_flex_6864), rw_pm.clone())))
            },
            crate::check::types::Ty::TyElem(rw_pn, o_po) => {
                let cm_p1 = cm_p1.clone();
                let m_p0 = m_p0.clone();
                let o_po = (**o_po).clone();
                let rw_pn = rw_pn.clone();
                call_then(start_subst_flex(m_p0.clone(), cm_p1.clone(), o_po.clone()), move |subst_flex_6918: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyElem(rw_pn.clone(), Rc::new(subst_flex_6918))))
            },
            crate::check::types::Ty::TyAssoc(n_pp, a_pq) => {
                let a_pq = (**a_pq).clone();
                let cm_p1 = cm_p1.clone();
                let m_p0 = m_p0.clone();
                let n_pp = n_pp.clone();
                call_then(start_subst_flex(m_p0.clone(), cm_p1.clone(), a_pq.clone()), move |subst_flex_6968: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyAssoc(n_pp.clone(), Rc::new(subst_flex_6968))))
            },
            other_pr => prism_rtl::Turn::Finished(other_pr.clone()),
        }
    }
}

/// `Start SubstFlex, x`: what the function value is when passed to `@Run`.
pub fn start_subst_flex(m_p0: Map<Nat, crate::check::types::Ty>, cm_p1: Map<Nat, crate::check::types::Col>, t_p2: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(SubstFlex { m_p0, cm_p1, t_p2 })
}

/// ```prism
/// HoldsNode: unbounded fn St, Ty -> Bool
/// ```
pub fn holds_node(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> bool {
    match crate::check::types::recording::walk(st_p0, t_p1) {
        crate::check::types::Ty::TySig(s_p2, i_p3) => ((&s_p2 == &Text::lit("$")) || (&s_p2 == &Text::lit("!"))) || holds_node(st_p0, &*i_p3),
        crate::check::types::Ty::TyTuple(ts_p4) => run_to_end(fold_job(ts_p4.clone(), false, {
            let st_p0 = st_p0.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let st_p0 = st_p0.clone();
                entered(once_job(move || {
                    let seen_p5 = p0;
                    let x_p6 = p1;
                    prism_rtl::Turn::Finished(seen_p5 || holds_node(&st_p0, &x_p6))
                }))
            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::check::types::Ty::TyArray(e_p7) => holds_node(st_p0, &*e_p7),
        crate::check::types::Ty::TyMap(k_p8, v_p9) => holds_node(st_p0, &*k_p8) || holds_node(st_p0, &*v_p9),
        crate::check::types::Ty::TyCon(_, args_pa) => run_to_end(fold_job(args_pa.clone(), false, {
            let st_p0 = st_p0.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let st_p0 = st_p0.clone();
                entered(once_job(move || {
                    let seen_pb = p0;
                    let x_pc = p1;
                    prism_rtl::Turn::Finished(seen_pb || holds_node(&st_p0, &x_pc))
                }))
            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        _ => false,
    }
}

/// The step machine of `HoldsNode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HoldsNode: unbounded fn St, Ty -> Bool
/// ```
pub struct HoldsNode {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<bool> for HoldsNode {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0 = st_p0.clone();
        let t_p1 = t_p1.clone();
        call_then(crate::check::types::recording::start_walk(st_p0.clone(), t_p1.clone()), move |walk_7202: crate::check::types::Ty| match walk_7202 {
            crate::check::types::Ty::TySig(s_p2, i_p3) => prism_rtl::Turn::Finished(((&s_p2 == &Text::lit("$")) || (&s_p2 == &Text::lit("!"))) || holds_node(&st_p0, &*i_p3)),
            crate::check::types::Ty::TyTuple(ts_p4) => fold_job(ts_p4.clone(), false, {
                let st_p0 = st_p0.clone();
                Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                    let st_p0 = st_p0.clone();
                    entered(once_job(move || {
                        let seen_p5 = p0;
                        let x_p6 = p1;
                        prism_rtl::Turn::Finished(seen_p5 || holds_node(&st_p0, &x_p6))
                    }))
                }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            crate::check::types::Ty::TyArray(e_p7) => prism_rtl::Turn::More(Rc::new(HoldsNode { st_p0: st_p0.clone(), t_p1: (*e_p7).clone() })),
            crate::check::types::Ty::TyMap(k_p8, v_p9) => call_then(start_holds_node(st_p0.clone(), (*k_p8).clone()), move |holds_node_7385: bool| prism_rtl::Turn::Finished(holds_node_7385 || holds_node(&st_p0, &*v_p9))),
            crate::check::types::Ty::TyCon(_, args_pa) => fold_job(args_pa.clone(), false, {
                let st_p0 = st_p0.clone();
                Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                    let st_p0 = st_p0.clone();
                    entered(once_job(move || {
                        let seen_pb = p0;
                        let x_pc = p1;
                        prism_rtl::Turn::Finished(seen_pb || holds_node(&st_p0, &x_pc))
                    }))
                }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            _ => prism_rtl::Turn::Finished(false),
        })
    }
}

/// `Start HoldsNode, x`: what the function value is when passed to `@Run`.
pub fn start_holds_node(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(HoldsNode { st_p0, t_p1 })
}

/// ```prism
/// EnterLevel: fn St -> St
/// ```
pub fn enter_level(st_p0: &crate::check::types::St) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.level = &this.level + &Nat::from(1u32);
    this
}

/// ```prism
/// LeaveLevel: fn St -> St
/// ```
pub fn leave_level(st_p0: &crate::check::types::St) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.level = or(&(&this.level).checked_sub(&Nat::from(1u32)), &Nat::from(0u32));
    this
}
