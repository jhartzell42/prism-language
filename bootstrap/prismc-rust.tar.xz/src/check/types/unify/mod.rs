//! The module `Check.Types.Unify`, from `target/bootstrap/src/prismc/check/types/unify.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `FieldQ`:
///
/// ```prism
/// type FieldQ = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct FieldQ {
    pub recv_p: crate::check::types::Ty,
    pub field_p: crate::prelude::Text,
    pub result_p: crate::check::types::Ty,
    pub span_p: crate::syntax::Range,
    pub file_p: crate::prelude::Nat,
    pub owners_p: crate::prelude::Array<crate::prelude::Text>,
    pub marks_o: ::std::option::Option<(crate::prelude::Text, crate::syntax::Range)>,
}

impl crate::prelude::Show for FieldQ {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("FieldQ", &[("recv", &self.recv_p), ("field", &self.field_p), ("result", &self.result_p), ("span", &self.span_p), ("file", &self.file_p), ("owners", &self.owners_p), ("marks", &self.marks_o)]);
    }
}

impl crate::prelude::ToPod for FieldQ {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("FieldQ", vec![("recv", self.recv_p.to_pod()), ("field", self.field_p.to_pod()), ("result", self.result_p.to_pod()), ("span", self.span_p.to_pod()), ("file", self.file_p.to_pod()), ("owners", self.owners_p.to_pod()), ("marks", self.marks_o.to_pod())])
    }
}

impl crate::prelude::FromPod for FieldQ {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(FieldQ { recv_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "recv")?)?, field_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "field")?)?, result_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "result")?)?, span_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "span")?)?, file_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "file")?)?, owners_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "owners")?)?, marks_o: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "marks")?)? })
    }
}

/// ```prism
/// Unify: unbounded fn St, Ty, Ty, Range -> St
/// ```
pub fn unify_f(st_p0: &crate::check::types::St, expected_p1: &crate::check::types::Ty, found_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> crate::check::types::St {
    let (verdict_p4, st2_p5) = unify_in_f(st_p0, expected_p1, found_p2, span_p3);
    if &verdict_p4 == &crate::prelude::Text::lit("mismatch") {
        {
            let e_p6 = crate::check::types::show_ty_f(&st2_p5, expected_p1);
            let f_p7 = crate::check::types::show_ty_f(&st2_p5, found_p2);
            if &e_p6 == &f_p7 {
                crate::check::types::recording::err_f(&st2_p5, &crate::prelude::Text::lit("mismatch"), span_p3, &crate::prelude::Text::from(format!("expected `{}`, found `{}`", &show_ty_q_f(&st2_p5, expected_p1), &show_ty_q_f(&st2_p5, found_p2))))
            } else {
                crate::check::types::recording::err_f(&st2_p5, &crate::prelude::Text::lit("mismatch"), span_p3, &crate::prelude::Text::from(format!("expected `{}`, found `{}`", &e_p6, &f_p7)))
            }
        }
    } else {
        st2_p5.clone()
    }
}

/// The step machine of `Unify`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Unify: unbounded fn St, Ty, Ty, Range -> St
/// ```
pub struct Unify {
    pub st_p0: crate::check::types::St,
    pub expected_p1: crate::check::types::Ty,
    pub found_p2: crate::check::types::Ty,
    pub span_p3: crate::syntax::Range,
}

impl ::prism_rtl::Job<crate::check::types::St> for Unify {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let expected_p1 = &self.expected_p1;
        let found_p2 = &self.found_p2;
        let span_p3 = &self.span_p3;
        let expected_p1x = expected_p1.clone();
        let found_p2x = found_p2.clone();
        let span_p3x = span_p3.clone();
        let st_p0x = st_p0.clone();
        crate::prelude::call_then(start_unify_in_f(st_p0x.clone(), expected_p1x.clone(), found_p2x.clone(), span_p3x.clone()), move |unify_in_f_1030: (crate::prelude::Text, crate::check::types::St)| {
            let (verdict_p4, st2_p5) = unify_in_f_1030;
            if &verdict_p4 == &crate::prelude::Text::lit("mismatch") {
                crate::prelude::call_then(crate::check::types::start_show_ty_f(st2_p5.clone(), expected_p1x.clone()), move |show_ty_f_1110: crate::prelude::Text| {
                    let e_p6 = show_ty_f_1110;
                    crate::prelude::call_then(crate::check::types::start_show_ty_f(st2_p5.clone(), found_p2x.clone()), move |show_ty_f_1147: crate::prelude::Text| {
                        let f_p7 = show_ty_f_1147;
                        if &e_p6 == &f_p7 {
                            crate::prelude::call_then(start_show_ty_q_f(st2_p5.clone(), expected_p1x.clone()), move |show_ty_q_f_1223: crate::prelude::Text| crate::prelude::call_then(start_show_ty_q_f(st2_p5.clone(), found_p2x.clone()), move |show_ty_q_f_1256: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&st2_p5, &crate::prelude::Text::lit("mismatch"), &span_p3x, &crate::prelude::Text::from(format!("expected `{}`, found `{}`", &show_ty_q_f_1223, &show_ty_q_f_1256))))))
                        } else {
                            ::prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&st2_p5, &crate::prelude::Text::lit("mismatch"), &span_p3x, &crate::prelude::Text::from(format!("expected `{}`, found `{}`", &e_p6, &f_p7))))
                        }
                    })
                })
            } else {
                ::prism_rtl::Turn::Finished(st2_p5.clone())
            }
        })
    }
}

/// `Start Unify, x`: what the function value is when passed to `@Run`.
pub fn start_unify_f(st_p0: crate::check::types::St, expected_p1: crate::check::types::Ty, found_p2: crate::check::types::Ty, span_p3: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(Unify { st_p0, expected_p1, found_p2, span_p3 })
}

/// ```prism
/// ShowTyQ: unbounded fn St, Ty -> Text
/// ```
pub fn show_ty_q_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> crate::prelude::Text {
    match crate::check::types::recording::zonk_f(st_p0, t_p1) {
        crate::check::types::Ty::TyCon(n_p2, m1487_0_1) if ((&m1487_0_1).len() == 0) => n_p2,
        crate::check::types::Ty::TyCon(n_p3, args_p4) => crate::prelude::Text::from(format!("({}{})", &n_p3, &crate::prelude::concat(&crate::prelude::run_to_end(crate::prelude::each_job(args_p4.clone(), {
            let st_p0x = st_p0.clone();
            ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p5 = p0;
                    crate::prelude::call_then(start_show_ty_q_f(st_p0xy.clone(), a_p5.clone()), move |show_ty_q_f_1578: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!(" {}", &show_ty_q_f_1578))))
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
        }))))),
        crate::check::types::Ty::TySig(s_p6, i_p7) => crate::prelude::Text::from(format!("{}{}", &s_p6, &show_ty_q_f(st_p0, &*i_p7))),
        crate::check::types::Ty::TyArray(e_p8) => {
            let inner_p9 = show_ty_q_f(st_p0, &*e_p8);
            if crate::syntax::lexer::chars::has_prefix_f(&inner_p9, &crate::prelude::Text::lit("[")) {
                crate::prelude::Text::from(format!("[ {} ]", &inner_p9))
            } else {
                crate::prelude::Text::from(format!("[{}]", &inner_p9))
            }
        },
        crate::check::types::Ty::TyMap(k_pa, v_pb) => crate::prelude::Text::from(format!("({} ==> {})", &show_ty_q_f(st_p0, &*k_pa), &show_ty_q_f(st_p0, &*v_pb))),
        crate::check::types::Ty::TyAt(i_pc, rw_pd) => crate::prelude::Text::from(format!("@{} emit {}", &show_ty_q_f(st_p0, &*i_pc), &crate::check::types::show_row_in_f(&rw_pd, &true))),
        other_pe => crate::check::types::show_ty_f(st_p0, &other_pe),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ShowTyQ`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowTyQ: unbounded fn St, Ty -> Text
/// ```
pub struct ShowTyQ {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::prelude::Text> for ShowTyQ {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p0x.clone(), t_p1x.clone()), move |zonk_f_1493: crate::check::types::Ty| match zonk_f_1493 {
            crate::check::types::Ty::TyCon(n_p2, m1487_0_1) if ((&m1487_0_1).len() == 0) => ::prism_rtl::Turn::Finished(n_p2.clone()),
            crate::check::types::Ty::TyCon(n_p3, args_p4) => crate::prelude::call_value(crate::prelude::each_job(args_p4.clone(), {
                let st_p0xx = st_p0x.clone();
                ::std::rc::Rc::new(move |p0: crate::check::types::Ty| {
                    let st_p0xxy = st_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_p5 = p0;
                        crate::prelude::call_then(start_show_ty_q_f(st_p0xxy.clone(), a_p5.clone()), move |show_ty_q_f_1578: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!(" {}", &show_ty_q_f_1578))))
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
            }), move |each_1559: crate::prelude::Array<crate::prelude::Text>| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("({}{})", &n_p3, &crate::prelude::concat(&each_1559))))),
            crate::check::types::Ty::TySig(s_p6, i_p7) => crate::prelude::call_then(start_show_ty_q_f(st_p0x.clone(), (*i_p7).clone()), move |show_ty_q_f_1619: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{}", &s_p6, &show_ty_q_f_1619)))),
            crate::check::types::Ty::TyArray(e_p8) => crate::prelude::call_then(start_show_ty_q_f(st_p0x.clone(), (*e_p8).clone()), move |show_ty_q_f_1670: crate::prelude::Text| {
                let inner_p9 = show_ty_q_f_1670;
                if crate::syntax::lexer::chars::has_prefix_f(&inner_p9, &crate::prelude::Text::lit("[")) {
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("[ {} ]", &inner_p9)))
                } else {
                    ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("[{}]", &inner_p9)))
                }
            }),
            crate::check::types::Ty::TyMap(k_pa, v_pb) => crate::prelude::call_then(start_show_ty_q_f(st_p0x.clone(), (*k_pa).clone()), move |show_ty_q_f_1770: crate::prelude::Text| crate::prelude::call_then(start_show_ty_q_f(st_p0x.clone(), (*v_pb).clone()), move |show_ty_q_f_1790: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("({} ==> {})", &show_ty_q_f_1770, &show_ty_q_f_1790))))),
            crate::check::types::Ty::TyAt(i_pc, rw_pd) => crate::prelude::call_then(start_show_ty_q_f(st_p0x.clone(), (*i_pc).clone()), move |show_ty_q_f_1826: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("@{} emit {}", &show_ty_q_f_1826, &crate::check::types::show_row_in_f(&rw_pd, &true))))),
            other_pe => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::ShowTy { st_p0: st_p0x.clone(), t_p1: other_pe.clone() })),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start ShowTyQ, x`: what the function value is when passed to `@Run`.
pub fn start_show_ty_q_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(ShowTyQ { st_p0, t_p1 })
}

/// ```prism
/// TryUnify: unbounded fn St, Ty, Ty, Range -> ((Bool, St))
/// ```
pub fn try_unify_f(st_p0: &crate::check::types::St, expected_p1: &crate::check::types::Ty, found_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> (bool, crate::check::types::St) {
    let (verdict_p4, st2_p5) = unify_in_f(st_p0, expected_p1, found_p2, span_p3);
    (&verdict_p4 == &crate::prelude::Text::lit(""), st2_p5.clone())
}

/// The step machine of `TryUnify`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TryUnify: unbounded fn St, Ty, Ty, Range -> ((Bool, St))
/// ```
pub struct TryUnify {
    pub st_p0: crate::check::types::St,
    pub expected_p1: crate::check::types::Ty,
    pub found_p2: crate::check::types::Ty,
    pub span_p3: crate::syntax::Range,
}

impl ::prism_rtl::Job<(bool, crate::check::types::St)> for TryUnify {
    fn cycle(&self) -> ::prism_rtl::Turn<(bool, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let expected_p1 = &self.expected_p1;
        let found_p2 = &self.found_p2;
        let span_p3 = &self.span_p3;
        let expected_p1x = expected_p1.clone();
        let found_p2x = found_p2.clone();
        let span_p3x = span_p3.clone();
        let st_p0x = st_p0.clone();
        crate::prelude::call_then(start_unify_in_f(st_p0x.clone(), expected_p1x.clone(), found_p2x.clone(), span_p3x.clone()), move |unify_in_f_2156: (crate::prelude::Text, crate::check::types::St)| {
            let (verdict_p4, st2_p5) = unify_in_f_2156;
            ::prism_rtl::Turn::Finished((&verdict_p4 == &crate::prelude::Text::lit(""), st2_p5.clone()))
        })
    }
}

/// `Start TryUnify, x`: what the function value is when passed to `@Run`.
pub fn start_try_unify_f(st_p0: crate::check::types::St, expected_p1: crate::check::types::Ty, found_p2: crate::check::types::Ty, span_p3: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(bool, crate::check::types::St)>> {
    ::std::rc::Rc::new(TryUnify { st_p0, expected_p1, found_p2, span_p3 })
}

/// ```prism
/// UnifyIn: unbounded fn St, Ty, Ty, Range -> ((Text, St))
/// ```
pub fn unify_in_f(st_p0: &crate::check::types::St, expected_p1: &crate::check::types::Ty, found_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> (crate::prelude::Text, crate::check::types::St) {
    let e_p4 = norm_assoc_f(st_p0, &crate::check::types::recording::walk_f(st_p0, expected_p1));
    let f_p5 = norm_assoc_f(st_p0, &crate::check::types::recording::walk_f(st_p0, found_p2));
    if is_waiting_assoc_f(st_p0, &e_p4) || is_waiting_assoc_f(st_p0, &f_p5) {
        if &crate::check::types::recording::zonk_f(st_p0, &e_p4) == &crate::check::types::recording::zonk_f(st_p0, &f_p5) {
            (crate::prelude::Text::lit(""), st_p0.clone())
        } else {
            if crate::check::types::is_flex_var_f(st_p0, &e_p4) || crate::check::types::is_flex_var_f(st_p0, &f_p5) {
                unify_heads_f(st_p0, &e_p4, &f_p5, span_p3)
            } else {
                (crate::prelude::Text::lit(""), defer_f(st_p0, &e_p4, &f_p5, span_p3))
            }
        }
    } else {
        unify_heads_f(st_p0, &e_p4, &f_p5, span_p3)
    }
}

/// The step machine of `UnifyIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyIn: unbounded fn St, Ty, Ty, Range -> ((Text, St))
/// ```
pub struct UnifyIn {
    pub st_p0: crate::check::types::St,
    pub expected_p1: crate::check::types::Ty,
    pub found_p2: crate::check::types::Ty,
    pub span_p3: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::St)> for UnifyIn {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Text, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let expected_p1 = &self.expected_p1;
        let found_p2 = &self.found_p2;
        let span_p3 = &self.span_p3;
        let expected_p1x = expected_p1.clone();
        let found_p2x = found_p2.clone();
        let span_p3x = span_p3.clone();
        let st_p0x = st_p0.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), expected_p1x.clone()), move |walk_f_2446: crate::check::types::Ty| crate::prelude::call_then(start_norm_assoc_f(st_p0x.clone(), walk_f_2446), move |norm_assoc_f_2431: crate::check::types::Ty| {
            let e_p4 = norm_assoc_f_2431;
            crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), found_p2x.clone()), move |walk_f_2492: crate::check::types::Ty| crate::prelude::call_then(start_norm_assoc_f(st_p0x.clone(), walk_f_2492), move |norm_assoc_f_2477: crate::check::types::Ty| {
                let f_p5 = norm_assoc_f_2477;
                crate::prelude::call_then(start_is_waiting_assoc_f(st_p0x.clone(), e_p4.clone()), move |is_waiting_assoc_f_2742: bool| if is_waiting_assoc_f_2742 || is_waiting_assoc_f(&st_p0x, &f_p5) {
                    crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p0x.clone(), e_p4.clone()), move |zonk_f_3020: crate::check::types::Ty| crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p0x.clone(), f_p5.clone()), move |zonk_f_3036: crate::check::types::Ty| if &zonk_f_3020 == &zonk_f_3036 {
                        ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), st_p0x.clone()))
                    } else {
                        crate::prelude::call_then(crate::check::types::start_is_flex_var_f(st_p0x.clone(), e_p4.clone()), move |is_flex_var_f_3078: bool| if is_flex_var_f_3078 || crate::check::types::is_flex_var_f(&st_p0x, &f_p5) {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(UnifyHeads { st_p0: st_p0x.clone(), e_p1: e_p4.clone(), f_p2: f_p5.clone(), span_p3: span_p3x.clone() }))
                        } else {
                            ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), defer_f(&st_p0x, &e_p4, &f_p5, &span_p3x)))
                        })
                    }))
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(UnifyHeads { st_p0: st_p0x.clone(), e_p1: e_p4.clone(), f_p2: f_p5.clone(), span_p3: span_p3x.clone() }))
                })
            }))
        }))
    }
}

/// `Start UnifyIn, x`: what the function value is when passed to `@Run`.
pub fn start_unify_in_f(st_p0: crate::check::types::St, expected_p1: crate::check::types::Ty, found_p2: crate::check::types::Ty, span_p3: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::St)>> {
    ::std::rc::Rc::new(UnifyIn { st_p0, expected_p1, found_p2, span_p3 })
}

/// ```prism
/// NormAssoc: unbounded fn St, Ty -> Ty
/// ```
pub fn norm_assoc_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    let n_p2 = norm_assoc_once_f(st_p0, t_p1);
    if &n_p2 == t_p1 {
        t_p1.clone()
    } else {
        norm_assoc_f(st_p0, &crate::check::types::recording::walk_f(st_p0, &n_p2))
    }
}

/// The step machine of `NormAssoc`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NormAssoc: unbounded fn St, Ty -> Ty
/// ```
pub struct NormAssoc {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::Ty> for NormAssoc {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::Ty> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(start_norm_assoc_once_f(st_p0x.clone(), t_p1x.clone()), move |norm_assoc_once_f_3733: crate::check::types::Ty| {
            let n_p2 = norm_assoc_once_f_3733;
            if &n_p2 == &t_p1x {
                ::prism_rtl::Turn::Finished(t_p1x.clone())
            } else {
                crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), n_p2.clone()), move |walk_f_3791: crate::check::types::Ty| ::prism_rtl::Turn::More(::std::rc::Rc::new(NormAssoc { st_p0: st_p0x.clone(), t_p1: walk_f_3791 })))
            }
        })
    }
}

/// `Start NormAssoc, x`: what the function value is when passed to `@Run`.
pub fn start_norm_assoc_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>> {
    ::std::rc::Rc::new(NormAssoc { st_p0, t_p1 })
}

/// ```prism
/// NormAssocOnce: unbounded fn St, Ty -> Ty
/// ```
pub fn norm_assoc_once_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p1 {
        crate::check::types::Ty::TyAssoc(tr_p2, m3870_0_1, a_p3) if (m3870_0_1 == &crate::prelude::Text::lit("Quotient")) && (tr_p2 == &crate::check::types::quotient_trait_p()) => match crate::check::types::recording::walk_f(st_p0, &**a_p3) {
            crate::check::types::Ty::TyCon(m3933_0_0, m3933_0_1) if (&m3933_0_0 == &crate::prelude::Text::lit("Float")) && ((&m3933_0_1).len() == 0) => crate::check::types::t_float_p(),
            crate::check::types::Ty::TyCon(n_p4, m3933_1_1) if ((&m3933_1_1).len() == 0) => if ((&n_p4 == &crate::prelude::Text::lit("Nat")) || (&n_p4 == &crate::prelude::Text::lit("Int"))) || (&n_p4 == &crate::prelude::Text::lit("U8")) {
                crate::check::types::Ty::TySig(crate::prelude::Text::lit("?"), ::std::rc::Rc::new(crate::check::types::Ty::TyCon(n_p4.clone(), crate::prelude::Array::new())))
            } else {
                impl_assoc_f(st_p0, tr_p2, &crate::prelude::Text::lit("Quotient"), &crate::check::types::recording::walk_f(st_p0, &**a_p3), t_p1)
            },
            _ => impl_assoc_f(st_p0, tr_p2, &crate::prelude::Text::lit("Quotient"), &crate::check::types::recording::walk_f(st_p0, &**a_p3), t_p1),
            _ => unreachable!("no arm matched"),
        },
        crate::check::types::Ty::TyAssoc(tr_p5, n_p6, a_p7) => impl_assoc_f(st_p0, tr_p5, n_p6, &crate::check::types::recording::walk_f(st_p0, &**a_p7), t_p1),
        other_p8 => other_p8.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `NormAssocOnce`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NormAssocOnce: unbounded fn St, Ty -> Ty
/// ```
pub struct NormAssocOnce {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::Ty> for NormAssocOnce {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::Ty> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        match t_p1 {
            crate::check::types::Ty::TyAssoc(tr_p2, m3870_0_1, a_p3) if (m3870_0_1 == &crate::prelude::Text::lit("Quotient")) && (tr_p2 == &crate::check::types::quotient_trait_p()) => {
                let a_p3x = (**a_p3).clone();
                let st_p0x = st_p0.clone();
                let t_p1x = t_p1.clone();
                let tr_p2x = tr_p2.clone();
                crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), a_p3x.clone()), move |walk_f_3939: crate::check::types::Ty| match walk_f_3939 {
                    crate::check::types::Ty::TyCon(m3933_0_0, m3933_0_1) if (&m3933_0_0 == &crate::prelude::Text::lit("Float")) && ((&m3933_0_1).len() == 0) => ::prism_rtl::Turn::Finished(crate::check::types::t_float_p()),
                    crate::check::types::Ty::TyCon(n_p4, m3933_1_1) if ((&m3933_1_1).len() == 0) => if ((&n_p4 == &crate::prelude::Text::lit("Nat")) || (&n_p4 == &crate::prelude::Text::lit("Int"))) || (&n_p4 == &crate::prelude::Text::lit("U8")) {
                        ::prism_rtl::Turn::Finished(crate::check::types::Ty::TySig(crate::prelude::Text::lit("?"), ::std::rc::Rc::new(crate::check::types::Ty::TyCon(n_p4.clone(), crate::prelude::Array::new()))))
                    } else {
                        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), a_p3x.clone()), move |walk_f_4116: crate::check::types::Ty| ::prism_rtl::Turn::More(::std::rc::Rc::new(ImplAssoc { st_p0: st_p0x.clone(), tr_p1: tr_p2x.clone(), n_p2: crate::prelude::Text::lit("Quotient"), a_p3: walk_f_4116, t_p4: t_p1x.clone() })))
                    },
                    _ => crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), a_p3x.clone()), move |walk_f_4181: crate::check::types::Ty| ::prism_rtl::Turn::More(::std::rc::Rc::new(ImplAssoc { st_p0: st_p0x.clone(), tr_p1: tr_p2x.clone(), n_p2: crate::prelude::Text::lit("Quotient"), a_p3: walk_f_4181, t_p4: t_p1x.clone() }))),
                    _ => unreachable!("no arm matched"),
                })
            },
            crate::check::types::Ty::TyAssoc(tr_p5, n_p6, a_p7) => {
                let a_p7x = (**a_p7).clone();
                let n_p6x = n_p6.clone();
                let st_p0x = st_p0.clone();
                let t_p1x = t_p1.clone();
                let tr_p5x = tr_p5.clone();
                crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), a_p7x.clone()), move |walk_f_4240: crate::check::types::Ty| ::prism_rtl::Turn::More(::std::rc::Rc::new(ImplAssoc { st_p0: st_p0x.clone(), tr_p1: tr_p5x.clone(), n_p2: n_p6x.clone(), a_p3: walk_f_4240, t_p4: t_p1x.clone() })))
            },
            other_p8 => ::prism_rtl::Turn::Finished(other_p8.clone()),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start NormAssocOnce, x`: what the function value is when passed to `@Run`.
pub fn start_norm_assoc_once_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>> {
    ::std::rc::Rc::new(NormAssocOnce { st_p0, t_p1 })
}

/// ```prism
/// ImplAssoc: unbounded fn St, Text, Text, Ty, Ty -> Ty
/// ```
pub fn impl_assoc_f(st_p0: &crate::check::types::St, tr_p1: &crate::prelude::Text, n_p2: &crate::prelude::Text, a_p3: &crate::check::types::Ty, t_p4: &crate::check::types::Ty) -> crate::check::types::Ty {
    match a_p3 {
        crate::check::types::Ty::TyFlex(_) => t_p4.clone(),
        crate::check::types::Ty::TyRigid(_) => t_p4.clone(),
        _ => {
            let whole_p5 = crate::check::types::recording::zonk_f(st_p0, a_p3);
            crate::prelude::run_to_end(crate::prelude::fold_job(st_p0.assoc_impls_p.clone(), t_p4.clone(), {
                let t_p4x = t_p4.clone();
                let tr_p1x = tr_p1.clone();
                let n_p2x = n_p2.clone();
                let whole_p5x = whole_p5.clone();
                ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::Ty, crate::check::types::AssocImpl)| {
                    let t_p4xy = t_p4x.clone();
                    let tr_p1xy = tr_p1x.clone();
                    let n_p2xy = n_p2x.clone();
                    let whole_p5xy = whole_p5x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let found_p6 = p0;
                        let ai_p7 = p1;
                        if ((&found_p6 != &t_p4xy) || (&ai_p7.cls_p != &tr_p1xy)) || (&ai_p7.name_p != &n_p2xy) {
                            ::prism_rtl::Turn::Finished(found_p6.clone())
                        } else {
                            crate::prelude::call_then(start_match_head_o(ai_p7.head_p.clone(), whole_p5xy.clone(), crate::prelude::Map::new()), move |match_head_o_4973: ::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>| match match_head_o_4973 {
                                ::std::option::Option::Some(tys_p8) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::schemes::SubstQ { m_p0: crate::check::types::schemes::Inst { tys_p: tys_p8.clone(), rows_p: crate::prelude::Map::new(), cols_p: crate::prelude::Map::new() }, t_p1: ai_p7.value_p.clone() })),
                                ::std::option::Option::None => ::prism_rtl::Turn::Finished(found_p6.clone()),
                            })
                        }
                    }))
                }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::Ty, crate::check::types::AssocImpl)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
            }))
        },
    }
}

/// The step machine of `ImplAssoc`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ImplAssoc: unbounded fn St, Text, Text, Ty, Ty -> Ty
/// ```
pub struct ImplAssoc {
    pub st_p0: crate::check::types::St,
    pub tr_p1: crate::prelude::Text,
    pub n_p2: crate::prelude::Text,
    pub a_p3: crate::check::types::Ty,
    pub t_p4: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::check::types::Ty> for ImplAssoc {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::Ty> {
        let st_p0 = &self.st_p0;
        let tr_p1 = &self.tr_p1;
        let n_p2 = &self.n_p2;
        let a_p3 = &self.a_p3;
        let t_p4 = &self.t_p4;
        match a_p3 {
            crate::check::types::Ty::TyFlex(_) => ::prism_rtl::Turn::Finished(t_p4.clone()),
            crate::check::types::Ty::TyRigid(_) => ::prism_rtl::Turn::Finished(t_p4.clone()),
            _ => {
                let a_p3x = a_p3.clone();
                let n_p2x = n_p2.clone();
                let st_p0x = st_p0.clone();
                let t_p4x = t_p4.clone();
                let tr_p1x = tr_p1.clone();
                crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p0x.clone(), a_p3x.clone()), move |zonk_f_4853: crate::check::types::Ty| {
                    let whole_p5 = zonk_f_4853;
                    crate::prelude::fold_job(st_p0x.assoc_impls_p.clone(), t_p4x.clone(), {
                        let t_p4xx = t_p4x.clone();
                        let tr_p1xx = tr_p1x.clone();
                        let n_p2xx = n_p2x.clone();
                        let whole_p5x = whole_p5.clone();
                        ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::Ty, crate::check::types::AssocImpl)| {
                            let t_p4xxy = t_p4xx.clone();
                            let tr_p1xxy = tr_p1xx.clone();
                            let n_p2xxy = n_p2xx.clone();
                            let whole_p5xy = whole_p5x.clone();
                            crate::prelude::entered(crate::prelude::once_job(move || {
                                let found_p6 = p0;
                                let ai_p7 = p1;
                                if ((&found_p6 != &t_p4xxy) || (&ai_p7.cls_p != &tr_p1xxy)) || (&ai_p7.name_p != &n_p2xxy) {
                                    ::prism_rtl::Turn::Finished(found_p6.clone())
                                } else {
                                    crate::prelude::call_then(start_match_head_o(ai_p7.head_p.clone(), whole_p5xy.clone(), crate::prelude::Map::new()), move |match_head_o_4973: ::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>| match match_head_o_4973 {
                                        ::std::option::Option::Some(tys_p8) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::schemes::SubstQ { m_p0: crate::check::types::schemes::Inst { tys_p: tys_p8.clone(), rows_p: crate::prelude::Map::new(), cols_p: crate::prelude::Map::new() }, t_p1: ai_p7.value_p.clone() })),
                                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(found_p6.clone()),
                                    })
                                }
                            }))
                        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::Ty, crate::check::types::AssocImpl)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>>>
                    }).cycle()
                })
            },
        }
    }
}

/// `Start ImplAssoc, x`: what the function value is when passed to `@Run`.
pub fn start_impl_assoc_f(st_p0: crate::check::types::St, tr_p1: crate::prelude::Text, n_p2: crate::prelude::Text, a_p3: crate::check::types::Ty, t_p4: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::Ty>> {
    ::std::rc::Rc::new(ImplAssoc { st_p0, tr_p1, n_p2, a_p3, t_p4 })
}

/// ```prism
/// ?MatchHead: unbounded fn Ty, Ty, (Text ==> Ty) -> ?(Text ==> Ty)
/// ```
pub fn match_head_o(pat_p0: &crate::check::types::Ty, t_p1: &crate::check::types::Ty, m_p2: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>) -> ::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>> {
    match (pat_p0.clone(), t_p1.clone()) {
        (crate::check::types::Ty::TyQ(v_p3), x_p4) => match crate::prelude::get(m_p2, &v_p3) {
            ::std::option::Option::Some(y_p5) => if &y_p5 == &x_p4 {
                ::std::option::Option::Some(m_p2.clone())
            } else {
                ::std::option::Option::None
            },
            ::std::option::Option::None => ::std::option::Option::Some(crate::prelude::insert(m_p2, &v_p3, &x_p4)),
        },
        (crate::check::types::Ty::TyCon(a_p6, xs_p7), crate::check::types::Ty::TyCon(b_p8, ys_p9)) => if (&a_p6 == &b_p8) && (&crate::prelude::len(&xs_p7) == &crate::prelude::len(&ys_p9)) {
            match_all_o(&xs_p7, &ys_p9, m_p2)
        } else {
            ::std::option::Option::None
        },
        (crate::check::types::Ty::TyTuple(xs_pa), crate::check::types::Ty::TyTuple(ys_pb)) => if &crate::prelude::len(&xs_pa) == &crate::prelude::len(&ys_pb) {
            match_all_o(&xs_pa, &ys_pb, m_p2)
        } else {
            ::std::option::Option::None
        },
        (crate::check::types::Ty::TyArray(x_pc), crate::check::types::Ty::TyArray(y_pd)) => match_head_o(&*x_pc, &*y_pd, m_p2),
        (crate::check::types::Ty::TyMap(k1_pe, v1_pf), crate::check::types::Ty::TyMap(k2_pg, v2_ph)) => match_all_o(&crate::prelude::Array::from(vec![(*k1_pe).clone(), (*v1_pf).clone()]), &crate::prelude::Array::from(vec![(*k2_pg).clone(), (*v2_ph).clone()]), m_p2),
        (crate::check::types::Ty::TySig(s1_pi, i1_pj), crate::check::types::Ty::TySig(s2_pk, i2_pl)) => if &s1_pi == &s2_pk {
            match_head_o(&*i1_pj, &*i2_pl, m_p2)
        } else {
            ::std::option::Option::None
        },
        _ => ::std::option::Option::None,
    }
}

/// The step machine of `MatchHead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?MatchHead: unbounded fn Ty, Ty, (Text ==> Ty) -> ?(Text ==> Ty)
/// ```
pub struct MatchHead {
    pub pat_p0: crate::check::types::Ty,
    pub t_p1: crate::check::types::Ty,
    pub m_p2: crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>,
}

impl ::prism_rtl::Job<::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>> for MatchHead {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>> {
        let pat_p0 = &self.pat_p0;
        let t_p1 = &self.t_p1;
        let m_p2 = &self.m_p2;
        match (pat_p0.clone(), t_p1.clone()) {
            (crate::check::types::Ty::TyQ(v_p3), x_p4) => match crate::prelude::get(m_p2, &v_p3) {
                ::std::option::Option::Some(y_p5) => if &y_p5 == &x_p4 {
                    ::prism_rtl::Turn::Finished(::std::option::Option::Some(m_p2.clone()))
                } else {
                    ::prism_rtl::Turn::Finished(::std::option::Option::None)
                },
                ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::Some(crate::prelude::insert(m_p2, &v_p3, &x_p4))),
            },
            (crate::check::types::Ty::TyCon(a_p6, xs_p7), crate::check::types::Ty::TyCon(b_p8, ys_p9)) => if (&a_p6 == &b_p8) && (&crate::prelude::len(&xs_p7) == &crate::prelude::len(&ys_p9)) {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(MatchAll { xs_p0: xs_p7.clone(), ys_p1: ys_p9.clone(), m_p2: m_p2.clone() }))
            } else {
                ::prism_rtl::Turn::Finished(::std::option::Option::None)
            },
            (crate::check::types::Ty::TyTuple(xs_pa), crate::check::types::Ty::TyTuple(ys_pb)) => if &crate::prelude::len(&xs_pa) == &crate::prelude::len(&ys_pb) {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(MatchAll { xs_p0: xs_pa.clone(), ys_p1: ys_pb.clone(), m_p2: m_p2.clone() }))
            } else {
                ::prism_rtl::Turn::Finished(::std::option::Option::None)
            },
            (crate::check::types::Ty::TyArray(x_pc), crate::check::types::Ty::TyArray(y_pd)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(MatchHead { pat_p0: (*x_pc).clone(), t_p1: (*y_pd).clone(), m_p2: m_p2.clone() })),
            (crate::check::types::Ty::TyMap(k1_pe, v1_pf), crate::check::types::Ty::TyMap(k2_pg, v2_ph)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(MatchAll { xs_p0: crate::prelude::Array::from(vec![(*k1_pe).clone(), (*v1_pf).clone()]), ys_p1: crate::prelude::Array::from(vec![(*k2_pg).clone(), (*v2_ph).clone()]), m_p2: m_p2.clone() })),
            (crate::check::types::Ty::TySig(s1_pi, i1_pj), crate::check::types::Ty::TySig(s2_pk, i2_pl)) => if &s1_pi == &s2_pk {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(MatchHead { pat_p0: (*i1_pj).clone(), t_p1: (*i2_pl).clone(), m_p2: m_p2.clone() }))
            } else {
                ::prism_rtl::Turn::Finished(::std::option::Option::None)
            },
            _ => ::prism_rtl::Turn::Finished(::std::option::Option::None),
        }
    }
}

/// `Start MatchHead, x`: what the function value is when passed to `@Run`.
pub fn start_match_head_o(pat_p0: crate::check::types::Ty, t_p1: crate::check::types::Ty, m_p2: crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>>> {
    ::std::rc::Rc::new(MatchHead { pat_p0, t_p1, m_p2 })
}

/// ```prism
/// ?MatchAll: unbounded fn [Ty], [Ty], (Text ==> Ty) -> ?(Text ==> Ty)
/// ```
pub fn match_all_o(xs_p0: &crate::prelude::Array<crate::check::types::Ty>, ys_p1: &crate::prelude::Array<crate::check::types::Ty>, m_p2: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>) -> ::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>> {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(xs_p0)), ::std::option::Option::Some(m_p2.clone()), {
        let xs_p0x = xs_p0.clone();
        let ys_p1x = ys_p1.clone();
        ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>, crate::prelude::Nat)| {
            let xs_p0xy = xs_p0x.clone();
            let ys_p1xy = ys_p1x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let acc_o3 = p0;
                let i_p4 = p1;
                match &acc_o3 {
                    ::std::option::Option::Some(mm_p5) => ::prism_rtl::Turn::More(::std::rc::Rc::new(MatchHead { pat_p0: crate::prelude::or(&crate::prelude::index(&xs_p0xy, &i_p4), &crate::check::types::Ty::TyErr), t_p1: crate::prelude::or(&crate::prelude::index(&ys_p1xy, &i_p4), &crate::check::types::Ty::TyErr), m_p2: mm_p5.clone() })),
                    ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>>>>
    }))
}

/// The step machine of `MatchAll`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?MatchAll: unbounded fn [Ty], [Ty], (Text ==> Ty) -> ?(Text ==> Ty)
/// ```
pub struct MatchAll {
    pub xs_p0: crate::prelude::Array<crate::check::types::Ty>,
    pub ys_p1: crate::prelude::Array<crate::check::types::Ty>,
    pub m_p2: crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>,
}

impl ::prism_rtl::Job<::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>> for MatchAll {
    fn cycle(&self) -> ::prism_rtl::Turn<::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>> {
        let xs_p0 = &self.xs_p0;
        let ys_p1 = &self.ys_p1;
        let m_p2 = &self.m_p2;
        crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(xs_p0)), ::std::option::Option::Some(m_p2.clone()), {
            let xs_p0x = xs_p0.clone();
            let ys_p1x = ys_p1.clone();
            ::std::rc::Rc::new(move |(p0, p1): (::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>, crate::prelude::Nat)| {
                let xs_p0xy = xs_p0x.clone();
                let ys_p1xy = ys_p1x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let acc_o3 = p0;
                    let i_p4 = p1;
                    match &acc_o3 {
                        ::std::option::Option::Some(mm_p5) => ::prism_rtl::Turn::More(::std::rc::Rc::new(MatchHead { pat_p0: crate::prelude::or(&crate::prelude::index(&xs_p0xy, &i_p4), &crate::check::types::Ty::TyErr), t_p1: crate::prelude::or(&crate::prelude::index(&ys_p1xy, &i_p4), &crate::check::types::Ty::TyErr), m_p2: mm_p5.clone() })),
                        ::std::option::Option::None => ::prism_rtl::Turn::Finished(::std::option::Option::None),
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>, crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>>>>
        }).cycle()
    }
}

/// `Start MatchAll, x`: what the function value is when passed to `@Run`.
pub fn start_match_all_o(xs_p0: crate::prelude::Array<crate::check::types::Ty>, ys_p1: crate::prelude::Array<crate::check::types::Ty>, m_p2: crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>) -> ::std::rc::Rc<dyn ::prism_rtl::Job<::std::option::Option<crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>>>> {
    ::std::rc::Rc::new(MatchAll { xs_p0, ys_p1, m_p2 })
}

/// ```prism
/// IsWaitingAssoc: unbounded fn St, Ty -> Bool
/// ```
pub fn is_waiting_assoc_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> bool {
    match t_p1 {
        crate::check::types::Ty::TyAssoc(_, _, a_p2) => crate::check::types::is_flex_var_f(st_p0, &**a_p2),
        _ => false,
    }
}

/// The step machine of `IsWaitingAssoc`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsWaitingAssoc: unbounded fn St, Ty -> Bool
/// ```
pub struct IsWaitingAssoc {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl ::prism_rtl::Job<bool> for IsWaitingAssoc {
    fn cycle(&self) -> ::prism_rtl::Turn<bool> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        match t_p1 {
            crate::check::types::Ty::TyAssoc(_, _, a_p2) => ::prism_rtl::Turn::More(::std::rc::Rc::new(crate::check::types::IsFlexVar { st_p0: st_p0.clone(), t_p1: (**a_p2).clone() })),
            _ => ::prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start IsWaitingAssoc, x`: what the function value is when passed to `@Run`.
pub fn start_is_waiting_assoc_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<bool>> {
    ::std::rc::Rc::new(IsWaitingAssoc { st_p0, t_p1 })
}

/// ```prism
/// Defer: fn St, Ty, Ty, Range -> St
/// ```
pub fn defer_f(st_p0: &crate::check::types::St, e_p1: &crate::check::types::Ty, f_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.deferred_p = crate::prelude::push(&this.deferred_p, &crate::check::types::Waiting { expected_p: e_p1.clone(), found_p: f_p2.clone(), span_p: span_p3.clone(), file_p: st_p0.file_p.clone() });
    this
}

/// ```prism
/// RetryDeferred: unbounded fn St -> St
/// ```
pub fn retry_deferred_f(st_p0: &crate::check::types::St) -> crate::check::types::St {
    let waiting_p1 = st_p0.deferred_p.clone();
    let cleared_p2 = {
        let mut this: crate::check::types::St = st_p0.clone();
        this.deferred_p = crate::prelude::Array::new();
        this
    };
    let done_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(waiting_p1.clone(), cleared_p2.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Waiting)| crate::prelude::entered(crate::prelude::once_job(move || {
        let s_p4 = p0;
        let w_p5 = p1;
        {
            let there_p6 = {
                let mut this: crate::check::types::St = s_p4.clone();
                this.file_p = w_p5.file_p.clone();
                this
            };
            ::prism_rtl::Turn::More(::std::rc::Rc::new(Unify { st_p0: there_p6.clone(), expected_p1: w_p5.expected_p.clone(), found_p2: w_p5.found_p.clone(), span_p3: w_p5.span_p.clone() }))
        }
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::types::Waiting)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>));
    let mut this: crate::check::types::St = done_p3.clone();
    this.file_p = st_p0.file_p.clone();
    this
}

/// The step machine of `RetryDeferred`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RetryDeferred: unbounded fn St -> St
/// ```
pub struct RetryDeferred {
    pub st_p0: crate::check::types::St,
}

impl ::prism_rtl::Job<crate::check::types::St> for RetryDeferred {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let waiting_p1 = st_p0.deferred_p.clone();
        let cleared_p2 = {
            let mut this: crate::check::types::St = st_p0.clone();
            this.deferred_p = crate::prelude::Array::new();
            this
        };
        let st_p0x = st_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(waiting_p1.clone(), cleared_p2.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Waiting)| crate::prelude::entered(crate::prelude::once_job(move || {
            let s_p4 = p0;
            let w_p5 = p1;
            {
                let there_p6 = {
                    let mut this: crate::check::types::St = s_p4.clone();
                    this.file_p = w_p5.file_p.clone();
                    this
                };
                ::prism_rtl::Turn::More(::std::rc::Rc::new(Unify { st_p0: there_p6.clone(), expected_p1: w_p5.expected_p.clone(), found_p2: w_p5.found_p.clone(), span_p3: w_p5.span_p.clone() }))
            }
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::types::Waiting)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>), move |fold_6580: crate::check::types::St| {
            let done_p3 = fold_6580;
            ::prism_rtl::Turn::Finished({
                let mut this: crate::check::types::St = done_p3.clone();
                this.file_p = st_p0x.file_p.clone();
                this
            })
        })
    }
}

/// `Start RetryDeferred, x`: what the function value is when passed to `@Run`.
pub fn start_retry_deferred_f(st_p0: crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(RetryDeferred { st_p0 })
}

/// ```prism
/// Undecided: unbounded fn St -> St
/// ```
pub fn undecided_f(st0_p0: &crate::check::types::St) -> crate::check::types::St {
    let st_p1 = retry_deferred_f(st0_p0);
    let left_p2 = crate::prelude::run_to_end(crate::prelude::fold_job(st_p1.deferred_p.clone(), st_p1.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Waiting)| crate::prelude::entered(crate::prelude::once_job(move || {
        let s_p3 = p0;
        let w_p4 = p1;
        {
            let there_p5 = {
                let mut this: crate::check::types::St = s_p3.clone();
                this.file_p = w_p4.file_p.clone();
                this
            };
            crate::prelude::call_then(crate::check::types::start_show_ty_f(s_p3.clone(), w_p4.expected_p.clone()), move |show_ty_f_7205: crate::prelude::Text| crate::prelude::call_then(crate::check::types::start_show_ty_f(s_p3.clone(), w_p4.found_p.clone()), move |show_ty_f_7232: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&there_p5, &crate::prelude::Text::lit("ambiguous"), &w_p4.span_p, &crate::prelude::Text::from(format!("nothing decides the associated type in `{}` = `{}`", &show_ty_f_7205, &show_ty_f_7232)), &crate::prelude::Text::lit("annotate the value\'s type")))))
        }
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::types::Waiting)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>));
    let mut this: crate::check::types::St = left_p2.clone();
    this.deferred_p = crate::prelude::Array::new();
    this.file_p = st_p1.file_p.clone();
    this
}

/// The step machine of `Undecided`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Undecided: unbounded fn St -> St
/// ```
pub struct Undecided {
    pub st0_p0: crate::check::types::St,
}

impl ::prism_rtl::Job<crate::check::types::St> for Undecided {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st0_p0 = &self.st0_p0;
        let st0_p0x = st0_p0.clone();
        crate::prelude::call_then(start_retry_deferred_f(st0_p0x.clone()), move |retry_deferred_f_6997: crate::check::types::St| {
            let st_p1 = retry_deferred_f_6997;
            crate::prelude::call_value(crate::prelude::fold_job(st_p1.deferred_p.clone(), st_p1.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::Waiting)| crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p3 = p0;
                let w_p4 = p1;
                {
                    let there_p5 = {
                        let mut this: crate::check::types::St = s_p3.clone();
                        this.file_p = w_p4.file_p.clone();
                        this
                    };
                    crate::prelude::call_then(crate::check::types::start_show_ty_f(s_p3.clone(), w_p4.expected_p.clone()), move |show_ty_f_7205: crate::prelude::Text| crate::prelude::call_then(crate::check::types::start_show_ty_f(s_p3.clone(), w_p4.found_p.clone()), move |show_ty_f_7232: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&there_p5, &crate::prelude::Text::lit("ambiguous"), &w_p4.span_p, &crate::prelude::Text::from(format!("nothing decides the associated type in `{}` = `{}`", &show_ty_f_7205, &show_ty_f_7232)), &crate::prelude::Text::lit("annotate the value\'s type")))))
                }
            }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, crate::check::types::Waiting)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>), move |fold_7030: crate::check::types::St| {
                let left_p2 = fold_7030;
                ::prism_rtl::Turn::Finished({
                    let mut this: crate::check::types::St = left_p2.clone();
                    this.deferred_p = crate::prelude::Array::new();
                    this.file_p = st_p1.file_p.clone();
                    this
                })
            })
        })
    }
}

/// `Start Undecided, x`: what the function value is when passed to `@Run`.
pub fn start_undecided_f(st0_p0: crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(Undecided { st0_p0 })
}

/// ```prism
/// UnifyHeads: unbounded fn St, Ty, Ty, Range -> ((Text, St))
/// ```
pub fn unify_heads_f(st_p0: &crate::check::types::St, e_p1: &crate::check::types::Ty, f_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> (crate::prelude::Text, crate::check::types::St) {
    match (e_p1.clone(), f_p2.clone()) {
        (crate::check::types::Ty::TyErr, _) => (crate::prelude::Text::lit(""), st_p0.clone()),
        (_, crate::check::types::Ty::TyErr) => (crate::prelude::Text::lit(""), st_p0.clone()),
        (crate::check::types::Ty::TyFlex(a_p4), crate::check::types::Ty::TyFlex(b_p5)) => if &a_p4 == &b_p5 {
            (crate::prelude::Text::lit(""), st_p0.clone())
        } else {
            (crate::prelude::Text::lit(""), merge_vars_f(st_p0, &a_p4, &b_p5))
        },
        (crate::check::types::Ty::TyFlex(a_p6), t_p7) => bind_var_f(st_p0, &a_p6, &t_p7, span_p3),
        (t_p8, crate::check::types::Ty::TyFlex(b_p9)) => bind_var_f(st_p0, &b_p9, &t_p8, span_p3),
        (crate::check::types::Ty::TyRigid(a_pa), crate::check::types::Ty::TyRigid(b_pb)) => if &a_pa == &b_pb {
            (crate::prelude::Text::lit(""), st_p0.clone())
        } else {
            (crate::prelude::Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Ty::TyQ(a_pc), crate::check::types::Ty::TyQ(b_pd)) => if &a_pc == &b_pd {
            (crate::prelude::Text::lit(""), st_p0.clone())
        } else {
            (crate::prelude::Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Ty::TyCon(a_pe, xs_pf), crate::check::types::Ty::TyCon(b_pg, ys_ph)) => if (&a_pe == &b_pg) && (&crate::prelude::len(&xs_pf) == &crate::prelude::len(&ys_ph)) {
            unify_all_f(st_p0, &xs_pf, &ys_ph, span_p3)
        } else {
            (crate::prelude::Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Ty::TyFn(c1_pi, ps_pj, r1_pk), crate::check::types::Ty::TyFn(c2_pl, qs_pm, r2_pn)) => if &crate::prelude::len(&ps_pj) == &crate::prelude::len(&qs_pm) {
            {
                let (v_po, st2_pp) = crate::check::types::colors::unify_col_f(st_p0, &c1_pi, &c2_pl);
                if &v_po != &crate::prelude::Text::lit("") {
                    (v_po.clone(), st2_pp.clone())
                } else {
                    unify_all_f(&st2_pp, &crate::prelude::push(&ps_pj, &*r1_pk), &crate::prelude::push(&qs_pm, &*r2_pn), span_p3)
                }
            }
        } else {
            (crate::prelude::Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Ty::TyTuple(xs_pq), crate::check::types::Ty::TyTuple(ys_pr)) => if &crate::prelude::len(&xs_pq) == &crate::prelude::len(&ys_pr) {
            unify_all_f(st_p0, &xs_pq, &ys_pr, span_p3)
        } else {
            (crate::prelude::Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Ty::TyArray(x_ps), crate::check::types::Ty::TyArray(y_pt)) => unify_in_f(st_p0, &*x_ps, &*y_pt, span_p3),
        (crate::check::types::Ty::TyMap(k1_pu, v1_pv), crate::check::types::Ty::TyMap(k2_p10, v2_p11)) => unify_all_f(st_p0, &crate::prelude::Array::from(vec![(*k1_pu).clone(), (*v1_pv).clone()]), &crate::prelude::Array::from(vec![(*k2_p10).clone(), (*v2_p11).clone()]), span_p3),
        (crate::check::types::Ty::TySig(s1_p12, i1_p13), crate::check::types::Ty::TySig(s2_p14, i2_p15)) => if &s1_p12 == &s2_p14 {
            unify_in_f(st_p0, &*i1_p13, &*i2_p15, span_p3)
        } else {
            (crate::prelude::Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Ty::TyAt(i1_p16, r1_p17), crate::check::types::Ty::TyAt(i2_p18, r2_p19)) => {
            let (v_p1a, st2_p1b) = unify_in_f(st_p0, &*i1_p16, &*i2_p18, span_p3);
            if &v_p1a != &crate::prelude::Text::lit("") {
                (v_p1a.clone(), st2_p1b.clone())
            } else {
                unify_row_f(&st2_p1b, &r1_p17, &r2_p19, span_p3)
            }
        },
        (crate::check::types::Ty::TyElem(r1_p1c, o1_p1d), crate::check::types::Ty::TyElem(r2_p1e, o2_p1f)) => {
            let (v_p1g, st2_p1h) = unify_row_f(st_p0, &r1_p1c, &r2_p1e, span_p3);
            if &v_p1g != &crate::prelude::Text::lit("") {
                (v_p1g.clone(), st2_p1h.clone())
            } else {
                unify_in_f(&st2_p1h, &*o1_p1d, &*o2_p1f, span_p3)
            }
        },
        (crate::check::types::Ty::TyElemAny(r1_p1i), crate::check::types::Ty::TyElemAny(r2_p1j)) => unify_row_f(st_p0, &r1_p1i, &r2_p1j, span_p3),
        (crate::check::types::Ty::TyAssoc(t1_p1k, n1_p1l, a1_p1m), crate::check::types::Ty::TyAssoc(t2_p1n, n2_p1o, a2_p1p)) => if (&t1_p1k == &t2_p1n) && (&n1_p1l == &n2_p1o) {
            unify_in_f(st_p0, &*a1_p1m, &*a2_p1p, span_p3)
        } else {
            (crate::prelude::Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Ty::TyAny(xs_p1q), crate::check::types::Ty::TyAny(ys_p1r)) => if &crate::check::types::sort_texts_f(&xs_p1q) == &crate::check::types::sort_texts_f(&ys_p1r) {
            (crate::prelude::Text::lit(""), st_p0.clone())
        } else {
            (crate::prelude::Text::lit("mismatch"), st_p0.clone())
        },
        _ => (crate::prelude::Text::lit("mismatch"), st_p0.clone()),
    }
}

/// The step machine of `UnifyHeads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyHeads: unbounded fn St, Ty, Ty, Range -> ((Text, St))
/// ```
pub struct UnifyHeads {
    pub st_p0: crate::check::types::St,
    pub e_p1: crate::check::types::Ty,
    pub f_p2: crate::check::types::Ty,
    pub span_p3: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::St)> for UnifyHeads {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Text, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let e_p1 = &self.e_p1;
        let f_p2 = &self.f_p2;
        let span_p3 = &self.span_p3;
        match (e_p1.clone(), f_p2.clone()) {
            (crate::check::types::Ty::TyErr, _) => ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), st_p0.clone())),
            (_, crate::check::types::Ty::TyErr) => ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), st_p0.clone())),
            (crate::check::types::Ty::TyFlex(a_p4), crate::check::types::Ty::TyFlex(b_p5)) => if &a_p4 == &b_p5 {
                ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), st_p0.clone()))
            } else {
                ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), merge_vars_f(st_p0, &a_p4, &b_p5)))
            },
            (crate::check::types::Ty::TyFlex(a_p6), t_p7) => ::prism_rtl::Turn::More(::std::rc::Rc::new(BindVar { st_p0: st_p0.clone(), n_p1: a_p6.clone(), t_p2: t_p7.clone(), span_p3: span_p3.clone() })),
            (t_p8, crate::check::types::Ty::TyFlex(b_p9)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(BindVar { st_p0: st_p0.clone(), n_p1: b_p9.clone(), t_p2: t_p8.clone(), span_p3: span_p3.clone() })),
            (crate::check::types::Ty::TyRigid(a_pa), crate::check::types::Ty::TyRigid(b_pb)) => if &a_pa == &b_pb {
                ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), st_p0.clone()))
            } else {
                ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("mismatch"), st_p0.clone()))
            },
            (crate::check::types::Ty::TyQ(a_pc), crate::check::types::Ty::TyQ(b_pd)) => if &a_pc == &b_pd {
                ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), st_p0.clone()))
            } else {
                ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("mismatch"), st_p0.clone()))
            },
            (crate::check::types::Ty::TyCon(a_pe, xs_pf), crate::check::types::Ty::TyCon(b_pg, ys_ph)) => if (&a_pe == &b_pg) && (&crate::prelude::len(&xs_pf) == &crate::prelude::len(&ys_ph)) {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(UnifyAll { st_p0: st_p0.clone(), xs_p1: xs_pf.clone(), ys_p2: ys_ph.clone(), span_p3: span_p3.clone() }))
            } else {
                ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("mismatch"), st_p0.clone()))
            },
            (crate::check::types::Ty::TyFn(c1_pi, ps_pj, r1_pk), crate::check::types::Ty::TyFn(c2_pl, qs_pm, r2_pn)) => if &crate::prelude::len(&ps_pj) == &crate::prelude::len(&qs_pm) {
                {
                    let span_p3x = span_p3.clone();
                    let st_p0x = st_p0.clone();
                    crate::prelude::call_then(crate::check::types::colors::start_unify_col_f(st_p0x.clone(), c1_pi.clone(), c2_pl.clone()), move |unify_col_f_8152: (crate::prelude::Text, crate::check::types::St)| {
                        let (v_po, st2_pp) = unify_col_f_8152;
                        if &v_po != &crate::prelude::Text::lit("") {
                            ::prism_rtl::Turn::Finished((v_po.clone(), st2_pp.clone()))
                        } else {
                            ::prism_rtl::Turn::More(::std::rc::Rc::new(UnifyAll { st_p0: st2_pp.clone(), xs_p1: crate::prelude::push(&ps_pj, &*r1_pk), ys_p2: crate::prelude::push(&qs_pm, &*r2_pn), span_p3: span_p3x.clone() }))
                        }
                    })
                }
            } else {
                ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("mismatch"), st_p0.clone()))
            },
            (crate::check::types::Ty::TyTuple(xs_pq), crate::check::types::Ty::TyTuple(ys_pr)) => if &crate::prelude::len(&xs_pq) == &crate::prelude::len(&ys_pr) {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(UnifyAll { st_p0: st_p0.clone(), xs_p1: xs_pq.clone(), ys_p2: ys_pr.clone(), span_p3: span_p3.clone() }))
            } else {
                ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("mismatch"), st_p0.clone()))
            },
            (crate::check::types::Ty::TyArray(x_ps), crate::check::types::Ty::TyArray(y_pt)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(UnifyIn { st_p0: st_p0.clone(), expected_p1: (*x_ps).clone(), found_p2: (*y_pt).clone(), span_p3: span_p3.clone() })),
            (crate::check::types::Ty::TyMap(k1_pu, v1_pv), crate::check::types::Ty::TyMap(k2_p10, v2_p11)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(UnifyAll { st_p0: st_p0.clone(), xs_p1: crate::prelude::Array::from(vec![(*k1_pu).clone(), (*v1_pv).clone()]), ys_p2: crate::prelude::Array::from(vec![(*k2_p10).clone(), (*v2_p11).clone()]), span_p3: span_p3.clone() })),
            (crate::check::types::Ty::TySig(s1_p12, i1_p13), crate::check::types::Ty::TySig(s2_p14, i2_p15)) => if &s1_p12 == &s2_p14 {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(UnifyIn { st_p0: st_p0.clone(), expected_p1: (*i1_p13).clone(), found_p2: (*i2_p15).clone(), span_p3: span_p3.clone() }))
            } else {
                ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("mismatch"), st_p0.clone()))
            },
            (crate::check::types::Ty::TyAt(i1_p16, r1_p17), crate::check::types::Ty::TyAt(i2_p18, r2_p19)) => {
                let span_p3x = span_p3.clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_then(start_unify_in_f(st_p0x.clone(), (*i1_p16).clone(), (*i2_p18).clone(), span_p3x.clone()), move |unify_in_f_8736: (crate::prelude::Text, crate::check::types::St)| {
                    let (v_p1a, st2_p1b) = unify_in_f_8736;
                    if &v_p1a != &crate::prelude::Text::lit("") {
                        ::prism_rtl::Turn::Finished((v_p1a.clone(), st2_p1b.clone()))
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(UnifyRow { st_p0: st2_p1b.clone(), a0_p1: r1_p17.clone(), b0_p2: r2_p19.clone(), span_p3: span_p3x.clone() }))
                    }
                })
            },
            (crate::check::types::Ty::TyElem(r1_p1c, o1_p1d), crate::check::types::Ty::TyElem(r2_p1e, o2_p1f)) => {
                let span_p3x = span_p3.clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_then(start_unify_row_f(st_p0x.clone(), r1_p1c.clone(), r2_p1e.clone(), span_p3x.clone()), move |unify_row_f_8904: (crate::prelude::Text, crate::check::types::St)| {
                    let (v_p1g, st2_p1h) = unify_row_f_8904;
                    if &v_p1g != &crate::prelude::Text::lit("") {
                        ::prism_rtl::Turn::Finished((v_p1g.clone(), st2_p1h.clone()))
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(UnifyIn { st_p0: st2_p1h.clone(), expected_p1: (*o1_p1d).clone(), found_p2: (*o2_p1f).clone(), span_p3: span_p3x.clone() }))
                    }
                })
            },
            (crate::check::types::Ty::TyElemAny(r1_p1i), crate::check::types::Ty::TyElemAny(r2_p1j)) => ::prism_rtl::Turn::More(::std::rc::Rc::new(UnifyRow { st_p0: st_p0.clone(), a0_p1: r1_p1i.clone(), b0_p2: r2_p1j.clone(), span_p3: span_p3.clone() })),
            (crate::check::types::Ty::TyAssoc(t1_p1k, n1_p1l, a1_p1m), crate::check::types::Ty::TyAssoc(t2_p1n, n2_p1o, a2_p1p)) => if (&t1_p1k == &t2_p1n) && (&n1_p1l == &n2_p1o) {
                ::prism_rtl::Turn::More(::std::rc::Rc::new(UnifyIn { st_p0: st_p0.clone(), expected_p1: (*a1_p1m).clone(), found_p2: (*a2_p1p).clone(), span_p3: span_p3.clone() }))
            } else {
                ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("mismatch"), st_p0.clone()))
            },
            (crate::check::types::Ty::TyAny(xs_p1q), crate::check::types::Ty::TyAny(ys_p1r)) => if &crate::check::types::sort_texts_f(&xs_p1q) == &crate::check::types::sort_texts_f(&ys_p1r) {
                ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), st_p0.clone()))
            } else {
                ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("mismatch"), st_p0.clone()))
            },
            _ => ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("mismatch"), st_p0.clone())),
        }
    }
}

/// `Start UnifyHeads, x`: what the function value is when passed to `@Run`.
pub fn start_unify_heads_f(st_p0: crate::check::types::St, e_p1: crate::check::types::Ty, f_p2: crate::check::types::Ty, span_p3: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::St)>> {
    ::std::rc::Rc::new(UnifyHeads { st_p0, e_p1, f_p2, span_p3 })
}

/// ```prism
/// UnifyAll: unbounded fn St, [Ty], [Ty], Range -> ((Text, St))
/// ```
pub fn unify_all_f(st_p0: &crate::check::types::St, xs_p1: &crate::prelude::Array<crate::check::types::Ty>, ys_p2: &crate::prelude::Array<crate::check::types::Ty>, span_p3: &crate::syntax::Range) -> (crate::prelude::Text, crate::check::types::St) {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(xs_p1)), (crate::prelude::Text::lit(""), st_p0.clone()), {
        let xs_p1x = xs_p1.clone();
        let ys_p2x = ys_p2.clone();
        let span_p3x = span_p3.clone();
        ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Text, crate::check::types::St), crate::prelude::Nat)| {
            let xs_p1xy = xs_p1x.clone();
            let ys_p2xy = ys_p2x.clone();
            let span_p3xy = span_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (v_p4, s_p5) = p0;
                let i_p6 = p1;
                if &v_p4 != &crate::prelude::Text::lit("") {
                    ::prism_rtl::Turn::Finished((v_p4.clone(), s_p5.clone()))
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(UnifyIn { st_p0: s_p5.clone(), expected_p1: crate::prelude::or(&crate::prelude::index(&xs_p1xy, &i_p6), &crate::check::types::Ty::TyErr), found_p2: crate::prelude::or(&crate::prelude::index(&ys_p2xy, &i_p6), &crate::check::types::Ty::TyErr), span_p3: span_p3xy.clone() }))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Text, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::St)>>>
    }))
}

/// The step machine of `UnifyAll`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyAll: unbounded fn St, [Ty], [Ty], Range -> ((Text, St))
/// ```
pub struct UnifyAll {
    pub st_p0: crate::check::types::St,
    pub xs_p1: crate::prelude::Array<crate::check::types::Ty>,
    pub ys_p2: crate::prelude::Array<crate::check::types::Ty>,
    pub span_p3: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::St)> for UnifyAll {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Text, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let xs_p1 = &self.xs_p1;
        let ys_p2 = &self.ys_p2;
        let span_p3 = &self.span_p3;
        crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(xs_p1)), (crate::prelude::Text::lit(""), st_p0.clone()), {
            let xs_p1x = xs_p1.clone();
            let ys_p2x = ys_p2.clone();
            let span_p3x = span_p3.clone();
            ::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Text, crate::check::types::St), crate::prelude::Nat)| {
                let xs_p1xy = xs_p1x.clone();
                let ys_p2xy = ys_p2x.clone();
                let span_p3xy = span_p3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (v_p4, s_p5) = p0;
                    let i_p6 = p1;
                    if &v_p4 != &crate::prelude::Text::lit("") {
                        ::prism_rtl::Turn::Finished((v_p4.clone(), s_p5.clone()))
                    } else {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(UnifyIn { st_p0: s_p5.clone(), expected_p1: crate::prelude::or(&crate::prelude::index(&xs_p1xy, &i_p6), &crate::check::types::Ty::TyErr), found_p2: crate::prelude::or(&crate::prelude::index(&ys_p2xy, &i_p6), &crate::check::types::Ty::TyErr), span_p3: span_p3xy.clone() }))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Text, crate::check::types::St), crate::prelude::Nat)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::St)>>>
        }).cycle()
    }
}

/// `Start UnifyAll, x`: what the function value is when passed to `@Run`.
pub fn start_unify_all_f(st_p0: crate::check::types::St, xs_p1: crate::prelude::Array<crate::check::types::Ty>, ys_p2: crate::prelude::Array<crate::check::types::Ty>, span_p3: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::St)>> {
    ::std::rc::Rc::new(UnifyAll { st_p0, xs_p1, ys_p2, span_p3 })
}

/// ```prism
/// MergeVars: fn St, Nat, Nat -> St
/// ```
pub fn merge_vars_f(st_p0: &crate::check::types::St, a_p1: &crate::prelude::Nat, b_p2: &crate::prelude::Nat) -> crate::check::types::St {
    let ia_p3 = crate::check::types::recording::info_of_f(st_p0, a_p1);
    let ib_p4 = crate::check::types::recording::info_of_f(st_p0, b_p2);
    let merged_p5 = crate::check::types::VInfo { plain_p: ia_p3.plain_p || ib_p4.plain_p, level_p: crate::prelude::min(&ia_p3.level_p, &ib_p4.level_p), name_p: if &ib_p4.name_p == &crate::prelude::Text::lit("") {
        ia_p3.name_p.clone()
    } else {
        ib_p4.name_p.clone()
    } };
    let mut this: crate::check::types::St = st_p0.clone();
    this.tys_p = crate::prelude::insert(&this.tys_p, a_p1, &crate::check::types::Ty::TyFlex(b_p2.clone()));
    this.infos_p = crate::prelude::insert(&this.infos_p, b_p2, &merged_p5);
    this
}

/// ```prism
/// BindVar: unbounded fn St, Nat, Ty, Range -> ((Text, St))
/// ```
pub fn bind_var_f(st_p0: &crate::check::types::St, n_p1: &crate::prelude::Nat, t_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> (crate::prelude::Text, crate::check::types::St) {
    let info_p4 = crate::check::types::recording::info_of_f(st_p0, n_p1);
    let stack_p5 = crate::check::types::stack_of_f(st_p0, t_p2);
    if crate::check::types::has_nat_f(&crate::check::types::recording::free_vars_f(st_p0, t_p2), n_p1) {
        (crate::prelude::Text::lit("reported"), crate::check::types::recording::err_f(st_p0, &crate::prelude::Text::lit("occurs"), span_p3, &crate::prelude::Text::from(format!("`t{}` would contain itself: `t{} = {}`", n_p1, n_p1, &crate::check::types::show_ty_f(st_p0, t_p2)))))
    } else {
        if info_p4.plain_p && (&stack_p5 != &crate::prelude::Text::lit("")) {
            if &info_p4.name_p != &crate::prelude::Text::lit("") {
                {
                    let marks_p6 = marks_of_f(&info_p4.name_p);
                    let whole_p7 = crate::prelude::Text::from(format!("{}{}", &marks_p6, &crate::check::types::show_ty_in_f(st_p0, &crate::check::types::recording::zonk_f(st_p0, t_p2), &true)));
                    let at_p8 = crate::prelude::or(&crate::prelude::get(&st_p0.binder_at_p, n_p1), span_p3);
                    let st2_p9 = crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("mark-stack"), &at_p8, &crate::prelude::Text::from(format!("`{}` has type `{}`, whose stack is `{}{}`; the name shows `{}`", &info_p4.name_p, &whole_p7, &marks_p6, &stack_p5, &marks_p6)), &crate::prelude::Text::from(format!("rename to `{}{}{}`", &marks_p6, &stack_p5, &crate::syntax::lexer::chars::drop_prefix_f(&info_p4.name_p, &marks_p6))));
                    (crate::prelude::Text::lit(""), {
                        let mut this: crate::check::types::St = lower_levels_f(&st2_p9, &crate::prelude::append(&crate::check::types::recording::free_vars_f(&st2_p9, t_p2), &crate::check::types::colors::free_col_vars_f(&st2_p9, t_p2)), &info_p4.level_p);
                        this.tys_p = crate::prelude::insert(&this.tys_p, n_p1, t_p2);
                        this
                    })
                }
            } else {
                (crate::prelude::Text::lit("mismatch"), st_p0.clone())
            }
        } else {
            {
                let lowered_pa = lower_levels_f(st_p0, &crate::prelude::append(&crate::check::types::recording::free_vars_f(st_p0, t_p2), &crate::check::types::colors::free_col_vars_f(st_p0, t_p2)), &info_p4.level_p);
                (crate::prelude::Text::lit(""), {
                    let mut this: crate::check::types::St = lowered_pa.clone();
                    this.tys_p = crate::prelude::insert(&this.tys_p, n_p1, t_p2);
                    this
                })
            }
        }
    }
}

/// The step machine of `BindVar`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindVar: unbounded fn St, Nat, Ty, Range -> ((Text, St))
/// ```
pub struct BindVar {
    pub st_p0: crate::check::types::St,
    pub n_p1: crate::prelude::Nat,
    pub t_p2: crate::check::types::Ty,
    pub span_p3: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::St)> for BindVar {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Text, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let n_p1 = &self.n_p1;
        let t_p2 = &self.t_p2;
        let span_p3 = &self.span_p3;
        let info_p4 = crate::check::types::recording::info_of_f(st_p0, n_p1);
        let n_p1x = n_p1.clone();
        let span_p3x = span_p3.clone();
        let st_p0x = st_p0.clone();
        let t_p2x = t_p2.clone();
        crate::prelude::call_then(crate::check::types::start_stack_of_f(st_p0x.clone(), t_p2x.clone()), move |stack_of_f_10171: crate::prelude::Text| {
            let stack_p5 = stack_of_f_10171;
            crate::prelude::call_then(crate::check::types::recording::start_free_vars_f(st_p0x.clone(), t_p2x.clone()), move |free_vars_f_10200: crate::prelude::Array<crate::prelude::Nat>| if crate::check::types::has_nat_f(&free_vars_f_10200, &n_p1x) {
                crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p0x.clone(), t_p2x.clone()), move |show_ty_f_10306: crate::prelude::Text| ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("reported"), crate::check::types::recording::err_f(&st_p0x, &crate::prelude::Text::lit("occurs"), &span_p3x, &crate::prelude::Text::from(format!("`t{}` would contain itself: `t{} = {}`", &n_p1x, &n_p1x, &show_ty_f_10306))))))
            } else {
                if info_p4.plain_p && (&stack_p5 != &crate::prelude::Text::lit("")) {
                    if &info_p4.name_p != &crate::prelude::Text::lit("") {
                        {
                            let marks_p6 = marks_of_f(&info_p4.name_p);
                            crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p0x.clone(), t_p2x.clone()), move |zonk_f_10483: crate::check::types::Ty| crate::prelude::call_then(crate::check::types::start_show_ty_in_f(st_p0x.clone(), zonk_f_10483, true), move |show_ty_in_f_10469: crate::prelude::Text| {
                                let whole_p7 = crate::prelude::Text::from(format!("{}{}", &marks_p6, &show_ty_in_f_10469));
                                let at_p8 = crate::prelude::or(&crate::prelude::get(&st_p0x.binder_at_p, &n_p1x), &span_p3x);
                                let st2_p9 = crate::check::types::recording::err_fix_f(&st_p0x, &crate::prelude::Text::lit("mark-stack"), &at_p8, &crate::prelude::Text::from(format!("`{}` has type `{}`, whose stack is `{}{}`; the name shows `{}`", &info_p4.name_p, &whole_p7, &marks_p6, &stack_p5, &marks_p6)), &crate::prelude::Text::from(format!("rename to `{}{}{}`", &marks_p6, &stack_p5, &crate::syntax::lexer::chars::drop_prefix_f(&info_p4.name_p, &marks_p6))));
                                ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), {
                                    let mut this: crate::check::types::St = lower_levels_f(&st2_p9, &crate::prelude::append(&crate::check::types::recording::free_vars_f(&st2_p9, &t_p2x), &crate::check::types::colors::free_col_vars_f(&st2_p9, &t_p2x)), &info_p4.level_p);
                                    this.tys_p = crate::prelude::insert(&this.tys_p, &n_p1x, &t_p2x);
                                    this
                                }))
                            }))
                        }
                    } else {
                        ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("mismatch"), st_p0x.clone()))
                    }
                } else {
                    crate::prelude::call_then(crate::check::types::recording::start_free_vars_f(st_p0x.clone(), t_p2x.clone()), move |free_vars_f_11148: crate::prelude::Array<crate::prelude::Nat>| crate::prelude::call_then(crate::check::types::colors::start_free_col_vars_f(st_p0x.clone(), t_p2x.clone()), move |free_col_vars_f_11166: crate::prelude::Array<crate::prelude::Nat>| {
                        let lowered_pa = lower_levels_f(&st_p0x, &crate::prelude::append(&free_vars_f_11148, &free_col_vars_f_11166), &info_p4.level_p);
                        ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), {
                            let mut this: crate::check::types::St = lowered_pa.clone();
                            this.tys_p = crate::prelude::insert(&this.tys_p, &n_p1x, &t_p2x);
                            this
                        }))
                    }))
                }
            })
        })
    }
}

/// `Start BindVar, x`: what the function value is when passed to `@Run`.
pub fn start_bind_var_f(st_p0: crate::check::types::St, n_p1: crate::prelude::Nat, t_p2: crate::check::types::Ty, span_p3: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::St)>> {
    ::std::rc::Rc::new(BindVar { st_p0, n_p1, t_p2, span_p3 })
}

/// ```prism
/// MarksOf: fn Text -> Text
/// ```
pub fn marks_of_f(name_p0: &crate::prelude::Text) -> crate::prelude::Text {
    let c_p1 = {
        let mut this: crate::prelude::Cursor = crate::prelude::front(name_p0);
        while let ::std::option::Option::Some((_, next_p2)) = crate::prelude::step(&this) {
            if !is_mark_char_f(&crate::syntax::lexer::chars::char_at_f(&this)) {
                break;
            }
            this = next_p2.clone();
        }
        this
    };
    crate::prelude::before(&c_p1)
}

/// ```prism
/// IsMarkChar: fn Text -> Bool
/// ```
pub fn is_mark_char_f(c_p0: &crate::prelude::Text) -> bool {
    (((((c_p0 == &crate::prelude::Text::lit("$")) || (c_p0 == &crate::prelude::Text::lit("!"))) || (c_p0 == &crate::prelude::Text::lit("@"))) || (c_p0 == &crate::prelude::Text::lit("?"))) || (c_p0 == &crate::prelude::Text::lit("~"))) || (c_p0 == &crate::prelude::Text::lit("&"))
}

/// ```prism
/// LowerLevels: fn St, [Nat], Nat -> St
/// ```
pub fn lower_levels_f(st_p0: &crate::check::types::St, vs_p1: &crate::prelude::Array<crate::prelude::Nat>, level_p2: &crate::prelude::Nat) -> crate::check::types::St {
    crate::prelude::fold(vs_p1, st_p0, &(|s_p3: &crate::check::types::St, v_p4: &crate::prelude::Nat| lower_one_f(s_p3, v_p4, level_p2)))
}

/// ```prism
/// LowerOne: fn St, Nat, Nat -> St
/// ```
pub fn lower_one_f(s_p0: &crate::check::types::St, v_p1: &crate::prelude::Nat, level_p2: &crate::prelude::Nat) -> crate::check::types::St {
    let i_p3 = crate::check::types::recording::info_of_f(s_p0, v_p1);
    if &i_p3.level_p <= level_p2 {
        s_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = s_p0.clone();
            this.infos_p = crate::prelude::insert(&this.infos_p, v_p1, &crate::check::types::VInfo { plain_p: i_p3.plain_p, level_p: level_p2.clone(), name_p: i_p3.name_p.clone() });
            this
        }
    }
}

/// ```prism
/// UnifyRow: unbounded fn St, Rw, Rw, Range -> ((Text, St))
/// ```
pub fn unify_row_f(st_p0: &crate::check::types::St, a0_p1: &crate::check::types::Rw, b0_p2: &crate::check::types::Rw, span_p3: &crate::syntax::Range) -> (crate::prelude::Text, crate::check::types::St) {
    let a_p4 = crate::check::types::recording::walk_row_f(st_p0, a0_p1);
    let b_p5 = crate::check::types::recording::walk_row_f(st_p0, b0_p2);
    let only_a_p6 = crate::check::types::minus_texts_f(&a_p4.fams_p, &b_p5.fams_p);
    let only_b_p7 = crate::check::types::minus_texts_f(&b_p5.fams_p, &a_p4.fams_p);
    match (a_p4.tail_p.clone(), b_p5.tail_p.clone()) {
        (crate::check::types::Tail::TlClosed, crate::check::types::Tail::TlClosed) => if (&crate::prelude::len(&only_a_p6) == &crate::prelude::Nat::from(0u32)) && (&crate::prelude::len(&only_b_p7) == &crate::prelude::Nat::from(0u32)) {
            (crate::prelude::Text::lit(""), st_p0.clone())
        } else {
            (crate::prelude::Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Tail::TlFlex(x_p8), crate::check::types::Tail::TlFlex(y_p9)) => if &x_p8 == &y_p9 {
            if (&crate::prelude::len(&only_a_p6) == &crate::prelude::Nat::from(0u32)) && (&crate::prelude::len(&only_b_p7) == &crate::prelude::Nat::from(0u32)) {
                (crate::prelude::Text::lit(""), st_p0.clone())
            } else {
                (crate::prelude::Text::lit("mismatch"), st_p0.clone())
            }
        } else {
            {
                let lacking_pa = crate::check::types::union_texts_f(&crate::check::types::union_texts_f(&lacks_of_f(st_p0, &x_p8), &lacks_of_f(st_p0, &y_p9)), &crate::check::types::union_texts_f(&a_p4.fams_p, &b_p5.fams_p));
                let (fresh_pb, st2_pc) = crate::check::types::recording::fresh_row_f(st_p0, &lacking_pa);
                let (v1_pd, st3_pe) = bind_row_f(&st2_pc, &x_p8, &crate::check::types::Rw { fams_p: only_b_p7.clone(), minus_p: crate::prelude::Array::new(), tail_p: fresh_pb.tail_p.clone() }, span_p3);
                if &v1_pd != &crate::prelude::Text::lit("") {
                    (v1_pd.clone(), st3_pe.clone())
                } else {
                    bind_row_f(&st3_pe, &y_p9, &crate::check::types::Rw { fams_p: only_a_p6.clone(), minus_p: crate::prelude::Array::new(), tail_p: fresh_pb.tail_p.clone() }, span_p3)
                }
            }
        },
        (crate::check::types::Tail::TlFlex(x_pf), other_pg) => if &crate::prelude::len(&only_a_p6) == &crate::prelude::Nat::from(0u32) {
            bind_row_f(st_p0, &x_pf, &crate::check::types::Rw { fams_p: only_b_p7.clone(), minus_p: b_p5.minus_p.clone(), tail_p: other_pg }, span_p3)
        } else {
            (crate::prelude::Text::lit("mismatch"), st_p0.clone())
        },
        (other_ph, crate::check::types::Tail::TlFlex(y_pi)) => if &crate::prelude::len(&only_b_p7) == &crate::prelude::Nat::from(0u32) {
            bind_row_f(st_p0, &y_pi, &crate::check::types::Rw { fams_p: only_a_p6.clone(), minus_p: a_p4.minus_p.clone(), tail_p: other_ph }, span_p3)
        } else {
            (crate::prelude::Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Tail::TlRigid(x_pj), crate::check::types::Tail::TlRigid(y_pk)) => if ((&x_pj == &y_pk) && (&crate::prelude::len(&only_a_p6) == &crate::prelude::Nat::from(0u32))) && (&crate::prelude::len(&only_b_p7) == &crate::prelude::Nat::from(0u32)) {
            (crate::prelude::Text::lit(""), st_p0.clone())
        } else {
            (crate::prelude::Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Tail::TlQ(x_pl), crate::check::types::Tail::TlQ(y_pm)) => if ((&x_pl == &y_pm) && (&crate::prelude::len(&only_a_p6) == &crate::prelude::Nat::from(0u32))) && (&crate::prelude::len(&only_b_p7) == &crate::prelude::Nat::from(0u32)) {
            (crate::prelude::Text::lit(""), st_p0.clone())
        } else {
            (crate::prelude::Text::lit("mismatch"), st_p0.clone())
        },
        _ => (crate::prelude::Text::lit("mismatch"), st_p0.clone()),
    }
}

/// The step machine of `UnifyRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyRow: unbounded fn St, Rw, Rw, Range -> ((Text, St))
/// ```
pub struct UnifyRow {
    pub st_p0: crate::check::types::St,
    pub a0_p1: crate::check::types::Rw,
    pub b0_p2: crate::check::types::Rw,
    pub span_p3: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::St)> for UnifyRow {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Text, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let a0_p1 = &self.a0_p1;
        let b0_p2 = &self.b0_p2;
        let span_p3 = &self.span_p3;
        let a0_p1x = a0_p1.clone();
        let b0_p2x = b0_p2.clone();
        let span_p3x = span_p3.clone();
        let st_p0x = st_p0.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p0x.clone(), a0_p1x.clone()), move |walk_row_f_12208: crate::check::types::Rw| {
            let a_p4 = walk_row_f_12208;
            crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p0x.clone(), b0_p2x.clone()), move |walk_row_f_12235: crate::check::types::Rw| {
                let b_p5 = walk_row_f_12235;
                let only_a_p6 = crate::check::types::minus_texts_f(&a_p4.fams_p, &b_p5.fams_p);
                let only_b_p7 = crate::check::types::minus_texts_f(&b_p5.fams_p, &a_p4.fams_p);
                match (a_p4.tail_p.clone(), b_p5.tail_p.clone()) {
                    (crate::check::types::Tail::TlClosed, crate::check::types::Tail::TlClosed) => if (&crate::prelude::len(&only_a_p6) == &crate::prelude::Nat::from(0u32)) && (&crate::prelude::len(&only_b_p7) == &crate::prelude::Nat::from(0u32)) {
                        ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), st_p0x.clone()))
                    } else {
                        ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("mismatch"), st_p0x.clone()))
                    },
                    (crate::check::types::Tail::TlFlex(x_p8), crate::check::types::Tail::TlFlex(y_p9)) => if &x_p8 == &y_p9 {
                        if (&crate::prelude::len(&only_a_p6) == &crate::prelude::Nat::from(0u32)) && (&crate::prelude::len(&only_b_p7) == &crate::prelude::Nat::from(0u32)) {
                            ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), st_p0x.clone()))
                        } else {
                            ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("mismatch"), st_p0x.clone()))
                        }
                    } else {
                        {
                            let lacking_pa = crate::check::types::union_texts_f(&crate::check::types::union_texts_f(&lacks_of_f(&st_p0x, &x_p8), &lacks_of_f(&st_p0x, &y_p9)), &crate::check::types::union_texts_f(&a_p4.fams_p, &b_p5.fams_p));
                            let (fresh_pb, st2_pc) = crate::check::types::recording::fresh_row_f(&st_p0x, &lacking_pa);
                            crate::prelude::call_then(start_bind_row_f(st2_pc.clone(), x_p8.clone(), crate::check::types::Rw { fams_p: only_b_p7.clone(), minus_p: crate::prelude::Array::new(), tail_p: fresh_pb.tail_p.clone() }, span_p3x.clone()), move |bind_row_f_12849: (crate::prelude::Text, crate::check::types::St)| {
                                let (v1_pd, st3_pe) = bind_row_f_12849;
                                if &v1_pd != &crate::prelude::Text::lit("") {
                                    ::prism_rtl::Turn::Finished((v1_pd.clone(), st3_pe.clone()))
                                } else {
                                    ::prism_rtl::Turn::More(::std::rc::Rc::new(BindRow { st_p0: st3_pe.clone(), n_p1: y_p9.clone(), rw_p2: crate::check::types::Rw { fams_p: only_a_p6.clone(), minus_p: crate::prelude::Array::new(), tail_p: fresh_pb.tail_p.clone() }, span_p3: span_p3x.clone() }))
                                }
                            })
                        }
                    },
                    (crate::check::types::Tail::TlFlex(x_pf), other_pg) => if &crate::prelude::len(&only_a_p6) == &crate::prelude::Nat::from(0u32) {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(BindRow { st_p0: st_p0x.clone(), n_p1: x_pf.clone(), rw_p2: crate::check::types::Rw { fams_p: only_b_p7.clone(), minus_p: b_p5.minus_p.clone(), tail_p: other_pg.clone() }, span_p3: span_p3x.clone() }))
                    } else {
                        ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("mismatch"), st_p0x.clone()))
                    },
                    (other_ph, crate::check::types::Tail::TlFlex(y_pi)) => if &crate::prelude::len(&only_b_p7) == &crate::prelude::Nat::from(0u32) {
                        ::prism_rtl::Turn::More(::std::rc::Rc::new(BindRow { st_p0: st_p0x.clone(), n_p1: y_pi.clone(), rw_p2: crate::check::types::Rw { fams_p: only_a_p6.clone(), minus_p: a_p4.minus_p.clone(), tail_p: other_ph.clone() }, span_p3: span_p3x.clone() }))
                    } else {
                        ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("mismatch"), st_p0x.clone()))
                    },
                    (crate::check::types::Tail::TlRigid(x_pj), crate::check::types::Tail::TlRigid(y_pk)) => if ((&x_pj == &y_pk) && (&crate::prelude::len(&only_a_p6) == &crate::prelude::Nat::from(0u32))) && (&crate::prelude::len(&only_b_p7) == &crate::prelude::Nat::from(0u32)) {
                        ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), st_p0x.clone()))
                    } else {
                        ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("mismatch"), st_p0x.clone()))
                    },
                    (crate::check::types::Tail::TlQ(x_pl), crate::check::types::Tail::TlQ(y_pm)) => if ((&x_pl == &y_pm) && (&crate::prelude::len(&only_a_p6) == &crate::prelude::Nat::from(0u32))) && (&crate::prelude::len(&only_b_p7) == &crate::prelude::Nat::from(0u32)) {
                        ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), st_p0x.clone()))
                    } else {
                        ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("mismatch"), st_p0x.clone()))
                    },
                    _ => ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("mismatch"), st_p0x.clone())),
                }
            })
        })
    }
}

/// `Start UnifyRow, x`: what the function value is when passed to `@Run`.
pub fn start_unify_row_f(st_p0: crate::check::types::St, a0_p1: crate::check::types::Rw, b0_p2: crate::check::types::Rw, span_p3: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::St)>> {
    ::std::rc::Rc::new(UnifyRow { st_p0, a0_p1, b0_p2, span_p3 })
}

/// ```prism
/// AskField: fn St, Ty, Text, Ty, Range, [Text] -> St
/// ```
pub fn ask_field_f(st_p0: &crate::check::types::St, recv_p1: &crate::check::types::Ty, field_p2: &crate::prelude::Text, result_p3: &crate::check::types::Ty, span_p4: &crate::syntax::Range, owners_p5: &crate::prelude::Array<crate::prelude::Text>) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.field_qs_p = crate::prelude::push(&this.field_qs_p, &FieldQ { recv_p: recv_p1.clone(), field_p: field_p2.clone(), result_p: result_p3.clone(), span_p: span_p4.clone(), file_p: this.file_p.clone(), owners_p: owners_p5.clone(), marks_o: ::std::option::Option::None });
    this
}

/// ```prism
/// MarkLastField: fn St, Ty, Text, Range -> St
/// ```
pub fn mark_last_field_f(st_p0: &crate::check::types::St, result_p1: &crate::check::types::Ty, marks_p2: &crate::prelude::Text, at_p3: &crate::syntax::Range) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.field_qs_p = crate::prelude::each(&this.field_qs_p, &(|q_p4: &FieldQ| if (&q_p4.result_p == result_p1) && (&q_p4.marks_o == &::std::option::Option::None) {
        {
            let mut this: FieldQ = q_p4.clone();
            this.marks_o = ::std::option::Option::Some((marks_p2.clone(), at_p3.clone()));
            this
        }
    } else {
        q_p4.clone()
    }));
    this
}

/// ```prism
/// AskLayer: fn St, Ty, Range, Text -> St
/// ```
pub fn ask_layer_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty, span_p2: &crate::syntax::Range, fname_p3: &crate::prelude::Text) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.layer_qs_p = crate::prelude::push(&this.layer_qs_p, &(t_p1.clone(), span_p2.clone(), fname_p3.clone()));
    this
}

/// ```prism
/// LayerQuestions: unbounded fn St -> St
/// ```
pub fn layer_questions_f(st_p0: &crate::check::types::St) -> crate::check::types::St {
    let qs_p1 = st_p0.layer_qs_p.clone();
    let cleared_p2 = {
        let mut this: crate::check::types::St = st_p0.clone();
        this.layer_qs_p = crate::prelude::Array::new();
        this
    };
    crate::prelude::run_to_end(crate::prelude::fold_job(qs_p1.clone(), cleared_p2.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, (crate::check::types::Ty, crate::syntax::Range, crate::prelude::Text))| crate::prelude::entered(crate::prelude::once_job(move || {
        let s_p3 = p0;
        let (t_p4, span_p5, fname_p6) = p1;
        crate::prelude::call_then(crate::check::types::start_head_sigil_f(s_p3.clone(), t_p4.clone()), move |head_sigil_f_15378: crate::prelude::Text| {
            let h_p7 = head_sigil_f_15378;
            crate::prelude::call_then(crate::check::types::start_is_free_headed_f(s_p3.clone(), t_p4.clone()), move |is_free_headed_f_15405: bool| if (is_free_headed_f_15405 || (&h_p7 == &crate::prelude::Text::lit("$"))) || (&h_p7 == &crate::prelude::Text::lit("!")) {
                ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&s_p3, &crate::prelude::Text::lit("layer-unknown"), &span_p5, &crate::prelude::Text::from(format!("the layer of this argument to `{}` is not known here", &fname_p6)), &crate::prelude::Text::lit("say it where the value is made: a name whose marks declare the layer (`let $x = ...`), `<<T>>` at the application that made it, or a signature on the enclosing `let`")))
            } else {
                ::prism_rtl::Turn::Finished(s_p3.clone())
            })
        })
    }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, (crate::check::types::Ty, crate::syntax::Range, crate::prelude::Text))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>))
}

/// The step machine of `LayerQuestions`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LayerQuestions: unbounded fn St -> St
/// ```
pub struct LayerQuestions {
    pub st_p0: crate::check::types::St,
}

impl ::prism_rtl::Job<crate::check::types::St> for LayerQuestions {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let qs_p1 = st_p0.layer_qs_p.clone();
        let cleared_p2 = {
            let mut this: crate::check::types::St = st_p0.clone();
            this.layer_qs_p = crate::prelude::Array::new();
            this
        };
        crate::prelude::fold_job(qs_p1.clone(), cleared_p2.clone(), ::std::rc::Rc::new(move |(p0, p1): (crate::check::types::St, (crate::check::types::Ty, crate::syntax::Range, crate::prelude::Text))| crate::prelude::entered(crate::prelude::once_job(move || {
            let s_p3 = p0;
            let (t_p4, span_p5, fname_p6) = p1;
            crate::prelude::call_then(crate::check::types::start_head_sigil_f(s_p3.clone(), t_p4.clone()), move |head_sigil_f_15378: crate::prelude::Text| {
                let h_p7 = head_sigil_f_15378;
                crate::prelude::call_then(crate::check::types::start_is_free_headed_f(s_p3.clone(), t_p4.clone()), move |is_free_headed_f_15405: bool| if (is_free_headed_f_15405 || (&h_p7 == &crate::prelude::Text::lit("$"))) || (&h_p7 == &crate::prelude::Text::lit("!")) {
                    ::prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&s_p3, &crate::prelude::Text::lit("layer-unknown"), &span_p5, &crate::prelude::Text::from(format!("the layer of this argument to `{}` is not known here", &fname_p6)), &crate::prelude::Text::lit("say it where the value is made: a name whose marks declare the layer (`let $x = ...`), `<<T>>` at the application that made it, or a signature on the enclosing `let`")))
                } else {
                    ::prism_rtl::Turn::Finished(s_p3.clone())
                })
            })
        }))) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::check::types::St, (crate::check::types::Ty, crate::syntax::Range, crate::prelude::Text))) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>>>).cycle()
    }
}

/// `Start LayerQuestions, x`: what the function value is when passed to `@Run`.
pub fn start_layer_questions_f(st_p0: crate::check::types::St) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::check::types::St>> {
    ::std::rc::Rc::new(LayerQuestions { st_p0 })
}

/// ```prism
/// NameRow: fn St, Tail, Text -> St
/// ```
pub fn name_row_f(st_p0: &crate::check::types::St, tail1: &crate::check::types::Tail, text2: &crate::prelude::Text) -> crate::check::types::St {
    match (tail1, text2) {
        (crate::check::types::Tail::TlFlex(n_p1), q_p2) => {
            let mut this: crate::check::types::St = st_p0.clone();
            this.row_names_p = crate::prelude::insert(&this.row_names_p, n_p1, q_p2);
            this
        },
        (_, _) => st_p0.clone(),
    }
}

/// ```prism
/// RowName: fn St, Nat -> Text
/// ```
pub fn row_name_f(st_p0: &crate::check::types::St, n_p1: &crate::prelude::Nat) -> crate::prelude::Text {
    crate::prelude::or(&crate::prelude::get(&st_p0.row_names_p, n_p1), &crate::prelude::Text::from(format!("r{}", n_p1)))
}

/// ```prism
/// LacksOf: fn St, Nat -> [Text]
/// ```
pub fn lacks_of_f(st_p0: &crate::check::types::St, n_p1: &crate::prelude::Nat) -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::or(&crate::prelude::get(&st_p0.lacks_p, n_p1), &crate::prelude::Array::new())
}

/// ```prism
/// BindRow: unbounded fn St, Nat, Rw, Range -> ((Text, St))
/// ```
pub fn bind_row_f(st_p0: &crate::check::types::St, n_p1: &crate::prelude::Nat, rw_p2: &crate::check::types::Rw, span_p3: &crate::syntax::Range) -> (crate::prelude::Text, crate::check::types::St) {
    let bad_p4 = crate::check::types::inter_texts_f(&lacks_of_f(st_p0, n_p1), &rw_p2.fams_p);
    if &crate::prelude::len(&bad_p4) > &crate::prelude::Nat::from(0u32) {
        {
            let fam_p5 = crate::prelude::or(&crate::prelude::index(&bad_p4, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit(""));
            (crate::prelude::Text::lit("reported"), crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("row-lacks"), span_p3, &crate::prelude::Text::from(format!("`{} | {}.*` promises `{}` has no `{}` tags", &row_name_f(st_p0, n_p1), &fam_p5, &row_name_f(st_p0, n_p1), &fam_p5)), &crate::prelude::Text::from(format!("answer the `{}` tags before this point, or widen the row", &fam_p5))))
        }
    } else {
        {
            let st2_p6 = match &rw_p2.tail_p {
                crate::check::types::Tail::TlFlex(m_p7) => {
                    let mut this: crate::check::types::St = st_p0.clone();
                    this.lacks_p = crate::prelude::insert(&this.lacks_p, m_p7, &crate::check::types::union_texts_f(&lacks_of_f(st_p0, m_p7), &lacks_of_f(st_p0, n_p1)));
                    this
                },
                _ => st_p0.clone(),
            };
            (crate::prelude::Text::lit(""), {
                let mut this: crate::check::types::St = st2_p6.clone();
                this.rows_p = crate::prelude::insert(&this.rows_p, n_p1, rw_p2);
                this
            })
        }
    }
}

/// The step machine of `BindRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindRow: unbounded fn St, Nat, Rw, Range -> ((Text, St))
/// ```
pub struct BindRow {
    pub st_p0: crate::check::types::St,
    pub n_p1: crate::prelude::Nat,
    pub rw_p2: crate::check::types::Rw,
    pub span_p3: crate::syntax::Range,
}

impl ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::St)> for BindRow {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Text, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let n_p1 = &self.n_p1;
        let rw_p2 = &self.rw_p2;
        let span_p3 = &self.span_p3;
        let bad_p4 = crate::check::types::inter_texts_f(&lacks_of_f(st_p0, n_p1), &rw_p2.fams_p);
        if &crate::prelude::len(&bad_p4) > &crate::prelude::Nat::from(0u32) {
            {
                let fam_p5 = crate::prelude::or(&crate::prelude::index(&bad_p4, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit(""));
                ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("reported"), crate::check::types::recording::err_fix_f(st_p0, &crate::prelude::Text::lit("row-lacks"), span_p3, &crate::prelude::Text::from(format!("`{} | {}.*` promises `{}` has no `{}` tags", &row_name_f(st_p0, n_p1), &fam_p5, &row_name_f(st_p0, n_p1), &fam_p5)), &crate::prelude::Text::from(format!("answer the `{}` tags before this point, or widen the row", &fam_p5)))))
            }
        } else {
            {
                let st2_p6 = match &rw_p2.tail_p {
                    crate::check::types::Tail::TlFlex(m_p7) => {
                        let mut this: crate::check::types::St = st_p0.clone();
                        this.lacks_p = crate::prelude::insert(&this.lacks_p, m_p7, &crate::check::types::union_texts_f(&lacks_of_f(st_p0, m_p7), &lacks_of_f(st_p0, n_p1)));
                        this
                    },
                    _ => st_p0.clone(),
                };
                ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), {
                    let mut this: crate::check::types::St = st2_p6.clone();
                    this.rows_p = crate::prelude::insert(&this.rows_p, n_p1, rw_p2);
                    this
                }))
            }
        }
    }
}

/// `Start BindRow, x`: what the function value is when passed to `@Run`.
pub fn start_bind_row_f(st_p0: crate::check::types::St, n_p1: crate::prelude::Nat, rw_p2: crate::check::types::Rw, span_p3: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::check::types::St)>> {
    ::std::rc::Rc::new(BindRow { st_p0, n_p1, rw_p2, span_p3 })
}
