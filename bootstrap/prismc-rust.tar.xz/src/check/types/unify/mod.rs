//! The module `Check.Types.Unify`, from `target/bootstrap/src/prismc/check/types/unify.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `FieldQ`:
///
/// ```prism
/// type FieldQ = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct FieldQ {
    pub recv_p: crate::check::types::Ty,
    pub field_p: Text,
    pub result_p: crate::check::types::Ty,
    pub span_p: crate::syntax::Range,
    pub file_p: Nat,
    pub owners_p: Array<Text>,
    pub marks_o: Option<(Text, crate::syntax::Range)>,
}

impl Show for FieldQ {
    fn show(&self, p: &mut Printer) {
        p.record("FieldQ", &[("recv", &self.recv_p), ("field", &self.field_p), ("result", &self.result_p), ("span", &self.span_p), ("file", &self.file_p), ("owners", &self.owners_p), ("marks", &self.marks_o)]);
    }
}

impl ToPod for FieldQ {
    fn to_pod(&self) -> Pod {
        Pod::record("FieldQ", vec![("recv", self.recv_p.to_pod()), ("field", self.field_p.to_pod()), ("result", self.result_p.to_pod()), ("span", self.span_p.to_pod()), ("file", self.file_p.to_pod()), ("owners", self.owners_p.to_pod()), ("marks", self.marks_o.to_pod())])
    }
}

impl FromPod for FieldQ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(FieldQ { recv_p: FromPod::from_pod(field(p, "recv")?)?, field_p: FromPod::from_pod(field(p, "field")?)?, result_p: FromPod::from_pod(field(p, "result")?)?, span_p: FromPod::from_pod(field(p, "span")?)?, file_p: FromPod::from_pod(field(p, "file")?)?, owners_p: FromPod::from_pod(field(p, "owners")?)?, marks_o: FromPod::from_pod(field(p, "marks")?)? })
    }
}

/// ```prism
/// Unify: unbounded fn St, Ty, Ty, Range -> St
/// ```
pub fn unify_f(st_p0: &crate::check::types::St, expected_p1: &crate::check::types::Ty, found_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> crate::check::types::St {
    let (verdict_p4, st2_p5) = unify_in_f(st_p0, expected_p1, found_p2, span_p3);
    if &verdict_p4 == &Text::lit("mismatch") {
        {
            let e_p6 = crate::check::types::show_ty_f(&st2_p5, expected_p1);
            let f_p7 = crate::check::types::show_ty_f(&st2_p5, found_p2);
            if &e_p6 == &f_p7 {
                crate::check::types::recording::err_f(&st2_p5, &Text::lit("mismatch"), span_p3, &Text::from(format!("expected `{}`, found `{}`", &show_ty_q_f(&st2_p5, expected_p1), &show_ty_q_f(&st2_p5, found_p2))))
            } else {
                crate::check::types::recording::err_f(&st2_p5, &Text::lit("mismatch"), span_p3, &Text::from(format!("expected `{}`, found `{}`", &e_p6, &f_p7)))
            }
        }
    } else {
        st2_p5.clone()
    }
}

/// The step machine of `Unify`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Unify: unbounded fn St, Ty, Ty, Range -> St
/// ```
pub struct Unify {
    pub st_p0: crate::check::types::St,
    pub expected_p1: crate::check::types::Ty,
    pub found_p2: crate::check::types::Ty,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for Unify {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let expected_p1 = &self.expected_p1;
        let found_p2 = &self.found_p2;
        let span_p3 = &self.span_p3;
        let expected_p1x = expected_p1.clone();
        let found_p2x = found_p2.clone();
        let span_p3x = span_p3.clone();
        let st_p0x = st_p0.clone();
        crate::prelude::call_then(start_unify_in_f(st_p0x.clone(), expected_p1x.clone(), found_p2x.clone(), span_p3x.clone()), move |unify_in_f_1030: (Text, crate::check::types::St)| {
            let (verdict_p4, st2_p5) = unify_in_f_1030;
            if &verdict_p4 == &Text::lit("mismatch") {
                crate::prelude::call_then(crate::check::types::start_show_ty_f(st2_p5.clone(), expected_p1x.clone()), move |show_ty_f_1110: Text| {
                    let e_p6 = show_ty_f_1110;
                    crate::prelude::call_then(crate::check::types::start_show_ty_f(st2_p5.clone(), found_p2x.clone()), move |show_ty_f_1147: Text| {
                        let f_p7 = show_ty_f_1147;
                        if &e_p6 == &f_p7 {
                            crate::prelude::call_then(start_show_ty_q_f(st2_p5.clone(), expected_p1x.clone()), move |show_ty_q_f_1223: Text| crate::prelude::call_then(start_show_ty_q_f(st2_p5.clone(), found_p2x.clone()), move |show_ty_q_f_1256: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&st2_p5, &Text::lit("mismatch"), &span_p3x, &Text::from(format!("expected `{}`, found `{}`", &show_ty_q_f_1223, &show_ty_q_f_1256))))))
                        } else {
                            prism_rtl::Turn::Finished(crate::check::types::recording::err_f(&st2_p5, &Text::lit("mismatch"), &span_p3x, &Text::from(format!("expected `{}`, found `{}`", &e_p6, &f_p7))))
                        }
                    })
                })
            } else {
                prism_rtl::Turn::Finished(st2_p5.clone())
            }
        })
    }
}

/// `Start Unify, x`: what the function value is when passed to `@Run`.
pub fn start_unify_f(st_p0: crate::check::types::St, expected_p1: crate::check::types::Ty, found_p2: crate::check::types::Ty, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(Unify { st_p0, expected_p1, found_p2, span_p3 })
}

/// ```prism
/// ShowTyQ: unbounded fn St, Ty -> Text
/// ```
pub fn show_ty_q_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> Text {
    match crate::check::types::recording::zonk_f(st_p0, t_p1) {
        crate::check::types::Ty::TyCon(n_p2, m1487_0_1) if ((&m1487_0_1).len() == 0) => n_p2,
        crate::check::types::Ty::TyCon(n_p3, args_p4) => Text::from(format!("({}{})", &n_p3, &crate::prelude::concat(&crate::prelude::run_to_end(crate::prelude::each_job(args_p4.clone(), {
            let st_p0x = st_p0.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p5 = p0;
                    crate::prelude::call_then(start_show_ty_q_f(st_p0xy.clone(), a_p5.clone()), move |show_ty_q_f_1578: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &show_ty_q_f_1578))))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>
        }))))),
        crate::check::types::Ty::TySig(s_p6, i_p7) => Text::from(format!("{}{}", &s_p6, &show_ty_q_f(st_p0, &*i_p7))),
        crate::check::types::Ty::TyArray(e_p8) => {
            let inner_p9 = show_ty_q_f(st_p0, &*e_p8);
            if crate::syntax::lexer::chars::has_prefix_f(&inner_p9, &Text::lit("[")) {
                Text::from(format!("[ {} ]", &inner_p9))
            } else {
                Text::from(format!("[{}]", &inner_p9))
            }
        },
        crate::check::types::Ty::TyMap(k_pa, v_pb) => Text::from(format!("({} ==> {})", &show_ty_q_f(st_p0, &*k_pa), &show_ty_q_f(st_p0, &*v_pb))),
        crate::check::types::Ty::TyAt(i_pc, rw_pd) => Text::from(format!("@{} emit {}", &show_ty_q_f(st_p0, &*i_pc), &crate::check::types::show_row_in_f(&rw_pd, &true))),
        other_pe => crate::check::types::show_ty_f(st_p0, &other_pe),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ShowTyQ`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowTyQ: unbounded fn St, Ty -> Text
/// ```
pub struct ShowTyQ {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<Text> for ShowTyQ {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p0x.clone(), t_p1x.clone()), move |zonk_f_1493: crate::check::types::Ty| match zonk_f_1493 {
            crate::check::types::Ty::TyCon(n_p2, m1487_0_1) if ((&m1487_0_1).len() == 0) => prism_rtl::Turn::Finished(n_p2.clone()),
            crate::check::types::Ty::TyCon(n_p3, args_p4) => crate::prelude::call_value(crate::prelude::each_job(args_p4.clone(), {
                let st_p0xx = st_p0x.clone();
                Rc::new(move |p0: crate::check::types::Ty| {
                    let st_p0xxy = st_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_p5 = p0;
                        crate::prelude::call_then(start_show_ty_q_f(st_p0xxy.clone(), a_p5.clone()), move |show_ty_q_f_1578: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &show_ty_q_f_1578))))
                    }))
                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_1559: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("({}{})", &n_p3, &crate::prelude::concat(&each_1559))))),
            crate::check::types::Ty::TySig(s_p6, i_p7) => crate::prelude::call_then(start_show_ty_q_f(st_p0x.clone(), (*i_p7).clone()), move |show_ty_q_f_1619: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &s_p6, &show_ty_q_f_1619)))),
            crate::check::types::Ty::TyArray(e_p8) => crate::prelude::call_then(start_show_ty_q_f(st_p0x.clone(), (*e_p8).clone()), move |show_ty_q_f_1670: Text| {
                let inner_p9 = show_ty_q_f_1670;
                if crate::syntax::lexer::chars::has_prefix_f(&inner_p9, &Text::lit("[")) {
                    prism_rtl::Turn::Finished(Text::from(format!("[ {} ]", &inner_p9)))
                } else {
                    prism_rtl::Turn::Finished(Text::from(format!("[{}]", &inner_p9)))
                }
            }),
            crate::check::types::Ty::TyMap(k_pa, v_pb) => crate::prelude::call_then(start_show_ty_q_f(st_p0x.clone(), (*k_pa).clone()), move |show_ty_q_f_1770: Text| crate::prelude::call_then(start_show_ty_q_f(st_p0x.clone(), (*v_pb).clone()), move |show_ty_q_f_1790: Text| prism_rtl::Turn::Finished(Text::from(format!("({} ==> {})", &show_ty_q_f_1770, &show_ty_q_f_1790))))),
            crate::check::types::Ty::TyAt(i_pc, rw_pd) => crate::prelude::call_then(start_show_ty_q_f(st_p0x.clone(), (*i_pc).clone()), move |show_ty_q_f_1826: Text| prism_rtl::Turn::Finished(Text::from(format!("@{} emit {}", &show_ty_q_f_1826, &crate::check::types::show_row_in_f(&rw_pd, &true))))),
            other_pe => prism_rtl::Turn::More(Rc::new(crate::check::types::ShowTy { st_p0: st_p0x.clone(), t_p1: other_pe.clone() })),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start ShowTyQ, x`: what the function value is when passed to `@Run`.
pub fn start_show_ty_q_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ShowTyQ { st_p0, t_p1 })
}

/// ```prism
/// TryUnify: unbounded fn St, Ty, Ty, Range -> ((Bool, St))
/// ```
pub fn try_unify_f(st_p0: &crate::check::types::St, expected_p1: &crate::check::types::Ty, found_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> (bool, crate::check::types::St) {
    let (verdict_p4, st2_p5) = unify_in_f(st_p0, expected_p1, found_p2, span_p3);
    (&verdict_p4 == &Text::lit(""), st2_p5.clone())
}

/// The step machine of `TryUnify`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TryUnify: unbounded fn St, Ty, Ty, Range -> ((Bool, St))
/// ```
pub struct TryUnify {
    pub st_p0: crate::check::types::St,
    pub expected_p1: crate::check::types::Ty,
    pub found_p2: crate::check::types::Ty,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(bool, crate::check::types::St)> for TryUnify {
    fn cycle(&self) -> prism_rtl::Turn<(bool, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let expected_p1 = &self.expected_p1;
        let found_p2 = &self.found_p2;
        let span_p3 = &self.span_p3;
        let expected_p1x = expected_p1.clone();
        let found_p2x = found_p2.clone();
        let span_p3x = span_p3.clone();
        let st_p0x = st_p0.clone();
        crate::prelude::call_then(start_unify_in_f(st_p0x.clone(), expected_p1x.clone(), found_p2x.clone(), span_p3x.clone()), move |unify_in_f_2156: (Text, crate::check::types::St)| {
            let (verdict_p4, st2_p5) = unify_in_f_2156;
            prism_rtl::Turn::Finished((&verdict_p4 == &Text::lit(""), st2_p5.clone()))
        })
    }
}

/// `Start TryUnify, x`: what the function value is when passed to `@Run`.
pub fn start_try_unify_f(st_p0: crate::check::types::St, expected_p1: crate::check::types::Ty, found_p2: crate::check::types::Ty, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(bool, crate::check::types::St)>> {
    Rc::new(TryUnify { st_p0, expected_p1, found_p2, span_p3 })
}

/// ```prism
/// UnifyIn: unbounded fn St, Ty, Ty, Range -> ((Text, St))
/// ```
pub fn unify_in_f(st_p0: &crate::check::types::St, expected_p1: &crate::check::types::Ty, found_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> (Text, crate::check::types::St) {
    let e_p4 = norm_assoc_f(st_p0, &crate::check::types::recording::walk_f(st_p0, expected_p1));
    let f_p5 = norm_assoc_f(st_p0, &crate::check::types::recording::walk_f(st_p0, found_p2));
    if is_waiting_assoc_f(st_p0, &e_p4) || is_waiting_assoc_f(st_p0, &f_p5) {
        if &e_p4 == &f_p5 {
            (Text::lit(""), st_p0.clone())
        } else {
            (Text::lit(""), defer_f(st_p0, &e_p4, &f_p5, span_p3))
        }
    } else {
        unify_heads_f(st_p0, &e_p4, &f_p5, span_p3)
    }
}

/// The step machine of `UnifyIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyIn: unbounded fn St, Ty, Ty, Range -> ((Text, St))
/// ```
pub struct UnifyIn {
    pub st_p0: crate::check::types::St,
    pub expected_p1: crate::check::types::Ty,
    pub found_p2: crate::check::types::Ty,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(Text, crate::check::types::St)> for UnifyIn {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let expected_p1 = &self.expected_p1;
        let found_p2 = &self.found_p2;
        let span_p3 = &self.span_p3;
        let expected_p1x = expected_p1.clone();
        let found_p2x = found_p2.clone();
        let span_p3x = span_p3.clone();
        let st_p0x = st_p0.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), expected_p1x.clone()), move |walk_f_2446: crate::check::types::Ty| crate::prelude::call_then(start_norm_assoc_f(st_p0x.clone(), walk_f_2446), move |norm_assoc_f_2431: crate::check::types::Ty| {
            let e_p4 = norm_assoc_f_2431;
            crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), found_p2x.clone()), move |walk_f_2492: crate::check::types::Ty| crate::prelude::call_then(start_norm_assoc_f(st_p0x.clone(), walk_f_2492), move |norm_assoc_f_2477: crate::check::types::Ty| {
                let f_p5 = norm_assoc_f_2477;
                crate::prelude::call_then(start_is_waiting_assoc_f(st_p0x.clone(), e_p4.clone()), move |is_waiting_assoc_f_2516: bool| if is_waiting_assoc_f_2516 || is_waiting_assoc_f(&st_p0x, &f_p5) {
                    if &e_p4 == &f_p5 {
                        prism_rtl::Turn::Finished((Text::lit(""), st_p0x.clone()))
                    } else {
                        prism_rtl::Turn::Finished((Text::lit(""), defer_f(&st_p0x, &e_p4, &f_p5, &span_p3x)))
                    }
                } else {
                    prism_rtl::Turn::More(Rc::new(UnifyHeads { st_p0: st_p0x.clone(), e_p1: e_p4.clone(), f_p2: f_p5.clone(), span_p3: span_p3x.clone() }))
                })
            }))
        }))
    }
}

/// `Start UnifyIn, x`: what the function value is when passed to `@Run`.
pub fn start_unify_in_f(st_p0: crate::check::types::St, expected_p1: crate::check::types::Ty, found_p2: crate::check::types::Ty, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>> {
    Rc::new(UnifyIn { st_p0, expected_p1, found_p2, span_p3 })
}

/// ```prism
/// NormAssoc: unbounded fn St, Ty -> Ty
/// ```
pub fn norm_assoc_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p1 {
        crate::check::types::Ty::TyAssoc(m2934_0_0, a_p2) if (m2934_0_0 == &Text::lit("Quotient")) => match crate::check::types::recording::walk_f(st_p0, &**a_p2) {
            crate::check::types::Ty::TyCon(m2970_0_0, m2970_0_1) if (&m2970_0_0 == &Text::lit("Float")) && ((&m2970_0_1).len() == 0) => crate::check::types::t_float_p(),
            crate::check::types::Ty::TyCon(n_p3, m2970_1_1) if ((&m2970_1_1).len() == 0) => if ((&n_p3 == &Text::lit("Nat")) || (&n_p3 == &Text::lit("Int"))) || (&n_p3 == &Text::lit("U8")) {
                crate::check::types::Ty::TySig(Text::lit("?"), Rc::new(crate::check::types::Ty::TyCon(n_p3.clone(), Array::new())))
            } else {
                t_p1.clone()
            },
            _ => t_p1.clone(),
            _ => unreachable!("no arm matched"),
        },
        other_p4 => other_p4.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `NormAssoc`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NormAssoc: unbounded fn St, Ty -> Ty
/// ```
pub struct NormAssoc {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::Ty> for NormAssoc {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        match t_p1 {
            crate::check::types::Ty::TyAssoc(m2934_0_0, a_p2) if (m2934_0_0 == &Text::lit("Quotient")) => {
                let a_p2x = (**a_p2).clone();
                let st_p0x = st_p0.clone();
                let t_p1x = t_p1.clone();
                crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), a_p2x.clone()), move |walk_f_2976: crate::check::types::Ty| match walk_f_2976 {
                    crate::check::types::Ty::TyCon(m2970_0_0, m2970_0_1) if (&m2970_0_0 == &Text::lit("Float")) && ((&m2970_0_1).len() == 0) => prism_rtl::Turn::Finished(crate::check::types::t_float_p()),
                    crate::check::types::Ty::TyCon(n_p3, m2970_1_1) if ((&m2970_1_1).len() == 0) => if ((&n_p3 == &Text::lit("Nat")) || (&n_p3 == &Text::lit("Int"))) || (&n_p3 == &Text::lit("U8")) {
                        prism_rtl::Turn::Finished(crate::check::types::Ty::TySig(Text::lit("?"), Rc::new(crate::check::types::Ty::TyCon(n_p3.clone(), Array::new()))))
                    } else {
                        prism_rtl::Turn::Finished(t_p1x.clone())
                    },
                    _ => prism_rtl::Turn::Finished(t_p1x.clone()),
                    _ => unreachable!("no arm matched"),
                })
            },
            other_p4 => prism_rtl::Turn::Finished(other_p4.clone()),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start NormAssoc, x`: what the function value is when passed to `@Run`.
pub fn start_norm_assoc_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(NormAssoc { st_p0, t_p1 })
}

/// ```prism
/// IsWaitingAssoc: unbounded fn St, Ty -> Bool
/// ```
pub fn is_waiting_assoc_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> bool {
    match t_p1 {
        crate::check::types::Ty::TyAssoc(_, a_p2) => crate::check::types::is_flex_var_f(st_p0, &**a_p2),
        _ => false,
    }
}

/// The step machine of `IsWaitingAssoc`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsWaitingAssoc: unbounded fn St, Ty -> Bool
/// ```
pub struct IsWaitingAssoc {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<bool> for IsWaitingAssoc {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        match t_p1 {
            crate::check::types::Ty::TyAssoc(_, a_p2) => prism_rtl::Turn::More(Rc::new(crate::check::types::IsFlexVar { st_p0: st_p0.clone(), t_p1: (**a_p2).clone() })),
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start IsWaitingAssoc, x`: what the function value is when passed to `@Run`.
pub fn start_is_waiting_assoc_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsWaitingAssoc { st_p0, t_p1 })
}

/// ```prism
/// Defer: fn St, Ty, Ty, Range -> St
/// ```
pub fn defer_f(st_p0: &crate::check::types::St, e_p1: &crate::check::types::Ty, f_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.deferred_p = crate::prelude::push(&this.deferred_p, &(e_p1.clone(), f_p2.clone(), span_p3.clone()));
    this
}

/// ```prism
/// RetryDeferred: unbounded fn St -> St
/// ```
pub fn retry_deferred_f(st_p0: &crate::check::types::St) -> crate::check::types::St {
    let waiting_p1 = st_p0.deferred_p.clone();
    let cleared_p2 = {
        let mut this: crate::check::types::St = st_p0.clone();
        this.deferred_p = Array::new();
        this
    };
    crate::prelude::run_to_end(crate::prelude::fold_job(waiting_p1.clone(), cleared_p2.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, (crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range))| crate::prelude::entered(crate::prelude::once_job(move || {
        let s_p3 = p0;
        let (e_p4, f_p5, span_p6) = p1;
        prism_rtl::Turn::More(Rc::new(Unify { st_p0: s_p3.clone(), expected_p1: e_p4.clone(), found_p2: f_p5.clone(), span_p3: span_p6.clone() }))
    }))) as Rc<dyn Fn((crate::check::types::St, (crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range))) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>))
}

/// The step machine of `RetryDeferred`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RetryDeferred: unbounded fn St -> St
/// ```
pub struct RetryDeferred {
    pub st_p0: crate::check::types::St,
}

impl prism_rtl::Job<crate::check::types::St> for RetryDeferred {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let waiting_p1 = st_p0.deferred_p.clone();
        let cleared_p2 = {
            let mut this: crate::check::types::St = st_p0.clone();
            this.deferred_p = Array::new();
            this
        };
        crate::prelude::fold_job(waiting_p1.clone(), cleared_p2.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, (crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range))| crate::prelude::entered(crate::prelude::once_job(move || {
            let s_p3 = p0;
            let (e_p4, f_p5, span_p6) = p1;
            prism_rtl::Turn::More(Rc::new(Unify { st_p0: s_p3.clone(), expected_p1: e_p4.clone(), found_p2: f_p5.clone(), span_p3: span_p6.clone() }))
        }))) as Rc<dyn Fn((crate::check::types::St, (crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range))) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>).cycle()
    }
}

/// `Start RetryDeferred, x`: what the function value is when passed to `@Run`.
pub fn start_retry_deferred_f(st_p0: crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(RetryDeferred { st_p0 })
}

/// ```prism
/// UnifyHeads: unbounded fn St, Ty, Ty, Range -> ((Text, St))
/// ```
pub fn unify_heads_f(st_p0: &crate::check::types::St, e_p1: &crate::check::types::Ty, f_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> (Text, crate::check::types::St) {
    match (e_p1.clone(), f_p2.clone()) {
        (crate::check::types::Ty::TyErr, _) => (Text::lit(""), st_p0.clone()),
        (_, crate::check::types::Ty::TyErr) => (Text::lit(""), st_p0.clone()),
        (crate::check::types::Ty::TySig(m3799_2_0_0, _), crate::check::types::Ty::TyCon(m3799_2_1_0, m3799_2_1_1)) if (&m3799_2_0_0 == &Text::lit("~")) && (&m3799_2_1_0 == &Text::lit("Prelude.Error")) && ((&m3799_2_1_1).len() == 0) => (Text::lit(""), st_p0.clone()),
        (crate::check::types::Ty::TyCon(m3799_3_0_0, m3799_3_0_1), crate::check::types::Ty::TySig(m3799_3_1_0, _)) if (&m3799_3_0_0 == &Text::lit("Prelude.Error")) && ((&m3799_3_0_1).len() == 0) && (&m3799_3_1_0 == &Text::lit("~")) => (Text::lit(""), st_p0.clone()),
        (crate::check::types::Ty::TyFlex(a_p4), crate::check::types::Ty::TyFlex(b_p5)) => if &a_p4 == &b_p5 {
            (Text::lit(""), st_p0.clone())
        } else {
            (Text::lit(""), merge_vars_f(st_p0, &a_p4, &b_p5))
        },
        (crate::check::types::Ty::TyFlex(a_p6), t_p7) => bind_var_f(st_p0, &a_p6, &t_p7, span_p3),
        (t_p8, crate::check::types::Ty::TyFlex(b_p9)) => bind_var_f(st_p0, &b_p9, &t_p8, span_p3),
        (crate::check::types::Ty::TyRigid(a_pa), crate::check::types::Ty::TyRigid(b_pb)) => if &a_pa == &b_pb {
            (Text::lit(""), st_p0.clone())
        } else {
            (Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Ty::TyQ(a_pc), crate::check::types::Ty::TyQ(b_pd)) => if &a_pc == &b_pd {
            (Text::lit(""), st_p0.clone())
        } else {
            (Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Ty::TyCon(a_pe, xs_pf), crate::check::types::Ty::TyCon(b_pg, ys_ph)) => if (&a_pe == &b_pg) && (&crate::prelude::len(&xs_pf) == &crate::prelude::len(&ys_ph)) {
            unify_all_f(st_p0, &xs_pf, &ys_ph, span_p3)
        } else {
            (Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Ty::TyFn(c1_pi, ps_pj, r1_pk), crate::check::types::Ty::TyFn(c2_pl, qs_pm, r2_pn)) => if &crate::prelude::len(&ps_pj) == &crate::prelude::len(&qs_pm) {
            {
                let (v_po, st2_pp) = crate::check::types::colors::unify_col_f(st_p0, &c1_pi, &c2_pl);
                if &v_po != &Text::lit("") {
                    (v_po.clone(), st2_pp.clone())
                } else {
                    unify_all_f(&st2_pp, &crate::prelude::push(&ps_pj, &*r1_pk), &crate::prelude::push(&qs_pm, &*r2_pn), span_p3)
                }
            }
        } else {
            (Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Ty::TyTuple(xs_pq), crate::check::types::Ty::TyTuple(ys_pr)) => if &crate::prelude::len(&xs_pq) == &crate::prelude::len(&ys_pr) {
            unify_all_f(st_p0, &xs_pq, &ys_pr, span_p3)
        } else {
            (Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Ty::TyArray(x_ps), crate::check::types::Ty::TyArray(y_pt)) => unify_in_f(st_p0, &*x_ps, &*y_pt, span_p3),
        (crate::check::types::Ty::TyMap(k1_pu, v1_pv), crate::check::types::Ty::TyMap(k2_p10, v2_p11)) => unify_all_f(st_p0, &Array::from(vec![(*k1_pu).clone(), (*v1_pv).clone()]), &Array::from(vec![(*k2_p10).clone(), (*v2_p11).clone()]), span_p3),
        (crate::check::types::Ty::TySig(s1_p12, i1_p13), crate::check::types::Ty::TySig(s2_p14, i2_p15)) => if &s1_p12 == &s2_p14 {
            unify_in_f(st_p0, &*i1_p13, &*i2_p15, span_p3)
        } else {
            (Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Ty::TyAt(i1_p16, r1_p17), crate::check::types::Ty::TyAt(i2_p18, r2_p19)) => {
            let (v_p1a, st2_p1b) = unify_in_f(st_p0, &*i1_p16, &*i2_p18, span_p3);
            if &v_p1a != &Text::lit("") {
                (v_p1a.clone(), st2_p1b.clone())
            } else {
                unify_row_f(&st2_p1b, &r1_p17, &r2_p19, span_p3)
            }
        },
        (crate::check::types::Ty::TyElem(r1_p1c, o1_p1d), crate::check::types::Ty::TyElem(r2_p1e, o2_p1f)) => {
            let (v_p1g, st2_p1h) = unify_row_f(st_p0, &r1_p1c, &r2_p1e, span_p3);
            if &v_p1g != &Text::lit("") {
                (v_p1g.clone(), st2_p1h.clone())
            } else {
                unify_in_f(&st2_p1h, &*o1_p1d, &*o2_p1f, span_p3)
            }
        },
        (crate::check::types::Ty::TyElemAny(r1_p1i), crate::check::types::Ty::TyElemAny(r2_p1j)) => unify_row_f(st_p0, &r1_p1i, &r2_p1j, span_p3),
        (crate::check::types::Ty::TyAssoc(n1_p1k, a1_p1l), crate::check::types::Ty::TyAssoc(n2_p1m, a2_p1n)) => if &n1_p1k == &n2_p1m {
            unify_in_f(st_p0, &*a1_p1l, &*a2_p1n, span_p3)
        } else {
            (Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Ty::TyAny(xs_p1o), crate::check::types::Ty::TyAny(ys_p1p)) => if &crate::check::types::sort_texts_f(&xs_p1o) == &crate::check::types::sort_texts_f(&ys_p1p) {
            (Text::lit(""), st_p0.clone())
        } else {
            (Text::lit("mismatch"), st_p0.clone())
        },
        _ => (Text::lit("mismatch"), st_p0.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `UnifyHeads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyHeads: unbounded fn St, Ty, Ty, Range -> ((Text, St))
/// ```
pub struct UnifyHeads {
    pub st_p0: crate::check::types::St,
    pub e_p1: crate::check::types::Ty,
    pub f_p2: crate::check::types::Ty,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(Text, crate::check::types::St)> for UnifyHeads {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let e_p1 = &self.e_p1;
        let f_p2 = &self.f_p2;
        let span_p3 = &self.span_p3;
        match (e_p1.clone(), f_p2.clone()) {
            (crate::check::types::Ty::TyErr, _) => prism_rtl::Turn::Finished((Text::lit(""), st_p0.clone())),
            (_, crate::check::types::Ty::TyErr) => prism_rtl::Turn::Finished((Text::lit(""), st_p0.clone())),
            (crate::check::types::Ty::TySig(m3799_2_0_0, _), crate::check::types::Ty::TyCon(m3799_2_1_0, m3799_2_1_1)) if (&m3799_2_0_0 == &Text::lit("~")) && (&m3799_2_1_0 == &Text::lit("Prelude.Error")) && ((&m3799_2_1_1).len() == 0) => prism_rtl::Turn::Finished((Text::lit(""), st_p0.clone())),
            (crate::check::types::Ty::TyCon(m3799_3_0_0, m3799_3_0_1), crate::check::types::Ty::TySig(m3799_3_1_0, _)) if (&m3799_3_0_0 == &Text::lit("Prelude.Error")) && ((&m3799_3_0_1).len() == 0) && (&m3799_3_1_0 == &Text::lit("~")) => prism_rtl::Turn::Finished((Text::lit(""), st_p0.clone())),
            (crate::check::types::Ty::TyFlex(a_p4), crate::check::types::Ty::TyFlex(b_p5)) => if &a_p4 == &b_p5 {
                prism_rtl::Turn::Finished((Text::lit(""), st_p0.clone()))
            } else {
                prism_rtl::Turn::Finished((Text::lit(""), merge_vars_f(st_p0, &a_p4, &b_p5)))
            },
            (crate::check::types::Ty::TyFlex(a_p6), t_p7) => prism_rtl::Turn::More(Rc::new(BindVar { st_p0: st_p0.clone(), n_p1: a_p6.clone(), t_p2: t_p7.clone(), span_p3: span_p3.clone() })),
            (t_p8, crate::check::types::Ty::TyFlex(b_p9)) => prism_rtl::Turn::More(Rc::new(BindVar { st_p0: st_p0.clone(), n_p1: b_p9.clone(), t_p2: t_p8.clone(), span_p3: span_p3.clone() })),
            (crate::check::types::Ty::TyRigid(a_pa), crate::check::types::Ty::TyRigid(b_pb)) => if &a_pa == &b_pb {
                prism_rtl::Turn::Finished((Text::lit(""), st_p0.clone()))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0.clone()))
            },
            (crate::check::types::Ty::TyQ(a_pc), crate::check::types::Ty::TyQ(b_pd)) => if &a_pc == &b_pd {
                prism_rtl::Turn::Finished((Text::lit(""), st_p0.clone()))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0.clone()))
            },
            (crate::check::types::Ty::TyCon(a_pe, xs_pf), crate::check::types::Ty::TyCon(b_pg, ys_ph)) => if (&a_pe == &b_pg) && (&crate::prelude::len(&xs_pf) == &crate::prelude::len(&ys_ph)) {
                prism_rtl::Turn::More(Rc::new(UnifyAll { st_p0: st_p0.clone(), xs_p1: xs_pf.clone(), ys_p2: ys_ph.clone(), span_p3: span_p3.clone() }))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0.clone()))
            },
            (crate::check::types::Ty::TyFn(c1_pi, ps_pj, r1_pk), crate::check::types::Ty::TyFn(c2_pl, qs_pm, r2_pn)) => if &crate::prelude::len(&ps_pj) == &crate::prelude::len(&qs_pm) {
                {
                    let span_p3x = span_p3.clone();
                    let st_p0x = st_p0.clone();
                    crate::prelude::call_then(crate::check::types::colors::start_unify_col_f(st_p0x.clone(), c1_pi.clone(), c2_pl.clone()), move |unify_col_f_4653: (Text, crate::check::types::St)| {
                        let (v_po, st2_pp) = unify_col_f_4653;
                        if &v_po != &Text::lit("") {
                            prism_rtl::Turn::Finished((v_po.clone(), st2_pp.clone()))
                        } else {
                            prism_rtl::Turn::More(Rc::new(UnifyAll { st_p0: st2_pp.clone(), xs_p1: crate::prelude::push(&ps_pj, &*r1_pk), ys_p2: crate::prelude::push(&qs_pm, &*r2_pn), span_p3: span_p3x.clone() }))
                        }
                    })
                }
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0.clone()))
            },
            (crate::check::types::Ty::TyTuple(xs_pq), crate::check::types::Ty::TyTuple(ys_pr)) => if &crate::prelude::len(&xs_pq) == &crate::prelude::len(&ys_pr) {
                prism_rtl::Turn::More(Rc::new(UnifyAll { st_p0: st_p0.clone(), xs_p1: xs_pq.clone(), ys_p2: ys_pr.clone(), span_p3: span_p3.clone() }))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0.clone()))
            },
            (crate::check::types::Ty::TyArray(x_ps), crate::check::types::Ty::TyArray(y_pt)) => prism_rtl::Turn::More(Rc::new(UnifyIn { st_p0: st_p0.clone(), expected_p1: (*x_ps).clone(), found_p2: (*y_pt).clone(), span_p3: span_p3.clone() })),
            (crate::check::types::Ty::TyMap(k1_pu, v1_pv), crate::check::types::Ty::TyMap(k2_p10, v2_p11)) => prism_rtl::Turn::More(Rc::new(UnifyAll { st_p0: st_p0.clone(), xs_p1: Array::from(vec![(*k1_pu).clone(), (*v1_pv).clone()]), ys_p2: Array::from(vec![(*k2_p10).clone(), (*v2_p11).clone()]), span_p3: span_p3.clone() })),
            (crate::check::types::Ty::TySig(s1_p12, i1_p13), crate::check::types::Ty::TySig(s2_p14, i2_p15)) => if &s1_p12 == &s2_p14 {
                prism_rtl::Turn::More(Rc::new(UnifyIn { st_p0: st_p0.clone(), expected_p1: (*i1_p13).clone(), found_p2: (*i2_p15).clone(), span_p3: span_p3.clone() }))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0.clone()))
            },
            (crate::check::types::Ty::TyAt(i1_p16, r1_p17), crate::check::types::Ty::TyAt(i2_p18, r2_p19)) => {
                let span_p3x = span_p3.clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_then(start_unify_in_f(st_p0x.clone(), (*i1_p16).clone(), (*i2_p18).clone(), span_p3x.clone()), move |unify_in_f_5237: (Text, crate::check::types::St)| {
                    let (v_p1a, st2_p1b) = unify_in_f_5237;
                    if &v_p1a != &Text::lit("") {
                        prism_rtl::Turn::Finished((v_p1a.clone(), st2_p1b.clone()))
                    } else {
                        prism_rtl::Turn::More(Rc::new(UnifyRow { st_p0: st2_p1b.clone(), a0_p1: r1_p17.clone(), b0_p2: r2_p19.clone(), span_p3: span_p3x.clone() }))
                    }
                })
            },
            (crate::check::types::Ty::TyElem(r1_p1c, o1_p1d), crate::check::types::Ty::TyElem(r2_p1e, o2_p1f)) => {
                let span_p3x = span_p3.clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_then(start_unify_row_f(st_p0x.clone(), r1_p1c.clone(), r2_p1e.clone(), span_p3x.clone()), move |unify_row_f_5405: (Text, crate::check::types::St)| {
                    let (v_p1g, st2_p1h) = unify_row_f_5405;
                    if &v_p1g != &Text::lit("") {
                        prism_rtl::Turn::Finished((v_p1g.clone(), st2_p1h.clone()))
                    } else {
                        prism_rtl::Turn::More(Rc::new(UnifyIn { st_p0: st2_p1h.clone(), expected_p1: (*o1_p1d).clone(), found_p2: (*o2_p1f).clone(), span_p3: span_p3x.clone() }))
                    }
                })
            },
            (crate::check::types::Ty::TyElemAny(r1_p1i), crate::check::types::Ty::TyElemAny(r2_p1j)) => prism_rtl::Turn::More(Rc::new(UnifyRow { st_p0: st_p0.clone(), a0_p1: r1_p1i.clone(), b0_p2: r2_p1j.clone(), span_p3: span_p3.clone() })),
            (crate::check::types::Ty::TyAssoc(n1_p1k, a1_p1l), crate::check::types::Ty::TyAssoc(n2_p1m, a2_p1n)) => if &n1_p1k == &n2_p1m {
                prism_rtl::Turn::More(Rc::new(UnifyIn { st_p0: st_p0.clone(), expected_p1: (*a1_p1l).clone(), found_p2: (*a2_p1n).clone(), span_p3: span_p3.clone() }))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0.clone()))
            },
            (crate::check::types::Ty::TyAny(xs_p1o), crate::check::types::Ty::TyAny(ys_p1p)) => if &crate::check::types::sort_texts_f(&xs_p1o) == &crate::check::types::sort_texts_f(&ys_p1p) {
                prism_rtl::Turn::Finished((Text::lit(""), st_p0.clone()))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0.clone()))
            },
            _ => prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0.clone())),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start UnifyHeads, x`: what the function value is when passed to `@Run`.
pub fn start_unify_heads_f(st_p0: crate::check::types::St, e_p1: crate::check::types::Ty, f_p2: crate::check::types::Ty, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>> {
    Rc::new(UnifyHeads { st_p0, e_p1, f_p2, span_p3 })
}

/// ```prism
/// UnifyAll: unbounded fn St, [Ty], [Ty], Range -> ((Text, St))
/// ```
pub fn unify_all_f(st_p0: &crate::check::types::St, xs_p1: &Array<crate::check::types::Ty>, ys_p2: &Array<crate::check::types::Ty>, span_p3: &crate::syntax::Range) -> (Text, crate::check::types::St) {
    crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(xs_p1)), (Text::lit(""), st_p0.clone()), {
        let xs_p1x = xs_p1.clone();
        let ys_p2x = ys_p2.clone();
        let span_p3x = span_p3.clone();
        Rc::new(move |(p0, p1): ((Text, crate::check::types::St), Nat)| {
            let xs_p1xy = xs_p1x.clone();
            let ys_p2xy = ys_p2x.clone();
            let span_p3xy = span_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (v_p4, s_p5) = p0;
                let i_p6 = p1;
                if &v_p4 != &Text::lit("") {
                    prism_rtl::Turn::Finished((v_p4.clone(), s_p5.clone()))
                } else {
                    prism_rtl::Turn::More(Rc::new(UnifyIn { st_p0: s_p5.clone(), expected_p1: crate::prelude::or(&crate::prelude::index(&xs_p1xy, &i_p6), &crate::check::types::Ty::TyErr), found_p2: crate::prelude::or(&crate::prelude::index(&ys_p2xy, &i_p6), &crate::check::types::Ty::TyErr), span_p3: span_p3xy.clone() }))
                }
            }))
        }) as Rc<dyn Fn(((Text, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>>>
    }))
}

/// The step machine of `UnifyAll`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyAll: unbounded fn St, [Ty], [Ty], Range -> ((Text, St))
/// ```
pub struct UnifyAll {
    pub st_p0: crate::check::types::St,
    pub xs_p1: Array<crate::check::types::Ty>,
    pub ys_p2: Array<crate::check::types::Ty>,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(Text, crate::check::types::St)> for UnifyAll {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let xs_p1 = &self.xs_p1;
        let ys_p2 = &self.ys_p2;
        let span_p3 = &self.span_p3;
        crate::prelude::fold_job(crate::check::errors::range0_f(&crate::prelude::len(xs_p1)), (Text::lit(""), st_p0.clone()), {
            let xs_p1x = xs_p1.clone();
            let ys_p2x = ys_p2.clone();
            let span_p3x = span_p3.clone();
            Rc::new(move |(p0, p1): ((Text, crate::check::types::St), Nat)| {
                let xs_p1xy = xs_p1x.clone();
                let ys_p2xy = ys_p2x.clone();
                let span_p3xy = span_p3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (v_p4, s_p5) = p0;
                    let i_p6 = p1;
                    if &v_p4 != &Text::lit("") {
                        prism_rtl::Turn::Finished((v_p4.clone(), s_p5.clone()))
                    } else {
                        prism_rtl::Turn::More(Rc::new(UnifyIn { st_p0: s_p5.clone(), expected_p1: crate::prelude::or(&crate::prelude::index(&xs_p1xy, &i_p6), &crate::check::types::Ty::TyErr), found_p2: crate::prelude::or(&crate::prelude::index(&ys_p2xy, &i_p6), &crate::check::types::Ty::TyErr), span_p3: span_p3xy.clone() }))
                    }
                }))
            }) as Rc<dyn Fn(((Text, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>>>
        }).cycle()
    }
}

/// `Start UnifyAll, x`: what the function value is when passed to `@Run`.
pub fn start_unify_all_f(st_p0: crate::check::types::St, xs_p1: Array<crate::check::types::Ty>, ys_p2: Array<crate::check::types::Ty>, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>> {
    Rc::new(UnifyAll { st_p0, xs_p1, ys_p2, span_p3 })
}

/// ```prism
/// MergeVars: fn St, Nat, Nat -> St
/// ```
pub fn merge_vars_f(st_p0: &crate::check::types::St, a_p1: &Nat, b_p2: &Nat) -> crate::check::types::St {
    let ia_p3 = crate::check::types::recording::info_of_f(st_p0, a_p1);
    let ib_p4 = crate::check::types::recording::info_of_f(st_p0, b_p2);
    let merged_p5 = crate::check::types::VInfo { plain_p: ia_p3.plain_p || ib_p4.plain_p, level_p: crate::prelude::min(&ia_p3.level_p, &ib_p4.level_p), name_p: if &ib_p4.name_p == &Text::lit("") {
        ia_p3.name_p.clone()
    } else {
        ib_p4.name_p.clone()
    } };
    let mut this: crate::check::types::St = st_p0.clone();
    this.tys_p = crate::prelude::insert(&this.tys_p, a_p1, &crate::check::types::Ty::TyFlex(b_p2.clone()));
    this.infos_p = crate::prelude::insert(&this.infos_p, b_p2, &merged_p5);
    this
}

/// ```prism
/// BindVar: unbounded fn St, Nat, Ty, Range -> ((Text, St))
/// ```
pub fn bind_var_f(st_p0: &crate::check::types::St, n_p1: &Nat, t_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> (Text, crate::check::types::St) {
    let info_p4 = crate::check::types::recording::info_of_f(st_p0, n_p1);
    let stack_p5 = crate::check::types::stack_of_f(st_p0, t_p2);
    if crate::check::types::has_nat_f(&crate::check::types::recording::free_vars_f(st_p0, t_p2), n_p1) {
        (Text::lit("reported"), crate::check::types::recording::err_f(st_p0, &Text::lit("occurs"), span_p3, &Text::from(format!("`t{}` would contain itself: `t{} = {}`", n_p1, n_p1, &crate::check::types::show_ty_f(st_p0, t_p2)))))
    } else {
        if info_p4.plain_p && (&stack_p5 != &Text::lit("")) {
            if &info_p4.name_p != &Text::lit("") {
                {
                    let marks_p6 = marks_of_f(&info_p4.name_p);
                    let whole_p7 = Text::from(format!("{}{}", &marks_p6, &crate::check::types::show_ty_in_f(st_p0, &crate::check::types::recording::zonk_f(st_p0, t_p2), &true)));
                    let at_p8 = crate::prelude::or(&crate::prelude::get(&st_p0.binder_at_p, n_p1), span_p3);
                    let st2_p9 = crate::check::types::recording::err_fix_f(st_p0, &Text::lit("mark-stack"), &at_p8, &Text::from(format!("`{}` has type `{}`, whose stack is `{}{}`; the name shows `{}`", &info_p4.name_p, &whole_p7, &marks_p6, &stack_p5, &marks_p6)), &Text::from(format!("rename to `{}{}{}`", &marks_p6, &stack_p5, &crate::syntax::lexer::chars::drop_prefix_f(&info_p4.name_p, &marks_p6))));
                    (Text::lit(""), {
                        let mut this: crate::check::types::St = lower_levels_f(&st2_p9, &crate::prelude::append(&crate::check::types::recording::free_vars_f(&st2_p9, t_p2), &crate::check::types::colors::free_col_vars_f(&st2_p9, t_p2)), &info_p4.level_p);
                        this.tys_p = crate::prelude::insert(&this.tys_p, n_p1, t_p2);
                        this
                    })
                }
            } else {
                (Text::lit("mismatch"), st_p0.clone())
            }
        } else {
            {
                let lowered_pa = lower_levels_f(st_p0, &crate::prelude::append(&crate::check::types::recording::free_vars_f(st_p0, t_p2), &crate::check::types::colors::free_col_vars_f(st_p0, t_p2)), &info_p4.level_p);
                (Text::lit(""), {
                    let mut this: crate::check::types::St = lowered_pa.clone();
                    this.tys_p = crate::prelude::insert(&this.tys_p, n_p1, t_p2);
                    this
                })
            }
        }
    }
}

/// The step machine of `BindVar`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindVar: unbounded fn St, Nat, Ty, Range -> ((Text, St))
/// ```
pub struct BindVar {
    pub st_p0: crate::check::types::St,
    pub n_p1: Nat,
    pub t_p2: crate::check::types::Ty,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(Text, crate::check::types::St)> for BindVar {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let n_p1 = &self.n_p1;
        let t_p2 = &self.t_p2;
        let span_p3 = &self.span_p3;
        let info_p4 = crate::check::types::recording::info_of_f(st_p0, n_p1);
        let n_p1x = n_p1.clone();
        let span_p3x = span_p3.clone();
        let st_p0x = st_p0.clone();
        let t_p2x = t_p2.clone();
        crate::prelude::call_then(crate::check::types::start_stack_of_f(st_p0x.clone(), t_p2x.clone()), move |stack_of_f_6651: Text| {
            let stack_p5 = stack_of_f_6651;
            crate::prelude::call_then(crate::check::types::recording::start_free_vars_f(st_p0x.clone(), t_p2x.clone()), move |free_vars_f_6680: Array<Nat>| if crate::check::types::has_nat_f(&free_vars_f_6680, &n_p1x) {
                crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p0x.clone(), t_p2x.clone()), move |show_ty_f_6786: Text| prism_rtl::Turn::Finished((Text::lit("reported"), crate::check::types::recording::err_f(&st_p0x, &Text::lit("occurs"), &span_p3x, &Text::from(format!("`t{}` would contain itself: `t{} = {}`", &n_p1x, &n_p1x, &show_ty_f_6786))))))
            } else {
                if info_p4.plain_p && (&stack_p5 != &Text::lit("")) {
                    if &info_p4.name_p != &Text::lit("") {
                        {
                            let marks_p6 = marks_of_f(&info_p4.name_p);
                            crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p0x.clone(), t_p2x.clone()), move |zonk_f_6963: crate::check::types::Ty| crate::prelude::call_then(crate::check::types::start_show_ty_in_f(st_p0x.clone(), zonk_f_6963, true), move |show_ty_in_f_6949: Text| {
                                let whole_p7 = Text::from(format!("{}{}", &marks_p6, &show_ty_in_f_6949));
                                let at_p8 = crate::prelude::or(&crate::prelude::get(&st_p0x.binder_at_p, &n_p1x), &span_p3x);
                                let st2_p9 = crate::check::types::recording::err_fix_f(&st_p0x, &Text::lit("mark-stack"), &at_p8, &Text::from(format!("`{}` has type `{}`, whose stack is `{}{}`; the name shows `{}`", &info_p4.name_p, &whole_p7, &marks_p6, &stack_p5, &marks_p6)), &Text::from(format!("rename to `{}{}{}`", &marks_p6, &stack_p5, &crate::syntax::lexer::chars::drop_prefix_f(&info_p4.name_p, &marks_p6))));
                                prism_rtl::Turn::Finished((Text::lit(""), {
                                    let mut this: crate::check::types::St = lower_levels_f(&st2_p9, &crate::prelude::append(&crate::check::types::recording::free_vars_f(&st2_p9, &t_p2x), &crate::check::types::colors::free_col_vars_f(&st2_p9, &t_p2x)), &info_p4.level_p);
                                    this.tys_p = crate::prelude::insert(&this.tys_p, &n_p1x, &t_p2x);
                                    this
                                }))
                            }))
                        }
                    } else {
                        prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0x.clone()))
                    }
                } else {
                    crate::prelude::call_then(crate::check::types::recording::start_free_vars_f(st_p0x.clone(), t_p2x.clone()), move |free_vars_f_7628: Array<Nat>| crate::prelude::call_then(crate::check::types::colors::start_free_col_vars_f(st_p0x.clone(), t_p2x.clone()), move |free_col_vars_f_7646: Array<Nat>| {
                        let lowered_pa = lower_levels_f(&st_p0x, &crate::prelude::append(&free_vars_f_7628, &free_col_vars_f_7646), &info_p4.level_p);
                        prism_rtl::Turn::Finished((Text::lit(""), {
                            let mut this: crate::check::types::St = lowered_pa.clone();
                            this.tys_p = crate::prelude::insert(&this.tys_p, &n_p1x, &t_p2x);
                            this
                        }))
                    }))
                }
            })
        })
    }
}

/// `Start BindVar, x`: what the function value is when passed to `@Run`.
pub fn start_bind_var_f(st_p0: crate::check::types::St, n_p1: Nat, t_p2: crate::check::types::Ty, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>> {
    Rc::new(BindVar { st_p0, n_p1, t_p2, span_p3 })
}

/// ```prism
/// MarksOf: fn Text -> Text
/// ```
pub fn marks_of_f(name_p0: &Text) -> Text {
    let c_p1 = {
        let mut this: Cursor = crate::prelude::front(name_p0);
        while let Some((_, next_p2)) = crate::prelude::step(&this) {
            if !is_mark_char_f(&crate::syntax::lexer::chars::char_at_f(&this)) {
                break;
            }
            this = next_p2.clone();
        }
        this
    };
    crate::prelude::before(&c_p1)
}

/// ```prism
/// IsMarkChar: fn Text -> Bool
/// ```
pub fn is_mark_char_f(c_p0: &Text) -> bool {
    (((((c_p0 == &Text::lit("$")) || (c_p0 == &Text::lit("!"))) || (c_p0 == &Text::lit("@"))) || (c_p0 == &Text::lit("?"))) || (c_p0 == &Text::lit("~"))) || (c_p0 == &Text::lit("&"))
}

/// ```prism
/// LowerLevels: fn St, [Nat], Nat -> St
/// ```
pub fn lower_levels_f(st_p0: &crate::check::types::St, vs_p1: &Array<Nat>, level_p2: &Nat) -> crate::check::types::St {
    crate::prelude::fold(vs_p1, st_p0, &(|s_p3: &crate::check::types::St, v_p4: &Nat| lower_one_f(s_p3, v_p4, level_p2)))
}

/// ```prism
/// LowerOne: fn St, Nat, Nat -> St
/// ```
pub fn lower_one_f(s_p0: &crate::check::types::St, v_p1: &Nat, level_p2: &Nat) -> crate::check::types::St {
    let i_p3 = crate::check::types::recording::info_of_f(s_p0, v_p1);
    if &i_p3.level_p <= level_p2 {
        s_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = s_p0.clone();
            this.infos_p = crate::prelude::insert(&this.infos_p, v_p1, &crate::check::types::VInfo { plain_p: i_p3.plain_p, level_p: level_p2.clone(), name_p: i_p3.name_p.clone() });
            this
        }
    }
}

/// ```prism
/// UnifyRow: unbounded fn St, Rw, Rw, Range -> ((Text, St))
/// ```
pub fn unify_row_f(st_p0: &crate::check::types::St, a0_p1: &crate::check::types::Rw, b0_p2: &crate::check::types::Rw, span_p3: &crate::syntax::Range) -> (Text, crate::check::types::St) {
    let a_p4 = crate::check::types::recording::walk_row_f(st_p0, a0_p1);
    let b_p5 = crate::check::types::recording::walk_row_f(st_p0, b0_p2);
    let only_a_p6 = crate::check::types::minus_texts_f(&a_p4.fams_p, &b_p5.fams_p);
    let only_b_p7 = crate::check::types::minus_texts_f(&b_p5.fams_p, &a_p4.fams_p);
    match (a_p4.tail_p.clone(), b_p5.tail_p.clone()) {
        (crate::check::types::Tail::TlClosed, crate::check::types::Tail::TlClosed) => if (&crate::prelude::len(&only_a_p6) == &Nat::from(0u32)) && (&crate::prelude::len(&only_b_p7) == &Nat::from(0u32)) {
            (Text::lit(""), st_p0.clone())
        } else {
            (Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Tail::TlFlex(x_p8), crate::check::types::Tail::TlFlex(y_p9)) => if &x_p8 == &y_p9 {
            if (&crate::prelude::len(&only_a_p6) == &Nat::from(0u32)) && (&crate::prelude::len(&only_b_p7) == &Nat::from(0u32)) {
                (Text::lit(""), st_p0.clone())
            } else {
                (Text::lit("mismatch"), st_p0.clone())
            }
        } else {
            {
                let lacking_pa = crate::check::types::union_texts_f(&crate::check::types::union_texts_f(&lacks_of_f(st_p0, &x_p8), &lacks_of_f(st_p0, &y_p9)), &crate::check::types::union_texts_f(&a_p4.fams_p, &b_p5.fams_p));
                let (fresh_pb, st2_pc) = crate::check::types::recording::fresh_row_f(st_p0, &lacking_pa);
                let (v1_pd, st3_pe) = bind_row_f(&st2_pc, &x_p8, &crate::check::types::Rw { fams_p: only_b_p7.clone(), minus_p: Array::new(), tail_p: fresh_pb.tail_p.clone() }, span_p3);
                if &v1_pd != &Text::lit("") {
                    (v1_pd.clone(), st3_pe.clone())
                } else {
                    bind_row_f(&st3_pe, &y_p9, &crate::check::types::Rw { fams_p: only_a_p6.clone(), minus_p: Array::new(), tail_p: fresh_pb.tail_p.clone() }, span_p3)
                }
            }
        },
        (crate::check::types::Tail::TlFlex(x_pf), other_pg) => if &crate::prelude::len(&only_a_p6) == &Nat::from(0u32) {
            bind_row_f(st_p0, &x_pf, &crate::check::types::Rw { fams_p: only_b_p7.clone(), minus_p: b_p5.minus_p.clone(), tail_p: other_pg }, span_p3)
        } else {
            (Text::lit("mismatch"), st_p0.clone())
        },
        (other_ph, crate::check::types::Tail::TlFlex(y_pi)) => if &crate::prelude::len(&only_b_p7) == &Nat::from(0u32) {
            bind_row_f(st_p0, &y_pi, &crate::check::types::Rw { fams_p: only_a_p6.clone(), minus_p: a_p4.minus_p.clone(), tail_p: other_ph }, span_p3)
        } else {
            (Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Tail::TlRigid(x_pj), crate::check::types::Tail::TlRigid(y_pk)) => if ((&x_pj == &y_pk) && (&crate::prelude::len(&only_a_p6) == &Nat::from(0u32))) && (&crate::prelude::len(&only_b_p7) == &Nat::from(0u32)) {
            (Text::lit(""), st_p0.clone())
        } else {
            (Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Tail::TlQ(x_pl), crate::check::types::Tail::TlQ(y_pm)) => if ((&x_pl == &y_pm) && (&crate::prelude::len(&only_a_p6) == &Nat::from(0u32))) && (&crate::prelude::len(&only_b_p7) == &Nat::from(0u32)) {
            (Text::lit(""), st_p0.clone())
        } else {
            (Text::lit("mismatch"), st_p0.clone())
        },
        _ => (Text::lit("mismatch"), st_p0.clone()),
    }
}

/// The step machine of `UnifyRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyRow: unbounded fn St, Rw, Rw, Range -> ((Text, St))
/// ```
pub struct UnifyRow {
    pub st_p0: crate::check::types::St,
    pub a0_p1: crate::check::types::Rw,
    pub b0_p2: crate::check::types::Rw,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(Text, crate::check::types::St)> for UnifyRow {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let a0_p1 = &self.a0_p1;
        let b0_p2 = &self.b0_p2;
        let span_p3 = &self.span_p3;
        let a0_p1x = a0_p1.clone();
        let b0_p2x = b0_p2.clone();
        let span_p3x = span_p3.clone();
        let st_p0x = st_p0.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p0x.clone(), a0_p1x.clone()), move |walk_row_f_8688: crate::check::types::Rw| {
            let a_p4 = walk_row_f_8688;
            crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p0x.clone(), b0_p2x.clone()), move |walk_row_f_8715: crate::check::types::Rw| {
                let b_p5 = walk_row_f_8715;
                let only_a_p6 = crate::check::types::minus_texts_f(&a_p4.fams_p, &b_p5.fams_p);
                let only_b_p7 = crate::check::types::minus_texts_f(&b_p5.fams_p, &a_p4.fams_p);
                match (a_p4.tail_p.clone(), b_p5.tail_p.clone()) {
                    (crate::check::types::Tail::TlClosed, crate::check::types::Tail::TlClosed) => if (&crate::prelude::len(&only_a_p6) == &Nat::from(0u32)) && (&crate::prelude::len(&only_b_p7) == &Nat::from(0u32)) {
                        prism_rtl::Turn::Finished((Text::lit(""), st_p0x.clone()))
                    } else {
                        prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0x.clone()))
                    },
                    (crate::check::types::Tail::TlFlex(x_p8), crate::check::types::Tail::TlFlex(y_p9)) => if &x_p8 == &y_p9 {
                        if (&crate::prelude::len(&only_a_p6) == &Nat::from(0u32)) && (&crate::prelude::len(&only_b_p7) == &Nat::from(0u32)) {
                            prism_rtl::Turn::Finished((Text::lit(""), st_p0x.clone()))
                        } else {
                            prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0x.clone()))
                        }
                    } else {
                        {
                            let lacking_pa = crate::check::types::union_texts_f(&crate::check::types::union_texts_f(&lacks_of_f(&st_p0x, &x_p8), &lacks_of_f(&st_p0x, &y_p9)), &crate::check::types::union_texts_f(&a_p4.fams_p, &b_p5.fams_p));
                            let (fresh_pb, st2_pc) = crate::check::types::recording::fresh_row_f(&st_p0x, &lacking_pa);
                            crate::prelude::call_then(start_bind_row_f(st2_pc.clone(), x_p8.clone(), crate::check::types::Rw { fams_p: only_b_p7.clone(), minus_p: Array::new(), tail_p: fresh_pb.tail_p.clone() }, span_p3x.clone()), move |bind_row_f_9329: (Text, crate::check::types::St)| {
                                let (v1_pd, st3_pe) = bind_row_f_9329;
                                if &v1_pd != &Text::lit("") {
                                    prism_rtl::Turn::Finished((v1_pd.clone(), st3_pe.clone()))
                                } else {
                                    prism_rtl::Turn::More(Rc::new(BindRow { st_p0: st3_pe.clone(), n_p1: y_p9.clone(), rw_p2: crate::check::types::Rw { fams_p: only_a_p6.clone(), minus_p: Array::new(), tail_p: fresh_pb.tail_p.clone() }, span_p3: span_p3x.clone() }))
                                }
                            })
                        }
                    },
                    (crate::check::types::Tail::TlFlex(x_pf), other_pg) => if &crate::prelude::len(&only_a_p6) == &Nat::from(0u32) {
                        prism_rtl::Turn::More(Rc::new(BindRow { st_p0: st_p0x.clone(), n_p1: x_pf.clone(), rw_p2: crate::check::types::Rw { fams_p: only_b_p7.clone(), minus_p: b_p5.minus_p.clone(), tail_p: other_pg.clone() }, span_p3: span_p3x.clone() }))
                    } else {
                        prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0x.clone()))
                    },
                    (other_ph, crate::check::types::Tail::TlFlex(y_pi)) => if &crate::prelude::len(&only_b_p7) == &Nat::from(0u32) {
                        prism_rtl::Turn::More(Rc::new(BindRow { st_p0: st_p0x.clone(), n_p1: y_pi.clone(), rw_p2: crate::check::types::Rw { fams_p: only_a_p6.clone(), minus_p: a_p4.minus_p.clone(), tail_p: other_ph.clone() }, span_p3: span_p3x.clone() }))
                    } else {
                        prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0x.clone()))
                    },
                    (crate::check::types::Tail::TlRigid(x_pj), crate::check::types::Tail::TlRigid(y_pk)) => if ((&x_pj == &y_pk) && (&crate::prelude::len(&only_a_p6) == &Nat::from(0u32))) && (&crate::prelude::len(&only_b_p7) == &Nat::from(0u32)) {
                        prism_rtl::Turn::Finished((Text::lit(""), st_p0x.clone()))
                    } else {
                        prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0x.clone()))
                    },
                    (crate::check::types::Tail::TlQ(x_pl), crate::check::types::Tail::TlQ(y_pm)) => if ((&x_pl == &y_pm) && (&crate::prelude::len(&only_a_p6) == &Nat::from(0u32))) && (&crate::prelude::len(&only_b_p7) == &Nat::from(0u32)) {
                        prism_rtl::Turn::Finished((Text::lit(""), st_p0x.clone()))
                    } else {
                        prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0x.clone()))
                    },
                    _ => prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0x.clone())),
                }
            })
        })
    }
}

/// `Start UnifyRow, x`: what the function value is when passed to `@Run`.
pub fn start_unify_row_f(st_p0: crate::check::types::St, a0_p1: crate::check::types::Rw, b0_p2: crate::check::types::Rw, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>> {
    Rc::new(UnifyRow { st_p0, a0_p1, b0_p2, span_p3 })
}

/// ```prism
/// AskField: fn St, Ty, Text, Ty, Range, [Text] -> St
/// ```
pub fn ask_field_f(st_p0: &crate::check::types::St, recv_p1: &crate::check::types::Ty, field_p2: &Text, result_p3: &crate::check::types::Ty, span_p4: &crate::syntax::Range, owners_p5: &Array<Text>) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.field_qs_p = crate::prelude::push(&this.field_qs_p, &FieldQ { recv_p: recv_p1.clone(), field_p: field_p2.clone(), result_p: result_p3.clone(), span_p: span_p4.clone(), file_p: this.file_p.clone(), owners_p: owners_p5.clone(), marks_o: None });
    this
}

/// ```prism
/// MarkLastField: fn St, Ty, Text, Range -> St
/// ```
pub fn mark_last_field_f(st_p0: &crate::check::types::St, result_p1: &crate::check::types::Ty, marks_p2: &Text, at_p3: &crate::syntax::Range) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.field_qs_p = crate::prelude::each(&this.field_qs_p, &(|q_p4: &FieldQ| if (&q_p4.result_p == result_p1) && (&q_p4.marks_o == &None) {
        {
            let mut this: FieldQ = q_p4.clone();
            this.marks_o = Some((marks_p2.clone(), at_p3.clone()));
            this
        }
    } else {
        q_p4.clone()
    }));
    this
}

/// ```prism
/// AskLayer: fn St, Ty, Range, Text -> St
/// ```
pub fn ask_layer_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty, span_p2: &crate::syntax::Range, fname_p3: &Text) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.layer_qs_p = crate::prelude::push(&this.layer_qs_p, &(t_p1.clone(), span_p2.clone(), fname_p3.clone()));
    this
}

/// ```prism
/// LayerQuestions: unbounded fn St -> St
/// ```
pub fn layer_questions_f(st_p0: &crate::check::types::St) -> crate::check::types::St {
    let qs_p1 = st_p0.layer_qs_p.clone();
    let cleared_p2 = {
        let mut this: crate::check::types::St = st_p0.clone();
        this.layer_qs_p = Array::new();
        this
    };
    crate::prelude::run_to_end(crate::prelude::fold_job(qs_p1.clone(), cleared_p2.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, (crate::check::types::Ty, crate::syntax::Range, Text))| crate::prelude::entered(crate::prelude::once_job(move || {
        let s_p3 = p0;
        let (t_p4, span_p5, fname_p6) = p1;
        crate::prelude::call_then(crate::check::types::start_head_sigil_f(s_p3.clone(), t_p4.clone()), move |head_sigil_f_11857: Text| {
            let h_p7 = head_sigil_f_11857;
            crate::prelude::call_then(crate::check::types::start_is_free_headed_f(s_p3.clone(), t_p4.clone()), move |is_free_headed_f_11884: bool| if (is_free_headed_f_11884 || (&h_p7 == &Text::lit("$"))) || (&h_p7 == &Text::lit("!")) {
                prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&s_p3, &Text::lit("layer-unknown"), &span_p5, &Text::from(format!("the layer of this argument to `{}` is not known here", &fname_p6)), &Text::lit("say it where the value is made: a name whose marks declare the layer (`let $x = ...`), `<<T>>` at the application that made it, or a signature on the enclosing `let`")))
            } else {
                prism_rtl::Turn::Finished(s_p3.clone())
            })
        })
    }))) as Rc<dyn Fn((crate::check::types::St, (crate::check::types::Ty, crate::syntax::Range, Text))) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>))
}

/// The step machine of `LayerQuestions`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LayerQuestions: unbounded fn St -> St
/// ```
pub struct LayerQuestions {
    pub st_p0: crate::check::types::St,
}

impl prism_rtl::Job<crate::check::types::St> for LayerQuestions {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let qs_p1 = st_p0.layer_qs_p.clone();
        let cleared_p2 = {
            let mut this: crate::check::types::St = st_p0.clone();
            this.layer_qs_p = Array::new();
            this
        };
        crate::prelude::fold_job(qs_p1.clone(), cleared_p2.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, (crate::check::types::Ty, crate::syntax::Range, Text))| crate::prelude::entered(crate::prelude::once_job(move || {
            let s_p3 = p0;
            let (t_p4, span_p5, fname_p6) = p1;
            crate::prelude::call_then(crate::check::types::start_head_sigil_f(s_p3.clone(), t_p4.clone()), move |head_sigil_f_11857: Text| {
                let h_p7 = head_sigil_f_11857;
                crate::prelude::call_then(crate::check::types::start_is_free_headed_f(s_p3.clone(), t_p4.clone()), move |is_free_headed_f_11884: bool| if (is_free_headed_f_11884 || (&h_p7 == &Text::lit("$"))) || (&h_p7 == &Text::lit("!")) {
                    prism_rtl::Turn::Finished(crate::check::types::recording::err_fix_f(&s_p3, &Text::lit("layer-unknown"), &span_p5, &Text::from(format!("the layer of this argument to `{}` is not known here", &fname_p6)), &Text::lit("say it where the value is made: a name whose marks declare the layer (`let $x = ...`), `<<T>>` at the application that made it, or a signature on the enclosing `let`")))
                } else {
                    prism_rtl::Turn::Finished(s_p3.clone())
                })
            })
        }))) as Rc<dyn Fn((crate::check::types::St, (crate::check::types::Ty, crate::syntax::Range, Text))) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>).cycle()
    }
}

/// `Start LayerQuestions, x`: what the function value is when passed to `@Run`.
pub fn start_layer_questions_f(st_p0: crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(LayerQuestions { st_p0 })
}

/// ```prism
/// NameRow: fn St, Tail, Text -> St
/// ```
pub fn name_row_f(st_p0: &crate::check::types::St, tail1: &crate::check::types::Tail, text2: &Text) -> crate::check::types::St {
    match (tail1, text2) {
        (crate::check::types::Tail::TlFlex(n_p1), q_p2) => {
            let mut this: crate::check::types::St = st_p0.clone();
            this.row_names_p = crate::prelude::insert(&this.row_names_p, n_p1, q_p2);
            this
        },
        (_, _) => st_p0.clone(),
    }
}

/// ```prism
/// RowName: fn St, Nat -> Text
/// ```
pub fn row_name_f(st_p0: &crate::check::types::St, n_p1: &Nat) -> Text {
    crate::prelude::or(&crate::prelude::get(&st_p0.row_names_p, n_p1), &Text::from(format!("r{}", n_p1)))
}

/// ```prism
/// LacksOf: fn St, Nat -> [Text]
/// ```
pub fn lacks_of_f(st_p0: &crate::check::types::St, n_p1: &Nat) -> Array<Text> {
    crate::prelude::or(&crate::prelude::get(&st_p0.lacks_p, n_p1), &Array::new())
}

/// ```prism
/// BindRow: unbounded fn St, Nat, Rw, Range -> ((Text, St))
/// ```
pub fn bind_row_f(st_p0: &crate::check::types::St, n_p1: &Nat, rw_p2: &crate::check::types::Rw, span_p3: &crate::syntax::Range) -> (Text, crate::check::types::St) {
    let bad_p4 = crate::check::types::inter_texts_f(&lacks_of_f(st_p0, n_p1), &rw_p2.fams_p);
    if &crate::prelude::len(&bad_p4) > &Nat::from(0u32) {
        {
            let fam_p5 = crate::prelude::or(&crate::prelude::index(&bad_p4, &Nat::from(0u32)), &Text::lit(""));
            (Text::lit("reported"), crate::check::types::recording::err_fix_f(st_p0, &Text::lit("row-lacks"), span_p3, &Text::from(format!("`{} | {}.*` promises `{}` has no `{}` tags", &row_name_f(st_p0, n_p1), &fam_p5, &row_name_f(st_p0, n_p1), &fam_p5)), &Text::from(format!("answer the `{}` tags before this point, or widen the row", &fam_p5))))
        }
    } else {
        {
            let st2_p6 = match &rw_p2.tail_p {
                crate::check::types::Tail::TlFlex(m_p7) => {
                    let mut this: crate::check::types::St = st_p0.clone();
                    this.lacks_p = crate::prelude::insert(&this.lacks_p, m_p7, &crate::check::types::union_texts_f(&lacks_of_f(st_p0, m_p7), &lacks_of_f(st_p0, n_p1)));
                    this
                },
                _ => st_p0.clone(),
            };
            (Text::lit(""), {
                let mut this: crate::check::types::St = st2_p6.clone();
                this.rows_p = crate::prelude::insert(&this.rows_p, n_p1, rw_p2);
                this
            })
        }
    }
}

/// The step machine of `BindRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindRow: unbounded fn St, Nat, Rw, Range -> ((Text, St))
/// ```
pub struct BindRow {
    pub st_p0: crate::check::types::St,
    pub n_p1: Nat,
    pub rw_p2: crate::check::types::Rw,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(Text, crate::check::types::St)> for BindRow {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let n_p1 = &self.n_p1;
        let rw_p2 = &self.rw_p2;
        let span_p3 = &self.span_p3;
        let bad_p4 = crate::check::types::inter_texts_f(&lacks_of_f(st_p0, n_p1), &rw_p2.fams_p);
        if &crate::prelude::len(&bad_p4) > &Nat::from(0u32) {
            {
                let fam_p5 = crate::prelude::or(&crate::prelude::index(&bad_p4, &Nat::from(0u32)), &Text::lit(""));
                prism_rtl::Turn::Finished((Text::lit("reported"), crate::check::types::recording::err_fix_f(st_p0, &Text::lit("row-lacks"), span_p3, &Text::from(format!("`{} | {}.*` promises `{}` has no `{}` tags", &row_name_f(st_p0, n_p1), &fam_p5, &row_name_f(st_p0, n_p1), &fam_p5)), &Text::from(format!("answer the `{}` tags before this point, or widen the row", &fam_p5)))))
            }
        } else {
            {
                let st2_p6 = match &rw_p2.tail_p {
                    crate::check::types::Tail::TlFlex(m_p7) => {
                        let mut this: crate::check::types::St = st_p0.clone();
                        this.lacks_p = crate::prelude::insert(&this.lacks_p, m_p7, &crate::check::types::union_texts_f(&lacks_of_f(st_p0, m_p7), &lacks_of_f(st_p0, n_p1)));
                        this
                    },
                    _ => st_p0.clone(),
                };
                prism_rtl::Turn::Finished((Text::lit(""), {
                    let mut this: crate::check::types::St = st2_p6.clone();
                    this.rows_p = crate::prelude::insert(&this.rows_p, n_p1, rw_p2);
                    this
                }))
            }
        }
    }
}

/// `Start BindRow, x`: what the function value is when passed to `@Run`.
pub fn start_bind_row_f(st_p0: crate::check::types::St, n_p1: Nat, rw_p2: crate::check::types::Rw, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>> {
    Rc::new(BindRow { st_p0, n_p1, rw_p2, span_p3 })
}
