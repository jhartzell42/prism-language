//! The module `Check.Types.Unify`, from `target/bootstrap/src/prismc/check/types/unify.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `FieldQ`:
///
/// ```prism
/// type FieldQ = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct FieldQ {
    pub recv: crate::check::types::Ty,
    pub field: Text,
    pub result: crate::check::types::Ty,
    pub span: crate::syntax::Range,
    pub file: Nat,
    pub owners: Array<Text>,
}

impl Show for FieldQ {
    fn show(&self, p: &mut Printer) {
        p.record("FieldQ", &[("recv", &self.recv), ("field", &self.field), ("result", &self.result), ("span", &self.span), ("file", &self.file), ("owners", &self.owners)]);
    }
}

impl ToPod for FieldQ {
    fn to_pod(&self) -> Pod {
        Pod::record("FieldQ", vec![("recv", self.recv.to_pod()), ("field", self.field.to_pod()), ("result", self.result.to_pod()), ("span", self.span.to_pod()), ("file", self.file.to_pod()), ("owners", self.owners.to_pod())])
    }
}

impl FromPod for FieldQ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(FieldQ { recv: FromPod::from_pod(field(p, "recv")?)?, field: FromPod::from_pod(field(p, "field")?)?, result: FromPod::from_pod(field(p, "result")?)?, span: FromPod::from_pod(field(p, "span")?)?, file: FromPod::from_pod(field(p, "file")?)?, owners: FromPod::from_pod(field(p, "owners")?)? })
    }
}

/// ```prism
/// Unify: unbounded fn St, Ty, Ty, Range -> St
/// ```
pub fn unify(st_p0: &crate::check::types::St, expected_p1: &crate::check::types::Ty, found_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> crate::check::types::St {
    let (verdict_p4, st2_p5) = unify_in(st_p0, expected_p1, found_p2, span_p3);
    if &verdict_p4 == &Text::lit("mismatch") {
        {
            let e_p6 = crate::check::types::show_ty(&st2_p5, expected_p1);
            let f_p7 = crate::check::types::show_ty(&st2_p5, found_p2);
            if &e_p6 == &f_p7 {
                crate::check::types::recording::err(&st2_p5, &Text::lit("mismatch"), span_p3, &Text::from(format!("expected `{}`, found `{}`", &show_ty_q(&st2_p5, expected_p1), &show_ty_q(&st2_p5, found_p2))))
            } else {
                crate::check::types::recording::err(&st2_p5, &Text::lit("mismatch"), span_p3, &Text::from(format!("expected `{}`, found `{}`", &e_p6, &f_p7)))
            }
        }
    } else {
        st2_p5.clone()
    }
}

/// The step machine of `Unify`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Unify: unbounded fn St, Ty, Ty, Range -> St
/// ```
pub struct Unify {
    pub st_p0: crate::check::types::St,
    pub expected_p1: crate::check::types::Ty,
    pub found_p2: crate::check::types::Ty,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for Unify {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let expected_p1 = &self.expected_p1;
        let found_p2 = &self.found_p2;
        let span_p3 = &self.span_p3;
        let expected_p1 = expected_p1.clone();
        let found_p2 = found_p2.clone();
        let span_p3 = span_p3.clone();
        let st_p0 = st_p0.clone();
        call_then(start_unify_in(st_p0.clone(), expected_p1.clone(), found_p2.clone(), span_p3.clone()), move |unify_in_1030: (Text, crate::check::types::St)| {
            let (verdict_p4, st2_p5) = unify_in_1030;
            if &verdict_p4 == &Text::lit("mismatch") {
                call_then(crate::check::types::start_show_ty(st2_p5.clone(), expected_p1.clone()), move |show_ty_1110: Text| {
                    let e_p6 = show_ty_1110;
                    call_then(crate::check::types::start_show_ty(st2_p5.clone(), found_p2.clone()), move |show_ty_1147: Text| {
                        let f_p7 = show_ty_1147;
                        if &e_p6 == &f_p7 {
                            call_then(start_show_ty_q(st2_p5.clone(), expected_p1.clone()), move |show_ty_q_1223: Text| call_then(start_show_ty_q(st2_p5.clone(), found_p2.clone()), move |show_ty_q_1256: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err(&st2_p5, &Text::lit("mismatch"), &span_p3, &Text::from(format!("expected `{}`, found `{}`", &show_ty_q_1223, &show_ty_q_1256))))))
                        } else {
                            prism_rtl::Turn::Finished(crate::check::types::recording::err(&st2_p5, &Text::lit("mismatch"), &span_p3, &Text::from(format!("expected `{}`, found `{}`", &e_p6, &f_p7))))
                        }
                    })
                })
            } else {
                prism_rtl::Turn::Finished(st2_p5.clone())
            }
        })
    }
}

/// `Start Unify, x`: what the function value is when passed to `@Run`.
pub fn start_unify(st_p0: crate::check::types::St, expected_p1: crate::check::types::Ty, found_p2: crate::check::types::Ty, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(Unify { st_p0, expected_p1, found_p2, span_p3 })
}

/// ```prism
/// ShowTyQ: unbounded fn St, Ty -> Text
/// ```
pub fn show_ty_q(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> Text {
    match crate::check::types::recording::zonk(st_p0, t_p1) {
        crate::check::types::Ty::TyCon(n_p2, m1487_0_1) if ((&m1487_0_1).len() == 0) => n_p2,
        crate::check::types::Ty::TyCon(n_p3, args_p4) => Text::from(format!("({}{})", &n_p3, &concat(&run_to_end(each_job(args_p4.clone(), {
            let st_p0 = st_p0.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let st_p0 = st_p0.clone();
                entered(once_job(move || {
                    let a_p5 = p0;
                    call_then(start_show_ty_q(st_p0.clone(), a_p5.clone()), move |show_ty_q_1578: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &show_ty_q_1578))))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>
        }))))),
        crate::check::types::Ty::TySig(s_p6, i_p7) => Text::from(format!("{}{}", &s_p6, &show_ty_q(st_p0, &*i_p7))),
        crate::check::types::Ty::TyArray(e_p8) => {
            let inner_p9 = show_ty_q(st_p0, &*e_p8);
            if crate::syntax::lexer::chars::has_prefix(&inner_p9, &Text::lit("[")) {
                Text::from(format!("[ {} ]", &inner_p9))
            } else {
                Text::from(format!("[{}]", &inner_p9))
            }
        },
        crate::check::types::Ty::TyMap(k_pa, v_pb) => Text::from(format!("({} ==> {})", &show_ty_q(st_p0, &*k_pa), &show_ty_q(st_p0, &*v_pb))),
        crate::check::types::Ty::TyAt(i_pc, rw_pd) => Text::from(format!("@{} emit {}", &show_ty_q(st_p0, &*i_pc), &crate::check::types::show_row_in(&rw_pd, &true))),
        other_pe => crate::check::types::show_ty(st_p0, &other_pe),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ShowTyQ`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowTyQ: unbounded fn St, Ty -> Text
/// ```
pub struct ShowTyQ {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<Text> for ShowTyQ {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0 = st_p0.clone();
        let t_p1 = t_p1.clone();
        call_then(crate::check::types::recording::start_zonk(st_p0.clone(), t_p1.clone()), move |zonk_1493: crate::check::types::Ty| match zonk_1493 {
            crate::check::types::Ty::TyCon(n_p2, m1487_0_1) if ((&m1487_0_1).len() == 0) => prism_rtl::Turn::Finished(n_p2.clone()),
            crate::check::types::Ty::TyCon(n_p3, args_p4) => call_value(each_job(args_p4.clone(), {
                let st_p0 = st_p0.clone();
                Rc::new(move |p0: crate::check::types::Ty| {
                    let st_p0 = st_p0.clone();
                    entered(once_job(move || {
                        let a_p5 = p0;
                        call_then(start_show_ty_q(st_p0.clone(), a_p5.clone()), move |show_ty_q_1578: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &show_ty_q_1578))))
                    }))
                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_1559: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("({}{})", &n_p3, &concat(&each_1559))))),
            crate::check::types::Ty::TySig(s_p6, i_p7) => call_then(start_show_ty_q(st_p0.clone(), (*i_p7).clone()), move |show_ty_q_1619: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &s_p6, &show_ty_q_1619)))),
            crate::check::types::Ty::TyArray(e_p8) => call_then(start_show_ty_q(st_p0.clone(), (*e_p8).clone()), move |show_ty_q_1670: Text| {
                let inner_p9 = show_ty_q_1670;
                if crate::syntax::lexer::chars::has_prefix(&inner_p9, &Text::lit("[")) {
                    prism_rtl::Turn::Finished(Text::from(format!("[ {} ]", &inner_p9)))
                } else {
                    prism_rtl::Turn::Finished(Text::from(format!("[{}]", &inner_p9)))
                }
            }),
            crate::check::types::Ty::TyMap(k_pa, v_pb) => call_then(start_show_ty_q(st_p0.clone(), (*k_pa).clone()), move |show_ty_q_1770: Text| call_then(start_show_ty_q(st_p0.clone(), (*v_pb).clone()), move |show_ty_q_1790: Text| prism_rtl::Turn::Finished(Text::from(format!("({} ==> {})", &show_ty_q_1770, &show_ty_q_1790))))),
            crate::check::types::Ty::TyAt(i_pc, rw_pd) => call_then(start_show_ty_q(st_p0.clone(), (*i_pc).clone()), move |show_ty_q_1826: Text| prism_rtl::Turn::Finished(Text::from(format!("@{} emit {}", &show_ty_q_1826, &crate::check::types::show_row_in(&rw_pd, &true))))),
            other_pe => prism_rtl::Turn::More(Rc::new(crate::check::types::ShowTy { st_p0: st_p0.clone(), t_p1: other_pe.clone() })),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start ShowTyQ, x`: what the function value is when passed to `@Run`.
pub fn start_show_ty_q(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ShowTyQ { st_p0, t_p1 })
}

/// ```prism
/// TryUnify: unbounded fn St, Ty, Ty, Range -> ((Bool, St))
/// ```
pub fn try_unify(st_p0: &crate::check::types::St, expected_p1: &crate::check::types::Ty, found_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> (bool, crate::check::types::St) {
    let (verdict_p4, st2_p5) = unify_in(st_p0, expected_p1, found_p2, span_p3);
    (&verdict_p4 == &Text::lit(""), st2_p5.clone())
}

/// The step machine of `TryUnify`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TryUnify: unbounded fn St, Ty, Ty, Range -> ((Bool, St))
/// ```
pub struct TryUnify {
    pub st_p0: crate::check::types::St,
    pub expected_p1: crate::check::types::Ty,
    pub found_p2: crate::check::types::Ty,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(bool, crate::check::types::St)> for TryUnify {
    fn cycle(&self) -> prism_rtl::Turn<(bool, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let expected_p1 = &self.expected_p1;
        let found_p2 = &self.found_p2;
        let span_p3 = &self.span_p3;
        let expected_p1 = expected_p1.clone();
        let found_p2 = found_p2.clone();
        let span_p3 = span_p3.clone();
        let st_p0 = st_p0.clone();
        call_then(start_unify_in(st_p0.clone(), expected_p1.clone(), found_p2.clone(), span_p3.clone()), move |unify_in_2156: (Text, crate::check::types::St)| {
            let (verdict_p4, st2_p5) = unify_in_2156;
            prism_rtl::Turn::Finished((&verdict_p4 == &Text::lit(""), st2_p5.clone()))
        })
    }
}

/// `Start TryUnify, x`: what the function value is when passed to `@Run`.
pub fn start_try_unify(st_p0: crate::check::types::St, expected_p1: crate::check::types::Ty, found_p2: crate::check::types::Ty, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(bool, crate::check::types::St)>> {
    Rc::new(TryUnify { st_p0, expected_p1, found_p2, span_p3 })
}

/// ```prism
/// UnifyIn: unbounded fn St, Ty, Ty, Range -> ((Text, St))
/// ```
pub fn unify_in(st_p0: &crate::check::types::St, expected_p1: &crate::check::types::Ty, found_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> (Text, crate::check::types::St) {
    let e_p4 = norm_assoc(st_p0, &crate::check::types::recording::walk(st_p0, expected_p1));
    let f_p5 = norm_assoc(st_p0, &crate::check::types::recording::walk(st_p0, found_p2));
    if is_waiting_assoc(st_p0, &e_p4) || is_waiting_assoc(st_p0, &f_p5) {
        if &e_p4 == &f_p5 {
            (Text::lit(""), st_p0.clone())
        } else {
            (Text::lit(""), defer(st_p0, &e_p4, &f_p5, span_p3))
        }
    } else {
        unify_heads(st_p0, &e_p4, &f_p5, span_p3)
    }
}

/// The step machine of `UnifyIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyIn: unbounded fn St, Ty, Ty, Range -> ((Text, St))
/// ```
pub struct UnifyIn {
    pub st_p0: crate::check::types::St,
    pub expected_p1: crate::check::types::Ty,
    pub found_p2: crate::check::types::Ty,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(Text, crate::check::types::St)> for UnifyIn {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let expected_p1 = &self.expected_p1;
        let found_p2 = &self.found_p2;
        let span_p3 = &self.span_p3;
        let expected_p1 = expected_p1.clone();
        let found_p2 = found_p2.clone();
        let span_p3 = span_p3.clone();
        let st_p0 = st_p0.clone();
        call_then(crate::check::types::recording::start_walk(st_p0.clone(), expected_p1.clone()), move |walk_2446: crate::check::types::Ty| call_then(start_norm_assoc(st_p0.clone(), walk_2446), move |norm_assoc_2431: crate::check::types::Ty| {
            let e_p4 = norm_assoc_2431;
            call_then(crate::check::types::recording::start_walk(st_p0.clone(), found_p2.clone()), move |walk_2492: crate::check::types::Ty| call_then(start_norm_assoc(st_p0.clone(), walk_2492), move |norm_assoc_2477: crate::check::types::Ty| {
                let f_p5 = norm_assoc_2477;
                call_then(start_is_waiting_assoc(st_p0.clone(), e_p4.clone()), move |is_waiting_assoc_2516: bool| if is_waiting_assoc_2516 || is_waiting_assoc(&st_p0, &f_p5) {
                    if &e_p4 == &f_p5 {
                        prism_rtl::Turn::Finished((Text::lit(""), st_p0.clone()))
                    } else {
                        prism_rtl::Turn::Finished((Text::lit(""), defer(&st_p0, &e_p4, &f_p5, &span_p3)))
                    }
                } else {
                    prism_rtl::Turn::More(Rc::new(UnifyHeads { st_p0: st_p0.clone(), e_p1: e_p4.clone(), f_p2: f_p5.clone(), span_p3: span_p3.clone() }))
                })
            }))
        }))
    }
}

/// `Start UnifyIn, x`: what the function value is when passed to `@Run`.
pub fn start_unify_in(st_p0: crate::check::types::St, expected_p1: crate::check::types::Ty, found_p2: crate::check::types::Ty, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>> {
    Rc::new(UnifyIn { st_p0, expected_p1, found_p2, span_p3 })
}

/// ```prism
/// NormAssoc: unbounded fn St, Ty -> Ty
/// ```
pub fn norm_assoc(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p1 {
        crate::check::types::Ty::TyAssoc(m2934_0_0, a_p2) if (m2934_0_0 == &Text::lit("Quotient")) => match crate::check::types::recording::walk(st_p0, &**a_p2) {
            crate::check::types::Ty::TyCon(m2970_0_0, m2970_0_1) if (&m2970_0_0 == &Text::lit("Float")) && ((&m2970_0_1).len() == 0) => crate::check::types::t_float(),
            crate::check::types::Ty::TyCon(n_p3, m2970_1_1) if ((&m2970_1_1).len() == 0) => if ((&n_p3 == &Text::lit("Nat")) || (&n_p3 == &Text::lit("Int"))) || (&n_p3 == &Text::lit("U8")) {
                crate::check::types::Ty::TySig(Text::lit("?"), Rc::new(crate::check::types::Ty::TyCon(n_p3.clone(), Array::new())))
            } else {
                t_p1.clone()
            },
            _ => t_p1.clone(),
            _ => unreachable!("no arm matched"),
        },
        other_p4 => other_p4.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `NormAssoc`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NormAssoc: unbounded fn St, Ty -> Ty
/// ```
pub struct NormAssoc {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::Ty> for NormAssoc {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        match t_p1 {
            crate::check::types::Ty::TyAssoc(m2934_0_0, a_p2) if (m2934_0_0 == &Text::lit("Quotient")) => {
                let a_p2 = (**a_p2).clone();
                let st_p0 = st_p0.clone();
                let t_p1 = t_p1.clone();
                call_then(crate::check::types::recording::start_walk(st_p0.clone(), a_p2.clone()), move |walk_2976: crate::check::types::Ty| match walk_2976 {
                    crate::check::types::Ty::TyCon(m2970_0_0, m2970_0_1) if (&m2970_0_0 == &Text::lit("Float")) && ((&m2970_0_1).len() == 0) => prism_rtl::Turn::Finished(crate::check::types::t_float()),
                    crate::check::types::Ty::TyCon(n_p3, m2970_1_1) if ((&m2970_1_1).len() == 0) => if ((&n_p3 == &Text::lit("Nat")) || (&n_p3 == &Text::lit("Int"))) || (&n_p3 == &Text::lit("U8")) {
                        prism_rtl::Turn::Finished(crate::check::types::Ty::TySig(Text::lit("?"), Rc::new(crate::check::types::Ty::TyCon(n_p3.clone(), Array::new()))))
                    } else {
                        prism_rtl::Turn::Finished(t_p1.clone())
                    },
                    _ => prism_rtl::Turn::Finished(t_p1.clone()),
                    _ => unreachable!("no arm matched"),
                })
            },
            other_p4 => prism_rtl::Turn::Finished(other_p4.clone()),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start NormAssoc, x`: what the function value is when passed to `@Run`.
pub fn start_norm_assoc(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(NormAssoc { st_p0, t_p1 })
}

/// ```prism
/// IsWaitingAssoc: unbounded fn St, Ty -> Bool
/// ```
pub fn is_waiting_assoc(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> bool {
    match t_p1 {
        crate::check::types::Ty::TyAssoc(_, a_p2) => crate::check::types::is_flex_var(st_p0, &**a_p2),
        _ => false,
    }
}

/// The step machine of `IsWaitingAssoc`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsWaitingAssoc: unbounded fn St, Ty -> Bool
/// ```
pub struct IsWaitingAssoc {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<bool> for IsWaitingAssoc {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        match t_p1 {
            crate::check::types::Ty::TyAssoc(_, a_p2) => prism_rtl::Turn::More(Rc::new(crate::check::types::IsFlexVar { st_p0: st_p0.clone(), t_p1: (**a_p2).clone() })),
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start IsWaitingAssoc, x`: what the function value is when passed to `@Run`.
pub fn start_is_waiting_assoc(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsWaitingAssoc { st_p0, t_p1 })
}

/// ```prism
/// Defer: fn St, Ty, Ty, Range -> St
/// ```
pub fn defer(st_p0: &crate::check::types::St, e_p1: &crate::check::types::Ty, f_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.deferred = push(&this.deferred, &(e_p1.clone(), f_p2.clone(), span_p3.clone()));
    this
}

/// ```prism
/// RetryDeferred: unbounded fn St -> St
/// ```
pub fn retry_deferred(st_p0: &crate::check::types::St) -> crate::check::types::St {
    let waiting_p1 = st_p0.deferred.clone();
    let cleared_p2 = {
        let mut this: crate::check::types::St = st_p0.clone();
        this.deferred = Array::new();
        this
    };
    run_to_end(fold_job(waiting_p1.clone(), cleared_p2.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, (crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range))| entered(once_job(move || {
        let s_p3 = p0;
        let (e_p4, f_p5, span_p6) = p1;
        prism_rtl::Turn::More(Rc::new(Unify { st_p0: s_p3.clone(), expected_p1: e_p4.clone(), found_p2: f_p5.clone(), span_p3: span_p6.clone() }))
    }))) as Rc<dyn Fn((crate::check::types::St, (crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range))) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>))
}

/// The step machine of `RetryDeferred`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RetryDeferred: unbounded fn St -> St
/// ```
pub struct RetryDeferred {
    pub st_p0: crate::check::types::St,
}

impl prism_rtl::Job<crate::check::types::St> for RetryDeferred {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let waiting_p1 = st_p0.deferred.clone();
        let cleared_p2 = {
            let mut this: crate::check::types::St = st_p0.clone();
            this.deferred = Array::new();
            this
        };
        fold_job(waiting_p1.clone(), cleared_p2.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, (crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range))| entered(once_job(move || {
            let s_p3 = p0;
            let (e_p4, f_p5, span_p6) = p1;
            prism_rtl::Turn::More(Rc::new(Unify { st_p0: s_p3.clone(), expected_p1: e_p4.clone(), found_p2: f_p5.clone(), span_p3: span_p6.clone() }))
        }))) as Rc<dyn Fn((crate::check::types::St, (crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range))) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>).cycle()
    }
}

/// `Start RetryDeferred, x`: what the function value is when passed to `@Run`.
pub fn start_retry_deferred(st_p0: crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(RetryDeferred { st_p0 })
}

/// ```prism
/// UnifyHeads: unbounded fn St, Ty, Ty, Range -> ((Text, St))
/// ```
pub fn unify_heads(st_p0: &crate::check::types::St, e_p1: &crate::check::types::Ty, f_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> (Text, crate::check::types::St) {
    match (e_p1.clone(), f_p2.clone()) {
        (crate::check::types::Ty::TyErr, _) => (Text::lit(""), st_p0.clone()),
        (_, crate::check::types::Ty::TyErr) => (Text::lit(""), st_p0.clone()),
        (crate::check::types::Ty::TySig(m3799_2_0_0, _), crate::check::types::Ty::TyCon(m3799_2_1_0, m3799_2_1_1)) if (&m3799_2_0_0 == &Text::lit("~")) && (&m3799_2_1_0 == &Text::lit("Prelude.Error")) && ((&m3799_2_1_1).len() == 0) => (Text::lit(""), st_p0.clone()),
        (crate::check::types::Ty::TyCon(m3799_3_0_0, m3799_3_0_1), crate::check::types::Ty::TySig(m3799_3_1_0, _)) if (&m3799_3_0_0 == &Text::lit("Prelude.Error")) && ((&m3799_3_0_1).len() == 0) && (&m3799_3_1_0 == &Text::lit("~")) => (Text::lit(""), st_p0.clone()),
        (crate::check::types::Ty::TyFlex(a_p4), crate::check::types::Ty::TyFlex(b_p5)) => if &a_p4 == &b_p5 {
            (Text::lit(""), st_p0.clone())
        } else {
            (Text::lit(""), merge_vars(st_p0, &a_p4, &b_p5))
        },
        (crate::check::types::Ty::TyFlex(a_p6), t_p7) => bind_var(st_p0, &a_p6, &t_p7, span_p3),
        (t_p8, crate::check::types::Ty::TyFlex(b_p9)) => bind_var(st_p0, &b_p9, &t_p8, span_p3),
        (crate::check::types::Ty::TyRigid(a_pa), crate::check::types::Ty::TyRigid(b_pb)) => if &a_pa == &b_pb {
            (Text::lit(""), st_p0.clone())
        } else {
            (Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Ty::TyQ(a_pc), crate::check::types::Ty::TyQ(b_pd)) => if &a_pc == &b_pd {
            (Text::lit(""), st_p0.clone())
        } else {
            (Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Ty::TyCon(a_pe, xs_pf), crate::check::types::Ty::TyCon(b_pg, ys_ph)) => if (&a_pe == &b_pg) && (&len(&xs_pf) == &len(&ys_ph)) {
            unify_all(st_p0, &xs_pf, &ys_ph, span_p3)
        } else {
            (Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Ty::TyFn(c1_pi, ps_pj, r1_pk), crate::check::types::Ty::TyFn(c2_pl, qs_pm, r2_pn)) => if &len(&ps_pj) == &len(&qs_pm) {
            {
                let (v_po, st2_pp) = crate::check::types::colors::unify_col(st_p0, &c1_pi, &c2_pl);
                if &v_po != &Text::lit("") {
                    (v_po.clone(), st2_pp.clone())
                } else {
                    unify_all(&st2_pp, &push(&ps_pj, &*r1_pk), &push(&qs_pm, &*r2_pn), span_p3)
                }
            }
        } else {
            (Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Ty::TyTuple(xs_pq), crate::check::types::Ty::TyTuple(ys_pr)) => if &len(&xs_pq) == &len(&ys_pr) {
            unify_all(st_p0, &xs_pq, &ys_pr, span_p3)
        } else {
            (Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Ty::TyArray(x_ps), crate::check::types::Ty::TyArray(y_pt)) => unify_in(st_p0, &*x_ps, &*y_pt, span_p3),
        (crate::check::types::Ty::TyMap(k1_pu, v1_pv), crate::check::types::Ty::TyMap(k2_p10, v2_p11)) => unify_all(st_p0, &Array::from(vec![(*k1_pu).clone(), (*v1_pv).clone()]), &Array::from(vec![(*k2_p10).clone(), (*v2_p11).clone()]), span_p3),
        (crate::check::types::Ty::TySig(s1_p12, i1_p13), crate::check::types::Ty::TySig(s2_p14, i2_p15)) => if &s1_p12 == &s2_p14 {
            unify_in(st_p0, &*i1_p13, &*i2_p15, span_p3)
        } else {
            (Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Ty::TyAt(i1_p16, r1_p17), crate::check::types::Ty::TyAt(i2_p18, r2_p19)) => {
            let (v_p1a, st2_p1b) = unify_in(st_p0, &*i1_p16, &*i2_p18, span_p3);
            if &v_p1a != &Text::lit("") {
                (v_p1a.clone(), st2_p1b.clone())
            } else {
                unify_row(&st2_p1b, &r1_p17, &r2_p19, span_p3)
            }
        },
        (crate::check::types::Ty::TyElem(r1_p1c, o1_p1d), crate::check::types::Ty::TyElem(r2_p1e, o2_p1f)) => {
            let (v_p1g, st2_p1h) = unify_row(st_p0, &r1_p1c, &r2_p1e, span_p3);
            if &v_p1g != &Text::lit("") {
                (v_p1g.clone(), st2_p1h.clone())
            } else {
                unify_in(&st2_p1h, &*o1_p1d, &*o2_p1f, span_p3)
            }
        },
        (crate::check::types::Ty::TyElemAny(r1_p1i), crate::check::types::Ty::TyElemAny(r2_p1j)) => unify_row(st_p0, &r1_p1i, &r2_p1j, span_p3),
        (crate::check::types::Ty::TyAssoc(n1_p1k, a1_p1l), crate::check::types::Ty::TyAssoc(n2_p1m, a2_p1n)) => if &n1_p1k == &n2_p1m {
            unify_in(st_p0, &*a1_p1l, &*a2_p1n, span_p3)
        } else {
            (Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Ty::TyAny(xs_p1o), crate::check::types::Ty::TyAny(ys_p1p)) => if &crate::check::types::sort_texts(&xs_p1o) == &crate::check::types::sort_texts(&ys_p1p) {
            (Text::lit(""), st_p0.clone())
        } else {
            (Text::lit("mismatch"), st_p0.clone())
        },
        _ => (Text::lit("mismatch"), st_p0.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `UnifyHeads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyHeads: unbounded fn St, Ty, Ty, Range -> ((Text, St))
/// ```
pub struct UnifyHeads {
    pub st_p0: crate::check::types::St,
    pub e_p1: crate::check::types::Ty,
    pub f_p2: crate::check::types::Ty,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(Text, crate::check::types::St)> for UnifyHeads {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let e_p1 = &self.e_p1;
        let f_p2 = &self.f_p2;
        let span_p3 = &self.span_p3;
        match (e_p1.clone(), f_p2.clone()) {
            (crate::check::types::Ty::TyErr, _) => prism_rtl::Turn::Finished((Text::lit(""), st_p0.clone())),
            (_, crate::check::types::Ty::TyErr) => prism_rtl::Turn::Finished((Text::lit(""), st_p0.clone())),
            (crate::check::types::Ty::TySig(m3799_2_0_0, _), crate::check::types::Ty::TyCon(m3799_2_1_0, m3799_2_1_1)) if (&m3799_2_0_0 == &Text::lit("~")) && (&m3799_2_1_0 == &Text::lit("Prelude.Error")) && ((&m3799_2_1_1).len() == 0) => prism_rtl::Turn::Finished((Text::lit(""), st_p0.clone())),
            (crate::check::types::Ty::TyCon(m3799_3_0_0, m3799_3_0_1), crate::check::types::Ty::TySig(m3799_3_1_0, _)) if (&m3799_3_0_0 == &Text::lit("Prelude.Error")) && ((&m3799_3_0_1).len() == 0) && (&m3799_3_1_0 == &Text::lit("~")) => prism_rtl::Turn::Finished((Text::lit(""), st_p0.clone())),
            (crate::check::types::Ty::TyFlex(a_p4), crate::check::types::Ty::TyFlex(b_p5)) => if &a_p4 == &b_p5 {
                prism_rtl::Turn::Finished((Text::lit(""), st_p0.clone()))
            } else {
                prism_rtl::Turn::Finished((Text::lit(""), merge_vars(st_p0, &a_p4, &b_p5)))
            },
            (crate::check::types::Ty::TyFlex(a_p6), t_p7) => prism_rtl::Turn::More(Rc::new(BindVar { st_p0: st_p0.clone(), n_p1: a_p6.clone(), t_p2: t_p7.clone(), span_p3: span_p3.clone() })),
            (t_p8, crate::check::types::Ty::TyFlex(b_p9)) => prism_rtl::Turn::More(Rc::new(BindVar { st_p0: st_p0.clone(), n_p1: b_p9.clone(), t_p2: t_p8.clone(), span_p3: span_p3.clone() })),
            (crate::check::types::Ty::TyRigid(a_pa), crate::check::types::Ty::TyRigid(b_pb)) => if &a_pa == &b_pb {
                prism_rtl::Turn::Finished((Text::lit(""), st_p0.clone()))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0.clone()))
            },
            (crate::check::types::Ty::TyQ(a_pc), crate::check::types::Ty::TyQ(b_pd)) => if &a_pc == &b_pd {
                prism_rtl::Turn::Finished((Text::lit(""), st_p0.clone()))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0.clone()))
            },
            (crate::check::types::Ty::TyCon(a_pe, xs_pf), crate::check::types::Ty::TyCon(b_pg, ys_ph)) => if (&a_pe == &b_pg) && (&len(&xs_pf) == &len(&ys_ph)) {
                prism_rtl::Turn::More(Rc::new(UnifyAll { st_p0: st_p0.clone(), xs_p1: xs_pf.clone(), ys_p2: ys_ph.clone(), span_p3: span_p3.clone() }))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0.clone()))
            },
            (crate::check::types::Ty::TyFn(c1_pi, ps_pj, r1_pk), crate::check::types::Ty::TyFn(c2_pl, qs_pm, r2_pn)) => if &len(&ps_pj) == &len(&qs_pm) {
                {
                    let span_p3 = span_p3.clone();
                    let st_p0 = st_p0.clone();
                    call_then(crate::check::types::colors::start_unify_col(st_p0.clone(), c1_pi.clone(), c2_pl.clone()), move |unify_col_4653: (Text, crate::check::types::St)| {
                        let (v_po, st2_pp) = unify_col_4653;
                        if &v_po != &Text::lit("") {
                            prism_rtl::Turn::Finished((v_po.clone(), st2_pp.clone()))
                        } else {
                            prism_rtl::Turn::More(Rc::new(UnifyAll { st_p0: st2_pp.clone(), xs_p1: push(&ps_pj, &*r1_pk), ys_p2: push(&qs_pm, &*r2_pn), span_p3: span_p3.clone() }))
                        }
                    })
                }
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0.clone()))
            },
            (crate::check::types::Ty::TyTuple(xs_pq), crate::check::types::Ty::TyTuple(ys_pr)) => if &len(&xs_pq) == &len(&ys_pr) {
                prism_rtl::Turn::More(Rc::new(UnifyAll { st_p0: st_p0.clone(), xs_p1: xs_pq.clone(), ys_p2: ys_pr.clone(), span_p3: span_p3.clone() }))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0.clone()))
            },
            (crate::check::types::Ty::TyArray(x_ps), crate::check::types::Ty::TyArray(y_pt)) => prism_rtl::Turn::More(Rc::new(UnifyIn { st_p0: st_p0.clone(), expected_p1: (*x_ps).clone(), found_p2: (*y_pt).clone(), span_p3: span_p3.clone() })),
            (crate::check::types::Ty::TyMap(k1_pu, v1_pv), crate::check::types::Ty::TyMap(k2_p10, v2_p11)) => prism_rtl::Turn::More(Rc::new(UnifyAll { st_p0: st_p0.clone(), xs_p1: Array::from(vec![(*k1_pu).clone(), (*v1_pv).clone()]), ys_p2: Array::from(vec![(*k2_p10).clone(), (*v2_p11).clone()]), span_p3: span_p3.clone() })),
            (crate::check::types::Ty::TySig(s1_p12, i1_p13), crate::check::types::Ty::TySig(s2_p14, i2_p15)) => if &s1_p12 == &s2_p14 {
                prism_rtl::Turn::More(Rc::new(UnifyIn { st_p0: st_p0.clone(), expected_p1: (*i1_p13).clone(), found_p2: (*i2_p15).clone(), span_p3: span_p3.clone() }))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0.clone()))
            },
            (crate::check::types::Ty::TyAt(i1_p16, r1_p17), crate::check::types::Ty::TyAt(i2_p18, r2_p19)) => {
                let span_p3 = span_p3.clone();
                let st_p0 = st_p0.clone();
                call_then(start_unify_in(st_p0.clone(), (*i1_p16).clone(), (*i2_p18).clone(), span_p3.clone()), move |unify_in_5237: (Text, crate::check::types::St)| {
                    let (v_p1a, st2_p1b) = unify_in_5237;
                    if &v_p1a != &Text::lit("") {
                        prism_rtl::Turn::Finished((v_p1a.clone(), st2_p1b.clone()))
                    } else {
                        prism_rtl::Turn::More(Rc::new(UnifyRow { st_p0: st2_p1b.clone(), a0_p1: r1_p17.clone(), b0_p2: r2_p19.clone(), span_p3: span_p3.clone() }))
                    }
                })
            },
            (crate::check::types::Ty::TyElem(r1_p1c, o1_p1d), crate::check::types::Ty::TyElem(r2_p1e, o2_p1f)) => {
                let span_p3 = span_p3.clone();
                let st_p0 = st_p0.clone();
                call_then(start_unify_row(st_p0.clone(), r1_p1c.clone(), r2_p1e.clone(), span_p3.clone()), move |unify_row_5405: (Text, crate::check::types::St)| {
                    let (v_p1g, st2_p1h) = unify_row_5405;
                    if &v_p1g != &Text::lit("") {
                        prism_rtl::Turn::Finished((v_p1g.clone(), st2_p1h.clone()))
                    } else {
                        prism_rtl::Turn::More(Rc::new(UnifyIn { st_p0: st2_p1h.clone(), expected_p1: (*o1_p1d).clone(), found_p2: (*o2_p1f).clone(), span_p3: span_p3.clone() }))
                    }
                })
            },
            (crate::check::types::Ty::TyElemAny(r1_p1i), crate::check::types::Ty::TyElemAny(r2_p1j)) => prism_rtl::Turn::More(Rc::new(UnifyRow { st_p0: st_p0.clone(), a0_p1: r1_p1i.clone(), b0_p2: r2_p1j.clone(), span_p3: span_p3.clone() })),
            (crate::check::types::Ty::TyAssoc(n1_p1k, a1_p1l), crate::check::types::Ty::TyAssoc(n2_p1m, a2_p1n)) => if &n1_p1k == &n2_p1m {
                prism_rtl::Turn::More(Rc::new(UnifyIn { st_p0: st_p0.clone(), expected_p1: (*a1_p1l).clone(), found_p2: (*a2_p1n).clone(), span_p3: span_p3.clone() }))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0.clone()))
            },
            (crate::check::types::Ty::TyAny(xs_p1o), crate::check::types::Ty::TyAny(ys_p1p)) => if &crate::check::types::sort_texts(&xs_p1o) == &crate::check::types::sort_texts(&ys_p1p) {
                prism_rtl::Turn::Finished((Text::lit(""), st_p0.clone()))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0.clone()))
            },
            _ => prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0.clone())),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start UnifyHeads, x`: what the function value is when passed to `@Run`.
pub fn start_unify_heads(st_p0: crate::check::types::St, e_p1: crate::check::types::Ty, f_p2: crate::check::types::Ty, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>> {
    Rc::new(UnifyHeads { st_p0, e_p1, f_p2, span_p3 })
}

/// ```prism
/// UnifyAll: unbounded fn St, [Ty], [Ty], Range -> ((Text, St))
/// ```
pub fn unify_all(st_p0: &crate::check::types::St, xs_p1: &Array<crate::check::types::Ty>, ys_p2: &Array<crate::check::types::Ty>, span_p3: &crate::syntax::Range) -> (Text, crate::check::types::St) {
    run_to_end(fold_job(crate::check::errors::range0(&len(xs_p1)), (Text::lit(""), st_p0.clone()), {
        let xs_p1 = xs_p1.clone();
        let ys_p2 = ys_p2.clone();
        let span_p3 = span_p3.clone();
        Rc::new(move |(p0, p1): ((Text, crate::check::types::St), Nat)| {
            let xs_p1 = xs_p1.clone();
            let ys_p2 = ys_p2.clone();
            let span_p3 = span_p3.clone();
            entered(once_job(move || {
                let (v_p4, s_p5) = p0;
                let i_p6 = p1;
                if &v_p4 != &Text::lit("") {
                    prism_rtl::Turn::Finished((v_p4.clone(), s_p5.clone()))
                } else {
                    prism_rtl::Turn::More(Rc::new(UnifyIn { st_p0: s_p5.clone(), expected_p1: or(&index(&xs_p1, &i_p6), &crate::check::types::Ty::TyErr), found_p2: or(&index(&ys_p2, &i_p6), &crate::check::types::Ty::TyErr), span_p3: span_p3.clone() }))
                }
            }))
        }) as Rc<dyn Fn(((Text, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>>>
    }))
}

/// The step machine of `UnifyAll`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyAll: unbounded fn St, [Ty], [Ty], Range -> ((Text, St))
/// ```
pub struct UnifyAll {
    pub st_p0: crate::check::types::St,
    pub xs_p1: Array<crate::check::types::Ty>,
    pub ys_p2: Array<crate::check::types::Ty>,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(Text, crate::check::types::St)> for UnifyAll {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let xs_p1 = &self.xs_p1;
        let ys_p2 = &self.ys_p2;
        let span_p3 = &self.span_p3;
        fold_job(crate::check::errors::range0(&len(xs_p1)), (Text::lit(""), st_p0.clone()), {
            let xs_p1 = xs_p1.clone();
            let ys_p2 = ys_p2.clone();
            let span_p3 = span_p3.clone();
            Rc::new(move |(p0, p1): ((Text, crate::check::types::St), Nat)| {
                let xs_p1 = xs_p1.clone();
                let ys_p2 = ys_p2.clone();
                let span_p3 = span_p3.clone();
                entered(once_job(move || {
                    let (v_p4, s_p5) = p0;
                    let i_p6 = p1;
                    if &v_p4 != &Text::lit("") {
                        prism_rtl::Turn::Finished((v_p4.clone(), s_p5.clone()))
                    } else {
                        prism_rtl::Turn::More(Rc::new(UnifyIn { st_p0: s_p5.clone(), expected_p1: or(&index(&xs_p1, &i_p6), &crate::check::types::Ty::TyErr), found_p2: or(&index(&ys_p2, &i_p6), &crate::check::types::Ty::TyErr), span_p3: span_p3.clone() }))
                    }
                }))
            }) as Rc<dyn Fn(((Text, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>>>
        }).cycle()
    }
}

/// `Start UnifyAll, x`: what the function value is when passed to `@Run`.
pub fn start_unify_all(st_p0: crate::check::types::St, xs_p1: Array<crate::check::types::Ty>, ys_p2: Array<crate::check::types::Ty>, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>> {
    Rc::new(UnifyAll { st_p0, xs_p1, ys_p2, span_p3 })
}

/// ```prism
/// MergeVars: fn St, Nat, Nat -> St
/// ```
pub fn merge_vars(st_p0: &crate::check::types::St, a_p1: &Nat, b_p2: &Nat) -> crate::check::types::St {
    let ia_p3 = crate::check::types::recording::info_of(st_p0, a_p1);
    let ib_p4 = crate::check::types::recording::info_of(st_p0, b_p2);
    let merged_p5 = crate::check::types::VInfo { plain: ia_p3.plain || ib_p4.plain, level: min(&ia_p3.level, &ib_p4.level), name: if &ib_p4.name == &Text::lit("") { ia_p3.name.clone() } else { ib_p4.name.clone() } };
    let mut this: crate::check::types::St = st_p0.clone();
    this.tys = insert(&this.tys, a_p1, &crate::check::types::Ty::TyFlex(b_p2.clone()));
    this.infos = insert(&this.infos, b_p2, &merged_p5);
    this
}

/// ```prism
/// BindVar: unbounded fn St, Nat, Ty, Range -> ((Text, St))
/// ```
pub fn bind_var(st_p0: &crate::check::types::St, n_p1: &Nat, t_p2: &crate::check::types::Ty, span_p3: &crate::syntax::Range) -> (Text, crate::check::types::St) {
    let info_p4 = crate::check::types::recording::info_of(st_p0, n_p1);
    let stack_p5 = crate::check::types::stack_of(st_p0, t_p2);
    if crate::check::types::has_nat(&crate::check::types::recording::free_vars(st_p0, t_p2), n_p1) {
        (Text::lit("reported"), crate::check::types::recording::err(st_p0, &Text::lit("occurs"), span_p3, &Text::from(format!("`t{}` would contain itself: `t{} = {}`", n_p1, n_p1, &crate::check::types::show_ty(st_p0, t_p2)))))
    } else {
        if info_p4.plain && (&stack_p5 != &Text::lit("")) {
            if &info_p4.name != &Text::lit("") {
                {
                    let marks_p6 = marks_of(&info_p4.name);
                    let whole_p7 = Text::from(format!("{}{}", &marks_p6, &crate::check::types::show_ty_in(st_p0, &crate::check::types::recording::zonk(st_p0, t_p2), &true)));
                    let at_p8 = or(&get(&st_p0.binder_at, n_p1), span_p3);
                    let st2_p9 = crate::check::types::recording::err_fix(st_p0, &Text::lit("mark-stack"), &at_p8, &Text::from(format!("`{}` has type `{}`, whose stack is `{}{}`; the name shows `{}`", &info_p4.name, &whole_p7, &marks_p6, &stack_p5, &marks_p6)), &Text::from(format!("rename to `{}{}{}`", &marks_p6, &stack_p5, &crate::syntax::lexer::chars::drop_prefix(&info_p4.name, &marks_p6))));
                    (Text::lit(""), {
                        let mut this: crate::check::types::St = lower_levels(&st2_p9, &append(&crate::check::types::recording::free_vars(&st2_p9, t_p2), &crate::check::types::colors::free_col_vars(&st2_p9, t_p2)), &info_p4.level);
                        this.tys = insert(&this.tys, n_p1, t_p2);
                        this
                    })
                }
            } else {
                (Text::lit("mismatch"), st_p0.clone())
            }
        } else {
            {
                let lowered_pa = lower_levels(st_p0, &append(&crate::check::types::recording::free_vars(st_p0, t_p2), &crate::check::types::colors::free_col_vars(st_p0, t_p2)), &info_p4.level);
                (Text::lit(""), {
                    let mut this: crate::check::types::St = lowered_pa.clone();
                    this.tys = insert(&this.tys, n_p1, t_p2);
                    this
                })
            }
        }
    }
}

/// The step machine of `BindVar`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindVar: unbounded fn St, Nat, Ty, Range -> ((Text, St))
/// ```
pub struct BindVar {
    pub st_p0: crate::check::types::St,
    pub n_p1: Nat,
    pub t_p2: crate::check::types::Ty,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(Text, crate::check::types::St)> for BindVar {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let n_p1 = &self.n_p1;
        let t_p2 = &self.t_p2;
        let span_p3 = &self.span_p3;
        let info_p4 = crate::check::types::recording::info_of(st_p0, n_p1);
        let n_p1 = n_p1.clone();
        let span_p3 = span_p3.clone();
        let st_p0 = st_p0.clone();
        let t_p2 = t_p2.clone();
        call_then(crate::check::types::start_stack_of(st_p0.clone(), t_p2.clone()), move |stack_of_6651: Text| {
            let stack_p5 = stack_of_6651;
            call_then(crate::check::types::recording::start_free_vars(st_p0.clone(), t_p2.clone()), move |free_vars_6680: Array<Nat>| if crate::check::types::has_nat(&free_vars_6680, &n_p1) {
                call_then(crate::check::types::start_show_ty(st_p0.clone(), t_p2.clone()), move |show_ty_6786: Text| prism_rtl::Turn::Finished((Text::lit("reported"), crate::check::types::recording::err(&st_p0, &Text::lit("occurs"), &span_p3, &Text::from(format!("`t{}` would contain itself: `t{} = {}`", &n_p1, &n_p1, &show_ty_6786))))))
            } else {
                if info_p4.plain && (&stack_p5 != &Text::lit("")) {
                    if &info_p4.name != &Text::lit("") {
                        {
                            let marks_p6 = marks_of(&info_p4.name);
                            call_then(crate::check::types::recording::start_zonk(st_p0.clone(), t_p2.clone()), move |zonk_6963: crate::check::types::Ty| call_then(crate::check::types::start_show_ty_in(st_p0.clone(), zonk_6963, true), move |show_ty_in_6949: Text| {
                                let whole_p7 = Text::from(format!("{}{}", &marks_p6, &show_ty_in_6949));
                                let at_p8 = or(&get(&st_p0.binder_at, &n_p1), &span_p3);
                                let st2_p9 = crate::check::types::recording::err_fix(&st_p0, &Text::lit("mark-stack"), &at_p8, &Text::from(format!("`{}` has type `{}`, whose stack is `{}{}`; the name shows `{}`", &info_p4.name, &whole_p7, &marks_p6, &stack_p5, &marks_p6)), &Text::from(format!("rename to `{}{}{}`", &marks_p6, &stack_p5, &crate::syntax::lexer::chars::drop_prefix(&info_p4.name, &marks_p6))));
                                prism_rtl::Turn::Finished((Text::lit(""), {
                                    let mut this: crate::check::types::St = lower_levels(&st2_p9, &append(&crate::check::types::recording::free_vars(&st2_p9, &t_p2), &crate::check::types::colors::free_col_vars(&st2_p9, &t_p2)), &info_p4.level);
                                    this.tys = insert(&this.tys, &n_p1, &t_p2);
                                    this
                                }))
                            }))
                        }
                    } else {
                        prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0.clone()))
                    }
                } else {
                    call_then(crate::check::types::recording::start_free_vars(st_p0.clone(), t_p2.clone()), move |free_vars_7628: Array<Nat>| call_then(crate::check::types::colors::start_free_col_vars(st_p0.clone(), t_p2.clone()), move |free_col_vars_7646: Array<Nat>| {
                        let lowered_pa = lower_levels(&st_p0, &append(&free_vars_7628, &free_col_vars_7646), &info_p4.level);
                        prism_rtl::Turn::Finished((Text::lit(""), {
                            let mut this: crate::check::types::St = lowered_pa.clone();
                            this.tys = insert(&this.tys, &n_p1, &t_p2);
                            this
                        }))
                    }))
                }
            })
        })
    }
}

/// `Start BindVar, x`: what the function value is when passed to `@Run`.
pub fn start_bind_var(st_p0: crate::check::types::St, n_p1: Nat, t_p2: crate::check::types::Ty, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>> {
    Rc::new(BindVar { st_p0, n_p1, t_p2, span_p3 })
}

/// ```prism
/// MarksOf: fn Text -> Text
/// ```
pub fn marks_of(name_p0: &Text) -> Text {
    let c_p1 = {
        let mut this: Cursor = front(name_p0);
        while let Some((_, next_p2)) = step(&this) {
            if !is_mark_char(&crate::syntax::lexer::chars::char_at(&this)) {
                break;
            }
            this = next_p2.clone();
        }
        this
    };
    before(&c_p1)
}

/// ```prism
/// IsMarkChar: fn Text -> Bool
/// ```
pub fn is_mark_char(c_p0: &Text) -> bool {
    (((((c_p0 == &Text::lit("$")) || (c_p0 == &Text::lit("!"))) || (c_p0 == &Text::lit("@"))) || (c_p0 == &Text::lit("?"))) || (c_p0 == &Text::lit("~"))) || (c_p0 == &Text::lit("&"))
}

/// ```prism
/// LowerLevels: fn St, [Nat], Nat -> St
/// ```
pub fn lower_levels(st_p0: &crate::check::types::St, vs_p1: &Array<Nat>, level_p2: &Nat) -> crate::check::types::St {
    fold(vs_p1, st_p0, &(|s_p3: &crate::check::types::St, v_p4: &Nat| lower_one(s_p3, v_p4, level_p2)))
}

/// ```prism
/// LowerOne: fn St, Nat, Nat -> St
/// ```
pub fn lower_one(s_p0: &crate::check::types::St, v_p1: &Nat, level_p2: &Nat) -> crate::check::types::St {
    let i_p3 = crate::check::types::recording::info_of(s_p0, v_p1);
    if &i_p3.level <= level_p2 {
        s_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = s_p0.clone();
            this.infos = insert(&this.infos, v_p1, &crate::check::types::VInfo { plain: i_p3.plain, level: level_p2.clone(), name: i_p3.name.clone() });
            this
        }
    }
}

/// ```prism
/// UnifyRow: unbounded fn St, Rw, Rw, Range -> ((Text, St))
/// ```
pub fn unify_row(st_p0: &crate::check::types::St, a0_p1: &crate::check::types::Rw, b0_p2: &crate::check::types::Rw, span_p3: &crate::syntax::Range) -> (Text, crate::check::types::St) {
    let a_p4 = crate::check::types::recording::walk_row(st_p0, a0_p1);
    let b_p5 = crate::check::types::recording::walk_row(st_p0, b0_p2);
    let only_a_p6 = crate::check::types::minus_texts(&a_p4.fams, &b_p5.fams);
    let only_b_p7 = crate::check::types::minus_texts(&b_p5.fams, &a_p4.fams);
    match (a_p4.tail.clone(), b_p5.tail.clone()) {
        (crate::check::types::Tail::TlClosed, crate::check::types::Tail::TlClosed) => if (&len(&only_a_p6) == &Nat::from(0u32)) && (&len(&only_b_p7) == &Nat::from(0u32)) {
            (Text::lit(""), st_p0.clone())
        } else {
            (Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Tail::TlFlex(x_p8), crate::check::types::Tail::TlFlex(y_p9)) => if &x_p8 == &y_p9 {
            if (&len(&only_a_p6) == &Nat::from(0u32)) && (&len(&only_b_p7) == &Nat::from(0u32)) {
                (Text::lit(""), st_p0.clone())
            } else {
                (Text::lit("mismatch"), st_p0.clone())
            }
        } else {
            {
                let lacking_pa = crate::check::types::union_texts(&crate::check::types::union_texts(&lacks_of(st_p0, &x_p8), &lacks_of(st_p0, &y_p9)), &crate::check::types::union_texts(&a_p4.fams, &b_p5.fams));
                let (fresh_pb, st2_pc) = crate::check::types::recording::fresh_row(st_p0, &lacking_pa);
                let (v1_pd, st3_pe) = bind_row(&st2_pc, &x_p8, &crate::check::types::Rw { fams: only_b_p7.clone(), minus: Array::new(), tail: fresh_pb.tail.clone() }, span_p3);
                if &v1_pd != &Text::lit("") {
                    (v1_pd.clone(), st3_pe.clone())
                } else {
                    bind_row(&st3_pe, &y_p9, &crate::check::types::Rw { fams: only_a_p6.clone(), minus: Array::new(), tail: fresh_pb.tail.clone() }, span_p3)
                }
            }
        },
        (crate::check::types::Tail::TlFlex(x_pf), other_pg) => if &len(&only_a_p6) == &Nat::from(0u32) {
            bind_row(st_p0, &x_pf, &crate::check::types::Rw { fams: only_b_p7.clone(), minus: b_p5.minus.clone(), tail: other_pg }, span_p3)
        } else {
            (Text::lit("mismatch"), st_p0.clone())
        },
        (other_ph, crate::check::types::Tail::TlFlex(y_pi)) => if &len(&only_b_p7) == &Nat::from(0u32) {
            bind_row(st_p0, &y_pi, &crate::check::types::Rw { fams: only_a_p6.clone(), minus: a_p4.minus.clone(), tail: other_ph }, span_p3)
        } else {
            (Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Tail::TlRigid(x_pj), crate::check::types::Tail::TlRigid(y_pk)) => if ((&x_pj == &y_pk) && (&len(&only_a_p6) == &Nat::from(0u32))) && (&len(&only_b_p7) == &Nat::from(0u32)) {
            (Text::lit(""), st_p0.clone())
        } else {
            (Text::lit("mismatch"), st_p0.clone())
        },
        (crate::check::types::Tail::TlQ(x_pl), crate::check::types::Tail::TlQ(y_pm)) => if ((&x_pl == &y_pm) && (&len(&only_a_p6) == &Nat::from(0u32))) && (&len(&only_b_p7) == &Nat::from(0u32)) {
            (Text::lit(""), st_p0.clone())
        } else {
            (Text::lit("mismatch"), st_p0.clone())
        },
        _ => (Text::lit("mismatch"), st_p0.clone()),
    }
}

/// The step machine of `UnifyRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyRow: unbounded fn St, Rw, Rw, Range -> ((Text, St))
/// ```
pub struct UnifyRow {
    pub st_p0: crate::check::types::St,
    pub a0_p1: crate::check::types::Rw,
    pub b0_p2: crate::check::types::Rw,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(Text, crate::check::types::St)> for UnifyRow {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let a0_p1 = &self.a0_p1;
        let b0_p2 = &self.b0_p2;
        let span_p3 = &self.span_p3;
        let a0_p1 = a0_p1.clone();
        let b0_p2 = b0_p2.clone();
        let span_p3 = span_p3.clone();
        let st_p0 = st_p0.clone();
        call_then(crate::check::types::recording::start_walk_row(st_p0.clone(), a0_p1.clone()), move |walk_row_8688: crate::check::types::Rw| {
            let a_p4 = walk_row_8688;
            call_then(crate::check::types::recording::start_walk_row(st_p0.clone(), b0_p2.clone()), move |walk_row_8715: crate::check::types::Rw| {
                let b_p5 = walk_row_8715;
                let only_a_p6 = crate::check::types::minus_texts(&a_p4.fams, &b_p5.fams);
                let only_b_p7 = crate::check::types::minus_texts(&b_p5.fams, &a_p4.fams);
                match (a_p4.tail.clone(), b_p5.tail.clone()) {
                    (crate::check::types::Tail::TlClosed, crate::check::types::Tail::TlClosed) => if (&len(&only_a_p6) == &Nat::from(0u32)) && (&len(&only_b_p7) == &Nat::from(0u32)) {
                        prism_rtl::Turn::Finished((Text::lit(""), st_p0.clone()))
                    } else {
                        prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0.clone()))
                    },
                    (crate::check::types::Tail::TlFlex(x_p8), crate::check::types::Tail::TlFlex(y_p9)) => if &x_p8 == &y_p9 {
                        if (&len(&only_a_p6) == &Nat::from(0u32)) && (&len(&only_b_p7) == &Nat::from(0u32)) {
                            prism_rtl::Turn::Finished((Text::lit(""), st_p0.clone()))
                        } else {
                            prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0.clone()))
                        }
                    } else {
                        {
                            let lacking_pa = crate::check::types::union_texts(&crate::check::types::union_texts(&lacks_of(&st_p0, &x_p8), &lacks_of(&st_p0, &y_p9)), &crate::check::types::union_texts(&a_p4.fams, &b_p5.fams));
                            let (fresh_pb, st2_pc) = crate::check::types::recording::fresh_row(&st_p0, &lacking_pa);
                            call_then(start_bind_row(st2_pc.clone(), x_p8.clone(), crate::check::types::Rw { fams: only_b_p7.clone(), minus: Array::new(), tail: fresh_pb.tail.clone() }, span_p3.clone()), move |bind_row_9329: (Text, crate::check::types::St)| {
                                let (v1_pd, st3_pe) = bind_row_9329;
                                if &v1_pd != &Text::lit("") {
                                    prism_rtl::Turn::Finished((v1_pd.clone(), st3_pe.clone()))
                                } else {
                                    prism_rtl::Turn::More(Rc::new(BindRow { st_p0: st3_pe.clone(), n_p1: y_p9.clone(), rw_p2: crate::check::types::Rw { fams: only_a_p6.clone(), minus: Array::new(), tail: fresh_pb.tail.clone() }, span_p3: span_p3.clone() }))
                                }
                            })
                        }
                    },
                    (crate::check::types::Tail::TlFlex(x_pf), other_pg) => if &len(&only_a_p6) == &Nat::from(0u32) {
                        prism_rtl::Turn::More(Rc::new(BindRow { st_p0: st_p0.clone(), n_p1: x_pf.clone(), rw_p2: crate::check::types::Rw { fams: only_b_p7.clone(), minus: b_p5.minus.clone(), tail: other_pg.clone() }, span_p3: span_p3.clone() }))
                    } else {
                        prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0.clone()))
                    },
                    (other_ph, crate::check::types::Tail::TlFlex(y_pi)) => if &len(&only_b_p7) == &Nat::from(0u32) {
                        prism_rtl::Turn::More(Rc::new(BindRow { st_p0: st_p0.clone(), n_p1: y_pi.clone(), rw_p2: crate::check::types::Rw { fams: only_a_p6.clone(), minus: a_p4.minus.clone(), tail: other_ph.clone() }, span_p3: span_p3.clone() }))
                    } else {
                        prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0.clone()))
                    },
                    (crate::check::types::Tail::TlRigid(x_pj), crate::check::types::Tail::TlRigid(y_pk)) => if ((&x_pj == &y_pk) && (&len(&only_a_p6) == &Nat::from(0u32))) && (&len(&only_b_p7) == &Nat::from(0u32)) {
                        prism_rtl::Turn::Finished((Text::lit(""), st_p0.clone()))
                    } else {
                        prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0.clone()))
                    },
                    (crate::check::types::Tail::TlQ(x_pl), crate::check::types::Tail::TlQ(y_pm)) => if ((&x_pl == &y_pm) && (&len(&only_a_p6) == &Nat::from(0u32))) && (&len(&only_b_p7) == &Nat::from(0u32)) {
                        prism_rtl::Turn::Finished((Text::lit(""), st_p0.clone()))
                    } else {
                        prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0.clone()))
                    },
                    _ => prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0.clone())),
                }
            })
        })
    }
}

/// `Start UnifyRow, x`: what the function value is when passed to `@Run`.
pub fn start_unify_row(st_p0: crate::check::types::St, a0_p1: crate::check::types::Rw, b0_p2: crate::check::types::Rw, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>> {
    Rc::new(UnifyRow { st_p0, a0_p1, b0_p2, span_p3 })
}

/// ```prism
/// AskField: fn St, Ty, Text, Ty, Range, [Text] -> St
/// ```
pub fn ask_field(st_p0: &crate::check::types::St, recv_p1: &crate::check::types::Ty, field_p2: &Text, result_p3: &crate::check::types::Ty, span_p4: &crate::syntax::Range, owners_p5: &Array<Text>) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.field_qs = push(&this.field_qs, &FieldQ { recv: recv_p1.clone(), field: field_p2.clone(), result: result_p3.clone(), span: span_p4.clone(), file: this.file.clone(), owners: owners_p5.clone() });
    this
}

/// ```prism
/// AskLayer: fn St, Ty, Range, Text -> St
/// ```
pub fn ask_layer(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty, span_p2: &crate::syntax::Range, fname_p3: &Text) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.layer_qs = push(&this.layer_qs, &(t_p1.clone(), span_p2.clone(), fname_p3.clone()));
    this
}

/// ```prism
/// LayerQuestions: unbounded fn St -> St
/// ```
pub fn layer_questions(st_p0: &crate::check::types::St) -> crate::check::types::St {
    let qs_p1 = st_p0.layer_qs.clone();
    let cleared_p2 = {
        let mut this: crate::check::types::St = st_p0.clone();
        this.layer_qs = Array::new();
        this
    };
    run_to_end(fold_job(qs_p1.clone(), cleared_p2.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, (crate::check::types::Ty, crate::syntax::Range, Text))| entered(once_job(move || {
        let s_p3 = p0;
        let (t_p4, span_p5, fname_p6) = p1;
        call_then(crate::check::types::start_head_sigil(s_p3.clone(), t_p4.clone()), move |head_sigil_11312: Text| {
            let h_p7 = head_sigil_11312;
            call_then(crate::check::types::start_is_free_headed(s_p3.clone(), t_p4.clone()), move |is_free_headed_11339: bool| if (is_free_headed_11339 || (&h_p7 == &Text::lit("$"))) || (&h_p7 == &Text::lit("!")) {
                prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&s_p3, &Text::lit("layer-unknown"), &span_p5, &Text::from(format!("the layer of this argument to `{}` is not known here", &fname_p6)), &Text::lit("say it where the value is made: a name whose marks declare the layer (`let $x = ...`), `<<T>>` at the application that made it, or a signature on the enclosing `let`")))
            } else {
                prism_rtl::Turn::Finished(s_p3.clone())
            })
        })
    }))) as Rc<dyn Fn((crate::check::types::St, (crate::check::types::Ty, crate::syntax::Range, Text))) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>))
}

/// The step machine of `LayerQuestions`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LayerQuestions: unbounded fn St -> St
/// ```
pub struct LayerQuestions {
    pub st_p0: crate::check::types::St,
}

impl prism_rtl::Job<crate::check::types::St> for LayerQuestions {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let qs_p1 = st_p0.layer_qs.clone();
        let cleared_p2 = {
            let mut this: crate::check::types::St = st_p0.clone();
            this.layer_qs = Array::new();
            this
        };
        fold_job(qs_p1.clone(), cleared_p2.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, (crate::check::types::Ty, crate::syntax::Range, Text))| entered(once_job(move || {
            let s_p3 = p0;
            let (t_p4, span_p5, fname_p6) = p1;
            call_then(crate::check::types::start_head_sigil(s_p3.clone(), t_p4.clone()), move |head_sigil_11312: Text| {
                let h_p7 = head_sigil_11312;
                call_then(crate::check::types::start_is_free_headed(s_p3.clone(), t_p4.clone()), move |is_free_headed_11339: bool| if (is_free_headed_11339 || (&h_p7 == &Text::lit("$"))) || (&h_p7 == &Text::lit("!")) {
                    prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&s_p3, &Text::lit("layer-unknown"), &span_p5, &Text::from(format!("the layer of this argument to `{}` is not known here", &fname_p6)), &Text::lit("say it where the value is made: a name whose marks declare the layer (`let $x = ...`), `<<T>>` at the application that made it, or a signature on the enclosing `let`")))
                } else {
                    prism_rtl::Turn::Finished(s_p3.clone())
                })
            })
        }))) as Rc<dyn Fn((crate::check::types::St, (crate::check::types::Ty, crate::syntax::Range, Text))) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>).cycle()
    }
}

/// `Start LayerQuestions, x`: what the function value is when passed to `@Run`.
pub fn start_layer_questions(st_p0: crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(LayerQuestions { st_p0 })
}

/// ```prism
/// NameRow: fn St, Tail, Text -> St
/// ```
pub fn name_row(st_p0: &crate::check::types::St, tail1: &crate::check::types::Tail, text2: &Text) -> crate::check::types::St {
    match (tail1, text2) {
        (crate::check::types::Tail::TlFlex(n_p1), q_p2) => {
            let mut this: crate::check::types::St = st_p0.clone();
            this.row_names = insert(&this.row_names, n_p1, q_p2);
            this
        },
        (_, _) => st_p0.clone(),
    }
}

/// ```prism
/// RowName: fn St, Nat -> Text
/// ```
pub fn row_name(st_p0: &crate::check::types::St, n_p1: &Nat) -> Text {
    or(&get(&st_p0.row_names, n_p1), &Text::from(format!("r{}", n_p1)))
}

/// ```prism
/// LacksOf: fn St, Nat -> [Text]
/// ```
pub fn lacks_of(st_p0: &crate::check::types::St, n_p1: &Nat) -> Array<Text> {
    or(&get(&st_p0.lacks, n_p1), &Array::new())
}

/// ```prism
/// BindRow: unbounded fn St, Nat, Rw, Range -> ((Text, St))
/// ```
pub fn bind_row(st_p0: &crate::check::types::St, n_p1: &Nat, rw_p2: &crate::check::types::Rw, span_p3: &crate::syntax::Range) -> (Text, crate::check::types::St) {
    let bad_p4 = crate::check::types::inter_texts(&lacks_of(st_p0, n_p1), &rw_p2.fams);
    if &len(&bad_p4) > &Nat::from(0u32) {
        {
            let fam_p5 = or(&index(&bad_p4, &Nat::from(0u32)), &Text::lit(""));
            (Text::lit("reported"), crate::check::types::recording::err_fix(st_p0, &Text::lit("row-lacks"), span_p3, &Text::from(format!("`{} | {}.*` promises `{}` has no `{}` tags", &row_name(st_p0, n_p1), &fam_p5, &row_name(st_p0, n_p1), &fam_p5)), &Text::from(format!("answer the `{}` tags before this point, or widen the row", &fam_p5))))
        }
    } else {
        {
            let st2_p6 = match &rw_p2.tail {
                crate::check::types::Tail::TlFlex(m_p7) => {
                    let mut this: crate::check::types::St = st_p0.clone();
                    this.lacks = insert(&this.lacks, m_p7, &crate::check::types::union_texts(&lacks_of(st_p0, m_p7), &lacks_of(st_p0, n_p1)));
                    this
                },
                _ => st_p0.clone(),
            };
            (Text::lit(""), {
                let mut this: crate::check::types::St = st2_p6.clone();
                this.rows = insert(&this.rows, n_p1, rw_p2);
                this
            })
        }
    }
}

/// The step machine of `BindRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindRow: unbounded fn St, Nat, Rw, Range -> ((Text, St))
/// ```
pub struct BindRow {
    pub st_p0: crate::check::types::St,
    pub n_p1: Nat,
    pub rw_p2: crate::check::types::Rw,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<(Text, crate::check::types::St)> for BindRow {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let n_p1 = &self.n_p1;
        let rw_p2 = &self.rw_p2;
        let span_p3 = &self.span_p3;
        let bad_p4 = crate::check::types::inter_texts(&lacks_of(st_p0, n_p1), &rw_p2.fams);
        if &len(&bad_p4) > &Nat::from(0u32) {
            {
                let fam_p5 = or(&index(&bad_p4, &Nat::from(0u32)), &Text::lit(""));
                prism_rtl::Turn::Finished((Text::lit("reported"), crate::check::types::recording::err_fix(st_p0, &Text::lit("row-lacks"), span_p3, &Text::from(format!("`{} | {}.*` promises `{}` has no `{}` tags", &row_name(st_p0, n_p1), &fam_p5, &row_name(st_p0, n_p1), &fam_p5)), &Text::from(format!("answer the `{}` tags before this point, or widen the row", &fam_p5)))))
            }
        } else {
            {
                let st2_p6 = match &rw_p2.tail {
                    crate::check::types::Tail::TlFlex(m_p7) => {
                        let mut this: crate::check::types::St = st_p0.clone();
                        this.lacks = insert(&this.lacks, m_p7, &crate::check::types::union_texts(&lacks_of(st_p0, m_p7), &lacks_of(st_p0, n_p1)));
                        this
                    },
                    _ => st_p0.clone(),
                };
                prism_rtl::Turn::Finished((Text::lit(""), {
                    let mut this: crate::check::types::St = st2_p6.clone();
                    this.rows = insert(&this.rows, n_p1, rw_p2);
                    this
                }))
            }
        }
    }
}

/// `Start BindRow, x`: what the function value is when passed to `@Run`.
pub fn start_bind_row(st_p0: crate::check::types::St, n_p1: Nat, rw_p2: crate::check::types::Rw, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>> {
    Rc::new(BindRow { st_p0, n_p1, rw_p2, span_p3 })
}
