//! The module `Check.Types.Unify`, from `target/bootstrap/src/prismc/check/types/unify.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `FieldQ`:
///
/// ```prism
/// type FieldQ = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct FieldQ {
    pub recv: crate::check::types::Ty,
    pub field: Text,
    pub result: crate::check::types::Ty,
    pub span: crate::syntax::Range,
    pub file: Nat,
    pub owners: Array<Text>,
}

impl Show for FieldQ {
    fn show(&self, p: &mut Printer) {
        p.record("FieldQ", &[("recv", &self.recv), ("field", &self.field), ("result", &self.result), ("span", &self.span), ("file", &self.file), ("owners", &self.owners)]);
    }
}

impl ToPod for FieldQ {
    fn to_pod(&self) -> Pod {
        Pod::record("FieldQ", vec![("recv", self.recv.to_pod()), ("field", self.field.to_pod()), ("result", self.result.to_pod()), ("span", self.span.to_pod()), ("file", self.file.to_pod()), ("owners", self.owners.to_pod())])
    }
}

impl FromPod for FieldQ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(FieldQ { recv: FromPod::from_pod(field(p, "recv")?)?, field: FromPod::from_pod(field(p, "field")?)?, result: FromPod::from_pod(field(p, "result")?)?, span: FromPod::from_pod(field(p, "span")?)?, file: FromPod::from_pod(field(p, "file")?)?, owners: FromPod::from_pod(field(p, "owners")?)? })
    }
}

/// ```prism
/// Unify: unbounded fn St, Ty, Ty, Range -> St
/// ```
pub fn unify(st: &crate::check::types::St, expected: &crate::check::types::Ty, found: &crate::check::types::Ty, span: &crate::syntax::Range) -> crate::check::types::St {
    let (verdict, st2) = unify_in(st, expected, found, span);
    if &verdict == &Text::lit("mismatch") {
        {
            let e = crate::check::types::show_ty(&st2, expected);
            let f = crate::check::types::show_ty(&st2, found);
            if &e == &f {
                crate::check::types::recording::err(&st2, &Text::lit("mismatch"), span, &Text::from(format!("expected `{}`, found `{}`", &show_ty_q(&st2, expected), &show_ty_q(&st2, found))))
            } else {
                crate::check::types::recording::err(&st2, &Text::lit("mismatch"), span, &Text::from(format!("expected `{}`, found `{}`", &e, &f)))
            }
        }
    } else {
        st2.clone()
    }
}

/// The step machine of `Unify`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Unify: unbounded fn St, Ty, Ty, Range -> St
/// ```
pub struct Unify {
    pub st: crate::check::types::St,
    pub expected: crate::check::types::Ty,
    pub found: crate::check::types::Ty,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for Unify {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st = &self.st;
        let expected = &self.expected;
        let found = &self.found;
        let span = &self.span;
        let expected = expected.clone();
        let found = found.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(start_unify_in(st.clone(), expected.clone(), found.clone(), span.clone()), move |unify_in_1030: (Text, crate::check::types::St)| {
            let (verdict, st2) = unify_in_1030;
            if &verdict == &Text::lit("mismatch") {
                call_then(crate::check::types::start_show_ty(st2.clone(), expected.clone()), move |show_ty_1110: Text| {
                    let e = show_ty_1110;
                    call_then(crate::check::types::start_show_ty(st2.clone(), found.clone()), move |show_ty_1147: Text| {
                        let f = show_ty_1147;
                        if &e == &f {
                            call_then(start_show_ty_q(st2.clone(), expected.clone()), move |show_ty_q_1223: Text| call_then(start_show_ty_q(st2.clone(), found.clone()), move |show_ty_q_1256: Text| prism_rtl::Turn::Finished(crate::check::types::recording::err(&st2, &Text::lit("mismatch"), &span, &Text::from(format!("expected `{}`, found `{}`", &show_ty_q_1223, &show_ty_q_1256))))))
                        } else {
                            prism_rtl::Turn::Finished(crate::check::types::recording::err(&st2, &Text::lit("mismatch"), &span, &Text::from(format!("expected `{}`, found `{}`", &e, &f))))
                        }
                    })
                })
            } else {
                prism_rtl::Turn::Finished(st2.clone())
            }
        })
    }
}

/// `Start Unify, x`: what the function value is when passed to `@Run`.
pub fn start_unify(st: crate::check::types::St, expected: crate::check::types::Ty, found: crate::check::types::Ty, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(Unify { st, expected, found, span })
}

/// ```prism
/// ShowTyQ: unbounded fn St, Ty -> Text
/// ```
pub fn show_ty_q(st: &crate::check::types::St, t: &crate::check::types::Ty) -> Text {
    match crate::check::types::recording::zonk(st, t) {
        crate::check::types::Ty::TyCon(n, m1487_0_1) if ((&m1487_0_1).len() == 0) => n.clone(),
        crate::check::types::Ty::TyCon(n, args) => Text::from(format!("({}{})", &n, &concat(&run_to_end(each_job(args.clone(), {
            let st = st.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let st = st.clone();
                entered(once_job(move || {
                    let a = p0;
                    call_then(start_show_ty_q(st.clone(), a.clone()), move |show_ty_q_1578: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &show_ty_q_1578))))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>
        }))))),
        crate::check::types::Ty::TySig(s, i) => Text::from(format!("{}{}", &s, &show_ty_q(st, &*i))),
        crate::check::types::Ty::TyArray(e) => {
            let inner = show_ty_q(st, &*e);
            if crate::syntax::lexer::chars::has_prefix(&inner, &Text::lit("[")) {
                Text::from(format!("[ {} ]", &inner))
            } else {
                Text::from(format!("[{}]", &inner))
            }
        },
        crate::check::types::Ty::TyMap(k, v_) => Text::from(format!("({} ==> {})", &show_ty_q(st, &*k), &show_ty_q(st, &*v_))),
        crate::check::types::Ty::TyAt(i, rw) => Text::from(format!("@{} emit {}", &show_ty_q(st, &*i), &crate::check::types::show_row_in(&rw, &true))),
        other => crate::check::types::show_ty(st, &other),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ShowTyQ`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowTyQ: unbounded fn St, Ty -> Text
/// ```
pub struct ShowTyQ {
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<Text> for ShowTyQ {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let st = &self.st;
        let t = &self.t;
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::recording::start_zonk(st.clone(), t.clone()), move |zonk_1493: crate::check::types::Ty| match zonk_1493 {
            crate::check::types::Ty::TyCon(n, m1487_0_1) if ((&m1487_0_1).len() == 0) => prism_rtl::Turn::Finished(n.clone()),
            crate::check::types::Ty::TyCon(n, args) => call_value(each_job(args.clone(), {
                let st = st.clone();
                Rc::new(move |p0: crate::check::types::Ty| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let a = p0;
                        call_then(start_show_ty_q(st.clone(), a.clone()), move |show_ty_q_1578: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &show_ty_q_1578))))
                    }))
                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_1559: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("({}{})", &n, &concat(&each_1559))))),
            crate::check::types::Ty::TySig(s, i) => call_then(start_show_ty_q(st.clone(), (*i).clone()), move |show_ty_q_1619: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &s, &show_ty_q_1619)))),
            crate::check::types::Ty::TyArray(e) => call_then(start_show_ty_q(st.clone(), (*e).clone()), move |show_ty_q_1670: Text| {
                let inner = show_ty_q_1670;
                if crate::syntax::lexer::chars::has_prefix(&inner, &Text::lit("[")) {
                    prism_rtl::Turn::Finished(Text::from(format!("[ {} ]", &inner)))
                } else {
                    prism_rtl::Turn::Finished(Text::from(format!("[{}]", &inner)))
                }
            }),
            crate::check::types::Ty::TyMap(k, v_) => call_then(start_show_ty_q(st.clone(), (*k).clone()), move |show_ty_q_1770: Text| call_then(start_show_ty_q(st.clone(), (*v_).clone()), move |show_ty_q_1790: Text| prism_rtl::Turn::Finished(Text::from(format!("({} ==> {})", &show_ty_q_1770, &show_ty_q_1790))))),
            crate::check::types::Ty::TyAt(i, rw) => call_then(start_show_ty_q(st.clone(), (*i).clone()), move |show_ty_q_1826: Text| prism_rtl::Turn::Finished(Text::from(format!("@{} emit {}", &show_ty_q_1826, &crate::check::types::show_row_in(&rw, &true))))),
            other => prism_rtl::Turn::More(Rc::new(crate::check::types::ShowTy { st: st.clone(), t: other.clone() })),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start ShowTyQ, x`: what the function value is when passed to `@Run`.
pub fn start_show_ty_q(st: crate::check::types::St, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ShowTyQ { st, t })
}

/// ```prism
/// TryUnify: unbounded fn St, Ty, Ty, Range -> ((Bool, St))
/// ```
pub fn try_unify(st: &crate::check::types::St, expected: &crate::check::types::Ty, found: &crate::check::types::Ty, span: &crate::syntax::Range) -> (bool, crate::check::types::St) {
    let (verdict, st2) = unify_in(st, expected, found, span);
    (&verdict == &Text::lit(""), st2.clone())
}

/// The step machine of `TryUnify`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TryUnify: unbounded fn St, Ty, Ty, Range -> ((Bool, St))
/// ```
pub struct TryUnify {
    pub st: crate::check::types::St,
    pub expected: crate::check::types::Ty,
    pub found: crate::check::types::Ty,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(bool, crate::check::types::St)> for TryUnify {
    fn cycle(&self) -> prism_rtl::Turn<(bool, crate::check::types::St)> {
        let st = &self.st;
        let expected = &self.expected;
        let found = &self.found;
        let span = &self.span;
        let expected = expected.clone();
        let found = found.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(start_unify_in(st.clone(), expected.clone(), found.clone(), span.clone()), move |unify_in_2156: (Text, crate::check::types::St)| {
            let (verdict, st2) = unify_in_2156;
            prism_rtl::Turn::Finished((&verdict == &Text::lit(""), st2.clone()))
        })
    }
}

/// `Start TryUnify, x`: what the function value is when passed to `@Run`.
pub fn start_try_unify(st: crate::check::types::St, expected: crate::check::types::Ty, found: crate::check::types::Ty, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(bool, crate::check::types::St)>> {
    Rc::new(TryUnify { st, expected, found, span })
}

/// ```prism
/// UnifyIn: unbounded fn St, Ty, Ty, Range -> ((Text, St))
/// ```
pub fn unify_in(st: &crate::check::types::St, expected: &crate::check::types::Ty, found: &crate::check::types::Ty, span: &crate::syntax::Range) -> (Text, crate::check::types::St) {
    let e = norm_assoc(st, &crate::check::types::recording::walk(st, expected));
    let f = norm_assoc(st, &crate::check::types::recording::walk(st, found));
    if is_waiting_assoc(st, &e) || is_waiting_assoc(st, &f) {
        if &e == &f {
            (Text::lit(""), st.clone())
        } else {
            (Text::lit(""), defer(st, &e, &f, span))
        }
    } else {
        unify_heads(st, &e, &f, span)
    }
}

/// The step machine of `UnifyIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyIn: unbounded fn St, Ty, Ty, Range -> ((Text, St))
/// ```
pub struct UnifyIn {
    pub st: crate::check::types::St,
    pub expected: crate::check::types::Ty,
    pub found: crate::check::types::Ty,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(Text, crate::check::types::St)> for UnifyIn {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::check::types::St)> {
        let st = &self.st;
        let expected = &self.expected;
        let found = &self.found;
        let span = &self.span;
        let expected = expected.clone();
        let found = found.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(crate::check::types::recording::start_walk(st.clone(), expected.clone()), move |walk_2446: crate::check::types::Ty| call_then(start_norm_assoc(st.clone(), walk_2446), move |norm_assoc_2431: crate::check::types::Ty| {
            let e = norm_assoc_2431;
            call_then(crate::check::types::recording::start_walk(st.clone(), found.clone()), move |walk_2492: crate::check::types::Ty| call_then(start_norm_assoc(st.clone(), walk_2492), move |norm_assoc_2477: crate::check::types::Ty| {
                let f = norm_assoc_2477;
                call_then(start_is_waiting_assoc(st.clone(), e.clone()), move |is_waiting_assoc_2516: bool| if is_waiting_assoc_2516 || is_waiting_assoc(&st, &f) {
                    if &e == &f {
                        prism_rtl::Turn::Finished((Text::lit(""), st.clone()))
                    } else {
                        prism_rtl::Turn::Finished((Text::lit(""), defer(&st, &e, &f, &span)))
                    }
                } else {
                    prism_rtl::Turn::More(Rc::new(UnifyHeads { st: st.clone(), e: e.clone(), f: f.clone(), span: span.clone() }))
                })
            }))
        }))
    }
}

/// `Start UnifyIn, x`: what the function value is when passed to `@Run`.
pub fn start_unify_in(st: crate::check::types::St, expected: crate::check::types::Ty, found: crate::check::types::Ty, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>> {
    Rc::new(UnifyIn { st, expected, found, span })
}

/// ```prism
/// NormAssoc: unbounded fn St, Ty -> Ty
/// ```
pub fn norm_assoc(st: &crate::check::types::St, t: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t {
        crate::check::types::Ty::TyAssoc(m2934_0_0, a) if (m2934_0_0 == &Text::lit("Quotient")) => match crate::check::types::recording::walk(st, &**a) {
            crate::check::types::Ty::TyCon(m2970_0_0, m2970_0_1) if (&m2970_0_0 == &Text::lit("Float")) && ((&m2970_0_1).len() == 0) => crate::check::types::t_float(),
            crate::check::types::Ty::TyCon(n, m2970_1_1) if ((&m2970_1_1).len() == 0) => if ((&n == &Text::lit("Nat")) || (&n == &Text::lit("Int"))) || (&n == &Text::lit("U8")) {
                crate::check::types::Ty::TySig(Text::lit("?"), Rc::new(crate::check::types::Ty::TyCon(n.clone(), Array::new())))
            } else {
                t.clone()
            },
            _ => t.clone(),
            _ => unreachable!("no arm matched"),
        },
        other => other.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `NormAssoc`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NormAssoc: unbounded fn St, Ty -> Ty
/// ```
pub struct NormAssoc {
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::Ty> for NormAssoc {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let st = &self.st;
        let t = &self.t;
        match t {
            crate::check::types::Ty::TyAssoc(m2934_0_0, a) if (m2934_0_0 == &Text::lit("Quotient")) => {
                let a = (**a).clone();
                let st = st.clone();
                let t = t.clone();
                call_then(crate::check::types::recording::start_walk(st.clone(), a.clone()), move |walk_2976: crate::check::types::Ty| match walk_2976 {
                    crate::check::types::Ty::TyCon(m2970_0_0, m2970_0_1) if (&m2970_0_0 == &Text::lit("Float")) && ((&m2970_0_1).len() == 0) => prism_rtl::Turn::Finished(crate::check::types::t_float()),
                    crate::check::types::Ty::TyCon(n, m2970_1_1) if ((&m2970_1_1).len() == 0) => if ((&n == &Text::lit("Nat")) || (&n == &Text::lit("Int"))) || (&n == &Text::lit("U8")) {
                        prism_rtl::Turn::Finished(crate::check::types::Ty::TySig(Text::lit("?"), Rc::new(crate::check::types::Ty::TyCon(n.clone(), Array::new()))))
                    } else {
                        prism_rtl::Turn::Finished(t.clone())
                    },
                    _ => prism_rtl::Turn::Finished(t.clone()),
                    _ => unreachable!("no arm matched"),
                })
            },
            other => prism_rtl::Turn::Finished(other.clone()),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start NormAssoc, x`: what the function value is when passed to `@Run`.
pub fn start_norm_assoc(st: crate::check::types::St, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(NormAssoc { st, t })
}

/// ```prism
/// IsWaitingAssoc: unbounded fn St, Ty -> Bool
/// ```
pub fn is_waiting_assoc(st: &crate::check::types::St, t: &crate::check::types::Ty) -> bool {
    match t {
        crate::check::types::Ty::TyAssoc(_, a) => crate::check::types::is_flex_var(st, &**a),
        _ => false,
    }
}

/// The step machine of `IsWaitingAssoc`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsWaitingAssoc: unbounded fn St, Ty -> Bool
/// ```
pub struct IsWaitingAssoc {
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<bool> for IsWaitingAssoc {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let st = &self.st;
        let t = &self.t;
        match t {
            crate::check::types::Ty::TyAssoc(_, a) => prism_rtl::Turn::More(Rc::new(crate::check::types::IsFlexVar { st: st.clone(), t: (**a).clone() })),
            _ => prism_rtl::Turn::Finished(false),
        }
    }
}

/// `Start IsWaitingAssoc, x`: what the function value is when passed to `@Run`.
pub fn start_is_waiting_assoc(st: crate::check::types::St, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsWaitingAssoc { st, t })
}

/// ```prism
/// Defer: fn St, Ty, Ty, Range -> St
/// ```
pub fn defer(st: &crate::check::types::St, e: &crate::check::types::Ty, f: &crate::check::types::Ty, span: &crate::syntax::Range) -> crate::check::types::St {
    let mut this: crate::check::types::St = st.clone();
    this.deferred = push(&this.deferred, &(e.clone(), f.clone(), span.clone()));
    this
}

/// ```prism
/// RetryDeferred: unbounded fn St -> St
/// ```
pub fn retry_deferred(st: &crate::check::types::St) -> crate::check::types::St {
    let waiting = st.deferred.clone();
    let cleared = {
        let mut this: crate::check::types::St = st.clone();
        this.deferred = Array::new();
        this
    };
    run_to_end(fold_job(waiting.clone(), cleared.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, (crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range))| entered(once_job(move || {
        let s = p0;
        let (e, f, span) = p1;
        prism_rtl::Turn::More(Rc::new(Unify { st: s.clone(), expected: e.clone(), found: f.clone(), span: span.clone() }))
    }))) as Rc<dyn Fn((crate::check::types::St, (crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range))) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>))
}

/// The step machine of `RetryDeferred`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RetryDeferred: unbounded fn St -> St
/// ```
pub struct RetryDeferred {
    pub st: crate::check::types::St,
}

impl prism_rtl::Job<crate::check::types::St> for RetryDeferred {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st = &self.st;
        let waiting = st.deferred.clone();
        let cleared = {
            let mut this: crate::check::types::St = st.clone();
            this.deferred = Array::new();
            this
        };
        fold_job(waiting.clone(), cleared.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, (crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range))| entered(once_job(move || {
            let s = p0;
            let (e, f, span) = p1;
            prism_rtl::Turn::More(Rc::new(Unify { st: s.clone(), expected: e.clone(), found: f.clone(), span: span.clone() }))
        }))) as Rc<dyn Fn((crate::check::types::St, (crate::check::types::Ty, crate::check::types::Ty, crate::syntax::Range))) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>).cycle()
    }
}

/// `Start RetryDeferred, x`: what the function value is when passed to `@Run`.
pub fn start_retry_deferred(st: crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(RetryDeferred { st })
}

/// ```prism
/// UnifyHeads: unbounded fn St, Ty, Ty, Range -> ((Text, St))
/// ```
pub fn unify_heads(st: &crate::check::types::St, e: &crate::check::types::Ty, f: &crate::check::types::Ty, span: &crate::syntax::Range) -> (Text, crate::check::types::St) {
    match (e.clone(), f.clone()) {
        (crate::check::types::Ty::TyErr, _) => (Text::lit(""), st.clone()),
        (_, crate::check::types::Ty::TyErr) => (Text::lit(""), st.clone()),
        (crate::check::types::Ty::TySig(m3799_2_0_0, _), crate::check::types::Ty::TyCon(m3799_2_1_0, m3799_2_1_1)) if (&m3799_2_0_0 == &Text::lit("~")) && (&m3799_2_1_0 == &Text::lit("Prelude.Error")) && ((&m3799_2_1_1).len() == 0) => (Text::lit(""), st.clone()),
        (crate::check::types::Ty::TyCon(m3799_3_0_0, m3799_3_0_1), crate::check::types::Ty::TySig(m3799_3_1_0, _)) if (&m3799_3_0_0 == &Text::lit("Prelude.Error")) && ((&m3799_3_0_1).len() == 0) && (&m3799_3_1_0 == &Text::lit("~")) => (Text::lit(""), st.clone()),
        (crate::check::types::Ty::TyFlex(a), crate::check::types::Ty::TyFlex(b)) => if &a == &b {
            (Text::lit(""), st.clone())
        } else {
            (Text::lit(""), merge_vars(st, &a, &b))
        },
        (crate::check::types::Ty::TyFlex(a), t) => bind_var(st, &a, &t, span),
        (t, crate::check::types::Ty::TyFlex(b)) => bind_var(st, &b, &t, span),
        (crate::check::types::Ty::TyRigid(a), crate::check::types::Ty::TyRigid(b)) => if &a == &b {
            (Text::lit(""), st.clone())
        } else {
            (Text::lit("mismatch"), st.clone())
        },
        (crate::check::types::Ty::TyQ(a), crate::check::types::Ty::TyQ(b)) => if &a == &b {
            (Text::lit(""), st.clone())
        } else {
            (Text::lit("mismatch"), st.clone())
        },
        (crate::check::types::Ty::TyCon(a, xs), crate::check::types::Ty::TyCon(b, ys)) => if (&a == &b) && (&len(&xs) == &len(&ys)) {
            unify_all(st, &xs, &ys, span)
        } else {
            (Text::lit("mismatch"), st.clone())
        },
        (crate::check::types::Ty::TyFn(c1, ps, r1), crate::check::types::Ty::TyFn(c2, qs, r2)) => if &len(&ps) == &len(&qs) {
            {
                let (v_, st2) = crate::check::types::colors::unify_col(st, &c1, &c2);
                if &v_ != &Text::lit("") {
                    (v_.clone(), st2.clone())
                } else {
                    unify_all(&st2, &push(&ps, &*r1), &push(&qs, &*r2), span)
                }
            }
        } else {
            (Text::lit("mismatch"), st.clone())
        },
        (crate::check::types::Ty::TyTuple(xs), crate::check::types::Ty::TyTuple(ys)) => if &len(&xs) == &len(&ys) {
            unify_all(st, &xs, &ys, span)
        } else {
            (Text::lit("mismatch"), st.clone())
        },
        (crate::check::types::Ty::TyArray(x), crate::check::types::Ty::TyArray(y)) => unify_in(st, &*x, &*y, span),
        (crate::check::types::Ty::TyMap(k1, v1), crate::check::types::Ty::TyMap(k2, v2)) => unify_all(st, &Array::from(vec![(*k1).clone(), (*v1).clone()]), &Array::from(vec![(*k2).clone(), (*v2).clone()]), span),
        (crate::check::types::Ty::TySig(s1, i1), crate::check::types::Ty::TySig(s2, i2)) => if &s1 == &s2 {
            unify_in(st, &*i1, &*i2, span)
        } else {
            (Text::lit("mismatch"), st.clone())
        },
        (crate::check::types::Ty::TyAt(i1, r1), crate::check::types::Ty::TyAt(i2, r2)) => {
            let (v_, st2) = unify_in(st, &*i1, &*i2, span);
            if &v_ != &Text::lit("") {
                (v_.clone(), st2.clone())
            } else {
                unify_row(&st2, &r1, &r2, span)
            }
        },
        (crate::check::types::Ty::TyElem(r1, o1), crate::check::types::Ty::TyElem(r2, o2)) => {
            let (v_, st2) = unify_row(st, &r1, &r2, span);
            if &v_ != &Text::lit("") {
                (v_.clone(), st2.clone())
            } else {
                unify_in(&st2, &*o1, &*o2, span)
            }
        },
        (crate::check::types::Ty::TyElemAny(r1), crate::check::types::Ty::TyElemAny(r2)) => unify_row(st, &r1, &r2, span),
        (crate::check::types::Ty::TyAssoc(n1, a1), crate::check::types::Ty::TyAssoc(n2, a2)) => if &n1 == &n2 {
            unify_in(st, &*a1, &*a2, span)
        } else {
            (Text::lit("mismatch"), st.clone())
        },
        (crate::check::types::Ty::TyAny(xs), crate::check::types::Ty::TyAny(ys)) => if &crate::check::types::sort_texts(&xs) == &crate::check::types::sort_texts(&ys) {
            (Text::lit(""), st.clone())
        } else {
            (Text::lit("mismatch"), st.clone())
        },
        _ => (Text::lit("mismatch"), st.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `UnifyHeads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyHeads: unbounded fn St, Ty, Ty, Range -> ((Text, St))
/// ```
pub struct UnifyHeads {
    pub st: crate::check::types::St,
    pub e: crate::check::types::Ty,
    pub f: crate::check::types::Ty,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(Text, crate::check::types::St)> for UnifyHeads {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::check::types::St)> {
        let st = &self.st;
        let e = &self.e;
        let f = &self.f;
        let span = &self.span;
        match (e.clone(), f.clone()) {
            (crate::check::types::Ty::TyErr, _) => prism_rtl::Turn::Finished((Text::lit(""), st.clone())),
            (_, crate::check::types::Ty::TyErr) => prism_rtl::Turn::Finished((Text::lit(""), st.clone())),
            (crate::check::types::Ty::TySig(m3799_2_0_0, _), crate::check::types::Ty::TyCon(m3799_2_1_0, m3799_2_1_1)) if (&m3799_2_0_0 == &Text::lit("~")) && (&m3799_2_1_0 == &Text::lit("Prelude.Error")) && ((&m3799_2_1_1).len() == 0) => prism_rtl::Turn::Finished((Text::lit(""), st.clone())),
            (crate::check::types::Ty::TyCon(m3799_3_0_0, m3799_3_0_1), crate::check::types::Ty::TySig(m3799_3_1_0, _)) if (&m3799_3_0_0 == &Text::lit("Prelude.Error")) && ((&m3799_3_0_1).len() == 0) && (&m3799_3_1_0 == &Text::lit("~")) => prism_rtl::Turn::Finished((Text::lit(""), st.clone())),
            (crate::check::types::Ty::TyFlex(a), crate::check::types::Ty::TyFlex(b)) => if &a == &b {
                prism_rtl::Turn::Finished((Text::lit(""), st.clone()))
            } else {
                prism_rtl::Turn::Finished((Text::lit(""), merge_vars(st, &a, &b)))
            },
            (crate::check::types::Ty::TyFlex(a), t) => prism_rtl::Turn::More(Rc::new(BindVar { st: st.clone(), n: a.clone(), t: t.clone(), span: span.clone() })),
            (t, crate::check::types::Ty::TyFlex(b)) => prism_rtl::Turn::More(Rc::new(BindVar { st: st.clone(), n: b.clone(), t: t.clone(), span: span.clone() })),
            (crate::check::types::Ty::TyRigid(a), crate::check::types::Ty::TyRigid(b)) => if &a == &b {
                prism_rtl::Turn::Finished((Text::lit(""), st.clone()))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
            },
            (crate::check::types::Ty::TyQ(a), crate::check::types::Ty::TyQ(b)) => if &a == &b {
                prism_rtl::Turn::Finished((Text::lit(""), st.clone()))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
            },
            (crate::check::types::Ty::TyCon(a, xs), crate::check::types::Ty::TyCon(b, ys)) => if (&a == &b) && (&len(&xs) == &len(&ys)) {
                prism_rtl::Turn::More(Rc::new(UnifyAll { st: st.clone(), xs: xs.clone(), ys: ys.clone(), span: span.clone() }))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
            },
            (crate::check::types::Ty::TyFn(c1, ps, r1), crate::check::types::Ty::TyFn(c2, qs, r2)) => if &len(&ps) == &len(&qs) {
                {
                    let span = span.clone();
                    let st = st.clone();
                    call_then(crate::check::types::colors::start_unify_col(st.clone(), c1.clone(), c2.clone()), move |unify_col_4653: (Text, crate::check::types::St)| {
                        let (v_, st2) = unify_col_4653;
                        if &v_ != &Text::lit("") {
                            prism_rtl::Turn::Finished((v_.clone(), st2.clone()))
                        } else {
                            prism_rtl::Turn::More(Rc::new(UnifyAll { st: st2.clone(), xs: push(&ps, &*r1), ys: push(&qs, &*r2), span: span.clone() }))
                        }
                    })
                }
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
            },
            (crate::check::types::Ty::TyTuple(xs), crate::check::types::Ty::TyTuple(ys)) => if &len(&xs) == &len(&ys) {
                prism_rtl::Turn::More(Rc::new(UnifyAll { st: st.clone(), xs: xs.clone(), ys: ys.clone(), span: span.clone() }))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
            },
            (crate::check::types::Ty::TyArray(x), crate::check::types::Ty::TyArray(y)) => prism_rtl::Turn::More(Rc::new(UnifyIn { st: st.clone(), expected: (*x).clone(), found: (*y).clone(), span: span.clone() })),
            (crate::check::types::Ty::TyMap(k1, v1), crate::check::types::Ty::TyMap(k2, v2)) => prism_rtl::Turn::More(Rc::new(UnifyAll { st: st.clone(), xs: Array::from(vec![(*k1).clone(), (*v1).clone()]), ys: Array::from(vec![(*k2).clone(), (*v2).clone()]), span: span.clone() })),
            (crate::check::types::Ty::TySig(s1, i1), crate::check::types::Ty::TySig(s2, i2)) => if &s1 == &s2 {
                prism_rtl::Turn::More(Rc::new(UnifyIn { st: st.clone(), expected: (*i1).clone(), found: (*i2).clone(), span: span.clone() }))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
            },
            (crate::check::types::Ty::TyAt(i1, r1), crate::check::types::Ty::TyAt(i2, r2)) => {
                let span = span.clone();
                let st = st.clone();
                call_then(start_unify_in(st.clone(), (*i1).clone(), (*i2).clone(), span.clone()), move |unify_in_5237: (Text, crate::check::types::St)| {
                    let (v_, st2) = unify_in_5237;
                    if &v_ != &Text::lit("") {
                        prism_rtl::Turn::Finished((v_.clone(), st2.clone()))
                    } else {
                        prism_rtl::Turn::More(Rc::new(UnifyRow { st: st2.clone(), a0: r1.clone(), b0: r2.clone(), span: span.clone() }))
                    }
                })
            },
            (crate::check::types::Ty::TyElem(r1, o1), crate::check::types::Ty::TyElem(r2, o2)) => {
                let span = span.clone();
                let st = st.clone();
                call_then(start_unify_row(st.clone(), r1.clone(), r2.clone(), span.clone()), move |unify_row_5405: (Text, crate::check::types::St)| {
                    let (v_, st2) = unify_row_5405;
                    if &v_ != &Text::lit("") {
                        prism_rtl::Turn::Finished((v_.clone(), st2.clone()))
                    } else {
                        prism_rtl::Turn::More(Rc::new(UnifyIn { st: st2.clone(), expected: (*o1).clone(), found: (*o2).clone(), span: span.clone() }))
                    }
                })
            },
            (crate::check::types::Ty::TyElemAny(r1), crate::check::types::Ty::TyElemAny(r2)) => prism_rtl::Turn::More(Rc::new(UnifyRow { st: st.clone(), a0: r1.clone(), b0: r2.clone(), span: span.clone() })),
            (crate::check::types::Ty::TyAssoc(n1, a1), crate::check::types::Ty::TyAssoc(n2, a2)) => if &n1 == &n2 {
                prism_rtl::Turn::More(Rc::new(UnifyIn { st: st.clone(), expected: (*a1).clone(), found: (*a2).clone(), span: span.clone() }))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
            },
            (crate::check::types::Ty::TyAny(xs), crate::check::types::Ty::TyAny(ys)) => if &crate::check::types::sort_texts(&xs) == &crate::check::types::sort_texts(&ys) {
                prism_rtl::Turn::Finished((Text::lit(""), st.clone()))
            } else {
                prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
            },
            _ => prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone())),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start UnifyHeads, x`: what the function value is when passed to `@Run`.
pub fn start_unify_heads(st: crate::check::types::St, e: crate::check::types::Ty, f: crate::check::types::Ty, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>> {
    Rc::new(UnifyHeads { st, e, f, span })
}

/// ```prism
/// UnifyAll: unbounded fn St, [Ty], [Ty], Range -> ((Text, St))
/// ```
pub fn unify_all(st: &crate::check::types::St, xs: &Array<crate::check::types::Ty>, ys: &Array<crate::check::types::Ty>, span: &crate::syntax::Range) -> (Text, crate::check::types::St) {
    run_to_end(fold_job(crate::check::errors::range0(&len(xs)), (Text::lit(""), st.clone()), {
        let xs = xs.clone();
        let ys = ys.clone();
        let span = span.clone();
        Rc::new(move |(p0, p1): ((Text, crate::check::types::St), Nat)| {
            let xs = xs.clone();
            let ys = ys.clone();
            let span = span.clone();
            entered(once_job(move || {
                let (v_, s) = p0;
                let i = p1;
                if &v_ != &Text::lit("") {
                    prism_rtl::Turn::Finished((v_.clone(), s.clone()))
                } else {
                    prism_rtl::Turn::More(Rc::new(UnifyIn { st: s.clone(), expected: or(&index(&xs, &i), &crate::check::types::Ty::TyErr), found: or(&index(&ys, &i), &crate::check::types::Ty::TyErr), span: span.clone() }))
                }
            }))
        }) as Rc<dyn Fn(((Text, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>>>
    }))
}

/// The step machine of `UnifyAll`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyAll: unbounded fn St, [Ty], [Ty], Range -> ((Text, St))
/// ```
pub struct UnifyAll {
    pub st: crate::check::types::St,
    pub xs: Array<crate::check::types::Ty>,
    pub ys: Array<crate::check::types::Ty>,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(Text, crate::check::types::St)> for UnifyAll {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::check::types::St)> {
        let st = &self.st;
        let xs = &self.xs;
        let ys = &self.ys;
        let span = &self.span;
        fold_job(crate::check::errors::range0(&len(xs)), (Text::lit(""), st.clone()), {
            let xs = xs.clone();
            let ys = ys.clone();
            let span = span.clone();
            Rc::new(move |(p0, p1): ((Text, crate::check::types::St), Nat)| {
                let xs = xs.clone();
                let ys = ys.clone();
                let span = span.clone();
                entered(once_job(move || {
                    let (v_, s) = p0;
                    let i = p1;
                    if &v_ != &Text::lit("") {
                        prism_rtl::Turn::Finished((v_.clone(), s.clone()))
                    } else {
                        prism_rtl::Turn::More(Rc::new(UnifyIn { st: s.clone(), expected: or(&index(&xs, &i), &crate::check::types::Ty::TyErr), found: or(&index(&ys, &i), &crate::check::types::Ty::TyErr), span: span.clone() }))
                    }
                }))
            }) as Rc<dyn Fn(((Text, crate::check::types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>>>
        }).cycle()
    }
}

/// `Start UnifyAll, x`: what the function value is when passed to `@Run`.
pub fn start_unify_all(st: crate::check::types::St, xs: Array<crate::check::types::Ty>, ys: Array<crate::check::types::Ty>, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>> {
    Rc::new(UnifyAll { st, xs, ys, span })
}

/// ```prism
/// MergeVars: fn St, Nat, Nat -> St
/// ```
pub fn merge_vars(st: &crate::check::types::St, a: &Nat, b: &Nat) -> crate::check::types::St {
    let ia = crate::check::types::recording::info_of(st, a);
    let ib = crate::check::types::recording::info_of(st, b);
    let merged = crate::check::types::VInfo { plain: ia.plain || ib.plain, level: min(&ia.level, &ib.level), name: if &ib.name == &Text::lit("") { ia.name.clone() } else { ib.name.clone() } };
    let mut this: crate::check::types::St = st.clone();
    this.tys = insert(&this.tys, a, &crate::check::types::Ty::TyFlex(b.clone()));
    this.infos = insert(&this.infos, b, &merged);
    this
}

/// ```prism
/// BindVar: unbounded fn St, Nat, Ty, Range -> ((Text, St))
/// ```
pub fn bind_var(st: &crate::check::types::St, n: &Nat, t: &crate::check::types::Ty, span: &crate::syntax::Range) -> (Text, crate::check::types::St) {
    let info = crate::check::types::recording::info_of(st, n);
    let stack = crate::check::types::stack_of(st, t);
    if crate::check::types::has_nat(&crate::check::types::recording::free_vars(st, t), n) {
        (Text::lit("reported"), crate::check::types::recording::err(st, &Text::lit("occurs"), span, &Text::from(format!("`t{}` would contain itself: `t{} = {}`", n, n, &crate::check::types::show_ty(st, t)))))
    } else {
        if info.plain && (&stack != &Text::lit("")) {
            if &info.name != &Text::lit("") {
                {
                    let marks = marks_of(&info.name);
                    let whole = Text::from(format!("{}{}", &marks, &crate::check::types::show_ty_in(st, &crate::check::types::recording::zonk(st, t), &true)));
                    let at_ = or(&get(&st.binder_at, n), span);
                    let st2 = crate::check::types::recording::err_fix(st, &Text::lit("mark-stack"), &at_, &Text::from(format!("`{}` has type `{}`, whose stack is `{}{}`; the name shows `{}`", &info.name, &whole, &marks, &stack, &marks)), &Text::from(format!("rename to `{}{}{}`", &marks, &stack, &crate::syntax::lexer::chars::drop_prefix(&info.name, &marks))));
                    (Text::lit(""), {
                        let mut this: crate::check::types::St = lower_levels(&st2, &append(&crate::check::types::recording::free_vars(&st2, t), &crate::check::types::colors::free_col_vars(&st2, t)), &info.level);
                        this.tys = insert(&this.tys, n, t);
                        this
                    })
                }
            } else {
                (Text::lit("mismatch"), st.clone())
            }
        } else {
            {
                let lowered = lower_levels(st, &append(&crate::check::types::recording::free_vars(st, t), &crate::check::types::colors::free_col_vars(st, t)), &info.level);
                (Text::lit(""), {
                    let mut this: crate::check::types::St = lowered.clone();
                    this.tys = insert(&this.tys, n, t);
                    this
                })
            }
        }
    }
}

/// The step machine of `BindVar`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindVar: unbounded fn St, Nat, Ty, Range -> ((Text, St))
/// ```
pub struct BindVar {
    pub st: crate::check::types::St,
    pub n: Nat,
    pub t: crate::check::types::Ty,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(Text, crate::check::types::St)> for BindVar {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::check::types::St)> {
        let st = &self.st;
        let n = &self.n;
        let t = &self.t;
        let span = &self.span;
        let info = crate::check::types::recording::info_of(st, n);
        let n = n.clone();
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::start_stack_of(st.clone(), t.clone()), move |stack_of_6651: Text| {
            let stack = stack_of_6651;
            call_then(crate::check::types::recording::start_free_vars(st.clone(), t.clone()), move |free_vars_6680: Array<Nat>| if crate::check::types::has_nat(&free_vars_6680, &n) {
                call_then(crate::check::types::start_show_ty(st.clone(), t.clone()), move |show_ty_6786: Text| prism_rtl::Turn::Finished((Text::lit("reported"), crate::check::types::recording::err(&st, &Text::lit("occurs"), &span, &Text::from(format!("`t{}` would contain itself: `t{} = {}`", &n, &n, &show_ty_6786))))))
            } else {
                if info.plain && (&stack != &Text::lit("")) {
                    if &info.name != &Text::lit("") {
                        {
                            let marks = marks_of(&info.name);
                            call_then(crate::check::types::recording::start_zonk(st.clone(), t.clone()), move |zonk_6963: crate::check::types::Ty| call_then(crate::check::types::start_show_ty_in(st.clone(), zonk_6963, true), move |show_ty_in_6949: Text| {
                                let whole = Text::from(format!("{}{}", &marks, &show_ty_in_6949));
                                let at_ = or(&get(&st.binder_at, &n), &span);
                                let st2 = crate::check::types::recording::err_fix(&st, &Text::lit("mark-stack"), &at_, &Text::from(format!("`{}` has type `{}`, whose stack is `{}{}`; the name shows `{}`", &info.name, &whole, &marks, &stack, &marks)), &Text::from(format!("rename to `{}{}{}`", &marks, &stack, &crate::syntax::lexer::chars::drop_prefix(&info.name, &marks))));
                                prism_rtl::Turn::Finished((Text::lit(""), {
                                    let mut this: crate::check::types::St = lower_levels(&st2, &append(&crate::check::types::recording::free_vars(&st2, &t), &crate::check::types::colors::free_col_vars(&st2, &t)), &info.level);
                                    this.tys = insert(&this.tys, &n, &t);
                                    this
                                }))
                            }))
                        }
                    } else {
                        prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
                    }
                } else {
                    call_then(crate::check::types::recording::start_free_vars(st.clone(), t.clone()), move |free_vars_7628: Array<Nat>| call_then(crate::check::types::colors::start_free_col_vars(st.clone(), t.clone()), move |free_col_vars_7646: Array<Nat>| {
                        let lowered = lower_levels(&st, &append(&free_vars_7628, &free_col_vars_7646), &info.level);
                        prism_rtl::Turn::Finished((Text::lit(""), {
                            let mut this: crate::check::types::St = lowered.clone();
                            this.tys = insert(&this.tys, &n, &t);
                            this
                        }))
                    }))
                }
            })
        })
    }
}

/// `Start BindVar, x`: what the function value is when passed to `@Run`.
pub fn start_bind_var(st: crate::check::types::St, n: Nat, t: crate::check::types::Ty, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>> {
    Rc::new(BindVar { st, n, t, span })
}

/// ```prism
/// MarksOf: fn Text -> Text
/// ```
pub fn marks_of(name: &Text) -> Text {
    let c = {
        let mut this: Cursor = front(name);
        while let Some((_, next)) = step(&this) {
            if !is_mark_char(&crate::syntax::lexer::chars::char_at(&this)) {
                break;
            }
            this = next.clone();
        }
        this
    };
    before(&c)
}

/// ```prism
/// IsMarkChar: fn Text -> Bool
/// ```
pub fn is_mark_char(c: &Text) -> bool {
    (((((c == &Text::lit("$")) || (c == &Text::lit("!"))) || (c == &Text::lit("@"))) || (c == &Text::lit("?"))) || (c == &Text::lit("~"))) || (c == &Text::lit("&"))
}

/// ```prism
/// LowerLevels: fn St, [Nat], Nat -> St
/// ```
pub fn lower_levels(st: &crate::check::types::St, vs: &Array<Nat>, level: &Nat) -> crate::check::types::St {
    fold(vs, st, &(|s: &crate::check::types::St, v_: &Nat| lower_one(s, v_, level)))
}

/// ```prism
/// LowerOne: fn St, Nat, Nat -> St
/// ```
pub fn lower_one(s: &crate::check::types::St, v_: &Nat, level: &Nat) -> crate::check::types::St {
    let i = crate::check::types::recording::info_of(s, v_);
    if &i.level <= level {
        s.clone()
    } else {
        {
            let mut this: crate::check::types::St = s.clone();
            this.infos = insert(&this.infos, v_, &crate::check::types::VInfo { plain: i.plain, level: level.clone(), name: i.name.clone() });
            this
        }
    }
}

/// ```prism
/// UnifyRow: unbounded fn St, Rw, Rw, Range -> ((Text, St))
/// ```
pub fn unify_row(st: &crate::check::types::St, a0: &crate::check::types::Rw, b0: &crate::check::types::Rw, span: &crate::syntax::Range) -> (Text, crate::check::types::St) {
    let a = crate::check::types::recording::walk_row(st, a0);
    let b = crate::check::types::recording::walk_row(st, b0);
    let only_a = crate::check::types::minus_texts(&a.fams, &b.fams);
    let only_b = crate::check::types::minus_texts(&b.fams, &a.fams);
    match (a.tail.clone(), b.tail.clone()) {
        (crate::check::types::Tail::TlClosed, crate::check::types::Tail::TlClosed) => if (&len(&only_a) == &Nat::from(0u32)) && (&len(&only_b) == &Nat::from(0u32)) {
            (Text::lit(""), st.clone())
        } else {
            (Text::lit("mismatch"), st.clone())
        },
        (crate::check::types::Tail::TlFlex(x), crate::check::types::Tail::TlFlex(y)) => if &x == &y {
            if (&len(&only_a) == &Nat::from(0u32)) && (&len(&only_b) == &Nat::from(0u32)) {
                (Text::lit(""), st.clone())
            } else {
                (Text::lit("mismatch"), st.clone())
            }
        } else {
            {
                let lacking = crate::check::types::union_texts(&crate::check::types::union_texts(&lacks_of(st, &x), &lacks_of(st, &y)), &crate::check::types::union_texts(&a.fams, &b.fams));
                let (fresh, st2) = crate::check::types::recording::fresh_row(st, &lacking);
                let (v1, st3) = bind_row(&st2, &x, &crate::check::types::Rw { fams: only_b.clone(), minus: Array::new(), tail: fresh.tail.clone() }, span);
                if &v1 != &Text::lit("") {
                    (v1.clone(), st3.clone())
                } else {
                    bind_row(&st3, &y, &crate::check::types::Rw { fams: only_a.clone(), minus: Array::new(), tail: fresh.tail.clone() }, span)
                }
            }
        },
        (crate::check::types::Tail::TlFlex(x), other) => if &len(&only_a) == &Nat::from(0u32) {
            bind_row(st, &x, &crate::check::types::Rw { fams: only_b.clone(), minus: b.minus.clone(), tail: other.clone() }, span)
        } else {
            (Text::lit("mismatch"), st.clone())
        },
        (other, crate::check::types::Tail::TlFlex(y)) => if &len(&only_b) == &Nat::from(0u32) {
            bind_row(st, &y, &crate::check::types::Rw { fams: only_a.clone(), minus: a.minus.clone(), tail: other.clone() }, span)
        } else {
            (Text::lit("mismatch"), st.clone())
        },
        (crate::check::types::Tail::TlRigid(x), crate::check::types::Tail::TlRigid(y)) => if ((&x == &y) && (&len(&only_a) == &Nat::from(0u32))) && (&len(&only_b) == &Nat::from(0u32)) {
            (Text::lit(""), st.clone())
        } else {
            (Text::lit("mismatch"), st.clone())
        },
        (crate::check::types::Tail::TlQ(x), crate::check::types::Tail::TlQ(y)) => if ((&x == &y) && (&len(&only_a) == &Nat::from(0u32))) && (&len(&only_b) == &Nat::from(0u32)) {
            (Text::lit(""), st.clone())
        } else {
            (Text::lit("mismatch"), st.clone())
        },
        _ => (Text::lit("mismatch"), st.clone()),
    }
}

/// The step machine of `UnifyRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyRow: unbounded fn St, Rw, Rw, Range -> ((Text, St))
/// ```
pub struct UnifyRow {
    pub st: crate::check::types::St,
    pub a0: crate::check::types::Rw,
    pub b0: crate::check::types::Rw,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(Text, crate::check::types::St)> for UnifyRow {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::check::types::St)> {
        let st = &self.st;
        let a0 = &self.a0;
        let b0 = &self.b0;
        let span = &self.span;
        let a0 = a0.clone();
        let b0 = b0.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(crate::check::types::recording::start_walk_row(st.clone(), a0.clone()), move |walk_row_8688: crate::check::types::Rw| {
            let a = walk_row_8688;
            call_then(crate::check::types::recording::start_walk_row(st.clone(), b0.clone()), move |walk_row_8715: crate::check::types::Rw| {
                let b = walk_row_8715;
                let only_a = crate::check::types::minus_texts(&a.fams, &b.fams);
                let only_b = crate::check::types::minus_texts(&b.fams, &a.fams);
                match (a.tail.clone(), b.tail.clone()) {
                    (crate::check::types::Tail::TlClosed, crate::check::types::Tail::TlClosed) => if (&len(&only_a) == &Nat::from(0u32)) && (&len(&only_b) == &Nat::from(0u32)) {
                        prism_rtl::Turn::Finished((Text::lit(""), st.clone()))
                    } else {
                        prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
                    },
                    (crate::check::types::Tail::TlFlex(x), crate::check::types::Tail::TlFlex(y)) => if &x == &y {
                        if (&len(&only_a) == &Nat::from(0u32)) && (&len(&only_b) == &Nat::from(0u32)) {
                            prism_rtl::Turn::Finished((Text::lit(""), st.clone()))
                        } else {
                            prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
                        }
                    } else {
                        {
                            let lacking = crate::check::types::union_texts(&crate::check::types::union_texts(&lacks_of(&st, &x), &lacks_of(&st, &y)), &crate::check::types::union_texts(&a.fams, &b.fams));
                            let (fresh, st2) = crate::check::types::recording::fresh_row(&st, &lacking);
                            call_then(start_bind_row(st2.clone(), x.clone(), crate::check::types::Rw { fams: only_b.clone(), minus: Array::new(), tail: fresh.tail.clone() }, span.clone()), move |bind_row_9329: (Text, crate::check::types::St)| {
                                let (v1, st3) = bind_row_9329;
                                if &v1 != &Text::lit("") {
                                    prism_rtl::Turn::Finished((v1.clone(), st3.clone()))
                                } else {
                                    prism_rtl::Turn::More(Rc::new(BindRow { st: st3.clone(), n: y.clone(), rw: crate::check::types::Rw { fams: only_a.clone(), minus: Array::new(), tail: fresh.tail.clone() }, span: span.clone() }))
                                }
                            })
                        }
                    },
                    (crate::check::types::Tail::TlFlex(x), other) => if &len(&only_a) == &Nat::from(0u32) {
                        prism_rtl::Turn::More(Rc::new(BindRow { st: st.clone(), n: x.clone(), rw: crate::check::types::Rw { fams: only_b.clone(), minus: b.minus.clone(), tail: other.clone() }, span: span.clone() }))
                    } else {
                        prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
                    },
                    (other, crate::check::types::Tail::TlFlex(y)) => if &len(&only_b) == &Nat::from(0u32) {
                        prism_rtl::Turn::More(Rc::new(BindRow { st: st.clone(), n: y.clone(), rw: crate::check::types::Rw { fams: only_a.clone(), minus: a.minus.clone(), tail: other.clone() }, span: span.clone() }))
                    } else {
                        prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
                    },
                    (crate::check::types::Tail::TlRigid(x), crate::check::types::Tail::TlRigid(y)) => if ((&x == &y) && (&len(&only_a) == &Nat::from(0u32))) && (&len(&only_b) == &Nat::from(0u32)) {
                        prism_rtl::Turn::Finished((Text::lit(""), st.clone()))
                    } else {
                        prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
                    },
                    (crate::check::types::Tail::TlQ(x), crate::check::types::Tail::TlQ(y)) => if ((&x == &y) && (&len(&only_a) == &Nat::from(0u32))) && (&len(&only_b) == &Nat::from(0u32)) {
                        prism_rtl::Turn::Finished((Text::lit(""), st.clone()))
                    } else {
                        prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone()))
                    },
                    _ => prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone())),
                }
            })
        })
    }
}

/// `Start UnifyRow, x`: what the function value is when passed to `@Run`.
pub fn start_unify_row(st: crate::check::types::St, a0: crate::check::types::Rw, b0: crate::check::types::Rw, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>> {
    Rc::new(UnifyRow { st, a0, b0, span })
}

/// ```prism
/// AskField: fn St, Ty, Text, Ty, Range, [Text] -> St
/// ```
pub fn ask_field(st: &crate::check::types::St, recv: &crate::check::types::Ty, field: &Text, result: &crate::check::types::Ty, span: &crate::syntax::Range, owners: &Array<Text>) -> crate::check::types::St {
    let mut this: crate::check::types::St = st.clone();
    this.field_qs = push(&this.field_qs, &FieldQ { recv: recv.clone(), field: field.clone(), result: result.clone(), span: span.clone(), file: this.file.clone(), owners: owners.clone() });
    this
}

/// ```prism
/// AskLayer: fn St, Ty, Range, Text -> St
/// ```
pub fn ask_layer(st: &crate::check::types::St, t: &crate::check::types::Ty, span: &crate::syntax::Range, fname: &Text) -> crate::check::types::St {
    let mut this: crate::check::types::St = st.clone();
    this.layer_qs = push(&this.layer_qs, &(t.clone(), span.clone(), fname.clone()));
    this
}

/// ```prism
/// LayerQuestions: unbounded fn St -> St
/// ```
pub fn layer_questions(st: &crate::check::types::St) -> crate::check::types::St {
    let qs = st.layer_qs.clone();
    let cleared = {
        let mut this: crate::check::types::St = st.clone();
        this.layer_qs = Array::new();
        this
    };
    run_to_end(fold_job(qs.clone(), cleared.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, (crate::check::types::Ty, crate::syntax::Range, Text))| entered(once_job(move || {
        let s = p0;
        let (t, span, fname) = p1;
        call_then(crate::check::types::start_head_sigil(s.clone(), t.clone()), move |head_sigil_11312: Text| {
            let h = head_sigil_11312;
            call_then(crate::check::types::start_is_free_headed(s.clone(), t.clone()), move |is_free_headed_11339: bool| if (is_free_headed_11339 || (&h == &Text::lit("$"))) || (&h == &Text::lit("!")) {
                prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&s, &Text::lit("layer-unknown"), &span, &Text::from(format!("the layer of this argument to `{}` is not known here", &fname)), &Text::lit("say it where the value is made: a name whose marks declare the layer (`let $x = ...`), `<<T>>` at the application that made it, or a signature on the enclosing `let`")))
            } else {
                prism_rtl::Turn::Finished(s.clone())
            })
        })
    }))) as Rc<dyn Fn((crate::check::types::St, (crate::check::types::Ty, crate::syntax::Range, Text))) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>))
}

/// The step machine of `LayerQuestions`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LayerQuestions: unbounded fn St -> St
/// ```
pub struct LayerQuestions {
    pub st: crate::check::types::St,
}

impl prism_rtl::Job<crate::check::types::St> for LayerQuestions {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st = &self.st;
        let qs = st.layer_qs.clone();
        let cleared = {
            let mut this: crate::check::types::St = st.clone();
            this.layer_qs = Array::new();
            this
        };
        fold_job(qs.clone(), cleared.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, (crate::check::types::Ty, crate::syntax::Range, Text))| entered(once_job(move || {
            let s = p0;
            let (t, span, fname) = p1;
            call_then(crate::check::types::start_head_sigil(s.clone(), t.clone()), move |head_sigil_11312: Text| {
                let h = head_sigil_11312;
                call_then(crate::check::types::start_is_free_headed(s.clone(), t.clone()), move |is_free_headed_11339: bool| if (is_free_headed_11339 || (&h == &Text::lit("$"))) || (&h == &Text::lit("!")) {
                    prism_rtl::Turn::Finished(crate::check::types::recording::err_fix(&s, &Text::lit("layer-unknown"), &span, &Text::from(format!("the layer of this argument to `{}` is not known here", &fname)), &Text::lit("say it where the value is made: a name whose marks declare the layer (`let $x = ...`), `<<T>>` at the application that made it, or a signature on the enclosing `let`")))
                } else {
                    prism_rtl::Turn::Finished(s.clone())
                })
            })
        }))) as Rc<dyn Fn((crate::check::types::St, (crate::check::types::Ty, crate::syntax::Range, Text))) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>).cycle()
    }
}

/// `Start LayerQuestions, x`: what the function value is when passed to `@Run`.
pub fn start_layer_questions(st: crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(LayerQuestions { st })
}

/// ```prism
/// NameRow: fn St, Tail, Text -> St
/// ```
pub fn name_row(st: &crate::check::types::St, tail1: &crate::check::types::Tail, text2: &Text) -> crate::check::types::St {
    match (tail1, text2) {
        (crate::check::types::Tail::TlFlex(n), q) => {
            let mut this: crate::check::types::St = st.clone();
            this.row_names = insert(&this.row_names, n, q);
            this
        },
        (_, _) => st.clone(),
    }
}

/// ```prism
/// RowName: fn St, Nat -> Text
/// ```
pub fn row_name(st: &crate::check::types::St, n: &Nat) -> Text {
    or(&get(&st.row_names, n), &Text::from(format!("r{}", n)))
}

/// ```prism
/// LacksOf: fn St, Nat -> [Text]
/// ```
pub fn lacks_of(st: &crate::check::types::St, n: &Nat) -> Array<Text> {
    or(&get(&st.lacks, n), &Array::new())
}

/// ```prism
/// BindRow: unbounded fn St, Nat, Rw, Range -> ((Text, St))
/// ```
pub fn bind_row(st: &crate::check::types::St, n: &Nat, rw: &crate::check::types::Rw, span: &crate::syntax::Range) -> (Text, crate::check::types::St) {
    let bad = crate::check::types::inter_texts(&lacks_of(st, n), &rw.fams);
    if &len(&bad) > &Nat::from(0u32) {
        {
            let fam = or(&index(&bad, &Nat::from(0u32)), &Text::lit(""));
            (Text::lit("reported"), crate::check::types::recording::err_fix(st, &Text::lit("row-lacks"), span, &Text::from(format!("`{} | {}.*` promises `{}` has no `{}` tags", &row_name(st, n), &fam, &row_name(st, n), &fam)), &Text::from(format!("answer the `{}` tags before this point, or widen the row", &fam))))
        }
    } else {
        {
            let st2 = match &rw.tail {
                crate::check::types::Tail::TlFlex(m) => {
                    let mut this: crate::check::types::St = st.clone();
                    this.lacks = insert(&this.lacks, m, &crate::check::types::union_texts(&lacks_of(st, m), &lacks_of(st, n)));
                    this
                },
                _ => st.clone(),
            };
            (Text::lit(""), {
                let mut this: crate::check::types::St = st2.clone();
                this.rows = insert(&this.rows, n, rw);
                this
            })
        }
    }
}

/// The step machine of `BindRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindRow: unbounded fn St, Nat, Rw, Range -> ((Text, St))
/// ```
pub struct BindRow {
    pub st: crate::check::types::St,
    pub n: Nat,
    pub rw: crate::check::types::Rw,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<(Text, crate::check::types::St)> for BindRow {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::check::types::St)> {
        let st = &self.st;
        let n = &self.n;
        let rw = &self.rw;
        let span = &self.span;
        let bad = crate::check::types::inter_texts(&lacks_of(st, n), &rw.fams);
        if &len(&bad) > &Nat::from(0u32) {
            {
                let fam = or(&index(&bad, &Nat::from(0u32)), &Text::lit(""));
                prism_rtl::Turn::Finished((Text::lit("reported"), crate::check::types::recording::err_fix(st, &Text::lit("row-lacks"), span, &Text::from(format!("`{} | {}.*` promises `{}` has no `{}` tags", &row_name(st, n), &fam, &row_name(st, n), &fam)), &Text::from(format!("answer the `{}` tags before this point, or widen the row", &fam)))))
            }
        } else {
            {
                let st2 = match &rw.tail {
                    crate::check::types::Tail::TlFlex(m) => {
                        let mut this: crate::check::types::St = st.clone();
                        this.lacks = insert(&this.lacks, m, &crate::check::types::union_texts(&lacks_of(st, m), &lacks_of(st, n)));
                        this
                    },
                    _ => st.clone(),
                };
                prism_rtl::Turn::Finished((Text::lit(""), {
                    let mut this: crate::check::types::St = st2.clone();
                    this.rows = insert(&this.rows, n, rw);
                    this
                }))
            }
        }
    }
}

/// `Start BindRow, x`: what the function value is when passed to `@Run`.
pub fn start_bind_row(st: crate::check::types::St, n: Nat, rw: crate::check::types::Rw, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>> {
    Rc::new(BindRow { st, n, rw, span })
}
