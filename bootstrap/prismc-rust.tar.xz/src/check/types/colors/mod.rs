//! The module `Check.Types.Colors`, from `target/bootstrap/src/prismc/check/types/colors.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// JoinCol: fn Col, Col -> Col
/// ```
pub fn join_col_f(col0: &crate::check::types::Col, col1: &crate::check::types::Col) -> crate::check::types::Col {
    match (col0, col1) {
        (crate::check::types::Col::CBound, c_p0) => c_p0.clone(),
        (c_p1, crate::check::types::Col::CBound) => c_p1.clone(),
        (crate::check::types::Col::CUnbound, _) => crate::check::types::Col::CUnbound,
        (_, crate::check::types::Col::CUnbound) => crate::check::types::Col::CUnbound,
        (a_p2, b_p3) => if a_p2 == b_p3 { a_p2.clone() } else { crate::check::types::Col::CUnbound },
    }
}

/// ```prism
/// ColLeq: fn Col, Col -> Bool
/// ```
pub fn col_leq_f(a_p0: &crate::check::types::Col, b_p1: &crate::check::types::Col) -> bool {
    &join_col_f(a_p0, b_p1) == b_p1
}

/// ```prism
/// ColWord: fn Col -> Text
/// ```
pub fn col_word_f(col0: &crate::check::types::Col) -> Text {
    match col0 {
        crate::check::types::Col::CBound => Text::lit("bounded"),
        crate::check::types::Col::CUnbound => Text::lit("unbounded"),
        crate::check::types::Col::CRigid(n_p0) => Text::from(format!("`{}`-colored", n_p0)),
        crate::check::types::Col::CQ(n_p1) => Text::from(format!("`{}`-colored", n_p1)),
        crate::check::types::Col::CFlex(_) => Text::lit("bounded"),
    }
}

/// ```prism
/// UseColor: unbounded fn St, Col, Text, Range -> St
/// ```
pub fn use_color_f(st_p0: &crate::check::types::St, c0_p1: &crate::check::types::Col, why_p2: &Text, span_p3: &crate::syntax::Range) -> crate::check::types::St {
    match walk_col_f(st_p0, c0_p1) {
        crate::check::types::Col::CFlex(n_p4) => {
            let mut this: crate::check::types::St = st_p0.clone();
            this.color_flex_p = crate::prelude::push(&this.color_flex_p, &(crate::check::types::Col::CFlex(n_p4), why_p2.clone(), span_p3.clone()));
            this
        },
        c_p5 => join_known_f(st_p0, &c_p5, why_p2),
    }
}

/// The step machine of `UseColor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UseColor: unbounded fn St, Col, Text, Range -> St
/// ```
pub struct UseColor {
    pub st_p0: crate::check::types::St,
    pub c0_p1: crate::check::types::Col,
    pub why_p2: Text,
    pub span_p3: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for UseColor {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let c0_p1 = &self.c0_p1;
        let why_p2 = &self.why_p2;
        let span_p3 = &self.span_p3;
        let c0_p1x = c0_p1.clone();
        let span_p3x = span_p3.clone();
        let st_p0x = st_p0.clone();
        let why_p2x = why_p2.clone();
        crate::prelude::call_then(start_walk_col_f(st_p0x.clone(), c0_p1x.clone()), move |walk_col_f_1582: crate::check::types::Col| match walk_col_f_1582 {
            crate::check::types::Col::CFlex(n_p4) => prism_rtl::Turn::Finished({
                let mut this: crate::check::types::St = st_p0x.clone();
                this.color_flex_p = crate::prelude::push(&this.color_flex_p, &(crate::check::types::Col::CFlex(n_p4.clone()), why_p2x.clone(), span_p3x.clone()));
                this
            }),
            c_p5 => prism_rtl::Turn::Finished(join_known_f(&st_p0x, &c_p5, &why_p2x)),
        })
    }
}

/// `Start UseColor, x`: what the function value is when passed to `@Run`.
pub fn start_use_color_f(st_p0: crate::check::types::St, c0_p1: crate::check::types::Col, why_p2: Text, span_p3: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(UseColor { st_p0, c0_p1, why_p2, span_p3 })
}

/// ```prism
/// JoinKnown: fn St, Col, Text -> St
/// ```
pub fn join_known_f(st_p0: &crate::check::types::St, c0_p1: &crate::check::types::Col, why_p2: &Text) -> crate::check::types::St {
    let c_p3 = up_col_f(st_p0, c0_p1);
    let mut this: crate::check::types::St = st_p0.clone();
    if !col_leq_f(&c_p3, &this.color_p) {
        this.color_why_p = why_p2.clone();
    }
    this.color_p = join_col_f(&this.color_p, &c_p3);
    this
}

/// ```prism
/// UpCol: fn St, Col -> Col
/// ```
pub fn up_col_f(st_p0: &crate::check::types::St, col1: &crate::check::types::Col) -> crate::check::types::Col {
    match col1 {
        crate::check::types::Col::CRigid(n_p1) => match crate::prelude::get(&st_p0.col_up_p, n_p1) {
            Some(up_p2) => crate::check::types::Col::CRigid(up_p2),
            None => crate::check::types::Col::CRigid(n_p1.clone()),
        },
        c_p4 => c_p4.clone(),
    }
}

/// ```prism
/// WalkCol: unbounded fn St, Col -> Col
/// ```
pub fn walk_col_f(st_p0: &crate::check::types::St, col1: &crate::check::types::Col) -> crate::check::types::Col {
    match col1 {
        crate::check::types::Col::CFlex(n_p1) => match crate::prelude::get(&st_p0.cols_p, n_p1) {
            Some(c_p2) => walk_col_f(st_p0, &c_p2),
            None => crate::check::types::Col::CFlex(n_p1.clone()),
        },
        c_p4 => c_p4.clone(),
    }
}

/// The step machine of `WalkCol`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WalkCol: unbounded fn St, Col -> Col
/// ```
pub struct WalkCol {
    pub st_p0: crate::check::types::St,
    pub col1: crate::check::types::Col,
}

impl prism_rtl::Job<crate::check::types::Col> for WalkCol {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Col> {
        let st_p0 = &self.st_p0;
        let col1 = &self.col1;
        match col1 {
            crate::check::types::Col::CFlex(n_p1) => match crate::prelude::get(&st_p0.cols_p, n_p1) {
                Some(c_p2) => prism_rtl::Turn::More(Rc::new(WalkCol { st_p0: st_p0.clone(), col1: c_p2.clone() })),
                None => prism_rtl::Turn::Finished(crate::check::types::Col::CFlex(n_p1.clone())),
            },
            c_p4 => prism_rtl::Turn::Finished(c_p4.clone()),
        }
    }
}

/// `Start WalkCol, x`: what the function value is when passed to `@Run`.
pub fn start_walk_col_f(st_p0: crate::check::types::St, col1: crate::check::types::Col) -> Rc<dyn prism_rtl::Job<crate::check::types::Col>> {
    Rc::new(WalkCol { st_p0, col1 })
}

/// ```prism
/// IsRigidCol: fn Col -> Bool
/// ```
pub fn is_rigid_col_f(col0: &crate::check::types::Col) -> bool {
    match col0 {
        crate::check::types::Col::CRigid(_) => true,
        _ => false,
    }
}

/// ```prism
/// IsOwnCol: fn St, Col -> Bool
/// ```
pub fn is_own_col_f(s_p0: &crate::check::types::St, col1: &crate::check::types::Col) -> bool {
    match col1 {
        crate::check::types::Col::CFlex(n_p1) => &crate::check::types::recording::info_of_f(s_p0, n_p1).level_p > &s_p0.level_p,
        _ => false,
    }
}

/// ```prism
/// IsFlexCol: fn Col -> Bool
/// ```
pub fn is_flex_col_f(col0: &crate::check::types::Col) -> bool {
    match col0 {
        crate::check::types::Col::CFlex(_) => true,
        _ => false,
    }
}

/// ```prism
/// SettledCol: unbounded fn St, Col -> Col
/// ```
pub fn settled_col_f(st_p0: &crate::check::types::St, c_p1: &crate::check::types::Col) -> crate::check::types::Col {
    match walk_col_f(st_p0, c_p1) {
        crate::check::types::Col::CFlex(_) => crate::check::types::Col::CBound,
        other_p2 => other_p2,
    }
}

/// The step machine of `SettledCol`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SettledCol: unbounded fn St, Col -> Col
/// ```
pub struct SettledCol {
    pub st_p0: crate::check::types::St,
    pub c_p1: crate::check::types::Col,
}

impl prism_rtl::Job<crate::check::types::Col> for SettledCol {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Col> {
        let st_p0 = &self.st_p0;
        let c_p1 = &self.c_p1;
        let c_p1x = c_p1.clone();
        let st_p0x = st_p0.clone();
        crate::prelude::call_then(start_walk_col_f(st_p0x.clone(), c_p1x.clone()), move |walk_col_f_2936: crate::check::types::Col| match walk_col_f_2936 {
            crate::check::types::Col::CFlex(_) => prism_rtl::Turn::Finished(crate::check::types::Col::CBound),
            other_p2 => prism_rtl::Turn::Finished(other_p2.clone()),
        })
    }
}

/// `Start SettledCol, x`: what the function value is when passed to `@Run`.
pub fn start_settled_col_f(st_p0: crate::check::types::St, c_p1: crate::check::types::Col) -> Rc<dyn prism_rtl::Job<crate::check::types::Col>> {
    Rc::new(SettledCol { st_p0, c_p1 })
}

/// ```prism
/// UnifyCol: unbounded fn St, Col, Col -> ((Text, St))
/// ```
pub fn unify_col_f(st_p0: &crate::check::types::St, a0_p1: &crate::check::types::Col, b0_p2: &crate::check::types::Col) -> (Text, crate::check::types::St) {
    let a_p3 = walk_col_f(st_p0, a0_p1);
    let b_p4 = walk_col_f(st_p0, b0_p2);
    if &a_p3 == &b_p4 {
        (Text::lit(""), st_p0.clone())
    } else {
        match (a_p3.clone(), b_p4.clone()) {
            (crate::check::types::Col::CFlex(x_p5), other_p6) => (Text::lit(""), bind_col_f(st_p0, &x_p5, &other_p6)),
            (other_p7, crate::check::types::Col::CFlex(y_p8)) => (Text::lit(""), bind_col_f(st_p0, &y_p8, &other_p7)),
            (crate::check::types::Col::CQ(_), _) => (Text::lit(""), st_p0.clone()),
            (_, crate::check::types::Col::CQ(_)) => (Text::lit(""), st_p0.clone()),
            _ => (Text::lit("mismatch"), st_p0.clone()),
        }
    }
}

/// The step machine of `UnifyCol`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyCol: unbounded fn St, Col, Col -> ((Text, St))
/// ```
pub struct UnifyCol {
    pub st_p0: crate::check::types::St,
    pub a0_p1: crate::check::types::Col,
    pub b0_p2: crate::check::types::Col,
}

impl prism_rtl::Job<(Text, crate::check::types::St)> for UnifyCol {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::check::types::St)> {
        let st_p0 = &self.st_p0;
        let a0_p1 = &self.a0_p1;
        let b0_p2 = &self.b0_p2;
        let a0_p1x = a0_p1.clone();
        let b0_p2x = b0_p2.clone();
        let st_p0x = st_p0.clone();
        crate::prelude::call_then(start_walk_col_f(st_p0x.clone(), a0_p1x.clone()), move |walk_col_f_3231: crate::check::types::Col| {
            let a_p3 = walk_col_f_3231;
            crate::prelude::call_then(start_walk_col_f(st_p0x.clone(), b0_p2x.clone()), move |walk_col_f_3258: crate::check::types::Col| {
                let b_p4 = walk_col_f_3258;
                if &a_p3 == &b_p4 {
                    prism_rtl::Turn::Finished((Text::lit(""), st_p0x.clone()))
                } else {
                    match (a_p3.clone(), b_p4.clone()) {
                        (crate::check::types::Col::CFlex(x_p5), other_p6) => prism_rtl::Turn::Finished((Text::lit(""), bind_col_f(&st_p0x, &x_p5, &other_p6))),
                        (other_p7, crate::check::types::Col::CFlex(y_p8)) => prism_rtl::Turn::Finished((Text::lit(""), bind_col_f(&st_p0x, &y_p8, &other_p7))),
                        (crate::check::types::Col::CQ(_), _) => prism_rtl::Turn::Finished((Text::lit(""), st_p0x.clone())),
                        (_, crate::check::types::Col::CQ(_)) => prism_rtl::Turn::Finished((Text::lit(""), st_p0x.clone())),
                        _ => prism_rtl::Turn::Finished((Text::lit("mismatch"), st_p0x.clone())),
                    }
                }
            })
        })
    }
}

/// `Start UnifyCol, x`: what the function value is when passed to `@Run`.
pub fn start_unify_col_f(st_p0: crate::check::types::St, a0_p1: crate::check::types::Col, b0_p2: crate::check::types::Col) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>> {
    Rc::new(UnifyCol { st_p0, a0_p1, b0_p2 })
}

/// ```prism
/// BindCol: fn St, Nat, Col -> St
/// ```
pub fn bind_col_f(st_p0: &crate::check::types::St, n_p1: &Nat, c_p2: &crate::check::types::Col) -> crate::check::types::St {
    let st2_p3 = match c_p2 {
        crate::check::types::Col::CFlex(m_p4) => crate::check::types::unify::lower_one_f(st_p0, m_p4, &crate::check::types::recording::info_of_f(st_p0, n_p1).level_p),
        _ => st_p0.clone(),
    };
    let mut this: crate::check::types::St = st2_p3.clone();
    this.cols_p = crate::prelude::insert(&this.cols_p, n_p1, c_p2);
    this
}

/// ```prism
/// FreeColVars: unbounded fn St, Ty -> [Nat]
/// ```
pub fn free_col_vars_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> Array<Nat> {
    free_cols_into_f(st_p0, &Array::new(), t_p1)
}

/// The step machine of `FreeColVars`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FreeColVars: unbounded fn St, Ty -> [Nat]
/// ```
pub struct FreeColVars {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<Array<Nat>> for FreeColVars {
    fn cycle(&self) -> prism_rtl::Turn<Array<Nat>> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        prism_rtl::Turn::More(Rc::new(FreeColsInto { st_p0: st_p0.clone(), acc_p1: Array::new(), t_p2: t_p1.clone() }))
    }
}

/// `Start FreeColVars, x`: what the function value is when passed to `@Run`.
pub fn start_free_col_vars_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Array<Nat>>> {
    Rc::new(FreeColVars { st_p0, t_p1 })
}

/// ```prism
/// FreeColsInto: unbounded fn St, [Nat], Ty -> [Nat]
/// ```
pub fn free_cols_into_f(st_p0: &crate::check::types::St, acc_p1: &Array<Nat>, t_p2: &crate::check::types::Ty) -> Array<Nat> {
    match crate::check::types::recording::walk_f(st_p0, t_p2) {
        crate::check::types::Ty::TyCon(_, args_p3) => crate::prelude::run_to_end(crate::prelude::fold_job(args_p3.clone(), acc_p1.clone(), {
            let st_p0x = st_p0.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p4 = p0;
                    let x_p5 = p1;
                    prism_rtl::Turn::More(Rc::new(FreeColsInto { st_p0: st_p0xy.clone(), acc_p1: a_p4.clone(), t_p2: x_p5.clone() }))
                }))
            }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        })),
        crate::check::types::Ty::TyFn(c_p6, ps_p7, res_p8) => {
            let acc2_p9 = match walk_col_f(st_p0, &c_p6) {
                crate::check::types::Col::CFlex(n_pa) => crate::check::types::add_nat_f(acc_p1, &n_pa),
                _ => acc_p1.clone(),
            };
            free_cols_into_f(st_p0, &crate::prelude::run_to_end(crate::prelude::fold_job(ps_p7.clone(), acc2_p9.clone(), {
                let st_p0x = st_p0.clone();
                Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                    let st_p0xy = st_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_pb = p0;
                        let x_pc = p1;
                        prism_rtl::Turn::More(Rc::new(FreeColsInto { st_p0: st_p0xy.clone(), acc_p1: a_pb.clone(), t_p2: x_pc.clone() }))
                    }))
                }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
            })), &*res_p8)
        },
        crate::check::types::Ty::TyTuple(ts_pd) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_pd.clone(), acc_p1.clone(), {
            let st_p0x = st_p0.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pe = p0;
                    let x_pf = p1;
                    prism_rtl::Turn::More(Rc::new(FreeColsInto { st_p0: st_p0xy.clone(), acc_p1: a_pe.clone(), t_p2: x_pf.clone() }))
                }))
            }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        })),
        crate::check::types::Ty::TyArray(e_pg) => free_cols_into_f(st_p0, acc_p1, &*e_pg),
        crate::check::types::Ty::TyMap(k_ph, v_pi) => free_cols_into_f(st_p0, &free_cols_into_f(st_p0, acc_p1, &*k_ph), &*v_pi),
        crate::check::types::Ty::TySig(_, i_pj) => free_cols_into_f(st_p0, acc_p1, &*i_pj),
        crate::check::types::Ty::TyAt(i_pk, _) => free_cols_into_f(st_p0, acc_p1, &*i_pk),
        crate::check::types::Ty::TyElem(_, o_pl) => free_cols_into_f(st_p0, acc_p1, &*o_pl),
        crate::check::types::Ty::TyAssoc(_, a_pm) => free_cols_into_f(st_p0, acc_p1, &*a_pm),
        _ => acc_p1.clone(),
    }
}

/// The step machine of `FreeColsInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FreeColsInto: unbounded fn St, [Nat], Ty -> [Nat]
/// ```
pub struct FreeColsInto {
    pub st_p0: crate::check::types::St,
    pub acc_p1: Array<Nat>,
    pub t_p2: crate::check::types::Ty,
}

impl prism_rtl::Job<Array<Nat>> for FreeColsInto {
    fn cycle(&self) -> prism_rtl::Turn<Array<Nat>> {
        let st_p0 = &self.st_p0;
        let acc_p1 = &self.acc_p1;
        let t_p2 = &self.t_p2;
        let acc_p1x = acc_p1.clone();
        let st_p0x = st_p0.clone();
        let t_p2x = t_p2.clone();
        crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p0x.clone(), t_p2x.clone()), move |walk_f_3992: crate::check::types::Ty| match walk_f_3992 {
            crate::check::types::Ty::TyCon(_, args_p3) => crate::prelude::fold_job(args_p3.clone(), acc_p1x.clone(), {
                let st_p0xx = st_p0x.clone();
                Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                    let st_p0xxy = st_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_p4 = p0;
                        let x_p5 = p1;
                        prism_rtl::Turn::More(Rc::new(FreeColsInto { st_p0: st_p0xxy.clone(), acc_p1: a_p4.clone(), t_p2: x_p5.clone() }))
                    }))
                }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
            }).cycle(),
            crate::check::types::Ty::TyFn(c_p6, ps_p7, res_p8) => crate::prelude::call_then(start_walk_col_f(st_p0x.clone(), c_p6.clone()), move |walk_col_f_4120: crate::check::types::Col| {
                let acc2_p9 = match walk_col_f_4120 {
                    crate::check::types::Col::CFlex(n_pa) => crate::check::types::add_nat_f(&acc_p1x, &n_pa),
                    _ => acc_p1x.clone(),
                };
                crate::prelude::call_value(crate::prelude::fold_job(ps_p7.clone(), acc2_p9.clone(), {
                    let st_p0xx = st_p0x.clone();
                    Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                        let st_p0xxy = st_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_pb = p0;
                            let x_pc = p1;
                            prism_rtl::Turn::More(Rc::new(FreeColsInto { st_p0: st_p0xxy.clone(), acc_p1: a_pb.clone(), t_p2: x_pc.clone() }))
                        }))
                    }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
                }), move |fold_4223: Array<Nat>| prism_rtl::Turn::More(Rc::new(FreeColsInto { st_p0: st_p0x.clone(), acc_p1: fold_4223, t_p2: (*res_p8).clone() })))
            }),
            crate::check::types::Ty::TyTuple(ts_pd) => crate::prelude::fold_job(ts_pd.clone(), acc_p1x.clone(), {
                let st_p0xx = st_p0x.clone();
                Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                    let st_p0xxy = st_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_pe = p0;
                        let x_pf = p1;
                        prism_rtl::Turn::More(Rc::new(FreeColsInto { st_p0: st_p0xxy.clone(), acc_p1: a_pe.clone(), t_p2: x_pf.clone() }))
                    }))
                }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
            }).cycle(),
            crate::check::types::Ty::TyArray(e_pg) => prism_rtl::Turn::More(Rc::new(FreeColsInto { st_p0: st_p0x.clone(), acc_p1: acc_p1x.clone(), t_p2: (*e_pg).clone() })),
            crate::check::types::Ty::TyMap(k_ph, v_pi) => crate::prelude::call_then(start_free_cols_into_f(st_p0x.clone(), acc_p1x.clone(), (*k_ph).clone()), move |free_cols_into_f_4407: Array<Nat>| prism_rtl::Turn::More(Rc::new(FreeColsInto { st_p0: st_p0x.clone(), acc_p1: free_cols_into_f_4407, t_p2: (*v_pi).clone() }))),
            crate::check::types::Ty::TySig(_, i_pj) => prism_rtl::Turn::More(Rc::new(FreeColsInto { st_p0: st_p0x.clone(), acc_p1: acc_p1x.clone(), t_p2: (*i_pj).clone() })),
            crate::check::types::Ty::TyAt(i_pk, _) => prism_rtl::Turn::More(Rc::new(FreeColsInto { st_p0: st_p0x.clone(), acc_p1: acc_p1x.clone(), t_p2: (*i_pk).clone() })),
            crate::check::types::Ty::TyElem(_, o_pl) => prism_rtl::Turn::More(Rc::new(FreeColsInto { st_p0: st_p0x.clone(), acc_p1: acc_p1x.clone(), t_p2: (*o_pl).clone() })),
            crate::check::types::Ty::TyAssoc(_, a_pm) => prism_rtl::Turn::More(Rc::new(FreeColsInto { st_p0: st_p0x.clone(), acc_p1: acc_p1x.clone(), t_p2: (*a_pm).clone() })),
            _ => prism_rtl::Turn::Finished(acc_p1x.clone()),
        })
    }
}

/// `Start FreeColsInto, x`: what the function value is when passed to `@Run`.
pub fn start_free_cols_into_f(st_p0: crate::check::types::St, acc_p1: Array<Nat>, t_p2: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Array<Nat>>> {
    Rc::new(FreeColsInto { st_p0, acc_p1, t_p2 })
}

/// ```prism
/// AddLeq: unbounded fn St, Col, Col, Range, Text, Text, Text -> St
/// ```
pub fn add_leq_f(st_p0: &crate::check::types::St, lo0_p1: &crate::check::types::Col, hi0_p2: &crate::check::types::Col, span_p3: &crate::syntax::Range, kind_p4: &Text, name_p5: &Text, why_p6: &Text) -> crate::check::types::St {
    let lo_p7 = walk_col_f(st_p0, lo0_p1);
    let hi_p8 = walk_col_f(st_p0, hi0_p2);
    if ((&lo_p7 == &crate::check::types::Col::CBound) || (&hi_p8 == &crate::check::types::Col::CUnbound)) || (&lo_p7 == &hi_p8) {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.cleqs_p = crate::prelude::push(&this.cleqs_p, &crate::check::types::CLeq { lo_p: lo_p7.clone(), hi_p: hi_p8.clone(), file_p: this.file_p.clone(), span_p: span_p3.clone(), kind_p: kind_p4.clone(), name_p: name_p5.clone(), why_p: why_p6.clone() });
            this
        }
    }
}

/// The step machine of `AddLeq`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AddLeq: unbounded fn St, Col, Col, Range, Text, Text, Text -> St
/// ```
pub struct AddLeq {
    pub st_p0: crate::check::types::St,
    pub lo0_p1: crate::check::types::Col,
    pub hi0_p2: crate::check::types::Col,
    pub span_p3: crate::syntax::Range,
    pub kind_p4: Text,
    pub name_p5: Text,
    pub why_p6: Text,
}

impl prism_rtl::Job<crate::check::types::St> for AddLeq {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let lo0_p1 = &self.lo0_p1;
        let hi0_p2 = &self.hi0_p2;
        let span_p3 = &self.span_p3;
        let kind_p4 = &self.kind_p4;
        let name_p5 = &self.name_p5;
        let why_p6 = &self.why_p6;
        let hi0_p2x = hi0_p2.clone();
        let kind_p4x = kind_p4.clone();
        let lo0_p1x = lo0_p1.clone();
        let name_p5x = name_p5.clone();
        let span_p3x = span_p3.clone();
        let st_p0x = st_p0.clone();
        let why_p6x = why_p6.clone();
        crate::prelude::call_then(start_walk_col_f(st_p0x.clone(), lo0_p1x.clone()), move |walk_col_f_4883: crate::check::types::Col| {
            let lo_p7 = walk_col_f_4883;
            crate::prelude::call_then(start_walk_col_f(st_p0x.clone(), hi0_p2x.clone()), move |walk_col_f_4912: crate::check::types::Col| {
                let hi_p8 = walk_col_f_4912;
                if ((&lo_p7 == &crate::check::types::Col::CBound) || (&hi_p8 == &crate::check::types::Col::CUnbound)) || (&lo_p7 == &hi_p8) {
                    prism_rtl::Turn::Finished(st_p0x.clone())
                } else {
                    prism_rtl::Turn::Finished({
                        let mut this: crate::check::types::St = st_p0x.clone();
                        this.cleqs_p = crate::prelude::push(&this.cleqs_p, &crate::check::types::CLeq { lo_p: lo_p7.clone(), hi_p: hi_p8.clone(), file_p: this.file_p.clone(), span_p: span_p3x.clone(), kind_p: kind_p4x.clone(), name_p: name_p5x.clone(), why_p: why_p6x.clone() });
                        this
                    })
                }
            })
        })
    }
}

/// `Start AddLeq, x`: what the function value is when passed to `@Run`.
pub fn start_add_leq_f(st_p0: crate::check::types::St, lo0_p1: crate::check::types::Col, hi0_p2: crate::check::types::Col, span_p3: crate::syntax::Range, kind_p4: Text, name_p5: Text, why_p6: Text) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(AddLeq { st_p0, lo0_p1, hi0_p2, span_p3, kind_p4, name_p5, why_p6 })
}

/// ```prism
/// Propagate: unbounded fn St, Bool -> St
/// ```
pub fn propagate_f(st_p0: &crate::check::types::St, rigid_p1: &bool) -> crate::check::types::St {
    let (st2_p8, changed_p9) = crate::prelude::run_to_end(crate::prelude::fold_job(st_p0.cleqs_p.clone(), (st_p0.clone(), false), {
        let rigid_p1x = *rigid_p1;
        Rc::new(move |(p0, p1): ((crate::check::types::St, bool), crate::check::types::CLeq)| {
            let rigid_p1xy = rigid_p1x;
            crate::prelude::entered(crate::prelude::once_job(move || {
                let (s_p2, ch_p3) = p0;
                let c_p4 = p1;
                crate::prelude::call_then(start_walk_col_f(s_p2.clone(), c_p4.lo_p.clone()), move |walk_col_f_5490: crate::check::types::Col| {
                    let lo_p5 = walk_col_f_5490;
                    crate::prelude::call_then(start_walk_col_f(s_p2.clone(), c_p4.hi_p.clone()), move |walk_col_f_5520: crate::check::types::Col| match walk_col_f_5520 {
                        crate::check::types::Col::CFlex(h_p6) => {
                            let forced_p7 = (&lo_p5 == &crate::check::types::Col::CUnbound) || (rigid_p1xy && is_rigid_col_f(&lo_p5));
                            if forced_p7 {
                                prism_rtl::Turn::Finished((bind_col_f(&s_p2, &h_p6, &lo_p5), true))
                            } else {
                                prism_rtl::Turn::Finished((s_p2.clone(), ch_p3))
                            }
                        },
                        _ => prism_rtl::Turn::Finished((s_p2.clone(), ch_p3)),
                    })
                })
            }))
        }) as Rc<dyn Fn(((crate::check::types::St, bool), crate::check::types::CLeq)) -> Rc<dyn prism_rtl::Job<(crate::check::types::St, bool)>>>
    }));
    if changed_p9 { propagate_f(&st2_p8, rigid_p1) } else { st2_p8.clone() }
}

/// The step machine of `Propagate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Propagate: unbounded fn St, Bool -> St
/// ```
pub struct Propagate {
    pub st_p0: crate::check::types::St,
    pub rigid_p1: bool,
}

impl prism_rtl::Job<crate::check::types::St> for Propagate {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let rigid_p1 = &self.rigid_p1;
        let rigid_p1x = *rigid_p1;
        let st_p0x = st_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(st_p0x.cleqs_p.clone(), (st_p0x.clone(), false), {
            let rigid_p1xx = rigid_p1x;
            Rc::new(move |(p0, p1): ((crate::check::types::St, bool), crate::check::types::CLeq)| {
                let rigid_p1xxy = rigid_p1xx;
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let (s_p2, ch_p3) = p0;
                    let c_p4 = p1;
                    crate::prelude::call_then(start_walk_col_f(s_p2.clone(), c_p4.lo_p.clone()), move |walk_col_f_5490: crate::check::types::Col| {
                        let lo_p5 = walk_col_f_5490;
                        crate::prelude::call_then(start_walk_col_f(s_p2.clone(), c_p4.hi_p.clone()), move |walk_col_f_5520: crate::check::types::Col| match walk_col_f_5520 {
                            crate::check::types::Col::CFlex(h_p6) => {
                                let forced_p7 = (&lo_p5 == &crate::check::types::Col::CUnbound) || (rigid_p1xxy && is_rigid_col_f(&lo_p5));
                                if forced_p7 {
                                    prism_rtl::Turn::Finished((bind_col_f(&s_p2, &h_p6, &lo_p5), true))
                                } else {
                                    prism_rtl::Turn::Finished((s_p2.clone(), ch_p3))
                                }
                            },
                            _ => prism_rtl::Turn::Finished((s_p2.clone(), ch_p3)),
                        })
                    })
                }))
            }) as Rc<dyn Fn(((crate::check::types::St, bool), crate::check::types::CLeq)) -> Rc<dyn prism_rtl::Job<(crate::check::types::St, bool)>>>
        }), move |fold_5427: (crate::check::types::St, bool)| {
            let (st2_p8, changed_p9) = fold_5427;
            if changed_p9 {
                prism_rtl::Turn::More(Rc::new(Propagate { st_p0: st2_p8.clone(), rigid_p1: rigid_p1x }))
            } else {
                prism_rtl::Turn::Finished(st2_p8.clone())
            }
        })
    }
}

/// `Start Propagate, x`: what the function value is when passed to `@Run`.
pub fn start_propagate_f(st_p0: crate::check::types::St, rigid_p1: bool) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(Propagate { st_p0, rigid_p1 })
}

/// ```prism
/// GeneralizeCols: unbounded fn St -> St
/// ```
pub fn generalize_cols_f(st0_p0: &crate::check::types::St) -> crate::check::types::St {
    let st1_p1 = lower_joined_f(&propagate_f(st0_p0, &false));
    let st2_p2 = crate::prelude::run_to_end(crate::prelude::fold_job(st1_p1.cleqs_p.clone(), st1_p1.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::CLeq)| crate::prelude::entered(crate::prelude::once_job(move || {
        let s_p3 = p0;
        let c_p4 = p1;
        crate::prelude::call_then(start_walk_col_f(s_p3.clone(), c_p4.lo_p.clone()), move |walk_col_f_6260: crate::check::types::Col| {
            let lo_p5 = walk_col_f_6260;
            crate::prelude::call_then(start_walk_col_f(s_p3.clone(), c_p4.hi_p.clone()), move |walk_col_f_6293: crate::check::types::Col| {
                let hi_p6 = walk_col_f_6293;
                match (lo_p5.clone(), hi_p6.clone()) {
                    (crate::check::types::Col::CFlex(x_p7), crate::check::types::Col::CFlex(y_p8)) => if ((&x_p7 != &y_p8) && is_own_col_f(&s_p3, &lo_p5)) && is_own_col_f(&s_p3, &hi_p6) {
                        prism_rtl::Turn::Finished(bind_col_f(&s_p3, &x_p7, &hi_p6))
                    } else {
                        prism_rtl::Turn::Finished(s_p3.clone())
                    },
                    _ => prism_rtl::Turn::Finished(s_p3.clone()),
                }
            })
        })
    }))) as Rc<dyn Fn((crate::check::types::St, crate::check::types::CLeq)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>));
    crate::prelude::run_to_end(crate::prelude::fold_job(st2_p2.cleqs_p.clone(), st2_p2.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::CLeq)| crate::prelude::entered(crate::prelude::once_job(move || {
        let s_p9 = p0;
        let c_pa = p1;
        crate::prelude::call_then(start_walk_col_f(s_p9.clone(), c_pa.lo_p.clone()), move |walk_col_f_6522: crate::check::types::Col| {
            let lo_pb = walk_col_f_6522;
            crate::prelude::call_then(start_walk_col_f(s_p9.clone(), c_pa.hi_p.clone()), move |walk_col_f_6555: crate::check::types::Col| {
                let hi_pc = walk_col_f_6555;
                match (lo_pb.clone(), hi_pc.clone()) {
                    (crate::check::types::Col::CFlex(_), crate::check::types::Col::CFlex(_)) => prism_rtl::Turn::Finished(s_p9.clone()),
                    (crate::check::types::Col::CFlex(_), crate::check::types::Col::CUnbound) => prism_rtl::Turn::Finished(s_p9.clone()),
                    (crate::check::types::Col::CFlex(x_pd), other_pe) => if is_own_col_f(&s_p9, &lo_pb) {
                        prism_rtl::Turn::Finished(bind_col_f(&s_p9, &x_pd, &other_pe))
                    } else {
                        prism_rtl::Turn::Finished(s_p9.clone())
                    },
                    (crate::check::types::Col::CRigid(r_pf), crate::check::types::Col::CFlex(y_pg)) => if is_own_col_f(&s_p9, &hi_pc) {
                        prism_rtl::Turn::Finished(bind_col_f(&s_p9, &y_pg, &lo_pb))
                    } else {
                        prism_rtl::Turn::Finished(s_p9.clone())
                    },
                    _ => prism_rtl::Turn::Finished(s_p9.clone()),
                }
            })
        })
    }))) as Rc<dyn Fn((crate::check::types::St, crate::check::types::CLeq)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>))
}

/// The step machine of `GeneralizeCols`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GeneralizeCols: unbounded fn St -> St
/// ```
pub struct GeneralizeCols {
    pub st0_p0: crate::check::types::St,
}

impl prism_rtl::Job<crate::check::types::St> for GeneralizeCols {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st0_p0 = &self.st0_p0;
        let st0_p0x = st0_p0.clone();
        crate::prelude::call_then(start_propagate_f(st0_p0x.clone(), false), move |propagate_f_6178: crate::check::types::St| crate::prelude::call_then(start_lower_joined_f(propagate_f_6178), move |lower_joined_f_6165: crate::check::types::St| {
            let st1_p1 = lower_joined_f_6165;
            crate::prelude::call_value(crate::prelude::fold_job(st1_p1.cleqs_p.clone(), st1_p1.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::CLeq)| crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p3 = p0;
                let c_p4 = p1;
                crate::prelude::call_then(start_walk_col_f(s_p3.clone(), c_p4.lo_p.clone()), move |walk_col_f_6260: crate::check::types::Col| {
                    let lo_p5 = walk_col_f_6260;
                    crate::prelude::call_then(start_walk_col_f(s_p3.clone(), c_p4.hi_p.clone()), move |walk_col_f_6293: crate::check::types::Col| {
                        let hi_p6 = walk_col_f_6293;
                        match (lo_p5.clone(), hi_p6.clone()) {
                            (crate::check::types::Col::CFlex(x_p7), crate::check::types::Col::CFlex(y_p8)) => if ((&x_p7 != &y_p8) && is_own_col_f(&s_p3, &lo_p5)) && is_own_col_f(&s_p3, &hi_p6) {
                                prism_rtl::Turn::Finished(bind_col_f(&s_p3, &x_p7, &hi_p6))
                            } else {
                                prism_rtl::Turn::Finished(s_p3.clone())
                            },
                            _ => prism_rtl::Turn::Finished(s_p3.clone()),
                        }
                    })
                })
            }))) as Rc<dyn Fn((crate::check::types::St, crate::check::types::CLeq)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>), move |fold_6214: crate::check::types::St| {
                let st2_p2 = fold_6214;
                crate::prelude::fold_job(st2_p2.cleqs_p.clone(), st2_p2.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::CLeq)| crate::prelude::entered(crate::prelude::once_job(move || {
                    let s_p9 = p0;
                    let c_pa = p1;
                    crate::prelude::call_then(start_walk_col_f(s_p9.clone(), c_pa.lo_p.clone()), move |walk_col_f_6522: crate::check::types::Col| {
                        let lo_pb = walk_col_f_6522;
                        crate::prelude::call_then(start_walk_col_f(s_p9.clone(), c_pa.hi_p.clone()), move |walk_col_f_6555: crate::check::types::Col| {
                            let hi_pc = walk_col_f_6555;
                            match (lo_pb.clone(), hi_pc.clone()) {
                                (crate::check::types::Col::CFlex(_), crate::check::types::Col::CFlex(_)) => prism_rtl::Turn::Finished(s_p9.clone()),
                                (crate::check::types::Col::CFlex(_), crate::check::types::Col::CUnbound) => prism_rtl::Turn::Finished(s_p9.clone()),
                                (crate::check::types::Col::CFlex(x_pd), other_pe) => if is_own_col_f(&s_p9, &lo_pb) {
                                    prism_rtl::Turn::Finished(bind_col_f(&s_p9, &x_pd, &other_pe))
                                } else {
                                    prism_rtl::Turn::Finished(s_p9.clone())
                                },
                                (crate::check::types::Col::CRigid(r_pf), crate::check::types::Col::CFlex(y_pg)) => if is_own_col_f(&s_p9, &hi_pc) {
                                    prism_rtl::Turn::Finished(bind_col_f(&s_p9, &y_pg, &lo_pb))
                                } else {
                                    prism_rtl::Turn::Finished(s_p9.clone())
                                },
                                _ => prism_rtl::Turn::Finished(s_p9.clone()),
                            }
                        })
                    })
                }))) as Rc<dyn Fn((crate::check::types::St, crate::check::types::CLeq)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>).cycle()
            })
        }))
    }
}

/// `Start GeneralizeCols, x`: what the function value is when passed to `@Run`.
pub fn start_generalize_cols_f(st0_p0: crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(GeneralizeCols { st0_p0 })
}

/// ```prism
/// LowerJoined: unbounded fn St -> St
/// ```
pub fn lower_joined_f(st_p0: &crate::check::types::St) -> crate::check::types::St {
    let (st2_p8, changed_p9) = crate::prelude::run_to_end(crate::prelude::fold_job(st_p0.cleqs_p.clone(), (st_p0.clone(), false), Rc::new(move |(p0, p1): ((crate::check::types::St, bool), crate::check::types::CLeq)| crate::prelude::entered(crate::prelude::once_job(move || {
        let (s_p1, ch_p2) = p0;
        let c_p3 = p1;
        crate::prelude::call_then(start_walk_col_f(s_p1.clone(), c_p3.lo_p.clone()), move |walk_col_f_7100: crate::check::types::Col| crate::prelude::call_then(start_walk_col_f(s_p1.clone(), c_p3.hi_p.clone()), move |walk_col_f_7119: crate::check::types::Col| match (walk_col_f_7100, walk_col_f_7119) {
            (crate::check::types::Col::CFlex(x_p4), crate::check::types::Col::CFlex(y_p5)) => {
                let lx_p6 = crate::check::types::recording::info_of_f(&s_p1, &x_p4).level_p.clone();
                let ly_p7 = crate::check::types::recording::info_of_f(&s_p1, &y_p5).level_p.clone();
                if ((&lx_p6 > &s_p1.level_p) && (&ly_p7 <= &s_p1.level_p)) && (&lx_p6 > &ly_p7) {
                    prism_rtl::Turn::Finished((crate::check::types::unify::lower_one_f(&s_p1, &x_p4, &ly_p7), true))
                } else {
                    if ((&ly_p7 > &s_p1.level_p) && (&lx_p6 <= &s_p1.level_p)) && (&ly_p7 > &lx_p6) {
                        prism_rtl::Turn::Finished((crate::check::types::unify::lower_one_f(&s_p1, &y_p5, &lx_p6), true))
                    } else {
                        prism_rtl::Turn::Finished((s_p1.clone(), ch_p2))
                    }
                }
            },
            _ => prism_rtl::Turn::Finished((s_p1.clone(), ch_p2)),
        }))
    }))) as Rc<dyn Fn(((crate::check::types::St, bool), crate::check::types::CLeq)) -> Rc<dyn prism_rtl::Job<(crate::check::types::St, bool)>>>));
    if changed_p9 { lower_joined_f(&st2_p8) } else { st2_p8.clone() }
}

/// The step machine of `LowerJoined`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LowerJoined: unbounded fn St -> St
/// ```
pub struct LowerJoined {
    pub st_p0: crate::check::types::St,
}

impl prism_rtl::Job<crate::check::types::St> for LowerJoined {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st_p0 = &self.st_p0;
        let st_p0x = st_p0.clone();
        crate::prelude::call_value(crate::prelude::fold_job(st_p0x.cleqs_p.clone(), (st_p0x.clone(), false), Rc::new(move |(p0, p1): ((crate::check::types::St, bool), crate::check::types::CLeq)| crate::prelude::entered(crate::prelude::once_job(move || {
            let (s_p1, ch_p2) = p0;
            let c_p3 = p1;
            crate::prelude::call_then(start_walk_col_f(s_p1.clone(), c_p3.lo_p.clone()), move |walk_col_f_7100: crate::check::types::Col| crate::prelude::call_then(start_walk_col_f(s_p1.clone(), c_p3.hi_p.clone()), move |walk_col_f_7119: crate::check::types::Col| match (walk_col_f_7100, walk_col_f_7119) {
                (crate::check::types::Col::CFlex(x_p4), crate::check::types::Col::CFlex(y_p5)) => {
                    let lx_p6 = crate::check::types::recording::info_of_f(&s_p1, &x_p4).level_p.clone();
                    let ly_p7 = crate::check::types::recording::info_of_f(&s_p1, &y_p5).level_p.clone();
                    if ((&lx_p6 > &s_p1.level_p) && (&ly_p7 <= &s_p1.level_p)) && (&lx_p6 > &ly_p7) {
                        prism_rtl::Turn::Finished((crate::check::types::unify::lower_one_f(&s_p1, &x_p4, &ly_p7), true))
                    } else {
                        if ((&ly_p7 > &s_p1.level_p) && (&lx_p6 <= &s_p1.level_p)) && (&ly_p7 > &lx_p6) {
                            prism_rtl::Turn::Finished((crate::check::types::unify::lower_one_f(&s_p1, &y_p5, &lx_p6), true))
                        } else {
                            prism_rtl::Turn::Finished((s_p1.clone(), ch_p2))
                        }
                    }
                },
                _ => prism_rtl::Turn::Finished((s_p1.clone(), ch_p2)),
            }))
        }))) as Rc<dyn Fn(((crate::check::types::St, bool), crate::check::types::CLeq)) -> Rc<dyn prism_rtl::Job<(crate::check::types::St, bool)>>>), move |fold_7037: (crate::check::types::St, bool)| {
            let (st2_p8, changed_p9) = fold_7037;
            if changed_p9 {
                prism_rtl::Turn::More(Rc::new(LowerJoined { st_p0: st2_p8.clone() }))
            } else {
                prism_rtl::Turn::Finished(st2_p8.clone())
            }
        })
    }
}

/// `Start LowerJoined, x`: what the function value is when passed to `@Run`.
pub fn start_lower_joined_f(st_p0: crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(LowerJoined { st_p0 })
}

/// ```prism
/// CheckColors: unbounded fn St -> St
/// ```
pub fn check_colors_f(st0_p0: &crate::check::types::St) -> crate::check::types::St {
    let st_p1 = propagate_f(&propagate_f(st0_p0, &false), &true);
    let st2_p2 = crate::prelude::run_to_end(crate::prelude::fold_job(st_p1.cleqs_p.clone(), st_p1.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::CLeq)| crate::prelude::entered(crate::prelude::once_job(move || {
        let s_p3 = p0;
        let c_p4 = p1;
        crate::prelude::call_then(start_settled_col_f(s_p3.clone(), c_p4.lo_p.clone()), move |settled_col_f_7897: crate::check::types::Col| {
            let lo_p5 = settled_col_f_7897;
            crate::prelude::call_then(start_settled_col_f(s_p3.clone(), c_p4.hi_p.clone()), move |settled_col_f_7933: crate::check::types::Col| {
                let hi_p6 = settled_col_f_7933;
                if col_leq_f(&lo_p5, &hi_p6) || col_leq_f(&up_col_f(&s_p3, &lo_p5), &up_col_f(&s_p3, &hi_p6)) {
                    prism_rtl::Turn::Finished(s_p3.clone())
                } else {
                    prism_rtl::Turn::Finished(crate::check::types::recording::add_diag_f(&s_p3, &leq_diag_f(&c_p4, &lo_p5, &hi_p6)))
                }
            })
        })
    }))) as Rc<dyn Fn((crate::check::types::St, crate::check::types::CLeq)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>));
    let mut this: crate::check::types::St = st2_p2.clone();
    this.cleqs_p = Array::new();
    this.color_flex_p = Array::new();
    this.col_up_p = Map::new();
    this
}

/// The step machine of `CheckColors`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckColors: unbounded fn St -> St
/// ```
pub struct CheckColors {
    pub st0_p0: crate::check::types::St,
}

impl prism_rtl::Job<crate::check::types::St> for CheckColors {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st0_p0 = &self.st0_p0;
        let st0_p0x = st0_p0.clone();
        crate::prelude::call_then(start_propagate_f(st0_p0x.clone(), false), move |propagate_f_7811: crate::check::types::St| crate::prelude::call_then(start_propagate_f(propagate_f_7811, true), move |propagate_f_7800: crate::check::types::St| {
            let st_p1 = propagate_f_7800;
            crate::prelude::call_value(crate::prelude::fold_job(st_p1.cleqs_p.clone(), st_p1.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::CLeq)| crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p3 = p0;
                let c_p4 = p1;
                crate::prelude::call_then(start_settled_col_f(s_p3.clone(), c_p4.lo_p.clone()), move |settled_col_f_7897: crate::check::types::Col| {
                    let lo_p5 = settled_col_f_7897;
                    crate::prelude::call_then(start_settled_col_f(s_p3.clone(), c_p4.hi_p.clone()), move |settled_col_f_7933: crate::check::types::Col| {
                        let hi_p6 = settled_col_f_7933;
                        if col_leq_f(&lo_p5, &hi_p6) || col_leq_f(&up_col_f(&s_p3, &lo_p5), &up_col_f(&s_p3, &hi_p6)) {
                            prism_rtl::Turn::Finished(s_p3.clone())
                        } else {
                            prism_rtl::Turn::Finished(crate::check::types::recording::add_diag_f(&s_p3, &leq_diag_f(&c_p4, &lo_p5, &hi_p6)))
                        }
                    })
                })
            }))) as Rc<dyn Fn((crate::check::types::St, crate::check::types::CLeq)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>), move |fold_7853: crate::check::types::St| {
                let st2_p2 = fold_7853;
                prism_rtl::Turn::Finished({
                    let mut this: crate::check::types::St = st2_p2.clone();
                    this.cleqs_p = Array::new();
                    this.color_flex_p = Array::new();
                    this.col_up_p = Map::new();
                    this
                })
            })
        }))
    }
}

/// `Start CheckColors, x`: what the function value is when passed to `@Run`.
pub fn start_check_colors_f(st0_p0: crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckColors { st0_p0 })
}

/// ```prism
/// LeqDiag: fn CLeq, Col, Col -> CDiag
/// ```
pub fn leq_diag_f(c_p0: &crate::check::types::CLeq, lo_p1: &crate::check::types::Col, hi_p2: &crate::check::types::Col) -> crate::check::errors::CDiag {
    if &c_p0.kind_p == &Text::lit("lifted") {
        crate::check::errors::diag_fix_f(&Text::lit("lifted-unbounded"), &c_p0.file_p, &c_p0.span_p, &Text::from(format!("{} `{}` lifted over `{}`; use `@Run`", &col_word_f(lo_p1), &c_p0.name_p, &c_p0.why_p)), &Text::from(format!("run it through `!done <- @Run {}, ...`", &c_p0.name_p)))
    } else {
        if &c_p0.kind_p == &Text::lit("arg") {
            crate::check::errors::diag_fix_f(&Text::lit("calls-unbounded"), &c_p0.file_p, &c_p0.span_p, &Text::from(format!("{} `{}` takes a {} closure; this one is {}", &col_word_f(hi_p2), &c_p0.name_p, &col_word_f(hi_p2), &col_word_f(lo_p1))), &Text::lit("mark the parameter `unbounded fn`, or run the work through `@Run`"))
        } else {
            if &c_p0.kind_p == &Text::lit("lambda") {
                crate::check::errors::diag_fix_f(&Text::lit("calls-unbounded"), &c_p0.file_p, &c_p0.span_p, &Text::from(format!("this {} lambda calls {} `{}`", &col_word_f(hi_p2), &col_word_f(lo_p1), &c_p0.why_p)), &Text::lit("mark the function type it meets `unbounded fn`, or run the call through `@Run`"))
            } else {
                crate::check::errors::diag_fix_f(&Text::lit("calls-unbounded"), &c_p0.file_p, &c_p0.span_p, &Text::from(format!("{} `{}` calls {} `{}`", &col_word_f(hi_p2), &c_p0.name_p, &col_word_f(lo_p1), &c_p0.why_p)), &Text::from(format!("mark `{}` `unbounded fn`, or run the call through `@Run`", &c_p0.name_p)))
            }
        }
    }
}

/// ```prism
/// SettleBody: unbounded fn St, Col, Text -> St
/// ```
pub fn settle_body_f(st0_p0: &crate::check::types::St, col_p1: &crate::check::types::Col, name_p2: &Text) -> crate::check::types::St {
    let st_p3 = propagate_f(st0_p0, &false);
    let waiting_p4 = st_p3.color_flex_p.clone();
    let cleared_p5 = {
        let mut this: crate::check::types::St = st_p3.clone();
        this.color_flex_p = Array::new();
        this
    };
    crate::prelude::run_to_end(crate::prelude::fold_job(waiting_p4.clone(), cleared_p5.clone(), {
        let col_p1x = col_p1.clone();
        let name_p2x = name_p2.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, (crate::check::types::Col, Text, crate::syntax::Range))| {
            let col_p1xy = col_p1x.clone();
            let name_p2xy = name_p2x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let s_p6 = p0;
                let (c_p7, why_p8, span_p9) = p1;
                crate::prelude::call_then(start_walk_col_f(s_p6.clone(), c_p7.clone()), move |walk_col_f_9404: crate::check::types::Col| match walk_col_f_9404 {
                    crate::check::types::Col::CFlex(n_pa) => prism_rtl::Turn::More(Rc::new(AddLeq { st_p0: s_p6.clone(), lo0_p1: crate::check::types::Col::CFlex(n_pa.clone()), hi0_p2: col_p1xy.clone(), span_p3: span_p9.clone(), kind_p4: if &name_p2xy == &Text::lit("") { Text::lit("lambda") } else { Text::lit("body") }, name_p5: name_p2xy.clone(), why_p6: why_p8.clone() })),
                    known_pb => prism_rtl::Turn::Finished(join_known_f(&s_p6, &known_pb, &why_p8)),
                })
            }))
        }) as Rc<dyn Fn((crate::check::types::St, (crate::check::types::Col, Text, crate::syntax::Range))) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `SettleBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SettleBody: unbounded fn St, Col, Text -> St
/// ```
pub struct SettleBody {
    pub st0_p0: crate::check::types::St,
    pub col_p1: crate::check::types::Col,
    pub name_p2: Text,
}

impl prism_rtl::Job<crate::check::types::St> for SettleBody {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st0_p0 = &self.st0_p0;
        let col_p1 = &self.col_p1;
        let name_p2 = &self.name_p2;
        let col_p1x = col_p1.clone();
        let name_p2x = name_p2.clone();
        let st0_p0x = st0_p0.clone();
        crate::prelude::call_then(start_propagate_f(st0_p0x.clone(), false), move |propagate_f_9238: crate::check::types::St| {
            let st_p3 = propagate_f_9238;
            let waiting_p4 = st_p3.color_flex_p.clone();
            let cleared_p5 = {
                let mut this: crate::check::types::St = st_p3.clone();
                this.color_flex_p = Array::new();
                this
            };
            crate::prelude::fold_job(waiting_p4.clone(), cleared_p5.clone(), {
                let col_p1xx = col_p1x.clone();
                let name_p2xx = name_p2x.clone();
                Rc::new(move |(p0, p1): (crate::check::types::St, (crate::check::types::Col, Text, crate::syntax::Range))| {
                    let col_p1xxy = col_p1xx.clone();
                    let name_p2xxy = name_p2xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let s_p6 = p0;
                        let (c_p7, why_p8, span_p9) = p1;
                        crate::prelude::call_then(start_walk_col_f(s_p6.clone(), c_p7.clone()), move |walk_col_f_9404: crate::check::types::Col| match walk_col_f_9404 {
                            crate::check::types::Col::CFlex(n_pa) => prism_rtl::Turn::More(Rc::new(AddLeq { st_p0: s_p6.clone(), lo0_p1: crate::check::types::Col::CFlex(n_pa.clone()), hi0_p2: col_p1xxy.clone(), span_p3: span_p9.clone(), kind_p4: if &name_p2xxy == &Text::lit("") { Text::lit("lambda") } else { Text::lit("body") }, name_p5: name_p2xxy.clone(), why_p6: why_p8.clone() })),
                            known_pb => prism_rtl::Turn::Finished(join_known_f(&s_p6, &known_pb, &why_p8)),
                        })
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, (crate::check::types::Col, Text, crate::syntax::Range))) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            }).cycle()
        })
    }
}

/// `Start SettleBody, x`: what the function value is when passed to `@Run`.
pub fn start_settle_body_f(st0_p0: crate::check::types::St, col_p1: crate::check::types::Col, name_p2: Text) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(SettleBody { st0_p0, col_p1, name_p2 })
}
