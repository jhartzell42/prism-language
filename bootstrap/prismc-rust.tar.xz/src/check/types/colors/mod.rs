//! The module `Check.Types.Colors`, from `target/bootstrap/src/prismc/check/types/colors.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// JoinCol: fn Col, Col -> Col
/// ```
pub fn join_col(col0: &crate::check::types::Col, col1: &crate::check::types::Col) -> crate::check::types::Col {
    match (col0, col1) {
        (crate::check::types::Col::CBound, c) => c.clone(),
        (c, crate::check::types::Col::CBound) => c.clone(),
        (crate::check::types::Col::CUnbound, _) => crate::check::types::Col::CUnbound,
        (_, crate::check::types::Col::CUnbound) => crate::check::types::Col::CUnbound,
        (a, b) => if a == b { a.clone() } else { crate::check::types::Col::CUnbound },
    }
}

/// ```prism
/// ColLeq: fn Col, Col -> Bool
/// ```
pub fn col_leq(a: &crate::check::types::Col, b: &crate::check::types::Col) -> bool {
    &join_col(a, b) == b
}

/// ```prism
/// ColWord: fn Col -> Text
/// ```
pub fn col_word(col0: &crate::check::types::Col) -> Text {
    match col0 {
        crate::check::types::Col::CBound => Text::lit("bounded"),
        crate::check::types::Col::CUnbound => Text::lit("unbounded"),
        crate::check::types::Col::CRigid(n) => Text::from(format!("`{}`-colored", n)),
        crate::check::types::Col::CQ(n) => Text::from(format!("`{}`-colored", n)),
        crate::check::types::Col::CFlex(_) => Text::lit("bounded"),
    }
}

/// ```prism
/// UseColor: unbounded fn St, Col, Text, Range -> St
/// ```
pub fn use_color(st: &crate::check::types::St, c0: &crate::check::types::Col, why: &Text, span: &crate::syntax::Range) -> crate::check::types::St {
    match walk_col(st, c0) {
        crate::check::types::Col::CFlex(n) => {
            let mut this: crate::check::types::St = st.clone();
            this.color_flex = push(&this.color_flex, &(crate::check::types::Col::CFlex(n.clone()), why.clone(), span.clone()));
            this
        },
        c => join_known(st, &c, why),
    }
}

/// The step machine of `UseColor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UseColor: unbounded fn St, Col, Text, Range -> St
/// ```
pub struct UseColor {
    pub st: crate::check::types::St,
    pub c0: crate::check::types::Col,
    pub why: Text,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::check::types::St> for UseColor {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st = &self.st;
        let c0 = &self.c0;
        let why = &self.why;
        let span = &self.span;
        let c0 = c0.clone();
        let span = span.clone();
        let st = st.clone();
        let why = why.clone();
        call_then(start_walk_col(st.clone(), c0.clone()), move |walk_col_1582: crate::check::types::Col| match walk_col_1582 {
            crate::check::types::Col::CFlex(n) => prism_rtl::Turn::Finished({
                let mut this: crate::check::types::St = st.clone();
                this.color_flex = push(&this.color_flex, &(crate::check::types::Col::CFlex(n.clone()), why.clone(), span.clone()));
                this
            }),
            c => prism_rtl::Turn::Finished(join_known(&st, &c, &why)),
        })
    }
}

/// `Start UseColor, x`: what the function value is when passed to `@Run`.
pub fn start_use_color(st: crate::check::types::St, c0: crate::check::types::Col, why: Text, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(UseColor { st, c0, why, span })
}

/// ```prism
/// JoinKnown: fn St, Col, Text -> St
/// ```
pub fn join_known(st: &crate::check::types::St, c0: &crate::check::types::Col, why: &Text) -> crate::check::types::St {
    let c = up_col(st, c0);
    let mut this: crate::check::types::St = st.clone();
    if !col_leq(&c, &this.color) {
        this.color_why = why.clone();
    }
    this.color = join_col(&this.color, &c);
    this
}

/// ```prism
/// UpCol: fn St, Col -> Col
/// ```
pub fn up_col(st: &crate::check::types::St, col1: &crate::check::types::Col) -> crate::check::types::Col {
    match col1 {
        crate::check::types::Col::CRigid(n) => match get(&st.col_up, n) {
            Some(up) => crate::check::types::Col::CRigid(up.clone()),
            None => crate::check::types::Col::CRigid(n.clone()),
        },
        c => c.clone(),
    }
}

/// ```prism
/// WalkCol: unbounded fn St, Col -> Col
/// ```
pub fn walk_col(st: &crate::check::types::St, col1: &crate::check::types::Col) -> crate::check::types::Col {
    match col1 {
        crate::check::types::Col::CFlex(n) => match get(&st.cols, n) {
            Some(c) => walk_col(st, &c),
            None => crate::check::types::Col::CFlex(n.clone()),
        },
        c => c.clone(),
    }
}

/// The step machine of `WalkCol`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WalkCol: unbounded fn St, Col -> Col
/// ```
pub struct WalkCol {
    pub st: crate::check::types::St,
    pub col1: crate::check::types::Col,
}

impl prism_rtl::Job<crate::check::types::Col> for WalkCol {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Col> {
        let st = &self.st;
        let col1 = &self.col1;
        match col1 {
            crate::check::types::Col::CFlex(n) => match get(&st.cols, n) {
                Some(c) => prism_rtl::Turn::More(Rc::new(WalkCol { st: st.clone(), col1: c.clone() })),
                None => prism_rtl::Turn::Finished(crate::check::types::Col::CFlex(n.clone())),
            },
            c => prism_rtl::Turn::Finished(c.clone()),
        }
    }
}

/// `Start WalkCol, x`: what the function value is when passed to `@Run`.
pub fn start_walk_col(st: crate::check::types::St, col1: crate::check::types::Col) -> Rc<dyn prism_rtl::Job<crate::check::types::Col>> {
    Rc::new(WalkCol { st, col1 })
}

/// ```prism
/// IsRigidCol: fn Col -> Bool
/// ```
pub fn is_rigid_col(col0: &crate::check::types::Col) -> bool {
    match col0 {
        crate::check::types::Col::CRigid(_) => true,
        _ => false,
    }
}

/// ```prism
/// IsOwnCol: fn St, Col -> Bool
/// ```
pub fn is_own_col(s: &crate::check::types::St, col1: &crate::check::types::Col) -> bool {
    match col1 {
        crate::check::types::Col::CFlex(n) => &crate::check::types::recording::info_of(s, n).level > &s.level,
        _ => false,
    }
}

/// ```prism
/// IsFlexCol: fn Col -> Bool
/// ```
pub fn is_flex_col(col0: &crate::check::types::Col) -> bool {
    match col0 {
        crate::check::types::Col::CFlex(_) => true,
        _ => false,
    }
}

/// ```prism
/// SettledCol: unbounded fn St, Col -> Col
/// ```
pub fn settled_col(st: &crate::check::types::St, c: &crate::check::types::Col) -> crate::check::types::Col {
    match walk_col(st, c) {
        crate::check::types::Col::CFlex(_) => crate::check::types::Col::CBound,
        other => other.clone(),
    }
}

/// The step machine of `SettledCol`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SettledCol: unbounded fn St, Col -> Col
/// ```
pub struct SettledCol {
    pub st: crate::check::types::St,
    pub c: crate::check::types::Col,
}

impl prism_rtl::Job<crate::check::types::Col> for SettledCol {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Col> {
        let st = &self.st;
        let c = &self.c;
        let c = c.clone();
        let st = st.clone();
        call_then(start_walk_col(st.clone(), c.clone()), move |walk_col_2936: crate::check::types::Col| match walk_col_2936 {
            crate::check::types::Col::CFlex(_) => prism_rtl::Turn::Finished(crate::check::types::Col::CBound),
            other => prism_rtl::Turn::Finished(other.clone()),
        })
    }
}

/// `Start SettledCol, x`: what the function value is when passed to `@Run`.
pub fn start_settled_col(st: crate::check::types::St, c: crate::check::types::Col) -> Rc<dyn prism_rtl::Job<crate::check::types::Col>> {
    Rc::new(SettledCol { st, c })
}

/// ```prism
/// UnifyCol: unbounded fn St, Col, Col -> ((Text, St))
/// ```
pub fn unify_col(st: &crate::check::types::St, a0: &crate::check::types::Col, b0: &crate::check::types::Col) -> (Text, crate::check::types::St) {
    let a = walk_col(st, a0);
    let b = walk_col(st, b0);
    if &a == &b {
        (Text::lit(""), st.clone())
    } else {
        match (a.clone(), b.clone()) {
            (crate::check::types::Col::CFlex(x), other) => (Text::lit(""), bind_col(st, &x, &other)),
            (other, crate::check::types::Col::CFlex(y)) => (Text::lit(""), bind_col(st, &y, &other)),
            (crate::check::types::Col::CQ(_), _) => (Text::lit(""), st.clone()),
            (_, crate::check::types::Col::CQ(_)) => (Text::lit(""), st.clone()),
            _ => (Text::lit("mismatch"), st.clone()),
        }
    }
}

/// The step machine of `UnifyCol`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyCol: unbounded fn St, Col, Col -> ((Text, St))
/// ```
pub struct UnifyCol {
    pub st: crate::check::types::St,
    pub a0: crate::check::types::Col,
    pub b0: crate::check::types::Col,
}

impl prism_rtl::Job<(Text, crate::check::types::St)> for UnifyCol {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::check::types::St)> {
        let st = &self.st;
        let a0 = &self.a0;
        let b0 = &self.b0;
        let a0 = a0.clone();
        let b0 = b0.clone();
        let st = st.clone();
        call_then(start_walk_col(st.clone(), a0.clone()), move |walk_col_3231: crate::check::types::Col| {
            let a = walk_col_3231;
            call_then(start_walk_col(st.clone(), b0.clone()), move |walk_col_3258: crate::check::types::Col| {
                let b = walk_col_3258;
                if &a == &b {
                    prism_rtl::Turn::Finished((Text::lit(""), st.clone()))
                } else {
                    match (a.clone(), b.clone()) {
                        (crate::check::types::Col::CFlex(x), other) => prism_rtl::Turn::Finished((Text::lit(""), bind_col(&st, &x, &other))),
                        (other, crate::check::types::Col::CFlex(y)) => prism_rtl::Turn::Finished((Text::lit(""), bind_col(&st, &y, &other))),
                        (crate::check::types::Col::CQ(_), _) => prism_rtl::Turn::Finished((Text::lit(""), st.clone())),
                        (_, crate::check::types::Col::CQ(_)) => prism_rtl::Turn::Finished((Text::lit(""), st.clone())),
                        _ => prism_rtl::Turn::Finished((Text::lit("mismatch"), st.clone())),
                    }
                }
            })
        })
    }
}

/// `Start UnifyCol, x`: what the function value is when passed to `@Run`.
pub fn start_unify_col(st: crate::check::types::St, a0: crate::check::types::Col, b0: crate::check::types::Col) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::St)>> {
    Rc::new(UnifyCol { st, a0, b0 })
}

/// ```prism
/// BindCol: fn St, Nat, Col -> St
/// ```
pub fn bind_col(st: &crate::check::types::St, n: &Nat, c: &crate::check::types::Col) -> crate::check::types::St {
    let st2 = match c {
        crate::check::types::Col::CFlex(m) => crate::check::types::unify::lower_one(st, m, &crate::check::types::recording::info_of(st, n).level),
        _ => st.clone(),
    };
    let mut this: crate::check::types::St = st2.clone();
    this.cols = insert(&this.cols, n, c);
    this
}

/// ```prism
/// FreeColVars: unbounded fn St, Ty -> [Nat]
/// ```
pub fn free_col_vars(st: &crate::check::types::St, t: &crate::check::types::Ty) -> Array<Nat> {
    free_cols_into(st, &Array::new(), t)
}

/// The step machine of `FreeColVars`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FreeColVars: unbounded fn St, Ty -> [Nat]
/// ```
pub struct FreeColVars {
    pub st: crate::check::types::St,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<Array<Nat>> for FreeColVars {
    fn cycle(&self) -> prism_rtl::Turn<Array<Nat>> {
        let st = &self.st;
        let t = &self.t;
        prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: Array::new(), t: t.clone() }))
    }
}

/// `Start FreeColVars, x`: what the function value is when passed to `@Run`.
pub fn start_free_col_vars(st: crate::check::types::St, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Array<Nat>>> {
    Rc::new(FreeColVars { st, t })
}

/// ```prism
/// FreeColsInto: unbounded fn St, [Nat], Ty -> [Nat]
/// ```
pub fn free_cols_into(st: &crate::check::types::St, acc: &Array<Nat>, t: &crate::check::types::Ty) -> Array<Nat> {
    match crate::check::types::recording::walk(st, t) {
        crate::check::types::Ty::TyCon(_, args) => run_to_end(fold_job(args.clone(), acc.clone(), {
            let st = st.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                let st = st.clone();
                entered(once_job(move || {
                    let a = p0;
                    let x = p1;
                    prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: a.clone(), t: x.clone() }))
                }))
            }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        })),
        crate::check::types::Ty::TyFn(c, ps, res) => {
            let acc2 = match walk_col(st, &c) {
                crate::check::types::Col::CFlex(n) => crate::check::types::add_nat(acc, &n),
                _ => acc.clone(),
            };
            free_cols_into(st, &run_to_end(fold_job(ps.clone(), acc2.clone(), {
                let st = st.clone();
                Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let a = p0;
                        let x = p1;
                        prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: a.clone(), t: x.clone() }))
                    }))
                }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
            })), &*res)
        },
        crate::check::types::Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), acc.clone(), {
            let st = st.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                let st = st.clone();
                entered(once_job(move || {
                    let a = p0;
                    let x = p1;
                    prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: a.clone(), t: x.clone() }))
                }))
            }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        })),
        crate::check::types::Ty::TyArray(e) => free_cols_into(st, acc, &*e),
        crate::check::types::Ty::TyMap(k, v_) => free_cols_into(st, &free_cols_into(st, acc, &*k), &*v_),
        crate::check::types::Ty::TySig(_, i) => free_cols_into(st, acc, &*i),
        crate::check::types::Ty::TyAt(i, _) => free_cols_into(st, acc, &*i),
        crate::check::types::Ty::TyElem(_, o) => free_cols_into(st, acc, &*o),
        crate::check::types::Ty::TyAssoc(_, a) => free_cols_into(st, acc, &*a),
        _ => acc.clone(),
    }
}

/// The step machine of `FreeColsInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FreeColsInto: unbounded fn St, [Nat], Ty -> [Nat]
/// ```
pub struct FreeColsInto {
    pub st: crate::check::types::St,
    pub acc: Array<Nat>,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<Array<Nat>> for FreeColsInto {
    fn cycle(&self) -> prism_rtl::Turn<Array<Nat>> {
        let st = &self.st;
        let acc = &self.acc;
        let t = &self.t;
        let acc = acc.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check::types::recording::start_walk(st.clone(), t.clone()), move |walk_3992: crate::check::types::Ty| match walk_3992 {
            crate::check::types::Ty::TyCon(_, args) => fold_job(args.clone(), acc.clone(), {
                let st = st.clone();
                Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let a = p0;
                        let x = p1;
                        prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: a.clone(), t: x.clone() }))
                    }))
                }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
            }).cycle(),
            crate::check::types::Ty::TyFn(c, ps, res) => call_then(start_walk_col(st.clone(), c.clone()), move |walk_col_4120: crate::check::types::Col| {
                let acc2 = match walk_col_4120 {
                    crate::check::types::Col::CFlex(n) => crate::check::types::add_nat(&acc, &n),
                    _ => acc.clone(),
                };
                call_value(fold_job(ps.clone(), acc2.clone(), {
                    let st = st.clone();
                    Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                        let st = st.clone();
                        entered(once_job(move || {
                            let a = p0;
                            let x = p1;
                            prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: a.clone(), t: x.clone() }))
                        }))
                    }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
                }), move |fold_4223: Array<Nat>| prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: fold_4223, t: (*res).clone() })))
            }),
            crate::check::types::Ty::TyTuple(ts) => fold_job(ts.clone(), acc.clone(), {
                let st = st.clone();
                Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let a = p0;
                        let x = p1;
                        prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: a.clone(), t: x.clone() }))
                    }))
                }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
            }).cycle(),
            crate::check::types::Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: acc.clone(), t: (*e).clone() })),
            crate::check::types::Ty::TyMap(k, v_) => call_then(start_free_cols_into(st.clone(), acc.clone(), (*k).clone()), move |free_cols_into_4407: Array<Nat>| prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: free_cols_into_4407, t: (*v_).clone() }))),
            crate::check::types::Ty::TySig(_, i) => prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: acc.clone(), t: (*i).clone() })),
            crate::check::types::Ty::TyAt(i, _) => prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: acc.clone(), t: (*i).clone() })),
            crate::check::types::Ty::TyElem(_, o) => prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: acc.clone(), t: (*o).clone() })),
            crate::check::types::Ty::TyAssoc(_, a) => prism_rtl::Turn::More(Rc::new(FreeColsInto { st: st.clone(), acc: acc.clone(), t: (*a).clone() })),
            _ => prism_rtl::Turn::Finished(acc.clone()),
        })
    }
}

/// `Start FreeColsInto, x`: what the function value is when passed to `@Run`.
pub fn start_free_cols_into(st: crate::check::types::St, acc: Array<Nat>, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Array<Nat>>> {
    Rc::new(FreeColsInto { st, acc, t })
}

/// ```prism
/// AddLeq: unbounded fn St, Col, Col, Range, Text, Text, Text -> St
/// ```
pub fn add_leq(st: &crate::check::types::St, lo0: &crate::check::types::Col, hi0: &crate::check::types::Col, span: &crate::syntax::Range, kind: &Text, name: &Text, why: &Text) -> crate::check::types::St {
    let lo = walk_col(st, lo0);
    let hi = walk_col(st, hi0);
    if ((&lo == &crate::check::types::Col::CBound) || (&hi == &crate::check::types::Col::CUnbound)) || (&lo == &hi) {
        st.clone()
    } else {
        {
            let mut this: crate::check::types::St = st.clone();
            this.cleqs = push(&this.cleqs, &crate::check::types::CLeq { lo: lo.clone(), hi: hi.clone(), file: this.file.clone(), span: span.clone(), kind: kind.clone(), name: name.clone(), why: why.clone() });
            this
        }
    }
}

/// The step machine of `AddLeq`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AddLeq: unbounded fn St, Col, Col, Range, Text, Text, Text -> St
/// ```
pub struct AddLeq {
    pub st: crate::check::types::St,
    pub lo0: crate::check::types::Col,
    pub hi0: crate::check::types::Col,
    pub span: crate::syntax::Range,
    pub kind: Text,
    pub name: Text,
    pub why: Text,
}

impl prism_rtl::Job<crate::check::types::St> for AddLeq {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st = &self.st;
        let lo0 = &self.lo0;
        let hi0 = &self.hi0;
        let span = &self.span;
        let kind = &self.kind;
        let name = &self.name;
        let why = &self.why;
        let hi0 = hi0.clone();
        let kind = kind.clone();
        let lo0 = lo0.clone();
        let name = name.clone();
        let span = span.clone();
        let st = st.clone();
        let why = why.clone();
        call_then(start_walk_col(st.clone(), lo0.clone()), move |walk_col_4883: crate::check::types::Col| {
            let lo = walk_col_4883;
            call_then(start_walk_col(st.clone(), hi0.clone()), move |walk_col_4912: crate::check::types::Col| {
                let hi = walk_col_4912;
                if ((&lo == &crate::check::types::Col::CBound) || (&hi == &crate::check::types::Col::CUnbound)) || (&lo == &hi) {
                    prism_rtl::Turn::Finished(st.clone())
                } else {
                    prism_rtl::Turn::Finished({
                        let mut this: crate::check::types::St = st.clone();
                        this.cleqs = push(&this.cleqs, &crate::check::types::CLeq { lo: lo.clone(), hi: hi.clone(), file: this.file.clone(), span: span.clone(), kind: kind.clone(), name: name.clone(), why: why.clone() });
                        this
                    })
                }
            })
        })
    }
}

/// `Start AddLeq, x`: what the function value is when passed to `@Run`.
pub fn start_add_leq(st: crate::check::types::St, lo0: crate::check::types::Col, hi0: crate::check::types::Col, span: crate::syntax::Range, kind: Text, name: Text, why: Text) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(AddLeq { st, lo0, hi0, span, kind, name, why })
}

/// ```prism
/// Propagate: unbounded fn St, Bool -> St
/// ```
pub fn propagate(st: &crate::check::types::St, rigid: &bool) -> crate::check::types::St {
    let (st2, changed) = run_to_end(fold_job(st.cleqs.clone(), (st.clone(), false), {
        let rigid = *rigid;
        Rc::new(move |(p0, p1): ((crate::check::types::St, bool), crate::check::types::CLeq)| {
            let rigid = rigid;
            entered(once_job(move || {
                let (s, ch) = p0;
                let c = p1;
                call_then(start_walk_col(s.clone(), c.lo.clone()), move |walk_col_5490: crate::check::types::Col| {
                    let lo = walk_col_5490;
                    call_then(start_walk_col(s.clone(), c.hi.clone()), move |walk_col_5520: crate::check::types::Col| match walk_col_5520 {
                        crate::check::types::Col::CFlex(h) => {
                            let forced = (&lo == &crate::check::types::Col::CUnbound) || (rigid && is_rigid_col(&lo));
                            if forced {
                                prism_rtl::Turn::Finished((bind_col(&s, &h, &lo), true))
                            } else {
                                prism_rtl::Turn::Finished((s.clone(), ch))
                            }
                        },
                        _ => prism_rtl::Turn::Finished((s.clone(), ch)),
                    })
                })
            }))
        }) as Rc<dyn Fn(((crate::check::types::St, bool), crate::check::types::CLeq)) -> Rc<dyn prism_rtl::Job<(crate::check::types::St, bool)>>>
    }));
    if changed { propagate(&st2, rigid) } else { st2.clone() }
}

/// The step machine of `Propagate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Propagate: unbounded fn St, Bool -> St
/// ```
pub struct Propagate {
    pub st: crate::check::types::St,
    pub rigid: bool,
}

impl prism_rtl::Job<crate::check::types::St> for Propagate {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st = &self.st;
        let rigid = &self.rigid;
        let rigid = *rigid;
        let st = st.clone();
        call_value(fold_job(st.cleqs.clone(), (st.clone(), false), {
            let rigid = rigid;
            Rc::new(move |(p0, p1): ((crate::check::types::St, bool), crate::check::types::CLeq)| {
                let rigid = rigid;
                entered(once_job(move || {
                    let (s, ch) = p0;
                    let c = p1;
                    call_then(start_walk_col(s.clone(), c.lo.clone()), move |walk_col_5490: crate::check::types::Col| {
                        let lo = walk_col_5490;
                        call_then(start_walk_col(s.clone(), c.hi.clone()), move |walk_col_5520: crate::check::types::Col| match walk_col_5520 {
                            crate::check::types::Col::CFlex(h) => {
                                let forced = (&lo == &crate::check::types::Col::CUnbound) || (rigid && is_rigid_col(&lo));
                                if forced {
                                    prism_rtl::Turn::Finished((bind_col(&s, &h, &lo), true))
                                } else {
                                    prism_rtl::Turn::Finished((s.clone(), ch))
                                }
                            },
                            _ => prism_rtl::Turn::Finished((s.clone(), ch)),
                        })
                    })
                }))
            }) as Rc<dyn Fn(((crate::check::types::St, bool), crate::check::types::CLeq)) -> Rc<dyn prism_rtl::Job<(crate::check::types::St, bool)>>>
        }), move |fold_5427: (crate::check::types::St, bool)| {
            let (st2, changed) = fold_5427;
            if changed {
                prism_rtl::Turn::More(Rc::new(Propagate { st: st2.clone(), rigid }))
            } else {
                prism_rtl::Turn::Finished(st2.clone())
            }
        })
    }
}

/// `Start Propagate, x`: what the function value is when passed to `@Run`.
pub fn start_propagate(st: crate::check::types::St, rigid: bool) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(Propagate { st, rigid })
}

/// ```prism
/// GeneralizeCols: unbounded fn St -> St
/// ```
pub fn generalize_cols(st0: &crate::check::types::St) -> crate::check::types::St {
    let st1 = lower_joined(&propagate(st0, &false));
    let st2 = run_to_end(fold_job(st1.cleqs.clone(), st1.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::CLeq)| entered(once_job(move || {
        let s = p0;
        let c = p1;
        call_then(start_walk_col(s.clone(), c.lo.clone()), move |walk_col_6260: crate::check::types::Col| {
            let lo = walk_col_6260;
            call_then(start_walk_col(s.clone(), c.hi.clone()), move |walk_col_6293: crate::check::types::Col| {
                let hi = walk_col_6293;
                match (lo.clone(), hi.clone()) {
                    (crate::check::types::Col::CFlex(x), crate::check::types::Col::CFlex(y)) => if ((&x != &y) && is_own_col(&s, &lo)) && is_own_col(&s, &hi) {
                        prism_rtl::Turn::Finished(bind_col(&s, &x, &hi))
                    } else {
                        prism_rtl::Turn::Finished(s.clone())
                    },
                    _ => prism_rtl::Turn::Finished(s.clone()),
                }
            })
        })
    }))) as Rc<dyn Fn((crate::check::types::St, crate::check::types::CLeq)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>));
    run_to_end(fold_job(st2.cleqs.clone(), st2.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::CLeq)| entered(once_job(move || {
        let s = p0;
        let c = p1;
        call_then(start_walk_col(s.clone(), c.lo.clone()), move |walk_col_6522: crate::check::types::Col| {
            let lo = walk_col_6522;
            call_then(start_walk_col(s.clone(), c.hi.clone()), move |walk_col_6555: crate::check::types::Col| {
                let hi = walk_col_6555;
                match (lo.clone(), hi.clone()) {
                    (crate::check::types::Col::CFlex(_), crate::check::types::Col::CFlex(_)) => prism_rtl::Turn::Finished(s.clone()),
                    (crate::check::types::Col::CFlex(_), crate::check::types::Col::CUnbound) => prism_rtl::Turn::Finished(s.clone()),
                    (crate::check::types::Col::CFlex(x), other) => if is_own_col(&s, &lo) {
                        prism_rtl::Turn::Finished(bind_col(&s, &x, &other))
                    } else {
                        prism_rtl::Turn::Finished(s.clone())
                    },
                    (crate::check::types::Col::CRigid(r), crate::check::types::Col::CFlex(y)) => if is_own_col(&s, &hi) {
                        prism_rtl::Turn::Finished(bind_col(&s, &y, &lo))
                    } else {
                        prism_rtl::Turn::Finished(s.clone())
                    },
                    _ => prism_rtl::Turn::Finished(s.clone()),
                }
            })
        })
    }))) as Rc<dyn Fn((crate::check::types::St, crate::check::types::CLeq)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>))
}

/// The step machine of `GeneralizeCols`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GeneralizeCols: unbounded fn St -> St
/// ```
pub struct GeneralizeCols {
    pub st0: crate::check::types::St,
}

impl prism_rtl::Job<crate::check::types::St> for GeneralizeCols {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st0 = &self.st0;
        let st0 = st0.clone();
        call_then(start_propagate(st0.clone(), false), move |propagate_6178: crate::check::types::St| call_then(start_lower_joined(propagate_6178), move |lower_joined_6165: crate::check::types::St| {
            let st1 = lower_joined_6165;
            call_value(fold_job(st1.cleqs.clone(), st1.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::CLeq)| entered(once_job(move || {
                let s = p0;
                let c = p1;
                call_then(start_walk_col(s.clone(), c.lo.clone()), move |walk_col_6260: crate::check::types::Col| {
                    let lo = walk_col_6260;
                    call_then(start_walk_col(s.clone(), c.hi.clone()), move |walk_col_6293: crate::check::types::Col| {
                        let hi = walk_col_6293;
                        match (lo.clone(), hi.clone()) {
                            (crate::check::types::Col::CFlex(x), crate::check::types::Col::CFlex(y)) => if ((&x != &y) && is_own_col(&s, &lo)) && is_own_col(&s, &hi) {
                                prism_rtl::Turn::Finished(bind_col(&s, &x, &hi))
                            } else {
                                prism_rtl::Turn::Finished(s.clone())
                            },
                            _ => prism_rtl::Turn::Finished(s.clone()),
                        }
                    })
                })
            }))) as Rc<dyn Fn((crate::check::types::St, crate::check::types::CLeq)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>), move |fold_6214: crate::check::types::St| {
                let st2 = fold_6214;
                fold_job(st2.cleqs.clone(), st2.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::CLeq)| entered(once_job(move || {
                    let s = p0;
                    let c = p1;
                    call_then(start_walk_col(s.clone(), c.lo.clone()), move |walk_col_6522: crate::check::types::Col| {
                        let lo = walk_col_6522;
                        call_then(start_walk_col(s.clone(), c.hi.clone()), move |walk_col_6555: crate::check::types::Col| {
                            let hi = walk_col_6555;
                            match (lo.clone(), hi.clone()) {
                                (crate::check::types::Col::CFlex(_), crate::check::types::Col::CFlex(_)) => prism_rtl::Turn::Finished(s.clone()),
                                (crate::check::types::Col::CFlex(_), crate::check::types::Col::CUnbound) => prism_rtl::Turn::Finished(s.clone()),
                                (crate::check::types::Col::CFlex(x), other) => if is_own_col(&s, &lo) {
                                    prism_rtl::Turn::Finished(bind_col(&s, &x, &other))
                                } else {
                                    prism_rtl::Turn::Finished(s.clone())
                                },
                                (crate::check::types::Col::CRigid(r), crate::check::types::Col::CFlex(y)) => if is_own_col(&s, &hi) {
                                    prism_rtl::Turn::Finished(bind_col(&s, &y, &lo))
                                } else {
                                    prism_rtl::Turn::Finished(s.clone())
                                },
                                _ => prism_rtl::Turn::Finished(s.clone()),
                            }
                        })
                    })
                }))) as Rc<dyn Fn((crate::check::types::St, crate::check::types::CLeq)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>).cycle()
            })
        }))
    }
}

/// `Start GeneralizeCols, x`: what the function value is when passed to `@Run`.
pub fn start_generalize_cols(st0: crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(GeneralizeCols { st0 })
}

/// ```prism
/// LowerJoined: unbounded fn St -> St
/// ```
pub fn lower_joined(st: &crate::check::types::St) -> crate::check::types::St {
    let (st2, changed) = run_to_end(fold_job(st.cleqs.clone(), (st.clone(), false), Rc::new(move |(p0, p1): ((crate::check::types::St, bool), crate::check::types::CLeq)| entered(once_job(move || {
        let (s, ch) = p0;
        let c = p1;
        call_then(start_walk_col(s.clone(), c.lo.clone()), move |walk_col_7100: crate::check::types::Col| call_then(start_walk_col(s.clone(), c.hi.clone()), move |walk_col_7119: crate::check::types::Col| match (walk_col_7100, walk_col_7119) {
            (crate::check::types::Col::CFlex(x), crate::check::types::Col::CFlex(y)) => {
                let lx = crate::check::types::recording::info_of(&s, &x).level.clone();
                let ly = crate::check::types::recording::info_of(&s, &y).level.clone();
                if ((&lx > &s.level) && (&ly <= &s.level)) && (&lx > &ly) {
                    prism_rtl::Turn::Finished((crate::check::types::unify::lower_one(&s, &x, &ly), true))
                } else {
                    if ((&ly > &s.level) && (&lx <= &s.level)) && (&ly > &lx) {
                        prism_rtl::Turn::Finished((crate::check::types::unify::lower_one(&s, &y, &lx), true))
                    } else {
                        prism_rtl::Turn::Finished((s.clone(), ch))
                    }
                }
            },
            _ => prism_rtl::Turn::Finished((s.clone(), ch)),
        }))
    }))) as Rc<dyn Fn(((crate::check::types::St, bool), crate::check::types::CLeq)) -> Rc<dyn prism_rtl::Job<(crate::check::types::St, bool)>>>));
    if changed { lower_joined(&st2) } else { st2.clone() }
}

/// The step machine of `LowerJoined`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LowerJoined: unbounded fn St -> St
/// ```
pub struct LowerJoined {
    pub st: crate::check::types::St,
}

impl prism_rtl::Job<crate::check::types::St> for LowerJoined {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st = &self.st;
        let st = st.clone();
        call_value(fold_job(st.cleqs.clone(), (st.clone(), false), Rc::new(move |(p0, p1): ((crate::check::types::St, bool), crate::check::types::CLeq)| entered(once_job(move || {
            let (s, ch) = p0;
            let c = p1;
            call_then(start_walk_col(s.clone(), c.lo.clone()), move |walk_col_7100: crate::check::types::Col| call_then(start_walk_col(s.clone(), c.hi.clone()), move |walk_col_7119: crate::check::types::Col| match (walk_col_7100, walk_col_7119) {
                (crate::check::types::Col::CFlex(x), crate::check::types::Col::CFlex(y)) => {
                    let lx = crate::check::types::recording::info_of(&s, &x).level.clone();
                    let ly = crate::check::types::recording::info_of(&s, &y).level.clone();
                    if ((&lx > &s.level) && (&ly <= &s.level)) && (&lx > &ly) {
                        prism_rtl::Turn::Finished((crate::check::types::unify::lower_one(&s, &x, &ly), true))
                    } else {
                        if ((&ly > &s.level) && (&lx <= &s.level)) && (&ly > &lx) {
                            prism_rtl::Turn::Finished((crate::check::types::unify::lower_one(&s, &y, &lx), true))
                        } else {
                            prism_rtl::Turn::Finished((s.clone(), ch))
                        }
                    }
                },
                _ => prism_rtl::Turn::Finished((s.clone(), ch)),
            }))
        }))) as Rc<dyn Fn(((crate::check::types::St, bool), crate::check::types::CLeq)) -> Rc<dyn prism_rtl::Job<(crate::check::types::St, bool)>>>), move |fold_7037: (crate::check::types::St, bool)| {
            let (st2, changed) = fold_7037;
            if changed {
                prism_rtl::Turn::More(Rc::new(LowerJoined { st: st2.clone() }))
            } else {
                prism_rtl::Turn::Finished(st2.clone())
            }
        })
    }
}

/// `Start LowerJoined, x`: what the function value is when passed to `@Run`.
pub fn start_lower_joined(st: crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(LowerJoined { st })
}

/// ```prism
/// CheckColors: unbounded fn St -> St
/// ```
pub fn check_colors(st0: &crate::check::types::St) -> crate::check::types::St {
    let st = propagate(&propagate(st0, &false), &true);
    let st2 = run_to_end(fold_job(st.cleqs.clone(), st.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::CLeq)| entered(once_job(move || {
        let s = p0;
        let c = p1;
        call_then(start_settled_col(s.clone(), c.lo.clone()), move |settled_col_7897: crate::check::types::Col| {
            let lo = settled_col_7897;
            call_then(start_settled_col(s.clone(), c.hi.clone()), move |settled_col_7933: crate::check::types::Col| {
                let hi = settled_col_7933;
                if col_leq(&lo, &hi) || col_leq(&up_col(&s, &lo), &up_col(&s, &hi)) {
                    prism_rtl::Turn::Finished(s.clone())
                } else {
                    prism_rtl::Turn::Finished(crate::check::types::recording::add_diag(&s, &leq_diag(&c, &lo, &hi)))
                }
            })
        })
    }))) as Rc<dyn Fn((crate::check::types::St, crate::check::types::CLeq)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>));
    let mut this: crate::check::types::St = st2.clone();
    this.cleqs = Array::new();
    this.color_flex = Array::new();
    this.col_up = Map::new();
    this
}

/// The step machine of `CheckColors`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckColors: unbounded fn St -> St
/// ```
pub struct CheckColors {
    pub st0: crate::check::types::St,
}

impl prism_rtl::Job<crate::check::types::St> for CheckColors {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st0 = &self.st0;
        let st0 = st0.clone();
        call_then(start_propagate(st0.clone(), false), move |propagate_7811: crate::check::types::St| call_then(start_propagate(propagate_7811, true), move |propagate_7800: crate::check::types::St| {
            let st = propagate_7800;
            call_value(fold_job(st.cleqs.clone(), st.clone(), Rc::new(move |(p0, p1): (crate::check::types::St, crate::check::types::CLeq)| entered(once_job(move || {
                let s = p0;
                let c = p1;
                call_then(start_settled_col(s.clone(), c.lo.clone()), move |settled_col_7897: crate::check::types::Col| {
                    let lo = settled_col_7897;
                    call_then(start_settled_col(s.clone(), c.hi.clone()), move |settled_col_7933: crate::check::types::Col| {
                        let hi = settled_col_7933;
                        if col_leq(&lo, &hi) || col_leq(&up_col(&s, &lo), &up_col(&s, &hi)) {
                            prism_rtl::Turn::Finished(s.clone())
                        } else {
                            prism_rtl::Turn::Finished(crate::check::types::recording::add_diag(&s, &leq_diag(&c, &lo, &hi)))
                        }
                    })
                })
            }))) as Rc<dyn Fn((crate::check::types::St, crate::check::types::CLeq)) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>), move |fold_7853: crate::check::types::St| {
                let st2 = fold_7853;
                prism_rtl::Turn::Finished({
                    let mut this: crate::check::types::St = st2.clone();
                    this.cleqs = Array::new();
                    this.color_flex = Array::new();
                    this.col_up = Map::new();
                    this
                })
            })
        }))
    }
}

/// `Start CheckColors, x`: what the function value is when passed to `@Run`.
pub fn start_check_colors(st0: crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(CheckColors { st0 })
}

/// ```prism
/// LeqDiag: fn CLeq, Col, Col -> CDiag
/// ```
pub fn leq_diag(c: &crate::check::types::CLeq, lo: &crate::check::types::Col, hi: &crate::check::types::Col) -> crate::check::errors::CDiag {
    if &c.kind == &Text::lit("lifted") {
        crate::check::errors::diag_fix(&Text::lit("lifted-unbounded"), &c.file, &c.span, &Text::from(format!("{} `{}` lifted over `{}`; use `@Run`", &col_word(lo), &c.name, &c.why)), &Text::from(format!("run it through `!done <- @Run {}, ...`", &c.name)))
    } else {
        if &c.kind == &Text::lit("arg") {
            crate::check::errors::diag_fix(&Text::lit("calls-unbounded"), &c.file, &c.span, &Text::from(format!("{} `{}` takes a {} closure; this one is {}", &col_word(hi), &c.name, &col_word(hi), &col_word(lo))), &Text::lit("mark the parameter `unbounded fn`, or run the work through `@Run`"))
        } else {
            if &c.kind == &Text::lit("lambda") {
                crate::check::errors::diag_fix(&Text::lit("calls-unbounded"), &c.file, &c.span, &Text::from(format!("this {} lambda calls {} `{}`", &col_word(hi), &col_word(lo), &c.why)), &Text::lit("mark the function type it meets `unbounded fn`, or run the call through `@Run`"))
            } else {
                crate::check::errors::diag_fix(&Text::lit("calls-unbounded"), &c.file, &c.span, &Text::from(format!("{} `{}` calls {} `{}`", &col_word(hi), &c.name, &col_word(lo), &c.why)), &Text::from(format!("mark `{}` `unbounded fn`, or run the call through `@Run`", &c.name)))
            }
        }
    }
}

/// ```prism
/// SettleBody: unbounded fn St, Col, Text -> St
/// ```
pub fn settle_body(st0: &crate::check::types::St, col: &crate::check::types::Col, name: &Text) -> crate::check::types::St {
    let st = propagate(st0, &false);
    let waiting = st.color_flex.clone();
    let cleared = {
        let mut this: crate::check::types::St = st.clone();
        this.color_flex = Array::new();
        this
    };
    run_to_end(fold_job(waiting.clone(), cleared.clone(), {
        let col = col.clone();
        let name = name.clone();
        Rc::new(move |(p0, p1): (crate::check::types::St, (crate::check::types::Col, Text, crate::syntax::Range))| {
            let col = col.clone();
            let name = name.clone();
            entered(once_job(move || {
                let s = p0;
                let (c, why, span) = p1;
                call_then(start_walk_col(s.clone(), c.clone()), move |walk_col_9404: crate::check::types::Col| match walk_col_9404 {
                    crate::check::types::Col::CFlex(n) => prism_rtl::Turn::More(Rc::new(AddLeq { st: s.clone(), lo0: crate::check::types::Col::CFlex(n.clone()), hi0: col.clone(), span: span.clone(), kind: if &name == &Text::lit("") { Text::lit("lambda") } else { Text::lit("body") }, name: name.clone(), why: why.clone() })),
                    known => prism_rtl::Turn::Finished(join_known(&s, &known, &why)),
                })
            }))
        }) as Rc<dyn Fn((crate::check::types::St, (crate::check::types::Col, Text, crate::syntax::Range))) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
    }))
}

/// The step machine of `SettleBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SettleBody: unbounded fn St, Col, Text -> St
/// ```
pub struct SettleBody {
    pub st0: crate::check::types::St,
    pub col: crate::check::types::Col,
    pub name: Text,
}

impl prism_rtl::Job<crate::check::types::St> for SettleBody {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::St> {
        let st0 = &self.st0;
        let col = &self.col;
        let name = &self.name;
        let col = col.clone();
        let name = name.clone();
        let st0 = st0.clone();
        call_then(start_propagate(st0.clone(), false), move |propagate_9238: crate::check::types::St| {
            let st = propagate_9238;
            let waiting = st.color_flex.clone();
            let cleared = {
                let mut this: crate::check::types::St = st.clone();
                this.color_flex = Array::new();
                this
            };
            fold_job(waiting.clone(), cleared.clone(), {
                let col = col.clone();
                let name = name.clone();
                Rc::new(move |(p0, p1): (crate::check::types::St, (crate::check::types::Col, Text, crate::syntax::Range))| {
                    let col = col.clone();
                    let name = name.clone();
                    entered(once_job(move || {
                        let s = p0;
                        let (c, why, span) = p1;
                        call_then(start_walk_col(s.clone(), c.clone()), move |walk_col_9404: crate::check::types::Col| match walk_col_9404 {
                            crate::check::types::Col::CFlex(n) => prism_rtl::Turn::More(Rc::new(AddLeq { st: s.clone(), lo0: crate::check::types::Col::CFlex(n.clone()), hi0: col.clone(), span: span.clone(), kind: if &name == &Text::lit("") { Text::lit("lambda") } else { Text::lit("body") }, name: name.clone(), why: why.clone() })),
                            known => prism_rtl::Turn::Finished(join_known(&s, &known, &why)),
                        })
                    }))
                }) as Rc<dyn Fn((crate::check::types::St, (crate::check::types::Col, Text, crate::syntax::Range))) -> Rc<dyn prism_rtl::Job<crate::check::types::St>>>
            }).cycle()
        })
    }
}

/// `Start SettleBody, x`: what the function value is when passed to `@Run`.
pub fn start_settle_body(st0: crate::check::types::St, col: crate::check::types::Col, name: Text) -> Rc<dyn prism_rtl::Job<crate::check::types::St>> {
    Rc::new(SettleBody { st0, col, name })
}
