//! The module `Check.Types.Recording`, from `target/bootstrap/src/prismc/check/types/recording.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// AtHere: fn St, Range -> SrcAt
/// ```
pub fn at_here_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range) -> crate::check::typed::SrcAt {
    crate::check::typed::SrcAt { file_p: st_p0.file_p.clone(), span_p: span_p1.clone() }
}

/// ```prism
/// NoteTy: fn St, Range, Ty -> St
/// ```
pub fn note_ty_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, t_p2: &crate::check::types::Ty) -> crate::check::types::St {
    if !st_p0.recording_p {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed_p.exprs_p = crate::prelude::push(&this.typed_p.exprs_p, &crate::check::typed::TyNote { at_p: at_here_f(st_p0, span_p1), ty_p: t_p2.clone() });
            this
        }
    }
}

/// ```prism
/// NoteBinder: fn St, Range, Text, Ty -> St
/// ```
pub fn note_binder_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, name_p2: &Text, t_p3: &crate::check::types::Ty) -> crate::check::types::St {
    if !st_p0.recording_p {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed_p.binders_p = crate::prelude::push(&this.typed_p.binders_p, &crate::check::typed::BinderNote { at_p: at_here_f(st_p0, span_p1), name_p: name_p2.clone(), ty_p: t_p3.clone() });
            this
        }
    }
}

/// ```prism
/// NoteLocal: fn St, Range, Nat -> St
/// ```
pub fn note_local_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, id_p2: &Nat) -> crate::check::types::St {
    if !st_p0.recording_p {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed_p.locals_p = crate::prelude::push(&this.typed_p.locals_p, &crate::check::typed::LocalNote { at_p: at_here_f(st_p0, span_p1), id_p: id_p2.clone() });
            this
        }
    }
}

/// ```prism
/// NoteGlobal: fn St, Range, Text -> St
/// ```
pub fn note_global_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, qk_p2: &Text) -> crate::check::types::St {
    if !st_p0.recording_p {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed_p.globals_p = crate::prelude::push(&this.typed_p.globals_p, &crate::check::typed::GlobalNote { at_p: at_here_f(st_p0, span_p1), target_p: qk_p2.clone() });
            this
        }
    }
}

/// ```prism
/// NoteCall: fn St, Range, Nat -> St
/// ```
pub fn note_call_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, id_p2: &Nat) -> crate::check::types::St {
    if !st_p0.recording_p {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed_p.calls_p = crate::prelude::push(&this.typed_p.calls_p, &crate::check::typed::LocalNote { at_p: at_here_f(st_p0, span_p1), id_p: id_p2.clone() });
            this
        }
    }
}

/// ```prism
/// NoteUse: fn St, Range, Nat -> St
/// ```
pub fn note_use_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, id_p2: &Nat) -> crate::check::types::St {
    if !st_p0.recording_p {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed_p.uses_p = crate::prelude::push(&this.typed_p.uses_p, &crate::check::typed::LocalNote { at_p: at_here_f(st_p0, span_p1), id_p: id_p2.clone() });
            this
        }
    }
}

/// ```prism
/// NoteGen: fn St, Range, Text, Scheme -> St
/// ```
pub fn note_gen_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, name_p2: &Text, sc_p3: &crate::check::types::Scheme) -> crate::check::types::St {
    if !st_p0.recording_p || ((&crate::prelude::len(&sc_p3.qs_p) == &Nat::from(0u32)) && (&crate::prelude::len(&sc_p3.cqs_p) == &Nat::from(0u32))) {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed_p.gens_p = crate::prelude::push(&this.typed_p.gens_p, &crate::check::typed::GenNote { at_p: at_here_f(st_p0, span_p1), name_p: name_p2.clone(), tys_p: sc_p3.qs_p.clone(), cols_p: sc_p3.cqs_p.clone() });
            this
        }
    }
}

/// ```prism
/// NoteInst: fn St, Range, Text, Scheme, Inst -> St
/// ```
pub fn note_inst_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, name_p2: &Text, sc_p3: &crate::check::types::Scheme, inst_p4: &crate::check::types::schemes::Inst) -> crate::check::types::St {
    if !st_p0.recording_p {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed_p.insts_p = crate::prelude::push(&this.typed_p.insts_p, &crate::check::typed::InstNote { at_p: at_here_f(st_p0, span_p1), name_p: name_p2.clone(), tys_p: crate::prelude::each(&sc_p3.qs_p, &(|q_p5: &Text| (q_p5.clone(), crate::prelude::or(&crate::prelude::get(&inst_p4.tys_p, q_p5), &crate::check::types::Ty::TyErr)))), cols_p: crate::prelude::each(&sc_p3.cqs_p, &(|q_p6: &Text| (q_p6.clone(), crate::prelude::or(&crate::prelude::get(&inst_p4.cols_p, q_p6), &crate::check::types::Col::CBound)))) });
            this
        }
    }
}

/// ```prism
/// NoteApp: fn St, Range, Text, Text, Text, [Nat], Text, Col -> St
/// ```
pub fn note_app_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, callee_p2: &Text, kind_p3: &Text, layer_p4: &Text, lifted_p5: &Array<Nat>, inner_p6: &Text, col_p7: &crate::check::types::Col) -> crate::check::types::St {
    if !st_p0.recording_p {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed_p.apps_p = crate::prelude::push(&this.typed_p.apps_p, &crate::check::typed::AppNote { at_p: at_here_f(st_p0, span_p1), callee_p: callee_p2.clone(), kind_p: kind_p3.clone(), layer_p: layer_p4.clone(), lifted_p: lifted_p5.clone(), inner_p: inner_p6.clone(), color_p: col_p7.clone() });
            this
        }
    }
}

/// ```prism
/// NoteLift: fn St, Range, Text, [Range] -> St
/// ```
pub fn note_lift_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, sigil_p2: &Text, operands_p3: &Array<crate::syntax::Range>) -> crate::check::types::St {
    if !st_p0.recording_p || (&crate::prelude::len(operands_p3) == &Nat::from(0u32)) {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed_p.lifts_p = crate::prelude::push(&this.typed_p.lifts_p, &crate::check::typed::LiftNote { at_p: at_here_f(st_p0, span_p1), sigil_p: sigil_p2.clone(), operands_p: operands_p3.clone() });
            this
        }
    }
}

/// ```prism
/// NoteFn: fn St, Range, Text, Col, Col -> St
/// ```
pub fn note_fn_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, name_p2: &Text, declared_p3: &crate::check::types::Col, body_p4: &crate::check::types::Col) -> crate::check::types::St {
    if !st_p0.recording_p {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed_p.fns_p = crate::prelude::push(&this.typed_p.fns_p, &crate::check::typed::FnNote { at_p: at_here_f(st_p0, span_p1), name_p: name_p2.clone(), declared_p: declared_p3.clone(), body_p: body_p4.clone() });
            this
        }
    }
}

/// ```prism
/// NoteImpl: fn St, Nat, Range, Text, Ty, Text -> St
/// ```
pub fn note_impl_f(st_p0: &crate::check::types::St, file_p1: &Nat, span_p2: &crate::syntax::Range, cls_p3: &Text, t_p4: &crate::check::types::Ty, how_p5: &Text) -> crate::check::types::St {
    if ((!st_p0.recording_p || crate::syntax::lexer::chars::has_prefix_f(cls_p3, &Text::lit("Range "))) || (cls_p3 == &Text::lit("Prelude.Sub"))) || (cls_p3 == &Text::lit("Prelude.Signed")) {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed_p.impls_p = crate::prelude::push(&this.typed_p.impls_p, &crate::check::typed::ImplNote { at_p: crate::check::typed::SrcAt { file_p: file_p1.clone(), span_p: span_p2.clone() }, cls_p: cls_p3.clone(), ty_p: t_p4.clone(), how_p: how_p5.clone() });
            this
        }
    }
}

/// ```prism
/// NoteChoice: fn St, Nat, Range, Text, Text -> St
/// ```
pub fn note_choice_f(st_p0: &crate::check::types::St, file_p1: &Nat, span_p2: &crate::syntax::Range, cls_p3: &Text, ch_p4: &Text) -> crate::check::types::St {
    let k_p5 = choice_key_f(file_p1, span_p2, cls_p3);
    if (crate::syntax::lexer::chars::has_prefix_f(cls_p3, &Text::lit("Range ")) || (cls_p3 == &Text::lit("Prelude.Sub"))) || (cls_p3 == &Text::lit("Prelude.Signed")) {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.choices_p = crate::prelude::insert(&this.choices_p, &k_p5, &crate::check::types::add_text_f(&crate::prelude::or(&crate::prelude::get(&this.choices_p, &k_p5), &Array::new()), ch_p4));
            this
        }
    }
}

/// ```prism
/// NoteSizeTy: fn St, Range, Ty -> St
/// ```
pub fn note_size_ty_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, t_p2: &crate::check::types::Ty) -> crate::check::types::St {
    match t_p2 {
        crate::check::types::Ty::TyFn(_, ps_p3, _) => match crate::prelude::index(ps_p3, &Nat::from(0u32)) {
            Some(p_p4) => {
                let mut this: crate::check::types::St = st_p0.clone();
                this.size_tys_p = crate::prelude::insert(&this.size_tys_p, &Text::from(format!("{}:{}:{}", &st_p0.file_p, &span_p1.start_p, &span_p1.end_p)), &p_p4);
                this
            },
            None => st_p0.clone(),
        },
        _ => st_p0.clone(),
    }
}

/// ```prism
/// ChoiceKey: fn Nat, Range, Text -> Text
/// ```
pub fn choice_key_f(file_p0: &Nat, span_p1: &crate::syntax::Range, cls_p2: &Text) -> Text {
    Text::from(format!("{}:{}:{}:{}", file_p0, &span_p1.start_p, &span_p1.end_p, cls_p2))
}

/// ```prism
/// NoteMethod: fn St, Range, Text, Text -> St
/// ```
pub fn note_method_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, method_p2: &Text, cls_p3: &Text) -> crate::check::types::St {
    if !st_p0.recording_p {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed_p.methods_p = crate::prelude::push(&this.typed_p.methods_p, &crate::check::typed::MethodNote { at_p: at_here_f(st_p0, span_p1), method_p: method_p2.clone(), cls_p: cls_p3.clone() });
            this
        }
    }
}

/// ```prism
/// NoteGroup: fn St, Range, Text, [ [Nat] ] -> St
/// ```
pub fn note_group_f(st_p0: &crate::check::types::St, span_p1: &crate::syntax::Range, kind_p2: &Text, order_p3: &Array<Array<Nat>>) -> crate::check::types::St {
    if !st_p0.recording_p {
        st_p0.clone()
    } else {
        {
            let mut this: crate::check::types::St = st_p0.clone();
            this.typed_p.groups_p = crate::prelude::push(&this.typed_p.groups_p, &crate::check::typed::GroupNote { at_p: at_here_f(st_p0, span_p1), kind_p: kind_p2.clone(), order_p: order_p3.clone() });
            this
        }
    }
}

/// ```prism
/// ZonkTyped: unbounded fn St -> TProgram
/// ```
pub fn zonk_typed_f(st_p0: &crate::check::types::St) -> crate::check::typed::TProgram {
    let t_p1 = st_p0.typed_p.clone();
    let mut this: crate::check::typed::TProgram = t_p1.clone();
    this.exprs_p = crate::prelude::run_to_end(crate::prelude::each_job(this.exprs_p.clone(), {
        let st_p0x = st_p0.clone();
        Rc::new(move |p0: crate::check::typed::TyNote| {
            let st_p0xy = st_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let n_p2 = p0;
                crate::prelude::call_then(start_resolve_ty_f(st_p0xy.clone(), n_p2.ty_p.clone()), move |resolve_ty_f_6257: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::typed::TyNote { at_p: n_p2.at_p.clone(), ty_p: resolve_ty_f_6257 }))
            }))
        }) as Rc<dyn Fn(crate::check::typed::TyNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::TyNote>>>
    }));
    this.binders_p = crate::prelude::run_to_end(crate::prelude::each_job(this.binders_p.clone(), {
        let st_p0x = st_p0.clone();
        Rc::new(move |p0: crate::check::typed::BinderNote| {
            let st_p0xy = st_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let n_p3 = p0;
                crate::prelude::call_then(start_resolve_ty_f(st_p0xy.clone(), n_p3.ty_p.clone()), move |resolve_ty_f_6359: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::typed::BinderNote { at_p: n_p3.at_p.clone(), name_p: n_p3.name_p.clone(), ty_p: resolve_ty_f_6359 }))
            }))
        }) as Rc<dyn Fn(crate::check::typed::BinderNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::BinderNote>>>
    }));
    this.insts_p = crate::prelude::run_to_end(crate::prelude::each_job(this.insts_p.clone(), {
        let st_p0x = st_p0.clone();
        Rc::new(move |p0: crate::check::typed::InstNote| {
            let st_p0xy = st_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let n_p4 = p0;
                crate::prelude::call_value(crate::prelude::each_job(n_p4.tys_p.clone(), {
                    let st_p0xyx = st_p0xy.clone();
                    Rc::new(move |p0: (Text, crate::check::types::Ty)| {
                        let st_p0xyxy = st_p0xyx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (q_p5, x_p6) = p0;
                            crate::prelude::call_then(start_resolve_ty_f(st_p0xyxy.clone(), x_p6.clone()), move |resolve_ty_f_6486: crate::check::types::Ty| prism_rtl::Turn::Finished((q_p5.clone(), resolve_ty_f_6486)))
                        }))
                    }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::Ty)>>>
                }), move |each_6456: Array<(Text, crate::check::types::Ty)>| crate::prelude::call_value(crate::prelude::each_job(n_p4.cols_p.clone(), {
                    let st_p0xyx = st_p0xy.clone();
                    Rc::new(move |p0: (Text, crate::check::types::Col)| {
                        let st_p0xyxy = st_p0xyx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let (q_p7, c_p8) = p0;
                            crate::prelude::call_then(start_resolve_col_f(st_p0xyxy.clone(), c_p8.clone()), move |resolve_col_f_6544: crate::check::types::Col| prism_rtl::Turn::Finished((q_p7.clone(), resolve_col_f_6544)))
                        }))
                    }) as Rc<dyn Fn((Text, crate::check::types::Col)) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::Col)>>>
                }), move |each_6513: Array<(Text, crate::check::types::Col)>| prism_rtl::Turn::Finished(crate::check::typed::InstNote { at_p: n_p4.at_p.clone(), name_p: n_p4.name_p.clone(), tys_p: each_6456, cols_p: each_6513 })))
            }))
        }) as Rc<dyn Fn(crate::check::typed::InstNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::InstNote>>>
    }));
    this.impls_p = crate::prelude::run_to_end(crate::prelude::each_job(this.impls_p.clone(), {
        let st_p0x = st_p0.clone();
        Rc::new(move |p0: crate::check::typed::ImplNote| {
            let st_p0xy = st_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let n_p9 = p0;
                crate::prelude::call_then(start_resolve_ty_f(st_p0xy.clone(), n_p9.ty_p.clone()), move |resolve_ty_f_6639: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::typed::ImplNote { at_p: n_p9.at_p.clone(), cls_p: n_p9.cls_p.clone(), ty_p: resolve_ty_f_6639, how_p: n_p9.how_p.clone() }))
            }))
        }) as Rc<dyn Fn(crate::check::typed::ImplNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::ImplNote>>>
    }));
    this.apps_p = crate::prelude::run_to_end(crate::prelude::each_job(this.apps_p.clone(), {
        let st_p0x = st_p0.clone();
        Rc::new(move |p0: crate::check::typed::AppNote| {
            let st_p0xy = st_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let n_pa = p0;
                crate::prelude::call_then(start_resolve_col_f(st_p0xy.clone(), n_pa.color_p.clone()), move |resolve_col_f_6810: crate::check::types::Col| prism_rtl::Turn::Finished(crate::check::typed::AppNote { at_p: n_pa.at_p.clone(), callee_p: n_pa.callee_p.clone(), kind_p: n_pa.kind_p.clone(), layer_p: n_pa.layer_p.clone(), lifted_p: n_pa.lifted_p.clone(), inner_p: n_pa.inner_p.clone(), color_p: resolve_col_f_6810 }))
            }))
        }) as Rc<dyn Fn(crate::check::typed::AppNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::AppNote>>>
    }));
    this.fns_p = crate::prelude::run_to_end(crate::prelude::each_job(this.fns_p.clone(), {
        let st_p0x = st_p0.clone();
        Rc::new(move |p0: crate::check::typed::FnNote| {
            let st_p0xy = st_p0x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let n_pb = p0;
                crate::prelude::call_then(start_resolve_col_f(st_p0xy.clone(), n_pb.declared_p.clone()), move |resolve_col_f_6910: crate::check::types::Col| crate::prelude::call_then(start_resolve_col_f(st_p0xy.clone(), n_pb.body_p.clone()), move |resolve_col_f_6944: crate::check::types::Col| prism_rtl::Turn::Finished(crate::check::typed::FnNote { at_p: n_pb.at_p.clone(), name_p: n_pb.name_p.clone(), declared_p: resolve_col_f_6910, body_p: resolve_col_f_6944 })))
            }))
        }) as Rc<dyn Fn(crate::check::typed::FnNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::FnNote>>>
    }));
    this
}

/// The step machine of `ZonkTyped`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ZonkTyped: unbounded fn St -> TProgram
/// ```
pub struct ZonkTyped {
    pub st_p0: crate::check::types::St,
}

impl prism_rtl::Job<crate::check::typed::TProgram> for ZonkTyped {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::typed::TProgram> {
        let st_p0 = &self.st_p0;
        let t_p1 = st_p0.typed_p.clone();
        prism_rtl::Turn::Finished({
            let mut this: crate::check::typed::TProgram = t_p1.clone();
            this.exprs_p = crate::prelude::run_to_end(crate::prelude::each_job(this.exprs_p.clone(), {
                let st_p0x = st_p0.clone();
                Rc::new(move |p0: crate::check::typed::TyNote| {
                    let st_p0xy = st_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let n_p2 = p0;
                        crate::prelude::call_then(start_resolve_ty_f(st_p0xy.clone(), n_p2.ty_p.clone()), move |resolve_ty_f_6257: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::typed::TyNote { at_p: n_p2.at_p.clone(), ty_p: resolve_ty_f_6257 }))
                    }))
                }) as Rc<dyn Fn(crate::check::typed::TyNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::TyNote>>>
            }));
            this.binders_p = crate::prelude::run_to_end(crate::prelude::each_job(this.binders_p.clone(), {
                let st_p0x = st_p0.clone();
                Rc::new(move |p0: crate::check::typed::BinderNote| {
                    let st_p0xy = st_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let n_p3 = p0;
                        crate::prelude::call_then(start_resolve_ty_f(st_p0xy.clone(), n_p3.ty_p.clone()), move |resolve_ty_f_6359: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::typed::BinderNote { at_p: n_p3.at_p.clone(), name_p: n_p3.name_p.clone(), ty_p: resolve_ty_f_6359 }))
                    }))
                }) as Rc<dyn Fn(crate::check::typed::BinderNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::BinderNote>>>
            }));
            this.insts_p = crate::prelude::run_to_end(crate::prelude::each_job(this.insts_p.clone(), {
                let st_p0x = st_p0.clone();
                Rc::new(move |p0: crate::check::typed::InstNote| {
                    let st_p0xy = st_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let n_p4 = p0;
                        crate::prelude::call_value(crate::prelude::each_job(n_p4.tys_p.clone(), {
                            let st_p0xyx = st_p0xy.clone();
                            Rc::new(move |p0: (Text, crate::check::types::Ty)| {
                                let st_p0xyxy = st_p0xyx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let (q_p5, x_p6) = p0;
                                    crate::prelude::call_then(start_resolve_ty_f(st_p0xyxy.clone(), x_p6.clone()), move |resolve_ty_f_6486: crate::check::types::Ty| prism_rtl::Turn::Finished((q_p5.clone(), resolve_ty_f_6486)))
                                }))
                            }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::Ty)>>>
                        }), move |each_6456: Array<(Text, crate::check::types::Ty)>| crate::prelude::call_value(crate::prelude::each_job(n_p4.cols_p.clone(), {
                            let st_p0xyx = st_p0xy.clone();
                            Rc::new(move |p0: (Text, crate::check::types::Col)| {
                                let st_p0xyxy = st_p0xyx.clone();
                                crate::prelude::entered(crate::prelude::once_job(move || {
                                    let (q_p7, c_p8) = p0;
                                    crate::prelude::call_then(start_resolve_col_f(st_p0xyxy.clone(), c_p8.clone()), move |resolve_col_f_6544: crate::check::types::Col| prism_rtl::Turn::Finished((q_p7.clone(), resolve_col_f_6544)))
                                }))
                            }) as Rc<dyn Fn((Text, crate::check::types::Col)) -> Rc<dyn prism_rtl::Job<(Text, crate::check::types::Col)>>>
                        }), move |each_6513: Array<(Text, crate::check::types::Col)>| prism_rtl::Turn::Finished(crate::check::typed::InstNote { at_p: n_p4.at_p.clone(), name_p: n_p4.name_p.clone(), tys_p: each_6456, cols_p: each_6513 })))
                    }))
                }) as Rc<dyn Fn(crate::check::typed::InstNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::InstNote>>>
            }));
            this.impls_p = crate::prelude::run_to_end(crate::prelude::each_job(this.impls_p.clone(), {
                let st_p0x = st_p0.clone();
                Rc::new(move |p0: crate::check::typed::ImplNote| {
                    let st_p0xy = st_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let n_p9 = p0;
                        crate::prelude::call_then(start_resolve_ty_f(st_p0xy.clone(), n_p9.ty_p.clone()), move |resolve_ty_f_6639: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::typed::ImplNote { at_p: n_p9.at_p.clone(), cls_p: n_p9.cls_p.clone(), ty_p: resolve_ty_f_6639, how_p: n_p9.how_p.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::typed::ImplNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::ImplNote>>>
            }));
            this.apps_p = crate::prelude::run_to_end(crate::prelude::each_job(this.apps_p.clone(), {
                let st_p0x = st_p0.clone();
                Rc::new(move |p0: crate::check::typed::AppNote| {
                    let st_p0xy = st_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let n_pa = p0;
                        crate::prelude::call_then(start_resolve_col_f(st_p0xy.clone(), n_pa.color_p.clone()), move |resolve_col_f_6810: crate::check::types::Col| prism_rtl::Turn::Finished(crate::check::typed::AppNote { at_p: n_pa.at_p.clone(), callee_p: n_pa.callee_p.clone(), kind_p: n_pa.kind_p.clone(), layer_p: n_pa.layer_p.clone(), lifted_p: n_pa.lifted_p.clone(), inner_p: n_pa.inner_p.clone(), color_p: resolve_col_f_6810 }))
                    }))
                }) as Rc<dyn Fn(crate::check::typed::AppNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::AppNote>>>
            }));
            this.fns_p = crate::prelude::run_to_end(crate::prelude::each_job(this.fns_p.clone(), {
                let st_p0x = st_p0.clone();
                Rc::new(move |p0: crate::check::typed::FnNote| {
                    let st_p0xy = st_p0x.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let n_pb = p0;
                        crate::prelude::call_then(start_resolve_col_f(st_p0xy.clone(), n_pb.declared_p.clone()), move |resolve_col_f_6910: crate::check::types::Col| crate::prelude::call_then(start_resolve_col_f(st_p0xy.clone(), n_pb.body_p.clone()), move |resolve_col_f_6944: crate::check::types::Col| prism_rtl::Turn::Finished(crate::check::typed::FnNote { at_p: n_pb.at_p.clone(), name_p: n_pb.name_p.clone(), declared_p: resolve_col_f_6910, body_p: resolve_col_f_6944 })))
                    }))
                }) as Rc<dyn Fn(crate::check::typed::FnNote) -> Rc<dyn prism_rtl::Job<crate::check::typed::FnNote>>>
            }));
            this
        })
    }
}

/// `Start ZonkTyped, x`: what the function value is when passed to `@Run`.
pub fn start_zonk_typed_f(st_p0: crate::check::types::St) -> Rc<dyn prism_rtl::Job<crate::check::typed::TProgram>> {
    Rc::new(ZonkTyped { st_p0 })
}

/// ```prism
/// ResolveCol: unbounded fn St, Col -> Col
/// ```
pub fn resolve_col_f(st_p0: &crate::check::types::St, c_p1: &crate::check::types::Col) -> crate::check::types::Col {
    match crate::check::types::colors::walk_col_f(st_p0, c_p1) {
        crate::check::types::Col::CFlex(n_p2) => match crate::prelude::get(&st_p0.col_q_p, &n_p2) {
            Some(q_p3) => crate::check::types::Col::CQ(q_p3),
            None => crate::check::types::Col::CBound,
        },
        other_p4 => other_p4,
    }
}

/// The step machine of `ResolveCol`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResolveCol: unbounded fn St, Col -> Col
/// ```
pub struct ResolveCol {
    pub st_p0: crate::check::types::St,
    pub c_p1: crate::check::types::Col,
}

impl prism_rtl::Job<crate::check::types::Col> for ResolveCol {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Col> {
        let st_p0 = &self.st_p0;
        let c_p1 = &self.c_p1;
        let c_p1x = c_p1.clone();
        let st_p0x = st_p0.clone();
        crate::prelude::call_then(crate::check::types::colors::start_walk_col_f(st_p0x.clone(), c_p1x.clone()), move |walk_col_f_7179: crate::check::types::Col| match walk_col_f_7179 {
            crate::check::types::Col::CFlex(n_p2) => match crate::prelude::get(&st_p0x.col_q_p, &n_p2) {
                Some(q_p3) => prism_rtl::Turn::Finished(crate::check::types::Col::CQ(q_p3.clone())),
                None => prism_rtl::Turn::Finished(crate::check::types::Col::CBound),
            },
            other_p4 => prism_rtl::Turn::Finished(other_p4.clone()),
        })
    }
}

/// `Start ResolveCol, x`: what the function value is when passed to `@Run`.
pub fn start_resolve_col_f(st_p0: crate::check::types::St, c_p1: crate::check::types::Col) -> Rc<dyn prism_rtl::Job<crate::check::types::Col>> {
    Rc::new(ResolveCol { st_p0, c_p1 })
}

/// ```prism
/// ResolveTy: unbounded fn St, Ty -> Ty
/// ```
pub fn resolve_ty_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    resolve_in_f(st_p0, &zonk_f(st_p0, t_p1))
}

/// The step machine of `ResolveTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResolveTy: unbounded fn St, Ty -> Ty
/// ```
pub struct ResolveTy {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::Ty> for ResolveTy {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(start_zonk_f(st_p0x.clone(), t_p1x.clone()), move |zonk_f_7392: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(ResolveIn { st_p0: st_p0x.clone(), t_p1: zonk_f_7392 })))
    }
}

/// `Start ResolveTy, x`: what the function value is when passed to `@Run`.
pub fn start_resolve_ty_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(ResolveTy { st_p0, t_p1 })
}

/// ```prism
/// ResolveIn: unbounded fn St, Ty -> Ty
/// ```
pub fn resolve_in_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p1 {
        crate::check::types::Ty::TyCon(n_p2, args_p3) => crate::check::types::Ty::TyCon(n_p2.clone(), crate::prelude::run_to_end(crate::prelude::each_job(args_p3.clone(), {
            let st_p0x = st_p0.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p4 = p0;
                    prism_rtl::Turn::More(Rc::new(ResolveIn { st_p0: st_p0xy.clone(), t_p1: a_p4.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyFn(c_p5, ps_p6, res_p7) => crate::check::types::Ty::TyFn(resolve_col_f(st_p0, c_p5), crate::prelude::run_to_end(crate::prelude::each_job(ps_p6.clone(), {
            let st_p0x = st_p0.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let p_p8 = p0;
                    prism_rtl::Turn::More(Rc::new(ResolveIn { st_p0: st_p0xy.clone(), t_p1: p_p8.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        })), Rc::new(resolve_in_f(st_p0, &**res_p7))),
        crate::check::types::Ty::TyTuple(ts_p9) => crate::check::types::Ty::TyTuple(crate::prelude::run_to_end(crate::prelude::each_job(ts_p9.clone(), {
            let st_p0x = st_p0.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pa = p0;
                    prism_rtl::Turn::More(Rc::new(ResolveIn { st_p0: st_p0xy.clone(), t_p1: a_pa.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyArray(e_pb) => crate::check::types::Ty::TyArray(Rc::new(resolve_in_f(st_p0, &**e_pb))),
        crate::check::types::Ty::TyMap(k_pc, v_pd) => crate::check::types::Ty::TyMap(Rc::new(resolve_in_f(st_p0, &**k_pc)), Rc::new(resolve_in_f(st_p0, &**v_pd))),
        crate::check::types::Ty::TySig(s_pe, i_pf) => crate::check::types::Ty::TySig(s_pe.clone(), Rc::new(resolve_in_f(st_p0, &**i_pf))),
        crate::check::types::Ty::TyAt(i_pg, rw_ph) => crate::check::types::Ty::TyAt(Rc::new(resolve_in_f(st_p0, &**i_pg)), rw_ph.clone()),
        crate::check::types::Ty::TyElem(rw_pi, o_pj) => crate::check::types::Ty::TyElem(rw_pi.clone(), Rc::new(resolve_in_f(st_p0, &**o_pj))),
        crate::check::types::Ty::TyAssoc(n_pk, a_pl) => crate::check::types::Ty::TyAssoc(n_pk.clone(), Rc::new(resolve_in_f(st_p0, &**a_pl))),
        other_pm => other_pm.clone(),
    }
}

/// The step machine of `ResolveIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ResolveIn: unbounded fn St, Ty -> Ty
/// ```
pub struct ResolveIn {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::Ty> for ResolveIn {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        match t_p1 {
            crate::check::types::Ty::TyCon(n_p2, args_p3) => {
                let args_p3x = args_p3.clone();
                let n_p2x = n_p2.clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_value(crate::prelude::each_job(args_p3x.clone(), {
                    let st_p0xx = st_p0x.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let st_p0xxy = st_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_p4 = p0;
                            prism_rtl::Turn::More(Rc::new(ResolveIn { st_p0: st_p0xxy.clone(), t_p1: a_p4.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_7501: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyCon(n_p2x.clone(), each_7501)))
            },
            crate::check::types::Ty::TyFn(c_p5, ps_p6, res_p7) => {
                let c_p5x = c_p5.clone();
                let ps_p6x = ps_p6.clone();
                let res_p7x = (**res_p7).clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_then(start_resolve_col_f(st_p0x.clone(), c_p5x.clone()), move |resolve_col_f_7561: crate::check::types::Col| crate::prelude::call_value(crate::prelude::each_job(ps_p6x.clone(), {
                    let st_p0xx = st_p0x.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let st_p0xxy = st_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let p_p8 = p0;
                            prism_rtl::Turn::More(Rc::new(ResolveIn { st_p0: st_p0xxy.clone(), t_p1: p_p8.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_7581: Array<crate::check::types::Ty>| crate::prelude::call_then(start_resolve_in_f(st_p0x.clone(), res_p7x.clone()), move |resolve_in_f_7614: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyFn(resolve_col_f_7561, each_7581, Rc::new(resolve_in_f_7614))))))
            },
            crate::check::types::Ty::TyTuple(ts_p9) => {
                let st_p0x = st_p0.clone();
                let ts_p9x = ts_p9.clone();
                crate::prelude::call_value(crate::prelude::each_job(ts_p9x.clone(), {
                    let st_p0xx = st_p0x.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let st_p0xxy = st_p0xx.clone();
                        crate::prelude::entered(crate::prelude::once_job(move || {
                            let a_pa = p0;
                            prism_rtl::Turn::More(Rc::new(ResolveIn { st_p0: st_p0xxy.clone(), t_p1: a_pa.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_7658: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyTuple(each_7658)))
            },
            crate::check::types::Ty::TyArray(e_pb) => {
                let e_pbx = (**e_pb).clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_then(start_resolve_in_f(st_p0x.clone(), e_pbx.clone()), move |resolve_in_f_7713: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyArray(Rc::new(resolve_in_f_7713))))
            },
            crate::check::types::Ty::TyMap(k_pc, v_pd) => {
                let k_pcx = (**k_pc).clone();
                let st_p0x = st_p0.clone();
                let v_pdx = (**v_pd).clone();
                crate::prelude::call_then(start_resolve_in_f(st_p0x.clone(), k_pcx.clone()), move |resolve_in_f_7753: crate::check::types::Ty| crate::prelude::call_then(start_resolve_in_f(st_p0x.clone(), v_pdx.clone()), move |resolve_in_f_7772: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyMap(Rc::new(resolve_in_f_7753), Rc::new(resolve_in_f_7772)))))
            },
            crate::check::types::Ty::TySig(s_pe, i_pf) => {
                let i_pfx = (**i_pf).clone();
                let s_pex = s_pe.clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_then(start_resolve_in_f(st_p0x.clone(), i_pfx.clone()), move |resolve_in_f_7815: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TySig(s_pex.clone(), Rc::new(resolve_in_f_7815))))
            },
            crate::check::types::Ty::TyAt(i_pg, rw_ph) => {
                let i_pgx = (**i_pg).clone();
                let rw_phx = rw_ph.clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_then(start_resolve_in_f(st_p0x.clone(), i_pgx.clone()), move |resolve_in_f_7854: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyAt(Rc::new(resolve_in_f_7854), rw_phx.clone())))
            },
            crate::check::types::Ty::TyElem(rw_pi, o_pj) => {
                let o_pjx = (**o_pj).clone();
                let rw_pix = rw_pi.clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_then(start_resolve_in_f(st_p0x.clone(), o_pjx.clone()), move |resolve_in_f_7905: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyElem(rw_pix.clone(), Rc::new(resolve_in_f_7905))))
            },
            crate::check::types::Ty::TyAssoc(n_pk, a_pl) => {
                let a_plx = (**a_pl).clone();
                let n_pkx = n_pk.clone();
                let st_p0x = st_p0.clone();
                crate::prelude::call_then(start_resolve_in_f(st_p0x.clone(), a_plx.clone()), move |resolve_in_f_7952: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyAssoc(n_pkx.clone(), Rc::new(resolve_in_f_7952))))
            },
            other_pm => prism_rtl::Turn::Finished(other_pm.clone()),
        }
    }
}

/// `Start ResolveIn, x`: what the function value is when passed to `@Run`.
pub fn start_resolve_in_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(ResolveIn { st_p0, t_p1 })
}

/// ```prism
/// AtBinder: fn St, Ty, Range -> St
/// ```
pub fn at_binder_f(st_p0: &crate::check::types::St, ty1: &crate::check::types::Ty, range2: &crate::syntax::Range) -> crate::check::types::St {
    match (ty1, range2) {
        (crate::check::types::Ty::TyFlex(n_p1), span_p2) => {
            let mut this: crate::check::types::St = st_p0.clone();
            this.binder_at_p = crate::prelude::insert(&this.binder_at_p, n_p1, span_p2);
            this
        },
        (_, _) => st_p0.clone(),
    }
}

/// ```prism
/// FreshRow: fn St, [Text] -> ((Rw, St))
/// ```
pub fn fresh_row_f(st_p0: &crate::check::types::St, lacking_p1: &Array<Text>) -> (crate::check::types::Rw, crate::check::types::St) {
    let n_p2 = st_p0.next_p.clone();
    let st2_p3 = {
        let mut this: crate::check::types::St = st_p0.clone();
        this.next_p = &this.next_p + &Nat::from(1u32);
        this.lacks_p = crate::prelude::insert(&this.lacks_p, &n_p2, lacking_p1);
        this
    };
    (crate::check::types::Rw { fams_p: Array::new(), minus_p: Array::new(), tail_p: crate::check::types::Tail::TlFlex(n_p2.clone()) }, st2_p3.clone())
}

/// ```prism
/// AddDiag: fn St, CDiag -> St
/// ```
pub fn add_diag_f(st_p0: &crate::check::types::St, d_p1: &crate::check::errors::CDiag) -> crate::check::types::St {
    let mut this: crate::check::types::St = st_p0.clone();
    this.diags_p = crate::prelude::push(&this.diags_p, d_p1);
    this
}

/// ```prism
/// Err: fn St, Text, Range, Text -> St
/// ```
pub fn err_f(st_p0: &crate::check::types::St, code_p1: &Text, span_p2: &crate::syntax::Range, message_p3: &Text) -> crate::check::types::St {
    add_diag_f(st_p0, &crate::check::errors::diag0_f(code_p1, &st_p0.file_p, span_p2, message_p3))
}

/// ```prism
/// ErrFix: fn St, Text, Range, Text, Text -> St
/// ```
pub fn err_fix_f(st_p0: &crate::check::types::St, code_p1: &Text, span_p2: &crate::syntax::Range, message_p3: &Text, fix_p4: &Text) -> crate::check::types::St {
    add_diag_f(st_p0, &crate::check::errors::diag_fix_f(code_p1, &st_p0.file_p, span_p2, message_p3, fix_p4))
}

/// ```prism
/// InfoOf: fn St, Nat -> VInfo
/// ```
pub fn info_of_f(st_p0: &crate::check::types::St, n_p1: &Nat) -> crate::check::types::VInfo {
    crate::prelude::or(&crate::prelude::get(&st_p0.infos_p, n_p1), &crate::check::types::VInfo { plain_p: false, level_p: Nat::from(0u32), name_p: Text::lit("") })
}

/// ```prism
/// Walk: unbounded fn St, Ty -> Ty
/// ```
pub fn walk_f(st_p0: &crate::check::types::St, ty1: &crate::check::types::Ty) -> crate::check::types::Ty {
    match ty1 {
        crate::check::types::Ty::TyFlex(n_p1) => match crate::prelude::get(&st_p0.tys_p, n_p1) {
            Some(t_p2) => walk_f(st_p0, &t_p2),
            None => crate::check::types::Ty::TyFlex(n_p1.clone()),
        },
        t_p4 => t_p4.clone(),
    }
}

/// The step machine of `Walk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Walk: unbounded fn St, Ty -> Ty
/// ```
pub struct Walk {
    pub st_p0: crate::check::types::St,
    pub ty1: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::Ty> for Walk {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let st_p0 = &self.st_p0;
        let ty1 = &self.ty1;
        match ty1 {
            crate::check::types::Ty::TyFlex(n_p1) => match crate::prelude::get(&st_p0.tys_p, n_p1) {
                Some(t_p2) => prism_rtl::Turn::More(Rc::new(Walk { st_p0: st_p0.clone(), ty1: t_p2.clone() })),
                None => prism_rtl::Turn::Finished(crate::check::types::Ty::TyFlex(n_p1.clone())),
            },
            t_p4 => prism_rtl::Turn::Finished(t_p4.clone()),
        }
    }
}

/// `Start Walk, x`: what the function value is when passed to `@Run`.
pub fn start_walk_f(st_p0: crate::check::types::St, ty1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(Walk { st_p0, ty1 })
}

/// ```prism
/// WalkRow: unbounded fn St, Rw -> Rw
/// ```
pub fn walk_row_f(st_p0: &crate::check::types::St, r_p1: &crate::check::types::Rw) -> crate::check::types::Rw {
    match &r_p1.tail_p {
        crate::check::types::Tail::TlFlex(n_p2) => match crate::prelude::get(&st_p0.rows_p, n_p2) {
            Some(r2_p3) => {
                let w_p4 = walk_row_f(st_p0, &r2_p3);
                crate::check::types::Rw { fams_p: crate::check::types::sort_texts_f(&crate::check::types::union_texts_f(&r_p1.fams_p, &w_p4.fams_p)), minus_p: crate::check::types::union_texts_f(&r_p1.minus_p, &w_p4.minus_p), tail_p: w_p4.tail_p.clone() }
            },
            None => r_p1.clone(),
        },
        _ => r_p1.clone(),
    }
}

/// The step machine of `WalkRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WalkRow: unbounded fn St, Rw -> Rw
/// ```
pub struct WalkRow {
    pub st_p0: crate::check::types::St,
    pub r_p1: crate::check::types::Rw,
}

impl prism_rtl::Job<crate::check::types::Rw> for WalkRow {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Rw> {
        let st_p0 = &self.st_p0;
        let r_p1 = &self.r_p1;
        match &r_p1.tail_p {
            crate::check::types::Tail::TlFlex(n_p2) => match crate::prelude::get(&st_p0.rows_p, n_p2) {
                Some(r2_p3) => {
                    let r_p1x = r_p1.clone();
                    let st_p0x = st_p0.clone();
                    crate::prelude::call_then(start_walk_row_f(st_p0x.clone(), r2_p3.clone()), move |walk_row_f_9319: crate::check::types::Rw| {
                        let w_p4 = walk_row_f_9319;
                        prism_rtl::Turn::Finished(crate::check::types::Rw { fams_p: crate::check::types::sort_texts_f(&crate::check::types::union_texts_f(&r_p1x.fams_p, &w_p4.fams_p)), minus_p: crate::check::types::union_texts_f(&r_p1x.minus_p, &w_p4.minus_p), tail_p: w_p4.tail_p.clone() })
                    })
                },
                None => prism_rtl::Turn::Finished(r_p1.clone()),
            },
            _ => prism_rtl::Turn::Finished(r_p1.clone()),
        }
    }
}

/// `Start WalkRow, x`: what the function value is when passed to `@Run`.
pub fn start_walk_row_f(st_p0: crate::check::types::St, r_p1: crate::check::types::Rw) -> Rc<dyn prism_rtl::Job<crate::check::types::Rw>> {
    Rc::new(WalkRow { st_p0, r_p1 })
}

/// ```prism
/// Zonk: unbounded fn St, Ty -> Ty
/// ```
pub fn zonk_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    match crate::check::types::unify::norm_assoc_f(st_p0, &walk_f(st_p0, t_p1)) {
        crate::check::types::Ty::TyCon(n_p2, args_p3) => crate::check::types::Ty::TyCon(n_p2.clone(), crate::prelude::run_to_end(crate::prelude::each_job(args_p3.clone(), {
            let st_p0x = st_p0.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p4 = p0;
                    prism_rtl::Turn::More(Rc::new(Zonk { st_p0: st_p0xy.clone(), t_p1: a_p4.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyFn(c_p5, ps_p6, res_p7) => crate::check::types::Ty::TyFn(crate::check::types::colors::walk_col_f(st_p0, &c_p5), crate::prelude::run_to_end(crate::prelude::each_job(ps_p6.clone(), {
            let st_p0x = st_p0.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let p_p8 = p0;
                    prism_rtl::Turn::More(Rc::new(Zonk { st_p0: st_p0xy.clone(), t_p1: p_p8.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        })), Rc::new(zonk_f(st_p0, &*res_p7))),
        crate::check::types::Ty::TyTuple(ts_p9) => crate::check::types::Ty::TyTuple(crate::prelude::run_to_end(crate::prelude::each_job(ts_p9.clone(), {
            let st_p0x = st_p0.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pa = p0;
                    prism_rtl::Turn::More(Rc::new(Zonk { st_p0: st_p0xy.clone(), t_p1: a_pa.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyArray(e_pb) => crate::check::types::Ty::TyArray(Rc::new(zonk_f(st_p0, &*e_pb))),
        crate::check::types::Ty::TyMap(k_pc, v_pd) => crate::check::types::Ty::TyMap(Rc::new(zonk_f(st_p0, &*k_pc)), Rc::new(zonk_f(st_p0, &*v_pd))),
        crate::check::types::Ty::TySig(s_pe, i_pf) => crate::check::types::Ty::TySig(s_pe, Rc::new(zonk_f(st_p0, &*i_pf))),
        crate::check::types::Ty::TyAt(i_pg, rw_ph) => crate::check::types::Ty::TyAt(Rc::new(zonk_f(st_p0, &*i_pg)), walk_row_f(st_p0, &rw_ph)),
        crate::check::types::Ty::TyElem(rw_pi, o_pj) => crate::check::types::Ty::TyElem(walk_row_f(st_p0, &rw_pi), Rc::new(zonk_f(st_p0, &*o_pj))),
        crate::check::types::Ty::TyElemAny(rw_pk) => crate::check::types::Ty::TyElemAny(walk_row_f(st_p0, &rw_pk)),
        crate::check::types::Ty::TyAssoc(n_pl, a_pm) => crate::check::types::Ty::TyAssoc(n_pl, Rc::new(zonk_f(st_p0, &*a_pm))),
        w_pn => w_pn,
    }
}

/// The step machine of `Zonk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Zonk: unbounded fn St, Ty -> Ty
/// ```
pub struct Zonk {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::check::types::Ty> for Zonk {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        let st_p0x = st_p0.clone();
        let t_p1x = t_p1.clone();
        crate::prelude::call_then(start_walk_f(st_p0x.clone(), t_p1x.clone()), move |walk_f_9610: crate::check::types::Ty| crate::prelude::call_then(crate::check::types::unify::start_norm_assoc_f(st_p0x.clone(), walk_f_9610), move |norm_assoc_f_9595: crate::check::types::Ty| match norm_assoc_f_9595 {
            crate::check::types::Ty::TyCon(n_p2, args_p3) => crate::prelude::call_value(crate::prelude::each_job(args_p3.clone(), {
                let st_p0xx = st_p0x.clone();
                Rc::new(move |p0: crate::check::types::Ty| {
                    let st_p0xxy = st_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_p4 = p0;
                        prism_rtl::Turn::More(Rc::new(Zonk { st_p0: st_p0xxy.clone(), t_p1: a_p4.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
            }), move |each_9652: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyCon(n_p2.clone(), each_9652))),
            crate::check::types::Ty::TyFn(c_p5, ps_p6, res_p7) => crate::prelude::call_then(crate::check::types::colors::start_walk_col_f(st_p0x.clone(), c_p5.clone()), move |walk_col_f_9707: crate::check::types::Col| crate::prelude::call_value(crate::prelude::each_job(ps_p6.clone(), {
                let st_p0xx = st_p0x.clone();
                Rc::new(move |p0: crate::check::types::Ty| {
                    let st_p0xxy = st_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let p_p8 = p0;
                        prism_rtl::Turn::More(Rc::new(Zonk { st_p0: st_p0xxy.clone(), t_p1: p_p8.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
            }), move |each_9724: Array<crate::check::types::Ty>| crate::prelude::call_then(start_zonk_f(st_p0x.clone(), (*res_p7).clone()), move |zonk_f_9752: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyFn(walk_col_f_9707, each_9724, Rc::new(zonk_f_9752)))))),
            crate::check::types::Ty::TyTuple(ts_p9) => crate::prelude::call_value(crate::prelude::each_job(ts_p9.clone(), {
                let st_p0xx = st_p0x.clone();
                Rc::new(move |p0: crate::check::types::Ty| {
                    let st_p0xxy = st_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_pa = p0;
                        prism_rtl::Turn::More(Rc::new(Zonk { st_p0: st_p0xxy.clone(), t_p1: a_pa.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
            }), move |each_9791: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyTuple(each_9791))),
            crate::check::types::Ty::TyArray(e_pb) => crate::prelude::call_then(start_zonk_f(st_p0x.clone(), (*e_pb).clone()), move |zonk_f_9841: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyArray(Rc::new(zonk_f_9841)))),
            crate::check::types::Ty::TyMap(k_pc, v_pd) => crate::prelude::call_then(start_zonk_f(st_p0x.clone(), (*k_pc).clone()), move |zonk_f_9876: crate::check::types::Ty| crate::prelude::call_then(start_zonk_f(st_p0x.clone(), (*v_pd).clone()), move |zonk_f_9890: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyMap(Rc::new(zonk_f_9876), Rc::new(zonk_f_9890))))),
            crate::check::types::Ty::TySig(s_pe, i_pf) => crate::prelude::call_then(start_zonk_f(st_p0x.clone(), (*i_pf).clone()), move |zonk_f_9928: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TySig(s_pe.clone(), Rc::new(zonk_f_9928)))),
            crate::check::types::Ty::TyAt(i_pg, rw_ph) => crate::prelude::call_then(start_zonk_f(st_p0x.clone(), (*i_pg).clone()), move |zonk_f_9962: crate::check::types::Ty| crate::prelude::call_then(start_walk_row_f(st_p0x.clone(), rw_ph.clone()), move |walk_row_f_9976: crate::check::types::Rw| prism_rtl::Turn::Finished(crate::check::types::Ty::TyAt(Rc::new(zonk_f_9962), walk_row_f_9976)))),
            crate::check::types::Ty::TyElem(rw_pi, o_pj) => crate::prelude::call_then(start_walk_row_f(st_p0x.clone(), rw_pi.clone()), move |walk_row_f_10018: crate::check::types::Rw| crate::prelude::call_then(start_zonk_f(st_p0x.clone(), (*o_pj).clone()), move |zonk_f_10036: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyElem(walk_row_f_10018, Rc::new(zonk_f_10036))))),
            crate::check::types::Ty::TyElemAny(rw_pk) => crate::prelude::call_then(start_walk_row_f(st_p0x.clone(), rw_pk.clone()), move |walk_row_f_10077: crate::check::types::Rw| prism_rtl::Turn::Finished(crate::check::types::Ty::TyElemAny(walk_row_f_10077))),
            crate::check::types::Ty::TyAssoc(n_pl, a_pm) => crate::prelude::call_then(start_zonk_f(st_p0x.clone(), (*a_pm).clone()), move |zonk_f_10123: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyAssoc(n_pl.clone(), Rc::new(zonk_f_10123)))),
            w_pn => prism_rtl::Turn::Finished(w_pn.clone()),
        }))
    }
}

/// `Start Zonk, x`: what the function value is when passed to `@Run`.
pub fn start_zonk_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(Zonk { st_p0, t_p1 })
}

/// ```prism
/// FreeVars: unbounded fn St, Ty -> [Nat]
/// ```
pub fn free_vars_f(st_p0: &crate::check::types::St, t_p1: &crate::check::types::Ty) -> Array<Nat> {
    free_vars_into_f(st_p0, &Array::new(), t_p1)
}

/// The step machine of `FreeVars`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FreeVars: unbounded fn St, Ty -> [Nat]
/// ```
pub struct FreeVars {
    pub st_p0: crate::check::types::St,
    pub t_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<Array<Nat>> for FreeVars {
    fn cycle(&self) -> prism_rtl::Turn<Array<Nat>> {
        let st_p0 = &self.st_p0;
        let t_p1 = &self.t_p1;
        prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0.clone(), acc_p1: Array::new(), t_p2: t_p1.clone() }))
    }
}

/// `Start FreeVars, x`: what the function value is when passed to `@Run`.
pub fn start_free_vars_f(st_p0: crate::check::types::St, t_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Array<Nat>>> {
    Rc::new(FreeVars { st_p0, t_p1 })
}

/// ```prism
/// FreeVarsInto: unbounded fn St, [Nat], Ty -> [Nat]
/// ```
pub fn free_vars_into_f(st_p0: &crate::check::types::St, acc_p1: &Array<Nat>, t_p2: &crate::check::types::Ty) -> Array<Nat> {
    match walk_f(st_p0, t_p2) {
        crate::check::types::Ty::TyFlex(n_p3) => crate::check::types::add_nat_f(acc_p1, &n_p3),
        crate::check::types::Ty::TyCon(_, args_p4) => crate::prelude::run_to_end(crate::prelude::fold_job(args_p4.clone(), acc_p1.clone(), {
            let st_p0x = st_p0.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p5 = p0;
                    let x_p6 = p1;
                    prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0xy.clone(), acc_p1: a_p5.clone(), t_p2: x_p6.clone() }))
                }))
            }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        })),
        crate::check::types::Ty::TyFn(_, ps_p7, res_p8) => free_vars_into_f(st_p0, &crate::prelude::run_to_end(crate::prelude::fold_job(ps_p7.clone(), acc_p1.clone(), {
            let st_p0x = st_p0.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_p9 = p0;
                    let x_pa = p1;
                    prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0xy.clone(), acc_p1: a_p9.clone(), t_p2: x_pa.clone() }))
                }))
            }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        })), &*res_p8),
        crate::check::types::Ty::TyTuple(ts_pb) => crate::prelude::run_to_end(crate::prelude::fold_job(ts_pb.clone(), acc_p1.clone(), {
            let st_p0x = st_p0.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                let st_p0xy = st_p0x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let a_pc = p0;
                    let x_pd = p1;
                    prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0xy.clone(), acc_p1: a_pc.clone(), t_p2: x_pd.clone() }))
                }))
            }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        })),
        crate::check::types::Ty::TyArray(e_pe) => free_vars_into_f(st_p0, acc_p1, &*e_pe),
        crate::check::types::Ty::TyMap(k_pf, v_pg) => free_vars_into_f(st_p0, &free_vars_into_f(st_p0, acc_p1, &*k_pf), &*v_pg),
        crate::check::types::Ty::TySig(_, i_ph) => free_vars_into_f(st_p0, acc_p1, &*i_ph),
        crate::check::types::Ty::TyAt(i_pi, _) => free_vars_into_f(st_p0, acc_p1, &*i_pi),
        crate::check::types::Ty::TyElem(_, o_pj) => free_vars_into_f(st_p0, acc_p1, &*o_pj),
        crate::check::types::Ty::TyAssoc(_, a_pk) => free_vars_into_f(st_p0, acc_p1, &*a_pk),
        _ => acc_p1.clone(),
    }
}

/// The step machine of `FreeVarsInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FreeVarsInto: unbounded fn St, [Nat], Ty -> [Nat]
/// ```
pub struct FreeVarsInto {
    pub st_p0: crate::check::types::St,
    pub acc_p1: Array<Nat>,
    pub t_p2: crate::check::types::Ty,
}

impl prism_rtl::Job<Array<Nat>> for FreeVarsInto {
    fn cycle(&self) -> prism_rtl::Turn<Array<Nat>> {
        let st_p0 = &self.st_p0;
        let acc_p1 = &self.acc_p1;
        let t_p2 = &self.t_p2;
        let acc_p1x = acc_p1.clone();
        let st_p0x = st_p0.clone();
        let t_p2x = t_p2.clone();
        crate::prelude::call_then(start_walk_f(st_p0x.clone(), t_p2x.clone()), move |walk_f_10356: crate::check::types::Ty| match walk_f_10356 {
            crate::check::types::Ty::TyFlex(n_p3) => prism_rtl::Turn::Finished(crate::check::types::add_nat_f(&acc_p1x, &n_p3)),
            crate::check::types::Ty::TyCon(_, args_p4) => crate::prelude::fold_job(args_p4.clone(), acc_p1x.clone(), {
                let st_p0xx = st_p0x.clone();
                Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                    let st_p0xxy = st_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_p5 = p0;
                        let x_p6 = p1;
                        prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0xxy.clone(), acc_p1: a_p5.clone(), t_p2: x_p6.clone() }))
                    }))
                }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
            }).cycle(),
            crate::check::types::Ty::TyFn(_, ps_p7, res_p8) => crate::prelude::call_value(crate::prelude::fold_job(ps_p7.clone(), acc_p1x.clone(), {
                let st_p0xx = st_p0x.clone();
                Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                    let st_p0xxy = st_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_p9 = p0;
                        let x_pa = p1;
                        prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0xxy.clone(), acc_p1: a_p9.clone(), t_p2: x_pa.clone() }))
                    }))
                }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
            }), move |fold_10510: Array<Nat>| prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0x.clone(), acc_p1: fold_10510, t_p2: (*res_p8).clone() }))),
            crate::check::types::Ty::TyTuple(ts_pb) => crate::prelude::fold_job(ts_pb.clone(), acc_p1x.clone(), {
                let st_p0xx = st_p0x.clone();
                Rc::new(move |(p0, p1): (Array<Nat>, crate::check::types::Ty)| {
                    let st_p0xxy = st_p0xx.clone();
                    crate::prelude::entered(crate::prelude::once_job(move || {
                        let a_pc = p0;
                        let x_pd = p1;
                        prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0xxy.clone(), acc_p1: a_pc.clone(), t_p2: x_pd.clone() }))
                    }))
                }) as Rc<dyn Fn((Array<Nat>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
            }).cycle(),
            crate::check::types::Ty::TyArray(e_pe) => prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0x.clone(), acc_p1: acc_p1x.clone(), t_p2: (*e_pe).clone() })),
            crate::check::types::Ty::TyMap(k_pf, v_pg) => crate::prelude::call_then(start_free_vars_into_f(st_p0x.clone(), acc_p1x.clone(), (*k_pf).clone()), move |free_vars_into_f_10693: Array<Nat>| prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0x.clone(), acc_p1: free_vars_into_f_10693, t_p2: (*v_pg).clone() }))),
            crate::check::types::Ty::TySig(_, i_ph) => prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0x.clone(), acc_p1: acc_p1x.clone(), t_p2: (*i_ph).clone() })),
            crate::check::types::Ty::TyAt(i_pi, _) => prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0x.clone(), acc_p1: acc_p1x.clone(), t_p2: (*i_pi).clone() })),
            crate::check::types::Ty::TyElem(_, o_pj) => prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0x.clone(), acc_p1: acc_p1x.clone(), t_p2: (*o_pj).clone() })),
            crate::check::types::Ty::TyAssoc(_, a_pk) => prism_rtl::Turn::More(Rc::new(FreeVarsInto { st_p0: st_p0x.clone(), acc_p1: acc_p1x.clone(), t_p2: (*a_pk).clone() })),
            _ => prism_rtl::Turn::Finished(acc_p1x.clone()),
        })
    }
}

/// `Start FreeVarsInto, x`: what the function value is when passed to `@Run`.
pub fn start_free_vars_into_f(st_p0: crate::check::types::St, acc_p1: Array<Nat>, t_p2: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Array<Nat>>> {
    Rc::new(FreeVarsInto { st_p0, acc_p1, t_p2 })
}
